/* ==========================================================================
   timer.js — Pomodoro focus timer
   ========================================================================== */

const TimerState = {
  mode: 'focus',          // 'focus' | 'break'
  focusMinutes: 25,
  breakMinutes: 5,
  remainingSeconds: 25 * 60,
  intervalId: null,
  running: false,
  subjectId: null,
  elapsedFocusSeconds: 0  // accumulated focus time this session, for logging
};

function fmtTimer(totalSeconds) {
  const m = Math.floor(totalSeconds / 60).toString().padStart(2, '0');
  const s = Math.floor(totalSeconds % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

function updateTimerDisplay() {
  document.getElementById('timerDisplay').textContent = fmtTimer(TimerState.remainingSeconds);
  document.getElementById('timerModeLabel').textContent = TimerState.mode === 'focus' ? 'Focus' : 'Break';
}

function playChime() {
  if (!App.data.settings.soundEnabled) return;
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.value = 880;
    gain.gain.setValueAtTime(0.15, ctx.currentTime);
    osc.start();
    osc.stop(ctx.currentTime + 0.35);
  } catch (e) { /* audio not available, ignore */ }
}

function logFocusSession(minutes) {
  if (minutes <= 0) return;
  App.data.sessions.push({
    id: genId('sess'),
    date: todayISO(),
    subjectId: TimerState.subjectId || null,
    minutes: Math.round(minutes)
  });
  App.save();
}

function timerTick() {
  TimerState.remainingSeconds--;
  if (TimerState.mode === 'focus') TimerState.elapsedFocusSeconds++;

  if (TimerState.remainingSeconds <= 0) {
    clearInterval(TimerState.intervalId);
    TimerState.running = false;

    if (TimerState.mode === 'focus') {
      logFocusSession(TimerState.elapsedFocusSeconds / 60);
      TimerState.elapsedFocusSeconds = 0;
      showToast('Focus session complete! Time for a break. 🎉', 'success');
      playChime();
      TimerState.mode = 'break';
      TimerState.remainingSeconds = TimerState.breakMinutes * 60;
      renderRecentSessions();
    } else {
      showToast('Break over! Ready for another focus session?', 'info');
      playChime();
      TimerState.mode = 'focus';
      TimerState.remainingSeconds = TimerState.focusMinutes * 60;
    }
    setTimerButtons(false);
    updateTimerDisplay();
    return;
  }
  updateTimerDisplay();
}

function setTimerButtons(running) {
  document.getElementById('timerStartBtn').disabled = running;
  document.getElementById('timerPauseBtn').disabled = !running;
}

function startTimer() {
  if (TimerState.running) return;
  TimerState.running = true;
  setTimerButtons(true);
  TimerState.intervalId = setInterval(timerTick, 1000);
}

function pauseTimer() {
  TimerState.running = false;
  clearInterval(TimerState.intervalId);
  // log partial focus progress so time isn't lost if the user pauses and moves away
  if (TimerState.mode === 'focus' && TimerState.elapsedFocusSeconds >= 60) {
    logFocusSession(TimerState.elapsedFocusSeconds / 60);
    TimerState.elapsedFocusSeconds = 0;
    renderRecentSessions();
  }
  setTimerButtons(false);
}

function resetTimer() {
  clearInterval(TimerState.intervalId);
  TimerState.running = false;
  TimerState.mode = 'focus';
  TimerState.elapsedFocusSeconds = 0;
  TimerState.remainingSeconds = TimerState.focusMinutes * 60;
  setTimerButtons(false);
  updateTimerDisplay();
}

function renderRecentSessions() {
  const list = document.getElementById('recentSessionsList');
  const recent = App.data.sessions.slice().sort((a, b) => b.id.localeCompare(a.id)).slice(0, 8);
  if (recent.length === 0) {
    list.innerHTML = `<div class="empty-state"><div class="icon">⏱</div>No focus sessions logged yet. Start the timer above!</div>`;
    return;
  }
  list.innerHTML = recent.map(s => {
    const subj = App.data.subjects.find(x => x.id === s.subjectId);
    return `<div class="list-row">
      <div class="grow">
        <div class="title">${subj ? escapeHTML(subj.name) : 'No subject'}</div>
        <div class="meta">${fmtDate(s.date)}</div>
      </div>
      <span class="badge badge-low">${minutesToHM(s.minutes)}</span>
    </div>`;
  }).join('');
}

function renderTimerSection() {
  const select = document.getElementById('timerSubjectSelect');
  select.innerHTML = subjectOptionsHTML(TimerState.subjectId);
  document.getElementById('timerSoundToggle').checked = !!App.data.settings.soundEnabled;
  updateTimerDisplay();
  renderRecentSessions();
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('timerStartBtn').addEventListener('click', startTimer);
  document.getElementById('timerPauseBtn').addEventListener('click', pauseTimer);
  document.getElementById('timerResetBtn').addEventListener('click', resetTimer);

  document.getElementById('timerSubjectSelect').addEventListener('change', (e) => {
    TimerState.subjectId = e.target.value || null;
  });

  document.getElementById('timerSoundToggle').addEventListener('change', (e) => {
    App.data.settings.soundEnabled = e.target.checked;
    App.save();
  });

  document.querySelectorAll('#focusPresets .chip').forEach(chip => {
    chip.addEventListener('click', () => {
      document.querySelectorAll('#focusPresets .chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      let mins;
      if (chip.dataset.focus === 'custom') {
        mins = parseInt(prompt('Custom focus minutes:', '25'), 10);
        if (!mins || mins <= 0) { mins = 25; }
      } else {
        mins = parseInt(chip.dataset.focus, 10);
      }
      TimerState.focusMinutes = mins;
      if (TimerState.mode === 'focus' && !TimerState.running) {
        TimerState.remainingSeconds = mins * 60;
        updateTimerDisplay();
      }
    });
  });

  document.querySelectorAll('#breakPresets .chip').forEach(chip => {
    chip.addEventListener('click', () => {
      document.querySelectorAll('#breakPresets .chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      let mins;
      if (chip.dataset.break === 'custom') {
        mins = parseInt(prompt('Custom break minutes:', '5'), 10);
        if (!mins || mins <= 0) { mins = 5; }
      } else {
        mins = parseInt(chip.dataset.break, 10);
      }
      TimerState.breakMinutes = mins;
      if (TimerState.mode === 'break' && !TimerState.running) {
        TimerState.remainingSeconds = mins * 60;
        updateTimerDisplay();
      }
    });
  });
});
