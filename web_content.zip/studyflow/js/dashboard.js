/* ==========================================================================
   dashboard.js — app shell coordinator: auth guard, section navigation,
   shared App state object, and the Dashboard overview section itself.
   ========================================================================== */

const App = {
  user: null,
  data: null,
  save() {
    saveUserData(this.user.id, this.data);
  }
};

/* ---------- streak calculation (shared by dashboard + goals) ---------- */
function calcStreaks(sessions) {
  const studyDays = new Set(sessions.map(s => s.date));
  let current = 0;
  let cursor = new Date();
  // count backwards from today while consecutive days have a session
  while (true) {
    const iso = cursor.toISOString().slice(0, 10);
    if (studyDays.has(iso)) {
      current++;
      cursor.setDate(cursor.getDate() - 1);
    } else if (iso === todayISO()) {
      // today with no session yet doesn't break the streak, just skip it
      cursor.setDate(cursor.getDate() - 1);
    } else {
      break;
    }
  }
  // best streak: scan all study days
  const sortedDays = Array.from(studyDays).sort();
  let best = 0, run = 0, prev = null;
  sortedDays.forEach(d => {
    if (prev) {
      const diff = (new Date(d) - new Date(prev)) / 86400000;
      run = diff === 1 ? run + 1 : 1;
    } else {
      run = 1;
    }
    best = Math.max(best, run);
    prev = d;
  });
  best = Math.max(best, current);
  return { current, best };
}

/* ---------- section navigation ---------- */
function switchSection(name) {
  document.querySelectorAll('.section-view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-item[data-section]').forEach(n => n.classList.remove('active'));
  const view = document.getElementById(`view-${name}`);
  const nav = document.querySelector(`.nav-item[data-section="${name}"]`);
  if (view) view.classList.add('active');
  if (nav) nav.classList.add('active');
  closeSidebarMobile();

  // lazy-render each section when it's opened, so data always reflects latest state
  const renderers = {
    dashboard: renderDashboard,
    tasks: renderTasks,
    timer: renderTimerSection,
    subjects: renderSubjects,
    planner: renderPlanner,
    exams: renderExams,
    notes: renderNotes,
    goals: renderGoals,
    analytics: renderAnalytics,
    settings: renderSettings
  };
  if (renderers[name]) renderers[name]();
}

function openSidebarMobile() {
  document.getElementById('sidebar').classList.add('open');
  document.getElementById('sidebarBackdrop').classList.add('open');
}
function closeSidebarMobile() {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sidebarBackdrop').classList.remove('open');
}

/* ---------- generic modal helper (used by tasks/subjects/planner/exams/notes/goals) ---------- */
function openGenericModal(title, bodyHTML, onSave) {
  const overlay = document.getElementById('genericModal');
  document.getElementById('genericModalTitle').textContent = title;
  document.getElementById('genericModalBody').innerHTML = bodyHTML;
  overlay.classList.add('open');

  const saveBtn = document.getElementById('genericModalSave');
  const cancelBtn = document.getElementById('genericModalCancel');
  // reset defaults every open, in case a previous caller (e.g. planner action menu) changed them
  saveBtn.style.display = '';
  cancelBtn.textContent = 'Cancel';

  const close = () => overlay.classList.remove('open');
  const saveHandler = () => { if (onSave() !== false) close(); };
  const cancelHandler = () => close();

  // replace nodes to clear any previously bound listeners
  const newSave = saveBtn.cloneNode(true);
  saveBtn.parentNode.replaceChild(newSave, saveBtn);
  newSave.addEventListener('click', saveHandler);

  const newCancel = cancelBtn.cloneNode(true);
  cancelBtn.parentNode.replaceChild(newCancel, cancelBtn);
  newCancel.addEventListener('click', cancelHandler);
}
function closeGenericModal() {
  document.getElementById('genericModal').classList.remove('open');
}

/* ---------- Dashboard overview section ---------- */
function renderDashboard() {
  const { tasks, sessions, subjects, exams, planner, settings } = App.data;
  const today = todayISO();

  document.getElementById('welcomeMsg').textContent = `Welcome back, ${App.user.fullName.split(' ')[0]}! 👋`;
  document.getElementById('todayDateLabel').textContent = new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

  const todaysTasks = tasks.filter(t => t.date === today);
  const completedToday = todaysTasks.filter(t => t.completed).length;
  const todaysMinutes = sessions.filter(s => s.date === today).reduce((sum, s) => sum + s.minutes, 0);
  const weekStart = isoDaysAgo(6);
  const weekMinutes = sessions.filter(s => s.date >= weekStart).reduce((sum, s) => sum + s.minutes, 0);
  const streaks = calcStreaks(sessions);

  const cards = [
    { label: "Today's Tasks", value: todaysTasks.length, hint: `${completedToday} completed` },
    { label: 'Completed Tasks', value: tasks.filter(t => t.completed).length, hint: `of ${tasks.length} total` },
    { label: "Today's Study Time", value: minutesToHM(todaysMinutes), hint: `Goal: ${minutesToHM(settings.dailyGoalMinutes)}` },
    { label: 'Current Streak', value: `🔥 ${streaks.current}d`, hint: `Best: ${streaks.best}d` },
    { label: 'Daily Goal', value: `${Math.min(100, Math.round((todaysMinutes / settings.dailyGoalMinutes) * 100 || 0))}%`, hint: `${minutesToHM(todaysMinutes)} / ${minutesToHM(settings.dailyGoalMinutes)}` },
    { label: 'Weekly Goal', value: `${Math.min(100, Math.round((weekMinutes / settings.weeklyGoalMinutes) * 100 || 0))}%`, hint: `${minutesToHM(weekMinutes)} / ${minutesToHM(settings.weeklyGoalMinutes)}` }
  ];
  document.getElementById('dashboardCards').innerHTML = cards.map(c => `
    <div class="stat-card">
      <div class="label">${c.label}</div>
      <div class="value">${c.value}</div>
      <div class="hint">${c.hint}</div>
    </div>`).join('');

  // Today's plan: tasks + planner sessions + upcoming exams
  const todaysPlanner = planner.filter(p => p.date === today);
  const upcomingExams = exams.filter(e => daysUntil(e.date, e.time) >= 0).sort((a, b) => new Date(a.date) - new Date(b.date)).slice(0, 3);
  const remainingMinutes = todaysTasks.filter(t => !t.completed).reduce((s, t) => s + (t.estMinutes || 0), 0);

  let planHTML = '';
  if (todaysTasks.length === 0 && todaysPlanner.length === 0 && upcomingExams.length === 0) {
    planHTML = `<div class="empty-state"><div class="icon">🌿</div>Nothing scheduled for today. Enjoy the calm!</div>`;
  } else {
    if (todaysTasks.length) {
      planHTML += `<div class="meta" style="margin-bottom:6px; font-weight:700;">Tasks</div>`;
      planHTML += todaysTasks.map(t => `
        <div class="list-row">
          <div class="check ${t.completed ? 'checked' : ''}"></div>
          <div class="grow"><div class="title ${t.completed ? 'done' : ''}">${escapeHTML(t.title)}</div></div>
          <span class="badge badge-${t.priority}">${t.priority}</span>
        </div>`).join('');
    }
    if (todaysPlanner.length) {
      planHTML += `<div class="meta" style="margin:12px 0 6px; font-weight:700;">Planner Sessions</div>`;
      planHTML += todaysPlanner.map(p => `
        <div class="list-row"><div class="grow"><div class="title">${escapeHTML(p.topic)}</div><div class="meta">${p.duration} min</div></div></div>`).join('');
    }
    if (upcomingExams.length) {
      planHTML += `<div class="meta" style="margin:12px 0 6px; font-weight:700;">Upcoming Exams</div>`;
      planHTML += upcomingExams.map(e => `
        <div class="list-row"><div class="grow"><div class="title">${escapeHTML(e.name)}</div></div><span class="badge badge-medium">${examCountdownLabel(e.date, e.time)}</span></div>`).join('');
    }
    planHTML += `<div class="meta" style="margin-top:12px;">⏳ Remaining estimated study time today: <strong>${minutesToHM(remainingMinutes)}</strong></div>`;
  }
  document.getElementById('todaysPlanList').innerHTML = planHTML;

  // clicking a task checkbox in the dashboard toggles it too
  document.querySelectorAll('#todaysPlanList .check').forEach((el, i) => {
    if (i < todaysTasks.length) {
      el.addEventListener('click', () => { toggleTaskComplete(todaysTasks[i].id); renderDashboard(); });
    }
  });

  // subject progress
  document.getElementById('dashSubjectProgress').innerHTML = subjects.length ? subjects.map(subj => {
    const minutes = sessions.filter(s => s.subjectId === subj.id && s.date >= weekStart).reduce((s, x) => s + x.minutes, 0);
    const pct = Math.min(100, Math.round((minutes / subj.weeklyTargetMinutes) * 100 || 0));
    return `
      <div class="subject-card" style="border-left-color:${subj.color}">
        <h4>${escapeHTML(subj.name)}</h4>
        <div class="meta">${minutes} / ${subj.weeklyTargetMinutes} minutes</div>
        <div class="progress-bar" style="margin:10px 0;"><div class="fill" style="width:${pct}%; background:${subj.color}"></div></div>
        <div class="meta">${pct}%</div>
      </div>`;
  }).join('') : `<div class="empty-state"><div class="icon">📚</div>No subjects yet. Add one from the Subjects page.</div>`;

  // last 7 days mini chart
  renderLast7Chart(sessions);
}

function renderLast7Chart(sessions) {
  const canvas = document.getElementById('last7Chart');
  if (!canvas || typeof Chart === 'undefined') return;
  const labels = [];
  const values = [];
  for (let i = 6; i >= 0; i--) {
    const day = isoDaysAgo(i);
    labels.push(new Date(day + 'T00:00:00').toLocaleDateString(undefined, { weekday: 'short' }));
    values.push(sessions.filter(s => s.date === day).reduce((s, x) => s + x.minutes, 0));
  }
  if (canvas._chart) canvas._chart.destroy();
  canvas._chart = new Chart(canvas, {
    type: 'bar',
    data: { labels, datasets: [{ label: 'Minutes', data: values, backgroundColor: '#6366f1', borderRadius: 6 }] },
    options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
  });
}

/* ---------- boot ---------- */
document.addEventListener('DOMContentLoaded', () => {
  const user = requireAuthOrRedirect();
  if (!user) return;

  App.user = user;
  App.data = getUserData(user.id);
  applyStoredTheme();

  // nav clicks
  document.querySelectorAll('.nav-item[data-section]').forEach(item => {
    item.addEventListener('click', () => switchSection(item.dataset.section));
  });

  document.getElementById('logoutBtn').addEventListener('click', () => {
    logout();
    window.location.href = 'login.html';
  });

  // mobile menu
  document.getElementById('hamburgerBtn').addEventListener('click', openSidebarMobile);
  document.getElementById('sidebarBackdrop').addEventListener('click', closeSidebarMobile);

  renderDashboard();
});
