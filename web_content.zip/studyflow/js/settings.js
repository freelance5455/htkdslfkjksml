/* ==========================================================================
   settings.js — settings section
   ========================================================================== */

function renderSettings() {
  document.getElementById('settingFullName').value = App.user.fullName;
  document.getElementById('settingUsername').value = App.user.username;
  document.getElementById('settingEmail').value = App.user.email;
  document.getElementById('settingDailyGoal').value = App.data.settings.dailyGoalMinutes;
  document.getElementById('settingWeeklyGoal').value = App.data.settings.weeklyGoalMinutes;
  document.getElementById('darkModeToggle').checked = App.data.settings.theme === 'dark';
}

function saveProfile() {
  const fullName = document.getElementById('settingFullName').value.trim();
  const username = document.getElementById('settingUsername').value.trim();
  const email = document.getElementById('settingEmail').value.trim();

  if (!fullName || !username || !email) { showToast('All profile fields are required', 'error'); return; }
  if (!isValidEmail(email)) { showToast('Enter a valid email address', 'error'); return; }

  const users = getUsers();
  const dup = users.find(u => u.email.toLowerCase() === email.toLowerCase() && u.id !== App.user.id);
  if (dup) { showToast('That email is already used by another account', 'error'); return; }

  const userRecord = users.find(u => u.id === App.user.id);
  userRecord.fullName = fullName;
  userRecord.username = username;
  userRecord.email = email;
  saveUsers(users);
  App.user = userRecord;
  showToast('Profile updated', 'success');
  renderDashboard();
}

function saveGoals() {
  const daily = parseInt(document.getElementById('settingDailyGoal').value, 10) || 0;
  const weekly = parseInt(document.getElementById('settingWeeklyGoal').value, 10) || 0;
  App.data.settings.dailyGoalMinutes = daily;
  App.data.settings.weeklyGoalMinutes = weekly;
  App.save();
  showToast('Study goals updated', 'success');
}

function handleExport() {
  exportUserData(App.user.id);
  showToast('Backup downloaded', 'success');
}

function handleImportFile(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const payload = JSON.parse(reader.result);
      importUserData(App.user.id, payload);
      App.data = getUserData(App.user.id);
      showToast('Data imported successfully', 'success');
      renderDashboard();
      renderSettings();
    } catch (err) {
      console.error(err);
      showToast(err.message || 'Failed to import file — invalid backup format.', 'error');
    }
  };
  reader.onerror = () => showToast('Could not read that file.', 'error');
  reader.readAsText(file);
}

function handleClearData() {
  if (!confirm('This will permanently delete all your tasks, sessions, planner entries, exams, notes and goals. Continue?')) return;
  clearUserStudyData(App.user.id);
  App.data = getUserData(App.user.id);
  showToast('Study data cleared', 'info');
  renderDashboard();
}

function handleLoadDemo() {
  if (!confirm('Load demo data? This adds sample subjects, tasks, planner sessions, exams and notes on top of your current data.')) return;
  const fresh = getUserData(App.user.id);
  loadDemoData(App.user.id);
  App.data = getUserData(App.user.id);
  showToast('Demo data loaded ✨', 'success');
  renderDashboard();
}

function handleDeleteAccount() {
  if (!confirm('This will permanently delete your account and all associated data from this browser. This cannot be undone. Continue?')) return;
  deleteUserAccount(App.user.id);
  window.location.href = 'index.html';
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('saveProfileBtn').addEventListener('click', saveProfile);
  document.getElementById('saveGoalsBtn').addEventListener('click', saveGoals);

  document.getElementById('darkModeToggle').addEventListener('change', (e) => {
    setTheme(e.target.checked ? 'dark' : 'light');
    App.data = getUserData(App.user.id);
  });

  document.getElementById('exportDataBtn').addEventListener('click', handleExport);

  document.getElementById('importDataBtn').addEventListener('click', () => {
    document.getElementById('importFileInput').click();
  });
  document.getElementById('importFileInput').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) handleImportFile(file);
    e.target.value = '';
  });

  document.getElementById('loadDemoBtn').addEventListener('click', handleLoadDemo);
  document.getElementById('clearDataBtn').addEventListener('click', handleClearData);

  document.getElementById('settingsLogoutBtn').addEventListener('click', () => {
    logout();
    window.location.href = 'login.html';
  });
  document.getElementById('deleteAccountBtn').addEventListener('click', handleDeleteAccount);
});
