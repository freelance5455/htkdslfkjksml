/* ==========================================================================
   analytics.js — analytics section (uses Chart.js loaded via CDN in
   dashboard.html; if the CDN fails to load, canvases are simply skipped
   and the numeric stat cards still render fully without it).
   ========================================================================== */

function destroyChart(canvas) {
  if (canvas && canvas._chart) {
    canvas._chart.destroy();
    canvas._chart = null;
  }
}

function renderAnalytics() {
  const { sessions, tasks, subjects } = App.data;
  const today = todayISO();

  const totalMinutes = sessions.reduce((s, x) => s + x.minutes, 0);
  const todayMinutes = sessions.filter(s => s.date === today).reduce((s, x) => s + x.minutes, 0);
  const weekMinutes = sessions.filter(s => s.date >= isoDaysAgo(6)).reduce((s, x) => s + x.minutes, 0);
  const monthMinutes = sessions.filter(s => s.date >= isoDaysAgo(29)).reduce((s, x) => s + x.minutes, 0);
  const streaks = calcStreaks(sessions);

  const cards = [
    { label: 'Total Study Time', value: minutesToHM(totalMinutes) },
    { label: "Today's Study Time", value: minutesToHM(todayMinutes) },
    { label: 'Weekly Study Time', value: minutesToHM(weekMinutes) },
    { label: 'Monthly Study Time', value: minutesToHM(monthMinutes) },
    { label: 'Completed Tasks', value: tasks.filter(t => t.completed).length },
    { label: 'Remaining Tasks', value: tasks.filter(t => !t.completed).length },
    { label: 'Focus Sessions', value: sessions.length },
    { label: 'Current / Best Streak', value: `${streaks.current} / ${streaks.best} days` }
  ];
  document.getElementById('analyticsCards').innerHTML = cards.map(c => `
    <div class="stat-card"><div class="label">${c.label}</div><div class="value">${c.value}</div></div>
  `).join('');

  if (typeof Chart === 'undefined') {
    // graceful fallback: hide chart canvases' parent boxes' canvas, keep the rest of the app working
    document.querySelectorAll('#view-analytics canvas').forEach(c => {
      c.replaceWith(document.createTextNode('Chart library unavailable — showing numbers only.'));
    });
    return;
  }

  // Last 7 days
  const c1 = document.getElementById('chartLast7');
  destroyChart(c1);
  const days7 = [], vals7 = [];
  for (let i = 6; i >= 0; i--) {
    const d = isoDaysAgo(i);
    days7.push(new Date(d + 'T00:00:00').toLocaleDateString(undefined, { weekday: 'short' }));
    vals7.push(sessions.filter(s => s.date === d).reduce((s, x) => s + x.minutes, 0));
  }
  c1._chart = new Chart(c1, {
    type: 'line',
    data: { labels: days7, datasets: [{ label: 'Minutes', data: vals7, borderColor: '#6366f1', backgroundColor: 'rgba(99,102,241,0.15)', fill: true, tension: 0.3 }] },
    options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
  });

  // Subject distribution
  const c2 = document.getElementById('chartSubjects');
  destroyChart(c2);
  const subjMinutes = subjects.map(s => sessions.filter(x => x.subjectId === s.id).reduce((sum, x) => sum + x.minutes, 0));
  c2._chart = new Chart(c2, {
    type: 'doughnut',
    data: {
      labels: subjects.length ? subjects.map(s => s.name) : ['No subjects'],
      datasets: [{ data: subjects.length ? subjMinutes : [1], backgroundColor: subjects.length ? subjects.map(s => s.color) : ['#e5e7eb'] }]
    },
    options: { plugins: { legend: { position: 'bottom' } } }
  });

  // Weekly study time (last 4 weeks)
  const c3 = document.getElementById('chartWeekly');
  destroyChart(c3);
  const weekLabels = [], weekVals = [];
  for (let w = 3; w >= 0; w--) {
    const start = isoDaysAgo(w * 7 + 6);
    const end = isoDaysAgo(w * 7);
    weekLabels.push(w === 0 ? 'This week' : `${w}w ago`);
    weekVals.push(sessions.filter(s => s.date >= start && s.date <= end).reduce((s, x) => s + x.minutes, 0));
  }
  c3._chart = new Chart(c3, {
    type: 'bar',
    data: { labels: weekLabels, datasets: [{ label: 'Minutes', data: weekVals, backgroundColor: '#22c55e', borderRadius: 6 }] },
    options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
  });

  // Task completion
  const c4 = document.getElementById('chartTasks');
  destroyChart(c4);
  const completedCount = tasks.filter(t => t.completed).length;
  const remainingCount = tasks.filter(t => !t.completed).length;
  c4._chart = new Chart(c4, {
    type: 'pie',
    data: { labels: ['Completed', 'Remaining'], datasets: [{ data: [completedCount, remainingCount], backgroundColor: ['#22c55e', '#e5e7eb'] }] },
    options: { plugins: { legend: { position: 'bottom' } } }
  });
}
