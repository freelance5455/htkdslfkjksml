/* ==========================================================================
   auth.js — register + login page behaviour
   ========================================================================== */

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function setFieldError(id, message) {
  const el = document.getElementById(`err-${id}`);
  if (el) el.textContent = message || '';
}

function clearAllFieldErrors(ids) {
  ids.forEach(id => setFieldError(id, ''));
}

function showFormMessage(text, type = 'error') {
  const box = document.getElementById('formMessage');
  if (!box) return;
  box.textContent = text;
  box.className = `form-message show ${type}`;
}

/* ---------- Register page ---------- */

function initRegisterPage() {
  // if already logged in, go straight to dashboard
  if (getCurrentUser()) {
    window.location.href = 'dashboard.html';
    return;
  }

  const form = document.getElementById('registerForm');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearAllFieldErrors(['fullName', 'username', 'email', 'password', 'confirmPassword']);

    const fullName = document.getElementById('fullName').value.trim();
    const username = document.getElementById('username').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    let valid = true;

    if (!fullName) { setFieldError('fullName', 'Full name is required.'); valid = false; }
    if (!username) { setFieldError('username', 'Username is required.'); valid = false; }
    if (!email) {
      setFieldError('email', 'Email is required.'); valid = false;
    } else if (!isValidEmail(email)) {
      setFieldError('email', 'Enter a valid email address.'); valid = false;
    }
    if (!password || password.length < 6) {
      setFieldError('password', 'Password must be at least 6 characters.'); valid = false;
    }
    if (confirmPassword !== password) {
      setFieldError('confirmPassword', 'Passwords do not match.'); valid = false;
    }

    if (!valid) return;

    if (findUserByEmail(email)) {
      setFieldError('email', 'An account with this email already exists.');
      showFormMessage('That email is already registered. Try logging in instead.', 'error');
      return;
    }

    const submitBtn = form.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.textContent = 'Creating account...';

    try {
      const user = await createUser({ fullName, username, email, password });
      setCurrentUser(user.id);
      showFormMessage('Account created! Redirecting to your dashboard...', 'success');
      setTimeout(() => { window.location.href = 'dashboard.html'; }, 600);
    } catch (err) {
      console.error(err);
      showFormMessage('Something went wrong creating your account. Please try again.', 'error');
      submitBtn.disabled = false;
      submitBtn.textContent = 'Create Account';
    }
  });
}

/* ---------- Login page ---------- */

function initLoginPage() {
  if (getCurrentUser()) {
    window.location.href = 'dashboard.html';
    return;
  }

  const form = document.getElementById('loginForm');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearAllFieldErrors(['email', 'password']);

    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;

    let valid = true;
    if (!email) { setFieldError('email', 'Email is required.'); valid = false; }
    if (!password) { setFieldError('password', 'Password is required.'); valid = false; }
    if (!valid) return;

    const user = findUserByEmail(email);
    if (!user) {
      showFormMessage('No account found with that email.', 'error');
      return;
    }

    const ok = await verifyPassword(user, password);
    if (!ok) {
      showFormMessage('Incorrect password. Please try again.', 'error');
      return;
    }

    setCurrentUser(user.id);
    showFormMessage('Logged in! Redirecting...', 'success');
    setTimeout(() => { window.location.href = 'dashboard.html'; }, 400);
  });

  // Forgot password modal
  const forgotLink = document.getElementById('forgotLink');
  const forgotModal = document.getElementById('forgotModal');
  const closeForgotModal = document.getElementById('closeForgotModal');
  if (forgotLink) {
    forgotLink.addEventListener('click', (e) => {
      e.preventDefault();
      forgotModal.classList.add('open');
    });
    closeForgotModal.addEventListener('click', () => forgotModal.classList.remove('open'));
    forgotModal.addEventListener('click', (e) => {
      if (e.target === forgotModal) forgotModal.classList.remove('open');
    });
  }
}
