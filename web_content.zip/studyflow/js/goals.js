/* ==========================================================================
   goals.js — goals section + streak calendar
   ========================================================================== */

function openGoalModal(existing) {
  const g = existing || { type: 'daily', label: '', targetMinutes: 60, targetTasks: 10, subjectId: '' };
  const body = `
    <div class="form-row"><label>Goal Type</label>
      <select id="f-type">
        <option value="daily" ${g.type === 'daily' ? 'selected' : ''}>Daily (minutes)</option>
        <option value="weekly" ${g.type === 'weekly' ? 'selected' : ''}>Weekly (minutes)</option>
        <option value="monthly" ${g.type === 'monthly' ? 'selected' : ''}>Monthly (minutes)</option>
        <option value="subject" ${g.type === 'subject' ? 'selected' : ''}>Subject (task count)</option>
      </select>
    </div>
    <div class="form-row"><label>Label</label><input type="text" id="f-label" value="${escapeHTML(g.label)}" placeholder="e.g. Study 2 hours today"></div>
    <div id="f-target-wrap"></div>
    <div class="form-row" id="f-subject-wrap"><label>Subject (for subject goals)</label><select id="f-subject">${subjectOptionsHTML(g.subjectId)}</select></div>
  `;
  openGenericModal(existing ? 'Edit Goal' : 'Add Goal', body, () => {
    const type = document.getElementById('f-type').value;
    const label = document.getElementById('f-label').value.trim();
    if (!label) { showToast('Label is required', 'error'); return false; }
    const payload = { type, label, subjectId: document.getElementById('f-subject').value || null };
    if (type === 'subject') {
      payload.targetTasks = parseInt(document.getElementById('f-target').value, 10) || 0;
    } else {
      payload.targetMinutes = parseInt(document.getElementById('f-target').value, 10) || 0;
    }
    if (existing) {
      Object.assign(existing, payload);
    } else {
      App.data.goals.push({ id: genId('goal'), ...payload });
    }
    App.save();
    renderGoals();
    showToast(existing ? 'Goal updated' : 'Goal added', 'success');
  });

  function renderTargetField() {
    const type = document.getElementById('f-type').value;
    const wrap = document.getElementById('f-target-wrap');
    if (type === 'subject') {
      wrap.innerHTML = `<div class="form-row"><label>Target Task Count</label><input type="number" id="f-target" min="0" value="${g.targetTasks || 10}"></div>`;
    } else {
      wrap.innerHTML = `<div class="form-row"><label>Target Minutes</label><input type="number" id="f-target" min="0" value="${g.targetMinutes || 60}"></div>`;
    }
  }
  renderTargetField();
  document.getElementById('f-type').addEventListener('change', renderTargetField);
}

function deleteGoal(id) {
  App.data.goals = App.data.goals.filter(g => g.id !== id);
  App.save();
  renderGoals();
  showToast('Goal deleted', 'info');
}

function goalProgress(goal) {
  const { sessions, tasks } = App.data;
  const today = todayISO();

  if (goal.type === 'subject') {
    const completed = tasks.filter(t => t.subjectId === goal.subjectId && t.completed).length;
    const pct = Math.min(100, Math.round((completed / (goal.targetTasks || 1)) * 100));
    return { current: completed, target: goal.targetTasks, pct, unit: 'tasks' };
  }

  let rangeStart;
  if (goal.type === 'daily') rangeStart = today;
  else if (goal.type === 'weekly') rangeStart = isoDaysAgo(6);
  else rangeStart = isoDaysAgo(29); // monthly ~ last 30 days

  let filtered = sessions.filter(s => s.date >= rangeStart && s.date <= today);
  if (goal.subjectId) filtered = filtered.filter(s => s.subjectId === goal.subjectId);
  const minutes = filtered.reduce((sum, s) => sum + s.minutes, 0);
  const pct = Math.min(100, Math.round((minutes / (goal.targetMinutes || 1)) * 100));
  return { current: minutes, target: goal.targetMinutes, pct, unit: 'minutes' };
}

function renderGoals() {
  const grid = document.getElementById('goalsGrid');
  if (App.data.goals.length === 0) {
    grid.innerHTML = `<div class="empty-state"><div class="icon">🎯</div>No goals yet. Add a daily, weekly, monthly or subject goal.</div>`;
  } else {
    grid.innerHTML = App.data.goals.map(g => {
      const prog = goalProgress(g);
      return `
        <div class="subject-card" data-id="${g.id}">
          <div style="display:flex; justify-content:space-between; align-items:start;">
            <div>
              <span class="badge badge-medium" style="text-transform:capitalize;">${g.type}</span>
              <h4 style="margin-top:8px;">${escapeHTML(g.label)}</h4>
            </div>
            <div class="actions">
              <button class="icon-btn" data-action="edit">✏️</button>
              <button class="icon-btn" data-action="delete">🗑</button>
            </div>
          </div>
          <div class="meta">${prog.unit === 'minutes' ? minutesToHM(prog.current) + ' / ' + minutesToHM(prog.target) : prog.current + ' / ' + prog.target + ' tasks'}</div>
          <div class="progress-bar" style="margin:10px 0;"><div class="fill" style="width:${prog.pct}%"></div></div>
          <div class="meta">${prog.pct}%</div>
        </div>`;
    }).join('');
  }

  grid.querySelectorAll('.subject-card').forEach(card => {
    const id = card.dataset.id;
    const goal = App.data.goals.find(g => g.id === id);
    card.querySelector('[data-action="edit"]').addEventListener('click', () => openGoalModal(goal));
    card.querySelector('[data-action="delete"]').addEventListener('click', () => {
      if (confirm('Delete this goal?')) deleteGoal(id);
    });
  });

  renderStreakSection();
}

function renderStreakSection() {
  const streaks = calcStreaks(App.data.sessions);
  document.getElementById('currentStreakVal').textContent = `🔥 ${streaks.current} days`;
  document.getElementById('bestStreakVal').textContent = `🏆 ${streaks.best} days`;

  const studyDays = new Set(App.data.sessions.map(s => s.date));
  const cal = document.getElementById('streakCalendar');
  const cells = [];
  for (let i = 27; i >= 0; i--) {
    const day = isoDaysAgo(i);
    cells.push(`<div class="cal-cell ${studyDays.has(day) ? 'active' : ''}" title="${day}"></div>`);
  }
  cal.innerHTML = cells.join('');
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('addGoalBtn').addEventListener('click', () => openGoalModal(null));
});
