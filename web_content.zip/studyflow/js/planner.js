/* ==========================================================================
   planner.js — weekly study planner section
   ========================================================================== */

function currentWeekDates() {
  const now = new Date();
  const dayOfWeek = now.getDay(); // 0 = Sunday
  const start = new Date(now);
  start.setDate(now.getDate() - dayOfWeek);
  const days = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    days.push(d.toISOString().slice(0, 10));
  }
  return days;
}

function openPlanModal(existing) {
  const p = existing || { date: todayISO(), subjectId: '', topic: '', duration: 30, priority: 'medium', notes: '', completed: false };
  const body = `
    <div class="form-grid-2">
      <div class="form-row"><label>Date</label><input type="date" id="f-date" value="${p.date}"></div>
      <div class="form-row"><label>Subject</label><select id="f-subject">${subjectOptionsHTML(p.subjectId)}</select></div>
    </div>
    <div class="form-row"><label>Topic</label><input type="text" id="f-topic" value="${escapeHTML(p.topic)}" placeholder="e.g. Quadratic equations"></div>
    <div class="form-grid-2">
      <div class="form-row"><label>Duration (minutes)</label><input type="number" id="f-duration" min="0" value="${p.duration}"></div>
      <div class="form-row"><label>Priority</label>
        <select id="f-priority">
          <option value="low" ${p.priority === 'low' ? 'selected' : ''}>Low</option>
          <option value="medium" ${p.priority === 'medium' ? 'selected' : ''}>Medium</option>
          <option value="high" ${p.priority === 'high' ? 'selected' : ''}>High</option>
        </select>
      </div>
    </div>
    <div class="form-row"><label>Notes</label><textarea id="f-notes">${escapeHTML(p.notes)}</textarea></div>
  `;
  openGenericModal(existing ? 'Edit Session' : 'Add Session', body, () => {
    const topic = document.getElementById('f-topic').value.trim();
    if (!topic) { showToast('Topic is required', 'error'); return false; }
    const payload = {
      date: document.getElementById('f-date').value || todayISO(),
      subjectId: document.getElementById('f-subject').value || null,
      topic,
      duration: parseInt(document.getElementById('f-duration').value, 10) || 0,
      priority: document.getElementById('f-priority').value,
      notes: document.getElementById('f-notes').value.trim()
    };
    if (existing) {
      Object.assign(existing, payload);
    } else {
      App.data.planner.push({ id: genId('plan'), completed: false, ...payload });
    }
    App.save();
    renderPlanner();
    showToast(existing ? 'Session updated' : 'Session added', 'success');
  });
}

function deletePlanEntry(id) {
  App.data.planner = App.data.planner.filter(p => p.id !== id);
  App.save();
  renderPlanner();
  showToast('Session removed', 'info');
}

function renderPlanner() {
  const week = currentWeekDates();
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const grid = document.getElementById('weekGrid');

  grid.innerHTML = week.map((dateISO, idx) => {
    const entries = App.data.planner.filter(p => p.date === dateISO);
    const isToday = dateISO === todayISO();
    return `
      <div class="week-day" style="${isToday ? 'border-color:var(--brand); border-width:2px;' : ''}">
        <h5>${dayNames[idx]} · ${new Date(dateISO + 'T00:00:00').getDate()}</h5>
        ${entries.length ? entries.map(e => {
          const subj = App.data.subjects.find(s => s.id === e.subjectId);
          return `<div class="week-entry" data-id="${e.id}" style="border-left:3px solid ${subj ? subj.color : '#999'}; ${e.completed ? 'opacity:0.55; text-decoration:line-through;' : ''}">
            <div>${escapeHTML(e.topic)}</div>
            <div style="color:var(--text-muted);">${e.duration}min</div>
          </div>`;
        }).join('') : `<div style="font-size:11.5px; color:var(--text-muted);">—</div>`}
      </div>`;
  }).join('');

  grid.querySelectorAll('.week-entry').forEach(el => {
    const id = el.dataset.id;
    const entry = App.data.planner.find(p => p.id === id);
    el.style.cursor = 'pointer';
    el.addEventListener('click', () => openPlannerActionMenu(entry));
  });
}

function openPlannerActionMenu(entry) {
  const body = `
    <p style="color:var(--text-muted); font-size:14px;">What would you like to do with "<strong>${escapeHTML(entry.topic)}</strong>"?</p>
    <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:14px;">
      <button class="btn btn-outline btn-sm" id="pa-complete">${entry.completed ? '↺ Mark Incomplete' : '✓ Mark Complete'}</button>
      <button class="btn btn-outline btn-sm" id="pa-edit">✏️ Edit</button>
      <button class="btn btn-danger btn-sm" id="pa-delete">🗑 Delete</button>
    </div>
  `;
  openGenericModal('Session Options', body, () => false);
  document.getElementById('pa-complete').addEventListener('click', () => {
    entry.completed = !entry.completed;
    App.save();
    renderPlanner();
    closeGenericModal();
  });
  document.getElementById('pa-edit').addEventListener('click', () => { closeGenericModal(); openPlanModal(entry); });
  document.getElementById('pa-delete').addEventListener('click', () => {
    if (confirm('Delete this planner session?')) { deletePlanEntry(entry.id); closeGenericModal(); }
  });
  document.getElementById('genericModalSave').style.display = 'none';
  document.getElementById('genericModalCancel').textContent = 'Close';
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('addPlanBtn').addEventListener('click', () => {
    document.getElementById('genericModalSave').style.display = '';
    document.getElementById('genericModalCancel').textContent = 'Cancel';
    openPlanModal(null);
  });
});
