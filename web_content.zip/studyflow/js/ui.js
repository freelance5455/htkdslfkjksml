/* ==========================================================================
   ui.js — small shared UI helpers used across pages (toasts, theme, dates)
   ========================================================================== */

function showToast(message, type = 'info') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.textContent = message;
  container.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add('show'));
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

function applyStoredTheme() {
  const user = typeof getCurrentUser === 'function' ? getCurrentUser() : null;
  let theme = 'light';
  if (user) {
    theme = getUserData(user.id).settings.theme || 'light';
  } else {
    theme = localStorage.getItem('studyflow_guest_theme') || 'light';
  }
  document.documentElement.setAttribute('data-theme', theme);
  return theme;
}

function setTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  const user = typeof getCurrentUser === 'function' ? getCurrentUser() : null;
  if (user) {
    const data = getUserData(user.id);
    data.settings.theme = theme;
    saveUserData(user.id, data);
  } else {
    localStorage.setItem('studyflow_guest_theme', theme);
  }
}

function fmtDate(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
}

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

function isoDaysAgo(n) {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d.toISOString().slice(0, 10);
}

function minutesToHM(mins) {
  const h = Math.floor(mins / 60);
  const m = Math.round(mins % 60);
  if (h === 0) return `${m}m`;
  if (m === 0) return `${h}h`;
  return `${h}h ${m}m`;
}

function escapeHTML(str) {
  const div = document.createElement('div');
  div.textContent = str ?? '';
  return div.innerHTML;
}

function daysUntil(dateStr, timeStr) {
  const target = new Date(`${dateStr}T${timeStr || '00:00'}`);
  const now = new Date();
  const diffMs = target - now;
  const diffDays = Math.ceil(diffMs / 86400000);
  return diffDays;
}

function examCountdownLabel(dateStr, timeStr) {
  const days = daysUntil(dateStr, timeStr);
  if (days < 0) return 'Passed';
  if (days === 0) return 'Today';
  if (days === 1) return 'Tomorrow';
  return `${days} days left`;
}
