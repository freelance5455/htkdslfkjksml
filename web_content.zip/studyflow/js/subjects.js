/* ==========================================================================
   subjects.js — subject management section
   ========================================================================== */

const SUBJECT_COLORS = ['#6366f1', '#22c55e', '#f59e0b', '#ef4444', '#06b6d4', '#a855f7', '#ec4899', '#84cc16'];

function openSubjectModal(existing) {
  const s = existing || { name: '', color: SUBJECT_COLORS[App.data.subjects.length % SUBJECT_COLORS.length], weeklyTargetMinutes: 180 };
  const body = `
    <div class="form-row"><label>Subject Name</label><input type="text" id="f-name" value="${escapeHTML(s.name)}" placeholder="e.g. Mathematics"></div>
    <div class="form-row"><label>Weekly Target (minutes)</label><input type="number" id="f-target" min="0" value="${s.weeklyTargetMinutes}"></div>
    <div class="form-row"><label>Color</label>
      <div style="display:flex; gap:8px; flex-wrap:wrap;">
        ${SUBJECT_COLORS.map(c => `<div class="color-swatch" data-color="${c}" style="width:28px;height:28px;border-radius:50%;background:${c};cursor:pointer;border:3px solid ${c === s.color ? '#000' : 'transparent'};"></div>`).join('')}
      </div>
      <input type="hidden" id="f-color" value="${s.color}">
    </div>
  `;
  openGenericModal(existing ? 'Edit Subject' : 'Add Subject', body, () => {
    const name = document.getElementById('f-name').value.trim();
    if (!name) { showToast('Subject name is required', 'error'); return false; }
    const payload = {
      name,
      weeklyTargetMinutes: parseInt(document.getElementById('f-target').value, 10) || 0,
      color: document.getElementById('f-color').value
    };
    if (existing) {
      Object.assign(existing, payload);
    } else {
      App.data.subjects.push({ id: genId('subj'), ...payload });
    }
    App.save();
    renderSubjects();
    showToast(existing ? 'Subject updated' : 'Subject added', 'success');
  });

  document.querySelectorAll('.color-swatch').forEach(sw => {
    sw.addEventListener('click', () => {
      document.getElementById('f-color').value = sw.dataset.color;
      document.querySelectorAll('.color-swatch').forEach(x => x.style.border = '3px solid transparent');
      sw.style.border = '3px solid #000';
    });
  });
}

function deleteSubject(id) {
  App.data.subjects = App.data.subjects.filter(s => s.id !== id);
  App.save();
  renderSubjects();
  showToast('Subject deleted', 'info');
}

function renderSubjects() {
  const grid = document.getElementById('subjectsGrid');
  if (App.data.subjects.length === 0) {
    grid.innerHTML = `<div class="empty-state"><div class="icon">📚</div>No subjects yet. Add your first subject to start tracking progress.</div>`;
    return;
  }
  const weekStart = isoDaysAgo(6);
  grid.innerHTML = App.data.subjects.map(subj => {
    const minutes = App.data.sessions.filter(s => s.subjectId === subj.id && s.date >= weekStart).reduce((s, x) => s + x.minutes, 0);
    const pct = Math.min(100, Math.round((minutes / subj.weeklyTargetMinutes) * 100 || 0));
    const subjTasks = App.data.tasks.filter(t => t.subjectId === subj.id);
    const completedTasks = subjTasks.filter(t => t.completed).length;
    return `
      <div class="subject-card" style="border-left-color:${subj.color}" data-id="${subj.id}">
        <div style="display:flex; justify-content:space-between; align-items:start;">
          <h4>${escapeHTML(subj.name)}</h4>
          <div class="actions">
            <button class="icon-btn" data-action="edit">✏️</button>
            <button class="icon-btn" data-action="delete">🗑</button>
          </div>
        </div>
        <div class="meta">${minutes} / ${subj.weeklyTargetMinutes} minutes</div>
        <div class="progress-bar" style="margin:10px 0;"><div class="fill" style="width:${pct}%; background:${subj.color}"></div></div>
        <div class="meta">${pct}% of weekly target</div>
        <div class="meta" style="margin-top:8px;">${subjTasks.length} tasks · ${completedTasks} completed</div>
      </div>`;
  }).join('');

  grid.querySelectorAll('.subject-card').forEach(card => {
    const id = card.dataset.id;
    const subj = App.data.subjects.find(s => s.id === id);
    card.querySelector('[data-action="edit"]').addEventListener('click', () => openSubjectModal(subj));
    card.querySelector('[data-action="delete"]').addEventListener('click', () => {
      if (confirm(`Delete "${subj.name}"? Tasks/notes referencing it will keep showing "No subject".`)) deleteSubject(id);
    });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('addSubjectBtn').addEventListener('click', () => openSubjectModal(null));
});
