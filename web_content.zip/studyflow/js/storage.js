/* ==========================================================================
   storage.js — centralized localStorage layer for StudyFlow
   All reading/writing of localStorage happens through this file so the
   rest of the app never touches localStorage directly.
   ========================================================================== */

const DB = {
  USERS: 'studyflow_users',
  CURRENT_USER: 'studyflow_current_user',
  DATA_PREFIX: 'studyflow_data_' // + userId
};

/* ---------- generic helpers ---------- */

function genId(prefix = 'id') {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

function readJSON(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) {
    console.error('StudyFlow: failed to read', key, e);
    return fallback;
  }
}

function writeJSON(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (e) {
    console.error('StudyFlow: failed to write', key, e);
    return false;
  }
}

/* ---------- password hashing (Web Crypto SHA-256) ----------
   NOTE: This is NOT real security. See README "Authentication limitations".
   It only prevents storing raw plaintext passwords in localStorage. */
async function hashPassword(password) {
  const enc = new TextEncoder().encode(password);
  const buf = await crypto.subtle.digest('SHA-256', enc);
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

/* ---------- users ---------- */

function getUsers() {
  return readJSON(DB.USERS, []);
}

function saveUsers(users) {
  writeJSON(DB.USERS, users);
}

function findUserByEmail(email) {
  return getUsers().find(u => u.email.toLowerCase() === email.toLowerCase());
}

function findUserById(id) {
  return getUsers().find(u => u.id === id);
}

async function createUser({ fullName, username, email, password }) {
  const users = getUsers();
  const passwordHash = await hashPassword(password);
  const user = {
    id: genId('user'),
    fullName,
    username,
    email,
    passwordHash,
    createdAt: new Date().toISOString()
  };
  users.push(user);
  saveUsers(users);
  initUserData(user.id);
  return user;
}

async function verifyPassword(user, password) {
  const hash = await hashPassword(password);
  return hash === user.passwordHash;
}

/* ---------- session ---------- */

function setCurrentUser(userId) {
  localStorage.setItem(DB.CURRENT_USER, userId);
}

function getCurrentUserId() {
  return localStorage.getItem(DB.CURRENT_USER);
}

function getCurrentUser() {
  const id = getCurrentUserId();
  if (!id) return null;
  return findUserById(id);
}

function logout() {
  localStorage.removeItem(DB.CURRENT_USER);
}

function requireAuthOrRedirect() {
  const user = getCurrentUser();
  if (!user) {
    window.location.href = 'login.html';
    return null;
  }
  return user;
}

/* ---------- per-user data ---------- */

function defaultUserData() {
  return {
    tasks: [],
    subjects: [],
    sessions: [],   // completed focus/study sessions {id, date, subjectId, minutes}
    planner: [],    // planner entries
    exams: [],
    notes: [],
    goals: [],
    settings: {
      theme: 'light',
      dailyGoalMinutes: 120,
      weeklyGoalMinutes: 600,
      soundEnabled: true
    }
  };
}

function initUserData(userId) {
  const key = DB.DATA_PREFIX + userId;
  if (!localStorage.getItem(key)) {
    writeJSON(key, defaultUserData());
  }
}

function getUserData(userId) {
  const key = DB.DATA_PREFIX + userId;
  const data = readJSON(key, null);
  if (!data) {
    const fresh = defaultUserData();
    writeJSON(key, fresh);
    return fresh;
  }
  // backfill any missing fields for forward-compat
  const merged = { ...defaultUserData(), ...data, settings: { ...defaultUserData().settings, ...(data.settings || {}) } };
  return merged;
}

function saveUserData(userId, data) {
  writeJSON(DB.DATA_PREFIX + userId, data);
}

function deleteUserAccount(userId) {
  const users = getUsers().filter(u => u.id !== userId);
  saveUsers(users);
  localStorage.removeItem(DB.DATA_PREFIX + userId);
  logout();
}

function clearUserStudyData(userId) {
  const data = getUserData(userId);
  data.tasks = [];
  data.sessions = [];
  data.planner = [];
  data.exams = [];
  data.notes = [];
  data.goals = [];
  saveUserData(userId, data);
}

/* ---------- export / import ---------- */

function exportUserData(userId) {
  const user = findUserById(userId);
  const data = getUserData(userId);
  const payload = {
    app: 'StudyFlow',
    version: 1,
    exportedAt: new Date().toISOString(),
    profile: { fullName: user.fullName, username: user.username, email: user.email },
    data
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'studyflow-backup.json';
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function isValidImportPayload(payload) {
  if (!payload || typeof payload !== 'object') return false;
  if (!payload.data || typeof payload.data !== 'object') return false;
  const required = ['tasks', 'subjects', 'sessions', 'planner', 'exams', 'notes', 'goals', 'settings'];
  return required.every(k => k in payload.data);
}

function importUserData(userId, payload) {
  if (!isValidImportPayload(payload)) {
    throw new Error('Invalid StudyFlow backup file.');
  }
  saveUserData(userId, payload.data);
}

/* ---------- demo data ---------- */

function loadDemoData(userId) {
  const data = defaultUserData();
  const mathId = genId('subj');
  const physId = genId('subj');
  const engId = genId('subj');

  data.subjects = [
    { id: mathId, name: 'Mathematics', color: '#6366f1', weeklyTargetMinutes: 300 },
    { id: physId, name: 'Physics', color: '#22c55e', weeklyTargetMinutes: 240 },
    { id: engId, name: 'English', color: '#f59e0b', weeklyTargetMinutes: 180 }
  ];

  const today = new Date();
  const iso = d => d.toISOString().slice(0, 10);

  data.tasks = [
    { id: genId('task'), title: 'Finish algebra worksheet', subjectId: mathId, date: iso(today), priority: 'high', estMinutes: 45, description: 'Chapter 4 exercises', completed: false },
    { id: genId('task'), title: 'Read Newton\'s laws', subjectId: physId, date: iso(today), priority: 'medium', estMinutes: 30, description: '', completed: false },
    { id: genId('task'), title: 'Essay draft', subjectId: engId, date: iso(new Date(today.getTime() + 86400000)), priority: 'low', estMinutes: 60, description: 'First draft of the essay', completed: false },
    { id: genId('task'), title: 'Practice quiz', subjectId: mathId, date: iso(new Date(today.getTime() - 86400000)), priority: 'high', estMinutes: 20, description: '', completed: true }
  ];

  data.sessions = [0, 1, 2, 3].map(i => ({
    id: genId('sess'),
    date: iso(new Date(today.getTime() - i * 86400000)),
    subjectId: [mathId, physId, engId][i % 3],
    minutes: 25 + i * 10
  }));

  data.planner = [
    { id: genId('plan'), date: iso(today), subjectId: mathId, topic: 'Quadratic equations', duration: 45, priority: 'high', notes: '', completed: false },
    { id: genId('plan'), date: iso(new Date(today.getTime() + 86400000)), subjectId: physId, topic: 'Kinematics review', duration: 30, priority: 'medium', notes: '', completed: false }
  ];

  data.exams = [
    { id: genId('exam'), name: 'Midterm Exam', subjectId: mathId, date: iso(new Date(today.getTime() + 7 * 86400000)), time: '09:00', description: 'Covers chapters 1-4' },
    { id: genId('exam'), name: 'Lab Practical', subjectId: physId, date: iso(new Date(today.getTime() + 2 * 86400000)), time: '13:00', description: '' }
  ];

  data.notes = [
    { id: genId('note'), title: 'Derivative rules', subjectId: mathId, content: 'Power rule, product rule, chain rule...', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
    { id: genId('note'), title: 'Essay outline', subjectId: engId, content: 'Intro, 3 body paragraphs, conclusion.', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }
  ];

  data.goals = [
    { id: genId('goal'), type: 'daily', label: 'Study 2 hours today', targetMinutes: 120, subjectId: null },
    { id: genId('goal'), type: 'weekly', label: 'Study 10 hours this week', targetMinutes: 600, subjectId: null },
    { id: genId('goal'), type: 'subject', label: 'Complete 20 Mathematics tasks', targetTasks: 20, subjectId: mathId }
  ];

  saveUserData(userId, data);
}
