"""
Render the StudyFlow logo as PNGs with Pillow, mirroring the SVG design:
an open book whose pages rise into a flowing progress line ending in a spark.
Drawn at high resolution then downsampled for clean anti-aliasing.
"""
from PIL import Image, ImageDraw, ImageFont
import math

SCALE = 4  # supersample factor for anti-aliasing
FONT_PATH = "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf"

BRAND_TOP = (99, 102, 241)      # #6366f1
BRAND_BOTTOM = (67, 56, 202)    # #4338ca
FLOW_LIGHT = (165, 243, 201)    # #a5f3c9
FLOW_DARK = (34, 197, 94)       # #22c55e
WHITE = (255, 255, 255)
PAGE_LINE_1 = (199, 210, 254)   # #c7d2fe
PAGE_LINE_2 = (224, 231, 255)   # #e0e7ff
TEXT_DARK = (31, 35, 51)        # #1f2333


def cubic_bezier(p0, p1, p2, p3, steps=40):
    pts = []
    for i in range(steps + 1):
        t = i / steps
        mt = 1 - t
        x = (mt**3) * p0[0] + 3 * (mt**2) * t * p1[0] + 3 * mt * (t**2) * p2[0] + (t**3) * p3[0]
        y = (mt**3) * p0[1] + 3 * (mt**2) * t * p1[1] + 3 * mt * (t**2) * p2[1] + (t**3) * p3[1]
        pts.append((x, y))
    return pts


def rounded_rect_mask(size, radius):
    mask = Image.new("L", size, 0)
    d = ImageDraw.Draw(mask)
    d.rounded_rectangle([0, 0, size[0] - 1, size[1] - 1], radius=radius, fill=255)
    return mask


def vertical_gradient(size, top_color, bottom_color):
    w, h = size
    grad = Image.new("RGB", size, top_color)
    px = grad.load()
    for y in range(h):
        t = y / (h - 1)
        r = int(top_color[0] + (bottom_color[0] - top_color[0]) * t)
        g = int(top_color[1] + (bottom_color[1] - top_color[1]) * t)
        b = int(top_color[2] + (bottom_color[2] - top_color[2]) * t)
        for x in range(w):
            px[x, y] = (r, g, b)
    return grad


def draw_icon(px_size):
    """Draw the icon mark at px_size x px_size, returns an RGBA image."""
    S = px_size * SCALE
    scale = S / 200.0

    def P(x, y):
        return (x * scale, y * scale)

    bg = vertical_gradient((S, S), BRAND_TOP, BRAND_BOTTOM).convert("RGBA")
    mask = rounded_rect_mask((S, S), radius=44 * scale)
    canvas = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    canvas.paste(bg, (0, 0), mask)
    draw = ImageDraw.Draw(canvas, "RGBA")

    # left page
    left_pts = (
        [P(100, 78)]
        + cubic_bezier(P(100, 78), P(92, 66), P(66, 58), P(46, 61))
        + [P(46, 132)]
        + cubic_bezier(P(46, 132), P(66, 129), P(92, 137), P(100, 149))
    )
    draw.polygon(left_pts, fill=(*WHITE, 240))

    # right page
    right_pts = (
        [P(100, 78)]
        + cubic_bezier(P(100, 78), P(108, 66), P(134, 58), P(154, 61))
        + [P(154, 132)]
        + cubic_bezier(P(154, 132), P(134, 129), P(108, 137), P(100, 149))
    )
    draw.polygon(right_pts, fill=(*WHITE, 199))

    # spine
    draw.line([P(100, 78), P(100, 149)], fill=(67, 56, 202, 90), width=max(1, int(2.5 * scale)))

    # page texture lines
    lw = max(1, int(3 * scale))
    draw.line([P(54, 78), P(90, 83)], fill=PAGE_LINE_1, width=lw)
    draw.line([P(54, 92), P(90, 96)], fill=PAGE_LINE_1, width=lw)
    draw.line([P(110, 83), P(146, 78)], fill=PAGE_LINE_2, width=lw)
    draw.line([P(110, 96), P(146, 92)], fill=PAGE_LINE_2, width=lw)

    # flow line: sample bezier, color-interpolate per-segment for a gradient stroke
    flow_pts = cubic_bezier(P(52, 118), P(78, 122), P(96, 108), P(112, 88), steps=30) \
        + cubic_bezier(P(112, 88), P(124, 72), P(138, 60), P(156, 52), steps=30)[1:]
    n = len(flow_pts)
    stroke_w = max(2, int(9 * scale))
    for i in range(n - 1):
        t = i / (n - 2)
        r = int(FLOW_LIGHT[0] + (FLOW_DARK[0] - FLOW_LIGHT[0]) * t)
        g = int(FLOW_LIGHT[1] + (FLOW_DARK[1] - FLOW_LIGHT[1]) * t)
        b = int(FLOW_LIGHT[2] + (FLOW_DARK[2] - FLOW_LIGHT[2]) * t)
        draw.line([flow_pts[i], flow_pts[i + 1]], fill=(r, g, b), width=stroke_w)
    # round the joints so the stroke reads as one smooth line
    for pt in flow_pts:
        draw.ellipse([pt[0] - stroke_w / 2, pt[1] - stroke_w / 2, pt[0] + stroke_w / 2, pt[1] + stroke_w / 2],
                     fill=FLOW_DARK)

    # spark at the end of the flow line
    cx, cy = P(156, 52)
    r1, r2 = 10 * scale, 4 * scale
    draw.ellipse([cx - r1, cy - r1, cx + r1, cy + r1], fill=FLOW_DARK)
    draw.ellipse([cx - r2, cy - r2, cx + r2, cy + r2], fill=WHITE)

    return canvas.resize((px_size, px_size), Image.LANCZOS)


def make_wordmark(height_px, icon_gap=0.35, text="StudyFlow"):
    """Icon + wordmark lockup, transparent background."""
    S = height_px * SCALE
    icon = draw_icon(S)

    font = ImageFont.truetype(FONT_PATH, int(S * 0.62))
    dummy = Image.new("RGBA", (10, 10))
    ddraw = ImageDraw.Draw(dummy)
    bbox = ddraw.textbbox((0, 0), text, font=font)
    text_w = bbox[2] - bbox[0]
    text_h = bbox[3] - bbox[1]

    gap = int(S * icon_gap)
    total_w = S + gap + text_w + int(S * 0.06)
    total_h = S
    canvas = Image.new("RGBA", (total_w, total_h), (0, 0, 0, 0))
    canvas.paste(icon, (0, 0), icon)

    draw = ImageDraw.Draw(canvas, "RGBA")
    text_y = (total_h - text_h) // 2 - bbox[1]
    draw.text((S + gap, text_y), text, font=font, fill=(*TEXT_DARK, 255))

    out_w = int(total_w / SCALE)
    out_h = int(total_h / SCALE)
    return canvas.resize((out_w, out_h), Image.LANCZOS)


if __name__ == "__main__":
    import os
    out_dir = "/mnt/user-data/outputs/studyflow/logo"
    os.makedirs(out_dir, exist_ok=True)

    # square icon marks
    for size in [1024, 512, 192, 64, 32]:
        img = draw_icon(size)
        img.save(f"{out_dir}/studyflow-icon-{size}.png")

    # horizontal lockup (icon + wordmark) on transparent background
    lockup = make_wordmark(240)
    lockup.save(f"{out_dir}/studyflow-logo-transparent.png")

    # same lockup on a white card, for previewing / places that need a solid background
    white_bg = Image.new("RGBA", lockup.size, (255, 255, 255, 255))
    white_bg.paste(lockup, (0, 0), lockup)
    white_bg.save(f"{out_dir}/studyflow-logo-white-bg.png")

    print("done")
