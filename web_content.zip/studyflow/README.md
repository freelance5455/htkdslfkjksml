# StudyFlow

**Plan. Focus. Learn. Improve.**

StudyFlow is a 100% browser-only study tracker. There is no server, no database, no
Node.js, no PHP, no Python backend — everything runs as static HTML, CSS and
JavaScript, and all data is stored in your browser's `localStorage`.

## Features

- 🏠 Dashboard with today's stats, plan, subject progress and a 7-day chart
- ✅ Task management (priority, subject, due date, estimated minutes, filters, search)
- ⏱ Working Pomodoro focus timer with custom durations, subject tagging, and an
  optional sound notification; completed sessions are logged automatically
- 📚 Subjects with weekly targets, color coding, and live progress bars
- 🗓 Weekly planner laid out day-by-day
- 🎯 Exams & deadlines with automatic countdowns ("3 days left", "Tomorrow", "Today", "Passed")
- 📝 Searchable notes, organized by subject
- 🏆 Daily / weekly / monthly / subject goals with progress bars
- 🔥 Study streak tracking (current + best) with a 28-day activity calendar
- 📊 Analytics dashboard with Chart.js charts (study time, subject distribution, task completion)
- 🌙 Light / dark mode, saved across sessions
- ⬇️⬆️ Export your data as `studyflow-backup.json` and import it back later
- ✨ One-click demo data so you can explore the app immediately
- 📱 Fully responsive: sidebar becomes a mobile menu, cards stack, forms go single-column

## Folder structure

```
studyflow/
├── index.html        Landing page
├── login.html         Login + "forgot password" explanation
├── register.html       Registration
├── dashboard.html       The app itself (all sections live here)
│
├── css/
│   ├── style.css       Base styles, theme variables, landing page
│   ├── auth.css        Login/register page styles
│   └── dashboard.css   App shell, sidebar, cards, forms, mobile styles
│
└── js/
    ├── storage.js     Centralized localStorage read/write layer
    ├── ui.js          Shared helpers: toasts, dates, theme
    ├── auth.js        Register/login page logic
    ├── dashboard.js   App shell: nav, auth guard, dashboard section
    ├── tasks.js       Task management
    ├── timer.js       Focus timer / Pomodoro
    ├── subjects.js    Subjects
    ├── planner.js     Weekly planner
    ├── exams.js       Exams & deadlines
    ├── notes.js       Notes
    ├── goals.js       Goals + streaks
    ├── analytics.js   Charts and summary stats
    └── settings.js    Profile, goals, appearance, data, account
```

## How to run

1. Download/unzip the `studyflow` folder.
2. Open `index.html` in a modern browser (Chrome, Firefox, Edge, Safari).
3. Click **Register**, create an account, and start using StudyFlow.

That's it — no installation, no build step, no server required.

> **Note on opening files directly:** most browsers allow `file://` pages to use
> `localStorage` and read the linked CSS/JS just fine. If your browser blocks
> anything when opening `index.html` directly (some strict security setups do),
> you can optionally serve the folder with any simple static server, for example:
> `python3 -m http.server` or the VS Code "Live Server" extension, then visit
> `http://localhost:8000`. A backend is never required — this is purely a
> convenience for browsers with stricter local-file policies.

## Browser compatibility

Any modern browser with `localStorage` and the Web Crypto API (all current
versions of Chrome, Firefox, Safari, and Edge). Charts use Chart.js via CDN;
if you're offline, everything except the analytics charts still works fully.

## localStorage architecture

All data lives under a few keys:

- `studyflow_users` — array of all registered accounts (name, username, email,
  password hash)
- `studyflow_current_user` — the currently logged-in user's id
- `studyflow_data_<userId>` — one object per user containing their tasks,
  subjects, sessions, planner, exams, notes, goals, and settings

Every read/write goes through `js/storage.js`, so each user's data is fully
isolated — User A can never see User B's tasks, notes, or study time.

## ⚠️ Authentication limitations — please read

StudyFlow's login system is a **local-only demo authentication system**, not a
production-grade one. Please understand:

- Passwords are hashed with SHA-256 (via the Web Crypto API) before being
  stored, so raw passwords are never saved in `localStorage`. However, this is
  **not** the same as real security: there's no server-side salt, no rate
  limiting, no protection against someone with access to your browser's
  storage, and SHA-256 alone is not considered secure for password storage in
  a real production system (proper systems use slow, salted hashing like
  bcrypt/argon2 on a server).
- Anyone with access to your browser (or your browser profile/backups) can, in
  principle, read the stored data.
- There is no email service, so **"Forgot Password" cannot send a reset
  email** — the app tells you this directly. If you forget your password and
  don't already know it, your only local option is registering a new account;
  this does not recover your old data.
- **Do not reuse a real, sensitive password for this app.** Treat it as a
  local demo/productivity tool, not a secure account system.

## Export & import

- **Export** (Settings → Data → Export Data) downloads a `studyflow-backup.json`
  file containing your profile info and all your study data.
- **Import** (Settings → Data → Import Data) lets you pick a previously
  exported JSON file. The file is validated before use — if it isn't a
  recognizable StudyFlow backup, the import is rejected and you'll see an
  error toast instead of corrupted data.

## How to customize

- **Colors / theme:** edit the CSS variables at the top of `css/style.css`
  (`--brand`, `--bg`, `--surface`, etc.) and the `[data-theme="dark"]` block
  for dark mode.
- **Default study goals:** change the defaults in `defaultUserData()` inside
  `js/storage.js`.
- **Subject colors palette:** edit `SUBJECT_COLORS` in `js/subjects.js`.

## How to add new features

1. Add any new data fields to `defaultUserData()` in `js/storage.js` so
   existing and new users get sensible defaults.
2. Create a new `js/<feature>.js` file following the pattern used by the
   existing sections (a `render<Feature>()` function, a modal opener using
   `openGenericModal()`, and `App.save()` after every change).
3. Add a new `<section class="section-view" id="view-<feature>">` to
   `dashboard.html`, a matching sidebar `<div class="nav-item" data-section="...">`,
   and register the renderer inside the `renderers` map in `js/dashboard.js`.
4. Include your new script tag in `dashboard.html`, after `storage.js` and
   `ui.js` and before `dashboard.js`.

---

Built as a fully functional, browser-only demo application. No data ever
leaves your device — there is nothing to leave to, since there is no server.
