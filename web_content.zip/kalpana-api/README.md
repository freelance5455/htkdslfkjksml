# Kalpana AI — website + API

Ek hi Node server website (`public/index.html`) aur teen API endpoints chalata hai.

| Endpoint | Kaam | Provider |
|---|---|---|
| `POST /api/chat` | AI chat | Anthropic (Claude) |
| `POST /api/image` | Image generate | OpenAI Images |
| `POST /api/video` + `GET /api/video/:id` | Video generate (job + polling) | Replicate |

## Computer par chalana

1. Node.js 20 ya naya install karein.
2. `.env.example` ko copy karke `.env` banayein aur keys bharein (jis tool ko use karna ho sirf uski key bharna kaafi hai).
3. Terminal mein:
   ```
   npm install
   npm start
   ```
4. Browser mein `http://localhost:3000` kholein.

## Free mein live karna

Is project ko GitHub par daalein (`.env` file mat daalna) aur Render ya Railway par "New Web Service" banayein.
Build command `npm install`, start command `npm start`. Keys ko dashboard ke Environment Variables mein daalein.

## Zaroori baatein

- **Unlimited ka matlab:** har video, image aur chat par provider paisa leta hai. `RATE_LIMIT_PER_HOUR` se ek IP ki limit lagi hai taaki bill na badhe. Sach mein unlimited karne se pehle apna kharcha dekh lein.
- **Video:** `VIDEO_MODEL` mein Replicate ka koi text-to-video model likhein (jaise `owner/model-name`). Har model ke input alag ho sakte hain; agar model `prompt` ke alawa kuch maangta hai to `server.js` mein `input` badalna padega.
- **Keys:** keys sirf server par rehti hain. Unhe kabhi `index.html` mein na daalein.
