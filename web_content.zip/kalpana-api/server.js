import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const {
  ANTHROPIC_API_KEY,
  OPENAI_API_KEY,
  REPLICATE_API_TOKEN,
  CHAT_MODEL = 'claude-sonnet-5-5',
  IMAGE_MODEL = 'gpt-image-1',
  VIDEO_MODEL = '', // Replicate model, e.g. "owner/model-name"
  RATE_LIMIT_PER_HOUR = '30',
  PORT = '3000',
} = process.env;

// ---- Simple per-IP rate limit (protects your API bill) ----
const hits = new Map();
function rateLimit(req, res, next) {
  const ip = req.ip;
  const now = Date.now();
  const windowMs = 60 * 60 * 1000;
  const list = (hits.get(ip) || []).filter((t) => now - t < windowMs);
  if (list.length >= Number(RATE_LIMIT_PER_HOUR)) {
    return res.status(429).json({ error: 'Too many requests. Please try again later.' });
  }
  list.push(now);
  hits.set(ip, list);
  next();
}
app.set('trust proxy', 1);
app.use('/api', rateLimit);

function needKey(res, key, name) {
  if (!key) {
    res.status(503).json({ error: `${name} is not set on the server.` });
    return false;
  }
  return true;
}

function cleanPrompt(p) {
  if (typeof p !== 'string') return null;
  const s = p.trim();
  return s.length > 0 && s.length <= 2000 ? s : null;
}

// ---- Chat (Claude) ----
app.post('/api/chat', async (req, res) => {
  if (!needKey(res, ANTHROPIC_API_KEY, 'ANTHROPIC_API_KEY')) return;
  const msgs = Array.isArray(req.body.messages) ? req.body.messages.slice(-20) : [];
  const ok = msgs.length > 0 && msgs.every(
    (m) => (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string' && m.content.length <= 4000
  );
  if (!ok) return res.status(400).json({ error: 'Send messages: [{role, content}].' });
  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: CHAT_MODEL,
        max_tokens: 1024,
        system: 'You are a friendly creative assistant inside Kalpana AI. Help users brainstorm ideas, write scripts and improve prompts for AI video and images. Reply in the language the user writes in.',
        messages: msgs,
      }),
    });
    const data = await r.json();
    if (!r.ok) return res.status(502).json({ error: data?.error?.message || 'Chat provider error.' });
    const text = (data.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('');
    res.json({ reply: text });
  } catch (e) {
    res.status(502).json({ error: 'Could not reach chat provider.' });
  }
});

// ---- Image (OpenAI Images API) ----
app.post('/api/image', async (req, res) => {
  if (!needKey(res, OPENAI_API_KEY, 'OPENAI_API_KEY')) return;
  const prompt = cleanPrompt(req.body.prompt);
  if (!prompt) return res.status(400).json({ error: 'Send a prompt (1-2000 characters).' });
  try {
    const r = await fetch('https://api.openai.com/v1/images/generations', {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${OPENAI_API_KEY}` },
      body: JSON.stringify({ model: IMAGE_MODEL, prompt, size: '1024x1024', n: 1 }),
    });
    const data = await r.json();
    if (!r.ok) return res.status(502).json({ error: data?.error?.message || 'Image provider error.' });
    const item = data.data?.[0];
    const src = item?.b64_json ? `data:image/png;base64,${item.b64_json}` : item?.url;
    if (!src) return res.status(502).json({ error: 'No image returned.' });
    res.json({ image: src });
  } catch (e) {
    res.status(502).json({ error: 'Could not reach image provider.' });
  }
});

// ---- Video (Replicate: start a job, then poll) ----
app.post('/api/video', async (req, res) => {
  if (!needKey(res, REPLICATE_API_TOKEN, 'REPLICATE_API_TOKEN')) return;
  if (!VIDEO_MODEL) return res.status(503).json({ error: 'VIDEO_MODEL is not set on the server.' });
  const prompt = cleanPrompt(req.body.prompt);
  if (!prompt) return res.status(400).json({ error: 'Send a prompt (1-2000 characters).' });
  try {
    const r = await fetch(`https://api.replicate.com/v1/models/${VIDEO_MODEL}/predictions`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${REPLICATE_API_TOKEN}` },
      body: JSON.stringify({ input: { prompt } }),
    });
    const data = await r.json();
    if (!r.ok) return res.status(502).json({ error: data?.detail || 'Video provider error.' });
    res.json({ id: data.id });
  } catch (e) {
    res.status(502).json({ error: 'Could not reach video provider.' });
  }
});

app.get('/api/video/:id', async (req, res) => {
  if (!needKey(res, REPLICATE_API_TOKEN, 'REPLICATE_API_TOKEN')) return;
  if (!/^[a-z0-9]+$/i.test(req.params.id)) return res.status(400).json({ error: 'Bad id.' });
  try {
    const r = await fetch(`https://api.replicate.com/v1/predictions/${req.params.id}`, {
      headers: { authorization: `Bearer ${REPLICATE_API_TOKEN}` },
    });
    const data = await r.json();
    if (!r.ok) return res.status(502).json({ error: data?.detail || 'Video provider error.' });
    const out = Array.isArray(data.output) ? data.output[0] : data.output;
    res.json({ status: data.status, video: out || null, error: data.error || null });
  } catch (e) {
    res.status(502).json({ error: 'Could not reach video provider.' });
  }
});

app.listen(Number(PORT), () => console.log(`Kalpana AI running on http://localhost:${PORT}`));
