package com.medicourse.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
