/*
 * MediCourse — Native Bridge (Capacitor)
 * --------------------------------------
 * এই ফাইলটি শুধু Capacitor-এর ভেতরে (native Android অ্যাপে) কাজ করে।
 * সাধারণ ওয়েব ব্রাউজারে এটি সম্পূর্ণ no-op — কোনো কোডই চলবে না।
 *
 * কাজ: অ্যাপের localStorage state ("medicourse_v1") পড়ে, ভবিষ্যতের
 * প্রতিটি pending ডোজের জন্য একটি করে native local notification
 * শিডিউল করা — যাতে অ্যাপ বন্ধ থাকলেও ওষুধের সময়ে রিমাইন্ডার আসে।
 *
 * নিয়ম:
 *  - এটি কখনো অ্যাপের ডেটা বদলায় না (শুধু পড়ে)।
 *  - কোনো ত্রুটি ঘটলেও তা অ্যাপের গায়ে লাগবে না (সবকিছু try/catch-এ মোড়া)।
 *  - ডোজ taken/skipped হলে বা সময় পেরিয়ে গেলে সেই নোটিফিকেশন বাতিল হয়।
 *  - Snooze করা থাকলে (snoozeUntil) নোটিফিকেশন ওই সময়ে যায়।
 *  - যেসব ওষুধের reminder বন্ধ (med.reminder === false), সেগুলো বাদ।
 *  - Re-sync হয়: অ্যাপ খুললে, প্রতি ৫ মিনিটে, অ্যাপ সামনে এলে, এবং
 *    stored state JSON বদলালেই (hash poll দিয়ে ধরা হয়)।
 *
 * দ্রষ্টব্য: অ্যাপটি দিন অনুযায়ী ডোজ তৈরি করে (আজ পর্যন্ত), তাই native
 * নোটিফিকেশন মূলত আজকের বাকি ডোজগুলো কভার করে; প্রতিদিন অ্যাপ একবার
 * খুললেই পরের ডোজগুলো আবার শিডিউল হয়ে যায়।
 */
(function () {
  "use strict";

  /* ---------- Capacitor ছাড়া সম্পূর্ণ no-op ---------- */
  var Cap = null;
  try {
    Cap = (typeof window !== "undefined") ? window.Capacitor : null;
  } catch (e) {
    Cap = null;
  }
  if (!Cap || typeof Cap.isNativePlatform !== "function") return;
  var isNative = false;
  try {
    isNative = !!Cap.isNativePlatform();
  } catch (e) {
    isNative = false;
  }
  if (!isNative) return;

  var LocalNotifications = null;
  try {
    LocalNotifications = (Cap.Plugins && Cap.Plugins.LocalNotifications) || null;
  } catch (e) {
    LocalNotifications = null;
  }
  if (!LocalNotifications) return; // প্লাগইন নেই — নীরবে কিছুই করব না

  /* ---------- ধ্রুবক ---------- */
  var STORAGE_KEY = "medicourse_v1";
  var NOTIF_TITLE = "ওষুধ খাওয়ার সময় হয়েছে";
  var RESYNC_MS = 5 * 60 * 1000;   // প্রতি ৫ মিনিটে re-sync
  var HASH_POLL_MS = 15 * 1000;    // state বদল ধরার জন্য hash poll
  var MAX_SCHEDULE = 500;          // নিরাপত্তা সীমা

  function log() {
    try {
      var args = ["[MediCourseBridge]"];
      for (var i = 0; i < arguments.length; i++) args.push(arguments[i]);
      if (window.console && console.log) console.log.apply(console, args);
    } catch (e) { /* নীরব */ }
  }

  /* ---------- state পড়া (কখনো লেখা নয়) ---------- */
  function readState() {
    try {
      var raw = window.localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      return parsed && typeof parsed === "object" ? parsed : null;
    } catch (e) {
      return null;
    }
  }

  function stateHash() {
    try {
      var raw = window.localStorage.getItem(STORAGE_KEY) || "";
      var h = 5381;
      for (var i = 0; i < raw.length; i++) {
        h = (((h << 5) + h) + raw.charCodeAt(i)) | 0;
      }
      return raw.length + ":" + h;
    } catch (e) {
      return "";
    }
  }

  /* ---------- সাহায্যকারী ---------- */
  // dateKey "YYYY-MM-DD" + time "HH:MM" -> স্থানীয় Date
  function doseDateTime(dateKey, hhmm) {
    try {
      var dp = String(dateKey || "").split("-");
      var tp = String(hhmm || "").split(":");
      if (dp.length !== 3 || tp.length < 2) return null;
      var dt = new Date(+dp[0], +dp[1] - 1, +dp[2], +tp[0], +tp[1], 0, 0);
      return isNaN(dt.getTime()) ? null : dt;
    } catch (e) {
      return null;
    }
  }

  // FNV-1a hash -> ধনাত্মক 31-bit পূর্ণসংখ্যা (একই ইনপুটে সবসময় একই id)
  function hashId(str) {
    var h = 0x811c9dc5;
    for (var i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 0x01000193) >>> 0;
    }
    var id = h & 0x7fffffff;
    return id === 0 ? 1 : id;
  }

  function buildBody(d, med) {
    var name = d.name || (med && med.name) || "";
    var strength = d.strength || (med && med.strength) || "";
    var dose = d.dose || (med && med.dose) || "";
    var parts = [];
    var head = (name + " " + strength).replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
    if (head) parts.push(head);
    if (dose) parts.push(dose);
    return parts.join(" · ");
  }

  /* ভবিষ্যতের pending ডোজগুলো থেকে কাঙ্ক্ষিত নোটিফিকেশনের তালিকা */
  function desiredNotifications(state) {
    var out = [];
    if (!state || !state.doses || typeof state.doses !== "object") return out;

    var medById = {};
    try {
      (state.medicines || []).forEach(function (m) {
        if (m && m.id) medById[m.id] = m;
      });
    } catch (e) { /* উপেক্ষা */ }

    var now = Date.now();
    var dateKeys = Object.keys(state.doses).sort();
    for (var k = 0; k < dateKeys.length; k++) {
      var dateKey = dateKeys[k];
      var list = state.doses[dateKey];
      if (!list || !list.length) continue;
      for (var i = 0; i < list.length; i++) {
        var d = list[i];
        try {
          if (!d || d.status !== "pending") continue;
          var med = medById[d.medId] || null;
          if (med && med.reminder === false) continue; // এই ওষুধের রিমাইন্ডার বন্ধ

          var when = doseDateTime(dateKey, d.time);
          if (!when) continue;
          var at = when.getTime();
          // Snooze করা থাকলে নোটিফিকেশন snooze-এর সময়ে যাবে
          if (d.snoozeUntil && +d.snoozeUntil > at) at = +d.snoozeUntil;
          if (at <= now) continue; // সময় পেরিয়ে গেছে — native নোটিফিকেশন নয়

          var key = dateKey + "|" + String(d.id);
          out.push({
            key: key,
            id: hashId(key),
            at: at,
            title: NOTIF_TITLE,
            body: buildBody(d, med)
          });
        } catch (e) { /* একটি ডোজে সমস্যা হলে বাকিগুলো চলবে */ }
      }
    }

    out.sort(function (a, b) { return a.at - b.at; });

    // id collision এড়ানো (একই sync-এর ভেতরে)
    var used = {};
    out.forEach(function (n) {
      var id = n.id;
      while (used[id]) id = id >= 0x7ffffffe ? 1 : id + 1;
      n.id = id;
      used[id] = true;
    });

    if (out.length > MAX_SCHEDULE) out = out.slice(0, MAX_SCHEDULE);
    return out;
  }

  /* ---------- অনুমতি ---------- */
  var permAsked = false;
  function ensurePermission() {
    try {
      return LocalNotifications.checkPermissions()
        .then(function (st) {
          if (st && st.display === "granted") return true;
          if (permAsked) return false;
          permAsked = true;
          return LocalNotifications.requestPermissions()
            .then(function (r) { return !!(r && r.display === "granted"); })
            .catch(function () { return false; });
        })
        .catch(function () { return false; });
    } catch (e) {
      return Promise.resolve(false);
    }
  }

  /* ---------- মূল sync ---------- */
  var syncing = false;
  function syncNotifications() {
    if (syncing) return;
    syncing = true;
    var done = function () { syncing = false; };

    ensurePermission()
      .then(function (granted) {
        if (!granted) return null;
        var desired = desiredNotifications(readState());
        return LocalNotifications.getPending().then(function (res) {
          var pending = (res && res.notifications) || [];

          var desiredById = {};
          desired.forEach(function (n) { desiredById[n.id] = n; });

          var pendingById = {};
          var toCancel = [];
          pending.forEach(function (p) {
            pendingById[p.id] = p;
            var want = desiredById[p.id];
            var pAt = null;
            try {
              if (p.schedule && p.schedule.at) pAt = new Date(p.schedule.at).getTime();
            } catch (e) { pAt = null; }
            // আর চাই না, অথবা সময় বদলে গেছে — বাতিল
            if (!want || pAt !== want.at) toCancel.push({ id: p.id });
          });

          var toSchedule = desired.filter(function (n) {
            var p = pendingById[n.id];
            if (!p) return true;
            var pAt = null;
            try {
              if (p.schedule && p.schedule.at) pAt = new Date(p.schedule.at).getTime();
            } catch (e) { pAt = null; }
            return pAt !== n.at;
          });

          var chain = Promise.resolve();
          if (toCancel.length) {
            chain = chain.then(function () {
              return LocalNotifications.cancel({ notifications: toCancel });
            });
          }
          if (toSchedule.length) {
            chain = chain.then(function () {
              return LocalNotifications.schedule({
                notifications: toSchedule.map(function (n) {
                  return {
                    id: n.id,
                    title: n.title,
                    body: n.body,
                    schedule: { at: new Date(n.at), allowWhileIdle: true }
                  };
                })
              });
            });
          }
          return chain;
        });
      })
      .then(done, function (err) {
        log("sync failed:", err);
        done();
      });
  }

  /* ---------- চালু করা ---------- */
  var lastHash = "";
  function start() {
    try {
      lastHash = stateHash();
      syncNotifications(); // লোডে একবার

      // প্রতি ৫ মিনিটে re-sync
      setInterval(function () {
        lastHash = stateHash();
        syncNotifications();
      }, RESYNC_MS);

      // state JSON বদলালেই re-sync (hash poll)
      setInterval(function () {
        var h = stateHash();
        if (h !== lastHash) {
          lastHash = h;
          syncNotifications();
        }
      }, HASH_POLL_MS);

      // অ্যাপ সামনে এলে re-sync
      try {
        document.addEventListener("visibilitychange", function () {
          if (!document.hidden) {
            lastHash = stateHash();
            syncNotifications();
          }
        });
      } catch (e) { /* উপেক্ষা */ }

      log("native notification bridge active");
    } catch (e) {
      log("bridge start failed:", e);
    }
  }

  try {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", function () {
        setTimeout(start, 1500);
      });
    } else {
      setTimeout(start, 1500);
    }
  } catch (e) {
    /* ব্রিজ চালু না হলেও অ্যাপ স্বাভাবিক চলবে */
  }
})();
