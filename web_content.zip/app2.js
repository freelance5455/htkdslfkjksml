/* ---------- Navigation ---------- */
function show(v){
  view=v;
  $$('.v').forEach(function(s){s.classList.remove('on');});
  $('#v-'+v).classList.add('on');
  var navKey=v==='detail'?'list':v;
  $$('#nav button').forEach(function(b){b.classList.toggle('on',b.getAttribute('data-v')===navKey);});
  if(v==='form'&&!editId)resetForm();
  renderAll();
  window.scrollTo(0,0);
}

/* ---------- Form ---------- */
function setErr(id,on){$('#e-'+id).classList.toggle('on',!!on);}
function clearErrs(){['name','date','months'].forEach(function(i){setErr(i,false);});}
function resetForm(){
  editId=null;$('#pform').reset();
  $('#f-cat').value='electronics';$('#f-months').value='12';$('#f-date').value=todayStr();
  clearErrs();updateFormTexts();updateExpiryPreview();
}
function loadForm(p){
  editId=p.id;
  $('#f-name').value=p.name;$('#f-brand').value=p.brand;$('#f-cat').value=p.category;
  $('#f-date').value=p.purchaseDate;$('#f-months').value=p.months;
  $('#f-shop').value=p.shop;$('#f-serial').value=p.serial;$('#f-notes').value=p.notes;
  clearErrs();updateFormTexts();updateExpiryPreview();
}
function monthsValue(){
  var v=$('#f-months').value.trim().replace(/[০-৯]/g,function(d){return '০১২৩৪৫৬৭৮৯'.indexOf(d);});
  if(!/^\d+$/.test(v))return null;
  var n=parseInt(v,10);return (n>=1&&n<=120)?n:null;
}
function updateExpiryPreview(){
  var pd=$('#f-date').value,m=monthsValue();
  $('#f-expiry').value=(parseDate(pd)&&m)?fmtDate(addMonths(pd,m)):'—';
}
function submitForm(e){
  e.preventDefault();
  var name=str($('#f-name').value,100),pd=$('#f-date').value,m=monthsValue();
  var bad=false;
  setErr('name',!name);setErr('date',!parseDate(pd));setErr('months',m===null);
  if(!name||!parseDate(pd)||m===null)bad=true;
  if(bad){var f=$('.err.on');if(f&&f.previousElementSibling&&f.previousElementSibling.focus)f.previousElementSibling.focus();return;}
  var old=editId?products.filter(function(x){return x.id===editId;})[0]:null;
  var p=clean({
    id:old?old.id:uid(),name:name,brand:$('#f-brand').value,category:$('#f-cat').value,
    purchaseDate:pd,months:m,shop:$('#f-shop').value,serial:$('#f-serial').value,notes:$('#f-notes').value,
    createdAt:old?old.createdAt:Date.now()
  });
  if(!p)return;
  var backup=products.slice();
  if(old){products=products.map(function(x){return x.id===p.id?p:x;});}else{products.push(p);}
  if(!persist()){products=backup;return;}
  toast(t(old?'sUpdated':'sSaved'));
  detailId=p.id;editId=null;show('detail');
}

/* ---------- Backup ---------- */
function doExport(){
  if(!products.length){toast(t('noData'));return;}
  try{
    var data={app:'AKASH Warranty Keeper',version:1,exportedAt:new Date().toISOString(),products:products};
    var blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});
    var url=URL.createObjectURL(blob),a=document.createElement('a');
    a.href=url;a.download='akash-warranty-backup-'+todayStr()+'.json';
    document.body.appendChild(a);a.click();document.body.removeChild(a);
    setTimeout(function(){URL.revokeObjectURL(url);},1500);
    toast(t('exported'));
  }catch(e){toast(t('eStore'));}
}
function doImport(file){
  if(!file)return;
  var rd=new FileReader();
  rd.onerror=function(){toast(t('impBad'));};
  rd.onload=function(){
    var d;
    try{d=JSON.parse(rd.result);}catch(e){toast(t('impBad'));return;}
    var items=Array.isArray(d)?d:(d&&Array.isArray(d.products)?d.products:null);
    if(!items){toast(t('impBad'));return;}
    var valid=[];items.forEach(function(x){var c=clean(x);if(c)valid.push(c);});
    if(!valid.length){toast(t('impBad'));return;}
    var skipped=items.length-valid.length;
    ask(t('impTitle'),fill(t('impMsg'),{n:num(valid.length),s:skipped?fill(t('impSkip'),{k:num(skipped)}):''}),t('yesImp'),function(){
      var backup=products.slice();
      valid.forEach(function(v){
        var i=-1;products.forEach(function(x,k){if(x.id===v.id)i=k;});
        if(i>-1)products[i]=v;else products.push(v);
      });
      if(!persist()){products=backup;return;}
      toast(fill(t('impDone'),{n:num(valid.length)}));renderAll();
    });
  };
  rd.readAsText(file);
}

/* ---------- Events ---------- */
function findP(id){return products.filter(function(x){return x.id===id;})[0];}
document.addEventListener('click',function(e){
  var el=e.target.closest?e.target.closest('[data-act]'):null;if(!el)return;
  var act=el.getAttribute('data-act'),id=el.getAttribute('data-id');
  switch(act){
    case 'nav':
      var v=el.getAttribute('data-v');
      if(v==='form'){editId=null;}
      if(v==='list'){filter='all';}
      show(v);break;
    case 'stat':filter=el.getAttribute('data-f');show('list');break;
    case 'filter':filter=el.getAttribute('data-f');renderList();break;
    case 'open':detailId=id;show('detail');break;
    case 'toList':show('list');break;
    case 'edit':var p=findP(id);if(p){loadForm(p);show('form');}break;
    case 'cancelForm':
      if(editId&&findP(editId)){detailId=editId;editId=null;show('detail');}else{editId=null;show('home');}
      break;
    case 'del':
      var dp=findP(id);if(!dp)break;
      ask(t('delTitle'),fill(t('delMsg'),{n:dp.name}),t('yesDel'),function(){
        var backup=products.slice();
        products=products.filter(function(x){return x.id!==id;});
        if(!persist()){products=backup;return;}
        toast(t('sDeleted'));show('list');
      });break;
    case 'langToggle':setLang(lang==='bn'?'en':'bn');break;
    case 'setLang':setLang(el.getAttribute('data-l'));break;
    case 'export':doExport();break;
    case 'import':$('#file').click();break;
    case 'mOk':var cb=modalCb;closeModal();if(cb)cb();break;
    case 'mCancel':closeModal();break;
  }
});
$('#modal').addEventListener('click',function(e){if(e.target===this)closeModal();});
$('#pform').addEventListener('submit',submitForm);
$('#f-date').addEventListener('input',updateExpiryPreview);
$('#f-date').addEventListener('change',updateExpiryPreview);
$('#f-months').addEventListener('input',updateExpiryPreview);
$('#q').addEventListener('input',function(){query=this.value;renderList();});
$('#file').addEventListener('change',function(){doImport(this.files&&this.files[0]);this.value='';});

function setLang(l){
  lang=(l==='en')?'en':'bn';
  try{localStorage.setItem(LKEY,lang);}catch(e){}
  applyLang();
}

/* ---------- Start ---------- */
try{var sl=localStorage.getItem(LKEY);if(sl==='en'||sl==='bn')lang=sl;}catch(e){}
products=load();
applyLang();
show('home');
