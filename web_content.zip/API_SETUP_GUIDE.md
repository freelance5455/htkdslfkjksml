# 🔑 Gemini API Setup & Configuration Guide

This guide walks you through acquiring, testing, and configuring your Google Gemini API Key for **Shivania AI**.

---

## Step 1: Get Your Free Gemini API Key

1. Go to **[Google AI Studio](https://aistudio.google.com/app/apikey)**.
2. Sign in with any active Google account.
3. Click on the blue **"Create API Key"** button.
4. Select an existing Google Cloud project or click **"Create new project"**.
5. Once created, click the copy button to copy your API key (it begins with `AIzaSy...`).

---

## Step 2: Configuring in Shivania AI

### Method 1: Directly in the Web App UI (Recommended)
1. Open `index.html` in your browser.
2. In the top navigation bar, click on the **Settings (Gear Icon)**.
3. Under the **"Google Gemini API"** section, paste your key into the **"Gemini API Key"** field.
4. Click the **"Test Connection"** button:
   - ✅ A green banner will confirm: *"Successfully connected to Gemini API!"*
5. Select your preferred model:
   - **`gemini-3.8-flash`** *(Recommended)*: Latest 3.8 frontier model, ultra-fast, highly expressive, superior Hinglish banter and emotional nuance.
   - **`gemini-3.5-flash`**: Fast, efficient and reliable.
   - **`gemini-3.1-pro`**: Deep analytical and reasoning capabilities.
   - **`gemini-4-argon`**: Next-generation reasoning flagship.
6. Click **"Save Settings"**. Your key is securely saved in your browser's local storage and is ready for live chat!

### Method 2: Via Backend `.env` File (For Server Hosting)
1. In the project root, open `.env.example`.
2. Rename it to `.env` (or run `cp .env.example .env`).
3. Replace the placeholder with your key:
   ```env
   GEMINI_API_KEY=AIzaSyYourCopiedKeyHere
   PORT=3000
   GEMINI_MODEL=gemini-3.8-flash
   ```
4. Run `cd backend && npm install && npm start`.
5. Open `http://localhost:3000` — the app will automatically communicate with the backend proxy!

---

## Troubleshooting & Common Error Codes

| Error Code | Reason | Solution |
| :--- | :--- | :--- |
| **400 / 403 API_KEY_INVALID** | The key was mistyped or revoked. | Re-copy the key from Google AI Studio and ensure there are no extra spaces. |
| **429 RESOURCE_EXHAUSTED** | Gemini free-tier rate limit reached. | Wait 30 seconds or create a new key in Google AI Studio. |
| **500 Internal Error** | Temporary Google server glitch. | Click the **"Retry"** button on the message bubble. |
| **Network Error / Offline** | Internet connection issue. | Check your connection; click Retry once online. |
