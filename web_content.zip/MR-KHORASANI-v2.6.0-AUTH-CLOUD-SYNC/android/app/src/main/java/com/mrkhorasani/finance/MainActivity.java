package com.mrkhorasani.finance;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.view.WindowInsets;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.InputStream;
import java.util.UUID;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private static final int FILE_CHOOSER = 8016;
    private static final int SAVE_FILE_CHOOSER = 8017;
    private static final int FILE_PICKER_V16 = 8018;
    private String pendingSaveRequestId;
    private String pendingSaveFileName;
    private String pendingSaveMime;
    private byte[] pendingSaveBytes;
    private String pendingPickRequestId;
    private String pendingPickedFileName;
    private String pendingPickedFileMime;
    private byte[] pendingPickedFileBytes;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();
        w.setStatusBarColor(android.graphics.Color.rgb(8,26,53));
        w.setNavigationBarColor(android.graphics.Color.rgb(8,26,53));
        webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params){
                if(fileChooserCallback!=null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback=cb;
                Intent i=params.createIntent();
                i.addCategory(Intent.CATEGORY_OPENABLE);
                try{ startActivityForResult(i, FILE_CHOOSER); }catch(Exception e){ fileChooserCallback=null; return false; }
                return true;
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==FILE_CHOOSER && fileChooserCallback!=null){
            Uri[] r=(resultCode==RESULT_OK && data!=null && data.getData()!=null)?new Uri[]{data.getData()}:null;
            fileChooserCallback.onReceiveValue(r); fileChooserCallback=null;
            return;
        }
        if(requestCode==FILE_PICKER_V16){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null){
                Uri uri=data.getData();
                try{
                    if(data.getFlags()!=(0)) getContentResolver().takePersistableUriPermission(uri,data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION));
                }catch(Exception ignored){}
                try(InputStream is=getContentResolver().openInputStream(uri)){
                    if(is==null) throw new Exception("file stream unavailable");
                    java.io.ByteArrayOutputStream bos=new java.io.ByteArrayOutputStream();
                    byte[] buf=new byte[8192]; int n;
                    while((n=is.read(buf))>0) bos.write(buf,0,n);
                    pendingPickedFileBytes=bos.toByteArray();
                    pendingPickedFileMime=getContentResolver().getType(uri);
                    pendingPickedFileName=queryDisplayName(uri);
                    if(pendingPickedFileName==null || pendingPickedFileName.isEmpty()) pendingPickedFileName="فایل-انتخابی";
                    if(pendingPickedFileMime==null || pendingPickedFileMime.isEmpty()) pendingPickedFileMime="application/octet-stream";
                    notifyPickedFileV16(true);
                }catch(Exception e){
                    pendingPickedFileBytes=null; pendingPickedFileName=null; pendingPickedFileMime=null;
                    notifyPickedFileV16(false);
                }
            }else{
                pendingPickedFileBytes=null; pendingPickedFileName=null; pendingPickedFileMime=null;
                notifyPickedFileV16(false);
            }
            return;
        }
        if(requestCode==SAVE_FILE_CHOOSER){
            boolean ok=false;
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null && pendingSaveBytes!=null){
                try(OutputStream os=getContentResolver().openOutputStream(data.getData())){
                    if(os!=null){os.write(pendingSaveBytes);os.flush();ok=true;}
                }catch(Exception ignored){}
            }
            notifySaveResult(ok);
        }
    }

    private String queryDisplayName(Uri uri){
        Cursor c=null;
        try{
            c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null);
            if(c!=null && c.moveToFirst()){
                int idx=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if(idx>=0) return c.getString(idx);
            }
        }catch(Exception ignored){} finally { if(c!=null) c.close(); }
        String path=uri!=null?uri.getPath():null;
        if(path==null)return "";
        int slash=path.lastIndexOf('/');
        return slash>=0?path.substring(slash+1):path;
    }

    private void notifyPickedFileV16(boolean ok){
        String id=pendingPickRequestId;
        if(id==null || webView==null) return;
        String safe=id.replace("\\","\\\\").replace("'","\\'");
        webView.evaluateJavascript("window.__mrkNativeFilePickedV16&&window.__mrkNativeFilePickedV16('"+safe+"',"+(ok?"true":"false")+");",null);
    }

    private void notifySaveResult(boolean ok){
        String id=pendingSaveRequestId;
        pendingSaveRequestId=null; pendingSaveFileName=null; pendingSaveMime=null; pendingSaveBytes=null;
        if(id==null || webView==null)return;
        String safe=id.replace("\\","\\\\").replace("'","\\'");
        webView.evaluateJavascript("window.__mrkNativeSaveDone&&window.__mrkNativeSaveDone('"+safe+"',"+(ok?"true":"false")+");",null);
    }

    @Override public void onBackPressed(){
        if(webView!=null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public class AndroidBridge {
        @android.webkit.JavascriptInterface public String getDeviceId(){
            try{return Settings.Secure.getString(getContentResolver(),Settings.Secure.ANDROID_ID);}catch(Exception e){return "";}
        }
        @android.webkit.JavascriptInterface public String pickFileV16(){
            try{
                pendingPickRequestId=UUID.randomUUID().toString();
                pendingPickedFileBytes=null; pendingPickedFileName=null; pendingPickedFileMime=null;
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{
                    "application/json","text/csv","text/plain","application/pdf",
                    "application/vnd.ms-excel","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    "application/octet-stream"
                });
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(i,FILE_PICKER_V16);
                return pendingPickRequestId;
            }catch(Exception e){
                pendingPickRequestId=null;
                pendingPickedFileBytes=null; pendingPickedFileName=null; pendingPickedFileMime=null;
                return "";
            }
        }

        @android.webkit.JavascriptInterface public String consumePickedFileV16(String requestId){
            try{
                if(requestId==null || !requestId.equals(pendingPickRequestId) || pendingPickedFileBytes==null) return "";
                String b64=Base64.encodeToString(pendingPickedFileBytes,Base64.NO_WRAP);
                String name=Base64.encodeToString((pendingPickedFileName==null?"فایل-انتخابی":pendingPickedFileName).getBytes(java.nio.charset.StandardCharsets.UTF_8),Base64.NO_WRAP);
                String mime=Base64.encodeToString((pendingPickedFileMime==null?"application/octet-stream":pendingPickedFileMime).getBytes(java.nio.charset.StandardCharsets.UTF_8),Base64.NO_WRAP);
                pendingPickRequestId=null; pendingPickedFileBytes=null; pendingPickedFileName=null; pendingPickedFileMime=null;
                return "{\"name\":\""+name+"\",\"mime\":\""+mime+"\",\"base64\":\""+b64+"\"}";
            }catch(Exception e){
                return "";
            }
        }

        @android.webkit.JavascriptInterface public String saveFileWithChooser(String fileName,String mime,String base64){
            try{
                if(fileName==null || fileName.trim().isEmpty()) fileName="MR-KHORASANI-output.xls";
                pendingSaveRequestId=UUID.randomUUID().toString();
                pendingSaveFileName=fileName;
                pendingSaveMime=(mime==null||mime.isEmpty())?"application/octet-stream":mime;
                pendingSaveBytes=Base64.decode(base64,Base64.DEFAULT);
                Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(pendingSaveMime);
                i.putExtra(Intent.EXTRA_TITLE,pendingSaveFileName);
                startActivityForResult(i,SAVE_FILE_CHOOSER);
                return pendingSaveRequestId;
            }catch(Exception e){
                pendingSaveRequestId=null; pendingSaveFileName=null; pendingSaveMime=null; pendingSaveBytes=null;
                return "";
            }
        }

        @android.webkit.JavascriptInterface public boolean saveFile(String fileName,String mime,String base64,String directory){
            try{
                byte[] bytes=Base64.decode(base64,Base64.DEFAULT);
                if(Build.VERSION.SDK_INT>=29){
                    android.content.ContentValues v=new android.content.ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME,fileName);
                    v.put(MediaStore.Downloads.MIME_TYPE,mime==null?"application/octet-stream":mime);
                    v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/MR-KHORASANI");
                    Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
                    if(uri==null)return false;
                    try(OutputStream os=getContentResolver().openOutputStream(uri)){if(os==null)return false;os.write(bytes);}
                    return true;
                }
                File dir=new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),"MR-KHORASANI");
                if(!dir.exists() && !dir.mkdirs())return false;
                try(FileOutputStream fos=new FileOutputStream(new File(dir,fileName))){fos.write(bytes);}
                return true;
            }catch(Exception e){return false;}
        }
        @android.webkit.JavascriptInterface public boolean saveToDownloads(String fileName,String mime,String base64){return saveFile(fileName,mime,base64,"Download/MR-KHORASANI");}
        @android.webkit.JavascriptInterface public boolean writeFile(String path,String mime,String base64){
            String name=path==null?"file.bin":path.substring(path.lastIndexOf('/')+1);
            return saveFile(name,mime,base64,path);
        }
    }
}
