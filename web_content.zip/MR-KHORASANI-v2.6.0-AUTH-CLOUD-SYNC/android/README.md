# Android build — MR, KHORASANI v2.3.0

- Application ID: `com.app.mrali`
- Version code/name: `230` / `2.3.0`
- Android module mirrors the web application from `web/app.js` into the WebView asset `src/main/assets/www/index.html`.
- Build requirement: JDK 17 and Android SDK/Build Tools for compileSdk 36, plus Gradle wrapper or compatible Gradle installation.
- Production module: BOM, actual consumption, direct/indirect cost allocations, worker hourly cost, WIP and finished-goods receipt.

The APK was not built in this environment because Android SDK/Gradle tooling is unavailable.
