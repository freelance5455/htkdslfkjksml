const fs=require('node:fs');const path=require('node:path');const assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p));
const webHtml=read('web/index.html').toString('utf8');const webApp=read('web/app.js').toString('utf8');
const inlines=[...webHtml.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g)].map(m=>m[1]).sort((a,b)=>b.length-a.length);
assert.equal(inlines[0].trim(),webApp.trim(),'WebView inline app matches the tested source');
assert(webHtml.indexOf('src="supabase-config.js"')<webHtml.indexOf('src="supabase-client.js"'),'Supabase config loads before client');
assert(webHtml.indexOf('src="supabase-client.js"')<webHtml.indexOf("'use strict'"),'Supabase client loads before main app');
const cloudClient=read('web/supabase-client.js').toString('utf8');assert(cloudClient.includes("/auth/v1/token?grant_type=password"),'app cloud client login flow exists');
assert(cloudClient.includes('functions/v1/manage-company-users')&&webApp.includes('MRKCloud.manageUsers'),'app user management uses central function');
assert(!webApp.includes('/functions/v1/mhz-sync')&&!webApp.includes('/functions/v1/khsync'),'legacy shared-key endpoints are not used');
assert(webApp.includes('UI.readOnly?clone(remoteState):mergeState(S,remoteState)'),'read-only users load authoritative cloud snapshot');
const sw=read('web/sw.js').toString('utf8');assert(sw.includes("'./supabase-config.js'")&&sw.includes("'./supabase-client.js'"),'service worker caches Auth scripts');
for(const mirror of ['android/app/src/main/assets/www','apk-overlay/assets/web']){
 for(const file of ['index.html','app.js','supabase-config.js','supabase-client.js','sw.js'])assert(read(`${mirror}/${file}`).equals(read(`web/${file}`)),`${mirror}/${file} matches web source`);
}
assert(fs.existsSync(path.join(root,'docs/SUPABASE-AUTH-SYNC-2.6_FA.md')),'security and integration documentation exists');
assert(fs.existsSync(path.join(root,'supabase/20261110_secure_authenticated_sync.sql')),'SQL migration script exists');
console.log('PASS: release wiring, Auth script order, no legacy sync endpoint in app, read-only snapshot behavior, offline cache, Android/APK overlay parity, documentation and migration files.');
