const vm = require('node:vm');
const fs = require('node:fs');
const assert = require('node:assert/strict');
const code = fs.readFileSync(__dirname + '/app.js', 'utf8');
const store = new Map();
const document = {
  addEventListener(){}, querySelector(){return null;}, querySelectorAll(){return [];},
  createElement(){return {style:{},classList:{add(){},remove(){}},appendChild(){},remove(){},setAttribute(){},getContext(){return null;}};},
  body:{appendChild(){},classList:{add(){},remove(){}}},
  documentElement:{style:{setProperty(){}}}
};
const window = {addEventListener(){},self:{},top:{},confirm(){return true},print(){}};
const ctx = {
  console, document, window, navigator:{}, localStorage:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v)},
  setTimeout(){return 0}, clearTimeout(){}, setInterval(){return 0}, clearInterval(){},
  Blob, File, URL, TextEncoder, TextDecoder, Intl, Date, Math, JSON, Map, Set, Object, Array, String, Number, RegExp, Error, Promise,
  alert(){}, prompt(){return null}, confirm(){return true}
};
vm.createContext(ctx);
const exposure = `\nglobalThis.__TEST__={build,COA,TI,warehouseList,REP,THEMES,GROUPS,fresh,defRoles,index,setState:(x)=>{S=x;B=index(build(S));},runCost:()=>REP.cost.run({}),runStock:()=>REP.iv.run({}),mergeState,stampChanges,stateSig,alertsData,settingsOf,defaultSaleWarehouse,defaultPurchaseWarehouse,defaultItemWarehouse,needsInvoiceDue,newDraft,retCalc,UNIT_CHOICES,unitConversionFactor,toBaseQuantity,nextProdNo,inventoryCostMethod,renderProduction:(id,tab)=>{S.roles=defRoles();UI.user={id:'u_mrk',name:'Tester',role:'مدیر سیستم'};UI.prodTab=tab||'report';UI.prodOrderDetail=id||null;return productionPage()},renderSettings:(tab)=>{UI.st=tab;return settingsPage()},renderInvoiceForm:(type)=>{UI.type=type;UI.edit=null;UI.draft=newDraft(type);return formHtml()}};`;
vm.runInContext(code + exposure, ctx);
const api=ctx.__TEST__;

function makeState(){
  const accounts=api.COA.map(([code,name])=>({code,name}));
  accounts.push({code:'1603',name:'موجودی کالا – انبار سوم'});
  const ops=[
    {id:'o1',seq:1,no:1,type:'خرید',date:'1405/01/01',inv:1,party:'sup',due:'',items:[{g:'g1',q:10,p:200,w:'1'}],discAmt:0,ship:0,vat:false,pays:[],status:'active',user:'tester',ts:'1'},
    {id:'o2',seq:2,no:2,type:'فروش',date:'1405/01/02',inv:1,party:'cus',due:'',items:[{g:'g1',q:4,p:250,w:'1'}],discAmt:0,ship:0,vat:false,pays:[],status:'active',user:'tester',ts:'2'},
    {id:'o3',seq:3,no:3,type:'انتقال بین انبارها',date:'1405/01/03',fromWh:'1',toWh:'2',items:[{g:'g1',q:2,p:0,w:''}],status:'active',user:'tester',ts:'3'},
    {id:'o4',seq:4,no:4,type:'رسید کالا',date:'1405/01/04',items:[{g:'g1',q:3,p:300,w:'w3'}],status:'active',user:'tester',ts:'4'},
    {id:'o5',seq:5,no:5,type:'حواله خروج کالا',date:'1405/01/05',acc:'5101',items:[{g:'g1',q:1,p:0,w:'2'}],status:'active',user:'tester',ts:'5'},
    {id:'o6',seq:6,no:6,type:'برگشت از فروش',date:'1405/01/06',refInv:1,items:[{g:'g1',q:1,w:'1'}],status:'active',user:'tester',ts:'6'},
    {id:'o7',seq:7,no:7,type:'برگشت از خرید',date:'1405/01/07',refInv:1,items:[{g:'g1',q:1,w:'1'}],status:'active',user:'tester',ts:'7'}
  ];
  return {
    fy:1405,seq:200,docSeq:7,accounts,taf:{},warehouses:[
      {id:'1',name:'انبار یک',acc:'1601'},{id:'2',name:'انبار دو',acc:'1602'},{id:'w3',name:'انبار سوم',acc:'1603'}
    ],
    parties:[{id:'cus',kind:'مشتری',name:'مشتری تست',open:0,side:'bd'},{id:'sup',kind:'تأمین‌کننده',name:'تأمین‌کننده تست',open:0,side:'cr'}],
    goods:[{id:'g1',name:'کالای آزمایشی',code:'100',unit:'عدد',q1:10,c1:100,q2:0,c2:0,opening:{}}],sources:[],ops,days:{},carry:null,invCarry:null,carryChq:[],carryInvs:[]
  };
}

const state=makeState();
const result=api.build(state);
assert.equal(result.errs.length,0, 'all sample transactions should post without errors: '+JSON.stringify(result.errs));
const entry=(id)=>result.docs.find(x=>x.opId===id);
const sum=(lines,side,acc)=>lines.filter(l=>!acc||l.acc===acc).reduce((a,l)=>a+l[side],0);
// Every generated document, including each inventory action, must be balanced.
for(const doc of result.docs){assert.equal(sum(doc.lines,'d'),sum(doc.lines,'c'),`document ${doc.no} must balance`)}
// Moving weighted-average cost is 150 after opening 10@100 and purchase 10@200.
assert.equal(result.opd.o2.calc.cost,600,'sale COGS must be 4 × 150');
assert.equal(result.opd.o1.calc.items[0].cost,2000,'purchase value must be 10 × 200');
// Transfer moves 2 units at 150 cost from warehouse 1 to 2 without COGS effect.
assert.equal(result.opd.o3.calc.cost,300,'transfer carries 2 × 150');
assert.equal(sum(entry('o3').lines,'d','1602'),300,'transfer debits destination inventory');
assert.equal(sum(entry('o3').lines,'c','1601'),300,'transfer credits source inventory');
assert.equal(sum(entry('o3').lines,'d','5101')+sum(entry('o3').lines,'c','5101'),0,'transfer has no COGS posting');
assert.equal(result.opd.o3.moves.reduce((a,m)=>a+m.q,0),0,'transfer quantity movement nets to zero');
assert.equal(result.opd.o3.moves.reduce((a,m)=>a+m.v,0),0,'transfer value movement nets to zero');
// Receipt debits selected warehouse and credits GRNI; issue credits the selected warehouse at WAC.
assert.equal(sum(entry('o4').lines,'d','1603'),900,'receipt adds 900 to warehouse 3');
assert.equal(sum(entry('o4').lines,'c','2702'),900,'receipt uses goods-received-not-invoiced clearing account');
assert.equal(result.opd.o5.calc.cost,150,'goods issue uses warehouse 2 average cost');
assert.equal(sum(entry('o5').lines,'c','1602'),150,'issue reduces selected warehouse value');
// Returns reverse to the warehouse from the original invoice at the recorded invoice cost.
assert.equal(result.opd.o6.calc.cost,150,'sales return restores original sale cost');
assert.equal(result.opd.o7.calc.cost,150,'purchase return relieves the current moving weighted-average cost');
assert.equal(result.inv['g1|1'].q,14,'warehouse 1 final quantity');
assert.equal(result.inv['g1|1'].v,2100,'warehouse 1 final value after purchase return at moving average');
assert.equal(result.inv['g1|2'].q,1,'warehouse 2 final quantity');
assert.equal(result.inv['g1|2'].v,150,'warehouse 2 final value');
assert.equal(result.inv['g1|w3'].q,3,'warehouse 3 final quantity');
assert.equal(result.inv['g1|w3'].v,900,'warehouse 3 final value');
// Report output includes invoice-specific COGS, warehouse labels, and additional warehouse values.
api.setState(state);
const costReport=api.runCost();
const costSection=costReport.sections[0];
assert(costSection.rows.some(r=>r[0]==='فروش' && r[8]===600),'cost report includes sale invoice row COGS');
const stockReport=api.runStock();
assert(stockReport.sections[0].cols.some(c=>String(c).includes('انبار سوم')),'stock report contains dynamic warehouse columns');
assert(api.GROUPS.wh && api.TI['رسید کالا'] && api.TI['حواله خروج کالا'] && api.TI['انتقال بین انبارها'],'warehouse operation menu items are registered');
assert.equal(api.THEMES.length,1,'single navy/gold theme only');
const html=fs.readFileSync(__dirname+'/index.html','utf8');
assert(!/#(?:1f9d78|2aa876|0d3b2e|1b6b52)/i.test(html),'green theme colors must not remain');
const inlineApp=[...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g)].map(m=>m[1]).sort((a,b)=>b.length-a.length)[0]||'';
assert.equal(inlineApp.trim(),fs.readFileSync(__dirname+'/app.js','utf8').trim(),'WebView executable must match tested application source');
assert(/--i1:#d6ad55;--i2:#d6ad55;--i3:#d6ad55;--i4:#d6ad55;--i5:#d6ad55;--i6:#d6ad55;--i7:#d6ad55;--i8:#d6ad55/.test(html),'all page icon accent tokens are gold while page surfaces remain navy');

// A goods receipt followed by a matching purchase invoice must settle GRNI without doubling stock.
const receiptState=makeState();
receiptState.goods[0].q1=10; receiptState.goods[0].c1=100; receiptState.ops=[
  {id:'r1',seq:1,no:1,type:'رسید کالا',date:'1405/02/01',items:[{g:'g1',q:5,p:200,w:'1'}],status:'active',user:'tester',ts:'1'},
  {id:'p1',seq:2,no:2,type:'خرید',date:'1405/02/02',inv:1,party:'sup',items:[{g:'g1',q:5,p:200,w:'1'}],discAmt:0,ship:0,vat:false,pays:[],stockMode:'grn',status:'active',user:'tester',ts:'2'}
];
receiptState.docSeq=2;
const settled=api.build(receiptState);
assert.equal(settled.errs.length,0,'receipt plus matching invoice should clear successfully: '+JSON.stringify(settled.errs));
assert.equal(settled.inv['g1|1'].q,15,'purchase invoice matching receipt must not double the receipt quantity');
assert.equal(settled.inv['g1|1'].v,2000,'inventory value remains the receipt amount');
assert.equal(settled.grn['g1|1'].q,0,'GRNI quantity must be fully cleared');
assert.equal(settled.grn['g1|1'].v,0,'GRNI value must be fully cleared');
assert.equal(sum(settled.docs.find(x=>x.opId==='p1').lines,'d','2702'),1000,'purchase invoice debits the GRNI clearing account');
assert.equal(sum(settled.docs.find(x=>x.opId==='p1').lines,'d','1601'),0,'settlement invoice does not debit inventory again');


// Cloud merge must preserve and stamp independently created warehouses across devices.
const localSync=makeState(),remoteSync=makeState();
localSync.warehouses.push({id:'w4',name:'انبار چهارم',acc:'1604'});
remoteSync.warehouses.push({id:'w5',name:'انبار پنجم',acc:'1605'});
api.stampChanges(makeState(),localSync);
api.stampChanges(makeState(),remoteSync);
const merged=api.mergeState(localSync,remoteSync);
assert(merged.warehouses.some(w=>w.id==='w4') && merged.warehouses.some(w=>w.id==='w5'),'cloud merge combines new warehouses');


// Closed-day snapshots must retain GRNI movements so later invoices can still settle them.
const frozenState=makeState();
frozenState.ops=[{id:'fr',seq:1,no:1,type:'رسید کالا',date:'1405/03/01',items:[{g:'g1',q:2,p:125,w:'1'}],status:'active',user:'tester',ts:'1'}];
const preClose=api.build(frozenState);
assert.equal(preClose.errs.length,0);
const frozenOp=preClose.opd.fr;
frozenState.days={'1405/03/01':{closed:true}};
frozenState.ops[0].frozen={lines:frozenOp.lines,moves:frozenOp.moves,grnMoves:frozenOp.grnMoves,calc:frozenOp.calc};
frozenState.ops.push({id:'fb',seq:2,no:2,type:'خرید',date:'1405/03/02',inv:1,party:'sup',items:[{g:'g1',q:2,p:125,w:'1'}],discAmt:0,ship:0,vat:false,pays:[],stockMode:'grn',status:'active',user:'tester',ts:'2'});
const frozenResult=api.build(frozenState);
assert.equal(frozenResult.errs.length,0,'closed receipt should be reusable for later invoice settlement: '+JSON.stringify(frozenResult.errs));
assert.equal(frozenResult.grn['g1|1'].q,0,'frozen receipt GRNI quantity is cleared');
assert.equal(frozenResult.inv['g1|1'].q,12,'frozen receipt does not double count inventory');


// An unbilled receipt transferred to another warehouse follows the goods and can be settled there.
const movedReceipt=makeState();
movedReceipt.ops=[
  {id:'mr1',seq:1,no:1,type:'رسید کالا',date:'1405/04/01',items:[{g:'g1',q:4,p:125,w:'1'}],status:'active',user:'tester',ts:'1'},
  {id:'mt1',seq:2,no:2,type:'انتقال بین انبارها',date:'1405/04/02',fromWh:'1',toWh:'2',items:[{g:'g1',q:2,p:0,w:''}],status:'active',user:'tester',ts:'2'},
  {id:'mb1',seq:3,no:3,type:'خرید',date:'1405/04/03',inv:1,party:'sup',items:[{g:'g1',q:2,p:125,w:'2'}],discAmt:0,ship:0,vat:false,pays:[],stockMode:'grn',status:'active',user:'tester',ts:'3'}
];
movedReceipt.docSeq=3;
const movedResult=api.build(movedReceipt);
assert.equal(movedResult.errs.length,0,'transferred receipt can be settled in destination warehouse: '+JSON.stringify(movedResult.errs));
assert.equal(movedResult.grn['g1|1'].q,2,'untransferred unbilled receipt remainder stays in source warehouse');
assert.equal(movedResult.grn['g1|2'].q,0,'transferred unbilled receipt is cleared at destination');
assert.equal(movedResult.inv['g1|1'].q,12,'two units left source inventory');
assert.equal(movedResult.inv['g1|2'].q,2,'two units remain in destination inventory');

// If invoice value does not match the receipt, the operation fails and leaves balances untouched.
const mismatch=makeState();
mismatch.ops=[
  {id:'mr2',seq:1,no:1,type:'رسید کالا',date:'1405/05/01',items:[{g:'g1',q:2,p:100,w:'1'}],status:'active',user:'tester',ts:'1'},
  {id:'mb2',seq:2,no:2,type:'خرید',date:'1405/05/02',inv:1,party:'sup',items:[{g:'g1',q:2,p:110,w:'1'}],discAmt:0,ship:0,vat:false,pays:[],stockMode:'grn',status:'active',user:'tester',ts:'2'}
];
mismatch.docSeq=2;
const mismatchResult=api.build(mismatch);
assert.equal(mismatchResult.errs.length,1,'mismatching receipt invoice is rejected');
assert.equal(mismatchResult.inv['g1|1'].q,12,'rejected invoice does not change stock');
assert.equal(mismatchResult.grn['g1|1'].q,2,'rejected invoice does not consume GRNI');

console.log('PASS: weighted average, purchase/sales returns, multi-warehouse receipt/issue/transfer, balanced journals, inventory and reports.');

// Duplicate return lines are aggregated before checking the original invoice quantity.
const duplicateReturn=makeState();
duplicateReturn.ops=[
  {id:'ds',seq:1,no:1,type:'فروش',date:'1405/06/01',inv:1,party:'cus',items:[{g:'g1',q:2,p:300,w:'1'}],discAmt:0,ship:0,vat:false,pays:[],status:'active',user:'tester',ts:'1'},
  {id:'dr',seq:2,no:2,type:'برگشت از فروش',date:'1405/06/02',refInv:1,items:[{g:'g1',q:1,w:'1'},{g:'g1',q:2,w:'1'}],status:'active',user:'tester',ts:'2'}
];
duplicateReturn.docSeq=2;
const duplicateResult=api.build(duplicateReturn);
assert.equal(duplicateResult.errs.length,1,'duplicate return rows exceeding original sale quantity must be rejected');
assert(!duplicateResult.docs.some(d=>d.opId==='dr'),'invalid duplicate return must not create a journal');
assert.equal(duplicateResult.inv['g1|1'].q,8,'invalid duplicate return must not restore stock');

console.log('PASS: duplicate return rows cannot exceed source invoice quantity.');

// A purchase invoice may contain multiple price lines for the same item and warehouse.
const mixedPriceReceipt=makeState();
mixedPriceReceipt.ops=[
  {id:'mpr',seq:1,no:1,type:'رسید کالا',date:'1405/07/01',items:[{g:'g1',q:2,p:100,w:'1'},{g:'g1',q:3,p:200,w:'1'}],status:'active',user:'tester',ts:'1'},
  {id:'mpb',seq:2,no:2,type:'خرید',date:'1405/07/02',inv:1,party:'sup',items:[{g:'g1',q:2,p:100,w:'1'},{g:'g1',q:3,p:200,w:'1'}],discAmt:0,ship:0,vat:false,pays:[],stockMode:'grn',status:'active',user:'tester',ts:'2'}
];
mixedPriceReceipt.docSeq=2;
const mixedPriceResult=api.build(mixedPriceReceipt);
assert.equal(mixedPriceResult.errs.length,0,'same item across multiple price lines should settle against the aggregate GRNI balance: '+JSON.stringify(mixedPriceResult.errs));
assert.equal(mixedPriceResult.inv['g1|1'].q,15,'multiple price lines must not double count receipt quantity');
assert.equal(mixedPriceResult.grn['g1|1'].q,0,'aggregate GRNI quantity must clear');
assert.equal(mixedPriceResult.grn['g1|1'].v,0,'aggregate GRNI value must clear');

console.log('PASS: aggregated receipt-to-invoice settlement supports repeated item price lines.');

// Automatic sales allocation consumes warehouses in the configured order and books their exact WAC costs.
const autoSale=makeState();
autoSale.goods[0].q1=2;autoSale.goods[0].c1=100;autoSale.goods[0].q2=3;autoSale.goods[0].c2=200;
autoSale.ops=[{id:'as',seq:1,no:1,type:'فروش',date:'1405/08/01',inv:1,party:'cus',items:[{g:'g1',q:4,p:300,w:'auto'}],discAmt:0,ship:0,vat:false,pays:[],status:'active',user:'tester',ts:'1'}];
autoSale.docSeq=1;
const autoSaleResult=api.build(autoSale);
assert.equal(autoSaleResult.errs.length,0,'automatic warehouse sale allocation should post');
assert.equal(autoSaleResult.opd.as.calc.cost,600,'automatic allocation should consume 2×100 plus 2×200 cost');
assert.equal(autoSaleResult.inv['g1|1'].q,0,'automatic allocation empties the first warehouse first');
assert.equal(autoSaleResult.inv['g1|2'].q,1,'automatic allocation consumes the second warehouse for the balance');
assert.equal(sum(autoSaleResult.docs.find(d=>d.opId==='as').lines,'c','1601'),200,'first warehouse is credited at its own cost');
assert.equal(sum(autoSaleResult.docs.find(d=>d.opId==='as').lines,'c','1602'),400,'second warehouse is credited at its own cost');

console.log('PASS: automatic sale allocation uses warehouse-specific moving average costs.');


// FIFO consumes the oldest inventory layers first and carries them through warehouse transfers.
const fifoState=makeState();
fifoState.settings={inventory:{costingMethod:'fifo'}};
fifoState.goods[0].q1=10;fifoState.goods[0].c1=100;fifoState.goods[0].q2=0;fifoState.goods[0].c2=0;
fifoState.ops=[
 {id:'fp',seq:1,no:1,type:'خرید',date:'1405/09/01',inv:1,party:'sup',items:[{g:'g1',q:10,p:200,w:'1'}],discAmt:0,ship:0,vat:false,vatRate:10,pays:[],costMethod:'fifo',status:'active',user:'tester',ts:'1'},
 {id:'fs',seq:2,no:2,type:'فروش',date:'1405/09/02',inv:1,party:'cus',items:[{g:'g1',q:12,p:300,w:'1'}],discAmt:0,ship:0,vat:false,vatRate:10,pays:[],costMethod:'fifo',status:'active',user:'tester',ts:'2'}
];
fifoState.docSeq=2;
const fifoResult=api.build(fifoState);
assert.equal(fifoResult.errs.length,0,'FIFO purchase and sale should post: '+JSON.stringify(fifoResult.errs));
assert.equal(fifoResult.opd.fs.calc.cost,1400,'FIFO cost should be 10×100 plus 2×200');
assert.equal(fifoResult.inv['g1|1'].q,8,'FIFO remaining quantity');
assert.equal(fifoResult.inv['g1|1'].v,1600,'FIFO remaining value');
assert.equal(fifoResult.inv['g1|1'].layers.reduce((a,l)=>a+l.q,0),8,'FIFO layers quantity reconciles to stock quantity');
assert.equal(fifoResult.inv['g1|1'].layers.reduce((a,l)=>a+l.v,0),1600,'FIFO layers value reconciles to stock value');

const fifoTransfer=makeState();fifoTransfer.settings={inventory:{costingMethod:'fifo'}};
fifoTransfer.goods[0].q1=10;fifoTransfer.goods[0].c1=100;fifoTransfer.goods[0].q2=0;fifoTransfer.goods[0].c2=0;
fifoTransfer.ops=[
 {id:'ftp',seq:1,no:1,type:'خرید',date:'1405/09/01',inv:1,party:'sup',items:[{g:'g1',q:10,p:200,w:'1'}],discAmt:0,ship:0,vat:false,pays:[],costMethod:'fifo',status:'active',user:'tester',ts:'1'},
 {id:'ft',seq:2,no:2,type:'انتقال بین انبارها',date:'1405/09/02',fromWh:'1',toWh:'2',items:[{g:'g1',q:12,p:0,w:''}],costMethod:'fifo',status:'active',user:'tester',ts:'2'},
 {id:'fts',seq:3,no:3,type:'فروش',date:'1405/09/03',inv:1,party:'cus',items:[{g:'g1',q:1,p:300,w:'2'}],discAmt:0,ship:0,vat:false,pays:[],costMethod:'fifo',status:'active',user:'tester',ts:'3'}
];
fifoTransfer.docSeq=3;
const fifoTransferResult=api.build(fifoTransfer);
assert.equal(fifoTransferResult.errs.length,0,'FIFO transfer and subsequent sale should post: '+JSON.stringify(fifoTransferResult.errs));
assert.equal(fifoTransferResult.opd.ft.calc.cost,1400,'FIFO transfer preserves the original layer values');
assert.equal(fifoTransferResult.opd.fts.calc.cost,100,'destination warehouse must retain the FIFO sequence after transfer');

// Each invoice stores its applied tax rate; returns use the original invoice rate.
const taxState=makeState();
taxState.settings={tax:{salesRate:12,purchaseRate:9,defaultEnabled:true}};
taxState.ops=[
 {id:'taxs',seq:1,no:1,type:'فروش',date:'1405/10/01',inv:1,party:'cus',items:[{g:'g1',q:2,p:500,w:'1'}],discAmt:0,ship:0,vat:true,vatRate:12,pays:[],status:'active',user:'tester',ts:'1'},
 {id:'taxr',seq:2,no:2,type:'برگشت از فروش',date:'1405/10/02',refInv:1,items:[{g:'g1',q:1,w:'1'}],status:'active',user:'tester',ts:'2'}
];
taxState.docSeq=2;
const taxResult=api.build(taxState);
assert.equal(taxResult.errs.length,0,'tax invoice and return should post');
assert.equal(taxResult.opd.taxs.calc.tax,120,'sales invoice VAT at 12 percent');
assert.equal(taxResult.opd.taxr.calc.total,560,'sales return tax must retain original 12 percent rate');

// Configuration drives the default sale warehouse and date/stock reminders.
const prefsState=makeState();
prefsState.settings={inventory:{defaultSaleWarehouse:'2',minStockDefault:0},alerts:{chequeEnabled:true,chequeDaysBefore:3,overdueEnabled:true,invoiceEnabled:true,invoiceDaysBefore:7,lowStockEnabled:true}};
prefsState.goods[0].q1=1;prefsState.goods[0].c1=100;prefsState.goods[0].q2=0;prefsState.goods[0].c2=0;prefsState.goods[0].minQty=3;
prefsState.ops=[
 {id:'pc',seq:1,no:1,type:'دریافت چک',date:'1405/10/01',party:'cus',sayad:'1234567890123456',bank:'بانک تست',due:'1405/10/20',amt:500,status:'active',user:'tester',ts:'1'},
 {id:'pi',seq:2,no:2,type:'فروش',date:'1405/10/01',inv:1,party:'cus',due:'1405/10/22',items:[{g:'g1',q:1,p:1000,w:'1'}],discAmt:0,ship:0,vat:false,pays:[],status:'active',user:'tester',ts:'2'}
];prefsState.docSeq=2;
api.setState(prefsState);
assert.equal(api.defaultSaleWarehouse(prefsState),'2','default sales warehouse should follow saved settings');
const prefsAlerts=api.alertsData('1405/10/18');
assert(prefsAlerts.some(x=>x.kind==='cheque'),'cheque due alert should be generated within lead time');
assert(prefsAlerts.some(x=>x.kind==='invoice'),'open invoice due alert should be generated within lead time');
assert(prefsAlerts.some(x=>x.kind==='stock'),'low stock alert should respect per-item minimum quantity');

console.log('PASS: FIFO layers, transfer layer integrity, invoice tax snapshots, default sale warehouse, and reminders.');


// The settings screens must expose the configured accounting controls to users.
const acctSettingsHtml=api.renderSettings('acct');
const inventorySettingsHtml=api.renderSettings('inv');
const taxSettingsHtml=api.renderSettings('tax');
const alertSettingsHtml=api.renderSettings('alerts');
assert(acctSettingsHtml.includes('saveAccountingPrefs') && acctSettingsHtml.includes('prefRequireDue'), 'accounting settings expose the optional due-date rule');
assert(inventorySettingsHtml.includes('prefSaleWarehouse') && inventorySettingsHtml.includes('prefPurchaseWarehouse'), 'inventory settings expose both default warehouses');
assert(inventorySettingsHtml.includes('prefCostMethod') && inventorySettingsHtml.includes('fifo'), 'inventory settings expose costing selection');
assert(taxSettingsHtml.includes('prefSalesTax') && taxSettingsHtml.includes('prefPurchaseTax'), 'tax settings expose independent purchase and sales rates');
assert(alertSettingsHtml.includes('prefChequeAlert') && alertSettingsHtml.includes('prefInvoiceAlert') && alertSettingsHtml.includes('prefAlertLowStock'), 'alert settings expose checks, invoices and stock controls');
console.log('PASS: accounting, warehouse, costing, tax and alert settings screens render their controls.');

// New purchase/receipt forms respect the configured purchase warehouse.
const purchaseWarehouseState=makeState();
purchaseWarehouseState.settings={inventory:{defaultPurchaseWarehouse:'2',defaultSaleWarehouse:'1',costingMethod:'moving_average'},tax:{salesRate:14,purchaseRate:8,defaultEnabled:true}};
api.setState(purchaseWarehouseState);
assert.equal(api.defaultPurchaseWarehouse(purchaseWarehouseState),'2','configured purchase warehouse is retained');
assert.equal(api.newDraft('خرید').items[0].w,'2','purchase draft uses the configured purchase warehouse');
assert.equal(api.newDraft('رسید کالا').items[0].w,'2','goods receipt draft uses the configured purchase warehouse');
assert.equal(api.newDraft('فروش').items[0].w,'1','sales draft uses the configured sales warehouse');
assert.equal(api.newDraft('فروش').vatRate,14,'sales draft uses the configured sales VAT rate');
assert.equal(api.newDraft('خرید').vatRate,8,'purchase draft uses the configured purchase VAT rate');
assert.equal(api.defaultItemWarehouse('خرید',purchaseWarehouseState),'2','added purchase rows retain the configured purchase warehouse');
assert.equal(api.defaultItemWarehouse('رسید کالا',purchaseWarehouseState),'2','added receipt rows retain the configured purchase warehouse');
assert.equal(api.defaultItemWarehouse('فروش',purchaseWarehouseState),'1','added sales rows retain the configured sales warehouse');
console.log('PASS: purchase, receipt and sales drafts use their configured default warehouses.');


const dueRuleState=makeState();
dueRuleState.settings={accounting:{requireDueOnCredit:true}};
assert.equal(api.needsInvoiceDue('فروش','',1000,200,dueRuleState),true,'credit sales invoice needs a due date when the rule is active');
assert.equal(api.needsInvoiceDue('خرید','1405/12/01',1000,200,dueRuleState),false,'invoice with due date passes the rule');
assert.equal(api.needsInvoiceDue('فروش','',1000,1000,dueRuleState),false,'fully paid cash invoice does not need a due date');
assert.equal(api.needsInvoiceDue('دریافت خارج از فاکتور','',1000,0,dueRuleState),false,'non-invoice operations are not subject to invoice due-date rule');
console.log('PASS: optional due-date enforcement applies only to credit invoices with an unpaid balance.');


const invoiceDueUiState=makeState();
invoiceDueUiState.settings={accounting:{requireDueOnCredit:true}};
api.setState(invoiceDueUiState);
assert(api.renderInvoiceForm('فروش').includes('تاریخ سررسید (برای فاکتور دارای مانده الزامی)'), 'sales invoice form explains mandatory due date rule');
console.log('PASS: invoice form label reflects the enabled due-date policy.');

// Settings are scalar synchronized state, so a changed policy is included in multi-user merges.
const settingsLocal=makeState();
const settingsRemote=makeState();
settingsRemote.settings={tax:{salesRate:14,purchaseRate:8,defaultEnabled:true}};
settingsRemote.setMt=Date.now()+1000;
const settingsMerged=api.mergeState(settingsLocal,settingsRemote);
assert.equal(settingsMerged.settings.tax.salesRate,14,'tax settings propagate through multi-user state merge');
assert.equal(settingsMerged.settings.tax.purchaseRate,8,'purchase tax setting propagates through multi-user state merge');
console.log('PASS: saved accounting policies remain in synchronized multi-user state.');


const invoiceTaxCalc=api.retCalc({calc:{vat:true,vatRate:12,discRatio:0.1}},[{q:1,pr:1000}]);
assert.equal(invoiceTaxCalc.net,900,'return net value uses the original discount ratio');
assert.equal(invoiceTaxCalc.tax,108,'return panel tax calculation uses the original invoice rate, not a hard-coded 10 percent');
assert.equal(invoiceTaxCalc.vatRate,12,'return panel shows the original invoice tax rate');
console.log('PASS: return calculations preserve the source invoice tax rate.');


// Unit conversion contract: stock and production quantities are normalized to the item's base unit.
assert.deepEqual(Array.from(api.UNIT_CHOICES),['عدد','بسته','گرم','کیلوگرم','میلی‌لیتر','لیتر','سانتی‌متر','متر']);
const flour={id:'flour',unit:'کیلوگرم',conversions:[{unit:'بسته',factor:5}]};
assert.equal(api.unitConversionFactor(flour,'گرم'),0.001,'one gram converts to 0.001 base kilograms');
assert.equal(api.unitConversionFactor(flour,'بسته'),5,'one configured package converts to five base kilograms');
assert.equal(api.toBaseQuantity(flour,250,'گرم'),0.25,'250 grams normalize to 0.25 kilograms');
assert.equal(api.toBaseQuantity(flour,2,'بسته'),10,'two packages normalize to ten kilograms');
assert.equal(api.unitConversionFactor({unit:'کیلوگرم'},'گرم'),0.001,'automatic kilogram-to-gram conversion remains available');
assert.equal(api.unitConversionFactor({unit:'لیتر'},'میلی‌لیتر'),0.001,'automatic liter-to-milliliter conversion remains available');
assert.equal(api.nextProdNo({fy:1405,productionSeq:7,dev:'DLOCAL01'}).no,'PR-1405-000008-DLOCAL01','production order numbers increment uniquely by fiscal year sequence');
assert.equal(api.inventoryCostMethod({inventory:{costingMethod:'fifo'}}),'fifo','production orders preserve the configured FIFO method');
assert.equal(api.inventoryCostMethod({inventory:{costingMethod:'moving_average'}}),'moving_average','production defaults to moving average when configured');
assert.throws(()=>api.toBaseQuantity(flour,1,'لیتر'),/تبدیل|واحد/,'incompatible dimensions must be rejected');
const unitState=makeState();unitState.goods=[{id:'flour',name:'آرد',unit:'کیلوگرم',kind:'material',q1:0,c1:0,q2:0,c2:0,opening:{},conversions:[{unit:'بسته',factor:5}]}];unitState.ops=[{id:'ug1',seq:1,no:1,type:'رسید کالا',date:'1405/01/01',items:[{g:'flour',q:1000,p:2,w:'1',unit:'گرم'}],status:'active',user:'tester',ts:'1'}];const unitBuilt=api.build(unitState);assert.equal(unitBuilt.errs.length,0,'purchase/receipt in grams must normalize cleanly');assert.equal(unitBuilt.inv['flour|1'].q,1,'1000 grams increase one kilogram base-unit quantity');assert.equal(unitBuilt.inv['flour|1'].v,2000,'entered gram price is normalized to base price while preserving line total');

// Production orders post all four cost flows as balanced double-entry vouchers tied to one unique order.
const prodState=makeState();
prodState.goods=[
 {id:'raw',name:'مواد اولیه',unit:'کیلوگرم',kind:'material',q1:20,c1:100,opening:{}},
 {id:'finished',name:'محصول تولیدی',unit:'عدد',kind:'finished',q1:0,c1:0,opening:{}}
];
prodState.accounts.push({code:'1691',name:'کالای در جریان ساخت'},{code:'6102',name:'تسهیم دستمزد مستقیم'},{code:'6103',name:'تسهیم سربار ساخت'});
prodState.taf=Object.assign({},prodState.taf,{'1691':'production'});
prodState.productionOrders=[{id:'pr-1405-000001',orderNo:'PR-1405-000001-DTEST',productId:'finished',quantity:2,status:'completed',standardMaterials:[{g:'raw',q:10,unit:'کیلوگرم'}],materialVariance:[{g:'raw',standard:10,actual:5,variance:-5,unit:'کیلوگرم'}],labour:[{workerId:'wk1',hours:4,hourlyRate:100,amount:400}],directCosts:[{sourceAcc:'6501',amount:50}],overhead:[{sourceAcc:'6201',amount:100}]}];
prodState.ops=[
 {id:'pi1',seq:1,no:1,type:'حواله مصرف مواد تولید',prodOrderId:'pr-1405-000001',prodOrderNo:'PR-1405-000001',date:'1405/01/01',items:[{g:'raw',q:5,p:0,w:'1',unit:'کیلوگرم'}],status:'active'},
 {id:'pl1',seq:2,no:2,type:'تخصیص دستمزد تولید',prodOrderId:'pr-1405-000001',prodOrderNo:'PR-1405-000001',date:'1405/01/01',amount:400,status:'active'},
 {id:'pd1',seq:3,no:3,type:'تخصیص هزینه مستقیم تولید',prodOrderId:'pr-1405-000001',prodOrderNo:'PR-1405-000001',date:'1405/01/01',amount:50,sourceAcc:'6501',status:'active'},
 {id:'po1',seq:4,no:4,type:'تخصیص سربار تولید',prodOrderId:'pr-1405-000001',prodOrderNo:'PR-1405-000001',date:'1405/01/01',amount:100,sourceAcc:'6201',status:'active'},
 {id:'pr1',seq:5,no:5,type:'رسید محصول تولیدی',prodOrderId:'pr-1405-000001',prodOrderNo:'PR-1405-000001',date:'1405/01/01',productId:'finished',quantity:2,warehouse:'2',status:'active'}
];
const prodResult=api.build(prodState);
assert.equal(prodResult.errs.length,0,'production vouchers should post without errors: '+JSON.stringify(prodResult.errs));
for(const doc of prodResult.docs)assert.equal(sum(doc.lines,'d'),sum(doc.lines,'c'),`production voucher ${doc.no} must balance`);
assert.equal(prodResult.inv['raw|1'].q,15,'production issue reduces the selected raw-material warehouse');
assert.equal(prodResult.inv['finished|2'].q,2,'production receipt increases finished goods in the selected warehouse');
assert.equal(prodResult.inv['finished|2'].v,1050,'finished goods receive actual materials, labour, direct costs and overhead');
assert.equal(prodResult.prodWip['pr-1405-000001'],0,'production WIP must be cleared into finished goods');
assert(prodResult.docs.filter(d=>d.prodOrderId==='pr-1405-000001').length===5,'all production vouchers remain linked to the unique production order');

// A production material issue must honour the selected FIFO method instead of silently falling back to moving average.
const fifoProd=makeState();fifoProd.settings={inventory:{costingMethod:'fifo'}};fifoProd.goods=[{id:'raw',name:'مواد اولیه',unit:'کیلوگرم',kind:'material',q1:0,c1:0,opening:{}},{id:'finished',name:'محصول',unit:'عدد',kind:'finished',q1:0,c1:0,opening:{}}];fifoProd.accounts.push({code:'1691',name:'کالای در جریان ساخت'});fifoProd.taf={'1691':'production'};fifoProd.productionOrders=[{id:'fifo-order',orderNo:'PR-1405-000002-DTEST',productId:'finished',quantity:1}];fifoProd.ops=[{id:'f1',seq:1,no:1,type:'رسید کالا',date:'1405/01/01',items:[{g:'raw',q:5,p:100,w:'1'},{g:'raw',q:5,p:300,w:'1'}],status:'active'},{id:'f2',seq:2,no:2,type:'حواله مصرف مواد تولید',date:'1405/01/02',prodOrderId:'fifo-order',prodOrderNo:'PR-1405-000002-DTEST',costMethod:api.inventoryCostMethod(fifoProd.settings),items:[{g:'raw',q:5,p:0,w:'1'}],status:'active'},{id:'f3',seq:3,no:3,type:'رسید محصول تولیدی',date:'1405/01/02',prodOrderId:'fifo-order',prodOrderNo:'PR-1405-000002-DTEST',productId:'finished',quantity:1,warehouse:'2',status:'active'}];const fifoProdResult=api.build(fifoProd);assert.equal(fifoProdResult.errs.length,0,'FIFO production material issue and finished receipt post');assert.equal(fifoProdResult.inv['finished|2'].v,500,'FIFO production uses the oldest 5-unit layer at 100 per unit, not the 200 weighted average');
const brokenProd=makeState();brokenProd.goods=[...prodState.goods];brokenProd.accounts=prodState.accounts.filter(a=>a.code!=='6101');brokenProd.taf={'1691':'production','6101':'party'};brokenProd.productionOrders=prodState.productionOrders;brokenProd.ops=[prodState.ops[0],prodState.ops[1]];const brokenBuilt=api.build(brokenProd);assert(brokenBuilt.errs.length>0,'invalid production voucher should be rejected');assert.equal(brokenBuilt.prodWip['pr-1405-000001'],500,'failed voucher must not partially alter the WIP balance');

api.setState({...makeState(),goods:prodState.goods,productionOrders:prodState.productionOrders,workers:[{id:'wk1',name:'کارگر ۱',monthlyGross:30000000,requiredHours:200}],boms:[]});
const prodHtml=api.renderProduction('pr-1405-000001');
assert(prodHtml.includes('PR-')||prodHtml.includes('دستور ساخت'),'production page exposes production order area');
assert(prodHtml.includes('انتخاب دستور برای مشاهده ریزگردش'),'production page exposes order drill-down control');
assert(prodHtml.includes('مقایسه مقدار استاندارد و واقعی مواد'),'production report compares standard BOM quantities with actual consumption');
assert(prodHtml.includes('اسناد دوبل متصل به دستور'),'production report exposes linked double-entry documents');
assert(prodHtml.includes('تخصیص دستمزد کارگران'),'production report exposes employee-level labour allocation');
const bomHtml=api.renderProduction(null,'bom');assert.equal((bomHtml.match(/id=\"bom_g_/g)||[]).length,20,'BOM editor supports twenty raw-material lines per product');
const goodHtml=api.renderSettings('inv');
assert(goodHtml.includes('واحدهای اندازه‌گیری کالا'),'settings page documents the eight recommended measurement units');
assert(goodHtml.includes('ضریب بسته‌بندی'),'settings explains item-specific package conversion');
console.log('PASS: unit conversion rules, unique production orders, and production-order accounting flow with FIFO costing.');
