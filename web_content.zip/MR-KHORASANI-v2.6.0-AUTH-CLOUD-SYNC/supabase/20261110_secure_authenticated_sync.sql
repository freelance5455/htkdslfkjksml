-- MR,KHORASANI 2.6.0 — secure authenticated snapshot sync
-- Applied to project klomsegarpfdkhkmoazy on 2026-11-10.
-- Run once in a controlled migration window; this script does not migrate legacy master data.

begin;
revoke all privileges on all tables in schema public from anon;
revoke truncate, references, trigger on all tables in schema public from authenticated;
alter default privileges in schema public revoke all on tables from anon;
alter default privileges in schema public revoke truncate, references, trigger on tables from authenticated;

revoke usage on schema app from anon;
grant usage on schema app to authenticated;
revoke execute on all functions in schema app from public;
grant execute on function app.has_company_access(uuid) to authenticated;
grant execute on function app.can_write(uuid) to authenticated;
grant execute on function app.can_manage_users(uuid) to authenticated;
grant execute on function app.company_unclaimed(uuid) to authenticated;
grant execute on function app.can_close_day(uuid) to authenticated;

drop policy if exists companies_bootstrap_select on public.companies;
drop policy if exists companies_update on public.companies;
create policy companies_update on public.companies
for update to authenticated
using (app.can_manage_users(id))
with check (app.can_manage_users(id));
drop policy if exists companies_delete on public.companies;

create or replace function app.can_write(p_company_id uuid)
returns boolean language sql stable security definer
set search_path = pg_catalog, public
as $function$
  select exists(
    select 1 from public.company_members m
    where m.company_id = p_company_id
      and m.user_id = auth.uid()
      and m.is_active = true
      and m.role in ('OWNER','ADMIN','FINANCE','ACCOUNTANT','SALES','PURCHASE','CASHIER','WAREHOUSE')
  );
$function$;

create or replace function public.save_app_state_snapshot(
  p_company_id uuid,
  p_state jsonb,
  p_schema_version text,
  p_expected_updated_at timestamptz default null
)
returns timestamptz
language plpgsql
security invoker
set search_path = pg_catalog, public, app
as $function$
declare
  v_current timestamptz;
  v_new timestamptz := clock_timestamp();
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;
  if not app.has_company_access(p_company_id) or not app.can_write(p_company_id) then
    raise exception 'COMPANY_WRITE_FORBIDDEN';
  end if;
  if p_state is null or jsonb_typeof(p_state) <> 'object' then raise exception 'INVALID_SNAPSHOT'; end if;
  perform pg_advisory_xact_lock(hashtextextended(p_company_id::text, 0));
  select s.updated_at into v_current from public.app_state_snapshots s
    where s.company_id = p_company_id for update;
  if found then
    if p_expected_updated_at is null or v_current <> p_expected_updated_at then raise exception 'SYNC_CONFLICT'; end if;
    update public.app_state_snapshots set state=p_state,
      schema_version=coalesce(nullif(p_schema_version,''),'1.6.0'),
      updated_by=auth.uid(), updated_at=v_new where company_id=p_company_id;
  else
    if p_expected_updated_at is not null then raise exception 'SYNC_CONFLICT'; end if;
    insert into public.app_state_snapshots(company_id,state,schema_version,updated_by,updated_at)
      values(p_company_id,p_state,coalesce(nullif(p_schema_version,''),'1.6.0'),auth.uid(),v_new);
  end if;
  return v_new;
end;
$function$;
revoke all on function public.save_app_state_snapshot(uuid,jsonb,text,timestamptz) from public, anon;
grant execute on function public.save_app_state_snapshot(uuid,jsonb,text,timestamptz) to authenticated;
commit;
