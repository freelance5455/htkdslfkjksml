MY WALLET v4.5 — ANDROID PROJECT

What's new in v4.5
- Languages: English, Arabic (العربية), Kurdish Sorani (کوردی) with full right-to-left layout.
- Currencies: 24 built-in (IQD, USD, EUR, TRY, IRR, SAR, AED, KWD, ...) plus a custom label.
  Changing currency only changes the label; amounts are NOT converted.
- New futuristic dark/light design with a spending ring chart.
- Dialogs rewritten as in-app sheets (the old alert/confirm/prompt do not show in a plain WebView).
- Backup: Settings > Export data / Import data (saves a .json file you choose).
- App icon, safe-area handling for Android 15, links can no longer navigate away from the app.

BUILD AN APK
1. Open the project folder in Android Studio and let Gradle sync.
2. Build > Build Bundle(s) / APK(s) > Build APK(s).
   Debug APK: app/build/outputs/apk/debug/app-debug.apk

BEFORE PUBLISHING TO GOOGLE PLAY
- Change applicationId and namespace from com.example.mywallet to your own unique ID
  (Play rejects com.example.*). Rename the java package folder to match.
- Build a signed release bundle (Build > Generate Signed Bundle / APK > Android App Bundle).
- Check Google's current target SDK requirement for new apps.
- Add a privacy policy URL and complete the Data safety form (the app collects nothing).

NOTES
- No internet permission is requested; the app runs from the bundled HTML.
- Data is stored locally (WebView localStorage). Use Export before uninstalling.

v4.5 changes
- "End this month" is now "Close this month" and lives in Settings.
- Recent spending moved from Home to the History tab (above Past months).
- Import/Export open a sheet: choose a file or paste text.
- "Close this month" is always visible in Settings (disabled when no month is open).
- Import/Export are now inline in Settings (no popups). Import shows how many categories, spendings and months it found, then asks for a second tap to confirm.
- Import data now has a "Merge into current data" button: adds missing categories/spendings from a backup without deleting what you already have (matches categories by name, skips duplicates).
- Deleting a spending or category now asks Yes/No first, then shows an Undo button for 8 seconds.
- In builder/WebView apps without a file picker, Choose file and Save file are hidden; use Paste from clipboard / Copy text instead.
- Import tolerates curly quotes, code fences and extra spaces, and explains why a backup text is invalid.
