MORROW — JOURNAL PAGE ORDER FIX

This ZIP contains index.html at the archive root for your ZIP-to-APK converter.

Fix included:
- Journal entries now display in chronological page order: Page 1, Page 2, Page 3, and so on.
- The oldest entry appears first and the newest entry appears last.
- Page labels are shown in the notebook list.
- Edit and delete actions continue to target the correct entry after reversing the display order.

No other app features or styling were intentionally changed. Existing saved entries are not rewritten; their display order is corrected.

Before replacing an installed build, export a backup from Morrow Settings as a precaution.
