RP CIDADE LIVRE — BUILD JOGÁVEL V1

Esta é uma primeira build funcional feita para navegador/HTML-to-APK.

COMO TESTAR:
1. Extraia o ZIP.
2. Abra index.html em um navegador moderno.
3. No celular, use o joystick da esquerda para andar.
4. Use AÇÃO para interagir.
5. Aproximar-se do carro e tocar ENTRAR CARRO permite dirigir.
6. Vá até o marcador amarelo "RP" para completar a primeira missão e receber $250.

CONTROLES:
- Celular: joystick + botões.
- PC: WASD ou setas.
- Shift: correr.
- Espaço: ação.

OBSERVAÇÃO:
A build é um jogo original inspirado em mecânicas de RP urbano. Não usa personagens, mapa, músicas ou arquivos do GTA.
