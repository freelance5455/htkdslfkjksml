PokéPad — HeartGold Generations
Pacote compatível com conversores HTML → APK e WebViews mais antigos.

IMPORTANTE:
- index.html está na raiz.
- JavaScript foi refeito sem async/await, arrow functions e optional chaining para maior compatibilidade.
- A barra de pesquisa possui sugestões automáticas via datalist.
- Digite poucas letras, como “Pika”, e o navegador poderá sugerir Pokémon correspondentes.
- Ative JavaScript e Internet no conversor HTML → APK.
