AVIATOR PREDICTOR — BROWSER BUILDER PROJECT

Files:
- index.html
- style.css
- app.js

How to build on a phone:
1. Create a new WebView/HTML app in your browser-based Android builder.
2. Upload/add these three files.
3. Set index.html as the start page.
4. Build/export the APK.
5. Install the APK on your Android phone.

This app is a statistical/demo estimator, not a guaranteed Aviator predictor.
