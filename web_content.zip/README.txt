خطوات النشر (مجاني تقريباً) على Render.com
1) سوّي حساب على console.anthropic.com وسوّي API Key (تحتاج رصيد صغير).
2) ارفع هذا المجلد على GitHub.
3) على render.com: New > Web Service > اختار المستودع.
   Build Command: (فاضي)   Start Command: npm start
   Environment: ANTHROPIC_API_KEY = مفتاحك
   (اختياري) HOURLY_LIMIT = 20  (عدد الطلبات بالساعة لكل شخص)
4) ياخذ رابط مثل https://اسم.onrender.com — شاركه ويا أصدقائك.
5) من Chrome بالتلفون: ⋮ > إضافة إلى الشاشة الرئيسية، ويصير يشتغل مثل تطبيق.

لو تريد APK حقيقي:
npm i -g @capacitor/cli ; npm i @capacitor/core @capacitor/android
npx cap init khamis com.khamis.app --web-dir=public
ثم بـ public/index.html غيّر "/api/generate" إلى رابط السيرفر الكامل، وبعدها:
npx cap add android ; npx cap sync ; npx cap open android
ومن Android Studio: Build > Build APK.
