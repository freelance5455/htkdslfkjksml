DRACO AI — Personal OTC & Real Signal Engine (v3)
================================================

What is updated in v3:
1. Decoupled Manual Override vs. Auto-Sync:
   - When Manual inputs are left on "Auto (Dynamic)", Manual mode stays inactive (AUTO SYNC) and signals generate independently with balanced CALL & PUT distribution (preventing one-sided CALL streaks).
   - As soon as you select a Trend, Zone, or Candle Pattern, MANUAL ACTIVE turns on and generates signals from your manual selection. Tap "Auto Sync" anytime to return to automatic mode.
2. Full Timeframe Dropdown (1 Minute up to 1 Day) + Floating Glass Cards + BD Server Time (UTC+6) + Cooldown Timer.
