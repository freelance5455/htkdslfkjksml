OFFICE AUDIT CHECKLIST APP (APKForge ZIP)

Import this ZIP into APKForge as the web app project.
Features:
- Dashboard overview and category completion counts
- Daily, Weekly, Monthly and As Required checklists (all 43 original items)
- Checkbox status with automatic date/time records
- Per-item notes saved and included in history
- History page with category filter and search
- Add checklist items with number/sub-number and category
- Edit and delete checklist items (history retained)
- Export JSON backup
- Data saved locally on this device/browser

Note: Local storage is device/browser-specific. Export backups regularly if needed.
