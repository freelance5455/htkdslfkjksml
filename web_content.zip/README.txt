Sri Bangaradamma website package for HTML-to-APK converter.
Start page: index.html
App name suggestion: Sri Bangaradamma
Package ID suggestion: com.ncreations.bangaradamma
External temple pages and donation links require internet access.
