BIKOO 2018 - SINGLE FILE HTML APP

This is a converter-friendly version: open index.html directly or upload the ZIP to an HTML-to-APK builder that accepts a website ZIP / index.html.

Features:
- Clean responsive interface
- Reading mode opens notes without showing Edit controls
- Edit button required to change a note
- Auto-save to local device storage
- 16 page colors
- Font size A-/A+ controls
- Full-screen editor
- Copy, paste, share, rich text, bullets and numbering
- Search, categories, favorites and TXT export
- Dark app theme

Important:
- Notes are stored locally on the device/browser. Back up important notes by exporting them.
- Screen-awake depends on Android WebView/browser support.
- This is source code, not a compiled APK.
