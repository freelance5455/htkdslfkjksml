for_html_to_apk_app/index.html : use with your HTML-to-APK app. Exports cannot save files there; use the 'Works in ANY WebView' buttons (copy to Excel/Sheets, text box, mail link) and the storage/clipboard backups.
android_project/ : real file Save-as support (build with Android Studio or GitHub Actions, see its README.md).
