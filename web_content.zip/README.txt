Contractor Pro V1 Fixed
========================
This ZIP is structured for HTML-to-APK tools that expect:
web/index.html

Import/select this ZIP in the HTML-to-APK builder.
The app is a working prototype. Store licensing, account login, billing and server-side entitlement
are NOT included in this prototype yet and must be added before commercial release.
