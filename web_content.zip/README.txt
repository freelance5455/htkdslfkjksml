Contractor Pro V13.0 — Subscription & License
Global Edition · APK Ready

Base: verified Contractor Pro V12 Cloud & Sync.

V13 adds a conservative Subscription & License layer:
- License metadata: License ID, provider, product ID.
- Plan/status/expiry/server-validation state display.
- Production server validation preparation.
- Offline-first operation is preserved.
- No fake online purchase, OTP, cloud sync, or server validation is claimed.
- Paid entitlement must be returned and validated by the real Contractor Pro backend.
- V12 Cloud & Sync structures are preserved.
- V11 Account & Security structures are preserved.
- Existing local data migration includes the V12 storage key.
- Original splash is preserved unchanged.

APK converter requirement:
- index.html is at ZIP root.
- package.json is at ZIP root.
- No external JS/CSS dependencies.
- No manifest is required by this package.

This is a development/commercial-architecture build, not a final production backend.
