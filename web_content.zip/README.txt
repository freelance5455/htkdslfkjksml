# My Calendar — APK Project

Ini adalah project Android Studio untuk aplikasi kalender pastel blue.

## Yang sudah disiapkan
- Tampilan kalender berasal dari kode HTML yang kamu berikan.
- `alarm.mp3` yang kamu upload sudah dimasukkan ke `app/src/main/res/raw/alarm.mp3`.
- Saat kegiatan disimpan, Android menjadwalkan alarm native.
- Alarm menggunakan AlarmManager exact + foreground service.
- Suara alarm di-loop sampai tombol **MATIKAN ALARM** ditekan.
- Notifikasi Android memiliki tombol **MATIKAN ALARM**.
- Penghapusan kegiatan membatalkan alarm native.
- Data kegiatan tetap memakai localStorage WebView.

## Cara membuat APK
1. Install Android Studio di laptop/PC.
2. Buka folder `MyCalendar` sebagai project.
3. Tunggu Gradle selesai sync.
4. Jalankan ke HP Android untuk tes.
5. Izinkan notifikasi.
6. Jika Android meminta izin alarm tepat, izinkan.
7. Untuk APK: Build > Build App Bundle(s) / APK(s) > Build APK(s).

## Catatan
Project ini memakai AlarmManager Android, jadi jauh lebih cocok untuk alarm ketika layar mati/aplikasi tidak sedang dibuka dibanding timer JavaScript biasa.
