Road to Doomsday - Marvel checklist (158 titles by release date)

Files:
- index.html     the whole app (open it in any browser)
- icon.png       1024x1024 app icon (icon-192.png / icon-512.png are smaller copies)
- manifest.json  lets phones add it to the home screen

Run: unzip, then open index.html.
Phone home screen: host the folder on any static host (GitHub Pages, Netlify, ...), open the link, then Add to Home Screen.
Your "done" marks are saved in the browser on that device only.
