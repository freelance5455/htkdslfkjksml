SHARON PRECIOUS WRITER'S STUDIO — OFFLINE BUILD

Upload this ZIP to your APK converter using its ZIP option.

Included local/offline modules:
- Dashboard and word/chapter/character/idea counts
- Multiple novel projects
- Writing workspace with chapter drafts, autosave, word count, chapter rename/delete, TXT export
- Novel Bible (premise, setting, rules, conflict, themes)
- Character creator (role, appearance, personality, backstory, goals, secrets, relationships)
- Plot planner (structure, plot threads, foreshadowing, twists, secrets, antagonist plan, continuity)
- Chapter planner (purpose, events, emotional change, ending hook)
- Scene planner
- Story timeline
- Ideas Vault
- Notes and journal
- Full JSON backup export/import

LIMITATIONS:
- AI Editor is not included; it needs an online AI service and API integration.
- This is a new standalone offline companion, not an exact copy of the original Lovable app or its existing data.
- This version does not include cloud sync, account login, publishing-platform integration, or automatic web syncing.
- The APK converter must package local HTML/JS correctly for offline operation. Test with data off before relying on it.
- Local data may be lost if app storage is cleared or the app is uninstalled. Export backups regularly.


UPDATE: This version adds a Publishing Platforms page for each novel. Track GoodNovel, MegaNovel, Wattpad, Inkitt, Webnovel, KDP, or another platform, with submission/publication status, an optional link, and notes. It records your tracking information locally; it does not publish directly to those sites.
