FF Bazar Demo Top-Up App

এটি একটি মোবাইল-ফ্রেন্ডলি DEMO UI।
এতে কোনো আসল bKash/Nagad payment বা Garena top-up API যুক্ত নেই।

চালাতে:
1. index.html ব্রাউজারে খুলুন।
2. UID, package ও payment method নির্বাচন করুন।
3. Order চাপুন।

আসল পেমেন্ট/টপ-আপ চালু করতে পরে বৈধ payment gateway ও অনুমোদিত top-up API/backend যুক্ত করতে হবে।
