# NYXARA — HTML → APK PACKAGE

This folder is designed for an HTML-to-APK wrapper.

FILES
-----
index.html   Main application
style.css    Obsidian/violet interface
app.js       Assistant logic, voice, memory, reminders and actions

QUICK SETUP
-----------
1. Upload/import the whole folder into your HTML-to-APK builder.
2. Set index.html as the start/home page.
3. Enable JavaScript.
4. Enable microphone permission if the builder provides it.
5. Enable WebView/local storage.
6. Build the APK.

WHAT IT DOES
------------
- Nyxara-style digital assistant interface
- Text chat
- Voice input when the wrapper exposes Web Speech Recognition
- Voice output using Speech Synthesis
- Local memory
- Local conversation history
- Reminders while the app is active
- Quick actions
- Android Settings intent
- YouTube/Google/WhatsApp links
- Optional secure AI backend endpoint

IMPORTANT
---------
HTML by itself cannot become a complete Android system assistant.

For genuine background Android functions such as:
- waking on a hotword while the app is closed
- reliable notifications after the app is killed
- reading phone notifications
- sending messages automatically
- controlling other apps deeply
- setting itself as the Android default assistant

the HTML-to-APK builder must expose native Android APIs/plugins.

AI SECURITY
-----------
Do NOT put an OpenAI or other private API key directly in app.js.
Use a secure backend endpoint instead.

The Settings screen contains an optional AI endpoint field.
The app sends:
{
  message,
  memory,
  history
}

and expects JSON such as:
{
  "reply": "Nyxara's answer"
}

PERSONA
-------
The interface is Nyxara-themed, but the HTML layer intentionally does not
hard-code a private API key or unsafe device-control permissions.
