PDF MANIA by Anand Pandey - APKForge package

IMPORTANT: index.html is intentionally at the ZIP ROOT.
Upload this ZIP to APKForge.

Entry file: index.html
App name: PDF MANIA by Anand Pandey
Icon: icon.png

The HTML app uses CDN libraries for PDF.js, pdf-lib, jsPDF, Mammoth and JSZip.
For full offline APK operation, APKForge/build configuration must bundle these libraries locally or allow the required CDN resources.
