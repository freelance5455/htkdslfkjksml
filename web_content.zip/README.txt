ALL LINKS APP V19
Delete button fixed for WebView: tapping Delete directly removes the selected link and saves the change to local storage. No confirmation dialog is used.
