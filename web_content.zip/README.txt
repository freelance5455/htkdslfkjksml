SAFELY PWA v4

Offline browser/PWA personal finance command centre.
No server, Firebase, API, or cloud database required.

Features:
- Home dashboard, financial week W1–W4
- Income / expense recording with delete
- Dynamic fixed expense types: add, edit, delete (modal forms)
- Horizon: 1 / 3 / 6 / 12 month income, bills, leftover, cash position
- Calendar, goals, tutoring, notes, what-if
- Themes, currency (ZAR/USD/GBP/EUR), export/import JSON
- LocalStorage + service-worker offline caching

v4 fixes:
- Edit and Delete for fixed expenses use modal forms + data-action handlers
  (no broken prompt/onclick escaping)
- Horizon multi-month outlook
- Transaction IDs for reliable delete
- Migrates data from safely_pwa_data_v3 when present

Open index.html in a browser, or package as a PWA/APK with any HTML wrapper.
