SHAIKH ERP – Box Costing Package
================================

Main application:
app/index.html

Included:
- Box Costing
- RSC / HSC / FOL / OSC / 5 Panel
- MM / CM / Inch / Foot units
- Sheet, Deckle and Cut calculations
- 3 / 5 / 7 Ply and flute options
- Paper board options
- Printing & Lamination
- Die Charge
- Profit & GST
- Local browser storage for saved costings

How to use:
1. Open app/index.html in Chrome/Edge.
2. For APK/EXE conversion, use the app/index.html file or this project folder.
3. Keep the folder structure unchanged if additional assets are added later.

Note:
This package contains the current HTML prototype. Some sidebar modules in the prototype are previews/placeholders and are not full production modules.
