CLIO — History Intelligence (starter app)

HOW TO OPEN ON ANDROID
1. Download and extract clio_history_app.zip.
2. Open index.html using Chrome.
3. If Android asks which app to use, choose Chrome.

This is a working browser-based starter app with:
- Home screen and navigation
- Built-in history topic answers (not live generative AI)
- Explore categories
- Historical timeline
- Multiple-choice quiz

Important:
- It does not require an account or sign-in to run locally.
- The first version is English-only; the language selector is a preview.
- A real AI assistant requires connecting a model through a secure backend. Do not put a private API key in a public HTML file.
- This is a web app prototype, not yet a Play Store or iPhone App Store release.
