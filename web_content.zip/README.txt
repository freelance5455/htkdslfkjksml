THE HOLLOW ESTATE — V12 GOTHIC 3D
=================================

A mobile-friendly, first-person gothic horror survival game using a custom WebGL 3D renderer. No external JavaScript library or network download is required. The game world is built from 3D geometry in the browser; the cover image is used only for the menu.

MANSION DESIGN (inspired by your reference picture)
- A grand entrance hall with a burgundy runner, gold trim, tall arches, ornate staircase details, and multiple chandeliers.
- Antique framed portraits in the corridors, dark stonework, carved wooden furniture, wall sconces, and atmospheric fog/flashlight lighting.
- Four connected levels: Basement, Ground Floor, Upper Floor, and Attic.
- A concealed library behind a bookcase on the upper floor, filled with shelves, a desk, books, and a hidden Moon Relic.
- Multiple wardrobes for hiding, hidden caches, a false bookcase panel, loose floorboards, and a cracked stone niche.
- The Veiled Bride has a redesigned 3D silhouette with a flowing gown, layered veil, pale face, glowing eyes, and roaming/chase behavior across the floors.

HOW TO PLAY ON ANDROID
1. Extract the ZIP into a folder.
2. Open index.html in Spck Editor and use Preview / run, or host the folder on a static web host.
3. Landscape orientation is recommended for the widest view.
4. Tap ENTER THE ESTATE. Use the left pad to move and drag on the right side of the view to look around. Use the on-screen action buttons to search, toggle the flashlight, hide, use stairs, and run.

DESKTOP CONTROLS
WASD / arrow keys = move; mouse = look; E or Space = interact/search; F = flashlight; Shift = run; U = stairs up; J = stairs down; M = map; P or Escape = pause.

OBJECTIVE
1. Collect four Moon Seals, one on each level.
2. Find the generator fuse in the basement.
3. Search the ground-floor false bookcase for the brass key; use it on the concealed upper-floor library door.
4. Start the basement generator after recovering all four seals.
5. Return to the ground-floor entrance and escape through the front doors.
6. Hide in wardrobes if the Bride gets close. Search the floorboards, stone niche, and bookcase for optional hidden objects.

ACCESSIBILITY / PERFORMANCE
- Pause control at the top centre, show/hide map, larger UI option, reduced-motion option, touch movement pad, and interaction buttons.
- The renderer caps device pixel ratio to reduce load on mobile hardware.

NOTES
- This is real perspective 3D rendered through WebGL, but its visuals are procedural custom geometry rather than a large imported AAA asset pack. It needs a modern browser with WebGL enabled.
- If opening index.html directly fails in a particular Android file manager, open it through Spck Editor Preview or host the folder as a static website.
