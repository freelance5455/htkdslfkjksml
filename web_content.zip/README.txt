CRICKET LEGENDS — WEB GAME PACKAGE

Files:
- index.html: the game, including its CSS and JavaScript, in one self-contained HTML file.

How to use:
1. Extract this ZIP in your Android app builder, or upload the ZIP if the builder supports HTML game projects.
2. If the builder asks for the start page, choose index.html.
3. This is a web game package, not an APK. You still need an app builder or WebView wrapper to turn it into an Android APK.

Notes:
- The HTML file contains no external script or stylesheet imports, so the core game is packaged in one file.
- Some menu options in the current game may be incomplete or use fictional/sample data. A ZIP conversion does not add new gameplay features or make official player data/logos appear.
