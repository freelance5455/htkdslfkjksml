ANGOLA CONNECT VPN PRO - PACOTE COMPATÍVEL COM "ZIP PARA APK"
======================================================================
Este arquivo compactado possui o arquivo 'index.html' exatamente na RAIZ principal,
conforme exigido pelo aplicativo Android "ZIP para APK":

Arquivos incluídos na raiz:
- index.html (Aplicativo completo com 5 abas ativas, SNI, Operadoras, Logs e Perfil)
- manifest.json (Configuração PWA Android)
- README.txt

Como instalar no seu celular:
1. Abra o aplicativo 'ZIP para APK' no seu celular Android.
2. Selecione este arquivo ZIP baixado (angola_connect_vpn_apk_pkg.zip).
3. Clique em 'Converter' ou 'Gerar APK'.
4. O app criará o instalador APK com suporte completo a SNI Unitel, Africell e Movicel!

Suporte WhatsApp Oficial: +244 958 174 838
