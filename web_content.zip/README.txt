RIAZ DAIRY - HTML TO APK PACKAGE

এই ZIP-এর index.html হলো Riaz Dairy-এর অ্যাপ।

HTML-to-APK Builder-এ:
1. ZIP ফাইলটি Upload করুন।
2. App name: Riaz Dairy
3. Package name: com.riazdairy.app
4. Launcher icon হিসেবে নিজের Riaz Dairy logo দিলে সেট করুন।
5. Build/Generate APK করুন।

অ্যাপের হিসাবের খাত:
- খাদ্যের বিল
- ওষুধের বিল
- স্টাফ/শ্রমিকের বিল
- বিদ্যুৎ/পানি
- পশু কেনার খরচ
- রক্ষণাবেক্ষণ
- অন্যান্য

আয়, মোট ব্যয় এবং লাভ/ক্ষতির হিসাবও আছে।
