MY GEOMINERAL OFFLINE MOBILE

This is a phone-friendly offline web app/PWA.

EASIEST:
1. Extract this ZIP.
2. Put the folder on a web host or local network server.
3. Open index.html through a browser.
4. Use the browser menu > Add to Home screen.

For full offline PWA installation, the browser normally requires the app to be served over HTTPS (or localhost). A file:// HTML can still run many features, but service-worker installation may be blocked.

The app stores samples in the phone browser's local storage.
