MASUD CARROM - 2 Player
========================

1. Open index.html in Chrome/any modern browser.
2. Press/hold the striker and pull back, then release to shoot.
3. Player 1 plays from the bottom; Player 2 plays from the top.
4. NEW GAME starts a fresh match.
5. RESET returns the striker to the current player's line.

No external files or libraries are required.
