SCENA — REAL STARTER
======================
Questo pacchetto contiene:
- PWA mobile-first
- schema PostgreSQL/Supabase per utenti, scene, like e commenti
- regole RLS di sicurezza
- configurazione frontend
- demo UI pronta

Per renderla multiutente reale serve creare un progetto Supabase gratuito e inserire URL + anon key
in config.js. Non serve una carta per il piano Free secondo la documentazione ufficiale; il progetto
può però essere messo in pausa dopo inattività.

Il file APK richiede poi un wrapper Android (es. Capacitor) o un convertitore PWA/HTML→APK.
