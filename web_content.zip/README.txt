HOLY QURAN - offline PWA (569-page Madinah Mushaf PDF built in)

FILES
 index.html            app (home, reader, about) - all code in one file
 quran.pdf             your Quran PDF (decrypted/optimised, 3.9 MB)
 lib/pdf.min.mjs,
 lib/pdf.worker.min.mjs  PDF.js (legacy build, Apache-2.0) - renders the PDF
 sw.js                 service worker: caches everything for offline use
 manifest.webmanifest, icon-192.png, icon-512.png   install info

INSTALL ON ANDROID (needs internet only ONCE)
 1. Upload this whole folder to any free static host
    (Netlify Drop: app.netlify.com/drop, GitHub Pages, Cloudflare Pages).
    It must be served over https.
 2. Open the link in Chrome on your phone, wait ~10 seconds for it to load.
 3. Chrome menu (3 dots) > "Install app" / "Add to Home screen".
 4. Turn on airplane mode and open it from the home screen - it works offline.

REAL APK (optional)
 Give the https link to pwabuilder.com > Package for Android. It produces an
 APK/AAB wrapping this same app. Total size is about 6 MB.

TEST ON A COMPUTER
 python3 -m http.server 8000   then open http://localhost:8000
