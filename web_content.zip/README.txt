NEXUS VIRTUAL DESKTOP - ANDROID APP PROJECT
===========================================

This folder is a complete Android project. It has not been compiled yet, so the
first build is what turns it into an installable app (an .apk file).

What the app is
- The whole NEXUS workspace (displays, Cardboard VR, AR camera, environments)
  bundled inside the app. It works offline. There is no INTERNET permission.
- Camera and head tracking work because the app opens the page on a secure
  (https) address, which phone browsers refuse to do for http://192.168.x.x links.
- Exports (JSON, setup notes) are saved to your phone's Downloads folder.
- Needs Android 8.0 or newer.
- Real PC desktop streaming is not built yet, in the app or anywhere else.

OPTION A - Android Studio (on a PC)
1. Install Android Studio (free): https://developer.android.com/studio
2. File > Open, then choose THIS folder (the one containing settings.gradle).
3. Wait for "Gradle sync" to finish. The first time it downloads components and
   can take several minutes.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Click "locate" in the popup. The file is app-debug.apk.
6. Copy app-debug.apk to your phone (USB cable, Google Drive, etc.) and open it.
   Android will ask you to allow "Install unknown apps" for the app you opened it from.

OPTION B - GitHub (nothing to install)
1. Create a free GitHub account and a new repository.
2. Upload everything in this folder, including the hidden .github folder.
   (If the upload skips it: in the repo choose Add file > Create new file, name it
   .github/workflows/build-apk.yml and paste in the contents of that file.)
3. Open the repository's Actions tab, pick "Build Android APK", press Run workflow.
4. When it turns green, open the run and download "NEXUS-debug-apk".
   Unzip it to get app-debug.apk, then install it as in step 6 above.

If a build fails, copy the error text and send it back. It is usually a small fix.

Notes
- This builds a "debug" APK, which is fine for your own phone. It is not for the
  Google Play Store.
- The app icon is a simple "N". Replace the files in app/src/main/res to change it.
- To update the page later, replace app/src/main/assets/index.html and rebuild.
