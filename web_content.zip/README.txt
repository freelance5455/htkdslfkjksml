MK ACCESSORIES POS - PWA PROJECT

Features: offline-first sales/billing, product inventory, purchases, udhaar tracking, expense recording, gross and estimated net profit reports, JSON backup/restore, CSV export and browser print receipts.

HOW TO USE AS AN INSTALLABLE ANDROID APP
1. Upload these files to a static HTTPS host (for example GitHub Pages, Netlify, or another HTTPS web host). Service workers and PWA installation do not work from a file:// URL.
2. Open the hosted URL in Chrome on Android.
3. Chrome menu > Install app (or Add to Home screen).
4. Open the installed MK Accessories POS app.

IMPORTANT
- This is a Progressive Web App project, not a signed APK. Building an APK requires an Android wrapper/build tool and signing.
- Records are stored locally in the browser/device. Export backups regularly.
- Offline mode becomes available after the first successful online load from HTTPS.
- Profit reports estimate gross profit from sale totals minus recorded product costs, then subtract recorded expenses. They do not include taxes or unrecorded costs.
- Older sales from the prior prototype may have profit calculated differently because the previous version deducted discount twice. Review historical reports and restore a backup if needed.
