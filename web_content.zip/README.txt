VetProfit 0.6.96 — FIX eliminazione paziente

Causa reale:
repairMissingClients() veniva eseguita ad ogni render e ricostruiva anche i pazienti leggendo i movimenti storici. Quindi, dopo aver cancellato “Ricki” dalla scheda cliente e salvato, il successivo render trovava una vecchia prestazione intestata a Ricki e lo aggiungeva nuovamente.

Correzione:
- i pazienti di un cliente esistente non vengono più ricreati dai movimenti storici;
- la lista pazienti della scheda cliente è ora gestita dall'utente;
- cancellare un paziente e salvare è persistente;
- i movimenti storici del paziente eliminato restano invariati (corretto: non si perde lo storico);
- solo quando deve essere ricreata da zero un'intera anagrafica cliente mancante, l'eventuale paziente del movimento viene usato come dato iniziale;
- salvataggio cliente riallaccia i movimenti anche tramite clientId.

Test regressione:
cliente con solo “Ricky” + vecchio movimento intestato “Ricki” → repair/render NON ricrea “Ricki”: OK.
