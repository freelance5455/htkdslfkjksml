# 3D Car - Motorcycle Rider (Web Game)

## Files
- `index.html` — game screen and controls
- `style.css` — responsive mobile layout and HUD
- `game.js` — Three.js 3D scene, motorcycle, road, scenery, traffic, gears, speed, steering and collision logic

## Run
This project loads Three.js from jsDelivr, so the device needs an internet connection.
Open `index.html` from a local web server (recommended) rather than `file://`, because `game.js` uses JavaScript modules.

A simple local server can be started from the project folder in Termux:
```bash
pkg install python -y
python -m http.server 8080
```
Then open `http://127.0.0.1:8080` in Chrome.

## APK
This ZIP is a web game source project, not a compiled APK. To package it as an Android app, import the `www` files into a Capacitor Android project and build with Android SDK/Gradle, or use a reputable HTML-to-APK service that accepts a ZIP. Test the resulting APK before sharing it.

## Notes
- This is a 3D motorcycle-riding prototype with a stylized motorcycle assembled from 3D shapes.
- Touch controls: left/right steering, gear, gas, brake, pause.
- Keyboard: arrow keys, Space for gear, P for pause.
- Landscape orientation is recommended.
