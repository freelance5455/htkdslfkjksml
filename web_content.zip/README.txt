Nokia Snake Game

Modes:
EASY   = 180ms (slow)
MEDIUM = 140ms (a little faster)
HARD   = 110ms (faster, but still controlled)

Use the MODE button to switch modes while playing.
