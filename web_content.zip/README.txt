CYBER PLUG — ANDROID WEB APP PACKAGE

Contents:
- www/index.html: complete single-file Cyber Plug app
- config.xml: Cordova-style WebView wrapper metadata

IMPORTANT: This ZIP is a wrapper/import package, NOT a compiled APK. An Android builder (such as APKForge) must compile and sign it.

Friend requests and friend DMs in this build are a local prototype: they save on this device only. They are not delivered to other users until a shared backend is connected.

The app loads React, ReactDOM, Babel, Tailwind, and Lucide from CDNs, so first launch and some features require internet access.
