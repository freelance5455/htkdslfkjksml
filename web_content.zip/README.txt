SHADOW RADIOLOGY V9
- Landscape orientation requested when the immersive game enters fullscreen (supported browsers).
- Transparent, compact touch controls with reduced visual obstruction.
- Landscape HUD and control placement optimized for short phone screens.
- If the browser blocks orientation locking, rotate the phone manually.
- Requires internet for external Three.js modules and the GLB character model.
- HTML preview, not an APK.
