Baraa.c v1.0

Same calculator features as Dafaallah Calculator, using the Baraa logo and Baraa.c branding.
Operation history and stopwatch history include delete controls.
Data is stored locally in the app.

Theme selector added; history deletion works without confirmation dialogs.
