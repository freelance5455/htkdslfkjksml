STAMINA UZ — V5 (so'zlar chiqmaslik muammosi tuzatilgan)

ISHGA TUSHIRISH
1. ZIP faylni oching (hamma fayllar bitta papkada tursin).
2. index.html faylini brauzerda oching. Boshqa narsa kerak emas.

FAYLLAR
- index.html            — asosiy ilova (so'zlar ro'yxati ichiga ham joylangan)
- words.txt             — so'zlar ro'yxati (har qatorda bitta so'z, faqat oddiy ' belgisi)
- manifest.webmanifest  — ilova nomi va ranglari (telefonga o'rnatish uchun)
- sw.js                 — internetsiz ishlash uchun (faqat https/localhost da ishlaydi)
- icon.svg              — ilova belgisi

SO'Z QO'SHISH
words.txt ga yangi so'zlarni yangi qatordan yozing. Ilova veb-serverga (http/https)
joylanganda words.txt ni avtomatik o'qiydi. Faylni to'g'ridan-to'g'ri ochsangiz,
index.html ichidagi ro'yxat ishlatiladi.

APK QILISH
Papkadagi hamma fayllarni Android WebView / website-to-APK loyihasiga birga joylang.
