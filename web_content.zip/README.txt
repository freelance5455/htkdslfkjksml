BRUNO PANEL - ANDROID STUDIO

1. Extrae esta carpeta.
2. Abre la carpeta BrunoPanel desde Android Studio.
3. Espera a que Gradle termine de sincronizar.
4. Pulsa Run para probarla en un teléfono/emulador.
5. Para generar el APK: Build > Build APK(s).

La app contiene un panel HTML local y sus funciones son simulaciones visuales.
No modifica Free Fire ni controla otras aplicaciones.
