SmartAttend AI - Teacher account setup

Teacher Google account configured in this prototype: shanthaishantha4@gmail.com
Sign in with this account to see Add Student and manual attendance controls. Other Google accounts currently get view-only access.

Important: this is only a front-end role display/control. It is NOT secure authorization by itself. Before real classroom use, configure Firebase Realtime Database Security Rules (or a trusted backend) to enforce teacher/student permissions. Student face enrollment, face scanning, and automatic attendance are NOT implemented in this ZIP yet.

Firebase project config is retained from the supplied app. Upload index.html to your existing hosting service.
