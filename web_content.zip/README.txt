Chandpur Video - Simple Upload
1. index.html must stay at the ZIP root.
2. This version uses the Cloudinary unsigned upload preset 'chandpur_video'.
3. It is designed to keep the upload control simple.
4. The app stores uploaded video links on the same device. It is not yet a shared multi-user feed.
