مشروع أندرويد (Gradle) - يبني APK حقيقي بصلاحية قراءة كل الفيديوهات تلقائي.
الفتح: Android Studio أو AIDE على الهاتف، ثم Build > Build APK.
الواجهة موجودة في app/src/main/assets/index.html
