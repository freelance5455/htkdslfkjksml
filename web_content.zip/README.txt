# SURYAVANSH vs ASUR EMPIRE 3D (Cinematic Edition)
**Production Banner:** Ringo Master

## How to Play on PC or Mobile
1. Extract `suryavansh_vs_asur_empire_3d.zip`.
2. Double-click `index.html` to open directly in any modern browser (Chrome, Edge, Brave, Firefox, Safari).

## Controls
- **A / D or Left / Right Arrow:** Switch Lanes
- **W / Space / Up Arrow:** 360° Aerial Jump
- **S / Down Arrow:** Spark Slide
- **F:** Shoot Agni-Baan (Fire Arrow) to shatter Asur enemies in Slow-Motion
- **Shift / E:** Unleash RAAKA Overdrive Boost (when energy bar is 100%)
- **C:** Toggle Front Hero Camera / Chase Camera
- **B:** Toggle Leather Ranger Boots / White Sport Sneakers
- **V:** Switch Cinematic Color Grading LUTs (Surya Gold, Neela Cyber, Blood Eclipse)
- **L:** Toggle 2.39:1 Widescreen Cinema Bars
