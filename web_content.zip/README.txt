Calculator app ZIP prepared for converters that expect web/index.html.
The project keeps index.html at the ZIP root and also mirrors all web files under web/.
