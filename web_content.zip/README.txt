VYB WEATHER — Developed by Abhay
=================================

Files
- index.html: complete single-page weather app (HTML/CSS/JavaScript)
- README.txt: setup notes

Features
- Live clock showing seconds, current date, month, and year
- Weather, feels-like temperature, humidity, wind, rain chance, UV, sunrise/sunset
- Hourly and 7-day forecast
- City search and device location
- Animated black intro screen: “DEVELOPED BY ABHAY”
- VYB voice assistant: speaks answers for time/date/weather; speech recognition depends on Android WebView support
- Glassmorphism design inspired by your reference screenshots

Weather API
Uses Open-Meteo's free forecast and geocoding endpoints. No API key is required.
An internet connection is required for live weather. If location permission is denied, Patna is used as the initial fallback; you can search another city in Settings.

Use on Android
1. Extract the ZIP.
2. Open index.html in Chrome to test first.
3. In your HTML-to-APK builder, import index.html or the extracted folder.
4. Import the ZIP contents so that index.html is at the top/root level (not inside an extra VYB_Weather_App folder). Enable Internet access and Location permission. Enable Microphone permission if your builder supports voice input.
5. For voice input, test in Chrome first. Some HTML-to-APK WebViews do not support Web Speech recognition even when text-to-speech works.

Important limitations
- This is a complete front-end starter, not a published native Android APK.
- The Profile screen is a demo, not real user login. Do not collect passwords in a static HTML app. Real secure login needs a backend/auth provider.
- “History” is currently a navigation shortcut to the 7-day forecast, not a stored past-weather database.
- Weather values come from a real API but can differ from some apps due to provider/model differences and update intervals.
