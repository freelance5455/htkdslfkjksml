HTML to APK Builder - Web ZIP
Upload this ZIP to HTML to APK Builder. index.html is at the archive root.
The image is bundled locally under assets/app-logo.png.
