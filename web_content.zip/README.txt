Muneeb Store Hisab Book app files

index.html = app
manifest.json and sw.js = installable web app support

To try: open index.html in a browser.
To install like an app: these files must first be hosted on an HTTPS website. Then open the website in Chrome on Android and choose menu (⋮) > Add to Home screen / Install app.

This is not an APK and is not published on Google Play. Records are currently stored only in the same browser/device; online sync is not included. Download backups regularly.
