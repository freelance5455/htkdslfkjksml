Pan Shop Khata - HTML to APK
Use index.html as the root entry file. This version is based on the supplied Cloud/Supabase HTML app.
Keep index.html at the ZIP root for HTML-to-APK converters.
