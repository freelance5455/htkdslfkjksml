SATYANAM SWEETS & SUDHA MILK PARLOR — STARTER APP

Files:
- index.html: shop management app
- manifest.json and sw.js: basic installable web-app support

How to use:
1. Extract this ZIP.
2. To use it on a phone, upload the extracted folder to a static HTTPS hosting service (for example, your own hosting).
3. Open the hosted index.html in Chrome on Android.
4. Chrome menu (⋮) > Add to Home screen / Install app.

Important:
- This is a starter offline browser app, not a signed Android APK or Play Store release.
- Data is stored only in that browser/device. Use Backup regularly.
- Sample products, prices and stock are placeholders for demonstration. Confirm actual Sudha MRP and your shop's sweet prices/stock before use.
- No GST invoice, barcode, cloud sync, multi-user login or automatic online backup is included yet.
