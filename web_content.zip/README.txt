DJ MOYIZA - PROJET ANDROID APK

Ce dossier contient le projet source Android (WebView) de DJ Moyiza.
Il n'est pas encore un APK compilé.

Pour produire un APK :
1. Installez Android Studio sur un ordinateur.
2. Ouvrez ce dossier de projet dans Android Studio.
3. Laissez Android Studio synchroniser Gradle et télécharger le SDK demandé.
4. Choisissez Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Récupérez l'APK dans app/build/outputs/apk/debug/app-debug.apk.
6. Transférez l'APK sur le TECNO POP 8, ouvrez-le et autorisez l'installation depuis cette source si Android le demande.

L'application fonctionne localement, sans compte ni serveur. Le contenu importé est stocké dans IndexedDB du WebView; effacer les données de l'application peut supprimer les médias importés. La sélection des fichiers utilise le sélecteur Android.
