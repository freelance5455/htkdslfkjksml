# Military 30 v3 — PWA
A genuine installable/offline PWA build.

IMPORTANT: Chrome generally will NOT offer Install/Add to Home screen when the app is opened directly from a `file://` path. It needs to be served over HTTPS (or localhost).

Easiest phone setup:
1. Put these files on a simple HTTPS web host (for example GitHub Pages or another static host).
2. Open the resulting HTTPS address in Chrome on your Samsung.
3. Chrome menu → Install app / Add to Home screen.
4. Launch Military 30 from the home screen.
5. After the first successful load, the service worker caches the app so the core app works offline.

No account, backend, analytics or subscription is required by the app.
