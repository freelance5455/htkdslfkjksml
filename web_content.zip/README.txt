MY QUIZ APP

यह एक offline personal MCQ quiz app है।

Files:
- index.html = app का layout
- style.css = app का design
- script.js = subjects, chapters और questions

नया question जोड़ने का format:

{
  question:"प्रश्न यहाँ लिखें",
  options:["पहला","दूसरा","तीसरा","चौथा"],
  answer:0
}

answer:
0 = पहला
1 = दूसरा
2 = तीसरा
3 = चौथा

नया chapter जोड़ने के लिए:
1. chapters में chapter का नाम जोड़ें।
2. questions में उसी नाम की key बनाएं।
3. उसके अंदर MCQ डालें।

Acode में index.html खोलकर Preview करें।
