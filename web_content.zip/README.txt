ONE LOVE V3

Nouveautés :
- ❤️ Likes interactifs
- 💬 Commentaires interactifs
- ↗ Partage de démonstration
- Les données sont conservées localement sur le téléphone.

Important : cette version reste un prototype local. Les données ne sont pas encore partagées entre plusieurs téléphones. Une prochaine étape pourra ajouter un serveur et une base de données sécurisés.
