====================================================================
MATYKA CHEATS — PROXY ANDROID
INSTRUÇÕES DE IMPORTAÇÃO E COMPILAÇÃO (APK FORGE / HTML TO APK)
====================================================================

1. ESTRUTURA DO PROJETO
- index.html             -> Arquivo principal na raiz do ZIP.
- assets/style.css       -> Folha de estilos responsiva (tema escuro/neon).
- assets/app.js          -> Lógica local, persistência e navegação.
- assets/images/logo-m.svg -> Logotipo vetorial exclusivo.
- README.txt             -> Este guia de importação.

2. COMO IMPORTAR NO APK FORGE (OU CONVERSORES HTML PARA APK)
Passo 1: Não extraia nem coloque os arquivos dentro de subpastas extras.
         Importe diretamente o arquivo MATYKA_CHEATS_PROXY_ANDROID.zip
         (ou selecione o index.html da raiz caso a ferramenta peça a pasta).
Passo 2: Defina o nome do aplicativo como:
         MATYKA CHEATS
Passo 3: Orientação recomendada:
         Retrato (Portrait).
Passo 4: Permissões e recursos recomendados no construtor APK:
         - Ativar JavaScript (Enabled).
         - Ativar DOM Storage / localStorage (Obrigatório para salvar switches e KEY).
         - Permitir abertura de Intents externos (para abrir pacotes Android e Ajustes).
Passo 5: Compile e instale o APK gerado no dispositivo Android.

3. OBSERVAÇÕES TÉCNICAS
- O aplicativo funciona 100% localmente (offline-first), sem depender de
  servidores externos.
- Todas as preferências, switches e chave de ativação são armazenados no
  localStorage do WebView Android.
====================================================================
