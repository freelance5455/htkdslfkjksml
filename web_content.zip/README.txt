MIS TARJETAS - VERSION HTML2APK
index.html esta en la raiz del ZIP.
💚 TARJETAS / 💙 CREDITOS.
Incluye compras, MSI, cargos recurrentes, reestructuras, creditos, resumen final de pagos por separado y respaldo importar/exportar.
