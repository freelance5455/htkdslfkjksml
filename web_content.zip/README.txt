Chetan Info
============

Mobile-friendly HTML/CSS/JavaScript app.

Files:
- index.html
- style.css
- app.js

For an HTML-to-APK service, ZIP the contents of this project and upload the ZIP.
No server or external framework is required.
