AQUA Sales V5 FINAL — TARGET GLOBAL
- Target utama dihitung sebagai total seluruh target item.
- Pencapaian utama dihitung sebagai total realisasi seluruh item.
- Sisa global = total target - total pencapaian.
- Persentase sisa = sisa global / total target x 100.
- Rincian per item tetap ditampilkan sebagai informasi pendukung.
- Storage aqua_sales_v5 dipertahankan.
