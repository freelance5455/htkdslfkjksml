VIDEOGENIE recovery ZIP

Contains index.html at root and web/index.html to satisfy ZIP-to-APK HTML entry-point checks. The uploaded APK did not include the original web app source files, so this is a structural placeholder only, NOT a production-ready restoration of VIDEOGENIE. Upload the original project ZIP or provide the live website URL to restore full functionality.
