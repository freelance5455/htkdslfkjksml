FYNK OS Pro with Ad Reports
Open the HTML file in Chrome. Performance reports are based on records entered or imported as CSV. This standalone file cannot fetch private live aggregator reports automatically. Data is local to the browser. Production use needs a backend and authorized integrations.
