NAVYUVA DURGA PUJA APP - ADMIN CONTROLLED VERSION

Admin mobile: 7905106011

Features:
- Firebase Phone OTP login
- Admin controls which mobile numbers are allowed
- Non-approved numbers cannot enter the app
- Each receipt is stored in Firestore with the creating mobile number
- Admin dashboard: add/disable allowed numbers, see all receipts and total amount, delete receipts
- Users can see their own receipt history
- PDF receipt generation/download and sharing retained

IMPORTANT SETUP
1. Create a Firebase project.
2. Enable Authentication > Sign-in method > Phone.
3. Create Firestore Database.
4. Put your Firebase web config into index.html in firebaseConfig.
5. Publish firestore.rules from this ZIP to Firestore Rules.
6. Add your app domain to Firebase Authentication authorized domains if using a hosted web app.
7. For APK/WebView, use a builder that supports Firebase HTTPS/JS and phone auth. Phone OTP needs internet.

SECURITY
The Firestore rules make 7905106011 the only Admin. Do not rely only on the HTML UI; publish the included firestore.rules.
