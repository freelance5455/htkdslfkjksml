EKRAN HTML baglanyşyk taslamasy

index.html faýlyny brauzerde açyň. Ol https://bulutv.lovable.app/ saýtyny doly ekran iframe içinde açýar. Saýtyň dizaýny üýtgedilmeýär; asyl saýtyň dizaýny görkezilýär.
