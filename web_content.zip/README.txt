ZIP-TO-APK INSTRUCTIONS

This folder is the WebView/HTML version of FOMO Sniper.

For a ZIP-to-APK / Website-to-APK wrapper:
1. Use webapp/index.html as the app's start page.
2. If the wrapper asks for a ZIP, ZIP the CONTENTS of webapp so index.html is at the ZIP root.
3. Choose portrait mode.
4. Enable local storage if the wrapper offers the option.
5. Do not request camera, contacts, SMS, location, microphone, or storage permissions.
6. The app opens FOMO in an external browser when the OPEN FOMO button is pressed.

This HTML version does not execute trades and does not request wallet/private-key information.
