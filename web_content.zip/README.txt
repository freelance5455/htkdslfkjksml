FIFO Family Roster – updated APK build package

What's included
- Multiple independent roster profiles, each with its own name, colour, start date and repeating pattern.
- Your alternating roster: 7 NIGHT shifts, 7 days off, 8 DAY shifts, 6 days off (28-day cycle). The start date is the first NIGHT shift.
- Daughter's existing 2 DAY, 2 NIGHT, 4 OFF cycle.
- Presets for 7/7, 8/6, 2/1, 2/2 and 4/4, plus custom blocks and day/night shift modes.
- Add birthdays, anniversaries, appointments and meetings. Appointments and meetings require a time.
- WA statewide public holidays shown on the calendar for 2026–2029, including the published 2028 changes.
- Local browser storage; profiles and events stay on the device/browser where entered.

Build the Android APK
1. Open https://www.apkbuilder.dev/
2. Choose Build from HTML or ZIP.
3. Upload this ZIP file.
4. Set app name to FIFO Family Roster.
5. Build and download the APK.
6. Install the APK on your Android phone.

Important
- This is an offline-capable HTML app. Data is stored locally in the app/browser storage and is not automatically shared between different phones.
- The previous v1 settings key is read and migrated into the new profile list when the old data is present in the same browser storage. The old 'first DAY shift' date is preserved as the DAY block in the new 28-day cycle by setting the cycle start 14 days earlier.
- WA public holiday dates are based on the WA Government public holidays page. Some regional holidays may differ; Show Day dates for 2028–2029 are the published dates in the Government table and may be subject to proclamation.
