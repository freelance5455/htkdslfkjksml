# NOVA Calculator

A standalone, mobile-first scientific calculator with a premium glassmorphism interface.

## Features
- Basic arithmetic, parentheses, percentage and sign toggle
- Scientific functions: sin, cos, tan, ln, log, square root, exponent and factorial
- DEG/RAD angle mode
- Calculation history saved locally in the browser/WebView
- Light/dark theme toggle
- Copy result, keyboard support, responsive layout and reduced-motion support
- Optional service worker for offline caching when hosted over HTTPS

## Files
- `index.html` — app layout
- `style.css` — glassmorphism visuals and animations
- `app.js` — calculator logic and local history
- `manifest.json` — web-app metadata
- `sw.js` — offline cache helper for HTTPS hosting

## Run locally
Open `index.html` in a browser or preview it in an HTML editor. Local-file browsers may block service workers; the calculator itself works without one.

## Package as Android APK
Use an HTML-to-APK/WebView builder that explicitly supports importing local HTML/CSS/JS files and exporting an APK. Import this project's files, set `index.html` as the start page, use app name `NOVA Calculator`, package ID such as `com.nova.calculator`, portrait orientation, and enable JavaScript/local storage. Build and install the APK. The service worker is optional inside a WebView.
Do not upload private files; this project contains no personal information.
