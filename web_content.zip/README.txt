EarnUG Android/Web Project
===========================

This is a self-contained mobile-first HTML/CSS/JavaScript app designed to be packaged as an Android APK.

Files:
- index.html — complete app

Features:
- Uganda-focused opportunity finder
- Search
- Categories
- Save opportunities using phone local storage
- External Apply/View buttons
- Scam warning and safety checklist
- Works offline for the bundled sample data

IMPORTANT:
The opportunity links/data are starter examples. Before public launch, replace them with verified, current opportunities and an appropriate backend/API.

Recommended online builder:
1. Open https://www.htmltoapp.dev/
2. Upload this ZIP.
3. Set App Name: EarnUG
4. Package name: ug.earnug.app
5. Choose APK.
6. Build and download the APK.
