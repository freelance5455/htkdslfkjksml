Smart Store Manager - Android APK Builder Package

1. In APK Forge, choose HTML to App / Zipped Site.
2. Select this ZIP file.
3. Keep the same app name and package name as your existing app: com.smartstoremanager.app.
4. Use a higher version than the installed app (for example 1.0.2 / version code 3).
5. Build and install as an update only if APK Forge uses the same signing key as the previously installed build. If Android says the app cannot be installed because signatures conflict, STOP and do not uninstall the current app.

Changes in this version:
- Report PDF is generated as a downloadable PDF file rather than relying only on window.print().
- Backup restore uses a JSON file picker and FileReader for broader WebView compatibility.
- Restore shows the selected backup's record counts and the current app's counts before confirmation.
- A safety snapshot of current app data is stored locally before a restore is attempted.

Important:
- This ZIP contains the app source only, not your private store data.
- Do not restore an old backup unless you are certain it contains the records you want. Restore replaces current records.
- Build and test on the phone. The source can be syntax-checked here, but APK Forge's WebView/download handling must be confirmed on your device.
