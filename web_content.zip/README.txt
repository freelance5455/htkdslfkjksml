CRYPTO SIGNAL ANALYZER — ZIP PACKAGE

Files:
- index.html
- style.css
- script.js

Run:
1. Extract this ZIP in SPCK Editor.
2. Open index.html and use Preview / Run.
3. Allow internet access and wait for Binance public market data.

Notes:
- This version uses Binance public REST endpoints, not Shark Exchange.
- If Binance endpoints are unavailable on your network, the dashboard may show a connection error.
- Signals are educational technical-analysis examples, not guaranteed predictions or financial advice.
- Entry/targets/stop-loss are illustrative percentage levels, not volatility-adjusted.
- The browser must have internet access. For an Android WebView APK, ensure INTERNET permission is enabled.
