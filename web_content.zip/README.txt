# NEXORA ONLINE

A simple real-time one-group gaming chat app.

## Included
- Server-side group password
- Real-time group chat with Socket.IO
- Online member list
- Typing indicator
- Voice/video calling using WebRTC
- Blue/black gaming UI
- Mobile-friendly layout

## Run on a PC
1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Run:
   npm install
4. Start:
   npm start
5. Open:
   http://localhost:3000

Default group password:
Nexa2026

You can change it before starting the server:
Linux/macOS:
NEXORA_PASSWORD=YourPassword npm start

Windows PowerShell:
$env:NEXORA_PASSWORD="YourPassword"; npm start

## Let friends connect
The server must be reachable from the internet. For a simple test, run the server on a hosting service that supports Node.js/WebSockets, then send friends the HTTPS address.

For voice/video, HTTPS is recommended/required by browsers for camera and microphone permissions (localhost is an exception). WebRTC may also need a TURN server for users behind restrictive NATs. The included STUN servers are only a starting point.

## Important
This is a starter server. Chat history is kept only in memory and is lost when the server restarts. The group password is server-side, but this is not a production authentication system.
