ACC V7 – Selectable Financial Period

This package updates ACC's dashboard financial-month panel. Tap the Financial Month panel to open a date-range selector. Choose a From date and an End date using the phone's calendar controls (day, month and year), then Apply date range.

Use automatic financial month resets the selection and returns to the recurring financial month configured in Settings.

The selected date range is saved with ACC's existing local data and is used for dashboard income/expense totals and the Food budget calculation. Existing transaction records and the current localStorage key are preserved.

Install/update using the same PWA hosting process as your existing ACC version. This is a PWA source package, not an APK. Back up records before updating and do not clear browser/app storage.
