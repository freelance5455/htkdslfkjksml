TABLETOP B751 V0.3
Sistema de mazos:
- crear mazos
- añadir/eliminar cartas
- barajar
- robar
- descartar
- devolver descartes y barajar
- guardar/cargar localmente
