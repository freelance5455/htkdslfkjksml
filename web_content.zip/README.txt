SHUVECCHA GARMENTS - Phone-first offline stock app

Files:
- index.html: app
- manifest.json: installable web app metadata
- sw.js: offline cache support when hosted over HTTPS

IMPORTANT:
This is a web app/PWA package, not a signed Android APK. It can be tested by opening index.html in a phone browser, but browser local storage is tied to that browser/device. For reliable install/offline behavior, host these files on an HTTPS static host, then open the hosted page in Chrome on Android and use menu > Add to Home screen / Install app. Back up data regularly from the app.
No login password is implemented in this initial version; the requested password feature needs secure implementation before use with sensitive data.
