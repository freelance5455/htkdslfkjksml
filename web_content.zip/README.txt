HOMENEST HOUSEHOLD INVENTORY V3
Buka index.html di browser HP.

Fitur:
- Dashboard
- Kategori dengan ikon
- Tambah/edit/hapus barang
- Foto barang dari kamera/galeri
- Pencarian
- Laporan nilai inventori per kategori
- Ringkasan stok
- Penyimpanan lokal
- ID unik per barang agar edit tidak tertukar
