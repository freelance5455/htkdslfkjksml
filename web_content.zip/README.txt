MECHANICAL TECH WORLD HTML APP

1. Download this ZIP on your Android phone.
2. Open Files > Downloads, tap the ZIP and choose Extract.
3. Open the extracted folder and tap index.html.
4. Choose Chrome or another browser.
5. Search a subject, open it, then tap Open subject PDF.

Keep the pdfs folder beside index.html. Do not move index.html alone. Local PDF opening depends on your browser/file manager. These are introductory notes; verify current VTU syllabus and prescribed references.