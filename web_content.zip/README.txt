Shop Manager - complete mobile-friendly offline version
No stock management.
Features: products, purchase/sale prices, fast search, new bills, automatic profit, sales records, daily/monthly reports, receipt sharing.
Data is stored locally in the browser.
This is a working web-app/PWA-style prototype, not a compiled APK.
