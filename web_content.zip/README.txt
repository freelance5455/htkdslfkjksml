SHAIKH Box ERP V10 - Consolidated Factory ERP Project

This project packages the existing SHAikh Box ERP modules into one Android Studio WebView project, including:
- Dashboard, multi-company profile and financial year settings
- Sales / GST invoices, quotations, sale returns / credit notes, print/PDF/share
- Purchase, purchase returns / debit notes, vendor ledger and stock movements
- Inventory, item master, stock valuation and low-stock indicators
- Dynamic GST rates, inclusive/exclusive invoice tax, CGST/SGST/IGST selection
- E-Way Bill entry and invoice-linked fields (government API integration requires credentials)
- Accounting journal/report screens and Khata / outstanding views
- Separate Cash Work module and cash-work entries
- Labour master, attendance, advance management, payroll calculation and payroll reports
- Box Designer with Use Size in Costing
- Factory costing: cutting size L+W+2, deckle W+H, paper cost = cutting x deckle x GSM x paper rate / 1,540,000, printing total / quantity, lamination and die area rates, manual overrides, profit markup or selling-price margin, GST separate, per-box and order totals.
- Visual box-type selector on costing screen with compact panel/flap diagram.
- Local browser storage and JSON backup workflow.

Important: This ZIP contains the Android Studio project source, not a precompiled APK. Open the project in Android Studio with Android SDK/Gradle configured to build an APK. Government e-way bill API access and any production deployment credentials must be configured separately. Verify all business calculations and compliance workflows against your factory's actual practices before production use.

V10 updates:
- Premium invoice screen with prominent invoice header, live amount summary, separate CGST/SGST/IGST display, and improved action buttons.
- Invoice validation for party, item, quantity, rate and discount.
- Print/PDF output includes company and party details, item, taxes, round-off, payment terms and total.
- Share invoice summary through Android share sheet, or copy where supported.
- JavaScript syntax check completed for the app asset.

Production note: this is still a local/offline WebView ERP starter project. Before using for statutory invoicing or live factory accounts, validate workflows and GST calculations on the actual Android device, and configure the company/GST profile. Government integrations need credentials.
