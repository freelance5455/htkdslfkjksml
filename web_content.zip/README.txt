# Mis Préstamos — aplicación administrativa + formulario público

Esta versión separa claramente los dos accesos.

## 1. Aplicación Mis Préstamos (privada)
La aplicación Android instalada en el teléfono del administrador abre siempre el panel completo: Inicio, Clientes, Nuevo préstamo, Pagos, Cuotas, Comunicación y Seguridad.

La aplicación NO convierte el enlace público en una pantalla del administrador ni usa enlaces internos `misprestamos://...` para los clientes.

## 2. Formulario público (clientes)
El cliente usa únicamente este enlace web:
https://mis-prestamos-21fd9.web.app/

El cliente no necesita instalar el APK. Completa el formulario y pulsa “Enviar solicitud por WhatsApp”.

## 3. WhatsApp
Las solicitudes se preparan para el número +57 300 4026303 e incluyen nombre, celular, documento, valor, plazo y motivo.

## 4. Desde la aplicación
En Comunicación, “Abrir formulario público” abre el formulario web fuera de la aplicación, y “Copiar enlace público” copia la dirección que se debe compartir.

## 5. Firebase Hosting
`firebase.json` publica la carpeta `public`. La dirección anterior solo estará activa cuando se despliegue esa carpeta en el proyecto Firebase `mis-prestamos-21fd9`.

Este ZIP contiene el proyecto Android y el sitio público. No afirma que Firebase ya esté desplegado.
