Nova Executor-Style UI (Website ZIP)

This ZIP is formatted for ZIP-to-APK tools that require index.html at the archive root.
Open index.html in a browser to preview. The Lua sandbox uses an external engine and needs internet access.
This is a UI/sandbox prototype only; it does not inject into Roblox.
