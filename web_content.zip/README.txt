SLB Paint Brush Web App
1. Upload this ZIP to a service that converts HTML/ZIP to Android APK.
2. App features: Orders, Customers, Invoice, Stock Track, Order Status and WhatsApp invoice sharing.
3. Data is stored locally in the browser/app.
