# STUDYVAULT 10 — CBSE Class X 2026–27

## Run it
- Extract the ZIP.
- Open `index.html` in a modern browser, or upload the ZIP to a static host that serves `index.html` from the archive root.
- No build step, account, server, or internet connection is required for tracking.

## Included
- Preloaded subjects and chapter index for Mathematics Standard (041), Science (086), Social Science (087), English Language & Literature (184), Hindi Course A, and optional Information Technology (402).
- 15 independently saved tasks per chapter.
- Completion percentage, separate mastery self-assessment, test score history and notes.
- Subject/chapter dashboards, pending work, analytics, activity log, undo, JSON backup/restore, CSV export, dark/light themes and subject visibility.
- Local persistence using browser localStorage.

## Important syllabus note
The app labels the session as CBSE 2026–27 and annotates selected formative-only, periodic-assessment-only, project-only and map-only SST portions. Hindi lesson-level textbook selections and IT unit naming should be checked against the current official curriculum PDF and the NCERT edition supplied by the school before treating the index as an exhaustive official lesson checklist. The app does not connect to Supabase or provide cross-device cloud sync; keep JSON backups.

Official reference:
https://cbseacademic.nic.in/curriculum_2027.html
https://cbseacademic.nic.in/SQP_CLASSX_2026-27.html
