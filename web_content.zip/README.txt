StudyHub AI + Admin Panel

WHAT'S NEW
- Real AI Assistant through a secure Node/Express backend.
- Admin Panel at /admin.
- Add Notes/chapters, recorded videos or Live Class links, and quizzes.
- Content is stored in studyhub-data.json on the server.
- Delete custom content from the Admin Panel.
- Existing built-in notes, 170 practice Q&A, quiz, games, search and progress remain.

SETUP
1. Install Node.js 20+.
2. Extract this ZIP.
3. Open a terminal in this folder.
4. Run: npm install
5. Copy .env.example to .env
6. Put YOUR OpenAI API key in .env (never put it in index.html).
7. Set ADMIN_PASSWORD to a strong private password.
8. Run: npm start
9. Open: http://localhost:3000
10. Admin panel: http://localhost:3000/admin

ADDING CONTENT
- Notes: choose Note / Chapter, enter title/subject/theory, Publish.
- Live/recorded class: choose Recorded / Live Class and paste the approved video/live URL.
- Quiz: choose Quiz and enter a JSON array of question objects. For example:
  [{"q":"2+2?","options":["3","4","5","6"],"answer":1}]

IMPORTANT
- Do not send your API key or admin password in chat.
- The included practice questions are generated practice content, not automatically verified official PYQs.
- For production use, deploy the Node backend on a server and keep .env secret.
