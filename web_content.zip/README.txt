AL FAJR FURNITURE BUSINESS APP
No billing included.

Features:
- Dashboard
- Customer management
- Furniture orders with status
- Sofa repair job tracking
- Product/service list
- Call/WhatsApp contact
- Local browser storage (data stays on the device/browser)

Open index.html in Chrome on Android. Use Chrome menu > Add to Home screen for an app-like shortcut.
