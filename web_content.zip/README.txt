BMT SMART ASSISTANT v2.0 — PWA OFFLINE-FIRST (PAKET SUMBER)

ISI PAKET
- index.html: aplikasi utama
- manifest.webmanifest: konfigurasi PWA
- sw.js: service worker/cache offline

CARA MENJALANKAN DI ANDROID
1. Ekstrak ZIP.
2. Upload ketiga file ke hosting HTTPS (misalnya Netlify) dengan index.html di root.
3. Buka URL HTTPS di Chrome Android.
4. Pilih menu ⋮ > Instal aplikasi / Tambahkan ke layar utama.
5. Buka sekali saat online agar service worker menyimpan shell aplikasi.

PENYIMPANAN
- Database utama menggunakan IndexedDB browser, bukan localStorage.
- Data tersimpan di profil browser/perangkat yang sama dan dapat digunakan offline setelah aplikasi dimuat melalui HTTPS.
- Backup manual menghasilkan file JSON; restore mengganti isi database lokal setelah konfirmasi.
- Dokumen yang diunggah disimpan sebagai data URL di IndexedDB. Kapasitas bergantung pada browser/perangkat.

FITUR YANG SUDAH DISEDIAKAN DALAM V2
- Dashboard ringkasan harian dan saldo kas indikatif per kategori.
- Database nasabah gabungan, pencarian, edit, profil, upload banyak gambar/PDF dan preview.
- Slip tabungan massal: daftar nasabah aktif, input nominal, hitung total, cegah duplikasi dasar, validasi saldo untuk penarikan.
- Transaksi tabungan satuan, penarikan, angsuran sederhana, riwayat dan pembatalan dengan audit log.
- Administrasi buku dengan status dibayar dan diserahkan ke accounting.
- Kas per kategori dan serah terima yang mengurangi saldo berdasarkan alokasi kategori.
- JU multi-baris, hitung debit/kredit dan hanya menyimpan jurnal seimbang.
- Denominasi pecahan uang, total otomatis, simpan dan tautan referensi nomor JU (perbandingan memakai total debit JU).
- Kunjungan, catatan/pengingat, laporan ringkas, cetak/PDF via dialog print, ekspor CSV.
- Backup dan restore JSON.

BATASAN PENTING — BELUM BOLEH DIANGGAP SISTEM OPERASIONAL RESMI
1. Belum ada backend/cloud, sinkronisasi multi-perangkat, atau antrean sinkronisasi.
2. Belum ada PIN/login, enkripsi database/backup, atau penguncian otomatis.
3. Dokumen tersimpan lokal tanpa enkripsi. Jangan masukkan NIK, KTP, KK, akad, jaminan, atau data rahasia nasabah sebelum keamanan ditambahkan dan disetujui lembaga.
4. Belum ada modul jadwal/akad pembiayaan lengkap, perhitungan sisa kewajiban sesuai akad, angsuran massal, atau kalender jatuh tempo.
5. Belum ada master akun/JU buku besar, attachment jurnal, reversal akuntansi formal, atau pembandingan denom terhadap nilai kas spesifik JU yang dipilih. Perbandingan saat ini memakai total debit jurnal yang direferensikan.
6. Belum ada kategori uang lainnya yang bisa diinput terpisah dari serah terima, foto bukti serah terima, maupun tanda tangan penerima.
7. Laporan PDF dibuat melalui fitur cetak browser; belum ada generator PDF/Excel khusus.
8. Pengujian browser otomatis lintas perangkat belum dilakukan. Uji terlebih dahulu dengan data dummy, backup, restore, dan mode pesawat.
9. PWA bukan APK native. Untuk APK diperlukan proses pembungkus Android (misalnya Trusted Web Activity/Capacitor) dan penandatanganan terpisah.

PENTING
Aplikasi ini adalah asisten pencatatan pribadi, bukan pengganti sistem resmi BMT. Angka saldo dan kas merupakan hasil perhitungan atas data yang dimasukkan dan bukan verifikasi kas fisik. Selalu cocokkan dengan bukti dan prosedur resmi BMT. Jangan menganggap data tersinkronisasi: versi ini hanya menyimpan data lokal pada browser/perangkat.
