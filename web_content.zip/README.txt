PHIERRI PANEL - projeto Android

Este ZIP contém o projeto-fonte Android que abre a interface HTML em um WebView.
O painel é demonstrativo: os controles não se conectam ao jogo nem implementam Aimbot/ESP real.

Como gerar o APK:
1. Abra o projeto PHIERRI_PANEL no Android Studio.
2. Aguarde o Gradle sincronizar e instalar os componentes de SDK solicitados.
3. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
4. O APK de teste normalmente aparece em app/build/outputs/apk/debug/app-debug.apk.

Requisitos: Android Studio atualizado e Android SDK Platform 35 instalado.

Nota: foi incluído app/src/main/assets/resources.dat como recurso de preenchimento não executável. Ele não adiciona funcionalidades; serve apenas para aumentar o tamanho do pacote final. O tamanho final do APK pode variar conforme o modo de compilação e compressão.
