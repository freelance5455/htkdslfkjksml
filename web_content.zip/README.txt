GAME FILE LAB V1.1
Versão simplificada para facilitar a conversão em APK por ferramentas HTML-to-APK.

- Apenas index.html.
- Sem bibliotecas externas.
- Sem imagens externas.
- Sem chamadas de internet.
- Seleção e visualização local de arquivos.
- Compatível com projetos próprios ou arquivos para os quais o usuário tenha autorização.

Acesso a pastas privadas de outros aplicativos depende das permissões e limitações do Android.
