A1 Classes - Fixed Mobile Web ZIP

IMPORTANT: This ZIP is structured for Android WebView APK builders that expect web/index.html.
Upload this ZIP to your HTML-to-APK / ZIP-to-APK builder.

Entry file: web/index.html
Assets: web/a1_logo.png

Demo Admin login:
Username: admin
Password: 1234
