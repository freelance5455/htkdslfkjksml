TICKETVAULT V3 — MULTI-ID PDF IMPORT EDITION
==============================================

WHAT THIS UPDATE DOES
- Reads EVERY ticket ID on EVERY selectable-text PDF page (not just the first ID per page).
- Creates one permanent database record per unique ID.
- Assigns sequential roll numbers (000001, 000002, ...).
- Generates and stores an individual QR image for every ticket.
- Search by ticket ID, roll number, file name, and filters; open a record to see its QR.
- Scan QR codes with the phone camera to find the matching record.
- Export PDF reports containing visible QR images.
- IndexedDB database remains id-vault-db / records to preserve compatibility with the earlier TicketVault app.
- Append-only: no edit, delete, or clear database action; imports and restores skip duplicates rather than overwrite records.

YOUR AWE PDF (100 RECORDS)
The project includes:
1. AWE_ID_QR_000001_000100.pdf — original uploaded PDF.
2. AWE_100_Ticket_Register.pdf — converted register with roll number, ID, and a visible QR for each ticket.
3. AWE_100_Tickets_Import.json — ready-to-restore JSON containing all 100 database records and their QR PNG images.

FASTEST WAY TO LOAD THE 100 TICKETS
1. Deploy the project folder to an HTTPS static host.
2. Open TicketVault in Chrome on Android.
3. Allow the app libraries and service worker to finish loading while online.
4. Open Backup & Restore.
5. Choose AWE_100_Tickets_Import.json and tap Restore / Merge.
6. The app adds the 100 records. Existing IDs are skipped; existing records are never overwritten.
7. Open All Tickets and search AWE-000001 or scan one of the QR codes.

ALTERNATIVE: IMPORT THE PDF DIRECTLY
1. Open Upload.
2. Select AWE_ID_QR_000001_000100.pdf.
3. Tap Import.
4. The importer finds all AWE-000001 through AWE-000100 across the five pages and creates one record for each.
5. Each record receives the next available sequential roll number and its own QR code.
Note: importing the same PDF again is detected as a duplicate. It does not create duplicate tickets.

ANDROID INSTALLATION
1. Extract the ZIP on your computer or Android file manager.
2. Upload all files while preserving their folder structure to an HTTPS static host.
3. Open the hosted index.html URL in Google Chrome.
4. Wait for external libraries to load and the service worker to cache the app shell.
5. Use Chrome menu > Install app (or Add to Home screen).
6. Keep the app in the same Chrome profile that contains your previous TicketVault database.

OFFLINE USE
- First load must be online so PDF.js, QRCode.js, jsPDF, Mammoth, and SheetJS can be cached.
- After successful initial load, open the installed app offline.
- Database/search/details/QR generation from cached app libraries can work offline.
- Camera scan requires HTTPS permission and browser BarcodeDetector support.
- Do not clear Chrome site data; that can remove the local IndexedDB database.

BACKUP & DATA PROTECTION
- Create a JSON backup regularly and copy it to a second safe location (Drive, USB, or computer).
- Test a backup by restoring it into a separate browser profile before relying on it.
- Restore is a merge: it adds records whose ticket IDs are not already present.
- The browser's local database is not a cloud database. Device loss or clearing browser data can destroy local records.
- Keep at least two independent backup copies.

PDF IMPORT LIMITATIONS
- Text-based PDFs are supported. This uploaded AWE PDF has selectable text and was checked to contain 100 unique IDs.
- Scanned/image-only PDFs need OCR and are not automatically read by this build.
- Word support is for .docx text extraction; Excel support reads workbook sheets. Other binary formats may be stored as attachments but cannot yield IDs unless their text is extractable.
- If a file has no matching IDs, the app reports that no ticket IDs were found rather than inventing IDs.

TEST NOTES
- Verified the supplied PDF has 5 pages and 100 unique IDs, from AWE-000001 to AWE-000100.
- Verified the converted register contains 100 ticket entries and visible QR code drawings.
- Verified the import JSON contains 100 unique IDs, 100 unique roll numbers, and 100 QR PNG data URLs.
- JavaScript syntax and physical Android/browser camera/offline behavior should be checked after deployment on the target device.


V3.2 CLEAR DATABASE FEATURE
Open Storage & Settings > Clear ticket database. The app displays a warning and asks you to type CLEAR before removing all ticket records, QR codes and stored file attachments from the IndexedDB records store. The app installation, offline app shell, theme preference and other browser settings remain. Export a JSON backup before clearing if you may need the records later.
