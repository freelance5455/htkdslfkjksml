ILOSTAN POJAZDÓW TRAKCYJNYCH

Uruchomienie:
1. Rozpakuj ZIP.
2. Otwórz index.html w przeglądarce.

Funkcje:
- ciemny interfejs wzorowany na dostarczonym projekcie,
- 8 kategorii pojazdów,
- dodawanie zdjęć z podglądem,
- zapis zdjęć i danych lokalnie w przeglądarce,
- wyszukiwanie,
- filtrowanie po kategorii,
- otwieranie zdjęcia w dużym rozmiarze,
- usuwanie zdjęć,
- eksport/import kopii zapasowej JSON.

Uwaga:
Dane są przechowywane lokalnie w przeglądarce. Jeśli przeglądarka ogranicza pamięć dla dużych zdjęć, używaj mniejszych plików lub regularnie wykonuj kopię zapasową.
