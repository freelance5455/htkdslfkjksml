LSB di general — v8 Professional Android-ready

New professional features:
- Edit and delete customers, orders, appointments and gallery designs
- Customer-linked order/appointment cleanup when a customer is deleted
- Backup all app data to a JSON file
- Restore a previous JSON backup
- Delete-all-data safety confirmation
- Currency-aware financial display
- Dashboard deposits and outstanding balances
- Compressed gallery images to reduce storage use
- Professional action buttons and cleaner management screens

Still intentionally local/offline:
- Data is stored on the device/app.
- Backup/restore is manual.
- No cloud sync or multi-user accounts yet.
- This ZIP is Android-ready source, not an APK.
