Clipzo Media Picker Fix

This build adds a visible Choose photo or video button, image/video previews, a Done confirmation step, and Publish. Photo posts accept images, Reels accept videos, and Stories accept either.

IMPORTANT: If the app is running inside an Android WebView/app-builder wrapper that does not implement the native file chooser (WebChromeClient.onShowFileChooser), HTML alone cannot open the Android gallery. Enable File chooser / media picker support in that builder or open this index.html in a browser that supports file inputs. This demo keeps selected media only in the current page session; publishing is local preview, not server upload.
