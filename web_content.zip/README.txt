Office Audit Checklist - APKForge project package

Import these files into APKForge as the web app source.
Pages:
1 Dashboard
2 Total Checklist
3 Daily
4 Weekly
5 Monthly
6 As Required
7 History / PDF / Settings

Seed checklist: 43 items. Categories color-coded: Daily blue, Weekly orange, Monthly purple, As Required yellow. Completed green, Pending red.
Daily, Weekly and Monthly statuses are period-based and reset automatically when the date/week/month changes. History is retained. As Required remains completed until manually reopened.
Includes Add/Edit/Delete, parent/sub-item fields, note field, history search/filter, print-to-PDF report, JSON backup/restore.
All records are stored locally in browser storage. Export backups regularly. The app does not sync across devices.
