BHAN GROUPS - ANDROID PROJECT

This project wraps the Bhan Groups HTML app inside a native Android WebView.
It includes the requested Tic-Tac-Toe game.

BUILD:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated APK on your Android phone.

IMPORTANT:
- The current chat/room feature remains a browser-local demo. Real phone-to-phone
  Zapya-style chat/file transfer requires a real networking/signaling/backend layer.
- The supplied photo is embedded in the HTML app as the logo.
