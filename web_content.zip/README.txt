TradeScope AI

Open index.html in a browser to see the app.
The Analyze button only works inside Claude (claude.ai artifact link).
For a standalone/APK version an Anthropic API key and a small backend are needed.
