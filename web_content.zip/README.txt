OFFLINE BILLING PRO v2
Features: customers, suppliers, ledgers, credit management, GST billing, products/stock, barcode/SKU fields, purchases, sales returns, expenses/cash ledger, reports, invoice print/save as PDF, backup/restore, offline local storage, PWA manifest.
Open index.html. For Android installation, serve the folder from HTTPS or package it in a WebView/TWA. Browser localStorage is device/browser-specific; use Backup regularly.
