Vosiqova Student 1.0 — yangi boshlang‘ich loyiha

Fayllar:
- index.html: ilova interfeysi va demo funksiyalar.

Yangi APK yaratish uchun index.html faylini HTML-to-APK servisiga yuklang. Bu ZIP APK emas. AI yordamchi, reyting va ayrim ma’lumotlar hozircha demo rejimida.

O‘qituvchilar bo‘limida fan ustiga bosilganda jadvaldagi o‘qituvchi ism-familiyasi ko‘rsatiladi. Telefon raqamlari keyingi versiyalarda, rozilik va tasdiqdan so‘ng qo‘shiladi.
