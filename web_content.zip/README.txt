INDIAN CAR DRIVING 3D - PLAYABLE PHONE PROTOTYPE
Created by Raushan

Open index.html in Chrome.
Press START.
▲ accelerate, ▼ brake, ◀ ▶ steer.
The road, camera perspective, traffic and player car move during driving.
