GAME ON LIVE — Parvej (Starter Project)

WHAT'S INCLUDED
- Responsive mobile-first cricket app UI
- Home screen, demo scoreboard, official streaming service links
- Login/signup screen mockup (DEMO ONLY)
- Owner credit: Parvej

IMPORTANT LIMITATIONS
- This is a web app starter, not a signed Android APK.
- Scores are placeholders; no live-score API is connected.
- Login/signup is only a front-end demonstration. It does not create secure accounts.
- Streaming buttons open official services. No pirated stream URLs are included.
- Availability and subscription rights depend on country and tournament.
- Do not collect real passwords until a secure backend/auth provider is integrated.

HOW TO OPEN ON ANDROID
1. Extract the ZIP on your phone.
2. Open index.html in a browser to preview.
3. To publish as a website, upload the files to a static hosting service.
4. To make an Android APK, wrap this web app in an Android project or use a trusted app builder. An APK must be built and tested separately.

NEXT DEVELOPMENT STEPS
1. Add licensed live cricket data API.
2. Add secure authentication backend.
3. Add authorized streaming/player integration only where the broadcaster permits embedding.
4. Build, test, and sign Android APK.
