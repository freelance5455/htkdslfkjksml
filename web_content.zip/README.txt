GM PAY - VERSION STABLE HTML
1. Ouvre index.html dans Chrome pour tester.
2. Pour créer un APK, importe index.html dans ton convertisseur HTML vers APK.
3. Cette version fonctionne hors connexion et garde les comptes dans le stockage local du téléphone.
4. Les dépôts/retraits sont une démonstration : aucun argent réel n'est transféré.
5. Le transfert entre utilisateurs fonctionne sur le même appareil/navigateur dans cette version.
6. Firebase et les paiements réels seront ajoutés dans une prochaine étape après validation de l'APK.
