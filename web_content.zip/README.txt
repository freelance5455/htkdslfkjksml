# Mini GPT + Ollama Cloud

## Қосу
1. Node.js 18+ орнат.
2. Осы папкада терминал ашып `npm install` орында.
3. Ollama Cloud API кілтін орта айнымалысы ретінде бер:
   - macOS/Linux: `export OLLAMA_API_KEY="СЕНІҢ_ЖАҢА_КІЛТІҢ"`
   - Windows PowerShell: `$env:OLLAMA_API_KEY="СЕНІҢ_ЖАҢА_КІЛТІҢ"`
4. `npm start` орында.
5. Браузерде `http://localhost:3000` аш.

API кілтін HTML-ге, GitHub репозиторийге немесе ашық сайтқа жазба.
Бұл жоба кілтті серверде сақтайды. Бұрын чатқа жіберілген кілтті қауіпсіздік үшін жаңарт.
