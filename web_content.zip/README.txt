Calculator app ZIP prepared for converters.
Theme matches the original palette: #ccd5ae background, #e9edc9 panel, #fefae0 display, #d4a373 buttons.
Brand: آرسام; creator credit: طراحی و توسعه توسط آرسام خانی.
Settings and History buttons are only at the top next to the brand name; bottom toolbar removed.
