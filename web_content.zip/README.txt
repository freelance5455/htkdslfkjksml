TERMINALE D — APPLICATION ANDROID

Cette version contient :
- accueil mobile
- 5 matières du PDF
- navigation par matière
- rubriques Cours, Exercices, Quiz et Tuteur IA
- interface de base du tuteur

Fichiers :
index.html
style.css
script.js

Étape suivante : connecter le vrai tuteur IA puis empaqueter le projet en APK.
