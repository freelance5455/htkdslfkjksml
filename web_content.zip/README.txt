CERrajería Pro - primera versión

Esta versión funciona como una aplicación web en un único archivo index.html.
Incluye:
- Nuevo presupuesto
- Coste de material + margen
- Mano de obra
- Desplazamiento
- Copias de llave
- IVA
- Cálculo automático
- Guardado local de presupuestos en el navegador

Para usarla en un móvil, abre index.html desde un servidor/web. La siguiente versión puede convertirse en PWA instalable y añadir clientes, catálogo de productos, PDF y datos del autónomo.
