KANTONG JAGOAN — PAKET ZIP UNTUK ZIPTOAPK
========================================

Isi paket:
- index.html berada di akar ZIP.
- css/app.css dan js/*.js adalah aset lokal.
- icon.svg adalah ikon sumber.
- Aplikasi menggunakan HTML, CSS, dan JavaScript murni, tanpa CDN atau backend.

CARA MEMBUAT APK DENGAN ZIPTOAPK
1. Unggah kantong-jagoan.zip ke ZipToApk.
2. Nama aplikasi: Kantong Jagoan
3. Orientasi: Portrait / Potret
4. Start page / halaman awal: index.html
5. Aktifkan penyimpanan WebView / local storage jika tersedia.
6. Internet permission tidak diperlukan untuk aplikasi ini.
7. Buat APK, pasang di Android, lalu uji tutup paksa dan buka kembali.

PENTING
- ZIP ini dibuat agar index.html berada di direktori akar.
- Data disimpan di localStorage perangkat. Hapus data aplikasi dapat menghapus catatan.
- Gunakan menu Profil > Salin cadangan secara berkala.
- Periksa izin APK hasil pembungkus sebelum dibagikan.
- PRD meminta uji pada HP Android nyata. Uji tersebut belum dapat dilakukan dari paket sumber ini.

CATATAN FITUR
Versi ini mencakup onboarding, tiga kantong, transaksi dasar, riwayat, target,
setoran target, pelajaran dan kuis, XP/level dasar, batas jajan, cadangan,
pemulihan, privasi, serta hapus data.
Beberapa fitur lanjutan dalam PRD belum termasuk versi ini: pembagian pemasukan
50/40/10 yang dapat diubah, filter tanggal riwayat, grafik ringkasan, misi
mingguan lengkap, streak dan seluruh syarat lencana, simulator bunga majemuk,
anggaran bulanan Senior, tema gelap, PIN, pohon tabungan, serta alur pencairan
target yang lengkap.
