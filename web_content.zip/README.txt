TRUE SUCCESS
============
Mobile-friendly prototype.

Features included:
- Login screen
- Dashboard and wallet
- Demo video reward (+ETB 5)
- Telebirr and CBE payment options
- Minimum withdrawal ETB 100
- Admin section placeholder
- Support number 0941595099

IMPORTANT:
This is a working front-end prototype, not yet a production money/payment system.
Real Telebirr/CBE transactions, secure admin authentication, user database,
video/ad network, and server-side withdrawal verification require a backend
and the appropriate provider integrations.
