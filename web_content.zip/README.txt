# JARVIS — pacote Site ZIP para APKForge

Este ZIP foi preparado para a opção **Site zipado** mostrada na captura de tela.

## Importante
- `index.html` está na raiz do ZIP, que é o requisito indicado pela mensagem da APKForge.
- O pacote é um protótipo web responsivo, não um projeto Android nativo Gradle.
- A interface apresenta os módulos e algumas interações locais.
- Não implementa ainda IA conectada, hotword contínua, bolha Android nativa, nuvem real de 10 GB, nem os editores profissionais completos.
- O reconhecimento de voz usa a API de fala do navegador quando disponível e após ação do usuário.

## Importação
1. Na APKForge, escolha **Site zipado**.
2. Selecione `JARVIS_APKForge_Site.zip`.
3. Toque em **Visualizar**.
4. Volte à tela anterior e escolha **Criar app**, se a visualização funcionar.

Se a ferramenta aceitar apenas `index.html` e recursos web, este pacote tem a estrutura esperada. Recursos Android nativos, como bolha flutuante sobre outros aplicativos e palavra de ativação em segundo plano, exigem implementação Android nativa separada.
