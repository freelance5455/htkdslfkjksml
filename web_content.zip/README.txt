Wedding Guests — Android-ready web app

The original app is self-contained in www/index.html: no external assets or libraries are required.
The HTML already uses IndexedDB with localStorage fallback for guest storage.

For Capacitor:
1. npm init -y
2. npm install @capacitor/core @capacitor/cli
3. npx cap init "Wedding Guests" "com.boukari.weddingguests" --web-dir=www
4. npx cap add android
5. npx cap copy android
6. npx cap open android

Build the APK/AAB from Android Studio.
