ZAMGRAM Web Starter
===================
Versi web app untuk layanan pembuat APK dari HTML/ZIP.

Cara:
1. Upload ZIP ini ke layanan yang menerima ZIP website dengan index.html di root.
2. Nama aplikasi: ZAMGRAM
3. Package name: com.zamgram.app
4. Build dan unduh APK.

Catatan jujur: ini prototipe tampilan. Login, upload media, story viewer/filter, chat realtime, reels player, pencarian, dan sinkronisasi Supabase belum aktif. Jangan gunakan sebagai aplikasi produksi. ZIP ini bukan proyek Flutter.
