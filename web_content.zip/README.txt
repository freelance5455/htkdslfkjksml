MFUMOH SCALPER ROBOT V2 - ANDROID DASHBOARD

This package contains an English-only mobile dashboard designed for conversion
with an HTML-to-APK builder.

IMPORTANT:
- This dashboard does NOT directly run an MT5 Expert Advisor on Android.
- The actual MFUMOH SCALPER ROBOT V2 EA runs inside MT5 on a desktop/VPS.
- To make the START/STOP, signals, account data and trade controls live,
  an MT5-to-API bridge must be configured.
- The current dashboard includes demo data so the interface can be tested.

HTML-TO-APK:
1. Open your HTML-to-APK builder.
2. Choose "Local HTML" / "Website files" / similar.
3. Select index.html from this folder (or upload the ZIP if supported).
4. Set the app name to: MFUMOH SCALPER ROBOT V2
5. Build the APK.
6. Install the APK on Android.

LIVE MT5 ARCHITECTURE:
Android APK <-> API/Bridge <-> MT5 EA <-> Broker/Market

Never rely on demo signals for real-money trading. Test the EA in the MT5
Strategy Tester and on a demo account before using real funds.
