Caneco - application Android (WebView)

1. Installer Android Studio (https://developer.android.com/studio).
2. Menu File > Open, puis choisir le dossier caneco-android.
3. Attendre la fin de la synchronisation Gradle.
4. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Le fichier est généré dans app/build/outputs/apk/debug/app-debug.apk.
6. Copier ce fichier sur le téléphone et l'installer
   (autoriser l'installation depuis une source inconnue).

Le contenu de l'application est dans app/src/main/assets/index.html.
Pour mettre à jour l'application, remplacez ce fichier par la nouvelle version.
