TAP AWAY ARROWS — FULL GAME

Open Tap_Away_Arrows_Full_Game.html in Chrome on Android or on a computer.

Included:
- 100 levels
- Tap-to-clear arrow gameplay
- 3 hearts
- Coins and bonus coins
- Hint button
- Reset button
- Sound toggle
- Progress bar
- Local save of level/coins/settings

This is a standalone browser game. No internet connection is required after the file is downloaded.
