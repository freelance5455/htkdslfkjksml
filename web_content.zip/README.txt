TECHYOLO LITE - APK FORGE
Use index.html as the website entry file.
One HTML file, no external libraries, no network requests, no remote fonts, no backend.
Features: Home, Reels, Music, Chat, Calls, Profile, Create, local video/reel preview.
Go Live is a demo only; real online accounts, calls, uploads and livestreaming need a backend.
