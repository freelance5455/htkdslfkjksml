SO TACTICS - CORRECCION ICONOS

- Humo: centrado y con forma de nube limpia.
- HE: explosión centrada, sin punto negro.
- Molotov y Flash: conservados.
- No se modificaron las coordenadas de los elementos del mapa.
