REGISTRO DE TRAZABILIDAD — PROYECTO HTML PARA CONVERSOR HTML A APK

Contenido:
- index.html: aplicación local.
- manifest.webmanifest: metadatos e iconos de aplicación web.
- icon-192.png e icon-512.png: iconos.

IMPORTANTE:
Este paquete es un proyecto web offline para un conversor que envuelve HTML en APK.
La persistencia usa IndexedDB del WebView/navegador, no SQLite nativo.
Antes de usar datos reales, probar:
1) crear un lote;
2) cerrar y volver a abrir la APK;
3) registrar una salida;
4) exportar copia JSON;
5) importar esa copia en otro teléfono y comprobar lotes e historial.

Para convertir: seleccionar este ZIP en la herramienta únicamente si acepta ZIP de proyectos HTML
(o extraerlo y seleccionar index.html si solicita un archivo HTML).

La copia de seguridad JSON debe transferirse por Zapya como archivo aparte.
La APK y la copia de datos son archivos diferentes.
