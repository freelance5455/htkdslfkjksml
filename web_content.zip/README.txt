ANSH GAMING STUDIO - BUILD 0.2

This is an improved 3D browser-game prototype.

CONTROLS
- Rotate phone to landscape. The game viewport is fixed to 16:9.
- Left joystick UP: move forward relative to the camera.
- Left joystick DOWN: move backward.
- Left/right: strafe relative to the camera.
- Drag the right side of the game screen to rotate the camera.
- ENTER CAR: get into / out of a nearby car.
- RUN: toggle running speed.
- PHONE: cheat codes, AGS tools, and city travel.

IMPORTANT
- This is a procedural 3D prototype, not a complete photorealistic GTA-scale game.
- Three.js loads from jsDelivr CDN, so an internet connection is required.
- APK conversion websites may package the game in a WebView; performance and compatibility depend on the converter and Android device.
