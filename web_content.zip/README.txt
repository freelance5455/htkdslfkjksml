Radha Rani Shop - Offline Demo
1. index.html is the complete offline shopping demo.
2. It uses no external website or remote web page, so it does not depend on appassets.androidplatform.net.
3. Open index.html in a browser to test it.
4. For an Android APK, import this folder/HTML into an Android WebView or app builder that supports local HTML assets.
