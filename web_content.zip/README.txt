SWADBRAMHA FOODS - HOTEL BILLING APP
1. Extract this ZIP.
2. Open index.html in Chrome to use the app.
3. To package as APK, use an HTML-to-APK builder that bundles local HTML assets (offline/local assets), not one that only loads a web URL.
4. Set the app's start page / launch file to index.html and enable JavaScript + DOM storage/localStorage.
5. This is an HTML app package, not an APK itself.
Features: item selection, veg/non-veg menus, veg/non-veg combos, rice/roti, packing charge, discount, total, save bills, add items, edit prices, WhatsApp share, local storage.
