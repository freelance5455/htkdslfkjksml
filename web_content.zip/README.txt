Kuvi Paachu Kathaya - Full Screen Pure Dark

Updated:
- All 131 song images rebuilt from the original Kuvi Christian Songs 2019 PDF.
- Each song now contains its complete content, including continuation on the next source PDF page.
- Original aspect ratio preserved; no fixed-height cropping.
- Song viewer remains vertically scrollable for long songs.
- Pinch-to-zoom and double-tap zoom remain available without visible zoom buttons.
- Pure Dark mode and existing app features retained.
