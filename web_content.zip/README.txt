MASENA MENTE — PROJETO PARA APK

O jogo está em www/index.html.

Para gerar o APK:
1. Instalar Node.js e Android Studio num computador.
2. Nesta pasta executar:
   npm install
   npx cap add android
   npx cap sync android
   cd android
   ./gradlew assembleDebug

No Windows:
   android\gradlew.bat assembleDebug

APK de teste:
android/app/build/outputs/apk/debug/app-debug.apk
