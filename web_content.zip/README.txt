NIHA AI - Character prototype
- index.html: মোবাইল-ফ্রেন্ডলি HTML UI
- niha-character.jpg: ব্যবহারকারীর দেওয়া আসল ছবি; কোনো পরিবর্তন করা হয়নি।

ZIP extract করলে দুটি ফাইল একই ফোল্ডারে রাখবে। APK builder-এ পুরো ZIP আপলোড করবে এবং entry/start page হিসেবে index.html নির্বাচন করবে (যদি অপশন থাকে)।

এটি এখনো demo UI, real AI নয়। নমুনা reply rule-based। Real AI-এর জন্য secure backend/API দরকার; API key কখনো HTML বা APK-তে সরাসরি রেখো না। ছবির মুখের সত্যিকারের lip-sync করতে আলাদা animation/rigging pipeline লাগবে। ফোনের অন্য অ্যাপের ওপর ভাসমান character-এর জন্য Android native overlay permission ও native development দরকার।
