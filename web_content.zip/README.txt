RISEUP MAX — FREE FITNESS RPG APP PROTOTYPE

Included:
- 4 app pages: Home, Workout, Progress, Profile
- XP and level-up system
- Daily quests
- Workout library
- Workout timer
- Streak, calories, minutes and workout tracking
- Weekly progress chart
- Badges
- Profile name + settings toggles
- Local device/browser save using localStorage
- Mobile-first dark gaming UI
- No paid subscription or external API required

Run:
1. Extract the ZIP.
2. Open riseup_max.html in Chrome.
3. Add it to the home screen if you want an app-like shortcut.

Note: This is a self-contained web app prototype, not a signed Android APK.
