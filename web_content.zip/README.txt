PHANTOM THE 70 DAY — Offline personal reader

Open index.html in a modern browser. Keep the app_assets folder beside index.html.
Features: 70 individual pages, page backgrounds, bookmarks, reading progress, per-page notes, journal, day tracker, font size, fullscreen, theme toggle, and bilingual interface labels.

IMPORTANT: This build preserves the original Bengali book text. English interface labels are included, but the complete English translation of all 70 book pages is not yet included. Do not treat English mode as a translated book.

This is an HTML offline app package, not a compiled Android APK.
