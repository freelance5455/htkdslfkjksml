Hadi Engine Tuning — Offline Edition
=====================================
Entry point: index.html
Storage: browser localStorage bundled in the Android WebView.
No external libraries, CDNs, APIs, modules, or network calls.

ZIP TO APK REQUIREMENTS:
- index.html must be at the root of the ZIP
- all paths are relative
- scripts are classic <script src>, not modules
- this project is intentionally plain HTML/CSS/JS for compatibility
