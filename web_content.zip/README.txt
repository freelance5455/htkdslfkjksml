Fellah Android + Firebase
Package: com.fellah.agriculture
Google Services plugin: 4.5.0
Firebase BoM: 34.19.0
Firebase Auth + Firestore included.

ضع google-services.json داخل:
app/google-services.json

ملاحظة: ملف google-services.json يجب تنزيله من مشروع Firebase الخاص بك؛ لم يتم اختراعه أو تضمينه.
