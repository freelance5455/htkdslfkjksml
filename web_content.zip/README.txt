తెలంగాణ ప్లాట్స్ — mobile-first prototype

index.html ను Chromeలో open చేస్తే యాప్ prototype కనిపిస్తుంది.
ఇందులో Home, search UI, location chips, venture listings, price/size,
verified badge, Call, WhatsApp మరియు RERA/approval section ఉన్నాయి.

గమనిక: ప్రదర్శన కోసం మాత్రమే sample venture data మరియు placeholder contact number ఉన్నాయి.
Production app కోసం real listings, RERA verification workflow, database, admin panel,
maps, authentication మరియు Play Store build జోడించాలి.
