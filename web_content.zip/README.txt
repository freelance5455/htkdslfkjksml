KAREN V5 — MODO ECONÔMICO

Esta versão foi preparada para você continuar desenvolvendo a Karen sem precisar gastar dinheiro agora.

O que funciona sem API paga:
- Conversa básica offline com respostas variadas.
- Nome/apelido salvo no aparelho.
- Hora e data pelo relógio do aparelho.
- Cálculos matemáticos simples.
- Conversões de comprimento, massa e volume.
- Ajuda e informações sobre o próprio modo econômico.
- Histórico automático local.
- Voz para texto e texto para voz (dependendo do WebView/permissões).
- Regra fixa de desenvolvedor oficial: Marcos.

IA real continua opcional:
- O painel Configurar IA permanece disponível.
- Se uma chave/API compatível for adicionada, a Karen pode usar o modelo conectado.
- Para um APK distribuído publicamente, não embuta uma chave secreta no aplicativo; use um backend/proxy.

Importante: o modo econômico não é um modelo de IA completo. Ele evita respostas inventadas e avisa quando uma pergunta exige conhecimento externo.
