ASHEN SPARTAN — GHOST OF VENGEANCE V2

Contenu :
- index.html à la racine : application autonome HTML/CSS/JavaScript.
- README.txt : instructions.

Utilisation :
1. Décompresse le ZIP.
2. Ouvre index.html dans un navigateur ou importe le ZIP dans ton convertisseur site-vers-APK.
3. Pour les réponses IA réelles, configure dans Paramètres l'adresse HTTPS d'un serveur compatible POST /chat.

Réponse serveur attendue :
{ "reply": "Réponse de l'assistant" }
ou
{ "response": "Réponse de l'assistant" }

Sans serveur connecté, l'interface fonctionne en mode démonstration. La génération réelle d'images ou de vidéos nécessite un service de génération relié au serveur.
Les clés saisies sont conservées localement dans le navigateur ; pour une application publiée, il est plus sûr de les conserver côté serveur.
