TIKTHEME STUDIO - PHONE APK BUILD PACKAGE

This is a standalone offline web app.

Recommended process:
1. Upload the contents of this ZIP to a browser-based HTML-to-APK/PWA wrapper.
2. Set the start page to index.html.
3. Build an Android APK.
4. Download and install the APK on your Android phone.

The app does not require TikTok login and does not send the user's designs to a server.
It creates 1080x1920 PNG backgrounds with multiple styles, custom text, randomization,
and an optional uploaded image.

IMPORTANT:
The app creates artwork. TikTok itself controls whether and how a custom profile
background/banner can be applied to an account.
