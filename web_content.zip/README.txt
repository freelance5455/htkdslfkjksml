FlameSpeed ClimeSpeed APS - V0 prototype
Offline-first demonstrator. Fake data only. No production Dolibarr connection.
Entry point: index.html
