GONDAL DIRECTORY — DIRECT GOOGLE SHEETS VERSION

This ZIP contains a standalone web app page that reads the Google Sheet directly. It needs no Apps Script code. It must still be opened from a web address (HTTPS) for browsers to fetch Google Sheets data; opening the file in ChatGPT's Android preview may fail.

Source:
Spreadsheet ID: 18gizMssw7YqadIWJbQ0cczSlrBY_rj3E281Wp38QFo4
Worksheet gid: 1825938974

IMPORTANT:
1. Google Sheet must allow public viewing ("Anyone with the link — Viewer") for a no-login public directory.
2. This ZIP is the app source, not a published internet URL. I cannot publish a website on your behalf without a hosting/account authorization.
3. Review the sheet carefully before making it public. Do not publish confidential or sensitive customer data. The code hides some columns based on header names, but that is not a substitute for access control.
4. The app refreshes every 60 seconds while open and visible. New/deleted rows and columns appear after refresh.
