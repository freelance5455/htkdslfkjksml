DG GAMES — ADMIN PANEL (alag app)
=================================
Sirf admin ke liye. Players ko yeh zip mat do.
Zip ke andar "index.html" root mein hai, isliye kisi bhi APK builder / hosting par seedha kaam karti hai.

LOGIN
-----
Email: nabeeleditsofficial@gmail.com
Password: aap ko chat mein bataya gaya hai.
Login ke baad admin panel mein Dashboard -> "My account" mein password badal lo.

Pehli baar login par Ludo multiplayer game khud install ho jata hai.

ADMIN PANEL MEIN KYA HAI
- Dashboard: Website ON/OFF, App ON/OFF, announcement, stats, password change.
- Games: naya game, edit, hide/show, delete, "Update Ludo".
- Users: sab members, suspend / restore.
- Support: messages ka jawab, close, delete.
- Content: contact details, About, Rules, FAQ.

APK BANANE KE TAREEQE
- "Website to APK" builder: yeh zip seedha upload karo (App name: DG GAMES Admin, icon: icons/icon-512.png).
- PWABuilder: zip ki files HTTPS hosting par rakho -> pwabuilder.com -> Android.
- Internet permission ON rakho.

Security: admin ki taqat Supabase ke server-side rules par hai — koi aam user is panel se kuch change nahi kar sakta.
