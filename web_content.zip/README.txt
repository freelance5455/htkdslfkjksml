ALIvanta Medicine Intelligence
-----------------------------
New standalone interface for the ALIvanta medicine reference app.

Features:
- Completely new visual design, separate from the earlier WahidMedX interface.
- Exact brand/formula matching.
- Single-ingredient searches exclude combination products.
- Combination searches match the complete ingredient set and strength.
- Established-company and famous-brand ranking signals.
- Offline IndexedDB catalogue sync from the public Indian Medicine Dataset.
- Voice search where supported.
- Public verification links for medicine sources.
- No external font or JavaScript dependency; intended to be WebView-friendly.

ZIP ROOT:
index.html must remain at the root when uploading to an HTML-to-APK builder.

NOTE:
The catalogue download requires internet access. Clinical details and prices should be verified against current product sources.
