SEVAL RUNNER INDIA HTML5 ZIP
Select this ZIP in your ZIP-to-APK app. IMPORTANT: ZIP must contain index.html at the top level. This is a lightweight HTML5/WebView edition, not the Unity 3D project. For native Unity Android builds, open the separate Unity project in Unity Hub and build for Android.
