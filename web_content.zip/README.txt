BachPlan PWA – reparierte Version

Cette version corrige la navigation et inclut les fichiers nécessaires à une PWA (icône, manifeste, cache hors ligne).

IMPORTANT : pour l’installer comme une application autonome sur Android, les fichiers doivent être publiés sur une adresse HTTPS. Une fois publiée : ouvre l’adresse dans Chrome > menu ⋮ > « Installer l’application » ou « Ajouter à l’écran d’accueil ». Elle s’ouvrira alors dans sa propre fenêtre, sans barre d’adresse Chrome.

Le ZIP seul ne peut pas installer une application Android ni créer un lien HTTPS public. Il ne s’agit pas d’un APK Play Store.
