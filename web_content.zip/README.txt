ENGLISH AFAAN OROMOO - prototype
1. Extract the ZIP.
2. Open index.html in Chrome.
3. The prototype works offline after extraction.
4. The next version can add lessons, quizzes, scores, audio and an Android APK wrapper.
