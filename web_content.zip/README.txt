STUDY BUDDY — FIREBASE CLOUD SYNC EDITION

Files
- index.html (project entry page at ZIP root)
- style.css, app.js
- firebase-config.js (paste your Firebase web app config here)
- cloud.js (email/password authentication + per-user Firestore sync)
- firestore.rules (security rules to publish in Firebase)
- README.txt

IMPORTANT
The ZIP is prepared for Firebase, but it will NOT sync online until you create
your own Firebase project and add its web configuration. This project does not
contain a live server account or your private credentials.

SETUP FROM AN ANDROID PHONE
1. Open https://console.firebase.google.com/ in Chrome and sign in to Google.
2. Create a Firebase project.
3. In Project settings, add a Web app and copy the Firebase config.
4. Extract this ZIP using your phone's file manager.
5. Open firebase-config.js in a code editor and replace each placeholder with
   the values from your Firebase Web app config. Do not add a service-account
   key or private server key.
6. In Firebase Console > Authentication > Sign-in method, enable Email/Password.
7. In Firebase Console > Firestore Database, create a database.
8. Open Firestore Rules, replace the rules with the contents of firestore.rules,
   then Publish.
9. Host the website on an HTTPS host (for example Firebase Hosting or another
   static web host). Firebase Authentication and Firestore are intended to run
   from a hosted web origin; opening index.html as a local file may not work.
10. Open the hosted site, go to Profile & Settings, create an account, then sign
    in. Your profile, notes and planner tasks sync to that account.

DATA & SECURITY
- Passwords are handled by Firebase Authentication, not saved in Firestore.
- Study Buddy data is stored in Firestore at users/{your-auth-uid}.
- Rules restrict each user to their own document.
- A local browser copy is also kept as a convenience.
- Never share your password or Firebase service-account credentials.
- For a real public deployment, consider enabling email verification and
  configuring Firebase authorized domains and billing/usage alerts.

This is a client-side starter integration, not a preconfigured live backend.
