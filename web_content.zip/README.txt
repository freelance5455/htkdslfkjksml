LINE BALANCING APP
Files:
- index.html : main app
- Operator_Attendance_50.xlsx : attendance test file
- Operator_Skill_Efficiency_50.xlsx : operator operation/SAM/efficiency test file

Note: The current HTML prototype's Excel reader is CSV-oriented, so XLSX import may still need the SheetJS/XLSX library added for true .xlsx parsing.
