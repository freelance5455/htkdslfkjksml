Al Fadl Admin APK package
Entry file: index.html
Upload this ZIP to a ZIP-to-APK builder.
Note: the admin uses Supabase and requires internet for database/auth.
