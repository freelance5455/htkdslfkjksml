This ZIP is for a ZIP-to-APK converter that accepts a website project.
IMPORTANT: index.html is at the root of the ZIP, as requested by the converter.
It contains five offline profile cards and a search field.
If your converter asks for a website ZIP, upload this file.
