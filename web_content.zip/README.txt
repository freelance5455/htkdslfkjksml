# Mi Horario Diario — PWA

## Cómo instalarla desde Chrome en Android

1. Sube TODA esta carpeta a un hosting que use HTTPS.
2. Abre la dirección de `index.html` desde Chrome.
3. Usa el menú de Chrome y selecciona **Instalar aplicación** o **Añadir a pantalla de inicio**.
4. La app se abrirá en modo independiente.

## Importante
No funciona como PWA instalable abriendo `index.html` directamente desde el almacenamiento del teléfono (`file://`).
El Service Worker necesita un sitio servido por HTTPS (localhost también sirve para pruebas).

## Archivos
- `index.html` — página del horario.
- `manifest.json` — configuración de instalación.
- `sw.js` — funcionamiento offline/caché.
- `icons/` — iconos de la aplicación.
