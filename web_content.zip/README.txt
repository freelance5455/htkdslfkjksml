RAYAN — prototip i përditësuar me WhatsApp

Numri i destinacionit WhatsApp është konfiguruar në format ndërkombëtar: +355 696 580 359.

Si ta provosh:
1. Nxirr (Extract) skedarët nga ZIP-i.
2. Hape index.html në një shfletues Android.
3. Shto produkte në shportë, plotëso emrin/telefonin/adresën dhe shtyp “Porosit në WhatsApp”.
4. Paneli demo: përdoruesi rayan; fjalëkalimi RayanDemo2026!

Kufizime të rëndësishme:
- Kjo është ende një prototip web/PWA, jo APK e publikuar në Google Play.
- Për instalim si PWA zakonisht duhet ta vendosësh faqen në një host HTTPS dhe pastaj të zgjedhësh “Add to Home screen”.
- Produktet ruhen vetëm në shfletuesin ku i shton. Nuk ka databazë online të përbashkët, sinkronizim admin-klient, ose menaxhim real të porosive.
- Fjalëkalimi i panelit është demonstrues dhe nuk është i sigurt për përdorim real.
- Porosia hap WhatsApp me mesazhin e përgatitur; klienti duhet ta dërgojë vetë mesazhin.
