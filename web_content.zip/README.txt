MyApp Android Studio Project

Open this folder in Android Studio and let Gradle Sync finish.
Then press Run to install/run it.

APK:
Build > Build App Bundle(s) / APK(s) > Build APK(s)

Original HTML:
app/src/main/assets/index.html
