Child Health Clinic - AppForge PDF FIX V4

This version uses the same Blob + anchor download pattern that is already working for CSV export in the app. The PDF is generated as a standards-compliant ASCII PDF and is delivered with a generic downloadable MIME type so AppForge can save it as a .pdf file.

Import this folder into AppForge and build the app. Use Save PDF and then check the phone Downloads folder.
