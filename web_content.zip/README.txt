علوم پنجم | پروژه آماده Android Studio

1) Android Studio را نصب کن.
2) این پوشه را با Open باز کن.
3) صبر کن Gradle پروژه را Sync کند.
4) از منوی Build گزینه Build APK(s) را بزن.
5) APK در مسیر app/build/outputs/apk/debug/ ساخته می‌شود.

نکته: برنامه محتوای HTML را کاملاً آفلاین از assets اجرا می‌کند.
