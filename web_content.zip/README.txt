ACC V4 – updated personal accounts PWA package

Updates included:
- Removed the dashboard top-right settings icon.
- Username field in Settings and username display at the top-left.
- Financial month start day and opening balances remain configurable.
- Recent transactions are hidden initially; tap an account card to view its transactions.
- Optional PIN lock (off by default; enable it in Settings > Profile).
- Monthly report moved to Settings and remains available from the Reports bottom tab.
- Bottom navigation simplified to Home, Reports and Settings.
- Existing localStorage key and transaction structure are preserved.
- Existing themes, category management, budgets, editing, backup and CSV export retained.

IMPORTANT:
- This is a Progressive Web App (PWA) website package, NOT an APK. Host it on HTTPS and install from Chrome (Add to Home screen / Install app).
- ACC AI chat interface is included, but online AI replies still require a secure backend at /api/assistant. This package does not include an AI server or API key. Never place an API key in index.html or other public files.
- Before replacing an existing live version, use Settings > Security & backup > Download backup. Keep the same website origin so existing browser data can remain available.
