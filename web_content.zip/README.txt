StapelCam HTI web prototype. Entry point: index.html. Prototype only; height inputs are manual, not automatic photo measurement.
