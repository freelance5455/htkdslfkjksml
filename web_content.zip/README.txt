JAI SHREE KAPDA DUKAN — ANDROID APP

This is an Android Studio project that packages the website into a mobile app using Android WebView.
It includes the same responsive website, WhatsApp, Call, Instagram and Google Maps actions.

HOW TO BUILD APK:
1. Install Android Studio.
2. Open this folder: Jai_Shree_Kapda_Dukan_Android_App
3. Let Gradle sync.
4. Choose Build > Build APK(s).
5. The debug APK will be under:
   app/build/outputs/apk/debug/app-debug.apk

BEFORE PUBLISHING:
- Replace the demo gallery visual with real store/product photos.
- Confirm phone/address/owner/policy.
- Replace Instagram URL in app/src/main/assets/script.js.
- For Play Store release, create a proper app icon, privacy policy, signed release build and store listing.
