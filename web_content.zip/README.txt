D3R ORACLE — pacchetto HTML per APKForge
==========================================

CONTENUTO
- index.html: applicazione completa in un unico file.
- assets/: cartella riservata a eventuali icone e risorse.
- README.txt: queste istruzioni.

IMPORTAZIONE IN APKFORGE
1. Estrai o importa direttamente questo ZIP, se la tua versione di APKForge supporta ZIP di siti web.
2. Se APKForge chiede il file iniziale, seleziona index.html.
3. Se chiede una cartella web/root, seleziona la cartella che contiene index.html.
4. Imposta il nome app: D3R ORACLE.
5. Imposta orientamento portrait e abilita JavaScript/local storage nel WebView, se presenti queste opzioni.
6. Genera l'APK.

FUNZIONI INCLUSE
- Profilo locale: nome, data di nascita, ora e luogo facoltativi.
- Numerologia: percorso di vita, anno personale e cicli mensili/giornalieri.
- Segno zodiacale solare.
- Stima della fase lunare.
- Mazzo simbolico completo di 78 carte.
- Estrazione casuale singola e stesa di tre carte.
- Letture giornaliere, mensili e annuali.
- Archivio locale delle letture.

NOTE IMPORTANTI
- È un'app web offline: non richiede librerie esterne o connessione Internet.
- I dati sono salvati nel localStorage del WebView. Se si cancellano i dati dell'app o si disinstalla, potrebbero andare persi.
- Per mantenere la privacy, non è dichiarato alcun accesso a server.
- Ascendente, case astrologiche e transiti non sono inclusi in questa prima versione.
- La fase lunare è una stima basata sul ciclo medio, non un'effemeride astronomica di precisione.
- Le letture sono simboliche e di intrattenimento/riflessione, non predizioni scientifiche del futuro.
