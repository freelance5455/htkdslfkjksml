NDAPHUNZIRA V97

Based on V96.

Change in V97:
- When a cross-reference verse is tapped, the top Book / Chapter / Verse selector is now synchronized to the opened cross-reference verse.
- The selected verse remains highlighted and centered without re-render flicker.
- All V96 cross-reference data and features are preserved.
