1) Download https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js and save it next to index.html as three.min.js (for fully offline play).
2) Zip the folder (index.html at the zip root) and use a website-to-APK tool, or put it in a Capacitor / Android Studio WebView project.
3) Landscape: in AndroidManifest.xml set  android:screenOrientation="sensorLandscape"  on the activity (Capacitor: same). Most converters have a "Landscape" option.
