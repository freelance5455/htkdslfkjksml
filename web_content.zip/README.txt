ABDULSAMAD FAMILY RECORD — ONLINE APK BUILDER

Upload this ZIP to the ZIP-to-APK website.

Features:
- Father at top left and mother at top right; both names, descriptions, and photos can be edited.
- Eight existing family records with the previously corrected final birth time.
- Add/edit/delete members, add photos, search records, export/import backup.
- Uses local IndexedDB storage in the app's WebView.

The ZIP contains family names and birth information. An online build service may process uploaded files. Upload only if comfortable with that. Test photo upload and backup after installing. Export backups before clearing app data or uninstalling.
