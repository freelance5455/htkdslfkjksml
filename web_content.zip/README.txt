FLOORA — LANDSCAPE EDITION

This package contains the redesigned HTML app and this README.

Design direction: warm ivory, forest green, muted sage, and restrained harvest-gold accents, with a subtle rural landscape illustration in the dashboard hero. The design aims for calm contrast and clear readability rather than bright decorative colours.

The existing app features and underlying JavaScript are preserved; this pass focuses on visual styling. Open the HTML in a browser or use your existing HTML-to-APK converter. After conversion, test navigation, forms, calendar, storage, dark mode, and notifications on the target Android device.

This is HTML source, not a compiled APK. It has not been physically tested on an Android device. Predictions are estimates, not medical advice. Local records remain on the device unless exported; exported backups may contain private information.
