# யாழ் பீனிக்ஸ் பாக்கு வாணிபம் – Offline App
இந்த தொகுப்பில் `index.html` உள்ளது. Android Chrome-ல் திறந்தால் Offline-ஆக பயன்படுத்தலாம்.
தரவுகள் localStorage-ல் சேமிக்கப்படும்; Backup பகுதியில் JSON backup/restore உள்ளது.
குரல் பதிவுக்கு browser microphone permission தேவை.
APK ஆக மாற்ற, Android WebView/Capacitor/WebView wrapper பயன்படுத்தலாம்.
