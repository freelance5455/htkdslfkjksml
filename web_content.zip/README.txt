NounouPilot — version hors ligne
- Interface vierge au premier lancement
- Données stockées localement sur l'appareil
- Aucun CDN ni ressource Internet requis
- Navigation avec bouton retour
- Zoom tactile désactivé
Pour HTML to APK : utiliser « Fichier ZIP vers APK ».
