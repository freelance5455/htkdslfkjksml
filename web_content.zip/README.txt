FaizTrack — encrypted personal finance planner

FILES
- index.html: complete single-file HTML/CSS/JavaScript app, ready as a local HTML app entry point for an Android WebView builder.

SECURITY DESIGN
- Financial data is encrypted before it is saved in localStorage.
- AES-256-GCM authenticated encryption; PBKDF2-SHA-256 password-based key derivation with 310,000 iterations and a fresh random salt and IV for each saved vault/backup.
- Password is not written to storage. The app needs it again after a full reload/restart.
- Exported backups are encrypted and require the export password to restore.
- Data is stored locally; this version has no cloud sync.

IMPORTANT LIMITS
- No app can guarantee that nobody can hack or access data. This protects stored records at rest but cannot protect against a compromised/unlocked phone, malicious code, screen recording, or access while the app is unlocked.
- If you forget your password and have no other copy that can be decrypted, your records cannot be recovered.
- Keep encrypted backups private and remember the password. Test restore with fake records before entering real finance data.
- Local browser/WebView storage can be erased by clearing app data or uninstalling. Export backups regularly.
- If upgrading from the previous FaizTrack version, the app will migrate its old local data into the encrypted vault when you create a password, then remove the old plaintext storage key. This assumes the old storage is available in the same browser/WebView origin.

BUILDING AN APK
1. Open https://www.webintoapp.com/ on your phone and review its current terms, privacy policy, and available plans before uploading anything.
2. Use the website's HTML/local-app ZIP workflow and upload this ZIP. index.html is at the ZIP root.
3. Configure the app name as FaizTrack. Use an appropriate app icon if desired.
4. Generate the APK, download it, and install it on your Realme 15T. Android may ask you to allow installation from that browser/file manager; only allow it for a builder and APK you trust, and turn the permission off again afterward.
5. Do not use real records yet. First test the checks in TEST_REPORT.txt.

This package contains source files only; it is not an APK and has not been installed on a physical phone.
