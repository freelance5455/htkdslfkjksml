Gemini AI Chat — API-connected frontend
=========================================

Included:
- index.html — complete app
- README.txt — setup notes

Setup:
1. Extract this ZIP.
2. Open/import index.html in your app builder or a modern browser.
3. Create a Gemini API key in Google AI Studio.
4. Paste the key into the Gemini API key field in the left sidebar.
5. Select an available Gemini model and send a message.
6. Attach PNG, JPG, or WEBP images (maximum 8 MB) for image prompts.

API connection:
The page sends requests to Google's Gemini generateContent REST API using the x-goog-api-key header. The selected model defaults to gemini-2.5-flash. Model access and availability depend on Google's current API offering and your key.

Security:
This is a browser-only demo. A key entered in a frontend page is not secret and may be exposed to anyone who can inspect the page or browser network traffic. Do not deploy this version publicly with a private API key. For public deployment, create a backend endpoint and store the key as a server-side environment variable. Do not send your API key to anyone.
