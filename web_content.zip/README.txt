WAWAWA TRADING JOURNAL — Versi pribadi

ISI:
- index.html: aplikasi jurnal trading
- logo.png: logo W milik pengguna

CARA MEMAKAI:
1. Ekstrak ZIP ke folder.
2. Pastikan index.html dan logo.png tetap berada dalam folder yang sama.
3. Buka index.html di Chrome atau browser modern.
4. Buat Trading Notes, Trade Journal, atau Post pribadi.
5. Tambahkan beberapa foto/screenshot dari galeri; foto bisa dibuka dan diperbesar.
6. Gunakan tombol panah di header untuk ekspor backup JSON. Pilih impor jika ingin memulihkan backup.

PENTING:
- Aplikasi ini versi web lokal, bukan APK dan bukan layanan cloud.
- Catatan dan gambar tersimpan pada penyimpanan browser di perangkat ini.
- Jangan hapus data browser sebelum membuat backup.
- Post adalah jenis catatan pribadi, bukan posting publik online.
