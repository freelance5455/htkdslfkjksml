GHULAM ALI COMMANDER AI — Free Starter App

Included:
- PMA daily routine
- 10-question basic intelligence quiz with score and explanations
- Customer reply templates in Roman Urdu, English and Urdu
- Income/expense tracker with net profit/loss calculation
- Task list and progress notes
- Local storage on the device/browser
- Basic offline support after first load

Important:
- This is a lightweight installable web app (PWA), not a signed APK.
- It does not include live AI chat, cloud sync, or push notifications.
- Your data stays in this browser/device storage. Clearing browser data may remove it.
- PMA Long Course 159 eligibility and dates must be checked against official recruitment announcements.

Quick test:
1. Open index.html in a modern browser.
2. For install-to-home-screen, host these files on an HTTPS site, then use the browser menu > Add to Home screen / Install app.
3. To build a native Android APK, these web files need to be wrapped with a tool such as Capacitor or recreated in Android Studio.
