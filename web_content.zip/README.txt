Child Health Clinic – AppForge PDF download fix

This version avoids blob: URLs and automatic/programmatic downloads. It creates the PDF as a data URL and presents a real user-tappable Android WebView download link. This is intended to work with AppForge's Web2App file-download handling.

Import index.html into AppForge and rebuild/run the app. Generate the report, then tap the visible “Save PDF to Downloads” button.
