Duty Calendar Android project

This is an Android Studio project wrapper around your index.html.

Build APK:
1. Install Android Studio on a computer and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Debug APK output: app/build/outputs/apk/debug/app-debug.apk

Notes:
- JavaScript and DOM/localStorage are enabled.
- Android file picker support is enabled for HTML input type=file.
- Data stored in localStorage remains on this device unless app data is cleared or the app is uninstalled.
- This project has not been compiled/tested here; APK compilation requires Android SDK and Gradle.
