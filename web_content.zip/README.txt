NØVA — paczka interfejsu

Główny plik index.html znajduje się w katalogu głównym archiwum.
Zawiera ekran startowy NØVA, dashboard i galerię z albumami, koszem oraz lokalnym zapisem IndexedDB.

WAŻNE: aplikacja typu ZIP to APK musi obsługiwać WebView file chooser (onShowFileChooser), aby przycisk Dodaj mógł otwierać systemowy wybór zdjęć i filmów. Jeśli generator tego nie obsługuje, sam HTML nie może dodać tej funkcji. Wtedy należy użyć natywnego projektu Android z MainActivity obsługującą File Chooser.
