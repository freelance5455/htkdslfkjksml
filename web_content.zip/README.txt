ELAN - paquete web para APK

Estructura:
web/index.html

Carga index.html como archivo inicial de la aplicación.
