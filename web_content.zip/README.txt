ZOZO TOURNAMENT — starter website ZIP

Files:
- index.html: website structure
- style.css: responsive dark neon styling
- app.js: demo sign-in, tournaments, virtual coins and local admin controls

IMPORTANT:
- This is a front-end demo. Data is stored in the browser's localStorage.
- Demo admin username: zozoadmin. Create an account with that username to see the admin panel. The demo password is whatever you set during registration.
- This is NOT secure for a public production website. Real authentication, server-side admin roles, database, anti-cheat rules and moderation must be implemented before public launch.
- Tournament entry is free. Virtual coins are not redeemable for money. No deposits, cash withdrawals, betting, or payment processing are included.
- For a basic static APK wrapper, these files can be used as the website content. A ZIP-to-APK service may require index.html at the ZIP root.
