Max Call — 50 ta interfeys tili

Ilovada 50 ta til tanlash imkoniyati mavjud. 20 ta oldingi til va 30 ta qo‘shimcha til uchun interfeys matnlari kiritildi. O‘zbek tili birinchi va boshlang‘ich til bo‘lib qoladi.

Eslatma: bu loyiha ZIP fayli, APK emas. Tarjimalar sintaksis jihatdan tekshirilishi va Android qurilmada sinovdan o‘tkazilishi kerak. Ayrim tarjimalar tabiiylik yoki qurilma mosligi bo‘yicha qo‘shimcha tekshiruv talab qilishi mumkin.
