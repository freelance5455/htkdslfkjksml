AKILLI SAYAC KONTROL - ILK PROTOTIP

Bu ZIP, APKMaker.dev benzeri bir HTML/ZIP web-app paketine yüklemek için hazırlanmış basit bir HTML prototipidir.

İçerik:
- Telefon kamerasıyla fotoğraf çekme / galeriden fotoğraf seçme
- Sayaç numarası ve saha notu
- Telefon destekliyorsa Türkçe sesli okuma
- JSON inceleme kaydı indirme

ÖNEMLİ:
Bu sürüm gerçek yapay zekâ görsel analizi yapmaz. “Kaçak var/yok” kararı vermez.
Gerçek görsel analiz için bir görüntü analiz modeli/API'si veya telefonda çalışan uygun bir model entegre edilmelidir. API anahtarı bu ZIP içine konulmamalıdır.
