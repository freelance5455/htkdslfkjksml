NIVIL STEP 1 — Acode

Put your official logo at assets/logo.png.
Open index.html in Acode Preview.
Set DELIVERY_AREA at the top of script.js when your launch area is decided.
This is frontend-only demo code: localStorage is used for cart, login and demo orders.
No backend, real authentication, database, live tracking or real payment gateway is included yet.
Product photos currently use remote Unsplash URLs, so internet is required for them.
