PIXORA - Single File HTML App
================================

This ZIP contains a single index.html.

How to use on Android:
1. Extract the ZIP.
2. Open index.html in Acode or another HTML editor.
3. Preview it in a browser.
4. For APK, upload index.html/the extracted folder to an HTML-to-APK builder.

Included:
- Login/signup demo
- Home feed
- Stories UI
- Photo post upload
- Likes
- Comments
- Search
- Profile/edit profile
- Reels UI
- Messages UI
- Notifications UI
- Settings
- LocalStorage persistence
- Premium dark/VFX-style UI

IMPORTANT:
This version is a local/demo app. Accounts and posts are stored in the device's browser LocalStorage.
For real multi-user online accounts, cloud media, real-time chat, and cross-device posts, connect Firebase/Supabase backend.
Pixora is an independent brand and is not affiliated with Instagram or Meta.
