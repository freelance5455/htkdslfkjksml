NAVYUVA DURGA PUJA SAMITI — USER HISTORY & PDF FIXED

Admin User ID: 7905106011
Admin password (as configured in this project): Gyan@123
Firebase project: navyuva-durga-pooja-samiti

FIXES IN THIS VERSION
- Each account has a separate local receipt history.
- A normal user loads only cloud receipts whose createdBy matches their own User ID.
- Admin Dashboard can view and manage all cloud receipts.
- Receipt header includes a small Maa Durga image with explicit sizing.
- PDF Save first attempts a file download. If the Android APK/WebView blocks downloads, press OK in the prompt to open the print screen and choose “Save as PDF”.
- Firestore rules allow a user to increment only their own receiptSeq, create/read only their own receipts, and reserve all-receipt management for Admin.

REQUIRED FIREBASE SETUP
1. Open Firebase Console for project navyuva-durga-pooja-samiti.
2. Open Firestore Database > Rules.
3. Replace the existing rules with the complete contents of firestore.rules from this ZIP, then press Publish.
4. Confirm Authentication > Sign-in method has Email/Password enabled, because this app uses User ID + Password.
5. Test with one normal user: create a small test receipt, open its history, save PDF, then test a second user and confirm the first user's receipts do not appear.

IMPORTANT
- App code cannot change Firebase rules automatically. The included firestore.rules must be published in Firebase Console for privacy to be enforced server-side.
- The PDF print fallback depends on the APK/WebView allowing pop-ups and printing. If the builder blocks both downloads and printing, use a WebView/APK builder that supports file downloads and printing, or open the project in Chrome.
- Keep Firebase API/config values and Admin credentials private.
