PASHU SAATHI — FIRST PROTOTYPE

Included:
- Mobile-first polished UI
- Pashu Saathi logo
- Mobile number + OTP login flow (DEMO OTP: 123456)
- Add animal profile
- Animal details: name, type, breed, age, gender, color, milk/day, vaccination date, breeding/checkup date, notes
- Local browser storage
- Home dashboard with animal count, milk total, vaccination count
- PWA manifest + service worker
- ₹20 membership placeholder (payment is NOT connected yet)

IMPORTANT:
The OTP in this prototype is simulated. For real OTP login, connect a backend and an SMS/OTP provider.
The ₹20 payment button is a placeholder. Real payments should be integrated later through an appropriate payment provider and platform rules.
