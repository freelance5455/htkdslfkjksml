Char Rajibpur Government School - student database (works offline, no Claude needed)

Files: index.html (root), css/style.css, js/app.js, images/icon.svg, manifest.json
Test: open index.html in Chrome. First tap "Login" to create username/password.
Data is saved inside the phone/browser only (localStorage). Use the Backup button regularly.
