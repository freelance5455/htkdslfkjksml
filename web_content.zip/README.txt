COURSE LIBRARY — Android-friendly student organizer

WHAT IT DOES
- Three bottom actions: Library, + Add documents, Courses.
- Imports files into a central local library.
- Create custom courses.
- Assign one library document to one or several courses without duplicate entries.
- Search and rename files.
- Preview PDFs, images, and text files; download/open other file types in a compatible app.
- Export/import a backup JSON containing the courses and documents.
- Local-first storage; no account or cloud required.

IMPORTANT LIMITATIONS
- This is a first working web-app prototype, not a signed Android APK.
- To install it as an app icon and enable the offline shell reliably, host this folder on a free HTTPS static host (for example, GitHub Pages) then open its HTTPS URL in Chrome/Samsung Internet and choose Install app / Add to Home screen.
- Opening index.html directly from Downloads may not support reliable storage or installation in every browser.
- Files stay in the browser's local storage on that device. Export backups regularly; clearing browser data can delete them.
- PPT/PPTX files are stored and assigned but open through another compatible app, not rendered inside this prototype.
- The browser may impose storage limits for large files.

FILES
index.html — app
manifest.json — install metadata
sw.js — offline app shell
icons/ — app icons
