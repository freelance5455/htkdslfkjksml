NAMAMI HOTEL & RESTAURANT - COMPLETE BILLING SYSTEM

Files:
- Namami_Hotel_Complete_Billing_System.html : Open this file in Chrome.

Sounds:
- Adding an item or changing quantity plays a short clear click tone.
- Successfully saving a bill plays a three-tone confirmation sound.
- Sounds are generated in the browser and do not require internet/audio files.
- Device/browser volume must be on. Some browsers may require the first tap to enable audio.

Important:
- Records are stored locally in the browser on this device; export a backup before replacing your old file.
- Test printing and due-payment workflow on your device before relying on it for daily accounts.
