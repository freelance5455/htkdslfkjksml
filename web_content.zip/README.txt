StudyFlow Android project

This project wraps your existing StudyFlow.html in an Android WebView.
The supplied anime image is used temporarily as the launcher icon and is also included
as app/src/main/assets/placeholder.jpg. Your HTML has not been redesigned.

Build APK:
1. Install Android Studio on a computer.
2. Open this StudyFlowAndroid folder as an existing project.
3. Let Gradle sync and install the Android SDK Platform 35 if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK location when finished.

Notes:
- JavaScript and localStorage are enabled so StudyFlow task data can persist in the app.
- The Google Fonts stylesheet in the HTML needs internet to load Figtree; system fallback fonts
  are already specified.
- The app itself loads the HTML locally. Task storage is app-local and separate from browser data.
- Replace mipmap-* / ic_launcher.png with your final logo when you send it.
- This source project is not itself an APK; compiling requires Android Studio / Android SDK.
