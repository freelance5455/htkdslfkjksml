COIN STACK REMASTERED - PAQUETE WEB TO APK

Contenido:
- index.html: juego completo, listo para cargar como página principal.

INSTRUCCIONES:
1. Sube este archivo ZIP a tu plataforma Web To APK.
2. Si te pide el archivo o página de inicio, selecciona index.html.
3. Configura el nombre de la aplicación como "Coin Stack Remastered".
4. Genera el APK siguiendo los pasos de la plataforma.

NOTAS:
- El HTML original se conserva sin modificar.
- El juego incluye sus recursos integrados en el propio HTML.
- Este ZIP es un paquete web; no es un APK compilado.
- La compatibilidad final depende de la plataforma Web To APK y de su WebView.
