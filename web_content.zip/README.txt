PRAGATI EDUCATION - No Fees version. Fees management and fee display have been removed. Open index.html in Chrome/Edge.
