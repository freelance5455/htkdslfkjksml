मेरा हिसाब V2
=============
अब Customers दो अलग folders में हैं:
1. 🔴 मुझे पैसे देने हैं
2. 🟢 मुझे पैसे लेने हैं

Home पर दोनों folders और customer counts दिखते हैं।
Customer के अंदर पूरा हिसाब, WhatsApp और SMS reminder उपलब्ध है।
Daily/Monthly reports और transaction history भी हैं।
ZIP-to-APK builders के लिए index.html root और web/index.html दोनों जगह रखा गया है।
