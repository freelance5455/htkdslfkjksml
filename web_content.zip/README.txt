LOONIE ACADEMY v13 — EXPANDED CURRICULUM & CLEAN STUDY HUB
Complete, installable PWA with all six prior development phases intact
===================================================================

WHAT THIS RELEASE ADDS
- 807 total lessons in the existing 37 subjects (+423 topic-specific lessons).
- 3,714 total objective quiz checks (+1,692). Each new lesson includes four
  multiple-choice checks with varied correct-answer positions, feedback and
  original explanatory/reflective activities.
- Every subject has at least 20 lessons; many previously had only 2–6.
- Foundation, applied, and advanced modules in each subject, including
  health, aviation, law, design, AI, manufacturing, energy, business,
  computing, math, the construction trades and additional technologies.
- Redesigned mobile-first Study Hub: simplified course discovery, search,
  category filters, Continue Learning, less clutter and a tighter layout.
- Streamlined subject pages with collapsible learning stages, compact lesson
  rows, progress breakdown, saved capstone project workspace and Markdown
  export for personal learning notes.
- Searchable, filtered lesson library with pages of 24 results.
- Offline cache version updated to load all v13 assets after a web update.

IMPORTANT EDUCATION DISCLAIMER
- Advanced content in the app is SELF-STUDY, not a completed bachelor's degree
  and does not provide academic credits, Red Seal certification, licensing,
  apprenticeship hours or trade practical assessment. It cannot fully replace
  multi-year accredited programs or on-the-job training. Practical/regulated
  subjects include safety notices. Quizzes check recognition and reasoning,
  not real-world competence. Research official local program standards.
- Some generated lessons share instructional scaffolding; they are not
  equivalent to instructor-graded college modules. Review independent sources
  and seek qualified supervision before applying safety-critical practices.

VERY IMPORTANT — YOU ALREADY HAVE LOONIE ACADEMY ON NETLIFY
You should UPDATE THE ORIGINAL WEBSITE, not make a new website or uninstall
Loonie Academy. The prior app's progress lives in browser/app storage on that
specific website origin and is included in its backup exports.

Step 1: Open your existing Loonie Academy app on your PHONE, navigate to
        Me → Backup & Restore, and DOWNLOAD a backup as a safety copy.
Step 2: On your COMPUTER, download and EXTRACT
        Loonie_Academy_v13_Netlify_Ready.zip into an empty folder.
        You should see index.html and 20 other files directly in that folder.
        (Do not upload a folder that contains another nested folder above
         index.html.)
Step 3: Sign in to Netlify, open YOUR CURRENT Loonie Academy project
        (the one with your existing netlify.app address), and open Deploys.
Step 4: Find the manual deploy / drag-and-drop section in the Deploys page,
        then drag the entire *extracted folder* of updated site assets there.
        Wait for the production deploy to report Published.
Step 5: Keep the EXACT SAME netlify.app address. On your phone, reopen the
        installed app WHILE ONLINE. If it shows the old version, close and
        reopen it or reload once in Chrome. The service worker may take a
        subsequent reload to activate. Confirm the Study Hub shows 807 lessons.
Step 6: Confirm your progress is intact. Make a new in-app backup. Only then
        test airplane-mode reopening and offline lessons.

If you still see v12 after a fresh reload, open the existing website in Chrome,
refresh while online, and relaunch the installed app. Do not delete site data
or uninstall: that can permanently erase local progress without a backup.
If you want to keep the app private, preserve your Netlify access settings.

PACKAGES
A) Loonie_Academy_v13_Netlify_Ready.zip — JUST the 21 deployable web assets
   with index.html at the ZIP root. This is the easy Netlify update package.
B) Loonie_Academy_v13_Expanded_Curriculum_Complete.zip — the same complete
   app, authoring outline/source generator, v13 regression scripts, historical
   development QA, optional Android build-kit and GitHub workflow.

PWA AND ANDROID
The v13 PWA runs in a standalone browser-installed window on supported
Android phones. An optional native Capacitor build kit is included in package
B for a separate APK, but a new Android APK was NOT compiled in this environment.
Netlify requires an initial web connection. Core offline assets are precached
by the service worker; the service-worker cache passed a simulation, but
physical Android airplane-mode tests remain unverified. Some optional online
content (e.g. remote Python runtime/fonts) needs a separate connection.

TESTING
- Core JavaScript syntax; v13 Playwright browser UI tests at 320px, 390px,
  768px and 1280px, including quiz, project exports, backups and old state.
- Phase 2 four-semester University regression; Phase 3 all labs/investigations
  and Teach Lou modes; Phase 4 full Knowledge Kingdom; Phase 5 all career
  projects; Phase 6 Loonie Life and business progression: all passed.
- Simulated service-worker precache and offline cache route: passed.
- Local HTTP browser navigation is blocked in the automated test environment,
  so live localhost/phone airplane-mode testing was not completed.
See QA-v13.txt and the supplied regression scripts for precise scope.

DATA AND PRIVACY
No new accounts or backend are required for these features. Notes, progress,
self-study project work and optional simulations are saved locally in the
site/app's data storage until exported. Hosting the static site on a public
URL makes the app files and course content accessible to those who can visit
it, but local notes/progress are not automatically published.

OFFICIAL REFERENCES FOR CREDENTIAL REQUIREMENTS
Canada Red Seal: https://www.red-seal.ca/
Alberta apprenticeship information: https://tradesecrets.alberta.ca/
Alberta post-secondary credential types:
https://www.alberta.ca/post-secondary-credential-types
Netlify manual deploys: https://docs.netlify.com/deploy/create-deploys/
