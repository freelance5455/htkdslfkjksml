Spesen und Arbeitszeiten — v7, only zoom-out adjustment.
Everything else is unchanged from the restored v7.
Zoom can now be reduced to 10%, with 30% as the initial view.
Two-finger pinch zoom remains available.
