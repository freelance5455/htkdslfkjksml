Skill4Grow direct launcher

Import this ZIP into your HTML-to-APK Builder. The launcher immediately navigates to https://skill4grow.vercel.app/ and has no welcome/splash screen.

Important: for links to open in Chrome/default browser instead of inside the app WebView, enable the Builder's external HTTPS link/browser option. Plain HTML cannot force Android to launch Chrome.
