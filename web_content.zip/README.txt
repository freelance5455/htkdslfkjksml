1) Download https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js and save it next to index.html as three.min.js (for fully offline play).
2) Zip the folder (index.html at the zip root) and use a website-to-APK tool, or put it in a Capacitor / Android Studio WebView project.
3) Landscape: in AndroidManifest.xml set  android:screenOrientation="sensorLandscape"  on the activity (Capacitor: same). Most converters have a "Landscape" option.

--- v2 ---
Landscape (automatic): index.html tries fullscreen + landscape lock itself, and falls back to rotating the screen if the phone is held upright. For a real APK also set  android:screenOrientation="sensorLandscape"  on the activity in AndroidManifest.xml (Capacitor: same file), plus android:theme with fullscreen/immersive if you want.
Offline: all textures, sounds and effects are generated in code. The only external file is three.min.js (step 1) - without it the game falls back to the CDN and needs internet once.

--- v3 ---
Models are now smooth/organic (rounded bevels, blob trees and rocks, capsule soldiers, metal PBR weapon with sky reflections). Still fully offline except three.min.js.


--- SHADOW OPS ULTIMATE UI ---
This edition adds a custom tactical intro screen, animated grid, mint-green mission branding, responsive landscape layout styling, and upgraded start button styling. Gameplay logic and touch/keyboard controls are preserved.
For fully offline play, place the official Three.js r128 minified build named three.min.js beside index.html. Otherwise the page attempts to load Three.js from its CDN and requires internet access for that library.
