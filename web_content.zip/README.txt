MIS PRÉSTAMOS — VERSIÓN FINAL

ADMINISTRADOR
- La APK abre la administración.
- El formulario público NO se abre dentro de la APK.

CLIENTES
- Enlace público: https://mis-prestamos-21fd9.web.app/
- Abre el formulario de solicitud.
- Al pulsar “Enviar solicitud por WhatsApp”, abre WhatsApp hacia 300 402 6303 con los datos diligenciados.

PUBLICACIÓN
- Firebase Hosting debe usar la carpeta: public
- El proyecto Firebase configurado en el proyecto es: mis-prestamos-21fd9
- La URL anterior queda disponible después de hacer el deploy/autenticación de Firebase.
