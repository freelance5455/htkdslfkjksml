NIROB — TEXT-ONLY DOCUMENT SCANNER UPDATE
==========================================

All app interface text is English-only.

This version attempts OCR (text recognition) and rebuilds the recognized text onto a clean white A4 page, instead of keeping the photographed background. It embeds the fixed watermark and footer, then exports JPG or PDF.

Fixed watermark:
Abdur Rahman Shihan

Fixed footer:
This document was created by Abdur Rahman Shihan.

Build:
1. Open HTML to APK.
2. Choose ZIP File to APK and select this ZIP.
3. App name: Nirob
4. Package ID if requested: com.nirob.scanner

Important technical notes:
- OCR uses Tesseract.js loaded from a CDN, so an internet connection is required the first time and the APK WebView must permit remote scripts.
- This prototype recognizes English text only. Other languages, complex columns, tables, stamps, handwriting, and exact original page layout may not be reconstructed correctly.
- The output is retyped OCR text on a white page, not a pixel-perfect facsimile of the original. Please proofread before using.
- Camera access depends on the converter's Android WebView permissions.
- Watermark/footer are baked into exported image/PDF, but external editing tools can still alter exported files.
