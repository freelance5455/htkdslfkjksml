ATINY Universe - Web App Bundle

This is a standard ZIP archive for web-to-app tools that accept a static HTML project.
- index.html is at the ZIP root.
- No password, no nested top-level folder.

Important: no ZIP can be guaranteed compatible with every converter. Some services require a URL, a Git repository, or a specific project structure; some charge for APK export. This bundle is not itself an APK.
