PRADEEP HINDI AI — HTML-to-APK starter ZIP

HOW TO TRY ON YOUR ANDROID PHONE
1. Open your HTML to APK app.
2. Choose “ZIP File to APK”.
3. Select this ZIP file.
4. Follow the converter's app-name/icon/build steps and build the APK.

IMPORTANT LIMITATION
This ZIP contains a mobile-friendly app interface. It does NOT include a real AI dubbing engine or API key. Actual English-to-Hindi translation, Hindi voice generation, and exporting a dubbed video require a working backend/server connected through the “AI backend URL” field. Do not paste private API keys into a public/shared APK.

The app sends the selected video to the backend URL you provide. Only use a backend you trust and have permission to upload your video to.
