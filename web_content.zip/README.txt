EGG PARTY SALES DASHBOARD - APP READY V4 (Excel File Picker Fix)
=================================================================

FILES
- index.html: Standalone dashboard + Admin Panel + Excel Import.
- sample-import-template-2026.xlsx: Example workbook for import.
- ANDROID_WEBVIEW_FILE_CHOOSER.java: Reference Android Activity code to enable
  the system file picker in Android WebView apps.

FIXED IN V4
- Removed the invisible input that covered the upload box in V3.
- Added a visible, native Choose File control.
- Tapping the upload box or the native control opens the file chooser
  in compatible browsers / Android WebViews.
- The selected Excel file is previewed and can be saved to local storage.

HOW TO USE
1. Open index.html in a browser, or use it as the entry page in your app builder.
2. Open Admin Panel > Excel Upload.
3. Tap the visible Choose File button and select .xlsx or .xlsm.
4. Tap Preview Excel Data.
5. Verify the monthly sheets, party count and quantity.
6. Tap Save & Apply Report.

IMPORTANT FOR APK BUILDERS
HTML cannot enable a missing native Android file chooser.
If tapping Choose File opens nothing in the installed APK, your builder's
WebView must implement WebChromeClient.onShowFileChooser (see Java example).
Also enable JavaScript, DOM Storage and content/file access.
If your no-code app builder has no File Upload / File Chooser option, use an
Android Studio WebView wrapper or a different builder that supports uploads.

TESTED
The HTML upload box and the native input both opened a file chooser in
mobile-emulated Chromium. A two-sheet Excel workbook was parsed with two
party codes and a total quantity of 2,900; Save & Apply persisted the data.
This does not verify your particular APK builder or Android device.

DATA SAFETY
Data is saved locally in the browser / app WebView storage. It is not
synchronized to a server. Make a JSON backup before uninstalling the app,
clearing app storage, or changing the app's WebView origin.

NOTE
Excel export, blob downloads, PDF and PNG may require additional native
Android integration depending on the APK builder. The Java example addresses
FILE UPLOAD only, not those other native integrations.
