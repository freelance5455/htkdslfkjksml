ENGLISH QUEST - ANDROID WEB APP PACKAGE

This package contains the app entry page in common locations:
- index.html
- web/index.htm
- web/index.html

The converter error screenshot showed it was trying to load:
https://appassets.androidplatform.net/web/index.htm
So web/index.htm is included explicitly.

Upload this ZIP as a fresh project/build to the converter. If the converter asks for a start page or entry file, use:
web/index.htm

This is still a web app packaged in an Android WebView, not a native Android app. Test the generated APK and export a progress backup regularly.
