VIDORA — ENHANCED WEB APK PACKAGE

Enhanced from the uploaded Vidora APK web assets:
- HTML5 direct-video player
- Download Video button for direct/authorized media URLs
- Existing downloads, files, vault and settings preserved

IMPORTANT: a web-only iframe cannot inspect <video> elements on arbitrary cross-origin websites. Therefore this package cannot reliably add a download button to every third-party page exactly when its video starts. That exact behavior requires native Android WebView download/media interception. DRM/protected media is not bypassed.

Use only media you are authorized to download.
