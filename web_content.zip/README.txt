AI CROP DOCTOR — FIRST ANDROID APP INTERFACE

This ZIP contains index.html for the first interface prototype.

Included:
- camera photo selection
- gallery photo selection
- crop selection list
- language selection list
- safe demo result screen

IMPORTANT:
This is NOT yet an AI disease detector. No AI model, diagnosis API, fertilizer database,
product inventory, or live buying links are connected. Do not use this prototype to
decide a real crop treatment. A verified agriculture backend must be added and tested.

To package as an APK, use a reputable Android packaging service that accepts an HTML ZIP.
Review its privacy policy and permissions first. Do not upload private farm/customer data.
