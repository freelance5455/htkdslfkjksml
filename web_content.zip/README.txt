# SAMI TRADER MT5 DEMO v2

This package is a mobile-first web/PWA frontend plus a real MetaTrader 5 Python bridge.

## What works
- MT5 DEMO login: login/password/server
- Truthful connection state
- Account balance/equity
- Live symbol quote through MT5
- BUY/SELL demo orders
- Open positions
- Close position / Close All
- Safety: real-money trading and auto trading are OFF
- No password stored by the frontend

## Setup the real MT5 demo connection
1. On Windows/VPS install MetaTrader 5 desktop and log into the Exness DEMO account.
2. Install Python 3.10+.
3. Open a terminal in `bridge/`.
4. Run:
   `py -m pip install MetaTrader5 fastapi uvicorn`
5. Run:
   `py -m uvicorn mt5_bridge:app --host 127.0.0.1 --port 8000`
6. Serve the frontend with any static web server.
7. Enter the MT5 DEMO login, password and server in SAMI TRADER.
8. Use DEMO only.

IMPORTANT: The frontend alone cannot directly talk to the MT5 broker server. The MT5 desktop terminal/bridge must be running on a Windows PC or VPS. Never paste your password into chat.
