# Smart Expense Tracker — First Working Version

Open `index.html` in Chrome on Android or any modern browser.

Features:
- Add daily purchases
- Categories
- Necessary vs unnecessary flag
- Current-month total
- Unnecessary spending total / potential saving
- Category spending bars
- Simple spending-reduction suggestions
- Recent purchase history
- Data stored locally in the browser

No internet or account is required.
