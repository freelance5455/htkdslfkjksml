ONE LOVE V6
Version corrigée pour la création de publications.

- Bouton « Créer une publication » directement sur Accueil et Profil.
- Écriture d'un texte.
- Ajout d'une photo.
- Publication enregistrée sur le téléphone.
- Les publications apparaissent dans « Mes publications ».

IMPORTANT : cette version reste un prototype local. Les publications ne sont pas encore partagées entre plusieurs téléphones.
