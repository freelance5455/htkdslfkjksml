GunForge Arena - HTML5 game (Cyberpunk Neon)
วิธีใช้กับ App "HTML to APK": อัปโหลดไฟล์ zip นี้ (index.html อยู่ที่ root)
- ไม่ต้องมีไฟล์รูป/เสียง: เสียงทั้งหมดสังเคราะห์ด้วย WebAudio
- ฟอนต์ Orbitron/Rajdhani โหลดจาก Google Fonts (ต้องมีเน็ตครั้งแรก ถ้าไม่มีจะใช้ฟอนต์สำรอง)
- เซฟเกมด้วย localStorage
- ตั้งค่า Orientation = Portrait ในแอปแปลง APK
