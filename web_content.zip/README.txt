SN FF TOUR - APK WEBVIEW BUILD PACKAGE

This package is intentionally a static web package for ZIP-to-APK/WebView builders.
It loads the live SN FF TOUR V6.1.1 website after the branded splash screen.
Offline/unreachable startup shows Retry and Exit instead of a blank page.

Website: https://sn-nexora-ff.web.app/
