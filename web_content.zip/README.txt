INVENTORY & SALES TRACKER - ANDROID APP (installable web app / PWA)
===================================================================
Put these files on any HTTPS web host, open the link in Chrome on your phone,
then tap  (3-dot menu) > Install app (or "Add to Home screen"). It then opens like a
normal app, full screen, and works offline. Camera scanning needs HTTPS.

Easy free hosting: drag this whole folder onto Netlify Drop (app.netlify.com/drop)
or use GitHub Pages / Cloudflare Pages. You get an https:// link to open on the phone.
If you update an installed copy, close and reopen the app twice to load the new files.

Features: scan (camera or Bluetooth/USB scanner), price breakdown with discounts,
commission and profit, record sales, stock in/out, items, dashboard, barcode image
generator, and PDF REPORTS.

PDF reports (Reports tab): Stock In, Stock Out, Sales (detail), Daily / Weekly / Monthly
Sales, Discounts, Commission, Profit by Item, Stock Valuation, Low Stock / Reorder.
Choose a period (dates or Today / This week / This month / This year / All time), enter your
business name once, tap PDF. Files go to the phone's Downloads folder; a Share button
appears on phones that support sharing files.

Data lives on the phone (browser storage). Back it up: menu > Export backup (JSON).
Move data from the desktop app: there, File > Export (inventory and log CSV), then on the
phone menu > Import backup / desktop CSV (import inventory first, then the log).
Importing the same log twice adds duplicates.

Want a real .apk? Wrap this folder with PWABuilder (pwabuilder.com) or Capacitor.

BARCODE LABELS FROM YOUR ITEM LIST
Import your item list (menu > Import backup / desktop CSV; save Excel sheets as CSV first). Any CSV
with an item-name column works (Item Name / Name / Description; Price, Cost, Barcode, Category etc. are
recognised automatically; ; or , separated). Items with no barcode get one automatically.
Then Reports tab > Barcode labels: choose category, copies, price on/off > Labels PDF (24 per A4 page) or
Barcode list PDF. EAN-13 and UPC-A codes are drawn as EAN-13; any other code is drawn as Code 128.

MULTI-ITEM INVOICES AND RECEIPTS
Invoices tab > set Business name, address, phone, tax % and footer once.
Scan tab: scan an item, set quantity > "Add to invoice" (repeat) > "View invoice" > enter customer,
Cash or Credit, agent > "Complete sale". Stock for every item goes down at once. Cash sale = RECEIPT
(paid); Credit sale = INVOICE (amount due). Get an A4 PDF or an 80 mm receipt PDF right away, or later from
the Invoices tab. "Void invoice" cancels a wrong sale (items return to stock, removed from reports).
Reports tab > Invoice Register lists all invoices for a period. Customer documents never show cost,
commission or profit. "Quick sale (no invoice)" still records a single item.

MAKING AN APK (PWABuilder)
1. Upload the unzipped folder (index.html must be at the top level) to Netlify Drop (app.netlify.com/drop).
   The included _headers file makes Netlify serve manifest.json correctly.
2. Check the link works: open https://YOUR-LINK/manifest.json in a browser. You should see text starting with {"id": ...
3. Go to pwabuilder.com, paste your link, press Start, then Package for stores > Android.
   Choose the SIGNED option, let PWABuilder create the key, and keep the key file and password safe.
Manifest checks run on this version: valid manifest, installable, service worker, 192/512 icons (any + maskable),
screenshots, shortcuts, id/scope/start_url.

SERVICE WORKER (sw.js)
Already included and registered by the app. It saves the app on the phone so it opens with no internet,
refreshes saved files in the background, and shows "Update ready" when you upload a new version.
To publish an update: change the cache name on line 2 of sw.js (e.g. inventory-v7), re-upload the folder,
then close and reopen the app.

IF PWABUILDER SAYS "DID NOT FIND A WEB MANIFEST"
That means it could not reach manifest.json on your link, so every field shows red. It is a hosting problem,
not missing fields. Check, in this order:
1. Open https://YOUR-LINK/manifest.json in a browser. You must see text starting with {  If you see "Page not found"
   or the app itself, index.html is not at the top level of your site: unzip, open the folder, and drag the folder
   that directly contains index.html (not a folder that only contains another folder) onto Netlify Drop.
2. Open https://YOUR-LINK/check.html. It shows PASS or FAIL for every item PWABuilder needs.
3. Make sure you are using the NEW upload: in Netlify open your site > Deploys and confirm the latest deploy time.

IF PWABUILDER SAYS A MANIFEST FIELD (e.g. description) IS MISSING
Our manifest.json contains every field. So PWABuilder is reading something else: an old upload, a cached result, or
a manifest it generated itself in its Manifest Editor. Open https://YOUR-LINK/check.html : it shows the build version
on your site and the exact manifest text PWABuilder receives. Then re-run PWABuilder on https://YOUR-LINK/?v=2
(the ?v=2 forces a fresh analysis).
