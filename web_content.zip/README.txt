Jogo das 140 Casas — Android TV
=================================

Ficheiro principal: index.html

Características:
- 140 casas
- 2 jogadores
- 2 dados simultâneos, grandes, com total
- Chegada exata à casa 140; excesso recua
- 60 casas coloridas (10 de cada: verde, amarelo, azul, laranja, rosa, roxo)
- Nas casas coloridas: Avançar/Recuar manual + Confirmar + Passar a vez
- 10 bombas até à casa 135
- Nas bombas: Recuar 5, Recuar 10, Avançar até à próxima bomba, Passar a vez
- 6 escadas
- Interface horizontal e responsiva para Android TV
- Funciona offline
