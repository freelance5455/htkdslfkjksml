BADRA Adiestramiento — versión funcional base

Incluye:
- Clientes y perros
- Ciclos configurables de 4, 8 o 12 clases
- Contador por ciclo y nuevo ciclo al completar
- Historial de clases
- Pagos e ingresos
- Gastos y ganancia
- Persistencia local en el dispositivo mediante localStorage
- Interfaz móvil y navegación inferior

Esta entrega es el código funcional/PWA base. Para generar un APK instalable hace falta empaquetarlo con un entorno Android (Android Studio/Gradle o un servicio de build).
