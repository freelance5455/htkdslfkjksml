MY TV – fertige HTML-TV-App für HTML-to-APK
===============================================

Die ZIP kann direkt bei einem HTML-to-APK-Dienst hochgeladen werden.
Wichtig: index.html liegt direkt im ZIP-Hauptverzeichnis.

ENTHALTEN:
- TV-Startoberfläche im dunklen 16:9-Stil
- CHANGE SERVER / SETTINGS / LIVE TV / MOVIES / SERIES
- Fernbedienung: Pfeile + Enter + Escape
- Geräte-ID wird automatisch erzeugt
- Aktivierung per API
- Demo-Modus mit Teststreams
- HTML/CSS/JavaScript ohne externe Frameworks
- PWA manifest

AKTIVIERUNG:
1. Für Testbetrieb: DEMO eingeben.
2. Für deinen eigenen Server in SETTINGS die API-Adresse eintragen.
3. Erwarteter Endpoint: POST /api/v1/activation
   JSON: {"deviceId":"TV-...","key":"..."}
   Erwartete Antwort: {"token":"..."}

HINWEIS:
Die Demo-Streams sind öffentliche Teststreams. Für den produktiven Einsatz bitte eigene, rechtmäßig verwendbare Streams und deine eigene API verwenden.
Die App verwendet eine eigene MY-TV-Oberfläche und kein fremdes Logo/Branding.
