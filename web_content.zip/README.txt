# Wildlife Quest

A free, mobile-friendly wildlife learning app prototype.

## Included features
- Wildlife facts and animal cards
- Habitat filters (savannah, forest, ocean)
- Multiple-choice quiz
- Paws, learned-fact tracking, quiz wins and unlockable badges
- Progress saved in the browser on the same device
- Offline support after the first successful load
- Progressive Web App (PWA) install support on compatible Android browsers
- No paid APIs, account, or external libraries required

## Test it locally
Opening `index.html` directly works for most features, but browser install and service-worker offline caching need a secure origin.
For full PWA testing, serve the folder on `localhost` using a local development server.

## Publish free with Netlify
1. Extract `wildlife_quest.zip`.
2. Open Netlify and sign in or create an account.
3. In the Netlify dashboard, choose **Add new site** / **Deploy manually** (wording may vary).
4. Upload the extracted folder contents, or ZIP the contents so `index.html` is at the top level.
5. Open the HTTPS site URL once while online. Wait a moment for the service worker to cache the app.
6. On Android, open the site in Chrome. Use the browser menu and choose **Install app** or **Add to Home screen** if offered.
7. To test offline, open the app once, then enable Airplane mode and reopen it.

## Important notes
- The app saves progress in local browser storage. Progress is tied to that browser and device; clearing site data or using a different browser may remove or not show it.
- Offline mode works after the app has loaded and cached successfully at least once.
- This is a website/PWA, not a native APK. A PWA can be installed from a compatible browser; publishing a native app to an app store requires additional packaging and store setup.
- Facts are simplified educational summaries. Verify information with trusted sources for formal school projects.
- To reset saved progress, use the **Reset progress** button inside the app.
