Max Call — yangilangan prototip manbasi

Ushbu paketda APK ichidan olingan WebView sahifasining yangilangan HTML manbasi bor.

Hozir qo‘shilganlar:
- telefon raqami kiritish maydoni;
- Android telefon ilovasini tel: havolasi orqali ochishga urinish;
- kontakt qo‘shishning vaqtinchalik, shu seanslik ko‘rinishi;
- internet audio/video qo‘ng‘irog‘i uchun xizmat hali ulanmaganini ochiq ko‘rsatish.

Muhim:
- Bu ZIP tayyor APK emas.
- Asl APK ichidagi HTML faylni almashtirish va APKni qayta imzolash uchun Android loyihasi/build muhiti kerak.
- SIM qo‘ng‘irog‘i WebView/Android ilovasi tel: havolasini tashqi telefon ilovasiga uzatsa ishlaydi.
- Haqiqiy internet audio/video qo‘ng‘irog‘i uchun ZEGOCLOUD App ID/project configuration va serverda yaratiladigan tokenlar kerak. Maxfiy server kalitlarini ilova ichiga yozmang.
