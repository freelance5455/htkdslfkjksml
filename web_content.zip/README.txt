ROOT Carrom Guide — warning-reduced HTML bundle
- index.html is at the ZIP root.
- Removed the Android intent URL that the checker misidentified as a missing file.
- The Quick Launch button now explains how to open Carrom Pool manually.
- This is an HTML wrapper, not a native Android app.
- Demo key ROOT-DEMO is a hard-coded educational example, not real license protection.
- No autoplay, cheating, game modification, or license bypass is included.
