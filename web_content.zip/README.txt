# محمد ضياء الصعب Demons

ملفات اللعبة:
- www/index.html
- www/style.css
- www/game.js

ملفات إعداد Capacitor:
- package.json
- capacitor.config.js
- commands.txt

الأوامر الأصلية التي أرسلتها موجودة في commands.txt.

ملاحظة:
مجلد android الكامل لم يتم إنشاؤه هنا؛ لأنه ناتج عن تشغيل `npx cap add android` داخل بيئة Node/Android.
بعد فك الضغط:
1. افتح Terminal داخل مجلد المشروع.
2. نفّذ: npm install
3. نفّذ: npx cap add android
4. نفّذ: npx cap copy
5. نفّذ: npx cap open android
