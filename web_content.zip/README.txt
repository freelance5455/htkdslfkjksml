القرآن الكريم - Android Studio Project

1. Android Studio کھولیں
2. Open پر کلک کریں
3. AlQuranAndroid فولڈر منتخب کریں
4. Gradle Sync مکمل ہونے دیں
5. موبائل USB سے Connect کریں یا Emulator چلائیں
6. Run ▶️ دبائیں

اہم:
یہ App موجودہ HTML Frontend کو Android WebView میں چلاتی ہے۔
114 Surahs کی فہرست موجود ہے، لیکن مکمل 6,236 آیات کا اصل Quran text
ابھی شامل نہیں کیونکہ اس کے لیے قابلِ اعتماد Quran data source یا آپ کی PDF ضروری ہے۔
