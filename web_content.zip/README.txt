Protocol Tracker – vollständige Offline-Web-App
Index-Datei liegt direkt im ZIP-Hauptverzeichnis.
Daten werden lokal im Browser/WebView gespeichert.
