PSX Profit Calculator - HTML APK Package

UPLOAD:
- This ZIP is intentionally flat.
- index.html is at the ROOT of the ZIP.
- Upload this ZIP to a ZIP-to-APK web builder.
- Choose APK (not AAB) for direct installation on Vivo Y05.

CALCULATION RULES:
- Brokerage <= Rs.20: Rs.0.03/share
- Brokerage > Rs.20: 0.15% of trade value
- SST: 15% of brokerage
- CDC + NCCPL: 0.015% of applicable transaction value when enabled
- Intraday: buy-side brokerage/SST/CDC-NCCPL only
- Delivery: buy + sell brokerage/SST/CDC-NCCPL
- CGT: 15% of positive gross profit when enabled
