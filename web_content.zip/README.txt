JAIBIR – SPOKEN MANDARIN COURSE: PRACTICE & TEST FORMAT FIX

Practice items now show Chinese characters, tone-marked Mandarin Pinyin, Hindi pronunciation, Hindi meaning, and example sentence.
MCQ questions show Pinyin and Hindi pronunciation directly under the Chinese word; the learner chooses the Hindi meaning.
Verbal prompts show the meaning first, then the spoken answer reference with Pinyin and Hindi pronunciation for self-check.
No handwriting or copying exercise is included.
Detailed authored lessons remain Days 1–7; Days 8–90 roadmap only.
