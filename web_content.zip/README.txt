Contractor Pro V2
Languages: Persian, English, Arabic, Turkish, Russian.
Automatic calendar defaults: Persian=Persian/Solar Hijri, Arabic=Islamic, English/Turkish/Russian=Gregorian.
Dates are stored internally as ISO timestamps and formatted for display by selected language/calendar.
Manual calendar override is available.
HTML-to-APK structure: web/index.html
Commercial licensing/payment/server verification is not included in this prototype.
