SIMPLES FOOTBALL — VERSÃO FULL (HTML)

Abra o arquivo index.html no navegador (celular ou PC) ou hospede a pasta em qualquer site estático.

O QUE TEM NESTA VERSÃO:
• Conta por nome de usuário — ao entrar de novo, o elenco, moedas, histórico e tudo reaparecem
• Sistema de CAIXAS (Bronze, Prata, Ouro e Lendária) com jogadores aleatórios
• Venda de jogadores do elenco
• Mercado livre com ofertas e atualização
• Partidas automáticas com escalação dos melhores 11 jogadores
• Simulação em tempo real com gols, cartões, lances e nomes dos artilheiros
• Resultado com destaques e escalação usada
• Evolução de divisão e upgrade de estádio
• Histórico de partidas e estatísticas
• Tudo salvo automaticamente no navegador (localStorage)

LIMITAÇÃO:
Ainda é um protótipo local. Contas online reais e marketplace entre pessoas de verdade precisam de servidor + banco de dados.
