MY DAY OS
1) تجربة سريعة: افتح index.html في Chrome (الحفظ يعمل، لكن التثبيت كتطبيق يحتاج رابط https).
2) للتثبيت على Android: ارفع المجلد كاملاً على Netlify Drop أو GitHub Pages أو Cloudflare Pages، افتح الرابط في Chrome ثم "تثبيت التطبيق". بعدها يعمل Offline.
3) البيانات محفوظة في IndexedDB على الجهاز. خذ نسخة JSON من الإعدادات بانتظام (خصوصاً قبل تغيير الهاتف).
