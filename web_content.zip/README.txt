NEXFIRE — ZIP PRONTO PARA CONVERSOR HTML/ZIP → APK

1. Mantenha index.html na raiz deste ZIP.
2. Abra este ZIP em um conversor que aceite HTML/ZIP.
3. Não use npm, Vite ou Node para esta versão.
4. O app funciona como página estática e tenta usar Supabase quando houver internet.
5. A opção ENTRAR COMO CONVIDADO funciona mesmo sem o Supabase.

Arquivos principais:
- index.html
- main.js
- style.css
