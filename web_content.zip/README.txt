Ultimate Drift — Android Studio project

This project wraps the HTML game in an Android WebView and forces LANDSCAPE orientation through AndroidManifest.xml.

Build APK: Open this folder in Android Studio, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).
The generated APK is usually in app/build/outputs/apk/debug/app-debug.apk.

Note: This is a source project ZIP, not a prebuilt APK. An Android SDK/Android Studio environment is required to compile it.
