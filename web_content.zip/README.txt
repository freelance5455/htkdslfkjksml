ODDECH 4–7–8 — instalowalna aplikacja webowa (PWA)

1. Wgraj CAŁĄ zawartość tego folderu do katalogu publikowanego przez Netlify.
2. Otwórz adres strony na telefonie z Androidem w Google Chrome.
3. Wybierz menu ⋮ i opcję „Zainstaluj aplikację” lub „Dodaj do ekranu głównego”.
4. Aplikacja będzie uruchamiała się w osobnym oknie i po pierwszym załadowaniu działać także offline.

Wymagany jest adres HTTPS (np. Netlify). Sam lokalny plik HTML nie może zostać zainstalowany jako PWA.
