FRUIT CATCHER — MOBILE APK PACKAGE

Files:
- index.html = mobile-ready game + AdMob configuration placeholders + Privacy/Consent settings UI
- privacy-policy.html = privacy policy template; replace contact email before publishing
- icon.png = app icon artwork

AdMob:
Replace these values inside index.html:
YOUR_ADMOB_APP_ID
YOUR_BANNER_AD_UNIT_ID
YOUR_INTERSTITIAL_AD_UNIT_ID
YOUR_REWARDED_AD_UNIT_ID

IMPORTANT:
A plain HTML file does not execute the Google Mobile Ads SDK. The final Android APK/WebView wrapper must connect these IDs to the Google Mobile Ads SDK and Google's UMP consent flow.

Suggested app:
Name: Fruit Catcher
Package: com.fruitcatcher.game
Version: 1.2
Orientation: Portrait
