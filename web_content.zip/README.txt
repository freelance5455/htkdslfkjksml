NEUBURG WINTER DASHBOARD - erste Version

Import in APK Forge:
1. ZIP-Datei auf dem Handy speichern.
2. In APK Forge "Gezippte Website" auswählen.
3. Diese ZIP-Datei auswählen.
4. Warten, bis der Import abgeschlossen ist.
5. Vorschau öffnen und prüfen.

Enthalten:
- index.html: App-Struktur
- style.css: Layout und Winter-Design
- script.js: Uhr, Weihnachts-Countdown und Wetterdaten

Wetter:
Die App ruft Open-Meteo über das Internet ab. Standort ist fest auf Neuburg an der Donau eingestellt.
Die angezeigte Schneewahrscheinlichkeit ist eine vereinfachte Näherung aus der Stundenprognose und der Niederschlagswahrscheinlichkeit, keine amtliche Schneewahrscheinlichkeit.
Für offizielle Warnungen bitte den Deutschen Wetterdienst (DWD) prüfen.

Hinweis:
Dies ist eine erste Web-App-Version. APK Forge kann je nach Version zusätzliche App-Einstellungen benötigen.
