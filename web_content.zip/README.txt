SUPER STAR PES LEAGUE - HTML VERSION

Open index.html in a browser or upload the ZIP to a ZIP-to-APK converter.

Features:
- Maximum 20 players
- 3 points win, 1 draw, 0 loss
- Automatic league table
- Match results
- Admin PIN: 20067
- Add players from the app

IMPORTANT:
This starter HTML version stores data locally on one device. It does NOT yet synchronize results between different phones. For shared live results, connect the JavaScript to Firebase/Supabase before distributing the APK.

The ZIP must contain index.html at its root, which fixes the "No index.html found" error from ZIP-to-APK apps.
