NAAM JAP TRACKER — HTML APP

Files:
- index.html: app screen
- style.css: UI/theme
- app.js: counter, local storage, statistics, history, export/import
- manifest.json: PWA metadata
- sw.js: offline cache

How to use:
1. Open index.html in a modern browser.
2. Set your mantra and daily goal.
3. Tap "जप +1" to record each jap.
4. Data is stored locally in browser storage on the device.
5. Use Export JSON for backup.

Important:
This is a pure HTML/CSS/JavaScript app. It does NOT create a system-wide floating overlay when minimized. Android overlay/background behavior requires native Android functionality or a native wrapper with the appropriate Android permission/service.
