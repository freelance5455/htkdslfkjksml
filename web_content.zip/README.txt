Study Plan Nest - Android Package v2

Changes:
- Daily List automatically resets at the start of a new local calendar day.
- Completed tasks from the previous day return to the active Daily List.
- If the app remains open across midnight, the reset is detected automatically.
- If the app is reopened the next day, the reset is also detected automatically.

Entry point: index.html
