# Xadrez 3D Cartoon — protótipo mobile

Abra `index.html` em um navegador moderno com internet para carregar o Three.js pelo CDN.

Recursos:
- Tabuleiro e peças 3D low-poly/cartoon, gerados proceduralmente.
- Controle de câmera por toque/arrasto e zoom.
- Toque na peça e depois na casa de destino.
- Regras de movimento com verificação de xeque.
- Roque, en passant e promoção.
- Xeque-mate e afogamento.
- Cor do jogador sorteada; se você ficar de pretas, a IA começa.
- IA leve com priorização de capturas, xeques e mate.
- Relógio de 5 minutos para cada lado.
- Peças capturadas saem do tabuleiro e ficam ao lado.
- Tela inicial com apenas JOGAR.

Observação:
Este pacote é um protótipo jogável em navegador/PWA. Para gerar um APK Android nativo, o mesmo núcleo pode ser empacotado em uma aplicação Android.
