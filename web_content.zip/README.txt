SAHM Travel Agency — Netlify website ZIP

DEPLOY:
1. Open Netlify and sign in.
2. Go to the manual deploy / drag-and-drop deploy area.
3. Extract this ZIP on your device/computer.
4. Upload or drag the extracted folder containing index.html to Netlify.
   If your Netlify interface accepts ZIP uploads directly, upload this ZIP.
5. Netlify will publish the static website and give you a site URL.

IMPORTANT:
This is a static website preview. The login buttons are demo-only. Google sign-in,
SMS OTP, password reset, and account creation need a real authentication service
and secure backend before collecting or verifying customer credentials.
