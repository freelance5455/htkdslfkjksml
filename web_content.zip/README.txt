MEGWA SmartFarm update

The Farmer Academy veterinary-guidance section now shows the photo above the explanatory text, including on mobile screens. Upload index.html to your static website host to publish the change.
