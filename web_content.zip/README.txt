AVRIX Store update

1. Extract this ZIP.
2. Open index.html to preview the store.
3. In APKForge, replace the old HTML/home page with this index.html and rebuild the APK.
4. Admin button opens Add Product. Add product name, price, category, description, stock and optional photo.
5. Customers can use Add to Cart or Buy Now, enter name, phone and full address, then send the COD order through WhatsApp.

Important limitation:
This version stores products and cart in the browser's local storage. Products added on the admin device will NOT automatically appear on customers' phones. Shared live inventory requires a backend/database (for example Firebase or Supabase) and admin authentication. Do not treat this local-only admin as secure for a public live shop.
WhatsApp order number is set to 8491003821.
