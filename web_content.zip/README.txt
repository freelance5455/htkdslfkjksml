M.S.M E Sevai — FILE UPLOAD FIX

This version adds Android WebView file-picker support.
When the HTML app asks to upload a file, Android's Files/document picker will open.

Build a NEW APK and reinstall it; the old APK will not have this fix.
