LANCER SECURE WRAPPER

Purpose:
A minimal Android WebView wrapper for your Lancer HTML.

IMPORTANT:
The Android app uses FLAG_SECURE. On Android devices that honor it,
the app window is excluded from normal screenshots and screen recordings.

HOW TO ADD YOUR HTML:
1. Put your finished HTML in:
   app/src/main/assets/index.html

2. Put images/files referenced by that HTML in:
   app/src/main/assets/
   Example:
   app/src/main/assets/lancer.png

3. Keep local references relative, e.g.:
   <img src="lancer.png">

BUILD:
Open this project in Android Studio or another Android Gradle build
environment, then build the debug APK.

No internet permission is declared.
