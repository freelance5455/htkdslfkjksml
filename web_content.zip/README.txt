CALORIE BUDDY — Versi 1.0 (offline-first)

ISI PAKET
- index.html: antarmuka aplikasi
- app.js: database awal, kalkulasi, penyimpanan, riwayat, grafik, backup
- manifest.webmanifest + sw.js: dukungan PWA/offline cache

CARA MENJALANKAN
1. Ekstrak ZIP.
2. Untuk uji cepat, buka index.html di browser. Penyimpanan lokal berjalan pada browser tersebut.
3. Untuk pengalaman install seperti aplikasi: host folder ini pada HTTPS (mis. GitHub Pages/hosting pribadi), buka alamatnya di Chrome Android, lalu pilih menu ⋮ > Install app / Tambahkan ke layar utama.
4. Setelah pertama kali termuat melalui HTTPS, aplikasi dapat dibuka offline.

CATATAN PENTING
- Versi ini menyimpan data di perangkat/browser (localStorage) dan menyediakan ekspor/impor backup JSON.
- Sinkronisasi cloud lintas perangkat belum diaktifkan karena memerlukan backend dan akun/konfigurasi cloud. Jangan menganggap data sudah tersinkron.
- Database makanan adalah estimasi per 100 gram, bukan nilai laboratorium. Sesuaikan dengan label produk/resep.
- Belum berupa APK native yang ditandatangani. Paket ini adalah PWA yang dapat dipasang dari Chrome setelah di-host melalui HTTPS.
