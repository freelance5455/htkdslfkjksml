BD Life Toolkit — Zero Budget Android Web App

Features:
- Age Calculator
- Percentage
- Discount
- EMI
- BDT/USD converter
- Unit converter
- Fuel cost
- Trip budget
- Salary + OT
- BMI
- Profit
- Bill split
- Electricity estimate
- Date difference
- Simple interest

The app works offline and stores no personal data.
APK building:
1. Extract this ZIP.
2. Use an Android WebView/HTML-to-APK builder that accepts a local HTML project.
3. Set www/index.html as the start page.
4. App name: BD Life Toolkit
5. Use www/icon.svg as the icon if supported.

For a full native APK, the www folder can also be wrapped with Capacitor/Android Studio.
