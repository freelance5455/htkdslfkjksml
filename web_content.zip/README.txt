Food War — HTML to APK package

Files:
- index.html: plays the IRAQ GAMES intro video, then displays the blank dark-green game screen.
- assets/iraq-games-splash.mp4: the exact intro video file.
- manifest.webmanifest: requests landscape orientation for compatible wrappers.

How to use:
1. Extract this ZIP on your phone.
2. In your HTML-to-APK app, choose the option to load/import a local HTML project or folder.
3. Select index.html as the start page (or select the extracted project folder if the app asks for a folder).
4. Set orientation to Landscape in the APK builder settings.
5. Enable media/video playback and fullscreen if those options exist.
6. Build the APK and test it on your phone.

Important:
- This is a web project ZIP, not an APK.
- Some builders only accept a single HTML file or a hosted URL. If your app does not accept folders/local assets, it may not work as-is; use a builder that supports local HTML files and bundled assets.
- Android WebViews may block autoplay with sound until the user taps. If that happens, the intro screen shows a "Tap to start intro" button; after the video ends, the green screen appears.
- The game screen remains blank green as requested.
