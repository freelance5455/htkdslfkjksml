MY AI — HTML web starter

CONTENTS
- index.html: dark-blue multilingual assistant UI
- README.txt: usage and Android wrapping notes

PREVIEW
1. Extract this ZIP.
2. Open index.html in Chrome or another modern browser.
3. Send a message to try the demo response.

FEATURES
- Language selector for speech input/output (language support depends on the device/browser)
- Microphone input through Web Speech API where supported
- Text-to-speech for assistant responses
- Chat history stored locally in this browser (up to 100 messages)
- New chat and clear history controls
- Responsive mobile-first design

IMPORTANT: REAL AI IS NOT CONNECTED BY DEFAULT
Demo replies are local examples, not actual model-generated responses.
To enable real AI, set BACKEND_URL in index.html to your own HTTPS backend route.
Your backend should accept POST JSON {"message":"...", "history":[...]} and return {"reply":"..."}.
Keep AI API keys on the server. Never place keys in HTML, JavaScript, or an APK.
Before public release, add authentication, rate limiting, usage limits, and a privacy notice.

ANDROID APK
This ZIP is a web project, not a compiled APK.
You can later put index.html into an Android Studio WebView app or a trusted web-to-app workflow. Test microphone permissions and speech features on a real Android device. Use HTTPS for any backend connection.
