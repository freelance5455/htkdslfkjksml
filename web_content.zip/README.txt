GM CAD Manson Electro - versión web DXF 0.3

IMPORTANTE
- Este paquete está preparado para convertidores HTML a APK (WebView).
- index.html está en la raíz del ZIP.
- No requiere conexión ni librerías externas para las funciones incluidas.
- Abrir DXF ASCII desde el selector de archivos del dispositivo.

Funciones incluidas:
- Importación DXF ASCII.
- Visualización de LINE, CIRCLE, ARC, LWPOLYLINE, TEXT y MTEXT.
- Zoom con rueda/pellizco del navegador y desplazamiento de vista.
- Capas visibles/ocultas.
- Selección y movimiento básico de entidades.
- Borrado y deshacer básico.
- Medición de distancia entre dos puntos.
- Ajustar dibujo a pantalla.
- Exportación de DXF con las entidades compatibles.

Limitaciones:
- No es todavía un CAD completo. No implementa bloques INSERT, SPLINE, DIMENSION,
  POLYLINE 3D, referencias externas ni todas las variantes binarias DXF.
- El exportador genera un DXF ASCII nuevo con las entidades compatibles; no conserva
  datos avanzados, estilos, bloques ni metadatos del archivo original.
- La edición de polilíneas/textos es limitada; el movimiento básico está disponible.
- La compatibilidad de selección/descarga de archivos depende de los permisos y
  capacidades del convertidor HTML-to-APK/WebView que se utilice.

Para convertir:
1. Abrir la aplicación HTML to APK Builder.
2. Elegir importar ZIP/proyecto.
3. Seleccionar este archivo ZIP.
4. Verificar que index.html aparezca como página inicial.
5. Configurar nombre e icono y compilar.
