ALPHA LOAN TRACKER — APKForge ZIP

1. Upload this ZIP to APKForge using its HTML/ZIP import option.
2. Set the app title to ALPHA LOAN TRACKER.
3. Set index.html as the start/home page if APKForge asks.
4. Build and install the APK.

Included:
- Sinhala-first loan and people management UI
- Loan records with date and notes
- Installment/payment history
- Offline localStorage data
- JSON backup/restore and CSV report
- Black/deep-red theme
- Monthly 10% interest estimate based on the remaining principal balance

IMPORTANT CALCULATION NOTE:
This starter version calculates and displays 10% of the current outstanding principal as a one-month interest estimate. It does not yet accrue interest automatically by elapsed calendar months, nor split each payment between interest and principal. The payment entry currently reduces principal by the payment amount. Confirm the desired repayment allocation and date-based interest rules before using it for real accounting.

Data is stored locally in the app's WebView storage. Export a JSON backup before clearing app data or uninstalling.


GOOGLE DRIVE BACKUP SETUP
1. Open https://script.google.com and create a new Apps Script project.
2. Copy all contents of GoogleAppsScript_Code.gs into Code.gs.
3. Deploy > New deployment > Web app.
4. Execute as: Me. Set access to Anyone only if required by your account policy.
5. Authorize the Google Drive permission and deploy.
6. Copy the Web App URL ending in /exec.
7. In the app open Backup > Google Drive Backup, paste the URL, save it, then upload.

IMPORTANT:
- This uses your own Google Apps Script deployment to save JSON backups into a
  Google Drive folder named ALPHA_LOAN_TRACKER_Backups.
- The app's browser request uses no-cors, so it cannot read a server success
  response. After upload, verify the JSON file in Google Drive.
- Anyone who obtains a public Web App URL may be able to submit files to your
  Drive. Keep the URL private. Add authentication before using sensitive data.
- This is manual upload when you press the button, not automatic scheduled backup.


UPDATED INTEREST RULE (V1.1):
- Interest accrues only on exact monthly anniversaries counted from the original loan date.
- At each completed month, 10% is added to the then-outstanding principal.
- When a payment is entered, accrued unpaid interest is settled first; any remainder reduces principal.
- The next month's 10% is calculated on the reduced principal.
- A payment before the next monthly anniversary reduces principal; no incomplete-month interest is charged.
- The app computes allocations from the transaction dates. Keep device date correct.

NOTE: This is a prototype. Test with sample transactions and verify all results before real financial use. Existing backup restore data should be backed up before replacing app files.
