MINTY — HTML-to-APK test package

WHAT THIS IS
This is the MINTY web app packaged so an HTML-to-APK builder can find
index.html immediately at the ZIP root.

HOW TO USE
1. Open an HTML-to-APK / HTML-to-Android app builder.
2. Choose its option for importing an HTML project, ZIP, or local website files.
3. Upload minty-apk-ready.zip.
4. Set the start page to index.html if the builder asks.
5. Build a test APK, install it on your Android device, and test it.

IMPORTANT
- This ZIP is NOT an APK. The APK builder website creates the APK from it.
- If the builder only accepts a website URL (and not a ZIP/local HTML project),
  you must first host this folder on a static website host, then give that URL
  to the builder.
- MINTY currently saves songs and playlists in the browser's local storage.
  They may not carry over if the app is reinstalled or if app data is cleared.
- Firebase login/cloud sync is not enabled until you add your own Firebase
  project configuration in index.html.
- Saved song links open in their original website/app; MINTY does not download
  or contain music files.

The original app code is kept intact; this package only moves index.html to
the ZIP root and adds these instructions.
