Modi vs Rahul Dice Battle V10
Open index.html in Chrome or import the ZIP into your HTML-to-App builder.
Unofficial entertainment game; AI illustrated portraits.
