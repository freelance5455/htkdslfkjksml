JAY FX App — kifurushi cha awamu ya kwanza

JINSI YA KUTUMIA
1. Extract/unzip faili hili lote.
2. Fungua JAY_FX_App.html kwa Chrome au browser nyingine.
3. Usihamishe HTML peke yake; folda ya assets lazima ibaki pamoja nayo ili picha na video zionekane.

YALIYOWEKWA
- Nembo ya JAY FX kwenye sehemu ya brand/header.
- Poster ya JAY FX Academy kwenye ukurasa wa mwanzo.
- Picha ya mwalimu/portrait kwenye sehemu ya utambulisho.
- Video ya utambulisho (inafunguliwa kwenye sehemu ya Video ya JAY FX).
- Nembo ya duara imehifadhiwa ndani ya assets kwa matumizi ya baadaye.

KUMBUKA
Hili ni toleo la HTML linalofunguka kwenye browser, si APK iliyosainiwa wala app iliyochapishwa Play Store. Signals hazijaunganishwa na soko la live; mfano wowote wa signal ni wa demo/elimu tu.
