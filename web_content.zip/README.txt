ChessDesk Academy Manager - Web Upload Package

The website entry file is index.html at the root of this ZIP.
Upload this ZIP to your static website hosting service.

Note: This is the offline browser version, not an Android APK. Data is stored locally in the browser on the device and is not automatically synced between devices.
