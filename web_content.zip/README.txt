SAHRUKH KHATA v1.12
Settings > PIN सेट / बदलें now opens an in-app PIN form. Enter 4-6 digits twice and save. App Lock turns on automatically.
