ITRAK SHOP - Offline Website Export

This ZIP contains the publicly accessible front-end files downloaded from:
https://itrakshop-vyg3hscx.manus.space

To preview locally, serve this folder with any static web server, for example:
  python3 -m http.server 8000
Then open http://localhost:8000/

Note: this is a front-end export. Server-side APIs, database data, authentication,
checkout, WhatsApp ordering, and other external services are not included.
