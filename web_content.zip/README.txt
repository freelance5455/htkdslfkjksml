Polandball Epic v3
Загрузка: импортируйте index.html или ZIP в HTML to APK Builder.
Ориентация: Landscape. JavaScript должен быть включён.
