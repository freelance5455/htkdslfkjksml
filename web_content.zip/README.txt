Wave Study Hub - No Sign-In Website Prototype

Changes made:
- Removed Student sign in button.
- Removed the demo sign-in popup and email/password form.
- Changed Start learning to jump directly to the subject list.
- Removed the student-account promotional card.

How to use:
1. Extract this ZIP using your phone's Files app.
2. Open index.html in a browser to test the website prototype.
3. To update the installed APK, rebuild the app using a compatible HTML-to-APK builder.

Important: This ZIP is a website prototype, not a ready-made APK. Rebuilding the APK is required to replace the currently installed app. Some lesson and question content is sample content.
