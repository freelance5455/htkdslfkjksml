Girl Puzzle — standalone WebView-compatible prototype.
Features: 8x8 grid, colored regions, girl pieces, row/column/region rules, no-touch rule, Hint, Reset, Undo, Move Counter, Timer, 3 levels, Level Complete/Next Level.
Open index.html in a browser or use the folder in an Android WebView.
This ZIP is a standalone HTML/CSS/JS prototype, not a native .gdevelop project file.