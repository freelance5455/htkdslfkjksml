SGFE para Android - projeto Android Studio

O conteúdo web original está em:
app/src/main/assets/www/

Como gerar o APK:
1. Instale/abra o Android Studio num computador.
2. Escolha Open e selecione a pasta SGFE_Android.
3. Aguarde a sincronização do Gradle e a instalação das dependências.
4. Ligue um telemóvel Android ou use um emulador.
5. Para testar: Run > Run 'app'.
6. Para gerar o APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
7. O APK de debug ficará em app/build/outputs/apk/debug/app-debug.apk.

O aplicativo carrega os ficheiros localmente através de WebViewAssetLoader,
sem servidor e sem depender de um site externo. O armazenamento IndexedDB
fica no perfil local do WebView. A impressão chama o serviço de impressão
do Android.

Requisitos: Android Studio recente, JDK 17 e Android SDK 35.
Na primeira sincronização/build é necessária Internet para descarregar
as dependências e ferramentas do Android. Depois de instalado, o SGFE
pode ser utilizado offline.

Nota: esta é a embalagem Android do projeto original; recomenda-se testar
todas as operações, impressão e exportações num aparelho antes da utilização
com dados reais. Não desinstale a aplicação nem limpe os dados do app sem
fazer cópia de segurança, pois isso pode apagar a base de dados local.
