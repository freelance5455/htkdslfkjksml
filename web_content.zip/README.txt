Bunny Quote Studio v0.a.1.3 - Android Studio project (Roman Urdu)

Kya hai: Threads ke liye quote images banane wala tool. HTML app/src/main/assets/index.html mein hai,
Android WebView usay chalata hai. Download hone wali PNG Gallery mein Pictures/ThreadsQuotes mein save hoti hai.

Android Studio mein kholne ka tareeqa:
1. Android Studio kholein, File > Open, is poore folder ko select karein.
2. Gradle sync ka intezar karein (internet chahiye).
3. Build > Build APK(s) ya Generate Signed Bundle / APK > release.
   Signing key folder mein hai: tq.keystore (password tqstudio123, alias tqkey).
   APK: app/build/outputs/apk/release/

Tayyar APK: dist/ThreadsQuoteStudio-v0.a.1.3.apk (seedha phone mein install kar sakte hain).
Agar browser .apk download block kare to alag se aya hua ThreadsQuoteStudio-v0.a.1.3-APK-only.zip use karein.

Roz update ke liye: index.html badlein, phir app/build.gradle mein versionCode aur versionName barhayein,
aur index.html mein VER aur header ka version text bhi.

Note: gradlew agar maujood na ho to Android Studio khud Gradle 8.2 download kar leta hai.
Keystore ko mehfooz rakhein; naya update isi key se sign hona chahiye warna purani app par install nahi hoga.
