POLYSTRIKE
==========

WHAT'S NEW IN THIS BUILD
- Fixed the "THREE is not defined" crash: this build loads the 3D and
  physics libraries from a CDN, which needs internet the first time it
  runs. It's packaged as a proper folder now (not one giant HTML file)
  specifically so this can be fixed to fully local libraries later if
  your APK wrapper turns out to block all network access.
- Renamed to PolyStrike.
- Character select screen with 4 original heroes (Ember, Volt, Verdant,
  Shade) -- original designs only, no licensed characters.
- Character limbs are now tapered cylinders instead of boxes -- a much
  less blocky silhouette.
- An original dragon circles a small village. It periodically breathes
  fire, which sends villagers fleeing and can hurt you if you're caught
  in range. Shoot the dragon enough and it gets driven off for a while.
- Player health is now real: a health bar in the HUD, damage from the
  dragon, respawn if it hits zero.

CONTROLS
  Left thumb stick    Move
  Drag right side      Look around (third-person camera)
  FIRE                  Shoot
  ENTER                 Get in or out of the car
  JUMP                  Jump
  Keyboard/mouse fallback works too, for testing on a desktop browser.

IF THE GAME WON'T LOAD
Check for "THREE is not defined" or similar in the console -- that means
this specific environment has no internet access, and the CDN libraries
can't load. A real installed APK almost always has internet permission
by default, so test the actual packaged app, not just a raw preview. If
it still fails there, come back and we'll build a version with the
libraries fully embedded locally instead.

STILL ON THE LIST
The 4-faction conquest system, weather, wildlife, cheat codes, and
resource gathering from the earlier 2D version haven't been ported into
3D yet. Bring this back to the chat any time to keep building.
