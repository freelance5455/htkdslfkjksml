STOCKLY DIGITAL TWIN v2 — ELITES CAFÉ

Offline PWA: operations + Digital Twin (forecast, simulate, ask, past books).

Tabs: Home · Stock · Sales · Twin · Book · More

Digital Twin
- Expected sales by day of week (learns from history)
- Expected expenses & profit
- Stock depletion / reorder suggestions
- Menu engineering (Star / Workhorse / Hidden gem / Problem)
- Best / Expected / Worst 3-month forecast
- Simulation lab (price, volume, labour, waste)
- Ask the Business structured answers
- Forecast accuracy tracking

Past books
- Add past sales day (no live stock deduction)
- Add past expense
- Bulk paste: YYYY-MM-DD, revenue[, expenses]

Core café ops from v1 retained: recipes, COGS, EOD sales, waste, restock, workers, backup.

Open index.html or install as PWA.
