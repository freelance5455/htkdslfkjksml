Rajasthan Economic Survey APK source. index.html is at ZIP root. Package using an Android WebView or HTML-to-APK builder.
