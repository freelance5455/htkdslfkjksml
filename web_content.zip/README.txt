EDGE CLOUD USER PANEL — SOURCE ZIP

এই ZIP-এ গ্রাহক প্যানেলের index.html এবং Firestore rules আছে। এটি APK নয়।

একই Firebase project ব্যবহার করতে হবে যা Admin Panel-এ ব্যবহার করবেন। index.html ফাইলে firebaseConfig-এর YOUR_API_KEY, YOUR_PROJECT_ID ইত্যাদি আপনার Firebase Console > Project settings > Your apps > Web app থেকে পাওয়া মান দিয়ে পূরণ করুন।

প্রয়োজনীয় Firebase services: Authentication (Email/Password), Cloud Firestore. Firestore Database তৈরি করে firestore.rules প্রকাশ করুন।

ফিচার: নিবন্ধন/লগইন/পাসওয়ার্ড রিসেট, প্যাকেজ দেখা/অনুরোধ, বিল দেখা, পেমেন্ট রেফারেন্স জমা, অভিযোগ, প্রোফাইল।

গুরুত্বপূর্ণ: Admin Panel-এর জন্য আলাদা ZIP আছে, কিন্তু দুই অ্যাপ একই Firebase project ও একই Firestore database ব্যবহার করবে। অ্যাডমিনের অনুমতি শুধুমাত্র adminUsers/{uid} ডকুমেন্টে trusted setup দিয়ে দিতে হবে; public user app থেকে admin role তৈরি করবেন না।

APK বানাতে Android wrapper/build tool-এ এই index.html প্যাকেজ করতে হবে। শুধু ZIP খুলে ইনস্টল করা যাবে না।
