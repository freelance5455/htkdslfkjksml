# Boutique Ali Mdo / بوتيك الإي مدو

## Contents
- `index.html`: Arabic/French responsive storefront.
- `assets/logo.png`: supplied logo.
- `assets/reference-home.png`: supplied reference screenshot.
- `supabase_schema.sql`: tables and row-level security policies.

## Connect to Supabase
The frontend is configured with the project URL and publishable key supplied in this chat. Account registration and login use email and password; the phone number is not used for login.
A publishable key is designed for frontend use, but it is not an admin key. Never put a `service_role` or secret key in this project.

1. Open the Supabase project `lcrxgefesisnuhvumayv`.
2. Open **SQL Editor**, create a query, paste `supabase_schema.sql`, and run it.
3. Open **Authentication > Providers > Phone** and enable phone authentication.
4. Configure an SMS provider in Supabase and test it. Phone sign-up/password login will not work until the project's phone/SMS settings support it. SMS provider availability and cost depend on your Supabase setup.
5. In **Table Editor > products**, add actual products. `category` must be one of `food`, `oil`, `cleaning`, `feed`, `other`. Set `is_active` to true. The storefront intentionally displays an empty state instead of fake sample products.
6. Test account creation, login, product loading, and order submission.

## Product table fields
- `name_ar`, `name_fr`
- `description_ar`, `description_fr` (optional)
- `category`
- `unit_price` (single item price in FCFA)
- `carton_price` (optional)
- `is_active`

## Important limitations
- This is a web storefront source package, not an Android APK.
- The app does not fabricate product listings, order history, or wallet balances.
- Checkout saves orders to Supabase; online payment is not integrated.
- The admin dashboard, stock management, sales reports, and customer blocking are not included in this customer-facing package yet.
- For production, add server-side validation for order totals and prices (for example a Supabase Edge Function). Do not trust totals sent by the browser.
- The SQL schema allows customers to submit order items only for their own order, but a production backend should validate product price/availability server-side.

## Run
For quick testing, serve this folder with any static web server or deploy it to a static host that supports HTTPS. Opening the HTML directly may work for viewing, but authentication features should be tested on HTTPS/localhost.
