Pro Photo Studio AI web app bundle
Upload this ZIP to an HTML/ZIP-to-APK builder.
App name: Pro Photo Studio AI
The app works offline after packaging.
Note: this is a web app wrapper, not a native AI photo editor. Actual AI background removal/face retouch is not included.
