UP BOARD STUDY HUB
=================

यह एक शुरुआती HTML prototype है।

कैसे चलाएँ:
1. index.html को Chrome या Acode में खोलें।
2. Preview करें।
3. APK बनाने के लिए इस ZIP को किसी HTML-to-APK builder में upload करें।

नोट:
- अभी Notes/PDF/Questions में demo content है।
- असली UP Board सामग्री बाद में जोड़ी जा सकती है।
