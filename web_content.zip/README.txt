Wedding Gift Register — Premium lightweight edition

Included:
- Smooth, subtle CSS animations (no heavy animation libraries)
- Premium purple design
- Malayalam, English and Hindi language switch
- Search, edit, delete, totals, JSON backup and CSV export
- Data stored locally in the browser

Android:
1. Extract this ZIP.
2. Open index.html in Chrome.
3. Use Chrome menu ⋮ → Add to Home screen (or Install app if offered).

This is a lightweight offline web app, not a compiled APK. Data remains in this browser on this device. Download backups regularly before clearing browser data.
