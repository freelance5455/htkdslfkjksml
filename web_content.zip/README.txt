RICK.demon Painel Demo
Painel visual independente. O arquivo principal é index.html e está na raiz do ZIP.
