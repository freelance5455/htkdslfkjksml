NOVA STUDY — updated interface
1. Open nova_study_planner_v2.html in a browser on Android.
2. Use the phase tabs and date selectors to view daily tasks.
3. Checkboxes save progress in that browser on that device.
4. Use Export progress to download a text backup.
Note: This is a downloadable HTML app, not a compiled Android APK. Progress storage may be cleared if browser data is cleared. The remaining-new-chapters phase is provisional and should be matched to the school's full pre-board syllabus and actual PT-3 exam dates.
