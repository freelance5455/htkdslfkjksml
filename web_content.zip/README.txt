ARROWS RUSH — MOBILE WEB BUNDLE

1. Extract this ZIP on your phone.
2. Open index.html with your mobile browser.

The game is a single self-contained HTML page. The intro displays first; after its animation, the lobby appears. Tap SKIP INTRO to continue immediately.
This is a browser bundle, not an installable Android APK.
