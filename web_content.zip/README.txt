TABLETOP B751 V0.3 FIXED
IMPORTANTE:
- index.html está directamente en la raíz del ZIP.
- No hay carpeta intermedia.
- El ZIP está preparado para conversores Web/HTML -> APK que cargan index.html como página inicial.
