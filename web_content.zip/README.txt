JEE LABs — WEBSITE ZIP FOR WEB-TO-APK TOOLS

This ZIP contains the built static website version of the JEE Study Companion, with index.html at the ZIP root. Use it with a converter that accepts a static website / HTML ZIP and wraps it in an Android WebView.

HOW TO USE
1. In the converter, choose its Website ZIP, HTML app, or WebView app option and upload this ZIP.
2. Set the start page to index.html if asked.
3. Enable JavaScript and DOM storage/localStorage. The app needs these to run and keep study logs on the device.
4. Use app-icon.png as the launcher icon if the converter offers that setting.
5. Build/download the APK from the converter and install it on Android.

IMPORTANT
- This ZIP is under 5 MB and is not itself an APK or an Android Studio/Gradle project.
- Converter tools use different input formats. This ZIP is for tools that accept a zipped static website; a tool that only accepts a website URL or Android Studio project will not accept it.
- Study data is stored in the app's local WebView storage. Uninstalling the APK or clearing its app/WebView data can erase those logs. Export a backup from Settings before clearing data.
- The HTML, JavaScript, CSS, fonts, and other included assets are bundled locally; the app does not need a hosted website to load.
