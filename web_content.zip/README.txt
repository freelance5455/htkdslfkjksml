Yaman Gider Takip - APKForge dosya seçici düzeltmesi

APKForge'a yüklemek için bu ZIP dosyasını kullanın.
Arşiv kökünde index.html bulunur.

Düzeltme: Yedeği geri yükle düğmesi, gizli input.click() yerine gerçek dosya input'unu doğrudan dokunulabilir alana yerleştirir. Böylece Android WebView dosya seçiciyi destekliyorsa kullanıcı dokunuşuyla açılır.

Not: APKForge'un oluşturduğu WebView yerel dosya seçiciyi hiç desteklemiyorsa bunu yalnız HTML ile kesin olarak çözmek mümkün değildir; APKForge ayarlarında dosya yükleme / file chooser desteği gerekir.
