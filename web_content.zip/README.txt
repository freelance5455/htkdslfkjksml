Baraa v9.6 — My Gallery and Hidden 3s fixes
- Gallery theme selector now appears above the Gallery screen instead of behind it.
- Gallery image viewer is above the Gallery intro and opens as a large view.
- Opening an artwork immediately hides the Gallery intro overlay.
- My Gallery now includes a visible “Upload from phone” button for selecting one or more images.
- Uploaded images are resized and compressed before local storage to reduce storage usage.
- The dynamic note-pin hidden 3-second phrase is initialized when the editor opens.
- Existing Baraa and My Gallery features preserved.

v11.2 — Gallery
- Restored the original gallery look (no delete/trash buttons on images).
- All 17 bundled artworks now appear.
- "Add artwork" button: pick one or more images from the phone (resized, stored in IndexedDB).
- Tap an image to open the viewer: edit artwork date/time, see date added, favorite.
