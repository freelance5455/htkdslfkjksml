PRONOSTICSSPORT IA — VERSION AUTONOME

Aucune dépendance à FastAPI, Python, Node.js ou à un serveur backend.

Fichiers :
- index.html : interface
- config.js : clé et configuration API-Football
- assets/app.js : logique JavaScript et appels API
- assets/style.css : interface mobile

Pour utiliser l'application :
1. Ouvre config.js.
2. Remplace COLLE_TA_CLE_API_FOOTBALL_ICI par ta clé API-Football.
3. Garde les guillemets.
4. Ouvre index.html pour tester.

Pour convertir en APK :
- Garde index.html à la racine du ZIP.
- Le convertisseur Web -> APK doit accepter les appels réseau vers API-Football.

Attention :
- Les appels directs depuis un navigateur/WebView peuvent être bloqués par CORS selon la plateforme.
- Une clé API placée dans une application cliente peut être récupérée. Pour une application publique, un backend/proxy sécurisé est préférable.
