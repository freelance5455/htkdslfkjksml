Staff Attendance Register - Basic Prototype

Features:
- No login/logout
- Add staff
- Select month
- Daily attendance register
- P = Present
- A = Absent
- L = Leave
- WO = Weekly Off
- HD = Half Day (0.5 Present)
- Monthly totals
- Data saved locally on the device/browser

Open index.html in a browser to test the prototype.
