HALIMAW CF ID — APKForge Web Project

This ZIP is prepared for a website/HTML-to-APK builder such as APKForge.
The app UI can search locally added/imported entries and load a public JSON database URL.
It is NOT a compiled APK.

IMPORTANT:
- cfids.json is a placeholder example, NOT a real NBA 2K20 Mobile CF ID database.
- To let followers search the same data, host a verified JSON array publicly online and paste its raw HTTPS URL into the app's Online shared database field.
- Do not use the placeholder ID as a real CF ID.
- This app does not scan game files or discover CF IDs automatically.
