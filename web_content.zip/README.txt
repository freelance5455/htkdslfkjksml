Pic90s - Fixed Web APK ZIP
============================
IMPORTANT:
- index.html is placed directly at the ZIP root.
- CSS and JavaScript are referenced with relative paths.
- This package is designed for HTML-to-APK/WebView converters.
- Set the converter's start page to: index.html

This is a working front-end demo. Actual AI image generation requires an image-generation API/backend.
