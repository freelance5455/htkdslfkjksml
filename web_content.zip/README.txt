Mr.Campus Demo App
===================
A mobile-first HTML prototype inspired by the supplied Mr.Campus screenshots.

Included:
- Student dashboard matching the dark/cyan style
- Student profile and photo upload
- Notes
- AI area with text, voice, photo and file upload UI
- Teacher dashboard
- Teacher-generated attendance QR with 30-second expiry/rotation
- One attendance record per student per day
- Department/class separation
- Attendance details
- Teacher sharing of files with up to 3 departments
- Teacher-only event publishing
- Separate Principal login with institution-wide visibility
- LocalStorage demo data

Demo logins:
Student: AI001 / 1234
Teacher: teacher@mrcampus.demo / 1234
Principal: principal@mrcampus.demo / 1234

Important:
This is a frontend prototype. Real production authentication, secure database permissions,
persistent file storage, real AI/vision API integration, and server-side attendance validation
should be implemented in a backend before deployment. QR scanning/generation uses CDN libraries,
so internet access is required unless those libraries are bundled locally.
