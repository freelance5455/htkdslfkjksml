Max Call — video funksiyasi qo‘shilgan loyiha manbalari.

Yangi: Video tugmasi kamera/mikrofon ruxsatini so‘raydi, mahalliy kamera ko‘rinishini ko‘rsatadi, kamera/mikrofonni yoqib-o‘chiradi va tugatish tugmasi bor.

MUHIM: Bu hali boshqa foydalanuvchi bilan haqiqiy internet video qo‘ng‘iroq emas. Masofadagi qo‘ng‘iroq uchun ZEGOCLOUD/WebRTC SDK, foydalanuvchi ID-lari, signaling va serverda yaratiladigan xavfsiz token kerak. Android WebView’da kamera/mikrofon ishlashi uchun native ilova ruxsatlari ham berilishi lozim.

ZIP tayyor o‘rnatiladigan APK emas; Android loyihasiga qo‘shib, qayta build qilish kerak. Maxfiy AppSign/ServerSecret ni ilova ichiga joylamang.

Til tanlash qo‘shildi: O‘zbekcha, ruscha, inglizcha, turkcha va arabcha. Davlat nomlari ham tanlangan tilga mos ko‘rsatiladi. ZIP loyiha fayli, tayyor APK emas.
