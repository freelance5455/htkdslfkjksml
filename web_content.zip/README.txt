Snake Game - HTML5 (index.html in zip root)
Convert to app: upload this zip to WebIntoApp / AppsGeyser / Median / Appilix (Website -> ZIP/HTML),
or use Capacitor: npm i @capacitor/core @capacitor/cli; npx cap init; set webDir to this folder; npx cap add android.
