Privacy Shield Network (VPN)
1. Build: Android Studio -> open native-android/ (JDK 17, SDK 35) -> Build > Build APK. Sign ALL THREE apps with the SAME key (signature permission com.privacyshield.permission.CONTROL).
2. Permissions: INTERNET; VpnService (user confirms Android VPN dialog once).
3. Install order: any; install all three APKs (Control Center, Network VPN, Private Browser).
4. Detection: Control Center uses <queries> for com.privacyshield.network / .browser; missing app shows NOT INSTALLED.
5. VPN permission: open app -> 'Save + grant VPN permission' -> accept Android dialog.
6. SOCKS5 host/port/DNS: fields in this app (your own server only; no default proxy).
IMPORTANT: no tun2socks library is bundled (cannot be verified offline). Implement TunEngine (see ShieldVpn.kt) with e.g. hev-socks5-tunnel, then set Engines.engine. SOCKS credentials not implemented yet.
7. ZIP-to-APK (index.html): only the info/UI page works. HTML/WebView version cannot provide system-wide Android VPN/TUN functionality, cannot talk to the other apps, and is not "100% anonymous".
8. Native APK only: IPC control, VpnService, WebView privacy settings, cross-app status.
IPC: explicit broadcasts + signature permission. Actions: com.privacyshield.PRIVACY_ON / PRIVACY_OFF / STATUS_REQUEST / STATUS_RESPONSE. No analytics, no data collection.
