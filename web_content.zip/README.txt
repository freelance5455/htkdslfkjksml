Tabletop B751 V0.5
===================
HTML version for the ZIP-to-APK converter that worked with V0.3 Fixed.

index.html is directly in the ZIP root.

New in V0.5:
- Games/profiles: create, select, rename, duplicate and delete games.
- Each game keeps its own dice, counters, decks and roll history.
- Start a new session without deleting the game's configuration.
- Automatic local saving plus GUARDAR/CARGAR.

No image upload is included in this version.
