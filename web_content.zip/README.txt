AI DUO Starter (mobile web interface)
===================================
Files:
- index.html: responsive chat UI with browser speech input/output.

Important:
This is a starter interface, NOT a finished AI application or APK.
It currently does not connect to an AI model. A real AI service or local model,
and an Android packaging/build step, are still required.

Quick test:
1. Extract the ZIP.
2. Open index.html in a modern Android browser (Chrome).
3. Try the microphone button; browser permissions and language support vary.
