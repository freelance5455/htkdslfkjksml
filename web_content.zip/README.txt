SCOOTER DASHBOARD PRO — HTML project

FILES
- index.html: full responsive dashboard code and UI.
- README.txt: build notes.

FEATURES
- Responsive split screen: Spotify panel left; live clock/date and map launcher right.
- Liquid-glass-inspired panels and multi-colour neon accents.
- 12/24-hour clock setting; settings persist on the device.
- Google Maps destination search and driving directions using standard HTTPS URLs (not intent:// URLs).
- Location button and optional local weather using Open-Meteo, subject to internet and Android WebView location permission.
- Spotify URL setting for a playlist, album, or track; YouTube Music shortcut.
- Fullscreen request.

LIMITS
The map panel is a designed launcher, not an embedded live Google Map. It opens actual directions in Google Maps/browser. Spotify buttons open the Spotify URL; plain HTML cannot directly control the separate Spotify app's play/pause/next/previous. Real Spotify control needs Spotify's supported API/SDK and user authentication, or Android native media-session integration.

BUILD
1. Import index.html or this ZIP into the HTML-to-APK builder.
2. App name: Scooter Dashboard.
3. Enable internet and external HTTPS links. Configure the builder to open external links in the system browser/appropriate app instead of forcing all links into its WebView.
4. Enable location permission if you want location/weather.
5. Build and test while parked.

If Google Maps still shows a WebView "intent" error, the APK wrapper needs an external-link handler. HTML cannot override a wrapper that forcibly loads external app links inside its own WebView.
