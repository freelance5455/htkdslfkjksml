Portugal RP — Godot project
==============================

Este ZIP é o projeto Godot, não é o APK.
Abra a pasta no Godot 4.x e escolha Project > Export > Android.

O preset Android já está incluído em export_presets.cfg.
Para compilar o APK, o Godot precisa do Android SDK/JDK configurado no computador.

Conteúdo principal:
- cidade 3D procedural
- personagem
- carros
- NPCs
- polícia/procurado
- missões
- dinheiro/vida/armadura
- HUD e controles de toque

O conteúdo é original/procedural e não inclui assets proprietários do APK de referência.
