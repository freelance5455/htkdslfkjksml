HIGHLAND REACH
An open-world explorer set in Ethiopia.

RUN
Open index.html in Chrome, Edge or Firefox (internet needed on first launch for three.js and real elevation data; visited areas then work offline). For install and offline mode, serve the folder over https or localhost.

GOAL
Recover the ten glowing relics hidden at real Ethiopian heritage sites. Hyenas hunt you, more at night. Progress and best time are saved.

CONTROLS
Move WASD | Run Shift | Jump Space | Crouch C | Torch F | Camera V | Use E | Bag I
Atlas M (click to travel) | Items 1 2 3 | Bow hold click | Zoom hold Z | Photo P
Rain R | Graphics G | Skip time T | Hide HUD H | Journal J | New run N | Pause Esc
Touch and gamepad are supported automatically.

COMBAT
Hold click to draw the bow. Everything can be shot: hyenas, wildlife, villagers, goats, cattle, donkeys, camels, chickens and soaring birds. Hit animals flee; defeated ones drop meat and return after a while.

THE WORLD
All of Ethiopia at real scale, loaded around you from real elevation data. Biomes follow altitude. Villages and towns follow regional architecture. Sixteen historic sites stand at their real coordinates and real sizes where known: Lalibela, Aksum, Gondar, Harar, Yeha, Debre Damo, Konso, Tiya, Sof Omar, Hadar, Mekelle, Entoto, Debre Libanos and Adwa. Walk up to one to log it in the Journal.

CONFIGURATION
Edit config.js for start region, world size, relic count, field of view, day length and speeds. Add ?region=simien (or bluenile, bale, lalibela, entoto, tana, aksum, rift, omo, dallol, harar) to the address.

FILES
index.html, style.css, config.js, game.js, controls.js, sw.js, manifest.webmanifest, icons/

SIZES
Verified from published sources: Bete Medhane Alem 33.5 x 23.5 x 11.5 m; Bete Giyorgis trench 12 m deep; Yeha temple 18.5 x 15 m, 14 m walls; Fasil Ghebbi 900 m wall, Fasilides' castle 25 x 25 m with a 32 m tower; Aksum stelae 20.6 m, 24.6 m and the fallen 33 m stele; Tiya 36 stelae; Debre Damo 15 m cliff. Estimated where no figures were found: St Mary of Zion, Mekelle palace, smaller Gondar palaces, Konso and Harar buildings.
