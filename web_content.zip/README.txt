SmartWeight AI — Zipped Site
IMPORTANT: This is a web/PWA-style estimator for "Zipped site" builders.
index.html is intentionally at the ZIP ROOT because the builder requires it.

Upload this ZIP directly in the builder shown in your screenshot.

It uses camera/photo input and dimensions/material density to ESTIMATE weight.
It does not turn the phone into a real weighing scale.
