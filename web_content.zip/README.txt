GEOLINIX Complete Web Package v0.8.0

CONTENTS
- index.html: app entry point (must stay in the ZIP root)
- styles.css: responsive mobile styling
- app.js: navigation and local interface behavior
- manifest.json: web app metadata

HOW TO USE
1. Extract this ZIP.
2. In your ZIP-to-APK builder, select this ZIP.
3. If the builder offers a preview, it should load index.html from the root.
4. Build only as a test APK first.

IMPORTANT
This is a complete front-end prototype package, not a production service.
GEO AI intentionally does not fake answers: it displays that the secure AI backend
is not connected. Live AI, online login/accounts, real maps/GPS, realtime messaging,
payments, cloud sync and business publishing need backend/provider setup.
Do not put private API keys inside app.js or any file shipped in an APK.
An adult/guardian should manage any developer accounts, API billing and public release.
