BADRA Adiestramiento v5 - aplicación web empaquetable como APK.
