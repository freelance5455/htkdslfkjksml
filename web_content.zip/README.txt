GST & Income Tax Calculator

Upload index.html directly, or upload this ZIP to an HTML-to-APK builder.
The calculator is bundled as a local HTML file and is intended to run offline.
App display name suggestion: GST Tax Calculator
Package name suggestion: com.mohsin.gsttaxcalculator
