PROJECT: UNCHAINED — 2D Prototype 0.1

RUN ON ANDROID
1. Download unchained_2d_android.zip and extract it.
2. Open index.html with Chrome or another modern browser.
   If your file manager won't open it directly, upload index.html to a static host or open it on a computer first.
3. Tap BOSHLASH. Landscape orientation is recommended.
4. Touch controls: left/right buttons, up to jump, pink ✦ to attack.
   Keyboard: A/D or arrows to move, W/Space to jump, J to attack, E near the end to interact.

WHAT'S INCLUDED
- 2D side-scrolling neon city
- Movement, jumping, energy pulse/attack, enemies, vitality
- Public Trust and Fear meters
- A story decision with two distinct ending branches

LIMITATIONS
- This is a small browser prototype, not a finished commercial game.
- Art is drawn with canvas shapes; there are no imported sprites, music, saves, or levels beyond the prototype.
- The decision is a simple branch; more missions and deeper consequences can be added later.
- Android browser support varies. Chrome is recommended; a static web host is the easiest way to run it if local HTML opening is blocked.
