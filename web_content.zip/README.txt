EUROPATH PRO starter website

Contents:
- index.html: the website entry page required by APK Forge's "Zipped site" option.

How to use:
1. Upload this ZIP to APK Forge using "Zipped site".
2. The archive must contain index.html at its ROOT (not inside an extra folder). This ZIP is structured that way.
3. Preview the page first, then follow APK Forge's create-app steps.

Important:
This is a front-end starter/demo. Real interactive maps, navigation, live public transport schedules, restaurant details, weather, and booking APIs must be connected separately. Do not describe demo prices or actions as live/confirmed services.
