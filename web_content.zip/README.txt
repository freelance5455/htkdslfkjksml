HABITLY - OFFLINE ANDROID APP (full project)

This is a real Android project. The whole app is stored inside it, so the
finished APK works with NO internet. Habits are saved on the phone.

OPTION A - Android Studio (on a computer)
1. Unzip this file.
2. Open Android Studio > Open > pick the unzipped folder. Wait for the sync.
3. Menu: Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Click "locate" - copy app-debug.apk to your phone and tap it to install.

OPTION B - free online build with GitHub (on a computer, no coding)
1. Make a free account at github.com and create a new repository.
2. Click "uploading an existing file" and drag in everything from the
   unzipped folder (hidden folders are skipped on some systems).
3. Click Add file > Create new file. Name it:  .github/workflows/build.yml
   Paste in the text from build-workflow.txt and commit.
4. Open the Actions tab > Build APK > wait a few minutes.
5. Download "Habitly-APK" at the bottom of the finished run, unzip it,
   and install app-debug.apk on your phone.

On the phone: allow "Install unknown apps" for your browser/files app.
