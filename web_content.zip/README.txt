PRIME Android project — 30-day challenge edition
=================================================
Features:
- PRIME welcome screen with creator credit: ANSHUMAN JAT
- User name onboarding
- Study or Fitness challenge selection
- User-defined repeated daily tasks
- 30-day commitment confirmation
- Daily task check-off and submission
- A missed day marks the challenge failed
- Completing all 30 days marks it completed
- Challenge history stores completed and failed challenges
- Offline local storage; no login/server required

Build APK:
1. Install Android Studio on a computer.
2. Open this PRIME_Android_Project folder.
3. Let Gradle sync complete (internet is needed once for Android Gradle Plugin).
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find app-debug.apk in app/build/outputs/apk/debug/.

Note: This ZIP contains Android Studio source files, not a compiled APK.
Challenge timing is evaluated when the app is opened; Android may suspend an
app in the background, so this app checks for a missed day on the next launch.
