LEGEND CLIENT LAUNCHER - WEBSITE ZIP PROTOTYPE

How to use:
1. Upload this ZIP to your ZIP-to-APK website wrapper app.
2. The ZIP contains index.html at the root, as the converter requested.
3. Choose the WebView/website app option if asked.

Important:
This is a visual website prototype only. It does not launch Minecraft, download game files,
sign into Microsoft, install mods, or provide real game controls. A ZIP-to-APK converter wraps
the website in an Android app; it does not turn it into a native Minecraft launcher.
