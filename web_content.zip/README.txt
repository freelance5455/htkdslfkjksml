FUTBOL GAMES — SAYT FAYLLARI

1) APK faylını bu qovluğa əlavə et:
   downloads/futbol-games.apk

2) Saytı pulsuz yayımlamaq üçün:
   - Netlify və ya GitHub Pages kimi statik sayt hostinqindən istifadə et.
   - Bu ZIP-i aç və içindəki faylları hostinqə yüklə.
   - Sayt yayımlandıqdan sonra sənə internet linki veriləcək; həmin linki Chrome-da açmaq olar.

3) Öz domenin (məsələn, futbolgames.az) ayrıca alınmalı və hostinqə qoşulmalıdır.
   Domenin mövcudluğu və qiyməti qeydiyyatçıdan asılıdır.

Qeyd:
- Bu paket sayt şablonudur, özü-özünə internetdə yayımlanmır.
- APK bu paketə daxil deyil. Öz hazırladığın APK faylını downloads qovluğuna
  futbol-games.apk adı ilə qoy.
- İnsanlar APK-nı brauzerdən endirəndə Android təhlükəsizlik xəbərdarlığı görə bilər.
  Yalnız öz hazırladığın, yoxlanılmış APK faylını paylaş.
