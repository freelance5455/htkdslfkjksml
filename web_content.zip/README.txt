JAIBIR – SPOKEN MANDARIN PROGRESSIVE COURSE UPDATE

This build includes:
- Days 1–7: 70 distinct new words.
- Every example sentence includes Chinese, tone-marked Mandarin Pinyin, easy Hindi pronunciation, and Hindi meaning.
- Daily practice: up to 15 guided repetitions with word and sentence pronunciation support.
- Main Test: exactly 20 prompts per lesson: 10 MCQs + 10 verbal prompts.
- No Chinese handwriting or copying exercises.

Important: This starter build contains detailed lessons only for Days 1–7. The 90-day roadmap is included, but detailed Days 8–90 vocabulary and lesson questions are not yet authored.
