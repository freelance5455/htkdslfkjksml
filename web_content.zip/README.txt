業務記録アプリ - APK変換用Webサイト

ZIPを展開すると index.html / css / js / manifest.json が入っています。
ZIP→APK変換サービスでは、このZIPをそのまま指定してください。
index.htmlはZIPのルートにあります。
