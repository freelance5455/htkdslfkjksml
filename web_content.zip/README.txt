MediAI — Multi-model manager update

Files:
- MediAI_ChatGPT_Style.html

Updates:
- Removed the fixed Gemma 3 download card and Gemma-specific branding.
- Added an AI model library that can import multiple local model files.
- Added direct HTTPS model download with progress (the server must allow browser CORS access).
- Added a saved-model list with active model selection and delete controls.
- Added permission information and a browser notification permission request.
- Uses browser IndexedDB for model file storage.

Important limitations:
- This HTML preview stores files and remembers which one is selected; it does not execute model files.
- Actual model inference requires a compatible native Android runtime or an online AI backend that supports the selected model.
- A browser cannot grant itself unrestricted Android storage access. The Android file picker handles user-selected files.
- Notification permission does not mean reminders are scheduled. This preview currently has no notification scheduler.
- Large model files may exceed browser storage limits. Some model hosting sites block browser fetches (CORS) or require account/licence acceptance; in that case download through the browser and import the file.
- MediAI is for medical education, not diagnosis or prescribing.
