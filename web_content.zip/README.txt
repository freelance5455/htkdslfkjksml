CredPay Calculator - Web App
=============================
Open index.html in a modern browser. This is a local-first web application; transaction records and settings are stored in the browser's localStorage on that device.
For an Android APK, you can use Android Studio with a WebView wrapper or package this project with a compatible web-to-APK workflow. This file alone is a browser app, not an APK.
Features: Model A/Model B calculator, editable fields, range sliders + direct entry, local transaction history, status management, filters, CSV export, settings, combined-transfer fee grouping.
Compliance: this app records calculations only and does not process payments. Verify relevant card-network, issuer, payment-provider and Indian regulatory requirements before real-world use.
