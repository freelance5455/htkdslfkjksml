AoT Chess PWA - deployment
1. Upload ALL files in this folder (index.html, sw.js, manifest.webmanifest, 4 icons) to a free HTTPS static host
   (Netlify Drop, GitHub Pages, Cloudflare Pages). It must be served over https.
2. Open the link in Chrome on Android > menu > Install app. On iPhone: Safari > Share > Add to Home Screen.
3. Open it once while online so the 3D libraries and fonts get cached; after that it works offline (except online play).
4. Updating: change files, then bump VERSION in sw.js (e.g. aot-v3) so installed copies refresh.
Online play: Menu > Create game, share the code; the other phone taps Join game. Uses PeerJS public signalling (needs internet).
