MORNING HUB APP
================
Install on Android (no Play Store needed):
1. Upload this folder to any free host (Netlify Drop: app.netlify.com/drop, or GitHub Pages).
2. Open the link in Chrome on your phone -> menu (3 dots) -> "Install app" / "Add to Home screen".
3. It then opens full-screen like a normal app and works offline.

Real APK file (optional):
- Go to pwabuilder.com, paste your hosted link, choose Android -> Download. You get a signed .apk to install directly.

Daily use:
- Google Sheet -> File -> Download -> Microsoft Excel (.xlsx)
- App -> Settings -> "Import Excel (new orders)" adds only new orders and keeps your delivered/paid marks.
- Settings -> Backup (JSON) saves everything; Export CSV opens in Excel/Sheets.

AUTO-SYNC FROM GOOGLE SHEET
- In Google Sheets: Share -> General access -> "Anyone with the link" -> Viewer.
- In the app: Settings -> paste the sheet link -> "Save & sync now".
- After that it syncs on every app open, every 5 minutes, and with the refresh button on the Today tab.
- The file must be a real Google Sheet (if it is an .xlsx in Drive: open it -> File -> Save as Google Sheets).

UPDATE PAID / DELIVERY / MENU FROM THE APP (one-time setup, 3 minutes)
1. Open your Google Sheet -> Extensions -> Apps Script.
2. Click "+" next to Files -> Script -> name it MorningHubAPI -> paste everything from MorningHubAPI.gs.
   (If your project already has a doPost function, tell me / rename it: only one doPost can exist.)
3. Change MH_PIN to your own PIN and save.
4. Deploy -> Manage deployments -> pencil icon -> Version: "New version" -> Deploy.
   (Execute as: Me, Who has access: Anyone. Keeping the same deployment keeps your /exec link unchanged.)
5. In the app: Settings -> Update PIN -> type the same PIN -> "Test updates" should say "Updates connected".
After that, Out for delivery / Delivered / Paid and Menu changes in the app are written to the sheet.
If the phone is offline, changes wait (shown as "to upload") and are sent when you are back online.

UPDATED SCRIPT (v2 – faster, 1 call for many orders)
If you pasted MorningHubAPI.gs earlier, replace it with the new file (or use Settings -> "Copy script code" in the app),
keep your PIN, then Deploy -> Manage deployments -> pencil -> New version -> Deploy. The app also works with the old script.
Red box at the top of Today/Orders/Menu = changes are NOT in the sheet yet; it shows the exact reason.
Settings -> "Upload all Paid/Status to sheet" sends every order's status to the sheet in one go (catch-up).

PULL DOWN TO REFRESH: on any screen, scroll to the top and pull down, then release to load the latest orders from the sheet.

v6: Edit-form buttons (Save / Cancel / Delete) fixed. New "Delivered + Paid" button. Logo is now built in.
Script v3 re-reads the sheet after every Paid/Status write and shows an error if the sheet did not keep it.
Update the script again (paste MorningHubAPI.gs, keep your PIN, Deploy -> New version).
Note: Delete in the app removes the order from the phone only; it comes back on the next sync because the sheet still has it.

v7: Today tab now opens on TOMORROW's list after 10 AM (orders are for the next morning) and on TODAY's list before 10 AM.
Today / Tomorrow buttons show how many orders each day has. A yellow "Latest order is for <date> – View" card appears when your newest order is on another day.
Flat numbers: leading zeros kept, "Flat 203" -> 203, and renamed sheet columns are found automatically. Settings shows the columns it read.
