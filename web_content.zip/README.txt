GBNPAY Demo
=============
Demo only — no real money, banking, gambling, or live transaction processing.

Run:
1. Open index.html in a browser.
2. Enter any demo mobile number.
3. OTP: 123456
4. Set any 4-digit demo PIN.
