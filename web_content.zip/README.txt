BLEACH: SOUL RHYTHM

Proyecto HTML/CSS/JS preparado para empaquetarse como APK.
Incluye teclado y controles táctiles, personajes, dificultad, música y Bankai.
Los recursos de imágenes/audio/video son remotos, por lo que el APK necesita Internet.
