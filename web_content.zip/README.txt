NAVYUVA DURGA PUJA SAMITI — PRIVACY + PRINT FIX

Changes in this ZIP:
- Added a separate “प्रिंट / PDF सेव करें” button in receipt preview. It uses Android WebView's print support when available.
- Kept “PDF डाउनलोड करें” as a separate download attempt. Some HTML-to-APK builders do not implement download handling or Android printing.
- Receipt history is filtered to the signed-in User ID in local storage and cloud query.
- Firestore rules restrict normal users to receipts whose createdBy matches their login ID; Admin can view/manage all.

IMPORTANT — REQUIRED FOR REAL PRIVACY:
The ZIP cannot publish Firebase rules by itself. Open Firebase Console > Firestore Database > Rules, replace the rules with firestore.rules from this ZIP, and press Publish. Until these rules are published, old permissive rules may still let users read other users’ receipts.

PDF/PRINT NOTE:
After creating/opening a receipt, use “प्रिंट / PDF सेव करें”. If no Android print dialog appears, the HTML-to-APK builder may not support WebView printing; use a builder that supports Android WebView printing/downloads or open the HTML in Chrome.
