ZENTRA WORLD — Prototype 0.1
Tagline: Watch. Create. Connect. Earn.

WHAT WORKS IN THIS PROTOTYPE
- Mobile-first interface and navigation
- Demo video feed and local demo post creation
- Local profile editing
- Demo wallet top-up and activity ledger
- Demo data/airtime order form and order history
- Local storage on the same browser/device
- PWA manifest and service worker for installability when hosted over HTTPS

IMPORTANT LIMITATIONS
- This is a frontend prototype, not a production financial or social platform.
- No real money is deposited or transferred.
- No real data/airtime is delivered.
- No real user accounts, server database, shared posts, cloud video hosting, creator payouts, KYC or admin security are connected.
- Demo wallet balances are not real funds and cannot be withdrawn.
- Never ask users to enter bank PINs, card PINs, passwords or OTPs into this prototype.

HOW TO TEST
1. Extract the ZIP file.
2. Open index.html in a modern browser. The interface should work for basic local testing.
3. For installable PWA behavior, upload the extracted folder to an HTTPS static host (e.g. GitHub Pages or Netlify), then open the hosted HTTPS address in Chrome on Android and choose Install app / Add to Home screen.
4. The app icon/logo is assets/logo.svg.

NEXT STEPS FOR A REAL RELEASE
1. Add a secure backend and database (accounts, posts, orders, audit logs).
2. Add authentication and role-based admin access.
3. Integrate a licensed Nigerian payment gateway for wallet funding and verify payments server-side using signed webhooks.
4. Integrate a VTU provider API for data/airtime, with server-side credentials, transaction requery, idempotency, and refund/reconciliation handling.
5. Implement video upload/storage, moderation, reporting and privacy controls.
6. Publish clear creator-reward eligibility rules and only pay rewards from a funded, auditable program.
7. Test security, privacy, failed transactions and abuse cases before launch.
