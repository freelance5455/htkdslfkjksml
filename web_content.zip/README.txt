BaatChit - SoftSpring + Cloud Sync + Story Views

IMPORTANT:
This app's original demo mode stores messages in localStorage, so two different phones CANNOT exchange messages.
The screenshots showing Anil and Reena not receiving each other's messages are consistent with Cloud/Firebase not being connected.

This ZIP keeps the existing Gallery/Photo Picker work and adds:
1) Cloud Sync setup inside the app (Menu -> Cloud Sync).
2) Same Firebase Realtime Database can be configured on BOTH phones.
3) Online/last-seen presence uses the shared database.
4) Story view tracking: viewers are recorded under storyViews and the owner sees an eye/view count.

SETUP:
A) Firebase Console -> create a project.
B) Build -> Realtime Database -> Create Database.
C) For initial testing, use rules that allow read/write. Secure them before production.
D) Project settings -> Your apps -> Web app -> copy the Firebase config.
E) Build/install this APK on both phones.
F) In BaatChit: Menu (⋮) -> Cloud Sync.
G) Enter the SAME databaseURL, apiKey, authDomain and projectId on BOTH phones.
H) Save & Connect. App reloads.
I) Login with two different 10-digit numbers (for example, Anil and Reena). Add each other's number and chat.

NOTE ABOUT NUMBERS:
If two people use different accounts, their phone numbers should be different. The screenshots show different numbers for Anil and Reena; that is normal. What was broken was cross-device data sync when Firebase was not connected.
