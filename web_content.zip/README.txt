EVSL AUTO MAINTENANCE MANAGEMENT – FULL ADVANCED v7

Included:
- Offline responsive maintenance web app (HTML)
- Hindi / English language switch
- Vehicle Master with editable vehicle details and hour-meter/month PM intervals
- Breakdown Entry with multiple spare-part rows; each part has its own part number and quantity
- Add/remove unlimited part rows in one breakdown
- Optional breakdown photo attachment (compressed before local save) and Photo view action in breakdown history
- Date-wise breakdown search and filters
- Automatic inventory stock-out by matching part number; blocks stock-out beyond available balance
- Spare Parts Inventory with separate per-part stock balance, stock in/out and low-stock warning
- Vehicle Parts Master, PM, Daily Work Report, Fault Diagnosis, Reports, Analytics
- JSON backup, restore and previous auto-backup recovery

HOW TO USE:
1. Extract the ZIP.
2. Open EVSL_Auto_Maintenance_FULL_ADVANCED_v7.html in Chrome.
3. Use the language selector for English or Hindi.
4. In Breakdown Entry, use “Add Another Part” to add each spare part with its own quantity.
5. Add a breakdown photo if required. Photos and records are stored in this browser on this device.
6. Add matching Part Numbers in Inventory for automatic stock deduction from breakdown entries.
7. Use Backup Now regularly and keep the JSON backup outside the phone.

IMPORTANT:
- This ZIP is an offline HTML web-app update, not an Android APK.
- Existing data stays in the old app/browser storage unless you export and restore a JSON backup. Do not uninstall or clear app/browser data before backup.
- Test this update with a backup copy first. Do not overwrite your only working app or data.
