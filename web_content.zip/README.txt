AS Enterprises V25 - bold old-style UI, non-green. Existing V24/V23 process and data structure retained; no app data is included in this ZIP. Installed localStorage is not erased by this package.
