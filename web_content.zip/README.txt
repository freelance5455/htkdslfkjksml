HIDDER - Web ZIP version
This ZIP is specifically for ZIP-to-APK converters that require index.html.
Important: this version is a web app. It can protect its own vault with a PIN, but
a normal web app cannot hide other installed Android apps. For true Android app
hiding, build the native Android project with Android Studio/device-owner or
launcher capabilities as appropriate.
