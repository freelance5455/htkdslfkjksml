Веб-версия Spesen und Arbeitszeiten для ZIP to APK.
index.html находится в корне архива. Тахобук не используется.
