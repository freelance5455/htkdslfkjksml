QXAI Live - APK build (Bengali / English)

GitHub Actions diye APK banano:
1. github.com e new repository banan (private rakhte paren).
2. Ei zip er sob file upload korun (.github folder shoho).
3. Actions tab > "Build APK" > Run workflow. Shesh hole Artifacts theke app-debug.apk namiye phone e install korun.

Android Studio diye: folder ta Open korun, Build > Build APK(s).

Install er por app er Settings (gear) e Twelve Data key paste kore Test chapun.
Key shudhu apnar phone e thake. Real Market analysis ei key chhara chalbe na.
Bridge shudhu https://api.twelvedata.com/ e request pathate pare.
