VaghtJo APK Package

App name: VaghtJo
Website URL: https://vaghtjo.ir/
App icon: logo.png / icons/

This package is prepared for a WebView/PWA-to-APK converter.
The entry page loads https://vaghtjo.ir/ and the manifest contains the app name and icon.
