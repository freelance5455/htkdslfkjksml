HOTEL HR MANAGER — WEB APP ZIP
================================

Contents:
- index.html: app entry point requested by HTML-to-APK converters
- style.css: responsive mobile-first styling
- app.js: app functionality

How to use:
1. Upload this ZIP to your HTML-to-APK service.
2. If the service asks for an index file, choose index.html (not .index).
3. For a local preview, open index.html in a browser.

Demo sign-in:
Username: admin
Password: admin123

Features in this prototype:
- Dashboard summary and probation alerts (next 14 days)
- Employee profiles and department/job title
- Onboarding records
- Training and tests
- Appraisals
- Counselling notes
- HR document register
- Employee CSV export and JSON backup/restore

Important limitations:
- Prototype data is stored in the browser/app local storage on that device.
- No cloud sync, multi-user access, server database, payroll integration, or real authentication.
- Demo sign-in is only a basic front-end gate and is not secure for confidential production HR records.
- Export and backup features should be tested in the target APK wrapper.
