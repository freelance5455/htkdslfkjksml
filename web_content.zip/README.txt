TAX INVOICE ANDROID APP
========================
Features:
- Edit supplier, buyer and invoice details
- Add/remove multiple items
- Automatic quantity x rate calculation
- Automatic GST split (SGST/CGST)
- Automatic grand total
- Save/load invoice on the phone
- Print / Save as PDF using Android print dialog
- Mobile-friendly interface

FASTEST USE:
1. The app source is in this Android Studio project.
2. Open the project in Android Studio.
3. Build > Build APK(s).
4. Install the generated APK on Android.

The same HTML inside app/src/main/assets/index.html can also be opened as a mobile web app.
