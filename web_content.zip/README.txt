PYQ Question Filter - APK converter version

This ZIP is made as a normal web app so a ZIP-to-APK/WebView converter that requires index.html can load it.

Important: the app uses PDF.js from cdnjs, so the APK needs internet access when reading a PDF. If your converter does not allow external JavaScript/CDN files, use a converter that supports remote scripts or package PDF.js locally.

Features:
- PDF upload
- Extract text from PDF
- Detect question-like blocks
- Rank using PYQ/exam/repeated-topic signals
- Show top questions
- Export CSV

Scanned/image-only PDFs need OCR and are not supported by this version.
