GYZ MAN - VERSION TEST

Ity dia prototype web-app tsotra natao ho an'ny Gyz man.
Misy:
- Trano
- Tany
- Zavatra maro
- Antso
- WhatsApp
- Adiresy sy email

Fanamarihana:
Ity ZIP ity dia prototype azo sokafana amin'ny navigateur. Tsy APK Android mbola izy.
Ny APK tena installable dia mila atao build Android amin'ny dingana manaraka.
