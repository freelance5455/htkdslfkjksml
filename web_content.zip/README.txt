MASTER SHIELD v1.1 update
Import the contents of the www folder into the same Android web-app builder project, replacing the old index.html and manifest.webmanifest. Then build a new APK.
Menu and Settings now open and provide basic interface controls. Device statistics and protection features are still placeholders and are not active.
