MobiCash Android
================
Projet Android prêt à être compilé en APK.
- Ouvrir ce dossier dans Android Studio.
- Attendre la synchronisation Gradle.
- Build > Build APK(s).
- Installer l'APK généré sur un téléphone Android.

Note: les missions et retraits sont encore un prototype et ne versent pas de vrais fonds.
