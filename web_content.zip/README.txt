Mr Chat FPS Pack - HTML5 bundle (index.html at the zip root).
Games: Wait for Green (reflex), Arena Waves, Maze Escape, Coin Rush, Target Gallery, Ghost Chase.
Works offline as single player. With Firebase (see FIREBASE_SETUP.txt): accounts, leaderboards,
multiplayer rooms + invites, chat servers/channels/DMs.
Controls: left thumb move, right thumb drag to look, FIRE button.
