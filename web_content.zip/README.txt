FF MAX TOURNAMENT — DEMO PROJECT
=================================

A mobile-first, static HTML/CSS/JavaScript community tournament dashboard.

IMPORTANT SAFETY & PRODUCT SCOPE
--------------------------------
This build is an independent community project and is NOT affiliated with,
endorsed by, or sponsored by Garena or Free Fire.

This is a free-entry demonstration app:
- Demo points are fictional, non-monetary, non-transferable and have no cash value.
- No real payments, deposits, paid entry fees, cash prizes or withdrawals are processed.
- The "request demo points" flow creates a pending admin-review request only.
- Cash withdrawal is intentionally disabled.
- Do not use this local demo for real-money tournaments or payment handling.

RUN LOCALLY
-----------
1. Extract the ZIP.
2. Open index.html in a modern browser, or serve this folder with a local static server.
   Example: python -m http.server 8000
3. Visit http://localhost:8000

DEMO PLAYER LOGIN
-----------------
Email: player@demo.test
Password: player123

DEMO ADMIN
----------
Open admin.html and use demo passcode: MAXADMIN26

The admin passcode is hard-coded only to demonstrate the UI. It is visible
in the client-side source and is NOT secure. Never deploy this admin login
or localStorage authentication as production security.

FEATURES
--------
- Player registration/login and local demo session
- Tournament listing and registration with UID/IGN validation
- Duplicate-registration prevention
- My Matches with admin-published room details
- Demo points balance and request history
- Leaderboard, winners and notifications
- Local admin panel for events, room details, requests, winners and notices
- Responsive bottom navigation and mobile-first layout
- Persistent demo state in browser localStorage

RESET DEMO DATA
---------------
In browser developer tools, run:
localStorage.removeItem('ffmax_demo_v1');
location.reload();

ARCHITECTURE / PRODUCTION NOTES
------------------------------
The project is organized so a future backend can replace the local data
layer. Before production, implement Firebase Authentication, Firestore
security rules, server-side authorization, trusted result validation,
rate limiting, audit logs and a secure admin role system. Never trust
client-side roles, balances, room credentials or payment status.

All tournament sample events are free-entry and use zero cash-value prizes.
