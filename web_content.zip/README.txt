MY STUDY LIFE BY ABDOULAYE - V2.0

NOUVEAUTÉS V2
- Bibliothèque locale de documents avec IndexedDB.
- Import de photos depuis le téléphone.
- Capture photo via l'appareil photo lorsque la WebView/plateforme l'autorise.
- Import de PDF.
- Classement des documents par matière.
- Filtres par matière.
- Ouverture des fichiers dans le navigateur/visionneur disponible.
- Suppression des documents.
- Dossiers de matières avec actions photo/fichier.
- Compteur de documents et indicateur de stockage.
- Interface préparée pour les prochaines fonctions Android.

IMPORTANT POUR HTML2APP
La caméra et les accès aux fichiers dépendent des permissions et des capacités de la WebView utilisée par le convertisseur.
Pour une application Android publiée, il faudra demander les permissions nécessaires et tester sur plusieurs versions Android.

Les données locales de cette V2 utilisent IndexedDB. Elles sont stockées localement et ne sont pas automatiquement synchronisées entre appareils.

La prochaine étape peut ajouter un vrai lecteur PDF intégré, édition/cadrage des photos, renommage des documents, recherche, dossiers personnalisés et notifications Android.


MY STUDY LIFE V3
================
Nouveautés :
- Bibliothèque documentaire renforcée.
- Stockage du Blob/Fichier dans IndexedDB au lieu de conserver uniquement une URL temporaire.
- Recherche instantanée.
- Tri par date, nom, taille ou favoris.
- Filtres par matière.
- Favoris.
- Renommage des documents.
- Suppression.
- Statistiques de taille réelle des documents stockés.
- Éditeur d'images intégré avec rotation gauche/droite et réinitialisation.
- Les PDF restent non modifiables et sont ouverts via le visionneur disponible sur l'appareil.
- Correction du risque d'importation en double présent dans la V2.
- Interface responsive pour petits écrans.

LIMITES V3
-----------
- Le comportement de la caméra et du sélecteur de fichiers dépend du WebView/conteneur Android utilisé par le convertisseur HTML.
- L'ouverture des PDF dépend des capacités du WebView. Pour un visionneur PDF totalement intégré et identique sur tous les appareils, une couche PDF dédiée sera nécessaire.
- L'application ne garantit pas la compatibilité avec absolument toutes les versions Android. Il faut tester le package final sur plusieurs appareils.
- L'IA réelle n'est pas encore branchée dans cette V3. Ne place jamais une clé API secrète directement dans le JavaScript client.
