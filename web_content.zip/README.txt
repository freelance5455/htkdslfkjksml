SKYSTRIKE ARENA — 3D MULTIPLAYER STARTER

CONTENTS
- index.html: game page and interface
- style.css: responsive landscape/mobile HUD
- game.js: Three.js scene, player movement, shooting, bots, and PeerJS connection
- Uses Three.js and PeerJS from public CDNs (internet required to load these libraries).

HOW TO RUN
1. Extract this ZIP.
2. Open the folder in a code editor.
3. Run index.html using a local web server (recommended), for example VS Code Live Server.
4. On a phone, open the hosted page in Chrome and rotate to landscape.
5. Training Mode works locally. For online rooms, both players must be online and use the same hosted page; one player creates a room and shares the room code.

IMPORTANT
This is a playable starter prototype, not a finished commercial battle royale or a Free Fire replacement.
The online mode is a basic PeerJS peer connection demonstration, not authoritative matchmaking or anti-cheat infrastructure. For a real public multiplayer game you will need a dedicated game server, accounts, matchmaking, persistence, optimized art/audio assets, and extensive testing.
The game uses simple procedural 3D shapes rather than high-end custom models.
