MITIA WARFARE — Prototype 0.3

Fanovana:
- Namboarina ho HTML tokana tsy miankina amin'ny CDN, ka afaka misokatra offline amin'ny navigateur Android maoderina.
- Tsy aseho intsony ilay hafatra lehibe hoe “ahodino ny findainao...” ao amin'ny lalao; misy fanamarihana kely ao amin'ny menu ihany. Miezaka manidy orientation ho landscape rehefa manomboka, raha avelan'ny navigateur.
- Safidy Map 4: Training Yard, Desert Base, Forest Camp, Urban Ruins.
- Solo mode: tsy mila internet.
- +10 points rehefa mamono bot; anaran'ny mpilalao sy bots azo ovaina.

ZAVA-DEHIBE:
- Ny Multiplayer Wi-Fi/hotspot sy En ligne dia mbola tsy tena mandeha. Ny tena multiplayer dia mila server/communication layer sy testing amin'ny fitaovana maromaro. Ny menu dia manazava izany ary tsy milaza fa efa mandeha.
- Ity dia prototype HTML, fa tsy APK Android.
- Sokafy ny ZIP, esory (Extract), dia sokafy ny index.html amin'ny Chrome. Raha tsy misokatra amin'ny file manager, ampiasao navigateur afaka manokatra HTML local.
