TEMPLE RUN 3D ADVENTURE — উন্নত 3D সংস্করণ

চালাতে:
1) ZIP Extract করুন।
2) index.html Chrome-এ খুলুন। Three.js CDN থেকে আসে, তাই ইন্টারনেট সংযোগ দরকার।
3) Swipe: বামে/ডানে লেন, উপরে লাফ, নিচে স্লাইড।
   Keyboard: Arrow keys / WASD.

এই সংস্করণে 3D perspective camera, lighting, shadows, fog, পাহাড়, জঙ্গল, মন্দিরের গেট,
3D রানার চরিত্র ও চলমান হাত-পা, ৪ ধরনের বাধা, ৩ ধরনের কয়েন, ৪টি চরিত্র,
স্কোর/গতি/কয়েন, গেম ওভার ও চরিত্র আনলক রয়েছে।

এটি HTML গেমের ZIP, APK নয়। Android APK করতে হলে WebView/Android Studio দিয়ে প্যাকেজ করতে হবে।
