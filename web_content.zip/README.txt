MY STUDY DIARY — ANDROID-FRIENDLY WEB APP

FILES
- index.html: the app
- manifest.json: install metadata
- sw.js: offline cache helper

EASIEST WAY TO USE
1. Open index.html in a modern browser to preview it.
2. To install it like an app, the files must be hosted on an HTTPS static host (for example GitHub Pages or Netlify).
3. Open the hosted HTTPS link in Chrome on Android, open the browser menu, and choose “Install app” or “Add to Home screen” if available.

IMPORTANT
- This project is a web app/PWA source project, not an APK. It cannot be installed by tapping the HTML file alone.
- Daily task and subject checkmarks are saved in browser local storage on that device/browser.
- No account is needed. Clearing browser data can erase saved progress.
