DAVOMAT — tayyor web ilova
Login: admin
Parol: 12345

index.html faylini brauzerda ochish mumkin.
APK qilish uchun ZIP ichida index.html eng yuqori papkada bo‘lishi kerak.
Ma’lumotlar localStorage’da saqlanadi.
