नवयुवा दुर्गा पूजा समिति — Chanda Receipt App

यह self-contained HTML app है। इसे किसी ऐसे HTML-to-APK/WebView builder में खोलें जो local HTML/JavaScript चलाता हो।

मुख्य सुविधाएँ:
- पहली स्क्रीन पर full-screen Maa Durga artwork
- चंदा रसीद form
- automatic receipt number
- receipt history (localStorage)
- receipt पर छोटी Maa Durga image
- PDF सेव करने का वास्तविक client-side PDF generator
- Android Share/WhatsApp sharing support
- कोई external image/CDN dependency नहीं

APK बनाने के लिए:
1. index.html को ZIP से निकालें।
2. किसी HTML-to-APK/WebView builder में local HTML project के रूप में import करें।
3. JavaScript और file download/share permissions enabled रखें।
