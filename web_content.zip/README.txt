RUNNER AUTOPILOT — WEB PACKAGE + NATIVE APP SPEC

Files:
- index.html: the supplied Coin Runner demo game with its own internal autopilot.
- RUNNER_AUTOPILOT_NATIVE_APP_SPEC.md: specification for the actual Android app intended to observe an external runner game and use screen capture + accessibility gestures.

IMPORTANT:
This ZIP is not a finished Subway Surfers auto-player APK. The HTML demo autopilot reads its own JavaScript game state, so it cannot automatically see Subway Surfers. A real external-game controller requires native Android MediaProjection screen capture, visual obstacle detection/calibration, and an AccessibilityService for gestures, with user-granted permissions. A simple HTML-to-APK wrapper cannot implement those native features by itself.

For an HTML-to-APK website, upload this ZIP only if the builder accepts a root index.html. That will package the demo, not the full native autopilot. For the real app, use the included specification in a native Android-capable builder.
