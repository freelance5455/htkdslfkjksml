AI SIGNAL LAB — HTML TO APK PACKAGE

IMPORTANT:
1. Keep index.html in the ROOT of the ZIP.
2. In your "HTML to APK" app choose "ZIP File to APK".
3. Select this ZIP.
4. Build the APK.

The app is designed as a mobile WebView website and does not require Android Studio.

LIVE DATA:
- Demo mode works without an API key.
- Live mode uses Twelve Data 1-minute forex time-series data.
- Enter your own Twelve Data API key inside the app.
- The app does NOT claim guaranteed accuracy.
- 5/10/15/30/60 second selections are forecast horizons; the supplied endpoint is 1-minute data, not a true 5-second tick feed.
- No automatic real-money trade execution is included.

SUPPORTED PAIRS:
EUR/USD, GBP/USD, USD/JPY, EUR/JPY, AUD/USD, USD/CAD, USD/CHF, NZD/USD

SIGNAL LOGIC:
EMA 9/21 + RSI 14 + short momentum. Weak setups return WAIT.
