Для HTML to APK: выбери ZIP File to APK и загрузи этот архив. Главная страница сайта — index.html.
