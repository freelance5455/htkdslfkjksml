Pragmatic RTP Analyzer

Готовый HTML + Android WebView проект.
1) index.html можно загрузить в HTML-to-APK сервис.
2) Для Android Studio используйте app/ и settings.gradle.
Важно: приложение не может изменить RTP/RNG/MAX WIN на стороне казино; переключатели являются режимами анализа интерфейса.
