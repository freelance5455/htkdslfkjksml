Football Draft Game - Web APK package
Main file: index.html
Upload this ZIP to a web-to-APK builder that accepts an HTML ZIP containing index.html.
