HTML & ZIP FILE TO APK BUILDER

Main file: index.html

FLOW:
Choose ZIP -> Preview -> Create App -> Build APK -> Download APK -> Install APK

The frontend is functional:
- imports HTML or ZIP
- validates ZIP and finds index.html
- previews HTML
- collects app name/package/version/icon
- stores unlimited My Apps records in localStorage
- calls a real APK build server
- receives apkUrl or polls a jobId
- provides Download APK and Install APK buttons
- can also export the web assets as an Android-project ZIP

REAL APK REQUIREMENT:
A normal HTML file cannot compile an arbitrary Android APK binary or silently install
one. For genuine APKs, configure a secure Android/Gradle build server under:
Menu -> Build Server Settings.

POST /build multipart fields:
webProject, appName, packageName, versionName, versionCode

Response option A:
{"apkUrl":"https://server.example/app.apk"}

Response option B:
{"jobId":"abc123"}

Polling:
GET /build/abc123
{"status":"building","progress":50}
then:
{"status":"complete","progress":100,"apkUrl":"https://server.example/app.apk"}

Production server requirements:
- sandbox every uploaded project
- reject path traversal in ZIPs
- enforce file-size/time limits
- do not execute uploaded JavaScript during build
- isolate each Gradle build
- sign APKs with a protected signing key
- authenticate/rate-limit the API
- scan/validate output before returning it

UNLIMITED APPS:
There is no build-count limit in this frontend. Actual server storage/build capacity
is the only practical limitation.
