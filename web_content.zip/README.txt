My Notebook — Web APK Builder package

Upload this ZIP to your web-to-APK builder. The HTML entry page is located at web/index.html because the builder's WebView URL is https://appassets.androidplatform.net/web/index.html.

This is the web bundle only, not a compiled APK. If your builder still returns ERR_HTTP_RESPONSE_CODE_FAILURE, confirm that it accepts ZIP uploads with a top-level web/ folder. If it expects index.html at the ZIP root, use its required folder structure instead.
