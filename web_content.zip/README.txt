Math AI Assistant — website-ready starter

1. Extract the ZIP.
2. Upload index.html to your website hosting.
3. Open the page and enter your own Gemini API key under “API setup”.
4. To make an APK, use a reputable website-to-APK/PWA wrapper; the wrapper itself may charge fees.

Security:
- The API key included in your original message appears exposed. Revoke it and create a new key.
- Do not put API keys directly into public HTML. This demo asks for the key at runtime and does not save it.
- For a public app, use a backend proxy to protect the key.
- Free API quotas and availability depend on Google’s current terms.
