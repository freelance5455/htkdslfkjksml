ACCOUNTING SYSTEM — PWA PACKAGE (with cross-device sync)
==========================================================

WHAT'S IN THIS ZIP
-------------------
index.html, bundle.js, styles.css   — the app itself (bundled, no build step needed)
manifest.webmanifest                — PWA metadata (name, icons, colors)
sw.js                                — service worker (offline caching)
icons/                                — app icons (192, 512, maskable 512)
firestore.rules                     — security rules to paste into Firebase (sync setup)

Data is stored locally (works fully offline) and, once you set up sync
(Part 2 below), mirrored to your own free Firebase project so every device
using the same "sync code" sees the same ledger.

Default login: username "admin", password "admin123" (change it after first
login from Users & Roles, or add real users there). Note this app login is
separate from the sync code — the app login controls who can use the app;
the sync code controls which devices share the same data.


PART 1 — HOST THE PWA
-----------------------
A PWA must be served over HTTPS (localhost also works for testing) — it can't
be opened as a bare file:// page because service workers require a real origin.

Easiest free options:
  - GitHub Pages: create a repo, push these files, enable Pages.
  - Netlify / Vercel: drag-and-drop this folder in their web dashboard.
  - Your own server: upload as-is to any static host / Nginx / Apache root.

To test locally first:
  cd this-folder
  python3 -m http.server 8080
  open http://localhost:8080 in Chrome on your phone or desktop.


PART 2 — TURN ON CROSS-DEVICE SYNC (free, ~5 minutes)
--------------------------------------------------------
Without this step, the app still works great — it just keeps each device's
data separate. To make phone/tablet/laptop share one ledger:

1. Go to https://console.firebase.google.com and create a new project
   (free "Spark" plan — no credit card needed).

2. In the project, go to Build → Firestore Database → Create database.
   Start in production mode, pick any region.

3. Go to the Rules tab of Firestore and paste in the contents of
   firestore.rules (included in this zip), then Publish.

4. Go to Build → Authentication → Get started → enable "Anonymous"
   sign-in method. (This lets devices connect without needing their own
   login — the "sync code" is what actually keeps data separated/shared.)

5. Go to Project settings (gear icon) → General → scroll to "Your apps" →
   click the Web icon (</>) → register an app (any nickname) →
   copy the firebaseConfig object it gives you.

6. Open src/firebase-config.js in the project source and paste in those
   values in place of the YOUR_... placeholders. (If you only have this
   built zip and not the source project, message me and I'll hand you the
   full source folder — you need the source to rebuild after editing this
   file, since bundle.js is a compiled output.)

7. Rebuild:
     cd pwa-app
     npx tailwindcss -i ./src/input.css -o ./styles.css --minify
     npx esbuild src/index.jsx --bundle --minify --loader:.js=jsx --outfile=bundle.js
   Then re-copy index.html, bundle.js, styles.css, manifest.webmanifest, sw.js,
   icons/ into your hosted folder and re-deploy.

8. Open the app on your first device, expand the top menu, and type any
   sync code you like (e.g. "smith-books-2026") into the "Enter a sync
   code…" field, then tap Connect. Do the exact same on every other device.
   All of them will now read and write the same cloud copy — changes on one
   show up on the others within a couple of seconds (or tap "Sync now" to
   force an immediate pull).

Treat the sync code like a shared password — anyone who knows it can read
and write that ledger. Don't use anything guessable, and don't share it
outside your team.


PART 3 — TURN THE HOSTED PWA INTO AN APK
-------------------------------------------
Once it's hosted at a public HTTPS URL, use one of these (both free, no
Android Studio required):

  Option A — PWABuilder (easiest, browser-only):
    1. Go to https://www.pwabuilder.com
    2. Enter your hosted URL and click "Start".
    3. Click "Package for stores" → Android → download the APK.
    4. Install it on an Android device (enable "install from unknown
       sources") or upload it to Google Play.

  Option B — Bubblewrap CLI (more control, needs Node + Java + Android SDK):
    npm i -g @bubblewrap/cli
    bubblewrap init --manifest https://your-url.com/manifest.webmanifest
    bubblewrap build


NOTES
-----
- Sync setup (Part 2) is optional — skip it if every device using this app
  is fine keeping its own separate data.
- APK signing needs the Android SDK/build tools, which aren't available in
  this environment — Part 3's tools are the standard free way to finish
  that step yourself.
- If you update the app source later, re-run the build commands in step 7
  and re-zip/re-deploy.
