1-sinf uchun 50 ta xitoy tili mini-darsi.
Pinyin → tovushlar → so‘zlar → gaplar → o‘yinli takrorlash.
