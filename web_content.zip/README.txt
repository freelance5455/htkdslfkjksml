BENGKEL AL BONYOX - APLIKASI STRUK OFFLINE

Cara menggunakan:
1. Buka index.html di Chrome Android atau komputer.
2. Isi pelanggan, kendaraan, nomor polisi, KM dan mekanik.
3. Tambahkan jasa/sparepart.
4. Masukkan diskon dan pembayaran.
5. Tekan CETAK STRUK.
6. Pilih printer yang tersedia pada dialog cetak Android/komputer.

Catatan:
- Aplikasi ini offline dan menyimpan data transaksi di perangkat menggunakan localStorage.
- Format dirancang untuk struk bengkel dan logo AL BONYOX.
- Untuk printer thermal Bluetooth ESC/POS, dukungan pencetakan langsung tergantung Android/printer. Jika printer tidak muncul di dialog cetak, gunakan aplikasi bridge ESC/POS seperti Cleanter.
