GHOST BOX PRO 3.0 – ALAIN DELAY EDITION

Enthalten:
- index.html: vollständiger App-Inhalt
- manifest.webmanifest: App-Metadaten
- sw.js: Offline-Cache
- icons/: App-Symbole

APKForge:
1. Öffne dein Projekt in APKForge.
2. Wähle gebündelten Inhalt / Startseite index.html.
3. Ersetze den bisherigen Inhalt durch diese V3-Dateien (falls APKForge ZIP-Import unterstützt, den gesamten Ordner/ZIP importieren; andernfalls Dateien einzeln hinzufügen).
4. Vergib eine neue Paket-ID, z. B. com.alaindelay.ghostboxpro.v3, damit die alte Installation unangetastet bleibt.
5. App-Name: Ghost Box Pro 3.0.
6. Baue die APK und teste sie, bevor du die alte App entfernst.

Hinweis: Das ist der neue App-Inhalt, noch keine APK. Eine neue Paket-ID erzeugt eine zweite App-Installation. Die alte App bleibt dadurch als Rückfallebene erhalten.
Die App synthetisiert Wörter und Audio; sie empfängt keine realen Funk- oder Geisterstimmen.
