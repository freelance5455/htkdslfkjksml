MedsReminder v1.01 - Final Android APK Build Package
======================================================
Version: 1.01
Release Date: 2026-10-29

Features in v1.01:
- 3-Line Hamburger Menu integrating Push Notification Settings, Profile Manager, History & Alerts
- Draggable Course Window timeline synchronized with prescription days
- Thick checkmark (✔) on day tab upon taking all doses of the day
- Strict future date lock: doses on future dates cannot be marked as taken in advance
- Adaptive course duration (days, weeks, months) and smart pill inventory restock suppression

How to build your APK:
1. Visit https://www.pwabuilder.com
2. Upload this package or host index.html on GitHub Pages / Netlify / Vercel
3. Generate signed or debug APK for Android install.
