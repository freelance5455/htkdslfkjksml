AROMA COLLECTION — OWNER: AMIR SERAJ
Hindi + English sandal/shoes store prototype

WHAT’S INCLUDED
- Hindi/English toggle
- Product listing, search, categories, cart preview
- Local demo product editor: name, price, stock, category, photo
- CSV bulk import/export
- WhatsApp, Gmail, Instagram, Facebook and Snapchat link buttons
- Owner name Amir Seraj shown in the store

IMPORTANT LIMITATIONS
- This ZIP is a website/HTML prototype, NOT an installable Android APK.
- Product edits and social links are saved only in the current browser/device.
- It does NOT yet sync prices to customers’ other phones.
- The PIN is demo-only and is NOT secure production authentication.
- To make all installed apps update together, configure hosting + a shared online database + server-side admin authentication, then build/package the Android app.
- Replace social/contact links with the owner’s actual account details before launch.

OPENING
Open index.html in a browser to preview the prototype.
