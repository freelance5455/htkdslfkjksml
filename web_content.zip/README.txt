TallerPro v1 - aplicación privada de gestión de taller.

Incluye:
- PIN de acceso en el dispositivo.
- Clientes.
- Vehículos.
- Órdenes de trabajo.
- Estados de reparación.
- Búsqueda.
- Datos persistentes mediante IndexedDB.
- Funciona como PWA instalable.

IMPORTANTE:
Esta primera versión guarda los datos en el dispositivo/navegador. No hay todavía sincronización en la nube ni copia automática entre móviles. Para una versión de producción, la siguiente fase debe añadir una base de datos privada en la nube y copias de seguridad.
