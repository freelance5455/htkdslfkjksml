नवयुवा दुर्गा पूजा समिति - Updated App

इस ZIP में:
1. index.html - पूरा mobile-friendly चंदा बुक/रसीद app
2. durga.jpg - पहली स्क्रीन के लिए केवल माँ दुर्गा की तस्वीर

Features:
- पहली स्क्रीन पर full-screen Maa Durga image
- Automatic receipt number
- नाम, मोबाइल, पता, राशि और तारीख
- रसीद local storage में save
- चंदा बुक में सभी records, search और total amount
- PDF सेव/डाउनलोड
- WhatsApp share (फोन/WebView की सुविधा के अनुसार)
- चंदा बुक का summary PDF

APK बनाने के लिए किसी HTML-to-APK builder में index.html को start/entry file रखें और durga.jpg को उसी folder में रखें.
