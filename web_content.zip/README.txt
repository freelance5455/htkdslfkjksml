FOREX LEARNING LAB — ZERO TO HERO (DETAILED LESSON BUILD)

This is a rebuilt HTML/PWA learning app package, not a compiled Android APK.

Included:
- 30 beginner lessons in English
- Expanded lesson-specific explanations, diagram-reading guidance, worked examples and common mistakes for all 30 topics
- Original SVG teaching diagrams (schematic examples, not live charts)
- Quizzes with answer feedback
- Local lesson progress and quiz scores
- Risk/position-size learning calculator and practice tools from the existing build

Preview: open index.html in a browser. Some PWA installation features require HTTPS hosting.

To create an APK, import the complete extracted folder into your chosen trusted web-to-APK builder. The ZIP itself is not an APK. Review permissions and builder privacy before installing.

UPDATE: Each lesson now includes a side-by-side bullish and bearish candlestick example panel. These are schematic educational illustrations, not live signals or predictions.
