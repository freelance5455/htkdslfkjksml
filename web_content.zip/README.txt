KANONA FC ANDROID APP — SOURCE PROJECT

This Android Studio project wraps the supplied Kanona FC supporters' website in an Android WebView.

Included:
- Supplied website HTML in app/src/main/assets/index.html
- Android launcher app named Kanona FC
- Placeholder images for referenced image filenames

Important:
- Placeholder images are not the official club badge/team photos; replace them with the real image files.
- This ZIP is Android Studio source, not a compiled APK. Android SDK/build tools are not installed in this environment, so I cannot compile the APK here.
- The website uses the data from the supplied HTML and is not connected to live Supabase data yet.

Build the APK:
1. Install Android Studio on a computer.
2. Open the extracted folder containing settings.gradle.
3. Let Android Studio sync and install required SDK components.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The APK will normally be at app/build/outputs/apk/debug/app-debug.apk.

Application ID: com.kanonafc.app
Minimum Android: Android 6.0 (API 23)


NEW: Tap any fixture to open match lineup and player ratings. In this demo, lineup and ratings save locally on the device; online admin syncing is not yet connected.
