MY DAY PRO — HTML/ZIP to APK uchun
1. htmltoapp.net saytini oching.
2. Upload HTML or ZIP bo‘limida ushbu ZIP faylni tanlang.
3. App name: MY DAY PRO.
4. Package name: com.mydaypro.app
5. Build APK tugmasini bosing va tayyor APKni yuklab oling.
6. Telefon sozlamasida noma’lum manbadan o‘rnatishga ruxsat bering.

Eslatma: bu ZIP ichidagi HTML ilova vazifalar, qaydlar, maqsadlar va backupni
localStorage orqali telefonda saqlaydi va HTML fayllari APK ichiga joylangani
uchun internet talab qilmaydi. Umumiy HTML-to-APK WebView konvertori o‘zi
Android AlarmManager native integratsiyasini bermaydi. Shu sababli ilova
yopiq yoki telefon qayta yoqilgan holatda aniq vaqtdagi signal kafolatlanmaydi.
Buning uchun alohida native Android loyihasi/AlarmManager ko‘prigi kerak.
