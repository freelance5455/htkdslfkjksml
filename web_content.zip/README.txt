PRIME Android project — 30-day challenge + permanent rank system
================================================================
Features:
- PRIME welcome screen with creator credit: ANSHUMAN JAT
- User name onboarding
- Direct daily-task setup (no Study/Fitness goal-selection screen)
- User-defined repeated daily tasks
- 30-day commitment confirmation
- Daily task check-off and submission
- A missed day marks the challenge failed
- Completing all 30 days marks it completed
- Challenge history stores completed and failed challenges
- Permanent rank points: +10 for each submitted day; -2,000 when a challenge fails
- Rank progression: Bronze 1–4, Silver 1–4, Gold 1–5, Platinum 1–5,
  Diamond 1–5, Heroic 1–5, Elite Heroic 1–6, Master 1–6,
  Elite Master 1–6 (highest)
- Higher ranks require progressively more rank points
- Rank shortcut at the top opens the full rank list and progress
- Rank points and challenge history are saved locally on the device
- Offline local storage; no login/server required

Build APK:
1. Install Android Studio on a computer.
2. Open this PRIME_Android_Project folder.
3. Let Gradle sync complete (internet is needed once for Android Gradle Plugin).
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find app-debug.apk in app/build/outputs/apk/debug/.

Note: This ZIP contains Android Studio source files, not a compiled APK.
Challenge timing is evaluated when the app is opened; Android may suspend an
app in the background, so this app checks for a missed day on the next launch.


VERSION 4 UPDATE:
- Added Player Profile screen on app launch for returning users without an active challenge.
- Active challenge dashboard shows player name, current rank, rank points, and completed/failed challenge totals.
- Profile shows completed/failed challenges, highest rank reached, total completed days, and active challenge status.
- Rank history remains stored locally on the device.

VERSION 5 UPDATE — PERSONAL COMPETITORS & LEADERBOARD:
- First-time setup asks for the user's name, daily tasks, and four unique competitor names.
- Four personal bot competitors are created with varied starting ranks and points.
- Competitor scores are simulated by elapsed calendar days whenever the app opens; this does not require background execution or internet.
- Each competitor has independent random daily progress, with occasional point losses.
- User performance does not affect bot performance, and bot performance does not affect the user's rank.
- A five-player personal leaderboard displays rank, points, position, and score difference.
- Competitor points and ranks persist across 30-day challenges; they do not reset at challenge boundaries.
- This is a local simulated competition, not an online multiplayer leaderboard.
