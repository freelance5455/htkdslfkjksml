# Mis Préstamos — APK actualizado

Este proyecto empaqueta el ZIP `MisPrestamos_Actualizacion_FINAL.zip` como una aplicación Android WebView.

- Nombre: Mis Préstamos
- Versión: 3.0
- Código actualizado: incluido en `app/src/main/assets/`
- Punto de entrada: `app/src/main/assets/index.html`

## Generar APK
Abrir este proyecto en Android Studio y elegir:
Build > Build App Bundle(s) / APK(s) > Build APK(s)

El APK quedará en:
app/build/outputs/apk/debug/app-debug.apk

Si Android Studio solicita instalar componentes del SDK/Gradle, aceptar la instalación.


## WhatsApp directo
El enlace para clientes apunta directamente al WhatsApp configurado: +57 300 402 6303. También queda como número predeterminado para que las solicitudes funcionen inmediatamente.
