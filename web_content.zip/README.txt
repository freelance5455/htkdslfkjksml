শরিফুল অফিসিয়াল Game Hub

index.html হলো মূল HTML ফাইল। ব্রাউজারে খুললে Game Hub চলবে।
এটি ZIP প্যাকেজ, ইনস্টলযোগ্য Android APK নয়। APK বানাতে উপযুক্ত builder-এ ZIP আপলোড করতে হবে।
