BOUBA SERVICES — APPLICATION WEB ENRICHIE

Fonctionnalités :
- Site vitrine responsive mobile et ordinateur.
- Catalogue de 8 familles d’équipements avec recherche et filtres.
- Assistant BOUBA interactif à plusieurs étapes : il pose des questions complémentaires pour qualifier un projet de vidéosurveillance, réseau, dépannage, alarme ou sécurité incendie, puis prépare un résumé transmissible sur WhatsApp.
- Formulaire de demande de devis qui prépare un message WhatsApp au +223 70 72 23 69.
- Coordonnées : bsy64064@gmail.com — Bamako, Mali.

À SAVOIR :
L’assistant intégré est un conseiller interactif local avec questionnaires à plusieurs étapes et réponses prédéfinies. Il ne s’agit pas encore d’une IA générative : il ne comprend pas toutes les formulations et ne consulte pas Internet. Pour une vraie IA capable de traiter des questions très variées, il faut connecter un service IA via un serveur sécurisé. La clé API ne doit jamais être placée dans le code du navigateur ou de l’application : elle doit rester côté serveur (voir les recommandations OpenAI : https://help.openai.com/en/articles/5112595-best-practices-for-api-key-safety).

Les images du catalogue sont illustratives. Les références exactes, fiches techniques, prix et stocks doivent être confirmés avant publication commerciale.

Le ZIP contient les fichiers du site, mais le site n’est pas encore publié sur Internet et ce n’est pas une application Android APK. Pour le rendre visitable, il faut le publier sur un hébergeur web.
