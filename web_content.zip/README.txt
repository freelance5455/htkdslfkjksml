Australia Work Visa - Android APK Project
This project wraps the supplied index.html in an Android WebView.
Open the project in Android Studio, sync Gradle, then Build > Build APK(s).
This is a demo/application-assistance app, not an official Australian Government app.
