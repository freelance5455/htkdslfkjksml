Jogo das 150 Casas — protótipo offline

Como testar no Android:
1. Extraia o ZIP.
2. Abra index.html no navegador do telemóvel.
3. O jogo funciona sem internet depois de aberto/localmente.

Esta versão contém:
- 150 casas
- 2 jogadores
- 2 dados simultâneos
- 60 casas coloridas para usar com cartas físicas
- 10 bombas: recuam 10 casas
- 3 escadas de subida e 3 de descida
- restantes casas normais
- botão Passar vez
