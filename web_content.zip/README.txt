CV Builder — ficheiros separados
================================
cv-builder.html          página principal (estrutura)
css/builder.css          estilos do editor
js/core.js               estado, motor de modelos, tema, pré-visualização
js/rich.js               texto formatado (negrito, itálico, sublinhado, lista)
js/crop.js               recorte/zoom da foto
js/sign.js               assinatura: desenhar, escrever (Manuscrita, French Script MT, Künstler Script) ou importar
js/form.js               formulário: secções, itens, títulos editáveis
js/tools.js              painel de ferramentas (fonte, espaço, layout, cores com seletor arrastável e gradiente)
js/pdf.js                paginação A4, margens e exportação PDF (carrega as bibliotecas só ao exportar)
templates/manifest.json  lista de modelos (6: professional, modern, classic, elegant, creative, executive); templates/<id>/index.html + style.css
sample-data.json         dados do botão "Carregar exemplo"
fonts/                   .ttf opcionais (ver fonts/README.txt; frscript.ttf e kunstler.ttf para a assinatura)

Abra cv-builder.html pelo pré-visualizador do SPCK (ou qualquer servidor estático).

PDF: botão PDF -> páginas A4 geradas a partir da pré-visualização (as bibliotecas html-to-image e jsPDF
são carregadas da internet na primeira exportação). Margens ajustáveis no próprio ecrã do PDF.
"Imprimir" usa o motor de impressão do navegador (PDF vetorial) como alternativa.

Dados dos modelos: ver sample-data.json. Títulos das secções: {{t.experience}}, {{t.education}}, ...
Texto formatado: {{{description}}}, {{{professional_summary}}} (HTML já limpo pelo editor).
Habilidades e idiomas: listas com name, level (25/50/75/100) e level_label.
Tema: variáveis --primary, --text, --paper, --font, --fs, --lh, --gap, --photo-r e classe "flip" no <html>.

Notas desta versão
------------------
- Modelos: cada index.html tem <meta name="tpl" content="<id>"> e cada style.css começa por /* tpl:<id> */.
  O editor carrega os ficheiros um a um, sem cache, e confirma estas marcas (evita misturar o HTML de um modelo com o CSS de outro).
  Ao criar um modelo novo, acrescente as duas marcas com o mesmo id do manifest.json.
- Gradiente: no manifest.json, "gradient": true marca os modelos compatíveis. Nos CSS use background:var(--grad, <cor normal>);
  a classe "grad" no <html> indica que o gradiente está ligado (Cores > Gradiente).
- Foto: só JPG, PNG, WEBP, GIF e BMP (confirmado pelo conteúdo do ficheiro, máx. 25 MB).
- Páginas: o corte tenta 3 níveis (blocos inteiros > linhas inteiras com títulos juntos > só linhas) e nunca corta uma linha de texto ao meio.

Dados pessoais extra: nationality, marital_status (Solteiro(a), Casado(a), Divorciado(a), Viúvo(a)), birth_date (AAAA-MM-DD), gender.
Nos modelos aparecem como lista pinfo_list (label, value). Secções movíveis levam data-sec="<chave>"; a ordem do editor (arrastar pela pega à esquerda) aplica-se às secções que partilham o mesmo contentor do modelo.

Níveis (habilidades e idiomas): 20, 40, 60, 80 ou 100 (5 pontos/barras). Estado civil acompanha o sexo (Solteiro/Solteira, ...).
Novas secções: extra (atividades extracurriculares: activity, organization, location, start_date, end_date, description) e references (name, company, phone, email).
Dados pessoais extra chegam aos modelos como pinfo_list com kind (birth, nationality, marital, gender), label e value.

Datas, LinkedIn e ferramentas
-----------------------------
- Datas (Experiência, Formação, Atividades): mês e ano escolhidos em listas (sm/sy = início, em/ey = fim, cur = Presente).
  O texto mostrado no CV é composto no core.js (start_date, end_date, dates, dates_h). Texto antigo ("Jan 2022", "03/2018", "Presente")
  é convertido automaticamente; o que não for reconhecido mantém-se como estava e aparece com um aviso no editor.
  Nos modelos use {{dates}} (separador —) ou {{dates_h}} (separador -).
- LinkedIn: o campo guarda só o nome de utilizador (linkedin). Links colados (https://www.linkedin.com/in/nome/?x=1, pt.linkedin.com/in/nome,
  in/nome, @nome) são reduzidos ao nome. Nos modelos use {{#if linkedin_url}}...{{linkedin_url}}; a classe "linkedin" mostra o ícone original
  (cores do LinkedIn). Se o campo Website tinha um link do LinkedIn, passa para o campo LinkedIn.
- Cores > Repor, Fonte > Repor, Espaço > Repor e Layout > Repor só repõem o que essa ferramenta controla; as margens do PDF não são afetadas.

Ajustes recentes
----------------
- Páginas A4 (js/pdf.js): o corte já não recua em cascata. Procura, entre todas as posições possíveis, a que deixa a página mais cheia sem nunca cortar uma
  linha de texto (em nenhuma coluna). Partir um item (experiência, lista) ou deixar um título sozinho no fim da página só é aceite se compensar bastante
  (penalizações em measureDoc/cuts). Em modelos com 2 colunas já não sobra meia página vazia.
- Anos (js/form.js): a lista parte do ano do dispositivo + 6 e desce até 1960. A primeira opção a seguir a "Ano" é "Outro ano (digitar)…", que troca a lista
  por um campo numérico (1900–2100); o botão ▾ volta à lista.
- Títulos das secções: Professional e Modern ligeiramente maiores (Creative, Classic e Elegant mantidos).
- Novo modelo "Executive (Híbrido)" (templates/executive): cabeçalho em faixa com contactos e foto (do Professional) + barra lateral suave com
  habilidades/idiomas em pontos e entradas com traço à esquerda (do Modern). Suporta Layout (barra à direita), Gradiente e cores do editor.
  Barra lateral: habilidades, idiomas, certificados, interesses, secções personalizadas e informações adicionais. Coluna principal: perfil,
  experiência, formação, atividades, projectos e referências.
- PDF, margens e títulos (js/pdf.js): (1) um corte nunca cai dentro de um título (h2/h3): o título fica inteiro numa página ou na outra;
  (2) as margens de topo/rodapé já não "esticam" uma linha do ponto de corte (isso arrastava texto, títulos escuros ou etiquetas até ao fim da página);
  passam a ser preenchidas, coluna a coluna, com a linha limpa mais próxima do corte (só o fundo da página/coluna). measureDoc devolve agora também
  as caixas com cor/borda (D) e a união de tudo o que é "tinta" (B), usadas por cleanRow().
- Versão v7 (aparece junto a "N páginas A4" no ecrã do PDF, para confirmar que o código novo está a correr; os ficheiros js/css levam ?v=7 contra a cache):
  * Título de secção nunca fica sozinho no fim da página: vai sempre com o início do seu conteúdo (1.º item da lista, ou o bloco todo se for pequeno).
  * Margens de topo/rodapé do PDF preenchidas com a cor de fundo de cada coluna (nunca copiam uma linha do corte).
  * Gradiente: os títulos da barra lateral (Modern, Creative, Executive) usavam border-image, que o conversor para imagem desenhava como caixas escuras;
    passaram a usar background (visualmente igual).
  * Nomes das secções (DT em core.js): Perfil profissional, Experiência profissional, Formação académica, Habilidades e competências, Certificações e cursos,
    Interesses pessoais, Referências profissionais. Títulos já editados à mão no editor mantêm-se.
  * Dados pessoais: novo campo Endereço (casa, apartamento…) com ícone de casa; "Morada / Cidade" passou a "Cidade / País". Ícone de nacionalidade: bandeira preenchida.
  * Ícones de contacto alinhados com o texto (antes ficavam ~1,5px abaixo).
- Versão v8:
  * REMOVIDO o conversor de PDF por imagem (html-to-image, jsPDF, composição de páginas, ecrã de PDF, margens Topo/Rodapé/Laterais, linhas de página).
    O botão "PDF" abre a impressão do navegador: escolha "Guardar como PDF". O PDF é vectorial (texto pesquisável, zoom sem perder qualidade)
    e as quebras de página são as do próprio navegador (já com regras para não partir itens nem separar títulos). Active "Gráficos/Cores de fundo" se o navegador o pedir.
    A pré-visualização continua, só para dar noção do resultado (é contínua; não mostra a quebra de página).
  * Secções seleccionáveis na pré-visualização: toque num bloco (ou no cabeçalho) -> contorno azul + barra com ↑ ↓ (mover), ✎ Editar (abre a secção no formulário) e ✕.
    Só existe no ecrã: nunca entra no PDF. Código em js/pdf.js (prevMark/selBar); função guides() é o gancho chamado pelo núcleo após cada desenho.
  * Ícones de contacto todos preenchidos; Sexo usa o ícone de duas pessoas; "Cidade / País" -> "Província / Estado" (clássico: "Província"); "Cidade" nas experiências -> "Local".
  * Dicas/perguntas nos campos (ex.: "Onde fez o curso?") em todas as secções, incluindo caixas de texto formatado (atributo data-ph) e listas de certificados/interesses.
- Versão v9:
  * Pré-visualização = folhas A4 reais (210x297 mm) flutuantes, como no Word: o conteúdo flui de uma folha para a seguinte e as quebras de página aparecem
    já durante a edição (sem linhas a adivinhar). A etiqueta "N páginas A4" mostra o total. Regras: nunca corta uma linha, nunca separa um título do seu conteúdo.
  * O PDF imprime exactamente estas folhas (vectorial, texto pesquisável, sem conversão para imagem): o que se vê é o que sai. Código: js/pdf.js (paginate/printHtml).
  * Margens devolvidas: ferramenta "Margens" na barra inferior do preview (superior das páginas 2+, inferior, laterais; em mm). As margens de topo/rodapé
    prolongam a cor da barra lateral (sem copiar conteúdo).
  * Ícones de contacto (incluindo LinkedIn) seguem agora a cor principal em todos os modelos; título/contactos do Professional também.
  * Mover secções para a barra lateral (Modern, Creative, Executive): toque numa secção (Habilidades, Idiomas, Certificações, Interesses, Informações adicionais,
    secções personalizadas) -> botão "⇆ Lateral / ⇆ Principal". Configuração por modelo em templates/manifest.json ("side"). Escolha guardada em D.place[modelo].
- Versão v10:
  * Barra lateral (Modern, Creative, Executive) preenche SEMPRE a folha de cima a baixo, independentemente do conteúdo (incluindo margens e a parte vazia da última folha).
  * Corrigido: folhas do Modern ficavam "incompletas" (fundo transparente -> cinzento do ecrã). Agora o papel é sempre a cor --paper.
  * Corrigido: conteúdo "tapado" (ex.: Creative) quando o tipo de letra/imagens mudam a altura depois da medição: as folhas são refeitas automaticamente até estabilizarem.
  * Margens: mínimo razoável de 10 mm e padrão de 18 mm no topo (páginas 2+) e no rodapé. Margens laterais passam a ser espaço interior extra (variável --mx nos modelos),
    por isso as barras laterais e cabeçalhos continuam a ir de lado a lado da folha.
- Versão v11:
  * Folhas do preview com cantos arredondados (só no ecrã; o PDF impresso mantém cantos rectos).
  * Menu "PDF ▾": Imprimir / Guardar PDF (vectorial), Guardar projecto, Abrir projecto (e Partilhar, quando o dispositivo suporta).
    Projecto = ficheiro .cvb.json com dados + modelo + estilo (cores, fontes, margens, ordem das secções). Também há botões no fim do formulário (junto de "Carregar exemplo").
- Versão v12:
  * Ícones de contacto maiores (+4 pt), centrados na primeira linha do texto.
  * Estilo das secções com datas (Experiência, Formação, Atividades): ferramenta Layout > "Datas": Clássico (padrão do modelo), Data à esquerda,
    Linha do tempo, Cartões, Destaque. Guardado no projecto (S.es). Implementado por CSS (html.es-*) no fim de cada templates/*/style.css; novos modelos só precisam de copiar esse bloco.
  * Formulário em acordeão: abrir uma secção fecha a anterior (também ao tocar "✎ Editar" no preview).
- Versão v13:
  * Ícones: Cores (paleta), Margens (folha com guias de margem) e calendário preenchido (data de nascimento) nos modelos com ícones.
  * Carregar exemplo / Abrir projecto: se houver alterações por guardar, pergunta "Guardar e continuar / Continuar sem guardar / Cancelar".
  * Estilo das datas é POR SECÇÃO: seleccione Experiência, Formação ou Atividades no preview e use o botão "▦ Datas" (Clássico, Data à esquerda, Linha do tempo, Cartões, Destaque).
    Guardado em S.es = {experience:'time',...}; CSS: [data-es=...] no fim de cada templates/*/style.css.
  * Regra do botão Layout: só aparece quando há algo a ajustar: foto adicionada (forma da foto) e/ou modelo com barra lateral invertível (manifest "flip").
  * Dados pessoais: Nome, Cargo, Email, Telefone, Endereço e Província aparecem sempre; LinkedIn, Website, Data de nascimento, Sexo, Nacionalidade e Estado civil
    surgem como sugestões "+ …" e podem ser removidos com ×. Campos personalizados (nome + valor) abaixo, sem sugestões; aparecem no CV com ícone próprio.
- Versão v14:
  * Dados pessoais: campo(s) personalizado(s) ficam SEMPRE acima das sugestões "+ …" (ordem: campos, personalizados, sugestões).
  * Layout: modelos com espaço de foto fixo (manifest "slot": Modern) mostram sempre os botões da forma da foto.
  * Barra lateral (Padrão / Invertida) passou a botões, como Foto.
- Versão v15:
  * Nova secção ASSINATURA (última por defeito, pode ser arrastada): Cidade, Data (botão "Hoje") e Assinatura. Ao tocar na caixa abre uma janela com
    3 separadores: Desenhar (dedo/rato, cores preto/azul/vermelho, Apagar), Escrever (nome em 4 estilos manuscritos, cores) e Importar (foto da assinatura,
    fundo branco removido). Guarda um PNG transparente recortado (js/sign.js). No CV aparece "Cidade, data" à esquerda e a assinatura com o nome por baixo, nunca cortada entre páginas.
  * Secção personalizada com 4 tipos (botões no editor): Texto, Experiência (entradas com datas, local e descrição), Competências (nome + nível) e Lista (itens).
    Ao trocar de tipo os dados dos outros tipos não se perdem. Cada modelo usa o seu próprio estilo de experiência/competências/lista.
    O botão "Datas" do preview também funciona nas secções personalizadas do tipo Experiência.
  * Ícone do app: pasta icons/ (favicon, apple-touch-icon, ícones 192/512) + manifest.webmanifest + logótipo no cabeçalho.
- Versão v18:
  * Estilo da pontuação POR SECÇÃO (Habilidades, Idiomas e secções personalizadas do tipo Competências): seleccione a secção no preview e use o botão "◐ Nível".
    Opções: Padrão do modelo, Cinco pontos, Barra de progresso, Lista, Slider, Anel e Etiquetas. Guardado no projecto em S.ls = {skills:'bar', languages:'ring', custom:'tags'}
    (todas as secções personalizadas de competências partilham a chave "custom", tal como as datas).
  * Implementação (js/pdf.js: applyLS / lsHtml / LSCSS): cada item com nível tem data-lv (20..100) e data-lb (texto do nível) nos templates/*/index.html;
    o motor reescreve só o conteúdo dos <li> e define data-ls="<estilo>" na secção. "Padrão do modelo" repõe o desenho original. O CSS é partilhado
    (injectado no preview e no PDF) e usa --accent/--primary, --paper e --grad (gradiente), por isso funciona em todos os modelos sem mexer nos style.css.
    Novos modelos só precisam de ter data-lv/data-lb em cada <li> de habilidades/idiomas/competências.
  * O menu flutuante da barra da secção é partilhado entre "▦ Datas" e "◐ Nível"; a barra passa a quebrar linha em ecrãs estreitos.
  * Ferramenta Espaço: novo ícone (setas para cima/baixo + linhas de texto), sem contorno, na cor do botão (cinzento/branco quando activo).
- Versão v19:
  * Barra da secção seleccionada: o botão ✕ ficou fixo no canto superior esquerdo (não se desloca quando há muitos botões, que quebram linha ao lado); removido o nome da secção.
  * Assinatura: sem nome nem linha por baixo; tamanho reduzido (máx. 15 mm de altura × 46 mm de largura), alinhada à direita.
  * Dados pessoais: "Endereço (casa, rua, bairro…)"; novo campo "Distrito" ao lado de "Província / Estado". Com ambos preenchidos aparece "Província - Distrito".
- Versão v20:
  * Ícones de Fonte e Layout substituídos pelos enviados (máscaras PNG em css/builder.css, classes .ti-font / .ti-layout; mudam de cor como os outros).
  * Barra da secção: o botão ✕ fica fixo no canto direito.
  * Assinatura: "Cidade, data" fica POR CIMA da assinatura (centrado sobre ela), o conjunto alinhado à direita.
  * Estilo da pontuação: já não há "Padrão do modelo" + o mesmo estilo repetido. A 1.ª opção é o padrão do modelo com o nome do estilo
    (ex.: "Cinco pontos (padrão)" nos modelos com pontos; "Barra de progresso (padrão)" no Professional; "Texto (padrão)" no Classic) e as restantes não repetem o padrão.
