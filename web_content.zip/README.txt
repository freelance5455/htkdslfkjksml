RD ALPHA MODARA - WEBSITE ZIP

IMPORTANT: This ZIP is formatted for a Zipped site importer.
index.html and logo.jpg are placed at the ZIP ROOT.

Open this ZIP in the Zipped site tool and preview it first.
Login PIN: 2323

Data is stored in the browser on the same device. Use Backup regularly.
If the hosting/preview tool blocks browser storage, saving will show an error.
This is a website package, not an Android APK or Android Studio project.
