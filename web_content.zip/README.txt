NEXORA CALC PRO — Mobile Web App
================================

Included:
- Premium dark/navy calculator interface
- Basic arithmetic and scientific functions
- Memory, history, GST and EMI calculators
- Currency conversion via a public online exchange-rate endpoint (internet required)

Important:
- This is a standalone HTML web app, not a compiled Android APK.
- Open index.html in a browser to test it. For installable Android APK, a separate build/package step is required.
- Exchange rates require internet and depend on the public provider's availability.
