Nisho Grocery — Bengali/English Rating Prototype

- Extract ZIP and open index.html in Chrome.
- Use the language button to switch Bengali/English.
- Customer/delivery account sees the Ratings & Feedback section.
- Rate seller, delivery partner, or customer from 1–5 stars; choose a service tag and add optional comments.
- Ratings are saved only in this device's browser. This is a demo HTML prototype, not a production APK.
- For real app, ratings should be attached to completed orders, with account authentication and server/database moderation.
