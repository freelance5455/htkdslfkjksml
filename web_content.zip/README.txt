BTC Balance Scanner — paste-address edition

This build avoids the Android HTML file-picker issue. Open your TXT file in a text editor, select/copy the address lines, paste them into the app's large text field, then tap UČITAJ ZALIJEPLJENE ADRESE and START SCAN.

Rebuild this ZIP in your HTML-to-APK builder. Internet access is required. Uses public Blockstream API sequentially. Use public addresses only; never enter seed phrases or private keys.
