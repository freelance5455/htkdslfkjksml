Gemo Werkzeuge — GEMO NRW GmbH
Testversion für ZIP → APK Konverter

Startdatei: index.html

Sprachen:
- Deutsch (Standard)
- Russisch
- Rumänisch

Enthalten:
- Mitarbeiter
- Werkzeuge
- Mehrere Fotos pro Werkzeug / Aktion
- Kamera oder Galerie
- Ausgabe, Rückgabe, Übergabe
- Vollständigkeitsprüfung
- Kommentare
- GPS + Datum/Uhrzeit
- Optionale Unterschrift
- Historie + PDF
- Export .gemotools
- Import mit Zusammenführung per eindeutiger ID

Die Daten bleiben lokal auf dem Gerät.

Neu in v4:
- Öffnen / Bearbeiten / Löschen für Mitarbeiter
- Öffnen / Bearbeiten / Löschen für Werkzeuge
- Öffnen / Bearbeiten / Löschen für Historien-Aktionen
- Fotos können beim Bearbeiten ergänzt oder gelöscht werden
