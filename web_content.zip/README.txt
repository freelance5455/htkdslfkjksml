UPLOAD THIS ZIP TO AN ONLINE HTML/WEB-TO-APK BUILDER.
The project is intentionally simple: index.html is at the ZIP root.
Suggested app name: Farnek Village Maintenance Work
Package ID: com.farnek.villagemaintenance
Camera/photo, GPS, report generation and WhatsApp sharing are included.
Important: real AI image analysis needs a secure AI backend/API; an offline HTML ZIP cannot safely contain a private AI API key.
