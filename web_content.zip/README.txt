SKY STRIKE 3D
=============

HOW TO PLAY
1. Open sky-strike-3d.html with Chrome (or any modern browser).
2. Chrome menu (three dots) -> "Add to Home screen" for an app icon.
3. Works fully offline - music and sound effects are inside the file.

SHARING
Send sky-strike-3d.html by Bluetooth / ShareIt / anything else.
One single file, nothing else needed.

CONTROLS
Joystick (bottom-left) or drag anywhere - switch in Settings.
Rocket button = homing missiles.  Target button = guided bullets.
Fire-mode chip under the skill bar switches NORMAL / SPREAD.
Keyboard: WASD or arrows, Space = missile, F = target, P = pause.

SOUND
Music sits under the game sounds so guns, explosions and the boss
warning stay clear. Music and sound can be turned off in Settings.

PERFORMANCE
Settings -> Graphics: High / Mid / Low.
The game also lowers resolution by itself if the frame rate drops.

TIP
If anything ever feels wrong, open Settings -> HUD -> "Fix the game"
to restore the controls and layout to their defaults.
