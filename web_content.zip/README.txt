Cricket Legends - Updated HTML game

Open index.html in a browser to play.
This ZIP is not an APK. Upload it to your app builder if ZIP/HTML projects are supported.
