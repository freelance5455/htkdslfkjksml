IFD-ROHINGYA SALAH TRACKER — ADVANCED PROJECT
English interface. Developed for IFD-Rohingya School by MV Anwar Hussain.

Upload this ZIP to your HTML-to-APK builder and choose bundled HTML/ZIP mode, not website URL mode.

Includes:
- Grades 1–12 with five sample Islamic names per grade (placeholders; replace with actual students).
- Daily Fajr, Dhuhr, Asr, Maghrib and Isha attendance.
- Individual student history by date and prayer.
- Monthly class reports and CSV export.
- Add/edit/archive/restore students; name changes preserve history.
- Optional student photos (resized before saving).
- Automatic local saving and JSON backup/restore.

This ZIP is a project, not a compiled APK. Test before entering official records. Data is stored on the device; download backups regularly. APK-builder storage behavior may vary.
