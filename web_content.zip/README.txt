Raj World Ludo - Fixed for HTML to APK Builder
Both index.htm and index.html are included so builders expecting either filename can load the app.
