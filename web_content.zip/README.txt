M Alhaisam customer service — English Light Accounts

Complete English interface.
No scanner, no separate Stock menu, no Start screen.
Opens directly to Dashboard.
Light UI, manual Sales and Purchases, daily Sales/Profit/Purchases, monthly History, JSON Backup/Restore.
HTML to APK Builder: enable JavaScript and Local Storage/DOM Storage. Camera permission is not required.
