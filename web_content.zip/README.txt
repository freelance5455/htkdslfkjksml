TRENDWAVE — OWN VIDEO PLATFORM

This version does NOT use YouTube or any other video website.
Videos are uploaded to TrendWave's own Firebase Storage and played directly in the TrendWave interface.

WHAT IT INCLUDES
- Google sign-in
- Direct video upload to TrendWave
- Online shared video feed
- Vertical autoplay FYP-style feed
- Explore/search
- Likes
- Share button
- User profile
- No YouTube embeds

IMPORTANT
This is a real web app frontend, but Firebase must be connected to make the online features work.

SETUP
1. Create a Firebase project.
2. Add a Web App in Firebase and copy its web config.
3. Replace the firebaseConfig values in index.html.
4. Enable Authentication > Google.
5. Create a Firestore database.
6. Create Storage.
7. Publish the Firestore rules from firestore.rules.
8. Publish the Storage rules from storage.rules.
9. Host index.html on a web host (or Firebase Hosting).

SECURITY
The included rules allow anyone to watch published videos, while uploads require Google sign-in and are limited to the signed-in user's own video folder. For a production social network, add moderation/reporting, rate limits, stronger validation, and abuse protection.

MOBILE
The page is designed for phone screens. You can open the hosted site on a phone and use it like a web app. A true APK can be made later by wrapping this app in a native Android project, but that requires an Android build environment.
