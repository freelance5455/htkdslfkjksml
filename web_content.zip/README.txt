Marketplace Profit Calculator - HTML package for APK builder compatibility

This ZIP includes index.html at the root and also at web/index.html.
This supports builders that load either /index.html or /web/index.html.
Upload this ZIP to your APK builder and rebuild the APK.
If the same error remains, the builder's asset packaging or WebView configuration may need to be corrected.
