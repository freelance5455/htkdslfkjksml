NEXTKICK FOOTBALL — PHONE-ONLY APK WRAPPER PACKAGE

Upload this ZIP to an HTML-to-APK builder that accepts a ZIP containing index.html.
Suggested name: NextKick Football
Orientation: Landscape
Package ID suggestion: com.nextkick.football

This is a wrapper around an early HTML/Three.js prototype, not a finished realistic football game.
The current index.html loads Three.js from a CDN, so internet access is required while playing.
Choose a debug/test APK for now; do not pay for store publishing or use this as a final Play Store release.
Review the service's privacy, fees, and permissions before uploading. Never share passwords or signing keys.
