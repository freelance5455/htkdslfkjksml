KEUANGAN PRIBADI — VERSI OFFLINE

Isi:
- index.html: aplikasi utama
- manifest.json dan sw.js: dukungan instalasi/offline jika dijalankan melalui hosting HTTPS atau localhost.

Cara paling mudah di Android:
1. Ekstrak ZIP ini menggunakan aplikasi pengelola file.
2. Buka folder, lalu buka index.html dengan Chrome atau browser.
3. Tambahkan transaksi pemasukan/pengeluaran.
4. Data tersimpan di browser pada perangkat yang sama. Jangan hapus data browser sebelum membuat cadangan JSON.

Fitur:
- Saldo keseluruhan
- Ringkasan pemasukan dan pengeluaran bulan ini
- Kategori pemasukan/pengeluaran
- Riwayat dan filter transaksi
- Laporan bulanan dan ringkasan pengeluaran per kategori
- Ekspor cadangan JSON, ekspor CSV, dan pulihkan cadangan
- Penyimpanan lokal; tidak memerlukan akun atau internet untuk pencatatan dasar

Catatan:
Ini adalah aplikasi web offline, bukan APK Android. Untuk pemasangan PWA dengan ikon di layar utama, aplikasi perlu disajikan lewat HTTPS/localhost terlebih dahulu. Data tersimpan pada browser/perangkat ini, bukan otomatis tersinkron ke perangkat lain.
