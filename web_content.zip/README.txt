Shree Sendhav Dairy Mobile V34 - HTML APK Package

This package is a separate mobile web build based on the supplied V34 Desktop app/index.html.
The original V34 Desktop files are not modified.

Use with an HTML ZIP to APK app:
1. Keep index.html at the ZIP root.
2. Import this ZIP into the HTML-to-APK app.
3. Set app name: Shree Sendhav Dairy Mobile V34.
4. Enable Internet permission because Firebase sync requires internet.
5. Build APK.

Firebase config is already present in the HTML. Firestore/Auth rules and account permissions must allow the required sync operations.
