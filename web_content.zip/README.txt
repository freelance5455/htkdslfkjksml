========================================================================
ATC Aviation Weather — Mobile-First HTML App & APK Packaging Guide
========================================================================

Application Name: ATC Aviation Weather
Description: Lightweight Mobile-First Aviation Weather Application for Air Traffic Controllers
Author: ATC Engineering Team

------------------------------------------------------------------------
1. PROJECT STRUCTURE
------------------------------------------------------------------------
- index.html   : Complete, self-contained application (HTML5 + CSS3 + Vanilla JavaScript ES6)
- manifest.json: Web App Manifest for mobile installation (PWA)
- icon.png     : High-resolution application icon (512x512 pixels)
- README.txt   : This packaging and usage instruction guide

No server, no terminal, no Node.js, and no build tools are required.
You can open "index.html" directly in any browser on your phone, tablet, or PC.

------------------------------------------------------------------------
2. HOW TO CONVERT TO ANDROID APK (ONLINE HTML-TO-APK BUILDERS)
------------------------------------------------------------------------
You can turn this web app into an installable Android APK (.apk) in 2 minutes
using any of the popular online HTML-to-APK services:

OPTION 1: WebIntoApp (Recommended & Free)
1. Go to https://www.webintoapp.com/
2. Choose "HTML" or "Offline Website" mode.
3. Upload "index.html" (or upload the complete ZIP file containing index.html and icon.png).
4. Enter the App Name: "ATC Aviation Weather"
5. Set Package Name: "com.atcweather.app"
6. Select "icon.png" as the App Launcher Icon.
7. Click "Make App" and download your installable Android APK file (.apk).

OPTION 2: AppsGeyser / Website2APK
1. Go to https://appsgeyser.com/ or https://websitetoapk.com/
2. Select "HTML / Web App" template.
3. Upload "index.html" and "icon.png".
4. Enter App Title: "ATC Aviation Weather".
5. Generate and download the APK to install on your Android phone.

OPTION 3: Direct Chrome / Samsung Internet PWA Installation (Zero Conversion)
1. Open "index.html" on your mobile browser (or host it on any static web link).
2. Tap the browser menu (three dots) -> "Install app" or "Add to Home screen".
3. The app will install directly with full offline support and full-screen experience.

------------------------------------------------------------------------
3. AVIATION WEATHER DATA SOURCES & OPERATION
------------------------------------------------------------------------
1. METAR / SPECI:
   Retrieved live from AviationWeather.gov API (NOAA/NWS) for Iranian and
   international aerodromes. Displays full, untouched original text.
   Includes observation time, retrieval timestamp, and one-tap copy button.

2. TAF:
   Terminal Aerodrome Forecasts in their complete, original text format,
   preserving line breaks and change groups.

3. SIGMET:
   Active significant weather warnings worldwide and for Tehran FIR (OIIX).
   Only genuine official bulletins are shown (never simulated).

4. Upper Wind & Temperature:
   Numerical upper-air forecast levels (SFC, FL050, FL100, FL180, FL240,
   FL300, FL340, FL390) derived from global WMO GFS numerical prediction.

5. AFTN / Local Bulletin Manual Import:
   If isolated from the public internet or working with internal Iranian
   AFTN messages, controllers can tap "ورود دستی AFTN" on any tab to paste
   and display messages immediately.

------------------------------------------------------------------------
4. OPERATIONAL DISCLAIMER
------------------------------------------------------------------------
Operational decisions must be based on current authorized aviation
information sources and applicable local procedures.

تصمیمات عملیاتی مراقبت پرواز باید بر اساس منابع رسمی معتبر هوانوردی و
دستورالعمل‌های محلی مصوب اتخاذ گردد.
========================================================================
