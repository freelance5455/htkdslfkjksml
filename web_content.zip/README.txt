120tik merged web app
- index.html at ZIP root
- smooth button interactions + click sounds
- PWA manifest/service worker
- completion notification hook
Note: browser background processing is subject to Android/WebView throttling; a native foreground service is required for guaranteed long exports in the background.
