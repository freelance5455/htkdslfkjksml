PCM TRACKER – Deployment and Usage

DEPLOY ON NETLIFY
1. Go to app.netlify.com > Add new site > Deploy manually.
2. Drag the unzipped "pcm-tracker" folder (or this whole ZIP's contents) into the drop area.
3. Netlify gives you an https:// URL. Use that URL; PWA install and offline mode need HTTPS.

INSTALL ON ANDROID
1. Open the Netlify URL in Chrome or Brave.
2. Chrome: tap the ⋮ menu > "Install app" (or "Add to Home screen").
   Brave: tap the ⋮ menu > "Install PCM TRACKER" (or "Add to Home screen").
3. Open PCM TRACKER from the home screen. It runs full screen without browser bars.

TEST OFFLINE
1. Open the app once while online and let the page finish loading.
2. Turn on Airplane mode (or disconnect Wi-Fi and mobile data).
3. Close and reopen PCM TRACKER from the home screen. It should load and save progress.
4. In Chrome desktop: DevTools > Application > Service Workers should show "activated",
   and Cache Storage should list "pcm-tracker-v1".

BACKUP
Settings > Export backup saves a JSON file. Settings > Import backup restores it.

VERIFY SYLLABUS
Chapter lists are in data.js. Check them against the NCERT 2026–27 table of contents
and the CBSE syllabus, then edit names or scope values there. Do not change chapter IDs.
