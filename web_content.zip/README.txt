Elektrik 24/7 — HTML APK BUILDER VERSIYASI

Ilova nomi: Elektrik 24/7
Package: uz.elektrik247.app
Orientatsiya: portrait
Asosiy fayl: index.html

Bu demo/prototip. Keyinchalik haqiqiy login, buyurtmalar, server va admin panel qo‘shiladi.
