Child Health Clinic - AppForge Offline PDF Version (Android PDF fix)
=======================================================================
Entry point: index.html

This version generates a real PDF directly in the app using a self-contained
PDF writer. It does NOT require jsPDF, a CDN, or internet access.

PDF:
- Generate PDF first attempts the normal Android/WebView download.
- The generated PDF is also kept available through "Open / Share PDF".
- If Android/AppForge does not handle the HTML download automatically, use
  Open / Share PDF and choose an Android save/share/print destination.

Steps if the PDF is not visible in Downloads:
1. Tap Generate PDF.
2. Tap Open / Share PDF.
3. Use the Android share/save/print options to save the PDF.

Includes:
- Date/calendar first field
- Patient and fee actually received
- Expense detail
- Previous balance
- Current balance
- Daily/monthly/all filters
- Real PDF report
- Open / Share PDF fallback for Android
- Print
- Excel-compatible CSV export
- Offline local storage
