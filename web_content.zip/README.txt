NOVA - Android project

APK বানানোর দুটি উপায়:
A) Android Studio (কম্পিউটারে): Open > এই ফোল্ডার বেছে নিন > Sync > Build > Build APK(s)
B) GitHub (ফ্রি): নতুন repository বানিয়ে এই ফোল্ডারের সব ফাইল (.github সহ) আপলোড করুন।
   Actions ট্যাবে "Build APK" চলবে, শেষে Artifacts থেকে nova-apk নামান।

APK ইনস্টলের পর: অ্যাপ খুলে সব পারমিশন Allow দিন, ⚙ থেকে Gemini key বসান
(ফ্রি key: https://aistudio.google.com/apikey), তারপর গোলকে ট্যাপ করে কথা বলুন।
