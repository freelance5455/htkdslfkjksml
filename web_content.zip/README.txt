# Snake Fighter Android project
Game name: Snake Fighter
Creator credit shown in game: Made by me

This Android Studio project wraps the offline Snake Fighter game in a WebView.

## Build an APK
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Find the APK at app/build/outputs/apk/debug/app-debug.apk.

No internet permission is required. The game runs locally inside the app.
