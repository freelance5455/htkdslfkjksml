READING PDF - PAQUETE PARA APK FORGE
====================================

IMPORTANTE: index.html está directamente en la raíz del ZIP.

CONTENIDO
- index.html: interfaz principal y lógica local.
- manifest.webmanifest: metadatos de la aplicación web.
- assets/icon-192.png y icon-512.png: iconos grandes, sin márgenes blancos excesivos.
- assets/icon-foreground.png y icon-background.png: recursos separados para adaptar el icono si APK Forge los admite.

FUNCIONES INCLUIDAS EN ESTA VERSIÓN
- Pantalla de inicio minimalista: Reading PDF, buscador desplegable y configuración.
- Dos secciones principales: Inicio y Documentos.
- Selección de PDF mediante el selector de archivos Android/WebView.
- Lista local persistente mediante IndexedDB.
- Orden de documentos: último abierto primero; después fecha de modificación descendente.
- Documento destacado en Inicio para continuar leyendo.
- Intenta leer la fecha de creación PDF y el número de páginas cuando esos datos están disponibles en la estructura del archivo; los PDF comprimidos pueden no exponerlos.
- Tema claro, oscuro o según el sistema.
- Modo Lectura con filtro cálido en el visor.
- Captura de firma manuscrita y exportación PNG.

LIMITACIONES IMPORTANTES QUE DEBEN PROBARSE EN APK FORGE / ANDROID
1. Este ZIP es un paquete HTML para el flujo de APK Forge; no es un proyecto Android nativo ni un APK.
2. El listado automático de TODOS los PDF del teléfono no es posible desde HTML/WebView sin una integración nativa y permisos/API Android. En esta versión el usuario selecciona los PDF desde el selector del teléfono.
3. Para aparecer en "Abrir con" al tocar un PDF en el administrador de archivos y poder ser lector predeterminado, APK Forge debe permitir configurar AndroidManifest.xml con un intent-filter para ACTION_VIEW, MIME application/pdf y los esquemas content/file, además de conceder acceso URI. Esta configuración no se puede declarar desde index.html.
4. La visualización PDF usa un iframe con URL blob. Algunos WebView Android no incluyen visor PDF; en ese caso APK Forge necesita un plugin/visor PDF nativo o soporte explícito para PDF. Debe probarse en el APK instalado.
5. La firma se captura y guarda como PNG. Insertar la firma dentro del PDF y exportar un PDF firmado requiere una librería/función de edición PDF que no está incluida en este paquete.
6. No se ha podido compilar ni probar dentro de APK Forge o en un Motorola físico desde este entorno. No se garantiza que la vista previa replique el APK instalado.

PRUEBA RECOMENDADA
- Importar el ZIP completo en APK Forge, sin descomprimir ni cambiar el nombre de index.html.
- Generar una compilación de prueba.
- En el APK instalado: seleccionar un PDF, comprobar que queda en Documentos, abrirlo, cerrar y verificar que aparece destacado en Inicio.
- Probar tema claro/oscuro/sistema y Modo Lectura.
- Comprobar si el visor PDF renderiza el documento.
- Comprobar en APK Forge si existe configuración de intents/AndroidManifest para integrar "Abrir con".
