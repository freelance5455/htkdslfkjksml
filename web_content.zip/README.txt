Version 365 APK Project

Open this folder in Android Studio.
The original Version 365 HTML is copied unchanged to:
app/src/main/assets/index.html

APK-side settings:
- Local WebView (does not open Chrome for the app page)
- Text zoom fixed at 100%
- Wide viewport enabled
- Portrait mode
- Android Back button goes back inside WebView when possible

Build: Android Studio -> Build -> Build APK(s)
