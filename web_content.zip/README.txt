TechYolo — Same Design + Create Features

This build follows the look shown in the user's screenshots:
- TechYolo header
- Home / Reels / Music / Chat / Calls / Me bottom navigation
- Dark interface
- Profile and call layouts
- Messages layout

Added:
- Create screen
- Upload Video
- Upload Reel
- Local video preview/feed
- Go Live demo

The selected videos are local only. Real online uploads, accounts, messaging and livestreaming require a backend/server and appropriate privacy/moderation controls.
