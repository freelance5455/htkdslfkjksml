Smart Store Manager v1.1 - In-app PDF (Preview + Save)

APK Forge: choose HTML to App / Zipped Site, select this ZIP.
Keep the SAME app name and package name as your ORIGINAL app (com.smartstoremanager.app),
use a higher version number, and install it as an UPDATE over the original.
If Android says the signatures conflict, STOP. Do not uninstall the original app.

Before installing: open the original app > Backup / Settings > Export Full Backup and keep the text/file safe.

What is new
- Reports tab: Generate Report, then "Preview & Save PDF" opens a full-screen preview inside the app.
- "Save PDF" builds a real A4 PDF (table layout, page numbers, totals, expenses, signature lines).
- "Share / Copy text" sends or copies the report as plain text (WhatsApp / Notes) if the phone blocks file saving.
- Saved report history now has a "PDF" button that reopens the saved copy.
- Backup / Settings > "Run device check" reports what this phone app can do.
- Storage key and all data handling are unchanged, so existing records stay in place.
