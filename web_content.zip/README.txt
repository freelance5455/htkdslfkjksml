Medicine Name Guessing Game — 20 questions
Extract and open index.html in Chrome. HTML game, not an APK.
