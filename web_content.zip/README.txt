NIKHIL FX V4.0
--------------
Files:
- index.html: app interface and features
- virat-hero.jpg: supplied Virat Kohli photo used as app and hero background
- click-sound.mp3: supplied sound effect used on button/tile clicks
- ns-icon.png: original app icon

How to use:
1. Extract all files into the same folder.
2. Open index.html in a modern browser, or use the folder as the web app source.
3. Keep the image and MP3 files beside index.html so the background and sound work.
4. Tap ENTER once to allow browser audio playback.

Added in V4.0:
- My Notes with local-device saving
- To-do list with completion and deletion
- Stopwatch
- Cricket quiz with score
- Unit converter (distance, weight, temperature)
- Focus timer (5–30 minutes)
- Quick feature search
- User-supplied full-screen background photo
- User-supplied MP3 click sound for buttons and feature tiles
- Refreshed dark-blue glass interface and fixed stylesheet structure

Existing tools retained:
Calculator, date/day, player directory, Virat gallery, batting game, editing academy, settings, accent colour, language and sound toggle.
Notes and tasks stay in this browser/device using local storage. The gallery requires internet access.
