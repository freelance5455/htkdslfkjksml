ST IRON PERFORMANCE — MOBILE OFFLINE APP

Files:
- index.html: app
- logo.png: supplied logo used unchanged
- manifest.json: installable PWA settings
- service-worker.js: offline cache

Use:
1. Upload all files and folders in this ZIP to the root of a GitHub repository.
2. In Settings > Pages, publish from the main branch and root folder.
3. Open the published URL in Chrome on Android. Use menu > Add to Home screen / Install app.
4. The app saves client data automatically in this browser on this device.
5. Use Backup > Export JSON regularly. Data is stored locally and will not automatically sync across devices.

Features:
Client ID, full name, phone, age, session count, subscription type/date, private status and notes; individual client pages; quick previous/next client navigation; vertical workout exercise cards with day, sets, reps, weight, rest and notes; edit existing program in place; InBody history; JSON backup/restore; offline caching.

Important: Service worker offline support requires serving through HTTPS (GitHub Pages is suitable), not opening index.html directly as a local file. Do not clear browser storage without exporting a backup first.
