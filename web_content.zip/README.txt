SUMO LEARN UPGRADE PACKAGE

Contents:
- index.html: The uploaded Sumo Learn WASSCE study library.
- UPGRADE_PROMPT.txt: The full upgrade instructions supplied by the user.

IMPORTANT:
This ZIP is a prompt/content package. It is NOT the native Kotlin/Jetpack Compose project and is NOT an APK.
To upgrade the existing Android app, the original Google AI Studio Android project ZIP is still required.
