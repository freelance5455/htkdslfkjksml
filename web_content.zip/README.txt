CONTROLMAX COMERCIAL - CORRECCIÓN DE LICENCIAS PARA APKFORGE

CAUSA DEL PROBLEMA EN EL ZIP ORIGINAL
- index.html no cargaba js/license.js.
- js/license.js solo devolvía true y no mostraba pantalla de activación.
- app.js no implementaba la activación.
- licencia_ejemplo.dat era una clave de demostración incompatible con el generador real.

QUÉ SE CORRIGIÓ
- Se agregó una pantalla de activación visible al abrir la aplicación.
- Se muestra un ID de instalación SP-XXXXXXXX.
- Se puede seleccionar el archivo .dat emitido por StockPro Admin.
- Se valida la firma ECDSA P-256/SHA-256, el producto, el ID de equipo y las fechas.
- Se guarda la activación y se vuelve a comprobar al abrir la app.

PASO NECESARIO ANTES DE COMPILAR
1. Abre el Generador de Licencias de StockPro Admin.
2. Entra en Llaves y carga TU CLAVE PRIVADA EXISTENTE. No generes un par nuevo si ya emitiste licencias.
3. Copia el objeto de CLAVE PÚBLICA.
4. Abre ControlMax_Comercial/js/license.js.
5. Sustituye la línea:
   const PUBLIC_KEY_JWK = null;
   por:
   const PUBLIC_KEY_JWK = { ...objeto de clave pública... };
   Pega el objeto completo, sin comillas.
6. Guarda y vuelve a importar la carpeta ControlMax_Comercial en APKForge.
7. Compila e instala la APK. Al abrirla aparecerá el ID de instalación.
8. Envía ese ID al administrador. En StockPro Admin crea la licencia para ese ID y descarga el archivo .dat.
9. En la APK selecciona el .dat y pulsa Validar y activar.

IMPORTANTE
- El archivo .dat de ejemplo antiguo NO sirve. Debes generar una licencia desde tu Generador de Licencias HTML usando el ID que aparece en la APK.
- Nunca incluyas ni distribuyas la clave privada dentro de la APK. Solo la clave pública.
- Si se cambia o borra el almacenamiento/datos de la aplicación, puede generarse otro ID y será necesario emitir otra licencia.
- La validación criptográfica requiere Web Crypto (crypto.subtle). APKForge debe ejecutar el contenido en un WebView Android que lo soporte. Si APKForge bloquea Web Crypto en su modo de carga, habrá que habilitar un origen seguro o integrar la validación nativamente.
- Este paquete conserva una estructura mínima de ControlMax Comercial; el ZIP original recibido no contenía la aplicación POS funcional, solo una pantalla básica y archivos JS de ejemplo.
