Stock Counter Web APK v1

1) index.html must stay at ZIP root.
2) Intended for HTML-to-APK/WebView builders.
3) Initial stock is parsed from FIFO_Report_W0251_20260921125813.pdf: 304 rows (CE1 260, CO8 27, CO9 17).
4) Camera uses Android WebView/browser getUserMedia plus BarcodeDetector when available; manual/Bluetooth scanner input is included as fallback.
5) Data is stored locally on the phone. New CSV imports are kept as separate stock sets.
