NAVYUVA DURGA POOJA COMMITTEE - APK READY WEB PROJECT

Included:
1. Full-screen Maa Durga first screen.
2. नवयुवा दुर्गा पूजा समिति / रेलवे गेट, मारकुंडी.
3. Chanda entry: name, address, mobile, amount, Cash/UPI.
4. Automatic receipt number.
5. Receipt history and total collection.
6. Print/PDF from Android print dialog.
7. WhatsApp sharing.
8. Admin section (demo PIN 1234).
9. Data stored locally on the phone/browser.

HOW TO MAKE APK:
- Extract this ZIP.
- Keep index.html and durga.png in the same folder.
- Use any Android WebView/HTML-to-APK builder and select index.html as the start page.
- If the builder asks for assets, include durga.png.
- For a production app, replace local storage with Firebase and add real OTP, cloud backup, verified UPI payments, and automatic WhatsApp/PDF delivery.

This is the editable source project, not an APK itself.
