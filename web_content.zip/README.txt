VICHIKA MOD WEBSITE DEMO
========================

IMPORTANT
- index.html is at the ZIP root, for website ZIP importers such as Zipped Site.
- This is a front-end demo only. It does NOT include a secure server, real account authentication,
  cloud file storage, or real admin authorization.
- Uploaded files are not transferred to a server. The submission form only adds demo metadata in memory.
- Do not enter real passwords. The "owner" username only previews the local review panel.
- A real marketplace needs a backend (for example Firebase) with Authentication, Firestore,
  Storage, and security rules.

HOW TO USE ON ANDROID
1. Download VichikaMod_Website.zip.
2. Open Zipped Site and choose the ZIP.
3. The archive contains index.html at its root.
4. Preview the site. If the app asks you to create/publish, follow its on-screen steps.
