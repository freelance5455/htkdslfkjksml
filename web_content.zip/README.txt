GAME GENIE AUFA MAX
ENTRY: index.html
SEMUA FILE LANGSUNG DI ROOT ZIP.

Katalog musik di aplikasi adalah metadata/judul contoh, bukan rekaman. Rekaman lagu berhak cipta tidak dibundel. Gunakan file audio yang kamu miliki atau yang memang berlisensi untuk dipakai/diunduh. Tidak ada ripping atau bypass Spotify/YouTube.

Fitur: landscape, neon anime, booster controls, game launcher, search/filter katalog, player, import audio legal, AUFA BOT.
