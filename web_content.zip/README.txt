Yeasin Telecom 17 — Firebase Sync

এক ফোনে Admin > Edit Mode > Save করলে Firebase Realtime Database-এর মাধ্যমে অন্য ফোনেও অফার আপডেট হবে।

Firebase project: manik-telecom-26c92
Web app: Yeasin Telecom Web
