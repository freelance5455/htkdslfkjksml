Baraa v16 — Luxe
- NEW hidden gift: "A star named Baraa" (replaces the old gift). Hold the two-arrows (sort) button in the notes screen for 3 seconds.
- NEW secret password screen (different look from the main lock). Secret word is NOT case-sensitive. Default: 1997.12.7
  After the correct word: the number "1" shows for 1.5 seconds, then the gift opens.
  To change the word: open the secret screen and tap "تغيير كلمة السر" (enter the current word, then the new one twice).
  The new word is saved on the device; clearing the app's data resets it to the default.
- NEW main lock screen: round keypad buttons with glowing dots (PIN 4 or 6 digits), or switch to a normal password.
  Existing passwords keep working (a numeric one shows the keypad, any other shows the text field; you can switch at any time).
- Total package size is under 5 MB (gift images/music re-compressed; gift lives in assets/gift/).
- v15: gift runs smoother (cached glow sprites, lighter canvas, app paused behind the gift, gift preloaded while typing the word).
- v16: fixed gift sky (preload size bug); default secret word is now Baraa.1

- music fix: gift music re-encoded (stereo, ~60kbps, proper header) + auto-resume if playback stalls; package ~4.8 MB; default secret word is now 1997.12.7 (year.month.day)
- gift gate: countdown to 7 Dec 2026 (days/hours/min/sec) above the lock box; on 7 Dec the password box disappears and only the open button remains (password also works before that day); after that day the normal password returns
- hidden: press the About photo for 1 second -> shows assets/self_photo.jpg with assets/self_music.mp3 (back/X closes and stops the music); gallery images resized to 1200px and both songs re-encoded (48k/40k, 32kHz) to stay under 5 MB
- about photo: now a single tap (not long press); self_music.mp3 replaced by the edited Spectacles track (98s); gift bgm.mp3 is now 'Jonna och Johan' (mono 32k to fit 5 MB). Previous gift track (Glimpse slowed) removed on request, can be restored.
- restored gift music Glimpse (slowed) (48k, -2dB to avoid clipping); about-photo music re-encoded 48k with -2.5dB headroom + soft fades (fixes crackle)
