RAHUL SHOP
===========
এটি একটি মোবাইল-friendly demo marketplace frontend.

চালানো:
1. index.html ফাইলটি Chrome-এ খুলুন।
2. "+ Sell ID" চাপ দিয়ে listing যোগ করুন।
3. Listing এই ব্রাউজারের localStorage-এ থাকে।

গুরুত্বপূর্ণ:
- এটি এখন offline/local demo; অনলাইনে সবাইকে একই listing দেখাতে backend/database লাগবে।
- কোনো Free Fire password বা login credential অ্যাপে রাখবেন না।
- বাস্তব marketplace প্রকাশের আগে Terms, Privacy Policy, moderation এবং নিরাপদ payment workflow যোগ করা উচিত।

পরবর্তী ধাপে এই একই UI-কে Firebase/Supabase backend-এর সাথে যুক্ত করে multi-user online version করা যাবে।
