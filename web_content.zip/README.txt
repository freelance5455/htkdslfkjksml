NEXUS TAEKWONDO COMPLETE PC APP
Open PC_APP_COMPLETE.html in Chrome/Edge.
Staff: owner / 1234
Features: customers, automatic IDs/PINs, payments, bookings at ₹200/hour, attendance, QR scanner with webcam when supported, manual QR ID fallback, dashboard, reports, CSV, backup/restore.
For phone+PC same-Wi-Fi sync, use the local server package from the earlier Wi-Fi version; this PC app itself stores data locally.