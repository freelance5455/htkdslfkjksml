Baraa v9.2 — My Gallery fixes
- Gallery theme selector now appears above the Gallery screen instead of behind it.
- Gallery image viewer is above the Gallery intro and opens as a large view.
- Opening an artwork immediately hides the Gallery intro overlay.
- Existing Baraa and My Gallery features preserved.
