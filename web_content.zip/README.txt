MULTI CERTIFICATE MANAGEMENT & ONLINE VERIFICATION SYSTEM

CERTIFICATE TYPES
1. Operator Certificate
2. Electrical Training Certificate
3. Welder Training Certificate
4. Computer Training Certificate
5. AC Technician Training Certificate

FEATURES
- Separate button for each certificate type
- Certificate-specific title/design color
- Automatic Certificate ID
- Google Sheets database
- Admin login
- Issue certificate
- Search certificates
- Revoke certificate
- QR code
- Public online verification
- A4 print / Save as PDF
- Dashboard counts

INSTALL
1. Create a Google Sheet.
2. Extensions > Apps Script.
3. Put Code.gs in Code.gs.
4. Create HTML file named Index and paste Index.html.
5. In Code.gs edit COMPANY, ADDRESS, PHONE, EMAIL.
6. Run setupSystem() once and authorize.
7. Deploy > New deployment > Web app.
8. Execute as Me.
9. Who has access: Anyone.
10. Open the Web App URL.

DEFAULT LOGIN
Username: admin
Password: Admin@123

IMPORTANT
Change the password after first login.

PUBLIC VERIFICATION
Anyone can open the Web App URL and enter a Certificate ID.
QR codes automatically open the same Web App with ?id=CERT-YYYY-000001.

The five buttons are:
Operator
Electrical
Welder
Computer
AC Technician

Each certificate uses the same database and verification system.
