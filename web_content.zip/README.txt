FREE GUY TECH AI - ZIPPED SITE PACKAGE
======================================

IMPORT
1. Download this ZIP.
2. In HTML to App, choose "Zipped site".
3. Select this ZIP. index.html is at the ZIP root.
4. Build the APK, then open it.

ACTIVATE LIVE AI
1. Open Setup inside the app.
2. Create a Gemini API key at https://aistudio.google.com/app/apikey
3. Paste it into the API key field and Save.
4. Try AI Chat. Image Studio uses the configured image model.

FEATURES
- Gemini AI chat with multi-turn conversation context
- Image generation request and image download (if model access is enabled)
- Local chat history, new chat, clear history and export
- Copy last AI answer
- Free Guy Tech black/orange branding

IMPORTANT LIMITATIONS
- This is a front-end app package, not an offline AI model.
- Live requests require internet, a valid Gemini API key, and available API quota.
- Google controls which models, regions, quotas and prices are available. Do not assume unlimited free usage.
- Default chat model: gemini-2.5-flash. Default image model: gemini-3.1-flash-image. If a model is unavailable to your key, edit its name in Setup to a model currently enabled for your account.
- The API key is stored in local app/browser storage. Do NOT distribute a public APK with your personal key embedded or ask every public user to share your key. For a public multi-user product, build a secure backend that holds the key and applies rate limits.
- HTML-to-App packaging and device WebView settings can affect network access. If chat fails in the APK, check app internet permission and WebView/network settings.
