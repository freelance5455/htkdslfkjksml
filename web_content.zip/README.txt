WARMATE 12.12

Cara menjalankan:
1. Ekstrak file ZIP.
2. Buka index.html di browser Android (Chrome disarankan).
3. Tambahkan produk dengan link Shopee.
4. Atur waktu countdown sesuai jadwal promo.
5. Checklist dan daftar produk disimpan di browser perangkat.

Upload gratis:
- Buat repository baru di GitHub.
- Upload index.html, style.css, dan app.js ke root repository.
- Buka Settings > Pages, pilih Deploy from a branch, pilih main dan /(root), lalu Save.

Catatan:
Website ini hanya alat persiapan. Tombol "Buka produk" membuka halaman Shopee.
Tidak ada login Shopee, bot checkout otomatis, atau jaminan stok/keberhasilan pembelian.
Data tersimpan lokal di browser perangkat, bukan tersinkron ke perangkat lain.
