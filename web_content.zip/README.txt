MATEMATIKA QUIZ
YARATUVCHI: IBRAGIMJANOV KARIMJON

Bu loyiha offline ishlaydigan HTML quiz ilovasi.
APK builder saytiga ZIP faylni yuklab, Android APK sifatida build qilish mumkin.
