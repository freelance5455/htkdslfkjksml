CET MASTER 2028 — Web app package

This ZIP contains a mobile-friendly HTML/CSS/JavaScript recreation of the starter app's visible features:
- CET MASTER 2028 name and PCM dashboard
- Physics, Chemistry and Mathematics chapter lists
- English and Hindi sample revision notes
- One sample Physics MCQ with answer feedback
- Chapter completion tracking stored on this device
- Progress page and light/dark toggle

IMPORTANT:
This is a web version, not a conversion of the original Kotlin source code.
The app name and core starter sections are retained, but the web implementation may look or behave slightly differently from the native Android project.
The chapter lists and notes are starter/sample content, not a complete verified MHT CET 2028 syllabus or full notes bank.
No APK is included in this ZIP.

To try an HTML-to-APK service:
1. Upload this ZIP to the service's HTML/Web app import option.
2. Set the start page to index.html if asked.
3. Preview and test on mobile before building.
4. Download the APK only after the preview works.
Use a trusted build provider and check any charges before starting.
