R-MONEY OFFLINE WEB ZIP
----------------------
This archive contains index.html at the archive root, for converters that expect a website ZIP.

IMPORTANT:
- This is an offline HTML/WebView app package, not a compiled native Android APK.
- In the ZIP-to-APK app, choose this ZIP using the local ZIP file picker. Do not enter appassets.androidplatform.net as a website URL.
- If the converter has a mode selector, choose local website/HTML ZIP mode, not remote website/URL mode.
- Some converters may still fail if their generated APK does not correctly load local index.html. This ZIP cannot fix a converter-generated APK runtime bug by itself.
- App data is stored in WebView local storage; uninstalling/clearing app data may erase it. Export a JSON backup from inside the app when possible.
