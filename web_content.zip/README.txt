CPR METRONOME - OFFLINE WEB APP SOURCE

LOUDER BEEP VERSION

Fixed tempo: 120 BPM (one beat every 500 ms).
One button toggles green START to red STOP.
Louder, fuller digital tick generated locally by Web Audio.
No vibration, ads, analytics, external libraries, or internet permission.
The metronome stops when the page is hidden.

Actual audible loudness also depends on the phone's media volume and speaker.
Set media volume to a comfortable audible level before use.

This is a web app ZIP, not an APK. Upload it to an HTML/WebView-to-APK
service that explicitly supports ZIP uploads.
