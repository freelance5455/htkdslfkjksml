FreshCheck – Android build package

IMPORTANT:
- index.html is at the ZIP root.
- logo.png is the final FreshCheck logo.
- No external internet/CDN is required for the core app.
- First launch: FreshCheck + “Know your food. Trust your senses.”, then language selection.
- After language selection, the interface uses only the selected language.
- Product list starts empty.
- Expiry date can always be entered manually. Camera/photo is optional.
- Product status changes automatically: green (>7 days), orange (0–7 days), red (expired).

For HTML-to-APK builders: import this ZIP as a folder/ZIP project and set the app name to FreshCheck.
