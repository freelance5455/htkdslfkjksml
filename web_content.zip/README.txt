Lønn & AAP
============
Dette er en offline webapp som kan pakkes inn som Android APK med en ZIP-to-APK/HTML-to-App-tjeneste.

Startfil: index.html
Appnavn: Lønn & AAP
Standard satser: jobb 1695 kr/dag, AAP 1072 kr/dag, skatt 13 %.
Neste AAP: 5. oktober 2026, deretter hver 14. dag.
Lønn: den 12. måneden etter.

Ingen server eller konto er nødvendig for selve appen.
