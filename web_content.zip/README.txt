Kabul Horse Rider - HTML5 touch game (index.html in zip root, landscape).
Convert to Android app: upload this zip to WebIntoApp / AppsGeyser / Median / Appilix (ZIP/HTML option) and set orientation = Landscape.
Or Capacitor: npm i @capacitor/core @capacitor/cli; npx cap init; webDir = this folder; npx cap add android.
