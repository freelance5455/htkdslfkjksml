Color Formula Lab — Universal Smart Offline

Это автономная веб-версия приложения. Все расчёты выполняются локально; сетевые API и внешние CDN не используются.

Для ZIP-to-APK сборщика index.html должен находиться в корне ZIP. Используйте архив ColorFormulaLab_Offline_WebApp.zip.
