Mimic Shadow HTML App

Upload this ZIP to an online HTML-to-APK / website-to-APK builder.
Entry file: index.html
Recommended app name: Mimic Shadow
Microphone permission is required for speech recognition.
