SUMIT MOBILE SERVICE CENTRE WEBSITE

Files:
- index.html: complete responsive website (HTML, CSS, JavaScript in one file)

Preview:
Open index.html in a browser.

Included:
- Responsive mobile-friendly design
- Spare-parts catalogue with search and category filters
- Popular phone brands
- WhatsApp enquiry links and enquiry form
- Contact/address section and Google Maps search link

Important:
This is a ready-to-upload website starter, not a live published domain. Catalogue categories are enquiry categories; do not advertise every part as confirmed in stock unless you verify your inventory. Replace or verify contact details, address, hours, and claims before publishing.

To publish free:
1. Create a GitHub account and a new public repository.
2. Upload index.html to the repository root.
3. In repository Settings > Pages, choose Deploy from a branch, select main and /(root), then Save.
4. GitHub will provide a live URL. For www.sumitmobileservicecentre.com, buy/register the domain if not already owned and configure its DNS plus GitHub Pages custom-domain settings.
