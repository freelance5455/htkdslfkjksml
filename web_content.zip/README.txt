30-Day Reset app files

Included:
- index.html: the interactive tracker
- manifest.webmanifest: web app metadata
- service-worker.js: basic offline cache support

Important:
For a true Install App / Add to Home Screen experience, these files need to be served from an HTTPS website. A downloaded HTML file alone is not guaranteed to install as an app. You can open index.html in a browser to use it, but for a home-screen app icon, host the folder on an HTTPS static host first, then open that URL in Chrome on Android and choose ⋮ > Add to Home screen / Install.

Progress is saved in browser storage when supported. Export/copy the summary regularly as a backup.
