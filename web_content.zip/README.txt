MITABONI HIGH SCHOOL ANDROID APP

This is a ready-to-open Android Studio project.
The school website is bundled inside the app, so it can open without needing a separate website file.

WHAT IS INCLUDED
- App name: Mitaboni High School
- Navy/gold school design
- School website and generated school image
- Phone: 0734953667
- Email: mitabonihighschool@gmail.com
- Location: Karen, Nairobi, Kenya
- Launcher icon
- Portrait phone layout

HOW TO BUILD THE APK
1. Open Android Studio on a computer.
2. Choose "Open" and select the folder named Mitaboni_High_School_Android_App.
3. Let Android Studio download/sync the required Gradle and Android components.
4. Choose Build > Build APK(s).
5. Android Studio will create an APK you can copy to your phone and install.

IMPORTANT
This chat environment cannot install an APK directly onto your Android phone. The project is ready for Android Studio to build.
