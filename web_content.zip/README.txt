EDGE CLOUD ADMIN PANEL — SOURCE ZIP

এই ZIP-এ অ্যাডমিন প্যানেলের index.html এবং Firestore rules আছে। এটি APK নয়।

User Panel-এর সঙ্গে ঠিক একই Firebase project/config ব্যবহার করুন। index.html ফাইলে firebaseConfig-এর YOUR_API_KEY, YOUR_PROJECT_ID ইত্যাদি আপনার Firebase Console > Project settings > Your apps > Web app থেকে পাওয়া মান দিয়ে পূরণ করুন।

প্রয়োজনীয় Firebase services: Authentication (Email/Password), Cloud Firestore. Firestore Database তৈরি করে firestore.rules প্রকাশ করুন।

অ্যাডমিন লগইনের পর code adminUsers/{Firebase Auth UID} ডকুমেন্টে active:true চেক করে। অ্যাডমিন অ্যাকাউন্ট তৈরি করে UID কপি করুন এবং Firebase Console থেকে adminUsers collection-এ UID-নামক document তৈরি করে {"active": true, "role": "admin"} সেট করুন। এটি কেবল বিশ্বস্ত মালিক/প্রশাসক করবেন; সাধারণ user-কে এই অনুমতি দেবেন না। নিরাপদ প্রোডাকশনে role provision করার জন্য trusted Admin SDK/backend ব্যবহার করুন।

ফিচার: dashboard, customer management, package create/assign, bill create, payment verification, complaint handling/replies, announcements.

গুরুত্বপূর্ণ: এটি User Panel-এর সঙ্গে একই Firebase database ব্যবহার করবে, কিন্তু Admin Panel আলাদা অ্যাপ/ইন্টারফেস। APK বানাতে Android wrapper/build tool-এ এই index.html প্যাকেজ করতে হবে। শুধু ZIP খুলে ইনস্টল করা যাবে না।
