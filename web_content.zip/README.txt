KOTAK LIFESTYLE SURVEY - APKFORGE READY

Use index.html as the app start page / local HTML source in APKForge.

Recommended settings:
App name: Kotak Lifestyle Survey
Orientation: Portrait
Internet permission: Not required for normal offline use
Start page: index.html

The app stores survey records in browser/app local storage. Export CSV regularly as backup.
