FR FURNISHING QUOTATION MAKER - MOBILE/PWA

This version is a Progressive Web App (PWA).

ANDROID:
1. Host/upload this folder on an HTTPS website/server.
2. Open the website in Chrome on Android.
3. Tap "Install App" if shown, or Chrome menu -> Install app / Add to Home screen.
4. The app then opens as a standalone app.

IMPORTANT:
A ZIP file cannot be installed directly as an Android APK. This is a web app/PWA.
For the Install App button and offline caching to work, the app must be opened from HTTPS
(or localhost during development). No Play Store is required.

DESKTOP:
Open the HTTPS website in Chrome/Edge and use the Install App button or browser install icon.
