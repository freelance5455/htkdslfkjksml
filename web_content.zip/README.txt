LIGHTEDIT OFFLINE V1
====================
This is a self-contained offline photo editor made with HTML/CSS/JavaScript.

Features:
- Open local photo
- Brightness / Contrast / Saturation / Sharpness
- Rotate / Flip
- Crop by dragging on canvas
- Text overlay
- B&W / Warm / Cool / Vivid / Fade filters
- Undo / Redo
- Reset
- Save as JPG
- No external libraries, CDN, API, login or server required

APK:
Upload this whole folder as a ZIP to a compatible HTML-to-APK builder.
For an offline app, choose a mode that bundles local files and does not require a remote URL.

Folder:
index.html
style.css
app.js
README.txt
