VEHICLE TRAFFIC ANALYTICS – ZIPPED.SITE PACKAGE

UPLOAD:
1. Upload this ZIP directly to Zipped.site.
2. The ZIP contains index.html at the ROOT of the archive.
3. Preview the site, then return to Zipped.site to complete its publish/create step.

FEATURES:
- Professional BI dashboard with KPI cards, monthly line chart and comparison table.
- Select two comparison years.
- Daily data entry, edit and delete.
- Daily, monthly and yearly comparisons.
- Difference, percentage difference, remaining-to-match calculation and N/A when first-year value is zero.
- English and Sinhala UI.
- Print / Save as PDF using the phone browser print dialog.
- CSV backup export and CSV import.
- Responsive mobile layout.

IMPORTANT:
This is a browser-based web app package for Zipped.site, NOT a native Android APK.
Records are saved in local browser storage on this device. Export CSV backups regularly.
For Sinhala PDF output, use a browser/device with Sinhala font support. The page requests Noto Sans Sinhala from Google Fonts when internet is available.
