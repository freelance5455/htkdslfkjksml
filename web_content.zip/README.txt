SellEasy MVP
-------------
This is the Android-ready web app package.

The app is a functional MVP prototype. It stores saved content locally on the device.
The current content generator is local/demo logic; a real Gemini API connection can be added later.

For APK packaging, upload this ZIP to a service that accepts HTML/ZIP-to-APK conversion, or import it into an Android web-to-app builder.
