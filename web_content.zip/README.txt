RAFAQAT RACING — Professional Mobile Game Package
----------------------------------------------------
This is an original mobile-first HTML5 racing game package.
Main file: index.html
Assets: assets/logo.svg
No external libraries or paid assets are required.

For ZIP-to-APK services:
- Upload this ZIP.
- App name: RAFAQAT RACING
- Version: 1.0.0
- The game is designed to run offline after packaging because its core files are local.

Important:
This package is a web/HTML5 game source package, not a compiled APK.
To make an APK, use a trusted Android wrapper/build service or an Android build environment.
