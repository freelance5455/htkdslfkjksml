FocusFlow Android package

Contents:
- index.html: the original FocusFlow app
- icon.png: FocusFlow launcher icon

The HTML is self-contained and uses localStorage for app data.
It can be packaged as an Android WebView app and can work offline when bundled.
