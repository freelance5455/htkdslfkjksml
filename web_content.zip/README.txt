ATLAS X — ANDROID INSTALLATION

1. Open the HTML to APK app shown in your screenshot.
2. Easiest: choose "HTML File to APK" and upload ATLAS_X_Android_Standalone.html.
3. Or choose "ZIP File to APK" and upload ATLAS_X_HTML_to_APK.zip (index.html is at the ZIP root).
4. Set app name: ATLAS X or Sequence Intelligence.
5. Optional icon: atlas_x_icon.png (inside ZIP, or download separately).
6. Enable Internet permission / allow external HTTPS in the APK builder if available. JavaScript and local storage must be enabled.
7. Generate signed APK. Review requested permissions; avoid giving unnecessary access. Install only from sources you trust.
8. Open APK. Its 14 research sections and Oct 6–18 archived sample work offline.

LIVE RESULTS:
- Countdown animates every second. Automatic results require Netlify endpoint and a separately configured authorized provider feed. Without both, there is no real live feed.
- Optional: publish companion Netlify backend and paste your HTTPS site address in ATLAS X > Settings > Android app · Server link.
- It checks server regularly while open. Android may suspend checking while the app is closed or in the background.
- OLG approximate Eastern times: 09:30, 13:30, 16:00, 19:30, 23:30.
- Never assume models can predict a fair random draw. Two distinct numbers always have 2/15 fair-draw probability.

MODEL / DATA:
- 12 rule sets including a uniform baseline, walk-forward backtests, adaptive ensemble based on past losses, draw map, simulator, ticket analysis, prediction ledger and manual input.
- Historic data are a fixed archive, not live; verify ticket outcomes at the official OLG site.
- This package does not scrape Lottery Post or try to bypass provider terms or app restrictions.
