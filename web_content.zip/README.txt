AccoNova 1.2 — Smart accounting · حسابداری هوشمند
=================================================
این بسته / This package
- index.html     برنامهٔ نهایی (فشرده‌شده، بدون کد آزمون) / the production app (minified, no test code)
- server/        سرور بدون وابستگی (Node 20+): دستیار هوش مصنوعی واقعی، اشتراک Stripe، توکن امضاشدهٔ طرح
- public/ tools/ shell/ tests/ compose.yaml deploy/  فایل‌های PWA، لایه‌ی اپ، تست و تنظیمات HTTPS (جزئیات: docs/DEPLOY.md بخش ۷)
- Dockerfile, package.json, docs/DEPLOY.md  راه‌اندازی / how to deploy
- LICENSE.txt

بدون سرور هم کار می‌کند (فقط محلی): حسابداری، گزارش‌ها، بکاپ، ۵ زبان. دستیار هوشمند و پرداخت آنلاین فقط با سرور کار می‌کنند.
Works without a server (local-only): bookkeeping, reports, backup, 5 languages. The AI assistant and online billing need the server.

پیش از انتشار / Before you publish
1) docs/DEPLOY.md را بخوانید؛ فایل server/.env.example را پر کنید (کلید Anthropic، کلیدهای Stripe). کلیدها هرگز داخل index.html نیستند.
2) بلوک LEGAL CONFIG بالای index.html را پر کنید (مالک، ایمیل، قانون حاکم، بازپرداخت). متن‌های قوانین الگو هستند؛ وکیل باید بازبینی کند.
3) ترجمهٔ عربی/فرانسوی/آلمانی ماشینی است؛ فرد بومی بازخوانی کند.
4) هیچ کدی که به مرورگر می‌رسد کاملاً غیرقابل‌کپی نمی‌شود؛ بخش‌های ارزشمند (AI، پرداخت، طرح) سمت سرور هستند. جزئیات در DEPLOY.md.

ارز و قیمت / Currency
ارز پیش‌فرض شرکت‌ها دلار آمریکا (USD) است؛ اشتراک‌ها ۹ و ۲۹ دلار در ماه (نمونه؛ قیمت واقعی را در Stripe و در src/core.js تنظیم کنید).

سورس خصوصی / Private source
AccoNova-source-PRIVATE.zip شامل src، tools و tests است؛ آن را عمومی نکنید. تست‌ها: bash tests/run-all.sh
