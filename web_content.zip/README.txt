AUTO TEXT COLOR - FINAL TV SETTINGS FIX

Previous app format/features preserved.
Settings interaction is hardened for Android 7.x WebView / TV remote / touch:
- touchstart
- click/mouse
- DPAD/Enter/OK keyboard events
- explicit TV focus

Save Settings remains available and persistent storage uses localStorage with cookie fallback.
