UNIVERSALAI - APK Forge uchun loyiha (index.html, bitta fayl)
APK Forge'da INTERNET ruxsatini yoqing. Birinchi ishga tushirishda WebLLM kutubxonasi va modellar internetdan yuklanadi.
