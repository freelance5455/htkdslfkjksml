VARAVU SELAVU - START HERE

This is the source project for your Varavu Selavu web app / APK wrapper.

IMPORTANT:
- The app uses Firebase Anonymous Authentication in the background; there is no visible login screen.
- Enable Authentication > Sign-in method > Anonymous in your Firebase project.
- Paste the contents of firestore.rules into Firestore Database > Rules and Publish.
- Do NOT use public read/write rules.
- The app's six-digit password is set on first launch by the user and stored as a PBKDF2 hash in this browser/device. It is a local screen lock, not cloud account authentication.
- Anonymous Firebase identity is tied to this browser/app installation. Clearing app data or reinstalling may lose access to that identity's cloud records. Export regular JSON backups.
- This starter uses Firebase web SDK imports and must be hosted on HTTPS or localhost; opening index.html directly as a file will not work reliably.
- For an APK, first host the app on HTTPS, then use a reputable website-to-APK wrapper that loads your hosted URL. Test the generated APK before entering important records.

FIREBASE PROJECT:
Project ID: varavu-selavu-c2750

FILES:
index.html       App screens
style.css        App design
app.js           Calendar, editable rows, saving/loading/search/export/import
firebase-config.js Firebase project configuration
firestore.rules  Required database protection rules
manifest.json   PWA metadata
sw.js            Basic app shell cache

CLOUD DATA PATH:
users/{anonymous-auth-uid}/dailyRecords/{YYYY-MM-DD}

The "மொத்தம்" column is manually editable. No automatic balance calculation is performed.
