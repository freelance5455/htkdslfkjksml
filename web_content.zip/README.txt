SNAKE ANDROID

Đây là Android Studio project bọc game HTML Snake bằng WebView.

Cách build APK:
1. Mở thư mục SnakeGame bằng Android Studio.
2. Chờ Gradle sync.
3. Chọn Build > Build APK(s).
4. APK debug thường nằm trong:
   app/build/outputs/apk/debug/app-debug.apk

Game nằm tại:
app/src/main/assets/index.html
