QR MASTER 2.0
QR generator, camera scanner, image scanner and local media preview.
Photo/video files are not uploaded online.
Camera scanning requires a supported secure browser context
or an Android wrapper that grants camera access.
