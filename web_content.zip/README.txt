Medicine Name Guessing Game — 20 questions
Extract and open index.html in Chrome. HTML game, not an APK.


Coin system: Earn 10 coins for each correct answer. The balance is saved on this device/browser and is separate for this game. The original game layout, colours, and emojis are preserved. The handwritten font uses Google Fonts and needs internet access to load.

Theme Shop: Red, Blue, and Black themes cost 100 coins each. Original theme remains free. Coins and purchases are saved locally on this device/browser.
