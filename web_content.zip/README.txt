EVSL Auto Maintenance Management — FULL ADVANCED v6

Included: offline responsive web app, Hindi/English toggle, dashboard, vehicle master with editable machine details and hour/month PM intervals, all-breakdown register with search/date/status filters, breakdown edit/delete, PM register, service history, spare inventory with part-number search, stock movements, daily work reports, fault diagnosis, vehicle parts master, analytics, CSV export, JSON backup/restore and previous local auto-backup.

HOW TO USE (Android):
1. Extract this ZIP.
2. Open EVSL_Auto_Maintenance_FULL_ADVANCED_v6.html in Chrome.
3. Use Chrome menu > Add to Home screen for app-like access.
4. Use Backup Now regularly and keep the JSON backup outside the phone.

IMPORTANT DATA SAFETY:
- This is an offline browser app, not a signed Android APK.
- Existing data in an older app/browser is not automatically merged. Export its JSON backup first. In this version open Backup / Restore and restore that JSON.
- Do not clear Chrome/site storage unless you have a backup.
- A real APK update preserving app data requires building/signing with the same Android package and signing key.
