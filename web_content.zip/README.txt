# Dayal Computer Center - Mobile App (PWA)
Proprietor: Rahul Kumar
Address: Shahu Ji Market, Salarpur Chauraha, Sitapur (U.P.) - 261135
Mobile: 9005281033
Email: rkverma02014@gmail.com

## Is App Ko Mobile Mein Kaise Install Karein?
Yeh ek Progressive Web App (PWA) hai jo Android aur iPhone dono mein bina Play Store ke seedha mobile app ki tarah install hota hai (aapke Dayal Computer Center logo ke saath):

1. Is ZIP ke sabhi 6 files (index.html, style.css, script.js, manifest.json, sw.js, logo.png) ko kisi free hosting jaise **Netlify** (app.netlify.com/drop) par drag & drop karke upload karein.
2. Aapko ek link milega. Us link ko apne mobile ke Chrome browser mein kholein.
3. Upar **"📲 Install App"** button dikhega (ya Chrome ke 3 dots par click karke **"Add to Home Screen / Install App"** chunein).
4. Aapke phone ki home screen par aapke logo ke saath **Dayal Computer** app icon ban jayega!

## APK Banane Ke Liye:
Agar aapko `.apk` file chahiye to live link banne ke baad **PWABuilder.com** ya **AppsGeyser** par link dalkar 1 click mein Android APK download kar sakte hain.
