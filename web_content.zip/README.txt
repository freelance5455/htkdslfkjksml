SAVARIYA SETH BILLING - Phone Version

1. index.html ko phone ke browser me open karein.
2. App internet ke bina bhi data browser ke local storage me save karta hai.
3. New Bill: customer + products + qty + rate + payment.
4. History: saved bills aur Share.
5. Stock: product, quantity, selling rate.

APK banane ke liye is web app ko kisi trusted WebView/PWA wrapper service ya Android development environment me package kiya ja sakta hai.
