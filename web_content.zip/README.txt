GoalPulse Web-to-APK package

Upload this ZIP to a website/HTML-to-APK builder that accepts a ZIP with index.html at the ZIP root.

App name: GoalPulse
Type: mobile-first HTML/PWA prototype

Included:
- index.html
- manifest.json
- sw.js

Important: match data in this package is demo data. Live scores/API-Football, real news, notifications, and automatic season rollover still need backend/API integration.
