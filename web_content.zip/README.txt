TVBOX - versión HTML para convertir a APK
URL M3U: http://tvboxdep.duckdns.org:8080/canales.m3u
Abrí index.html en un conversor HTML/ZIP -> APK.
La interfaz está diseñada en negro + rojo neón.
