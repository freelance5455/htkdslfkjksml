# Royal Number Showdown — Ready-to-Use Bundle

এই ZIP প্যাকেজটির ভেতরে যা যা আছে:
1. `index.html` — সম্পূর্ণ গেম ফাইল (কোনো সার্ভার বা ইনস্টলেশন ছাড়াই সরাসরি যেকোনো ব্রাউজারে ওপেন করা যায়)।
2. `manifest.json` — ওয়েব অ্যাপ / PWA ম্যানিফেস্ট ফাইল।

## ফোনে বা পিসিতে সহজে চালানোর নিয়ম:
1. `royal-number-showdown-bundle.zip` ফাইলটি ডাউনলোড করে **Extract / Unzip** করুন।
2. ভেতরের `index.html` ফাইলটি **Chrome / Safari / Edge** ব্রাউজারে ওপেন করুন।
3. ফোনে খেললে ফোনটি **ল্যান্ডস্কেপ (আড়াআড়ি)** করে ধরুন।

## Android APK বানাতে চাইলে (বিকল্প):
- আপনি যদি সত্যিকারের `.apk` ফাইল চান, তবে **PWABuilder** বা **Website 2 APK Builder** / **Android Studio (WebView)**-এ এই `index.html` (অথবা লাইভ লিংক) দিলে কয়েক মিনিটেই `.apk` তৈরি হয়ে যাবে।
- সরাসরি এখান থেকে Android keystore দিয়ে সাইন করা `.apk` বাইনারি জেনারেট করা যায় না, তাই সবচেয়ে দ্রুত উপায় হলো ZIP আনজিপ করে `index.html` ওপেন করা অথবা কোনো ফ্রি WebView-to-APK টুল ব্যবহার করা।
