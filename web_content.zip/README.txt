FPS combat sim
- fps-sim.html : the full playable 3D game (HTML + JavaScript, open in any browser)
- core/ : the game's rules core (2-shot kill, ammo/reload, 1 death -> 2 spawns capped at 14) ported to each language.
  Every port prints: shots=2 alive=7 mag=30 res=60 (assembly exits with status 2).

Run (inside core/):
  core.cpp|g++ core.cpp -o t && ./t
  core.c|gcc core.c -o t && ./t
  Core.cs|mcs Core.cs -out:t.exe && mono t.exe
  core.rs|rustc core.rs -o t && ./t
  core.py|python3 core.py
  Core.java|javac Core.java && java Core
  core.js|node core.js
  core.ts|tsc core.ts --outDir out && node out/core.js
  core.lua|lua core.lua
  core.gd|godot --headless -s core.gd
  core.go|go run core.go
  core.swift|swiftc core.swift -o t && ./t
  core.kt|kotlinc core.kt -include-runtime -d t.jar && java -jar t.jar
  core.dart|dart run core.dart
  core.rb|ruby core.rb
  core.php|php core.php
  core.pl|perl core.pl
  core.zig|zig run core.zig
  core.hs|runghc core.hs
  core.s|gcc -nostdlib -static core.s -o t && ./t; echo exit=$?
