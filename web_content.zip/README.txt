STAR GULLAK V4
Ready Android project based on the supplied V4 HTML.

Open the extracted folder in AndroidIDE/Android Studio.
Then build the debug APK and install it.

The original V4 HTML is stored at:
app/src/main/assets/index.html
