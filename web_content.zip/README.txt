Contractor Pro V17.5 Full Commercial Edition
Root entry: index.html
Based directly on the verified V17 structure. Existing local modules are preserved.
Added: Commercial Center, professional document builder, online account bridge, cloud sync bridge, license validation bridge, client portal, AI server bridge with offline fallback, billing provider bridge, and improved app-lock UI.
Important: real email delivery, production cloud, payment provider, and generative AI require the provided backend and production provider configuration.
Splash asset was preserved unchanged in the HTML.
