Baraa Secure Offline — original design; opening message; Arabic/English; local encrypted notes; no cloud backup.
Version update: Added About/عن Baraa creator section with profile photo and Arabic/English biography.

v8.1 — Fixed: removing a note's password was confusing (the old "leave both fields blank" toggle silently kept the password if tapped twice). Now there are two clear separate buttons — "Change password" and "Remove password" — with an on-screen confirmation before you save.

v8 — Save/Delete bug fix + Modernization:
- Fixed: missing makeId() function that silently broke Save and Delete.
- New: search notes, sort (newest/oldest/title), filter chips (all/favorites/pinned).
- New: pin notes, tag notes with a color, live word/character counter while writing.
- New: encrypted backup export/import (.json file), including a "restore backup" option right on the lock screen.
- New: drawer stats (total notes, favorites, pinned, trash).
- New: in-app confirm dialogs and a proper password-change form (replacing plain browser prompts/alerts).
- New: toast notifications, light haptic feedback, smoother modal/drawer animations, nicer splash/lock screens, tap-to-skip splash, PIN lockout after 5 failed attempts.
- Same core: local-only AES-GCM encrypted storage, PBKDF2 key derivation, 30-day trash, offline-first, no cloud.


v8.3 — Splash screen auto-continues after 10 seconds; removed the “Tap to continue / اضغط للمتابعة” hint and disabled tap-to-skip.
