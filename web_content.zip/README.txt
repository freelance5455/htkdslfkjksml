FIRE SAFETY INSPECTOR - READY TO UPLOAD

This ZIP is prepared for an HTML-to-APK online builder.

IMPORTANT:
- index.html is at the ROOT of this ZIP.
- Upload this ZIP as an HTML/website project.
- App name: Fire Safety Inspector
- The app stores inspection data locally on the device/browser using localStorage.
- The included PWA manifest and service worker provide install/offline support where supported.

Suggested APK builder settings:
App name: Fire Safety Inspector
Orientation: Portrait
Package name (if requested): com.firesafety.inspector

Do not upload the earlier Android/Gradle project ZIP to an HTML-to-APK builder. Use this ZIP instead.
