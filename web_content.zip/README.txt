خطوات بناء APK (على حاسوب):
1) ثبّت Node.js و Android Studio
2) داخل هذا المجلد نفّذ:
   npm install
   npx cap add android
   npx cap sync
   npx cap open android
3) في Android Studio: Build > Build APK(s)
   الملف الناتج: android/app/build/outputs/apk/debug/app-debug.apk
