하루 가계부+ v3
ZIP 루트에 index.html과 web/index.html이 포함되어 있습니다.
APK 제작기에서 ZIP 파일로 업로드하세요.
월 실수령액은 설정(톱니바퀴)에서 입력합니다.
