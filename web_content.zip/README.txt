TechYolo Lite with Log Out. Use index.html as the entry file. Logout is a demo button; real accounts require a backend.
