NOTE TACTICAL HUD v2 - paket HTML untuk layanan web-to-APK

Upload ZIP ini ke layanan yang mendukung ZIP HTML/CSS/JS -> APK (contoh: apkmaker.dev).

Fitur: tulis/simpan/edit/hapus/cari note, import TXT, export satu/semua TXT,
layout panel bisa digeser dan diubah ukurannya (tombol ATUR LAYOUT).
Data tersimpan di penyimpanan lokal WebView (hapus data aplikasi = note hilang).

Import/ekspor TXT:
- IMPORT TXT memakai pemilih file bawaan Android. Sebagian layanan APK tidak
  mengaktifkan pemilih file; aktifkan izin file/upload di pengaturannya jika ada.
- Jika tetap gagal, pakai PASTE / COPY TXT: tempel isi file .txt lalu simpan
  sebagai note, atau ambil isi note lalu salin ke aplikasi lain.
