BOLEMO WORLD — FIXED PROJECT

FIX: The Games tile used lowercase "games" but the page logic expected "Games". This version fixes that, so tapping Games shows the Play 3D button.

Contents:
- index.html: Homepage, Games/Catalog/Inventory/Club/Profile/Messages, gray block avatar 3D world, mobile joystick/jump, collision, chat.
- server.js: HTTP server and WebSocket multiplayer relay.
- package.json: Node dependency.

TEST:
1. Extract the ZIP on your phone.
2. Open index.html in Chrome with internet access.
3. Tap Games, then Play 3D.

MAKE AN APK ON YOUR PHONE:
1. In Google Play, search for "HTML to APK Builder - ZIP APK" (SaifTech) or another reputable HTML-to-APK builder.
2. Choose ZIP website/project and select this ZIP.
3. App name: Bolemo World
4. Package name: com.bolemo.world
5. Build a signed APK, download it, then tap the APK to install.
6. Only install APKs from a builder you trust.

ONLINE MULTIPLAYER:
Host this project on a Node.js server. Run npm install then npm start. The server uses PORT (default 8080) for the site and WebSocket relay. Use HTTPS/WSS for public hosting.

LIMITATIONS:
- Three.js is loaded from a CDN, so the 3D game needs internet.
- Sign-in, real purchases, Robux transactions, persistent inventory, and moderation are not implemented; Club is a demo page.
- The multiplayer relay is a prototype, not a production game backend.
