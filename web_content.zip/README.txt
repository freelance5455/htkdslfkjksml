SHIVAM YADAV — PERSONAL CREATOR WEBSITE

Files:
- index.html: Complete responsive one-page website.

How to preview:
1. Extract the ZIP file.
2. Open index.html in a web browser (Chrome works).
3. To publish publicly, upload index.html to a static hosting service or connect a domain.

Before publishing:
- Add your own profile photo if you want one; currently the avatar uses the initials "SY".
- Check that the Instagram and YouTube links are correct.
- The canonical URL is intentionally commented out. After publishing, add your real public URL to the canonical tag.
- This package does not publish the website automatically and does not guarantee Google indexing or a Knowledge Panel.

SEO included:
- Hindi page language, responsive/mobile layout, title, meta description, Open Graph metadata, Person JSON-LD structured data, descriptive headings, and crawl-friendly HTML.
