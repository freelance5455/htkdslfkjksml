SAYDAZIMBEK AI — KUNDALIK PLUS

Fayllar:
- index.html — sayt interfeysi va tugmalar
- database.json — savol-javoblar bazasi (taxminan 2–3 MB)
- README.txt — ushbu yo‘riqnoma

Ishga tushirish:
1. ZIP faylni oching.
2. index.html va database.json bir papkada qolsin.
3. Saytni internetga HTTPS orqali joylang yoki lokal web-server orqali oching.
4. Ovoz tugmasi uchun Chrome va mikrofon ruxsati kerak. Ayrim brauzerlarda ovoz tanish ishlamasligi mumkin.
5. Ob-havo uchun internet va joylashuv ruxsati kerak.

Eslatma:
Bu katta generativ AI modeli emas. Javoblarni lokal bazadan qidiradi va shu sababli har qanday savolga javob bera olmaydi. Ma’lumotlar bazasi o‘quv va kundalik maqsadlar uchun mo‘ljallangan; muhim ma’lumotlarni ishonchli manbadan tekshiring.
