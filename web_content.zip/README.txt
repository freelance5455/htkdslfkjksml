MOBILE VERSION

This is a mobile-friendly Progressive Web App (PWA).
Open index.html through a web server on your phone/browser. On supported browsers,
use Add to Home Screen to make it behave like an app.

The photo camera/gallery interface works on mobile.
The AI explanation needs the /explain backend from the original project.
For production, host both the PWA and backend over HTTPS.

For a true APK, this PWA can later be wrapped with Capacitor or rebuilt with Expo/EAS.
