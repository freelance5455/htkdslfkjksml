PEMBUKUAN KAS - SEBLAK STORY
Cara memakai:
1. Buka index.html dengan Chrome/Edge.
2. Data tersimpan otomatis di browser perangkat.
3. Gunakan menu Transaksi untuk mencatat uang masuk/keluar.
4. Menu Laporan untuk periode dan export CSV.
5. Menu Data untuk backup/restore JSON.

Catatan: versi ini menggunakan localStorage (tanpa server/database online).
