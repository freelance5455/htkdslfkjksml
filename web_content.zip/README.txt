Kazakh-English Quiz
Open index.html in any browser (no internet needed).
Levels: A1, A2, B1, B2.
