ZgamesStaff HTML/Web App

Files:
- index.html
- style.css
- app.js

Features:
- First launch Create Admin
- Default initial admin password: 6342 @
- Store name + admin name
- Multiple staff with unique 4-digit IDs
- Staff ID toggles check-in/check-out
- Admin login from ⋮ menu
- Admin panel, history, CSV export
- Backup/Restore using browser file download/upload
- Reset Admin Password
- About: This app is created by Abdul Raheem / Oman

Important:
This is a browser-based HTML app. Browser storage is local to the browser/device.
For an APK, use an HTML-to-APK wrapper that supports localStorage and file downloads/uploads.
