THE HOLLOW ESTATE — VERSION 2.0
=================================

A standalone browser-based survival horror game, built with HTML, CSS and JavaScript.
No external libraries or network connection are required.

VERSION 2.0 UPDATES
-------------------
- Refined main menu with graphics-quality and difficulty settings.
- High Detail, Balanced and Performance rendering presets for different devices.
- Story, Survival and Nightmare enemy difficulty presets.
- Stamina meter: sprinting drains stamina and resting restores it.
- Threat indicator showing low, nearby, searching or critical enemy status.
- Enhanced atmospheric horizon haze and responsive rendering resolution.
- Runtime error overlay to display JavaScript failures instead of silently failing.
- Android touch controls, minimap, flashlight battery, hiding, collectible sigils,
  notes, fuse, generator, doors, and escape objective retained.

HOW TO RUN ON ANDROID
---------------------
1. Download and extract the ZIP.
2. Open index.html in Chrome or in Spck Editor's preview.
3. Rotate to landscape for the best view.
4. Select a graphics preset and difficulty, then tap Enter the Estate.
5. Drag/swipe on the game view to look around. Use the on-screen directional controls
   to move, Sprint to run, Lamp to toggle the flashlight, and Action to interact.

DESKTOP CONTROLS
----------------
WASD / arrow keys: move
Mouse: look around (click the game to lock pointer)
Shift: sprint
E: interact
F: flashlight
Esc: pause

TROUBLESHOOTING
---------------
If a browser error occurs, the in-game error panel should show the message.
Try Balanced or Performance quality on slower phones. If a problem remains, send
a screenshot of the error panel so the exact runtime issue can be diagnosed.

TECHNICAL NOTE
--------------
This is a pseudo-3D raycasting browser game, not a native APK or a full polygonal
3D engine. Visual quality depends on browser and device performance.
