Gardes Polyclinique Hacine - version hors ligne
=================================================

Le fichier index.html fonctionne sans Internet et ne charge aucune bibliothèque externe.

Pour l'utiliser :
1. Décompressez le ZIP.
2. Ouvrez index.html dans un navigateur.
3. Pour l'intégrer dans une application Android WebView, utilisez index.html comme page locale.
4. Le bouton Exporter vers Excel produit un fichier CSV compatible avec Excel.

Important : cette version ne contient pas encore d'OCR automatique de la photo.
