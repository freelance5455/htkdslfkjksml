ONWORK ACADEMY — PROTÓTIPO CLIENTE E PRÉVIA ADMINISTRATIVA

Como abrir:
- Abra index.html num navegador moderno (Chrome recomendado).
- Para testar, vá a Inscrever-me e envie um pedido.
- A prévia Administração mostra apenas os pedidos guardados no mesmo navegador/dispositivo.
- O botão Exportar CSV descarrega os pedidos de demonstração.

IMPORTANTE — ESTADO TÉCNICO
Este pacote NÃO é um APK Android compilado e NÃO tem servidor/base de dados remoto.
O formulário grava localmente no navegador. Por isso, neste estado, o administrador não consegue ver os pedidos feitos noutros dispositivos.

Para produção, integrar:
1. Backend/API HTTPS e base de dados central (ex.: Supabase/Firebase ou backend próprio).
2. Autenticação segura de administradores e permissões por função.
3. Envio das inscrições para o backend e painel admin protegido.
4. Política de privacidade, consentimento e rotina de cópias de segurança.
5. Compilar APK Android usando Android Studio/Capacitor ou projeto Android nativo e testar num aparelho.

Não colocar chaves privadas no HTML. Não usar dados reais sensíveis neste protótipo.
Contacto WhatsApp: +244 972 255 427
Identidade visual: branco, azul e pequenos detalhes dourados.


ACESSO OCULTO À PRÉVIA ADMINISTRATIVA
Para abrir a prévia administrativa, toque 5 vezes seguidas no logótipo/nome ONWORK ACADEMY no topo e introduza o código 2026.
IMPORTANTE: este código é apenas uma ocultação de demonstração no navegador, não é segurança real. Não use para guardar dados confidenciais. Os pedidos continuam guardados apenas no dispositivo até integrar um servidor/base de dados.

APK ANDROID
Este ZIP contém uma aplicação web/PWA, não um APK. Para gerar APK é necessário empacotar/compilar com um serviço ou ambiente Android.
