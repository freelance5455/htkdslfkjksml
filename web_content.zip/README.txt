NEXO 1.0 — primeira versão funcional offline-first

Esta versão é uma aplicação web instalável (PWA), com:
- tela inicial seguindo a referência enviada;
- navegação entre Início, Buscar, Chat IA e Perfil;
- categorias e Montar minha solução;
- armazenamento local;
- funcionamento sem internet para os recursos locais;
- detecção de online/offline;
- cache para reabrir a aplicação sem conexão.

Para virar um APK Android nativo/Play Store, o mesmo código pode ser empacotado em um projeto Android.
