Shop Hisab PWA V5 - IndexedDB migration
Important:
1. Export a backup from your current app before updating.
2. Upload all files from this folder to the SAME existing Worker/project and SAME URL.
3. On first open, V5 copies shopHisabV1 from localStorage to IndexedDB if the new IndexedDB database is empty.
4. It intentionally keeps the old localStorage record as a recovery copy.
5. Test counts, customer balances, payments, stock and backup/restore before real use.
6. This is still browser-local storage, not yet a native Android private database and not cloud sync.
