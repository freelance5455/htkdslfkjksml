A2Z SERVICE APP – PROFESSIONAL VERSION

मुख्य सुधार:
1. WhatsApp sharing fixed using api.whatsapp.com.
2. 10 digit Indian mobile number automatically +91 format मध्ये जातो.
3. Desktop वर WhatsApp Web/browser आणि mobile वर WhatsApp उघडण्यास support.
4. SMS आणि native Share.
5. Professional dark blue dashboard UI.
6. Munna Computer logo app आणि receipt मध्ये.
7. Other / Manual Service.
8. Service price, अर्ज क्रमांक, Enrollment Number.
9. Receipt, Search, Edit, Delete, CSV.
10. Responsive mobile layout.

वापर:
- ZIP extract करा आणि index.html उघडा.
- Settings मध्ये दुकानाची माहिती भरा.
- Services मध्ये service/price सेट करा.
- नोंद तयार करा.
- Records मध्ये WhatsApp वर क्लिक करा.

WhatsApp:
- Mobile number 10 digits असणे आवश्यक.
- उदाहरण: 9579969702
- WhatsApp app/browser मध्ये internet आणि WhatsApp login आवश्यक असू शकतो.
