LAHOOTI DIGITALS & DOCUMENT SERVICE - APP
==============================================

Included:
- Mobile responsive digital business app
- Home page
- 5 services: Graphic Designing, Web Development, App Development, Document Maker, Sheets Maker
- Employee assignment: Sabir Hussain, Shan Ali, Ali Rehman
- Customer order form
- EasyPaisa payment section (manual transaction ID)
- Tando Bago City location
- Custom SVG logo
- WhatsApp order handoff
- LocalStorage saves last submitted order
- PWA manifest

IMPORTANT SETUP:
1. Open index.html in a browser.
2. In index.html search for:
   "EasyPaisa Number: Add Your Business Number"
   Replace it with your real EasyPaisa business/merchant number.
3. In the JavaScript search for:
   "https://wa.me/?text="
   For automatic WhatsApp destination, change it to:
   https://wa.me/92XXXXXXXXXX?text=
   (Use your own WhatsApp number in international format, without + or spaces.)
4. Automatic EasyPaisa payment verification is NOT included because it requires an approved merchant/API integration and credentials.
5. To publish online, upload the whole folder to a web host. For Android APK, this web app can later be wrapped into an APK.

The app is a front-end starter. A server/database/admin panel can be added in the next version for:
- Order IDs and statuses
- Customer accounts
- File uploads
- Admin dashboard
- Automatic invoices/receipts
- Real EasyPaisa merchant integration
