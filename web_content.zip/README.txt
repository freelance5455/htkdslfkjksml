Harvest Haven HTML-to-APK import

Open/import this ZIP in your HTML-to-APK app. The main page is index.html at the ZIP root.

Note: This archive uses the latest Harvest Haven HTML file currently available in the saved Library (Harvest_Haven_Menu_Character_Actions_Fixed7.html). It may be older than the current working baseline. The game references Three.js from jsDelivr, so the app may need internet access unless that dependency is bundled locally.
