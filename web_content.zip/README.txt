My First Home Philippines - v1.2 room layout
Workstation on left, bed on right, kitchen far right. Kris enlarged, sleep pose placed over bed.
Open index.html with css, js and assets folders intact. Existing localStorage key kris-home-v2 preserved.
