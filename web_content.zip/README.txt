Contractor Pro V10.0 — Global Commercial Foundation

V10 builds on the V9 Commercial Core with a stronger local commercial workspace model: workspace identity, role-based permissions, session/security settings, safer state normalization, and preserved migration data.

Important: V10 is still a development release. Authentication, cloud sync, server-side permissions, subscription billing/entitlement, online Client Portal, push notifications and production backend are NOT claimed as live services. They require a deployed secure backend.

APK packaging is intentionally separate from the development source. The production Android package should be built only after backend/security/compliance testing.
