Balance v1.1 — Offline personal finance tracker
=================================================

Files
- index.html: the complete app (HTML, CSS and JavaScript bundled into one file).

Quick start
1. Extract Balance.zip.
2. Open index.html in a modern browser to test.
3. To convert it into an Android APK with your HTML-to-APK builder, import the ZIP or use index.html as that builder expects.
4. On first launch, enter the opening balance for your first account.

Included in this first build
- Offline local storage (data stays in this app/browser storage on this device).
- Arabic and English interface; RTL/LTR layout.
- Light and dark themes.
- Multiple accounts and transfers.
- Income/expense recording, categories, notes, person/place fields.
- Budgets, savings goals, searchable transactions, reports, dashboard customization.
- JSON backup/restore, CSV export, recycle bin (30-day cleanup when the app is opened).
- Recurring rules can be saved and manually recorded when due.

Important limitations
- This is a first functional web-app build, not a native Android app yet.
- Native Android fingerprint authentication and Android home-screen widgets are not implemented.
- The optional PIN is an in-app UI barrier only; it is not strong encryption. Do not treat it as protection against someone who can access the app's local files.
- Because it runs offline as HTML, scheduled entries and reminders do not run in the background while the app is closed. Recurring rules are saved and can be manually recorded.
- Local app/browser data can be lost if app data is cleared or the converter isolates storage differently. Export backups regularly and test restore before entering important financial records.
- Do not use this app as a bank ledger without independently checking totals; verify calculations after converting to APK.


Changes in v1.1
- Fixed: transfers between accounts (amount field was missing).
- Added: delete button on transactions (moves to recycle bin); delete button for accounts.
- Fixed: PIN lock now actually appears on launch (and after 30s in background).
- Fixed: dates use the device's local time (no more previous-day entries after midnight).
- Fixed: recurring rule "record" in the manager no longer creates the entry twice.
- "Set aside" now means savings goals only; budget totals no longer mix overall and category budgets.
- "Balance trend" chart now shows real balance and follows the selected report period.
- Hide-balances button works without a PIN.
- Warning when an expense/transfer would make an account negative.
- Editing a transaction keeps its category split.
- Recurring rules show categories matching the chosen type.
- Backup reminder on Home (never backed up, or older than 7 days); storage-failure warning.
- CSV export handles transfers properly; safer backup import.

Visual updates in v1.1
- Signs (+/-) on amounts now sit in the right place in Arabic.
- Quick-add buttons: tinted icons, smaller labels.
- Bottom nav: shorter "Savings" label so it stays on one line.
- Page scrolls to top after saving a new transaction from Home.
- Reports: donut chart + percentages and colours per category.
- Toggle switch style, Arabic labels for theme (Light/Dark), soft page/modal animations,
  modal grab-handle, safe-area padding for phones with a notch.
