AM GROUP CIVIL DESIGNER - WEBSITE FILES
========================================
1. 'index.html' ko double click karke kisi bhi browser (Google Chrome, Edge) me open karein.
2. Ise internet par free live karne ke liye https://tiiny.host ya https://app.netlify.com/drop par upload karein.
