APNA HISAAB — Android ZIP project
=================================
Files:
- index.html: complete mobile-friendly inventory app.

Features:
- Hindi/English switch and light/dark theme
- Add/edit/delete products and custom categories
- Big/small unit conversion; big-unit options appear in a compact bordered two-row scrollable selection list below the field; select an option or type a custom unit name; suggestions include box, bundle, carton, bag/sack, dozen, pack, roll, drum, bottle, crate, tray and packet; custom units can also be typed
- Bounded, independently scrollable stock list with touch momentum scrolling and reduced-motion support
- Increase/reduce stock, with validation against negative stock
- Green available / red out-of-stock status
- Monthly incoming/outgoing history
- Local storage for offline use
- NEW: Export all data to a JSON backup file and import/restore that backup later

Backup:
1. Tap the download arrow (⇩) in the top-right corner.
2. Tap "Download backup file".
3. Your phone/browser will save a file named like Apna_Hisaab_Backup_YYYY-MM-DD.json. Usually it appears in Downloads; depending on Android/browser, you may be asked where to save it.
4. To restore, tap the arrow again, choose the saved JSON file, then Import. Import replaces current data, so export a backup of current data first.

How to build:
1. Zip the CONTENTS of this folder so index.html is at the root of the ZIP.
2. Upload that ZIP to your APK builder. Set the app name to "अपना हिसाब" (or "Apna Hisaab").
3. Ensure the builder bundles the HTML locally and enables JavaScript in its Android WebView.

Important:
- Data is stored locally in the app's web storage. Clearing app/browser data or uninstalling the APK may erase it. Use the new backup feature regularly.
- Backup is a portable JSON file; keep it in Downloads, Documents, or another safe folder.
- Test with sample products before relying on it for shop inventory.
