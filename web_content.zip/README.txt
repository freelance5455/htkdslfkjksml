Caption Ghor - original file

This package contains the original HTML file supplied for the app.
The HTML file has been copied without changing its contents.
