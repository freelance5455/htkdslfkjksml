Max Call — yangilangan prototip manbasi

Ushbu paketda APK ichidan olingan WebView sahifasining yangilangan HTML manbasi bor.

Hozir qo‘shilganlar:
- telefon raqami kiritish maydoni;
- Android telefon ilovasini tel: havolasi orqali ochishga urinish;
- kontakt qo‘shishning vaqtinchalik, shu seanslik ko‘rinishi;
- internet audio/video qo‘ng‘irog‘i uchun xizmat hali ulanmaganini ochiq ko‘rsatish.

Muhim:
- Bu ZIP tayyor APK emas.
- Asl APK ichidagi HTML faylni almashtirish va APKni qayta imzolash uchun Android loyihasi/build muhiti kerak.
- SIM qo‘ng‘irog‘i WebView/Android ilovasi tel: havolasini tashqi telefon ilovasiga uzatsa ishlaydi.
- Haqiqiy internet audio/video qo‘ng‘irog‘i uchun ZEGOCLOUD App ID/project configuration va serverda yaratiladigan tokenlar kerak. Maxfiy server kalitlarini ilova ichiga yozmang.


Yangilanish: telefon terish qismida O‘zbekiston (+998) davlat kodi ko‘rsatiladi. Mahalliy raqamni 90 123 45 67 ko‘rinishida kiritsangiz, +998 avtomatik qo‘shiladi. Agar to‘liq xalqaro raqam (+998...) kiritilsa, kod takrorlanmaydi. Bu hali APK emas, loyiha manba fayllari ZIP arxividir.


YANGILANISH: Raqam terish qismiga davlat telefon kodi tanlash ro‘yxati qo‘shildi. O‘zbekiston (+998) boshlang‘ich tanlov. Bu ZIP loyiha manba fayllari, o‘rnatiladigan APK emas.


YANGI FUNKSIYA: Davlat tanlanganda shu davlatning telefon kodi raqam maydonida avtomatik ko‘rinadi va davlat o‘zgartirilganda yangilanadi. Isroil (+972) ro‘yxatda yo‘q. Bu ZIP loyiha manbasi, APK emas.
