Study Buddy 4 - offline HTML prototype.
Features: class 1-8 selector, subject/topic notes, quiz modes up to 100,
XP, streak, progress, homework, timetable and dark mode.
Content is original and does not copy NCERT textbook passages.
The curriculum structure is a starter NCERT/CBSE-aligned design, not a claim
to be the complete current official syllabus.
