POCKET FOOTBALL CHALLENGE - SOURCE PROJECT
==========================================

This ZIP contains the full source of the game. It is NOT an APK yet.
You need to convert it with an HTML-to-APK tool (steps below).

FILES
-----
index.html  - the complete game (HTML5, CSS3, JavaScript, no libraries,
              no images, no fonts, no internet needed)
README.txt  - this file


HOW TO PLAY
-----------
1. Tap Play.
2. Tap anywhere on the goal to place the aiming mark.
   - Aim inside the posts to score.
   - Aim outside the posts or over the bar and the shot is a MISS.
   - Shots are never perfectly accurate, so corners are risky.
3. Press SHOOT to kick.
4. The goalkeeper dives. You see GOAL, SAVED or MISS after each kick.
5. You take 5 shots. Your goals are your score.
6. Your best score is saved on the phone (localStorage).

Buttons: Sound on/off (bottom left), Restart (bottom right).
After shot 5, the Game Over screen shows your final score and
a Play Again button.


TRY IT FIRST (OPTIONAL)
-----------------------
Unzip the file, then open index.html in Chrome on your phone.
(Files app -> index.html -> Open with Chrome.)


HOW TO MAKE THE APK ON AN ANDROID PHONE
---------------------------------------
Use any online "HTML to APK" or "ZIP/HTML5 to APK" converter in
your phone browser. Tool names and screens change over time, so
the exact buttons may differ, but the steps are almost always:

1. Open the converter website in Chrome.
2. Choose the option that lets you upload a ZIP / HTML5 project
   (not "website URL").
3. Upload Pocket_Football_Challenge_Source.zip
   (index.html is already at the root of the ZIP, as most
   converters require).
4. Enter these app details:
     App name     : Pocket Football Challenge
     Package name : com.pocketfootball.challenge
     Orientation  : Portrait
     Fullscreen   : ON (if offered)
5. Optionally add an app icon (any square PNG, 512 x 512).
6. Build, then download the APK file.
7. Open the downloaded APK to install it.
   If Android blocks it, allow "Install unknown apps" for the
   app you used to open it (Chrome or Files), then try again.

Tips:
- If the converter asks for a "start page" or "entry file",
  type: index.html
- If the sound seems off, tap Sound on/off once. Android only
  allows sound after the first tap.
- Use only converters you trust, and read their permission
  requests. This game needs no permissions at all.


TECHNICAL NOTES
---------------
- Orientation is portrait. The layout scales to any phone screen.
- All graphics are drawn in code (Canvas + CSS + SVG).
- Sounds are generated in code (Web Audio).
- Best score and sound setting use localStorage.
