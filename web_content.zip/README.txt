OG Pizza Town Billing App — WhatsApp share patch

Changed:
- Replaced the bill-sharing button label with “WhatsApp पर भेजें”.
- Tapping it opens WhatsApp (or WhatsApp Web where applicable) with the current bill text pre-filled.

Important:
This ZIP contains the modified web asset only. It is NOT a rebuilt/installable APK.
The supplied APK is a compiled Android package; rebuilding/signing it requires the original Android project/build setup.
Replace:
assets/web/ProBill_Cafe_3in1/index.html
with the included index.html in the original project, then rebuild and sign the APK.
