Spesen und Arbeitszeiten – v3
Basis: der vom Nutzer gelieferte leere Originalbogen 1084x1536.
Die Eingabefelder sind an den tatsächlichen Zellgrenzen des Bogens ausgerichtet.
Arbeitslogik:
- von = Startzeit manuell
- bis = von + Netto Fahrzeit + 2:00 (Arbeitszeit + 1:00 Pause)
- Zeit = 24
- Spesen Mo/Fr 14, Di/Mi/Do 28, Wochenende —
- Start/Stop = PLZ; Stop manuell, nächster Arbeitstag Start übernimmt den letzten Arbeitstag-Stop
- zweites von = Startzeit
- Pause = 1:00
- zweites bis = Ende
- Netto Arb.Zeit = Netto Fahrzeit + 1:00
- Netto Fahrzeit manuell
