MORROW — RESTORED OFFLINE-FIRST SOURCE
This package restores the main dashboard progress circle and activity overview, keeps the original core sections,
and changes only the Journal notebook shade selection. Notebook shades are fixed and independent of the app theme:
Clean White, Sky Blue, Soft Red, Sage Green, Heavenly Pink.

IMPORTANT ABOUT THE ERROR IN YOUR SCREENSHOT
The address appassets.androidplatform.net/web/index.html is an Android WebView local-page address.
That error means the WebView did not find/serve its packaged web page. This package's Android app is a native
Flutter app and does not load a website in a WebView, so it avoids that specific appassets web-page failure.
It stores tasks, notebooks, entries, quotes and lists on the device and does not require internet to open or use.
No internet-based fonts, scripts, images, login, or cloud calls are required at runtime.

NO SPLASH ANIMATION
The launch animation has been removed. The app opens directly to the dashboard.

BUILD THE ANDROID APP (Windows)
1. Install Flutter SDK and Android Studio.
2. Extract this ZIP and open a terminal in the extracted folder.
3. Run: flutter create . --platforms=android,windows
4. Run: flutter pub get
5. Run: flutter build apk --release
APK: build/app/outputs/flutter-apk/app-release.apk

WEBSITE
Open website/index.html directly in a browser. The website is standalone and has no remote runtime dependencies.

LIMITATIONS / HONEST NOTE
This is source code, not a compiled APK. It has not been built or tested on your phone here, so I cannot promise
the error is permanently gone until the generated APK is installed and tested on your device. The native Flutter
app is designed to work offline after it has been built and installed. Phone/laptop cloud sync is not included.
