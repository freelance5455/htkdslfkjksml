JARVIS - Android APK için web projesi

1) index.html dosyasını APK oluşturucuya yükleyin.
2) Uygulama adı: JARVIS
3) Paket adı örneği: com.kenan.jarvis
4) APK'yı oluşturup telefona kurun.
5) Uygulamayı açınca OpenAI API anahtarınızı girin.
6) Mikrofon butonuna basıp Türkçe konuşun.

Not: Bu kişisel kullanım prototipidir. API anahtarı APK içine gömülmez; cihazın yerel tarayıcı depolamasında tutulur. Anahtarı kimseyle paylaşmayın.
