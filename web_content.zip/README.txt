VIANA GALLERY — SINGLE-FILE HTML / WEBSITE-TO-APK PACKAGE
==========================================================

This ZIP contains one self-contained HTML app. All CSS and JavaScript are
inside index.html; no CDN, remote font, external script, or external image is
required. index.html is located at the ZIP ROOT.

App name: Viana Gallery
Suggested package ID: com.samyar.vianagallery
PIN: 24 (two digits)

Included features:
- Glass-style interface and animated light sweep over the title (2.7 seconds)
- PIN entry screen (24)
- Manually selected photos using the device file picker
- IndexedDB persistence for photos and preferences
- Photo grid, preview, favorites, search and sorting
- Album creation and moving photos between albums
- Individual photo download and download-all action
- Set a photo as app background
- Custom app and button backgrounds
- Accent color, title size, button size and grid-column settings
- Reordering the Add and Download buttons

IMPORTANT:
This is website source code, NOT an APK. Upload it to a builder that explicitly
compiles HTML/website ZIP files into a signed Android APK. Do not use a generic
ZIP-to-APK archive converter. MConverter itself explains that it cannot create
an installable APK from a ZIP that does not already contain an Android app.

Suggested builder to try:
https://www.htmltoapk.com/
Its published instructions state that it accepts a ZIP with index.html at the
archive root and builds a signed APK. Availability and free-tier limits may
change, so check the current build page before uploading.

Build metadata:
App name: Viana Gallery
Package ID: com.samyar.vianagallery
Version: 1

Limitations:
- The app is a WebView-based Android wrapper, not a native Kotlin gallery.
- The PIN is a convenience screen, not strong security or encryption.
- The app imports only images explicitly selected by the user; it does not
  automatically scan every image on the phone.
- Data lives in the WebView's IndexedDB. Clearing app data or uninstalling
  the APK may erase it. Keep independent backups of important photos.
- Download-all behavior depends on whether the APK builder configures WebView
  downloads correctly.
- This source ZIP has not been compiled, signed, or installed on your device.
  No source package can guarantee that a third-party builder or your phone
  will accept the resulting APK.
