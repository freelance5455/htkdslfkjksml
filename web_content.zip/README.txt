Shop Hisab V6 - Android WebView backup fallback

This package retains the existing IndexedDB/localStorage migration and adds a text-based JSON backup/restore fallback for Android WebView wrappers where file download/file chooser do not work.
Backup: Reports > Backup/Restore > Show backup text, then Copy backup text. If clipboard copy is unavailable, long-press selected text and Copy, then paste into Notes and save it.
Restore: paste the complete JSON backup into Backup JSON text and tap Restore from pasted text. Confirm carefully; restore replaces matching app data structure. Keep a separate copy of the JSON.
Test in a separate APK build before relying on it. Do not uninstall the old app or clear its data until the new APK has been verified.
