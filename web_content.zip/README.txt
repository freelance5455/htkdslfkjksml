NEXUS TAEKWONDO CUSTOMER APP
Standalone customer portal.
Customer logs in with Customer ID + PIN.
It reads the same localStorage database key as the new Owner/Staff app when both run in the same browser/origin.
Features: dashboard, membership card, profile/photo, bookings, manual attendance history, payments, support, change PIN.
This is a local prototype and is not a secure production database.
