ABC tRADERS V1 — Android APK prototype

Contents:
- index.html: standalone mobile-first prototype. No server is required to open it.
- ZIP this file with index.html at the ZIP root and upload to an HTML-to-APK builder.

App name: ABC tRADERS
Suggested package name: com.abctraders.privateapp
Version: 1.0

IMPORTANT LIMITATIONS:
This is a UI prototype. It supports choosing an instrument, mode, selecting/previewing screenshots, and viewing the planned rulebook. It does NOT perform AI image analysis, extract reliable prices, calculate entry/SL/TP, authenticate Engine Room edits, or connect to MT5. The scan status deliberately remains WAIT rather than inventing signals.
Do not enter MT5 passwords or sensitive credentials.
