MAYANK CNC WRITER V1
=====================

Files:
- index.html: app interface and experimental G-code generator
- manifest.json: PWA metadata
- sw.js: basic offline cache for same-origin files
- icon.svg: app icon

IMPORTANT LIMITATIONS:
1. This is a prototype and has not been tested on a physical CNC machine.
2. G-code generator uses opentype.js loaded from jsDelivr, so first-time font-to-G-code generation needs internet.
3. G-code generation supports basic ASCII/English only in this version. Hindi preview is supported, but Hindi shaping/ligatures are not yet converted correctly to G-code.
4. It traces font outlines, not single-stroke handwriting.
5. Generated G-code assumes a Z axis for pen up/down. Some plotters need servo-specific M-codes or custom firmware. Never run on a real machine until controller, coordinate origin, axis direction, travel limits, and pen control are verified.
6. Do not upload private homework or personal data to a public repository. GitHub Pages source repositories are public on the free plan.

For publishing:
- Create a public GitHub repository.
- Upload all four files to repository root.
- Open Settings > Pages; choose Deploy from a branch, branch main, folder /(root), Save.
- Wait for GitHub Pages to publish the site.
- Open the published HTTPS URL on phone.
- For app-like install, use Chrome menu > Add to Home screen / Install app if offered.
- To package as Android APK, enter the published HTTPS PWA URL into PWABuilder.com and follow its Android packaging steps. APK generation/package options may change; Google Play publishing requires a paid developer account.
