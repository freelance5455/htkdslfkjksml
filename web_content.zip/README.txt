DRVWK 2.0 — Premium Red/Green 3D-style UI
- Dark premium interface with red/green profit/loss language.
- Responsive layout, crisp vector/CSS rendering on high-resolution and 4K screens.
- No fixed 4K bitmap: UI scales to the device's actual display resolution.
- Trade calculations and data migration remain in the app.
- Export JSON backup before uninstalling/updating; WebView storage may be erased by app data reset.
- Unrealized PNL uses a manually entered mark price; no exchange connection is active.
