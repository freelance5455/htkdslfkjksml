Study Answer Helper - web ZIP project

index.html is at the ROOT of this ZIP.

This version is structured for web ZIP-to-APK converters. It provides the
study interface, but real cross-app screen reading and AI answering require
native Android screen capture plus an AI backend.
