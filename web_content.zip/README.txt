ClassCheck Separate Admin and Student Accounts — Photo + QR

Admin:
- Default demo password: AdminChange123! (stored locally in browser; prototype only)
- Create student accounts with full name, student number/username, grade, section, password, and optional photo.
- View student photos and generate student QR IDs.
- Take attendance (Present/Late/Absent), review/filter records, export CSV.

Student:
- Log in with username = student number and password assigned by admin.
- See only their own profile, picture, QR ID, and attendance history.

Use:
1. Extract ZIP and open index.html in a modern browser.
2. Admin login using the demo password.
3. Create student accounts and upload photos.
4. Give each student their username and password privately.
5. Log out and test student login.

IMPORTANT LIMITATION:
This is a school-project prototype. Accounts, passwords, photos, and records are stored in browser localStorage and are not securely protected; anyone with browser/devtools access may be able to inspect them. It does not sync across devices. QR code generation loads a library online. Do not use real student data or passwords for official use. A production version needs a secure backend, proper password hashing, role-based access controls, HTTPS, backups, and school authorization/consent for photos.
