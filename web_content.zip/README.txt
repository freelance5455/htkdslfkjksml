CRICKET SCORER BY JCL — V2 DEVELOPMENT PROTOTYPE

Files:
- index.html: mobile-friendly scoring interface with English/Punjabi UI toggle.
- overlay.html: standalone scoreboard page for later hosting / PRISM web-source use.
- firebase-config.example.js: illustrative configuration placeholder only.
- FIREBASE_PRISM_SETUP.md: production architecture and deployment plan.

Included in this prototype:
- Team/match/overs setup
- Batter run buttons (0, 1, 2, 3, 4, 6)
- Wicket, wide, no-ball, bye, leg-bye, penalty and retired-hurt actions
- Basic batter/bowler tables, run rate, innings switch, undo
- Scoreboard preview, JSON export/import
- English/Punjabi labels

Important scoring-engine limitations:
This is a development prototype, not yet suitable for official scorekeeping. The current build does not fully model every Laws of Cricket scenario. In particular, wicket type and run-out choice, completed runs on wides/no-balls, striker rotation on every extra/overthrow, bowler changes validation, maiden overs, free hits, penalty edge cases, second-innings chase result, persistence and multi-innings scorecards require more implementation and testing. Test and correct these before a tournament.

PRISM integration:
A public HTTPS overlay URL and realtime backend are required. A local HTML file or localStorage is not a reliable PRISM web source. See FIREBASE_PRISM_SETUP.md.

V3 UI UPDATE
- Broadcast scoreboard moved directly below match setup, above scoring/statistics.
- Run buttons now include 0, 1, 2, 3, 4, 5, 6 and a three-dot options button.
- Wide workflow: tap WIDE, then tap 0 for wide only or 1-6 for completed runs; the total adds 1 wide plus completed runs, no legal ball is counted, and odd completed runs swap strike in this simplified implementation.
- Validate unusual wide scenarios under the Laws of Cricket before official use.

V5 POPUP SCORING UPDATE
- WIDE, NO-BALL, BYE and LEG-BYE each open a centered popup with run choices 0–6.
- Wide/no-ball selected value is interpreted as total runs for the delivery including the mandatory 1 extra (minimum 1). Bye/leg-bye selected value is the number of bye/leg-bye runs.
- These are simplified initial rules; run-out on a wide/no-ball, completed-run distinctions, no-ball batter-run attribution and full Laws of Cricket edge cases still need validation.


V6 UPDATE: Wide, No-ball, Bye, Leg-bye and Penalty runs now open a centered 0–6 run-selection popup (Wide starts at 1 because a wide always adds at least one run). Fixed +1/+5 text was removed from those buttons. For No-ball, selected runs are added on top of the compulsory 1 no-ball extra.


V7 UPDATE: Added match setup workflow with team names, innings overs, maximum overs per bowler (recommended default is ceil(innings overs / 5), e.g. 20 overs = 4), and powerplay overs (default 6 for T20). Scoring is hidden until the match starts. Added a player roster so names can be entered as players arrive and tapped to assign as striker, non-striker, bowler, or next batter. This remains a browser prototype; validate all cricket scoring rules and player-selection flows before official use.


V8 UPDATE: Added a proper toss setup between team/overs selection and match start: choose toss winner, choose Bat first or Bowl first, and the app previews which team bats first. Starting the match automatically sets innings 1 batting team from the toss decision.
\n\nV9 UPDATE: Added a Yes/No confirmation before ending an innings or finishing the match. Selecting No cancels and leaves the current scoring state unchanged. The Undo / Restore button is more explicit; the innings transition is added to undo history so it can be restored after an accidental confirmation.\n

V10 FIXED UPDATE: Verified the actual source file. Wide popup now starts at 0. Choosing 0 adds only the compulsory 1 wide extra, with no strike rotation. Choosing 1 adds 1 wide + 1 completed run (2 total) and rotates strike. The popup values represent completed runs.


V11 UPDATE: After starting a match, setup, broadcast preview and stats panels are hidden for a cleaner scoring screen. Added ball-by-ball log grouped by over. It records runs, wides, no-balls, byes, leg-byes and wickets; Undo restores the log along with the score.


V12 UPDATE: Main scoring view shows only the current over. Full older ball history is accessible through the ••• Full history button, with delivery highlight on tap. Six legal balls automatically open a next-bowler dialog; previous bowlers can be selected or a new bowler name entered. WICKET opens a dismissal dialog with dismissed batter selection, dismissal type, optional fielder name for caught/run-out/stumped, and next batter name. This remains a prototype; wicket rules such as run-out on illegal deliveries and end-over strike rotation require full rules testing.


V13 UPDATE: Added a top ••• match menu with Scoreboard and Overs tabs. Scoreboard shows both innings' batting scorecards, bowling figures, extras, partnerships, and fall-of-wickets where recorded. Overs tab displays ball-by-ball summaries for each innings. Match setup and broadcast preview hide after starting the match. Partnership and fall-of-wicket tracking starts with this version; older prototype history cannot retroactively provide missing partnership/fall-of-wicket details.


V14 UPDATE: Start match now opens a toss-result popup (winner + bat/bowl decision) and only starts the match after confirmation. Live scoring shows striker/non-striker run-ball-4s-6s stats and current bowler overs/runs/wickets/economy, plus a swap-ends button. Retire batter requires confirmation and replacement batter name. Next-bowler dialog now lists saved bowlers, marks the last bowler as ineligible for consecutive overs, requires a bowler selection before scoring resumes, and supports entering a new bowler.


V15 UPDATE: Team/batter/bowler inputs are blank with light example placeholders (GCL, JCL, Love, Gurpreet, Aditya). Toss field removed from setup; toss popup remains after Start New Match. Pre-match screen hides scoreboard and broadcast preview until match starts. Overs selector offers 5/10/15/20/25/30/40/50 and manual custom overs. When innings reaches selected legal-ball limit, further scoring taps do not add runs; they open second-innings player setup for striker, non-striker, and bowler. Second innings starts after those three names are entered.
