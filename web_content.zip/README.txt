DG GAMES — PLAYER APP
=====================
Is zip ke andar ki saari files ek hi folder mein hain, "index.html" root mein hai.
Isliye yeh kisi bhi APK builder / hosting par seedha kaam karti hai.

Is mein: opening animation (intro.mp4), DG logo, games, login/signup, Ludo online multiplayer,
Customer Support, Rules, About. (Admin panel alag zip mein hai.)
Backend: Supabase project "Free games" (pehle se connected).

APK BANANE KE TAREEQE
---------------------
A) "Website to APK" / "HTML to APK" builder (sabse aasaan)
   Is zip ko seedha upload karo. App name: DG GAMES. Icon: icons/icon-512.png.
   Zip ko extract ya badalna nahi hai.

B) PWABuilder (pwabuilder.com)
   1. Zip ki files kisi HTTPS hosting par upload karo (Netlify Drop / InfinityFree / Cloudflare Pages).
   2. pwabuilder.com par apna link daalo -> Package for stores -> Android -> Download.

C) Android Studio / Capacitor
   npm init -y && npm i @capacitor/core @capacitor/cli @capacitor/android
   npx cap init "DG GAMES" com.dggames.app --web-dir=www
   (zip ki files "www" folder mein rakho) -> npx cap add android -> npx cap sync -> npx cap open android

ZAROORI: App ko internet chahiye (Supabase se data aata hai). Builder mein "Internet permission" ON rakho.
Opening animation par tap karne se skip ho jati hai.
