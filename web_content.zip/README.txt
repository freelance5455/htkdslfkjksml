IRON SIEGE: DAKSHIN PROTOCOL - PHONE APK PACKAGE

Upload this ZIP to an HTML/ZIP-to-APK builder from an Android phone.
The required index.html is at the ZIP root and the boss reference video is bundled.
No Android Studio, Gradle, or computer is required for this route.
