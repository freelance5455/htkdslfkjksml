FOREST COMBAT RACERS — Mobile Edition

This is a self-contained, offline HTML5 arcade game prototype with touch controls.
To turn it into an Android APK on an Android phone:
1. Open https://www.htmltoapk.com/ in Chrome.
2. Choose the ZIP upload option.
3. Upload forest_combat_racers_mobile.zip.
4. Set app name to FOREST COMBAT RACERS and choose package name com.forestcombatracers.mobile.
5. Build the APK and download/install the signed APK when the service finishes.

This ZIP is not itself an APK. The external builder performs the Android compilation.
