VAISHNAV WORLD ADMIN APK-READY WEB FILES

The web app is intentionally placed at:
web/index.html

Use this folder as the web/asset source in an Android WebView/APK wrapper that expects appassets.androidplatform.net/web/index.html.

The earlier Acode project keeps Admin under admin/index.html; this package puts it at the path expected by that wrapper.
