TechYolo latest lightweight version. Added Donation and Report features. Donation and reports are demo/local UI only; real payments and admin reports require a backend/payment provider.
