Child Health Clinic - AppForge
================================
This is a single-file offline web app designed for import into AppForge.

Entry point:
index.html

Features:
- Date first field with calendar
- Patient name
- Fee actually received
- Expense details
- Previous balance
- Current balance = Previous + fees - expenses
- Daily/monthly/all filters
- Print / Save as PDF through device/browser print dialog
- Excel-compatible CSV export
- Offline local storage
