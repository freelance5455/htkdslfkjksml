# Mouse Family Android project

This project wraps the existing Mouse Family HTML game in a full-screen Android WebView.

## Build an APK in Android Studio
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio, choose **Open** and select the extracted `MouseFamilyAndroid` folder.
4. Allow Gradle sync and install any requested Android SDK platform (API 35).
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The APK will be in `app/build/outputs/apk/debug/app-debug.apk`.

This is an Android Studio source project, not a precompiled APK. The current execution environment does not have the Android SDK/Gradle build toolchain needed to compile an APK here.
