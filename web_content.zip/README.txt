UP Board Class 12 Study App - Version 2
यह मोबाइल पर चलने वाला web-app prototype है।
इसमें Subjects, Notes, PDF section और 20 Practice Questions हैं।
इसे सीधे Play Store पर publish करने से पहले Android APK/AAB में package करना होगा।
