RUMAHKU FINANCE — APK FORGE SOURCE v0.1.4
==========================================

Versi ini memperbarui gaya visual dengan ikon emoji ala Gen Z, kartu rounded,
warna hijau segar, gradien lembut, dan tombol modern. Struktur file tetap:
index.html, manifest.json, sw.js, README.txt.

Fondasi fitur: PIN UI, dompet/saldo awal, transaksi masuk/keluar/transfer,
riwayat transaksi, penyimpanan lokal, backup JSON, dan pemulihan dengan validasi.

Catatan: ini source untuk APK Forge, bukan APK hasil kompilasi. Uji preview dan backup/restore
pada perangkat target. PIN mengunci UI tetapi tidak mengenkripsi database/file backup.
Fitur anggaran, tagihan, target tabungan, dan laporan lengkap belum ada di fondasi ini.
