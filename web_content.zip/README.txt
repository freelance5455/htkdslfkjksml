ANCIENT VIBE EVENT ORGANIZER  (v22)
===================================
v22: Forgot password page: "Reset password, keep tickets" (removes only the password; tickets and scan history stay; countdown + reset log).
v21: New look - default Royal Purple theme plus Emerald, Blue and Night themes (pick in the sidebar; remembered in this browser).
v20: Admin page: "Clear database & restart all" (full reset, optional CSV backup).
v19: Forgot password page now has Old password / New password / Confirm new password / Change Password; recovery code kept as an option underneath.
v18: Generate 1 to 5000 tickets at once (first 100 previewed on screen, all in the PDF/database). Forgot password: one-time recovery code (or erase-and-reset as a last resort).
v17: White background and blue buttons/menu highlight.
v16: Dashboard layout with a responsive sidebar (fixed on desktop, slide-out menu on tablet/phone), blue-and-gold theme, new gold/navy buttons and the new event-hall banner and background.
Renamed from "Event Ticket Generator" and restyled with an ancient parchment-and-gold look.

Pages (tabs at the top):
 1. Generator          - create tickets (auto PDF, print, CSV). Tickets and PDFs carry the app name.
 2. Tickets dashboard  - Dashboard 1: totals, events, created today / last 7 days chart,
                         tickets per event (with used count), latest tickets.
 3. Entry dashboard    - Dashboard 2: check-in ring (% in), checked-in / unused, scan counts,
                         already-used attempts, invalid scans, gate activity by hour (today),
                         entry rate by event, recent scans. Event filter. Refreshes every 5 seconds.
 4. Scanner            - one-time QR scanning (staff password; camera needs https:// or localhost).
 5. Database           - the database store: search by ticket ID, filter by event and status, CSV export.
 6. Admin              - delete tickets, clear history, backups, change password.

Existing tickets from earlier versions are kept (same browser, same address).
Records live in one browser on one device. Export CSV backups regularly.
