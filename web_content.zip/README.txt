हनोकको पुस्तक — Mobile Web-App

यो ZIP मा:
- index.html
- assets/hanok-ko-pustak.pdf (मूल 153-पेज PDF)

प्रयोग:
1. ZIP extract गर्नुहोस्।
2. index.html लाई web-app/HTML-to-APK builder मा upload गर्नुहोस्।
3. App name: हनोकको पुस्तक
4. Build APK गरेर Android मोबाइलमा install गर्नुहोस्।

नोट: PDF browser/WebView को PDF support अनुसार खुल्छ।
