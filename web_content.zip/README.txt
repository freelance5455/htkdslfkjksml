আফ্রীদি শহীদ — Mobile PWA v2

এই প্যাকেজটি Android Chrome-এ Installable PWA হিসেবে ব্যবহার করা যাবে।

ইনস্টল:
1. সব ফাইল HTTPS hosting-এ আপলোড করুন।
2. Chrome দিয়ে index.html-এর ওয়েব ঠিকানা খুলুন।
3. Chrome Menu (⋮) → Install app / Add to Home screen চাপুন।

নোট: ZIP ফাইলটি সরাসরি APK নয়। এটি PWA। আসল APK বানাতে Android WebView/Wrapper দিয়ে build করতে হবে।
