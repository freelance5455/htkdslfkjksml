MONEY PLAN 3.0 — REVISION 10 PROJECT

Contents
- index.html: current WebView-friendly prototype
- MoneyPlan3_Migration_Review.json: selected source cells from We.xlsx for careful review

Workbook scope
Included sheets: sal, personal, RD, Loans, emi, Sheet1, HL, OD, CL.
Excluded unrelated sheets: car, 11BPS, house work, DA Calc, BPS Calc, EXP, Sheet6, Sheet7, Sheet3, Sheet5.

IMPORTANT
This migration file is a source-preserving review pack, NOT an automatic import. The workbook has mixed layouts and unclear account groupings. The app's Settings > Workbook migration review can preview selected sheet cell counts without changing live app records. Do not treat it as a completed transfer.

APP STATUS
This is a browser/WebView prototype project, not a signed native Android APK. The optional PIN is a basic local gate, not secure encryption. Fingerprint unlock, encrypted cloud backup, reliable notifications, and tested Money Plan 2.1 migration are not implemented.

Safety
Keep Money Plan 2.1 and the original Excel workbook unchanged. Test this prototype separately and export backups before entering real financial records.
