PromptHub AI Prompt App Prototype

Features:
Home, search, categories, prompt details, copy, favorites, profile, add/publish prompt, image upload, video duration options, aspect ratio and style.

How to use:
Extract the ZIP and open index.html in a browser. For full PWA installation/service-worker behavior, host the folder on HTTPS.

This is a local prototype. Data is saved in the browser. A real online multi-user app needs a backend/database, authentication, cloud image/video storage and an admin system.
