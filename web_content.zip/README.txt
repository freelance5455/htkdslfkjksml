MAAN FASTag Daily Hisab

Files:
- index.html: app
- manifest.json and sw.js: PWA install support

Quick use:
1. Open index.html in a browser to use the ledger.
2. Data is stored on the same browser/device.
3. Download CSV regularly for backup.

Installable app note:
For Chrome's "Install app" option, host these files on an HTTPS website, then open that website in Chrome and choose Install app / Add to Home screen.
