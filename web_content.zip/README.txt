GEOLINIX GEO MARKET v2 — GEO TRUST prototype

Files:
- index.html: phone-friendly standalone prototype
- README.txt: this guide

How to test on Android:
1. Extract this ZIP using your file manager.
2. Open index.html with Chrome.
3. Try Shop, Cart, Sell, Orders and Trust tabs.
4. In Sell, create a sample listing and submit a demo seller-verification request.
5. In Trust, submit a sample buyer report and inspect Local test records.

IMPORTANT LIMITATIONS:
- This is a local front-end prototype. Records stay in this browser/device.
- It does not transmit verification requests or reports to GEOLINIX staff.
- No seller is actually verified by submitting the form.
- No live user accounts, server database, messaging, delivery integration, payment processing, escrow, refunds or buyer reimbursement are connected.
- Do not enter NRC/passport numbers, passwords, payment PINs, one-time codes or private documents.

Before public launch, GEOLINIX needs a secure backend, an authorised seller-review process, moderation staff, privacy notice, seller terms, refund/returns policy, complaint handling and properly approved payment/delivery partners.
