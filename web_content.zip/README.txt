HunterXEsport APK-Ready Package
================================

1. Upload index.html to an HTML-to-APK converter.
2. App name: HunterXEsport
3. Package name: com.hunterxesport.app
4. Version: 1.0.0

Pricing:
Solo: ₹10 entry / ₹7 per kill
Duo: ₹10 entry / ₹6 per kill
Squad: ₹20 entry / ₹10 per kill

IMPORTANT:
This package contains demo/local payment, wallet, login and room logic.
It does NOT process real money. For production use, add a secure backend,
verified payment gateway/webhooks, authentication, database, and server-side
result/payout verification.
