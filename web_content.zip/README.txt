REHAMAN OXYGEN FILLING POINT — Polished ZIP Prototype

Design update:
- App header changed to a light blue/white background so the blue R/S and black G in the RGS logo are visible.
- Invoice and detailed customer statement use a smaller left-aligned logo with a clean light background.
- Invoice/statement styling uses restrained light blue accents, pale blue heading areas, and readable totals.

This is an HTML prototype in a ZIP, not a compiled APK. Test on the intended Android browser/WebView before business use. Back up local browser data regularly.
