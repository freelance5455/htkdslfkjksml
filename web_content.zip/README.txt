AGENDA LASHES - VERSIONE APP
=============================

Questa cartella contiene una Progressive Web App (PWA) installabile su Android.

FUNZIONI
- Agenda settimanale
- Clienti e schede cliente
- Storico appuntamenti
- Trattamenti, durata, prezzo e stato
- Ricorrenze
- Promemoria 24/48 ore
- Notifiche del dispositivo (quando supportate)
- Messaggi WhatsApp già compilati
- Backup/importazione JSON
- PIN locale
- Funzionamento offline dopo il primo caricamento

INSTALLAZIONE ANDROID
1. Pubblica questi file su un sito HTTPS (o apri index.html in un ambiente che supporti service worker).
2. Dal browser Android scegli "Installa app" / "Aggiungi alla schermata Home".
3. L'app si aprirà a schermo intero come una normale app.

NOTA WHATSAPP
Il pulsante WhatsApp apre il messaggio già compilato. Per invii automatici in background (24/48 ore anche con app chiusa) serve un backend e WhatsApp Business Platform/API con consenso e template approvati.
