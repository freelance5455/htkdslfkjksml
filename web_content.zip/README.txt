Study Plan Nest - Android Offline Package

Entry point:
  index.html

This package contains the supplied Study Plan Nest HTML app.
It is intended for HTML/ZIP -> APK builders that support local/offline HTML.

Important:
- The supplied HTML currently references some libraries from external CDNs.
- Therefore, the app may still require Internet for those external resources unless
  the APK builder caches/bundles them or the dependencies are made local.
- The app's own localStorage-based data is part of the supplied HTML application.
