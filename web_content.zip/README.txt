Munna Computer Aambapani - HTML App
Phone: 9579969702

HOW TO USE:
1. Extract this ZIP.
2. Upload/use index.html in your HTML-to-App builder.
3. The app stores services, receipt number and receipt history in local storage on the device.
4. Add/edit your service rates inside the app.
5. WhatsApp and SMS buttons open the phone's respective app with a prefilled message.
6. Print / PDF uses the device/browser print dialog.

Note: Direct automatic SMS or WhatsApp Business API sending requires a separate SMS/WhatsApp provider and configuration. This version uses the phone's share/open flow.
