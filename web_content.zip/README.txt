SEVAL FIRE INDIA - ZIP TO APK VERSION

IMPORTANT: index.html is placed at the ROOT of this ZIP, as requested by your ZIP-to-APK converter.

HOW TO USE:
1. Select this ZIP in your ZIP-to-APK app.
2. Tap Preview.
3. If the preview works, continue with that app's APK build/export option.

This is an offline HTML game-menu prototype with Battle Arena placeholder, Training Ground, Lucky Royale (100 coins per spin), Emotes and Profile.
It is not a finished 3D multiplayer battle-royale game.
