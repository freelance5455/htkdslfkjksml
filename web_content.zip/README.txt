J.A.R.V.I.S. — HTML / CSS / JavaScript Android Web App Starter
==============================================================

CONTENTS
- index.html     Main app screen
- styles.css     Responsive futuristic interface
- app.js         Chat UI, voice input/output, local commands and settings

HOW TO USE WITH APPGEYSER
1. Extract this ZIP on a computer or phone to inspect the files.
2. In AppGeyser, choose the ZIP template shown in your screenshot.
3. Upload this ZIP file (do not upload the extracted folder).
4. Follow AppGeyser's remaining steps to create your app and APK.
5. Install the APK and test microphone permission and speech features.

If AppGeyser rejects the ZIP, check its current ZIP-template requirements. This archive is a simple website bundle with index.html at the ZIP root.

WHAT WORKS IN THIS STARTER
- Mobile-friendly JARVIS-inspired interface
- Text chat interface
- Voice input when the Android browser/WebView supports Web Speech Recognition
- Spoken replies using device text-to-speech
- Time and date commands
- Basic greetings and help
- Open Google and YouTube commands
- Saves preferred name, voice choice and speech toggle in local browser storage

TRY THESE COMMANDS
- Hello JARVIS
- What time is it?
- What is today's date?
- What can you do?
- Remember my name is Alex
- Open YouTube
- Open Google

IMPORTANT LIMITATIONS
This is Version 1: a working assistant interface and basic command engine, not yet a full conversational AI. General questions need an AI model/service connection. A production app should call that service through a secure backend; putting a secret API key in JavaScript or inside an APK exposes it.

Voice recognition support varies by browser, Android version and WebView provider. Microphone permission must be granted. Some speech services may require internet access. The app does not listen continuously in the background.

The optional Google Fonts import improves the look when internet is available; system fallback fonts are used if unavailable.

NEXT DEVELOPMENT STAGES
1. Connect a secure AI backend for natural conversations.
2. Add persistent, user-controlled memory.
3. Add Android-specific integrations for supported device actions.
4. Add wake-word / background listening only if the Android implementation and permissions support it.

Built as a plain HTML, CSS and JavaScript project. No Python or GitHub is required to edit these files.
