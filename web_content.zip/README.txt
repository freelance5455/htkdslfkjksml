Yaman Şifre Kasası - APKForge kaynak paketi

Dosyalar:
- index.html: uygulama
- logo.png: uygulama logosu

APKForge'a index.html ve logo.png dosyalarını birlikte ekleyin ve başlangıç sayfası olarak index.html seçin.

Güncelleme: Çıkış düğmesi PIN giriş ekranına döner; PIN alanı ve ekranda kalan kayıt/form verileri temizlenir. Hesap kayıtları otomatik kaydedilir ve şifreli saklanır.
