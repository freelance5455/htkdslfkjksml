JMF CIVIL BUILDING ESTIMATOR PRO - VERSION 2.0

Included:
- Project information, multi-floor built-up area and per-sq.ft budget
- Editable rates for local quotations / PWD SoR entry
- Preliminary footing, column, beam and slab concrete quantity calculator
- Indicative steel weight allowance (not a BBS or structural design)
- Brickwork and plaster quantity calculator
- Door, window and ventilator schedule
- BOQ-style summary report
- Print / Save PDF and Share
- Offline Android WebView app

BUILD APK:
1. Download and extract this ZIP on a computer.
2. Install Android Studio.
3. Open the extracted project folder in Android Studio.
4. Wait for Gradle sync and install Android SDK Platform 35 if prompted.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Find APK at app/build/outputs/apk/debug/app-debug.apk
7. Transfer APK to Android phone and install (allow install from this source if Android asks).

This is an Android Studio source project, not a precompiled APK.

IMPORTANT ENGINEERING LIMITATIONS:
- This is a preliminary quantity and budgeting tool only.
- Structural dimensions, footing sizes, reinforcement, beam/column/slab design and BBS must be taken from approved engineering drawings and checked by a qualified structural engineer.
- Steel kg/m3 is only a rough budgeting allowance.
- Sample rates are placeholders and are not official current West Bengal PWD Schedule of Rates.
- Use current applicable SoR, taxes, lead/lift, specifications, wastage and site measurements.
