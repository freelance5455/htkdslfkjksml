STEAL AN EGG — LANDSCAPE-READY WEB APK INPUT

This input includes a web manifest requesting landscape orientation and a LANDSCAPE LOCK button on the “TURN YOUR TABLET SIDEWAYS” screen. The button tries fullscreen first, then screen.orientation.lock('landscape'). It reports when the browser/builder blocks rotation.

Important: a plain HTML page cannot override the Android APK wrapper's native screen orientation. If your builder blocks the browser orientation API, use the supplied native Android project instead. That project locks landscape in both AndroidManifest.xml and MainActivity.java, including at app launch and on the button press.
