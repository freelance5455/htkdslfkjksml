JT WINDOW CLEANING — PROTOTYPE 2
Blank customer database; editable customers; Google Maps address links; customer notes; photos; job scheduling; calendar; analytics; customizable business name/color/reminder.
Data is stored locally on the device in this prototype. For production, connect a secure cloud database and real push notification service.
Serve over HTTPS to install as a PWA.
