SNR TRADER 999 - HTML website ZIP

এই ZIP-টি HTML to APK অ্যাপের "ZIP File to APK" অপশনের জন্য।
গুরুত্বপূর্ণ: index.html ফাইলটি ZIP-এর root-এ আছে।

ব্যবহার:
1. ZIP ফাইলটি extract না করে HTML to APK অ্যাপ খুলুন।
2. ZIP File to APK নির্বাচন করুন।
3. এই ZIP নির্বাচন করুন।
4. অ্যাপের নির্দেশনা অনুসারে App name / package / icon দিন এবং Build করুন।

ফিচার:
- চার্ট screenshot import
- pixel-pattern ভিত্তিক সম্ভাব্য horizontal SNR candidate line
- sensitivity control
- support/resistance candidate তালিকা

সীমাবদ্ধতা:
এটি screenshot analyzer, live Quotex integration নয়। Android screen capture permission, floating overlay,
এবং নির্ভুল market-structure analysis এই ZIP-এ নেই। Pixel pattern থেকে পাওয়া লাইনগুলো নিশ্চিত SNR নয়।
