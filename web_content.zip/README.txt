ECHOTUNE WEB-TO-APK PACKAGE

This ZIP is a self-contained HTML music-player app intended for an HTML-to-APK builder.
No API key is required. It plays audio files that the user selects from their phone.

BUILD USING A WEBSITE
1. Open https://www.htmltoapk.com/ in your phone browser.
2. Choose the HTML/ZIP upload option.
3. Upload this ZIP. It contains index.html at the ZIP root.
4. Set the app name to EchoTune and build/download the signed APK if the website offers this in its current free tier.
5. Download the APK and open it on Android. If prompted, allow installing unknown apps for the browser/file manager you used.

Important limitations:
- The player needs the user to choose audio files in the app; web-app security means it cannot scan the whole phone music library like a fully native player.
- Background playback, lock-screen controls and media notifications may be limited by the website wrapper.
- Website plans/features can change; check the builder's current terms before relying on free APK builds.
