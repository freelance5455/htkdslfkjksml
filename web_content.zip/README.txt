SHAIKH Box ERP V16 — Gesture Navigation Update

Features:
- Pull down from the top to refresh the app.
- Swipe right from the left screen edge to go back to the previous app page.
- Swipe left from the right screen edge to go forward when a forward page exists.
- Android/system Back returns to the previous app page first; at the home page, double Back within 2 seconds requests exit.
- Existing local app data is stored as before; refresh reloads the current app.

Note: Android WebView/converter wrappers can intercept edge gestures or refresh gestures. Test the generated APK on your target phone. These are app-page navigation gestures, not browser internet history.
