RUKOPIS – BETA ČTEČKA

Rozbalte ZIP a otevřete index.html v prohlížeči.
Ovládání: vyberte nástroj vlevo, poté označte text. Komentář a návrh změny otevřou editor; zvýraznění, podtržení a přeškrtnutí se provedou okamžitě. Volná poznámka se přidává klepnutím do dokumentu. Data se ukládají lokálně v prohlížeči. Export pro autora vytvoří HTML soubor s anotovaným textem a přehledem komentářů.

Projekt obsahuje offline PWA shell. Pro APK lze použít Capacitor/WebView wrapper.


V2: Poznámky se zobrazují přímo v textu jako samostatné rámečky/bubliny s barevným okrajem a štítkem „Komentář betačtenáře“ nebo „Volná poznámka“. Tím jsou vizuálně oddělené od původního rukopisu.
