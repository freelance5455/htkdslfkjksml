Click Simülatör - APK uyumlu sürüm

index.html dosyasını HTML -> APK uygulamasına yükleyin.
Bu sürüm harici CDN/JavaScript dosyalarına ihtiyaç duymaz; offline WebView içinde çalışacak şekilde hazırlanmıştır.
Para ve sevgi puanı sınırsızdır ve kaydedilir.
