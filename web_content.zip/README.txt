Afzali Inventory - HTML to APK input

Upload this ZIP to an HTML-to-APK builder that accepts ZIP projects. The main file is index.html in the archive root. This is not an APK file.
