DIGITAL MARKETING WEBSITE
==========================

Files:
- index.html  -> main website
- style.css   -> design and responsive layout
- script.js   -> mobile menu, animations and contact form

HOW TO PUBLISH
1. Replace hello@youragency.com and +351 000 000 000 in index.html with your real contact details.
2. Also replace the recipient in script.js with the email address that should receive enquiries.
3. Upload index.html, style.css and script.js to your hosting provider's public_html/www/root folder.
4. Open your domain.

CONTACT FORM
The included form uses the visitor's email app via a mailto link. For a server-side form that works without an email client, connect it to your hosting provider's form handler or a form service.

CUSTOMISATION
Search and replace the placeholder email/phone. You can also replace colours in :root inside style.css.
