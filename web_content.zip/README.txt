حكاية Final Edition
- PDF upload
- PDF text extraction via PDF.js
- Story style selection
- Voice selection including Egyptian Arabic female preference
- Browser/device speech synthesis playback
IMPORTANT: A guaranteed studio-quality Egyptian female AI voice requires an external TTS service/API and cannot be embedded as a voice file automatically in this offline PWA. The app selects an ar-EG device voice when available and falls back to another Arabic voice.
- Scanned/image-only PDFs need OCR in a future version.
