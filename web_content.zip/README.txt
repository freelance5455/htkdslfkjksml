MY TUK TUK Android Project - Updated

Open this complete Android project in Android Studio and build with:
  ./gradlew assembleDebug

The app loads its offline interface from:
  app/src/main/assets/web/index.html

A web/index and web/index.html copy is also included for web-based APK builders that expect /web/index.

Features:
- Daily hire records and hire-customer daily tracker
- Credit Hire grouped under each customer's name, with each trip date, destination, amount owed, partial/full payments and balance
- School Hire daily date/status/received-amount records
- Automatic School Hire monthly totals
- Offline local storage and JSON backup/restore

The Gradle wrapper files are included. First build requires internet access to download Gradle and Android Gradle Plugin dependencies.
