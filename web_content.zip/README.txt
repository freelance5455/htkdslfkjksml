BAHA GESTION — CODE SOURCE POUR CONVERSION ANDROID

Le fichier principal se trouve dans web/index.html.
Cette structure correspond au chemin appassets.androidplatform.net/web/index.html.

Conservez le dossier web lors de l'importation dans votre outil de conversion.
Ce ZIP contient le code source web, pas un APK compilé.
