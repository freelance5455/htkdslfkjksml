Contractor Pro V19 - Built from the user-provided source code.
This is the uploaded V19 frontend source packaged as a directly usable HTML project.
The source itself states that a real backend and PostgreSQL connection are required for production.
