Personal Tax Manager – Sri Lanka (Starter)
===========================================

This is a simple bilingual (Sinhala/English) offline-first web app package for Android.

HOW TO USE ON ANDROID
1. Extract this ZIP using Files / My Files.
2. Open index.html in Chrome.
3. Use Add Entry to record income, expenses and APIT/tax payments.
4. Use Reports to export a CSV that opens in Excel/Google Sheets, or Print > Save as PDF.
5. Use Backup to download a JSON backup. Upload that file to Google Drive using the Drive app.
6. Restore from a JSON backup when needed.

IMPORTANT LIMITATIONS
- This is a starter web app, not yet a signed/installable APK.
- It does not automatically connect to Google Drive; backup upload is manual.
- Data is stored in the browser's local storage. Do not clear browser data without a backup.
- The summary is not an official taxable-income calculation and does not submit a return to IRD.
- Confirm current filing requirements, tax rules, allowable reliefs, and income classifications with IRD or a qualified tax adviser.
- For 2025/2026 assessment year, check IRD guidance and the 30 November 2026 deadline.

The app is provided as a record-keeping aid, not legal or tax advice.
