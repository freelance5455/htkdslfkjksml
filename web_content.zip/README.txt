StudyMate - simple HSC study web app
Open index.html in a browser. Works offline after download.