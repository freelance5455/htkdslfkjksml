NEBULA - HTML TO APK FIXED
Use this ZIP in your HTML-to-APK builder.
IMPORTANT BUILDER SETTINGS:
- Local/start page: index.html
- JavaScript: ON
- Internet/network access: ON
- Allow external content/HTTPS: ON
- Portrait: optional
This version uses Firebase compat scripts instead of ES modules, which is more compatible with simple WebView builders.
