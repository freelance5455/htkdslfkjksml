PERSONAL INFO — OFFLINE LOGIN

Features:
- Admin and User login/logout.
- Each account can add/update its own personal information: name, email, phone, date of birth, address/city, occupation and notes.
- Admin can create new User accounts and view account/profile status.
- IndexedDB is the browser-local database; localStorage keeps the login session.
- Service worker caches app files for offline use after the first load.
- Responsive layout.

Demo accounts:
Admin: admin / admin123
User:  user / user123

Run:
1. Extract ZIP.
2. Open terminal/command prompt in this folder.
3. Run: python -m http.server 8000
4. Open http://localhost:8000
5. Load it once; then cached app files can work offline at the same origin/browser.

IMPORTANT:
This is a browser-only offline demo. IndexedDB is not a central server database; data stays in this browser/device and does not sync to other devices. Demo passwords are stored as plain text locally. Do not use for sensitive real-world data. Browser-side roles are not secure against a technically skilled user. Production use requires a backend such as PHP + MySQL, server-side password hashing, and access control.
