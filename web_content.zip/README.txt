HYPER KAZANÇ — UYGULAMA PAKETİ

Bu ZIP, Hyper Kazanç'ın geliştirilmiş web/PWA sürümüdür; doğrudan APK değildir.

İçerik:
- index.html: uygulama arayüzü
- manifest.webmanifest: uygulama adı ve simgesi
- sw.js: çevrimdışı önbellek
- icons/: gönderdiğin logodan hazırlanan uygulama simgeleri

Özellikler:
- Toplam, günlük ve aylık kazanç
- Kategoriye göre kayıtlar
- Kazanç ekleme, düzenleme ve silme
- Son 7 gün grafiği
- Günlük hedef ve ilerleme
- Arama ve kategori filtresi
- CSV dışa aktarma
- JSON yedekleme ve geri yükleme
- Mobil ekrana uyum ve çevrimdışı kullanım

Kullanım:
1. ZIP'i aç.
2. Dosyaları HTTPS destekleyen statik hosting alanına yükle.
3. index.html sayfasını Chrome'da aç.
4. Chrome menüsünden "Ana ekrana ekle" / "Uygulamayı yükle" seç.

Not:
Kayıtlar varsayılan olarak kullandığın cihazın tarayıcısında saklanır. Tarayıcı verilerini silersen kayıtlar kaybolabilir; düzenli yedek al.
