HoK Practice Coach website ZIP for ZIP-to-APK wrapper apps
1. Select this ZIP in the wrapper app.
2. If it asks for a start page, use index.html.
3. The app works offline after first load where wrapper supports local website assets.
4. This is a practice coach, not live screen capture, a trained AI, or automatic game control.
5. It stores logs locally in the wrapper's web storage. Export JSON/CSV to back up.
