# Recetas Pro

Proyecto frontend separado:
- index.html
- style.css
- app.js

Características:
- Más de 100 recetas distintas cargadas.
- Imágenes de comida enlazadas desde Unsplash.
- Búsqueda por nombre, categoría e ingredientes.
- Filtros por categoría.
- Detalle completo: ingredientes, cantidades, pasos, tiempo, dificultad y porciones.
- Me gusta y favoritos persistentes con localStorage.
- Comentarios locales.
- Perfil editable y avatar local.
- Crear recetas con foto local.
- Modo oscuro.
- Navegación inferior: Inicio, Me gusta, + Crear y Perfil.
- Responsive para móvil y escritorio.

Abrí index.html en un navegador moderno. Las imágenes necesitan conexión a internet.
