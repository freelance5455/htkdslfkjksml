MY UPGRADE v4 — MOBILE + PC
============================
Included:
- My_Upgrade_Logo.png
- web/index.html + logo.png: responsive PC/mobile web app
- android/: Android Studio WebView project containing the same app

PC:
Open web/index.html in Chrome/Edge. Data is stored locally in the browser.

Android:
Open the android/ folder in Android Studio, allow Gradle sync, then Run.
Build > Build APK(s) creates the APK.

The app is offline-first. The built-in AI Coach is a local rule-based coach, not a cloud ChatGPT/Gemini API.
Trading is educational/paper-trading only.
