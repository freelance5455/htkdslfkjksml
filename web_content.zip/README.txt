DIVAFIT 7 WEB APP FILES

The website files are inside the web/ folder because some Android web-app builders load appassets.androidplatform.net/web/index.html.
Upload this ZIP to your web-to-APK builder and make sure it preserves the web/ directory. If it asks for a start page, use web/index.html.

Note: this package is website content, not a precompiled APK. Cloud login needs Supabase setup in web/config.js.
