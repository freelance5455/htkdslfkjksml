AMAN MOBILE — RV.KING — Native Voice APK Project

دا نسخه د Android Native SpeechRecognizer کاروي، نو د content://download له لارې د HTML غږ ستونزه نه لري.

Voice:
- پښتو ps-AF
- که پښتو ونه پېژندل شي، fa-AF ته یو ځل fallback کوي.
- دکان غږ: موجودي، خرڅلاو، پور، راپور، ګټه، تنظیمات، نوی جنس، مال اضافه کول، د پور قسط.
- که جمله کمانډ نه وي، خاموش نه پاتې کېږي؛ څه چې اورېدلي یې ښکاره کوي او د جنس نوم لټوي.

Build:
Android Studio کې پروژه Open کړه، بیا Build > Build APK(s).
Microphone permission: RECORD_AUDIO په Manifest کې شته.
