Aqua Marine Pro v1.2
====================
Mobile-first offline web app for Aqua Marine Pure.

Open index.html in a modern browser. Data is stored locally in the browser.

v1.2 key fixes:
- Customer rate is automatically fixed in Delivery entry and cannot be manually changed there.
- Customer type: Daily or Monthly.
- Today's Fuel/Water Refill setup must be entered before Delivery unlocks; it remains editable.
- Daily setup includes date, fuel/refill amount, quantity, type and notes.
- Customers: Add New, edit, and full delete including that customer's delivery records.
- Editable delivery records: edit/delete.
- Empty bottles received field.
- Customer running balance / ledger.
- Full ledger print-to-PDF and monthly report print-to-PDF.
- Backup/restore JSON.
- WhatsApp delivery message after saving a delivery.
- Branding: Aqua Marine Pure Bottled Drinking Water 19 Litre, 0304 9513729.
