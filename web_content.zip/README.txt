ROADSTER STUNT RUSH 3D — ANDROID PROJECT

This is an Android Studio project wrapper for the supplied HTML game.
The game HTML and all five GLB files are included in app/src/main/assets.

BUILD:
1. Open this folder in Android Studio (or import it in a compatible Android IDE).
2. Allow Gradle to sync and download Android Gradle Plugin/Kotlin dependencies.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated app-debug.apk on your Android device.

NOTES:
- Internet is required because the supplied HTML loads Three.js and its loaders from public CDNs.
- Keep the models folder in assets; the HTML may request models using relative paths.
- This project is a WebView wrapper. It does not modify the original game code.
