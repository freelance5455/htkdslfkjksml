Study Sanctuary
================

Standalone local copy of the Hatchable Study Sanctuary app.

Files
- index.html
- theme.css
- app.js

How to run
1. Keep all three files in the same folder.
2. Double-click index.html, or use any simple local web server.
3. Your personal timer settings/statistics are saved in your browser's localStorage.

No backend or login is required for this standalone version.
