IQ QUEST — Android starter (PWA)
=================================
Includes:
- Bilingual Uzbek/English quiz game
- 10 questions per round, score, timer, explanations
- Best score saved on device
- App icon, manifest, offline cache service worker

IMPORTANT:
This is a working installable-web-app starter, not an APK yet.
To install as an app on Android, host these files over HTTPS, open the site in Chrome,
then use Chrome menu > Install app (or Add to Home screen).
For a signed APK/AAB, the web app must next be wrapped/built with Android tooling
(e.g. Android Studio / Bubblewrap) and tested before publishing.
