MonsterWalk Playable Prototype v2

This is the next browser/APK-builder prototype.
It adds an explorable world, touch joystick movement, a city, roads,
trees, water, visible wild beasts, rarity, elements, scanning,
catching, XP, crystals, Dex, inventory, and basic day/night visuals.

It is still a prototype: the final game will use real 3D assets,
multiple regions, full battles, evolution, weather, quests, accounts,
and 500+ original beasts.
