VAISHNAV WORLD ADMIN - FIXED BLUE BUILD

Main fixes:
- Quiz Manager now has exactly 10 question editors on one page.
- Hindi and Bengali use the same lowercase Firebase language keys as the Devotee app: hindi / bengali.
- Quiz fields match the Devotee app: question, optionA, optionB, optionC, optionD, correct.
- Publish writes Q1..Q10 under quiz/daily/{language}/{date}.
- Save Draft writes quiz/drafts/{language}/{date}.
- Quiz history supports load/edit and delete.
- Combined leaderboard viewer reads quiz/results/{date}.
- Publishing quiz also creates an in-app notification.
- Courses use day-wise YouTube URLs under courses/{id}/days.
- Weekly Challenge uses active/week/tasks schema expected by the Devotee app.
- Calendar uses title/date/details.
- Prabhupada Today uses prabhupadaToday/{date}/text/source.
- Notifications use title/text/target.
- Book Store includes title, author, language, price, URL and description.
- Yatra manager updates yatra/{bookingId}, members seat/ticket data and yatraIndex.
- No Firebase Storage is required by this build.

Important:
- Firebase Authentication must have Email/Password enabled for the Admin login.
- Realtime Database rules must allow the authenticated admin to write the required paths.
- The current Admin login is client-side Firebase Email/Password authentication; use strong credentials and proper Security Rules before production.
