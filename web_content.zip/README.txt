Flight Logbook — version Web à convertir en APK

Ce ZIP est volontairement un projet WEB avec index.html à la racine.
Il est destiné aux services "ZIP vers APK" qui demandent un index.html.

Fonctions:
- journal local (localStorage)
- recherche historique par numéro de vol + date via OpenSky
- ajout manuel
- statistiques: vols, durée, pays (si disponibles), aéroports, routes, appareils
- recherche d'itinéraire dans le journal
- aucune fonction live

Si le convertisseur demande une URL ou un nom d'application:
Nom: Flight Logbook
Orientation: portrait
Type: WebView / PWA
