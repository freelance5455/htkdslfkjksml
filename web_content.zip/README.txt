SAMI MONEY APP
================
1. Extract this ZIP file.
2. Open index.html in Chrome.
3. The app includes income, expense, balance, debt/loan records and payment tracking.
4. Data is saved in the browser on the device.

Note: This is a web app package, not an Android APK.
