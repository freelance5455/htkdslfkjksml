Nova Player - HTML Media Player
Features:
- Select and detect audio/video files from device
- Audio playback and playlist
- Video playback
- Fullscreen video button
- Previous/next controls
- Dark Red, Light, Ocean and Purple themes

How to use:
1. Extract the ZIP.
2. Open index.html in Chrome or another modern browser.
3. Tap “Detect Device Media” and select your files.
4. For APK conversion, use a trusted HTML-to-APK/WebView builder.
Note: Browsers cannot automatically scan all device storage; the user must select files using the file picker.
