Smart Agriculture AI – Bilingual prototype

1. Extract this ZIP.
2. Open index.html in a modern browser, or host the folder on an HTTPS static host.
3. Create a Gemini API key in Google AI Studio and paste it into the app's Gemini API Key field.
4. Click save for this browser session.
5. Test plant image analysis, soil image analysis, chat, and the topic guide.

Important:
- The app has not been clinically or agronomically validated. AI output is an estimate, not a lab diagnosis.
- A soil photo cannot measure pH, salinity, moisture, or NPK accurately.
- Never share your API key or publish a public app with a key embedded in client-side code. For public deployment, use a secure backend.
- Use only free-tier access if available; do not enable paid billing without a parent/guardian's approval.

Updated build: uses the Gemini 3.8 Flash model endpoint. The API key is entered in the browser and is not embedded in this ZIP. Do not publish this client-side-key version publicly; use a secure backend for public deployment.
