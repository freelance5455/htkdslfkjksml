Fahs - فحص المكونات (APK avec scanner de code-barres)

1. Installer Android Studio (developer.android.com/studio).
2. File > Open > choisir le dossier fahs-android. Attendre la synchronisation Gradle.
3. Build > Build APK(s).
4. Le fichier est dans app/build/outputs/apk/debug/app-debug.apk.
5. Copier l'APK sur le téléphone et l'installer.

Fonctionnement :
- Bouton "فتح الكاميرا للمسح" : ouvre le scanner natif (ZXing), puis remplit le produit
  depuis Open Food Facts (connexion Internet requise).
- Si le produit n'existe pas dans la base, saisir les valeurs manuellement.
- L'application demande l'autorisation de la caméra à la première utilisation.
