MoodMind - personal assistant app (bina API key ke).
index.html ko browser mein kholo, ya is zip ko HTML-to-app builder mein upload karo.
