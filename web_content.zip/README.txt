INFORMATIKA TEST — INTERNET + O'RTACHA MURAKKABLIK

Asosiy rejim:
- Internetdan Open Trivia DB ning Science: Computers (18) kategoriyasidan
  multiple-choice, MEDIUM difficulty savollar olinadi.
- Har safar 20 ta savoldan 10 tasi tasodifiy tanlanadi.
- Savollar ingliz tilidan o'zbekchaga avtomatik tarjima qilinadi.
- Savol matni bo'yicha oldingi ishlatilgan savollar eslab qolinadi.
- Javob variantlari ham har safar aralashtiriladi.

Internet ishlamasa:
- Maktab o'quvchilariga mos ichki savollar ishlaydi.

ZIP to APK uchun index.html asosiy papkada joylashgan.
