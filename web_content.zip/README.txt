Zoria OS 1.0 «Світанок» — гра-конструктор власної ОС.

Як зробити APK:
1) Найпростіше: сайти-конвертери (WebIntoApp, AppsGeyser, Website2APK) — завантаж цей zip, головний файл index.html.
2) Android Studio: поклади index.html у app/src/main/assets/ і відкрий через WebView (file:///android_asset/index.html).
3) Capacitor: npm i @capacitor/core @capacitor/cli; npx cap init; поклади index.html у папку www; npx cap add android; npx cap open android.

Проєкт ОС зберігається в localStorage застосунку автоматично.
