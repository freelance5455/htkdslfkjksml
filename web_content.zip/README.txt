QUICKQUIZ ANDROID PROJECT — READY TO BUILD

This ZIP is a complete minimal Android Studio/Gradle project wrapping the QuickQuiz web app in an Android WebView. It is source code, not a precompiled APK.

BUILD ON AN ANDROID PHONE USING GITHUB ACTIONS:
1. Sign in/create an account at https://github.com/
2. Create a repository named QuickQuizAndroid.
3. Extract this ZIP on your phone.
4. Upload all extracted files and folders to the repository root, preserving structure. Ensure .github/workflows/build-apk.yml is included. If hidden files are not shown, enable "show hidden files" in your file manager.
5. In the GitHub repository, open Actions. If prompted, enable workflows.
6. Select "Build QuickQuiz APK" and tap "Run workflow".
7. When the run completes successfully, open it and download the "QuickQuiz-debug-apk" artifact.
8. Extract the artifact ZIP to get app-debug.apk, then tap it to install.

NOTES:
- Internet is required for the first online build.
- This debug APK is intended for testing/personal use.
- The project uses Android Gradle Plugin 8.7.3 and Java 17.
- If the workflow fails, open the failed run and share the last error lines for troubleshooting.
