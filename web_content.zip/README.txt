STUDY TIME MANAGER — HTML TO APK PACKAGE
Version: 1.0.0
Edition: Free

HOW TO BUILD
1. Open your HTML to APK app.
2. Choose "ZIP File to APK".
3. Select this ZIP file.
4. Set App Name: Study Time Manager.
5. Build the APK.

IMPORTANT
- This is the first HTML/WebView prototype.
- Timer, pause/resume, daily/monthly/yearly totals, history, calendar colors,
  routine list, local storage and JSON backup/import are implemented.
- AdMob is only a placeholder. A real AdMob SDK / native Android integration,
  AdMob app ID and ad unit ID must be added before showing real ads.
- Reading usage time of other Android apps requires Android Usage Access permission
  and a native Android bridge. Pure HTML/JavaScript cannot read that information.
- Reliable scheduled notifications while the app is closed require native Android
  notification/alarm integration. Browser notifications may not work reliably in
  every HTML-to-APK converter.
- Local data is stored in WebView localStorage. Clearing app data or uninstalling
  may delete it. Use Settings > Export regularly for backup.
- For future APK updates, keep the same package/application ID and signing key.
  Do not uninstall the existing app when updating if you want to preserve local data.
