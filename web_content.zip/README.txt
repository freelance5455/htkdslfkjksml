Saleem Abbas Sohia — Family Contacts App Package

Included:
- index.html: mobile-friendly family contacts app
- manifest.webmanifest: installable web-app settings
- sw.js: basic offline cache for hosting on HTTPS

How to use:
1. Open index.html on your Android phone to test the page.
2. For an installable app-like PWA, upload these files to an HTTPS website.
3. Open that HTTPS website in Chrome on Android and choose the browser menu > Add to Home screen / Install app.

This package is not an APK file. Creating a signed APK requires packaging/building and signing it separately.
