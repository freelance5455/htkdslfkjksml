SEATED ENTERPRISE POS — CLEAN RETAIL PWA

Modules included:
Dashboard, POS / Checkout, Sales, Products, Inventory, Purchases, Customers, Suppliers, Expenses, Reports, Users, Settings & Backup.

CLEAN START
No demo products, demo sales, purchases, expenses, customers or suppliers are preloaded. The app uses a fresh browser-storage key so the old demo records will not automatically appear in this version.

OWNER LOGIN
Username: admin
Password: admin123
The password is not displayed or prefilled on the login screen. Change the initial password before operational use.

USER MANAGEMENT
The owner can create, enable, disable and delete staff accounts from Users. The owner account cannot be deleted or disabled. Available role labels: Owner, Manager, Cashier, Stock Clerk. Screen access by role: Cashier = POS, Sales (no profit figures), Customers. Stock Clerk = Products, Inventory, Purchases, Suppliers. Manager = everything except Users and Settings. Owner = everything. The owner can also reset staff passwords and change roles; every user can change their own password with the key button at the top. (Access is enforced in the browser only.)

RECEIPTS
Settings > Business profile & receipt: set business name, OWNER NAME, owner phone numbers, address, footer message and paper size (80 mm / 58 mm thermal or A4). These print on every receipt. Print from the POS after a sale, or reprint any old receipt from Sales > View / Print. Use 'Print test receipt' to check the layout.

OWNER CONTACTS
0758 485 092
0791 213 660

IMPORTANT SECURITY / STORAGE LIMITATION
This is a browser-local prototype. Business data and staff credentials are stored in local browser storage. User accounts do not synchronize between devices, and this is not secure server-side authentication. Do not use it for sensitive production financial data until server-side authentication, database storage, and permission enforcement are implemented.

PWA DEPLOYMENT
Upload the contents of this folder to an HTTPS static host. Keep index.html, manifest.webmanifest, sw.js and icons together. After deployment, open the HTTPS address in Chrome and choose Install app / Add to Home screen. The service worker caches the app shell for offline reopening after the first successful online visit.

BACKUPS
Use Settings > Download full backup regularly. Keep backup files somewhere other than the same phone/browser. Restoring replaces current local records.
