Kimitso AI — Web project

Files: index.html, styles.css, script.js

How to use:
1. Extract the ZIP file.
2. Keep the three files in the same folder.
3. Open index.html in a modern browser or import the folder into your Web-to-APK builder.

Features:
- Separate character chats and character groups
- Hashira / Slayers / Demons categories
- Light, dark and purple themes, background options
- Secret Hub at the bottom of Settings; default code: 123
- Back arrow at the top of Secret Hub

Important:
- Character responses are local demo responses, not a real connected AI model.
- Character portraits are emoji placeholders, not official character artwork.
- Manga/film information is summarized in original wording; film details that are not confirmed are marked as such.
