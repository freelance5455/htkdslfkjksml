OUTFIT STUDIO — DEPLOYMENT

STATIC TEST:
Upload index.html, style.css and app.js to Netlify, Vercel, GitHub Pages, Cloudflare Pages, etc.
The interface will load, but AI processing needs the backend.

LOCAL FULL TEST:
1. Install Node.js.
2. Open this folder in Terminal.
3. Run: npm install
4. Run: npm start
5. Open: http://localhost:3000

PRODUCTION:
Deploy the frontend and server/API together or configure /api/outfit-edit as a serverless function.
Add your authorized, policy-compliant image-editing provider inside server.js.
Never expose provider secret keys in browser JavaScript.

This package implements outfit replacement, not undressing/removing clothes.
