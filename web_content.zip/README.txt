Oh, this Yuki
index.html + assets/backgrounds, assets/sprites, assets/audio (menu.mp3 optional).
APK: pack the whole folder with an HTML-to-APK (WebView) converter, keeping assets/.
