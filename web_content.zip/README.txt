Updated as requested:
- Short column headings with small arrow marks (↕).
- Narrow Sr. No. column at the left.
- Horizontal scrolling, alternating row colours, global search and pagination.
- Uses supplied spreadsheet ID and worksheet gid=0.
- Replace hosted index.html with this file; keep manifest.json and sw.js alongside it.
- This is web-app source, not a compiled APK.
