MAX CALL — boshlang‘ich ilova prototipi

index.html — telefon ekraniga mos zamonaviy ko‘rinishdagi interfeys.

Eslatma: bu prototip hali haqiqiy ovozli/video qo‘ng‘iroqlarni bajarmaydi. Buning uchun ZEGOCLOUD/WebRTC kabi xizmat, backend, foydalanuvchi tizimi va konfiguratsiya kerak.

APK olish uchun HTML faylni Android WebView loyihasiga joylashtirish yoki WebView-to-APK vositasidan foydalanish mumkin. APKni tarqatishdan oldin imzolash talab qilinishi mumkin.
