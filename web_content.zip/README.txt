Nader Calc - built from your supplied HTML/CSS design direction.
- Open index.html for a browser preview.
- For installable PWA, host all files on HTTPS (GitHub Pages / Netlify), open in Android Chrome, then choose Install app / Add to Home screen.
- Sound starts after the first tap due to browser audio restrictions.
- Cash counter denominations: 200, 100, 50, 20, 10, 5.
