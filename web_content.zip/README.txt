# ShizNarwe Pro — AndroidIDE Project

Project ini membungkus index.html yang diberikan pengguna menjadi aplikasi Android WebView.

## Build di HP dengan AndroidIDE
1. Extract ZIP ini.
2. Buka AndroidIDE.
3. Open/Import folder `ShizNarwePro`.
4. Tunggu Gradle sync.
5. Pilih Build > Assemble Debug (atau tombol Build).
6. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

Catatan:
- `Boost HP` pada HTML asli hanya animasi/status lokal; tidak benar-benar meningkatkan performa Android.
- Statistik RAM/CPU pada HTML asli dibuat secara acak, bukan pembacaan hardware sebenarnya.
- Key yang tertanam di HTML bukan sistem lisensi aman karena dapat dilihat dari APK.
