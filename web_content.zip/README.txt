# میری دکان — Android Project

یہ Android Studio project آپ کی فراہم کردہ `index.html` کو WebView کے اندر APK کی شکل میں چلاتا ہے۔

خصوصیات:
- آف لائن HTML app
- JavaScript فعال
- localStorage / DOM storage فعال
- portrait موبائل layout
- Back button handling

APK بنانے کے لیے:
1. Android Studio کھولیں۔
2. `MeriDukan_Android_Project` فولڈر Open کریں۔
3. Gradle sync مکمل ہونے دیں۔
4. Build > Build APK(s) منتخب کریں۔
5. بننے والی APK موبائل میں install کریں۔

نوٹ: اصل HTML فائل `app/src/main/assets/index.html` میں رکھی گئی ہے۔
