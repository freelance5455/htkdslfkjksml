ZYRÉVAN Business Pro prototype
Open index.html in Chrome on Android.

Improvements:
- Clear Dashboard, Sales, Orders, Menu/New Sale, Stock, Reports sections.
- Cancel order action with confirmation.
- Cancelled orders shown separately and excluded from sales/profit.
- Sales entries for outside-app cash sales; expenses tracked separately.
- Daily/monthly reports with completed, active, cancelled counts, cancelled value excluded, sales, expenses, estimated profit, best sellers.
- CSV report export.
- Menu prices included as provided.

Limitations:
Local browser prototype only; not a native APK or live online ordering backend. Records are saved only in this browser on this device. No cloud sync, payment gateway, multi-device customer ordering or notifications. Export CSV backups. Profit is estimated and depends on entered expenses.
