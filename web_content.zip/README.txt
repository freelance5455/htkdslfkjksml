ScoreDeck v1.9 — Android/WebView Ready Package

This ZIP is the web-app payload extracted from the ScoreDeck Android project.
Use this package when an HTML/WebView-to-APK converter asks for the app's HTML/web files.

ENTRY FILE
- index.html

REQUIRED FILES
- study-ai.js
- storybook.js
- paper_images/
- papers/

IMPORTANT
- Keep the folder structure unchanged.
- index.html must remain at the ZIP root.
- Do not rename ScoreDeck to Board Boost/BoardBoost.
- The app uses localStorage for practice/session/history persistence.
- The sample-paper viewer uses the supplied WebP page images.
- The supplied PDFs are retained for Open/Print/Save PDF functionality.
- No Node.js server is required for the normal offline app UI.

For a converter that accepts a ZIP/folder, upload this package as-is.
If the converter asks for an entry/start file, select index.html.
