TECHYOLO PROFILE FIXED
APK Forge / HTML-to-APK compatible.
Includes working Edit Profile (username, bio, profile picture), Save Changes and Log Out demo.
Uses one HTML file with no external libraries or network requests.
