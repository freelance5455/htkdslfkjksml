TIGRINYA LEARNING APP
Upload index.html and the whole sounds/ folder together (keep the folder names exactly as they are).

Sounds: sounds/<folder>/<name>.mp3 (a .wav with the same name also works).
Folders: letters, numbers, colors, greetings, animal-names, family, days, body-parts, food, clothing, verbs  (all your recordings, converted to small .mp3 files)
         animals/        the animal noises you sent first (chicken, rooster, sheep, goat, horse, donkey, bird)
         animal-sounds/  OPTIONAL: your own recorded animal noises. If a file is here it is used first. Still missing: cow, dog, cat (they play only the spoken name for now).

To add or replace a sound: record it with recorder.html (it names the files correctly), then copy the file into the matching folder.
Full list of file names: SOUNDS-LIST.csv
