SKILLVERSE — PHOTO THUMBNAIL EDITION
Open index.html in a browser. Search for any course and open its dedicated page.
Includes 53 courses, one thumbnail image per course, 159 starter lessons (3 per course), English headings and Roman Urdu explanations, responsive white theme and colourful accents.
The lessons are starter content, not complete textbook-length curricula. The thumbnails are cropped from generated contact sheets; each course has its own image file.
No admin panel and no visitor upload/edit feature.
