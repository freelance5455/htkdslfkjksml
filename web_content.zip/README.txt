# MatchMind mobile demo

This is an offline HTML5 prototype intended for private device testing and packaging into an Android APK.

## Included
- English/Tamil interface toggle
- Fictional sample profiles
- Demonstration compatibility explanations (not a real AI model)
- Local interest/pass interactions
- Local profile form saved in this browser's storage
- Chat placeholder

## Important limitations
This is NOT a production matrimonial service. It has no backend, real accounts, OTP, profile verification, server-side database, real users, real AI, messaging, moderation workflow, or secure cloud storage. Do not enter sensitive personal information. Data stays in browser/app local storage and may be lost if app data is cleared.

## Packaging
The ZIP is intended for an HTML-to-APK wrapper. It is not the original Flutter source project. The APK wrapper will package this HTML app in an Android WebView.
