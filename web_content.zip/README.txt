YEK Gold Alignment - RSI + Stochastic Android PWA prototype

Conditions:
- Buy-watch alignment: RSI <= oversold AND Stochastic %K <= oversold on 15m, 1h, and 4h.
- Sell-watch alignment: RSI >= overbought AND Stochastic %K >= overbought on all 3.
Defaults: RSI 14, Stochastic %K 14, %D smoothing 3, levels 70/30.
Data API: Twelve Data time_series endpoint, needs API key. Provider's symbol/interval access and quotas vary.
Installation: deploy files to HTTPS, open in Android Chrome, menu > Install app / Add to Home screen.
This is a prototype, not a signed APK. Refresh is on demand; background monitoring is not guaranteed.
API key is stored locally in browser localStorage. Protect it.
