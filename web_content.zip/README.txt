ALPHA VEHICLE ANALYTICS — V2
==============================

Package contents
- index.html: offline web app
- README.txt: setup and testing notes

Features
- Daily vehicle totals and daily targets
- One record per date; an existing date can be updated
- Calendar-month comparison with the same month in the previous year
- 21st-to-20th period comparison with the corresponding previous-year period
- Daily comparisons, difference and percentage change
- JSON backup and restore
- Printable report for a selected date range

APKForge / Android WebView requirements
For data persistence, enable JavaScript and DOM storage (localStorage).
For file downloads, the WebView wrapper must support download handling.
For the report, the wrapper must support pop-ups and Android printing.
If these WebView features are not enabled by the APK builder, the related
functions may not work even though they work in a normal browser.

Important testing
1. Install the APK and add a test record.
2. Close and reopen the app; confirm the record remains.
3. Try downloading a JSON backup and restoring it.
4. Try creating a report and saving it as PDF.
5. Test on a copy of your data before relying on it operationally.

This package does not contain any visible password note or password instructions.
