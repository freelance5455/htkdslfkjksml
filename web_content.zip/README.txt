Child Health Clinic - Offline version
Open index.html in an Android browser. Data is stored locally in the browser/device.
For an APK, this package can be wrapped with an Android WebView/app builder.
