JEE God Mode Tracker — Android/PWA package

This is an installable Progressive Web App version of the supplied HTML tracker.

On Android: serve this folder from HTTPS (or localhost), open index.html in Chrome, then use “Add to Home screen” / “Install app”.

For a true signed APK, open this project in Android Studio and wrap the local web app in a WebView/Trusted Web Activity.
