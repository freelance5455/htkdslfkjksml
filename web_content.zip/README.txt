FANCI AI — FINAL UPDATE 1.0.0

Isi:
- index.html — frontend final, mempertahankan gaya Fanci V2
- server.js — backend Railway backward-compatible untuk POST /chat
- package.json — dependency backend
- manifest.json — metadata/permission reference untuk builder

BACKEND:
Endpoint frontend sudah dikunci ke:
https://fanci-ai-production.up.railway.app/chat

Secret:
OPENROUTER_API_KEY hanya dibaca dari process.env.OPENROUTER_API_KEY.
Jangan menaruh key di file frontend atau APK.

REQUEST:
Teks:
{"message":"...","history":[...]}

Foto:
{"message":"...","image":"data:image/...","history":[...]}

CATATAN VISION:
server.js memakai model dari OPENROUTER_MODEL jika tersedia; jika tidak, memakai "openrouter/free".
Kemampuan vision bergantung pada model yang dipilih OpenRouter. Jika model yang dipakai tidak menerima gambar, chat teks tetap kompatibel tetapi analisis foto akan ditolak oleh provider/model.

VOICE:
Speech-to-text dan text-to-speech memakai kemampuan browser/WebView. Tidak semua HTML-to-APK wrapper menyediakan SpeechRecognition atau izin microphone. Jika wrapper meminta permission, aktifkan Microphone/Camera.

RIWAYAT:
Disimpan lokal menggunakan localStorage perangkat. Menghapus data aplikasi/browser wrapper akan menghapus riwayat lokal.

PENTING:
Sebelum memakai fitur foto pada APK final, deploy server.js ini ke SERVICE RAILWAY YANG SAMA jika backend lama belum mendukung field image/history. Jangan membuat service Railway baru.
