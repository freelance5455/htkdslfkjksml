COUPLE MONEY - ZIP WEBSITE UNTUK WEB TO APK

1. Upload ZIP ini ke aplikasi ZIP ke APK.
2. Pastikan index.html berada di root arsip.
3. Aplikasi membutuhkan internet untuk sinkronisasi Google Sheets.
4. URL Google Apps Script sudah diisi pada pengaturan.
5. Setelah APK dibuat, tekan Hubungkan / Tes, lalu Ambil Data.

Catatan: Jangan mengubah atau membagikan URL Apps Script jika akses API tidak dibatasi.
