Easy Earning PWA v1
--------------------
This is a demo web/PWA version. It stores demo points locally on the device.
No real-money earning or withdrawal is included.

To package as an Android APK, upload the project to a reputable PWA-to-APK/Android wrapper service or build it with Android Studio/another supported tool.
