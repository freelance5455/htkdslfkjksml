ZgamesStaff HTML/Web App

Files:
- index.html
- style.css
- app.js

Features:
- First launch Create Admin
- Initial app login password: 6342
- Store name + admin name
- Multiple staff with unique 4-digit IDs
- Staff ID toggles check-in/check-out
- Admin login from ⋮ menu
- Admin panel, history, CSV export
- Backup/Restore using browser file download/upload
- Reset Admin Password
- About: This app is created by Abdul Raheem / Oman

Important:
This is a browser-based HTML app. Browser storage is local to the browser/device.
For an APK, use an HTML-to-APK wrapper that supports localStorage and file downloads/uploads.

Startup login: Admin password is 6342. The retype-password field has been removed.

First-time login: Admin name is chosen by the user; the first-time password is fixed at 6342. Retype password is not used.
\nAdmin Login now asks for both Admin Name and Password after logout, and reloads the saved admin configuration before checking credentials.\n