VHARANOR READER – OFFLINE APP
================================

Diese Version ist ein funktionsfähiger Offline-PWA-Prototyp für Vharanor.

Enthalten:
- Vollbild-Buchoberfläche
- Wischen nach oben/unten zum Seitenwechsel
- Kapitelübersicht
- lokaler Lesefortschritt
- Lesezeichen
- eigenes Vharanor-App-Symbol
- Manifest + Service Worker für Offlinebetrieb
- keine Anmeldung, keine Datenbank, keine Veröffentlichung nötig

WICHTIG:
Die tatsächlichen Romantexte werden erst eingesetzt, sobald die noch vorhandenen Originalkapitel vorliegen.
Die vorhandenen Texte im Prototyp sind bewusst nur Platzhalter/Zusammenfassungen und ersetzen nicht den Roman.

INSTALLATION ALS PWA:
1. Die Dateien auf eine HTTPS-Webadresse hochladen.
2. Die Adresse auf Android mit Chrome öffnen.
3. "Installieren" bzw. "Zum Startbildschirm hinzufügen" wählen.

APK:
Die PWA kann anschließend mit einem geeigneten Web/PWA-to-APK-Werkzeug verpackt werden. Für eine echte Offline-App müssen alle Buchtexte und Bilder in der App enthalten sein.
