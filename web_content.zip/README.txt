UNNATI – Original Code + Previous Page Back Buttons

IMPORTANT: The original UNNATI HTML/CSS/JavaScript is preserved exactly. Only one separate script was appended at the end to make existing Back buttons navigate to the immediately previous screen. No existing feature, design, form, text, or business logic was intentionally changed.

Expected flow: Home/Auth → Login → Register; Back from Register returns Login, and Back from Login returns the previous screen. On other screens, the existing Back/Home-labelled header button returns to the screen opened immediately before it, rather than always jumping to Home.

Rebuild your APK using this index.html in the same WebView/HTML project. Android hardware Back behavior also depends on the APK builder/WebView wrapper forwarding Back to WebView history.
