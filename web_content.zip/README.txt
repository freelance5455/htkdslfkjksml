KEA HSE FORMS - HOW TO PUT ON THE INTERNET
1. Go to https://app.netlify.com/drop (free) and drag this ZIP (or the unzipped folder) onto the page.
   Other options: GitHub Pages, Vercel, Cloudflare Pages, or your own web hosting (upload everything, keep folder structure).
2. Open the https:// link on your phone. HTTPS is required for camera access.
3. Install as app: Chrome menu > Add to Home screen (Android) or Safari Share > Add to Home Screen (iPhone).
4. Camera: tap the photo button in a form and allow Camera when asked.
5. PDF / Word: tap Print / PDF or Word, then use "Share / Save to phone" (or Download) in the green bar at the bottom.
   The first PDF needs internet once (it loads a small PDF tool).
Every form is in its own folder with index.html. The main index.html lists all forms.
Disciplinary forms: use "Upload company logo" on the left panel to add or replace the right-hand logo.
