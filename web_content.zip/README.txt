CALL TRACKER - APKForge Website ZIP

Upload this ZIP to APKForge. The archive root contains index.html.

Features:
- Dial pad only; Call button opens the phone's native dialer using tel:
- Manual completed-call entry and status selection
- Local offline storage via localStorage
- Daily and monthly summary PDF exports (no individual call details)
- Separate call details PDF (date, time, phone number, status)

Important limitations:
This is a web app packaged by APKForge, not a native Android default dialer.
It cannot automatically read Android call logs, detect call completion, or display system call-state popups.
After a call, return to the app and tap "Save Call & Select Status".
Data remains in the app's local browser storage; uninstalling/clearing app data may erase it.
