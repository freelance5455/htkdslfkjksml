आकार हिशोब वही PRO 1.0
Android Studio project.

Modules:
Dashboard, Daily Hishob, Worker Salary, Purchase/Bills, Shop Expenses,
Monthly report, Profit/Loss, Search, Backup/Restore.

डेटा WebView Local Storage मध्ये डिव्हाइसवर सेव्ह होतो.
Android Studio -> Open Project -> Sync -> Build APK(s).
