THE HOLLOW ESTATE — HAUNTED HAVELI V9

Updated in this version:
- More detailed haunted haveli wall textures and damp, cracked plaster.
- Expanded central gallery and additional connected architectural spaces.
- Carved decorative pillars in the mansion interior.
- Redesigned Veiled Bride ghost with added veil layers, crown details, spectral face markings and jewelry.
- Atmospheric low mist and enhanced supernatural lighting.
- Preserves the existing top-center pause button and mobile landscape controls.

How to play on Android:
1. Extract this ZIP.
2. Open index.html in Chrome, or edit it with Spck Editor.
3. Rotate your phone to landscape.

This is a browser-based canvas raycaster horror game, not a native APK or full polygonal 3D game. Tested: JavaScript syntax and ZIP integrity. Full browser gameplay testing was not performed.
