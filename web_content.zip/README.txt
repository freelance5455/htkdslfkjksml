Veltrixa Finance — hardened web build
for-server/          upload to an HTTPS host (index.html + _headers for Netlify/Cloudflare Pages, or nginx-snippet.conf for nginx)
for-apk-converter/   the same app, as the folder the Web2App converter expects (MyLedger-Pro/index.html). Rebuild the APK from it,
                     and in the converter turn OFF camera, microphone, location, storage and media permissions: this app needs none of them.
Contains NO tests, tools, source, README or keys. Keep SELLER-ONLY/ (your private license key) offline and never upload it.
