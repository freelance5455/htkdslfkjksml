MAHFILE MASTI CAFE - ORDER APP
This version adds:
- Cart with remove/clear
- Customer name + mobile + order type
- WhatsApp order message
- VIP room booking request through WhatsApp

IMPORTANT:
Before converting this ZIP to APK, replace WHATSAPP_NUMBER in index.html:
const WHATSAPP_NUMBER = "91XXXXXXXXXX";
Use digits only, e.g. 919876543210.
