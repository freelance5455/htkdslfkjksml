ONE LOVE V8
Prototype Android local.

Fonctions visibles :
- Accueil et publications
- J'aime et commentaires
- Création de compte / connexion
- Profil et photo de profil
- Recherche d'utilisateurs
- Messages de démonstration
- Création de groupes
- Notifications
- Paramètres

Important : les données sont stockées sur le téléphone avec localStorage.
Ce n'est pas encore une vraie base de données en ligne : les utilisateurs de deux téléphones ne partagent pas encore les mêmes données.
Pour transformer One Love en vrai réseau social public, il faudra ensuite ajouter un serveur/base de données et une authentification sécurisée.
