# Insta Messages App

## Frontend
Open `frontend/index.html` in Acode.

Before using Connect Instagram, replace:
`https://YOUR-BACKEND-DOMAIN.com`
with your deployed backend URL.

## Backend
Deploy the `backend` folder to a Node.js host.

Install:
npm install

Set environment variables from `.env.example`.

IMPORTANT:
- Never put INSTAGRAM_APP_SECRET in the frontend.
- Never collect Instagram passwords in your app.
- The API integration for conversations depends on the current Meta/Instagram API permissions and endpoints.
- This package provides the OAuth foundation and UI; it does not bypass Instagram access restrictions.

## Meta
You must create/configure the Meta/Instagram developer app and add the exact OAuth redirect URI used by your backend.
