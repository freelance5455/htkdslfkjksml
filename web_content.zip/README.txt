ASPENDOSRECORD V2 — OFFLINE SHIFT & PAYMENT TRACKER

Features:
• Record day/night/extra shifts, date, hours, earnings and notes.
• Track total earned, total paid, outstanding balance and shifts worked.
• Record multiple partial payments per shift with date, method, reference and notes.
• Edit shifts, inspect payment history, delete selected shifts/payments.
• Filter records by date and payment status.
• Remove fully paid shifts while preserving unpaid/part-paid shifts.
• Monthly summary.
• Export and restore JSON backups.
• Local browser storage and service-worker caching for offline use after first successful HTTPS load.

IMPORTANT:
This ZIP is a web/PWA project, not an APK. Data is stored in this phone's browser/app storage. A web app cannot request broad Android file-storage permissions like a native APK. Export a backup to Downloads regularly. Records do not sync to other devices.

For PWA installation/offline caching, host these files over HTTPS, open the site once in Chrome, then use Chrome menu > Install app/Add to Home screen. Opening index.html directly from a file manager may not enable service-worker offline caching.
