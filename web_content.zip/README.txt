OFFLINE MEDIA STUDIO — ALL-IN-ONE ZIP

WHAT IS INCLUDED
- Photo editing: filters, brightness, contrast, saturation, text overlay, PNG export.
- AI Prompt Lab: creates/copies/saves prompt text for use in an AI app.
- Photo Motion: slow zoom/pan animation from one photo, export to WebM if browser supports MediaRecorder.
- Slideshow: combine selected photos into a basic WebM slideshow.

ANDROID
1. Extract this ZIP using your file manager.
2. Open index.html with Chrome.
3. Try features in airplane mode to verify local operation.
4. Keep the page open while exporting video.

IMPORTANT HONEST LIMITATIONS
This package does NOT include actual generative AI model weights or a native inference engine.
Therefore it does NOT directly generate AI images from text or AI videos from text.
Real offline AI needs a compatible Android app/runtime and model files (often multiple GB), with hardware support. True AI video generation is particularly demanding.
The motion-video feature is a pan/zoom effect, not generative AI.
External research links are in the AI tab and require internet. Use trusted sources and review model licences.
