BOOST X — HTML app package

Contents:
- index.html: complete app
- assets/boostx-art.jpg: decorative generated artwork (if included)

Upload this ZIP to an HTML-to-APK builder that accepts an index.html at the ZIP root.
The app is a web-based Android wrapper companion. It does not overclock the device or read Roblox's private FPS/ping telemetry.
It performs only browser-exposed device checks and safe in-app optimizations. It never deletes user files.
