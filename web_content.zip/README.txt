Gaurav Browser - Web APK package
Open index.html at the ZIP root.
Default search: DuckDuckGo.
