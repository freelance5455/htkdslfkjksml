KILLERBOI web dashboard
Upload this ZIP to an HTML-to-APK builder that accepts a website ZIP.
The ZIP contains index.html at its top level.

The dashboard can connect to the existing KILLERBOI MT5 bridge using:
GET /status
POST /command with {"command":"start"} or {"command":"stop"}
Bearer API key authentication.

For live browser-to-bridge control, the bridge must permit CORS requests from the app and use HTTPS.
