HABITFLOW - INSTALLABLE WEB APP

Files:
- index.html       Main HabitFlow app
- manifest.webmanifest  App name/icon/install settings
- sw.js            Offline service worker
- icon.svg         App icon

IMPORTANT:
For Android "Install app" behavior, host this folder on HTTPS (for example GitHub Pages or Netlify).
Then open the hosted index.html in Chrome and choose "Add to Home screen" / "Install app".

The app's habit data is stored in the browser's local storage.
