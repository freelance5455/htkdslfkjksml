AI Mobile Agent — PWA starter

Files:
- index.html: user interface and command handling
- manifest.webmanifest: install metadata
- sw.js: basic offline shell caching

How to test:
1. Upload these files to a static HTTPS host (for example, a static site host).
2. Open the HTTPS page in Android Chrome.
3. Use Chrome menu > "Add to Home screen" or "Install app" if offered.
4. Voice input depends on browser support and microphone permission; speech recognition may require internet.
5. External sites open in a new tab. The app does not silently follow, subscribe, like, or comment.

This is an installable web-app starter, not a compiled APK. A native APK needs an Android project and build/signing process.
