AS Metal Dyes & Nakas - Staff App
Username: Ibrahim  Password: 1994
Products tab: add/edit products (photo, price, stock). Settings: set UPI ID for payments. Orders: Mark paid.
Home > Publish (or Settings > Data sync): download products.json and upload next to the customer app's index.html.
