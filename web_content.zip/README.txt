FOX WARRIOR v31 - Pixel Art Assets
- All PNG, transparent background (except sky, dirt tile, water tiles which are opaque).
- Native pixel size. Scale in your engine with NEAREST filtering (no smoothing), e.g. x3 or x4.
- Animated assets: one PNG per frame (name_00.png ...) + horizontal strip in strips/.
- assets.json lists frame count, frame size, fps, loop and pivot (x,y from top-left) for every asset.
- Characters face RIGHT (fox) / LEFT (zombie). Flip horizontally in code for the other direction.
- Fox frames are all 80x64 with the same pivot (feet center) so animations never jump.
- Tiles: grass_top (32x16) sits on top of dirt (32x32). Platforms: L + M repeated + R.
- Backgrounds: sky/clouds/mountains/forest layers are tileable horizontally - scroll at different speeds (parallax).

- v20: new main menu, full-screen map, Raven HQ (shop/upgrades/inventory), outfits (characters/fox_yl = golden outfit), bosses every 2 levels, drown/lava death, 6 upgrades.
- v21: Raven HQ screens (shop/inventory/upgrades) now sit over the map with the bottom tab bar; fixed New Game crash that blocked finishing stage 1; safer jump.
- v22: map and Raven HQ use the painted map art (ui/map_bg.jpg) with live level nodes; pause menu = Continue + Exit only; Raven HQ button added inside stages.

- v24: 3-star guide before each stage + star goals on the results screen; 9 general/weapon upgrades with up to 8 levels; 6 new weapons; shop with weapon stat bars and supplies (full ammo, coins x2, damage +50%); all weapons redrawn in pixel art with muzzle sparks and bullet trails.

- v26: knife-wielding zombies (new 72x64 pixel sprites: 6-frame walk, 7-frame knife slash with trail, lunge + sound), removed kill/coin quests, fixed menu crash on file:// (tainted canvas), fixed clipped titles in shop/upgrades.

- v27: added 'Restart stage' button to the pause menu.

- v28: fixed pre-stage screen clipping (Start/Continue buttons were cut off), added 'Restart stage' button there when a saved stage exists.

- v29: pre-stage buttons pinned to the bottom of the screen (always visible on short phones), compact layout on short screens.

- v30: all dialog panels auto-shrink to fit the screen height (no clipping, no fixed-position buttons); start/restart buttons back in normal flow.

- v31: zombies have more health (about +45%, growing in late stages); bosses much tougher (hp 80/130/200/300/420, faster, fire faster); removed the blue shield ring around the player.

- v33: bosses now use the supplied artwork (forest guardian, stone golem, village wood giant, armored dwarf, ice golem) enlarged with full animation sets; bosses no longer shoot; reaching a boss teleports you to a dedicated boss arena, and defeating the boss shows the star results screen and leads to the next stage; zombies no longer carry knives - they bite (new 7-frame bite animation); more and tougher zombies from stage 1; 20 new exclusive field weapons (two per stage, unique looks, never repeated in another stage and never sold in the shop).
