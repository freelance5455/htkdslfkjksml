JEPX PANEL - PROJECT ANDROID

Perubahan:
- Nama aplikasi dan label launcher: JepX Panel.
- Saat pertama kali dibuka, tampil halaman penyambutan "WELCOME TO JEPX PANEL".
- Tombol "MASUK KE JEPX PANEL" membuka halaman utama. Penyambutan hanya muncul pada pembukaan pertama.
- Crosshair hijau neon dapat tampil sebagai overlay dan digeser dengan jari.

Cara membuat APK:
1. Ekstrak ZIP ini.
2. Buka folder JepXPanel di Android Studio.
3. Tunggu Gradle Sync selesai.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug biasanya tersedia di app/build/outputs/apk/debug/app-debug.apk.

Catatan:
- Memerlukan izin "Display over other apps".
- Android versi baru dapat meminta izin notifikasi.
- Aplikasi hanya menampilkan overlay crosshair; tidak mengubah atau menyuntikkan kode ke game.
- Tidak ada jaminan bebas bug pada semua perangkat; lakukan pengujian sebelum digunakan.
