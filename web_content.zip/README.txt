ALPHA MONEY TRACKER - APKForge ZIP
===================================

මෙම ZIP එකේ index.html ගොනුව ප්‍රධාන Offline Web App එකයි.

APKForge භාවිතය:
1. ZIP ගොනුව APKForge හි HTML/ZIP Upload කොටසට Upload කරන්න.
2. index.html ප්‍රධාන HTML file එක ලෙස තෝරන්න (APKForge එය අසන්නේ නම්).
3. App name: ALPHA MONEY TRACKER
4. Package name: com.alpha.moneytracker (විකල්පය තිබේ නම්)
5. Build APK කර Android දුරකථනයේ Install කරන්න.

දැනට ඇති පහසුකම්:
- පුද්ගලයන් එක් කිරීම
- එක් පුද්ගලයෙකුට වෙන වෙනම ගනුදෙනු කිහිපයක්
- ලබාදුන් මුදල්, කොටස්/සම්පූර්ණ ආපසු ලැබීම්
- පුද්ගලයා සහ ගනුදෙනුව අනුව ඉතිරි ශේෂය
- PAID / PARTIAL / UNPAID තත්ත්ව
- Dashboard සහ ගනුදෙනු ඉතිහාසය
- Local storage මඟින් Offline දත්ත
- JSON Backup / Restore
- Print / Save as PDF

වැදගත්:
- දත්ත එම දුරකථනයේ App/WebView local storage තුළ පවතී.
- App data clear කිරීම හෝ uninstall කිරීමෙන් දත්ත නැතිවිය හැකිය. නිතර JSON Backup ගන්න.
- APKForge හි ZIP upload ක්‍රමය/version එක අනුව පියවර වෙනස් විය හැක.
