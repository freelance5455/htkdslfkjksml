Nasulu13 Font Changer — HTML Edition

This is an offline HTML/WebView version designed to be converted to an APK using an HTML-to-APK/WebView builder on an Android phone.

Included:
- Font gallery and live preview
- TTF/OTF local import
- Offline operation
- XOS 13 / Infinix Hot 40i guidance

Important:
This HTML APK can preview fonts but cannot, by itself, replace Android's system font. System-wide font application requires an XOS-supported Themes/font mechanism or elevated Android privileges.

Suggested APK settings:
- App name: Nasulu13 Font Changer
- Orientation: Portrait
- JavaScript: ON
- Local file access: ON
- File picker/storage permission: allow if requested
- Internet: not required
