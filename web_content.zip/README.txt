POCKET FOOTBALL CHALLENGE
=========================
App name:     Pocket Football Challenge
Package name: com.pocketfootball.challenge
Orientation:  Portrait

HOW TO PLAY
1. Open index.html in a mobile browser (Chrome) or install the APK.
2. Press PLAY.
3. Tap inside the goal to choose where to shoot (a yellow target appears).
4. Press SHOOT to kick the ball.
5. You get 5 shots. Results are GOAL, SAVED or MISS.
   Aiming near the corners is harder and can miss the target.
6. Your best score is saved on your phone.
7. Sound ON/OFF and Restart buttons are at the top right.

HOW TO MAKE AN APK FROM YOUR PHONE
1. Open this ZIP in your phone's file manager and keep it as a ZIP
   (index.html and README.txt are at the ZIP root, no extra folder).
2. In your phone browser, search for "HTML to APK converter"
   and open one (many are free; some need an account).
3. Choose the option to upload a ZIP / HTML project and select
   Pocket_Football_Challenge_Source.zip.
4. Enter these details:
     App name:     Pocket Football Challenge
     Package name: com.pocketfootball.challenge
     Orientation:  Portrait
     Fullscreen:   ON
5. Build, then download the APK and tap it to install.
   If Android blocks it, allow "Install unknown apps" for your browser
   or file manager when asked.

NOTES
- The game uses no internet, no external files and no libraries.
- This ZIP contains source code only. It is NOT an APK.
