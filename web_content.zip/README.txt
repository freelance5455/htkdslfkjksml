# Rice Mill Manager — APK Ready Package

यह package Android APK बनाने के लिए तैयार web-app assets और Capacitor configuration रखता है।

## मोबाइल पर
ऐसा APK builder चुनें जो Capacitor project / web app import स्वीकार करता हो।
Project root में:
- package.json
- capacitor.config.json
- www/index.html
- www/manifest.json
- www/sw.js

मौजूद हैं।

## महत्वपूर्ण
यह ZIP खुद APK नहीं है। APK compilation के लिए किसी Android build service/builder की जरूरत होगी।
Android Studio इस project की मूल web files के लिए आवश्यक नहीं है, लेकिन जिस builder/service का इस्तेमाल करेंगे उसकी अपनी requirements हो सकती हैं।

## App features
धान खरीद, 1 kg/quintal mandatory cutting, 15% moisture threshold,
55% rice recovery, manual recovery, party ledger, payments, reports,
printing, backup/restore.
