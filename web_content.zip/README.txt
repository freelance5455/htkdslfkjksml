Protocol Tracker v5.1 – Web/ZIP-Version

Diese ZIP ist für ZIP->APK-Konverter gedacht, die eine index.html im Stammverzeichnis erwarten.

Startdatei: index.html
Datenhaltung: localStorage auf dem Gerät.
Version: 5.1

Enthalten:
- Dashboard mit Tagesmakros und prominentem Proteinwert
- dynamische Makro-Zielberechnung
- manuelle Makroziele
- Körperdaten
- Ernährung
- Dosis & mathematische Rekonstruktion (mg/ml/U40/U100)
- Vorrat
- Training
- Labor
- Befinden
- Auswertung
- Körperbilder mit Datum/Gewicht
- Einstellungen
- lokaler JSON-Export/Import
