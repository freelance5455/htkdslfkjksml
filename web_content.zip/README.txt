GENIUS BHARAT AI - COMPLETE FILE

Upload this folder to Vercel.
In Vercel Environment Variables add OPENAI_API_KEY with your private key.
Deploy. Vercel will give a URL ending in /api/chat.
Put that URL into config.js as API_URL, then rebuild the Android app.

The demo AI fallback has been removed. The app will not pretend to be AI when the backend is missing.
Never put your OpenAI API key inside the HTML, JavaScript, config.js, or APK.