Unser Vorrat – eigene EAN-Produktdatenbank

Neu:
- Die EAN-Suche verwendet jetzt ausschließlich eure eigene Supabase-Produktdatenbank.
- Wird eine EAN gefunden, werden Name, Kategorie, Einheit und ggf. Marke/Menge/Bild automatisch übernommen.
- Wird eine EAN nicht gefunden, könnt ihr den Artikel normal eingeben; mit aktivierter Option wird die EAN beim Speichern automatisch als neues Produkt gemerkt.
- Beim nächsten Mal genügt die EAN und das Produkt wird automatisch erkannt.
- Open Food Facts wurde aus der Suche entfernt.
- Barcode-Kamera bleibt als separate Funktion erhalten.

Einmalig:
1. migration_produktdatenbank.sql im Supabase SQL Editor ausführen.
2. Danach die neue App-Version verwenden.

Hinweis:
Die Produktdatenbank ist pro Haushalt getrennt. Beide Benutzer desselben Haushalts sehen und verwenden dieselben gespeicherten Produkte.
