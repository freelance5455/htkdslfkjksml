PINTURIZE — PROJETO FUNCIONAL

Conteúdo:
- index.html
- style.css
- app.js
- manifest.json
- assets/logo-pinturize.jpg

Como testar:
1. Abra index.html em um navegador ou publique estes arquivos em um serviço de hospedagem.
2. O projeto funciona como uma interface web responsiva e pode ser convertido em APK por um serviço de empacotamento Android.
3. Os pedidos ficam salvos localmente no navegador (localStorage). Este protótipo ainda não possui banco de dados/servidor.
4. O botão WhatsApp usa o número da Pinturize: (21) 97561-3428.

Importante:
Este é o primeiro protótipo funcional. Para produção, recomendamos adicionar backend, autenticação, armazenamento de fotos, envio real de pedidos, painel administrativo e geração de PDF no servidor.
