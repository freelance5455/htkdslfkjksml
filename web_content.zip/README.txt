RANDOM RACERS — LOW GRAPHICS DEMO APK PROJECT
This is the lightweight web-game source intended to be packaged into an Android WebView APK.
It is NOT itself an APK.

Files:
- index.html — playable low-graphics racing demo.

To make an APK, import index.html into an Android/WebView wrapper or online APK builder.
The demo uses landscape-friendly controls and low rendering resolution for better performance.
