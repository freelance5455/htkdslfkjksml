HAPPY HEARTS ACADEMY – PWA HTML STARTER

HOW TO OPEN
1. Extract this ZIP if your HTML-to-PWA viewer requires extraction.
2. Open index.html using your Android HTML ZIP to PWA app viewer.
3. If the viewer offers an option to keep site data/local storage, enable it.
4. Use More > Settings & backup to download a JSON backup regularly.

INCLUDED
- Dashboard
- Learner registration and profiles
- Daily attendance
- Daily activity records
- Fees and printable receipts
- Learner report card drafts and print view
- Parent communication message drafts
- School calendar
- Photo gallery (small images)
- Staff records
- Basic class timetable template
- JSON backup and restore

IMPORTANT LIMITATIONS
- This is an offline-friendly single-device starter, not a hosted multi-user system.
- Records are stored in the browser's local storage on this phone. Clearing app/browser data can erase them.
- Backup files contain sensitive learner information. Store them securely.
- The role selector is a display/demo setting, not real login security or permission enforcement.
- Parent messages are drafts only; no SMS, WhatsApp, email, cloud sync, or push notifications are sent.
- The app is not yet connected to a secure server/database.
- The viewer must support JavaScript, localStorage, file inputs, and printing for all features to work.
