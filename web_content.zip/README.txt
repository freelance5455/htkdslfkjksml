SHAIKH Box ERP WebView Splash/Login Recovery ZIP

Includes index.html at root and web/index.html for converter compatibility.
Login splash is isolated in a separate script to ensure prior ERP script errors do not prevent the Continue button and 10-second transition from initializing. Hidden panel handling is enforced for WebViews.

Import this ZIP in the same APK converter. If error persists, share converter name/settings; no ZIP alone can fix an Android wrapper that fails to package local assets.


DISPLAY SETTINGS UPDATE:
- All-caps and bold display preferences enabled by default.
- Font family, text size, theme, delete confirmation, draft preference, sound feedback toggle, and compact card preferences are available under Settings.
- Preferences are stored locally on the device. Font availability varies by Android device.
