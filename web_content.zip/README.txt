AXELFF - PROYECTO ANDROID

El nombre de la aplicación y el título del lobby ahora son AXELFF.
Este ZIP es el proyecto fuente, no un APK instalable.

PARA GENERAR EL APK:
1. Descomprime este ZIP en una computadora.
2. Abre la carpeta del proyecto en Android Studio.
3. Espera la sincronización de Gradle.
4. Ve a Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Instala el APK generado en el teléfono.

Incluye lobby, avión, contador de 60 segundos, botón SALTAR, mapa, casas,
bots simulados y objetos para recoger. No incluye multijugador online real.
