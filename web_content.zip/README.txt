ALLIANCE RING SETUP — PHONE PROTOTYPE

Open Alliance_Ring_Setup.html in your phone browser.

Included:
- Pairing setup flow from the start
- Ring and kwami pod setup steps
- AI account/Alliance selection mock-up
- Ring theme, notification and snap-to-mute settings
- Friends list demo
- New hologram-style home screen
- Mood check-in, heart-rate placeholder and running-tracker placeholder

The “Hey Alliance” wake phrase/voice activation feature has been removed.

Important: This is a simple HTML prototype, not an APK. Pairing, AI sign-in, calls/texts, live heart-rate sensing and tracking are demo placeholders and do not connect to real hardware or online services. No advanced data is used.
