TradeSignal AI V4.6.6 — Potential Autopsy Lab
Segunda fase causal: separa contribuição do Potential no score, gate abaixo do custo, sensibilidade do limiar e sensibilidade do custo.
Uso: abrir o HTML no celular e tocar em EXECUTAR AUTÓPSIA DO POTENTIAL — 3K × 5K × 15K.
Sem envio de ordens.
