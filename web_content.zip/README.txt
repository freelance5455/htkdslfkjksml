NEXORA UPDATE MOD — WEBVIEW APK PACKAGE

Isi ZIP:
- index.html : halaman utama aplikasi
- style.css  : tampilan responsif dan animasi
- script.js  : interaksi tombol prank

Cara pakai:
1. Upload ZIP ini ke layanan HTML-to-APK / WebView APK Builder.
2. Pastikan builder memakai index.html sebagai halaman awal.
3. Nama aplikasi: Nexora Update mod
4. Build APK lalu unduh hasilnya.

Catatan:
- Ini paket web (HTML/CSS/JS), bukan APK jadi.
- Tidak meminta akses kamera, kontak, lokasi, penyimpanan, atau internet.
- Tulisan prank muncul setelah aplikasi dibuka, bukan saat proses instalasi.
- Tombol hanya menampilkan reaksi lucu; tidak menutup aplikasi secara paksa.
