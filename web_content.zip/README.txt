COMO USAR O PWA
1. Publique esta pasta em qualquer hospedagem HTTPS que aceite arquivos estáticos.
2. Abra o endereço no Chrome do Android.
3. Menu ⋮ > Adicionar à tela inicial / Instalar aplicativo.
4. O Controle Produção abrirá como aplicativo, sem barra do navegador.
5. Os registros ficam salvos no aparelho pelo armazenamento local.

Observação: para instalação PWA completa, o site precisa estar em HTTPS (exceto localhost).
