RD ALPHA MODARA — rebuilt web app

1. ZIP must contain index.html and logo.jpg at its ROOT. This archive is structured that way.
2. Upload this ZIP to the Zipped site preview service.
3. Login PIN: 2323
4. Data is stored in the browser's IndexedDB on the same device/browser. Do not clear site data. Use Backup regularly.
5. Backup JSON can be downloaded or shared with Android's native share sheet where supported.
6. Reports can be printed and saved as PDF. Share PDF uses HTML report sharing when supported; use Print / Save PDF for a real PDF.
7. This is a browser app, not a native APK. Persistence depends on the preview host retaining browser storage for the same site origin.
