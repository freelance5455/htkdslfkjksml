CHAOS PET — Glitchy
===================

Rychlé vyzkoušení:
1. Rozbal ZIP.
2. Otevři index.html v prohlížeči na mobilu.
3. Hra ukládá postup do úložiště daného prohlížeče.

Instalace jako PWA:
1. Nahraj obsah složky na HTTPS hosting (např. GitHub Pages).
2. Otevři adresu v Chrome na Androidu.
3. V menu Chrome zvol „Přidat na plochu“ / „Instalovat aplikaci“.

Poznámka:
Service worker a plná instalace PWA vyžadují HTTPS (nefungují při otevření souboru file://).
Postup je uložen pouze v daném prohlížeči / zařízení. Vymazání dat webu může postup smazat.
