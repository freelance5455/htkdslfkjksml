RD ALPHA MODARA Website ZIP

Upload this ZIP using Zipped site. index.html is at the ZIP root.
Backup supports Android share sheet when the browser supports file sharing.
Data is stored in this browser on this device; regularly share a backup file.
