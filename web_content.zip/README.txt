REMOTE-X UNIVERSAL 1.0
=======================

WHAT THIS BUILD DOES
- Works in modern mobile browsers on Android and iPhone/iPad browsers.
- Either phone can create a session or join one.
- Six-digit session code and explicit approval by the session creator.
- Live, two-way text messaging (500 characters), pause/resume, and end session.
- No target APK is required if the target opens the hosted page in a browser.

IMPORTANT LIMITATION
This is a consent-based remote SESSION and live messaging app, not full remote
control of the phone's operating system. It does not view the screen, tap apps,
read files, access camera/microphone, change passwords, or shut down a phone.
Those capabilities require separate platform-specific permissions and APIs.
iOS does not allow general-purpose third-party apps to remotely control the
whole device. Android screen sharing/input features require visible user
authorization and additional native Android implementation.

SETUP
1. Create a Firebase project: https://console.firebase.google.com
2. Add a Web app in Project settings and copy its config into firebase-config.js.
3. In Firebase Authentication > Sign-in method, enable Anonymous.
4. Create a Realtime Database.
5. Publish database.rules.json contents into Realtime Database > Rules.
6. Host this folder on an HTTPS host (Firebase Hosting is recommended).
   Do not use file:// directly; Firebase Auth requires an authorized web domain.
7. Add the hosted domain to Authentication > Settings > Authorized domains.
8. Open the same hosted URL on both phones.
9. Phone A taps Create session and shares the six-digit code.
10. Phone B taps Join session, enters the code, and requests to join.
11. Phone A reviews the request and taps Approve this device.

APK PACKAGING
A WebView/website-to-APK builder can package index.html, but this project uses
Firebase over the internet, so the builder must allow internet access and the
hosted HTTPS URL should be used as the app start page. The easiest option is
to host the app and use a trusted WebView wrapper pointing to that URL.
Both phones can also simply use the browser and Add to Home Screen.

SECURITY NOTES
- This starter uses Firebase anonymous sign-in. It does NOT implement SMS OTP.
- A six-digit session code is for pairing convenience, not strong identity proof.
- Use a production security review before exposing this service publicly.
- Add App Check, rate limits, short session expiry, and stronger pairing tokens
  before production use. Never publish Firebase service-account credentials.
- The sample database rules are a starter and should be tested in Firebase
  Rules Simulator before real deployment.

FILES
index.html             App interface
style.css              Neon-green responsive design
app.js                 Pairing and realtime messaging
firebase-config.js     Your Firebase web config (fill this in)
database.rules.json    Starter database rules
manifest.json          PWA metadata
