My Planner - HTML ZIP for ZIP to APK
Package Name: com.hassony.todo
App Name: My Planner
The Add Task sheet was restored to the older layout style.
Share App feature removed.
