Music File Verifier v2
=======================
Versi diperbaiki untuk Android/browser WebView.

Perbaikan utama:
- Menghapus penggunaan BigInt yang dapat membuat JavaScript gagal dijalankan pada WebView tertentu.
- Pemrosesan file dibuat lebih aman dengan try/catch per file.
- Mendukung beberapa FLAC sekaligus.
- Pemeriksaan signature mora dan OTOTOY.
- Menampilkan sample rate, bit depth, channel, durasi, ukuran file, estimasi saving vs PCM, cover art, vendor, dan metadata.

Cara memakai:
1. Buka index.html di browser.
2. Pilih satu atau beberapa file FLAC.
3. Hasil verifikasi muncul di halaman.

Untuk membuat APK:
ZIP ini dapat diunggah ke layanan HTML-to-APK/cloud builder yang mendukung website/HTML lokal.
