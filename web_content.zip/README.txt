Contractor Pro V4.1

New in this version:
- Inventory: in/out with date, shelf view of current stock for many item types, quick +In / -Out on each shelf slot, out-of-stock protection.
- Tools: tool type and quantity needed per project, grouped by project.
- Languages: French and German added to every screen (7 languages total).
- Clients: separate account per client (contracts, payments, balance, projects) and add-client.
- "+" add button in every section (dashboard card corner, page header, floating button).

Structure for HTML-to-APK: web/index.html
Data stays on the device (localStorage, same key as V3/V4, so old data is kept).
