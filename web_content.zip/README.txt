# Dear Supriya — Forever Us (HTML ZIP)

## Contents
- `index.html` — complete responsive romantic experience with CSS and JavaScript embedded
- `assets/app-icon.png` — app icon image (if included in this package)

## Test it
1. Extract the ZIP.
2. Open `index.html` in a modern browser, or load it into your HTML-to-APK/WebView builder.
3. Keep the `assets` folder beside `index.html` so the icon can load.

## Convert to APK
Use an Android WebView wrapper or a reputable HTML-to-APK builder. Set `index.html` as the start page and choose `assets/app-icon.png` as the launcher icon if your builder supports it. Test the resulting APK on your own phone before sharing it.

This package is the HTML source ZIP, not a compiled APK. No network connection or special Android permissions are required for the page's core interactions.
