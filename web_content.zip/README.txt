SAVE SHOP OFFLINE v5
=====================
100% offline single-file web app.

Features:
- Product search/category
- Add/Edit/Delete products
- Product image upload (stored locally)
- Stock management
- Cart
- Cash on Delivery checkout
- Delivery charge
- Orders + statuses
- Admin PIN
- Backup Export/Import
- LocalStorage persistence
- No Supabase, no server, no internet required after installation

Default Admin PIN: 1234
You can change it from Admin > Settings.

Important:
Data is stored on the device/browser/app storage. Clearing app data can remove it.
For multiple phones/cloud sync, a separate online version is required.
