ZgamesStaff

Fresh configuration:
- First launch: Create Admin Account. Store Name becomes Admin Name.
- Default password: 63427.
- Admin: Add/Edit/Deactivate staff, Event History, Working Hours, Export, Backup, Restore, Settings > Reset Admin Password, Logout.
- Staff: unique 4-digit ID toggles CHECK-IN/CHECK-OUT and supports multiple sessions.
- Main screen has three-dot Admin Login and About.
- About: ABDULRAHEEM / OMAN.
- No Google Drive, OAuth, API, Firebase or cloud services.
- Backup/Restore uses local file picker where supported; otherwise browser download/file picker.
