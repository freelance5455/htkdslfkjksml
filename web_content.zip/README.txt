Max Call — qo‘ng‘iroq musiqasi funksiyasi

Fayllar:
- index.html: yangilangan ilova ichki sahifasi

Qanday ishlatish:
1. Android loyihangizdagi assets/web/assets/web/index.html faylini shu index.html bilan almashtiring.
2. Ilovani qayta build qilib, APKni imzolang.
3. Max Call ichidagi Musiqa bo‘limida audio fayl qo‘shing.
4. Trek yonidagi “📞 Qo‘ng‘iroqqa” tugmasini bosing.
5. Ilova ichidagi chiquvchi qo‘ng‘iroq ekranida tanlangan musiqa ijro etiladi.

Muhim cheklovlar:
- Bu ZIP tayyor o‘rnatiladigan APK emas; bu APK ichki sahifasining yangilangan fayli.
- Siz yuborgan base.apk ichidan index.html olinib, faqat musiqani tanlash/qo‘ng‘iroqda ijro etish funksiyasi qo‘shildi.
- Tanlangan trek hozircha ilova sessiyasida saqlanadi; ilova qayta ochilganda qayta tanlash kerak bo‘lishi mumkin.
- Bu mahalliy qurilmada qo‘ng‘iroq ekranida musiqa chaladi. Suhbatdoshga ham uzatish uchun audio/video qo‘ng‘iroq SDKsi bilan alohida integratsiya zarur.
