Rupiyal APK-ready package. Entry point: index.html
