Listener - म्यूज़िक प्लेयर (PWA)

इंस्टॉल कैसे करें:
1. इस ज़िप को खोलकर सारी फ़ाइलें किसी वेब होस्टिंग (Netlify Drop, GitHub Pages, Vercel आदि) पर डालें।
2. फ़ोन के Chrome में उस लिंक को खोलें -> मेन्यू -> "Add to Home screen" / "Install app"।
   (iPhone: Safari -> Share -> Add to Home Screen)
3. ऐप खोलकर "+ गाने जोड़ें" से अपने फ़ोन के गाने चुनें।

नोट: PWA को इंस्टॉल करने के लिए https लिंक चाहिए। सिर्फ़ फ़ाइल खोलने से इंस्टॉल नहीं होगा।
