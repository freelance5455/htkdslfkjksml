Daily Expense & EMI – Free Prototype

1. Open index.html in Chrome/Edge on your computer or phone.
2. Your Excel's current Daily and EMI records are already included.
3. New records are saved locally in the browser.
4. This is the first working prototype; next step can be converting it to a proper installable Android/PWA app and adding Excel import/export, reminders and cloud backup.

Important: browser-local data is not automatically synced between devices. Keep the JSON backup until cloud/database sync is added.
