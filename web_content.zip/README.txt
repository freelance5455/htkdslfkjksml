MY TUK TUK - Android project

Features
- Offline hire and payment records.
- Daily Hire, Credit and Monthly School Hire sections.
- Hire List: add a customer once, then mark each date that customer went on hire.
- Edit or remove individual marked hire days and edit customer names.
- Edit or delete existing daily, credit and school records.
- Backup and restore app data as a JSON file.
- Existing records stored under the original mytuktuk_records key are retained.

Build
- Open this folder in Android Studio, or run ./gradlew assembleDebug on a machine with internet access.
- The Gradle bootstrap launcher uses Gradle 8.9 and downloads the distribution on first run.
- Android Gradle Plugin: 8.7.3; Kotlin plugin: 2.0.21; compile SDK: 35.

App data is stored locally on the device. Use Backup Data before uninstalling or clearing app storage.
