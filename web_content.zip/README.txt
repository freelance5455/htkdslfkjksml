RAJU HUNTS — OFFLINE PACKAGE

The game HTML has been changed to load Three.js locally instead of from the internet.

ONE-TIME SETUP (requires internet once):
1. Download the Three.js r128 minified browser build from:
   https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
2. Save the downloaded file in this same folder, with the exact name: three.min.js
3. Keep both files together:
   - Raju_Hunts.html
   - three.min.js

PLAY OFFLINE:
1. Turn off mobile data and Wi-Fi.
2. Open Raju_Hunts.html in Chrome or another browser that supports WebGL.
3. Use landscape orientation.

IMPORTANT:
- This is an offline-capable browser version, not an Android APK.
- The game engine must be downloaded once before offline play.
- Browser support for opening local HTML files varies on Android. If Chrome blocks local files, use a trusted local HTML viewer/browser that supports JavaScript and WebGL.
- Progress uses browser local storage and may not transfer between browsers.

Three.js r128 is MIT-licensed. Keep its license notice if redistributing the library.
