Solar Calculator - Android Studio Project
=====================================

IMPORT KARNE KA TARIQA:
1. Android Studio open karo
2. Open -> is folder ko select karo (SolarCalculatorAndroid)
3. Gradle sync hone do
4. Run button se APK banao ya Build > Build Bundle(s) / APK(s) > Build APK(s)

PLAYSTORE ASSETS:
- playstore-icon-512.png (512x512) -> Play Console me High-res icon ke liye
- playstore-feature-graphic-1024x500.png -> Feature Graphic
- app/src/main/res/mipmap-* me launcher icons already add hain

PACKAGE: com.solar.calculator
APP NAME: Solar Calculator

HTML file: app/src/main/assets/index.html me hai, update kar sakte ho

APK BUILD:
Android Studio me: Build > Generate Signed Bundle / APK > APK > apna keystore banao

