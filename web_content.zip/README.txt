Anime Quest Pro Max
===================
- 26 anime worlds and 50 questions per world in 3 tiers: medium/hard/impossible (1300 total).
- Arabic RTL responsive UI designed for mobile/tablet.
- Progress, XP, coins, unlock progression, achievements, sound effects, optional vibration.
- App icon supplied by you is included as icon-192.png and icon-512.png and referenced in the PWA manifest.
- Offline caching is provided by sw.js after the first visit when served over HTTPS or localhost.

IMPORTANT:
For best results, run using a static web host (HTTPS) or a local server. Opening index.html directly works for gameplay in many browsers, but PWA installation and service worker offline support require HTTPS/localhost.
The character names are the answer bank; several hints for later worlds are generic. This is a self-contained fan-made quiz and is not affiliated with any anime rights holders.
On Android: unzip the archive, upload the folder to a static host or use a local web server app, open index.html, then browser menu > Add to Home screen / Install app.

--- v2 fixes ---
Data embedded inline (fixes dead buttons), answer buttons fixed, skip no longer counts as solved,
world-completion bonus only once, progress remembers last world, network-first service worker, icons optimized.
