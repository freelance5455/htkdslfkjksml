TaskFlow Android project

Build APK:
1. Install Android Studio (latest stable) on a computer.
2. Open this TaskFlowAndroid folder using File > Open.
3. Allow Gradle sync and install the Android SDK platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is created at app/build/outputs/apk/debug/app-debug.apk.

Important:
- This is an Android Studio source project, not a precompiled APK.
- This environment does not have Android SDK or Gradle installed, so an APK could not be compiled or device-tested here.
- Reminder scheduling uses Android AlarmManager. Android battery optimization, exact-alarm permission, and manufacturer restrictions can affect delivery.
- This starter build persists task data in WebView local storage. Reboot restoration of scheduled alarms and robust recurring reminder rescheduling still need a final native implementation and physical-device testing before production release.
