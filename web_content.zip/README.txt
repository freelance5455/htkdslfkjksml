Hisab Se Aasan — Final prototype
मुख्य स्क्रीन, व्यक्ति सूची, व्यक्ति की अलग स्क्रीन, लेना/देना, भुगतान दर्ज करना और बाकी रकम का हिसाब।
इसे चलाने के लिए www/index.html को Chrome में खोलें।
यह APK नहीं है; यह browser में चलने वाला offline prototype है।
