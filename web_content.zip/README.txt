AutoTech Work Assistant V4
Phone-friendly offline HTML app for conversion to APK.

Includes:
- 33 vehicle brands and common models
- Expanded practical DTC reference
- DTC category search (P/B/C/U)
- Vehicle/year/ECU records
- Battery/charging check
- CAN resistance check
- Voltage-drop check
- Workshop job history stored locally
- Parts and test guide
- Offline operation after packaging

Important:
This is a diagnostic reference, not a substitute for OEM service information.
Generic DTCs are standardized, while many manufacturer-specific DTCs depend on make/model/year/ECU.
