SHAIKH BOX ERP — WORKFLOW QA BUILD

Based on the user-supplied SHAikh Box ERP Deep Audit/Billing ZIP. Existing design and module structure are preserved.

Corrections in this build:
- Moved compatibility targets required by the initial render before the app startup script. Previously renderAll() could execute before those nodes existed and stop the first render.
- Moved billing dropdown CSS back inside the document's style element; it had been outside the style block and was rendered as visible page text.
- Kept root index.html and web/index.html byte-identical for common Android WebView ZIP converters.
- Preserved party/item/GST dropdown refresh patches and the existing modules.

Checks performed:
- ZIP integrity test.
- JavaScript syntax check for all inline scripts.
- HTML duplicate-ID scan.
- Headless browser smoke test with simulated local/session storage: startup completed without page errors; navigation/rendering for all page sections completed without errors.
- Workflow smoke test: add/save a customer and confirm it appears in party dropdown; add/save item and confirm it appears in item dropdown; select customer/item, select 18% GST, create sample invoice and verify ₹40 taxable + ₹3.60 CGST + ₹3.60 SGST = ₹47.20 total; no browser page errors or console errors during these steps.

Important limits:
- Automated browser smoke tests are not the same as testing the APK on your Android phone or every ZIP-to-APK converter. Please test with sample data first and keep a backup.
- GSTIN auto-fetch, government e-Way bill creation, SMS OTP, native biometrics, and background notifications require external services/native Android integration.
- Review company-specific data isolation and linked stock/ledger effects before using live business records.
