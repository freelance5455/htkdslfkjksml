Color Rush - APK Builder Ready

Upload this ZIP to an HTML-to-APK builder that accepts a ZIP containing index.html at the root.
Main file: index.html
App name: Color Rush
Package ID: com.colorrush.game
