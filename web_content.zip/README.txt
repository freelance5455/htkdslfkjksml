CALTRACK — version PWA
=========================
Fonctions:
- objectif calorique
- ajout manuel calories + macros
- recherche produit par code-barres via Open Food Facts
- historique local
- photo avec capture caméra, puis confirmation manuelle pour éviter les fausses calories
- thème rouge/noir
- fonctionnement installable comme PWA

Installation Android:
1. Héberge ce dossier sur un site HTTPS (GitHub Pages, Netlify, Vercel, etc.).
2. Ouvre l'adresse avec Chrome sur Android.
3. Menu ⋮ > "Ajouter à l'écran d'accueil" / "Installer l'application".

Important:
Une photo seule ne permet pas de connaître précisément les calories d'un repas. La version actuelle refuse donc de fabriquer une valeur présentée comme exacte. Le code-barres utilise Open Food Facts lorsqu'une connexion Internet est disponible.
