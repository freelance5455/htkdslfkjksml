Family Finance Web App
========================
This ZIP is designed for ZIP-to-APK / WebView converters that require index.html at the ZIP root.

Default PIN: 1234

Features:
- Dashboard with imported 21-09-2026 data
- Income, expense and remaining balance
- Transaction list
- Expense report
- Add income/expense
- Local browser storage (new entries persist on the same device/browser)
- Bengali / English language switch
- Change PIN
- Reset to imported data

Important:
The app works offline because it does not require external libraries or internet services.
