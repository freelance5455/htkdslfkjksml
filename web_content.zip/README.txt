MAX Online Store — starter app

Included:
- Mobile-friendly MAX shopping home screen
- Men's Shirt listing at ₹549
- Add to Cart and cart total
- Search field
- WhatsApp checkout placeholder

Important:
1. This is a free starter PWA, not yet published on Play Store.
2. To install it as an app, upload these files to a free HTTPS host (for example GitHub Pages).
3. Before accepting orders, set your WhatsApp Business number in checkout code.
4. Replace “Add product photo” with your shirt photo and add your MAX logo/photo.

Open index.html to preview the design. For installable PWA behavior, it must be hosted on HTTPS.
