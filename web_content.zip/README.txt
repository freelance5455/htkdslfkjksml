CLOUD PLAY V4 — Google login required to play

Behavior:
- Anyone can browse and add games in the current browser.
- Pressing Play requires a signed-in Google account.
- Google login uses Firebase Authentication redirect flow.
- This is a front-end integration scaffold; configure Firebase before login works.
- The Play button opens the user-provided game/stream URL after login and safety confirmation. It does NOT create a cloud gaming server or verify game ownership.

Firebase setup:
1. Go to https://console.firebase.google.com/ and create a Firebase project.
2. Add a Web App to the project and copy its Firebase web config.
3. Open firebase-config.js and replace YOUR_API_KEY, YOUR_PROJECT_ID and YOUR_APP_ID with the values from Firebase.
4. Firebase Console > Authentication > Get started > Sign-in method > enable Google.
5. Authentication > Settings > Authorized domains: add your published Netlify domain (example: your-site.netlify.app).
6. Upload all five files in the same website folder: index.html, styles.css, app.js, firebase-config.js, README.txt.
7. Use HTTPS hosting and reload the website.

Important:
- Never share passwords, private service-account keys, or OAuth client secrets.
- A Google sign-in alone does not provide cloud gaming. A compatible streaming provider/server and its official integration are still required.
- Game entries and reward demo state are browser-local in this starter; they are not synced across accounts.
