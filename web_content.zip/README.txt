LEGENDARY ZIZO ADVENTURE — MULTIPLAYER

Files:
- index.html: game, UI, procedural 3D city and multiplayer logic in one HTML file.

Start:
1. Extract ZIP.
2. Open index.html in an internet-connected browser. Three.js and PeerJS are loaded from CDNs.
3. Press Multiplayer > Create New Server. Share the displayed six-digit code.
4. On the other device, press Multiplayer > Join Server and enter the code.

Important networking notes:
- PeerJS uses its public signaling service by default to establish WebRTC connections. This is not a paid game backend, but it is an external service and availability is not guaranteed.
- This demo is peer-to-peer and designed for two players in a simple room. NAT/firewall restrictions may prevent some connections.
- This is a playable prototype. Multiplayer state synchronization is best-effort and not authoritative/anti-cheat.
- The city is procedural; the elevator is a floor selector/teleport approximation rather than a full interior simulation.
- Since dependencies are CDN-loaded, internet is required. For fully offline APK packaging, bundle Three.js and PeerJS locally and update script URLs.
