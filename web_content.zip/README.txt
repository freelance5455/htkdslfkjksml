
FIX: No puedo poner mi música en APK

ApkForge WebView bloquea el file picker oculto.
Este fix agrega un panel visible 📁 en la parte inferior que SÍ funciona en WebView.

Si +Audio no abre, usa el botón 📁 flotante abajo a la derecha.

Android 13+: permite acceso a audio cuando el sistema lo pida.

100% offline, IDB, sin piratería.
