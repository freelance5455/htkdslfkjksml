Samsung Remote — HTML-to-APK package

This package is structured for an HTML/ZIP-to-APK builder:
- index.html is at the ZIP root.
- All styling and JavaScript are embedded.
- No Gradle, Kotlin, external libraries, or CDN assets are required.

IMPORTANT LIMITATION:
This is an experimental web implementation. It uses the legacy Samsung TV WebSocket endpoint on port 8001. Many newer Samsung Tizen TVs require secure WebSocket pairing on port 8002 and a token. A WebView-based HTML wrapper may not be able to complete that pairing. This package has NOT been tested against a physical Samsung TV.

App shortcuts are currently labels only and do not launch apps. The Assistant button sends KEY_VOICE, which may not be supported. Automatic TV discovery is not included; enter the TV's IP address manually.

For APK Maker, upload this ZIP as a website ZIP. If it asks for permissions, enable Internet access. Network state is not required by this HTML-only implementation. Local-network access may still be restricted by the wrapper or Android version.
