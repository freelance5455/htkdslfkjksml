MOB CROWD RUSH - WEBINTOAPP ZIP

The ZIP root contains index.html directly (not inside a nested folder).
Upload this ZIP to your HTML-to-Android app maker.

This is an HTML5 playable prototype. Touch and drag left/right to move.
Characters spawn over time; +5 and x2 gates increase the crowd; an enemy
crowd appears later. This is separate from the Unity C# starter project.
