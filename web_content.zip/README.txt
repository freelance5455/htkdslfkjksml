RIFTBOUND: SHADOW EVOLUTION — 3D HTML GAME (Improved)

HOW TO PLAY
1. Extract this ZIP (or open the folder).
2. Open index.html in Chrome, Edge, or another modern browser.
3. Internet access is required to load the Three.js engine from its CDN.

CONTROLS
Keyboard: WASD / arrow keys move, mouse drag looks around, J attacks, K uses special, Space dodges, E talks, I opens inventory.
Controller (standard Gamepad API / Xbox / DualShock / DualSense layout):
  · Left stick — move
  · Right stick — look (with deadzone + response curve)
  · A / Cross — attack
  · B / Circle — dodge
  · X / Square — special burst
  · Y / Triangle — summon shadow ally
  · LB / L1 — inventory
  · RB / R1 — interact / talk
  · RT — alternate attack
  · Start / Select — inventory
  · L3+R3 or LT+RT — reset camera
  · D-pad Down — close inventory
  · D-pad Up — close dialogue
Rumble feedback on hit and heavy attacks (when the browser + controller support it).
The bottom HUD automatically switches help text when a controller is connected.

Mobile: on-screen joystick + action buttons; drag the world to rotate the camera.

WHAT WAS IMPROVED (vs original ChatGPT build)
· Equipment now grants real ATK / DEF stats by rarity (Common / Rare / Epic).
· Armour reduces damage taken; weapons increase attack power and range.
· Accessories can boost mana regeneration.
· Inventory shows live ATK / DEF and supports consumable potions (USE button).
· Better loot tables: gold, potions, weapons, armour, materials; bosses drop better gear.
· Side quests track progress correctly (herb bundles from combat in the wilds, kill counter from quest accept).
· Controller support hardened: deadzones, analog curves, connection toasts, button remaps, camera reset, inventory/dialogue navigation, rumble.
· Level-ups raise max HP properly; XP scales with enemy strength.
· Opening inventory pauses combat; dying allows restart via inventory / Start button.
· Shop sells actual potions into your bag instead of only healing once.

FEATURES
- Large fantasy world with mountain ridges, forest belts, meadows, ruins and a Demon King fortress.
- Start with no weapon, armour, items or gold. Choose a unique ability, then find loot by defeating enemies.
- Inventory and equipment slots for weapon, head, chest, legs and accessory. Equipped weapon and armour visuals appear on the character.
- NPC conversations, side quests, enemy types, XP, leveling, and boss progression.

NOTES
Procedural 3D prototype using Three.js from a CDN. Controller support uses the standard Gamepad API.
