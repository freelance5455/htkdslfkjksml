FARM MONITOR v4.0.0  (index.html + icon.png, no build step needed)

CHAT ASSISTANT (bell icon on Overview, or "Ask AI"): chat-style screen. App notifications appear in the
conversation as cards. The AI agent (Gemini function calling) can add/edit/delete expenses, income, flocks,
stock, feed plans, daily costs, calendar events, medicine schedules, alarms, weights, eggs, transfers,
incubator batches, debts and profile - and undo its changes ("undo", or the Undo button).
The Gemini key is built in (AI_KEY_DEFAULT in index.html); Settings -> AI assistant can override it.
NOTE: a key inside an app file can be extracted - restrict it in Google Cloud/AI Studio (Android app
restriction + quota) or move calls to your own server before publishing the app to others.

GOOGLE ACCOUNT / DRIVE SYNC: one-time developer Client ID needed (see earlier notes):
Android native: Capacitor + @codetrix-studio/capacitor-google-auth; web/PWA: GCID_DEFAULT in index.html.
Closed-app alarms/reminders: install @capacitor/local-notifications. Back button: @capacitor/app.
