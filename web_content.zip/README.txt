NEON NIGHTFALL — SCI-FI FPS ANDROID PROTOTYPE

WHAT THIS IS
A browser-playable 3D first-person sci-fi training arena with a nighttime neon city, pulse-carbine viewmodel, touch HUD, movement joystick, aiming by dragging, firing, reloading, dash movement, and 8 floating training bots.

HOW TO PLAY ON ANDROID
1. Download and extract this ZIP using your Files app.
2. Open index.html with a browser or trusted HTML preview app.
3. Keep internet enabled: Three.js is loaded from a CDN.
4. Rotate your phone to landscape for the best experience.
5. Tap INITIALIZE DROP.

TOUCH CONTROLS
- Left thumbstick: move
- Drag the right side of the screen: look / aim
- FIRE: shoot (hold for repeated shots)
- CHARGE: refill energy magazine from reserve
- DASH: quick forward movement

DESKTOP TESTING
- WASD: move
- Mouse or drag: look
- R: charge/reload
- Shift: dash

LIMITATIONS
- This is a prototype, not a finished commercial game.
- The targets are local computer-controlled training bots, not real online players.
- No matchmaking, accounts, battle royale lobby, shrinking zone, or multiplayer server is included.
- It is not an APK. It runs as an HTML game in a compatible browser/preview.
- Internet is required to load the Three.js engine from the CDN.
