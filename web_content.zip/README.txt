TechYolo Login + Sign Up interface.
This is a UI prototype only. It does not create real online accounts yet.
Next step: connect authentication to Firebase or Supabase.
Upload the ZIP directly to the ZIP-to-APK app; do not extract it first.
