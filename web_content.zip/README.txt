UNSER VORRAT – TESTVERSION

Diese Version ist die gemeinsame Testphase mit dem neuen Gothic / Neon / House / Urban Layout.

Enthalten:
- Fledermaus-Logo
- Gothic/Neon-Design mit roten, blauen, orangenen und violetten Akzenten
- Fledermäuse als wiederkehrendes UI-Motiv
- große klickbare Übersichtskarten
- feste Navigation unten: Vorrat / Einkauf / Rezepte
- klickbare MHD-/Einkaufs-/Mindestbestands-Karten
- Vorrat, MHD-Chargen, Einkauf, Rezepte, Produktdatenbank und Supabase bleiben erhalten

Supabase bleibt das bestehende Projekt „Vorrat 2.0“.

WICHTIG:
Diese Version ist als Testbasis gedacht. Erst mehrere Tage normal benutzen und neue Änderungswünsche sammeln, bevor wieder größere Umbauten gemacht werden.
