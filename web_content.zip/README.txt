PASHTUN BACHA — NEON XO + ROBOT
================================

Files:
- index.html: the complete game with your uploaded photo embedded. Works offline after extracting.

Features:
- Two-player mode: Player A vs Player B
- Robot mode: Player A vs Robot
- The robot's play style changes randomly each round: 50% Smart Robot (tries to win/block) and 50% Friendly Robot (random moves). This makes results varied; it does NOT guarantee a mathematically exact 50/50 win rate.
- Neon visual design and glowing electric line across a winning three-in-a-row
- English spoken winner announcements using browser speech synthesis, plus move/win sound effects
- Scoreboard, Restart Round, Reset Scores, Voice ON/OFF
- Creator: Mansoor Niazai / پشتون باچا

Android:
1. Extract the ZIP.
2. Open index.html in Chrome.
3. Choose 2 Players or Play vs Robot.
4. If speech is silent, enable a text-to-speech voice in Android settings and try Chrome.
