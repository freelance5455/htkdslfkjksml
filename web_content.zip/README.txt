GOLD SCANNER PRO V3.1 - FIXED LIVE FEED

This version fixes the "Failed to fetch" problem by using a CORS-friendly XAU/USD source first, with fallback sources.

Phone build:
1. Upload this ZIP to your web-to-APK builder.
2. App name: Gold Scanner Pro.
3. Build and install the APK.

The scanner needs an internet connection for live XAU/USD prices. M5 candles are built from live observations while the app is open.
