Adminu Admin Panel
- index.html ን WebView/HTML APK builder ውስጥ ያስገቡ።
- Item ስም፣ ዋጋ እና ፎቶ መጨመር/ማስተካከል/መሰረዝ ይቻላል።
- መረጃው በዚያ መሳሪያ local storage ውስጥ ይቀመጣል።
