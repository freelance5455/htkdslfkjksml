REAMAB V2 - Smart Salary & Expense Manager

This build preserves the existing V1/V2 fundamentals and adds:
- Three selectable icon sizes (Large / Medium / Small) from Settings, saved locally.
- Real responsive navigation icons that follow the selected icon size.
- Smaller REAMAB V2 top logo for a cleaner header.
- Dedicated Fixed Expenses section replacing the REAMAB AI section.
- Fixed expenses can be added, categorized, listed, deleted, or cleared.
- Fixed monthly expenses are included in total spent, remaining balance, spending ratio, and analytics.
- Existing budget, custom names, themes, languages, currencies, notes, normal expenses, spending plans, savings goals, analytics, reports/PDF print, and JSON backup are retained.

DATA:
Fixed expenses are stored locally with the existing application data. JSON export/import also preserves them and the selected icon size.

APK:
This is a web/Capacitor source project. Android APK compilation requires the Android/Capacitor build environment.
