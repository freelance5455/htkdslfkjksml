The Magic Adventures of Nino - Neon Quest

Main game: NINO_Neon_Quest_HD.html

Open the HTML file in a modern browser. For mobile play, rotate the phone to landscape and allow fullscreen if prompted.

Controls: floating joystick on the left; large Jump, Attack, and Special buttons on the right.
