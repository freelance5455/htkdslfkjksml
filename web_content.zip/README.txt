THAKUR TEMPLE RUN - CHARACTER UPDATE

New 3D runner character with visible arm/leg running animation and body bounce.
Controls: Left/Right, Jump, Slide; swipe left/right/up/down on mobile.
Internet connection is needed to load Three.js from CDN.
