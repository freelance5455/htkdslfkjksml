RIFT//RUMBLE v7 - ALT OVERDRIVE
================================

A mobile-first 2D top-down free-for-all arena fighter. The complete game is in index.html; it uses canvas-drawn models and does not need separate image files.

WHAT'S NEW IN V7
----------------
- Added weapon-specific ALT attacks for the full weapon collection. Weapon cards now describe what each ALT does, and the on-screen ALT button shows its assigned action.
- ALT moves are differentiated by weapon family: piercing and charged shots, spreads, melee sweeps, chain lightning, gravity implosions, healing bursts, homing rockets and drones, meteor strikes, freeze rings, return throws, and more.
- Quantum Yo-Yo now actively homes back to its owner after travelling out or hitting a target. Its returning attack can hit multiple opponents.
- Homing missiles and drone projectiles actively steer toward a living opponent.
- Afterimage Decoy creates three targetable holographic decoys. Opponents can attack the decoys, while the owner's own attacks do not hit their own decoys; decoys expire and do not count as kills.
- Echo Edge repeats its attack after a short delay, while Echo Mine triggers a delayed area pulse after impact.
- Removed the bottom helper notes from both Weapons and Specials views, the Upgrades screen, and the bottom of the Online screen.
- Renamed the loadout switcher label to simply "WEAPONS" and reduced the size of the bottom navigation bar.
- Retains 31 arenas, 63 weapons, and 16 special abilities (with hidden Admin content).

CONTROLS
--------
Mobile:
- Left stick: move
- ATTACK: hold to attack
- SPECIAL: use the equipped special ability
- DASH: quick movement burst
- WEAPON: cycle unlocked weapons
- ALT: use the equipped weapon's secondary function when it has one

Keyboard:
- W/A/S/D or arrow keys: move
- Space: attack
- E: special
- Shift: dash
- Q: cycle weapon
- F: ALT secondary
- Escape: pause offline matches only. Online matches cannot be paused.

WEAPON ALTS
-----------
Each weapon card in the Weapons tab contains a brief description of its ALT move. The in-game ALT button also displays the action label and cooldown. Some powerful moves need a valid target in range; others target the nearest rival or the area ahead of the fighter.

ADMIN ACCESS
------------
Open the Admin page and enter: RIFTROOT
Admin gear and Admin Specials are hidden when Admin access is locked. Admin money and restricted content are intended for chaos runs.

ONLINE PLAY
-----------
The game supports private rooms for up to five players total (host plus four guests) using PeerJS and WebRTC. Internet access is required and PeerJS is loaded from its online service. This is invite-based multiplayer, not a dedicated matchmaking server. Certain networks may block direct browser-to-browser connections.

BUILDING AN APK USING ONLY AN ANDROID PHONE
------------------------------------------
1. Download rift_rumble_v7.zip.
2. Import the ZIP into a compatible HTML-to-APK builder, or use the included index.html if the builder asks for a single file.
3. Name the app RIFT//RUMBLE.
4. Enable JavaScript and internet access. Online play also needs external scripts and WebRTC/data-channel support.
5. Build the APK, download it, and install it through Android's normal installer prompt.

You can also test index.html in a mobile browser. Progress is stored locally in that device/browser.

VALIDATION NOTE
---------------
The embedded JavaScript passed a syntax check and static checks confirmed the requested bottom notices were removed and ALT descriptions are present for all weapon IDs. A live browser run and multi-device online play were not completed in the build environment; test those on your device after opening the HTML or installing the APK.
