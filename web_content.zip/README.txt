QAJOO TASFAA APP
Kun bu'uura web-app/PWA dha. Android fi iPhone irratti browser irraa hojjeta.
Akka appitti Home Screen irratti dabaluuf, appichi web hosting irratti banamuu qaba.
Odeeffannoon galfame browser/device keessa localStorage keessatti kuufama.
APK/IPA dhugaa ijaaruuf Android/iOS build environment barbaachisa.
