HALLWAY DRAMA FINAL

Features kept:
- One like per Google account/device per photo or video
- Google sign-in with account chooser
- School-code gate after Google sign-in
- West Limestone High School code: 21511
- Big GC, private conversations, photo/video feed, camera, gallery, effects, filters, comments, share, profiles, settings

IMPORTANT GOOGLE SETUP
1. Create a Firebase project.
2. Add a Web App and copy its firebaseConfig into firebase-config.js.
3. In Firebase Authentication, enable Google as a sign-in provider.
4. Add your hosted app domain to Firebase Authentication Authorized Domains.
5. Host this folder on HTTPS before using Google sign-in. Mobile Firebase docs recommend redirect-based sign-in for mobile.

This build only registers school code 21511. Other school codes must be added by the app owner/admin before they can join.
