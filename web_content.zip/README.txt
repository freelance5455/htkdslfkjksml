SoulTune — অনুভব (APK input)
This is a single-file HTML app prepared for an HTML-to-APK builder.
Suggested app name: SoulTune — অনুভব
Suggested package ID: com.soultune.anubhob
Entry file: index.html

Upload index.html directly if your builder accepts HTML files.
If it asks for a ZIP, upload the ZIP containing index.html at its root.
This is a web app wrapped in an Android WebView, not a native Android app.
