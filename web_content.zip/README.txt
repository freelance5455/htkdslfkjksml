Mahmud Arabic Learning Institute
================================

প্রধান ওয়েবসাইট ফাইল: index.html

ব্যবহার:
1. ZIP ফাইলটি Extract করুন।
2. index.html ফাইলটি Google Chrome বা অন্য আধুনিক ব্রাউজারে খুলুন।
3. ওয়েব হোস্টিংয়ে প্রকাশ করতে চাইলে index.html-কে hosting-এর public root folder-এ আপলোড করুন।

নোট:
এটি Front-end demo। ভর্তি আবেদন ও কোর্সের ডেমো তথ্য একই ব্রাউজারের local storage-এ থাকে।
নিরাপদ admin login, online database, payment gateway এবং live-class integration-এর জন্য
আলাদা backend/server configuration প্রয়োজন।
