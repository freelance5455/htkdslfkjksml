RMS MASTER KAROBAR — Android offline-first source

इसमें स्टॉक/ब्रांड जोड़ना, एडिट/डिलीट, खरीद-बिक्री, मात्रा × रेट, बिक्री पर 2% डिफॉल्ट कमीशन, ड्राइवर सूची, डिलीवरी एंट्री, रिपोर्ट और JSON बैकअप/रीस्टोर काम करते हैं। डेटा localStorage में इसी फोन/ब्राउज़र में सेव होता है।

Android पर: ZIP Extract करें, index.html खोलें। बेहतर इंस्टॉल और offline cache के लिए HTTPS hosting जरूरी है; Chrome में साइट खोलकर ⋮ > Add to Home screen चुनें।

महत्वपूर्ण: यह अभी single-device offline working build/source है, signed APK या production cloud multi-user system नहीं। Firebase Authentication/Firestore security rules/sync, conflict handling, server-side commission ledger, SMS OTP, payment gateway और अलग customer/driver login अभी जुड़े नहीं हैं। इन्हें असली Firebase/payment accounts और deployment के बाद जोड़ना होगा। बैकअप नियमित डाउनलोड करें; browser data clear न करें।
