PrintProfit V2 - versão Web para conversor ZIP para APK
============================================================

IMPORTANTE:
- O conversor mostrado pelo usuário exige um arquivo index.html na raiz do ZIP.
- Esta versão foi feita como aplicativo web responsivo para funcionar nesse tipo de conversor.
- Basta selecionar este ZIP no site/app "ZIP para APK".
- O arquivo index.html está diretamente na raiz do ZIP.
- O projeto tem menos de 5 MB.

Funcionalidades:
- Calculadora de preço de impressão 3D
- Catálogo de filamentos
- Preço médio por kg e por grama
- Temperaturas de bico e mesa
- Seleção de filamento para cálculo
- Orçamento
- Cálculo de encomenda
- Interface mobile

Os preços são valores de referência da demonstração e podem variar no mercado.
As temperaturas são faixas iniciais; confirme sempre a ficha técnica do fabricante.
