FF Arena WebView Safe Build v3

This build preserves the original external SDK loading behavior and app features. Only startup routing was changed: Home is not initially active; a startup gate waits for Firebase auth, then opens Login/Home/Admin.

HTML-to-APK: JavaScript ON, DOM Storage ON, Internet permission ON.
