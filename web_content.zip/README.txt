FLAPPY BATTLE — VERSÃO 5.0 (HTML-to-APK)

NOVIDADES:
- Loja integrada no menu principal.
- Moedas colecionáveis durante as partidas; cada moeda apanhada aumenta o saldo guardado.
- Carteira de moedas visível no menu e na loja.
- Loja de visuais: coroa, chapéu de pirata, boné de piloto e auréola.
- Equipar e trocar os visuais comprados.
- Melhorias permanentes: íman de moedas (3 níveis), escudo (uma colisão evitada por partida) e bónus de moedas (até 3 níveis).
- Melhorias e compras guardadas localmente no dispositivo.
- Moedas recolhidas na partida aparecem no ecrã de resultado.
- Animação de voo mais viva com oscilação, batimento visual e partículas.
- Personagens HD 3D baseados na arte aprovada.
- Mantém o modo individual, recordes, música, efeitos, pausa e reinício.

COMO IMPORTAR:
1. Extrair o ZIP.
2. Importar o ZIP ou a pasta no conversor HTML-to-APK.
3. O ficheiro de entrada é index.html, diretamente na raiz.
4. Manter a pasta assets ao lado de index.html.
5. Usar icon.png como ícone.
6. Ativar JavaScript, Web Audio e armazenamento local.
7. Gerar a APK.

ECONOMIA DO JOGO:
- As moedas são ganhas ao recolher as moedas douradas que aparecem entre os obstáculos.
- O saldo, os visuais desbloqueados, o visual equipado e as melhorias ficam guardados em localStorage.
- A loja é offline e não envolve pagamentos reais.

MULTIPLAYER:
O botão Bluetooth informa a limitação: HTML/WebView comum não disponibiliza por si só Bluetooth Classic entre dois telemóveis. Esta versão não implementa multiplayer Bluetooth. É necessária uma ponte/plugin Android nativo suportado pelo conversor ou uma aplicação Android nativa.

VALIDAÇÃO:
O JavaScript passou na verificação sintática Node.js. A APK ainda precisa de ser gerada no teu conversor HTML-to-APK e testada num Android real.
