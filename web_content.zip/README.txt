EDPM CARCASSONNE — PAQUET HTML → APK
======================================

IMPORTANT :
Ce paquet est destiné à un convertisseur HTML → APK qui accepte un dossier/ZIP
contenant directement www/index.html. Ce n'est PAS un projet Android Studio.

Nom : EDPM Carcassonne
Identifiant : fr.edpmcarcassonne
Orientation : portrait
Fonctionnement : hors ligne

Le fichier principal est :
www/index.html

Si le convertisseur demande le fichier d'entrée, choisir :
www/index.html

Si le convertisseur demande une URL de démarrage :
index.html

Ne pas sélectionner un fichier APK précédent.
