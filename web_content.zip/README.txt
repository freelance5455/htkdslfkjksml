# GLINK başlangıç projesi

Bu ZIP, GLINK'in kaydırmalı video akışını ve temel mesajlaşma arayüzünü içerir.

ÖNEMLİ:
- İçindeki 1000 kayıt, gerçek kullanıcı videosu değildir; başlangıç için örnek akış kayıtlarıdır.
- Mesajlar şu an cihazın localStorage alanında tutulur.
- Gerçek hesap, gerçek kullanıcılar, gerçek mesajlaşma, gerçek video yükleme, takip, yorum ve bildirimler için Firebase yapılandırması eklenmelidir.
- Firebase config bilgilerini `firebase.js` dosyasına ekleyip Authentication, Firestore ve Storage'ı bağlayacağız.

Bir sonraki aşamada:
1. Firebase Authentication
2. Firestore
3. Storage
4. Gerçek mesajlaşma
5. Gerçek video yükleme
6. Kullanıcı profilleri
7. Ayarlar + çoklu dil
8. Yönetici paneli
9. Güvenlik kuralları
