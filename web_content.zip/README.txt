POLYSTRIKE
==========

MAKING SURE PLAY ACTUALLY WORKS
This build is run through a real execution test every time: every script
actually running in a JS engine with the 3D/physics libraries stubbed
out, tapping Play for real, clicking every hero and every cheat, firing
a shot, and simulating 200 frames of gameplay -- all with zero errors.
The one thing that can't be tested from here is whether Three.js and
cannon.js can download over the internet inside your specific APK
wrapper -- see the note below if the game won't start.

WHAT'S NEW: CAMPS CAN NOW BE CAPTURED
Barracks and totems have real HP now and can be shot down, same as any
enemy. Destroy one and it stops sending reinforcements for good -- the
barracks goes dark and its flag drops, the totem's crystal goes gray and
falls dark. Any survivors from that camp keep fighting until you mop
them up, but no more reinforcements will come. The HUD now shows how
many camps are still standing out of 6 (2 military bases + 4 magic
clans), so there's a real objective: clear the map. There's also a
"Destroy All Camps" cheat if you want to skip straight to mop-up.

EVERYTHING FROM BEFORE
- 4 elemental magic clans (Fire, Storm, Nature, Shadow) whose mages fight
  rival clans, the military factions, AND you -- not just you.
- 2 military factions (barracks spawning soldiers, tanks, helicopters).
- 3 bird nests -- steal an egg and the guardian bird turns angry and
  dive-bombs you.
- A hidden shrine far south-west, past the Shadow Clan, that grants a
  huge one-time power surge (500 HP, big damage, rapid fire).
- A village with a circling dragon, a rumbling volcano, and a 50%-bigger
  world than the original build.

THE INTERNET-ACCESS CAVEAT STILL APPLIES
This build still loads Three.js/cannon.js from a CDN the first time it
runs. If this app's WebView has no network access, you'll see an
on-screen error message instead of a frozen screen -- check for an
"internet permission" setting in your APK-packaging tool if that happens.

HIDDEN CHEATS
Tap the small, faded dragon icon in the top-right corner: God Mode, Full
Heal, Rapid Fire, Kill All Enemies, Destroy All Camps, Scare Off Dragon,
and teleports to the Village, Volcano, or Aether Shrine.

STILL ON THE LIST
Weather, resource gathering, and ground wildlife/critters (birds are in,
but nothing walking around yet). Bring this back to the chat any time.
