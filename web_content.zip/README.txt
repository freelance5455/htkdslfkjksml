Accounting Software Evaluator — Web ZIP (v2, Persian + English)
ارزیاب نرم‌افزار حسابداری — نسخهٔ ۲ (فارسی + انگلیسی)

- index.html at the root of the archive (ready for website-to-app converters).
- Persian: Solar Hijri (Jalali) calendar, Persian digits, RTL layout, Friday highlighted.
- English: Gregorian calendar, LTR layout. Both show the other calendar as a secondary date.
- Live analog + digital clock, 12/24-hour toggle, time-zone picker, month navigation.
- Works offline, no external files, no network requests. Language/time-zone choice is remembered locally.
- Web app demo, not a native APK by itself.
