HZR Member Info V8.1 — A4 Print Fix

Contents: app/index.html and original HZR media/logo assets.
A4 Print Out now opens an in-app preview with automatic page breaks. Use Print / Save as PDF for Android's system print flow, or Download A4 Images to save page images to Downloads.
Security Mode profile includes the same A4 Print Out action and prints linked main data plus saved security extras, stories, diary, memories and life events.

Important limitation: an HTML-only APK cannot guarantee direct Gallery insertion. If the APK builder does not expose Android MediaStore/Print services, use Android Print > Save as PDF or open downloaded PNG files from Downloads and save them to Gallery.
