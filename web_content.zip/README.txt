SAHRUKH LOCKER - ZIP TO APK READY
================================
IMPORTANT: index.html is at the ROOT of this ZIP.

In your ZIP-to-APK app:
1. Select this ZIP.
2. It should find index.html automatically.
3. App name: SAHRUKH LOCKER.
4. Do NOT enter a website URL.
5. Enable JavaScript.
6. Enable File chooser / Storage access.
7. Enable Camera permission if the converter provides it.

The app has:
- Home
- Real folder navigation
- Photo/Gallery selection
- Camera input
- File upload
- PDF upload
- Notes can be added in later native version
- PIN lock
- Local IndexedDB item storage

IMPORTANT LIMITATION:
A ZIP-to-APK/WebView converter can only provide camera/file access if its WebView exposes those Android permissions. The package itself does not open any external website.
Default PIN: 1234
