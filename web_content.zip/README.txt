BLACKFOX-EXACT-ANDROID — ONE-TIME KEY LOGIN DEMO

Open the extracted project folder in AndroidIDE and let Gradle sync.
Build with: ./gradlew assembleDebug
APK output: app/build/outputs/apk/debug/app-debug.apk

The app demonstrates a locally generated one-time key login. It is NOT secure authentication:
keys are generated and checked on the same device. Anyone can inspect or reset the app.
For real access control, use a trusted backend that issues unique random keys, stores only
hashed keys, expires them, and marks each key consumed after successful login. Never embed
a secret master key in the APK.
