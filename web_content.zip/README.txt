JASS ❤️ PAKHI JI — OUR LOVE STORY
Offline app prototype

Included:
- index.html: mobile-friendly app with Love Story, Manali Trip, Budget, and Future Plan.
- Notes and budget are saved in browser local storage.
- Photo gallery can save small images locally in the browser.

Use:
1. Extract the ZIP on your Android phone.
2. Open index.html in Chrome.
3. Use the navigation tabs.

Important:
This is a web-app prototype, NOT an installable APK yet. It has not been tested on your specific phone. To make an APK, package this HTML in a trusted Android WebView project/build tool. It does not upload photos or notes to a server.
