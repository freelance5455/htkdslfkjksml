FF ARENA PRO - WebView Safe V4

Built from the original working HTML. The local page is no longer blocked by Firebase/EmailJS CDN loading. Startup also uses a gate so Home is not shown before authentication is known.

HTML-to-APK settings:
- Start file: index.html
- JavaScript: ON
- DOM Storage / Local Storage: ON
- Internet access: ON
- Local/File access: ON if available
- Do not rename index.html
