Dream University Web-to-APK v3

Updates:
- Different professional SVG icons for subjects and freshman courses.
- Different professional SVG icons are assigned across the department list.
- Separate modern icons for Amharic Notes and English Notes.
- Distinct Natural Science and Social Science stream icons.
- Support Center icon and support actions open the Dream University Telegram support chat: https://t.me/DreamUniversitySupport
- Previous entrance images and Freshman resource flow are preserved.
