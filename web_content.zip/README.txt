NARAYANA GAMES - Offline Number Analytics

This is an installable offline web app prototype (PWA), not a compiled Android APK.
1. Extract the ZIP.
2. Serve the folder from localhost or an HTTPS static host to enable PWA installation.
3. Open index.html in a browser for a local preview. Browser localStorage keeps records on the device.
4. Use browser menu > Add to Home Screen / Install when hosted over HTTPS.

Features:
- Jori: 00-99 count records with edit/delete
- Crossing: unique ordered two-digit combinations (view only)
- Haruf: manual A/B category labels
- Graph, leaderboard including zero-count numbers
- JSON export
- Auto-clear 24 hours after the latest entry; every new/edit/delete/tag action resets the timer
- Manual all-data clear

This app intentionally contains no wagering, stake, payout, prediction, or gambling workflow.
For a native APK, this source needs to be wrapped/built in an Android project and signed.

Offline cache: service worker included; first load/install requires HTTPS or localhost.
