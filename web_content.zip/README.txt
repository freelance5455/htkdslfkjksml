Hadi Engine Tuning v1.1.28
Offline mobile web app.

Changes:
- Removed the backup/restore section completely.
- Added invoice font controls in Settings: family, size, and weight.
- Font settings are stored locally and applied to the full-screen invoice/print view.
- Existing invoices keep their saved data; only their display/print font changes according to current settings.
