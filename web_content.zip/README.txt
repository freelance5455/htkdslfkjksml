W5 FC V2 — PACOTE INICIAL OFFLINE
=================================

O QUE VEM NESTE ZIP
- Interface W5 FC V2
- Menu, escolha de clubes e dificuldade
- Protótipo de campo 3D desenhado com Canvas (perspetiva)
- Controlos móveis básicos
- Moedas por vitória: Fácil 45, Normal 90, Difícil 135, Muito difícil 180
- Bónus de 500 moedas ao alcançar 5 vitórias consecutivas
- Abandono: derrota automática por 0-3 e sem moedas
- Guardar saldo e progresso no dispositivo
- Manifest e service worker para instalação PWA/offline

IMPORTANTE — ESTADO DO PROJETO
Este ZIP é um protótipo inicial jogável, não é ainda um jogo comercial completo.
Os jogadores são representações simples, não modelos humanos realistas. A partida
usa uma simulação básica e o relógio foi acelerado para facilitar os testes.
Ainda faltam modelos 3D humanos com animações, IA avançada, física realista,
árbitros, som, replays, licenças de clubes/jogadores e otimização final.

COMO TESTAR
1. Extrai o ZIP.
2. Abre a pasta num editor/servidor web local ou publica-a num alojamento HTTPS.
3. No Android, abre o endereço no Chrome.
4. Usa o menu do Chrome > Instalar app / Adicionar ao ecrã inicial.
5. Depois da primeira instalação e cache, a aplicação pode abrir offline.

NOTA
Um ZIP não é um APK. Para criar APK Android será necessário empacotar esta aplicação
numa ferramenta Android (por exemplo, Capacitor) e fazer a compilação.
