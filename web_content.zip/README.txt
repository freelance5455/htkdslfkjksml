SMART STUDY AI 2.0 — SOURCE PROJECT
Gujarati-medium Std 9 study web app starter.

RUN:
1. Extract the ZIP.
2. Open index.html in Chrome.
3. For Android-like install: Chrome menu > Add to Home screen (hosted HTTPS/PWA works best).

INCLUDED:
- Dark purple/blue student dashboard and SVG app icon
- Notes, Classwork, Homework starter content
- Subjects: Science, Maths, Social Science, English
- Chapter selector
- 25-question randomized quiz, 10 easy + 10 medium + 5 hard
- Automatic scoring, answer review, local report history (localStorage)

IMPORTANT AI LIMITATION:
This package works without an API key and includes offline starter study guidance and sample question pools.
It does NOT contain a hosted generative AI model. Real AI-generated chapter-specific notes/questions require a trusted server-side AI backend (for example Firebase AI Logic / Cloud Functions) configured by the app owner. Students should never be asked to paste an API key into the app. No credentials are included in this ZIP.
The sample question pool is a demo and repeats sample patterns to fill 25 questions; it is not a complete official GSEB question bank. Verify all content against the current textbook.
