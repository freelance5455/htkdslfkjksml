Vosiqova Student 2.0 — source project

Included: premium animated styling, group leader page, email-only contact, gallery avatar upload, 20 sample law quiz questions, subject-to-teacher lookup, and AI chat frontend prepared for a secure backend endpoint.

IMPORTANT AI STATUS: The AI frontend is NOT live until a backend endpoint is deployed and AI_API_URL in index.html is configured. Never put a secret AI API key in index.html. A secure backend and provider API credentials are required for real AI answers.

This ZIP is a web source project, not an APK. Open index.html in a browser for a quick preview, or import it into your APK builder. Test the new build on device before replacing your previous working app. The timetable/teacher content is sample data based on the supplied schedule and should be checked against the official timetable.
