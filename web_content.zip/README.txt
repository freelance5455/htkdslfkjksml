# Unfiltered Bot

This project was reconstructed from the three screenshots supplied in the chat.

Files:
- index.html — page structure
- style.css — styling
- script.js — chat behavior

Open `index.html` in a browser to run it.

Note: a few characters in the screenshots were obscured/blurred, so the code was cleaned into valid HTML/CSS/JavaScript while preserving the visible behavior.
