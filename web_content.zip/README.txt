Contractor Pro V4 — Detailed Functional Prototype

Improvements over V3:
- Settings cards are functional, not placeholders.
- Backup/export JSON, restore/import JSON, and delete-all-data controls.
- Reports are fully localized and report rows open their related sections.
- Language, calendar and currency persist correctly.
- Every module has its own detailed screen, add/edit/delete/search and Back button.
- 5 languages: Persian, English, Arabic, Turkish, Russian.
- Automatic calendar by language plus Persian/Gregorian/Islamic manual selection.
- Structure for HTML-to-APK: web/index.html.

Important: this is still a local prototype. Production store release needs authenticated account,
server-side entitlements/licensing, cloud sync and store billing.
