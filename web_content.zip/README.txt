MOTOLOG VAULT — ANDROID APK & ONLINE HOSTING GUIDE
==================================================

OPTION A: GET A FREE ONLINE HTTPS URL (2 MINUTES)
-------------------------------------------------
1. On your Android phone, open https://tiiny.host
2. Upload this ZIP file directly (MotoLog_Vault_APK_Package.zip).
3. Enter a short link name (e.g., motolog-apache) and sign in with Gmail.
4. Open your live https:// link in Chrome -> tap Menu (3 dots) -> "Install app"
   or "Add to Home screen" to run it full-screen like a native app!

(On PC, you can also extract this ZIP and drag the folder to https://app.netlify.com/drop)

OPTION B: CONVERT TO AN INSTALLABLE .APK FILE (3 MINUTES)
---------------------------------------------------------
1. Get your live https:// URL using Option A above.
2. Open https://webintoapp.com
3. Paste your live URL, set App Name to "MotoLog Vault", and upload icon-512.png.
4. Click "Make App" -> download the .apk file -> install on your Android phone.

WHAT IS INCLUDED IN THIS PACKAGE
--------------------------------
- index.html      : Complete offline-ready MotoLog Vault web app (all Rajkot->Mumbai
                    data, 11 Nov benchmark, Baleshwar chain lube, Garage specs,
                    multi-trip PDF/JPG export, Pro Troubleshooter, and AES-256 Vault).
- manifest.json   : Android PWA standalone app manifest.
- icon-192.png    : 192x192 app icon.
- icon-512.png    : 512x512 app icon.
