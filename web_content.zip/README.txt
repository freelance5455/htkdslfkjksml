JT WINDOW CLEANING PRO v2
Includes Home button, blank customer database, editable customer profiles, maps links, notes/photos, job calendar, analytics, and manual revenue entries for cash, checks, Venmo, cards, transfers, or other. Revenue dashboards show payments actually received. Data remains local to this browser/device in this prototype.
