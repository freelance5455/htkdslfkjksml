J.A.R.V.I.S. Offline Voice Chat — Muhammad Moiz Edition

Upload this ZIP to your Zipped Site builder. index.html is at the ZIP root.
It has a simple voice-assistant screen with a blue animated orb, chat messages,
built-in offline small-talk replies, creator answer, optional speech output,
and a microphone button.

IMPORTANT LIMITATIONS:
- Built-in replies work offline, but this is not a full language model and cannot
  answer arbitrary questions like ChatGPT without an AI model.
- Speech output uses the device/browser speech synthesis engine; install an
  offline voice on Android if available.
- Microphone speech recognition support varies by browser/device and may require
  an internet connection. The text box works as an offline alternative.
- Live weather and other current information cannot be fetched offline.
