FOREX LEARNING LAB — ANDROID INSTALLABLE PWA

Includes:
- 30 lessons with detailed Day 2 candlesticks
- Candle, trend structure, support/resistance and supply/demand diagrams
- Quizzes with instant answers
- Local lesson progress tracking
- Lot-size/risk calculator
- Signal Lab checklist (not a live data feed)
- PWA manifest, service worker and app icons

INSTALL ON ANDROID:
1. Host the files in this folder on an HTTPS static host you control.
2. Open the hosted URL in Chrome on Android.
3. Open the three-dot menu and choose Install app or Add to Home screen.
4. Launch the app from your home screen.
Opening index.html from a file manager can preview it, but install prompts and offline caching generally require HTTPS or localhost.

LIVE SIGNALS:
This build has no broker or live market-data API connection. It does not fabricate real-time buy/sell signals. A real live feed requires a legitimate provider/broker API and secure backend; never expose secret API keys in public HTML.

RISK CALCULATOR:
Enter a broker-confirmed pip value per 1.00 lot in account currency. Contract size, pip value, spreads, commissions, slippage and currency conversion vary. Results are estimates.

PROGRESS:
Stored in localStorage in the browser/device. Clearing browser data can erase progress.
