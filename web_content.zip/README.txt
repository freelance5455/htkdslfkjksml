KEN Web ZIP → APK
==================
This is a web-based KEN starter packaged as a ZIP for ZIP-to-APK services.

IMPORTANT:
- It is NOT the full native Android KEN.
- It can provide KEN's futuristic interface, text commands, browser speech recognition,
  voice replies, and permission confirmation.
- A web wrapper cannot provide Android AccessibilityService, floating overlays,
  unrestricted screen reading, or legitimate system-wide automation.

ZIP CONTENT:
index.html

Upload this ZIP to a ZIP-to-APK service that accepts HTML/web projects.
