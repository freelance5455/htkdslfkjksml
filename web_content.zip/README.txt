Saqi AI Video V2
==================
1. saqi_ai_video_v2.html کو Chrome میں کھولیں۔
2. تصویر یا ویڈیو منتخب کریں؛ اس کا preview نظر آئے گا۔
3. اردو ڈائیلاگ لکھیں۔
4. AI Video بٹن دبانے پر project validation ہوگی۔
5. اصل AI generation کے لیے backend/API درکار ہے۔

اہم: API key کو HTML/Android app میں براہ راست نہ رکھیں۔ Backend server پر رکھیں۔
