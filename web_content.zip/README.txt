AUTO SAVDO HISOBCHI — Android Studio loyiha manbalari

APK fayl hali tayyor emas: ushbu muhitda Android SDK va Gradle build muhiti mavjud emas.
APK yaratish:
1. Android Studio o‘rnating.
2. Ushbu ZIP faylni oching.
3. Android Studio -> Open -> AutoSavdoHisobchi papkasini tanlang.
4. Gradle sync tugashini kuting.
5. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
6. APK app/build/outputs/apk/debug/app-debug.apk ichida hosil bo‘ladi.

Ilova internet talab qilmaydi. Kiritilgan raqamlar asosida tushum va foydani hisoblaydi.
Eslatma: foizni avtomatik hisoblash hozircha alohida izoh sifatida ko‘rsatilgan; yuqoridagi hisob oylik to‘lovga asoslanadi.
