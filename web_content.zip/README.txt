BANIQUED HAPPY GAME

Offline browser game package. Open index.html in a modern browser.
New arcade games added:
- Tetris Blocks: move, rotate, and drop blocks to complete rows.
- Happy Car Race: steer left/right to avoid traffic.
- Number & Letter Blaster: tap the requested letter or number.

Touch controls are included for phones and tablets. Keyboard controls are also available for Tetris and Car Race.
This ZIP is a web game package, not a compiled Android APK. To install as an Android app, wrap/build the HTML project with an Android WebView/HTML-to-APK builder.
