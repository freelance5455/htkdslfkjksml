ZOYA SURPRISE WEBSITE - FINAL MUSIC VERSION

Upload these two files together to GitHub Pages:
- index.html
- meri_banogi_kya.mp3

The website is configured to use meri_banogi_kya.mp3.
On mobile browsers, audible autoplay may be blocked by the browser; the first tap on the surprise button starts the music.
