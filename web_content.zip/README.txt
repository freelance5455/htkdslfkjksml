Pixel Flappy Legend - smoother gravity edition.
Main file: index.html
