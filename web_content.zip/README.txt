PAGE PRO - ANDROID PROJECT
===========================

Ity dia Android project feno natao ho an'ny Page pro.

ZAVA-DEHIBE:
- Tsy HTML ZIP tsotra intsony.
- Ny index.html dia ao amin'ny app/src/main/assets/
- Ny MainActivity dia mampiasa WebViewAssetLoader ka tsy tokony hiverina intsony ilay
  "Page Web non disponible" vokatry ny URL assets diso.
- Mila AndroidIDE na Android Studio/Gradle build environment ianao vao manova azy ho APK.

Raha AndroidIDE:
1. Extract/unzip ity projet ity.
2. Open/Import ny dossier PagePro_Android_Complete.
3. Avelao izy haka Gradle dependencies raha angatahina.
4. Build > Assemble Debug (na Run).
5. Apetraho ilay APK vokarina.

Application:
- Anarana: Page pro
- Version: 1.0
- Package: com.pagepro.app
- French + Malagasy toggle
- Mombamomba pejy pro
- Fitehirizana local amin'ny téléphone
- Menu Ma page / Produits / Contact / À propos

Fanamarihana:
Ny version voalohany dia test local. Tsy mbola manana serveur na compte en ligne.
