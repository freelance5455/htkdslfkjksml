Mis Tarjetas - Calculadora y Cargos

Versión completa para convertir a APK.
Incluye Registros, Tarjetas, Créditos, Resumen, Calculadora, Cargos recurrentes y Respaldo.
La sección Respaldo incluye Exportar datos e Importar datos desde un archivo JSON.
