TubeMax - paquete web listo para ZIP->APK
=============================================

IMPORTANTE
----------
Este ZIP tiene index.html EN LA RAÍZ, para evitar el error:
"No se encontró index.html en ese ZIP".

Incluye:
- Buscador tipo Snaptube.
- Pegado de enlaces de YouTube.
- Carga del título, autor y miniatura mediante oEmbed.
- Lista de resultado.
- Panel de descarga con MP3/M4A y resoluciones 144p a 1080p.
- "Más formatos".
- Interfaz móvil sin publicidad.
- No copia el paquete, nombre ni firma de Snaptube.

LIMITACIÓN TÉCNICA
------------------
Una página HTML dentro de un APK/WebView no puede convertir por sí sola un
enlace de YouTube en un archivo MP3/MP4 real. Para que el botón "Descargar"
descargue el archivo de medios, hay que conectar un backend/motor de extracción
de medios. Esta versión evita fingir una descarga: muestra correctamente el
selector y abre el video original como alternativa.

Para probar:
1. Comprimí el CONTENIDO de esta carpeta (index.html + README.txt).
2. En tu convertidor ZIP->APK, seleccioná el ZIP.
3. El archivo index.html debe quedar en la raíz del ZIP.
