DELTA DEMO HTML
- Abra index.html no navegador para testar.
- Este ZIP contém uma versão web, não um APK já compilado.
- Importe index.html numa ferramenta de empacotamento HTML/WebView para Android para gerar um APK.
- Não injeta código, não modifica Roblox e não executa scripts.
