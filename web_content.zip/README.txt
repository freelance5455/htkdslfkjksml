Diesel 48L Calculator

Function:
- Enter Hour and Minutes separately.
- Enter Diesel in Litres.
- Converts Hour:Minutes to decimal Hours.
- Calculates Diesel ÷ Hours = L/Hour.
- Checks against maximum 48 L/Hour.
- Shows NOT OVER LIMIT or OVER 48 L/HOUR immediately.

Example:
79 Hours 30 Minutes + 40 L Diesel
79:30 -> 79.50 Hours
40 / 79.50 -> 0.50 L/Hour
Result: NOT OVER LIMIT

On Android:
Open index.html in Chrome. You can also host it on a simple web server and use Chrome's "Add to Home screen" to make it behave like an app.
