MY DAILY LIFE — FIRST VERSION

This is an offline-first daily task calendar prototype.

HOW TO TRY ON ANDROID
1. Extract my_daily_life_v1.zip.
2. Open index.html in Chrome.
3. Add tasks to a date, tick them when complete, and use Complete Day.
4. Calendar status and task records are saved in that browser on that device.

IMPORTANT
- This first version is a browser-based prototype, not yet a signed APK.
- It stores data locally in browser storage. Clearing browser/app data or uninstalling may erase records.
- For a true installable Android APK, this prototype can be wrapped in an Android project (for example, using Capacitor or Android Studio), then built and signed.
