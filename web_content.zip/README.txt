T-Æ_ViP — Quotex 1M Live Market Reader
=========================================
This build is a signal/market-reading tool only. It does NOT place trades.

IMPORTANT:
- The original app used Binance ticker data, not Quotex.
- Quotex's public documentation describes its own server quote stream, but does not provide a documented public WebSocket/API endpoint for this app to connect to.
- Therefore this build does NOT scrape/bypass Quotex login sessions or store Quotex credentials.
- "Authorized WebSocket Feed" accepts a WebSocket endpoint only when you have legitimate authorization to use that feed.
- Binance remains available as a public fallback and should not be treated as identical to Quotex quotes.

Activation Key: Ta007

How to use:
1. Extract the ZIP.
2. Open index.html in a modern browser.
3. Enter Ta007.
4. For public crypto data, keep "Public Crypto Feed (Binance)".
5. If you have an authorized QX-compatible WebSocket market-data endpoint, select "Authorized WebSocket Feed" and enter only that endpoint.
6. No auto-trading is included.

The signal engine uses RSI(14), EMA(9/21), EMA spread and a rule-based score. It does not guarantee profitable trades.
