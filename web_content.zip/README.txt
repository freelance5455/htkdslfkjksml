WhatsApp Ban Checker Pro - HTML version

For HTML to APK builders:
1. Extract this ZIP.
2. Select index.html as the start/home page (or upload the ZIP if your builder supports website ZIPs).
3. Keep index.html, style.css and app.js in the same folder.

Features: Dari/English, manual status records, search, delete, estimated temporary restriction end time. Data is stored in browser localStorage on the device.
Important: This app does NOT connect to WhatsApp and cannot automatically check whether a number is banned.
