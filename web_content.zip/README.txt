WarMate Android source project

Isi:
- Aplikasi Android WebView dengan halaman WarMate lokal.
- Countdown yang bisa diatur.
- Daftar produk dan harga normal/target.
- Checklist persiapan checkout.
- Penyimpanan data di perangkat (localStorage).
- Link Shopee pendek id.shp.ee diterima.
- Link shopeeid:// dengan navigate_url diarahkan ke URL HTTPS melalui aplikasi/browser eksternal.

Build:
1. Buka project ini di Android Studio atau unggah ke layanan build Android yang mendukung project Gradle.
2. Build app > assembleDebug.
3. APK debug akan berada di app/build/outputs/apk/debug/app-debug.apk.

Catatan:
- ZIP ini adalah source project Android, bukan file APK yang sudah dikompilasi.
- Countdown hanya pengingat waktu. Aplikasi tidak menjamin stok, harga flash sale, atau keberhasilan checkout.
