ANTRO EDU - Versi awal
Cara mencoba:
1. Buka index.html di browser.
2. Untuk menjadikannya situs, unggah folder ini ke layanan hosting statis.
3. Untuk menjadi APK, project web ini dapat dibungkus dengan WebView/Capacitor pada tahap berikutnya.

Fitur:
- Beranda
- Materi kuliah
- Jurnal/referensi
- Kamus antropologi
- Antropologi Indonesia
- Latihan soal
- Favorit (tersimpan di perangkat)
- Pencarian
