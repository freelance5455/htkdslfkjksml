MANI PROJECTS — Mobile App Stage

This package is the mobile/PWA stage of the app.

How to test on Android:
1. Extract the ZIP.
2. Open index.html in a browser, or host the folder from a local/web server.
3. On a supported browser, use the Install button / browser menu → Add to Home screen.
4. It opens in a standalone app-like window.

Current stage:
- Mobile-first interface
- Installable PWA structure
- Offline shell caching
- Local project data storage
- Save-anytime / edit-later workflow
- Engineering project, BOM, calculations, manufacturing, master data, reverse engineering, photo collection and field trials

Important:
This is a prototype mobile web app, not yet a signed native Android APK. Data is local to the browser/device at this stage; use Backup regularly.
