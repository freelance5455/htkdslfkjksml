Abdullah's Classroom — FINAL OFFLINE APP PACKAGE

This package contains the complete offline-ready HTML.

IMPORTANT:
- Build the APK by bundling these local files into the APK. Do NOT use the live website URL.
- The app data and PDF Library use local browser storage/IndexedDB.
- PDF files added inside the app are stored locally; the APK shell must support IndexedDB and blob/PDF downloads.
- For Android APK building, use a builder that explicitly enables Offline/Bundled files, JavaScript, LocalStorage/IndexedDB and a PDF/blob download manager.
- Live admission/news synchronization necessarily needs Internet. Previously stored/local admission data remains available offline.
