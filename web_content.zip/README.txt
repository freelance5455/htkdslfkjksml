GEOLINIX WEBAPK PACKAGE v0.6.0
================================
This package is a self-contained HTML/CSS/JavaScript preview for a WebView/HTML-to-APK builder.

ENTRY FILES
- index.html (root entry)
- web/index.html (entry path expected by some HTML-to-APK builders)
- web/assets/geolinix-icon.png (512 x 512 app icon)
- web/manifest.webmanifest

No remote JavaScript libraries, external fonts, CDN resources, or network requests are required to display the preview.
Local demo notes/profile/business draft use browser localStorage when supported.

IMPORTANT
This is a front-end preview, not the complete production GEOLINIX service.
Live authentication, cloud accounts/sync, GEO AI, live maps/location search, messaging,
notifications, payment processing, subscriptions, and team administration are not connected.
Do not describe this package as a production-ready app or as a Play Store release.
