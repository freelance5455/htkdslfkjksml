GARDEN 3D OFFLINE - bản đơn giản nhất
1. Giải nén.
2. Mở index.html bằng Chrome trên Android.
3. Không cần Internet/server.
4. Game tự lưu trên trình duyệt.
Chạm vào ô đất để trồng/tưới/thu hoạch. Nút Shop để mua hạt và bình tưới.
