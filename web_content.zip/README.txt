Auto Call Helper Web App
========================
This ZIP is intended for a website-to-APK wrapper that requires index.html at the ZIP root.

How to use:
1. Upload this ZIP to your ZIP-to-APK app/site.
2. The app wrapper should detect index.html.
3. The app opens the phone dialer via tel: links; the user must confirm each call.
4. Web apps cannot silently place repeated calls. For full Android functionality, build a native Android app with required permissions and user controls.
