SkyHop v1.7.1 — Palm Sunset Theme

Files: index.html and update.json. Upload both files to the root of your Netlify site.

The free Sky Blue theme has been replaced with Palm Sunset using the provided palm-tree sunset image. Other themes remain available.

APK updates are not automatic; a real hosted APK URL and matching signing key/package name are required.
