# Spend Elon's Money — Android-friendly prototype

Open `index.html` in a mobile browser to play.

Game rules:
- Starts at a fictional $100 Billion balance.
- Buy/Sell items.
- Spend the entire balance to complete a round.
- Every 10 completed rounds, the starting balance increases by 10x (100B -> 1T -> 10T ...).
- Progress is saved with localStorage.

Next step for an Android APK:
Wrap this web game in an Android WebView/Capacitor project and build a release APK.
