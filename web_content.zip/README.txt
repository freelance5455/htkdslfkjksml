SIMPLE OFFLINE LOGIN SYSTEM
===========================

Features
- Admin and User login/logout
- Admin can create additional User accounts
- IndexedDB works as a local browser database
- localStorage keeps the current login session
- PWA service worker caches files for offline use after the first load

Demo accounts
Admin: admin / admin123
User:  user / user123

How to run
Recommended:
1. Extract the ZIP.
2. Open a terminal/command prompt in this folder.
3. Run: python -m http.server 8000
4. Visit: http://localhost:8000

You may open index.html directly for basic use, but offline caching/PWA service worker
requires localhost or HTTPS and a first successful load.

IMPORTANT SECURITY NOTE
This is a local/offline demonstration, not a secure production login system.
Passwords are stored in the browser's IndexedDB in readable form. Anyone with access
to this browser profile can inspect or change local data. There is no shared server
database, no cross-device synchronization, and no real server-side access control.
For a real website with secure Admin/User permissions, use a backend such as PHP +
MySQL and hash passwords on the server. Browser storage is not a replacement for that.
