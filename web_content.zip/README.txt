MERI BEGUM — BIRTHDAY WEBSITE

How to preview:
1. Open index.html in a browser.
2. The audio controls play the included M4A voice recordings.

How to publish:
1. Upload this ZIP to your static website host (for example, Tiiny.host).
2. Keep index.html and the audio folder together.

Included:
- index.html
- audio/ (5 unique compressed recordings used by 7 voice-note cards)

The last two voice-note cards were removed as requested. Duplicate recordings
were consolidated, and the remaining speech audio was compressed for a smaller upload.
