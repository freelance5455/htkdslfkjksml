SKstoremanager — Android APK build on your phone

This ZIP contains the mobile-friendly store manager website as index.html.

To create an APK without a computer:
1. Open https://www.ziptoapk.com/ in your phone's browser.
2. Choose the ZIP-to-APK builder and upload this ZIP file.
3. Set the app name to SKstoremanager.
4. Choose an icon if the service offers that option.
5. Build and download the APK, then follow Android's prompts to install it.

Important:
- This is a browser-based store manager packaged in an Android WebView, not a fully native app.
- Business records are stored locally on this device/app. They do not sync to the cloud.
- Use the app's Backup all data feature regularly and keep the JSON backup somewhere safe.
- Review the builder's privacy, permissions, and pricing before uploading source files.
