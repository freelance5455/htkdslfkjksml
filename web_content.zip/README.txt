FITPIYU WORKOUT APP
====================
Put index.html into your HTML-to-APK converter.

Features:
- Modern mobile workout dashboard
- Home / Workouts / Exercises / Progress / Profile
- Create custom workouts
- Add and remove custom exercises
- Search/filter exercises
- Track sets and reps
- 30/60/90 second rest timer
- Workout history
- Streak and weekly progress
- Editable name
- Offline/local storage
- No external libraries required

Converter:
- Start/entry page: index.html
- Enable JavaScript
- Enable Local Storage / DOM Storage
- Portrait orientation recommended
