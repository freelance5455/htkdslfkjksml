ZIP contents:
- index.html: the app's main page

To use:
1. If your HTML-to-APK tool accepts ZIP files, upload this ZIP.
2. Set the start page/main file to index.html if asked.
3. If it accepts only HTML files, extract the ZIP and select index.html.
4. If the APK displays Webpage not available, the converter may not bundle the HTML correctly; use its local HTML/file option and ensure index.html is the start page.

This app only displays/copies text and opens an email draft. It does not automatically send reports. Check all claims are true before sending.
