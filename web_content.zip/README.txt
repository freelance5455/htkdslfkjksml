KLING BTP — CALCULATEUR PRO
============================

Version HTML autonome destinée à servir de base pour conversion en APK.

Fonctions incluses:
- Béton: volume, ciment, sacs, sable, gravier, eau
- Ferraillage: longueur, nombre, poids
- Poteaux, poutres, dalles, semelles
- Fondations: fouilles, propreté, béton armé, remblai
- Maçonnerie et mortier
- Enduit
- Peinture
- Terrassement
- Conversion m³ / tonnes / kg
- Transport et nombre de voyages
- Récapitulatif
- Devis avec prix unitaires
- Sauvegarde locale
- Impression / enregistrement PDF via la fonction d'impression du téléphone
- Export CSV compatible Excel

IMPORTANT:
Les calculs de dimensionnement et de ferraillage sont indicatifs. Ils doivent être vérifiés et validés par l'ingénieur responsable selon les charges, le sol et la norme applicable.

UTILISATION:
1. Ouvrir index.html dans un navigateur.
2. Choisir un module.
3. Remplir les dimensions.
4. Cliquer sur Calculer.
5. Cliquer sur Ajouter au projet.
6. Ouvrir Récapitulatif puis Devis.
7. Pour un PDF, utiliser Imprimer / PDF puis choisir "Enregistrer en PDF" sur Android.
