Build the APK (no Android Studio needed)
1. Create a free GitHub account and a new empty repository.
2. Upload everything from this folder, including the hidden .github folder (easiest from a computer).
3. Open the repo's Actions tab, run "Build APK" (it also runs on every upload).
4. When it finishes (about 5 minutes), open the run and download the artifact "UPES-SpaceBasic-apk".
5. Unzip it, send app-debug.apk to your phone and install it (allow "install unknown apps").
The app needs internet for the fonts and the QR code.
