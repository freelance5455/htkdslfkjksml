WahidMedX FINAL PREMIUM

India-focused medicine reference app.

Features:
- Exact brand/API/formulation search
- Single-ingredient searches do not mix FDC combinations
- Same-formulation alternative brands
- Established-company and individual-brand popularity ranking
- Offline local catalogue after download
- Live internet discovery mode
- Hindi/English voice search
- Premium medical UI

Important: the catalogue is downloaded from the bundled public Indian medicine dataset when the user taps Download full India catalogue. Live web mode uses broad web discovery and falls back to a normal web search if in-app rendering is unavailable.
