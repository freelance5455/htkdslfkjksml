MasterFlow Trading v12 — IDX Edge PRO via HTTPS proxy

ZIP ini khusus untuk SoftSpring HTML & ZIP File to APK Builder.
Isi ZIP harus memiliki index.html di root.

Setelah APK dibuat:
1. Buka API/Pengaturan.
2. Isi API Key IDX Edge PRO.
3. Isi URL Proxy IDX PRO (Cloudflare Worker yang Anda deploy sendiri).
4. Simpan.
5. Pilih BBCA/BBRI/dll dan tekan ANALISIS.

US tetap memakai Twelve Data.
IDX hanya memakai IDX Edge PRO melalui proxy.
