SHOURYA HACKRR Android project
Login: shourya
Password: hackrr
Instagram label: @flexxy._.oo1

This is a WebView wrapper for the local HTML interface. The AIMBOT/ESP/AIM LINE/etc.
switches are visual mock controls only and do not modify Free Fire or provide cheats.

Build APK:
1. Open this folder as a project in AndroidIDE (or Android Studio).
2. Allow Gradle sync/downloads.
3. Choose Build > Build APK(s).
4. Debug APK is usually at app/build/outputs/apk/debug/app-debug.apk.
