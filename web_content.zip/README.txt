EQUAROOM - APKFORGE HTML PACKAGE

HOW TO USE
1. Extract EquaRoom_APKForge.zip.
2. In APKForge, choose the option to build an app from a website/HTML or upload local HTML files.
3. Use index.html as the start page / entry file.
4. Enable JavaScript and DOM storage/local storage in WebView settings if available.
5. Grant camera and microphone permissions if you want to test the EquaMeet camera preview.

IMPORTANT LIMITATIONS
- This is a standalone HTML version. Accounts, classroom records, posts, assignments, and submissions are stored locally on the same device using localStorage.
- A student on another phone cannot join a teacher's class with the code because there is no shared online backend in this package.
- EquaMeet currently offers a local camera/microphone preview and controls. Real calls between different devices need an online signaling server and a TURN/SFU media server. Do not advertise cross-device video calling as functional until that backend is connected.
- Do not use real sensitive student data in this demo.
