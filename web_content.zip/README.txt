ORKUT MODERNO — PACOTE WEB

Conteúdo:
- index.html: tela principal do aplicativo
- style.css: aparência e layout responsivo
- app.js: navegação e interações demonstrativas
- manifest.json: metadados do aplicativo web

IMPORTAÇÃO:
1. Extraia este ZIP, se a plataforma exigir.
2. No APKForge, procure a opção de importar/enviar um projeto ou arquivo ZIP.
3. Se pedir a página inicial, selecione index.html.
4. Gere uma prévia e teste em um celular.

IMPORTANTE:
Esta é uma primeira versão visual local. As publicações, curtidas, comunidades e alterações de perfil ainda não são sincronizadas com uma conta nem salvas em um servidor. O PocketBase será conectado em uma etapa posterior.
O pacote não contém logotipo ou conteúdo oficial do antigo Orkut.
