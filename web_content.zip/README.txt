AL-TAQWA SUPER ADMIN DASHBOARD
===============================

Files:
- index.html
- style.css
- app.js

How to use:
1. Extract the ZIP.
2. Open index.html in a browser.
3. The dashboard is a front-end UI prototype.
4. The charts use Chart.js from a CDN, so charts require internet access.

Next development stage:
- Connect login/authentication.
- Replace demo statistics with an online database.
- Add Students, Teachers, Classes, Attendance, Exams, Fees and Users CRUD.
- Add role-based permissions for Super Admin, Teacher and Student.
