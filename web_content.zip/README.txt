Contractor Pro V14 — Team + Client Portal

Based directly on the verified V13 Subscription & License build.
Adds offline-first team access profiles and client portal access configuration/preview.
Live multi-user portal and server-side authorization require the Contractor Pro backend; this APK-ready build does not fake online services.
Root index.html is provided for HTML-to-APK converters that require index.html at the package root.
