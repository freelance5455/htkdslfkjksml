SIMPLES FOOTBALL - versão HTML

Abra index.html no navegador do celular ou hospede a pasta em um site estático.
Esta versão é um protótipo local; contas online e marketplace entre pessoas reais ainda precisam de servidor e banco de dados.
