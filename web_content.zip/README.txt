LAMILINK Android app
====================
Easiest (phone or PC, no Android Studio):
1. Make a free GitHub account, create a new repository, upload ALL files from this folder
   (keep the .github folder).
2. Open the repo > Actions tab > "Build APK" > wait ~4 minutes.
3. Open the finished run > Artifacts > download LAMILINK-apk (zip) > unzip > app-debug.apk.
4. Open the APK on your phone and allow "Install unknown apps" when asked.

Android Studio: File > Open this folder > Build > Build APK(s).

Downloads are saved to Downloads/LAMILINK. Copy a direct file link, open LAMILINK, tap the logo.
