GX Web Studio — REPAIRED PREVIEW

Open index.html in a modern browser or upload this ZIP to a static-site preview host.
Features: import ZIP/HTML, inspect files, edit text files, preview index.html, export ZIP.
ZIP support uses the bundled JSZip library.
Limitations: browser-based preview only; not a native Android app and cannot run Gradle/Android SDK or build an APK.
Relative local assets are rewritten to blob URLs for basic preview. Some advanced routing, service workers, server APIs, module paths, and complex CSS assets may need a local server.
