SHOP BILLING APP — HTML ZIP
Open index.html in Chrome on Android or a desktop browser.
This is an offline-first HTML prototype. Products, bills and shop details are stored in browser localStorage on the device.
Features: product/stock list, bill builder, GST, discount, payment type, invoice print dialog, sales history, local JSON export/import.
Important: Drive upload is shown as optional but requires Google OAuth/API configuration; this standalone ZIP does not upload to Drive yet. You can print/save the invoice as PDF and upload it manually to Drive > Shop Backup.
For dependable business use, package this as an Android app with a native local database and test invoice/tax settings before issuing official bills.
