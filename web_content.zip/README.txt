45 AR Leave Management System - HTML to APK package

This ZIP includes the same HTML at both locations:
- index.html (ZIP root)
- web/index.html

This is intended to accommodate builders that expect either location.
Upload this ZIP to your HTML-to-APK builder and rebuild the APK.

Important:
- This ZIP is not an APK.
- The HTML stores records and login session in browser localStorage.
- Clearing app data or uninstalling may erase locally stored records. Export JSON backups regularly.
- The page contains demo credentials in the HTML. Do not use real personnel or sensitive operational data until proper authentication, access controls, and approved secure storage are implemented and authorized.
