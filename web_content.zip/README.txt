TGJ Launcher — Wood & Glass HTML Edition

HOW TO RUN
1. Download and extract this ZIP.
2. Open index.html in Chrome, Edge, Firefox or another modern browser.
3. On Android, open index.html from your file manager and choose Chrome.
4. For a home-screen shortcut, use Chrome menu > Add to Home screen (browser shortcut only).

FEATURES
- iOS-inspired glass panels and colorful glossy 3D icon styling
- Layered outdoor-inspired background, light beams, haze/smoke and floating orb
- Wood-grain physical shelf with horizontal swipe/drag scrolling
- App library search and category filters
- Hover/tap icon lift and press animations
- Live clock/date, quick tool interactions and theme tint toggle
- Responsive layout for desktop and phone

IMPORTANT
This is a standalone interactive HTML UI concept / browser launcher simulation.
It does not replace Android's system launcher, cannot enumerate or launch installed
Android apps from a normal browser page, and does not control Wi-Fi, torch, battery,
or other system settings. Those require a native Android application and OS permissions.
No internet connection or external libraries are required.
