AS Enterprises V17 FINAL

Fixes:
- Save/Edit code paths preserved and syntax checked.
- Main stock sales now require/select a stock batch when matching stock exists, so sale quantity is deducted from the selected stock batch instead of being ambiguously deducted across all rates.
- Own Purchase/Sale now tracks aggregate purchased/sold/remaining quantity by Item + Brand and blocks own sale above remaining own stock.
- Separate Wastage In/Out remains independent from Sales; its rate affects Own Profit only.
- Labour wastage remains separate.
- Loan Paid and Own Purchase Paid remain deductions in Daily Hisaab/Final Benefit as requested.
- Existing localStorage key AS_ENTERPRISES_V3 is preserved; no clear/reset migration is included.
- Phone/Gmail fields remain profile-only; real cloud authentication/sync requires backend setup.
