MI ORGANIZADOR — paquete Web/PWA listo para convertir a APK.

IMPORTANTE: index.html está en la raíz del ZIP.

Este paquete está pensado para servicios que aceptan HTML/ZIP y lo envuelven en una app Android. Ejemplo: HTMLtoAPK.

No es todavía un APK nativo. La conversión final la hace el servicio de compilación.
