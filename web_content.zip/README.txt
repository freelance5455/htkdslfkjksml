FACILITIES MANAGEMENT — VERSION INSTALLABLE (PWA)

CONTENU
- index.html : application en français
- manifest.webmanifest, icon.svg, sw.js : installation sur écran d’accueil et cache de base

TEST LOCAL
Ouvrir index.html dans Chrome pour tester. L'installation PWA nécessite toutefois un hébergement HTTPS (ex. Netlify).

MISE EN LIGNE GRATUITE (NETLIFY DROP)
1. Décompresser le ZIP sur un ordinateur. Le dossier envoyé doit contenir directement index.html, manifest.webmanifest, icon.svg et sw.js.
2. Aller sur https://app.netlify.com/drop et se connecter / créer un compte gratuit.
3. Glisser-déposer le dossier du site décompressé sur la page Netlify Drop.
4. Ouvrir l'adresse HTTPS créée par Netlify sur Android avec Chrome.
5. Menu ⋮ > Installer l'application ou Ajouter à l'écran d'accueil. Le libellé dépend de Chrome.

LIMITES IMPORTANTES
Ceci reste une démonstration locale : les données sont conservées dans le navigateur de chaque appareil, pas partagées entre techniciens. Pas de véritable connexion, rôles ou base de données distante. Ne pas utiliser pour des données professionnelles confidentielles.

POUR UNE VERSION MULTI-UTILISATEUR
Il faudra connecter une base distante (par exemple Supabase), mettre en place l'authentification, les rôles et les politiques de sécurité RLS, puis tester les autorisations avant usage réel. Ne jamais exposer la clé service_role dans le navigateur.
