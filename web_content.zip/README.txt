SIRI AI ANDROID - GOI APKFORGE
================================

Cau truc:
- index.html (nam ngay thu muc goc ZIP)

Cach dung:
1. Mo APKForge.
2. Chon upload/import ZIP project.
3. Chon file Siri_AI_Android_APKForge.zip.
4. Dat ten app: Siri AI.
5. Build APK, cai dat va mo app.
6. Bam nut bat va cho phep Microphone neu APKForge/WebView hien hop thoai.

CHUC NANG TRONG BAN NAY
- Giao dien Siri/Dynamic Island nho gon.
- Hieu ung thanh am thanh va qua cau khi nghe/xu ly.
- Nhan dang giong noi tieng Viet bang Web Speech API neu WebView ho tro.
- Tu khoa danh thuc: "Nay, ..."
- Lenh mo mot so app co package ID da khai bao (Free Fire, TikTok, YouTube, Facebook, Zalo, Chrome, Roblox, Maps, Gmail).
- Lenh tim kiem Google, xem gio va ngay.

GIOI HAN QUAN TRONG
- Day la ung dung HTML/WebView, KHONG phai tro ly Android native co quyen he thong.
- Khong the lang nghe lien tuc khi app o nen/da dong; khong the hien Dynamic Island noi tren moi app neu APKForge khong co tinh nang overlay native.
- Mot so WebView khong ho tro Web Speech API hoac intent://; khi do nhan dang/mo app co the khong hoat dong.
- Trang web khong the tu doc danh sach app da cai dat. Muon mo ung dung bat ky can native Android package manager va dich vu Android tuong ung.
- Khong the thuc hien moi yeu cau, thao tac trong game, gui tin nhan hay thay doi cai dat bao mat mot cach tuy y. Cac hanh dong nhay cam can xac nhan va quyen he thong.
- Nhan dang giong noi co the can Internet va phu thuoc dich vu tren thiet bi.

Neu APKForge chi dong goi HTML vao WebView, cac gioi han tren van ton tai; khong co cach them quyen micro/overlay nen chi bang HTML.
