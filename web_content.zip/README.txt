REMINDER MESSENGER — FIRST PROTOTYPE

Files:
- index.html: app interface and reminder logic
- manifest.json: installable-web-app metadata

What works:
- Add one-time, daily, and weekly reminders
- Save reminders in browser storage on this device
- Bot-style in-app chat
- Done, snooze 10 minutes, cancel
- Request browser notification permission
- Export a JSON backup

Important limitations:
- Reminder checks run only while the page is open. This prototype cannot guarantee background notifications after the browser is fully closed.
- To install like an app, host these files on an HTTPS static host and use Chrome > Add to Home screen.
- No external messages, WhatsApp, server, or paid API is included.
- Reliable background reminders require a proper Android app/native scheduling or a suitable push/scheduler setup.
