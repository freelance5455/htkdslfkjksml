Market TJ — package contents

index.html: Your supplied Market TJ app.

Already included in the HTML:
- Product photo upload (image/*, up to 5 MB)
- Upload to Supabase Storage bucket: market-images
- Display product image in listing and details
- Seller phone number and "Позвонить продавцу" tel: link

Important:
For these features to work online, the Supabase project must have the required table, storage bucket, and access policies configured.
