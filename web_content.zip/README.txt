Alfaz-e-Dil ❤️
3000 original, varied poetry entries across 15 categories.
Each entry uses varied sentence structures and category-specific vocabulary.
Features: search, categories, favorites, remove favorite, random, share.
