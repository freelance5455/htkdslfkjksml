Build the APK (needs no coding):
1) Make a free account on github.com, create a new repository, upload ALL files of this folder (keep the .github folder).
2) Open the "Actions" tab -> "Build APK" -> wait ~5 min until green.
3) Open the finished run -> Artifacts -> butcher-apk -> download, unzip, install app-debug.apk on the phone.
Or open this folder in Android Studio -> Build -> Build APK.
