MI ORGANIZADOR — MASTER UNICO FINAL

Paquete autocontenido. index.html está en la raíz para conversores que requieren index.html en root.

Incluye la base completa de MI ORGANIZADOR: proyectos, carpetas/subcarpetas, tareas, calendario, notas, ideas,
archivos, fotos, cámara, clasificación automática por información disponible, confirmación de destino,
búsqueda, favoritos, papelera, compartir mediante el menú nativo cuando el entorno lo permite,
notificaciones/recordatorios cuando Android/WebView expone la API, almacenamiento local y backup/restauración.

Regla de actualización: cada futuro ZIP debe conservar este proyecto completo y agregar solamente correcciones
nuevas o funciones nuevas; nunca eliminar funcionalidades existentes que ya funcionen.
