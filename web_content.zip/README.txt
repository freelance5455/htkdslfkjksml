Geld Klicker Web App V3

Neue Funktionen:
- Mehrere Upgrade-Arten: Klick-Power, Auto-Einkommen und Bonus.
- Auto-Einkommen gibt jede Sekunde Geld, auch wenn nichts geklickt wird.
- Level benötigen eine steigende XP-Menge und dauern dadurch länger.
- Klicks und Bonus geben XP.
- Level-Up gibt einen kleinen Geldbonus.
