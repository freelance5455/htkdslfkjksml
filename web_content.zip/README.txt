Child Health Clinic – AppForge PDF fix v2

This version avoids the unreliable WebView data/blob download links.

PDF method:
1. Tap “Save PDF / Print”.
2. Android/AppForge print dialog should open.
3. Select “Save as PDF”.
4. Choose the destination (usually Downloads) and save.

There is also “Share PDF”, which uses the Android Web Share facility when the AppForge build supports sharing PDF files.

Import index.html into ApkForge/AppForge and rebuild the project.
