# Offline AI Assistant — APK Builder Version

This folder is intentionally a simple static web app:
- index.html is at the ZIP root.
- No React, TypeScript, Vite, npm, Tailwind, or external libraries are required.
- No internet connection is required for the included features.
- Local memory uses browser/device localStorage.
- Text documents can be imported locally.
- Calculator, study prompts, floating assistant, and text-to-speech are included when the Android WebView exposes them.

Use the contents of this folder as the ZIP uploaded to an HTML-to-APK builder.
Do not put this folder itself around the files inside the ZIP; index.html must be at the ZIP root.
