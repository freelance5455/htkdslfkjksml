MACACOPOLIS - VERSAO COM COPA FACIL

Novo botao: Copa Facil. Ao tocar, abre https://copafacil.com.br/
Demais arquivos e funcoes foram mantidos da versao original extraida do APK.
