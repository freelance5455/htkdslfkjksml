TradeLog PWA
============

Ini adalah versi PWA (Progressive Web App) dari TradeLog.

Penting:
- PWA harus dibuka dari alamat HTTPS/localhost agar fitur install + offline aktif.
- Jika hanya dibuka sebagai file .html (file://), browser dapat tetap memperlakukannya sebagai halaman web biasa.
- Setelah dipasang sebagai PWA, tampilannya menjadi mode aplikasi (standalone) tanpa address bar.

Cara termudah:
1. Upload isi folder ini ke hosting HTTPS sederhana.
2. Buka URL-nya di Chrome Android.
3. Pilih menu ⋮ -> Install app / Tambahkan ke layar utama.
4. Jalankan dari ikon TradeLog.

Data jurnal tersimpan di penyimpanan browser perangkat. Gunakan Export secara berkala sebagai backup.
