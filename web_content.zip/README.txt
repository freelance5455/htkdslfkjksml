GM PAY — VERSION INTERNATIONALE
=================================

Cette archive contient une base d'application internationale.

1. Ouvrir index.html dans un hébergement HTTPS/WebIntoApp.
2. Remplacer dans index.html:
   - REMPLACER_PAR_TA_CLE_FIREBASE
   - REMPLACER_PAR_TON_APP_ID
   par les valeurs exactes de Firebase.
3. Activer Email/Password dans Firebase Authentication.
4. Créer Firestore Database.
5. Publier les règles présentes dans firestore.rules.

IMPORTANT:
Cette version constitue l'interface et la base Firebase. Elle ne doit pas être présentée comme une banque ou un service de paiement mondial opérationnel.
Pour les paiements réels, il faut connecter un backend sécurisé et des prestataires agréés par pays (Mobile Money, cartes, virements, etc.), gérer KYC/AML, limites, conversion de devises, remboursements et conformité locale.

Les transferts inter-devises sont volontairement bloqués côté client tant qu'un moteur de change/backend sécurisé n'est pas connecté.
