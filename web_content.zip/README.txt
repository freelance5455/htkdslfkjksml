TURBO//HACK ULTRA V6 IDEAL
=============================

Pacote para conversor HTML/site -> APK.

Conteúdo:
- index.html na raiz
- sem CDN, sem bibliotecas externas e sem chamadas de rede obrigatórias
- interface hacker/terminal
- Game Center e perfis para Free Fire
- perfis 1/2/3/4/6 GB+
- CPU/GPU/RAM diagnostics
- FPS, touch, display, escala visual
- rede e bateria
- benchmark, frames, storage
- console de comandos
- limpeza somente local/sessão
- logs e perfis

COMANDOS:
help
scan
turbo on
cpu scan
gpu scan
ram scan
game freefire
fps 60 / 90 / 120
stretch 90..115
background scan
network scan
battery scan
benchmark

LIMITAÇÕES:
A versão WebView não recebe automaticamente privilégios para overclock,
alterar governor CPU/GPU, matar outros aplicativos, limpar cache de terceiros
ou alterar diretamente arquivos do Free Fire. Essas ações exigem Android nativo
e permissões específicas. A escala "stretch" desta versão atua na interface do
aplicativo; não promete alterar a resolução física do sistema/jogo.
