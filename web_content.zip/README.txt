Abdullah's Classroom - APK READY BUNDLE

Entry file: index.html

Upload this ZIP to a ZIP/HTML-to-APK builder that bundles local files into the APK.
App name: Abdullah's Classroom
Suggested package name: com.abdullah.classroom
Version: 1.0.0

IMPORTANT: choose ZIP/local HTML bundling, NOT a live website URL, for offline use.
