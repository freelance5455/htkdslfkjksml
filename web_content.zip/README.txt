# Interactive Buddy Pack

A small, customizable desktop/web buddy starter pack.

## Included
- `index.html` — main buddy interface
- `style.css` — buddy UI and overlay styling
- `app.js` — interactions, rename system, old-school text emoticons, TTS, and microphone-reactive meter
- `overlay.html` — OBS/browser-source-friendly transparent overlay page
- `README.txt` — this guide

## Run it
1. Open `index.html` in a modern browser.
2. Rename the buddy in the Name field.
3. Use Say It for text-to-speech.
4. Enable the mic to make the buddy react to microphone volume.
5. Toggle Overlay for a minimal transparent-style buddy view.

## OBS overlay
Use `overlay.html` as a Browser Source after hosting/opening it through a local web server. A simple option is VS Code Live Server or Python's local HTTP server.

Example:
`python -m http.server 8000`

Then use:
`http://localhost:8000/overlay.html`

The browser may require microphone permission. TTS support depends on the browser/OS speech engine.

## Customizing
Change the default name in `index.html`, edit the emoticon list in `app.js`, or change the appearance in `style.css`.

This pack intentionally uses text emoticons such as :) :D ;) XD ^_^ instead of standard Unicode emoji.
