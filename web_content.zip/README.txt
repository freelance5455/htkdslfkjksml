Asalxon va Go‘zalxon sayohati — rasmsiz APK uchun tayyor loyiha.
50 ta qo‘shish/ayirish topshirig‘i. Barcha sonlar 50 dan kichik.
Keyinchalik har bir topshiriqqa mos surat/sahna qo‘shish mumkin.
