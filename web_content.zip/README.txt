CAT'S WAY HOME — 10 LEVELS — MORE BUGS

Each level now has more bugs:
3, 4, 5, 6, 7, 8, 9, 10, 12, and 14 bugs.

Controls:
- Phone/tablet: hold the on-screen arrows.
- Computer: Arrow Keys or WASD.

Reach the owner while avoiding bugs. You have 3 hearts.
