Los Santos Lite - open index.html in Chrome/Safari (internet needed once for the 3D libraries).
The game opens in landscape automatically (rotates itself if the phone is held upright).
Pause button = settings (controls / graphics / accessibility / audio) and layout editor.
