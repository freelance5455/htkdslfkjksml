ChatGPT Camera - Zipped Site package
Upload this ZIP to Zipped Site. index.html is at the archive root.
This is a browser-based camera demo. It cannot guarantee background/screen-off recording; use a native Android app for that feature.
