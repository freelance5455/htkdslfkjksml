Lio Universe Android project

هذا مشروع Android Studio يغلّف واجهة المتجر في تطبيق Android WebView.
لإنشاء APK:
1. نزّل وثبّت Android Studio على كمبيوتر.
2. افتح مجلد المشروع Lio_Universe_Android_Project.
3. وافق على مزامنة Gradle وتنزيل Android SDK المطلوب.
4. اختر Build > Build APK(s).
5. ستجد APK في app/build/outputs/apk/debug/app-debug.apk.

ملاحظة: هذه نسخة واجهة تجريبية؛ لا يوجد دفع إلكتروني حقيقي أو اتصال بخادم أو لوحة إدارة.
