Kissan Zameen Khata Web App starter
Open index.html in a browser to test. It saves data in browser localStorage on that device.
Important: this folder is NOT hosted online, and online cloud backup is NOT configured. Use Export Backup regularly.
To install as a home-screen app/PWA, host these files on an HTTPS website, then use Chrome menu > Add to Home screen / Install app.
