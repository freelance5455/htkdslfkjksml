NEON ESCAPE: OVERDRIVE (v2 — Full Progressive Difficulty & Audio Edition)
Upload-Ready HTML5 Game Package

WHAT WAS ADDED & UPGRADED
1. 5-Stage Progressive Difficulty Curve (EASY -> NORMAL -> HARD -> EXPERT -> OVERDRIVE):
   - Starts at a relaxed speed (BASE_SPEED = 4.2 instead of 7.0) with generous 1.55s obstacle spacing
     and single-obstacle spawns so players can warm up easily.
   - Smoothly increases speed, spawn rate, and 2-lane obstacle combinations over time (never blocking all 3 lanes).
2. Procedural Web Audio API Synthwave Soundtrack & Sound Effects:
   - Zero external audio files needed — generates bassline, arpeggio, jump, slide, coin, dodge, and crash SFX natively.
3. Fixed Perspective Lane Alignment & Ground Shadow:
   - Aligned player X-coordinate with the exact perspective lane width at the hit zone so lane visuals match hitboxes 100%.
   - Added a dynamic ground shadow under the player so jumping height is always clear.
4. Full UI, Career Save & Controls:
   - High Score, Coin Bank, and Total Runs saved automatically in localStorage.
   - Instant touch-swipe detection + toggleable On-Screen Touch Pads (Left, Right, Jump, Slide).
   - Pause Menu (P/Esc), God Shield Cheat toggle (C), Mute toggle (M), Fullscreen toggle (F), and auto-pause on tab switch.
   - Offline-ready: 100% self-contained with zero external CDN dependencies.
