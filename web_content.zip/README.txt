BUBBLE RAMP
============
A simple playable motorcycle ramp game made for mobile browsers.

How to play:
- Open index.html in a browser.
- Use ◀ / ▶ to move.
- Use ▲ to jump.
- Collect yellow bubbles/coins.
- Avoid red hazards.
- Reach the checkered finish.

Controls:
Keyboard: Arrow Left, Arrow Right, Space/Arrow Up, R to restart.
