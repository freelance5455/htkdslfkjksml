FURNITURE STOCK MANAGER - ANDROID INSTALL GUIDE

WHAT IS INCLUDED
- index.html: your existing stock manager, adapted as an installable web app
- manifest.json and icons: app identity and icon
- sw.js: offline app shell caching
- Export Backup / Import Backup buttons

INSTALL ON ANDROID USING CHROME
1. Upload the contents of this folder to a static HTTPS host such as Netlify.
2. Open the deployed site URL in Chrome on your Android phone.
3. Use the Install App button if shown, or Chrome menu > Install app / Add to Home screen.
4. Open it from the new home-screen icon.

NETLIFY QUICK START
1. Sign in to Netlify and choose Add new site > Deploy manually (wording may vary).
2. Drag the unzipped folder contents, or the folder, into the manual deploy area.
3. Open the generated HTTPS URL on your phone.

IMPORTANT DATA NOTE
This version stores inventory in browser local storage on the device. It does not include online accounts, multi-device cloud sync, or automatic cloud backup. Use Export Backup to save a JSON backup somewhere safe and Import Backup to restore it. Clearing browser/site data can erase local inventory.

APK NOTE
This package is an installable PWA, not a compiled APK. After deploying it on HTTPS, you can use PWABuilder (pwabuilder.com) to package it for Android; APK/AAB packaging may require additional Android signing/build steps.
