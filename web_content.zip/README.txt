# HAMDI FILE CENTER

مشروع مركز توزيع ملفات أونلاين، مناسب للعمل من الهاتف.

## الملفات
- index.html: واجهة المستخدمين.
- admin.html: لوحة الإدارة.
- firestore.rules: قواعد Firestore.
- storage.rules: قواعد Firebase Storage.

## إعداد Firebase
1. أنشئ مشروعًا في Firebase.
2. فعّل Authentication > Email/Password.
3. أنشئ مستخدم الإدارة بالبريد وكلمة المرور.
4. فعّل Firestore Database.
5. فعّل Storage.
6. افتح index.html وadmin.html وضع نفس firebaseConfig الخاص بمشروعك بدل القيم YOUR_*.
7. انشر ملفات الموقع على استضافة HTTPS.
8. بعد إنشاء حساب الإدارة، خذ UID الخاص به من Firebase Authentication.
9. في Firestore أنشئ:
   admins / UID
   ويمكن أن يكون المستند فارغًا.
10. ضع قواعد firestore.rules وstorage.rules في Firebase.

## الاستخدام
- افتح admin.html.
- سجّل دخول حساب الإدارة.
- اختر الملف.
- اكتب الاسم والإصدار والوصف والحجم.
- اضغط رفع وإضافة الملف.
- سيظهر الملف تلقائيًا في index.html لجميع المستخدمين.

## ملاحظات
- لا تضع مفاتيح Admin SDK أو service account داخل HTML.
- firebaseConfig الخاص بالويب ليس كلمة مرور سرية، لكن صلاحيات البيانات تحميها Rules.
- استخدم HTTPS.
- وزّع فقط الملفات التي تملك حق توزيعها.
