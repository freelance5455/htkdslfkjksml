# Meu Estúdio IA — versão 1

Esta é a primeira versão visual do seu aplicativo pessoal.

## O que já existe
- Tela inicial para celular
- Upload de foto
- Prévia da foto
- Botões para Foto → Vídeo, Modelo, Narração, Capa, Legenda e Imagem
- Campo para escrever o prompt
- Estrutura preparada para receber as funções de IA

## Próxima etapa
Conectar cada botão a um serviço/modelo de IA para gerar os arquivos de verdade.

## Como testar
Abra `index.html` no navegador do celular ou computador.
Para instalar como aplicativo pela tela inicial, o ideal é hospedar os arquivos em um endereço HTTPS; depois, no Chrome, use "Adicionar à tela inicial".
