NEXORA UPDATE MOD — APKFORGE WEBVIEW PACKAGE (FIX)

Upload ZIP ini ke APKForge. Atur halaman awal menjadi index.html.

PERUBAHAN:
- Tombol Bagikan Prank dihapus dan diganti teks ajakan membagikan aplikasi.
- Tombol Laporkan via WhatsApp menggunakan tautan HTTPS api.whatsapp.com dengan nomor 6285165829430 dan pesan otomatis.
- Tidak ada fungsi berbagi APK otomatis. Untuk menyebarkan aplikasi, pengguna mengirim file APK secara manual.

CATATAN:
WebView APKForge dapat berbeda perilakunya tergantung pengaturan dan versi builder. Tautan HTTPS ini menghindari pemanggilan skema whatsapp:// secara langsung, tetapi jika APKForge memblokir navigasi ke aplikasi eksternal, pengaturan navigasi eksternal pada builder mungkin tetap diperlukan.
Aplikasi hanya menampilkan layar prank setelah dibuka dan tidak meminta izin sensitif.
