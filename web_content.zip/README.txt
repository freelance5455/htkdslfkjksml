SR X TOURNAMENTS
Professional standalone esports app revision.

Files:
- index.html — complete standalone app UI.

Wallet logic:
- Approved deposits go to ADD BALANCE.
- ADD BALANCE remains separate until match entry is used.
- Match entry consumes ADD BALANCE first, then AVAILABLE BALANCE if needed.
- Match result settlement uses a net amount: positive adds to AVAILABLE BALANCE; negative subtracts from AVAILABLE BALANCE.
- Withdrawal is allowed only from AVAILABLE BALANCE.
- Duplicate deposit approval is blocked by request status.

Deposit proof:
- Payment screenshot is stored with the deposit request and is visible in Owner > Deposits on the same app/device.
- After submission, supported browsers can open the device share sheet for sending the proof details.
- A standalone HTML file cannot silently transmit an image to a remote owner's phone without a server/backend or an authenticated external service.

Support:
- Profile > Support opens https://t.me/SRGAMER96

Owner:
- Admin Console uses Owner Gmail + Admin Password after first-time setup.
- Owner ID is stored as metadata only.
