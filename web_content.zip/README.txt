ZIP to APK test website

IMPORTANT: index.html is at the ROOT of this ZIP.
In the converter app, choose this ZIP file, then set app name and build.
This is a sample offline website; replace it with your own site content later.
