# Kinder Kids Pre School — HTML App

## Included
- Responsive mobile-first HTML/CSS/JavaScript app
- Parent and Admin demo panels
- Demo login, dashboard, attendance, homework, fees, student list and announcements
- Local demo data saved in the browser using localStorage

## Demo credentials
- Parent: `parent` / `parent123`
- Admin: `admin` / `admin123`

## Test on Android
1. Extract the ZIP.
2. Open `index.html` in Chrome, or upload the folder to a static website host.
3. For an APK, package the web app inside an Android WebView wrapper / trusted HTML-to-APK builder.
4. Set the app name to `Kinder Kids Pre School` and package ID to a unique ID such as `in.kinderkids.preschool`.

## Important limitations
This is a front-end prototype, not a production school system. Login credentials are hard-coded and data is stored locally on one device. It is NOT secure and does not sync between parent and admin devices. Do not enter real children's names, photos, contact details, attendance or payment data.

Before real use, replace demo login and localStorage with a secure backend, role-based authentication, server-side authorization, encrypted transport, backups, audit logs, privacy policy and parent/school consent. Payment processing and push notifications need separate trusted integrations.
