Zikr App - HTML package

Files:
- index.html: app home page
- reminder.mp3: reminder audio; keep it in the same folder as index.html

Import steps:
1. Extract this ZIP.
2. In your HTML-to-APK tool, select the extracted folder or upload both files together.
3. Set index.html as the start page.
4. Do not rename or move reminder.mp3.

Included: four separate dhikr counters, daily goal/progress, saved daily counts, reminder interval controls, volume control, and WhatsApp channel button.

Android limitation: a plain HTML page cannot guarantee reminder playback after the app is fully closed, nor force Android's notification audio stream. That requires native Android app code and notification/service permissions.
