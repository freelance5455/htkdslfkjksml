TV Box — Version 1
এটি প্রথম ধাপের Home Screen ডেমো।

ব্যবহার:
1) index.html ব্রাউজারে খুললে অ্যাপের ডিজাইন দেখা যাবে।
2) পরের ধাপে এটিকে Android অ্যাপে প্যাক করা হবে।
3) Live TV চালু করার সময় শুধু নিজের বা অনুমোদিত স্ট্রিম/কনটেন্ট ব্যবহার করতে হবে।

পরের ধাপ:
- Channel list
- Search
- Favorites
- Video player
- Android TV remote/keyboard navigation
