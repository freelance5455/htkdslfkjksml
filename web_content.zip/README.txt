ROSHAN Healthcare — lightweight study file organiser

How to use:
1. Extract the ZIP.
2. Open index.html in a recent Chrome browser.
3. Create folders and upload files.
4. Use Save to download a file back to your device.

Important:
- This is a lightweight web app, not an Android APK or iPhone App Store package.
- Uploaded files are stored in the browser's local IndexedDB on that device/browser.
- Clearing browser storage or uninstalling/clearing the browser may delete app data.
- Keep separate copies of important files. Backup Export only exports folder/file index metadata, not the file contents.
- For large files, browser storage limits vary by device/browser.
