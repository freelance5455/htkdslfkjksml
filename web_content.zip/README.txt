Hubby & Wifey offline web package

This is an HTML package intended for a WebView/HTML-to-APK wrapper. It is NOT an APK yet.
Open index.html to preview. The PIN is a basic local gate, not strong native security. A WebView wrapper cannot guarantee device-bound installation or prevent APK copying.
