NISHANT LIVE — ONLINE VIDEO & VOICE ROOM APP

Included:
- Small splash icon
- icon.png for app/PWA icon
- Video Rooms
- Voice Rooms
- Live screen
- Audience
- Big Gifts
- Unlimited demo coins
- Owner Mode
- Chat
- Profile
- Notifications
- Settings

Payment:
NO payment gateway, UPI, card, Play Billing, purchase URL or payment source.

Important:
Real-time video/voice/chat and secure owner permissions require a backend.
