Daily Expense Monitoring App

Open index.html in Chrome/Edge. On Android Chrome, use Add to Home Screen for an app-like experience.
Data is stored locally in the browser/device using localStorage. Use Export CSV regularly for backup.
Categories: Grocery, Food - Outside, Travel, Shopping, Bills, Other.
Payment modes: UPI, Cash, Card, Other.
Includes add, edit, delete, date filter, totals and CSV export.
