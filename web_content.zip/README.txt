GREEN DIALER — APKForge web project

1. Open https://apkforge.site/ on your Android phone.
2. Choose the HTML/ZIP project upload option.
3. Upload GreenDialer-APKForge.zip.
4. App name: Green Dialer
5. Package name suggestion: com.example.greendialer.web
6. Choose portrait orientation and enable JavaScript if asked.
7. Build, wait for completion, then download and install the APK.

This is a WebView-style dialer. It supports a keypad, user-added contacts, app-local favourites, app-local recent-call entries and search. Call buttons open the system calling app with a tel: link. Web apps cannot automatically access Android's native contacts database or system call log, and this does not replace the system's default phone app. The app stores its own contacts/history in localStorage; clearing app data or some WebView settings may erase them.
