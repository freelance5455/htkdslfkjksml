MathSolver — JZst Studio UI Upgrade
===================================

FILES
- index.html: page structure and interface
- style.css: responsive neon dark theme
- main.js: example buttons, demo solver, solution steps, history, settings

HOW TO IMPORT
1. Make a backup of your existing project first.
2. Extract this ZIP.
3. If your app uses a simple HTML/CSS/JS project (such as SPCK Editor), copy these three files into the same project folder.
4. If prompted, replace index.html, style.css, and main.js only after backing up the old versions.
5. Open index.html in the preview and test the buttons on a phone.

IMPORTANT
- This is a front-end starter/demo, not a full symbolic algebra engine.
- Included example problems have built-in step-by-step responses. Basic arithmetic is also supported.
- To solve arbitrary math questions, connect a legitimate math API or add a proper math engine.
- This ZIP is for web-based HTML/CSS/JS projects. Native Android Studio Kotlin/Java apps need the UI rebuilt in native components or loaded in a WebView.


LOGO
- Your supplied JZst Studio logo is included at assets/jzst-studio-logo.png and displayed in the app header.

SOLVER IMPROVEMENTS
- Improved recognition of common example inputs with flexible spacing and symbols.
- Added a basic linear equation pattern and clearer error messages.
- Added a built-in “How MathSolver works” guide and syntax examples.

IMPORTANT SOLVER LIMITATION
This is still an offline demonstration solver, not a complete symbolic algebra system. It cannot reliably solve every arbitrary equation. For broad support (polynomials, matrices, limits, arbitrary integrals, complex systems, etc.), integrate a trusted computer algebra engine/API and handle errors carefully. Do not claim unsupported expressions have been solved.
