ENGLISH AFAAN OROMOO — Full interactive prototype
Features:
- Home dashboard
- 10 lessons
- Oromo explanations and examples
- English text-to-speech
- Quiz with 10 questions
- XP, streak and progress
- Local storage so progress remains on the device
- Mobile-first Android-friendly design

Run:
Open index.html in Chrome. Internet is not required for the basic prototype.
Next development step: convert this prototype into a signed Android APK/AAB and add more lesson/audio content.
