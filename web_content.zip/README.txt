PRIYA MEDICAL STORE — UPDATED EXISTING APP (WHATSAPP ORDERS ONLY)

This is the existing Priya Medical Store app with the requested settings updated.
- Removed Order ID, Order Status and tracking/confirmation status panels.
- Customer order details are sent directly to the store WhatsApp number +91 94099 96340.
- Prescription/photo can be shared using Android's Share sheet when supported. If file sharing is not supported, attach the photo/PDF manually in WhatsApp.
- No Firebase, Supabase, admin login, database or paid service is required.

IMPORTANT: This ZIP is the PWA/web-app source package, not an APK. It must be hosted on HTTPS or packaged by a PWA-to-APK builder. The customer must press Send in WhatsApp to submit the order.
