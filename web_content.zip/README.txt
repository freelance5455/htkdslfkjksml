EduMind AI v3 — Kamera oqimi bilan
1. ZIP ichidagi index.html faylini APK builderga yuklang.
2. APK builder/WebView sozlamalarida Camera permission va JavaScript yoqilgan bo‘lsin.
3. APK o‘rnatilgach: Android Settings > Apps > EduMind AI > Permissions > Camera > Allow.
4. Skaner sahifasida “Kamerani ochish” tugmasi video kamera oqimini so‘raydi. “Suratga olish” bosilganda kadr olinadi.
5. Agar builder WebView kamera ruxsatini qo‘llamasa, bu HTML kodi bilan ham kamera ochilmaydi. Builder kamera/WebRTC getUserMedia ruxsatini qo‘llashi shart. Bunday holatda APK builder sozlamasini yoki boshqa wrapperni almashtirish kerak.
6. OCR va Gemini AI funksiyalari internet talab qiladi. Gemini API key kerak. Ommaviy APKda API kalitni client ichida saqlamang; backend orqali himoyalang.
