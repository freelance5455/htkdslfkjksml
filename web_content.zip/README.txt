MASUD RANA Invoice Maker
Open index.html in a browser. QR generation uses an online QRCode library, so internet is required for QR creation. Print / Save PDF uses the browser print dialog.
