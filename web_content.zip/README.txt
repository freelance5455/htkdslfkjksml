TANGA REYTING O'YINI
- O'yinga kirishda ism yoziladi.
- Tanga tugmasi bosilganda tanga yig'iladi.
- Level 1 dan 10 gacha ko'tariladi.
- TOP 3 jadvali ko'rsatiladi.
- Natija telefonda saqlanadi.
- Bu versiyada umumiy internet reytingi yo'q.

ZIP to APK:
1. ZIP faylni ZIP to APK ilovasiga yuklang.
2. index.html ni asosiy HTML fayl sifatida tanlang.
3. APK build qiling.
