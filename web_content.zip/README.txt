# Poultry Manager — phone-friendly starter

## What is included
- Incubation batch records with day count and estimated hatch date
- Manual temperature and humidity logs
- Chick batches with automatic age calculation
- Health events, weight/feed/water notes, treatments and mortality records
- Five configurable daily reminders and one-time tasks
- JSON export/import backups
- A Firebase configuration form as a preparation step

## Important limitations
This is a usable starter web app, not a finished native APK.
- Records are stored in the current browser on the current device.
- Firebase config can be saved, but Firestore sync is NOT implemented yet.
- Browser reminders are not guaranteed when the page/app is closed or Android suspends it. Add the five times to Android Clock for dependable alarms.
- Do not rely on this app as the sole reminder system for critical incubation tasks.

## Run it on Android
1. Upload this folder to a static HTTPS host (for example, a static web hosting service) or run it through a local web server. Service workers/PWA installation require HTTPS or localhost.
2. Open the hosted `index.html` in Chrome.
3. Chrome menu (⋮) → **Add to Home screen** or **Install app** if offered.
4. Start with a test batch and export backups regularly.

## Cloud sync next step
Create a Firebase project, enable Authentication and Cloud Firestore, configure secure user-scoped Firestore rules, then implement sign-in and per-user record synchronization. Do not make Firestore publicly readable/writable.

## Data model
- batches: incubation batch metadata
- readings: manual temperature/humidity entries
- chicks: hatch batch and starting count
- health: health/feed/weight/mortality events
- tasks: one-time reminders
- alarms: five recurring daily reminders
