Sohrawardi College APK project
Main file: index.html
Import this ZIP into your Android HTML-to-App / WebView APK builder as a zipped website.
App name suggestion: Sohrawardi College
This is a web project package, not a compiled APK.
