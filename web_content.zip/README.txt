SkyCrash APK builder ZIP — index.html at archive root.
Opens https://skycrash-game-official.netlify.app/ in external browser (target=_system).
For builder compatibility: set External links / Open in browser / Chrome to ON if available. Some builders ignore target=_system and may open the site inside WebView; in that case choose a builder that supports external browser launch.
Deposit and withdrawal submissions run on the LIVE WEBSITE, not inside this launcher. Existing Firebase settings and admin panel are untouched.
This package does not include offline game assets and does not activate automatic bonuses. Live Google login and submission have NOT been verified end-to-end.
