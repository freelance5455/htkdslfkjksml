THE MANAGEMENT COMPLETE WHATSAPP-STYLE APP

Included interface:
- Chats and private conversations
- Groups and group creation
- Communities
- Updates/status
- Calls and call history
- Voice and video call UI
- Incoming calls
- Mute/camera/hang-up controls
- Attachments menu
- Search UI
- Profile/settings/logout menu
- Mobile-first WhatsApp-style conversation screen
- THE MANAGEMENT branding

IMPORTANT:
This package contains the complete front-end experience. To make messages,
groups, statuses, communities, accounts, and calls truly shared across
different phones, connect a secure realtime backend such as Supabase/Firebase
and production WebRTC signaling. Browser localStorage is only a demo store.
