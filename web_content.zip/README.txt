Island Assault 3D

Diese ZIP enthält die aktuelle Startdatei des Spiels.

Öffne Island-Assault-3D.html in Chrome/Edge/Firefox.
Eine Internetverbindung ist erforderlich, weil Three.js, der aktuelle Spielcode und die 3D-GLB-Assets online geladen werden.

Die Datei verwendet den aktuellen Stand von GETA Games, einschließlich der neuesten Soldaten-GLB-Modelle.
