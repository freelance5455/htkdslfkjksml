MY DREAM WISHLIST PLUS

Included:
- Pink/purple/blue/green themes
- Wish pictures, categories, prices, notes, checkboxes, search and sorting
- Savings goal tracker
- Birthday countdown and birthday gift ideas
- Biggest dreams page
- CSV export and JSON backup/restore
- Optional basic password screen

Android:
1. Download and extract the ZIP.
2. Open index.html in Chrome.
3. Use Chrome's Add to Home screen option if available.

This is a browser-based app, not a Play Store APK. The manifest alone does not make a local HTML file installable as a full PWA; secure hosting and a service worker are needed for a full installable/offline PWA. Wishlist data stays in local browser storage. The password is only a basic screen lock, not strong encryption. Back up data before clearing browser storage or changing devices.
