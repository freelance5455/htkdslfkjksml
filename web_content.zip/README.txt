TRAP RUSH - Web Edition
========================
Open index.html in a browser, or upload this ZIP to a service that supports HTML/WebView apps.

Features:
- Levels 0 through 2300
- Mobile touch controls
- Keyboard controls
- Jumping and movement
- Spikes
- Hidden-floor troll levels
- Fake doors
- Moving platforms
- Death/restart
- Level progression
- Final completion at level 2300
- Original visuals

Controls:
Mobile: LEFT / JUMP / RIGHT buttons.
Keyboard: A/D or Arrow keys, Space/Up to jump, R to restart.

This is an original troll-platformer prototype and is not a copy of Level Devil.
