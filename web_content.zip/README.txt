MAMAMIA MAMA — Fullscreen Image + Sound APK project

IMPORTANT: index.html is only an informational web page. It is NOT the Android app.
The actual app is built from the Android project files and installed from app-debug.apk.

PHONE-ONLY BUILD USING GITHUB ACTIONS
1. Create/sign in to a GitHub account at https://github.com.
2. Create a new repository named mamamia-mama.
3. Extract this ZIP on your phone.
4. In the repository, use Add file > Upload files.
5. Upload ALL extracted contents, including the hidden .github folder and its workflows/build-apk.yml file. Upload the contents, not the outer folder and not only the ZIP.
6. Commit the files to the main branch.
7. Open the repository's Actions tab. Choose "Build MAMAMIA MAMA APK" and run the workflow if it did not start automatically.
8. When the workflow finishes successfully, open the run and download the MAMAMIA-MAMA-APK artifact.
9. Extract the artifact ZIP and install app-debug.apk.

APP
- Shows the supplied image full-screen when opened.
- Starts a generated spooky ambient sound when opened.
- STOP SOUND / PLAY SOUND controls.
- CLOSE exits the app.
- Sound stops when the app closes.

The APK is not included in this ZIP; GitHub Actions builds it.
