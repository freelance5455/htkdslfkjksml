LIFELOOP - ANDROID STUDIO PROJECT

This ZIP contains Android source code for a simple offline-first personal organiser.
It is NOT an APK and has not been compiled or tested on a physical device.

Included and implemented:
- Home dashboard
- Daily task list: add, mark complete, delete
- Notes: add and delete
- Expense diary: add and delete, with total
- Local on-device saving using Android SharedPreferences
- No account, server, or internet permission is required for these features

Not included:
- Online AI assistant
- Community networking
- Cloud backup or sync
- Notifications/reminders
- Translation packs
These would require additional development and, for online features, services and privacy/security work.

BUILD ON WINDOWS:
1. Install Android Studio: https://developer.android.com/studio
2. Extract this ZIP to a normal folder, for example Documents.
3. Open Android Studio > Open, then choose the extracted LifeLoop folder.
4. Wait for Gradle sync. If prompted, install Android SDK Platform 35.
5. Connect your Android phone with USB debugging enabled, or use an emulator.
6. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
7. Android Studio should create app/build/outputs/apk/debug/app-debug.apk.

If you only have an Android phone:
This project is not directly installable from the ZIP. You will need a compatible Android build environment or a Windows/Linux/Mac computer to compile it.

Package name: in.lifeloop.app
Minimum Android version: Android 6.0 (API 23)
Target SDK: 35


WEB VERSION ADDED:
- Open index.html in Chrome, Edge, Firefox, or another modern browser.
- It works offline after the file is on your device and opened in a browser.
- Tasks, notes and expense records are saved in that browser's local storage.
- The web version is not an APK. The Android Studio project remains in the app/ folder.
- Language choice is saved, but the full interface is not translated yet.
