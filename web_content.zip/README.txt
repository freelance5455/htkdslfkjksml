DASH 100 - Enhanced Android Project

Features:
- 100 progressively harder levels
- Saved unlocked/current level using localStorage
- Cube skin selector
- Generated original sound effects and simple synth music (no copyrighted music)
- Pause button
- Main menu and level select
- App icon included as Dash100_App_Icon.png

Open this folder in Android Studio and build/run the app.
The game itself is app/src/main/assets/index.html.

Note: This project does not contain an advertising SDK or payment system.
Those should only be added later with the relevant platform account/age/consent requirements.
