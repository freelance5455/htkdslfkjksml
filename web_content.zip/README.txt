NounouPilot – version 100% hors ligne

Tous les fichiers nécessaires à l'application sont inclus localement.
Aucun CDN, aucune police externe, aucune API et aucune URL Internet n'est nécessaire.
Les données sont conservées dans le stockage local du téléphone.

Fichiers de démarrage fournis :
- index.html
- web/index.html
- web/index (pour les convertisseurs WebView qui chargent cette URL)
