Lucky Overlay WebView Fix

This ZIP includes the page at web/index.html, which matches the local path
shown in the error screen: https://appassets.androidplatform.net/web/index.html

Try importing this ZIP into the same APK builder. If it still shows the same
error, the builder likely expects a different project layout or does not copy
the web/ folder into the APK.
