Civil Engineering Drawings v7
- Keeps the existing app design and features from v6.
- Added two-finger pinch-to-zoom in/out for PDFs in both chapter reader and problem drawings.
- Existing Zoom In (+) and Zoom Out (-) buttons remain available.
- Home: seven original chapter PDFs.
- Questions: Short, Conceptual, Long.
- Problems: original problem pages and figures for chapters 2–7.
- PDFs render page-by-page inside this app using PDF.js, with scroll and zoom controls; no external PDF app is opened.
- PDF.js is loaded from a CDN, so internet is required to load the in-app reader.
- This is a web app project, not an APK. Keep all folders/files together. Serve over HTTPS for PWA installation.
