Mitra Connect Web APK package.
Upload this ZIP to an HTML-to-APK builder that accepts a ZIP containing index.html.
This is a starter UI; real online chat/voice/video calls require a backend/signaling service.
