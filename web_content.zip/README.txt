FITNESS CIRCLE - PREMIUM DEMO
Open index.html in a browser.

Features:
- Premium dark dashboard
- Start-of-day animation/intro
- Water tracker
- Movement tracker
- Food log
- Live clock
- Daily progress overview
- Reminder time UI

This is a self-contained HTML app and needs no internet connection.
