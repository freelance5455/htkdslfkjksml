GAME GENIE AUFA - HTML PROJECT
===============================

Isi ZIP:
- index.html       <- file utama yang wajib dibuka converter
- css/style.css    <- desain fullscreen neon
- js/app.js        <- fungsi tombol dan daftar game
- assets/anime-bg.jpg <- gambar latar

Cara pakai:
1. Extract ZIP.
2. Pastikan index.html berada di root folder ZIP/project.
3. Masukkan folder/project ini ke converter HTML -> APK.
4. Entry/start page: index.html.

Catatan:
HTML/WebView tidak dapat mengontrol RAM, FPS, atau cache aplikasi/game lain secara langsung.
Tombol booster menjalankan fungsi yang aman di level aplikasi/web; Ping melakukan pengukuran latency bila jaringan mengizinkan.
