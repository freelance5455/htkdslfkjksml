GoPro Android wrapper project (lightweight offline WebView app)
============================================================

This project packages the GoPro Football Career HTML prototype as an Android app.
The game files are bundled locally in app/src/main/assets/index.html, so the app
does not need an internet connection to open. Career save behavior depends on the
prototype's localStorage implementation and Android WebView storage.

Important:
- This is Android project source, NOT a compiled APK.
- An Android SDK and Gradle are needed to build the APK.
- Open this folder in Android Studio, let it sync, then use Build > Build APK(s).
- The resulting debug APK is normally under app/build/outputs/apk/debug/.
- Package ID: com.gopro.career
- Minimum Android version: Android 6.0 (API 23).

This is a basic wrapper around the current HTML prototype, not a full native rewrite.
