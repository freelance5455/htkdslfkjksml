WHITE ROOM — Updated anime-background build

The six images supplied by you are used as-is (not AI-generated or redrawn):
- Home: Haikyuu character image
- Exam: Luffy running
- Routine: Luffy cheering
- Syllabus: hooded Solo Leveling character
- Growth: supplied portrait image
- Settings: supplied Blue Lock image

All six navigation options are now fixed at the bottom of the screen.
To use: extract ZIP, open index.html or load the ZIP/folder into your trusted HTML-to-APK builder. Set index.html as the start page.
The app stores progress and custom wallpapers in local browser storage. Keep using the same app/browser.
Exact native Android alarms/background notifications require a native Android implementation; this web build does not guarantee them.
