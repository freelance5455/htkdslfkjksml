Child Health Clinic - AppForge PDF Version
============================================
Entry point: index.html

Features:
- Offline clinic fee and expense records using local storage
- Date/calendar as first field
- Previous balance
- Fees actually received
- Expenses with description
- Current balance
- Daily/monthly/all filtering
- Generate a real PDF report
- Print
- Excel-compatible CSV export

PDF note:
The app uses jsPDF from CDN for direct PDF generation. For a fully offline first-run,
open the app once while internet is available so the library can load/cache if the
AppForge WebView permits caching.
