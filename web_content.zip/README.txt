JJK SOLY OTAKO EDITION - Web package for website-to-APK converters

Start page: index.html (works fully offline, no external libraries)

3D action fighter with a perspective camera, low-poly 3D fighters, arena, and effects.
Controls (touch): move, jump, attack (punch/kick combo), block, and cursed technique.
- Cursed technique: fires a cursed-energy blast (25 energy). With full energy (100) it triggers Domain Expansion.
- Modes: Story (3 chapters), 2x2, Two Players (second control pad on top, rotated for the opponent), Basic Training, Domain Expansion Training.
- Keyboard: A/D move, W jump, J attack, K special, L block. Player 2: arrow keys, 1/2/3.
Uses original placeholder low-poly models, not official art. An APK converter wraps this website; it is not a native engine build.
