Contractor Pro V10.5 — Professional Documents

APK-ready single-file build based directly on V10.4.

New in V10.5:
- Professional Document Center inside Documents.
- Print-ready Estimate / Quotation, Contract, Invoice, Change Order and Payment Receipt documents.
- Branded company header, document number, client/project metadata, totals and signature lines.
- Device print dialog can be used to save the document as PDF.
- Existing copy/share, data model, offline storage and V10.4 splash are preserved.

Important:
- This is still an offline-first APK-ready build.
- PDF creation uses the device/browser print dialog; no external PDF library or server is bundled.
- Cloud authentication, live sync and server-side licensing are not claimed as implemented here.

Package root must keep index.html at the root for APK converters that require it.
