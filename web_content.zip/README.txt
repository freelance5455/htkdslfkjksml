YouTube Lite - HTML to APK Builder ZIP

Import this ZIP into the HTML to APK Builder app.
Entry file: index.html

The app is a lightweight YouTube mobile-web wrapper.
It does not bypass YouTube restrictions or provide third-party downloading.
Current YouTube compatibility depends on the Android/WebView/browser engine.
