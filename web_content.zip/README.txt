Aviator Predictor Dashboard - Demo
====================================
Open index.html in any Android browser.

Important:
- This is a statistics/manual-history demo, not a real predictor.
- It does not access private APIs, bypass security, automate betting, or guarantee future crash points.
- Enter round multipliers manually.
- To convert to APK on mobile, use a trusted HTML-to-APK wrapper/WebView builder and review permissions carefully.
