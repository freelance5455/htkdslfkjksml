Teacher Vacancy Connect - simple prototype

Included:
- Nandyal district / Nandyal Town
- Anantapur district / Kalyandurg
- Vacancy search by area and subject
- Simple school vacancy posting
- Simple teacher profile
- Phone contact button
- Data stored locally in the browser for this prototype

This is a working prototype, not yet a cloud-connected production app.
To make it a real public Android app, add a database, login/OTP, admin approval, privacy/security, and then package it as an Android APK/AAB.
