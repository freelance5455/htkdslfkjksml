CLINIC ASSISTANT V3 — ZERO-COST OFFLINE CLINICAL COPILOT

This package builds on V2 and adds a Clinical Copilot tab. It searches the existing custom clinical library and imported PDF reference cases using local keyword/symptom matching. No external AI API is called and no text is sent to an AI provider. This is NOT a generative AI model and must not be represented as one.

Includes V2 features:
- Symptom library, diagnosis-symptom linking, investigations and medicine library
- Medicine duration in library and consultation
- PDF reference cases imported from uploaded OPD Clinical Reference Notebook
- Patient visit and editable prescription prototype

Install/deploy:
- Host this folder over HTTPS (for example, Cloudflare Pages static asset upload).
- Open the HTTPS URL in Android Chrome and choose Install app / Add to Home screen when offered.

IMPORTANT SAFETY:
- Prototype only; do not store identifiable real patient data.
- No login, encryption, secure server database, audit trail, access controls or multi-device backup.
- Matching is not diagnosis. It may miss synonyms, atypical presentations, comorbidities and emergencies.
- Imported PDF treatments are unverified source text. Confirm against current authoritative guidance and patient-specific factors.
- The copilot is decision-support only, not a substitute for clinician judgment.
