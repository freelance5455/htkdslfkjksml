SEHAT TIPS APP
================
यह पहला APK-ready HTML prototype है।

चलाने के लिए:
1. index.html को Chrome में खोलें।
2. मोबाइल पर भी responsive है।
3. इसे Android WebView/Capacitor जैसे wrapper में डालकर APK बनाया जा सकता है।

नोट: स्वास्थ्य सामग्री सामान्य जानकारी है, चिकित्सा निदान/इलाज नहीं।
