CLASS 10 MATHS PRACTICE — STARTER PROJECT

This is a phone-friendly web app/PWA starter project.

Included:
- Chapter-wise practice
- MCQ answer checking
- Solutions
- Random practice
- 5-question test mode
- Local progress using browser storage
- Hindi UI/questions
- Installable PWA manifest

How to test:
1. Extract the ZIP.
2. Open index.html in a browser.
3. For full PWA installation/service-worker support, host the folder on a web server.

To expand the question bank:
Open app.js and add objects to the `questions` array:
{c:"Chapter",q:"Question",o:["A","B","C","D"],a:0,s:"Solution"}

Note: This starter contains sample questions, not the complete official WBBSE question bank.
