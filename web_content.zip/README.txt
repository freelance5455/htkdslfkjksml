مصاريفي - نسخة Web APK جاهزة للتحويل إلى APK.
ارفع ZIP كما هو إلى خدمة HTML-to-APK. يجب أن يبقى index.html في جذر ZIP.
