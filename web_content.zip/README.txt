CryptoTrader web app packaged for a web-to-APK builder.
Paper trading only. No real Binance orders.
