تحويل اللعبة إلى APK (Capacitor) — اللعبة شغالة بالكامل أوفلاين، ملف واحد: www/index.html

المتطلبات: Node.js + Android Studio

1) npm install
2) npx cap add android
3) npx cap sync android
4) npx cap open android   ← ثم Build > Build APK(s)

أيقونة التطبيق: icon.png (1024x1024). استخدم: npx @capacitor/assets generate --android (بعد وضعها في assets/icon.png)

ملاحظات مهمة:
- الإعلانات والمشتريات حاليًا تجريبية (MONET.ads / MONET.pay = 'mock' داخل index.html). بدّلها قبل النشر.
- خط Cairo مش مدمج (كان بيتحمّل من الإنترنت). لو عايزه، حط ملف Cairo.woff2 في www وأضف @font-face.
- اللعبة بتحفظ التقدم في localStorage داخل التطبيق.
