PETUALANGAN WORLD CURAM — DEMO GAME
====================================
Isi:
- index.html: game demo yang bisa dimainkan offline di browser modern.
- Fitur: 6 level bertahap, skor, koin, rintangan, lompat, level terbuka, rekor tersimpan di browser.

CARA MENCOBA:
1. Ekstrak ZIP ini.
2. Buka index.html di browser (Chrome disarankan).
3. Tekan MULAI PETUALANGAN.
4. Gunakan tombol kiri/kanan dan lompat.

CATATAN APK:
Paket ini adalah proyek game HTML, BUKAN file APK yang sudah dikompilasi dan belum siap diunggah ke Play Store.
Untuk APK Android, proyek ini perlu dibungkus menggunakan Android Studio + WebView atau Capacitor, lalu dibangun dan diuji. Untuk Play Store biasanya perlu AAB, akun Play Console, dan memenuhi persyaratan Google Play.
