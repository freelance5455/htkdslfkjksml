Dafaallah Calculator v1.1

Updated: operation-history button with delete, stopwatch-history button with delete, centered splash branding.
Data is stored locally in the app.

Theme selector added; history deletion works without confirmation dialogs.
