WING POINTE HTML-TO-APK PACKAGE

Upload the ZIP containing these files to HTML & ZIP File to APK Builder.
index.html must remain at the top level of the ZIP.

After installing the APK:
1. Open Settings inside Wing Pointe Manager.
2. Enter a separate OpenAI Platform API key and model name.
3. Save confirmed business facts.
4. Use AI Manager, Calendar, Insights, and Library.

Important:
- ChatGPT subscriptions do not include API usage.
- This wrapper stores the API key in local web-app storage, not Android Keystore.
- The wrapper must permit HTTPS internet requests to api.openai.com.
- If direct requests are blocked by the wrapper's browser security, a secure backend is required.
- The app never publishes to Facebook.
