KART F2 — primeiro teste offline

Abra index.html no Chrome. Todos os quatro áudios e as imagens do carro estão dentro desta pasta/ZIP; não dependem de internet.

Controles: chave liga/desliga, acelerador, freio, setas de faixa, farol e pausa.
