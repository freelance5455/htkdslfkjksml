AnimeMind — تسجيل دخول وقاعدة بيانات

مهم: الملفات فيها تكامل Supabase، لكن لا يمكن تسجيل حساب حقيقي أو حفظ البيانات على الإنترنت قبل إضافة بيانات مشروع Supabase. لا تضع service_role key في الموقع.

1) أنشئ مشروعًا في https://supabase.com/ (راجع شروط السن/موافقة ولي الأمر إن لزم).
2) من Project Settings > API انسخ Project URL و anon/public key.
3) افتح supabase-config.js واستبدل YOUR_PROJECT و YOUR_SUPABASE_ANON_PUBLIC_KEY بالقيم الفعلية. مفتاح anon/public مخصص للواجهة ويجب أن تحمي البيانات بسياسات RLS الموجودة بالملف SQL. لا تضع service_role key مطلقًا.
4) من Authentication > URL Configuration أضف عنوان موقعك المنشور إلى Site URL و Redirect URLs.
5) من Authentication > Providers تأكد أن Email مفعّل، وحدد إعداد تأكيد البريد.
6) افتح SQL Editor وشغّل محتويات supabase-setup.sql.
7) ارفع index.html و supabase-config.js إلى استضافة HTTPS ثابتة (مثل Netlify أو Cloudflare Pages). لا تعتمد على فتح الملف مباشرة file:// لأن جلسات تسجيل الدخول وإعادة التوجيه تحتاج عنوان موقع مستضاف.

الملفات:
- index.html: الموقع وشاشة تسجيل الدخول الأولى.
- supabase-config.js: ضع إعدادات مشروعك هنا.
- supabase-setup.sql: جدول بيانات المستخدم وسياسات أمان الصفوف RLS.

التسجيل: إنشاء الحساب، تأكيد البريد، تسجيل الدخول، واسترجاع كلمة المرور تستخدم Supabase Auth. بيانات السجل والتفضيلات تحفظ في user_data. هذا التكامل يحتاج إعداد المشروع واستضافة الموقع قبل أن يصبح فعليًا.
