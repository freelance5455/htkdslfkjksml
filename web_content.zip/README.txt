# Meu Financeiro 2.0

Versão avançada do projeto, feita para celular.

Recursos:
- Dashboard com saldo, entradas, despesas e taxa de economia
- Gráficos mensais
- Despesas por categoria
- Histórico com busca e filtros
- Adicionar, editar e excluir lançamentos
- Metas financeiras com progresso
- Dados salvos no próprio aparelho via localStorage
- Backup e restauração em JSON
- Interface responsiva para Android

Para testar: abra `index.html` no navegador.

Observação: esta entrega é o projeto funcional em formato web/PWA-base. Para gerar um APK instalável, ele precisa ser empacotado como aplicativo Android (por exemplo, WebView/Capacitor).
