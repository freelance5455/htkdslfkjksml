SKY HOPPER — Browser Game
=========================
Files:
- index.html: game page
- style.css: responsive phone/desktop layout
- game.js: game logic and random ad selection
- assets/: the three supplied ad images

Run:
1. Extract the ZIP.
2. Open index.html in Chrome, Edge, Firefox, or Safari.
3. Press PLAY GAME. A randomly selected supplied ad appears.
4. Use the X in the top-right or PLAY GAME to enter the game.
5. Tap/click the game area or press Space to flap.

This is a client-side browser game. Scores are stored locally in the browser.
Ads are locally bundled sample creatives from the images supplied in this chat;
they are not connected to an advertising network and do not track users.
For a public website, use only images and ad creatives you have permission to use.
