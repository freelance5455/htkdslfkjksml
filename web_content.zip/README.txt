Ki Rivals - versión HTML móvil
Sube index.html como proyecto HTML/Frontend en un creador de APK compatible con HTML estático.
El juego funciona offline y usa Canvas, JavaScript y CSS; no requiere servidor ni dependencias externas.
Controles táctiles incluidos.
