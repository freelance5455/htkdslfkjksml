Mowasat Call Center Hub - Android APK Build Package

This ZIP is prepared for an HTML-to-APK cloud builder.
Entry point: index.html
The app is self-contained and intended to work offline.
Suggested app name: Mowasat Call Center Hub
Suggested package ID: com.mowasat.callcenterhub
Suggested orientation: Portrait
