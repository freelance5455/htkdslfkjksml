SOLO QUEST — SHADOW SYSTEM (Enhanced Version)

Includes:
- Daily fitness quests and XP
- Level-up popup animation
- Hunter rank progression
- Shadow Army unlock milestone
- 100-day challenge tracker
- Saves progress in your browser using local storage

How to run on Android:
1. Extract this ZIP.
2. Open index.html in Chrome.
3. Your progress is saved in that browser.

This is a web app package, not a compiled APK. Building an installable APK requires an Android build toolchain such as Android Studio or Capacitor.
Safety: train at your own pace; stop for pain, dizziness, or unusual shortness of breath.
