CATHY WORLD — PHONE EDITION

This is a Progressive Web App (PWA).

To install it as an app, the files need to be served from a normal HTTPS website.
Opening index.html directly will let you inspect/play the page in browsers that permit local files, but Android's Add to Home Screen installation and offline service worker require HTTPS.

Files:
index.html - complete game
manifest.webmanifest - app metadata
sw.js - offline cache

No OpenAI API key is embedded. This edition uses a local procedural story engine.
