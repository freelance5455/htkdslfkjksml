PLC Industrial Practice Simulator
Offline Android-ready HTML app.

Features:
- PLC FX5U virtual inputs/outputs
- 24V DC and L1/L2/L3/N/PE virtual power practice
- START/STOP
- SEN1/SEN2/SEN3
- SAKO VFD frequency practice
- 3-phase motor/conveyor simulation
- Virtual wiring with correct/wrong indication
- Errors and activity log
- Step-by-step lessons and challenge mode

Safety: this is a low-voltage CONCEPT SIMULATOR. It does not connect to real electrical equipment.
