FIT POINT CUSTOMER APP

Extract the ZIP and open index.html in Chrome.
Demo OTP: enter a 10-digit phone number; the screen displays 123456.
This OTP is a demo and is not sent by SMS. Live OTP requires backend/SMS provider integration.
