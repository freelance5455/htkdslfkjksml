LAHCEN GAME WEB
هذه نسخة Web من لعبة «الحسن: من الفقر إلى الثراء».
ابدأ من index.html.
الملف مهيأ للرفع في مواقع تحويل HTML/ZIP إلى APK.
