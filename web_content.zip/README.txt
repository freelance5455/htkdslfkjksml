FFM 26 - split project
======================
index.html            page structure only (HTML)
css/style.css         original game styles
css/mobile-fit.css    mobile sizing + no text selection (added)
js/01..18-*.js        game scripts - they MUST load in this numeric order
                      (already ordered in index.html)
assets/audio/         music.mp3, click.mp3, click2.wav (were embedded base64)
manifest.webmanifest, sw.js, icon-*.png   PWA / install files

Note: run it through a web server (or inside an APK/WebView) rather than
double-clicking index.html, so audio and loading behave correctly.
Quick test: python3 -m http.server   then open http://localhost:8000
