QURAN & ISLAM — Khalid Mohammed Tahir
Version: offline single-page starter app

Faayila ijoo: index.html
Banuu: index.html irratti cuqaasi; browser keessatti bani.

Hubachiisa:
- App kun bu'uura offline-first fi UI guutuu qaba.
- Qur'aana/Hadiisa/lecture guutuu itti dabaluuf data amanamaa fi hayyama isaa barbaachisa.
