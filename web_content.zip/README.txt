NOVA AI PRO - APK DONUSTURME PAKETI

DOSYALAR
- index.html: NOVA AI arayuzu ve yerel model baglantisi.

KULLANIM
1. Bu ZIP'i APK olusturucu uygulamasinda acin veya cikartin.
2. index.html dosyasini HTML dosyasi olarak secin.
3. Uygulama ayarlarinda JavaScript, DOM storage ve internet erisimini etkinlestirin.
4. Olusturulan APK'yi kurup acin. Sag ustteki sistem kontrol simgesiyle WebGPU ve internet durumunu gorebilirsiniz.

GERCEKCI UYARILAR
- Bu paket WebLLM ve Qwen2.5 3B yerel modelini kullanmayi dener.
- Ilk model yuklemesi internet ister; model buyuk olabilir ve cihazda birkac GB bellek/alan gerektirebilir.
- APK olusturucunun Android WebView bileseninde WebGPU yoksa model calismaz. Sistem kontrol ekrani bunu gostermeye calisir.
- APK olusturmak, modelin cihazda calisacagini garanti etmez.
- Model ve kutuphane ilk acilista internetten yuklenir; cevrimdisi ilk kurulum desteklenmez.
