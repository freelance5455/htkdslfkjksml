MISSION CONTROL — OFFLINE BUILD

Run:
1. Keep index.html at ZIP root.
2. Open index.html in a modern browser or import the ZIP into an HTML-to-APK/PWA wrapper.
3. Missions are stored locally with localStorage, so core mission management works without internet.

Included:
- Dashboard
- Daily/Weekly/Monthly/Yearly/Future missions
- Pending/Completed
- Priorities, due dates, categories, notes
- Progress and streak
- Offline local storage
- Local rule-based Mission AI
- Responsive mobile UI
- PWA manifest

Important:
- No API key is embedded.
- No external network request is required for core functionality.
- An actual cloud LLM cannot be guaranteed offline. The included Mission AI is deliberately offline and uses local mission data.
- Android/browser permission prompts cannot be silently auto-granted by a web app; the app requests no unnecessary permissions.
