ST World bd — 3 Separate Apps

1. admin/index.html — Admin
2. rider/index.html — Rider
3. shop/index.html — Shop

Admin features include:
- Add/Delete Shops
- Add/Delete Riders
- Create & Assign Orders
- Send order to Shop/Rider by WhatsApp
- Order status management
- Dashboard

Shop App:
- Shop selects its account
- Sees orders assigned to that shop
- Customer, address, products, total and assigned rider
- Accept Order
- Ready for Pickup

Rider App:
- Rider selects account
- Sees assigned orders
- Accept / Picked Up / Delivered
- Shop and customer map buttons

IMPORTANT: This is the front-end starter. For Admin PC, Shop phone and Rider phone to share orders live, all three must connect to the same online database with secure Admin/Shop/Rider login.

WhatsApp update: Admin can save a separate WhatsApp number for every Shop and Rider. Order WhatsApp sending uses the saved WhatsApp number first, then falls back to phone.
