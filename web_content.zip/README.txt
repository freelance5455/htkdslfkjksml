TABLETOP B751 V0.5.1

Cambios:
- MESA, MAZOS, JUEGOS, GUARDAR y CARGAR ahora están en una sola fila de tabs compactos.
- Se eliminó la barra de botones inferior para ahorrar espacio vertical.
- La interfaz se mantiene basada en V0.5, que ya fue probada correctamente.
- No se cambia todavía la lógica de la mano/mazos.

index.html está directamente en la raíz del ZIP.
