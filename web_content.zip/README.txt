DÉCIDE POUR NOUS — VERSION 4
==============================

Nouveautés :
- Action ou Vérité — Amis
  - Tranquille
  - Fun
  - Gênant
  - Défis
  - nombreuses questions/actions
- Action ou Vérité — Couple
  - Romantique
  - Séduction
  - Hot
  - Défis couple
  - actions pimentées mais non graphiques
- Bouton « Encore un »
- Toujours 100 % hors ligne
- Aucun compte, aucune API, aucun serveur

Les contenus sont stockés directement dans l'application.
