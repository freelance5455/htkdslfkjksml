GODWIN AI VIDEO STUDIO - PHONE WEB APK PACKAGE

Upload this ZIP to an HTML-to-APK builder. index.html must remain at the ZIP root.
This is a standalone front-end demo that stores projects on the phone using localStorage. Real AI/video generation providers require a connected backend later.
