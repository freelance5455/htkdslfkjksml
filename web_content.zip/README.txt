SCHOOL PLANNER — HTML-TO-APK PACKAGE

This ZIP is arranged for HTML-to-APK/WebView converters that accept a website ZIP.

CONTENTS
- index.html: the planner app (entry page)
- manifest.json: basic app metadata
- icon.svg: simple app icon

HOW TO USE
1. Upload this ZIP to an HTML-to-APK or WebView app builder that accepts ZIP website uploads.
2. Set the start page to index.html if the service asks.
3. Enable JavaScript and local storage, and enable internet access if you want remote Google Fonts.
4. Build the APK, then test it on your phone.

LIMITATIONS
- This is a website ZIP, not an already-built APK.
- The planner's local data is stored in the app's WebView local storage on the device.
- Social/cloud functions that depend on the custom claude.use(...) environment will not work unless the builder supplies a compatible integration/backend.
- A converter's output and requirements vary; no ZIP can be guaranteed to work on every converter.
