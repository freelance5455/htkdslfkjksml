FAIZ SPOOKY FACE — Android project ZIP

WHAT'S INCLUDED
- app/src/main/assets/index.html: the full-screen image popup page
- app/src/main/assets/spooky_face.jpg: the image you supplied
- MainActivity.kt: opens the popup automatically when the app launches
- Close button: dismisses the image and reveals the app's notification controls

BUILDING
This ZIP contains Android Studio project source files, not a prebuilt/installable APK.
Upload/extract the project files to a GitHub repository and run the included GitHub Actions
workflow (.github/workflows/build-apk.yml). Download the APK artifact from the completed run.

NOTIFICATION CONTROLS
Notifications are optional and only start after the user taps START NOTIFICATIONS
and grants permission where Android requests it. They can be stopped in the app.
