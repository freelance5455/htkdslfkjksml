N PLC WORKING ANDROID PROJECT

The two images supplied by the user are already included in this project.

Access codes:
HAZA19  -> first supplied human photo
HAZE19  -> first supplied human photo
DINORIDER -> second supplied dinosaur photo
DINO RIDER -> second supplied dinosaur photo

The code ignores spaces and capitalization.

After a valid code is entered, the matching image opens in a separate Android screen.

Build:
Open the project in Android Studio and use:
Build > Build APK(s)

The images are in:
app/src/main/assets/files/
