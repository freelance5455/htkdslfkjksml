NOVA AI - Proyecto Android

Este ZIP contiene un proyecto Android Studio y una interfaz HTML de asistente con estética futurista.

IMPORTANTE:
- Este ZIP NO es un APK compilado.
- La app es una demostración visual con respuestas locales; no está conectada a una IA real.
- Para generar el APK, abre la carpeta del proyecto con Android Studio y espera la sincronización de Gradle.
- Luego usa Build > Build APK(s). El APK de prueba suele quedar en app/build/outputs/apk/debug/.
- No requiere permisos especiales ni acceso a la cámara.
