POLICONECTA — DEMONSTRAÇÃO WEB

Este pacote contém a interface demonstrativa do PoliConecta em index.html.
Ele foi separado do projeto Android original para tentar usar uma ferramenta
que transforme um site HTML em APK.

Como usar:
1. Se o conversor aceitar ZIP, envie este arquivo.
2. Se ele pedir um arquivo HTML, extraia o ZIP e selecione index.html.
3. Defina o nome do aplicativo como PoliConecta.

Limitações:
- É apenas um protótipo de interface.
- Não há servidor, banco de dados, cadastro real, mensagens entre usuários
  diferentes nem verificação política real.
- Um conversor externo pode não aceitar este pacote ou exigir configuração.
