Mərsiyələr — offline HTML kitab

index.html və pages qovluğunu birlikdə saxlayın. İnternet tələb etmir.
APK yaratmaq üçün bu qovluğun ZIP faylını HTML/ZIP to APK xidmətinə yükləmək olar; xidmətin offline asset dəstəyi və məxfilik şərtlərini yoxlayın.
