ARAF SCRIPTS
Open index.html in a browser.
Owner login: exhibetalanjandro@gmail.com / Aa11Aa11

Note: outside claude.ai this runs in local mode. Accounts, chat and scripts are stored in your own browser only (shared between tabs on this device, not between different people). For a real multi-user app, connect a backend such as Firebase or Supabase.
