SMART ATTENDANCE — PHONE-ONLY APK BUILDER PROJECT

Files:
- index.html: complete responsive attendance app
- README.txt: these instructions

WHAT IT DOES
- Runs face recognition in the browser/WebView using face-api.js.
- Lets you register multiple names only after ticking a consent checkbox.
- Stores face descriptors and attendance records in localStorage on this device.
- First successful scan per person per day = IN + PRESENT; next scan = OUT.
- Exports attendance rows to a CSV file.
- No server/database is configured and no data is intentionally uploaded by this code.

IMPORTANT LIMITATIONS
This is a prototype, not production-grade identity verification. It has no liveness/anti-spoofing, can confuse people, and does not encrypt local browser storage. The face-recognition library and model weights are loaded from public CDNs, so internet is required for first load and usually for use. Do not use it for official or high-stakes attendance. Offer a non-biometric alternative and get informed consent from everyone registered.

PHONE-ONLY BUILD STEPS
1. Download this ZIP to your Android phone and extract it using Files / My Files.
2. Open the online APK builder in Chrome. One possible route is https://ziptoapk.com/ or the on-device Android app “HTML to APK Builder” in Google Play. Availability and features may change; review permissions and privacy before use.
3. Choose the HTML/ZIP import option and upload this ZIP. The ZIP has index.html at its top level.
4. Set app name to Smart Attendance. Use a unique package ID such as com.example.smartattendanceapp.
5. Build an APK, then download it.
6. Android may ask you to allow installation from that browser/file manager. Only allow it for the app you trust, install, and then turn that permission off again.
7. Open Smart Attendance, allow camera access, ensure internet is available, tap Start camera, and wait for “One face detected.”
8. To register a person: type their name, get their permission, tick the consent box, and tap Register current face.
9. To mark arrival/departure: tap Recognize face and record IN / OUT once at arrival and once at departure.
10. Tap Export CSV and save/share the file. The CSV contains names and attendance times.

CAMERA COMPATIBILITY
A WebView/HTML-to-APK wrapper must explicitly support camera permission and getUserMedia. If camera fails inside the APK, test index.html in Chrome over HTTPS first, or use a wrapper that supports camera access; do not grant unrelated permissions. Do not switch to a URL wrapper that sends attendance data to an unknown third party.

PRIVACY
Templates and records are stored in localStorage for the app origin. Clearing app storage, clearing browser data, or uninstalling may erase them. CSV exports are not automatically deleted. Anyone with access to the device/app may be able to view or alter data. Avoid storing sensitive attendance records on a shared/unlocked device.
