BIKE EXPENSE MANAGER - APKFORGE ZIP PROJECT

1. Extract this ZIP and upload the project ZIP to APKForge.
2. Set the start/home page to index.html if APKForge asks.
3. App password: 2323.
4. Local expenses are stored on the phone using localStorage. The app works offline after it has loaded once.
5. Google sign-in and Firebase sync need internet.
6. Firebase Realtime Database rules must be configured before cloud sync. Do NOT set public read/write rules.
7. The current sync path is users/{Firebase Auth UID}/bikeExpenseManager.
8. The project uses Firebase Web SDK from Google's CDN. First load / Google login requires internet.
9. PDF export opens the print dialog; choose Save as PDF. CSV downloads as an Excel-compatible UTF-8 CSV.
10. APKForge wrapper support varies. If the wrapper blocks Google redirect login or downloads/print, configure it to allow pop-ups/redirects and file downloads, or use its external browser support.

IMPORTANT SECURITY NOTE:
The in-app PIN is a simple local screen lock, not strong device/account security. Do not store sensitive financial or personal information in a shared phone profile.
