DART TRAINER – första prototypen

Innehåll:
- index.html: själva appen
- manifest.webmanifest: appnamn och ikon-/startinställningar
- sw.js: offline-cache när appen körs via HTTPS

Testa:
1. Öppna index.html i en webbläsare på datorn för att prova funktionerna.
2. För att installera som riktig hemskärmsapp på Android behöver filerna publiceras på en HTTPS-adress.
3. När sidan öppnas i Chrome på Android: välj menyn (⋮) och "Lägg till på startskärmen" eller "Installera app" om alternativet visas.

Viktigt:
Det här är en första prototyp, inte en färdig Play Store-app.
Den sparar statistik lokalt i webbläsaren. Om webbläsardata rensas kan statistiken försvinna.
