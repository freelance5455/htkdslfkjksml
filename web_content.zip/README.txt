SINGH GRILL — BROWSER APK BUILDER PACKAGE

Use this folder with a browser-based HTML-to-APK builder.

Main file:
index.html

Customer flow:
Menu -> Cart -> Name + Mobile Number -> Place Order.
No OTP and no customer login.

Important:
The Android WebView project and Node server are kept separately in the parent package.
A browser APK builder packages the web interface; it does NOT automatically run the Node server.
For shared online orders, the app must point to the live Singh Grill server/URL already configured in the web app.
