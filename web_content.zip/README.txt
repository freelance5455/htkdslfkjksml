SkyCrash Google Login + Firebase Deposit/Withdraw Requests

FILES
- index.html: game frontend; submits deposit requests to Realtime Database path `deposits`, uploads receipt screenshots to Firebase Storage, and submits withdrawal requests to `withdrawals`.
- admin.html: admin dashboard; reads deposit requests from `deposits` and withdrawal requests from `withdrawals`.

DEPLOY
1. Back up your current Netlify game and admin deployments.
2. Deploy this ZIP's index.html to the existing game Netlify site.
3. Deploy this ZIP's admin.html to the existing admin site (or deploy the ZIP to the admin site only if that site's setup expects the admin page as index.html; otherwise keep admin.html as the panel entry page).
4. In Firebase Console > Storage, enable/create the default Storage bucket if it is not already enabled.
5. Publish the Storage Rules below.
6. In Realtime Database > Rules, ensure signed-in users can create their own records under `deposits` and `withdrawals`, while only the admin can read all requests. Do not use open public read/write rules.


REALTIME DATABASE RULES (Firebase Console > Realtime Database > Rules)
Review this carefully before publishing; it keeps the controller's existing authenticated sharedGame access, lets users create their own pending request records, and lets the admin read requests.

{
  "rules": {
    ".read": "auth != null && auth.token.email == 'pkrewards31@gmail.com'",
    ".write": "auth != null && auth.token.email == 'pkrewards31@gmail.com'",
    "users": {
      "$uid": {
        ".read": "auth != null && (auth.uid == $uid || auth.token.email == 'pkrewards31@gmail.com')",
        ".write": "auth != null && (auth.uid == $uid || auth.token.email == 'pkrewards31@gmail.com')"
      }
    },
    "deposits": {
      ".read": "auth != null && auth.token.email == 'pkrewards31@gmail.com'",
      "$requestId": {
        ".write": "auth != null && (auth.token.email == 'pkrewards31@gmail.com' || (!data.exists() && newData.child('uid').val() == auth.uid))"
      }
    },
    "withdrawals": {
      ".read": "auth != null && auth.token.email == 'pkrewards31@gmail.com'",
      "$requestId": {
        ".write": "auth != null && (auth.token.email == 'pkrewards31@gmail.com' || (!data.exists() && newData.child('uid').val() == auth.uid))"
      }
    },
    "sharedGame": {
      ".read": "auth != null",
      ".write": "auth != null"
    },
    "adminControls": {
      ".read": "auth != null",
      ".write": "auth != null && auth.token.email == 'pkrewards31@gmail.com'"
    },
    "adminDiagnostics": {
      ".read": "auth != null && auth.token.email == 'pkrewards31@gmail.com'",
      ".write": "auth != null && auth.token.email == 'pkrewards31@gmail.com'"
    },
    "transactions": {
      ".read": "auth != null && auth.token.email == 'pkrewards31@gmail.com'",
      ".write": "auth != null && auth.token.email == 'pkrewards31@gmail.com'"
    }
  }
}

FIREBASE STORAGE RULES (Firebase Console > Storage > Rules)

rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    function isAdmin() {
      return request.auth != null && request.auth.token.email == 'pkrewards31@gmail.com';
    }
    match /depositReceipts/{uid}/{requestId}/{fileName} {
      allow create: if request.auth != null && request.auth.uid == uid
                    && request.resource.size < 5 * 1024 * 1024
                    && request.resource.contentType.matches('image/(jpeg|png|webp)');
      allow read: if isAdmin() || (request.auth != null && request.auth.uid == uid);
      allow update, delete: if isAdmin();
    }
  }
}

REALTIME DATABASE PATHS
- deposits/{requestId}: pending deposit requests with amount, reference, receipt URL/path, user UID and status.
- withdrawals/{requestId}: pending withdrawal requests with account details, amount, user UID and status.
- The admin page reads those exact paths.

IMPORTANT SECURITY
- These are client-submitted virtual/demo payment requests, not payment verification. An uploaded receipt does not prove payment.
- Admin approval/rejection controls and trusted balance crediting must be implemented and tested separately before treating deposits as processed.
- Do not credit a balance automatically from a client request. Use a trusted backend/Cloud Function for balance changes and status transitions.
- User balance writes in this demo remain client-side and are not secure for real-money use.
- If Firebase Rules currently deny writes to `deposits`/`withdrawals`, the request will fail and the game will show an error instead of falsely claiming success.
