PASS J Planner — version 3

Objectif :
- Calendrier du semestre entier fourni par le planning CM.
- Les CM AVANT le 05/10/2026 ne sont jamais affichés comme des CM sur le calendrier : ils sont transformés en retard à rattraper.
- Les CM à partir du 05/10 restent sur leur date réelle et apparaissent comme J0.
- Tous les cours, anciens et nouveaux, ont une série J0, J1, J3, J7, J14, J30, puis tous les 15 jours (J45, J60, J75...).
- Les J0 des anciens cours sont répartis à partir du 05/10 sur des créneaux de rattrapage.
- Les cartes peuvent être glissées vers un autre jour.
- Double-clic : modifier nom, numéro/intitulé, horaire, note, état terminé.
- Ajout/suppression manuels.
- Barre de progression : cours/J0 terminés, retard restant et volume du semestre.
- Réinitialisation possible pour revenir au planning automatique.

La source précise que le planning est susceptible d'être modifié : vérifier régulièrement eCampus/messagerie.
