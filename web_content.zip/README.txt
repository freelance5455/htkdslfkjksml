# CediWise — Mobile Browser Edition

A responsive, mobile-first browser app for student spending, budgets, and savings in Ghana cedis.

## Open on a computer
Extract the ZIP and open `index.html` in a modern browser.

## Open on a phone
For a quick preview, transfer the extracted folder to a web host or serve it from a computer on your network. To install it like an app on Android:
1. Host these files on an HTTPS website (for example, GitHub Pages, Netlify, or another static host).
2. Open the HTTPS link in Chrome on your phone.
3. Open Chrome's menu and choose **Install app** or **Add to Home screen**.

The installable/offline features require serving the files over HTTPS (or localhost); they do not activate by opening `index.html` directly from a file manager.

## Features
- Mobile-first layout with touch-friendly controls and a bottom navigation bar on small screens
- Add/delete expenses and view spending summaries
- Monthly and category budgets
- Savings goals, deposits, and withdrawals
- Local browser storage
- Basic offline app shell after the first load on a supported hosted site

## Important
Data stays in that browser on that device. It is not backed up or synced to another device. This is a demo budgeting tool, not a bank or payment app.
