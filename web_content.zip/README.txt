IJAL STR — FINAL MERGED BUILD
================================
Fitur gabungan:
- Beranda responsif/full-screen
- Menu garis 3 / drawer
- Pengaturan
- Login & register username-only
- Profil pengguna
- Profil Owner IJAL STR
- Nomor Owner +62 851-3878-4245
- WhatsApp Owner
- QRIS Owner bawaan + upload QRIS
- Jual Beli dengan foto galeri
- APK Store / upload
- Game Space + pilih file APK (metadata lokal)
- RUN BOT / pairing panel
- Chat Global
- Creative
- Creative Account Role: Owner, Admin, VIP, Seluler, Member
- Owner Account Manager: buat, ganti role, aktif/nonaktif, hapus akun
- Riwayat, notifikasi, izin web, syarat & aturan
- Ajakan dan tombol Gabung GB WhatsApp

GB WhatsApp:
https://chat.whatsapp.com/JlhZQLFXHVWDtcXlStCRGy?s=cl&p=a&mlu=4&ilr=4

Catatan:
- Login username-only bukan autentikasi aman untuk produksi.
- Role dan akun tersimpan di localStorage pada perangkat.
- Verifikasi pembayaran QRIS otomatis membutuhkan backend/payment gateway.
- Game Space web tidak dapat mengontrol APK Android secara native tanpa wrapper/native integration.
