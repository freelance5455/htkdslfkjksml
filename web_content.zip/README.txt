# تطبيق أبناء د.سراج – إدارة السكان والمدفوعات

## محتوى الحزمة
- www/index.html: النسخة النهائية من التطبيق.
- www/manifest.webmanifest + sw.js + icon.svg: دعم PWA.
- capacitor.config.json + package.json: تجهيز للتحويل إلى Android عبر Capacitor.

## ملاحظة مهمة
ملف HTML الأصلي يعتمد على Firebase وTailwind من روابط خارجية، لذلك يلزم اتصال بالإنترنت عند تشغيل النسخة السحابية.
كما أن إعدادات Firebase الاحتياطية داخل الملف تبدو تجريبية؛ قبل الاستخدام الفعلي يجب وضع إعدادات مشروع Firebase الحقيقي.

## بناء APK
بعد تثبيت Node.js وAndroid Studio:
npm install
npx cap add android
npx cap sync android
npx cap open android
ثم من Android Studio اختر Build > Build APK(s).
