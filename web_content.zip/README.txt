ST PLAY - Video & Music App (PWA prototype)

FILES
- index.html: the app interface
- manifest.json: installable app settings
- sw.js: basic offline caching
- icon.svg: app icon

HOW TO USE
1. Upload this folder to a static web host that supports HTTPS.
2. Open the hosted website in Chrome on Android.
3. Open Chrome menu (three dots) and choose "Install app" or "Add to Home screen".

IMPORTANT
This is an installable web-app prototype, not a Play Store APK.
The current upload feature plays files locally in the browser/device only.
Public accounts, shared uploads, comments, likes across users, and cloud video storage
need a secure backend, database, and hosting. Do not upload copyrighted media unless
you have permission.
