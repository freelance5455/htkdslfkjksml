MATYKA CHEATS — PROXY ANDROID
Versão 1.0.0

ESTRUTURA
- index.html (arquivo principal na raiz)
- assets/style.css (estilos)
- assets/app.js (lógica local)
- assets/images/ (reservado para recursos gráficos locais)

COMO IMPORTAR
1. Extraia o ZIP.
2. No HTML To APK, selecione a pasta extraída ou o arquivo index.html.
3. Defina index.html como página inicial.
4. Gere o APK conforme as opções do conversor.

OBSERVAÇÕES
- O projeto funciona localmente e não exige servidor.
- A ativação aceita qualquer KEY não vazia e é salva no armazenamento local.
- Os 12 controles guardam suas preferências localmente.
- A área de depuração Wi-Fi registra os dados e apresenta o estado da interface; uma página HTML não consegue estabelecer uma sessão ADB por conta própria.
- O botão INJETAR não injeta código nem altera processos de terceiros. O campo de pacote é uma solicitação informativa de abertura; o suporte depende do conversor Android utilizado.
- A navegação para configurações Android depende do suporte do WebView/conversor.
- Fontes externas são apenas um aprimoramento visual; a interface usa fontes alternativas se estiver offline.
