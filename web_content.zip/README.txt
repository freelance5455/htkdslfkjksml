Ngoi Medics PWA
Imeandaliwa kutoka mfumo wa Ngoi Medics Offline v1.
Risiti imeondolewa.

Kwa matumizi kamili ya PWA, host folder hii kwenye HTTPS, kisha fungua kwa Chrome na chagua Add to Home screen / Install app.
