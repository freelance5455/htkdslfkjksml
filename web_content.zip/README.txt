AQUA Sales V5 FINAL
UI: Gen Z dark/neon.
Data: storage key aqua_sales_v5 is preserved. Existing storage is NEVER overwritten.
Fallback: the latest user-provided V5 backup is only seeded if aqua_sales_v5 does not exist.
Backup before update is recommended.
Do not uninstall the old app or Clear Data if you want in-place localStorage preservation.
