AS Metal Dyes & Nakas - Staff App
Username: Ibrahim  Password: 1994
Works offline. Default theme: Black. Login-details PDF in Settings.
