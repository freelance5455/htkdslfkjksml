ENTIRE APPAREL WEBSITE — MOBILE-FRIENDLY 7-PAGE STATIC SITE

Pages:
1. index.html — Home
2. about.html — About
3. services.html — Services
4. products.html — Products
5. process.html — Our Process
6. quality.html — Quality
7. contact.html — Contact

Assets:
- assets/entire-apparel-logo.jpg — supplied logo image
- assets/style.css — responsive styling
- assets/script.js — mobile menu and WhatsApp inquiry form

Contact links:
- WhatsApp: https://wa.me/923326846694
- Instagram: https://www.instagram.com/entireapparels.pk/

HOW TO USE:
- Extract the ZIP file.
- Keep all seven HTML files and the assets folder together.
- Open index.html to preview locally.
- For hosting, upload the contents of the folder to Netlify, GitHub Pages, or another static web host.

IMPORTANT:
- The contact form opens WhatsApp with a pre-filled message; the visitor must press Send.
- Replace or update the Instagram URL if the exact username differs.
- No email address was provided, so the website uses WhatsApp and Instagram for contact.
- Product visuals are abstract CSS placeholders, not actual product photography.
- Confirm manufacturing capabilities, minimum order quantities, certifications and delivery timelines before publishing claims.
