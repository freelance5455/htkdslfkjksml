N Weather - Android app + real home-screen widget
Option A (computer): Android Studio > Open this folder > Run on phone.
Option B (no Android Studio): upload this folder's contents to a new GitHub repo; Actions > Build APK > download NWeather-APK, install the APK.
Then: long-press home screen > Widgets > N Weather.
Open the app once so the widget gets your city.

Battery: no foreground service, no wake locks, no exact alarms. One batched job ~every 90 min (network + battery-not-low), skipped when data is <45 min old, at night, or under Data Saver. WebView is paused in background.
