ULTRA ROOM CALLING - NO LOGIN

Web JSON ki zaroorat? ANSWER: HAAN, Firebase JSON chahiye - aur wo already isme add hai (ultra-calling). Bina uske 2 device ek dusre ko dhoond nahi payenge. Isliye Firebase hi signaling ka kaam karta hai.

MIC/CAMERA PROBLEM KYUN AATA HAI:
Browser sirf HTTPS pe mic/camera deta hai. file:// ya http:// pe block karta hai.
Solution is file me already hai:
- Page khulte hi Permission Check button hai
- Call se pehle permission mangta hai
- Android WebView me permission manifest me pehle se allow hai

USE:
1. Isko Netlify / Firebase Hosting / GitHub Pages pe daalo -> https:// link milega
2. Dono phone me wahi https link kholo
3. Dono me SAME Room ID daalo - jaise SHIV123
4. Ek CREATE, dusra auto JOIN - Call direct lag jayegi

Android App:
WebView app me index.html daalo, Manifest me RECORD_AUDIO, CAMERA, INTERNET permission add karo
