MG — Football Player Guessing Game
Upload this ZIP to a web-to-APK builder that accepts an index.html.
The game is intended to run offline after packaging.
