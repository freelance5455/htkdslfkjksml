DANX STORE - FIXED BUILD

File utama: DANX_STORE_FIXED.html
Perbaikan: timer lisensi dibuat lebih ringkas dan hijau, bukan merah; info lisensi permanen ditampilkan sebagai tanpa batas; hitung mundur tetap diperbarui setiap detik.

Catatan: halaman VPN pada build ini tetap merupakan simulasi UI dan bukan koneksi VPN WireGuard sungguhan. Koneksi sungguhan memerlukan aplikasi Android dengan VpnService serta server/konfigurasi WireGuard yang valid.
