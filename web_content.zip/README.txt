Android ID Reader HTML package

index.html must remain at the ZIP root.
Important: HTML/WebView alone cannot read Settings.Secure.ANDROID_ID.
The APK builder must provide a native Android-ID JavaScript bridge; otherwise
the app will display "Not available".
