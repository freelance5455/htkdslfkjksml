Universal Invoice Studio - installable web app package

This is a PWA package, not an Android APK. It must be hosted on an HTTPS website before Chrome can install it as an app.

Easy route:
1. Upload the contents of this folder to a static host that gives an HTTPS URL (for example Netlify Drop).
2. Open the resulting HTTPS URL in Chrome on Android.
3. Chrome menu (three dots) -> Install app / Add to Home screen.
4. Once installed, the interface can open like an app and the service worker caches the app shell.

Data is stored in the browser/device only; this is not cloud sync. This package does not include Play Store publishing or native APK build.
