GRK HOME MADE PICKLES — PWA

1. Upload the complete contents of this folder to an HTTPS web host (for example your domain or static hosting).
2. Open the hosted URL in Chrome on Android.
3. Use Chrome menu > Install app / Add to Home screen.
4. The service worker caches the shop shell for repeat/offline opening. WhatsApp ordering still requires an internet connection.

The original catalogue, product pricing, embedded photos/logo, cart, pincode-based delivery calculation, checkout validation and WhatsApp handoff are retained.

Shop WhatsApp number in the source: +91 90108 10884. Verify this number and delivery slabs before publishing.
