M.S.M E Sevai - STAFF package

The web app is placed at:
web/index.html

Android project location:
app/src/main/assets/web/index.html

This package is separated as the STAFF version.
The supplied interface/content has not been redesigned or replaced.
