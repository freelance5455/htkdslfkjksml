PRICEPILOT — AUTOMATIC PRICE CALCULATOR

WHAT IT DOES
- Saves item names and prices in a permanent SQLite database (prices.db).
- Automatically loads saved items whenever you open the app.
- Calculates quantity × unit price and the grand total.
- Lets you search, use, edit, update and delete saved items.
- Prints or saves a bill as PDF using your browser's print option.

REQUIREMENTS
- Python 3.9 or newer
- Flask

INSTALL
1. Extract this ZIP folder.
2. Open a terminal/command prompt inside the extracted folder.
3. Run: pip install -r requirements.txt
4. Run: python app.py
5. Open: http://127.0.0.1:5000

IMPORTANT
Keep app.py, the templates folder, the static folder and prices.db together.
The database is created automatically the first time the app starts.
Your prices are stored on the computer running the Python server. They are not
automatically shared between different devices. For online multi-device access,
the app needs to be deployed to a server with persistent storage.