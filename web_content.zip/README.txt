ACC V5 – personal accounts PWA package

Includes: AI features removed; professional username header; Food-only budget with compact dashboard summary; customizable financial month start and financial-year start date; Light, Default and Dark themes; custom start/end date monthly report.

Install: extract all files and host them on your HTTPS site, then open in Chrome and choose Install app / Add to Home screen. This is a PWA package, not an APK.

Your account data remains in this phone browser storage. Back up your data from Settings before replacing an existing version.
