ClassCheck Attendance Checker — Student Photo + QR Edition

Features:
- Upload a photo from phone when adding a student; image is resized for browser storage.
- Student profile cards show photo, name, student number, grade, section.
- Each student receives a unique random record ID.
- Generate and download a QR image for each student. QR contains only the record ID, not personal details.
- Attendance: Present, Late, Absent; date/section filters; history; CSV export.
- Responsive mobile layout; duplicate student number validation; empty states.

Use:
1. Extract ZIP and open index.html in a modern browser.
2. Add student information and choose an optional photo.
3. Open Student QR IDs, select a student, and tap Generate QR code.
4. Tap Download QR image to save it.

Important:
This is a prototype. Data and photos are stored in localStorage on this device/browser and are not synced to other devices. It does not have real user accounts or strong access controls. QR generation uses an online library and requires internet. Get school authorization before collecting student photos or real student records. Use a school-approved secure system for official use.
