redbrowser HTML APK converter package

Extract this ZIP with ZArchiver and select index.html as the start page. Configure the converter to keep website navigation inside its WebView where supported.

Includes browser/search settings, AI provider/model/key entry, voice sample testing, appearance/language preferences, local developer diagnostics and reset-to-defaults.

Important: Google and some sites block iframe embedding. A WebView converter may keep top-level navigation inside the app, but HTML cannot override website restrictions. The AI key is only held in page memory and is not sent to a service; create your own at https://platform.openai.com/api-keys. AI search engines are preferences until a backend is configured. Voice tests use device voices. Public-IP changes, accessing other people's servers, and fake premium unlocks are not implemented.
