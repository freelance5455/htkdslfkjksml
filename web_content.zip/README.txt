JARVIS Android — HTML-to-APK starter project

Import the ZIP into your HTML-to-APK Builder as a web project.

Included: JARVIS HUD, voice input when supported, speech output, local memory, AI endpoint settings, quick commands, and safe hooks for a native Android bridge.

IMPORTANT: HTML/JavaScript alone cannot read notifications in the background or obtain unrestricted control of Android. Background notification reading requires Android NotificationListenerService plus explicit user-granted Notification Access. Deep automation may require an AccessibilityService or other Android APIs and must respect Android security and user consent.

The JavaScript optionally calls:
  Android.openApp(packageName)
  Android.readNotifications()
  Android.openNotificationAccessSettings()
(or the same methods on window.Jarvis)

Your builder must provide a documented JavaScript-to-native bridge for those functions. If it does not, those features will not work merely by importing this ZIP.

AI: Do not distribute an APK containing a real API secret. For production, use your own backend/proxy. The Settings screen is intended for testing.
