CUANKITA - DEMO
================
Versi ini adalah website/PWA demo yang dapat diubah menjadi APK menggunakan layanan HTML-to-APK.

FITUR:
- Dashboard
- Sistem poin demo
- Rewarded-ad simulator
- Check-in
- Marketplace tugas demo
- Referral demo
- Wallet & withdrawal demo
- Riwayat transaksi
- Profil
- LocalStorage

PENTING:
Saldo pada versi ini adalah SIMULASI LOKAL, bukan uang sungguhan.
Untuk production perlu backend server, autentikasi, database, ad provider,
offerwall/provider tugas, affiliate tracking, anti-fraud, dan payment provider.
Jangan mengiklankan saldo demo sebagai uang yang dapat dicairkan.

CARA:
1. Upload ZIP ini ke layanan HTML-to-APK.
2. Pastikan index.html berada di root ZIP.
3. Build APK.
4. Untuk production, ganti sistem demo dengan backend nyata.
