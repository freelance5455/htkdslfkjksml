الإصدار 3.0 - إصلاح حقيقي لوظائف APK

تم تعديل HTML نفسه وواجهة Android WebView معًا.

1) النسخ الاحتياطي داخل APK:
   JavaScript يرسل JSON إلى AndroidApp.saveBackup().
   Android يحفظ الملف مباشرة في Downloads باستخدام MediaStore.
   لا يعتمد على Blob URL أو DownloadListener.

2) الاستعادة داخل APK:
   JavaScript يطلب AndroidApp.openBackupPicker().
   Android يفتح ACTION_OPEN_DOCUMENT، يقرأ الملف، يحوله Base64، ثم يعيده إلى JavaScript.
   المتصفح/المعاينة ما زالت تستخدم input + FileReader الطبيعي.

3) الطباعة داخل APK:
   printCategory() يستدعي AndroidApp.printPage() إذا كان التطبيق APK.
   Android يستخدم PrintManager/CreatePrintDocumentAdapter.
   المعاينة تستخدم window.print() الطبيعي.

4) فحص JavaScript:
   تم تشغيل node --check على JavaScript المستخرج من index.html وكانت النتيجة ناجحة.

مهم: لا يمكنني تشغيل APK فعليًا داخل بيئة المحادثة، لذلك لا أدعي أنني اختبرت نافذة Android الفعلية. لكن مسار الوظائف لم يعد يعتمد على واجهات WebView التي كانت سبب الخلل السابق.
