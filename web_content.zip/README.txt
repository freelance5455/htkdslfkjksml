DG GAMES — ADMIN PANEL (alag app)
=================================
Sirf admin ke liye. Players ko yeh zip mat do. index.html zip ke root mein hai.

LOGIN: email nabeeleditsofficial@gmail.com (password chat mein bataya gaya hai).
Login ke baad Dashboard -> "My account" mein password badal lo.

IS VERSION MEIN FIX (games add nahi ho rahi thi)
- Galti ka message ab SAAF nazar aata hai: screen par message aata hai, form khud wahi field par le jata hai
  (jo bhara nahi) aur us field ko laal kar deta hai. Pehle message form ke sabse neeche chhupa rehta tha.
- "Save" button ab hamesha neeche dikhta hai, lamba form scroll karne ki zaroorat nahi.
- File dene wale boxes ab asli file-input hain (hidden nahi), isliye zyada phones / APK builders mein picker khulta hai.
- HTML game ke liye 4 tareeqe: (1) HTML file chuno, (2) HTML code paste karo (kitne characters aaye wo dikhta hai),
  (3) .html file ka link daal kar "Load" dabao, (4) "In-app link" mode mein game ka page link do.
- Naya mode "In-app link": game kisi bhi free hosting par rakho (Netlify Drop, GitHub Pages) aur link paste karo.

TABS
- Dashboard : Website ON/OFF, App ON/OFF, announcement, "Default Ludo look & rules", Ludo coin settings, password change.
- Games     : naya game / edit / hide / delete.
- Events    : naya event (poster, entry, prize, MODE, THEME, reward, end time) + notification.
- Shop      : profile pictures aur banners (avatar yahin se add hote hain).
- Users     : ID, coins, rank points; "± Coins"; Suspend / Restore.
- Support   : player messages ka jawab.
- Content   : contact details, About, Rules, FAQ.

AGAR PHIR BHI FILE PICKER NA KHULE
Kuch APK builders file picker bilkul allow nahi karte. Tab paste ya link wale tareeqe use karo, ya admin panel ko
Chrome mein kholo (hosting par rakh kar) — wahan file picker hamesha chalta hai. Ya HTML file mujhe chat mein bhej do,
main server mein daal dunga.

NAYA MODE / THEME (BINA APP BADLE)
Event form mein "Game mode" aur "Theme" chuno, neeche JSON bhar jata hai (edit kar sakte ho).
Rules: tokens, tokens_to_win, exit_on, extra_on_six/capture/home, three_sixes, safe_stars, turn_seconds, dice_weights.
Theme: title, emoji, accent, accent2, bg, panel, board, track, dice, dice_dot, colors{red,green,yellow,blue},
token_shape (circle|square|diamond|star), bg_image, board_image, css.
Kisi bhi setting mein "until": "2026-11-01T00:00:00+05:00" likho to us waqt ke baad wo khud hat jati hai.

APK: yeh zip seedha "website to APK" builder mein upload karo (App name: DG GAMES Admin, icon: icons/icon-512.png).
