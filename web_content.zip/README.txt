EthioLearn Educational App project for ZIP-to-APK builders

Files: index.html, manifest.json, sw.js, icon-192.png, icon-512.png.
Features: responsive student dashboard, starter notes in Mathematics, Physics, Chemistry, Biology, English, and Aptitude; multiple-choice quizzes with explanations and scores; entrance-exam weekly checklist; optional local profile; English/Afaan Oromoo welcome text toggle; local progress storage.
This ZIP is a web project, NOT a compiled APK. Upload it to a ZIP/HTML-to-APK builder.
Important: the notes and questions are starter examples, not an official Ethiopian curriculum or official exam paper. The app stores the profile and quiz count locally in the app's browser storage. A builder's offline support depends on its WebView and hosting configuration. This app does not include AI generation or online video streaming.
