آسمان v6.4 — راهنمای آپلود

همه‌ی این فایل‌ها را کنار هم در یک پوشه (ریشه‌ی سایت) آپلود کن:

  index.html              خود برنامه
  manifest.webmanifest    برای نصب روی صفحه‌ی اصلی
  sw.js                   کارکرد آفلاین
  icon-192.png  icon-512.png  icon-maskable-512.png  apple-touch-icon.png
  og.jpg                  تصویر پیش‌نمایش لینک (تلگرام، توییتر، ...)

فونت وزیرمتن (اختیاری، پیشنهادی):
  فایل Vazirmatn را با یکی از این دو نام کنار index.html بگذار:
     Vazirmatn.woff2   (بهتر؛ نسخه‌ی variable)
     Vazirmatn.ttf
  اگر فایل نباشد برنامه بدون خطا با فونت پیش‌فرض دستگاه اجرا می‌شود.

بعد از آپلود فقط یک کار:
  داخل index.html دو خط og:image و twitter:image را به آدرس کامل تبدیل کن:
     https://دامنه‌ی-تو/og.jpg
