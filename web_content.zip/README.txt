AR Chat updated: per-contact Appearance colours, Online/Last seen, functional settings panels, no fake AR Chat Support contact, and contact-based private chat routing.
