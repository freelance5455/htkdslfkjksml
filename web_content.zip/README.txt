GARAGEM KIDS V13 — HTML TO APK

Arquivo principal: index.html

V13 inclui:
- Resumo inicial com Aluguéis e Produtos (quantidade de unidades vendidas no dia)
- Edição de despesas já registradas em Movimentações
- Relatório Financeiro por dia, mês, ano ou período personalizado
- Faturamento - Despesas - Custo da Mercadoria Vendida = Resultado Financeiro
- Custo da mercadoria vendida calculado somente sobre produtos vendidos
- Formato simples para conversão em APK e operação offline
