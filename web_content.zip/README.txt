Pizza Nagar Billing POS
========================
Mobile-friendly billing software prototype.

Features:
- New Order
- Product/category selection
- Quantity controls
- Customer, phone, order type and payment
- Save order
- Print bill
- Daily sales, order count, items and profit
- Date-range reports
- Add/edit/delete products
- Cost price for profit calculation
- Data saved locally in the browser (localStorage)

How to use on Android:
1. Extract the ZIP and open index.html in Chrome.
2. For a permanent app icon, the same interface can be hosted as a PWA/web app.
3. For real printer/Bluetooth support, an Android app wrapper and printer-specific integration can be added.
