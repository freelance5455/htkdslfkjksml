Sabzi Khata / سبزی کھاتہ — bilingual offline browser app

Open index.html in Chrome on your phone. The app saves its records in the browser storage on that device and works offline once the file is saved locally. Use Reports & Backup > Download JSON Backup regularly.

Features: customers and contact details, customer khata/receivables, vegetables with cost and selling rates, stock, sales, purchases, payments, expenses, estimated profit, transaction history, reports, CSV export, JSON backup/restore, English/Urdu interface.

Important: this is a local browser app, not a public hosted website. Records are saved on this device/browser and do not sync between phones.
