MORROW WEBSITE ZIP (for ZIP-to-APK website wrapper apps)

The converter complained because the previous ZIP was a Flutter source project and did not contain index.html.

This ZIP is a small website package and contains index.html at the ROOT of the archive.
Select this ZIP in the website-to-APK converter.

Important:
- This creates a WebView-style APK that displays the Morrow website, not a native Flutter APK.
- Data is saved locally in the browser/WebView on that device.
- This starter does not include cloud sync, real Auri AI, push notifications, or account sign-in.
- The ZIP is designed to be small and offline-friendly.
