APEX F1 PWA — o‘rnatish yo‘riqnomasi

1. Barcha fayllarni bitta papkada saqlang: index.html, manifest.json, service-worker.js va icons/.
2. Papkani HTTPS hostingga joylang (masalan, GitHub Pages).
3. Sayt manzilini Android Chrome’da oching.
4. “Ilovani o‘rnatish” tugmasini bosing yoki Chrome menyusidan “Ilovani o‘rnatish”ni tanlang.

Muhim:
- PWA HTTPS orqali ishlaydi (localhost bundan mustasno). Acode ichidagi file:/// manzili yetarli emas.
- Offline holatda ilovaning asosiy sahifasi ochiladi; yangiliklar va reytinglar uchun internet kerak.
- Bu Android APK emas, o‘rnatiladigan veb-ilova (PWA).
