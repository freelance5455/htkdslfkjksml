QUIZ KING — Full Free Starter Project

Files:
- index.html: पूरा playable quiz app (20 questions, random 10-question quiz, score, best score, replay).
- README.txt: यह guide.

Phone पर demo:
1. ZIP extract करें.
2. index.html को Chrome में खोलें.

Monetization:
- App में AdMob के लिए ad-space placeholder दिया गया है.
- Real ads दिखाने के लिए अपना Google AdMob account और ad unit IDs चाहिए.
- AdMob/Play Store की policies follow करनी होंगी.
- कमाई की गारंटी नहीं है.

Important:
यह original starter design है; किसी दूसरे app का exact copy नहीं है.
