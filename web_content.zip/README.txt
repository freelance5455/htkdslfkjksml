CLIPTOK Web V1

This is a browser-based Progressive Web App (PWA) starter for CLIPTOK.
It uses the Appwrite project details supplied by the user:
Endpoint: https://nyc.cloud.appwrite.io/v1
Project ID: 6b029f4f0010fd7beca2
Storage bucket ID: cliptok_videos

IMPORTANT
- This is a starter, not a finished TikTok clone.
- It implements Appwrite email/password sign-up/sign-in and video upload/listing from Storage.
- It does not yet implement video metadata in the Videos table, likes, comments, follows, wallets,
  creator rewards, withdrawals, MTN/Airtel payouts, or admin tools.
- Appwrite bucket permissions and allowed web hostname must be configured.
- Serve over HTTPS. Do not open index.html directly from a file manager.
- APK conversion can be attempted after hosting the web app at an HTTPS address using a PWA/TWA
  packaging service. This ZIP itself is not an APK.
- Never put an Appwrite API key in browser code.

Quick start:
1. Extract this ZIP.
2. Host the files on an HTTPS static host.
3. In Appwrite Console, confirm Web platform hostname matches your hosted domain.
4. Confirm the cliptok_videos bucket allows authenticated users to create files and allows
   intended users to read files.
5. Open the hosted URL in Chrome and test sign-up and upload.
