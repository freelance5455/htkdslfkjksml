BLUEWAVE RADIO — Android home-screen web app

This is a safe radio tuner simulator. It does not transmit radio signals and does not include live stations.

To use it as an installable Android home-screen app:
1. Upload the contents of this folder to a secure HTTPS static website host.
2. Open that hosted website in Chrome on your Android device.
3. Open Chrome's three-dot menu and choose "Add to Home screen" or "Install app".

The included icon files use the radio image supplied in the chat.
