Rahvessa AI - ZIP-to-APK Web Package

This package is intentionally a WEB app because the ZIP-to-APK app shown in the screenshot requires a root index.html.

Files:
- index.html: app entry point
- assets/style.css: UI styling
- assets/app.js: chat/history/projects/settings logic

The app uses an OpenAI-compatible Chat Completions request. No API key is hard-coded.
Open Settings inside the app and enter your own API key.

Important:
1. A browser-based APK wrapper cannot compile the original Java Android sources.
2. This package is designed for ZIP-to-APK tools that turn an HTML website into an APK.
3. Internet access is required for AI requests.
4. Never publish a secret API key in a public website. This demo stores a user-entered key locally on the device.
