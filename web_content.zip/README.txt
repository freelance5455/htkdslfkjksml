ALPHA VEHICLE ANALYTICS – FULL APP (APKFORGE HTML ZIP)

UPLOAD:
Upload this ZIP to APKForge. The ZIP contains index.html at the root.

LOGIN:
2323

FEATURES:
- Daily vehicle totals, one record per date; edit/delete existing records.
- Calendar-month totals (1st to month end) compared with the same dates in the previous year.
- 21st to following month's 20th period comparison with previous year.
- Daily comparisons against the same calendar date in the previous year.
- Daily target entry. Targets are summed for either reporting period and compared with actual totals.
- PDF report generation and print/save-as-PDF fallback.
- JSON backup and restore.
- Local offline data storage using browser localStorage.

IMPORTANT APKFORGE NOTE:
This is a full HTML app package, but it cannot force the APK wrapper to grant Android WebView storage or file-download support. The earlier test showed that localStorage and browser downloads did not work in your generated APK. If they still fail, APKForge must enable JavaScript DOM storage and WebView file downloads / a native file-save bridge in its project settings. The app code alone cannot grant Android permissions or change the wrapper's native WebView configuration.

TEST AFTER BUILD:
1. Login with 2323.
2. Save a date and count, close and reopen app; check whether the record remains.
3. Save the same date again; it should block duplicate entry.
4. Edit the existing date.
5. Generate PDF and JSON backup; check Downloads.
6. Restore JSON backup.
7. Check Analysis and Targets.

PDF direct download is attempted from the app. Print / Save as PDF is a fallback if APKForge allows popup windows and Android printing.
