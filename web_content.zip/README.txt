CASIO fx-991ES PLUS 2nd edition (black) - web calculator
Open index.html in any browser. Fully offline, single file, no dependencies.
Features: textbook (Math I/O) display, MODE/SETUP menu, HELP, CLR reset (SHIFT+9).
