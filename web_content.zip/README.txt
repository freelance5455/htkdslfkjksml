MT5 Analyzer V3 - Android-friendly

Open index.html in a mobile browser.

Enter:
- Instrument (e.g. XAUUSD)
- Timeframe
- Current price
- EMA 20
- EMA 50
- RSI 14
- MACD
- MACD Signal

Press ANALYZE.

The result is a rule-based historical/current-indicator interpretation. It does not connect to MT5, place orders, or guarantee future price movements.

For a real live-data version, a broker/API connection would be required.
