VAISHNAV WORLD — UPDATED ADMIN PANEL

This package contains the updated Admin web app arranged for a WebView wrapper that loads:
https://appassets.androidplatform.net/web/index.html

Included:
- Professional responsive Admin UI with SVG icons
- Dashboard, Devotees, Yatra, Courses, Book Store, Posters
- Bhakti Content, Prabhupada Today, Calendar, YouTube
- Weekly Challenge
- Separate Hindi and Bengali quiz editors
- Combined quiz leaderboard view
- Notification records
- Yatra status, per-member seat number and ticket upload
- Firebase Realtime Database integration
- Firebase Storage image/file upload for books, posters and Yatra tickets

Important:
- The current admin login password is a prototype client-side code: 2011. This is not production-grade authentication.
- Firebase Security Rules must protect admin writes before public launch.
- Storage uploads require appropriate Firebase Storage rules and an enabled Storage setup/plan.
- This package is web assets, not an APK by itself.
