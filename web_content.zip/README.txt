# NEET Biology CBT — Module 01 Full Question Bank

This project contains 954 MCQs extracted from the uploaded Biology Module 01 PDF using text extraction and the PDF's answer-key sections.

Included:
- Chapter and section filters
- Random mode and line-by-line sequential mode
- 20 / 50 / 100 / all available questions
- Configurable timer
- +4 / -1 marking
- Automatic submission
- Score, correct, wrong, skipped and accuracy
- Answer review with source chapter, section and PDF page

Run:
1. Keep all four files in the same folder.
2. Open index.html in a browser.
3. For Android, wrap the folder in a WebView/HTML-to-APK builder.

Note:
A small number of PDF questions had incomplete or non-text options in the extracted layer and were not included. The app uses the PDF answer key for automatic checking.
