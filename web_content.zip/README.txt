SUPER QUIZ - PACOTE PARA ZIP TO APK

Conteúdo:
- index.html: jogo completo em HTML, CSS e JavaScript.
- README.txt: estas instruções.

Como usar:
1. Extrai o ficheiro ZIP, se a aplicação pedir.
2. No ZIP to APK, escolhe criar/importar projeto a partir de ZIP.
3. Seleciona este ficheiro ZIP.
4. Define index.html como página inicial, se essa opção aparecer.
5. Gera o APK.

Nota:
Este pacote não usa PHP nem session_start(). O jogo funciona no navegador/WebView
com HTML, CSS e JavaScript. O conteúdo inclui 2 desafios com 15 perguntas cada.
