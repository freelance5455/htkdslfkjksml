WATER SORT PUZZLE  -  Created by Abdul Wajed Adel

RUN OFFLINE
1. Extract Water_Sort_Puzzle.zip (keep all files together).
2. Open index.html in any modern browser (Chrome on Android or desktop).
No internet, install or build tools needed. Progress and settings are saved in localStorage.

HOW TO PLAY
Tap a bottle, then tap another to pour. Liquid goes only onto the same top color or an empty
bottle, if there is room. Sort so each bottle holds one color. UNDO: 3 per level.
HINT shows a move. Levels are procedurally generated and verified solvable by a solver.

PACKAGE AS AN ANDROID APP (WebView wrapper)
Option A - Android Studio:
 1. New Project > Empty Views Activity.
 2. Copy index.html, style.css, script.js into app/src/main/assets/
 3. Layout: add a <WebView android:id="@+id/web" .../> filling the screen.
 4. In MainActivity: web.settings.javaScriptEnabled=true; web.settings.domStorageEnabled=true;
    web.loadUrl("file:///android_asset/index.html")
 5. Build > Build APK.
Option B - Capacitor/Cordova: put the three files in the web folder (www), then
 "npx cap add android", "npx cap sync", open in Android Studio and build.
Option C - online "HTML to APK" tools: upload the ZIP.
Enable domStorage so saving works.
