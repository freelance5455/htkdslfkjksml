এই ফোল্ডারটি যেকোনো HTTPS হোস্টিংয়ে আপলোড করুন (যেমন Netlify Drop, Cloudflare Pages, GitHub Pages)।
তারপর ফোনের Chrome-এ লিংক খুলে মেনু → "Install app" / "Add to Home screen" চাপুন।
iPhone: Safari → Share → Add to Home Screen।
