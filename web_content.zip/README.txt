IQ-próba Android projekt
========================
A projekt Android Studio-ban nyitható meg. Az app offline működik, 20 magyar nyelvű logikai kérdést tartalmaz.
Az Android Studio-ban: Open -> válaszd ki ezt a mappát -> várd meg a Gradle szinkronizálást -> Build > Build APK(s).
Az APK-t az Android Studio az app/build/outputs/apk/debug/ mappába teszi.

Fontos: ez gyakorló logikai teszt, nem standardizált pszichometriai IQ-teszt. A százalékos eredmény nem valódi IQ-pontszám.
