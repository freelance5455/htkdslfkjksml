DERIV PRO - CURRENT FIXED PROJECT
=================================

This is the current HTML/CSS/JavaScript version of the Deriv PRO live market scanner.

MAIN FIX
--------
The previous error:
  "Deriv API: Input validation failed: subscribe"

is addressed by sending the tick subscription in the correct format:

{
  "ticks": "<actual_symbol>",
  "subscribe": 1
}

The scanner first requests active_symbols, obtains actual market symbols, then subscribes using those symbols. Market-data access is public and does not require a trading token.

FILES
-----
index.html
style.css
app.js

HOW TO TEST ON ANDROID
----------------------
1. Extract the ZIP.
2. Open index.html in a browser.
3. Allow the browser to use the internet.
4. Wait for the status to change from CONNECTING to LIVE.
5. You should then see live derived/synthetic tick cards.

IMPORTANT
---------
This is a READ-ONLY market scanner. It does not place trades.
Signals are technical/heuristic indicators, not guaranteed predictions.

APK
---
For an APK, the HTML project must be wrapped in an Android WebView/Capacitor project and built with Android tooling. The HTML files themselves are not an APK.
