MaliTask — projet Android de test
Ce projet encapsule le prototype HTML fourni dans une WebView Android.
Pour générer un APK, ouvrir le dossier dans Android Studio puis Build > Build APK(s).
L'APK obtenu est une version de test : missions, solde et validations restent simulés.
