JARVIS HTML TO APK STARTER

Main file: index.html

How to use:
1. Import/open index.html in your preferred HTML-to-APK builder.
2. Set the app name to JARVIS AI.
3. Allow microphone permission if your builder/WebView supports voice recognition.
4. Build and install the APK.

What works without a backend:
- Mobile-friendly futuristic JARVIS interface
- Chat UI
- Text-to-speech replies
- Voice input where supported
- Simple demo responses (date/time, greetings)

For full AI responses:
- Host a backend endpoint that accepts POST JSON with a `messages` array and returns JSON `{ "reply": "..." }`.
- Open AI setup in the app and enter that endpoint URL.
- Keep API keys on the server. Do not put secret API keys inside index.html or the APK.

Note: APK wrappers vary. Some WebViews do not support browser speech recognition or microphone permissions. This is an HTML project, not a precompiled APK.
