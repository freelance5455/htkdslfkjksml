Rajasthan Economic Survey Master Practice

Open index.html in a browser or package it in an Android WebView/Capacitor project.
The app contains chapter-wise practice, mock tests, revision tools, progress tracking, language selection and explanations.
English content is embedded. Hindi translation uses an online translation service and may require internet access.
