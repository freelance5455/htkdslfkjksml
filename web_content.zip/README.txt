RSI FAST SCALPER - MT4 + MT5
===============================

WHAT IS INCLUDED
----------------
1. RSI_Risk_Scalper_MT4.mq4  - MT4 Expert Advisor source
2. RSI_Risk_Scalper_MT5.mq5  - MT5 Expert Advisor source
3. dashboard.html             - mobile-friendly dashboard mock/control panel
4. README.txt

STRATEGY
--------
Based on the supplied screenshot:
- RSI period: 14
- Buy at/below RSI 30
- Sell at/above RSI 70
- SL: 100 points
- TP: 150 points
- Starting lot: 0.01

The EA adds safety controls:
- maximum lot
- maximum open trades
- maximum trades per minute
- cooldown
- maximum spread
- daily loss limit
- account drawdown limit
- consecutive-loss shutdown
- margin check
- profit-based lot increase
- lot reset after a losing trade

IMPORTANT
---------
This is an execution engine, not a profit guarantee. RSI scalping can lose money.
Test it on a DEMO account first.

SPEED
-----
MT5 supports OrderSendAsync for asynchronous requests. The EA exposes
UseAsyncOrders, but it defaults to false because the safer behavior is to
wait for normal trade processing. Async mode does NOT guarantee 1000 trades
per second: broker/server limits, execution model, symbol rules and latency
still control actual throughput.

MT4 uses OrderSend, which is synchronous.

ANDROID APK
-----------
A true Android APK that remotely START/STOPs a broker-side EA needs a bridge
service because the EA runs inside MT4/MT5 and the phone is not the broker
terminal. The included dashboard.html is a visual/mobile dashboard prototype;
it is NOT falsely presented as a live broker controller.

To make a production APK, the next component is:
Android app -> authenticated HTTPS bridge -> MT4/MT5 EA.
The EA should poll the bridge for START/STOP and settings, while the app reads
telemetry from the bridge.

INSTALL MT4
-----------
Copy the .mq4 file to:
MQL4/Experts/
Open MetaEditor -> compile -> attach EA to a chart -> enable AutoTrading.

INSTALL MT5
-----------
Copy the .mq5 file to:
MQL5/Experts/
Open MetaEditor -> compile -> attach EA to a chart -> enable Algo Trading.

BROKER COMPATIBILITY
--------------------
No EA can literally guarantee compatibility with every broker. Broker symbol
names, minimum lot, lot step, stop levels, execution modes, hedging/netting
rules, spread and trade-frequency limits vary. The code reads broker lot
constraints where possible and applies its own risk caps.

RECOMMENDED INITIAL DEMO SETTINGS
---------------------------------
LotSize=0.01
LotIncrement=0.01
MaxLotSize=0.05
MaxOpenTrades=1
MaxTradesPerMinute=10
CooldownSeconds=2
MaxDailyLossPct=2
MaxDrawdownPct=5
MaxConsecutiveLosses=2

Only increase limits after testing on the exact broker/symbol/account type.
