CANCIONERO - Proyecto Android

Este proyecto empaqueta la aplicación web localmente dentro de una app Android.
No depende del sitio publicado en Netlify y no carga la página web remota.
Por tanto, la insignia "Powered by Netlify" que se inyectaba en el sitio publicado
no forma parte de esta versión empaquetada.

Cómo generar el APK:
1. Instala Android Studio.
2. Abre la carpeta CancioneroAndroid.
3. Espera a que Gradle sincronice y descargue los componentes necesarios.
4. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
5. El APK de depuración aparecerá en app/build/outputs/apk/debug/app-debug.apk.

Notas:
- El identificador de paquete es com.cancionero.app.
- Nombre visible: Cancionero.
- Se conservan el HTML y los iconos originales.
- Esta carpeta es un proyecto Android Studio; no es todavía un APK compilado.
