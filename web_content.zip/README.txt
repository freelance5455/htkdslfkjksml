NOVA ULTIMATE AI — ZIP web prêt à importer

CONTENU
- index.html à la racine
- style.css
- app.js
- assets/ (réservé aux visuels)

UTILISATION
1. Décompressez le ZIP ou importez-le directement dans votre convertisseur ZIP-vers-APK.
2. Ouvrez index.html comme page d'accueil.
3. Dans « Réglages API », choisissez le fournisseur et saisissez vos clés.
4. Appuyez sur « Enregistrer toutes les clés ».

IMPORTANT — LIMITES DE CETTE VERSION
Cette livraison est une interface autonome de centralisation des clés et de préparation du studio. Elle sauvegarde les valeurs dans le stockage local de l'application. Elle ne réalise pas encore les appels de génération aux fournisseurs : une clé API seule ne suffit pas. Chaque fournisseur a des routes, modèles, formats et règles d'authentification propres. Les appels depuis une page web peuvent aussi être bloqués par CORS. Les intégrations réelles de Gemini, RunAPI et KIE AI doivent être ajoutées selon la documentation exacte des API et, idéalement, via un serveur sécurisé.

SÉCURITÉ
- Ne mettez jamais de vraies clés dans le code source ou dans le ZIP.
- Ne partagez pas une capture d'écran montrant une clé.
- Ne collez pas vos clés dans une conversation.
- Une application web locale n'est pas un coffre-fort : toute personne ayant accès à l'appareil peut potentiellement accéder aux données du navigateur.
- Le bouton « Enregistrer » confirme uniquement la sauvegarde locale, pas la validité de la clé.

Format : HTML / CSS / JavaScript simple, sans React, Vite ou Node.js.
