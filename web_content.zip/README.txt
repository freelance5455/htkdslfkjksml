MUBASHIR BUMRAAA - FIXED HTML ZIP

IMPORTANT:
1. Extract this ZIP first.
2. For playing on Android, open the extracted index.html using Chrome (choose Open with > Chrome).
3. Do not open the ZIP preview inside a file manager or an app-builder preview.
4. If your app builder specifically shows the URL appassets.androidplatform.net/web/index.html, import/copy the included web/index.html into the builder's web asset folder so that the final path is assets/web/index.html (or the builder's equivalent web folder).

This is a self-contained offline browser game. It does not need internet to play locally, and has no real online multiplayer server. A ZIP is not an installable APK.
