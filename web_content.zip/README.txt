Crypto Max PRO (نسخة ويب) — Directed by Bilal
index.html في جذر الأرشيف (مطلوب لأداة «موقع مضغوط»). ملف واحد بلا مكتبات خارجية.
الأسعار من CoinGecko مباشرة من المتصفح. فرص المكافآت: رابط JSON تضبطه من الإعدادات، أو إضافة يدوية.
صيغة JSON: الحقول id و project إلزامية؛ راجع مشروع Android (docs/REWARDS_FEED.md).
