Otaku Decoration - ملف المشروع
index.html = التطبيق كامل | icon.png = الأيقونة | manifest.json = بيانات التطبيق
حوّله لـ APK: ارفع الـ Zip على WebIntoApp أو AppsGeyser (Zip/HTML to APK) أو استخدم Capacitor.
