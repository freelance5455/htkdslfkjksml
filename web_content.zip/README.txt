Photo Studio - Photo Picker Fix

This ZIP changes the photo input so it is not display:none; some Android WebView wrappers fail to open the picker for hidden inputs.

Upload this ZIP to your APK builder and build a new APK. If tapping the button still does nothing, the APK builder must implement Android WebView file chooser support (WebChromeClient.onShowFileChooser); HTML alone cannot fix a builder that lacks that native support.
