Smart Store Manager PDF export fix

APK Forge input: upload this ZIP using HTML to App > Zipped Site.
The ZIP contains index.html at its root.

PDF export now tries Android's native file share sheet first (when supported),
then uses a persistent Blob download link and opens the generated PDF as a fallback.
Backup restore by pasted JSON remains available in Backup / Settings.

Keep the old installed app and its original records untouched until the new build
has been tested and the records have been verified.
