TownLife RP

Open index.html in a modern browser (Chrome recommended). Works on mobile and desktop.

Features: on-screen joystick, walking, jumping, cars, houses, coins, avatar styles, seven language choices, guest mode, local save data, and a Halloween mode with ghosts, bats and pumpkins.

Save data is stored locally in the browser on this device. This prototype does not include cloud accounts or cross-device syncing. Keep using the same browser and avoid clearing its site data to preserve progress.
