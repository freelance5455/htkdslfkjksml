Kunwar Estate PRO - Edit Deal Edition

Edit button is available for existing deals. It opens the deal form with saved details; save updates the same deal instead of creating a duplicate. Owner/Customer UPI and WhatsApp fields are retained.
