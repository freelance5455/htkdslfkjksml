GoalPulse update 1.1.0
Package name: com.goalpulse.football
Version name: 1.1.0
Version code: 2

Update: Live match cards are now tappable and open match details/events using the fixture ID and API-Football.
Do not include or paste the API key into this ZIP; enter it inside GoalPulse Settings.
