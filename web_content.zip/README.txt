WORLD ONE // THE VEIL
========================

This package is a mobile-first WebGL prototype of the approved concept.

Included:
- 3D green world with open sky and rolling terrain
- autonomous humanoid being
- needs: energy, hunger, thirst, curiosity
- memory, emotions, personality and an internal self-model
- no direct player-command system
- unexplained events that can influence the being's beliefs
- rain, snow, clear weather, anomaly, resource and new-being controls
- persistent local save
- real-world elapsed-time catch-up after reopening
- touch/pointer camera controls
- no external CDN dependency

Important:
The "soul" is represented as a persistent simulated identity/self-model, not a claim of real consciousness.
This is a playable browser/WebView build, not a compiled native APK. The current environment does not contain an Android SDK/Gradle toolchain, so a signed APK cannot honestly be produced here.
