EchoPod HTML-to-APK Builder Package

Contains index.html, which opens the hosted EchoPod music app in a full-screen frame.

Important:
- This is a lightweight wrapper/launcher, not the complete offline source of the EchoPod app.
- Internet access is required.
- Use an HTML-to-APK builder that accepts a ZIP containing index.html and permits a hosted URL/iframe.
- If the builder blocks iframes or remote content, this package may not work with that builder. In that case, use a WebView URL mode and enter https://echopod-fae7xo.v2.appdeploy.ai/ directly.
