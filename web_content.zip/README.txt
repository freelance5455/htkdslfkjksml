========================================
  FINANÇAS DO CASAL - BB  →  APK
========================================

Este pacote contém o app web pronto para ser
transformado em APK instalável.

COMO GERAR O APK (mais fácil e gratuito):

1. Acesse um destes sites (recomendados):
   • https://www.htmltoapp.net/
   • https://htmltoapk.com/
   • https://www.ziptoapk.com/

2. Faça upload do arquivo:
   financas-casal-app.zip   (este mesmo ZIP)

3. Configure:
   - Nome do App: Finanças do Casal
   - Package name: com.casal.financasbb
     (ou qualquer com.seunome.financas)
   - Ícone: use o icon-512.png que está dentro da pasta www
   - Orientação: Portrait (vertical)

4. Clique em Build / Gerar APK

5. Baixe o APK e instale no celular
   (pode precisar ativar "Fontes desconhecidas")

========================================
Observações importantes:
- O app usa Firebase + internet (precisa de conexão)
- A chave da API Gemini está vazia no código
  (o botão "IA BB" não funcionará até você colocar uma chave)
- Os usuários padrão são: lucas / sofia e maria / sofia
- Código priv para criar usuário: 7014095
========================================
