خبر میدان یار
فایل‌ها را در یک پوشه قرار دهید:
index.html
login.html
dashboard.html

ورود مالک:
نام کاربری: velayati
رمز عبور: 5196931f

صفحه اصلی را با index.html اجرا کنید.
