APK-ready static bundle.
- Removed absolute /src paths.
- Removed file://-blocked ES module entry; app is bundled into classic bundle.js.
- Tailwind is loaded in browser mode; fonts remain external.
- Local API falls back to localStorage when no server is available.
