# حسابها — Professional Test Build

هذه نسخة Frontend/PWA احترافية قابلة للاختبار الآن.

تحتوي على:
- لوحة تحكم
- العملاء
- العمليات والمبيعات والتحصيل
- إدخال صوتي عربي مع شاشة تأكيد
- أرقام عربية/إنجليزية
- كشف حساب ومشاركة
- نسخة احتياطية واستعادة
- إعدادات التاجر
- تصميم Mobile-first
- PWA + Service Worker

## مهم
هذه النسخة لا تحتوي على Backend حقيقي ولا Paymob Live ولا اشتراكات المتجر حتى الآن.
بعد اعتماد بنية الخادم وموافقة Paymob، نربط:
App → Secure Backend → Payment provider
ولا نضع Secret Keys داخل التطبيق.

للاختبار في HTML to APK Builder:
Start URL = index.html
Package ID = com.hisabha.app
