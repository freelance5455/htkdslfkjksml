WhatsApp Share Fix – ProBill Cafe 3in1

This patch replaces only the bill-share handler in:
assets/web/ProBill_Cafe_3in1/index.html

Fix: avoids the unsupported whatsapp:// URL scheme. It first uses Android/Web Share (choose WhatsApp from the share sheet); if unavailable, it opens the HTTPS WhatsApp share URL with the bill text prefilled.

Apply this file to the same path in the Android project assets and rebuild/sign the APK. This ZIP is a source-asset patch, not an installable APK.
No billing, menu, pricing, history, stock, PIN, or settings logic is intentionally changed.
