FITTRACK FINAL
Open index.html in a browser. The app stores data in localStorage on the device/browser.

Features:
- Diet, 2500 kcal default target, protein tracking
- Body weight and waist tracking
- Editable PPL/workout plan
- Workout logging with 3 default sets and unlimited added sets
- Exact workout history with date, exercise, sets, weight, reps, notes
- Edit/delete old workouts
- Rename workout names and exercises; add/remove exercises
- Offline local storage
- No floor barbell pullover is included in the default plan
