AI Voice Studio v2

Features:
- Video upload (500 MB app limit)
- Video -> Text using ElevenLabs Scribe v2
- Copy transcript
- Final script box for translated/edited text
- 9 configurable voices
- AI voice generation
- Speed, pitch, volume controls
- Audio download
- Upload generated audio + original video
- Mute original video audio or keep/mix it
- Fit new audio to video duration automatically using FFmpeg
- Final video download

Setup:
1. Install Python 3.
2. Install packages: pip install -r requirements.txt
3. Install FFmpeg and make sure `ffmpeg` and `ffprobe` are in PATH.
4. Copy .env.example to .env.
5. Add ElevenLabs API key and your 9 voice IDs.
6. Run: python app.py
7. Open: http://127.0.0.1:5000

Important:
- Do not put API keys in index.html.
- API usage may consume paid/free-tier credits according to your provider plan.
- This version does NOT do lip-sync.
- "Fit Audio" changes the generated audio speed to match the video duration. Extreme duration differences can make speech sound unnatural; a warning/limit should be added for production.
- This is a prototype, not a production-grade public service.
