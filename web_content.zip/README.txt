GALI RUSH: APP PACKAGE
======================

Is folder mein game ka poora app package hai (PWA):
  index.html            game
  manifest.webmanifest  app ka naam, icon, full screen setting
  sw.js                 offline chalane ke liye
  icons/                app icons

Ye files kisi website (https) par honi chahiye, tabhi phone mein app install hota hai.


STEP 1: HOST KARO (free, 5 minute)
----------------------------------
Option A: Netlify Drop
  1. app.netlify.com/drop kholo (account banana pad sakta hai).
  2. Is poore folder ko page par drag and drop karo.
  3. Aapko ek https link milega.

Option B: GitHub Pages
  1. GitHub par naya repository banao, in files ko upload karo.
  2. Settings > Pages > Branch: main > Save.
  3. Link: https://<aapka-naam>.github.io/<repo-ka-naam>/

Option C: Cloudflare Pages (Direct Upload), ya koi bhi aur static hosting.


STEP 2: PHONE PAR APP INSTALL KARO
----------------------------------
Android (Chrome): link kholo, "SHURU KARO" ke neeche "APP INSTALL KARO" dabao.
                  Ya Chrome menu (teen dot) > Install app / Add to Home screen.
iPhone (Safari):  Share button > Add to Home Screen.
Install ke baad icon home screen par aata hai, game full screen khulta hai aur
bina internet ke bhi chalta hai (pehli baar internet se ek baar kholna zaroori hai).


STEP 3 (OPTIONAL): APK / PLAY STORE
-----------------------------------
  1. pwabuilder.com kholo, apna https link daalo, Start dabao.
  2. Package for stores > Android > Generate.
  3. Download mein APK (khud install karne ke liye) aur AAB (Play Store ke liye) milte hain.
  Play Store par daalne ke liye Google Play Developer account chahiye
  (ek baar ka $25 fee).


UPDATE KAISE KAREIN
-------------------
Game badalne ke baad sw.js ki pehli line mein VERSION ka number badal do
(jaise gali-rush-v1 se gali-rush-v2), warna phones purana game dikhate rahenge.

Note: file:// se (double click karke) index.html khol sakte ho, par tab install
aur offline wali cheezein kaam nahi karti. Unke liye https chahiye.
