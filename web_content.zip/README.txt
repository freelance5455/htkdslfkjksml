v1.3 — Gift loading fix: fonts no longer block the gift script; name animation falls back to system fonts.

v1.1 — Hidden gift
- Type 1997 then press = to open the birthday gift "نجمة اسمها براءة" (assets/gift.html) full-screen. Close with × or the Android back button.
- The code is not saved in the operation history.

Baraa.c v1.0

Same calculator features as Dafaallah Calculator, using the Baraa logo and Baraa.c branding.
Operation history and stopwatch history include delete controls.
Data is stored locally in the app.

Theme selector added; history deletion works without confirmation dialogs.
