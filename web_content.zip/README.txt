NØVA - paczka strony do Zip to APK

WAŻNE: W ZIP plik index.html znajduje się w katalogu głównym archiwum (nie w podfolderze).

W kreatorze Zip to APK wybierz ten plik ZIP jako źródło. Ustaw nazwę NØVA i package id com.nova.tracker (jeśli kreator o to pyta).

Po zbudowaniu APK sprawdź aplikację na kilku zdjęciach testowych przed importem dużej biblioteki.
