Adrian Browser v1.0 - Pakiet do konwersji na APK
--------------------------------------------------
Autor: Adrian (Adrian Studio)
Przeznaczenie: Stare tablety z Android 4 (Optymalizacja wydajności, lekki interfejs, pełna płynność).

Instrukcja budowania pliku APK za pomocą aplikacji "HTML & ZIP File to APK Builder":
1. Pobierz aplikację "HTML & ZIP File to APK Builder" ze Sklepu Play.
2. Otwórz aplikację i wybierz opcję wgrania spakowanego archiwum ZIP (ten plik ZIP).
3. Wpisz nazwę aplikacji: Adrian Browser.
4. Ustaw wersję na 1.0 oraz skonfiguruj ikonę (opcjonalnie).
5. Kliknij przycisk budowania (Build APK).
6. Zainstaluj wygenerowany plik APK na tablecie z Android 4 i ciesz się szybkim przeglądaniem!

Zawartość paczki:
- index.html (główny interfejs przeglądarki z paskiem adresu, kafelkami startowymi i silnikiem nawigacji)
- style.css (stylowy, responsywny i lekki design zoptymalizowany pod starsze ekrany dotykowe)
- script.js (płynna logika obsługi adresów, zakładek i nawigacji)
