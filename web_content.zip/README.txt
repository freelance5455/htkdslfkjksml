Privacy Shield Suite v4 — ZIP-to-APK bridge

The ZIP root contains index.html so HTML/WebView ZIP-to-APK converters can
recognize the package.

The full native Android v4 project is stored in:
native-android/

IMPORTANT:
A generic ZIP-to-APK/WebView converter will package index.html only. It cannot
turn the native VpnService + TUN + tun2socks code into a real system VPN.
For the real v4 functionality, open native-android/ in Android Studio and
build the APK.

No converter can legitimately add Android VpnService capabilities to a plain
HTML page.
