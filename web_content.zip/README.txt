CONNECTLY - CHAT APPLICATION

1. Open Supabase Dashboard.
2. Open SQL Editor.
3. Paste database.sql and run it.
4. Open Authentication > Providers > Email.
5. Enable Email authentication.
6. Open Project Settings > API Keys.
7. Copy the publishable key.
8. Open index.html and replace:
   PASTE_YOUR_SUPABASE_PUBLISHABLE_KEY_HERE
   with your key.
9. ZIP the Connectly folder.
10. Upload the ZIP to your ZIP-to-APK converter.

This is an MVP. It requires an internet connection.
Do not use real customer data until security testing is complete.
