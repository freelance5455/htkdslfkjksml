REPORT PRODUZIONE WEB V2
Aprire index.html con Chrome, Edge o Firefox.
Non richiede server né installazione.
I dati vengono salvati nel localStorage del browser.
Per pubblicarla online: caricare index.html su un hosting statico.
