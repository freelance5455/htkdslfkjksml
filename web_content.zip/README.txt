طريقة تحويل التطبيق إلى APK
===========================
الطريقة السهلة (بدون برمجة):
1) ارفع مجلد www على استضافة مجانية (Netlify Drop أو GitHub Pages).
2) افتح pwabuilder.com والصق الرابط ثم اختر Android وحمّل ملف APK.

الطريقة الثانية (Capacitor) على الكمبيوتر:
  npm install
  npx cap add android
  npx cap sync
  npx cap open android   (ثم Build > Build APK من Android Studio)

ملاحظات:
- الإملاء الصوتي يعمل في Chrome مباشرة. داخل APK قد لا يعمل؛ حينها استخدم أيقونة الميكروفون في لوحة مفاتيح الهاتف (تعمل دائمًا)، أو أضف إضافة @capacitor-community/speech-recognition.
- البيانات تُحفظ على الجهاز؛ استخدم النسخ الاحتياطي من تبويب البيانات.

صلاحيات الكاميرا والميكروفون (مهم عند استخدام Capacitor):
بعد npx cap add android افتح android/app/src/main/AndroidManifest.xml وأضف داخل <manifest>:
  <uses-permission android:name="android.permission.CAMERA"/>
  <uses-permission android:name="android.permission.RECORD_AUDIO"/>
  <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS"/>
عند استخدام PWABuilder تُطلب الصلاحيات تلقائيًا من المتصفح.
