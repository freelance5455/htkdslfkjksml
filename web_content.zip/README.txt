SAKUKU - STARTER WEB APP UNTUK DIKEMAS MENJADI APK

Isi: index.html, style.css, script.js.

PENTING:
- Ini paket sumber web app, BUKAN APK terkompilasi.
- APK belum dibuat atau diuji. Gunakan layanan pembungkus HTML-ke-APK tepercaya untuk membuat berkas APK.
- Data Preview HCODX tidak otomatis masuk ke APK baru. Saldo Rp850.000 dan transaksi lama tetap di HCODX; CSV lama adalah cadangan terpisah.
- Aplikasi baru menyimpan transaksi pada localStorage perangkat/aplikasi ini. Ekspor CSV berkala.
- Sebelum memakai untuk pencatatan nyata, uji tambah transaksi, tutup-buka aplikasi, dan ekspor CSV.
