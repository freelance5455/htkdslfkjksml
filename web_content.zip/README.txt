JARVIS OMEGA ULTRA — ZIP com index.html na raiz

COMO USAR
1. Importe este ZIP no criador de app/site.
2. Toque em Visualizar.
3. Toque no botão ⚙ no topo para abrir Configuração Neural.
4. Cole sua chave Gemini, selecione o modelo e toque em TESTAR CONEXÃO.
5. Se o teste der certo, toque em SALVAR.
6. Faça perguntas no chat. Comandos locais funcionam mesmo sem Gemini.

CHAVE E SEGURANÇA
A chave pode ser mantida apenas na sessão ou salva no armazenamento local do navegador se marcar a opção. O armazenamento local não é um cofre seguro; uma chave usada no cliente pode ser extraída. Não publique nem distribua uma versão com sua chave. Para um app público, use um backend próprio para proteger a chave e impor limites.

RECURSOS
- HUD futurista responsiva
- Integração Gemini via REST Interactions API (modelo padrão gemini-3.8-flash)
- Campo de chave e teste de conexão
- Histórico de conversa durante a sessão
- Voz de saída e reconhecimento de voz quando suportados
- Atalhos para apps e sites
- Hora, status de rede e bateria se suportada
- Notas, tarefas, temporizador, exportação local
- Temas ciano/violeta

LIMITAÇÕES
- É um projeto web/PWA, não um APK nativo pronto.
- Abrir apps depende do Android, do navegador e dos apps instalados.
- Não controla silenciosamente todo o Android.
- Gemini requer internet, chave válida, modelo disponível e cota.
- Não cole uma chave em um app que você não controla.
