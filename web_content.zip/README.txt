Paper Blocks v4 - hand drawn block puzzle (HTML/CSS/JS/JSON)
Put the ZIP in your APK builder with index.html at the ZIP root.
Edit config.json for grid size, colors, scoring, sound default. Missing/failed config.json falls back to built-in defaults.
All art and sound is generated in code; no image or audio files are needed.
