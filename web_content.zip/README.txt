SULTHAN HACK TOOLS V5.0
========================

Isi ZIP:
- index.html: aplikasi web terminal hijau, animasi Matrix, menu tools, kalkulator, jam, status koneksi.

Cara pakai:
1. Di aplikasi pembuat APK, pilih Import Project ZIP.
2. Pilih file sulthan_hack_tools_v5.zip.
3. Jika diminta folder awal/start page, pilih index.html.
4. Atur nama aplikasi: SULTHAN HACK TOOLS.
5. Build/Export APK.

Catatan:
Fitur scan hanya simulasi visual. File ini tidak melakukan akses atau pemindaian perangkat/jaringan lain.
