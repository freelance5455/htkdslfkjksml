CARROM MASTER
==============
A polished, mobile-first offline carrom board game by Hunain Qk.

RUN OFFLINE
-----------
1. Extract the project ZIP.
2. Open index.html in a modern browser. No internet connection, account or server is required.
3. For a local development server, run `pnpm install` then `pnpm dev` from the project root.

GAME MODES
----------
- Play vs Computer: choose Easy, Medium or Hard AI. The computer lines up and shoots automatically.
- Two Players: pass the same phone or use a mouse/trackpad. Player 1 and Player 2 alternate turns.

CONTROLS
--------
- Move the striker with the position slider, the left/right buttons, keyboard arrows, or by dragging along the baseline.
- Touch/click directly on the striker and drag backward, away from the target, to aim. Release to shoot; the pull distance controls power. Touch elsewhere along the baseline to smoothly reposition the striker.
- The large SHOOT button performs a centered practice shot.
- Pause, sound, restart and home controls are available in the match header.
- Keyboard: Arrow Left/Right moves the striker, Space shoots, P pauses the match.

RULES IMPLEMENTED
-----------------
- 9 white coins, 9 black coins, 1 red queen and 1 striker.
- Coins and striker use sub-stepped physics, smooth friction, near-elastic collisions, boundary bounce and four-pocket detection. Fast shots are checked in small physics steps to reduce pieces passing through each other.
- Pocket your own colour to score and continue the turn.
- Pocketing the opponent's colour returns one coin to their remaining count.
- Pocketing the striker is a foul: one point is removed and the turn ends.
- The queen is worth 3 bonus points only when covered by a valid own-colour pocket in the same shot; otherwise it returns to the table.
- The game waits for all pieces to stop before resolving the turn. A player wins after clearing their nine coins.

SETTINGS
--------
- Classic Wooden, Dark Premium and Light Modern themes update the table immediately.
- Sound effects and ambient music can be toggled independently and persist locally.
- AI difficulty persists locally.

PROJECT FILES
-------------
index.html          Main offline app shell.
style.css           Responsive portrait UI and wooden board styling.
script.js           Canvas renderer, physics, game rules, AI, menus and controls.
assets/images/      Local logo and favicon artwork.
assets/sounds/      Local WAV sound cues and ambient loop.
assets/models/      Optional generated carrom-board.glb reference asset.

TECHNICAL NOTES
---------------
- The playable experience is dependency-free at runtime and uses Canvas 2D plus native Web Audio/Audio.
- All player-facing strings and gameplay are stored locally; the game does not make network requests.
- The Vite/TypeScript starter files in the full development project are not required for the extracted offline release ZIP.

Developer credit: Hunain Qk
