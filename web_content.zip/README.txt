LUDO MASTER - PROJETO ANDROID OFFLINE

O jogo roda localmente, sem internet, conta ou servidor.
Para gerar o APK: abra a pasta do projeto em AndroidIDE/Android Studio, configure o Android SDK e execute :app:assembleDebug.
O APK será criado em app/build/outputs/apk/debug/app-debug.apk.
Este pacote e o projeto-fonte; o APK binario ainda precisa ser compilado com Android SDK.
