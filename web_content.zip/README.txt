Ma Annapurna Health Center - standalone Android project

Doctor login:
ID: Dr.mpgupta4111
Password: Mpgupta879587@

Patient:
ID = prescription par diya gaya Patient ID
Password = registered mobile number

Prescription image:
- Camera/Gallery supported
- 30 MB per image

This build is standalone and does NOT depend on appassets.androidplatform.net or a web preview URL.

NOTE: I can provide the Android project here, but this environment does not have Android SDK/Gradle installed, so I cannot compile the APK binary here. Build this project with Android Studio/Gradle or an Android build service.
