MAYA KUTHIR WEBSITE
====================
ফাইল:
- index.html = মূল অনলাইন শপ
- admin.html = ডেমো Admin Panel
- style.css = ডিজাইন
- script.js = কার্ট ও অর্ডার সিস্টেম

মোবাইলে চালানো:
1. ZIP ফাইলটি Extract করুন।
2. index.html Chrome-এ খুলুন।
3. অনলাইনে দিতে হলে এই ফাইলগুলো কোনো static hosting service-এ upload করুন।

গুরুত্বপূর্ণ:
এটি একটি frontend/demo version। বর্তমানে অর্ডার ও পণ্যের তথ্য browser localStorage-এ থাকে।
বাস্তব ব্যবসার জন্য database, secure admin login, image upload, payment gateway এবং server/backend যুক্ত করা প্রয়োজন।
