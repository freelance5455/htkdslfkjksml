MEDICINE NAME GUESSING GAME

Files:
- index.html: the playable mobile-friendly game.

How to try it:
1. Extract the ZIP on your Android phone.
2. Open index.html in Chrome or another browser.

APK note:
This ZIP is a playable web game project, not a signed APK. To make an installable APK, the HTML game must be packaged with an Android wrapper/build service. You may need to sign in to a builder and download its generated APK. Do not install APKs from unknown or suspicious sources.

Safety:
This is a medicine-name quiz only, not medical advice. It does not recommend taking any medicine.
