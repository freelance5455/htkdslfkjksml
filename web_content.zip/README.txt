JARVIS mobile web-app APK build package.
index.html is at the ZIP root for ZIP-to-APK builders.
