SHESHA DELIVERY — whole-service test build
Included:
- Food
- Car spares
- Groceries
- Parcels
- Anything/custom request with photo + chat
- Customer address
- Transparent item + km + handling + tip total
- Order history
- Driver dashboard
- Admin pricing + adverts
- Android WebView project ready for Android Studio

IMPORTANT: This is a test/demo build. Automatic road-km calculation, real maps, live driver GPS, real payments, push notifications and backend/database still need production services/API keys.
The Android folder is an APK-ready source project, but an APK must be compiled with the Android SDK/Gradle toolchain.
