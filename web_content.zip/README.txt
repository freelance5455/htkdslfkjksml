StudyGlass - GSEB PCM study app (Class 11 and 12)

How to use
1. Unzip this folder.
2. Open index.html in Chrome or Safari. It works offline and has no other files.
3. To use it like an app on your phone, upload the folder to a free host
   (GitHub Pages, Netlify or Cloudflare Pages), open that link on your phone,
   then choose "Add to Home Screen" in the browser menu.

Your data
- Everything is saved only in your phone's browser (local storage). Nothing goes to a server.
- Data is stored per address, so the file on your computer and a hosted link keep separate data.
- Clearing browser data erases it. Use Me > Backup > Create backup to save a code,
  and Restore to bring it back.
