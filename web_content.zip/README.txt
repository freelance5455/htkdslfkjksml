ENGLISH CLASS 9 v2.0
Fitur:
- 9 materi: Narrative, Recount, Procedure, Report, Descriptive, Simple Past, Present Perfect, Expressions, Passive Voice
- Vocabulary V1/V2/V3
- Flashcard vocabulary
- Quiz 10 soal
- Nilai terbaik tersimpan
- Progress bar
- Offline: materi dan quiz berada di dalam aplikasi

Cara menjadi APK:
Buka folder ini di Android Studio -> Build -> Build APK(s).
