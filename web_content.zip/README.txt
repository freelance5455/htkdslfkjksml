Webetu - offline demo project

App name: Webetu
This is a demo recreation of a student portal interface and is not an official university application or university service.

Changes in this version:
- Removed the visible DEMO indicator from the UI.
- Reduced the fixed Home/Cards/Profile navigation to a compact 64px bar on normal phones.
- Navigation stays fixed while Home/Profile content scrolls.
- Extra bottom padding prevents navigation from covering the final Home/Profile content.
- Replaced the card images with the newly supplied clean cropped images.
- Cards are displayed without CSS cropping or stretching and the supplied PNG assets are kept losslessly.
- Cards support tap/swipe flip.
- No external libraries or internet resources are required.
