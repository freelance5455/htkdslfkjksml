Split Antagoniste Pro — projet Android sécurisé (sources, PAS un APK compilé)

Modifications :
- Aucune permission Android demandée.
- Accès Internet et HTTP bloqués dans le WebView.
- Aucune passerelle JavaScript vers Android.
- Progression automatique corrigée : pas d’augmentation si les charges varient entre les séries.
- Toutes les ressources HTML/JS/images conservées dans app/src/main/assets/web/.

Compilation : ouvrir ce dossier dans Android Studio, laisser Gradle se synchroniser, puis Build > Build APK(s).
Installer l’APK généré après vérification du manifeste et signature.
Le nom de package et la signature sont différents de l’APK précédent : il peut falloir désinstaller l’ancien.
IMPORTANT : exporter d’abord la sauvegarde JSON depuis l’ancienne application.
La sauvegarde locale de l’ancienne application ne sera pas transférée automatiquement.
L’alerte sonore en arrière-plan n’est pas garantie, comme dans la version précédente.
Ce projet n’a pas été compilé ni exécuté sur un téléphone dans cet environnement.
