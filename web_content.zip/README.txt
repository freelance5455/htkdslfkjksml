BAPA SITARAM Multi-Work version.
One Party can have unlimited work entries.
Each work entry has Work description, Date, optional Gallery photo or Camera photo.
Search by Party Name. Edit/Delete individual work or delete the whole party.
Photos are resized/compressed and stored locally.
APK wrapper must support WebView file chooser/camera input for Gallery/Camera.
