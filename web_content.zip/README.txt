Bayaz Nursery - Version 1
Offline bilingual (English/Urdu) nursery management prototype.

Build without a PC:
1. Open https://www.htmltoapk.com/
2. Upload the ZIP file.
3. Set app name: Bayaz Nursery
4. Build the APK and install it on Android.

Data is stored locally in the app/browser storage.
Use Backup All Data regularly.
CSV import uses two columns: Species, Quantity.
CSV export opens in Excel.

Next development stage:
- True .xlsx import/export
- Edit records
- Date/category/species filters
- Multiple nurseries
- Better Urdu translations
- PDF report
- Stronger backup/restore and data validation
