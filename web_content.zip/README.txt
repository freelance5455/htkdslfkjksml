ARAF SCRIPTS — APP STARTER

Included:
- Google sign-in and email/password registration/login.
- Owner identity is fixed to exhibetalanjandro@gmail.com.
- Owner-only script publishing enforced by Firestore security rules.
- Display-name moderation through a Firebase Cloud Function.
- Scripts, Chat and Theme navigation.
- Installable PWA shell (Android: browser menu > Add to Home screen).

IMPORTANT:
This ZIP is the app source, not a ready-made APK. Firebase must be configured before sign-in, publishing, and name saving can work. Do not publish until setup is complete.

SETUP (one-time):
1. Create a Firebase project at https://console.firebase.google.com/
2. Add a Web App and copy its Firebase config into public/app.js.
3. In Firebase Authentication, enable Google and Email/Password providers.
4. Add your email as an authorized Google account. Sign in once and verify that email.
5. Create a Firestore database.
6. Install Node.js and Firebase CLI on a computer, then run:
   npm install
   cd functions && npm install && cd ..
   firebase login
   firebase use --add
   firebase deploy
7. In Firebase Console > Authentication > Settings, configure authorized domains for your hosting domain.
8. Deploy Hosting with: firebase deploy --only hosting

SECURITY:
- Firestore rules only allow the verified owner email to create, edit or delete scripts.
- Owner status is checked using the signed-in token email, not a browser-stored role.
- Name filtering runs in a Cloud Function. The included word list is a basic starter filter, not a perfect profanity detector; expand and test it before public release.
- Do not share Firebase service-account keys or private credentials.

LIMITATIONS:
- Chat screen is currently a placeholder, not live multi-user chat.
- Script upload currently supports title/description only, not file attachments.
- iPhone installation/distribution requires Apple's signing/App Store process. A website ZIP cannot directly become an iOS App Store app.
