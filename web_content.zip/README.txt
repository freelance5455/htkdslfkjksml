NSE STOCK MANAGER - ANDROID HTML VERSION

Files:
- index.html : complete offline app in one file.

How to use:
1. Put index.html into your Android HTML/WebView app compiler.
2. Set index.html as the start/home page.
3. Enable JavaScript and DOM storage/localStorage.
4. Build the Android APK.

The app stores data locally on the phone. Use Data > Export Backup regularly.

Main modules:
- Dashboard
- Buy/Sell transaction entry
- Holdings and average cost
- Current price entry
- Target price and target-profit calculation
- Expected dividends
- Book closure and dividend payment dates
- Broker cash deposits/withdrawals
- JSON backup/import

This is an offline foundation. Live NSE prices, automated dividend/book-closure updates,
broker integration, authentication, cloud sync and push notifications require additional
data/API or backend integration.
