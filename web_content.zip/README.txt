FF SENSI PRO - app package
Upload index.html to any static host (Netlify, Vercel, GitHub Pages, Cloudflare Pages) or to a website-to-APK builder.
Search index.html for f3RXxnJCPV0, i0TcoXnjjS8 and #FFHUDT6O3jHUJWxJPo7eO to change your links and code.
Google Play subscription is planned and disabled for now. Put AdMob/AdSense code inside elements marked data-ad="banner".
