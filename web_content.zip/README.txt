مشروع دعوة + الأذان في الخلفية.
- Android Studio: افتح المجلد وابني (Build > Build APK).
- GitHub من الموبايل: ارفع project.zip و build.yml (في .github/workflows/) وشغّل Actions.
مهم: امسح النسخة القديمة من التطبيق قبل تثبيت الجديدة (التوقيع مختلف).
