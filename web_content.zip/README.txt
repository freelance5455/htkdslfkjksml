Fuego + Bruno Panel - proyecto Android.
Abre app/src/main/assets/index.html mediante WebView.
Para generar APK usa Android Studio/AndroidIDE y ejecuta assembleDebug.
El APK estará en app/build/outputs/apk/debug/app-debug.apk.
El simulador es independiente y solo interactúa con su propio muñeco.