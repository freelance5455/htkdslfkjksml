Abdullah's Classroom — Final Offline Package

Use this ZIP as a bundled/local HTML app. Do NOT use a live URL wrapper if you need offline behavior.

PDF Library:
- Add PDF from device
- Store locally in IndexedDB
- Remove to Recycle Bin and restore via the existing trash feature
- Download/open fallback included

Important: many Android WebViews cannot render application/pdf inside an iframe/object. For guaranteed in-app PDF rendering, the final native APK wrapper must include a native PDF renderer or PDF.js. The package therefore includes a robust download/open fallback rather than falsely claiming every WebView can render PDFs.

Timer:
- Wake Lock is requested while timer runs and re-requested when the app returns to foreground.
- Native Android APKs can guarantee screen-on behavior with the Android window FLAG_KEEP_SCREEN_ON; a pure HTML wrapper cannot guarantee this on every device.
