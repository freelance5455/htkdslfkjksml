नवयुवा दुर्गा पूजा समिति - Updated ZIP

मुख्य बदलाव:
1. Login screen में Admin Login और User Login अगल-बगल tab buttons हैं। जिस tab को touch करेंगे उसी के fields खुलेंगे।
2. हर रसीद में “PDF में सेव करें” बटन है। यह print dialog खोलता है; Android में वहाँ “Save as PDF” चुनकर PDF सेव किया जा सकता है।

Admin ID: 7905106011
Admin Password: Gyan@123

नोट: यह web/offline demo build है; Firebase/real OTP/backend इसमें शामिल नहीं है।
