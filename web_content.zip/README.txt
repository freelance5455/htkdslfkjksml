Child Health Clinic – AppForge PDF fix

This version avoids the Android WebView download problem.
Tap Reports > Generate / Save PDF. Android should open the print screen. Choose “Save as PDF”, then select Downloads.
If a preview opens instead, use the Android Print option and select Save as PDF.
