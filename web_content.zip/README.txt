EduMind AI v2 — ZIP to APK uchun
=================================

1) ZIP faylni APK builder saytiga yuklang.
2) Agar sayt index.html talab qilsa, ZIP ichida index.html root papkada joylashgan.
3) Ilova kamerasi uchun Android ilovasi kamera ruxsatini so'rashi kerak. Sayt/WebView builderda camera permission yoqilgan bo'lsin.
4) Rasm olish va galereyadan tanlash: Skaner bo'limi.
5) OCR Tesseract.js orqali internetda ishlaydi. Birinchi ishga tushishda til ma'lumotlarini yuklab olishi mumkin.
6) Haqiqiy AI test yaratish va AI Tutor uchun Google Gemini API key kerak. Kalitni Google AI Studio'dan oling va ilovaga kiriting.
7) XAVFSIZLIK: bu demo ilova API kalitini brauzer tomondan yuboradi. Uni ommaga tarqatmang yoki shaxsiy kalitingizni APK ichida qoldirmang. Ommaviy foydalanish uchun backend/proxy kerak.
8) Bu ZIP — web-ilova. APK builder uni Android WebView ilovasiga aylantiradi. Offline OCR/AI hozircha yo'q.
