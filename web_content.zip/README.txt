FindBack APKForge starter package

1. Open APKForge.
2. Choose its HTML/website upload option.
3. Upload this ZIP if APKForge accepts ZIP files, or extract it and upload index.html if it asks for that file.
4. Build the APK in APKForge.

This is a local prototype only. Reports stay on the same device/browser. It does not yet sync between friends or send push notifications. Those features require an online backend and notification setup.
