CET MASTER 2028 HTML starter app

Includes a mobile-friendly dashboard, PCM subject screens, sample topic-wise bilingual notes, important points, star/unstar topics saved locally, Important Topics list, sample test and Doubts notebook.

Preview: extract ZIP and open index.html in a browser.
APK: upload this ZIP to an HTML-to-APK builder that accepts HTML/CSS/JS projects, then follow its build steps.

This is a starter sample, not a complete official MHT-CET 2028 syllabus, complete notes library, official PYQ bank or full test series. Add and verify remaining chapters when the official 2028 syllabus is available. No paid/private content from other apps is included.
