نسخة V5 مصححة لبناة Android التي تستخدم appassets.androidplatform.net/web/index.html
البنية:
web/index.html
web/assets/icon.png
إذا كان المنشئ يطلب رفع مجلد/ZIP للويب، ارفع هذا الملف كما هو.
