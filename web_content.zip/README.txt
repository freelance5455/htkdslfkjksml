NexPhys Maroc — Offline WebApp

نسخة Web App مجهزة لتغليفها داخل APK.
- index.html في الجذر
- بيانات S1/S2 مدمجة داخل index.html
- الفيديوهات محلية داخل videos/
- لا توجد fetch أو روابط إنترنت للمحتوى

ملاحظة: أداة التحويل إلى APK يجب أن تدعم ZIP محلي مع index.html وتضمين مجلد videos داخل الحزمة.


VERSION 23
- 14 explanatory module videos M1-M14 are bundled locally.
- Module pages prefer the explanatory video first.
- Chapter videos remain available where present.
- No YouTube is required for the bundled videos.
- Designed for offline study.

VERSION 24 — STUDY MASTER
- Local study dashboard.
- Average quiz score tracking.
- Weak-module detection.
- Daily revision guidance.
- All state stored locally; no account or internet required.
