TradePilot MT5 Full Demo
Features: demo balance/equity, realized P/L, win/loss count, win rate, open positions, automatic entries, simulated TP/SL exits, daily loss protection, max-open-trade protection, configurable risk, signal threshold, trade history, reset and close-all.

This is a simulator. It does not connect to MT5 or place real broker orders.
Before live use, the strategy must be connected to real market data and tested with MT5 Strategy Tester/demo account.
