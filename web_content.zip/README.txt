NEXUS OS - WEB APK PAKETI

Paket, hem kok dizinde hem de web/ alt klasorunde index.html bulundurur.
Bu, donusturucu web/index.html adresini ariyorsa dosya bulunamama hatasini onlemeye yardimci olur.

Yukleme ekraninda ZIP proje yukleme destekleniyorsa bu ZIP'i secin.
Eger site yalnizca HTML dosyasi istiyorsa index.html dosyasini tek basina secin.

Not: Bu paket APK degildir. APK, donusturucu tarafindan basarili derleme yapilmasi halinde olusur.
