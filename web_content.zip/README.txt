RISEUP X — FREE FITNESS RPG PROTOTYPE

How to use:
1. Extract the ZIP.
2. Open riseup_x_upgraded.html in Chrome or another browser.
3. Your XP and level are saved in the browser on the device.

This package is a self-contained web app prototype, not an Android APK.
