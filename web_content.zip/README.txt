EGG PARTY SALES — OFFLINE APP READY (v2)
========================================

FILES
- index.html : Complete offline app UI (Sales Dashboard + separate Admin Panel)
- egg-party-sales-app-ready-admin-v2.html : Same single-file HTML for direct use

USE
1. Open index.html in Chrome, or import it into your Android WebView/HTML-to-APK builder.
2. Tap Admin Panel to access Overview, Excel Upload, Party Records, and Backup & Settings.
3. To update: choose report year, select .xlsx/.xlsm file, Preview Excel Data, then Save & Apply.
4. Month sheets must be named like "January 2026" and have Egg Code/Code, Company/Name and Total.
5. Admin Panel > Party Records: edit/add/delete parties and export CSV or Excel.
6. Download JSON backups regularly, especially before reinstalling an app.

ANDROID BUILDER SETTINGS
- Enable JavaScript and DOM storage (localStorage).
- Enable file chooser (for Excel uploads and JSON restore).
- Enable downloads (for Excel/CSV/JSON/PNG).
- Allow printing (for PDF) if supported by the app wrapper.
- No network permission needed for Excel .xlsx/.xlsm import.

LIMITATIONS
- This HTML has NO secure administrator authentication. Admin is a separate UI section, not a protected server role.
- Data stays on this specific device/app storage, not shared between phones or website visitors.
- Clearing app data or uninstalling may delete records. Keep JSON backups.
- Excel .xls (legacy binary format) is not supported. Save it as .xlsx.
- Some basic HTML-to-APK builders do not implement file chooser/downloads; use a WebView wrapper that does.
- Original WordPress plugin still offers protected admin capabilities when hosted on WordPress.

Preserves the original plugin's June 2026 commission start and slabs, party/monthly sales lookup, report preview, print/PDF and PNG export.
