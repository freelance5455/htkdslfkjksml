BaatChit - SoftSpring HTML/ZIP APK Builder Gallery Fix

IMPORTANT:
1. index.html is at the ZIP ROOT.
2. Profile photo Gallery button uses a real HTML <input type="file" accept="image/*"> directly under the button, instead of relying on a JavaScript bridge.
3. Chat attachment uses the same direct file input method.
4. This is the maximum gallery-side fix possible from an HTML/ZIP-only builder.
5. In SoftSpring, upload this ZIP as a ZIP project. If SoftSpring's generated WebView still does nothing when a direct <input type="file"> is tapped, the builder itself does not expose Android's file chooser; HTML code cannot add WebChromeClient/onShowFileChooser to that generated APK. In that case use the supplied Android Studio project instead.
