EVOLUTION Android Project

1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Connect an Android phone or use an emulator.
4. Run the app with the Run button.
5. To create an APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

The original HTML app is in:
app/src/main/assets/index.html

The app uses Tailwind, Google Fonts and Lucide from HTTPS CDNs, so INTERNET permission is included.
The WebView has JavaScript and DOM storage enabled because the app uses JavaScript and localStorage.
