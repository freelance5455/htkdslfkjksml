Upload this ZIP to an HTML-to-APK/PWA builder.
The app entry file is index.html at the ZIP root.
App name: XAU/USD Trading Journal
