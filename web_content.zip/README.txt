NOTOTYPE — MOBILE WORKSPACE UPGRADE
===================================

This package is designed for HTML-to-APK converter apps that accept a ZIP containing
an index.html at the ZIP root.

START FILE
----------
Open index.html. No build step, npm, server, or mandatory account is required.

WHAT WAS UPDATED
----------------
- Added responsive mobile sizing and touch-friendly input behavior.
- Added dynamic viewport-height handling for Android browser/WebView layouts.
- Added compact landscape rules to reclaim vertical workspace when the phone rotates.
- Preserved the existing Nototype HTML application and its embedded libraries/features.
- Kept the app local-first; existing browser storage behavior remains unchanged.
- Did not add paid APIs or make offline-capable features internet-dependent.

NOTES
-----
- Features that already rely on online services or external resources may still need
  internet. This package does not convert a remote service into an offline service.
- Local notes are stored by the existing app in the WebView/browser storage. Clearing
  app data or using a converter that resets WebView storage can remove local data.
  Export/backup important notes when the app offers that option.
- In your ZIP-to-APK converter, select this ZIP or its index.html entry point if asked.
  If it asks for a start page, use: index.html
- Test the generated APK on-device, especially export/import, math rendering, and any
  feature that depends on network access. Converter WebView settings vary by app.

This is a static HTML package; it does not require a separate server.


PHASE 1 MOBILE RELIABILITY
- Keep index.html at the ZIP root and select it as the start page in the APK converter.
- Test portrait and landscape orientation, especially short landscape screens.
- Test keyboard entry in note editors, formula inputs, search, and dialogs.
- Test local save/reopen, import/export, citation dialogs, and formula sandbox.
- Online features may still require connectivity; this package does not add paid API dependencies.
- This is a responsive WebView-oriented HTML package, not a signed APK. Validate in your chosen converter.
