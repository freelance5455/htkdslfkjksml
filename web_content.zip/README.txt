GLORY MILITARY - HTML PROTOTYPE
Versi awal untuk diuji di browser atau dikemas menjadi APK.

CARA PAKAI
1. Ekstrak ZIP.
2. Buka index.html di browser untuk mencoba.
3. Untuk APK, unggah file HTML/CSS/JS sesuai alur APKForge/HTML to APK.
4. Pastikan index.html, style.css, dan app.js berada dalam folder project yang sama.

FITUR
- Dashboard
- Public Information: tambah, edit, hapus informasi
- Military Schedule / Events: tambah, edit, hapus agenda
- Achievements
- Clip & Cover archive
- Poster archive dengan URL gambar opsional
- Recruitment form
- UUD & Rules
- Member Information
- Menu navigasi mobile

CATATAN PENTING
Ini prototipe frontend saja. Data disimpan menggunakan localStorage di browser/perangkat yang sama.
Data BELUM sinkron antar pengguna dan tidak otomatis masuk ke Firebase.
Untuk menambahkan poster melalui URL, gambar harus tersedia pada tautan gambar yang bisa diakses publik.
Jangan gunakan data sensitif untuk pengujian. Login, role admin/member, upload gambar, dan database online akan dibuat pada tahap lanjutan.
