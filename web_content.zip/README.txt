CAREER GROWTH SPECIALIST — HTML app package

CONTENTS
- index.html: mobile-friendly app. It must remain at the root of the ZIP.

HOW TO USE
1. Keep this ZIP intact.
2. Upload it to an HTML/ZIP-to-Android APK builder that explicitly offers a free APK download.
3. Set the app name to CAREER GROWTH SPECIALIST.
4. Check the builder's final APK download terms before spending time creating an account.

IMPORTANT LIMITATIONS
- This is a web-based app packaged for Android (WebView), not a native Android app.
- Candidate profiles and demo vacancies are stored locally in the browser on one device only.
- CV file selection is local; files are not uploaded to a server.
- The service request opens WhatsApp for the user to review and send.
- Shared online accounts, cloud CV storage, and a cross-device recruitment database require a backend service.
