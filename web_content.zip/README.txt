FOX MEADOW: WILDHEART
Offline 3D fox-life adventure — version 0.2

CONTENTS
- index.html: complete single-file game: HTML, CSS, JavaScript, WebGL renderer, generated low-poly meshes, controls and save logic. It has an embedded icon and needs no internet connection or external libraries.
- fox-meadow-icon.svg: separate app/icon artwork for a wrapper.
- SAVE_FORMAT.md: current save format and migration notes.
- TEST_REPORT.txt: checks performed and limits of testing.

HOW TO PLAY
1. Open index.html in a modern browser with WebGL 1 support (Chrome on Android is a starting point).
2. Choose Story, Free Roam or Sandbox, then tap Begin your adventure.
3. Move with the lower-left joystick. Drag the meadow to rotate the camera.
4. Tap RUN to sprint, JUMP to hop, INTERACT near glowing markers and animals, and REST for a quiet pause.
5. Open the menu for the meadow map and journal, fur colours, graphics quality, sound, den decorations and save controls.

GAMEPLAY INCLUDED
- Third-person camera-relative movement, sprinting, jumping and idle/run animation.
- A procedural low-poly meadow, winding footpath, creek, wooden bridge, den, oak, fern hollow, trees, grass, flowers and drifting motes.
- Ginger fox avatar with cream chin/belly and a white tail tip by default; fur, belly, tail-tip, ear and eye colours can be changed.
- Seven short story chapters, wildlife interactions, 16 collectible star seeds, three pawprint discoveries, den-comfort progression and sandbox decorations.
- Daylight colour cycle, generated audio cues and soft ambient wind.
- Autosave to browser storage, manual save, .fox export/import, validation, backup of the previous save and migration from the earlier version-1 Fox Meadow save shape.
- No external libraries, downloaded models, web requests or online assets are required during play.

ANDROID / APK
This ZIP is laid out with index.html at its root for an HTML-to-APK wrapper. The ZIP itself is not an APK. Upload the ZIP to a compatible wrapper, set index.html as the start page, choose the app name/icon, and build/sign the APK. No Android SDK or Godot exporter was available in this build environment, so no APK has been compiled here. Test the wrapper-generated APK on the target phone before relying on it.

PERFORMANCE AND SCOPE
This is a compact, self-contained procedural indie-style game build, not a finished commercial asset-heavy release. Its small size comes from generating the world and models in code rather than including large textures, recorded audio and authored model files. A 50–100 MB file size would not by itself make it better. Choose Graphics: lite in the menu if the phone struggles. Touch responsiveness, frame rate and WebGL support still need checking on the actual TCL 501.

SAVE SAFETY
Export a .fox backup before reinstalling or changing app wrappers/devices. Browser storage is tied to the browser/app origin and can be cleared by Android or by uninstalling the app. Importing a file validates it and stores the existing local state as a backup first. Do not import a save from a future version into an older build.
