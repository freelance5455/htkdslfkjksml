DEENWITHALBI OFFLINE WEB APP STARTER
Upload this ZIP to the builder's 'Zipped site' option. index.html is at the ZIP root.
Offline: habit checklist and Tasbeeh are saved locally; core app shell is cached for offline use.
Not included: complete Quran Arabic text/translations/audio, Hadith collections, prayer-time calculation, Qibla, or scheduled alarms. These require verified/licensed data and additional implementation.
This is a web app package; whether the builder can package it as an Android APK depends on that service.
