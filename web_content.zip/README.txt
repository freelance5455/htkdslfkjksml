YACKUZA — AJOUTS AU SITE EXISTANT

Le fichier assets/www/index.html d’origine a été conservé et les nouveaux outils ont été ajoutés mécaniquement à la fin de la page, sans analyse manuelle de son contenu.

Ajouts : bouton MEDIA FLOW, import d’images et vidéos, lecteur musical avec playlist/volume/aléatoire/répétition, choix de fond image/vidéo et réglage d’assombrissement.

Le fond fourni est dans background.png. Garder index.html et background.png dans le même dossier.

Confidentialité : les médias sélectionnés par les outils ajoutés sont traités localement dans le navigateur. Aucune fonction de téléversement n’a été ajoutée par ce patch. Les médias sont temporaires.

Déploiement : décompresser puis publier le dossier sur un hébergeur statique. Les fonctions propres à Android ne sont pas converties automatiquement.
