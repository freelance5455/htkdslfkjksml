ClassCheck Attendance Checker Web App
Features: add/search/delete students; take attendance by date and section; mark Present/Late/Absent; view/filter history; export CSV; responsive layout; empty states; required-field and duplicate-number validation.
To use: extract ZIP, open index.html in a modern browser, add students, then take attendance.
Privacy: records are stored in this browser on this device only. No server sync or strong access controls. Use fictional data for testing and get school approval before using real student records.
