MIZAN 10K PANEL DEMO — V3

Files:
- index.html
- background_music.mp3 (audio extracted from the supplied MP4) OR background_music.mp4 if MP3 extraction was unavailable.

How to use:
1. Extract the ZIP.
2. Keep index.html and the music file in the same folder.
3. Open index.html in Chrome on Android or another modern browser.
4. If autoplay is blocked by the browser, tap “TAP TO START MUSIC” once.

Demo key:
MIZAN 10K

V3 features:
- Bengali one-time voice guide about getting the key and YouTube channel.
- Voice stops after each announcement; it is not a live assistant.
- Full-screen, multi-colour syntax-style code lines animate for about 4 seconds.
- Music uses the supplied clip.
- ESP BOX / ESP LINE and other controls are interactive visual-only switches.
- Theme colour buttons change the panel colours.
- Three game launch buttons attempt Android app launch by package ID. Availability depends on the game edition, region, installed package and browser/app environment.
- M10 quick-menu badge opens an in-page demo menu after the dashboard opens.

Limitations:
- Web browsers often block autoplay audio until the user taps once.
- Speech voice and Bengali support depend on voices installed on the device/browser.
- A normal HTML web app cannot create a genuine floating overlay on top of another app/game. The M10 badge and quick menu are inside this demo page only.
- The panel does not read, modify, automate or affect any game. All ESP/panel toggles are visual simulation only.
