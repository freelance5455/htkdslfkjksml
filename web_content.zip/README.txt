DOJO ZERO - ANIME UPDATE
Deploy every file and folder in this ZIP to your site root, replacing the old files.
Keep index.html, sw.js, manifest.webmanifest, both icons and the portraits folder together.
New: original anime-style portraits for all 9 fighters (portraits/*.svg), ultimate cut-in
animation, anime eyes and hair on the in-game fighters, new cache version.
New modes: Daily Rift (seeded daily twist, 5 rounds, boons), Blitz (60s time attack), Boss Rush (5 bosses).
New: per-fighter visual effects (hit sparks, cast flashes, auras, dash trails, projectile styles, landing dust).
New: distinct enemies and arenas for Daily Rift (wraiths), Blitz (imps), Boss Rush (titans); original portrait eyes restored.
v2 overhaul: new title screen, Records/Settings/How to play, STYLE rank meter, hit vignette, glass HUD.
