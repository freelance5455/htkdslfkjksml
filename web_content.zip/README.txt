Contractor Pro V16 — AI Copilot & Smart Capture
APK-ready single-file build based directly on the verified V15 Notifications & Smart Alerts edition.

V16 adds a local-first Smart Assistant and natural quick capture for project, cost, profit, inventory, overdue invoices and worker-hour entries.
No external AI SDK, private API key, or fake online AI is embedded.
Real generative AI and server-side company-data access require the production backend.
Offline operation is preserved.
Root index.html is required by HTML-to-APK converters.
