MY TUK TUK - Android Studio project
Designed by Ravindu

Features:
- Offline dashboard with daily and monthly income totals
- Daily hire records: paid or on credit
- Credit hire balances and partial payment updates
- Monthly school hire records and partial payment updates
- Multiple dated fuel expense records, including several on the same day
- Monthly fuel expense total and daily-hire income after fuel expenses
- Local phone storage; no internet permission or server required

Build an APK:
1. On a computer, install Android Studio.
2. Open this folder as an existing project.
3. Allow Gradle sync (first build may need internet to download Android build tools).
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK, normally app/build/outputs/apk/debug/app-debug.apk.

This ZIP contains the Android source project, not a prebuilt APK. Note: the supplied original ZIP did not include the Gradle wrapper (gradlew and gradle/wrapper/gradle-wrapper.jar), so those files are still required by build services that specifically validate for a complete Gradle wrapper. Keep separate backups: uninstalling the app or clearing its storage may erase locally saved records.
