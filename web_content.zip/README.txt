Child Health Clinic - AppForge Offline PDF Version
=====================================================
Entry point: index.html

This version generates a real PDF directly in the app using a self-contained
PDF writer. It does NOT require jsPDF, a CDN, or internet access.

PDF button:
Generate PDF -> creates Child_Health_Clinic_Report_DATE.pdf and downloads it.
On Android/AppForge, check the Downloads folder or the browser/WebView download area.

Includes:
- Date/calendar first field
- Patient and fee actually received
- Expense detail
- Previous balance
- Current balance
- Daily/monthly/all filters
- Real PDF report
- Print
- Excel-compatible CSV export
- Offline local storage
