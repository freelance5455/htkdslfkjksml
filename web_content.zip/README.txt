HTML to App me: "Zipped site" chunein aur yeh zip dein (index.html andar hai).
Staff panel: app me "My Tunnel" naam par 5 dafa tap karein (2.5 second ke andar).
Staff login: admin / admin123
