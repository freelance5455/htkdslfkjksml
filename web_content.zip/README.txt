KEYS.zip — sit entènèt demo ak kòd sekrè

Kijan pou itilize:
1. Chwazi KEYS.zip nan aplikasyon “Site zippé”.
2. Peze Aperçu pou verifye paj la.
3. Kòd demonstrasyon an se: ALPHA-7391.

ENPÒTAN: Sa se yon demo sèlman. Kòd la estoke nan HTML/JavaScript la, kidonk nenpòt moun ki konn enspekte fichye a ka jwenn li. Pa mete foto prive oswa enfòmasyon sansib ladan l. Pou pwoteksyon reyèl, ou bezwen otantifikasyon sou yon sèvè.
