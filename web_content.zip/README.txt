# Aurora Premium Launcher — Builder Ready

This version is intentionally dependency-free so HTML-to-APK/app builders can load it directly.

## Entry point
Use `index.html` as the app start/home file.

## Included
- iPhone-style launcher interface
- Dynamic Island interaction
- App grid and dock
- Search
- Control Center
- Notifications
- Settings
- Wallpaper switching
- Wi-Fi/Bluetooth/Airplane demo toggles
- Touch/swipe navigation
- LocalStorage wallpaper persistence
- Mobile viewport/PWA metadata
- No npm, React, Vite, TypeScript, or external libraries required

## Important
This is a launcher-style simulation inside an Android/WebView. A normal web app cannot replace the Android system launcher or access installed apps/phone controls without native Android permissions and code.
