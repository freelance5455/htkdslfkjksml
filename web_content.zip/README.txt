MAKHAN CLASSES APP

This is a responsive installable web app (PWA) for Classes 1st to 8th.
Included: class selector, subjects, video/notes/test/result/notifications/teacher-support sections, splash branding, offline cache.

To use: upload this folder to any HTTPS web hosting service. Open the URL on Android Chrome and choose “Add to Home screen” / “Install app”.

To make a Play Store APK/AAB, this web app can be wrapped with a standard Android WebView/TWA build process.
