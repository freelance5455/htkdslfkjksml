Abody AI — Android APK package

This ZIP contains the current Abody AI HTML prototype as index.html.
It is ready to upload to an HTML-to-APK builder from your Android phone.

Important:
- This is NOT an APK yet.
- The app is currently a WebView wrapper around the HTML prototype.
- AI replies require a valid API key in the app settings; the current prototype may use Gemini.
- Do not share your API key or upload it in public screenshots.
- Voice features depend on Android WebView/browser support and may require internet.

Suggested next step:
Open https://htmltoapp.dev/ in Chrome on your phone, upload this ZIP, set the app name to "Abody AI", then build and download the signed APK if the site's free tier is available.
