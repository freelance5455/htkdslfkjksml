आकार हिशोब वही - Android APK Project

हा Android Studio project आहे.
1. ZIP extract करा.
2. Android Studio मध्ये project folder उघडा.
3. Gradle Sync होऊ द्या.
4. Build > Build APK(s) निवडा.
5. APK app/build/outputs/apk/debug/app-debug.apk येथे मिळेल.

ॲपमध्ये व्यवहारांचा डेटा WebView Local Storage मध्ये फोनवरच सेव्ह होतो.
