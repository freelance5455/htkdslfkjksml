MX Blade
index.html + icon.png = اللعبة
server.js + package.json = السيرفر الأونلاين

تشغيل السيرفر على render.com:
- New Web Service، Start Command: node server.js
- Environment (اختياري لكن مهم للحفظ الدائم):
  UPSTASH_REDIS_REST_URL = رابط REST من upstash.com
  UPSTASH_REDIS_REST_TOKEN = التوكن من upstash.com
- بعدها انسخ رابط render وحطه بـ DEFSRV داخل index.html ثم حول الزيب APK.
