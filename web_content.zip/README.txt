Shadow Reign 3D V5
الجديد عن V4:
- Safe Zone
- Mission وRewards
- Level
- Heal مرة واحدة
- Squad dots في Mini Map
- نظام Score/Combo محسن
- Arena ومبانٍ وصناديق وصخور
Prototype 2.5D خفيفة للهاتف وليست 3D حقيقية بمحرك Unity/Godot.
