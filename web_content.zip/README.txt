BRAZIL FAMILY CLOTHING APP — STARTER PACKAGE

Included:
- index.html: mobile-friendly interactive shop prototype
- assets/logo.png: your uploaded Brazil Family logo

Features:
- Black premium storefront
- Product catalogue and sample KSh prices
- Category filters and search
- Size/colour selection
- Shopping bag and quantities
- WhatsApp order message to the supplied number

IMPORTANT:
This is a web app prototype, not a compiled Android APK yet. It uses sample product prices and emoji product placeholders. Replace these with real product photos and confirmed prices before launch.

Fastest no-code route to an Android install:
1. Upload/host this website on a web hosting service that supports HTTPS.
2. Use a reputable website-to-Android wrapper/PWA builder to package the hosted site.
3. Test on your Android phone, especially WhatsApp links.
4. If publishing on Google Play, follow current Play Console requirements and provide privacy/contact details.
5. Do not collect or process online payments until you have chosen and configured a payment provider.

WhatsApp number configured in the prototype: +254113322804
Confirm this is the correct business WhatsApp number before sharing the shop publicly.
