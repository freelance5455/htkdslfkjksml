NEON HORIZON: NEXT GEN (v2 — Progressive Difficulty Edition)
Upload Package

CONTENTS
- index.html: Complete standalone 3D WebGL game with progressive 5-stage difficulty
  (EASY -> NORMAL -> HARD -> EXPERT -> OVERDRIVE), embedded SVG favicon, fullscreen toggle,
  and auto-pause on tab switch.
- manifest.json: Web App Manifest for mobile/desktop fullscreen installation.
- README.txt: Deployment and package documentation.

PROGRESSIVE DIFFICULTY OVERVIEW
- Starts at a relaxed cruising speed (BASE_SPEED = 16.0) with wide 40m obstacle spacing
  and single-obstacle waves (2 open lanes per row) for the first 20 seconds.
- Gradually increases acceleration, wave complexity, and spawn frequency over time:
  * 0s - 20s:   EASY (Single-obstacle waves, wide spacing)
  * 20s - 48s:  NORMAL (Blends 1-obstacle and 2-obstacle waves)
  * 48s - 85s:  HARD (Introduces 3-lane jump/slide tactical waves)
  * 85s - 130s: EXPERT (High-speed reflex waves)
  * 130s+:      OVERDRIVE (Infinite high-velocity scaling up to MAX_SPEED = 86.0)

CONTROLS
- Steer Left / Right: A / D, Left / Right Arrow Keys, Swipe Left/Right, or On-Screen Touch Pads
- Jump: W, Up Arrow, Spacebar, Swipe Up, or JUMP Button
- Slide / Mid-Air Slam: S, Down Arrow, Swipe Down, or SLIDE Button
- Pause: P or Escape (also auto-pauses when switching tabs)
- Fullscreen: F or HUD Fullscreen Button
- Mute Audio: M or HUD Audio Button
- Cheat Matrix: C or HUD Cheats Button
- Instant Retry: R

DEPLOYMENT
Upload this ZIP file directly to any HTML5 game portal (Itch.io, CrazyGames, Poki, GameJolt, Newgrounds)
or extract its contents (index.html, manifest.json, README.txt) to any static web host
(GitHub Pages, Netlify, Vercel, Cloudflare Pages). No build step or server runtime is required.
