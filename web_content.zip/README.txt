GALO EVOLUÇÃO — VERSÃO COMPLETA DO PROTÓTIPO

Abra index.html no navegador.

Sistemas incluídos:
cadastro/login; confirmação de senha; validação de formato de e-mail; galo inicial nível 0; detalhes do galo; edição de nome/descrição; comida; água; treino com corrida/força/agilidade/resistência; XP; níveis; estatísticas; limites de treino; coleção; galinheiro; seis raridades; missões; inventário; conquistas; ADM com código 777; criação de variações branco/preto/fogo/mítico; salvamento local.

Observação técnica: confirmação de que um endereço de e-mail realmente existe e geração de imagens por IA exigem serviços/backend externos. Esta versão deixa a arquitetura funcional no navegador e usa um personagem vetorial como referência temporária.


ATUALIZAÇÃO: o galo enviado pelo usuário (galo_base.png) foi definido como a imagem principal/referência visual do jogo.


ATUALIZAÇÃO PRINCIPAL:
- O galo enviado pelo usuário em galo_base.png é agora o personagem-base oficial.
- O galo inicial do jogador usa exatamente essa imagem.
- As telas de Meus Galos, detalhes, Coleção e ADM usam essa referência.
- As propriedades de raridade/variante continuam salvas no jogo, mas a aparência-base não é mais substituída pelo galo SVG antigo.


VERSÃO DE INVESTIMENTO — ALTERAÇÕES:
- Removida a opção ADM da interface e o código administrativo.
- Removida a aba Treinamento do menu principal.
- O treinamento agora fica acessível dentro de "Editar Galo" do galo selecionado.
- Corrigido o logout para voltar diretamente à tela de login sem recarregar a página.
- Adicionada a opção "EXCLUIR" no menu.
- Em Excluir, o jogador pode selecionar vários galos e excluir os selecionados.
- O jogo impede a exclusão de todos os galos, mantendo pelo menos um.
- Mantido o galo-base enviado pelo usuário.


ATUALIZAÇÃO:
- Removidos Inventário, Missões e Conquistas da interface.
- Removida a área de recompensas junto com o Inventário.
- Menu principal agora: Meus Galos, Coleção, Excluir e Adicionar Galo.
- Adicionar Galo permite escolher uma imagem da galeria, informar nome e descrição.
- Galos adicionados ficam salvos na conta e aparecem em Meus Galos e Coleção.


CORREÇÕES DESTA VERSÃO
- Recuperação do Hospital usa horário absoluto (timestamp), continuando com o jogo fechado.
- Galos recuperados ao reabrir o jogo são liberados automaticamente.
- Galos feridos não podem ser escolhidos para novo combate.
- O mesmo galo não pode ser escolhido nos dois lados do combate.
- Sair de um combate com perda de vida envia o galo ferido ao Hospital para não perder o estado.
- Validação e normalização de vida/ataque/defesa/tempo de defesa foram reforçadas.
