DG GAMES — ADMIN PANEL (alag app)
=================================
Sirf admin ke liye. Players ko yeh zip mat do. index.html zip ke root mein hai.

LOGIN: email nabeeleditsofficial@gmail.com (password chat mein bataya gaya hai).
Login ke baad Dashboard -> "My account" mein password badal lo.

TABS
- Dashboard : Website ON/OFF, App ON/OFF, announcement, "Default Ludo look & rules", Ludo coin settings
              (rank entry fee, prize, classic prize, signup bonus, rank points), password change.
- Games     : naya game / edit / hide / delete. File upload ya link/paste dono se.
- Events    : naya event post karo (poster, entry fee, prize, MODE, THEME, optional reward, end time).
              Post karte hi sab ko notification jati hai. Player event par tap kare to seedha Ludo us event
              mein khulta hai. Neeche "Send a notification" se kisi bhi waqt message bhej sakte ho.
- Shop      : profile pictures aur banners (avatar yahin se add hote hain). Price 0 = free.
- Users     : har user ka ID, coins, rank points. "± Coins" se coins do/kato. Suspend / Restore.
- Support   : player messages ka jawab.
- Content   : contact details, About, Rules, FAQ.

NAYA MODE / THEME (BINA APP BADLE)
Event form mein "Game mode" aur "Theme" chuno -> neeche "Advanced" box mein JSON bhar jata hai. Chahe to
us JSON ko edit karke apna alag mode/theme bana lo. Yehi cheez "Default Ludo look & rules" mein bhi hai
(har normal match ke liye). Sab server par save hota hai, players ko foran milta hai.

JSON mein kya likh sakte ho (sab optional):
{
  "mode_name": "Speed Ludo",  "mode_desc": "2 tokens each",
  "players": [2,4],                         // kitne players ke match allowed
  "rules": {
    "tokens": 2,                            // har player ke tokens (1-4)
    "tokens_to_win": 2,                     // kitne tokens ghar pahunchne par jeet
    "exit_on": 6,                           // yard se nikalne ke liye dice (1-6), ya 0 = kisi bhi roll par
    "extra_on_six": true, "extra_on_capture": true, "extra_on_home": true,
    "three_sixes": true,                    // teen 6 par turn khatam
    "safe_stars": true,                     // star squares safe
    "turn_seconds": 15,                     // 8 se 90
    "dice_weights": [1,1,1,1,1,3]           // dice ke 1..6 ka wazan (zyada 6 ke liye aakhri number bada karo)
  },
  "theme": {
    "title": "HALLOWEEN LUDO", "emoji": "🎃",
    "accent": "#FF8A00", "accent2": "#8B3DFF",
    "bg": "#120A1A", "panel": "#1C1228", "board": "#1A1024", "track": "#2A1B3A",
    "dice": "#ffffff", "dice_dot": "#0A0C10",
    "colors": {"red":"#FF5A36","green":"#7CFC00","yellow":"#FFB300","blue":"#B14DFF"},
    "token_shape": "circle | square | diamond | star",
    "bg_image": "https://...", "board_image": "https://...",
    "css": "/* koi bhi extra CSS */"
  }
}
Yaad rakho: naye RULES / THEME / events sab server se chalte hain. Bilkul NAYA game type (jaise Snakes & Ladders)
ke liye app mein ek baar naya code chahiye hota hai.

AGAR UPLOAD BUTTON KUCH NAHI KARTA (APK mein aam masla hai)
Kai APK builders file picker allow nahi karte. Isliye har jagah link / paste ka option bhi hai:
- Image: "…or paste an image link" mein https:// link daalo.
- Game: "…or paste the game's HTML code" mein HTML code paste karo.
- Download file: direct download link daalo.
Files ko link banane ke liye Supabase Dashboard -> Storage -> game-assets mein upload karke "Copy URL" karo.

APK: yeh zip seedha "website to APK" builder mein upload karo (App name: DG GAMES Admin, icon: icons/icon-512.png).
