MIS TARJETAS Y MIS CREDITOS

Archivo principal: index.html
Copia HTML: mis_tarjetas.html
Service worker: sw.js
Manifest PWA: manifest.json

El archivo index.html es AUTOCONTENIDO y debe ser la página inicial del APK.
No requiere internet ni archivos externos para mostrar la aplicación.

Para convertir a APK:
1. Carga el ZIP completo sin extraerlo.
2. Si el convertidor solicita página inicial, selecciona index.html.
3. Conserva todos los archivos del paquete.
