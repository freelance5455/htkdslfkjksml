HARBOR HEIST - phone app package (all files are at the top level of this zip)

EASIEST ON A PHONE
1. Open the game link in Chrome (the one Claude gave you).
2. Chrome menu (3 dots) > "Add to Home screen". You get an icon that opens the game.

REAL APP (Android APK)
Use a free "website/HTML5 to APK" builder that accepts a zip (for example AppsGeyser or Web2Apk Builder).
Upload this zip (index.html is at the top level), build, download the APK, install it.
The game loads its 3D library from the internet the first time, so keep data on when you first open it.

INSTALL FROM A WEB ADDRESS (works offline after first load)
Upload these files to any free static host (Netlify Drop, GitHub Pages, Cloudflare Pages).
Open the address in Chrome > menu > "Install app". It opens full screen in landscape.
