PROJETO PAINEL

Arquivo inicial: index.html
Inclua todos os arquivos deste ZIP ao converter para APK.
O painel é visual, arrastável e minimizável dentro do aplicativo.
