Radha Rani Shop login/OTP demo.
Login with mobile + password, simulated OTP flow, account creation, and local logout.
Demo OTP is 123456. Real SMS OTP requires a backend/SMS provider connection.
