Circle Chat prototype
Open index.html in a browser (internet needed for the Manrope font).
Flow: index (welcome) -> login -> chats <-> status.
