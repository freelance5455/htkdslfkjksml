SMART CALCULATOR — ZIP PROJECT

কীভাবে চালাবেন:
1. ZIP ফাইল Extract করুন।
2. index.html ফাইলটি Chrome বা অন্য ব্রাউজারে খুলুন।
3. Basic / Scientific / History ব্যবহার করুন।
4. Music: On চাপলে ছোট original electronic melody বাজবে। এটি বন্ধ করতে আবার চাপুন।

ফিচার:
- Basic arithmetic, percentage, backspace
- Scientific: sin, cos, tan, √, log, ln, x², π
- হিসাবের History
- Dark / Light theme
- Button sound এবং ঐচ্ছিক background melody
- Mobile responsive এবং keyboard support

এটি HTML ওয়েব অ্যাপ। Android APK করতে Android Studio-তে WebView project বা কোনো HTML-to-APK builder ব্যবহার করতে হবে।
