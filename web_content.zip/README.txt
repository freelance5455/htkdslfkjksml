LAST MAN STANDING — HORDE EDITION
A P-RAHNA PRODUCTION GAME
==================================

This is a portrait mobile web game. It runs in a modern browser and can be wrapped as an Android APK with an HTML-to-APK tool.

IMPORTANT GAMEPLAY CHANGES
--------------------------
- The battlefield stays in the top section; the upgrade workshop stays visible underneath.
- Start with a sidearm pistol; unlock 21 weapons as you earn coins.
- Permanent Twin-Grip and Bullet Storm upgrades unlock dual wielding and increase your volley up to 100 shots per tap.
- Upgrade levels have no maximum; costs rise as you level them.
- Zombies begin slowly and become faster as waves progress.
- Shooting remains available after taking damage. The firing calculation and weapon-level reference have been repaired.
- Coins earned during a run are shown as RUN earnings.
- When the run ends, all run earnings are transferred into your permanent BANK.
- Banked coins are kept after death and can be spent in the permanent upgrade shop or weapon workshop.
- Permanent upgrades, weapon unlocks and weapon levels carry into future runs.
- Use the DEPLOY button on the Battle tab to start another run after shopping.
- The upgrade shop has separate Combat, Survival, Economy and Special filters, clear level indicators, progress bars and prices.
- Progress auto-saves on this device. If you close the app during a run, its saved run earnings are banked the next time you open it. Clearing browser/app data can erase local saves.

CONTROLS
--------
- Tap the battlefield: fire one burst.
- Hold the battlefield: keep firing automatically.
- BATTLE: combat stats, music and deploy control.
- ARSENAL: unlock, equip and improve weapons using banked coins.
- UPGRADES: buy permanent character upgrades using banked coins.

BUILDING AN ANDROID APP
-----------------------
1. Upload the ZIP to an HTML-to-APK wrapper that accepts a ZIP containing index.html.
2. Keep index.html, style.css, game.js and manifest.json together in the same folder.
3. Enable JavaScript, local storage and canvas support in the wrapper.
4. Set the app orientation to PORTRAIT.
5. Build the APK and install it on your device.

NOTES
-----
- The game includes a four-scene illustrated comic-style story intro with speech bubbles.
- The game uses custom-drawn 16-bit-inspired canvas artwork, slimmer zombies with more varied skin and clothing colours, weapon artwork in the upgrade cards, blood splashes, blood pools, and occasional flying zombie limbs. The upgrade workshop has a refreshed arcade-style visual design.
- The soundtrack is a original Amiga-inspired tracker-style game theme (about 1 minute 31 seconds) and loops only after it finishes; it is not a short 5-second loop.
- P-RAHNA PRODUCTION is credited in the title header, story intro and footer.
- Audio starts after the first touch because mobile browsers restrict autoplay.
- Save data is stored locally on the device/browser.
