TIME MODS STUDIO

This ZIP contains the Time Mods Studio HTML preview.
Extract the ZIP and open Mods_Time_Studio_Preview.html in a browser on your Android device.

Important: this is a browser preview/project file, NOT an installable Android APK.
The preview does not itself package the real Minecraft add-ons or create an APK.
