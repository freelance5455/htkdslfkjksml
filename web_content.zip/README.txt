ABD-X Sensi — FINAL OB55 build

UI:
- Heavy visual gaming background with ABD-X SENSI branding.
- Generated ABD-X logo included.
- Brand -> Model -> Sensi Mode.
- Three separate modes for every listed device: Abnormal, Heavy, Brazilian.
- Every mode shows General, Red Dot, 2x, 4x, Sniper, Free Look, Recommended DPI and Fire Button.
- Infinix Note 10 Pro is included.

Research:
- YouTube OB55 guide: https://www.youtube.com/watch?v=HEuwKrA2k9o
- Taki FF OB55 guide: https://www.takiff.online/blog/best-ff-sensitivity-for-ob55
- The Click OB55 guide: https://www.theclick.gg/free-fire-max-one-tap-headshot-settings/
- Infinix Note 10 Pro reference: https://www.freefiremania.com.br/sensitivity/infinix-note-10-pro.html

Important:
The web sources disagree on exact per-device numbers, and no official Garena source publishes a universal "best" preset. This build therefore uses documented OB55 ranges/device-class guidance as the basis for deterministic starting presets rather than random numbers. No setting guarantees headshots or imitates a cheat/hack.
