POKÉPAD — HEARTGOLD GENERATIONS
Pacote preparado para conversores HTML → APK

Conteúdo:
- index.html (arquivo principal, na raiz)

Configuração sugerida no conversor:
- Nome: PokéPad — HeartGold Generations
- Orientação: Retrato
- Internet: ATIVADA

IMPORTANTE:
O aplicativo usa imagens/sprites e a API do PokeAPI online para tipos e evoluções. Portanto, mantenha a permissão de Internet ativada no conversor.

O index.html já contém a base de encontros do PokéPad e não depende de db.json para abrir.
