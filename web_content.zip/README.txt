TECHZENO APP PACKAGE
- index.html = the full website (must stay named index.html at the root of the zip).
- To make an APK: upload this zip to a "website/HTML to APK" converter (e.g. WebIntoApp, AppsGeyser, Median).

IMPORTANT FOR LOGIN (Firebase):
Firebase login does not work inside most zip-to-APK apps (they open the file locally).
Best method: host index.html on Netlify first, then give the converter the website LINK instead of the zip.
Also add that Netlify domain in Firebase > Authentication > Settings > Authorized domains.
