GARAGEM KIDS — VERSÃO 3

Projeto offline para controle de aluguel de 8 carrinhos elétricos infantis.

RECURSOS PRINCIPAIS
- 8 carrinhos
- Tela operacional com status Livre / Em uso / Pausado / Manutenção
- Início rápido: 10, 15, 20 e 30 minutos
- Timer individual e atualização automática
- Encerrar, pausar, retomar, editar e adicionar tempo
- Cliente/criança, responsável e operador
- Fila de espera
- Caixa, abertura, fechamento e conferência
- PIX, cartão e dinheiro
- Despesas
- Relatórios por período do dia, carrinho e funcionário
- Cadastro de clientes e equipe
- Backup/restauração local
- Exportação CSV
- Funcionamento offline com localStorage

IMPORTANTE
Este é um projeto HTML/PWA. Para gerar APK, importe este ZIP no HTML to APK Builder e use index.html como tela inicial.
