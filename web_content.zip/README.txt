XY LIFE SKILLS — 23 LESSON SEQUENTIAL READER

This is the app-ready HTML version of the existing 23 Core Life Skills book.

How it works:
1. Lesson 1 is unlocked.
2. The learner reads it and presses "Complete Lesson 1".
3. Lesson 2 automatically unlocks.
4. The same process continues through Lesson 23.
5. Progress is saved on the device using browser/WebView localStorage.
6. The content is bundled into the HTML, so it can work offline.

For Android:
- Put index.html into an Android WebView app's assets folder.
- Load it with: file:///android_asset/index.html
- No internet connection is required for the book content.

The source content used is the existing 23-Core-Life-Skills-Landscape-HD-HTML file.
