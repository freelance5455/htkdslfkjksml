FUCKA BARI - WhatsApp Order App
=================================

WhatsApp order number:
+8801345684003

How it works:
1. Add food to Cart.
2. Open Cart.
3. Enter Customer Name, Phone Number and Delivery Address (English).
4. Tap "Send Order on WhatsApp".
5. WhatsApp opens with the complete order message addressed to +8801345684003.
6. The customer still needs to tap Send in WhatsApp; normal wa.me links cannot silently send a message without the user's confirmation.

Main file:
index.html

The HTML uses Tailwind CDN and Google Fonts, so internet access is recommended when running it as a web app/APK.
