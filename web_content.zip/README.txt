BTC Balance Scanner — HTML edition for online ZIP-to-APK builders

1. Upload this ZIP to a builder that explicitly accepts an HTML/website ZIP (not a native Kotlin/Gradle project).
2. Set app name to BTC Balance Scanner.
3. Build/download signed APK.
4. Install on Android. Allow installation from the browser/file manager if Android asks.

This package contains index.html at the ZIP root. It scans public BTC addresses via the Blockstream public API and requires internet access. One address per line in a TXT file. The browser/webview must permit file selection and network access.

Never enter seed phrases or private keys. Test with a few addresses first. The app makes sequential public API requests with a delay; large lists may be slow or rate-limited.
