MonsterWalk Character-Fixed Advanced Build

This build specifically fixes the missing/invisible character:
- Player CSS is fully scoped so beast .head/.leg styles cannot override it.
- Player has a dedicated high z-index.
- Player is explicitly forced visible.
- Player is positioned by its feet and follows the camera.
- Added a visible ground shadow/ring and YOU label.
- Movement animation remains active.
- Beast tapping/encounters and infinite-world behavior are retained.

Use this ZIP in the same HTML-to-APK builder workflow.
