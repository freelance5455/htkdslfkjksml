OTP VIỆT – TALKBACK: ZIP DÀNH CHO CÔNG CỤ ZIP TO APK

Cấu trúc ZIP:
- index.html (ở thư mục gốc)
- style.css
- app.js
- manifest.webmanifest
- README.txt

Cách dùng:
1. Tải ZIP này lên ziptoapk.com theo hướng dẫn của trang.
2. Chọn tên ứng dụng "OTP Việt TalkBack" và biểu tượng nếu được hỏi.
3. Tạo APK, tải xuống và thử cài.
4. Nếu Android chặn cài đặt, chỉ cho phép cài từ nguồn đó khi bạn tin tưởng trang; sau khi cài có thể tắt quyền này lại.

QUAN TRỌNG:
- Đây là bản giao diện thử nghiệm phù hợp cấu trúc web ZIP-to-APK, KHÔNG phải ứng dụng OTPVN hoàn chỉnh.
- Chức năng API thật cố ý bị tắt. Không nhập token OTPVN thật vào bản này và không dùng để thuê số thật.
- Cần một backend/proxy được bảo vệ để gọi API OTPVN an toàn. Đóng gói trang web thành APK không tự tạo backend.
- Không thể bảo đảm trang ZIP-to-APK tạo ra APK hợp lệ; chỉ thử với bản thử nghiệm và kiểm tra quyền ứng dụng trước khi cài.
