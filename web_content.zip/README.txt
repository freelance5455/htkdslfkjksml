JARVIS Android project
Open this folder in Android Studio and build the APK.
Build > Build App Bundle(s) / APK(s) > Build APK(s).

The app includes a JARVIS UI, Android microphone permission, speech recognition and speech synthesis.
For real AI answers, connect the JavaScript frontend to a secure backend. Do not put an AI API key inside the APK.
