META AI CLONE — WEBSITE ZIP

For ZIP to APK tools that accept a website ZIP:
1. Select this ZIP file.
2. If Preview is available, open it to check the website.
3. Follow the converter's own Build/Export APK steps.

IMPORTANT:
- index.html is at the ZIP root.
- This is a responsive web-app demo with chat UI, local chat history, image attachment preview, theme toggle and browser voice-input support (if available).
- Replies are demo replies only. No live Meta AI/OpenAI service is connected.
- To enable real AI, connect a provider through a secure backend. Never put private API keys in app.js.
- Some ZIP-to-APK converters require a website URL instead of a local ZIP, or require internet access. Follow that converter's own requirements.
