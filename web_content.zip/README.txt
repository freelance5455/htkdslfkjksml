Iron Mechanics Glossary - APK Ready
استخدم هذا الملف ZIP في برنامج ZIP إلى APK.
مهم: يوجد ملف index.html واحد فقط في الجذر لتجنب فتح ملف قديم بالخطأ.
بعد تثبيت APK: افتح المساعد > إعداد ChatGPT، وضع عنوان السيرفر.
