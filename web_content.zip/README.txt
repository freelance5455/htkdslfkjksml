Websnap Capture
===============

Snap ID: ebcd84dc-ffe6-4d54-a533-e803e7f79a86
URL: https://the-hollow-app.base44.app
Pages: 1
Assets: 4
Captured: 2026-10-23T14:21:20.237Z

Files:
- *.html - Captured pages with navigation
- state-tree.json - Navigation tree structure
- _assets/ - Captured assets (CSS, images, fonts)
- *.jpg - Screenshots (available separately)

To view:
1. Extract this ZIP
2. Open any .html file in a browser
3. Click links to navigate between captured states
4. All assets are included for offline viewing