حكاية MVP: واجهة PDF واختيار أسلوب الحكاية والصوت والمدة.
التحويل الحقيقي يحتاج PDF text extraction + AI summarization/storytelling + TTS backend.
