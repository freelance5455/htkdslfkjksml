1. GitHub e notun repository banan (Public/Private duitoi cholbe).
2. Ei folder er shob file (.github folder shoho) repo te upload korun.
3. Repo -> Actions tab -> "Build APK" -> run hoye shesh hole (~5 min) "baby-feed-reminder-apk" artifact download korun.
4. Zip khule app-debug.apk phone e install korun (Unknown sources allow korte hobe).
5. Prothom bar Start chaple Notification ar Alarm permission allow korun.
