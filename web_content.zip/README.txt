DRUMMER'S METRONOME
===================

FILES
- index.html: the complete metronome app.

HOW TO USE ON ANDROID
1. Download index.html to your phone.
2. Open it using Chrome or another modern browser. If your phone only offers a file viewer, open the Downloads folder in a file manager and choose Chrome.
3. Press Start. If the voice does not speak, check that "Speak counts using a voice on this device" is enabled and that your browser supports speech synthesis.
4. For offline use, keep this file saved on your phone. The app itself does not need an internet connection once saved.

IMPORTANT
This version uses the speech-synthesis voice available in your browser/device, not included recorded human audio. A genuine recorded voice requires audio recordings to be supplied and bundled into the app. Very fast subdivisions may be difficult for any spoken voice to articulate clearly.
