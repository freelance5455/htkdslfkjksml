DAGACHAT V1 — application installable (prototype fonctionnel)
1. Ouvrir index.html dans Chrome.
2. L'inscription et les discussions sont simulées localement.
3. Cette version n'a PAS encore de serveur ni de vrais SMS/messages entre téléphones.
4. Pour une vraie messagerie Internet, prochaine étape : backend + base de données + authentification SMS.
