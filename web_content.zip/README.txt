STUDY TRACKER — ANDROIDIDE PROJECT

You do NOT need to write code.

1. Extract this ZIP on your Android phone.
2. Open the extracted "StudyTrackerAndroid" folder in AndroidIDE.
3. Let AndroidIDE finish Gradle/SDK setup.
4. Build -> Assemble Debug APK.
5. Install the generated APK.
6. Allow notifications when Android asks.

The existing HTML app is already inside:
app/src/main/assets/index.html

The native Android wrapper includes local notification scheduling:
- 15 minutes before activity
- activity start
- attendance window closing (10 min)
- activity end
- schedules restored after reboot

Important:
- Notification behavior depends on Android battery/alarms settings.
- Exact alarms may require Android's "Alarms & reminders" permission on some devices.
- The app is offline; no server is required.
