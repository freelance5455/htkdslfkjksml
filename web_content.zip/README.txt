FF STRATEGY BOARD - APK ke liye zip
====================================
Is zip mein:
  index.html     -> poora app (ek hi file, internet nahi chahiye)
  icon.png       -> app icon 512x512 (APK mein yahi icon lagao)
  icon-192.png   -> chhota icon
  manifest.json  -> app ka naam aur colors

APK BANANE KE STEPS (mobile par)
1. Is zip ko extract karo. index.html ka naam mat badlo.
2. Website 2 APK Builder (ya koi HTML-to-APK app) kholo.
3. "Offline / Local HTML" wala option chuno aur extract kiya hua folder select karo.
4. App ka naam: FF Strategy Board. Icon: icon.png.
5. Settings mein FILE UPLOAD / FILE CHOOSER option ON karo (map upload ke liye zaroori).
   JavaScript aur DOM Storage bhi ON rakho (maps save hone ke liye).
6. Build APK dabao, phir install karo.

TEST (install ke baad)
- "Apna Map Upload Karo" dabao -> gallery khulni chahiye -> map screen par aana chahiye.
- App band karke dobara kholo -> map aur drawing wahi milni chahiye.
- Upload na chale to Maps -> "Simple upload try karo".

Agar converter file upload support nahi karta to upload kaam nahi karega -
tab Capacitor ya Android Studio (WebView + onShowFileChooser) use karo.
