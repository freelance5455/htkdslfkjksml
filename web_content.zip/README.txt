IRON ARENA v3 - Offline 2D Fighting Game
Developer: Shakil Khan | Studio: Shefa Studio

PLAY: open index.html in a mobile browser (Chrome). Fully offline. Landscape recommended.
MAKE APK: open the android_project folder in Android Studio -> Build > Build APK(s).
 (The game files are already inside android_project/app/src/main/assets.)
Keyboard (testing): Arrows/A D W move+jump (hold W to fly), J punch (tap repeatedly = combo), K kick, S block, L special.
22 fighters, 4 arenas (Jungle, Mountains, River, City). Add fighters in the CH array of index.html.
