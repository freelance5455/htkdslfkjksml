CLINIQUE VÉTÉRINAIRE — VERSION V14

Modifications incluses :
- V14 : correction du parcours d’impression avec fichier HTML autonome, tentative de partage Android et messages explicites si l’APK bloque l’impression.
- V13 : boutons du tableau de bord plus petits et plus compacts sur téléphone et ordinateur.
- Interface modernisée en bleu nuit et turquoise.
- Accueil plein écran avec accès aux rubriques sans barre de navigation en doublon.
- Bouton Fermer avec demande de confirmation.
- Double appui sur Retour depuis l’accueil pour demander la fermeture.
- Tri des médicaments par nom, stock croissant/décroissant et péremption la plus proche.
- Impression avec deux méthodes : bouton Imprimer dans le navigateur compatible, ou Télécharger pour imprimer dans Chrome si l’APK bloque la fenêtre d’impression. Dans Chrome Android, ouvrez le fichier téléchargé, menu ⋮, puis Imprimer ou Enregistrer en PDF.
- Sauvegarde et restauration conservées uniquement dans Gestion du cabinet.
- Aucun bouton « Ajouter fichier » séparé : le sélecteur de fichier de restauration reste caché et s’ouvre uniquement depuis « Restaurer une sauvegarde ».
- Les fonctions et les données des modules V10 sont conservées.

IMPORTANT : faites une sauvegarde JSON dans Gestion du cabinet avant de remplacer l’ancienne application. Les données sont stockées localement sur l’appareil. Pour créer l’APK, décompressez ce ZIP si le générateur exige un ZIP de fichiers web ; index.html doit se trouver à la racine.

Si le bouton Imprimer ne fait rien dans l’APK, utilisez « Télécharger pour imprimer dans Chrome ». Ouvrez ensuite le fichier HTML téléchargé avec Chrome Android, appuyez sur ⋮ puis Imprimer et sélectionnez une imprimante ou « Enregistrer au format PDF ». La fermeture réelle peut également dépendre des capacités du générateur APK.


V14 — IMPRESSION : Dans l’aperçu, appuyez sur « Imprimer ». Si l’APK ne fournit pas de service d’impression natif, l’application tente de partager un fichier HTML autonome puis propose un téléchargement. Ouvrez le document dans Chrome et utilisez « Imprimer / Enregistrer en PDF ». Les capacités réelles dépendent du générateur APK/WebView. Faites une sauvegarde depuis Gestion du cabinet avant de remplacer la version installée.

V16 — INTERFACE SIMPLIFIÉE : un seul bouton « Imprimer le bilan » dans l’aperçu. Le bouton séparé « Exporter en PDF » a été supprimé. Le bouton unique conserve la génération du PDF et propose le partage/enregistrement selon les capacités Android.
