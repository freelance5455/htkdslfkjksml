Lulu Movers Survey Pro v28

Open lulu-survey-pro-v28.html in a modern browser. Keep regular JSON/Excel backups.
New in v28:
- Team Schedule: paste job text and auto-fill moves; Materials field; team, vehicle, driver and materials are mandatory before saving; saved moves auto-create/update Job Costing.
- Saved surveys: marking a survey Won (confirmed) creates a job cost sheet with an automatic CBM-based estimate; Lost now requires a reason.
- Confirmed & Lost page: confirmed job list, lost-job reasons report, CSV export, editable cost rates.
- Materials & Stock: edit, adjust balance and delete materials.
- HR: expiry symbol shown on the HR section only. Operations section removed from the menu.
- Leads CRM: Next stage, Assign and Start survey buttons on every lead.
Records stay in this browser/device unless exported.
