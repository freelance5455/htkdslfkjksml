Mirpurkhas Store — Final PWA-style app

Features:
- Modern blue/white shop UI
- Product search
- Product image upload from Admin
- Buy Now / order form
- Cash on Delivery only
- Customer orders saved locally
- Admin login + product management
- Order status management
- Seller chat demo
- PWA manifest + offline service worker

Demo Admin password:
MpkStore#2026

Important:
This package is a front-end/local app. Orders, products and chat are stored in the browser's localStorage. For a real public store where customers on different phones can place orders and you can receive them centrally, a secure backend/database and hosting are required. Do not put passwords, OTPs, MPINs, or other secrets in frontend code.
