KASA LIMP - APP POS
Esta versión es una aplicación web instalable (PWA).

INSTALACIÓN EN ANDROID:
1. Descarga y descomprime Kasa_Limp_App.zip.
2. Abre index.html con Chrome.
3. En Chrome usa "Añadir a pantalla de inicio" cuando esté disponible.
4. Los productos, inventario y ventas se guardan localmente en el dispositivo.

Incluye:
- Venta de líquidos por litro y mililitro.
- Venta por pieza, par y paquete.
- Carrito y cambio.
- Efectivo, transferencia y tarjeta.
- Inventario.
- Alta y edición de productos.
- Corte de caja.
