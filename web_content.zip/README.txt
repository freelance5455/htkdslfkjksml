Cosmetic Skins 1M - LIVE DATABASE EDITION

The app connects to the public Hugging Face Dataset Viewer API and reads the
neurlang/Minecraft-Skins-Captioned-1M dataset on demand. The dataset contains
about 981,079 unique skins. The app does not bundle the dataset, so the APK stays small.

Features:
- Live database pagination (24 at a time)
- Search
- Categories
- Favorites saved locally
- Preview
- PNG import
- Save/share PNG
- No ads/tracking code

Note: the dataset is third-party and not affiliated with Mojang/Microsoft.
Review its dataset license/terms before distributing an app commercially.
