Greek Maps - HTML app
Το index.html βρίσκεται στη ρίζα του ZIP, όπως απαιτεί το HTML-to-APK builder.
Η εφαρμογή χρησιμοποιεί online OpenStreetMap, Nominatim και OSRM.
