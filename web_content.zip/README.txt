POCKET APK STUDIO — MOBILE-FIRST MVP (v0.1)

WHAT THIS ZIP DOES
- Contains index.html at the archive root for HTML-to-APK tools such as ApkForge.
- Includes JSZip locally under assets/; ZIP import/export does not rely on a CDN.
- Inspects project ZIP entries, detects common project types, performs basic archive hygiene checks, exports inspection JSON/build plan, and prepares a compatible ZIP for ready-to-run static web projects.
- Includes a sample project flow for trying the interface without a real project.

WHAT IT DOES NOT DO YET
- It does not compile Kotlin/Java/Gradle/Flutter/React Native source into an APK.
- It does not itself create/sign an APK. The static-web bundle must be passed to a compatible HTML-to-APK packager.
- It is not a malware scanner or security certification tool.
- ZIP inspection happens inside the local browser/WebView session; no remote build API is configured.

USE WITH APKFORGE
1. Upload this ZIP. The archive root must contain index.html (it does).
2. Build an HTML/web-wrapper APK with app name Pocket APK Studio.
3. Open the installed app, import a ZIP, review findings, then export a static web bundle or build plan.
4. For a ready static web bundle, use a compatible packager to create a separate WebView APK.
5. For native Android source, follow the generated build plan with a real Android/Gradle toolchain.

LIMITS
- Input ZIP max 80 MiB; <= 2,500 entries; declared extracted size <= 200 MiB.
- Static web bundle export supports a ready index.html build output.
- React/Vite source-only projects should first be built (e.g. npm run build) in a supported Node environment.
- A browser-based wrapper cannot access Android system compiler tools just by being wrapped by ApkForge.

THIRD-PARTY LIBRARY
assets/jszip.min.js is JSZip v3.10.1, dual-licensed under MIT or GPLv3. See assets/JSZIP-LICENSE.markdown for the full license text.
