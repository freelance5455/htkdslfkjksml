FarmGrow Manager — downloadable prototype

HOW TO USE
1. Download and extract FarmGrow-Manager.zip, or open FarmGrow-Manager.html directly.
2. On a computer, open the HTML file in a modern browser. On Android, save the HTML file and open it using Chrome or another browser that supports local HTML files.
3. Add/edit crops, record fertilizer/chemical applications, and add dated farm tasks.
4. Use Backup / Restore to download a JSON backup and export application records to CSV.

DATA & LIMITATIONS
- Data is stored in the browser's local storage for the page's origin. Clearing browser data, using a different browser, or opening the file under a different origin may make it unavailable. Export backups regularly.
- This is a local prototype, not an online multi-user service. It does not automatically send reminders or sync between devices.
- A proper installable Android/iPhone app or hosted Progressive Web App would require hosting, testing, and optional user accounts/cloud backup.
- Chemical and nutrient rates must be verified for the specific crop, product label and Jamaican registration. The app records rates but does not prescribe them.
