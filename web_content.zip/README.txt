AURA / MUSE HTML package for APK Builder
Version: 1.3

IMPORTANT:
- index.html is intentionally located at the ZIP ROOT.
- This package is a self-contained offline HTML prototype.
- Import this ZIP using APK Builder's "Build from HTML or ZIP" option.

Included prototype features:
- AURA / MUSE dark violet mobile UI
- Home, Chat, Character Profile, Skills, Settings screens
- Local photo selection for the character portrait (photo stays in the local app session)
- Demo character states: idle, listening, thinking, speaking, happy, focused
- Local demonstration chat only; no real AI model/API is connected

Not included yet:
- Real GPT / DSH / WorkBuddy connection
- Cloud sync, account login, server-side memory
- Guaranteed speech recognition / text-to-speech support
- Live2D/3D animation or lip-sync

This ZIP is an HTML wrapper package, not a compiled APK. APK Builder must still build/sign the APK.
