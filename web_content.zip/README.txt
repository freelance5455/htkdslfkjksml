TradePilot MT5 AutoBot v2
This build adds an automatic DEMO signal engine. It generates test prices and automatically creates simulated BUY/SELL signals when its momentum threshold is met.
It does NOT use live market data and does NOT place real broker orders.
For live MT5 execution, connect a secure MT5 bridge/API and real-time price feed after demo testing.
