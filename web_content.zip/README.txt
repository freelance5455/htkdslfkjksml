Mis Tarjetas y Mis Créditos - versión final
Abre index.html en Chrome. Los datos se guardan en el teléfono mediante almacenamiento local del navegador.
Incluye cargos recurrentes dentro de Compras del mes, editables y cancelables.
