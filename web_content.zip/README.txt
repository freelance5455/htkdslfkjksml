CollegeMate PCM v4
Smart Campus design preserved.
Improved Notes, date-wise subject attendance/calendar, and advanced timetable with weekly + monthly/date view.
Offline-friendly single HTML app.
