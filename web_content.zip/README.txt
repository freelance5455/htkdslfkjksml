RIFF RECORDER - STARTER APP

Included: index.html, style.css, script.js, manifest.json, sw.js, icon.svg.
Features: microphone recording, bass/treble EQ, simple distortion, playback, download recording, PWA manifest/service worker.

PHONE-ONLY STEPS
1. Download and extract this ZIP on your phone.
2. On GitHub, create a NEW public repository.
3. Upload the FILES INSIDE the extracted folder to the repository root. Do not upload only the outer folder.
4. Open repository Settings > Pages.
5. Choose Deploy from a branch; select main and /(root), then Save.
6. Wait for publishing. Your site will look like https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/ .
7. Open the HTTPS site and test microphone permission/recording.
8. For Android packaging, open https://www.pwabuilder.com/ and paste your published site URL. Follow its Android packaging prompts.

NOTES
- Microphone access requires HTTPS and permission.
- This is a prototype, not a professional low-latency amp simulator. Real-time effects depend on the phone/browser and audio hardware.
- Use an appropriate guitar audio interface; never plug speaker-level output directly into the phone.
- Live monitoring can feedback. Use wired headphones and turn monitoring off if needed.
