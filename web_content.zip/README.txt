Roblox Lua Starter — виправлений ZIP

index.html знаходиться в корені архіву для HTML-імпортерів.
MovementPanel.client.lua — приклад LocalScript для власної гри Roblox Studio.

Встановлення:
1. Розпакуйте архів.
2. Відкрийте власну гру у Roblox Studio.
3. Додайте LocalScript у StarterPlayer > StarterPlayerScripts.
4. Скопіюйте код з MovementPanel.client.lua.

index.html є лише довідковою сторінкою. ZIP не запускає Lua-код у звичайному Roblox і не є executor.
