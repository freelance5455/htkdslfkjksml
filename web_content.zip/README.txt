SP GAME — Playable Prototype
1. Unzip this folder.
2. Open index.html in Chrome.
3. Tap PLAY LEVEL 1 or CAREER 1–50.
4. This is a prototype, not yet an Android APK/AAB.
To publish on Google Play, the project must be packaged as an Android app and prepared for Play Console requirements.
