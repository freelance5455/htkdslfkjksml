طريقة بناء الـAPK (مرة واحدة، على حاسوب):
1) ثبّت Android Studio (مجاني من developer.android.com/studio).
2) File ← Open ← اختر هذا المجلد (ArenaFighters). انتظر اكتمال Gradle Sync (يحتاج إنترنت أول مرة فقط).
3) من القائمة: Build ← Build Bundle(s) / APK(s) ← Build APK(s).
4) بعد انتهاء البناء اضغط Locate، ستجد الملف: app/build/outputs/apk/debug/app-debug.apk
5) انقل app-debug.apk إلى هاتفك وثبّته (فعّل "التثبيت من مصادر غير معروفة"). اللعبة بعدها تعمل بدون إنترنت.
لتغيير اللعبة لاحقاً: استبدل الملف app/src/main/assets/index.html
