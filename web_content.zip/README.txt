GAME FILE LAB V1
Primeira versão do novo projeto.

Inclui painel visual, seleção de arquivos, pesquisa, lista e visualização de arquivos de texto/JSON/INI/XML/CSV/JS/HTML/CSS, além de um modo demonstração.

A V1 não acessa diretórios privados de outros aplicativos e não altera jogos de terceiros. A base foi preparada para trabalhar futuramente com arquivos de projetos próprios ou autorizados, dentro das permissões do Android.
