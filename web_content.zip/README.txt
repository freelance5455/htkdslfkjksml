Baraa v16 — Luxe
- NEW hidden gift: "A star named Baraa" (replaces the old gift). Hold the two-arrows (sort) button in the notes screen for 3 seconds.
- NEW secret password screen (different look from the main lock). Secret word is NOT case-sensitive. Default: 1997.12.7
  After the correct word: the number "1" shows for 1.5 seconds, then the gift opens.
  To change the word: open the secret screen and tap "تغيير كلمة السر" (enter the current word, then the new one twice).
  The new word is saved on the device; clearing the app's data resets it to the default.
- NEW main lock screen: round keypad buttons with glowing dots (PIN 4 or 6 digits), or switch to a normal password.
  Existing passwords keep working (a numeric one shows the keypad, any other shows the text field; you can switch at any time).
- Total package size is under 5 MB (gift images/music re-compressed; gift lives in assets/gift/).
- v15: gift runs smoother (cached glow sprites, lighter canvas, app paused behind the gift, gift preloaded while typing the word).
- v16: fixed gift sky (preload size bug); default secret word is now Baraa.1

- music fix: gift music re-encoded (stereo, ~60kbps, proper header) + auto-resume if playback stalls; package ~4.8 MB; default secret word is now 1997.12.7 (year.month.day)
- gift gate: countdown to 7 Dec 2026 (days/hours/min/sec) above the lock box; on 7 Dec the password box disappears and only the open button remains (password also works before that day); after that day the normal password returns
- hidden: press the About photo for 1 second -> shows assets/self_photo.jpg with assets/self_music.mp3 (back/X closes and stops the music); gallery images resized to 1200px and both songs re-encoded (48k/40k, 32kHz) to stay under 5 MB
- about photo: now a single tap (not long press); self_music.mp3 replaced by the edited Spectacles track (98s); gift bgm.mp3 is now 'Jonna och Johan' (mono 32k to fit 5 MB). Previous gift track (Glimpse slowed) removed on request, can be restored.
- restored gift music Glimpse (slowed) (48k, -2dB to avoid clipping); about-photo music re-encoded 48k with -2.5dB headroom + soft fades (fixes crackle)
- v22 Plus: drawer items for Star corner (embedded game assets/stars.html), Wallpaper studio (8 palettes, logo, shuffle, save/share PNG 1080x2400) and Star of the day with daily streak
- v23: game modes (star rain with golden words + hazards, nature memory cards, word puzzles, 2-player tug/reaction), sounds; notes storage meter in drawer
- v24: ludo with sister, werewolf & witch (4 players, editable names, avatars), card flip animation, religious reminders level, prayer reminder at end of each game; story levels 5, rain 4, cards 4
- v25: werewolf redesigned (own night/day UI, roster, hunter role, log, avatar editor with hijab/hair/glasses/background, saved), ludo replaced by family game 'Stars Ladder' (2-4 players); gift music 44k to fit 5 MB
- v27: family game redesigned (big board, two dice buttons, editable players), memory cards = memorize then find, werewolf 4-6 players with gendered speech + timer + rules, richer sound effects; gift fonts now awaited (stylesheet + document.fonts) before drawing text
