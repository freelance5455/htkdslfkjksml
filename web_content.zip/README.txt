SHRI SHUBH PANCHANG - Android Studio project (AdMob ke saath)

1) Android Studio (free) install karein -> File > Open -> is folder ko chunein -> Gradle sync hone dein.
2) app/build.gradle me REAL_APP_ID ko apne AdMob App ID se badlein (ca-app-pub-3698737038057104~XXXXXXXXXX).
3) Test: Build > Build APK(s) (debug) -> Google ke TEST ads dikhenge (safe).
   Asli ads: Build Variants me "release" chunein -> Build APK(s). Apne ads par khud click na karein.
4) APK yahan milegi: app/build/outputs/apk/debug/ ya /release/
Ads: neeche banner har samay. Interstitial: sirf pehle zoom par, ek baar (pinch khatam hone ke ~1.5 sec baad).
