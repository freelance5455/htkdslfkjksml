TOGO AI ULTRA — PROTOTYPE WEB + ANDROID
=======================================

IMPORTANT
- Les fichiers du site sont prêts pour être hébergés.
- L'interface seule ne fournit pas de réponses IA réelles : le serveur Worker doit être déployé et relié à une clé API.
- Le fournisseur peut proposer une offre gratuite avec des quotas qui changent. Vérifie les conditions et les limites actuelles avant usage.
- Ne publie jamais ta clé API dans index.html ni dans un dépôt public.
- Ce prototype n'inclut pas encore de comptes utilisateurs, d'historique cloud, de génération d'images ou de création automatique d'APK.

A. CONFIGURER LE SERVEUR IA (Cloudflare Workers)
1. Crée un compte Cloudflare et ouvre Workers & Pages.
2. Crée un Worker et colle le contenu de worker.js, puis déploie.
   Autre possibilité : installe Node.js sur un ordinateur, puis exécute :
      npm install -g wrangler
      wrangler login
      wrangler deploy
   depuis le dossier du projet.
3. Dans les paramètres du Worker, ajoute le secret GEMINI_API_KEY avec ta clé obtenue depuis Google AI Studio.
4. Vérifie que GEMINI_MODEL correspond à un modèle disponible pour ta clé et ton compte. Le modèle par défaut du fichier peut changer de disponibilité.
5. Teste l'adresse du Worker en ajoutant /api/health. Tu dois recevoir {"ok":true,"service":"Togo AI Ultra"}.
6. Dans index.html, trouve :
      const API_BASE = "";
   Remplace par l'URL de ton Worker, par exemple :
      const API_BASE = "https://togo-ai-ultra-api.ton-compte.workers.dev";
   Remplace l'exemple par TA vraie URL, sans /api/chat à la fin.
7. Héberge index.html, manifest.json, sw.js et icon.svg ensemble. Le serveur Worker est séparé.

B. OBTENIR UNE CLÉ GEMINI
1. Ouvre https://aistudio.google.com/
2. Connecte-toi et vérifie si l'accès API est disponible pour ton compte et ton pays.
3. Crée une clé API et garde-la secrète.
4. Les offres gratuites ont des limites, peuvent changer et ne garantissent pas une utilisation illimitée. Ne promets pas une IA gratuite sans limites.
5. Si l'API demande une facturation ou n'est pas disponible, n'ajoute pas de carte sans l'accord d'un adulte responsable ; on peut rechercher une autre option.

C. HÉBERGER LE SITE GRATUITEMENT
Option simple : Cloudflare Pages ou GitHub Pages pour les fichiers du site.
- Téléverse les fichiers du site (index.html, manifest.json, sw.js, icon.svg) dans un dépôt ou un projet Pages.
- Le Worker est l'API séparée.
- Une page Web installable (PWA) peut être ajoutée à l'écran d'accueil Android depuis le menu du navigateur.
- Pour le service worker/PWA, le site doit être servi via HTTPS (localhost pour test local).

D. UTILISER SUR ANDROID
1. Ouvre l'URL HTTPS du site dans Chrome.
2. Menu ⋮ > Ajouter à l'écran d'accueil ou Installer l'application si l'option apparaît.
3. Cela donne une expérience proche d'une application. Ce n'est pas encore un fichier APK natif.
4. Pour fabriquer un APK, utilise ensuite un outil de conversion WebView/PWA fiable. Vérifie ses conditions : les conversions et signatures APK ne sont pas toujours gratuites.

E. TEST LOCAL
Ouvre le dossier sur un ordinateur et démarre un serveur local :
  python -m http.server 8000
Puis visite http://localhost:8000.
Sur Android seul, utilise un hébergeur HTTPS ou un éditeur local avec serveur local.

F. DÉPANNAGE
- « serveur IA pas encore configuré » : renseigne API_BASE après avoir déployé le Worker.
- Erreur 503 : secret GEMINI_API_KEY manquant.
- Erreur 502 : clé invalide, modèle indisponible, quota dépassé ou panne du fournisseur.
- Erreur CORS : restreins ou ajuste Access-Control-Allow-Origin dans worker.js selon le domaine du site.
- Ne publie pas le Worker sans protection si tu crains un usage abusif : une API publique peut être appelée par d'autres personnes et consommer ton quota. Avant un lancement public, ajoute une limitation de débit, une protection anti-abus et une surveillance des coûts.

PROCHAINES ÉTAPES CONSEILLÉES
- Ajouter une limite d'utilisation par utilisateur et une politique de confidentialité.
- Ajouter un écran de réglages, historique local, choix de langue.
- Ajouter plus tard d'autres modèles et outils, sans prétendre remplacer toutes les IA spécialisées.
