KISAN MOTOR & TRACTOR LEDGER

This source is a static ES-module web app. It can run locally in a browser and can
be deployed to Firebase Hosting. It is not itself a finished APK.

FIREBASE SETUP
1. Create a Firebase project and enable Google as an Authentication provider.
2. Create Firestore and publish firestore.rules.
3. Copy the web app config into firebase-config.js.
4. Host this directory on HTTPS. Firebase web authentication requires a trusted
   origin; configure that origin in Firebase Authentication.
5. Keep a downloaded backup until cloud sync has been confirmed from a second
   browser/device.

FIRESTORE AND CONFLICTS
- Farmer, worker, and entry records live in the existing compatible collections
  users/{uid}/customers/{id}, users/{uid}/workers/{id}, and
  users/{uid}/entries/{id}. Shared rates and custom categories live in
  users/{uid}/settings/main.
- Collection snapshots use onSnapshot. There is no whole-ledger document write.
- Firestore is initialized with persistentLocalCache and a multi-tab manager;
  environments where browser persistence is unavailable fall back to the SDK's
  in-memory cache and log a warning.
- Each record has updatedAt and _fieldUpdatedAt timestamps. Concurrent changes
  merge per field; a newer field timestamp wins. Deletes are soft deletes, so
  deleted:true and the original record remain syncable and can be restored.
- Pending writes are persisted in a local outbox and retried after reconnection.
  The local ledger and outbox are stored in browser local storage. For
  substantially larger histories, migrate the persistence adapter to IndexedDB
  or Capacitor Preferences/Filesystem rather than enlarging a single localStorage
  value; retain downloadable backups.
- On first sign-in, a legacy users/{uid}/ledger/main backup is migrated into the
  new collections and retained for recovery. Do not manually delete it until
  migration has been confirmed.
- Firestore client timestamps depend on the device clock. Devices should have
  automatic date/time enabled for predictable conflict ordering.

MODULES
- app.js: UI, forms, route history, validation, filtering, and ledger actions.
- ledger-store.js: local persistence, outbox, Firestore snapshots, migration,
  field-level merge, soft deletes, and restore.
- date-utils.js: local calendar date keys (does not convert through UTC).
- firebase-client.js: Firebase initialization.
- native-adapters.js: browser fallbacks plus Capacitor plugin adapters.

CAPACITOR PREPARATION
- The app uses browser download/print fallbacks on the web and checks the
  Capacitor Filesystem, Share, and App plugins when available.
- For a bundled Capacitor build, install and register @capacitor/filesystem,
  @capacitor/share, and @capacitor/app, then expose their plugin APIs through
  Capacitor.Plugins or adapt native-adapters.js to the installed plugin version.
- Native Google authentication is an integration point at
  window.KisanNativeAuth.signIn(auth). Implement it with a supported native
  authentication plugin and exchange the resulting credential with Firebase.
  Popup sign-in remains the browser fallback and should not be relied on inside
  Android WebView.
- App route changes are written to browser history. Android back events use the
  Capacitor App plugin when present, with browser popstate as the fallback.

DATE AND BUSINESS LOGIC
- Date keys and the displayed app date use Asia/Karachi via Intl.DateTimeFormat,
  not UTC conversion or the device's configured timezone.
- Dashboard and reports share the same inclusive date range filters.
- Tractor and field-work rates are independent settings, as are solar and WAPDA
  motor-bill rates. Motor-bill entries select Solar or WAPDA and use that rate.
- Custom field-work categories are stored in settings.customCategories and sync
  with the user's settings document.
- Worker attendance is recorded per worker and date. Present earns the full
  configured rate, half-day earns one half, short-day earns two thirds, and
  absent earns zero. Daily workers use their daily rate; monthly workers use
  their monthly salary divided by the calendar days in that month. Payments
  subtract from the worker's calculated balance.
- Reports default to the current month and support optional Farmer and Worker
  filters. Clearing a person filter includes all records for the date range.
- Entry edits update individual records. Deleted entries remain in the deleted
  list on Settings and can be restored.

The source has no build step or automated test runner. Open index.html through
HTTPS or a local static server to test it. Verify sign-in, offline entry creation,
reconnection, conflict scenarios on two devices, restore, and APK plugin setup
before using real business data.
