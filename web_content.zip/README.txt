WhatsApp Ban Checker Pro - HTML edition

How to use with an HTML-to-APK builder:
1. Extract this ZIP.
2. Import index.html as the app's start page, or import the extracted folder if supported.
3. Allow internet access in the APK builder if you want the official wa.me link to open.
4. Build and install the APK.

Important limitations:
- WhatsApp does not provide a public endpoint to determine whether any phone number is banned, temporarily restricted, or active from the number alone. The Check button opens the official wa.me route; it is not an automatic ban scan.
- SIM carrier/phone number/signal details cannot be read by a plain HTML page in Android WebView. The app shows browser-accessible network status and offers an attempt to open Android settings. Full SIM data requires a native Android app and Android permissions.
- Never enter or share your WhatsApp verification code or password with third-party tools.
- Records are stored locally in browser/WebView localStorage.
