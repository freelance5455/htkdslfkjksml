Split Antagoniste Pro — édition 3D partielle

Ouvrir index.html dans un navigateur. Fonctionne sans connexion.
Nouvelles vues 3D départ/arrivée : Tirage vertical neutre et Rowing barre buste penché.
Les autres exercices conservent les illustrations précédentes : leur remplacement en 3D reste à faire.
Les illustrations 3D sont générées et ne sont pas des références biomécaniques certifiées.
Onglet Mes max : renseigner les 1RM; les charges indicatives apparaissent dans Entraînement.
Ce dossier HTML n’est pas un APK Android.
