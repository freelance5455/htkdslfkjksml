AUSTRALWEATHER 1.0
==================

COMO EXECUTAR
1. Extrai o ZIP.
2. Abre index.html num navegador com ligação à internet.
3. Escolhe um país e uma cidade no menu lateral.

FUNCIONALIDADES
- Condições meteorológicas atuais consultadas na API Open-Meteo.
- Previsão horária e para 7 dias.
- Temperatura, sensação térmica, humidade, vento, rajadas, probabilidade de chuva, UV, pressão, nuvens, ponto de orvalho, visibilidade, nascer e pôr do sol.
- Seletor de país e cidade, comparação regional, alternância °C/°F e tema claro/escuro.
- Layout responsivo para telemóvel e computador.

NOTAS
- É necessária ligação à internet para consultar os dados e carregar a fonte externa.
- A versão inicial usa a API pública da Open-Meteo. Consulta os termos e limites de uso antes de publicar comercialmente: https://open-meteo.com/en/pricing
- Os dados são previsões estimadas e não substituem avisos oficiais das autoridades meteorológicas.
- Se abrires o HTML localmente e o navegador bloquear pedidos, experimenta servir a pasta com um servidor local (por exemplo, a extensão Live Server no computador).
- Lista de cidades editável em js/cities.js.
