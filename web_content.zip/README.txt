PRIME BUSINESS — déploiement statique de démonstration

Le fichier index.html est la page d'accueil à téléverser sur Cloudflare Pages.
Ce site reste un prototype : le panier ne traite pas de paiement, le code admin est public côté navigateur et les données sont locales à l'appareil.
Ne l'utilisez pas pour encaisser de vrais paiements ou stocker des données clients.
Orange Money, comptes clients, base de données et authentification sécurisée ne sont pas implémentés.
