UNSER VORRAT – Gothic Layout + Produktfoto

Diese Version hält das gewünschte Gothic-Neon-Layout fest und ergänzt im Artikel-Formular:
- Produktfoto aufnehmen (Android-Kamera über Bildauswahl)
- Foto aus Galerie auswählen
- Foto-Vorschau und Foto entfernen
- Foto wird komprimiert und im vorhandenen product_image_url-Feld gespeichert
- deutlich sichtbare Option „Produkt für später merken“

Die vorhandenen Supabase-, MHD-, Mengen-, Einkaufs-, Rezept- und Realtime-Funktionen bleiben erhalten.
Barcode/Kamera-Funktion des Barcodes wurde nicht verändert.
