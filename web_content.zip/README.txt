MOTY BET — Virtual-credit prototype

Files:
- index.html: responsive web app
- manifest.webmanifest: installable web app metadata
- sw.js: basic offline cache

Run:
1. Upload the files to a static web host (keep all files in the same folder).
2. Open the HTTPS website on Android Chrome.
3. Use Chrome menu > Add to Home screen / Install app.

This prototype uses illustrative fixtures and virtual credits only. It has no real-money deposits, payouts, live odds, authentication backend, or admin server. The Android home-screen install is a PWA; a signed APK requires a separate Android wrapper/build step.
