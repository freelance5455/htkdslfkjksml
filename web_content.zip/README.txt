JT WINDOW CLEANING PRO — VERSION 3
- Dedicated customer profile view for each customer.
- Profile includes clickable Google Maps address, contact info, notes, photos, job history, and transaction history.
- Edit customer details, notes, and photos from profile.
- Revenue Log supports individual transactions and running totals.
- Data remains local to this browser until cloud sync is implemented.
- Serve from HTTPS for PWA installation.
