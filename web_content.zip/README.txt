PS4 Shop Manager prototype v3

Open index.html in Chrome on Android to test. This is a browser prototype, not an APK.
Includes console timers, configurable pricing, player loss balances/draw carry-forward/minimizer, session history, expenses, revenue reports, and local JSON backup.
Session history and CSV export show exact start and end date/time and actual elapsed duration.
Data is stored locally in the browser. Back up regularly.
