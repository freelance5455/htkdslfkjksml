RPGMVP PNG Converter

Upload this ZIP to an HTML & ZIP to APK builder.
IMPORTANT: index.html is at the ZIP root, as required by most builders.

The converter processes .rpgmvp and .png_ images locally in the app.
It reconstructs standard RPG Maker encrypted PNG headers without System.json.
