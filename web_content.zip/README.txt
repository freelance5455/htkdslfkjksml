ZIP-to-APK READY PACKAGE

This ZIP intentionally contains index.html at the ROOT so ZIP-to-APK apps can detect it.

IMPORTANT:
- This is a local HTML starter, not a Laravel/PHP server.
- PHP/Laravel cannot run inside a basic ZIP-to-APK HTML wrapper.
- For a real Laravel website, keep Laravel on HTTPS hosting and use an Android WebView app that opens the hosted website.
- Do not put secret payment API keys in index.html or inside an APK.
