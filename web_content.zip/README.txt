İNCİR ALTI BALIK DÜNYASI — HTML prototip

KULLANIM:
1) ZIP dosyasını açın.
2) Dönüştürücü uygulamada mümkünse index.html dosyasını seçin veya ZIP'i seçin.
3) Eğer uygulama yalnızca proje klasörü/HTML dosyası kabul ediyorsa, index.html dosyasının doğrudan seçilmesi gerekir.
4) Uygulama içindeki ekranlar demo/prototiptir.

ÖNEMLİ:
- Bu paket HTML arayüz prototipidir; canlı sunucuya bağlı değildir.
- Giriş ekranı gerçek kullanıcı doğrulaması yapmaz.
- İlanlar diğer telefonlara gönderilmez ve uygulama kapatılınca kalıcı kayıt garantisi yoktur.
- Canlı hava durumu, bildirimler, hesaplar, ilan kayıtları ve güvenli yönetici paneli için ayrıca backend gerekir.
