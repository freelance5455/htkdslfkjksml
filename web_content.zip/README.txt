WahidMedX — FINAL SEARCH-FIX BUILD

Search rules fixed:
1. Famous/established companies AND famous individual brands/products are both prioritized.
2. Exact brand search (e.g. Zerodol SP) returns only products with the SAME complete composition, strength and dosage form.
3. Combination composition searches are exact and order-independent.
4. Single-API searches return only single-ingredient products of that API/strength; combinations are excluded.
5. These rules apply globally to all medicines, not only Zerodol SP/Aceclofenac examples.
6. Old IndexedDB data is versioned to v4 so the corrected search logic starts cleanly.

Catalogue source remains the existing Indian medicine dataset package used by this build.
Reference-only app. Verify current regulatory/price information from authoritative sources before use.
