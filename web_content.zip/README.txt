D3R TELETEXT - pacchetto web installabile

Contenuto:
- index.html: applicazione
- manifest.webmanifest: configurazione installazione
- sw.js: cache dei file dell'app

IMPORTANTE:
Questa è una prima versione PWA (web app installabile), NON un APK Android.
Per installarla come app da Chrome occorre pubblicare questi file su un hosting HTTPS,
poi aprire l'indirizzo sul telefono e scegliere 'Installa app' / 'Aggiungi a schermata Home'.

La visualizzazione incorporata dipende dalle policy del sito RAI. È presente un collegamento
alternativo per aprire la pagina Televideo direttamente sul sito ufficiale.
D3R Televideo è indipendente e non è un'app ufficiale RAI.
