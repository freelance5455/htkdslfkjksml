SHARON MONEY SAVER — APK BUILDER PROJECT

FIX FOR “index.html NOT FOUND”
1. Extract this ZIP file first.
2. Open your APK builder and choose its HTML / Website / WebView app option.
3. Select the extracted project folder (or upload index.html, if the builder asks for a single file).
4. Make sure index.html is at the ROOT of the selected folder. Do not select a parent folder that contains another folder named Sharon_Money_Saver_APK_Builder_Project.
5. If the builder accepts a ZIP, upload this ZIP and check that index.html appears at the top level.
6. Set the app name to: Sharon Money Saver
7. Build / Export APK.

FEATURES
- Set and save your current pocket-money balance
- Add money with a reason and amount
- Withdraw money with a reason and amount
- Blocks withdrawals larger than the current balance
- Transaction history with date/time
- Dark neon gaming-style interface
- Saves data locally on the device using localStorage

IMPORTANT
This is the HTML project intended for APK builders that package an index.html app inside an Android wrapper. It is not a compiled APK by itself. Choose the builder's HTML/Website/WebView app type; a native-only Android project importer may not accept it.
