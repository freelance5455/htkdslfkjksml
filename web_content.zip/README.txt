Survey Engineering Calculator
=============================

App Name   : Survey Engineering Calculator
Owner      : Mubashir Amjed
Version    : 1.0
Platform   : Android (via HTML-to-APK) / Any modern browser
Mode       : Fully Offline

DESCRIPTION
-----------
Professional offline calculator for road survey, civil engineering 
and quantity estimation. All calculations run locally on the device.
No internet, no cloud, no demo data.

IMPORTANT NOTES
---------------
• This is a COMPLETELY SEPARATE application from TST Calco.
• TST calculations are NOT included.
• Bitumen / mix design calculations are NOT included.
• Engineering results MUST be verified against approved drawings, 
  specifications and BOQ before use on site.

MODULES INCLUDED
----------------
Core:
 1. Area & Volume Calculation
 2. Level Survey (Height of Instrument Method)
 3. Rise & Fall Method
 4. Average End Area Formula
 5. Prismoidal Formula
 6. Trapezoidal Cross Section
 7. Road Cutting with Side Slopes
 8. Chainage Calculation
 9. Gradient / Slope Calculation
10. Camber / Crossfall Calculation
11. Coordinate Inverse Calculation
12. Polar to Grid Coordinates
13. Simple Circular Curve Calculation
14. Asphalt Quantity Estimation (volume / mass only)
15. Unit Converter
16. Bearing to Azimuth Conversion

Advanced:
17. Transition Curve (IRC & theoretical)
18. Vertical Curve (parabolic elements)
19. Irregular Cross-Section Earthwork
20. Road Quantity Estimation

FEATURES
--------
• Clean mobile-first interface
• Search formulas
• Step-by-step calculation display
• Formula shown for every module
• Results to 4 decimal places
• Input validation & division-by-zero protection
• Calculation history (saved on device via localStorage)
• Copy result button
• Reset fields
• Fully offline

HOW TO USE WITH HTML-to-APK
--------------------------
1. Unzip this file.
2. The file index.html is at the root of the ZIP.
3. Upload the entire folder or just index.html into your 
   HTML-to-APK builder (most builders accept the index.html 
   at root).
4. Build the APK.
5. Install on Android device. No internet permission needed.

TECHNICAL
---------
• Single file application (HTML + CSS + JavaScript)
• No external libraries or CDN
• Uses only localStorage for history
• Works on modern Android WebView / browsers

Developed for Mubashir Amjed
Survey Engineering Calculator v1.0
