STREET SPRINT — arcade racing game

A simple mobile-friendly racing game with:
- Three-lane steering
- Traffic to avoid
- Stars collected during gameplay
- Score and replay screen

This is a conventional arcade racing game. It has no gambling, betting, wagering, cash prizes, or real-money rewards.

Upload this ZIP to a site/app builder that accepts a ZIP containing index.html. Preview the game before packaging it.

Note: this ZIP contains a playable web game, not a signed Android APK. The app builder must support packaging HTML into an Android app.
