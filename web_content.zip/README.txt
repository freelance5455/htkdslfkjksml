A1 Classes FINAL V2
Marks are now configurable for every exam.
Admin enters Obtained Marks + Total Marks separately, e.g. 18/20, 27/30, 42/50, 76/80, 91/100.
Percentage/progress is calculated automatically from the configured total marks.
Admin demo password: admin123.
This remains an offline prototype; a production multi-device app needs a secure cloud backend/database.
