W5 FC V1 — PACOTE INICIAL
==========================

CONTEÚDO
- index.html: ecrãs e estrutura da aplicação
- style.css: design responsivo para Android
- app.js: navegação, clubes, plantel WJ FC e progresso local
- manifest.webmanifest: configuração de aplicação web instalável
- sw.js: cache offline (PWA)
- icons/: ícones da aplicação

COMO TESTAR
1. Extrai o ZIP.
2. Publica a pasta num alojamento HTTPS estático (por exemplo, GitHub Pages ou Netlify).
3. Abre o endereço HTTPS no Chrome do Android.
4. Usa o menu do Chrome > "Instalar aplicação" ou "Adicionar ao ecrã inicial".

IMPORTANTE
- Este pacote é uma primeira versão PWA, não um APK.
- Para instalar como PWA, o projeto deve ser servido por HTTPS ou localhost.
- O modo offline funciona depois de o service worker guardar os ficheiros.
- O modo online ainda não está implementado e exigirá servidor.
- A demonstração de partida desta V1 não é ainda um jogo 3D jogável.
- A seleção de clubes existe; plantéis de clubes mundiais são placeholders.
- O WJ FC contém os jogadores e posições indicados na especificação.

PRÓXIMA ETAPA
Integrar o motor 3D, campo, jogadores articulados, bola física, IA, árbitros,
animações, som, competições e restantes funcionalidades planeadas.
