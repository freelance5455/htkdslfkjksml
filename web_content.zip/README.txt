# Jackaroo Offline

## Included
- `index.html`: complete single-page offline game
- `manifest.webmanifest` and `sw.js`: installable PWA/offline cache support

## Play
1. Extract the ZIP.
2. Open `index.html` in Chrome/Edge. No internet or server is required.
3. Choose **2 खिलाड़ी** or **4 खिलाड़ी**. Pass the device after each turn.
4. Select a card, choose its action, then tap the required marble on the board.

## Android
Open `index.html` in Chrome on Android. For install support, serve the extracted folder once over HTTPS or localhost and choose **Add to Home screen**. The game itself runs offline after the first successful load.
This package does not include a compiled APK. To make a signed APK, wrap this web app in Android Studio using a WebView or Capacitor and build it with Android SDK/Gradle.

## Rules note
Jackaroo has regional rule variations. This build uses a 76-space loop and the card guide shown inside the game. It is a local hot-seat game (not online multiplayer).
