LOOK COACH - PACKAGE APK PREMIUM

Nom: Look Coach
Package ID suggere: com.lookcoach.app
Orientation: portrait
Fichier principal: index.html
Icone: assets/icon_512.png
Splash screen: assets/splash_1080x1920.jpg

Envoyer ce dossier/ZIP a un convertisseur HTML vers APK/AAB.
