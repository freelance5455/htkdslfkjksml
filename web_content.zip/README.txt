Pixel Runner 3D
- index.html is at the top level of this zip (what APK builders expect).
- Online: it works as is (loads three.js from the internet).
- Offline / APK: save https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
  as three.min.js next to index.html, then zip both files together.
