My Notebook Lite — AppOfWeb compatibility package

This package preserves the existing app HTML and features. It includes the same index.html at both the ZIP root and web/index.html because HTML-to-APK builders differ in which location they package as the app entry page.

Import this ZIP as a new project. If the builder offers a start-page field, set it to index.html. If it explicitly asks for a web folder entry page, choose web/index.html.

This package cannot fix a server-side API rate limit or a bug inside the APK builder. If the resulting APK still shows https://appassets.androidplatform.net/web/index.html with ERR_HTTP_RESPONSE_CODE_FAILURE, the builder is failing to package/serve that asset path; its project settings/support or a different builder will be needed.
