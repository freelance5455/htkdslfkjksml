WBX GAMER0.2 Tournament Demo v2

Requested demo tournament:
- 12 Squads
- Entry: 30 Demo Coins
- 1st Prize: 160 Demo Coins
- 2nd Prize: 100 Demo Coins
- 3rd Prize: 60 Demo Coins

এটি শুধুমাত্র demo coins ব্যবহার করে। Real-money payment/cash prize নেই.
