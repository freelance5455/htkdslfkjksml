NEON AI ONE-FILE APK PACKAGE

1. Extract/upload this ZIP to a ZIP-to-APK builder.
2. The app has CHAT, IMAGE, EDIT and SETUP.
3. In SETUP enter an OpenAI-compatible HTTPS endpoint and API key.
4. Chat uses /responses.
5. Image generation uses /images/generations with gpt-image-1.
6. Image editing uses /images/edits with gpt-image-1.

IMPORTANT:
- This direct-client version sends the API key from the device to the endpoint.
- Do not embed a valuable/private production API key in a distributed APK.
- Some APK/WebView environments or API providers may block browser-origin requests (CORS). If that happens, a backend/proxy is required.
- API/model availability and pricing are controlled by the provider and can change.
