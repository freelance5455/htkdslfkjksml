Contractor Pro V17 — Globalization & Security Hardening

Base: verified Contractor Pro V16 AI Copilot & Smart Capture.

V17 adds:
- Globalization hardening for locale/currency/time-zone/date/calendar behavior already present in the core.
- Local app lock with 4–8 digit PIN using device-side SHA-256 hashing.
- Optional auto-lock interval.
- Failed-attempt throttling.
- Offline-first behavior preserved.
- V16 AI Copilot & Smart Capture preserved.
- V16 Cloud/Sync, License, Team/Client Portal and Notifications layers preserved.

Important: This is still an offline APK-ready web build. Real email authentication, OTP, biometric authentication, encrypted cloud storage, server-side authorization, subscription validation and remote security require the production backend. No fake online service is embedded.

Packaging: index.html is at ZIP root for HTML-to-APK converters that require root index.html.
