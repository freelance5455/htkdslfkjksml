Saif Ullah working app package.
Upload all files to an HTTPS static host to enable Install App and offline caching.
Open hosted index.html in Android Chrome > menu > Install app.
Data is stored locally in the browser/app WebView storage. Back up regularly.
This is a working first version; please test calculations with sample entries before relying on it for official balances.
