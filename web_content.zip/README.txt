STUDENT PLANNER V2 — BLUE & WHITE EDITION

What's included
- Redesigned responsive blue-and-white interface inspired by the supplied reference.
- Five tabs: Tasks, Daily Plan, Marks, Mood and Calendar.
- Larger icon navigation, refined cards, progress indicators and improved empty states.
- Existing browser data key (localStorage: sp) retained, so existing saved data should continue to load in the same browser.
- PWA manifest, app icon and service worker for installability and basic offline caching.

Run locally
1. Extract this ZIP.
2. Open todomate/index.html in a browser. For PWA installation/service worker testing, serve the folder over HTTPS or localhost.

Deploy to Netlify
1. Extract the ZIP.
2. Drag the todomate folder (the folder containing index.html) into Netlify Deploys, or connect its Git repository.
3. Open the deployed HTTPS URL on Android Chrome and choose Install app / Add to Home screen.

Notes
- Tasks, plans, marks and moods are stored locally in the browser on that device. They are not automatically synced between devices.
- The mood chart visualizes the most recent seven mood check-ins; it is a lightweight visual summary, not a medical measure.
