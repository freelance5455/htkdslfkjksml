AL-IHSÃN CREATIVE AGENCY — WEBSITE SOURCE

What's included:
- index.html: responsive multi-section website (Home, Our Services, About Us, Contact Us)
- WhatsApp buttons open a chat with +234 902 296 1896
- Email button opens Ihsangraphixe@gmail.com
- No installation required to test the website

HOW TO TEST ON ANDROID:
1. Download the ZIP file.
2. Open your phone's Files app and find the ZIP in Downloads.
3. Tap it and choose Extract / Unzip.
4. Open the extracted folder and tap index.html.
5. If asked, choose Chrome or another browser.

IMPORTANT:
This ZIP is the website source, NOT an Android APK or Play Store AAB yet.
To publish on Google Play, the project must be packaged and tested according to current Google Play requirements.
Facebook button currently opens Facebook's main website; replace its URL with your exact page URL if needed.
