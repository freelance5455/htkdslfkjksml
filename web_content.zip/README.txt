BUILD STATUS
This build is the working frontend and Android WebView project generator.

Flow:
Choose ZIP -> Preview -> Create App -> Build APK -> Download APK -> Install APK.

The first four local stages work in the browser. A real APK binary cannot be compiled by
plain HTML/JavaScript in Chrome. Build APK therefore requires a real Android/Gradle build
server configured under Build Server.

API contract:
POST /build (multipart/form-data)
webProject, appName, packageName, versionName, versionCode

Immediate response:
{"apkUrl":"https://your-server.example/app.apk"}

OR job response:
{"jobId":"123"}
Then GET /build/123 until:
{"status":"complete","progress":100,"apkUrl":"https://.../app.apk"}

Never send private projects or signing keys to an untrusted build service.
