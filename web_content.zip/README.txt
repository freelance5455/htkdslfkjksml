GST & Income Tax Calculator — Fixed App Builder ZIP

CONTENTS
- index.html: Updated calculator with revised PDF, print and preview actions.
- APP_DETAILS.txt: App name, package name, version and builder settings.

HOW TO BUILD
1. Upload this ZIP to an HTML-to-APK / Website-to-APK builder that accepts ZIP files.
2. Set the start page to index.html.
3. Enter the App Name and Package Name from APP_DETAILS.txt.
4. Enable JavaScript and local/offline HTML support.
5. If available, enable downloads from WebView.
6. Build the APK and test PDF, preview and print on the target device.

NOTES
This is a source ZIP, not an APK. Native printing depends on the APK builder's Android WebView implementation. The app includes a PDF export fallback for Android WebViews that do not support the native print dialog.
