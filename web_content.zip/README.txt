GOES Mobile — projeto Web/PWA pronto para conversão em APK

O projeto replica a interface principal do notebook e usa os JPEGs pré-renderizados do serviço público da NOAA/NESDIS/STAR. Isso permite funcionar em um WebView sem instalar Python/xarray/cartopy no Android.

Recursos:
- GOES-16 / GOES-19
- 16 bandas ABI
- Data, hora e minuto UTC
- Área de interesse com retângulo no mapa
- Visualização da imagem NOAA
- Botão para abrir/baixar o original
- Modo de animação GIF
- Seleção de duração, intervalo e FPS
- Opção GLM na interface

Observação técnica: o notebook original trabalha com NetCDF bruto, Cartopy e a paleta numérica customizada do C13. Nesta conversão móvel, a fonte é a imagem JPEG já renderizada pela NOAA; portanto, a saída não é numericamente idêntica ao processamento CMI/NetCDF original e a camada GLM do notebook não é re-renderizada pixel a pixel.

Para gerar APK: compacte o CONTEÚDO desta pasta com index.html na raiz e use um conversor HTML/ZIP -> APK, ou abra em Android Studio como WebView/Capacitor.
