ATTENOVA — INSTALLABLE APP EDITION
Tagline: Attendance. Simplified.
Created by Adil Latif

PACKAGE CONTENTS
- index.html — app interface and attendance features
- manifest.webmanifest — ATTENOVA install identity
- sw.js — offline app-shell caching (updated cache version)
- attenova-icon-192.png and attenova-icon-512.png — app icons

WHAT'S INCLUDED
- Smooth page transitions, subtle card motion and responsive button feedback.
- Upload, preview, replace and remove a profile picture. Photos are cropped to a square, resized and compressed before being stored locally.
- Switch between top navigation and a left-side navigation layout. On small screens, side navigation opens as a slide-out menu.
- Light and dark themes.
- First-launch student profile setup (full name, college name and year of study).
- Profile details can be edited later in Settings; profile is stored locally on this device.
- Configurable attendance target.
- Subjects, Present / Absent / Leave records, class-type prompt.
- Monthly calendar with attendance-day colours and daily details.
- Weekly timetable planner.
- Attendance insights and subject comparison.
- Attendance target calculator.
- JSON backup/restore and CSV export.
- Offline-first app shell through the service worker.

DATA PRESERVATION
The existing localStorage key and attendance data structure are retained. Updating the app files does not intentionally reset existing profile, subjects, timetable or attendance records. New profile-photo and navigation settings are added to the existing profile/app data. Download a JSON backup before updating or changing devices as a precaution.

INSTALLATION
1. Extract this ZIP.
2. Host the extracted folder on an HTTPS static host such as GitHub Pages or Netlify.
3. Open the HTTPS address in Chrome on Android and choose Install app / Add to Home Screen.
4. On iPhone, open the HTTPS address in Safari, tap Share, then Add to Home Screen.
5. Open the app once while online so the app shell and icons can be cached for offline reopening.

IMPORTANT LIMITATIONS
- This is an installable Progressive Web App (PWA), not a signed APK or Play Store package.
- Attendance records, profile and photo are stored locally in the browser/device. They do not automatically sync between devices.
- Cloud sync, Google sign-in, owner approvals and remote admin controls are not included.
- Browser storage can be cleared; download backups regularly. The profile photo is compressed to reduce storage use.
- Service-worker installation and offline caching require HTTPS hosting (or localhost). Opening index.html directly is preview-only.


Version 4 dashboard update:
- Removed dashboard quick-action buttons (Record a class / Open calendar) and the Quick tip panel button.
- Added a student profile card showing profile photo, student name, college name, and year of study.
- Profile card reads existing locally saved profile data; update details/photo from Settings.


Version 5 navigation fix: the mobile menu opens on the first tap, section buttons navigate reliably, the menu closes after a section is selected or the user taps outside it, and the service-worker cache has been versioned to ensure the updated app is loaded. Existing local attendance/profile storage key is unchanged.


Version 6 reliability fix:
- Fixed a JavaScript rendering error caused by dashboard elements that were removed in the profile-card redesign.
- Navigation and theme controls now work independently of dashboard rendering.
- Mobile menu state, close behavior and theme-color metadata are updated reliably.
- Existing localStorage key am20_app_v3 is unchanged.
