RSA.AI Web Edition
====================
این نسخه یک Web App مستقل و بدون نیاز به سرور است.
فایل اصلی: index.html

برای APK Forge:
1) فایل RSA.AI-WEB.zip را انتخاب کن.
2) گزینه Zipped site را بزن.
3) چون داخل ZIP فایل index.html وجود دارد، APK Forge می‌تواند آن را به‌عنوان سایت دریافت کند.
