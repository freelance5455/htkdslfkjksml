MOON AI STUDIO v2
Features: AI Chat, Code Generator/Editor, AI Edit/Copilot, Website Builder + Preview,
Image Lab, AI Writer, Project Context, API Settings, Android WebView wrapper.

IMPORTANT:
HTML provides the interface and API client. Real AI generation requires a compatible
backend endpoint. Do not publish private API keys in client-side HTML. For a public app,
use your own server-side proxy.

Android project is build-ready, but compilation requires Android Studio/SDK + Gradle.
