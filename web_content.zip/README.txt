WhatsPoint website package
- index.html: app preview
- manifest.json: app metadata
- sw.js: basic offline cache
This is a demo UI only. Secure accounts, verified referrals, and real cash/airtime payouts are not included.
For HTML to App, choose “Zipped site” and upload this ZIP.