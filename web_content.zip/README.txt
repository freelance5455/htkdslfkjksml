SELF ATTENDANCE APP
====================

This is a working browser-based first version.

How to use:
1. Open index.html in Chrome on Android.
2. Go to Setup.
3. Add your subjects.
4. Add each weekly timetable period.
5. Set the number of working days and minimum attendance (75% by default).
6. Go to Holidays and add college/school holidays. Sundays are automatically holidays.
7. Open Today and tap PRESENT or ABSENT for each scheduled class.
8. Dashboard automatically calculates subject-wise attendance and shows warnings below 75%.

Data is stored locally in the browser using localStorage.

Note:
- The app does not yet automatically fetch official Indian government/college holiday lists. You select holidays in the app, while Sundays are automatic.
- Browser notification permissions are not required for the first version; the Dashboard provides the 75% warning. Native Android notifications can be added in the next version.
