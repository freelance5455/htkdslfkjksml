INVERTER HOME - WASHING MACHINE PARTS STOCK APP

This is an offline, phone-friendly stock management web app.

How to use:
1. Open index.html in a browser.
2. Add it to your phone home screen if your browser offers "Add to Home Screen".
3. Add parts, then use Stock In/Out.
4. Use Backup -> Export Backup regularly.

Data is stored locally in the browser on the phone. Clearing browser/site data can remove it, so keep backups.
