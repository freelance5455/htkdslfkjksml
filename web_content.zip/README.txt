শিক্ষা Offline — Student Learning App (Fixed Mobile AI Version)

এই ZIP-এ যা আছে
- প্রথমবার Admin account setup করতে হবে না। ডিফল্ট Admin ID: Abir; Password: Abir@123
- Student Login ফর্মের উপরে শুধু ফুল থাকবে; ফুলের নিচে শুরুতে কোনো লেখা থাকবে না।
- ফুলটি একটানা ৫ সেকেন্ড ধরে রাখলে ১০ থেকে reverse countdown শুরু হবে। countdown শেষ হলে Admin Login খুলবে। মাঝখানে ছেড়ে দিলে countdown বাতিল হবে।
- Admin Panel: Student account তৈরি/ডিলিট, student password reset, class update, practice history দেখা/ডিলিট
- Student: নিজের profile আপডেট, practice করা, নিজের history দেখা/মুছে ফেলা
- Admin Offline Knowledge Base-এ Q&A/MCQ add/delete এবং knowledge pack import/export
- Admin App Management: app name, announcement, AI model ID, admin password পরিবর্তন, সব practice history মুছুন
- JSON backup export/import; IndexedDB local storage; app shell service worker cache
- Class 1–10, SSC, HSC, Honours, Degree, Masters selector

চালানোর নিয়ম
1. ZIP extract করুন।
2. HTTPS hosting বা localhost-এ চালান। সরাসরি file:// থেকে AI module/service worker কাজ নাও করতে পারে।
3. Student যোগ করার আগে ফুলটি ৫ সেকেন্ড ধরে রাখুন; এরপর ১০ সেকেন্ডের countdown শেষ হলে Admin Login খুলবে।
4. Admin ID: Abir; Password: Abir@123। নিরাপত্তার জন্য Admin Panel থেকে প্রথম সুযোগেই পাসওয়ার্ড বদলে নিন।
5. Admin Panel থেকে Student account তৈরি করুন। এরপর Student ID ও password দিয়ে লগইন করুন।
6. Test/Practice-এ Offline AI চালু / Model Load চাপুন। প্রথমবার ইন্টারনেট চালু রাখুন।

AI মডেল ও ডাউনলোড
- ডিফল্ট মডেল: onnx-community/SmolLM2-360M-Instruct-ONNX, q4 quantization। এটি আগের 1.7B মডেলের চেয়ে ছোট এবং 3–4 GB RAM Android ফোনে চেষ্টা করার জন্য বেশি উপযোগী।
- ZIP-এ AI model weights অন্তর্ভুক্ত নেই। প্রথমবার Transformers.js লাইব্রেরি ও মডেল ফাইল ডাউনলোড করতে ইন্টারনেট লাগবে। q4 model file প্রায় 400 MB; tokenizer/config ফাইলসহ মোট ডাউনলোড কিছুটা বেশি হতে পারে।
- মডেল ডাউনলোড/লোড করার সময় HTTPS বা localhost ব্যবহার করুন, স্থিতিশীল Wi-Fi ও অন্তত 2 GB ফাঁকা স্টোরেজ রাখুন এবং পেজ খোলা রাখুন।
- WebGPU উপলব্ধ থাকলে প্রথমে সেটি চেষ্টা করবে; ব্যর্থ হলে CPU/WASM মোডে আবার চেষ্টা করবে। CPU মোডে উত্তর তৈরি ধীর হতে পারে।
- মডেল ওজন, Transformers.js লাইব্রেরি ও প্রয়োজনীয় assets ZIP-এ নেই বলে প্রথমবার থেকেই সম্পূর্ণ অফলাইন চালানো সম্ভব নয়। সফল ডাউনলোডের পর একই browser-এর cache/storage অক্ষত থাকলে offline কাজ করতে পারে; browser data clear, private mode বা storage eviction হলে পুনরায় ডাউনলোড লাগতে পারে।
- 360M মডেল ছোট হওয়ায় উত্তর দুর্বল বা ভুল হতে পারে; বিশেষ করে বাংলা, গণিত ও পাঠ্যবই-ভিত্তিক উত্তরে যাচাই করুন। নির্ভরযোগ্য অফলাইন উত্তর পেতে Admin-এর Offline Knowledge Base-এ পাঠ্যবই-যাচাইকৃত প্রশ্নোত্তর যোগ করুন।
- Admin Panel → App Management থেকে Model ID বদলানো যায়। ভুল বা Transformers.js/ONNX-compatible নয় এমন ID দিলে AI লোড হবে না।

ডেটা ও নিরাপত্তা
- অ্যাপের ডেটা এই browser/device-এর IndexedDB-তে থাকে; অন্য ডিভাইসে নিজে থেকে sync করে না। JSON backup-এ model weights থাকে না। নিয়মিত backup নিন।
- ডিফল্ট Admin credentials সবার জানা থাকতে পারে; প্রথম লগইনের পর অবশ্যই পাসওয়ার্ড পরিবর্তন করুন। এটি local demo authentication, production-grade security নয়।
