AIM OS — archive compatible avec le convertisseur « Site zippé »

IMPORTANT : index.html est placé directement à la racine du ZIP, comme demandé par le convertisseur montré dans la capture.

Cette archive convertit une interface AIM OS web en APK WebView si le convertisseur accepte les sites HTML.
Elle n'est PAS le projet Android natif Gradle. Les actions Android (Paramètres / composeur) dépendent des autorisations et des liens pris en charge par le convertisseur. Le navigateur ne peut pas garantir la lecture de la RAM physique exacte ni augmenter la RAM du téléphone.
Tout le code de cette page est inclus dans index.html ; aucun accès Internet n'est nécessaire.
