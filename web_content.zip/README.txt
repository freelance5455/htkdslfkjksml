Saravanabhava Translinks - Black & Gold APK source

This ZIP contains index.html at the root and embeds your supplied official logo.
To create APK on Android: use an HTML/ZIP-to-APK builder; upload this ZIP, set app name to Saravanabhava Translinks, and build signed APK. Test all data entry, backup/restore, and offline behavior before using for business records. Data stays on the device/browser storage. Keep exported backups safe.

Final visual update: full black theme, gold accents, white statistic numbers, login name Sukumar Dharani. This is source HTML, not a compiled APK.
