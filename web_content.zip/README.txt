SheSafe - fixed HTML source

This ZIP is intended for an HTML-to-APK builder that accepts index.html at the ZIP root.

Fixes in this version:
1. Nearby police/hospital/women-support searches now navigate to Google Maps using a standard Maps Search URL instead of window.open('_blank'), which commonly fails in simple Android WebViews.
2. Saved safe-place navigation uses the same Maps URL approach.
3. Fake Call now creates audible beeps using Web Audio and vibration where supported. It requires the app page to remain open, the phone volume to be up, and the WebView to permit audio. This is a simulation, not a real incoming phone call.
4. Journey Check-in now opens an SMS draft to the phone number entered when starting the journey. The user must press Send. The app records a local timestamp but cannot confirm SMS delivery.

Important limitations:
- This is a corrected HTML source ZIP, not a rebuilt/signed APK.
- The APK must be rebuilt with an Android WebView wrapper that supports external https links, tel: and sms: intents, and Web Audio.
- Background tracking, automatic missed-check-in escalation, and automatic SMS sending are not implemented. Do not rely on this app as the only emergency safety method.
- JavaScript syntax was checked with Node.js; the APK has not been tested on a physical Android device.
