LIVE POLL APP - how to turn this into an APK

Files: index.html (the whole app, works offline, no internet needed)

Easiest: upload this ZIP to a website-to-APK converter
(e.g. WebIntoApp, Appmaker, AppsGeyser "HTML5 app"). index.html is at the zip root.

Developer way (Capacitor):
  npm i @capacitor/core @capacitor/cli @capacitor/android
  npx cap init LivePoll com.example.livepoll --web-dir=.
  npx cap add android && npx cap sync && npx cap open android
  Build > Build APK(s) in Android Studio.

If photo upload does not open: your converter WebView blocks file pickers. Use Capacitor + @capacitor/camera (npm i @capacitor/camera), or the "Photo link" button.

Data (title, names, votes, photos) is saved on the device automatically.
