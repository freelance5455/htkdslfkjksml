AgroVision AI Starter for ApkForge

1. Upload this ZIP using ApkForge's "Zipped site" option.
2. The ZIP contains index.html at its root.
3. Preview the site, then choose Create app.
4. This is a front-end starter/demo. It does NOT include a trained AI model, server, database, live weather, or real disease diagnosis.
5. To enable real AI diagnosis, connect a trusted crop-disease model/API and a secure backend. Do not put secret API keys in index.html.
