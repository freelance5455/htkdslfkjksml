NEON BIKE RUSH X — LANDSCAPE EDITION · V2.8
===========================================

MAIN FILE
- index.html is directly in the ZIP root.

PROJECT FILES
- src/game.js: game engine, race controls, traffic, pickups, upgrades and gyro steering
- src/style.css: responsive landscape-first interface and swapped bottom control layout
- manifest.json: requests landscape display when installed as a PWA
- sw.js: versioned offline cache

UPDATED MOBILE LAYOUT
- Bottom-left corner: PAUSE, ACCEL, BRAKE, NITRO and DRIFT controls.
- Bottom-right corner: analogue steering joystick.
- Top-centre: gyroscope status and GYRO ON/OFF switch.
- The gyro panel stays clear of both bottom control groups.
- No rotate-device blocking message.

RUN ON ANDROID
1. Extract the ZIP.
2. Open the extracted folder in Spck Editor, or open index.html in Chrome.
3. Tap START RACE. The game continues even if landscape locking is unavailable.
4. Tap the top-centre GYRO switch to enable phone-tilt steering. Grant sensor permission if requested.
5. If the sensor is unavailable, steer with the bottom-right joystick.

CONTROLS
- Joystick (bottom-right): steer left/right.
- ACCEL (bottom-left): increase speed while held.
- BRAKE (bottom-left): slow down while held.
- NITRO (bottom-left): spend energy for a speed boost.
- DRIFT (bottom-left): build drift combo bonuses.
- PAUSE (bottom-left): pause/resume the race.
- GYRO switch (top-centre): enable/disable phone tilt steering.

KEYBOARD
- Arrow keys / A and D: steer
- W / Up: accelerate
- S / Down: brake
- Space / Shift: nitro
- X: drift
- P / Escape: pause

FEATURES
- Landscape-first responsive racing game
- Swapped bottom-corner touch controls and top-centre gyro panel
- Perspective road, changing scenery, roadside lighting and lane markings
- Traffic, rival bikes, collision and shield protection
- Acceleration, braking, nitro boost and drift combo bonus
- Coin, nitro-energy and shield pickups
- Garage upgrades: engine, nitro capacity and handling
- Sound effects, pause/resume, race report and personal-best tracking
- Local save for credits, upgrades and best distance
- Offline service-worker cache after first load when served over HTTPS

GYROSCOPE NOTE
The game uses the browser DeviceOrientation API. Some browsers require HTTPS and/or
an explicit sensor permission. Sensor support differs by device. Use the on-screen
joystick whenever tilt control is unavailable or permission is denied.

This is an original 2D arcade racer with perspective graphics, not a full 3D simulator.
