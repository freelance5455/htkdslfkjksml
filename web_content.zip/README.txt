Busdriver Navi V9 – OpenStreetMap

Auf HTTPS-Webserver veröffentlichen und in Chrome als PWA installieren.
Karten benötigen Internet und Leaflet-CDN. Kein Google Maps API-Key nötig.
GPS funktioniert nur über HTTPS/localhost. Keine geprüfte Busnavigation.
© OpenStreetMap-Mitwirkende; https://www.openstreetmap.org/copyright
