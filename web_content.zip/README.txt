ANIME CARD QUEST V2
New features: one-by-one booster reveal, illustrated card faces, collection gallery, quick battle mode, gems and daily reward.
To update your HTML-to-App project, upload this ZIP as a new zipped site and create a new app build. Keep your old build until the new one works.
