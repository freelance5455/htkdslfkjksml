PULGUITA IA - versión web/APK
- index.html autónomo, sin librerías externas ni internet requerida para arrancar.
- Memoria local con localStorage.
- Chat básico y respuestas locales.
- No incluye todavía búsqueda web real ni modelo de IA externo.
- Para convertir a APK, mantener index.html en la raíz del ZIP.
