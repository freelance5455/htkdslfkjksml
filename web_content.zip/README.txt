# Paris Open World — Android v0.1

Prototype mobile jouable dans un navigateur Android.
- joystick tactile
- personnage
- voiture
- mission Tour Eiffel
- environnement urbain prototype

Ouvrir `index.html` dans Chrome/Firefox Android.
Cette version est un prototype : elle n'est pas encore un APK natif Unreal Engine 5.
