# Dayal Computer Center - Android Studio Project (APK Builder)
Proprietor: Rahul Kumar
Address: Shahu Ji Market, Salarpur Chauraha, Sitapur (U.P.) - 261135
Mobile: 9005281033
Email: rkverma02014@gmail.com

## Is Android App Project Se APK Kaise Banayein?
Yeh ek complete **Android Studio Project** hai jisme aapka official logo (`app_logo.png`), Java code (`MainActivity.java`), aur offline app UI (`index.html`) pehle se set hai:

1. Is ZIP file ko extract (unzip) karein.
2. Apne computer mein **Android Studio** open karein.
3. **"Open"** par click karke extract kiye gaye folder ko select karein.
4. Gradle sync poora hone dein (1-2 minute lag sakte hain).
5. Upar menu mein **Build > Build Bundle(s) / APK(s) > Build APK(s)** par click karein.
6. Kuch hi der mein aapki **`app-debug.apk`** file ban jayegi, jise aap kisi bhi Android phone mein bhejkar install kar sakte hain!
