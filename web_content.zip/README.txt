# Mon Argent — PWA de gestion financière en FCFA

## Contenu
- `index.html`, `styles.css`, `app.js` : application.
- `manifest.webmanifest` : configuration PWA.
- `sw.js` : cache hors ligne.
- `icon.svg` : icône.

## Installation sur Android
Une PWA installable doit être servie depuis une adresse HTTPS (ou localhost pour le développement). Le fichier ZIP seul ne s'installe pas directement comme une APK.

1. Décompresse le dossier.
2. Héberge les fichiers à la racine d'un site HTTPS (par exemple un hébergement statique).
3. Ouvre l'adresse dans Chrome sur Android en étant connecté à Internet.
4. Choisis le menu ⋮ puis « Installer l'application » ou « Ajouter à l'écran d'accueil ».
5. Ouvre une première fois l'application en ligne ; les fichiers seront ensuite disponibles hors connexion.

## Données initiales incluses
- Banque : 297 000 F
- Espèces : 760 000 F
- MTN MoMo : 274 000 F
- Orange Money : 65 000 F
- Salaire mensuel prévisionnel : 300 000 F
- Frais bancaires mensuels : 1 193 F
- Fonds entreprise déclarés : 682 000 F location + 100 000 F vente d'accessoires, déjà inclus dans les soldes physiques.

## Sauvegarde
Les données sont stockées dans `localStorage` du navigateur sur l'appareil. Utilise régulièrement « Exporter une sauvegarde JSON ». Une désinstallation ou l'effacement des données du navigateur peut supprimer les données locales. La sauvegarde JSON permet de les restaurer.

## Note importante
Cette application est une première version locale. Elle ne se connecte pas à ta banque ni à Mobile Money et ne vérifie pas automatiquement les transactions. Enregistre les opérations réelles manuellement.
