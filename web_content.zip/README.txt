MY ELECTRIC WORK - starter app
Open index.html in Chrome.
This is an offline starter version with Hindi/English toggle, wiring plan, room area,
wire estimate, material list, load calculation and estimate.
It is not yet an Android APK; the files are ready to be packaged as an APK later.
