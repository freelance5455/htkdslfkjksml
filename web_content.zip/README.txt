NJ RÉVISE 4e HUMANITÉ — V5 CAHIER + PROFESSEUR

Cette version transforme l'application en cahier numérique pédagogique.
- Lecture page par page
- Introduction du professeur
- Définitions
- Exemples guidés
- Étapes numérotées
- Explication du pourquoi de la méthode
- Erreurs fréquentes
- À retenir
- Exercices et corrections
- Évaluation de chapitre
- Progression locale
- Recherche
- Interface mobile

Contenu modèle détaillé : Mathématiques, SVT, Sciences Physiques.
La prochaine extension consiste à remplir le même niveau de détail pour l'ensemble des chapitres du programme officiel de 4e Humanité Scientifique.
Aucun module de musique n'est inclus.
