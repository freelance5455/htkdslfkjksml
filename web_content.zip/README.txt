NEON RAIN v5 - PC / Android APK build asset

The app source is index.html.
If a direct HTML download link fails, download this ZIP and extract it.
For an Android Studio WebView project, place index.html in:
app/src/main/assets/index.html
Then load it with:
webView.loadUrl("file:///android_asset/index.html");

This ZIP contains the HTML source only; it is not a compiled APK.
