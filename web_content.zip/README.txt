ARISE v3 — installable Android PWA (not a compiled APK)

HOW TO INSTALL
1. Upload ALL files in this folder to a static HTTPS host (GitHub Pages, Netlify, Cloudflare Pages), keeping names.
2. Open the site in Chrome on Android > menu > "Install app".
3. Your old v2 data (same browser/host) is migrated automatically. Or use Settings > Import backup.

WHAT'S NEW
- Guided workout player: animated exercise demos, set/rep tracking, rest timers, hold timers, beeps, vibration, screen wake lock
- Adaptive engine: recommendations from readiness, recovery and rolling 7-day targets; auto-progression of reps/holds from "too easy / just right / hard" feedback
- Run/walk with 5 progressive levels; recovery flow and breathing exercise
- Daily quests, XP, levels, E-to-S ranks, attributes radar, 20 badges, personal bests
- Responsive weight/waist charts with tap details, weekly minutes, month calendar, weekly review
- Metric/imperial units, backup/restore with validation, safety gating on pain/symptom check-ins
- Fixes: restored-habit state, notifications via service worker (Android-safe), network-first updates, storage errors handled

LIMITATIONS
- Data is local to the device (no cloud sync). Background reminders are not guaranteed on Android.
- Not medical advice.
