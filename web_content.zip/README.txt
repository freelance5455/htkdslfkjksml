አርኪ ካፌና ሬስቶራንት – Final Menu
1) index.html ን በbrowser ይክፈቱ ወይም ZIP ፋይሉን ወደ app builder ይጫኑ።
2) Menu ይሰራል፣ Add Item / Photo / Edit Price / Delete Item ይሰራሉ።
3) Admin PIN = 1234
4) ትዕዛዝ በዚያው ስልክ ውስጥ ይመዘገባል፣ WhatsApp ደግሞ ወደ 0969296547 ይከፈታል።
5) የድር ሊንክ እና QR እንዲሰሩ ይህን ፋይል መጀመሪያ በweb hosting/app builder ላይ publish ማድረግ ያስፈልጋል።
