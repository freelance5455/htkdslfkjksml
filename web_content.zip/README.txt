SCHNEIDER Kids v2
Updated quiz flow: each game now has five questions in sequence.
The child sees feedback after each answer and taps Next question to continue.
One point is awarded after completing all five questions in a game.
Includes local progress, Kreyol/French/English UI, parent gate and demo-only ad toggle.
No real ads, no accounts, no analytics, and no external network requests.
