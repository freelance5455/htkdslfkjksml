M ALHAISAM CUSTOMER SERVICE — HTML APP (UPDATED)
=================================================

Included updates:
- Official uploaded M ALHAISAM logo is now used throughout the app.
- Daily Sales Detail: product/service, quantity, date, time, rate, amount and profit.
- Monthly Sales Detail: product/service, quantity, date, time, rate, amount and profit.
- Dashboard shows daily/monthly item summaries plus View All detailed tables.
- New Bill has a Bill Preview button before saving.
- New Bill preview can be printed.
- Bill History Preview is preview-only and intentionally has NO Print button.
- Thermal printing defaults to 58mm auto-height, with optional 80mm.
- Separate barcode scanner for Product entry and separate scanner for New Bill.
- Repeated bill scans add repeated quantities.
