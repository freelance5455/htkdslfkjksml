NEON HIGHWAY 2.0 — WebIntoApp HTML ZIP

Upload the ZIP as an HTML project, with index.html at the ZIP root.
This is a fully offline single-file HTML5 Canvas game. No server or internet required.
Garage purchases and level progress use browser localStorage; preserving app storage is required for progress to survive app updates.
Sounds are synthesized with Web Audio after user interaction. Enable audio in WebView.
Graphics are stylized pseudo-top-down Canvas cars, not photorealistic 3D models.
For an installed app update, retain your previous Android package ID and signing certificate and increment version code.
