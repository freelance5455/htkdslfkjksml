DemoBank EDU — Ethiopian-inspired mobile banking education prototype

IMPORTANT:
- Fictional demo app only.
- No real money, bank connection, account access, or payment processing.
- Do not use it to mislead anyone or present test activity as real bank activity.
- All accounts and balances are made up.
- QR payments are a visual simulation; camera scanning is not enabled.

Open on Android:
1. Download and extract DemoBankEDU_Ethiopian_Style_Phone.zip in My Files.
2. Open the extracted folder.
3. Tap index.html and choose Chrome.
4. If your file manager will not open it, use a local HTML viewer/editor app.

Starting demo accounts:
Fira Demo — ETB 10,000
Mimi Sample — ETB 4,500
Abel Test — ETB 2,500

Demo PIN for future login practice: 1234
This version does not require a login. Balances reset if the page is refreshed/closed.
