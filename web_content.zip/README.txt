DoruYob WebView repair package

Contains index.html at both the ZIP root and web/index.html for builders that expect either layout.

If an already-installed AppsGeyser APK shows net::ERR_HTTP_RESPONSE_CODE_FAILURE for appassets.androidplatform.net/web/index.html, the packaged app asset/build may be missing or damaged. Import this ZIP into the website/app builder and rebuild/reinstall the APK; replacing a ZIP on the phone alone will not change the installed APK.

Обновление: в разделе «История размещения» справа у каждого лекарства есть кнопка «Отметить». Нажатие окрашивает строку в красный цвет; отметка сохраняется на устройстве. Повторное нажатие снимает отметку.
