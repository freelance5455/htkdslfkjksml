Santosh Dhaba Web App ZIP
========================
This is a lightweight offline web-app version designed for web-to-APK converters.

Files:
- index.html
- style.css
- app.js
- manifest.json

It stores entries on the device using localStorage and supports CSV export.
The module buttons are included; the current build provides a common entry ledger
rather than the complete Excel-equivalent workflow.

For a web-to-APK service, upload the contents/ZIP as requested by that service.
