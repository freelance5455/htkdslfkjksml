FIFA AI Manager X v2.0.0 - APK Web Bundle
Entry point: web/index.html
This package is structured for converters that load appassets.androidplatform.net/web/index.html.
