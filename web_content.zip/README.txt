PIZZERÍA LA ESQUINA — PROYECTO ANDROID

Qué incluye
- Menú de ejemplo con precios editables.
- Carrito con cantidades y total.
- Nombre y teléfono del cliente.
- Retiro en el local o envío con dirección.
- Preparación del pedido para enviarlo por WhatsApp.
- Menú editable que queda guardado en ese teléfono.

IMPORTANTE
Este ZIP contiene el proyecto Android Studio, no un APK ya compilado.
No incluye servidor ni panel administrativo en línea. Los cambios del menú se guardan localmente en el teléfono donde se hacen.
El número de WhatsApp configurado es 543388000000. Para cambiarlo, abrí:
app/src/main/assets/index.html
Buscá:
https://wa.me/543388000000?text=
y reemplazá el número por el de tu negocio, con código de país y sin el signo +.

CÓMO GENERAR EL APK EN UNA COMPUTADORA
1. Instalá Android Studio desde https://developer.android.com/studio
2. Descomprimí este ZIP.
3. En Android Studio, elegí Open y seleccioná la carpeta PizzeriaLaEsquinaAndroid.
4. Esperá a que termine la sincronización de Gradle. Si pide instalar Android SDK 35 o componentes, aceptá.
5. En el menú, elegí Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Cuando termine, tocá “locate” en la notificación. El APK suele quedar en:
   app/build/outputs/apk/debug/app-debug.apk
7. Pasá el APK al celular, abrilo y autorizá la instalación desde esa fuente si Android lo solicita.

PARA PROBAR SIN GENERAR APK
En Android Studio conectá el celular por USB con Depuración USB habilitada y pulsá Run (▶). También podés usar un emulador.

PRUEBA RÁPIDA
1. Agregá una o más pizzas.
2. Comprobá cantidades y total.
3. Completá nombre y teléfono.
4. Elegí retiro o envío; si elegís envío, completá la dirección.
5. Tocá “Enviar pedido por WhatsApp”. Se abrirá WhatsApp con el pedido preparado; revisalo y enviá manualmente.

LIMITACIONES DE ESTA VERSIÓN
- Los productos y precios son de muestra: editá el menú antes de usarla comercialmente.
- Los pedidos se envían a WhatsApp; no hay base de datos ni panel administrativo remoto.
- La app requiere conexión para abrir WhatsApp y enviar el pedido.
- El proyecto necesita Android Studio para compilar el APK; no se garantiza que compile en todas las configuraciones sin instalar los componentes indicados.
