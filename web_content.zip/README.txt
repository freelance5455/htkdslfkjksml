MH MIRAZ AI — Android Studio project

1. Open android-app/ in Android Studio.
2. Build/install using Android SDK and Gradle available in your environment.
3. In the app, open Settings > AI Connection and enter your own Gemini/OpenAI key.
4. Chat supports phone image picking and text-based file attachments. Gemini may accept PDF inline data; OpenAI chat endpoint here is used for text and images, not PDF attachments.
5. Tap the animated microphone. Grant microphone permission; Android speech recognition service must be available and configured for Bengali. AI replies are read with Android Text-to-Speech. Install Bengali TTS voice data on the phone if necessary.
6. Settings > Voice Tools controls spoken replies and speed. The Live Voice API section documents the separate backend/ephemeral-token work still required for a true continuous, bidirectional live session.
7. Existing branding, theme, wallpaper, image library, AI provider settings and floating bubble integration are retained.

No APK has been built or device-tested in this environment. Use the project source and verify build/runtime behavior on the target device before distributing.

Live Voice: Android Studio-তে build করে Settings > AI মডেল ও সংযোগ > Voice Tools-এ Gemini Live API key save করুন, Test Connection করুন, তারপর Live Voice চালু করুন। Client-side key ঝুঁকি সম্পর্কে CHANGELOG_BN.txt দেখুন।


v12: Repeated identical text prompts are cached for 10 minutes (up to 20 prompts) to reduce duplicate API requests. Image/file requests are not cached.
