TAVARs — Sales, Profit, Search & Chat build

Login:
- Admin: faqat parol. Standart parol: parol
- User: faqat ism. Ism tahrir qilinmaguncha qurilmada saqlanadi.

Admin:
- Sotuv: mahsulotlarni + / - bilan bittalab savatchaga qo'shish.
- Har bir mahsulotning sotuv va kelish (tannarx) narxi bor.
- Foyda/zarar = sotuv summasi - kelish summasi.
- Har bir tasdiqlangan savdo uchun chek yaratiladi va chek tarixi yig'ilib boradi.
- Ombor, moliya, statistika, qarz, buy-list, remont va SMS/chat.

User:
- Bor mahsulotlar — alohida sahifa + search.
- Yaqinda — alohida sahifa + search.
- Admin funksiyalari User panelida ko'rinmaydi.

SMS/Chat:
- User <-> Admin chat ko'rinishi.
- Matn, rasm, video yuborish.
- Mikrofon ruxsati berilsa ovozli xabar yozish.
- Media fayllar shu qurilmadagi IndexedDB'da saqlanadi.

Ma'lumotlar localStorage + IndexedDB'da shu qurilmada saqlanadi.
