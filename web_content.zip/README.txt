Pocket APK Studio v0.20.0 — ApkForge package

Upload this ZIP to ApkForge using its HTML/ZIP-to-APK import. index.html is at the archive root and the ZIP library is embedded in the HTML source.

Important: this package is the Pocket APK Studio HTML application, not a compiled APK and not an on-device Kotlin/Gradle compiler. Native Android projects still require an actual Android build toolchain. No GitHub workflow is required just to create the ApkForge-wrapped Pocket Studio UI APK.
