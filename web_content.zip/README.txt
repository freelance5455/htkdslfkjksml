Nishant Live - Mobile Build Project

यह एक mobile-friendly Owner/Admin Panel prototype है।

मोबाइल से APK बनाने के लिए:
1. index.html और manifest.json को किसी WebView/App Builder में import करें।
2. App name: Nishant Live
3. Start page: index.html
4. App icon के लिए अपना Owner profile/logo लगाएँ।
5. Generate APK करें।

ध्यान दें:
यह अभी UI/prototype है। Real login, live video/voice, chat, coins, payments और online admin controls के लिए backend/server और secure authentication जोड़ना जरूरी है।
