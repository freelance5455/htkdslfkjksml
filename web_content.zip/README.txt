APK OLUŞTURMA (bilgisayar gerekmez, telefondan da olur)
1) github.com'da ücretsiz hesap aç, yeni bir repo oluştur.
2) Bu zip'in içindeki TÜM dosyaları (www klasörü, .github klasörü dahil) repoya yükle.
3) Repoda Actions sekmesi > "Build APK" > Run workflow. ~5-10 dk sürer.
4) Bitince çalıştırmanın altındaki "world-conquest-apk" dosyasını indir, zip'ten çıkan app-debug.apk'yı telefona kur
   (Ayarlar'dan "bilinmeyen kaynaklardan yükleme" iznini ver).
Oyun tamamen çevrimdışı çalışır.

---- GELİŞTİRME / TEST ----
Yerelde çalıştırma: www/index.html dosyasını bir tarayıcıda aç (veya `npx serve www`). Tamamen çevrimdışı çalışır.
Dosyalar: www/index.html (d3/topojson/datamaps kütüphaneleri + harita verisi), www/app.js (oyun), www/app.css (arayüz), www/flags/ (SVG bayraklar).
Otomatik test: `pip install playwright && playwright install chromium && python3 tests/e2e_test.py`
(tests/geo.js ve tests/geo-test.js eski komşuluk testidir; lib/ klasörü projede olmadığı için çalıştırılamaz.)
[V4] Tek oyunculu: bayrak çarkı -> pusula ışını -> komşu savaşı; Game Over yok; testler: python3 tests/solo_test.py. Herkes yalnızca kara komşusuna saldırır, kara komşusu kalmazsa deniz aşırı (SEA=0.62 rad). Kayıt sürümü 4 (eski tek oyunculu kayıtlar uyumsuz).
[ESKİ] Tek oyunculuda: tur zarı / kalan savaş sınırı yoktur; keşif serbesttir; her 5 fetihte 1 geliştirme puanı kazanılır (app.js: UPG_EVERY).
