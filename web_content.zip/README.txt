NITROHEX web app prototype
Contains index.html, style.css, app.js, manifest.json, sw.js.
Important: this is a web dashboard, not a native Android performance engine. It cannot grant Android permissions itself, create a true system-wide floating panel, read CPU/GPU use, change FPS, clear other apps' RAM, or force-close apps. Settings shortcuts may be blocked by some ZIP-to-APK wrappers. Native Android code and explicit system permissions are required for those features.
