APSARA RENTAL DRESSES — FIRST WORKING VERSION

1. Open index.html in Chrome on a phone or computer.
2. The first launch creates 500 sample costume records in the browser.
3. Data is saved locally in that browser using localStorage.
4. Use Inventory to search/filter costumes.
5. Use Bookings to create a booking. Overlapping bookings for the same costume are blocked.
6. Use Mark collected when the customer takes the costume.
7. Use Returns -> Process return to record late/damage fees and return the costume to Available.
8. Customers shows booking history aggregated by phone.

IMPORTANT:
This is a prototype. Data is stored only on the device/browser and is not yet synced between staff phones.
For production, the next step should be a shared cloud database, user login, photo uploads, QR scanning, backups, and WhatsApp reminders.
