ASTRA Project — Web prototype v0.1

INSTRUÇÕES
1. Envie ASTRA_Web_To_APK.zip para o APK Maker.
2. O ZIP já contém index.html na raiz.
3. Configure o nome como ASTRA Project e gere o APK.
4. Teste o APK gerado antes de distribuir.

Este protótipo é uma interface web empacotável. Não executa jailbreak, root ou exploits.
