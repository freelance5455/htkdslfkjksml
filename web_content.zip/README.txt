ALL IN ONE SHOPPING STORE - Starter App

Files:
- index.html: app interface and local record storage
- manifest.webmanifest and service-worker.js: PWA install support when hosted on HTTPS

Important limitations:
1. This is a starter web app, not an APK. Host these files on an HTTPS website (for example, a private hosting account) to install via Chrome > menu > Add to Home screen / Install app.
2. Records currently stay in this browser/device only. Online cloud sync, account-based login, encrypted server backup, and multi-device restore are NOT implemented yet.
3. Keep regular JSON backups using the app's backup button. Do not clear browser storage.
4. Do not collect full Aadhaar numbers for ordinary UPI cash transactions. Customer face/payment image collection should be consent-based and limited to what is necessary.
5. PDF share uses the phone's share sheet when supported. PDF generation library is loaded from the internet.
