Automatic Duty Attendance - starter web app

How to use:
1. Open index.html from a secure HTTPS host in Android Chrome (geolocation generally requires HTTPS or localhost).
2. Stand at the workplace and tap "বর্তমান GPS-কে অফিস হিসেবে সেট করুন".
3. Choose geofence radius and shift label, then save.
4. Keep the page open and tap "GPS মনিটরিং চালু". Allow location permission.
5. Download CSV for Excel or use PDF/Print.

Important limitation:
This is a foreground browser prototype. Browsers do not guarantee continuous geofence monitoring when the page is closed, suspended, or the phone restarts. For reliable background attendance, build and install a native Android app with geofencing/background location permissions, persistent storage, and battery-optimization guidance. User consent and employer policy should be followed.
