IFD-ROHINGYA SALAH TRACKER
Prepared for IFD-Rohingya School
Attribution: MV Anwar Hussain

Files:
- index.html: the offline student salah tracker
- icon.svg: app icon artwork

To build an Android APK using your Android phone:
1. Open https://www.htmltoapk.com/ in Chrome.
2. Choose the HTML/ZIP upload option and upload this ZIP file.
3. Set the app name to: IFD-ROHINGYA SALAH TRACKER
4. Set package name to: org.ifdrohingya.salahtracker
5. Upload icon.svg if the builder accepts SVG; otherwise use a PNG icon.
6. Build and download the signed APK.
7. Open the downloaded APK and allow installation from this source if Android asks.

Important:
- Choose the HTML/ZIP bundled option, NOT the website URL option, so the app can work offline.
- Test the APK with sample records before entering real student data.
- The app stores data on this device. Export/download a backup regularly.
- Do not clear the app's storage/data unless you have a backup.
- This ZIP is the app project, not the APK itself. The APK is produced by the separate builder.
