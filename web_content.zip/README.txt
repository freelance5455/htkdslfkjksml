Nafs Control APK Project
=========================
1. Extract this ZIP.
2. The main file is index.html.
3. Upload the ZIP to an HTML-to-APK builder.
4. Set app name: Nafs Control
5. Build/download the APK.

The app is a simple offline HTML app. Progress is saved locally on the device.
