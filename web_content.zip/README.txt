NIGHTMARE FF membership demo app source
App name: NIGHTMARE FF
Package name: com.nightmare.ff
App icon: app-icon.png
Logo: assets/nightmare-logo.png
Payment QR: assets/payment-qr.jpg

Demo login:
Username: nightmare
Password: 1206

This is a front-end demo for legitimate gaming community/training memberships. The local demo password is visible in index.html and is not secure authentication. Confirm recipient and amount in your UPI app before paying.
