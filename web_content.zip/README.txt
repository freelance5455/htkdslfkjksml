Android 1.6 — Lost Media Edition
=================================
This is an original reconstruction/demo, not the official Android 1.6 ROM and not the original Buka/Subway Surfers games.

Open index.html in a modern browser. It simulates a complete old-phone style interface with apps and two original mini-game reconstructions.
