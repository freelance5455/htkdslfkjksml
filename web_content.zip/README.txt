Bismillah Telecom - HTML to APK package

1. Open your HTML to APK converter app.
2. Choose ZIP File to APK.
3. Select this ZIP file.
4. Set app name: বিসমিল্লাহ টেলিকম
5. Set package ID if requested: com.bismillah.telecom
6. Enable Internet permission if the converter offers this option (the OCR library loads from CDN).
7. Build/Convert APK.

Important:
- Keep index.html at the ZIP root; do not select the extracted parent folder.
- Camera permission may be requested by the converter, but WebView camera support depends on the converter app.
- This package uses the current HTML OCR implementation. The previous Code=0 OCR issue may persist in a converter-generated WebView APK; native Android changes may be needed to fix it fully.
