MINI PS2 WEB

Abra index.html em um navegador Android.

Para converter em APK:
1. Compacte esta pasta como ZIP.
2. Use um conversor HTML -> APK.
3. O arquivo principal deve continuar sendo index.html.

Recursos desta versão:
- Tela horizontal/fullscreen quando o navegador/conversor permitir
- D-pad
- Analógicos L3/R3 com movimento
- R3/L3 por toque no analógico
- L1/L2/R1/R2
- △ ○ × □
- SELECT/START
- Contador de FPS e limite configurável
- Editor de controles
- Arrastar controles
- Opacidade/tamanho/textura
- Salvar layouts por nome no armazenamento local
- Mini jogo de teste para verificar os controles

Observação: isto é a camada Web/GUI. Executar jogos PS2 reais requer um núcleo de emulação nativo/WebAssembly apropriado; esta etapa não inclui BIOS/ROMs/ISO.
