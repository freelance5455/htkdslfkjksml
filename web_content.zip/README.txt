CUSTOM TOP TRUMPS — PHONE VERSION

This is the installable PWA version.
Features:
- 200-card limit
- Custom photos
- Custom stats
- CPU gameplay
- Local save
- JSON backup/restore
- Offline cache after first load

To install:
1. Put these files on any HTTPS web host.
2. Open the site in Chrome on Android.
3. Chrome menu -> Add to Home screen / Install app.

A normal local file (file://) cannot fully install a PWA; it needs HTTPS hosting.
