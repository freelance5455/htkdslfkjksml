TRAFFIC MASTER v1.1
===================

Premium cartoon 2D traffic game.

FEATURES
- Four numbered roads
- Independent RED/GREEN controls for every road
- Only one green road at a time
- Animated vehicles
- City and road graphics
- Score, coins and levels
- Automatic local high score saving
- Mobile touchscreen interface
- Offline gameplay

ROAD NUMBERS
1 = Top
2 = Right
3 = Bottom
4 = Left

CONTROLS
GREEN allows a road to move.
RED stops traffic on that road.
Turning one road GREEN makes the other roads RED.

PLAY
Open index.html in Chrome or serve the folder locally:
python -m http.server 8080

Created with Termux.
