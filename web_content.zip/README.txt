MEIN STERNENBEGLEITER – WEB-APP FÜR APK-UMWANDLER

Inhalt:
- index.html: die App
- manifest.webmanifest: PWA-Informationen
- sw.js: Offline-Cache
- icon.svg: App-Symbol

APK-Erstellung im Browser:
1. ZIP entpacken, falls dein APK-Dienst einzelne Webdateien verlangt.
2. Bei einem Web-to-APK-Dienst die index.html bzw. den gehosteten App-Link als Startseite eintragen. Manche Dienste akzeptieren einen ZIP-Upload; andere verlangen eine öffentlich erreichbare HTTPS-Adresse.
3. App-Name: Mein Sternenbegleiter
4. App-Symbol: icon.svg (falls SVG nicht unterstützt wird, PNG daraus exportieren).
5. Paket-ID z. B. de.mandy.sternenbegleiter (falls der Dienst danach fragt).

WICHTIG ZU ERINNERUNGEN:
Die Browser-App kann Erinnerungen auslösen, solange sie geöffnet und aktiv ist. Browser und Android garantieren keine pünktlichen JavaScript-Zeitgeber, wenn die App geschlossen oder vom System beendet wurde. Der Service Worker sorgt für Offline-Dateien, aber NICHT für verlässliche tägliche Alarmplanung. Für garantiert zuverlässige Erinnerungen auch bei geschlossener App muss der APK-Wrapper native Alarm-Benachrichtigungen unterstützen oder die App nativ implementiert werden.

Datenschutz:
Medikamentennamen und Tagesstatus werden nur lokal in localStorage dieses Browsers gespeichert. Kein Konto, kein Server, keine Synchronisierung.
