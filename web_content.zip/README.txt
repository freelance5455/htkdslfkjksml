Snake Battle prototype
Open index.html in a browser. It is a private playable prototype with infinite-style procedural levels, enemy snakes, score and coins.
Ads/earning are intentionally not active yet; the app can later be wrapped into an Android app and connected to an ad network if desired.
