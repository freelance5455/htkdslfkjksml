DONE — To-do web app
====================

Contents
- index.html: complete standalone app (HTML, CSS and JavaScript)

Run it
1. Extract the ZIP.
2. Open index.html in a modern browser.
3. Add tasks, complete them, filter them, and delete them.

Features
- Responsive mobile-first layout
- Add, complete, delete and filter tasks
- Task counters
- Clear completed tasks
- Local storage persistence (data stays in this browser/device)
- No framework, server, account, or external dependencies

For ZIP-to-APK conversion
- Upload the ZIP to a converter that accepts a website ZIP, or extract it and upload index.html plus assets if required.
- Set the app's start page to index.html.
- Choose an Android WebView wrapper and generate the APK.
- Test the APK on your own device before distributing it.

This is a web app packaged in an Android APK/WebView, not a native Kotlin rewrite.
