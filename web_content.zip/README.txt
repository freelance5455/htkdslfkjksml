ACCOUNT SIGN-IN DEMO
====================

Files
- index.html: local-only sign-in form demo
- dashboard.html: shows demo submissions saved by this browser

How to use
1. Extract the ZIP.
2. Open index.html in a modern browser.
3. Enter a made-up test email/username and any non-empty test password.
4. Click Continue.
5. Open Demo dashboard to see the test email/username and timestamp.

Important safety and technical notes
- This is not Google and is not affiliated with Google.
- Do not enter real account credentials.
- Passwords are never stored, logged, or transmitted.
- Demo entries are stored only in this browser's localStorage.
- Entries do not automatically sync between devices or browsers.
- Clearing browser site data may erase the entries.
- This is a front-end demonstration, not real authentication.
