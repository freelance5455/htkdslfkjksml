Highway Car Racing

1. Extract this ZIP.
2. Open index.html in a browser to play.
3. On Android Chrome, if hosted online, use "Add to Home screen" / "Install app" for an app-like experience.

This package is a web app/PWA, not a compiled APK.
