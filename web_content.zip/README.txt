SYASYA KIDSWEAR POS - APKForge bundle

Isi:
- index.html: aplikasi kasir
- assets/logo.jpg: logo toko

Cara:
1. Buka https://apkforge.site/
2. Pilih HTML/ZIP project upload.
3. Upload syasya_kidswear_apkforge.zip.
4. App name: SYASYA KIDSWEAR
5. Package name: id.syasya.kidswear
6. Version: 1.0.0
7. Upload assets/logo.jpg sebagai app icon jika APKForge meminta icon terpisah.
8. Build APK, lalu unduh hasilnya dan instal di Android.

Catatan:
Data transaksi tersimpan di localStorage perangkat. Tidak ada sinkronisasi cloud atau backend.
Pembayaran non-tunai dicatat sebagai metode, tidak memproses uang otomatis.
