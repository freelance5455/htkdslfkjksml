SKILL4GROW HTML-TO-APK BUILDER

1. Import this ZIP into the HTML-to-APK builder.
2. This is a launcher for https://skill4grow.vercel.app/ and requires internet.
3. The launcher intentionally does NOT auto-refresh or auto-redirect in preview. Tap Open Skill4Grow.
4. IMPORTANT: Deploy Skill4Grow-Website-Deploy-Root.zip to Vercel first, with the project root set to the folder containing index.html and api/course.js.
5. In Vercel Environment Variables, set AROLINKS_API_TOKEN to your current/rotated Arolinks API token and redeploy.
6. Then test the builder preview. The launcher should open the actual website, not itself.
7. Whether final Google Drive opens in Drive app or Chrome depends on the builder's WebView/external-link settings.
