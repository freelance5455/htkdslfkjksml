A1 Classes App Demo
Open admin.html for the Admin UI and student.html for the Student UI.
This is a visual/functional front-end demo. A real two-app system needs a shared online database/backend for login, marks, attendance, photos and notices to sync across devices.
