AL SOP App
Password: MDVWELD
CARGO: 6 sections
G91: 14 sections
Replace placeholder PDFs in the pdf folder with actual SOP PDFs using the same filenames.