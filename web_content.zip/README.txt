BizCashFlow APK Builder package. index.html is a classic non-module script bundle designed for ZIP-to-APK builders that block ES modules.
