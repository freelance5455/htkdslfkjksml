NEOXRA • UMANG UI — API/APK READY PACKAGE

1. Web:
   Upload this folder to Netlify.
2. Netlify environment variables:
   GEMINI_API_KEY = create a NEW Gemini API key; do not reuse a key previously exposed in chat.
   GEMINI_TEXT_MODEL = gemini-2.5-flash
   GEMINI_IMAGE_MODEL = an image-capable Gemini model enabled for your account
   GEMINI_VIDEO_MODEL = veo-3.1-fast-generate-preview
3. Deploy/redeploy after setting variables.
4. index.html calls /.netlify/functions/ai, so the Gemini key stays server-side.
5. To make APK, wrap index.html as a WebView/PWA with your preferred Android builder.

Important:
- The old API key that was previously pasted in chat is intentionally NOT included.
- Firebase credentials/Realtime Database URL were not present in the current OPBRO.html source, so they are not invented here.
- Real Firebase auth/storage/chat need your RTDB URL and rules to be connected before claiming those parts are production-ready.
- Video generation is asynchronous; the backend returns the operation/job name rather than pretending a finished MP4 exists.
