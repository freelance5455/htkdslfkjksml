Market Utiliti — HTML/WebView demo package

Внутри архива index.html — главная страница мобильного демо.
Это не нативный Android-проект и не готовый APK.
Реальные Telegram login, market data, AutoBuy и Transfer не подключены.

Для упаковки используйте HTML-to-APK сервис, который принимает ZIP с index.html.
Перед установкой APK проверьте разрешения и подпись приложения.
