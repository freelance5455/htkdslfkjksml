Bright Purple & Blue MOD Menu - Test 1

使い方:
1. ZIPファイルを解凍します。
2. index.html をブラウザで開きます。
3. 右側の丸いMODボタンでメニューを開閉します。
4. MENU / SHOP / SETTINGS を切り替えて試せます。

注意:
これはブラウザ内で動くデモです。Robloxには接続せず、
実際のRobux残高やゲーム内のSpeed / Jump Powerは変更しません。
