APK / হোম-স্ক্রিন আইকন বানানোর ধাপ
1) এই ফোল্ডারটি যেকোনো ফ্রি হোস্টিংয়ে আপলোড করুন (Netlify Drop: app.netlify.com/drop, অথবা GitHub Pages, Cloudflare Pages)।
2) ফোনের Chrome-এ লিংক খুলুন, মেনু থেকে "Add to Home screen / Install app" চাপুন। আইকন হোম স্ক্রিনে চলে আসবে।
3) APK চাইলে pwabuilder.com এ লিংকটি দিন, Android প্যাকেজ ডাউনলোড করুন (APK ও AAB দুটোই পাবেন)।
