# Licence Demo App

This is an offline, browser-based prototype built from the supplied screen designs.

PIN: 000000

Interaction:
- Enter the six-digit PIN.
- The licence-style demo screen opens.
- Tap the main screen 25 times to unlock demo edit mode.
- Edit the displayed demo fields.
- Upload a photo and signature.
- Changes are shown in the current session.

Important:
This prototype intentionally identifies itself as "DEMO • NOT AN OFFICIAL LICENCE" and is not intended to function as, imitate for use as, or replace an official identity/driver-licence credential.

To turn this into an Android APK, open the folder in Android Studio and package the web assets inside a WebView/Capacitor project. The current environment does not include the Android SDK/Gradle toolchain, so this delivery is the complete offline prototype/source rather than a compiled APK.
