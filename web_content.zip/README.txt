FAKE CALL SIMULATOR — BUILDER COMPATIBILITY VERSION

This is a browser/WebView simulation only. It does not place real calls and does not use the phone dialer, microphone, camera, contacts, or call permissions.

IMPORTANT:
The package intentionally contains the website at BOTH the ZIP root and /web/.
This is to support APK builders that load:
https://appassets.androidplatform.net/web/index.html

If the builder accepts a ZIP website project, upload this ZIP as-is.
