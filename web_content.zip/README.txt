ELECTRICAL ENGLISH TRAINER — ANDROID PWA

IMPORTANT:
A PWA can be installed on Android from a secure HTTPS website. This ZIP is the app source package, not an APK.
To test it on your Android phone:
1. Upload/extract this folder to a static host that serves HTTPS (for example GitHub Pages, Netlify, or another static website host).
2. Open the hosted index.html URL in Chrome on Android.
3. Tap Chrome's three-dot menu and choose "Install app" or "Add to Home screen".
4. Open the installed app. It caches the files for offline use after the first successful load.

Features:
- Multiple-choice quiz: English to Portuguese, Portuguese to English, English definitions
- Topics, 10/20/all questions
- Flashcards
- Searchable vocabulary list
- Best score stored locally on device
- Service worker offline cache

No external JavaScript libraries or network APIs are used.
