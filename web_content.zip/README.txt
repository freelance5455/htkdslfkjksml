DAFAALLAH Wi-Fi Transfer v0.3

This package is an improved HTML-first front end ready for an HTML-to-APK builder.

Added:
- Modern responsive interface and dashboard
- Send / Receive navigation
- Multi-file selection, drag & drop, remove individual files
- Local file saving/download from the browser layer
- Transfer history with search, 100-entry limit, delete confirmation
- Local/private status and clearer native-layer boundary
- Three themes and Arabic/English interface
- Storage preference, history preferences
- Selected-file count and total size
- Toast feedback and improved mobile controls
- Original DAFAALLAH logo retained

Important:
A pure HTML file cannot by itself open a TCP/WebSocket server on Android or discover another phone on the LAN. The UI therefore prepares the app for a real native LAN layer. For true phone-to-phone transfer, the APK wrapper needs Android-side networking (for example a local HTTP/WebSocket server, Wi-Fi Direct, or a compatible bridge). This avoids pretending that a browser button is already transferring files when it is not.

Suggested next native features:
1. Start/stop local server and show IP + port.
2. QR code / short pairing code.
3. Device discovery on the same Wi-Fi.
4. WebSocket/HTTP file transfer with progress and cancel.
5. Android Storage Access Framework folder picker.
6. Notifications and background receiving.
7. Transfer resume/checksum for large files.
