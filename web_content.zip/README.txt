PATER MÓVIL — PROTOTIPO ACTUALIZADO
Incluye la lista de 11 espacios, matrículas confirmadas en las capturas y categorías de taller.

Matrículas:
- Ford Explorer: 785053
- Mitsubishi Montero: 888491
- Suzuki Vitara: 644003
- Toyota 4Runner gris: BNR746
- Toyota 4Runner “Pater”: PTR609
- Toyota 4Runner “Roncona”: BXM307
- Hyundai Galloper: 357114
- Kia Bongo “Pater Truck”: CL335121
- Autobús Blue Bird: pendiente de matrícula
- Espacios 10 y 11 para vehículos futuros.

Categorías de taller: Frenos, cambio de aceite de motor, filtro de aceite, filtro de aire, filtro de combustible, aceite de caja, filtro de aceite de caja, clutch/embrague, sistema de combustible, suspensión, llantas, rotación de llantas, alineamiento, A/C, dirección, transmisión, batería, escape, escaneo, motor, luces, escobillas, filtro de aire, filtro de cabina, eléctrico, transfer 4x4, diferencial, pintura, chasis, carrocería, vidrios y otro.

LIMITACIONES IMPORTANTES:
- Guarda datos únicamente en el navegador/dispositivo. No hay sincronización entre teléfonos, autenticación ni copia de seguridad compartida.
- No es un APK ni una app nativa. Para instalar como PWA, súbelo a un alojamiento HTTPS.
- Antes de usar con datos reales hacen falta pruebas, privacidad, sincronización y copias de seguridad.
- El kilometraje, VIN, fotos y matrículas que no aparecen en las capturas se pueden completar desde la interfaz.
