# Mod AI Studio — V1
Protótipo inicial para criação assistida de addons Minecraft Bedrock.

Abra `index.html` no navegador do celular ou computador.
Esta versão demonstra a interface e a criação da especificação inicial do projeto.
A geração real por IA, modelos 3D/Blockbench e exportação .mcaddon serão implementados nas próximas versões.
