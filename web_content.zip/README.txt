BUSINESSFLOW MOBILE — PWA PACKAGE

This package converts the supplied BusinessFlow Sentinel portal into an installable Progressive Web App. It includes the existing portal HTML plus a web app manifest, app icons, install prompt handling, and a service worker for caching the app shell.

DEPLOY
1. Extract the ZIP.
2. Upload the CONTENTS of this folder to the root of the existing Netlify site (keep index.html, manifest.webmanifest, service-worker.js, and icons/ together).
3. Open the HTTPS site in Chrome on Android. Use the browser menu > Install app / Add to Home screen, or use the Install app button when Chrome offers it.

IMPORTANT
- This is an installable web app, not yet a Play Store APK/AAB.
- The PWA shell can open offline after it has been cached, but live sign-in, database, security checks, and remote services still require internet.
- This does not add continuous threat monitoring or change the existing Sentinel backend. Existing portal/backend capabilities and limitations remain unchanged.
- Before public release, review all existing portal content, payment configuration, privacy/legal pages, and production security settings.
