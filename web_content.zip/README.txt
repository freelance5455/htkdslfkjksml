Bani Al-Hammadi Lab Pro (starter)
Open index.html using Chrome or Edge.
Features: patient data, test selection, patient search/report, invoice builder, invoice print-to-PDF, editable lab details and test catalog, JSON backup/import.
PDF instructions: In Invoice tab, choose patient / enter invoice items, click Export / Save PDF, then choose Save as PDF in browser print dialog.
Data is stored in local browser storage on this device. This is a demo/starter and not an approved clinical system. Do not store actual patient records before professional privacy/security validation and encrypted storage is implemented. Medical results must be checked by authorized lab personnel.
