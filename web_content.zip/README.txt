YUKIO HUB V2
Minigames agora possuem objetivos e condições de vitória.
- Xadrez: capture 4 peças.
- Ski: sobreviva 20 passos.
- Boxe: faça 5 pontos.
- Pesca: pesque 3 peixes.
- Vôlei: mantenha a bola por 10 segundos com pelo menos 6 toques.
- Pou Fish: pegue 8 comidas.
As moedas só são dadas após vitória.
