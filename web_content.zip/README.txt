JUVENIL - pacote compatível
Esta versão é de arquivo único: o logo está embutido no index.html para evitar erro de carregamento de assets no Android WebView.
Envie este ZIP ao mesmo conversor HTML -> APK.
