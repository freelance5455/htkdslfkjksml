PC Savings Tracker
==================
Files:
- index.html: complete app. Open in a browser or Acode preview.

Acode on Android:
1. Extract this ZIP into a folder.
2. Open Acode and choose Open Folder, then select the extracted folder.
3. Open index.html and use Preview.
4. In Chrome, open the app page and choose menu > Add to Home screen (or Install app) to get an icon.

Features:
- Set savings goal (default ₹40,000)
- Add daily savings and notes
- Quick-add ₹50 / ₹100
- Progress and remaining amount
- Saved-days count and streak
- History
- Export JSON backup
- Local storage persistence on that browser/device

Important: local browser storage is device/browser-specific. Export backups periodically.
