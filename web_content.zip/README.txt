TAP JUMP — Free mobile game starter

PLAY:
1. Open index.html in a modern browser.
2. Tap the game screen to jump.
3. Avoid orange spikes. Tap after Game Over to restart.
4. Best score is saved in the browser.

ANDROID APK:
This folder is a playable web game, not a compiled APK. To package it as an APK, use a web-to-app wrapper or Android build service. Some services charge for APK export; check pricing before using one. You can also use Android Studio with a WebView if you have access to a computer. This project itself is free.
