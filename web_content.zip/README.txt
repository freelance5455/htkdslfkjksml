PATHWAYLEX INVESTMENT - WEB ZIP FOR ZIP-TO-APK APPS

This ZIP is deliberately structured as a website package with index.html at the
ROOT, because the ZIP-to-APK application shown in the user's screenshot expects
index.html.

HOW TO USE:
1. Download PathwayLexInvestment_WebZIP.zip.
2. In the ZIP-to-APK app, choose this ZIP.
3. The app should now detect index.html.
4. Preview/test the app.
5. If the converter supports APK export, generate the APK.

IMPORTANT:
This is a DEMO web app. All balances, earnings, deposits and withdrawals are
simulated. It is not connected to M-Pesa and must not be used to accept real
customer funds or advertise guaranteed returns.
For Google Play production, a proper signed Android App Bundle (AAB), secure
backend, authorized payment integration, regulated financial/investment partner,
KYC/AML, privacy/data-protection compliance and Play Console requirements are
still required.
