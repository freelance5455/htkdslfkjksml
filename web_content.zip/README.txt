GST Calculator updated HTML

Open GST_Calculator_Updated.html in a modern browser or your HTML-to-APK WebView.
Cash in Hand result rows are hidden (calculations remain intact). Non-Filer Required Billing Amount spans the full row.
PDF/Print actions use the app browser/WebView capabilities; printing may require Android print service support.
