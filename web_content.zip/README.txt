FitTrack v4

History now opens as a complete workout session:
- date + workout/day name at the top
- every exercise from that saved session
- every set with weight and reps
- exercise notes
- old sessions remain available by date
- template changes do not rewrite old sessions

index.html is at the ZIP root for HTML-to-APK converters.
