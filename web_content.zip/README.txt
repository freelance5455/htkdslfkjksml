Contractor Pro V16.0.1 — AI Copilot & Smart Capture (stabilized)
APK-ready single-file build. Root index.html is required by HTML-to-APK converters.
No external AI SDK, API key or network request is embedded. Offline operation is preserved.
Local data key is unchanged (contractor_pro_global_v14): existing data loads as before.

Fixes in 16.0.1
- Dashboard: raw template text (${esc(t(...))}) was shown in "Connected" and "Attention" cards and
  caused ~20px horizontal overflow on phones -> fixed (proper translated labels, no overflow).
- Notifications: duplicates were created on every dashboard render -> fixed; old duplicates are cleaned
  automatically on first launch (your own reminders are kept).
- Overdue logic: cancelled invoices and invoices due today no longer counted as overdue; tasks due today
  are no longer "overdue". Same rule on dashboard, reports, alerts and assistant.
- Low-stock alerts now use the aggregated stock of an item (not single in/out records) and close
  automatically after restocking.
- Income/expense totals unified everywhere (income = income+payment+advance; expense = expense+debt+refund).
- Quick Capture / Smart Assistant: "take 5 bags cement" was recorded as stock IN -> now OUT;
  "Add 8 hours for Ali" created a worker named "add" -> fixed; Persian digits supported;
  same worker is reused (hours accumulate + time entry created) instead of duplicating workers;
  Persian/English item names (سیمان/cement, سرامیک/tile) map to the same stock item;
  assistant answers/alerts are in Persian when the app language is Persian; "Smart mode OFF" is respected.
- Translations: 17 corrupted strings (mixed Russian/Turkish/German/French), swapped FR/DE "Paid",
  German text in Arabic, "Copier" in German -> fixed. Notification type labels added.
- CSV export now opens correctly in Excel with Persian text (UTF-8 BOM).
- Version strings made consistent (title, APP_VERSION, package.json).
