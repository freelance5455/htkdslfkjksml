Gamerox — PLAYER APP
=====================
index.html zip ke root mein hai, isliye kisi bhi "website to APK" builder / hosting par seedha chalti hai.

NAYA: Forgot password mein OTP — 6 digit ka code user ki Gmail par aata hai, wahi daal kar naya password banta hai.
Is ke liye Supabase mein ek baar email setup karna hai: PASSWORD-RESET-SETUP.txt padho (5 minute).

Is mein: opening animation, DG logo, games, login / signup (direct), Events, Notifications (🔔), Customer Support,
Rules, About, Profile (picture, banner, User ID) aur Ludo (real online multiplayer).

LUDO
- Wahi app account Ludo mein chalta hai. Coins profile par nazar nahi aate (Profile -> My Ludo wallet).
- Lobby -> RANK MATCH (entry 10, jeetne par 20 coins + rank points) ya CLASSIC MATCH (free, jeetne par 10 coins).
- Event match: har event ki apni entry / prize / mode / theme (server se). Halloween theme 31 October tak.
- Lobby mein: Shop, Leaderboard, My rank, Records.

APK: yeh zip seedha "website to APK" builder mein upload karo (App name: Gamerox, icon: icons/icon-512.png,
Internet permission ON, JavaScript + DOM storage ON). Ya PWABuilder / Capacitor.

NAYA LOOK (v4)
- Har page ka apna rang (Home orange, Games violet, Events gold, Download cyan, Profile/Rules/About green, Support red).
- Rang server se badalte hain: Supabase site_settings -> key "app_theme" -> pages.<page>.{a,b,bg,on}. Zip dobara banane ki zaroorat nahi.
- Header mein coins chip, page ka naam, floating bottom nav, naya Home (Play Now / Featured / Quick Access).
- Accounts, coins aur rank Supabase mein hain — update se koi data nahi jata. Purani APK ke upar hi install karo (same package name).

GAMEROX (v5)
- Naam: Gamerox. Naya logo (G + play triangle), naye icons aur naya opening animation (koi video file nahi).
- Forgot password hata diya gaya hai.
- Google chalane ke liye Supabase mein Google provider ON karna zaroori hai (Authentication > Sign In / Providers > Google).
- Purane email/password wale users pehle ki tarah login kar sakte hain. Data Supabase mein hai, kuch nahi jata.

APP UPDATE (v5.1)
- Admin panel ke "App update" tab se naya APK upload hota hai. Players ko app mein "Update available" popup aata hai, aur "Update now" dabane se APK download hota hai.
- Is build ka version number 2 hai (index.html mein APP_VERSION_CODE). Agla APK 3, phir 4... aur APK builder mein bhi wahi version code rakho.
- Naya APK usi package name aur usi signing key se banna chahiye, warna Android purani app ke upar install nahi hone dega.

ADMIN PANEL APP KE ANDAR (v5.2)
- Admin account se login karo -> Profile -> "Admin panel". Sirf admin ko dikhta hai.
- Wahi admin panel khulta hai (games, events, shop, users, support, content, App update). "Back to app" se wapas.
- Game add karte waqt photo ka link aur play ka link paste kar sakte ho (file picker ki zaroorat nahi).
