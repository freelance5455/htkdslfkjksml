DLSS 5 Swapper - Web APK version
================================
This is a self-contained HTML/CSS/JavaScript app intended for Web-to-APK builders.

How to build:
1. Upload this ZIP to a Web/HTML-to-APK builder.
2. Set the entry file to index.html if requested.
3. App name: DLSS 5 Swapper
4. Package ID suggestion: com.example.dlss5swapper
5. Build APK and install it on Android.

Important:
- This is a graphics/profile manager UI prototype.
- It does NOT contain NVIDIA proprietary DLSS runtime.
- It does NOT inject DLSS into games or bypass Android game security.
- Folder selection is subject to Android WebView/browser storage restrictions.
