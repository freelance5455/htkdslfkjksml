Pocket APK Studio v0.10.0

ApkForge-compatible HTML package. index.html is at the archive root. JSZip is embedded in index.html, so the ZIP engine does not require a separate asset file or CDN.

New in v0.10.0: offline Build Doctor for pasted Android/Gradle/GitHub Actions error logs. It classifies common SDK/JDK/Gradle/plugin/manifest/resource/Kotlin/dependency/network/duplicate-class/memory/variant/wrapper failures, shows suggested next steps, and can export a report with redacted excerpts. The raw pasted log is not included in the export.

To update: upload this ZIP to ApkForge, build a new APK, and install that new APK. Reopening an older installed version will not apply the update.

Important limitations: Pocket APK Studio does not compile APKs inside this HTML app. Generated Android source and GitHub Actions workflow are not the same as a built APK. You must review source/build scripts before remote builds, run the workflow in your own repository, and install/test the resulting APK.
