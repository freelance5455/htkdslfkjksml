IRON / JOURNAL+ — V3
====================

What's new
- Readiness check-in: readiness, sleep, soreness, shin symptom rating and context.
- Hockey/conditioning activity log: activity, duration, effort, date and notes.
- Exercise-specific progression hints based on the latest completed exposure.
- AES-GCM encrypted backup export and encrypted restore (Web Crypto, PBKDF2-SHA256).
- Improved PWA metadata and offline shell cache.

Install/use
1. Extract the ZIP.
2. For quick use, open index.html in a modern browser. Browser storage and offline behavior differ.
3. For installable PWA and reliable service-worker support, host the folder on HTTPS.
4. On Android Chrome, open the HTTPS site menu and choose Install app / Add to Home screen.

Privacy and storage
- Workout and journal records are stored in localStorage in this browser profile.
- The app does not configure accounts, cloud sync, analytics or ad services.
- Ordinary app storage is NOT encrypted at rest. Encrypted backup protects the exported backup file only.
- Keep a backup. Browser cleanup, lost device, private browsing or profile changes may erase local records.
- Encrypted backup passphrase cannot be recovered. Store it separately and securely.
- Avoid using shared/untrusted devices. Backups may contain sensitive personal notes.

Programming / safety notes
- Progression hints are heuristics, not individualized coaching guarantees. They consider latest recorded set data and the programmed rep range. Override freely.
- Hypertrophy exposure counts remain approximate tagged-set counts, not scientifically calibrated effective sets.
- Estimated 1RM is only an estimate.
- Hockey scheduling and shin check-ins are logging tools, not medical assessments. Follow your clinician's return-to-training guidance. Do not interpret low symptom scores as clearance.

Limitations
- This is a local-first PWA-style app, not a signed Android APK.
- No automatic cloud backup, multi-device sync, push notifications or biometric app lock.
- Validate the app in your target browser before relying on it as your only training record.
