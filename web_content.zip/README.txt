# Proposal Maker — Phone Friendly Web MVP

Open `index.html` in a browser. It works without a backend.

Features:
- Names + custom message
- Romantic/Cute/Elegant themes
- Floating hearts
- YES success screen
- Playful "Maybe later" button

For an APK, upload the project to a web-to-APK/PWA packaging service or use an Android WebView wrapper.
