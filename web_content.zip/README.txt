Contractor Pro V11.0 Global Edition
APK-ready single-file build based directly on the verified V10.4 core.

Added: Account & Security foundation: individual/company account type, email profile, roles, local session state, OTP/cloud/backend connection points.
Offline use remains supported. Real email OTP, server authentication, cloud restore and server-side licensing are NOT simulated and require the production backend.

Packaging: root index.html is intentional for HTML-to-APK converters that require index.html at the package root. No external assets, manifest or external libraries are required.
