CLINIQUE VÉTÉRINAIRE — VERSION V18 CORRIGÉE (EXPORT PDF ANDROID)

- Le bilan s’affiche dans l’aperçu intégré à l’application : aucune fenêtre secondaire n’est nécessaire.
- Dans l’aperçu intégré, appuyez sur « Enregistrer / Imprimer le PDF ». L’application tente d’ouvrir la feuille de partage Android pour envoyer le PDF à NokoPrint ou l’enregistrer. Si le partage n’est pas disponible dans l’APK, des liens « Ouvrir le PDF » et « Télécharger le PDF » apparaissent.
- L’application web ne peut pas forcer silencieusement l’écriture dans le dossier Documents à cause des restrictions de sécurité Android. L’utilisateur choisit l’emplacement dans la boîte de dialogue système.
- Le code d’export évite les fenêtres secondaires, qui peuvent être bloquées ou dépourvues de commandes d’impression dans certains APK.
- Les modules et les données de la version V16 sont conservés dans les fichiers web. Faites une sauvegarde JSON depuis Gestion du cabinet avant de remplacer l’ancienne installation.
- Placez index.html à la racine du ZIP lors de la génération APK.


CORRECTIF IMPRESSION ANDROID V18.1
- Le lien « Ouvrir le PDF » est remplacé par un téléchargement explicite afin d’éviter les pages blanches des PDF dans certaines WebView Android.
- Ajout d’une commande « Imprimer cet aperçu » qui tente l’impression de la page HTML courante sans ouvrir de fenêtre secondaire.
- Si l’impression directe n’est pas prise en charge par le générateur APK, télécharger le PDF puis l’ouvrir depuis Téléchargements avec NokoPrint.

\nTEST CORRECTIF V18 - partage PDF relançable
- Le PDF préparé est conservé en mémoire pour permettre une nouvelle tentative de partage Android après un clic direct.
- Les boutons de secours sont « Partager le PDF avec Android », « Télécharger le PDF » et « Imprimer cet aperçu ».
- Important : si le générateur APK n’expose pas les API Android de partage/téléchargement/impression, le HTML seul ne peut pas forcer ces fonctions natives. Il faudra configurer les options du générateur APK ou utiliser un conteneur compatible.
