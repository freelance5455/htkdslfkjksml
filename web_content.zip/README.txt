FOOTVISION ULTRA
Start file: index.html

This is an original football prediction and analysis app.
Included:
- Large mobile-first Match Centre
- Home win / Draw / Away win probabilities
- Three possible match scenarios
- Separate lucky/low-probability scenario
- Team form
- Head-to-head history
- Expected lineups
- Team Centre
- League table
- Fixture text import for normal football fixtures
- Offline PWA/WebView structure

The included fixtures and statistics are demonstration data. For current fixtures,
lineups, injuries, standings and genuinely data-driven predictions, connect the app
to a licensed/reliable football-data API. Predictions are estimates, not guarantees.
This package is designed for football match analysis and outcome scenarios only.
