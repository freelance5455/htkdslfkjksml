K2 Signal Hub v2.6 — HTML to APK compatibility build

This archive intentionally contains BOTH:
- /index.html
- /web/index.html

This supports converters that load appassets.androidplatform.net/web/index.html as well as converters expecting index.html at ZIP root.
