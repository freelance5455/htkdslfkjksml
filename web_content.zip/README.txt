SK..mathematics Grade 7 — Formal App Package

Open launcher.html or index.html in Microsoft Edge.

This package is an offline-capable PWA-style app shell. It can be opened locally and, in supported browsers, installed as an app.

Included:
- SK..mathematics branding and icon
- Grade 7 learner identification
- Lessons
- Timed classwork
- Monthly tests
- Automatic corrections
- Learner progress
- Classroom shared-question demonstration
- Help/inbox
- Teacher dashboard
- Top 3 ranking
- Certificate generation
- Results export for future MPSAMS integration
- Offline cache/service worker

For a production school deployment, the next engineering phase is still required for:
- secure multi-user accounts
- real Excel learner import
- real tablet-to-tablet local network classroom server
- full CAPS content and vetted question bank
- actual lesson videos
- robust sync to MPSAMS
- detailed per-item error analysis
- printable PDF certificates
- backups and POPIA/security controls

Do not use the prototype as the official learner record until those production controls are implemented.
