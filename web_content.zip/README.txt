NEXORA 3D — Name Studio
========================

1) Extract the ZIP.
2) Open index.html in Chrome or MT Manager's HTML viewer.
3) Enter a name, choose effects/music and preview.
4) Tap Full Screen for presentation.

Offline:
- The editor and procedural visual effects work offline.
- Audio is generated in the browser; tap Play / Stop to start it.
- The share link is a design URL, not a hosted public page by itself.

Sharing with another phone:
- To make links open on other phones, upload index.html to a static web host.
- After hosting, use Create Share Link. The link contains the design settings.
- For private creator access, hosting must use a separate password-protected creator route.
- No automatic cloud upload is included in this offline starter ZIP.
