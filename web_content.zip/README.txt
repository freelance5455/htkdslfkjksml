UBAID OFFLINE BATTLE V2
========================

This is an original browser-based offline battle-royale prototype.

Included:
- airplane intro and parachute landing sequence
- one small original map
- hidden enemy positions on minimap; enemies are visible only nearby
- gunfire muzzle flashes and bullet tracers help reveal where shots came from
- 12 hunting/shooting bots
- mobile movement buttons, sprint, fire, jump, reload
- M416-style placeholder weapon and ammo/health HUD

Important:
- This is not the official PUBG Mobile game and does not contain PUBG's copyrighted map, models, or exact weapon assets.
- It is a 2D top-down prototype, not a full 3D game.
- Open index.html in a browser. For Android, extracting the ZIP and opening index.html in Chrome may work; if local-file scripts are restricted, use a simple static host or an HTML viewer.
