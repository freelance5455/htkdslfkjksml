FF Panel Pro HTML package

Main entry file: index.html
Open index.html in a browser, or import this ZIP into an HTML-to-APK builder that supports ZIP projects.

Note: AndroidBridge features (installed-app picker, launching apps, native Text-to-Speech) require a native Android WebView bridge implemented in the Android app. A basic HTML-to-APK wrapper may show the web UI but those native bridge features will not work until the bridge is added.
