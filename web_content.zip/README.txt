TRUK BOX SIMULATOR - KOTA JAMBI (aplikasi offline / PWA)

CARA PAKAI
1. Taruh semua isi folder ini di hosting HTTPS (GitHub Pages, Netlify, dll) atau jalankan server lokal:
   python3 -m http.server 8000   lalu buka http://localhost:8000
2. Buka SEKALI saat online. Service worker menyimpan game + three.js ke cache.
3. Setelah itu game jalan tanpa internet. Di Chrome/Edge/Android pilih "Instal aplikasi" / "Tambahkan ke layar utama".

OPSIONAL - 100% mandiri (tanpa perlu online sama sekali, mis. untuk dibungkus jadi APK/Capacitor atau dibuka dari file://)
Unduh 3 file ini ke folder lib/ dengan nama persis:
  curl -L -o lib/three.min.js https://cdn.jsdelivr.net/npm/three@0.128.0/build/three.min.js
  curl -L -o lib/GLTFLoader.js https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/loaders/GLTFLoader.js
  curl -L -o lib/BufferGeometryUtils.js https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/utils/BufferGeometryUtils.js
Game otomatis memakai file lokal bila ada, dan CDN bila tidak.
