THE HOLLOW HOUSE — RIFT-STYLE DICE FIGHTER
==========================================
Version 3.0.0 | Android / HTML source package

WHAT THIS VERSION IS
--------------------
This redesign changes the gameplay structure, not just the colors. It is now a real-time, top-down free-for-all brawler inspired by the movement, match flow, and mobile combat layout of your RIFT//RUMBLE project. The house is the arena. Dice replace the normal weapon/special loadout and determine each attack or ability.

There is NO shop, currency, upgrade grind, or weapon store.

MATCH RULES
-----------
- 2–5 players total. A match cannot start with only one participant.
- Play locally with AI opponents, or create/join a private online room.
- In online rooms, the host can add AI seats. Human players plus AI may never exceed five.
- The game chooses one random player to receive one random starting die. Everyone else searches the rooms for pickups.
- The house has a living room, kitchen, central hall, nursery, and basement, joined into one arena.
- Real-time movement, dashing, health, shields, knockouts, lives, respawns, and a match timer.
- A player rolls their selected die; it tumbles for a moment, then the landed symbol/number and its effect appear in the top-right roll panel. The match state broadcasts that result to all connected players.

DICE COLLECTION
---------------
- 120 regular dice, with numbered dice and themed symbol dice.
- 24 restricted Admin Dice.
- 144 unique dice total and 888 faces across the full catalogue.
- Effects include damage, burn, poison, blast, shields, healing, speed, freeze, knockback, teleport, swaps, traps, leech, critical hits, chain attacks, gravity, meteor, echo, and reveal.
- Regular dice are found as house pickups. Admin Dice never spawn naturally.
- Each player can carry up to five dice. Tap an inventory slot to select it.

ADMIN VAULT
-----------
Open ADMIN from the main menu and enter this access key:

    RIFTROOT

The key unlocks the Admin Vault on that device. During a match, use the ADMIN button or pause-menu Admin option to open the live Admin Dice Giver.

Admin features:
- Choose a target player or ALL PLAYERS.
- Give a chosen regular die directly to a player's inventory.
- Spawn a selected regular die as a floor pickup.
- Separate **ADMIN DICE · ADMIN ONLY** list with 24 special admin dice.
- Give or manifest an Admin Die.
- REMOVE CURRENT DICE: empties the selected target's inventory, clears all floor pickups, and locks automatic dice spawning.
- Clear floor pickups, manifest 30 dice, or unlock natural spawning again.
- Full heal, 30-second god mode, revive, and eliminate a target.

Admin authority is local/host-side. In an online match, only the room host can administer the match. The access key is a local developer gate, not secure anti-cheat; do not treat it as a protected account system.

CONTROLS
--------
PHONE / TABLET (LANDSCAPE)
- Left virtual stick: move.
- ROLL: roll the currently selected die.
- DASH: burst movement / evade.
- SWITCH DIE: cycle through carried dice.
- Tap a die slot in the inventory bar to select it.
- Pause: resume or leave the match; admins can open the Admin Menu there too.

KEYBOARD
- WASD or arrow keys: move.
- Space: roll selected die.
- Shift: dash.
- Q: switch die.
- Escape: open pause controls.

ONLINE PLAY
-----------
The game loads PeerJS 1.5.4 from the public unpkg CDN when you create or join a room. The host shares a room ID; guests join with that ID. Host-side simulation is broadcast to guests over WebRTC data connections.

Online play requires internet access, JavaScript, WebRTC/data-channel support, and access to the PeerJS signaling service. Peer-to-peer connections can fail on restrictive networks or NAT configurations; this package does not include its own TURN relay or dedicated matchmaking server. Local matches with AI work offline.

MAKE AN APK USING A PHONE-BASED HTML-TO-APK BUILDER
-------------------------------------------------
The ZIP contains `index.html` at its top level for builders that accept a single HTML file or a ZIP:
1. Import this ZIP (or its root `index.html`) into a reputable HTML-to-APK builder.
2. Set the app name to **The Hollow House**.
3. Enable JavaScript, internet access, and WebRTC/data channels if those options are offered.
4. Set the app orientation to **Landscape**.
5. Build/sign the APK, then install it through Android's installer prompt.

Builder websites and free plans can change. Check current terms and permissions before uploading or paying. A wrapper that blocks external HTTPS scripts or WebRTC may allow offline AI matches but not online rooms.

BUILD WITH ANDROID STUDIO
-------------------------
A complete Android Studio project is included in the `HollowTable/` folder.
1. Extract the ZIP.
2. Open `HollowTable/` in Android Studio.
3. Install Android SDK 36 and JDK 17+ if prompted, then let Gradle sync.
4. Choose **Build → Build APK(s)**.
5. The debug APK is created at:

   `HollowTable/app/build/outputs/apk/debug/app-debug.apk`

On Windows, `HollowTable/build-apk.bat` is included as a helper. It expects Android Studio/JDK 17+ and Android SDK 36 already installed, and downloads Gradle 8.13 if needed.

FILES
-----
- `index.html` — the complete single-file game for mobile browser or HTML-to-APK packaging.
- `HollowTable/` — Android Studio WebView wrapper project; game assets are bundled locally.

VALIDATION / LIMITATIONS
------------------------
- JavaScript syntax validation passed.
- Automated runtime smoke test passed: local 2-player match initialized, random starting die assigned, roll queued and settled, canvas loop ran, Admin menu opened, all 144 dice IDs were unique, and all 888 faces executed through the effect resolver without an exception.
- The archive is source code, not a precompiled APK.
- An Android APK build, physical-device play test, and live two-device online session were not available in this environment. Online connectivity still needs testing on the actual devices/networks you plan to use.
