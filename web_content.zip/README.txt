DIGITAL KHATA PRO
==================
This version follows the supplied six-screen reference:
1 Home
2 Village / City (Shop replaced)
3 Customers
4 Product Details / Add Product
5 Sales
6 Admin

There is NO Shop page and NO Ledger page.

Features:
- Add unlimited villages/cities
- Add unlimited customers
- Customer number, phone, village/city
- Add products and sales
- Quantity, rate, cash, recovery, Black/Baki, notes
- Automatic sales/recovery/cash/outstanding/quantity totals
- Date and day
- Date-wise sales summary
- Product filters: Surf, Soap, Dish Wash Bar
- Admin totals
- Add/delete products
- Backup/export and restore/import JSON
- Light/Dark mode
- Data is saved locally on the device/browser

Open index.html in Chrome. For an Android APK, this project can be wrapped with a WebView/Capacitor build.
