ROYAL VOICE CHAT — हिंदी डेमो

इस्तेमाल:
1. index.html को Chrome/किसी भी आधुनिक ब्राउज़र में खोलें।
2. किसी रूम पर "जॉइन" दबाएँ।
3. माइक, गिफ्ट और शेयर बटन UI डेमो के रूप में काम करते हैं।

नोट: यह फ्रंटएंड डेमो है। असली multi-user live voice के लिए WebRTC/LiveKit/Agora जैसे voice backend और server-side authentication जोड़ना होगा।
