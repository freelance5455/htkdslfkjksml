NISHANT LIVE CHATS - SAB KUCH EK ZIP ME
========================================
app/            Android app (WebView, index.html: app/src/main/assets/index.html)
backend/        Node server (Express + socket.io) + LiveKit docker-compose
server/         Chhota test server (Hello World)
.github/        APK build workflow (GitHub Actions)

APK BANANA (phone se, free):
 1. github.com par repository banao.
 2. Is ZIP ke ANDAR ki saari files/folders upload karo (.github folder bhi - hidden hai,
    Files app me "show hidden" on karo).
 3. Actions tab -> "Build APK" -> Run workflow. 5-8 min baad Artifacts me APK milega.
APK BANANA (computer): Android Studio me yahi folder kholo -> Build > Build APK(s).

SERVER CHALANA: backend/README.txt dekho (docker compose up -d).
APP ME: Me tab -> Backend server / Live Server menu me URL daalo.
Owner/Admin panel: Home par "Nishant Live Chats" title 7 baar tap -> email unlock.
Owner/Admin PIN abhi 1111 / 2222 hain - badal dena.

GOOGLE LOGIN: GOOGLE-LOGIN-SETUP.txt padho (Web Client ID + server .env zaroori).
