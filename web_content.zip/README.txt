NovaSnake Ultimate — Compact HUD Edition

Updated from NovaSnake_Ultimate_FIXED.

UI changes only:
- Smaller score and length HUD at the top so more of the arena remains visible.
- Smaller, more transparent leaderboard moved closer to the top-right corner.
- Smaller HUD labels and spacing for a cleaner mobile landscape view.
- Gameplay logic, food pickup, growth, bots, collisions, boost, joystick, skins, coins, minimap and Bluetooth UI are preserved.

The food/eating fix from the previous build is preserved.
Bluetooth 2-player still requires the Android native Bluetooth bridge described in the project architecture; pure HTML cannot provide reliable phone-to-phone Bluetooth networking by itself.
