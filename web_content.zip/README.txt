ENDCORD ULTIMATE 4.0
=====================

Start:
- index.html im Browser öffnen.

Neu:
- Login/Registrierung-Demo
- Owner / Administrator / Moderator / Support / Member
- Admin Center mit Übersicht, Nutzerverwaltung, Reports, Audit Log und Rollen
- Nutzer verwarnen / sperren (lokale Demo)
- Server wechseln und neue Server anlegen
- Textkanäle erstellen
- Voice-Kanal-Oberfläche
- Nachrichten senden, bearbeiten, löschen
- Reaktionen
- Suche mit Strg+K
- Freunde und DMs
- Benachrichtigungen
- Profile und Status
- Akzentfarbe
- LocalStorage
- Responsive Handy/PC-Layout
- Modernes Endcord-Design

WICHTIG:
Diese Version ist eine Frontend-Demo. Alle Daten werden nur im Browser gespeichert.
Für echte Accounts, echte Mehrspieler-Kommunikation, sichere Adminrechte,
echte Voice-Chats und serverseitige Bans wird ein Backend mit Datenbank und
Authentifizierung benötigt.

LOGIN
=====
Erster Owner-Account:
Benutzername: Endcord
Passwort: louli2012

Hinweis: Dies ist eine reine Browser-Demo. Das Passwort steht im Frontend-Code und ist NICHT für echte Produktion geeignet. Für eine echte App muss die Anmeldung serverseitig mit sicherem Passwort-Hashing erfolgen.
