Kotak Lifestyle Survey - APKForge Ready

Offline Android survey app.

IMPORTANT APKForge settings:
- JavaScript: ON
- Allow Internet/Web access: ON (needed only for WhatsApp web fallback)
- Allow external links / external apps: ON, if available
- Do not block tel:, whatsapp:, or intent: links

Buttons:
- WhatsApp: opens the WhatsApp Android app using an intent, with web fallback.
- Call: opens the phone dialer using tel:.
- Save Contact: opens Android Contacts using an intent. If unsupported, a .vcf contact file is offered as fallback.

Survey responses remain in the device's local browser/WebView storage and are not uploaded by this app.
