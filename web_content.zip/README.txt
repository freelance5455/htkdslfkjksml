RezaTools
=========
Web app offline berisi:
1. Kalkulator ilmiah
2. Tabel periodik
3. Catatan (tersimpan di localStorage)
4. Alat ekonomi: pajak, diskon, untung/rugi
5. Konversi satuan

Cara pakai:
- Ekstrak ZIP.
- Buka index.html di browser untuk mengetes.
- Untuk dijadikan APK, masukkan folder ini ke pembungkus WebView/HTML-to-APK yang mendukung file lokal.
- Pastikan index.html menjadi halaman utama.
