JOGO DAS 140 CASAS — ANDROID TV OFFLINE

Esta versão é um protótipo Web offline preparado para Android TV.

Inclui:
- 140 casas
- 2 jogadores
- 2 dados simultâneos
- chegada exata à casa 140
- se ultrapassar 140, recua a diferença
- 60 casas coloridas (10 verdes, 10 amarelas, 10 azuis, 10 laranja, 10 cor-de-rosa, 10 roxas)
- 10 bombas
- 6 escadas
- avançar manualmente introduzindo o número de casas
- recuar manualmente introduzindo o número de casas
- passar vez
- interface com botões grandes
- funciona sem Wi-Fi e sem Internet

Ficheiro principal: index.html

NOTA:
Este ZIP contém o protótipo offline. Para gerar um APK Android TV é necessário empacotar este conteúdo num projeto Android/WebView ou usar uma ferramenta de criação de APK compatível.


ATUALIZAÇÃO ANDROID TV:
- Navegação por comando D-pad (cima/baixo/esquerda/direita)
- OK/Enter ativa os botões
- Foco visual forte para saber onde está selecionado
- Campos Avançar/Recuar podem receber números pelo teclado da TV
