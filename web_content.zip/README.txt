PITH  (web version for zip-to-apk converters)
=============================================

index.html is at the top level of this ZIP. Upload the whole ZIP to your converter.

Converter settings to switch on
- Internet permission (required for Gemini)
- JavaScript and DOM storage / local storage (required: chats are stored on the device)
- File upload and camera access (for the + button: Camera, Gallery, Files)
- Optional: vibration (haptic feedback)

What works
- ChatGPT-style layout: chat history sidebar (pin, rename, delete), main chat
- Streaming replies, Markdown, syntax-highlighted code with copy
- Copy, edit and resend, delete messages; regenerate; timestamps; auto-scroll
- Image generation and image editing (Create image in the + menu)
- Attach images, PDFs, audio, text and code files
- Search across all chats, with jump to the message
- Export a chat as text or PDF
- Instructions per chat plus default instructions
- Offline queue: messages wait and send when the connection returns
- Themes: 4 built in, unlimited custom themes, full-spectrum colour picker,
  chat background image, bubble corners, text size, live preview
- Local profile (name and photo)

Google Sign-In
Google blocks sign-in inside embedded WebViews, which is what every zip-to-apk converter
produces, so it cannot work in this kind of APK. The app uses a local profile instead.

API key
The Gemini key is hardcoded in js/gemini.js (top of the file), as requested. Anyone who
unpacks the APK can read it. Restrict it in Google AI Studio and set a spend cap.
Models are listed in the same file.

Files
index.html, css/, js/ (util, store, md, gemini, theme, state, ui, pdf, chat, views, settings, main),
manifest.webmanifest, icon-192.png, icon-512.png
