SkyHop v1.6.1
- index.html: game with ten selectable profile photos.
- Tap the profile avatar to open the slim vertical scrolling photo list; photo choices have no numbered labels.
- The selected avatar and profile are stored locally in the browser/app storage.
- update.json is a version manifest. downloadUrl is blank until you provide a real hosted APK URL.
Deploy index.html and update.json to the Netlify site root (not inside an extra nested folder).
