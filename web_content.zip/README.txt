JADWALPINTAR v2 — ZIP untuk dikonversi menjadi APK
Bahasa antarmuka: Indonesia.
Cara: unggah ZIP ini ke layanan konversi web-ke-APK. index.html ada langsung di akar ZIP.

FITUR:
- Jadwal dengan tanggal, jam, durasi detik/menit/jam/hari, pengulangan dan pengingat awal.
- Tugas sekolah, PR, proyek, presentasi, ujian, kelompok, tenggat dan status selesai.
- Jadwal mata pelajaran berdasarkan hari, jam mulai/selesai, guru/ruangan, serta ringkasan mapel hari ini.
- Pengaturan baju/seragam per hari.
- Checklist perlengkapan sekolah seperti buku, alat tulis, botol minum, dan barang tambahan.
- Timer fokus dan istirahat.
- Catatan sekolah, target belajar, checklist bebas.
- Pencatatan uang saku/pengeluaran sederhana.
- Jam dan tanggal, notifikasi web, cadangan/impor data.
- Data disimpan di perangkat melalui localStorage.

CATATAN ALARM:
Alarm/notifikasi web tidak dijamin berbunyi jika aplikasi ditutup paksa, perangkat restart, atau Android membatasi aktivitas latar belakang. Alarm native yang andal memerlukan pengembangan Android native dan izin sistem yang sesuai.
