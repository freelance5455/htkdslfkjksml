DavElec — HTMLtoApp FINAL 8

index.html na raiz. Corrigido o bloco órfão que fazia código JavaScript aparecer como texto no ecrã e corrigido o preenchimento dos campos Quadro PRO.
