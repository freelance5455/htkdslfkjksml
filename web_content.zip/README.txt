M.S.M E Sevai — APK-ready Android project

The original uploaded HTML is included unchanged as:
app/src/main/assets/index.html

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. The debug APK will be under:
   app/build/outputs/apk/debug/app-debug.apk

Application ID:
com.msmesevai.app

This is a WebView wrapper around the uploaded HTML. Internet permission is enabled so web content such as maps can work.
