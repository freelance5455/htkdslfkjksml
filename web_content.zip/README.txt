TechYolo Social MVP

Phone-friendly HTML prototype with Home, Reels, Music, Chat, Calls and Profile.
Branding updated to TechYolo and includes the TechYolo logo.

To build an APK with an HTML-to-APK app, upload this folder as a ZIP containing index.html, techyolo-logo.png and this README.
