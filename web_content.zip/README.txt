# Deriv Pro Scanner V2 — Corrected Live HTML Edition

This version fixes the OFFLINE problem in the earlier HTML build.

## What was fixed
- Uses Deriv's current public WebSocket endpoint:
  wss://api.derivws.com/trading/v1/options/ws/public
- No login/token is required for public market data.
- Automatically handles Deriv's newer active-symbol field names:
  `underlying_symbol`, `underlying_symbol_name`, `underlying_symbol_type`.
- Includes a compatibility fallback to the older Deriv WebSocket endpoint.
- Handles current candle responses where `echo_req` may be absent.
- Requests historical candles without leaving a subscription open for every market.
- Subscribes to live ticks in chunks.
- Shows an on-screen API error/connection message instead of silently remaining OFFLINE.
- Tap the LIVE/OFFLINE indicator to reconnect.

## Important
Open or package the ROOT `index.html`.

If your HTML-to-APK converter asks for:
- Start page / Entry page: `index.html`
- Website folder: choose the extracted folder containing `index.html`
- Do NOT upload the old Kotlin/Gradle Android project.

## Market data
The app uses Deriv's public market-data WebSocket, which does not require account authentication.

## Safety
Signals are technical-analysis calculations for educational use. They are not guaranteed predictions or financial advice.
