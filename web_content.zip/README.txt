MOUSSA APP — prototype 0.1

Contenu:
- index.html : interface mobile trilingue (Hausa, Français, English)
- manifest.webmanifest : configuration installable PWA
- sw.js : cache de base hors ligne

IMPORTANT:
Cette première version est un prototype local. Les vidéos, likes et commentaires sont stockés uniquement dans le navigateur de l'appareil. Il n'y a pas encore de comptes réels, de serveur, de stockage vidéo partagé, de chat en direct, de modération ni de publication mondiale.

Pour le rendre accessible au monde entier:
1. Héberger ces fichiers sur un service web HTTPS.
2. Créer un backend sécurisé (authentification, base de données, stockage vidéo/CDN).
3. Ajouter les règles de confidentialité, signalement, blocage et modération.
4. Tester puis préparer la publication Android / Google Play.

Pour l'installer après hébergement: ouvrir le site dans Chrome Android, menu ⋮, puis "Installer l'application" ou "Ajouter à l'écran d'accueil".
