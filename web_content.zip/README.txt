GYM TRACKER - how to run and install

Files: index.html (the app), manifest.json + sw.js (installable + offline), icon-192.png, icon-512.png.

1. Quick try on a computer: double-click index.html (works, but cannot be installed this way).
2. Put it online: go to app.netlify.com/drop and drag this whole unzipped folder onto the page. You get a link like something.netlify.app.
3. Android: open the link in Chrome, menu (three dots) > "Add to Home screen" / "Install app".
   iPhone: open in Safari, Share > "Add to Home Screen".  PC: Edge/Chrome install icon in the address bar.
4. Real APK (optional): paste your link into pwabuilder.com and choose Package for Android.

Data and photos stay only on the device/browser you use. Clearing browser data, uninstalling, or changing phones erases them. The JSON backup covers workouts, exercises and body weight but NOT photo files - keep important photos in your gallery too.
