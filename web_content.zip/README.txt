MR.SHUCAYB PRO — Android Studio project (offline prototype)

Included:
- Android WebView wrapper and offline HTML UI
- Lobby, Controls, Custom, weapon notes and separated map notes
- No Internet permission is requested; settings are stored locally in WebView storage

How to build APK:
1. Install Android Studio on a computer.
2. Open this project folder (MR_SHUCAYB_PRO_ANDROID_PROJECT).
3. Let Gradle sync. Use a compatible JDK (17) if prompted.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find APK in app/build/outputs/apk/debug/app-debug.apk.
6. Transfer it to your Android phone and install, allowing installs from that source if Android asks.

Important:
This is a starter Android project, not a prebuilt APK. It must be built in Android Studio.
If Gradle plugin versions are unavailable in your environment, update plugin versions in build.gradle/app/build.gradle to those supported by your installed Android Studio.
This companion does not alter PUBG Mobile, inject into the game, or include copyrighted PUBG sound files.
