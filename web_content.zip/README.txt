Mahfile Masti Cafe - App Demo
================================

This is a first working mobile-web prototype based on the menu photos provided in the chat.

Included:
- Home screen
- Category-wise menu
- Exact menu prices transcribed from the supplied photos
- Add to cart
- Cart total
- VIP private room booking section
- Combo offers data
- Real supplied menu photos

Open index.html in a browser on a phone or computer.

Next development steps:
1. Connect WhatsApp order number
2. Add customer details/address
3. Add online payment
4. Build admin panel
5. Add real-time order status
6. Package as an Android app and prepare Play Store release
