ZABOTKER 3D — Android-friendly 3D game starter
================================================

WHAT THIS IS
- A small, playable 3D browser prototype with touch controls.
- Uses the portrait image you supplied as a project asset.
- Includes a simple city, player, car, jump/run/action controls, and a mission marker.
- This is a starter project, not a finished GTA-sized game and not yet an APK.

HOW TO RUN
1. Extract the ZIP.
2. Open index.html in a modern browser with internet access.
   The 3D engine is loaded from the Three.js CDN, so the first load needs internet.
3. On Android, some browsers restrict module files opened directly from file storage.
   If it does not start, upload the extracted folder to a static web host or run it
   through a local web server, then open the page in Chrome.
4. To build a true APK, this prototype needs to be wrapped in an Android WebView
   project or rebuilt in Unity. The ZIP itself is source code, not an APK installer.

CONTROLS
- Drag the left circular pad to move.
- RUN: hold to move faster.
- JUMP: jump.
- CAR: stand close to the red car and tap to enter/exit.
- ACTION: show mission message.

FILES
- index.html: game code and UI.
- assets/zabotker_portrait.jpg: cropped copy of your supplied image.

CUSTOMIZATION
- Change city colors, road layout, mission location, and player details in index.html.
- For a closer 3D likeness, a proper 3D character model is needed; a portrait photo alone
  cannot automatically become a fully animated 3D person.
