BaatChit - SETUP (2 phones ke beech message ke liye zaroori)

1. https://console.firebase.google.com par jao -> Add project (free).
2. Build -> Realtime Database -> Create database -> "Start in test mode".
3. Project settings (gear) -> Your apps -> Web (</>) -> app register karo.
   Wahan se apiKey, authDomain, databaseURL, projectId milenge.
4. index.html mein ye line dhundo:
   const CFG={apiKey:"",authDomain:"",databaseURL:"",projectId:""};
   aur apni values bharo. Phir ZIP dobara banao / SoftSpring mein upload karo.
5. Dono phones par NAYA APK install karo.

Firebase databaseURL set hai (baatchit-87420). Rules test mode me hone chahiye.

Story views: dusre ki story kholne par uska "view" count hota hai. Apni story kholo -> neeche "👁 N views" dabao -> kaun-kaun ne dekha list me dikhega.

Gallery: direct <input type=file> use hota hai. Agar SoftSpring ka WebView file chooser support nahi karta to HTML se fix nahi ho sakta (Android Studio project chahiye).
