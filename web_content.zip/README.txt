FINANCIAL ACCOUNTING MADE EASY — VERSION 2.0

Files:
- index.html: the app website used by the HTML-to-APK converter.
- README.txt: these instructions.

Version 2.0 improvements:
- Displays the Version 2.0 label.
- Tracks quiz attempts, correct answers, and accuracy on this device.
- Adds JSON backup and restore for lessons, progress, and quiz statistics.
- Keeps the existing Student lessons and Teacher Editor.

Important:
- Lesson edits and progress are stored locally on the device.
- Use Back Up Lessons / Back Up My Work before reinstalling, changing devices, or restoring a backup.
- Restore replaces the lesson data currently on the device, so only restore a backup you trust.
- Test the HTML preview before creating the APK.
