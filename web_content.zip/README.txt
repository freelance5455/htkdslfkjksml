MARKETPLACE ONLY — ZIP to APK website package

1. Open the ZIP-to-APK application on your Android phone.
2. Choose Marketplace_Only_ZIP_to_APK.zip (do not unzip it).
3. If prompted, choose index.html as the startup page.
4. Build, install and launch the generated APK.
5. Tap Browse listings. Use the Back button to return to the launcher when possible.

This ZIP is a website-style package, not a compiled Android APK.
It contains index.html in the root, plus this README.

IMPORTANT:
- Facebook may reject sign-in from embedded browsers/WebViews.
- Facebook can redirect pages into a separate browser or Facebook app.
- This package does not bypass Meta rules or prevent access to Facebook's feed from within its pages.
- Never enter your password into an unfamiliar converter app's own login form. Only sign in on an authentic facebook.com page.
- The shortcut URLs for Saved/Selling/Inbox may change.
- The application is not affiliated with Meta.
