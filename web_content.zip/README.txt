Block Burst — более ранняя HTML-версия игры. Откройте index.html в браузере Android. Это не APK.
