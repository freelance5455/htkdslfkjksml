ABDULSAMAD FAMILY RECORD - app package

Files
 index.html     the whole app
 manifest.json  app name, colours, icons (makes it installable)
 sw.js          lets the app open without internet
 icon-192.png, icon-512.png

Option 1 - Use as a phone app (no APK needed)
 1. Put all files in one folder on any web host (GitHub Pages, Netlify, etc.). It must be https.
 2. Open the link in Chrome on Android, tap the menu, then "Install app" / "Add to Home screen".

Option 2 - Make an APK
 Upload this folder (zipped) to a web-to-APK builder, the same kind of tool used for your current app.
 Use index.html as the start page.

Option 3 - Quick test on a computer
 Open index.html in a browser. (Installing needs https or localhost.)

Your data is saved inside the browser/app on that phone. Use Backup regularly.
Dates are read as Ethiopian calendar by default; change in Family details if you prefer Gregorian.
