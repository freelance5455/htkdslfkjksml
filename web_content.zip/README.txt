HERMES — ZIP-TO-APK WEBSITE PACKAGE

This is a mobile-friendly web app package. It is NOT a native Android Studio project.

HOW TO CONVERT:
1. Open your ZIP-to-APK / HTML-to-APK converter.
2. Select this ZIP file.
3. If the converter says it cannot render ZIP files, extract this ZIP and choose index.html, or use a converter that accepts website folders.
4. Set app name to HERMES.
5. Build/export the APK and install it.

FEATURES:
- Futuristic dark interface
- Browser speech recognition (where supported)
- Spoken replies using device text-to-speech
- Local time/date, YouTube/Google launch, web search, jokes and fun facts
- Optional OpenRouter online AI using model openrouter/free
- Session-only API key entry (not saved to disk)
- Basic offline page caching

LIMITATIONS:
- Voice recognition availability depends on browser/WebView and may require internet.
- No always-listening wake word; tap the microphone.
- A web wrapper cannot freely control Wi-Fi/Bluetooth, read notifications, send SMS, or control other apps.
- Online AI requires a valid OpenRouter key, internet and available free model capacity.
- Do not paste a key that has been shared publicly. The key is sent to OpenRouter from the app session.
