CHRISTMAS SAVINGS TRACKER — INSTALLABLE WEB APP

Files:
- index.html: savings tracker
- manifest.webmanifest: app name, icon and install settings
- sw.js: offline cache
- icon-192.png and icon-512.png: app icons

IMPORTANT:
A PWA must be served from an HTTPS website (or localhost) to install as an app.
Opening index.html directly from a file manager will NOT install it as an app.

After hosting these files at an HTTPS address:
1. Open that HTTPS address in Chrome on Android.
2. Open the Chrome menu (three dots).
3. Tap "Install app" or "Add to Home screen".
4. Confirm the install. The app icon will appear in the app list/home screen.

The tracker stores checked days in browser storage on this device.
The current reminder feature is only an in-page reminder while the page is open;
it is not a guaranteed background alarm or push notification.
