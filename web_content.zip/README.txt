FZ APP STUDIO — FIXED FRONTEND

Open FZ_APP_STUDIO_FIXED.html in a modern browser. The supplied FZ logo is embedded in the HTML, so no separate image path is required.

Working without a backend:
- Responsive splash, logo animation, navigation
- HTML upload, editor, preview, HTML export
- Save/edit/delete projects in this browser's local storage
- App Store search opens official Google Play search results
- APK mode selection and validation, file selection, readable error handling

Real services require a backend:
GET /health
POST /api/build-apk (multipart: appName, packageId, mode, websiteUrl, projectFile OR html)
Return an APK binary (application/vnd.android.package-archive) OR JSON {"downloadUrl":"https://...apk"}.
POST /api/deploy (multipart: siteName, domain, projectFile)
Return JSON {"url":"https://published-site.example"}.

Important: this frontend does not pretend to compile APKs or host websites locally. A real Android SDK/Gradle build server and a hosting provider/API must be configured in Settings. Do not put provider secret keys in frontend HTML.
