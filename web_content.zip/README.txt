ICT Market Maker SPOT Strategy
- Open ICT_Market_Maker_SPOT.html in Chrome.
- Upload historical crypto OHLCV CSV with Date,Open,High,Low,Close.
- Select the timezone matching your candle timestamps.
- This version is Spot-only: it generates BUY setups only and does not open short trades.
- Configure risk %, R:R, starting capital and fee per side.
- Run Backtest and review win rate, profit factor, net R and drawdown.

This is a research/backtest prototype, not live exchange integration or financial advice. The source PDF does not specify every numeric rule; EQH tolerance, displacement and OB retest logic are explicit approximations. Test on historical data with realistic spread, fees and slippage before risking funds.
