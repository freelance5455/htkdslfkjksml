Zain Eleven Android App project

This is an Android Studio project, not a prebuilt APK.
Build an APK:
1. Install Android Studio on a computer.
2. Open the ZainElevenAndroid folder in Android Studio.
3. Let Gradle sync and install any requested Android SDK platform (API 35).
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the generated APK on your Android phone.

Features:
- Mobile-friendly cricket scorer interface.
- Team/player setup, innings/overs, batting/bowling display.
- Runs, extras, wickets, choose next batter, add a player, bowler selection, undo.
- Innings and match scorecards.
- Match history stored locally on the device's WebView storage.

Notes:
- The scoring app runs offline once installed.
- Match history is stored inside app data on that phone. Uninstalling the app or clearing app data can erase it.
- This is a first Android port of the Tkinter scorer. Test scorekeeping and rules for your own match format before relying on it for official results.
