PAGE PRO — VERSION DE DÉPART
=============================

Cette archive contient une interface web mobile "Page pro" destinée à être convertie en APK avec un outil HTML-to-APK.

Fonctions incluses :
- écran d'entrée ;
- Internet obligatoire pour continuer ;
- création d'un compte qui correspond directement à une Page ;
- nom de Page unique (un seul nom suffit) ;
- page publique de type professionnel ;
- couverture, avatar, followers et publications ;
- création de publications avec texte et image ;
- boutons Message, WhatsApp, WhatsApp Business, Appel, Groupe, Vidéo, E-mail, Commande ;
- modification du nom, couverture, téléphone, WhatsApp et e-mail ;
- sauvegarde locale sur le téléphone.

IMPORTANT :
Cette version est le FRONT-END. Les Pages créées sont actuellement enregistrées dans le navigateur/téléphone (localStorage). Pour que "une Page créée sur un téléphone soit visible sur tous les autres téléphones et sur Internet", il faut ajouter un serveur + une base de données + authentification + stockage d'images. Il faut aussi un domaine/URL public.

Ne pas présenter cette version comme un réseau social mondial complet : elle est la base fonctionnelle de l'interface. La prochaine étape technique est le backend.
