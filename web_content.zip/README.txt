جاوید موزیک - نسخه HTML/Web App
این ZIP برای سرویس‌های تبدیل Web App/HTML به APK آماده شده است.
فایل index.html صفحه اصلی است.
