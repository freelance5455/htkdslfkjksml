myAakash-style home screen recreation based on the supplied screen recording.
Class changes only:
Mental Ability — 19 Nov 2026, 04:15 PM–06:15 PM
Social Science — 19 Nov 2026, 06:20 PM–07:20 PM

Open index.html to preview. To install on Android, host this folder on HTTPS and open it in Chrome, then use menu > Install app / Add to Home screen.
This is an unofficial visual recreation and does not connect to Aakash services. A native APK has not been compiled.
