NELAYAN GPS GO - PAKET HTML UNTUK APLIKASI HTML KE APLIKASI

Cara pakai:
1. Buka aplikasi HTML ke Aplikasi.
2. Pilih "Situs ter-zip".
3. Pilih file NELAYAN_GPS_GO_HTML_ANDROID11.zip.
4. Buat aplikasi dan izinkan akses lokasi/GPS saat diminta.
5. Uji GPS di luar ruangan terlebih dahulu.

Catatan:
- Peta dan navigasi peta membutuhkan internet.
- GPS menggunakan kemampuan geolocation WebView/browser. Jika pembungkus tidak memberi izin lokasi, GPS tidak bekerja.
- Alarm hanya dapat berjalan selama halaman/aplikasi aktif dan mendapat pembaruan lokasi. Alarm latar belakang/layar mati tidak dijamin.
- Data disimpan lokal pada WebView/browser. Menghapus data aplikasi dapat menghapus data.
- Ini bukan peta laut resmi, tidak menyediakan kedalaman laut, karang, rute aman, prakiraan cuaca, atau komunikasi SOS ke petugas.
- Uji semua fitur di darat dan jangan gunakan sebagai satu-satunya alat navigasi keselamatan.
