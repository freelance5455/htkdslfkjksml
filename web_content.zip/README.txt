FreshBasket phone-friendly ZIP-to-APK package

index.html is at the ZIP root and contains all app HTML, CSS and JavaScript.

Use a trusted ZIP-to-APK builder that accepts a static website ZIP. App name: FreshBasket
Suggested package ID: com.freshbasket.shop
Version: 1.0 (version code 1)

This is a prototype only. Orders are demo-only; online payments are not connected; there is no live inventory/backend. Do not use it to accept real customer orders or payments until a backend and secure payment integration are implemented.
