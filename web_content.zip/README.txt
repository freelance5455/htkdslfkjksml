TradeGuru AI - HTML app package

This ZIP contains a simple mobile-first educational demo.
It is NOT a native Android APK and has no live AI, market feed, broker login, or order execution.

The project is a static HTML app. Whether a third-party APK wrapper can package it depends on that service's accepted input format. Do not upload broker API keys or passwords to any wrapper.

Main file: index.html
