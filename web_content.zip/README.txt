SH TRADING BOT PRO SITE
Open index.html in a browser.

LIVE mode timeframes: 1 min, 5 min, 15 min.
OTC mode timeframes: 5 sec, 10 sec, 15 sec, 30 sec, 1 min, 2 min, 3 min, 5 min.
Includes live/OTC pair lists, automatic-signal interface, owner section and contact.

IMPORTANT:
The automatic signal button in this prototype generates illustrative demo output. It is NOT connected to Quotex and does not have access to Quotex's private/live or OTC feed. Real automatic signals require a lawful/authorized market-data source and a server-side signal engine. No system can honestly guarantee "best" or winning signals.
For a public link, upload index.html to a web host. For secure owner controls and signals visible to other users, add a private backend/database; do not put the owner password in HTML/localStorage.
