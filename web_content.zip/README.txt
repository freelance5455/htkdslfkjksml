TORNADO AI MOBILE WEB APP
Files: index.html, style.css, app.js

HOW TO CONVERT:
1. Extract this ZIP.
2. In your HTML-to-APK / website-to-APK converter, choose index.html as the home page.
3. Make sure style.css and app.js remain in the same folder as index.html and are included in the package.
4. Enable Internet permission only if you want external websites to open; enable microphone permission if offered and you want voice recognition.
5. Build/export APK and test it on your Android phone.

IMPORTANT LIMITATIONS:
- Chat is demo logic, not a connected AI model.
- Image Studio creates prompts only; it does not generate image files.
- Voice features depend on the converter, Android WebView, browser support and permissions.
- A web app cannot reliably control Android system settings or hardware.
- Do not put private API keys into client-side JavaScript.
