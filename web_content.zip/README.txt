MUMBAI HIGH HEIST — SCHOOL PROJECT PROTOTYPE

Included: index.html, PWA manifest, offline cache worker, app icons.

PLAY ON A SCHOOL COMPUTER:
1. Extract this ZIP from your USB drive.
2. Open index.html in Chrome or Edge.
3. The game can run locally in the browser. Test it on the school computer first.

ANDROID APK:
This ZIP is NOT an APK. To package it, first host the files at a public HTTPS URL.
Then open https://www.pwabuilder.com, enter that URL, choose Android packaging,
and follow its build steps. Downloaded APKs must be tested before sharing.

LIMITATIONS:
This is a small stylized prototype, not a complete GTA-like 3D game. It has
basic movement, a vehicle, simple NPCs and objectives. It has not been built
or verified as an Android APK.
