FreshDrop Sales PWA V1
======================
Open index.html through a web server/HTTPS hosting service for full PWA installation and offline service-worker support.
Owner PIN in this prototype: 1234 (change in production).
The app stores sales/products locally in the browser. For production, replace localStorage with IndexedDB and add a proper backup/sync layer.
