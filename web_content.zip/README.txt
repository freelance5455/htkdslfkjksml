Financial Accounting Made Easy - Version 2.2

This ZIP contains index.html for your Android HTML-to-APK builder.

Version 2.2 includes the existing Student and Teacher modes, 45 editable lessons, lesson search, Quick Checks, practice quizzes, on-device progress and quiz statistics, and JSON backup/restore.

New in Version 2.2:
- Searchable Accounting Glossary with 40 key terms.
- About section describing the learning app.
- Navigation between Student, Glossary and Teacher sections.
- Backup metadata updated to Version 2.2.

Phone-first build notes:
1. Upload this ZIP to your HTML-to-APK builder.
2. Set the app name to Financial Accounting Made Easy.
3. If updating an existing installation, keep the exact same package/application ID so Android recognises it as the same app.
4. Set version name to 2.2 and use a version code higher than the one in your currently installed APK.
5. Build and test the APK before replacing your existing installation. Keep a backup of your current lessons.

Important: Lesson edits, progress and quiz statistics are stored locally on each device. Export a JSON backup before reinstalling or changing devices. This version does not sync data online between devices.
