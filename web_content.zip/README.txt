DIPSTER DIGS! — fixed Acode project

1. Extract this ZIP into a folder.
2. In Acode, open the extracted folder and edit index.html.
3. Keep the assets folder beside index.html. Do not move the MP3 or PNGs away from assets.
4. To preview, open index.html in Acode's preview/browser. The phone needs to be sideways for the game view.
5. To package as an Android app, import this folder into your Android WebView/APK builder and choose index.html as the start page. Enable landscape orientation in that builder.

Included:
assets/do_static.png
assets/do_singing.png
assets/re_static.png
assets/re_singing.png
assets/dipster_sound.mp3

This is a corrected source project, not a compiled APK. Browser file permissions may affect audio preview in Acode; packaged local assets should be included in the APK.
