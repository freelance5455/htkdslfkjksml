CARA PAKE:
1. Ekstrak ZIP ini, lu bakal liat index.html di paling luar.
2. Masuk ke folder assets/, ganti / tambahin video mentah lu di situ.
   Contoh: idle.mp4, attack1.mp4, attack5.mp4, effect-celah.mp4
3. Di index.html / game.js, panggil videonya pake:
   assets/idle.mp4  (BUKAN C:/ atau link AI Studio)
4. Kalo mau jadi APK, ZIP ini tinggal di-build pake Capacitor / Cordova / AIDE WebView.
   Semua file di assets/ ikut kekemas otomatis.
