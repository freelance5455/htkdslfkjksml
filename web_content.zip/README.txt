Toolspea Website Clone archive
Source: https://neon-rift-fps--reemtwfeek71.replit.app/
Mode: entire
Captured: 2026-10-03T14:09:19.391Z
Pages: 1 · Assets: 9 · Size: 1.6 MB

How to open: unzip the archive and open index.html in any browser.
Internal links between downloaded pages are rewritten to relative paths, so you can browse offline.

Known limitations:
- Server-dependent features (forms, search, login, checkout, comments) only work on the live site.
- Content rendered by JavaScript after page load may be missing.
- Pages behind authentication, paywalls or bot protection are never downloaded.
- Only assets you enabled in the options were fetched; see assets.csv for anything skipped.

Rights: the archived content stays the copyright of its owner. You are responsible for how you use it.