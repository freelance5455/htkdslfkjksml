AQUA Sales V5
================
Isi:
- Multi-item order per toko
- Delivery berdasarkan tanggal
- Reschedule delivery tanpa input ulang
- Target per item/qty
- Master produk
- Sales
- Backup & restore data
- PWA files
- Folder web untuk percobaan HTML-to-APK

PENTING:
Preview ZIP di aplikasi HTML to APK sudah terbukti bisa menjalankan HTML.
Jika APK hasil build masih menampilkan appassets.androidplatform.net/web/index.htm,
masalah kemungkinan ada pada wrapper/builder, bukan pada fitur aplikasi.
