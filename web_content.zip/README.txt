GHOST SHIELD — OFFLINE DEMO

This is a web app package, not an APK installer.
Open index.html in a browser to preview. To make an APK, an Android packaging/build service or Android build environment is required.
The app does not connect to Free Fire, provide live ESP, modify game controls, or guarantee anti-ban protection.
