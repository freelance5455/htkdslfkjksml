Swiss Sistem Chess 1.0
Paquete preparado para conversores HTML → APK.

Contenido:
- index.html: aplicación Swiss Sistem Chess V7
- icon.png: ícono de la aplicación
- manifest.webmanifest: nombre, orientación vertical y tema

En el conversor:
Nombre: Swiss Sistem Chess
Orientación: Portrait / Vertical
Ícono: icon.png
Archivo web: index.html
