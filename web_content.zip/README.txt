QARAQALPAQ LIFE — APKForge HTML5 project

BUILD:
1. Import this ZIP into APKForge as HTML5 / Website / ZIP project.
2. App name: QARAQALPAQ LIFE
3. Package: uz.qaraqalpaq.life
4. Enable JavaScript.
5. Enable WebView Geolocation / Location.
6. Android permissions: ACCESS_FINE_LOCATION and ACCESS_COARSE_LOCATION.
7. For weather when online, allow Internet access (INTERNET permission).
8. Build APK. On first launch allow precise location while using the app.

FEATURES:
- Dark premium blue/neon interface, mobile responsive.
- Qaraqalpaqstan-focused schematic map and selected town search.
- Auto GPS tracking on app launch with moving blue location marker and map follow.
- Saved places and local profile/points/check-ins stored in localStorage.
- Explore check-in awards 25 points when GPS is within 1 km of the selected preloaded point.
- SOS contact: user enters a trusted phone number; call button opens Android dialer (does not silently place a call).
- Weather: fetches current weather from Open-Meteo when internet is available; caches last result for offline display.
- Online/offline status indicator.
- No external JS/CSS libraries required.

IMPORTANT LIMITATIONS:
This is a functional starter app/prototype, not a complete Google Maps replacement. The map is a schematic map with approximate coordinates and selected settlements. It does not contain every street, address, business, hospital, pharmacy or fuel station, and it does not calculate road routes or turn-by-turn navigation. For real detailed offline navigation, package an OSM-derived offline map and routing dataset, with required OpenStreetMap attribution and ODbL compliance.

GPS REQUIREMENTS:
HTML geolocation needs the APKForge Android WebView host to grant geolocation permission. If the APKForge builder has a separate WebView location permission setting, enable it. Also enable Android Location services and grant the app precise location. Wi-Fi may help Android location provider but Wi-Fi alone cannot guarantee a fix. Weather requires internet; all local saved features and schematic map work offline.
