My90Days — PWA prototype with reminders

Files:
- index.html: app UI
- manifest.webmanifest: installable web-app metadata
- service-worker.js: caching and notification click handling
- icon-192.png, icon-512.png: app icons

Important:
1. Serve this folder over HTTPS (for example, GitHub Pages) before testing install/notifications.
2. Open the HTTPS URL in Chrome on Android, then Chrome menu > Add to Home screen / Install app.
3. Open the app, go to the 🔔 Reminders tab, enable notifications, and test.
4. This prototype's scheduled reminders use page timers and are not guaranteed when the app/browser is fully closed or Android suspends it. For reliable notifications while closed, build a native Android APK with native scheduled notifications or implement push notifications with a server.
5. App data is stored in localStorage in the browser origin. Export a backup from the app before clearing site data.
