SHAIKH Box ERP V16 — Advanced Factory Suite (HTML-to-APK package)

Package entry point: index.html (ZIP root).

New V16 additions:
- Costing-to-quotation transfer: copies box style, dimensions, ply/flute, order quantity, selling rate and GST into the quotation form for review.
- Print / Save as PDF costing summary with factory dimensions, cut/deckle, per-box cost breakdown, selling rate, GST and order total.
- Sheet imposition Auto Fit compares normal and rotated blank orientation and chooses the higher-count grid estimate.
- Sheet panel now shows best-grid count/orientation and approximate unused sheet area alongside utilization.
- Preserves the existing V15 box selector, dieline previews, costing recipes and other ERP modules.

How to use: extract this ZIP or upload it to your usual HTML-to-APK converter. If print/PDF does not open in a WebView, enable printing/pop-ups in the converter or open the HTML in a browser.

Important limits: drawings and nesting estimates are planning aids, not production-certified dielines or a guarantee of factory yield. Check dimensions, grain/flute direction, trim/bleed, machine gripper, joint and allowances with your production team. Cloud backup/API credentials are not configured by this HTML package. Phone/APK runtime tests have not been performed here; verify the converter output and back up data before production use.
