V22 Stable
- Restores the working V18 circle loading behavior.
- Removes all teacher_code database references.
- Keeps working adaptive save/report logic.
- Adds an optional local teacher name field on login; it is stored on the device only.
- No SQL is required.
- Multi-teacher separation by shared email is NOT enforced at database level in this version; that requires a dedicated DB identity field/table.
