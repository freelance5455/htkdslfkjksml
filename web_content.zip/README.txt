TANJIRO VS RUI — HTML TO APK ZIP

This archive is formatted for the "ZIP File to APK" option in your HTML to APK app.
IMPORTANT: index.html is in the ZIP ROOT (not inside another folder).

CONTENTS
- index.html
- assets/tanjiro_vs_rui.mp4

HOW TO USE
1. In your HTML to APK app, choose "ZIP File to APK".
2. Select Tanjiro_Rui_HTML_to_APK.zip.
3. If the app asks for a start page or entry file, use: index.html
4. Build the APK, install it, and open it.
5. Tap "Enable motion effect" if shown. Tilt your phone to shift the scene.
6. If motion sensors are blocked in the WebView, drag/touch the screen to move the scene.

IMPORTANT LIMITATION
This HTML APK is an animated video viewer with tilt/parallax effects. It is NOT a true Android
system live wallpaper service and may not appear in Android's wallpaper picker. To use it as
a moving home-screen wallpaper, use a video-live-wallpaper app after exporting/saving the MP4.
The tilt effect works only while this HTML app is open and when the converter's WebView exposes
device orientation events. The included video loops silently.
