AUTO TEXT COLOR — POSTER VERSION
Direct text input is at the top. The colored live preview is shown in the middle. Color Design/Style section removed; 1000 Colors retained.
