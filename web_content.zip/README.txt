KIRATANDAN SAWIT v2.0 - HTML TO APK

Fail utama: index.html

Reka bentuk:
- Dashboard kemas hijau/putih.
- 11 LOT sebenar: A, C, E, G, J, K, N, Q, R, T, U.
- 15 platform setiap LOT (165 keseluruhan).
- Borang input 15 platform terus dalam satu skrin; tidak perlu tekan kad platform.
- Butang Simpan & Seterusnya menyimpan nilai yang diisi dan fokus automatik ke ruangan platform kosong seterusnya.
- Nama pekerja boleh ditukar.
- Rekod harian, edit/padam, laporan dan cetak/Simpan PDF.
- Backup/Restore JSON.
- Offline melalui localStorage.

Cara guna:
1. Extract ZIP.
2. Buka index.html dalam Chrome untuk uji.
3. Dalam HTML to APK Converter, pilih index.html atau folder hasil extract (ikut kemampuan converter).
4. Tetapkan nama KiraTandan Sawit dan aktifkan local/offline HTML assets.
5. Build APK.

PENTING:
Data disimpan dalam WebView localStorage. Buat backup berkala dan jangan clear data/uninstall sebelum backup. Uji backup/restore. PDF bergantung kepada sokongan print WebView pada converter; jika tiada, buka HTML dalam Chrome untuk fungsi cetak ke PDF.
