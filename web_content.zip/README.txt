EC TECHNOLOGIE — VERSION 1
=============================

Cette version est un prototype fonctionnel hors ligne.

Fonctions incluses :
- Tableau de bord
- Stock avec référence, désignation, achat, vente, quantité, seuil
- Recherche par référence/désignation
- Recherche automatique d'un produit lors de la saisie d'une référence dans un devis
- Gestion clients
- Création de devis
- Calcul HT / TVA 20 % / TTC
- Numérotation automatique des devis
- Historique
- Impression / Enregistrement PDF via la fonction d'impression du navigateur
- Données conservées localement dans le navigateur

UTILISATION
1. Décompresser le fichier ZIP.
2. Ouvrir index.html avec Chrome/Edge/Firefox.
3. Aucune installation ni connexion Internet n'est nécessaire.

NOTE
C'est une V1 de démonstration. La prochaine version peut ajouter :
- vraie génération PDF intégrée
- transformation devis -> facture
- déduction automatique du stock après vente
- gestion acomptes / reste à payer
- utilisateurs et mots de passe
- paramètres société
- sauvegarde/restauration des données
- logo EC Technologie officiel
- mise en page PDF encore plus proche du devis fourni.
