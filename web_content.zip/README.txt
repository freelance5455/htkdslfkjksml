KOTAK LIFESTYLE SURVEY – APKFORGE PACKAGE

Main file: index.html
App name: Kotak Lifestyle Survey
Orientation: Portrait
JavaScript: ON
Local storage/cookies: ON
Internet/Web permission: OFF if APKForge allows it

This version is intentionally a simple offline HTML package for APKForge.
Survey data is stored locally on the device using localStorage.
Export CSV regularly as a backup.
