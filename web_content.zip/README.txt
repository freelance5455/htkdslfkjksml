# My HUF Budget

A simple offline HUF budget tracker.

## Features
- Hungarian Forint (Ft)
- Add money
- Add expenses
- Automatic balance calculation
- Transaction history
- Local-only storage
- No account, server, API, or internet required
- Light/dark appearance follows the device

## Build as an Android app
This is a self-contained HTML project intended for an HTML-to-Android/website-to-APK builder.

Upload `index.html` (and `manifest.json` if the builder accepts multiple files) to your chosen builder and select a standalone/offline Android app option if available.

Important: keep JavaScript/localStorage enabled and do not add an external web URL.
