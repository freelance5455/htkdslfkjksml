Study Plan Nest V7
Offline-safe native HTML bar chart (no Chart.js dependency).
Kawaii UI polish with compact navigation.
