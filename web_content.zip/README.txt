MedGuide Pro - ZIP to APK website package

This ZIP contains index.html at the root, specifically for ZIP-to-APK tools that require index.html.

Included:
- Medicine search
- Medicine details
- Uses
- Common side effects
- Warnings
- Dose reference notes
- Urdu/English toggle
- Mobile-friendly professional interface

This is an educational/reference app, not a prescribing or diagnostic tool.
The database is a small starter set. For a public/production app, every record should be reviewed against current authoritative medical sources and updated regularly.
