Android WebView asset layout

Place the supplied HTML at:
  app/src/main/assets/web/index.html

The app's start URL should be:
  https://appassets.androidplatform.net/web/index.html

The HTML itself is unchanged. The error shown in the screenshot occurs while Android WebView is trying to load this asset URL, before the HTML or JavaScript can execute.
