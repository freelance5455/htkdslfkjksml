WINTER ARC — PREMIUM HABIT TRACKER

Files:
- index.html        Main app
- winter_arc_logo.png  App logo

How to use:
1. Open index.html in Chrome/any modern browser.
2. Your entries save automatically on the device.
3. Use Print for a printable tracker.
4. The app works offline; no API key is required.

Included:
- Premium glassmorphism UI
- Animated gradients and borders
- Animated progress feedback
- 30-day habit tracker
- Sleep tracker
- Weekly check-ins
- Monthly reflection
- LocalStorage persistence
- Mobile responsive layout
