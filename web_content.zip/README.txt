شهنشاھ دامن علي سرڪار — Final Search App

ڊيٽا: 704 گڏيل مواد يونٽ.
اصل archive ۽ اضافي مواد کي ساڳئي مواد جي نقل ختم ڪري گڏ ڪيو ويو آهي.
Search نتيجو مڪمل text ڏيکاري ٿو، ۽ نتيجي تي ڪلڪ ڪرڻ سان مڪمل مواد کلي ٿو.

Android APK build: Android Studio/Android SDK سان android فولڊر کوليو ۽ Build > Build APK(s) ڪريو.
