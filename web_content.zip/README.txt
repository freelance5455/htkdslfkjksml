FoundIt final web-app prototype.
QR scanning uses html5-qrcode for broader Android/iOS browser compatibility. Camera access requires HTTPS (or localhost). Manual FoundIt ID remains available as a fallback. Includes in-app messaging, finder location/return-time flow, and owner item management.
