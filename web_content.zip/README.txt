FOX WARRIOR - Pixel Art Assets
- All PNG, transparent background (except sky, dirt tile, water tiles which are opaque).
- Native pixel size. Scale in your engine with NEAREST filtering (no smoothing), e.g. x3 or x4.
- Animated assets: one PNG per frame (name_00.png ...) + horizontal strip in strips/.
- assets.json lists frame count, frame size, fps, loop and pivot (x,y from top-left) for every asset.
- Characters face RIGHT (fox) / LEFT (zombie). Flip horizontally in code for the other direction.
- Fox frames are all 80x64 with the same pivot (feet center) so animations never jump.
- Tiles: grass_top (32x16) sits on top of dirt (32x32). Platforms: L + M repeated + R.
- Backgrounds: sky/clouds/mountains/forest layers are tileable horizontally - scroll at different speeds (parallax).
