Offline Product Catalog web app.
Open index.html in a browser. For best offline/PWA behavior host it once over HTTPS and add to Home screen; browser local storage can be cleared by Android cleanup, so export/backup is not yet included.
