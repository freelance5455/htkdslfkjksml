BAHRIDDIN SHASHKA
Web-app package. Open index.html in a browser to play.
For APK conversion, upload this ZIP to a compatible HTML-to-APK builder.
