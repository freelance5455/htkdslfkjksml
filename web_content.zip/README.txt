HYAKKA RYOURAN - APK BUILDER

Sube este ZIP al conversor HTML -> APK.

IMPORTANTE: el archivo principal se llama index.html y está en la raíz del ZIP.
No cambies su nombre ni lo metas dentro de otra carpeta.

El juego es autocontenido y no necesita conexión a Internet para funcionar.
