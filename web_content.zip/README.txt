VEXA Battle Royale - mini prototype
========================================
A tiny mobile-friendly battle royale prototype.

How to play:
- Open www/index.html in a modern browser.
- On mobile: left side = movement, right side = shoot toward that point.
- Defeat all 8 enemies and stay inside the shrinking blue zone.
- If you lose, refresh the page (or press R on desktop).

This is an original prototype, not a copy of Free Fire assets or code.
For a real Android APK, this web prototype can be wrapped with a webview/build tool later.
