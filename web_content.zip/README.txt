Study Time Manager v1.0.2

Fixes:
- Timer session state is saved automatically in local storage.
- If the app is closed or reopened, an active or paused session is restored.
- Active time continues to count while the app is closed (if it was not paused).
- OFF saves completed session intervals into daily history, split at midnight.

Note: Data is stored in the same browser/WebView storage. Clearing app data, uninstalling, or opening the app in a different browser/WebView can remove or separate the history. Native Android background reliability requires a foreground service and persistent database integration.
