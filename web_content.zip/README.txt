BCCI Cricket Manager (Unofficial) — ZIP-to-APK version

This archive has index.html at the ROOT, as requested by the ZIP-to-APK app.

How to use:
1. Download this ZIP.
2. Open your ZIP-to-APK app and select this file.
3. If the converter supports packaging local HTML files, follow its prompts.

Features: teams, players, matches/schedules, editable scorecard notes, local browser storage, JSON backup export/restore.

Limitations: automatic cloud sync/email backup is not implemented. Export JSON then attach it to email or upload to cloud storage. Scorecards are editable notes, not ball-by-ball scoring. This is not an official BCCI app and is not affiliated with BCCI.
