NEUROVIA GAMES - ANDROID WEBVIEW FIXED PROJECT
===============================================

What this fixes
---------------
The previous APK was loading the HTML UI, but game buttons could fail if the
APK builder disabled JavaScript or DOM storage. This project uses a native
Android WebView and explicitly enables JavaScript + DOM storage.

Included
--------
- Offline Neurovia Games HTML game
- Sequence Recall
- Number Recall
- Grid Memory
- Pattern Hunter
- Odd One Out
- Idea Forge
- XP / level / streak / sessions
- Local progress save
- Vibration support
- Native Android WebView wrapper
- Portrait layout
- No external JavaScript libraries

Build
-----
1. Open this folder in Android Studio (or a compatible Android Gradle builder).
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated APK on Android.

Important
---------
This ZIP is an Android SOURCE PROJECT, not a precompiled APK.
A compiled APK requires an Android build environment.

If your mobile APK builder only accepts a single HTML file:
use app/src/main/assets/index.html and make sure its WebView settings have:
JavaScript = ON
DOM Storage / Local Storage = ON
Web content = trusted/local

Official Android documentation confirms JavaScript is disabled by default in
WebView and must be enabled for JavaScript-based web apps. DOM storage is also
disabled by default.

App
---
Name: Neurovia Games
Tagline: Train Memory • Build Ideas • Improve Life
Package: com.neurovia.games
Version: 1.0
