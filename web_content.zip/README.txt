BOOTS AI - version web 0.0.4 (HTML / CSS / JS, aucune dépendance)

FICHIERS (tous à la racine du ZIP) :
index.html, style.css, script.js, manifest.webmanifest, icon.svg, icon-192.png, icon-512.png, README.txt

CONVERSION EN APK
- Importe le ZIP tel quel. Le point d'entrée est index.html (à la racine, pas dans un sous-dossier).
- Choisis le mode "fichiers locaux / HTML" du convertisseur, PAS le mode "URL de site web".
- Active les permissions INTERNET et MICROPHONE si le convertisseur les propose.

« PAGE WEB NON DISPONIBLE » AU LANCEMENT - CAUSES POSSIBLES
Je n'ai pas l'APK ni le convertisseur sous les yeux : je ne peux pas confirmer la cause exacte. Les causes probables, par ordre :
1. Le convertisseur est en mode "URL" (il tente de charger une adresse web, pas tes fichiers) ou l'URL est vide/invalide.
2. index.html n'est pas à la racine de l'archive (ZIP contenant un dossier qui contient les fichiers).
3. L'ancienne version enregistrait un service worker (sw.js) et se référait à des fichiers que le WebView ne servait pas :
   il a été supprimé. Cette version n'effectue AUCUNE requête réseau au démarrage et tous les chemins sont relatifs.
4. Un lien "intent:" ouvert directement dans le WebView provoque cette même page d'erreur : les commandes lancent maintenant
   le lien dans un iframe caché, ce qui laisse l'application intacte si Android/le convertisseur le refuse.
Si l'erreur persiste : dis-moi le nom du convertisseur et ses réglages (mode local ou URL).

CONFIGURATION IA (icône ⚙) - GOOGLE GEMINI PAR DÉFAUT
Cause de l'erreur 401 « Invalid API Key » constatée avant : l'application envoyait ta clé Gemini à Groq (api.groq.com), un autre
fournisseur au format OpenAI. Groq refusait donc la clé. Corrigé : fournisseur "Google Gemini" avec l'API native
(POST https://generativelanguage.googleapis.com/v1beta/models/{modèle}:generateContent, clé dans l'en-tête x-goog-api-key,
corps contents/parts + systemInstruction). Une clé commençant par « AIza » est toujours envoyée à Gemini, jamais ailleurs
(les anciennes configurations sont migrées automatiquement).
Étapes : ⚙ > fournisseur Google Gemini > colle ta clé > Modèles (liste réelle des modèles de ta clé) > Tester > Enregistrer.
Clés acceptées : « AIza… » et le nouveau format « AQ.… » (Google AI Studio ne génère plus que des clés AQ.).
Modèle par défaut : gemini-3.8-flash. FIABILITÉ : en cas d'échec (modèle introuvable/retiré, quota, surcharge, clé AQ. refusée
pour ce modèle), l'application réessaie une fois puis bascule automatiquement sur gemini-3.5-flash puis gemini-2.5-flash, et retient
le modèle qui marche. Le message d'erreur final liste les modèles essayés.
Problème connu côté Google : certains comptes avec clé AQ. reçoivent 401 « ACCESS_TOKEN_TYPE_UNSUPPORTED » sur l'API REST
(rapporté sur le forum Google AI). Si cela arrive avec tous les modèles : crée une nouvelle clé, ou utilise Groq (gratuit) via
« Compatible OpenAI » (clé gsk_…, URL https://api.groq.com/openai/v1).
PROTECTION DE LA CLÉ : la clé est saisie par toi et stockée localement (localStorage), jamais dans le code. Mais une clé utilisée
côté client reste récupérable par quiconque a accès à l'APK ou au téléphone. Si tu diffuses l'application : mets en place un petit
serveur intermédiaire (ex. Cloudflare Worker) qui garde la clé et la transmet à Gemini ; dans ⚙ mets l'URL de ce serveur à la place
de l'URL Google. Sinon, limite le quota de ta clé dans Google AI Studio.
Internet obligatoire pour les réponses IA. Niveau gratuit Gemini : quotas limités (erreur 429 si dépassés).

LIMITES CONNUES
- Ouvrir applis/paramètres : liens "intent:", dépendants du convertisseur. 14 applis reconnues (liste APPS dans script.js).
- Micro : la reconnaissance vocale web marche dans Chrome, souvent pas dans un WebView d'APK. Alternative : micro du clavier Android.
- Pas d'arrière-plan ni de mot d'activation.
- Hors connexion : l'interface et les commandes marchent, pas les réponses IA.

TESTS RÉELLEMENT EFFECTUÉS (Chromium headless, écran 393x800, ouverture file://) avec serveurs Gemini/Groq SIMULÉS :
endpoint, en-tête x-goog-api-key, format du corps, lecture de la réponse, historique multi-tours, erreurs 400/404/réponse bloquée,
migration d'une ancienne config Groq + clé AIza, mode OpenAI, absence de clé, commandes, absence d'erreur JS.
Aucune vraie requête n'a été envoyée à Google (pas d'accès réseau ici) : ta clé reste à tester de ton côté (bouton "Tester").
NON TESTÉ : vraie API Gemini, micro/reconnaissance vocale, synthèse vocale, ouverture réelle d'applis Android, installation de l'APK.
