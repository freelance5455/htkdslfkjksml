SHAIKH Box ERP V15 - HTML-to-APK converter package

Open this ZIP in your HTML-to-APK converter. The main page is at the ZIP root as index.html, which is the entry name many converters expect.

If your converter requires a specific ZIP layout or additional settings, follow its own instructions. APK build and phone runtime have not been verified here.
