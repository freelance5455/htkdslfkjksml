SMART DAILY TOOLS — STARTER APP
1. Open index.html in a modern browser to try the app.
2. This is a starter web app (PWA-ready direction), not an Android APK.
3. The ad area is only a placeholder. Real AdMob ads require an Android build,
   an AdMob account, app IDs/ad unit IDs, consent/privacy disclosures, and policy review.
4. Quick Notes are stored locally in the browser on the same device.
5. Next step: package and test as an Android app, then integrate AdMob responsibly.
