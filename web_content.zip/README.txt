StudyBoss 4.0 — HTML to APK Ready
1) ارفع index.html أو ZIP كله إلى HTML to APK Builder.
2) اجعل App Name = StudyBoss.
3) فعّل Camera permission لأن AI Verification يستخدم الكاميرا.
4) التطبيق يعمل Offline للبيانات الأساسية.
5) Online AI يحتاج Server URL من الإعدادات.
6) لا تضع OPENAI_API_KEY داخل index.html أو APK.
