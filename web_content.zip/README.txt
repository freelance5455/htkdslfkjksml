RadiaNano 2.1 — Feature / USB + BLE synchronization edition
===========================================================

Open index.html from the ZIP-to-APK HTML importer. index.html is at ZIP root.
This package contains application code and documentation only; it is not padded
with dummy data to reach an arbitrary archive size.

Included functions
------------------
- Live CPM and pulse-total parser: CPM:<n>, PULSE:<n>, bare integer CPM.
- JSON telemetry input: {"cpm":123,"pulse_total":456}.
- BLE UART: Nordic UART Service and HM-10 FFE0/FFE1.
- USB OTG through a native Android wrapper bridge, plus Web Serial fallback
  where the browser actually exposes navigator.serial.
- Automatic config push after BLE connection or USB connection callback.
- Config sequence number, timestamp, chunked BLE writes and CONFIG_ACK status.
- CPM trend chart with 1/5/15/60 minute and full-session ranges.
- EMA / five-sample average / raw display modes; configurable EMA alpha.
- Optional non-paralyzable dead-time correction (disabled by default).
- CPM and dose-rate alarms, vibration, session peak/average, dose integration.
- User-entered CPM-per-uSv/h factor; no invented calibration factor.
- Local history/settings, CSV export, log export, Demo clearly marked as simulated.

USB Android wrapper contract
----------------------------
The HTML page cannot obtain Android USB host access by itself inside a generic
WebView. The ZIP-to-APK wrapper must expose these JavaScript bridge methods:

  AndroidBridge.connectUsb()
  AndroidBridge.disconnectUsb()
  AndroidBridge.writeUsb(text)       // sends UTF-8 serial bytes
  AndroidBridge.setBaudRate(number)  // optional
  AndroidBridge.vibrateAlert()       // optional

And invoke these page callbacks from native Android:

  window.onUsbConnected({name, vendorId, productId})
  window.onUsbSerialData(text)       // arbitrary chunks; page line-buffers
  window.onUsbDisconnected(reason)
  window.onUsbError(message)

USB serial defaults to 9600 baud, 8 data bits, no parity, 1 stop bit.
The Android wrapper must request USB permission and implement the USB host
serial driver (for example, a compatible usb-serial library). If it does not
provide the bridge, USB OTG will not work in its WebView. Web Serial is only a
fallback on browsers that support it; many Android WebViews do not.

ESP32 configuration protocol
----------------------------
On every BLE/USB connection, the app sends newline-terminated JSON:
{"cmd":"SET_CONFIG","version":1,"seq":1,"ts":0,
 "alarm_cpm":300,"calibration_cpm_per_usvh":null,
 "dose_alarm_usvh":1,"smoothing":"ema","ema_alpha":0.35,
 "dead_time_us":0,"baud_rate":9600}

ESP32 firmware must parse and validate the command, apply supported settings,
and reply with a newline-terminated acknowledgement:
{"event":"CONFIG_ACK","seq":1,"ok":true}

Optional identity response:
{"event":"HELLO","name":"ESP32 Radiation Node","fw":"1.0"}

The app displays ACK only after receiving CONFIG_ACK; sending a command is not
proof the firmware applied it. The ESP32 must implement SET_CONFIG itself.
BLE writes are split into <=180-byte chunks to avoid truncating longer JSON.
Nordic UART TX (notify): 6E400003-B5A3-F393-E0A9-E50E24DCCA9E
Nordic UART RX (write): 6E400002-B5A3-F393-E0A9-E50E24DCCA9E
HM-10: service FFE0, characteristic FFE1 (module firmware varies).

Measurement and safety notes
----------------------------
- CPM-to-uSv/h is an estimate. Enter only a factor obtained with a suitable
  calibrated reference for the actual tube, circuit, geometry and radiation.
- Smoothing changes response and can conceal short transients; RAW mode is
  available when immediate response is required.
- Dead-time correction is off by default; use only a measured system dead time.
- A simple GM pulse counter does not provide gamma energy spectra or isotope ID.
- This build is statically checked, not hardware-certified. Test USB bridge,
  BLE module, ESP32 ACK, alarm and calibration on the actual hardware.
