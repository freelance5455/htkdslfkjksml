APLEX Standalone HTML - Version 1.0.2

Files:
- index.html: single-file HTML app with inline CSS and JavaScript.

Build:
1. Upload this ZIP or index.html to htmltoapp.dev.
2. Choose ZIP to APK (or HTML to APK).
3. App name: APLEX
4. Package name: com.arminstudios.aplex
5. Version name: 1.0.2

Notes:
- This is a WebView-wrapped HTML interface. AI models, image generation/analysis, and subscription payments are not connected yet.
- First launch shows the ARMIN STUDIOS splash, four onboarding pages, and a local display-name account screen.
- Contact action opens the email app using mailto: elantradar@gmail.com.
