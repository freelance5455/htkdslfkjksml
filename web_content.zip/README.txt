# PatiGram Android
Android Studio ile açılabilir PatiGram uygulama projesidir.
1. ZIP'i çıkarın.
2. Android Studio > Open ile klasörü açın.
3. Gradle senkronizasyonunu bekleyin.
4. Build > Build APK(s) > Build APK(s).
5. APK: app/build/outputs/apk/debug/app-debug.apk
Not: Bu sürüm yerel çalışan prototiptir; gerçek kullanıcı hesabı, Firebase, sunucu ve mağaza yayını henüz eklenmemiştir.
