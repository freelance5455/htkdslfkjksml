SMART — ZIP-TO-APK WEB BUILD

This package is intentionally FLAT for ZIP-to-APK/WebView services.
Do NOT put these files inside another web/ folder before uploading.

Files:
- index.html
- app.js
- style.css
- assets/smart-background.svg

The converter can place these files under its internal web/ directory and load web/index.html.
