RICK.demon Overlay FINAL
1. Compile como APK.
2. Abra o aplicativo: o painel HTML deve aparecer.
3. Toque em ATIVAR BOLHA RICK.demon.
4. O Android abrirá a tela de "Exibir sobre outros apps".
5. Ative a permissão.
6. Volte ao RICK.demon e toque novamente em ATIVAR BOLHA se necessário.
7. A bolha roxa aparece por cima dos outros aplicativos e pode ser arrastada.
