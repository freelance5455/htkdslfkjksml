Medicine quiz — 35 questions

This ZIP contains index.html and can be opened in a browser or imported into an HTML-to-APK builder as a local HTML project. Keep index.html as the start page.

The original visual theme and the existing coin/shop features are retained. Correct answers award 10 coins. This is educational content only; it is not medical advice.
