CONNECTLY - BLUE UPDATE

Theme: Midnight Blue + Electric Blue
Backend: Existing Supabase project
Main file: index.html

This package does not contain database migrations.
Your existing Supabase database and accounts are not modified.
Do not expose Supabase service-role keys.
