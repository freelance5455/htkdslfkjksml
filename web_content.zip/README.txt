AL-KHAIR TRADERS
V4 HTML Prototype

New in V4:
- Every required document has BOTH Camera and Upload File options.
- Camera uses the device camera on supported phones/browsers.
- Image preview is shown after selecting/taking a photo.
- Retake is supported by opening the camera option again.
- Existing files can still be selected from the device.
- Payment information: JazzCash, 03056685229, IRFAN.
- No visible DEMO label and no phase numbers.
- Registration remains 3 logical sections.

Documents:
CNIC Front
CNIC Back
Shop Picture
Electricity / Gas Bill
Payment Receipt / Proof
Visiting Card (last)

Important:
This is a local HTML prototype. Files are NOT uploaded to a real server.
The 30-minute verification timer is only a prototype behavior.
A production version will need a secure backend, database, storage, admin portal,
real verification, authentication, and server-side status control.

V5 VALIDATION:
- Mobile number accepts digits only and exactly 11 digits.
- Pakistani mobile number must start with 03.
- CNIC accepts digits only and exactly 13 digits.
- Email must have a valid email structure such as name@gmail.com.
- Full name is restricted to letters, spaces, apostrophe, dot and hyphen.
- Mobile/CNIC limits are enforced while typing as well as on validation.

V6: Added the AL-KHAIR TRADERS logo to the application header.

V7: Payment section now clearly states Minimum Payment: PKR 100,000.
