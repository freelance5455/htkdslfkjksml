PHONE GUARD AI — WEB ZIP PROJECT

This ZIP contains a mobile-first HTML/CSS/JavaScript app intended for converters that accept a website/HTML project. It is NOT a native Android Studio project.

HOW TO USE
1. Upload this ZIP to a converter that explicitly supports HTML/website projects.
2. If it asks for a start page, choose index.html.
3. Set app name to Phone Guard AI and package ID to com.phoneguard.ai if requested.
4. Build a test APK and test on your own device.

IMPORTANT
- Online ZIP-to-APK converters have different required formats. This website ZIP is compatible only with converters that package HTML websites, usually inside an Android WebView. No universal converter format exists.
- This app performs simple local text pattern checks; it is not an AI model, antivirus, malware scanner, or verified scam-number database.
- It cannot read SMS, monitor calls, inspect other apps, scan all device files, or send background alerts.
- Number reports are stored only in this browser/device and are unverified.
- The file checker reads basic file metadata only; it does not inspect file contents.
- The cybercrime links are official destinations, but verify URLs before sharing this app.
- Do not distribute publicly until you test the app, publish a privacy policy, add real threat-intelligence sources, and complete security/legal review.
