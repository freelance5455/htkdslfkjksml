BRASIL TRUCK MOBILE
Arquivo pronto para conversor HTML -> APK.
O index.html deve ficar na raiz do ZIP.
Protótipo inclui estrada, caminhão, aceleração, direção, barro, sujeira e chuva.
