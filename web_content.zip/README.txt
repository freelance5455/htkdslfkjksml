ARS WARP VPN
This ZIP contains a mobile-friendly HTML VPN interface.

Upload the ZIP to HTML-to-APK and build it as an Android APK.

IMPORTANT:
This is a web/HTML interface. The Connect button simulates connection status and does NOT create a real VPN tunnel.
A real VPN requires native Android VpnService and a configured VPN backend/server.
