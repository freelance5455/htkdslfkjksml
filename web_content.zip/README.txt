FAMILY BUDGET KSA — ANDROID-FRIENDLY APP PROJECT (v3)

WHAT THIS IS
A complete offline-first web app project for managing a six-month family relocation budget in Saudi Arabia. This is source code in a ZIP archive, not a compiled APK.

FEATURES
- Overview of actual pocket balance, projected end balance, planned income and planned expenses
- Upcoming dated transactions and low-balance / cash-shortfall warnings
- Add, edit, update and delete any transaction
- Search and filter transactions
- Track planned and actual income/expenses separately
- Edit salary, monthly living costs, opening balance, alert buffer and family-stay dates
- Editable household resale estimates
- Forecast expected pocket balance across the family stay
- Export JSON backup, import JSON backup, and export transaction CSV
- Local device storage and installable PWA support when hosted over HTTPS

FILES
- index.html: app and UI
- manifest.json: install metadata
- sw.js: offline service worker
- icon.svg: app icon
- README.txt: project guide
- APK_BUILD_GUIDE.txt: build/conversion notes

HOW TO TEST
1. Extract the ZIP on a computer or phone.
2. Open index.html in a modern browser. Most app functions work, but offline installation requires HTTPS hosting.
3. Go to Transactions. Add an item, then tap Edit next to it. The form scrolls into view; change the amount/date/description and tap Update transaction.
4. Check the Overview and Forecast screens; totals should recalculate automatically.
5. Use Settings > Export backup before clearing browser data or changing devices.

IMPORTANT LIMITATIONS
- Data is stored locally in the browser on the device. It does not automatically sync between phones.
- Keep JSON backups regularly.
- This ZIP is not an APK. To produce an APK, it must be packaged by a suitable Android WebView/PWA wrapper or build service. Test the generated APK before relying on it.
- Seeded salary and living-cost figures are editable assumptions, not verified payroll data.
