BHUTOLA PANEL V4
Open index.html in your mobile web app builder or supported browser.
The Home page contains ESP BOX and ESP LINE switches with RGB styling.
Background music and the existing access screen are included.
