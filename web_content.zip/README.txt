Jully AI standalone HTML
Open index.html in a modern browser. Features carried from the supplied project:
- Chat history stored locally
- Groq + Google AI provider/model settings
- Image generation through Pollinations
- Image/file attachment UI; image input can be sent to Groq multimodal models
- Voice input + spoken replies
- Notes
- Themes
- PIN lock
- Stop/cancel generation
- Mobile responsive UI
- Local persistence

For Android APK wrapping, load index.html as the WebView start page. Browser-only APIs such as microphone/speech require the WebView/app to grant the relevant permissions and support them.
