CPR METRONOME - DRY WOODBLOCK VERSION

The audio loop is exactly 0.500 seconds long (48,000 Hz PCM, 24,000 samples).
It contains one identical short wooden "tok" click at the start of each loop.
The same sound repeats twice per second: 120 BPM. No alternating tick/tock,
no accent pattern, and no second-long loop.

Single green START / red STOP button.
No vibration, ads, analytics, external libraries or network requests.
HTML audio volume is set to 100%; actual loudness still depends on phone media
volume and speaker output. Test at a comfortable audible media volume.
