FIZAN APK STORE
===============
index.html  -> app UI (browser me khol kar bhi chala sakte hain)
android/    -> WebView Android project (index.html assets me bundled)
.github/    -> GitHub Actions: repo me push karo, Actions se app-debug.apk download karo

APK banane ke 2 tareeqe:
1) GitHub: poora folder repo me upload -> Actions -> Build APK -> Artifacts -> app-debug-apk
2) Android Studio: "android" folder open -> Build > Build APK(s)

App ke andar: ZIP/HTML import, editor + preview, project save/open, Download APK
(Settings me Build Server URL dein to APK direct download hoti hai).
