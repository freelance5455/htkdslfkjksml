CONNECTLY V2

Features:
- Email registration and login
- Username profiles and search
- Recent chats
- One-to-one messaging
- Group creation
- Real-time text messages
- Voice recording and playback
- Private voice-message storage

SETUP:
1. Run database-upgrade.sql in your Connectly Supabase SQL Editor.
2. Enable Email authentication in Supabase.
3. Rebuild the ZIP after the SQL migration succeeds.
4. Convert the ZIP using a web-app-compatible APK converter.
5. Allow microphone permission in the Android app.

Voice messages require microphone permission and HTTPS/WebView support.
This is an MVP, not a production-audited messaging service.
