# NutriScan V4.0 — by Shivansh Gairola

## Included in this ZIP
- Responsive installable-web-app (PWA) starter.
- Owner branding: Shivansh Gairola, User No. 1, free lifetime (policy display only).
- Pricing policy display: Users 2–20 ₹2,000 lifetime; User 21 onward ₹200 every 3 months.
- Special-date and seasonal promotional pricing display.
- Local meal journal with meal-photo preview.
- Barcode/QR camera scan where the browser supports the BarcodeDetector API.
- Barcode product lookup through Open Food Facts when online; database coverage varies.
- Local daily habit checklist and a 7-day workout log chart.
- Workout video preview and manual activity/duration log.
- Broad activity-based calorie estimate (generic reference estimate only).
- Discord community section where the owner can add an invite URL later.
- Local JSON backup and restore.
- PWA manifest and service worker.

## Important: what is and is not actually connected
This is a local-first prototype. It does NOT include a connected AI model.
- Meal photo recognition and automatic micronutrient analysis are NOT active. A photo preview is provided; users must enter ingredients/portions manually.
- Workout video pose analysis, exercise counting, form assessment and AI progressive-overload recommendations are NOT active. Video preview and a generic activity-based calorie estimate are provided.
- The workout calorie estimate is a rough reference calculation using a generic 60 kg reference, not an individual measurement or medical-grade result.
- Barcode lookup uses Open Food Facts over the internet. Product records may be missing or incomplete; QR contents are not always food nutrition data.
- Exact micronutrients are not guaranteed by the barcode lookup.
- There is no secure account system, cloud sync, globally counted user number, payment processing or automatic subscription enforcement.
- The displayed prices are policy information only. Do not collect payments based on this prototype.
- Owner status is a local profile label, not secure server-side administrator authentication.
- Local data stays in the browser on the device. Clearing browser data may erase it; export backups regularly.
- Do not use the app as medical advice. Nutrition and exercise estimates are approximate.

## Pricing policy shown
- User No. 1: Shivansh Gairola — Owner / Founder — free lifetime.
- Users 2–20: ₹2,000 one-time lifetime price.
- User 21 onward: ₹200 every 3 months.
- Special dates: ₹1,000 lifetime (17 July owner birthday; 23 June father's birthday; 26 January mother's birthday; 20 June parents' anniversary).
- Christmas, Halloween and Black Friday: ₹500–₹1,000 for one year.

Special pricing needs proper date validation, eligibility rules and secure backend implementation before public launch.

## How to test
1. Extract the ZIP.
2. Open `index.html` for basic local testing. Some camera, network and PWA features require HTTPS hosting.
3. For installation, host the folder on a secure HTTPS static host, then open the link in Chrome and choose Install app / Add to Home screen.
4. Camera use requires browser permission and HTTPS in most browsers.

## Files
- `index.html` — app interface and local functionality
- `manifest.webmanifest` — PWA installation metadata
- `sw.js` — static asset caching
- `icons/icon.svg` — app icon
