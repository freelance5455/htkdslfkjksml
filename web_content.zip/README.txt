PrintProfit V2 - Dashboard + Cadastro
========================================

Inclui:
- Tela de cadastro simples com nome do usuário
- Saudação personalizada: "Olá, [nome]"
- Nome salvo no armazenamento local do aparelho
- Opção para alterar o nome
- Dashboard completo
- Calculadora de preço
- Catálogo de filamentos
- Orçamentos
- Encomendas
- Sem emojis na interface

O cadastro é local: não exige e-mail, senha ou servidor. O nome fica salvo no próprio aparelho/navegador do aplicativo.
O index.html fica diretamente na raiz do ZIP para o conversor ZIP para APK.
