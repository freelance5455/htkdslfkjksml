KANONA FC ONLINE DEPLOY PACKAGE

Files:
- index.html: existing Kanona FC app with Supabase online news, fixtures, players and admin dashboard added.
- supabase_setup.sql: database tables, Row Level Security policies, admin allow-list and public club-media storage bucket.
- README.txt: setup checklist.

IMPORTANT
This package is prepared but is NOT yet a live website. It needs the SQL to be run and the web files to be hosted.

1. SUPABASE DATABASE
Open:
https://supabase.com/dashboard/project/blbowajktvnqwmdrlgbh/sql/new
Open supabase_setup.sql, copy all of its contents into the SQL editor and click Run.
The SQL grants write access only to the Auth user UUID included in the script.

2. AUTH ADMIN
In Supabase Dashboard > Authentication > Users, confirm the admin account you created has this user ID:
47b47f28-07ee-4760-a44e-b3bb51e72341
The email used for login should be your club admin email. Do not send anyone your password or a Supabase secret key.
If the UID is different, STOP before running the SQL and replace the UUID in the SQL with the correct Auth user ID.

3. HOST THE WEBSITE
Upload index.html to a static web host such as Netlify Drop or a GitHub repository with GitHub Pages enabled. The published site URL will be the link you share with fans. Do not share a file:// URL or the ZIP itself as the public website.
Netlify: https://app.netlify.com/drop
GitHub Pages guide: https://docs.github.com/en/pages/getting-started-with-github-pages

4. TEST
Open the deployed public URL in a private/incognito browser: the app should load and public database entries will appear after you add them.
Tap Admin Login, sign in with the Supabase Auth admin email/password, then use Manage News / Manage Fixtures / Manage Players to add content and optional photos.
Use only the publishable key in browser code. Never put a Supabase secret/service-role key in index.html.

SCOPE / NOTES
- The existing bundled app content and photos are preserved.
- Online news, fixtures and player records are stored in Supabase and shared with visitors.
- New photos upload to the public-read club-media bucket; only the configured admin can upload/update/delete.
- Existing preloaded content in the original HTML remains as existing app content; it is not automatically imported into the database.
- Lineups/ratings and the older local-only photo tools from the original app are not yet synced across devices.
