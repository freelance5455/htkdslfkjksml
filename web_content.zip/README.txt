CMSDHG Engineering

Offline browser calculator for diesel consumption, operating-time arithmetic, and general arithmetic. Diesel rate follows the selected method: convert minutes to decimal hours and round hours to 2 decimals, divide litres by those hours, then truncate the displayed rate to 2 decimals.

Engineering tools include single-/balanced-three-phase active-power calculations (kW, A or V, with power factor), electrical unit conversions (V, A, W/kW/MW, VA/kVA, resistance and energy), ACMV cooling-capacity and airflow conversions, gas volumetric-flow conversions, pressure conversions (including psi), and °C/°F conversion. Three-phase power assumes line-to-line voltage. Gas-flow conversion assumes the same gas temperature and pressure and does not normalize to Nm³/h/SCFM; pressure conversion does not change gauge pressure to absolute pressure.

The basic calculator keeps the latest 50 calculations in browser storage, lets you reuse a previous result, and includes Backspace, Clear Input and Clear History controls.

Open index.html in a modern web browser. No installation or internet connection is required. Electrical results are estimates and should not replace site-specific engineering checks.
