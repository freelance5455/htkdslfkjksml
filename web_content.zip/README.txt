MINHAS OBRAS — VERSÃO 3
Inclui:
- pagamentos parciais por obra e saldo em dívida
- despesas por obra e lucro estimado (contrato - despesas)
- datas de início e prazo final, agenda e alertas visuais de prazo vencido
- fichas de cliente com telefone, email, morada, NIF opcional e notas
- importação de anotações, relatórios e cópia de segurança JSON/CSV
- migração dos registos da versão anterior quando a chave antiga está disponível

IMPORTANTE:
- Os dados são guardados localmente no navegador/WebView. A cópia automática é local, não é cloud sync.
- Para sincronização na nuvem, é necessário configurar Firebase ou backend privado e autenticação.
- Testa a aplicação e faz exportação JSON antes de substituir o APK atual.
- Para Android APK, a página inicial deve ser incluída como index.html na raiz do pacote.
