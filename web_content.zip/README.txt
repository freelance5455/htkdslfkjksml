SHEEEDGE — ZIP FOR YOUR ZIP-TO-APK BUILDER

IMPORTANT:
- This ZIP is arranged for a ZIP-to-APK / HTML app builder.
- index.html is at the ROOT of the ZIP (not inside another folder).
- Upload this ZIP to the same builder workflow used for AspendosRecord.
- Choose APK as the output format, not AAB.
- Suggested app name: SheeEdge
- Suggested package name: com.shee.sheedge

The app stores records locally on the device using browser storage and is designed to work offline after it has been packaged and opened once. Use the upload/backup arrow at the top right to export a JSON backup. Long-press/right-click that arrow to choose a backup file to restore.

This is a source ZIP for the builder, NOT a finished APK. I have not verified a successful APK build or installation from your specific builder.

Current features:
- Dashboard and available balance
- Manual trade entry: asset, CALL/PUT, stake, win/loss/draw, total return, date/time, note
- Win profit = total returned minus stake; loss = stake deducted; draw = zero
- Deposits, withdrawals and adjustments are separate from trading P/L
- Monthly calendar with daily profit/loss
- Basic analysis by date range, asset and weekday
- Profit goals
- JSON backup and restore

No sample trades or fake balance are included.
