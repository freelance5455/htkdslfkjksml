Contractor Pro V18.2.0 — Smart Construction + Indian languages + Backend
Based on V18.0 (nothing removed). Development/QA build, not a production release.

NEW
- web/index.html: Hindi, Tamil, Telugu, Kannada, Marathi, Gujarati, Bengali (menus, modules, common labels; other text falls back to English); India + INR + GST + Kolkata time zone.
- AI Quick Estimate from text (offline): "280 m facade stone, 140 m ceramic ..." -> BOQ -> saved estimates; remembers your unit prices.
- server/: auth, 7-role RBAC, hash-chained audit log, offline sync + conflict resolution, license validation, AI gateway, PostgreSQL schema. See server/README.md.
- docs/ROADMAP-fa.md: status of every requirement (done / partial / not done).

NOT DONE (needs keys/services/time): payments, real email/push, SSO/SCIM, APK build + device QA, live PostgreSQL run, full UI translation.
