ZIP compatible avec un générateur ZIP → APK.
IMPORTANT : index.html est à la racine de l'archive.
Modules : Éleveurs, Produits/Médicaments, Rendez-vous.
Les données sont enregistrées localement sur le téléphone.
