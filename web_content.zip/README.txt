SkyHop v1.7.0

Deploy index.html and update.json together at the website root. Adaptive Liquid Glass styling follows the selected Light/Dark theme. APK updates still require a hosted APK URL, matching package name/signing key, and an incremented Android version code.
