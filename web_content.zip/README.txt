Maple AI Cognitive Engine build. Includes a local JavaScript dialogue/reasoning engine with intent handling, contextual follow-ups, common-topic knowledge, arithmetic, conversation-aware responses, and existing local tools. No paid API or external model is used. It is not equivalent to a large trained language model. Open index.html or package the ZIP with a ZIP-to-APK converter.


This version adds a mobile slide-out sidebar with new chat and saved conversation history. Conversations are stored locally in the browser/app storage.


UI fix: header is sticky at the top while the page scrolls; horizontal overflow clipping avoids creating a scrolling ancestor that interferes with sticky positioning.
