CHETAN CITY — 3D JALGAON PLAYABLE PROTOTYPE

This build is a self-contained WebGL 3D gameplay prototype.
- Landscape-first gameplay UI
- Virtual movement joystick
- Right-side camera drag
- Run button
- Third-person perspective camera
- 3D procedural houses, roads, trees, vehicles and NPCs
- Village selector with the 15 Jalgaon talukas and example villages supplied for the game plan

IMPORTANT:
This is a procedural 3D prototype, not a photorealistic 1:1 recreation of real Jalgaon.
It does not contain copyrighted GTA assets or real-world GPS geometry.
Open index.html in a modern WebGL browser (Chrome/Edge).
For best mobile controls, rotate the phone to landscape.
