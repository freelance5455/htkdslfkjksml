AS Metal Dyes & Nakas - Customer Shop App
1. Host index.html (any static host) or open it on the phone.
2. Staff app > Settings > Payments: set your UPI ID (GPay/PhonePe/Paytm). 
3. Staff app > Products: add products. Then Staff > Publish > download products.json and put it next to this index.html - customers get new products/prices automatically.
