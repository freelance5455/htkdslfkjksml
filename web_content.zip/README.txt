FONTORA — TYPE · STYLE · COPY

النشر على Netlify: اسحب مجلد الملفات كامل إلى app.netlify.com/drop
ثم افتح الرابط في كروم واضغط "إضافة إلى الشاشة الرئيسية" ليصير تطبيق.
لتحويله إلى APK: ارفع الرابط على pwabuilder.com واختر Android.

Deploy: drag this folder to app.netlify.com/drop, open the link in Chrome, then "Add to Home screen".
APK: use pwabuilder.com with the deployed URL.
