ShieldPath VPN — ApkForge HTML package

IMPORTANT:
This ZIP is designed for HTML/ZIP-to-APK tools that require index.html at the archive root.
It is a mobile UI preview only. A WebView wrapper cannot start Android's system-wide VPN tunnel by itself.

Included:
- index.html (single-file dark/neon-green mobile dashboard)
- README.txt

The Connect button explains the native VPN requirement; it does not fake a working VPN.
No analytics, CDN assets, or external network requests are included.

To use:
1. Upload this ZIP to ApkForge's HTML/ZIP-to-APK feature.
2. Choose app name "ShieldPath VPN".
3. Build it as a UI-preview APK.
4. Do not market or rely on this APK as a real VPN.
For the genuine VPN, continue the separate native Android/Kotlin + Android VpnService + WireGuard project and validate it on a physical phone with a configured server.
