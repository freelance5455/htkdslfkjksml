ELECTRICAL HUB INC Job Manager - Android Studio source project

This wraps the original CodePen HTML unchanged, using AndroidX WebViewAssetLoader to load it from a secure appassets HTTPS origin. It uses the existing Supabase project and requires internet access for login and data synchronization and for the Supabase JS CDN.

To compile: Open this folder in Android Studio, install requested SDK/build tools, then Build > Build APK(s). APK output: app/build/outputs/apk/debug/app-debug.apk. Do not publish a debug APK to an app store. Test sign-in, data loading, edits, and persistence on a real Android phone before relying on it.

No APK has been compiled in this environment. No Netlify or GitHub deployment is needed to compile this source project.
