ALPHA VEHICLE ANALYTICS – APKFORGE TEST BUILD

Upload Alpha_Vehicle_Test_App.zip to APKForge.

Test steps:
1. Build the APK and install it on your Android phone.
2. Open the app and enter password 2323.
3. Enter a date and vehicle count, then tap SAVE DATA.
4. Enter another date and save it.
5. Try to save the same date again: the app should block a duplicate.
6. Tap EDIT to change an existing date.
7. Tap DOWNLOAD PDF and check the phone Downloads folder.
8. If that does not work, tap PRINT / SAVE AS PDF and check whether the Android print dialog opens.
9. Test DOWNLOAD BACKUP and RESTORE BACKUP.

Important:
- This is a test build for checking APKForge WebView behavior.
- Data is stored locally in WebView localStorage. It can be lost if app data is cleared or the app is uninstalled.
- The direct PDF download depends on APKForge's WebView download support. If it fails, report the result; APKForge may need a native download bridge or file handling setting.
- The print-to-PDF method depends on APKForge allowing popups and Android printing.
- This is not yet the complete Vehicle Analytics app.
