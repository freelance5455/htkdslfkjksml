LDY CODE ACADEMY V2 — YACKUZA
=================================

Cette version est conçue pour être :
- uploadée telle quelle sur Netlify ;
- emballée dans une APK HTML/WebView ;
- utilisable hors-ligne pour le parcours, les quiz, la progression, le Code Lab et le coach IA local.

FICHIERS
--------
index.html
style.css
script.js

NOUVEAUTÉS
----------
1. Onboarding obligatoire au premier lancement :
   - niveau zéro / débutant / petite expérience
   - objectif site / application / jeu / exploration
2. Parcours progressif et non technique au départ.
3. YACKUZA AI :
   - coach local embarqué, utilisable sans serveur ;
   - contexte du niveau, objectif, XP et missions ;
   - architecture prête à appeler un endpoint IA distant via state.aiEndpoint.
4. Progression façon jeu :
   - XP, niveaux, séries de jours ;
   - forêt qui pousse avec les missions ;
   - avatar animé ;
   - missions et mini-quizz.
5. Code Lab conservé et amélioré.
6. Musique d'ambiance générée avec Web Audio :
   - aucun fichier audio externe obligatoire ;
   - l'utilisateur active la musique après interaction, ce qui respecte les restrictions mobiles.
7. YouTube et WhatsApp conservés.
8. localStorage pour la progression.

IMPORTANT — VRAIE IA DISTANTE
-----------------------------
Le navigateur/une APK HTML ne doit pas contenir une clé secrète d'API.
Le mode local fonctionne immédiatement.
Pour une vraie IA générative en ligne, configure un backend/proxy sécurisé qui accepte :
POST JSON { message, context }
et retourne :
{ "reply": "..." }

Puis définis state.aiEndpoint dans script.js ou ajoute un écran de configuration administrateur.

IMPORTANT — APK
---------------
Les fonctions locales ne dépendent pas d'un serveur :
- navigation
- onboarding
- progression
- quiz
- forêt
- Code Lab
- coach local
- musique Web Audio

Les liens YouTube/WhatsApp ont besoin d'Internet.
Une IA distante a besoin d'Internet et d'un endpoint.
