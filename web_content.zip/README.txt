Protocol Tracker v5.1 FINAL

ZIP→APK build based on the working v5.2 WebView file-input implementation.

Included:
- Dashboard / Makros / dynamische Ziele
- Ernährung: manuelle Eingabe + KI-Fotoanalyse
- Körperdaten: Waagenfoto-KI mit Übernahme
- Training / Labor / Auswertung
- Dosis & Rekonstruktion / Vorrat
- KI-Bilder
- OpenRouter Vision API
- Firebase Authentication / Firestore / Storage
- Cloud-Speichern und Cloud-Laden des strukturierten App-Zustands
- Export / Import
- Befinden-Modul entfernt
- Native simple <input type=file> preserved for ZIP→APK WebView compatibility
