AQUA Sales V5 – Produk Manual
Tambah, hapus, aktif/nonaktif, dan urutkan produk dengan tombol Naik/Turun. Data urutan tersimpan di localStorage dan ikut backup/restore.
