Contractor Pro V8.0.1 — APK READY PACKAGE

This ZIP is intentionally structured for HTML-to-APK/WebView tools that load:
appassets.androidplatform.net/web/index.html

Required structure:
web/index.html
web/manifest.json

Import this ZIP directly. Do not place the web folder inside another parent folder.

This is the frontend APK package. The backend architecture files are kept separately in the development package and are not needed by an offline HTML-to-APK wrapper.
