PURFFLE SHORTS - ZIP TO APK STARTER

This ZIP is a mobile-friendly web interface starter. It includes index.html at the archive root, which is what the ZIP-to-APK converter asks for.

HOW TO USE
1. Upload this ZIP to your ZIP-to-APK converter.
2. If asked, set the app name to Purffle Shorts.
3. Build the APK and test it on your phone.

IMPORTANT LIMITATIONS
This is a front-end demo. It generates a starter Tamil horror script and visual prompts in the browser. It does not generate actual AI images, voice audio, or MP4 video yet. Those features require a backend and/or external AI services. The original Python ZIP is not embedded or converted by this starter.
