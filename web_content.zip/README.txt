STUDY BUDDY — COMPLETE WEBSITE STARTER
======================================

ROOT FILE
---------
index.html is placed at the top level of the ZIP archive.

FILES
-----
index.html  Main HTML page
style.css   Responsive layout and visual design
app.js      App features, sample content and local storage
README.txt  Setup instructions and limitations

RUN ON ANDROID (PHONE ONLY)
---------------------------
1. Download and extract study_buddy_complete.zip using your Android file manager.
2. Open the extracted study_buddy folder.
3. Open index.html in Chrome, or use an Android code editor with a live preview.
4. For best results, use a local preview server provided by your code editor.
5. Keep index.html, style.css and app.js in the same folder.

FEATURES INCLUDED
-----------------
- Class 10, +1 and +2 profile selection
- Tamil Nadu State Board, CBSE and Other board profile options
- Science, Commerce, Humanities, Vocational and Class 10 group categories
- Group-combination selection data, including Mathematics combinations
- English, Tamil and Malayalam interface options (core navigation translations)
- Subject dashboard and dedicated Mathematics hub
- Class 11 and Class 12 Mathematics chapter index
- Five-question sample quiz with feedback
- Personal notes saved in browser local storage
- Study planner with completion tracking
- Dark mode
- Official Tamil Nadu textbook and DGE links
- Responsive mobile layout

IMPORTANT CONTENT AND INTEGRATION NOTES
---------------------------------------
This is a functional front-end starter project, not a fully populated commercial
learning platform. Sample quiz questions and chapter navigation are included.
Subject-specific lessons, complete textbook content, all official group codes,
verified previous-year question papers and full translations must be added and
checked against the current academic-year Tamil Nadu State Board materials.

The group catalogue is a starter reference. Group availability can vary by school
and academic year. Confirm the exact code and subject combination with the school
or official Tamil Nadu authorities before publishing it as an authoritative list.

AI tutoring is not connected in this ZIP. A secure backend and an AI API integration
are needed. Do not place a private API key in app.js or any browser-side file.
For real student accounts and cloud sync, add a backend/database and appropriate
privacy protections. Current notes, profile and tasks are stored only in this browser.

LANGUAGE NOTE
-------------
The app provides English, Tamil and Malayalam navigation translations. Full lesson,
question, explanation and textbook translation content is not included yet.

OFFICIAL STARTING POINTS
------------------------
Tamil Nadu Textbooks: https://textbooksonline.tn.nic.in/
Directorate of Government Examinations: https://dge.tn.gov.in/

LICENSE / CONTENT
-----------------
Use original or properly licensed educational content. Do not redistribute copyrighted
textbooks or paid guide content without permission.
