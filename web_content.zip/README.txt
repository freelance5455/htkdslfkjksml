SPRM Rice Mill - HTML to APK converter package

Upload this ZIP to an HTML-to-APK builder. It contains index.html at the ZIP root, with app.js and styles.css beside it. It uses a classic script, not an ES module, for WebView converter compatibility.

Backup exports a JSON file; save it to Google Drive manually.

IMPORTANT: This is a development build. Test with dummy data before live use. Complete rice/bran/husk production-yield accounting, full GST logic, and automatic Google Drive sync are not implemented. Local records may be lost if app data is cleared or the app is uninstalled. Export backups regularly.
