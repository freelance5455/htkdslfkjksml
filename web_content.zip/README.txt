Radwan × Nasibah — ZIP to APK
--------------------------------
Upload this ZIP to a ZIP-to-APK web builder.

The entry point is:
index.html

The game is HTML/CSS/JavaScript and is designed for mobile screens.
No Flutter, Node.js, or build tools are required for the web version.
