Saif World 360° — Offline HTML package

Files:
- index.html : the app interface and logic in one file.

Important:
This HTML file has no external JavaScript/CSS library dependency. It should be bundled inside the APK as a local asset, not loaded from an expired or unavailable website URL.

If you use a Website-to-APK builder:
1. Choose the option to load a local HTML file / upload website files, if supported.
2. Upload index.html as the start page (index.html).
3. Do NOT set the start URL to an old/temporary preview URL.
4. Build/export a new APK and install that newly built APK.
5. If the builder only accepts a public website URL, upload the HTML to a stable HTTPS host first; this cannot be fixed by replacing the APK's HTML alone.

For Android Studio WebView, put index.html in:
app/src/main/assets/index.html
and load it with:
webView.loadUrl("file:///android_asset/index.html");

Data note:
The app stores data in browser/WebView localStorage. Removing app data or reinstalling the app may remove locally stored information.
