Protocol Tracker v5.1 – ZIP→APK
Startdatei: web/index.html
Zusätzlich vorhanden: www/index.html und index.html
Enthält KI-Auswertung für Waagenbilder in Körperdaten.
