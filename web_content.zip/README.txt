ChartLearn Live — APKForge-friendly educational demo

Features:
- Live public price-history data from CoinGecko API (internet required)
- Asset selector: Bitcoin, Ethereum, Solana, Dogecoin
- 1 day / 7 day / 30 day historical price chart
- Price change, last data timestamp, high/low and point count
- Educational candlestick-pattern notes

Important:
- This is not a DracoTrade clone and does not contain its proprietary code/assets.
- No future price prediction, UP/DOWN trading signals, Quotex/broker connection, login, payment, or auto-trading.
- Market data availability and update frequency depend on the public API and network.
- Do not use this educational demo as financial advice.

APKForge:
1. Extract this ZIP.
2. Import index.html as the app's start page / HTML project.
3. Ensure internet access is enabled for the WebView/app.
4. Build the APK. API requests need internet access.
