TechYolo Upload + Reel + Live Demo

Added:
- Upload Video
- Upload Reel
- Local video preview
- Feed cards
- Go Live demo

The videos are currently local only; they are NOT uploaded online.
Real online uploads and livestreaming require a backend/server, authentication, storage, moderation, reporting/blocking and privacy controls.
