ALPHA LOAN TRACKER — APKForge ZIP

1. Upload this ZIP to APKForge using its HTML/ZIP import option.
2. Set the app title to ALPHA LOAN TRACKER.
3. Set index.html as the start/home page if APKForge asks.
4. Build and install the APK.

Included:
- Sinhala-first loan and people management UI
- Loan records with date and notes
- Installment/payment history
- Offline localStorage data
- JSON backup/restore and CSV report
- Black/deep-red theme
- Monthly 10% interest estimate based on the remaining principal balance

IMPORTANT CALCULATION NOTE:
This starter version calculates and displays 10% of the current outstanding principal as a one-month interest estimate. It does not yet accrue interest automatically by elapsed calendar months, nor split each payment between interest and principal. The payment entry currently reduces principal by the payment amount. Confirm the desired repayment allocation and date-based interest rules before using it for real accounting.

Data is stored locally in the app's WebView storage. Export a JSON backup before clearing app data or uninstalling.
