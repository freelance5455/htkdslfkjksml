EHM21 — proyecto HTML listo para HTML to APK Builder

Archivos principales:
- index.html
- style.css
- app.js

Importante:
index.html está en la raíz del ZIP.

Funciones:
- Ingreso del día y registro de historial
- Total acumulado
- Objetivo del día 21
- Alquiler, tarjeta, monotributo, combustible, comida y ahorro
- Dinero disponible
- Progreso hacia el objetivo
- Configuración para activar/desactivar módulos
- Pantalla de acceso mediante PIN opcional
- Tema oscuro moderno / tema claro
- Cambio de nombre y moneda
- Reseteo completo de cuenta
- Guardado local en el dispositivo
