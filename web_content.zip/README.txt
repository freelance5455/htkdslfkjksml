My Group D Study V25 - video fix project

Fixed: Video Classes now shows Maths, Reasoning, Science and GK teachers, embedded player and YouTube fallback link.
Existing native password dialog preserved: set password on first launch and enter it on each new app launch.

Limitations: This is Android source, NOT a compiled APK. YouTube needs internet; videos may be restricted from embedding. LIVE push notifications and background automatic class discovery are NOT implemented. No guarantees of error-free operation.

To build: open this Gradle Android project in Android Studio or another Android Gradle build service, compileSdk 35.

V25 UPDATE: LIVE search links for four subjects, a daily 7 PM local study reminder (subject to Android notification permission/battery settings), and preserved offline bundled website/password lock. These are NOT automatic real-time LIVE alerts. The Android app must be compiled; no APK is included. Videos need internet and may be restricted by YouTube.
