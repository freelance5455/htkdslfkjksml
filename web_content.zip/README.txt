APP: Subway Surfers - Painel Fake

Fluxo:
1. Mostra a capa enviada pelo usuário.
2. Tela azul.
3. Botão "ABRIR PAINEL DO FREE FIRE".
4. Painel visual fake com AIMBOT, FULL CAPA, ATRAVESSAR BARREIRA, SPIN e FOV 0-100.
5. "APLICAR TUDO" abre o vídeo.

O painel é apenas visual: não modifica nem interage com Free Fire.

Para usar o vídeo final, coloque um arquivo chamado:
video.mp4
na mesma pasta de index.html.
