Quotex Signal Assistant - 1-minute Android-friendly prototype

This is an HTML prototype, NOT an APK and NOT an official Quotex app.
It does not fetch live market data, connect to Quotex, or execute trades.
Signal logic is simple illustrative rules based on manually entered RSI, EMA relationship, trend, and last completed candle. It is not a trained AI model and does not predict candles reliably.

Test:
- Extract ZIP and open index.html in a browser.
- To use from Android as an installed web app, host index.html on a trusted HTTPS static host, open it in Chrome, then use menu > Add to Home screen / Install app if available.
- A real APK requires a separate Android packaging/build process.
- Never provide Quotex credentials, password, or OTP to unofficial tools.
