IMPORTANTE:
Esta versión NO usa appassets.androidplatform.net.
El WebView abre directamente:
file:///android_asset/index.html

Si el APK muestra una URL appassets.androidplatform.net/web/index.html, estás instalando/compilando una versión anterior. Eliminá esa versión y compilá este proyecto nuevo.
