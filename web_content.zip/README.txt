AERORE website ZIP for HTML-to-APK builders

IMPORTANT: The ZIP contains a static local preview with a working demo sign-in screen, theme switch, and local-only chat preview. It does NOT connect to global accounts or live messaging. Those require configuring the AERORE backend separately.

For HTML to APK:
1. Select this ZIP in ZIP File to APK.
2. Tap Preview first.
3. If the preview displays AERORE, tap Create App.
4. Install the new APK and test it.

Keep index.html at the ZIP root. Do not zip the parent folder itself.
