NEUBURG WINTER DASHBOARD – KOMBINIERTE APP

IMPORT:
1. ZIP-Datei auf dem Android-Handy speichern.
2. APK Forge öffnen.
3. "Gezippte Website" auswählen.
4. Diese ZIP-Datei importieren.
5. Vorschau testen und anschließend die APK erstellen.

DATEIEN:
- index.html: kompletter, scrollbarerer Seitenaufbau
- style.css: Winter-Design, Karten, Hintergrund und Schneeeffekt
- script.js: Live-Uhr, Wetterdaten, Schneeprognose, Silvester-Countdown,
  Wetter-Szene, Tagesübersicht und zufällige Winter-Aktivitäten
- assets/winter-background.png: winterlicher Hintergrund

WETTER:
- Standort ist auf Neuburg an der Donau eingestellt.
- Wetterdaten kommen live von Open-Meteo und benötigen Internet.
- Schneewahrscheinlichkeit wird vereinfacht aus der Stundenprognose abgeleitet.
- Neuschnee, Dauer und Temperatur beim nächsten Schneefall sind Schätzungen
  aus den stündlichen Modellwerten und keine Garantie.
- Die Wetter-Vorschau wechselt passend zum aktuellen Wettercode zwischen
  Schnee-, Regen-, Wolken- und Sonnendarstellung.
- Für amtliche Warnungen bitte den Deutschen Wetterdienst (DWD) prüfen.

HINWEIS:
Diese ZIP ist ein Web-App-Projekt. Die APK-Erstellung und eventuelle
Berechtigungs-/Internet-Einstellungen hängen von deiner APK-Forge-Version ab.
