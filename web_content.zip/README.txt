Deshi Code
index.html = full app (single file, logos embedded).
Open in Chrome/Safari, or upload as index.html to any web host.
