SEATED ENTERPRISE POS — CLEAN RETAIL PWA

Modules included:
Dashboard, POS / Checkout, Sales, Products, Inventory, Purchases, Customers, Suppliers, Expenses, Reports, Users, Settings & Backup.

CLEAN START
No demo products, demo sales, purchases, expenses, customers or suppliers are preloaded. The app uses a fresh browser-storage key so the old demo records will not automatically appear in this version.

OWNER LOGIN
Username: admin
Password: admin123
The password is not displayed or prefilled on the login screen. Change the initial password before operational use.

USER MANAGEMENT
The owner can create, enable, disable and delete staff accounts from Users. The owner account cannot be deleted or disabled. Available role labels: Owner, Manager, Cashier, Stock Clerk. In this prototype, only access to the Users screen is restricted to Owner; detailed per-module permissions are not yet implemented.

OWNER CONTACTS
0758 485 092
0791 213 660

IMPORTANT SECURITY / STORAGE LIMITATION
This is a browser-local prototype. Business data and staff credentials are stored in local browser storage. User accounts do not synchronize between devices, and this is not secure server-side authentication. Do not use it for sensitive production financial data until server-side authentication, database storage, and permission enforcement are implemented.

PWA DEPLOYMENT
Upload the contents of this folder to an HTTPS static host. Keep index.html, manifest.webmanifest, sw.js and icons together. After deployment, open the HTTPS address in Chrome and choose Install app / Add to Home screen. The service worker caches the app shell for offline reopening after the first successful online visit.

BACKUPS
Use Settings > Download full backup regularly. Keep backup files somewhere other than the same phone/browser. Restoring replaces current local records.
