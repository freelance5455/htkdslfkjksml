Transora - HTML/CSS/JS

A lightweight offline translator interface designed for mobile use.

Brand: Transora
Copyright: © Yousef Osama

Supported UI languages:
Arabic, English, French, Spanish, German, Chinese, Korean, Japanese, Russian.

The project works directly from index.html and does not require a server.
Translation is local and dictionary-based; it does not provide unrestricted machine translation while offline.

Performance:
- No gradients, glassmorphism, backdrop blur, particles, or continuous animations.
- Only small transform/opacity transitions are used.
- Reduced-motion preferences are respected.
- Minimal DOM and lightweight JavaScript.
