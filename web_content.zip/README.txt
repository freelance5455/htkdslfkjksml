M Alhaisam Customer Service
Logo update:
- Uses the user's supplied M ALHAISAM CUSTOMER SERVICE logo.
- Animated splash screen when the app opens.
- Logo zoom/rotate entrance + glow effect.
- Brand name fades in below the logo.
- Existing billing, products, receipts, reports and other features are retained.
- No stock management.
