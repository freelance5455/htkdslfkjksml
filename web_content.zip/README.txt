MG4 POS with Email Backup

Open index.html in a browser or import this ZIP into an HTML-to-APK builder.
The Backup tab is available to the owner after PIN login.
On Android, tap Backup > Hifadhi na tuma backup kwa email, then choose Gmail from the share menu.
If file sharing is unavailable, the JSON backup downloads and an email draft opens; attach the downloaded JSON file manually.
Owner and staff PINs are excluded from the backup for security.
