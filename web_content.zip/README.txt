SALATY V2
Features: prayer times, countdown, notifications while app/runtime is active, morning/evening adhkar, tasbeeh counter, qibla compass, settings.
Prayer times use AlAdhan API method 5 (Egyptian General Authority of Survey).
IMPORTANT: browser/PWA notifications are not guaranteed to fire after Android fully suspends the WebView. For guaranteed alarm/adhan while the app is closed, we should build a native Android V3.
