BX Trading App — Prototype v0.2
- Mobile-first web UI.
- Attempts to fetch public quote data for XAUUSD, EURUSD, GBPUSD and USDJPY from biquote.io every 30 seconds.
- This public feed is not OctaFX data and is not a guaranteed executable price feed. Browser/network/CORS/provider issues may make quotes unavailable.
- Chart is illustrative, not a real candle chart.
- BUY/SELL only records a local demo preview; it does NOT place real orders.
- No broker login, password, or API key is included.
To use: open index.html in a modern browser with internet access. For APK packaging, use a trusted wrapper that accepts HTML assets, inspect permissions, and test before installing. This ZIP is not itself an APK.
