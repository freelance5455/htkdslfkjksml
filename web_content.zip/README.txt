TPH X — COMPLETE PRIVATE SEARCH APP
==================================

TAGLINE: PRIVATE SEARCH. YOUR RULES.

This package contains the fully functional, deployment-ready frontend asset pipeline for TPH X, designed to operate optimally within mobile standalone windows and Android System WebView targets.

FILES CONTAINED:
----------------
1. index.html          - Semantic core structural components and view nodes.
2. styles.css          - Presentation layer containing the dark palette (#090909) and neon accents (#22f000).
3. app.js              - JavaScript core handling browser queries, state isolation, and LocalStorage file manipulation.
4. manifest.webmanifest- Progressive Web App configurations for native application wrappers.
5. icon.svg            - Custom identity vector layout asset.

NATIVE ANDROID DEPLOYMENT NOTES:
--------------------------------
When using standard wrappers (like Android Studio WebView templates, Capacitor, Cordova, or online builders like Website 2 APK Builder):
1. Set JavascriptEnabled = true in your WebSettings instance.
2. Allow DomStorageEnabled = true to support the local document index storage layers.
3. Configure target links to open within system activity intents or external default browsers if separate container breakout routing is desired.
