NEONAI — WORKING CHATGPT-STYLE WEB APP
========================================

This package contains a real AI chat frontend + backend. It does NOT fake answers.

REQUIREMENTS
- Node.js 18+
- An OpenAI API key (the key stays on the server; never put it in index.html)

RUN
1. Open a terminal in this folder.
2. npm install
3. Set your API key:
   Windows PowerShell:
     $env:OPENAI_API_KEY="YOUR_KEY"
   macOS/Linux:
     export OPENAI_API_KEY="YOUR_KEY"
4. npm start
5. Open http://localhost:3000

OPTIONAL MODEL
Set OPENAI_MODEL to a model available to your API account.

IMPORTANT
A truly AI-powered ChatGPT-like app requires access to an AI model/API. The ZIP cannot contain a private API key for security reasons.
