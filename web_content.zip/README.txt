مغامرات البطل الصغير - لعبة منصات 8-bit بالعرض (Landscape)
=========================================================
التحكم: ذراع على الشاشة بشكل ذراع PlayStation
  اتجاهات (D-Pad) يسار | ✕ و △ = قفز | □ و ○ = جري | START = إيقاف/بدء
  يدعم أيضًا: كيبورد (أسهم + Z قفز + X جري) وذراع PS/Xbox متصل بالبلوتوث.

التحويل إلى APK:
1) الأسهل: ارفع الـ ZIP على WebIntoApp.com أو Median.co أو AppsGeyser واختر الاتجاه Landscape.
2) Capacitor:
   npm init -y && npm i @capacitor/core @capacitor/cli @capacitor/android
   npx cap init HeroGame com.example.hero --web-dir=.
   npx cap add android && npx cap sync && npx cap open android
   ثم في AndroidManifest.xml أضف للـ activity:  android:screenOrientation="sensorLandscape"
3) Android Studio WebView: ضع index.html في assets وحمّله بـ file:///android_asset/index.html
