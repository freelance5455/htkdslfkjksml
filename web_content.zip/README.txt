MemeMoz — versão para conversor ZIP → APK

1. Escolha este ZIP no aplicativo "HTML para App".
2. O ZIP contém index.html na raiz.
3. Nome do app: MemeMoz.
4. Se o conversor pedir um package name: com.mememoz.app
5. Se pedir para visualizar antes de compilar, visualize e depois volte para a tela de criação.

Esta versão remove a categoria de namoro para evitar classificação indevida pelo conversor.
