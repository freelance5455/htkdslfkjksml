STUDENT QR ID APP

Files:
- index.html: the complete app

How to use:
1. Extract the ZIP file.
2. Open index.html in Chrome or Edge while connected to the internet (the QR/scanner libraries load from CDNs).
3. Go to Generate QR, enter the student's name, student number, and section, then press Generate QR Code.
4. Press Download QR PNG to save the QR code.
5. Open Scanner and press Start Camera Scanner. Camera scanning generally requires HTTPS or localhost and camera permission.

Notes:
- This is a simple demo for a school project, not a secure official student database.
- QR code data contains the name, student number, and section entered.
- Do not encode private or sensitive information.
