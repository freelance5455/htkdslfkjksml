JC GROCERIES — MODERN EDITION

Files:
- index.html: the offline-first shop management app
- icon.png: JC Groceries app icon

HOW TO USE ON ANDROID (ACODE):
1. Extract the ZIP into a folder.
2. Open the folder in Acode.
3. Open index.html and preview it in a browser.
4. Keep icon.png in the same folder as index.html.

Data is saved in the browser's local storage on that device. Use Shop settings > Download data backup regularly. Browser private/incognito sessions may not retain data. This app does not sync data between devices.

Currency note: USD and ZWG records are kept separately; the app does not convert between currencies. For accurate profit, record each sale in the product's selling currency and purchases in the product's cost currency.
