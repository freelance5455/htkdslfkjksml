Lork — Starter prototype
========================

This is a mobile-friendly HTML prototype for the Lork social gaming app.

Included:
- Arabic RTL interface
- Home, rooms, games, friends, profile screens
- Local demo room and friend creation
- Local two-player XO game

Not included yet:
- Real accounts/authentication
- Internet-connected friends or private invite enforcement
- Live voice rooms / microphone streaming
- Multiplayer games across devices
- Android APK package

How to preview:
1. Extract the ZIP on your phone.
2. Open index.html in a browser if your file manager supports it.
3. For a better experience, host the folder on a static hosting service.

Important:
This is a working visual prototype, not a finished secure online app or APK.
Real private rooms require backend authentication and access rules. Voice chat requires a WebRTC/voice service and server-side room permissions.
