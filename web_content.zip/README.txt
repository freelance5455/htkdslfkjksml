Sri Krishna Interior - Final Attendance System

Attendance options:
- Present – 1
- Present – 1.5
- Present – 2
- Absent / छुट्टी (amount ₹0)

Also includes worker full-record search, site, expenses, reports, WhatsApp and Send buttons, backup/restore.

For Android WebView packaging, place index.html in app/src/main/assets/ and load:
https://appassets.androidplatform.net/assets/index.html
using WebViewAssetLoader.
