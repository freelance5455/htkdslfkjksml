HUBBY & WIFEY — REBUILD PACKAGE
Contains a single offline HTML app with seven distinct interactive modes:
roulette wheel animation, selectable flip cards, animated dice, surprise reveal,
mystery envelope, couple's choice, and random combo. Each mode reveals a scenario
with category, illustration emoji, description, and safety/preparation notes.

IMPORTANT:
- This is a WebView/HTML app package, not a native Kotlin APK.
- PIN is a local app gate, not strong device-bound encryption.
- An APK builder may sign/package this differently; upgrading over an existing APK
  may fail if its signing key/package ID differs.
- Keep the current installed app until the new APK is confirmed working.
