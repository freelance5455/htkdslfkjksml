Bayt al-Hikmah | Islamic Personal Library

Files: index.html, manifest.webmanifest, sw.js, share-target.html, icon-192.png, icon-512.png

Incoming book sharing: manifest share_target accepts PDF, EPUB, TXT files. The service worker stores shared files in IndexedDB, then the app imports them into the library.

Important: Web Share Target works only in supported installed PWAs served from HTTPS (or localhost for development). A plain HTML file opened from file:// will not appear in Android Share. Many generic APK/WebView builders do not implement Android's native share target; for APK support, the wrapper must explicitly handle ACTION_SEND/ACTION_SEND_MULTIPLE and pass received file URIs into the web app. Test on the target phone. External fonts and EPUB reader still need internet unless bundled locally.
