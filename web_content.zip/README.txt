NOVA AI CON IA REAL — PROYECTO ANDROID

Este ZIP es un proyecto Android Studio, no un APK ya compilado.
La app usa OpenRouter con el modelo enrutador openrouter/free. Necesita internet y una clave API propia.
Los modelos gratuitos tienen límites y pueden no estar disponibles siempre.

PASOS:
1. Entra en https://openrouter.ai/ y crea una cuenta.
2. Genera una API key en la sección de claves: https://openrouter.ai/keys
3. Abre este proyecto en Android Studio y espera la sincronización de Gradle.
4. Compila con Build > Build APK(s).
5. Instala el APK en tu Android.
6. En Nova AI toca "Configurar conexión", pega tu clave y envíala. La clave se guarda en las preferencias privadas de esta instalación.
7. Asegúrate de tener internet y prueba una pregunta.

SEGURIDAD:
- No compartas tu clave API ni publiques capturas donde se vea.
- La clave se guarda localmente en el teléfono, pero una app APK no es el lugar más seguro para una clave. Para publicar la app para más personas, usa un servidor propio que proteja la clave.
- OpenRouter y sus modelos gratuitos tienen límites de uso y disponibilidad; "gratis" no significa ilimitado.
- Las consultas se envían al proveedor/modelo elegido para generar respuestas. No envíes datos sensibles.

Si aparece error HTTP 401, revisa la clave. Si aparece 429, puede que hayas alcanzado el límite. Si aparece un error de conexión, revisa internet.
