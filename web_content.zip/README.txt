# رنگوں کی دنیا — ZIP to APK ویب ایپ

یہ ایک مکمل offline-friendly HTML/CSS/JavaScript ایپ ہے۔ اسے ایسے ZIP-to-APK / WebView APK converter میں استعمال کیا جا سکتا ہے جو `index.html` کو entry page بناتا ہو۔

## فائلیں
- index.html — ایپ کا مرکزی صفحہ
- style.css — موبائل/ڈیسک ٹاپ ڈیزائن
- app.js — تمام رنگ، سیکشن، سرچ، کمبینیشن، گیم اور رنگ لیب
- manifest.json — PWA معلومات
- sw.js — بنیادی offline cache

## استعمال
1. ZIP کو unzip کریں یا converter میں ZIP upload کریں۔
2. اگر converter پوچھے تو Start/Entry file = `index.html` منتخب کریں۔
3. App name = `رنگوں کی دنیا` رکھیں۔
4. RTL/Urdu سپورٹ برقرار رکھیں۔
5. APK بنا کر Android پر انسٹال کریں۔

## اہم نوٹ
'دنیا کے تمام رنگ' ریاضیاتی طور پر محدود فہرست نہیں ہے، کیونکہ RGB/HEX میں لاکھوں ممکنہ رنگ بن سکتے ہیں۔ اس ورژن میں وسیع بنیادی palette، متعدد categories، shade families اور custom color lab دی گئی ہے، جہاں آپ ہر HEX رنگ دیکھ/محفوظ کر سکتے ہیں۔
