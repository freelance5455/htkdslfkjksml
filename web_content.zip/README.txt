HARDPANEL PRO — ZIPtoAPK WEB APP SOURCE
======================================

This archive is intended for ZIPtoAPK's HTML/CSS/JavaScript website-to-APK builder.
The archive root contains index.html. Do not move it into another folder before uploading.

APP DETAILS
-----------
Name: HardPanel Pro
Package ID suggestion: com.hardday.hardpanel
Version: 1.0.0
Theme: Black / red / cream

FEATURES
--------
- Mobile-first dashboard
- Add, edit, delete and favorite Minecraft Java servers
- Minecraft Java status through McQuery public API: online state, player count,
  max players, version and MOTD
- Server status history stored in localStorage
- Five-sample API response-time chart (6 seconds between samples)
- DNS A/AAAA lookup through Cloudflare DNS-over-HTTPS
- Website availability check through AllOrigins public fetch proxy
- Approximate download speed test through Cloudflare speed test endpoint
- Export local data as JSON

IMPORTANT TECHNICAL LIMITS
--------------------------
This is a WebView/browser app, not a native Android app.
Browsers do not expose arbitrary ICMP ping or raw TCP sockets to page JavaScript.
The graph therefore measures phone-to-McQuery-API HTTP response time (API RTT),
not direct ICMP latency from the phone to the Minecraft host. If a status source
provides a server latency value, it can be displayed separately.

WebView JavaScript cannot guarantee periodic execution after the app is closed.
Background monitoring, Android system widgets, raw TCP port checks and native
notifications require a native Android implementation.

NETWORK SERVICES
----------------
Minecraft status: https://api.mcquery.net/java
DNS: https://cloudflare-dns.com/dns-query
HTTP check proxy: https://api.allorigins.win/raw
Download test: https://speed.cloudflare.com/__down

The app does not connect to RCON, a hosting panel, a private API or any server plugin.
Server list and history stay in the app's local browser storage. Network checks
send the requested public host/domain to the named third-party service.

UPLOAD
------
Upload this ZIP as-is to ZIPtoAPK. It is a web project archive, not an Android
Studio/Gradle project. Keep the suggested package name stable if you later
rebuild and want Android to treat the APK as an update.
