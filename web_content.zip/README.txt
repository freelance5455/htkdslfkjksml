THE BUDGET TANK — DOWNLOADABLE APP PACKAGE

Included:
- index.html: the budget tracker app
- manifest.json and icon.svg: installable web-app metadata and icon

HOW TO USE
1. Extract the ZIP file.
2. Open index.html in a modern browser.
3. Your budget data is saved in that browser on that device. Use Settings & backup to download a backup JSON file and restore it later.
4. Export CSV to keep a spreadsheet of transactions.

IMPORTANT
This package works as a browser app. Installing it as a proper home-screen PWA usually requires hosting these files on an HTTPS website; opening a local HTML file alone may not show an install option. This is not yet an Android APK or a Play Store release.
