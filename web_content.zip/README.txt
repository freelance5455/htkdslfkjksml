SUPERSTAR CHILD CLUB OFFLINE APP
Files: index.html, manifest.json, sw.js.
Features: members, NPR money ledger and balance, meetings, upcoming events,
photos/files, activities, certificates, official documents, dashboard,
backup/restore. No member accounts. Data is stored locally.
Use Export SCC Backup regularly. For true Android APK installation, this
web app can be wrapped into an APK using a WebView/Trusted Web Activity.
