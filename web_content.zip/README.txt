AURA INFINITA — WEB GAMING HUB
================================

ESTE ZIP ES UNA WEB, NO UN PROYECTO JAVA.

Cómo abrir:
1. Descarga el ZIP y descomprímelo.
2. Abre la carpeta.
3. Pulsa sobre index.html. En Android, elige Chrome u otro navegador.
4. Para publicarla como web, sube los archivos a un alojamiento estático (por ejemplo GitHub Pages o Netlify).

Qué incluye:
- Interfaz responsive inspirada en consolas, con neón y mando ilustrado con CSS.
- Catálogo de 30 sistemas, filtros y buscador.
- Favoritos guardados en el navegador.
- Ventana de detalles por sistema.
- Selector de archivos locales; no sube archivos a Internet.
- Accesos que intentan lanzar apps compatibles en Android.
- Botón Spotify.
- No redirige a páginas de descarga ni incluye ROMs o juegos.

Limitaciones importantes:
- Un archivo HTML no puede instalar aplicaciones ni ejecutar emuladores dentro del navegador.
- La apertura de otras apps depende del navegador, Android y la app instalada; los accesos directos no funcionan en todos los móviles.
- Seleccionar un ISO/CSO en la web no lo ejecuta por sí mismo. Abre el archivo desde el emulador compatible.
- No incluye juegos, BIOS ni emuladores.
- El archivo usa Google Fonts si hay conexión; con Internet desactivado se mostrarán fuentes alternativas.
