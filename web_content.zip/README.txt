Pharma Order Booker
Online database version

Files:
- index.html          Mobile app
- supabase_setup.sql  Database + security policies
- SUPABASE_SETUP.txt  Mobile-friendly setup instructions
- README.txt          This file

Brand:
Developed by Rais Umair

The HTML uses the official Supabase JavaScript CDN.
