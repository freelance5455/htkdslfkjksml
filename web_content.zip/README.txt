LIVE MICE SHAKIL — AppsGeyser real local audio test

Upload this ZIP in AppsGeyser's ZIP template. index.html is at the ZIP root.

This version uses Web Audio API to process microphone audio locally (EQ, gain, compressor, distortion, delay/echo, and reverb). It asks for microphone permission. Use headphones to prevent feedback.

Important limitation: AppsGeyser creates a WebView APK. Android does not normally let one app replace the microphone audio of a separate app such as Messenger. This ZIP therefore does NOT guarantee processed voice in a separate Web Messenger call. Testing local effects is possible; routing processed audio into another app requires a separate supported Android audio-routing/virtual microphone implementation, which AppsGeyser ZIP alone cannot provide.
