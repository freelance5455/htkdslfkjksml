FindBack India Firebase starter ZIP

Includes index.html with Firebase email/password sign-in, lost/found reports, City and State fields, Firestore saving in collection 'reports', and live report updates for signed-in users.

Before testing:
1. Enable Email/Password in Firebase Authentication.
2. Publish Firestore rules matching fields userId, type, itemName, description, city, state, status, createdAt.
3. Rules must allow signed-in users to read reports and create their own. Any signed-in user can read report details under the earlier rules, so never enter private information.
4. This is a WEB APP ZIP, not an APK. Import it using a builder's HTML/website ZIP option, or host it and package it using a suitable Android WebView builder.
5. It does not include background push notifications, photo uploads, owner verification, or advanced matching.
6. Test with sample details only. Do not publish phone numbers, addresses, ID numbers, passwords, or OTPs. Use a trusted adult or staff member for item handovers.

If the builder says index.html is missing, make sure you selected its HTML/website ZIP importer. A native Android project importer may not accept this file.
