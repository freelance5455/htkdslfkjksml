PROJETO ANDROID - SIMULADOR DE BIOMETRIA FACIAL

Projeto de homologação/fictício. A captura é feita localmente e o resultado é uma simulação; não envia biometria para banco ou serviço externo.

Para gerar o APK: abra esta pasta no Android Studio e aguarde a sincronização do Gradle. Depois use Build > Build APK(s).

Requisito: Android Studio com internet na primeira sincronização para baixar o Gradle/Android Gradle Plugin.
