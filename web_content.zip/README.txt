SK MATHEMATICS GRADE 7 - ACTUAL FUNCTIONAL APP BUILD
=====================================================
Teacher password: skmp7theledi

This build is a functional browser/PWA app for demonstration and classroom workflow:
- Learner / Teacher entry
- Protected Teacher Dashboard
- Lessons with five-day sequence
- Different classwork per day
- One classwork attempt per day
- Monthly Tests & Exams with one submission
- Shared Discussion area
- Learner list, schedule and results dashboard
- No video option

IMPORTANT:
The app is functional locally and stores demo progress in the device browser.
For real multi-device synchronization (teacher phone -> all tablets) a hosted backend/database
must be connected. This package does not falsely claim that a live cloud backend is already active.
