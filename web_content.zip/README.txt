Paket shanshancantik - versi APK/WebView offline
=================================================

Struktur dibuat kompatibel dengan pembuat APK yang memuat halaman dari:
https://appassets.androidplatform.net/web/index.html

File tersedia di root dan juga di folder web/ agar lebih kompatibel.

Isi aplikasi:
- Kalkulator ilmiah
- Kimia + tabel periodik
- Massa molar
- Mol <-> massa
- Stoikiometri sederhana
- Analisis beberapa reaksi
- Catatan offline
- Ekonomi
- Konversi satuan

Semua file HTML, CSS, dan JavaScript lokal; tidak memakai CDN atau koneksi internet.

Jika pembuat APK meminta Start Page / Entry Page, pilih:
web/index.html
Jika pembuat APK justru meminta index.html di root, pilih:
index.html
