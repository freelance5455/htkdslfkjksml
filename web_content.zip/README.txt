Contractor Pro V15 — Notifications & Smart Alerts

APK-ready single-file build based directly on the verified V14 Team + Client Portal edition.

V15 adds:
- Offline smart alerts for overdue tasks
- Overdue invoice alerts
- Contracts due soon alerts
- Low-stock alerts when minimum stock is configured
- Notification completion state
- Manual refresh and reminder creation

Preserved:
- V14 Team & Client Portal
- V13 Subscription & License
- V12 Cloud & Sync
- V11 Account & Security
- Offline-first local storage
- Original Contractor Pro splash

Important:
This APK does not claim to provide real push/email notifications. Real remote notifications require the Contractor Pro backend, authentication and a notification service.

Root files required by simple HTML-to-APK converters:
- index.html
- package.json
- README.txt
