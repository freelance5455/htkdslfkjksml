DIEL_SHA Android WebView package

IMPORTANT: All website files are at the ZIP ROOT. Do not add an extra web/ folder.
The APK builder should extract index.html into its internal web directory so that its appassets.androidplatform.net/web/index.html path can find it.

Entry file: index.html
App icon: icons/icon-192.png and icons/icon-512.png
Offline: all app content and material data are local.

If the builder has a start-page setting, use index.html (not web/index.html). If it has an option to upload a website ZIP, upload this ZIP as-is.
