AS Metal Dyes & Nakas - Customer App
Open index.html. Dies catalogue (search, filter, cart). Invoice opens inside the app with PDF / WhatsApp / Share / Copy / SMS buttons.
