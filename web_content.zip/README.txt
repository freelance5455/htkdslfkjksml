IB NEXUS LAB
=============
ZIP to APK ilovasi uchun tayyor web loyiha.
Bosh fayl: index.html

Funksiyalar:
- Smart Quiz: 10 ta savol, javoblar, ball, rekord
- Code Studio: JavaScript/Python/HTML rejimlari, RUN tugmasi
- Reflex Game: 30 soniyalik interaktiv o‘yin
- My Progress: XP, level, rekordlar, achievements
- Offline localStorage
- AI Chat yo‘q
- Barcha asosiy tugmalar ishlaydi
