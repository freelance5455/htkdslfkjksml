KADAM PROJECT LEAVE — PRO EDITION
यह ZIP website-to-APK / ZIP-to-APK tools के लिए है। index.html root में है।

मुख्य features:
- Attractive dashboard
- Top photo slider; Head/Admin अपनी photos जोड़ सकता है
- Teacher login and leave apply
- Head approve/reject
- Teacher history and approved leaves
- Teacher add/edit/delete
- App name, school name, subtitle, theme color editable
- Leave types editable
- Local prototype storage

Demo:
Teacher: T001 / 1234
Head: ADMIN001 / admin123

महत्वपूर्ण: यह prototype local browser/app storage पर चलता है। अलग-अलग phones पर shared live data के लिए Firebase या secure server backend जोड़ना आवश्यक है।
