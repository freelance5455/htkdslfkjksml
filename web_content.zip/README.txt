Shekhar's Life — APKForge project v2.0

This is the updated offline diary web project.

v2.0 fixes:
- Reduced the unnecessary top blank space on My Diary.
- Corrected the fixed viewport height calculation so the entries panel ends above the bottom navigation.
- Kept the My Diary header, title, action button and section heading stationary.
- Kept only the bordered All entries panel independently scrollable.
- Preserved the existing botanical Life Timeline and Calendar styling, private-note vault, and photo attachment handling.

Import the ZIP into APKForge and rebuild the APK to test on your device.
