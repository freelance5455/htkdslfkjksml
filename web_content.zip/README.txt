D3R Televideo - versione senza banner

Questa versione rimuove il messaggio nero 'Problemi di visualizzazione? Apri sul sito RAI'.
Il banner 'This is exactly what your app will show' è una cornice del programma di anteprima:
non fa parte della pagina HTML e normalmente non viene incluso nell'APK finale.
La pagina RAI incorporata può comunque mostrare contenuti aggiuntivi propri.
