FreshCheck — final offline package
- First launch: FreshCheck → slogan → العربية / الفرنسية / الإنجليزية.
- Exact user-provided logo included.
- No demo products.
- Existing product storage, expiry colors and categories retained.
- Recipe section/navigation retained and opens from the app.
- Offline package: no external CDN is required by the HTML.
- Camera photo + manual expiry date fallback retained.
- Android-native OCR and system notifications still require native APK integration.
