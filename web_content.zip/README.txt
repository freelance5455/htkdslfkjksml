FOX WARRIOR  v66

How to run: open index.html in a browser (works from a folder, no server needed).

What's new in v41
- New 2D pixel enemies: Basic / Fast / Exploder / Armored zombies + mini-boss "Brutal Butcher".
  Ice zombies appear in snow/ice stages (3-4, 9-10), lava zombies in lava stages (7-8).
- 5 new pixel bosses (Forest Warden, Mountain Chief, Village Brute, Volcano Lord, Ice King).
  The boss arena was removed: you fight the boss right in the level.
- Checkpoint signs along every stage. When you die you return to the previous checkpoint:
  zombies, boxes, coins and ammo are restored exactly as they were at that moment.
- Tougher zombies, slightly more zombies per stage.
- Difficulty: Easy (easy) / Normal / Hard (really hard) - verified.
- Weapons use the shapes from the weapon sheet + new animations (energy glow, sparks,
  recoil smoke, switch pop, floating shop icons).
- Info screen updated.

Files: enemies/sheets (zombie + boss sprite sheets), weapons/w_XX.png (39 weapons).

v41: death restarts the stage from the beginning (no checkpoints), coins from the failed attempt are refunded,
all UI icons redrawn (each with its own shape/palette), missing icons added.

v41: checkpoints restored (signs + saved progress), death restarts the stage from the beginning.
New "Outfit upgrades" tab (gold outfit icon): red endurance bar / blue power bar, longer bars for rarer outfits;
locked outfits show how to get them. Inventory icon = red outfit. Weapon upgrades got bars too (longer for rarer weapons).
Stage weapons are now permanent; replaying gives coins from that crate. Glow added to every weapon.

v41: death screen has both 'from checkpoint' and 'retry stage'; coin chests give 10-15; animated glow on weapon images in weapon upgrades.

v41: smaller held weapons (per-weapon scale), removed in-game weapon glow/brightening, redrawn coin chests.

v41: no minus sign in armor %, bigger held weapons, stage-1 weapon is now an Arabic-named AK-47, wooden crates give ammo.

v43: game speed is now fixed at x1.5 (speed button removed from the screen and from Settings).
Crates (wooden + ammo crates) now give health AND ammo.
Weapons: removed leftover gun pixels on the firing pose, redrew the Scout AK-47 sprite (w_19), added recoil kick,
muzzle glow, ejected shell casings and light idle sway.
Graphics: canvas renders at up to 4K (auto-scaled to the screen, drops resolution automatically on slow devices),
smooth backgrounds + crisp sprites + sharp HUD.

v43: pause menu has a Map button; from the map (mid-stage) every unlocked stage can be opened. Choosing the current stage offers 'Continue mission' (same spot), choosing another starts it - no need to die.
v43: fixed map clicks while in a stage (stages are clickable from the in-stage map); Raven HQ button moved next to the pause button.
v44: same as v43 (renamed).


v50: Achievements outfit is now onyx black (suit+bandana). New 'Smoky Fox' outfit (smoky gray + diamond-white bandana) unlocked by killing the Forest Warden (stage 2).
Poppy-Playtime-style 'NEW MISSION' banner + progress counter; NPCs now promise rewards. Wooden bridges in stages 3-4. Full story arc + cinematic ending (TO BE CONTINUED). Weapons: outline/shine/saturation pass. Background: haze + fireflies/embers/snow.

v53: smaller objective panel (10s, never replays after checkpoint/resume), progress bar moved off the weapon text, rifle given by Uncle Saqr at the start, laughing taunt dialog on death, auto-resume after the app reloads, lighter rendering for less lag.
v53 fix: stage 2 freeze after the Forest Warden outfit (Smoky Fox had no stats entry, which crashed the game on every hit).
v54 fix: ending now always plays after stage 10 (it was skipped if the closing dialogue had already been seen).
v56: harder enemies, Arabic chapter cards, boss-specific death taunts, redesigned dialogue portraits, stage 10 ends with "To be continued" black screen then map.

v57 (fixes + new look):
- Story: Uncle Saqr now says "zombies" instead of "hunters". At the end of stages 4 and 5 (and in the stage 5/6 briefings) he says "the zombie hunters".
- Stages 5-6 (village): the zombies are now Zombie Hunters (olive cap + orange vest) and they shoot back with slow, dodgeable bullets.
- Death taunts: every death now gets a taunt from the monster you were facing (bosses, ice/lava/hunter/normal zombies), including drowning/burning, always calling Raven by name ("Raven, I never expected you to be such a failure, hahaha!").
- Game completion: beating stage 10 plays a real ending (THE END), marks the game as completed (menu badge + "Beat the game" achievement) and from then on replays never show story/dialogues/objective banners again. Stage 10 no longer shows "TO BE CONTINUED" or a dead "Next Stage" button on replay.
- All 39 weapons redrawn (new shapes, colours, shading, outlines), larger on screen, rendered at 2x so they stay sharp while held, firing and in menus. Weapon sprites now match their names/colours (Golden AK, Fox Spear Rifle, ...). Idle carry pose adjusted.
- Lag fixes: render scale capped at 3x with automatic (remembered) downscale, background composed once per frame, no more animated CSS filters in shop/upgrade screens, far fewer save-game writes.
- Text: Arabic/English wording fixed (duplicated sentences, dialect phrases, "Level" -> "Stage", missing hamzas/tashkeel, spacing), stage briefing now shows the correct NPC for stages 5-10.
- Bug fixes: weapon image cache could keep a gun-less sprite if the image loaded late; glow position used a fixed scale; stage 10 replay showed the ending again.


v58:
- Developer names removed from the game (end screen) and from this README.
- New story images at the start of the ending (after stage 10): "It's over..." then the new monster ("Who is this?!"). Tap an image to skip to the next one. Files: story/scene1_over.jpg, story/scene2_monster.jpg.
- Monster death: bosses now fall to the ground and then disappear (the boss corpse used to freeze and never vanish). Zombies fall a little slower, lie on the ground for a moment, then fade away.
- Stage gates: every stage now has a gate (the flag on odd stages was replaced). Frame and inside use the same colour:
  stages 1-2 green, 3-4 gray, 5-6 brown, 7-8 red, 9-10 icy blue. (Stage 9 keeps its locked energy door in front of the gate.)

v59: the ending now shows only the two story images, then a black screen with "To be continued" (Arabic: يتبع). The old text scenes and THE END screen were removed.

v60: new real sound effects (file: sounds.js, loaded by index.html).
- Jump: "Jump On Soggy Grass" (3 variants). Landing: soft sand thud.
- Footsteps on sand in all stages (one step per run cycle, alternating 6 variants).
- Falling into water: "Big Water Splash" (lower-pitched in lava stages).
- Stages 7 and 8: looping lava flow ambience (seamless crossfaded loop, quieter while paused).
- Removed the old synthesized (PS1-style) sounds for jump, landing, drowning/burning and the bubble noises.

v61: menu button click sounds, softer gunshot, new drowning/lava-death animation (splash, waving paw, bubbles, flames, smoke), 12 new revolvers in the shop (smaller size; old revolvers shrunk a bit).

v62: removed footstep, jump and landing sounds; gunshot is now only a very light click (no thud).

v63: all synthesized PS1-style sounds removed (hits, kills, coins, jingles, etc.). Only the gunshot, menu clicks, water splash and lava ambience remain.

v64: drowning splash sound removed, lava ambience much quieter, every weapon has its own gunshot sound (slightly louder).

v65: weapon sounds rebuilt as punchy layered shots (crack + body + tail + reverb + compressor, much louder); lava ambience lowered further.

v66: studio logo replaced with the black-and-white NP / نيو بيكسل STUDIO logo.
