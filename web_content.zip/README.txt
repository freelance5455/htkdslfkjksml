M Alhaisam customer service — Light Accounts
Scanner نہیں، الگ Stock menu نہیں، Start screen نہیں۔
ایپ سیدھا Dashboard کھولتی ہے۔ Light UI، Manual Sale/Purchase، روزانہ Sale/Profit/Purchase، Monthly History اور JSON Backup۔
HTML to APK Builder میں JavaScript اور Local Storage/DOM Storage ON رکھیں۔ Camera permission کی ضرورت نہیں۔
