Forma – Android-Web-App-Paket

Enthalten: index.html, manifest.webmanifest, service-worker.js und icon.svg.
Dieses ZIP enthält die Forma-Oberfläche und PWA-Dateien für einen HTML/ZIP-zu-APK-Builder.
Es enthält absichtlich keinen Server und keine API-Schlüssel. KI-Funktionen, die einen Server benötigen, funktionieren offline nicht.
