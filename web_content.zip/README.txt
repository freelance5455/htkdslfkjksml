THE HOLLOW ESTATE — Mobile-Friendly Survival Horror
===================================================

A self-contained, original browser horror game built with HTML, CSS and JavaScript. It has no external libraries, images, fonts, API keys or network dependencies. All textures and sprites are drawn at runtime, so it can run offline once the HTML file is saved to your device.

PLAY ON ANDROID
---------------
1. Extract this ZIP to a folder on your Android phone.
2. Open index.html in a modern browser, or open the file in a code editor such as Spck Editor and use its preview feature.
3. Rotate to landscape for the best view. Tap “Enter the estate”.
4. Touch controls are shown on phones: left-side arrows move, drag on the view to look around, RUN sprints, LIGHT toggles the flashlight, and INTERACT opens doors / collects items / hides / uses machinery.
5. For desktop: WASD or arrow keys move, mouse looks around, E interacts, F toggles flashlight, Shift runs, Esc pauses.

OBJECTIVE
---------
- Explore the estate and recover all 3 sigils.
- Find the ceramic generator fuse.
- Interact with the generator after collecting the 3 sigils and fuse.
- Reach and open the front gate.
- Avoid the Caretaker. Running makes more noise; a wardrobe can hide you.

FEATURES
--------
- First-person raycast rendering with procedurally generated wall textures, perspective floor, darkness, flashlight, fog and vignette.
- Original Caretaker enemy with patrol, hearing/vision detection, chase and search states.
- Doors, collectible sigils, fuse, readable notes, hiding places, generator and escape objective.
- Web Audio ambience and synthesized sound effects (audio starts after the Start button is tapped).
- Mobile-friendly touch controls, keyboard and mouse controls, mini-map, objective tracking, pause and restart screens.
- Single-file game: all code and art are in index.html.

NOTES / TROUBLESHOOTING
----------------------
- Use a current Chromium-based browser (Chrome recommended) for best performance.
- If the preview is cramped, rotate the phone to landscape and refresh.
- Sound requires the initial tap because browsers block autoplay before user interaction.
- The game is an original genre-inspired project and does not include assets from Granny or Kamala.


TROUBLESHOOTING UPDATE
----------------------
This build includes a visible runtime-error panel. If the browser encounters a JavaScript
error, the message is displayed on screen instead of leaving you with a silent blank page.
Take a screenshot of that message if a problem remains.

For Android, extract the ZIP first, then open index.html in Chrome or Spck Editor Preview.
Some editor previews restrict browser APIs; if so, try opening the extracted file in Chrome.
