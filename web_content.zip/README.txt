RAPPEL FANAFODY - SINGLE FILE ZIP TO APK

index.html is completely self-contained: HTML + CSS + JavaScript + creator photo are embedded. No external files, CDN, API or Internet required.

Use a ZIP-to-APK service that accepts a ZIP with index.html at the root.
