APP: ¿SÍ O NO?

Archivos:
- index.html: pantalla y botones.
- styles.css: diseño.
- app.js: ambos botones intentan cerrar la app.
- assets/icon.svg: icono.

IMPORTANTE:
En un navegador normal, JavaScript no puede forzar el cierre de una pestaña
que el usuario abrió manualmente. Por eso window.close() puede ser bloqueado.

Para que cierre de verdad dentro de una APK Android, la app debe abrir esta
página en un Android WebView y exponer un puente Android.closeApp() que cierre
la Activity. No se redirige a sitios externos.

Ejemplo Kotlin para una Activity con WebView:

class WebAppBridge(private val activity: Activity) {
    @JavascriptInterface
    fun closeApp() {
        activity.runOnUiThread { activity.finish() }
    }
}

Luego, después de configurar el WebView:
webView.addJavascriptInterface(WebAppBridge(this), "Android")

Usa este puente solo con archivos HTML locales de confianza.
