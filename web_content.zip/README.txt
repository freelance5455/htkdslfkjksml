UPPSC Prep - folder for "HTML to APK" converters

index.html  = the whole app (one file, works offline, no internet needed inside the APK)
icon.png    = 512x512 app icon (upload it if the converter asks for an icon)

Use: upload THIS zip (or just index.html) to the converter. App name suggestion: UPPSC Prep.
After installing the APK, open it, go to Settings and press "Export backup" once to check downloads work.
If downloads do not work in that app, use "Copy backup as text" and paste it into a notes app; restore later with "Restore from pasted text".
