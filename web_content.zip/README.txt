ApkForge me: "Zipped site" chunein aur yeh zip dein (index.html andar hai).
Staff panel (hidden): splash par ya Home me "My Tunnel" naam par 5 baar tap karein (2.5 second ke andar).
Staff login: admin / admin123
