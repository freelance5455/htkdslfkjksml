DG GAMES — PLAYER APP
=====================
index.html zip ke root mein hai, isliye kisi bhi "website to APK" builder / hosting par seedha chalti hai.

Is mein: opening animation (intro.mp4, canvas par chalti hai — video player nahi dikhta), DG logo,
games, login / signup (direct, email confirm nahi), Events, Notifications (🔔), Customer Support,
Rules, About, Profile (picture, banner, User ID) aur Ludo (real online multiplayer).

LUDO
- Har banda sirf app mein signup karta hai. Ludo mein wahi account chalta hai (alag login nahi).
- Coins profile par nazar nahi aate. Profile -> "My Ludo wallet" dabao to dikhte hain, aur Ludo ke andar bhi.
- Ludo kholne par pehle LOBBY aati hai (profile picture, banner, rank, coins). Match tab lagta hai jab
  RANK MATCH ya CLASSIC MATCH dabao. Dono mein sirf real players, bots nahi.
- RANK MATCH : entry 10 coins, jeetne wale ko 20 coins + rank points (+30 jeet, -10 haar).
- CLASSIC MATCH : entry free, jeetne wale ko 10 coins, rank nahi badalta.
- Event match : har event ki apni entry / prize / MODE / THEME (server se tay hota hai).
- Lobby mein: Shop (coins se profile picture / banner), Leaderboard, My rank, Records.

NAYA MODE / THEME BINA NAYA ZIP BANAYE
Events ke rules aur theme app ke andar nahi, server (Supabase) mein hote hain. Naya event, naya mode ya naya
theme daalne ke liye app/zip badalne ki zaroorat nahi — Admin panel se ya server se event daal do, players ko
foran nazar aata hai. Details admin zip ki README mein hain.

APK BANANE KE TAREEQE
A) "Website to APK" / "HTML to APK" builder: yeh zip seedha upload karo.
   App name: DG GAMES | Icon: icons/icon-512.png | Internet permission ON | JavaScript + DOM storage ON
   Splash/loading screen ka rang #091135 rakho (opening animation se match karega).
B) PWABuilder: files HTTPS hosting par rakho -> pwabuilder.com -> Android.
C) Android Studio / Capacitor: files "www" folder mein rakh kar (npx cap init, add android, sync, open).
