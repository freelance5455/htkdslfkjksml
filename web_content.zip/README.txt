Max Call — yangilangan loyiha fayllari

Qo‘shilgan funksiyalar:
- Kontakt ismi va telefon raqamini qo‘shish.
- Kontaktlar localStorage orqali shu qurilmada saqlanadi (WebView sozlamalari ma’lumotlarni o‘chirmasa).
- Saqlangan kontaktga bosib SIM telefon ilovasini ochish.
- Kontaktni o‘chirish.
- Pastki menyu: Bosh sahifa, Qo‘ng‘iroqlar, Kontaktlar, Sozlamalar.
- Sozlamalarda standart davlat kodini tanlab saqlash.

MUHIM: Bu ZIP ichida assets/web/index.html manba fayli bor; bu o‘rnatiladigan APK emas. Uni mavjud Android/WebView loyihasiga joylab qayta build qilish kerak. Internet audio/video qo‘ng‘iroqlari haqiqiy ishlashi uchun ZEGOCLOUD SDK va xavfsiz token serveri alohida sozlanishi shart.
