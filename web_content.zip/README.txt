FAMILY BUDGET KSA — COMPLETE WEB APP SOURCE PACKAGE

This package contains the app source files. It is NOT a compiled APK.

FILES
- index.html: complete mobile-first budget app; CSS and JavaScript are included in this file.
- manifest.json: app name, display mode, theme and icon metadata for PWA-capable hosts.
- sw.js: offline cache service worker for HTTPS hosting.
- icon.svg: app icon.
- APK_BUILD_GUIDE.txt: instructions for using a web-to-APK packaging service.

APP FEATURES
- Budget overview: current actual pocket balance, projected end balance, planned income/expenses.
- Transactions: add/edit/delete planned and actual income/expenses, dates, notes and search/filter.
- Forecast: expected cash balance by date and cash-shortfall/low-balance warnings.
- Settings: opening balance, monthly salary, living costs, buffer and stay dates.
- Household resale estimates: edit purchase cost and resale percentage.
- Backup/export: JSON backup, restore from JSON, CSV transaction export.
- Sample plan: family stay 7 Nov 2026–7 May 2027; starting salary SAR 10,000/month and living costs SAR 3,000/month. These are example assumptions and are editable.

HOW TO PACKAGE AS APK
1. Upload this ZIP to a reputable HTML/WebView-to-APK packaging service that explicitly accepts a ZIP with index.html at the ZIP root.
2. If the service asks for a start page, use index.html.
3. App name: Family Budget KSA.
4. Choose Android APK output, then build and download the APK.
5. Test the APK and its backup/export features before relying on it for important financial records.

IMPORTANT
- This is a client-side web app. Records are stored in browser/app local storage on the device. Export JSON backups regularly.
- If the packaging service requires a URL instead of a ZIP, this package must first be hosted on HTTPS. Do not upload personal budget records to the converter.
- A compiled/signed APK is not included in this ZIP.
