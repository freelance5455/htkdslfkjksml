MonsterWalk Prototype
Original browser-based prototype. No Pokémon assets or code.
Includes touch joystick, scanning/catching prototype, seven rarity tiers,
elements, Beast Ball tiers, Dex placeholder, and day/night visuals.
