# SecretCalculator — Double-Tap Fixed

Fix:
- If trigger button is 5, double-tapping it no longer briefly shows 55.
- The trigger digit is not inserted during a double-tap.
- After the double-tap, the app waits 1 second and then shows:
  Secret Number - remembered last completed total.
- Example: 20 + 30 = 50, AC, double-tap 5 -> after 1 second: 450.

The trigger button still supports a delayed normal single-tap action.
