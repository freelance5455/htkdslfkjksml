Super Football Arena
1) Put server.js and index.html in the same folder.
2) Termux: pkg install nodejs  (once, needs internet)
3) cd to the folder, then: node server.js
4) Host opens http://localhost:3000 -> create room
5) Friend opens the printed http://IP:3000 link -> join room
