Vibely Private App - Starter Prototype
1. This ZIP contains index.html at the root, as required by APKForge's Zipped site upload.
2. It is a front-end demo/prototype only. Demo login, posts and chat do not connect to a real server.
3. Do not use real passwords or private content in this prototype.
4. Real multi-device accounts, invite-only access, synced posts/chat, secure media storage, and robust permissions require a backend (for example Firebase/Supabase) and security rules.
5. Screenshot blocking in a web page is not reliable. Native Android wrapper support is required, and it cannot prevent photographing the screen with another device.
