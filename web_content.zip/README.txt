BizManager Starter Demo (বাংলা)
================================

এটি একটি প্রাথমিক ওয়েব অ্যাপ ডেমো, Android APK নয় এবং এখনো অনলাইন মাল্টি-ইউজার সিস্টেম নয়।

কীভাবে চালাবেন (Android):
1. ZIP ফাইলটি Extract/Unzip করুন।
2. BizManager_Starter ফোল্ডারের index.html ফাইল Chrome দিয়ে খুলুন।
3. Chrome-এ খুললে ডেমোর ফিচারগুলো ব্যবহার করতে পারবেন।
4. ডেটা এই ব্রাউজারের localStorage-এ থাকে; ব্রাউজারের ডেটা মুছলে হারাতে পারে।

ফিচার:
- Dashboard
- Orders + status
- Products/stock
- Customers
- Courier information (manual only; no live booking/tracking)
- Expense and simple sales-minus-expense view
- JSON data export

পরবর্তী production ধাপে লাগবে:
- Secure authentication and per-business data isolation
- Cloud database + server-side authorization
- Backup and error handling
- Actual courier API integrations (where available)
- Subscription and payment integration
- Android build and testing

নিরাপত্তা:
এই ডেমোতে বাস্তব কাস্টমার/পেমেন্টের সংবেদনশীল তথ্য রাখবেন না।
