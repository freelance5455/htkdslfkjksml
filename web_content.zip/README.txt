APLIKASI ABSENSI MANUAL HENDRIK - PAKET APK

Isi:
- www/index.html : aplikasi utama
- server.js sengaja tidak disertakan karena APK berjalan sebagai aplikasi Android offline/WebView.

Konfigurasi yang disarankan:
Nama aplikasi : Absensi Manual Hendrik
Package ID    : com.hendrik.absensi
Versi         : 1.0.0
Orientasi     : Portrait

Catatan:
- Data absensi disimpan oleh aplikasi melalui localStorage, sesuai kode sumber.
- Fungsi jam berjalan, check-in/check-out, koreksi, filter, rekap gaji, dan cetak menggunakan fungsi yang ada di index.html.
- server.js hanya diperlukan untuk menjalankan versi web melalui Node.js pada port 3000.

Paket ini dapat langsung diunggah ke layanan Web/HTML -> APK yang menerima ZIP.
