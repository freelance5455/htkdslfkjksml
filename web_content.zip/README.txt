AUTO TEXT COLOR — TX3 MINI TV WEB EDITION

Target:
- TX3 Mini TV Box / Android 7.1.2
- Designed as a fixed TV 16:9 interface; not a mobile-first layout.

Files:
- index.html — complete app
- profile.jpg — profile image cropped from the supplied reference image

Main functions:
- Text input / paste
- Auto Color
- Save + local history
- PDF via print dialog
- Share (where the TV browser supports Web Share; otherwise copy fallback)
- Settings
- 1,000 generated text-color choices
- 25 light background-color choices
- Text size
- Day/Night
- Auto Save

Important:
This ZIP is a web app package. It is not an APK. Actual TX3 Mini installation/hardware behavior still needs to be checked on the user's TV Box because this environment cannot physically operate the TX3 Mini.
