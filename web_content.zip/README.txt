OVERTIME TRACKER - WEB APP PACKAGE

Files:
- index.html: the complete app.

To convert to APK:
1. Upload this ZIP to an online HTML-to-APK builder that accepts ZIP files.
2. Keep index.html at the ZIP root (already arranged this way).
3. App name: Overtime Tracker.

First launch asks only for your name. There is no ID/password login page.
Dashboard, Calendar, Settings, attendance records, salary settings, and JSON backup are included.

Important: this version saves records in local device/browser storage and does not cloud-sync between phones.
