INEXA CHALLAN & MATERIAL CALCULATOR — SELF-HOSTED, WITH YOUR OWN FIREBASE
==========================================================================

This copy of the app signs in with email + password and syncs through
your own Firebase project, instead of Claude's built-in storage. It is
meant to be hosted on Cloudflare Pages (or any static host) under your
own link or domain.

FILES IN THIS FOLDER
- index.html        the app itself
- manifest.json      the Inexa app icon / install details
- icons/              your logo at 192px and 512px
- firestore.rules    security rules — paste these into Firebase Console

------------------------------------------------------------------------
STEP 1 — SET UP FIREBASE (free)
------------------------------------------------------------------------
1. Go to console.firebase.google.com, sign in, click "Add project",
   name it (e.g. inexa-challan), finish the wizard. Skip Analytics.
2. Build > Firestore Database > Create database. Pick a region close to
   Kerala (asia-south1, Mumbai). Start in production mode.
3. Build > Authentication > Get started > Sign-in method > enable
   "Email/Password".
4. On the project overview page, click the </> (web) icon, name it
   Inexa Challan, skip Firebase Hosting (Cloudflare will host it).
   Firebase shows a block like this:

     const firebaseConfig = {
       apiKey: "AIza...",
       authDomain: "inexa-challan.firebaseapp.com",
       projectId: "inexa-challan",
       storageBucket: "inexa-challan.appspot.com",
       messagingSenderId: "...",
       appId: "..."
     };

5. Open index.html in a text editor, find FIREBASE_CONFIG near the top
   of the <script> section, and replace the six PASTE_... placeholder
   values with your real ones from step 4. Save the file.
6. In Firebase Console: Firestore Database > Rules. Delete what's there
   and paste in the contents of firestore.rules from this folder.
   Click Publish. This makes sure nobody but you (your own logged-in
   account) can read or write your data.

------------------------------------------------------------------------
STEP 2 — HOST IT ON CLOUDFLARE PAGES (free)
------------------------------------------------------------------------
1. Go to dash.cloudflare.com, sign up free.
2. Workers & Pages > Create > Pages > Upload assets.
3. Name the project (e.g. inexa-challan) and drag in this whole folder
   (index.html with your real Firebase config already pasted in,
   manifest.json, icons/). Do not upload firestore.rules — that one
   only goes into the Firebase Console, not onto the website.
4. Cloudflare deploys it in under a minute and gives you a link like
   inexa-challan.pages.dev — that is now your permanent app link.
5. Optional: Custom domains tab, to use your own domain name instead.

------------------------------------------------------------------------
STEP 3 — FIRST SIGN-IN
------------------------------------------------------------------------
1. Open your new Cloudflare link on your phone or computer.
2. On the sign-in screen, type an email and a password of your choosing
   and tap "Create account". This is now your one login — use the same
   email and password to sign in on every other device.
3. "Add to Home Screen" / "Install app" from your browser, same as
   before, to get the app icon on your home screen and desktop.
4. Go to Setup and check your company details, HSN codes, and set a
   PIN if you also want a screen lock on top of the sign-in.

------------------------------------------------------------------------
HOW THIS APP LOCK + SIGN-IN WORK TOGETHER
------------------------------------------------------------------------
- Sign-in (email/password): controls whether your data is loaded and
  synced at all. Required once per device.
- PIN lock (optional, in Setup): a quick screen lock on an already
  signed-in device — for example so a family member who picks up your
  phone can't flip through it without the PIN, even though the device
  itself is already signed in.

------------------------------------------------------------------------
THINGS TO KNOW
------------------------------------------------------------------------
- You are now responsible for this backend. Firebase's free tier is
  generous for one business, but keep an eye on usage in the console.
- Never share firestore.rules publicly with a different, looser rule —
  the rule above is what keeps your data private to your own login.
- Forgot your password? Use Firebase Console > Authentication to reset
  it, or add "Forgot password" sign-in later if you'd like — ask and
  this can be added.
- If you ever want to add a second person (e.g. a site supervisor) with
  their own login, create a second account the same way; they'll get
  their own separate data unless the app is changed to share one
  account's data between logins — ask if you want that instead, since
  right now each login is a separate, private set of data.


------------------------------------------------------------------------
SPEED NOTES (this version)
------------------------------------------------------------------------
- Your 8 most recently used items show as one-tap buttons at the top of
  "Add material", so repeat jobs need far less typing.
- Quantities have +/- buttons next to them, for fast changes without
  opening the phone keyboard.
- The Firebase sign-in scripts only load after the page itself has
  fully loaded (not before), and are skipped entirely if you haven't
  pasted in your FIREBASE_CONFIG yet — so the app opens instantly
  whether or not Firebase is set up.
- sw.js caches the app shell (index.html, manifest, icons) so the app
  opens instantly on repeat visits and still opens with no signal.
  It never caches your data or anything from Firebase — that is always
  fetched live. The browser installs sw.js automatically; you don't
  need to do anything for it, it just needs to sit in this same folder.

------------------------------------------------------------------------
NEW: STOCK TRACKING
------------------------------------------------------------------------
A "Stock" tab now shows, per item: Opening (set once in Items & prices,
for stock you already had before using this app) + Purchased (logged
in Stock, below) \u2212 Delivered (automatic, from every saved challan) =
Balance.

Logging a purchase is built like your challan screen: enter the
vendor's name, an optional bill/invoice number and the date once, then
search or tap-add every item on that bill with its quantity, and tap
"Save this purchase bill" \u2014 one tap saves every line. Recently used
vendors and items are suggested so repeat bills are quick.

This does NOT replace your Inexa tracker. Inexa tracker is for money
(what you owe each vendor, what's paid) \u2014 keep using it exactly as
before. This Stock tab is only for quantity (how much of each item is
left), which Inexa tracker doesn't track. If you don't need a running
stock balance, you can ignore this tab entirely; nothing else in the
app depends on it.

This matches items by their exact name, so a custom/typo'd line on a
challan or purchase won't count unless its name matches an item in
your price list exactly. It's for your own tracking only; nothing here
is sent to the GST portal automatically.

------------------------------------------------------------------------
NEW: E-WAY BILL HELP
------------------------------------------------------------------------
- Any challan or bill totalling \u20b950,000 or more now shows a clear
  warning on screen and a note on the printed copy, since CGST Rule 138
  requires an e-way bill for a consignment at or above that value.
- A new "Customer GSTIN" and "Approx. distance" field on the challan
  form feed straight into a new "E-way bill details" button, which
  lays out every field in the order ewaybillgst.gov.in asks for them
  (document no./date, bill from/to, GSTIN, items with HSN, vehicle,
  distance) and copies it to your clipboard.
- This app still does NOT generate the e-way bill itself or talk to
  the government portal \u2014 there is no official API for a small
  business to do that directly. You still log in to ewaybillgst.gov.in
  yourself and paste these details in; this just saves you from typing
  them out by hand. Always check the live rules at ewaybillgst.gov.in
  before you skip generating one.
