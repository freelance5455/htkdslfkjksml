MEMORIES — APP INSTALÁVEL (PWA)

Esta versão usa o projeto enviado e foi preparada para ser instalada como aplicativo.

Senha atual:
141816

Como usar no computador:
- Abra o projeto por um servidor local (recomendado).
- Não é garantido que PWA/service worker funcione abrindo index.html com file://.

Modo simples com Python:
1. Abra o Prompt de Comando na pasta Memories.
2. Execute:
   py -m http.server 8080
3. Abra:
   http://localhost:8080

Android:
- Publique a pasta em um endereço HTTPS.
- Abra o endereço no Chrome.
- Use o botão "📲 Instalar" quando aparecer, ou o menu do navegador > Instalar aplicativo.

iPhone/iPad:
- Publique em HTTPS.
- Abra no Safari.
- Compartilhar > Adicionar à Tela de Início.

Os dados continuam locais e criptografados no navegador/dispositivo.
Para sincronizar PC + celular, será necessária uma versão com servidor/banco de dados.
