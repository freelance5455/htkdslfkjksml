JASS ❤️ PAKHI JI — 12 SECRET GIFT BOXES
Extract the complete ZIP folder, then open index.html in Chrome.
The page uses a bundled romantic background image and includes 12 separate gift boxes. Tap each box to reveal its own emoji, title and surprise message.
Keep the images folder next to index.html for offline use.
