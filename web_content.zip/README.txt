KI Calculator — Khandelwal Industries

Files:
- index.html: Open in Chrome or another modern browser.
- khandelwal_industries_calculator_icon.png and ki_calculator_app_icon.png: branding images.

Pochi Poha:
- Customer name/mobile optional.
- Add individual bag weights.
- Hamali is ₹5 per bag weighing 51 kg or less; ₹10 per bag weighing above 51 kg.
- Net Rate only; no CD option.
- Payment status and optional signature are saved with the calculation.
- Entries persist in this browser/device until manually deleted.

Saved entries use browser local storage. They are not cloud-synced and can be lost if browser/site data is cleared or the browser/device changes. Use Saved Entries > Export Backup periodically.

Other included calculators: Dhan, Poha Payment, Powder/Churi, Bhusa.
