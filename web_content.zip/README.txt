PROYEK ANDROID NATIVE (JAVA) - Laporan Kurir Homey Catering
===========================================================

Folder ini berisi kerangka lengkap proyek Android Studio berbasis Java (Native Android App) yang dikonfigurasi khusus untuk aplikasi laporan kurir dengan izin kamera, GPS, dan WhatsApp Basic langsung.

Struktur Proyek:
- app/src/main/java/com/homeycatering/kurir/MainActivity.java (Logika Java & Izin Native)
- app/src/main/res/layout/activity_main.xml (Tampilan Layout WebView)
- app/src/main/AndroidManifest.xml (Konfigurasi Izin Kamera, Lokasi, Internet)
- app/src/main/assets/laporan-kurir.html (Antarmuka Form Laporan)

Cara Build ke file .apk:
1. Buka Android Studio di komputer Anda.
2. Pilih "Open an Existing Project" dan pilih folder proyek ini.
3. Tunggu proses Gradle Sync selesai.
4. Klik menu "Build" > "Build Bundle(s) / APK(s)" > "Build APK(s)".
5. File APK siap dipindahkan dan diinstal ke HP Android kurir!
