Meal Day - lightweight APK upload package

Upload this ZIP to an HTML/ZIP-to-APK builder.
App name: Meal Day
Package: com.mealday.foodtracker
Portrait orientation recommended.

The app is fully local: meal records are stored on the device/browser.
No money tracking, login, server, or external libraries are required.
