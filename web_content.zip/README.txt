MY WALLET — ANDROID PROJECT

This project packages your supplied My Wallet HTML as an Android app using a WebView.
It works offline. Your HTML's localStorage data is stored locally on the phone.

BUILD AN APK
1. Install Android Studio on a Windows PC.
2. Open Android Studio and choose Open.
3. Select the folder containing this README (the MyWallet project folder).
4. Allow Gradle sync. If prompted, install Android SDK Platform 35 and a compatible
   Android Gradle Plugin/Gradle version.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When complete, use the notification's Locate link. The APK is normally under:
   app/build/outputs/apk/debug/app-debug.apk
7. Transfer the APK to your Android phone and install it. Android may ask you to allow
   installation from that file manager.

NOTES
- No internet permission is requested; the wallet runs from the bundled HTML.
- Data is stored locally on the device using WebView localStorage.
- Uninstalling the app or clearing its storage may erase wallet data. Export/backup
  important data before doing so.
- This ZIP is the Android Studio source project, not a precompiled APK.
