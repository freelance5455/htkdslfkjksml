মেস ম্যানেজার

ফোনে HTML হিসেবে চালানো যায়। ডেটা ব্রাউজারের localStorage-এ থাকে। বাস্তব multi-phone push notification-এর জন্য Firebase/online backend লাগবে।