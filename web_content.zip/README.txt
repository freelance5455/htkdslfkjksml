IRON ARENA v5 - Offline 2D Fighting Game
Developer: MD Shakil Khan | Shefa Studio Apk

PLAY: unzip, keep index.html and the assets folder together, open index.html in Chrome. Fully offline.
The game is always 16:9 landscape (it auto-rotates if the phone is held upright).
MAKE APK: open android_project in Android Studio -> Build > Build APK(s).
Loading screens: assets/loading1.jpg (startup) and assets/loading2.jpg (before each match). Replace these files to change the art.
