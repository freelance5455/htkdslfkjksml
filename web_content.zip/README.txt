COLECTIVOS JUJUY – VERSIÓN FUNCIONAL
Cada línea abre un mapa propio y consulta la traza cartográfica de OpenStreetMap mediante Overpass.
La lista de líneas se actualizó con las fuentes municipales y la reorganización vigente desde agosto de 2026.
Requiere internet para cargar el mapa y las trazas.
La geometría no se inventa: si una línea no está mapeada en OSM, la app lo informa.
