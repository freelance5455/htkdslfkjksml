PesoFlow Online v1
===================
Files:
- index.html : mobile-friendly finance tracker web app
- supabase_schema.sql : database tables and row-level security setup
- README.txt : setup steps

This is an online/cloud-sync version. It uses Supabase Auth and database.
It is NOT pre-hosted. To enable online sign-in and sync:

1. Create a project at https://supabase.com
2. In Supabase SQL Editor, run the entire supabase_schema.sql file.
3. Go to Project Settings / API and copy the Project URL and anon (public) key.
4. Open index.html in a browser, choose Settings, paste the Project URL and anon key, then tap Save connection.
5. Go to sign-in screen, create account. Verify email if required, then sign in.

Hosting for web link:
Upload index.html to a static hosting provider (e.g. Netlify, GitHub Pages, Cloudflare Pages).
The Supabase URL and anon key can be configured by each user in the app Settings.
For online functionality, internet is needed to load Supabase SDK and connect to your Supabase project.

Security:
- Use ONLY the anon/public key in this client-side app. Never use Supabase service_role or secret keys.
- The SQL enables row-level security and policies so authenticated users access only their own records.
- Supabase dashboard Auth settings may require email confirmation.
- CSV exports are generated locally in the browser.
