NewsFlow WebAPK edition. Upload this ZIP to an HTML/ZIP-to-APK builder. index.html must remain at the ZIP root. The app uses an iOS-inspired UI and live RSS via rss2json.
