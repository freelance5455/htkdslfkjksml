ARCAD WORLD CRM — ANDROID APK PROJECT

This is a mobile-first HTML/CSS/JavaScript Owner CRM demo. The Arcad World brand mark is drawn as inline SVG vector artwork in index.html; there is no PNG/JPEG logo asset. It stays crisp at different screen sizes.

APP DETAILS
- App name: Arcad World CRM
- Short name: Arcad CRM
- Android package ID suggestion: com.arcadworld.crm
- Entry file: index.html

EMPLOYEE DEMO DATA
- Sidhique — Sales Manager
- Ranees — IT Support
- Sadiq — Accounts
- Sinan — Operations

BUILD
1. Upload this ZIP to an HTML-to-APK builder.
2. Set the entry/start page to index.html.
3. Set app name to Arcad World CRM and package ID to com.arcadworld.crm.
4. Select Android APK output and build.

DEMO ONLY
All data is sample data. The app is not connected to the live CRM, Tally, or Windows Server. Approval and period changes are temporary. Do not use for production until secure authentication, server APIs, HTTPS, role permissions and audit logging are implemented.
