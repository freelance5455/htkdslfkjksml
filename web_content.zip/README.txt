LIVE LOOPS COMPACT
==================
Updated playback:
- एक बार loop pad दबाने पर loop लगातार repeat होगा.
- दूसरा loop दबाने पर पहला तुरंत बंद होकर नया loop चलेगा.
- उसी चालू loop को दोबारा दबाने पर STOP होगा.
- असली audio files: app/src/main/assets/loops/loop1.mp3 ... loop200.mp3
- अगर audio file अभी मौजूद नहीं है तो built-in demo rhythm चलता है.
- A/B/C/D = 50-50 loops, कुल 200.
- BPM और master volume controls.
- Offline Android WebView project.
