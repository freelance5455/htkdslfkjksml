ColorLab Recipe - complete package
index.html  = complete working app (single file, open in Chrome; works offline)
source/     = same code split for reading: styles.css, JS files, markup.html
(Use index.html to run. source/ is for reference/editing.)
