JARVIS Free Phone Edition

This is a small web-based assistant packaged as a website ZIP.
To make an APK without a computer:
1. Open a reputable HTML/ZIP-to-APK builder in your Android browser.
2. Upload this ZIP (index.html is at the ZIP root).
3. Name the app JARVIS and choose an icon/theme, then build/download the APK.
4. Install only if you trust the builder and Android shows the expected app name.

Important:
- This is a WebView-style app, not a full native Android assistant.
- Voice input depends on whether the chosen wrapper/WebView supports Web Speech recognition.
  If voice input does not work inside the APK, use the page in Chrome.
- Gemini API key is entered by the user and stored in local browser/app storage.
  Do not share the key. API usage is subject to Google's current free-tier limits.
- The app does not listen in the background and cannot control arbitrary phone settings/apps.
