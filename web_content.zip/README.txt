Brain Up Android project (WebView wrapper)

This is source code, not a compiled APK.
Build with Android Studio: Open this folder, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).
Requires Android SDK platform 35 and a compatible Android Gradle Plugin download.
