CoinScout APK builder
1. Create a free GitHub account, make a NEW PRIVATE repository.
2. Upload everything in this folder (keep the .github folder).
3. Open the repo > Actions tab > "Build APK" > wait ~5 min until green.
4. Open the finished run > Artifacts > CoinScout-apk > download, unzip, install app-debug.apk on your phone.
To update the app later: replace www/index.html and commit; a new APK builds automatically.
