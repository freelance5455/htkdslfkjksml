معاون نمونه — Android APK Ready

Upload this ZIP directly to HTML to APK Builder.
index.html is at the ZIP root.
Suggested app name: معاون نمونه
Suggested package: ir.moaven.nemooneh.app
Suggested version: 1.0.0 / version code 1
Suggested permission: Internet (only if you want Firebase cloud sync)
Icon: icon.png
