ABDIBAASID - Offline All-in-One app prototype

This is an offline HTML app package, NOT a compiled Android APK.
Included: clock/date, calculator, local notes, tasks, simple income/expense log, text statistics.
Data is stored locally in the app WebView/browser storage. Clearing app data or uninstalling may erase it.
To make an installable APK, this package must still be wrapped/built by an Android app builder.
