# MOZ CITY MULTIPLAYER — v0.1

Primeira versão jogável de um mundo aberto original, com multiplayer por Wi‑Fi local.

## O que já funciona
- mapa de cidade
- personagem
- carros
- entrar/sair do carro
- controles Android + teclado
- 2+ jogadores na mesma rede local
- nomes dos jogadores
- vida e dinheiro no HUD
- servidor LAN sem dependências externas
- não usa internet/dados móveis para a comunicação entre jogadores

## Como testar sem PC usando Android + Termux

1. No telemóvel que será o HOST, instale Termux.
2. Crie/extraia esta pasta no Termux ou copie os arquivos para uma pasta acessível.
3. No Termux, entre na pasta do jogo e execute:
   `node server.js`
4. Ative o hotspot Wi‑Fi desse telemóvel e conecte os outros telemóveis ao mesmo hotspot.
5. Descubra o IP local do host com:
   `ip addr`
   Procure o endereço IPv4 da interface do hotspot/rede (geralmente começa por 192.168.).
6. Nos outros telemóveis, abra no Chrome:
   `http://IP_DO_HOST:8080`
   Exemplo: `http://192.168.43.1:8080`

Se o hotspot usar outro endereço, use o endereço mostrado pelo `ip addr`.

## Próximas atualizações possíveis
- mapa maior
- mais carros
- armas e combate
- NPCs
- polícia
- missões
- inventário
- dinheiro persistente
- chat
- salas/lobby
- otimização 3D
- versão APK

O projeto é original e não copia personagens, mapas ou outros assets de GTA San Andreas.
