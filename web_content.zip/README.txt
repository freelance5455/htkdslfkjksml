EasyTask

A mobile-first task manager built with plain HTML, CSS and JavaScript.

Features: add, edit, delete, complete, search, filter, priority, categories, due dates, dashboard statistics, and localStorage persistence.

Run locally: open index.html in a browser.

No database, backend, API, or external libraries required.

For an offline Android APK, upload this ZIP to an HTML-to-APK builder and choose the HTML/ZIP input mode (not the live URL mode).
