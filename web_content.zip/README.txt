STOCKLY v1 — ELITES CAFÉ Edition

Offline-first PWA for café inventory, sales, bookkeeping and planning.
No server, login, or cloud required. Data stays in the browser (localStorage).

Navigation
- HOME — sales, profit, stock snapshot, targets, health, break-even, alerts
- STOCK — items, filters, restock, waste, stock count, movements
- SALES — quick sale + end-of-day quantities → calculate → confirm
- BOOK — month totals, expenses, ledger (auto entries from sales)
- MORE — workers/pay, top products, 3-month projection, settings, backup

Preloaded ELITES menu
Kota R15–R40, hotdogs, chips, burgers, club sandwich, extras
Recipes deduct ingredients on confirmed sales and compute COGS.

Open index.html or install as PWA / wrap as APK.
