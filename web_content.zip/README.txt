# PWABuilder-ready Household Budget

Deploy the CONTENTS of this folder to the root of your Netlify site (not a nested folder). Confirm these paths work:
- /manifest.json
- /sw.js
- /icons/icon-192.png
- /icons/icon-512.png

Then re-run PWABuilder against the site's homepage. This package includes a manifest linked from index.html, app icons, and a registered service worker. Your existing transaction data is stored in browser local storage; back it up before replacing hosted files.
