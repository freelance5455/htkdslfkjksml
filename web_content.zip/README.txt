WAUTOGIK–BOGUMATAI WARD 1 YOUTH REGISTRATION APP — STARTER BUILD

Included:
- index.html: mobile-friendly registration form based on the supplied PDF
- manifest.json and sw.js: installable web app/offline shell when hosted over HTTPS
- Local save, edit/delete, total count, CSV export, JSON backup, photo, GPS, signature pad

IMPORTANT LIMITATION:
This first build stores records only in the current phone/browser. It does NOT yet synchronize between different officers or devices. Shared multi-user records require connecting a secure backend/database and configuring officer sign-in/access rules. Do not collect real sensitive data with this starter until you have tested it and decided how to protect/backup records.

HOW TO TEST:
1. Host these files on a secure HTTPS static host (for example, a hosting service you control).
2. Open the HTTPS link in Chrome on Android while online.
3. Use Chrome menu > Add to Home screen / Install app if offered.
4. Open it once online so the app shell is cached.
5. Test with dummy records offline, then test CSV export and backup.

For actual multi-officer use, connect the form to a central database and authentication. Do not simply share a local copy and assume the records are shared.
