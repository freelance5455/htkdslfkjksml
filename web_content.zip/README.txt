Mountain Rider Ultimate
12 worlds/roads, day-night, 16 vehicles (including helicopter, plane and rocket), 6 characters, unlock progression, upgrades, coins/fuel visuals, touch controls and saved progress.
This is an original 2D/2.5D-style browser game, not an exact copy of Hill Climb Racing.
Open index.html or package it as Android WebView APK/AAB.
