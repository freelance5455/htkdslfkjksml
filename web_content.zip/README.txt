3D CAR RUNNER
Open index.html in a modern mobile browser with internet access.
The game uses Three.js from jsDelivr, so the first load needs internet.
Features: 3D car, endless road, coins, power-ups, jump, slide, obstacles, car store, multiple cars, saved coins/unlocks.
