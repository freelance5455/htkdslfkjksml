Aroma Collection - Sandals & Shoes APK input

This ZIP is formatted for a phone-based HTML-to-APK builder. It is an OFFLINE DEMO. Products and edits are saved only on the same device/browser/app and will NOT sync to customers. For shared live rates, first deploy a website with a shared online database, then build an APK that opens that live website URL.
