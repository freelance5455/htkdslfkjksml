# Jil Std 11 & 12 Science PRO — HTML → APK

## What is included
- Mobile-first dark/blue professional UI based on your supplied design.
- Std 11 + Std 12.
- Physics, Chemistry, Mathematics, Biology.
- Chapter lists supplied by you.
- Biology has NO JEE tab.
- Physics/Chemistry/Mathematics have Board, NCERT, JEE, Extra.
- Chapter-wise automatic navigation.
- Chapter Quiz auto-selects according to selected Std + Subject + Chapter.
- Admin Panel protected by the password you requested: `Sat Shree 108`.
  The app stores only the SHA-256 hash in JavaScript, not the plain password.
- Admin can add PDF/Notes/Drill Book links, Google Drive video links, and other links.
- Added content appears automatically under the selected chapter/category.
- Downloads page uses IndexedDB/local storage. If a Google Drive resource allows browser CORS access, the app tries to store the actual file blob; otherwise it stores the link inside the app.
- Firebase Web configuration is included exactly as supplied.
- `assets/app-icon.png` = app icon for the HTML-to-APK converter.
- `assets/splash.png` = splash/start image for converters that ask for a second image.

## Important security limitation
A pure HTML-to-APK app cannot keep an admin password truly secret because the JavaScript runs on the user's device.
The password gate is useful for convenience, but NOT a high-security authorization system.
For true admin security, use Firebase Authentication + custom admin claims + Firestore/Storage Security Rules.
See `firebase-rules.txt`.

## Phone conversion
1. Unzip this folder.
2. Keep `index.html`, `app.js`, `manifest.json` and the `assets` folder together.
3. In your HTML-to-APK app choose "HTML File to APK" (or ZIP File to APK).
4. Select `index.html` if it asks for an HTML file, OR select the whole ZIP if it asks for ZIP.
5. App name: `Jil Std 11 & 12 Science PRO`
6. Icon image: `assets/app-icon.png`
7. Splash/second image: `assets/splash.png` if the converter asks for it.
8. Build the APK.

## Google Drive video
In Admin Panel:
Standard → Subject → Chapter → Category → Type = Video → paste the Google Drive sharing link.
The Drive file should have appropriate sharing permission (for example, viewer access for intended students).

## Firebase
The Web Firebase config is in `app.js`.
This project intentionally uses Firebase Web CDN imports instead of `npm install firebase`, because an HTML-to-APK converter on a phone normally cannot run an npm build pipeline.

For cloud admin editing, configure Firebase Authentication and restrictive Firestore rules before allowing real users.
