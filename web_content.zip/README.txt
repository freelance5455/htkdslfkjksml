Partners Diary V5 — WhatsApp fixed.
WhatsApp buttons now use the WhatsApp app URI instead of wa.me browser links.
This avoids opening the browser in Android WebView wrappers.
WhatsApp Business uses the same WhatsApp URI and Android may route it according to installed/default app settings.
