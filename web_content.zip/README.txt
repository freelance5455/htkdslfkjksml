WOOD & STONE — ISOMETRIC RUN v1.1

Correzioni core:
- Alberi molto più grandi, contrastati e visibili sulla board.
- Skill Tree usa Punti Abilità + Legna e, nei rami avanzati, Pietra.
- Se non restano risorse minabili la run termina immediatamente.
- Lo Skill Tree è bloccato durante una run.
- Ramo critici: 12% x2 -> 22% x2.5.
- Ricrescita: gli alberi abbattuti possono rigenerarsi dopo 2.5 s durante la stessa run.
- Un solo timer globale della run.
- Le risorse parzialmente danneggiate allo scadere non danno ricompense.
- Default: 3 tile, una sola risorsa casuale.

APK wrapper:
App: Wood & Stone
Package: com.woodstone.isometricrun
Orientation: portrait / sensor
Fullscreen: ON
Internet permission: non necessaria.
