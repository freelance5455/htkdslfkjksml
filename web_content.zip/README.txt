DICE BATTLE — Android installable web app package

Files:
- index.html: the game
- manifest.webmanifest: install metadata
- sw.js: offline app-shell cache
- icon.svg: app icon

Important:
This is a Progressive Web App (PWA) package, not a signed Android APK.
To install it like an app:
1. Upload all four files to an HTTPS website (same folder).
2. Open that HTTPS address in Chrome on Android.
3. Open Chrome menu (⋮) and choose "Install app" or "Add to Home screen".

The game logic works locally. The two portrait images are loaded from Wikimedia URLs,
so the first image load requires internet unless those image files are separately hosted
alongside the app and the HTML image URLs are updated.

A signed APK needs an Android build/signing environment; one is not available in this
workspace, so this package does not claim to be an APK.
