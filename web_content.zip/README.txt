EchoPod Offline — Full Single-File Web App

Files:
- index.html: complete offline-first EchoPod UI and player logic.

How to use on Android:
1. Extract the ZIP with your Files app.
2. Open index.html in a modern browser or a local HTML viewer that supports JavaScript, IndexedDB and local file input.
3. Tap Import music and select audio files from your device.
4. After the files are imported, playback works without an internet connection, because the audio blobs are stored in IndexedDB in that browser's local storage.

Important:
- Imported audio is stored locally in the browser profile. Clearing browser/app data may erase the library.
- A browser's file:// restrictions and some HTML viewer apps can limit storage/audio file access. If it doesn't work in your chosen viewer, use an offline HTML app that supports IndexedDB and file input.
- This is a complete offline-capable web app, not a compiled Android APK. A real APK still requires packaging/building with an Android build service or Android build tools.
- Tracks must be imported from files you own or have permission to use. The app doesn't bundle copyrighted songs.
