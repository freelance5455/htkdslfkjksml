PAGE PRO — VERSION 3 (HTML)
============================

Cette version est volontairement un fichier HTML autonome :
- aucun script externe ;
- aucun framework externe ;
- aucune image externe ;
- pas de dépendance à un site Web pour afficher l'écran ;
- écran Connexion : numéro + mot de passe ;
- création d'une Page : nom de Page + numéro + mot de passe ;
- vérification Internet ;
- blocage de l'utilisation hors connexion ;
- publications texte + image ;
- interface mobile Page pro.

IMPORTANT POUR LE CONVERTISSEUR HTML -> APK
1. Importer UNIQUEMENT index.html.
2. Le fichier doit être chargé comme fichier local / asset.
3. Si le convertisseur demande « Internet permission », « INTERNET », « Network access » ou similaire : ACTIVER.
4. Ne pas choisir une option « Website URL ».
5. Ne pas mettre https://local.file/... comme URL manuellement.
6. Si le builder affiche encore appassets.androidplatform.net/web/index.htm avec ERR_HTTP_RESPONSE_CODE_FAILURE, le problème vient du builder/WebView et non du HTML. Dans ce cas il faut utiliser son mode « Local HTML / HTML files / Import ZIP » ou un autre builder compatible.

IMPORTANT SUR LA VERSION FINALE
Cette version est une base d'interface. Les comptes et publications sont encore stockés localement sur l'appareil. Pour une vraie plateforme où une Page créée sur un téléphone est visible sur tous les téléphones et sur Internet, il faudra ajouter un serveur, une base de données, authentification, stockage d'images et une URL publique.
