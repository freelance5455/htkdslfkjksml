JPSHOPPING Navigator - Elegant Fixed Bottom Menu

Upload this ZIP to an HTML/Web-to-APK builder.

index.html is intentionally at the ZIP ROOT.

The app opens JPSHOPPING first. A fixed bottom navigation stays visible above the website:
- Home
- Purchase (opens Yahoo Auctions Buying + Other Websites Buying)
- Orders (opens Tracking + Purchase History + Packing/Shipping)

The navigation is fixed to the app viewport and does not scroll with the website.
