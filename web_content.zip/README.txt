FF BATTLE ASSISTANT - VOICE EDITION

1. Is ZIP ko HTML-to-APK builder me upload karo.
2. index.html ko start/home file rakho.
3. APK install karke Microphone permission Allow karo.
4. App me VOICE ON dabao aur sawal bolo.
5. TEST VOICE se voice output check karo.

IMPORTANT:
- Voice input ke liye Android WebView/browser ka SpeechRecognition support zaroori hai.
- Kuch HTML-to-APK builders SpeechRecognition ko support nahi karte. Aise builder me permission Allow hone ke baad bhi mic voice input start nahi hoga.
- Voice output (speechSynthesis) device/WebView ke available voices par depend karta hai; Hindi voice available ho to app usko prefer karta hai.
- Is project me koi cheat/hack feature nahi hai; ye gameplay tips assistant hai.
