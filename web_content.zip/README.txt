Silver One - HTML to APK package
جرّب رفع هذا الملف كما هو إلى أداة HTML to APK.
تم وضع الملفات في المجلد الرئيسي وكذلك web/ لضمان التوافق مع الأدوات التي تبحث عن web/index.html.
ابدأ بملف index.html.
