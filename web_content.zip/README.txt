WATER PUMP SYSTEM - SHARIF & SONS CONVERTER FORMAT

This package follows the same basic format as the supplied working Sharif & Sons app:
- index.html
- manifest.json
- assets/pump_scene.png

IMPORTANT:
- index.html is at the ZIP ROOT.
- No external CSS or JavaScript files are required.
- The tank/pump reference image is local.

ESP32:
Router: http://192.168.100.50
Backup AP: http://192.168.4.1

Expected endpoints:
GET /status
GET /mode?value=auto|manual
GET /pump?state=on|off
GET /settings?waterCheck=60&retryDelay=15&speed=60
GET /speed?value=60

APK converter:
Use this ZIP/folder as local web content and keep index.html as the start page.
Enable JavaScript and local HTTP access for the ESP32 network.

The ESP32 must keep AUTO and all safety logic locally.
