PANEL VISUAL GAMING
===================
Incluye botones visuales: Aimbot, Línea, Teleport y FPS.
Las opciones NO realizan aimbot, teleport, inyección ni modificación del juego.
Al activar las cuatro, se habilita el botón para intentar abrir Free Fire mediante un intent Android estándar.

Conversión:
1. Usa "Archivo ZIP a APK" en tu conversor.
2. Selecciona este ZIP.
3. Usa index.html como inicio si lo solicita.
4. Genera el APK.
