Shadow Reign V3
- index.html at ZIP root
- 3 battle backgrounds (HD SVG, scalable)
- Locker: outfit, pants, shoes, mask, hair
- Beginner missions
- Punch/kick animations, hit/KO animation
- Local WAV punch/UI sounds
- No external URLs, no ads, no blood/gore
