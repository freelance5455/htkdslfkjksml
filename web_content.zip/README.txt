IRON ARENA v6 - Offline 2D Fighting Game
Developer: MD Shakil Khan | Shefa Studio Apk

PLAY: unzip, keep index.html and the assets folder together, open index.html in Chrome. Fully offline.
Always 16:9 landscape (auto-rotates if the phone is held upright).
MAKE APK: open android_project in Android Studio -> Build > Build APK(s).
Modes: START (versus + 8 arenas), TOURNAMENT (16 fighters bracket), BOSS LEVELS (5 bosses).
Skills: each fighter has 3 skills (energy bar) + ULTIMATE. Loading art: assets/loading1.jpg (startup), assets/loading2.jpg (before each match).
Keyboard (testing): Arrows/A D W move, J punch, K kick, S block, E dash, L/U/I skills 1/2/3 (I = ultimate).
