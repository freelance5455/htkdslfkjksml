# PS2 Game Fund

A small offline-friendly savings tracker with a PlayStation-blue theme.

## Use on Android
1. Extract `PS2_Game_Fund_App.zip`.
2. Open `index.html` in Chrome (or host the folder on a static HTTPS site).
3. For the installable home-screen experience, open the hosted HTTPS version in Chrome and choose **Add to Home screen** / **Install app**.

The app supports flexible deposits, withdrawals, milestones, transaction history, and JSON backup/restore. It stores data locally in the browser on that device.

## Important limitation
This package is a web app/PWA source, not a compiled Android APK. A signed APK requires an Android build toolchain and packaging/signing step. No APK has been produced here.
