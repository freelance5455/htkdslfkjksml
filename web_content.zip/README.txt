NSE STOCK INVESTMENT APP - HTML/JAVASCRIPT VERSION

Files:
- index.html: app interface
- app.js: calculations, local storage, forms and CSV export
- style.css: Android-friendly styling
- template_data.json: extracted Excel workbook structure/data
- NSE_Stock_Investment_App_Template.xlsx: original Excel template

HOW TO USE:
1. Put index.html, app.js and style.css in the same folder.
2. Open index.html in a browser, or import the folder into an HTML-to-APK compiler.
3. Data entered in the app is saved locally on the device using localStorage.
4. CSV export can be used to move data back into Excel.

The app implements the main Excel fields: transactions, holdings, target price/profit, expected dividend, book closure/payment dates, broker, notes and cash deposits/withdrawals.
