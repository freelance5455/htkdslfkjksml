SMART STUDY AI — Android Studio project

Features
- Gujarati Std 9 GSEB Science chapters 1, 2, 5, 7, 8, 12
- Notes, Homework checklist, daily Class Work
- 25-question chapter quizzes; 9 easy, 9 medium, 7 hard
- Shuffled question order on each attempt, score history and answer review
- Offline local storage; JSON backup export
- No AI API key, Firebase, account, or internet connection required

Important honesty note
This build uses an offline question bank, not a live generative AI model. No API key is required because questions are bundled with the app. The question order is shuffled each attempt. To get a genuinely different set of 25 questions each time, expand the question bank beyond 25 questions per chapter or import a larger bank in a future version.

Open this folder in Android Studio (recent version), allow Gradle sync, then Run on an Android device/emulator. The app is a lightweight WebView shell with HTML/CSS/JS assets.

Data is stored locally in the app WebView storage. Clearing app data may erase it; use Backup to export your records.
