English Sikho — Mobile App
यह एक मोबाइल-friendly English learning app है।
Files:
- index.html
- manifest.json
- sw.js

मोबाइल में index.html खोलकर ऐप चलाएँ। Chrome में "Add to Home screen" उपलब्ध हो तो इसे होम स्क्रीन पर ऐप की तरह जोड़ा जा सकता है।

APK बनाने के लिए इस folder को किसी HTML-to-APK/Android WebView builder में import करें।
