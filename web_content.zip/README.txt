FEMHUB STUDIO - ANDROID PROJECT
Option A (computer, Android Studio): open this folder in Android Studio, wait for sync, then Build > Build APK(s).
Option B (no install, GitHub): create a free GitHub repo, upload ALL these files and folders (keep the folders, including .github),
open the Actions tab > Build APK > run it, then download the 'femhub-apk' file from the finished run. Unzip it and install app-debug.apk.
Your app lives in app/src/main/assets/index.html.
