UNIVERSAL GAME SERVER STATUS CHECKER
Open index.html in Chrome or another modern browser. No coding or installation.
Supported: Minecraft Java, Minecraft Bedrock, SA-MP/open.mp.
Shows online/offline, current/max players, version, MOTD/gamemode and player sample if provided.
Minecraft API: https://api.mcsrvstat.us/ (cached, may take several minutes to reflect changes).
SA-MP API: https://samp.directory/developers (only servers indexed there; cached and periodically rechecked).
This is status-only, not server control. Unlisted SA-MP servers may return not found even when online.
