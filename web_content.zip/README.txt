# Live Loops Pro - HTML Project

यह Offline Android WebView/HTML ऐप के लिए तैयार बेस प्रोजेक्ट है।

## Files
- index.html
- style.css
- script.js
- audio/loop1.mp3 ... loop200.mp3

## जरूरी बात
ZIP में 200 वास्तविक audio loops शामिल नहीं किए गए हैं। अपनी MP3 files को audio folder में रखें और नाम रखें:
loop1.mp3, loop2.mp3 ... loop200.mp3

फिर इस project को किसी Android WebView/HTML-to-APK builder में खोलकर APK बनाया जा सकता है।

## Features
- 1 से 200 loops
- हर loop का Volume control
- एक समय में एक loop
- Offline audio
- Android WebView के लिए उपयुक्त
- BPM field शामिल है

नोट: BPM control अभी BPM value रखने के लिए है; MP3 की actual speed बदलने के लिए audio processing/Web Audio implementation जोड़ना होगा।
