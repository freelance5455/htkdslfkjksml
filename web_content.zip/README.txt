GONDAL DIVISION BUSINESS DIRECTORY — NO-BUILD STATIC PACKAGE

This is a plain HTML website. It does not require npm, React, a framework, or a build command.

Deploy instructions:
1. Extract this ZIP.
2. Upload/deploy the folder containing index.html to any static HTTPS host.
3. If your hosting service asks for a build command, leave it blank.
4. Set the publish/output directory to the folder containing index.html (often "." or the root).
5. Open the deployed URL on mobile to test.

The page reads the configured Google Sheet ID and worksheet gid=0. The sheet must allow public viewing for this no-sign-in public directory to work.
The page includes search, 50 rows per page, narrow Index No and Contract ID columns, wider Customer Name, row-detail popup, dynamic columns, and click-to-call links for detected phone/mobile columns.
Only publish information approved for public viewing.
