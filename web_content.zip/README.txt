NUMBER TRACKER

This is an installable offline-capable web app (PWA), not a compiled APK.

QUICK START:
1. Upload the contents of this folder to any HTTPS static hosting service.
2. Open the hosted address in Chrome on Android.
3. Open Chrome menu (three dots) > Install app / Add to Home screen.
4. Launch NUMBER TRACKER from your home screen.

Features:
- Numbers 0 through 100
- Add multiple positive whole-number entries to each number
- Automatic lifetime and daily totals
- Tap a number to view its entry history; edit/delete entries
- Daily report and lifetime bar graph
- Highest and lowest number with entries
- Data is stored locally in the browser on that device

IMPORTANT:
- Data stays on the device/browser and is not synced across phones.
- Clearing browser/site data can erase entries. Export/backup is not included in this first version.
- For a true APK, this web app can be wrapped in an Android Studio WebView/Capacitor project and built with Android SDK.
