CLAUDE AI PRO — ANDROID BAŞLANGIÇ PROJESİ

Bu ZIP, Android Studio ile açılabilecek bir başlangıç projesidir.
Henüz APK değildir ve gerçek Claude/Anthropic servisine bağlı değildir.
İçinde çalışan bir sohbet ekranı demosu vardır.

APK üretmek için Android Studio ve Android SDK kurulu bir bilgisayar gerekir:
1. ZIP'i çıkarın.
2. Android Studio'da klasörü Open ile açın.
3. Gradle senkronizasyonunun bitmesini bekleyin.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.
5. APK, app/build/outputs/apk/debug/ klasöründe oluşur.

Önemli:
- Bu, Anthropic'in resmî Claude uygulaması değildir.
- Claude markasını veya ücretli Pro üyeliğini kopyalamaz.
- Gerçek model bağlantısı için güvenli backend ve geçerli API erişimi gerekir.
- API ücretleri ve kullanım limitleri olabilir.
- API anahtarını APK içine koymayın.
