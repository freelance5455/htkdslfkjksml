AivoCut Beta 1.0 - pacote para APK

Este ZIP contém o HTML atual do AivoCut.
Use-o como arquivo web do aplicativo Android/WebView.

Arquivo principal:
- index.html

Observação:
Este ZIP não é um APK instalável por si só. Ele é o projeto web que será colocado dentro de um aplicativo Android/WebView para gerar o APK.
