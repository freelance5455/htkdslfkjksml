Alcy — PLÉYADES | WEB BETA 1.0

NOVEDADES
- El asistente ahora se llama Alcy (antes AIRA) en todo el proyecto.
- IA básica mejorada: responde preguntas frecuentes, hace cuentas (sumas, restas, porcentajes, raíces), dice la hora y la fecha, cuenta chistes y datos curiosos, tira dados/monedas, recuerda tu nombre ("me llamo ...") y entiende "otro".
- Voces: la primera opción es la voz femenina y la segunda la masculina (Ajustes > Voz de Alcy). También podés elegir cualquier voz en español de tu dispositivo.
- Nueva pantalla de entrada con el diseño del boceto y letra a mano (las fuentes se descargan con internet).
- Modo voz (Ajustes): Alcy lee en voz alta cada respuesta.
- Botón de micrófono: hablale y te responde con voz.
- Se corrigió el paquete ZIP y se creó una ruta nueva de descarga.
- El botón circular del perfil abre un centro con tres secciones: Perfil, Ajustes y Acerca de.
- Perfil: ver y cambiar el nombre de usuario, y cerrar sesión del perfil local.
- Ajustes: activar/desactivar los botones de voz, elegir velocidad de voz, reducir animaciones y borrar todos los chats.
- El nombre se guarda localmente y Alcy lo usa en el saludo.
- El historial y las preferencias se guardan en este dispositivo.

CONECTAR GEMINI DE GOOGLE
1. Abrí Google AI Studio desde el navegador y creá una clave de API de Gemini: https://aistudio.google.com/app/apikey
2. En Alcy, entrá al círculo del perfil → Ajustes → Inteligencia artificial.
3. Pegá la clave, guardala y tocá “Probar conexión con Google”.
4. Cuando la conexión sea correcta, los mensajes nuevos se responderán con Gemini. Si borrás la clave, Alcy vuelve a sus respuestas locales.

SEGURIDAD DE LA CLAVE
- La clave se guarda en el almacenamiento local de este navegador/dispositivo; no está incluida dentro del ZIP.
- No compartas el ZIP con una clave añadida ni pegues la clave en chats públicos.
- Esta integración directa es solo para pruebas personales. Para publicar Alcy, hay que mover las llamadas a un servidor propio para no exponer la clave en el navegador.
- El uso de la API está sujeto a límites, disponibilidad y posibles costos de Google.

IMPORTANTE
- Sin una clave de Gemini, esta beta funciona como prototipo local.
- El acceso por correo y contraseña todavía no está conectado a un servidor. No introduzcas contraseñas reales.
- No hay sincronización en la nube ni cuentas reales.
- La voz utiliza las voces disponibles en el navegador/Android: cuál suena y si es masculina depende de tu dispositivo.
- El micrófono necesita Chrome y permiso de micrófono.

CÓMO PROBAR
1. Descargá y extraé Alcy_Beta_0.9.zip.
2. Abrí index.html en Chrome.
3. Entrá como invitado y elegí tu nombre.
4. Tocá el círculo con tu inicial, arriba a la derecha.
5. Probá Perfil, Ajustes y Acerca de.


PUBLICAR COMO SITIO WEB (HTTPS)
1. Abrí https://app.netlify.com/drop desde Chrome.
2. Iniciá sesión o creá una cuenta en el servicio de hosting.
3. Extraé este ZIP y subí la carpeta que contiene index.html, styles.css, app.js y las imágenes.
4. El hosting generará una dirección HTTPS para abrir Alcy desde el celular.
5. Para mantenerlo solo para vos, no compartas esa dirección. El enlace de un sitio estático no es privado por contraseña: cualquiera que lo consiga podría abrirlo.

NOTA DE PRIVACIDAD
Esta versión no tiene autenticación real ni backend privado. El perfil, el historial y la clave de Gemini se guardan en el navegador/dispositivo. No uses una contraseña real ni compartas tu clave. Para acceso verdaderamente privado hace falta agregar inicio de sesión y un servidor seguro.
