NEXYVERA UPDATE — V2 PROTOTYPE
1) index.html is the app's main file.
2) The ZIP is structured with index.html at its root for HTML-to-APK builders.
3) Upload/import this ZIP into your HTML to APK app to build the new APK.
IMPORTANT UPDATE NOTE:
- This is a web-app prototype; health values are sample values.
- Real sensor readings, Bluetooth, fall detection, and emergency calling are not implemented.
- To install as an update over an existing APK, the new APK must use the same application/package ID and compatible signing key, with a higher version code. If your builder cannot preserve these, Android may reject the APK as an update. Do not uninstall the existing app until you decide whether you can reinstall it and have backed up anything important.
