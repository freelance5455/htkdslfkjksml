BaatChit - Setup (ek baar)
1) https://console.firebase.google.com -> Add project (free) -> Build -> Realtime Database -> Create (Test mode).
2) Project settings -> Your apps -> Web (</>) -> config copy karo.
3) index.html kholo, "const CFG={...}" me apiKey, authDomain, databaseURL, projectId bhar do.
4) Zip -> "ZIP to APK" app (index.html root me hai). Camera/Mic permission ON rakho (call ke liye).
Bina Firebase ke app demo mode me chalta hai (sirf ek hi phone par).
