MATYKA CHEATS — CENTRAL ADMINISTRATIVA
Versão 4.0.0

COMO IMPORTAR
1. Extraia o arquivo ZIP.
2. Abra o HTML To APK.
3. Selecione a pasta extraída ou o arquivo index.html.
4. Defina index.html como página inicial.

ESTRUTURA
- index.html
- assets/style.css
- assets/app.js
- assets/images/

RECURSOS
- Uma aba independente para cada produto.
- Cadastro, edição e remoção de módulos.
- Edição em lote de nomes.
- Bloqueio/liberação administrativa do catálogo por produto.
- Restauração da lista padrão por produto.
- Pesquisa, ordenação e exportação JSON.
- Salvamento local com localStorage.

OBSERVAÇÕES
O Painel Android está marcado como OFFLINE NO MOMENTO.
As alterações do catálogo são armazenadas localmente neste dispositivo.
