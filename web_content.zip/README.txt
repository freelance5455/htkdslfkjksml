TRAP TOWER — WORLD EDITION
20 níveis • orientação horizontal • menu principal • seleção de níveis • configurações • pausa
Personagem com pernas animadas • monstros • serras giratórias • espinhos • armadilhas dinâmicas
Controlos: esquerda = andar | direita = andar | ▲ = saltar | ● = atirar
Funciona offline no navegador. Extraia o ZIP no ZArchiver e abra index.html.
