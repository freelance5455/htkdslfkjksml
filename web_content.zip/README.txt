ONE LOVE V5
Fonctions ajoutées:
- photo de profil choisie depuis le téléphone
- création de publications texte + photo
- publications conservées localement sur le téléphone
- interface de test

Important: cette version reste un prototype local. Les photos, comptes et publications ne sont pas encore partagés entre plusieurs téléphones. Pour un vrai réseau social, il faudra une base de données et un serveur sécurisé.
