FLYFIX SENSIE 200 sensitivity HTML app. Open index.html in a browser or use it as the web assets for an Android WebView app. Sensitivity suggestions are illustrative and do not change game settings automatically.

Device Finder expanded to 497 device profiles, including OPPO K10. Device values are starting estimates and should be adjusted in-game.
