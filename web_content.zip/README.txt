CRIME RUSSIA FULL SITE
Главный файл ОБЯЗАТЕЛЬНО: index.html.

Структура:
index.html
login.php
database.sql
assets/
api/
  config.php
  stats.php
  players.php
  logs.php
  logout.php

Сайт -> PHP API -> MySQL.
Чистый HTML не может подключаться к MySQL напрямую.

Перед загрузкой:
1. Импортируй database.sql.
2. В api/config.php впиши данные MySQL.
3. Загрузи все файлы на PHP-хостинг.
4. Открой login.php.
5. После входа откроется index.html.

Важно: database.sql здесь демонстрационный. Для реального игрового сервера нужно заменить таблицы/поля на структуру БД твоего мода.
