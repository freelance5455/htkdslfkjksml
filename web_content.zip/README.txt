UNIQUE LOOK SALON - fixed HTML package
Important: this ZIP intentionally contains BOTH index.html at the root and web/index.html
so ZIP-to-APK builders that load appassets.androidplatform.net/web/index.html can find it.
