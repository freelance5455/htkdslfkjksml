GLADIATOR STUDIO - Photo Editor
================================

كيفية الاستخدام:
1. افتح ملف gladiator-studio.html في المتصفح (Chrome أو Firefox)
2. اضغط على "استيراد" لاختيار صورة
3. من تبويب Effects اختر أي مؤثر → يتضاف للـ Stack
4. تقدر تزيد أكثر من 20 مؤثر في نفس الصورة
5. من تبويب Stack تقدر تغير شدة كل مؤثر أو ترتبهم أو تحذفهم
6. Export لحفظ النتيجة

المميزات:
- أكثر من 500 مؤثر (Cinematic, Vintage, Neon, Beauty, Glitch, Artistic...)
- Stack غير محدود (طبق أكثر من 10-20 مؤثر)
- تنظيم حسب الفئات (Pills)
- Adjustments كاملة
- Text + Crop + Export عالي الجودة
- حفظ المشاريع في المتصفح

للمستقبل: يمكن تحويله لتطبيق PWA أو Capacitor.
