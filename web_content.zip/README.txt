Island Life: Survival — FINAL RELEASE CANDIDATE
=================================================

এই ZIP-টি একই single-game codebase-এর সবচেয়ে পূর্ণাঙ্গ playable prototype/release-candidate foundation।

Included systems:
1) Survival: HP, hunger, thirst, energy, day/night, weather, unconsciousness
2) Gathering: wood, stone, fiber, food, water
3) Crafting: axe, pickaxe, fishing rod, bow
4) Building: campfire, shelter, workshop, storage, animal pen, house, shop, dock
5) Farming: 5 crop types, crop timers, harvest, seed economy
6) Animals: chicken, cow, goat, sheep, feeding, health, egg/milk/wool production
7) Fishing
8) Inventory
9) XP and levels
10) NPC roles: farmer, trader, builder
11) Trading/economy
12) Village progression
13) Boat + island unlock progression
14) Quests/objectives
15) LocalStorage save/autosave
16) Mobile touch controls
17) Dark responsive UI

IMPORTANT HONEST NOTE:
এটি "final playable prototype/release candidate", কোনো finished AAA/commercial game নয়।
একটি সত্যিকারের store-ready game করতে custom art/sprites, animation, sound/music, collision polish,
advanced NPC pathfinding/AI, real streamed multiple maps, richer combat/hunting, breeding, weather effects,
quest engine, save migration, balancing, performance testing, Android packaging এবং QA দরকার।
এই ফাইলের architecture সেই পরের কাজগুলো করার জন্য প্রস্তুত রাখা হয়েছে।

RUN:
index.html browser-এ খুলুন। Phaser CDN থেকে আসায় প্রথম load-এ internet লাগবে।
APK বানানোর সময় Phaser local bundle করলে offline app করা যাবে।
