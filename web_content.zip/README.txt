CITY STRIKE 3D - ROTATE MODE

This ZIP has index.html at the ROOT for web-to-APK converters.

ROTATE MODE:
- Landscape-first game layout.
- Portrait screen shows a "فون کو گھمائیں" prompt.
- LANDSCAPE MODE requests fullscreen + landscape orientation where Android/WebView permits it.
- For true automatic sensor rotation in a native APK, enable "sensor"/"full sensor" orientation in the APK converter or Android manifest.

GAME URL:
https://village-3d-gun-game.hatchable.site/

Internet is required for this version.
