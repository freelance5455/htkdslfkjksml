Child Health Clinic - AppForge PDF Fix V3

This version uses a Blob URL and a real Android/WebView download action for Save PDF.
Tap Save PDF and then check the phone's Downloads folder.
Share PDF uses Android Web Share when supported.
The app remains offline and stores clinic data locally.
