Privacy Shield Browser + Guard
1. Build: Android Studio -> open native-android/ (JDK 17, SDK 35) -> Build > Build APK. Sign ALL THREE apps with the SAME key (signature permission com.privacyshield.permission.CONTROL).
2. Permissions: INTERNET.
3. Install order: any; install all three APKs (Control Center, Network VPN, Private Browser).
4. Detection: Control Center uses <queries> for com.privacyshield.network / .browser; missing app shows NOT INSTALLED.
5. n/a (VPN is handled by the Network app).
6. n/a.
Features built: JS toggle, 3rd-party cookies off, no cache, Clear Session, auto-clear on close in private mode, audit text. NOT built: per-site permission manager, download cleanup, WebRTC/canvas/WebGL controls (WebView limits).
7. ZIP-to-APK (index.html): only the info/UI page works. HTML/WebView version cannot provide system-wide Android VPN/TUN functionality, cannot talk to the other apps, and is not "100% anonymous".
8. Native APK only: IPC control, VpnService, WebView privacy settings, cross-app status.
IPC: explicit broadcasts + signature permission. Actions: com.privacyshield.PRIVACY_ON / PRIVACY_OFF / STATUS_REQUEST / STATUS_RESPONSE. No analytics, no data collection.
