JUVENIL V7
Jogo de palpites de futebol com pontos virtuais.

NOVOS MERCADOS:
- Resultado final: 1 / X / 2 = 5 pts
- Dupla chance: 1X / 12 / X2 = 3 pts
- Total de gols: Mais/Menos de 2,5 = 4 pts
- Ambos marcam: Sim/Não = 4 pts
- Escanteios: Mais/Menos de 9,5 = 4 pts
- Cartões: Mais/Menos de 4,5 = 4 pts
- Resultado do 1º tempo: 1 / X / 2 = 3 pts
- Placar exato = 10 pts

IMPORTANTE:
A V7 registra os mercados escolhidos no aparelho. A correção automática completa dos mercados estatísticos exige uma fonte de dados que forneça essas estatísticas após cada partida. O protótipo não inventa resultados.

Também inclui a Roleta de Bônus Diário, ranking, perfil, jogos reais e menu mobile.
Sem dinheiro real, depósitos, saques ou conversão dos pontos em dinheiro.
