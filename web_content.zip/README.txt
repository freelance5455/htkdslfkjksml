NOOR — GLOBAL ISLAMIC COMPANION (LAPTOP EDITION)

A free, responsive Islamic companion for Windows laptops. No account, subscription, paid API or API key is required. NOOR uses public data services and stores personal settings locally in your browser.

RUN NOOR
1. Extract this ZIP to a folder, for example Desktop\NOOR.
2. Double-click start-noor.bat.
3. Your browser should open http://localhost:8000.
4. Keep the Command Prompt window open while using NOOR. Close it to stop the local server.

The launcher uses Python's built-in web server. If Windows says py is not recognized, install Python 3 from https://www.python.org/downloads/ and select “Add Python to PATH”. Then run the launcher again.

FEATURES
- Quran index and all 114 Surahs, with Uthmani Arabic text.
- English Sahih International is the default meaning translation. Choose from a catalogue of published Quran translations in 22+ languages where editions are available, including Tamil, Urdu, Bengali, Indonesian, Malay, Turkish, French, Spanish, Russian, Chinese, Hindi, Persian, German, Swahili, Hausa, Pashto, Kurdish, Somali, Italian, Dutch and others. Catalogue availability can change; unavailable editions are not fabricated.
- Arabic revelation text remains present when a translation is selected. Translator/edition name is shown. Translation language is a Quran-reader setting; the rest of the app interface is currently English.
- Quran translation search, bookmarks, last-read position and offline Surah text saving.
- Three selectable Quran reciters: Mishary Rashid Alafasy, Abdurrahman Al-Sudais and Maher Al-Muaiqly. Recitation streams ayah-by-ayah; internet is required for audio.
- Worldwide prayer times: enter a city and country or allow browser device location. Your selected location is saved locally.
- Prayer calculation choices include Umm al-Qura, Muslim World League, ISNA, Egyptian, Karachi, Gulf, Kuwait, Qatar, Singapore, Turkey, Tehran and Jafari conventions, plus Standard/Hanafi Asr settings.
- Qibla bearing from device coordinates, with live device-orientation support where the browser and hardware provide a compass sensor. Laptops often lack a magnetometer; on those devices NOOR can show the calculated bearing but cannot rotate live with your heading.
- Built-in Adhan playback from the audio file bundled locally at assets/audio/adhan.mp3; no audio streaming is needed. Preview the recording once to permit browser audio, then enable scheduled playback.
- Bead-style 33 × 3 tasbeeh with three-step progress, custom dhikr counters, selected Quranic duas and sourced adhkar.
- Introductory Wudu, Ghusl and Salah guides with notes about madhhab differences.
- Dedicated 604-page Mushaf memorization workspace: load a complete page, hide/reveal Arabic for recall, listen to the page, mark memorized pages and track whole-Quran progress locally.
- Quran and dhikr reading goals, local bookmarks and installable PWA app shell. No prayer checklist or prayer completion tracking.
- Responsive layout for laptop and mobile-sized screens.

GLOBAL PRAYER LOCATION
Open Settings → Prayer location. Enter both city and country, then choose Use this city. For precise Qibla direction, choose Use device location and grant permission. The device coordinates remain in local browser storage; NOOR does not send them to an account. Prayer calculations vary by authority and location. Compare timings with your local mosque when needed.

OFFLINE AND PRIVACY
- The app shell is cached by the service worker when opened on localhost or HTTPS. A new cache version is used in this update; hard-refresh once after replacing files.
- Save a Surah offline from the Quran reader to store its Arabic and selected translation on this device. Audio streaming still requires internet.
- Clearing browser site data can erase local app data. Settings → Clear NOOR data also clears NOOR's local preferences and logs.

PRAYER ALERTS AND ADHAN
Browser notifications and built-in Adhan playback are best-effort only while NOOR is open and the browser is running. They are not guaranteed when the laptop sleeps, the browser is closed, or the operating system suspends the page. Preview the built-in Adhan once after enabling audio so the browser can grant playback permission. The bundled Adhan recording was supplied by the app owner. Reuse and redistribution rights should be confirmed by the owner before public distribution.

DATA SOURCES AND RELIGIOUS CARE
- Quran Arabic text and Surah metadata: AlQuran Cloud API — https://alquran.cloud/api
- Quran translations and edition metadata: QuranEnc API — https://quranenc.com/en/home/api
- Prayer timings and Hijri-to-Gregorian date conversion: AlAdhan API — https://aladhan.com/prayer-times-api
- Built-in Adhan recording: locally bundled user-supplied MP3 at assets/audio/adhan.mp3.
- Quran recitation audio: Mishary Alafasy from AlQuran Cloud; Abdurrahman Al-Sudais and Maher Al-Muaiqly from EveryAyah (selected per-reciter audio sources).
- English translation is a translation of the meanings, not a replacement for the Arabic Quran. Published translation editions and their translators vary by language.
- Duas and adhkar display source references where included. Hadith numbering can vary by edition. Verify religious matters with trusted primary sources and qualified teachers.
- Learning material is introductory, not a fatwa. Details can differ among the Hanafi, Maliki, Shafi'i and Hanbali schools.

LIMITATIONS TO KNOW
- Internet is required for first-time Quran catalogue loading, fresh prayer times and recitation audio. Previously saved Surahs and app shell can work offline.
- Prayer reminders cannot be guaranteed while the app is closed or the computer is asleep.
- Prayer calculation methods are conventions; local mosque timetables may differ.
- The app interface is English in this edition, while Quran translations can be selected in supported catalogue languages. The language dropdown is in Settings; unavailable translations remain disabled until a published source is found.

TROUBLESHOOTING
- If Quran/prayer content does not load, check your internet connection and refresh.
- If opened as file:// and online requests fail, use start-noor.bat.
- If Quran audio does not start, click Play once. For Adhan, use Preview Adhan once; browsers require a user gesture.
- For compass accuracy, use calibrated device sensors and compare with a trusted physical compass.

Everyday-life adhkar includes short supplications for eating, sleeping, waking, bathroom visits, home, mosque, clothing, travel, sneezing and other common moments. References are supplied for checking; translations are meanings, and wording/numbering can vary by edition.
