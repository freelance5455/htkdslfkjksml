LUNATUNES — PURPLE MUSIC PLAYER

This is a small progressive web app prototype for playing audio files stored on your device.

TO TEST:
- Open index.html in a modern browser. Some browser features such as install/offline caching require hosting over HTTPS or localhost.
- Tap “Add music from your phone” and choose audio files.

TO ADD TO ANDROID HOME SCREEN:
1. Upload all files, keeping their filenames and folder structure, to a static web host that provides HTTPS (for example, GitHub Pages or Netlify).
2. Open the hosted URL in Chrome on Android.
3. Tap Chrome menu ⋮ and choose “Install app” or “Add to Home screen” if offered.

LIMITS:
- This package is not hosted online yet, so there is no live website URL included.
- It plays compatible local audio files only; it does not stream Spotify/YouTube or include copyrighted songs.
- For install/offline support, serve over HTTPS. The browser may vary in whether it offers installation for SVG app icons.
