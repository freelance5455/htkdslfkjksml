# Live Ludo Multiplayer

## Features
- 2–4 player room system
- Firebase Realtime Database synchronization
- Dice/turn synchronization
- WebRTC microphone voice chat
- Mobile responsive UI

## Firebase setup
1. Create a Firebase project.
2. Enable Authentication -> Sign-in method -> Anonymous.
3. Create Realtime Database.
4. Register a Web app and copy its config into `index.html`.
5. For a quick test, use temporary Realtime Database rules:
{
  "rules": {
    ".read": "auth != null",
    ".write": "auth != null"
  }
}
Do NOT use these open rules for a production game. Add validation/security rules before publishing.

## Important
The included Ludo board is a starter implementation. It synchronizes rooms/dice/turns, but it does not yet implement the full official Ludo token path, captures, six-extra-turn rules, safe squares, win detection, or matchmaking.

For production voice reliability, add a TURN server because STUN alone cannot connect every network.

## Run
Use a local HTTPS-capable host or deploy to Firebase Hosting / another HTTPS host. Browser microphone access requires a secure context (HTTPS), except localhost.
