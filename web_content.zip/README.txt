CPR METRONOME - SMOOTH BEAT VERSION

Fixed 120 BPM: exactly 500 ms between beats.
Uses Web Audio API look-ahead scheduling against the audio clock to reduce
gaps/stuttering caused by Android browser timer jitter.
Louder short double-harmonic digital tick with dynamics compression.
One green START / red STOP toggle.
No vibration, ads, analytics, external libraries, or network requests.
Screen wake lock is requested while running where browser support allows.
Stops when the app/page is hidden.

Set the Motorola media volume to a comfortable level. Browser/app volume
cannot override the phone's hardware volume limit.

This is an HTML web app ZIP, not an APK.
