FARM MONITOR v2.0.1  (index.html + icon.png, no build step needed)

GOOGLE ACCOUNT / DRIVE SYNC (how it works, like WhatsApp backup)
Users only tap "Continue with Google" and pick their Gmail. No ID is ever typed by users.
Data is kept in ONE file (farm-monitor-data.json) in the app's private Drive folder,
edited in place, synced automatically whenever the phone is online.

ONE-TIME DEVELOPER STEP (Google requires every app, WhatsApp included, to register once):
1. console.cloud.google.com -> new project -> enable "Google Drive API".
2. OAuth consent screen -> add scope .../auth/drive.appdata
3. Create OAuth client IDs:
   - Android: your package name + SHA-1 of your signing key (native sign-in, uses the phone's Gmail accounts)
   - Web: needed by the Capacitor plugin config (serverClientId)
4. Native Android app (recommended): wrap with Capacitor and install
   @codetrix-studio/capacitor-google-auth. index.html detects the plugin and uses it automatically.
5. Installed web app / PWA instead: put the Web client ID in index.html: var GCID_DEFAULT="....apps.googleusercontent.com";
Google blocks sign-in inside a plain WebView, so step 4 or 5 is required.

WEATHER: free Open-Meteo (no key). Default Dhaka; "Use my location" on the Weather page.
VACCINE GUIDE: general intervals only, always confirm with your vet.
