========================================================================
            NOVA ULTIMATE AI — STUDIO MULTIMÉDIA ULTIME
========================================================================

Ce projet est une suite logicielle complète pour la création multimédia par Intelligence Artificielle (Assistant, Générateur d'Images Anime/Manhwa Premium, Studio Manga, Studio Vidéo, Générateur Automatique de Films à partir de chapitres, Studio Musical et Créateur d'Applications).

------------------------------------------------------------------------
STRUCTURE DU PROJET :
------------------------------------------------------------------------
- index.html          : Page d'accueil et interface utilisateur unique (SPA).
- css/style.css       : Thème sombre futuriste, animations et responsive Android.
- js/app.js           : Orchestration de l'interface et gestion du pipeline client.
- backend/server.py   : Serveur Flask Python centralisant les clés API et moteurs IA.
- config_server.json  : Configuration des clés d'accès serveurs.

------------------------------------------------------------------------
INSTALLATION ET EXÉCUTION :
------------------------------------------------------------------------

1. UTILISATION IMMÉDIATE (Navigateur / Android) :
   - Ouvrez simplement le fichier `index.html` dans n'importe quel navigateur web (Chrome, Firefox, Safari ou navigateur Android).
   - L'interface se charge instantanément en Mode Hors-Ligne / Fallback avec toutes ses fonctions de démonstration et d'ergonomie.

2. CONNEXION AU BACKEND PYTHON (Pour les vrais moteurs IA) :
   - Installez Python 3.9+ sur votre machine ou serveur.
   - Installez les dépendances :
       pip install flask flask-cors requests
   - Lancez le serveur backend :
       python backend/server.py
   - Dans l'interface web, ouvrez les "Paramètres" (icône engrenage) et connectez l'URL `http://localhost:5000`.

------------------------------------------------------------------------
CONVERSION EN APPLICATION ANDROID (APK) :
------------------------------------------------------------------------
Ce projet est conçu pour être facilement transformé en APK native :
1. Utilisez des outils comme Website 2 APK Builder, Cordova, ou Capacitor.
2. Définissez le dossier racine contenant `index.html`.
3. Compilez pour obtenir votre fichier APK directement utilisable sur smartphone Android.

========================================================================
