Socialcip website starter

This ZIP contains index.html at the archive root, as required by the Zipped site uploader.
Extract or upload the ZIP as-is. This is a static UI prototype; authentication, uploads, chat, database and live social features require backend integration.
