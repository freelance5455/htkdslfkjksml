SÜRÜ TAKİP - ANDROID ANA EKRAN KURULUMU

Bu paket bir PWA/web uygulamasıdır; APK değildir.
Kurulum için dosyaların HTTPS destekli bir web adresinde yayınlanması gerekir.

1. ZIP dosyasını açın.
2. İçindeki tüm dosyaları (index.html, manifest.webmanifest, sw.js, icon-192.png, icon-512.png) aynı klasör yapısını koruyarak bir statik web barındırma alanına yükleyin.
3. Oluşan HTTPS adresini Android telefonda Chrome ile açın.
4. Chrome menüsünden "Uygulamayı yükle" veya "Ana ekrana ekle" seçeneğine dokunun.
5. Ana ekrandaki Sürü Takip simgesinden açın.

Veriler aynı cihazın tarayıcı depolamasında tutulur. Tarayıcı verilerini temizlemeyin ve Ayarlar / Yedek bölümünden düzenli JSON yedeği indirin.
Bildirimler bu prototipte uygulama açıkken kontrol edilir. Uygulama kapalıyken zamanında bildirim için sunucu destekli push sistemi gerekir.
