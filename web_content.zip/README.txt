Notepad Windows 11 — APK Ready

ارفع هذا ZIP إلى أداة تحويل HTML إلى APK.
اسم التطبيق: Notepad Windows 11
صفحة البداية: index.html
الأيقونة: icon.png
المشروع يعمل محليًا بدون إنترنت.
