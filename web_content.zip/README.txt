MR-KHORASANI 2.0.4 — LOGIN / FETCH FIX

نسخه MR,KHORASANI با کاربر ورود اولیه مشخص تنظیم شده است.

حساب ورود اولیه:
Email: alijim88887777@gmail.com
Role: OWNER / مدیر سیستم
Company: MR,KHORASANI

این حساب در Supabase Auth تأییدشده و عضویت آن در شرکت فعال است.
رمز عبور در فایل پروژه ذخیره نمی‌شود و قابل بازیابی به‌صورت متن ساده نیست؛ برای ورود باید همان رمز Supabase Auth این حساب استفاده شود یا از مسیر رسمی بازیابی/تغییر رمز Supabase استفاده گردد.

نکته امنیتی: رمز عبور را داخل APK، ZIP یا کد برنامه قرار ندهید.


اصلاح این نسخه: درخواست‌های GET/HEAD دیگر body ارسال نمی‌کنند؛ خطای WebView با متن «Request with GET/HEAD method cannot have a body» برطرف شده است. درخواست ورود با رمز همچنان POST است.
