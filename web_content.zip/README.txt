OʻZBEK HILL CLIMB — ilova papkasi

Papkadagi fayllar: index.html (oʻyin), manifest.json, sw.js, icon-192.png, icon-512.png

1) Hostingga yuklash (bepul, HTTPS kerak):
   - Netlify: app.netlify.com/drop saytiga shu papkani sudrab tashlang.
   - yoki GitHub Pages / Cloudflare Pages ga barcha fayllarni yuklang.
2) Telefonda havolani Chrome da oching, menyudan "Ilovani oʻrnatish" yoki
   "Bosh ekranga qoʻshish" ni bosing. Shundan keyin oʻyin internetsiz ham ishlaydi.
3) Play Market uchun: hosting manzilini pwabuilder.com ga kiriting va Android paketini yuklab oling.

Oʻyinni yangilasangiz, sw.js ichidagi CACHE nomini ("uz-hill-climb-v2" kabi) oʻzgartiring.
