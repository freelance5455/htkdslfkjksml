Upload ALL files in this folder to a free static host (Netlify Drop, GitHub Pages, Cloudflare Pages).
Open the https link in Chrome on Android > menu > Install app / Add to Home screen.
