АРЕНА СТЕНДІВ - проєкт для .apk

ВАРІАНТ 1 (з телефону, найпростіший)
1. Відкрий в інтернеті будь-який конвертер «HTML to APK» (або застосунок «Website to APK / HTML to APK builder»).
2. Завантаж цей архів або папку www (головний файл index.html).
3. Збери APK, завантаж і встанови (дозволь установку з невідомих джерел).

ВАРІАНТ 2 (комп'ютер, Android Studio)
1. Встанови Node.js і Android Studio.
2. У цій папці: npm install
3. npx cap add android
4. npx cap copy
5. npx cap open android - у Android Studio: Build > Build APK(s).

ВАРІАНТ 3 (без .apk)
Відкрий www/index.html у Chrome, меню > «Додати на головний екран».

ПРИМІТКА: піксельний шрифт підвантажується з Google Fonts. Без інтернету буде запасний шрифт.
