Vichika Launcher website ZIP. index.html is at the ZIP root for Zipped site import. This is a website, not a native APK.
