MasterFlow Trading - ZIP to APK package

Entry point required by the converter:
web/index.html

Upload/import this ZIP into the ZIP-to-APK app and build.
