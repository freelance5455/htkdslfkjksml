ShopTrack - Offline APK Ready Package

IMPORTANT:
- index.html is in the ZIP ROOT. Do not put it inside another folder.
- The app is self-contained: no CDN, no external JS/CSS, no internet required for core features.
- Data is stored locally in IndexedDB on the device.
- Sales, Purchases, Products, Customers and Reports work offline after installation.
- Purchase records remain separate from Customer/Sales screens.

APK BUILDER:
Upload the complete ZIP as-is. Set Start/Entry page to index.html if the builder asks.
For Android WebView, use local/offline assets and enable JavaScript + DOM storage + IndexedDB if those options exist.
Do NOT set a remote website URL.
