مكتبة كمال — version vert/blanc
- Écran d'accueil vert et blanc.
- Les boutons Copier/Partager/Supprimer ne sont plus affichés sous chaque بيت.
- Ils sont retirés de l'écran des œuvres.
- Ajout d'œuvres.
- Sauvegarde locale.
- Export/Import des œuvres depuis Paramètres pour transférer les nouvelles œuvres vers un autre téléphone.
- Pour qu'un téléphone neuf reçoive les œuvres ajoutées après installation, exporter le fichier JSON depuis l'ancien téléphone puis l'importer sur le nouveau.
- Les œuvres intégrées à l'application au moment de la création de l'APK seront présentes sur toute nouvelle installation de cet APK.
