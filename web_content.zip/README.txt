GoalPulse v4.0.0
Package: com.goalpulse.football
Mobile-first football app UI.
Home redesigned as the main football dashboard.
Bottom navigation: Home, Live, Leagues, News, Settings.
Theme: Light / Dark / System Default.
