JOGO DAS 140 CASAS — PROTÓTIPO OFFLINE

Conteúdo:
- index.html: jogo completo para abrir no navegador Android.
- README.txt: instruções.

Regras implementadas:
- 140 casas.
- 2 jogadores.
- 2 dados lançados em simultâneo.
- Para vencer é necessário chegar exatamente à casa 140.
- Se ultrapassar 140, recua a diferença.
- 10 bombas distribuídas até à casa 135.
- Nas bombas: recuar 5, recuar 10 ou avançar manualmente até à próxima bomba.
- 60 casas coloridas: 10 verdes, 10 azuis, 10 amarelas, 10 laranja, 10 roxas e 10 cor-de-rosa.
- Casas cor-de-rosa apenas entre 80 e 138.
- Nas casas coloridas: avanço/recuo manual e passar a vez.
- Botão geral para passar a vez.
- 3 escadas de subida e 3 de descida.
- Animação das peças e das bombas.
- Modo local no mesmo telemóvel.

MODO WI-FI:
- É usada a biblioteca PeerJS para criar a ligação entre os dois telemóveis.
- O telemóvel 1 toca em “Wi-Fi” > “Criar sala”.
- Partilha o código apresentado.
- O telemóvel 2 toca em “Wi-Fi”, escreve o código e toca em “Entrar”.
- O estado do jogo é sincronizado entre os dois aparelhos.
- É necessária ligação à internet/Wi-Fi para o serviço de sinalização PeerJS funcionar; depois a comunicação do jogo é P2P.
- Se a aplicação for empacotada como APK, deve manter acesso à internet e suporte WebRTC/WebView.


COMO TESTAR:
1. Extraia o ZIP.
2. Abra index.html no Android.
3. Pode jogar offline no mesmo telemóvel.

COMO CRIAR APK:
Este ZIP é um protótipo web. Para gerar um APK, use um empacotador Android/WebView compatível (por exemplo, Android Studio ou um serviço/IDE que aceite projeto WebView). O index.html deve ficar dentro dos assets do APK.


WI-FI — IMPORTANTE: o código da sala deve ser copiado exatamente como aparece. Os dois aparelhos precisam de acesso à internet para a sinalização PeerJS; podem estar ligados à mesma rede Wi-Fi.
