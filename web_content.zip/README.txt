नवयुवा दुर्गा पूजा समिति ऐप

महत्वपूर्ण:
1. Firebase Console > Firestore Database > Rules में firestore.rules का पूरा कोड Publish करें।
2. नई सुरक्षा में हर रसीद ownerUid से उसके Firebase user account तक सीमित है। केवल Admin सभी रसीदें देख/हटा सकता है।
3. Admin Dashboard में “पुरानी रसीदों की सुरक्षा ठीक करें” एक बार चलाएँ, ताकि पुराने receipts में ownerUid जुड़ जाए।
4. PDF सेव में पहले Android file picker, फिर सामान्य download और जरूरत पड़ने पर Share/Files fallback है। Print में Save as PDF चुना जा सकता है।
5. HTML-to-APK wrapper download/print APIs को रोकता हो तो native wrapper की अनुमति जरूरी होगी।
