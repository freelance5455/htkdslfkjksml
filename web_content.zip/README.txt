SIMON PHOTOGRAPHY APP
=======================

This is a real installable Progressive Web App (PWA).

WHAT IT INCLUDES
- Home/portfolio screen
- Gallery section
- Packages & UGX pricing
- Booking form
- Contact section
- Mobile bottom navigation
- Offline app shell
- Install-to-home-screen support

IMPORTANT BEFORE PUBLISHING
Open index.html and replace:
  const BUSINESS_WHATSAPP = "";
with your WhatsApp number in international format, without + or spaces.
Example format: 2567XXXXXXXX

TO TEST
1. Open the folder through a local web server (not by double-clicking index.html).
2. On Android Chrome, open the app URL.
3. Choose Chrome menu -> Add to Home screen / Install app.

NEXT STEP
Send me your business WhatsApp/phone number and the real photos you want in the gallery, and I can prepare a personalized version.
