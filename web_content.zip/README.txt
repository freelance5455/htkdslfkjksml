తెలంగాణ ప్లాట్స్ - Admin v5

ఈ వెర్షన్‌లో:
- ➕ కొత్త వెంచర్ యాడ్
- ✏️ Edit
- 🗑️ Delete
- 📁 ఫోన్‌లోని Gallery/Photos నుంచి ఫోటో ఎంచుకునే స్పష్టమైన బటన్
- 🖼️ ఎంచుకున్న ఫోటో preview
- 💾 ఫోటోలు Data URLగా సేవ్ అవుతాయి; App/Browser మళ్లీ తెరిచినా ఉండేలా మెరుగుపరిచాం
- 🔍 Search
- 📞 Call drawer
- 💬 WhatsApp
- Approval/RERA
- Photo zoom

వాడటం:
1. ఈ ZIP‌ను HTML-to-APK Builderలో upload చేయండి.
2. APK తయారు చేసి install చేయండి.
3. కింద/పై ఉన్న ➕ Add ద్వారా కొత్త వెంచర్ యాడ్ చేయండి.
4. "📁 ఫోన్‌లోని ఫోటోను ఎంచుకోండి" నొక్కి Galleryలోంచి ఫోటోలు ఎంచుకోండి.
5. Save నొక్కండి.

గమనిక:
- ఈ app డేటా అదే ఫోన్‌లో local storageలో ఉంటుంది.
- App data clear చేస్తే లేదా app uninstall చేస్తే డేటా పోవచ్చు.
- Approval/RERA వివరాలు అధికారిక పత్రాలతోనే నమోదు చేయండి.
