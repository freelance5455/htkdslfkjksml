WALLPAPER ORO — XUMURAA

- Afaan Oromoo motivational wallpapers
- Search, categories fi favorites
- Save PNG fi Share
- PWA installable + offline assets
- Android WebView bridge keessatti Set Wallpaper native ni deeggara

Web/PWA: index.html banuu ykn server local irraa tajaajilchi.
Android: folder android-app keessatti project Android Studio jira; bifa WebView fi WallpaperManager qaba.
