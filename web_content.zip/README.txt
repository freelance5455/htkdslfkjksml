GARAGEM KIDS V6

Versão corrigida para alertas sonoros.
- 8 carrinhos
- Escolha manual do carrinho no Início Rápido
- Som de aviso quando o tempo está acabando
- Som diferente e mais longo quando o tempo termina
- Botão Mais > Testar alerta para confirmar o áudio
- Notificações do sistema continuam disponíveis
- Funcionamento offline

Importe este ZIP no HTML to APK Builder e use index.html como página inicial.
IMPORTANTE: o primeiro toque do operador libera o áudio do Android/WebView. Faça um teste em Mais > Testar alerta antes da operação.
