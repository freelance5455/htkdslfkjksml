SMART SWITCH v1.6

Files:
index.html
style.css
app.js
server.js
sw.js
manifest.json
package.json

Run:
1. Put all files in the same project folder.
2. Install dependencies with: npm install
3. Start with: npm start
4. Open the displayed local/online address in a browser.

Important:
- The browser and ESP/Arduino controller must be on a network that can reach each other.
- The /relay endpoint expected by app.js is:
  http://CONTROLLER_IP/relay?state=ON&pin=5
  or
  http://CONTROLLER_IP/relay?state=OFF&pin=5
- The current assistant is a built-in app-focused assistant, not a cloud LLM.
- Browser notifications/push require HTTPS and user permission; full background push needs a push service/backend in a later step.
