SHAIKH BOX ERP — FINAL FUNCTIONAL FIX BUILD

Package: HTML-to-APK / offline WebView ZIP
Main file: index.html (ZIP root)

Changes in this build:
- Added multiple-company selector and Add Company workflow. Company-specific parties, bills, purchases, stock, khata, costing, cash work, labour, payroll, journals, items and counters are saved in separate company snapshots in localStorage.
- Strengthened party/vendor save validation and confirmation. New records are saved locally and rendered into lists/dropdowns.
- Added local autosave for unfinished form drafts. Committed business records still use their Save buttons and are written to local device storage.
- Added configurable GSTIN lookup using a GST/GSP provider endpoint and API key. This is NOT plug-and-play without an authorized provider endpoint/key and compatible response format. Review fetched details before saving. The public GST portal lookup uses CAPTCHA; no open unauthenticated government API is assumed.
- Improved app page tracking, back/forward edge gestures, pull-down refresh (rerenders data without clearing saved records), and hardware Back trapping. Actual exit on second Back depends on whether the Android WebView wrapper exposes an exitApp bridge; a plain HTML converter cannot force-close its host app.
- Existing billing, costing, reports, backup and other modules retained.

Important limitations:
- Data is stored in this WebView's localStorage. Clearing app data, uninstalling the app, or using a converter that changes WebView storage origin may remove or separate data. Export a JSON backup regularly.
- GST API lookup requires internet, CORS-compatible provider access, and the provider's valid endpoint/key. E-way bill/e-invoice government submission still requires the official/authorized integration credentials.
- Dieline graphics are schematic previews, not manufacturing-certified cutting dies.
- This build passed JavaScript syntax validation and ZIP integrity validation. Automated end-to-end browser testing could not be completed in this environment, and the build has not been tested on the user's physical Android phone. Please verify sample party save, invoice print, company switching, and Back/gesture behavior before live invoicing.


LOGIN / FIRST-TIME SETUP (added in FINAL LOGIN PROFILE build)
- App opens a branded loading screen for 10 seconds, then login.
- Initial login name: dhanwan
- Initial password: shaikh@1990
- On first successful login, fill owner name, mobile, email, company name and full address. GSTIN/PAN are optional.
- Use the Login/Profile button in the top bar to change login name/password later. Current password is required; new password must be at least 6 characters.
- Login credentials and first-time profile are stored locally in this browser/WebView. They are not cloud-verified and do not protect data against someone with direct device/storage access.
- GSTIN lookup requires a configured authorized GST/GSP API endpoint and key; it does not work automatically without those credentials.


SECURITY UPDATE (PIN + OTP + BIOMETRIC)
- After username/password login, first-time users complete profile, then mobile OTP verification, then create a 4-digit PIN. Later launches require PIN after the 10-second splash/login flow.
- OTP is enforced and deliberately does not accept a local/demo code. To actually send/verify SMS, configure an HTTPS OTP provider endpoint and API key in Login/Profile > PIN / OTP / Biometric Settings. Endpoint contract: POST JSON {action:"send",mobile:"+91..."}; verify: POST JSON {action:"verify",mobile:"+91...",otp:"123456"}; successful verify response must include {"success":true}. A compatible backend/provider adapter may be required.
- Biometric unlock requires an Android wrapper exposing window.AndroidBiometric.authenticate() returning a boolean/Promise. Plain HTML-to-APK converters do not consistently expose Android fingerprint APIs; PIN remains the fallback.
- PIN and API key are stored in WebView localStorage and are not hardware-backed secrets. Use native secure storage and server-side auth for production security.
- Syntax/ZIP checks do not equal physical-device OTP/biometric end-to-end verification.
