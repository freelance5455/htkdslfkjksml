Gestion Financière — V9

V8 reprend V6 et ajoute uniquement les modifications demandées :
- Mes ressources disponibles reste intemporel et indépendant du mois/année.
- Historique déplacé en bas de l'accueil.
- Historique avec accès aux données de Mes ressources disponibles.
- Dettes actuelles devient un bloc indépendant avec 5 lignes manuelles.
- Comptes pour enfants ajouté avec Enfant 1 à Enfant 5.
- Projet 1 à Projet 5 dans Mes ressources.
- Petite indication libre à côté de chaque compte dans Mes ressources uniquement (ex. Banque BESCAM).
- Code d'entrée demandé à l'ouverture/au retour dans l'application pour le profil actif.

Fonctionnement hors connexion et stockage local sur l'appareil.

V9 — modifications demandées :
- Ajout de la section « LES 10 COMMANDEMENTS DE GESTION FINANCIÈRE » sur l’accueil.
- Ajout de « QUELQUES PENSÉES POUR NOURRIR TA VISION FINANCIÈRE ».
- Conservation du système d’épargne progressive existant à 26 semaines.
- Ajout d’un deuxième système d’épargne indépendant à 30 cases, avec choix 500 / 1 000 / 5 000 FCFA.
- Ajout de sauvegarde/export et import des données au format JSON.
- Aucune modification volontaire des couleurs, formes et fonctions existantes hors des ajouts ci-dessus.

Nouvelle modification — Revenus prévisionnels :
- Ajout d'une tuile « REVENUS PRÉVISIONNELS » à l'accueil, juste à droite de « MES RESSOURCES DISPONIBLES ».
- Formulaire simple commun : intitulé, montant total attendu, provenance et date prévue.
- Choix entre « Versement unique » et « Versements multiples ».
- Versement unique : possibilité de confirmer la réception.
- Versements multiples : enregistrement de chaque montant réellement reçu avec sa date, suivi du total reçu et du reste à recevoir.
- Statuts automatiques : En attente, En retard, Partiellement reçu, Reçu intégralement.
- Historique des revenus prévisionnels placé dans la page Historique, dans une section identifiée « après la priorité 5 ».
- Données enregistrées localement et séparément selon le profil actif. Le montant attendu n'est pas ajouté automatiquement aux recettes existantes.


Mise à jour — TOP VERT (octobre 2026) :
- Dans « Revenus prévisionnels », ajout d'un encadré coloré avec le total des versements uniques, le total des versements multiples et le total général.
- Dans l'Historique général, les revenus prévisionnels sont résumés par ces trois totaux, sans les détails des paiements. Les détails restent dans « Revenus prévisionnels ».
- Séparation automatique des milliers par espaces dans les champs de montant du Planificateur budgétaire (revenu total et budget réel), de « Mes ressources disponibles » et du montant attendu des revenus prévisionnels.
- Dans chaque compte du Planificateur budgétaire, affichage sous « Budget affecté » du reste disponible, calculé à partir du budget affecté moins les montants du budget réel saisis dans le compte. Les dettes, hors calcul, affichent « Reste : Hors calcul ».
- Conservation du style existant et des autres fonctionnalités.
