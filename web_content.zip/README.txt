ApkForge: choose 'Zipped site' and pick this zip (index.html + style.css + app.js).
Hidden staff panel: tap the app name 5 times quickly. Login: admin / admin123
Top of app.js: DB_URL (Firebase), AI_URL, GOOGLE_CLIENT_ID, STAFF_PASS.
