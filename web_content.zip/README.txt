ZACH RYIE CHAT - DEMO
Fungua index.html kwenye browser ya simu kuona prototype.
Ina Login, Sign Up, Chat, Profile na Video Call UI.
Hii ni prototype ya UI; ujumbe wa kweli, accounts, notifications na video calls za watu wawili zinahitaji backend kama Firebase + WebRTC.
