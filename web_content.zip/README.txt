Veltrixa Finance — hardened web build
for-server/          upload to an HTTPS host (index.html + _headers for Netlify/Cloudflare Pages, or nginx-snippet.conf for nginx)
for-apk-converter/   the same app, as the folder the Web2App converter expects (MyLedger-Pro/index.html). Rebuild the APK from it,
                     and in the converter turn OFF camera, microphone, location, storage and media permissions: this app needs none of them.
Contains NO tests, tools, source, README or keys. Keep SELLER-ONLY/ (your private license key) offline and never upload it.

App-feel update: no pull-to-refresh / rubber-band, Android Back walks back through sections, offline / install notices (inline, so the
strict no-external-script design is kept). for-server now also ships manifest.webmanifest, sw.js and icons/ (installable + works offline);
its CSP gained only: 'self' for scripts/images/connect, manifest-src 'self', worker-src 'self'. for-apk-converter is unchanged apart from the shell.
In the APK converter turn OFF "pull to refresh" / "swipe refresh". Bump V in sw.js on every release.
