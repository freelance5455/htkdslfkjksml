TRAP TOWER — EDIÇÃO PROFESSIONAL
8 níveis, menu, HUD, arma, monstros, armadilhas, efeitos sonoros e controlos móveis.

COMO ABRIR:
1. Extraia este ZIP no ZArchiver.
2. Abra a pasta.
3. Abra index.html num navegador compatível.
4. Para transformar em APK, use estes ficheiros como base de um projeto WebView/Capacitor.

Tudo nesta versão é original e foi feito para funcionar offline, sem ficheiros externos.
