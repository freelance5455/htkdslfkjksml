RP CITY V6 — JOGO WEB LOCAL
============================

Conteúdo:
- index.html
- style.css
- game.js

Como testar:
1. Extraia o ZIP.
2. Abra index.html em um navegador com WebGL.
3. Para APK, importe a pasta no seu conversor HTML to APK.
4. Ative orientação Landscape/horizontal no conversor.

CONTROLES:
- Joystick esquerdo: movimentação do personagem / aceleração e ré do carro.
- Arraste no lado direito: câmera 360° e inclinação.
- ENTRAR CARRO: entra/sai quando estiver perto e o carro estiver parado.
- INTERAGIR: feedback contextual.
- TRABALHO: ganha $75 no ponto de trabalho (40,40), consumindo energia.
- Combustível diminui enquanto dirige.

OBSERVAÇÕES:
- O jogo é offline e não usa servidor nem CDN.
- A cidade, carros, NPCs e objetos são gerados pelo próprio JavaScript/WebGL.
- O modo horizontal é solicitado pela Screen Orientation API e há uma tela de bloqueio visual para retrato.
- Alguns conversores APK podem sobrescrever a orientação; nesse caso defina Landscape no próprio conversor.

V6 prioriza controles, movimentação, câmera, direção do veículo, interação e sistemas básicos.
