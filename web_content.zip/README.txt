Naam — Complete Offline Naam Jap App
Version 3 — Full Naam in Jap circle + Hinglish/Hindi/English

Features:
- 108 Jap = exactly 1 Mala
- 108-bead circular Mala progress
- Full selected Naam shown inside the Jap circle; long names wrap instead of being cut off
- Tap pulse only on the Jap circle
- Soft Jap sound with ON/OFF control
- First launch: user name + Naam selection
- Local/offline saved data
- 100+ built-in Naam + Custom Naam
- Dark / White theme
- Hinglish / हिन्दी / English language selector
- Milestones and certificate unlock after milestone (not at 0)
- Responsive Android mobile UI
- index.html is at ZIP root for ZIP-to-APK builders
