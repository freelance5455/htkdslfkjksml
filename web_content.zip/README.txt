Ludo Tournament - HopWeb Website Project
=========================================
এই ZIP-টি HopWeb-এর "Import by ZIP File of Website" অপশনের জন্য একটি সাধারণ website project।

Import:
1. HopWeb খুলুন।
2. Create Project চাপুন।
3. IMPORT PROJECT চাপুন।
4. Import by ZIP File of Website নির্বাচন করুন।
5. এই ZIP ফাইলটি নির্বাচন করুন।
6. Project খুলে Preview/Run করুন।

নোট:
এটি একটি frontend/demo tournament app। Real bKash/Nagad payment gateway, server database,
real authentication এবং real-money tournament backend সংযুক্ত নেই। সেগুলো আলাদা backend/API
ও নিরাপদ payment integration দিয়ে করতে হবে।
