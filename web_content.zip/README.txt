Contractor Pro V8.0.1 — APK READY PACKAGE

This ZIP is intentionally structured for HTML-to-APK/WebView tools that load:
appassets.androidplatform.net/web/index.html

Required structure:
web/index.html
web/manifest.json

Import this ZIP directly. Do not place the web folder inside another parent folder.

This is the frontend APK package. The backend architecture files are kept separately in the development package and are not needed by an offline HTML-to-APK wrapper.

V8.0.2 SPLASH LOCK
-------------------
- The supplied Contractor Pro artwork is bundled locally at: web/assets/contractor-pro-splash.jpeg
- The launch splash uses a full-screen cover layout and keeps the original image unchanged.
- Routine application updates should preserve this exact asset; do not replace or regenerate it unless the owner explicitly requests a new splash image.
- The image is packaged inside the web folder so HTML-to-APK builds continue to resolve it offline.
