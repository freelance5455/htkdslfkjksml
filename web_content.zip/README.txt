CRYPTO SIGNAL APP — SPCK EDITOR

Files:
- index.html
- style.css
- script.js

How to use:
1. Extract this ZIP in SPCK Editor or create a project and copy the three files.
2. Open index.html preview with internet access.
3. Binance mode uses public Binance market-data REST + WebSocket endpoints.
4. Choose BTCUSDT, ETHUSDT, BNBUSDT or SOLUSDT.

SHARK EXCHANGE:
This project does NOT pretend Shark is connected by default. In script.js, find:
const SHARK = {
  restBase: "",
  websocketUrl: "",
  ...
}
Set these only from Shark's official API documentation. Then adapt buildKlineUrl(), buildKlineRequest(), subscribeMessage(), and the WebSocket message mapping to Shark's actual documented request/response format. The endpoint shown in previous code alone does not establish whether Shark uses GET/POST, symbol field names, auth, CORS, or WebSocket topic format. Without those details a genuine connection cannot be guaranteed.
Never place private API keys or trading secrets in client-side JavaScript.

Signal logic:
- Uses completed candles and EMA 9/21/34, RSI(14), MACD and volume check.
- Final BUY/SELL requires all three timeframes (3m, 5m, 15m) to agree. Otherwise WAIT is expected.
- No system can guarantee 99% accuracy. This is educational analysis, not financial advice.
