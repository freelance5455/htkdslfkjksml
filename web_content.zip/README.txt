JARVIS V3 WebApp
Ouvrir index.html avec Chrome sur Android.
Pour transformer ce dossier en APK, utiliser un service de conversion WebApp -> APK qui accepte un ZIP.
