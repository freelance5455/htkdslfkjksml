NEXUS — mobile standalone messenger UI

Open index.html in a mobile browser. No server is required for the local UI.
Data is stored in this browser/device via localStorage.

Install:
- Android Chrome: browser menu -> Add to Home screen / Install app.
- iOS Safari: Share -> Add to Home Screen.

Notes:
- Wallet and USDT are local UI records only; they do not broadcast blockchain transactions.
- AI is not connected in this standalone build. A production AI integration should use a backend so secrets are never shipped in the HTML.
- For commercial deployment, add HTTPS, server-side auth, secure storage, backend APIs, logging/monitoring, rate limits, backups, privacy/terms, and a real database.
