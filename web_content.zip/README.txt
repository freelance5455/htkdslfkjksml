Superbactérias e Fagoterapia — App HTML Completo V6
Abra index.html no navegador.
Inclui: projeto, justificativa, problema de pesquisa, objetivos, hipótese, metodologia, conclusão, 20 tópicos, Fago AI local, simulação, quiz Fácil/Médio/Difícil, equipe, MOSTRATEC, FELUC e glossário.
Funciona offline. A Fago AI é uma base local de conhecimento; não é um modelo generativo online.
