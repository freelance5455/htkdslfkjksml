StudyGrid — APK Builder Package

This folder is prepared for a browser-based HTML/ZIP to APK builder.

IMPORTANT:
- index.html is at the top level of the ZIP.
- The app is fully self-contained and does not need a server.
- The background picker uses the normal Android file/gallery chooser.
- The focus timer is opened from the floating timer button.
- Sound and vibration feedback are disabled.

Suggested app details:
App name: StudyGrid
Package name: com.studygrid.app
Version: 1.0.0

Use the included icon-512.png as the app icon if the builder asks for one.
