Clinique Vétérinaire — Version enrichie, compatible avec un générateur ZIP → APK.
IMPORTANT : index.html est à la racine de l’archive.
Fonctions existantes : éleveurs et effectifs mixtes, produits/stock avec ancien stock et nouveaux arrivages (bouton dédié « Nouvel arrivage » qui ajoute la quantité au stock existant), catégories de médicaments, rendez-vous avec heure, lieux mémorisés, tri des éleveurs, cabinet, recettes/dépenses, alertes, bilans imprimables et sauvegarde JSON.
Nouveaux modules :
- Reproduction et échographie : saillie/insémination, date d’échographie, résultat, contrôle et mise bas prévue/réelle.
- Laboratoire : coproscopie, examen microscopique, prélèvement, résultat et compte rendu.
- Dossiers sanitaires : maladies, vaccinations, traitements, mortalités, effectif concerné et rappel.
- Comptes des éleveurs : actes facturés, avances, règlements et solde estimé par éleveur.
- Tournées : date/heure, éleveur, lieu, statut, kilomètres, frais de déplacement et honoraires.
Données stockées localement dans localStorage pour fonctionner hors ligne. Le bouton Sauvegarde exporte les données en JSON. Exportez régulièrement une sauvegarde avant de mettre à jour l’application.
À noter : les comptes et statistiques sont des outils de suivi interne et doivent être vérifiés par l’utilisateur. Les résultats de laboratoire et les décisions cliniques restent à valider par le vétérinaire.

Navigation corrigée : chaque bouton principal affiche sa rubrique, masque les autres et remonte en haut de page. Le bouton Accueil affiche le tableau de bord.

V8 - Interface : le tableau de bord occupe toute la largeur et propose des indicateurs ainsi que des raccourcis. Cliquer sur une rubrique ouvre une vue dédiée plein écran dans l'application, masque le tableau de bord et la navigation principale, et un bouton Retour permet de revenir à l'accueil.


VERSION 9 - fenêtres de saisie et sauvegarde rapide
- Les boutons Ajouter ouvrent maintenant une fenêtre de saisie plein écran, avec un bouton Fermer.
- Le tableau de bord occupe toute la largeur et la hauteur disponible de l'écran d'accueil.
- Sauvegarde rapide exporte toute la base locale (éleveurs, produits, rendez-vous, cabinet, reproduction, laboratoire, sanitaire, comptes, tournées et paramètres) dans un fichier JSON daté.
- Restaurer permet de réimporter un fichier JSON de sauvegarde. La restauration remplace les données locales après confirmation.
- Les données restent locales et l'application continue à fonctionner hors ligne.
Conseil : testez la restauration avec une copie de sauvegarde avant de remplacer les données importantes.


Version 10 : les boutons de sauvegarde et de restauration ont été déplacés dans la rubrique « Gestion du cabinet ». Le champ de sélection de fichier reste caché et ne s’ouvre que lorsque l’utilisateur appuie sur « Restaurer une sauvegarde » ; aucun bouton « Ajouter fichier » séparé n’est affiché. La restauration remplace les données locales : créer une sauvegarde avant de restaurer.
