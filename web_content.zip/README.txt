AspendosRecord - repaired HTML package

This package contains the app as a single HTML file to avoid missing JavaScript/CSS assets.
Upload the ZIP to your HTML-to-APK builder with index.html at the archive root.

Important: Test in the builder preview before creating/installing an APK. Confirm that navigation works and that a test shift saves and appears in Records. Storage is local to the app/browser instance; export JSON backups regularly.

This package has had its JavaScript syntax checked, but still needs functional testing in the builder preview and on Android.
