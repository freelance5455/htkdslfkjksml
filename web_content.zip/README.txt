Countdown — Pure Offline HTML Package

index.html is self-contained and has no external network dependencies.
Fonts are bundled locally under fonts/.

Put index.html at the ZIP root when converting to APK.
