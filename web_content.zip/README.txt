Catatan Hutang Rafif — Popup Pembayaran v2

Perubahan: bagian Menu Utama dan Kategori Hutang di Beranda dihapus. Tombol navigasi bawah dan fitur lain dipertahankan.
Buka index.html di browser Android untuk menguji.
