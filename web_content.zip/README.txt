NOVA PLAYER — FULL HTML EDITION

Upload this ZIP to your ZIP-to-APK builder. index.html is directly at the ZIP root.

Included:
- Dark premium Nova Player library interface
- Add multiple local video files
- Search, sort, grid/list layout
- All videos, folders (based on file paths where provided), recent and favorites tabs
- Video playback with seek bar, play/pause, +/- 10 second controls
- Playback speed: 0.5x to 2x
- Aspect ratio modes
- Subtitle file selection (WebVTT recommended; SRT support depends on WebView)
- Screen lock overlay
- Picture-in-picture request when supported by Android WebView/browser
- Sleep timer presets and custom 1–180 minutes; pauses video at expiry

Important limitations of HTML/WebView:
- This is not a native XPlayer clone. Codec support depends on the WebView.
- Selected local files and the library list are session-only; they are not scanned persistently like a native media library.
- Folder grouping depends on file paths exposed by the file picker.
- Equalizer, hardware decoding controls, background audio/video service, reliable timer when Android suspends the app, and full gesture-based brightness/volume controls require native Android implementation.
- For subtitles, WebVTT (.vtt) is the most reliable browser format. SRT may not work in all WebViews.
- Picture-in-picture requires builder/WebView support and may not be enabled by the converter.

Set the converter's start page to index.html if asked.
