# Sri Lakshmi Sai Surat Sarees — PWA

Files:
- index.html — app interface
- script.js — recovered billing-system JavaScript
- manifest.webmanifest — PWA installation metadata
- sw.js — service worker for app-shell/offline caching

Important:
The recovered JavaScript loads Chart.js and chartjs-plugin-zoom from jsDelivr when the Sales Report is opened. The app shell itself is cached, but those external libraries are not bundled locally.
