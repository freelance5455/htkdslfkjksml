FF SENSI PRO - 24 HOUR TRIAL BUILD
==================================
index.html = the full app (single file, at the root of this zip).

How the trial works
- The app records the time of the first launch. After 24 hours it locks completely and shows "Trial ended".
- The build also has a hard last day (see HARD in index.html, currently 2026-11-18 UTC), so reinstalling or clearing app data cannot extend it past that day.
- If the phone clock is moved backwards, the app locks.
- Limits: this lock lives inside the app, so a very determined user can still bypass it. A server check is needed for stronger protection.

To make a new trial build: change HARD (and optionally HOURS) in index.html, then zip again.
