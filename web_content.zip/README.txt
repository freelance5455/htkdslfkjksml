WEIGHT CONVERTER — ANDROID INSTALL NOTES

Included:
- index.html: working converter interface
- manifest.json: installable web-app settings
- sw.js: offline cache support

Important:
This is a Progressive Web App (PWA) prototype, not an Android APK. To install it like an app, it needs to be hosted on an HTTPS website first.

Simple route:
1. Upload the contents of this folder to a static hosting service that gives you an HTTPS URL (for example, GitHub Pages or Netlify).
2. Open that HTTPS URL in Chrome on your Android phone.
3. Open Chrome's ⋮ menu and choose "Install app" or "Add to Home screen".
4. Confirm installation.

The app performs conversions locally. Conversion history is stored in the browser on that device.
