BE SAFE — NORMAL ZIP APP PACKAGE

This ZIP contains a responsive browser-based prototype with a custom inline logo and polished UI.

HOW TO RUN
1. Extract this ZIP.
2. Open index.html in Chrome, Edge, or another modern browser.
3. Allow location permission if you want to test the location screen.
4. Add trusted contacts in the Contacts section.

INCLUDED
- Be Safe branding and inline shield logo
- SOS message preview, copy action, and opens SMS composer
- Trusted contact management saved locally in this browser
- Current location using browser geolocation and Google Maps link
- Demo device status, activity history, dark/light theme
- Responsive layout for mobile and desktop

IMPORTANT LIMITATIONS
This is a web app prototype, not an APK. A browser page cannot reliably detect three Volume Down presses while other apps are open, run an Android background service for that trigger, or send SMS silently. The SOS action opens the phone's SMS composer; the user must review and send the message. BLE-to-ESP32 support is not connected in this package. Do not rely on this demo for emergencies.
For a real installable Android app, these features require native Android implementation and testing on a physical phone.
