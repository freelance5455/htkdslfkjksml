Mora & OTOTOY Verifier — HTML-to-APK package

Upload this ZIP to HTML-to-APK Builder.

IMPORTANT:
- index.html must remain at the ZIP root.
- The builder must have its WebView file chooser enabled. The HTML-to-APK Builder documentation states its generated app implements the file chooser for <input type="file">.
- App name: Mora & OTOTOY Verifier
- Suggested package: com.topixcyber.moraototoyverifier
- The included icon.png is the original 1024x1024 app icon.

The app processes selected FLAC files locally in the WebView. It does not upload audio to a server.
