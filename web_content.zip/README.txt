PANEL GAMING HTML → APK
========================

Contenido:
- index.html
- styles.css
- script.js

Cómo convertirlo con tu app "HTML to APK":
1. Descomprime este ZIP.
2. Entra en "Archivo HTML a APK" o "Archivo ZIP a APK".
3. Si eliges ZIP, selecciona este archivo directamente.
4. Usa index.html como página inicial si la app te lo pide.
5. Pon el nombre que quieras para el APK.
6. Genera el APK e instálalo.

Nota:
Este proyecto es una interfaz local de configuración/visualización. No modifica Free Fire,
no inyecta código y no necesita root, Shizuku ni permisos especiales.
