MY TUK TUK - Designed by Ravindu
Version: 1.1 (project source)

Included features:
- Daily hire records and payment status
- Hire customer list with daily marks
- Credit hire records and partial payments
- School hire daily tracker and monthly totals
- Fuel expense records (date, amount, optional litres and note)
- Repair/maintenance expense records (date, description and amount)
- Edit/delete expense records
- JSON backup and restore (now includes fuel and repair expenses)
- Offline WebView interface using the packaged Android asset file URL

Build:
- Open this project in Android Studio, or run ./gradlew :app:assembleDebug
- The Gradle wrapper is included. The first build requires internet access to download Gradle and Android dependencies.

Note: The project source was syntax-checked for JavaScript and the ZIP archive was integrity-checked. An APK build could not be completed in this environment because internet/DNS access to services.gradle.org was unavailable.
