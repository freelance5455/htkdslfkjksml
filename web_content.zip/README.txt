NIL VAPE Manager — Android APK Project
این پروژه نسخه تک‌گوشی آفلاین را داخل WebView اندروید قرار می‌دهد.

ساخت APK:
1) Android Studio را نصب کن.
2) این پوشه را Open کن.
3) اجازه بده Gradle همگام‌سازی شود.
4) از منوی Build گزینه Build APK(s) را بزن.
5) فایل APK در app/build/outputs/apk/debug/ ساخته می‌شود.

نکته: این پروژه برای استفاده شخصی/تک‌گوشی است و اطلاعات را روی خود دستگاه نگه می‌دارد.
