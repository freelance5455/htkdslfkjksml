OFFLINE PHOTO ENHANCE — HTML PROJECT

WHAT IS INCLUDED
- index.html: app screen
- style.css: design
- app.js: local photo processing
- models/: reserved folder for a future offline AI model

IMPORTANT HONEST LIMITATION
This ZIP is an offline photo-enhancement starter. The one-tap Enhance button uses local brightness, contrast, color and sharpening algorithms. It does NOT contain a trained neural-network AI model, so it should not be advertised as true AI super-resolution or face restoration.

A real offline AI enhancer needs:
1. A compatible trained model file (for example an ONNX super-resolution model).
2. An offline inference runtime and its browser/WASM files.
3. Integration code and testing on the target Android phone.
Those model/runtime files are not included in this starter ZIP.

HOW TO USE
1. Extract the ZIP.
2. Open index.html in a modern browser.
3. Choose a photo, tap Enhance photo, then Save photo.
4. Internet is not needed after the files are on the device.

ANDROID APK
This is a website-style HTML project, not a compiled APK. To make an APK, import the extracted project into an Android WebView wrapper or an HTML-to-APK builder. Keep all project assets local and enable file access as required by that builder.

PRIVACY
Images are processed in the browser and are not uploaded by this project.
