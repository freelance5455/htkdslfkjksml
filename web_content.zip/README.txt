Ozbek Hill Climb

index.html faylini brauzerda oching (Chrome tavsiya etiladi).
3D uchun internet kerak: three.js kutubxonasi cdnjs.cloudflare.com dan yuklanadi.
Internet bolmasa, oyin 2D korinishda ishlaydi.
