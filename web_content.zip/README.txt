Ludo Royale Gold Edition — HTML ZIP-to-APK compatible version

This ZIP has index.html at the archive root, for converters that require a website ZIP.
Extract and open index.html in a browser to test. This is a 2D canvas Ludo prototype with gold/black styling and 3D-like glossy pieces, not a true 3D engine game. Check your converter's limits and test the generated APK before publishing.
