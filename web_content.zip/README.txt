Yaman Gider Takip - APKForge paketi

Bu pakette index.html bulunur. APKForge projesinde web uygulaması dosyası olarak kullanın.
Gider ekleme, düzenleme, silme, Ödendi ve Katma değişiklikleri localStorage içine otomatik kaydedilir.
Yedekle ve Yedeği geri yükle düğmeleri kaldırılmıştır. Sil düğmesi onay sormadan siler.
Not: Uygulama verileri uygulamanın yerel depolamasında tutulur; uygulama verilerini temizlemek veya uygulamayı kaldırmak verileri silebilir.
