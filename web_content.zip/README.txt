Baraa v16 — Luxe
- NEW hidden gift: "A star named Baraa" (replaces the old gift). Hold the two-arrows (sort) button in the notes screen for 3 seconds.
- NEW secret password screen (different look from the main lock). Secret word is NOT case-sensitive. Default: 1997.12.7
  After the correct word: the number "1" shows for 1.5 seconds, then the gift opens.
  To change the word: open the secret screen and tap "تغيير كلمة السر" (enter the current word, then the new one twice).
  The new word is saved on the device; clearing the app's data resets it to the default.
- NEW main lock screen: round keypad buttons with glowing dots (PIN 4 or 6 digits), or switch to a normal password.
  Existing passwords keep working (a numeric one shows the keypad, any other shows the text field; you can switch at any time).
- Total package size is under 5 MB (gift images/music re-compressed; gift lives in assets/gift/).
- v15: gift runs smoother (cached glow sprites, lighter canvas, app paused behind the gift, gift preloaded while typing the word).
- v16: fixed gift sky (preload size bug); default secret word is now Baraa.1

- music fix: gift music re-encoded (stereo, ~60kbps, proper header) + auto-resume if playback stalls; package ~4.8 MB; default secret word is now 1997.12.7 (year.month.day)
