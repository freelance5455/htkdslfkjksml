RTP Pragmatic Analyzer 3.0
===========================
Android project with the HTML interface embedded at:
app/src/main/assets/index.html

Main functions:
- Search built-in Pragmatic Play game RTP catalog.
- Enter a casino/game URL directly in the app.
- Load the URL in a hidden WebView.
- Search the loaded page for published RTP / Return to Player.
- Show the detected RTP back in the HTML interface.

Build:
- Android Studio / Gradle Android plugin 8.7.3
- compileSdk 35, minSdk 23
- Internet permission included.
