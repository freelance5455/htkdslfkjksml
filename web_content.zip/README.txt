Lulu Movers Survey Pro v30

Open lulu-survey-pro-v30.html in a modern browser. Data stays in this browser/device: use ERP > Backup to download a JSON backup regularly.
PDF and Excel export need internet access for their libraries.

New in v30 (benchmarked against the Move Survey Quote Pro store listing):
- Estimated weight from volume x density (density editable, default 150 kg per CBM). Shown on the form, saved cards and the survey PDF.
- Custom item size (cm) to CBM calculator in the inventory section.
- Quote builder in Charges: suggest lines from CBM and selected services, add packing materials priced from Materials & Stock, edit the rate card, use the total as the quote price. The breakdown prints on the Quote PDF.
- New services: Car / Vehicle Shipping and Pet Relocation.
- Saved surveys: Call, Map (Google Maps directions), advance Receipt (printable).

Kept from v29: ERP Home, Invoices & Payments, Expenses, Fleet, Payroll, Backup, Confirmed & Lost, Team Schedule paste entry, lead tools, and the sign-in and menu bug fixes.
The default rate card and density are placeholders: set your real prices in Charges > Quote builder > Rate card.
