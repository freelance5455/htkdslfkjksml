TUNNEL PROXY - real Android VPN-style proxy app (source)

What it does: you enter host, port, (optional) username/password of a SOCKS5
proxy, tap Connect, accept the Android VPN prompt, and all apps on the phone
use that proxy. Engine: hev-socks5-tunnel (tun2socks) + Android VpnService.

HOW TO GET THE APK (no PC needed beyond unzipping)
1. Make a free GitHub account, create a new repository.
2. Upload ALL files from this zip, keeping folders, including the hidden
   .github folder (the GitHub website uploader accepts folder drag-and-drop on
   a computer; on a phone use the "GitHub" mobile site in desktop mode or
   Android Studio).
3. Open the repo > Actions > "Build APK" > wait ~5-10 minutes.
4. Open the finished run > Artifacts > TunnelProxy-apk > download, unzip, install
   app-debug.apk (allow "install unknown apps").

OR build locally: install Android Studio, run the git clone line from
.github/workflows/build.yml, open this folder, Build > Build APK.

LIMITS
- SOCKS5 only. HTTP/HTTPS proxies are not supported by this engine.
- UDP (including DNS) needs the proxy server to support SOCKS5 UDP ASSOCIATE.
  If pages do not load but connect succeeds, the proxy probably lacks UDP.
- Written without a compiler available, so the first CI build may need small
  fixes. Send me the build log if it fails.
