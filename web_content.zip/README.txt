AION 2 Gildenbegleiter – HTML/CSS/JS für WebView-APK-Builder.
Startdatei: index.html. Alle vier Dateien zusammen hochladen bzw. als ZIP importieren.
Funktionen: Dailies/Weeklies, manuelle Aufgaben, lokaler Reset, DE/EN, Worldboss-Einträge, Notizen, Offline-Speicherung.
WICHTIG: Resetzeit ist nur ein Platzhalter, im Spiel prüfen. Keine automatisch synchronisierten Spieldaten, keine echten Hintergrund-Pushs und keine live synchronisierten Bosszeiten. Lokale Speicherung kann beim Löschen der App verloren gehen.
