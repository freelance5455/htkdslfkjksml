TPH-X FLIGHT RADAR - FRONTEND SOURCE
======================================

An interface constructed using pure responsive web standards (HTML5, CSS3, ES6 JavaScript) engineered specifically for compatibility with hybrid standard container formats (like Android System WebView APK compilation frameworks).

PRODUCTION & DEVELOPMENT CONFIGURATION
--------------------------------------
1. Open 'config.js' to change the targeting settings.
2. Update 'CONFIG.API_BASE_URL' to point to your live deployed backend service domain (HTTPS URL).

LOCAL PREVIEW & SIMULATION TESTING
----------------------------------
To preview without cors restrictions locally, spin up a fast static files system:
$ python -m http.server 8080
Then load up http://localhost:8080 or map directly inside your Android APK generation tools.
