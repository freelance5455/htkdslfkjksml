MY MONEY PREMIUM v2
====================
Offline personal finance app.

Features:
- Premium Myanmar-style modern UI
- Initial Balance
- Multiple Bank/Cash/Wallet accounts (account balance is included in total balance)
- Income / Expense tracking
- Daily income and expense
- Income/Expense charts
- Goals with progress
- Account transfer
- Personal calculator
- Backup / Restore JSON
- LocalStorage offline data

Open index.html in TrebEdit Preview, or package it as an Android WebView APK.
No server is required. Data stays on the device/browser/app storage.
