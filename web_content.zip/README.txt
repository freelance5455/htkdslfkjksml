AVRIX FINAL WEBSITE PACKAGE

Files:
- index.html: store website
- avrix-logo.jpg: AVRIX portrait logo

Included:
- Product catalogue and search
- Admin product add/delete
- Product image upload field and preview (requires Android WebView file chooser support)
- Add to Cart and Buy Now
- Customer name, phone and delivery address form
- Cash on Delivery order request sent to WhatsApp +91 8491003821
- Product prices and descriptions

IMPORTANT:
1. Extract the ZIP.
2. Upload BOTH index.html and avrix-logo.jpg into the same website/app project folder in APKForge.
3. Set index.html as the start page and rebuild the APK.
4. If tapping the photo chooser still does nothing, this is an APKForge/Android WebView limitation, not something HTML can fix. The APK builder must support Android WebChromeClient.onShowFileChooser / file upload and grant gallery/camera access.
5. Products are stored only in the same browser/device in this version. To make admin-added products appear on every customer's phone, a shared online database and secure admin login are required.
6. WhatsApp orders open a prefilled message to +91 8491003821. Customer must tap Send in WhatsApp; the app cannot silently send messages.
