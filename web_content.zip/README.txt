Max Call — kengaytirilgan til tarjimasi loyihasi

- Til tanlash ro'yxatida 245 ta til kodi/nomi mavjud.
- O'zbek tili boshlang'ich til sifatida qoladi.
- Bir nechta asosiy tillar uchun oldindan yozilgan interfeys tarjimalari bor.
- Qo'shimcha interfeys matnlarini tarjima qilish uchun MyMemory onlayn tarjima xizmatiga murojaat qiladigan funksiya qo'shildi; tarjimalar qurilmada keshlanadi.

MUHIM CHEKLOVLAR:
1. Bu 245 tilning hammasi to'liq va tekshirilgan tarjimasi degani emas. Onlayn xizmat ayrim tillarni qo'llamasligi, cheklov qo'yishi yoki noto'g'ri tarjima berishi mumkin.
2. Onlayn tarjima ishlashi uchun internet kerak.
3. Bu ZIP loyiha manbasi, APK emas. APK olish uchun Android loyihasiga qayta yig'ish va telefonda sinash zarur.
4. Haqiqiy internet audio/video qo'ng'iroqlari hali alohida SDK va server integratsiyasini talab qiladi.
