MR REMINDER — NOTIFICATION WEB APP

FILES
- index.html: app screen and reminder manager
- manifest.json: installable web-app settings
- sw.js: service worker for displaying notifications
- icon.svg: app icon

HOW TO TRY ON ANDROID
1. Extract this ZIP.
2. Put the folder on a secure HTTPS website, or run it on localhost. Browser notifications and service workers do not work reliably from a file:// address.
3. Open the hosted index.html in Chrome on Android.
4. Tap "Enable notifications" and choose Allow.
5. Tap "Send test notification" to check permission.
6. Add a reminder for a few minutes in the future.
7. Keep the app/browser open (it can be in the background) until the reminder time.

IMPORTANT LIMITATION
This is a browser-based prototype. Browser timers can be delayed or stopped when Chrome/Android suspends or closes the page. It does NOT guarantee an exact-time notification after the browser is fully closed or the phone is restarted. For reliable closed-app Android reminders, the project must be converted to a native Android app and use Android notification scheduling (with notification permission and exact-alarm handling where required).

Data is stored in this browser on this device. Clearing browser data can remove reminders.
