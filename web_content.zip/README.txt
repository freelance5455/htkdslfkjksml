
Bopi's Macaroon Tetris - Android APK Instructions

You have 2 options to get this as an APK:

OPTION 1 - Instant Install (PWA - recommended, works like APK):
1. Open index.html on your Android phone in Chrome
2. Tap menu (3 dots) -> Add to Home Screen / Install App
3. It will install as Bopi Tetris with its own icon, fullscreen, offline

OPTION 2 - Build real APK with PWABuilder (free):
1. Upload this folder to a GitHub repo or host it (or zip and upload to https://www.pwabuilder.com)
2. Go to https://www.pwabuilder.com -> Enter your site URL
3. Click Build -> Android -> Download APK
4. Install APK on phone (enable unknown sources)

This package includes:
- index.html (game)
- manifest.json
- icons
- Sanrio wallpaper background (embedded in html)

Rules: 8 lines = 1 level, speed up every 2 levels, confetti every level, Bopi the Bunny, macaroon colors, sounds.
