AIM OS 0.2 — ZIP pour outil « Site zippé → APK »

IMPORTANT : index.html se trouve à la racine de l’archive, comme l’exige le message d’erreur de l’outil montré en capture.

Utilisation :
1. Dans le convertisseur, choisissez ce fichier ZIP.
2. Appuyez sur Aperçu, puis créez l’application si l’aperçu fonctionne.

Cette version est une interface Web compagnon, pas une ROM Android. Elle présente des conseils d’optimisation mémoire et explique la RAM virtuelle. Une page Web ne peut pas augmenter la RAM physique ni activer une fonction système cachée. Le navigateur limite aussi l’accès aux informations matérielles.
