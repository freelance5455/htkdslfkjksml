SmartNurse – Gemini ücretsiz AI (çoklu yedekli sürüm)

Bu sürüm OpenAI kullanmaz. Google Gemini API kullanır.
Ücretsiz katmanı bulunan modeller için sırayla otomatik deneme yapar:
1) gemini-3.5-flash-lite
2) gemini-3.1-flash-lite
3) gemini-3.7-flash
4) gemini-3.5-flash
5) gemini-2.5-flash-lite

Bir model yoğunluk, geçici sunucu hatası veya kota/rate-limit nedeniyle cevap vermezse sonraki modele geçer.
Not: Ücretsiz API kotaları ve model erişimi Google tarafından değiştirilebilir; hiçbir üçüncü taraf servis %100 kesintisiz garanti edilemez.
API anahtarını yalnızca kendi cihazındaki uygulamaya gir; anahtarı kimseyle paylaşma.
