NEXYVERA app update V3
Contains the updated index.html for the existing NEXYVERA HTML-to-APK app.

New features:
- Water log: add 250 ml or 500 ml and save the count locally.
- Recent activity log: save the current workout timer session.
- Existing screens and settings are preserved.

How to use:
1. Import this ZIP into the same HTML-to-APK builder you used before.
2. Keep the same package/app ID and signing key if your builder supports updating the existing installation.
3. Build the APK and install it. If Android treats it as a separate app, the builder may be using a different app ID/signing key.

Important:
This is still a prototype. Health values are sample data; no real watch sensors, Bluetooth connection, emergency calling, or automatic reminders are implemented.
