Click Simülatör - HTML to APK Builder

Bu paket HTML to APK Builder gibi araçlara yüklenmek üzere hazırlanmıştır.
Ana dosya: index.html
ZIP'i açmadan yükleme desteklenmiyorsa ZIP'i çıkarıp index.html dosyasını seçin.
