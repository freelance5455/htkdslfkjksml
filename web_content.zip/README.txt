Open World 3D Android Project (v2)
- تحتاج اتصال إنترنت (Three.js من CDN).
- Build > Build APK(s) من Android Studio.
