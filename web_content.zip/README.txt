# Neon Dash — Endless Runner

This is a single-file web game.

## Fastest way to publish
1. Open https://app.netlify.com/drop
2. Drag the `endless-runner` folder (or upload its contents) into the page.
3. Netlify will give you a public `https://...netlify.app` link that you can share.

You do not need to install anything or buy a domain.
