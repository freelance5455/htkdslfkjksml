TOPOGEN QIBLA PRO - APK Conversion Package
==========================================

This zip contains the Topogen Qibla Pro HTML application ready for conversion to Android APK.

HOW TO CONVERT TO APK:

Option 1: Online HTML to APK Converters (Easiest)
-------------------------------------------------
1. Extract this zip.
2. Upload the index.html file to one of these free services:
   - https://www.htmltoapk.com
   - https://app.pwabuilder.com (for PWA then package)
   - Search for "HTML to APK converter online"
3. Follow their instructions to generate and download the APK.
4. Install the APK on your Android phone (enable "Install from Unknown Sources").

Option 2: Using Apache Cordova (For Developers)
------------------------------------------------
1. Install Node.js and Cordova CLI.
2. Create a new Cordova project:
   cordova create TopogenQibla com.topogen.qibla "Topogen Qibla Pro"
3. Copy index.html into the www/ folder (replace existing).
4. Add Android platform:
   cordova platform add android
5. Build:
   cordova build android
6. APK will be in platforms/android/app/build/outputs/apk/

NOTES:
- The app uses Tailwind CSS and Google Fonts from CDN. Internet connection is required for full styling on first load, or you can make it fully offline by downloading the assets.
- For professional survey use, enter DGPS coordinates manually for high precision.
- Phone GPS is only for rough location detection.

For any issues or customizations, contact your developer.

