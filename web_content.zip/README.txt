Daily Money Diary — APK READY FIXED (offline-safe build)

This ZIP is prepared for HTML/ZIP → APK WebView builders.

Important:
- Keep index.html at the ZIP root.
- IndexedDB is used for persistent on-device data.
- WhatsApp buttons were converted to APK/WebView-safe event handlers.
- Backup JSON export/import is retained.
- Excel export uses SheetJS when available and has an offline XLSX fallback when the CDN is unavailable.
- External Google Fonts were removed so the UI does not depend on internet fonts.
- Existing diary/customer/payment/expense/history/settings functionality is preserved.

Recommended: choose a builder that packages local HTML files into an Android WebView and enables JavaScript + DOM storage/file access.
