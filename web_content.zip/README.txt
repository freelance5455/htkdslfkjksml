PHIERRI PANEL - painel flutuante completo

Recursos:
- Janela completa com a interface HTML do painel.
- Arraste a barra superior para mover a janela.
- Toque no × para fechar a janela flutuante.
- Requer permissão Android "Exibir sobre outros apps".

Como compilar:
1. Abra o projeto no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Build > Build APK(s).

Este é o projeto-fonte, não um APK já compilado. A interface é demonstrativa e não controla nem modifica o jogo.
