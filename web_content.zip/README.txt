BIKE RIDER — HIGHWAY RUSH

Files:
- index.html: complete playable browser game.

How to test:
1. Open index.html in a modern browser (Chrome recommended).
2. Press START RIDE.
3. Desktop: use Left/Right arrows or A/D to steer; Up/Space accelerates; Down/S brakes.
4. Mobile: use the on-screen arrow, brake, and accelerate buttons.

Publishing:
- For a quick public web link, upload index.html to a static website host that supports HTML files (for example GitHub Pages or Netlify).
- To publish on Google Play, this HTML game needs to be wrapped in an Android app (for example using a WebView/Capacitor workflow), then built, tested, signed, and submitted through a Google Play Console account. Store approval is not automatic.
