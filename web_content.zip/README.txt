Eco Galaxy OS Prototype v1.0
================================
This is an offline HTML/CSS/JavaScript prototype that simulates the Eco Galaxy OS interface.

Included:
- Eco Galaxy home screen
- Lock-style branding
- App grid
- Settings
- Quick/basic system screens
- Phone, Messages, Calculator, Files, Camera, Browser placeholders
- About Eco Galaxy
- "Powered by Android" branding

To convert to APK:
1. Keep index.html at the ZIP root.
2. Upload this ZIP to an HTML-to-APK builder.
3. App name: Eco Galaxy OS
4. Suggested package: com.ecogalaxy.os
5. Build a signed APK for testing.

Note: This is a prototype/simulator, not a real Android operating system.
