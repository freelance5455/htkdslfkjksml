XITET FW PHZIN — EZZY
WEB-APK VERSION

Sube este ZIP a un convertidor HTML/ZIP a APK.
index.html está directamente en la raíz del ZIP.

Nombre: XITET FW PHZIN — EZZY
Package ID: com.xitet.fwphzin.ezzy
Versión: 1.0
Orientación: Horizontal
Key: EZZY-0019

Los controles Aimbot/Aim Rage son únicamente visuales y no modifican ningún juego.
