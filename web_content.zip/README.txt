SALATY PWA - Mobile Build
==========================
This is a browser/PWA version designed for phone-only APK builders.
Default location: Cairo, Egypt.
Prayer calculation method: AlAdhan method 5 (Egyptian General Authority of Survey).
API source: https://api.aladhan.com/
To package as APK, upload the ZIP to a PWA/HTML-to-APK builder that accepts a ZIP containing index.html at the root.
