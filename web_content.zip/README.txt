ENGLISH QUEST — DAY-WISE CAMPAIGN + 3 AMBIENT BGM OPTIONS
Entry page: web/index.htm

Choose one of three generated offline ambient music styles:
1. Adventure Journey — bright, forward-moving fantasy arpeggio.
2. Mystic Kingdom — softer, mysterious magical atmosphere.
3. Epic Expedition — deeper, more cinematic exploration pulse.

Select a track in the BGM dropdown, then tap Ambient ON. Changing the selection while music is playing switches tracks immediately. The volume slider controls music and effects.
All sound is generated locally through Web Audio; no external audio files or subscription needed.
Includes the 30 day-wise speaking prompts, grammar assignments and writing tasks, plus the existing XP/mission sound effects.
Tap Enable sounds once after launch to unlock audio in Android WebView.
Export a JSON backup before replacing an existing APK; local progress may not transfer automatically.
