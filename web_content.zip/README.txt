SAMIR DNS - HTML PROJECT
========================
index.html در ریشه پروژه قرار دارد.

این نسخه برای Web-to-App/HTML builders ساخته شده است.
امکانات:
- Splash و لوگوی SAMIR DNS
- Google / Cloudflare / Quad9
- تست زمان پاسخ شبکه
- رابط اتصال/قطع
- طراحی موبایل و بدون تبلیغات

توجه: HTML به تنهایی نمی‌تواند DNS کل سیستم Android را تغییر دهد.
برای DNS واقعی سراسری، نسخه Native Android با VpnService لازم است.
