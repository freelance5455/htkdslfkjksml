ACORDE FÁCIL — PROJETO INICIAL
================================

Arquivos:
- index.html: aplicativo completo (interface, diagramas e lógica).
- manifest.webmanifest: configurações de PWA.
- sw.js: cache offline após a primeira carga.
- icon-192.png / icon-512.png: ícones do app.

IMPORTANTE SOBRE ESTA VERSÃO
- O app funciona sem backend e não depende de APIs.
- O histórico fica no armazenamento local do navegador.
- O modo offline da PWA exige que o site seja servido por HTTPS e carregado pelo menos uma vez.
- Para virar APK, use um serviço confiável que empacote PWA/HTML em Android. Confira se o resultado é um APK instalável assinado; não envie chaves privadas.
- Este é um protótipo funcional inicial. A biblioteca de posições é intencionalmente limitada: quando uma posição não está cadastrada, o app informa isso em vez de inventá-la.
- Antes de distribuir, valide todas as digitações e posições com uma fonte musical confiável. A representação de dedos é uma aproximação inicial e pode precisar de revisão.

Teste local:
Abra index.html em um navegador para verificar a interface. A instalação PWA/offline completa exige hospedagem HTTPS ou um ambiente local compatível.
