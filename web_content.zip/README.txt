Purchase Calculation (G.S.T & I.Tax) — HTML to APK package

Files:
- index.html: the complete offline-ready calculator.

How to use:
1. Extract this ZIP on your phone.
2. Open your HTML-to-APK converter app.
3. Choose the extracted index.html (or select this ZIP if your converter supports ZIP projects).
4. Set the start/home page to index.html if asked.
5. Build/convert the APK, then install it on your phone.

Notes:
- The calculator's HTML, CSS, and JavaScript are self-contained; it does not require internet for its calculations.
- Tax rates saved by the page use browser localStorage. Whether they persist depends on the WebView/converter app's storage settings.
- Enable installation from the source app when Android asks. Only install APKs you trust.
