BACKROOMS: NO WAY OUT — ANDROID 16:9

Esta versión está preparada SOLO para Android.
La zona de juego mantiene una relación de aspecto 16:9.
En pantallas Android verticales se mantienen bandas negras para conservar 16:9.

Controles:
- Joystick izquierdo: movimiento
- Arrastrar en la zona derecha: mirar
- RUN: correr
- E: interactuar
- 🔦: linterna

Abrir index.html en un navegador Android compatible con WebGL y con Internet.
