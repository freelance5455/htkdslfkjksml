UNIVERSALAI - APK Forge uchun loyiha
Fayl: index.html (butun ilova bitta faylda: HTML + CSS + JS)
APK Forge'ga ZIP ni yuklang yoki index.html ni tanlang.
Eslatma: onlayn model uchun APK ichida INTERNET ruxsati kerak.
