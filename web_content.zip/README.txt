NIHONGO MASTER v2.2 — PROJETO WEB OFFLINE PARA ANDROID
====================================================

CONTEÚDO
- Dicionário local com 2.383 kanjis, 7.811 verbetes de vocabulário, 526 pontos gramaticais e 1.800 frases/exemplos.
- Abas de nível N5–N1, flashcards com repetição espaçada, exercícios, favoritos, progresso e backup local.
- Interface de dicionário simplificada: significado sem rótulos repetitivos e leituras on’yomi/kun’yomi em colunas fixas.
- Animações vetoriais da ordem dos traços a partir do KanjiVG para kanjis com caminhos disponíveis.
- Gráfico de contorno do pitch accent a partir do Kanjium quando palavra e leitura coincidem exatamente com a fonte. Pode haver variantes; o aplicativo informa quando há mais de um padrão.
- Leitor de textos: segmenta palavras conhecidas, mostra leitura opcional e glosas de dicionário. A glosa é aproximada e não é uma tradução gramatical completa.
- Plano diário visual com progresso da meta e sessão de revisão direta na tela inicial.
- Repetição espaçada adaptativa: intervalos crescem conforme o desempenho; respostas “Novamente” voltam à fila após 10 minutos.
- Funcionamento offline após os arquivos serem empacotados localmente. Não exige conta.

USO
1. Extraia o ZIP. index.html é a entrada.
2. Envie o ZIP/pasta ao construtor de aplicativo HTML.
3. Teste navegação, animações e dados no APK. A síntese de voz ainda depende do suporte do navegador/WebView e pode não funcionar no AppsGeyser.

NÍVEIS
N5–N1 são classificações aproximadas para estudo; o JLPT não publica uma lista oficial pública e definitiva de todos os itens.

FONTES E LICENÇAS
OpenJLPT: https://github.com/evanclan/OpenJLPT — manter OPENJLPT-LICENSE.txt e OPENJLPT-NOTICE.md; dados derivados sob CC BY-SA 4.0 conforme avisos do projeto e de suas fontes.
KanjiVG: https://kanjivg.tagaini.net/ — CC BY-SA 3.0; os caminhos vetoriais são distribuídos em stroke_data.js. Ver KANJIVG-LICENSE.txt.
Kanjium: https://github.com/mifunetoshiro/kanjium — pitch accent derivado de accents.txt; ver KANJIUM-LICENSE.txt e as atribuições originais.

IMPORTANTE
- Pitch accent só aparece quando existe correspondência exata entre palavra e leitura; ausência de gráfico significa ausência de correspondência, não ausência de acento.
- A visualização usa o primeiro padrão retornado para a leitura exata; se a fonte registrar vários, o app indica isso. O acento pode variar por contexto.
- O leitor segmenta pelo vocabulário local e a glosa concatenada não é uma tradução contextual.
- Nenhum áudio gravado foi adicionado.
- O ZIP foi gerado; ainda é necessário testar a experiência final no APK real.

Notas culturais
Algumas expressões comuns têm notas de uso contextual em português. São explicações didáticas para os termos selecionados, não traduções universais.

Atualização v2.1.1: as fichas de vocabulário e frases agora podem expandir uma seção opcional de ordem de escrita para os kanji presentes na palavra, reutilizando os dados vetoriais KanjiVG. O pitch accent original continua independente e não é removido quando a animação está disponível.

Atualização v2.2: adiciona painel de foco diário e melhora a repetição espaçada. Novos intervalos são adaptativos e os registros antigos continuam compatíveis. A meta diária conta avaliações de flashcards; exercícios de múltipla escolha não entram nesse contador.
