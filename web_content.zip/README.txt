Shambhu Tours and Travels - Android-friendly web app

Files:
- index.html: app screen with Marathi/English language switch and WhatsApp booking
- logo.png: generated logo
- manifest.webmanifest and sw.js: installable/offline PWA support

To use:
1. Extract this ZIP.
2. Upload the folder to a static web host that supports HTTPS.
3. Open the hosted link in Chrome on Android.
4. Chrome menu > Add to Home screen / Install app.

This is an installable web app prototype, not a signed Android APK. A native APK requires an Android build/signing step.
WhatsApp booking number is set to +91 8799819990.
