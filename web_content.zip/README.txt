BHAN GROUPS - NEARBY / ZAPYA-STYLE CONNECTION

This version adds a native Android Wi-Fi Direct nearby connection layer.

HOW IT WORKS
- Phone A opens ZYNKO and taps "Find Nearby Phones".
- Phone B also opens ZYNKO with Wi-Fi enabled.
- Nearby Android devices appear in the app.
- Tap a device to request a direct Wi-Fi Direct connection.
- After the Android P2P connection is formed, ZYNKO opens a local TCP
  channel between the two phones.
- Internet and the included cloud/WebSocket server are NOT required for this
  nearby connection.

REQUIREMENTS / LIMITATIONS
- Both phones must support Wi-Fi Direct / Wi-Fi P2P.
- Wi-Fi must be enabled.
- Android will ask for the required Nearby devices permission.
- The user must accept the Android connection flow where the OS requires it.
- This implementation currently provides the connection and text-message
  transport. It is NOT yet a complete Zapya replacement for high-speed folder
  transfer, QR pairing, group transfer, pause/resume, or background transfer.
- File transfer should be added as a native byte-stream protocol with progress,
  permissions and safe storage handling for a production release.

BUILD
Open in Android Studio, sync Gradle, then Build > Build APK(s).

STICKERS:
- 59 built-in original emoji-based sticker items are included.
- Stickers can be sent in the chat UI and relayed through the WebSocket server.
- They are emoji-style stickers rather than copied WhatsApp sticker assets.
