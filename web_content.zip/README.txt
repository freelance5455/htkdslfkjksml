K2 Signal Hub — пакет саме для HTML to APK.

У застосунку HTML to APK:
1) ZIP File to APK
2) вибери цей ZIP
3) якщо просить Start/Home file — index.html
4) назва: K2 Signal Hub
5) Internet permission — увімкнути (потрібно для Supabase)
6) зібрати APK

Це тестова збірка для перевірки реєстрації/входу та нотаток. Перед реальним службовим використанням потрібен окремий аудит безпеки.
