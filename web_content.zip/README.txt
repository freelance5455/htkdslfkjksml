KINO AI v1.1 — FULL LIGHTWEIGHT ZIP

Features:
Chat, voice-input interface, web-search-ready settings, video creator, 15-second maximum, 50 credits/generation, 200-credit personal display, multiple styles, image/document upload interface, notes, history area, settings/privacy.

This is a lightweight frontend. Real AI chat, web search, voice output, authentication and video generation require a secure backend/provider. No API keys are included and no payment system is included.

Use a ZIP-to-APK builder that accepts HTML/CSS/JavaScript projects.