Smart Store Manager – File Picker Fix

APK Forge import instructions:
1. In APK Forge, choose HTML to App / Zipped Site (the same workflow used previously).
2. Select this ZIP file: Smart_Store_Manager_FilePicker_Fixed.zip
3. Build using the existing app settings: App name Smart Store Manager; package name com.smartstoremanager.app.
4. Keep the old app installed and do not clear its data.

This ZIP contains index.html and this README. Test the file picker in the rebuilt app before importing the original backup.
