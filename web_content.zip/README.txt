SK MUSIC PLAYER — VERSION 2
Multi-page layout: Kiɗa (library), Mai kunnawa (player), Favorites, and Saituna.
Upload this ZIP using the Zipped site option. The ZIP contains index.html at its root.
Select audio files from the phone with Ɗora waƙoƙi. Playback is local/offline.
This version does not bundle copyrighted music or automatically scan device storage.
