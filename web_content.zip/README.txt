DIEL_VIR HTML-to-APK package

IMPORTANT: The website files are deliberately placed inside the top-level web/ folder because the HTML-to-APK WebView error showed it expects:
https://appassets.androidplatform.net/web/index.html

Upload the ZIP exactly as supplied. Do not zip the parent folder again and do not move index.html out of web/.

Expected ZIP structure:
web/index.html
web/manifest.json
web/sw.js
web/icons/icon-192.png
web/icons/icon-512.png

If the builder has a setting for the start page / entry file, use: web/index.html
If it asks for a web root folder, use: web

This package contains a self-contained educational web app. The PWA service worker is included for browser hosting; a native WebView may not use it for local appassets content, but all app content works locally without network access.

Material properties are approximate representative learning values and vary by material grade, composition, temperature and frequency. Consult manufacturer datasheets for engineering design.
