JT WINDOW CLEANING PRO — VERSION 4
- Customer Directory: searchable A-Z list of all customers with edit/profile actions and clickable Google Maps addresses.
- Analytics: all seven figures can be edited and saved; reset returns to calculated totals.
- Data remains local to this browser until cloud sync is implemented.
