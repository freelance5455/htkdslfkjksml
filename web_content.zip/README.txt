ATOM EXPLORER PRO - Android app source package

This ZIP is a web-app project, NOT an APK.
To create a private installable Android app, upload this ZIP to a trusted HTML-to-APK builder and select ZIP input.
Make sure index.html is at the root of the ZIP archive.
Do not publish to Google Play if you only want to install it on your own phone.
