Skill4Grow HTML-to-APK Builder launcher

Import this ZIP into the HTML-to-APK Builder. It opens the live Skill4Grow website at https://skill4grow.vercel.app/. The community popup and all course functionality are served by the live website, so deploy the matching Vercel website ZIP first. This is a launcher source, not a compiled APK.
