GOAL 25 — UPDATED OFFLINE SAVING APP

New features:
- Target/price ab aap khud set kar sakte ho.
- Target phone me save rahega.
- Savings, date aur note offline save hote hain.
- Progress bar aur milestones.
- Saving delete kar sakte ho.
- Home Screen shortcut/install ke instructions app ke andar hain.

USE:
1. ZIP extract karo.
2. index.html ko Chrome me open karo.
3. App ke andar "Target Change" se apna goal/price set karo.
4. Chrome ke menu me "Add to Home screen" / "Install app" option mile to use select karo.

IMPORTANT:
Local HTML file ko home-screen app ki tarah install karna har Android/Chrome version me same nahi hota. Agar option na aaye, index.html ko Chrome me bookmark/shortcut kar sakte ho.
