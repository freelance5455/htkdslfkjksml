TABLETOP B751 V0.2
Web app preparada para convertir a APK.
Incluye D4/D6/D8/D10/D12/D20/D100, cantidad, modificador,
historial, contadores configurables y guardado local.
Los botones de dados personalizados, mazos y juegos son placeholders para V0.3.
