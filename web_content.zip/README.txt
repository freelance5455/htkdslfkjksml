ZIP-to-APK website bundle. index.html is at the root of the ZIP.
This is a shortcuts launcher, not a native Facebook app or content filter.
Links open Facebook pages, and some destinations may redirect to Home or launch the official Facebook app.
Facebook may prevent embedding or force its own login flow; a ZIP-to-APK converter might not support every link.
Do not enter your Facebook password into an untrusted APK conversion website.
