MAZE ADVENTURE — POLISHED ONLINE/OFFLINE BUILD

OFFLINE
1. Open index.html in a modern browser.
2. Play normally; progress is saved in the browser.

MOBILE / LANDSCAPE
- The menu now has a dedicated landscape layout for short/wide phone screens.
- Buttons remain visible and scrollable on small screens.
- Friends opens immediately even when no online server is available.
- Touch/click handling was strengthened for mobile buttons.

ONLINE FRIENDS
1. Install Node.js.
2. In this folder run:
   npm install
3. Start the server:
   node server.js
4. Open index.html.
5. Set a profile username, then use GO ONLINE.

INTERNET SERVER
- The included server listens on port 8080.
- For internet multiplayer/social use, host server.js on a server and change
  window.MAZE_SERVER_URL in index.html from ws://localhost:8080 to your
  hosted WebSocket address.

NOTE
The current online system provides usernames, friend requests, presence,
invites, and chat. The maze itself is still local per player; synchronized
real-time maze movement is not included in this build.
