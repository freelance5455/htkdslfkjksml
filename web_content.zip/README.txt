NIGHT SHIFT: HOLLOW PIZZERIA — FREE ROAM + TALK UPDATE

Open index.html in Chrome or another modern browser.
Android: extract this ZIP, then open index.html with Chrome.
Rotate to landscape for the best layout.

NEW:
- Free roam mode: explore the foyer, dining room, party hall, kitchen, arcade, backstage and storage.
- TALK button: microphone speech recognition where supported, or type a message as a fallback.
- Animatronic replies with browser speech synthesis where available.
- Friendly words calm it; insults make it angrier.
- Office survival mode remains selectable.

Allow microphone permission for voice input. Some browsers block speech recognition on local HTML files; typed fallback still works.
This is an original analog-horror HTML prototype, not an APK or a full 3D engine.
