SmartAttend AI — Face Registration Prototype

Included:
- Existing Firebase project configuration retained.
- Teacher-only face registration using the teacher phone camera.
- Student face scan using the student's own signed-in Gmail and phone.
- Prototype face matching using face-api.js.
- Student dashboard filters the visible list to the signed-in student's own profile.
- Student attendance history view; new manual and face-marked records are copied to attendanceByStudent.
- Teacher can delete an active student profile while retaining old attendance records.

IMPORTANT BEFORE USING WITH REAL STUDENTS:
1. This is a demonstration prototype, NOT secure production biometric attendance.
2. Face descriptors are sensitive biometric data. Obtain explicit informed consent and provide a non-biometric alternative.
3. The current client-side app has no reliable liveness detection. A photo/video may fool face matching.
4. Firebase Realtime Database Security Rules MUST be configured before real use. UI role checks are not security.
5. The student history feature uses:
   smartAttendAI/attendanceByStudent/{studentId}/{YYYYMMDD}
   Old attendance records already stored only under attendance/{YYYYMMDD}/{studentId} are not automatically backfilled.
6. face-api.js and its model weights load from jsDelivr; camera access requires HTTPS and browser permission.
7. Do not make faceTemplates publicly readable. Configure rules so only the teacher can write/read all templates and each student can read only their own template. Also restrict attendance writes and history reads by authenticated email/UID.
8. The app retains the Firebase configuration from the supplied ZIP. Keep your existing project; do not create a new one.

Testing:
- Sign in as teacher: add a student, ask for consent, press Register Face, allow camera, capture.
- Sign in as that student's registered Gmail on a separate phone: press Scan my face and capture.
- Check teacher date-wise attendance and student own history.
