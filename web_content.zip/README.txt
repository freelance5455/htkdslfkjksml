MFUMO WA KUANDAA MATOKEO - SHULE ZA MSINGI

JINSI YA KUTUMIA
1. Fungua index.html kwa Chrome au kivinjari kingine.
2. Mipangilio: jaza jina la shule, mwaka, muhula, darasa na masomo, kisha hifadhi.
3. Wanafunzi: sajili namba, jina, jinsia na darasa.
4. Kuingiza Alama: chagua darasa, mwanafunzi, somo na alama kati ya 0-100. Hifadhi kila somo.
5. Matokeo ya Darasa: tengeneza jedwali, kisha unaweza kuchapisha au kupakua CSV.
6. Ripoti ya Mwanafunzi: chagua mwanafunzi na tengeneza ripoti; tumia Chapisha/Hifadhi PDF.
7. Nakala/Data: pakua nakala ya JSON mara kwa mara. Hii ni muhimu kabla ya kufuta data au kubadilisha kifaa.

MUHIMU
- Mfumo hufanya kazi bila intaneti, lakini data huhifadhiwa kwenye kivinjari/kifaa hicho.
- Nakala ya JSON ndiyo njia ya kuhamisha data kwenda kifaa kingine au kuirejesha.
- Madaraja ya A-E ni mipangilio ya kuanzia; rekebisha kulingana na mwongozo rasmi wa shule/wizara.
- Nafasi na wastani huhesabiwa kwa alama zilizowekwa tu. Hakikisha masomo na alama zimejazwa kabla ya kutoa ripoti rasmi.
- Mfumo huu ni toleo la msingi la offline, si mfumo wa mtandaoni wenye database ya pamoja.


BORESHO LA RIPOTI
Ripoti ya mwanafunzi sasa ina sehemu za taarifa binafsi, matokeo ya masomo, jumla, wastani, daraja, ukamilifu wa alama, nafasi, wastani wa darasa, somo lenye alama ya juu/chini, maoni ya mfumo, maoni ya mwalimu/mzazi na sehemu za saini. Hakiki taarifa na madaraja kabla ya kutumia ripoti rasmi.
