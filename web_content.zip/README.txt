GLASS LAUNCHER - WEBVIEW ZIP
IMPORTANT:
- index.html is directly in the ZIP root.
- No external CSS, JavaScript, fonts, images, or libraries are required.
- Use the converter's "ZIP File to APK" option.
- Keep Pull Refresh disabled and Page Loader disabled.
- Keep Bottom Tab Bar disabled.
- Package name can be: com.glass.launcher
- Version name: 1.0
- Version code: 1

The launcher is designed to work offline for its UI. Internet is only needed when opening web links such as YouTube or Google.
