CPH ENGINEERING BILL BOOK
==========================

Company:
CPH ENGINEERING
PRAKASH
9790623900

This is a simple offline Bill Book web app.
Open index.html in a browser.

Features:
- New bill
- Automatic bill number
- Customer details
- Multiple items
- Qty x Rate
- Discount and GST
- Grand total
- Save bill history in the browser
- Print / Save as PDF

IMPORTANT:
This first version stores bills only in the device/browser. It does not yet sync to cloud.
WhatsApp sharing can be added in the next version.
