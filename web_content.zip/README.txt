BTC Balance Scanner — revised HTML package

This revision uses a visible native HTML file input rather than a hidden input activated through a label. Upload this ZIP to the HTML-to-APK builder and rebuild the APK. If file selection still does not open, the builder's WebView likely lacks Android WebChromeClient file chooser support; use a builder that supports HTML file uploads or ask its developer to enable file chooser support.
