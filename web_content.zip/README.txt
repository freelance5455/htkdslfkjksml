XT KID AI All-in-One Starter

Included:
- Broker login/setup screen
- Screenshot upload for M15 and M5
- Manual checklist analysis
- Live-market demo scanner
- Learning history saved locally

Not included yet:
- Real MT5/Exness connection
- Real live prices
- Automatic AI image interpretation
- Cloud learning/backend

For real live data, use a secure MT5 bridge/backend.
Use only investor/read-only credentials. Never put a master trading password in an APK.
