PURFFLE STUDIO — ANY CONTENT CREATOR
====================================

This ZIP contains a mobile-friendly, standalone web app.
The required index.html is at the ZIP root.

Features:
- Content draft templates for stories, YouTube scripts, Shorts/Reels, social posts,
  blog outlines, business promotions, educational explanations, speeches, captions,
  and content idea lists.
- Language/style/length options.
- Editable output, copy, TXT download, and local browser save/load.
- No external dependencies; opens in a browser and works offline.

IMPORTANT:
This is a template-based offline prototype, not a connected generative AI service.
It does not generate AI images, voiceovers, or MP4 video. Those need a backend and
appropriate AI/media services. Do not place API secrets in client-side HTML.

For ZIP-to-APK converters, upload this ZIP as-is. If a converter rejects it,
check whether it requires index.html at the archive root.
