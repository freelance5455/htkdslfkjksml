LEARNOVA CREATOR STUDIO - AI UPGRADE (multi-page)

PAGES
index.html      Home dashboard: totals, recent projects, upcoming uploads
projects.html   All projects with search and status filters
overview.html / script.html / scenes.html / editing.html / thumbnail.html / schedule.html
                One page per project section (open a project to reach them)
calendar.html   Projects grouped by publish date (overdue, this week, later)
settings.html   Export / import JSON backups, reset, example project
assistant.html   AI Creator Assistant chat with project context and save-to-script option
help.html       Workflow guide

WHAT'S NEW
- Split into separate pages with shared navigation and a mobile bottom bar
- Autosave everywhere (no Save buttons) + readiness progress per project
- Word count and narration timing; reorder scenes; JSON import
- Fixed: template scripts showed literal "\n" instead of line breaks
- Script page: pronunciation notes, Shorts length warning, timing in seconds
- Scenes page: split script into scenes, per-scene production status, progress count
- AI assist (Groq, OpenRouter, Mistral or Claude): research outline, hook, script draft, tighten, scene visual prompts, titles, thumbnail and tags. Add your own API key on the Backup page
- AI video-idea generator (Home/Projects), month calendar, YouTube character counters (title/description/tags), script .txt download, saved project templates
- Installable PWA files (manifest + service worker) when hosted on HTTPS
- Existing v1 data is kept (same storage key)

Keep all files in the same folder. Open index.html in Chrome. Data is stored in this browser only - export backups regularly.


AI UPGRADE NOTES
- Backup page now includes an AI connection test and clearer key-safety guidance.
- Save the provider, model and key, then tap Test connection.
- AI requests need internet and a provider account/API key. Provider prices, free limits, and model availability may change.
- The browser-based setup is suitable for personal testing, not a public multi-user product. API keys saved in browser storage are not fully protected. For a public release, use a private serverless/backend endpoint and keep the key in server-side secrets.
- If fetch requests fail when opening index.html directly, host the app on HTTPS (e.g. GitHub Pages) and retry. GitHub Pages hosts static files only; it does not keep server secrets.
- AI-generated research and claims must be checked before publishing.


AI CREATOR ASSISTANT
- Tap AI Assistant in the navigation. Select a project to include its title, goal, script and scenes as context.
- Use the starter prompts or type your own question. Replies can be exported as a text file.
- To save the latest reply into the selected project, tap “Save latest AI reply as script”. This replaces the project script only after confirmation.
- Chat history is stored in this browser and can be cleared from the assistant page. Project content remains stored separately.
- For phone-only testing, keep the app on your own device. API keys stored in browser storage are not a secure vault; do not use this browser-key setup for a public app. A real secure backend requires an online server-side component, which is not included in this phone-only package.
