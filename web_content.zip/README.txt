# NEXUS V3 — ULTIMATE CYBER EDITION (Build 0.1.0)

This is the first phone-friendly browser prototype of the NEXUS V3 project.

## Run it
1. Extract `NEXUS_V3_ULTIMATE.zip`.
2. Open `index.html` in a modern browser.
3. For Web Crypto features (SHA-256), use HTTPS or localhost if your browser blocks cryptography on local files.
4. Audio starts only after user interaction, as required by mobile browsers.

## Included working prototype features
- Responsive neon-cyan command dashboard and module navigation.
- Animated CSS globe preview and OpenStreetMap search link.
- Simulated safe terminal (`help`, `status`, `date`, `modules`, `clear`, `about`, `echo`).
- Password generator using Web Crypto randomness.
- Base64 encode/decode.
- SHA-256 text hash and selected-file hash.
- Reaction-time mini game and sensitivity notes.
- Browser-visible device diagnostics.
- FPS readiness checklist and general game optimization tips.
- Original synthesized sound effects and ambient tones using Web Audio API.
- Optional AI backend connection field (expects a secure endpoint accepting JSON `{ "message": "..." }`).

## Important limitations
This is NOT yet a native Android APK and does not have privileged Android access.
A browser page cannot:
- Force-close apps, clear protected RAM, change CPU/GPU clocks, or guarantee FPS gains.
- Read another game's actual FPS or internal memory.
- Capture arbitrary Wi-Fi packets or scan networks without native permissions and an authorized implementation.
- Access another device's screen without explicit consent and a proper remote-sharing implementation.
- Run real operating-system shell commands.

Those capabilities require a separate Kotlin Android application, carefully scoped permissions, and in some cases a backend or dedicated hardware/API support.

## Planned next stages
1. Android wrapper / Kotlin bridge and permission model.
2. Three.js Earth with map provider integration.
3. Secure AI backend integration (never embed API keys in client files).
4. Native device diagnostics and supported Android performance information.
5. Consent-based remote support and authorized network lab tools.
6. Test on the target Android phone and package an APK.

## Security
Do not paste API secrets into `index.html`, `app.js`, or any client-side file. Do not test systems or networks without permission.
