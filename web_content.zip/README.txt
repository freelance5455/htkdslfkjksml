CRIME RUSSIA WEB PANEL
Залей index.html и папку assets на веб-хостинг.
HTML не подключается к MySQL напрямую: HTML -> PHP API -> MySQL.
API уже указан в assets/app.js.
Для реального изменения данных игрока нужны серверные PHP endpoint'ы с проверкой прав; чистый HTML не должен хранить пароль MySQL.