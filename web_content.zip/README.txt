Guess the Disease Game

Extract this ZIP on your phone and open index.html in Chrome. This is an HTML game, not an APK.
