StudyMate AI
=============
A mobile-friendly student AI assistant starter app.

Included:
- AI question interface
- Photo question interface
- Notes summarizer demo
- Quiz generator demo
- History using localStorage
- Progress screen
- Student profile
- Responsive mobile UI

IMPORTANT:
The included app is a frontend prototype. The AI buttons are prepared for API integration but do not call a real AI service yet. For production, connect a secure backend to your chosen AI API; never put a private API key directly in the HTML/JavaScript.

Run:
Open index.html in a browser.

For Android/Play Store:
Wrap the web app with a trusted WebView/Capacitor workflow, add app icon/splash screen, privacy policy, and configure your backend/API securely before publishing.
