BaatChit - Setup (ek baar)
1) https://console.firebase.google.com -> Add project (free) -> Build -> Realtime Database -> Create (Test mode).
2) Project settings -> Your apps -> Web (</>) -> config copy karo.
3) index.html kholo, "const CFG={...}" me apiKey, authDomain, databaseURL, projectId bhar do.
4) Zip -> "ZIP to APK" app (index.html root me hai). Camera/Mic permission ON rakho (call ke liye).
Bina Firebase ke app demo mode me chalta hai (sirf ek hi phone par).

IMPORTANT - Android APK Gallery Upload
--------------------------------------
BaatChit uses the standard Android/WebView <input type="file"> photo picker. The HTML side is prepared for direct Gallery/Photos selection.
If Gallery does NOT open after tapping "Gallery se photo" inside an APK, the APK wrapper must implement WebView file upload with WebChromeClient.onShowFileChooser (or enable "File Upload / File Chooser / Gallery access" in the APK builder). Android 14/15/16 use the system photo picker.
Target SDK: 35 (Android 15)
Minimum SDK: 24 (Android 7.0)
Package example: com.baatchit.chat
Version: 1.0.0 / Version Code 1

For Android Studio WebView, the host Activity should set a WebChromeClient and handle onShowFileChooser with ACTION_GET_CONTENT or ACTION_PICK for image/*, then return the selected Uri(s) to the WebView callback. Without this native bridge, a WebView APK can show the HTML button but cannot open the Android Gallery on some wrappers.
