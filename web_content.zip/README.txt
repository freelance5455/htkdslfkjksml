Jahon tarixi — Sulolalar Premium
1) index.html faylini Android brauzerda oching.
2) Offline ishlaydi; savollar uchun illyustratsiyalar HTML ichida yaratiladi.
3) APK uchun HTML-to-APK builder yoki Android WebView wrapper talab qilinadi.
Eslatma: savollar sertifikat-uslubida, ammo Germaniya bo‘limidagi ayrim savollar umumiy xronologik tahlilga asoslangan. Asl darslik rasmlarini qayta yuborsangiz, barcha savollarni aynan o‘sha jadvallarga moslab tekislash mumkin.
