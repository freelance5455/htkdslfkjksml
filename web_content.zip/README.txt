Laboratório de Probabilidades - versão offline

Abra index.html no navegador para usar imediatamente.
O ZIP contém um site estático local e não é um APK.
Para criar um APK, é necessário um empacotador Android que suporte sites locais ou um projeto Android WebView.
Nenhum arquivo usa URLs externas, serviços de terceiros ou permissões de rede.
