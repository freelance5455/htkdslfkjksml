TaskEarn demo website
=====================

Contents:
- index.html: responsive demo earning/task website.

How to use:
1. Upload this ZIP in the Zipped Site tool.
2. Preview it first.
3. This is a visual/front-end demo only. It does not pay real money and does not collect payments.
4. To launch a real earning platform, build a secure backend, user accounts, legitimate task/reward funding, anti-fraud controls, privacy policy/terms, and a verified payment integration. Do not promise guaranteed earnings or charge users a joining fee.
