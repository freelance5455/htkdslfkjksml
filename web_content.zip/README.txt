Kontrol Keuangan Pribadi - Dashboard Biru Gelap

Unggah index.html atau ZIP ini ke layanan pembuat APK HTML.
Data awal 176 transaksi disertakan. Simpan cadangan sebelum mengganti aplikasi lama.
Desain meniru gaya dashboard biru pada gambar referensi, dengan penyesuaian untuk layar tablet dan ponsel.
