Cosmetic Skins 1M — Marketplace style (updated)

- Dedicated ✨ Cosmetic section is kept.
- The first 300 catalog skins are placed into the Cosmetic section and marked ✨ Cosmetic + 🪽 Wing.
- The same 300 are also available through the Wing category.
- Marketplace-like grid, search, preview, favorites.
- One-skin PNG export.
- Multi-skin MC Skin Pack export keeps each skin as a separate PNG inside the pack.
- The app is WebToApp/ZIP-to-APK compatible.

Important:
The cosmetic/wing label is catalog/preview metadata in this prototype; it does not create 3D wearable wings on a Bedrock skin model.
The app fetches skin data online. The real dataset source is about 981k skins, while the app has a 1,000,000-slot catalog target.
