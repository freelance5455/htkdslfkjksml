AC APP STORE V3.0 - APKForge website ZIP

HOW TO BUILD THE APK
1. Open APKForge.
2. Choose "Zipped site".
3. Select this ZIP.
4. Build, download and install the APK.

WHAT THIS VERSION DOES
- Independent AC APP STORE design; no Google Play redirects.
- Search and Games / Apps / Tools categories.
- Admin-style local APK upload, app details, file size in MB and download.
- Local demo passcode: AC2026.

IMPORTANT LIMITATIONS
- This is an APKForge-compatible front-end prototype. Uploads are stored locally in the WebView/browser on the same device only.
- It does NOT create a public website, public URL, secure administrator account, or shared app catalogue.
- To make the store work for everyone online, a separately hosted backend/server and persistent file storage must be connected. The previous V3 Admin ZIP is a Python/Flask backend starter, not an APKForge ZIP.
- Change the demo passcode in index.html before sharing the ZIP; it is not secure authentication.
- Do not distribute APKs unless you own them or have permission. This prototype does not scan files for malware.
