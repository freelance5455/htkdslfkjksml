LoanDesk Professional Rebuild

FILES
- index.html: offline-first loan manager.

FEATURES IN THIS BUILD
- Black/red theme and responsive layout.
- Customer editing, name/mobile/loan-ID search.
- Loan entry save validation and readable Loan IDs.
- Daily/monthly loan tracking, collections, manual interest, discounted closure.
- Receipt image generation/share for new loan, payments, reminders and closures (Android share sheet support required; WhatsApp can be selected).
- Self Account, asset custody, reports, CSV export, JSON backup/restore.
- Spreadsheet import: CSV works offline. XLS/XLSX reading uses SheetJS from CDN and requires internet.

IMPORT HEADERS
Customer Name, Mobile, Address, Loan Type, Loan Date, Principal, Interest, Total Payable, Total Received, Outstanding, Status, Notes

Import is row-based (one loan per row). Existing customers are matched by mobile or name. Loan amounts/interest/paid/outstanding are imported as recorded, without recalculating monthly interest. Use a backup before importing.

APKFORGE
1. Extract ZIP.
2. Use index.html as the app's web page/start file.
3. Rebuild the APK in APKForge.

IMPORTANT
This is an HTML project, not a compiled APK. Data is stored locally in the WebView/browser on the device. Back up regularly. Sharing receipt images depends on Android Web Share support; otherwise text sharing fallback is used.
