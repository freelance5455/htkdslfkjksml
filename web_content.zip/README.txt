MOTY NEON RANGE v9
New animated loading screen with Moty Creations graffiti artwork, main menu, interactive level selection for levels 1-100, challenge information screen, sound toggle and quick play. Existing game rules retained: 3-second bubble expiry, immediate miss/game-over notification, levels with increasing bubble spawn speed and hit goals.
