Waves & Wish — installable web app
=====================================

This folder is a complete, self-contained static website: the same game that runs at
https://perchance.org/91j4lynqas, packaged so it can be installed to a phone or desktop
home screen and played offline.

FILES
  index.html            the game (single document)
  character.js          the sprite/icon generator it imports
  audio.js              the music + hero-voice engine it imports
  waves-and-wish-classic.html  the whole game as one file, using a classic (non-module) script
  manifest.json         app manifest (name, icons, fullscreen display)
  manifest.webmanifest  the same manifest under its other common filename
  sw.js                 offline service worker (cache-first)
  icon-192.png, icon-512.png, icon-maskable-512.png, apple-touch-icon.png

THE ONE-FILE VERSION
  waves-and-wish.html is the whole game in a single file with both modules (character.js
  and audio.js) inlined and nothing left to fetch. It needs no server, no manifest and no
  build: copy it to a phone and open it in a browser (or just double-click it on a computer)
  and it plays, offline, exactly like the hosted version. Use this one if a tool only accepts
  a single HTML file, or if you just want the simplest possible thing.

  waves-and-wish-classic.html is the same single file with the game script changed from
  <script type="module"> to a plain classic <script>. Bundled app builders that load pages
  from a file:// origin cannot run module scripts at all (the page loads but nothing runs);
  this variant works there, and everywhere else. Prefer it when an app-builder tool only
  accepts one HTML file.

HOW TO RUN / INSTALL
  1. Put all of the files in the SAME folder on any static host — GitHub Pages,
     Netlify Drop (https://app.netlify.com/drop), Vercel, Cloudflare Pages, an S3
     bucket, or even a local server (`python3 -m http.server`).
  2. Open that URL in a browser. On a phone, use "Install app" (Chrome/Android) or
     Share → "Add to Home Screen" (Safari/iOS).
  3. It launches fullscreen and keeps working with no internet connection.

Note: opening index.html straight from the filesystem (file://) will NOT work, because
its module imports would be blocked cross-file imports — use waves-and-wish.html for that.
The install prompt and offline mode need http/https because browsers only allow service
workers on real web origins.

REBUILDING
  The generator's source is the source of truth. From the perchance editor, the builder
  at src/app/build.js regenerates this whole folder + zip straight from the current
  index.html, src/character.js and src/audio.js, so the app always matches the live game.

Progress is saved in the browser (localStorage) on whichever origin you host it — it is
per-domain, so a game started on one host will not carry over to another.
