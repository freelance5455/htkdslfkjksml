VIBE SOCIAL MVP
================
This is the first lightweight prototype.

Included:
- Home video feed
- Reels screen
- Local music player
- Local chat demo
- Call screen demo
- Profile screen
- Mobile-first UI

Run:
1. Extract the ZIP.
2. Open index.html in Chrome.
3. On Android Chrome, use Add to Home screen for an app-like experience.

Important:
This first version does NOT have a real backend, accounts, internet video hosting, real-time chat, or real voice/video calls.
Those require a server/database and additional services.
Commercial music also requires appropriate licensing.
