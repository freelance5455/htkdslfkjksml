Relay Setting Assistant Pro
- index.html : خود برنامه (آفلاین؛ روی گوشی/کامپیوتر باز می‌شود)
- manifest.json + sw.js + icons/ : برای ساخت اپ (PWA یا APK)
ساخت APK: پوشه را روی هاست بگذارید و در PWABuilder.com آدرس را بدهید، یا با Capacitor/WebIntoApp فایل index.html را بسته‌بندی کنید.
آیکون: از تصویر شما ساخته شده؛ برای تعویض، icon-192.png و icon-512.png و apple-touch-icon.png را (مربع) جایگزین کنید.
