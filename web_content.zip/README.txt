Photo Studio Online — ZIP to APK project

ZIP में index.html root और web/index.html दोनों जगह है। यह browser-based photo editor है। फोन से फोटो चुनकर edit/save कर सकते हैं; इंटरनेट पर उपलब्ध public image URL खोलने का विकल्प भी है।

ZIP-to-APK builder में पूरा ZIP upload करें। APK builder के हर platform की requirements अलग हो सकती हैं; APK बनने की गारंटी नहीं है। यदि app खोलते समय web page error आए, तो यह ZIP नहीं बल्कि builder की asset path/WebView configuration की समस्या भी हो सकती है।
