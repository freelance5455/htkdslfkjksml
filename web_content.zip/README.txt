S SANSKAR AI — ZIP TO APK BUILD

Creator: Aryan Renacia
AI name: S Sanskar AI

IMPORTANT:
This package is specifically made for ZIP-to-APK / HTML-to-APK builders.
The ZIP root contains index.html.

FILES:
- index.html
- style.css
- config.js
- app.js
- README.txt

SETUP:
1. Extract the ZIP if your builder requires extraction.
2. Upload the ZIP/folder.
3. Make sure the builder's start page is index.html.
4. Build the APK.
5. Open S Sanskar AI.
6. Go to Settings.
7. Paste your NEW Gemini API key.
8. Select Gemini 3.8 Flash or Gemini 3.1 Pro.
9. Save settings.
10. Test chat and voice.

FEATURES:
- Gemini Interactions API chat
- Local chat memory
- Server-side Gemini conversation chaining
- Voice input where the WebView supports Web Speech
- Text-to-speech
- Image analysis
- Model selection
- AI name / user name / personality
- Android intent-style opening of supported web apps
- Android native bridge hook for future phone-control integration
- Mobile futuristic UI

LIMITATION:
A pure HTML-to-APK wrapper cannot provide full phone control by itself.
Screen capture, Accessibility actions, background services, notification reading and advanced phone automation require native Android APIs and a wrapper that exposes those APIs to JavaScript.

API KEY:
The real key is intentionally NOT included in this ZIP.
Enter it in Settings on your own device. Because a key placed in a client APK can be extracted by someone who obtains the APK, never distribute this APK containing your real key.

GEMINI:
The app uses the Interactions API for chat, with the current default model gemini-3.8-flash. Image analysis uses the compatible generateContent endpoint.
