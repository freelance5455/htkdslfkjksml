MR-KHORASANI 2.0.2
APK-ready web project. index.html is at archive root. All project scripts are classic/local.
Supabase is accessed over HTTPS after login; the APK does not depend on a CDN library.
