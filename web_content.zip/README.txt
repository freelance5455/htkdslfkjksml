GFX TOPUP — Connected User + Admin Demo

Folders:
- User_Panel/index.html : open the public User Panel
- Admin_Panel/admin.html : open the separate Admin Panel

Connection:
Both panels are designed to use the same browser storage keys from the included app.js.
For them to share localStorage reliably, host BOTH folders on the SAME origin (same domain, scheme and port), for example:
  /User_Panel/
  /Admin_Panel/

Important limitations:
- This is a front-end prototype, not a production backend.
- Opening separate files with file:// may prevent reliable shared storage depending on browser.
- Orders are not synced between different devices or browsers.
- The demo has no secure admin authentication and does not perform real payments/top-ups.
- For a live store, connect both panels to a PHP/MySQL backend, protect admin routes with server-side roles,
  store orders in a database, and integrate an authorized payment/top-up provider.
