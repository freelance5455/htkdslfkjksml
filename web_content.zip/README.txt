BROXY ADEM VIP - Web app prototype

This is NOT an APK. It is an offline-capable single HTML interface prototype.
On Android: extract the ZIP, open index.html in Chrome, then use Chrome menu > Add to Home screen (if available).
For a true APK, the project must be packaged and built with Android build tools.
All toggles are visual demo controls only; no game integration or cheating features.
