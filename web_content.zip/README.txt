COIN HUB — TOKENLESS INSIDE-WEBSITE TIKTOK PROFILE DEMO

Deploy this folder/ZIP to Netlify.

When a username is searched, the page first tries the optional official TikTok API.
If no token is configured (or the API is unavailable), the site automatically renders
TikTok's official Creator Profile Embed INSIDE the Coin Hub page. The visitor does not
need to be redirected to a separate TikTok page to see the embedded profile.

TikTok's official Creator Profile Embed can show creator profile information including
followers, following, likes and recent videos. TikTok controls the embedded component,
and some of its elements can link to TikTok by design.

No fake follower/like/view numbers are generated. Total profile views are not invented.
Private/underage accounts may not be embeddable under TikTok's rules.

OPTIONAL API:
TIKTOK_RESEARCH_ACCESS_TOKEN can still be configured in Netlify for the custom stats card.

PAYMENT:
This is a browser simulation only. No real payment, card details, CVV, OTP, or passwords
are processed by the checkout.

V5: Piece Find ON now also stops the demo purchase during processing and shows the configured Piece Find error before success. Piece Find settings are moved higher for mobile visibility.

V5: Piece Find ON also stops the demo purchase during processing and shows the configured Piece Find error before success. Piece Find settings are moved higher for mobile visibility.

LOGIN / PASSWORD (DEMO)
-----------------------
Username: admin
Initial password: 123456

The site now shows a login gate. After login, Settings contains a Panel Password section where the current password must be entered before setting a new password. Use Log out to return to the login screen.
IMPORTANT: this is a client-side demo login using localStorage. It is NOT secure authentication for a production/admin system. Do not use it to protect real accounts, payments, or sensitive data.
