ANATOMY EXPLORER — PROJECT NOTES

Files
- index.html: existing Arabic/French/English anatomy explorer with the interactive 3D viewer.

3D assets and dependencies
- The external full-body skeleton/muscle model is loaded from:
  https://cdn.jsdelivr.net/gh/Charleeh/ecorche@main/model/ecorche.glb
- Three.js 0.160.0 is loaded from jsDelivr.
- An internet connection is required when opening the page unless these assets are separately downloaded and hosted locally.

Attribution
- Écorché model by Charleeh, based on BodyParts3D and Z-Anatomy.
- Model licence: Creative Commons Attribution-ShareAlike 4.0 (CC BY-SA 4.0).
- Model/code source: https://github.com/Charleeh/ecorche
- Three.js: MIT licence.

Important educational limitation
- The skeleton and muscle layer comes from the cited Écorché model.
- The internal organs added in this edition are schematic Three.js geometries positioned for learning and interaction. They are not segmented medical-grade organ models and are not suitable for diagnosis or clinical measurement.
- Arabic/French labels are provided for the main mapped structures. If a source mesh name is not in the bilingual dictionary, the original mesh identifier is displayed with a neutral Arabic/French description rather than pretending a verified translation exists.
- This project is educational only, not a diagnostic or treatment tool.

Run
- Upload index.html to GitHub Pages or another static host, then open the hosted page in Chrome.
- Opening a page from file:// may be restricted by browser module-loading rules; hosting over HTTPS is recommended.
