SPINWHEEL STUDIO — ANDROID ZIP-TO-APK PACKAGE

This package is prepared for HTML/WebView-style ZIP-to-APK converters.

IMPORTANT: Keep index.html in the ZIP root. Do not put the files inside an extra parent folder when uploading if your converter expects index.html at the root.

FILES
- index.html: complete app (light theme, library-first navigation, play-only wheel view, edit-from-library, landing celebration effects)
- manifest.json: app name, launch page, and display settings
- service-worker.js: offline cache for supported environments
- icon.svg: app icon source

SUGGESTED CONVERTER SETTINGS
- App name: SpinWheel Studio
- Start page / entry file: index.html
- Orientation: Portrait
- Internet permission: Not required for normal use
- Local storage / DOM storage: ENABLED (important for saved wheels)
- JavaScript: ENABLED
- File access: ENABLED if the converter needs it for importing/exporting JSON backups

SAVING
Saved wheels and spin history use browser localStorage. In the APK builder, enable WebView DOM storage / local storage. The data stays on that app installation and is normally removed if the app is uninstalled or its app data is cleared. Export backups from inside the app before changing devices.

This is a web app package, not an APK. Your ZIP-to-APK converter creates the APK. Different converters have different requirements, so check that it supports local HTML files and WebView DOM storage.
