MIS TARJETAS - paquete para HTML2APK

index.html es la pagina principal y esta directamente en la raiz del ZIP.
La aplicacion funciona con HTML, CSS y JavaScript dentro de un solo archivo, sin dependencias externas, sin fetch y sin modulos ES.

Funciones incluidas: tarjetas, agregar/editar/cancelar/reactivar tarjetas, compras de contado y MSI, cargos recurrentes, reestructuras, creditos separados, resumen de pagos e importar/exportar respaldo.
