AIRPORT CONTROL 2D - Version 1.0
=================================

This is a lightweight, offline-first 2D airport arcade game.

PACKAGE CONTENTS
- index.html: complete game (HTML, CSS and JavaScript in one file)
- README.txt: these instructions

HOW TO BUILD WITH AN HTML TO APK SERVICE
1. Upload this ZIP archive.
2. Set the start page / entry page to: index.html (if requested).
3. Enable local/offline assets or offline mode if the service offers that option.
4. Build the Android APK and install it on your test device.

GAMEPLAY
- Tap START GAME.
- Tap + ARRIVAL to create an aircraft.
- Tap the aircraft, then tap a free gate (G1-G4).
- After it parks, select it and press DEPARTURE.
- When it reaches the runway holding point, tap the runway to complete departure.
- Avoid assigning an occupied gate.

NOTES
- All game logic and graphics are local; no network connection is required.
- This is a fictional arcade game, not a real air traffic control or flight operations tool.
- ZIP size target: under 5 MB. The final APK size depends on the HTML-to-APK wrapper.
