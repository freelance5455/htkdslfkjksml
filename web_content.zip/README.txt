ZEUS AI - PURE WEB APP APK EDITION

Upload these files to a static host or an online ZIP-to-APK/WebView builder.
Entry file: index.html
App name: ZEUS AI
Package: com.zeus.ai

This package is frontend-only. It has no Python backend or Ollama.
For live AI, put your HTTPS backend URL in API_BASE inside app.js.
Do not put private API keys in frontend JavaScript.
