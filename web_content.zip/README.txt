RBM 5-BUTTON PUBLIC MAGAZINE

BOTTOM NAV:
Home = public pictures
Names = creators featured in RBM
Upload = submit picture + choose regular or promotion
Payment = Mobile Money numbers and promotion information
Search = search title/name/category/details

MOBILE MONEY:
+260 966 385 074
+260 973 736 863

PROMOTION FLOW:
1. User uploads.
2. User chooses Promote.
3. User pays Mobile Money.
4. User enters the transaction/reference number.
5. Upload is stored as pending.
6. RBM verifies payment.
7. The RBM administrator changes the Firestore record to:
   promoted: true
   watermark: false
   paymentStatus: "verified"
8. The promoted item then appears at the top.

The supplied public web page cannot safely prove that a Mobile Money payment happened. Automatic payment confirmation requires a supported Mobile Money/payment-gateway API and merchant credentials. Do not mark payments verified solely from user input.

WATERMARK:
Regular uploads get RICH BOYYZ + email QR watermark.
Paid/verified promotions should be reprocessed by trusted server code to remove the watermark before being made public. The current client upload intentionally keeps watermark:true until admin verification.

SHARING:
Put your Facebook/TikTok/Instagram/X/etc. destinations in SHARE_LINKS inside index.html. Automatic posting to those platforms requires each platform's API/OAuth; a normal HTML page cannot silently publish to arbitrary accounts.

FIREBASE:
Replace firebaseConfig in index.html with your Firebase Web App configuration.
Enable Firestore + Storage.
Deploy firestore.rules and storage.rules.
The promoted/createdAt query may ask Firebase to create a Firestore composite index.

Security:
This is a public submission system. For production, add Firebase Authentication/App Check/CAPTCHA and an admin-only approval workflow. Firebase recommends Security Rules and authentication for production access control.
