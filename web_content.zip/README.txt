STONE SHOP — prototype de départ — direction visuelle luxe noir & or

CONTENU
- index.html : boutique responsive avec recherche, catégories, panier et formulaire de commande
- images/ : visuels produits de style studio noir et or intégrés aux 8 fiches
- manifest.json et sw.js : base pour une PWA installable depuis un navigateur compatible

IMPORTANT
- Les produits et prix sont des exemples de démonstration en USD. Les visuels sont des illustrations de présentation, pas des photos contractuelles de produits fournisseurs.
- Aucun paiement réel n'est activé.
- Les commandes ne sont pas envoyées à un serveur. Sans numéro WhatsApp configuré, le prototype télécharge un fichier texte de commande.
- Pour activer WhatsApp, ouvre index.html et remplace const whatsappNumber="" par le numéro du commerçant au format international, chiffres uniquement (ex. 243XXXXXXXXX).
- Ne recueille pas de données de carte bancaire avec cette page. Un prestataire de paiement certifié devra être intégré côté serveur.
- Pour installer comme application Android, héberge le site en HTTPS puis ouvre-le dans Chrome Android et utilise le menu « Ajouter à l'écran d'accueil ». Une publication Play Store est une étape distincte.
- Avant la mise en vente réelle : remplacer les produits/prix, définir livraison, retours, confidentialité, conditions de vente, et connecter un backend sécurisé.

Mise à jour : prix affichés en dollars américains (USD). Les montants sont des repères de démonstration pour des produits génériques, non des prix de marché garantis. Vérifier le modèle exact, le fournisseur, la disponibilité, le transport, les taxes et les frais d’importation avant la vente.
