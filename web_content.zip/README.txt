ମୋ ଗୀତ ବହି
1. index.html ଖୋଲିଲେ app ଚାଲିବ।
2. ନିଜର ଗୀତର ନାମ ଓ lyrics ଲେଖି "ଗୀତ ଯୋଡନ୍ତୁ" ଦବାନ୍ତୁ।
3. ତଥ୍ୟ ଏହି browser/device ରେ localStorage ରେ ରହିବ।
