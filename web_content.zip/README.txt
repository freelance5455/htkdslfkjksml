QUIZ ARENA FREE UPLOAD EDITION
Upload this ZIP to a ZIP-to-APK website.
Main file: index.html
This is a small offline starter edition designed for free upload limits.
It does not contain the previous 4,000,000-record database because that database is hundreds of MB and will not fit a 5 MB free upload limit.
