AC APP STORE V2.0 - APKForge ZIP project

BUILD:
1. In APKForge choose "Zipped site".
2. Select this ZIP. It contains index.html at the ZIP root.
3. Build APK, download, and install.

WHAT WORKS:
- Play Store-inspired AC APP STORE interface
- Search and Games/Apps/My uploads categories
- App detail pages
- Local APK upload using the file picker
- APK file size shown in MB
- Local APK download on the same device (IndexedDB storage)

IMPORTANT LIMITATIONS:
- This is a local/offline prototype. APK uploads are stored only in the app/browser on this device.
- Other users cannot see your uploads; it does not generate public URLs or shared reviews/ratings.
- Public uploads, public download URLs, shared ratings/reviews and user accounts need a hosted backend, secure authentication, malware scanning and persistent file storage.
- Catalogue entries are listings only and link to official Google Play searches. They do not contain third-party APKs.
- Only distribute APKs you own or have permission to distribute. Do not install unknown APK files.

FIXED BUILD:
This ZIP updates the sample catalogue buttons to direct Google Play app detail URLs.
Re-import this ZIP into APKForge using Zipped site and rebuild the APK.
If a specific app is unavailable in your country/device, Google Play may show its own unavailable page.
