Yaman Gider Takip - APK Maker için güncel HTML

APK Maker'a yüklemek için index.html dosyasını veya bu klasörün ZIP paketini kullanın.

Özellikler:
- Her ay tekrar eden başlangıç ve bitiş günü (1-31)
- Giderler başlangıç gününe göre sıralanır
- Toplam gider ve ödenen tutar ayrı gösterilir
- Ödendi işareti ay değişince otomatik sıfırlanmaz
- Gider ekleme, düzenleme ve silme
- Veriler cihazın tarayıcı depolamasında tutulur
