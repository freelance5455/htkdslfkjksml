Phoenix Insurance Reference BD - WebView package

Required Android WebView asset path:
app/src/main/assets/web/index.html

This ZIP contains web/index.html. When using an APK builder that accepts a ZIP or project assets, preserve the web/ folder and place it under the app's assets/ directory so the final APK contains assets/web/index.html.

The WebView URL https://appassets.androidplatform.net/web/index.html requires that exact asset path (when using AndroidX WebKit WebViewAssetLoader with /web/ mapped to assets/web/).
