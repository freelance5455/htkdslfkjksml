HACIENDA GUAYABITA — proyecto completo

Módulos: panel UA/ha y cabezas; mapa satelital/normal; GPS y detección del potrero dibujado donde cae la ubicación; registro de potreros; tropas y asignación de potrero; vacunas y próximas fechas; nacimientos y muertes que actualizan el conteo de la tropa; alimentos/sal/suplementos; lluvia en mm; trabajos agrícolas; respaldo JSON.

Limitaciones importantes:
- Este ZIP es el PROYECTO WEB, NO una APK compilada.
- El mapa y las bibliotecas externas requieren internet.
- GPS requiere permiso de ubicación y un contexto seguro (HTTPS o app correctamente empaquetada).
- Los datos se guardan en el almacenamiento local de este navegador/app; exporta respaldos regularmente.
- El área automática de polígonos es aproximada; para cálculos oficiales verifica las hectáreas.
- La detección de tropa usa el GPS actual y la asignación manual de tropa a potrero. No identifica animales individualmente ni rastrea GPS continuamente en segundo plano.
