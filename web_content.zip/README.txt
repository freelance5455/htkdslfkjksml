ANDROID WEB-TO-APK PACKAGE
Use the www folder with an Android WebView/PWA-to-APK packaging service.
App name: Deriv Synthetic Analyzer
Package ID suggestion: org.derivanalyzer.app
Portrait orientation; internet required.
