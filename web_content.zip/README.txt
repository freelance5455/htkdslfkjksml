EasyQuestionMaker — Android Print & Download integration

এই প্যাকেজে আছে:
1) app.html — APK-এর assets/web ফোল্ডারে থাকা HTML-এর Android bridge-সমর্থিত সংস্করণ।
2) MainActivity-bridge.kt — আপনার বিদ্যমান MainActivity-তে একীভূত করার Kotlin উদাহরণ।

গুরুত্বপূর্ণ:
- এটি নিজে থেকে নতুন APK নয়। APK-তে Native bridge যোগ করে Android Studio থেকে পুনরায় Build ও Sign করতে হবে।
- Kotlin উদাহরণটি একটি সাধারণ AppCompatActivity + WebView-এর জন্য। আপনার APK-এর প্রকৃত MainActivity/Gradle কাঠামোর সঙ্গে মিলিয়ে merge করতে হবে; বিদ্যমান Activity পুরোপুরি প্রতিস্থাপন করবেন না।
- HTML-এর asset path আগের APK-এর path অনুযায়ী রাখা হয়েছে।
- Download কোডটি Android 10 (API 29)+ ব্যবহার করে Downloads ফোল্ডারে ফাইল রাখে।
- Print চাপলে Android Print Framework খুলবে; সেখান থেকে Save as PDF নির্বাচন করা যাবে।
- Word তৈরির জন্য HTML-এ থাকা docx CDN লাইব্রেরি এখনো প্রয়োজন; তাই Word export-এর জন্য ইন্টারনেট/লাইব্রেরি লোড থাকা দরকার।
