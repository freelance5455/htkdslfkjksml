GoalPulse final web package for HTML/ZIP-to-APK builders.

Use these exact builder settings:
App Name: GoalPulse
Package Name: com.app.goalpulse
Version Name: 2.0.0
Version Code: 100

The ZIP is intentionally flattened so the builder can find index.html directly.
The app includes Settings -> API-Football key and a Live page.
Do not paste the API key into this ZIP or into chat; enter it inside the app.
