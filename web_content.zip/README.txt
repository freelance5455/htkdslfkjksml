Unser Vorrat – EAN-Produktdaten

Neu:
- EAN kann manuell eingegeben werden.
- „Produkt suchen“ ruft Open Food Facts auf und übernimmt Produktname, erkannte Kategorie und passende Einheit, wenn verfügbar.
- Produktbild wird angezeigt und beim Speichern als Bild-URL am Vorratsartikel gespeichert.
- Wenn EAN nicht gefunden wird, kann der Artikel weiterhin komplett manuell angelegt werden.
- Barcode-Kamera bleibt als separate Funktion erhalten.

Wichtig:
Vor der ersten Nutzung der neuen Bildspeicherung die Datei migration_ean_produktdaten.sql einmal im Supabase SQL Editor ausführen.

Open Food Facts ist eine gemeinschaftliche Datenbank. Die Daten können unvollständig oder fehlerhaft sein; deshalb werden die übernommenen Angaben vor dem Speichern sichtbar und können geändert werden.
