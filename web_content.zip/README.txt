SULTHAN AI — PROYEK HTML UNTUK APKFORGE
========================================

ISI ZIP
- index.html : aplikasi chat responsif dalam satu file.
- README.txt : petunjuk ini.

CARA MEMAKAI DI APKFORGE
1. Simpan file ZIP ini ke HP Android.
2. Buka ApkForge dan buat proyek aplikasi HTML/WebView baru (nama menu bisa berbeda).
3. Pilih impor proyek/ZIP jika tersedia, lalu pilih Sulthan_AI_HTML.zip.
4. Pastikan index.html berada di folder utama proyek, bukan di dalam folder bertingkat.
5. Jalankan Preview. Tes tombol chat, Pengaturan AI, dan Chat baru.
6. Build APK lalu instal untuk menguji di HP.

FITUR
- UI chat bergaya modern, responsif untuk layar HP.
- Mode demo agar UI bisa dicoba tanpa API.
- Pengaturan endpoint, model, dan API key untuk API yang kompatibel dengan format OpenAI Chat Completions.
- API key tidak disimpan ke localStorage; hanya ada di memori selama halaman aktif.

PENTING
- Mode demo bukan AI sungguhan.
- Untuk mengaktifkan AI, siapkan endpoint API yang benar, nama model, dan autentikasi yang sesuai.
- Banyak API tidak mengizinkan permintaan langsung dari WebView karena CORS. Jika gagal, buat backend/proxy milikmu dan hubungkan aplikasi ke backend tersebut.
- Jangan menaruh API key rahasia di APK yang dibagikan ke orang lain. Key yang ditanam di aplikasi klien dapat diekstrak. Gunakan backend dengan autentikasi dan pembatasan penggunaan.
- Jangan mengunggah data pribadi atau rahasia ke layanan AI yang belum kamu percaya.
- Ini adalah template HTML, bukan APK yang sudah dikompilasi. APK dibuat melalui ApkForge.
