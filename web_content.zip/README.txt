# Quiz OFPPT – TSGE (WebView fixed)

The WebView error:
`https://appassets.androidplatform.net/web/index.html`

is fixed by putting the HTML in:
`app/src/main/assets/web/index.html`

and loading it through AndroidX WebViewAssetLoader.

## Build
Open this folder in Android Studio, allow Gradle to sync, then:
Build > Build APK(s)

## Important
Do not move `index.html` out of `app/src/main/assets/web/`.
