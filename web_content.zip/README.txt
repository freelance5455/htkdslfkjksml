YellowgoTaxi Offline Bill Book — Starter
1. index.html is a single-file prototype intended to work offline when opened locally or bundled into an Android WebView app.
2. Bills are saved in the device browser/app localStorage. Clearing app data or uninstalling may delete saved bills; export/print important bills.
3. PDF/Print uses the Android print dialog when supported. WhatsApp sharing needs WhatsApp installed and typically an internet connection.
4. This starter is not yet an APK. To make a true installable APK, bundle index.html as a local asset in an Android WebView wrapper/build service and test on your phone.
5. Brand contact shown: 9080151265. Add the exact logo image later if desired.
