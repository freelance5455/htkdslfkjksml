MUKESH ♥ MAUSUMI — Acode starter project

IMPORTANT
- This is a web app (HTML/CSS/JavaScript), not a compiled Android APK.
- Both people can use it from their phones after it is hosted online.
- Firebase is required for accounts and syncing between phones.
- This starter gives live in-app syncing. Push notifications while the app is closed are NOT configured; that needs Firebase Cloud Messaging plus a service worker and deployment setup.

SETUP
1. Open https://console.firebase.google.com/ and create a Firebase project.
2. Add a Web App in Project settings and copy its firebaseConfig.
3. Open app.js in Acode and replace all PASTE_... values with your real Firebase config.
4. In Firebase Authentication > Sign-in method, enable Email/Password.
5. In Firestore Database, create a database.
6. Open Firestore Rules and paste the contents of firestore.rules, then Publish.
7. Host the folder using Firebase Hosting (recommended) or another HTTPS static host. Do not expect Firebase login to work reliably from a file:// URL in Acode preview.
8. Open the hosted link on both phones. Each person creates their own account.
9. First person taps “Create couple code” and privately sends the 6-digit code to the partner. Partner signs in, enters code, and taps Join.

SECURITY NOTES
- Keep your Firebase config in the app; Firebase web config is not a password. Firestore Rules protect the data.
- Never share account passwords. Share the couple code only with your partner.
- The included rules are a starter. Test them in Firebase Rules Playground before real use.
- The first account creates the couple room; the second joins it. Do not create multiple rooms by mistake.

WHAT WORKS
- Email/password sign up and sign in
- One private couple room (up to two accounts)
- Wishes and personal notes
- Live updates while both are online
- Replies and mark wish completed

NOT INCLUDED YET
- Push notifications when the app is closed
- Image uploads, voice notes, APK packaging
