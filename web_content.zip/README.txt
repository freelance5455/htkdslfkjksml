SUKEY GAMING PANEL — Android project

PROJECT CONTENTS
- app/src/main/assets/index.html: mobile gaming dashboard UI and in-app controls
- MainActivity.java: Android WebView activity
- Gradle build files: Android Studio/compatible cloud build project

BUILD ON YOUR PHONE
1. Extract this ZIP using a file manager.
2. Open the extracted project in an Android Gradle build environment that supports Android projects, or upload it to a trusted cloud Android build service.
3. Build a debug APK.
4. Download the APK and install it. Android may ask you to allow installation from that source.

NOTES
- Requires Android SDK platform 35 and Gradle/Android Gradle Plugin support.
- This project is source code, not a prebuilt APK.
- The dashboard controls only change in-app preferences. They do not change system FPS, DPI, touch drivers, or game files.
