JIN MENTALITY web preview
Open index.html in a browser or upload the ZIP to a converter that accepts website ZIPs with index.html at the archive root.
This is a web preview only. It does not perform automatic cross-app scroll detection or app blocking. Those require a native Android implementation and appropriate user-granted permissions.
