GLOW LINK - ÇALIŞAN WEB DEMOSU
=================================
Bu paket tarayıcıda çalışan bir Glow Link arayüzüdür. Verileri tarayıcının localStorage alanında saklar.

Yönetici demo hesabı:
E-posta: glowlink@official.local
Şifre: demo

İçerikler:
- Giriş / misafir girişi
- Profil ve ayarlar
- Glow Link hesabında mavi doğrulama tiki
- Takip et / takipten çık ve takipçi sayısı
- Beğeni +1/-1
- Video izlenme sayacı
- Video ekleme ve kendi videosunu silme
- Arama
- Yalnızca yönetici hesabında görünen "Diğer Hesapları Görüntüle" paneli

NOT:
Bu sürüm gerçek sunucu/Firebase backend'i içermez. Gerçek kullanıcıların farklı cihazlarda aynı verileri görmesi için Firebase Authentication + Firestore + Storage entegrasyonu gerekir.
