Advisor Connect — Offline Recruitment Follow-Up App
1. Extract the ZIP.
2. Open index.html in Chrome on Android.
3. Candidate data is saved locally in the browser/device using localStorage.
4. Keep a backup of browser/app data before clearing site data.
This version is a standalone offline web app and does not connect to Kotak Life systems.
