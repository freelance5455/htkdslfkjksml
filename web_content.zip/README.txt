ZEN FINAL APK-READY PACKAGE

Main app: index.html
PWA files: manifest.webmanifest, sw.js
Icons: icons/icon-192.png and icons/icon-512.png

IMPORTANT UI UPDATES
- Zen is centered.
- Main buttons are smaller.
- "Built by Mahesh" sits at the bottom.
- Subjects + is fully usable for adding subjects.
- Built-in subjects can never be removed.
- Custom subjects can be removed.
- The subject list scrolls when it gets long.

FASTEST WAY TO APK WITHOUT GITHUB
Use a ZIP-to-APK service that accepts a complete web project. One current option is https://www.htmltoapp.dev/ . Upload this ZIP, set the app name to Zen, choose the icon, build, and download the signed APK. Its site currently says it accepts HTML/ZIP input and produces a signed Android APK without Android Studio.

BACKUP
Zen stores sessions, custom subjects, the subject queue, and active study/break timestamps on the device. Use Export before moving to another device, then Import the JSON backup.
