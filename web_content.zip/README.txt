خطوتي — نسخة مطابقة عالية الدقة لتخطيط لوحة VISION HABIT SYSTEM في الصورة المرجعية.
- عرض أفقي/فيلم، وتدور تلقائياً على الهاتف في الوضع العمودي.
- نفس الهيكل العام: الشريط العلوي، My Habit، Daily Question، Today، Months، 4 أسابيع، Daily Tracker، Consistency Chart، Monthly Habit Heatmap، Weekly Analysis، Habit Performance، Random Notes، Skill Balance، Achievement.
- خلايا العادات قابلة للنقر ويتم حفظ حالتها على الهاتف عبر LocalStorage.
