MY TUK TUK - Website APK Builder package

This ZIP is prepared for a web-to-APK builder that accepts an HTML/website ZIP.
Upload this ZIP as-is. index.html is at the ZIP root. The app works offline and stores its records in the device's local WebView storage.

Features: Home dashboard, Daily Hire, Monthly School Hire, Credit Hire, partial loan payments, daily/monthly income reports, local offline storage.
Footer: Designed by Ravindu.

Important: Back up records before clearing app data or uninstalling the app. Local app data may be erased by those actions.
