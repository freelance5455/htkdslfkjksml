TORNADO ORBIT ESCAPE - WEB/APK BUILD

This is a self-contained HTML5/WebGL playable prototype designed for a browser-based APK wrapper.

FILES
- index.html: complete game prototype

FEATURES
- 3D procedural residential neighborhood
- Three distinct driveable cars
- Mobile virtual joystick and jump
- Locked driver-seat/dashcam camera while driving
- EF0-EF5 selector
- EF4/EF5 wider wedge-style tornado profile
- Tornado suction, orbital ride and high-speed ejection
- Procedural debris, trees, houses, roads and lighting/shadow-like shading
- No health/death/game-over

APK ROUTE
1. Upload this ZIP to a browser HTML-to-APK/ZIP-to-APK builder.
2. Make sure index.html is at the ZIP root.
3. Set app name: Tornado Orbit Escape
4. Set orientation: Landscape
5. Build the signed APK and install it on Android.

NOTE
This is a playable prototype/base. It uses procedural geometry so it stays small enough for web-to-APK builders. A production version would replace the procedural cars/houses/debris with optimized GLB assets and add more advanced volumetric tornado rendering.
