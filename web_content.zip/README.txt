Pesca: Lago Dorado
==================
Este ZIP está preparado para convertir el juego HTML en APK con un conversor HTML/ZIP -> APK.
Archivo principal: index.html

Nombre sugerido de la app: Pesca: Lago Dorado
Paquete sugerido: com.pescalagodorado
Orientación: vertical
