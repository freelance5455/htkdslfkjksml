حاسبتي - آلة حاسبة تعمل في المتصفح.

لرفعها إلى Netlify: ارفع ملف index.html أو ملف ZIP إلى Netlify Drop.
لا تحتاج إلى npm أو Buildozer أو قاعدة بيانات.
