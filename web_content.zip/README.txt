TUITION MANAGER - ANDROID PROJECT

This project packages the existing HTML/CSS/JavaScript app in a native Android WebView.

IMPORTANT:
- The app loads file:///android_asset/index.html, not appassets.androidplatform.net.
- JavaScript and DOM/localStorage are enabled.
- No internet permission is required for the current app.

BUILD:
1. Open this folder in AndroidIDE on Android, or Android Studio on a computer.
2. Let Gradle sync/download the Android Gradle Plugin.
3. Build > Assemble Debug (or run ./gradlew assembleDebug).
4. APK will be at: app/build/outputs/apk/debug/app-debug.apk

If AndroidIDE asks to create/update the Gradle wrapper, allow it.
