ONE LOVE — prototype 1
Cette version est une maquette fonctionnelle de démonstration.
Elle contient Accueil, Messages, Groupes, Profil et inscription.
Pour devenir une vraie application sociale publiée sur Google Play, il faudra ensuite ajouter:
- serveur et base de données
- comptes sécurisés
- vrais messages et publications
- stockage photos/vidéos
- modération, signalement et blocage
- système de notifications
- monétisation et conformité Google Play
