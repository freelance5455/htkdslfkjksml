ANEM PLUS - ZIPtoAPK web package

Upload this ZIP to ZIPtoAPK. index.html is at the ZIP root.
This is a web app package, not the native Kotlin Android project.
It opens the official ANEM login page and does not collect or store passwords.
Automatic personal-data retrieval requires an authorized official ANEM integration.
