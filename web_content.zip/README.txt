NIROB — ORIENTATION UPDATE
==========================

All app UI text is English-only.

Updated behavior:
- The A4 guide changes between portrait and landscape when the phone orientation changes.
- Camera capture rotates to match portrait phone orientation when the camera stream is landscape.
- Imported images are placed on portrait or landscape A4 based on the image's own proportions.
- The original image ratio is preserved: it is fitted within the A4 page without stretching or squashing.
- The fixed watermark and bottom-right footer are embedded into exported PDF/JPG.

Build:
1. Open HTML to APK.
2. Choose ZIP File to APK and select this ZIP.
3. App name: Nirob
4. Package ID if requested: com.nirob.scanner

Important:
This is still an HTML-based prototype. It auto-adjusts orientation and preserves proportions, but does not yet perform reliable document-corner detection or perspective dewarping. If the paper is skewed in the photo, it may remain skewed. Camera access depends on the converter's Android WebView permissions.
