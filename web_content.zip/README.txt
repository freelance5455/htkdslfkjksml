Kalyani Creations and Boutique - No Background

Clean version with no logo/photo background. Upload index.html or this ZIP to an HTML-to-APK builder.
App name: Kalyani Creations and Boutique
Default admin password: 2011
