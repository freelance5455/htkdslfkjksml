PHANTOM ORDER TACTICS — APK COMPATIBLE WEB PACKAGE

Contains index.html at ZIP root and web/index.html for builders that expect the Android WebViewAssetLoader path /web/index.html.

IMPORTANT: If your APK builder loads a remote website URL, publish this package to hosting first and enter the published HTTPS URL. If it bundles local assets, upload this ZIP and ensure the builder's start page is web/index.html or index.html as appropriate.

PNG EXPORT: Export buttons generate a PNG and open a preview fallback. Some WebView builders block file downloads; if so, use the preview and long-press the image to save it, or enable WebView download support in the builder.
