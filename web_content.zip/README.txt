STOCKLY v4 — Sales vs Owner · Anti-theft · Themes · Calendar

Owner password: childrenofthesun

SALES MODE (default)
Nav: Home · Orders · Customers · More
- Take orders (normal / custom / templates)
- Return customers
- Stock alerts: LOW / OUT only (no quantities, no costs)
- Seller name required on every order (anti-theft)
- No Digital Twin, no Book, no full Stock, no Calendar
- No profit / revenue totals on sales home

OWNER MODE (password)
Nav: Home · Orders · Stock · Twin · Book · Cal · More
- Full stock quantities, costs, restock, count
- Digital Twin forecasts
- Bookkeeping
- Calendar (rent, stock count, custom events)
- Themes: emerald, ocean, sunset, midnight, light
- Audit log of sensitive actions
- Backup / import / reset

Anti-theft
- Seller name tagged on create & complete
- Completed orders not editable from sales
- Costs/profits/quantities hidden from sales
- Audit trail of unlocks, completes, cancels, stock changes
