FF Voice Assistant - Microphone Permission Fixed

This project includes:
- RECORD_AUDIO Android permission
- Automatic runtime microphone permission request
- WebView audio-capture permission grant
- Hindi speech recognition and Hindi text-to-speech

APK build:
Open the project in Android Studio and build an APK.
On first launch, when Android asks for microphone permission, press Allow.
If permission was previously denied, open:
Settings > Apps > FF Voice Assistant > Permissions > Microphone > Allow.

Note: SpeechRecognition support also depends on the Android WebView/browser speech service.
