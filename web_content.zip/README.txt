REKCHIAI — Android ilova uchun boshlang‘ich loyiha

Fayllar:
- index.html: ilova interfeysi va ishlaydigan navigatsiya
- manifest.json: PWA sozlamasi

Videodagi och pushti uslubdan ilhomlangan.
Kirishda faqat nick so‘raladi.
Taklif qilish/referal bo‘limi olib tashlangan.
Ilova nomi Rekchiai qilib belgilangan.
Admin oynasi prototip sifatida bor.
Xizmat bo‘limlari ko‘rinadi, boshlang‘ich holatda o‘chiq.

MUHIM:
1) Admin PIN 2468 faqat ko‘rgazmali prototip uchun. APKni mijozga topshirishdan oldin
   admin autentifikatsiyasini serverga ko‘chiring va kuchli maxfiy PIN/parol ishlating.
2) Nick va olmos balansi hozircha qurilma localStorage'ida. Bu haqiqiy foydalanuvchilar
   uchun xavfsiz emas; server va ma'lumotlar bazasi kerak.
3) Reklama hozir ulanmagan. Haqiqiy rewarded ads uchun reklama tarmog‘i SDK,
   18+ kontent filtri va server-side reward verification callback kerak.
   Hozirgi tugma soxta olmos bermaydi.
4) APK qilish uchun Android Studio/Capacitor yoki WebView wrapper ishlatiladi.
   Bu ZIP tayyor APK emas.
