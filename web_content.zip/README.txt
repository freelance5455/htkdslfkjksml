zip2apk - تحويل مشروع أندرويد (zip) إلى APK

المتطلبات: Docker + unzip + Python 3

الطريقة 1 - واجهة ويب (index.html):
  python3 server.py
  ثم افتح http://localhost:8000 ، اختر ملف zip واضغط "ابدأ التحويل".

الطريقة 2 - سطر الأوامر:
  chmod +x zip2apk.sh
  ./zip2apk.sh project.zip            # debug
  ./zip2apk.sh project.zip release    # release (غير موقّعة ما لم يُضبط التوقيع)

ملاحظة: كل شيء يعمل على جهازك ولا يُرفع الملف لأي موقع. احتفظ بمساحة فارغة ≈ 3 أضعاف حجم الملف.
