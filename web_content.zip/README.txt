FINANCE HUB V17 — DARK EDITION

SADRŽAJ
- index.html: glavna aplikacija
- Finance_Hub_Dark_V17.html: samostalna HTML kopija
- manifest.webmanifest: PWA podešavanja
- service-worker.js: osnovno keširanje za rad van mreže nakon prve posete

VAŽNO
1. Za instalaciju kao PWA, fajlove postavi na HTTPS hosting; otvaranje lokalnog HTML fajla nije isto što i instalirana PWA.
2. Podaci se čuvaju lokalno u pregledaču. Redovno preuzimaj JSON rezervnu kopiju.
3. Nova „Provera evidencije“ je pomoćna provera očiglednih nepravilnosti, ne zamena za rezervnu kopiju i ne garantuje da su svi podaci tačni.
4. Još je potrebno testiranje na Android/iOS uređajima pre korišćenja kao glavne evidencije.
