Nex POS mobile app package
Main file: www/index.html
Open www/index.html in a browser or import the ZIP into a compatible HTML-to-APK converter.
