Easy Calculator — English Version
All visible app text is in English.
Calculation rule: add adjacent digits; reduce sums to one digit by repeatedly adding the digits.
Examples: 10→1, 11→2, 12→3, 18→9, 19→1, 20→2, 30→3.
Input may be continuous (20101988) or separated (2 0 1 0 1 9 8 8).
