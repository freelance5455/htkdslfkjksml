RM REFORMAS v3.0 — PROYECTO ANDROID

NOVEDADES v3
- Presupuestos guardados: lista con buscar, abrir, duplicar, PDF, papelera y recuperar. Numeración P-AAAA-001.
- Presupuesto en PDF (botón "Presupuesto PDF" -> "Guardar PDF / Imprimir": en Android elige "Guardar como PDF").
- Fecha de ejecución: inicio, duración en días laborables y fin previsto.
- Garantía (LOE 1-3-10 años, reforma menor, ampliada, personalizada), exclusiones, forma de pago y ACTA DE ENTREGA firmable.
- Guardado seguro: base de datos del móvil + localStorage + archivo interno de la app + copias automáticas. Se guarda al escribir y al cerrar.
- Guía técnica: cobre, multicapa y PVC por aparato (CTE HS-4 y HS-5), materiales de albañilería por trabajo (enfoscado, capa fina, perlita, tabiques, muros, escaleras...), tarifas hora y día de albañil, peón, pintor, fontanero y electricista, precios de mercado 2026 con fuente.
- Fotos reducidas y ligadas a cada obra. Corregido el fallo de v2 que impedía ver las partidas.

APK: abrir en Android Studio -> Build -> Build APK(s).
Salida: app/build/outputs/apk/debug/app-debug.apk
IMPORTANTE: instala la v3 SOBRE la anterior (mismo paquete) para conservar los datos. Antes, en la v2, exporta la copia JSON por si acaso.

Nota: los precios de mercado son referencias publicadas (con fuente). Los precios de materiales sin dato aparecen a 0 para que pongas el de tu proveedor.
