YOGI LUCKY SPIN

This is an offline-friendly browser app package (not a compiled Android APK).

HOW TO USE ON ANDROID
1. Extract this ZIP on your phone.
2. Open index.html in Chrome.
3. Use Edit your six prizes to type names and choose a photo for each prize.
4. Spin the wheel. After the result appears, tap that prize photo in the top row to increase its count manually.
5. Your prize names, photos and counts are saved in this browser on this device. Do not clear Chrome site data if you want to keep them.

To add it to your home screen, open the page in Chrome and use the browser menu > Add to Home screen (availability may vary for local files).
