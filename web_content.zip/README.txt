DPR 3MW — Premium dark-theme web app package inspired by the supplied 3MW Vempalle reference.
Features: Dashboard, Daily DPR, DPR history, Material stock ledger, Vehicle Entry (Arrival/Cargo/Exit), Rain report, site photos, TXT/CSV export, print-to-PDF, JSON backup/restore.
To use in APK Maker, upload this ZIP if its HTML/ZIP input accepts bundled assets, or use index.html according to that service's instructions. Set app name to DPR 3MW.
This is a web app package, not a built APK. Records are stored locally on the device/browser. Back up regularly. Historical DPR values are not fabricated.
