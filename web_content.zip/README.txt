Shihan Web App package

Contains index.html and app.js at the ZIP root for HTML-to-app builders that accept a static web project ZIP.

Important: This is NOT an APK. A third-party builder must support offline HTML/JavaScript apps and localStorage. Some online builders require an account, project configuration, or a native Android project and may not accept this ZIP directly. Test all functions after building.
