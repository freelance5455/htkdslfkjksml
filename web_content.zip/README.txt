BULUT TV — HTML web-wrapper

Ulanylyşy:
1. ZIP-i açyň.
2. index.html faýlyny brauzerde açyň ýa-da hosting-e ýerleşdiriň.
3. Android APK döretmek üçin bu index.html faýlyny HTML-to-APK/WebView hyzmatyna beriň.

Bellik:
Bu taslama bulutv.lovable.app saýtyny iframe arkaly açýar we internet ýok wagty habar görkezýär.
Daşarky saýtyň içindäki kanal kartalaryna, logolaryna ýa-da pleýerine bu faýldan göni CSS/JS täsir edip bolmaýar.
Kanallaryň logolaryny aýratyn dizaýn etmek we pleýeri üýtgetmek üçin Lovable taslamanyň HTML/CSS/JS çeşme kodlary gerek.
