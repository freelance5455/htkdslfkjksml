DJ GAMING CLUB PRESENTS HAZARI WITH CALCULATOR — VERSION 2

HOW TO USE ON ANDROID:
1. Extract this ZIP.
2. Open index.html with Chrome.
3. Hazari tab: edit player names, Deal/New Game, Show/Hide Cards.
4. Record a round winner and set the points-per-win amount.
5. Calculator tab: edit names, choose the amount, use + or -, or Add custom score.
6. Scores and history are saved locally in the browser on this device.

IMPORTANT:
This is an offline HTML prototype, not yet an APK.
Hazari hand-ranking automation is not included because local Hazari rules can vary.
This prototype records winner and assigned points. Do not clear Chrome site data if you want to retain saved scores.
