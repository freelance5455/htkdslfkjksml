PERIODIC MASTER - HTML VERSION
================================

This is an offline-friendly web app for learning the first 30 chemical elements.

FILES
- index.html: Complete app (HTML, CSS and JavaScript in one file).

HOW TO USE
1. Extract the ZIP.
2. Open index.html in a browser to test.
3. To package it with an HTML-to-APK builder, upload the extracted project or select index.html as the start page.
4. Keep index.html at the project root. Do not rename it.

FEATURES
- Element library (1-30), search and learned filter
- Learn cards with atomic number, symbol and name
- Mixed quiz, Name -> Symbol, Symbol -> Name, Name -> Atomic Number
- 5, 10, 15 or 30 question practice sessions
- Wrong-answer revision list
- Progress and accuracy saved in browser localStorage
- No external libraries, fonts, images or internet required

NOTE
The app saves progress in the browser/device storage. Clearing browser/app data may erase it.
This ZIP is the HTML app source, not a compiled APK.
