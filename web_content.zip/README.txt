FF Battle Assistant - Phone Edition

1. Extract the ZIP.
2. Open index.html in Chrome.
3. The assistant works offline after the page is loaded.
4. Chrome menu can be used to add the page to the home screen when available.

This is a gameplay helper only. It does not modify Free Fire, inject code,
provide auto-aim, or bypass game security.

This version is intentionally simple so it can be used directly on a phone.
