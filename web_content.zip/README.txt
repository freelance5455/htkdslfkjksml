Mansoor Voice Studio Web Edition
Upload this ZIP to Zipped site. index.html is at the ZIP root.
Open in a modern browser and allow microphone access. The browser version previews 20 pitch/speed effects. It does not permanently render transformed audio files.
