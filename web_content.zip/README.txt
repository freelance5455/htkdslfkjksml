WAITER ASSISTANT - UPDATED WEB APP

Files:
- index.html : the app interface (open in a modern browser or give this ZIP to a trusted website-to-APK builder).

Features:
- 12 tables and Morning/Lunch/Dinner menus.
- Add single pieces or sets of two for Idly, Puri, Chapathi, and Parotta.
- Running/Finished table status. Completing an order saves a dated history entry and clears the current order for that table.
- India time (Asia/Kolkata), daily completed-order count, and known sales total.
- Previous completed order history retained across dates.
- Milestone celebration on every 10th completed order (10, 20, 30, etc.).
- Juice icons animate when an item is added.
- Prices the user supplied are entered. Other menu prices are left unset; tap a price / Set price button to enter or change the price.
- Custom extra items with optional price.
- Order totals include known prices. Items without a price are clearly shown as pending, not guessed.
- Export order history to a JSON backup.

Important:
- This ZIP is a web app, NOT a compiled APK.
- Data is saved in local browser storage on the device. It may be lost if browser/site storage is cleared, so export history regularly.
- Price list follows the prices supplied for this build. Dosa varieties and other unspecified menu items are intentionally left without prices.
