MUZ — INSTALLABLE PWA PACKAGE

What this is:
- An installable Progressive Web App (PWA) package for Android and other supported phones.
- The app shell and its embedded illustrations are cached for offline reopening.
- J remains a local, offline command-based organizer in this prototype.
- Your notes and library data are stored locally by the browser on that device.

Important:
This ZIP is NOT an APK and is not yet published publicly.
For the Install Muz button and offline service worker to work, upload the contents of this folder
to a website served over HTTPS. A local file opened directly from Downloads cannot register
a service worker and therefore cannot be installed as a full PWA.

After HTTPS hosting:
1. Open the site's address in Chrome on Android.
2. Choose Install Muz if the button appears, or Chrome menu > Install app / Add to Home screen.
3. After installation and first load, Muz can reopen offline.

For Play Store distribution or a standalone APK:
A separate Android packaging/signing and testing step is still required. This package alone
does not create an APK or publish the app to Google Play.
