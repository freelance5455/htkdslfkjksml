Seif TV - HTML to APK package
================================

This package is a self-contained Arabic RTL streaming-style UI inspired by the supplied reference image.
It is designed for HTML-to-APK/WebView converters.

Files:
- index.html
- assets/icon.png

How to convert:
1. Keep index.html at the ZIP root.
2. Upload the ZIP to your HTML-to-APK converter.
3. App name: Seif TV
4. Package ID example: com.seiftv.app
5. Upload assets/icon.png as the launcher icon.
6. Build APK.

The UI is a front-end demo. Add only video/poster content that you own or are licensed to distribute.
For offline conversion, keep assets local and use relative paths.
