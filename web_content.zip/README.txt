# VoxelCraft: Survival

A procedural voxel survival sandbox inspired by classic block-building games, built from scratch for this demo.

## Run
1. Extract the ZIP.
2. Open `index.html` in a modern browser.
3. Click **ENTER WORLD**.
4. Click the scene to lock the mouse.

A local web server is recommended if your browser blocks module loading from local files.

## Controls
- WASD: move
- Shift: sprint
- Space: jump
- Mouse: look
- Left click: mine
- Right click: place
- 1-9: select hotbar slot
- Esc: release mouse

## Included systems
- Procedural multi-octave terrain
- Mountains, beaches, sea level and snow caps
- Caves
- Trees and leaves
- Coal and iron ore
- Chunked visible-face mesh generation
- Dynamic sun + day/night cycle
- Atmospheric fog
- Clouds
- Basic survival hunger/health
- Block mining / placing
- First-person collision and jumping
- Hotbar and block selection
- Procedurally generated texture atlas

This is intentionally an original prototype rather than a copy of Minecraft's copyrighted assets or code.
