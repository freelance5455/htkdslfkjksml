ARSI — Arsip Harian
====================

Isi paket:
- index.html : aplikasi jurnal harian offline, satu file.

Cara memasukkan ke HTML2APK:
1. Ekstrak ZIP ini.
2. Di aplikasi HTML2APK, pilih opsi membuat APK dari HTML / local HTML.
3. Pilih file index.html (atau folder hasil ekstrak jika diminta).
4. Pastikan mode WebView mendukung JavaScript, DOM Storage/localStorage, dan IndexedDB.
5. Jika ada pengaturan izin file/media, izinkan akses pemilih foto/video saat diminta.
6. Build APK dan uji dengan membuat catatan, menutup aplikasi, lalu membukanya kembali.

Fitur:
- Jam dan tanggal berjalan.
- Pilih tahun, bulan, dan tanggal.
- Timeline catatan berdasarkan jam.
- Satu entri dapat memuat beberapa kategori sekaligus.
- Kategori terstruktur dengan kolom yang sesuai + catatan bebas.
- Foto dan video pada setiap entri.
- Kategori bawaan: Pakaian, Makanan & Minuman, Lokasi, Orang ditemui,
  Percakapan, Aktivitas, Suasana hati, Momen, Catatan pribadi.
- Edit/hapus catatan dan pencarian.
- Ekspor/impor cadangan JSON termasuk media.

Catatan penyimpanan:
Data disimpan lokal di perangkat (localStorage + IndexedDB), bukan di cloud.
Jangan hapus data aplikasi/browser sebelum mengekspor cadangan.
Kapasitas video bergantung pada ruang penyimpanan perangkat dan batas WebView.
