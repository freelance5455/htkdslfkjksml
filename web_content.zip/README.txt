GEOLINIX v0.7.0 — WebAPK builder package

HOW TO USE
1. Import this ZIP into your WebView/HTML-to-APK builder.
2. Set the start page to index.html (or web/index.html if the builder asks for a folder).
3. App name: GEOLINIX
4. Package ID: com.geolinix.app
5. Version: 0.7.0 (version code 7)
6. Theme colour: #0B1F44

WHAT WORKS IN THIS LOCAL DEMO
- Home navigation and app-wide search across included sample content
- GEO AI scripted demo responses (not a live AI model)
- GEO MAPS searchable sample Zambian cities (not GPS/live maps)
- CONNECT demo chats saved locally on this device
- DISCOVER searchable sample listings and categories
- BUSINESS local draft creation and deletion
- PROFILE local editing and saving
- WORKSPACE local demo team members and tasks

NOT CONNECTED
No online accounts, server/cloud sync, live AI, live maps/GPS, real-time messaging,
push notifications, payments, MTN MoMo, subscriptions, or production team administration.
Wallet is a coming-soon information screen only. Local browser data may be lost if app
storage is cleared or the app is uninstalled.

This is a prototype package, not a compiled or tested APK.
