MELA V3 - Working marketplace prototype

This version demonstrates:
- Search and categories
- Post an ad
- Featured ads
- Sample Boost plans in ETB
- Local storage on the device

IMPORTANT:
This is still a prototype. Payments are TEST ONLY and listings are stored locally.
For a real public MELA app, the next production work is online backend/database,
real authentication, cloud image storage, secure payment verification, chat,
admin moderation, Android/iOS packaging, and store publishing.
