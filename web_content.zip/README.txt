AR Social - prototype by Azhar Ali Channa

This is a front-end demo, not a production TikTok clone.
To preview: open index.html in a modern browser.
To install as a home-screen web app, upload the folder to an HTTPS host and add it from the browser's menu.

Current demo features:
- Home feed and sample welcome post
- Local video preview and local feed post
- Like interaction
- Profile, inbox and settings screens

Not yet implemented:
- Real accounts/login, cloud video upload/storage, shared feed across users,
  comments database, follows/followers, chat, live streaming, notifications,
  moderation/reporting, admin dashboard and production security.
These require a backend, hosting, database, video storage/CDN, and app-store deployment.
