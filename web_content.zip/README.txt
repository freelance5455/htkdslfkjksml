# Class 10 Bihar Board Quiz App

Included:
- Student demo login
- Maths, Science, Hindi
- Chapter-wise MCQ quiz
- 20-second timer
- Score/result
- Progress counter
- Admin question add form

Note: Google Login and permanent database storage are not connected in this prototype.
For production, connect Firebase Authentication + Firestore (or another backend).
