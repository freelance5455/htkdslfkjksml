GOKUL WIN HTML EDITION

Open index.html in a browser. Games work without login.
Real phone OTP is not active until you replace the Firebase config placeholders in index.html, enable Phone sign-in in Firebase Console, configure authorized domains, and host the page over HTTPS. Opening file:// directly will not support Firebase phone auth.

Some games are mini-game implementations, not full versions of the named commercial games. Virtual points have no cash value.
