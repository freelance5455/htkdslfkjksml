MIS TARJETAS — PAQUETE DE ARCHIVOS

Contenido de la raíz del ZIP:
- index.html: aplicación corregida.
- manifest.json: configuración de la aplicación.
- sw.js: archivo de service worker para uso web/PWA si la plataforma lo registra.
- README.txt: estas instrucciones.

Para un conversor HTML a APK, carga este ZIP directamente y configura index.html como archivo de entrada si el conversor lo solicita. No agregues una carpeta contenedora dentro del ZIP.

IMPORTANTE: este paquete contiene el código de la aplicación, NO los datos personales guardados dentro de la app del teléfono. No desinstales ni borres datos de la aplicación actual. Prueba primero la copia y conserva la app actual hasta confirmar que tus datos están respaldados.

Nota: el HTML incluido no registra automáticamente sw.js; el archivo se incluye como parte del paquete para plataformas que lo necesiten.
