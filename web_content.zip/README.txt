Mind Rush v1 Prototype
========================
Open index.html in Chrome/Edge to play.

Features:
- 10-question quiz
- Virtual coin rewards
- Daily bonus
- Result screen
- Mobile-friendly UI

This is a prototype, not yet a signed Android APK.
Next development step: convert this gameplay into an Android app, add a secure backend, analytics, ads, age-appropriate content, privacy policy, and Play Store assets.
