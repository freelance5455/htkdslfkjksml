DH PATHWAYS - INSTITUTE EMAIL LOGIN MODEL

Supported demo domains:
@iitj.ac.in -> IIT Jodhpur
@iitp.ac.in -> IIT Patna
@visvabharati.ac.in -> Visva-Bharati University

Users create their own password and can login/logout.
Gmail/Yahoo are rejected in this prototype.
Admin:
email: admin@dhpathways.app
password: dhpadmin

IMPORTANT: This is a prototype. Passwords are stored locally for demonstration only.
A real multi-device app needs a backend/authentication service.
