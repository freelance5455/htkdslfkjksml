ASX OBD2 Dashboard — APKForge HTML edition

1. Upload this ZIP to ApkForge.
2. The ZIP must contain index.html at its root (it does).
3. Build the APK.

Bluetooth note:
This edition uses Web Bluetooth and is intended for BLE ELM327 adapters with a UART GATT service.
A traditional Bluetooth Classic ELM327 using SPP/RFCOMM cannot be accessed from a normal Android WebView.
For a Classic ELM327, use the native Java Android project edition instead.

The dashboard also has Demo mode in the HTML if Bluetooth is unavailable.
