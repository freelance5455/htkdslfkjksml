MI AGENDA · BOLOS — proyecto Android

Este proyecto contiene la aplicación web empaquetada dentro de un WebView nativo. Guarda los conciertos en el almacenamiento local de la app.

Para compilar el APK: abre esta carpeta en Android Studio actualizado, deja que Gradle sincronice (necesita conexión a Internet para descargar el plugin de Android y el SDK si no están instalados), y usa Build > Build APK(s).

El entorno donde se preparó el proyecto no dispone de Android SDK/Gradle ni de acceso a Internet, por lo que aquí no se ha podido compilar ni verificar un APK. No instales un APK de origen desconocido.
