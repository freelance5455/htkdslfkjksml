NOVA CHAMPIONS — PRONOSTICS JAVASCRIPT FIX

WHAT'S NEW
- New public navigation section: الجريدة / Journal / News.
- Newspaper-style front page with a featured lead story, article cards, photos, categories, dates, and full article reading view.
- Admin dashboard includes article publishing, editing, deleting, and image upload from a phone or computer.
- Articles and image URLs sync through Firebase Firestore; article images are uploaded to Cloudinary (free unsigned image preset).
- Existing league, cup, Champions League, teams, match results, comments, admin login, and standings features are retained.

IMPORTANT FIREBASE SETUP (ONE-TIME)
The new newspaper uses Firestore collection `articles` and Firebase Storage folder `news/`.

1) Firestore Rules
Open Firebase Console > Firestore Database > Rules.
Keep the existing rules and add this match block INSIDE:
match /databases/{database}/documents {

    match /articles/{articleId} {
      allow read: if true;
      allow create, update, delete: if isAdmin();
    }

Place it before the final catch-all rule:
match /{document=**} {
  allow read, write: if false;
}

Do not remove the existing admins, leagues, teams, or matches rules.
The existing isAdmin() function should remain unchanged.

2) Cloudinary image hosting (no Firebase Storage upgrade required)
The site uses these public upload settings:
- Cloud name: qkkji4xm
- Upload preset: nova_news
- Signing mode: Unsigned

In Cloudinary > Settings > Upload > Upload presets, edit `nova_news` and restrict it to image formats JPG, PNG, WEBP with a maximum file size of 5 MB. Keep the preset assigned to the news folder. Never put API Secret in the website code. Unsigned presets are public, so these restrictions are important; for stronger abuse prevention, use a signed upload through a server-side function later.

No Firebase Storage rules or Storage billing upgrade are needed for article images. Firestore still needs the `articles` rule above.

3) Deploy
- Extract this ZIP.
- Upload the extracted index.html and assets folder to the Netlify site (index.html must be at the root).
- Open the site and refresh. Log in as Admin, then scroll to “إدارة الجريدة والأخبار”.
- Create a title, category, short introduction, full article, and choose an image from the device.

Do not enable Firebase Storage for this newspaper feature. Do not change the Firebase Authentication setup.

4) PRONOSTICS
- The main menu now includes Pronostics for upcoming League, Cup, and Champions League matches.
- Followers do not create accounts. They enter a nickname and predict the exact score.
- Scoring: 3 points for the exact score; 1 point for the correct match outcome (home win / draw / away win); 0 otherwise.
- Each nickname can submit once per match. Predictions are write-once; they cannot be edited after submission.
- Admin can open/close predictions for each match from Admin > Gestion des matchs using the “فتح التوقعات / إغلاق التوقعات” button.
- The leaderboard is calculated from submitted predictions and saved match results.

FIRESTORE RULES FOR PREDICTIONS
Add this block inside match /databases/{database}/documents, before the final catch-all rule. Keep all existing rules (including articles) unchanged:

    match /predictions/{predictionId} {
      allow read: if true;
      allow create: if
        request.resource.data.keys().hasAll(['matchId', 'nickname', 'homeGoals', 'awayGoals', 'createdAt']) &&
        request.resource.data.keys().hasOnly(['matchId', 'nickname', 'homeGoals', 'awayGoals', 'createdAt']) &&
        request.resource.data.matchId is string &&
        request.resource.data.nickname is string &&
        request.resource.data.nickname.size() >= 2 &&
        request.resource.data.nickname.size() <= 24 &&
        request.resource.data.homeGoals is int &&
        request.resource.data.awayGoals is int &&
        request.resource.data.homeGoals >= 0 &&
        request.resource.data.homeGoals <= 20 &&
        request.resource.data.awayGoals >= 0 &&
        request.resource.data.awayGoals <= 20 &&
        request.resource.data.createdAt is int &&
        exists(/databases/$(database)/documents/matches/$(request.resource.data.matchId)) &&
        get(/databases/$(database)/documents/matches/$(request.resource.data.matchId)).data.predictionsClosed != true &&
        get(/databases/$(database)/documents/matches/$(request.resource.data.matchId)).data.get('hs', null) == null &&
        get(/databases/$(database)/documents/matches/$(request.resource.data.matchId)).data.get('as', null) == null;
      allow update, delete: if isAdmin();
    }

IMPORTANT: This no-account system uses nicknames, not verified identities. A person can choose another nickname on a different device. Predictions are publicly readable so the public leaderboard can be displayed. Do not replace your existing rules with this snippet; add only this match block before the final catch-all.


TROUBLESHOOTING FIX
The previous Pronostics build contained a JavaScript template-literal syntax error that stopped the entire app from rendering. This build corrects that error. The main application script passes Node.js syntax validation.


FINAL PRONOSTICS FIX
- Only matches with BOTH scores empty (null or missing) appear in Pronostics.
- Matches with either score recorded are hidden and cannot accept a prediction.
- Firestore prediction rules use data.get('hs', null) and data.get('as', null) to support older match documents with missing score fields.
