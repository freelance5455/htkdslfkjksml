SpeedX web prototype

Open index.html in a browser to preview the interface.

This is a UI prototype, not a native Android APK. The speed slider changes
only the displayed value. Android does not allow an ordinary app or web page
to alter another app's gameplay speed or audio. The Geometry Dash launch
button uses an Android intent link, which may not work in every browser.

To create a native APK, this folder must be packaged by a trusted Android
web-to-app builder. Do not upload private files or pay for a service without
checking its terms and reputation.
