AUXILIO DE MIRA - proyecto Android base

Este proyecto contiene:
- Panel HTML local dentro de WebView.
- Detector de swipe.
- Feedback háptico.
- Botón para abrir Free Fire.
- Base preparada para añadir después funciones globales mediante permisos legítimos de Android/Shizuku.

No inyecta código ni modifica archivos/procesos de Free Fire.
