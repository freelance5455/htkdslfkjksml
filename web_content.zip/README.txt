JARVIS - Dazly/HTML-to-APK compatibility build

IMPORTANT:
The previous APK showed:
https://appassets.androidplatform.net/web/index.html
net::ERR_HTTP_RESPONSE_CODE_FAILURE

This version includes the page at BOTH:
- web/index.html
- index.html

When importing, choose the option for a LOCAL HTML/ZIP project, not a website URL.
If the builder asks for the start page, select:
web/index.html
If it asks for a single HTML file, select:
index.html

Enable JavaScript and Microphone if those options are available.
