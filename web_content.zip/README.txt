MFUMOH NASDAQ ROBOT V2 - MOBILE BUILDER EDITION

This is a dependency-free mobile web app that can be wrapped into an APK by a mobile-friendly web-to-APK builder.

Files:
- index.html = the app
- app-config.json = basic app information
- README.txt = instructions

Important: this is a dashboard/demo signal interface. It does not directly place RCG Markets orders. Actual automated trading requires the MT5 Expert Advisor running in MetaTrader 5.
