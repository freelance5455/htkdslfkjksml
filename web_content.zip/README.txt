RBM — RICH BOYYZ MAGAZINE
===========================

Files:
- index.html — complete responsive RBM magazine.

WHAT IT DOES
1. Vogue-inspired editorial layout.
2. Attempts to load image uploads/contributions for "O richboyyz" from Wikimedia Commons.
3. Lets a visitor select photos in the browser.
4. Adds a RICH BOYYZ watermark in the lower-right corner.
5. Adds a QR code in the upper-left corner pointing to mailto:richboyyzymcmb@gmail.com.
6. Saves browser uploads locally in that visitor's browser.

IMPORTANT PUBLIC-UPLOAD NOTE
A single static HTML file cannot make uploads from one visitor automatically appear on every other visitor's phone. That requires shared cloud storage/database and security rules.

The included upload UI is therefore a working local/demo version. To make it a real public magazine:
- connect the upload function to Firebase Storage + Firestore, Supabase Storage + database, or another backend;
- authenticate/rate-limit uploads and validate image MIME/type/size server-side;
- generate the watermark server-side as well if you need it to be tamper-resistant;
- store the final public image URL and metadata in the database;
- have RBM read those records when the page loads.

WIKIMEDIA
The supplied Meta-Wiki page currently does not exist. RBM queries Wikimedia Commons for contributions by "O richboyyz"; if the account has no Commons uploads, the page simply shows the RBM upload prompt.

QR CODE
The generated QR encodes:
mailto:richboyyzymcmb@gmail.com

To use a different email, change EMAIL in index.html.

DEPLOYMENT
You can upload this folder to GitHub Pages, Netlify, Vercel, Firebase Hosting, or any static web host.
For true shared uploads, add a backend/storage integration first.
