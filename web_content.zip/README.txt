# Instagram Maxx — Android-friendly MVP preview

This is a clickable front-end demo that opens in a mobile browser.

## Run it
1. Extract the ZIP on a computer or Android phone.
2. Open `index.html` in Chrome.
3. Try Home, Reels, Create and Profile. Create lets you preview a local post.

## Important
This is a prototype, not a finished social network or Play Store APK. Login is a visual demo only; posts stay on the device and are not sent to other users. Real accounts, secure authentication, cloud photo/video storage, feeds, comments, follows, chat, moderation, privacy controls and notifications require a backend and security testing. Do not enter real passwords in this demo.

The supplied logo image is in `assets/`.
