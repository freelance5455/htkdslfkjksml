RedBrowser Blackfire Edition — HTML project

Entry file: index.html (ZIP root)

Convert using a tool that accepts a website ZIP and builds a signed Android APK. Keep index.html at the root. Configure links to open inside the app WebView where available. Browser search now opens a normal top-level page rather than an iframe, helping with sites that block iframe embedding. Use Android Back to return to RedBrowser.

This is an HTML front-end prototype. AI, RMail and wallet services require real backend implementations. Never put private API keys in the HTML or APK. Developer/Premium toggles are local demo settings, not secure authorization.
