# Nen Period Tracker — Android project

This ZIP contains the complete web app source and Capacitor configuration. It is ready to generate the native Android project and build a test APK.

## Requirements
- Windows 10/11, macOS or Linux
- Node.js LTS (includes npm): https://nodejs.org/
- Android Studio: https://developer.android.com/studio
- Android SDK installed through Android Studio

## Build your APK (Windows)
1. Extract this ZIP to a folder, for example `C:\NenPeriodTracker`.
2. Open that folder in File Explorer.
3. Click the address bar, type `cmd`, and press Enter.
4. Run these commands one at a time:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

5. Android Studio opens. Wait for Gradle sync and SDK downloads to finish.
6. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. When the build completes, click **locate** in the notification.

The debug APK is normally here:

`android/app/build/outputs/apk/debug/app-debug.apk`

Copy that APK to your Android phone and tap it to install. You may need to allow installation from that file manager/browser under Android settings.

## Run directly on a connected phone
- Enable Developer options and USB debugging on the phone.
- Connect it by USB and accept the debugging prompt.
- Run `npm run android:run` from the project folder, or use Android Studio's Run button.

## Updating the app
Edit files in `www/`. Then run:

```bash
npx cap sync android
```

Rebuild the APK in Android Studio.

## App features
- Cycle setup (last period start, average cycle length, period duration)
- Period start/end logging
- Monthly calendar with period and estimated period markings
- Estimated next period and ovulation dates
- Daily symptom, flow and notes log
- Cycle phase information and period history
- Local device storage using browser localStorage

## Important notes
- This is a testing build, not a medical device or contraceptive tool. Cycle and ovulation dates are estimates.
- Entries are stored locally on the device; uninstalling the app or clearing app data may erase them.
- The app does not currently include push notifications, cloud backup, account login, biometric lock or encrypted health-data storage.
- `npm install` and the first Android build require an internet connection to download packages and Android build dependencies.
- This ZIP does not contain a prebuilt APK. The APK is generated on your computer using the steps above.
