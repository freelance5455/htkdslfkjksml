MindUp by Abdoulaye V5 - Arcade cérébrale
12 nouveaux jeux : calcul éclair, intrus, suites, équations, memory match,
flash visuel, réflexe logique, orientation, mot mystère, vrai/faux,
mini puzzle et défi mixte.
Les parcours V4 restent disponibles : logique, mémoire, concentration et BAC.
