WahidMedX — India-focused final prototype

Scope:
- Indian medicines, Indian brands and Indian pricing/reference workflows are the primary focus.
- Uses/reference information is included as a separate field.
- Offline mode uses the local database.
- Online + Offline mode is designed around current Indian official sources, especially NPPA Pharma Sahi Daam and PMBI/Jan Aushadhi.
- Hindi/English UI and voice search are included.

Authoritative source targets:
- CDSCO/SUGAM: formulation fields such as generic name, strength, brand name, pack size, dosage form, composition and therapeutic category.
- NPPA/Pharma Sahi Daam: current medicine price/MRP verification.
- PMBI/Jan Aushadhi: generic products and MRP/brand-vs-generic comparison.
- Commercial medicine sites can be used for cross-checking where permitted.

Important:
This package does NOT claim to contain every Indian medicine/brand. A genuinely complete database requires a controlled ingestion pipeline, deduplication/normalization, regular updates and, for some commercial datasets, appropriate licensing/access. The app is structured so that a full database can be imported later without redesigning the UI.
