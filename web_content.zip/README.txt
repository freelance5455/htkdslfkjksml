Protocol Tracker v5.2 – WebView-kompatible Firebase-Testversion

Für ZIP→APK-Konverter: index.html als Startdatei verwenden.
Die App startet ohne automatische Netzwerk-/Firebase-Aufrufe. Firebase wird erst beim manuellen Verbindungstest geladen.
Der zuvor eingebettete OpenRouter-API-Key wurde aus Sicherheitsgründen entfernt und muss bei Bedarf unter Einstellungen → KI/API neu eingetragen werden.
