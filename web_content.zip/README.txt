مفكرة جني – الإصدار 0.3.0
=========================

الملف index.html هو التطبيق كاملًا (ملف واحد). يمكن فتحه في Chrome مباشرة،
أو تحويله إلى تطبيق APK باستخدام Capacitor:

  mkdir janni && cd janni
  mkdir www && cp /path/to/index.html www/
  npm init -y
  npm i @capacitor/core @capacitor/cli @capacitor/android @capacitor/local-notifications @capacitor-community/speech-recognition @capacitor-community/text-to-speech capacitor-voice-recorder
  npx cap init "مفكرة جني" com.janni.notebook --web-dir www
  npx cap add android
  npx cap sync android
  npx cap open android      (ثم Build > Build APK(s) في Android Studio)

صلاحيات يجب إضافتها في android/app/src/main/AndroidManifest.xml داخل <manifest>:
  RECORD_AUDIO, POST_NOTIFICATIONS, SCHEDULE_EXACT_ALARM, RECEIVE_BOOT_COMPLETED

تحقّق من وثائق كل إضافة (README) لإصداراتها وأسماء دوالها قبل البناء.
