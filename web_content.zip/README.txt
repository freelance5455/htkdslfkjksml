SONAR VISION v2 files
- index.html: polished browser app interface.
- Upload to an HTTPS host and open in Chrome for camera/microphone access.
- Local file access uses the Android file picker. Permission prompts are user initiated.
- Generates a WAV tone sequence representing one sampled grayscale video frame.
- Records microphone audio and allows downloading the recording where MediaRecorder is supported.
Limits: not an APK. Full video frame synchronization/decoder is not implemented; Wi-Fi peer streaming is not implemented. Web Bluetooth is not a universal substitute. Browser permissions cannot be silently granted. No claim of zero bugs or complete production functionality.
