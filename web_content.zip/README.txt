PrintProfit V2 - Navegação completa
===================================

A navegação possui DOIS modos:

1. Botões na parte inferior:
   Início, Preço, Filamentos, Orçamento e Produtos.

2. Gestos:
   Deslizar da direita para a esquerda avança.
   Deslizar da esquerda para a direita volta.

Os dois modos funcionam juntos.
O index.html fica na raiz do ZIP para o conversor ZIP para APK.
