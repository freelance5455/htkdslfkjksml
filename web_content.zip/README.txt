UNNATI HTML Demo — Original Structure Preserved

Files: index.html

How to run:
1. Extract this ZIP.
2. Open index.html in Chrome/Edge. Internet is needed for YouTube and official scheme links.
3. Choose language from the top dropdown. Use Login or Register.
4. Register a demo account, then log in using the same 10-digit mobile number and password.
5. Woman role opens the original dashboard; other roles open role-specific demo dashboards.
6. Complete all 10 Skill Assessment questions.

YouTube links included exactly as supplied by the user:
- https://youtube.com/playlist?list=PLhQE-XzwOg7PGzWM1omlNSzbRCx7pEVl7&si=Vi6geQqzEu7nRIe5
- https://youtu.be/S7CjkCPnT3s?si=7n73tldGXss36dkC
- https://youtube.com/playlist?list=PLgDH3cTLckEHA6KMbr4iL5GreTp-6aFNJ&si=qe4NiF0nH9A4TOV3

Important limitations:
- This is a front-end demo; demo accounts are stored in this browser's localStorage and passwords are not securely hashed. Do not use real passwords or sensitive data.
- Password reset/OTP, real AI, server/database, real orders/payments, official user reports, and certificate verification need backend integration.
- For Android APK/WebView, external links must be allowed by the wrapper; browser testing cannot guarantee every APK builder's behavior.
