HOUSEHOLD EXPENSE TRACKER — OPTIONAL INSTALL KIT
================================================

The app works perfectly well as a single file you open in your browser.
This kit is only if you want it to install to your phone's home screen
like a normal app (own icon, full screen, works offline).

WHAT'S IN HERE
--------------
  shopping-list.html      the app (same file you already have)
  manifest.webmanifest    tells the phone the app's name, icon, colours
  sw.js                   makes it work offline after the first visit
  icon-192.png            home screen icon (small)
  icon-512.png            home screen icon (large)

HOW TO INSTALL IT  (free, about 5 minutes)
------------------------------------------
1. Put all five files in the SAME folder on any free HTTPS host.
   Free options: GitHub Pages, Cloudflare Pages, Netlify Drop.
   (Cloudflare Pages and Netlify Drop let you drag a folder onto a web
   page and get a link back — no account setup beyond signing in.)

2. Open that link in Chrome on your Android phone.

3. Tap the three-dot menu  ->  "Add to Home screen"  /  "Install app".

4. It now has its own icon and opens full screen, offline.

NOTES
-----
* The service worker (sw.js) only works over https:// or localhost,
  not over a plain file:// path. That is why hosting is needed.
* If you change the app later, bump the CACHE name in sw.js
  (expenses-v1 -> expenses-v2) so phones pick up the new version.
* Your data still lives only on your phone. Hosting does not upload
  anything — the files are static.
* Long-press the home screen icon for shortcuts straight to
  "Add expense" or "Reports".
* IMPORTANT: the microphone (voice input) does NOT work inside in-app
  browsers such as the Amazon app's viewer. Open the app in Chrome
  directly for voice.
