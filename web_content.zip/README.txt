MY TUCKSHOP — ANDROID APK SOURCE BUNDLE

This ZIP has index.html at the ZIP ROOT (not inside a subfolder). Some HTML-to-APK builders require this layout. It is source HTML, not a compiled APK.

Build steps:
1. Keep a JSON backup of any important records from the original app.
2. Upload this ZIP to a builder that explicitly supports ZIPs containing local HTML, or upload index.html directly if supported.
3. If the builder asks for a website URL instead of a file, this ZIP will not work in that field; use a builder option for local HTML files or host the app first.
4. After installation, test with non-critical data and verify backup/restore before relying on it.

The app is self-contained and has no external scripts or stylesheets. Local data in the browser does not automatically transfer into the APK; export and restore a JSON backup. Do not upload your customer/sales backup to the APK builder. Keep the original app and backup until the APK is verified.
