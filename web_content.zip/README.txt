ABUKI TRANSPORT & LOGISTICS — MOBILE HTML PROJECT

Contents:
- index.html: mobile-optimized version of your uploaded HTML app.

How to use:
1. Upload index.html to an HTML-to-APK builder that accepts a local HTML file or ZIP.
2. Set the app name to ABUKI TRANSPORT & LOGISTICS.
3. Generate and download the APK.
4. Install it on your Android phone and test the booking flows.

Important:
- This is a mobile layout conversion of your original front-end prototype.
- The app uses Tailwind CSS, Google Fonts, and Font Awesome from online CDNs, so an internet connection is needed for those resources.
- Fare estimates, seat availability, and tracking in the original code are demonstration features, not live connected services.
- Booking links currently contact the WhatsApp/phone number already present in your source code.
- A production transport platform still needs a secure backend, database, real driver/location integration, and proper booking/payment systems.
