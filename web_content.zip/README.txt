Committee Plus - Offline HTML package

IMPORTANT: The ZIP contains index.html at the ROOT of the archive. In HTML to APK, choose ZIP File to APK and select this file.

This version uses local-only account setup and local password reset codes displayed on the device. It does NOT send email and does not need an email service. Committee records and account data are stored in the app/browser local storage. Export backups regularly; uninstalling or clearing app data can erase local records.

If the converter still shows appassets.androidplatform.net/web/index.html could not load, check its Start Page / Entry Page setting is index.html and that ZIP File to APK supports offline HTML assets.
