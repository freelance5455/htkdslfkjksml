FARM MONITOR v2.0.0  (index.html + icon.png, no build step needed)

GOOGLE DRIVE LOGIN - ONE-TIME SETUP (by the app owner)
1. console.cloud.google.com -> create a project -> enable "Google Drive API".
2. OAuth consent screen: add the scope .../auth/drive.appdata (private app folder).
3. Credentials -> Create OAuth client ID -> "Web application".
   Authorized JavaScript origins: the https address where the app is hosted.
4. Paste the Client ID in the login screen (or Settings -> Google Drive backup),
   or put it in index.html: var GCID_DEFAULT="xxxx.apps.googleusercontent.com";
Data is stored as ONE file "farm-monitor-data.json" in the app's hidden Drive folder
and is edited in place (no daily files).
NOTE: Google blocks sign-in inside plain Android WebViews. If you wrap this as an APK,
use a wrapper with native Google sign-in (e.g. Capacitor + Google Auth plugin) or open
it as an installed web app (PWA) in Chrome.

WEATHER: free Open-Meteo service (no key). Default location Dhaka; use "Use my location".
VACCINE GUIDE: general intervals only - always confirm with your vet.
