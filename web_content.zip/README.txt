# RTT Crypto Mining — Android starter project

## What is included
- Mobile-first mining dashboard
- 24-hour timer and auto-stop
- Start another session after completion
- Deposit and Withdraw marked COMING SOON
- Local browser state and optional PWA install support

## Important
This is a starter UI, not a production cryptocurrency mining service. RTT points are local demo points only, not blockchain tokens or redeemable funds. A production launch needs:
1. Secure backend and authentication
2. Server-side UTC session timing and anti-tampering
3. Database ledger and admin controls
4. Audited token contract and wallet integration
5. Withdrawals only after legal, security, and liquidity checks

## Try it on Android
Open `index.html` in a mobile browser. For installable PWA behavior, serve the folder over HTTPS; then use the browser menu > Add to Home screen. A real Android APK requires an Android wrapper/build service or a development environment; this ZIP is source, not an APK.
