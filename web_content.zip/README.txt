ANGOLA CONNECT VPN - PACOTE COMPATÍVEL COM CONVERSOR APK
============================================================
Este arquivo ZIP contém o 'index.html' exatamente na raiz principal,
conforme exigido pelo aplicativo Android "ZIP para APK":

Arquivos incluídos na raiz:
- index.html (Página principal da VPN pronta para empacotamento)
- manifest.json (Configuração de manifesto PWA Android)
- README.txt

Como instalar no seu celular:
1. Abra o aplicativo 'ZIP para APK' no seu celular Android.
2. Selecione este arquivo ZIP baixado.
3. Clique em 'Converter' ou 'Gerar APK'.
4. Instale o APK gerado no seu dispositivo!

Suporte WhatsApp: +244 958174838
