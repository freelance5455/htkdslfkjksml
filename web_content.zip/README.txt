CLINIQUE VÉTÉRINAIRE — VERSION V17

- Le bouton « Imprimer le bilan » ouvre une nouvelle fenêtre contenant l’aperçu du bilan complet.
- Dans l’aperçu intégré, appuyez sur « Enregistrer / Imprimer le PDF ». Le PDF est généré directement. Android ouvre la feuille de partage si le partage de fichiers est pris en charge ; choisissez une option d’enregistrement et sélectionnez Documents si l’application de destination le permet. Sinon, le navigateur tente de télécharger le fichier dans Téléchargements. La page ne peut pas écrire silencieusement dans Documents sans autorisation Android native.
- L’application web ne peut pas forcer silencieusement l’écriture dans le dossier Documents à cause des restrictions de sécurité Android. L’utilisateur choisit l’emplacement dans la boîte de dialogue système.
- Si aucune fenêtre ne s’ouvre dans l’APK, le générateur peut bloquer les fenêtres secondaires : autorisez les pop-ups ou essayez de lancer l’application dans Chrome.
- Les modules et les données de la version V16 sont conservés dans les fichiers web. Faites une sauvegarde JSON depuis Gestion du cabinet avant de remplacer l’ancienne installation.
- Placez index.html à la racine du ZIP lors de la génération APK.
