Saif Ullah PWA package

This is a Progressive Web App-ready version of your offline manager.

Important:
- It must be hosted on an HTTPS website once before Chrome offers Install app.
- Upload ALL files in this folder to a static HTTPS host (for example GitHub Pages or Netlify).
- Open the hosted website in Chrome on Android, then Chrome menu (⋮) > Install app / Add to Home screen.
- After first successful load, the service worker caches the app for offline opening.
- Data is stored in this browser's local storage. Do not clear Chrome site data. Use the app's Backup option regularly.
- The existing records/data from the previous HTML file are not automatically transferred; use Backup/Restore if you already entered records.
