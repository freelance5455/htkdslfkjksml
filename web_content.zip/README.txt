AQUA MARINE PRO WEB APP v0.1
1. Open index.html in Chrome to use it.
2. Data is stored locally in the browser on this phone.
3. Use Billing PDF -> Generate / Print Monthly PDF -> Android Print -> Save as PDF.
4. To turn it into an APK, upload this ZIP to a free HTML-to-APK builder.
