NOVASNAKE — 2 PLAYER LAN
==========================

What this is:
A 2-player Snake.io-style game for phones on the SAME Wi-Fi/hotspot.
No internet is required after Node.js and the ws package are installed.

FEATURES
- Exactly 2 players per room
- Same hotspot / Wi-Fi
- Real-time movement
- Food and growth
- Body collision kills
- Head-to-head collision: longer snake survives; equal length = both die
- Boost
- Mobile joystick
- Keyboard controls
- Score/leaderboard
- Landscape gameplay
- Offline local network play

RUN ON A LAPTOP
1. Install Node.js.
2. Open a terminal in this project folder.
3. Run:
   npm install
4. Run:
   npm start
5. Find the laptop's Wi-Fi/hotspot IPv4 address.
   Windows: ipconfig
   Linux: ip addr
   Example: 192.168.43.100
6. Player 1 and Player 2 connect to:
   http://192.168.43.100:3000

HOTSPOT
- Turn on the laptop/phone hotspot or connect both phones to the same Wi-Fi.
- The host computer running server.js must be reachable by the other phone.
- If Windows Firewall asks, allow Node.js on Private networks.

IMPORTANT FOR ANDROID
A normal HTML-to-APK converter can package the CLIENT, but it usually cannot automatically run Node.js as the LAN server.
For the easiest test, run the server on a laptop.
For a fully self-contained Android host APK, the server needs to be embedded using an Android native/WebSocket implementation.

GAME
Player 1 taps CREATE GAME.
Player 2 enters the host's local IP and taps CONNECT.
Both must use the same hotspot/Wi-Fi.
