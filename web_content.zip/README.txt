BLOCKBOUND RUN — ANDROID LANDSCAPE EDITION

START
1. Extract the entire ZIP file.
2. Keep game.html and the assets folder together.
3. Open game.html in Chrome or another modern mobile browser.
4. Rotate the phone to landscape and tap START RUN.
5. Tap once if the browser asks permission to start music.

CONTROLS
- Left / Right: move
- Up: jump (Spider can double-jump)
- Sword: attack
- Star: selected character ability
- Keyboard: A/D or arrow keys, Space to jump, J to attack, K for ability, M to toggle sound

GAMEPLAY
- Endless runner with five rotating environments: Plains, Dark Forest, Mesa, Snow Peaks and Deep Dark.
- Score, health, coin collection, unlockable characters and achievements.
- Random mobs, weapon drops and boss encounters every 2,000 score.
- Weapons have different damage and range. Bow fires a ranged projectile.
- Coins, unlocked characters and achievements are saved in this browser's local storage.

IMPORTANT
- This is an HTML5 browser game, not an APK.
- Do not open game.html from inside the ZIP preview. Extract all files first.
- The assets folder is required; do not rename or move it away from game.html.
- Audio playback may require the first tap because of browser autoplay restrictions.
