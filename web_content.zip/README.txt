ANIME BATTLE MOBILE — PLAYABLE PROTOTYPE

This is a lightweight, original 3D-style combat prototype designed to run in a mobile browser, including low-end phones.

CONTROLS
Touch buttons: move, combo, ki blast, guard, vanish, transform, ultimate.
Keyboard fallback: A/D/J/K/L/I/U/O.

WHAT IS INCLUDED
- 20-enemy battle
- Fast lightweight arena combat
- Combo attacks
- Ki blasts
- Guard
- Vanish/dodge
- 3 transformation upgrades
- Ultimate attack
- HP and Ki
- Mobile touch controls
- Low-end performance-oriented rendering

IMPORTANT
This prototype intentionally uses original placeholder art and does not include copyrighted Dragon Ball game assets. It is a foundation for expanding the game with original characters, worlds, abilities and progression.

HOW TO PLAY
1. Unzip the project.
2. Open index.html in Chrome/Firefox/Safari.
3. On Android, use the browser menu and choose "Add to Home screen" if you want it to behave like an installed web app.

NEXT DEVELOPMENT STAGE
A larger version can add character creation, races, quests, multiple maps, bosses, save data, more combat moves and a real 3D engine/build pipeline.
