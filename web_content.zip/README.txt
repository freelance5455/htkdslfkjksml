HTML & ZIP -> APK Builder (URL-free single-page edition)

Files:
- index.html: app interface, ZIP selection, file listing, and index.html preview
- app-logo.svg: original app logo

Important:
This is a browser-based front end. It can read and preview a ZIP (the JSZip library is loaded from a CDN, so internet is needed for ZIP reading). It does NOT compile a real Android APK. Genuine APK output requires a build service or a native Android build environment. The build-service URL field has been removed as requested; APK buttons explain that no APK is available rather than generating a fake file.

Open index.html in a modern browser. For ZIP reading, stay connected to the internet.
