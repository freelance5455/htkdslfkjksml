# The Kishore Chronicles — website app

This package keeps the Version 2 interface and adds installable-PWA files plus an optional Google Drive encrypted-backup flow.

## Important before use
- This is a static website package, not yet published online.
- Diary entries remain in this browser's local storage. Moving from a local HTML file to a hosted HTTPS site creates separate browser storage; export an encrypted backup from the old app before switching.
- Google Drive backup needs your own Google Cloud OAuth **Web client ID**, the Google Drive API enabled, and the hosted website's exact HTTPS origin added to the OAuth client's Authorized JavaScript origins.
- Do not put a Google client secret in this app. The app only asks for a public OAuth client ID.
- Drive upload stores an encrypted backup JSON file. Keep the encryption password safe. Google sign-in may need to be repeated.
- Do not upload private diary entries or backups into the public hosting repository. Only upload these app files.

## Publish free with GitHub Pages
1. Create a GitHub repository. If using GitHub Free, a Pages site from a private repository may not be available for your account setup; a public repository is the simplest free route.
2. Upload the files in this folder (`index.html`, `manifest.webmanifest`, `sw.js`, `icon-192.svg`, `icon-512.svg`) to the repository root.
3. In repository Settings → Pages, enable deployment from the main branch and root folder.
4. Wait for the Pages URL, open it on your phone, then use Chrome menu → Add to Home screen / Install app.
5. For Drive backup, in Google Cloud Console create/select a project, enable Google Drive API, configure OAuth consent screen, add your Google account as a test user if the app is in Testing, and create an OAuth client ID of type Web application. Add the exact GitHub Pages origin (no path) as an Authorized JavaScript origin. Paste the client ID into Settings → Google Drive backup → option 1.

## Test the app
Serve the folder over localhost or HTTPS to test PWA installation. Service workers do not run from `file://`.
