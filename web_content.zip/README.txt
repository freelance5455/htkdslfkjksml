AIM HTML Studio Offline — version corrigée

Cette version corrige une erreur de syntaxe JavaScript qui empêchait les fonctions de démarrer. Ouvre index.html dans Chrome ou un navigateur qui autorise JavaScript. Le convertisseur HTML→APK doit aussi autoriser JavaScript.

Fonctions : éditer HTML, ouvrir un fichier HTML, enregistrer le code, actualiser l’aperçu et générer un ZIP source Android WebView. La génération du ZIP source ne compile pas directement un APK. Pour obtenir un APK natif, compile le projet avec Android SDK + Gradle.
