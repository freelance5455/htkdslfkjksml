Hubby & Wifey — corrected offline web package

This package contains the PIN validation correction. It is a web package for a WebView/HTML-to-APK builder, not an APK. Rebuild the APK from this ZIP to apply the fix. The PIN is a basic local gate, not native Android security.
