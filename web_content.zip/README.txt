ABDIA'S BOOK
Created by A.H ABDILLE

This ZIP is an offline HTML app designed for HTML-to-APK converters.
Main file: index.html
Photo: assets/abdia.jpg
All dictionary data is embedded in index.html. No Firebase, login, phone number, server or internet is required by the app.
