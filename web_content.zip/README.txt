blure v0.6.9

UPLOAD
Upload the CONTENTS of this ZIP into your hosting htdocs folder, replacing existing files.
Delete old leftovers if present: offline.html, test.html, sw-test.html, server.log, *.py, *.png test screenshots.
Open /index.html (offline IDE) or /php-playground.php (PHP mode, needs PHP 8.1+).

OFFLINE FILE
blure-offline.html is the whole IDE in ONE file.
- Open https://blure.rf.gd/blure-offline.html in the browser to use it online (nothing to download).
- To use it with NO internet, open https://blure.rf.gd/download.php once, save the file to your phone, then open the saved copy any time.
  (A website cannot work offline on this host because it blocks the service worker, so a saved copy is the only offline way.)
- The saved copy checks version.js when you open it online. If a newer version exists, an "Update available" button appears: tap it and save the new file over the old one.
  The footer also has a "Check for updates" button. The website address is set at the top of dev-tools/build-offline.py (SITE).
To release a new version: change the version in blure-runtime.js, run  python3 dev-tools/build-offline.py  and upload index.html, blure-offline.html and version.js.

FILES
index.html            the IDE (index.php just serves the same page)
blure-runtime.js      offline interpreter
blure-offline.html    single-file offline IDE (download this to your phone)
version.js            latest version number, read by the update check
download.php          downloads blure-offline.html as a file
blure-engine.php      PHP interpreter used by php-playground.php
sw.js / sw.php        service worker (sw.php is a fallback for hosts that serve .js as text/html)
manifest.webmanifest  installable app info (+ icons)

LANGUAGE NOTES
- Every program needs exactly one start.fn.mn(name) and a closing close.fn.mn (both runners now report an error if missing/duplicated).
- Comparisons: = equal, / not equal, gt, lt, gt=, lt=. Division is math.div(a,b); / is NOT division.
- Inside show(...), > separates groups (it is not a comparison there).
- Text formatting inside strings or after show(): /n \n newline, /l3 \l3 lines, /p \p paragraph, /t2 \t2 tabs. Use // for a literal / and \\ for a literal \ (so "http://x" prints as http:/x; write "http:////x" for two slashes).
- Reserved words cannot be variable names: show check loop repeat make change start close run give end input break continue try catch finally raise math true false null.
- Decimal results are shown to 14 significant digits (0.1+0.2 shows 0.3).
- Interactive input: input.var / input.num / input.yesno / input.password; several prompts separated by >. Works in both offline and PHP modes.

LIMITS
50,000 instructions, 2,000,000 characters of source, 100 input answers (10,000 chars each), 2 MB virtual storage (PHP mode).
PHP mode: same-origin requests only, 120 runs per minute per session.

NOT a native compiler: programs are interpreted; eval() is never used on user programs.
