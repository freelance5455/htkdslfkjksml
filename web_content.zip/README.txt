BINANCE AI ANALYZER — ANDROID PACKAGE

FILES
- index.html: app screen
- style.css: mobile-friendly design
- script.js: Binance market data and indicator calculations

RUN ON ANDROID (SPCK EDITOR)
1. Extract this ZIP into a folder.
2. Open SPCK Editor and open/import the extracted folder.
3. Open index.html and use SPCK Preview / Live Preview.
4. Keep the phone connected to the internet.

IMPORTANT
- This is a web app, not an installable APK. To install as an Android app, host the files on HTTPS and wrap the hosted page with a WebView/PWA or Android app builder.
- Binance public market-data endpoints are used; no API key is required for these public endpoints.
- If the preview reports a network/CORS error, run it from an HTTPS web host rather than opening index.html directly as a file.
- The displayed BUY/SELL/WAIT output is a basic technical indicator calculation, not an AI prediction or guaranteed trading advice. Verify independently and manage risk.
- Binance service availability and regional restrictions may affect data access.
