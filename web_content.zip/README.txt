SoftSpring HTML & ZIP File to APK Builder用
ZIP直下にindex.htmlがあります。
PDFはAndroid共有機能へ渡す方式です。共有先に印刷・Files・Drive等があれば、そこから保存/印刷できます。
