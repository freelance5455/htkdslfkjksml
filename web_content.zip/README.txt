Calculadora lista para convertir a APK.
Nombre sugerido: Calculadora
Package sugerido: com.calculadora.app
