BubbleDefence 0.5.0  (vancode.io, MIT)
Spusteni: rozbal celou slozku a otevri index.html primo v prohlizeci (bez serveru, bez internetu).

lib/      sora.css, vue.global.prod.js (offline knihovny)
css/      base, window (uvod/menu/nastaveni), map, game
js/core/  bd.js (namespace window.BD), store.js (profil, localStorage, export/import JSON)
js/systems/  grid, towers, enemies, projectiles, waves, levels, game  (cista logika bez UI)
js/data/towers/  jedna kategorie veze = jeden soubor (base = zakladni vez, normal, burst, ghost, boost): zaklad + 3 vetve. Nova veze = novy soubor + radek v index.html
js/data/  presets (mapy), story (uzly mapy levelu), tutorial (kroky)
js/render/  draw.js, renderer.js (canvas)
js/ui/    Vue komponenty (intro, menu, settings, story-map, game-view, editor-view, backdrop, app)
js/main.js  start
tests/    node tests/test_systems.js ; python3 tests/ui_flow.py ; python3 tests/ui_mobile.py

Novy skript: pridej <script> do index.html (poradi je dulezite - zadne ES moduly kvuli file://).
Placeholdery: editor, zvuk, jazyk, story levely 3+ (generovane), 3D patra.

Level (v2): w,h = rozmer v vezich (4-32); mrizka je 2x2 bunky na vez (BD.SUB). spawns = 1-8 bran {side:L|R|T|B,pos,len} (mezery v okraji pole),
exit = cil: brana na okraji {side,pos,len} NEBO koule uvnitr pole {orb:[[x,y],...]}; rocks = skaly [[x,y]] nebo [[x,y,g]] (stejne g a sousedni bunky = jedna souvisla skala),
walls = zdi (presny ctverec), vse v bunkach. Brany se nesmi dotykat (mezi nimi aspon 1 bunka). Stary format se prevadi sam.
Pravidla (volitelna): lives (1-999), gold (0-99999), waves (10-999, 0/nic = nekonecno), hp (nasobek zdravi bublin 0.25-5),
allowed (povolene kategorie vezi, napr. ['normal','burst']), towers (predpostavene veze [{type,x,y}]).
Ve hre jsou brany jen diry ve zdi (bez barev); barevne sipky vidis jen v editoru a v nahledech levelu.
Editor: S skala, Z zed, G guma, V vstup, C cil, T vez; 1/2/3 stetec; Ctrl+Z zpet; prave tlacitko mysi maze.
Testy: node tests/test_systems.js ; python3 tests/ui_flow.py ; python3 tests/ui_editor.py ; python3 tests/ui_orb.py ; python3 tests/ui_belt.py ; python3 tests/ui_layout.py ; python3 tests/ui_zoom.py ; python3 tests/ui_keys.py ; python3 tests/ui_mobile.py

Pás vln (0.6.0): vpravo od hrací plochy (na mobilu pod ní) jede pás bloků – každý blok je jedna vlna
(barva podle nepřátel, počet, společné zdraví, boss má třpytivý blok). Po Startu vlny přijíždějí samy
po odstupu (pravidlo levelu "Odstup vln", výchozí 20 s). Klik na k-tý blok přivolá k vln najednou
s malým odstupem. Zkušební hra z editoru se nikam neukládá a vrací se zpět do editoru.

Rozložení hry (0.6.1): vlevo základna (se třemi čísly) a pod ní karta a upgrady vybrané věže, vpravo jen pás vln.
Nastavení zobrazení (dosah, trasa, délka cesty, mřížka) je jen v globálním nastavení; ve hře ho otevřeš z Menu > Nastavení (popup).
Pás: blok ukazuje číslo vlny, nahoře zapadá do rámečku; přivolané vlny letí nahoru plynule.

0.6.2: Základna už střílí (slabě, nezasáhne duchy) a po kliknutí se vylepší na kategorii. Pás vln přiléhá k hrací ploše,
nahoře má výrazný rámeček; přivolané vlny čekají ve frontě a vyrážejí po jedné (blok vždy jede nahoru, nikdy dolů).

0.7.0: Pás vln je širší (karty na šířku, vyplní místo vpravo) a ukazuje druhy nepřátel ve vlně.
Zoom: když je mapa moc velká (buňky by byly malé), zapne se přiblížení – táhni myší/prstem nebo kolečkem/šipkami,
vpravo nahoře je minimapka s právě viditelným výřezem (klik/tažení přesune pohled) a tlačítko "Celá mapa" / "Přiblížit".
Story mapa levelů jde také přibližovat (kolečko, +/−, štípnutí, tažení, minimapka, "Celá mapa").
Story: po výhře tlačítko "Další level" – podle cesty mapy, na rozcestí vybere náhodnou větev.

0.7.1: Klávesy ve hře: T = věž Základna, S/Delete = prodat, M sloučit, P pauza, mezerník další vlna, 1-3 věže, šipky posun zoomu.
Klávesy se berou podle fyzické klávesy (funguje i s českou klávesnicí) a Ctrl/Alt kombinace se ignorují. Caps Lock se rozpoznává (v.caps);
v tabulce keymap v game-view.js jde zkratce nastavit caps:true/false a shift:true/false.
Spodní lišta (.dock) je připravená, ale vypnutá: zapne se BD.debug.dock.enabled = true (ve hře), později se napojí na funkci.

0.7.2: Pás vln je pravý sloupec (288 px, stejně široký jako levý) bez mezery vpravo; karty vln jsou poloviční, na pás se jich vejde 10 (na mobilu 5).

0.7.3: Zoom ve story mapě (tlačítka, minimapka, kolečko, štípnutí) se nabídne jen u velkého stromu: odkryto aspoň 10 uzlů, nebo je obrazovka tak malá, že jsou uzly moc blízko (BIG_NODES a MIN_GAP v story-map.js). Malý strom je vždy celý vidět.

0.8.0: Terminál (vývojářský příkazový řádek). Odemkne se napsáním slova "terminal" kdekoli ve hře (pauzy mezi klávesami max. 1,5 s; pamatuje se v prohlížeči),
otevírá se klávesou ` / ~ (nad Tabem), zavírá Esc nebo znovu `. Příkazy: help, clear, close/exit, version, status, godmod [on|off] (nekonečné životy a zlato),
livelog [on|off] (živý výpis dění vlevo dole), alllevels / dev [on|off] (odemkne všechny levely ve story módu, postup se nemění), gold N, lives N, lock.
Nový příkaz = jeden řádek v js/core/dev.js: BD.dev.command('jmeno', 'nápověda', function (args, out) { … }).
Sekvence kláves obecně: BD.keys.sequence('kód', funkce) v js/core/keys.js; rozepsaný kód potlačí herní zkratky (ev.bdSeq).
Test: tests/ui_terminal.py (24).

0.9.0: Bestiář (kniha). Otevře se klávesou B, ikonou otevřené knihy (ve hře nahoře, na mapě levelů, v menu "Bestiář"), zavře Esc / křížek / klik mimo.
Tři záložky vyjíždějí zpoza pravé hrany knihy (Nepřátelé, Věže, Karty a bonusy), přepnutí listuje stránku. Vlevo seznam s hledáním a značkou "nové",
vpravo detail. Tři stupně odkrytí: 0 rozmazaná silueta a ???, 1 ostrá silueta + jméno + krátký popis, 2 plný popis (statistiky z dat hry, výhody, nevýhody, tip).
Nepřítel: viděn = poprvé se objeví v boji, poznán = dokončíš level, ve kterém se objevil. Věž: viděna = nabídne se (základna hned, kategorie při výběru vylepšení),
poznána = postavíš ji; sloučení XL/XXL se zapisuje. Stav je v postupu hráče (profile.bestiary). Při otevřené knize je hra pozastavená.
Texty záznamů: js/data/bestiary.js (nový nepřítel/věž = jeden objekt, id sedí s daty hry). SHOW_UNKNOWN v js/ui/bestiary.js = ukázat neodkryté jako ???.
Terminál: příkaz bestiary all | reset. Test: tests/ui_bestiary.py (31).

0.9.1: Bestiář: při listování záložek obsah stránek zmizí (fade) hned se začátkem animace a nový se vyfade ještě před dosednutím listu (žádný přeblik).

0.10.0: Karty (odměny). Spodní lišta (.dock) mezi levým sloupcem a pásem vln; hráč o kartách neví, dokud nějakou nezíská (pak se lišta vysune,
objeví se oznámení a v bestiáři záložka "Karty"). Padají za zabitého bosse (100 %) a za bezchybnou vlnu (25 %) - data/cards.js (drop).
Karty: Atomovka (zničí všechny nepřátele, i bosse) a Meteorický roj (8-14 náhodných meteoritů na cestě, bosse jen zraní o 20 %).
Klik na kartu ji použije; klávesa C lištu schová/ukáže; plná lišta se posouvá vodorovně (i kolečkem myši).
Tutoriál a levely t1, l2 (noCards:true v story.js) karty nedávají. Ve story módu se karty ukládají (profile.story.cards) a přenášejí do dalšího levelu;
prohra levelu vrátí karty do stavu na začátku levelu. Nová karta = objekt v js/data/cards.js + efekt v js/systems/cards.js (EFFECTS) + text v js/data/bestiary.js.
Terminál: card <id>. Test: tests/ui_cards.py (20).

0.11.0: Export / import levelů z editoru. V editoru tlačítka Kopírovat (level jako text do schránky) a Export (soubor level-<nazev>.json).
V menu Editor: Načíst ze souboru, Vložit text, Exportovat vše (bubbledefence-levely.json). Formát: {"game":"BubbleDefence","type":"levels","v":1,"levels":[…]};
import level vždy přidá jako nový (nové id), data prochází stejným čištěním jako uložený postup (limity rozměrů, počet vln…).
Kód: store.exportLevels / store.importLevels (js/core/store.js), pomocné stažení/kopírování js/ui/level-io.js. Test: tests/ui_levelio.py (11).

0.12.0: Duchové letí skrz skály i věže. Mají vlastní pole vzdáleností game.distG (jen zdi a okraj blokují, osm směrů, úhlopříčka neřeže roh zdi), počítá se jednou při startu levelu.
Zeď ducha nezastaví napořád - obletí ji. Věže při míření na ducha berou jeho vzdálenost (distG). Ostatní nepřátelé beze změny (game.dist).
Kód: grid.bfs(…, diag), enemies.nextCell(…, ghost). Test: tests/test_systems.js (3 nové), tests/ui_ghost.py (3). Text ducha v bestiáři upraven.

0.13.0: Studio (vývojářský editor nepřátel a věží) + nové mechaniky + oprava duchů.
Oprava: duch proletěl zdí, když se na jedné buňce překrývala skála a zeď (story level Bludiště). Teď duchové zdi vždy obletí; test projede všechny presety a story levely.
Studio se zapíná JEN příkazem  dev  v terminálu (odemčení: napsat "terminal", otevření ` nebo ~). dev = zapne a otevře okno, dev on|off zapne/vypne, studio = znovu otevře okno.
Vypnuté Studio = hra jede s původními daty a v menu ani ve hře po Studiu není stopa. (Starý alias dev = alllevels zrušen, použij alllevels.)
Okno: Nepřátelé / Věže; vlevo seznam + "Nový" (identifikátor malými písmeny), uprostřed formulář (posuvník + číslo, hodnoty se ořežou do mezí, ↺ vrátí výchozí hodnotu pole),
vpravo živý náhled, shrnutí a "Zkusit ve hře" (prázdné pole, 5000 zlata, každá vlna = vybraný nepřítel; u věže je nová kategorie v nabídce vylepšení Základny). Tlačítko Studio je i v liště hry a v menu.
Export / Import: JSON { items (úpravy), result (hotové definice změněných položek) } - kopírovat, stáhnout, načíst. Úpravy jsou v postupu (profile.studio) a platí po obnovení stránky, dokud je Studio zapnuté.
Nepřítel (pole): name, color, hp, speed, reward, r, life; ghost; resist (0-0.9 snížení poškození); regen (zdraví/s); slowImmune; splitCount + splitInto (po smrti se rozpadne, max 3 generace, atomovka rozpad neprovede);
  atkDmg + atkRange (věží) + atkCd + atkStop (útočí na nejbližší věž, při atkStop při útoku stojí).
Věž (pole): name, color, desc, cost, order, role (shot / burst / boost), upgradeOnly, hp (životy věže; roste s úrovní ×1+0.25/úr. a ×3 za sloučení), target (first / close / strong / weak), hitsGhost, onlyGhost,
  base {dmg, range, cd, speed, splash, slow, boost}, 3 větve (name, desc, mods dmg/cd/range/splash/slow/boost).
Věže mají životy (t.hp, t.s.hp), poškozená věž má nad sebou pruh; zničená zmizí, cesta se přepočítá, událost 'towerLost'.
Kód: js/core/studio.js (data, schémata, apply, export), js/ui/studio.js + css/studio.css (okno), mechaniky v systems/enemies.js (hurt, onDeath, attackTowers), towers.js, game.js (destroyTower).
Testy: tests/ui_studio.py (31), tests/test_systems.js (+5 mechanik, +1 duchové/zdi).

0.14.0: Studio přes celou obrazovku + grafický návrh vzhledu + pravidla vln. (Příkaz  dev  zrušen, nahrazen příkazem  studio.)
Zapnutí: v terminálu (odemčení: napsat "terminal", otevření ` nebo ~)  studio  (on/off; bez parametru zapne). Po zapnutí se v menu mezi Story/Editor/Volná hra objeví položka Studio = celoobrazovkové Studio.
studio off = původní data, položka z menu zmizí; úpravy zůstávají uložené (profile.studio) pro příště.
Záložky: Vzhled / Vlastnosti / Vlny; nahoře Nepřátelé / Věže; Export / Import; "Zkusit ve hře" (prázdné pole, hodně zlata, vlny jen z vybraného nepřítele); tlačítko Studio v liště hry vrací zpět.
Vlastnosti: stejná pole a mechaniky jako v 0.13.0 (viz výše), rozšíří se později.
Vzhled (js/render/sprite.js): hřiště s kolečkem/tlačítky přiblížitelné až ×60, osy, mřížka, míry, dosah, animace zap/vyp, "Skutečná velikost" (vložené okno ve hře ×1), světlé pozadí.
  Vrstvy = strom (skupiny uvnitř skupin, max 80 vrstev, hloubka 6): Kruh, Prstenec, Elipsa, Obdélník, Mnohoúhelník, Hvězda, Skupina. Seznam: nahoře = vepředu; ↑/↓ pořadí, Seskupit, Kopie, Zpět (Ctrl+Z), smazat, změna rodiče.
  Každá vrstva: poloha, otočení, velikost, průhlednost, výplň (plná / lineární / radiální přechod s barvami a polohami), okraj, stín. Klik na plátno vybere nejvyšší vrstvu pod myší, tažením se posouvá.
  Skupina může mít animaci: míří (otáčí se podle míření věže - hlava se točí, tělo stojí), točí, pulzuje, houpe se. Nepřítel nebo věž bez vlastního vzhledu se kreslí jako dřív; "Začít ze šablony" udělá výchozí vzhled.
  Data: položka.sprite = {v:1, nodes:[…]}; sanitize ořeže počty, rozměry a barvy (jen #hex / rgb(a)), takže i podvržený import je bezpečný. Věž má jeden vzhled pro všechny větve.
Vlny (nepřátelé): waveMode = builtin (původní předpis) / none (nikdy ve vlnách - např. potomci rozpadu) / rules (vlastní pravidla):
  waveFrom (od vlny), waveTo (do vlny, 0 = bez konce), waveEvery (každá N-tá vlna), waveCount + wavePer (počet a přírůstek), waveGap, levelFrom (od N-tého levelu = dokončené story levely + 1; ve volné hře se ignoruje).
  Vestavěného nepřítele lze z vln vyřadit, prázdná vlna nespadne.
Kód: js/render/sprite.js, js/ui/studio.js, css/studio.css, core/studio.js, systems/waves.js. Testy: tests/ui_studio.py (41).

0.14.1: Studio - pozadí hřiště je jako ve hře (šachovnice buněk, výraznější čáry po 2 buňkách = hranice věží). Míry: rámečky N×N buněk (1,2,3,4,8,20 + vlastní 1-60, lze kombinovat, popsané),
  nepřítel má výchozí 1×1, věž 2×2. Tlačítko "střed" přepíná, zda střed postavy leží ve středu buňky (nepřítel) nebo v rohu (věž). Okénko "ve hře (×1)" má také podlahu.

0.14.2: Studio - nástroje vzhledu.
  Shift při tažení tvaru na plátně = posun jen po osách po 45° (vodorovně, svisle, úhlopříčky; v obrazovém směru).
  Seznam vrstev: drag & drop - tažením vrstvu přesuneš výš/níž (okraj řádku = nad/pod cílem) nebo vložíš do skupiny (střed řádku skupiny); do vlastního potomka a přes limit hloubky to nejde.
  Zrcadlení: osa přímkou přes střed (x,y) pod úhlem (svislá 90°, vodorovná 0°, ±45°, libovolný úhel); "Zrcadlová kopie" přidá obraz, "Převrátit tvar" zrcadlí tvar samotný. Uzel má nové pole flip (zrcadlí se i animace).
  Opakovat kolem středu: počet kusů (2-24), rozsah ° (360 = celý kruh), střed x,y; vytvoří otočené kopie (do limitu 80 vrstev). Osa/střed se ukazují na plátně (lze vypnout).
  Cíl (tlačítko Cíl): smyšlený cíl obíhá kolem objektu, čára a šipka ukazují, kam míří předek (0° = doprava). Při vypnuté animaci se směr cíle zadá ve stupních.
  Pozn.: ve hře mají nepřátelé aim = 0 (nemíří), takže u nich je předek vždy doprava; věž míří na cíl.

0.14.3: Studio - nová položka: text v poli je rovnou její NÁZEV (identifikátor se odvodí sám: bez diakritiky, malá písmena, při shodě se přidá číslo; diakritika a mezery jsou povolené).
  Název jde přepsat kdykoli v poli "Název" úplně nahoře v pravém panelu (na všech záložkách), v seznamu vlevo se projeví hned.

0.14.4: Studio - výběr a skupiny ve vzhledu.
  Tažení na plátně: když klikneš na už vybraný tvar (i skupinu), hýbe se právě on, i kdyby nad ním ležel jiný objekt - výběr nepřeskočí. Klik mimo vybraný tvar vybere to, co je tam nahoře; Alt+klik vybere vrchní tvar i nad vybraným; Ctrl+klik přidá/odebere tvar z výběru.
  Více vrstev: v seznamu Ctrl+klik (přidat/odebrat), Shift+klik (rozsah), "Vybrat vše". Pro všechny vybrané platí: smazat, Seskupit, ↑/↓, Kopie, drag & drop v seznamu, zrcadlení i opakování kolem středu, tažení na plátně (vybrané jsou obarvené, hlavní žlutě). Vlastnosti v pravém panelu upravují hlavní (poslední kliknutou) vrstvu.
  Skupinu lze zrcadlit i opakovat celou (kopie obsahuje vše uvnitř).
  Sbalení: ▾/▸ u skupiny skryje její prvky v seznamu (počet se ukáže v závorce); "Sbalit vše" / "Rozbalit vše". Výběr tvaru na plátně a přidání do skupiny skupinu samo rozbalí. Stav sbalení se neukládá s postupem.

0.15.0: Vlastní ColorPicker (js/ui/colorpicker.js + css/colorpicker.css) místo systémového výběru barvy - zatím ve Studiu (barva věže/nepřítele, výplň, okraj, stín).
  Tlačítko barvy (vzorek + kód) otevře okno, které vyskočí NAD tlačítkem (nemá-li nad sebou místo, pod ním); zavře se klikem mimo nebo Esc. Barva se mění průběžně.
  Řádek 1: přepínač HEX / RGB / HSL / HSB.
  Řádek 2 (pokaždé jiný): HEX = čtverec sytost×jas + pruh odstínu + pruh průhlednosti (+ pipeta, je-li ji prohlížeč umí);
    RGB = plocha R×G + svislý pruh B; HSL = plocha odstín×sytost + svislý pruh světlosti; HSB = kruh odstínu s čtvercem sytost×jas uvnitř. (RGB/HSL/HSB mají i pruh průhlednosti.)
  Řádek 3: HEX = zápis #RGB / #RRGGBB / #RRGGBBAA; ostatní = posuvníky (vybarvené podle toho, co změní) a číselná políčka; u barev s průhledností i A (0-100).
  Řádek 4: posledních 8 a 8 nejčastěji používaných barev (pamatuje se v tomto prohlížeči, localStorage "bd.colors.v1"; zapisuje se při zavření okna, když se barva změnila, nebo po výběru vzorku).
  Výstup: "#rrggbb" (bez průhlednosti) nebo "#rrggbbaa". API: BD.ui.colorPicker.open(prvek, barva, {alpha, onChange, onClose}), .close(), .parse(), .format().
  Test: tests/ui_colorpicker.py (24).

0.15.1: Základní věž má navržený vzhled (js/data/towers/base_look.js - tower 'base' = Základna; z exportu ze Studia: modré tělo s nohami a otáčivou žlutou hlavou s kanónem; otáčí se jen hlava).
  Vzhled věže podle stupně: věž má výchozí vzhled (sprite) a volitelně pole looks [{level 2-4, branch '' | id větve, sprite}]. Vzhled platí od dané úrovně výš; vzhled s větví má přednost před obecným, jinak vyhrává vyšší úroveň.
  Studio → Věže → Vzhled: nahoře pruh stupňů ("Výchozí", "od úrovně 3", "Silná · od úrovně 2"…). "Jiný vzhled od [úrovně] [větev] + Přidat" vytvoří kopii právě zobrazeného vzhledu, kterou upravíš; "Smazat tento vzhled" ho odstraní.
  Okénko "ve hře (×1)" u věže ukazuje věž přesně tak, jak ji nakreslí hra (včetně čtverečků úrovně a vzhledu zvoleného stupně). Kód: BD.systems.towers.look(t), draw.tower.
  Export / Import: zaškrtávátko "jen vybraná položka" (výchozí zapnuto) - exportuje jednu věž / jednoho nepřítele (se vzhledy stupňů); bez zaškrtnutí všechno. Import vždy přidává/přepisuje jen položky ze souboru, ostatní nechá.
  Testy: tests/ui_looks.py (14).
0.15.2: Navržený vzhled patří Základně (věž "base"), ne Základní (věž "normal"; ta má zase výchozí kreslení). Studio - export už neobsahuje smazané ani osiřelé položky (jen to, co je v seznamu); při zapnutí/úpravě se z profilu uklidí záznamy bez existující položky.
0.16.0: Studio - (1) převzetí vzhledu z jiné věže/nepřítele (i z jejich stupňů): u položky bez vzhledu "převzít vzhled z", u hotové "Nahradit kopií" (jde Zpět); tlačítko "+ Duplikovat sem" duplikuje vzhled pro stupeň. (2) Schránka tvarů: Kopírovat / Vložit (Ctrl+C / Ctrl+V) mezi libovolnými položkami (drží se i po obnovení stránky, kopie jde i do systémové schránky). (3) Hromadná úprava více vybraných vrstev: posun, otočení (kolem společného středu), změna velikosti % (skupiny i s dětmi), barva výplně, barva a tloušťka okraje, průhlednost. Test: tests/ui_multi.py.
0.17.0: Studio - seznam věží je rozdělený do skupin: (1) Základní věže, (2) Druhy věží a vylepšení (strom: druh -> větve -> chipy úrovní 2-4; puntík = úroveň má vlastní vzhled, čárkovaně = dědí), (3) Kombinované a (4) Výjimečné (zatím prázdné zástupné skupiny). Klik na větev otevře její vlastnosti, klik na úroveň její vzhled (nabídne vytvoření). Skupiny jdou sbalit. Test: tests/ui_tree.py.
0.17.1: Studio - seznam věží upraven: sekce Basic Tower / Upgrades (věž a pod ní odsazená vylepšení, ● = má vlastní vzhled) / Combinations; bez čtverečků úrovní. Panel Vzhled má nápovědu k úrovním a vylepšením, volba "Vzhled pro vylepšení ... od úrovně ...".
0.18.0: STROM VĚŽÍ. Úrovně (čtverečky 1-4) a větve jsou pryč; každé vylepšení je samostatná věž s vlastním id, vlastnostmi, cenou a vzhledem. Věž má pole parent (z které věže se vylepšuje): základna -> 4 druhy -> jejich 3 vylepšení (staré větve jsou teď skutečné věže s přepočtenými hodnotami z úrovně 2). Ve hře věž nabízí všechny své děti, platí se cena dítěte, volba je nevratná, kreslení podle hloubky ve stromě. Sloučení 2x2 je zatím vypnuté (kapitola Kombinace); staré uložené hry se převedou (kategorie + větev -> samostatná věž). Studio: sekce Basic Tower / Upgrades / Combinations, strom s odsazením a sbalováním, přetahování (na věž = vylepšení, nad/pod = pořadí), nové vylepšení vzniká pod vybranou věží, mazání i vestavěných věží (jdou obnovit), pole "Vylepšení z věže", upozornění na slabší vylepšení než rodič (jen varování). Vzhledy podle úrovně/větve zrušeny (každá věž má vlastní). Testy: tests/ui_tree.py, ui_towertree.py.
0.18.1: Export postupu (Nastavení) nově ukládá i stav vývojářského režimu (terminál, Studio zapnuté) a po importu se úpravy ze Studia hned projeví ve hře (dřív až po obnovení stránky). Test: tests/ui_roundtrip.py.
0.19.0: Vzhled může mít nejvýš 160 vrstev (dřív 80) a v editoru je počítadlo s ukazatelem (žlutě od 85 %, červeně když je plno; tlačítka přidání se pak vypnou). Nová záložka Studia „Šablony“: vzhled se nakreslí jednou a vloží do věží i nepřátel novým tvarem „Šablona“ (výběr šablony a měřítko). Změna šablony se projeví všude, kde je vložená. Šablona se počítá jako jedna vrstva (nejvýš 30 odkazů na vzhled), v šabloně další šablona být nemůže. Šablony jsou v exportu Studia i v exportu postupu. Opraveno tlačítko „Zahodit vlastní vzhled“. Test: tests/ui_templates.py.
0.19.1: Šablonu jde vložit i do jiné šablony (šablona na šabloně, libovolně do hloubky). Šablona nesmí obsahovat sebe sama ani oklikou přes jiné - takový odkaz se nenabídne a případná smyčka z importu se zahodí. Kreslení má pojistku proti zacyklení a přehnanému vnořování (do 6 úrovní). Počet použití šablony se počítá i přes vnořené šablony. (V 0.19.0 platilo, že v šabloně další šablona být nemůže - už neplatí.)
0.19.2: Studio: levý sloupec se seznamem je širší (260 px místo 210), tlačítka pro přidání tvaru jsou čtvercová s ikonou (název je v tooltipu), seznam vrstev je o 50 % vyšší (až 330 px, minimálně 135 px).
0.19.3: Studio: mezi záložkami (Nepřátelé | Věže | Šablony) je jemný svislý oddělovač; skupiny jsou v kódu (pole tabs, položka g), takže budoucí záložky Karty a Střelivo se jen zařadí.
0.20.0: Zkušebna ve hře (Studio → Zkusit ve hře): vlevo panel Zkušebna - postavíš rovnou kteroukoli věž ze stromu (i z hloubky, bez cesty přes vylepšení), vybereš nepřítele a vypustíš 1 nebo 10, zapneš/vypneš nekonečné zlato a životy, vyčistíš pole. Zkouška věže začne s vybranou věží připravenou k postavení. Nic se neukládá do postupu ani bestiáře. Test: tests/ui_lab.py.
0.21.0: Střelivo (1. etapa). Nová záložka Studia „Střelivo“ (mezi Věžemi a Šablonami) a pole Střelivo ve Vlastnostech střílející věže. Střelivo = vzhled a chování střely ve třech fázích: Výstřel (efekt u věže), Let (tvar střely, rotace, stopa, způsob letu naváděná / rovná / oblouk) a Dopad (efekt v místě zásahu). Každá fáze má vlastní tvar z vrstev (jako u věží), délku, velikost, průhlednost a natočení od začátku do konce. Poškození, dosah a prodleva zůstávají na věži; střelivo je jen násobí (násobek poškození a rychlosti). Dole je náhled s časovou osou: věž, cíl, přehrávání a posuvník. „Výchozí střela“ platí pro věže bez střeliva, nejde smazat a bez nakreslených tvarů se hra kreslí úplně po staru. Export / import ze Studia obsahuje i střelivo. Test: tests/ui_ammo.py + test_systems.js.
