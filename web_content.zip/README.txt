MURALI DIARY — ANDROID INSTALLATION

Included:
- index.html: complete diary app
- manifest.json: installable app settings
- sw.js: offline app shell cache
- icon.svg, icon-192.png, icon-512.png: 🙄 logo icons

FEATURES
- Create a 4-digit PIN on first open
- Write, edit, delete, and search diary entries
- Entries stored locally in the browser on this device
- Export and import JSON backups
- PWA install support and cached offline shell

IMPORTANT
This ZIP is a Progressive Web App (PWA), not a compiled APK.
For a proper install prompt and service worker, upload the extracted files to an HTTPS host.
Then open the hosted website in Chrome on Android and choose menu (⋮) > Install app or Add to Home screen.
Do not open index.html as a local file and expect PWA installation/offline service worker to work.

PRIVACY
Entries are stored in local browser storage. They are not encrypted and do not sync to another device.
The PIN is a simple lock screen, not strong encryption. Export backups and keep them safe.
Clearing browser data may delete diary entries.
