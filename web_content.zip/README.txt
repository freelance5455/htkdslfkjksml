Maintenance Stock & Vehicle Manager - App Package

Files:
- index.html: the software
- manifest.webmanifest: installable app settings
- sw.js: offline cache support
- icon.svg: app icon

Important:
For installable PWA behavior, upload these files to an HTTPS web host.
Then open the hosted index.html in Chrome on Android:
Chrome menu (⋮) > Install app or Add to Home screen.

This package does not create a native Android APK. It creates a web app that can be installed on the phone's home screen.
