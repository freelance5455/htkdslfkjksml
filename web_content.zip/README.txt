TGA 1 Android APK cloud build

1. Upload this ZIP contents to a new GitHub repository (not as a ZIP file; extract it first).
2. Open the repository Actions tab.
3. Select Build TGA 1 APK and run workflow (or push a commit).
4. Wait for green check, open the run, download artifact named TGA1-APK.
5. Extract artifact and install app-debug.apk on Android. Allow installation from your browser/files app when Android prompts.

This is a basic WebView wrapper. The game HTML is included as app/src/main/assets/index.html.
