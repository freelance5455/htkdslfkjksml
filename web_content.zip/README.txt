NEXORA CALCULATOR — first prototype

Files:
- index.html: calculator interface and calculations
- manifest.webmanifest: installable web-app settings
- sw.js: offline cache support

Important:
This is a working web-app prototype, not yet a signed Android APK.
To install it as an app through Chrome, these files must first be hosted
on an HTTPS website. Then open that website in Chrome and choose
Install app / Add to Home screen. A native APK and AdMob integration
are separate later steps.

The scientific-mode buttons are an early prototype; standard arithmetic
and percentage calculations are the main tested features.
