HOPPING PUMPKIN — APK CONVERSION SOURCE

Files:
- index.html: the complete game in one HTML file.

How to use:
1. Upload this ZIP to an HTML-to-APK builder that accepts a ZIP or website files.
2. If the builder asks for the start page, set it to: index.html
3. Choose Android APK and build.
4. Download the APK and test it on your Android phone.

Notes:
- This is a web game source ZIP, not an APK yet.
- The game can run offline once packaged if the converter bundles the HTML locally.
- If the converter asks for a website URL instead of source files, first host index.html as a website or choose a converter that supports local HTML/ZIP upload.
