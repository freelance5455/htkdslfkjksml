St Christopher Kids Nursery and Primary School - Accountability Portal (cloud version)

WHAT CHANGED
- All data is now shared live through your Firebase Realtime Database
  (https://st-christopher-kids-default-rtdb.firebaseio.com). Head, Bursar, teachers and parents
  each sign in on their own phone and see the same records.
- Works offline too: changes are kept on the phone and sent when the network returns.
- Fees pre-loaded: School fees 10,000 | PTA 500 per term | Development levy 1,000 | Assessment pack 2,000 |
  Tissue and soap 1,000 | Admission fee 2,000 (new pupils) | Day wear, PE wear, Cultural wear 6,000 each
  (tick the uniforms a pupil ordered when you add or edit the pupil).
- 15 subjects including CRS and Health Education & Health Habits.
- Parents: new "Teacher report" tab (best teacher of the term + their child's class teachers).

ONE-TIME FIREBASE SETUP (required)
Firebase console > Realtime Database > Rules, publish:
  { "rules": { "portal": { ".read": true, ".write": true } } }
Everything is stored under /portal. (Anyone who knows the database address could read it with these
rules, so keep the address private. Stronger locking needs Firebase Authentication.)

SIGN IN
Pick a role and enter its PIN (Admin / Bursar / Teacher / Parent). Parents also enter the child's
admission number. PINs can be changed in Settings (admin).

APK
Use index.html as the web app. The APK needs the INTERNET permission (APK Forge adds it by default).

IMPORTING THE SCHEME OF WORK
Weekly curriculum > pick class and term > Import scheme.
- scheme-files/scheme-of-work-first-term.json loads Primary 1 to 6 first term in one go.
- scheme-files/Primary-N-first-term.csv loads one class (opens in Excel; edit, then import for the class and term selected).

ADDING PUPILS IN BULK
Classes and registration lists > pick the class > "Paste / import list". Paste names (one per line, optional M/F, parent, phone) or choose a .csv/.txt file. Admission numbers are made automatically. Names already in the class are skipped.

FEE COLLECTION (Bursar)
Fee collection page: pick class and term, type the amount a parent has just paid next to the pupil and tap Add. The portal adds it to what was paid before, spreads it over the unpaid fees and updates the balance. Repeat until paid in full. History shows every instalment, with Receipt, Void and Print history. "Print collection sheet" prints the class sheet.

PRINTING
Every page has a Print button in the top bar; it prints the page you are on (without buttons).

PHOTOS AND QR CODE ON REPORT CARDS
- Add a photo: Classes page > Photo (next to the pupil) or inside Edit pupil > Take / choose photo.
- Many at once: Classes page > Upload class photos. Name each picture file after the pupil (for example Ada Nwosu.jpg) or the admission number (SCK-2026-002.jpg).
- Report cards show the photo (or a box to paste a passport photo) and a QR code with the pupil's name, admission number, class, term, total, average, position and a reference code. Any phone camera can scan it.

REPORT CARDS PAGE (Head and teachers)
Top menu > Report cards. Pick session, term and class. For each pupil: Preview, Remarks, Print. "Print all cards" gives one A4 page per pupil. "Suggest remarks for the class" fills class-teacher remarks (and head remarks when signed in as Head) which you can edit.
Remarks window: class teacher's remark, head teacher's remark (Head only) and 1-5 ratings for eight skills (punctuality, neatness, politeness, honesty, attentiveness, handwriting, sports, relationships).
The card shows: photo, details, class teacher, total/average/position/grade/class average, every subject with CA1, CA2, exam, total, performance bar, class average, grade, position and remark, skills ratings, attendance, next term date, remarks, signature lines and a QR code that verifies the card. Parents print the same card from their Results tab.

SHARING DATA BETWEEN PHONES (checklist)
1. Firebase console > Realtime Database > Rules: publish
   { "rules": { "portal": { ".read": true, ".write": true } } }
2. Install this same version on EVERY phone (Head, Bursar, each teacher, proprietor).
3. The top bar must show "● Live". A red bar means the phone is NOT sharing: tap "Check connection" and follow the fix.
4. Settings (Head) > Connection check shows how many pupils, payments, teachers, score sheets and attendance sheets are in the school database compared with this phone.
5. Phones also check for updates every 8 seconds, so entries appear on other phones within seconds even if the live link is blocked.
6. If a phone held records typed before it was linked, it asks once whether to use the school database (recommended) or add this phone's records to it. Records typed separately on different phones can appear twice, so enter each class once.
