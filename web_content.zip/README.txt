Partners Diary V3 — Direct Recruitment edition.
Features: Recruiting Partners, Advisor Candidates, Direct Recruitment assignment, editing, follow-ups, Call, WhatsApp/WhatsApp Business choice, local saving, Export Backup and Restore Backup.
Use index.html or upload the ZIP to an HTML-to-APK converter.
