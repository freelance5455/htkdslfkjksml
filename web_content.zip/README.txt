VYBORA AI — APKForge ZIP PROJECT

WHAT IS INCLUDED
- index.html: responsive dark AI-chat interface
- Demo responses clearly labelled as demo, so it does not pretend to be a real AI model
- Local chat history in the browser/app webview
- Settings field for your own backend URL
- No API keys embedded in the APK

HOW TO USE IN APKFORGE
1. Upload this ZIP using “Choose .zip file”.
2. The ZIP root contains index.html, as requested by APKForge.
3. Tap Preview it and test the chat interface.
4. Return from preview and create the app if the builder enables it.

IMPORTANT ABOUT REAL AI
This ZIP alone does NOT include a real AI model or backend. To get real AI replies, create a backend endpoint that accepts:
POST /chat
Content-Type: application/json
{"message":"Hello","history":[]}

It should return JSON such as:
{"reply":"Hello! How can I help?"}

Keep your AI provider API key on the backend, never in index.html or the APK.
The app sends a JSON request to the URL entered in Settings. Your backend must allow requests from the app origin / WebView (CORS where applicable), use HTTPS, and authenticate/limit requests appropriately.
Free AI provider quotas and hosting limits can change; unlimited free usage is not guaranteed.
