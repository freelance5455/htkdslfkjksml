BLAZING WHEELS CHAMPIONSHIP 2026 — OFFLINE LOCAL EDITION

FILES
- index.html: complete single-page app. No internet, server, framework, or external CDN required.
- README.txt: setup and limitations.
- FEATURE_CHECKLIST.txt: included feature checklist.

HOW TO USE
1. Keep index.html in the same folder as this README.
2. Open index.html in a modern browser to test it first. On first launch, create the first local account; it automatically becomes Race Director.
3. For your HTML-to-APK converter, import index.html (or import the ZIP/folder if the converter supports local assets). Choose an app name such as Blazing Wheels Championship 2026.
4. Launch the APK and create/sign in to the local account. Register actual riders before recording results. Only registered riders are seeded into the app; no placeholder racer names were invented.
5. Export a JSON backup regularly, especially before APK reinstall or clearing app/browser data.

SEE FEATURE_CHECKLIST.txt FOR THE BUILT-IN FEATURES.

IMPORTANT LIMITATIONS
- This package is an offline HTML app source, NOT an APK. The APK must be built by your converter and tested on the target Android device.
- Offline storage is local to that browser/app installation. It does NOT synchronise across phones. Shared live racer accounts and secure server-side Race Director permissions require a hosted backend and persistent database; an offline HTML file cannot provide those.
- Local accounts and PINs are stored on this device and are a convenience lock, not encryption or server-grade security. Do not store sensitive personal data.
- Browser storage can be cleared by Android, the browser, or uninstalling the APK. Export backups regularly. Photos consume local storage; if storage fills, export a backup and remove some photos.
- Timers are independent, manual elapsed-time clocks. They use timestamps to keep elapsed time accurate when the app is backgrounded, but they are not certified timing equipment and do not record laps automatically.
- Officials must manually verify laps, finish positions, bonuses, inspection status, race status, announcements and publication.
- Race 2 — Thunder Endurance Challenge is preloaded for 30 laps as Scheduled and Unpublished, with inspection set to Not inspected. Its date/time is intentionally blank because none was confirmed.
- The event track note is an estimate: two connected off-road circuits, grass/dirt/loose leaves, approximately 280–300 m per lap, 2–3 pit stops planned. Confirm actual measurements before race day.

SCORING
1st = 20 points; 2nd = 15; 3rd = 10; 4th = 5. Bonuses: technical zone +2, precision gates +2, sportsmanship +1. Only approved results contribute to standings. Team points are the sum of the approved points earned by that team's riders.
