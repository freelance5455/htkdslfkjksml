Fun Party Game

1. Extract the ZIP.
2. Open index.html in Chrome.
3. Choose Toss or Spin.
4. Toss and Spin include built-in browser sound effects; no external audio files are required.
5. Spin challenges can be added/removed and saved in the browser.

To publish on Netlify, upload the extracted folder (or ZIP) containing index.html.
