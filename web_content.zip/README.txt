NexaChat Web APK Source

This archive is prepared for ZIP-to-APK web builders.
index.html is at the archive root.
App name: NexaChat
Theme: Lemon Green Neobrutalism
