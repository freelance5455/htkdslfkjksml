नवयुवा दुर्गा पूजा समिति — HTML App ZIP
========================================

इस ZIP में मोबाइल-फ्रेंडली HTML ऐप का शुरुआती प्रोजेक्ट है।

मुख्य सुविधाएँ:
- समिति का नाम: नवयुवा दुर्गा पूजा समिति
- पता: रेलवे गेट, मार्कुंडी
- Admin ID: 7905106011
- Admin Password: 7905106011
- Admin यूज़र बना/बंद/हटा सकता है और सभी रसीदें देख सकता है।
- यूज़र अपनी रसीदें ही देख सकता है।
- यूज़र-आधारित रसीद नंबर अक्षर से शुरू होता है (A001, B001, C001...)।
- रसीद में नाम, मोबाइल, पता, सहयोग राशि, दिनांक।
- PDF/प्रिंट के लिए Print dialog; Android Chrome में “Save as PDF” चुनें।
- WhatsApp शेयर टेक्स्ट बनाता है। ब्राउज़र सुरक्षा के कारण यह PDF फाइल को अपने-आप WhatsApp में attach नहीं करता।

महत्वपूर्ण सीमाएँ:
1) यह ZIP अभी localStorage पर चलता है। इसका मतलब डेटा उसी ब्राउज़र/डिवाइस में रहता है।
2) अलग-अलग मोबाइलों पर कई यूज़र और सुरक्षित admin-only access के लिए Firebase Authentication + Firestore जोड़ना आवश्यक है। इस डेमो को बिना backend सुरक्षा के सार्वजनिक रूप से deploy न करें।
3) वर्तमान admin login कोड में दिख रहा है; production में इसे Firebase Authentication और server-side/Firestore rules से सुरक्षित करें।
4) यह HTML ZIP है; हर APK builder इसे समान तरीके से नहीं चलाएगा। पहले browser में index.html खोलकर परीक्षण करें।

चलाने का तरीका:
- ZIP extract करें।
- index.html को browser में खोलें।
- Admin login करें।
- Admin से यूज़र बनाएं, हर यूज़र को अलग prefix दें।
- User login से रसीद बनाएं।
- PDF के लिए “PDF सेव / प्रिंट” दबाएँ; print dialog में “Save as PDF” चुनें।

Firebase setup अभी शामिल नहीं है। यदि आपको सभी मोबाइलों पर online sync चाहिए, तो Firebase configuration और Firestore rules के साथ अगला संस्करण बनाना होगा।

UPDATE: Receipt layout expanded to full-screen height on mobile and full-page A4 print layout. Admin/User login panels are side by side, including narrow mobile screens. Durga illustration refreshed.
