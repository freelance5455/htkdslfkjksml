G3: GO GO GO! — Updated Playable Build

Changes:
- Removed the BOUNCE ON IT button from the home menu.
- Removed the music button beside the sound-effects button.
- Removed the Music CHANGE control from Settings.
- Music screen is hidden from the normal UI.
- Existing gameplay, levels, scoring, coins, XP, themes, shop, profile,
  leaderboard, settings, animations, and local save system remain.

Open index.html in a modern browser.
