Student QR ID — Privacy-Protected Demo

Files:
- index.html: browser app prototype

Features:
- Local demo admin login (default password: ChangeMe123!)
- Student information records
- QR code contains a random record ID only, not name/number/violations
- Uniform violation recording and history
- Basic local data export and deletion
- Camera scanning support when served over HTTPS with permissions

IMPORTANT PRIVACY LIMITATION:
This is a prototype for a school project. Data is stored in browser localStorage and the password gate is client-side; it is NOT strong security. A person with access to the device/browser may inspect stored data. Do not enter real student data or deploy for actual school use without school approval, secure server-side authentication, access controls, encryption, backups, retention/deletion policy, and a privacy review.

To try:
1. Open index.html in a browser (QR generation may need internet).
2. Default demo password: ChangeMe123!
3. Add fictional/test student data first.
