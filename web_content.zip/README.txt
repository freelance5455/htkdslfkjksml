FF CROSSHAIR HTML

File utama: index.html

Ini adalah versi web/HTML. Bisa dipakai untuk preview crosshair di browser
atau dimasukkan ke layanan Web/HTML-to-APK.

Catatan: HTML biasa tidak bisa membuat overlay di atas game Android.
Untuk overlay sungguhan di atas Free Fire tetap diperlukan aplikasi Android
dengan izin "tampil di atas aplikasi lain".
