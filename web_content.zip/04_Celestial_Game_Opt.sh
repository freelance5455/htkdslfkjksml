#!/bin/bash
# Celestial Game Opt 3.2 - Comandos limpos com 2>/dev/null || true
echo "Aplicando Celestial Game Opt..."

setprop debug.sf.multithreaded_present 1 2>/dev/null || true
setprop debug.sf.use_frame_rate_priority 1 2>/dev/null || true
setprop debug.sf.no_vsyncs_on_screen_off 1 2>/dev/null || true
setprop debug.hwui.use_buffer_age false 2>/dev/null || true
setprop debug.hwui.initialize_gl_always true 2>/dev/null || true
setprop debug.hwui.skia_atrace_enabled false 2>/dev/null || true
setprop debug.hwui.early_preload_gl_context true 2>/dev/null || true
setprop debug.hwui.skip_eglmanager_telemetry true 2>/dev/null || true
setprop debug.renderengine.restore_blur_step false 2>/dev/null || true
setprop debug.renderengine.skia_tracing_enabled false 2>/dev/null || true
setprop debug.renderengine.skia_use_perfetto_track_events false 2>/dev/null || true
setprop debug.renderengine.capture_skia_ms 0 2>/dev/null || true
setprop sys.use_fifo_ui 1 2>/dev/null || true
setprop vendor.perf.gestureflingboost.enable true 2>/dev/null || true
setprop vendor.perf.workloadclassifier.enable true 2>/dev/null || true
setprop sys.hwc.gpu_perf_mode 1 2>/dev/null || true

# FPS
settings put system peak_refresh_rate 120 2>/dev/null || true
settings put system min_refresh_rate 120 2>/dev/null || true

echo "Celestial Game Opt aplicado!"
