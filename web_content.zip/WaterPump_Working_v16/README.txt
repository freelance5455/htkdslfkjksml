WATER PUMP SYSTEM V16
=====================

V16 keeps the V15 AUTO-button fix and changes the Home Water Supply area to look like the same rounded function/button cards used by AUTO and PUMP controls.

Water Supply is one compact horizontal box:
  💧 Water Supply       WATER DETECTED
or
  💧 Water Supply       NO WATER

The status stays on the same line and does not create a second row.
