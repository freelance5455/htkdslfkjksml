const fs=require('fs'),vm=require('vm');
const values={}; const app={innerHTML:'',insertAdjacentHTML(){},addEventListener(){}};
const alerts=[];let confirms=0;
const document={getElementById(id){if(id==='app')return app;if(id==='loginForm')return {addEventListener(){}};return values[id]||null;},querySelectorAll(){return []},addEventListener(){},createElement(){return {getContext(){return {drawImage(){}}}}}};
const context={values,document,localStorage:{getItem(){return null},setItem(){}},structuredClone,Date,Math,JSON,Number,String,Array,Object,RegExp,Set,Map,encodeURIComponent,decodeURIComponent,URL,alert:m=>alerts.push(m),confirm:()=>{confirms++;return true},scrollTo(){},location:{href:''},navigator:{},console};
let src=fs.readFileSync('/tmp/flowtask/script.js','utf8');
src += `\nS.role='t'; S.currentUserId='teacher-demo'; S.page='inicio'; render();
if(!teacherHome().includes('TOTAL DE ALUNOS MATRICULADOS') || teacherHome().includes('ALUNOS COM ACESSO ATIVO') || teacherHome().includes('cadastrados pela professora') || teacherHome().includes('criadas em Nova turma')) throw new Error('dashboard labels incorrect');
S.students=[]; S.users=S.users.filter(u=>u.role==='t');
values.newStudentName={value:'Teste Novo'};values.newStudentEmail={value:'novo@example.com'};values.newStudentModality={value:'Turma'};values.newStudentClass={value:S.classes[0].id};
for (const id of ['newStudentPhone','newStudentAddress','newStudentBirth','newStudentLevel','newStudentEmergency','newStudentEmergencyPhone','newStudentNotes']) values[id]={value:''};
createStudent(); if(S.students.length!==1 || S.students[0].name!=='Teste Novo') throw new Error('save student failed');
values.invoiceClass={value:''};values.st={value:S.students[0].id};values.am={value:'199.50'};values.dt={value:'2026-11-01'};
createInvoice();if(S.invoices.length!==2||S.invoices[1].amount!==199.5||S.invoices[1].studentId!==S.students[0].id)throw new Error('monthly invoice failed');
S.materials.push({id:'test-material',title:'x'});deleteData('material','test-material');if(S.materials.some(x=>x.id==='test-material'))throw new Error('delete material failed');
deleteData('invoice',S.invoices[1].id);if(S.invoices.length!==1)throw new Error('delete invoice failed');

for(const [type,key] of [['lesson','lessons'],['live','live'],['exercise','exercises'],['research','researchMaterials']]){const id='test-'+type;S[key].push({id,title:'x'});deleteData(type,id);if(S[key].some(x=>x.id===id))throw new Error('delete '+type+' failed')}
const cid='test-class';S.classes.push({id:cid,name:'x',code:'FLOW-TEST'});deleteData('class',cid);if(S.classes.some(x=>x.id===cid))throw new Error('delete class failed');
const sid=S.students[0].id;deleteData('student',sid);if(S.students.some(x=>x.id===sid))throw new Error('delete student failed');
console.log('PASS dashboard labels, save student, launch monthly fee, and delete student/class/lesson/live/material/exercise/invoice/research items');`;
vm.runInNewContext(src,context);
