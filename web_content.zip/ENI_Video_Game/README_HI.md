# ENI Video Game — Android source project

यह एक हल्का Android WebView ऐप है। वीडियो YouTube के आधिकारिक embedded player से स्ट्रीम होते हैं; ऐप वीडियो डाउनलोड नहीं करता।

## ज़रूरी सेटअप: YouTube Search API key
1. Google Cloud Console में एक प्रोजेक्ट बनाएं।
2. YouTube Data API v3 enable करें और API key बनाएं।
3. `app/src/main/assets/index.html` खोलें।
4. `const API_KEY = "PASTE_YOUTUBE_DATA_API_KEY_HERE";` में अपनी API key डालें।
5. API key पर Android ऐप/वेबसाइट प्रतिबंध और quota सेट करें। सार्वजनिक ऐप में key को पूरी तरह छिपा हुआ न मानें; production के लिए सुरक्षित backend बेहतर है।

## Android Studio से APK बनाना
- Android Studio में इस फ़ोल्डर को Open करें।
- Gradle sync पूरा करें।
- Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
- Release APK के लिए Build > Generate Signed Bundle / APK का उपयोग करें।

## 5 MB लक्ष्य
प्रोजेक्ट में कोई तृतीय-पक्ष लाइब्रेरी नहीं है और release build में code/resource shrinking चालू है। फिर भी 5 MB से कम आकार की गारंटी नहीं दी जा सकती; अंतिम आकार Android Gradle Plugin, SDK और build configuration पर निर्भर करेगा। Android System WebView डिवाइस पर पहले से उपलब्ध होना चाहिए।

## सीमाएँ
- YouTube API quota और YouTube की शर्तें लागू होती हैं।
- कुछ वीडियो मालिक की embedding/privacy settings के कारण ऐप में नहीं चलेंगे।
- Full screen YouTube player के controls से उपलब्ध है।
- यह ऐप YouTube Premium सुविधाएँ, विज्ञापन हटाना, offline download या background playback उपलब्ध नहीं कराता।
