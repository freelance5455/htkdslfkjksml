# Mi Aplicación Escolar (Android WebView) — versión ligera

Proyecto Android Studio con cinco botones: Word, PowerPoint, Excel, Vídeo y Foto. Este ZIP se preparó para respetar el límite de 5 MB.

## Incluido en este ZIP
- Código Android/Kotlin, AndroidManifest.xml, Gradle, HTML, CSS y JavaScript.
- `files/lista_materiales.docx` (Word).
- `files/foto_proyecto.png` (imagen del proyecto).

## Archivos que debes añadir después de descomprimir
Por el límite de tamaño, no se incluyen el vídeo MP4 ni la presentación PPTX/PDF. Copia tus archivos en `app/src/main/assets/files/` con estos nombres para que los botones funcionen:
- `procedimiento.pptx` — presentación PowerPoint.
- `video_proyecto.mp4` — vídeo.

El botón Excel está preparado, pero falta un archivo `.xlsx`. Cuando tengas uno, cópialo a esa misma carpeta como `hoja_calculo.xlsx`. Si no se añade un archivo, la app mostrará un aviso en lugar de fallar silenciosamente.

## Cambiar rutas
Edita `app/src/main/assets/index.html` y modifica el objeto `FILES` al inicio del JavaScript. Los archivos locales deben estar en `app/src/main/assets/files/`.

## Compilar APK
1. Abre la carpeta del proyecto en Android Studio en una computadora.
2. Espera a que Gradle sincronice y descargue las dependencias (requiere conexión).
3. Para pruebas, selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. El APK debug normalmente queda en `app/build/outputs/apk/debug/app-debug.apk`.
5. Para distribuirlo, usa **Build > Generate Signed Bundle / APK > APK**.

Este ZIP es el proyecto fuente, no un APK ya compilado.
