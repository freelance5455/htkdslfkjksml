package com.miescuela.miaplicacionescolar

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("https://") || url.startsWith("http://")) {
                    try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                    catch (_: ActivityNotFoundException) { toast("No hay una aplicación disponible para abrir este enlace.") }
                    return true
                }
                return false
            }
        }
        webView.addJavascriptInterface(AndroidBridge(), "AndroidApp")
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class AndroidBridge {
        @JavascriptInterface fun openExternal(url: String) {
            runOnUiThread {
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    startActivity(intent)
                } catch (_: ActivityNotFoundException) {
                    toast("No hay una aplicación compatible instalada para abrir este archivo.")
                }
            }
        }
        @JavascriptInterface fun openAssetDocument(relativePath: String, mimeType: String) {
            runOnUiThread {
                try {
                    val safePath = relativePath.removePrefix("files/")
                    val dir = File(cacheDir, "school_documents").apply { mkdirs() }
                    val outFile = File(dir, safePath.substringAfterLast('/'))
                    assets.open("files/$safePath").use { input -> outFile.outputStream().use { output -> input.copyTo(output) } }
                    val contentUri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", outFile)
                    val intent = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(contentUri, mimeType)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(intent)
                } catch (_: ActivityNotFoundException) {
                    toast("No hay una aplicación compatible instalada para abrir este archivo.")
                } catch (_: Exception) {
                    toast("No se pudo abrir el archivo. Comprueba que esté incluido en la aplicación.")
                }
            }
        }
        @JavascriptInterface fun showMessage(message: String) { runOnUiThread { toast(message) } }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
