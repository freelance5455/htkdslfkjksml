GES Billing & Accounting App — Prototype v0.2

ZIP میں شامل:
- index.html: بنیادی آف لائن ویب پروٹوٹائپ
- FEATURES_COMPLETE_PLAN_UR.txt: آپ کے بتائے تمام فیچرز کی مکمل specification/checklist
- APK_FROM_MOBILE_UR.txt: موبائل سے APK بنانے کی اردو ہدایات

چلانے کا طریقہ:
1) ZIP Extract کریں۔
2) index.html کو Chrome میں کھولیں۔
3) Settings میں اپنی دکان کا نام، پتہ اور فون نمبر تبدیل کریں۔
4) Items & Stock میں آئٹمز شامل کریں، پھر New Bill سے بنیادی بل آزمائیں۔
5) Backup / Sync & Health سے JSON بیک اپ بنائیں۔

اہم:
یہ ابھی مکمل production app نہیں، بلکہ قابلِ استعمال ابتدائی پروٹوٹائپ اور مکمل فیچر specification ہے۔ موجودہ HTML میں ڈیٹا اسی ڈیوائس/براؤزر کے localStorage میں محفوظ ہوتا ہے۔ browser data صاف ہونے یا ڈیوائس خراب ہونے پر ریکارڈ ضائع ہوسکتا ہے، اس لیے JSON backup الگ جگہ محفوظ رکھیں۔

تمام بڑے فیچرز کی فہرست ZIP میں شامل ہے، لیکن Google login، محفوظ multi-tenant server/database، staff permission enforcement، online sync، مکمل double-entry accounting، supplier ledger/payments، payroll، branches، tax، warranty/serial، purchase orders، audit trail، aging reports، multiple account reconciliation اور حقیقی thermal printer integration کو مکمل بنانے کے لیے مزید coding، backend اور testing ضروری ہے۔

APK:
یہ ZIP براہ راست APK نہیں۔ index.html کو Android WebView/HTML-to-APK builder میں پیک کیا جا سکتا ہے، مگر ہر موبائل builder local HTML درآمد نہیں کرتا۔ مزید تفصیل APK_FROM_MOBILE_UR.txt میں ہے۔
