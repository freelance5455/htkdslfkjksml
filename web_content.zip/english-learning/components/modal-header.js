/**
 * Component: Modal Detail Header
 * Reusable ES6 Header Card for Modal Verb Detail Pages (pages/modal.html?id=...).
 */

import { escapeHtml } from '../assets/js/modal-utils.js';

/**
 * Create Modal Detail Header Card DOM Element
 * @param {object} lessonData - Lesson schema object from data/modals.js
 * @param {object} modalMeta - Modal metadata object from data/modals.js
 * @param {object} options - Options including basePath ('', '../')
 * @returns {HTMLElement}
 */
export function createModalDetailHeader(lessonData, modalMeta, options = {}) {
    const { basePath = "../" } = options;

    const card = document.createElement("section");
    card.className = "modal-detail-header-card";

    const title = lessonData.title || modalMeta.title || 'Modal Verb';
    const titleHindi = lessonData.titleHindi || modalMeta.titleHindi || 'मोडल वर्ब';
    const category = modalMeta.category || 'Modal Verb';

    card.innerHTML = `
        <div class="modal-detail-nav-bar">
            <a href="${basePath}pages/modals.html" class="btn-back-to-modals">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="19" y1="12" x2="5" y2="12"></line>
                    <polyline points="12 19 5 12 12 5"></polyline>
                </svg>
                <span>Back to All Modal Verbs</span>
            </a>
            <span class="modal-category-chip">${escapeHtml(category)}</span>
        </div>

        <div class="modal-detail-title-group">
            <div class="modal-detail-title-row">
                <h2 class="modal-detail-main-title">${escapeHtml(title)}</h2>
                <span class="modal-detail-status-tag">Foundation Active</span>
            </div>
            <span class="modal-detail-hindi-title">${escapeHtml(titleHindi)}</span>
        </div>

        <div class="modal-detail-meta-pills">
            <span class="meta-pill">
                <strong>Meaning:</strong> ${escapeHtml(modalMeta.hindiMeaning || titleHindi)}
            </span>
            <span class="meta-pill">
                <strong>Rule:</strong> Base Verb (V1)
            </span>
        </div>
    `;

    return card;
}
