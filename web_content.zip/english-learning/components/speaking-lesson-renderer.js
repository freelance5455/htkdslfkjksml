/**
 * Component: Speaking Lesson Renderer
 * Renders the complete structured view for an individual Speaking English lesson.
 * Supports all 10 core learning sections:
 * - Introduction
 * - Objective
 * - Vocabulary
 * - Useful Patterns
 * - Speaking Examples
 * - Conversation / Dialogue
 * - Speaking Practice
 * - Why Explanation
 * - Common Mistakes
 * - Summary
 */

import { isLessonCompleted, toggleLessonCompleted } from '../services/speaking-progress.js';

export function renderSpeakingLesson(lesson, category) {
    const container = document.createElement('div');
    container.className = 'speaking-lesson-container';

    const categoryId = category.id;
    const initialCompleted = isLessonCompleted(categoryId, lesson.id);

    container.innerHTML = `
        <!-- Lesson Header Banner -->
        <header class="lesson-view-header">
            <div class="lesson-header-top">
                <a href="speaking-topic.html?id=${encodeURIComponent(categoryId)}" class="btn-back-to-category">
                    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="19" y1="12" x2="5" y2="12"></line>
                        <polyline points="12 19 5 12 12 5"></polyline>
                    </svg>
                    <span>Back to ${escapeHtml(category.title)} Lessons</span>
                </a>
                <button type="button" class="btn-toggle-completion ${initialCompleted ? 'is-completed' : ''}" id="btn-complete-lesson">
                    <svg class="check-icon" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span class="completion-btn-text">${initialCompleted ? 'Completed' : 'Mark as Completed'}</span>
                </button>
            </div>
            
            <div class="lesson-title-meta">
                <div class="lesson-tags">
                    <span class="lesson-order-tag">Lesson ${lesson.order || 1}</span>
                    <span class="diff-badge diff-${lesson.difficulty || 'easy'}">${(lesson.difficulty || 'easy').toUpperCase()}</span>
                </div>
                <h2 class="lesson-main-title">${escapeHtml(lesson.title)}</h2>
                <p class="lesson-main-desc">${escapeHtml(lesson.description)}</p>
            </div>
        </header>

        <div class="lesson-sections-grid">
            <!-- 1. Introduction Section -->
            ${renderIntroductionSection(lesson.introduction)}

            <!-- 2. Learning Objective Section -->
            ${renderObjectiveSection(lesson.objective)}

            <!-- 3. Vocabulary Section -->
            ${renderVocabularySection(lesson.vocabulary)}

            <!-- 4. Useful Patterns Section -->
            ${renderPatternsSection(lesson.patterns)}

            <!-- 5. Speaking Examples Section -->
            ${renderExamplesSection(lesson.examples)}

            <!-- 6. Conversation / Dialogue Section -->
            ${renderConversationSection(lesson.conversation)}

            <!-- 7. Speaking Practice Section -->
            ${renderPracticeSection(lesson.speakingPractice)}

            <!-- 8. Why Explanation Section -->
            ${renderWhySection(lesson.whyExplanation)}

            <!-- 9. Common Mistakes Section -->
            ${renderMistakesSection(lesson.commonMistakes)}

            <!-- 10. Summary Section -->
            ${renderSummarySection(lesson.summary)}
        </div>
    `;

    // Bind event for completion toggle
    setTimeout(() => {
        const completeBtn = container.querySelector('#btn-complete-lesson');
        if (completeBtn) {
            completeBtn.addEventListener('click', () => {
                const nowCompleted = toggleLessonCompleted(categoryId, lesson.id);
                if (nowCompleted) {
                    completeBtn.classList.add('is-completed');
                    completeBtn.querySelector('.completion-btn-text').textContent = 'Completed';
                } else {
                    completeBtn.classList.remove('is-completed');
                    completeBtn.querySelector('.completion-btn-text').textContent = 'Mark as Completed';
                }
            });
        }
    }, 0);

    return container;
}

/* -------------------------------------------------------------------------- */
/* Section Helper Renderers                                                   */
/* -------------------------------------------------------------------------- */

function renderIntroductionSection(intro) {
    if (!intro) return '';
    return `
        <section class="lesson-section-card section-introduction">
            <div class="section-card-header">
                <span class="section-icon">📌</span>
                <h3 class="section-card-title">1. Introduction</h3>
            </div>
            <div class="section-card-content">
                <p class="intro-en">${escapeHtml(intro.english)}</p>
                ${intro.hindi ? `<p class="intro-hi">${escapeHtml(intro.hindi)}</p>` : ''}
                
                <div class="intro-details-grid">
                    ${intro.whatYouWillLearn ? `
                        <div class="detail-box">
                            <span class="detail-box-label">Target Skills:</span>
                            <p>${escapeHtml(intro.whatYouWillLearn)}</p>
                        </div>
                    ` : ''}
                    ${intro.whyUseful ? `
                        <div class="detail-box">
                            <span class="detail-box-label">Why Useful:</span>
                            <p>${escapeHtml(intro.whyUseful)}</p>
                        </div>
                    ` : ''}
                    ${intro.whereUsed ? `
                        <div class="detail-box">
                            <span class="detail-box-label">Where Used:</span>
                            <p>${escapeHtml(intro.whereUsed)}</p>
                        </div>
                    ` : ''}
                </div>
            </div>
        </section>
    `;
}

function renderObjectiveSection(obj) {
    if (!obj) return '';
    return `
        <section class="lesson-section-card section-objective">
            <div class="section-card-header">
                <span class="section-icon">🎯</span>
                <h3 class="section-card-title">2. Learning Objective</h3>
            </div>
            <div class="section-card-content">
                <div class="objective-box">
                    <p class="obj-en"><strong>Goal:</strong> ${escapeHtml(obj.english)}</p>
                    ${obj.hindi ? `<p class="obj-hi"><strong>लक्ष्य:</strong> ${escapeHtml(obj.hindi)}</p>` : ''}
                </div>
            </div>
        </section>
    `;
}

function renderVocabularySection(vocabList) {
    if (!vocabList || vocabList.length === 0) {
        return renderEmptySectionPlaceholder("3. Vocabulary", "📚", "Vocabulary words will be added for this lesson.");
    }
    const items = vocabList.map(item => `
        <div class="vocab-card">
            <div class="vocab-top">
                <span class="vocab-word">${escapeHtml(item.word)}</span>
                ${item.pronunciation ? `<span class="vocab-phonetic">/${escapeHtml(item.pronunciation)}/</span>` : ''}
            </div>
            <p class="vocab-meaning">${escapeHtml(item.meaning)}</p>
            <div class="vocab-example-box">
                <p class="ex-en">💬 "${escapeHtml(item.example)}"</p>
                ${item.hindiExample ? `<p class="ex-hi">💬 "${escapeHtml(item.hindiExample)}"</p>` : ''}
            </div>
        </div>
    `).join('');

    return `
        <section class="lesson-section-card section-vocabulary">
            <div class="section-card-header">
                <span class="section-icon">📚</span>
                <h3 class="section-card-title">3. Key Vocabulary</h3>
            </div>
            <div class="section-card-content">
                <div class="vocab-grid">${items}</div>
            </div>
        </section>
    `;
}

function renderPatternsSection(patternsList) {
    if (!patternsList || patternsList.length === 0) {
        return renderEmptySectionPlaceholder("4. Useful Patterns", "🗣️", "Speaking patterns will be added for this lesson.");
    }
    const items = patternsList.map(item => `
        <div class="pattern-card">
            <div class="pattern-formula">
                <span class="formula-label">Pattern:</span>
                <code>${escapeHtml(item.pattern)}</code>
            </div>
            <div class="pattern-details">
                <p class="pattern-meaning"><strong>Meaning:</strong> ${escapeHtml(item.meaning)}</p>
                <p class="pattern-usage"><strong>Usage:</strong> ${escapeHtml(item.usage)}</p>
                ${item.hindiExplanation ? `<p class="pattern-hi"><strong>व्याख्या:</strong> ${escapeHtml(item.hindiExplanation)}</p>` : ''}
            </div>
            ${item.examples && item.examples.length > 0 ? `
                <div class="pattern-examples-list">
                    <span class="examples-subhead">Examples:</span>
                    ${item.examples.map(ex => `
                        <div class="pattern-ex-item">
                            <span class="ex-text-en">🔹 ${escapeHtml(ex.english)}</span>
                            ${ex.hindi ? `<span class="ex-text-hi">🔸 ${escapeHtml(ex.hindi)}</span>` : ''}
                        </div>
                    `).join('')}
                </div>
            ` : ''}
        </div>
    `).join('');

    return `
        <section class="lesson-section-card section-patterns">
            <div class="section-card-header">
                <span class="section-icon">🗣️</span>
                <h3 class="section-card-title">4. Useful Speaking Patterns</h3>
            </div>
            <div class="section-card-content">
                <div class="patterns-stack">${items}</div>
            </div>
        </section>
    `;
}

function renderExamplesSection(examplesList) {
    if (!examplesList || examplesList.length === 0) {
        return renderEmptySectionPlaceholder("5. Speaking Examples", "💬", "Speaking examples will be added for this lesson.");
    }
    const items = examplesList.map(ex => `
        <div class="speaking-ex-card">
            <p class="speaking-ex-en">"${escapeHtml(ex.english)}"</p>
            ${ex.hindi ? `<p class="speaking-ex-hi">"${escapeHtml(ex.hindi)}"</p>` : ''}
            ${ex.explanation ? `<p class="speaking-ex-notes">ℹ️ ${escapeHtml(ex.explanation)}</p>` : ''}
        </div>
    `).join('');

    return `
        <section class="lesson-section-card section-examples">
            <div class="section-card-header">
                <span class="section-icon">💬</span>
                <h3 class="section-card-title">5. Speaking Examples</h3>
            </div>
            <div class="section-card-content">
                <div class="examples-grid">${items}</div>
            </div>
        </section>
    `;
}

function renderConversationSection(convList) {
    if (!convList || convList.length === 0) {
        return renderEmptySectionPlaceholder("6. Conversation / Dialogue", "👥", "Conversations will be added for this lesson.");
    }
    const items = convList.map(conv => `
        <div class="conversation-block">
            <div class="conv-header">
                <h4 class="conv-title">${escapeHtml(conv.title)}</h4>
                ${conv.situation ? `<p class="conv-situation">📍 <em>Situation: ${escapeHtml(conv.situation)}</em></p>` : ''}
            </div>
            <div class="dialogue-bubbles-list">
                ${conv.dialogue ? conv.dialogue.map(turn => `
                    <div class="dialogue-turn">
                        <div class="speaker-avatar">${escapeHtml(turn.speaker.charAt(0))}</div>
                        <div class="dialogue-content">
                            <span class="speaker-name">${escapeHtml(turn.speaker)}</span>
                            <p class="dialogue-en">${escapeHtml(turn.english)}</p>
                            ${turn.hindi ? `<p class="dialogue-hi">${escapeHtml(turn.hindi)}</p>` : ''}
                        </div>
                    </div>
                `).join('') : ''}
            </div>
            ${conv.explanation ? `<p class="conv-explanation">💡 ${escapeHtml(conv.explanation)}</p>` : ''}
        </div>
    `).join('');

    return `
        <section class="lesson-section-card section-conversation">
            <div class="section-card-header">
                <span class="section-icon">👥</span>
                <h3 class="section-card-title">6. Conversation & Dialogue</h3>
            </div>
            <div class="section-card-content">
                <div class="conversations-stack">${items}</div>
            </div>
        </section>
    `;
}

function renderPracticeSection(practiceList) {
    if (!practiceList || practiceList.length === 0) {
        return renderEmptySectionPlaceholder("7. Speaking Practice", "🎤", "Speaking practice prompts will be added for this lesson.");
    }
    const items = practiceList.map(p => `
        <div class="practice-card">
            <div class="practice-instruction">
                <span class="practice-tag">Instruction</span>
                <p class="practice-inst-en">${escapeHtml(p.instruction)}</p>
                ${p.hindiInstruction ? `<p class="practice-inst-hi">${escapeHtml(p.hindiInstruction)}</p>` : ''}
            </div>
            <div class="practice-prompt-box">
                <span class="prompt-label">Speaking Prompt:</span>
                <p class="prompt-text">"${escapeHtml(p.prompt)}"</p>
            </div>
            ${p.expectedPattern ? `
                <div class="expected-pattern-box">
                    <span class="pattern-hint-label">Expected Pattern / Response Hint:</span>
                    <code>${escapeHtml(p.expectedPattern)}</code>
                </div>
            ` : ''}
        </div>
    `).join('');

    return `
        <section class="lesson-section-card section-practice">
            <div class="section-card-header">
                <span class="section-icon">🎤</span>
                <h3 class="section-card-title">7. Speaking Practice</h3>
            </div>
            <div class="section-card-content">
                <div class="practice-stack">${items}</div>
            </div>
        </section>
    `;
}

function renderWhySection(whyList) {
    if (!whyList || whyList.length === 0) {
        return renderEmptySectionPlaceholder("8. Why Explanation (WHAT + WHY)", "💡", "Usage rationale explanations will be added for this lesson.");
    }
    const items = whyList.map(w => `
        <div class="why-card">
            <h4 class="why-point-title">❓ ${escapeHtml(w.point)}</h4>
            <div class="why-explanations">
                <p class="why-en">${escapeHtml(w.englishExplanation)}</p>
                ${w.hindiExplanation ? `<p class="why-hi">${escapeHtml(w.hindiExplanation)}</p>` : ''}
            </div>
            ${w.examples && w.examples.length > 0 ? `
                <div class="why-examples-box">
                    <span class="why-ex-head">Examples:</span>
                    <ul>
                        ${w.examples.map(e => `<li>"${escapeHtml(e)}"</li>`).join('')}
                    </ul>
                </div>
            ` : ''}
        </div>
    `).join('');

    return `
        <section class="lesson-section-card section-why">
            <div class="section-card-header">
                <span class="section-icon">💡</span>
                <h3 class="section-card-title">8. Why Explanation (WHAT + WHY)</h3>
            </div>
            <div class="section-card-content">
                <div class="why-stack">${items}</div>
            </div>
        </section>
    `;
}

function renderMistakesSection(mistakesList) {
    if (!mistakesList || mistakesList.length === 0) {
        return renderEmptySectionPlaceholder("9. Common Mistakes", "⚠️", "Common mistakes will be added for this lesson.");
    }
    const items = mistakesList.map(m => `
        <div class="mistake-card">
            <div class="mistake-comparison">
                <div class="mistake-box incorrect-box">
                    <span class="mistake-label label-incorrect">❌ Incorrect</span>
                    <p class="mistake-text">"${escapeHtml(m.incorrect)}"</p>
                </div>
                <div class="mistake-box correct-box">
                    <span class="mistake-label label-correct">✅ Correct</span>
                    <p class="mistake-text">"${escapeHtml(m.correct)}"</p>
                </div>
            </div>
            <div class="mistake-notes">
                <p class="note-en"><strong>Reason:</strong> ${escapeHtml(m.explanation)}</p>
                ${m.hindiExplanation ? `<p class="note-hi"><strong>कारण:</strong> ${escapeHtml(m.hindiExplanation)}</p>` : ''}
            </div>
        </div>
    `).join('');

    return `
        <section class="lesson-section-card section-mistakes">
            <div class="section-card-header">
                <span class="section-icon">⚠️</span>
                <h3 class="section-card-title">9. Common Mistakes to Avoid</h3>
            </div>
            <div class="section-card-content">
                <div class="mistakes-stack">${items}</div>
            </div>
        </section>
    `;
}

function renderSummarySection(summary) {
    if (!summary) return '';
    return `
        <section class="lesson-section-card section-summary">
            <div class="section-card-header">
                <span class="section-icon">📋</span>
                <h3 class="section-card-title">10. Lesson Summary</h3>
            </div>
            <div class="section-card-content">
                <div class="summary-grid">
                    ${summary.keyPoints && summary.keyPoints.length > 0 ? `
                        <div class="summary-box">
                            <span class="summary-subhead">Key Takeaways:</span>
                            <ul>
                                ${summary.keyPoints.map(kp => `<li>✅ ${escapeHtml(kp)}</li>`).join('')}
                            </ul>
                        </div>
                    ` : ''}
                    ${summary.importantPatterns && summary.importantPatterns.length > 0 ? `
                        <div class="summary-box">
                            <span class="summary-subhead">Important Patterns:</span>
                            <ul>
                                ${summary.importantPatterns.map(p => `<li><code>${escapeHtml(p)}</code></li>`).join('')}
                            </ul>
                        </div>
                    ` : ''}
                </div>
                ${summary.hindiSummary ? `
                    <div class="summary-hi-box">
                        <span class="summary-subhead">सारांश (Hindi Summary):</span>
                        <p>${escapeHtml(summary.hindiSummary)}</p>
                    </div>
                ` : ''}
            </div>
        </section>
    `;
}

function renderEmptySectionPlaceholder(title, icon, message) {
    return `
        <section class="lesson-section-card section-empty-placeholder">
            <div class="section-card-header">
                <span class="section-icon">${icon}</span>
                <h3 class="section-card-title">${title}</h3>
            </div>
            <div class="section-card-content">
                <p class="placeholder-msg"><em>${escapeHtml(message)}</em></p>
            </div>
        </section>
    `;
}

function escapeHtml(str) {
    if (!str) return '';
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
