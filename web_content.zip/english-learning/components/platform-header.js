/**
 * Component: Platform Header
 * Reusable header foundation for the English Learning Platform.
 */

export function createPlatformHeader(options = {}) {
    const { 
        title = "English Learning Platform",
        subtitle = "Learn English from Beginner to Advanced",
        onMenuToggle = null,
        showSidebarToggle = true,
        basePath = ""
    } = options;

    const header = document.createElement("header");
    header.className = "platform-header";

    header.innerHTML = `
        <div class="platform-header-inner">
            <div class="platform-header-left">
                ${showSidebarToggle ? `
                    <button type="button" class="sidebar-toggle-btn" id="platform-sidebar-toggle" aria-label="Toggle Navigation Sidebar">
                        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <line x1="3" y1="12" x2="21" y2="12"></line>
                            <line x1="3" y1="6" x2="21" y2="6"></line>
                            <line x1="3" y1="18" x2="21" y2="18"></line>
                        </svg>
                    </button>
                ` : ''}
                <a href="${basePath}index.html" class="platform-brand">
                    <span class="brand-logo">💬</span>
                    <div class="brand-text">
                        <h1 class="platform-title">${escapeHtml(title)}</h1>
                        <span class="platform-subtitle">${escapeHtml(subtitle)}</span>
                    </div>
                </a>
            </div>

            <div class="platform-header-right">
                <span class="header-badge">Hindi Medium</span>
            </div>
        </div>
    `;

    if (showSidebarToggle && onMenuToggle) {
        setTimeout(() => {
            const toggleBtn = header.querySelector('#platform-sidebar-toggle');
            if (toggleBtn) {
                toggleBtn.addEventListener('click', onMenuToggle);
            }
        }, 0);
    }

    return header;
}

function escapeHtml(str) {
    if (!str) return '';
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
