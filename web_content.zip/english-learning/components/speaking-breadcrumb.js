/**
 * Component: Speaking Breadcrumb
 * Renders data-driven, accessible breadcrumb navigation.
 * Levels: Home → Speaking English [ → Category Title [ → Lesson Title ] ]
 */

export function createSpeakingBreadcrumb({
    category = null,     // { id, title }
    lessonTitle = null,
    isSubpage = false
} = {}) {
    const nav = document.createElement("nav");
    nav.className = "speaking-breadcrumb-nav";
    nav.setAttribute("aria-label", "Breadcrumb");

    const homeUrl = isSubpage ? "../index.html" : "index.html";

    let breadcrumbHtml = `
        <ol class="breadcrumb-list">
            <li class="breadcrumb-item">
                <a href="${homeUrl}">Home</a>
            </li>
            <li class="breadcrumb-item ${!category ? 'active' : ''}">
                ${category ? `<a href="${homeUrl}">Speaking English</a>` : 'Speaking English'}
            </li>
    `;

    if (category) {
        if (lessonTitle) {
            const categoryUrl = `speaking-topic.html?id=${encodeURIComponent(category.id)}`;
            breadcrumbHtml += `
                <li class="breadcrumb-item">
                    <a href="${categoryUrl}">${escapeHtml(category.title)}</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                    ${escapeHtml(lessonTitle)}
                </li>
            `;
        } else {
            breadcrumbHtml += `
                <li class="breadcrumb-item active" aria-current="page">
                    ${escapeHtml(category.title)}
                </li>
            `;
        }
    }

    breadcrumbHtml += `</ol>`;
    nav.innerHTML = breadcrumbHtml;

    return nav;
}

function escapeHtml(str) {
    if (!str) return '';
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
