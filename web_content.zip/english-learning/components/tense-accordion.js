/**
 * Component: Tense Accordion Manager
 * Reusable ES6 Accordion controller for Tense Detail pages.
 * Converts section cards into accessible, keyboard-friendly accordion items.
 * Supports default open section, single-section toggle mode, Expand All, and Collapse All.
 */

export function createAccordionControlsUI() {
    const controls = document.createElement('div');
    controls.className = 'accordion-global-controls';
    controls.innerHTML = `
        <div class="accordion-controls-info">
            <span class="accordion-section-count font-bold">📚 12 Lesson Sections</span>
            <span class="accordion-mode-tip">💡 Click section headers to expand / collapse</span>
        </div>
        <div class="accordion-controls-buttons">
            <button type="button" class="btn-accordion-control btn-expand-all" id="btn-expand-all-sections">
                <span class="btn-icon">📂</span>
                <span>Expand All</span>
            </button>
            <button type="button" class="btn-accordion-control btn-collapse-all" id="btn-collapse-all-sections">
                <span class="btn-icon">📁</span>
                <span>Collapse All</span>
            </button>
        </div>
    `;
    return controls;
}

/**
 * Initialize accordion behavior on a list of section cards inside layout
 * @param {HTMLElement} layoutContainer 
 * @param {Array<{element: HTMLElement, key: string}>} sectionItems 
 * @param {object} options 
 */
export function initTenseAccordion(layoutContainer, sectionItems, options = {}) {
    if (!layoutContainer || !Array.isArray(sectionItems)) return;

    const {
        defaultOpenIndex = 0,
        onSectionOpen = null
    } = options;

    const accordionContainer = document.createElement('div');
    accordionContainer.className = 'tense-accordion-container';

    // Render Global Accordion Controls (Expand All / Collapse All)
    const controlsEl = createAccordionControlsUI();
    layoutContainer.appendChild(controlsEl);

    // Bind Expand All & Collapse All
    const expandBtn = controlsEl.querySelector('#btn-expand-all-sections');
    const collapseBtn = controlsEl.querySelector('#btn-collapse-all-sections');

    if (expandBtn) {
        expandBtn.addEventListener('click', () => {
            expandAllAccordionItems(accordionContainer, onSectionOpen);
        });
    }

    if (collapseBtn) {
        collapseBtn.addEventListener('click', () => {
            collapseAllAccordionItems(accordionContainer);
        });
    }

    // Process each section item
    sectionItems.forEach((itemObj, index) => {
        const { element: sectionEl, key: sectionKey } = itemObj;
        if (!sectionEl) return;

        const isDefaultOpen = (index === defaultOpenIndex);
        makeSectionAccordionItem(sectionEl, sectionKey, index, isDefaultOpen, accordionContainer, onSectionOpen);
        accordionContainer.appendChild(sectionEl);
    });

    layoutContainer.appendChild(accordionContainer);

    // Trigger initial progress record for default open section
    if (defaultOpenIndex >= 0 && sectionItems[defaultOpenIndex] && onSectionOpen) {
        onSectionOpen(sectionItems[defaultOpenIndex].key);
    }
}

function makeSectionAccordionItem(sectionEl, sectionKey, index, defaultOpen, accordionContainer, onSectionOpen) {
    const panelId = `accordion-panel-${sectionKey || index}`;
    const headerId = `accordion-header-${sectionKey || index}`;

    sectionEl.classList.add('tense-accordion-item');
    sectionEl.dataset.sectionKey = sectionKey || `sec-${index}`;

    if (defaultOpen) {
        sectionEl.classList.add('is-open');
    } else {
        sectionEl.classList.add('is-collapsed');
    }

    const header = sectionEl.querySelector('.section-card-header');
    const body = sectionEl.querySelector('.section-card-body');

    if (body) {
        body.id = panelId;
        body.setAttribute('role', 'region');
        body.setAttribute('aria-labelledby', headerId);
        body.classList.add('accordion-content-panel');
        if (!defaultOpen) {
            body.style.display = 'none';
        } else {
            body.style.display = 'block';
        }
    }

    if (header) {
        const titleMarkup = header.innerHTML;
        header.innerHTML = `
            <button type="button" class="accordion-toggle-btn" id="${headerId}" aria-expanded="${defaultOpen}" aria-controls="${panelId}">
                <div class="accordion-header-left">
                    ${titleMarkup}
                </div>
                <span class="accordion-chevron-icon" aria-hidden="true">${defaultOpen ? '▼' : '▶'}</span>
            </button>
        `;

        const toggleBtn = header.querySelector('.accordion-toggle-btn');
        if (toggleBtn) {
            toggleBtn.addEventListener('click', (e) => {
                e.preventDefault();
                const isOpen = sectionEl.classList.contains('is-open');

                if (isOpen) {
                    closeAccordionItem(sectionEl);
                } else {
                    // Single Section Open Mode: close all other items in accordionContainer
                    const allItems = accordionContainer.querySelectorAll('.tense-accordion-item');
                    allItems.forEach(item => {
                        if (item !== sectionEl) {
                            closeAccordionItem(item);
                        }
                    });

                    openAccordionItem(sectionEl);
                    if (onSectionOpen && sectionKey) {
                        onSectionOpen(sectionKey);
                    }
                }
            });
        }
    }
}

export function openAccordionItem(itemEl) {
    if (!itemEl) return;
    itemEl.classList.remove('is-collapsed');
    itemEl.classList.add('is-open');

    const toggleBtn = itemEl.querySelector('.accordion-toggle-btn');
    const panel = itemEl.querySelector('.accordion-content-panel');
    const chevron = itemEl.querySelector('.accordion-chevron-icon');

    if (toggleBtn) toggleBtn.setAttribute('aria-expanded', 'true');
    if (panel) panel.style.display = 'block';
    if (chevron) chevron.textContent = '▼';
}

export function closeAccordionItem(itemEl) {
    if (!itemEl) return;
    itemEl.classList.remove('is-open');
    itemEl.classList.add('is-collapsed');

    const toggleBtn = itemEl.querySelector('.accordion-toggle-btn');
    const panel = itemEl.querySelector('.accordion-content-panel');
    const chevron = itemEl.querySelector('.accordion-chevron-icon');

    if (toggleBtn) toggleBtn.setAttribute('aria-expanded', 'false');
    if (panel) panel.style.display = 'none';
    if (chevron) chevron.textContent = '▶';
}

export function expandAllAccordionItems(accordionContainer, onSectionOpen = null) {
    if (!accordionContainer) return;
    const items = accordionContainer.querySelectorAll('.tense-accordion-item');
    items.forEach(item => {
        openAccordionItem(item);
        const sectionKey = item.dataset.sectionKey;
        if (sectionKey && onSectionOpen) {
            onSectionOpen(sectionKey);
        }
    });
}

export function collapseAllAccordionItems(accordionContainer) {
    if (!accordionContainer) return;
    const items = accordionContainer.querySelectorAll('.tense-accordion-item');
    items.forEach(item => {
        closeAccordionItem(item);
    });
}
