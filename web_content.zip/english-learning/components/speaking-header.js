/**
 * Component: Speaking Header
 * Renders the standardized header for the Speaking English module.
 */

export function createSpeakingHeader({
    title = "Speaking English",
    subtitle = "Improve your English speaking skills step by step.",
    showBack = false,
    backUrl = "index.html"
} = {}) {
    const header = document.createElement("header");
    header.className = "speaking-header";
    
    header.innerHTML = `
        <div class="speaking-header-inner">
            ${showBack ? `
                <a href="${backUrl}" class="back-link" title="Back to Dashboard">
                    <svg class="icon-arrow-left" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="19" y1="12" x2="5" y2="12"></line>
                        <polyline points="12 19 5 12 12 5"></polyline>
                    </svg>
                    <span>Back to Dashboard</span>
                </a>
            ` : ''}
            <div class="speaking-header-text">
                <h1 class="speaking-title">${escapeHtml(title)}</h1>
                <p class="speaking-subtitle">${escapeHtml(subtitle)}</p>
            </div>
        </div>
    `;

    return header;
}

function escapeHtml(str) {
    if (!str) return '';
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
