/**
 * Component: Platform Sidebar
 * Dynamic reusable navigation sidebar powered by data/menu.js as single source of truth.
 * Supports nested sections, expand/collapse toggles, active state tracking, and route resolution.
 */

import { platformMenu } from '../data/menu.js';

export function createPlatformSidebar(options = {}) {
    const {
        activeId = "dashboard",
        basePath = "",           // e.g. "" for root or "../" for subpages
        collapsed = false,
        onSelect = null
    } = options;

    const nav = document.createElement("nav");
    nav.className = `platform-sidebar ${collapsed ? 'is-collapsed' : ''}`;
    nav.setAttribute("aria-label", "Platform Main Navigation");

    const innerContainer = document.createElement("div");
    innerContainer.className = "platform-sidebar-inner";

    // Build sidebar menu tree recursively from data/menu.js
    const menuList = renderMenuTree(platformMenu, { activeId, basePath, depth: 0 });
    innerContainer.appendChild(menuList);

    nav.appendChild(innerContainer);

    // Bind Expand/Collapse Click Events for Sections
    setTimeout(() => {
        bindSectionToggles(nav);
        if (onSelect) {
            bindLinkSelectEvents(nav, onSelect);
        }
    }, 0);

    return nav;
}

/**
 * Recursively render menu items from menu data structure
 */
function renderMenuTree(items, { activeId, basePath, depth }) {
    const ul = document.createElement("ul");
    ul.className = `menu-list depth-${depth}`;

    items.forEach(item => {
        const li = document.createElement("li");
        const hasChildren = Boolean(item.children && item.children.length > 0);
        const isParentOfActive = hasChildren && isItemAncestorOfActive(item, activeId);
        const isActive = item.id === activeId;

        li.className = `menu-item ${item.type} ${hasChildren ? 'has-children' : ''} ${isActive ? 'active' : ''} ${isParentOfActive ? 'expanded' : ''}`;
        li.dataset.itemId = item.id;

        if (hasChildren) {
            li.innerHTML = `
                <div class="menu-section-header" role="button" aria-expanded="${isParentOfActive ? 'true' : 'false'}" tabindex="0">
                    <span class="menu-item-icon">${getIconSymbol(item.icon)}</span>
                    <span class="menu-item-title">${escapeHtml(item.title)}</span>
                    <svg class="chevron-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="6 9 12 15 18 9"></polyline>
                    </svg>
                </div>
            `;
            const childrenUl = renderMenuTree(item.children, { activeId, basePath, depth: depth + 1 });
            li.appendChild(childrenUl);
        } else {
            const url = resolveItemUrl(item, basePath);
            li.innerHTML = `
                <a href="${url}" class="menu-link ${isActive ? 'active' : ''}">
                    ${item.icon ? `<span class="menu-item-icon">${getIconSymbol(item.icon)}</span>` : '<span class="menu-bullet">•</span>'}
                    <span class="menu-item-title">${escapeHtml(item.title)}</span>
                </a>
            `;
        }

        ul.appendChild(li);
    });

    return ul;
}

/**
 * Resolve URL target for a menu item based on category mapping
 */
function resolveItemUrl(item, basePath) {
    if (item.id === "dashboard") {
        return `${basePath}index.html`;
    }
    
    // Tenses group pages
    const tensesGroupIds = ["tenses", "present-tenses", "past-tenses", "future-tenses"];
    if (tensesGroupIds.includes(item.id)) {
        return `${basePath}pages/tenses.html`;
    }

    // Individual 12 Tense detail pages
    const individualTenseIds = [
        "simple-present", "present-continuous", "present-perfect", "present-perfect-continuous",
        "simple-past", "past-continuous", "past-perfect", "past-perfect-continuous",
        "simple-future", "future-continuous", "future-perfect", "future-perfect-continuous"
    ];
    if (individualTenseIds.includes(item.id)) {
        return `${basePath}pages/tense.html?id=${encodeURIComponent(item.id)}`;
    }

    // Speaking English category IDs mapping to pages/speaking-topic.html?id=...
    const speakingCategories = [
        "daily-conversation-basics", "office-workplace-english", "asking-questions-fluently",
        "giving-answers-elaborating", "making-requests-politely", "giving-advice-suggestions",
        "asking-giving-permission", "agreement-disagreement", "telephone-online-call",
        "meetings-presentations", "professional-email-writing", "job-interview-preparation",
        "travel-airport-english", "shopping-restaurant-english", "social-event-conversations",
        "english-fluency-confidence-mastery"
    ];

    if (speakingCategories.includes(item.id)) {
        return `${basePath}pages/speaking-topic.html?id=${encodeURIComponent(item.id)}`;
    }

    // Modal Verbs group listing page
    if (item.id === "modal-verbs") {
        return `${basePath}pages/modals.html`;
    }

    // Individual Modal detail pages (e.g. modal-can, modal-could, etc.)
    if (item.id.startsWith("modal-")) {
        return `${basePath}pages/modal.html?id=${encodeURIComponent(item.id)}`;
    }

    // Default route placeholder for future platform modules
    return `${basePath}#${item.id}`;
}

/**
 * Helper to check if an item is an ancestor of activeId
 */
function isItemAncestorOfActive(item, activeId) {
    if (!item.children) return false;
    for (const child of item.children) {
        if (child.id === activeId) return true;
        if (child.children && isItemAncestorOfActive(child, activeId)) return true;
    }
    return false;
}

/**
 * Bind section header click handlers to expand/collapse
 */
function bindSectionToggles(container) {
    const sectionHeaders = container.querySelectorAll('.menu-section-header');
    sectionHeaders.forEach(header => {
        header.addEventListener('click', (e) => {
            e.stopPropagation();
            const parentLi = header.closest('.menu-item.has-children');
            if (parentLi) {
                const isExpanded = parentLi.classList.contains('expanded');
                if (isExpanded) {
                    parentLi.classList.remove('expanded');
                    header.setAttribute('aria-expanded', 'false');
                } else {
                    parentLi.classList.add('expanded');
                    header.setAttribute('aria-expanded', 'true');
                }
            }
        });
    });
}

function bindLinkSelectEvents(container, onSelect) {
    const links = container.querySelectorAll('.menu-link');
    links.forEach(link => {
        link.addEventListener('click', (e) => {
            const li = link.closest('.menu-item');
            const id = li ? li.dataset.itemId : null;
            onSelect(id, e);
        });
    });
}

function getIconSymbol(iconName) {
    const icons = {
        'dashboard': '🏠',
        'clock': '⏰',
        'sparkles': '✨',
        'book-open': '📖',
        'academic-cap': '🎓',
        'chat-alt': '💬',
        'pencil-alt': '📝',
        'search': '🔍',
        'bookmark': '🔖',
        'document-text': '📑',
        'chart-bar': '📊',
        'light-bulb': '💡'
    };
    return icons[iconName] || '🔹';
}

function escapeHtml(str) {
    if (!str) return '';
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
