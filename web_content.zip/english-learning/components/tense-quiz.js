/**
 * Component: Simple Present Quiz UI Templates
 * Pure UI generator for Quiz setup, question cards, option buttons, feedback, and score summaries.
 */

export function createQuizCardHeader(tenseTitle = 'Simple Present') {
    return `
        <div class="section-card-header quiz-card-header">
            <div class="quiz-header-title-group">
                <span class="section-card-icon">🧠</span>
                <div class="section-card-title-group">
                    <h3 class="section-card-title-en">12. ${escapeHtml(tenseTitle)} Quiz</h3>
                    <span class="section-card-title-hi">ज्ञान परीक्षा (Interactive Practice Quiz)</span>
                </div>
            </div>
            <span class="quiz-badge">10 Questions</span>
        </div>
    `;
}

export function renderQuizSetupUI(currentCategory = 'positive', currentDifficulty = 'easy') {
    return `
        <div class="quiz-setup-container">
            <div class="quiz-setup-info">
                <h4 class="quiz-setup-title">Test Your Simple Present Mastery!</h4>
                <p class="quiz-setup-desc">अपनी श्रेणी और कठिनाई स्तर चुनें और 10 प्रश्नों की अभ्यास परीक्षा शुरू करें।</p>
            </div>

            <div class="quiz-config-controls">
                <!-- Category Selector -->
                <div class="config-group">
                    <label class="config-label">Category (श्रेणी चुनें):</label>
                    <div class="quiz-cat-tabs" id="quiz-cat-tabs">
                        <button type="button" class="quiz-cat-btn ${currentCategory === 'positive' ? 'active' : ''}" data-cat="positive">
                            <span>✅ Positive</span>
                        </button>
                        <button type="button" class="quiz-cat-btn ${currentCategory === 'negative' ? 'active' : ''}" data-cat="negative">
                            <span>❌ Negative</span>
                        </button>
                        <button type="button" class="quiz-cat-btn ${currentCategory === 'interrogative' ? 'active' : ''}" data-cat="interrogative">
                            <span>❓ Interrogative</span>
                        </button>
                        <button type="button" class="quiz-cat-btn ${currentCategory === 'whQuestions' ? 'active' : ''}" data-cat="whQuestions">
                            <span>🌐 WH Questions</span>
                        </button>
                    </div>
                </div>

                <!-- Difficulty Selector -->
                <div class="config-group">
                    <label class="config-label">Difficulty (कठिनाई स्तर):</label>
                    <div class="quiz-diff-tabs" id="quiz-diff-tabs">
                        <button type="button" class="quiz-diff-btn diff-tab-easy ${currentDifficulty === 'easy' ? 'active' : ''}" data-diff="easy">
                            <span>EASY (10)</span>
                        </button>
                        <button type="button" class="quiz-diff-btn diff-tab-medium ${currentDifficulty === 'medium' ? 'active' : ''}" data-diff="medium">
                            <span>MEDIUM (10)</span>
                        </button>
                        <button type="button" class="quiz-diff-btn diff-tab-hard ${currentDifficulty === 'hard' ? 'active' : ''}" data-diff="hard">
                            <span>HARD (10)</span>
                        </button>
                    </div>
                </div>
            </div>

            <button type="button" class="btn btn-primary btn-start-quiz" id="btn-start-quiz">
                <span>🚀 Start Quiz Now (क्विज़ शुरू करें)</span>
            </button>
        </div>
    `;
}

export function renderQuizQuestionUI(qData, currentScore) {
    const { index, promptHindi, options, categoryTitle, difficulty } = qData;
    const progressPercent = Math.round((index / 10) * 100);
    const optionLabels = ['A', 'B', 'C', 'D'];

    return `
        <div class="quiz-active-container">
            <!-- Quiz Progress & Status Bar -->
            <div class="quiz-status-bar">
                <div class="status-left">
                    <span class="question-step-badge">Question ${index} of 10</span>
                    <span class="diff-badge diff-${difficulty}">${difficulty.toUpperCase()}</span>
                    <span class="cat-pill">${escapeHtml(categoryTitle)}</span>
                </div>
                <div class="status-right">
                    <span class="score-badge">Current Score: <strong>${currentScore}</strong> / 10</span>
                </div>
            </div>

            <div class="quiz-progress-track">
                <div class="quiz-progress-fill" style="width: ${progressPercent}%;"></div>
            </div>

            <!-- Question Card Box -->
            <div class="quiz-question-box">
                <span class="question-instruction-hi">नीचे दिए गए हिंदी वाक्य का सही अंग्रेजी अनुवाद चुनें:</span>
                <h4 class="quiz-question-prompt">"${escapeHtml(promptHindi)}"</h4>
            </div>

            <!-- 4 Multiple Choice Options -->
            <div class="quiz-options-grid" id="quiz-options-grid">
                ${options.map((opt, idx) => `
                    <button type="button" class="quiz-option-btn" data-opt-idx="${idx}">
                        <span class="opt-key">${optionLabels[idx]}</span>
                        <span class="opt-text">${escapeHtml(opt.text)}</span>
                    </button>
                `).join('')}
            </div>

            <!-- Answer Feedback & Explanation Box (Shown after click) -->
            <div class="quiz-feedback-box is-hidden" id="quiz-feedback-box">
                <div class="feedback-status-header" id="feedback-status-header"></div>
                <div class="feedback-explanation-body">
                    <p class="feedback-hi" id="feedback-hi"></p>
                    <p class="feedback-struct" id="feedback-struct"></p>
                </div>
                <button type="button" class="btn btn-primary btn-next-question" id="btn-next-question">
                    <span>${index === 10 ? 'View Final Score 🏆' : 'Next Question ➔'}</span>
                </button>
            </div>
        </div>
    `;
}

export function renderQuizResultsUI(results) {
    const { score, totalQuestions, percentage, correctCount, incorrectCount, categoryTitle, difficulty } = results;

    let performanceBadge = '🌟 Outstanding!';
    let performanceClass = 'perf-excellent';
    let performanceMessage = 'आपकी Simple Present Tense पर बेहतरीन पकड़ है!';

    if (percentage < 50) {
        performanceBadge = '💪 Keep Practicing!';
        performanceClass = 'perf-needs-work';
        performanceMessage = 'नियमों और अभ्यास वाक्यों को एक बार फिर से पढ़ें और पुनः प्रयास करें!';
    } else if (percentage < 80) {
        performanceBadge = '👏 Great Job!';
        performanceClass = 'perf-good';
        performanceMessage = 'अच्छा प्रयास! थोड़ी और प्रैक्टिस से आप 100% स्कोर प्राप्त कर सकते हैं।';
    }

    return `
        <div class="quiz-results-container">
            <div class="results-header-card ${performanceClass}">
                <div class="results-icon">🏆</div>
                <h3 class="results-title">Quiz Completed! (क्विज़ समाप्त)</h3>
                <span class="results-perf-badge">${performanceBadge}</span>
                <p class="results-message-hi">${performanceMessage}</p>
            </div>

            <div class="results-score-summary">
                <div class="score-circle">
                    <span class="score-percent-text">${percentage}%</span>
                    <span class="score-fraction">${score} / ${totalQuestions} Correct</span>
                </div>

                <div class="score-breakdown-grid">
                    <div class="breakdown-card card-correct">
                        <span class="bd-icon">✅</span>
                        <span class="bd-count">${correctCount}</span>
                        <span class="bd-label">Correct Answers</span>
                    </div>
                    <div class="breakdown-card card-incorrect">
                        <span class="bd-icon">❌</span>
                        <span class="bd-count">${incorrectCount}</span>
                        <span class="bd-label">Incorrect Answers</span>
                    </div>
                </div>
            </div>

            <div class="results-actions-row">
                <button type="button" class="btn btn-primary btn-retry-quiz" id="btn-retry-quiz">
                    <span>🔄 Retry Quiz (${categoryTitle} - ${difficulty.toUpperCase()})</span>
                </button>
                <button type="button" class="btn btn-secondary btn-change-config" id="btn-change-config">
                    <span>⚙️ Change Category / Difficulty</span>
                </button>
            </div>
        </div>
    `;
}

function escapeHtml(str) {
    if (!str) return '';
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
