/**
 * Component: Speaking Category Card
 * Renders a card for a Speaking English category.
 */

export function createSpeakingCard(category, options = {}) {
    const { isOpened = false, basePath = "pages/" } = options;
    const card = document.createElement("article");
    card.className = "speaking-card";
    card.dataset.categoryId = category.id;

    const difficulties = ['easy', 'medium', 'hard'];
    const difficultyBadges = difficulties.map(diff => {
        const isAvailable = category.difficulty && category.difficulty[diff];
        const statusClass = isAvailable ? 'available' : 'disabled';
        const label = diff.charAt(0).toUpperCase() + diff.slice(1);
        return `<span class="diff-badge diff-${diff} ${statusClass}">${label}</span>`;
    }).join('');

    const targetUrl = `${basePath}speaking-topic.html?id=${encodeURIComponent(category.id)}`;

    card.innerHTML = `
        <div class="card-body">
            <div class="card-top">
                <h3 class="card-title">${escapeHtml(category.title)}</h3>
                ${isOpened ? '<span class="status-opened-badge" title="Opened previously">Opened</span>' : ''}
            </div>
            <p class="card-description">${escapeHtml(category.description)}</p>
            <div class="card-difficulty-section">
                <span class="difficulty-label">Levels:</span>
                <div class="difficulty-badges-group">
                    ${difficultyBadges}
                </div>
            </div>
        </div>
        <div class="card-footer">
            <a href="${targetUrl}" class="btn btn-open-topic">
                <span>Open Topic</span>
                <svg class="btn-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                    <polyline points="12 5 19 12 12 19"></polyline>
                </svg>
            </a>
        </div>
    `;

    return card;
}

function escapeHtml(str) {
    if (!str) return '';
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
