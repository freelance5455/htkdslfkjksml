/**
 * Component: Modal Card
 * Reusable ES6 Card Renderer for Modal Verbs Listing Page (pages/modals.html & modal-verbs/index.html).
 * Displays modal name, category badge, Hindi meaning placeholder, difficulty/status placeholder, and link to detail page.
 */

import { escapeHtml } from '../assets/js/modal-utils.js';

/**
 * Create a single Modal Card DOM Element
 * @param {object} modalMeta - Modal item metadata from data/modals.js
 * @param {object} options - Options including basePath ('', '../')
 * @returns {HTMLElement}
 */
export function createModalCard(modalMeta, options = {}) {
    const { basePath = "../" } = options;

    const card = document.createElement("article");
    card.className = "modal-card";
    card.dataset.modalId = modalMeta.id;

    const detailUrl = `${basePath}pages/modal.html?id=${encodeURIComponent(modalMeta.id)}`;

    card.innerHTML = `
        <div class="modal-card-header">
            <div class="modal-card-title-group">
                <h3 class="modal-card-name">${escapeHtml(modalMeta.name || modalMeta.title)}</h3>
                <span class="modal-card-category-badge">${escapeHtml(modalMeta.category || 'Modal Verb')}</span>
            </div>
            <span class="modal-card-status-chip">${escapeHtml(modalMeta.status || 'Foundation Ready')}</span>
        </div>

        <div class="modal-card-body">
            <div class="modal-card-meaning-box">
                <span class="meaning-label font-bold">Meaning:</span>
                <span class="meaning-text">${escapeHtml(modalMeta.hindiMeaning || modalMeta.titleHindi)}</span>
            </div>
            
            <p class="modal-card-desc">${escapeHtml(modalMeta.shortDescription || '')}</p>
            <p class="modal-card-desc-hi">${escapeHtml(modalMeta.shortDescriptionHindi || '')}</p>
        </div>

        <div class="modal-card-footer">
            <a href="${detailUrl}" class="btn-modal-action">
                <span>Learn ${escapeHtml(modalMeta.name)}</span>
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                    <polyline points="12 5 19 12 12 19"></polyline>
                </svg>
            </a>
        </div>
    `;

    return card;
}
