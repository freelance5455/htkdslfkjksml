/**
 * Component: Speaking Lesson Card
 * Renders a card for an individual lesson within a Speaking English category.
 */

export function createSpeakingLessonCard(lesson, options = {}) {
    const { isCompleted = false, categoryId = "" } = options;
    const card = document.createElement("article");
    card.className = `speaking-lesson-card ${isCompleted ? 'completed' : ''}`;
    card.dataset.lessonId = lesson.id;
    card.dataset.difficulty = lesson.difficulty || 'easy';

    const diff = lesson.difficulty || 'easy';
    const diffLabel = diff.charAt(0).toUpperCase() + diff.slice(1);
    const targetUrl = `speaking-topic.html?id=${encodeURIComponent(categoryId)}&lesson=${encodeURIComponent(lesson.id)}`;

    card.innerHTML = `
        <div class="lesson-card-header">
            <div class="lesson-card-meta">
                <span class="lesson-order-badge">Lesson ${lesson.order || 1}</span>
                <span class="diff-badge diff-${diff}">${diffLabel}</span>
            </div>
            ${isCompleted ? `
                <span class="completion-status-badge completed">
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    Completed
                </span>
            ` : ''}
        </div>
        <div class="lesson-card-body">
            <h4 class="lesson-card-title">${escapeHtml(lesson.title)}</h4>
            <p class="lesson-card-description">${escapeHtml(lesson.description)}</p>
        </div>
        <div class="lesson-card-footer">
            <a href="${targetUrl}" class="btn btn-open-lesson">
                <span>Start Lesson</span>
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                    <polyline points="12 5 19 12 12 19"></polyline>
                </svg>
            </a>
        </div>
    `;

    return card;
}

function escapeHtml(str) {
    if (!str) return '';
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
