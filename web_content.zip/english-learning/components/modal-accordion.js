/**
 * Component: Modal Accordion Manager
 * Reusable ES6 Accordion controller for Modal Verb Detail pages.
 * Supports default open section (Section 1), single-section toggle mode, Expand All, and Collapse All.
 */

export function createModalAccordionControlsUI() {
    const controls = document.createElement('div');
    controls.className = 'accordion-global-controls';
    controls.innerHTML = `
        <div class="accordion-controls-info">
            <span class="accordion-section-count font-bold">📚 12 Modal Lesson Sections</span>
            <span class="accordion-mode-tip">💡 Click section headers to expand / collapse</span>
        </div>
        <div class="accordion-controls-buttons">
            <button type="button" class="btn-accordion-control btn-expand-all" id="btn-expand-all-modals">
                <span class="btn-icon">📂</span>
                <span>Expand All</span>
            </button>
            <button type="button" class="btn-accordion-control btn-collapse-all" id="btn-collapse-all-modals">
                <span class="btn-icon">📁</span>
                <span>Collapse All</span>
            </button>
        </div>
    `;
    return controls;
}

/**
 * Initialize accordion behavior on a list of section cards inside layout
 * @param {HTMLElement} layoutContainer 
 * @param {Array<{element: HTMLElement, key: string}>} sectionItems 
 * @param {object} options 
 */
export function initModalAccordion(layoutContainer, sectionItems, options = {}) {
    if (!layoutContainer || !Array.isArray(sectionItems)) return;

    const {
        defaultOpenIndex = 0,
        onSectionOpen = null
    } = options;

    const accordionContainer = document.createElement('div');
    accordionContainer.className = 'modal-accordion-container';

    // Render Global Accordion Controls (Expand All / Collapse All)
    const controlsEl = createModalAccordionControlsUI();
    layoutContainer.appendChild(controlsEl);

    // Bind Expand All & Collapse All
    const expandBtn = controlsEl.querySelector('#btn-expand-all-modals');
    const collapseBtn = controlsEl.querySelector('#btn-collapse-all-modals');

    if (expandBtn) {
        expandBtn.addEventListener('click', () => {
            expandAllModalAccordionItems(accordionContainer, onSectionOpen);
        });
    }

    if (collapseBtn) {
        collapseBtn.addEventListener('click', () => {
            collapseAllModalAccordionItems(accordionContainer);
        });
    }

    // Process each section item
    sectionItems.forEach((itemObj, index) => {
        const { element: sectionEl, key: sectionKey } = itemObj;
        if (!sectionEl) return;

        const isDefaultOpen = (index === defaultOpenIndex);
        makeModalSectionAccordionItem(sectionEl, sectionKey, index, isDefaultOpen, accordionContainer, onSectionOpen);
        accordionContainer.appendChild(sectionEl);
    });

    layoutContainer.appendChild(accordionContainer);

    // Trigger initial progress record for default open section
    if (defaultOpenIndex >= 0 && sectionItems[defaultOpenIndex] && onSectionOpen) {
        onSectionOpen(sectionItems[defaultOpenIndex].key);
    }
}

function makeModalSectionAccordionItem(sectionEl, sectionKey, index, defaultOpen, accordionContainer, onSectionOpen) {
    const panelId = `modal-accordion-panel-${sectionKey || index}`;
    const headerId = `modal-accordion-header-${sectionKey || index}`;

    sectionEl.classList.add('modal-accordion-item');
    sectionEl.dataset.sectionKey = sectionKey || `sec-${index}`;

    if (defaultOpen) {
        sectionEl.classList.add('is-open');
    } else {
        sectionEl.classList.add('is-collapsed');
    }

    const header = sectionEl.querySelector('.section-card-header');
    const body = sectionEl.querySelector('.section-card-body');

    if (header) {
        header.id = headerId;
        header.setAttribute('role', 'button');
        header.setAttribute('tabindex', '0');
        header.setAttribute('aria-expanded', defaultOpen ? 'true' : 'false');
        header.setAttribute('aria-controls', panelId);

        // Add visual accordion chevron indicator if not present
        if (!header.querySelector('.accordion-chevron')) {
            const chevron = document.createElement('span');
            chevron.className = 'accordion-chevron';
            chevron.innerHTML = `
                <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
            `;
            header.appendChild(chevron);
        }

        // Toggle click handler
        const toggleHandler = () => {
            const isOpen = sectionEl.classList.contains('is-open');
            if (isOpen) {
                sectionEl.classList.remove('is-open');
                sectionEl.classList.add('is-collapsed');
                header.setAttribute('aria-expanded', 'false');
            } else {
                sectionEl.classList.remove('is-collapsed');
                sectionEl.classList.add('is-open');
                header.setAttribute('aria-expanded', 'true');
                if (onSectionOpen) {
                    onSectionOpen(sectionKey);
                }
            }
        };

        header.addEventListener('click', toggleHandler);

        header.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                toggleHandler();
            }
        });
    }

    if (body) {
        body.id = panelId;
        body.setAttribute('role', 'region');
        body.setAttribute('aria-labelledby', headerId);
    }
}

export function expandAllModalAccordionItems(accordionContainer, onSectionOpen) {
    if (!accordionContainer) return;
    const items = accordionContainer.querySelectorAll('.modal-accordion-item');
    items.forEach(item => {
        item.classList.remove('is-collapsed');
        item.classList.add('is-open');
        const header = item.querySelector('.section-card-header');
        if (header) {
            header.setAttribute('aria-expanded', 'true');
        }
        const key = item.dataset.sectionKey;
        if (key && onSectionOpen) {
            onSectionOpen(key);
        }
    });
}

export function collapseAllModalAccordionItems(accordionContainer) {
    if (!accordionContainer) return;
    const items = accordionContainer.querySelectorAll('.modal-accordion-item');
    items.forEach(item => {
        item.classList.remove('is-open');
        item.classList.add('is-collapsed');
        const header = item.querySelector('.section-card-header');
        if (header) {
            header.setAttribute('aria-expanded', 'false');
        }
    });
}
