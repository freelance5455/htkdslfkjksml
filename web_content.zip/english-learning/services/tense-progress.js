/**
 * Tense Progress Service Module
 * Manages LocalStorage persistence for tense views, section reads, and practice item completions.
 */

const STORAGE_KEY = 'speaking_english_tense_progress_v1';
const STORAGE_VERSION = 1;

/**
 * Load progress object from LocalStorage
 * @returns {object}
 */
export function loadProgress() {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (!raw) return getInitialStorageStructure();
        const parsed = JSON.parse(raw);
        if (!parsed || parsed.version !== STORAGE_VERSION || !parsed.tenses) {
            return getInitialStorageStructure();
        }
        return parsed;
    } catch (e) {
        console.warn('Failed to load tense progress from localStorage:', e);
        return getInitialStorageStructure();
    }
}

/**
 * Save progress object to LocalStorage
 * @param {object} progressObj 
 */
export function saveProgress(progressObj) {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(progressObj));
    } catch (e) {
        console.warn('Failed to save tense progress to localStorage:', e);
    }
}

function getInitialStorageStructure() {
    return {
        version: STORAGE_VERSION,
        tenses: {}
    };
}

function getInitialTenseStructure() {
    return {
        openedAt: new Date().toISOString(),
        lastVisited: new Date().toISOString(),
        sectionsViewed: {},
        completedItems: {}
    };
}

/**
 * Get progress structure for a specific tense
 * @param {string} tenseId 
 * @returns {object}
 */
export function getTenseProgress(tenseId) {
    if (!tenseId) return getInitialTenseStructure();
    const data = loadProgress();
    if (!data.tenses[tenseId]) {
        data.tenses[tenseId] = getInitialTenseStructure();
        saveProgress(data);
    }
    return data.tenses[tenseId];
}

/**
 * Record that a tense page was opened
 * @param {string} tenseId 
 */
export function recordTenseOpened(tenseId) {
    if (!tenseId) return;
    const data = loadProgress();
    if (!data.tenses[tenseId]) {
        data.tenses[tenseId] = getInitialTenseStructure();
    } else {
        data.tenses[tenseId].lastVisited = new Date().toISOString();
    }
    saveProgress(data);
}

/**
 * Record that a section was viewed
 * @param {string} tenseId 
 * @param {string} sectionKey 
 */
export function recordSectionViewed(tenseId, sectionKey) {
    if (!tenseId || !sectionKey) return;
    const data = loadProgress();
    if (!data.tenses[tenseId]) {
        data.tenses[tenseId] = getInitialTenseStructure();
    }
    data.tenses[tenseId].sectionsViewed[sectionKey] = true;
    saveProgress(data);
}

/**
 * Check if a practice item is marked completed
 * @param {string} tenseId 
 * @param {string} itemId 
 * @returns {boolean}
 */
export function isPracticeItemCompleted(tenseId, itemId) {
    if (!tenseId || !itemId) return false;
    const tenseData = getTenseProgress(tenseId);
    return Boolean(tenseData.completedItems && tenseData.completedItems[itemId]);
}

/**
 * Toggle practice item completion status
 * @param {string} tenseId 
 * @param {string} itemId 
 * @returns {boolean} isCompleted after toggle
 */
export function togglePracticeItemCompleted(tenseId, itemId) {
    if (!tenseId || !itemId) return false;
    const data = loadProgress();
    if (!data.tenses[tenseId]) {
        data.tenses[tenseId] = getInitialTenseStructure();
    }

    const current = Boolean(data.tenses[tenseId].completedItems[itemId]);
    if (current) {
        delete data.tenses[tenseId].completedItems[itemId];
    } else {
        data.tenses[tenseId].completedItems[itemId] = true;
    }
    saveProgress(data);
    return !current;
}

/**
 * Calculate progress statistics for a tense
 * @param {string} tenseId 
 * @param {Array<object>} allPracticeItems - array of practice objects [{ fullId, level, category }]
 * @param {Array<string>} allSectionKeys - array of section keys
 * @returns {object}
 */
export function getTenseProgressStats(tenseId, allPracticeItems = [], allSectionKeys = []) {
    const tenseData = getTenseProgress(tenseId);
    const completedMap = tenseData.completedItems || {};
    const viewedMap = tenseData.sectionsViewed || {};

    const totalSections = allSectionKeys.length || 11;
    let sectionsViewedCount = 0;
    allSectionKeys.forEach(k => {
        if (viewedMap[k]) sectionsViewedCount++;
    });

    const totalItems = allPracticeItems.length || 120;
    let completedItemsCount = 0;

    const difficultyStats = {
        easy: { total: 0, completed: 0, percentage: 0 },
        medium: { total: 0, completed: 0, percentage: 0 },
        hard: { total: 0, completed: 0, percentage: 0 }
    };

    const categoryStats = {
        positive: { total: 0, completed: 0, percentage: 0 },
        negative: { total: 0, completed: 0, percentage: 0 },
        interrogative: { total: 0, completed: 0, percentage: 0 },
        whQuestions: { total: 0, completed: 0, percentage: 0 }
    };

    allPracticeItems.forEach(item => {
        const isComp = Boolean(completedMap[item.fullId]);
        if (isComp) completedItemsCount++;

        // Difficulty stats
        const lvl = item.level || 'easy';
        if (difficultyStats[lvl]) {
            difficultyStats[lvl].total++;
            if (isComp) difficultyStats[lvl].completed++;
        }

        // Category stats
        const cat = item.category || 'positive';
        if (categoryStats[cat]) {
            categoryStats[cat].total++;
            if (isComp) categoryStats[cat].completed++;
        }
    });

    // Calculate percentages
    const overallPercentage = totalItems > 0 ? Math.round((completedItemsCount / totalItems) * 100) : 0;
    const sectionsPercentage = totalSections > 0 ? Math.round((sectionsViewedCount / totalSections) * 100) : 0;

    ['easy', 'medium', 'hard'].forEach(lvl => {
        const st = difficultyStats[lvl];
        st.percentage = st.total > 0 ? Math.round((st.completed / st.total) * 100) : 0;
    });

    ['positive', 'negative', 'interrogative', 'whQuestions'].forEach(cat => {
        const st = categoryStats[cat];
        st.percentage = st.total > 0 ? Math.round((st.completed / st.total) * 100) : 0;
    });

    return {
        tenseId,
        totalSections,
        sectionsViewedCount,
        sectionsPercentage,
        totalItems,
        completedItemsCount,
        overallPercentage,
        difficultyStats,
        categoryStats
    };
}
