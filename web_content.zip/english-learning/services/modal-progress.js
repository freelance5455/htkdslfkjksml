/**
 * Modal Verbs Progress Service Module
 * Manages LocalStorage persistence for modal views, section reads, and practice item completions.
 * Namespace: speaking_english_modal_progress_v1 (100% isolated from Tense progress).
 */

const STORAGE_KEY = 'speaking_english_modal_progress_v1';
const STORAGE_VERSION = 1;

/**
 * Load progress object from LocalStorage
 * @returns {object}
 */
export function loadModalProgress() {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (!raw) return getInitialStorageStructure();
        const parsed = JSON.parse(raw);
        if (!parsed || parsed.version !== STORAGE_VERSION || !parsed.modals) {
            return getInitialStorageStructure();
        }
        return parsed;
    } catch (e) {
        console.warn('Failed to load modal progress from localStorage:', e);
        return getInitialStorageStructure();
    }
}

/**
 * Save progress object to LocalStorage
 * @param {object} progressObj 
 */
export function saveModalProgress(progressObj) {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(progressObj));
    } catch (e) {
        console.warn('Failed to save modal progress to localStorage:', e);
    }
}

function getInitialStorageStructure() {
    return {
        version: STORAGE_VERSION,
        modals: {}
    };
}

function getInitialModalStructure() {
    return {
        openedAt: new Date().toISOString(),
        lastVisited: new Date().toISOString(),
        sectionsViewed: {},
        completedItems: {}
    };
}

/**
 * Get progress structure for a specific modal verb ID
 * @param {string} modalId 
 * @returns {object}
 */
export function getModalProgress(modalId) {
    if (!modalId) return getInitialModalStructure();
    const data = loadModalProgress();
    if (!data.modals[modalId]) {
        data.modals[modalId] = getInitialModalStructure();
        saveModalProgress(data);
    }
    return data.modals[modalId];
}

/**
 * Record that a modal detail page was opened
 * @param {string} modalId 
 */
export function recordModalOpened(modalId) {
    if (!modalId) return;
    const data = loadModalProgress();
    if (!data.modals[modalId]) {
        data.modals[modalId] = getInitialModalStructure();
    } else {
        data.modals[modalId].lastVisited = new Date().toISOString();
    }
    saveModalProgress(data);
}

/**
 * Record that a section was viewed
 * @param {string} modalId 
 * @param {string} sectionKey 
 */
export function recordModalSectionViewed(modalId, sectionKey) {
    if (!modalId || !sectionKey) return;
    const data = loadModalProgress();
    if (!data.modals[modalId]) {
        data.modals[modalId] = getInitialModalStructure();
    }
    data.modals[modalId].sectionsViewed[sectionKey] = true;
    saveModalProgress(data);
}

/**
 * Check if a practice item is marked complete
 * @param {string} modalId 
 * @param {string} itemId 
 * @returns {boolean}
 */
export function isModalPracticeItemCompleted(modalId, itemId) {
    if (!modalId || !itemId) return false;
    const modalProg = getModalProgress(modalId);
    return Boolean(modalProg.completedItems && modalProg.completedItems[itemId]);
}

/**
 * Toggle completed state for a practice item
 * @param {string} modalId 
 * @param {string} itemId 
 * @returns {boolean}
 */
export function toggleModalPracticeItemCompleted(modalId, itemId) {
    if (!modalId || !itemId) return false;
    const data = loadModalProgress();
    if (!data.modals[modalId]) {
        data.modals[modalId] = getInitialModalStructure();
    }
    const current = Boolean(data.modals[modalId].completedItems[itemId]);
    data.modals[modalId].completedItems[itemId] = !current;
    saveModalProgress(data);
    return !current;
}

/**
 * Calculate completion stats for a modal verb
 * @param {string} modalId 
 * @param {Array<object>} practiceItems 
 * @param {Array<string>} totalSectionKeys 
 * @returns {object}
 */
export function getModalProgressStats(modalId, practiceItems = [], totalSectionKeys = []) {
    const modalProg = getModalProgress(modalId);

    const totalSectionsCount = totalSectionKeys.length || 11;
    const viewedSectionsCount = Object.keys(modalProg.sectionsViewed || {}).filter(k => k !== 'quiz').length;

    const totalItemsCount = practiceItems.length;
    const completedItemsCount = practiceItems.filter(item => isModalPracticeItemCompleted(modalId, item.id)).length;

    const practicePercent = totalItemsCount > 0 ? Math.round((completedItemsCount / totalItemsCount) * 100) : 0;
    const readingPercent = totalSectionsCount > 0 ? Math.round((viewedSectionsCount / totalSectionsCount) * 100) : 0;

    const overallPercent = totalItemsCount > 0 
        ? Math.round((practicePercent * 0.7) + (readingPercent * 0.3))
        : readingPercent;

    return {
        modalId,
        lastVisited: modalProg.lastVisited,
        viewedSectionsCount,
        totalSectionsCount,
        readingPercent,
        completedItemsCount,
        totalItemsCount,
        practicePercent,
        overallPercent,
        isStarted: viewedSectionsCount > 0 || completedItemsCount > 0,
        isMastered: overallPercent >= 90
    };
}

/**
 * Reset progress for a specific modal verb
 * @param {string} modalId 
 */
export function resetModalProgress(modalId) {
    if (!modalId) return;
    const data = loadModalProgress();
    if (data.modals[modalId]) {
        delete data.modals[modalId];
        saveModalProgress(data);
    }
}
