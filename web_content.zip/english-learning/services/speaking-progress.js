/**
 * LocalStorage Service for Speaking English Progress
 * Handles reading and writing user progress locally.
 */

const STORAGE_KEY = 'speaking_english_progress_v1';

/**
 * Default progress data shape
 */
const defaultProgress = {
    topicsOpened: {},     // { [topicId]: timestamp }
    completedLessons: {}, // { [topicId]: [lessonId1, lessonId2] }
    difficultyProgress: {}// { [topicId]: 'easy' | 'medium' | 'hard' }
};

/**
 * Load progress object from LocalStorage
 * @returns {object}
 */
export function getProgress() {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (!raw) return { ...defaultProgress };
        const parsed = JSON.parse(raw);
        return {
            topicsOpened: parsed.topicsOpened || {},
            completedLessons: parsed.completedLessons || {},
            difficultyProgress: parsed.difficultyProgress || {}
        };
    } catch (e) {
        console.warn('Failed to read speaking progress from LocalStorage:', e);
        return { ...defaultProgress };
    }
}

/**
 * Save progress object to LocalStorage
 * @param {object} progress 
 */
function saveProgress(progress) {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
    } catch (e) {
        console.warn('Failed to save speaking progress to LocalStorage:', e);
    }
}

/**
 * Mark a topic as opened/visited
 * @param {string} topicId 
 */
export function markTopicOpened(topicId) {
    if (!topicId) return;
    const progress = getProgress();
    if (!progress.topicsOpened[topicId]) {
        progress.topicsOpened[topicId] = Date.now();
        saveProgress(progress);
    }
}

/**
 * Save selected difficulty for a topic
 * @param {string} topicId 
 * @param {string} difficulty - 'easy' | 'medium' | 'hard'
 */
export function setTopicDifficulty(topicId, difficulty) {
    if (!topicId || !difficulty) return;
    const progress = getProgress();
    progress.difficultyProgress[topicId] = difficulty;
    saveProgress(progress);
}

/**
 * Get selected difficulty for a topic
 * @param {string} topicId 
 * @param {string} fallback 
 * @returns {string}
 */
export function getTopicDifficulty(topicId, fallback = 'easy') {
    if (!topicId) return fallback;
    const progress = getProgress();
    return progress.difficultyProgress[topicId] || fallback;
}

/**
 * Mark a lesson as completed
 * @param {string} topicId 
 * @param {string} lessonId 
 */
export function markLessonCompleted(topicId, lessonId) {
    if (!topicId || !lessonId) return;
    const progress = getProgress();
    if (!progress.completedLessons[topicId]) {
        progress.completedLessons[topicId] = [];
    }
    if (!progress.completedLessons[topicId].includes(lessonId)) {
        progress.completedLessons[topicId].push(lessonId);
        saveProgress(progress);
    }
}

/**
 * Toggle lesson completion state
 * @param {string} topicId 
 * @param {string} lessonId 
 * @returns {boolean} returns true if marked completed, false if un-marked
 */
export function toggleLessonCompleted(topicId, lessonId) {
    if (!topicId || !lessonId) return false;
    const progress = getProgress();
    if (!progress.completedLessons[topicId]) {
        progress.completedLessons[topicId] = [];
    }
    const index = progress.completedLessons[topicId].indexOf(lessonId);
    let isCompleted = false;
    if (index === -1) {
        progress.completedLessons[topicId].push(lessonId);
        isCompleted = true;
    } else {
        progress.completedLessons[topicId].splice(index, 1);
        isCompleted = false;
    }
    saveProgress(progress);
    return isCompleted;
}

/**
 * Check if a lesson is completed
 * @param {string} topicId 
 * @param {string} lessonId 
 * @returns {boolean}
 */
export function isLessonCompleted(topicId, lessonId) {
    const progress = getProgress();
    return Boolean(
        progress.completedLessons[topicId] && 
        progress.completedLessons[topicId].includes(lessonId)
    );
}

/**
 * Get total number of completed lessons for a topic
 * @param {string} topicId 
 * @returns {number}
 */
export function getCompletedLessonsCount(topicId) {
    const progress = getProgress();
    return (progress.completedLessons[topicId] || []).length;
}

/**
 * Check if a topic has been opened
 * @param {string} topicId 
 * @returns {boolean}
 */
export function isTopicOpened(topicId) {
    const progress = getProgress();
    return Boolean(progress.topicsOpened[topicId]);
}
