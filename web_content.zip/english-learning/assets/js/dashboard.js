/**
 * Dashboard Entry Point Module
 * Renders the Speaking English module home dashboard.
 */

import { speakingCategories } from '../../data/speaking.js';
import { createSpeakingHeader } from '../../components/speaking-header.js';
import { createSpeakingBreadcrumb } from '../../components/speaking-breadcrumb.js';
import { createSpeakingCard } from '../../components/speaking-card.js';
import { getProgress } from '../../services/speaking-progress.js';

document.addEventListener('DOMContentLoaded', () => {
    initDashboard();
});

function initDashboard() {
    const headerContainer = document.getElementById('header-container');
    const breadcrumbContainer = document.getElementById('breadcrumb-container');
    const cardsGridContainer = document.getElementById('cards-grid-container');
    const categoryCountBadge = document.getElementById('category-count');

    // 1. Render Header
    if (headerContainer) {
        const headerEl = createSpeakingHeader({
            title: "Speaking English",
            subtitle: "Improve your English speaking skills step by step.",
            showBack: false
        });
        headerContainer.appendChild(headerEl);
    }

    // 2. Render Breadcrumb
    if (breadcrumbContainer) {
        const breadcrumbEl = createSpeakingBreadcrumb({
            topicTitle: null,
            isSubpage: false
        });
        breadcrumbContainer.appendChild(breadcrumbEl);
    }

    // 3. Update Category Count
    if (categoryCountBadge) {
        categoryCountBadge.textContent = `${speakingCategories.length} Categories`;
    }

    // 4. Load user progress from LocalStorage
    const progress = getProgress();

    // 5. Render Category Cards
    if (cardsGridContainer) {
        cardsGridContainer.innerHTML = '';
        
        speakingCategories.forEach(category => {
            const isOpened = Boolean(progress.topicsOpened && progress.topicsOpened[category.id]);
            const cardEl = createSpeakingCard(category, {
                isOpened,
                basePath: 'pages/'
            });
            cardsGridContainer.appendChild(cardEl);
        });
    }
}
