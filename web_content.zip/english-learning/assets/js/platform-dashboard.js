/**
 * Main Platform Dashboard Controller Module
 * Single Source of Truth entry point for the English Learning Platform.
 * Dynamically loads header, sidebar, and module cards using data/menu.js.
 */

import { platformMenu } from '../../data/menu.js';
import { createPlatformHeader } from '../../components/platform-header.js';
import { createPlatformSidebar } from '../../components/platform-sidebar.js';
import { getProgress } from '../../services/speaking-progress.js';

document.addEventListener('DOMContentLoaded', () => {
    initPlatformDashboard();
});

function initPlatformDashboard() {
    const headerContainer = document.getElementById('header-container');
    const sidebarContainer = document.getElementById('sidebar-container');
    const dashboardMainContainer = document.getElementById('dashboard-main-container');

    // 1. Render Platform Header
    if (headerContainer) {
        const headerEl = createPlatformHeader({
            title: "English Learning Platform",
            subtitle: "Learn English from Beginner to Advanced",
            showSidebarToggle: true,
            basePath: "",
            onMenuToggle: () => {
                const sidebarEl = document.querySelector('.platform-sidebar');
                if (sidebarEl) {
                    sidebarEl.classList.toggle('is-collapsed');
                }
            }
        });
        headerContainer.appendChild(headerEl);
    }

    // 2. Render Platform Sidebar from data/menu.js
    if (sidebarContainer) {
        const sidebarInstance = createPlatformSidebar({
            activeId: "dashboard",
            basePath: "",
            collapsed: false
        });
        sidebarContainer.appendChild(sidebarInstance);
    }

    // 3. Render Main Dashboard Content
    if (dashboardMainContainer) {
        dashboardMainContainer.innerHTML = '';

        // Hero Welcome Banner
        const heroBanner = createHeroBanner();
        dashboardMainContainer.appendChild(heroBanner);

        // Modules Grid Section
        const gridSection = createModulesGridSection();
        dashboardMainContainer.appendChild(gridSection);
    }
}

function createHeroBanner() {
    const progress = getProgress();
    const openedTopicsCount = Object.keys(progress.topicsOpened || {}).length;

    const banner = document.createElement('section');
    banner.className = 'dashboard-hero-banner';

    banner.innerHTML = `
        <div class="hero-text-group">
            <span class="hero-tag">Hindi Medium Platform</span>
            <h2 class="hero-title">English Learning Dashboard</h2>
            <p class="hero-subtitle">
                Master English step-by-step with structured lessons in Tenses, Grammar, Modal Verbs, Vocabulary, and Real-Life Speaking.
            </p>
        </div>
        <div class="hero-stats-group">
            <div class="stat-item">
                <span class="stat-value">12</span>
                <span class="stat-label">Modules</span>
            </div>
            <div class="stat-item">
                <span class="stat-value">16</span>
                <span class="stat-label">Speaking Topics</span>
            </div>
            <div class="stat-item">
                <span class="stat-value">${openedTopicsCount}</span>
                <span class="stat-label">Active Topics</span>
            </div>
        </div>
    `;

    return banner;
}

function createModulesGridSection() {
    const section = document.createElement('section');
    section.className = 'dashboard-grid-section';

    // Exclude the 'dashboard' item itself from module cards
    const modules = platformMenu.filter(item => item.id !== 'dashboard');

    section.innerHTML = `
        <div class="grid-section-header">
            <h3 class="grid-section-title">Platform Learning Modules</h3>
            <span class="grid-section-meta">${modules.length} Core Areas</span>
        </div>
        <div class="modules-grid" id="platform-modules-grid"></div>
    `;

    const gridContainer = section.querySelector('#platform-modules-grid');

    modules.forEach(module => {
        const cardEl = createModuleCard(module);
        gridContainer.appendChild(cardEl);
    });

    return section;
}

function createModuleCard(module) {
    const card = document.createElement('article');
    const isSpeaking = module.id === 'speaking-english';
    const isTenses = module.id === 'tenses';
    const isActiveModule = isSpeaking || isTenses;

    card.className = `platform-module-card ${isActiveModule ? 'featured-module' : ''}`;

    const iconSymbol = getIconSymbol(module.icon);
    const description = getModuleDescription(module);
    const subitemsSummaryHtml = renderSubitemsSummary(module);

    let targetUrl = '#';
    let buttonText = 'Explore Module →';

    if (isSpeaking) {
        targetUrl = 'pages/speaking-topic.html?id=daily-conversation-basics';
        buttonText = 'Open Speaking Module →';
    } else if (isTenses) {
        targetUrl = 'pages/tenses.html';
        buttonText = 'Explore Tenses →';
    }

    card.innerHTML = `
        <div class="module-card-top">
            <div class="module-icon-box">${iconSymbol}</div>
            ${isActiveModule ? '<span class="status-active-badge">Active Module</span>' : '<span class="status-upcoming-badge">Structured</span>'}
        </div>
        <div class="module-card-body">
            <h4 class="module-card-title">${escapeHtml(module.title)}</h4>
            <p class="module-card-description">${escapeHtml(description)}</p>
            ${subitemsSummaryHtml}
        </div>
        <div class="module-card-footer">
            <a href="${targetUrl}" class="btn-open-module" data-module-id="${module.id}">
                <span>${escapeHtml(buttonText)}</span>
                <svg class="btn-icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                    <polyline points="12 5 19 12 12 19"></polyline>
                </svg>
            </a>
        </div>
    `;

    // Intercept clicks on upcoming placeholder modules
    if (!isActiveModule) {
        setTimeout(() => {
            const linkBtn = card.querySelector('.btn-open-module');
            if (linkBtn) {
                linkBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    showPlaceholderToast(module.title);
                });
            }
        }, 0);
    }

    return card;
}

function renderSubitemsSummary(module) {
    if (!module.children || module.children.length === 0) {
        return '';
    }

    let chips = [];

    if (module.id === 'tenses') {
        chips = ['Present', 'Past', 'Future'];
    } else if (module.id === 'speaking-english') {
        chips = ['Daily Basics', 'Office English', 'Interviews', '+13 More'];
    } else if (module.id === 'modal-verbs') {
        chips = ['Can', 'Could', 'May', 'Might', 'Must', '+8 More'];
    } else if (module.id === 'verbs-library') {
        chips = ['V1-V5 Forms', 'Easy', 'Medium', 'Hard'];
    } else if (module.id === 'grammar') {
        chips = ['Foundation', 'Intermediate', 'Advanced'];
    } else {
        chips = module.children.slice(0, 3).map(c => c.title);
        if (module.children.length > 3) {
            chips.push(`+${module.children.length - 3} More`);
        }
    }

    const chipsHtml = chips.map(c => `<span class="subitem-chip ${c.includes('More') ? 'more-chip' : ''}">${escapeHtml(c)}</span>`).join('');

    return `
        <div class="module-subitems-summary">
            ${chipsHtml}
        </div>
    `;
}

function getModuleDescription(module) {
    const descriptions = {
        'tenses': 'Master Present, Past, and Future tenses with formulas, rules, and Hindi explanations.',
        'modal-verbs': 'Learn Can, Could, May, Might, Should, Must, Would and all 13 auxiliary modal verbs.',
        'verbs-library': 'Comprehensive V1 to V5 verb forms organized by Easy, Medium, and Hard tiers.',
        'grammar': 'Step-by-step English grammar rules from Foundation to Advanced levels.',
        'speaking-english': '16 practical speaking categories with real dialogues, vocabulary, and daily practice.',
        'practice-quiz': 'Interactive sentence construction tests, quizzes, and practice exercises.',
        'search': 'Instant search across all tenses, grammar rules, vocabulary, and speaking topics.',
        'bookmarks': 'Quick access to your saved lessons, grammar points, and speaking phrases.',
        'my-notes': 'Personal study notes, vocabulary list, and custom practice sentences.',
        'my-progress': 'Track your overall learning statistics, completed lessons, and accuracy.',
        'quick-reference': 'Handy cheat sheets for prepositions, tense formulas, and common idioms.'
    };

    return descriptions[module.id] || 'Structured module ready in the learning platform.';
}

function showPlaceholderToast(moduleTitle) {
    const existing = document.querySelector('.placeholder-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = 'placeholder-toast';

    toast.innerHTML = `
        <span class="toast-icon">ℹ️</span>
        <span class="toast-message"><strong>${escapeHtml(moduleTitle)}</strong> architecture is configured. Content module arriving in next phase.</span>
        <button class="toast-close-btn">&times;</button>
    `;

    document.body.appendChild(toast);

    toast.querySelector('.toast-close-btn').addEventListener('click', () => {
        toast.remove();
    });

    setTimeout(() => {
        if (document.body.contains(toast)) {
            toast.remove();
        }
    }, 4000);
}

function getIconSymbol(iconName) {
    const icons = {
        'dashboard': '🏠',
        'clock': '⏰',
        'sparkles': '✨',
        'book-open': '📖',
        'academic-cap': '🎓',
        'chat-alt': '💬',
        'pencil-alt': '📝',
        'search': '🔍',
        'bookmark': '🔖',
        'document-text': '📑',
        'chart-bar': '📊',
        'light-bulb': '💡'
    };
    return icons[iconName] || '🔹';
}

function escapeHtml(str) {
    if (!str) return '';
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
