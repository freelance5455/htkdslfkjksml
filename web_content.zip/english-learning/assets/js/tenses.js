/**
 * Tenses Module Main Controller
 * Dynamically renders Present, Past, and Future Tenses groups and cards from data/tenses.js.
 * Uses shared Platform Header & Sidebar with activeId: "tenses".
 */

import { tensesData, getAllTenses } from '../../data/tenses.js';
import { createPlatformHeader } from '../../components/platform-header.js';
import { createPlatformSidebar } from '../../components/platform-sidebar.js';

document.addEventListener('DOMContentLoaded', () => {
    initTensesModule();
});

function initTensesModule() {
    const headerContainer = document.getElementById('header-container');
    const sidebarContainer = document.getElementById('sidebar-container');
    const tensesMainContainer = document.getElementById('tenses-main-container');

    // 1. Initialize Shared Platform Header
    if (headerContainer) {
        const headerEl = createPlatformHeader({
            title: "English Learning Platform",
            subtitle: "English Tenses - काल (Tenses)",
            showSidebarToggle: true,
            basePath: "../",
            onMenuToggle: () => {
                const sidebarEl = document.querySelector('.platform-sidebar');
                if (sidebarEl) {
                    sidebarEl.classList.toggle('is-collapsed');
                }
            }
        });
        headerContainer.appendChild(headerEl);
    }

    // 2. Initialize Shared Platform Sidebar (activeId: "tenses")
    if (sidebarContainer) {
        const sidebarInstance = createPlatformSidebar({
            activeId: "tenses",
            basePath: "../",
            collapsed: false
        });
        sidebarContainer.appendChild(sidebarInstance);
    }

    // 3. Render Tenses Module Page Content
    if (tensesMainContainer) {
        tensesMainContainer.innerHTML = '';

        // Tenses Header Hero Card
        const headerCard = createTensesHeaderCard();
        tensesMainContainer.appendChild(headerCard);

        // Render Tense Groups (Present, Past, Future)
        const groupsContainer = createTensesGroupsContainer();
        tensesMainContainer.appendChild(groupsContainer);
    }
}

function createTensesHeaderCard() {
    const totalCount = getAllTenses().length;
    const card = document.createElement('section');
    card.className = 'tenses-header-card';

    card.innerHTML = `
        <div class="tenses-header-text">
            <span class="tenses-tag">Grammar Module</span>
            <h2 class="tenses-page-title">English Tenses — काल</h2>
            <p class="tenses-page-subtitle">
                Master all 12 English tenses with formulas, rules, positive/negative structures, and Hindi explanations.
            </p>
        </div>
        <div class="tenses-header-badge">
            <span class="tenses-badge-count">${totalCount}</span>
            <span class="tenses-badge-label">Total Tenses</span>
        </div>
    `;

    return card;
}

function createTensesGroupsContainer() {
    const layout = document.createElement('div');
    layout.className = 'tenses-page-layout';

    // Render 3 Groups: Present, Past, Future from data/tenses.js
    const groups = ['present', 'past', 'future'];
    let globalCounter = 1;

    groups.forEach(groupKey => {
        const group = tensesData[groupKey];
        if (group) {
            const sectionEl = createTenseGroupSection(group, globalCounter);
            globalCounter += group.tenses ? group.tenses.length : 0;
            layout.appendChild(sectionEl);
        }
    });

    return layout;
}

function createTenseGroupSection(group, startCounter) {
    const section = document.createElement('section');
    section.className = 'tense-group-section';

    section.innerHTML = `
        <div class="group-header-bar">
            <h3 class="group-title-en">${escapeHtml(group.title)}</h3>
            <span class="group-title-hi">${escapeHtml(group.titleHindi)}</span>
        </div>
        <div class="tense-cards-grid"></div>
    `;

    const gridEl = section.querySelector('.tense-cards-grid');

    if (group.tenses && group.tenses.length > 0) {
        group.tenses.forEach((tense, idx) => {
            const cardEl = createTenseCard(tense, startCounter + idx);
            gridEl.appendChild(cardEl);
        });
    }

    return section;
}

function createTenseCard(tense, indexNumber) {
    const card = document.createElement('article');
    card.className = 'tense-card';

    // Contract navigation link for next detail step
    const targetUrl = `tense.html?id=${encodeURIComponent(tense.id)}`;

    card.innerHTML = `
        <div class="tense-card-top">
            <span class="tense-order-number">Tense ${indexNumber}</span>
        </div>
        <div class="tense-card-body">
            <h4 class="tense-card-title-en">${escapeHtml(tense.title)}</h4>
            <span class="tense-card-title-hi">${escapeHtml(tense.titleHindi)}</span>
        </div>
        <div class="tense-card-footer">
            <a href="${targetUrl}" class="btn-learn-tense" data-tense-id="${tense.id}">
                <span>Learn Tense →</span>
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                    <polyline points="12 5 19 12 12 19"></polyline>
                </svg>
            </a>
        </div>
    `;

    return card;
}

function escapeHtml(str) {
    if (!str) return '';
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
