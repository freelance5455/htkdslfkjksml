/**
 * Controller: Simple Present Quiz Logic Module
 * Handles question selection, randomization, option generation, scoring, and UI state transitions.
 * Pure in-memory quiz engine (does not save to LocalStorage, does not modify Progress).
 */

import {
    createQuizCardHeader,
    renderQuizSetupUI,
    renderQuizQuestionUI,
    renderQuizResultsUI
} from '../../components/tense-quiz.js';

let quizState = {
    category: 'positive',
    difficulty: 'easy',
    questions: [],
    currentIndex: 0,
    score: 0,
    isAnswered: false,
    lessonData: null
};

/**
 * Initialize Tense Quiz section inside container
 * @param {HTMLElement} container 
 * @param {object} lessonData 
 */
export function initTenseQuiz(container, lessonData) {
    if (!container || !lessonData) return;

    quizState.lessonData = lessonData;

    const tenseTitle = lessonData.title || 'Tense';
    container.innerHTML = `
        ${createQuizCardHeader(tenseTitle)}
        <div class="section-card-body quiz-card-body" id="quiz-body-container"></div>
    `;

    const bodyContainer = container.querySelector('#quiz-body-container');
    renderSetupScreen(bodyContainer);
}

export function initSimplePresentQuiz(container, lessonData) {
    return initTenseQuiz(container, lessonData);
}

function renderSetupScreen(bodyContainer) {
    bodyContainer.innerHTML = renderQuizSetupUI(quizState.category, quizState.difficulty);

    // Bind Category Tabs
    const catBtns = bodyContainer.querySelectorAll('#quiz-cat-tabs .quiz-cat-btn');
    catBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const selectedCat = e.currentTarget.dataset.cat;
            quizState.category = selectedCat;
            catBtns.forEach(b => b.classList.remove('active'));
            e.currentTarget.classList.add('active');
        });
    });

    // Bind Difficulty Tabs
    const diffBtns = bodyContainer.querySelectorAll('#quiz-diff-tabs .quiz-diff-btn');
    diffBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const selectedDiff = e.currentTarget.dataset.diff;
            quizState.difficulty = selectedDiff;
            diffBtns.forEach(b => b.classList.remove('active'));
            e.currentTarget.classList.add('active');
        });
    });

    // Bind Start Quiz Button
    const startBtn = bodyContainer.querySelector('#btn-start-quiz');
    if (startBtn) {
        startBtn.addEventListener('click', () => {
            startQuiz(bodyContainer);
        });
    }
}

function startQuiz(bodyContainer) {
    quizState.questions = generateQuizQuestions(quizState.category, quizState.difficulty, quizState.lessonData);
    quizState.currentIndex = 0;
    quizState.score = 0;
    quizState.isAnswered = false;

    if (quizState.questions.length === 0) {
        bodyContainer.innerHTML = `<p class="quiz-error-msg">No practice items found for selected category and difficulty.</p>`;
        return;
    }

    renderCurrentQuestion(bodyContainer);
}

function renderCurrentQuestion(bodyContainer) {
    const qData = quizState.questions[quizState.currentIndex];
    quizState.isAnswered = false;

    bodyContainer.innerHTML = renderQuizQuestionUI(qData, quizState.score);

    // Bind Option Clicks
    const optionBtns = bodyContainer.querySelectorAll('#quiz-options-grid .quiz-option-btn');
    optionBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const optIdx = parseInt(e.currentTarget.dataset.optIdx, 10);
            handleOptionSelect(bodyContainer, optIdx, optionBtns, qData);
        });
    });

    // Bind Next Question Button
    const nextBtn = bodyContainer.querySelector('#btn-next-question');
    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            if (quizState.currentIndex < quizState.questions.length - 1) {
                quizState.currentIndex++;
                renderCurrentQuestion(bodyContainer);
            } else {
                renderResultsScreen(bodyContainer);
            }
        });
    }
}

function handleOptionSelect(bodyContainer, selectedOptIdx, optionBtns, qData) {
    if (quizState.isAnswered) return;
    quizState.isAnswered = true;

    // Lock option buttons
    optionBtns.forEach(b => b.classList.add('is-disabled'));

    const selectedOption = qData.options[selectedOptIdx];
    const isCorrect = Boolean(selectedOption && selectedOption.isCorrect);

    const feedbackBox = bodyContainer.querySelector('#quiz-feedback-box');
    const feedbackHeader = bodyContainer.querySelector('#feedback-status-header');
    const feedbackHi = bodyContainer.querySelector('#feedback-hi');
    const feedbackStruct = bodyContainer.querySelector('#feedback-struct');

    if (isCorrect) {
        quizState.score++;
        optionBtns[selectedOptIdx].classList.add('is-correct');
        if (feedbackHeader) {
            feedbackHeader.className = 'feedback-status-header header-correct';
            feedbackHeader.innerHTML = `
                <span class="status-icon">✅</span>
                <span class="status-title">Correct Answer! / सही उत्तर!</span>
            `;
        }
    } else {
        optionBtns[selectedOptIdx].classList.add('is-incorrect');
        // Find and highlight correct answer in green
        qData.options.forEach((opt, idx) => {
            if (opt.isCorrect) {
                optionBtns[idx].classList.add('is-correct');
            }
        });

        if (feedbackHeader) {
            feedbackHeader.className = 'feedback-status-header header-incorrect';
            feedbackHeader.innerHTML = `
                <span class="status-icon">❌</span>
                <span class="status-title">Incorrect! / गलत उत्तर!</span>
            `;
        }
    }

    if (feedbackHi) {
        feedbackHi.innerHTML = `💡 <strong>Hindi Sentence:</strong> ${escapeHtml(qData.promptHindi)}`;
    }
    if (feedbackStruct) {
        feedbackStruct.innerHTML = `📐 <strong>Grammar Rule:</strong> <code>${escapeHtml(qData.structureNote)}</code>`;
    }

    // Update live score display badge
    const scoreBadge = bodyContainer.querySelector('.score-badge strong');
    if (scoreBadge) {
        scoreBadge.textContent = quizState.score;
    }

    // Show feedback box
    if (feedbackBox) {
        feedbackBox.classList.remove('is-hidden');
    }
}

function renderResultsScreen(bodyContainer) {
    const totalQuestions = quizState.questions.length || 10;
    const score = quizState.score;
    const percentage = Math.round((score / totalQuestions) * 100);
    const correctCount = score;
    const incorrectCount = totalQuestions - score;

    const firstQ = quizState.questions[0] || {};
    const categoryTitle = firstQ.categoryTitle || 'Simple Present';
    const difficulty = quizState.difficulty;

    const results = {
        score,
        totalQuestions,
        percentage,
        correctCount,
        incorrectCount,
        categoryTitle,
        difficulty
    };

    bodyContainer.innerHTML = renderQuizResultsUI(results);

    // Bind Retry Quiz
    const retryBtn = bodyContainer.querySelector('#btn-retry-quiz');
    if (retryBtn) {
        retryBtn.addEventListener('click', () => {
            startQuiz(bodyContainer);
        });
    }

    // Bind Change Config
    const changeConfigBtn = bodyContainer.querySelector('#btn-change-config');
    if (changeConfigBtn) {
        changeConfigBtn.addEventListener('click', () => {
            renderSetupScreen(bodyContainer);
        });
    }
}

/**
 * Generate 10 randomized quiz questions from existing practice data
 * @param {string} category 
 * @param {string} difficulty 
 * @param {object} lessonData 
 * @returns {Array<object>}
 */
export function generateQuizQuestions(category, difficulty, lessonData) {
    if (!lessonData || !lessonData.sections || !lessonData.sections.exercises) return [];

    const categories = lessonData.sections.exercises.categories || [];
    const catObj = categories.find(c => c.id === category) || categories[0];
    if (!catObj || !catObj.sentences) return [];

    const targetList = catObj.sentences[difficulty] || [];
    if (targetList.length === 0) return [];

    // Shuffle and pick 10 target questions
    const shuffledTargets = shuffleArray(targetList).slice(0, 10);

    // Gather all candidate distractors from same category across all difficulty levels
    const allCatItems = [
        ...(catObj.sentences.easy || []),
        ...(catObj.sentences.medium || []),
        ...(catObj.sentences.hard || [])
    ];

    return shuffledTargets.map((item, index) => {
        const correctAnswer = item.english;

        // Distractor candidate pool (distinct English sentences)
        const candidates = allCatItems
            .filter(d => d.english !== correctAnswer)
            .map(d => d.english);

        const uniqueCandidates = Array.from(new Set(candidates));
        const selectedDistractors = shuffleArray(uniqueCandidates).slice(0, 3);

        // Standardized 4 Options
        const rawOptions = [
            { text: correctAnswer, isCorrect: true },
            ...selectedDistractors.map(text => ({ text, isCorrect: false }))
        ];

        return {
            index: index + 1,
            item,
            category: catObj.id,
            categoryTitle: catObj.title,
            difficulty,
            promptHindi: item.hindi,
            correctAnswer,
            options: shuffleArray(rawOptions),
            explanation: item.hindi,
            structureNote: getGrammarStructureNote(catObj.id, item)
        };
    });
}

function getGrammarStructureNote(categoryType, item) {
    const tenseId = quizState.lessonData ? quizState.lessonData.id : '';
    
    if (tenseId === 'future-perfect-continuous') {
        if (categoryType === 'positive') {
            return `Subject (${item.subject || 'Subject'}) + will have been + V1+ing (${item.verb || 'V1+ing'}) + Object`;
        } else if (categoryType === 'negative') {
            return `Subject (${item.subject || 'Subject'}) + ${item.aux || "won't have been"} + V1+ing (${item.verb || 'V1+ing'}) + Object`;
        } else if (categoryType === 'interrogative') {
            return `Will + Subject (${item.subject || 'Subject'}) + have been + V1+ing (${item.verb || 'V1+ing'}) + Object?`;
        } else if (categoryType === 'whQuestions') {
            return item.whWord === 'Who' && !item.aux ? `Who + will have been + V1+ing (${item.verb || 'V1+ing'}) + Object?` : `${item.whWord || 'WH Word'} + will + Subject (${item.subject || 'Subject'}) + have been + V1+ing (${item.verb || 'V1+ing'})?`;
        }
    }

    if (tenseId === 'past-perfect-continuous') {
        if (categoryType === 'positive') {
            return `Subject (${item.subject || 'Subject'}) + had been + V1+ing (${item.verb || 'V1+ing'}) + Object`;
        } else if (categoryType === 'negative') {
            return `Subject (${item.subject || 'Subject'}) + ${item.aux || "hadn't been"} + V1+ing (${item.verb || 'V1+ing'}) + Object`;
        } else if (categoryType === 'interrogative') {
            return `Had + Subject (${item.subject || 'Subject'}) + been + V1+ing (${item.verb || 'V1+ing'})?`;
        } else if (categoryType === 'whQuestions') {
            return `${item.whWord || 'WH Word'} + had + Subject (${item.subject || 'Subject'}) + been + V1+ing (${item.verb || 'V1+ing'})?`;
        }
    }

    if (tenseId === 'future-perfect') {
        if (categoryType === 'positive') {
            return `Subject (${item.subject || 'Subject'}) + will have + V3 (${item.verb || 'V3'}) + Object`;
        } else if (categoryType === 'negative') {
            return `Subject (${item.subject || 'Subject'}) + ${item.aux || "won't have"} + V3 (${item.verb || 'V3'}) + Object`;
        } else if (categoryType === 'interrogative') {
            return `Will + Subject (${item.subject || 'Subject'}) + have + V3 (${item.verb || 'V3'}) + Object?`;
        } else if (categoryType === 'whQuestions') {
            return item.whWord === 'Who' && !item.aux ? `Who + will have + V3 (${item.verb || 'V3'}) + Object?` : `${item.whWord || 'WH Word'} + will + Subject (${item.subject || 'Subject'}) + have + V3 (${item.verb || 'V3'})?`;
        }
    }

    if (tenseId === 'future-continuous') {
        if (categoryType === 'positive') {
            return `Subject (${item.subject || 'Subject'}) + will be + V1+ing (${item.verb || 'V1+ing'}) + Object`;
        } else if (categoryType === 'negative') {
            return `Subject (${item.subject || 'Subject'}) + ${item.aux || "won't be"} + V1+ing (${item.verb || 'V1+ing'}) + Object`;
        } else if (categoryType === 'interrogative') {
            return `Will + Subject (${item.subject || 'Subject'}) + be + V1+ing (${item.verb || 'V1+ing'}) + Object?`;
        } else if (categoryType === 'whQuestions') {
            return item.whWord === 'Who' && !item.aux ? `Who + will be + V1+ing (${item.verb || 'V1+ing'}) + Object?` : `${item.whWord || 'WH Word'} + will + Subject (${item.subject || 'Subject'}) + be + V1+ing (${item.verb || 'V1+ing'})?`;
        }
    }

    if (tenseId === 'simple-future') {
        if (categoryType === 'positive') {
            return `Subject (${item.subject || 'Subject'}) + will + V1 (${item.verb || 'V1'}) + Object`;
        } else if (categoryType === 'negative') {
            return `Subject (${item.subject || 'Subject'}) + ${item.aux || "won't"} + V1 (${item.verb || 'V1'}) + Object`;
        } else if (categoryType === 'interrogative') {
            return `Will + Subject (${item.subject || 'Subject'}) + V1 (${item.verb || 'V1'}) + Object?`;
        } else if (categoryType === 'whQuestions') {
            return item.whWord === 'Who' && !item.aux ? `Who + will + V1 (${item.verb || 'V1'}) + Object?` : `${item.whWord || 'WH Word'} + will + Subject (${item.subject || 'Subject'}) + V1 (${item.verb || 'V1'})?`;
        }
    }

    if (tenseId === 'past-perfect') {
        if (categoryType === 'positive') {
            return `Subject (${item.subject || 'Subject'}) + had + V3 (${item.verb || 'V3'}) + Object`;
        } else if (categoryType === 'negative') {
            return `Subject (${item.subject || 'Subject'}) + ${item.aux || "hadn't"} + V3 (${item.verb || 'V3'}) + Object`;
        } else if (categoryType === 'interrogative') {
            return `Had + Subject (${item.subject || 'Subject'}) + V3 (${item.verb || 'V3'})?`;
        } else if (categoryType === 'whQuestions') {
            return `${item.whWord || 'WH Word'} + had + Subject (${item.subject || 'Subject'}) + V3 (${item.verb || 'V3'})?`;
        }
    }

    if (tenseId === 'simple-past') {
        if (categoryType === 'positive') {
            return `Subject (${item.subject || 'Subject'}) + V2 (${item.verb || 'V2'}) + Object`;
        } else if (categoryType === 'negative') {
            return `Subject (${item.subject || 'Subject'}) + did not / didn't + V1 (${item.verb || 'V1'}) + Object`;
        } else if (categoryType === 'interrogative') {
            return `Did + Subject (${item.subject || 'Subject'}) + V1 (${item.verb || 'V1'}) + Object?`;
        } else if (categoryType === 'whQuestions') {
            return item.whWord === 'Who' && !item.aux ? `Who + V2 (${item.verb || 'V2'}) + Object?` : `${item.whWord || 'WH Word'} + did + Subject (${item.subject || 'Subject'}) + V1 (${item.verb || 'V1'})?`;
        }
    }

    if (tenseId === 'past-continuous') {
        if (categoryType === 'positive') {
            return `Subject (${item.subject || 'Subject'}) + ${item.aux || 'was/were'} + V1+ing (${item.verb || 'V1+ing'}) + Object`;
        } else if (categoryType === 'negative') {
            return `Subject (${item.subject || 'Subject'}) + ${item.aux || "wasn't/weren't"} + V1+ing (${item.verb || 'V1+ing'}) + Object`;
        } else if (categoryType === 'interrogative') {
            return `${item.aux || 'Was/Were'} + Subject (${item.subject || 'Subject'}) + V1+ing (${item.verb || 'V1+ing'})?`;
        } else if (categoryType === 'whQuestions') {
            return `${item.whWord || 'WH Word'} + ${item.aux || 'was/were'} + Subject (${item.subject || 'Subject'}) + V1+ing (${item.verb || 'V1+ing'})?`;
        }
    }

    if (tenseId === 'present-perfect-continuous') {
        if (categoryType === 'positive') {
            return `Subject (${item.subject || 'Subject'}) + ${item.aux || 'has/have been'} + V1+ing (${item.verb || 'V1+ing'}) + Object`;
        } else if (categoryType === 'negative') {
            return `Subject (${item.subject || 'Subject'}) + ${item.aux || 'has/have not been'} + V1+ing (${item.verb || 'V1+ing'}) + Object`;
        } else if (categoryType === 'interrogative') {
            return `${item.aux || 'Has/Have'} + Subject (${item.subject || 'Subject'}) + been + V1+ing (${item.verb || 'V1+ing'})?`;
        } else if (categoryType === 'whQuestions') {
            return `${item.whWord || 'WH Word'} + ${item.aux || 'has/have'} + Subject (${item.subject || 'Subject'}) + been + V1+ing (${item.verb || 'V1+ing'})?`;
        }
    }

    const isPerfect = tenseId === 'present-perfect' || (item.aux && (item.aux.includes('has') || item.aux.includes('have')) && !item.verb?.includes('ing'));
    if (isPerfect) {
        if (categoryType === 'positive') {
            return `Subject (${item.subject || 'Subject'}) + ${item.aux || 'has/have'} + V3 (${item.verb || 'V3'})`;
        } else if (categoryType === 'negative') {
            return `Subject (${item.subject || 'Subject'}) + ${item.aux || 'has/have'} + not + V3 (${item.verb || 'V3'})`;
        } else if (categoryType === 'interrogative') {
            return `${item.aux || 'Has/Have'} + Subject (${item.subject || 'Subject'}) + V3 (${item.verb || 'V3'})?`;
        } else if (categoryType === 'whQuestions') {
            return `${item.whWord || 'WH Word'} + ${item.aux || 'has/have'} + Subject (${item.subject || 'Subject'}) + V3 (${item.verb || 'V3'})?`;
        }
    }

    const isContinuous = (item.verb && (item.verb.includes('ing') || item.verb.includes('am') || item.verb.includes('is') || item.verb.includes('are'))) || (quizState.lessonData && quizState.lessonData.id === 'present-continuous');
    if (isContinuous) {
        if (categoryType === 'positive') {
            return `Subject (${item.subject || 'Subject'}) + am/is/are + V4 (${item.verb || 'V4'})`;
        } else if (categoryType === 'negative') {
            return `Subject (${item.subject || 'Subject'}) + am/is/are + not + V4 (${item.verb || 'V4'})`;
        } else if (categoryType === 'interrogative') {
            return `Am/Is/Are + Subject (${item.subject || 'Subject'}) + V4 (${item.verb || 'V4'})?`;
        } else if (categoryType === 'whQuestions') {
            return `${item.whWord || 'WH Word'} + am/is/are + Subject (${item.subject || 'Subject'}) + V4 (${item.verb || 'V4'})?`;
        }
    }

    if (categoryType === 'positive') {
        return `Subject (${item.subject || 'Subject'}) + Verb (${item.verb || 'V1/V1+s'})`;
    } else if (categoryType === 'negative') {
        return `Subject (${item.subject || 'Subject'}) + don't/doesn't + V1 (${item.verb || 'V1'})`;
    } else if (categoryType === 'interrogative') {
        return `Do/Does + Subject (${item.subject || 'Subject'}) + V1 (${item.verb || 'V1'})?`;
    } else if (categoryType === 'whQuestions') {
        return `${item.whWord || 'WH Word'} + Do/Does + Subject (${item.subject || 'Subject'}) + V1 (${item.verb || 'V1'})?`;
    }
    return "Subject + Verb Rule";
}

function shuffleArray(arr) {
    const list = [...arr];
    for (let i = list.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [list[i], list[j]] = [list[j], list[i]];
    }
    return list;
}

function escapeHtml(str) {
    if (!str) return '';
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
