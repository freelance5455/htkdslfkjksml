/**
 * Topic & Lesson Page Module
 * Handles dynamic rendering of Category Lesson List OR Selected Lesson View.
 * Concept URLs:
 * - Category View: pages/speaking-topic.html?id=<category-id>
 * - Lesson View:   pages/speaking-topic.html?id=<category-id>&lesson=<lesson-id>
 */

import { 
    getCategoryById, 
    getAdjacentCategories, 
    getLessonById, 
    getAdjacentLessons 
} from '../../data/speaking.js';
import { createSpeakingHeader } from '../../components/speaking-header.js';
import { createSpeakingBreadcrumb } from '../../components/speaking-breadcrumb.js';
import { createSpeakingLessonCard } from '../../components/speaking-lesson-card.js';
import { renderSpeakingLesson } from '../../components/speaking-lesson-renderer.js';
import { 
    markTopicOpened, 
    getTopicDifficulty, 
    setTopicDifficulty,
    isLessonCompleted,
    getCompletedLessonsCount
} from '../../services/speaking-progress.js';

document.addEventListener('DOMContentLoaded', () => {
    initTopicOrLessonPage();
});

function initTopicOrLessonPage() {
    const urlParams = new URLSearchParams(window.location.search);
    const categoryId = urlParams.get('id');
    const lessonId = urlParams.get('lesson');

    const headerContainer = document.getElementById('header-container');
    const breadcrumbContainer = document.getElementById('breadcrumb-container');
    const mainLayoutContainer = document.getElementById('main-layout-container');

    const category = categoryId ? getCategoryById(categoryId) : null;

    if (!category) {
        renderErrorState(mainLayoutContainer, breadcrumbContainer, headerContainer, "Category Not Found", "The requested Speaking English topic could not be found.");
        return;
    }

    // Mark topic as opened in LocalStorage
    markTopicOpened(category.id);

    // 1. Render Header
    if (headerContainer) {
        headerContainer.innerHTML = '';
        const headerEl = createSpeakingHeader({
            title: "Speaking English",
            subtitle: "Improve your English speaking skills step by step.",
            showBack: true,
            backUrl: "../index.html"
        });
        headerContainer.appendChild(headerEl);
    }

    // 2. Decide View Mode: Lesson View vs Category View
    if (lessonId) {
        renderLessonView({ category, lessonId, breadcrumbContainer, mainLayoutContainer });
    } else {
        renderCategoryView({ category, breadcrumbContainer, mainLayoutContainer });
    }
}

/* -------------------------------------------------------------------------- */
/* LESSON VIEW RENDERER                                                      */
/* -------------------------------------------------------------------------- */

function renderLessonView({ category, lessonId, breadcrumbContainer, mainLayoutContainer }) {
    const lesson = getLessonById(category.id, lessonId);

    if (!lesson) {
        renderErrorState(
            mainLayoutContainer, 
            breadcrumbContainer, 
            null, 
            "Lesson Not Found", 
            `The lesson "${lessonId}" was not found in ${category.title}.`,
            `speaking-topic.html?id=${encodeURIComponent(category.id)}`,
            `Back to ${category.title}`
        );
        return;
    }

    // Update document title
    document.title = `${lesson.title} - ${category.title} - Speaking English`;

    // Render Breadcrumb
    if (breadcrumbContainer) {
        breadcrumbContainer.innerHTML = '';
        const breadcrumbEl = createSpeakingBreadcrumb({
            category: { id: category.id, title: category.title },
            lessonTitle: lesson.title,
            isSubpage: true
        });
        breadcrumbContainer.appendChild(breadcrumbEl);
    }

    // Render Main Lesson Layout
    if (mainLayoutContainer) {
        mainLayoutContainer.innerHTML = '';

        // Lesson Renderer Component
        const lessonEl = renderSpeakingLesson(lesson, category);
        mainLayoutContainer.appendChild(lessonEl);

        // Lesson Previous / Next Navigation
        const { prev, next } = getAdjacentLessons(category.id, lesson.id);
        const navEl = createLessonNavigation(prev, next, category.id);
        mainLayoutContainer.appendChild(navEl);
    }
}

function createLessonNavigation(prevLesson, nextLesson, categoryId) {
    const nav = document.createElement('nav');
    nav.className = 'topic-nav-container lesson-nav-container';
    nav.setAttribute('aria-label', 'Lesson Navigation');

    nav.innerHTML = `
        ${prevLesson ? `
            <a href="speaking-topic.html?id=${encodeURIComponent(categoryId)}&lesson=${encodeURIComponent(prevLesson.id)}" class="topic-nav-btn prev-btn">
                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="19" y1="12" x2="5" y2="12"></line>
                    <polyline points="12 19 5 12 12 5"></polyline>
                </svg>
                <div class="nav-btn-text">
                    <span class="nav-btn-label">Previous Lesson</span>
                    <span class="nav-btn-title">${escapeHtml(prevLesson.title)}</span>
                </div>
            </a>
        ` : `<div class="topic-nav-btn prev-btn disabled"></div>`}

        ${nextLesson ? `
            <a href="speaking-topic.html?id=${encodeURIComponent(categoryId)}&lesson=${encodeURIComponent(nextLesson.id)}" class="topic-nav-btn next-btn">
                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                    <polyline points="12 19 5 12 12 19"></polyline>
                </svg>
                <div class="nav-btn-text">
                    <span class="nav-btn-label">Next Lesson</span>
                    <span class="nav-btn-title">${escapeHtml(nextLesson.title)}</span>
                </div>
            </a>
        ` : `<div class="topic-nav-btn next-btn disabled"></div>`}
    `;

    return nav;
}

/* -------------------------------------------------------------------------- */
/* CATEGORY VIEW RENDERER                                                     */
/* -------------------------------------------------------------------------- */

function renderCategoryView({ category, breadcrumbContainer, mainLayoutContainer }) {
    // Update document title
    document.title = `${category.title} - Speaking English`;

    // Render Breadcrumb
    if (breadcrumbContainer) {
        breadcrumbContainer.innerHTML = '';
        const breadcrumbEl = createSpeakingBreadcrumb({
            category: { id: category.id, title: category.title },
            lessonTitle: null,
            isSubpage: true
        });
        breadcrumbContainer.appendChild(breadcrumbEl);
    }

    // Render Main Category Layout
    if (mainLayoutContainer) {
        mainLayoutContainer.innerHTML = '';

        const currentDiffFilter = getTopicDifficulty(category.id, 'all');
        const completedCount = getCompletedLessonsCount(category.id);
        const totalLessons = category.lessons ? category.lessons.length : 0;

        const layout = document.createElement('div');
        layout.className = 'topic-page-layout';

        layout.innerHTML = `
            <!-- Topic Meta Header Card -->
            <section class="topic-meta-card">
                <div class="topic-meta-header">
                    <div class="topic-meta-badge-row">
                        <span class="category-tag">Speaking Category</span>
                        <span class="progress-meta-tag">${completedCount} / ${totalLessons} Lessons Completed</span>
                    </div>
                    <h2 class="topic-page-title">${escapeHtml(category.title)}</h2>
                    <p class="topic-page-description">${escapeHtml(category.description)}</p>
                </div>

                <!-- Difficulty Filter Selector -->
                <div class="difficulty-selector-container">
                    <span class="selector-label">Filter Lessons by Difficulty:</span>
                    <div class="difficulty-tabs">
                        <button type="button" class="diff-tab-btn ${currentDiffFilter === 'all' ? 'active' : ''}" data-difficulty="all">
                            All Lessons (${totalLessons})
                        </button>
                        <button type="button" class="diff-tab-btn tab-easy ${currentDiffFilter === 'easy' ? 'active' : ''}" data-difficulty="easy">
                            Easy
                        </button>
                        <button type="button" class="diff-tab-btn tab-medium ${currentDiffFilter === 'medium' ? 'active' : ''}" data-difficulty="medium">
                            Medium
                        </button>
                        <button type="button" class="diff-tab-btn tab-hard ${currentDiffFilter === 'hard' ? 'active' : ''}" data-difficulty="hard">
                            Hard
                        </button>
                    </div>
                </div>
            </section>

            <!-- Lessons Grid Container -->
            <section class="category-lessons-section">
                <div class="section-info-bar">
                    <h3 class="section-title">Category Lessons</h3>
                    <span class="category-count" id="filtered-lessons-count">${totalLessons} Available</span>
                </div>

                <div class="lessons-grid" id="lessons-grid-container"></div>
            </section>
        `;

        // Render Previous / Next Category Navigation
        const { prev, next } = getAdjacentCategories(category.id);
        const categoryNav = createCategoryNavigation(prev, next);

        mainLayoutContainer.appendChild(layout);
        mainLayoutContainer.appendChild(categoryNav);

        // Render Lessons List
        renderLessonsGrid(category, currentDiffFilter);

        // Bind Difficulty Filter Event Handlers
        bindDifficultyFilterHandlers(category);
    }
}

function renderLessonsGrid(category, difficultyFilter) {
    const gridContainer = document.getElementById('lessons-grid-container');
    const countBadge = document.getElementById('filtered-lessons-count');
    if (!gridContainer) return;

    gridContainer.innerHTML = '';

    let lessons = category.lessons || [];

    if (difficultyFilter !== 'all') {
        lessons = lessons.filter(l => l.difficulty === difficultyFilter);
    }

    if (countBadge) {
        countBadge.textContent = `${lessons.length} Lessons`;
    }

    if (lessons.length === 0) {
        gridContainer.innerHTML = `
            <div class="no-lessons-card">
                <span class="no-lessons-icon">📁</span>
                <h4 class="no-lessons-title">No lessons available in this view</h4>
                <p class="no-lessons-desc">
                    ${category.lessons && category.lessons.length > 0 
                        ? 'No lessons match the selected difficulty filter. Try selecting "All Lessons".' 
                        : 'Lesson architecture is ready for this category. Sample lessons will be populated in future content steps.'}
                </p>
            </div>
        `;
        return;
    }

    lessons.forEach(lesson => {
        const completed = isLessonCompleted(category.id, lesson.id);
        const cardEl = createSpeakingLessonCard(lesson, {
            isCompleted: completed,
            categoryId: category.id
        });
        gridContainer.appendChild(cardEl);
    });
}

function bindDifficultyFilterHandlers(category) {
    const tabs = document.querySelectorAll('.diff-tab-btn');

    tabs.forEach(tab => {
        tab.addEventListener('click', (e) => {
            const selectedDiff = e.currentTarget.dataset.difficulty;

            tabs.forEach(t => t.classList.remove('active'));
            e.currentTarget.classList.add('active');

            setTopicDifficulty(category.id, selectedDiff);
            renderLessonsGrid(category, selectedDiff);
        });
    });
}

function createCategoryNavigation(prevCategory, nextCategory) {
    const nav = document.createElement('nav');
    nav.className = 'topic-nav-container';
    nav.setAttribute('aria-label', 'Category Navigation');

    nav.innerHTML = `
        ${prevCategory ? `
            <a href="speaking-topic.html?id=${encodeURIComponent(prevCategory.id)}" class="topic-nav-btn prev-btn">
                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="19" y1="12" x2="5" y2="12"></line>
                    <polyline points="12 19 5 12 12 5"></polyline>
                </svg>
                <div class="nav-btn-text">
                    <span class="nav-btn-label">Previous Category</span>
                    <span class="nav-btn-title">${escapeHtml(prevCategory.title)}</span>
                </div>
            </a>
        ` : `<div class="topic-nav-btn prev-btn disabled"></div>`}

        ${nextCategory ? `
            <a href="speaking-topic.html?id=${encodeURIComponent(nextCategory.id)}" class="topic-nav-btn next-btn">
                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                    <polyline points="12 5 19 12 12 19"></polyline>
                </svg>
                <div class="nav-btn-text">
                    <span class="nav-btn-label">Next Category</span>
                    <span class="nav-btn-title">${escapeHtml(nextCategory.title)}</span>
                </div>
            </a>
        ` : `<div class="topic-nav-btn next-btn disabled"></div>`}
    `;

    return nav;
}

function renderErrorState(mainContainer, breadcrumbContainer, headerContainer, title, message, backUrl = "../index.html", backText = "Return to Speaking Dashboard") {
    if (headerContainer) {
        headerContainer.appendChild(createSpeakingHeader({
            title: "Speaking English",
            subtitle: title,
            showBack: true,
            backUrl: backUrl
        }));
    }

    if (breadcrumbContainer) {
        breadcrumbContainer.appendChild(createSpeakingBreadcrumb({
            category: { id: "", title: title },
            isSubpage: true
        }));
    }

    if (mainContainer) {
        mainContainer.innerHTML = `
            <div class="error-container">
                <h2 class="error-title">${escapeHtml(title)}</h2>
                <p>${escapeHtml(message)}</p>
                <a href="${backUrl}" class="btn btn-primary">${escapeHtml(backText)}</a>
            </div>
        `;
    }
}

function escapeHtml(str) {
    if (!str) return '';
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
