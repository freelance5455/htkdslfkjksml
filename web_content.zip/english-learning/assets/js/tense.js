/**
 * Generic Tense Detail Page Controller Module
 * Learner-Facing Simple Present Renderer (Step 3D & Step 3E Positive Sentences).
 * Consumes data directly from data/tenses/simple-present.js.
 */

import { getTenseById } from '../../data/tenses.js';
import { createPlatformHeader } from '../../components/platform-header.js';
import { createPlatformSidebar } from '../../components/platform-sidebar.js';
import { getSimplePresentLesson } from '../../data/tenses/simple-present.js';
import { getPresentContinuousLesson } from '../../data/tenses/present-continuous.js';
import { getPresentPerfectLesson } from '../../data/tenses/present-perfect.js';
import { getPresentPerfectContinuousLesson } from '../../data/tenses/present-perfect-continuous.js';
import { getSimplePastLesson } from '../../data/tenses/simple-past.js';
import { getPastContinuousLesson } from '../../data/tenses/past-continuous.js';
import { getPastPerfectLesson } from '../../data/tenses/past-perfect.js';
import { getPastPerfectContinuousLesson } from '../../data/tenses/past-perfect-continuous.js';
import { getSimpleFutureLesson } from '../../data/tenses/simple-future.js';
import { getFutureContinuousLesson } from '../../data/tenses/future-continuous.js';
import { getFuturePerfectLesson } from '../../data/tenses/future-perfect.js';
import { getFuturePerfectContinuousLesson } from '../../data/tenses/future-perfect-continuous.js';
import { initSimplePresentQuiz, initTenseQuiz } from './tense-quiz.js';
import { initTenseAccordion } from '../../components/tense-accordion.js';
import {
    recordTenseOpened,
    recordSectionViewed,
    isPracticeItemCompleted,
    togglePracticeItemCompleted,
    getTenseProgressStats
} from '../../services/tense-progress.js';

const ALL_SECTION_KEYS = [
    'identification',
    'uses',
    'structure',
    'subjectVerbRules',
    'positive',
    'negative',
    'interrogative',
    'whQuestions',
    'commonMistakes',
    'summary',
    'exercises'
];

document.addEventListener('DOMContentLoaded', () => {
    initTenseDetailPage();
});

function initTenseDetailPage() {
    const urlParams = new URLSearchParams(window.location.search);
    const tenseId = urlParams.get('id');

    const headerContainer = document.getElementById('header-container');
    const sidebarContainer = document.getElementById('sidebar-container');
    const mainContainer = document.getElementById('tense-detail-main-container');

    const tenseMeta = tenseId ? getTenseById(tenseId) : null;

    if (tenseId) {
        recordTenseOpened(tenseId);
    }

    // 1. Initialize Shared Platform Header
    if (headerContainer) {
        const headerEl = createPlatformHeader({
            title: "English Learning Platform",
            subtitle: tenseMeta ? `${tenseMeta.title} - ${tenseMeta.titleHindi}` : "Tense Detail",
            showSidebarToggle: true,
            basePath: "../",
            onMenuToggle: () => {
                const sidebarEl = document.querySelector('.platform-sidebar');
                if (sidebarEl) {
                    sidebarEl.classList.toggle('is-collapsed');
                }
            }
        });
        headerContainer.appendChild(headerEl);
    }

    // 2. Initialize Shared Platform Sidebar
    if (sidebarContainer) {
        const sidebarInstance = createPlatformSidebar({
            activeId: tenseId || "tenses",
            basePath: "../",
            collapsed: false
        });
        sidebarContainer.appendChild(sidebarInstance);
    }

    // 3. Render Detail View based on Tense ID
    if (mainContainer) {
        mainContainer.innerHTML = '';

        if (!tenseMeta) {
            renderInvalidTenseState(mainContainer, tenseId);
            return;
        }

        try {
            if (tenseId === 'simple-present') {
                renderSimplePresentDetail(mainContainer, tenseMeta);
            } else if (tenseId === 'present-continuous') {
                renderPresentContinuousDetail(mainContainer, tenseMeta);
            } else if (tenseId === 'present-perfect') {
                renderPresentPerfectDetail(mainContainer, tenseMeta);
            } else if (tenseId === 'present-perfect-continuous') {
                renderPresentPerfectContinuousDetail(mainContainer, tenseMeta);
            } else if (tenseId === 'simple-past') {
                renderSimplePastDetail(mainContainer, tenseMeta);
            } else if (tenseId === 'past-continuous') {
                renderPastContinuousDetail(mainContainer, tenseMeta);
            } else if (tenseId === 'past-perfect') {
                renderPastPerfectDetail(mainContainer, tenseMeta);
            } else if (tenseId === 'past-perfect-continuous') {
                renderPastPerfectContinuousDetail(mainContainer, tenseMeta);
            } else if (tenseId === 'simple-future') {
                renderSimpleFutureDetail(mainContainer, tenseMeta);
            } else if (tenseId === 'future-continuous') {
                renderFutureContinuousDetail(mainContainer, tenseMeta);
            } else if (tenseId === 'future-perfect') {
                renderFuturePerfectDetail(mainContainer, tenseMeta);
            } else if (tenseId === 'future-perfect-continuous') {
                renderFuturePerfectContinuousDetail(mainContainer, tenseMeta);
            } else {
                renderTenseComingSoonState(mainContainer, tenseMeta);
            }
        } catch (err) {
            console.error(`Error rendering tense detail page for '${tenseId}':`, err);
            renderTenseErrorState(mainContainer, tenseMeta, err);
        }
    }
}

function renderTenseErrorState(container, tenseMeta, error) {
    container.innerHTML = `
        <div class="tense-detail-layout">
            <section class="tense-section-card error-card" style="border-left: 4px solid #ef4444; padding: 2rem;">
                <div class="section-card-header">
                    <span class="section-card-icon" style="font-size: 2rem;">⚠️</span>
                    <div class="section-card-title-group">
                        <h3 class="section-card-title-en" style="color: #ef4444;">Unable to load ${escapeHtml(tenseMeta ? tenseMeta.title : 'Tense')}</h3>
                        <span class="section-card-title-hi">सामग्री लोड करने में समस्या आई</span>
                    </div>
                </div>
                <div class="section-card-body" style="margin-top: 1rem;">
                    <p style="color: var(--color-text-secondary, #64748b);">An unexpected error occurred while rendering this lesson. Other tenses remain fully accessible.</p>
                    <a href="tenses.html" class="btn btn-primary" style="display:inline-block; margin-top: 1.5rem; text-decoration: none;">← Back to Tenses List</a>
                </div>
            </section>
        </div>
    `;
}

/**
 * Render Learner-Facing Simple Present Tense Lesson with 12 Reusable Accordion Sections
 */
function renderSimplePresentDetail(container, tenseMeta) {
    document.title = `${tenseMeta.title} (${tenseMeta.titleHindi}) - English Tenses`;

    const lessonData = getSimplePresentLesson();
    const sections = lessonData.sections;

    const layout = document.createElement('div');
    layout.className = 'tense-detail-layout';

    // 1. Page Header Card (with Context Breadcrumb)
    const headerCard = createTenseDetailHeader(lessonData, tenseMeta);
    layout.appendChild(headerCard);

    const allPracticeItems = getAllSimplePresentPracticeItems(sections);
    const initialStats = getTenseProgressStats('simple-present', allPracticeItems, ALL_SECTION_KEYS);

    // 2. Progress Overview Card (Step 3M)
    const progressCard = renderProgressOverviewCard(layout, initialStats);
    if (progressCard && !progressCard.parentNode) {
        layout.appendChild(progressCard);
    }

    // Collect 12 Sections into sectionItems array for Accordion UI
    const sectionItems = [];

    // Section 1: Identification
    if (sections.identification) {
        sectionItems.push({
            key: 'identification',
            element: renderIdentificationSection(sections.identification)
        });
    }

    // Section 2: Uses & Scenarios
    if (sections.uses) {
        sectionItems.push({
            key: 'uses',
            element: renderUsesSection(sections.uses)
        });
    }

    // Section 3: Sentence Structure & Formulas
    if (sections.structure) {
        sectionItems.push({
            key: 'structure',
            element: renderStructureSection(sections.structure)
        });
    }

    // Section 4: Subject + Verb Rules
    if (sections.subjectVerbRules) {
        sectionItems.push({
            key: 'subjectVerbRules',
            element: renderSubjectVerbRulesSection(sections.subjectVerbRules)
        });
    }

    // Section 5: Positive / Affirmative Sentences
    if (sections.positive) {
        sectionItems.push({
            key: 'positive',
            element: renderPositiveSection(sections.positive)
        });
    }

    // Section 6: Negative Sentences
    if (sections.negative) {
        sectionItems.push({
            key: 'negative',
            element: renderNegativeSection(sections.negative)
        });
    }

    // Section 7: Interrogative Sentences
    if (sections.interrogative) {
        sectionItems.push({
            key: 'interrogative',
            element: renderInterrogativeSection(sections.interrogative)
        });
    }

    // Section 8: WH Questions
    if (sections.whQuestions) {
        sectionItems.push({
            key: 'whQuestions',
            element: renderWhQuestionsSection(sections.whQuestions)
        });
    }

    // Section 9: Common Mistakes & Corrections
    if (sections.commonMistakes) {
        sectionItems.push({
            key: 'commonMistakes',
            element: renderCommonMistakesSection(sections.commonMistakes)
        });
    }

    // Section 10: Summary & Revision
    if (sections.summary) {
        sectionItems.push({
            key: 'summary',
            element: renderSummarySection(sections.summary)
        });
    }

    // Section 11: Practice Exercises (120 Practice Sentences with completion toggles)
    if (sections.exercises) {
        sectionItems.push({
            key: 'exercises',
            element: renderExercisesSection(sections.exercises, sections)
        });
    }

    // Section 12: Simple Present Quiz
    const quizSection = document.createElement('section');
    quizSection.className = 'tense-section-card section-quiz';
    quizSection.id = 'simple-present-quiz';
    initSimplePresentQuiz(quizSection, lessonData);
    sectionItems.push({
        key: 'quiz',
        element: quizSection
    });

    // 3. Initialize Reusable Accordion UI Manager (Section 1 Open by Default, others Closed)
    initTenseAccordion(layout, sectionItems, {
        defaultOpenIndex: 0,
        onSectionOpen: (sectionKey) => {
            if (sectionKey && sectionKey !== 'quiz') {
                recordSectionViewed('simple-present', sectionKey);
                const updatedStats = getTenseProgressStats('simple-present', allPracticeItems, ALL_SECTION_KEYS);
                renderProgressOverviewCard(layout, updatedStats);
            }
        }
    });

    container.appendChild(layout);
}

/**
 * Render Learner-Facing Present Continuous Tense Lesson with 12 Reusable Accordion Sections
 */
function renderPresentContinuousDetail(container, tenseMeta) {
    document.title = `${tenseMeta.title} (${tenseMeta.titleHindi}) - English Tenses`;

    const lessonData = getPresentContinuousLesson();
    const sections = lessonData.sections;

    const layout = document.createElement('div');
    layout.className = 'tense-detail-layout';

    // 1. Page Header Card (with Context Breadcrumb)
    const headerCard = createTenseDetailHeader(lessonData, tenseMeta);
    layout.appendChild(headerCard);

    const allPracticeItems = getAllTensePracticeItems(sections);
    const initialStats = getTenseProgressStats('present-continuous', allPracticeItems, ALL_SECTION_KEYS);

    // 2. Progress Overview Card
    const progressCard = renderProgressOverviewCard(layout, initialStats);
    if (progressCard && !progressCard.parentNode) {
        layout.appendChild(progressCard);
    }

    // Collect 12 Sections into sectionItems array for Accordion UI
    const sectionItems = [];

    // Section 1: Identification
    if (sections.identification) {
        sectionItems.push({
            key: 'identification',
            element: renderIdentificationSection(sections.identification)
        });
    }

    // Section 2: Uses & Scenarios
    if (sections.uses) {
        sectionItems.push({
            key: 'uses',
            element: renderUsesSection(sections.uses)
        });
    }

    // Section 3: Sentence Structure & Formulas
    if (sections.structure) {
        sectionItems.push({
            key: 'structure',
            element: renderStructureSection(sections.structure)
        });
    }

    // Section 4: Subject + Verb Rules
    if (sections.subjectVerbRules) {
        sectionItems.push({
            key: 'subjectVerbRules',
            element: renderSubjectVerbRulesSection(sections.subjectVerbRules)
        });
    }

    // Section 5: Positive / Affirmative Sentences
    if (sections.positive) {
        sectionItems.push({
            key: 'positive',
            element: renderPositiveSection(sections.positive, 'present-continuous')
        });
    }

    // Section 6: Negative Sentences
    if (sections.negative) {
        sectionItems.push({
            key: 'negative',
            element: renderNegativeSection(sections.negative, 'present-continuous')
        });
    }

    // Section 7: Interrogative Sentences
    if (sections.interrogative) {
        sectionItems.push({
            key: 'interrogative',
            element: renderInterrogativeSection(sections.interrogative, 'present-continuous')
        });
    }

    // Section 8: WH Questions
    if (sections.whQuestions) {
        sectionItems.push({
            key: 'whQuestions',
            element: renderWhQuestionsSection(sections.whQuestions, 'present-continuous')
        });
    }

    // Section 9: Common Mistakes & Corrections
    if (sections.commonMistakes) {
        sectionItems.push({
            key: 'commonMistakes',
            element: renderCommonMistakesSection(sections.commonMistakes)
        });
    }

    // Section 10: Summary & Revision
    if (sections.summary) {
        sectionItems.push({
            key: 'summary',
            element: renderSummarySection(sections.summary)
        });
    }

    // Section 11: Practice Exercises (120 Practice Sentences)
    if (sections.exercises) {
        sectionItems.push({
            key: 'exercises',
            element: renderExercisesSection(sections.exercises, sections, 'present-continuous')
        });
    }

    // Section 12: Present Continuous Quiz
    const quizSection = document.createElement('section');
    quizSection.className = 'tense-section-card section-quiz';
    quizSection.id = 'present-continuous-quiz';
    initTenseQuiz(quizSection, lessonData);
    sectionItems.push({
        key: 'quiz',
        element: quizSection
    });

    // 3. Initialize Reusable Accordion UI Manager (Section 1 Open by Default, others Closed)
    initTenseAccordion(layout, sectionItems, {
        defaultOpenIndex: 0,
        onSectionOpen: (sectionKey) => {
            if (sectionKey && sectionKey !== 'quiz') {
                recordSectionViewed('present-continuous', sectionKey);
                const updatedStats = getTenseProgressStats('present-continuous', allPracticeItems, ALL_SECTION_KEYS);
                renderProgressOverviewCard(layout, updatedStats);
            }
        }
    });

    container.appendChild(layout);
}

/**
 * Render Learner-Facing Present Perfect Tense Lesson with 12 Reusable Accordion Sections
 */
function renderPresentPerfectDetail(container, tenseMeta) {
    document.title = `${tenseMeta.title} (${tenseMeta.titleHindi}) - English Tenses`;

    const lessonData = getPresentPerfectLesson();
    const sections = lessonData.sections;

    const layout = document.createElement('div');
    layout.className = 'tense-detail-layout';

    // 1. Page Header Card (with Context Breadcrumb)
    const headerCard = createTenseDetailHeader(lessonData, tenseMeta);
    layout.appendChild(headerCard);

    const allPracticeItems = getAllTensePracticeItems(sections);
    const initialStats = getTenseProgressStats('present-perfect', allPracticeItems, ALL_SECTION_KEYS);

    // 2. Progress Overview Card
    const progressCard = renderProgressOverviewCard(layout, initialStats);
    if (progressCard && !progressCard.parentNode) {
        layout.appendChild(progressCard);
    }

    // Collect 12 Sections into sectionItems array for Accordion UI
    const sectionItems = [];

    // Section 1: Identification
    if (sections.identification) {
        sectionItems.push({
            key: 'identification',
            element: renderIdentificationSection(sections.identification)
        });
    }

    // Section 2: Uses & Scenarios
    if (sections.uses) {
        sectionItems.push({
            key: 'uses',
            element: renderUsesSection(sections.uses)
        });
    }

    // Section 3: Sentence Structure & Formulas
    if (sections.structure) {
        sectionItems.push({
            key: 'structure',
            element: renderStructureSection(sections.structure)
        });
    }

    // Section 4: Subject + Verb Rules
    if (sections.subjectVerbRules) {
        sectionItems.push({
            key: 'subjectVerbRules',
            element: renderSubjectVerbRulesSection(sections.subjectVerbRules)
        });
    }

    // Section 5: Positive / Affirmative Sentences
    if (sections.positive) {
        sectionItems.push({
            key: 'positive',
            element: renderPositiveSection(sections.positive, 'present-perfect')
        });
    }

    // Section 6: Negative Sentences
    if (sections.negative) {
        sectionItems.push({
            key: 'negative',
            element: renderNegativeSection(sections.negative, 'present-perfect')
        });
    }

    // Section 7: Interrogative Sentences
    if (sections.interrogative) {
        sectionItems.push({
            key: 'interrogative',
            element: renderInterrogativeSection(sections.interrogative, 'present-perfect')
        });
    }

    // Section 8: WH Questions
    if (sections.whQuestions) {
        sectionItems.push({
            key: 'whQuestions',
            element: renderWhQuestionsSection(sections.whQuestions, 'present-perfect')
        });
    }

    // Section 9: Common Mistakes & Corrections
    if (sections.commonMistakes) {
        sectionItems.push({
            key: 'commonMistakes',
            element: renderCommonMistakesSection(sections.commonMistakes)
        });
    }

    // Section 10: Summary & Revision
    if (sections.summary) {
        sectionItems.push({
            key: 'summary',
            element: renderSummarySection(sections.summary)
        });
    }

    // Section 11: Practice Exercises (120 Practice Sentences)
    if (sections.exercises) {
        sectionItems.push({
            key: 'exercises',
            element: renderExercisesSection(sections.exercises, sections, 'present-perfect')
        });
    }

    // Section 12: Present Perfect Quiz
    const quizSection = document.createElement('section');
    quizSection.className = 'tense-section-card section-quiz';
    quizSection.id = 'present-perfect-quiz';
    initTenseQuiz(quizSection, lessonData);
    sectionItems.push({
        key: 'quiz',
        element: quizSection
    });

    // 3. Initialize Reusable Accordion UI Manager (Section 1 Open by Default, others Closed)
    initTenseAccordion(layout, sectionItems, {
        defaultOpenIndex: 0,
        onSectionOpen: (sectionKey) => {
            if (sectionKey && sectionKey !== 'quiz') {
                recordSectionViewed('present-perfect', sectionKey);
                const updatedStats = getTenseProgressStats('present-perfect', allPracticeItems, ALL_SECTION_KEYS);
                renderProgressOverviewCard(layout, updatedStats);
            }
        }
    });

    container.appendChild(layout);
}

/**
 * Render Learner-Facing Present Perfect Continuous Tense Lesson with 12 Reusable Accordion Sections
 */
function renderPresentPerfectContinuousDetail(container, tenseMeta) {
    document.title = `${tenseMeta.title} (${tenseMeta.titleHindi}) - English Tenses`;

    const lessonData = getPresentPerfectContinuousLesson();
    const sections = lessonData.sections;

    const layout = document.createElement('div');
    layout.className = 'tense-detail-layout';

    // 1. Page Header Card (with Context Breadcrumb)
    const headerCard = createTenseDetailHeader(lessonData, tenseMeta);
    layout.appendChild(headerCard);

    const allPracticeItems = getAllTensePracticeItems(sections);
    const initialStats = getTenseProgressStats('present-perfect-continuous', allPracticeItems, ALL_SECTION_KEYS);

    // 2. Progress Overview Card
    const progressCard = renderProgressOverviewCard(layout, initialStats);
    if (progressCard && !progressCard.parentNode) {
        layout.appendChild(progressCard);
    }

    // Collect 12 Sections into sectionItems array for Accordion UI
    const sectionItems = [];

    // Section 1: Identification
    if (sections.identification) {
        sectionItems.push({
            key: 'identification',
            element: renderIdentificationSection(sections.identification)
        });
    }

    // Section 2: Uses & Scenarios
    if (sections.uses) {
        sectionItems.push({
            key: 'uses',
            element: renderUsesSection(sections.uses)
        });
    }

    // Section 3: Sentence Structure & Formulas
    if (sections.structure) {
        sectionItems.push({
            key: 'structure',
            element: renderStructureSection(sections.structure)
        });
    }

    // Section 4: Subject + Verb Rules
    if (sections.subjectVerbRules) {
        sectionItems.push({
            key: 'subjectVerbRules',
            element: renderSubjectVerbRulesSection(sections.subjectVerbRules)
        });
    }

    // Section 5: Positive / Affirmative Sentences
    if (sections.positive) {
        sectionItems.push({
            key: 'positive',
            element: renderPositiveSection(sections.positive, 'present-perfect-continuous')
        });
    }

    // Section 6: Negative Sentences
    if (sections.negative) {
        sectionItems.push({
            key: 'negative',
            element: renderNegativeSection(sections.negative, 'present-perfect-continuous')
        });
    }

    // Section 7: Interrogative Sentences
    if (sections.interrogative) {
        sectionItems.push({
            key: 'interrogative',
            element: renderInterrogativeSection(sections.interrogative, 'present-perfect-continuous')
        });
    }

    // Section 8: WH Questions
    if (sections.whQuestions) {
        sectionItems.push({
            key: 'whQuestions',
            element: renderWhQuestionsSection(sections.whQuestions, 'present-perfect-continuous')
        });
    }

    // Section 9: Common Mistakes & Corrections
    if (sections.commonMistakes) {
        sectionItems.push({
            key: 'commonMistakes',
            element: renderCommonMistakesSection(sections.commonMistakes)
        });
    }

    // Section 10: Summary & Revision
    if (sections.summary) {
        sectionItems.push({
            key: 'summary',
            element: renderSummarySection(sections.summary)
        });
    }

    // Section 11: Practice Exercises (120 Practice Sentences)
    if (sections.exercises) {
        sectionItems.push({
            key: 'exercises',
            element: renderExercisesSection(sections.exercises, sections, 'present-perfect-continuous')
        });
    }

    // Section 12: Present Perfect Continuous Quiz
    const quizSection = document.createElement('section');
    quizSection.className = 'tense-section-card section-quiz';
    quizSection.id = 'present-perfect-continuous-quiz';
    initTenseQuiz(quizSection, lessonData);
    sectionItems.push({
        key: 'quiz',
        element: quizSection
    });

    // 3. Initialize Reusable Accordion UI Manager (Section 1 Open by Default, others Closed)
    initTenseAccordion(layout, sectionItems, {
        defaultOpenIndex: 0,
        onSectionOpen: (sectionKey) => {
            if (sectionKey && sectionKey !== 'quiz') {
                recordSectionViewed('present-perfect-continuous', sectionKey);
                const updatedStats = getTenseProgressStats('present-perfect-continuous', allPracticeItems, ALL_SECTION_KEYS);
                renderProgressOverviewCard(layout, updatedStats);
            }
        }
    });

    container.appendChild(layout);
}

/**
 * Render Learner-Facing Simple Past Tense Lesson with 12 Reusable Accordion Sections
 */
function renderSimplePastDetail(container, tenseMeta) {
    document.title = `${tenseMeta.title} (${tenseMeta.titleHindi}) - English Tenses`;

    const lessonData = getSimplePastLesson();
    const sections = lessonData.sections;

    const layout = document.createElement('div');
    layout.className = 'tense-detail-layout';

    // 1. Page Header Card (with Context Breadcrumb)
    const headerCard = createTenseDetailHeader(lessonData, tenseMeta);
    layout.appendChild(headerCard);

    const allPracticeItems = getAllTensePracticeItems(sections);
    const initialStats = getTenseProgressStats('simple-past', allPracticeItems, ALL_SECTION_KEYS);

    // 2. Progress Overview Card
    const progressCard = renderProgressOverviewCard(layout, initialStats);
    if (progressCard && !progressCard.parentNode) {
        layout.appendChild(progressCard);
    }

    // Collect 12 Sections into sectionItems array for Accordion UI
    const sectionItems = [];

    // Section 1: Identification
    if (sections.identification) {
        sectionItems.push({
            key: 'identification',
            element: renderIdentificationSection(sections.identification)
        });
    }

    // Section 2: Uses & Scenarios
    if (sections.uses) {
        sectionItems.push({
            key: 'uses',
            element: renderUsesSection(sections.uses)
        });
    }

    // Section 3: Sentence Structure & Formulas
    if (sections.structure) {
        sectionItems.push({
            key: 'structure',
            element: renderStructureSection(sections.structure)
        });
    }

    // Section 4: Subject + Verb Rules
    if (sections.subjectVerbRules) {
        sectionItems.push({
            key: 'subjectVerbRules',
            element: renderSubjectVerbRulesSection(sections.subjectVerbRules)
        });
    }

    // Section 5: Positive / Affirmative Sentences
    if (sections.positive) {
        sectionItems.push({
            key: 'positive',
            element: renderPositiveSection(sections.positive, 'simple-past')
        });
    }

    // Section 6: Negative Sentences
    if (sections.negative) {
        sectionItems.push({
            key: 'negative',
            element: renderNegativeSection(sections.negative, 'simple-past')
        });
    }

    // Section 7: Interrogative Sentences
    if (sections.interrogative) {
        sectionItems.push({
            key: 'interrogative',
            element: renderInterrogativeSection(sections.interrogative, 'simple-past')
        });
    }

    // Section 8: WH Questions
    if (sections.whQuestions) {
        sectionItems.push({
            key: 'whQuestions',
            element: renderWhQuestionsSection(sections.whQuestions, 'simple-past')
        });
    }

    // Section 9: Common Mistakes & Corrections
    if (sections.commonMistakes) {
        sectionItems.push({
            key: 'commonMistakes',
            element: renderCommonMistakesSection(sections.commonMistakes)
        });
    }

    // Section 10: Summary & Revision
    if (sections.summary) {
        sectionItems.push({
            key: 'summary',
            element: renderSummarySection(sections.summary)
        });
    }

    // Section 11: Practice Exercises (120 Practice Sentences)
    if (sections.exercises) {
        sectionItems.push({
            key: 'exercises',
            element: renderExercisesSection(sections.exercises, sections, 'simple-past')
        });
    }

    // Section 12: Simple Past Quiz
    const quizSection = document.createElement('section');
    quizSection.className = 'tense-section-card section-quiz';
    quizSection.id = 'simple-past-quiz';
    initTenseQuiz(quizSection, lessonData);
    sectionItems.push({
        key: 'quiz',
        element: quizSection
    });

    // 3. Initialize Reusable Accordion UI Manager (Section 1 Open by Default, others Closed)
    initTenseAccordion(layout, sectionItems, {
        defaultOpenIndex: 0,
        onSectionOpen: (sectionKey) => {
            if (sectionKey && sectionKey !== 'quiz') {
                recordSectionViewed('simple-past', sectionKey);
                const updatedStats = getTenseProgressStats('simple-past', allPracticeItems, ALL_SECTION_KEYS);
                renderProgressOverviewCard(layout, updatedStats);
            }
        }
    });

    container.appendChild(layout);
}

/**
 * Render Learner-Facing Past Continuous Tense Lesson with 12 Reusable Accordion Sections
 */
function renderPastContinuousDetail(container, tenseMeta) {
    document.title = `${tenseMeta.title} (${tenseMeta.titleHindi}) - English Tenses`;

    const lessonData = getPastContinuousLesson();
    const sections = lessonData.sections;

    const layout = document.createElement('div');
    layout.className = 'tense-detail-layout';

    // 1. Page Header Card (with Context Breadcrumb)
    const headerCard = createTenseDetailHeader(lessonData, tenseMeta);
    layout.appendChild(headerCard);

    const allPracticeItems = getAllTensePracticeItems(sections);
    const initialStats = getTenseProgressStats('past-continuous', allPracticeItems, ALL_SECTION_KEYS);

    // 2. Progress Overview Card
    const progressCard = renderProgressOverviewCard(layout, initialStats);
    if (progressCard && !progressCard.parentNode) {
        layout.appendChild(progressCard);
    }

    // Collect 12 Sections into sectionItems array for Accordion UI
    const sectionItems = [];

    // Section 1: Identification
    if (sections.identification) {
        sectionItems.push({
            key: 'identification',
            element: renderIdentificationSection(sections.identification)
        });
    }

    // Section 2: Uses & Scenarios
    if (sections.uses) {
        sectionItems.push({
            key: 'uses',
            element: renderUsesSection(sections.uses)
        });
    }

    // Section 3: Sentence Structure & Formulas
    if (sections.structure) {
        sectionItems.push({
            key: 'structure',
            element: renderStructureSection(sections.structure)
        });
    }

    // Section 4: Subject + Verb Rules
    if (sections.subjectVerbRules) {
        sectionItems.push({
            key: 'subjectVerbRules',
            element: renderSubjectVerbRulesSection(sections.subjectVerbRules)
        });
    }

    // Section 5: Positive / Affirmative Sentences
    if (sections.positive) {
        sectionItems.push({
            key: 'positive',
            element: renderPositiveSection(sections.positive, 'past-continuous')
        });
    }

    // Section 6: Negative Sentences
    if (sections.negative) {
        sectionItems.push({
            key: 'negative',
            element: renderNegativeSection(sections.negative, 'past-continuous')
        });
    }

    // Section 7: Interrogative Sentences
    if (sections.interrogative) {
        sectionItems.push({
            key: 'interrogative',
            element: renderInterrogativeSection(sections.interrogative, 'past-continuous')
        });
    }

    // Section 8: WH Questions
    if (sections.whQuestions) {
        sectionItems.push({
            key: 'whQuestions',
            element: renderWhQuestionsSection(sections.whQuestions, 'past-continuous')
        });
    }

    // Section 9: Common Mistakes & Corrections
    if (sections.commonMistakes) {
        sectionItems.push({
            key: 'commonMistakes',
            element: renderCommonMistakesSection(sections.commonMistakes)
        });
    }

    // Section 10: Summary & Revision
    if (sections.summary) {
        sectionItems.push({
            key: 'summary',
            element: renderSummarySection(sections.summary)
        });
    }

    // Section 11: Practice Exercises (120 Practice Sentences)
    if (sections.exercises) {
        sectionItems.push({
            key: 'exercises',
            element: renderExercisesSection(sections.exercises, sections, 'past-continuous')
        });
    }

    // Section 12: Past Continuous Quiz
    const quizSection = document.createElement('section');
    quizSection.className = 'tense-section-card section-quiz';
    quizSection.id = 'past-continuous-quiz';
    initTenseQuiz(quizSection, lessonData);
    sectionItems.push({
        key: 'quiz',
        element: quizSection
    });

    // 3. Initialize Reusable Accordion UI Manager (Section 1 Open by Default, others Closed)
    initTenseAccordion(layout, sectionItems, {
        defaultOpenIndex: 0,
        onSectionOpen: (sectionKey) => {
            if (sectionKey && sectionKey !== 'quiz') {
                recordSectionViewed('past-continuous', sectionKey);
                const updatedStats = getTenseProgressStats('past-continuous', allPracticeItems, ALL_SECTION_KEYS);
                renderProgressOverviewCard(layout, updatedStats);
            }
        }
    });

    container.appendChild(layout);
}

/**
 * Render Learner-Facing Past Perfect Tense Lesson with 12 Reusable Accordion Sections
 */
function renderPastPerfectDetail(container, tenseMeta) {
    document.title = `${tenseMeta.title} (${tenseMeta.titleHindi}) - English Tenses`;

    const lessonData = getPastPerfectLesson();
    const sections = lessonData.sections;

    const layout = document.createElement('div');
    layout.className = 'tense-detail-layout';

    // 1. Page Header Card (with Context Breadcrumb)
    const headerCard = createTenseDetailHeader(lessonData, tenseMeta);
    layout.appendChild(headerCard);

    const allPracticeItems = getAllTensePracticeItems(sections);
    const initialStats = getTenseProgressStats('past-perfect', allPracticeItems, ALL_SECTION_KEYS);

    // 2. Progress Overview Card
    const progressCard = renderProgressOverviewCard(layout, initialStats);
    if (progressCard && !progressCard.parentNode) {
        layout.appendChild(progressCard);
    }

    // Collect 12 Sections into sectionItems array for Accordion UI
    const sectionItems = [];

    // Section 1: Identification
    if (sections.identification) {
        sectionItems.push({
            key: 'identification',
            element: renderIdentificationSection(sections.identification)
        });
    }

    // Section 2: Uses & Scenarios
    if (sections.uses) {
        sectionItems.push({
            key: 'uses',
            element: renderUsesSection(sections.uses)
        });
    }

    // Section 3: Sentence Structure & Formulas
    if (sections.structure) {
        sectionItems.push({
            key: 'structure',
            element: renderStructureSection(sections.structure)
        });
    }

    // Section 4: Subject + Verb Rules
    if (sections.subjectVerbRules) {
        sectionItems.push({
            key: 'subjectVerbRules',
            element: renderSubjectVerbRulesSection(sections.subjectVerbRules)
        });
    }

    // Section 5: Positive / Affirmative Sentences
    if (sections.positive) {
        sectionItems.push({
            key: 'positive',
            element: renderPositiveSection(sections.positive, 'past-perfect')
        });
    }

    // Section 6: Negative Sentences
    if (sections.negative) {
        sectionItems.push({
            key: 'negative',
            element: renderNegativeSection(sections.negative, 'past-perfect')
        });
    }

    // Section 7: Interrogative Sentences
    if (sections.interrogative) {
        sectionItems.push({
            key: 'interrogative',
            element: renderInterrogativeSection(sections.interrogative, 'past-perfect')
        });
    }

    // Section 8: WH Questions
    if (sections.whQuestions) {
        sectionItems.push({
            key: 'whQuestions',
            element: renderWhQuestionsSection(sections.whQuestions, 'past-perfect')
        });
    }

    // Section 9: Common Mistakes & Corrections
    if (sections.commonMistakes) {
        sectionItems.push({
            key: 'commonMistakes',
            element: renderCommonMistakesSection(sections.commonMistakes)
        });
    }

    // Section 10: Summary & Revision
    if (sections.summary) {
        sectionItems.push({
            key: 'summary',
            element: renderSummarySection(sections.summary)
        });
    }

    // Section 11: Practice Exercises (120 Practice Sentences)
    if (sections.exercises) {
        sectionItems.push({
            key: 'exercises',
            element: renderExercisesSection(sections.exercises, sections, 'past-perfect')
        });
    }

    // Section 12: Past Perfect Quiz
    const quizSection = document.createElement('section');
    quizSection.className = 'tense-section-card section-quiz';
    quizSection.id = 'past-perfect-quiz';
    initTenseQuiz(quizSection, lessonData);
    sectionItems.push({
        key: 'quiz',
        element: quizSection
    });

    // 3. Initialize Reusable Accordion UI Manager (Section 1 Open by Default, others Closed)
    initTenseAccordion(layout, sectionItems, {
        defaultOpenIndex: 0,
        onSectionOpen: (sectionKey) => {
            if (sectionKey && sectionKey !== 'quiz') {
                recordSectionViewed('past-perfect', sectionKey);
                const updatedStats = getTenseProgressStats('past-perfect', allPracticeItems, ALL_SECTION_KEYS);
                renderProgressOverviewCard(layout, updatedStats);
            }
        }
    });

    container.appendChild(layout);
}

/**
 * Render Learner-Facing Past Perfect Continuous Tense Lesson with 12 Reusable Accordion Sections
 */
function renderPastPerfectContinuousDetail(container, tenseMeta) {
    document.title = `${tenseMeta.title} (${tenseMeta.titleHindi}) - English Tenses`;

    const lessonData = getPastPerfectContinuousLesson();
    const sections = lessonData.sections;

    const layout = document.createElement('div');
    layout.className = 'tense-detail-layout';

    // 1. Page Header Card (with Context Breadcrumb)
    const headerCard = createTenseDetailHeader(lessonData, tenseMeta);
    layout.appendChild(headerCard);

    const allPracticeItems = getAllTensePracticeItems(sections);
    const initialStats = getTenseProgressStats('past-perfect-continuous', allPracticeItems, ALL_SECTION_KEYS);

    // 2. Progress Overview Card
    const progressCard = renderProgressOverviewCard(layout, initialStats);
    if (progressCard && !progressCard.parentNode) {
        layout.appendChild(progressCard);
    }

    // Collect 12 Sections into sectionItems array for Accordion UI
    const sectionItems = [];

    // Section 1: Identification
    if (sections.identification) {
        sectionItems.push({
            key: 'identification',
            element: renderIdentificationSection(sections.identification)
        });
    }

    // Section 2: Uses & Scenarios
    if (sections.uses) {
        sectionItems.push({
            key: 'uses',
            element: renderUsesSection(sections.uses)
        });
    }

    // Section 3: Sentence Structure & Formulas
    if (sections.structure) {
        sectionItems.push({
            key: 'structure',
            element: renderStructureSection(sections.structure)
        });
    }

    // Section 4: Subject + Verb Rules
    if (sections.subjectVerbRules) {
        sectionItems.push({
            key: 'subjectVerbRules',
            element: renderSubjectVerbRulesSection(sections.subjectVerbRules)
        });
    }

    // Section 5: Positive / Affirmative Sentences
    if (sections.positive) {
        sectionItems.push({
            key: 'positive',
            element: renderPositiveSection(sections.positive, 'past-perfect-continuous')
        });
    }

    // Section 6: Negative Sentences
    if (sections.negative) {
        sectionItems.push({
            key: 'negative',
            element: renderNegativeSection(sections.negative, 'past-perfect-continuous')
        });
    }

    // Section 7: Interrogative Sentences
    if (sections.interrogative) {
        sectionItems.push({
            key: 'interrogative',
            element: renderInterrogativeSection(sections.interrogative, 'past-perfect-continuous')
        });
    }

    // Section 8: WH Questions
    if (sections.whQuestions) {
        sectionItems.push({
            key: 'whQuestions',
            element: renderWhQuestionsSection(sections.whQuestions, 'past-perfect-continuous')
        });
    }

    // Section 9: Common Mistakes & Corrections
    if (sections.commonMistakes) {
        sectionItems.push({
            key: 'commonMistakes',
            element: renderCommonMistakesSection(sections.commonMistakes)
        });
    }

    // Section 10: Summary & Revision
    if (sections.summary) {
        sectionItems.push({
            key: 'summary',
            element: renderSummarySection(sections.summary)
        });
    }

    // Section 11: Practice Exercises (120 Practice Sentences)
    if (sections.exercises) {
        sectionItems.push({
            key: 'exercises',
            element: renderExercisesSection(sections.exercises, sections, 'past-perfect-continuous')
        });
    }

    // Section 12: Past Perfect Continuous Quiz
    const quizSection = document.createElement('section');
    quizSection.className = 'tense-section-card section-quiz';
    quizSection.id = 'past-perfect-continuous-quiz';
    initTenseQuiz(quizSection, lessonData);
    sectionItems.push({
        key: 'quiz',
        element: quizSection
    });

    // 3. Initialize Reusable Accordion UI Manager (Section 1 Open by Default, others Closed)
    initTenseAccordion(layout, sectionItems, {
        defaultOpenIndex: 0,
        onSectionOpen: (sectionKey) => {
            if (sectionKey && sectionKey !== 'quiz') {
                recordSectionViewed('past-perfect-continuous', sectionKey);
                const updatedStats = getTenseProgressStats('past-perfect-continuous', allPracticeItems, ALL_SECTION_KEYS);
                renderProgressOverviewCard(layout, updatedStats);
            }
        }
    });

    container.appendChild(layout);
}

function renderSimpleFutureDetail(container, tenseMeta) {
    document.title = `${tenseMeta.title} (${tenseMeta.titleHindi}) - English Tenses`;

    const lessonData = getSimpleFutureLesson();
    const sections = lessonData.sections;

    const layout = document.createElement('div');
    layout.className = 'tense-detail-layout';

    // 1. Page Header Card (with Context Breadcrumb)
    const headerCard = createTenseDetailHeader(lessonData, tenseMeta);
    layout.appendChild(headerCard);

    const allPracticeItems = getAllTensePracticeItems(sections);
    const initialStats = getTenseProgressStats('simple-future', allPracticeItems, ALL_SECTION_KEYS);

    // 2. Progress Overview Card
    const progressCard = renderProgressOverviewCard(layout, initialStats);
    if (progressCard && !progressCard.parentNode) {
        layout.appendChild(progressCard);
    }

    // Collect 12 Sections into sectionItems array for Accordion UI
    const sectionItems = [];

    // Section 1: Identification
    if (sections.identification) {
        sectionItems.push({
            key: 'identification',
            element: renderIdentificationSection(sections.identification)
        });
    }

    // Section 2: Uses & Scenarios
    if (sections.uses) {
        sectionItems.push({
            key: 'uses',
            element: renderUsesSection(sections.uses)
        });
    }

    // Section 3: Structure & Formula Cards
    if (sections.structure) {
        sectionItems.push({
            key: 'structure',
            element: renderStructureSection(sections.structure)
        });
    }

    // Section 4: Subject + Verb Rules
    if (sections.subjectVerbRules) {
        sectionItems.push({
            key: 'subjectVerbRules',
            element: renderSubjectVerbRulesSection(sections.subjectVerbRules)
        });
    }

    // Section 5: Positive Sentences
    if (sections.positive) {
        sectionItems.push({
            key: 'positive',
            element: renderPositiveSection(sections.positive)
        });
    }

    // Section 6: Negative Sentences
    if (sections.negative) {
        sectionItems.push({
            key: 'negative',
            element: renderNegativeSection(sections.negative, 'simple-future')
        });
    }

    // Section 7: Interrogative Sentences
    if (sections.interrogative) {
        sectionItems.push({
            key: 'interrogative',
            element: renderInterrogativeSection(sections.interrogative)
        });
    }

    // Section 8: WH Questions
    if (sections.whQuestions) {
        sectionItems.push({
            key: 'whQuestions',
            element: renderWhQuestionsSection(sections.whQuestions)
        });
    }

    // Section 9: Common Mistakes & Corrections
    if (sections.commonMistakes) {
        sectionItems.push({
            key: 'commonMistakes',
            element: renderCommonMistakesSection(sections.commonMistakes)
        });
    }

    // Section 10: Summary & Revision
    if (sections.summary) {
        sectionItems.push({
            key: 'summary',
            element: renderSummarySection(sections.summary)
        });
    }

    // Section 11: Practice Exercises (120 Practice Sentences)
    if (sections.exercises) {
        sectionItems.push({
            key: 'exercises',
            element: renderExercisesSection(sections.exercises, sections, 'simple-future')
        });
    }

    // Section 12: Simple Future Quiz
    const quizSection = document.createElement('section');
    quizSection.className = 'tense-section-card section-quiz';
    quizSection.id = 'simple-future-quiz';
    initTenseQuiz(quizSection, lessonData);
    sectionItems.push({
        key: 'quiz',
        element: quizSection
    });

    // 3. Initialize Reusable Accordion UI Manager (Section 1 Open by Default, others Closed)
    initTenseAccordion(layout, sectionItems, {
        defaultOpenIndex: 0,
        onSectionOpen: (sectionKey) => {
            if (sectionKey && sectionKey !== 'quiz') {
                recordSectionViewed('simple-future', sectionKey);
                const updatedStats = getTenseProgressStats('simple-future', allPracticeItems, ALL_SECTION_KEYS);
                renderProgressOverviewCard(layout, updatedStats);
            }
        }
    });

    container.appendChild(layout);
}

function renderFutureContinuousDetail(container, tenseMeta) {
    document.title = `${tenseMeta.title} (${tenseMeta.titleHindi}) - English Tenses`;

    const lessonData = getFutureContinuousLesson();
    const sections = lessonData.sections;

    const layout = document.createElement('div');
    layout.className = 'tense-detail-layout';

    // 1. Page Header Card (with Context Breadcrumb)
    const headerCard = createTenseDetailHeader(lessonData, tenseMeta);
    layout.appendChild(headerCard);

    const allPracticeItems = getAllTensePracticeItems(sections);
    const initialStats = getTenseProgressStats('future-continuous', allPracticeItems, ALL_SECTION_KEYS);

    // 2. Progress Overview Card
    const progressCard = renderProgressOverviewCard(layout, initialStats);
    if (progressCard && !progressCard.parentNode) {
        layout.appendChild(progressCard);
    }

    // Collect 12 Sections into sectionItems array for Accordion UI
    const sectionItems = [];

    // Section 1: Identification
    if (sections.identification) {
        sectionItems.push({
            key: 'identification',
            element: renderIdentificationSection(sections.identification)
        });
    }

    // Section 2: Uses & Scenarios
    if (sections.uses) {
        sectionItems.push({
            key: 'uses',
            element: renderUsesSection(sections.uses)
        });
    }

    // Section 3: Structure & Formula Cards
    if (sections.structure) {
        sectionItems.push({
            key: 'structure',
            element: renderStructureSection(sections.structure)
        });
    }

    // Section 4: Subject + Verb Rules
    if (sections.subjectVerbRules) {
        sectionItems.push({
            key: 'subjectVerbRules',
            element: renderSubjectVerbRulesSection(sections.subjectVerbRules)
        });
    }

    // Section 5: Positive Sentences
    if (sections.positive) {
        sectionItems.push({
            key: 'positive',
            element: renderPositiveSection(sections.positive)
        });
    }

    // Section 6: Negative Sentences
    if (sections.negative) {
        sectionItems.push({
            key: 'negative',
            element: renderNegativeSection(sections.negative, 'future-continuous')
        });
    }

    // Section 7: Interrogative Sentences
    if (sections.interrogative) {
        sectionItems.push({
            key: 'interrogative',
            element: renderInterrogativeSection(sections.interrogative)
        });
    }

    // Section 8: WH Questions
    if (sections.whQuestions) {
        sectionItems.push({
            key: 'whQuestions',
            element: renderWhQuestionsSection(sections.whQuestions)
        });
    }

    // Section 9: Common Mistakes & Corrections
    if (sections.commonMistakes) {
        sectionItems.push({
            key: 'commonMistakes',
            element: renderCommonMistakesSection(sections.commonMistakes)
        });
    }

    // Section 10: Summary & Revision
    if (sections.summary) {
        sectionItems.push({
            key: 'summary',
            element: renderSummarySection(sections.summary)
        });
    }

    // Section 11: Practice Exercises (120 Practice Sentences)
    if (sections.exercises) {
        sectionItems.push({
            key: 'exercises',
            element: renderExercisesSection(sections.exercises, sections, 'future-continuous')
        });
    }

    // Section 12: Future Continuous Quiz
    const quizSection = document.createElement('section');
    quizSection.className = 'tense-section-card section-quiz';
    quizSection.id = 'future-continuous-quiz';
    initTenseQuiz(quizSection, lessonData);
    sectionItems.push({
        key: 'quiz',
        element: quizSection
    });

    // 3. Initialize Reusable Accordion UI Manager (Section 1 Open by Default, others Closed)
    initTenseAccordion(layout, sectionItems, {
        defaultOpenIndex: 0,
        onSectionOpen: (sectionKey) => {
            if (sectionKey && sectionKey !== 'quiz') {
                recordSectionViewed('future-continuous', sectionKey);
                const updatedStats = getTenseProgressStats('future-continuous', allPracticeItems, ALL_SECTION_KEYS);
                renderProgressOverviewCard(layout, updatedStats);
            }
        }
    });

    container.appendChild(layout);
}

function renderFuturePerfectDetail(container, tenseMeta) {
    document.title = `${tenseMeta.title} (${tenseMeta.titleHindi}) - English Tenses`;

    const lessonData = getFuturePerfectLesson();
    const sections = lessonData.sections;

    const layout = document.createElement('div');
    layout.className = 'tense-detail-layout';

    // 1. Page Header Card (with Context Breadcrumb)
    const headerCard = createTenseDetailHeader(lessonData, tenseMeta);
    layout.appendChild(headerCard);

    const allPracticeItems = getAllTensePracticeItems(sections);
    const initialStats = getTenseProgressStats('future-perfect', allPracticeItems, ALL_SECTION_KEYS);

    // 2. Progress Overview Card
    const progressCard = renderProgressOverviewCard(layout, initialStats);
    if (progressCard && !progressCard.parentNode) {
        layout.appendChild(progressCard);
    }

    // Collect 12 Sections into sectionItems array for Accordion UI
    const sectionItems = [];

    // Section 1: Identification
    if (sections.identification) {
        sectionItems.push({
            key: 'identification',
            element: renderIdentificationSection(sections.identification)
        });
    }

    // Section 2: Uses & Scenarios
    if (sections.uses) {
        sectionItems.push({
            key: 'uses',
            element: renderUsesSection(sections.uses)
        });
    }

    // Section 3: Structure & Formula Cards
    if (sections.structure) {
        sectionItems.push({
            key: 'structure',
            element: renderStructureSection(sections.structure)
        });
    }

    // Section 4: Subject + Verb Rules
    if (sections.subjectVerbRules) {
        sectionItems.push({
            key: 'subjectVerbRules',
            element: renderSubjectVerbRulesSection(sections.subjectVerbRules)
        });
    }

    // Section 5: Positive Sentences
    if (sections.positive) {
        sectionItems.push({
            key: 'positive',
            element: renderPositiveSection(sections.positive)
        });
    }

    // Section 6: Negative Sentences
    if (sections.negative) {
        sectionItems.push({
            key: 'negative',
            element: renderNegativeSection(sections.negative, 'future-perfect')
        });
    }

    // Section 7: Interrogative Sentences
    if (sections.interrogative) {
        sectionItems.push({
            key: 'interrogative',
            element: renderInterrogativeSection(sections.interrogative)
        });
    }

    // Section 8: WH Questions
    if (sections.whQuestions) {
        sectionItems.push({
            key: 'whQuestions',
            element: renderWhQuestionsSection(sections.whQuestions)
        });
    }

    // Section 9: Common Mistakes & Corrections
    if (sections.commonMistakes) {
        sectionItems.push({
            key: 'commonMistakes',
            element: renderCommonMistakesSection(sections.commonMistakes)
        });
    }

    // Section 10: Summary & Revision
    if (sections.summary) {
        sectionItems.push({
            key: 'summary',
            element: renderSummarySection(sections.summary)
        });
    }

    // Section 11: Practice Exercises (120 Practice Sentences)
    if (sections.exercises) {
        sectionItems.push({
            key: 'exercises',
            element: renderExercisesSection(sections.exercises, sections, 'future-perfect')
        });
    }

    // Section 12: Future Perfect Quiz
    const quizSection = document.createElement('section');
    quizSection.className = 'tense-section-card section-quiz';
    quizSection.id = 'future-perfect-quiz';
    initTenseQuiz(quizSection, lessonData);
    sectionItems.push({
        key: 'quiz',
        element: quizSection
    });

    // 3. Initialize Reusable Accordion UI Manager (Section 1 Open by Default, others Closed)
    initTenseAccordion(layout, sectionItems, {
        defaultOpenIndex: 0,
        onSectionOpen: (sectionKey) => {
            if (sectionKey && sectionKey !== 'quiz') {
                recordSectionViewed('future-perfect', sectionKey);
                const updatedStats = getTenseProgressStats('future-perfect', allPracticeItems, ALL_SECTION_KEYS);
                renderProgressOverviewCard(layout, updatedStats);
            }
        }
    });

    container.appendChild(layout);
}

function renderFuturePerfectContinuousDetail(container, tenseMeta) {
    document.title = `${tenseMeta.title} (${tenseMeta.titleHindi}) - English Tenses`;

    const lessonData = getFuturePerfectContinuousLesson();
    const sections = lessonData.sections;

    const layout = document.createElement('div');
    layout.className = 'tense-detail-layout';

    // 1. Page Header Card (with Context Breadcrumb)
    const headerCard = createTenseDetailHeader(lessonData, tenseMeta);
    layout.appendChild(headerCard);

    const allPracticeItems = getAllTensePracticeItems(sections);
    const initialStats = getTenseProgressStats('future-perfect-continuous', allPracticeItems, ALL_SECTION_KEYS);

    // 2. Progress Overview Card
    const progressCard = renderProgressOverviewCard(layout, initialStats);
    if (progressCard && !progressCard.parentNode) {
        layout.appendChild(progressCard);
    }

    // Collect 12 Sections into sectionItems array for Accordion UI
    const sectionItems = [];

    // Section 1: Identification
    if (sections.identification) {
        sectionItems.push({
            key: 'identification',
            element: renderIdentificationSection(sections.identification)
        });
    }

    // Section 2: Uses & Scenarios
    if (sections.uses) {
        sectionItems.push({
            key: 'uses',
            element: renderUsesSection(sections.uses)
        });
    }

    // Section 3: Structure & Formula Cards
    if (sections.structure) {
        sectionItems.push({
            key: 'structure',
            element: renderStructureSection(sections.structure)
        });
    }

    // Section 4: Subject + Verb Rules
    if (sections.subjectVerbRules) {
        sectionItems.push({
            key: 'subjectVerbRules',
            element: renderSubjectVerbRulesSection(sections.subjectVerbRules)
        });
    }

    // Section 5: Positive Sentences
    if (sections.positive) {
        sectionItems.push({
            key: 'positive',
            element: renderPositiveSection(sections.positive)
        });
    }

    // Section 6: Negative Sentences
    if (sections.negative) {
        sectionItems.push({
            key: 'negative',
            element: renderNegativeSection(sections.negative, 'future-perfect-continuous')
        });
    }

    // Section 7: Interrogative Sentences
    if (sections.interrogative) {
        sectionItems.push({
            key: 'interrogative',
            element: renderInterrogativeSection(sections.interrogative)
        });
    }

    // Section 8: WH Questions
    if (sections.whQuestions) {
        sectionItems.push({
            key: 'whQuestions',
            element: renderWhQuestionsSection(sections.whQuestions)
        });
    }

    // Section 9: Common Mistakes & Corrections
    if (sections.commonMistakes) {
        sectionItems.push({
            key: 'commonMistakes',
            element: renderCommonMistakesSection(sections.commonMistakes)
        });
    }

    // Section 10: Summary & Revision
    if (sections.summary) {
        sectionItems.push({
            key: 'summary',
            element: renderSummarySection(sections.summary)
        });
    }

    // Section 11: Practice Exercises (120 Practice Sentences)
    if (sections.exercises) {
        sectionItems.push({
            key: 'exercises',
            element: renderExercisesSection(sections.exercises, sections, 'future-perfect-continuous')
        });
    }

    // Section 12: Future Perfect Continuous Quiz
    const quizSection = document.createElement('section');
    quizSection.className = 'tense-section-card section-quiz';
    quizSection.id = 'future-perfect-continuous-quiz';
    initTenseQuiz(quizSection, lessonData);
    sectionItems.push({
        key: 'quiz',
        element: quizSection
    });

    // 3. Initialize Reusable Accordion UI Manager (Section 1 Open by Default, others Closed)
    initTenseAccordion(layout, sectionItems, {
        defaultOpenIndex: 0,
        onSectionOpen: (sectionKey) => {
            if (sectionKey && sectionKey !== 'quiz') {
                recordSectionViewed('future-perfect-continuous', sectionKey);
                const updatedStats = getTenseProgressStats('future-perfect-continuous', allPracticeItems, ALL_SECTION_KEYS);
                renderProgressOverviewCard(layout, updatedStats);
            }
        }
    });

    container.appendChild(layout);
}

/* -------------------------------------------------------------------------- */
/* Progress Tracking Helpers & Overview Card Renderer (Step 3M)               */
/* -------------------------------------------------------------------------- */

function getAllTensePracticeItems(sections) {
    const items = [];
    if (sections && sections.exercises && Array.isArray(sections.exercises.categories)) {
        sections.exercises.categories.forEach(cat => {
            const catId = cat.id;
            if (cat.sentences) {
                ['easy', 'medium', 'hard'].forEach(lvl => {
                    const list = cat.sentences[lvl] || [];
                    list.forEach(s => {
                        items.push({
                            fullId: `${catId}_${s.id}`,
                            id: s.id,
                            category: catId,
                            level: lvl
                        });
                    });
                });
            }
        });
    }
    return items;
}
const getAllSimplePresentPracticeItems = getAllTensePracticeItems;

function renderProgressOverviewCard(container, stats) {
    let card = container.querySelector('#tense-progress-overview-card');
    if (!card) {
        card = document.createElement('section');
        card.id = 'tense-progress-overview-card';
        card.className = 'tense-section-card tense-progress-overview-card';
    }

    const {
        totalSections,
        sectionsViewedCount,
        sectionsPercentage,
        totalItems,
        completedItemsCount,
        overallPercentage,
        difficultyStats,
        categoryStats,
        tenseId
    } = stats;

    const tenseTitleMap = {
        'simple-present': 'Simple Present',
        'present-continuous': 'Present Continuous',
        'present-perfect': 'Present Perfect',
        'present-perfect-continuous': 'Present Perfect Continuous',
        'simple-past': 'Simple Past',
        'past-continuous': 'Past Continuous',
        'past-perfect': 'Past Perfect',
        'past-perfect-continuous': 'Past Perfect Continuous',
        'simple-future': 'Simple Future',
        'future-continuous': 'Future Continuous',
        'future-perfect': 'Future Perfect',
        'future-perfect-continuous': 'Future Perfect Continuous'
    };
    const tenseTitle = tenseTitleMap[tenseId] || 'Tense';

    card.innerHTML = `
        <div class="section-card-header progress-card-header">
            <div class="progress-title-group">
                <span class="section-card-icon">📊</span>
                <div class="section-card-title-group">
                    <h3 class="section-card-title-en">${escapeHtml(tenseTitle)} Progress</h3>
                    <span class="section-card-title-hi">आपकी प्रगति (Progress Tracking)</span>
                </div>
            </div>
            <div class="progress-overall-badge">
                <span class="badge-percent">${overallPercentage}%</span>
                <span class="badge-sub">Practice Completed</span>
            </div>
        </div>

        <div class="section-card-body progress-card-body">
            <!-- Main Progress Metrics -->
            <div class="progress-main-metrics">
                <div class="metric-box">
                    <div class="metric-info">
                        <span class="metric-label">Practice Items Completed (अभ्यास प्रश्न)</span>
                        <span class="metric-value">${completedItemsCount} / ${totalItems} (${overallPercentage}%)</span>
                    </div>
                    <div class="progress-bar-track">
                        <div class="progress-bar-fill fill-primary" style="width: ${overallPercentage}%;"></div>
                    </div>
                </div>

                <div class="metric-box">
                    <div class="metric-info">
                        <span class="metric-label">Sections Viewed (पाठ अनुभाग)</span>
                        <span class="metric-value">${sectionsViewedCount} / ${totalSections} (${sectionsPercentage}%)</span>
                    </div>
                    <div class="progress-bar-track">
                        <div class="progress-bar-fill fill-info" style="width: ${sectionsPercentage}%;"></div>
                    </div>
                </div>
            </div>

            <!-- Difficulty Progress (Easy, Medium, Hard) -->
            <div class="progress-sub-section">
                <h4 class="progress-sub-title">Difficulty Progress (कठिनाई के अनुसार प्रगति)</h4>
                <div class="diff-progress-grid">
                    <div class="diff-progress-item diff-easy">
                        <div class="diff-item-top">
                            <span class="diff-tag badge-easy">EASY (10×4)</span>
                            <span class="diff-count">${difficultyStats.easy.completed} / ${difficultyStats.easy.total} (${difficultyStats.easy.percentage}%)</span>
                        </div>
                        <div class="progress-bar-track mini-track">
                            <div class="progress-bar-fill fill-easy" style="width: ${difficultyStats.easy.percentage}%;"></div>
                        </div>
                    </div>

                    <div class="diff-progress-item diff-medium">
                        <div class="diff-item-top">
                            <span class="diff-tag badge-medium">MEDIUM (10×4)</span>
                            <span class="diff-count">${difficultyStats.medium.completed} / ${difficultyStats.medium.total} (${difficultyStats.medium.percentage}%)</span>
                        </div>
                        <div class="progress-bar-track mini-track">
                            <div class="progress-bar-fill fill-medium" style="width: ${difficultyStats.medium.percentage}%;"></div>
                        </div>
                    </div>

                    <div class="diff-progress-item diff-hard">
                        <div class="diff-item-top">
                            <span class="diff-tag badge-hard">HARD (10×4)</span>
                            <span class="diff-count">${difficultyStats.hard.completed} / ${difficultyStats.hard.total} (${difficultyStats.hard.percentage}%)</span>
                        </div>
                        <div class="progress-bar-track mini-track">
                            <div class="progress-bar-fill fill-hard" style="width: ${difficultyStats.hard.percentage}%;"></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Category Progress -->
            <div class="progress-sub-section">
                <h4 class="progress-sub-title">Category Progress (श्रेणी के अनुसार प्रगति)</h4>
                <div class="cat-progress-grid">
                    <div class="cat-progress-item">
                        <span class="cat-label">Positive (30)</span>
                        <span class="cat-count">${categoryStats.positive.completed} / ${categoryStats.positive.total} (${categoryStats.positive.percentage}%)</span>
                    </div>
                    <div class="cat-progress-item">
                        <span class="cat-label">Negative (30)</span>
                        <span class="cat-count">${categoryStats.negative.completed} / ${categoryStats.negative.total} (${categoryStats.negative.percentage}%)</span>
                    </div>
                    <div class="cat-progress-item">
                        <span class="cat-label">Interrogative (30)</span>
                        <span class="cat-count">${categoryStats.interrogative.completed} / ${categoryStats.interrogative.total} (${categoryStats.interrogative.percentage}%)</span>
                    </div>
                    <div class="cat-progress-item">
                        <span class="cat-label">WH Questions (30)</span>
                        <span class="cat-count">${categoryStats.whQuestions.completed} / ${categoryStats.whQuestions.total} (${categoryStats.whQuestions.percentage}%)</span>
                    </div>
                </div>
            </div>
        </div>
    `;

    return card;
}

/* -------------------------------------------------------------------------- */
/* Learner-Facing Section Renderers                                           */
/* -------------------------------------------------------------------------- */

function createTenseDetailHeader(lessonData, tenseMeta) {
    const card = document.createElement('section');
    card.className = 'tense-detail-header-card';

    card.innerHTML = `
        <div class="tense-detail-nav-bar">
            <a href="tenses.html" class="btn-back-to-tenses">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="19" y1="12" x2="5" y2="12"></line>
                    <polyline points="12 19 5 12 12 5"></polyline>
                </svg>
                <span>Back to All Tenses</span>
            </a>

            <!-- Module Context Breadcrumb -->
            <div class="tense-breadcrumb-context">
                <span>Tenses</span>
                <span>→</span>
                <span>Present</span>
                <span>→</span>
                <span class="crumb-active">${escapeHtml(lessonData.title)}</span>
            </div>
        </div>

        <div class="tense-detail-title-group">
            <h2 class="tense-detail-main-title">${escapeHtml(lessonData.title)} Tense</h2>
            <span class="tense-detail-hindi-title">${escapeHtml(lessonData.titleHindi)}</span>
        </div>
    `;

    return card;
}

function renderIdentificationSection(data) {
    const section = document.createElement('section');
    section.className = 'tense-section-card';

    section.innerHTML = `
        <div class="section-card-header">
            <span class="section-card-icon">🔍</span>
            <div class="section-card-title-group">
                <h3 class="section-card-title-en">1. Identification</h3>
                <span class="section-card-title-hi">पहचान और अवधारणा</span>
            </div>
        </div>
        <div class="section-card-body">
            <p class="ident-overview-en">${escapeHtml(data.english)}</p>
            <p class="ident-overview-hi">💡 ${escapeHtml(data.hindi)}</p>

            ${data.hindiIdentityRule ? `
                <div class="ident-rule-pill-box">
                    <span class="rule-pill-icon">🔑</span>
                    <span class="rule-pill-text">${escapeHtml(data.hindiIdentityRule)}</span>
                </div>
            ` : ''}

            ${data.points && data.points.length > 0 ? `
                <div class="ident-points-grid">
                    ${data.points.map(pt => `
                        <div class="ident-point-card">
                            <span class="ident-point-en">🔹 ${escapeHtml(pt.english)}</span>
                            <span class="ident-point-hi">🔸 ${escapeHtml(pt.hindi)}</span>
                        </div>
                    `).join('')}
                </div>
            ` : ''}

            ${data.comparison ? `
                <div class="ident-comparison-card">
                    <h4 class="comparison-card-title">💡 ${escapeHtml(data.comparison.title)}</h4>
                    <div class="comparison-two-col">
                        ${Object.keys(data.comparison).filter(k => k !== 'title').map(key => {
                            const col = data.comparison[key];
                            if (!col) return '';
                            return `
                                <div class="comp-col comp-simple">
                                    <span class="comp-col-title">${escapeHtml(col.name || key)}</span>
                                    <code>${escapeHtml(col.formula || '')}</code>
                                    <p class="comp-desc">${escapeHtml(col.concept || '')}</p>
                                    <span class="comp-ex">💬 "${escapeHtml(col.example || '')}"</span>
                                </div>
                            `;
                        }).join('')}
                    </div>
                </div>
            ` : ''}
        </div>
    `;

    return section;
}

function renderUsesSection(usesData) {
    if (!usesData) return document.createElement('div');
    const usesList = Array.isArray(usesData) ? usesData : (usesData.list || []);

    const section = document.createElement('section');
    section.className = 'tense-section-card';

    section.innerHTML = `
        <div class="section-card-header">
            <span class="section-card-icon">📌</span>
            <div class="section-card-title-group">
                <h3 class="section-card-title-en">2. Uses & Scenarios</h3>
                <span class="section-card-title-hi">${escapeHtml(usesData.titleHindi || 'कब प्रयोग करें (5 मुख्य उपयोग)')}</span>
            </div>
        </div>
        <div class="section-card-body">
            ${usesData.introHindi || usesData.intro ? `
                <p class="ident-overview-en" style="margin-bottom: 0.25rem;">${escapeHtml(usesData.intro || '')}</p>
                <p class="ident-overview-hi" style="margin-bottom: 1.25rem;">💡 ${escapeHtml(usesData.introHindi || '')}</p>
            ` : ''}
            <div class="uses-cards-grid">
                ${usesList.map(use => `
                    <div class="use-card">
                        <div class="use-card-header">
                            <h4 class="use-title-en">${escapeHtml(use.title)}</h4>
                            <span class="use-title-hi">${escapeHtml(use.titleHindi)}</span>
                        </div>
                        <p class="use-desc-en">${escapeHtml(use.explanation)}</p>
                        <p class="use-desc-hi">${escapeHtml(use.explanationHindi)}</p>

                        ${use.whyUsedHindi || use.whyUsed ? `
                            <div class="use-why-box">
                                <span class="why-tag">💡 यह काल क्यों प्रयोग हुआ?</span>
                                <p class="why-text">${escapeHtml(use.whyUsedHindi || use.whyUsed)}</p>
                            </div>
                        ` : ''}

                        ${use.examples && use.examples.length > 0 ? `
                            <div class="use-multi-examples">
                                <span class="examples-label">💬 Examples (उदाहरण):</span>
                                ${use.examples.map(ex => `
                                    <div class="use-ex-item">
                                        <div class="ex-pair">
                                            <span class="ex-en">${escapeHtml(ex.english)}</span>
                                            <span class="ex-hi">${escapeHtml(ex.hindi)}</span>
                                        </div>
                                        ${ex.note ? `<span class="ex-note">📌 ${escapeHtml(ex.note)}</span>` : ''}
                                    </div>
                                `).join('')}
                            </div>
                        ` : (use.example ? `<span class="use-example-chip">💬 Example: "${escapeHtml(use.example)}"</span>` : '')}
                    </div>
                `).join('')}
            </div>
        </div>
    `;

    return section;
}

function renderStructureSection(structure) {
    const section = document.createElement('section');
    section.className = 'tense-section-card';

    let bodyContent = '';

    // 1. Simple Hindi Overview Banner if present
    if (structure.simpleHindiOverview) {
        bodyContent += `
            <div class="structure-overview-box">
                <span class="structure-overview-tag">💡 सरल हिंदी समझ (Concept)</span>
                <p class="structure-overview-text">${escapeHtml(structure.simpleHindiOverview)}</p>
                ${structure.mainFormula ? `<div class="structure-main-formula-chip">मुख्य सूत्र: <code>${escapeHtml(structure.mainFormula)}</code></div>` : ''}
            </div>
        `;
    }

    // 2. Auxiliary Verb Mapping Summary (I -> am, He/She/It -> is, You/We/They -> are)
    if (structure.auxiliaryMapping && structure.auxiliaryMapping.length > 0) {
        bodyContent += `
            <div class="structure-sub-block">
                <h4 class="structure-sub-title">1. Subject & Auxiliary Verb Mapping (कर्ता और सहायक क्रिया)</h4>
                <div class="aux-mapping-grid">
                    ${structure.auxiliaryMapping.map(item => `
                        <div class="aux-mapping-card">
                            <span class="aux-subject">${escapeHtml(item.subject)}</span>
                            <span class="aux-arrow">➔</span>
                            <span class="aux-verb-badge">${escapeHtml(item.aux)}</span>
                            <code class="aux-formula">${escapeHtml(item.formula)}</code>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    // 3. V4 Spelling Reminder if present
    if (structure.v4SpellingReminder && structure.v4SpellingReminder.length > 0) {
        bodyContent += `
            <div class="structure-sub-block">
                <h4 class="structure-sub-title">2. V4 (Verb + ing) Spelling Reminder (ing नियम)</h4>
                <div class="v4-reminder-grid">
                    ${structure.v4SpellingReminder.map(item => `
                        <div class="v4-reminder-card">
                            <div class="v4-pair">
                                <span class="v4-base">${escapeHtml(item.base)}</span>
                                <span class="v4-arrow">➔</span>
                                <span class="v4-ing">${escapeHtml(item.v4)}</span>
                            </div>
                            <span class="v4-rule-desc">${escapeHtml(item.rule)}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    // 4. Formula Blocks (Positive, Negative, Interrogative, WH Question)
    if (structure.formulaBlocks && structure.formulaBlocks.length > 0) {
        bodyContent += `
            <div class="structure-sub-block">
                <h4 class="structure-sub-title">3. Main Sentence Formulas & Examples (चारों सूत्र और उदाहरण)</h4>
                <div class="formula-rich-list">
                    ${structure.formulaBlocks.map(block => `
                        <div class="formula-rich-card">
                            <div class="formula-card-header">
                                <h4 class="formula-card-title">${escapeHtml(block.title)}</h4>
                                <code class="formula-code-highlight">${escapeHtml(block.formula)}</code>
                            </div>
                            <div class="formula-card-body">
                                <p class="formula-desc-en">${escapeHtml(block.englishExplanation)}</p>
                                <p class="formula-desc-hi">${escapeHtml(block.hindiExplanation)}</p>
                                
                                <div class="formula-examples-group">
                                    <span class="ex-group-title">💬 Examples & Element Breakdown (उदाहरण एवं वाक्य के अंग):</span>
                                    ${block.examples.map(ex => `
                                        <div class="formula-example-item">
                                            <div class="ex-sentence-pair">
                                                <span class="ex-sentence-en">"${escapeHtml(ex.english)}"</span>
                                                <span class="ex-sentence-hi">"${escapeHtml(ex.hindi)}"</span>
                                            </div>
                                            ${ex.breakdown ? `
                                                <div class="breakdown-pills-row">
                                                    ${ex.breakdown.wh ? `<span class="bd-pill bd-wh">WH: <strong>${escapeHtml(ex.breakdown.wh)}</strong></span>` : ''}
                                                    ${ex.breakdown.subject ? `<span class="bd-pill bd-sub">Subject: <strong>${escapeHtml(ex.breakdown.subject)}</strong></span>` : ''}
                                                    ${ex.breakdown.aux ? `<span class="bd-pill bd-aux">Aux Verb: <strong>${escapeHtml(ex.breakdown.aux)}</strong></span>` : ''}
                                                    ${ex.breakdown.not ? `<span class="bd-pill bd-not">Not: <strong>${escapeHtml(ex.breakdown.not)}</strong></span>` : ''}
                                                    ${ex.breakdown.mainVerb ? `<span class="bd-pill bd-verb">Main Verb: <strong>${escapeHtml(ex.breakdown.mainVerb)}</strong></span>` : ''}
                                                    ${ex.breakdown.object ? `<span class="bd-pill bd-obj">Object: <strong>${escapeHtml(ex.breakdown.object)}</strong></span>` : ''}
                                                </div>
                                            ` : ''}
                                        </div>
                                    `).join('')}
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    } else {
        // Fallback for simple structure (Simple Present)
        bodyContent += `
            <div class="structure-formulas-grid">
                <div class="formula-block">
                    <span class="formula-label">Positive / Affirmative (सकारात्मक)</span>
                    <code class="formula-code">${escapeHtml(structure.positive)}</code>
                </div>
                <div class="formula-block">
                    <span class="formula-label">Negative (नकारात्मक)</span>
                    <code class="formula-code">${escapeHtml(structure.negative)}</code>
                </div>
                <div class="formula-block">
                    <span class="formula-label">Interrogative (प्रश्नवाचक - Do/Does)</span>
                    <code class="formula-code">${escapeHtml(structure.interrogative)}</code>
                </div>
                <div class="formula-block">
                    <span class="formula-label">WH Questions (प्रश्नवाचक - WH शब्द)</span>
                    <code class="formula-code">${escapeHtml(structure.whQuestions)}</code>
                </div>
            </div>
        `;
    }

    section.innerHTML = `
        <div class="section-card-header">
            <span class="section-card-icon">📐</span>
            <div class="section-card-title-group">
                <h3 class="section-card-title-en">3. Sentence Structure & Formulas</h3>
                <span class="section-card-title-hi">वाक्य संरचना और सूत्र</span>
            </div>
        </div>
        <div class="section-card-body">
            ${bodyContent}
        </div>
    `;

    return section;
}

function renderSubjectVerbRulesSection(rules) {
    if (!rules) return document.createElement('div');

    const section = document.createElement('section');
    section.className = 'tense-section-card';

    let bodyContent = '';

    if (rules.auxiliaryMapping && Array.isArray(rules.auxiliaryMapping)) {
        // Present Continuous Schema
        bodyContent += `
            <div class="subject-rules-comparison">
                ${rules.auxiliaryMapping.map((group, idx) => `
                    <div class="rule-group-card ${idx === 0 ? 'rule-card-i' : (idx === 1 ? 'singular-rule-card' : 'plural-rule-card')}">
                        <div class="rule-card-header">
                            <h4 class="rule-group-title">${escapeHtml(group.subjectGroup)}</h4>
                        </div>
                        <div class="verb-rule-formula-box">
                            <span>Auxiliary Verb:</span>
                            <code>${escapeHtml(group.auxiliary)}</code>
                        </div>
                        <div class="verb-rule-formula-box">
                            <span>Formula:</span>
                            <code>${escapeHtml(group.formula)}</code>
                        </div>
                        <p class="rule-hindi-desc">💡 ${escapeHtml(group.hindiRule)}</p>
                    </div>
                `).join('')}
            </div>

            ${rules.v4Explanation ? `
                <div class="v4-explanation-container" style="margin-top: 1.5rem; background: rgba(59, 130, 246, 0.05); padding: 1.25rem; border-radius: 12px; border: 1px solid rgba(59, 130, 246, 0.15);">
                    <h4 class="v4-title" style="margin:0 0 0.5rem 0; color: var(--color-primary, #3b82f6); font-size: 1.1rem;">💡 ${escapeHtml(rules.v4Explanation.titleHindi || rules.v4Explanation.title)}</h4>
                    <p style="margin: 0 0 0.5rem 0;"><code>${escapeHtml(rules.v4Explanation.ruleText)}</code> — ${escapeHtml(rules.v4Explanation.explanationHindi)}</p>
                    <div class="v4-examples-chips" style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                        ${rules.v4Explanation.examples ? rules.v4Explanation.examples.map(ex => `
                            <span class="spelling-chip" style="background: rgba(255,255,255,0.08); padding: 4px 10px; border-radius: 6px; font-size: 0.9rem;">${escapeHtml(ex.base)} ➔ <strong>${escapeHtml(ex.v4)}</strong></span>
                        `).join('') : ''}
                    </div>
                </div>
            ` : ''}

            ${rules.spellingRulesIng && rules.spellingRulesIng.length > 0 ? `
                <div class="spelling-rules-container" style="margin-top: 1.5rem;">
                    <h4 class="spelling-rules-title">V4 (ing) Spelling Rules (वर्ब के साथ -ing लगाने के नियम):</h4>
                    <div class="spelling-rules-grid">
                        ${rules.spellingRulesIng.map(sr => `
                            <div class="spelling-rule-item">
                                <span class="spelling-condition">📌 ${escapeHtml(sr.condition)}</span>
                                <span class="spelling-action">➜ ${escapeHtml(sr.rule)}</span>
                                <span class="spelling-examples">${escapeHtml(sr.examples)}</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}
        `;
    } else {
        // Simple Present Schema
        const plural = rules.pluralGroup || { subjects: [], verbForm: '', hindiRule: '' };
        const singular = rules.singularGroup || { subjects: [], verbForm: '', hindiRule: '' };

        bodyContent += `
            <div class="subject-rules-comparison">
                <!-- Plural Group Card -->
                <div class="rule-group-card plural-rule-card">
                    <div class="rule-card-header">
                        <h4 class="rule-group-title">Group A: Plural Subjects</h4>
                    </div>
                    <div class="subjects-pills">
                        ${plural.subjects ? plural.subjects.map(s => `<span class="subject-pill">${escapeHtml(s)}</span>`).join('') : ''}
                    </div>
                    <div class="verb-rule-formula-box">
                        <span>Verb Form:</span>
                        <code>${escapeHtml(plural.verbForm)}</code>
                    </div>
                    <p class="rule-hindi-desc">💡 ${escapeHtml(plural.hindiRule)}</p>
                </div>

                <!-- Singular Group Card -->
                <div class="rule-group-card singular-rule-card">
                    <div class="rule-card-header">
                        <h4 class="rule-group-title">Group B: Singular Subjects</h4>
                    </div>
                    <div class="subjects-pills">
                        ${singular.subjects ? singular.subjects.map(s => `<span class="subject-pill">${escapeHtml(s)}</span>`).join('') : ''}
                    </div>
                    <div class="verb-rule-formula-box">
                        <span>Verb Form:</span>
                        <code>${escapeHtml(singular.verbForm)}</code>
                    </div>
                    <p class="rule-hindi-desc">💡 ${escapeHtml(singular.hindiRule)}</p>
                </div>
            </div>

            <!-- Spelling Rules Breakdown -->
            ${rules.spellingRules && rules.spellingRules.length > 0 ? `
                <div class="spelling-rules-container">
                    <h4 class="spelling-rules-title">Spelling Rules for adding -s / -es / -ies (Singular Subjects):</h4>
                    <div class="spelling-rules-grid">
                        ${rules.spellingRules.map(sr => `
                            <div class="spelling-rule-item">
                                <span class="spelling-condition">📌 ${escapeHtml(sr.condition)}</span>
                                <span class="spelling-action">➜ ${escapeHtml(sr.rule)}</span>
                                <span class="spelling-examples">${escapeHtml(sr.examples)}</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}
        `;
    }

    section.innerHTML = `
        <div class="section-card-header">
            <span class="section-card-icon">⚙️</span>
            <div class="section-card-title-group">
                <h3 class="section-card-title-en">4. Subject + Verb Rules</h3>
                <span class="section-card-title-hi">कर्ता और क्रिया के नियम</span>
            </div>
        </div>
        <div class="section-card-body">
            ${bodyContent}
        </div>
    `;

    return section;

    return section;
}

/**
 * Step 3E: Render Positive / Affirmative Sentences Section
 */
function renderPositiveSection(positiveData) {
    if (!positiveData) return document.createElement('div');

    const section = document.createElement('section');
    section.className = 'tense-section-card section-positive-sentences';

    section.innerHTML = `
        <div class="section-card-header">
            <span class="section-card-icon">✅</span>
            <div class="section-card-title-group">
                <h3 class="section-card-title-en">5. Positive / Affirmative Sentences</h3>
                <span class="section-card-title-hi">${escapeHtml(positiveData.titleHindi)}</span>
            </div>
        </div>
        <div class="section-card-body">
            <p class="ident-overview-en">${escapeHtml(positiveData.explanation)}</p>
            <p class="ident-overview-hi">💡 ${escapeHtml(positiveData.explanationHindi)}</p>

            <!-- Basic Rule Formulas -->
            <div class="positive-formulas-row">
                ${positiveData.formulaI ? `
                    <div class="positive-formula-box formula-i-theme">
                        <span class="formula-tag">Group 1 (I)</span>
                        <code>${escapeHtml(positiveData.formulaI)}</code>
                    </div>
                ` : ''}
                ${positiveData.formulaPlural ? `
                    <div class="positive-formula-box formula-plural-theme">
                        <span class="formula-tag">Group A (You / We / They)</span>
                        <code>${escapeHtml(positiveData.formulaPlural)}</code>
                    </div>
                ` : ''}
                ${positiveData.formulaSingular ? `
                    <div class="positive-formula-box formula-singular-theme">
                        <span class="formula-tag">Group B (He / She / It / Singular Name)</span>
                        <code>${escapeHtml(positiveData.formulaSingular)}</code>
                    </div>
                ` : ''}
            </div>

            <!-- Groups Sample Showcase -->
            ${positiveData.groups ? `
                <div class="positive-groups-showcase">
                    ${Object.values(positiveData.groups).map(grp => `
                        <div class="group-showcase-card">
                            <div class="group-showcase-header">
                                <h4 class="group-showcase-title">${escapeHtml(grp.name)}</h4>
                                <span class="group-showcase-rule">💡 ${escapeHtml(grp.ruleHindi || grp.rule)}</span>
                            </div>
                            <div class="group-sample-items">
                                ${grp.examples ? grp.examples.map(ex => `
                                    <div class="group-sample-item">
                                        <div class="sample-text-group">
                                            <span class="sample-en">${escapeHtml(ex.english)}</span>
                                            <span class="sample-hi">${escapeHtml(ex.hindi)}</span>
                                        </div>
                                        <span class="sample-verb-badge">${escapeHtml(ex.verb)}</span>
                                    </div>
                                `).join('') : ''}
                            </div>
                        </div>
                    `).join('')}
                </div>
            ` : ''}

            <!-- 30 Sentences Collection (Easy, Medium, Hard) -->
            ${positiveData.sentences ? `
                <div class="sentences-practice-block">
                    <div class="sentences-toolbar">
                        <h4 class="sentences-toolbar-title">Practice Sentences (30 Positive Sentences)</h4>
                        <div class="level-tabs-group" id="positive-level-tabs">
                            <button type="button" class="level-tab-btn tab-easy active" data-level="easy">Easy (10)</button>
                            <button type="button" class="level-tab-btn tab-medium" data-level="medium">Medium (10)</button>
                            <button type="button" class="level-tab-btn tab-hard" data-level="hard">Hard (10)</button>
                            <button type="button" class="level-tab-btn" data-level="all">All (30)</button>
                        </div>
                    </div>

                    <div class="sentences-cards-grid" id="positive-sentences-grid"></div>
                </div>
            ` : ''}
        </div>
    `;

    // Bind Level Tab Switching
    setTimeout(() => {
        const tabs = section.querySelectorAll('#positive-level-tabs .level-tab-btn');
        const gridContainer = section.querySelector('#positive-sentences-grid');

        if (tabs && gridContainer && positiveData.sentences) {
            // Initial render default: 'easy'
            renderPositiveSentencesCards(gridContainer, positiveData.sentences, 'easy');

            tabs.forEach(tab => {
                tab.addEventListener('click', (e) => {
                    const level = e.currentTarget.dataset.level;
                    tabs.forEach(t => t.classList.remove('active'));
                    e.currentTarget.classList.add('active');
                    renderPositiveSentencesCards(gridContainer, positiveData.sentences, level);
                });
            });
        }
    }, 0);

    return section;
}

function renderPositiveSentencesCards(container, sentencesObj, level) {
    container.innerHTML = '';
    let sentencesList = [];

    if (level === 'all') {
        sentencesList = [
            ...(sentencesObj.easy || []),
            ...(sentencesObj.medium || []),
            ...(sentencesObj.hard || [])
        ];
    } else {
        sentencesList = sentencesObj[level] || [];
    }

    sentencesList.forEach((s, idx) => {
        const card = document.createElement('div');
        card.className = 'sentence-item-card';

        const diffBadgeClass = getCardDifficulty(s, level, idx);
        const diffLabel = diffBadgeClass.toUpperCase();

        card.innerHTML = `
            <div class="sentence-card-top">
                <span class="sentence-index-tag">Sentence #${idx + 1}</span>
                <span class="diff-badge diff-${diffBadgeClass}">${diffLabel}</span>
            </div>
            <div class="sentence-text-content">
                <p class="sentence-en">${escapeHtml(s.english)}</p>
                <p class="sentence-hi">${escapeHtml(s.hindi)}</p>
            </div>
            <div class="sentence-meta-row">
                ${s.subject ? `<span class="sentence-subj-tag">Subject: ${escapeHtml(s.subject)}</span>` : ''}
                ${s.verb ? `<span class="sentence-verb-chip">Verb: ${escapeHtml(s.verb)}</span>` : ''}
            </div>
        `;

        container.appendChild(card);
    });
}

/**
 * Step 3F: Render Negative Sentences Section
 */
function renderNegativeSection(negativeData, tenseId = 'simple-present') {
    if (!negativeData) return document.createElement('div');

    const section = document.createElement('section');
    section.className = 'tense-section-card section-negative-sentences';

    section.innerHTML = `
        <div class="section-card-header">
            <span class="section-card-icon">❌</span>
            <div class="section-card-title-group">
                <h3 class="section-card-title-en">6. Negative Sentences</h3>
                <span class="section-card-title-hi">${escapeHtml(negativeData.titleHindi)}</span>
            </div>
        </div>
        <div class="section-card-body">
            <p class="ident-overview-en">${escapeHtml(negativeData.explanation)}</p>
            <p class="ident-overview-hi">💡 ${escapeHtml(negativeData.explanationHindi)}</p>

            <!-- Basic Rule Formulas & Contractions -->
            <div class="negative-formulas-row">
                ${negativeData.formula ? `
                    <div class="negative-formula-box formula-negative-plural-theme" style="width: 100%;">
                        <span class="formula-tag">All Subjects Formula (सभी कर्ताओं के लिए)</span>
                        <code>${escapeHtml(negativeData.formula)}</code>
                        <span class="contraction-chip">Contraction: <strong>${tenseId === 'future-perfect-continuous' ? "will not have been → won't have been" : (tenseId === 'future-perfect' ? "will not have → won't have" : (tenseId === 'future-continuous' ? "will not be → won't be" : (tenseId === 'simple-future' ? "will not → won't" : (tenseId === 'past-perfect-continuous' ? "had not been → hadn't been" : (tenseId === 'past-perfect' ? "had not → hadn't" : "did not → didn't")))))}</strong></span>
                    </div>
                ` : ''}
                ${negativeData.formulaI ? `
                    <div class="negative-formula-box formula-negative-plural-theme">
                        <span class="formula-tag">Group 1 (I)</span>
                        <code>${escapeHtml(negativeData.formulaI)}</code>
                        <span class="contraction-chip">Contraction: <strong>am not</strong></span>
                    </div>
                ` : ''}
                ${negativeData.formulaPlural ? `
                    <div class="negative-formula-box formula-negative-plural-theme">
                        <span class="formula-tag">Group A (You / We / They)</span>
                        <code>${escapeHtml(negativeData.formulaPlural)}</code>
                        <span class="contraction-chip">Contraction: <strong>${tenseId === 'past-continuous' ? "were not → weren't" : (tenseId === 'present-perfect-continuous' ? "have not been → haven't been" : (tenseId === 'present-perfect' ? "have not → haven't" : (negativeData.formulaI ? "are not → aren't" : "do not → don't")))}</strong></span>
                    </div>
                ` : ''}
                ${negativeData.formulaSingular ? `
                    <div class="negative-formula-box formula-negative-singular-theme">
                        <span class="formula-tag">Group B (He / She / It / Singular Name)</span>
                        <code>${escapeHtml(negativeData.formulaSingular)}</code>
                        <span class="contraction-chip">Contraction: <strong>${tenseId === 'past-continuous' ? "was not → wasn't" : (tenseId === 'present-perfect-continuous' ? "has not been → hasn't been" : (tenseId === 'present-perfect' ? "has not → hasn't" : (negativeData.formulaI ? "is not → isn't" : "does not → doesn't")))}</strong></span>
                    </div>
                ` : ''}
            </div>

            <!-- Groups Sample Showcase -->
            ${negativeData.groups ? `
                <div class="negative-groups-showcase">
                    ${Object.values(negativeData.groups).map(grp => `
                        <div class="group-showcase-card">
                            <div class="group-showcase-header">
                                <h4 class="group-showcase-title">${escapeHtml(grp.name)}</h4>
                                <span class="group-showcase-rule">💡 ${escapeHtml(grp.ruleHindi || grp.rule)}</span>
                            </div>
                            <div class="group-sample-items">
                                ${grp.examples ? grp.examples.map(ex => `
                                    <div class="group-sample-item">
                                        <div class="sample-text-group">
                                            <span class="sample-en">${escapeHtml(ex.english)}</span>
                                            <span class="sample-hi">${escapeHtml(ex.hindi)}</span>
                                        </div>
                                        <span class="sample-verb-badge negative-verb-badge">${escapeHtml(ex.verb)}</span>
                                    </div>
                                `).join('') : ''}
                            </div>
                        </div>
                    `).join('')}
                </div>
            ` : ''}

            <!-- CRITICAL RULE WARNING BOX -->
            ${negativeData.criticalRule ? `
                <div class="critical-rule-warning-box">
                    <div class="critical-rule-header">
                        <span class="rule-warning-icon">🚨</span>
                        <div class="rule-warning-titles">
                            <h4 class="rule-warning-en">${escapeHtml(negativeData.criticalRule.ruleTitle)}</h4>
                            <span class="rule-warning-hi">${escapeHtml(negativeData.criticalRule.ruleTitleHindi)}</span>
                        </div>
                    </div>
                    <p class="rule-warning-explanation-en">${escapeHtml(negativeData.criticalRule.explanation)}</p>
                    <p class="rule-warning-explanation-hi">💡 ${escapeHtml(negativeData.criticalRule.explanationHindi)}</p>
                    <div class="wrong-correct-comparison-grid">
                        ${negativeData.criticalRule.comparisonExamples.map(item => `
                            <div class="comparison-card">
                                <div class="wrong-row">
                                    <span class="status-icon">❌</span>
                                    <span class="wrong-sentence">${escapeHtml(item.wrong)}</span>
                                </div>
                                <div class="correct-row">
                                    <span class="status-icon">✅</span>
                                    <span class="correct-sentence">${escapeHtml(item.correct)}</span>
                                </div>
                                ${item.note ? `<span class="comparison-note">${escapeHtml(item.note)}</span>` : ''}
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}

            <!-- POSITIVE TO NEGATIVE TRANSFORMATION SHOWCASE -->
            ${negativeData.transformations ? `
                <div class="transformations-block">
                    <h4 class="transformations-title">Positive → Negative Transformations (सकारात्मक से नकारात्मक रूपांतरण)</h4>
                    <div class="transformations-grid">
                        ${negativeData.transformations.map(t => `
                            <div class="transformation-card">
                                <div class="trans-pos-row">
                                    <span class="trans-label">Positive:</span>
                                    <span class="trans-text">${escapeHtml(t.positive)}</span>
                                </div>
                                <div class="trans-arrow">↓</div>
                                <div class="trans-neg-row">
                                    <span class="trans-label">Negative:</span>
                                    <span class="trans-text-neg">${escapeHtml(t.negative)}</span>
                                </div>
                                ${t.note ? `<span class="trans-note">${escapeHtml(t.note)}</span>` : ''}
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}

            <!-- 30 Sentences Collection (Easy, Medium, Hard) -->
            ${negativeData.sentences ? `
                <div class="sentences-practice-block">
                    <div class="sentences-toolbar">
                        <h4 class="sentences-toolbar-title">Practice Sentences (30 Negative Sentences)</h4>
                        <div class="level-tabs-group" id="negative-level-tabs">
                            <button type="button" class="level-tab-btn tab-easy active" data-level="easy">Easy (10)</button>
                            <button type="button" class="level-tab-btn tab-medium" data-level="medium">Medium (10)</button>
                            <button type="button" class="level-tab-btn tab-hard" data-level="hard">Hard (10)</button>
                            <button type="button" class="level-tab-btn" data-level="all">All (30)</button>
                        </div>
                    </div>

                    <div class="sentences-cards-grid" id="negative-sentences-grid"></div>
                </div>
            ` : ''}
        </div>
    `;

    // Bind Level Tab Switching for Negative Sentences
    setTimeout(() => {
        const tabs = section.querySelectorAll('#negative-level-tabs .level-tab-btn');
        const gridContainer = section.querySelector('#negative-sentences-grid');

        if (tabs && gridContainer && negativeData.sentences) {
            renderNegativeSentencesCards(gridContainer, negativeData.sentences, 'easy');

            tabs.forEach(tab => {
                tab.addEventListener('click', (e) => {
                    const level = e.currentTarget.dataset.level;
                    tabs.forEach(t => t.classList.remove('active'));
                    e.currentTarget.classList.add('active');
                    renderNegativeSentencesCards(gridContainer, negativeData.sentences, level);
                });
            });
        }
    }, 0);

    return section;
}

function renderNegativeSentencesCards(container, sentencesObj, level) {
    container.innerHTML = '';
    let sentencesList = [];

    if (level === 'all') {
        sentencesList = [
            ...(sentencesObj.easy || []),
            ...(sentencesObj.medium || []),
            ...(sentencesObj.hard || [])
        ];
    } else {
        sentencesList = sentencesObj[level] || [];
    }

    sentencesList.forEach((s, idx) => {
        const card = document.createElement('div');
        card.className = 'sentence-item-card negative-item-card';

        const diffBadgeClass = getCardDifficulty(s, level, idx);
        const diffLabel = diffBadgeClass.toUpperCase();

        card.innerHTML = `
            <div class="sentence-card-top">
                <span class="sentence-index-tag">Sentence #${idx + 1}</span>
                <span class="diff-badge diff-${diffBadgeClass}">${diffLabel}</span>
            </div>
            <div class="sentence-text-content">
                <p class="sentence-en">${escapeHtml(s.english)}</p>
                <p class="sentence-hi">${escapeHtml(s.hindi)}</p>
            </div>
            <div class="sentence-meta-row">
                ${s.subject ? `<span class="sentence-subj-tag">Subject: ${escapeHtml(s.subject)}</span>` : ''}
                ${s.verb ? `<span class="sentence-verb-chip negative-verb-chip">Verb: ${escapeHtml(s.verb)}</span>` : ''}
            </div>
        `;

        container.appendChild(card);
    });
}

/**
 * Step 3G: Render Interrogative Sentences Section
 */
function renderInterrogativeSection(interrogativeData) {
    if (!interrogativeData) return document.createElement('div');

    const section = document.createElement('section');
    section.className = 'tense-section-card section-interrogative-sentences';

    section.innerHTML = `
        <div class="section-card-header">
            <span class="section-card-icon">❓</span>
            <div class="section-card-title-group">
                <h3 class="section-card-title-en">7. Interrogative Sentences</h3>
                <span class="section-card-title-hi">${escapeHtml(interrogativeData.titleHindi)}</span>
            </div>
        </div>
        <div class="section-card-body">
            <p class="ident-overview-en">${escapeHtml(interrogativeData.explanation)}</p>
            <p class="ident-overview-hi">💡 ${escapeHtml(interrogativeData.explanationHindi)}</p>

            <!-- Basic Rule Formulas -->
            <div class="interrogative-formulas-row">
                ${interrogativeData.formulaI ? `
                    <div class="interrogative-formula-box formula-interrogative-plural-theme">
                        <span class="formula-tag">Group 1 (I)</span>
                        <code>${escapeHtml(interrogativeData.formulaI)}</code>
                    </div>
                ` : ''}
                ${interrogativeData.formulaPlural ? `
                    <div class="interrogative-formula-box formula-interrogative-plural-theme">
                        <span class="formula-tag">Group A (You / We / They)</span>
                        <code>${escapeHtml(interrogativeData.formulaPlural)}</code>
                    </div>
                ` : ''}
                ${interrogativeData.formulaSingular ? `
                    <div class="interrogative-formula-box formula-interrogative-singular-theme">
                        <span class="formula-tag">Group B (He / She / It / Singular Name)</span>
                        <code>${escapeHtml(interrogativeData.formulaSingular)}</code>
                    </div>
                ` : ''}
            </div>

            <!-- Groups Sample Showcase -->
            ${interrogativeData.groups ? `
                <div class="interrogative-groups-showcase">
                    ${Object.values(interrogativeData.groups).map(grp => `
                        <div class="group-showcase-card">
                            <div class="group-showcase-header">
                                <h4 class="group-showcase-title">${escapeHtml(grp.name)}</h4>
                                <span class="group-showcase-rule">💡 ${escapeHtml(grp.ruleHindi || grp.rule)}</span>
                            </div>
                            <div class="group-sample-items">
                                ${grp.examples ? grp.examples.map(ex => `
                                    <div class="group-sample-item">
                                        <div class="sample-text-group">
                                            <span class="sample-en">${escapeHtml(ex.english)}</span>
                                            <span class="sample-hi">${escapeHtml(ex.hindi)}</span>
                                        </div>
                                        <span class="sample-verb-badge interrogative-verb-badge">${escapeHtml(ex.verb)}</span>
                                    </div>
                                `).join('') : ''}
                            </div>
                        </div>
                    `).join('')}
                </div>
            ` : ''}

            <!-- CRITICAL RULE WARNING BOX -->
            ${interrogativeData.criticalRule ? `
                <div class="critical-rule-warning-box interrogative-warning-theme">
                    <div class="critical-rule-header">
                        <span class="rule-warning-icon">🚨</span>
                        <div class="rule-warning-titles">
                            <h4 class="rule-warning-en">${escapeHtml(interrogativeData.criticalRule.ruleTitle)}</h4>
                            <span class="rule-warning-hi">${escapeHtml(interrogativeData.criticalRule.ruleTitleHindi)}</span>
                        </div>
                    </div>
                    <p class="rule-warning-explanation-en">${escapeHtml(interrogativeData.criticalRule.explanation)}</p>
                    <p class="rule-warning-explanation-hi">💡 ${escapeHtml(interrogativeData.criticalRule.explanationHindi)}</p>
                    <div class="wrong-correct-comparison-grid">
                        ${interrogativeData.criticalRule.comparisonExamples.map(item => `
                            <div class="comparison-card">
                                <div class="wrong-row">
                                    <span class="status-icon">❌</span>
                                    <span class="wrong-sentence">${escapeHtml(item.wrong)}</span>
                                </div>
                                <div class="correct-row">
                                    <span class="status-icon">✅</span>
                                    <span class="correct-sentence">${escapeHtml(item.correct)}</span>
                                </div>
                                ${item.note ? `<span class="comparison-note">${escapeHtml(item.note)}</span>` : ''}
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}

            <!-- POSITIVE TO INTERROGATIVE TRANSFORMATION SHOWCASE -->
            ${interrogativeData.transformations ? `
                <div class="transformations-block">
                    <h4 class="transformations-title">Positive → Interrogative Transformations (सकारात्मक से प्रश्नवाचक)</h4>
                    <div class="transformations-grid">
                        ${interrogativeData.transformations.map(t => `
                            <div class="transformation-card">
                                <div class="trans-pos-row">
                                    <span class="trans-label">Positive:</span>
                                    <span class="trans-text">${escapeHtml(t.positive)}</span>
                                </div>
                                <div class="trans-arrow">↓</div>
                                <div class="trans-neg-row">
                                    <span class="trans-label">Question:</span>
                                    <span class="trans-text-neg interrogative-text-highlight">${escapeHtml(t.interrogative)}</span>
                                </div>
                                ${t.note ? `<span class="trans-note">${escapeHtml(t.note)}</span>` : ''}
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}

            <!-- SHORT ANSWERS FOUNDATION BLOCK -->
            ${interrogativeData.shortAnswers ? `
                <div class="short-answers-block">
                    <h4 class="short-answers-title">Basic Short Answers Concept (संक्षिप्त उत्तर)</h4>
                    <div class="short-answers-grid">
                        ${interrogativeData.shortAnswers.map(sa => `
                            <div class="short-answer-card">
                                <div class="short-q-group">
                                    <span class="short-q-en">❓ ${escapeHtml(sa.question)}</span>
                                    <span class="short-q-hi">${escapeHtml(sa.questionHindi)}</span>
                                </div>
                                <div class="short-answers-row">
                                    <span class="ans-badge ans-yes">✅ ${escapeHtml(sa.yesAnswer)}</span>
                                    <span class="ans-badge ans-no">❌ ${escapeHtml(sa.noAnswer)}</span>
                                </div>
                                <span class="short-ans-note">💡 ${escapeHtml(sa.noteHindi)}</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}

            <!-- 30 Sentences Collection (Easy, Medium, Hard) -->
            ${interrogativeData.sentences ? `
                <div class="sentences-practice-block">
                    <div class="sentences-toolbar">
                        <h4 class="sentences-toolbar-title">Practice Questions (30 Interrogative Sentences)</h4>
                        <div class="level-tabs-group" id="interrogative-level-tabs">
                            <button type="button" class="level-tab-btn tab-easy active" data-level="easy">Easy (10)</button>
                            <button type="button" class="level-tab-btn tab-medium" data-level="medium">Medium (10)</button>
                            <button type="button" class="level-tab-btn tab-hard" data-level="hard">Hard (10)</button>
                            <button type="button" class="level-tab-btn" data-level="all">All (30)</button>
                        </div>
                    </div>

                    <div class="sentences-cards-grid" id="interrogative-sentences-grid"></div>
                </div>
            ` : ''}
        </div>
    `;

    // Bind Level Tab Switching for Interrogative Sentences
    setTimeout(() => {
        const tabs = section.querySelectorAll('#interrogative-level-tabs .level-tab-btn');
        const gridContainer = section.querySelector('#interrogative-sentences-grid');

        if (tabs && gridContainer && interrogativeData.sentences) {
            renderInterrogativeSentencesCards(gridContainer, interrogativeData.sentences, 'easy');

            tabs.forEach(tab => {
                tab.addEventListener('click', (e) => {
                    const level = e.currentTarget.dataset.level;
                    tabs.forEach(t => t.classList.remove('active'));
                    e.currentTarget.classList.add('active');
                    renderInterrogativeSentencesCards(gridContainer, interrogativeData.sentences, level);
                });
            });
        }
    }, 0);

    return section;
}

function renderInterrogativeSentencesCards(container, sentencesObj, level) {
    container.innerHTML = '';
    let sentencesList = [];

    if (level === 'all') {
        sentencesList = [
            ...(sentencesObj.easy || []),
            ...(sentencesObj.medium || []),
            ...(sentencesObj.hard || [])
        ];
    } else {
        sentencesList = sentencesObj[level] || [];
    }

    sentencesList.forEach((s, idx) => {
        const card = document.createElement('div');
        card.className = 'sentence-item-card interrogative-item-card';

        const diffBadgeClass = getCardDifficulty(s, level, idx);
        const diffLabel = diffBadgeClass.toUpperCase();

        card.innerHTML = `
            <div class="sentence-card-top">
                <span class="sentence-index-tag">Question #${idx + 1}</span>
                <span class="diff-badge diff-${diffBadgeClass}">${diffLabel}</span>
            </div>
            <div class="sentence-text-content">
                <p class="sentence-en">${escapeHtml(s.english)}</p>
                <p class="sentence-hi">${escapeHtml(s.hindi)}</p>
            </div>
            <div class="sentence-meta-row">
                ${s.subject ? `<span class="sentence-subj-tag">Subject: ${escapeHtml(s.subject)}</span>` : ''}
                ${s.verb ? `<span class="sentence-verb-chip interrogative-verb-chip">Verb: ${escapeHtml(s.verb)}</span>` : ''}
            </div>
        `;

        container.appendChild(card);
    });
}

/**
 * Step 3H: Render WH Questions Section
 */
function renderWhQuestionsSection(whData) {
    if (!whData) return document.createElement('div');

    const section = document.createElement('section');
    section.className = 'tense-section-card section-wh-questions';

    section.innerHTML = `
        <div class="section-card-header">
            <span class="section-card-icon">🌐</span>
            <div class="section-card-title-group">
                <h3 class="section-card-title-en">8. WH Questions</h3>
                <span class="section-card-title-hi">${escapeHtml(whData.titleHindi)}</span>
            </div>
        </div>
        <div class="section-card-body">
            <p class="ident-overview-en">${escapeHtml(whData.explanation)}</p>
            <p class="ident-overview-hi">💡 ${escapeHtml(whData.explanationHindi)}</p>

            <!-- Basic Rule Formulas -->
            <div class="wh-formulas-row">
                ${whData.formulaI ? `
                    <div class="wh-formula-box formula-wh-plural-theme">
                        <span class="formula-tag">Group 1 (I)</span>
                        <code>${escapeHtml(whData.formulaI)}</code>
                    </div>
                ` : ''}
                ${whData.formulaPlural ? `
                    <div class="wh-formula-box formula-wh-plural-theme">
                        <span class="formula-tag">Group A (You / We / They)</span>
                        <code>${escapeHtml(whData.formulaPlural)}</code>
                    </div>
                ` : ''}
                ${whData.formulaSingular ? `
                    <div class="wh-formula-box formula-wh-singular-theme">
                        <span class="formula-tag">Group B (He / She / It / Singular Name)</span>
                        <code>${escapeHtml(whData.formulaSingular)}</code>
                    </div>
                ` : ''}
            </div>

            <!-- WH Word-by-Word Guide -->
            ${whData.wordGuide ? `
                <div class="wh-word-guide-block">
                    <h4 class="wh-guide-title">WH Words Reference Guide (मुख्य WH शब्द तालिका)</h4>
                    <div class="wh-word-grid">
                        ${whData.wordGuide.map(wg => `
                            <div class="wh-word-card">
                                <div class="wh-word-header">
                                    <span class="wh-word-badge">${escapeHtml(wg.word)}</span>
                                    <span class="wh-word-hindi">${escapeHtml(wg.hindi)}</span>
                                </div>
                                <p class="wh-word-meaning">💡 ${escapeHtml(wg.meaningHindi)}</p>
                                ${wg.examples && Array.isArray(wg.examples) ? `
                                    <div class="wh-word-examples">
                                        ${wg.examples.map(ex => `
                                            <div class="wh-ex-item">
                                                <span class="wh-ex-en">🔹 ${escapeHtml(ex.english)}</span>
                                                <span class="wh-ex-hi">🔸 ${escapeHtml(ex.hindi)}</span>
                                            </div>
                                        `).join('')}
                                    </div>
                                ` : (wg.usage ? `<div class="wh-word-examples"><span class="wh-ex-en" style="font-size:0.9rem; color:var(--text-secondary,#94a3b8);">💬 Example: ${escapeHtml(wg.usage)}</span></div>` : '')}
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}

            <!-- Special Note: Who as Subject Introduction -->
            ${whData.whoAsSubjectNote ? `
                <div class="who-subject-note-card">
                    <div class="who-note-header">
                        <span class="who-icon">💡</span>
                        <h4 class="who-title">${escapeHtml(whData.whoAsSubjectNote.titleHindi)}</h4>
                    </div>
                    <p class="who-desc-en">${escapeHtml(whData.whoAsSubjectNote.explanation)}</p>
                    <p class="who-desc-hi">💡 ${escapeHtml(whData.whoAsSubjectNote.explanationHindi)}</p>
                    <div class="who-comparison-row">
                        ${whData.whoAsSubjectNote.examples.map(ex => `
                            <div class="who-comp-item">
                                <span class="who-comp-label">Object Question (Do/Does uses):</span>
                                <span class="who-comp-en">${escapeHtml(ex.objectWh)}</span>
                                <span class="who-comp-hi">${escapeHtml(ex.objectWhHindi)}</span>
                            </div>
                            <div class="who-comp-item">
                                <span class="who-comp-label">Subject Question (Direct V1+s/es):</span>
                                <span class="who-comp-en">${escapeHtml(ex.subjectWh)}</span>
                                <span class="who-comp-hi">${escapeHtml(ex.subjectWhHindi)}</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}

            <!-- CRITICAL RULE WARNING BOX -->
            ${whData.criticalRule ? `
                <div class="critical-rule-warning-box wh-warning-theme">
                    <div class="critical-rule-header">
                        <span class="rule-warning-icon">🚨</span>
                        <div class="rule-warning-titles">
                            <h4 class="rule-warning-en">${escapeHtml(whData.criticalRule.ruleTitle)}</h4>
                            <span class="rule-warning-hi">${escapeHtml(whData.criticalRule.ruleTitleHindi)}</span>
                        </div>
                    </div>
                    <p class="rule-warning-explanation-en">${escapeHtml(whData.criticalRule.explanation)}</p>
                    <p class="rule-warning-explanation-hi">💡 ${escapeHtml(whData.criticalRule.explanationHindi)}</p>
                    <div class="wrong-correct-comparison-grid">
                        ${whData.criticalRule.comparisonExamples.map(item => `
                            <div class="comparison-card">
                                <div class="wrong-row">
                                    <span class="status-icon">❌</span>
                                    <span class="wrong-sentence">${escapeHtml(item.wrong)}</span>
                                </div>
                                <div class="correct-row">
                                    <span class="status-icon">✅</span>
                                    <span class="correct-sentence">${escapeHtml(item.correct)}</span>
                                </div>
                                ${item.note ? `<span class="comparison-note">${escapeHtml(item.note)}</span>` : ''}
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}

            <!-- POSITIVE TO INTERROGATIVE TO WH TRANSFORMATION SHOWCASE -->
            ${whData.transformations ? `
                <div class="transformations-block">
                    <h4 class="transformations-title">Positive → Interrogative → WH Question Transformations</h4>
                    <div class="transformations-grid">
                        ${whData.transformations.map(t => `
                            <div class="transformation-card wh-trans-card">
                                <div class="trans-pos-row">
                                    <span class="trans-label">Positive:</span>
                                    <span class="trans-text">${escapeHtml(t.positive)}</span>
                                </div>
                                <div class="trans-pos-row">
                                    <span class="trans-label">Yes/No Q:</span>
                                    <span class="trans-text">${escapeHtml(t.interrogative)}</span>
                                </div>
                                <div class="trans-arrow">↓</div>
                                <div class="trans-neg-row">
                                    <span class="trans-label">WH Question:</span>
                                    <span class="trans-text-neg wh-text-highlight">${escapeHtml(t.wh)}</span>
                                </div>
                                ${t.note ? `<span class="trans-note">${escapeHtml(t.note)}</span>` : ''}
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}

            <!-- 30 Sentences Collection (Easy, Medium, Hard) -->
            ${whData.sentences ? `
                <div class="sentences-practice-block">
                    <div class="sentences-toolbar">
                        <h4 class="sentences-toolbar-title">Practice Questions (30 WH Questions)</h4>
                        <div class="level-tabs-group" id="wh-level-tabs">
                            <button type="button" class="level-tab-btn tab-easy active" data-level="easy">Easy (10)</button>
                            <button type="button" class="level-tab-btn tab-medium" data-level="medium">Medium (10)</button>
                            <button type="button" class="level-tab-btn tab-hard" data-level="hard">Hard (10)</button>
                            <button type="button" class="level-tab-btn" data-level="all">All (30)</button>
                        </div>
                    </div>

                    <div class="sentences-cards-grid" id="wh-sentences-grid"></div>
                </div>
            ` : ''}
        </div>
    `;

    // Bind Level Tab Switching for WH Questions
    setTimeout(() => {
        const tabs = section.querySelectorAll('#wh-level-tabs .level-tab-btn');
        const gridContainer = section.querySelector('#wh-sentences-grid');

        if (tabs && gridContainer && whData.sentences) {
            renderWhQuestionsCards(gridContainer, whData.sentences, 'easy');

            tabs.forEach(tab => {
                tab.addEventListener('click', (e) => {
                    const level = e.currentTarget.dataset.level;
                    tabs.forEach(t => t.classList.remove('active'));
                    e.currentTarget.classList.add('active');
                    renderWhQuestionsCards(gridContainer, whData.sentences, level);
                });
            });
        }
    }, 0);

    return section;
}

function renderWhQuestionsCards(container, sentencesObj, level) {
    container.innerHTML = '';
    let sentencesList = [];

    if (level === 'all') {
        sentencesList = [
            ...(sentencesObj.easy || []),
            ...(sentencesObj.medium || []),
            ...(sentencesObj.hard || [])
        ];
    } else {
        sentencesList = sentencesObj[level] || [];
    }

    sentencesList.forEach((s, idx) => {
        const card = document.createElement('div');
        card.className = 'sentence-item-card wh-item-card';

        const diffBadgeClass = getCardDifficulty(s, level, idx);
        const diffLabel = diffBadgeClass.toUpperCase();

        card.innerHTML = `
            <div class="sentence-card-top">
                <span class="sentence-index-tag">WH Question #${idx + 1}</span>
                <span class="diff-badge diff-${diffBadgeClass}">${diffLabel}</span>
            </div>
            <div class="sentence-text-content">
                <p class="sentence-en">${escapeHtml(s.english)}</p>
                <p class="sentence-hi">${escapeHtml(s.hindi)}</p>
            </div>
            <div class="sentence-meta-row">
                ${s.whWord ? `<span class="sentence-wh-word-tag">WH: ${escapeHtml(s.whWord)}</span>` : ''}
                ${s.aux ? `<span class="sentence-subj-tag">Aux: ${escapeHtml(s.aux)}</span>` : ''}
                ${s.subject ? `<span class="sentence-subj-tag">Subject: ${escapeHtml(s.subject)}</span>` : ''}
                ${s.verb ? `<span class="sentence-verb-chip wh-verb-chip">Verb: ${escapeHtml(s.verb)}</span>` : ''}
            </div>
        `;

        container.appendChild(card);
    });
}

/**
 * Step 3I: Render Common Mistakes Section
 */
function renderCommonMistakesSection(mistakesData) {
    if (!mistakesData) return document.createElement('div');

    const section = document.createElement('section');
    section.className = 'tense-section-card section-common-mistakes';

    section.innerHTML = `
        <div class="section-card-header">
            <span class="section-card-icon">⚠️</span>
            <div class="section-card-title-group">
                <h3 class="section-card-title-en">9. Common Mistakes & Corrections</h3>
                <span class="section-card-title-hi">${escapeHtml(mistakesData.titleHindi)}</span>
            </div>
        </div>
        <div class="section-card-body">
            <p class="ident-overview-en">${escapeHtml(mistakesData.introduction)}</p>
            <p class="ident-overview-hi">💡 ${escapeHtml(mistakesData.introductionHindi)}</p>

            <!-- 15 Mistake Cards Grid -->
            ${mistakesData.mistakes ? `
                <div class="mistakes-cards-grid">
                    ${mistakesData.mistakes.map((m, idx) => `
                        <div class="mistake-item-card">
                            <div class="mistake-card-top">
                                <span class="mistake-num-badge">Mistake #${idx + 1}</span>
                                <h4 class="mistake-title-en">${escapeHtml(m.title)}</h4>
                            </div>
                            <span class="mistake-title-hi">📌 ${escapeHtml(m.titleHindi)}</span>

                            <div class="wrong-correct-comparison-grid mistake-comparison-row">
                                <div class="comparison-card wrong-card">
                                    <div class="wrong-row">
                                        <span class="status-icon">❌</span>
                                        <span class="wrong-sentence">${escapeHtml(m.wrong)}</span>
                                    </div>
                                    <span class="comparison-note">Incorrect</span>
                                </div>
                                <div class="comparison-card correct-card">
                                    <div class="correct-row">
                                        <span class="status-icon">✅</span>
                                        <span class="correct-sentence">${escapeHtml(m.correct)}</span>
                                    </div>
                                    ${m.correctHindi ? `<span class="correct-hi-text">${escapeHtml(m.correctHindi)}</span>` : ''}
                                </div>
                            </div>

                            <p class="mistake-explanation-en">${escapeHtml(m.explanation)}</p>
                            <p class="mistake-explanation-hi">💡 ${escapeHtml(m.explanationHindi)}</p>

                            ${m.rule ? `<div class="mistake-rule-pill">🔑 Rule: <code>${escapeHtml(m.rule)}</code></div>` : ''}

                            ${m.examples && m.examples.length > 0 ? `
                                <div class="mistake-sub-examples">
                                    ${m.examples.map(ex => `
                                        <div class="mistake-sub-ex-item">
                                            <span class="sub-wrong">❌ ${escapeHtml(ex.wrong)}</span>
                                            <span class="sub-correct">✅ ${escapeHtml(ex.correct)}</span>
                                            ${ex.note ? `<span class="sub-note">(${escapeHtml(ex.note)})</span>` : ''}
                                        </div>
                                    `).join('')}
                                </div>
                            ` : ''}
                        </div>
                    `).join('')}
                </div>
            ` : ''}

            <!-- Quick-Reference Memory Rules Block -->
            ${mistakesData.memoryRules ? `
                <div class="memory-rules-block">
                    <h4 class="memory-rules-title">Quick-Reference Memory Rules (स्मरण रखने योग्य नियम)</h4>
                    <div class="memory-rules-grid">
                        ${mistakesData.memoryRules.map(mr => `
                            <div class="memory-rule-card">
                                <div class="memory-rule-header">
                                    <span class="memory-rule-title">${escapeHtml(mr.title)}</span>
                                    <span class="memory-rule-hi">${escapeHtml(mr.titleHindi)}</span>
                                </div>
                                <code class="memory-rule-code">${escapeHtml(mr.ruleEn)}</code>
                                <p class="memory-rule-desc">💡 ${escapeHtml(mr.ruleHi)}</p>
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}
        </div>
    `;

    return section;
}

/**
 * Step 3J: Render Summary Section
 */
function renderSummarySection(summaryData) {
    if (!summaryData) return document.createElement('div');

    const section = document.createElement('section');
    section.className = 'tense-section-card section-summary';

    const revisionSentences = summaryData.sentences || summaryData.finalExamples;

    section.innerHTML = `
        <div class="section-card-header">
            <span class="section-card-icon">🎓</span>
            <div class="section-card-title-group">
                <h3 class="section-card-title-en">10. Summary & Revision</h3>
                <span class="section-card-title-hi">${escapeHtml(summaryData.titleHindi)}</span>
            </div>
        </div>
        <div class="section-card-body">
            <p class="ident-overview-en">${escapeHtml(summaryData.introduction)}</p>
            <p class="ident-overview-hi">💡 ${escapeHtml(summaryData.introductionHindi)}</p>

            <!-- Quick Rules Recap (Present Continuous) -->
            ${summaryData.quickRules && summaryData.quickRules.length > 0 ? `
                <div class="summary-sub-block">
                    <h4 class="summary-sub-title">1. Key Rules Recap (मुख्य नियम)</h4>
                    <div class="quick-rules-list" style="display: flex; flex-direction: column; gap: 0.5rem;">
                        ${summaryData.quickRules.map(rule => `
                            <div class="quick-rule-item" style="background: rgba(255,255,255,0.03); padding: 0.75rem 1rem; border-radius: 8px; border-left: 3px solid var(--color-primary, #3b82f6);">
                                <span class="rule-text">🔹 ${escapeHtml(rule)}</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}

            <!-- Memory Rule Banner (Present Continuous) -->
            ${summaryData.memoryRule ? `
                <div class="summary-sub-block">
                    <div class="final-memory-message-box">
                        <div class="final-memory-header">
                            <span class="final-memory-icon">🧠</span>
                            <h4 class="final-memory-title">${escapeHtml(summaryData.memoryRule.ruleTitleHindi || summaryData.memoryRule.ruleTitle)}</h4>
                        </div>
                        <p class="final-memory-encouragement" style="font-size: 1.05rem; line-height: 1.6; margin-top: 0.5rem;">🌟 ${escapeHtml(summaryData.memoryRule.ruleText)}</p>
                    </div>
                </div>
            ` : ''}

            <!-- 1. Uses Recap Grid (Simple Present) -->
            ${summaryData.usesRecap ? `
                <div class="summary-sub-block">
                    <h4 class="summary-sub-title">1. When Do We Use Simple Present? (5 Main Uses)</h4>
                    <div class="uses-recap-grid">
                        ${summaryData.usesRecap.map((use, idx) => `
                            <div class="use-recap-card">
                                <div class="use-recap-header">
                                    <span class="use-num">${idx + 1}</span>
                                    <div class="use-titles">
                                        <h5 class="use-title-en">${escapeHtml(use.title)}</h5>
                                        <span class="use-title-hi">${escapeHtml(use.titleHindi)}</span>
                                    </div>
                                </div>
                                <div class="use-example-box">
                                    <p class="ex-en">${escapeHtml(use.english)}</p>
                                    <p class="ex-hi">${escapeHtml(use.hindi)}</p>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}

            <!-- 2. Core Sentence Type Formulas & Examples (Simple Present) -->
            ${summaryData.sentenceTypes ? `
                <div class="summary-sub-block">
                    <h4 class="summary-sub-title">2. Sentence Type Formulas & Rules</h4>
                    <div class="sentence-types-summary-grid">
                        ${summaryData.sentenceTypes.map(st => `
                            <div class="sentence-type-summary-card type-${st.type}">
                                <h5 class="st-card-title">${escapeHtml(st.title)}</h5>
                                <div class="st-formulas-group">
                                    <div class="st-formula-row">
                                        <span class="st-formula-label">Group A (I/You/We/They):</span>
                                        <code class="st-formula-code">${escapeHtml(st.groupAFormula)}</code>
                                        <p class="st-example-text">💬 ${escapeHtml(st.groupAExample)}</p>
                                    </div>
                                    <div class="st-formula-row">
                                        <span class="st-formula-label">Group B (He/She/It/Singular):</span>
                                        <code class="st-formula-code">${escapeHtml(st.groupBFormula)}</code>
                                        <p class="st-example-text">💬 ${escapeHtml(st.groupBExample)}</p>
                                    </div>
                                </div>
                                <p class="st-key-rule">💡 ${escapeHtml(st.keyRuleHindi)}</p>
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}

            <!-- 3. Do / Does Quick Rule -->
            ${summaryData.doDoesQuickRule ? `
                <div class="summary-sub-block">
                    <h4 class="summary-sub-title">3. Do / Does Quick Rule</h4>
                    <div class="do-does-quick-card">
                        <div class="do-does-row">
                            <div class="do-box">
                                <code>${escapeHtml(summaryData.doDoesQuickRule.groupA)}</code>
                            </div>
                            <div class="does-box">
                                <code>${escapeHtml(summaryData.doDoesQuickRule.groupB)}</code>
                            </div>
                        </div>
                        <p class="do-does-explanation">💡 ${escapeHtml(summaryData.doDoesQuickRule.explanationHindi)}</p>
                    </div>
                </div>
            ` : ''}

            <!-- 4. Golden V1 Rule Card -->
            ${summaryData.goldenV1Rule ? `
                <div class="summary-sub-block">
                    <div class="summary-golden-rule-card">
                        <div class="golden-header">
                            <span class="golden-icon">👑</span>
                            <div class="golden-titles">
                                <h4 class="golden-title-en">${escapeHtml(summaryData.goldenV1Rule.title)}</h4>
                                <span class="golden-title-hi">${escapeHtml(summaryData.goldenV1Rule.titleHindi)}</span>
                            </div>
                        </div>
                        <div class="golden-formula-box">
                            <code>${escapeHtml(summaryData.goldenV1Rule.formula)}</code>
                        </div>
                        <p class="golden-explanation">💡 ${escapeHtml(summaryData.goldenV1Rule.explanationHindi)}</p>

                        <div class="golden-comparisons-grid">
                            ${summaryData.goldenV1Rule.comparison.map(item => `
                                <div class="golden-comp-item">
                                    <span class="golden-wrong">❌ ${escapeHtml(item.wrong)}</span>
                                    <span class="golden-correct">✅ ${escapeHtml(item.correct)}</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
            ` : ''}

            <!-- 5. s / es / ies Rule Revision & Have/Has Rule Revision Grid -->
            <div class="summary-rules-two-col">
                ${summaryData.sEsRuleRevision ? `
                    <div class="summary-rule-half-card">
                        <h4 class="summary-half-title">${escapeHtml(summaryData.sEsRuleRevision.titleHindi)}</h4>
                        <code class="summary-half-formula">${escapeHtml(summaryData.sEsRuleRevision.ruleText)}</code>
                        <div class="spelling-examples-chips">
                            ${summaryData.sEsRuleRevision.examples.map(ex => `
                                <span class="spelling-chip">${escapeHtml(ex.base)} ➜ <strong>${escapeHtml(ex.singular)}</strong></span>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}

                ${summaryData.haveHasRule ? `
                    <div class="summary-rule-half-card">
                        <h4 class="summary-half-title">${escapeHtml(summaryData.haveHasRule.titleHindi)}</h4>
                        <p class="summary-half-desc"><code>${escapeHtml(summaryData.haveHasRule.positiveText)}</code></p>
                        <div class="have-has-examples-list">
                            <p class="hh-ex">✅ Positive: <strong>${escapeHtml(summaryData.haveHasRule.positiveExample)}</strong></p>
                            <p class="hh-ex">❓ Question: <strong>${escapeHtml(summaryData.haveHasRule.questionExample)}</strong></p>
                            <p class="hh-ex">❌ Negative: <strong>${escapeHtml(summaryData.haveHasRule.negativeExample)}</strong></p>
                        </div>
                        <p class="summary-half-explanation">💡 ${escapeHtml(summaryData.haveHasRule.explanationHindi)}</p>
                    </div>
                ` : ''}
            </div>

            <!-- 6. Subject + Verb Revision Table -->
            ${summaryData.revisionMatrix ? `
                <div class="summary-sub-block">
                    <h4 class="summary-sub-title">Subject + Verb Quick Revision Matrix</h4>
                    <div class="table-responsive-wrapper">
                        <table class="revision-matrix-table">
                            <thead>
                                <tr>
                                    <th>Subject (कर्ता)</th>
                                    <th>Positive (सकारात्मक)</th>
                                    <th>Negative (नकारात्मक)</th>
                                    <th>Question (प्रश्नवाचक)</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${summaryData.revisionMatrix.map(row => `
                                    <tr>
                                        <td class="subject-col"><strong>${escapeHtml(row.subject)}</strong></td>
                                        <td class="pos-col"><code>${escapeHtml(row.positive)}</code></td>
                                        <td class="neg-col"><code>${escapeHtml(row.negative)}</code></td>
                                        <td class="q-col"><code>${escapeHtml(row.question)}</code></td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            ` : ''}

            <!-- 7. 15 Final Revision Examples -->
            ${revisionSentences ? `
                <div class="sentences-practice-block">
                    <div class="sentences-toolbar">
                        <h4 class="sentences-toolbar-title">Final Revision Examples (15 Sentences)</h4>
                        <div class="level-tabs-group" id="summary-level-tabs">
                            <button type="button" class="level-tab-btn tab-easy active" data-level="easy">Easy (5)</button>
                            <button type="button" class="level-tab-btn tab-medium" data-level="medium">Medium (5)</button>
                            <button type="button" class="level-tab-btn tab-hard" data-level="hard">Hard (5)</button>
                            <button type="button" class="level-tab-btn" data-level="all">All (15)</button>
                        </div>
                    </div>

                    <div class="sentences-cards-grid" id="summary-sentences-grid"></div>
                </div>
            ` : ''}

            <!-- 8. Final Memory Message Card (Simple Present) -->
            ${summaryData.finalMemoryMessage ? `
                <div class="final-memory-message-box">
                    <div class="final-memory-header">
                        <span class="final-memory-icon">🧠</span>
                        <h4 class="final-memory-title">${escapeHtml(summaryData.finalMemoryMessage.title)}</h4>
                    </div>
                    <div class="final-memory-rules-list">
                        ${summaryData.finalMemoryMessage.rules.map(rule => `
                            <div class="final-memory-rule-item">
                                <span class="rule-bullet">✦</span>
                                <span class="rule-text">${escapeHtml(rule)}</span>
                            </div>
                        `).join('')}
                    </div>
                    <p class="final-memory-encouragement">🌟 ${escapeHtml(summaryData.finalMemoryMessage.encouragementHindi)}</p>
                </div>
            ` : ''}
        </div>
    `;

    // Bind Level Tab Switching for Summary Examples
    setTimeout(() => {
        const tabs = section.querySelectorAll('#summary-level-tabs .level-tab-btn');
        const gridContainer = section.querySelector('#summary-sentences-grid');

        if (tabs && gridContainer && revisionSentences) {
            renderSummaryExamplesCards(gridContainer, revisionSentences, 'easy');

            tabs.forEach(tab => {
                tab.addEventListener('click', (e) => {
                    const level = e.currentTarget.dataset.level;
                    tabs.forEach(t => t.classList.remove('active'));
                    e.currentTarget.classList.add('active');
                    renderSummaryExamplesCards(gridContainer, revisionSentences, level);
                });
            });
        }
    }, 0);

    return section;
}

function renderSummaryExamplesCards(container, examplesObj, level) {
    container.innerHTML = '';
    let sentencesList = [];

    if (level === 'all') {
        sentencesList = [
            ...(examplesObj.easy || []),
            ...(examplesObj.medium || []),
            ...(examplesObj.hard || [])
        ];
    } else {
        sentencesList = examplesObj[level] || [];
    }

    sentencesList.forEach((s, idx) => {
        const card = document.createElement('div');
        card.className = 'sentence-item-card summary-item-card';

        const diffBadgeClass = getCardDifficulty(s, level, idx);
        const diffLabel = diffBadgeClass.toUpperCase();

        card.innerHTML = `
            <div class="sentence-card-top">
                <span class="sentence-index-tag">Revision Sentence #${idx + 1}</span>
                <span class="diff-badge diff-${diffBadgeClass}">${diffLabel}</span>
            </div>
            <div class="sentence-text-content">
                <p class="sentence-en">${escapeHtml(s.english)}</p>
                <p class="sentence-hi">${escapeHtml(s.hindi)}</p>
            </div>
        `;

        container.appendChild(card);
    });
}

/**
 * Step 3L & 3M: Render Practice Exercises Section (120 Practice Sentences with completion toggles)
 */
function renderExercisesSection(exercisesData, sections, tenseId = 'simple-present') {
    if (!exercisesData || !exercisesData.categories) return document.createElement('div');

    const section = document.createElement('section');
    section.className = 'tense-section-card section-exercises';

    const categoryIcons = {
        positive: '✅',
        negative: '❌',
        interrogative: '❓',
        whQuestions: '🌐'
    };

    section.innerHTML = `
        <div class="section-card-header">
            <span class="section-card-icon">✍️</span>
            <div class="section-card-title-group">
                <h3 class="section-card-title-en">11. Practice Exercises</h3>
                <span class="section-card-title-hi">${escapeHtml(exercisesData.titleHindi)}</span>
            </div>
        </div>
        <div class="section-card-body">
            <p class="ident-overview-en">${escapeHtml(exercisesData.introduction)}</p>
            <p class="ident-overview-hi">💡 ${escapeHtml(exercisesData.introductionHindi)}</p>

            <!-- 4 Visually Distinct Practice Categories Container -->
            <div class="exercises-categories-container">
                ${exercisesData.categories.map((cat) => `
                    <div class="exercise-category-block cat-theme-${cat.id}" id="ex-cat-${cat.id}">
                        <div class="category-block-header">
                            <div class="cat-header-title-group">
                                <span class="cat-header-icon">${categoryIcons[cat.id] || '📌'}</span>
                                <div class="cat-titles">
                                    <h4 class="category-block-title">${escapeHtml(cat.titleHindi)}</h4>
                                    <span class="category-block-subtitle">${escapeHtml(cat.title)}</span>
                                </div>
                            </div>
                            <span class="category-count-badge badge-theme-${cat.id}">30 Sentences</span>
                        </div>

                        <div class="sentences-practice-block">
                            <div class="sentences-toolbar">
                                <h5 class="sentences-toolbar-title">${escapeHtml(cat.title)} Toolbar</h5>
                                <div class="level-tabs-group" id="tabs-ex-${cat.id}">
                                    <button type="button" class="level-tab-btn tab-easy active" data-level="easy">Easy (10)</button>
                                    <button type="button" class="level-tab-btn tab-medium" data-level="medium">Medium (10)</button>
                                    <button type="button" class="level-tab-btn tab-hard" data-level="hard">Hard (10)</button>
                                    <button type="button" class="level-tab-btn" data-level="all">All (30)</button>
                                </div>
                            </div>

                            <div class="sentences-cards-grid" id="grid-ex-${cat.id}"></div>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;

    // Bind Level Tab Switching for each of the 4 practice categories
    setTimeout(() => {
        exercisesData.categories.forEach(cat => {
            const tabs = section.querySelectorAll(`#tabs-ex-${cat.id} .level-tab-btn`);
            const gridContainer = section.querySelector(`#grid-ex-${cat.id}`);

            if (tabs && gridContainer && cat.sentences) {
                renderCategoryPracticeCards(gridContainer, cat.sentences, 'easy', cat.id, cat.typeLabel, sections, tenseId);

                tabs.forEach(tab => {
                    tab.addEventListener('click', (e) => {
                        const level = e.currentTarget.dataset.level;
                        tabs.forEach(t => t.classList.remove('active'));
                        e.currentTarget.classList.add('active');
                        renderCategoryPracticeCards(gridContainer, cat.sentences, level, cat.id, cat.typeLabel, sections, tenseId);
                    });
                });
            }
        });
    }, 0);

    return section;
}

function renderCategoryPracticeCards(container, sentencesObj, level, categoryType, typeLabel, sections, tenseId = 'simple-present') {
    container.innerHTML = '';
    let sentencesList = [];

    if (level === 'all') {
        sentencesList = [
            ...(sentencesObj.easy || []),
            ...(sentencesObj.medium || []),
            ...(sentencesObj.hard || [])
        ];
    } else {
        sentencesList = sentencesObj[level] || [];
    }

    sentencesList.forEach((s, idx) => {
        const fullItemId = `${categoryType}_${s.id}`;
        const isComp = isPracticeItemCompleted(tenseId, fullItemId);

        const card = document.createElement('div');
        card.className = `sentence-item-card ex-practice-card ${categoryType}-item-card ${isComp ? 'is-item-completed' : ''}`;

        const diffBadgeClass = getCardDifficulty(s, level, idx);
        const diffLabel = diffBadgeClass.toUpperCase();
        const itemId = `ex-${categoryType}-${s.id || idx}`;

        let structureNote = "";
        if (tenseId === 'present-perfect-continuous') {
            if (categoryType === 'positive') {
                structureNote = `Subject (${s.subject || 'Subject'}) + ${s.aux || 'has/have been'} + ${s.verb || 'V1+ing'} + ${s.object || 'Object/Complement'}`;
            } else if (categoryType === 'negative') {
                structureNote = `Subject (${s.subject || 'Subject'}) + ${s.aux || 'has/have not been'} + ${s.verb || 'V1+ing'} + ${s.object || 'Object/Complement'}`;
            } else if (categoryType === 'interrogative') {
                structureNote = `${s.aux || 'Has/Have'} + Subject (${s.subject || 'Subject'}) + been + ${s.verb || 'V1+ing'} + ${s.object || 'Object/Complement'}?`;
            } else if (categoryType === 'whQuestions') {
                structureNote = `${s.whWord || 'WH Word'} + ${s.aux || 'has/have'} + Subject (${s.subject || 'Subject'}) + been + ${s.verb || 'V1+ing'} + ${s.object || 'Object/Complement'}?`;
            }
        } else if (tenseId === 'present-perfect') {
            if (categoryType === 'positive') {
                structureNote = `Subject (${s.subject || 'Subject'}) + ${s.aux || 'has/have'} + ${s.verb || 'V3'} + ${s.object || 'Object'}`;
            } else if (categoryType === 'negative') {
                structureNote = `Subject (${s.subject || 'Subject'}) + ${s.aux || 'has/have'} + not + ${s.verb || 'V3'} + ${s.object || 'Object'}`;
            } else if (categoryType === 'interrogative') {
                structureNote = `${s.aux || 'Has/Have'} + Subject (${s.subject || 'Subject'}) + ${s.verb || 'V3'} + ${s.object || 'Object'}?`;
            } else if (categoryType === 'whQuestions') {
                structureNote = `${s.whWord || 'WH Word'} + ${s.aux || 'has/have'} + Subject (${s.subject || 'Subject'}) + ${s.verb || 'V3'} + ${s.object || 'Object'}?`;
            }
        } else if (tenseId === 'future-perfect-continuous') {
            if (categoryType === 'positive') {
                structureNote = `Subject (${s.subject || 'Subject'}) + will have been + V1+ing (${s.verb || 'V1+ing'}) + ${s.object || 'Object/Complement'}`;
            } else if (categoryType === 'negative') {
                structureNote = `Subject (${s.subject || 'Subject'}) + ${s.aux || "won't have been"} + V1+ing (${s.verb || 'V1+ing'}) + ${s.object || 'Object/Complement'}`;
            } else if (categoryType === 'interrogative') {
                structureNote = `Will + Subject (${s.subject || 'Subject'}) + have been + V1+ing (${s.verb || 'V1+ing'}) + ${s.object || 'Object/Complement'}?`;
            } else if (categoryType === 'whQuestions') {
                structureNote = s.whWord === 'Who' && !s.aux ? `Who + will have been + V1+ing (${s.verb || 'V1+ing'}) + ${s.object || 'Object'}?` : `${s.whWord || 'WH Word'} + will + Subject (${s.subject || 'Subject'}) + have been + V1+ing (${s.verb || 'V1+ing'}) + ${s.object || 'Object/Complement'}?`;
            }
        } else if (tenseId === 'future-perfect') {
            if (categoryType === 'positive') {
                structureNote = `Subject (${s.subject || 'Subject'}) + will have + V3 (${s.verb || 'V3'}) + ${s.object || 'Object/Complement'}`;
            } else if (categoryType === 'negative') {
                structureNote = `Subject (${s.subject || 'Subject'}) + ${s.aux || "won't have"} + V3 (${s.verb || 'V3'}) + ${s.object || 'Object/Complement'}`;
            } else if (categoryType === 'interrogative') {
                structureNote = `Will + Subject (${s.subject || 'Subject'}) + have + V3 (${s.verb || 'V3'}) + ${s.object || 'Object/Complement'}?`;
            } else if (categoryType === 'whQuestions') {
                structureNote = s.whWord === 'Who' && !s.aux ? `Who + will have + V3 (${s.verb || 'V3'}) + ${s.object || 'Object'}?` : `${s.whWord || 'WH Word'} + will + Subject (${s.subject || 'Subject'}) + have + V3 (${s.verb || 'V3'}) + ${s.object || 'Object/Complement'}?`;
            }
        } else if (tenseId === 'future-continuous') {
            if (categoryType === 'positive') {
                structureNote = `Subject (${s.subject || 'Subject'}) + will be + V1+ing (${s.verb || 'V1+ing'}) + ${s.object || 'Object/Complement'}`;
            } else if (categoryType === 'negative') {
                structureNote = `Subject (${s.subject || 'Subject'}) + ${s.aux || "won't be"} + V1+ing (${s.verb || 'V1+ing'}) + ${s.object || 'Object/Complement'}`;
            } else if (categoryType === 'interrogative') {
                structureNote = `Will + Subject (${s.subject || 'Subject'}) + be + V1+ing (${s.verb || 'V1+ing'}) + ${s.object || 'Object/Complement'}?`;
            } else if (categoryType === 'whQuestions') {
                structureNote = s.whWord === 'Who' && !s.aux ? `Who + will be + V1+ing (${s.verb || 'V1+ing'}) + ${s.object || 'Object'}?` : `${s.whWord || 'WH Word'} + will + Subject (${s.subject || 'Subject'}) + be + V1+ing (${s.verb || 'V1+ing'}) + ${s.object || 'Object/Complement'}?`;
            }
        } else if (tenseId === 'simple-future') {
            if (categoryType === 'positive') {
                structureNote = `Subject (${s.subject || 'Subject'}) + will + V1 (${s.verb || 'V1'}) + ${s.object || 'Object/Complement'}`;
            } else if (categoryType === 'negative') {
                structureNote = `Subject (${s.subject || 'Subject'}) + ${s.aux || "won't"} + V1 (${s.verb || 'V1'}) + ${s.object || 'Object/Complement'}`;
            } else if (categoryType === 'interrogative') {
                structureNote = `Will + Subject (${s.subject || 'Subject'}) + V1 (${s.verb || 'V1'}) + ${s.object || 'Object/Complement'}?`;
            } else if (categoryType === 'whQuestions') {
                structureNote = s.whWord === 'Who' && !s.aux ? `Who + will + V1 (${s.verb || 'V1'}) + ${s.object || 'Object'}?` : `${s.whWord || 'WH Word'} + will + Subject (${s.subject || 'Subject'}) + V1 (${s.verb || 'V1'}) + ${s.object || 'Object/Complement'}?`;
            }
        } else if (tenseId === 'past-perfect-continuous') {
            if (categoryType === 'positive') {
                structureNote = `Subject (${s.subject || 'Subject'}) + had been + ${s.verb || 'V1+ing'} + ${s.object || 'Object/Complement'}`;
            } else if (categoryType === 'negative') {
                structureNote = `Subject (${s.subject || 'Subject'}) + ${s.aux || "hadn't been"} + ${s.verb || 'V1+ing'} + ${s.object || 'Object/Complement'}`;
            } else if (categoryType === 'interrogative') {
                structureNote = `Had + Subject (${s.subject || 'Subject'}) + been + ${s.verb || 'V1+ing'} + ${s.object || 'Object/Complement'}?`;
            } else if (categoryType === 'whQuestions') {
                structureNote = `${s.whWord || 'WH Word'} + had + Subject (${s.subject || 'Subject'}) + been + ${s.verb || 'V1+ing'} + ${s.object || 'Object/Complement'}?`;
            }
        } else if (tenseId === 'past-perfect') {
            if (categoryType === 'positive') {
                structureNote = `Subject (${s.subject || 'Subject'}) + had + V3 (${s.verb || 'V3'}) + ${s.object || 'Object/Complement'}`;
            } else if (categoryType === 'negative') {
                structureNote = `Subject (${s.subject || 'Subject'}) + ${s.aux || "hadn't"} + V3 (${s.verb || 'V3'}) + ${s.object || 'Object/Complement'}`;
            } else if (categoryType === 'interrogative') {
                structureNote = `Had + Subject (${s.subject || 'Subject'}) + V3 (${s.verb || 'V3'}) + ${s.object || 'Object/Complement'}?`;
            } else if (categoryType === 'whQuestions') {
                structureNote = `${s.whWord || 'WH Word'} + had + Subject (${s.subject || 'Subject'}) + V3 (${s.verb || 'V3'}) + ${s.object || 'Object/Complement'}?`;
            }
        } else if (tenseId === 'past-continuous') {
            if (categoryType === 'positive') {
                structureNote = `Subject (${s.subject || 'Subject'}) + ${s.aux || 'was/were'} + ${s.verb || 'V1+ing'} + ${s.object || 'Object/Complement'}`;
            } else if (categoryType === 'negative') {
                structureNote = `Subject (${s.subject || 'Subject'}) + ${s.aux || "wasn't/weren't"} + ${s.verb || 'V1+ing'} + ${s.object || 'Object/Complement'}`;
            } else if (categoryType === 'interrogative') {
                structureNote = `${s.aux || 'Was/Were'} + Subject (${s.subject || 'Subject'}) + ${s.verb || 'V1+ing'} + ${s.object || 'Object/Complement'}?`;
            } else if (categoryType === 'whQuestions') {
                structureNote = s.whWord === 'Who' && !s.aux ? `Who + was + ${s.verb || 'V1+ing'} + ${s.object || 'Object'}?` : `${s.whWord || 'WH Word'} + ${s.aux || 'was/were'} + Subject (${s.subject || 'Subject'}) + ${s.verb || 'V1+ing'} + ${s.object || 'Object/Complement'}?`;
            }
        } else if (tenseId === 'simple-past') {
            if (categoryType === 'positive') {
                structureNote = `Subject (${s.subject || 'Subject'}) + V2 (${s.verb || 'V2'}) + ${s.object || 'Object/Complement'}`;
            } else if (categoryType === 'negative') {
                structureNote = `Subject (${s.subject || 'Subject'}) + did not / didn't + V1 (${s.verb || 'V1'}) + ${s.object || 'Object/Complement'}`;
            } else if (categoryType === 'interrogative') {
                structureNote = `Did + Subject (${s.subject || 'Subject'}) + V1 (${s.verb || 'V1'}) + ${s.object || 'Object/Complement'}?`;
            } else if (categoryType === 'whQuestions') {
                structureNote = s.whWord === 'Who' && !s.aux ? `Who + V2 (${s.verb || 'V2'}) + ${s.object || 'Object'}?` : `${s.whWord || 'WH Word'} + did + Subject (${s.subject || 'Subject'}) + V1 (${s.verb || 'V1'}) + ${s.object || 'Object/Complement'}?`;
            }
        } else if (tenseId === 'present-continuous') {
            if (categoryType === 'positive') {
                structureNote = `Subject (${s.subject || 'Subject'}) + ${s.aux || 'am/is/are'} + ${s.verb || 'V4(ing)'} + ${s.object || 'Object'}`;
            } else if (categoryType === 'negative') {
                structureNote = `Subject (${s.subject || 'Subject'}) + ${s.aux || 'am/is/are'} + not + ${s.verb || 'V4(ing)'} + ${s.object || 'Object'}`;
            } else if (categoryType === 'interrogative') {
                structureNote = `${s.aux || 'Am/Is/Are'} + Subject (${s.subject || 'Subject'}) + ${s.verb || 'V4(ing)'} + ${s.object || 'Object'}?`;
            } else if (categoryType === 'whQuestions') {
                structureNote = `${s.whWord || 'WH Word'} + ${s.aux || 'am/is/are'} + Subject (${s.subject || 'Subject'}) + ${s.verb || 'V4(ing)'} + ${s.object || 'Object'}?`;
            }
        } else {
            if (categoryType === 'positive') {
                structureNote = `Subject (${s.subject || 'Subject'}) + Verb (${s.verb || 'V1/V1+s'})`;
            } else if (categoryType === 'negative') {
                structureNote = `Subject (${s.subject || 'Subject'}) + don't/doesn't + V1 (${s.verb || 'V1'})`;
            } else if (categoryType === 'interrogative') {
                structureNote = `Do/Does + Subject (${s.subject || 'Subject'}) + V1 (${s.verb || 'V1'})?`;
            } else if (categoryType === 'whQuestions') {
                structureNote = `${s.whWord || 'WH Word'} + Do/Does + Subject (${s.subject || 'Subject'}) + V1 (${s.verb || 'V1'})?`;
            }
        }

        card.innerHTML = `
            <div class="sentence-card-top">
                <div class="ex-meta-left">
                    <span class="sentence-index-tag">Item #${idx + 1}</span>
                    ${typeLabel ? `<span class="ex-type-badge type-badge-${categoryType}">${escapeHtml(typeLabel)}</span>` : ''}
                </div>
                <div class="ex-meta-right">
                    <span class="diff-badge diff-${diffBadgeClass}">${diffLabel}</span>
                </div>
            </div>

            <div class="sentence-text-content">
                <p class="sentence-en">${escapeHtml(s.english)}</p>
                <p class="sentence-hi">${escapeHtml(s.hindi)}</p>
            </div>

            <div class="sentence-meta-row">
                ${s.whWord ? `<span class="sentence-wh-word-tag">WH: ${escapeHtml(s.whWord)}</span>` : ''}
                ${s.aux ? `<span class="sentence-subj-tag">Aux: ${escapeHtml(s.aux)}</span>` : ''}
                ${s.subject ? `<span class="sentence-subj-tag">Subject: ${escapeHtml(s.subject)}</span>` : ''}
                ${s.verb ? `<span class="sentence-verb-chip ${categoryType}-verb-chip">Verb: ${escapeHtml(s.verb)}</span>` : ''}
            </div>

            <div class="exercise-actions-bar">
                <button type="button" class="btn-toggle-complete ${isComp ? 'is-completed' : ''}" data-full-id="${fullItemId}">
                    <span class="complete-btn-icon">${isComp ? '✓' : '◯'}</span>
                    <span class="complete-btn-text">${isComp ? 'Completed' : 'Mark Complete'}</span>
                </button>

                <button type="button" class="btn-reveal-answer" data-target="${itemId}">
                    <span class="reveal-btn-icon">👁️</span>
                    <span class="reveal-btn-text">Show Answer & Structure</span>
                </button>
            </div>

            <div class="ex-answer-box is-hidden" id="ans-${itemId}">
                <div class="ans-row">
                    <span class="ans-icon">✅</span>
                    <div class="ans-text-group">
                        <span class="ans-label">Correct Sentence:</span>
                        <span class="ans-value">${escapeHtml(s.english)}</span>
                    </div>
                </div>
                <p class="ans-explanation-hi">💡 <strong>Hindi Meaning:</strong> ${escapeHtml(s.hindi)}</p>
                <p class="ans-structure-note">📐 <strong>Grammar Structure:</strong> <code>${escapeHtml(structureNote)}</code></p>
            </div>
        `;

        // Bind Completion Toggle Click
        const btnToggle = card.querySelector('.btn-toggle-complete');
        if (btnToggle) {
            btnToggle.addEventListener('click', (e) => {
                e.stopPropagation();
                const isNowCompleted = togglePracticeItemCompleted(tenseId, fullItemId);
                if (isNowCompleted) {
                    card.classList.add('is-item-completed');
                    btnToggle.classList.add('is-completed');
                    btnToggle.querySelector('.complete-btn-icon').textContent = '✓';
                    btnToggle.querySelector('.complete-btn-text').textContent = 'Completed';
                } else {
                    card.classList.remove('is-item-completed');
                    btnToggle.classList.remove('is-completed');
                    btnToggle.querySelector('.complete-btn-icon').textContent = '◯';
                    btnToggle.querySelector('.complete-btn-text').textContent = 'Mark Complete';
                }

                if (sections) {
                    const allItems = getAllTensePracticeItems(sections);
                    const updatedStats = getTenseProgressStats(tenseId, allItems, ALL_SECTION_KEYS);
                    const layoutContainer = container.closest('.tense-detail-layout');
                    if (layoutContainer) {
                        renderProgressOverviewCard(layoutContainer, updatedStats);
                    }
                }
            });
        }

        // Bind Answer Reveal Toggle
        const btn = card.querySelector('.btn-reveal-answer');
        const ansBox = card.querySelector(`#ans-${itemId}`);

        if (btn && ansBox) {
            btn.addEventListener('click', () => {
                const isHidden = ansBox.classList.contains('is-hidden');
                if (isHidden) {
                    ansBox.classList.remove('is-hidden');
                    btn.classList.add('is-active');
                    btn.querySelector('.reveal-btn-icon').textContent = '🙈';
                    btn.querySelector('.reveal-btn-text').textContent = 'Hide Answer';
                } else {
                    ansBox.classList.add('is-hidden');
                    btn.classList.remove('is-active');
                    btn.querySelector('.reveal-btn-icon').textContent = '👁️';
                    btn.querySelector('.reveal-btn-text').textContent = 'Show Answer & Structure';
                }
            });
        }

        container.appendChild(card);
    });
}

function getCardDifficulty(item, currentTabLevel, index) {
    if (currentTabLevel && currentTabLevel !== 'all') {
        return currentTabLevel;
    }
    if (item && item.level) {
        return item.level;
    }
    if (item && item.id) {
        const id = String(item.id).toLowerCase();
        if (id.includes('-e') || id.includes('easy')) return 'easy';
        if (id.includes('-m') || id.includes('med')) return 'medium';
        if (id.includes('-h') || id.includes('hard')) return 'hard';
    }
    if (typeof index === 'number') {
        if (index < 10) return 'easy';
        if (index < 20) return 'medium';
        return 'hard';
    }
    return 'easy';
}

function renderTenseComingSoonState(container, tenseMeta) {
    document.title = `${tenseMeta.title} - Content Coming Soon`;

    container.innerHTML = `
        <div class="tense-detail-layout">
            <section class="tense-detail-header-card">
                <div class="tense-detail-nav-bar">
                    <a href="tenses.html" class="btn-back-to-tenses">
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <line x1="19" y1="12" x2="5" y2="12"></line>
                            <polyline points="12 19 5 12 12 5"></polyline>
                        </svg>
                        <span>Back to All Tenses</span>
                    </a>
                </div>

                <div class="tense-detail-title-group">
                    <h2 class="tense-detail-main-title">${escapeHtml(tenseMeta.title)}</h2>
                    <span class="tense-detail-hindi-title">${escapeHtml(tenseMeta.titleHindi)}</span>
                </div>
            </section>

            <div class="state-card">
                <span class="state-icon">⏳</span>
                <h3 class="state-title">Lesson Content Coming Soon</h3>
                <span class="state-hindi-title">पाठ सामग्री जल्द आ रही है</span>
                <p class="state-desc">
                    The architecture for <strong>${escapeHtml(tenseMeta.title)}</strong> is configured in the central data system. Detailed lesson content will be populated in upcoming steps.
                </p>
                <a href="tenses.html" class="btn btn-primary">Back to All Tenses</a>
            </div>
        </div>
    `;
}

function renderInvalidTenseState(container, invalidId) {
    document.title = "Tense Not Found - English Tenses";

    container.innerHTML = `
        <div class="state-card" style="margin-top: 3rem;">
            <span class="state-icon">⚠️</span>
            <h3 class="state-title">Tense Not Found</h3>
            <span class="state-hindi-title">काल उपलब्ध नहीं है</span>
            <p class="state-desc">
                The requested tense ID "${escapeHtml(invalidId || 'none')}" does not exist in the central tenses data system.
            </p>
            <a href="tenses.html" class="btn btn-primary">Return to All Tenses</a>
        </div>
    `;
}

function escapeHtml(str) {
    if (!str) return '';
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
