/**
 * Controller: Modal Verb Detail Page Controller (pages/modal.html?id=...)
 * Data-driven detailed view renderer powered by data/modals.js, components/modal-accordion.js, and services/modal-progress.js.
 */

import { createPlatformHeader } from '../../components/platform-header.js';
import { createPlatformSidebar } from '../../components/platform-sidebar.js';
import { getModalById, getModalLesson } from '../../data/modals.js';
import { createModalDetailHeader } from '../../components/modal-header.js';
import { initModalAccordion } from '../../components/modal-accordion.js';
import {
    recordModalOpened,
    recordModalSectionViewed,
    getModalProgressStats
} from '../../services/modal-progress.js';
import { escapeHtml } from './modal-utils.js';

const ALL_MODAL_SECTION_KEYS = [
    'identification',
    'uses',
    'structure',
    'subjectVerbRules',
    'positive',
    'negative',
    'interrogative',
    'whQuestions',
    'commonMistakes',
    'summary',
    'exercises'
];

document.addEventListener('DOMContentLoaded', () => {
    initModalDetailPage();
});

function initModalDetailPage() {
    const urlParams = new URLSearchParams(window.location.search);
    const modalId = urlParams.get('id');

    const headerContainer = document.getElementById('header-container');
    const sidebarContainer = document.getElementById('sidebar-container');
    const mainContainer = document.getElementById('modal-detail-main-container');

    const modalMeta = modalId ? getModalById(modalId) : null;
    const lessonData = modalId ? getModalLesson(modalId) : null;

    if (modalId && modalMeta) {
        recordModalOpened(modalId);
    }

    // 1. Initialize Shared Platform Header
    if (headerContainer) {
        const headerEl = createPlatformHeader({
            title: "English Learning Platform",
            subtitle: modalMeta ? `${modalMeta.title} - ${modalMeta.hindiMeaning}` : "Modal Verb Detail",
            showSidebarToggle: true,
            basePath: "../",
            onMenuToggle: () => {
                const sidebarEl = document.querySelector('.platform-sidebar');
                if (sidebarEl) {
                    sidebarEl.classList.toggle('is-collapsed');
                }
            }
        });
        headerContainer.appendChild(headerEl);
    }

    // 2. Initialize Shared Platform Sidebar
    if (sidebarContainer) {
        const sidebarInstance = createPlatformSidebar({
            activeId: modalId || "modal-verbs",
            basePath: "../",
            collapsed: false
        });
        sidebarContainer.appendChild(sidebarInstance);
    }

    // 3. Render Detail View based on Modal ID
    if (mainContainer) {
        mainContainer.innerHTML = '';

        if (!modalMeta || !lessonData) {
            renderModalErrorState(mainContainer, modalId);
            return;
        }

        try {
            renderModalDetailContent(mainContainer, modalMeta, lessonData);
        } catch (err) {
            console.error(`Error rendering modal detail page for '${modalId}':`, err);
            renderModalErrorState(mainContainer, modalId, err);
        }
    }
}

function renderModalDetailContent(container, modalMeta, lessonData) {
    document.title = `${modalMeta.name} (${modalMeta.hindiMeaning}) - Modal Verbs`;

    const sections = lessonData.sections;

    const layout = document.createElement('div');
    layout.className = 'modal-detail-layout';

    // 1. Page Header Card
    const headerCard = createModalDetailHeader(lessonData, modalMeta, { basePath: "../" });
    layout.appendChild(headerCard);

    // 2. Progress Overview Card
    const initialStats = getModalProgressStats(modalMeta.id, [], ALL_MODAL_SECTION_KEYS);
    const progressCard = renderModalProgressOverviewCard(initialStats);
    layout.appendChild(progressCard);

    // 3. Assemble 12 Sections for Accordion UI
    const sectionItems = [];

    // Section 1: Identification
    if (sections.identification) {
        sectionItems.push({
            key: 'identification',
            element: renderSectionCard('identification', '🔍 1. Identification & Concept', sections.identification.titleHindi, renderIdentificationContent(sections.identification, modalMeta))
        });
    }

    // Section 2: Uses
    if (sections.uses) {
        sectionItems.push({
            key: 'uses',
            element: renderSectionCard('uses', '🎯 2. Uses & Scenarios', sections.uses.titleHindi, renderUsesContent(sections.uses, modalMeta))
        });
    }

    // Section 3: Structure & Formulas
    if (sections.structure) {
        sectionItems.push({
            key: 'structure',
            element: renderSectionCard('structure', '📐 3. Structure & Formulas', sections.structure.titleHindi, renderStructureContent(sections.structure, modalMeta))
        });
    }

    // Section 4: Subject + Verb Rules
    if (sections.subjectVerbRules) {
        sectionItems.push({
            key: 'subjectVerbRules',
            element: renderSectionCard('subjectVerbRules', '👑 4. Subject + Verb Rules', sections.subjectVerbRules.titleHindi, renderSubjectVerbRulesContent(sections.subjectVerbRules, modalMeta))
        });
    }

    // Section 5: Positive Sentences
    if (sections.positive) {
        sectionItems.push({
            key: 'positive',
            element: renderSectionCard('positive', '✅ 5. Positive Sentences', sections.positive.titleHindi, renderCategoryContent('Positive', sections.positive, modalMeta))
        });
    }

    // Section 6: Negative Sentences
    if (sections.negative) {
        sectionItems.push({
            key: 'negative',
            element: renderSectionCard('negative', '❌ 6. Negative Sentences', sections.negative.titleHindi, renderCategoryContent('Negative', sections.negative, modalMeta))
        });
    }

    // Section 7: Interrogative Sentences
    if (sections.interrogative) {
        sectionItems.push({
            key: 'interrogative',
            element: renderSectionCard('interrogative', '❓ 7. Interrogative Sentences', sections.interrogative.titleHindi, renderCategoryContent('Interrogative', sections.interrogative, modalMeta))
        });
    }

    // Section 8: WH Questions
    if (sections.whQuestions) {
        sectionItems.push({
            key: 'whQuestions',
            element: renderSectionCard('whQuestions', '🗣️ 8. WH Questions', sections.whQuestions.titleHindi, renderCategoryContent('WH Questions', sections.whQuestions, modalMeta))
        });
    }

    // Section 9: Common Mistakes
    if (sections.commonMistakes) {
        sectionItems.push({
            key: 'commonMistakes',
            element: renderSectionCard('commonMistakes', '⚠️ 9. Common Mistakes', sections.commonMistakes.titleHindi, renderCommonMistakesContent(sections.commonMistakes, modalMeta))
        });
    }

    // Section 10: Summary & Revision
    if (sections.summary) {
        sectionItems.push({
            key: 'summary',
            element: renderSectionCard('summary', '📝 10. Summary & Revision', sections.summary.titleHindi, renderSummaryContent(sections.summary, modalMeta))
        });
    }

    // Section 11: Practice Exercises
    if (sections.exercises) {
        sectionItems.push({
            key: 'exercises',
            element: renderSectionCard('exercises', '🏋️ 11. Practice Exercises', sections.exercises.titleHindi, renderExercisesContent(sections.exercises, modalMeta))
        });
    }

    // Section 12: Quiz Engine
    if (sections.quiz) {
        sectionItems.push({
            key: 'quiz',
            element: renderSectionCard('quiz', '🏆 12. Modal Quiz Engine', sections.quiz.titleHindi, renderQuizContent(sections.quiz, modalMeta))
        });
    }

    // Initialize Accordion (Section 1 Open by Default, others Closed)
    initModalAccordion(layout, sectionItems, {
        defaultOpenIndex: 0,
        onSectionOpen: (sectionKey) => {
            if (sectionKey && sectionKey !== 'quiz') {
                recordModalSectionViewed(modalMeta.id, sectionKey);
                const updatedStats = getModalProgressStats(modalMeta.id, [], ALL_MODAL_SECTION_KEYS);
                updateModalProgressOverviewCard(layout, updatedStats);
            }
        }
    });

    container.appendChild(layout);
}

function renderSectionCard(key, titleEn, titleHi, innerHtml) {
    const card = document.createElement('section');
    card.className = 'modal-section-card';
    card.dataset.sectionKey = key;
    card.innerHTML = `
        <div class="section-card-header">
            <div class="section-card-title-group">
                <h3 class="section-card-title-en">${escapeHtml(titleEn)}</h3>
                <span class="section-card-title-hi">${escapeHtml(titleHi || '')}</span>
            </div>
        </div>
        <div class="section-card-body">
            ${innerHtml}
        </div>
    `;
    return card;
}

function renderPlaceholderNotice(modalName, sectionName) {
    return `
        <div class="placeholder-notice-card">
            <div class="placeholder-notice-title">🏗️ Step 3AF Architecture Foundation Ready</div>
            <div class="placeholder-notice-desc">
                The 12-section architecture for <strong>${escapeHtml(modalName)}</strong> (${escapeHtml(sectionName)}) is loaded and ready. Specific lesson content will be populated in upcoming lesson steps.
            </div>
        </div>
    `;
}

function renderIdentificationContent(data, modalMeta) {
    return `
        ${renderPlaceholderNotice(modalMeta.name, 'Identification')}
        <div style="font-size:0.95rem; line-height:1.6;">
            <p><strong>English:</strong> ${escapeHtml(data.english || '')}</p>
            <p><strong>हिंदी:</strong> ${escapeHtml(data.hindi || '')}</p>
            <p><strong>पहचान नियम:</strong> ${escapeHtml(data.hindiIdentityRule || '')}</p>
        </div>
    `;
}

function renderUsesContent(data, modalMeta) {
    return `
        ${renderPlaceholderNotice(modalMeta.name, 'Uses & Scenarios')}
        <div style="font-size:0.95rem;">
            <p><strong>Primary Use:</strong> ${escapeHtml(data.list?.[0]?.explanation || '')}</p>
            <p><strong>व्याख्या (Hindi):</strong> ${escapeHtml(data.list?.[0]?.explanationHindi || '')}</p>
        </div>
    `;
}

function renderStructureContent(data, modalMeta) {
    return `
        ${renderPlaceholderNotice(modalMeta.name, 'Structure & Formulas')}
        <div style="font-size:0.95rem;">
            ${(data.formulas || []).map(f => `
                <div style="background:#f8fafc; padding:0.75rem 1rem; border-radius:6px; margin-bottom:0.5rem; border:1px solid #e2e8f0;">
                    <strong>${escapeHtml(f.name)}:</strong> <code style="color:#6d28d9; font-weight:700;">${escapeHtml(f.formula)}</code>
                </div>
            `).join('')}
        </div>
    `;
}

function renderSubjectVerbRulesContent(data, modalMeta) {
    return `
        ${renderPlaceholderNotice(modalMeta.name, 'Subject + Verb Rules')}
        <div style="font-size:0.95rem;">
            <p style="color:#047857; font-weight:700;">${escapeHtml(data.goldenRule || '')}</p>
            <p style="color:#065f46;">${escapeHtml(data.goldenRuleHindi || '')}</p>
        </div>
    `;
}

function renderCategoryContent(categoryName, data, modalMeta) {
    return `
        ${renderPlaceholderNotice(modalMeta.name, categoryName)}
        <div style="font-size:0.95rem; color:#64748b;">
            <p>${escapeHtml(data.description || '')}</p>
        </div>
    `;
}

function renderCommonMistakesContent(data, modalMeta) {
    return `
        ${renderPlaceholderNotice(modalMeta.name, 'Common Mistakes')}
        <div style="font-size:0.95rem; color:#64748b;">
            <p>${escapeHtml(data.list?.[0]?.why || '')}</p>
        </div>
    `;
}

function renderSummaryContent(data, modalMeta) {
    return `
        ${renderPlaceholderNotice(modalMeta.name, 'Summary & Revision')}
        <div style="font-size:0.95rem;">
            <p><strong>Golden Formula:</strong> ${escapeHtml(data.goldenFormula || '')}</p>
        </div>
    `;
}

function renderExercisesContent(data, modalMeta) {
    return `
        ${renderPlaceholderNotice(modalMeta.name, 'Practice Exercises')}
        <div style="font-size:0.95rem; color:#64748b;">
            <p>Interactive practice question framework ready for future lesson content.</p>
        </div>
    `;
}

function renderQuizContent(data, modalMeta) {
    return `
        ${renderPlaceholderNotice(modalMeta.name, 'Modal Quiz Engine')}
        <div style="font-size:0.95rem; color:#64748b;">
            <p>Quiz engine integration foundation ready for future lesson content.</p>
        </div>
    `;
}

function renderModalProgressOverviewCard(stats) {
    const card = document.createElement('section');
    card.className = 'modal-section-card modal-progress-card';
    card.style.background = '#fcfaff';
    card.style.border = '1px solid #ddd6fe';

    card.innerHTML = `
        <div style="padding: 1.25rem 1.5rem;">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:0.5rem;">
                <h4 style="margin:0; font-size:1.1rem; font-weight:700; color:#5b21b6;">📊 Modal Progress Tracker</h4>
                <span style="font-size:0.85rem; font-weight:600; color:#6d28d9; background:#edefed; padding:0.2rem 0.6rem; border-radius:12px;">
                    Sections Viewed: ${stats.viewedSectionsCount} / ${stats.totalSectionsCount}
                </span>
            </div>
            <div style="margin-top:0.75rem; background:#e9d5ff; height:8px; border-radius:4px; overflow:hidden;">
                <div style="background:#8b5cf6; height:100%; width:${stats.readingPercent}%; transition:width 0.3s ease;"></div>
            </div>
        </div>
    `;
    return card;
}

function updateModalProgressOverviewCard(layout, stats) {
    const card = layout.querySelector('.modal-progress-card');
    if (card) {
        const newCard = renderModalProgressOverviewCard(stats);
        card.parentNode.replaceChild(newCard, card);
    }
}

function renderModalErrorState(container, invalidId, error = null) {
    document.title = "Modal Not Found - Modal Verbs";

    container.innerHTML = `
        <div class="modal-detail-layout" style="margin-top:2rem;">
            <div class="state-card">
                <span class="state-icon">⚠️</span>
                <h3 class="state-title">Modal Verb Not Found</h3>
                <span class="state-hindi-title">मोडल वर्ब उपलब्ध नहीं है</span>
                <p class="state-desc">
                    The requested modal verb ID "${escapeHtml(invalidId || 'none')}" does not exist in the central modals data system.
                </p>
                <a href="modals.html" class="btn btn-primary">Return to All Modal Verbs</a>
            </div>
        </div>
    `;
}
