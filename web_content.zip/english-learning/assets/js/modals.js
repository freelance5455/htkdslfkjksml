/**
 * Controller: Modal Verbs Listing Page (pages/modals.html & modal-verbs/index.html)
 * Displays grid of all 13 Modal Verbs with cards powered by components/modal-card.js.
 */

import { createPlatformHeader } from '../../components/platform-header.js';
import { createPlatformSidebar } from '../../components/platform-sidebar.js';
import { getAllModals } from '../../data/modals.js';
import { createModalCard } from '../../components/modal-card.js';
import { escapeHtml } from './modal-utils.js';

document.addEventListener('DOMContentLoaded', () => {
    initModalsPage();
});

function initModalsPage() {
    const headerContainer = document.getElementById('header-container');
    const sidebarContainer = document.getElementById('sidebar-container');
    const mainContainer = document.getElementById('modals-main-container');

    // Detect if page is inside modal-verbs/ subfolder or pages/ subfolder
    const isSubfolder = window.location.pathname.includes('/modal-verbs/');
    const basePath = isSubfolder ? "../" : "../"; // Both pages/ and modal-verbs/ are 1 level deep relative to root

    // 1. Render Platform Header
    if (headerContainer) {
        const headerEl = createPlatformHeader({
            title: "English Learning Platform",
            subtitle: "Modal Verbs - मोडल वर्ब्स",
            showSidebarToggle: true,
            basePath: basePath,
            onMenuToggle: () => {
                const sidebarEl = document.querySelector('.platform-sidebar');
                if (sidebarEl) {
                    sidebarEl.classList.toggle('is-collapsed');
                }
            }
        });
        headerContainer.appendChild(headerEl);
    }

    // 2. Render Platform Sidebar
    if (sidebarContainer) {
        const sidebarInstance = createPlatformSidebar({
            activeId: "modal-verbs",
            basePath: basePath,
            collapsed: false
        });
        sidebarContainer.appendChild(sidebarInstance);
    }

    // 3. Render Modal Verbs Listing View
    if (mainContainer) {
        mainContainer.innerHTML = '';
        const allModals = getAllModals();

        const containerLayout = document.createElement('div');
        containerLayout.className = 'modals-listing-container';

        // Page Header
        containerLayout.innerHTML = `
            <div class="modals-page-header">
                <span class="header-badge">English Grammar Curriculum</span>
                <h1 class="main-title">Modal Verbs Module</h1>
                <span class="hindi-title">मोडल वर्ब्स - सहायक क्रियाएँ</span>
                <p class="header-desc">
                    Explore all 13 English Modal Verbs (Can, Could, May, Might, Will, Would, Shall, Should, Must, Ought to, Need, Dare, Used to). Master permission, ability, obligation, advice, and possibilities in simple Hindi & English.
                </p>
            </div>

            <div class="modals-grid-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem;">
                <h3 style="font-size:1.25rem; font-weight:700; margin:0;">All 13 Modal Verbs (${allModals.length})</h3>
                <span style="font-size:0.88rem; color:#64748b;">Click any card to explore lesson details</span>
            </div>
        `;

        // Render Grid of 13 Cards
        const grid = document.createElement('div');
        grid.className = 'modals-grid';

        allModals.forEach(modalMeta => {
            const cardEl = createModalCard(modalMeta, { basePath: basePath });
            grid.appendChild(cardEl);
        });

        containerLayout.appendChild(grid);
        mainContainer.appendChild(containerLayout);
    }
}
