/**
 * Central Lesson Data for Past Perfect Tense (पूर्ण भूतकाल)
 * Single Source of Truth for Past Perfect Tense Module.
 * Follows proven reference architecture established in Simple Present and Past Continuous.
 */

const pastPerfectLesson = {
    id: "past-perfect",
    title: "Past Perfect",
    titleHindi: "पूर्ण भूतकाल (Subject + had + V3)",
    description: "Learn Past Perfect Tense in simple Hindi & English: Subject + had + V3 + Object.",

    sections: {
        // 1. Identification / पहचान और अवधारणा
        identification: {
            title: "Identification",
            titleHindi: "पहचान और अवधारणा (Identification & Concept)",
            english: "Past Perfect Tense is used to describe an action that was completed BEFORE another action or specific time point in the past.",
            hindi: "Past Perfect Tense का प्रयोग ऐसे कार्य को व्यक्त करने के लिए किया जाता है जो भूतकाल में किसी दूसरे कार्य या निश्चित समय से पहले पूरा हो चुका था।",
            hindiIdentityRule: "पहचान (Hindi Clues): वाक्य की मुख्य क्रिया के अंत में - कर चुका था / कर चुकी थी / कर चुके थे / कर लिया था / दिया था / गया था आदि आता है।",
            points: [
                {
                    english: "Core Concept: Action A happened before Action B in the past timeline.",
                    hindi: "मूल अवधारणा: भूतकाल की समयरेखा में कार्य A, कार्य B से पहले घटित हुआ था।"
                },
                {
                    english: "Auxiliary Verb: Always use 'had' for ALL subjects (I, You, He, She, It, We, They, Singular, Plural).",
                    hindi: "सहायक क्रिया: सभी कर्ताओं (I, You, He, She, It, We, They, एकवचन, बहुवचन) के साथ हमेशा 'had' का प्रयोग होता है।"
                },
                {
                    english: "Main Verb: Always use V3 (Past Participle form of the verb).",
                    hindi: "मुख्य क्रिया: हमेशा V3 (Past Participle) रूप का प्रयोग किया जाता है।"
                },
                {
                    english: "Time Connectives: Frequently used with before, after, when, and by the time.",
                    hindi: "समय सूचक शब्द: before, after, when, और by + past time के साथ अक्सर प्रयोग किया जाता है।"
                }
            ],
            comparison: {
                title: "Concept Comparison: Past Perfect vs Simple Past vs Present Perfect",
                simplePast: {
                    name: "Simple Past (सामान्य भूतकाल)",
                    formula: "Subject + V2 + Object",
                    concept: "Single completed action in the past (किया / गया / देखा)",
                    example: "I finished the report yesterday. (मैंने कल रिपोर्ट पूरी की।)"
                },
                pastPerfect: {
                    name: "Past Perfect (पूर्ण भूतकाल)",
                    formula: "Subject + had + V3 + Object",
                    concept: "Action completed before another past event (कर चुका था)",
                    example: "I had finished the report before the boss arrived. (बॉस के आने से पहले मैं रिपोर्ट पूरी कर चुका था।)"
                },
                presentPerfect: {
                    name: "Present Perfect (पूर्ण वर्तमान काल)",
                    formula: "Subject + has/have + V3 + Object",
                    concept: "Action completed in past with connection to PRESENT (कर लिया है)",
                    example: "I have finished the report. (मैंने रिपोर्ट पूरी कर ली है - अभी टेबल पर है।)"
                }
            }
        },

        // 2. Uses & Scenarios / उपयोग और परिस्थितियाँ (Exactly 5 Major Uses)
        uses: {
            title: "Uses & Scenarios",
            titleHindi: "कब प्रयोग करें (5 मुख्य उपयोग)",
            intro: "Past Perfect Tense is used to clarify sequence of past events, show past completed goals, and express cause-and-effect in past contexts.",
            introHindi: "Past Perfect Tense का प्रयोग भूतकाल की दो घटनाओं के क्रम को स्पष्ट करने और पहले से संपन्न कार्यों को दर्शाने के लिए किया जाता है।",
            list: [
                {
                    title: "1. One Past Action Happened Before Another Past Action",
                    titleHindi: "भूतकाल में किसी दूसरे कार्य से पहले घटित हुआ कार्य",
                    explanation: "Used to show that an action was completed before a second past action took place.",
                    explanationHindi: "यह दर्शाने के लिए कि एक कार्य दूसरे अतीत के कार्य से पहले ही समाप्त हो चुका था।",
                    whyUsed: "Establishes a clear chronological order between two past events.",
                    whyUsedHindi: "दो अतीत की घटनाओं के बीच स्पष्ट समय क्रम (timeline sequence) स्थापित करता है।",
                    examples: [
                        { english: "She had left before I arrived at the station.", hindi: "मेरे स्टेशन पहुँचने से पहले वह जा चुकी थी।", note: "Earlier: she had left | Later: I arrived" },
                        { english: "They had finished dinner before the movie started.", hindi: "फिल्म शुरू होने से पहले वे खाना खा चुके थे।", note: "Earlier: had finished | Later: movie started" },
                        { english: "The patient had died before the doctor arrived.", hindi: "डॉक्टर के आने से पहले मरीज की मृत्यु हो चुकी थी।", note: "Earlier: had died | Later: doctor arrived" }
                    ]
                },
                {
                    title: "2. To Make the Earlier Action Clear in a Past Sequence",
                    titleHindi: "अतीत के घटनाक्रम में पहले कार्य को स्पष्ट करना (When / As soon as)",
                    explanation: "Highlights which action occurred first when two actions are described in a narrative.",
                    explanationHindi: "जब कहानी या विवरण में दो कार्य बताए जाएं, तो पहले घटित कार्य को स्पष्ट करने के लिए।",
                    whyUsed: "Removes ambiguity about which event happened first.",
                    whyUsedHindi: "कौन सा कार्य पहले हुआ, इस बारे में संदेह को दूर करता है।",
                    examples: [
                        { english: "When I reached the office, the meeting had already started.", hindi: "जब मैं दफ़्तर पहुँचा, बैठक पहले ही शुरू हो चुकी थी।", note: "Meeting started first" },
                        { english: "When we arrived at the hall, the play had begun.", hindi: "जब हम हॉल पहुंचे, नाटक शुरू हो चुका था।", note: "Play began before arrival" },
                        { english: "As soon as he had locked the door, the bell rang.", hindi: "जैसे ही उसने दरवाजा बंद कर लिया था, घंटी बजी।", note: "Locking completed first" }
                    ]
                },
                {
                    title: "3. Completed Action Before a Specific Past Time (By + time)",
                    titleHindi: "अतीत के किसी निश्चित समय से पहले पूरा हुआ कार्य (By + past time)",
                    explanation: "Used with 'by 8 PM', 'by last week', 'by 2020' to show completion by a deadline.",
                    explanationHindi: "भूतकाल के किसी निश्चित समय सीमा (deadline) तक कार्य के पूर्ण होने को दर्शाने के लिए।",
                    whyUsed: "Measures completion against a past clock or calendar deadline.",
                    whyUsedHindi: "अतीत की समय-सीमा के संदर्भ में कार्य की पूर्णता को मापता है।",
                    examples: [
                        { english: "By 8 PM, I had finished all my homework.", hindi: "रात 8 बजे तक, मैं अपना सारा गृहकार्य पूरा कर चुका था।", note: "Deadline: By 8 PM" },
                        { english: "By last year, they had constructed the new bridge.", hindi: "पिछले साल तक, वे नया पुल बना चुके थे।", note: "Deadline: By last year" },
                        { english: "She had completed the project by 5 o'clock.", hindi: "वह शाम 5 बजे तक प्रोजेक्ट पूरा कर चुकी थी।", note: "Deadline: by 5 o'clock" }
                    ]
                },
                {
                    title: "4. Past Cause and Result Relationship",
                    titleHindi: "अतीत में कारण और परिणाम का संबंध (Past Cause & Result)",
                    explanation: "An earlier action (Past Perfect) caused a result state in the past.",
                    explanationHindi: "भूतकाल के किसी पहले कार्य (Past Perfect) के कारण अतीत में कोई स्थिति बनी।",
                    whyUsed: "Explains the underlying reason for a past situation or emotional state.",
                    whyUsedHindi: "अतीत की किसी स्थिति या भावना का कारण स्पष्ट करता है।",
                    examples: [
                        { english: "He was very tired because he had worked all night.", hindi: "वह बहुत थका हुआ था क्योंकि उसने रात भर काम किया था।", note: "Cause: had worked | Result: was tired" },
                        { english: "She failed the exam because she had not prepared well.", hindi: "वह परीक्षा में असफल हो गई क्योंकि उसने अच्छी तैयारी नहीं की थी।", note: "Cause: hadn't prepared | Result: failed" },
                        { english: "The ground was wet because it had rained heavily.", hindi: "ज़मीन गीली थी क्योंकि भारी बारिश हुई थी।", note: "Cause: had rained | Result: ground was wet" }
                    ]
                },
                {
                    title: "5. Reported Speech and Past Context Reference",
                    titleHindi: "परोक्ष कथन और अतीत के संदर्भ में बात करना (Reported Speech)",
                    explanation: "When reporting what someone said about an earlier past event.",
                    explanationHindi: "जब किसी के द्वारा पूर्व में कहे गए या किए गए कार्य को Reported Speech में बताया जाए।",
                    whyUsed: "Maintains tense harmony when moving from Present Perfect/Simple Past to indirect speech.",
                    whyUsedHindi: "Indirect Speech में सही काल-संगति (tense harmony) बनाए रखता है।",
                    examples: [
                        { english: "Rahul told me that he had bought a new car.", hindi: "राहुल ने मुझे बताया कि उसने एक नई कार खरीद ली थी।", note: "Reported past action" },
                        { english: "She said that she had already seen that movie.", hindi: "उसने कहा कि वह वह फिल्म पहले ही देख चुकी थी।", note: "Reported completion" },
                        { english: "The manager confirmed that they had received the file.", hindi: "मैनेजर ने पुष्टि की कि उन्हें फाइल मिल चुकी थी।", note: "Reported receipt of file" }
                    ]
                }
            ]
        },

        // 3. Sentence Structure & Formulas / वाक्य संरचना और सूत्र
        structure: {
            title: "Structure & Formulas",
            titleHindi: "वाक्य संरचना और सूत्र (Formulas)",
            intro: "Past Perfect formulas use HAD + V3 for all subjects across Positive, Negative, Interrogative, and WH Questions.",
            introHindi: "Past Perfect में सभी कर्ताओं के साथ HAD + V3 का प्रयोग किया जाता है।",
            formulas: {
                positive: {
                    name: "Positive Formula",
                    rule: "Subject + had + V3 + Object / Complement",
                    example: "She had written the report.",
                    breakdown: {
                        subject: "She",
                        aux: "had",
                        verb: "written (V3 of write)",
                        object: "the report"
                    }
                },
                negative: {
                    name: "Negative Formula",
                    rule: "Subject + had + not (hadn't) + V3 + Object",
                    example: "She had not (hadn't) written the report.",
                    breakdown: {
                        subject: "She",
                        aux: "had not / hadn't",
                        verb: "written (V3)",
                        object: "the report"
                    }
                },
                interrogative: {
                    name: "Interrogative Formula (Yes/No)",
                    rule: "Had + Subject + V3 + Object?",
                    example: "Had she written the report?",
                    breakdown: {
                        aux: "Had",
                        subject: "she",
                        verb: "written (V3)",
                        object: "the report?"
                    }
                },
                whQuestion: {
                    name: "WH Question Formula",
                    rule: "WH-word + had + Subject + V3 + Object?",
                    example: "Why had she written the report?",
                    breakdown: {
                        wh: "Why",
                        aux: "had",
                        subject: "she",
                        verb: "written (V3)",
                        object: "the report?"
                    }
                }
            }
        },

        // 4. Subject + Verb Rules / कर्ता-क्रिया नियम
        subjectVerbRules: {
            title: "Subject + Verb Rules",
            titleHindi: "कर्ता + क्रिया नियम (Golden Rule: ALL SUBJECTS ➔ HAD + V3)",
            goldenRule: "Golden Rule: Every subject (I, You, He, She, It, We, They, Singular, Plural) takes HAD + V3 in Past Perfect.",
            goldenRuleHindi: "स्वर्ण नियम: Past Perfect Tense में सभी कर्ताओं (I, You, He, She, It, We, They, एकवचन, बहुवचन) के साथ केवल HAD + V3 का प्रयोग होता है।",
            
            table: [
                { subject: "I", aux: "had", verb: "V3 (gone / done)", example: "I had finished." },
                { subject: "You", aux: "had", verb: "V3 (gone / done)", example: "You had finished." },
                { subject: "He", aux: "had", verb: "V3 (gone / done)", example: "He had finished." },
                { subject: "She", aux: "had", verb: "V3 (gone / done)", example: "She had finished." },
                { subject: "It", aux: "had", verb: "V3 (gone / done)", example: "It had rained." },
                { subject: "We", aux: "had", verb: "V3 (gone / done)", example: "We had finished." },
                { subject: "They", aux: "had", verb: "V3 (gone / done)", example: "They had finished." },
                { subject: "Singular Name (Rahul)", aux: "had", verb: "V3 (gone / done)", example: "Rahul had finished." },
                { subject: "Plural Noun (Students)", aux: "had", verb: "V3 (gone / done)", example: "Students had finished." }
            ],

            v3Rules: {
                title: "V3 (Past Participle) Form Rules",
                titleHindi: "V3 (Past Participle) बनाने के मुख्य नियम",
                intro: "V3 is mandatory in Past Perfect. Never use V1 or V2 after 'had'.",
                introHindi: "'had' के बाद हमेशा V3 का प्रयोग करें। भूलकर भी V1 या V2 न लगाएं।",
                regularVerbs: "Regular Verbs: Add -ed or -d (e.g. work ➔ worked ➔ worked, finish ➔ finished ➔ finished, play ➔ played ➔ played).",
                irregularVerbs: "Irregular Verbs: Change forms completely (e.g. go ➔ went ➔ gone, write ➔ wrote ➔ written, see ➔ saw ➔ seen, eat ➔ ate ➔ eaten, take ➔ took ➔ taken, do ➔ did ➔ done).",
                warning: "❌ Wrong: She had went (had + V2) | She had go (had + V1)\n✅ Correct: She had gone (had + V3)"
            }
        },

        // 5. Positive Sentences / सकारात्मक वाक्य (30 Items)
        positive: {
            title: "Positive Sentences",
            titleHindi: "सकारात्मक वाक्य (Subject + had + V3 + Object)",
            formula: "Subject + had + V3 + Object/Complement",
            explanation: "Expresses actions that were completed prior to another past event or deadline.",
            explanationHindi: "सकारात्मक वाक्यों में सभी कर्ताओं के साथ 'had' और मुख्य क्रिया का V3 रूप लगाएं।",
            
            sentences: {
                easy: [
                    { id: "pos-e1", english: "I had finished my work before 8 PM.", hindi: "मैं रात 8 बजे से पहले अपना काम पूरा कर चुका था।", subject: "I", aux: "had", verb: "finished", object: "my work before 8 PM" },
                    { id: "pos-e2", english: "She had left the office before it rained.", hindi: "बारिश होने से पहले वह दफ़्तर से जा चुकी थी।", subject: "She", aux: "had", verb: "left", object: "the office before it rained" },
                    { id: "pos-e3", english: "They had completed the project yesterday.", hindi: "वे कल प्रोजेक्ट पूरा कर चुके थे।", subject: "They", aux: "had", verb: "completed", object: "the project yesterday" },
                    { id: "pos-e4", english: "We had eaten dinner when he arrived.", hindi: "जब वह पहुँचा तब हम रात का खाना खा चुके थे।", subject: "We", aux: "had", verb: "eaten", object: "dinner when he arrived" },
                    { id: "pos-e5", english: "He had already cleaned his room.", hindi: "वह पहले ही अपना कमरा साफ़ कर चुका था।", subject: "He", aux: "had", verb: "cleaned", object: "his room already" },
                    { id: "pos-e6", english: "Rahul had closed the shop by 9 PM.", hindi: "राहुल रात 9 बजे तक दुकान बंद कर चुका था।", subject: "Rahul", aux: "had", verb: "closed", object: "the shop by 9 PM" },
                    { id: "pos-e7", english: "You had seen that movie earlier.", hindi: "आप वह फिल्म पहले देख चुके थे।", subject: "You", aux: "had", verb: "seen", object: "that movie earlier" },
                    { id: "pos-e8", english: "The train had departed when we reached.", hindi: "जब हम पहुँचे तब ट्रेन छूट चुकी थी।", subject: "The train", aux: "had", verb: "departed", object: "when we reached" },
                    { id: "pos-e9", english: "My mother had cooked food before guests arrived.", hindi: "मेहमानों के आने से पहले मेरी माँ खाना बना चुकी थीं।", subject: "My mother", aux: "had", verb: "cooked", object: "food before guests arrived" },
                    { id: "pos-e10", english: "The sun had set before we reached home.", hindi: "हमारे घर पहुँचने से पहले सूरज ढल चुका था।", subject: "The sun", aux: "had", verb: "set", object: "before we reached home" }
                ],
                medium: [
                    { id: "pos-m1", english: "The doctor had examined the patient before the surgeon came.", hindi: "सर्जन के आने से पहले डॉक्टर मरीज की जांच कर चुके थे।", subject: "The doctor", aux: "had", verb: "examined", object: "the patient before surgeon came" },
                    { id: "pos-m2", english: "She had saved enough money before buying the car.", hindi: "कार खरीदने से पहले वह पर्याप्त पैसे बचा चुकी थी।", subject: "She", aux: "had", verb: "saved", object: "enough money before buying car" },
                    { id: "pos-m3", english: "The team had won three matches before the finals.", hindi: "टीम फाइनल से पहले तीन मैच जीत चुकी थी।", subject: "The team", aux: "had", verb: "won", object: "three matches before finals" },
                    { id: "pos-m4", english: "I had submitted the report before the deadline passed.", hindi: "समय-सीमा समाप्त होने से पहले मैं रिपोर्ट जमा कर चुका था।", subject: "I", aux: "had", verb: "submitted", object: "the report before deadline passed" },
                    { id: "pos-m5", english: "They had locked all windows before leaving the house.", hindi: "घर छोड़ने से पहले वे सभी खिड़कियाँ बंद कर चुके थे।", subject: "They", aux: "had", verb: "locked", object: "all windows before leaving" },
                    { id: "pos-m6", english: "The teacher had explained the lesson before the bell rang.", hindi: "घंटी बजने से पहले शिक्षक पाठ समझा चुके थे।", subject: "The teacher", aux: "had", verb: "explained", object: "the lesson before bell rang" },
                    { id: "pos-m7", english: "We had booked the hotel rooms two months in advance.", hindi: "हम दो महीने पहले ही होटल के कमरे बुक कर चुके थे।", subject: "We", aux: "had", verb: "booked", object: "hotel rooms two months in advance" },
                    { id: "pos-m8", english: "He had repaired the motor before the power restored.", hindi: "बिजली बहाल होने से पहले वह मोटर ठीक कर चुका था।", subject: "He", aux: "had", verb: "repaired", object: "the motor before power restored" },
                    { id: "pos-m9", english: "The passengers had boarded the flight before final call.", hindi: "अंतिम कॉल से पहले यात्री उड़ान में सवार हो चुके थे।", subject: "The passengers", aux: "had", verb: "boarded", object: "the flight before final call" },
                    { id: "pos-m10", english: "She had packed her luggage the previous night.", hindi: "वह पिछली रात ही अपना सामान पैक कर चुकी थी।", subject: "She", aux: "had", verb: "packed", object: "her luggage previous night" }
                ],
                hard: [
                    { id: "pos-h1", english: "The software engineers had resolved the security vulnerability before the breach occurred.", hindi: "उल्लंघन होने से पहले सॉफ्टवेयर इंजीनियर सुरक्षा भेद्यता को ठीक कर चुके थे।", subject: "The software engineers", aux: "had", verb: "resolved", object: "security vulnerability before breach" },
                    { id: "pos-h2", english: "The management had approved the budget allocation before launching the campaign.", hindi: "अभियान शुरू करने से पहले प्रबंधन बजट आवंटन को मंजूरी दे चुका था।", subject: "The management", aux: "had", verb: "approved", object: "budget allocation before campaign" },
                    { id: "pos-h3", english: "Scientists had published their observations before the international conference.", hindi: "अंतर्राष्ट्रीय सम्मेलन से पहले वैज्ञानिक अपने अवलोकनों को प्रकाशित कर चुके थे।", subject: "Scientists", aux: "had", verb: "published", object: "observations before conference" },
                    { id: "pos-h4", english: "The heavy rainfall had flooded the low-lying areas before emergency teams deployed.", hindi: "आपतकालीन टीमों के तैनात होने से पहले भारी बारिश निचले इलाकों में बाढ़ ला चुकी थी।", subject: "The heavy rainfall", aux: "had", verb: "flooded", object: "low-lying areas before deployment" },
                    { id: "pos-h5", english: "By the time the audit began, the accountant had reconciled all ledger entries.", hindi: "जब तक ऑडिट शुरू हुआ, लेखाकार सभी बहीखाता प्रविष्टियों का मिलान कर चुका था।", subject: "The accountant", aux: "had", verb: "reconciled", object: "all ledger entries by audit time" },
                    { id: "pos-h6", english: "The authorities had evacuated the coastal villagers before the cyclone hit.", hindi: "चक्रवात आने से पहले अधिकारियों ने तटीय ग्रामीणों को बाहर निकाल लिया था।", subject: "The authorities", aux: "had", verb: "evacuated", object: "coastal villagers before cyclone" },
                    { id: "pos-h7", english: "She had mastered three programming languages before graduating from university.", hindi: "विश्वविद्यालय से स्नातक होने से पहले वह तीन प्रोग्रामिंग भाषाओं में महारत हासिल कर चुकी थी।", subject: "She", aux: "had", verb: "mastered", object: "three languages before graduation" },
                    { id: "pos-h8", english: "The court had issued a stay order before the demolition work started.", hindi: "तोड़फोड़ का काम शुरू होने से पहले अदालत रोक का आदेश जारी कर चुकी थी।", subject: "The court", aux: "had", verb: "issued", object: "a stay order before demolition" },
                    { id: "pos-h9", english: "The research laboratory had synthesized the compound before filing the patent.", hindi: "पेटेंट दाखिल करने से पहले अनुसंधान प्रयोगशाला यौगिक का संश्लेषण कर चुकी थी।", subject: "The research laboratory", aux: "had", verb: "synthesized", object: "compound before patent filing" },
                    { id: "pos-h10", english: "The government had implemented strict measures before the festival season.", hindi: "त्योहारी सीजन से पहले सरकार कड़े कदम लागू कर चुकी थी।", subject: "The government", aux: "had", verb: "implemented", object: "strict measures before festival" }
                ]
            }
        },

        // 6. Negative Sentences / नकारात्मक वाक्य (30 Items)
        negative: {
            title: "Negative Sentences",
            titleHindi: "नकारात्मक वाक्य (Subject + had + not / hadn't + V3)",
            formula: "Subject + had + not (hadn't) + V3 + Object",
            explanation: "Use 'had not' or contraction 'hadn't' followed by V3 to state an action was not completed before a past reference.",
            explanationHindi: "नकारात्मक वाक्यों में 'had' के बाद 'not' (hadn't) और V3 का प्रयोग करें।",
            
            sentences: {
                easy: [
                    { id: "neg-e1", english: "I had not finished my work when you called.", hindi: "जब आपने फोन किया तब मैंने काम पूरा नहीं किया था।", subject: "I", aux: "had not", verb: "finished", object: "my work when you called" },
                    { id: "neg-e2", english: "She hadn't received the email before the meeting.", hindi: "बैठक से पहले उसे ईमेल प्राप्त नहीं हुआ था।", subject: "She", aux: "hadn't", verb: "received", object: "the email before meeting" },
                    { id: "neg-e3", english: "They had not left the hall before 9 PM.", hindi: "वे रात 9 बजे से पहले हॉल नहीं छोड़ चुके थे।", subject: "They", aux: "had not", verb: "left", object: "the hall before 9 PM" },
                    { id: "neg-e4", english: "We hadn't seen him before yesterday.", hindi: "हमने कल से पहले उसे नहीं देखा था।", subject: "We", aux: "hadn't", verb: "seen", object: "him before yesterday" },
                    { id: "neg-e5", english: "He had not paid the electric bill on time.", hindi: "उसने समय पर बिजली बिल का भुगतान नहीं किया था।", subject: "He", aux: "had not", verb: "paid", object: "electric bill on time" },
                    { id: "neg-e6", english: "Rahul hadn't completed his assignment.", hindi: "राहुल ने अपना असाइनमेंट पूरा नहीं किया था।", subject: "Rahul", aux: "hadn't", verb: "completed", object: "his assignment" },
                    { id: "neg-e7", english: "You had not informed the manager in advance.", hindi: "आपने मैनेजर को पहले से सूचित नहीं किया था।", subject: "You", aux: "had not", verb: "informed", object: "the manager in advance" },
                    { id: "neg-e8", english: "The rain hadn't stopped when we started our journey.", hindi: "जब हमने यात्रा शुरू की तब बारिश नहीं रुकी थी।", subject: "The rain", aux: "hadn't", verb: "stopped", object: "when we started journey" },
                    { id: "neg-e9", english: "She had not visited Delhi before last month.", hindi: "वह पिछले महीने से पहले दिल्ली नहीं गई थी।", subject: "She", aux: "had not", verb: "visited", object: "Delhi before last month" },
                    { id: "neg-e10", english: "They hadn't locked the main gate.", hindi: "उन्होंने मुख्य गेट बंद नहीं किया था।", subject: "They", aux: "hadn't", verb: "locked", object: "the main gate" }
                ],
                medium: [
                    { id: "neg-m1", english: "The doctor had not diagnosed the disease before blood test.", hindi: "ब्लड टेस्ट से पहले डॉक्टर बीमारी का निदान नहीं कर पाए थे।", subject: "The doctor", aux: "had not", verb: "diagnosed", object: "the disease before test" },
                    { id: "neg-m2", english: "She hadn't taken her medicines before breakfast.", hindi: "उसने नाश्ते से पहले अपनी दवाएं नहीं ली थीं।", subject: "She", aux: "hadn't", verb: "taken", object: "her medicines before breakfast" },
                    { id: "neg-m3", english: "The team had not prepared well for the presentation.", hindi: "टीम ने प्रस्तुति के लिए अच्छी तैयारी नहीं की थी।", subject: "The team", aux: "had not", verb: "prepared", object: "well for presentation" },
                    { id: "neg-m4", english: "We hadn't received confirmation from the venue.", hindi: "हमें स्थल से पुष्टि प्राप्त नहीं हुई थी।", subject: "We", aux: "hadn't", verb: "received", object: "confirmation from venue" },
                    { id: "neg-m5", english: "He had not checked the car tire pressure before long drive.", hindi: "लंबी ड्राइव से पहले उसने कार के टायर का दबाव नहीं जाँचा था।", subject: "He", aux: "had not", verb: "checked", object: "car tire pressure before drive" },
                    { id: "neg-m6", english: "The students hadn't understood the complex theorem.", hindi: "छात्रों ने जटिल प्रमेय नहीं समझा था।", subject: "The students", aux: "hadn't", verb: "understood", object: "the complex theorem" },
                    { id: "neg-m7", english: "She had not verified the document signatures.", hindi: "उसने दस्तावेज़ के हस्ताक्षरों को सत्यापित नहीं किया था।", subject: "She", aux: "had not", verb: "verified", object: "document signatures" },
                    { id: "neg-m8", english: "The bank hadn't updated their server database.", hindi: "बैंक ने अपने सर्वर डेटाबेस को अपडेट नहीं किया था।", subject: "The bank", aux: "hadn't", verb: "updated", object: "their server database" },
                    { id: "neg-m9", english: "They had not renewed their passport before booking tickets.", hindi: "टिकट बुक करने से पहले उन्होंने अपना पासपोर्ट नवीनीकृत नहीं कराया था।", subject: "They", aux: "had not", verb: "renewed", object: "their passport before booking" },
                    { id: "neg-m10", english: "I hadn't realized the mistake until he pointed it out.", hindi: "जब तक उसने नहीं बताया, मुझे गलती का एहसास नहीं हुआ था।", subject: "I", aux: "hadn't", verb: "realized", object: "the mistake until pointed out" }
                ],
                hard: [
                    { id: "neg-h1", english: "The board of directors had not sanctioned the financial expenditure before quarter end.", hindi: "निदेशक मंडल ने तिमाही के अंत से पहले वित्तीय व्यय को मंजूरी नहीं दी थी।", subject: "The board of directors", aux: "had not", verb: "sanctioned", object: "financial expenditure before quarter end" },
                    { id: "neg-h2", english: "The quality assurance team hadn't detected the bug prior to deployment.", hindi: "गुणवत्ता आश्वासन टीम ने तैनाती से पहले बग का पता नहीं लगाया था।", subject: "The quality assurance team", aux: "hadn't", verb: "detected", object: "the bug prior to deployment" },
                    { id: "neg-h3", english: "The municipality had not cleared the drainage system before monsoon.", hindi: "नगरपालिका ने मानसून से पहले जल निकासी व्यवस्था की सफाई नहीं की थी।", subject: "The municipality", aux: "had not", verb: "cleared", object: "drainage system before monsoon" },
                    { id: "neg-h4", english: "The research scholars hadn't published their peer-reviewed findings.", hindi: "शोध विद्वानों ने अपने सहकर्मी-समीक्षित निष्कर्षों को प्रकाशित नहीं किया था।", subject: "The research scholars", aux: "hadn't", verb: "published", object: "peer-reviewed findings" },
                    { id: "neg-h5", english: "The security guards had not inspected the rear exit gate.", hindi: "सुरक्षा गार्डों ने पिछले निकास द्वार की जांच नहीं की थी।", subject: "The security guards", aux: "had not", verb: "inspected", object: "rear exit gate" },
                    { id: "neg-h6", english: "The airline hadn't notified passengers about the flight delay.", hindi: "एयरलाइन ने यात्रियों को उड़ान में देरी की सूचना नहीं दी थी।", subject: "The airline", aux: "hadn't", verb: "notified", object: "passengers about delay" },
                    { id: "neg-h7", english: "The company had not backed up their cloud servers before cyber attack.", hindi: "साइबर हमले से पहले कंपनी ने अपने क्लाउड सर्वर का बैकअप नहीं लिया था।", subject: "The company", aux: "had not", verb: "backed up", object: "cloud servers before cyber attack" },
                    { id: "neg-h8", english: "The investigators hadn't found any conclusive evidence.", hindi: "जांचकर्ताओं को कोई निर्णायक सबूत नहीं मिला था।", subject: "The investigators", aux: "hadn't", verb: "found", object: "any conclusive evidence" },
                    { id: "neg-h9", english: "The government had not issued clear guidelines before lockdown.", hindi: "लॉकडाउन से पहले सरकार ने स्पष्ट दिशा-निर्देश जारी नहीं किए थे।", subject: "The government", aux: "had not", verb: "issued", object: "clear guidelines before lockdown" },
                    { id: "neg-h10", english: "The contractor hadn't completed the foundation work on schedule.", hindi: "ठेकेदार ने समय पर नींव का काम पूरा नहीं किया था।", subject: "The contractor", aux: "hadn't", verb: "completed", object: "foundation work on schedule" }
                ]
            }
        },

        // 7. Interrogative Sentences / प्रश्नवाचक वाक्य (30 Items)
        interrogative: {
            title: "Interrogative Sentences",
            titleHindi: "प्रश्नवाचक वाक्य (Had + Subject + V3 + Object?)",
            formula: "Had + Subject + V3 + Object?",
            explanation: "Start with HAD followed by Subject and V3 for Yes/No past completed questions.",
            explanationHindi: "प्रश्नवाचक वाक्यों में 'Had' से शुरुआत करें, फिर कर्ता और क्रिया का V3 रूप लगाएं।",
            
            sentences: {
                easy: [
                    { id: "int-e1", english: "Had you finished your work before he arrived?", hindi: "क्या आप उसके आने से पहले अपना काम पूरा कर चुके थे?", subject: "you", aux: "Had", verb: "finished", object: "your work before he arrived" },
                    { id: "int-e2", english: "Had she left the building before 6 PM?", hindi: "क्या वह शाम 6 बजे से पहले इमारत से जा चुकी थी?", subject: "she", aux: "Had", verb: "left", object: "the building before 6 PM" },
                    { id: "int-e3", english: "Had they completed the assignment yesterday?", hindi: "क्या वे कल असाइनमेंट पूरा कर चुके थे?", subject: "they", aux: "Had", verb: "completed", object: "the assignment yesterday" },
                    { id: "int-e4", english: "Had we met him before the conference?", hindi: "क्या हम सम्मेलन से पहले उनसे मिले थे?", subject: "we", aux: "Had", verb: "met", object: "him before conference" },
                    { id: "int-e5", english: "Had he paid the hotel bill?", hindi: "क्या उसने होटल का बिल चुका दिया था?", subject: "he", aux: "Had", verb: "paid", object: "the hotel bill" },
                    { id: "int-e6", english: "Had Rahul informed you earlier?", hindi: "क्या राहुल ने आपको पहले ही सूचित कर दिया था?", subject: "Rahul", aux: "Had", verb: "informed", object: "you earlier" },
                    { id: "int-e7", english: "Had the sun set when you reached home?", hindi: "क्या जब आप घर पहुंचे तब सूरज ढल चुका था?", subject: "the sun", aux: "Had", verb: "set", object: "when you reached home" },
                    { id: "int-e8", english: "Had the train left the station?", hindi: "क्या ट्रेन स्टेशन से छूट चुकी थी?", subject: "the train", aux: "Had", verb: "left", object: "the station" },
                    { id: "int-e9", english: "Had she cooked dinner before guests arrived?", hindi: "क्या मेहमानों के आने से पहले वह खाना बना चुकी थी?", subject: "she", aux: "Had", verb: "cooked", object: "dinner before guests arrived" },
                    { id: "int-e10", english: "Had they locked the main gate?", hindi: "क्या उन्होंने मुख्य गेट बंद कर दिया था?", subject: "they", aux: "Had", verb: "locked", object: "the main gate" }
                ],
                medium: [
                    { id: "int-m1", english: "Had the doctor examined the patient before surgery?", hindi: "क्या सर्जरी से पहले डॉक्टर ने मरीज की जांच कर ली थी?", subject: "the doctor", aux: "Had", verb: "examined", object: "the patient before surgery" },
                    { id: "int-m2", english: "Had she saved enough money before buying house?", hindi: "क्या घर खरीदने से पहले उसने पर्याप्त पैसे बचा लिए थे?", subject: "she", aux: "Had", verb: "saved", object: "enough money before buying house" },
                    { id: "int-m3", english: "Had the team won any trophy before this match?", hindi: "क्या टीम ने इस मैच से पहले कोई ट्रॉफी जीती थी?", subject: "the team", aux: "Had", verb: "won", object: "any trophy before this match" },
                    { id: "int-m4", english: "Had you submitted the application before deadline?", hindi: "क्या आपने समय-सीमा से पहले आवेदन जमा कर दिया था?", subject: "you", aux: "Had", verb: "submitted", object: "the application before deadline" },
                    { id: "int-m5", english: "Had they verified the customer details?", hindi: "क्या उन्होंने ग्राहक के विवरण का सत्यापन कर लिया था?", subject: "they", aux: "Had", verb: "verified", object: "the customer details" },
                    { id: "int-m6", english: "Had the teacher completed syllabus before exams?", hindi: "क्या परीक्षा से पहले शिक्षक ने पाठ्यक्रम पूरा कर लिया था?", subject: "the teacher", aux: "Had", verb: "completed", object: "syllabus before exams" },
                    { id: "int-m7", english: "Had we booked tickets in advance?", hindi: "क्या हमने अग्रिम में टिकट बुक कर लिए थे?", subject: "we", aux: "Had", verb: "booked", object: "tickets in advance" },
                    { id: "int-m8", english: "Had he repaired the engine properly?", hindi: "क्या उसने इंजन की ठीक से मरम्मत कर ली थी?", subject: "he", aux: "Had", verb: "repaired", object: "the engine properly" },
                    { id: "int-m9", english: "Had the passengers boarded the flight on time?", hindi: "क्या यात्री समय पर उड़ान में सवार हो चुके थे?", subject: "the passengers", aux: "Had", verb: "boarded", object: "the flight on time" },
                    { id: "int-m10", english: "Had she packed her luggage yesterday?", hindi: "क्या उसने कल ही अपना सामान पैक कर लिया था?", subject: "she", aux: "Had", verb: "packed", object: "her luggage yesterday" }
                ],
                hard: [
                    { id: "int-h1", english: "Had the engineers tested the system before commercial launch?", hindi: "क्या इंजीनियरों ने व्यावसायिक लॉन्च से पहले प्रणाली का परीक्षण कर लिया था?", subject: "the engineers", aux: "Had", verb: "tested", object: "the system before commercial launch" },
                    { id: "int-h2", english: "Had the management sanctioned the project budget?", hindi: "क्या प्रबंधन ने प्रोजेक्ट बजट को मंजूरी दे दी थी?", subject: "the management", aux: "Had", verb: "sanctioned", object: "the project budget" },
                    { id: "int-h3", english: "Had scientists published their findings before conference?", hindi: "क्या सम्मेलन से पहले वैज्ञानिकों ने अपने निष्कर्ष प्रकाशित कर दिए थे?", subject: "scientists", aux: "Had", verb: "published", object: "their findings before conference" },
                    { id: "int-h4", english: "Had heavy rainfall flooded the river basin area?", hindi: "क्या भारी बारिश ने नदी घाटी क्षेत्र में बाढ़ ला दी थी?", subject: "heavy rainfall", aux: "Had", verb: "flooded", object: "the river basin area" },
                    { id: "int-h5", english: "Had the accountant reconciled all financial entries?", hindi: "क्या लेखाकार ने सभी वित्तीय प्रविष्टियों का मिलान कर लिया था?", subject: "the accountant", aux: "Had", verb: "reconciled", object: "all financial entries" },
                    { id: "int-h6", english: "Had authorities evacuated residents before storm hit?", hindi: "क्या तूफान आने से पहले अधिकारियों ने निवासियों को बाहर निकाल लिया था?", subject: "authorities", aux: "Had", verb: "evacuated", object: "residents before storm" },
                    { id: "int-h7", english: "Had she completed her doctorate before age thirty?", hindi: "क्या उसने तीस वर्ष की आयु से पहले अपनी डॉक्टरेट पूरी कर ली थी?", subject: "she", aux: "Had", verb: "completed", object: "her doctorate before thirty" },
                    { id: "int-h8", english: "Had the high court issued a stay order on construction?", hindi: "क्या उच्च न्यायालय ने निर्माण पर रोक का आदेश जारी कर दिया था?", subject: "the high court", aux: "Had", verb: "issued", object: "a stay order on construction" },
                    { id: "int-h9", english: "Had research lab patented the medical discovery?", hindi: "क्या अनुसंधान प्रयोगशाला ने चिकित्सा खोज का पेटेंट करा लिया था?", subject: "research lab", aux: "Had", verb: "patented", object: "the medical discovery" },
                    { id: "int-h10", english: "Had government announced relief package before monsoon?", hindi: "क्या सरकार ने मानसून से पहले राहत पैकेज की घोषणा कर दी थी?", subject: "government", aux: "Had", verb: "announced", object: "relief package before monsoon" }
                ]
            }
        },

        // 8. WH Questions / WH प्रश्न (30 Items)
        whQuestions: {
            title: "WH Questions",
            titleHindi: "WH प्रश्न (WH-word + had + Subject + V3 + Object?)",
            formula: "WH-word + had + Subject + V3 + Object?",
            explanation: "Place WH question word (What, Where, Why, When, Who, How) before HAD + Subject + V3.",
            explanationHindi: "WH प्रश्नों में WH-शब्द के तुरंत बाद 'had', कर्ता और V3 लगाएं।",
            
            sentences: {
                easy: [
                    { id: "wh-e1", english: "What had you done before I came?", hindi: "मेरे आने से पहले आपने क्या किया था?", subject: "you", aux: "had", verb: "done", object: "before I came", whWord: "What" },
                    { id: "wh-e2", english: "Where had she gone before noon?", hindi: "दोपहर से पहले वह कहाँ गई थी?", subject: "she", aux: "had", verb: "gone", object: "before noon", whWord: "Where" },
                    { id: "wh-e3", english: "Why had they left the meeting early?", hindi: "वे बैठक जल्दी क्यों छोड़ कर चले गए थे?", subject: "they", aux: "had", verb: "left", object: "the meeting early", whWord: "Why" },
                    { id: "wh-e4", english: "When had he submitted the document?", hindi: "उसने दस्तावेज़ कब जमा किया था?", subject: "he", aux: "had", verb: "submitted", object: "the document", whWord: "When" },
                    { id: "wh-e5", english: "Who had called you before 7 AM?", hindi: "सुबह 7 बजे से पहले आपको किसने फोन किया था?", subject: "Who", aux: "had", verb: "called", object: "you before 7 AM", whWord: "Who" },
                    { id: "wh-e6", english: "Which movie had Rahul watched yesterday?", hindi: "राहुल ने कल कौन सी फिल्म देखी थी?", subject: "Rahul", aux: "had", verb: "watched", object: "yesterday", whWord: "Which" },
                    { id: "wh-e7", english: "How had she solved that problem?", hindi: "उसने वह समस्या कैसे हल की थी?", subject: "she", aux: "had", verb: "solved", object: "that problem", whWord: "How" },
                    { id: "wh-e8", english: "Whose bag had they taken by mistake?", hindi: "गलती से वे किसका बैग ले गए थे?", subject: "they", aux: "had", verb: "taken", object: "by mistake", whWord: "Whose" },
                    { id: "wh-e9", english: "Why had the train stopped unexpectedly?", hindi: "ट्रेन अप्रत्याशित रूप से क्यों रुक गई थी?", subject: "the train", aux: "had", verb: "stopped", object: "unexpectedly", whWord: "Why" },
                    { id: "wh-e10", english: "Where had we parked the car?", hindi: "हमने कार कहाँ खड़ी की थी?", subject: "we", aux: "had", verb: "parked", object: "the car", whWord: "Where" }
                ],
                medium: [
                    { id: "wh-m1", english: "What had the doctor suggested before surgery?", hindi: "सर्जरी से पहले डॉक्टर ने क्या सुझाव दिया था?", subject: "the doctor", aux: "had", verb: "suggested", object: "before surgery", whWord: "What" },
                    { id: "wh-m2", english: "Why had she resigned from her post?", hindi: "उसने अपने पद से इस्तीफा क्यों दिया था?", subject: "she", aux: "had", verb: "resigned", object: "from her post", whWord: "Why" },
                    { id: "wh-m3", english: "How had the team achieved the target so quickly?", hindi: "टीम ने इतनी जल्दी लक्ष्य कैसे हासिल कर लिया था?", subject: "the team", aux: "had", verb: "achieved", object: "the target so quickly", whWord: "How" },
                    { id: "wh-m4", english: "Where had they hidden the emergency key?", hindi: "उन्होंने आपातकालीन कुंजी कहाँ छिपाई थी?", subject: "they", aux: "had", verb: "hidden", object: "the emergency key", whWord: "Where" },
                    { id: "wh-m5", english: "When had the manager approved the leaves?", hindi: "मैनेजर ने छुट्टियों को कब मंजूरी दी थी?", subject: "the manager", aux: "had", verb: "approved", object: "the leaves", whWord: "When" },
                    { id: "wh-m6", english: "Which route had the driver chosen during traffic?", hindi: "ट्रैफिक के दौरान ड्राइवर ने कौन सा रास्ता चुना था?", subject: "the driver", aux: "had", verb: "chosen", object: "during traffic", whWord: "Which" },
                    { id: "wh-m7", english: "How much money had he borrowed from bank?", hindi: "उसने बैंक से कितना पैसा उधार लिया था?", subject: "he", aux: "had", verb: "borrowed", object: "from bank", whWord: "How much" },
                    { id: "wh-m8", english: "Why had the students protested before exams?", hindi: "परीक्षा से पहले छात्रों ने विरोध क्यों किया था?", subject: "the students", aux: "had", verb: "protested", object: "before exams", whWord: "Why" },
                    { id: "wh-m9", english: "Who had designed the company logo initially?", hindi: "शुरुआत में कंपनी का लोगो किसने डिजाइन किया था?", subject: "Who", aux: "had", verb: "designed", object: "company logo initially", whWord: "Who" },
                    { id: "wh-m10", english: "Where had she stored the official records?", hindi: "उसने आधिकारिक रिकॉर्ड कहाँ संग्रहीत किए थे?", subject: "she", aux: "had", verb: "stored", object: "official records", whWord: "Where" }
                ],
                hard: [
                    { id: "wh-h1", english: "What security measures had engineers implemented prior to breach?", hindi: "उल्लंघन से पहले इंजीनियरों ने क्या सुरक्षा उपाय लागू किए थे?", subject: "engineers", aux: "had", verb: "implemented", object: "prior to breach", whWord: "What" },
                    { id: "wh-h2", english: "Why had the board rejected the merger proposal?", hindi: "बोर्ड ने विलय प्रस्ताव को क्यों खारिज कर दिया था?", subject: "the board", aux: "had", verb: "rejected", object: "merger proposal", whWord: "Why" },
                    { id: "wh-h3", english: "How had scientists synthesized the new compound?", hindi: "वैज्ञानिकों ने नए यौगिक का संश्लेषण कैसे किया था?", subject: "scientists", aux: "had", verb: "synthesized", object: "new compound", whWord: "How" },
                    { id: "wh-h4", english: "Where had authorities set up emergency relief camps?", hindi: "अधिकारियों ने आपातकालीन राहत शिविर कहाँ स्थापित किए थे?", subject: "authorities", aux: "had", verb: "set up", object: "emergency relief camps", whWord: "Where" },
                    { id: "wh-h5", english: "When had the auditor discovered the financial discrepancy?", hindi: "अंकेक्षक ने वित्तीय विसंगति का पता कब लगाया था?", subject: "the auditor", aux: "had", verb: "discovered", object: "financial discrepancy", whWord: "When" },
                    { id: "wh-h6", english: "Which policies had government amended before fiscal year?", hindi: "वित्त वर्ष से पहले सरकार ने किन नीतियों में संशोधन किया था?", subject: "government", aux: "had", verb: "amended", object: "before fiscal year", whWord: "Which" },
                    { id: "wh-h7", english: "How long had the patient suffered before receiving treatment?", hindi: "इलाज मिलने से पहले मरीज कितने समय तक पीड़ित रहा था?", subject: "the patient", aux: "had", verb: "suffered", object: "before receiving treatment", whWord: "How long" },
                    { id: "wh-h8", english: "Why had the tribunal suspended the industrial license?", hindi: "न्यायाधिकरण ने औद्योगिक लाइसेंस क्यों निलंबित कर दिया था?", subject: "the tribunal", aux: "had", verb: "suspended", object: "industrial license", whWord: "Why" },
                    { id: "wh-h9", english: "Whose recommendation had the committee accepted?", hindi: "समिति ने किसकी सिफारिश स्वीकार की थी?", subject: "the committee", aux: "had", verb: "accepted", object: "recommendation", whWord: "Whose" },
                    { id: "wh-h10", english: "Where had research team published their experimental data?", hindi: "शोध टीम ने अपना प्रयोगात्मक डेटा कहाँ प्रकाशित किया था?", subject: "research team", aux: "had", verb: "published", object: "experimental data", whWord: "Where" }
                ]
            }
        },

        // 9. Common Mistakes & Corrections / सामान्य गलतियाँ (At least 15 Items)
        commonMistakes: {
            title: "Common Mistakes",
            titleHindi: "सामान्य गलतियाँ और सुधार (Common Mistakes & Corrections)",
            intro: "Avoid these 15 common errors when forming Past Perfect Tense sentences.",
            introHindi: "Past Perfect Tense का प्रयोग करते समय इन 15 सामान्य गलतियों से बचें।",
            mistakes: [
                {
                    wrong: "She had went to school.",
                    correct: "She had gone to school.",
                    why: "Past Perfect uses HAD + V3 (gone). 'went' is V2, which cannot be used after 'had'.",
                    whyHindi: "had के साथ हमेशा V3 (gone) का प्रयोग होता है, V2 (went) का नहीं।"
                },
                {
                    wrong: "They has finished their homework.",
                    correct: "They had finished their homework.",
                    why: "'has' is Present Perfect. Past Perfect always uses 'had' for all subjects.",
                    whyHindi: "Past Perfect में 'has/have' के स्थान पर केवल 'had' का प्रयोग होता है।"
                },
                {
                    wrong: "I had finish my work before 8 PM.",
                    correct: "I had finished my work before 8 PM.",
                    why: "'finish' is V1. Past Perfect requires V3 ('finished').",
                    whyHindi: "had के बाद V1 (finish) गलत है, V3 (finished) का प्रयोग करें।"
                },
                {
                    wrong: "She had not wrote the letter.",
                    correct: "She had not written the letter.",
                    why: "'wrote' is V2. Use V3 ('written') in negative Past Perfect.",
                    whyHindi: "नकारात्मक वाक्य में भी had not के बाद V3 (written) आता है।"
                },
                {
                    wrong: "Did she had left the house?",
                    correct: "Had she left the house?",
                    why: "Do not mix 'Did' with Past Perfect. Start interrogatives directly with 'Had'.",
                    whyHindi: "Past Perfect प्रश्नों में 'Did' का प्रयोग न करें, वाक्य 'Had' से शुरू करें।"
                },
                {
                    wrong: "I finished the work before he had arrived.",
                    correct: "I had finished the work before he arrived.",
                    why: "The earlier action takes Past Perfect (had finished), while the later action takes Simple Past (arrived).",
                    whyHindi: "पहले होने वाले कार्य में Past Perfect (had finished) और बाद वाले में Simple Past (arrived) आता है।"
                },
                {
                    wrong: "When I reached station, train left.",
                    correct: "When I reached the station, the train had left.",
                    why: "The train departed before I reached, so the earlier action requires Past Perfect (had left).",
                    whyHindi: "ट्रेन मेरे पहुँचने से पहले ही छूट चुकी थी, इसलिए इसमें had left (Past Perfect) आएगा।"
                },
                {
                    wrong: "She said that she has completed the task.",
                    correct: "She said that she had completed the task.",
                    why: "In reported speech with past reporting verb ('said'), Present Perfect shifts to Past Perfect ('had completed').",
                    whyHindi: "Reported Speech में 'said' आने पर 'has' बदलकर 'had' हो जाता है।"
                },
                {
                    wrong: "By 2020, he built a house.",
                    correct: "By 2020, he had built a house.",
                    why: "'By + past time' indicates completion before a past deadline, requiring Past Perfect.",
                    whyHindi: "'By + past time' (जैसे By 2020) के साथ Past Perfect (had built) आता है।"
                },
                {
                    wrong: "He was tired because he worked all night.",
                    correct: "He was tired because he had worked all night.",
                    why: "The working happened prior to being tired, so the cause takes Past Perfect.",
                    whyHindi: "थकान का कारण पहले का कार्य था, इसलिए इसमें had worked आएगा।"
                },
                {
                    wrong: "They didn't had finished the food.",
                    correct: "They hadn't finished the food. / They had not finished the food.",
                    why: "Never use 'didn't had'. The negative form is 'had not' or 'hadn't'.",
                    whyHindi: "'didn't had' व्याकरणिक रूप से गलत है, 'had not' या 'hadn't' का प्रयोग करें।"
                },
                {
                    wrong: "Had you saw him yesterday?",
                    correct: "Had you seen him yesterday?",
                    why: "'saw' is V2. After 'Had', use V3 ('seen').",
                    whyHindi: "Had के बाद V2 (saw) नहीं, V3 (seen) का प्रयोग होता है।"
                },
                {
                    wrong: "After he finished dinner, he had gone to bed.",
                    correct: "After he had finished dinner, he went to bed.",
                    why: "'After' introduces the earlier action, which should be Past Perfect (had finished), followed by Simple Past (went).",
                    whyHindi: "After वाले भाग में पहला कार्य (had finished) और दूसरे भाग में Simple Past (went) आता है।"
                },
                {
                    wrong: "Rahul had ate all the apples.",
                    correct: "Rahul had eaten all the apples.",
                    why: "'ate' is V2. Use V3 ('eaten') after 'had'.",
                    whyHindi: "had के बाद V2 (ate) गलत है, V3 (eaten) लगाएं।"
                },
                {
                    wrong: "She wasn't completed the task.",
                    correct: "She had not completed the task.",
                    why: "'wasn't completed' is passive or incorrect. Past Perfect negative active is 'had not completed'.",
                    whyHindi: "Past Perfect negative में wasn't नहीं, had not / hadn't आता है।"
                }
            ]
        },

        // 10. Summary & Revision / सारांश एवं दोहराव (15 Revision Examples)
        summary: {
            title: "Summary & Revision",
            titleHindi: "सारांश एवं दोहराव (Revision Summary)",
            introduction: "Quick summary of Past Perfect rules, formulas, timelines, and memory anchors.",
            introductionHindi: "Past Perfect Tense के मुख्य नियमों, सूत्रों और याद रखने योग्य बिंदुओं का त्वरित सारांश।",
            
            goldenRules: [
                "1. Golden Formula ➔ Subject + HAD + V3 + Object",
                "2. All Subjects ➔ HAD is used for I, You, He, She, It, We, They, Singular, Plural.",
                "3. Mandatory V3 ➔ Always use Past Participle (gone, eaten, written, finished).",
                "4. Negative Form ➔ Subject + had not (hadn't) + V3",
                "5. Interrogative Form ➔ Had + Subject + V3?",
                "6. Time Relationship ➔ Earlier Past Action = HAD + V3 | Later Past Action = V2 (Simple Past)",
                "7. Connectives ➔ Before + Simple Past, After + Past Perfect, By + past time"
            ],

            formulaSummary: {
                positive: "Subject + had + V3 + Object",
                negative: "Subject + had + not (hadn't) + V3 + Object",
                interrogative: "Had + Subject + V3 + Object?",
                whQuestion: "WH-word + had + Subject + V3 + Object?"
            },

            revisionExamples: {
                easy: [
                    { id: "sum-e1", english: "I had finished my work before 8 PM.", hindi: "मैं रात 8 बजे से पहले काम पूरा कर चुका था।", note: "All subjects take HAD + V3" },
                    { id: "sum-e2", english: "She had not received the letter.", hindi: "उसे पत्र प्राप्त नहीं हुआ था।", note: "Negative with had not + V3" },
                    { id: "sum-e3", english: "Had they left the hall?", hindi: "क्या वे हॉल छोड़ चुके थे?", note: "Interrogative starting with Had" },
                    { id: "sum-e4", english: "Why had he resigned?", hindi: "उसने इस्तीफा क्यों दिया था?", note: "WH question with Why had" },
                    { id: "sum-e5", english: "The train had departed before we reached.", hindi: "हमारे पहुँचने से पहले ट्रेन छूट चुकी थी।", note: "Earlier action: had departed" }
                ],
                medium: [
                    { id: "sum-m1", english: "The doctor had examined the patient before surgery.", hindi: "सर्जरी से पहले डॉक्टर मरीज की जांच कर चुके थे।", note: "Doctor + had + V3" },
                    { id: "sum-m2", english: "We hadn't received confirmation from venue.", hindi: "हमें स्थल से पुष्टि प्राप्त नहीं हुई थी।", note: "Contraction hadn't + V3" },
                    { id: "sum-m3", english: "Had the teacher completed syllabus before exams?", hindi: "क्या परीक्षा से पहले शिक्षक ने सिलेबस पूरा कर लिया था?", note: "Yes/No interrogative" },
                    { id: "sum-m4", english: "How had she solved that complex problem?", hindi: "उसने वह जटिल समस्या कैसे हल की थी?", note: "WH question with How had" },
                    { id: "sum-m5", english: "He was tired because he had worked all night.", hindi: "वह थका था क्योंकि उसने रात भर काम किया था।", note: "Cause and effect in past" }
                ],
                hard: [
                    { id: "sum-h1", english: "Engineers had resolved the vulnerability before breach.", hindi: "उल्लंघन से पहले इंजीनियर भेद्यता ठीक कर चुके थे।", note: "Technical context with had + V3" },
                    { id: "sum-h2", english: "The board had not approved the budget allocation.", hindi: "बोर्ड ने बजट आवंटन को मंजूरी नहीं दी थी।", note: "Formal negative" },
                    { id: "sum-h3", english: "Had authorities evacuated residents before cyclone hit?", hindi: "क्या अधिकारियों ने चक्रवात से पहले निवासियों को निकाला था?", note: "Emergency context question" },
                    { id: "sum-h4", english: "By the time audit began, accountant had reconciled entries.", hindi: "जब तक ऑडिट शुरू हुआ, लेखाकार प्रविष्टियाँ मिला चुका था।", note: "By the time pattern" },
                    { id: "sum-h5", english: "Rahul told me that he had bought a new car.", hindi: "राहुल ने बताया कि उसने नई कार खरीद ली थी।", note: "Reported speech past reference" }
                ]
            }
        },

        // 11. Practice Exercises / अभ्यास (120 Practice Sentences Total)
        exercises: {
            title: "Past Perfect Practice Sentences",
            titleHindi: "पूर्ण भूतकाल — अभ्यास (120 Practice Sentences)",
            introduction: "Practice all 120 sentences across Positive, Negative, Interrogative, and WH Questions to master Past Perfect Tense.",
            introductionHindi: "Past Perfect Tense के 120 अभ्यास वाक्यों (सकारात्मक, नकारात्मक, प्रश्नवाचक एवं WH प्रश्न) के माध्यम से पूरा अभ्यास करें।",
            categories: []
        },

        // 12. Quiz Configuration / ज्ञान परीक्षा (12 Quiz Combinations)
        quiz: {
            title: "Past Perfect Quiz",
            titleHindi: "पूर्ण भूतकाल — ज्ञान परीक्षा",
            questions: []
        }
    }
};

// Initialize categories referencing existing sections (120 Practice Sentences total)
pastPerfectLesson.sections.exercises.categories = [
    {
        id: "positive",
        title: "Positive Sentences Practice",
        titleHindi: "1. सकारात्मक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Positive Sentence",
        sentences: pastPerfectLesson.sections.positive.sentences
    },
    {
        id: "negative",
        title: "Negative Sentences Practice",
        titleHindi: "2. नकारात्मक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Negative Sentence",
        sentences: pastPerfectLesson.sections.negative.sentences
    },
    {
        id: "interrogative",
        title: "Interrogative Sentences Practice",
        titleHindi: "3. प्रश्नवाचक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Yes/No Question",
        sentences: pastPerfectLesson.sections.interrogative.sentences
    },
    {
        id: "whQuestions",
        title: "WH Questions Practice",
        titleHindi: "4. WH प्रश्न अभ्यास (30 Sentences)",
        typeLabel: "WH Question",
        sentences: pastPerfectLesson.sections.whQuestions.sentences
    }
];

/**
 * Get the complete Past Perfect lesson object
 * @returns {object}
 */
export function getPastPerfectLesson() {
    return { ...pastPerfectLesson };
}

/**
 * Get a specific section of Past Perfect lesson data
 * @param {string} sectionName 
 * @returns {object|Array|null}
 */
export function getPastPerfectSection(sectionName) {
    if (!sectionName || !pastPerfectLesson.sections) return null;
    return pastPerfectLesson.sections[sectionName] || null;
}
