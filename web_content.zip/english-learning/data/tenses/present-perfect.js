/**
 * Central Lesson Data for Present Perfect Tense (पूर्ण वर्तमान काल)
 * Single Source of Truth for Present Perfect Tense Module.
 * Follows proven reference architecture established in Simple Present and Present Continuous.
 */

const presentPerfectLesson = {
    id: "present-perfect",
    title: "Present Perfect",
    titleHindi: "पूर्ण वर्तमान काल (किया है / कर चुका हूँ)",
    description: "Learn Present Perfect Tense in simple Hindi: Subject + has/have + V3 + Object.",

    sections: {
        // 1. Identification / पहचान और अवधारणा
        identification: {
            title: "Identification",
            titleHindi: "पहचान और अवधारणा",
            english: "Present Perfect Tense is used for actions that were completed in the past, but whose effect, result, or connection remains relevant in the present moment.",
            hindi: "Present Perfect Tense का प्रयोग उन कार्यों के लिए किया जाता है जो भूतकाल में पूरे हो चुके हैं, लेकिन उनका परिणाम या प्रभाव वर्तमान समय से जुड़ा हुआ है।",
            hindiIdentityRule: "पहचान (Hindi Clues): वाक्य की मुख्य क्रिया के अंत में - कर चुका हूँ / कर चुकी हूँ / कर चुके हैं / किया है / लिया है / दिया है / आई है / गया है आदि आता है।",
            points: [
                {
                    english: "Focus is on the completion of the action and its present outcome.",
                    hindi: "मुख्य ध्यान कार्य के पूरा होने और उसके वर्तमान परिणाम पर होता है।"
                },
                {
                    english: "Exact past time is NOT specified (e.g. yesterday, last year are not used with Present Perfect).",
                    hindi: "कार्य किस सटीक समय पर पूरा हुआ, यह बताना आवश्यक नहीं होता (सटीक समय बताने के लिए Simple Past का प्रयोग करें)।"
                },
                {
                    english: "Auxiliary Verbs: 'has' (for singular subjects) and 'have' (for plural subjects and I/You).",
                    hindi: "सहायक क्रियाएं: एकवचन कर्ता के साथ 'has' और बहुवचन कर्ता तथा I/You के साथ 'have' का प्रयोग होता है।"
                },
                {
                    english: "Main Verb: Always use V3 (Past Participle form of the verb).",
                    hindi: "मुख्य क्रिया: हमेशा V3 (Past Participle form) का प्रयोग किया जाता है।"
                }
            ],
            comparison: {
                title: "Concept Comparison: Present Perfect vs Other Tenses",
                simplePresent: {
                    name: "Simple Present",
                    formula: "Subject + V1/V1+s + Object",
                    concept: "Habits, routines, daily facts.",
                    example: "I eat breakfast every morning. (रोज़ की आदत)"
                },
                presentContinuous: {
                    name: "Present Continuous",
                    formula: "Subject + am/is/are + V4 + Object",
                    concept: "Action happening right now in real time.",
                    example: "I am eating breakfast right now. (काम अभी चल रहा है)"
                },
                presentPerfect: {
                    name: "Present Perfect",
                    formula: "Subject + has/have + V3 + Object",
                    concept: "Action completed, present result.",
                    example: "I have eaten breakfast. (खाना खा लिया है, पेट भरा है)"
                }
            }
        },

        // 2. Uses & Scenarios / कब प्रयोग करें
        uses: [
            {
                id: "use-1-recent-completed",
                title: "1. Action Recently Completed with Present Result",
                titleHindi: "1. हाल ही में समाप्त हुआ कार्य जिसका परिणाम वर्तमान में मौजूद है",
                explanation: "Actions that happened a short time ago and directly affect the present state.",
                explanationHindi: "वे कार्य जो कुछ समय पहले पूरे हुए हैं और उनका परिणाम वर्तमान स्थिति पर असर डालता है।",
                whyUsed: "Used because the completion is fresh and its effect is active right now.",
                whyUsedHindi: "यह काल इसलिए प्रयोग हुआ है क्योंकि कार्य अभी-अभी पूरा हुआ है और उसका प्रभाव वर्तमान में है।",
                examples: [
                    {
                        english: "I have finished my homework.",
                        hindi: "मैंने अपना गृहकार्य पूरा कर लिया है।",
                        note: "Result: Now I am free to play."
                    },
                    {
                        english: "She has lost her office key.",
                        hindi: "उसकी ऑफिस की चाबी खो गई है।",
                        note: "Result: She cannot open the door right now."
                    },
                    {
                        english: "They have arrived at the station.",
                        hindi: "वे स्टेशन पहुँच चुके हैं।",
                        note: "Result: They are waiting at the platform now."
                    }
                ]
            },
            {
                id: "use-2-life-experience",
                title: "2. Life Experiences (Unspecified Past Time)",
                titleHindi: "2. जीवन के अनुभव (जब सटीक समय न बताया गया हो)",
                explanation: "Talking about events or accomplishments in life without stating when they occurred.",
                explanationHindi: "जीवन में हुए अनुभवों या उपलब्धियों के बारे में बात करना जब सटीक समय बताना उद्देश्य न हो।",
                whyUsed: "Used because the experience belongs to your life history up to the present moment.",
                whyUsedHindi: "यह काल इसलिए प्रयोग हुआ है क्योंकि अनुभव वर्तमान तक के जीवन का हिस्सा है।",
                examples: [
                    {
                        english: "I have visited Delhi three times.",
                        hindi: "मैं तीन बार दिल्ली जा चुका हूँ।",
                        note: "Unspecified past experience up to now."
                    },
                    {
                        english: "She has never seen a snow leopard.",
                        hindi: "उसने कभी हिम तेंदुआ नहीं देखा है।",
                        note: "Life experience up to present."
                    },
                    {
                        english: "Have you ever read this famous novel?",
                        hindi: "क्या आपने कभी यह प्रसिद्ध उपन्यास पढ़ा है?",
                        note: "Asking about life experience."
                    }
                ]
            },
            {
                id: "use-3-continuing-state",
                title: "3. Action/State Continuing from Past to Present (Since / For)",
                titleHindi: "3. भूतकाल से शुरू होकर वर्तमान तक जारी स्थिति (Since / For का प्रयोग)",
                explanation: "Situations that started in the past and continue into the present moment.",
                explanationHindi: "ऐसी स्थितियाँ या कार्य जो भूतकाल में आरंभ हुए और वर्तमान समय में भी बने हुए हैं।",
                whyUsed: "Used with 'since' (point of time) or 'for' (duration of time).",
                whyUsedHindi: "यह काल समय की शुरुआत (since) या अवधि (for) बताने के लिए प्रयोग होता है।",
                examples: [
                    {
                        english: "I have lived in Mumbai since 2018.",
                        hindi: "मैं 2018 से मुंबई में रह रहा हूँ / रहता आया हूँ।",
                        note: "Started in 2018, still living there today."
                    },
                    {
                        english: "He has been sick for three days.",
                        hindi: "वह तीन दिनों से बीमार है।",
                        note: "Illness started 3 days ago and continues now."
                    },
                    {
                        english: "We have known each other for ten years.",
                        hindi: "हम दस साल से एक-दूसरे को जानते हैं।",
                        note: "Relationship started 10 years ago."
                    }
                ]
            },
            {
                id: "use-4-repeated-actions",
                title: "4. Repeated Action up to Present",
                titleHindi: "4. अब तक कई बार दोहराया गया कार्य",
                explanation: "Actions that have happened multiple times from the past until now.",
                explanationHindi: "वे कार्य जो भूतकाल से लेकर अब तक कई बार दोहराए गए हैं।",
                whyUsed: "Used because the total count of repetitions is relevant up to now.",
                whyUsedHindi: "यह काल इसलिए प्रयोग हुआ है क्योंकि दोहराव की कुल संख्या अब तक मायने रखती है।",
                examples: [
                    {
                        english: "He has watched this film four times.",
                        hindi: "उसने यह फिल्म चार बार देखी है।",
                        note: "Repeated 4 times up to present."
                    },
                    {
                        english: "I have called him twice this morning.",
                        hindi: "मैंने आज सुबह उसे दो बार फोन किया है।",
                        note: "Called 2 times so far today."
                    },
                    {
                        english: "Our team has won three matches this season.",
                        hindi: "हमारी टीम ने इस सीजन में तीन मैच जीते हैं।",
                        note: "Total wins up to current date."
                    }
                ]
            },
            {
                id: "use-5-already-just-yet",
                title: "5. Actions with Already, Just, or Yet",
                titleHindi: "5. Already (पहले ही), Just (अभी-अभी), Yet (अभी तक) के साथ",
                explanation: "Expressing actions that happened very recently, earlier than expected, or haven't happened until now.",
                explanationHindi: "वे कार्य जो अभी-अभी हुए हैं, उम्मीद से पहले हो चुके हैं, या अभी तक पूरे नहीं हुए हैं।",
                whyUsed: "Used with adverbs 'just', 'already', and 'yet' to emphasize timing relative to now.",
                whyUsedHindi: "समय की स्थिति स्पष्ट करने के लिए adverbs (just, already, yet) के साथ प्रयोग होता है।",
                examples: [
                    {
                        english: "The train has just left the station.",
                        hindi: "ट्रेन अभी-अभी स्टेशन से निकली है।",
                        note: "'Just' indicates a moment ago."
                    },
                    {
                        english: "I have already paid the electricity bill.",
                        hindi: "मैं पहले ही बिजली का बिल भर चुका हूँ।",
                        note: "'Already' indicates completed earlier than required."
                    },
                    {
                        english: "The manager has not replied to the email yet.",
                        hindi: "मैनेजर ने अभी तक ईमेल का जवाब नहीं दिया है।",
                        note: "'Yet' indicates an action expected but not done until now."
                    }
                ]
            }
        ],

        // 3. Structure & Formulas / वाक्य संरचना
        structure: {
            simpleHindiOverview: "Present Perfect Tense में Subject के अनुसार auxiliary verb (has / have) का प्रयोग होता है और Main Verb हमेशा V3 (Past Participle form) में आती है।",
            mainFormula: "Subject + has/have + V3 + Object",

            auxiliaryMapping: [
                { subject: "I / You / We / They / Plural Noun", aux: "have", formula: "Subject + have + V3" },
                { subject: "He / She / It / Singular Noun", aux: "has", formula: "Subject + has + V3" }
            ],

            v3SpellingReminder: [
                { base: "finish (V1)", v4: "finished (V3)", rule: "Regular Verb: Add -ed to V1" },
                { base: "work (V1)", v4: "worked (V3)", rule: "Regular Verb: Add -ed to V1" },
                { base: "go (V1)", v4: "gone (V3)", rule: "Irregular Verb: go → went (V2) → gone (V3)" },
                { base: "eat (V1)", v4: "eaten (V3)", rule: "Irregular Verb: eat → ate (V2) → eaten (V3)" },
                { base: "see (V1)", v4: "seen (V3)", rule: "Irregular Verb: see → saw (V2) → seen (V3)" },
                { base: "write (V1)", v4: "written (V3)", rule: "Irregular Verb: write → wrote (V2) → written (V3)" },
                { base: "do (V1)", v4: "done (V3)", rule: "Irregular Verb: do → did (V2) → done (V3)" },
                { base: "take (V1)", v4: "taken (V3)", rule: "Irregular Verb: take → took (V2) → taken (V3)" }
            ],

            positive: "Subject + has/have + V3 + Object",
            negative: "Subject + has/have + not + V3 + Object",
            interrogative: "Has/Have + Subject + V3 + Object?",
            whQuestions: "WH-word + has/have + Subject + V3 + Object?",

            formulaBlocks: [
                {
                    id: "positive",
                    title: "1. Positive / Affirmative Formula (सकारात्मक वाक्य)",
                    formula: "Subject + has/have + V3 + Object",
                    englishExplanation: "Used for affirmative statements expressing a completed action with present relevance.",
                    hindiExplanation: "सकारात्मक वाक्यों में कर्ता के अनुसार has/have के साथ V3 (Past Participle form) का प्रयोग किया जाता है।",
                    examples: [
                        {
                            english: "I have written a letter.",
                            hindi: "मैंने एक पत्र लिखा है / मैं पत्र लिख चुका हूँ।",
                            breakdown: {
                                subject: "I",
                                aux: "have",
                                mainVerb: "written (V3)",
                                object: "a letter"
                            }
                        },
                        {
                            english: "She has completed her project.",
                            hindi: "वह अपना प्रोजेक्ट पूरा कर चुकी है।",
                            breakdown: {
                                subject: "She",
                                aux: "has",
                                mainVerb: "completed (V3)",
                                object: "her project"
                            }
                        }
                    ]
                },
                {
                    id: "negative",
                    title: "2. Negative Formula (नकारात्मक वाक्य)",
                    formula: "Subject + has/have + not + V3 + Object",
                    englishExplanation: "Used for negative statements by inserting 'not' directly after has/have (hasn't / haven't).",
                    hindiExplanation: "नकारात्मक वाक्यों में has/have के तुरंत बाद 'not' (hasn't / haven't) लगाया जाता है।",
                    examples: [
                        {
                            english: "They have not received the parcel.",
                            hindi: "उन्हें पार्सल नहीं मिला है।",
                            breakdown: {
                                subject: "They",
                                aux: "have",
                                not: "not",
                                mainVerb: "received (V3)",
                                object: "the parcel"
                            }
                        },
                        {
                            english: "He has not locked the office door.",
                            hindi: "उसने ऑफिस का दरवाजा लॉक नहीं किया है।",
                            breakdown: {
                                subject: "He",
                                aux: "has",
                                not: "not",
                                mainVerb: "locked (V3)",
                                object: "the office door"
                            }
                        }
                    ]
                },
                {
                    id: "interrogative",
                    title: "3. Interrogative Formula (प्रश्नवाचक वाक्य - Yes/No)",
                    formula: "Has/Have + Subject + V3 + Object?",
                    englishExplanation: "Used for Yes/No questions by placing Has or Have at the beginning of the sentence.",
                    hindiExplanation: "हाँ/ना वाले प्रश्नवाचक वाक्यों में Has/Have को कर्ता से पहले वाक्य के शुरू में रखा जाता है।",
                    examples: [
                        {
                            english: "Have you taken your medicine?",
                            hindi: "क्या आपने अपनी दवा ले ली है?",
                            breakdown: {
                                aux: "Have",
                                subject: "you",
                                mainVerb: "taken (V3)",
                                object: "your medicine"
                            }
                        },
                        {
                            english: "Has Rahul paid the electricity bill?",
                            hindi: "क्या राहुल ने बिजली का बिल भर दिया है?",
                            breakdown: {
                                aux: "Has",
                                subject: "Rahul",
                                mainVerb: "paid (V3)",
                                object: "the electricity bill"
                            }
                        }
                    ]
                },
                {
                    id: "whQuestions",
                    title: "4. WH Question Formula (प्रश्नवाचक वाक्य - WH शब्द)",
                    formula: "WH-word + has/have + Subject + V3 + Object?",
                    englishExplanation: "Used when asking for specific details using WH-words (What, Where, Why, When, Who, How, How long).",
                    hindiExplanation: "विशेष जानकारी वाले प्रश्नों के लिए WH-शब्द को has/have से भी पहले रखा जाता है।",
                    examples: [
                        {
                            english: "What have you prepared for lunch?",
                            hindi: "आपने दोपहर के भोजन के लिए क्या तैयार किया है?",
                            breakdown: {
                                wh: "What",
                                aux: "have",
                                subject: "you",
                                mainVerb: "prepared (V3)",
                                object: "for lunch"
                            }
                        },
                        {
                            english: "Where has she hidden the keys?",
                            hindi: "उसने चाबियाँ कहाँ छिपाई हैं?",
                            breakdown: {
                                wh: "Where",
                                aux: "has",
                                subject: "she",
                                mainVerb: "hidden (V3)",
                                object: "the keys"
                            }
                        }
                    ]
                }
            ]
        },

        // 4. Subject + Auxiliary Rules & V3 Formation / कर्ता और सहायक क्रिया के नियम
        subjectVerbRules: {
            auxiliaryMapping: [
                {
                    subjectGroup: "Group 1: Subject 'I / You / We / They / Plural'",
                    auxiliary: "have",
                    formula: "I / You / We / They / Plural + have + V3",
                    hindiRule: "I, You, We, They और सभी बहुवचन कर्ताओं के साथ 'have' का प्रयोग होता है। (जैसे: I have eaten. / They have gone.)"
                },
                {
                    subjectGroup: "Group 2: Singular Subjects (He / She / It / Name)",
                    auxiliary: "has",
                    formula: "He / She / It / Singular + has + V3",
                    hindiRule: "एकवचन कर्ता (He, She, It, Rahul) के साथ 'has' का प्रयोग होता है। (जैसे: She has written. / Rahul has come.)"
                }
            ],
            v4Explanation: {
                title: "What is V3? (Past Participle)",
                titleHindi: "V3 क्या है? (Past Participle form of Verb)",
                ruleText: "V3 = Third Form of the Verb (Past Participle)",
                explanationHindi: "Present Perfect Tense में सभी कर्ताओं (Subject) के साथ केवल V3 का प्रयोग किया जाता है। कभी भी V1 या V2 न लगाएं।",
                examples: [
                    { base: "go (V1)", v4: "gone (V3)" },
                    { base: "eat (V1)", v4: "eaten (V3)" },
                    { base: "write (V1)", v4: "written (V3)" },
                    { base: "see (V1)", v4: "seen (V3)" },
                    { base: "do (V1)", v4: "done (V3)" },
                    { base: "take (V1)", v4: "taken (V3)" }
                ]
            },
            spellingRulesIng: [
                {
                    condition: "1. Regular Verbs (-ed)",
                    rule: "Add -ed to base verb (V1)",
                    examples: "work → worked, play → played, finish → finished, ask → asked"
                },
                {
                    condition: "2. Verbs ending in -e",
                    rule: "Add -d only",
                    examples: "live → lived, close → closed, change → changed"
                },
                {
                    condition: "3. Verbs ending in consonant + y",
                    rule: "Change -y to -ied",
                    examples: "study → studied, carry → carried, try → tried"
                },
                {
                    condition: "4. Irregular Verbs (Must memorize)",
                    rule: "Unique past participle form",
                    examples: "go → gone, eat → eaten, write → written, see → seen, speak → spoken, buy → bought"
                }
            ]
        },

        // 5. Positive / Affirmative Sentences (सकारात्मक वाक्य)
        positive: {
            title: "Positive / Affirmative Sentences",
            titleHindi: "सकारात्मक वाक्य",
            formula: "Subject + has / have + V3 + Object",
            formulaPlural: "I / You / We / They + have + V3",
            formulaSingular: "He / She / It / Name + has + V3",
            explanation: "Positive sentences in Present Perfect state an action completed with a present connection or outcome.",
            explanationHindi: "Present Perfect के सकारात्मक वाक्य यह बताते हैं कि कार्य पूरा हो चुका है और उसका परिणाम वर्तमान से जुड़ा है।",
            groups: {
                groupHave: {
                    name: "Group A: Plural Subjects & I/You (have + V3)",
                    rule: "Always use 'have' + V3 with I, You, We, They, Plurals",
                    ruleHindi: "I, You, We, They और बहुवचन कर्ता के साथ have + V3 का प्रयोग करें।",
                    examples: [
                        { english: "I have finished my homework.", hindi: "मैंने अपना गृहकार्य पूरा कर लिया है।", verb: "have finished" },
                        { english: "They have moved to a new apartment.", hindi: "वे एक नए अपार्टमेंट में चले गए हैं।", verb: "have moved" }
                    ]
                },
                groupHas: {
                    name: "Group B: Singular Subjects (has + V3)",
                    rule: "Always use 'has' + V3 with He, She, It, Singular Names",
                    ruleHindi: "He, She, It और एकवचन कर्ता के साथ has + V3 का प्रयोग करें।",
                    examples: [
                        { english: "She has cooked a delicious meal.", hindi: "उसने एक स्वादिष्ट भोजन बनाया है।", verb: "has cooked" },
                        { english: "Rahul has purchased a new laptop.", hindi: "राहुल ने एक नया लैपटॉप खरीदा है।", verb: "has purchased" }
                    ]
                }
            },
            sentences: {
                easy: [
                    { id: "pos-e1", english: "I have finished my homework.", hindi: "मैंने अपना गृहकार्य पूरा कर लिया है।", subject: "I", aux: "have", verb: "finished", object: "my homework" },
                    { id: "pos-e2", english: "She has cooked dinner for the family.", hindi: "उसने परिवार के लिए रात का खाना बनाया है।", subject: "She", aux: "has", verb: "cooked", object: "dinner" },
                    { id: "pos-e3", english: "He has driven a car before.", hindi: "उसने पहले भी कार चलाई है।", subject: "He", aux: "has", verb: "driven", object: "a car" },
                    { id: "pos-e4", english: "They have won the football match.", hindi: "वे फुटबॉल मैच जीत चुके हैं।", subject: "They", aux: "have", verb: "won", object: "the match" },
                    { id: "pos-e5", english: "We have watched this movie already.", hindi: "हम यह फिल्म पहले ही देख चुके हैं।", subject: "We", aux: "have", verb: "watched", object: "this movie" },
                    { id: "pos-e6", english: "Rahul has written an article.", hindi: "राहुल ने एक लेख लिखा है।", subject: "Rahul", aux: "has", verb: "written", object: "an article" },
                    { id: "pos-e7", english: "The baby has fallen asleep.", hindi: "बच्चा सो चुका है।", subject: "The baby", aux: "has", verb: "fallen", object: "asleep" },
                    { id: "pos-e8", english: "You have learned all the basic grammar rules.", hindi: "आप सभी बुनियादी व्याकरण नियम सीख चुके हैं।", subject: "You", aux: "have", verb: "learned", object: "grammar rules" },
                    { id: "pos-e9", english: "The birds have flown away from the tree.", hindi: "पक्षी पेड़ से उड़ चुके हैं।", subject: "The birds", aux: "have", verb: "flown", object: "away" },
                    { id: "pos-e10", english: "It has stopped raining outside.", hindi: "बाहर बारिश होना बंद हो गया है।", subject: "It", aux: "has", verb: "stopped", object: "raining" }
                ],
                medium: [
                    { id: "pos-m1", english: "I have completed three online certification courses this year.", hindi: "मैंने इस वर्ष तीन ऑनलाइन प्रमाणन पाठ्यक्रम पूरे किए हैं।", subject: "I", aux: "have", verb: "completed", object: "three courses" },
                    { id: "pos-m2", english: "She has prepared a detailed presentation for the board meeting.", hindi: "उसने बोर्ड बैठक के लिए एक विस्तृत प्रस्तुति तैयार की है।", subject: "She", aux: "has", verb: "prepared", object: "a presentation" },
                    { id: "pos-m3", english: "They have constructed a new community center in our village.", hindi: "उन्होंने हमारे गाँव में एक नया सामुदायिक केंद्र बनाया है।", subject: "They", aux: "have", verb: "constructed", object: "a community center" },
                    { id: "pos-m4", english: "My brother has secured a software engineering job in Bengaluru.", hindi: "मेरे भाई को बेंगलुरु में सॉफ्टवेयर इंजीनियरिंग की नौकरी मिल गई है।", subject: "My brother", aux: "has", verb: "secured", object: "a job" },
                    { id: "pos-m5", english: "We have booked our flight tickets for the summer vacation.", hindi: "हमने गर्मियों की छुट्टियों के लिए अपनी उड़ानों के टिकट बुक कर लिए हैं।", subject: "We", aux: "have", verb: "booked", object: "flight tickets" },
                    { id: "pos-m6", english: "The students have submitted all their science assignments on time.", hindi: "छात्रों ने अपने सभी विज्ञान असाइनमेंट समय पर जमा कर दिए हैं।", subject: "The students", aux: "have", verb: "submitted", object: "assignments" },
                    { id: "pos-m7", english: "Our company has launched a revolutionary mobile application.", hindi: "हमारी कंपनी ने एक क्रांतिकारी मोबाइल एप्लिकेशन लॉन्च किया है।", subject: "Our company", aux: "has", verb: "launched", object: "an app" },
                    { id: "pos-m8", english: "The author has published five best-selling novels worldwide.", hindi: "लेखक दुनिया भर में पांच सबसे ज्यादा बिकने वाले उपन्यास प्रकाशित कर चुका है।", subject: "The author", aux: "has", verb: "published", object: "five novels" },
                    { id: "pos-m9", english: "You have improved your spoken English vocabulary remarkably.", hindi: "आपकी अंग्रेजी बोलने की शब्दावली में उल्लेखनीय सुधार हुआ है।", subject: "You", aux: "have", verb: "improved", object: "vocabulary" },
                    { id: "pos-m10", english: "The government has implemented new environmental conservation policies.", hindi: "सरकार ने नई पर्यावरण संरक्षण नीतियां लागू की हैं।", subject: "The government", aux: "has", verb: "implemented", object: "policies" }
                ],
                hard: [
                    { id: "pos-h1", english: "The parliamentary committee has approved the comprehensive economic reform bill.", hindi: "संसदीय समिति ने व्यापक आर्थिक सुधार विधेयक को मंजूरी दे दी है।", subject: "The committee", aux: "has", verb: "approved", object: "the reform bill" },
                    { id: "pos-h2", english: "International delegates have signed a landmark climate preservation treaty.", hindi: "अंतरराष्ट्रीय प्रतिनिधियों ने एक ऐतिहासिक जलवायु संरक्षण संधि पर हस्ताक्षर किए हैं।", subject: "Delegates", aux: "have", verb: "signed", object: "a treaty" },
                    { id: "pos-h3", english: "The cybersecurity team has neutralized all unauthorized network intrusion attempts.", hindi: "साइबर सुरक्षा टीम ने सभी अनाधिकृत नेटवर्क घुसपैठ के प्रयासों को विफल कर दिया है।", subject: "The team", aux: "has", verb: "neutralized", object: "intrusion attempts" },
                    { id: "pos-h4", english: "Senior research scientists have discovered a potential cure for the disease.", hindi: "वरिष्ठ शोध वैज्ञानिकों ने बीमारी के संभावित इलाज की खोज की है।", subject: "Scientists", aux: "have", verb: "discovered", object: "a cure" },
                    { id: "pos-h5", english: "The pharmaceutical firm has successfully conducted phase three clinical trials.", hindi: "दवा कंपनी ने चरण तीन के नैदानिक परीक्षणों का सफलतापूर्वक संचालन किया है।", subject: "The firm", aux: "has", verb: "conducted", object: "clinical trials" },
                    { id: "pos-h6", english: "Civil engineers have completed the structural inspection of the suspension bridge.", hindi: "सिविल इंजीनियरों ने सस्पेंशन ब्रिज का संरचनात्मक निरीक्षण पूरा कर लिया है।", subject: "Engineers", aux: "have", verb: "completed", object: "the inspection" },
                    { id: "pos-h7", english: "The chief executive officer has unveiled the company's decade-long strategic roadmap.", hindi: "मुख्य कार्यकारी अधिकारी ने कंपनी के दशक भर के रणनीतिक रोडमैप का अनावरण किया है।", subject: "The CEO", aux: "has", verb: "unveiled", object: "the roadmap" },
                    { id: "pos-h8", english: "Aviation authorities have upgraded radar communication systems across all airports.", hindi: "उड्डयन प्राधिकरणों ने सभी हवाई अड्डों पर रडार संचार प्रणालियों को अपग्रेड कर दिया है।", subject: "Authorities", aux: "have", verb: "upgraded", object: "radar systems" },
                    { id: "pos-h9", english: "The university department has published peer-reviewed findings in international journals.", hindi: "विश्वविद्यालय विभाग ने अंतरराष्ट्रीय पत्रिकाओं में सहकर्मी-समीक्षित निष्कर्ष प्रकाशित किए हैं।", subject: "The department", aux: "has", verb: "published", object: "findings" },
                    { id: "pos-h10", english: "Environmental researchers have measured a reduction in urban carbon emission levels.", hindi: "पर्यावरण शोधकर्ताओं ने शहरी कार्बन उत्सर्जन स्तरों में कमी को मापा है।", subject: "Researchers", aux: "have", verb: "measured", object: "emission reduction" }
                ]
            }
        },

        // 6. Negative Sentences (नकारात्मक वाक्य)
        negative: {
            title: "Negative Sentences",
            titleHindi: "नकारात्मक वाक्य",
            formula: "Subject + has / have + not + V3 + Object",
            formulaPlural: "I / You / We / They + have not (haven't) + V3",
            formulaSingular: "He / She / It / Name + has not (hasn't) + V3",
            explanation: "Negative sentences state that an expected completed action has not taken place up to the present.",
            explanationHindi: "Present Perfect के नकारात्मक वाक्य यह दर्शाते हैं कि कोई अपेक्षित कार्य वर्तमान तक पूरा नहीं हुआ है।",
            groups: {
                groupHaveNot: {
                    name: "Group A: Plural Subjects & I/You (have not / haven't + V3)",
                    rule: "Use 'have not' (haven't) + V3",
                    ruleHindi: "I, You, We, They और बहुवचन कर्ता के साथ have not (haven't) + V3 का प्रयोग करें।",
                    examples: [
                        { english: "I have not received the email yet.", hindi: "मुझे अभी तक ईमेल नहीं मिला है।", verb: "have not received" },
                        { english: "They haven't arrived at the office.", hindi: "वे कार्यालय नहीं पहुँचे हैं।", verb: "haven't arrived" }
                    ]
                },
                groupHasNot: {
                    name: "Group B: Singular Subjects (has not / hasn't + V3)",
                    rule: "Use 'has not' (hasn't) + V3",
                    ruleHindi: "He, She, It और एकवचन कर्ता के साथ has not (hasn't) + V3 का प्रयोग करें।",
                    examples: [
                        { english: "She has not completed her assignment.", hindi: "उसने अपना असाइनमेंट पूरा नहीं किया है।", verb: "has not completed" },
                        { english: "Rahul hasn't paid the utility bills.", hindi: "राहुल ने उपयोगिता बिलों का भुगतान नहीं किया है।", verb: "hasn't paid" }
                    ]
                }
            },
            criticalRule: {
                ruleTitle: "CRITICAL RULE: Always use V3 (Past Participle) after Has/Have!",
                ruleTitleHindi: "महत्वपूर्ण नियम: Has/Have के बाद हमेशा V3 का प्रयोग करें (V1 या V2 नहीं)!",
                explanation: "Never use V1 (go, finish) or V2 (went, finished) after has/have in negative sentences.",
                explanationHindi: "नकारात्मक वाक्यों में has not / have not के बाद V1 या V2 लगाने की गलती न करें।",
                comparisonExamples: [
                    { wrong: "He has not went to school.", correct: "He has not gone to school.", note: "Use V3 'gone', not V2 'went'." },
                    { wrong: "They haven't ate dinner.", correct: "They haven't eaten dinner.", note: "Use V3 'eaten', not V2 'ate'." },
                    { wrong: "She has not finish the task.", correct: "She has not finished the task.", note: "Use V3 'finished', not V1 'finish'." }
                ]
            },
            transformations: [
                { positive: "I have submitted the form.", negative: "I have not submitted the form.", note: "Insert 'not' after 'have'." },
                { positive: "She has locked the door.", negative: "She has not locked the door.", note: "Insert 'not' after 'has'." },
                { positive: "They have left the town.", negative: "They haven't left the town.", note: "Contraction: have not → haven't." }
            ],
            sentences: {
                easy: [
                    { id: "neg-e1", english: "I have not received your message yet.", hindi: "मुझे अभी तक आपका संदेश नहीं मिला है।", subject: "I", aux: "have not", verb: "received", object: "your message" },
                    { id: "neg-e2", english: "She has not cleaned her bedroom.", hindi: "उसने अपना बेडरूम साफ नहीं किया है।", subject: "She", aux: "has not", verb: "cleaned", object: "her bedroom" },
                    { id: "neg-e3", english: "He has not driven on the highway.", hindi: "उसने हाईवे पर गाड़ी नहीं चलाई है।", subject: "He", aux: "has not", verb: "driven", object: "on highway" },
                    { id: "neg-e4", english: "They have not eaten their lunch yet.", hindi: "उन्होंने अभी तक अपना दोपहर का खाना नहीं खाया है।", subject: "They", aux: "have not", verb: "eaten", object: "their lunch" },
                    { id: "neg-e5", english: "We have not seen that new movie.", hindi: "हमने वह नई फिल्म नहीं देखी है।", subject: "We", aux: "have not", verb: "seen", object: "that movie" },
                    { id: "neg-e6", english: "Rahul has not replied to my call.", hindi: "राहुल ने मेरे कॉल का जवाब नहीं दिया है।", subject: "Rahul", aux: "has not", verb: "replied", object: "to my call" },
                    { id: "neg-e7", english: "The package has not arrived at the doorstep.", hindi: "पैकेज दरवाजे पर नहीं पहुँचा है।", subject: "The package", aux: "has not", verb: "arrived", object: "at doorstep" },
                    { id: "neg-e8", english: "You have not signed the agreement document.", hindi: "आपने समझौते के दस्तावेज पर हस्ताक्षर नहीं किए हैं।", subject: "You", aux: "have not", verb: "signed", object: "the document" },
                    { id: "neg-e9", english: "The rain has not stopped since morning.", hindi: "सुबह से बारिश बंद नहीं हुई है।", subject: "The rain", aux: "has not", verb: "stopped", object: "since morning" },
                    { id: "neg-e10", english: "It has not rained in this district for months.", hindi: "इस जिले में महीनों से बारिश नहीं हुई है।", subject: "It", aux: "has not", verb: "rained", object: "for months" }
                ],
                medium: [
                    { id: "neg-m1", english: "I have not completed the annual taxation paperwork.", hindi: "मैंने वार्षिक कराधान का कागजी काम पूरा नहीं किया है।", subject: "I", aux: "have not", verb: "completed", object: "tax paperwork" },
                    { id: "neg-m2", english: "She has not received the formal job offer letter.", hindi: "उसे औपचारिक नौकरी का प्रस्ताव पत्र नहीं मिला है।", subject: "She", aux: "has not", verb: "received", object: "the offer letter" },
                    { id: "neg-m3", english: "They have not constructed the boundary wall yet.", hindi: "उन्होंने अभी तक चारदीवारी का निर्माण नहीं किया है।", subject: "They", aux: "have not", verb: "constructed", object: "the wall" },
                    { id: "neg-m4", english: "My brother has not renewed his driving license.", hindi: "मेरे भाई ने अपने ड्राइविंग लाइसेंस का नवीनीकरण नहीं कराया है।", subject: "My brother", aux: "has not", verb: "renewed", object: "license" },
                    { id: "neg-m5", english: "We have not finalized our holiday travel itinerary.", hindi: "हमने अपनी छुट्टियों की यात्रा की रूपरेखा को अंतिम रूप नहीं दिया है।", subject: "We", aux: "have not", verb: "finalized", object: "itinerary" },
                    { id: "neg-m6", english: "The candidates have not submitted their original certificates.", hindi: "उम्मीदवारों ने अपने मूल प्रमाण पत्र जमा नहीं किए हैं।", subject: "The candidates", aux: "have not", verb: "submitted", object: "certificates" },
                    { id: "neg-m7", english: "The company has not released the quarterly financial report.", hindi: "कंपनी ने तिमाही वित्तीय रिपोर्ट जारी नहीं की है।", subject: "The company", aux: "has not", verb: "released", object: "the report" },
                    { id: "neg-m8", english: "The publisher has not printed the revised edition of the textbook.", hindi: "प्रकाशक ने पाठ्यपुस्तक का संशोधित संस्करण नहीं छापा है।", subject: "The publisher", aux: "has not", verb: "printed", object: "revised edition" },
                    { id: "neg-m9", english: "You have not updated the antivirus software on your PC.", hindi: "आपने अपने पीसी पर एंटीवायरस सॉफ्टवेयर अपडेट नहीं किया है।", subject: "You", aux: "have not", verb: "updated", object: "antivirus" },
                    { id: "neg-m10", english: "The council has not approved the proposed residential expansion plan.", hindi: "परिषद ने प्रस्तावित आवासीय विस्तार योजना को मंजूरी नहीं दी है।", subject: "The council", aux: "has not", verb: "approved", object: "expansion plan" }
                ],
                hard: [
                    { id: "neg-h1", english: "The parliamentary committee has not reached a consensus on the bill.", hindi: "संसदीय समिति विधेयक पर सर्वसम्मति पर नहीं पहुँची है।", subject: "The committee", aux: "has not", verb: "reached", object: "a consensus" },
                    { id: "neg-h2", english: "International trade negotiators have not resolved key tariff disputes.", hindi: "अंतरराष्ट्रीय व्यापार वार्ताकारों ने प्रमुख शुल्क विवादों को नहीं सुलझाया है।", subject: "Negotiators", aux: "have not", verb: "resolved", object: "disputes" },
                    { id: "neg-h3", english: "The security team has not detected any further system vulnerabilities.", hindi: "सुरक्षा टीम को आगे की किसी भी प्रणाली भेद्यता का पता नहीं चला है।", subject: "The team", aux: "has not", verb: "detected", object: "vulnerabilities" },
                    { id: "neg-h4", english: "Economists have not predicted such a drastic slump in market demand.", hindi: "अर्थशास्त्रियों ने बाजार की मांग में इतनी भारी गिरावट का अनुमान नहीं लगाया था।", subject: "Economists", aux: "have not", verb: "predicted", object: "slump" },
                    { id: "neg-h5", english: "The medical institute has not published the full preliminary clinical findings.", hindi: "चिकित्सा संस्थान ने पूर्ण प्रारंभिक नैदानिक निष्कर्ष प्रकाशित नहीं किए हैं।", subject: "The institute", aux: "has not", verb: "published", object: "clinical findings" },
                    { id: "neg-h6", english: "Structural engineers have not authorized the heavy vehicle movement on the bridge.", hindi: "संरचनात्मक इंजीनियरों ने पुल पर भारी वाहनों की आवाजाही को अधिकृत नहीं किया है।", subject: "Engineers", aux: "have not", verb: "authorized", object: "vehicle movement" },
                    { id: "neg-h7", english: "The executive board has not sanctioned the emergency budget allocation.", hindi: "कार्यकारी बोर्ड ने आपातकालीन बजट आवंटन को मंजूरी नहीं दी है।", subject: "The board", aux: "has not", verb: "sanctioned", object: "budget allocation" },
                    { id: "neg-h8", english: "Airline operators have not restored normal international flight schedules.", hindi: "एयरलाइन संचालकों ने सामान्य अंतरराष्ट्रीय उड़ान समय सारिणी बहाल नहीं की है।", subject: "Operators", aux: "have not", verb: "restored", object: "schedules" },
                    { id: "neg-h9", english: "The research student has not defended his thesis before the academic panel.", hindi: "शोध छात्र ने अकादमिक पैनल के समक्ष अपने थीसिस का बचाव नहीं किया है।", subject: "The student", aux: "has not", verb: "defended", object: "his thesis" },
                    { id: "neg-h10", english: "Environmental agencies have not registered any reduction in ocean pollution.", hindi: "पर्यावरण एजेंसियों ने समुद्री प्रदूषण में कोई कमी दर्ज नहीं की है।", subject: "Agencies", aux: "have not", verb: "registered", object: "pollution reduction" }
                ]
            }
        },

        // 7. Interrogative Sentences (प्रश्नवाचक वाक्य)
        interrogative: {
            title: "Interrogative Sentences",
            titleHindi: "प्रश्नवाचक वाक्य (Yes/No Questions)",
            formula: "Has / Have + Subject + V3 + Object?",
            formulaPlural: "Have + I / You / We / They + V3?",
            formulaSingular: "Has + He / She / It / Name + V3?",
            explanation: "Interrogative sentences ask whether a completed action has taken place up to the present moment.",
            explanationHindi: "प्रश्नवाचक वाक्य यह पूछते हैं कि क्या कोई कार्य वर्तमान समय तक पूरा हो चुका है या नहीं।",
            groups: {
                groupHaveQ: {
                    name: "Group A: Have + Plural Subjects & I/You",
                    rule: "Start question with 'Have' for I, You, We, They, Plurals",
                    ruleHindi: "I, You, We, They और बहुवचन कर्ता के लिए प्रश्न की शुरुआत 'Have' से करें।",
                    examples: [
                        { english: "Have you finished your dinner?", hindi: "क्या आपने अपना रात का खाना खा लिया है?", verb: "Have ... finished" },
                        { english: "Have they left for the airport?", hindi: "क्या वे हवाई अड्डे के लिए निकल चुके हैं?", verb: "Have ... left" }
                    ]
                },
                groupHasQ: {
                    name: "Group B: Has + Singular Subjects",
                    rule: "Start question with 'Has' for He, She, It, Singular Names",
                    ruleHindi: "He, She, It और एकवचन कर्ता के लिए प्रश्न की शुरुआत 'Has' से करें।",
                    examples: [
                        { english: "Has she completed the task?", hindi: "क्या वह काम पूरा कर चुकी है?", verb: "Has ... completed" },
                        { english: "Has Rahul arrived at school?", hindi: "क्या राहुल स्कूल पहुँच चुका है?", verb: "Has ... arrived" }
                    ]
                }
            },
            criticalRule: {
                ruleTitle: "CRITICAL RULE: Move Has/Have before Subject!",
                ruleTitleHindi: "महत्वपूर्ण नियम: Has/Have को कर्ता से पहले रखें!",
                explanation: "Questions must start with Has or Have. Always keep the main verb in V3 form.",
                explanationHindi: "प्रश्न में Has/Have हमेशा कर्ता (Subject) से पहले आता है और क्रिया V3 रूप में रहती है।",
                comparisonExamples: [
                    { wrong: "You have finished your work?", correct: "Have you finished your work?", note: "Put Have before 'you'." },
                    { wrong: "Has she wrote the letter?", correct: "Has she written the letter?", note: "Use V3 'written', not V2 'wrote'." },
                    { wrong: "Have they went home?", correct: "Have they gone home?", note: "Use V3 'gone', not V2 'went'." }
                ]
            },
            shortAnswers: [
                {
                    question: "Have you finished your homework?",
                    questionHindi: "क्या आपने अपना गृहकार्य पूरा कर लिया है?",
                    yesAnswer: "Yes, I have.",
                    noAnswer: "No, I haven't.",
                    noteHindi: "हाँ में: Yes, I have. | ना में: No, I haven't."
                },
                {
                    question: "Has she locked the door?",
                    questionHindi: "क्या उसने दरवाजा लॉक कर दिया है?",
                    yesAnswer: "Yes, she has.",
                    noAnswer: "No, she hasn't.",
                    noteHindi: "हाँ में: Yes, she has. | ना में: No, she hasn't."
                }
            ],
            sentences: {
                easy: [
                    { id: "int-e1", english: "Have you finished your homework?", hindi: "क्या आपने अपना गृहकार्य पूरा कर लिया है?", aux: "Have", subject: "you", verb: "finished", object: "homework" },
                    { id: "int-e2", english: "Has she cooked dinner for us?", hindi: "क्या उसने हमारे लिए रात का खाना बनाया है?", aux: "Has", subject: "she", verb: "cooked", object: "dinner" },
                    { id: "int-e3", english: "Has he driven a sports car before?", hindi: "क्या उसने पहले कभी स्पोर्ट्स कार चलाई है?", aux: "Has", subject: "he", verb: "driven", object: "sports car" },
                    { id: "int-e4", english: "Have they won the championship match?", hindi: "क्या वे चैम्पियनशिप मैच जीत चुके हैं?", aux: "Have", subject: "they", verb: "won", object: "match" },
                    { id: "int-e5", english: "Have we met this gentleman before?", hindi: "क्या हम इस महानुभाव से पहले मिल चुके हैं?", aux: "Have", subject: "we", verb: "met", object: "this gentleman" },
                    { id: "int-e6", english: "Has Rahul sent the email attachment?", hindi: "क्या राहुल ने ईमेल अटैचमेंट भेज दिया है?", aux: "Has", subject: "Rahul", verb: "sent", object: "attachment" },
                    { id: "int-e7", english: "Has the train arrived at platform one?", hindi: "क्या ट्रेन प्लेटफॉर्म नंबर एक पर आ चुकी है?", aux: "Has", subject: "the train", verb: "arrived", object: "at platform one" },
                    { id: "int-e8", english: "Have you taken your morning medicine?", hindi: "क्या आपने अपनी सुबह की दवा ले ली है?", aux: "Have", subject: "you", verb: "taken", object: "medicine" },
                    { id: "int-e9", english: "Have all the birds flown away?", hindi: "क्या सभी पक्षी उड़ चुके हैं?", aux: "Have", subject: "all the birds", verb: "flown", object: "away" },
                    { id: "int-e10", english: "Has it stopped raining in the city?", hindi: "क्या शहर में बारिश होना बंद हो गया है?", aux: "Has", subject: "it", verb: "stopped", object: "raining" }
                ],
                medium: [
                    { id: "int-m1", english: "Have you completed all your semester examinations?", hindi: "क्या आपने अपनी सभी सेमेस्टर परीक्षाएं पूरी कर ली हैं?", aux: "Have", subject: "you", verb: "completed", object: "examinations" },
                    { id: "int-m2", english: "Has she submitted the quarterly project report?", hindi: "क्या उसने तिमाही परियोजना रिपोर्ट जमा कर दी है?", aux: "Has", subject: "she", verb: "submitted", object: "report" },
                    { id: "int-m3", english: "Have they constructed the new bridge over the river?", hindi: "क्या उन्होंने नदी पर नया पुल बना लिया है?", aux: "Have", subject: "they", verb: "constructed", object: "bridge" },
                    { id: "int-m4", english: "Has your brother secured admission in college?", hindi: "क्या आपके भाई को कॉलेज में दाखिला मिल गया है?", aux: "Has", subject: "your brother", verb: "secured", object: "admission" },
                    { id: "int-m5", english: "Have we reserved our hotel rooms in advance?", hindi: "क्या हमने पहले से अपने होटल के कमरे बुक कर लिए हैं?", aux: "Have", subject: "we", verb: "reserved", object: "hotel rooms" },
                    { id: "int-m6", english: "Has the manager approved your leave application?", hindi: "क्या मैनेजर ने आपके छुट्टी के आवेदन को मंजूरी दे दी है?", aux: "Has", subject: "the manager", verb: "approved", object: "leave application" },
                    { id: "int-m7", english: "Have the engineers fixed the internet connectivity issue?", hindi: "क्या इंजीनियरों ने इंटरनेट कनेक्टिविटी की समस्या को ठीक कर दिया है?", aux: "Have", subject: "the engineers", verb: "fixed", object: "internet issue" },
                    { id: "int-m8", english: "Has the author released the new paperback edition?", hindi: "क्या लेखक ने नया पेपरबैक संस्करण जारी कर दिया है?", aux: "Has", subject: "the author", verb: "released", object: "paperback edition" },
                    { id: "int-m9", english: "Have you updated your mobile banking security PIN?", hindi: "क्या आपने अपना मोबाइल बैंकिंग सुरक्षा पिन अपडेट कर लिया है?", aux: "Have", subject: "you", verb: "updated", object: "banking PIN" },
                    { id: "int-m10", english: "Has the committee passed the revised budget proposal?", hindi: "क्या समिति ने संशोधित बजट प्रस्ताव पारित कर दिया है?", aux: "Has", subject: "the committee", verb: "passed", object: "budget proposal" }
                ],
                hard: [
                    { id: "int-h1", english: "Has the parliamentary panel finalized the draft legislation bill?", hindi: "क्या संसदीय पैनल ने मसौदा कानून विधेयक को अंतिम रूप दे दिया है?", aux: "Has", subject: "the panel", verb: "finalized", object: "the bill" },
                    { id: "int-h2", english: "Have international diplomats signed the mutual defense pact?", hindi: "क्या अंतरराष्ट्रीय राजनयिकों ने पारस्परिक रक्षा समझौते पर हस्ताक्षर किए हैं?", aux: "Have", subject: "diplomats", verb: "signed", object: "pact" },
                    { id: "int-h3", english: "Has the cybersecurity team detected any critical system breaches?", hindi: "क्या साइबर सुरक्षा टीम को किसी गंभीर सिस्टम उल्लंघन का पता चला है?", aux: "Has", subject: "the team", verb: "detected", object: "breaches" },
                    { id: "int-h4", english: "Have economic analysts forecasted higher quarterly inflation rates?", hindi: "क्या आर्थिक विश्लेषकों ने उच्च तिमाही मुद्रास्फीति दरों का अनुमान लगाया है?", aux: "Have", subject: "analysts", verb: "forecasted", object: "inflation rates" },
                    { id: "int-h5", english: "Has the medical organization conducted nationwide vaccine trials?", hindi: "क्या चिकित्सा संगठन ने देशव्यापी टीकों का परीक्षण किया है?", aux: "Has", subject: "the organization", verb: "conducted", object: "vaccine trials" },
                    { id: "int-h6", english: "Have structural inspectors recertified the safety of the dam?", hindi: "क्या संरचनात्मक निरीक्षकों ने बांध की सुरक्षा को पुनः प्रमाणित किया है?", aux: "Have", subject: "inspectors", verb: "recertified", object: "safety of dam" },
                    { id: "int-h7", english: "Has the executive board sanctioned the new corporate merger?", hindi: "क्या कार्यकारी बोर्ड ने नए कॉर्पोरेट विलय को मंजूरी दे दी है?", aux: "Has", subject: "the board", verb: "sanctioned", object: "corporate merger" },
                    { id: "int-h8", english: "Have airline operators resumed direct flights to London?", hindi: "क्या एयरलाइन संचालकों ने लंदन के लिए सीधी उड़ानें फिर से शुरू कर दी हैं?", aux: "Have", subject: "operators", verb: "resumed", object: "direct flights" },
                    { id: "int-h9", english: "Have you submitted the verified research findings to the board?", hindi: "क्या आपने बोर्ड को सत्यापित शोध निष्कर्ष जमा कर दिए हैं?", aux: "Have", subject: "you", verb: "submitted", object: "research findings" },
                    { id: "int-h10", english: "Have environmental scientists published the climate assessment report?", hindi: "क्या पर्यावरण वैज्ञानिकों ने जलवायु मूल्यांकन रिपोर्ट प्रकाशित की है?", aux: "Have", subject: "scientists", verb: "published", object: "assessment report" }
                ]
            }
        },

        // 8. WH Questions (WH प्रश्न)
        whQuestions: {
            title: "WH Questions",
            titleHindi: "WH प्रश्नवाचक वाक्य",
            formula: "WH Word + has / have + Subject + V3 + Object?",
            formulaPlural: "WH Word + have + I/You/We/They + V3?",
            formulaSingular: "WH Word + has + He/She/It/Name + V3?",
            explanation: "WH Questions ask for specific information (What, Where, Why, When, Who, How, How long, How many times) regarding a completed action.",
            explanationHindi: "विशेष जानकारी वाले प्रश्नों के लिए WH शब्द (What, Where, Why आदि) को Has/Have से भी पहले लगाया जाता है।",
            examplesShowcase: [
                { english: "What have you done?", hindi: "आपने क्या किया है?", whWord: "What", aux: "have" },
                { english: "Where has she gone?", hindi: "वह कहाँ गई है?", whWord: "Where", aux: "has" },
                { english: "Why have they stopped working?", hindi: "उन्होंने काम करना क्यों बंद कर दिया है?", whWord: "Why", aux: "have" },
                { english: "How long have you lived here?", hindi: "आप यहाँ कितने समय से रह रहे हैं?", whWord: "How long", aux: "have" }
            ],
            sentences: {
                easy: [
                    { id: "wh-e1", english: "What have you done today?", hindi: "आज आपने क्या किया है?", whWord: "What", aux: "have", subject: "you", verb: "done" },
                    { id: "wh-e2", english: "Where has she hidden the house keys?", hindi: "उसने घर की चाबियाँ कहाँ छिपाई हैं?", whWord: "Where", aux: "has", subject: "she", verb: "hidden" },
                    { id: "wh-e3", english: "Why have they cancelled the game?", hindi: "उन्होंने खेल क्यों रद्द कर दिया है?", whWord: "Why", aux: "have", subject: "they", verb: "cancelled" },
                    { id: "wh-e4", english: "When has he arrived at the station?", hindi: "वह स्टेशन पर कब पहुँचा है?", whWord: "When", aux: "has", subject: "he", verb: "arrived" },
                    { id: "wh-e5", english: "Who has broken this glass vase?", hindi: "यह कांच का फूलदान किसने तोड़ा है?", whWord: "Who", aux: "has", subject: "Who", verb: "broken" },
                    { id: "wh-e6", english: "How have you solved this math problem?", hindi: "आपने गणित की इस समस्या को कैसे हल किया है?", whWord: "How", aux: "have", subject: "you", verb: "solved" },
                    { id: "wh-e7", english: "What has Rahul bought from the shop?", hindi: "राहुल ने दुकान से क्या खरीदा है?", whWord: "What", aux: "has", subject: "Rahul", verb: "bought" },
                    { id: "wh-e8", english: "Where have we parked our car?", hindi: "हमने अपनी कार कहाँ पार्क की है?", whWord: "Where", aux: "have", subject: "we", verb: "parked" },
                    { id: "wh-e9", english: "Why has the baby started crying?", hindi: "बच्चा क्यों रोने लगा है?", whWord: "Why", aux: "has", subject: "the baby", verb: "started" },
                    { id: "wh-e10", english: "Which movie have you selected to watch?", hindi: "आपने देखने के लिए कौन सी फिल्म चुनी है?", whWord: "Which", aux: "have", subject: "you", verb: "selected" }
                ],
                medium: [
                    { id: "wh-m1", english: "What have you prepared for the international food festival?", hindi: "आपने अंतरराष्ट्रीय खाद्य महोत्सव के लिए क्या तैयार किया है?", whWord: "What", aux: "have", subject: "you", verb: "prepared" },
                    { id: "wh-m2", english: "Where has the doctor opened his new medical clinic?", hindi: "डॉक्टर ने अपना नया मेडिकल क्लिनिक कहाँ खोला है?", whWord: "Where", aux: "has", subject: "the doctor", verb: "opened" },
                    { id: "wh-m3", english: "Why has the management increased the working hours?", hindi: "प्रबंधन ने काम के घंटे क्यों बढ़ा दिए हैं?", whWord: "Why", aux: "has", subject: "the management", verb: "increased" },
                    { id: "wh-m4", english: "When have the foreign guests arrived at the hotel?", hindi: "विदेशी अतिथि होटल कब पहुँचे हैं?", whWord: "When", aux: "have", subject: "the guests", verb: "arrived" },
                    { id: "wh-m5", english: "How long have you studied English grammar?", hindi: "आप कितने समय से अंग्रेजी व्याकरण का अध्ययन कर चुके हैं?", whWord: "How long", aux: "have", subject: "you", verb: "studied" },
                    { id: "wh-m6", english: "Which university has she selected for higher studies?", hindi: "उच्च शिक्षा के लिए उसने किस विश्वविद्यालय को चुना है?", whWord: "Which", aux: "has", subject: "she", verb: "selected" },
                    { id: "wh-m7", english: "Whose laptop have you borrowed for the presentation?", hindi: "आपने प्रस्तुति के लिए किसका लैपटॉप उधार लिया है?", whWord: "Whose", aux: "have", subject: "you", verb: "borrowed" },
                    { id: "wh-m8", english: "Who has authorized this financial expenditure?", hindi: "इस वित्तीय व्यय को किसने अधिकृत किया है?", whWord: "Who", aux: "has", subject: "Who", verb: "authorized" },
                    { id: "wh-m9", english: "How many times have you visited Jaipur?", hindi: "आप कितनी बार जयपुर जा चुके हैं?", whWord: "How many times", aux: "have", subject: "you", verb: "visited" },
                    { id: "wh-m10", english: "Where have they constructed the new solar power plant?", hindi: "उन्होंने नया सौर ऊर्जा संयंत्र कहाँ स्थापित किया है?", whWord: "Where", aux: "have", subject: "they", verb: "constructed" }
                ],
                hard: [
                    { id: "wh-h1", english: "What innovative solutions has the research team developed for water purification?", hindi: "शोध टीम ने जल शोधन के लिए क्या नवीन समाधान विकसित किए हैं?", whWord: "What", aux: "has", subject: "the team", verb: "developed" },
                    { id: "wh-h2", english: "Where have urban planners constructed the eco-friendly residential units?", hindi: "शहरी योजनाकारों ने पर्यावरण-अनुकूल आवासीय इकाइयों का निर्माण कहाँ किया है?", whWord: "Where", aux: "have", subject: "planners", verb: "constructed" },
                    { id: "wh-h3", english: "Why have financial regulators imposed strict compliance rules on banks?", hindi: "वित्तीय नियामकों ने बैंकों पर कड़े अनुपालन नियम क्यों लगाए हैं?", whWord: "Why", aux: "have", subject: "regulators", verb: "imposed" },
                    { id: "wh-h4", english: "How has the software department resolved the server performance bottleneck?", hindi: "सॉफ्टवेयर विभाग ने सर्वर प्रदर्शन बाधा को कैसे हल किया है?", whWord: "How", aux: "has", subject: "the department", verb: "resolved" },
                    { id: "wh-h5", english: "When have international flight operators resumed normal passenger services?", hindi: "अंतरराष्ट्रीय उड़ान संचालकों ने सामान्य यात्री सेवाएं कब फिर से शुरू की हैं?", whWord: "When", aux: "have", subject: "operators", verb: "resumed" },
                    { id: "wh-h6", english: "Which security protocols has the cybersecurity chief implemented recently?", hindi: "साइबर सुरक्षा प्रमुख ने हाल ही में कौन से सुरक्षा प्रोटोकॉल लागू किए हैं?", whWord: "Which", aux: "has", subject: "the chief", verb: "implemented" },
                    { id: "wh-h7", english: "Whose permission have developers obtained before launching the update script?", hindi: "अपडेट स्क्रिप्ट लॉन्च करने से पहले डेवलपर्स ने किसकी अनुमति प्राप्त की है?", whWord: "Whose", aux: "have", subject: "developers", verb: "obtained" },
                    { id: "wh-h8", english: "Who has coordinated the disaster recovery operations in the coastal region?", hindi: "तटीय क्षेत्र में आपदा राहत अभियानों का समन्वय किसने किया है?", whWord: "Who", aux: "has", subject: "Who", verb: "coordinated" },
                    { id: "wh-h9", english: "Why has the central bank adjusted the benchmark interest rates this quarter?", hindi: "केंद्रीय बैंक ने इस तिमाही में बेंचमार्क ब्याज दरों को क्यों समायोजित किया है?", whWord: "Why", aux: "has", subject: "central bank", verb: "adjusted" },
                    { id: "wh-h10", english: "How long have climate scientists recorded rising ocean surface temperatures?", hindi: "जलवायु वैज्ञानिकों ने कितने समय से समुद्र की सतह के बढ़ते तापमान को दर्ज किया है?", whWord: "How long", aux: "have", subject: "scientists", verb: "recorded" }
                ]
            }
        },

        // 9. Common Mistakes & Corrections / सामान्य गलतियाँ (15 Mistake Categories)
        commonMistakes: {
            title: "Common Mistakes & Corrections",
            titleHindi: "सामान्य गलतियाँ और सही नियम (15 Mistakes)",
            introduction: "Avoid these 15 common errors while learning Present Perfect Tense.",
            introductionHindi: "Present Perfect में अक्सर होने वाली इन 15 प्रमुख गलतियों से बचें:",
            mistakes: [
                {
                    id: "missing-auxiliary",
                    title: "1. Missing Auxiliary Verb (has/have भूल जाना)",
                    titleHindi: "has/have का प्रयोग न करना",
                    wrong: "I finished my work.",
                    correct: "I have finished my work.",
                    explanation: "In Present Perfect, you must use has/have before V3 verb.",
                    explanationHindi: "Present Perfect में V3 क्रिया से पहले has/have लगाना अनिवार्य है।",
                    rule: "Subject + has/have + V3"
                },
                {
                    id: "wrong-auxiliary-agreement",
                    title: "2. Wrong Auxiliary Agreement (गलत सहायक क्रिया)",
                    titleHindi: "He/She के साथ 'have' या I के साथ 'has' लगाना",
                    wrong: "He have completed the task.",
                    correct: "He has completed the task.",
                    explanation: "Use 'has' with singular subjects (he/she/it/Rahul) and 'have' with plural subjects and I/You.",
                    explanationHindi: "एकवचन (He/She/It) के साथ has और I/You/We/They के साथ have का प्रयोग करें।",
                    rule: "He/She/It → has | I/You/We/They → have"
                },
                {
                    id: "using-v1-after-auxiliary",
                    title: "3. Using V1 instead of V3 after Has/Have",
                    titleHindi: "Has/Have के बाद V1 (base form) का प्रयोग करना",
                    wrong: "She has finish her homework.",
                    correct: "She has finished her homework.",
                    explanation: "Always use V3 (Past Participle) after has/have, never V1.",
                    explanationHindi: "has/have के बाद हमेशा V3 (finished) आता है, V1 (finish) नहीं।",
                    rule: "has/have + V3 (NEVER has + V1)"
                },
                {
                    id: "using-v2-instead-of-v3",
                    title: "4. Using V2 (Past Simple form) instead of V3",
                    titleHindi: "Has/Have के बाद V2 (went, ate) का प्रयोग करना",
                    wrong: "They have went to Mumbai.",
                    correct: "They have gone to Mumbai.",
                    explanation: "Do not use V2 (went) after has/have. Use V3 (gone).",
                    explanationHindi: "has/have के बाद V2 (went) नहीं, V3 (gone) का प्रयोग होता है।",
                    rule: "have + V3 (gone)"
                },
                {
                    id: "wrong-irregular-v3",
                    title: "5. Wrong Irregular V3 Form",
                    titleHindi: "अनियमित क्रियाओं का गलत V3 रूप",
                    wrong: "I have ate dinner.",
                    correct: "I have eaten dinner.",
                    explanation: "'ate' is V2. The correct V3 of 'eat' is 'eaten'.",
                    explanationHindi: "eat का V2 ate होता है, लेकिन V3 eaten होता है।",
                    rule: "eat (V1) → ate (V2) → eaten (V3)"
                },
                {
                    id: "finished-past-time-error",
                    title: "6. Using Finished Past Time Expressions",
                    titleHindi: "सटीक भूतकाल (yesterday, last year) के साथ Present Perfect का प्रयोग",
                    wrong: "I have seen him yesterday.",
                    correct: "I saw him yesterday.",
                    explanation: "Do not use Present Perfect with finished past time expressions like yesterday, last year, ago. Use Simple Past instead.",
                    explanationHindi: "yesterday, last year, ago के साथ Present Perfect (have seen) नहीं, Simple Past (saw) का प्रयोग करें।",
                    rule: "Yesterday / Last year → Simple Past (V2)"
                },
                {
                    id: "present-perfect-vs-past-simple",
                    title: "7. Confusing Present Perfect with Simple Past",
                    titleHindi: "Present Perfect और Simple Past में भ्रम",
                    wrong: "I have completed my degree in 2020.",
                    correct: "I completed my degree in 2020.",
                    explanation: "Specific year (in 2020) requires Simple Past (completed).",
                    explanationHindi: "सटीक वर्ष (in 2020) बताने के लिए Simple Past (V2) का प्रयोग होता है।",
                    rule: "Specific Year (2020) → Simple Past"
                },
                {
                    id: "confusing-since-and-for",
                    title: "8. Confusing 'Since' and 'For'",
                    titleHindi: "Since और For के प्रयोग में गलती",
                    wrong: "I have lived here for 2015.",
                    correct: "I have lived here since 2015.",
                    explanation: "Use 'since' for a starting point (2015) and 'for' for duration (5 years).",
                    explanationHindi: "सटीक समय बिंदु (2015) के लिए since तथा कुल समय अवधि (5 years) के लिए for लगाएं।",
                    rule: "Since = starting point | For = duration"
                },
                {
                    id: "incorrect-question-order",
                    title: "9. Incorrect Question Word Order",
                    titleHindi: "प्रश्नवाचक वाक्य में गलत पदक्रम",
                    wrong: "Why you have done this?",
                    correct: "Why have you done this?",
                    explanation: "In WH questions, Has/Have must come BEFORE the subject.",
                    explanationHindi: "प्रश्न में Has/Have हमेशा कर्ता (Subject) से पहले आता है।",
                    rule: "WH-word + Has/Have + Subject + V3?"
                },
                {
                    id: "forgetting-question-mark",
                    title: "10. Forgetting Question Mark in Interrogative",
                    titleHindi: "प्रश्नवाचक चिह्न न लगाना",
                    wrong: "Has he completed the task.",
                    correct: "Has he completed the task?",
                    explanation: "Always place a question mark (?) at the end of an interrogative sentence.",
                    explanationHindi: "प्रश्नवाचक वाक्य के अंत में प्रश्नवाचक चिह्न (?) अनिवार्य है।",
                    rule: "Has/Have + Subject + V3 + Object?"
                },
                {
                    id: "using-has-with-i",
                    title: "11. Using 'has' with 'I' or 'You'",
                    titleHindi: "I या You के साथ 'has' लगाना",
                    wrong: "I has written a letter.",
                    correct: "I have written a letter.",
                    explanation: "Subject 'I' and 'You' always take 'have', never 'has'.",
                    explanationHindi: "I और You के साथ हमेशा 'have' आता है।",
                    rule: "I / You → HAVE"
                },
                {
                    id: "using-have-with-singular",
                    title: "12. Using 'have' with Singular Noun",
                    titleHindi: "एकवचन नाम के साथ 'have' लगाना",
                    wrong: "Rahul have submitted the form.",
                    correct: "Rahul has submitted the form.",
                    explanation: "Singular names take 'has'.",
                    explanationHindi: "एकवचन नाम (Rahul) के साथ 'has' का प्रयोग करें।",
                    rule: "Singular Name → HAS"
                },
                {
                    id: "double-past-verb-error",
                    title: "13. Double Past Form Error",
                    titleHindi: "दोहरी Past Form की गलती",
                    wrong: "He has did the work.",
                    correct: "He has done the work.",
                    explanation: "'did' is V2. Use V3 'done' after 'has'.",
                    explanationHindi: "did (V2) की जगह V3 (done) का प्रयोग करें।",
                    rule: "has + done (V3)"
                },
                {
                    id: "incorrect-negative-order",
                    title: "14. Incorrect Negative Word Order",
                    titleHindi: "नकारात्मक वाक्य में 'not' की गलत स्थिति",
                    wrong: "He not has finished work.",
                    correct: "He has not finished work.",
                    explanation: "'not' must come immediately AFTER has or have.",
                    explanationHindi: "'not' हमेशा has/have के ठीक बाद आता है।",
                    rule: "Subject + has/have + not + V3"
                },
                {
                    id: "hindi-to-english-literal-error",
                    title: "15. Hindi Literal Translation Error ('चुका हूँ')",
                    titleHindi: "हिंदी से अंग्रेजी का शाब्दिक अनुवाद (is/am + V3)",
                    wrong: "I am eaten food.",
                    correct: "I have eaten food.",
                    explanation: "Do not translate 'खा चुका हूँ' as 'am eaten'. Use 'have eaten'.",
                    explanationHindi: "'खा चुका हूँ' के लिए am eaten नहीं, have eaten का प्रयोग करें।",
                    rule: "Present Perfect = Has/Have + V3"
                }
            ]
        },

        // 10. Summary & Revision / संक्षिप्त पुनरावृत्ति
        summary: {
            title: "Present Perfect Summary",
            titleHindi: "पूर्ण वर्तमान काल — संक्षिप्त पुनरावृत्ति",
            introduction: "Master Present Perfect Tense with quick rules, major uses, formulas, and 15 revision examples.",
            introductionHindi: "Present Perfect Tense की त्वरित पुनरावृत्ति और 15 अभ्यास उदाहरण:",
            quickRules: [
                "I / You / We / They / Plural → HAVE + V3",
                "He / She / It / Singular → HAS + V3",
                "Positive: Subject + has/have + V3 + Object",
                "Negative: Subject + has/have + not + V3 + Object",
                "Interrogative: Has/Have + Subject + V3 + Object?",
                "WH Question: WH-word + has/have + Subject + V3 + Object?",
                "Since = Starting point (since 2020) | For = Duration (for 5 years)",
                "Finished past time (yesterday, last year) → Simple Past (V2), NOT Present Perfect."
            ],
            memoryRule: {
                ruleTitle: "GOLDEN MEMORY RULE: HAS/HAVE आया → Main Verb V3 (Past Participle) में आया!",
                ruleTitleHindi: "याद रखने का स्वर्णिम नियम: Has/Have आया → Main Verb हमेशा V3 (Past Participle form) में आया!",
                ruleText: "He/She/It/Singular → HAS  |  I/You/We/They/Plural → HAVE  |  HAS/HAVE → V3 (Past Participle)!"
            },
            sentences: {
                easy: [
                    { id: "sum-e1", english: "I have finished my homework.", hindi: "मैंने अपना गृहकार्य पूरा कर लिया है।", note: "Subject 'I' takes 'have' + V3" },
                    { id: "sum-e2", english: "She has cooked food.", hindi: "वह खाना बना चुकी है।", note: "Singular subject takes 'has' + V3" },
                    { id: "sum-e3", english: "They have won the match.", hindi: "वे मैच जीत चुके हैं।", note: "Plural subject takes 'have' + V3" },
                    { id: "sum-e4", english: "He has not locked the door.", hindi: "उसने दरवाजा लॉक नहीं किया है।", note: "Negative with 'has not' + V3" },
                    { id: "sum-e5", english: "Have you seen this movie?", hindi: "क्या आपने यह फिल्म देखी है?", note: "Interrogative starting with 'Have'" }
                ],
                medium: [
                    { id: "sum-m1", english: "He has lived in Delhi since 2015.", hindi: "वह 2015 से दिल्ली में रह रहा है / रहता आया है।", note: "Continuing state with 'since'" },
                    { id: "sum-m2", english: "We have known each other for five years.", hindi: "हम पाँच साल से एक-दूसरे को जानते हैं।", note: "Continuing relationship with 'for'" },
                    { id: "sum-m3", english: "She has not received the offer letter yet.", hindi: "उसे अभी तक ऑफर लेटर नहीं मिला है।", note: "Negative with 'yet' + V3" },
                    { id: "sum-m4", english: "Why have they cancelled the meeting?", hindi: "उन्होंने बैठक क्यों रद्द कर दी है?", note: "WH question with 'Why' + have" },
                    { id: "sum-m5", english: "Your English speaking skill has improved remarkably.", hindi: "आपकी अंग्रेजी बोलने की क्षमता में उल्लेखनीय सुधार हुआ है।", note: "Present outcome of past practice" }
                ],
                hard: [
                    { id: "sum-h1", english: "Research scientists have discovered a potential cure for the disease.", hindi: "शोध वैज्ञानिकों ने बीमारी के संभावित इलाज की खोज की है।", note: "Complex subject with 'have' + V3" },
                    { id: "sum-h2", english: "The management has not compromised on quality standards.", hindi: "प्रबंधन ने गुणवत्ता मानकों से समझौता नहीं किया है।", note: "Professional negative with 'has not'" },
                    { id: "sum-h3", english: "Which software have developers integrated into the security platform?", hindi: "डेवलपर्स ने सुरक्षा प्लेटफॉर्म में कौन सा सॉफ्टवेयर एकीकृत किया है?", note: "Complex WH question" },
                    { id: "sum-h4", english: "Who has coordinated the emergency medical response team?", hindi: "आपातकालीन चिकित्सा प्रतिक्रिया टीम का समन्वय किसने किया है?", note: "Who as subject with 'has' + V3" },
                    { id: "sum-h5", english: "Aviation authorities have upgraded radar communication systems.", hindi: "उड्डयन प्राधिकरणों ने रडार संचार प्रणालियों को अपग्रेड कर दिया है।", note: "Completed policy development" }
                ]
            }
        },

        // 11. Exercises (Practice Sentences - 120 Total Items)
        exercises: {
            title: "Present Perfect Practice Sentences",
            titleHindi: "पूर्ण वर्तमान काल — अभ्यास (120 Practice Sentences)",
            introduction: "Practice all 120 sentences across Positive, Negative, Interrogative, and WH Questions to master Present Perfect Tense.",
            introductionHindi: "Present Perfect Tense के 120 अभ्यास वाक्यों (सकारात्मक, नकारात्मक, प्रश्नवाचक एवं WH प्रश्न) के माध्यम से पूरा अभ्यास करें।",
            categories: []
        },

        // 12. Quiz Configuration
        quiz: {
            title: "Present Perfect Quiz",
            titleHindi: "पूर्ण वर्तमान काल — ज्ञान परीक्षा",
            questions: []
        }
    }
};

// Initialize categories referencing existing sections (120 Practice Sentences total)
presentPerfectLesson.sections.exercises.categories = [
    {
        id: "positive",
        title: "Positive Sentences Practice",
        titleHindi: "1. सकारात्मक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Positive Sentence",
        sentences: presentPerfectLesson.sections.positive.sentences
    },
    {
        id: "negative",
        title: "Negative Sentences Practice",
        titleHindi: "2. नकारात्मक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Negative Sentence",
        sentences: presentPerfectLesson.sections.negative.sentences
    },
    {
        id: "interrogative",
        title: "Interrogative Sentences Practice",
        titleHindi: "3. प्रश्नवाचक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Yes/No Question",
        sentences: presentPerfectLesson.sections.interrogative.sentences
    },
    {
        id: "whQuestions",
        title: "WH Questions Practice",
        titleHindi: "4. WH प्रश्न अभ्यास (30 Sentences)",
        typeLabel: "WH Question",
        sentences: presentPerfectLesson.sections.whQuestions.sentences
    }
];

/**
 * Get the complete Present Perfect lesson object
 * @returns {object}
 */
export function getPresentPerfectLesson() {
    return { ...presentPerfectLesson };
}

/**
 * Get a specific section of Present Perfect lesson data
 * @param {string} sectionName 
 * @returns {object|Array|null}
 */
export function getPresentPerfectSection(sectionName) {
    if (!sectionName || !presentPerfectLesson.sections) return null;
    return presentPerfectLesson.sections[sectionName] || null;
}
