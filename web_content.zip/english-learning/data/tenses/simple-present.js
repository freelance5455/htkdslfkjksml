/**
 * Simple Present Tense Lesson Data & Data Architecture
 * Single Source of Truth for Simple Present Tense (Hindi Medium).
 * Vanilla ES6 JavaScript Module.
 */

export const simplePresentLesson = {
    id: "simple-present",
    title: "Simple Present",
    titleHindi: "सामान्य वर्तमान काल",

    sections: {
        // 1. Identification / पहचान
        identification: {
            english: "Simple Present Tense is used to express daily routines, habits, general truths, and permanent situations.",
            hindi: "इस काल का प्रयोग दैनिक दिनचर्या, आदतों, सामान्य सत्यों और स्थायी स्थितियों को व्यक्त करने के लिए किया जाता है।",
            points: [
                {
                    english: "Daily Routine / Regular Work",
                    hindi: "रोज़ होने वाला काम या नियमित कार्य (जैसे: मैं रोज़ पढ़ाई करता हूँ।)"
                },
                {
                    english: "Habits and Customs",
                    hindi: "आदतें और नियम (जैसे: वह सुबह जल्दी उठता है।)"
                },
                {
                    english: "General / Universal Truths",
                    hindi: "सामान्य और सार्वभौमिक सत्य (जैसे: सूर्य पूर्व में उगता है।)"
                },
                {
                    english: "Permanent or General Situations",
                    hindi: "स्थायी या सामान्य स्थिति (जैसे: हम दिल्ली में रहते हैं।)"
                }
            ]
        },

        // 2. Uses / उपयोग
        uses: [
            {
                id: "habit-routine",
                title: "Habit / Routine",
                titleHindi: "आदत / दिनचर्या",
                explanation: "Actions that happen repeatedly or regularly.",
                explanationHindi: "वे कार्य जो बार-बार या नियमित रूप से होते हैं।",
                example: "I drink tea every morning."
            },
            {
                id: "general-truth",
                title: "General Truth",
                titleHindi: "सामान्य सत्य / विज्ञान के तथ्य",
                explanation: "Facts that are always true.",
                explanationHindi: "वे तथ्य जो हमेशा सत्य होते हैं।",
                example: "The Sun rises in the East."
            },
            {
                id: "repeated-action",
                title: "Repeated Action",
                titleHindi: "पुनरावृत्त कार्य",
                explanation: "Events occurring with frequency adverbs (always, often, usually).",
                explanationHindi: "वे कार्य जो निश्चित अंतराल पर होते हैं।",
                example: "He often plays cricket on Sundays."
            },
            {
                id: "permanent-situation",
                title: "Permanent / General Situation",
                titleHindi: "स्थायी स्थिति",
                explanation: "States or facts that remain true for a long time.",
                explanationHindi: "वे स्थितियां जो लंबे समय तक समान रहती हैं।",
                example: "She works at a bank."
            },
            {
                id: "timetable-schedule",
                title: "Timetable / Fixed Schedule",
                titleHindi: "समय सारिणी / निर्धारित कार्यक्रम",
                explanation: "Fixed future events following an official schedule.",
                explanationHindi: "निर्धारित समय सारिणी के अनुसार होने वाले कार्य।",
                example: "The train arrives at 9 PM."
            }
        ],

        // 3. Structure / Formula Overview
        structure: {
            positive: "Subject + V1 (+ s/es with He/She/It/Singular) + Object",
            negative: "Subject + do/does + not + V1 + Object",
            interrogative: "Do/Does + Subject + V1 + Object?",
            whQuestions: "WH-word + do/does + Subject + V1 + Object?"
        },

        // 4. Subject-Verb Rules / नियम
        subjectVerbRules: {
            pluralGroup: {
                subjects: ["I", "You", "We", "They", "Plural Nouns"],
                auxiliary: "do",
                verbForm: "V1 (Base Form without s/es)",
                hindiRule: "I, You, We, They और बहुवचन कर्ता के साथ केवल मुख्य क्रिया (V1) का प्रयोग होता है।"
            },
            singularGroup: {
                subjects: ["He", "She", "It", "Singular Nouns"],
                auxiliary: "does",
                verbForm: "V1 + s / es / ies",
                hindiRule: "He, She, It और एकवचन कर्ता के साथ V1 के अंत में s या es जोड़ा जाता है।"
            },
            spellingRules: [
                {
                    condition: "General verbs",
                    rule: "Add -s",
                    examples: "play → plays, read → reads, work → works"
                },
                {
                    condition: "Verbs ending in -ch, -sh, -ss, -x, -z, -o",
                    rule: "Add -es",
                    examples: "watch → watches, wash → washes, pass → passes, go → goes"
                },
                {
                    condition: "Verbs ending in Consonant + y",
                    rule: "Change y to -ies",
                    examples: "study → studies, fly → flies, try → tries"
                },
                {
                    condition: "Verbs ending in Vowel + y",
                    rule: "Add -s only",
                    examples: "play → plays, buy → buys, enjoy → enjoys"
                }
            ]
        },

        // 5. Positive / Affirmative Sentences (सकारात्मक वाक्य)
        positive: {
            title: "Positive / Affirmative Sentences",
            titleHindi: "सकारात्मक वाक्य",
            formulaPlural: "Subject (I/You/We/They) + V1 + Object",
            formulaSingular: "Subject (He/She/It/Singular) + V1(s/es/ies) + Object",
            explanation: "Positive sentences express facts, daily habits, or routines without negation or question.",
            explanationHindi: "सकारात्मक वाक्य बिना किसी प्रश्न या नकारात्मकता के तथ्यों, दैनिक आदतों या दिनचर्या को व्यक्त करते हैं।",
            
            groups: {
                groupA: {
                    name: "Group A: Plural Subjects & I/You",
                    subjects: ["I", "You", "We", "They", "Plural Nouns"],
                    rule: "Use base verb (V1) directly without adding s or es.",
                    ruleHindi: "मुख्य क्रिया (V1) का प्रयोग बिना s/es के करें।",
                    examples: [
                        { english: "I play cricket.", hindi: "मैं क्रिकेट खेलता हूँ।", verb: "play (V1)" },
                        { english: "They work hard.", hindi: "वे कड़ी मेहनत करते हैं।", verb: "work (V1)" }
                    ]
                },
                groupB: {
                    name: "Group B: Singular Subjects",
                    subjects: ["He", "She", "It", "Singular Name (Rahul/Priya)"],
                    rule: "Add -s, -es, or -ies to the base verb (V1).",
                    ruleHindi: "मुख्य क्रिया (V1) में -s, -es, या -ies जोड़ें।",
                    examples: [
                        { english: "He plays cricket.", hindi: "वह क्रिकेट खेलता है।", verb: "play → plays" },
                        { english: "She watches TV.", hindi: "वह टीवी देखती है।", verb: "watch → watches" }
                    ]
                }
            },

            sentences: {
                easy: [
                    { id: "pos-e1", english: "I read books every day.", hindi: "मैं रोज़ किताबें पढ़ता हूँ।", subject: "I", verb: "read" },
                    { id: "pos-e2", english: "You speak English very well.", hindi: "आप बहुत अच्छी अंग्रेजी बोलते हैं।", subject: "You", verb: "speak" },
                    { id: "pos-e3", english: "We live in India.", hindi: "हम भारत में रहते हैं।", subject: "We", verb: "live" },
                    { id: "pos-e4", english: "They play football in the evening.", hindi: "वे शाम को फुटबॉल खेलते हैं।", subject: "They", verb: "play" },
                    { id: "pos-e5", english: "He goes to school by bus.", hindi: "वह बस से स्कूल जाता है।", subject: "He", verb: "goes (go+es)" },
                    { id: "pos-e6", english: "She drinks tea in the morning.", hindi: "वह सुबह चाय पीती है।", subject: "She", verb: "drinks (drink+s)" },
                    { id: "pos-e7", english: "Rahul works in a bank.", hindi: "राहुल बैंक में काम करता है।", subject: "Rahul", verb: "works (work+s)" },
                    { id: "pos-e8", english: "The Sun shines brightly.", hindi: "सूर्य तेज चमकता है।", subject: "The Sun", verb: "shines (shine+s)" },
                    { id: "pos-e9", english: "Dogs bark at night.", hindi: "कुत्ते रात में भौंकते हैं।", subject: "Dogs", verb: "bark" },
                    { id: "pos-e10", english: "My sister cooks delicious food.", hindi: "मेरी बहन स्वादिष्ट खाना बनाती है।", subject: "My sister", verb: "cooks (cook+s)" }
                ],
                medium: [
                    { id: "pos-m1", english: "I usually wake up at six o'clock every morning.", hindi: "मैं आमतौर पर हर सुबह छह बजे उठता हूँ।", subject: "I", verb: "wake up" },
                    { id: "pos-m2", english: "She always completes her homework before dinner.", hindi: "वह हमेशा रात के खाने से पहले अपना गृहकार्य पूरा करती है।", subject: "She", verb: "completes" },
                    { id: "pos-m3", english: "My father drives to his office every weekday.", hindi: "मेरे पिता हर कार्यदिवस पर गाड़ी चलाकर अपने कार्यालय जाते हैं।", subject: "My father", verb: "drives" },
                    { id: "pos-m4", english: "We often visit our grandparents on weekends.", hindi: "हम अक्सर सप्ताहांत पर अपने दादा-दादी से मिलने जाते हैं।", subject: "We", verb: "visit" },
                    { id: "pos-m5", english: "The company releases new updates every month.", hindi: "कंपनी हर महीने नए अपडेट जारी करती है।", subject: "The company", verb: "releases" },
                    { id: "pos-m6", english: "He speaks three languages fluently.", hindi: "वह धाराप्रवाह तीन भाषाएं बोलता है।", subject: "He", verb: "speaks" },
                    { id: "pos-m7", english: "Water boils at one hundred degrees Celsius.", hindi: "पानी सौ डिग्री सेल्सियस पर उबलता है।", subject: "Water", verb: "boils" },
                    { id: "pos-m8", english: "She attends English grammar classes twice a week.", hindi: "वह सप्ताह में दो बार अंग्रेजी व्याकरण की कक्षाओं में शामिल होती है।", subject: "She", verb: "attends" },
                    { id: "pos-m9", english: "My colleagues always help me with complex projects.", hindi: "मेरे सहकर्मी जटिल परियोजनाओं में हमेशा मेरी मदद करते हैं।", subject: "My colleagues", verb: "help" },
                    { id: "pos-m10", english: "The train leaves the station at nine sharp.", hindi: "ट्रेन ठीक नौ बजे स्टेशन से निकलती है।", subject: "The train", verb: "leaves" }
                ],
                hard: [
                    { id: "pos-h1", english: "Our team lead reviews all code changes thoroughly before approving deployment.", hindi: "हमारे टीम लीडर परिनियोजन को मंजूरी देने से पहले सभी कोड परिवर्तनों की पूरी तरह से समीक्षा करते हैं।", subject: "Our team lead", verb: "reviews" },
                    { id: "pos-h2", english: "Whenever it rains heavily, the drainage system in our city overflows quickly.", hindi: "जब भी भारी बारिश होती है, हमारे शहर की जल निकासी व्यवस्था जल्दी से भर जाती है।", subject: "the drainage system", verb: "overflows" },
                    { id: "pos-h3", english: "Dr. Sharma manages the cardiology department while conducting clinical research.", hindi: "डॉ. शर्मा नैदानिक अनुसंधान करते हुए कार्डियोलॉजी विभाग का प्रबंधन करते हैं।", subject: "Dr. Sharma", verb: "manages" },
                    { id: "pos-h4", english: "Successful entrepreneurs continuously analyze market trends and adapt their strategies.", hindi: "सफल उद्यमी लगातार बाजार के रुझानों का विश्लेषण करते हैं और अपनी रणनीतियों को अपनाते हैं।", subject: "entrepreneurs", verb: "analyze / adapt" },
                    { id: "pos-h5", english: "The international airport handles over five hundred flights daily during peak season.", hindi: "पीक सीजन के दौरान यह अंतरराष्ट्रीय हवाई अड्डा रोजाना पांच सौ से अधिक उड़ानों को संभालता है।", subject: "airport", verb: "handles" },
                    { id: "pos-h6", english: "She maintains a strict daily routine that balances work with health.", hindi: "वह एक सख्त दैनिक दिनचर्या बनाए रखती है जो काम को स्वास्थ्य के साथ संतुलित करती है।", subject: "She", verb: "maintains / balances" },
                    { id: "pos-h7", english: "Ancient monuments attract thousands of tourists from around the world every year.", hindi: "प्राचीन स्मारक हर साल दुनिया भर से हजारों पर्यटकों को आकर्षित करते हैं।", subject: "Ancient monuments", verb: "attract" },
                    { id: "pos-h8", english: "Software developers fix bugs and optimize database performance regularly.", hindi: "सॉफ्टवेयर डेवलपर्स नियमित रूप से बग को ठीक करते हैं और डेटाबेस प्रदर्शन को अनुकूलित करते हैं।", subject: "Software developers", verb: "fix / optimize" },
                    { id: "pos-h9", english: "The financial advisor evaluates investment portfolios and provides sound guidance.", hindi: "वित्तीय सलाहकार निवेश पोर्टफोलियो का मूल्यांकन करता है और सही मार्गदर्शन प्रदान करता है।", subject: "financial advisor", verb: "evaluates / provides" },
                    { id: "pos-h10", english: "Government policies encourage renewable energy adoption across rural communities.", hindi: "सरकारी नीतियां ग्रामीण समुदायों में नवीकरणीय ऊर्जा अपनाने को प्रोत्साहित करती हैं।", subject: "Government policies", verb: "encourage" }
                ]
            }
        },

        // 6. Negative Sentences (नकारात्मक वाक्य) - STEP 3F
        negative: {
            title: "Negative Sentences",
            titleHindi: "नकारात्मक वाक्य",
            formulaPlural: "Subject (I/You/We/They) + do not (don't) + V1 + Object",
            formulaSingular: "Subject (He/She/It/Singular) + does not (doesn't) + V1 + Object",
            explanation: "Negative sentences deny an action, habit, or routine using 'do not / don't' or 'does not / doesn't'.",
            explanationHindi: "नकारात्मक वाक्य 'do not / don't' या 'does not / doesn't' का प्रयोग करके किसी आदत या कार्य को मना करते हैं।",
            
            // Critical Rule Highlight
            criticalRule: {
                ruleTitle: "CRITICAL RULE: Never use s/es/ies after does / doesn't!",
                ruleTitleHindi: "विशेष नियम: does / doesn't के बाद V1 में s/es/ies कभी न जोड़ें!",
                explanation: "Since 'does' already carries the singular grammatical marker, the main verb MUST revert to its base form (V1).",
                explanationHindi: "'does' में पहले से ही es जुड़ा होता है, इसलिए मुख्य क्रिया (V1) में फिर से s या es नहीं लगाया जाता है।",
                comparisonExamples: [
                    { wrong: "He doesn't plays cricket.", correct: "He doesn't play cricket.", note: "plays → play" },
                    { wrong: "She doesn't watches TV.", correct: "She doesn't watch TV.", note: "watches → watch" },
                    { wrong: "Rahul doesn't studies English.", correct: "Rahul doesn't study English.", note: "studies → study" }
                ]
            },

            // Groups Breakdown
            groups: {
                groupA: {
                    name: "Group A: Plural Subjects & I/You",
                    subjects: ["I", "You", "We", "They", "Plural Nouns"],
                    auxiliary: "do not / don't",
                    ruleHindi: "I, You, We, They के साथ do not (don't) + V1 आता है।",
                    examples: [
                        { english: "I do not play cricket.", hindi: "मैं क्रिकेट नहीं खेलता हूँ।", verb: "do not play" },
                        { english: "They don't watch TV.", hindi: "वे टीवी नहीं देखते हैं।", verb: "don't watch" }
                    ]
                },
                groupB: {
                    name: "Group B: Singular Subjects",
                    subjects: ["He", "She", "It", "Singular Name (Rahul/Priya)"],
                    auxiliary: "does not / doesn't",
                    ruleHindi: "He, She, It के साथ does not (doesn't) + V1 (बिना s/es) आता है।",
                    examples: [
                        { english: "He does not play cricket.", hindi: "वह क्रिकेट नहीं खेलता है।", verb: "does not play" },
                        { english: "She doesn't watch TV.", hindi: "वह टीवी नहीं देखती है।", verb: "doesn't watch" }
                    ]
                }
            },

            // Positive -> Negative Transformations
            transformations: [
                { positive: "He plays cricket.", negative: "He does not play cricket.", note: "plays → does not play" },
                { positive: "They play cricket.", negative: "They do not play cricket.", note: "play → do not play" },
                { positive: "She watches TV.", negative: "She does not watch TV.", note: "watches → does not watch" },
                { positive: "She studies English.", negative: "She does not study English.", note: "studies → does not study" }
            ],

            // 30 Negative Sentence Examples across Easy, Medium, Hard
            sentences: {
                easy: [
                    { id: "neg-e1", english: "I do not drink tea.", hindi: "मैं चाय नहीं पीता हूँ।", subject: "I", verb: "do not drink" },
                    { id: "neg-e2", english: "You do not know my brother.", hindi: "आप मेरे भाई को नहीं जानते हैं।", subject: "You", verb: "do not know" },
                    { id: "neg-e3", english: "We do not work on Sundays.", hindi: "हम रविवार को काम नहीं करते हैं।", subject: "We", verb: "do not work" },
                    { id: "neg-e4", english: "They don't watch television.", hindi: "वे टेलीविजन नहीं देखते हैं।", subject: "They", verb: "don't watch" },
                    { id: "neg-e5", english: "He does not play cricket.", hindi: "वह क्रिकेट नहीं खेलता है।", subject: "He", verb: "does not play" },
                    { id: "neg-e6", english: "She doesn't eat fast food.", hindi: "वह फास्ट फूड नहीं खाती है।", subject: "She", verb: "doesn't eat" },
                    { id: "neg-e7", english: "Rahul does not drive a car.", hindi: "राहुल कार नहीं चलाता है।", subject: "Rahul", verb: "does not drive" },
                    { id: "neg-e8", english: "It does not rain in winter here.", hindi: "यहाँ सर्दियों में बारिश नहीं होती है।", subject: "It", verb: "does not rain" },
                    { id: "neg-e9", english: "My cat does not like water.", hindi: "मेरी बिल्ली को पानी पसंद नहीं है।", subject: "My cat", verb: "does not like" },
                    { id: "neg-e10", english: "These children do not make noise.", hindi: "ये बच्चे शोर नहीं मचाते हैं।", subject: "These children", verb: "do not make" }
                ],
                medium: [
                    { id: "neg-m1", english: "I don't usually eat breakfast at the office.", hindi: "मैं आमतौर पर कार्यालय में नाश्ता नहीं करता हूँ।", subject: "I", verb: "don't eat" },
                    { id: "neg-m2", english: "She does not often use her phone during work hours.", hindi: "वह अक्सर काम के घंटों के दौरान अपने फोन का उपयोग नहीं करती है।", subject: "She", verb: "does not use" },
                    { id: "neg-m3", english: "My father doesn't stay late at the office on Fridays.", hindi: "मेरे पिता शुक्रवार को कार्यालय में देर तक नहीं ठहरते हैं।", subject: "My father", verb: "doesn't stay" },
                    { id: "neg-m4", english: "We do not receive many customer complaints this month.", hindi: "इस महीने हमें ग्राहकों की अधिक शिकायतें नहीं मिलती हैं।", subject: "We", verb: "do not receive" },
                    { id: "neg-m5", english: "The train does not stop at this small station.", hindi: "ट्रेन इस छोटे स्टेशन पर नहीं रुकती है।", subject: "The train", verb: "does not stop" },
                    { id: "neg-m6", english: "He doesn't speak French fluently yet.", hindi: "वह अभी तक धाराप्रवाह फ्रेंच नहीं बोलता है।", subject: "He", verb: "doesn't speak" },
                    { id: "neg-m7", english: "She does not buy expensive clothes online.", hindi: "वह ऑनलाइन महंगे कपड़े नहीं खरीदती है।", subject: "She", verb: "does not buy" },
                    { id: "neg-m8", english: "Our team doesn't lose hope during difficult matches.", hindi: "हमारी टीम कठिन मैचों के दौरान उम्मीद नहीं खोती है।", subject: "Our team", verb: "doesn't lose" },
                    { id: "neg-m9", english: "They do not live near the city center anymore.", hindi: "वे अब शहर के केंद्र के पास नहीं रहते हैं।", subject: "They", verb: "do not live" },
                    { id: "neg-m10", english: "The sun does not shine at night.", hindi: "सूर्य रात में नहीं चमकता है।", subject: "The sun", verb: "does not shine" }
                ],
                hard: [
                    { id: "neg-h1", english: "Our manager doesn't approve incomplete reports without checking supporting documents.", hindi: "हमारे प्रबंधक सहायक दस्तावेजों की जांच किए बिना अधूरी रिपोर्टों को मंजूरी नहीं देते हैं।", subject: "Our manager", verb: "doesn't approve" },
                    { id: "neg-h2", english: "He does not ignore constructive criticism from his senior colleagues.", hindi: "वह अपने वरिष्ठ सहकर्मियों की रचनात्मक आलोचना को नजरअंदाज नहीं करता है।", subject: "He", verb: "does not ignore" },
                    { id: "neg-h3", english: "The company doesn't hire new employees without a formal technical interview.", hindi: "कंपनी औपचारिक तकनीकी साक्षात्कार के बिना नए कर्मचारियों को काम पर नहीं रखती है।", subject: "The company", verb: "doesn't hire" },
                    { id: "neg-h4", english: "Software applications do not run smoothly on outdated operating systems.", hindi: "सॉफ्टवेयर एप्लिकेशन पुराने ऑपरेटिंग सिस्टम पर सुचारू रूप से नहीं चलते हैं।", subject: "Software applications", verb: "do not run" },
                    { id: "neg-h5", english: "She does not take major financial decisions without consulting her family.", hindi: "वह अपने परिवार से सलाह लिए बिना बड़े वित्तीय फैसले नहीं लेती है।", subject: "She", verb: "does not take" },
                    { id: "neg-h6", english: "Rural hospitals do not operate advanced surgical equipment without specialized doctors.", hindi: "ग्रामीण अस्पताल विशेष डॉक्टरों के बिना उन्नत सर्जिकल उपकरणों का संचालन नहीं करते हैं।", subject: "Rural hospitals", verb: "do not operate" },
                    { id: "neg-h7", english: "Students do not understand complex grammar concepts without practical examples.", hindi: "छात्र व्यावहारिक उदाहरणों के बिना जटिल व्याकरण अवधारणाओं को नहीं समझते हैं।", subject: "Students", verb: "do not understand" },
                    { id: "neg-h8", english: "The weather forecast doesn't guarantee clear skies during the monsoon season.", hindi: "मौसम का पूर्वानुमान मानसून के मौसम में साफ आसमान की गारंटी नहीं देता है।", subject: "The forecast", verb: "doesn't guarantee" },
                    { id: "neg-h9", english: "He doesn't reveal confidential project details to unauthorized persons.", hindi: "वह अनधिकृत व्यक्तियों को गोपनीय परियोजना विवरण का खुलासा नहीं करता है।", subject: "He", verb: "doesn't reveal" },
                    { id: "neg-h10", english: "Our organization does not compromise on ethical standards under any circumstances.", hindi: "हमारा संगठन किसी भी परिस्थिति में नैतिक मानकों से समझौता नहीं करता है।", subject: "Our organization", verb: "does not compromise" }
                ]
            }
        },

        // 7. Interrogative Sentences (प्रश्नवाचक वाक्य) - STEP 3G
        interrogative: {
            title: "Interrogative Sentences",
            titleHindi: "प्रश्नवाचक वाक्य (क्या ...?)",
            formulaPlural: "Do + Subject (I/You/We/They) + V1 + Object?",
            formulaSingular: "Does + Subject (He/She/It/Singular) + V1 + Object?",
            explanation: "Interrogative sentences ask questions about habits, routines, or general facts starting with 'Do' or 'Does'.",
            explanationHindi: "जिस वाक्य में किसी काम, आदत या स्थिति के बारे में प्रश्न पूछा जाता है, उसे प्रश्नवाचक वाक्य कहते हैं। Simple Present में ऐसे प्रश्न बनाने के लिए वाक्य की शुरुआत में **Do** या **Does** लगाया जाता है (हिंदी अर्थ: 'क्या...?')।",
            
            // Critical Rule Highlight
            criticalRule: {
                ruleTitle: "CRITICAL RULE: Never use s/es/ies after Does in questions!",
                ruleTitleHindi: "विशेष नियम: Does वाले प्रश्न में V1 के साथ s/es/ies कभी न जोड़ें!",
                explanation: "Since 'Does' already handles the singular grammatical marker at the beginning of the question, the main verb MUST revert to its base form (V1).",
                explanationHindi: "'Does' खुद ही एकवचन (singular subject) का काम संभाल लेता है। इसलिए 'Does' लगाने के बाद मुख्य verb पर s/es/ies नहीं लगाते, हमेशा केवल V1 का प्रयोग करते हैं।",
                comparisonExamples: [
                    { wrong: "Does he plays cricket?", correct: "Does he play cricket?", note: "plays → play" },
                    { wrong: "Does she watches TV?", correct: "Does she watch TV?", note: "watches → watch" },
                    { wrong: "Does Rahul studies English?", correct: "Does Rahul study English?", note: "studies → study" }
                ]
            },

            // Groups Breakdown
            groups: {
                groupA: {
                    name: "Group A: Plural Subjects & I/You",
                    subjects: ["I", "You", "We", "They", "Plural Nouns"],
                    auxiliary: "Do",
                    ruleHindi: "I, You, We, They के साथ प्रश्न बनाते समय शुरुआत में Do आता है: Do + Subject + V1 + Object?",
                    examples: [
                        { english: "Do I play cricket?", hindi: "क्या मैं क्रिकेट खेलता हूँ?", verb: "Do play" },
                        { english: "Do you read books?", hindi: "क्या तुम किताबें पढ़ते हो?", verb: "Do read" },
                        { english: "Do they work here?", hindi: "क्या वे यहाँ काम करते हैं?", verb: "Do work" }
                    ]
                },
                groupB: {
                    name: "Group B: Singular Subjects",
                    subjects: ["He", "She", "It", "Singular Name (Rahul/Priya)"],
                    auxiliary: "Does",
                    ruleHindi: "He, She, It, Singular Subject के साथ शुरुआत में Does आता है (मुख्य verb हमेशा V1 में रहता है): Does + Subject + V1 + Object?",
                    examples: [
                        { english: "Does he play cricket?", hindi: "क्या वह क्रिकेट खेलता है?", verb: "Does play" },
                        { english: "Does she watch TV?", hindi: "क्या वह टीवी देखती है?", verb: "Does watch" },
                        { english: "Does Rahul study English?", hindi: "क्या राहुल अंग्रेज़ी पढ़ता है?", verb: "Does study" }
                    ]
                }
            },

            // Positive -> Interrogative Transformations
            transformations: [
                { positive: "You play cricket.", interrogative: "Do you play cricket?", note: "Add Do at start" },
                { positive: "He plays cricket.", interrogative: "Does he play cricket?", note: "plays → Does ... play" },
                { positive: "She watches TV.", interrogative: "Does she watch TV?", note: "watches → Does ... watch" },
                { positive: "Rahul studies English.", interrogative: "Does Rahul study English?", note: "studies → Does ... study" }
            ],

            // Short Answer Foundation
            shortAnswers: [
                {
                    question: "Do you play cricket?",
                    questionHindi: "क्या तुम क्रिकेट खेलते हो?",
                    yesAnswer: "Yes, I do.",
                    noAnswer: "No, I don't.",
                    noteHindi: "Do से शुरू होने वाले प्रश्न का उत्तर: Yes, I do / No, I don't"
                },
                {
                    question: "Does he play cricket?",
                    questionHindi: "क्या वह क्रिकेट खेलता है?",
                    yesAnswer: "Yes, he does.",
                    noAnswer: "No, he doesn't.",
                    noteHindi: "Does से शुरू होने वाले प्रश्न का उत्तर: Yes, he does / No, he doesn't"
                }
            ],

            // 30 Interrogative Sentence Examples (10 Easy, 10 Medium, 10 Hard)
            sentences: {
                easy: [
                    { id: "int-e1", english: "Do you drink tea?", hindi: "क्या तुम चाय पीते हो?", subject: "you", verb: "Do drink" },
                    { id: "int-e2", english: "Does she cook food?", hindi: "क्या वह खाना बनाती है?", subject: "she", verb: "Does cook" },
                    { id: "int-e3", english: "Do they play cricket?", hindi: "क्या वे क्रिकेट खेलते हैं?", subject: "they", verb: "Do play" },
                    { id: "int-e4", english: "Does he know your address?", hindi: "क्या वह आपका पता जानता है?", subject: "he", verb: "Does know" },
                    { id: "int-e5", english: "Do we need a ticket?", hindi: "क्या हमें टिकट की आवश्यकता है?", subject: "we", verb: "Do need" },
                    { id: "int-e6", english: "Does Rahul drive a car?", hindi: "क्या राहुल कार चलाता है?", subject: "Rahul", verb: "Does drive" },
                    { id: "int-e7", english: "Do you like ice cream?", hindi: "क्या आपको आइसक्रीम पसंद है?", subject: "you", verb: "Do like" },
                    { id: "int-e8", english: "Does it rain heavily here?", hindi: "क्या यहाँ भारी बारिश होती है?", subject: "it", verb: "Does rain" },
                    { id: "int-e9", english: "Do they live in Delhi?", hindi: "क्या वे दिल्ली में रहते हैं?", subject: "they", verb: "Do live" },
                    { id: "int-e10", english: "Does your dog bark at night?", hindi: "क्या आपका कुत्ता रात में भौंकता है?", subject: "your dog", verb: "Does bark" }
                ],
                medium: [
                    { id: "int-m1", english: "Do you usually eat breakfast at home?", hindi: "क्या तुम आमतौर पर घर पर नाश्ता करते हो?", subject: "you", verb: "Do eat" },
                    { id: "int-m2", english: "Does she often use her phone during work?", hindi: "क्या वह अक्सर काम के दौरान अपना फोन इस्तेमाल करती है?", subject: "she", verb: "Does use" },
                    { id: "int-m3", english: "Does your father stay late at the office on Fridays?", hindi: "क्या आपके पिता शुक्रवार को कार्यालय में देर तक ठहरते हैं?", subject: "your father", verb: "Does stay" },
                    { id: "int-m4", english: "Do they receive customer feedback regularly?", hindi: "क्या वे नियमित रूप से ग्राहकों की प्रतिक्रिया प्राप्त करते हैं?", subject: "they", verb: "Do receive" },
                    { id: "int-m5", english: "Does the train stop at this station?", hindi: "क्या ट्रेन इस स्टेशन पर रुकती है?", subject: "the train", verb: "Does stop" },
                    { id: "int-m6", english: "Does he speak English fluently?", hindi: "क्या वह धाराप्रवाह अंग्रेजी बोलता है?", subject: "he", verb: "Does speak" },
                    { id: "int-m7", english: "Do you buy groceries from this store?", hindi: "क्या आप इस दुकान से किराना खरीदते हैं?", subject: "you", verb: "Do buy" },
                    { id: "int-m8", english: "Does the sun rise in the east?", hindi: "क्या सूर्य पूर्व में उगता है?", subject: "the sun", verb: "Does rise" },
                    { id: "int-m9", english: "Do we have enough time before the class starts?", hindi: "क्या कक्षा शुरू होने से पहले हमारे पास पर्याप्त समय है?", subject: "we", verb: "Do have" },
                    { id: "int-m10", english: "Does Priya manage the event team efficiently?", hindi: "क्या प्रिया इवेंट टीम का कुशलतापूर्वक प्रबंधन करती है?", subject: "Priya", verb: "Does manage" }
                ],
                hard: [
                    { id: "int-h1", english: "Does your manager review every report before approving the final submission?", hindi: "क्या आपका मैनेजर अंतिम सबमिशन को मंज़ूरी देने से पहले हर रिपोर्ट की समीक्षा करता है?", subject: "your manager", verb: "Does review" },
                    { id: "int-h2", english: "Do software engineers test their code thoroughly before deploying to production?", hindi: "क्या सॉफ्टवेयर इंजीनियर प्रोडक्शन में तैनात करने से पहले अपने कोड का पूरी तरह से परीक्षण करते हैं?", subject: "software engineers", verb: "Do test" },
                    { id: "int-h3", english: "Does the university conduct entrance examinations for international students every year?", hindi: "क्या विश्वविद्यालय हर साल अंतरराष्ट्रीय छात्रों के लिए प्रवेश परीक्षाएं आयोजित करता है?", subject: "the university", verb: "Does conduct" },
                    { id: "int-h4", english: "Do top management executives analyze quarterly financial performance metrics?", hindi: "क्या शीर्ष प्रबंधन अधिकारी तिमाही वित्तीय प्रदर्शन मेट्रिक्स का विश्लेषण करते हैं?", subject: "executives", verb: "Do analyze" },
                    { id: "int-h5", english: "Does she handle customer escalations without getting stressed?", hindi: "क्या वह बिना तनाव के ग्राहकों की शिकायतों को संभालती है?", subject: "she", verb: "Does handle" },
                    { id: "int-h6", english: "Do local authorities inspect building construction sites for safety compliance?", hindi: "क्या स्थानीय अधिकारी सुरक्षा अनुपालन के लिए भवन निर्माण स्थलों का निरीक्षण करते हैं?", subject: "local authorities", verb: "Do inspect" },
                    { id: "int-h7", english: "Does the weather forecasting department issue severe storm warnings in advance?", hindi: "क्या मौसम पूर्वानुमान विभाग पहले से ही गंभीर तूफान की चेतावनी जारी करता है?", subject: "the department", verb: "Does issue" },
                    { id: "int-h8", english: "Do senior doctors supervise junior interns during emergency night shifts?", hindi: "क्या वरिष्ठ डॉक्टर आपातकालीन रात की पाली के दौरान कनिष्ठ प्रशिक्षुओं की देखरेख करते हैं?", subject: "senior doctors", verb: "Do supervise" },
                    { id: "int-h9", english: "Does your company offer remote work options to full-time employees?", hindi: "क्या आपकी कंपनी पूर्णकालिक कर्मचारियों को रिमोट वर्क विकल्प प्रदान करती है?", subject: "your company", verb: "Does offer" },
                    { id: "int-h10", english: "Does the financial advisor recommend long-term investments for retirement planning?", hindi: "क्या वित्तीय सलाहकार सेवानिवृत्ति योजना के लिए दीर्घकालिक निवेश की सिफारिश करता है?", subject: "financial advisor", verb: "Does recommend" }
                ]
            }
        },

        // 8. WH Questions (प्रश्नवाचक - WH शब्द) - STEP 3H
        whQuestions: {
            title: "WH Questions",
            titleHindi: "WH प्रश्न (विशेष जानकारी के प्रश्न)",
            formulaPlural: "WH Word + Do + Subject (I/You/We/They) + V1 + Object?",
            formulaSingular: "WH Word + Does + Subject (He/She/It/Singular) + V1 + Object?",
            explanation: "WH Questions ask for specific information (such as place, time, reason, method, or thing) rather than simple Yes/No answers.",
            explanationHindi: "WH Question वह प्रश्न होता है जिसमें हम किसी खास जानकारी के बारे में पूछते हैं। Simple Present में WH शब्द (What, Where, When, Why...) के बाद **Do** या **Does** लगाया जाता है।",

            // WH Word Guide with explanations and examples
            wordGuide: [
                {
                    word: "What",
                    hindi: "क्या / कौन-सी चीज़",
                    meaningHindi: "किसी चीज़, वस्तु या कार्य की जानकारी के लिए।",
                    examples: [
                        { english: "What do you eat?", hindi: "तुम क्या खाते हो?" },
                        { english: "What does she cook?", hindi: "वह क्या बनाती है?" }
                    ]
                },
                {
                    word: "Where",
                    hindi: "कहाँ",
                    meaningHindi: "किसी स्थान या जगह की जानकारी के लिए।",
                    examples: [
                        { english: "Where do you work?", hindi: "तुम कहाँ काम करते हो?" },
                        { english: "Where does he live?", hindi: "वह कहाँ रहता है?" }
                    ]
                },
                {
                    word: "When",
                    hindi: "कब",
                    meaningHindi: "समय या अवसर की जानकारी के लिए।",
                    examples: [
                        { english: "When do you study?", hindi: "तुम कब पढ़ते हो?" },
                        { english: "When does she go to office?", hindi: "वह ऑफिस कब जाती है?" }
                    ]
                },
                {
                    word: "Why",
                    hindi: "क्यों",
                    meaningHindi: "कारण (reason) जानने के लिए।",
                    examples: [
                        { english: "Why do you learn English?", hindi: "तुम अंग्रेज़ी क्यों सीखते हो?" },
                        { english: "Why does he come late?", hindi: "वह देर से क्यों आता है?" }
                    ]
                },
                {
                    word: "Who",
                    hindi: "कौन / किसे",
                    meaningHindi: "व्यक्ति या कर्ता/कर्म जानने के लिए।",
                    examples: [
                        { english: "Who do you meet every day?", hindi: "तुम हर दिन किससे मिलते हो?" },
                        { english: "Who teaches you English?", hindi: "तुम्हें अंग्रेज़ी कौन पढ़ाता है? (Subject Question)" }
                    ]
                },
                {
                    word: "Which",
                    hindi: "कौन-सा / कौन-सी",
                    meaningHindi: "चयन या विकल्प (choice) जानने के लिए।",
                    examples: [
                        { english: "Which book do you read?", hindi: "तुम कौन-सी किताब पढ़ते हो?" },
                        { english: "Which subject does she teach?", hindi: "वह कौन-सा विषय पढ़ाती है?" }
                    ]
                },
                {
                    word: "Whose",
                    hindi: "किसका / किसकी",
                    meaningHindi: "स्वामित्व (ownership/possession) जानने के लिए।",
                    examples: [
                        { english: "Whose phone do you use?", hindi: "तुम किसका फोन इस्तेमाल करते हो?" },
                        { english: "Whose car does Rahul drive?", hindi: "राहुल किसकी कार चलाता है?" }
                    ]
                },
                {
                    word: "How",
                    hindi: "कैसे",
                    meaningHindi: "तरीका (method) या स्थिति जानने के लिए।",
                    examples: [
                        { english: "How do you learn English?", hindi: "तुम अंग्रेज़ी कैसे सीखते हो?" },
                        { english: "How does she travel to work?", hindi: "वह काम पर कैसे जाती है?" }
                    ]
                }
            ],

            // Special Note: Who as Subject Introduction
            whoAsSubjectNote: {
                title: "Who as Subject — Basic Introduction",
                titleHindi: "Who (कर्ता) के रूप में — प्राथमिक परिचय",
                explanation: "When 'Who' asks about the person performing the action (Subject), it directly takes the main verb without Do/Does.",
                explanationHindi: "जब 'Who' खुद काम करने वाले व्यक्ति (Subject) के बारे में पूछता है, तो Do/Does नहीं लगता, सीधे V1(s/es) आता है।",
                examples: [
                    { objectWh: "Who do you meet?", objectWhHindi: "तुम किससे मिलते हो? (Who = Object)", subjectWh: "Who teaches you?", subjectWhHindi: "तुम्हें कौन पढ़ाता है? (Who = Subject)" }
                ]
            },

            // Critical Rule Highlight
            criticalRule: {
                ruleTitle: "CRITICAL RULE: Memory Rule — Does आया → Main Verb V1 में आया!",
                ruleTitleHindi: "विशेष नियम: Does आया → Main Verb हमेशा V1 में आया!",
                explanation: "Positive sentences with He/She/It take s/es on the verb, but in WH Questions with Does, the main verb MUST revert to V1.",
                explanationHindi: "Positive वाक्य में He/She/It के साथ verb में s/es आता है, लेकिन WH Question में Does आते ही main verb वापस V1 में रहता है।",
                comparisonExamples: [
                    { wrong: "Why does he studies English?", correct: "Why does he study English?", note: "studies → study" },
                    { wrong: "Where does she works?", correct: "Where does she work?", note: "works → work" },
                    { wrong: "When does Rahul goes to office?", correct: "When does Rahul go to office?", note: "goes → go" }
                ]
            },

            // Positive -> Interrogative -> WH Transformations
            transformations: [
                {
                    positive: "You eat rice.",
                    interrogative: "Do you eat rice?",
                    wh: "What do you eat?",
                    note: "Replaces 'rice' with 'What'"
                },
                {
                    positive: "He works in Delhi.",
                    interrogative: "Does he work in Delhi?",
                    wh: "Where does he work?",
                    note: "Replaces 'in Delhi' with 'Where'"
                },
                {
                    positive: "She goes to school at 8 AM.",
                    interrogative: "Does she go to school at 8 AM?",
                    wh: "When does she go to school?",
                    note: "Replaces 'at 8 AM' with 'When'"
                },
                {
                    positive: "Rahul studies English to improve his career.",
                    interrogative: "Does Rahul study English to improve his career?",
                    wh: "Why does Rahul study English?",
                    note: "Replaces reason with 'Why'"
                }
            ],

            // 30 WH Questions across Easy, Medium, Hard
            sentences: {
                easy: [
                    { id: "wh-e1", english: "What do you eat?", hindi: "तुम क्या खाते हो?", whWord: "What", aux: "do", subject: "you", verb: "eat" },
                    { id: "wh-e2", english: "Where do you live?", hindi: "तुम कहाँ रहते हो?", whWord: "Where", aux: "do", subject: "you", verb: "live" },
                    { id: "wh-e3", english: "When do you sleep?", hindi: "तुम कब सोते हो?", whWord: "When", aux: "do", subject: "you", verb: "sleep" },
                    { id: "wh-e4", english: "Why does he laugh?", hindi: "वह क्यों हँसता है?", whWord: "Why", aux: "does", subject: "he", verb: "laugh" },
                    { id: "wh-e5", english: "What does she cook?", hindi: "वह क्या बनाती है?", whWord: "What", aux: "does", subject: "she", verb: "cook" },
                    { id: "wh-e6", english: "Where does he work?", hindi: "वह कहाँ काम करता है?", whWord: "Where", aux: "does", subject: "he", verb: "work" },
                    { id: "wh-e7", english: "When does the bus arrive?", hindi: "बस कब आती है?", whWord: "When", aux: "does", subject: "the bus", verb: "arrive" },
                    { id: "wh-e8", english: "Why do they play cricket?", hindi: "वे क्रिकेट क्यों खेलते हैं?", whWord: "Why", aux: "do", subject: "they", verb: "play" },
                    { id: "wh-e9", english: "How do you start this machine?", hindi: "तुम यह मशीन कैसे शुरू करते हो?", whWord: "How", aux: "do", subject: "you", verb: "start" },
                    { id: "wh-e10", english: "Which movie does she like?", hindi: "वह कौन-सी फिल्म पसंद करती है?", whWord: "Which", aux: "does", subject: "she", verb: "like" }
                ],
                medium: [
                    { id: "wh-m1", english: "Where do you usually have lunch?", hindi: "तुम आमतौर पर दोपहर का खाना कहाँ खाते हो?", whWord: "Where", aux: "do", subject: "you", verb: "have" },
                    { id: "wh-m2", english: "Why does she often arrive late?", hindi: "वह अक्सर देर से क्यों पहुँचती है?", whWord: "Why", aux: "does", subject: "she", verb: "arrive" },
                    { id: "wh-m3", english: "When do you usually practice English?", hindi: "तुम आमतौर पर अंग्रेज़ी का अभ्यास कब करते हो?", whWord: "When", aux: "do", subject: "you", verb: "practice" },
                    { id: "wh-m4", english: "What does your father do for a living?", hindi: "आपके पिता जीविका के लिए क्या काम करते हैं?", whWord: "What", aux: "does", subject: "your father", verb: "do" },
                    { id: "wh-m5", english: "How do they travel to their hometown?", hindi: "वे अपने गृहनगर कैसे यात्रा करते हैं?", whWord: "How", aux: "do", subject: "they", verb: "travel" },
                    { id: "wh-m6", english: "Which subject does Priya teach at school?", hindi: "प्रिया स्कूल में कौन-सा विषय पढ़ाती है?", whWord: "Which", aux: "does", subject: "Priya", verb: "teach" },
                    { id: "wh-m7", english: "Whose laptop do you borrow for work?", hindi: "आप काम के लिए किसका लैपटॉप उधार लेते हैं?", whWord: "Whose", aux: "do", subject: "you", verb: "borrow" },
                    { id: "wh-m8", english: "Why do we need to follow security rules?", hindi: "हमें सुरक्षा नियमों का पालन करने की आवश्यकता क्यों है?", whWord: "Why", aux: "do", subject: "we", verb: "need" },
                    { id: "wh-m9", english: "When does your office open in the morning?", hindi: "आपका कार्यालय सुबह कब खुलता है?", whWord: "When", aux: "does", subject: "your office", verb: "open" },
                    { id: "wh-m10", english: "Where does the doctor conduct medical checkups?", hindi: "डॉक्टर मेडिकल जांच कहाँ करते हैं?", whWord: "Where", aux: "does", subject: "the doctor", verb: "conduct" }
                ],
                hard: [
                    { id: "wh-h1", english: "Why does your manager review every report before the final meeting?", hindi: "आपका मैनेजर अंतिम मीटिंग से पहले हर रिपोर्ट की समीक्षा क्यों करता है?", whWord: "Why", aux: "does", subject: "your manager", verb: "review" },
                    { id: "wh-h2", english: "How does your team handle urgent customer requests during working hours?", hindi: "आपकी टीम काम के समय जरूरी ग्राहक अनुरोधों को कैसे संभालती है?", whWord: "How", aux: "does", subject: "your team", verb: "handle" },
                    { id: "wh-h3", english: "What procedures do software engineers follow during emergency server updates?", hindi: "आपातकालीन सर्वर अपडेट के दौरान सॉफ्टवेयर इंजीनियर कौन-सी प्रक्रियाओं का पालन करते हैं?", whWord: "What", aux: "do", subject: "engineers", verb: "follow" },
                    { id: "wh-h4", english: "Where does the organization store confidential client records securely?", hindi: "संगठन गोपनीय ग्राहक रिकॉर्ड सुरक्षित रूप से कहाँ संग्रहीत करता है?", whWord: "Where", aux: "does", subject: "organization", verb: "store" },
                    { id: "wh-h5", english: "When do international flight operators publish updated seasonal schedules?", hindi: "अंतरराष्ट्रीय उड़ान संचालक अद्यतन मौसमी समय सारिणी कब प्रकाशित करते हैं?", whWord: "When", aux: "do", subject: "operators", verb: "publish" },
                    { id: "wh-h6", english: "Why does the financial department audit expense receipts every quarter?", hindi: "वित्त विभाग हर तिमाही में खर्च की रसीदों का ऑडिट क्यों करता है?", whWord: "Why", aux: "does", subject: "department", verb: "audit" },
                    { id: "wh-h7", english: "Which communication channels do senior executives prefer for urgent updates?", hindi: "वरिष्ठ कार्यकारी अधिकारी तत्काल अपडेट के लिए कौन-से संचार चैनलों को प्राथमिकता देते हैं?", whWord: "Which", aux: "do", subject: "executives", verb: "prefer" },
                    { id: "wh-h8", english: "How does the research team analyze market feedback from diverse demographics?", hindi: "अनुसंधान टीम विभिन्न जनसांख्यिकी से बाजार प्रतिक्रिया का विश्लेषण कैसे करती है?", whWord: "How", aux: "does", subject: "research team", verb: "analyze" },
                    { id: "wh-h9", english: "Whose authorization does the developer require before releasing code changes?", hindi: "कोड परिवर्तनों को जारी करने से पहले डेवलपर को किसके प्राधिकरण की आवश्यकता होती है?", whWord: "Whose", aux: "does", subject: "developer", verb: "require" },
                    { id: "wh-h10", english: "What strategies does the marketing department deploy during festive promotional campaigns?", hindi: "त्योहारों के प्रचार अभियानों के दौरान विपणन विभाग कौन-सी रणनीतियाँ तैनात करता है?", whWord: "What", aux: "does", subject: "department", verb: "deploy" }
                ]
            }
        },

        // 9. Example Sentences Collection (Categorized by difficulty)
        examples: [
            { id: "ex-easy-1", level: "easy", english: "I read books every day.", hindi: "मैं रोज़ पुस्तकें पढ़ता हूँ।", note: "Basic daily habit using V1 'read'." },
            { id: "ex-easy-2", level: "easy", english: "She drinks milk in the morning.", hindi: "वह सुबह दूध पीती है।", note: "Singular subject 'She' uses V1+s 'drinks'." },
            { id: "ex-med-1", level: "medium", english: "They do not attend the meeting on Saturdays.", hindi: "वे शनिवार को बैठक में शामिल नहीं होते हैं।", note: "Plural negative with 'do not'." },
            { id: "ex-med-2", level: "medium", english: "Does your brother work at the hospital?", hindi: "क्या आपका भाई अस्पताल में काम करता है?", note: "Interrogative question with singular subject 'your brother'." },
            { id: "ex-hard-1", level: "hard", english: "The Earth rotates on its axis while revolving around the Sun.", hindi: "पृथ्वी सूर्य की परिक्रमा करते हुए अपनी धुरी पर घूमती है।", note: "Universal scientific facts expressed in Simple Present." }
        ],

        // 9. Common Mistakes (सामान्य गलतियां) - STEP 3I
        commonMistakes: {
            title: "Common Mistakes",
            titleHindi: "सामान्य गलतियाँ और उनके सुधार",
            introduction: "Simple Present Tense is easy to learn, but beginners often make simple mistakes with subject-verb agreement, Do/Does usage, and verb forms.",
            introductionHindi: "Simple Present में कुछ गलतियाँ बहुत सामान्य होती हैं। खासकर He, She, It के साथ verb, Do/Does और Negative/Question sentences बनाते समय। नीचे हम गलत और सही वाक्य को साथ देखकर समझेंगे कि गलती क्यों होती है और उसे कैसे ठीक करना है।",
            
            mistakes: [
                {
                    id: "cm-1",
                    title: "He/She/It + V1 Without s/es/ies",
                    titleHindi: "एकवचन कर्ता के साथ s/es/ies न लगाना",
                    wrong: "He play cricket.",
                    correct: "He plays cricket.",
                    correctHindi: "वह क्रिकेट खेलता है।",
                    explanation: "In Positive sentences, He, She, It and Singular Subjects MUST take s/es/ies with V1.",
                    explanationHindi: "He, She, It और Singular Subject के साथ Simple Present के Positive sentence में main verb में सामान्यतः s/es/ies लगता है।",
                    rule: "He / She / It / Singular Subject + V1(s/es/ies)",
                    examples: [
                        { wrong: "She work in an office.", correct: "She works in an office.", note: "work → works" },
                        { wrong: "Rahul study English.", correct: "Rahul studies English.", note: "study → studies" }
                    ]
                },
                {
                    id: "cm-2",
                    title: "Adding s/es/ies After Does in Questions",
                    titleHindi: "Does वाले प्रश्नों में verb पर s/es/ies लगाना",
                    wrong: "Does he plays cricket?",
                    correct: "Does he play cricket?",
                    correctHindi: "क्या वह क्रिकेट खेलता है?",
                    explanation: "When Does is used in questions, the main verb MUST revert to base form V1.",
                    explanationHindi: "जब Does आता है, तो main verb हमेशा V1 में रहता है। Does खुद singular work कर रहा है।",
                    rule: "Does + Subject + V1 (Memory Rule: Does आया → Main Verb V1 में आया!)",
                    examples: [
                        { wrong: "Does she watches TV?", correct: "Does she watch TV?", note: "watches → watch" },
                        { wrong: "Why does Rahul studies English?", correct: "Why does Rahul study English?", note: "studies → study" }
                    ]
                },
                {
                    id: "cm-3",
                    title: "Adding s/es/ies After Doesn't in Negative Sentences",
                    titleHindi: "Doesn't के बाद verb पर s/es/ies लगाना",
                    wrong: "He doesn't plays cricket.",
                    correct: "He doesn't play cricket.",
                    correctHindi: "वह क्रिकेट नहीं खेलता है।",
                    explanation: "In negative sentences with doesn't, the main verb MUST be in base form V1.",
                    explanationHindi: "Doesn't के बाद भी main verb हमेशा V1 में ही रहता है, s/es कभी नहीं लगता।",
                    rule: "Subject + doesn't + V1",
                    examples: [
                        { wrong: "She doesn't watches TV.", correct: "She doesn't watch TV.", note: "watches → watch" },
                        { wrong: "Rahul doesn't studies English.", correct: "Rahul doesn't study English.", note: "studies → study" }
                    ]
                },
                {
                    id: "cm-4",
                    title: "Using Do With He/She/It",
                    titleHindi: "He/She/It के साथ Do का गलत प्रयोग",
                    wrong: "Do he play cricket?",
                    correct: "Does he play cricket?",
                    correctHindi: "क्या वह क्रिकेट खेलता है?",
                    explanation: "Use Does (not Do) for questions with He, She, It, or Singular Subjects.",
                    explanationHindi: "He, She, It और Singular Subject के साथ question या negative बनाने में Does / Doesn't का प्रयोग करते हैं, Do का नहीं।",
                    rule: "Does + He / She / It / Singular + V1...?",
                    examples: [
                        { wrong: "Do she work here?", correct: "Does she work here?", note: "Do → Does" },
                        { wrong: "Do Rahul drive a car?", correct: "Does Rahul drive a car?", note: "Do → Does" }
                    ]
                },
                {
                    id: "cm-5",
                    title: "Using Does With I/You/We/They",
                    titleHindi: "I/You/We/They के साथ Does का गलत प्रयोग",
                    wrong: "Does you play cricket?",
                    correct: "Do you play cricket?",
                    correctHindi: "क्या तुम क्रिकेट खेलते हो?",
                    explanation: "Use Do (not Does) for questions with I, You, We, They, or Plural Subjects.",
                    explanationHindi: "I, You, We, They और Plural Subjects के साथ हमेशा Do / Don't का प्रयोग करते हैं।",
                    rule: "Do + I / You / We / They + V1...?",
                    examples: [
                        { wrong: "Does they work here?", correct: "Do they work here?", note: "Does → Do" },
                        { wrong: "Does we need a ticket?", correct: "Do we need a ticket?", note: "Does → Do" }
                    ]
                },
                {
                    id: "cm-6",
                    title: "Incorrect Negative Structure (Missing Do/Does)",
                    titleHindi: "नकारात्मक वाक्य में Do/Does छोड़ देना",
                    wrong: "He not play cricket.",
                    correct: "He does not play cricket.",
                    correctHindi: "वह क्रिकेट नहीं खेलता है।",
                    explanation: "Simple Present negative sentences require do not / does not. Just using 'not' is grammatically incomplete.",
                    explanationHindi: "Simple Present के Negative sentence में केवल 'not' लगाने से sentence पूरा नहीं बनता। Do not या Does not लगाना अनिवार्य है।",
                    rule: "Subject + do not / does not + V1 + Object",
                    examples: [
                        { wrong: "They not work here.", correct: "They do not work here.", note: "not work → do not work" },
                        { wrong: "She not cook food.", correct: "She does not cook food.", note: "not cook → does not cook" }
                    ]
                },
                {
                    id: "cm-7",
                    title: "Wrong Verb Form With Do",
                    titleHindi: "Do के साथ s/es वाली मुख्य क्रिया लगाना",
                    wrong: "Do you plays cricket?",
                    correct: "Do you play cricket?",
                    correctHindi: "क्या तुम क्रिकेट खेलते हो?",
                    explanation: "Main verb after Do MUST be in base V1 form without any s/es suffix.",
                    explanationHindi: "Do के बाद भी main verb हमेशा मूल रूप V1 में ही रहता है।",
                    rule: "Do + Subject + V1",
                    examples: [
                        { wrong: "Do they watches TV?", correct: "Do they watch TV?", note: "watches → watch" },
                        { wrong: "Do we works on Sundays?", correct: "Do we work on Sundays?", note: "works → work" }
                    ]
                },
                {
                    id: "cm-8",
                    title: "Wrong Interrogative Word Order",
                    titleHindi: "प्रश्नवाचक वाक्य में शब्दों का गलत क्रम",
                    wrong: "You do play cricket?",
                    correct: "Do you play cricket?",
                    correctHindi: "क्या तुम क्रिकेट खेलते हो?",
                    explanation: "In Simple Present questions, place Do/Does before the Subject, and WH words at the very beginning.",
                    explanationHindi: "Question बनाते समय Do/Does को Subject से पहले रखते हैं। WH Question में WH word सबसे पहले आता है।",
                    rule: "Do/Does + Subject + V1 ...? | WH Word + Do/Does + Subject + V1 ...?",
                    examples: [
                        { wrong: "He does work where?", correct: "Where does he work?", note: "Word order corrected" },
                        { wrong: "She goes when to office?", correct: "When does she go to office?", note: "Word order corrected" }
                    ]
                },
                {
                    id: "cm-9",
                    title: "Incorrect s/es/ies Spelling Rules",
                    titleHindi: "s/es/ies की स्पेलिंग में गलती",
                    wrong: "He go to school.",
                    correct: "He goes to school.",
                    correctHindi: "वह स्कूल जाता है।",
                    explanation: "Verbs ending in -o, -ch, -sh, -ss, -x take -es. Verbs ending in consonant+y change y to -ies.",
                    explanationHindi: "go का goes, watch का watches, और study का studies बनता है। केवल s जोड़ना गलत होगा।",
                    rule: "o/ch/sh/ss/x → +es | consonant + y → -ies",
                    examples: [
                        { wrong: "She watch TV.", correct: "She watches TV.", note: "watch → watches" },
                        { wrong: "Rahul study English.", correct: "Rahul studies English.", note: "study → studies" }
                    ]
                },
                {
                    id: "cm-10",
                    title: "Confusing Singular and Plural Subjects",
                    titleHindi: "एकवचन और बहुवचन कर्ता में भ्रम होना",
                    wrong: "Rahul and Amit studies English.",
                    correct: "Rahul and Amit study English.",
                    correctHindi: "राहुल और अमित अंग्रेज़ी पढ़ते हैं।",
                    explanation: "Two names joined by 'and' form a Plural Subject (They), so use base V1 without s/es.",
                    explanationHindi: "जब दो नाम 'and' से जुड़ते हैं, तो कर्ता बहुवचन (Plural) बन जाता है, इसलिए verb में s/es नहीं लगेगा।",
                    rule: "Singular (Rahul) → studies | Plural (Rahul and Amit) → study",
                    examples: [
                        { wrong: "My friends speaks English.", correct: "My friends speak English.", note: "friends (plural) → speak" },
                        { wrong: "My brother speak English.", correct: "My brother speaks English.", note: "brother (singular) → speaks" }
                    ]
                },
                {
                    id: "cm-11",
                    title: "Using Continuous Tense Unnecessarily for Habits",
                    titleHindi: "आदत बताने के लिए Continuous tense का गलत प्रयोग",
                    wrong: "I am going to office every day.",
                    correct: "I go to the office every day.",
                    correctHindi: "मैं हर दिन ऑफिस जाता हूँ।",
                    explanation: "Use Simple Present (not Present Continuous) to describe daily habits or routines.",
                    explanationHindi: "अगर हम किसी नियमित आदत या रोज़ होने वाले काम की बात कर रहे हैं, तो Simple Present (V1) का प्रयोग करते हैं।",
                    rule: "Habits/Routines → Simple Present (V1)",
                    examples: [
                        { wrong: "She is drinking tea every morning.", correct: "She drinks tea every morning.", note: "Habit → drinks" },
                        { wrong: "They are playing football on Sundays.", correct: "They play football on Sundays.", note: "Routine → play" }
                    ]
                },
                {
                    id: "cm-12",
                    title: "Incorrect Use of Have / Has",
                    titleHindi: "Have और Has का गलत प्रयोग",
                    wrong: "He have a car.",
                    correct: "He has a car.",
                    correctHindi: "उसके पास एक कार है।",
                    explanation: "In Positive Simple Present, I/You/We/They take 'have', while He/She/It takes 'has'.",
                    explanationHindi: "Positive sentence में He/She/It/Singular के साथ 'has' आता है, 'have' नहीं।",
                    rule: "I/You/We/They → have | He/She/It → has",
                    examples: [
                        { wrong: "She have two brothers.", correct: "She has two brothers.", note: "She → has" },
                        { wrong: "They has a big house.", correct: "They have a big house.", note: "They → have" }
                    ]
                },
                {
                    id: "cm-13",
                    title: "Incorrect Do/Does With Have (Does he has...?)",
                    titleHindi: "Does / Doesn't के साथ Has का गलत प्रयोग",
                    wrong: "Does he has a car?",
                    correct: "Does he have a car?",
                    correctHindi: "क्या उसके पास कार है?",
                    explanation: "After Does or Doesn't, 'has' MUST revert to base form V1 which is 'have'.",
                    explanationHindi: "Positive sentence में 'has' आता है, लेकिन Does या Doesn't आते ही main verb वापस V1 यानी 'have' हो जाता है।",
                    rule: "Does / Doesn't + have (NEVER Does + has)",
                    examples: [
                        { wrong: "He doesn't has a car.", correct: "He doesn't have a car.", note: "doesn't has → doesn't have" },
                        { wrong: "Does she has time?", correct: "Does she have time?", note: "Does has → Does have" }
                    ]
                },
                {
                    id: "cm-14",
                    title: "Hindi-to-English Direct Word-by-Word Translation",
                    titleHindi: "हिंदी से अंग्रेजी का सीधा शब्द-दर-शब्द अनुवाद",
                    wrong: "He every day office go.",
                    correct: "He goes to the office every day.",
                    correctHindi: "वह रोज़ ऑफिस जाता है।",
                    explanation: "English sentence order is Subject + Verb + Object, unlike Hindi Subject + Object + Verb order.",
                    explanationHindi: "English वाक्य का ढांचा Subject + Verb + Object होता है। हिंदी के क्रम (Subject + Object + Verb) में सीधे अनुवाद न करें।",
                    rule: "English Structure: Subject + Verb + Object",
                    examples: [
                        { wrong: "I tea drink in morning.", correct: "I drink tea in the morning.", note: "Subject + Verb + Object" },
                        { wrong: "She English speaks well.", correct: "She speaks English well.", note: "Subject + Verb + Object" }
                    ]
                },
                {
                    id: "cm-15",
                    title: "Forgetting the Auxiliary in Questions",
                    titleHindi: "प्रश्नवाचक वाक्य में Do/Does भूल जाना",
                    wrong: "You like tea?",
                    correct: "Do you like tea?",
                    correctHindi: "क्या तुम्हें चाय पसंद है?",
                    explanation: "Standard Simple Present Yes/No questions must begin with auxiliary Do or Does.",
                    explanationHindi: "Simple Present में सामान्य Yes/No question बनाते समय वाक्य के शुरू में Do या Does लगाना आवश्यक है।",
                    rule: "Do / Does + Subject + V1 + Object?",
                    examples: [
                        { wrong: "She likes tea?", correct: "Does she like tea?", note: "Add Does at start" },
                        { wrong: "They live here?", correct: "Do they live here?", note: "Add Do at start" }
                    ]
                }
            ],

            // Concise Quick-Reference Memory Rules
            memoryRules: [
                {
                    title: "Subject + Verb Match",
                    titleHindi: "कर्ता और क्रिया का मेल",
                    ruleEn: "I / You / We / They → V1  |  He / She / It / Singular → V1 + s/es/ies",
                    ruleHi: "I/You/We/They के साथ V1, और He/She/It के साथ V1+s/es/ies आता है।"
                },
                {
                    title: "The Golden V1 Rule",
                    titleHindi: "गोल्डन V1 नियम (Do / Does)",
                    ruleEn: "Do + V1  |  Does + V1  |  Don't + V1  |  Doesn't + V1",
                    ruleHi: "Do, Does, Don't, Doesn't के बाद मुख्य verb हमेशा मूल रूप (V1) में रहता है।"
                },
                {
                    title: "The Does Memory Trigger",
                    titleHindi: "Does मेमोरी ट्रिक",
                    ruleEn: "Does आया → Main Verb V1 में आया!",
                    ruleHi: "Does आते ही main verb से s/es/ies हट जाता है।"
                },
                {
                    title: "Have vs Has Rule",
                    titleHindi: "Have / Has का नियम",
                    ruleEn: "Positive: He has a car. | Question: Does he have a car? | Negative: He doesn't have a car.",
                    ruleHi: "Positive में Has आता है, लेकिन Does/Doesn't वाले वाक्यों में वापस Have बन जाता है।"
                }
            ]
        },

        // 10. Summary (सारांश) - STEP 3J
        summary: {
            title: "Simple Present Tense Summary",
            titleHindi: "सामान्य वर्तमान काल — संक्षिप्त पुनरावृत्ति",
            introduction: "Simple Present Tense is used to talk about daily routines, habits, general truths, repeated actions, and permanent situations.",
            introductionHindi: "Simple Present Tense का प्रयोग हम रोज़ होने वाले काम, आदत, सामान्य सत्य, बार-बार होने वाले काम और स्थायी स्थिति के बारे में बात करने के लिए करते हैं। इस Summary में हम Simple Present के सभी महत्वपूर्ण नियमों को एक जगह जल्दी से revise करेंगे।",

            // 1. When Do We Use Simple Present? (5 Main Uses)
            usesRecap: [
                { title: "Daily Routine", titleHindi: "दैनिक दिनचर्या", english: "I go to the office every day.", hindi: "मैं हर दिन ऑफिस जाता हूँ।" },
                { title: "Habit", titleHindi: "आदत", english: "She drinks tea every morning.", hindi: "वह हर सुबह चाय पीती है।" },
                { title: "General Truth", titleHindi: "सामान्य सत्य", english: "The sun rises in the east.", hindi: "सूरज पूर्व दिशा में उगता है।" },
                { title: "Repeated Action", titleHindi: "बार-बार होने वाला काम", english: "He visits his parents every Sunday.", hindi: "वह हर रविवार अपने माता-पिता से मिलने जाता है।" },
                { title: "Permanent Situation", titleHindi: "स्थायी स्थिति", english: "Rahul lives in Delhi.", hindi: "राहुल दिल्ली में रहता है।" }
            ],

            // 2. Core Sentence Type Formulas & Examples
            sentenceTypes: [
                {
                    type: "positive",
                    title: "Positive / Affirmative (सकारात्मक)",
                    groupAFormula: "I / You / We / They + V1 + Object",
                    groupAExample: "I play cricket. / They work in an office.",
                    groupBFormula: "He / She / It / Singular + V1(s/es/ies) + Object",
                    groupBExample: "He plays cricket. / She watches TV. / Rahul studies English.",
                    keyRuleHindi: "He, She, It और Singular Subject के साथ Positive sentence में main verb में सामान्यतः s/es/ies लगता है।"
                },
                {
                    type: "negative",
                    title: "Negative (नकारात्मक)",
                    groupAFormula: "I / You / We / They + do not (don't) + V1 + Object",
                    groupAExample: "I do not play cricket. / They don't watch TV.",
                    groupBFormula: "He / She / It / Singular + does not (doesn't) + V1 + Object",
                    groupBExample: "He does not play cricket. / She doesn't watch TV.",
                    keyRuleHindi: "Do not / Does not के बाद main verb हमेशा मूल रूप (V1) में रहता है। (❌ doesn't plays → ✅ doesn't play)"
                },
                {
                    type: "interrogative",
                    title: "Interrogative / Yes-No Questions (प्रश्नवाचक)",
                    groupAFormula: "Do + I / You / We / They + V1 + Object?",
                    groupAExample: "Do you play cricket? / Do they work here?",
                    groupBFormula: "Does + He / She / It / Singular + V1 + Object?",
                    groupBExample: "Does he play cricket? / Does she watch TV?",
                    keyRuleHindi: "जब Does आता है, तो main verb वापस V1 में आ जाता है। (Does आया → Main Verb V1 में आया!)"
                },
                {
                    type: "wh",
                    title: "WH Questions (विशेष जानकारी प्रश्न)",
                    groupAFormula: "WH Word + Do + Subject (I/You/We/They) + V1 + Object?",
                    groupAExample: "Where do you work? / What do you eat?",
                    groupBFormula: "WH Word + Does + Subject (He/She/It/Singular) + V1 + Object?",
                    groupBExample: "Why does he study English? / When does she go to office?",
                    keyRuleHindi: "WH Words: What (क्या), Where (कहाँ), When (कब), Why (क्यों), Who (कौन), Which (कौन-सा), Whose (किसका), How (कैसे)।"
                }
            ],

            // 3. Do / Does Quick Rule
            doDoesQuickRule: {
                groupA: "I / You / We / They → Do / Don't",
                groupB: "He / She / It / Singular → Does / Doesn't",
                explanationHindi: "Do/Does का प्रयोग मुख्य रूप से Simple Present के Negative और Question sentences बनाने में होता है।"
            },

            // 4. Golden V1 Rule Card
            goldenV1Rule: {
                title: "The Golden V1 Rule",
                titleHindi: "गोल्डन V1 नियम",
                formula: "Do + V1  |  Does + V1  |  Don't + V1  |  Doesn't + V1",
                explanationHindi: "Do, Does, Don't या Doesn't के बाद main verb हमेशा V1 में रहता है।",
                comparison: [
                    { wrong: "Does he plays?", correct: "Does he play?" },
                    { wrong: "He doesn't plays.", correct: "He doesn't play." },
                    { wrong: "Do you plays?", correct: "Do you play?" }
                ]
            },

            // 5. s / es / ies Rule Revision
            sEsRuleRevision: {
                title: "s / es / ies Rule (Positive Sentences)",
                titleHindi: "s / es / ies लगाने का नियम (केवल Positive sentence)",
                ruleText: "He / She / It / Singular Subject → V1 + s/es/ies",
                examples: [
                    { base: "play", singular: "plays" },
                    { base: "watch", singular: "watches" },
                    { base: "go", singular: "goes" },
                    { base: "study", singular: "studies" }
                ]
            },

            // 6. Have / Has Rule Revision
            haveHasRule: {
                title: "Have / Has Rule",
                titleHindi: "Have और Has का विशेष नियम",
                positiveText: "I / You / We / They → have  |  He / She / It → has",
                positiveExample: "He has a car.",
                questionExample: "Does he have a car? (NEVER Does he has...?)",
                negativeExample: "He doesn't have a car. (NEVER He doesn't has...?)",
                explanationHindi: "Positive sentence में He/She/It के साथ has आता है, लेकिन Does/Doesn't वाले वाक्यों में वापस V1 यानी have बन जाता है।"
            },

            // 7. Subject + Verb Matrix Revision Table
            revisionMatrix: [
                { subject: "I", positive: "I work.", negative: "I don't work.", question: "Do I work?" },
                { subject: "You", positive: "You work.", negative: "You don't work.", question: "Do you work?" },
                { subject: "We", positive: "We work.", negative: "We don't work.", question: "Do we work?" },
                { subject: "They", positive: "They work.", negative: "They don't work.", question: "Do they work?" },
                { subject: "He", positive: "He works.", negative: "He doesn't work.", question: "Does he work?" },
                { subject: "She", positive: "She works.", negative: "She doesn't work.", question: "Does she work?" },
                { subject: "It", positive: "It works.", negative: "It doesn't work.", question: "Does it work?" },
                { subject: "Rahul", positive: "Rahul works.", negative: "Rahul doesn't work.", question: "Does Rahul work?" }
            ],

            // 8. 15 Final Revision Examples (5 Easy, 5 Medium, 5 Hard)
            finalExamples: {
                easy: [
                    { english: "I drink tea every morning.", hindi: "मैं हर सुबह चाय पीता हूँ।" },
                    { english: "She speaks English very well.", hindi: "वह बहुत अच्छी अंग्रेजी बोलती है।" },
                    { english: "They do not live in this city.", hindi: "वे इस शहर में नहीं रहते हैं।" },
                    { english: "Do you know my brother?", hindi: "क्या आप मेरे भाई को जानते हैं?" },
                    { english: "Where does he work?", hindi: "वह कहाँ काम करता है?" }
                ],
                medium: [
                    { english: "She checks her email before starting work.", hindi: "वह काम शुरू करने से पहले अपना ईमेल देखती है।" },
                    { english: "My father doesn't stay late at office on Fridays.", hindi: "मेरे पिता शुक्रवार को ऑफिस में देर तक नहीं ठहरते हैं।" },
                    { english: "Do they receive customer feedback regularly?", hindi: "क्या वे नियमित रूप से ग्राहकों की प्रतिक्रिया प्राप्त करते हैं?" },
                    { english: "When do you usually practice English speaking?", hindi: "आप आमतौर पर अंग्रेजी बोलने का अभ्यास कब करते हैं?" },
                    { english: "He doesn't have a car, but he drives a scooter.", hindi: "उसके पास कार नहीं है, लेकिन वह स्कूटर चलाता है।" }
                ],
                hard: [
                    { english: "Our manager checks the report before the team starts the meeting.", hindi: "हमारे मैनेजर टीम के मीटिंग शुरू करने से पहले रिपोर्ट देखते हैं।" },
                    { english: "Software developers regularly optimize database performance for better speed.", hindi: "सॉफ्टवेयर डेवलपर्स बेहतर गति के लिए नियमित रूप से डेटाबेस प्रदर्शन को अनुकूलित करते हैं।" },
                    { english: "Why does your company offer remote work options to full-time employees?", hindi: "आपकी कंपनी पूर्णकालिक कर्मचारियों को रिमोट वर्क विकल्प क्यों प्रदान करती है?" },
                    { english: "The weather forecast department doesn't guarantee clear skies during monsoon.", hindi: "मौसम पूर्वानुमान विभाग मानसून के दौरान साफ आसमान की गारंटी नहीं देता है।" },
                    { english: "How does the research team analyze market feedback from diverse demographics?", hindi: "अनुसंधान टीम विभिन्न जनसांख्यिकी से बाजार प्रतिक्रिया का विश्लेषण कैसे करती है?" }
                ]
            },

            // 9. Final Quick Revision Chart & Beginner Memory Message
            finalMemoryMessage: {
                title: "Simple Present याद रखने का आसान तरीका:",
                rules: [
                    "I / You / We / They → V1  |  He / She / It / Singular → V1 + s/es/ies",
                    "Do / Don't → V1  |  Does / Doesn't → V1",
                    "Does आया → Main Verb V1 में आया!",
                    "Positive → He plays. | Question → Does he play? | Negative → He doesn't play."
                ],
                encouragementHindi: "अभ्यास जारी रखें! Simple Present पर आपकी पकड़ मजबूत हो चुकी है।"
            }
        },

        // 11. Practice Exercises / Practice Sentences - STEP 3K FIX
        exercises: {
            title: "Simple Present Practice Sentences",
            titleHindi: "सामान्य वर्तमान काल — अभ्यास (120 Practice Sentences)",
            introduction: "Practice all 120 sentences across Positive, Negative, Interrogative, and WH Questions to master Simple Present Tense.",
            introductionHindi: "Simple Present Tense के 120 अभ्यास वाक्यों (सकारात्मक, नकारात्मक, प्रश्नवाचक एवं WH प्रश्न) के माध्यम से पूरा अभ्यास करें।",
            categories: []
        }
    }
};

// Initialize categories referencing existing sections
simplePresentLesson.sections.exercises.categories = [
    {
        id: "positive",
        title: "Positive Sentences Practice",
        titleHindi: "1. सकारात्मक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Positive Sentence",
        sentences: simplePresentLesson.sections.positive.sentences
    },
    {
        id: "negative",
        title: "Negative Sentences Practice",
        titleHindi: "2. नकारात्मक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Negative Sentence",
        sentences: simplePresentLesson.sections.negative.sentences
    },
    {
        id: "interrogative",
        title: "Interrogative Sentences Practice",
        titleHindi: "3. प्रश्नवाचक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Yes/No Question",
        sentences: simplePresentLesson.sections.interrogative.sentences
    },
    {
        id: "whQuestions",
        title: "WH Questions Practice",
        titleHindi: "4. WH प्रश्न अभ्यास (30 Sentences)",
        typeLabel: "WH Question",
        sentences: simplePresentLesson.sections.whQuestions.sentences
    }
];

/**
 * Get the complete Simple Present lesson object
 * @returns {object}
 */
export function getSimplePresentLesson() {
    return { ...simplePresentLesson };
}

/**
 * Get a specific section of Simple Present lesson data
 * @param {string} sectionName 
 * @returns {object|Array|null}
 */
export function getSimplePresentSection(sectionName) {
    if (!sectionName || !simplePresentLesson.sections) return null;
    return simplePresentLesson.sections[sectionName] || null;
}

/**
 * Get Simple Present example sentences filtered by difficulty level
 * @param {string} level - 'easy' | 'medium' | 'hard' | 'all'
 * @returns {Array<object>}
 */
export function getSimplePresentExamples(level = 'all') {
    const examples = simplePresentLesson.sections.examples || [];
    if (level === 'all') return [...examples];
    return examples.filter(ex => ex.level === level);
}

/**
 * Get Positive Sentences filtered by difficulty level
 * @param {string} level - 'easy' | 'medium' | 'hard' | 'all'
 * @returns {Array<object>}
 */
export function getSimplePresentPositiveSentences(level = 'all') {
    const sentences = simplePresentLesson.sections.positive?.sentences || {};
    if (level === 'all') {
        return [
            ...(sentences.easy || []),
            ...(sentences.medium || []),
            ...(sentences.hard || [])
        ];
    }
    return sentences[level] || [];
}

/**
 * Get Negative Sentences filtered by difficulty level
 * @param {string} level - 'easy' | 'medium' | 'hard' | 'all'
 * @returns {Array<object>}
 */
export function getSimplePresentNegativeSentences(level = 'all') {
    const sentences = simplePresentLesson.sections.negative?.sentences || {};
    if (level === 'all') {
        return [
            ...(sentences.easy || []),
            ...(sentences.medium || []),
            ...(sentences.hard || [])
        ];
    }
    return sentences[level] || [];
}

/**
 * Get Interrogative Sentences filtered by difficulty level
 * @param {string} level - 'easy' | 'medium' | 'hard' | 'all'
 * @returns {Array<object>}
 */
export function getSimplePresentInterrogativeSentences(level = 'all') {
    const sentences = simplePresentLesson.sections.interrogative?.sentences || {};
    if (level === 'all') {
        return [
            ...(sentences.easy || []),
            ...(sentences.medium || []),
            ...(sentences.hard || [])
        ];
    }
    return sentences[level] || [];
}

/**
 * Get WH Questions filtered by difficulty level
 * @param {string} level - 'easy' | 'medium' | 'hard' | 'all'
 * @returns {Array<object>}
 */
export function getSimplePresentWhQuestions(level = 'all') {
    const sentences = simplePresentLesson.sections.whQuestions?.sentences || {};
    if (level === 'all') {
        return [
            ...(sentences.easy || []),
            ...(sentences.medium || []),
            ...(sentences.hard || [])
        ];
    }
    return sentences[level] || [];
}

/**
 * Get Common Mistakes section
 * @returns {object}
 */
export function getSimplePresentCommonMistakes() {
    return simplePresentLesson.sections.commonMistakes || {};
}

/**
 * Get Summary section
 * @returns {object}
 */
export function getSimplePresentSummary() {
    return simplePresentLesson.sections.summary || {};
}

/**
 * Get Exercises section data filtered by category and level
 * @param {string} category - 'all' | 'positive' | 'negative' | 'interrogative' | 'whQuestions'
 * @param {string} level - 'easy' | 'medium' | 'hard' | 'all'
 * @returns {object|Array}
 */
export function getSimplePresentExercises(category = 'all', level = 'all') {
    const exercisesSection = simplePresentLesson.sections.exercises || {};
    if (category === 'all' && level === 'all') {
        return exercisesSection;
    }
    if (category === 'all') {
        let result = [];
        (exercisesSection.categories || []).forEach(cat => {
            result = result.concat(cat.sentences[level] || []);
        });
        return result;
    }
    const cat = (exercisesSection.categories || []).find(c => c.id === category);
    if (!cat) return [];
    if (level === 'all') {
        return [
            ...(cat.sentences.easy || []),
            ...(cat.sentences.medium || []),
            ...(cat.sentences.hard || [])
        ];
    }
    return cat.sentences[level] || [];
}





