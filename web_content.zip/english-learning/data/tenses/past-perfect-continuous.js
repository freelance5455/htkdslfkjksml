/**
 * Central Lesson Data for Past Perfect Continuous Tense (पूर्ण निरंतर भूतकाल)
 * Hindi Medium English Learning Curriculum.
 * ES6 Module export.
 */

const pastPerfectContinuousLesson = {
    id: "past-perfect-continuous",
    title: "Past Perfect Continuous",
    titleHindi: "पूर्ण निरंतर भूतकाल (Subject + had + been + V1+ing)",
    subtitle: "Actions that had been continuing for a duration before another past event or point",
    subtitleHindi: "ऐसे कार्य जो भूतकाल में किसी अन्य घटना या समय से पहले कुछ अवधि से लगातार जारी थे",

    sections: {
        // 1. Identification / पहचान और अवधारणा
        identification: {
            title: "Identification",
            titleHindi: "पहचान और अवधारणा (Identification Guide)",
            english: "Past Perfect Continuous Tense is used for an action/activity that had been continuing for a duration or since a starting point before another past reference event occurred.",
            hindi: "Past Perfect Continuous Tense का प्रयोग ऐसे कार्यों के लिए किया जाता है जो भूतकाल में किसी अन्य घटना या समय बिंदु से पहले कुछ समय से लगातार चल रहे थे।",
            
            hindiIdentityRule: "हिंदी वाक्यों के अंत में प्रायः 'से रहा था', 'से रही थी', 'से रहे थे' के साथ समय (Time/Duration) का उल्लेख होता है। (जैसे: 'दो घंटे से पढ़ रहा था', 'सुबह से काम कर रही थी')।",
            
            identificationPoints: [
                {
                    english: "Continuity + Past Timeline: Focuses on the ongoing duration of an action in the past before a past deadline or interrupting event.",
                    hindi: "निरंतरता + अतीत की समयरेखा: भूतकाल में किसी घटना से पहले कार्य के जारी रहने की अवधि पर बल देता है।"
                },
                {
                    english: "Auxiliary Structure: Always use 'had been' for ALL subjects (I, You, He, She, It, We, They, Singular, Plural).",
                    hindi: "सहायक संरचना: सभी कर्ताओं (I, You, He, She, It, We, They, एकवचन, बहुवचन) के साथ 'had been' का प्रयोग होता है।"
                },
                {
                    english: "Main Verb: Always use V1+ing (Present Participle / V4 form).",
                    hindi: "मुख्य क्रिया: हमेशा V1+ing (जैसे: studying, working, waiting) का प्रयोग होता है।"
                },
                {
                    english: "Time Indicators (Since / For): 'Since' indicates starting point, and 'For' indicates duration of time.",
                    hindi: "समय सूचक (Since / For): 'Since' शुरुआती समय बिंदु को और 'For' समयावधि (duration) को दर्शाता है।"
                }
            ],
            
            comparison: {
                title: "Concept Comparison: Past Continuous vs Past Perfect vs Past Perfect Continuous",
                pastContinuous: {
                    name: "Past Continuous (अपूर्ण भूतकाल)",
                    formula: "Subject + was/were + V1+ing",
                    concept: "Action ongoing at a past time without specific duration (रहा था)",
                    example: "I was studying when he called. (मैं पढ़ रहा था जब उसने फोन किया।)"
                },
                pastPerfect: {
                    name: "Past Perfect (पूर्ण भूतकाल)",
                    formula: "Subject + had + V3",
                    concept: "Action completed before another past event (चुका था)",
                    example: "I had finished studying before he called. (उसके फोन करने से पहले मैं पढ़ाई पूरी कर चुका था।)"
                },
                pastPerfectContinuous: {
                    name: "Past Perfect Continuous (पूर्ण निरंतर भूतकाल)",
                    formula: "Subject + had + been + V1+ing + time",
                    concept: "Action continuing for a duration before a past event (से रहा था)",
                    example: "I had been studying for two hours before he called. (उसके फोन करने से पहले मैं दो घंटे से पढ़ रहा था।)"
                }
            }
        },

        // 2. Uses & Scenarios / उपयोग और परिस्थितियाँ (Exactly 5 Major Uses)
        uses: {
            title: "Uses & Scenarios",
            titleHindi: "कब प्रयोग करें (5 मुख्य उपयोग)",
            intro: "Past Perfect Continuous Tense is used to show past ongoing duration, emphasize effort before past milestones, and explain past causes.",
            introHindi: "Past Perfect Continuous Tense का प्रयोग अतीत की जारी अवधि, प्रयासों और अतीत के कारणों को स्पष्ट करने के लिए किया जाता है।",
            list: [
                {
                    title: "1. Action Continued for a Duration Before Another Past Event",
                    titleHindi: "भूतकाल के किसी अन्य कार्य से पहले निश्चित अवधि तक जारी रहने वाला कार्य",
                    explanation: "Describes an ongoing action that started earlier in the past and continued up until another past action took place.",
                    explanationHindi: "अतीत के उस कार्य का वर्णन करता है जो पहले शुरू हुआ और किसी दूसरे अतीत के कार्य तक लगातार चलता रहा।",
                    whyUsed: "Emphasizes the duration of the ongoing activity prior to a past point.",
                    whyUsedHindi: "अतीत की घटना से पहले की जा रही गतिविधि की अवधि पर ध्यान केंद्रित करता है।",
                    examples: [
                        { english: "I had been studying for two hours before my friend called.", hindi: "मेरे दोस्त के फोन करने से पहले मैं दो घंटे से पढ़ रहा था।", note: "Studying started earlier and continued for 2 hrs" },
                        { english: "She had been working at the company for five years before she got promoted.", hindi: "पदोनत्ति मिलने से पहले वह कंपनी में पाँच साल से काम कर रही थी।", note: "Ongoing 5 years before promotion" },
                        { english: "They had been repairing the bridge for months before it opened.", hindi: "पुल खुलने से पहले वे महीनों से उसकी मरम्मत कर रहे थे।", note: "Duration before bridge opening" }
                    ]
                },
                {
                    title: "2. Showing a Starting Point with Since in Past Context",
                    titleHindi: "अतीत के संदर्भ में Since के साथ शुरुआती समय दर्शाना (Starting point)",
                    explanation: "Used with 'since morning', 'since 2018', 'since Monday' to specify when the past activity began.",
                    explanationHindi: "यह दर्शाने के लिए कि अतीत में कोई कार्य किस निश्चित समय बिंदु से जारी था।",
                    whyUsed: "Fixes the exact starting point of a past continuing action.",
                    whyUsedHindi: "अतीत की निरंतर गतिविधि के सटीक शुरुआती समय को तय करता है।",
                    examples: [
                        { english: "She had been working since morning before she took a break.", hindi: "ब्रेक लेने से पहले वह सुबह से काम कर रही थी।", note: "Starting point: since morning" },
                        { english: "He had been living in Delhi since 2015 before moving to Mumbai.", hindi: "मुंबई स्थानांतरित होने से पहले वह 2015 से दिल्ली में रह रहा था।", note: "Starting point: since 2015" },
                        { english: "They had been practicing since 7 AM before the match started.", hindi: "मैच शुरू होने से पहले वे सुबह 7 बजे से अभ्यास कर रहे थे।", note: "Starting point: since 7 AM" }
                    ]
                },
                {
                    title: "3. Showing Duration with For in Past Context",
                    titleHindi: "अतीत के संदर्भ में For के साथ समयावधि दर्शाना (Duration of time)",
                    explanation: "Used with 'for an hour', 'for three days', 'for a long time' to highlight total elapsed duration.",
                    explanationHindi: "अतीत में किसी कार्य के कुल चले समय (जैसे: 2 घंटे से, 3 दिन से) को दर्शाने के लिए।",
                    whyUsed: "Measures total period of ongoing past effort.",
                    whyUsedHindi: "अतीत के प्रयास की कुल अवधि को मापता है।",
                    examples: [
                        { english: "They had been waiting for an hour when the bus arrived.", hindi: "जब बस आई तब वे एक घंटे से इंतज़ार कर रहे थे।", note: "Duration: for an hour" },
                        { english: "I had been driving for three hours before stopping for fuel.", hindi: "ईंधन के लिए रुकने से पहले मैं तीन घंटे से गाड़ी चला रहा था।", note: "Duration: for three hours" },
                        { english: "We had been discussing the project for two weeks before approval.", hindi: "मंजूरी मिलने से पहले हम दो हफ्ते से प्रोजेक्ट पर चर्चा कर रहे थे।", note: "Duration: for two weeks" }
                    ]
                },
                {
                    title: "4. Ongoing Activity as Background Cause of a Past Situation",
                    titleHindi: "अतीत की स्थिति का कारण बनने वाली निरंतर गतिविधि (Cause of past state)",
                    explanation: "The continuous action in the past explains the cause of a past result (e.g. fatigue, wetness).",
                    explanationHindi: "अतीत का निरंतर कार्य किसी अतीत के परिणाम (जैसे: थकान, पसीना) का कारण बताता है।",
                    whyUsed: "Provides the continuous background reason for a past physical/emotional state.",
                    whyUsedHindi: "अतीत की शारीरिक/मानसिक स्थिति का निरंतर पृष्ठभूमि कारण बताता है।",
                    examples: [
                        { english: "He was tired because he had been working all night.", hindi: "वह थका हुआ था क्योंकि वह रात भर काम कर रहा था।", note: "Cause: had been working all night" },
                        { english: "The ground was wet because it had been raining for hours.", hindi: "ज़मीन गीली थी क्योंकि घंटों से बारिश हो रही थी।", note: "Cause: had been raining for hours" },
                        { english: "Her eyes were red because she had been crying.", hindi: "उसकी आँखें लाल थीं क्योंकि वह रो रही थी।", note: "Cause: had been crying" }
                    ]
                },
                {
                    title: "5. Emphasizing Ongoing Effort Before a Past Reference Point",
                    titleHindi: "अतीत के संदर्भ बिंदु से पहले निरंतर प्रयास पर बल देना (Emphasis on effort)",
                    explanation: "Used in narratives to show dedicated long-term effort preceding a past event.",
                    explanationHindi: "कहानी या विवरण में किसी घटना से पहले के लंबे निरंतर प्रयास पर बल देने के लिए।",
                    whyUsed: "Highlights perseverance and continuous past involvement.",
                    whyUsedHindi: "अतीत के निरंतर जुड़ाव और दृढ़ता को उजागर करता है।",
                    examples: [
                        { english: "We had been living there for five years before we finally bought our own house.", hindi: "अपना खुद का घर खरीदने से पहले हम वहाँ पाँच साल से रह रहे थे।", note: "Long-term ongoing living" },
                        { english: "The scientist had been researching the vaccine for a decade before discovering breakthrough.", hindi: "सफलता खोजने से पहले वैज्ञानिक एक दशक से टीके पर शोध कर रहे थे।", note: "Decade of continuous research" },
                        { english: "She had been training hard for months before winning the championship.", hindi: "चैंपियनशिप जीतने से पहले वह महीनों से कड़ी मेहनत कर रही थी।", note: "Months of continuous training" }
                    ]
                }
            ]
        },

        // 3. Sentence Structure & Formulas / वाक्य संरचना और सूत्र
        structure: {
            title: "Structure & Formulas",
            titleHindi: "वाक्य संरचना और सूत्र (Formulas)",
            intro: "Past Perfect Continuous formulas use HAD + BEEN + V1+ing for all subjects across Positive, Negative, Interrogative, and WH Questions.",
            introHindi: "Past Perfect Continuous में सभी कर्ताओं के साथ HAD + BEEN + V1+ing का प्रयोग किया जाता है।",
            formulas: {
                positive: {
                    name: "Positive Formula",
                    rule: "Subject + had + been + V1+ing + Object / Complement + (since/for + time)",
                    example: "She had been studying for three hours.",
                    breakdown: {
                        subject: "She",
                        aux: "had been",
                        verb: "studying (V1+ing)",
                        object: "for three hours"
                    }
                },
                negative: {
                    name: "Negative Formula",
                    rule: "Subject + had + not + been + V1+ing + Object + (since/for + time)",
                    example: "She had not (hadn't) been studying for three hours.",
                    breakdown: {
                        subject: "She",
                        aux: "had not been / hadn't been",
                        verb: "studying (V1+ing)",
                        object: "for three hours"
                    }
                },
                interrogative: {
                    name: "Interrogative Formula (Yes/No)",
                    rule: "Had + Subject + been + V1+ing + Object + (since/for + time)?",
                    example: "Had she been studying for three hours?",
                    breakdown: {
                        aux: "Had",
                        subject: "she",
                        been: "been",
                        verb: "studying (V1+ing)",
                        object: "for three hours?"
                    }
                },
                whQuestion: {
                    name: "WH Question Formula",
                    rule: "WH-word + had + Subject + been + V1+ing + Object + (since/for + time)?",
                    example: "How long had she been studying?",
                    breakdown: {
                        wh: "How long",
                        aux: "had",
                        subject: "she",
                        been: "been",
                        verb: "studying (V1+ing)?"
                    }
                }
            }
        },

        // 4. Subject + Verb Rules & Since/For Guide / कर्ता-क्रिया और Since/For नियम
        subjectVerbRules: {
            title: "Subject + Verb Rules",
            titleHindi: "कर्ता + क्रिया नियम (Golden Rule: ALL SUBJECTS ➔ HAD BEEN + V1+ing)",
            goldenRule: "Golden Rule: Every subject (I, You, He, She, It, We, They, Singular, Plural) takes HAD BEEN + V1+ing in Past Perfect Continuous.",
            goldenRuleHindi: "स्वर्ण नियम: Past Perfect Continuous Tense में सभी कर्ताओं के साथ केवल HAD BEEN + V1+ing का प्रयोग होता है।",
            
            table: [
                { subject: "I", aux: "had been", verb: "V1+ing (working)", example: "I had been working." },
                { subject: "You", aux: "had been", verb: "V1+ing (working)", example: "You had been working." },
                { subject: "He", aux: "had been", verb: "V1+ing (working)", example: "He had been working." },
                { subject: "She", aux: "had been", verb: "V1+ing (working)", example: "She had been working." },
                { subject: "It", aux: "had been", verb: "V1+ing (raining)", example: "It had been raining." },
                { subject: "We", aux: "had been", verb: "V1+ing (working)", example: "We had been working." },
                { subject: "They", aux: "had been", verb: "V1+ing (working)", example: "They had been working." },
                { subject: "Singular Name (Rahul)", aux: "had been", verb: "V1+ing (working)", example: "Rahul had been working." },
                { subject: "Plural Noun (Students)", aux: "had been", verb: "V1+ing (working)", example: "Students had been working." }
            ],

            sinceForRules: {
                title: "Since vs For Usage Guide",
                titleHindi: "Since और For का प्रयोग (नियम और अंतर)",
                sinceExplanation: "SINCE = Point of Time (शुरुआती समय बिंदु): Use with specific starting times (e.g., since morning, since Monday, since 8 AM, since 2020, since childhood).",
                forExplanation: "FOR = Duration / Period of Time (समयावधि): Use with calculated time spans (e.g., for two hours, for three days, for five years, for a long time).",
                goldenMemoryRule: "Golden Memory Rule: SINCE ➔ शुरुआत का समय | FOR ➔ कुल अवधि"
            }
        },

        // 5. Positive Sentences / सकारात्मक वाक्य (30 Items)
        positive: {
            title: "Positive Sentences",
            titleHindi: "सकारात्मक वाक्य (Subject + had + been + V1+ing)",
            formula: "Subject + had + been + V1+ing + Object/Complement",
            explanation: "Expresses an action that had been going on continuously for a time period before a past event.",
            explanationHindi: "सकारात्मक वाक्यों में सभी कर्ताओं के साथ 'had been' और V1+ing लगाएं।",
            
            sentences: {
                easy: [
                    { id: "pos-e1", english: "I had been studying for two hours before dinner.", hindi: "मैं रात के खाने से पहले दो घंटे से पढ़ रहा था।", subject: "I", aux: "had been", verb: "studying", object: "for two hours before dinner" },
                    { id: "pos-e2", english: "She had been working since morning when I visited.", hindi: "जब मैं मिला तब वह सुबह से काम कर रही थी।", subject: "She", aux: "had been", verb: "working", object: "since morning when I visited" },
                    { id: "pos-e3", english: "They had been waiting for an hour before the bus arrived.", hindi: "बस आने से पहले वे एक घंटे से इंतज़ार कर रहे थे।", subject: "They", aux: "had been", verb: "waiting", object: "for an hour before bus arrived" },
                    { id: "pos-e4", english: "We had been playing cricket since 4 PM.", hindi: "हम शाम 4 बजे से क्रिकेट खेल रहे थे।", subject: "We", aux: "had been", verb: "playing", object: "cricket since 4 PM" },
                    { id: "pos-e5", english: "He had been sleeping for three hours.", hindi: "वह तीन घंटे से सो रहा था।", subject: "He", aux: "had been", verb: "sleeping", object: "for three hours" },
                    { id: "pos-e6", english: "Rahul had been reading a novel since afternoon.", hindi: "राहुल दोपहर से उपन्यास पढ़ रहा था।", subject: "Rahul", aux: "had been", verb: "reading", object: "a novel since afternoon" },
                    { id: "pos-e7", english: "You had been practicing piano for a long time.", hindi: "आप काफी समय से पियानो का अभ्यास कर रहे थे।", subject: "You", aux: "had been", verb: "practicing", object: "piano for a long time" },
                    { id: "pos-e8", english: "It had been raining continuously since yesterday.", hindi: "कल से लगातार बारिश हो रही थी।", subject: "It", aux: "had been", verb: "raining", object: "continuously since yesterday" },
                    { id: "pos-e9", english: "My mother had been cooking for two hours before guests came.", hindi: "मेहमानों के आने से पहले मेरी माँ दो घंटे से खाना बना रही थीं।", subject: "My mother", aux: "had been", verb: "cooking", object: "for two hours before guests came" },
                    { id: "pos-e10", english: "The children had been watching TV since 5 o'clock.", hindi: "बच्चे 5 बजे से टीवी देख रहे थे।", subject: "The children", aux: "had been", verb: "watching", object: "TV since 5 o'clock" }
                ],
                medium: [
                    { id: "pos-m1", english: "The doctor had been treating patients since early morning.", hindi: "डॉक्टर सुबह-सुबह से मरीजों का इलाज कर रहे थे।", subject: "The doctor", aux: "had been", verb: "treating", object: "patients since early morning" },
                    { id: "pos-m2", english: "She had been preparing for competitive exams for six months.", hindi: "वह छह महीने से प्रतियोगी परीक्षाओं की तैयारी कर रही थी।", subject: "She", aux: "had been", verb: "preparing", object: "for competitive exams for six months" },
                    { id: "pos-m3", english: "The team had been designing the software for three weeks.", hindi: "टीम तीन हफ्तों से सॉफ्टवेयर डिजाइन कर रही थी।", subject: "The team", aux: "had been", verb: "designing", object: "the software for three weeks" },
                    { id: "pos-m4", english: "I had been driving for four hours before taking a rest.", hindi: "आराम करने से पहले मैं चार घंटे से गाड़ी चला रहा था।", subject: "I", aux: "had been", verb: "driving", object: "for four hours before taking rest" },
                    { id: "pos-m5", english: "They had been renovating the house for two months.", hindi: "वे दो महीने से घर का नवीनीकरण कर रहे थे।", subject: "They", aux: "had been", verb: "renovating", object: "the house for two months" },
                    { id: "pos-m6", english: "The teacher had been explaining the topic since 10 AM.", hindi: "शिक्षक सुबह 10 बजे से विषय समझा रहे थे।", subject: "The teacher", aux: "had been", verb: "explaining", object: "the topic since 10 AM" },
                    { id: "pos-m7", english: "We had been planning the trip for several weeks.", hindi: "हम कई हफ्तों से यात्रा की योजना बना रहे थे।", subject: "We", aux: "had been", verb: "planning", object: "the trip for several weeks" },
                    { id: "pos-m8", english: "He had been repairing the machine for two days.", hindi: "वह दो दिन से मशीन की मरम्मत कर रहा था।", subject: "He", aux: "had been", verb: "repairing", object: "the machine for two days" },
                    { id: "pos-m9", english: "The workers had been digging the canal since last month.", hindi: "मजदूर पिछले महीने से नहर की खुदाई कर रहे थे।", subject: "The workers", aux: "had been", verb: "digging", object: "the canal since last month" },
                    { id: "pos-m10", english: "She had been living in London for three years before returning.", hindi: "वापस लौटने से पहले वह तीन साल से लंदन में रह रही थी।", subject: "She", aux: "had been", verb: "living", object: "in London for three years" }
                ],
                hard: [
                    { id: "pos-h1", english: "The software engineers had been troubleshooting the server glitch for eight hours before resolving it.", hindi: "सर्वर की समस्या हल करने से पहले सॉफ्टवेयर इंजीनियर आठ घंटे से उसे ठीक कर रहे थे।", subject: "The software engineers", aux: "had been", verb: "troubleshooting", object: "server glitch for eight hours" },
                    { id: "pos-h2", english: "The research scientists had been experimenting with the compound for a year before achieving breakthrough.", hindi: "सफलता हासिल करने से पहले अनुसंधान वैज्ञानिक एक साल से यौगिक पर प्रयोग कर रहे थे।", subject: "The research scientists", aux: "had been", verb: "experimenting", object: "with compound for a year" },
                    { id: "pos-h3", english: "The environmentalists had been campaigning against deforestation for a decade.", hindi: "पर्यावरणविद एक दशक से वनों की कटाई के खिलाफ अभियान चला रहे थे।", subject: "The environmentalists", aux: "had been", verb: "campaigning", object: "against deforestation for a decade" },
                    { id: "pos-h4", english: "By the time the rescue team arrived, villagers had been battling floodwaters since midnight.", hindi: "जब तक बचाव दल पहुँचा, ग्रामीण आधी रात से बाढ़ के पानी से जूझ रहे थे।", subject: "Villagers", aux: "had been", verb: "battling", object: "floodwaters since midnight" },
                    { id: "pos-h5", english: "The financial auditors had been scrutinizing the balance sheets for a month.", hindi: "वित्तीय लेखा परीक्षक एक महीने से बैलेंस शीट की जांच कर रहे थे।", subject: "The financial auditors", aux: "had been", verb: "scrutinizing", object: "balance sheets for a month" },
                    { id: "pos-h6", english: "The diplomatic mission had been negotiating the peace treaty for five years.", hindi: "राजनयिक मिशन पाँच साल से शांति संधि पर बातचीत कर रहा था।", subject: "The diplomatic mission", aux: "had been", verb: "negotiating", object: "peace treaty for five years" },
                    { id: "pos-h7", english: "She had been managing the regional operations since 2018 before taking executive role.", hindi: "कार्यकारी भूमिका संभालने से पहले वह 2018 से क्षेत्रीय संचालन का प्रबंधन कर रही थी।", subject: "She", aux: "had been", verb: "managing", object: "regional operations since 2018" },
                    { id: "pos-h8", english: "The committee had been evaluating the project proposals for three days before decision.", hindi: "फैसले से पहले समिति तीन दिन से परियोजना प्रस्तावों का मूल्यांकन कर रही थी।", subject: "The committee", aux: "had been", verb: "evaluating", object: "project proposals for three days" },
                    { id: "pos-h9", english: "The archeologists had been excavating the ancient ruin site since spring.", hindi: "पुरातत्वविद वसंत ऋतु से प्राचीन खंडहर स्थल की खुदाई कर रहे थे।", subject: "The archeologists", aux: "had been", verb: "excavating", object: "ancient ruin site since spring" },
                    { id: "pos-h10", english: "The government had been implementing infrastructure reforms for four years before election.", hindi: "चुनाव से पहले सरकार चार साल से बुनियादी ढांचे के सुधारों को लागू कर रही थी।", subject: "The government", aux: "had been", verb: "implementing", object: "infrastructure reforms for four years" }
                ]
            }
        },

        // 6. Negative Sentences / नकारात्मक वाक्य (30 Items)
        negative: {
            title: "Negative Sentences",
            titleHindi: "नकारात्मक वाक्य (Subject + had + not + been + V1+ing)",
            formula: "Subject + had + not (hadn't) + been + V1+ing + Object",
            explanation: "Use 'had not been' or contraction 'hadn't been' followed by V1+ing for negative past continuous duration.",
            explanationHindi: "नकारात्मक वाक्यों में 'had' के बाद 'not' (hadn't) और फिर 'been + V1+ing' लगाएं।",
            
            sentences: {
                easy: [
                    { id: "neg-e1", english: "I had not been sleeping well for a week.", hindi: "मैं एक हफ्ते से ठीक से सो नहीं रहा था।", subject: "I", aux: "had not been", verb: "sleeping", object: "well for a week" },
                    { id: "neg-e2", english: "She hadn't been working there for long.", hindi: "वह वहाँ लंबे समय से काम नहीं कर रही थी।", subject: "She", aux: "hadn't been", verb: "working", object: "there for long" },
                    { id: "neg-e3", english: "They had not been waiting for an hour.", hindi: "वे एक घंटे से इंतज़ार नहीं कर रहे थे।", subject: "They", aux: "had not been", verb: "waiting", object: "for an hour" },
                    { id: "neg-e4", english: "We hadn't been practicing since morning.", hindi: "हम सुबह से अभ्यास नहीं कर रहे थे।", subject: "We", aux: "hadn't been", verb: "practicing", object: "since morning" },
                    { id: "neg-e5", english: "He had not been taking his medicine regularly.", hindi: "वह नियमित रूप से अपनी दवा नहीं ले रहा था।", subject: "He", aux: "had not been", verb: "taking", object: "his medicine regularly" },
                    { id: "neg-e6", english: "Rahul hadn't been attending the classes.", hindi: "राहुल कक्षाओं में उपस्थित नहीं हो रहा था।", subject: "Rahul", aux: "hadn't been", verb: "attending", object: "the classes" },
                    { id: "neg-e7", english: "You had not been paying attention to instructions.", hindi: "आप निर्देशों पर ध्यान नहीं दे रहे थे।", subject: "You", aux: "had not been", verb: "paying", object: "attention to instructions" },
                    { id: "neg-e8", english: "It hadn't been raining for two days.", hindi: "दो दिन से बारिश नहीं हो रही थी।", subject: "It", aux: "hadn't been", verb: "raining", object: "for two days" },
                    { id: "neg-e9", english: "She had not been feeling well since yesterday.", hindi: "कल से उसकी तबीयत ठीक नहीं लग रही थी।", subject: "She", aux: "had not been", verb: "feeling", object: "well since yesterday" },
                    { id: "neg-e10", english: "They hadn't been making any noise.", hindi: "वे कोई शोर नहीं मचा रहे थे।", subject: "They", aux: "hadn't been", verb: "making", object: "any noise" }
                ],
                medium: [
                    { id: "neg-m1", english: "The doctor had not been practicing in this hospital for long.", hindi: "डॉक्टर इस अस्पताल में लंबे समय से अभ्यास नहीं कर रहे थे।", subject: "The doctor", aux: "had not been", verb: "practicing", object: "in this hospital for long" },
                    { id: "neg-m2", english: "She hadn't been using her mobile during class hours.", hindi: "वह कक्षा के घंटों के दौरान अपना मोबाइल इस्तेमाल नहीं कर रही थी।", subject: "She", aux: "hadn't been", verb: "using", object: "her mobile during class hours" },
                    { id: "neg-m3", english: "The team had not been practicing regularly before finals.", hindi: "फाइनल से पहले टीम नियमित रूप से अभ्यास नहीं कर रही थी।", subject: "The team", aux: "had not been", verb: "practicing", object: "regularly before finals" },
                    { id: "neg-m4", english: "We hadn't been expecting any delay in delivery.", hindi: "हम डिलीवरी में किसी देरी की उम्मीद नहीं कर रहे थे।", subject: "We", aux: "hadn't been", verb: "expecting", object: "any delay in delivery" },
                    { id: "neg-m5", english: "He had not been maintaining the logbook since last week.", hindi: "वह पिछले सप्ताह से लॉगबुक का रखरखाव नहीं कर रहा था।", subject: "He", aux: "had not been", verb: "maintaining", object: "the logbook since last week" },
                    { id: "neg-m6", english: "The students hadn't been preparing for test seriously.", hindi: "छात्र गंभीरता से टेस्ट की तैयारी नहीं कर रहे थे।", subject: "The students", aux: "hadn't been", verb: "preparing", object: "for test seriously" },
                    { id: "neg-m7", english: "She had not been updating her software regularly.", hindi: "वह नियमित रूप से अपने सॉफ्टवेयर को अपडेट नहीं कर रही थी।", subject: "She", aux: "had not been", verb: "updating", object: "her software regularly" },
                    { id: "neg-m8", english: "The system hadn't been responding properly for two hours.", hindi: "सिस्टम दो घंटे से ठीक से जवाब नहीं दे रहा था।", subject: "The system", aux: "hadn't been", verb: "responding", object: "properly for two hours" },
                    { id: "neg-m9", english: "They had not been following the safety rules.", hindi: "वे सुरक्षा नियमों का पालन नहीं कर रहे थे।", subject: "They", aux: "had not been", verb: "following", object: "the safety rules" },
                    { id: "neg-m10", english: "I hadn't been feeling energetic since Monday.", hindi: "सोमवार से मुझे ऊर्जावान महसूस नहीं हो रहा था।", subject: "I", aux: "hadn't been", verb: "feeling", object: "energetic since Monday" }
                ],
                hard: [
                    { id: "neg-h1", english: "The quality assurance team had not been monitoring the production line properly.", hindi: "गुणवत्ता आश्वासन टीम उत्पादन लाइन की ठीक से निगरानी नहीं कर रही थी।", subject: "The quality assurance team", aux: "had not been", verb: "monitoring", object: "production line properly" },
                    { id: "neg-h2", english: "The agency hadn't been backing up data servers regularly before crash.", hindi: "क्रैश से पहले एजेंसी डेटा सर्वर का नियमित बैकअप नहीं ले रही थी।", subject: "The agency", aux: "hadn't been", verb: "backing up", object: "data servers regularly" },
                    { id: "neg-h3", english: "The local council had not been maintaining drainage channels for years.", hindi: "स्थानीय परिषद सालों से जल निकासी चैनलों का रखरखाव नहीं कर रही थी।", subject: "The local council", aux: "had not been", verb: "maintaining", object: "drainage channels for years" },
                    { id: "neg-h4", english: "Research scholars hadn't been receiving sufficient funding for project.", hindi: "शोध विद्वानों को परियोजना के लिए पर्याप्त धनराशि नहीं मिल रही थी।", subject: "Research scholars", aux: "hadn't been", verb: "receiving", object: "sufficient funding" },
                    { id: "neg-h5", english: "The security guards had not been checking entry passes at gate.", hindi: "सुरक्षा गार्ड गेट पर प्रवेश पास की जांच नहीं कर रहे थे।", subject: "The security guards", aux: "had not been", verb: "checking", object: "entry passes at gate" },
                    { id: "neg-h6", english: "The company hadn't been reporting quarter growth accurately.", hindi: "कंपनी तिमाही वृद्धि की सटीक रिपोर्ट नहीं दे रही थी।", subject: "The company", aux: "hadn't been", verb: "reporting", object: "quarter growth accurately" },
                    { id: "neg-h7", english: "The government had not been enforcing the new regulations strictly.", hindi: "सरकार नए नियमों को सख्ती से लागू नहीं कर रही थी।", subject: "The government", aux: "had not been", verb: "enforcing", object: "new regulations strictly" },
                    { id: "neg-h8", english: "Investigators hadn't been following standard evidence procedures.", hindi: "जांचकर्ता मानक साक्ष्य प्रक्रियाओं का पालन नहीं कर रहे थे।", subject: "Investigators", aux: "hadn't been", verb: "following", object: "standard evidence procedures" },
                    { id: "neg-h9", english: "The contractor had not been paying workers full wages on time.", hindi: "ठेकेदार समय पर मजदूरों को पूरा वेतन नहीं दे रहा था।", subject: "The contractor", aux: "had not been", verb: "paying", object: "workers full wages on time" },
                    { id: "neg-h10", english: "The hospital hadn't been operating emergency power generators.", hindi: "अस्पताल आपातकालीन बिजली जनरेटर नहीं चला रहा था।", subject: "The hospital", aux: "hadn't been", verb: "operating", object: "emergency power generators" }
                ]
            }
        },

        // 7. Interrogative Sentences / प्रश्नवाचक वाक्य (30 Items)
        interrogative: {
            title: "Interrogative Sentences",
            titleHindi: "प्रश्नवाचक वाक्य (Had + Subject + been + V1+ing?)",
            formula: "Had + Subject + been + V1+ing + Object?",
            explanation: "Start with HAD followed by Subject, 'been', and V1+ing for Yes/No continuous past duration questions.",
            explanationHindi: "प्रश्नवाचक वाक्यों में 'Had' से शुरुआत करें, फिर कर्ता, 'been' और V1+ing लगाएं।",
            
            sentences: {
                easy: [
                    { id: "int-e1", english: "Had you been studying for two hours before dinner?", hindi: "क्या आप रात के खाने से पहले दो घंटे से पढ़ रहे थे?", subject: "you", aux: "Had", verb: "studying", object: "for two hours before dinner" },
                    { id: "int-e2", english: "Had she been working since morning when you arrived?", hindi: "क्या जब आप पहुंचे तब वह सुबह से काम कर रही थी?", subject: "she", aux: "Had", verb: "working", object: "since morning when you arrived" },
                    { id: "int-e3", english: "Had they been waiting for an hour?", hindi: "क्या वे एक घंटे से इंतज़ार कर रहे थे?", subject: "they", aux: "Had", verb: "waiting", object: "for an hour" },
                    { id: "int-e4", english: "Had we been playing cricket since 4 PM?", hindi: "क्या हम शाम 4 बजे से क्रिकेट खेल रहे थे?", subject: "we", aux: "Had", verb: "playing", object: "cricket since 4 PM" },
                    { id: "int-e5", english: "Had he been sleeping for three hours?", hindi: "क्या वह तीन घंटे से सो रहा था?", subject: "he", aux: "Had", verb: "sleeping", object: "for three hours" },
                    { id: "int-e6", english: "Had Rahul been reading the report since noon?", hindi: "क्या राहुल दोपहर से रिपोर्ट पढ़ रहा था?", subject: "Rahul", aux: "Had", verb: "reading", object: "the report since noon" },
                    { id: "int-e7", english: "Had it been raining continuously since yesterday?", hindi: "क्या कल से लगातार बारिश हो रही थी?", subject: "it", aux: "Had", verb: "raining", object: "continuously since yesterday" },
                    { id: "int-e8", english: "Had you been practicing piano for a long time?", hindi: "क्या आप काफी समय से पियानो का अभ्यास कर रहे थे?", subject: "you", aux: "Had", verb: "practicing", object: "piano for a long time" },
                    { id: "int-e9", english: "Had she been cooking before guests arrived?", hindi: "क्या मेहमानों के आने से पहले वह खाना बना रही थी?", subject: "she", aux: "Had", verb: "cooking", object: "before guests arrived" },
                    { id: "int-e10", english: "Had they been living in London for three years?", hindi: "क्या वे तीन साल से लंदन में रह रहे थे?", subject: "they", aux: "Had", verb: "living", object: "in London for three years" }
                ],
                medium: [
                    { id: "int-m1", english: "Had the doctor been treating patients since early morning?", hindi: "क्या डॉक्टर सुबह-सुबह से मरीजों का इलाज कर रहे थे?", subject: "the doctor", aux: "Had", verb: "treating", object: "patients since early morning" },
                    { id: "int-m2", english: "Had she been preparing for exams for six months?", hindi: "क्या वह छह महीने से परीक्षा की तैयारी कर रही थी?", subject: "she", aux: "Had", verb: "preparing", object: "for exams for six months" },
                    { id: "int-m3", english: "Had the team been designing software for weeks?", hindi: "क्या टीम हफ्तों से सॉफ्टवेयर डिजाइन कर रही थी?", subject: "the team", aux: "Had", verb: "designing", object: "software for weeks" },
                    { id: "int-m4", english: "Had you been driving for four hours before rest?", hindi: "क्या आप आराम से पहले चार घंटे से गाड़ी चला रहे थे?", subject: "you", aux: "Had", verb: "driving", object: "for four hours before rest" },
                    { id: "int-m5", english: "Had they been renovating the house for two months?", hindi: "क्या वे दो महीने से घर का नवीनीकरण कर रहे थे?", subject: "they", aux: "Had", verb: "renovating", object: "the house for two months" },
                    { id: "int-m6", english: "Had the teacher been explaining since 10 AM?", hindi: "क्या शिक्षक सुबह 10 बजे से समझा रहे थे?", subject: "the teacher", aux: "Had", verb: "explaining", object: "since 10 AM" },
                    { id: "int-m7", english: "Had we been planning the trip for weeks?", hindi: "क्या हम हफ्तों से यात्रा की योजना बना रहे थे?", subject: "we", aux: "Had", verb: "planning", object: "the trip for weeks" },
                    { id: "int-m8", english: "Had he been repairing the motor for two days?", hindi: "क्या वह दो दिन से मोटर की मरम्मत कर रहा था?", subject: "he", aux: "Had", verb: "repairing", object: "the motor for two days" },
                    { id: "int-m9", english: "Had workers been digging canal since last week?", hindi: "क्या मजदूर पिछले सप्ताह से नहर खोद रहे थे?", subject: "workers", aux: "Had", verb: "digging", object: "canal since last week" },
                    { id: "int-m10", english: "Had she been feeling sick since yesterday?", hindi: "क्या वह कल से बीमार महसूस कर रही थी?", subject: "she", aux: "Had", verb: "feeling", object: "sick since yesterday" }
                ],
                hard: [
                    { id: "int-h1", english: "Had engineers been troubleshooting server glitch for hours?", hindi: "क्या इंजीनियर घंटों से सर्वर की समस्या ठीक कर रहे थे?", subject: "engineers", aux: "Had", verb: "troubleshooting", object: "server glitch for hours" },
                    { id: "int-h2", english: "Had scientists been experimenting for a year before success?", hindi: "क्या सफलता से पहले वैज्ञानिक एक साल से प्रयोग कर रहे थे?", subject: "scientists", aux: "Had", verb: "experimenting", object: "for a year before success" },
                    { id: "int-h3", english: "Had environmentalists been campaigning for a decade?", hindi: "क्या पर्यावरणविद एक दशक से अभियान चला रहे थे?", subject: "environmentalists", aux: "Had", verb: "campaigning", object: "for a decade" },
                    { id: "int-h4", english: "Had villagers been battling floodwaters since midnight?", hindi: "क्या ग्रामीण आधी रात से बाढ़ के पानी से जूझ रहे थे?", subject: "villagers", aux: "Had", verb: "battling", object: "floodwaters since midnight" },
                    { id: "int-h5", english: "Had auditors been scrutinizing balance sheets for a month?", hindi: "क्या लेखा परीक्षक एक महीने से बैलेंस शीट की जांच कर रहे थे?", subject: "auditors", aux: "Had", verb: "scrutinizing", object: "balance sheets for a month" },
                    { id: "int-h6", english: "Had diplomats been negotiating peace treaty for five years?", hindi: "क्या राजनयिक पाँच साल से शांति संधि पर बातचीत कर रहे थे?", subject: "diplomats", aux: "Had", verb: "negotiating", object: "peace treaty for five years" },
                    { id: "int-h7", english: "Had she been managing regional ops since 2018?", hindi: "क्या वह 2018 से क्षेत्रीय संचालन का प्रबंधन कर रही थी?", subject: "she", aux: "Had", verb: "managing", object: "regional ops since 2018" },
                    { id: "int-h8", english: "Had committee been evaluating proposals for three days?", hindi: "क्या समिति तीन दिन से प्रस्तावों का मूल्यांकन कर रही थी?", subject: "committee", aux: "Had", verb: "evaluating", object: "proposals for three days" },
                    { id: "int-h9", english: "Had archeologists been excavating site since spring?", hindi: "क्या पुरातत्वविद वसंत से स्थल की खुदाई कर रहे थे?", subject: "archeologists", aux: "Had", verb: "excavating", object: "site since spring" },
                    { id: "int-h10", english: "Had government been implementing reforms for four years?", hindi: "क्या सरकार चार साल से सुधारों को लागू कर रही थी?", subject: "government", aux: "Had", verb: "implementing", object: "reforms for four years" }
                ]
            }
        },

        // 8. WH Questions / WH प्रश्न (30 Items)
        whQuestions: {
            title: "WH Questions",
            titleHindi: "WH प्रश्न (WH-word + had + Subject + been + V1+ing?)",
            formula: "WH-word + had + Subject + been + V1+ing + Object?",
            explanation: "Place WH question word (How long, What, Where, Why, Since when) before HAD + Subject + been + V1+ing.",
            explanationHindi: "WH प्रश्नों में WH-शब्द (जैसे How long, Where) के तुरंत बाद 'had', कर्ता, 'been' और V1+ing लगाएं।",
            
            sentences: {
                easy: [
                    { id: "wh-e1", english: "How long had you been waiting before the train arrived?", hindi: "ट्रेन आने से पहले आप कितनी देर से इंतज़ार कर रहे थे?", subject: "you", aux: "had", verb: "waiting", object: "before train arrived", whWord: "How long" },
                    { id: "wh-e2", english: "Where had she been living before moving to Delhi?", hindi: "दिल्ली जाने से पहले वह कहाँ रह रही थी?", subject: "she", aux: "had", verb: "living", object: "before moving to Delhi", whWord: "Where" },
                    { id: "wh-e3", english: "Why had they been arguing for hours?", hindi: "वे घंटों से क्यों बहस कर रहे थे?", subject: "they", aux: "had", verb: "arguing", object: "for hours", whWord: "Why" },
                    { id: "wh-e4", english: "What had he been doing since morning?", hindi: "वह सुबह से क्या कर रहा था?", subject: "he", aux: "had", verb: "doing", object: "since morning", whWord: "What" },
                    { id: "wh-e5", english: "Since when had she been working in that office?", hindi: "वह उस दफ़्तर में कब से काम कर रही थी?", subject: "she", aux: "had", verb: "working", object: "in that office", whWord: "Since when" },
                    { id: "wh-e6", english: "How long had Rahul been practicing cricket?", hindi: "राहुल कितनी देर से क्रिकेट का अभ्यास कर रहा था?", subject: "Rahul", aux: "had", verb: "practicing", object: "cricket", whWord: "How long" },
                    { id: "wh-e7", english: "Where had we been driving for two hours?", hindi: "हम दो घंटे से कहाँ गाड़ी चला रहे थे?", subject: "we", aux: "had", verb: "driving", object: "for two hours", whWord: "Where" },
                    { id: "wh-e8", english: "Why had the baby been crying since noon?", hindi: "बच्चा दोपहर से क्यों रो रहा था?", subject: "the baby", aux: "had", verb: "crying", object: "since noon", whWord: "Why" },
                    { id: "wh-e9", english: "What had they been discussing before meeting ended?", hindi: "बैठक खत्म होने से पहले वे क्या चर्चा कर रहे थे?", subject: "they", aux: "had", verb: "discussing", object: "before meeting ended", whWord: "What" },
                    { id: "wh-e10", english: "How long had it been raining before sun came out?", hindi: "सूरज निकलने से पहले कितनी देर से बारिश हो रही थी?", subject: "it", aux: "had", verb: "raining", object: "before sun came out", whWord: "How long" }
                ],
                medium: [
                    { id: "wh-m1", english: "How long had the doctor been treating patients before break?", hindi: "ब्रेक से पहले डॉक्टर कितनी देर से मरीजों का इलाज कर रहे थे?", subject: "the doctor", aux: "had", verb: "treating", object: "patients before break", whWord: "How long" },
                    { id: "wh-m2", english: "Why had she been crying before news arrived?", hindi: "खबर आने से पहले वह क्यों रो रही थी?", subject: "she", aux: "had", verb: "crying", object: "before news arrived", whWord: "Why" },
                    { id: "wh-m3", english: "Where had the team been practicing before championship?", hindi: "चैंपियनशिप से पहले टीम कहाँ अभ्यास कर रही थी?", subject: "the team", aux: "had", verb: "practicing", object: "before championship", whWord: "Where" },
                    { id: "wh-m4", english: "What had they been searching for in the forest for days?", hindi: "वे दिनों से जंगल में क्या ढूंढ रहे थे?", subject: "they", aux: "had", verb: "searching", object: "in forest for days", whWord: "What" },
                    { id: "wh-m5", english: "How long had he been repairing the car engine?", hindi: "वह कार का इंजन कितनी देर से ठीक कर रहा था?", subject: "he", aux: "had", verb: "repairing", object: "the car engine", whWord: "How long" },
                    { id: "wh-m6", english: "Since when had the teacher been explaining theorem?", hindi: "शिक्षक कब से प्रमेय समझा रहे थे?", subject: "the teacher", aux: "had", verb: "explaining", object: "theorem", whWord: "Since when" },
                    { id: "wh-m7", english: "Why had workers been protesting outside factory?", hindi: "मजदूर कारखाने के बाहर क्यों विरोध प्रदर्शन कर रहे थे?", subject: "workers", aux: "had", verb: "protesting", object: "outside factory", whWord: "Why" },
                    { id: "wh-m8", english: "Where had she been storing the raw materials?", hindi: "वह कच्चा माल कहाँ संग्रहीत कर रही थी?", subject: "she", aux: "had", verb: "storing", object: "raw materials", whWord: "Where" },
                    { id: "wh-m9", english: "How long had students been revising syllabus?", hindi: "छात्र कितनी देर से पाठ्यक्रम दोहरा रहे थे?", subject: "students", aux: "had", verb: "revising", object: "syllabus", whWord: "How long" },
                    { id: "wh-m10", english: "What had company been manufacturing at plant?", hindi: "कंपनी संयंत्र में क्या निर्माण कर रही थी?", subject: "company", aux: "had", verb: "manufacturing", object: "at plant", whWord: "What" }
                ],
                hard: [
                    { id: "wh-h1", english: "How long had engineers been troubleshooting server glitch before backup succeeded?", hindi: "बैकअप सफल होने से पहले इंजीनियर कितनी देर से सर्वर की समस्या ठीक कर रहे थे?", subject: "engineers", aux: "had", verb: "troubleshooting", object: "server glitch before backup", whWord: "How long" },
                    { id: "wh-h2", english: "Why had scientists been experimenting with that compound for years?", hindi: "वैज्ञानिक सालों से उस यौगिक पर प्रयोग क्यों कर रहे थे?", subject: "scientists", aux: "had", verb: "experimenting", object: "with compound for years", whWord: "Why" },
                    { id: "wh-h3", english: "Where had environmentalists been campaigning before government policy change?", hindi: "सरकारी नीति बदलने से पहले पर्यावरणविद कहाँ अभियान चला रहे थे?", subject: "environmentalists", aux: "had", verb: "campaigning", object: "before policy change", whWord: "Where" },
                    { id: "wh-h4", english: "How long had auditors been scrutinizing financial entries before discovering fraud?", hindi: "धोखाधड़ी का पता लगाने से पहले अंकेक्षक कितनी देर से वित्तीय प्रविष्टियों की जांच कर रहे थे?", subject: "auditors", aux: "had", verb: "scrutinizing", object: "entries before fraud detection", whWord: "How long" },
                    { id: "wh-h5", english: "What measures had government been enforcing prior to election?", hindi: "चुनाव से पहले सरकार क्या उपाय लागू कर रही थी?", subject: "government", aux: "had", verb: "enforcing", object: "prior to election", whWord: "What measures" },
                    { id: "wh-h6", english: "Why had tribunal been delaying the final judgment for months?", hindi: "न्यायाधिकरण महीनों से अंतिम फैसले में देरी क्यों कर रहा था?", subject: "tribunal", aux: "had", verb: "delaying", object: "judgment for months", whWord: "Why" },
                    { id: "wh-h7", english: "Since when had research team been observing atmospheric changes?", hindi: "शोध टीम कब से वायुमंडलीय परिवर्तनों का अवलोकन कर रही थी?", subject: "research team", aux: "had", verb: "observing", object: "atmospheric changes", whWord: "Since when" },
                    { id: "wh-h8", english: "Where had archaeologists been excavating ruins before monsoon arrived?", hindi: "मानसून आने से पहले पुरातत्वविद कहाँ खंडहरों की खुदाई कर रहे थे?", subject: "archaeologists", aux: "had", verb: "excavating", object: "ruins before monsoon", whWord: "Where" },
                    { id: "wh-h9", english: "How long had diplomats been negotiating peace treaty before signing?", hindi: "हस्ताक्षर करने से पहले राजनयिक कितनी देर से शांति संधि पर बातचीत कर रहे थे?", subject: "diplomats", aux: "had", verb: "negotiating", object: "peace treaty before signing", whWord: "How long" },
                    { id: "wh-h10", english: "What software features had developers been building throughout quarter?", hindi: "डेवलपर्स तिमाही भर से कौन सी सॉफ्टवेयर सुविधाएं बना रहे थे?", subject: "developers", aux: "had", verb: "building", object: "throughout quarter", whWord: "What software features" }
                ]
            }
        },

        // 9. Common Mistakes & Corrections / सामान्य गलतियाँ (At least 15 Items)
        commonMistakes: {
            title: "Common Mistakes",
            titleHindi: "सामान्य गलतियाँ और सुधार (Common Mistakes & Corrections)",
            intro: "Avoid these 15 common errors when forming Past Perfect Continuous Tense sentences.",
            introHindi: "Past Perfect Continuous Tense का प्रयोग करते समय इन 15 सामान्य गलतियों से बचें।",
            mistakes: [
                {
                    wrong: "She had been worked for two hours.",
                    correct: "She had been working for two hours.",
                    why: "Past Perfect Continuous uses V1+ing (working), not V2/V3 (worked).",
                    whyHindi: "had been के बाद V1+ing (working) आता है, V2/V3 (worked) नहीं।"
                },
                {
                    wrong: "They have been waiting for two hours before the bus arrived.",
                    correct: "They had been waiting for two hours before the bus arrived.",
                    why: "The waiting happened before a past event (arrived), so use 'had been', not 'have been'.",
                    whyHindi: "अतीत की घटना से पहले की निरंतरता के लिए 'have been' नहीं, 'had been' का प्रयोग करें।"
                },
                {
                    wrong: "I had studying since morning.",
                    correct: "I had been studying since morning.",
                    why: "Missing 'been'. Past Perfect Continuous requires 'had + been + V1+ing'.",
                    whyHindi: "'been' छोड़ना गलत है। हमेशा 'had + been + V1+ing' लगाएं।"
                },
                {
                    wrong: "She was working for three hours before she took a break.",
                    correct: "She had been working for three hours before she took a break.",
                    why: "Plain Past Continuous ('was working') lacks duration context before another past action; use Past Perfect Continuous.",
                    whyHindi: "अतीत में किसी कार्य से पहले की अवधि (for 3 hours) दर्शाने के लिए Past Perfect Continuous (had been working) आता है।"
                },
                {
                    wrong: "He had been work since Monday.",
                    correct: "He had been working since Monday.",
                    why: "'work' is V1. Continuous structure requires V1+ing ('working').",
                    whyHindi: "had been के बाद V1 (work) गलत है, V1+ing (working) लगाएं।"
                },
                {
                    wrong: "I had been studying for 8 AM.",
                    correct: "I had been studying since 8 AM.",
                    why: "8 AM is a specific starting time point, so use 'since', not 'for'.",
                    whyHindi: "8 AM शुरुआती समय बिंदु है, इसलिए 'for' नहीं 'since' का प्रयोग करें।"
                },
                {
                    wrong: "She had been working since three hours.",
                    correct: "She had been working for three hours.",
                    why: "'three hours' is a period of duration, so use 'for', not 'since'.",
                    whyHindi: "तीन घंटे समय की अवधि (duration) है, इसलिए 'since' नहीं 'for' लगाएं।"
                },
                {
                    wrong: "Had she working for two hours?",
                    correct: "Had she been working for two hours?",
                    why: "Missing 'been' in interrogative structure. Correct order: Had + Subject + been + V1+ing?",
                    whyHindi: "प्रश्नवाचक में 'been' छूट गया है। सही क्रम: Had + Subject + been + V1+ing?"
                },
                {
                    wrong: "They had not been worked properly.",
                    correct: "They had not been working properly.",
                    why: "After 'had not been', use V1+ing ('working'), not V3 ('worked').",
                    whyHindi: "had not been के बाद V1+ing (working) आता है।"
                },
                {
                    wrong: "She didn't had been studying.",
                    correct: "She hadn't been studying. / She had not been studying.",
                    why: "Never combine 'didn't' with 'had been'. Negative form is 'had not been' or 'hadn't been'.",
                    whyHindi: "'didn't had been' गलत है, 'had not been' या 'hadn't been' का प्रयोग करें।"
                },
                {
                    wrong: "Why you had been waiting?",
                    correct: "Why had you been waiting?",
                    why: "In WH questions, 'had' must come before the subject ('you').",
                    whyHindi: "WH प्रश्नों में 'had' कर्ता (you) से पहले आना चाहिए।"
                },
                {
                    wrong: "He was tired because he had worked all night.",
                    correct: "He was tired because he had been working all night.",
                    why: "To emphasize the ongoing duration of continuous effort leading to fatigue, Past Perfect Continuous is preferred.",
                    whyHindi: "रात भर की निरंतर मेहनत और थकान के कारण पर बल देने के लिए Past Perfect Continuous (had been working) बेहतर है।"
                },
                {
                    wrong: "I had been live in Delhi since 2010.",
                    correct: "I had been living in Delhi since 2010.",
                    why: "'live' is V1. Use 'living' (V1+ing).",
                    whyHindi: "had been के साथ live नहीं, living (V1+ing) आता है।"
                },
                {
                    wrong: "They had been waited since noon.",
                    correct: "They had been waiting since noon.",
                    why: "'waited' is V2/V3. Use V1+ing ('waiting').",
                    whyHindi: "had been के बाद waited नहीं, waiting (V1+ing) का प्रयोग होता है।"
                },
                {
                    wrong: "She has been working for two hours before he called yesterday.",
                    correct: "She had been working for two hours before he called yesterday.",
                    why: "The context is past ('called yesterday'), so use 'had been', not 'has been'.",
                    whyHindi: "अतीत के संदर्भ (yesterday) में 'has been' गलत है, 'had been' लगाएं।"
                }
            ]
        },

        // 10. Summary & Revision / सारांश एवं दोहराव (15 Revision Examples)
        summary: {
            title: "Summary & Revision",
            titleHindi: "सारांश एवं दोहराव (Revision Summary)",
            introduction: "Quick summary of Past Perfect Continuous rules, formulas, since/for, timelines, and memory anchors.",
            introductionHindi: "Past Perfect Continuous Tense के मुख्य नियमों, सूत्रों और याद रखने योग्य बिंदुओं का त्वरित सारांश।",
            
            goldenRules: [
                "1. Golden Formula ➔ Subject + HAD + BEEN + V1+ing + Object",
                "2. All Subjects ➔ HAD BEEN is used for I, You, He, She, It, We, They, Singular, Plural.",
                "3. Main Verb ➔ Always V1+ing (studying, working, waiting).",
                "4. Negative Form ➔ Subject + had not (hadn't) + been + V1+ing",
                "5. Interrogative Form ➔ Had + Subject + been + V1+ing?",
                "6. Time Expressions ➔ SINCE = Starting point (morning, 2020) | FOR = Duration (2 hours, 5 years).",
                "7. Past Timeline ➔ Ongoing activity before a past event or deadline."
            ],

            formulaSummary: {
                positive: "Subject + had + been + V1+ing + Object + (since/for + time)",
                negative: "Subject + had + not (hadn't) + been + V1+ing + Object",
                interrogative: "Had + Subject + been + V1+ing + Object?",
                whQuestion: "WH-word + had + Subject + been + V1+ing + Object?"
            },

            revisionExamples: {
                easy: [
                    { id: "sum-e1", english: "I had been studying for two hours before dinner.", hindi: "मैं खाने से पहले दो घंटे से पढ़ रहा था।", note: "All subjects take HAD BEEN + V1+ing" },
                    { id: "sum-e2", english: "She had not been working since morning.", hindi: "वह सुबह से काम नहीं कर रही थी।", note: "Negative with had not been + V1+ing" },
                    { id: "sum-e3", english: "Had they been waiting for an hour?", hindi: "क्या वे एक घंटे से इंतज़ार कर रहे थे?", note: "Interrogative starting with Had" },
                    { id: "sum-e4", english: "How long had he been driving?", hindi: "वह कितनी देर से गाड़ी चला रहा था?", note: "WH question with How long had" },
                    { id: "sum-e5", english: "It had been raining continuously since yesterday.", hindi: "कल से लगातार बारिश हो रही थी।", note: "Since for starting point" }
                ],
                medium: [
                    { id: "sum-m1", english: "The doctor had been treating patients since early morning.", hindi: "डॉक्टर सुबह-सुबह से मरीजों का इलाज कर रहे थे।", note: "Doctor + had been + V1+ing" },
                    { id: "sum-m2", english: "We hadn't been expecting any delay.", hindi: "हम किसी देरी की उम्मीद नहीं कर रहे थे।", note: "Contraction hadn't been" },
                    { id: "sum-m3", english: "Had the teacher been explaining since 10 AM?", hindi: "क्या शिक्षक 10 बजे से समझा रहे थे?", note: "Yes/No interrogative" },
                    { id: "sum-m4", english: "Why had workers been protesting outside factory?", hindi: "मजदूर कारखाने के बाहर क्यों विरोध कर रहे थे?", note: "WH question with Why had" },
                    { id: "sum-m5", english: "He was tired because he had been working all night.", hindi: "वह थका था क्योंकि वह रात भर काम कर रहा था।", note: "Continuous cause of past state" }
                ],
                hard: [
                    { id: "sum-h1", english: "Engineers had been troubleshooting server glitch for hours.", hindi: "इंजीनियर घंटों से सर्वर की समस्या ठीक कर रहे थे।", note: "Technical context with duration" },
                    { id: "sum-h2", english: "The council had not been maintaining drainage channels for years.", hindi: "परिषद सालों से जल निकासी चैनलों का रखरखाव नहीं कर रही थी।", note: "Formal long-term negative" },
                    { id: "sum-h3", english: "Had archaeologists been excavating site since spring?", hindi: "क्या पुरातत्वविद वसंत से स्थल की खुदाई कर रहे थे?", note: "Excavation context with since" },
                    { id: "sum-h4", english: "By the time rescue arrived, villagers had been battling floodwaters.", hindi: "जब तक बचाव पहुँचा, ग्रामीण बाढ़ के पानी से जूझ रहे थे।", note: "By the time ongoing timeline" },
                    { id: "sum-h5", english: "She had been managing regional ops for five years before promotion.", hindi: "पदोनत्ति से पहले वह पाँच साल से क्षेत्रीय संचालन संभाल रही थी।", note: "Long-term ongoing effort" }
                ]
            }
        },

        // 11. Practice Exercises / अभ्यास (120 Practice Sentences Total)
        exercises: {
            title: "Past Perfect Continuous Practice Sentences",
            titleHindi: "पूर्ण निरंतर भूतकाल — अभ्यास (120 Practice Sentences)",
            introduction: "Practice all 120 sentences across Positive, Negative, Interrogative, and WH Questions to master Past Perfect Continuous Tense.",
            introductionHindi: "Past Perfect Continuous Tense के 120 अभ्यास वाक्यों (सकारात्मक, नकारात्मक, प्रश्नवाचक एवं WH प्रश्न) के माध्यम से पूरा अभ्यास करें।",
            categories: []
        },

        // 12. Quiz Configuration / ज्ञान परीक्षा (12 Quiz Combinations)
        quiz: {
            title: "Past Perfect Continuous Quiz",
            titleHindi: "पूर्ण निरंतर भूतकाल — ज्ञान परीक्षा",
            questions: []
        }
    }
};

// Initialize categories referencing existing sections (120 Practice Sentences total)
pastPerfectContinuousLesson.sections.exercises.categories = [
    {
        id: "positive",
        title: "Positive Sentences Practice",
        titleHindi: "1. सकारात्मक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Positive Sentence",
        sentences: pastPerfectContinuousLesson.sections.positive.sentences
    },
    {
        id: "negative",
        title: "Negative Sentences Practice",
        titleHindi: "2. नकारात्मक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Negative Sentence",
        sentences: pastPerfectContinuousLesson.sections.negative.sentences
    },
    {
        id: "interrogative",
        title: "Interrogative Sentences Practice",
        titleHindi: "3. प्रश्नवाचक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Yes/No Question",
        sentences: pastPerfectContinuousLesson.sections.interrogative.sentences
    },
    {
        id: "whQuestions",
        title: "WH Questions Practice",
        titleHindi: "4. WH प्रश्न अभ्यास (30 Sentences)",
        typeLabel: "WH Question",
        sentences: pastPerfectContinuousLesson.sections.whQuestions.sentences
    }
];

/**
 * Get the complete Past Perfect Continuous lesson object
 * @returns {object}
 */
export function getPastPerfectContinuousLesson() {
    return { ...pastPerfectContinuousLesson };
}

/**
 * Get a specific section of Past Perfect Continuous lesson data
 * @param {string} sectionName 
 * @returns {object|Array|null}
 */
export function getPastPerfectContinuousSection(sectionName) {
    if (!sectionName || !pastPerfectContinuousLesson.sections) return null;
    return pastPerfectContinuousLesson.sections[sectionName] || null;
}
