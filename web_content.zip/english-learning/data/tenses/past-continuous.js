/**
 * Central Lesson Data for Past Continuous Tense (अपूर्ण भूतकाल)
 * Single Source of Truth for Past Continuous Tense Module.
 * Follows proven reference architecture established in completed Tenses.
 */

const pastContinuousLesson = {
    id: "past-continuous",
    title: "Past Continuous",
    titleHindi: "अपूर्ण भूतकाल (रहा था / रही थी / रहे थे)",
    description: "Learn Past Continuous Tense in simple Hindi: Subject + was/were + V1+ing + Object.",

    sections: {
        // 1. Identification / पहचान और अवधारणा
        identification: {
            title: "Identification",
            titleHindi: "पहचान और अवधारणा",
            english: "Past Continuous Tense is used to describe an action that was ongoing or in progress at a specific time in the past.",
            hindi: "Past Continuous Tense (अपूर्ण भूतकाल) का प्रयोग उन कार्यों के लिए किया जाता है जो भूतकाल (Past) में किसी निश्चित समय पर जारी (in progress) थे और पूरे नहीं हुए थे।",
            hindiIdentityRule: "पहचान (Hindi Clues): वाक्य की मुख्य क्रिया (Main Verb) के अंत में - रहा था, रही थी, रहे थे, हुआ था, हुई थी, हुए थे आदि शब्द आते हैं।",
            points: [
                {
                    english: "Expresses an action that was going on at a specific past moment.",
                    hindi: "अतीत में किसी खास समय पर चल रहे काम को दर्शाता है (जैसे: At 8 PM, I was studying. / रात 8 बजे मैं पढ़ रहा था।)"
                },
                {
                    english: "Auxiliary Verbs: 'was' for singular subjects (I, He, She, It, Singular) and 'were' for plural subjects (You, We, They, Plural).",
                    hindi: "सहायक क्रियाएं: I, He, She, It और एकवचन कर्ता के साथ 'was' और You, We, They तथा बहुवचन कर्ता के साथ 'were' का प्रयोग होता है।"
                },
                {
                    english: "Main Verb: Always use V1 + ing (Base form + ing).",
                    hindi: "मुख्य क्रिया: हमेशा V1 + ing (जैसे: working, reading, playing, studying) का प्रयोग किया जाता है।"
                },
                {
                    english: "Interrupted Actions: Frequently paired with Simple Past using 'when' and 'while'.",
                    hindi: "किसी अन्य कार्य से बाधित होने वाले कार्यों के लिए 'when' और 'while' का प्रयोग होता है।"
                }
            ],
            comparison: {
                title: "Concept Comparison: Past Continuous vs Other Tenses",
                simplePast: {
                    name: "Simple Past (सामान्य भूतकाल)",
                    formula: "Subject + V2 + Object",
                    concept: "भूतकाल में समाप्त हुआ कार्य (किया / गया / देखा)",
                    example: "I watched a movie yesterday. (मैंने कल एक फिल्म देखी।)"
                },
                pastContinuous: {
                    name: "Past Continuous (अपूर्ण भूतकाल)",
                    formula: "Subject + was/were + V1+ing + Object",
                    concept: "अतीत में किसी समय जारी कार्य (रहा था / रही थी)",
                    example: "I was watching a movie at 8 PM. (मैं 8 बजे फिल्म देख रहा था।)"
                },
                presentContinuous: {
                    name: "Present Continuous (अपूर्ण वर्तमान)",
                    formula: "Subject + am/is/are + V1+ing + Object",
                    concept: "वर्तमान समय में चल रहा कार्य (रहा है / रही है)",
                    example: "I am watching a movie right now. (मैं अभी फिल्म देख रहा हूँ।)"
                }
            }
        },

        // 2. Uses & Scenarios / उपयोग और परिस्थितियाँ
        uses: {
            title: "Uses & Scenarios",
            titleHindi: "कब प्रयोग करें (5 मुख्य उपयोग)",
            intro: "Past Continuous Tense is used to set past scenes, show interrupted actions, describe parallel events, and detail past habits.",
            introHindi: "Past Continuous Tense का प्रयोग अतीत की जारी गतिविधियों, एक साथ हो रहे कार्यों और बाधित घटनाओं को बताने के लिए किया जाता है।",
            list: [
                {
                    title: "1. Action in Progress at a Specific Past Time",
                    titleHindi: "भूतकाल के निश्चित समय पर जारी कार्य",
                    explanation: "Used to describe an action that was actively taking place at a exact past time point.",
                    explanationHindi: "अतीत में किसी सटीक समय पर चल रहे कार्य का वर्णन करने के लिए।",
                    whyUsed: "Focuses on the duration and continuation of the action at that past moment.",
                    whyUsedHindi: "उस अतीत के क्षण में कार्य की निरंतरता पर ध्यान केंद्रित करता है।",
                    examples: [
                        { english: "At 7 PM yesterday, I was studying in my room.", hindi: "कल शाम 7 बजे मैं अपने कमरे में पढ़ रहा था।", note: "Specific time: 7 PM yesterday" },
                        { english: "They were playing football at 4 o'clock.", hindi: "वे 4 बजे फुटबॉल खेल रहे थे।", note: "Specific time: at 4 o'clock" },
                        { english: "She was cooking dinner when midnight struck.", hindi: "आधी रात होने पर वह रात का खाना बना रही थी।", note: "Ongoing at specific time" }
                    ]
                },
                {
                    title: "2. Action Interrupted by Another Event (When)",
                    titleHindi: "किसी अन्य कार्य के होने से बाधित कार्य (When)",
                    explanation: "An ongoing past action (Past Continuous) interrupted by a shorter completed event (Simple Past).",
                    explanationHindi: "अतीत में चल रहा लंबा कार्य जो किसी छोटे कार्य (Simple Past) के घटित होने से बाधित हुआ।",
                    whyUsed: "Shows background action vs interrupting action.",
                    whyUsedHindi: "पृष्ठभूमि कार्य और उसमें आई बाधा का संबंध दिखाता है।",
                    examples: [
                        { english: "I was sleeping when the telephone rang.", hindi: "जब टेलीफोन बजा तब मैं सो रहा था।", note: "Background: was sleeping | Interrupting: rang" },
                        { english: "She was walking home when it started raining.", hindi: "जब बारिश शुरू हुई तब वह घर पैदल जा रही थी।", note: "Background: was walking | Interrupting: started" },
                        { english: "They were having dinner when guests arrived.", hindi: "जब मेहमान आए तब वे रात का खाना खा रहे थे।", note: "Background: were having | Interrupting: arrived" }
                    ]
                },
                {
                    title: "3. Parallel Actions Happening Simultaneously (While)",
                    titleHindi: "एक ही समय पर साथ-साथ चल रहे दो कार्य (While)",
                    explanation: "Two or more past actions taking place at the exact same time.",
                    explanationHindi: "अतीत में एक ही समय पर साथ-साथ जारी दो या दो से अधिक कार्य।",
                    whyUsed: "Demonstrates concurrent simultaneous progress.",
                    whyUsedHindi: "एक ही समय में दो निरंतर गतिविधियों को दिखाता है।",
                    examples: [
                        { english: "While I was studying, my brother was playing video games.", hindi: "जब मैं पढ़ रहा था, तब मेरा भाई वीडियो गेम खेल रहा था।", note: "Parallel: was studying / was playing" },
                        { english: "Mother was cooking while father was reading the newspaper.", hindi: "मां खाना बना रही थीं जबकि पिता समाचार पत्र पढ़ रहे थे।", note: "Parallel: was cooking / was reading" },
                        { english: "The children were laughing while the teacher was drawing.", hindi: "जब शिक्षक चित्र बना रहे थे तब बच्चे हंस रहे थे।", note: "Parallel actions with while" }
                    ]
                },
                {
                    title: "4. Temporary Situation in the Past",
                    titleHindi: "अतीत की अस्थायी स्थिति या गतिविधि",
                    explanation: "Describes a temporary state or habit that was in progress during a limited past period.",
                    explanationHindi: "अतीत की ऐसी अस्थायी आदत या स्थिति जो एक सीमित अवधि के दौरान जारी थी।",
                    whyUsed: "Emphasizes the non-permanent nature of the past situation.",
                    whyUsedHindi: "अतीत की स्थिति के अस्थायी होने पर बल देता है।",
                    examples: [
                        { english: "He was staying with his uncle during that summer.", hindi: "वह उस गर्मी के दौरान अपने चाचा के साथ रह रहा था।", note: "Temporary past stay" },
                        { english: "I was working on a temporary project last month.", hindi: "मैं पिछले महीने एक अस्थायी प्रोजेक्ट पर काम कर रहा था।", note: "Temporary monthly task" },
                        { english: "They were living in a rented house in 2020.", hindi: "वे 2020 में किराए के मकान में रह रहे थे।", note: "Temporary living situation" }
                    ]
                },
                {
                    title: "5. Background Scene Description in Stories",
                    titleHindi: "कहानी या घटना का पृष्ठभूमि विवरण (Setting the Scene)",
                    explanation: "Used at the beginning of a narrative to set the atmosphere or describe background events.",
                    explanationHindi: "किसी कहानी या घटना की शुरुआत में माहौल या पृष्ठभूमि का वर्णन करने के लिए।",
                    whyUsed: "Creates visual imagery and atmosphere for the listener.",
                    whyUsedHindi: "श्रोता के लिए दृश्य और माहौल तैयार करता है।",
                    examples: [
                        { english: "The sun was setting and the birds were singing in the trees.", hindi: "सूरज ढल रहा था और पक्षी पेड़ों पर गा रहे थे।", note: "Atmospheric setting" },
                        { english: "It was raining heavily and wind was blowing through the valley.", hindi: "तेज बारिश हो रही थी और घाटी में हवा चल रही थी।", note: "Weather background" },
                        { english: "People were rushing to work and sirens were sounding.", hindi: "लोग काम पर भाग रहे थे और सायरन बज रहे थे।", note: "City background scene" }
                    ]
                }
            ]
        },

        // 3. Structure & Formulas / वाक्य संरचना एवं सूत्र
        structure: {
            title: "Structure & Formulas",
            titleHindi: "वाक्य संरचना एवं सूत्र (Formulas)",
            simpleHindiOverview: "Past Continuous में Subject के अनुसार Auxiliary Verb 'was' या 'were' का प्रयोग होता है और Main Verb में हमेशा 'V1 + ing' जोड़ा जाता है।",
            mainFormula: "Positive: Subject + was/were + V1+ing + Object | Negative: Subject + was/were + not + V1+ing",
            
            auxiliaryMapping: [
                {
                    subjectGroup: "Group 1: Singular Subjects (I / He / She / It / Singular Name)",
                    auxiliary: "was + V1+ing",
                    formula: "I / He / She / It / Singular + was + V1+ing",
                    hindiRule: "I, He, She, It और एकवचन कर्ता के साथ 'was + V1+ing' का प्रयोग होता है। (जैसे: She was working.)"
                },
                {
                    subjectGroup: "Group 2: Plural Subjects (You / We / They / Plural Nouns)",
                    auxiliary: "were + V1+ing",
                    formula: "You / We / They / Plural + were + V1+ing",
                    hindiRule: "You, We, They और बहुवचन कर्ता के साथ 'were + V1+ing' का प्रयोग होता है। (जैसे: They were playing.)"
                }
            ],

            v4Explanation: {
                title: "Main Verb Form: V1 + ing (V4)",
                titleHindi: "मुख्य क्रिया का रूप: V1 + ing",
                ruleText: "Main Verb = Base Form (V1) + ing",
                explanationHindi: "Past Continuous में was/were के बाद हमेशा Verb में -ing जोड़ा जाता है। V2 या V3 का प्रयोग न करें।",
                examples: [
                    { base: "play", v4: "playing" },
                    { base: "work", v4: "working" },
                    { base: "read", v4: "reading" },
                    { base: "write", v4: "writing" },
                    { base: "run", v4: "running" },
                    { base: "sleep", v4: "sleeping" }
                ]
            },

            formulaBlocks: [
                {
                    type: "positive",
                    title: "1. Positive Sentence (सकारात्मक वाक्य)",
                    formula: "Subject + was / were + V1+ing + Object / Complement",
                    englishExplanation: "Use 'was' for singular subjects and 'were' for plural subjects + V1+ing.",
                    hindiExplanation: "सकारात्मक वाक्य में कर्ता के अनुसार was/were लगाएं और क्रिया में -ing जोड़ें।",
                    examples: [
                        {
                            english: "She was reading a book.",
                            hindi: "वह एक किताब पढ़ रही थी।",
                            breakdown: { subject: "She", aux: "was", mainVerb: "reading (V1+ing)", object: "a book" }
                        },
                        {
                            english: "They were playing cricket.",
                            hindi: "वे क्रिकेट खेल रहे थे।",
                            breakdown: { subject: "They", aux: "were", mainVerb: "playing (V1+ing)", object: "cricket" }
                        }
                    ]
                },
                {
                    type: "negative",
                    title: "2. Negative Sentence (नकारात्मक वाक्य)",
                    formula: "Subject + was / were + not (wasn't / weren't) + V1+ing + Object",
                    englishExplanation: "Add 'not' after was/were (wasn't / weren't), followed by V1+ing.",
                    hindiExplanation: "नकारात्मक वाक्य में was/were के बाद 'not' (wasn't / weren't) लगाएं और फिर V1+ing रखें।",
                    examples: [
                        {
                            english: "She was not reading a book.",
                            hindi: "वह किताब नहीं पढ़ रही थी।",
                            breakdown: { subject: "She", aux: "was", not: "not", mainVerb: "reading (V1+ing)", object: "a book" }
                        },
                        {
                            english: "They weren't playing cricket.",
                            hindi: "वे क्रिकेट नहीं खेल रहे थे।",
                            breakdown: { subject: "They", aux: "weren't", mainVerb: "playing (V1+ing)", object: "cricket" }
                        }
                    ]
                },
                {
                    type: "interrogative",
                    title: "3. Interrogative Sentence (Yes/No Questions)",
                    formula: "Was / Were + Subject + V1+ing + Object / Complement?",
                    englishExplanation: "Place 'Was' or 'Were' before the Subject, followed by V1+ing.",
                    hindiExplanation: "प्रश्नवाचक वाक्य में सबसे पहले Was/Were रखें, फिर Subject और फिर V1+ing।",
                    examples: [
                        {
                            english: "Was she reading a book?",
                            hindi: "क्या वह किताब पढ़ रही थी?",
                            breakdown: { aux: "Was", subject: "she", mainVerb: "reading (V1+ing)", object: "a book?" }
                        },
                        {
                            english: "Were they playing cricket?",
                            hindi: "क्या वे क्रिकेट खेल रहे थे?",
                            breakdown: { aux: "Were", subject: "they", mainVerb: "playing (V1+ing)", object: "cricket?" }
                        }
                    ]
                },
                {
                    type: "whQuestions",
                    title: "4. WH Question (Information Questions)",
                    formula: "WH-word + was / were + Subject + V1+ing + Object?",
                    englishExplanation: "Place WH-word at the beginning, followed by was/were + Subject + V1+ing.",
                    hindiExplanation: "WH प्रश्न में सबसे पहले WH शब्द, फिर was/were, फिर Subject और V1+ing रखें।",
                    examples: [
                        {
                            english: "What was she reading?",
                            hindi: "वह क्या पढ़ रही थी?",
                            breakdown: { wh: "What", aux: "was", subject: "she", mainVerb: "reading (V1+ing)?" }
                        },
                        {
                            english: "Where were they playing cricket?",
                            hindi: "वे कहाँ क्रिकेट खेल रहे थे?",
                            breakdown: { wh: "Where", aux: "were", subject: "they", mainVerb: "playing (V1+ing)", object: "cricket?" }
                        }
                    ]
                }
            ]
        },

        // 4. Subject + Verb Rules / कर्ता और क्रिया के नियम
        subjectVerbRules: {
            title: "Subject + Verb Rules",
            titleHindi: "कर्ता एवं सहायक क्रिया के नियम (Was vs Were Guide)",
            
            auxiliaryMapping: [
                {
                    subjectGroup: "Singular Subjects: I / He / She / It / Singular Name",
                    auxiliary: "was + V1+ing",
                    formula: "I / He / She / It / Singular + was + V1+ing",
                    hindiRule: "I, He, She, It और किसी भी एकवचन कर्ता के साथ 'was' + V1+ing लगाएं। (जैसे: I was sleeping.)"
                },
                {
                    subjectGroup: "Plural Subjects: You / We / They / Plural Nouns",
                    auxiliary: "were + V1+ing",
                    formula: "You / We / They / Plural + were + V1+ing",
                    hindiRule: "You, We, They और किसी भी बहुवचन कर्ता के साथ 'were' + V1+ing लगाएं। (जैसे: You were talking.)"
                }
            ],

            v4Explanation: {
                title: "V1+ing Spelling Rules Guide",
                titleHindi: "Verb में -ing जोड़ने के 4 स्पेलिंग नियम",
                ruleText: "Base Verb + ing",
                explanationHindi: "क्रिया में -ing जोड़ते समय स्पेलिंग के इन 4 नियमों का ध्यान रखें:",
                examples: [
                    { base: "play", v4: "playing (Normal)" },
                    { base: "make", v4: "making (Drop silent -e)" },
                    { base: "run", v4: "running (Double consonant)" },
                    { base: "die", v4: "dying (-ie ➔ -y)" }
                ]
            },

            spellingRulesIng: [
                {
                    condition: "1. Normal Verbs (सामान्य क्रियाएं)",
                    rule: "Add -ing directly to base verb",
                    examples: "play ➔ playing, work ➔ working, read ➔ reading, study ➔ studying"
                },
                {
                    condition: "2. Verbs ending in silent '-e'",
                    rule: "Drop '-e' and add -ing",
                    examples: "make ➔ making, write ➔ writing, come ➔ coming, live ➔ living"
                },
                {
                    condition: "3. Short Vowel + Single Consonant",
                    rule: "Double the final consonant and add -ing",
                    examples: "run ➔ running, sit ➔ sitting, stop ➔ stopping, swim ➔ swimming"
                },
                {
                    condition: "4. Verbs ending in '-ie'",
                    rule: "Change '-ie' to '-y' and add -ing",
                    examples: "die ➔ dying, lie ➔ lying, tie ➔ tying"
                }
            ]
        },

        // 5. Positive Sentences / सकारात्मक वाक्य (30 Items)
        positive: {
            title: "Positive / Affirmative Sentences",
            titleHindi: "सकारात्मक वाक्य (Subject + was/were + V1+ing)",
            formulaPlural: "You / We / They / Plural + were + V1+ing + Object",
            formulaSingular: "I / He / She / It / Singular + was + V1+ing + Object",
            explanation: "Use 'was' for singular subjects and 'were' for plural subjects, followed by V1+ing.",
            explanationHindi: "एकवचन कर्ताओं (I, He, She, It) के साथ was और बहुवचन कर्ताओं (You, We, They) के साथ were + V1+ing लगाएं।",
            
            sentences: {
                easy: [
                    { id: "pos-e1", english: "I was studying for my exam.", hindi: "मैं अपनी परीक्षा के लिए पढ़ रहा था।", subject: "I", aux: "was", verb: "studying", object: "for my exam" },
                    { id: "pos-e2", english: "She was cooking dinner in the kitchen.", hindi: "वह रसोई में खाना बना रही थी।", subject: "She", aux: "was", verb: "cooking", object: "dinner in the kitchen" },
                    { id: "pos-e3", english: "They were playing football in the garden.", hindi: "वे बगीचे में फुटबॉल खेल रहे थे।", subject: "They", aux: "were", verb: "playing", object: "football in garden" },
                    { id: "pos-e4", english: "We were watching a movie at 8 PM.", hindi: "हम रात 8 बजे फिल्म देख रहे थे।", subject: "We", aux: "were", verb: "watching", object: "a movie at 8 PM" },
                    { id: "pos-e5", english: "He was writing an email to his teacher.", hindi: "वह अपने शिक्षक को एक ईमेल लिख रहा था।", subject: "He", aux: "was", verb: "writing", object: "an email to teacher" },
                    { id: "pos-e6", english: "Rahul was waiting at the bus stop.", hindi: "राहुल बस स्टॉप पर इंतज़ार कर रहा था।", subject: "Rahul", aux: "was", verb: "waiting", object: "at the bus stop" },
                    { id: "pos-e7", english: "You were talking on the phone.", hindi: "आप फोन पर बात कर रहे थे।", subject: "You", aux: "were", verb: "talking", object: "on the phone" },
                    { id: "pos-e8", english: "It was raining heavily yesterday evening.", hindi: "कल शाम बहुत तेज बारिश हो रही थी।", subject: "It", aux: "was", verb: "raining", object: "heavily yesterday evening" },
                    { id: "pos-e9", english: "The baby was sleeping peacefully.", hindi: "बच्चा शांति से सो रहा था।", subject: "The baby", aux: "was", verb: "sleeping", object: "peacefully" },
                    { id: "pos-e10", english: "Birds were singing in the trees.", hindi: "पेड़ों पर पक्षी चहक रहे थे।", subject: "Birds", aux: "were", verb: "singing", object: "in the trees" }
                ],
                medium: [
                    { id: "pos-m1", english: "My father was repairing his car in the garage.", hindi: "मेरे पिता गैरेज में अपनी कार की मरम्मत कर रहे थे।", subject: "My father", aux: "was", verb: "repairing", object: "his car in garage" },
                    { id: "pos-m2", english: "She was practicing piano for two hours.", hindi: "वह दो घंटे से पियानो का अभ्यास कर रही थी।", subject: "She", aux: "was", verb: "practicing", object: "piano for two hours" },
                    { id: "pos-m3", english: "The doctor was examining patients in the clinic.", hindi: "डॉक्टर क्लिनिक में मरीजों की जांच कर रहे थे।", subject: "The doctor", aux: "was", verb: "examining", object: "patients in clinic" },
                    { id: "pos-m4", english: "We were traveling by train to Jaipur.", hindi: "हम ट्रेन से जयपुर की यात्रा कर रहे थे।", subject: "We", aux: "were", verb: "traveling", object: "by train to Jaipur" },
                    { id: "pos-m5", english: "He was painting the room wall green.", hindi: "वह कमरे की दीवार को हरे रंग से पेंट कर रहा था।", subject: "He", aux: "was", verb: "painting", object: "the room wall green" },
                    { id: "pos-m6", english: "The students were listening attentively to the lecture.", hindi: "छात्र व्याख्यान को ध्यान से सुन रहे थे।", subject: "The students", aux: "were", verb: "listening", object: "attentively to lecture" },
                    { id: "pos-m7", english: "Workers were constructing the new bridge.", hindi: "मजदूर नए पुल का निर्माण कर रहे थे।", subject: "Workers", aux: "were", verb: "constructing", object: "the new bridge" },
                    { id: "pos-m8", english: "She was driving carefully through the fog.", hindi: "वह कोहरे के बीच सावधानी से गाड़ी चला रही थी।", subject: "She", aux: "was", verb: "driving", object: "carefully through fog" },
                    { id: "pos-m9", english: "The chef was preparing gourmet dishes.", hindi: "शेफ स्वादिष्ट व्यंजन तैयार कर रहा था।", subject: "The chef", aux: "was", verb: "preparing", object: "gourmet dishes" },
                    { id: "pos-m10", english: "I was cleaning my room when you called.", hindi: "जब आपने फोन किया तब मैं अपना कमरा साफ कर रहा था।", subject: "I", aux: "was", verb: "cleaning", object: "my room when you called" }
                ],
                hard: [
                    { id: "pos-h1", english: "Engineers were inspecting the power grid infrastructure overnight.", hindi: "इंजीनियर रात भर पावर ग्रिड इंफ्रास्ट्रक्चर का निरीक्षण कर रहे थे।", subject: "Engineers", aux: "were", verb: "inspecting", object: "power grid infrastructure" },
                    { id: "pos-h2", english: "The research team was analyzing satellite atmospheric data.", hindi: "शोध टीम उपग्रह वायुमंडलीय आंकड़ों का विश्लेषण कर रही थी।", subject: "Research team", aux: "was", verb: "analyzing", object: "satellite atmospheric data" },
                    { id: "pos-h3", english: "Financial analysts were forecasting market trends for the company.", hindi: "वित्तीय विश्लेषक कंपनी के लिए बाजार के रुझानों का पूर्वानुमान लगा रहे थे।", subject: "Financial analysts", aux: "were", verb: "forecasting", object: "market trends for company" },
                    { id: "pos-h4", english: "The municipality was upgrading the city water pipeline.", hindi: "नगरपालिका शहर की जल पाइपलाइन को अपग्रेड कर रही थी।", subject: "The municipality", aux: "was", verb: "upgrading", object: "city water pipeline" },
                    { id: "pos-h5", english: "Legal advisors were reviewing complex contract clauses all afternoon.", hindi: "कानूनी सलाहकार पूरी दोपहर जटिल अनुबंध धाराओं की समीक्षा कर रहे थे।", subject: "Legal advisors", aux: "were", verb: "reviewing", object: "complex contract clauses" },
                    { id: "pos-h6", english: "Scientists were monitoring seismic activity near the fault line.", hindi: "वैज्ञानिक फॉल्ट लाइन के पास भूकंपीय गतिविधि की निगरानी कर रहे थे।", subject: "Scientists", aux: "were", verb: "monitoring", object: "seismic activity" },
                    { id: "pos-h7", english: "The committee was drafting new environmental guidelines.", hindi: "समिति नए पर्यावरण दिशानिर्देशों का मसौदा तैयार कर रही थी।", subject: "The committee", aux: "was", verb: "drafting", object: "environmental guidelines" },
                    { id: "pos-h8", english: "Heavy storm was damaging agricultural crops across the district.", hindi: "तेज तूफान पूरे जिले में कृषि फसलों को नुकसान पहुंचा रहा था।", subject: "Heavy storm", aux: "was", verb: "damaging", object: "agricultural crops" },
                    { id: "pos-h9", english: "Medical staff were coordinating emergency relief operations.", hindi: "चिकित्सा कर्मचारी आपातकालीन राहत कार्यों का समन्वय कर रहे थे।", subject: "Medical staff", aux: "were", verb: "coordinating", object: "emergency relief operations" },
                    { id: "pos-h10", english: "Software developers were debugging the cloud database system.", hindi: "सॉफ्टवेयर डेवलपर्स क्लाउड डेटाबेस सिस्टम को डिबग कर रहे थे।", subject: "Software developers", aux: "were", verb: "debugging", object: "cloud database system" }
                ]
            }
        },

        // 6. Negative Sentences / नकारात्मक वाक्य (30 Items)
        negative: {
            title: "Negative Sentences",
            titleHindi: "नकारात्मक वाक्य (Subject + was/were + not + V1+ing)",
            formulaPlural: "You / We / They / Plural + were not (weren't) + V1+ing",
            formulaSingular: "I / He / She / It / Singular + was not (wasn't) + V1+ing",
            explanation: "Add 'not' after was/were (wasn't / weren't) to form negative Past Continuous sentences.",
            explanationHindi: "नकारात्मक वाक्यों में was/were के बाद 'not' (wasn't / weren't) लगाएं और V1+ing रखें।",
            
            sentences: {
                easy: [
                    { id: "neg-e1", english: "I was not sleeping when you called.", hindi: "जब आपने फोन किया तब मैं सो नहीं रहा था।", subject: "I", aux: "was not", verb: "sleeping", object: "when you called" },
                    { id: "neg-e2", english: "She wasn't working in the office.", hindi: "वह दफ्तर में काम नहीं कर रही थी।", subject: "She", aux: "wasn't", verb: "working", object: "in the office" },
                    { id: "neg-e3", english: "They were not playing cricket yesterday.", hindi: "वे कल क्रिकेट नहीं खेल रहे थे।", subject: "They", aux: "were not", verb: "playing", object: "cricket yesterday" },
                    { id: "neg-e4", english: "We weren't watching television at that time.", hindi: "हम उस समय टीवी नहीं देख रहे थे।", subject: "We", aux: "weren't", verb: "watching", object: "television at that time" },
                    { id: "neg-e5", english: "He was not writing the report.", hindi: "वह रिपोर्ट नहीं लिख रहा था।", subject: "He", aux: "was not", verb: "writing", object: "the report" },
                    { id: "neg-e6", english: "Rahul wasn't listening to the instructions.", hindi: "राहुल निर्देशों को नहीं सुन रहा था।", subject: "Rahul", aux: "wasn't", verb: "listening", object: "to the instructions" },
                    { id: "neg-e7", english: "You were not paying attention.", hindi: "आप ध्यान नहीं दे रहे थे।", subject: "You", aux: "were not", verb: "paying", object: "attention" },
                    { id: "neg-e8", english: "It wasn't raining when we left.", hindi: "जब हम निकले तब बारिश नहीं हो रही थी।", subject: "It", aux: "wasn't", verb: "raining", object: "when we left" },
                    { id: "neg-e9", english: "She was not feeling well yesterday.", hindi: "कल उसकी तबीयत ठीक नहीं लग रही थी।", subject: "She", aux: "was not", verb: "feeling", object: "well yesterday" },
                    { id: "neg-e10", english: "They weren't making any noise.", hindi: "वे कोई शोर नहीं मचा रहे थे।", subject: "They", aux: "weren't", verb: "making", object: "any noise" }
                ],
                medium: [
                    { id: "neg-m1", english: "My father was not driving the car fast.", hindi: "मेरे पिता कार तेज नहीं चला रहे थे।", subject: "My father", aux: "was not", verb: "driving", object: "the car fast" },
                    { id: "neg-m2", english: "She wasn't using her phone during class.", hindi: "वह कक्षा के दौरान अपने फोन का उपयोग नहीं कर रही थी।", subject: "She", aux: "wasn't", verb: "using", object: "phone during class" },
                    { id: "neg-m3", english: "The doctor was not operating on the patient.", hindi: "डॉक्टर मरीज का ऑपरेशन नहीं कर रहे थे।", subject: "The doctor", aux: "was not", verb: "operating", object: "on the patient" },
                    { id: "neg-m4", english: "We weren't staying in a hotel that week.", hindi: "हम उस हफ्ते होटल में नहीं ठहर रहे थे।", subject: "We", aux: "weren't", verb: "staying", object: "in a hotel that week" },
                    { id: "neg-m5", english: "He was not complaining about the work.", hindi: "वह काम की शिकायत नहीं कर रहा था।", subject: "He", aux: "was not", verb: "complaining", object: "about the work" },
                    { id: "neg-m6", english: "The team wasn't practicing hard enough.", hindi: "टीम पर्याप्त मेहनत से अभ्यास नहीं कर रही थी।", subject: "The team", aux: "wasn't", verb: "practicing", object: "hard enough" },
                    { id: "neg-m7", english: "They were not expecting any guests.", hindi: "वे किसी मेहमान की उम्मीद नहीं कर रहे थे।", subject: "They", aux: "were not", verb: "expecting", object: "any guests" },
                    { id: "neg-m8", english: "She wasn't wearing her glasses yesterday.", hindi: "वह कल अपना चश्मा नहीं पहने हुए थी।", subject: "She", aux: "wasn't", verb: "wearing", object: "her glasses yesterday" },
                    { id: "neg-m9", english: "The student was not copying during the exam.", hindi: "छात्र परीक्षा के दौरान नकल नहीं कर रहा था।", subject: "The student", aux: "was not", verb: "copying", object: "during the exam" },
                    { id: "neg-m10", english: "I wasn't hiding anything from you.", hindi: "मैं आपसे कुछ भी नहीं छिपा रहा था।", subject: "I", aux: "wasn't", verb: "hiding", object: "anything from you" }
                ],
                hard: [
                    { id: "neg-h1", english: "The management was not violating safety regulations.", hindi: "प्रबंधन सुरक्षा नियमों का उल्लंघन नहीं कर रहा था।", subject: "Management", aux: "was not", verb: "violating", object: "safety regulations" },
                    { id: "neg-h2", english: "The board wasn't considering any merger proposals.", hindi: "बोर्ड किसी विलय प्रस्ताव पर विचार नहीं कर रहा था।", subject: "The board", aux: "wasn't", verb: "considering", object: "merger proposals" },
                    { id: "neg-h3", english: "Engineers were not ignoring structural warning signs.", hindi: "इंजीनियर संरचनात्मक चेतावनी संकेतों की उपेक्षा नहीं कर रहे थे।", subject: "Engineers", aux: "were not", verb: "ignoring", object: "warning signs" },
                    { id: "neg-h4", english: "The authority wasn't misusing public development funds.", hindi: "प्राधिकरण सार्वजनिक विकास कोष का दुरुपयोग नहीं कर रहा था।", subject: "The authority", aux: "wasn't", verb: "misusing", object: "development funds" },
                    { id: "neg-h5", english: "Researchers were not publishing unverified clinical data.", hindi: "शोधकर्ता असत्यापित नैदानिक डेटा प्रकाशित नहीं कर रहे थे।", subject: "Researchers", aux: "were not", verb: "publishing", object: "unverified clinical data" },
                    { id: "neg-h6", english: "The system wasn't malfunctioning during peak traffic hours.", hindi: "पीक ट्रैफ़िक आवर्स के दौरान सिस्टम खराब नहीं हो रहा था।", subject: "The system", aux: "wasn't", verb: "malfunctioning", object: "during peak hours" },
                    { id: "neg-h7", english: "The court was not delaying the legal hearing.", hindi: "अदालत कानूनी सुनवाई में देरी नहीं कर रही थी।", subject: "The court", aux: "was not", verb: "delaying", object: "the legal hearing" },
                    { id: "neg-h8", english: "Technicians weren't interrupting server operations.", hindi: "तकनीशियन सर्वर संचालन में बाधा नहीं डाल रहे थे।", subject: "Technicians", aux: "weren't", verb: "interrupting", object: "server operations" },
                    { id: "neg-h9", english: "The audit team was not overlooking accounting discrepancies.", hindi: "ऑडिट टीम खातों की विसंगतियों को नजरअंदाज नहीं कर रही थी।", subject: "Audit team", aux: "was not", verb: "overlooking", object: "accounting discrepancies" },
                    { id: "neg-h10", english: "Delegates weren't arguing during the summit meeting.", hindi: "शिखर सम्मेलन की बैठक के दौरान प्रतिनिधि बहस नहीं कर रहे थे।", subject: "Delegates", aux: "weren't", verb: "arguing", object: "during summit meeting" }
                ]
            }
        },

        // 7. Interrogative Sentences / प्रश्नवाचक वाक्य (30 Items)
        interrogative: {
            title: "Interrogative Sentences",
            titleHindi: "प्रश्नवाचक वाक्य (Was/Were + Subject + V1+ing?)",
            formula: "Was / Were + Subject + V1+ing + Object?",
            explanation: "Start Yes/No questions with 'Was' (singular) or 'Were' (plural), followed by Subject and V1+ing.",
            explanationHindi: "प्रश्नवाचक वाक्य में कर्ता के अनुसार सबसे पहले Was/Were रखें, फिर Subject और V1+ing।",
            
            sentences: {
                easy: [
                    { id: "int-e1", english: "Was I sleeping when you arrived?", hindi: "जब आप पहुंचे क्या मैं सो रहा था?", subject: "I", aux: "Was", verb: "sleeping", object: "when you arrived?" },
                    { id: "int-e2", english: "Was she cooking dinner in the kitchen?", hindi: "क्या वह रसोई में खाना बना रही थी?", subject: "she", aux: "Was", verb: "cooking", object: "dinner in the kitchen?" },
                    { id: "int-e3", english: "Were they playing football yesterday?", hindi: "क्या वे कल फुटबॉल खेल रहे थे?", subject: "they", aux: "Were", verb: "playing", object: "football yesterday?" },
                    { id: "int-e4", english: "Were you watching the cricket match?", hindi: "क्या आप क्रिकेट मैच देख रहे थे?", subject: "you", aux: "Were", verb: "watching", object: "the cricket match?" },
                    { id: "int-e5", english: "Was he writing an essay?", hindi: "क्या वह एक निबंध लिख रहा था?", subject: "he", aux: "Was", verb: "writing", object: "an essay?" },
                    { id: "int-e6", english: "Was Rahul waiting for the train?", hindi: "क्या राहुल ट्रेन का इंतज़ार कर रहा था?", subject: "Rahul", aux: "Was", verb: "waiting", object: "for the train?" },
                    { id: "int-e7", english: "Were we disturbing your study?", hindi: "क्या हम आपकी पढ़ाई में बाधा डाल रहे थे?", subject: "we", aux: "Were", verb: "disturbing", object: "your study?" },
                    { id: "int-e8", english: "Was it raining heavily when you left?", hindi: "जब आप निकले क्या तेज बारिश हो रही थी?", subject: "it", aux: "Was", verb: "raining", object: "heavily when you left?" },
                    { id: "int-e9", english: "Was she feeling cold in the room?", hindi: "क्या उसे कमरे में ठंड लग रही थी?", subject: "she", aux: "Was", verb: "feeling", object: "cold in the room?" },
                    { id: "int-e10", english: "Were they talking about the exam?", hindi: "क्या वे परीक्षा के बारे में बात कर रहे थे?", subject: "they", aux: "Were", verb: "talking", object: "about the exam?" }
                ],
                medium: [
                    { id: "int-m1", english: "Was your father repairing the garden fence?", hindi: "क्या आपके पिता बगीचे की बाड़ की मरम्मत कर रहे थे?", subject: "your father", aux: "Was", verb: "repairing", object: "the garden fence?" },
                    { id: "int-m2", english: "Was she practicing dance for the function?", hindi: "क्या वह समारोह के लिए नृत्य का अभ्यास कर रही थी?", subject: "she", aux: "Was", verb: "practicing", object: "dance for function?" },
                    { id: "int-m3", english: "Was the doctor checking patient records?", hindi: "क्या डॉक्टर मरीज के रिकॉर्ड की जांच कर रहे थे?", subject: "the doctor", aux: "Was", verb: "checking", object: "patient records?" },
                    { id: "int-m4", english: "Were you traveling to Mumbai last week?", hindi: "क्या आप पिछले हफ्ते मुंबई की यात्रा कर रहे थे?", subject: "you", aux: "Were", verb: "traveling", object: "to Mumbai last week?" },
                    { id: "int-m5", english: "Was he painting the office wall?", hindi: "क्या वह दफ्तर की दीवार पेंट कर रहा था?", subject: "he", aux: "Was", verb: "painting", object: "the office wall?" },
                    { id: "int-m6", english: "Were the students preparing for the test?", hindi: "क्या छात्र टेस्ट की तैयारी कर रहे थे?", subject: "the students", aux: "Were", verb: "preparing", object: "for the test?" },
                    { id: "int-m7", english: "Were they renovating the old house?", hindi: "क्या वे पुराने मकान का नवीनीकरण कर रहे थे?", subject: "they", aux: "Were", verb: "renovating", object: "the old house?" },
                    { id: "int-m8", english: "Was she driving when the phone rang?", hindi: "जब फोन बजा क्या वह गाड़ी चला रही थी?", subject: "she", aux: "Was", verb: "driving", object: "when phone rang?" },
                    { id: "int-m9", english: "Was the manager addressing the employees?", hindi: "क्या प्रबंधक कर्मचारियों को संबोधित कर रहे थे?", subject: "the manager", aux: "Was", verb: "addressing", object: "the employees?" },
                    { id: "int-m10", english: "Were you listening to music during work?", hindi: "क्या आप काम के दौरान संगीत सुन रहे थे?", subject: "you", aux: "Were", verb: "listening", object: "to music during work?" }
                ],
                hard: [
                    { id: "int-h1", english: "Was the committee reviewing environmental policies?", hindi: "क्या समिति पर्यावरण नीतियों की समीक्षा कर रही थी?", subject: "the committee", aux: "Was", verb: "reviewing", object: "environmental policies?" },
                    { id: "int-h2", english: "Were researchers analyzing climate pattern models?", hindi: "क्या शोधकर्ता जलवायु पैटर्न मॉडल का विश्लेषण कर रहे थे?", subject: "researchers", aux: "Were", verb: "analyzing", object: "climate pattern models?" },
                    { id: "int-h3", english: "Was the government implementing new tax regulations?", hindi: "क्या सरकार नए कर नियमों को लागू कर रही थी?", subject: "the government", aux: "Was", verb: "implementing", object: "new tax regulations?" },
                    { id: "int-h4", english: "Were scientists monitoring the volcanic activity?", hindi: "क्या वैज्ञानिक ज्वालामुखी गतिविधि की निगरानी कर रहे थे?", subject: "scientists", aux: "Were", verb: "monitoring", object: "volcanic activity?" },
                    { id: "int-h5", english: "Was the court evaluating additional prosecution evidence?", hindi: "क्या अदालत अतिरिक्त अभियोजन साक्ष्य का मूल्यांकन कर रही थी?", subject: "the court", aux: "Was", verb: "evaluating", object: "prosecution evidence?" },
                    { id: "int-h6", english: "Were auditors inspecting corporate account ledgers?", hindi: "क्या ऑडिटर कॉर्पोरेट खाता बही का निरीक्षण कर रहे थे?", subject: "auditors", aux: "Were", verb: "inspecting", object: "corporate ledgers?" },
                    { id: "int-h7", english: "Was the municipality clearing clogged drainage channels?", hindi: "क्या नगरपालिका जाम जल निकासी चैनलों की सफाई कर रही थी?", subject: "the municipality", aux: "Was", verb: "clearing", object: "clogged channels?" },
                    { id: "int-h8", english: "Were technicians replacing damaged transmission lines?", hindi: "क्या तकनीशियन क्षतिग्रस्त ट्रांसमिशन लाइनों को बदल रहे थे?", subject: "technicians", aux: "Were", verb: "replacing", object: "transmission lines?" },
                    { id: "int-h9", english: "Was the legal department negotiating contract terms?", hindi: "क्या कानूनी विभाग अनुबंध शर्तों पर बातचीत कर रहा था?", subject: "legal department", aux: "Was", verb: "negotiating", object: "contract terms?" },
                    { id: "int-h10", english: "Were developers testing the server load stability?", hindi: "क्या डेवलपर्स सर्वर लोड स्थिरता का परीक्षण कर रहे थे?", subject: "developers", aux: "Were", verb: "testing", object: "server load stability?" }
                ]
            }
        },

        // 8. WH Questions / WH प्रश्न (30 Items)
        whQuestions: {
            title: "WH Questions",
            titleHindi: "WH प्रश्न (WH-word + was/were + Subject + V1+ing?)",
            formula: "WH-word + was / were + Subject + V1+ing + Object?",
            explanation: "In WH Questions, place the WH word at the start, followed by was/were + Subject + V1+ing.",
            explanationHindi: "WH प्रश्न में सबसे पहले WH शब्द (What, Where, When, Why, How) रखें, फिर was/were, फिर Subject और V1+ing।",
            
            wordGuide: [
                { word: "What", meaning: "क्या?", usage: "What were you doing?" },
                { word: "Where", meaning: "कहाँ?", usage: "Where was she going?" },
                { word: "When", meaning: "कब?", usage: "When were they playing?" },
                { word: "Why", meaning: "क्यों?", usage: "Why was he crying?" },
                { word: "How", meaning: "कैसे?", usage: "How were you managing?" },
                { word: "Who", meaning: "कौन?", usage: "Who was calling you?" }
            ],

            sentences: {
                easy: [
                    { id: "wh-e1", english: "What were you doing at 8 PM yesterday?", hindi: "आप कल रात 8 बजे क्या कर रहे थे?", subject: "you", aux: "were", whWord: "What", verb: "doing", object: "at 8 PM yesterday?" },
                    { id: "wh-e2", english: "Where was she going when I saw her?", hindi: "जब मैंने उसे देखा तो वह कहाँ जा रही थी?", subject: "she", aux: "was", whWord: "Where", verb: "going", object: "when I saw her?" },
                    { id: "wh-e3", english: "Why was he crying in the room?", hindi: "वह कमरे में क्यों रो रहा था?", subject: "he", aux: "was", whWord: "Why", verb: "crying", object: "in the room?" },
                    { id: "wh-e4", english: "What were they watching on TV?", hindi: "वे टीवी पर क्या देख रहे थे?", subject: "they", aux: "were", whWord: "What", verb: "watching", object: "on TV?" },
                    { id: "wh-e5", english: "How were you feeling yesterday?", hindi: "कल आप कैसा महसूस कर रहे थे?", subject: "you", aux: "were", whWord: "How", verb: "feeling", object: "yesterday?" },
                    { id: "wh-e6", english: "Who was calling your name outside?", hindi: "बाहर आपका नाम कौन पुकार रहा था?", subject: "Who", aux: "was", whWord: "Who", verb: "calling", object: "your name outside?" },
                    { id: "wh-e7", english: "Which book were you reading last night?", hindi: "आप कल रात कौन सी किताब पढ़ रहे थे?", subject: "you", aux: "were", whWord: "Which book", verb: "reading", object: "last night?" },
                    { id: "wh-e8", english: "Where were they staying in Delhi?", hindi: "वे दिल्ली में कहाँ ठहर रहे थे?", subject: "they", aux: "were", whWord: "Where", verb: "staying", object: "in Delhi?" },
                    { id: "wh-e9", english: "Why was the baby crying so loudly?", hindi: "बच्चा इतना तेज क्यों रो रहा था?", subject: "the baby", aux: "was", whWord: "Why", verb: "crying", object: "so loudly?" },
                    { id: "wh-e10", english: "What was Rahul eating for lunch?", hindi: "राहुल दोपहर के खाने में क्या खा रहा था?", subject: "Rahul", aux: "was", whWord: "What", verb: "eating", object: "for lunch?" }
                ],
                medium: [
                    { id: "wh-m1", english: "Where was your brother working last year?", hindi: "आपका भाई पिछले साल कहाँ काम कर रहा था?", subject: "your brother", aux: "was", whWord: "Where", verb: "working", object: "last year?" },
                    { id: "wh-m2", english: "Why were the students making a noise?", hindi: "छात्र शोर क्यों मचा रहे थे?", subject: "the students", aux: "were", whWord: "Why", verb: "making", object: "a noise?" },
                    { id: "wh-m3", english: "When were they planning to leave for vacation?", hindi: "वे छुट्टियों के लिए कब निकलने की योजना बना रहे थे?", subject: "they", aux: "were", whWord: "When", verb: "planning", object: "to leave for vacation?" },
                    { id: "wh-m4", english: "How was she managing the project alone?", hindi: "वह अकेले प्रोजेक्ट को कैसे संभाल रही थी?", subject: "she", aux: "was", whWord: "How", verb: "managing", object: "the project alone?" },
                    { id: "wh-m5", english: "Who was driving the car when the accident occurred?", hindi: "दुर्घटना के समय कार कौन चला रहा था?", subject: "Who", aux: "was", whWord: "Who", verb: "driving", object: "the car when accident occurred?" },
                    { id: "wh-m6", english: "What were the doctors discussing in the emergency room?", hindi: "आपातकालीन कक्ष में डॉक्टर क्या चर्चा कर रहे थे?", subject: "the doctors", aux: "were", whWord: "What", verb: "discussing", object: "in emergency room?" },
                    { id: "wh-m7", english: "Why was the manager shouting at the assistant?", hindi: "प्रबंधक सहायक पर क्यों चिल्ला रहे थे?", subject: "the manager", aux: "was", whWord: "Why", verb: "shouting", object: "at the assistant?" },
                    { id: "wh-m8", english: "How long were you waiting for the bus?", hindi: "आप कितने समय से बस का इंतज़ार कर रहे थे?", subject: "you", aux: "were", whWord: "How long", verb: "waiting", object: "for the bus?" },
                    { id: "wh-m9", english: "Where were the children playing before it rained?", hindi: "बारिश होने से पहले बच्चे कहाँ खेल रहे थे?", subject: "the children", aux: "were", whWord: "Where", verb: "playing", object: "before it rained?" },
                    { id: "wh-m10", english: "What was she searching for in her drawer?", hindi: "वह अपनी दराज में क्या खोज रही थी?", subject: "she", aux: "was", whWord: "What", verb: "searching", object: "for in her drawer?" }
                ],
                hard: [
                    { id: "wh-h1", english: "Why was the board delaying the announcement?", hindi: "बोर्ड घोषणा में देरी क्यों कर रहा था?", subject: "the board", aux: "was", whWord: "Why", verb: "delaying", object: "the announcement?" },
                    { id: "wh-h2", english: "How were the engineers troubleshooting the system glitch?", hindi: "इंजीनियर सिस्टम की खराबी को कैसे ठीक कर रहे थे?", subject: "the engineers", aux: "were", whWord: "How", verb: "troubleshooting", object: "system glitch?" },
                    { id: "wh-h3", english: "What environmental changes were scientists observing?", hindi: "वैज्ञानिक किन पर्यावरण परिवर्तनों का अवलोकन कर रहे थे?", subject: "scientists", aux: "were", whWord: "What changes", verb: "observing", object: "?" },
                    { id: "wh-h4", english: "When were the authorities conducting the site inspection?", hindi: "प्राधिकरण स्थल निरीक्षण कब कर रहे थे?", subject: "authorities", aux: "were", whWord: "When", verb: "conducting", object: "site inspection?" },
                    { id: "wh-h5", english: "Where were researchers gathering soil samples?", hindi: "शोधकर्ता मिट्टी के नमूने कहाँ एकत्र कर रहे थे?", subject: "researchers", aux: "were", whWord: "Where", verb: "gathering", object: "soil samples?" },
                    { id: "wh-h6", english: "Who was coordinating the disaster recovery operations?", hindi: "आपदा रिकवरी कार्यों का समन्वय कौन कर रहा था?", subject: "Who", aux: "was", whWord: "Who", verb: "coordinating", object: "disaster recovery?" },
                    { id: "wh-h7", english: "Why was the server lagging during heavy traffic load?", hindi: "भारी ट्रैफ़िक लोड के दौरान सर्वर धीमा क्यों चल रहा था?", subject: "the server", aux: "was", whWord: "Why", verb: "lagging", object: "during heavy traffic?" },
                    { id: "wh-h8", english: "How were security officers monitoring the perimeter?", hindi: "सुरक्षा अधिकारी सीमा की निगरानी कैसे कर रहे थे?", subject: "security officers", aux: "were", whWord: "How", verb: "monitoring", object: "the perimeter?" },
                    { id: "wh-h9", english: "Which key proposal was the council debating?", hindi: "परिषद किस प्रमुख प्रस्ताव पर बहस कर रही थी?", subject: "the council", aux: "was", whWord: "Which proposal", verb: "debating", object: "?" },
                    { id: "wh-h10", english: "What evidence were investigators presenting to the judge?", hindi: "जांचकर्ता न्यायाधीश के समक्ष क्या सबूत पेश कर रहे थे?", subject: "investigators", aux: "were", whWord: "What evidence", verb: "presenting", object: "to judge?" }
                ]
            }
        },

        // 9. Common Mistakes & Corrections / सामान्य गलतियाँ और सुधार (15 Detailed Mistakes)
        commonMistakes: {
            title: "Common Mistakes",
            titleHindi: "सामान्य गलतियाँ और सही नियम (Common Mistakes & Rationale)",
            introduction: "Avoid these 15 common errors when forming Past Continuous sentences.",
            introductionHindi: "Past Continuous Tense का प्रयोग करते समय इन 15 सामान्य गलतियों से बचें।",
            
            mistakes: [
                {
                    id: "mistake-1",
                    title: "1. Missing Was/Were (Auxiliary Verb)",
                    titleHindi: "Was/Were का छूट जाना",
                    wrong: "I studying for the exam yesterday.",
                    correct: "I was studying for the exam yesterday.",
                    explanation: "Past Continuous requires auxiliary verb 'was' or 'were' before V1+ing.",
                    explanationHindi: "Past Continuous में V1+ing से पहले was या were लगाना अनिवार्य है।",
                    rule: "Subject + was/were + V1+ing"
                },
                {
                    id: "mistake-2",
                    title: "2. Wrong Was/Were Subject Agreement",
                    titleHindi: "Was/Were का कर्ता के अनुसार गलत प्रयोग",
                    wrong: "They was playing football.",
                    correct: "They were playing football.",
                    explanation: "Plural subject 'They' takes 'were', not 'was'.",
                    explanationHindi: "बहुवचन कर्ता 'They' के साथ हमेशा 'were' आता है, 'was' नहीं।",
                    rule: "You / We / They ➔ WERE"
                },
                {
                    id: "mistake-3",
                    title: "3. Using V2 Verb after Was/Were",
                    titleHindi: "Was/Were के बाद V2 का प्रयोग करना",
                    wrong: "She was went to school.",
                    correct: "She was going to school.",
                    explanation: "Do not use V2 (went) after was/were. Use V1+ing (going).",
                    explanationHindi: "was/were के बाद Verb की 2nd form (went) नहीं आती। हमेशा V1+ing (going) लगाएं।",
                    rule: "was/were + V1+ing (Not V2)"
                },
                {
                    id: "mistake-4",
                    title: "4. Using V3 Verb after Was/Were in Active Voice",
                    titleHindi: "Was/Were के बाद V3 का प्रयोग करना",
                    wrong: "He was written a letter.",
                    correct: "He was writing a letter.",
                    explanation: "In active Past Continuous, use V1+ing (writing), not V3 (written).",
                    explanationHindi: "अपूर्ण भूतकाल (active voice) में was/were के बाद V1+ing (writing) आता है, V3 (written) नहीं।",
                    rule: "was/were + V1+ing (Not V3)"
                },
                {
                    id: "mistake-5",
                    title: "5. Missing -ing from Main Verb",
                    titleHindi: "Main Verb से -ing का छूट जाना",
                    wrong: "They were play cricket.",
                    correct: "They were playing cricket.",
                    explanation: "Past Continuous main verb requires the -ing suffix.",
                    explanationHindi: "Past Continuous में मुख्य क्रिया में -ing जोड़ना अनिवार्य है (play ➔ playing)।",
                    rule: "Main Verb ➔ V1 + ing"
                },
                {
                    id: "mistake-6",
                    title: "6. Spelling Error in -ing Formation (Silent 'e')",
                    titleHindi: "Silent 'e' हटाए बिना -ing जोड़ना",
                    wrong: "She was writeing a story.",
                    correct: "She was writing a story.",
                    explanation: "Drop silent 'e' at the end of verb before adding -ing (write ➔ writing).",
                    explanationHindi: "वर्ब के अंत का शांत 'e' हटाकर ही -ing जोड़ा जाता है (write ➔ writing)।",
                    rule: "Drop silent -e + ing"
                },
                {
                    id: "mistake-7",
                    title: "7. Using V2 in Negative Past Continuous",
                    titleHindi: "नकारात्मक वाक्य में V2 का प्रयोग",
                    wrong: "I wasn't went there.",
                    correct: "I wasn't going there.",
                    explanation: "After wasn't/weren't, use V1+ing (going), not V2 (went).",
                    explanationHindi: "wasn't/weren't के बाद क्रिया की 1st form + ing (going) आती है, V2 नहीं।",
                    rule: "wasn't/weren't + V1+ing"
                },
                {
                    id: "mistake-8",
                    title: "8. Incorrect Question Word Order",
                    titleHindi: "प्रश्नवाचक वाक्य में गलत शब्द क्रम",
                    wrong: "Where you were going yesterday?",
                    correct: "Where were you going yesterday?",
                    explanation: "In WH questions, auxiliary 'were/was' comes before the subject.",
                    explanationHindi: "WH प्रश्न में auxiliary 'were/was' कर्ता (Subject) से पहले आता है।",
                    rule: "WH + was/were + Subject + V1+ing?"
                },
                {
                    id: "mistake-9",
                    title: "9. Using 'were' with Subject 'I'",
                    titleHindi: "Subject 'I' के साथ 'were' का गलत प्रयोग",
                    wrong: "I were studying at home.",
                    correct: "I was studying at home.",
                    explanation: "Subject 'I' takes 'was' in Past Continuous, not 'were'.",
                    explanationHindi: "Past Continuous में Subject 'I' के साथ 'was' का प्रयोग होता है, 'were' का नहीं।",
                    rule: "I ➔ WAS + V1+ing"
                },
                {
                    id: "mistake-10",
                    title: "10. Simple Past vs Past Continuous Misuse",
                    titleHindi: "Simple Past और Past Continuous का गलत मिश्रण",
                    wrong: "I was watching TV yesterday. (without time context)",
                    correct: "I watched TV yesterday. / I was watching TV at 8 PM yesterday.",
                    explanation: "Use Simple Past for simple finished events, and Past Continuous when specific ongoing time context is present.",
                    explanationHindi: "सामान्य बीते काम के लिए Simple Past (watched) और किसी निश्चित समय पर जारी काम के लिए Past Continuous का प्रयोग करें।",
                    rule: "Finished event ➔ Simple Past | Ongoing past time ➔ Past Continuous"
                },
                {
                    id: "mistake-11",
                    title: "11. Present Continuous vs Past Continuous Misuse",
                    titleHindi: "Present Continuous और Past Continuous में भ्रम",
                    wrong: "I am studying yesterday at 8 PM.",
                    correct: "I was studying yesterday at 8 PM.",
                    explanation: "Use 'was/were' for past continuous actions, not 'am/is/are'.",
                    explanationHindi: "बीते समय (yesterday) की जारी क्रिया के लिए 'was/were' का प्रयोग करें, 'am/is/are' का नहीं।",
                    rule: "Past time ➔ WAS/WERE + V1+ing"
                },
                {
                    id: "mistake-12",
                    title: "12. Double Past Continuous in 'When' Clause",
                    titleHindi: "'When' क्लॉज में दोनों तरफ Past Continuous लगाना",
                    wrong: "I was sleeping when the phone was ringing.",
                    correct: "I was sleeping when the phone rang.",
                    explanation: "The interrupting action after 'when' should be in Simple Past (rang), not Past Continuous.",
                    explanationHindi: "बाधित करने वाला कार्य 'when' के बाद Simple Past (rang) में होना चाहिए।",
                    rule: "Past Continuous + WHEN + Simple Past"
                },
                {
                    id: "mistake-13",
                    title: "13. Simple Past in 'While' Clause",
                    titleHindi: "'While' क्लॉज के बाद Simple Past की गलती",
                    wrong: "While I slept, my brother was watching TV.",
                    correct: "While I was sleeping, my brother was watching TV.",
                    explanation: "The clause after 'while' usually expresses an ongoing background action (Past Continuous).",
                    explanationHindi: "'While' के बाद वाला भाग आमतौर पर जारी क्रिया (Past Continuous) में होता है।",
                    rule: "WHILE + Past Continuous"
                },
                {
                    id: "mistake-14",
                    title: "14. Consonant Doubling Spelling Mistake",
                    titleHindi: "Double Consonant स्पेलिंग नियम में गलती",
                    wrong: "He was runing fast.",
                    correct: "He was running fast.",
                    explanation: "Verbs like run (short vowel + single consonant) double the consonant: running.",
                    explanationHindi: "Run जैसे शब्दों में -ing जोड़ते समय अंतिम consonant double (running) होता है।",
                    rule: "run ➔ running | sit ➔ sitting"
                },
                {
                    id: "mistake-15",
                    title: "15. Incorrect Contraction Apostrophe Placement",
                    titleHindi: "Contraction में गलत एपोस्ट्रोफी लगाना",
                    wrong: "They wasnt playing / werent working.",
                    correct: "They wasn't playing / weren't working.",
                    explanation: "Always place apostrophe between 'n' and 't' in contractions (wasn't / weren't).",
                    explanationHindi: "Contractions में एपोस्ट्रोफी (') हमेशा 'n' और 't' के बीच लगाएं (wasn't, weren't)।",
                    rule: "wasn't | weren't"
                }
            ]
        },

        // 10. Summary & Revision / सारांश एवं दोहराव
        summary: {
            title: "Summary & Revision",
            titleHindi: "सारांश एवं दोहराव (Revision Summary)",
            introduction: "Quick summary of Past Continuous rules, formulas, and memory markers.",
            introductionHindi: "Past Continuous Tense के मुख्य नियमों, सूत्रों और याद रखने योग्य बिंदुओं का त्वरित सारांश।",
            
            goldenRules: [
                "1. I / He / She / It / Singular ➔ WAS + V1+ing",
                "2. You / We / They / Plural ➔ WERE + V1+ing",
                "3. Positive Formula ➔ Subject + was/were + V1+ing + Object",
                "4. Negative Formula ➔ Subject + was/were + not (wasn't/weren't) + V1+ing",
                "5. Interrogative Formula ➔ Was/Were + Subject + V1+ing?",
                "6. Interrupted Action Pattern ➔ Past Continuous + WHEN + Simple Past",
                "7. Parallel Actions Pattern ➔ WHILE + Past Continuous, Past Continuous"
            ],

            formulaSummary: {
                positive: "Subject + was/were + V1+ing + Object",
                negative: "Subject + was/were + not + V1+ing + Object",
                interrogative: "Was/Were + Subject + V1+ing + Object?",
                whQuestion: "WH-word + was/were + Subject + V1+ing + Object?"
            },

            revisionExamples: {
                easy: [
                    { id: "sum-e1", english: "I was studying at 8 PM.", hindi: "मैं रात 8 बजे पढ़ रहा था।", note: "Singular I + was + V1+ing" },
                    { id: "sum-e2", english: "She was not working yesterday.", hindi: "वह कल काम नहीं कर रही थी।", note: "Negative with 'was not'" },
                    { id: "sum-e3", english: "Were they playing cricket?", hindi: "क्या वे क्रिकेट खेल रहे थे?", note: "Question starting with 'Were'" },
                    { id: "sum-e4", english: "What were you doing there?", hindi: "आप वहाँ क्या कर रहे थे?", note: "WH question with 'What were'" },
                    { id: "sum-e5", english: "Rahul was waiting for the bus.", hindi: "राहुल बस का इंतज़ार कर रहा था।", note: "Singular subject + was" }
                ],
                medium: [
                    { id: "sum-m1", english: "My father was repairing the car in garage.", hindi: "मेरे पिता गैरेज में कार ठीक कर रहे थे।", note: "Singular father + was" },
                    { id: "sum-m2", english: "She wasn't using her phone during class.", hindi: "वह कक्षा में फोन का प्रयोग नहीं कर रही थी।", note: "Contraction wasn't" },
                    { id: "sum-m3", english: "Were the students preparing for test?", hindi: "क्या छात्र टेस्ट की तैयारी कर रहे थे?", note: "Plural students + Were" },
                    { id: "sum-m4", english: "Why was he shouting at the meeting?", hindi: "वह बैठक में क्यों चिल्ला रहा था?", note: "WH question with 'Why was'" },
                    { id: "sum-m5", english: "I was sleeping when the alarm rang.", hindi: "जब अलार्म बजा तब मैं सो रहा था।", note: "When clause pattern" }
                ],
                hard: [
                    { id: "sum-h1", english: "Engineers were inspecting the power grid infrastructure.", hindi: "इंजीनियर पावर ग्रिड इंफ्रास्ट्रक्चर का निरीक्षण कर रहे थे।", note: "Professional context with were + V1+ing" },
                    { id: "sum-h2", english: "The research team was not ignoring environmental warnings.", hindi: "शोध टीम पर्यावरण चेतावनियों को नजरअंदाज नहीं कर रही थी।", note: "Negative with team + was not" },
                    { id: "sum-h3", english: "How were developers troubleshooting server issues?", hindi: "डेवलपर्स सर्वर की समस्याओं को कैसे ठीक कर रहे थे?", note: "Complex WH question with 'How were'" },
                    { id: "sum-h4", english: "While mother was cooking, father was reading.", hindi: "जब मां खाना बना रही थीं तब पिता पढ़ रहे थे।", note: "Parallel actions with While" },
                    { id: "sum-h5", english: "Heavy rain was disrupting transportation across the city.", hindi: "भारी बारिश शहर भर में परिवहन को बाधित कर रही थी।", note: "Atmospheric ongoing action" }
                ]
            }
        },

        // 11. Practice Exercises / अभ्यास (120 Practice Sentences Total)
        exercises: {
            title: "Past Continuous Practice Sentences",
            titleHindi: "अपूर्ण भूतकाल — अभ्यास (120 Practice Sentences)",
            introduction: "Practice all 120 sentences across Positive, Negative, Interrogative, and WH Questions to master Past Continuous Tense.",
            introductionHindi: "Past Continuous Tense के 120 अभ्यास वाक्यों (सकारात्मक, नकारात्मक, प्रश्नवाचक एवं WH प्रश्न) के माध्यम से पूरा अभ्यास करें।",
            categories: []
        },

        // 12. Quiz Configuration / ज्ञान परीक्षा (12 Quiz Combinations)
        quiz: {
            title: "Past Continuous Quiz",
            titleHindi: "अपूर्ण भूतकाल — ज्ञान परीक्षा",
            questions: []
        }
    }
};

// Initialize categories referencing existing sections (120 Practice Sentences total)
pastContinuousLesson.sections.exercises.categories = [
    {
        id: "positive",
        title: "Positive Sentences Practice",
        titleHindi: "1. सकारात्मक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Positive Sentence",
        sentences: pastContinuousLesson.sections.positive.sentences
    },
    {
        id: "negative",
        title: "Negative Sentences Practice",
        titleHindi: "2. नकारात्मक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Negative Sentence",
        sentences: pastContinuousLesson.sections.negative.sentences
    },
    {
        id: "interrogative",
        title: "Interrogative Sentences Practice",
        titleHindi: "3. प्रश्नवाचक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Yes/No Question",
        sentences: pastContinuousLesson.sections.interrogative.sentences
    },
    {
        id: "whQuestions",
        title: "WH Questions Practice",
        titleHindi: "4. WH प्रश्न अभ्यास (30 Sentences)",
        typeLabel: "WH Question",
        sentences: pastContinuousLesson.sections.whQuestions.sentences
    }
];

/**
 * Get the complete Past Continuous lesson object
 * @returns {object}
 */
export function getPastContinuousLesson() {
    return { ...pastContinuousLesson };
}

/**
 * Get a specific section of Past Continuous lesson data
 * @param {string} sectionName 
 * @returns {object|Array|null}
 */
export function getPastContinuousSection(sectionName) {
    if (!sectionName || !pastContinuousLesson.sections) return null;
    return pastContinuousLesson.sections[sectionName] || null;
}
