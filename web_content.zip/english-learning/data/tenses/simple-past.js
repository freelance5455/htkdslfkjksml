/**
 * Central Lesson Data for Simple Past Tense (सामान्य भूतकाल)
 * Single Source of Truth for Simple Past Tense Module.
 * Follows proven reference architecture established in completed Present Tenses.
 */

const simplePastLesson = {
    id: "simple-past",
    title: "Simple Past",
    titleHindi: "सामान्य भूतकाल (किया / गया / देखा / आया)",
    description: "Learn Simple Past Tense in simple Hindi: Subject + V2 + Object (Positive) and Subject + did not + V1 + Object (Negative/Question).",

    sections: {
        // 1. Identification / पहचान और अवधारणा
        identification: {
            title: "Identification",
            titleHindi: "पहचान और अवधारणा",
            english: "Simple Past Tense is used to express an action, event, or state that happened and was completed in the past.",
            hindi: "Simple Past Tense का प्रयोग ऐसे कार्यों, घटनाओं या स्थितियों को व्यक्त करने के लिए किया जाता है जो भूतकाल (Past) में शुरू हुईं और समाप्त हो गईं।",
            hindiIdentityRule: "पहचान (Hindi Clues): वाक्य की मुख्य क्रिया (Main Verb) के अंत में - आ, ई, ए, आया, गई, गए, देखा, बोला, लिखा, खाया, किया, था, थी, थे आदि शब्द आते हैं।",
            points: [
                {
                    english: "The action started and finished entirely in the past.",
                    hindi: "कार्य भूतकाल में ही शुरू हुआ और भूतकाल में ही समाप्त हो गया।"
                },
                {
                    english: "In Positive sentences, use V2 (Second form of the verb) for ALL subjects.",
                    hindi: "सकारात्मक (Positive) वाक्यों में सभी कर्ताओं (I, You, We, They, He, She, Singular, Plural) के साथ Main Verb की 2nd Form (V2) का प्रयोग होता है।"
                },
                {
                    english: "In Negative and Question sentences, use Auxiliary Verb 'did' + V1 (Base Form).",
                    hindi: "नकारात्मक (Negative) और प्रश्नवाचक (Question) वाक्यों में 'did' के साथ क्रिया की 1st Form (V1) का प्रयोग होता है।"
                },
                {
                    english: "Golden Rule: 'Did' is already the past form of 'do', so after 'did', ALWAYS use V1.",
                    hindi: "गोल्डन नियम: 'Did' खुद V2 है, इसलिए Did या Didn't आने पर मुख्य क्रिया हमेशा V1 में बदल जाती है।"
                },
                {
                    english: "Common Past Time Signals: yesterday, last night, last week, 2 days ago, in 2020, when I was young.",
                    hindi: "सामान्य भूतकाल सूचक शब्द: yesterday (कल), last night (बीती रात), last week (पिछले सप्ताह), 2 days ago (दो दिन पहले), in 2020 आदि।"
                }
            ],
            comparison: {
                title: "Concept Comparison: Simple Past vs Other Tenses",
                simplePresent: {
                    name: "Simple Present",
                    formula: "Subject + V1 / V1+s/es",
                    concept: "Routine / Daily Habit (वर्तमान की आदत)",
                    example: "I visit Delhi. (मैं दिल्ली जाता हूँ।)"
                },
                presentContinuous: {
                    name: "Present Continuous",
                    formula: "Subject + am/is/are + V4(ing)",
                    concept: "Action ongoing right now (काम अभी चल रहा है)",
                    example: "I am visiting Delhi. (मैं दिल्ली जा रहा हूँ।)"
                },
                simplePast: {
                    name: "Simple Past",
                    formula: "Subject + V2 / did + V1",
                    concept: "Completed past action (भूतकाल में समाप्त हुआ कार्य)",
                    example: "I visited Delhi yesterday. (मैं कल दिल्ली गया।)"
                }
            }
        },

        // 2. Uses & Scenarios / उपयोग और परिस्थितियाँ
        uses: {
            title: "Uses & Scenarios",
            titleHindi: "कब प्रयोग करें (5 मुख्य उपयोग)",
            intro: "Simple Past Tense is essential for talking about finished events, personal stories, habits, and historical facts.",
            introHindi: "Simple Past Tense का प्रयोग बीते समय की घटनाओं, कहानियों, पुरानी आदतों और ऐतिहासिक तथ्यों को बताने के लिए किया जाता है।",
            list: [
                {
                    title: "1. Completed Action in the Past",
                    titleHindi: "भूतकाल में समाप्त हुआ कार्य",
                    explanation: "Actions that took place and were completed at a specific or implied time in the past.",
                    explanationHindi: "ऐसे कार्य जो भूतकाल में किसी निश्चित या स्वाभाविक समय पर पूरे हो चुके हैं।",
                    whyUsed: "Indicates that the event has ended and has no ongoing process.",
                    whyUsedHindi: "यह दर्शाता है कि घटना समाप्त हो चुकी है और अब जारी नहीं है।",
                    examples: [
                        { english: "I watched a movie yesterday.", hindi: "मैंने कल एक फिल्म देखी।", note: "Watched (V2 of watch)" },
                        { english: "She bought a new laptop last week.", hindi: "उसने पिछले हफ्ते एक नया लैपटॉप खरीदा।", note: "Bought (V2 of buy)" },
                        { english: "They finished the project on time.", hindi: "उन्होंने समय पर प्रोजेक्ट पूरा किया।", note: "Finished (V2 of finish)" }
                    ]
                },
                {
                    title: "2. Action at a Specific Past Time",
                    titleHindi: "भूतकाल के निश्चित समय पर हुआ कार्य",
                    explanation: "Events accompanied by specific past time expressions such as ago, last year, in 2018.",
                    explanationHindi: "ऐसे कार्य जिनके साथ बीते समय का स्पष्ट उल्लेख होता है जैसे ago, last year, in 2018 आदि।",
                    whyUsed: "Anchors the completed event to a specific historical or chronological point.",
                    whyUsedHindi: "घटना को किसी विशिष्ट बीते समय से जोड़ता है।",
                    examples: [
                        { english: "My uncle arrived two hours ago.", hindi: "मेरे चाचा दो घंटे पहले आए।", note: "Time marker: two hours ago" },
                        { english: "We graduated in 2021.", hindi: "हमने 2021 में ग्रेजुएशन किया।", note: "Time marker: in 2021" },
                        { english: "The company opened a new branch last month.", hindi: "कंपनी ने पिछले महीने एक नई शाखा खोली।", note: "Time marker: last month" }
                    ]
                },
                {
                    title: "3. Series of Completed Past Actions",
                    titleHindi: "भूतकाल के एक के बाद एक हुए कार्य",
                    explanation: "Used to tell stories or describe a sequence of consecutive completed actions in the past.",
                    explanationHindi: "कहानियां सुनाने या अतीत में एक के बाद एक हुए कार्यों का क्रम बताने के लिए।",
                    whyUsed: "Shows sequential narrative progress.",
                    whyUsedHindi: "कहानी या घटनाक्रम का क्रम दर्शाता है।",
                    examples: [
                        { english: "I woke up, brushed my teeth, and left home.", hindi: "मैं उठा, दाँत साफ़ किए और घर से निकला।", note: "Sequence: woke, brushed, left" },
                        { english: "He entered the room, opened the window, and sat down.", hindi: "वह कमरे में आया, खिड़की खोली और बैठ गया।", note: "Sequence: entered, opened, sat" },
                        { english: "She locked the door and called a taxi.", hindi: "उसने दरवाजा बंद किया और टैक्स बुलाई।", note: "Sequence: locked, called" }
                    ]
                },
                {
                    title: "4. Past Habits & Repeated Actions",
                    titleHindi: "भूतकाल की पुरानी आदतें या गतिविधियां",
                    explanation: "Describes regular habits or routines practiced in the past that no longer happen.",
                    explanationHindi: "अतीत की पुरानी आदतें या दिनचर्या जो पहले नियमित थीं लेकिन अब नहीं हैं।",
                    whyUsed: "Expresses habitual past routines.",
                    whyUsedHindi: "अतीत की नियमित आदत व्यक्त करता है।",
                    examples: [
                        { english: "I played cricket every Sunday when I was a child.", hindi: "जब मैं बच्चा था तो हर रविवार क्रिकेट खेलता था।", note: "Past habit with 'every Sunday'" },
                        { english: "Grandmother told us stories every night.", hindi: "दादी हमें हर रात कहानियां सुनाती थीं।", note: "Past routine" },
                        { english: "He walked to school every morning.", hindi: "वह हर सुबह पैदल स्कूल जाता था।", note: "Past habit" }
                    ]
                },
                {
                    title: "5. Past States or Situations",
                    titleHindi: "भूतकाल की स्थिति या अवस्था",
                    explanation: "Describes long-term states, situations, or feelings that were true in the past.",
                    explanationHindi: "अतीत की लंबी स्थितियां, अवस्थाएं या भावनाएं जो पहले सच थीं।",
                    whyUsed: "States a past permanent or stable condition.",
                    whyUsedHindi: "अतीत की स्थिति का वर्णन करता है।",
                    examples: [
                        { english: "She lived in London for five years.", hindi: "वह पाँच साल तक लंदन में रही।", note: "Past state (now lives elsewhere)" },
                        { english: "They owned a house near the river.", hindi: "उनके पास नदी के पास एक घर था।", note: "Past ownership" },
                        { english: "He was very quiet during his childhood.", hindi: "वह अपने बचपन में बहुत शांत था।", note: "Past state" }
                    ]
                }
            ]
        },

        // 3. Sentence Structure & Formulas / वाक्य संरचना एवं सूत्र
        structure: {
            title: "Structure & Formulas",
            titleHindi: "वाक्य संरचना एवं सूत्र (Formulas)",
            simpleHindiOverview: "Simple Past के Positive वाक्यों में V2 का प्रयोग होता है। Negative, Interrogative और WH Questions में Auxiliary Verb 'did' के साथ हमेशा V1 आता है।",
            mainFormula: "Positive: Subject + V2 + Object | Negative: Subject + did not + V1 + Object",
            
            auxiliaryMapping: [
                {
                    subjectGroup: "All Subjects (I / You / We / They / He / She / It / Singular / Plural)",
                    auxiliary: "V2 (Positive) | did + V1 (Negative & Questions)",
                    formula: "Subject + V2 (Pos) | Subject + did not + V1 (Neg)",
                    hindiRule: "Simple Past में सभी कर्ताओं (Subject) के साथ Positive में V2 और Negative/Question में Did + V1 का नियम समान रूप से लागू होता है।"
                }
            ],

            v4Explanation: {
                title: "Main Verb Forms: V1 vs V2 vs V3",
                titleHindi: "मुख्य क्रिया के रूप: V1, V2 और V3 में अंतर",
                ruleText: "V1 = Base Form, V2 = Past Form, V3 = Past Participle",
                explanationHindi: "Positive Simple Past में केवल V2 आता है। Did आने पर क्रिया वापस V1 में बदल जाती है।",
                examples: [
                    { base: "go", v4: "went (V2) / gone (V3)" },
                    { base: "eat", v4: "ate (V2) / eaten (V3)" },
                    { base: "see", v4: "saw (V2) / seen (V3)" },
                    { base: "write", v4: "wrote (V2) / written (V3)" },
                    { base: "play", v4: "played (V2) / played (V3)" },
                    { base: "work", v4: "worked (V2) / worked (V3)" }
                ]
            },

            formulaBlocks: [
                {
                    type: "positive",
                    title: "1. Positive Sentence (सकारात्मक वाक्य)",
                    formula: "Subject + V2 + Object / Complement",
                    englishExplanation: "Use the second form of verb (V2) directly after the subject.",
                    hindiExplanation: "सकारात्मक वाक्य में कर्ता (Subject) के तुरंत बाद क्रिया की 2nd Form (V2) का प्रयोग करें।",
                    examples: [
                        {
                            english: "She visited Delhi.",
                            hindi: "वह दिल्ली गई।",
                            breakdown: { subject: "She", mainVerb: "visited (V2)", object: "Delhi" }
                        },
                        {
                            english: "They played cricket yesterday.",
                            hindi: "उन्होंने कल क्रिकेट खेला।",
                            breakdown: { subject: "They", mainVerb: "played (V2)", object: "cricket yesterday" }
                        }
                    ]
                },
                {
                    type: "negative",
                    title: "2. Negative Sentence (नकारात्मक वाक्य)",
                    formula: "Subject + did not (didn't) + V1 + Object / Complement",
                    englishExplanation: "Use 'did not' or contraction 'didn't', followed by base verb (V1).",
                    hindiExplanation: "नकारात्मक वाक्य में 'did not' या 'didn't' लगाएं और उसके बाद Verb 1st Form (V1) लगाएं।",
                    examples: [
                        {
                            english: "She did not visit Delhi.",
                            hindi: "वह दिल्ली नहीं गई।",
                            breakdown: { subject: "She", aux: "did", not: "not", mainVerb: "visit (V1)", object: "Delhi" }
                        },
                        {
                            english: "They didn't play cricket yesterday.",
                            hindi: "उन्होंने कल क्रिकेट नहीं खेला।",
                            breakdown: { subject: "They", aux: "didn't", mainVerb: "play (V1)", object: "cricket yesterday" }
                        }
                    ]
                },
                {
                    type: "interrogative",
                    title: "3. Interrogative Sentence (Yes/No Questions)",
                    formula: "Did + Subject + V1 + Object / Complement?",
                    englishExplanation: "Place 'Did' at the start, followed by Subject and V1 verb.",
                    hindiExplanation: "प्रश्नवाचक वाक्य में सबसे पहले 'Did' रखें, फिर Subject और फिर Verb की 1st Form (V1)।",
                    examples: [
                        {
                            english: "Did she visit Delhi?",
                            hindi: "क्या वह दिल्ली गई?",
                            breakdown: { aux: "Did", subject: "she", mainVerb: "visit (V1)", object: "Delhi?" }
                        },
                        {
                            english: "Did they play cricket yesterday?",
                            hindi: "क्या उन्होंने कल क्रिकेट खेला?",
                            breakdown: { aux: "Did", subject: "they", mainVerb: "play (V1)", object: "cricket yesterday?" }
                        }
                    ]
                },
                {
                    type: "whQuestions",
                    title: "4. WH Question (Information Questions)",
                    formula: "WH-word + did + Subject + V1 + Object / Complement?",
                    englishExplanation: "Place WH-word first, followed by did + Subject + V1.",
                    hindiExplanation: "WH प्रश्न में सबसे पहले WH शब्द, फिर did, फिर Subject और फिर Verb की 1st Form (V1)।",
                    examples: [
                        {
                            english: "Where did she go?",
                            hindi: "वह कहाँ गई?",
                            breakdown: { wh: "Where", aux: "did", subject: "she", mainVerb: "go (V1)?" }
                        },
                        {
                            english: "What did you eat for breakfast?",
                            hindi: "आपने नाश्ते में क्या खाया?",
                            breakdown: { wh: "What", aux: "did", subject: "you", mainVerb: "eat (V1)", object: "for breakfast?" }
                        }
                    ]
                }
            ]
        },

        // 4. Subject + Verb Rules / कर्ता और क्रिया के नियम
        subjectVerbRules: {
            title: "Subject + Verb Rules",
            titleHindi: "कर्ता एवं क्रिया के नियम (Simple Past Golden Rules)",
            
            auxiliaryMapping: [
                {
                    subjectGroup: "All Subjects (I / You / We / They / He / She / It / Names)",
                    auxiliary: "V2 (Positive) / did + V1 (Negative & Question)",
                    formula: "Subject + V2 (Pos) | Subject + did not + V1 (Neg)",
                    hindiRule: "Simple Past का नियम सबसे सरल है: Positive में सभी कर्ताओं के साथ V2, और Negative/Question में Did + V1।"
                }
            ],

            v4Explanation: {
                title: "Golden Memory Rule: DID = V1",
                titleHindi: "स्वर्ण नियम: DID आया ➔ Main Verb V1 में आया!",
                ruleText: "Positive ➔ Subject + V2 | Negative/Question ➔ Did + V1",
                explanationHindi: "याद रखें! 'did' स्वयं 'do' की Past Form (V2) है, इसलिए वाक्य में दोबारा V2 न लगाएं। Did के आते ही वर्ब V1 बन जाती है।",
                examples: [
                    { base: "I went to school. (Positive: V2)", v4: "I did not go to school. (Negative: V1)" },
                    { base: "She called me. (Positive: V2)", v4: "Did she call you? (Question: V1)" },
                    { base: "They ate food. (Positive: V2)", v4: "What did they eat? (WH Question: V1)" }
                ]
            },

            spellingRulesIng: [
                {
                    condition: "1. Regular Verbs (सामान्य क्रियाएं)",
                    rule: "Add -ed to the base form (V1 ➔ V2)",
                    examples: "work ➔ worked, play ➔ played, visit ➔ visited, clean ➔ cleaned"
                },
                {
                    condition: "2. Verbs ending in '-e'",
                    rule: "Add only -d",
                    examples: "live ➔ lived, change ➔ changed, arrive ➔ arrived, close ➔ closed"
                },
                {
                    condition: "3. Verbs ending in Consonant + 'y'",
                    rule: "Change 'y' to 'i' and add -ed",
                    examples: "study ➔ studied, try ➔ tried, carry ➔ carried, cry ➔ cried"
                },
                {
                    condition: "4. Irregular Verbs (अनियमित क्रियाएं)",
                    rule: "Completely change form (Must be memorized)",
                    examples: "go ➔ went, eat ➔ ate, see ➔ saw, write ➔ wrote, buy ➔ bought, take ➔ took"
                }
            ]
        },

        // 5. Positive Sentences / सकारात्मक वाक्य (30 Items)
        positive: {
            title: "Positive / Affirmative Sentences",
            titleHindi: "सकारात्मक वाक्य (Subject + V2 + Object)",
            formula: "Subject + V2 + Object / Complement",
            explanation: "In positive Simple Past sentences, use the second form of the verb (V2) for all subjects.",
            explanationHindi: "सकारात्मक वाक्य में सभी कर्ताओं के साथ Main Verb की 2nd Form (V2) का प्रयोग किया जाता है।",
            
            sentences: {
                easy: [
                    { id: "pos-e1", english: "I went to the market.", hindi: "मैं बाज़ार गया।", subject: "I", verb: "went", object: "to the market" },
                    { id: "pos-e2", english: "She ate an apple.", hindi: "उसने एक सेब खाया।", subject: "She", verb: "ate", object: "an apple" },
                    { id: "pos-e3", english: "They played football.", hindi: "उन्होंने फुटबॉल खेला।", subject: "They", verb: "played", object: "football" },
                    { id: "pos-e4", english: "We watched a movie.", hindi: "हमने एक फिल्म देखी।", subject: "We", verb: "watched", object: "a movie" },
                    { id: "pos-e5", english: "He wrote a letter.", hindi: "उसने एक पत्र लिखा।", subject: "He", verb: "wrote", object: "a letter" },
                    { id: "pos-e6", english: "Rahul bought a new book.", hindi: "राहुल ने एक नई किताब खरीदी।", subject: "Rahul", verb: "bought", object: "a new book" },
                    { id: "pos-e7", english: "You called me yesterday.", hindi: "आपने मुझे कल फोन किया।", subject: "You", verb: "called", object: "me yesterday" },
                    { id: "pos-e8", english: "The rain stopped.", hindi: "बारिश रुक गई।", subject: "The rain", verb: "stopped", object: "" },
                    { id: "pos-e9", english: "She sang a sweet song.", hindi: "उसने एक मीठा गाना गाया।", subject: "She", verb: "sang", object: "a sweet song" },
                    { id: "pos-e10", english: "They came home early.", hindi: "वे जल्दी घर आए।", subject: "They", verb: "came", object: "home early" }
                ],
                medium: [
                    { id: "pos-m1", english: "My father cooked dinner for us.", hindi: "मेरे पिता ने हमारे लिए खाना पकाया।", subject: "My father", verb: "cooked", object: "dinner for us" },
                    { id: "pos-m2", english: "She completed her homework quickly.", hindi: "उसने अपना गृहकार्य जल्दी पूरा किया।", subject: "She", verb: "completed", object: "her homework quickly" },
                    { id: "pos-m3", english: "The doctor examined the patient carefully.", hindi: "डॉक्टर ने मरीज की सावधानीपूर्वक जांच की।", subject: "The doctor", verb: "examined", object: "the patient carefully" },
                    { id: "pos-m4", english: "We visited our grandparents last weekend.", hindi: "हमने पिछले सप्ताहांत अपने दादा-दादी से मुलाकात की।", subject: "We", verb: "visited", object: "our grandparents last weekend" },
                    { id: "pos-m5", english: "He sold his old bicycle.", hindi: "उसने अपनी पुरानी साइकिल बेच दी।", subject: "He", verb: "sold", object: "his old bicycle" },
                    { id: "pos-m6", english: "The manager approved the budget proposal.", hindi: "प्रबंधक ने बजट प्रस्ताव को मंजूरी दे दी।", subject: "The manager", verb: "approved", object: "the budget proposal" },
                    { id: "pos-m7", english: "They built a community hall in the village.", hindi: "उन्होंने गांव में एक सामुदायिक भवन बनाया।", subject: "They", verb: "built", object: "a community hall" },
                    { id: "pos-m8", english: "She learned French during her vacation.", hindi: "उसने अपनी छुट्टियों के दौरान फ्रेंच सीखी।", subject: "She", verb: "learned", object: "French during vacation" },
                    { id: "pos-m9", english: "The teacher explained the lesson clearly.", hindi: "शिक्षक ने पाठ को स्पष्ट रूप से समझाया।", subject: "The teacher", verb: "explained", object: "the lesson clearly" },
                    { id: "pos-m10", english: "I paid the electricity bill online.", hindi: "मैंने बिजली के बिल का ऑनलाइन भुगतान किया।", subject: "I", verb: "paid", object: "the electricity bill online" }
                ],
                hard: [
                    { id: "pos-h1", english: "The engineers successfully launched the new satellite into orbit.", hindi: "इंजीनियरों ने कक्षा में नए उपग्रह का सफलतापूर्वक प्रक्षेपण किया।", subject: "The engineers", verb: "launched", object: "the satellite into orbit" },
                    { id: "pos-h2", english: "The company reported significant financial growth last quarter.", hindi: "कंपनी ने पिछली तिमाही में महत्वपूर्ण वित्तीय वृद्धि दर्ज की।", subject: "The company", verb: "reported", object: "significant financial growth" },
                    { id: "pos-h3", english: "Archaeologists discovered ancient artifacts near the river site.", hindi: "पुरातत्वविदों ने नदी के स्थल के पास प्राचीन कलाकृतियों की खोज की।", subject: "Archaeologists", verb: "discovered", object: "ancient artifacts" },
                    { id: "pos-h4", english: "The government implemented new healthcare reforms nationwide.", hindi: "सरकार ने देश भर में नए स्वास्थ्य सुधार लागू किए।", subject: "The government", verb: "implemented", object: "new healthcare reforms" },
                    { id: "pos-h5", english: "The legal team negotiated the contract terms exhaustively.", hindi: "कानूनी टीम ने अनुबंध की शर्तों पर व्यापक बातचीत की।", subject: "The legal team", verb: "negotiated", object: "contract terms exhaustively" },
                    { id: "pos-h6", english: "Scientists conducted a groundbreaking experiment in the laboratory.", hindi: "वैज्ञानिकों ने प्रयोगशाला में एक अभूतपूर्व प्रयोग किया।", subject: "Scientists", verb: "conducted", object: "a groundbreaking experiment" },
                    { id: "pos-h7", english: "The committee unanimously selected the new project director.", hindi: "समिति ने सर्वसम्मति से नए प्रोजेक्ट निदेशक का चयन किया।", subject: "The committee", verb: "selected", object: "the new project director" },
                    { id: "pos-h8", english: "Heavy storm damaged the transmission towers overnight.", hindi: "भारी तूफान ने रात भर में ट्रांसमिशन टावरों को क्षतिग्रस्त कर दिया।", subject: "Heavy storm", verb: "damaged", object: "transmission towers overnight" },
                    { id: "pos-h9", english: "The defense team submitted crucial evidence to the magistrate.", hindi: "बचाव पक्ष की टीम ने मजिस्ट्रेट को महत्वपूर्ण सबूत सौंपे।", subject: "The defense team", verb: "submitted", object: "crucial evidence" },
                    { id: "pos-h10", english: "Software developers resolved the critical security vulnerability.", hindi: "सॉफ्टवेयर डेवलपर्स ने महत्वपूर्ण सुरक्षा भेद्यता को हल किया।", subject: "Software developers", verb: "resolved", object: "critical security vulnerability" }
                ]
            }
        },

        // 6. Negative Sentences / नकारात्मक वाक्य (30 Items)
        negative: {
            title: "Negative Sentences",
            titleHindi: "नकारात्मक वाक्य (Subject + did not + V1)",
            formula: "Subject + did not (didn't) + V1 + Object",
            explanation: "In negative Simple Past sentences, use 'did not' or 'didn't' followed by verb 1st form (V1).",
            explanationHindi: "नकारात्मक वाक्यों में did not / didn't लगाने के बाद मुख्य क्रिया की 1st form (V1) का प्रयोग करें।",
            
            sentences: {
                easy: [
                    { id: "neg-e1", english: "I did not go to school yesterday.", hindi: "मैं कल स्कूल नहीं गया।", subject: "I", aux: "did not", verb: "go", object: "to school yesterday" },
                    { id: "neg-e2", english: "She didn't eat breakfast.", hindi: "उसने नाश्ता नहीं किया।", subject: "She", aux: "didn't", verb: "eat", object: "breakfast" },
                    { id: "neg-e3", english: "They did not play football.", hindi: "उन्होंने फुटबॉल नहीं खेला।", subject: "They", aux: "did not", verb: "play", object: "football" },
                    { id: "neg-e4", english: "We didn't watch the movie.", hindi: "हमने फिल्म नहीं देखी।", subject: "We", aux: "didn't", verb: "watch", object: "the movie" },
                    { id: "neg-e5", english: "He did not write the letter.", hindi: "उसने पत्र नहीं लिखा।", subject: "He", aux: "did not", verb: "write", object: "the letter" },
                    { id: "neg-e6", english: "Rahul didn't call me.", hindi: "राहुल ने मुझे फोन नहीं किया।", subject: "Rahul", aux: "didn't", verb: "call", object: "me" },
                    { id: "neg-e7", english: "You did not finish the work.", hindi: "आपने काम पूरा नहीं किया।", subject: "You", aux: "did not", verb: "finish", object: "the work" },
                    { id: "neg-e8", english: "The bus didn't arrive on time.", hindi: "बस समय पर नहीं आई।", subject: "The bus", aux: "didn't", verb: "arrive", object: "on time" },
                    { id: "neg-e9", english: "She did not like the food.", hindi: "उसे खाना पसंद नहीं आया।", subject: "She", aux: "did not", verb: "like", object: "the food" },
                    { id: "neg-e10", english: "They didn't come to the party.", hindi: "वे पार्टी में नहीं आए।", subject: "They", aux: "didn't", verb: "come", object: "to the party" }
                ],
                medium: [
                    { id: "neg-m1", english: "My father did not buy the old car.", hindi: "मेरे पिता ने पुरानी कार नहीं खरीदी।", subject: "My father", aux: "did not", verb: "buy", object: "the old car" },
                    { id: "neg-m2", english: "She didn't receive the email confirmation.", hindi: "उसे ईमेल पुष्टि प्राप्त नहीं हुई।", subject: "She", aux: "didn't", verb: "receive", object: "the email confirmation" },
                    { id: "neg-m3", english: "The officer did not sign the document.", hindi: "अधिकारी ने दस्तावेज़ पर हस्ताक्षर नहीं किए।", subject: "The officer", aux: "did not", verb: "sign", object: "the document" },
                    { id: "neg-m4", english: "We didn't visit the museum last Sunday.", hindi: "हमने पिछले रविवार संग्रहालय का दौरा नहीं किया।", subject: "We", aux: "didn't", verb: "visit", object: "the museum last Sunday" },
                    { id: "neg-m5", english: "He did not pay the room rent.", hindi: "उसने कमरे का किराया नहीं चुकाया।", subject: "He", aux: "did not", verb: "pay", object: "the room rent" },
                    { id: "neg-m6", english: "The team didn't win the final match.", hindi: "टीम फाइनल मैच नहीं जीती।", subject: "The team", aux: "didn't", verb: "win", object: "the final match" },
                    { id: "neg-m7", english: "They did not inform us about the meeting.", hindi: "उन्होंने हमें बैठक के बारे में सूचित नहीं किया।", subject: "They", aux: "did not", verb: "inform", object: "us about meeting" },
                    { id: "neg-m8", english: "She didn't attend the morning class.", hindi: "वह सुबह की कक्षा में शामिल नहीं हुई।", subject: "She", aux: "didn't", verb: "attend", object: "the morning class" },
                    { id: "neg-m9", english: "The student did not understand the question.", hindi: "छात्र प्रश्न नहीं समझ पाया।", subject: "The student", aux: "did not", verb: "understand", object: "the question" },
                    { id: "neg-m10", english: "I didn't lock the back door properly.", hindi: "मैंने पिछला दरवाजा ठीक से बंद नहीं किया।", subject: "I", aux: "didn't", verb: "lock", object: "the back door" }
                ],
                hard: [
                    { id: "neg-h1", english: "The committee did not accept the proposed policy changes.", hindi: "समिति ने प्रस्तावित नीति परिवर्तनों को स्वीकार नहीं किया।", subject: "The committee", aux: "did not", verb: "accept", object: "proposed policy changes" },
                    { id: "neg-h2", english: "The board didn't approve the annual financial audit.", hindi: "बोर्ड ने वार्षिक वित्तीय लेखापरीक्षा को मंजूरी नहीं दी।", subject: "The board", aux: "didn't", verb: "approve", object: "annual financial audit" },
                    { id: "neg-h3", english: "Engineers did not detect any structural flaws during inspection.", hindi: "निरीक्षण के दौरान इंजीनियरों को कोई संरचनात्मक खामी नहीं मिली।", subject: "Engineers", aux: "did not", verb: "detect", object: "any structural flaws" },
                    { id: "neg-h4", english: "The authority didn't grant permission for the rally.", hindi: "प्राधिकरण ने रैली की अनुमति नहीं दी।", subject: "The authority", aux: "didn't", verb: "grant", object: "permission for the rally" },
                    { id: "neg-h5", english: "Researchers did not find conclusive evidence in the study.", hindi: "शोधकर्ताओं को अध्ययन में निर्णायक सबूत नहीं मिले।", subject: "Researchers", aux: "did not", verb: "find", object: "conclusive evidence" },
                    { id: "neg-h6", english: "The management didn't address worker grievances effectively.", hindi: "प्रबंधन ने श्रमिकों की शिकायतों का प्रभावी ढंग से समाधान नहीं किया।", subject: "Management", aux: "didn't", verb: "address", object: "worker grievances" },
                    { id: "neg-h7", english: "The court did not dismiss the prosecution lawsuit.", hindi: "अदालत ने अभियोजन के मुकदमे को खारिज नहीं किया।", subject: "The court", aux: "did not", verb: "dismiss", object: "the prosecution lawsuit" },
                    { id: "neg-h8", english: "Technicians didn't restore server connectivity until midnight.", hindi: "तकनीशियनों ने आधी रात तक सर्वर कनेक्टिविटी बहाल नहीं की।", subject: "Technicians", aux: "didn't", verb: "restore", object: "server connectivity" },
                    { id: "neg-h9", english: "The audit team did not identify major discrepancies in accounts.", hindi: "ऑडिट टीम ने खातों में बड़ी गड़बड़ियों की पहचान नहीं की।", subject: "Audit team", aux: "did not", verb: "identify", object: "major discrepancies" },
                    { id: "neg-h10", english: "The defense ministry didn't release confidential flight logs.", hindi: "रक्षा मंत्रालय ने गोपनीय उड़ान लॉग जारी नहीं किए।", subject: "Defense ministry", aux: "didn't", verb: "release", object: "confidential flight logs" }
                ]
            }
        },

        // 7. Interrogative Sentences / प्रश्नवाचक वाक्य (30 Items)
        interrogative: {
            title: "Interrogative Sentences",
            titleHindi: "प्रश्नवाचक वाक्य (Did + Subject + V1?)",
            formula: "Did + Subject + V1 + Object?",
            explanation: "In Yes/No Simple Past questions, start with 'Did', followed by Subject and V1 verb.",
            explanationHindi: "प्रश्नवाचक वाक्यों में सबसे पहले 'Did' रखें, फिर Subject और फिर क्रिया की 1st form (V1)।",
            
            sentences: {
                easy: [
                    { id: "int-e1", english: "Did you go to school yesterday?", hindi: "क्या आप कल स्कूल गए?", subject: "you", aux: "Did", verb: "go", object: "to school yesterday?" },
                    { id: "int-e2", english: "Did she eat breakfast?", hindi: "क्या उसने नाश्ता किया?", subject: "she", aux: "Did", verb: "eat", object: "breakfast?" },
                    { id: "int-e3", english: "Did they play football?", hindi: "क्या उन्होंने फुटबॉल खेला?", subject: "they", aux: "Did", verb: "play", object: "football?" },
                    { id: "int-e4", english: "Did we watch the movie?", hindi: "क्या हमने फिल्म देखी?", subject: "we", aux: "Did", verb: "watch", object: "the movie?" },
                    { id: "int-e5", english: "Did he write the letter?", hindi: "क्या उसने पत्र लिखा?", subject: "he", aux: "Did", verb: "write", object: "the letter?" },
                    { id: "int-e6", english: "Did Rahul call you?", hindi: "क्या राहुल ने आपको फोन किया?", subject: "Rahul", aux: "Did", verb: "call", object: "you?" },
                    { id: "int-e7", english: "Did you finish your homework?", hindi: "क्या आपने अपना गृहकार्य पूरा किया?", subject: "you", aux: "Did", verb: "finish", object: "your homework?" },
                    { id: "int-e8", english: "Did the train arrive on time?", hindi: "क्या ट्रेन समय पर आई?", subject: "the train", aux: "Did", verb: "arrive", object: "on time?" },
                    { id: "int-e9", english: "Did she buy a new dress?", hindi: "क्या उसने एक नई पोशाक खरीदी?", subject: "she", aux: "Did", verb: "buy", object: "a new dress?" },
                    { id: "int-e10", english: "Did they come to the meeting?", hindi: "क्या वे बैठक में आए?", subject: "they", aux: "Did", verb: "come", object: "to the meeting?" }
                ],
                medium: [
                    { id: "int-m1", english: "Did your father approve your decision?", hindi: "क्या आपके पिता ने आपके फैसले को मंजूरी दी?", subject: "your father", aux: "Did", verb: "approve", object: "your decision?" },
                    { id: "int-m2", english: "Did she receive the parcel yesterday?", hindi: "क्या उसे कल पार्सल मिला?", subject: "she", aux: "Did", verb: "receive", object: "the parcel yesterday?" },
                    { id: "int-m3", english: "Did the doctor prescribe any medicine?", hindi: "क्या डॉक्टर ने कोई दवा दी?", subject: "the doctor", aux: "Did", verb: "prescribe", object: "any medicine?" },
                    { id: "int-m4", english: "Did you visit the historical museum?", hindi: "क्या आपने ऐतिहासिक संग्रहालय का दौरा किया?", subject: "you", aux: "Did", verb: "visit", object: "the historical museum?" },
                    { id: "int-m5", english: "Did he pay the college fees on time?", hindi: "क्या उसने समय पर कॉलेज की फीस चुकाई?", subject: "he", aux: "Did", verb: "pay", object: "the college fees on time?" },
                    { id: "int-m6", english: "Did the team win the championship?", hindi: "क्या टीम ने चैम्पियनशिप जीती?", subject: "the team", aux: "Did", verb: "win", object: "the championship?" },
                    { id: "int-m7", english: "Did they inform you about the schedule change?", hindi: "क्या उन्होंने आपको समय सारिणी के बदलाव के बारे में सूचित किया?", subject: "they", aux: "Did", verb: "inform", object: "you about schedule change?" },
                    { id: "int-m8", english: "Did she clean her room before leaving?", hindi: "क्या उसने जाने से पहले अपना कमरा साफ किया?", subject: "she", aux: "Did", verb: "clean", object: "her room before leaving?" },
                    { id: "int-m9", english: "Did the manager sign the official contract?", hindi: "क्या प्रबंधक ने आधिकारिक अनुबंध पर हस्ताक्षर किए?", subject: "the manager", aux: "Did", verb: "sign", object: "the official contract?" },
                    { id: "int-m10", english: "Did you lock the main gate last night?", hindi: "क्या आपने बीती रात मुख्य गेट बंद किया?", subject: "you", aux: "Did", verb: "lock", object: "the main gate last night?" }
                ],
                hard: [
                    { id: "int-h1", english: "Did the board of directors approve the new budget?", hindi: "क्या निदेशक मंडल ने नए बजट को मंजूरी दी?", subject: "board of directors", aux: "Did", verb: "approve", object: "the new budget?" },
                    { id: "int-h2", english: "Did the investigators find any substantial clues?", hindi: "क्या जांचकर्ताओं को कोई ठोस सुराग मिले?", subject: "investigators", aux: "Did", verb: "find", object: "any substantial clues?" },
                    { id: "int-h3", english: "Did the government release the official survey report?", hindi: "क्या सरकार ने आधिकारिक सर्वेक्षण रिपोर्ट जारी की?", subject: "the government", aux: "Did", verb: "release", object: "official survey report?" },
                    { id: "int-h4", english: "Did the scientists confirm the lab test results?", hindi: "क्या वैज्ञानिकों ने लैब टेस्ट के परिणामों की पुष्टि की?", subject: "scientists", aux: "Did", verb: "confirm", object: "lab test results?" },
                    { id: "int-h5", english: "Did the magistrate grant bail to the applicant?", hindi: "क्या मजिस्ट्रेट ने आवेदक को जमानत दे दी?", subject: "the magistrate", aux: "Did", verb: "grant", object: "bail to applicant?" },
                    { id: "int-h6", english: "Did the audit team complete the financial verification?", hindi: "क्या ऑडिट टीम ने वित्तीय सत्यापन पूरा किया?", subject: "the audit team", aux: "Did", verb: "complete", object: "financial verification?" },
                    { id: "int-h7", english: "Did the municipality resolve the water supply problem?", hindi: "क्या नगरपालिका ने जलापूर्ति की समस्या का समाधान किया?", subject: "municipality", aux: "Did", verb: "resolve", object: "water supply problem?" },
                    { id: "int-h8", english: "Did telecommunications engineers fix the fiber outage?", hindi: "क्या दूरसंचार इंजीनियरों ने फाइबर आउटेज को ठीक किया?", subject: "telecom engineers", aux: "Did", verb: "fix", object: "the fiber outage?" },
                    { id: "int-h9", english: "Did the international delegation sign the peace treaty?", hindi: "क्या अंतर्राष्ट्रीय प्रतिनिधिमंडल ने शांति संधि पर हस्ताक्षर किए?", subject: "international delegation", aux: "Did", verb: "sign", object: "the peace treaty?" },
                    { id: "int-h10", english: "Did software developers fix the database bug?", hindi: "क्या सॉफ्टवेयर डेवलपर्स ने डेटाबेस बग को ठीक किया?", subject: "software developers", aux: "Did", verb: "fix", object: "the database bug?" }
                ]
            }
        },

        // 8. WH Questions / WH प्रश्न (30 Items)
        whQuestions: {
            title: "WH Questions",
            titleHindi: "WH प्रश्न (WH-word + did + Subject + V1?)",
            formula: "WH-word + did + Subject + V1 + Object?",
            explanation: "In WH Questions, place the WH word at the start, followed by did + Subject + V1.",
            explanationHindi: "WH प्रश्न में सबसे पहले WH शब्द (What, Where, When, Why, How) रखें, फिर did, फिर Subject और V1।",
            
            wordGuide: [
                { word: "What", meaning: "क्या?", usage: "What did you eat?" },
                { word: "Where", meaning: "कहाँ?", usage: "Where did she go?" },
                { word: "When", meaning: "कब?", usage: "When did they arrive?" },
                { word: "Why", meaning: "क्यों?", usage: "Why did he leave early?" },
                { word: "How", meaning: "कैसे?", usage: "How did you solve the problem?" },
                { word: "Who", meaning: "किसने / कौन?", usage: "Who called you? (Subject question: Who + V2)" }
            ],

            sentences: {
                easy: [
                    { id: "wh-e1", english: "What did you eat for breakfast?", hindi: "आपने नाश्ते में क्या खाया?", subject: "you", aux: "did", whWord: "What", verb: "eat", object: "for breakfast?" },
                    { id: "wh-e2", english: "Where did she go yesterday?", hindi: "वह कल कहाँ गई?", subject: "she", aux: "did", whWord: "Where", verb: "go", object: "yesterday?" },
                    { id: "wh-e3", english: "When did they arrive home?", hindi: "वे घर कब पहुंचे?", subject: "they", aux: "did", whWord: "When", verb: "arrive", object: "home?" },
                    { id: "wh-e4", english: "Why did he leave the party early?", hindi: "वह पार्टी से जल्दी क्यों चला गया?", subject: "he", aux: "did", whWord: "Why", verb: "leave", object: "the party early?" },
                    { id: "wh-e5", english: "How did you solve the puzzle?", hindi: "आपने पहेली कैसे हल की?", subject: "you", aux: "did", whWord: "How", verb: "solve", object: "the puzzle?" },
                    { id: "wh-e6", english: "Who called you last night?", hindi: "कल रात आपको किसने फोन किया?", subject: "Who", aux: "", whWord: "Who", verb: "called", object: "you last night?" },
                    { id: "wh-e7", english: "Which movie did you watch?", hindi: "आपने कौन सी फिल्म देखी?", subject: "you", aux: "did", whWord: "Which movie", verb: "watch", object: "?" },
                    { id: "wh-e8", english: "How much money did he spend?", hindi: "उसने कितने पैसे खर्च किए?", subject: "he", aux: "did", whWord: "How much money", verb: "spend", object: "?" },
                    { id: "wh-e9", english: "Whose book did she borrow?", hindi: "उसने किसकी किताब उधार ली?", subject: "she", aux: "did", whWord: "Whose book", verb: "borrow", object: "?" },
                    { id: "wh-e10", english: "What did Rahul say to you?", hindi: "राहुल ने आपसे क्या कहा?", subject: "Rahul", aux: "did", whWord: "What", verb: "say", object: "to you?" }
                ],
                medium: [
                    { id: "wh-m1", english: "Where did you buy this beautiful watch?", hindi: "आपने यह सुंदर घड़ी कहाँ से खरीदी?", subject: "you", aux: "did", whWord: "Where", verb: "buy", object: "this watch?" },
                    { id: "wh-m2", english: "Why did the teacher scold the student?", hindi: "शिक्षक ने छात्र को क्यों डांटा?", subject: "the teacher", aux: "did", whWord: "Why", verb: "scold", object: "the student?" },
                    { id: "wh-m3", english: "When did the company launch its product?", hindi: "कंपनी ने अपना उत्पाद कब लॉन्च किया?", subject: "the company", aux: "did", whWord: "When", verb: "launch", object: "its product?" },
                    { id: "wh-m4", english: "How did they manage to win the match?", hindi: "वे मैच जीतने में कैसे सफल रहे?", subject: "they", aux: "did", whWord: "How", verb: "manage", object: "to win the match?" },
                    { id: "wh-m5", english: "Who broke the glass window?", hindi: "कांच की खिड़की किसने तोड़ी?", subject: "Who", aux: "", whWord: "Who", verb: "broke", object: "the glass window?" },
                    { id: "wh-m6", english: "What did the manager discuss in the meeting?", hindi: "प्रबंधक ने बैठक में क्या चर्चा की?", subject: "the manager", aux: "did", whWord: "What", verb: "discuss", object: "in the meeting?" },
                    { id: "wh-m7", english: "Why did she resign from her job?", hindi: "उसने अपनी नौकरी से इस्तीफा क्यों दिया?", subject: "she", aux: "did", whWord: "Why", verb: "resign", object: "from her job?" },
                    { id: "wh-m8", english: "How many tickets did you book?", hindi: "आपने कितने टिकट बुक किए?", subject: "you", aux: "did", whWord: "How many tickets", verb: "book", object: "?" },
                    { id: "wh-m9", english: "Where did they store the heavy equipment?", hindi: "उन्होंने भारी उपकरण कहाँ रखे?", subject: "they", aux: "did", whWord: "Where", verb: "store", object: "the equipment?" },
                    { id: "wh-m10", english: "When did your brother return from Canada?", hindi: "आपका भाई कनाडा से कब लौटा?", subject: "your brother", aux: "did", whWord: "When", verb: "return", object: "from Canada?" }
                ],
                hard: [
                    { id: "wh-h1", english: "Why did the board reject the investment proposal?", hindi: "बोर्ड ने निवेश प्रस्ताव को क्यों खारिज कर दिया?", subject: "the board", aux: "did", whWord: "Why", verb: "reject", object: "investment proposal?" },
                    { id: "wh-h2", english: "How did the engineers overcome the technical obstacle?", hindi: "इंजीनियरों ने तकनीकी बाधा पर कैसे काबू पाया?", subject: "the engineers", aux: "did", whWord: "How", verb: "overcome", object: "technical obstacle?" },
                    { id: "wh-h3", english: "What key factors influenced the court judgment?", hindi: "अदालत के फैसले को किन प्रमुख कारकों ने प्रभावित किया?", subject: "key factors", aux: "", whWord: "What key factors", verb: "influenced", object: "court judgment?" },
                    { id: "wh-h4", english: "When did the state authority initiate flood relief work?", hindi: "राज्य प्राधिकरण ने बाढ़ राहत कार्य कब शुरू किया?", subject: "state authority", aux: "did", whWord: "When", verb: "initiate", object: "flood relief work?" },
                    { id: "wh-h5", english: "Where did researchers find the historical documents?", hindi: "शोधकर्ताओं को ऐतिहासिक दस्तावेज़ कहाँ मिले?", subject: "researchers", aux: "did", whWord: "Where", verb: "find", object: "historical documents?" },
                    { id: "wh-h6", english: "Who authorized the emergency financial transfer?", hindi: "आपातकालीन वित्तीय हस्तांतरण को किसने अधिकृत किया?", subject: "Who", aux: "", whWord: "Who", verb: "authorized", object: "financial transfer?" },
                    { id: "wh-h7", english: "Why did the system crash during server updates?", hindi: "सर्वर अपडेट के दौरान सिस्टम क्यों क्रैश हो गया?", subject: "the system", aux: "did", whWord: "Why", verb: "crash", object: "during server updates?" },
                    { id: "wh-h8", english: "How did the security team stop the cyber attack?", hindi: "सुरक्षा टीम ने साइबर हमले को कैसे रोका?", subject: "security team", aux: "did", whWord: "How", verb: "stop", object: "the cyber attack?" },
                    { id: "wh-h9", english: "Which strategic options did the council consider?", hindi: "परिषद ने किन रणनीतिक विकल्पों पर विचार किया?", subject: "the council", aux: "did", whWord: "Which options", verb: "consider", object: "?" },
                    { id: "wh-h10", english: "What evidence did prosecution present to the jury?", hindi: "अभियोजन पक्ष ने जूरी के समक्ष क्या सबूत पेश किए?", subject: "prosecution", aux: "did", whWord: "What evidence", verb: "present", object: "to jury?" }
                ]
            }
        },

        // 9. Common Mistakes & Corrections / सामान्य गलतियाँ और सुधार (15 Detailed Mistakes)
        commonMistakes: {
            title: "Common Mistakes",
            titleHindi: "सामान्य गलतियाँ और सही नियम (Common Mistakes & Rationale)",
            introduction: "Avoid these 15 common errors when forming Simple Past sentences.",
            introductionHindi: "Simple Past Tense का प्रयोग करते समय इन 15 सामान्य गलतियों से बचें।",
            
            mistakes: [
                {
                    id: "mistake-1",
                    title: "1. Using V1 in Positive Simple Past",
                    titleHindi: "सकारात्मक वाक्य में V1 का प्रयोग करना",
                    wrong: "I go to Delhi yesterday.",
                    correct: "I went to Delhi yesterday.",
                    explanation: "Positive Simple Past sentences require V2 (went), not V1 (go).",
                    explanationHindi: "सकारात्मक वाक्यों में हमेशा Verb की 2nd form (V2 - went) का प्रयोग करें, V1 (go) का नहीं।",
                    rule: "Positive ➔ Subject + V2"
                },
                {
                    id: "mistake-2",
                    title: "2. Using V3 in Positive Simple Past",
                    titleHindi: "सकारात्मक वाक्य में V3 का प्रयोग करना",
                    wrong: "She gone to Mumbai yesterday.",
                    correct: "She went to Mumbai yesterday.",
                    explanation: "V3 (gone) requires auxiliary verbs like has/have/had. For Simple Past positive, use V2 (went).",
                    explanationHindi: "V3 (gone) बिना has/have/had के नहीं आता। Simple Past Positive में केवल V2 (went) आता है।",
                    rule: "Use V2 (went), not V3 (gone)"
                },
                {
                    id: "mistake-3",
                    title: "3. Using 'did not' with V2 (Double Past)",
                    titleHindi: "did not के साथ V2 का प्रयोग (Double Past की गलती)",
                    wrong: "I did not went there.",
                    correct: "I did not go there.",
                    explanation: "'Did' is already in past form. Using V2 (went) after did is a double-past error. Use V1 (go).",
                    explanationHindi: "'Did' खुद Past रूप है, इसलिए did not के बाद क्रिया दोबारा 2nd form में नहीं आएगी। हमेशा V1 (go) लगाएं।",
                    rule: "did not + V1 (go)"
                },
                {
                    id: "mistake-4",
                    title: "4. Using 'Did' with V3 in Questions",
                    titleHindi: "प्रश्नवाचक वाक्य में Did के साथ V3 का प्रयोग",
                    wrong: "Did you eaten breakfast?",
                    correct: "Did you eat breakfast?",
                    explanation: "After auxiliary verb 'Did', the main verb must be in V1 base form (eat).",
                    explanationHindi: "'Did' से शुरू होने वाले प्रश्नों में क्रिया हमेशा V1 (eat) में होती है, V3 (eaten) में नहीं।",
                    rule: "Did + Subject + V1"
                },
                {
                    id: "mistake-5",
                    title: "5. Using 'didn't' with V2 in Negatives",
                    titleHindi: "didn't के साथ V2 का प्रयोग",
                    wrong: "She didn't called me.",
                    correct: "She didn't call me.",
                    explanation: "After contraction 'didn't', use base form V1 (call), not V2 (called).",
                    explanationHindi: "Contraction 'didn't' के बाद वर्ब 1st Form (V1 - call) आती है, V2 (called) नहीं।",
                    rule: "didn't + V1"
                },
                {
                    id: "mistake-6",
                    title: "6. Using V2 in Interrogative Sentences",
                    titleHindi: "प्रश्नवाचक वाक्य में V2 का प्रयोग करना",
                    wrong: "Did she visited Delhi?",
                    correct: "Did she visit Delhi?",
                    explanation: "When 'Did' is used at the start of a question, the main verb changes back to V1 (visit).",
                    explanationHindi: "जब वाक्य Did से शुरू हो, तो मुख्य क्रिया V2 (visited) से बदलकर वापस V1 (visit) हो जाती है।",
                    rule: "Did + Subject + V1 (visit)"
                },
                {
                    id: "mistake-7",
                    title: "7. Wrong Word Order in WH Questions",
                    titleHindi: "WH प्रश्नों में गलत शब्द क्रम",
                    wrong: "Where you did go yesterday?",
                    correct: "Where did you go yesterday?",
                    explanation: "In WH questions, auxiliary 'did' must come before the subject.",
                    explanationHindi: "WH प्रश्न में auxiliary 'did' हमेशा Subject से पहले आता है।",
                    rule: "WH-word + did + Subject + V1"
                },
                {
                    id: "mistake-8",
                    title: "8. Missing 'did' in WH Questions",
                    titleHindi: "WH प्रश्नों में did का छूट जाना",
                    wrong: "Where you went yesterday?",
                    correct: "Where did you go yesterday?",
                    explanation: "Standard WH questions require the auxiliary verb 'did'.",
                    explanationHindi: "सामान्य WH प्रश्न में 'did' लगाना अनिवार्य है (Where did you go?)।",
                    rule: "WH + did + Subject + V1"
                },
                {
                    id: "mistake-9",
                    title: "9. Incorrect Negative Formation without 'did'",
                    titleHindi: "बिना did के गलत नकारात्मक वाक्य",
                    wrong: "I not went to school.",
                    correct: "I did not go to school.",
                    explanation: "Negative Simple Past requires auxiliary 'did not' before V1.",
                    explanationHindi: "नकारात्मक वाक्य बनाने के लिए 'did not' का प्रयोग अनिवार्य है।",
                    rule: "Subject + did not + V1"
                },
                {
                    id: "mistake-10",
                    title: "10. Adding 'was/were' before V2 in Simple Past",
                    titleHindi: "V2 से पहले अनावश्यक was/were लगाना",
                    wrong: "I was went to Delhi.",
                    correct: "I went to Delhi.",
                    explanation: "Do not mix 'was/were' with V2 main verbs in active Simple Past sentences.",
                    explanationHindi: "Simple Past active voice में main verb (V2) के साथ was/were नहीं लगाया जाता।",
                    rule: "Subject + V2 (No was/were before V2)"
                },
                {
                    id: "mistake-11",
                    title: "11. Confusing V2 and V3 of Irregular Verbs",
                    titleHindi: "V2 और V3 में भ्रम (Irregular Verbs)",
                    wrong: "She has went home. / She wrote the letter yesterday.",
                    correct: "She has gone home. / She wrote the letter yesterday.",
                    explanation: "Use V2 (wrote/went) for Simple Past, and V3 (written/gone) after has/have.",
                    explanationHindi: "Simple Past में V2 (wrote) का प्रयोग करें, और Has/Have के साथ V3 (written) का।",
                    rule: "Simple Past ➔ V2 | Present Perfect ➔ has/have + V3"
                },
                {
                    id: "mistake-12",
                    title: "12. Spelling Errors in Regular V2 Verbs",
                    titleHindi: "Regular Verbs की V2 स्पेलिंग में गलती",
                    wrong: "He playd cricket. / She studyed hard.",
                    correct: "He played cricket. / She studied hard.",
                    explanation: "Play + ed = played. Study ending in consonant + y changes y to i + ed = studied.",
                    explanationHindi: "Play का V2 'played' होता है। Consonant + y वाले शब्दों (study) में y हटकर -ied (studied) लगता है।",
                    rule: "Correct spelling rules for -ed / -ied"
                },
                {
                    id: "mistake-13",
                    title: "13. Incorrect Irregular Verb Conversions",
                    titleHindi: "Irregular Verbs में जबरदस्ती -ed लगाना",
                    wrong: "He buyed a car. / She teached English.",
                    correct: "He bought a car. / She taught English.",
                    explanation: "Irregular verbs do not take -ed. Buy ➔ bought, Teach ➔ taught.",
                    explanationHindi: "Irregular verbs में -ed नहीं लगता। Buy का V2 'bought' और Teach का V2 'taught' होता है।",
                    rule: "Memorize irregular V2 forms"
                },
                {
                    id: "mistake-14",
                    title: "14. Simple Present vs Simple Past Confusion",
                    titleHindi: "Simple Present और Simple Past में भ्रम",
                    wrong: "I live in Delhi in 2015.",
                    correct: "I lived in Delhi in 2015.",
                    explanation: "For past completed time (in 2015), use Simple Past V2 (lived), not V1 (live).",
                    explanationHindi: "बीते वर्ष (in 2015) की बात करने के लिए Simple Past V2 (lived) का प्रयोग करें।",
                    rule: "Past time expression ➔ Simple Past V2"
                },
                {
                    id: "mistake-15",
                    title: "15. Time Expression Collocation Errors",
                    titleHindi: "समय सूचक शब्दों में गलत प्रयोग",
                    wrong: "I visited him yesterday night.",
                    correct: "I visited him last night.",
                    explanation: "Use 'last night' instead of 'yesterday night' in standard English.",
                    explanationHindi: "अंग्रेजी में 'yesterday night' की जगह 'last night' का प्रयोग मानक माना जाता है।",
                    rule: "Use 'last night', 'yesterday morning'"
                }
            ]
        },

        // 10. Summary & Revision / सारांश एवं दोहराव
        summary: {
            title: "Summary & Revision",
            titleHindi: "सारांश एवं दोहराव (Revision Summary)",
            introduction: "Quick summary of Simple Past rules, formulas, and memory markers.",
            introductionHindi: "Simple Past Tense के मुख्य नियमों, सूत्रों और याद रखने योग्य बिंदुओं का त्वरित सारांश।",
            
            goldenRules: [
                "1. Positive Sentences ➔ Subject + V2 (All subjects take V2)",
                "2. Negative Sentences ➔ Subject + did not (didn't) + V1",
                "3. Interrogative Questions ➔ Did + Subject + V1?",
                "4. WH Questions ➔ WH-word + did + Subject + V1?",
                "5. Golden Memory Rule: DID आया ➔ Main Verb V1 में आया!",
                "6. Past Time Signals: yesterday, last night, last week, 2 days ago, in 2020."
            ],

            formulaSummary: {
                positive: "Subject + V2 + Object",
                negative: "Subject + did not + V1 + Object",
                interrogative: "Did + Subject + V1 + Object?",
                whQuestion: "WH-word + did + Subject + V1 + Object?"
            },

            revisionExamples: {
                easy: [
                    { id: "sum-e1", english: "I went to school yesterday.", hindi: "मैं कल स्कूल गया।", note: "Positive with V2 (went)" },
                    { id: "sum-e2", english: "She did not call me.", hindi: "उसने मुझे फोन नहीं किया।", note: "Negative with 'did not' + V1 (call)" },
                    { id: "sum-e3", english: "Did they play cricket?", hindi: "क्या उन्होंने क्रिकेट खेला?", note: "Question starting with 'Did' + V1 (play)" },
                    { id: "sum-e4", english: "Where did you live in 2018?", hindi: "आप 2018 में कहाँ रहते थे?", note: "WH question with 'Where did' + V1 (live)" },
                    { id: "sum-e5", english: "Rahul bought a new bicycle.", hindi: "राहुल ने एक नई साइकिल खरीदी।", note: "Positive V2 (bought)" }
                ],
                medium: [
                    { id: "sum-m1", english: "My father cooked dinner for the family.", hindi: "मेरे पिता ने परिवार के लिए खाना बनाया।", note: "Regular verb V2 (cooked)" },
                    { id: "sum-m2", english: "She didn't receive the official parcel.", hindi: "उसे आधिकारिक पार्सल नहीं मिला।", note: "Negative with didn't + V1 (receive)" },
                    { id: "sum-m3", english: "Did the manager sign the agreement papers?", hindi: "क्या प्रबंधक ने समझौते के कागजात पर हस्ताक्षर किए?", note: "Did + Subject + V1 (sign)" },
                    { id: "sum-m4", english: "Why did he resign from the company?", hindi: "उसने कंपनी से इस्तीफा क्यों दिया?", note: "WH question with 'Why did' + V1 (resign)" },
                    { id: "sum-m5", english: "We visited our native town last summer.", hindi: "हमने पिछली गर्मियों में अपने पैतृक शहर का दौरा किया।", note: "Time marker 'last summer'" }
                ],
                hard: [
                    { id: "sum-h1", english: "The board of directors approved the financial merger unanimously.", hindi: "निदेशक मंडल ने वित्तीय विलय को सर्वसम्मति से मंजूरी दी।", note: "Professional V2 context" },
                    { id: "sum-h2", english: "The audit team did not detect major accounting irregularities.", hindi: "ऑडिट टीम ने खातों की बड़ी गड़बड़ियों की पहचान नहीं की।", note: "Negative did not + V1 (detect)" },
                    { id: "sum-h3", english: "How did telecom technicians resolve the network outage?", hindi: "दूरसंचार तकनीशियनों ने नेटवर्क आउटेज का समाधान कैसे किया?", note: "Complex WH question with 'How did' + V1" },
                    { id: "sum-h4", english: "Who authorized the emergency security deployment?", hindi: "आपातकालीन सुरक्षा तैनाती को किसने अधिकृत किया?", note: "Subject WH question: Who + V2" },
                    { id: "sum-h5", english: "Heavy rain damaged the newly paved highway section overnight.", hindi: "भारी बारिश ने रात भर में नए पक्के राजमार्ग खंड को क्षतिग्रस्त कर दिया।", note: "Positive V2 (damaged)" }
                ]
            }
        },

        // 11. Practice Exercises / अभ्यास (120 Practice Sentences Total)
        exercises: {
            title: "Simple Past Practice Sentences",
            titleHindi: "सामान्य भूतकाल — अभ्यास (120 Practice Sentences)",
            introduction: "Practice all 120 sentences across Positive, Negative, Interrogative, and WH Questions to master Simple Past Tense.",
            introductionHindi: "Simple Past Tense के 120 अभ्यास वाक्यों (सकारात्मक, नकारात्मक, प्रश्नवाचक एवं WH प्रश्न) के माध्यम से पूरा अभ्यास करें।",
            categories: []
        },

        // 12. Quiz Configuration / ज्ञान परीक्षा (12 Quiz Combinations)
        quiz: {
            title: "Simple Past Quiz",
            titleHindi: "सामान्य भूतकाल — ज्ञान परीक्षा",
            questions: []
        }
    }
};

// Initialize categories referencing existing sections (120 Practice Sentences total)
simplePastLesson.sections.exercises.categories = [
    {
        id: "positive",
        title: "Positive Sentences Practice",
        titleHindi: "1. सकारात्मक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Positive Sentence",
        sentences: simplePastLesson.sections.positive.sentences
    },
    {
        id: "negative",
        title: "Negative Sentences Practice",
        titleHindi: "2. नकारात्मक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Negative Sentence",
        sentences: simplePastLesson.sections.negative.sentences
    },
    {
        id: "interrogative",
        title: "Interrogative Sentences Practice",
        titleHindi: "3. प्रश्नवाचक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Yes/No Question",
        sentences: simplePastLesson.sections.interrogative.sentences
    },
    {
        id: "whQuestions",
        title: "WH Questions Practice",
        titleHindi: "4. WH प्रश्न अभ्यास (30 Sentences)",
        typeLabel: "WH Question",
        sentences: simplePastLesson.sections.whQuestions.sentences
    }
];

/**
 * Get the complete Simple Past lesson object
 * @returns {object}
 */
export function getSimplePastLesson() {
    return { ...simplePastLesson };
}

/**
 * Get a specific section of Simple Past lesson data
 * @param {string} sectionName 
 * @returns {object|Array|null}
 */
export function getSimplePastSection(sectionName) {
    if (!sectionName || !simplePastLesson.sections) return null;
    return simplePastLesson.sections[sectionName] || null;
}
