/**
 * Central Lesson Data for Future Perfect Continuous Tense (पूर्ण निरंतर भविष्यत् काल)
 * Single Source of Truth for Future Perfect Continuous Tense Module.
 * Follows proven reference architecture established in completed Tenses.
 */

export const futurePerfectContinuousLesson = {
    id: "future-perfect-continuous",
    title: "Future Perfect Continuous",
    titleHindi: "पूर्ण निरंतर भविष्यत् काल (will have been + V1+ing)",
    description: "Learn Future Perfect Continuous Tense in simple Hindi & English: Subject + will have been + V1+ing + Object/Complement.",

    sections: {
        // 1. Identification / पहचान और अवधारणा
        identification: {
            title: "Identification",
            titleHindi: "पहचान और अवधारणा (Identification & Concept)",
            english: "Future Perfect Continuous Tense is used to describe an action that will have been continuing for a period of time up to a specific point or event in the future.",
            hindi: "Future Perfect Continuous Tense का प्रयोग ऐसे कार्यों के लिए किया जाता है जो भविष्य में किसी निश्चित समय या घटना तक एक निश्चित समय से लगातार जारी रहे होंगे (जारी रहेंगे)।",
            hindiIdentityRule: "पहचान (Hindi Clues): वाक्य के अंत में मुख्य क्रिया के साथ - करता आ रहा होगा, करती आ रही होगी, करते आ रहे होंगे, करता आ रहा होऊँगा, इतने समय से कर रहा होगा (जैसे: 5 घंटे से काम कर रहा होगा, सुबह से पढ़ रही होगी) आता है।",
            points: [
                {
                    english: "Golden Formula: WILL HAVE BEEN + V1+ING for ALL subjects.",
                    hindi: "मुख्य नियम: सभी कर्ताओं (Subject) के साथ केवल 'will have been + V1+ing' का प्रयोग होता है।"
                },
                {
                    english: "Core Concept: Focuses on the duration of an ongoing action up to a future reference point.",
                    hindi: "मुख्य अवधारणा: भविष्य के किसी संदर्भ बिंदु (future reference point) तक कार्य की समयावधि (duration) और निरंतरता पर जोर दिया जाता है।"
                },
                {
                    english: "Auxiliary Verbs: 'will have been' is unchanged for I, You, He, She, It, We, They. Never use 'will has been', 'will had been', or 'will have being'.",
                    hindi: "सहायक क्रियाएँ: कर्ता कोई भी हो, हमेशा 'will have been' ही रहेगा। भूलकर भी 'will has been', 'will had been' या 'will have being' का प्रयोग न करें।"
                },
                {
                    english: "Time Expressions: Often used with FOR (duration), SINCE (starting point), and BY / WHEN (future reference point).",
                    hindi: "समय सूचक शब्द: FOR (अवधि), SINCE (शुरुआती बिंदु), और BY / WHEN (भविष्य का संदर्भ बिंदु) का प्रयोग होता है।"
                },
                {
                    english: "Context-Based: Time markers clarify the exact duration, but context determines the future reference point.",
                    hindi: "संदर्भ-आधारित: समय सूचक शब्द समयावधि को स्पष्ट करते हैं, जबकि संदर्भ भविष्य की समय-सीमा तय करता है।"
                }
            ],
            comparison: {
                title: "Concept Comparison: Simple Future vs Future Continuous vs Future Perfect vs Future Perfect Continuous",
                simpleFuture: {
                    name: "Simple Future",
                    formula: "Subject + will + V1",
                    concept: "Future action/decision (भविष्य का सामान्य कार्य)",
                    example: "I will work tomorrow. (मैं कल काम करूँगा।)"
                },
                futureContinuous: {
                    name: "Future Continuous",
                    formula: "Subject + will be + V1+ing",
                    concept: "Action in progress at a future moment (भविष्य में जारी कार्य)",
                    example: "I will be working at 5 PM. (मैं शाम 5 बजे काम कर रहा होऊँगा।)"
                },
                futurePerfect: {
                    name: "Future Perfect",
                    formula: "Subject + will have + V3",
                    concept: "Action completed before a future time (भविष्य में पूरा हो चुका कार्य)",
                    example: "I will have finished by 5 PM. (मैं शाम 5 बजे तक काम पूरा कर चुका होऊँगा।)"
                },
                futurePerfectContinuous: {
                    name: "Future Perfect Continuous",
                    formula: "Subject + will have been + V1+ing",
                    concept: "Duration of action up to a future point (भविष्य में समय से जारी रहने वाला कार्य)",
                    example: "By 5 PM, I will have been working for 5 hours. (शाम 5 बजे तक मैं 5 घंटे से काम कर रहा होऊँगा।)"
                }
            }
        },

        // 2. Main Uses / प्रमुख उपयोग (Exactly 5 Major Uses)
        uses: {
            title: "Uses & Scenarios",
            titleHindi: "प्रयोग और परिस्थितियाँ (5 Major Uses)",
            list: [
                {
                    id: "use-1",
                    number: 1,
                    title: "Action continuing up to a specific future time",
                    titleHindi: "1. भविष्य के किसी निश्चित समय तक लगातार जारी रहने वाला कार्य",
                    explanation: "Used to describe an ongoing action that will reach a specified duration by a fixed future time point.",
                    explanationHindi: "भविष्य के किसी निश्चित समय (जैसे रात 8 बजे) तक किसी कार्य के लगातार जारी रहने और उसकी समयावधि बताने के लिए।",
                    why: "Emphasizes the duration reached at that future deadline.",
                    whyHindi: "भविष्य की उस सीमा पर कार्य की अवधि पर जोर दिया जाता है।",
                    examples: [
                        { english: "By 8 PM, I will have been working for six hours.", hindi: "रात 8 बजे तक मैं छह घंटे से काम कर रहा होऊँगा।" },
                        { english: "By midnight, he will have been driving for ten hours.", hindi: "आधी रात तक वह दस घंटे से गाड़ी चला रहा होगा।" },
                        { english: "By 5 PM, we will have been studying for four hours.", hindi: "शाम 5 बजे तक हम चार घंटे से पढ़ाई कर रहे होंगे।" }
                    ]
                },
                {
                    id: "use-2",
                    number: 2,
                    title: "Duration with FOR (period of time)",
                    titleHindi: "2. FOR के साथ समयावधि (Duration) का प्रयोग",
                    explanation: "Use 'FOR' when specifying the total length or period of time up to a future point.",
                    explanationHindi: "जब समय की कुल अवधि (जैसे 2 घंटे, 3 महीने, 5 साल) बताई जाए, तब FOR का प्रयोग करें।",
                    why: "FOR + duration (e.g. for two hours, for three years, for ten days).",
                    whyHindi: "FOR समय की अवधि (अवधि = गिनती/मात्रा) बताता है।",
                    examples: [
                        { english: "By next month, she will have been studying here for two years.", hindi: "अगले महीने तक वह यहाँ दो साल से पढ़ाई कर रही होगी।" },
                        { english: "By 6 PM, they will have been playing for three hours.", hindi: "शाम 6 बजे तक वे तीन घंटे से खेल रहे होंगे।" },
                        { english: "By tomorrow, it will have been raining for three days.", hindi: "कल तक तीन दिन से बारिश हो रही होगी।" }
                    ]
                },
                {
                    id: "use-3",
                    number: 3,
                    title: "Starting point with SINCE (point of time)",
                    titleHindi: "3. SINCE के साथ शुरुआती समय (Starting Point) का प्रयोग",
                    explanation: "Use 'SINCE' when specifying the starting point of the ongoing action relative to the future reference.",
                    explanationHindi: "जब कार्य शुरू होने का निश्चित समय (जैसे सुबह से, सोमवार से, जनवरी से) बताया जाए, तब SINCE का प्रयोग करें।",
                    why: "SINCE + starting point (e.g. since morning, since Monday, since 2024, since January).",
                    whyHindi: "SINCE समय का प्रारंभिक बिंदु बताता है।",
                    examples: [
                        { english: "By June, he will have been working here since January.", hindi: "जून तक वह यहाँ जनवरी से काम कर रहा होगा।" },
                        { english: "By 5 PM, I will have been writing since morning.", hindi: "शाम 5 बजे तक मैं सुबह से लिख रहा होऊँगा।" },
                        { english: "By Friday, she will have been practicing since Monday.", hindi: "शुक्रवार तक वह सोमवार से अभ्यास कर रही होगी।" }
                    ]
                },
                {
                    id: "use-4",
                    number: 4,
                    title: "Ongoing activity continuing until a future reference event",
                    titleHindi: "4. भविष्य की किसी अन्य घटना तक जारी रहने वाली गतिविधि",
                    explanation: "Used when one future event occurs while another activity has already been continuing for some time.",
                    explanationHindi: "जब भविष्य की कोई दूसरी घटना घटित होगी, तब तक पहली गतिविधि कुछ समय से चल रही होगी।",
                    why: "Connects a continuous action with another future event or clause.",
                    whyHindi: "एक सतत कार्य को भविष्य की किसी अन्य घटना से जोड़ता है।",
                    examples: [
                        { english: "When you arrive, we will have been waiting for an hour.", hindi: "जब आप पहुँचेंगे, तब हम एक घंटे से इंतज़ार कर रहे होंगे।" },
                        { english: "When the train comes, he will have been standing for two hours.", hindi: "जब ट्रेन आएगी, तब वह दो घंटे से खड़ा रहा होगा।" },
                        { english: "Before the sun sets, they will have been walking for miles.", hindi: "सूरज ढलने से पहले वे मीलों से चल रहे होंगे।" }
                    ]
                },
                {
                    id: "use-5",
                    number: 5,
                    title: "Emphasis on duration of a future ongoing activity",
                    titleHindi: "5. भविष्य की दीर्घकालिक गतिविधि की समयावधि पर विशेष बल",
                    explanation: "Emphasizes long milestone periods of living, working, or studying at a future landmark.",
                    explanationHindi: "भविष्य के किसी पड़ाव (जैसे वर्ष के अंत या अगले साल) पर किसी बड़े मील के पत्थर (milestone) या दीर्घकालिक कार्य की अवधि पर बल देना।",
                    why: "Highlights cumulative effort or persistence over a extended duration.",
                    whyHindi: "दीर्घकालिक प्रयास या निरंतरता को उजागर करता है।",
                    examples: [
                        { english: "By the end of this year, they will have been living in Delhi for five years.", hindi: "इस साल के अंत तक वे दिल्ली में पाँच साल से रह रहे होंगे।" },
                        { english: "By 2030, she will have been teaching for fifteen years.", hindi: "2030 तक वह पंद्रह साल से पढ़ा रही होगी।" },
                        { english: "By next week, I will have been working on this project for six months.", hindi: "अगले हफ्ते तक मैं इस प्रोजेक्ट पर छह महीने से काम कर रहा होऊँगा।" }
                    ]
                }
            ],
            forVsSinceCard: {
                title: "FOR vs SINCE Comparison Guide (समय का सही प्रयोग)",
                titleHindi: "FOR और SINCE के प्रयोग का स्पष्ट अंतर",
                forRules: {
                    heading: "FOR + Duration (समय की अवधि / गिनती)",
                    explanation: "Use FOR when you mention a quantity or length of time (hours, days, months, years).",
                    explanationHindi: "जब समय की संख्या या अवधि बताई जाए (जैसे 2 घंटे, 5 दिन, 3 महीने, 10 साल)।",
                    examples: [
                        "for two hours (दो घंटे से)",
                        "for five days (पाँच दिन से)",
                        "for three months (तीन महीने से)",
                        "for ten years (दस साल से)"
                    ]
                },
                sinceRules: {
                    heading: "SINCE + Starting Point (समय का शुरुआती बिंदु)",
                    explanation: "Use SINCE when you mention the exact starting clock time, day, month, or year.",
                    explanationHindi: "जब समय की शुरुआत का निश्चित नाम या बिंदु बताया जाए (जैसे सुबह से, सोमवार से, जनवरी से, 2024 से)।",
                    examples: [
                        "since morning (सुबह से)",
                        "since Monday (सोमवार से)",
                        "since January (जनवरी से)",
                        "since 2024 (2024 से)",
                        "since 8 AM (सुबह 8 बजे से)"
                    ]
                },
                comparisonExamples: [
                    { english: "By 6 PM, I will have been working for eight hours.", hindi: "शाम 6 बजे तक मैं आठ घंटे से काम कर रहा होऊँगा। (FOR = 8 घंटे की अवधि)" },
                    { english: "By June, I will have been working here since January.", hindi: "जून तक मैं यहाँ जनवरी से काम कर रहा होऊँगा। (SINCE = जनवरी शुरुआती बिंदु)" }
                ]
            }
        },

        // 3. Structure & Formulas / संरचना और सूत्र
        structure: {
            title: "Structure & Formulas",
            titleHindi: "संरचना और सूत्र (Grammar Formulas)",
            formulas: [
                {
                    type: "positive",
                    name: "Positive Formula (सकारात्मक वाक्य)",
                    formula: "Subject + will have been + V1+ing + Object/Complement + (for/since + time)",
                    example: "I will have been working for five hours. (मैं पाँच घंटे से काम कर रहा होऊँगा।)"
                },
                {
                    type: "negative",
                    name: "Negative Formula (नकारात्मक वाक्य)",
                    formula: "Subject + will not have been + V1+ing + Object/Complement + (for/since + time)",
                    contraction: "will not have been → won't have been",
                    example: "I will not have been working for five hours. (मैं पाँच घंटे से काम नहीं कर रहा होऊँगा।)"
                },
                {
                    type: "interrogative",
                    name: "Interrogative Formula (प्रश्नवाचक वाक्य)",
                    formula: "Will + Subject + have been + V1+ing + Object/Complement + (for/since + time)?",
                    example: "Will you have been working for five hours? (क्या आप पाँच घंटे से काम कर रहे होंगे?)"
                },
                {
                    type: "whQuestions",
                    name: "WH Question Formula (WH प्रश्नवाचक वाक्य)",
                    formula: "WH-word + will + Subject + have been + V1+ing + Object/Complement + (for/since + time)?",
                    example: "How long will you have been working here? (आप यहाँ कितने समय से काम कर रहे होंगे?)"
                }
            ],
            breakdown: [
                { component: "Subject", explanation: "I, You, He, She, It, We, They, Singular or Plural Noun" },
                { component: "will", explanation: "Future modal auxiliary verb (Used for ALL subjects)" },
                { component: "have", explanation: "Perfect aspect marker (Always 'have', never 'has' or 'had')" },
                { component: "been", explanation: "Continuous aspect linking verb (Past participle of 'be')" },
                { component: "V1+ing", explanation: "Present Participle Form of Main Verb (e.g. working, studying, living)" },
                { component: "Object / Complement", explanation: "Rest of the sentence / Direct or Indirect Object" },
                { component: "Time Expression", explanation: "For + duration OR Since + starting point (optional context marker)" }
            ]
        },

        // 4. Subject + Verb Rules / कर्ता और क्रिया के नियम
        subjectVerbRules: {
            title: "Subject + Verb Rules",
            titleHindi: "कर्ता और क्रिया के नियम (Universal Auxiliary Rule)",
            goldenRule: "GOLDEN RULE: ALL SUBJECTS USE 'WILL HAVE BEEN + V1+ING'",
            goldenRuleHindi: "स्वर्णिम नियम: सभी कर्ताओं के साथ केवल 'WILL HAVE BEEN + V1+ING' का प्रयोग होता है।",
            table: [
                { subject: "I", auxiliary: "will have been", verbForm: "V1+ing", example: "I will have been working" },
                { subject: "You", auxiliary: "will have been", verbForm: "V1+ing", example: "You will have been working" },
                { subject: "He", auxiliary: "will have been", verbForm: "V1+ing", example: "He will have been working" },
                { subject: "She", auxiliary: "will have been", verbForm: "V1+ing", example: "She will have been working" },
                { subject: "It", auxiliary: "will have been", verbForm: "V1+ing", example: "It will have been raining" },
                { subject: "We", auxiliary: "will have been", verbForm: "V1+ing", example: "We will have been working" },
                { subject: "They", auxiliary: "will have been", verbForm: "V1+ing", example: "They will have been working" }
            ],
            notes: [
                "There is NO 'will has been' in English grammar.",
                "There is NO 'will had been' in English grammar.",
                "There is NO 'will have being' in English grammar.",
                "Never use V1, V2, or V3 directly after 'will have been'. Always use V1+ing."
            ],
            spellingRules: {
                title: "V1+ING Spelling Rules (स्पेलिंग नियम)",
                rules: [
                    {
                        rule: "General Rule (सामान्य नियम): Add -ing directly to V1",
                        examples: [
                            { base: "work", ing: "working" },
                            { base: "study", ing: "studying" },
                            { base: "play", ing: "playing" },
                            { base: "read", ing: "reading" }
                        ]
                    },
                    {
                        rule: "Verbs ending in Silent 'e': Drop 'e' and add -ing",
                        examples: [
                            { base: "write", ing: "writing" },
                            { base: "make", ing: "making" },
                            { base: "live", ing: "living" },
                            { base: "drive", ing: "driving" }
                        ]
                    },
                    {
                        rule: "Short vowel + Single consonant: Double the final consonant and add -ing",
                        examples: [
                            { base: "run", ing: "running" },
                            { base: "sit", ing: "sitting" },
                            { base: "swim", ing: "swimming" },
                            { base: "begin", ing: "beginning" },
                            { base: "travel", ing: "traveling" }
                        ]
                    },
                    {
                        rule: "Verbs ending in 'ie': Change 'ie' to 'y' and add -ing",
                        examples: [
                            { base: "lie", ing: "lying" },
                            { base: "die", ing: "dying" }
                        ]
                    }
                ],
                incorrectVsCorrect: [
                    { wrong: "will have been worked", correct: "will have been working", explanation: "Use V1+ing, not V2/V3" },
                    { wrong: "will have been studied", correct: "will have been studying", explanation: "Use V1+ing, not V3" },
                    { wrong: "will have been wrote", correct: "will have been writing", explanation: "Use V1+ing, not V2" },
                    { wrong: "will have been ran", correct: "will have been running", explanation: "Use V1+ing, double consonant" }
                ]
            }
        },

        // 5. Positive Sentences (Exactly 30 sentences: 10 Easy, 10 Med, 10 Hard)
        positive: {
            title: "Positive Sentences",
            titleHindi: "सकारात्मक वाक्य (Positive Practice)",
            description: "Practice 30 Positive Sentences using 'Subject + will have been + V1+ing'.",
            easy: [
                { id: "pos-e1", english: "I will have been working for five hours.", hindi: "मैं पाँच घंटे से काम कर रहा होऊँगा।", subject: "I", verb: "working", object: "for five hours" },
                { id: "pos-e2", english: "She will have been studying since morning.", hindi: "वह सुबह से पढ़ाई कर रही होगी।", subject: "She", verb: "studying", object: "since morning" },
                { id: "pos-e3", english: "They will have been living here for ten years.", hindi: "वे यहाँ दस साल से रह रहे होंगे।", subject: "They", verb: "living", object: "here for ten years" },
                { id: "pos-e4", english: "He will have been waiting for two hours.", hindi: "वह दो घंटे से इंतज़ार कर रहा होगा।", subject: "He", verb: "waiting", object: "for two hours" },
                { id: "pos-e5", english: "We will have been playing for an hour.", hindi: "हम एक घंटे से खेल रहे होंगे।", subject: "We", verb: "playing", object: "for an hour" },
                { id: "pos-e6", english: "You will have been reading since 8 AM.", hindi: "आप सुबह 8 बजे से पढ़ रहे होंगे।", subject: "You", verb: "reading", object: "since 8 AM" },
                { id: "pos-e7", english: "It will have been raining for three days.", hindi: "तीन दिन से बारिश हो रही होगी।", subject: "It", verb: "raining", object: "for three days" },
                { id: "pos-e8", english: "Rohan will have been sleeping for eight hours.", hindi: "रोहन आठ घंटे से सो रहा होगा।", subject: "Rohan", verb: "sleeping", object: "for eight hours" },
                { id: "pos-e9", english: "Priya will have been cooking since noon.", hindi: "प्रिया दोपहर से खाना बना रही होगी।", subject: "Priya", verb: "cooking", object: "since noon" },
                { id: "pos-e10", english: "The boys will have been running for thirty minutes.", hindi: "लड़के तीस मिनट से दौड़ रहे होंगे।", subject: "The boys", verb: "running", object: "for thirty minutes" }
            ],
            medium: [
                { id: "pos-m1", english: "By 6 PM, I will have been writing this report for three hours.", hindi: "शाम 6 बजे तक मैं तीन घंटे से यह रिपोर्ट लिख रहा होऊँगा।", subject: "I", verb: "writing", object: "this report for three hours" },
                { id: "pos-m2", english: "By next month, she will have been teaching here for five years.", hindi: "अगले महीने तक वह यहाँ पाँच साल से पढ़ा रही होगी।", subject: "She", verb: "teaching", object: "here for five years" },
                { id: "pos-m3", english: "By 8 PM, they will have been driving for ten hours straight.", hindi: "रात 8 बजे तक वे लगातार दस घंटे से गाड़ी चला रहे होंगे।", subject: "They", verb: "driving", object: "for ten hours straight" },
                { id: "pos-m4", english: "By June, he will have been working in Mumbai since January.", hindi: "जून तक वह मुंबई में जनवरी से काम कर रहा होगा।", subject: "He", verb: "working", object: "in Mumbai since January" },
                { id: "pos-m5", english: "By tomorrow, we will have been practicing for a week.", hindi: "कल तक हम एक हफ्ते से अभ्यास कर रहे होंगे।", subject: "We", verb: "practicing", object: "for a week" },
                { id: "pos-m6", english: "When you arrive, I will have been preparing dinner for an hour.", hindi: "जब आप पहुँचेंगे, तब मैं एक घंटे से रात का खाना बना रहा होऊँगा।", subject: "I", verb: "preparing", object: "dinner for an hour" },
                { id: "pos-m7", english: "By 5 PM, the team will have been discussing the plan since 2 PM.", hindi: "शाम 5 बजे तक टीम दोपहर 2 बजे से योजना पर चर्चा कर रही होगी।", subject: "The team", verb: "discussing", object: "the plan since 2 PM" },
                { id: "pos-m8", english: "By next year, my brother will have been studying medicine for three years.", hindi: "अगले साल तक मेरा भाई तीन साल से डॉक्टरी की पढ़ाई कर रहा होगा।", subject: "My brother", verb: "studying", object: "medicine for three years" },
                { id: "pos-m9", english: "By sunset, the farmers will have been harvesting wheat for eight hours.", hindi: "सूर्यास्त तक किसान आठ घंटे से गेहूं की कटाई कर रहे होंगे।", subject: "The farmers", verb: "harvesting", object: "wheat for eight hours" },
                { id: "pos-m10", english: "By 10 PM, she will have been listening to music since evening.", hindi: "रात 10 बजे तक वह शाम से संगीत सुन रही होगी।", subject: "She", verb: "listening", object: "to music since evening" }
            ],
            hard: [
                { id: "pos-h1", english: "By the end of this year, they will have been living in Delhi for a decade.", hindi: "इस साल के अंत तक वे दिल्ली में एक दशक (दस साल) से रह रहे होंगे।", subject: "They", verb: "living", object: "in Delhi for a decade" },
                { id: "pos-h2", english: "When the clock strikes midnight, we will have been celebrating for five hours.", hindi: "जब घड़ी में आधी रात का समय होगा, तब हम पाँच घंटे से जश्न मना रहे होंगे।", subject: "We", verb: "celebrating", object: "for five hours" },
                { id: "pos-h3", english: "By the time he graduates, Vikas will have been researching AI for four years.", hindi: "उसके स्नातक पूरा करने तक, विकास चार साल से एआई पर शोध कर रहा होगा।", subject: "Vikas", verb: "researching", object: "AI for four years" },
                { id: "pos-h4", english: "By October, the company will have been expanding its operations for two years.", hindi: "अक्टूबर तक कंपनी दो साल से अपने परिचालन का विस्तार कर रही होगी।", subject: "The company", verb: "expanding", object: "its operations for two years" },
                { id: "pos-h5", english: "When the train arrives at the station, the passengers will have been traveling for twenty hours.", hindi: "जब ट्रेन स्टेशन पर पहुँचेगी, तब यात्री बीस घंटे से यात्रा कर रहे होंगे।", subject: "The passengers", verb: "traveling", object: "for twenty hours" },
                { id: "pos-h6", english: "By next summer, I will have been learning Japanese for three whole years.", hindi: "अगली गर्मियों तक मैं पूरे तीन साल से जापानी सीख रहा होऊँगा।", subject: "I", verb: "learning", object: "Japanese for three whole years" },
                { id: "pos-h7", english: "By the end of the day, the construction workers will have been building the bridge for twelve hours.", hindi: "दिन के अंत तक निर्माण मजदूर बारह घंटे से पुल का निर्माण कर रहे होंगे।", subject: "The construction workers", verb: "building", object: "the bridge for twelve hours" },
                { id: "pos-h8", english: "Before you complete your degree, she will have been managing the project since 2023.", hindi: "आपकी डिग्री पूरी होने से पहले, वह 2023 से प्रोजेक्ट का प्रबंधन कर रही होगी।", subject: "She", verb: "managing", object: "the project since 2023" },
                { id: "pos-h9", english: "By 2030, scientists will have been studying this climate pattern for fifty years.", hindi: "2030 तक वैज्ञानिक पचास वर्षों से इस जलवायु पैटर्न का अध्ययन कर रहे होंगे।", subject: "Scientists", verb: "studying", object: "this climate pattern for fifty years" },
                { id: "pos-h10", english: "When you finally reach the venue, the band will have been performing for two hours.", hindi: "जब आप अंततः कार्यक्रम स्थल पर पहुँचेंगे, तब बैंड दो घंटे से प्रस्तुति दे रहा होगा।", subject: "The band", verb: "performing", object: "for two hours" }
            ]
        },

        // 6. Negative Sentences (Exactly 30 sentences: 10 Easy, 10 Med, 10 Hard)
        negative: {
            title: "Negative Sentences",
            titleHindi: "नकारात्मक वाक्य (Negative Practice)",
            description: "Practice 30 Negative Sentences using 'Subject + will not have been + V1+ing' (won't have been).",
            easy: [
                { id: "neg-e1", english: "I will not have been working for five hours.", hindi: "मैं पाँच घंटे से काम नहीं कर रहा होऊँगा।", subject: "I", aux: "will not have been", verb: "working", object: "for five hours" },
                { id: "neg-e2", english: "She won't have been studying since morning.", hindi: "वह सुबह से पढ़ाई नहीं कर रही होगी।", subject: "She", aux: "won't have been", verb: "studying", object: "since morning" },
                { id: "neg-e3", english: "They will not have been living here for ten years.", hindi: "वे यहाँ दस साल से नहीं रह रहे होंगे।", subject: "They", aux: "will not have been", verb: "living", object: "here for ten years" },
                { id: "neg-e4", english: "He won't have been waiting for two hours.", hindi: "वह दो घंटे से इंतज़ार नहीं कर रहा होगा।", subject: "He", aux: "won't have been", verb: "waiting", object: "for two hours" },
                { id: "neg-e5", english: "We will not have been playing for an hour.", hindi: "हम एक घंटे से नहीं खेल रहे होंगे।", subject: "We", aux: "will not have been", verb: "playing", object: "for an hour" },
                { id: "neg-e6", english: "You won't have been reading since 8 AM.", hindi: "आप सुबह 8 बजे से नहीं पढ़ रहे होंगे।", subject: "You", aux: "won't have been", verb: "reading", object: "since 8 AM" },
                { id: "neg-e7", english: "It will not have been raining for three days.", hindi: "तीन दिन से बारिश नहीं हो रही होगी।", subject: "It", aux: "will not have been", verb: "raining", object: "for three days" },
                { id: "neg-e8", english: "Rohan won't have been sleeping for eight hours.", hindi: "रोहन आठ घंटे से नहीं सो रहा होगा।", subject: "Rohan", aux: "won't have been", verb: "sleeping", object: "for eight hours" },
                { id: "neg-e9", english: "Priya will not have been cooking since noon.", hindi: "प्रिया दोपहर से खाना नहीं बना रही होगी।", subject: "Priya", aux: "will not have been", verb: "cooking", object: "since noon" },
                { id: "neg-e10", english: "The boys won't have been running for thirty minutes.", hindi: "लड़के तीस मिनट से नहीं दौड़ रहे होंगे।", subject: "The boys", aux: "won't have been", verb: "running", object: "for thirty minutes" }
            ],
            medium: [
                { id: "neg-m1", english: "By 6 PM, I won't have been writing for three hours.", hindi: "शाम 6 बजे तक मैं तीन घंटे से नहीं लिख रहा होऊँगा।", subject: "I", aux: "won't have been", verb: "writing", object: "for three hours" },
                { id: "neg-m2", english: "By next month, she will not have been teaching here for long.", hindi: "अगले महीने तक वह यहाँ लंबे समय से नहीं पढ़ा रही होगी।", subject: "She", aux: "will not have been", verb: "teaching", object: "here for long" },
                { id: "neg-m3", english: "By 8 PM, they won't have been driving for ten hours.", hindi: "रात 8 बजे तक वे दस घंटे से गाड़ी नहीं चला रहे होंगे।", subject: "They", aux: "won't have been", verb: "driving", object: "for ten hours" },
                { id: "neg-m4", english: "By June, he will not have been working here since January.", hindi: "जून तक वह यहाँ जनवरी से काम नहीं कर रहा होगा।", subject: "He", aux: "will not have been", verb: "working", object: "here since January" },
                { id: "neg-m5", english: "By tomorrow, we won't have been practicing for a week.", hindi: "कल तक हम एक हफ्ते से अभ्यास नहीं कर रहे होंगे।", subject: "We", aux: "won't have been", verb: "practicing", object: "for a week" },
                { id: "neg-m6", english: "When you arrive, I will not have been waiting for very long.", hindi: "जब आप पहुँचेंगे, तब मैं बहुत देर से इंतज़ार नहीं कर रहा होऊँगा।", subject: "I", aux: "will not have been", verb: "waiting", object: "for very long" },
                { id: "neg-m7", english: "By 5 PM, the team won't have been discussing the issue for hours.", hindi: "शाम 5 बजे तक टीम घंटों से मुद्दे पर चर्चा नहीं कर रही होगी।", subject: "The team", aux: "won't have been", verb: "discussing", object: "the issue for hours" },
                { id: "neg-m8", english: "By next year, my brother will not have been studying medicine for long.", hindi: "अगले साल तक मेरा भाई लंबे समय से डॉक्टरी की पढ़ाई नहीं कर रहा होगा।", subject: "My brother", aux: "will not have been", verb: "studying", object: "medicine for long" },
                { id: "neg-m9", english: "By sunset, the farmers won't have been working without a break.", hindi: "सूर्यास्त तक किसान बिना ब्रेक के काम नहीं कर रहे होंगे।", subject: "The farmers", aux: "won't have been", verb: "working", object: "without a break" },
                { id: "neg-m10", english: "By 10 PM, she will not have been listening to music all day.", hindi: "रात 10 बजे तक वह पूरे दिन से संगीत नहीं सुन रही होगी।", subject: "She", aux: "will not have been", verb: "listening", object: "to music all day" }
            ],
            hard: [
                { id: "neg-h1", english: "By the end of this year, they won't have been living in Delhi for five years.", hindi: "इस साल के अंत तक वे दिल्ली में पाँच साल से नहीं रह रहे होंगे।", subject: "They", aux: "won't have been", verb: "living", object: "in Delhi for five years" },
                { id: "neg-h2", english: "When the clock strikes midnight, we will not have been celebrating for long.", hindi: "जब आधी रात होगी, तब हम लंबे समय से जश्न नहीं मना रहे होंगे।", subject: "We", aux: "will not have been", verb: "celebrating", object: "for long" },
                { id: "neg-h3", english: "By the time he graduates, Vikas won't have been researching AI for four years.", hindi: "उसके स्नातक पूरा करने तक, विकास चार साल से एआई पर शोध नहीं कर रहा होगा।", subject: "Vikas", aux: "won't have been", verb: "researching", object: "AI for four years" },
                { id: "neg-h4", english: "By October, the company will not have been operating at a loss for two years.", hindi: "अक्टूबर तक कंपनी दो साल से घाटे में काम नहीं कर रही होगी।", subject: "The company", aux: "will not have been", verb: "operating", object: "at a loss for two years" },
                { id: "neg-h5", english: "When the train arrives, the passengers won't have been waiting for more than an hour.", hindi: "जब ट्रेन आएगी, तब यात्री एक घंटे से अधिक समय से इंतज़ार नहीं कर रहे होंगे।", subject: "The passengers", aux: "won't have been", verb: "waiting", object: "for more than an hour" },
                { id: "neg-h6", english: "By next summer, I will not have been learning Japanese for five years.", hindi: "अगली गर्मियों तक मैं पाँच साल से जापानी नहीं सीख रहा होऊँगा।", subject: "I", aux: "will not have been", verb: "learning", object: "Japanese for five years" },
                { id: "neg-h7", english: "By the end of the day, workers won't have been digging the trench continuously.", hindi: "दिन के अंत तक मजदूर लगातार गड्ढा नहीं खोद रहे होंगे।", subject: "Workers", aux: "won't have been", verb: "digging", object: "the trench continuously" },
                { id: "neg-h8", english: "Before you complete your degree, she will not have been managing the unit for ten years.", hindi: "आपकी डिग्री पूरी होने से पहले, वह दस साल से इकाई का प्रबंधन नहीं कर रही होगी।", subject: "She", aux: "will not have been", verb: "managing", object: "the unit for ten years" },
                { id: "neg-h9", english: "By 2030, scientists won't have been studying this virus for long.", hindi: "2030 तक वैज्ञानिक इस वायरस का लंबे समय से अध्ययन नहीं कर रहे होंगे।", subject: "Scientists", aux: "won't have been", verb: "studying", object: "this virus for long" },
                { id: "neg-h10", english: "When you finally reach, the speaker will not have been addressing the audience for hours.", hindi: "जब आप अंततः पहुँचेंगे, तब वक्ता घंटों से दर्शकों को संबोधित नहीं कर रहा होगा।", subject: "The speaker", aux: "will not have been", verb: "addressing", object: "the audience for hours" }
            ]
        },

        // 7. Interrogative Sentences (Exactly 30 sentences: 10 Easy, 10 Med, 10 Hard)
        interrogative: {
            title: "Interrogative Sentences",
            titleHindi: "प्रश्नवाचक वाक्य (Interrogative Practice)",
            description: "Practice 30 Interrogative Sentences using 'Will + Subject + have been + V1+ing?'.",
            easy: [
                { id: "int-e1", english: "Will you have been working for five hours?", hindi: "क्या आप पाँच घंटे से काम कर रहे होंगे?", subject: "you", verb: "working", object: "for five hours", shortAns: "Yes, I will. / No, I won't." },
                { id: "int-e2", english: "Will she have been studying since morning?", hindi: "क्या वह सुबह से पढ़ाई कर रही होगी?", subject: "she", verb: "studying", object: "since morning", shortAns: "Yes, she will. / No, she won't." },
                { id: "int-e3", english: "Will they have been living here for ten years?", hindi: "क्या वे यहाँ दस साल से रह रहे होंगे?", subject: "they", verb: "living", object: "here for ten years", shortAns: "Yes, they will. / No, they won't." },
                { id: "int-e4", english: "Will he have been waiting for two hours?", hindi: "क्या वह दो घंटे से इंतज़ार कर रहा होगा?", subject: "he", verb: "waiting", object: "for two hours", shortAns: "Yes, he will. / No, he won't." },
                { id: "int-e5", english: "Will we have been playing for an hour?", hindi: "क्या हम एक घंटे से खेल रहे होंगे?", subject: "we", verb: "playing", object: "for an hour", shortAns: "Yes, we will. / No, we won't." },
                { id: "int-e6", english: "Will you have been reading since 8 AM?", hindi: "क्या आप सुबह 8 बजे से पढ़ रहे होंगे?", subject: "you", verb: "reading", object: "since 8 AM", shortAns: "Yes, I will. / No, I won't." },
                { id: "int-e7", english: "Will it have been raining for three days?", hindi: "क्या तीन दिन से बारिश हो रही होगी?", subject: "it", verb: "raining", object: "for three days", shortAns: "Yes, it will. / No, it won't." },
                { id: "int-e8", english: "Will Rohan have been sleeping for eight hours?", hindi: "क्या रोहन आठ घंटे से सो रहा होगा?", subject: "Rohan", verb: "sleeping", object: "for eight hours", shortAns: "Yes, he will. / No, he won't." },
                { id: "int-e9", english: "Will Priya have been cooking since noon?", hindi: "क्या प्रिया दोपहर से खाना बना रही होगी?", subject: "Priya", verb: "cooking", object: "since noon", shortAns: "Yes, she will. / No, she won't." },
                { id: "int-e10", english: "Will the boys have been running for thirty minutes?", hindi: "क्या लड़के तीस मिनट से दौड़ रहे होंगे?", subject: "the boys", verb: "running", object: "for thirty minutes", shortAns: "Yes, they will. / No, they won't." }
            ],
            medium: [
                { id: "int-m1", english: "By 6 PM, will you have been writing for three hours?", hindi: "क्या शाम 6 बजे तक आप तीन घंटे से लिख रहे होंगे?", subject: "you", verb: "writing", object: "for three hours", shortAns: "Yes, I will. / No, I won't." },
                { id: "int-m2", english: "By next month, will she have been teaching here for two years?", hindi: "क्या अगले महीने तक वह यहाँ दो साल से पढ़ा रही होगी?", subject: "she", verb: "teaching", object: "here for two years", shortAns: "Yes, she will. / No, she won't." },
                { id: "int-m3", english: "By 8 PM, will they have been driving for ten hours?", hindi: "क्या रात 8 बजे तक वे दस घंटे से गाड़ी चला रहे होंगे?", subject: "they", verb: "driving", object: "for ten hours", shortAns: "Yes, they will. / No, they won't." },
                { id: "int-m4", english: "By June, will he have been working here since January?", hindi: "क्या जून तक वह यहाँ जनवरी से काम कर रहा होगा?", subject: "he", verb: "working", object: "here since January", shortAns: "Yes, he will. / No, he won't." },
                { id: "int-m5", english: "By tomorrow, will we have been practicing for a week?", hindi: "क्या कल तक हम एक हफ्ते से अभ्यास कर रहे होंगे?", subject: "we", verb: "practicing", object: "for a week", shortAns: "Yes, we will. / No, we won't." },
                { id: "int-m6", english: "When I arrive, will you have been waiting for an hour?", hindi: "जब मैं पहुँचूँगा, क्या आप एक घंटे से इंतज़ार कर रहे होंगे?", subject: "you", verb: "waiting", object: "for an hour", shortAns: "Yes, I will. / No, I won't." },
                { id: "int-m7", english: "By 5 PM, will the team have been discussing the plan since noon?", hindi: "क्या शाम 5 बजे तक टीम दोपहर से योजना पर चर्चा कर रही होगी?", subject: "the team", verb: "discussing", object: "the plan since noon", shortAns: "Yes, it will. / No, it won't." },
                { id: "int-m8", english: "By next year, will your brother have been studying medicine for three years?", hindi: "क्या अगले साल तक आपका भाई तीन साल से डॉक्टरी की पढ़ाई कर रहा होगा?", subject: "your brother", verb: "studying", object: "medicine for three years", shortAns: "Yes, he will. / No, he won't." },
                { id: "int-m9", english: "By sunset, will the farmers have been harvesting wheat for eight hours?", hindi: "क्या सूर्यास्त तक किसान आठ घंटे से गेहूं की कटाई कर रहे होंगे?", subject: "the farmers", verb: "harvesting", object: "wheat for eight hours", shortAns: "Yes, they will. / No, they won't." },
                { id: "int-m10", english: "By 10 PM, will she have been listening to music since evening?", hindi: "क्या रात 10 बजे तक वह शाम से संगीत सुन रही होगी?", subject: "she", verb: "listening", object: "to music since evening", shortAns: "Yes, she will. / No, she won't." }
            ],
            hard: [
                { id: "int-h1", english: "By the end of this year, will they have been living in Delhi for five years?", hindi: "क्या इस साल के अंत तक वे दिल्ली में पाँच साल से रह रहे होंगे?", subject: "they", verb: "living", object: "in Delhi for five years", shortAns: "Yes, they will. / No, they won't." },
                { id: "int-h2", english: "When midnight arrives, will we have been celebrating for five hours?", hindi: "जब आधी रात होगी, क्या हम पाँच घंटे से जश्न मना रहे होंगे?", subject: "we", verb: "celebrating", object: "for five hours", shortAns: "Yes, we will. / No, we won't." },
                { id: "int-h3", english: "By graduation, will Vikas have been researching AI for four years?", hindi: "क्या स्नातक तक विकास चार साल से एआई पर शोध कर रहा होगा?", subject: "Vikas", verb: "researching", object: "AI for four years", shortAns: "Yes, he will. / No, he won't." },
                { id: "int-h4", english: "By October, will the company have been expanding operations for two years?", hindi: "क्या अक्टूबर तक कंपनी दो साल से परिचालन का विस्तार कर रही होगी?", subject: "the company", verb: "expanding", object: "operations for two years", shortAns: "Yes, it will. / No, it won't." },
                { id: "int-h5", english: "When the train arrives, will passengers have been waiting for twenty hours?", hindi: "क्या ट्रेन आने पर यात्री बीस घंटे से इंतज़ार कर रहे होंगे?", subject: "passengers", verb: "waiting", object: "for twenty hours", shortAns: "Yes, they will. / No, they won't." },
                { id: "int-h6", english: "By next summer, will you have been learning Japanese for three years?", hindi: "क्या अगली गर्मियों तक आप तीन साल से जापानी सीख रहे होंगे?", subject: "you", verb: "learning", object: "Japanese for three years", shortAns: "Yes, I will. / No, I won't." },
                { id: "int-h7", english: "By day end, will workers have been building the bridge for twelve hours?", hindi: "क्या दिन के अंत तक मजदूर बारह घंटे से पुल बना रहे होंगे?", subject: "workers", verb: "building", object: "the bridge for twelve hours", shortAns: "Yes, they will. / No, they won't." },
                { id: "int-h8", english: "Before degree completion, will she have been managing the project since 2023?", hindi: "डिग्री पूरी होने से पहले, क्या वह 2023 से प्रोजेक्ट संभाल रही होगी?", subject: "she", verb: "managing", object: "the project since 2023", shortAns: "Yes, she will. / No, she won't." },
                { id: "int-h9", english: "By 2030, will scientists have been studying this climate pattern for fifty years?", hindi: "क्या 2030 तक वैज्ञानिक पचास साल से इस जलवायु पैटर्न का अध्ययन कर रहे होंगे?", subject: "scientists", verb: "studying", object: "this climate pattern for fifty years", shortAns: "Yes, they will. / No, they won't." },
                { id: "int-h10", english: "When you arrive, will the band have been performing for two hours?", hindi: "जब आप पहुँचेंगे, क्या बैंड दो घंटे से प्रस्तुति दे रहा होगा?", subject: "the band", verb: "performing", object: "for two hours", shortAns: "Yes, it will. / No, it won't." }
            ]
        },

        // 8. WH Questions (Exactly 30 sentences: 10 Easy, 10 Med, 10 Hard)
        whQuestions: {
            title: "WH Questions",
            titleHindi: "WH प्रश्न (WH Question Practice)",
            description: "Practice 30 WH Questions using 'WH-word + will + Subject + have been + V1+ing?'. High emphasis on 'How long'.",
            easy: [
                { id: "wh-e1", english: "How long will you have been working here?", hindi: "आप यहाँ कितने समय से काम कर रहे होंगे?", whWord: "How long", subject: "you", verb: "working", object: "here" },
                { id: "wh-e2", english: "How long will she have been studying?", hindi: "वह कितने समय से पढ़ाई कर रही होगी?", whWord: "How long", subject: "she", verb: "studying", object: "" },
                { id: "wh-e3", english: "What will they have been doing all day?", hindi: "वे पूरे दिन क्या करते आ रहे होंगे?", whWord: "What", subject: "they", verb: "doing", object: "all day" },
                { id: "wh-e4", english: "Where will he have been living by next year?", hindi: "अगले साल तक वह कहाँ रह रहा होगा?", whWord: "Where", subject: "he", verb: "living", object: "by next year" },
                { id: "wh-e5", english: "Why will you have been waiting so long?", hindi: "आप इतनी देर से इंतज़ार क्यों कर रहे होंगे?", whWord: "Why", subject: "you", verb: "waiting", object: "so long" },
                { id: "wh-e6", english: "How long will it have been raining by tomorrow?", hindi: "कल तक कितने समय से बारिश हो रही होगी?", whWord: "How long", subject: "it", verb: "raining", object: "by tomorrow" },
                { id: "wh-e7", english: "How many hours will Rohan have been sleeping?", hindi: "रोहन कितने घंटे से सो रहा होगा?", whWord: "How many hours", subject: "Rohan", verb: "sleeping", object: "" },
                { id: "wh-e8", english: "When will they have been practicing for two hours?", hindi: "वे दो घंटे से कब अभ्यास कर रहे होंगे?", whWord: "When", subject: "they", verb: "practicing", object: "for two hours" },
                { id: "wh-e9", english: "Who will have been managing the shop?", hindi: "दुकान का प्रबंधन कौन करता आ रहा होगा?", whWord: "Who", subject: "", verb: "managing", object: "the shop" },
                { id: "wh-e10", english: "How long will we have been traveling by evening?", hindi: "शाम तक हम कितने समय से यात्रा कर रहे होंगे?", whWord: "How long", subject: "we", verb: "traveling", object: "by evening" }
            ],
            medium: [
                { id: "wh-m1", english: "By 6 PM, how long will you have been writing the report?", hindi: "शाम 6 बजे तक आप कितने समय से रिपोर्ट लिख रहे होंगे?", whWord: "How long", subject: "you", verb: "writing", object: "the report" },
                { id: "wh-m2", english: "By next month, where will she have been working since 2022?", hindi: "अगले महीने तक वह 2022 से कहाँ काम कर रही होगी?", whWord: "Where", subject: "she", verb: "working", object: "since 2022" },
                { id: "wh-m3", english: "By 8 PM, how long will they have been driving?", hindi: "रात 8 बजे तक वे कितने समय से गाड़ी चला रहे होंगे?", whWord: "How long", subject: "they", verb: "driving", object: "" },
                { id: "wh-m4", english: "By June, why will he have been studying Japanese for two years?", hindi: "जून तक वह दो साल से जापानी भाषा क्यों सीख रहा होगा?", whWord: "Why", subject: "he", verb: "studying", object: "Japanese for two years" },
                { id: "wh-m5", english: "When I arrive, what will you have been doing for an hour?", hindi: "जब मैं पहुँचूँगा, आप एक घंटे से क्या कर रहे होंगे?", whWord: "What", subject: "you", verb: "doing", object: "for an hour" },
                { id: "wh-m6", english: "How many years will she have been teaching by 2025?", hindi: "2025 तक वह कितने वर्षों से पढ़ा रही होगी?", whWord: "How many years", subject: "she", verb: "teaching", object: "by 2025" },
                { id: "wh-m7", english: "Where will the team have been playing since morning?", hindi: "टीम सुबह से कहाँ खेल रही होगी?", whWord: "Where", subject: "the team", verb: "playing", object: "since morning" },
                { id: "wh-m8", english: "How long will your brother have been studying medicine by next year?", hindi: "अगले साल तक आपका भाई कितने समय से डॉक्टरी पढ़ रहा होगा?", whWord: "How long", subject: "your brother", verb: "studying", object: "medicine" },
                { id: "wh-m9", english: "Why will the farmers have been harvesting wheat since dawn?", hindi: "किसान भोर से गेहूं की कटाई क्यों कर रहे होंगे?", whWord: "Why", subject: "the farmers", verb: "harvesting", object: "wheat since dawn" },
                { id: "wh-m10", english: "How long will she have been listening to music by 10 PM?", hindi: "रात 10 बजे तक वह कितने समय से संगीत सुन रही होगी?", whWord: "How long", subject: "she", verb: "listening", object: "to music" }
            ],
            hard: [
                { id: "wh-h1", english: "By the end of this year, how long will they have been living in Delhi?", hindi: "इस साल के अंत तक वे दिल्ली में कितने समय से रह रहे होंगे?", whWord: "How long", subject: "they", verb: "living", object: "in Delhi" },
                { id: "wh-h2", english: "When midnight strikes, what will we have been celebrating for hours?", hindi: "आधी रात होने पर हम घंटों से क्या मना रहे होंगे?", whWord: "What", subject: "we", verb: "celebrating", object: "for hours" },
                { id: "wh-h3", english: "By graduation, how long will Vikas have been researching artificial intelligence?", hindi: "स्नातक होने तक विकास कितने समय से कृत्रिम बुद्धिमत्ता (AI) पर शोध कर रहा होगा?", whWord: "How long", subject: "Vikas", verb: "researching", object: "artificial intelligence" },
                { id: "wh-h4", english: "By October, why will the company have been expanding its global footprint for two years?", hindi: "अक्टूबर तक कंपनी दो साल से अपनी वैश्विक उपस्थिति का विस्तार क्यों कर रही होगी?", whWord: "Why", subject: "the company", verb: "expanding", object: "its global footprint for two years" },
                { id: "wh-h5", english: "When the train arrives, how long will the passengers have been waiting at the platform?", hindi: "ट्रेन आने पर यात्री प्लेटफॉर्म पर कितने समय से इंतज़ार कर रहे होंगे?", whWord: "How long", subject: "the passengers", verb: "waiting", object: "at the platform" },
                { id: "wh-h6", english: "By next summer, which language will you have been learning for three years?", hindi: "अगली गर्मियों तक आप तीन साल से कौन सी भाषा सीख रहे होंगे?", whWord: "Which language", subject: "you", verb: "learning", object: "for three years" },
                { id: "wh-h7", english: "By the end of the day, how many hours will workers have been building the structure?", hindi: "दिन के अंत तक मजदूर कितने घंटे से संरचना का निर्माण कर रहे होंगे?", whWord: "How many hours", subject: "workers", verb: "building", object: "the structure" },
                { id: "wh-h8", english: "Who will have been managing the regional office since 2023?", hindi: "2023 से क्षेत्रीय कार्यालय का प्रबंधन कौन करता आ रहा होगा?", whWord: "Who", subject: "", verb: "managing", object: "the regional office since 2023" },
                { id: "wh-h9", english: "By 2030, how long will scientists have been tracking this space object?", hindi: "2030 तक वैज्ञानिक कितने समय से इस अंतरिक्ष वस्तु की निगरानी कर रहे होंगे?", whWord: "How long", subject: "scientists", verb: "tracking", object: "this space object" },
                { id: "wh-h10", english: "When you arrive, how long will the orchestra have been performing for the audience?", hindi: "जब आप पहुँचेंगे, आर्केस्ट्रा दर्शकों के लिए कितने समय से प्रस्तुति दे रहा होगा?", whWord: "How long", subject: "the orchestra", verb: "performing", object: "for the audience" }
            ]
        },

        // 9. Common Mistakes / आम गलतियाँ (At least 15 detailed common mistakes)
        commonMistakes: {
            title: "Common Mistakes",
            titleHindi: "सामान्य गलतियाँ और निवारण (16 Mistakes & Corrections)",
            list: [
                {
                    id: "err-1",
                    wrong: "He will has been working for two hours.",
                    correct: "He will have been working for two hours.",
                    why: "Never use 'will has been'. Always use 'will have been' for ALL subjects (He, She, It, They).",
                    whyHindi: "भविष्य काल में 'will has' कभी नहीं होता। सभी कर्ताओं के साथ हमेशा 'will have been' ही आता है।"
                },
                {
                    id: "err-2",
                    wrong: "They will had been studying since morning.",
                    correct: "They will have been studying since morning.",
                    why: "Never mix 'will' with 'had'. Future Perfect Continuous always requires 'have been'.",
                    whyHindi: "'will' के साथ 'had' का प्रयोग व्याकरण की दृष्टि से अशुद्ध है। हमेशा 'will have been' का प्रयोग करें।"
                },
                {
                    id: "err-3",
                    wrong: "I will been working for five hours.",
                    correct: "I will have been working for five hours.",
                    why: "Missing 'have'. 'have' is essential to link the modal 'will' with 'been'.",
                    whyHindi: "'have' को छोड़ना गलत है। 'will' और 'been' के बीच 'have' होना अनिवार्य है।"
                },
                {
                    id: "err-4",
                    wrong: "She will have working for two hours.",
                    correct: "She will have been working for two hours.",
                    why: "Missing 'been'. Without 'been', the continuous aspect link is broken.",
                    whyHindi: "'been' को छोड़ना गलत है। निरंतरता दिखाने के लिए 'been' आवश्यक है।"
                },
                {
                    id: "err-5",
                    wrong: "We will have being working since 9 AM.",
                    correct: "We will have been working since 9 AM.",
                    why: "Incorrect 'being'. Use the past participle 'been', not the present participle 'being'.",
                    whyHindi: "'being' का प्रयोग गलत है। हमेशा 'been' (b-e-e-n) का प्रयोग करें।"
                },
                {
                    id: "err-6",
                    wrong: "They will have been work for three hours.",
                    correct: "They will have been working for three hours.",
                    why: "Using V1 instead of V1+ing. Continuous aspect requires the '-ing' verb form.",
                    whyHindi: "'will have been' के बाद केवल V1 (work) लगाना गलत है। हमेशा V1+ing (working) लगाएं।"
                },
                {
                    id: "err-7",
                    wrong: "He will have been worked for five hours.",
                    correct: "He will have been working for five hours.",
                    why: "Using V3 (worked) instead of V1+ing. Future Perfect uses V3, but Future Perfect Continuous uses V1+ing.",
                    whyHindi: "V3 (worked) का प्रयोग Future Perfect में होता है। Future Perfect Continuous में V1+ing लगाना अनिवार्य है।"
                },
                {
                    id: "err-8",
                    wrong: "She will have been write for two hours.",
                    correct: "She will have been writing for two hours.",
                    why: "Missing '-ing' suffix and failing spelling rule (drop 'e' in write -> writing).",
                    whyHindi: "write से 'e' हटाकर '-ing' (writing) जोड़ना आवश्यक है।"
                },
                {
                    id: "err-9",
                    wrong: "I will have not been working for five hours.",
                    correct: "I will not have been working for five hours.",
                    why: "Incorrect negative placement. 'not' must directly follow 'will' (will not have been).",
                    whyHindi: "नकारात्मक वाक्य में 'not' हमेशा 'will' के ठीक बाद आता है (will not have been)।"
                },
                {
                    id: "err-10",
                    wrong: "Have you will been working for five hours?",
                    correct: "Will you have been working for five hours?",
                    why: "Incorrect interrogative word order. 'Will' comes first, followed by Subject, then 'have been'.",
                    whyHindi: "प्रश्नवाचक वाक्य में 'Will' सबसे पहले आता है, उसके बाद Subject और फिर 'have been'।"
                },
                {
                    id: "err-11",
                    wrong: "How long you will have been working?",
                    correct: "How long will you have been working?",
                    why: "Incorrect WH question order. Auxiliary 'will' must precede the Subject (you).",
                    whyHindi: "WH प्रश्नों में WH शब्द के तुरंत बाद 'will' आता है, उसके बाद Subject।"
                },
                {
                    id: "err-12",
                    wrong: "I will have been working since five hours.",
                    correct: "I will have been working for five hours.",
                    why: "Using 'since' with duration. Five hours is a duration, so use 'for'.",
                    whyHindi: "5 घंटे समय की अवधि (duration) है, इसलिए 'since' नहीं बल्कि 'for' लगेगा।"
                },
                {
                    id: "err-13",
                    wrong: "She will have been studying for morning.",
                    correct: "She will have been studying since morning.",
                    why: "Using 'for' with a starting point. Morning is a starting point, so use 'since'.",
                    whyHindi: "सुबह (morning) कार्य शुरू होने का बिंदु है, इसलिए 'for' नहीं 'since' लगेगा।"
                },
                {
                    id: "err-14",
                    wrong: "By 6 PM, I will be finishing my work for three hours.",
                    correct: "By 6 PM, I will have been working for three hours.",
                    why: "Confusing Future Continuous with Future Perfect Continuous when specifying duration.",
                    whyHindi: "समय की अवधि (for 3 hours) बताने के लिए Future Continuous नहीं, Future Perfect Continuous लगेगा।"
                },
                {
                    id: "err-15",
                    wrong: "By next year, I will have lived here for five years.",
                    correct: "By next year, I will have been living here for five years.",
                    why: "Future Perfect (will have lived) emphasizes completion; Future Perfect Continuous (will have been living) emphasizes ongoing duration.",
                    whyHindi: "यदि भविष्य में भी कार्य जारी रहने की अवधि पर बल देना हो, तो 'will have been living' अधिक सटीक है।"
                },
                {
                    id: "err-16",
                    wrong: "I will have been working by five hours.",
                    correct: "I will have been working for five hours.",
                    why: "'by' indicates a deadline/reference point, whereas 'for' indicates length of duration.",
                    whyHindi: "'by' का प्रयोग समय-सीमा (जैसे by 5 PM) के लिए होता है, अवधि (duration) के लिए 'for' का प्रयोग करें।"
                }
            ]
        },

        // 10. Summary & Revision / सारांश और पुनरावृत्ति
        summary: {
            title: "Summary & Revision",
            titleHindi: "सारांश और त्वरित पुनरावृत्ति (Quick Revision)",
            goldenFormula: "GOLDEN FORMULA: WILL HAVE BEEN + V1+ING",
            goldenFormulaHindi: "मुख्य नियम: WILL HAVE BEEN + V1+ING (सभी कर्ताओं के लिए)",
            quickFormulas: [
                { type: "Positive", formula: "Subject + will have been + V1+ing + Object + (for/since + time)" },
                { type: "Negative", formula: "Subject + will not have been + V1+ing + Object + (for/since + time)" },
                { type: "Interrogative", formula: "Will + Subject + have been + V1+ing + Object + (for/since + time)?" },
                { type: "WH Question", formula: "WH + will + Subject + have been + V1+ing + Object + (for/since + time)?" },
                { type: "FOR Rule", formula: "FOR + duration (e.g. for 2 hours, for 5 days, for 3 years)" },
                { type: "SINCE Rule", formula: "SINCE + starting point (e.g. since morning, since Monday, since 2024)" }
            ],
            conceptSummary: "Future Perfect Continuous Tense = भविष्य के किसी संदर्भ बिंदु (future reference point) तक कोई कार्य कितने समय से जारी रहेगा, उस अवधि (duration) को दर्शाता है।",
            tensesDifference: {
                title: "Future Perfect vs Future Perfect Continuous",
                futurePerfect: {
                    name: "Future Perfect (will have + V3)",
                    focus: "Focuses on COMPLETED action by a future time.",
                    example: "By 6 PM, I will have finished my work. (शाम 6 बजे तक मेरा काम पूरा हो चुका होगा।)"
                },
                futurePerfectContinuous: {
                    name: "Future Perfect Continuous (will have been + V1+ing)",
                    focus: "Focuses on DURATION / CONTINUITY of action up to a future time.",
                    example: "By 6 PM, I will have been working for six hours. (शाम 6 बजे तक मैं छह घंटे से काम कर रहा होऊँगा।)"
                }
            },
            revisionExamples: [
                { level: "easy", english: "I will have been working for five hours by 5 PM.", hindi: "शाम 5 बजे तक मैं पाँच घंटे से काम कर रहा होऊँगा।" },
                { level: "easy", english: "She won't have been studying since morning.", hindi: "वह सुबह से पढ़ाई नहीं कर रही होगी।" },
                { level: "easy", english: "Will they have been living here for ten years?", hindi: "क्या वे यहाँ दस साल से रह रहे होंगे?" },
                { level: "easy", english: "How long will you have been waiting?", hindi: "आप कितने समय से इंतज़ार कर रहे होंगे?" },
                { level: "easy", english: "It will have been raining since yesterday.", hindi: "कल से बारिश हो रही होगी।" },
                { level: "medium", english: "By 8 PM, he will have been driving for ten hours.", hindi: "रात 8 बजे तक वह दस घंटे से गाड़ी चला रहा होगा।" },
                { level: "medium", english: "By next month, she will have been teaching here for two years.", hindi: "अगले महीने तक वह यहाँ दो साल से पढ़ा रही होगी।" },
                { level: "medium", english: "When you arrive, we won't have been waiting for long.", hindi: "जब आप पहुँचेंगे, तब हम लंबे समय से इंतज़ार नहीं कर रहे होंगे।" },
                { level: "medium", english: "By June, will he have been working here since January?", hindi: "क्या जून तक वह यहाँ जनवरी से काम कर रहा होगा?" },
                { level: "medium", english: "How many years will you have been living in India by 2030?", hindi: "2030 तक आप कितने वर्षों से भारत में रह रहे होंगे?" },
                { level: "hard", english: "By the end of this year, they will have been living in Delhi for a decade.", hindi: "इस साल के अंत तक वे दिल्ली में एक दशक से रह रहे होंगे।" },
                { level: "hard", english: "By graduation, Vikas will have been researching AI for four years.", hindi: "स्नातक होने तक विकास चार साल से एआई पर शोध कर रहा होगा।" },
                { level: "hard", english: "When the train arrives, passengers will not have been waiting for more than an hour.", hindi: "ट्रेन आने पर यात्री एक घंटे से अधिक समय से इंतज़ार नहीं कर रहे होंगे।" },
                { level: "hard", english: "By the end of the day, how many hours will workers have been building the bridge?", hindi: "दिन के अंत तक मजदूर कितने घंटे से पुल का निर्माण कर रहे होंगे?" },
                { level: "hard", english: "Before degree completion, she will have been managing the unit since 2023.", hindi: "डिग्री पूरी होने से पहले, वह 2023 से इकाई का प्रबंधन कर रही होगी।" }
            ]
        },

        // 11. Practice Exercises / अभ्यास
        exercises: {
            title: "Practice Exercises",
            titleHindi: "अभ्यास प्रश्न (Interactive Practice)",
            categories: [
                { id: "positive", title: "Positive Sentences", count: 30 },
                { id: "negative", title: "Negative Sentences", count: 30 },
                { id: "interrogative", title: "Interrogative Sentences", count: 30 },
                { id: "whQuestions", title: "WH Questions", count: 30 }
            ]
        },

        // 12. Quiz / प्रश्नोत्तरी (12 combinations: 4 categories x 3 difficulties)
        quiz: {
            title: "Tense Quiz",
            titleHindi: "ज्ञान परीक्षा (Quiz Engine)",
            categories: [
                { id: "positive", title: "Positive Sentences" },
                { id: "negative", title: "Negative Sentences" },
                { id: "interrogative", title: "Interrogative Sentences" },
                { id: "whQuestions", title: "WH Questions" }
            ],
            difficulties: ["easy", "medium", "hard"],
            questionsPerCombination: 10
        }
    }
};

export function getFuturePerfectContinuousLesson() {
    return futurePerfectContinuousLesson;
}

export function getFuturePerfectContinuousSection(sectionName) {
    return futurePerfectContinuousLesson.sections[sectionName] || null;
}
