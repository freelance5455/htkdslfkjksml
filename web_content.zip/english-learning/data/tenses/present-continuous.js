/**
 * Present Continuous Tense Lesson Data & Data Architecture
 * Single Source of Truth for Present Continuous Tense (Hindi Medium).
 * Vanilla ES6 JavaScript Module.
 */

export const presentContinuousLesson = {
    id: "present-continuous",
    title: "Present Continuous",
    titleHindi: "अपूर्ण वर्तमान काल (रहा है / रही है / रहे हैं)",

    sections: {
        // 1. Identification / पहचान और अवधारणा
        identification: {
            english: "Present Continuous Tense expresses actions happening right now at the time of speaking or temporary activities in progress around the present time.",
            hindi: "Present Continuous Tense (अपूर्ण वर्तमान काल) का प्रयोग उन कार्यों के लिए किया जाता है जो इस समय बोलते वक्त चल रहे हैं या वर्तमान समय के आसपास जारी (in progress) हैं।",
            hindiIdentityRule: "हिंदी पहचान: वाक्यों के अंत में 'रहा है', 'रही है', 'रहे हैं', 'रहा हूँ' आदि शब्द आते हैं।",
            points: [
                {
                    english: "Action at the Moment of Speaking",
                    hindi: "बोलते समय चल रहा काम (जैसे: I am studying right now. / मैं अभी पढ़ रहा हूँ।)"
                },
                {
                    english: "Temporary Activity Around Present",
                    hindi: "वर्तमान के आसपास जारी अस्थायी काम (जैसे: He is writing a book these days. / वह इन दिनों एक किताब लिख रहा है।)"
                },
                {
                    english: "Ongoing Changes and Trends",
                    hindi: "निरंतर बदलाव या विकास (जैसे: It is getting dark. / अंधेरा हो रहा है।)"
                },
                {
                    english: "Pre-planned Near Future Events",
                    hindi: "निकट भविष्य की पक्की योजना (जैसे: We are leaving tomorrow. / हम कल रवाना हो रहे हैं।)"
                }
            ],
            comparison: {
                title: "Simple Present vs Present Continuous (अंतर समझें)",
                simplePresent: {
                    name: "Simple Present (सामान्य वर्तमान)",
                    formula: "Subject + V1(+s/es) + Object",
                    concept: "दैनिक आदत या नियमित कार्य (ता है / ती है)",
                    example: "I play cricket. (मैं क्रिकेट खेलता हूँ - यह मेरी आदत है।)"
                },
                presentContinuous: {
                    name: "Present Continuous (अपूर्ण वर्तमान)",
                    formula: "Subject + am/is/are + V4(V1+ing) + Object",
                    concept: "ठीक अभी चल रहा कार्य (रहा है / रही है / रहे हैं)",
                    example: "I am playing cricket. (मैं क्रिकेट खेल रहा हूँ - यह काम अभी जारी है।)"
                }
            }
        },

        // 2. Uses & Scenarios (5 Main Uses)
        uses: [
            {
                id: "use-1-action-now",
                title: "1. Action Happening Right Now",
                titleHindi: "1. बोलते समय ठीक अभी हो रहा कार्य",
                explanation: "Actions that are taking place at the exact moment of speaking.",
                explanationHindi: "वे कार्य जो ठीक बोलते समय हमारी आँखों के सामने या इसी क्षण जारी हैं।",
                whyUsed: "Used because the action is active and uncompleted right now.",
                whyUsedHindi: "यह काल इसलिए प्रयोग हुआ है क्योंकि कार्य अभी बोलते समय प्रगति पर (in progress) है।",
                examples: [
                    {
                        english: "I am reading a book right now.",
                        hindi: "मैं अभी एक किताब पढ़ रहा हूँ।",
                        note: "Reading is taking place at this instant."
                    },
                    {
                        english: "She is speaking on the phone.",
                        hindi: "वह फोन पर बात कर रही है।",
                        note: "Phone call is active right now."
                    },
                    {
                        english: "Listen! The baby is crying.",
                        hindi: "सुनो! बच्चा रो रहा है।",
                        note: "Crying is happening right at this moment."
                    }
                ]
            },
            {
                id: "use-2-around-present",
                title: "2. Action Happening Around Present Time",
                titleHindi: "2. वर्तमान समय के आसपास चल रहा कार्य (इन दिनों जारी काम)",
                explanation: "Actions in progress around now, even if not happening at the exact second of speaking.",
                explanationHindi: "वे कार्य जो इन दिनों या हाल के दिनों में जारी हैं, भले ही ठीक बोलते समय न हो रहे हों।",
                whyUsed: "Used because the task is a current ongoing project or continuous routine activity around this period.",
                whyUsedHindi: "यह काल इसलिए प्रयोग हुआ है क्योंकि यह कार्य इन दिनों एक प्रोजेक्ट या रूटीन के रूप में जारी है।",
                examples: [
                    {
                        english: "He is writing a new novel these days.",
                        hindi: "वह इन दिनों एक नया उपन्यास लिख रहा है।",
                        note: "Writing process is active during this period."
                    },
                    {
                        english: "I am taking a web development course this month.",
                        hindi: "मैं इस महीने एक वेब डेवलपमेंट कोर्स कर रहा हूँ।",
                        note: "Course is ongoing this month."
                    },
                    {
                        english: "She is preparing for competitive exams.",
                        hindi: "वह प्रतियोगी परीक्षाओं की तैयारी कर रही है।",
                        note: "Preparation is in progress around now."
                    }
                ]
            },
            {
                id: "use-3-temporary-situation",
                title: "3. Temporary Situation or Activity",
                titleHindi: "3. अस्थायी स्थिति (कुछ समय के लिए चल रहा काम)",
                explanation: "Living arrangements or activities that are temporary and not permanent.",
                explanationHindi: "वे स्थितियां जो केवल कुछ समय के लिए हैं और स्थायी (permanent) नहीं हैं।",
                whyUsed: "Used to emphasize that the current situation is temporary and expected to change soon.",
                whyUsedHindi: "यह काल इसलिए प्रयोग हुआ है ताकि स्पष्ट हो सके कि स्थिति अस्थायी है और जल्द बदलेगी।",
                examples: [
                    {
                        english: "I am staying at a hotel until I find an apartment.",
                        hindi: "जब तक मुझे अपार्टमेंट नहीं मिलता, मैं होटल में ठहरा हुआ हूँ।",
                        note: "Hotel stay is temporary."
                    },
                    {
                        english: "He is working from home this week.",
                        hindi: "वह इस हफ्ते घर से काम कर रहा है।",
                        note: "Working from home is only for this week."
                    },
                    {
                        english: "She is using her sister's laptop today.",
                        hindi: "वह आज अपनी बहन का लैपटॉप इस्तेमाल कर रही है।",
                        note: "Using the laptop is temporary for today."
                    }
                ]
            },
            {
                id: "use-4-fixed-future-plan",
                title: "4. Fixed Near-Future Arrangement",
                titleHindi: "4. निकट भविष्य की पक्की योजना (पूर्व-निर्धारित कार्यक्रम)",
                explanation: "Planned arrangements or events scheduled for the near future.",
                explanationHindi: "वे कार्य जो निकट भविष्य में होने वाले हैं और जिनकी पक्की योजना पहले से बन चुकी है।",
                whyUsed: "Used because the future arrangement is confirmed and scheduled.",
                whyUsedHindi: "यह काल इसलिए प्रयोग हुआ है क्योंकि भविष्य की योजना पहले से तय और पक्की है।",
                examples: [
                    {
                        english: "We are traveling to Mumbai tomorrow.",
                        hindi: "हम कल मुंबई की यात्रा कर रहे हैं।",
                        note: "Trip is planned and confirmed for tomorrow."
                    },
                    {
                        english: "She is meeting the manager this afternoon.",
                        hindi: "वह आज दोपहर मैनेजर से मिल रही है।",
                        note: "Meeting is pre-scheduled."
                    },
                    {
                        english: "My friends are arriving tonight.",
                        hindi: "मेरे दोस्त आज रात आ रहे हैं।",
                        note: "Arrival is fixed for tonight."
                    }
                ]
            },
            {
                id: "use-5-changing-situation",
                title: "5. Changing or Developing Situation",
                titleHindi: "5. निरंतर बदलाव या विकास (बदलती हुई स्थिति)",
                explanation: "Trends or situations that are gradually changing, growing, or evolving over time.",
                explanationHindi: "वे स्थितियां या प्रवृत्तियां जो समय के साथ धीरे-धीरे बदल या विकसित हो रही हैं।",
                whyUsed: "Used because the condition is in a constant state of dynamic change or progress.",
                whyUsedHindi: "यह काल इसलिए प्रयोग हुआ है क्योंकि स्थिति लगातार बदल या सुधर रही है।",
                examples: [
                    {
                        english: "Your English speaking is improving day by day.",
                        hindi: "आपकी अंग्रेजी बोली दिन-ब-दिन सुधर रही है।",
                        note: "Improvement is a continuous trend."
                    },
                    {
                        english: "The weather is getting colder every evening.",
                        hindi: "मौसम हर शाम ठंडा हो रहा है।",
                        note: "Weather change is a gradual process."
                    },
                    {
                        english: "The price of smartphones is decreasing.",
                        hindi: "स्मार्टफोन की कीमत कम हो रही है।",
                        note: "Price drop is an ongoing market trend."
                    }
                ]
            }
        ],

        // 3. Structure & Formulas / वाक्य संरचना
        structure: {
            simpleHindiOverview: "Present Continuous Tense में Main Verb के साथ V4 (ing form) आता है और am / is / are Auxiliary Verb (सहायक क्रिया) के रूप में प्रयोग होते हैं।",
            mainFormula: "Subject + am/is/are + V4(ing) + Object",

            auxiliaryMapping: [
                { subject: "I", aux: "am", formula: "I + am + V4" },
                { subject: "He / She / It / Singular Noun", aux: "is", formula: "He/She/It/Singular + is + V4" },
                { subject: "You / We / They / Plural Noun", aux: "are", formula: "You/We/They/Plural + are + V4" }
            ],

            v4SpellingReminder: [
                { base: "play", v4: "playing", rule: "सामान्य नियम: V1 + ing" },
                { base: "make", v4: "making", rule: "अंतिम e को हटाकर ing जोड़ें" },
                { base: "run", v4: "running", rule: "अंतिम अक्षर दोहराएं (double consonant)" },
                { base: "lie", v4: "lying", rule: "-ie को बदलकर y + ing करें" }
            ],

            positive: "Subject + am/is/are + V4(ing) + Object",
            negative: "Subject + am/is/are + not + V4(ing) + Object",
            interrogative: "Am/Is/Are + Subject + V4(ing) + Object?",
            whQuestions: "WH-word + am/is/are + Subject + V4(ing) + Object?",

            formulaBlocks: [
                {
                    id: "positive",
                    title: "1. Positive / Affirmative Formula (सकारात्मक वाक्य)",
                    formula: "Subject + am/is/are + V4(ing) + Object",
                    englishExplanation: "Used for affirmative statements describing actions happening right now.",
                    hindiExplanation: "सकारात्मक वाक्यों में कर्ता के अनुसार am/is/are के साथ V4 (ing form) का प्रयोग किया जाता है।",
                    examples: [
                        {
                            english: "I am reading a book.",
                            hindi: "मैं एक किताब पढ़ रहा हूँ।",
                            breakdown: {
                                subject: "I",
                                aux: "am",
                                mainVerb: "reading (V4)",
                                object: "a book"
                            }
                        },
                        {
                            english: "She is cooking food.",
                            hindi: "वह खाना बना रही है।",
                            breakdown: {
                                subject: "She",
                                aux: "is",
                                mainVerb: "cooking (V4)",
                                object: "food"
                            }
                        }
                    ]
                },
                {
                    id: "negative",
                    title: "2. Negative Formula (नकारात्मक वाक्य)",
                    formula: "Subject + am/is/are + not + V4(ing) + Object",
                    englishExplanation: "Used for negative statements by adding 'not' right after the auxiliary verb (am/is/are).",
                    hindiExplanation: "नकारात्मक वाक्यों में am/is/are के तुरंत बाद 'not' लगाया जाता है।",
                    examples: [
                        {
                            english: "They are not playing football.",
                            hindi: "वे फुटबॉल नहीं खेल रहे हैं।",
                            breakdown: {
                                subject: "They",
                                aux: "are",
                                not: "not",
                                mainVerb: "playing (V4)",
                                object: "football"
                            }
                        },
                        {
                            english: "He is not sleeping right now.",
                            hindi: "वह अभी नहीं सो रहा है।",
                            breakdown: {
                                subject: "He",
                                aux: "is",
                                not: "not",
                                mainVerb: "sleeping (V4)",
                                object: "right now"
                            }
                        }
                    ]
                },
                {
                    id: "interrogative",
                    title: "3. Interrogative Formula (प्रश्नवाचक वाक्य - Yes/No)",
                    formula: "Am/Is/Are + Subject + V4(ing) + Object?",
                    englishExplanation: "Used for Yes/No questions by moving the auxiliary verb (Am/Is/Are) before the subject.",
                    hindiExplanation: "हाँ/ना वाले प्रश्नवाचक वाक्यों में auxiliary verb (Am/Is/Are) को वाक्य के शुरू में रखा जाता है।",
                    examples: [
                        {
                            english: "Are you watching TV?",
                            hindi: "क्या आप टीवी देख रहे हैं?",
                            breakdown: {
                                aux: "Are",
                                subject: "you",
                                mainVerb: "watching (V4)",
                                object: "TV"
                            }
                        },
                        {
                            english: "Is Rahul writing a story?",
                            hindi: "क्या राहुल एक कहानी लिख रहा है?",
                            breakdown: {
                                aux: "Is",
                                subject: "Rahul",
                                mainVerb: "writing (V4)",
                                object: "a story"
                            }
                        }
                    ]
                },
                {
                    id: "whQuestions",
                    title: "4. WH Question Formula (प्रश्नवाचक वाक्य - WH शब्द)",
                    formula: "WH-word + am/is/are + Subject + V4(ing) + Object?",
                    englishExplanation: "Used when asking for specific detail using WH-words (What, Where, Why, When, Who, How).",
                    hindiExplanation: "विशेष जानकारी मांगने के लिए WH-शब्द को am/is/are से भी पहले रखा जाता है।",
                    examples: [
                        {
                            english: "What are you doing?",
                            hindi: "आप क्या कर रहे हैं?",
                            breakdown: {
                                wh: "What",
                                aux: "are",
                                subject: "you",
                                mainVerb: "doing (V4)",
                                object: "-"
                            }
                        },
                        {
                            english: "Where is she going?",
                            hindi: "वह कहाँ जा रही है?",
                            breakdown: {
                                wh: "Where",
                                aux: "is",
                                subject: "she",
                                mainVerb: "going (V4)",
                                object: "-"
                            }
                        }
                    ]
                }
            ]
        },

        // 4. Subject + Auxiliary Rules & V4 Formation / कर्ता और सहायक क्रिया के नियम
        subjectVerbRules: {
            auxiliaryMapping: [
                {
                    subjectGroup: "Group 1: Subject 'I'",
                    auxiliary: "am",
                    formula: "I + am + V4 (V1+ing)",
                    hindiRule: "केवल 'I' के साथ 'am' का प्रयोग होता है। (जैसे: I am reading. / मैं पढ़ रहा हूँ।)"
                },
                {
                    subjectGroup: "Group 2: Singular Subjects (He / She / It / Name)",
                    auxiliary: "is",
                    formula: "He / She / It / Singular + is + V4 (V1+ing)",
                    hindiRule: "एकवचन कर्ता (He, She, It, Rahul) के साथ 'is' का प्रयोग होता है। (जैसे: He is writing. / वह लिख रहा है।)"
                },
                {
                    subjectGroup: "Group 3: Plural Subjects (You / We / They)",
                    auxiliary: "are",
                    formula: "You / We / They / Plural + are + V4 (V1+ing)",
                    hindiRule: "बहुवचन कर्ता (You, We, They, Students) के साथ 'are' का प्रयोग होता है। (जैसे: They are playing. / वे खेल रहे हैं।)"
                }
            ],
            v4Explanation: {
                title: "What is V4? (Verb + ing)",
                titleHindi: "V4 क्या है? (मुख्य क्रिया में -ing जोड़ना)",
                ruleText: "V4 = Base Verb (V1) + ing",
                explanationHindi: "Present Continuous में सभी कर्ताओं के साथ Main Verb के अंत में 'ing' जुड़ता है।",
                examples: [
                    { base: "play", v4: "playing" },
                    { base: "read", v4: "reading" },
                    { base: "go", v4: "going" },
                    { base: "speak", v4: "speaking" }
                ]
            },
            spellingRulesIng: [
                {
                    condition: "1. Normal / General Verbs",
                    rule: "Add -ing directly to V1",
                    examples: "play → playing, read → reading, work → working, learn → learning"
                },
                {
                    condition: "2. Verbs ending in silent -e",
                    rule: "Remove final -e and add -ing",
                    examples: "make → making, write → writing, come → coming, take → taking"
                },
                {
                    condition: "3. Short CVC Verbs (Consonant-Vowel-Consonant)",
                    rule: "Double the final consonant and add -ing",
                    examples: "run → running, sit → sitting, stop → stopping, swim → swimming"
                },
                {
                    condition: "4. Verbs ending in -ie",
                    rule: "Change -ie to -y and add -ing",
                    examples: "lie → lying, die → dying, tie → tying"
                }
            ]
        },

        // 5. Positive / Affirmative Sentences (सकारात्मक वाक्य)
        positive: {
            title: "Positive / Affirmative Sentences",
            titleHindi: "सकारात्मक वाक्य",
            formula: "Subject + am / is / are + V4 (V1+ing) + Object",
            formulaPlural: "You / We / They + are + V4 (ing)",
            formulaSingular: "He / She / It / Name + is + V4 (ing)",
            formulaI: "I + am + V4 (ing)",
            explanation: "Positive sentences in Present Continuous express an action happening or progressing right now.",
            explanationHindi: "Present Continuous के सकारात्मक वाक्य यह दर्शाते हैं कि कोई कार्य अभी वर्तमान में चल रहा है।",
            groups: {
                groupI: {
                    name: "Group 1: Subject 'I' (I + am + V4)",
                    rule: "Always use 'am' + V4",
                    ruleHindi: "I के साथ हमेशा am + V4 (ing) का प्रयोग करें।",
                    examples: [
                        { english: "I am reading a book.", hindi: "मैं किताब पढ़ रहा हूँ।", verb: "am reading" },
                        { english: "I am learning English online.", hindi: "मैं ऑनलाइन अंग्रेजी सीख रहा हूँ।", verb: "am learning" }
                    ]
                },
                groupSingular: {
                    name: "Group 2: Singular Subjects (He / She / It / Name)",
                    rule: "Use 'is' + V4",
                    ruleHindi: "He, She, It और एकवचन कर्ता के साथ is + V4 का प्रयोग करें।",
                    examples: [
                        { english: "He is driving a car.", hindi: "वह कार चला रहा है।", verb: "is driving" },
                        { english: "She is cooking dinner.", hindi: "वह रात का खाना बना रही है।", verb: "is cooking" }
                    ]
                },
                groupPlural: {
                    name: "Group 3: Plural Subjects (You / We / They)",
                    rule: "Use 'are' + V4",
                    ruleHindi: "You, We, They और बहुवचन कर्ता के साथ are + V4 का प्रयोग करें।",
                    examples: [
                        { english: "They are playing football.", hindi: "वे फुटबॉल खेल रहे हैं।", verb: "are playing" },
                        { english: "We are watching a movie.", hindi: "हम फिल्म देख रहे हैं।", verb: "are watching" }
                    ]
                }
            },
            sentences: {
                easy: [
                    { id: "pos-e1", english: "I am reading a book.", hindi: "मैं एक किताब पढ़ रहा हूँ।", subject: "I", aux: "am", verb: "am reading", object: "a book" },
                    { id: "pos-e2", english: "She is cooking dinner.", hindi: "वह रात का खाना बना रही है।", subject: "She", aux: "is", verb: "is cooking", object: "dinner" },
                    { id: "pos-e3", english: "He is driving a car.", hindi: "वह कार चला रहा है।", subject: "He", aux: "is", verb: "is driving", object: "a car" },
                    { id: "pos-e4", english: "They are playing cricket.", hindi: "वे क्रिकेट खेल रहे हैं।", subject: "They", aux: "are", verb: "are playing", object: "cricket" },
                    { id: "pos-e5", english: "We are watching television.", hindi: "हम टेलीविजन देख रहे हैं।", subject: "We", aux: "are", verb: "are watching", object: "television" },
                    { id: "pos-e6", english: "Rahul is writing a letter.", hindi: "राहुल पत्र लिख रहा है।", subject: "Rahul", aux: "is", verb: "is writing", object: "a letter" },
                    { id: "pos-e7", english: "The baby is sleeping peacefully.", hindi: "बच्चा शांति से सो रहा है।", subject: "The baby", aux: "is", verb: "is sleeping", object: "peacefully" },
                    { id: "pos-e8", english: "You are learning English grammar.", hindi: "आप अंग्रेजी व्याकरण सीख रहे हैं।", subject: "You", aux: "are", verb: "are learning", object: "English grammar" },
                    { id: "pos-e9", english: "Birds are flying in the sky.", hindi: "पक्षी आसमान में उड़ रहे हैं।", subject: "Birds", aux: "are", verb: "are flying", object: "in the sky" },
                    { id: "pos-e10", english: "It is raining heavily outside.", hindi: "बाहर तेज बारिश हो रही है।", subject: "It", aux: "is", verb: "is raining", object: "heavily outside" }
                ],
                medium: [
                    { id: "pos-m1", english: "I am taking an online computer course this month.", hindi: "मैं इस महीने एक ऑनलाइन कंप्यूटर कोर्स कर रहा हूँ।", subject: "I", aux: "am", verb: "am taking", object: "a course" },
                    { id: "pos-m2", english: "She is preparing for her final medical exams.", hindi: "वह अपनी अंतिम मेडिकल परीक्षाओं की तैयारी कर रही है।", subject: "She", aux: "is", verb: "is preparing", object: "for exams" },
                    { id: "pos-m3", english: "They are constructing a new bridge near the river.", hindi: "वे नदी के पास एक नया पुल बना रहे हैं।", subject: "They", aux: "are", verb: "are constructing", object: "a new bridge" },
                    { id: "pos-m4", english: "My brother is working from home this week.", hindi: "मेरा भाई इस हफ्ते घर से काम कर रहा है।", subject: "My brother", aux: "is", verb: "is working", object: "from home" },
                    { id: "pos-m5", english: "We are planning a trip to Jaipur for next weekend.", hindi: "हम अगले सप्ताहांत के लिए जयपुर यात्रा की योजना बना रहे हैं।", subject: "We", aux: "are", verb: "are planning", object: "a trip" },
                    { id: "pos-m6", english: "The students are attending a live lecture on science.", hindi: "छात्र विज्ञान पर एक लाइव व्याख्यान में भाग ले रहे हैं।", subject: "The students", aux: "are", verb: "are attending", object: "a lecture" },
                    { id: "pos-m7", english: "She is wearing a beautiful blue saree today.", hindi: "उसने आज एक सुंदर नीली साड़ी पहनी हुई है।", subject: "She", aux: "is", verb: "is wearing", object: "a blue saree" },
                    { id: "pos-m8", english: "The weather is getting colder every evening.", hindi: "मौसम हर शाम ठंडा हो रहा है।", subject: "The weather", aux: "is", verb: "is getting", object: "colder" },
                    { id: "pos-m9", english: "Engineers are upgrading the company server system.", hindi: "इंजीनियर कंपनी के सर्वर सिस्टम को अपग्रेड कर रहे हैं।", subject: "Engineers", aux: "are", verb: "are upgrading", object: "server system" },
                    { id: "pos-m10", english: "The prices of smartphones are decreasing rapidly.", hindi: "स्मार्टफोन की कीमतें तेजी से कम हो रही हैं।", subject: "The prices", aux: "are", verb: "are decreasing", object: "rapidly" }
                ],
                hard: [
                    { id: "pos-h1", english: "The research team is developing an innovative artificial intelligence algorithm.", hindi: "अनुसंधान टीम एक अभिनव कृत्रिम बुद्धिमत्ता एल्गोरिदम विकसित कर रही है।", subject: "The research team", aux: "is", verb: "is developing", object: "an algorithm" },
                    { id: "pos-h2", english: "Foreign delegates are negotiating a multilateral trade agreement in Geneva.", hindi: "विदेशी प्रतिनिधि जिनेवा में एक बहुपक्षीय व्यापार समझौते पर बातचीत कर रहे हैं।", subject: "Foreign delegates", aux: "are", verb: "are negotiating", object: "trade agreement" },
                    { id: "pos-h3", english: "Environmental scientists are monitoring atmospheric pollution levels across major cities.", hindi: "पर्यावरण वैज्ञानिक प्रमुख शहरों में वायुमंडलीय प्रदूषण स्तर की निगरानी कर रहे हैं।", subject: "Scientists", aux: "are", verb: "are monitoring", object: "pollution levels" },
                    { id: "pos-h4", english: "Senior executives are discussing quarterly financial performance in the conference room.", hindi: "वरिष्ठ कार्यकारी अधिकारी सम्मेलन कक्ष में तिमाही वित्तीय प्रदर्शन पर चर्चा कर रहे हैं।", subject: "Executives", aux: "are", verb: "are discussing", object: "performance" },
                    { id: "pos-h5", english: "The government is implementing new healthcare policies to support rural families.", hindi: "सरकार ग्रामीण परिवारों की सहायता के लिए नई स्वास्थ्य नीतियों को लागू कर रही है।", subject: "The government", aux: "is", verb: "is implementing", object: "policies" },
                    { id: "pos-h6", english: "Software developers are migrating legacy databases to secure cloud infrastructure.", hindi: "सॉफ्टवेयर डेवलपर्स पुराने डेटाबेस को सुरक्षित क्लाउड इंफ्रास्ट्रक्चर में स्थानांतरित कर रहे हैं।", subject: "Developers", aux: "are", verb: "are migrating", object: "databases" },
                    { id: "pos-h7", english: "Medical specialists are conducting advanced clinical trials for the new vaccine.", hindi: "चिकित्सा विशेषज्ञ नए टीके के लिए उन्नत नैदानिक परीक्षण कर रहे हैं।", subject: "Specialists", aux: "are", verb: "are conducting", object: "trials" },
                    { id: "pos-h8", english: "Urban planners are redesigning public transportation networks to reduce traffic congestion.", hindi: "शहरी योजनाकार ट्रैफिक भीड़ को कम करने के लिए सार्वजनिक परिवहन नेटवर्क को नया रूप दे रहे हैं।", subject: "Planners", aux: "are", verb: "are redesigning", object: "networks" },
                    { id: "pos-h9", english: "Financial analysts are studying market fluctuations during the ongoing economic transition.", hindi: "वित्तीय विश्लेषक जारी आर्थिक संक्रमण के दौरान बाजार के उतार-चढ़ाव का अध्ययन कर रहे हैं।", subject: "Analysts", aux: "are", verb: "are studying", object: "fluctuations" },
                    { id: "pos-h10", english: "International space agencies are collaborating on a joint lunar exploration mission.", hindi: "अंतरराष्ट्रीय अंतरिक्ष एजेंसियां संयुक्त चंद्र अन्वेषण मिशन पर सहयोग कर रही हैं।", subject: "Space agencies", aux: "are", verb: "are collaborating", object: "mission" }
                ]
            }
        },

        // 6. Negative Sentences (नकारात्मक वाक्य)
        negative: {
            title: "Negative Sentences",
            titleHindi: "नकारात्मक वाक्य",
            formula: "Subject + am / is / are + not + V4 (V1+ing) + Object",
            formulaPlural: "You / We / They + are not (aren't) + V4",
            formulaSingular: "He / She / It / Name + is not (isn't) + V4",
            formulaI: "I + am not + V4",
            contractions: "is not → isn't  |  are not → aren't  |  am not (I'm not)",
            explanation: "Negative sentences state that an action is NOT happening right now.",
            explanationHindi: "नकारात्मक वाक्य यह दर्शाते हैं कि कोई कार्य अभी नहीं हो रहा है। इसके लिए am/is/are के ठीक बाद 'not' लगाया जाता है।",
            groups: {
                groupI: {
                    name: "Group 1: Subject 'I' (I + am not + V4)",
                    rule: "I + am not + V4",
                    ruleHindi: "I के साथ am not + V4 का प्रयोग करें।",
                    examples: [
                        { english: "I am not sleeping.", hindi: "मैं नहीं सो रहा हूँ।", verb: "am not sleeping" }
                    ]
                },
                groupSingular: {
                    name: "Group 2: Singular Subjects (is not / isn't)",
                    rule: "He/She/It + is not (isn't) + V4",
                    ruleHindi: "He/She/It के साथ is not (isn't) + V4 का प्रयोग करें।",
                    examples: [
                        { english: "He is not working today.", hindi: "वह आज काम नहीं कर रहा है।", verb: "is not working" }
                    ]
                },
                groupPlural: {
                    name: "Group 3: Plural Subjects (are not / aren't)",
                    rule: "You/We/They + are not (aren't) + V4",
                    ruleHindi: "You/We/They के साथ are not (aren't) + V4 का प्रयोग करें।",
                    examples: [
                        { english: "They are not coming to the party.", hindi: "वे पार्टी में नहीं आ रहे हैं।", verb: "are not coming" }
                    ]
                }
            },
            sentences: {
                easy: [
                    { id: "neg-e1", english: "I am not watching TV right now.", hindi: "मैं अभी टीवी नहीं देख रहा हूँ।", subject: "I", aux: "am not", verb: "am not watching", object: "TV" },
                    { id: "neg-e2", english: "She is not crying anymore.", hindi: "वह अब नहीं रो रही है।", subject: "She", aux: "is not", verb: "is not crying", object: "anymore" },
                    { id: "neg-e3", english: "He is not playing video games.", hindi: "वह वीडियो गेम नहीं खेल रहा है।", subject: "He", aux: "is not", verb: "is not playing", object: "video games" },
                    { id: "neg-e4", english: "They are not coming to the party.", hindi: "वे पार्टी में नहीं आ रहे हैं।", subject: "They", aux: "are not", verb: "are not coming", object: "to the party" },
                    { id: "neg-e5", english: "We are not wasting our time.", hindi: "हम अपना समय बर्बाद नहीं कर रहे हैं।", subject: "We", aux: "are not", verb: "are not wasting", object: "our time" },
                    { id: "neg-e6", english: "Rahul is not working today.", hindi: "राहुल आज काम नहीं कर रहा है।", subject: "Rahul", aux: "is not", verb: "is not working", object: "today" },
                    { id: "neg-e7", english: "You are not listening to the teacher.", hindi: "आप शिक्षक की बात नहीं सुन रहे हैं।", subject: "You", aux: "are not", verb: "are not listening", object: "to the teacher" },
                    { id: "neg-e8", english: "The dog is not barking at strangers.", hindi: "कुत्ता अजनबियों पर नहीं भौंक रहा है।", subject: "The dog", aux: "is not", verb: "is not barking", object: "at strangers" },
                    { id: "neg-e9", english: "It is not raining at the moment.", hindi: "इस समय बारिश नहीं हो रही है।", subject: "It", aux: "is not", verb: "is not raining", object: "at the moment" },
                    { id: "neg-e10", english: "The kids are not making noise in class.", hindi: "बच्चे कक्षा में शोर नहीं मचा रहे हैं।", subject: "The kids", aux: "are not", verb: "are not making", object: "noise" }
                ],
                medium: [
                    { id: "neg-m1", english: "I am not using my laptop today because it is charging.", hindi: "मैं आज अपना लैपटॉप इस्तेमाल नहीं कर रहा हूँ क्योंकि यह चार्ज हो रहा है।", subject: "I", aux: "am not", verb: "am not using", object: "laptop" },
                    { id: "neg-m2", english: "She isn't staying at the hotel this week.", hindi: "वह इस हफ्ते होटल में नहीं ठहर रही है।", subject: "She", aux: "isn't", verb: "isn't staying", object: "at the hotel" },
                    { id: "neg-m3", english: "They aren't following the updated traffic rules properly.", hindi: "वे अद्यतन यातायात नियमों का ठीक से पालन नहीं कर रहे हैं।", subject: "They", aux: "aren't", verb: "aren't following", object: "traffic rules" },
                    { id: "neg-m4", english: "My father is not working late hours this evening.", hindi: "मेरे पिता आज शाम देर तक काम नहीं कर रहे हैं।", subject: "My father", aux: "is not", verb: "is not working", object: "late hours" },
                    { id: "neg-m5", english: "We aren't experiencing any technical glitches during the call.", hindi: "कॉलिंग के दौरान हमें किसी भी तकनीकी खराबी का सामना नहीं करना पड़ रहा है।", subject: "We", aux: "aren't", verb: "aren't experiencing", object: "glitches" },
                    { id: "neg-m6", english: "The train is not running on time due to heavy fog.", hindi: "घने कोहरे के कारण ट्रेन अपने सही समय पर नहीं चल रही है।", subject: "The train", aux: "is not", verb: "is not running", object: "on time" },
                    { id: "neg-m7", english: "Priya isn't taking any medicine for her minor cold.", hindi: "प्रिया अपनी मामूली सर्दी के लिए कोई दवा नहीं ले रही है।", subject: "Priya", aux: "isn't", verb: "isn't taking", object: "medicine" },
                    { id: "neg-m8", english: "The company is not hiring new staff during the freeze.", hindi: "फ्रीज के दौरान कंपनी नए कर्मचारियों की भर्ती नहीं कर रही है।", subject: "The company", aux: "is not", verb: "is not hiring", object: "new staff" },
                    { id: "neg-m9", english: "You aren't paying attention to the security instructions.", hindi: "आप सुरक्षा निर्देशों पर ध्यान नहीं दे रहे हैं।", subject: "You", aux: "aren't", verb: "aren't paying", object: "attention" },
                    { id: "neg-m10", english: "Workers are not operating the heavy machinery without safety gear.", hindi: "कर्मचारी सुरक्षा उपकरण के बिना भारी मशीनरी का संचालन नहीं कर रहे हैं।", subject: "Workers", aux: "are not", verb: "are not operating", object: "machinery" }
                ],
                hard: [
                    { id: "neg-h1", english: "The legal department is not disclosing confidential litigation details to the press.", hindi: "कानूनी विभाग प्रेस को गोपनीय मुकदमेबाजी के विवरण का खुलासा नहीं कर रहा है।", subject: "Department", aux: "is not", verb: "is not disclosing", object: "details" },
                    { id: "neg-h2", english: "Board members are not approving the proposed budget without thorough auditing.", hindi: "बोर्ड सदस्य संपूर्ण ऑडिटिंग के बिना प्रस्तावित बजट को मंजूरी नहीं दे रहे हैं।", subject: "Board members", aux: "are not", verb: "are not approving", object: "budget" },
                    { id: "neg-h3", english: "The security system is not allowing unauthorized access to the server room.", hindi: "सुरक्षा प्रणाली सर्वर रूम में अनधिकृत पहुंच की अनुमति नहीं दे रही है।", subject: "Security system", aux: "is not", verb: "is not allowing", object: "access" },
                    { id: "neg-h4", english: "Market regulators are not overlooking deceptive advertising practices in the industry.", hindi: "बाजार नियामक उद्योग में भ्रामक विज्ञापन प्रथाओं को नजरअंदाज नहीं कर रहे हैं।", subject: "Regulators", aux: "are not", verb: "are not overlooking", object: "practices" },
                    { id: "neg-h5", english: "The hospital staff is not compromising on hygiene protocols during surgery.", hindi: "अस्पताल के कर्मचारी सर्जरी के दौरान स्वच्छता प्रोटोकॉल से समझौता नहीं कर रहे हैं।", subject: "Hospital staff", aux: "is not", verb: "is not compromising", object: "protocols" },
                    { id: "neg-h6", english: "Chief technical officers are not deploying unverified software updates to production.", hindi: "मुख्य तकनीकी अधिकारी प्रोडक्शन में असत्यापित सॉफ़्टवेयर अपडेट तैनात नहीं कर रहे हैं।", subject: "Officers", aux: "are not", verb: "are not deploying", object: "updates" },
                    { id: "neg-h7", english: "International monitors are not detecting any violations of the ceasefire agreement.", hindi: "अंतरराष्ट्रीय निगरानीकर्ता युद्धविराम समझौते के किसी भी उल्लंघन का पता नहीं लगा रहे हैं।", subject: "Monitors", aux: "are not", verb: "are not detecting", object: "violations" },
                    { id: "neg-h8", english: "Financial auditors are not finding any discrepancies in the annual balance sheet.", hindi: "वित्तीय ऑडिटर वार्षिक बैलेंस शीट में किसी भी विसंगति को नहीं पा रहे हैं।", subject: "Auditors", aux: "are not", verb: "are not finding", object: "discrepancies" },
                    { id: "neg-h9", english: "The academic committee is not postponing the scheduled entrance examinations.", hindi: "अकादमिक समिति निर्धारित प्रवेश परीक्षाओं को स्थगित नहीं कर रही है।", subject: "Committee", aux: "is not", verb: "is not postponing", object: "examinations" },
                    { id: "neg-h10", english: "Renewable energy plants are not generating excess carbon emissions during operation.", hindi: "अक्षय ऊर्जा संयंत्र संचालन के दौरान अत्यधिक कार्बन उत्सर्जन उत्पन्न नहीं कर रहे हैं।", subject: "Energy plants", aux: "are not", verb: "are not generating", object: "emissions" }
                ]
            }
        },

        // 7. Interrogative Sentences (प्रश्नवाचक वाक्य)
        interrogative: {
            title: "Interrogative Sentences (Yes/No Questions)",
            titleHindi: "प्रश्नवाचक वाक्य (क्या वाले प्रश्न)",
            formula: "Am / Is / Are + Subject + V4 (V1+ing) + Object?",
            formulaPlural: "Are + You / We / They + V4?",
            formulaSingular: "Is + He / She / It / Name + V4?",
            formulaI: "Am + I + V4?",
            explanation: "Interrogative sentences ask whether an action is currently happening right now.",
            explanationHindi: "क्या वाले प्रश्नों में सहायक क्रिया (Am/Is/Are) को वाक्य में कर्ता से पहले रखा जाता है।",
            shortAnswers: [
                { question: "Is he working?", yes: "Yes, he is.", no: "No, he isn't." },
                { question: "Are they coming?", yes: "Yes, they are.", no: "No, they aren't." },
                { question: "Am I disturbing you?", yes: "Yes, you are.", no: "No, you aren't." }
            ],
            groups: {
                groupI: {
                    name: "Am + I + V4?",
                    ruleHindi: "जब कर्ता I हो, तो Am को वाक्य के शुरू में रखें।",
                    examples: [
                        { english: "Am I speaking clearly?", hindi: "क्या मैं स्पष्ट बोल रहा हूँ?", verb: "Am ... speaking" }
                    ]
                },
                groupSingular: {
                    name: "Is + He / She / It / Name + V4?",
                    ruleHindi: "जब कर्ता एकवचन हो, तो Is को वाक्य के शुरू में रखें।",
                    examples: [
                        { english: "Is he watching TV?", hindi: "क्या वह टीवी देख रहा है?", verb: "Is ... watching" }
                    ]
                },
                groupPlural: {
                    name: "Are + You / We / They + V4?",
                    ruleHindi: "जब कर्ता बहुवचन या You/We/They हो, तो Are को वाक्य के शुरू में रखें।",
                    examples: [
                        { english: "Are they listening to music?", hindi: "क्या वे संगीत सुन रहे हैं?", verb: "Are ... listening" }
                    ]
                }
            },
            sentences: {
                easy: [
                    { id: "int-e1", english: "Are you reading a newspaper?", hindi: "क्या आप समाचार पत्र पढ़ रहे हैं?", aux: "Are", subject: "you", verb: "are reading", object: "newspaper" },
                    { id: "int-e2", english: "Is she cooking food in the kitchen?", hindi: "क्या वह रसोई में खाना बना रही है?", aux: "Is", subject: "she", verb: "is cooking", object: "food" },
                    { id: "int-e3", english: "Is he driving the car carefully?", hindi: "क्या वह सावधानी से कार चला रहा है?", aux: "Is", subject: "he", verb: "is driving", object: "car" },
                    { id: "int-e4", english: "Are they playing football in the garden?", hindi: "क्या वे बगीचे में फुटबॉल खेल रहे हैं?", aux: "Are", subject: "they", verb: "are playing", object: "football" },
                    { id: "int-e5", english: "Am I speaking clearly to you?", hindi: "क्या मैं आपसे स्पष्ट बोल रहा हूँ?", aux: "Am", subject: "I", verb: "am speaking", object: "clearly" },
                    { id: "int-e6", english: "Is Rahul studying for his exam?", hindi: "क्या राहुल अपनी परीक्षा के लिए पढ़ रहा है?", aux: "Is", subject: "Rahul", verb: "is studying", object: "for exam" },
                    { id: "int-e7", english: "Are we going to the market now?", hindi: "क्या हम अभी बाजार जा रहे हैं?", aux: "Are", subject: "we", verb: "are going", object: "to market" },
                    { id: "int-e8", english: "Is it raining outside?", hindi: "क्या बाहर बारिश हो रही है?", aux: "Is", subject: "it", verb: "is raining", object: "outside" },
                    { id: "int-e9", english: "Are the children watching cartoons?", hindi: "क्या बच्चे कार्टून देख रहे हैं?", aux: "Are", subject: "the children", verb: "are watching", object: "cartoons" },
                    { id: "int-e10", english: "Is the baby sleeping right now?", hindi: "क्या बच्चा अभी सो रहा है?", aux: "Is", subject: "the baby", verb: "is sleeping", object: "right now" }
                ],
                medium: [
                    { id: "int-m1", english: "Are you attending the online workshop this afternoon?", hindi: "क्या आप आज दोपहर ऑनलाइन कार्यशाला में भाग ले रहे हैं?", aux: "Are", subject: "you", verb: "are attending", object: "workshop" },
                    { id: "int-m2", english: "Is she preparing dinner for the family members?", hindi: "क्या वह परिवार के सदस्यों के लिए रात का खाना तैयार कर रही है?", aux: "Is", subject: "she", verb: "is preparing", object: "dinner" },
                    { id: "int-m3", english: "Are they traveling to Mumbai by train tomorrow?", hindi: "क्या वे कल ट्रेन से मुंबई की यात्रा कर रहे हैं?", aux: "Are", subject: "they", verb: "are traveling", object: "to Mumbai" },
                    { id: "int-m4", english: "Is your brother working on his college project?", hindi: "क्या आपका भाई अपने कॉलेज प्रोजेक्ट पर काम कर रहा है?", aux: "Is", subject: "your brother", verb: "is working", object: "on project" },
                    { id: "int-m5", english: "Am I bothering you with too many questions?", hindi: "क्या मैं आपको बहुत सारे सवालों से परेशान कर रहा हूँ?", aux: "Am", subject: "I", verb: "am bothering", object: "you" },
                    { id: "int-m6", english: "Is the manager reviewing the monthly sales report?", hindi: "क्या मैनेजर मासिक बिक्री रिपोर्ट की समीक्षा कर रहा है?", aux: "Is", subject: "the manager", verb: "is reviewing", object: "sales report" },
                    { id: "int-m7", english: "Are the engineers repairing the damaged bridge?", hindi: "क्या इंजीनियर क्षतिग्रस्त पुल की मरम्मत कर रहे हैं?", aux: "Are", subject: "the engineers", verb: "are repairing", object: "bridge" },
                    { id: "int-m8", english: "Is your mother feeling better today?", hindi: "क्या आपकी माँ आज बेहतर महसूस कर रही हैं?", aux: "Is", subject: "your mother", verb: "is feeling", object: "better" },
                    { id: "int-m9", english: "Are we meeting the supervisor after lunch?", hindi: "क्या हम दोपहर के भोजन के बाद पर्यवेक्षक से मिल रहे हैं?", aux: "Are", subject: "we", verb: "are meeting", object: "supervisor" },
                    { id: "int-m10", english: "Is the computer updating its operating system automatically?", hindi: "क्या कंप्यूटर अपना ऑपरेटिंग सिस्टम स्वचालित रूप से अपडेट कर रहा है?", aux: "Is", subject: "computer", verb: "is updating", object: "OS" }
                ],
                hard: [
                    { id: "int-h1", english: "Is the parliamentary committee reviewing the proposed tax reform bill today?", hindi: "क्या संसदीय समिति आज प्रस्तावित कर सुधार विधेयक की समीक्षा कर रही है?", aux: "Is", subject: "committee", verb: "is reviewing", object: "tax bill" },
                    { id: "int-h2", english: "Are international delegates attending the global climate summit in Berlin?", hindi: "क्या अंतरराष्ट्रीय प्रतिनिधि बर्लिन में वैश्विक जलवायु शिखर सम्मेलन में भाग ले रहे हैं?", aux: "Are", subject: "delegates", verb: "are attending", object: "summit" },
                    { id: "int-h3", english: "Is the cybersecurity team investigating the recent network breach attempt?", hindi: "क्या साइबर सुरक्षा टीम हाल ही में नेटवर्क उल्लंघन के प्रयास की जांच कर रही है?", aux: "Is", subject: "team", verb: "is investigating", object: "breach attempt" },
                    { id: "int-h4", english: "Are senior economists forecasting higher inflation rates for the next quarter?", hindi: "क्या वरिष्ठ अर्थशास्त्री अगली तिमाही के लिए उच्च मुद्रास्फीति दर का पूर्वानुमान लगा रहे हैं?", aux: "Are", subject: "economists", verb: "are forecasting", object: "inflation" },
                    { id: "int-h5", english: "Is the pharmaceutical company conducting advanced clinical trials on human subjects?", hindi: "क्या दवा कंपनी मानव विषयों पर उन्नत नैदानिक परीक्षण कर रही है?", aux: "Is", subject: "company", verb: "is conducting", object: "trials" },
                    { id: "int-h6", english: "Are urban developers constructing eco-friendly residential complexes in the suburbs?", hindi: "क्या शहरी डेवलपर उपनगरों में पर्यावरण-अनुकूल आवासीय परिसरों का निर्माण कर रहे हैं?", aux: "Are", subject: "developers", verb: "are constructing", object: "complexes" },
                    { id: "int-h7", english: "Is the chief executive officer presenting the annual strategic vision to investors?", hindi: "क्या मुख्य कार्यकारी अधिकारी निवेशकों के समक्ष वार्षिक रणनीतिक दृष्टिकोण प्रस्तुत कर रहे हैं?", aux: "Is", subject: "CEO", verb: "is presenting", object: "vision" },
                    { id: "int-h8", english: "Are flight operators rescheduling international flights due to adverse weather?", hindi: "क्या उड़ान संचालक प्रतिकूल मौसम के कारण अंतरराष्ट्रीय उड़ानों का समय पुनर्निर्धारित कर रहे हैं?", aux: "Are", subject: "operators", verb: "are rescheduling", object: "flights" },
                    { id: "int-h9", english: "Am I adhering to the recommended formatting guidelines for this research paper?", hindi: "क्या मैं इस शोध पत्र के लिए अनुशंसित प्रारूपण दिशा-निर्देशों का पालन कर रहा हूँ?", aux: "Am", subject: "I", verb: "am adhering", object: "guidelines" },
                    { id: "int-h10", english: "Are environmentalists measuring groundwater contamination near industrial zones?", hindi: "क्या पर्यावरणविद औद्योगिक क्षेत्रों के पास भूजल संदूषण को माप रहे हैं?", aux: "Are", subject: "environmentalists", verb: "are measuring", object: "contamination" }
                ]
            }
        },

        // 8. WH Questions (WH प्रश्न)
        whQuestions: {
            title: "WH Questions",
            titleHindi: "WH प्रश्नवाचक वाक्य",
            formula: "WH Word + am / is / are + Subject + V4 (V1+ing) + Object?",
            formulaPlural: "WH Word + are + You/We/They + V4?",
            formulaSingular: "WH Word + is + He/She/It/Name + V4?",
            formulaI: "WH Word + am + I + V4?",
            explanation: "WH Questions seek specific details (What, Where, Why, When, Who, How) about an action in progress.",
            explanationHindi: "विशेष जानकारी वाले प्रश्नों के लिए WH शब्द (What, Where, Why आदि) को Am/Is/Are से भी पहले लगाया जाता है।",
            examplesShowcase: [
                { english: "What are you doing right now?", hindi: "आप अभी क्या कर रहे हैं?", whWord: "What", aux: "are" },
                { english: "Where is he going?", hindi: "वह कहाँ जा रहा है?", whWord: "Where", aux: "is" },
                { english: "Why are they laughing?", hindi: "वे क्यों हंस रहे हैं?", whWord: "Why", aux: "are" },
                { english: "Who is speaking on stage?", hindi: "मंच पर कौन बोल रहा है?", whWord: "Who", aux: "is" }
            ],
            whoSpecialCase: {
                title: "Special Case: 'Who' as Subject",
                titleHindi: "विशेष नियम: जब 'Who' ही कर्ता (Subject) हो",
                formula: "Who + is / are + V4 + Object?",
                example: "Who is calling you?",
                exampleHindi: "आपको कौन बुला रहा है?"
            },
            sentences: {
                easy: [
                    { id: "wh-e1", english: "What are you doing right now?", hindi: "आप अभी क्या कर रहे हैं?", whWord: "What", aux: "are", subject: "you", verb: "doing" },
                    { id: "wh-e2", english: "Where is she going?", hindi: "वह कहाँ जा रही है?", whWord: "Where", aux: "is", subject: "she", verb: "going" },
                    { id: "wh-e3", english: "Why are they laughing?", hindi: "वे क्यों हंस रहे हैं?", whWord: "Why", aux: "are", subject: "they", verb: "laughing" },
                    { id: "wh-e4", english: "When is he coming home?", hindi: "वह घर कब आ रहा है?", whWord: "When", aux: "is", subject: "he", verb: "coming" },
                    { id: "wh-e5", english: "Who is calling you on the phone?", hindi: "आपको फोन पर कौन बुला रहा है?", whWord: "Who", aux: "is", subject: "Who", verb: "calling" },
                    { id: "wh-e6", english: "How are you feeling today?", hindi: "आज आप कैसा महसूस कर रहे हैं?", whWord: "How", aux: "are", subject: "you", verb: "feeling" },
                    { id: "wh-e7", english: "What is Rahul reading?", hindi: "राहुल क्या पढ़ रहा है?", whWord: "What", aux: "is", subject: "Rahul", verb: "reading" },
                    { id: "wh-e8", english: "Where are we meeting tomorrow?", hindi: "हम कल कहाँ मिल रहे हैं?", whWord: "Where", aux: "are", subject: "we", verb: "meeting" },
                    { id: "wh-e9", english: "Why is the baby crying?", hindi: "बच्चा क्यों रो रहा है?", whWord: "Why", aux: "is", subject: "the baby", verb: "crying" },
                    { id: "wh-e10", english: "Which book are you reading these days?", hindi: "आप इन दिनों कौन सी किताब पढ़ रहे हैं?", whWord: "Which", aux: "are", subject: "you", verb: "reading" }
                ],
                medium: [
                    { id: "wh-m1", english: "What are you preparing for your final examinations?", hindi: "आप अपनी अंतिम परीक्षाओं के लिए क्या तैयार कर रहे हैं?", whWord: "What", aux: "are", subject: "you", verb: "preparing" },
                    { id: "wh-m2", english: "Where is the doctor conducting patient consultations today?", hindi: "डॉक्टर आज रोगियों का परामर्श कहाँ कर रहे हैं?", whWord: "Where", aux: "is", subject: "the doctor", verb: "conducting" },
                    { id: "wh-m3", english: "Why is your team working late in the office tonight?", hindi: "आपकी टीम आज रात कार्यालय में देर तक काम क्यों कर रही है?", whWord: "Why", aux: "is", subject: "your team", verb: "working" },
                    { id: "wh-m4", english: "When are the guests arriving at the hotel venue?", hindi: "अतिथि होटल स्थल पर कब पहुँच रहे हैं?", whWord: "When", aux: "are", subject: "the guests", verb: "arriving" },
                    { id: "wh-m5", english: "How is she managing her work alongside studies?", hindi: "वह पढ़ाई के साथ-साथ अपने काम का प्रबंधन कैसे कर रही है?", whWord: "How", aux: "is", subject: "she", verb: "managing" },
                    { id: "wh-m6", english: "Which course are you pursuing at the university this semester?", hindi: "आप इस सेमेस्टर विश्वविद्यालय में कौन सा कोर्स कर रहे हैं?", whWord: "Which", aux: "are", subject: "you", verb: "pursuing" },
                    { id: "wh-m7", english: "Whose car are you driving to the office this week?", hindi: "आप इस हफ्ते कार्यालय जाने के लिए किसकी कार चला रहे हैं?", whWord: "Whose", aux: "are", subject: "you", verb: "driving" },
                    { id: "wh-m8", english: "Who is leading the project meeting this morning?", hindi: "आज सुबह परियोजना बैठक का नेतृत्व कौन कर रहा है?", whWord: "Who", aux: "is", subject: "Who", verb: "leading" },
                    { id: "wh-m9", english: "Why are the engineers replacing the main power cables?", hindi: "इंजीनियर मुख्य बिजली के केबलों को क्यों बदल रहे हैं?", whWord: "Why", aux: "are", subject: "engineers", verb: "replacing" },
                    { id: "wh-m10", english: "Where are they setting up the new community health center?", hindi: "वे नया सामुदायिक स्वास्थ्य केंद्र कहाँ स्थापित कर रहे हैं?", whWord: "Where", aux: "are", subject: "they", verb: "setting up" }
                ],
                hard: [
                    { id: "wh-h1", english: "What strategies is the marketing team deploying to increase customer engagement?", hindi: "ग्राहक जुड़ाव बढ़ाने के लिए विपणन टीम कौन सी रणनीतियाँ तैनात कर रही है?", whWord: "What", aux: "is", subject: "marketing team", verb: "deploying" },
                    { id: "wh-h2", english: "Where are government authorities constructing the new international airport facility?", hindi: "सरकारी प्राधिकरण नए अंतरराष्ट्रीय हवाई अड्डे की सुविधा का निर्माण कहाँ कर रहे हैं?", whWord: "Where", aux: "are", subject: "authorities", verb: "constructing" },
                    { id: "wh-h3", english: "Why are financial analysts projecting market volatility during the upcoming election cycle?", hindi: "वित्तीय विश्लेषक आगामी चुनाव चक्र के दौरान बाजार में अस्थिरता का अनुमान क्यों लगा रहे हैं?", whWord: "Why", aux: "are", subject: "analysts", verb: "projecting" },
                    { id: "wh-h4", english: "How is the IT department addressing critical security vulnerabilities in the system?", hindi: "आईटी विभाग प्रणाली में गंभीर सुरक्षा कमियों को कैसे दूर कर रहा है?", whWord: "How", aux: "is", subject: "IT department", verb: "addressing" },
                    { id: "wh-h5", english: "When are airline operators introducing direct flights to European destinations?", hindi: "एयरलाइन संचालक यूरोपीय गंतव्यों के लिए सीधी उड़ानें कब शुरू कर रहे हैं?", whWord: "When", aux: "are", subject: "operators", verb: "introducing" },
                    { id: "wh-h6", english: "Which technological innovations are software architects integrating into the app?", hindi: "सॉफ्टवेयर आर्किटेक्ट ऐप में कौन से तकनीकी नवाचारों को एकीकृत कर रहे हैं?", whWord: "Which", aux: "are", subject: "architects", verb: "integrating" },
                    { id: "wh-h7", english: "Whose authorization are developers waiting for before executing the deployment script?", hindi: "डेवलपर्स परिनियोजन स्क्रिप्ट निष्पादित करने से पहले किसके प्राधिकरण की प्रतीक्षा कर रहे हैं?", whWord: "Whose", aux: "are", subject: "developers", verb: "waiting for" },
                    { id: "wh-h8", english: "Who is coordinating the humanitarian relief efforts in the flood-affected regions?", hindi: "बाढ़ प्रभावित क्षेत्रों में मानवीय सहायता प्रयासों का समन्वय कौन कर रहा है?", whWord: "Who", aux: "is", subject: "Who", verb: "coordinating" },
                    { id: "wh-h9", english: "Why is the central bank raising benchmark interest rates this quarter?", hindi: "केंद्रीय बैंक इस तिमाही में बेंचमार्क ब्याज दरों को क्यों बढ़ा रहा है?", whWord: "Why", aux: "is", subject: "central bank", verb: "raising" },
                    { id: "wh-h10", english: "How are environmental scientists measuring microplastic concentration in oceanic waters?", hindi: "पर्यावरण वैज्ञानिक महासागरीय जल में माइक्रोप्लास्टिक सांद्रता को कैसे माप रहे हैं?", whWord: "How", aux: "are", subject: "scientists", verb: "measuring" }
                ]
            }
        },

        // 9. Common Mistakes & Corrections / सामान्य गलतियाँ
        commonMistakes: {
            title: "Common Mistakes & Corrections",
            titleHindi: "सामान्य गलतियाँ और सही नियम (15 Mistakes)",
            introduction: "Avoid these 15 common errors while learning Present Continuous Tense.",
            introductionHindi: "Present Continuous में अक्सर होने वाली इन 15 प्रमुख गलतियों से बचें:",
            mistakes: [
                {
                    id: "missing-auxiliary",
                    title: "1. Missing Auxiliary Verb (am/is/are भूल जाना)",
                    titleHindi: "is/am/are का प्रयोग न करना",
                    wrong: "He working in office.",
                    correct: "He is working in office.",
                    explanation: "Main verb with -ing cannot be used alone without am/is/are in Present Continuous.",
                    explanationHindi: "Present Continuous में -ing क्रिया के साथ am/is/are लगाना अनिवार्य है।",
                    rule: "Subject + am/is/are + V4"
                },
                {
                    id: "wrong-auxiliary",
                    title: "2. Wrong Auxiliary Verb Agreement (गलत सहायक क्रिया)",
                    titleHindi: "कर्ता के साथ गलत सहायक क्रिया का प्रयोग",
                    wrong: "I is reading a book.",
                    correct: "I am reading a book.",
                    explanation: "Use 'am' only with 'I'. Use 'is' with singular subjects and 'are' with plural subjects.",
                    explanationHindi: "I के साथ हमेशा am, एकवचन के साथ is तथा बहुवचन के साथ are लगाएं।",
                    rule: "I → am | Singular → is | Plural → are"
                },
                {
                    id: "using-v1-instead-of-v4",
                    title: "3. Using V1 instead of V4 after is/am/are",
                    titleHindi: "is/am/are के बाद -ing न लगाना (V1 का प्रयोग)",
                    wrong: "She is speak English.",
                    correct: "She is speaking English.",
                    explanation: "Always use V4 (V1+ing) after am/is/are in Present Continuous.",
                    explanationHindi: "am/is/are के बाद हमेशा V1+ing (V4) का प्रयोग होता है।",
                    rule: "am/is/are + V4 (NEVER is + V1)"
                },
                {
                    id: "using-v2-instead-of-v4",
                    title: "4. Using V2 (Past form) after auxiliary",
                    titleHindi: "is/am/are के बाद V2 का प्रयोग करना",
                    wrong: "They are went to market.",
                    correct: "They are going to market.",
                    explanation: "Do not use past tense verbs after am/is/are.",
                    explanationHindi: "am/is/are के बाद V2 (went) का प्रयोग नहीं होता, V4 (going) आता है।",
                    rule: "are + V4 (going)"
                },
                {
                    id: "using-v3-instead-of-v4",
                    title: "5. Using V3 (Past participle) after auxiliary",
                    titleHindi: "is/am/are के बाद V3 का प्रयोग करना",
                    wrong: "He is eaten food.",
                    correct: "He is eating food.",
                    explanation: "V3 is used in Perfect or Passive forms, not in active Present Continuous.",
                    explanationHindi: "Present Continuous में -ing क्रिया (V4) का प्रयोग करें।",
                    rule: "is + V4 (eating)"
                },
                {
                    id: "stative-verbs-error",
                    title: "6. Using Stative Verbs in Continuous",
                    titleHindi: "Stative Verbs (भावनाओं/ज्ञान) में -ing लगाना",
                    wrong: "I am knowing the answer.",
                    correct: "I know the answer.",
                    explanation: "Stative verbs like know, love, like, understand, want are used in Simple Present.",
                    explanationHindi: "know, understand, love, want जैसी Stative Verbs का प्रयोग continuous में नहीं होता।",
                    rule: "Use Simple Present for Stative Verbs."
                },
                {
                    id: "forgetting-double-consonant",
                    title: "7. Forgetting Double Consonant in V4 Spelling",
                    titleHindi: "V4 में अंतिम अक्षर दोहराना भूल जाना",
                    wrong: "He is runing fast.",
                    correct: "He is running fast.",
                    explanation: "Short CVC verbs double the final consonant before adding -ing.",
                    explanationHindi: "CVC क्रियाओं (run, sit, swim) में -ing जोड़ते समय अंतिम अक्षर डबल होता है।",
                    rule: "run → running, sit → sitting"
                },
                {
                    id: "forgetting-drop-e",
                    title: "8. Forgetting to drop silent -e",
                    titleHindi: "अंतिम silent -e को हटाना भूल जाना",
                    wrong: "She is makeing tea.",
                    correct: "She is making tea.",
                    explanation: "Verbs ending in silent -e drop -e before adding -ing.",
                    explanationHindi: "अंतिम silent -e को हटाकर -ing जोड़ा जाता है।",
                    rule: "make → making, write → writing"
                },
                {
                    id: "incorrect-ie-to-y",
                    title: "9. Incorrect -ie to -y Transformation",
                    titleHindi: "-ie क्रियाओं की गलत वर्तनी",
                    wrong: "He is lieing on the bed.",
                    correct: "He is lying on the bed.",
                    explanation: "Verbs ending in -ie change -ie to -y before adding -ing.",
                    explanationHindi: "-ie को बदलकर -y+ing किया जाता है।",
                    rule: "lie → lying, die → dying"
                },
                {
                    id: "wrong-question-word-order",
                    title: "10. Incorrect Question Word Order",
                    titleHindi: "प्रश्नवाचक वाक्य में गलत पदक्रम",
                    wrong: "Why you are crying?",
                    correct: "Why are you crying?",
                    explanation: "In questions, the auxiliary verb (am/is/are) must come BEFORE the subject.",
                    explanationHindi: "प्रश्न में am/is/are हमेशा कर्ता (Subject) से पहले आता है।",
                    rule: "WH-word + am/is/are + Subject + V4?"
                },
                {
                    id: "forgetting-question-mark",
                    title: "11. Forgetting Question Mark in Interrogative",
                    titleHindi: "प्रश्नवाचक चिह्न भूल जाना",
                    wrong: "Is he working right now.",
                    correct: "Is he working right now?",
                    explanation: "Always place a question mark at the end of an interrogative sentence.",
                    explanationHindi: "प्रश्नवाचक वाक्य के अंत में प्रश्नवाचक चिह्न (?) लगाना अनिवार्य है।",
                    rule: "Am/Is/Are + Subject + V4 + Object?"
                },
                {
                    id: "using-do-does-in-continuous",
                    title: "12. Using Do/Does in Continuous Questions",
                    titleHindi: "Continuous में Do/Does का गलत प्रयोग",
                    wrong: "Do you reading a book?",
                    correct: "Are you reading a book?",
                    explanation: "Do/Does is used in Simple Present, not Present Continuous.",
                    explanationHindi: "Present Continuous में Do/Does की जगह Are/Is/Am का प्रयोग करें।",
                    rule: "Are + you + V4?"
                },
                {
                    id: "double-auxiliary-error",
                    title: "13. Double Auxiliary Verb Error",
                    titleHindi: "दोहरी सहायक क्रिया की गलती",
                    wrong: "He is does working.",
                    correct: "He is working.",
                    explanation: "Do not combine 'is' and 'does' together in a single clause.",
                    explanationHindi: "is और does का एक साथ प्रयोग न करें।",
                    rule: "Use only 'is' + V4"
                },
                {
                    id: "confusing-habit-with-continuous",
                    title: "14. Confusing Simple Present Routine with Continuous",
                    titleHindi: "दैनिक आदत के लिए Continuous का गलत प्रयोग",
                    wrong: "I am going to school every day.",
                    correct: "I go to school every day.",
                    explanation: "Daily routines require Simple Present (go), not Continuous.",
                    explanationHindi: "रोज़ की आदत के लिए Simple Present (go) का प्रयोग करें।",
                    rule: "Routine → Simple Present | Right Now → Continuous"
                },
                {
                    id: "incorrect-negative-structure",
                    title: "15. Incorrect Negative Word Order",
                    titleHindi: "नकारात्मक वाक्य में 'not' की गलत स्थिति",
                    wrong: "He not is playing.",
                    correct: "He is not playing.",
                    explanation: "'not' must be placed immediately AFTER am/is/are.",
                    explanationHindi: "'not' हमेशा am/is/are के ठीक बाद आता है।",
                    rule: "Subject + am/is/are + not + V4"
                }
            ]
        },

        // 10. Summary & Revision / संक्षिप्त पुनरावृत्ति
        summary: {
            title: "Present Continuous Summary",
            titleHindi: "अपूर्ण वर्तमान काल — संक्षिप्त पुनरावृत्ति",
            introduction: "Master Present Continuous Tense with quick rules, major uses, formulas, and 15 revision examples.",
            introductionHindi: "Present Continuous Tense की त्वरित पुनरावृत्ति और 15 अभ्यास उदाहरण:",
            quickRules: [
                "I → am + V4  |  He/She/It/Singular → is + V4  |  You/We/They/Plural → are + V4",
                "Positive: Subject + am/is/are + V4 + Object",
                "Negative: Subject + am/is/are + not + V4 + Object",
                "Interrogative: Am/Is/Are + Subject + V4 + Object?",
                "WH Question: WH-word + am/is/are + Subject + V4 + Object?",
                "Stative verbs (know, want, like, love) take Simple Present, not Continuous."
            ],
            memoryRule: {
                ruleTitle: "MEMORY RULE: am/is/are आया → Main Verb V4 (ing) में आया!",
                ruleTitleHindi: "याद रखने का नियम: am/is/are आया → Main Verb हमेशा V4 (ing form) में आया!",
                ruleText: "जब भी वाक्य में am, is, या are सहायक क्रिया के रूप में आता है, मुख्य क्रिया हमेशा V4 (-ing form) में होगी।"
            },
            sentences: {
                easy: [
                    { id: "sum-e1", english: "I am learning English.", hindi: "मैं अंग्रेजी सीख रहा हूँ।", note: "Subject 'I' takes 'am' + V4" },
                    { id: "sum-e2", english: "She is cooking rice.", hindi: "वह चावल बना रही है।", note: "Singular subject takes 'is' + V4" },
                    { id: "sum-e3", english: "They are playing football.", hindi: "वे फुटबॉल खेल रहे हैं।", note: "Plural subject takes 'are' + V4" },
                    { id: "sum-e4", english: "He is not sleeping.", hindi: "वह नहीं सो रहा है।", note: "Negative with 'is not' + V4" },
                    { id: "sum-e5", english: "Are you watching TV?", hindi: "क्या आप टीवी देख रहे हैं?", note: "Interrogative starting with 'Are'" }
                ],
                medium: [
                    { id: "sum-m1", english: "He is writing a new book these days.", hindi: "वह इन दिनों एक नई किताब लिख रहा है।", note: "Temporary action around present" },
                    { id: "sum-m2", english: "We are traveling to Delhi tomorrow.", hindi: "हम कल दिल्ली की यात्रा कर रहे हैं।", note: "Fixed near-future plan" },
                    { id: "sum-m3", english: "She isn't attending the workshop today.", hindi: "वह आज कार्यशाला में भाग नहीं ले रही है।", note: "Contraction 'isn't' + V4" },
                    { id: "sum-m4", english: "Why are they arguing outside?", hindi: "वे बाहर बहस क्यों कर रहे हैं?", note: "WH question with 'Why' + are" },
                    { id: "sum-m5", english: "Your speaking skill is improving steadily.", hindi: "आपकी बोलने की क्षमता में लगातार सुधार हो रहा है।", note: "Changing/developing situation" }
                ],
                hard: [
                    { id: "sum-h1", english: "Scientists are investigating climate changes across polar regions.", hindi: "वैज्ञानिक ध्रुवीय क्षेत्रों में जलवायु परिवर्तनों की जांच कर रहे हैं।", note: "Complex subject with 'are' + V4" },
                    { id: "sum-h2", english: "The management is not compromising on quality standards.", hindi: "प्रबंधन गुणवत्ता मानकों से समझौता नहीं कर रहा है।", note: "Professional negative continuous" },
                    { id: "sum-h3", english: "Which software are developers integrating into the security platform?", hindi: "डेवलपर्स सुरक्षा प्लेटफॉर्म में कौन सा सॉफ्टवेयर एकीकृत कर रहे हैं?", note: "Complex WH question" },
                    { id: "sum-h4", english: "Who is coordinating the emergency medical response team?", hindi: "आपातकालीन चिकित्सा प्रतिक्रिया टीम का समन्वय कौन कर रहा है?", note: "Who as subject with 'is' + V4" },
                    { id: "sum-h5", english: "Urban authorities are modernizing public transportation networks.", hindi: "शहरी प्राधिकरण सार्वजनिक परिवहन नेटवर्क का आधुनिकीकरण कर रहे हैं।", note: "Ongoing development trend" }
                ]
            }
        },

        // 11. Exercises (Practice Sentences - 120 Total Items)
        exercises: {
            title: "Present Continuous Practice Sentences",
            titleHindi: "अपूर्ण वर्तमान काल — अभ्यास (120 Practice Sentences)",
            introduction: "Practice all 120 sentences across Positive, Negative, Interrogative, and WH Questions to master Present Continuous Tense.",
            introductionHindi: "Present Continuous Tense के 120 अभ्यास वाक्यों (सकारात्मक, नकारात्मक, प्रश्नवाचक एवं WH प्रश्न) के माध्यम से पूरा अभ्यास करें।",
            categories: []
        },

        // 12. Quiz Configuration
        quiz: {
            title: "Present Continuous Quiz",
            titleHindi: "अपूर्ण वर्तमान काल — ज्ञान परीक्षा",
            questions: []
        }
    }
};

// Initialize categories referencing existing sections (120 Practice Sentences total)
presentContinuousLesson.sections.exercises.categories = [
    {
        id: "positive",
        title: "Positive Sentences Practice",
        titleHindi: "1. सकारात्मक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Positive Sentence",
        sentences: presentContinuousLesson.sections.positive.sentences
    },
    {
        id: "negative",
        title: "Negative Sentences Practice",
        titleHindi: "2. नकारात्मक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Negative Sentence",
        sentences: presentContinuousLesson.sections.negative.sentences
    },
    {
        id: "interrogative",
        title: "Interrogative Sentences Practice",
        titleHindi: "3. प्रश्नवाचक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Yes/No Question",
        sentences: presentContinuousLesson.sections.interrogative.sentences
    },
    {
        id: "whQuestions",
        title: "WH Questions Practice",
        titleHindi: "4. WH प्रश्न अभ्यास (30 Sentences)",
        typeLabel: "WH Question",
        sentences: presentContinuousLesson.sections.whQuestions.sentences
    }
];

/**
 * Get the complete Present Continuous lesson object
 * @returns {object}
 */
export function getPresentContinuousLesson() {
    return { ...presentContinuousLesson };
}

/**
 * Get a specific section of Present Continuous lesson data
 * @param {string} sectionName 
 * @returns {object|Array|null}
 */
export function getPresentContinuousSection(sectionName) {
    if (!sectionName || !presentContinuousLesson.sections) return null;
    return presentContinuousLesson.sections[sectionName] || null;
}
