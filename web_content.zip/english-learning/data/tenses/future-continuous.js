/**
 * Central Lesson Data for Future Continuous Tense (अपूर्ण भविष्यत् काल)
 * Single Source of Truth for Future Continuous Tense Module.
 * Follows proven reference architecture established in completed Present, Past & Simple Future Tenses.
 */

const futureContinuousLesson = {
    id: "future-continuous",
    title: "Future Continuous",
    titleHindi: "अपूर्ण भविष्यत् काल (Subject + will be + V1+ing)",
    description: "Learn Future Continuous Tense in simple Hindi & English: Subject + will be + V1+ing + Object.",

    sections: {
        // 1. Identification / पहचान और अवधारणा
        identification: {
            title: "Identification",
            titleHindi: "पहचान और अवधारणा (Identification & Concept)",
            english: "Future Continuous Tense is used to describe an action that will be in progress at a specific point or period in the future.",
            hindi: "Future Continuous Tense का प्रयोग भविष्य में किसी निश्चित समय या समयावधि पर जारी रहने वाले (in progress) कार्यों को व्यक्त करने के लिए किया जाता है।",
            hindiIdentityRule: "पहचान (Hindi Clues): वाक्य के अंत में मुख्य क्रिया के साथ - रहा होगा, रही होगी, रहे होंगे, रहा होऊँगा (जैसे: कर रहा होगा, पढ़ रही होगी, इंतज़ार कर रहे होंगे, काम कर रहा होऊँगा) आता है।",
            points: [
                {
                    english: "Focus is on an action in progress at a future moment.",
                    hindi: "मुख्य ध्यान भविष्य के किसी समय पर कार्य के जारी रहने पर होता है।"
                },
                {
                    english: "Auxiliary Verbs: Use 'will be' for ALL subjects (I, You, He, She, It, We, They, Singular, Plural).",
                    hindi: "सहायक क्रिया: सभी कर्ताओं के साथ केवल 'will be' का प्रयोग होता है।"
                },
                {
                    english: "Main Verb: Always use V1+ing (Present Participle). Never use V1, V2, or V3 after 'will be'.",
                    hindi: "मुख्य क्रिया: 'will be' के बाद हमेशा V1+ing (जैसे: working, studying) का प्रयोग किया जाता है।"
                },
                {
                    english: "Common Future Time Signals: at 8 PM tomorrow, this time tomorrow, this time next week, tomorrow morning, tomorrow evening, next Monday at 10 AM, throughout the afternoon, during the meeting, when you arrive.",
                    hindi: "समय सूचक शब्द: at 8 PM tomorrow (कल रात 8 बजे), this time tomorrow (कल इसी समय), this time next week (अगले हफ्ते इसी समय), tomorrow morning (कल सुबह) आदि।"
                },
                {
                    english: "Context-Based: Time markers establish the future reference point but are not strictly mandatory when context is clear.",
                    hindi: "संदर्भ-आधारित: समय सूचक शब्द भविष्य के संदर्भ बिंदु को स्पष्ट करते हैं, लेकिन संदर्भ स्पष्ट होने पर इनका होना अनिवार्य नहीं है।"
                }
            ],
            comparison: {
                title: "Concept Comparison: Simple Future vs Future Continuous vs Present Continuous vs Future Perfect",
                simpleFuture: {
                    name: "Simple Future (सामान्य भविष्यत्)",
                    formula: "Subject + will + V1",
                    concept: "Future action or decision (भविष्य का कार्य/निर्णय)",
                    example: "I will study at 8 PM tomorrow. (मैं कल रात 8 बजे पढ़ाई करूँगा।)"
                },
                futureContinuous: {
                    name: "Future Continuous (अपूर्ण भविष्यत्)",
                    formula: "Subject + will be + V1+ing",
                    concept: "Action in progress at a future time (भविष्य में जारी कार्य)",
                    example: "I will be studying at 8 PM tomorrow. (मैं कल रात 8 बजे पढ़ रहा होऊँगा।)"
                },
                presentContinuousFuture: {
                    name: "Present Continuous (Future Plan)",
                    formula: "Subject + am/is/are + V1+ing",
                    concept: "Arranged/fixed future plan (पक्की तय योजना)",
                    example: "I am meeting my manager tomorrow. (मैं कल अपने मैनेजर से मिल रहा हूँ।)"
                },
                futurePerfectBasic: {
                    name: "Future Perfect (Basic Contrast)",
                    formula: "Subject + will have + V3",
                    concept: "Action completed by a future deadline (भविष्य की समय-सीमा तक पूरा कार्य)",
                    example: "I will have finished study by 8 PM. (मैं रात 8 बजे तक पढ़ाई पूरी कर चुका होऊँगा।)"
                }
            }
        },

        // 2. Main Uses / प्रमुख उपयोग (Exactly 5 Major Uses)
        uses: {
            title: "Uses & Scenarios",
            titleHindi: "प्रयोग और परिस्थितियाँ (5 Major Uses)",
            list: [
                {
                    id: "use-1",
                    number: 1,
                    title: "Action in Progress at a Specific Future Time",
                    titleHindi: "1. भविष्य में किसी निश्चित समय पर जारी कार्य",
                    explanation: "Expresses an action that will already be in progress at a precise future moment.",
                    explanationHindi: "किसी विशेष भविष्य काल (जैसे कल 8 बजे) पर जो कार्य चल रहा होगा उसे व्यक्त करने के लिए।",
                    why: "At 8 PM, the studying activity will be actively happening.",
                    whyHindi: "रात 8 बजे पढ़ाई का काम चालू स्थिति में होगा।",
                    examples: [
                        { english: "I will be studying at 8 PM tomorrow.", hindi: "मैं कल रात 8 बजे पढ़ रहा होऊँगा।" },
                        { english: "She will be sleeping at midnight.", hindi: "वह आधी रात को सो रही होगी।" },
                        { english: "They will be attending the lecture at 10 AM.", hindi: "वे सुबह 10 बजे लेक्चर में शामिल हो रहे होंगे।" }
                    ]
                },
                {
                    id: "use-2",
                    number: 2,
                    title: "Action in Progress During a Future Period",
                    titleHindi: "2. भविष्य की किसी समयावधि के दौरान जारी कार्य",
                    explanation: "Describes continuous activity taking place throughout a continuous period in the future.",
                    explanationHindi: "भविष्य की किसी लंबी अवधि (जैसे पूरे दोपहर, पूरे सप्ताह) के दौरान जारी रहने वाले कार्य के लिए।",
                    why: "Focus is on duration and continuous effort throughout the afternoon.",
                    whyHindi: "दोपहर भर लगातार काम चलने पर ज़ोर है।",
                    examples: [
                        { english: "She will be working throughout the afternoon.", hindi: "वह दोपहर भर काम कर रही होगी।" },
                        { english: "We will be traveling all day tomorrow.", hindi: "हम कल पूरा दिन यात्रा कर रहे होंगे।" },
                        { english: "The team will be testing the code all week.", hindi: "टीम पूरा सप्ताह कोड की टेस्टिंग कर रही होगी।" }
                    ]
                },
                {
                    id: "use-3",
                    number: 3,
                    title: "Future Background Activity Around Another Future Event",
                    titleHindi: "3. भविष्य की दूसरी घटना के समय पृष्ठभूमि में जारी कार्य",
                    explanation: "Used to show a background action in progress when another short future event happens.",
                    explanationHindi: "जब भविष्य में कोई घटना घटेगी, उस समय पहले से चल रहे पृष्ठभूमि कार्य को दर्शाने के लिए।",
                    why: "Arrival is the point of reference; working is the ongoing background action.",
                    whyHindi: "आगमन एक संदर्भ बिंदु है; काम करना जारी पृष्ठभूमि कार्य है।",
                    examples: [
                        { english: "When you arrive, I will be working.", hindi: "जब तुम आओगे, मैं काम कर रहा होऊँगा।" },
                        { english: "When the movie starts, they will be buying popcorn.", hindi: "जब फिल्म शुरू होगी, वे पॉपकॉर्न खरीद रहे होंगे।" },
                        { english: "She will be waiting when the train reaches the station.", hindi: "जब ट्रेन स्टेशन पहुँचेगी, वह इंतज़ार कर रही होगी।" }
                    ]
                },
                {
                    id: "use-4",
                    number: 4,
                    title: "Asking Politely About Someone's Expected Future Activity",
                    titleHindi: "4. किसी की भविष्य की योजना या कार्य के बारे में विनम्रता से पूछना",
                    explanation: "Used to inquire politely about plans without sounding demanding or pressuring.",
                    explanationHindi: "बिना दबाव डाले या विनम्रता से किसी के आगामी कार्यक्रम या साधन के उपयोग के बारे में पूछने के लिए।",
                    why: "Sounds polite, neutral, and respectful in casual or business contexts.",
                    whyHindi: "यह संवाद को अधिक विनम्र और स्वाभाविक बनाता है।",
                    examples: [
                        { english: "Will you be using the car tonight?", hindi: "क्या आप आज रात कार का इस्तेमाल कर रहे होंगे?" },
                        { english: "Will she be joining us for lunch?", hindi: "क्या वह दोपहर के खाने में हमारे साथ शामिल हो रही होगी?" },
                        { english: "Will you be passing by the post office later?", hindi: "क्या आप बाद में डाकघर के पास से गुज़र रहे होंगे?" }
                    ]
                },
                {
                    id: "use-5",
                    number: 5,
                    title: "Expected or Scheduled Activity in Progress at a Future Time",
                    titleHindi: "5. अपेक्षित या निर्धारित कार्य जो भविष्य में जारी रहेगा",
                    explanation: "Refers to activities that are expected to happen as part of routine, schedule, or course of events.",
                    explanationHindi: "नियमित दिनचर्या, तय कार्यक्रम या स्वाभाविक घटनाक्रम के तहत होने वाले कार्यों के लिए।",
                    why: "Refers to regular expected progress during that time frame.",
                    whyHindi: "उस समय अवधि के दौरान नियमित रूप से अपेक्षित कार्य को दर्शाता है।",
                    examples: [
                        { english: "They will be traveling tomorrow evening.", hindi: "वे कल शाम यात्रा कर रहे होंगे।" },
                        { english: "The professor will be delivering lectures next month.", hindi: "प्रोफेसर अगले महीने व्याख्यान दे रहे होंगे।" },
                        { english: "Our company will be holding annual meeting next Friday.", hindi: "हमारी कंपनी अगले शुक्रवार को वार्षिक बैठक आयोजित कर रही होगी।" }
                    ]
                }
            ]
        },

        // 3. Structure & Formulas / संरचना और सूत्र
        structure: {
            title: "Structure & Formulas",
            titleHindi: "वाक्य संरचना एवं सूत्र (Sentence Formulas)",
            formulas: {
                positive: {
                    name: "Positive Formula",
                    rule: "Subject + will be + V1+ing + Object/Complement",
                    example: "She will be working at 10 AM tomorrow.",
                    breakdown: {
                        subject: "She",
                        aux: "will be",
                        verb: "working (V1+ing)",
                        object: "at 10 AM tomorrow"
                    }
                },
                negative: {
                    name: "Negative Formula",
                    rule: "Subject + will not be (won't be) + V1+ing + Object",
                    example: "She will not be working at 10 AM tomorrow.",
                    breakdown: {
                        subject: "She",
                        aux: "will not be / won't be",
                        verb: "working (V1+ing)",
                        object: "at 10 AM tomorrow"
                    }
                },
                interrogative: {
                    name: "Interrogative Formula",
                    rule: "Will + Subject + be + V1+ing + Object?",
                    example: "Will she be working at 10 AM tomorrow?",
                    breakdown: {
                        aux1: "Will",
                        subject: "she",
                        aux2: "be",
                        verb: "working (V1+ing)",
                        object: "at 10 AM tomorrow?"
                    }
                },
                whQuestion: {
                    name: "WH Question Formula",
                    rule: "WH-word + will + Subject + be + V1+ing + Object?",
                    example: "What will she be doing at 10 AM?",
                    breakdown: {
                        wh: "What",
                        aux1: "will",
                        subject: "she",
                        aux2: "be",
                        verb: "doing (V1+ing)",
                        object: "at 10 AM?"
                    }
                }
            }
        },

        // 4. Subject + Verb Rules / कर्ता-क्रिया नियम
        subjectVerbRules: {
            title: "Subject + Verb Rules",
            titleHindi: "कर्ता + क्रिया नियम (Golden Rule: ALL SUBJECTS ➔ WILL BE + V1+ING)",
            goldenRule: "Golden Rule: Every subject (I, You, He, She, It, We, They, Singular, Plural) takes WILL BE + V1+ing in Future Continuous.",
            goldenRuleHindi: "स्वर्ण नियम: Future Continuous Tense में सभी कर्ताओं के साथ केवल WILL BE + V1+ing का प्रयोग होता है।",
            
            table: [
                { subject: "I", aux: "will be", verb: "V1+ing (studying)", example: "I will be studying." },
                { subject: "You", aux: "will be", verb: "V1+ing (working)", example: "You will be working." },
                { subject: "He", aux: "will be", verb: "V1+ing (reading)", example: "He will be reading." },
                { subject: "She", aux: "will be", verb: "V1+ing (sleeping)", example: "She will be sleeping." },
                { subject: "It", aux: "will be", verb: "V1+ing (raining)", example: "It will be raining." },
                { subject: "We", aux: "will be", verb: "V1+ing (waiting)", example: "We will be waiting." },
                { subject: "They", aux: "will be", verb: "V1+ing (traveling)", example: "They will be traveling." },
                { subject: "Singular Name (Rahul)", aux: "will be", verb: "V1+ing (driving)", example: "Rahul will be driving." },
                { subject: "Plural Noun (Students)", aux: "will be", verb: "V1+ing (testing)", example: "Students will be testing." }
            ],

            v1IngSpellingRules: {
                title: "V1+ing Verb Rules & Incorrect Patterns",
                titleHindi: "V1+ing क्रिया रूप नियम और अमान्य प्रयोग",
                intro: "After 'will be', the main verb MUST be in V1+ing form. Never use V1, V2, or V3.",
                introHindi: "'will be' के बाद मुख्य क्रिया में हमेशा '-ing' लगता है। V1, V2 या V3 न लगाएं।",
                spellingExamples: "Spelling Rules: work ➔ working | study ➔ studying | write ➔ writing | make ➔ making | run ➔ running | sit ➔ sitting | travel ➔ traveling | lie ➔ lying",
                correctExamples: "✅ Correct: I will be working | She will be studying | They will be traveling | He will be writing",
                incorrectExamples: "❌ Incorrect: I will be worked | She will be studied | They will be traveled | He will be wrote"
            }
        },

        // 5. Positive Sentences / सकारात्मक वाक्य (30 Items)
        positive: {
            title: "Positive Sentences",
            titleHindi: "सकारात्मक वाक्य (Subject + will be + V1+ing + Object)",
            formula: "Subject + will be + V1+ing + Object/Complement",
            explanation: "Expresses positive actions that will be in progress at a specific future time or period.",
            explanationHindi: "सकारात्मक वाक्यों में सभी कर्ताओं के साथ 'will be' और क्रिया का V1+ing रूप लगाएं।",
            
            sentences: {
                easy: [
                    { id: "pos-e1", english: "I will be studying at 8 PM tomorrow.", hindi: "मैं कल रात 8 बजे पढ़ रहा होऊँगा।", subject: "I", aux: "will be", verb: "studying", object: "at 8 PM tomorrow" },
                    { id: "pos-e2", english: "She will be working at 10 AM tomorrow.", hindi: "वह कल सुबह 10 बजे काम कर रही होगी।", subject: "She", aux: "will be", verb: "working", object: "at 10 AM tomorrow" },
                    { id: "pos-e3", english: "They will be traveling this time next week.", hindi: "वे अगले सप्ताह इसी समय यात्रा कर रहे होंगे।", subject: "They", aux: "will be", verb: "traveling", object: "this time next week" },
                    { id: "pos-e4", english: "We will be waiting for you at the station.", hindi: "हम स्टेशन पर आपका इंतज़ार कर रहे होंगे।", subject: "We", aux: "will be", verb: "waiting", object: "for you at the station" },
                    { id: "pos-e5", english: "He will be sleeping when you reach home.", hindi: "जब तुम घर पहुँचोगे तो वह सो रहा होगा।", subject: "He", aux: "will be", verb: "sleeping", object: "when you reach home" },
                    { id: "pos-e6", english: "Rahul will be driving to office at 9 AM.", hindi: "राहुल सुबह 9 बजे दफ़्तर जा रहा (ड्राइव कर रहा) होगा।", subject: "Rahul", aux: "will be", verb: "driving", object: "to office at 9 AM" },
                    { id: "pos-e7", english: "You will be feeling much better after rest.", hindi: "आराम के बाद आप बहुत बेहतर महसूस कर रहे होंगे।", subject: "You", aux: "will be", verb: "feeling", object: "much better after rest" },
                    { id: "pos-e8", english: "It will be raining heavily tomorrow afternoon.", hindi: "कल दोपहर तेज बारिश हो रही होगी।", subject: "It", aux: "will be", verb: "raining", object: "heavily tomorrow afternoon" },
                    { id: "pos-e9", english: "My mother will be cooking dinner at 7 PM.", hindi: "मेरी माँ शाम 7 बजे रात का खाना बना रही होंगी।", subject: "My mother", aux: "will be", verb: "cooking", object: "dinner at 7 PM" },
                    { id: "pos-e10", english: "The children will be playing in the garden.", hindi: "बच्चे बगीचे में खेल रहे होंगे।", subject: "The children", aux: "will be", verb: "playing", object: "in the garden" }
                ],
                medium: [
                    { id: "pos-m1", english: "The doctor will be examining patients all morning.", hindi: "डॉक्टर पूरी सुबह मरीजों की जांच कर रहे होंगे।", subject: "The doctor", aux: "will be", verb: "examining", object: "patients all morning" },
                    { id: "pos-m2", english: "She will be preparing for her final exams tonight.", hindi: "वह आज रात अपनी अंतिम परीक्षाओं की तैयारी कर रही होगी।", subject: "She", aux: "will be", verb: "preparing", object: "for her final exams tonight" },
                    { id: "pos-m3", english: "The team will be presenting the project at 11 AM.", hindi: "टीम सुबह 11 बजे प्रोजेक्ट प्रस्तुत कर रही होगी।", subject: "The team", aux: "will be", verb: "presenting", object: "the project at 11 AM" },
                    { id: "pos-m4", english: "I will be attending an online webinar tomorrow evening.", hindi: "मैं कल शाम एक ऑनलाइन वेबिनार में भाग ले रहा होऊँगा।", subject: "I", aux: "will be", verb: "attending", object: "an online webinar tomorrow evening" },
                    { id: "pos-m5", english: "They will be celebrating their anniversary this weekend.", hindi: "वे इस सप्ताहांत अपनी वर्षगांठ मना रहे होंगे।", subject: "They", aux: "will be", verb: "celebrating", object: "their anniversary this weekend" },
                    { id: "pos-m6", english: "The manager will be reviewing applications tomorrow.", hindi: "मैनेजर कल आवेदनों की समीक्षा कर रहा होगा।", subject: "The manager", aux: "will be", verb: "reviewing", object: "applications tomorrow" },
                    { id: "pos-m7", english: "We will be flying over the Himalayas at noon.", hindi: "हम दोपहर को हिमालय के ऊपर उड़ान भर रहे होंगे।", subject: "We", aux: "will be", verb: "flying", object: "over the Himalayas at noon" },
                    { id: "pos-m8", english: "He will be repairing the electrical system all day.", hindi: "वह पूरा दिन बिजली के सिस्टम की मरम्मत कर रहा होगा।", subject: "He", aux: "will be", verb: "repairing", object: "the electrical system all day" },
                    { id: "pos-m9", english: "The passengers will be boarding the flight at gate three.", hindi: "यात्री गेट नंबर तीन पर विमान में सवार हो रहे होंगे।", subject: "The passengers", aux: "will be", verb: "boarding", object: "the flight at gate three" },
                    { id: "pos-m10", english: "She will be giving a speech at the conference.", hindi: "वह सम्मेलन में भाषण दे रही होगी।", subject: "She", aux: "will be", verb: "giving", object: "a speech at the conference" }
                ],
                hard: [
                    { id: "pos-h1", english: "The software engineers will be deploying the cloud update tonight.", hindi: "सॉफ्टवेयर इंजीनियर आज रात क्लाउड अपडेट तैनात कर रहे होंगे।", subject: "The software engineers", aux: "will be", verb: "deploying", object: "cloud update tonight" },
                    { id: "pos-h2", english: "The board of directors will be discussing annual budget tomorrow.", hindi: "निदेशक मंडल कल वार्षिक बजट पर चर्चा कर रहा होगा।", subject: "The board of directors", aux: "will be", verb: "discussing", object: "annual budget tomorrow" },
                    { id: "pos-h3", english: "Scientists will be conducting clinical trials throughout next month.", hindi: "वैज्ञानिक अगले पूरे महीने नैदानिक परीक्षण कर रहे होंगे।", subject: "Scientists", aux: "will be", verb: "conducting", object: "clinical trials next month" },
                    { id: "pos-h4", english: "The construction workers will be building the highway all year.", hindi: "निर्माण मजदूर साल भर हाईवे का निर्माण कर रहे होंगे।", subject: "The construction workers", aux: "will be", verb: "building", object: "the highway all year" },
                    { id: "pos-h5", english: "Financial auditors will be inspecting bank balance sheets on Monday.", hindi: "वित्तीय लेखा परीक्षक सोमवार को बैंक बैलेंस शीट की जांच कर रहे होंगे।", subject: "Financial auditors", aux: "will be", verb: "inspecting", object: "bank balance sheets on Monday" },
                    { id: "pos-h6", english: "Rescue teams will be evacuating residents during the storm.", hindi: "बचाव दल तूफान के दौरान निवासियों को सुरक्षित बाहर निकाल रहे होंगे।", subject: "Rescue teams", aux: "will be", verb: "evacuating", object: "residents during storm" },
                    { id: "pos-h7", english: "She will be writing her doctoral thesis during winter vacation.", hindi: "वह सर्दियों की छुट्टियों के दौरान अपना डॉक्टरेट शोधप्रबंध लिख रही होगी।", subject: "She", aux: "will be", verb: "writing", object: "doctoral thesis during winter vacation" },
                    { id: "pos-h8", english: "The supreme court bench will be hearing constitutional matters at 10 AM.", hindi: "सुप्रीम कोर्ट की पीठ सुबह 10 बजे संवैधानिक मामलों की सुनवाई कर रही होगी।", subject: "The supreme court bench", aux: "will be", verb: "hearing", object: "constitutional matters at 10 AM" },
                    { id: "pos-h9", english: "Research analysts will be evaluating market trends during Q3.", hindi: "अनुसंधान विश्लेषक तीसरी तिमाही के दौरान बाजार के रुझानों का मूल्यांकन कर रहे होंगे।", subject: "Research analysts", aux: "will be", verb: "evaluating", object: "market trends during Q3" },
                    { id: "pos-h10", english: "The government will be implementing new solar policies next year.", hindi: "सरकार अगले साल नई सौर नीतियों को लागू कर रही होगी।", subject: "The government", aux: "will be", verb: "implementing", object: "new solar policies next year" }
                ]
            }
        },

        // 6. Negative Sentences / नकारात्मक वाक्य (30 Items)
        negative: {
            title: "Negative Sentences",
            titleHindi: "नकारात्मक वाक्य (Subject + will not be / won't be + V1+ing)",
            formula: "Subject + will not be (won't be) + V1+ing + Object",
            explanation: "Use 'will not be' or contraction 'won't be' followed by V1+ing to state that an action will not be in progress.",
            explanationHindi: "नकारात्मक वाक्यों में 'will not be' या संक्षिप्त रूप 'won't be' लगाकर V1+ing का प्रयोग करें।",
            
            sentences: {
                easy: [
                    { id: "neg-e1", english: "I will not be working tomorrow morning.", hindi: "मैं कल सुबह काम नहीं कर रहा होऊँगा।", subject: "I", aux: "will not be", verb: "working", object: "tomorrow morning" },
                    { id: "neg-e2", english: "She won't be attending the meeting at 10 AM.", hindi: "वह सुबह 10 बजे मीटिंग में शामिल नहीं हो रही होगी।", subject: "She", aux: "won't be", verb: "attending", object: "the meeting at 10 AM" },
                    { id: "neg-e3", english: "They will not be staying here next week.", hindi: "वे अगले सप्ताह यहाँ नहीं रुक रहे होंगे।", subject: "They", aux: "will not be", verb: "staying", object: "here next week" },
                    { id: "neg-e4", english: "We won't be using the computer tonight.", hindi: "हम आज रात कंप्यूटर का उपयोग नहीं कर रहे होंगे।", subject: "We", aux: "won't be", verb: "using", object: "the computer tonight" },
                    { id: "neg-e5", english: "He will not be sleeping at 8 PM.", hindi: "वह रात 8 बजे सो नहीं रहा होगा।", subject: "He", aux: "will not be", verb: "sleeping", object: "at 8 PM" },
                    { id: "neg-e6", english: "Rahul won't be driving in heavy rain.", hindi: "राहुल भारी बारिश में गाड़ी नहीं चला रहा होगा।", subject: "Rahul", aux: "won't be", verb: "driving", object: "in heavy rain" },
                    { id: "neg-e7", english: "You will not be waiting for long.", hindi: "आप ज्यादा देर तक इंतज़ार नहीं कर रहे होंगे।", subject: "You", aux: "will not be", verb: "waiting", object: "for long" },
                    { id: "neg-e8", english: "It won't be raining tomorrow.", hindi: "कल बारिश नहीं हो रही होगी।", subject: "It", aux: "won't be", verb: "raining", object: "tomorrow" },
                    { id: "neg-e9", english: "She will not be cooking at midnight.", hindi: "वह आधी रात को खाना नहीं बना रही होगी।", subject: "She", aux: "will not be", verb: "cooking", object: "at midnight" },
                    { id: "neg-e10", english: "They won't be traveling during festival season.", hindi: "वे त्योहार के मौसम में यात्रा नहीं कर रहे होंगे।", subject: "They", aux: "won't be", verb: "traveling", object: "during festival season" }
                ],
                medium: [
                    { id: "neg-m1", english: "The doctor will not be examining patients on Sunday.", hindi: "डॉक्टर रविवार को मरीजों की जांच नहीं कर रहे होंगे।", subject: "The doctor", aux: "will not be", verb: "examining", object: "patients on Sunday" },
                    { id: "neg-m2", english: "She won't be taking calls during presentation.", hindi: "वह प्रेजेंटेशन के दौरान फोन कॉल नहीं ले रही होगी।", subject: "She", aux: "won't be", verb: "taking", object: "calls during presentation" },
                    { id: "neg-m3", english: "The team will not be working on holidays.", hindi: "टीम छुट्टियों के दौरान काम नहीं कर रही होगी।", subject: "The team", aux: "will not be", verb: "working", object: "on holidays" },
                    { id: "neg-m4", english: "We won't be offering discounts next month.", hindi: "हम अगले महीने छूट नहीं दे रहे होंगे।", subject: "We", aux: "won't be", verb: "offering", object: "discounts next month" },
                    { id: "neg-m5", english: "He will not be using official car for private trips.", hindi: "वह निजी यात्राओं के लिए सरकारी कार का उपयोग नहीं कर रहा होगा।", subject: "He", aux: "will not be", verb: "using", object: "official car for private trips" },
                    { id: "neg-m6", english: "The teacher won't be conducting classes tomorrow.", hindi: "शिक्षक कल कक्षाएं नहीं ले रहे होंगे।", subject: "The teacher", aux: "won't be", verb: "conducting", object: "classes tomorrow" },
                    { id: "neg-m7", english: "They will not be accepting cash payments after noon.", hindi: "वे दोपहर के बाद नकद भुगतान स्वीकार नहीं कर रहे होंगे।", subject: "They", aux: "will not be", verb: "accepting", object: "cash payments after noon" },
                    { id: "neg-m8", english: "I won't be disturbing you while you study.", hindi: "जब आप पढ़ाई करेंगे तब मैं आपको परेशान नहीं कर रहा होऊँगा।", subject: "I", aux: "won't be", verb: "disturbing", object: "you while you study" },
                    { id: "neg-m9", english: "The manager will not be interviewing candidates today.", hindi: "मैनेजर आज उम्मीदवारों का साक्षात्कार नहीं ले रहा होगा।", subject: "The manager", aux: "will not be", verb: "interviewing", object: "candidates today" },
                    { id: "neg-m10", english: "She won't be living in London next year.", hindi: "वह अगले साल लंदन में नहीं रह रही होगी।", subject: "She", aux: "won't be", verb: "living", object: "in London next year" }
                ],
                hard: [
                    { id: "neg-h1", english: "Engineers will not be running server maintenance during peak hours.", hindi: "इंजीनियर पीक ऑवर्स के दौरान सर्वर मेंटेनेंस नहीं चला रहे होंगे।", subject: "Engineers", aux: "will not be", verb: "running", object: "server maintenance during peak hours" },
                    { id: "neg-h2", english: "The committee won't be reviewing unverified documents.", hindi: "समिति असत्यापित दस्तावेजों की समीक्षा नहीं कर रही होगी।", subject: "The committee", aux: "won't be", verb: "reviewing", object: "unverified documents" },
                    { id: "neg-h3", english: "Scientists will not be carrying out experiments without safety gear.", hindi: "वैज्ञानिक सुरक्षा उपकरणों के बिना प्रयोग नहीं कर रहे होंगे।", subject: "Scientists", aux: "will not be", verb: "carrying out", object: "experiments without safety gear" },
                    { id: "neg-h4", english: "The company won't be hiring new executives next quarter.", hindi: "कंपनी अगली तिमाही में नए अधिकारियों की भर्ती नहीं कर रही होगी।", subject: "The company", aux: "won't be", verb: "hiring", object: "new executives next quarter" },
                    { id: "neg-h5", english: "Auditors will not be signing reports without complete audit trail.", hindi: "लेखा परीक्षक पूर्ण ऑडिट ट्रेल के बिना रिपोर्ट पर हस्ताक्षर नहीं कर रहे होंगे।", subject: "Auditors", aux: "will not be", verb: "signing", object: "reports without complete audit trail" },
                    { id: "neg-h6", english: "Airlines won't be operating flights during thunderstorm warning.", hindi: "एयरलाइंस तूफान की चेतावनी के दौरान उड़ानें संचालित नहीं कर रही होंगी।", subject: "Airlines", aux: "won't be", verb: "operating", object: "flights during thunderstorm warning" },
                    { id: "neg-h7", english: "She will not be presenting outdated research data.", hindi: "वह पुराना शोध डेटा प्रस्तुत नहीं कर रही होगी।", subject: "She", aux: "will not be", verb: "presenting", object: "outdated research data" },
                    { id: "neg-h8", english: "The tribunal won't be issuing final orders before testimony completion.", hindi: "गवाही पूरी होने से पहले न्यायाधिकरण अंतिम आदेश जारी नहीं कर रहा होगा।", subject: "The tribunal", aux: "won't be", verb: "issuing", object: "final orders before testimony completion" },
                    { id: "neg-h9", english: "Research labs will not be wasting resources on unviable projects.", hindi: "शोध प्रयोगशालाएं अव्यवहारिक परियोजनाओं पर संसाधन बर्बाद नहीं कर रही होंगी।", subject: "Research labs", aux: "will not be", verb: "wasting", object: "resources on unviable projects" },
                    { id: "neg-h10", english: "The administration won't be enforcing curfews during peace talks.", hindi: "प्रशासन शांति वार्ता के दौरान कर्फ्यू लागू नहीं कर रहा होगा।", subject: "The administration", aux: "won't be", verb: "enforcing", object: "curfews during peace talks" }
                ]
            }
        },

        // 7. Interrogative Sentences / प्रश्नवाचक वाक्य (30 Items)
        interrogative: {
            title: "Interrogative Sentences",
            titleHindi: "प्रश्नवाचक वाक्य (Will + Subject + be + V1+ing...?)",
            formula: "Will + Subject + be + V1+ing + Object?",
            explanation: "Form Yes/No questions by placing 'Will' before the Subject, followed by 'be' and V1+ing.",
            explanationHindi: "प्रश्नवाचक वाक्यों में 'Will' को कर्ता से पहले लाएं, फिर 'be' और V1+ing का प्रयोग करें।",
            
            sentences: {
                easy: [
                    { id: "int-e1", english: "Will you be working tomorrow?", hindi: "क्या आप कल काम कर रहे होंगे?", subject: "you", aux: "Will...be", verb: "working", object: "tomorrow" },
                    { id: "int-e2", english: "Will she be studying at 8 PM?", hindi: "क्या वह रात 8 बजे पढ़ रही होगी?", subject: "she", aux: "Will...be", verb: "studying", object: "at 8 PM" },
                    { id: "int-e3", english: "Will they be traveling next week?", hindi: "क्या वे अगले सप्ताह यात्रा कर रहे होंगे?", subject: "they", aux: "Will...be", verb: "traveling", object: "next week" },
                    { id: "int-e4", english: "Will we be waiting for long?", hindi: "क्या हम लंबे समय तक इंतज़ार कर रहे होंगे?", subject: "we", aux: "Will...be", verb: "waiting", object: "for long" },
                    { id: "int-e5", english: "Will he be sleeping at midnight?", hindi: "क्या वह आधी रात को सो रहा होगा?", subject: "he", aux: "Will...be", verb: "sleeping", object: "at midnight" },
                    { id: "int-e6", english: "Will Rahul be driving to Delhi?", hindi: "क्या राहुल दिल्ली के लिए गाड़ी चला रहा होगा?", subject: "Rahul", aux: "Will...be", verb: "driving", object: "to Delhi" },
                    { id: "int-e7", english: "Will it be raining tomorrow afternoon?", hindi: "क्या कल दोपहर बारिश हो रही होगी?", subject: "it", aux: "Will...be", verb: "raining", object: "tomorrow afternoon" },
                    { id: "int-e8", english: "Will you be using the car tonight?", hindi: "क्या आप आज रात कार का इस्तेमाल कर रहे होंगे?", subject: "you", aux: "Will...be", verb: "using", object: "the car tonight" },
                    { id: "int-e9", english: "Will she be cooking dinner at 7 PM?", hindi: "क्या वह शाम 7 बजे खाना बना रही होगी?", subject: "she", aux: "Will...be", verb: "cooking", object: "dinner at 7 PM" },
                    { id: "int-e10", english: "Will children be playing in garden?", hindi: "क्या बच्चे बगीचे में खेल रहे होंगे?", subject: "children", aux: "Will...be", verb: "playing", object: "in garden" }
                ],
                medium: [
                    { id: "int-m1", english: "Will the doctor be examining patients at 9 AM?", hindi: "क्या डॉक्टर सुबह 9 बजे मरीजों की जांच कर रहे होंगे?", subject: "the doctor", aux: "Will...be", verb: "examining", object: "patients at 9 AM" },
                    { id: "int-m2", english: "Will she be preparing for exams all night?", hindi: "क्या वह पूरी रात परीक्षा की तैयारी कर रही होगी?", subject: "she", aux: "Will...be", verb: "preparing", object: "for exams all night" },
                    { id: "int-m3", english: "Will the team be meeting the manager tomorrow?", hindi: "क्या टीम कल मैनेजर से मिल रही होगी?", subject: "the team", aux: "Will...be", verb: "meeting", object: "the manager tomorrow" },
                    { id: "int-m4", english: "Will you be attending the annual conference?", hindi: "क्या आप वार्षिक सम्मेलन में भाग ले रहे होंगे?", subject: "you", aux: "Will...be", verb: "attending", object: "the annual conference" },
                    { id: "int-m5", english: "Will they be staying at hotel during trip?", hindi: "क्या वे यात्रा के दौरान होटल में रुक रहे होंगे?", subject: "they", aux: "Will...be", verb: "staying", object: "at hotel during trip" },
                    { id: "int-m6", english: "Will the manager be reviewing reports today?", hindi: "क्या मैनेजर आज रिपोर्टों की समीक्षा कर रहा होगा?", subject: "the manager", aux: "Will...be", verb: "reviewing", object: "reports today" },
                    { id: "int-m7", english: "Will we be crossing the border by evening?", hindi: "क्या हम शाम तक सीमा पार कर रहे होंगे?", subject: "we", aux: "Will...be", verb: "crossing", object: "the border by evening" },
                    { id: "int-m8", english: "Will he be repairing computer system tomorrow?", hindi: "क्या वह कल कंप्यूटर सिस्टम की मरम्मत कर रहा होगा?", subject: "he", aux: "Will...be", verb: "repairing", object: "computer system tomorrow" },
                    { id: "int-m9", english: "Will passengers be boarding flight now?", hindi: "क्या यात्री अब विमान में सवार हो रहे होंगे?", subject: "passengers", aux: "Will...be", verb: "boarding", object: "flight now" },
                    { id: "int-m10", english: "Will she be speaking at international seminar?", hindi: "क्या वह अंतर्राष्ट्रीय संगोष्ठी में बोल रही होगी?", subject: "she", aux: "Will...be", verb: "speaking", object: "at international seminar" }
                ],
                hard: [
                    { id: "int-h1", english: "Will software engineers be testing new security patch tonight?", hindi: "क्या सॉफ्टवेयर इंजीनियर आज रात नए सुरक्षा पैच की टेस्टिंग कर रहे होंगे?", subject: "software engineers", aux: "Will...be", verb: "testing", object: "security patch tonight" },
                    { id: "int-h2", english: "Will board of directors be voting on budget tomorrow?", hindi: "क्या निदेशक मंडल कल बजट पर मतदान कर रहा होगा?", subject: "board of directors", aux: "Will...be", verb: "voting", object: "on budget tomorrow" },
                    { id: "int-h3", english: "Will scientists be monitoring space signals continuously?", hindi: "क्या वैज्ञानिक लगातार अंतरिक्ष के संकेतों की निगरानी कर रहे होंगे?", subject: "scientists", aux: "Will...be", verb: "monitoring", object: "space signals continuously" },
                    { id: "int-h4", english: "Will municipality be constructing new bridge this winter?", hindi: "क्या नगरपालिका इस सर्दी में नए पुल का निर्माण कर रही होगी?", subject: "municipality", aux: "Will...be", verb: "constructing", object: "new bridge this winter" },
                    { id: "int-h5", english: "Will auditors be verifying accounting records next week?", hindi: "क्या लेखा परीक्षक अगले सप्ताह लेखा अभिलेखों का सत्यापन कर रहे होंगे?", subject: "auditors", aux: "Will...be", verb: "verifying", object: "accounting records next week" },
                    { id: "int-h6", english: "Will authorities be evacuating coastal zones before cyclone hits?", hindi: "क्या चक्रवात आने से पहले अधिकारी तटीय क्षेत्रों को खाली करा रहे होंगे?", subject: "authorities", aux: "Will...be", verb: "evacuating", object: "coastal zones before cyclone" },
                    { id: "int-h7", english: "Will she be defending her dissertation thesis on Friday?", hindi: "क्या वह शुक्रवार को अपने शोधप्रबंध का बचाव (प्रस्तुतीकरण) कर रही होगी?", subject: "she", aux: "Will...be", verb: "defending", object: "dissertation thesis on Friday" },
                    { id: "int-h8", english: "Will high court bench be hearing public interest litigation tomorrow?", hindi: "क्या उच्च न्यायालय की पीठ कल जनहित याचिका की सुनवाई कर रही होगी?", subject: "high court bench", aux: "Will...be", verb: "hearing", object: "PIL litigation tomorrow" },
                    { id: "int-h9", english: "Will research team be analyzing trial outcomes next month?", hindi: "क्या शोध टीम अगले महीने परीक्षण के परिणामों का विश्लेषण कर रही होगी?", subject: "research team", aux: "Will...be", verb: "analyzing", object: "trial outcomes next month" },
                    { id: "int-h10", english: "Will government be introducing new trade policy in parliament?", hindi: "क्या सरकार संसद में नई व्यापार नीति पेश कर रही होगी?", subject: "government", aux: "Will...be", verb: "introducing", object: "new trade policy in parliament" }
                ]
            }
        },

        // 8. WH Questions / WH प्रश्न (30 Items)
        whQuestions: {
            title: "WH Questions",
            titleHindi: "WH प्रश्न (WH + will + Subject + be + V1+ing...?)",
            formula: "WH-word + will + Subject + be + V1+ing + Object?",
            explanation: "Place the WH-word first, followed by 'will', Subject, 'be', and V1+ing.",
            explanationHindi: "WH प्रश्नों में सबसे पहले WH-शब्द, फिर 'will', कर्ता, 'be' और V1+ing लगाएं।",
            
            sentences: {
                easy: [
                    { id: "wh-e1", english: "What will you be doing at 8 PM?", hindi: "आप रात 8 बजे क्या कर रहे होंगे?", subject: "you", aux: "will...be", verb: "doing", object: "at 8 PM", whWord: "What" },
                    { id: "wh-e2", english: "Where will she be staying in Delhi?", hindi: "वह दिल्ली में कहाँ रुक रही होगी?", subject: "she", aux: "will...be", verb: "staying", object: "in Delhi", whWord: "Where" },
                    { id: "wh-e3", english: "When will they be arriving tomorrow?", hindi: "वे कल कब पहुँच रहे होंगे?", subject: "they", aux: "will...be", verb: "arriving", object: "tomorrow", whWord: "When" },
                    { id: "wh-e4", english: "Why will he be working late tonight?", hindi: "वह आज रात देर तक काम क्यों कर रहा होगा?", subject: "he", aux: "will...be", verb: "working", object: "late tonight", whWord: "Why" },
                    { id: "wh-e5", english: "Who will be attending the meeting tomorrow?", hindi: "कल बैठक में कौन शामिल हो रहा होगा?", subject: "Who", aux: "will...be", verb: "attending", object: "meeting tomorrow", whWord: "Who" },
                    { id: "wh-e6", english: "Which movie will they be watching tonight?", hindi: "वे आज रात कौन सी फिल्म देख रहे होंगे?", subject: "they", aux: "will...be", verb: "watching", object: "tonight", whWord: "Which movie" },
                    { id: "wh-e7", english: "How will she be traveling to London?", hindi: "वह लंदन की यात्रा कैसे कर रही होगी?", subject: "she", aux: "will...be", verb: "traveling", object: "to London", whWord: "How" },
                    { id: "wh-e8", english: "Whose car will you be driving tomorrow?", hindi: "आप कल किसकी कार चला रहे होंगे?", subject: "you", aux: "will...be", verb: "driving", object: "tomorrow", whWord: "Whose car" },
                    { id: "wh-e9", english: "How long will you be staying in Mumbai?", hindi: "आप मुंबई में कितने समय तक रुक रहे होंगे?", subject: "you", aux: "will...be", verb: "staying", object: "in Mumbai", whWord: "How long" },
                    { id: "wh-e10", english: "Where will we be parking our vehicle?", hindi: "हम अपना वाहन कहाँ खड़ा कर रहे होंगे?", subject: "we", aux: "will...be", verb: "parking", object: "our vehicle", whWord: "Where" }
                ],
                medium: [
                    { id: "wh-m1", english: "What will doctor be recommending for recovery?", hindi: "डॉक्टर रिकवरी के लिए क्या सुझाव दे रहे होंगे?", subject: "doctor", aux: "will...be", verb: "recommending", object: "for recovery", whWord: "What" },
                    { id: "wh-m2", english: "Why will she be leaving company next month?", hindi: "वह अगले महीने कंपनी क्यों छोड़ रही होगी?", subject: "she", aux: "will...be", verb: "leaving", object: "company next month", whWord: "Why" },
                    { id: "wh-m3", english: "How will the team be handling customer queries?", hindi: "टीम ग्राहकों के प्रश्नों को कैसे संभाल रही होगी?", subject: "the team", aux: "will...be", verb: "handling", object: "customer queries", whWord: "How" },
                    { id: "wh-m4", english: "Where will they be setting up solar plant?", hindi: "वे सौर संयंत्र कहाँ स्थापित कर रहे होंगे?", subject: "they", aux: "will...be", verb: "setting up", object: "solar plant", whWord: "Where" },
                    { id: "wh-m5", english: "When will manager be evaluating annual performance?", hindi: "मैनेजर वार्षिक प्रदर्शन का मूल्यांकन कब कर रहा होगा?", subject: "manager", aux: "will...be", verb: "evaluating", object: "annual performance", whWord: "When" },
                    { id: "wh-m6", english: "Which candidate will voters be supporting in election?", hindi: "मतदाता चुनाव में किस उम्मीदवार का समर्थन कर रहे होंगे?", subject: "voters", aux: "will...be", verb: "supporting", object: "in election", whWord: "Which candidate" },
                    { id: "wh-m7", english: "How much money will he be investing in stocks?", hindi: "वह शेयरों में कितना पैसा निवेश कर रहा होगा?", subject: "he", aux: "will...be", verb: "investing", object: "in stocks", whWord: "How much money" },
                    { id: "wh-m8", english: "Why will students be protesting outside university?", hindi: "छात्र विश्वविद्यालय के बाहर विरोध प्रदर्शन क्यों कर रहे होंगे?", subject: "students", aux: "will...be", verb: "protesting", object: "outside university", whWord: "Why" },
                    { id: "wh-m9", english: "Who will be hosting the annual tech summit?", hindi: "वार्षिक टेक शिखर सम्मेलन की मेजबानी कौन कर रहा होगा?", subject: "Who", aux: "will...be", verb: "hosting", object: "annual tech summit", whWord: "Who" },
                    { id: "wh-m10", english: "Where will she be storing secret files?", hindi: "वह गुप्त फाइलें कहाँ जमा कर रही होगी?", subject: "she", aux: "will...be", verb: "storing", object: "secret files", whWord: "Where" }
                ],
                hard: [
                    { id: "wh-h1", english: "What security features will engineers be implementing?", hindi: "इंजीनियर क्या सुरक्षा सुविधाएं लागू कर रहे होंगे?", subject: "engineers", aux: "will...be", verb: "implementing", object: "security features", whWord: "What security features" },
                    { id: "wh-h2", english: "Why will board of directors be delaying project launch?", hindi: "निदेशक मंडल प्रोजेक्ट लॉन्च में देरी क्यों कर रहा होगा?", subject: "board of directors", aux: "will...be", verb: "delaying", object: "project launch", whWord: "Why" },
                    { id: "wh-h3", english: "How will scientists be measuring quantum radiation?", hindi: "वैज्ञानिक क्वांटम विकिरण को कैसे माप रहे होंगे?", subject: "scientists", aux: "will...be", verb: "measuring", object: "quantum radiation", whWord: "How" },
                    { id: "wh-h4", english: "Where will authorities be constructing relief centers?", hindi: "अधिकारी राहत केंद्र कहाँ बना रहे होंगे?", subject: "authorities", aux: "will...be", verb: "constructing", object: "relief centers", whWord: "Where" },
                    { id: "wh-h5", english: "When will auditors be submitting tax compliance report?", hindi: "लेखा परीक्षक टैक्स अनुपालन रिपोर्ट कब जमा कर रहे होंगे?", subject: "auditors", aux: "will...be", verb: "submitting", object: "compliance report", whWord: "When" },
                    { id: "wh-h6", english: "Which economic policies will government be revising?", hindi: "सरकार किन आर्थिक नीतियों में संशोधन कर रही होगी?", subject: "government", aux: "will...be", verb: "revising", object: "economic policies", whWord: "Which economic policies" },
                    { id: "wh-h7", english: "How many delegates will be attending global climate forum?", hindi: "वैश्विक जलवायु मंच में कितने प्रतिनिधि भाग ले रहे होंगे?", subject: "delegates", aux: "will...be", verb: "attending", object: "climate forum", whWord: "How many delegates" },
                    { id: "wh-h8", english: "Why will judicial bench be reviewing previous judgment?", hindi: "न्यायिक पीठ पिछले फैसले की समीक्षा क्यों कर रही होगी?", subject: "judicial bench", aux: "will...be", verb: "reviewing", object: "previous judgment", whWord: "Why" },
                    { id: "wh-h9", english: "Whose research proposal will committee be recommending?", hindi: "समिति किसके शोध प्रस्ताव की सिफारिश कर रही होगी?", subject: "committee", aux: "will...be", verb: "recommending", object: "research proposal", whWord: "Whose research proposal" },
                    { id: "wh-h10", english: "Where will research team be conducting field trials?", hindi: "शोध टीम मैदानी परीक्षण कहाँ आयोजित कर रही होगी?", subject: "research team", aux: "will...be", verb: "conducting", object: "field trials", whWord: "Where" }
                ]
            }
        },

        // 9. Common Mistakes & Corrections / सामान्य गलतियाँ (At least 15 Items)
        commonMistakes: {
            title: "Common Mistakes",
            titleHindi: "सामान्य गलतियाँ और सुधार (Common Mistakes & Corrections)",
            intro: "Avoid these 15 common errors when forming Future Continuous Tense sentences.",
            introHindi: "Future Continuous Tense का प्रयोग करते समय इन 15 सामान्य गलतियों से बचें।",
            mistakes: [
                {
                    wrong: "I will working at 8 PM.",
                    correct: "I will be working at 8 PM.",
                    why: "Future Continuous requires 'will be' before V1+ing. Missing 'be' makes it ungrammatical.",
                    whyHindi: "will के साथ 'be' लगाना अनिवार्य है, बिना 'be' के वाक्य गलत है।"
                },
                {
                    wrong: "She will be worked tomorrow.",
                    correct: "She will be working tomorrow.",
                    why: "After 'will be', the main verb must be in V1+ing (working), not V2 or V3 (worked).",
                    whyHindi: "'will be' के बाद हमेशा V1+ing आता है, V2 या V3 नहीं।"
                },
                {
                    wrong: "They will be work at 10 AM.",
                    correct: "They will be working at 10 AM.",
                    why: "Do not use bare V1 (work) after 'will be'. Add '-ing' for continuous action.",
                    whyHindi: "'will be' के बाद केवल V1 (work) न लगाएं, '-ing' (working) जोड़ें।"
                },
                {
                    wrong: "She is will be working tomorrow.",
                    correct: "She will be working tomorrow.",
                    why: "Do not combine present auxiliary 'is' with future auxiliary 'will be'.",
                    whyHindi: "'is' और 'will be' दोनों सहायक क्रियाओं को एक साथ न मिलाएं।"
                },
                {
                    wrong: "I will is working tomorrow.",
                    correct: "I will be working tomorrow.",
                    why: "Always use base auxiliary 'be' after 'will', never 'is', 'am', or 'are'.",
                    whyHindi: "will के बाद हमेशा 'be' आता है, 'is/am/are' नहीं।"
                },
                {
                    wrong: "They was will be traveling.",
                    correct: "They will be traveling.",
                    why: "Do not use past tense 'was/were' when forming Future Continuous.",
                    whyHindi: "भविष्यत् काल में भूतकाल की क्रिया 'was/were' न लगाएं।"
                },
                {
                    wrong: "He will be not working tomorrow.",
                    correct: "He will not be working tomorrow. / He won't be working tomorrow.",
                    why: "In negative sentences, place 'not' between 'will' and 'be' (will not be).",
                    whyHindi: "नकारात्मक वाक्य में 'not' हमेशा 'will' और 'be' के बीच में आता है।"
                },
                {
                    wrong: "Will be she working at 10 AM?",
                    correct: "Will she be working at 10 AM?",
                    why: "In interrogative sentences, place the Subject ('she') between 'Will' and 'be'.",
                    whyHindi: "प्रश्नवाचक वाक्य में कर्ता (she) 'Will' और 'be' के बीच आता है।"
                },
                {
                    wrong: "She won't work tomorrow at 8 PM.",
                    correct: "She won't be working tomorrow at 8 PM.",
                    why: "To show an action in progress at a specific time (8 PM), use 'won't be working' instead of Simple Future.",
                    whyHindi: "विशेष समय (8 PM) पर जारी कार्य दर्शाने के लिए 'won't be working' का प्रयोग करें।"
                },
                {
                    wrong: "Why she will be working late?",
                    correct: "Why will she be working late?",
                    why: "In WH questions, auxiliary 'will' must come BEFORE the subject ('she').",
                    whyHindi: "WH प्रश्नों में 'will' हमेशा कर्ता (she) से पहले आता है।"
                },
                {
                    wrong: "I will be go to office tomorrow.",
                    correct: "I will be going to office tomorrow.",
                    why: "Use V1+ing (going) after 'will be', not plain V1 (go).",
                    whyHindi: "'will be' के बाद 'go' नहीं, 'going' आएगा।"
                },
                {
                    wrong: "When you will arrive, I will be working.",
                    correct: "When you arrive, I will be working.",
                    why: "In time clauses starting with 'when/if', use Simple Present (arrive), not future (will arrive).",
                    whyHindi: "Time clause (When/If से शुरू) में 'will arrive' की जगह Simple Present 'arrive' आता है।"
                },
                {
                    wrong: "She will be have studied at 8 PM.",
                    correct: "She will be studying at 8 PM.",
                    why: "Do not mix Future Continuous ('will be studying') with Future Perfect ('will have studied') formulas.",
                    whyHindi: "Future Continuous और Future Perfect के सूत्रों को आपस में न मिलाएं।"
                },
                {
                    wrong: "I will be writing yesterday.",
                    correct: "I will be writing tomorrow.",
                    why: "Future Continuous cannot be used with past time markers like 'yesterday'.",
                    whyHindi: "Future Continuous में अतीत के समय सूचक (yesterday) का प्रयोग न करें।"
                },
                {
                    wrong: "Will you working tomorrow?",
                    correct: "Will you be working tomorrow?",
                    why: "Do not omit 'be' in interrogative sentences. Formula is 'Will + Subject + be + V1+ing'.",
                    whyHindi: "प्रश्नवाचक वाक्य में 'be' न छोड़ें। सही रूप 'Will you be working...?' है।"
                }
            ]
        },

        // 10. Summary & Revision / सारांश एवं दोहराव (15 Revision Examples)
        summary: {
            title: "Summary & Revision",
            titleHindi: "पाठ सारांश एवं दोहराव (Summary & Memory Anchors)",
            keyPoints: [
                "1. Core Concept ➔ Describes an action that will be in progress at a specific future time or period.",
                "2. Golden Rule ➔ ALL SUBJECTS take WILL BE + V1+ING.",
                "3. Main Verb Rule ➔ Main verb MUST stay in V1+ing form. Never use V1, V2, or V3 after 'will be'.",
                "4. Negative Form ➔ Subject + will not be (won't be) + V1+ing.",
                "5. Interrogative Form ➔ Will + Subject + be + V1+ing...?",
                "6. 5 Core Uses ➔ Action in progress at future time, future period, background action, polite query, expected scheduled activity.",
                "7. Key Signals ➔ at 8 PM tomorrow, this time tomorrow, this time next week, when you arrive."
            ],

            formulaSummary: {
                positive: "Subject + will be + V1+ing + Object",
                negative: "Subject + will not be (won't be) + V1+ing + Object",
                interrogative: "Will + Subject + be + V1+ing + Object?",
                whQuestion: "WH-word + will + Subject + be + V1+ing + Object?"
            },

            revisionExamples: {
                easy: [
                    { id: "sum-e1", english: "I will be studying at 8 PM tomorrow.", hindi: "मैं कल रात 8 बजे पढ़ रहा होऊँगा।", note: "Action in progress at specific future time" },
                    { id: "sum-e2", english: "She won't be working tomorrow morning.", hindi: "वह कल सुबह काम नहीं कर रही होगी।", note: "Negative with won't be + V1+ing" },
                    { id: "sum-e3", english: "Will you be using the car tonight?", hindi: "क्या आप आज रात कार का इस्तेमाल कर रहे होंगे?", note: "Polite query about expected plan" },
                    { id: "sum-e4", english: "What will she be doing at 10 AM?", hindi: "वह सुबह 10 बजे क्या कर रही होगी?", note: "WH question with What will...be doing" },
                    { id: "sum-e5", english: "They will be sleeping at midnight.", hindi: "वे आधी रात को सो रहे होंगे।", note: "Expected future continuous state" }
                ],
                medium: [
                    { id: "sum-m1", english: "The doctor will be examining patients all morning.", hindi: "डॉक्टर पूरी सुबह मरीजों की जांच कर रहे होंगे।", note: "Action in progress during future period" },
                    { id: "sum-m2", english: "We won't be offering discounts next month.", hindi: "हम अगले महीने छूट नहीं दे रहे होंगे।", note: "Negative policy in progress" },
                    { id: "sum-m3", english: "Will the team be presenting the project tomorrow?", hindi: "क्या टीम कल प्रोजेक्ट प्रस्तुत कर रही होगी?", note: "Interrogative scheduled activity" },
                    { id: "sum-m4", english: "When you arrive, I will be working.", hindi: "जब तुम आओगे, मैं काम कर रहा होऊँगा।", note: "Background action around future event" },
                    { id: "sum-m5", english: "Where will they be staying in Delhi?", hindi: "वे दिल्ली में कहाँ रुक रहे होंगे?", note: "WH question with Where will...be staying" }
                ],
                hard: [
                    { id: "sum-h1", english: "Software engineers will be deploying cloud update tonight.", hindi: "सॉफ्टवेयर इंजीनियर आज रात क्लाउड अपडेट तैनात कर रहे होंगे।", note: "Technical continuous action" },
                    { id: "sum-h2", english: "Auditors won't be signing reports without full audit trail.", hindi: "लेखा परीक्षक पूर्ण ऑडिट ट्रेल के बिना रिपोर्ट पर हस्ताक्षर नहीं कर रहे होंगे।", note: "Formal professional negative" },
                    { id: "sum-h3", english: "Will rescue teams be evacuating residents during storm?", hindi: "क्या बचाव दल तूफान के दौरान निवासियों को सुरक्षित बाहर निकाल रहे होंगे?", note: "Emergency context query" },
                    { id: "sum-h4", english: "What security features will engineers be implementing?", hindi: "इंजीनियर क्या सुरक्षा सुविधाएं लागू कर रहे होंगे?", note: "Complex technical WH question" },
                    { id: "sum-h5", english: "Scientists will be conducting clinical trials next month.", hindi: "वैज्ञानिक अगले महीने नैदानिक परीक्षण कर रहे होंगे।", note: "Scheduled research activity" }
                ]
            }
        },

        // 11. Practice Exercises / अभ्यास (120 Practice Sentences Total)
        exercises: {
            title: "Future Continuous Practice Sentences",
            titleHindi: "अपूर्ण भविष्यत् काल — अभ्यास (120 Practice Sentences)",
            introduction: "Practice all 120 sentences across Positive, Negative, Interrogative, and WH Questions to master Future Continuous Tense.",
            introductionHindi: "Future Continuous Tense के 120 अभ्यास वाक्यों (सकारात्मक, नकारात्मक, प्रश्नवाचक एवं WH प्रश्न) के माध्यम से पूरा अभ्यास करें।",
            categories: []
        },

        // 12. Quiz Configuration / ज्ञान परीक्षा (12 Quiz Combinations)
        quiz: {
            title: "Future Continuous Quiz",
            titleHindi: "अपूर्ण भविष्यत् काल — ज्ञान परीक्षा",
            questions: []
        }
    }
};

// Initialize categories referencing existing sections (120 Practice Sentences total)
futureContinuousLesson.sections.exercises.categories = [
    {
        id: "positive",
        title: "Positive Sentences Practice",
        titleHindi: "1. सकारात्मक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Positive Sentence",
        sentences: futureContinuousLesson.sections.positive.sentences
    },
    {
        id: "negative",
        title: "Negative Sentences Practice",
        titleHindi: "2. नकारात्मक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Negative Sentence",
        sentences: futureContinuousLesson.sections.negative.sentences
    },
    {
        id: "interrogative",
        title: "Interrogative Sentences Practice",
        titleHindi: "3. प्रश्नवाचक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Yes/No Question",
        sentences: futureContinuousLesson.sections.interrogative.sentences
    },
    {
        id: "whQuestions",
        title: "WH Questions Practice",
        titleHindi: "4. WH प्रश्न अभ्यास (30 Sentences)",
        typeLabel: "WH Question",
        sentences: futureContinuousLesson.sections.whQuestions.sentences
    }
];

/**
 * Get the complete Future Continuous lesson object
 * @returns {object}
 */
export function getFutureContinuousLesson() {
    return { ...futureContinuousLesson };
}

/**
 * Get a specific section of Future Continuous lesson data
 * @param {string} sectionName 
 * @returns {object|Array|null}
 */
export function getFutureContinuousSection(sectionName) {
    if (!sectionName || !futureContinuousLesson.sections) return null;
    return futureContinuousLesson.sections[sectionName] || null;
}
