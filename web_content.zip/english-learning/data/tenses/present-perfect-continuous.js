/**
 * Central Lesson Data for Present Perfect Continuous Tense (पूर्ण निरंतर वर्तमान काल)
 * Hindi Medium English Learning Curriculum.
 * ES6 Module export.
 */

export const presentPerfectContinuousLesson = {
    id: "present-perfect-continuous",
    title: "Present Perfect Continuous",
    titleHindi: "पूर्ण निरंतर वर्तमान काल",
    subtitle: "Actions that started in the past and are still continuing or have present results",
    subtitleHindi: "ऐसे कार्य जो भूतकाल में शुरू हुए और वर्तमान में भी जारी हैं या उनका प्रभाव अभी भी है",
    
    sections: {
        // 1. Identification / पहचान (Hindi Medium Learner Guide)
        identification: {
            title: "Identification",
            titleHindi: "काल की पहचान (Identification Guide)",
            english: "Present Perfect Continuous Tense is used for an action that started at some point in the past and has been continuing up to the present time (or has just stopped with a visible result).",
            hindi: "Present Perfect Continuous Tense का प्रयोग ऐसे कार्यों के लिए किया जाता है जो भूतकाल (past) में किसी निश्चित या अनिश्चित समय पर शुरू हुए थे और वर्तमान (present) में भी लगातार चल रहे हैं, या अभी-अभी समाप्त हुए हैं और उनका प्रभाव वर्तमान में दिखाई दे रहा है।",
            
            hindiIdentityRule: "हिंदी वाक्यों के अंत में प्रायः 'रहा है', 'रही है', 'रहे हैं', 'रहा हूँ' के साथ समय (Time/Duration) का उल्लेख होता है। (जैसे: 'से रहा है', 'दो घंटे से कर रहा है', 'सुबह से पढ़ रहा है')।",
            
            identificationPoints: [
                {
                    english: "Time Reference (Since / For): Sentences usually specify WHEN the action started or HOW LONG it has been going on.",
                    hindi: "समय का संदर्भ (Since / For): वाक्यों में अक्सर यह बताया जाता है कि काम कब शुरू हुआ (since) या कितने समय से चल रहा है (for)।"
                },
                {
                    english: "Continuity + Time: Plain 'रहा है' without time is Present Continuous; WITH time it becomes Present Perfect Continuous.",
                    hindi: "निरंतरता + समय: बिना समय के केवल 'रहा है' Present Continuous होता है, लेकिन समय के साथ 'से रहा है' Present Perfect Continuous बनता है।"
                },
                {
                    english: "Present Connection: The action is either still happening now or its immediate physical/mental effect is present.",
                    hindi: "वर्तमान से संबंध: कार्य या तो अभी भी जारी है या उसका तात्कालिक प्रभाव (जैसे थकान, गीले कपड़े) वर्तमान में मौजूद है।"
                }
            ],
            
            comparison: {
                title: "Tense Comparison (तीनों Present Tenses में अंतर)",
                simplePresent: {
                    name: "Simple Present",
                    formula: "Subject + V1/V1+s",
                    concept: "Habitual or routine action (नियमित आदत)",
                    example: "I study English. (मैं अंग्रेजी पढ़ता हूँ।)"
                },
                presentContinuous: {
                    name: "Present Continuous",
                    formula: "Subject + am/is/are + V4(ing)",
                    concept: "Action happening right now without time duration (अभी हो रहा काम)",
                    example: "I am studying English. (मैं अंग्रेजी पढ़ रहा हूँ।)"
                },
                presentPerfectContinuous: {
                    name: "Present Perfect Continuous",
                    formula: "Subject + has/have + been + V1+ing + time",
                    concept: "Action started in past & continuing with time reference (समय के साथ जारी काम)",
                    example: "I have been studying English for two hours. (मैं दो घंटे से अंग्रेजी पढ़ रहा हूँ।)"
                }
            }
        },

        // 2. Uses & Practical Scenarios / उपयोग एवं परिस्थितियाँ
        uses: {
            title: "Uses & Scenarios",
            titleHindi: "प्रयोग और परिस्थितियाँ (5 Major Practical Uses)",
            intro: "Master the 5 key situations where Present Perfect Continuous Tense is used in real-life English communication.",
            introHindi: "व्यावहारिक अंग्रेजी में Present Perfect Continuous Tense के प्रयोग की 5 मुख्य स्थितियाँ समझें।",
            
            list: [
                {
                    id: "use-1",
                    number: "Use 1",
                    title: "Action started in the past and is still continuing now",
                    titleHindi: "भूतकाल में शुरू हुआ कार्य जो वर्तमान में भी जारी है",
                    explanation: "Used when an activity began earlier and is still in progress at the time of speaking.",
                    explanationHindi: "जब कोई कार्य पहले शुरू हुआ था और बोलते समय भी लगातार चल रहा हो।",
                    whyUsed: "Focuses on the duration of an ongoing uninterrupted activity.",
                    whyUsedHindi: "यह कार्य की निरंतरता और उसमें लगे समय पर जोर देता है।",
                    examples: [
                        { english: "She has been working in this company for five years.", hindi: "वह पाँच साल से इस कंपनी में काम कर रही है।", note: "Started 5 years ago, still works there" },
                        { english: "They have been playing football since 4 PM.", hindi: "वे शाम 4 बजे से फुटबॉल खेल रहे हैं।", note: "Started at 4 PM, still playing" }
                    ]
                },
                {
                    id: "use-2",
                    number: "Use 2",
                    title: "Duration of activity using 'FOR' (कितने समय से)",
                    titleHindi: "'FOR' के साथ समयावधि (Duration) का प्रयोग",
                    explanation: "Use 'for' with a period of time (number of hours, days, months, years).",
                    explanationHindi: "जब समय की अवधि (संख्या या मात्रा) बताई जाए, जैसे 2 घंटे, 3 दिन, 5 साल, तब 'for' का प्रयोग करें।",
                    whyUsed: "Answers the question 'How long?' (कितनी देर से?)",
                    whyUsedHindi: "'कितने समय से?' प्रश्न का उत्तर देता है।",
                    examples: [
                        { english: "I have been waiting for two hours.", hindi: "मैं दो घंटे से इंतज़ार कर रहा हूँ।", note: "for + period of time (2 hours)" },
                        { english: "Rahul has been living in Mumbai for ten years.", hindi: "राहुल दस साल से मुंबई में रह रहा है।", note: "for + period of time (10 years)" }
                    ]
                },
                {
                    id: "use-3",
                    number: "Use 3",
                    title: "Starting point of activity using 'SINCE' (कब से)",
                    titleHindi: "'SINCE' के साथ निश्चित शुरुआती समय (Point of Time) का प्रयोग",
                    explanation: "Use 'since' with a specific starting point in time (clock time, day, date, month, year, morning).",
                    explanationHindi: "जब कार्य शुरू होने का निश्चित बिंदु बताया जाए, जैसे सुबह से, 9 बजे से, सोमवार से, 2020 से, तब 'since' का प्रयोग करें।",
                    whyUsed: "Answers the question 'Since when?' (कब से?)",
                    whyUsedHindi: "'कब से काम शुरू हुआ?' बिंदु दर्शाता है।",
                    examples: [
                        { english: "It has been raining since morning.", hindi: "सुबह से बारिश हो रही है।", note: "since + point in time (morning)" },
                        { english: "We have been learning English since Monday.", hindi: "हम सोमवार से अंग्रेजी सीख रहे हैं।", note: "since + point in time (Monday)" }
                    ]
                },
                {
                    id: "use-4",
                    number: "Use 4",
                    title: "Recent continuous action with visible present evidence",
                    titleHindi: "हाल ही में समाप्त कार्य जिसका प्रत्यक्ष प्रभाव वर्तमान में दिख रहा हो",
                    explanation: "Used when the action has just stopped, but its physical result is clearly visible now.",
                    explanationHindi: "जब कार्य अभी-अभी रुका हो, लेकिन उसका असर (जैसे थकान, गीली जमीन) अभी साफ दिख रहा हो।",
                    whyUsed: "Explains the cause of a present physical state.",
                    whyUsedHindi: "वर्तमान की स्थिति का कारण बताने के लिए।",
                    examples: [
                        { english: "You look tired. Have you been running?", hindi: "तुम थके हुए लग रहे हो। क्या तुम दौड़ रहे थे?", note: "Present evidence: looking tired" },
                        { english: "Her eyes are red because she has been crying.", hindi: "उसकी आँखें लाल हैं क्योंकि वह रोती रही है।", note: "Present result: red eyes" }
                    ]
                },
                {
                    id: "use-5",
                    number: "Use 5",
                    title: "Repeated or ongoing habits over a temporary period",
                    titleHindi: "किसी निश्चित अवधि के दौरान बार-बार की जाने वाली गतिविधि",
                    explanation: "Used for repeated temporary actions happening regularly over a recent timeframe.",
                    explanationHindi: "हाल की अवधि में बार-बार की जाने वाली अस्थायी आदत या गतिविधि व्यक्त करने के लिए।",
                    whyUsed: "Highlights a temporary phase of repeated behavior.",
                    whyUsedHindi: "अस्थायी दौर की बारंबारता दर्शाने के लिए।",
                    examples: [
                        { english: "He has been attending morning yoga classes lately.", hindi: "वह आजकल सुबह की योग कक्षाओं में जा रहा है।", note: "Recent repeated habit" },
                        { english: "I have been going to the gym every evening this month.", hindi: "मैं इस महीने हर शाम जिम जा रहा हूँ।", note: "Temporary monthly routine" }
                    ]
                }
            ]
        },

        // 3. Sentence Structure & Formulas / वाक्य संरचना एवं सूत्र
        structure: {
            title: "Structure & Formulas",
            titleHindi: "वाक्य संरचना एवं सूत्र (Formulas)",
            simpleHindiOverview: "Present Perfect Continuous में Auxiliary Verb 'has been' या 'have been' के साथ Main Verb का 'V1 + ing' रूप आता है। साथ ही समय के लिए Since/For का प्रयोग होता है।",
            mainFormula: "Subject + has / have + been + V1+ing + Object + Since / For + Time",
            
            auxiliaryMapping: [
                {
                    subjectGroup: "Group 1: Subject 'I / You / We / They / Plural'",
                    auxiliary: "have been",
                    formula: "I / You / We / They / Plural + have been + V1+ing",
                    hindiRule: "I, You, We, They और सभी बहुवचन कर्ताओं के साथ 'have been' का प्रयोग होता है। (जैसे: They have been waiting.)"
                },
                {
                    subjectGroup: "Group 2: Singular Subjects (He / She / It / Name)",
                    auxiliary: "has been",
                    formula: "He / She / It / Singular + has been + V1+ing",
                    hindiRule: "एकवचन कर्ता (He, She, It, Rahul) के साथ 'has been' का प्रयोग होता है। (जैसे: She has been working.)"
                }
            ],

            v4Explanation: {
                title: "Main Verb Form: V1 + ing",
                titleHindi: "मुख्य क्रिया का रूप: V1 + ing",
                ruleText: "Main Verb = Base Form (V1) + ing",
                explanationHindi: "Present Perfect Continuous में 'has been / have been' के बाद हमेशा वर्ब में -ing जोड़ा जाता है।",
                examples: [
                    { base: "work", v4: "working" },
                    { base: "study", v4: "studying" },
                    { base: "play", v4: "playing" },
                    { base: "write", v4: "writing" },
                    { base: "run", v4: "running" },
                    { base: "wait", v4: "waiting" }
                ]
            },

            formulaBlocks: [
                {
                    type: "positive",
                    title: "1. Positive / Affirmative Sentence",
                    formula: "Subject + has / have + been + V1+ing + Object + since / for + time",
                    englishExplanation: "States an ongoing action starting in the past with time reference.",
                    hindiExplanation: "सकारात्मक वाक्य यह बताते हैं कि कोई कार्य अतीत से अब तक लगातार चल रहा है।",
                    examples: [
                        {
                            english: "She has been reading a book since 2 PM.",
                            hindi: "वह दोपहर 2 बजे से एक किताब पढ़ रही है।",
                            breakdown: { subject: "She", aux: "has been", mainVerb: "reading", object: "a book", complement: "since 2 PM" }
                        },
                        {
                            english: "They have been playing cricket for three hours.",
                            hindi: "वे तीन घंटे से क्रिकेट खेल रहे हैं।",
                            breakdown: { subject: "They", aux: "have been", mainVerb: "playing", object: "cricket", complement: "for three hours" }
                        }
                    ]
                },
                {
                    type: "negative",
                    title: "2. Negative Sentence",
                    formula: "Subject + has / have + NOT + been + V1+ing + Object + since / for + time",
                    englishExplanation: "Insert 'not' between has/have and been to form negatives.",
                    hindiExplanation: "नकारात्मक वाक्यों में has/have और been के बीच में 'not' लगाया जाता है। (has not been / have not been)",
                    examples: [
                        {
                            english: "She has not been reading the book since 2 PM.",
                            hindi: "वह दोपहर 2 बजे से किताब नहीं पढ़ रही है।",
                            breakdown: { subject: "She", aux: "has", not: "not", been: "been", mainVerb: "reading", object: "the book", complement: "since 2 PM" }
                        },
                        {
                            english: "They haven't been playing cricket for three hours.",
                            hindi: "वे तीन घंटे से क्रिकेट नहीं खेल रहे हैं।",
                            breakdown: { subject: "They", aux: "haven't", been: "been", mainVerb: "playing", object: "cricket", complement: "for three hours" }
                        }
                    ]
                },
                {
                    type: "interrogative",
                    title: "3. Interrogative Sentence (Yes/No Questions)",
                    formula: "Has / Have + Subject + been + V1+ing + Object + since / for + time?",
                    englishExplanation: "Place Has/Have before Subject to ask a question.",
                    hindiExplanation: "प्रश्नवाचक वाक्य बनाने के लिए Has/Have को कर्ता (Subject) से पहले रखा जाता है।",
                    examples: [
                        {
                            english: "Has she been reading the book since 2 PM?",
                            hindi: "क्या वह दोपहर 2 बजे से किताब पढ़ रही है?",
                            breakdown: { aux: "Has", subject: "she", been: "been", mainVerb: "reading", object: "the book", complement: "since 2 PM?" }
                        },
                        {
                            english: "Have they been playing cricket for three hours?",
                            hindi: "क्या वे तीन घंटे से क्रिकेट खेल रहे हैं?",
                            breakdown: { aux: "Have", subject: "they", been: "been", mainVerb: "playing", object: "cricket", complement: "for three hours?" }
                        }
                    ]
                },
                {
                    type: "whQuestions",
                    title: "4. WH Question",
                    formula: "WH-word + has / have + Subject + been + V1+ing + Object + since / for + time?",
                    englishExplanation: "Place WH-word at the beginning, followed by Has/Have + Subject + been + V1+ing.",
                    hindiExplanation: "WH प्रश्न में सबसे पहले WH शब्द, फिर Has/Have, फिर Subject, फिर been और V1+ing आता है।",
                    examples: [
                        {
                            english: "How long have you been waiting here?",
                            hindi: "आप यहाँ कितने समय से इंतज़ार कर रहे हैं?",
                            breakdown: { wh: "How long", aux: "have", subject: "you", been: "been", mainVerb: "waiting", complement: "here?" }
                        },
                        {
                            english: "Why has he been shouting since morning?",
                            hindi: "वह सुबह से क्यों चिल्ला रहा है?",
                            breakdown: { wh: "Why", aux: "has", subject: "he", been: "been", mainVerb: "shouting", complement: "since morning?" }
                        }
                    ]
                }
            ]
        },

        // 4. Subject + Verb Rules & V1+ing Spelling Guide / कर्ता और क्रिया के नियम
        subjectVerbRules: {
            title: "Subject + Verb Rules",
            titleHindi: "कर्ता एवं सहायक क्रिया के नियम (Has Been / Have Been Rules)",
            
            auxiliaryMapping: [
                {
                    subjectGroup: "Group 1: Subject 'I / You / We / They / Plural'",
                    auxiliary: "have been",
                    formula: "I / You / We / They / Plural + have been + V1+ing",
                    hindiRule: "I, You, We, They और बहुवचन कर्ता के साथ 'have been' + V1+ing लगाएं।"
                },
                {
                    subjectGroup: "Group 2: Singular Subjects (He / She / It / Name)",
                    auxiliary: "has been",
                    formula: "He / She / It / Singular + has been + V1+ing",
                    hindiRule: "He, She, It और एकवचन कर्ता के साथ 'has been' + V1+ing लगाएं।"
                }
            ],

            v4Explanation: {
                title: "V1+ing Spelling Rules (वर्ब के साथ -ing लगाने के नियम)",
                titleHindi: "V1 + ing बनाने के मुख्य नियम",
                ruleText: "Add -ing to base verb form",
                explanationHindi: "मुख्य क्रिया (Base Verb) के साथ -ing जोड़ते समय स्पेलिंग के इन 4 नियमों का ध्यान रखें।",
                examples: [
                    { base: "work", v4: "working" },
                    { base: "live", v4: "living" },
                    { base: "run", v4: "running" },
                    { base: "die", v4: "dying" }
                ]
            },

            spellingRulesIng: [
                {
                    condition: "1. Most Verbs (सामान्य नियम)",
                    rule: "Add -ing directly to the base verb",
                    examples: "work → working, play → playing, read → reading, study → studying"
                },
                {
                    condition: "2. Verbs ending in silent '-e'",
                    rule: "Drop '-e' and add -ing",
                    examples: "live → living, make → making, write → writing, come → coming"
                },
                {
                    condition: "3. Short Vowel + Single Consonant",
                    rule: "Double the final consonant and add -ing",
                    examples: "run → running, sit → sitting, swim → swimming, stop → stopping"
                },
                {
                    condition: "4. Verbs ending in '-ie'",
                    rule: "Change '-ie' to '-y' and add -ing",
                    examples: "die → dying, lie → lying, tie → tying"
                }
            ]
        },

        // 5. Positive / Affirmative Sentences (सकारात्मक वाक्य - 30 Items)
        positive: {
            title: "Positive / Affirmative Sentences",
            titleHindi: "सकारात्मक वाक्य",
            formula: "Subject + has / have + been + V1+ing + Object + since / for + time",
            formulaPlural: "I / You / We / They + have been + V1+ing",
            formulaSingular: "He / She / It / Name + has been + V1+ing",
            explanation: "Positive sentences express an action that started in the past and is still ongoing with time reference.",
            explanationHindi: "सकारात्मक वाक्य यह व्यक्त करते हैं कि कोई कार्य भूतकाल में शुरू हुआ और वर्तमान में भी जारी है।",
            
            groups: {
                groupHaveBeen: {
                    name: "Group A: Plural Subjects & I/You (have been + V1+ing)",
                    rule: "Use 'have been' + V1+ing with I, You, We, They, Plural Subjects",
                    ruleHindi: "I, You, We, They और बहुवचन कर्ता के साथ have been + V1+ing का प्रयोग करें।",
                    examples: [
                        { english: "I have been studying for two hours.", hindi: "मैं दो घंटे से पढ़ रहा हूँ।", verb: "have been studying" },
                        { english: "They have been playing since morning.", hindi: "वे सुबह से खेल रहे हैं।", verb: "have been playing" }
                    ]
                },
                groupHasBeen: {
                    name: "Group B: Singular Subjects (has been + V1+ing)",
                    rule: "Use 'has been' + V1+ing with He, She, It, Singular Names",
                    ruleHindi: "He, She, It और एकवचन कर्ता के साथ has been + V1+ing का प्रयोग करें।",
                    examples: [
                        { english: "She has been working since 9 AM.", hindi: "वह सुबह 9 बजे से काम कर रही है।", verb: "has been working" },
                        { english: "Rahul has been living here for five years.", hindi: "राहुल पाँच साल से यहाँ रह रहा है।", verb: "has been living" }
                    ]
                }
            },

            sentences: {
                easy: [
                    { id: "pos-e1", english: "I have been studying for two hours.", hindi: "मैं दो घंटे से पढ़ रहा हूँ।", subject: "I", aux: "have been", verb: "studying", object: "for two hours" },
                    { id: "pos-e2", english: "She has been working since 9 AM.", hindi: "वह सुबह 9 बजे से काम कर रही है।", subject: "She", aux: "has been", verb: "working", object: "since 9 AM" },
                    { id: "pos-e3", english: "They have been playing cricket since morning.", hindi: "वे सुबह से क्रिकेट खेल रहे हैं।", subject: "They", aux: "have been", verb: "playing", object: "cricket since morning" },
                    { id: "pos-e4", english: "He has been driving for three hours.", hindi: "वह तीन घंटे से गाड़ी चला रहा है।", subject: "He", aux: "has been", verb: "driving", object: "for three hours" },
                    { id: "pos-e5", english: "We have been living in Delhi since 2018.", hindi: "हम 2018 से दिल्ली में रह रहे हैं।", subject: "We", aux: "have been", verb: "living", object: "in Delhi since 2018" },
                    { id: "pos-e6", english: "The baby has been sleeping since 2 PM.", hindi: "बच्चा दोपहर 2 बजे से सो रहा है।", subject: "The baby", aux: "has been", verb: "sleeping", object: "since 2 PM" },
                    { id: "pos-e7", english: "You have been watching TV for an hour.", hindi: "आप एक घंटे से टीवी देख रहे हैं।", subject: "You", aux: "have been", verb: "watching", object: "TV for an hour" },
                    { id: "pos-e8", english: "It has been raining since yesterday.", hindi: "कल से बारिश हो रही है।", subject: "It", aux: "has been", verb: "raining", object: "since yesterday" },
                    { id: "pos-e9", english: "Priya has been practicing music since morning.", hindi: "प्रिया सुबह से संगीत का अभ्यास कर रही है।", subject: "Priya", aux: "has been", verb: "practicing", object: "music since morning" },
                    { id: "pos-e10", english: "My father has been reading for thirty minutes.", hindi: "मेरे पिता तीस मिनट से पढ़ रहे हैं।", subject: "My father", aux: "has been", verb: "reading", object: "for thirty minutes" }
                ],
                medium: [
                    { id: "pos-m1", english: "The software team has been developing this app for six months.", hindi: "सॉफ्टवेयर टीम छह महीने से इस ऐप को विकसित कर रही है।", subject: "The software team", aux: "has been", verb: "developing", object: "this app for six months" },
                    { id: "pos-m2", english: "Farmers have been working in the fields since sunrise.", hindi: "किसान सूर्योदय से खेतों में काम कर रहे हैं।", subject: "Farmers", aux: "have been", verb: "working", object: "in fields since sunrise" },
                    { id: "pos-m3", english: "She has been preparing for civil services exams since last year.", hindi: "वह पिछले साल से सिविल सेवा परीक्षा की तैयारी कर रही है।", subject: "She", aux: "has been", verb: "preparing", object: "for exams since last year" },
                    { id: "pos-m4", english: "We have been planning this family vacation for weeks.", hindi: "हम हफ़्तों से इस पारिवारिक छुट्टी की योजना बना रहे हैं।", subject: "We", aux: "have been", verb: "planning", object: "vacation for weeks" },
                    { id: "pos-m5", english: "The doctor has been examining patients since morning.", hindi: "डॉक्टर सुबह से मरीजों की जांच कर रहे हैं।", subject: "The doctor", aux: "has been", verb: "examining", object: "patients since morning" },
                    { id: "pos-m6", english: "Constructors have been building this bridge for two years.", hindi: "निर्माणकर्ता दो साल से इस पुल का निर्माण कर रहे हैं।", subject: "Constructors", aux: "have been", verb: "building", object: "bridge for two years" },
                    { id: "pos-m7", english: "He has been teaching mathematics at the university since 2015.", hindi: "वह 2015 से विश्वविद्यालय में गणित पढ़ा रहे हैं।", subject: "He", aux: "has been", verb: "teaching", object: "maths since 2015" },
                    { id: "pos-m8", english: "Passengers have been waiting at the airport terminal for four hours.", hindi: "यात्री चार घंटे से एयरपोर्ट टर्मिनल पर इंतज़ार कर रहे हैं।", subject: "Passengers", aux: "have been", verb: "waiting", object: "at airport for four hours" },
                    { id: "pos-m9", english: "Anita has been taking online coding classes this month.", hindi: "अनीता इस महीने ऑनलाइन कोडिंग क्लास ले रही है।", subject: "Anita", aux: "has been", verb: "taking", object: "coding classes this month" },
                    { id: "pos-m10", english: "Volunteers have been distributing food packs since noon.", hindi: "स्वयंसेवक दोपहर से भोजन के पैकेट बांट रहे हैं।", subject: "Volunteers", aux: "have been", verb: "distributing", object: "food packs since noon" }
                ],
                hard: [
                    { id: "pos-h1", english: "Climate scientists have been studying glacier movements in the Himalayas for decades.", hindi: "जलवायु वैज्ञानिक दशकों से हिमालय में ग्लेशियरों की गतिविधियों का अध्ययन कर रहे हैं।", subject: "Climate scientists", aux: "have been", verb: "studying", object: "glacier movements for decades" },
                    { id: "pos-h2", english: "The international research institute has been conducting clinical trials since January.", hindi: "अंतर्राष्ट्रीय अनुसंधान संस्थान जनवरी से नैदानिक परीक्षण आयोजित कर रहा है।", subject: "The research institute", aux: "has been", verb: "conducting", object: "clinical trials since January" },
                    { id: "pos-h3", english: "Engineers have been troubleshooting network server outages for eight straight hours.", hindi: "इंजीनियर लगातार आठ घंटों से नेटवर्क सर्वर आउटेज को ठीक कर रहे हैं।", subject: "Engineers", aux: "have been", verb: "troubleshooting", object: "server outages for 8 hours" },
                    { id: "pos-h4", english: "Our company has been expanding its operations across Southeast Asia since 2021.", hindi: "हमारी कंपनी 2021 से दक्षिण पूर्व एशिया में अपने परिचालन का विस्तार कर रही है।", subject: "Our company", aux: "has been", verb: "expanding", object: "operations since 2021" },
                    { id: "pos-h5", english: "Archaeologists have been excavating ancient ruins in Greece for three months.", hindi: "पुरातत्वविद तीन महीने से यूनान में प्राचीन खंडहरों की खुदाई कर रहे हैं।", subject: "Archaeologists", aux: "have been", verb: "excavating", object: "ancient ruins for 3 months" },
                    { id: "pos-h6", english: "The municipal corporation has been upgrading city drainage systems all summer.", hindi: "नगर निगम पूरी गर्मी शहर के ड्रेनेज सिस्टम को अपग्रेड कर रहा है।", subject: "Municipal corporation", aux: "has been", verb: "upgrading", object: "drainage systems all summer" },
                    { id: "pos-h7", english: "Financial analysts have been monitoring stock market fluctuations since the announcement.", hindi: "वित्तीय विश्लेषक घोषणा के बाद से शेयर बाजार के उतार-चढ़ाव की निगरानी कर रहे हैं।", subject: "Financial analysts", aux: "have been", verb: "monitoring", object: "market fluctuations since announcement" },
                    { id: "pos-h8", english: "The orchestra has been rehearsing the symphony for five consecutive weeks.", hindi: "ऑर्केस्ट्रा लगातार पांच हफ्तों से सिम्फनी का पूर्वाभ्यास कर रहा है।", subject: "The orchestra", aux: "has been", verb: "rehearsing", object: "symphony for five weeks" },
                    { id: "pos-h9", english: "Cybersecurity experts have been investigating data breach vulnerabilities since yesterday.", hindi: "साइबर सुरक्षा विशेषज्ञ कल से डेटा ब्रीच की कमजोरियों की जांच कर रहे हैं।", subject: "Cybersecurity experts", aux: "have been", verb: "investigating", object: "vulnerabilities since yesterday" },
                    { id: "pos-h10", english: "Astronomers have been tracking the trajectory of a near-Earth asteroid for a year.", hindi: "खगोलशास्त्री एक साल से पृथ्वी के निकट स्थित क्षुद्रग्रह के प्रक्षेपवक्र को ट्रैक कर रहे हैं।", subject: "Astronomers", aux: "have been", verb: "tracking", object: "asteroid trajectory for a year" }
                ]
            }
        },

        // 6. Negative Sentences (नकारात्मक वाक्य - 30 Items)
        negative: {
            title: "Negative Sentences",
            titleHindi: "नकारात्मक वाक्य",
            formula: "Subject + has / have + NOT + been + V1+ing + Object + since / for + time",
            formulaPlural: "I / You / We / They + have not (haven't) been + V1+ing",
            formulaSingular: "He / She / It / Name + has not (hasn't) been + V1+ing",
            explanation: "Negative sentences state that an expected continuous action has not been occurring over the specified timeframe.",
            explanationHindi: "नकारात्मक वाक्य यह दर्शाते हैं कि कोई कार्य दिए गए समय से लगातार नहीं हो रहा है।",
            
            groups: {
                groupHaveNotBeen: {
                    name: "Group A: Plural Subjects & I/You (have not been / haven't been)",
                    rule: "Use 'have not been' (haven't been) + V1+ing",
                    ruleHindi: "I, You, We, They के साथ have not been (haven't been) का प्रयोग करें।",
                    examples: [
                        { english: "I have not been feeling well for two days.", hindi: "मैं दो दिनों से अच्छा महसूस नहीं कर रहा हूँ।", verb: "have not been feeling" },
                        { english: "They haven't been practicing regularly.", hindi: "वे नियमित रूप से अभ्यास नहीं कर रहे हैं।", verb: "haven't been practicing" }
                    ]
                },
                groupHasNotBeen: {
                    name: "Group B: Singular Subjects (has not been / hasn't been)",
                    rule: "Use 'has not been' (hasn't been) + V1+ing",
                    ruleHindi: "He, She, It और एकवचन कर्ता के साथ has not been (hasn't been) का प्रयोग करें।",
                    examples: [
                        { english: "She has not been attending classes since Monday.", hindi: "वह सोमवार से कक्षाओं में नहीं आ रही है।", verb: "has not been attending" },
                        { english: "It hasn't been raining for a week.", hindi: "एक हफ्ते से बारिश नहीं हो रही है।", verb: "hasn't been raining" }
                    ]
                }
            },

            criticalRule: {
                ruleTitle: "CRITICAL RULE: Always place 'NOT' between HAS/HAVE and BEEN!",
                ruleTitleHindi: "महत्वपूर्ण नियम: 'NOT' हमेशा HAS/HAVE और BEEN के बीच में आता है!",
                explanation: "Correct order: has NOT been / have NOT been. Never say 'has been not' or 'has been working not'.",
                explanationHindi: "सही क्रम: has not been / have not been। कभी भी 'has been not' न कहें।",
                comparisonExamples: [
                    { wrong: "She has been not working for two days.", correct: "She has not been working for two days.", note: "Place 'not' before 'been'." },
                    { wrong: "They have been not attending the meeting.", correct: "They have not been attending the meeting.", note: "Place 'not' between have and been." },
                    { wrong: "He hasn't working since morning.", correct: "He hasn't been working since morning.", note: "Do not drop 'been'." }
                ]
            },

            transformations: [
                { positive: "I have been sleeping for 8 hours.", negative: "I have not been sleeping for 8 hours.", note: "Insert 'not' after 'have'." },
                { positive: "She has been working since morning.", negative: "She has not been working since morning.", note: "Insert 'not' after 'has'." },
                { positive: "They have been studying together.", negative: "They haven't been studying together.", note: "Contraction: have not → haven't." }
            ],

            sentences: {
                easy: [
                    { id: "neg-e1", english: "I have not been feeling well since yesterday.", hindi: "मैं कल से अच्छा महसूस नहीं कर रहा हूँ।", subject: "I", aux: "have not been", verb: "feeling", object: "well since yesterday" },
                    { id: "neg-e2", english: "She has not been attending classes for a week.", hindi: "वह एक हफ्ते से क्लास में नहीं आ रही है।", subject: "She", aux: "has not been", verb: "attending", object: "classes for a week" },
                    { id: "neg-e3", english: "They haven't been exercising regularly this month.", hindi: "वे इस महीने नियमित रूप से व्यायाम नहीं कर रहे हैं।", subject: "They", aux: "haven't been", verb: "exercising", object: "regularly this month" },
                    { id: "neg-e4", english: "He has not been sleeping well for two days.", hindi: "वह दो दिनों से ठीक से नहीं सो रहा है।", subject: "He", aux: "has not been", verb: "sleeping", object: "well for two days" },
                    { id: "neg-e5", english: "We have not been living here for very long.", hindi: "हम बहुत समय से यहाँ नहीं रह रहे हैं।", subject: "We", aux: "have not been", verb: "living", object: "here for long" },
                    { id: "neg-e6", english: "It has not been raining since morning.", hindi: "सुबह से बारिश नहीं हो रही है।", subject: "It", aux: "has not been", verb: "raining", object: "since morning" },
                    { id: "neg-e7", english: "You haven't been listening to the teacher.", hindi: "आप शिक्षक की बात नहीं सुन रहे हैं।", subject: "You", aux: "haven't been", verb: "listening", object: "to teacher" },
                    { id: "neg-e8", english: "Rahul has not been using his phone today.", hindi: "राहुल आज अपना फोन इस्तेमाल नहीं कर रहा है।", subject: "Rahul", aux: "has not been", verb: "using", object: "his phone today" },
                    { id: "neg-e9", english: "The bus hasn't been running on time this week.", hindi: "बस इस हफ्ते समय पर नहीं चल रही है।", subject: "The bus", aux: "hasn't been", verb: "running", object: "on time this week" },
                    { id: "neg-e10", english: "My friends have not been talking to each other.", hindi: "मेरे दोस्त एक-दूसरे से बात नहीं कर रहे हैं।", subject: "My friends", aux: "have not been", verb: "talking", object: "to each other" }
                ],
                medium: [
                    { id: "neg-m1", english: "The manager has not been responding to emails since Tuesday.", hindi: "प्रबंधक मंगलवार से ईमेल का उत्तर नहीं दे रहे हैं।", subject: "The manager", aux: "has not been", verb: "responding", object: "to emails since Tuesday" },
                    { id: "neg-m2", english: "Workers haven't been receiving overtime pay for two months.", hindi: "श्रमिकों को दो महीने से ओवरटाइम वेतन नहीं मिल रहा है।", subject: "Workers", aux: "haven't been", verb: "receiving", object: "overtime pay for two months" },
                    { id: "neg-m3", english: "She has not been taking her medicine regularly.", hindi: "वह अपनी दवा नियमित रूप से नहीं ले रही है।", subject: "She", aux: "has not been", verb: "taking", object: "medicine regularly" },
                    { id: "neg-m4", english: "We haven't been getting proper water supply for three days.", hindi: "हमें तीन दिनों से पानी की उचित आपूर्ति नहीं मिल रही है।", subject: "We", aux: "haven't been", verb: "getting", object: "water supply for three days" },
                    { id: "neg-m5", english: "The laptop hasn't been functioning smoothly since the update.", hindi: "अपडेट के बाद से लैपटॉप सुचारू रूप से काम नहीं कर रहा है।", subject: "The laptop", aux: "hasn't been", verb: "functioning", object: "smoothly since update" },
                    { id: "neg-m6", english: "Students have not been submitting assignments on time.", hindi: "छात्र समय पर असाइनमेंट जमा नहीं कर रहे हैं।", subject: "Students", aux: "have not been", verb: "submitting", object: "assignments on time" },
                    { id: "neg-m7", english: "He hasn't been driving carefully on the highway.", hindi: "वह हाईवे पर सावधानी से गाड़ी नहीं चला रहा है।", subject: "He", aux: "hasn't been", verb: "driving", object: "carefully on highway" },
                    { id: "neg-m8", english: "The committee has not been meeting regularly this quarter.", hindi: "समिति की इस तिमाही में नियमित बैठकें नहीं हो रही हैं।", subject: "The committee", aux: "has not been", verb: "meeting", object: "regularly this quarter" },
                    { id: "neg-m9", english: "They haven't been maintaining the garden since summer.", hindi: "वे गर्मी के बाद से बगीचे का रखरखाव नहीं कर रहे हैं।", subject: "They", aux: "haven't been", verb: "maintaining", object: "garden since summer" },
                    { id: "neg-m10", english: "Karan has not been preparing well for his final exams.", hindi: "करण अपनी अंतिम परीक्षा के लिए अच्छी तैयारी नहीं कर रहा है।", subject: "Karan", aux: "has not been", verb: "preparing", object: "for exams" }
                ],
                hard: [
                    { id: "neg-h1", english: "The government has not been enforcing environmental regulations strictly for years.", hindi: "सरकार वर्षों से पर्यावरणीय नियमों को सख्ती से लागू नहीं कर रही है।", subject: "The government", aux: "has not been", verb: "enforcing", object: "regulations for years" },
                    { id: "neg-h2", english: "Major shareholders haven't been supporting the new merger proposal.", hindi: "प्रमुख शेयरधारक नए विलय प्रस्ताव का समर्थन नहीं कर रहे हैं।", subject: "Shareholders", aux: "haven't been", verb: "supporting", object: "merger proposal" },
                    { id: "neg-h3", english: "The research team has not been receiving adequate funding since last year.", hindi: "अनुसंधान दल को पिछले वर्ष से पर्याप्त धन नहीं मिल रहा है।", subject: "The research team", aux: "has not been", verb: "receiving", object: "funding since last year" },
                    { id: "neg-h4", english: "Airlines haven't been operating direct flights to that destination recently.", hindi: "एयरलाइंस हाल ही में उस गंतव्य के लिए सीधी उड़ानें संचालित नहीं कर रही हैं।", subject: "Airlines", aux: "haven't been", verb: "operating", object: "direct flights recently" },
                    { id: "neg-h5", english: "The patient has not been showing significant signs of recovery for three days.", hindi: "मरीज तीन दिनों से ठीक होने के महत्वपूर्ण लक्षण नहीं दिखा रहा है।", subject: "The patient", aux: "has not been", verb: "showing", object: "signs of recovery for 3 days" },
                    { id: "neg-h6", english: "Software developers haven't been updating the legacy codebase.", hindi: "सॉफ्टवेयर डेवलपर लेगेसी कोडबेस को अपडेट नहीं कर रहे हैं।", subject: "Software developers", aux: "haven't been", verb: "updating", object: "legacy codebase" },
                    { id: "neg-h7", english: "The audit team has not been reviewing internal expense reports monthly.", hindi: "ऑडिट टीम हर महीने आंतरिक खर्च रिपोर्ट की समीक्षा नहीं कर रही है।", subject: "The audit team", aux: "has not been", verb: "reviewing", object: "expense reports monthly" },
                    { id: "neg-h8", english: "Residents haven't been segregating domestic waste properly since the notice.", hindi: "निवासी नोटिस के बाद से घरेलू कचरे को ठीक से अलग नहीं कर रहे हैं।", subject: "Residents", aux: "haven't been", verb: "segregating", object: "domestic waste properly" },
                    { id: "neg-h9", english: "The news agency has not been broadcasting unverified report details.", hindi: "समाचार एजेंसी असत्यापित रिपोर्ट विवरण प्रसारित नहीं कर रही है।", subject: "The news agency", aux: "has not been", verb: "broadcasting", object: "unverified report details" },
                    { id: "neg-h10", english: "Telecom providers haven't been upgrading rural signal towers this year.", hindi: "दूरसंचार प्रदाता इस वर्ष ग्रामीण सिग्नल टावरों को अपग्रेड नहीं कर रहे हैं।", subject: "Telecom providers", aux: "haven't been", verb: "upgrading", object: "signal towers this year" }
                ]
            }
        },

        // 7. Interrogative Sentences (प्रश्नवाचक वाक्य - 30 Items)
        interrogative: {
            title: "Interrogative Sentences",
            titleHindi: "प्रश्नवाचक वाक्य (Yes/No Questions)",
            formula: "Has / Have + Subject + been + V1+ing + Object + since / for + time?",
            formulaPlural: "Have + I / You / We / They + been + V1+ing?",
            formulaSingular: "Has + He / She / It / Name + been + V1+ing?",
            explanation: "Interrogative sentences ask whether an action has been ongoing over a period of time.",
            explanationHindi: "प्रश्नवाचक वाक्य यह पूछते हैं कि क्या कोई कार्य किसी समय से लगातार चल रहा है।",
            
            groups: {
                groupHaveBeen: {
                    name: "Group A: Plural Subjects & I/You (Have + Subject + been + V1+ing?)",
                    rule: "Place 'Have' before I, You, We, They",
                    ruleHindi: "I, You, We, They के साथ 'Have' वाक्य के शुरू में लगाएं।",
                    examples: [
                        { english: "Have you been waiting for a long time?", hindi: "क्या आप काफी समय से इंतज़ार कर रहे हैं?", verb: "Have ... been waiting" },
                        { english: "Have they been studying since morning?", hindi: "क्या वे सुबह से पढ़ाई कर रहे हैं?", verb: "Have ... been studying" }
                    ]
                },
                groupHasBeen: {
                    name: "Group B: Singular Subjects (Has + Subject + been + V1+ing?)",
                    rule: "Place 'Has' before He, She, It, Singular Name",
                    ruleHindi: "He, She, It और एकवचन के साथ 'Has' वाक्य के शुरू में लगाएं।",
                    examples: [
                        { english: "Has she been working on this project?", hindi: "क्या वह इस प्रोजेक्ट पर काम कर रही है?", verb: "Has ... been working" },
                        { english: "Has it been raining for hours?", hindi: "क्या घंटों से बारिश हो रही है?", verb: "Has ... been raining" }
                    ]
                }
            },

            criticalRule: {
                ruleTitle: "CRITICAL RULE: Subject sits BETWEEN Has/Have and Been!",
                ruleTitleHindi: "महत्वपूर्ण नियम: कर्ता (Subject) हमेशा Has/Have और Been के बीच बैठता है!",
                explanation: "Correct order: Has/Have + Subject + been + V1+ing. Never put 'been' before Subject.",
                explanationHindi: "सही क्रम: Has/Have + कर्ता + been + V1+ing। 'Been' को कर्ता से पहले न रखें।",
                comparisonExamples: [
                    { wrong: "Has been she studying for two hours?", correct: "Has she been studying for two hours?", note: "Put 'she' between Has and been." },
                    { wrong: "Have been they waiting since morning?", correct: "Have they been waiting since morning?", note: "Put 'they' between Have and been." },
                    { wrong: "Have you working for long?", correct: "Have you been working for long?", note: "Do not omit 'been'." }
                ]
            },

            shortAnswers: [
                {
                    question: "Have you been studying for two hours?",
                    questionHindi: "क्या आप दो घंटे से पढ़ रहे हैं?",
                    yesAnswer: "Yes, I have.",
                    noAnswer: "No, I haven't.",
                    noteHindi: "उत्तर देते समय केवल 'Yes, I have.' या 'No, I haven't.' कहना पर्याप्त होता है।"
                },
                {
                    question: "Has she been working since morning?",
                    questionHindi: "क्या वह सुबह से काम कर रही है?",
                    yesAnswer: "Yes, she has.",
                    noAnswer: "No, she hasn't.",
                    noteHindi: "एकवचन कर्ता के उत्तर में 'Yes, she has.' या 'No, she hasn't.' कहें।"
                }
            ],

            sentences: {
                easy: [
                    { id: "int-e1", english: "Have you been waiting for me for long?", hindi: "क्या आप काफी देर से मेरा इंतज़ार कर रहे हैं?", subject: "you", aux: "Have", verb: "waiting", object: "for me for long?" },
                    { id: "int-e2", english: "Has she been studying since morning?", hindi: "क्या वह सुबह से पढ़ाई कर रही है?", subject: "she", aux: "Has", verb: "studying", object: "since morning?" },
                    { id: "int-e3", english: "Have they been playing cricket for two hours?", hindi: "क्या वे दो घंटे से क्रिकेट खेल रहे हैं?", subject: "they", aux: "Have", verb: "playing", object: "cricket for 2 hours?" },
                    { id: "int-e4", english: "Has he been working in this company since 2020?", hindi: "क्या वह 2020 से इस कंपनी में काम कर रहा है?", subject: "he", aux: "Has", verb: "working", object: "in company since 2020?" },
                    { id: "int-e5", english: "Has it been raining since last night?", hindi: "क्या कल रात से बारिश हो रही है?", subject: "it", aux: "Has", verb: "raining", object: "since last night?" },
                    { id: "int-e6", english: "Have we been driving for three hours now?", hindi: "क्या हम अब तीन घंटे से गाड़ी चला रहे हैं?", subject: "we", aux: "Have", verb: "driving", object: "for three hours?" },
                    { id: "int-e7", english: "Has Rahul been practicing piano all morning?", hindi: "क्या राहुल पूरी सुबह से पियानो का अभ्यास कर रहा है?", subject: "Rahul", aux: "Has", verb: "practicing", object: "piano all morning?" },
                    { id: "int-e8", english: "Have the kids been watching cartoons since noon?", hindi: "क्या बच्चे दोपहर से कार्टून देख रहे हैं?", subject: "the kids", aux: "Have", verb: "watching", object: "cartoons since noon?" },
                    { id: "int-e9", english: "Has the baby been crying for twenty minutes?", hindi: "क्या बच्चा बीस मिनट से रो रहा है?", subject: "the baby", aux: "Has", verb: "crying", object: "for twenty minutes?" },
                    { id: "int-e10", english: "Have you been learning English for five months?", hindi: "क्या आप पांच महीने से अंग्रेजी सीख रहे हैं?", subject: "you", aux: "Have", verb: "learning", object: "English for 5 months?" }
                ],
                medium: [
                    { id: "int-m1", english: "Has the team been testing the new software for weeks?", hindi: "क्या टीम हफ़्तों से नए सॉफ्टवेयर का परीक्षण कर रही है?", subject: "the team", aux: "Has", verb: "testing", object: "software for weeks?" },
                    { id: "int-m2", english: "Have workers been repairing the road since Monday?", hindi: "क्या मजदूर सोमवार से सड़क की मरम्मत कर रहे हैं?", subject: "workers", aux: "Have", verb: "repairing", object: "road since Monday?" },
                    { id: "int-m3", english: "Has she been taking medication regularly for a month?", hindi: "क्या वह एक महीने से नियमित रूप से दवा ले रही है?", subject: "she", aux: "Has", verb: "taking", object: "medication for a month?" },
                    { id: "int-m4", english: "Have passengers been standing in line for two hours?", hindi: "क्या यात्री दो घंटे से कतार में खड़े हैं?", subject: "passengers", aux: "Have", verb: "standing", object: "in line for two hours?" },
                    { id: "int-m5", english: "Has your brother been preparing for competitive exams?", hindi: "क्या आपका भाई प्रतियोगी परीक्षाओं की तैयारी कर रहा है?", subject: "your brother", aux: "Has", verb: "preparing", object: "for competitive exams?" },
                    { id: "int-m6", english: "Have you been living in this neighborhood since childhood?", hindi: "क्या आप बचपन से इस मोहल्ले में रह रहे हैं?", subject: "you", aux: "Have", verb: "living", object: "in neighborhood since childhood?" },
                    { id: "int-m7", english: "Has the teacher been correcting test papers since 8 AM?", hindi: "क्या शिक्षक सुबह 8 बजे से टेस्ट पेपर जांच रहे हैं?", subject: "the teacher", aux: "Has", verb: "correcting", object: "test papers since 8 AM?" },
                    { id: "int-m8", english: "Have engineers been working on the power grid outage?", hindi: "क्या इंजीनियर पावर ग्रिड आउटेज पर काम कर रहे हैं?", subject: "engineers", aux: "Have", verb: "working", object: "on power grid outage?" },
                    { id: "int-m9", english: "Has Anita been running her own business for three years?", hindi: "क्या अनीता तीन साल से अपना खुद का व्यवसाय चला रही है?", subject: "Anita", aux: "Has", verb: "running", object: "business for 3 years?" },
                    { id: "int-m10", english: "Have students been practicing for the annual sports event?", hindi: "क्या छात्र वार्षिक खेल आयोजन के लिए अभ्यास कर रहे हैं?", subject: "students", aux: "Have", verb: "practicing", object: "for sports event?" }
                ],
                hard: [
                    { id: "int-h1", english: "Has the environmental committee been investigating pollution sources in the river?", hindi: "क्या पर्यावरण समिति नदी में प्रदूषण के स्रोतों की जांच कर रही है?", subject: "environmental committee", aux: "Has", verb: "investigating", object: "pollution sources in river?" },
                    { id: "int-h2", english: "Have medical researchers been analyzing trial clinical data for months?", hindi: "क्या चिकित्सा शोधकर्ता महीनों से ट्रायल नैदानिक डेटा का विश्लेषण कर रहे हैं?", subject: "medical researchers", aux: "Have", verb: "analyzing", object: "clinical data for months?" },
                    { id: "int-h3", english: "Has the central bank been adjusting benchmark interest rates steadily?", hindi: "क्या केंद्रीय बैंक लगातार बेंचमार्क ब्याज दरों का समायोजन कर रहा है?", subject: "the central bank", aux: "Has", verb: "adjusting", object: "interest rates steadily?" },
                    { id: "int-h4", english: "Have international observers been monitoring election polling booths since dawn?", hindi: "क्या अंतर्राष्ट्रीय पर्यवेक्षक भोर से चुनाव मतदान केंद्रों की निगरानी कर रहे हैं?", subject: "international observers", aux: "Have", verb: "monitoring", object: "polling booths since dawn?" },
                    { id: "int-h5", english: "Has the software architect been refactoring the codebase all morning?", hindi: "क्या सॉफ्टवेयर आर्किटेक्ट पूरी सुबह से कोडबेस को रीफैक्टर कर रहा है?", subject: "software architect", aux: "Has", verb: "refactoring", object: "codebase all morning?" },
                    { id: "int-h6", english: "Have corporate auditors been inspecting financial transactions for red flags?", hindi: "क्या कॉर्पोरेट ऑडिटर रेड फ्लैग्स के लिए वित्तीय लेनदेन का निरीक्षण कर रहे हैं?", subject: "corporate auditors", aux: "Have", verb: "inspecting", object: "financial transactions?" },
                    { id: "int-h7", english: "Has the municipality been upgrading water treatment facilities since last year?", hindi: "क्या नगरपालिका पिछले वर्ष से जल उपचार सुविधाओं को अपग्रेड कर रही है?", subject: "the municipality", aux: "Has", verb: "upgrading", object: "water treatment facilities?" },
                    { id: "int-h8", english: "Have space scientists been tracking deep space signals for a decade?", hindi: "क्या अंतरिक्ष वैज्ञानिक एक दशक से गहरे अंतरिक्ष के संकेतों को ट्रैक कर रहे हैं?", subject: "space scientists", aux: "Have", verb: "tracking", object: "space signals for a decade?" },
                    { id: "int-h9", english: "Has the legal department been reviewing contract compliance terms carefully?", hindi: "क्या कानून विभाग अनुबंध अनुपालन शर्तों की सावधानीपूर्वक समीक्षा कर रहा है?", subject: "the legal department", aux: "Has", verb: "reviewing", object: "contract compliance terms?" },
                    { id: "int-h10", english: "Have telecommunication technicians been replacing optic fiber cables in the zone?", hindi: "क्या दूरसंचार तकनीशियन क्षेत्र में ऑप्टिक फाइबर केबल बदल रहे हैं?", subject: "telecom technicians", aux: "Have", verb: "replacing", object: "optic fiber cables in zone?" }
                ]
            }
        },

        // 8. WH Questions (WH प्रश्न - 30 Items)
        whQuestions: {
            title: "WH Questions",
            titleHindi: "WH प्रश्न (Information Questions)",
            formula: "WH-word + has / have + Subject + been + V1+ing + Object + since / for + time?",
            formulaPlural: "WH-word + have + Subject + been + V1+ing?",
            formulaSingular: "WH-word + has + Subject + been + V1+ing?",
            explanation: "WH Questions seek specific details (how long, since when, what, why) about ongoing continuous actions.",
            explanationHindi: "WH प्रश्न जारी कार्यों के विवरण जैसे 'कितने समय से', 'कब से', 'क्या', 'क्यों' जानने के लिए पूछे जाते हैं।",
            
            wordGuide: [
                { word: "How long", meaning: "कितने समय से?", usage: "How long have you been waiting?" },
                { word: "Since when", meaning: "कब से?", usage: "Since when has she been working here?" },
                { word: "What", meaning: "क्या?", usage: "What have you been doing since morning?" },
                { word: "Why", meaning: "क्यों?", usage: "Why has he been shouting?" },
                { word: "Where", meaning: "कहाँ?", usage: "Where have they been living for years?" },
                { word: "Who", meaning: "कौन / किसने?", usage: "Who has been ringing the bell?" }
            ],

            sentences: {
                easy: [
                    { id: "wh-e1", english: "How long have you been waiting here?", hindi: "आप यहाँ कितने समय से इंतज़ार कर रहे हैं?", subject: "you", aux: "have", whWord: "How long", verb: "waiting", object: "here?" },
                    { id: "wh-e2", english: "Since when has she been living in Delhi?", hindi: "वह दिल्ली में कब से रह रही है?", subject: "she", aux: "has", whWord: "Since when", verb: "living", object: "in Delhi?" },
                    { id: "wh-e3", english: "What have you been doing since morning?", hindi: "आप सुबह से क्या कर रहे हैं?", subject: "you", aux: "have", whWord: "What", verb: "doing", object: "since morning?" },
                    { id: "wh-e4", english: "Why has he been crying for twenty minutes?", hindi: "वह बीस मिनट से क्यों रो रहा है?", subject: "he", aux: "has", whWord: "Why", verb: "crying", object: "for twenty minutes?" },
                    { id: "wh-e5", english: "Where have they been playing all afternoon?", hindi: "वे पूरी दोपहर कहाँ खेल रहे हैं?", subject: "they", aux: "have", whWord: "Where", verb: "playing", object: "all afternoon?" },
                    { id: "wh-e6", english: "How long has it been raining in your city?", hindi: "आपके शहर में कितने समय से बारिश हो रही है?", subject: "it", aux: "has", whWord: "How long", verb: "raining", object: "in your city?" },
                    { id: "wh-e7", english: "What has Rahul been studying for two hours?", hindi: "राहुल दो घंटे से क्या पढ़ रहा है?", subject: "Rahul", aux: "has", whWord: "What", verb: "studying", object: "for two hours?" },
                    { id: "wh-e8", english: "Why have you been standing outside in the rain?", hindi: "आप बारिश में बाहर क्यों खड़े हैं?", subject: "you", aux: "have", whWord: "Why", verb: "standing", object: "outside in rain?" },
                    { id: "wh-e9", english: "Since when have they been learning English?", hindi: "वे कब से अंग्रेजी सीख रहे हैं?", subject: "they", aux: "have", whWord: "Since when", verb: "learning", object: "English?" },
                    { id: "wh-e10", english: "Who has been ringing the doorbell continuously?", hindi: "लगातार डोरबेल कौन बजा रहा है?", subject: "Who", aux: "has", whWord: "Who", verb: "ringing", object: "doorbell continuously?" }
                ],
                medium: [
                    { id: "wh-m1", english: "How long has the team been developing this project?", hindi: "टीम कितने समय से इस प्रोजेक्ट को विकसित कर रही है?", subject: "the team", aux: "has", whWord: "How long", verb: "developing", object: "project?" },
                    { id: "wh-m2", english: "Why have the workers been protesting since Monday?", hindi: "मजदूर सोमवार से प्रदर्शन क्यों कर रहे हैं?", subject: "the workers", aux: "have", whWord: "Why", verb: "protesting", object: "since Monday?" },
                    { id: "wh-m3", english: "Where has she been working since she graduated?", hindi: "ग्रेजुएट होने के बाद से वह कहाँ काम कर रही है?", subject: "she", aux: "has", whWord: "Where", verb: "working", object: "since graduation?" },
                    { id: "wh-m4", english: "What topics have students been discussing in class?", hindi: "छात्र कक्षा में किन विषयों पर चर्चा कर रहे हैं?", subject: "students", aux: "have", whWord: "What topics", verb: "discussing", object: "in class?" },
                    { id: "wh-m5", english: "Since when has your company been offering remote work?", hindi: "आपकी कंपनी कब से रिमोट काम की पेशकश कर रही है?", subject: "your company", aux: "has", whWord: "Since when", verb: "offering", object: "remote work?" },
                    { id: "wh-m6", english: "How many months have you been practicing yoga?", hindi: "आप कितने महीनों से योग का अभ्यास कर रहे हैं?", subject: "you", aux: "have", whWord: "How many months", verb: "practicing", object: "yoga?" },
                    { id: "wh-m7", english: "Why has the baby been refusing to drink milk?", hindi: "बच्चा दूध पीने से क्यों मना कर रहा है?", subject: "the baby", aux: "has", whWord: "Why", verb: "refusing", object: "to drink milk?" },
                    { id: "wh-m8", english: "Which movie have they been watching for two hours?", hindi: "वे दो घंटे से कौन सी फिल्म देख रहे हैं?", subject: "they", aux: "have", whWord: "Which movie", verb: "watching", object: "for two hours?" },
                    { id: "wh-m9", english: "How long has doctor Anita been treating cancer patients?", hindi: "डॉक्टर अनीता कितने समय से कैंसर के मरीजों का इलाज कर रही हैं?", subject: "doctor Anita", aux: "has", whWord: "How long", verb: "treating", object: "cancer patients?" },
                    { id: "wh-m10", english: "What software have engineers been installing on servers?", hindi: "इंजीनियर सर्वर पर कौन सा सॉफ्टवेयर इंस्टॉल कर रहे हैं?", subject: "engineers", aux: "have", whWord: "What software", verb: "installing", object: "on servers?" }
                ],
                hard: [
                    { id: "wh-h1", english: "How long have climate scientists been monitoring arctic ice melt rates?", hindi: "जलवायु वैज्ञानिक कितने समय से आर्कटिक बर्फ के पिघलने की दर की निगरानी कर रहे हैं?", subject: "climate scientists", aux: "have", whWord: "How long", verb: "monitoring", object: "ice melt rates?" },
                    { id: "wh-h2", english: "Why has the central committee been delaying the policy announcement for weeks?", hindi: "केंद्रीय समिति हफ्तों से नीति की घोषणा में देरी क्यों कर रही है?", subject: "the central committee", aux: "has", whWord: "Why", verb: "delaying", object: "policy announcement for weeks?" },
                    { id: "wh-h3", english: "Since when have international agencies been providing relief aid to the region?", hindi: "अंतर्राष्ट्रीय एजेंसियां उस क्षेत्र में कब से राहत सहायता प्रदान कर रही हैं?", subject: "international agencies", aux: "have", whWord: "Since when", verb: "providing", object: "relief aid to region?" },
                    { id: "wh-h4", english: "What specific strategies have marketers been testing to increase engagement?", hindi: "मार्केटर जुड़ाव बढ़ाने के लिए किन विशिष्ट रणनीतियों का परीक्षण कर रहे हैं?", subject: "marketers", aux: "have", whWord: "What specific strategies", verb: "testing", object: "to increase engagement?" },
                    { id: "wh-h5", english: "Where have archaeologists been digging for ancient artifacts this season?", hindi: "पुरातत्वविद इस सीजन में प्राचीन कलाकृतियों की खुदाई कहाँ कर रहे हैं?", subject: "archaeologists", aux: "have", whWord: "Where", verb: "digging", object: "for artifacts this season?" },
                    { id: "wh-h6", english: "How many years has the author been writing this historical fiction novel?", hindi: "लेखक कितने वर्षों से यह ऐतिहासिक काल्पनिक उपन्यास लिख रहे हैं?", subject: "the author", aux: "has", whWord: "How many years", verb: "writing", object: "this fiction novel?" },
                    { id: "wh-h7", english: "Why have security teams been scanning server logs continuously since midnight?", hindi: "सुरक्षा टीमें आधी रात से लगातार सर्वर लॉग क्यों स्कैन कर रही हैं?", subject: "security teams", aux: "have", whWord: "Why", verb: "scanning", object: "server logs since midnight?" },
                    { id: "wh-h8", english: "Who has been managing the corporate sponsorship accounts during the transition?", hindi: "संक्रमण के दौरान कॉर्पोरेट प्रायोजन खातों का प्रबंधन कौन कर रहा है?", subject: "Who", aux: "has", whWord: "Who", verb: "managing", object: "sponsorship accounts?" },
                    { id: "wh-h9", english: "Which parameters have quality controllers been measuring throughout the shift?", hindi: "गुणवत्ता नियंत्रक पूरी शिफ्ट के दौरान किन मापदंडों को माप रहे हैं?", subject: "quality controllers", aux: "have", whWord: "Which parameters", verb: "measuring", object: "throughout shift?" },
                    { id: "wh-h10", english: "How long has the municipal board been planning the new metro line construction?", hindi: "नगर पालिका बोर्ड कितने समय से नई मेट्रो लाइन के निर्माण की योजना बना रहा है?", subject: "municipal board", aux: "has", whWord: "How long", verb: "planning", object: "metro line construction?" }
                ]
            }
        },

        // 9. Common Mistakes & Corrections / सामान्य गलतियाँ (15 Items)
        commonMistakes: {
            title: "Common Mistakes",
            titleHindi: "सामान्य गलतियाँ और उनके सही रूप (15 Key Mistakes)",
            description: "Avoid these 15 frequent errors made by English learners in Present Perfect Continuous Tense.",
            descriptionHindi: "Present Perfect Continuous Tense सीखते समय शिक्षार्थियों द्वारा की जाने वाली 15 आम गलतियों से बचें।",
            
            list: [
                {
                    id: "err-1",
                    wrong: "I am studying for two hours.",
                    correct: "I have been studying for two hours.",
                    why: "Do not use Present Continuous (am studying) with time duration (for 2 hours). Use Present Perfect Continuous (have been studying)."
                },
                {
                    id: "err-2",
                    wrong: "She has been work since morning.",
                    correct: "She has been working since morning.",
                    why: "After 'has been / have been', use V1+ing ('working'), not base verb V1 ('work')."
                },
                {
                    id: "err-3",
                    wrong: "They have working here for five years.",
                    correct: "They have been working here for five years.",
                    why: "Do not omit 'been'. Present Perfect Continuous structure requires 'have BEEN + V1+ing'."
                },
                {
                    id: "err-4",
                    wrong: "He has been worked on this project.",
                    correct: "He has been working on this project.",
                    why: "Do not use V3 ('worked') after 'has been' in active voice continuous tense; use V1+ing ('working')."
                },
                {
                    id: "err-5",
                    wrong: "I have been living here since five years.",
                    correct: "I have been living here for five years.",
                    why: "Use 'FOR' for duration/number of years (5 years). Use 'SINCE' for starting point (since 2018)."
                },
                {
                    id: "err-6",
                    wrong: "She has been working for 9 AM.",
                    correct: "She has been working since 9 AM.",
                    why: "Use 'SINCE' with specific starting clock time (9 AM), not 'for'."
                },
                {
                    id: "err-7",
                    wrong: "She have been reading since morning.",
                    correct: "She has been reading since morning.",
                    why: "Singular subject 'She' takes 'has been', not 'have been'."
                },
                {
                    id: "err-8",
                    wrong: "They has been playing for two hours.",
                    correct: "They have been playing for two hours.",
                    why: "Plural subject 'They' takes 'have been', not 'has been'."
                },
                {
                    id: "err-9",
                    wrong: "She has been not attending classes.",
                    correct: "She has not been attending classes.",
                    why: "In negative sentences, 'not' goes between 'has' and 'been' (has NOT been)."
                },
                {
                    id: "err-10",
                    wrong: "Has been she working for long?",
                    correct: "Has she been working for long?",
                    why: "In interrogative sentences, Subject sits between Has/Have and been: Has + Subject + been."
                },
                {
                    id: "err-11",
                    wrong: "How long you have been waiting?",
                    correct: "How long have you been waiting?",
                    why: "In WH questions, Auxiliary Verb (have) comes BEFORE Subject (you): WH + have + Subject + been."
                },
                {
                    id: "err-12",
                    wrong: "I have been knowing him for five years.",
                    correct: "I have known him for five years.",
                    why: "Stative verbs like 'know', 'like', 'understand' are not used in continuous forms; use Present Perfect ('have known')."
                },
                {
                    id: "err-13",
                    wrong: "It is raining since morning.",
                    correct: "It has been raining since morning.",
                    why: "Never use 'is raining' with 'since morning'. Time duration requires Present Perfect Continuous ('has been raining')."
                },
                {
                    id: "err-14",
                    wrong: "He hasn't working since Monday.",
                    correct: "He hasn't been working since Monday.",
                    why: "Never drop 'been' in negative continuous sentences (hasn't BEEN working)."
                },
                {
                    id: "err-15",
                    wrong: "She has been run for thirty minutes.",
                    correct: "She has been running for thirty minutes.",
                    why: "Double the consonant for short vowel verbs ('run' → 'running')."
                }
            ]
        },

        // 10. Summary & Revision / सारांश एवं दोहराव (15 Revision Items)
        summary: {
            title: "Summary & Revision",
            titleHindi: "सारांश एवं दोहराव (Revision Summary)",
            
            goldenRules: [
                "1. He / She / It / Singular Subject ➔ HAS BEEN + V1+ing",
                "2. I / You / We / They / Plural Subject ➔ HAVE BEEN + V1+ing",
                "3. SINCE = Point of Time (कब से - e.g., since morning, since 2020, since 9 AM)",
                "4. FOR = Period of Time (कितने समय से - e.g., for 2 hours, for 5 days, for 3 years)",
                "5. Negative: Subject + HAS/HAVE + NOT + BEEN + V1+ing",
                "6. Question: HAS/HAVE + Subject + BEEN + V1+ing + Object?"
            ],

            formulaSummary: {
                positive: "Subject + has/have + been + V1+ing + Object + since/for + time",
                negative: "Subject + has/have + NOT + been + V1+ing + Object + since/for + time",
                interrogative: "Has/Have + Subject + been + V1+ing + Object + since/for + time?",
                whQuestion: "WH + has/have + Subject + been + V1+ing + Object + since/for + time?"
            },

            revisionExamples: {
                easy: [
                    { id: "sum-e1", english: "I have been studying since 8 AM.", hindi: "मैं सुबह 8 बजे से पढ़ रहा हूँ।", note: "have been + V1+ing + since point in time" },
                    { id: "sum-e2", english: "She has been working for four hours.", hindi: "वह चार घंटे से काम कर रही है।", note: "has been + V1+ing + for duration" },
                    { id: "sum-e3", english: "They have not been playing football today.", hindi: "वे आज फुटबॉल नहीं खेल रहे हैं।", note: "Negative with 'have not been'" },
                    { id: "sum-e4", english: "Has it been raining since morning?", hindi: "क्या सुबह से बारिश हो रही है?", note: "Interrogative starting with 'Has'" },
                    { id: "sum-e5", english: "How long have you been waiting?", hindi: "आप कितने समय से इंतज़ार कर रहे हैं?", note: "WH question with 'How long'" }
                ],
                medium: [
                    { id: "sum-m1", english: "The team has been testing the application for three days.", hindi: "टीम तीन दिनों से एप्लिकेशन का परीक्षण कर रही है।", note: "Singular team with 'has been'" },
                    { id: "sum-m2", english: "Farmers haven't been receiving water supply since Monday.", hindi: "किसानों को सोमवार से पानी की आपूर्ति नहीं मिल रही है।", note: "Plural negative with 'haven't been'" },
                    { id: "sum-m3", english: "Have you been practicing English speaking daily?", hindi: "क्या आप रोजाना अंग्रेजी बोलने का अभ्यास कर रहे हैं?", note: "Yes/No Question with 'Have you been'" },
                    { id: "sum-m4", english: "Why has he been shouting at the assistant?", hindi: "वह सहायक पर क्यों चिल्ला रहा है?", note: "WH Question with 'Why has he been'" },
                    { id: "sum-m5", english: "We have been living in this society since 2019.", hindi: "हम 2019 से इस सोसाइटी में रह रहे हैं।", note: "Point of time 'since 2019'" }
                ],
                hard: [
                    { id: "sum-h1", english: "Climate researchers have been recording temperature anomalies for decades.", hindi: "जलवायु शोधकर्ता दशकों से तापमान की विसंगतियों को रिकॉर्ड कर रहे हैं।", note: "Plural subject + have been + V1+ing + for duration" },
                    { id: "sum-h2", english: "The municipal authority has not been upgrading water filters.", hindi: "नगर पालिका प्राधिकरण वाटर फिल्टर को अपग्रेड नहीं कर रहा है।", note: "Complex negative with 'has not been'" },
                    { id: "sum-h3", english: "Which software platform have developers been integrating since last month?", hindi: "डेवलपर पिछले महीने से किस सॉफ्टवेयर प्लेटफॉर्म को एकीकृत कर रहे हैं?", note: "Complex WH question" },
                    { id: "sum-h4", english: "Who has been managing emergency medical relief operations?", hindi: "आपातकालीन चिकित्सा राहत कार्यों का प्रबंधन कौन कर रहा है?", note: "Who as subject with 'has been'" },
                    { id: "sum-h5", english: "Aviation engineers have been servicing radar defense systems for hours.", hindi: "विमानन इंजीनियर घंटों से रडार रक्षा प्रणालियों की सर्विसिंग कर रहे हैं।", note: "Professional context with 'have been servicing'" }
                ]
            }
        },

        // 11. Exercises (120 Practice Sentences Total)
        exercises: {
            title: "Present Perfect Continuous Practice Sentences",
            titleHindi: "पूर्ण निरंतर वर्तमान काल — अभ्यास (120 Practice Sentences)",
            introduction: "Practice all 120 sentences across Positive, Negative, Interrogative, and WH Questions to master Present Perfect Continuous Tense.",
            introductionHindi: "Present Perfect Continuous Tense के 120 अभ्यास वाक्यों (सकारात्मक, नकारात्मक, प्रश्नवाचक एवं WH प्रश्न) के माध्यम से पूरा अभ्यास करें।",
            categories: []
        },

        // 12. Quiz Configuration
        quiz: {
            title: "Present Perfect Continuous Quiz",
            titleHindi: "पूर्ण निरंतर वर्तमान काल — ज्ञान परीक्षा",
            questions: []
        }
    }
};

// Initialize categories referencing existing sections (120 Practice Sentences total)
presentPerfectContinuousLesson.sections.exercises.categories = [
    {
        id: "positive",
        title: "Positive Sentences Practice",
        titleHindi: "1. सकारात्मक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Positive Sentence",
        sentences: presentPerfectContinuousLesson.sections.positive.sentences
    },
    {
        id: "negative",
        title: "Negative Sentences Practice",
        titleHindi: "2. नकारात्मक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Negative Sentence",
        sentences: presentPerfectContinuousLesson.sections.negative.sentences
    },
    {
        id: "interrogative",
        title: "Interrogative Sentences Practice",
        titleHindi: "3. प्रश्नवाचक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Yes/No Question",
        sentences: presentPerfectContinuousLesson.sections.interrogative.sentences
    },
    {
        id: "whQuestions",
        title: "WH Questions Practice",
        titleHindi: "4. WH प्रश्न अभ्यास (30 Sentences)",
        typeLabel: "WH Question",
        sentences: presentPerfectContinuousLesson.sections.whQuestions.sentences
    }
];

/**
 * Get the complete Present Perfect Continuous lesson object
 * @returns {object}
 */
export function getPresentPerfectContinuousLesson() {
    return { ...presentPerfectContinuousLesson };
}

/**
 * Get a specific section of Present Perfect Continuous lesson data
 * @param {string} sectionName 
 * @returns {object|Array|null}
 */
export function getPresentPerfectContinuousSection(sectionName) {
    if (!sectionName || !presentPerfectContinuousLesson.sections) return null;
    return presentPerfectContinuousLesson.sections[sectionName] || null;
}
