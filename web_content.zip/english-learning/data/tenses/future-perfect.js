/**
 * Central Lesson Data for Future Perfect Tense (पूर्ण भविष्यत् काल)
 * Single Source of Truth for Future Perfect Tense Module.
 * Follows proven reference architecture established in completed Present, Past & Future Tenses.
 */

const futurePerfectLesson = {
    id: "future-perfect",
    title: "Future Perfect",
    titleHindi: "पूर्ण भविष्यत् काल (Subject + will have + V3)",
    description: "Learn Future Perfect Tense in simple Hindi & English: Subject + will have + V3 + Object.",

    sections: {
        // 1. Identification / पहचान और अवधारणा
        identification: {
            title: "Identification",
            titleHindi: "पहचान और अवधारणा (Identification & Concept)",
            english: "Future Perfect Tense is used to describe an action that will be completed before a specified future time or before another future event.",
            hindi: "Future Perfect Tense का प्रयोग उन कार्यों को व्यक्त करने के लिए किया जाता है जो भविष्य के किसी निश्चित समय या किसी अन्य भविष्य की घटना से पहले पूरे (complete) हो चुके होंगे।",
            hindiIdentityRule: "पहचान (Hindi Clues): वाक्य के अंत में मुख्य क्रिया के साथ - चुका होगा, चुकी होगी, चुके होंगे, चुका होऊँगा, कर लिया होगा, पहुँच चुके होंगे (जैसे: काम पूरा कर चुका होगा, घर पहुँच चुकी होगी) आता है।",
            points: [
                {
                    english: "Core Concept: Action will be finished prior to a future reference point.",
                    hindi: "मुख्य अवधारणा: कार्य भविष्य की एक निश्चित समय-सीमा से पहले संपन्न हो चुका होगा।"
                },
                {
                    english: "Auxiliary Verb: Use 'will have' for ALL subjects (I, You, He, She, It, We, They, Singular, Plural). Never use 'will has' or 'will had'.",
                    hindi: "सहायक क्रिया: सभी कर्ताओं के साथ केवल 'will have' का प्रयोग होता है। भूलकर भी 'will has' या 'will had' न लगाएं।"
                },
                {
                    english: "Main Verb: Always use V3 (Past Participle Form). Never use V1 or V2 after 'will have'.",
                    hindi: "मुख्य क्रिया: 'will have' के बाद हमेशा मुख्य क्रिया का V3 (Past Participle) रूप लगाया जाता है।"
                },
                {
                    english: "Common Future Time Signals: by tomorrow, by 8 PM, by next week, by next month, by next year, by then, before you arrive, before the meeting starts, by the end of the day, by the end of the year.",
                    hindi: "समय सूचक शब्द: by tomorrow (कल तक), by 8 PM (रात 8 बजे तक), by next week (अगले सप्ताह तक), before you arrive (तुम्हारे आने से पहले) आदि।"
                },
                {
                    english: "Context-Based: Time markers help establish the future completion point but are not strictly mandatory when context is clear.",
                    hindi: "संदर्भ-आधारित: समय सूचक शब्द पूरा होने के समय को स्पष्ट करते हैं, लेकिन संदर्भ स्पष्ट होने पर इनका होना अनिवार्य नहीं है।"
                }
            ],
            comparison: {
                title: "Concept Comparison: Simple Future vs Future Continuous vs Future Perfect vs Present Perfect",
                simpleFuture: {
                    name: "Simple Future (सामान्य भविष्यत्)",
                    formula: "Subject + will + V1",
                    concept: "Future action or decision (भविष्य का कार्य)",
                    example: "I will finish the report at 6 PM. (मैं शाम 6 बजे रिपोर्ट पूरी करूँगा।)"
                },
                futureContinuous: {
                    name: "Future Continuous (अपूर्ण भविष्यत्)",
                    formula: "Subject + will be + V1+ing",
                    concept: "Action in progress at a future time (भविष्य में जारी कार्य)",
                    example: "I will be working at 6 PM. (मैं शाम 6 बजे काम कर रहा होऊँगा।)"
                },
                futurePerfect: {
                    name: "Future Perfect (पूर्ण भविष्यत्)",
                    formula: "Subject + will have + V3",
                    concept: "Action completed before a future deadline (भविष्य की सीमा से पहले पूरा कार्य)",
                    example: "I will have finished the report by 6 PM. (मैं शाम 6 बजे तक रिपोर्ट पूरी कर चुका होऊँगा।)"
                },
                presentPerfect: {
                    name: "Present Perfect (पूर्ण वर्तमान)",
                    formula: "Subject + has/have + V3",
                    concept: "Action completed up to present (वर्तमान समय तक पूरा कार्य)",
                    example: "I have finished the report. (मैं रिपोर्ट पूरी कर चुका हूँ।)"
                }
            }
        },

        // 2. Main Uses / प्रमुख उपयोग (Exactly 5 Major Uses)
        uses: {
            title: "Uses & Scenarios",
            titleHindi: "प्रयोग और परिस्थितियाँ (5 Major Uses)",
            list: [
                {
                    id: "use-1",
                    number: 1,
                    title: "Completed Before a Specific Future Time",
                    titleHindi: "1. भविष्य के किसी निश्चित समय से पहले पूरा कार्य",
                    explanation: "Expresses an action that will be finished before a specific hour, day, or time marker in the future.",
                    explanationHindi: "किसी विशेष भविष्य काल बिंदु (जैसे शाम 6 बजे या कल तक) से पहले पूरा होने वाले कार्य के लिए।",
                    why: "By 6 PM, the work will be completely done.",
                    whyHindi: "शाम 6 बजे की समय-सीमा से पहले काम समाप्त हो चुका होगा।",
                    examples: [
                        { english: "I will have finished the work by 6 PM.", hindi: "मैं शाम 6 बजे तक काम पूरा कर चुका होऊँगा।" },
                        { english: "She will have reached home by 8 PM.", hindi: "वह रात 8 बजे तक घर पहुँच चुकी होगी।" },
                        { english: "They will have closed the shop by midnight.", hindi: "वे आधी रात तक दुकान बंद कर चुके होंगे।" }
                    ]
                },
                {
                    id: "use-2",
                    number: 2,
                    title: "Completed Before Another Future Event",
                    titleHindi: "2. भविष्य की किसी दूसरी घटना से पहले पूरा कार्य",
                    explanation: "Used when one action will be completed before another action happens in the future.",
                    explanationHindi: "जब भविष्य में एक कार्य दूसरे कार्य के होने से पहले ही समाप्त हो चुका होगा।",
                    why: "Her departure occurs prior to your arrival.",
                    whyHindi: "आपके पहुँचने से पहले उसका निकलना पूरा हो चुका होगा।",
                    examples: [
                        { english: "She will have left before you arrive.", hindi: "तुम्हारे पहुँचने से पहले वह निकल चुकी होगी।" },
                        { english: "The movie will have started before we reach the cinema.", hindi: "हमारे सिनेमा हॉल पहुँचने से पहले फिल्म शुरू हो चुकी होगी।" },
                        { english: "The doctor will have checked the patient before family arrives.", hindi: "परिवार के पहुँचने से पहले डॉक्टर मरीज की जाँच कर चुके होंगे।" }
                    ]
                },
                {
                    id: "use-3",
                    number: 3,
                    title: "Completion by a Deadline",
                    titleHindi: "3. किसी दी गई समय-सीमा (Deadline) तक कार्य की समाप्ति",
                    explanation: "Emphasizes achieving or completing a goal by an explicit cutoff date or deadline.",
                    explanationHindi: "किसी तय अंतिम तिथि (जैसे अगला शुक्रवार या अगला महीना) तक कार्य पूरा करने पर ज़ोर।",
                    why: "Next Friday is the firm deadline by which completion is guaranteed.",
                    whyHindi: "अगला शुक्रवार अंतिम तिथि है जिस तक प्रोजेक्ट पूरा हो जाएगा।",
                    examples: [
                        { english: "We will have completed the project by next Friday.", hindi: "हम अगले शुक्रवार तक प्रोजेक्ट पूरा कर चुके होंगे।" },
                        { english: "The team will have submitted the proposal by tomorrow afternoon.", hindi: "टीम कल दोपहर तक प्रस्ताव जमा कर चुकी होगी।" },
                        { english: "I will have cleared all my debts by the end of this year.", hindi: "मैं इस साल के अंत तक अपने सारे कर्जे चुका चुका होऊँगा।" }
                    ]
                },
                {
                    id: "use-4",
                    number: 4,
                    title: "Future Result Viewed From a Future Reference Point",
                    titleHindi: "4. भविष्य के संदर्भ बिंदु से देखा जाने वाला भावी परिणाम",
                    explanation: "Refers to looking back at a completed construction, creation, or state from a future point in time.",
                    explanationHindi: "भविष्य के किसी समय में खड़े होकर उससे पहले हुए निर्माण या स्थिति को देखने के लिए।",
                    why: "Looking back from 'next year', the building process will be an accomplished fact.",
                    whyHindi: "अगले साल के संदर्भ में स्कूल का निर्माण एक संपन्न तथ्य बन चुका होगा।",
                    examples: [
                        { english: "By next year, they will have built the new school.", hindi: "अगले साल तक, वे नया स्कूल बना चुके होंगे।" },
                        { english: "By 2030, scientists will have developed new renewable tech.", hindi: "2030 तक, वैज्ञानिक नई नवीकरणीय तकनीक विकसित कर चुके होंगे।" },
                        { english: "By next decade, the government will have modernized railways.", hindi: "अगले दशक तक, सरकार रेलवे का आधुनिकीकरण कर चुकी होगी।" }
                    ]
                },
                {
                    id: "use-5",
                    number: 5,
                    title: "Expected Completion / Achievement by a Future Time",
                    titleHindi: "5. भविष्य में किसी उपलब्धि या आंकड़े का पूरा होना",
                    explanation: "Used to project accumulated experience, count, or milestones by a future target date.",
                    explanationHindi: "भविष्य की किसी लक्ष्य तिथि तक अर्जित अनुभव, शब्द या माइलस्टोन के पूरा होने का अनुमान लगाना।",
                    why: "500 words is the cumulative count achieved by the month's end.",
                    whyHindi: "महीने के अंत तक 500 शब्द सीखने का लक्ष्य हासिल हो चुका होगा।",
                    examples: [
                        { english: "By the end of this month, he will have learned 500 new words.", hindi: "इस महीने के अंत तक, वह 500 नए शब्द सीख चुका होगा।" },
                        { english: "By next month, she will have completed ten years of service.", hindi: "अगले महीने तक, वह सेवा के दस साल पूरे कर चुकी होगी।" },
                        { english: "By tomorrow, our channel will have gained ten thousand subscribers.", hindi: "कल तक, हमारा चैनल दस हजार सब्सक्राइबर हासिल कर चुका होगा।" }
                    ]
                }
            ]
        },

        // 3. Structure & Formulas / संरचना और सूत्र
        structure: {
            title: "Structure & Formulas",
            titleHindi: "वाक्य संरचना एवं सूत्र (Sentence Formulas)",
            formulas: {
                positive: {
                    name: "Positive Formula",
                    rule: "Subject + will have + V3 + Object/Complement",
                    example: "She will have completed the project by 5 PM.",
                    breakdown: {
                        subject: "She",
                        aux: "will have",
                        verb: "completed (V3)",
                        object: "the project by 5 PM"
                    }
                },
                negative: {
                    name: "Negative Formula",
                    rule: "Subject + will not have (won't have) + V3 + Object",
                    example: "She will not have completed the project by 5 PM.",
                    breakdown: {
                        subject: "She",
                        aux: "will not have / won't have",
                        verb: "completed (V3)",
                        object: "the project by 5 PM"
                    }
                },
                interrogative: {
                    name: "Interrogative Formula",
                    rule: "Will + Subject + have + V3 + Object?",
                    example: "Will she have completed the project by 5 PM?",
                    breakdown: {
                        aux1: "Will",
                        subject: "she",
                        aux2: "have",
                        verb: "completed (V3)",
                        object: "the project by 5 PM?"
                    }
                },
                whQuestion: {
                    name: "WH Question Formula",
                    rule: "WH-word + will + Subject + have + V3 + Object?",
                    example: "When will she have completed the project?",
                    breakdown: {
                        wh: "When",
                        aux1: "will",
                        subject: "she",
                        aux2: "have",
                        verb: "completed (V3)",
                        object: "the project?"
                    }
                }
            }
        },

        // 4. Subject + Verb Rules / कर्ता-क्रिया नियम
        subjectVerbRules: {
            title: "Subject + Verb Rules",
            titleHindi: "कर्ता + क्रिया नियम (Golden Rule: ALL SUBJECTS ➔ WILL HAVE + V3)",
            goldenRule: "Golden Rule: Every subject (I, You, He, She, It, We, They, Singular, Plural) takes WILL HAVE + V3 in Future Perfect.",
            goldenRuleHindi: "स्वर्ण नियम: Future Perfect Tense में सभी कर्ताओं के साथ केवल WILL HAVE + V3 का प्रयोग होता है। (कभी भी will has या will had का प्रयोग न करें)",
            
            table: [
                { subject: "I", aux: "will have", verb: "V3 (finished)", example: "I will have finished." },
                { subject: "You", aux: "will have", verb: "V3 (completed)", example: "You will have completed." },
                { subject: "He", aux: "will have", verb: "V3 (reached)", example: "He will have reached." },
                { subject: "She", aux: "will have", verb: "V3 (gone)", example: "She will have gone." },
                { subject: "It", aux: "will have", verb: "V3 (stopped)", example: "It will have stopped." },
                { subject: "We", aux: "will have", verb: "V3 (eaten)", example: "We will have eaten." },
                { subject: "They", aux: "will have", verb: "V3 (arrived)", example: "They will have arrived." },
                { subject: "Singular Name (Rahul)", aux: "will have", verb: "V3 (done)", example: "Rahul will have done." },
                { subject: "Plural Noun (Students)", aux: "will have", verb: "V3 (passed)", example: "Students will have passed." }
            ],

            v3Rules: {
                title: "V3 Verb Form Table & Incorrect Formations",
                titleHindi: "V3 क्रिया रूप तालिका और अमान्य प्रयोग",
                intro: "After 'will have', the main verb MUST be in V3 (Past Participle) form. Never use V1 or V2.",
                introHindi: "'will have' के बाद मुख्य क्रिया का केवल 3rd form (V3) ही आता है। V1 या V2 न लगाएं।",
                v3TableExamples: "V1 ➔ V2 ➔ V3 Table: go ➔ went ➔ gone | eat ➔ ate ➔ eaten | write ➔ wrote ➔ written | see ➔ saw ➔ seen | do ➔ did ➔ done | take ➔ took ➔ taken | make ➔ made ➔ made | finish ➔ finished ➔ finished | complete ➔ completed ➔ completed | build ➔ built ➔ built",
                correctExamples: "✅ Correct: She will have gone | He will have finished | They will have written | We will have completed",
                incorrectExamples: "❌ Incorrect: She will has gone | He will had finished | They will have wrote | We will have write"
            }
        },

        // 5. Positive Sentences / सकारात्मक वाक्य (30 Items)
        positive: {
            title: "Positive Sentences",
            titleHindi: "सकारात्मक वाक्य (Subject + will have + V3 + Object)",
            formula: "Subject + will have + V3 + Object/Complement",
            explanation: "Expresses positive actions that will be completed before a specified future time or event.",
            explanationHindi: "सकारात्मक वाक्यों में सभी कर्ताओं के साथ 'will have' और मुख्य क्रिया का V3 रूप लगाएं।",
            
            sentences: {
                easy: [
                    { id: "pos-e1", english: "I will have finished the work by 6 PM.", hindi: "मैं शाम 6 बजे तक काम पूरा कर चुका होऊँगा।", subject: "I", aux: "will have", verb: "finished", object: "the work by 6 PM" },
                    { id: "pos-e2", english: "She will have completed the project by tomorrow.", hindi: "वह कल तक प्रोजेक्ट पूरा कर चुकी होगी।", subject: "She", aux: "will have", verb: "completed", object: "the project by tomorrow" },
                    { id: "pos-e3", english: "They will have reached Delhi by night.", hindi: "वे रात तक दिल्ली पहुँच चुके होंगे।", subject: "They", aux: "will have", verb: "reached", object: "Delhi by night" },
                    { id: "pos-e4", english: "We will have eaten dinner before you arrive.", hindi: "आपके पहुँचने से पहले हम खाना खा चुके होंगे।", subject: "We", aux: "will have", verb: "eaten", object: "dinner before you arrive" },
                    { id: "pos-e5", english: "He will have slept by midnight.", hindi: "वह आधी रात तक सो चुका होगा।", subject: "He", aux: "will have", verb: "slept", object: "by midnight" },
                    { id: "pos-e6", english: "Rahul will have left for office by 9 AM.", hindi: "राहुल सुबह 9 बजे तक दफ़्तर के लिए निकल चुका होगा।", subject: "Rahul", aux: "will have", verb: "left", object: "for office by 9 AM" },
                    { id: "pos-e7", english: "You will have learned basic grammar by next month.", hindi: "आप अगले महीने तक बुनियादी व्याकरण सीख चुके होंगे।", subject: "You", aux: "will have", verb: "learned", object: "basic grammar by next month" },
                    { id: "pos-e8", english: "The rain will have stopped by afternoon.", hindi: "दोपहर तक बारिश रुक चुकी होगी।", subject: "The rain", aux: "will have", verb: "stopped", object: "by afternoon" },
                    { id: "pos-e9", english: "My mother will have cooked special meal by evening.", hindi: "मेरी माँ शाम तक विशेष भोजन बना चुकी होंगी।", subject: "My mother", aux: "will have", verb: "cooked", object: "special meal by evening" },
                    { id: "pos-e10", english: "The train will have arrived at station by 8 PM.", hindi: "ट्रेन रात 8 बजे तक स्टेशन पर पहुँच चुकी होगी।", subject: "The train", aux: "will have", verb: "arrived", object: "at station by 8 PM" }
                ],
                medium: [
                    { id: "pos-m1", english: "The doctor will have examined all patients by noon.", hindi: "डॉक्टर दोपहर तक सभी मरीजों की जांच कर चुके होंगे।", subject: "The doctor", aux: "will have", verb: "examined", object: "all patients by noon" },
                    { id: "pos-m2", english: "She will have submitted her research paper by Friday.", hindi: "वह शुक्रवार तक अपना शोध पत्र जमा कर चुकी होगी।", subject: "She", aux: "will have", verb: "submitted", object: "her research paper by Friday" },
                    { id: "pos-m3", english: "The team will have presented proposal before client meeting.", hindi: "क्लाइंट मीटिंग से पहले टीम प्रस्ताव प्रस्तुत कर चुकी होगी।", subject: "The team", aux: "will have", verb: "presented", object: "proposal before client meeting" },
                    { id: "pos-m4", english: "I will have paid all bills by end of this month.", hindi: "मैं इस महीने के अंत तक सभी बिलों का भुगतान कर चुका होऊँगा।", subject: "I", aux: "will have", verb: "paid", object: "all bills by end of this month" },
                    { id: "pos-m5", english: "They will have launched their new store by Diwali.", hindi: "वे दिवाली तक अपना नया स्टोर लॉन्च कर चुके होंगे।", subject: "They", aux: "will have", verb: "launched", object: "their new store by Diwali" },
                    { id: "pos-m6", english: "The manager will have reviewed all applications by 5 PM.", hindi: "मैनेजर शाम 5 बजे तक सभी आवेदनों की समीक्षा कर चुका होगा।", subject: "The manager", aux: "will have", verb: "reviewed", object: "all applications by 5 PM" },
                    { id: "pos-m7", english: "We will have booked hotel rooms before traveling.", hindi: "हम यात्रा करने से पहले होटल के कमरे बुक कर चुके होंगे।", subject: "We", aux: "will have", verb: "booked", object: "hotel rooms before traveling" },
                    { id: "pos-m8", english: "He will have repaired the computer by evening.", hindi: "वह शाम तक कंप्यूटर की मरम्मत कर चुका होगा।", subject: "He", aux: "will have", verb: "repaired", object: "the computer by evening" },
                    { id: "pos-m9", english: "The flight will have landed at airport by 10 PM.", hindi: "उड़ान रात 10 बजे तक हवाई अड्डे पर उतर चुकी होगी।", subject: "The flight", aux: "will have", verb: "landed", object: "at airport by 10 PM" },
                    { id: "pos-m10", english: "She will have graduated from university by next year.", hindi: "वह अगले साल तक विश्वविद्यालय से स्नातक कर चुकी होगी।", subject: "She", aux: "will have", verb: "graduated", object: "from university by next year" }
                ],
                hard: [
                    { id: "pos-h1", english: "The software engineers will have deployed the security update by midnight.", hindi: "सॉफ्टवेयर इंजीनियर आधी रात तक सुरक्षा अपडेट तैनात कर चुके होंगे।", subject: "The software engineers", aux: "will have", verb: "deployed", object: "security update by midnight" },
                    { id: "pos-h2", english: "The board of directors will have approved the budget before Q3.", hindi: "निदेशक मंडल तीसरी तिमाही से पहले बजट को मंजूरी दे चुका होगा।", subject: "The board of directors", aux: "will have", verb: "approved", object: "the budget before Q3" },
                    { id: "pos-h3", english: "Scientists will have published findings by end of semester.", hindi: "वैज्ञानिक सेमेस्टर के अंत तक निष्कर्ष प्रकाशित कर चुके होंगे।", subject: "Scientists", aux: "will have", verb: "published", object: "findings by end of semester" },
                    { id: "pos-h4", english: "The construction workers will have completed bridge before monsoon.", hindi: "निर्माण मजदूर मानसून से पहले पुल का निर्माण पूरा कर चुके होंगे।", subject: "The construction workers", aux: "will have", verb: "completed", object: "bridge before monsoon" },
                    { id: "pos-h5", english: "Financial auditors will have verified audit reports by Monday.", hindi: "वित्तीय लेखा परीक्षक सोमवार तक ऑडिट रिपोर्ट का सत्यापन कर चुके होंगे।", subject: "Financial auditors", aux: "will have", verb: "verified", object: "audit reports by Monday" },
                    { id: "pos-h6", english: "Rescue teams will have evacuated all villagers before cyclone hits.", hindi: "चक्रवात आने से पहले बचाव दल सभी ग्रामीणों को बाहर निकाल चुके होंगे।", subject: "Rescue teams", aux: "will have", verb: "evacuated", object: "all villagers before cyclone" },
                    { id: "pos-h7", english: "She will have written her doctoral thesis before deadline.", hindi: "वह अंतिम समय-सीमा से पहले अपना डॉक्टरेट शोधप्रबंध लिख चुकी होगी।", subject: "She", aux: "will have", verb: "written", object: "doctoral thesis before deadline" },
                    { id: "pos-h8", english: "The supreme court bench will have delivered judgment by Friday.", hindi: "सुप्रीम कोर्ट की पीठ शुक्रवार तक फैसला सुना चुकी होगी।", subject: "The supreme court bench", aux: "will have", verb: "delivered", object: "judgment by Friday" },
                    { id: "pos-h9", english: "Research analysts will have compiled market data by quarter end.", hindi: "अनुसंधान विश्लेषक तिमाही के अंत तक बाजार डेटा संकलित कर चुके होंगे।", subject: "Research analysts", aux: "will have", verb: "compiled", object: "market data by quarter end" },
                    { id: "pos-h10", english: "The government will have implemented economic reforms by next budget.", hindi: "सरकार अगले बजट तक आर्थिक सुधारों को लागू कर चुकी होगी।", subject: "The government", aux: "will have", verb: "implemented", object: "economic reforms by next budget" }
                ]
            }
        },

        // 6. Negative Sentences / नकारात्मक वाक्य (30 Items)
        negative: {
            title: "Negative Sentences",
            titleHindi: "नकारात्मक वाक्य (Subject + will not have / won't have + V3)",
            formula: "Subject + will not have (won't have) + V3 + Object",
            explanation: "Use 'will not have' or contraction 'won't have' followed by V3 to state an action will not be completed by a future time.",
            explanationHindi: "नकारात्मक वाक्यों में 'will not have' या उसका संक्षिप्त रूप 'won't have' लगाकर V3 का प्रयोग करें।",
            
            sentences: {
                easy: [
                    { id: "neg-e1", english: "I will not have finished the work by 6 PM.", hindi: "मैं शाम 6 बजे तक काम पूरा नहीं कर चुका होऊँगा।", subject: "I", aux: "will not have", verb: "finished", object: "the work by 6 PM" },
                    { id: "neg-e2", english: "She won't have completed the project by tomorrow.", hindi: "वह कल तक प्रोजेक्ट पूरा नहीं कर चुकी होगी।", subject: "She", aux: "won't have", verb: "completed", object: "the project by tomorrow" },
                    { id: "neg-e3", english: "They will not have reached Delhi by night.", hindi: "वे रात तक दिल्ली नहीं पहुँच चुके होंगे।", subject: "They", aux: "will not have", verb: "reached", object: "Delhi by night" },
                    { id: "neg-e4", english: "We won't have eaten dinner before you arrive.", hindi: "आपके पहुँचने से पहले हम खाना नहीं खा चुके होंगे।", subject: "We", aux: "won't have", verb: "eaten", object: "dinner before you arrive" },
                    { id: "neg-e5", english: "He will not have slept by midnight.", hindi: "वह आधी रात तक सो नहीं चुका होगा।", subject: "He", aux: "will not have", verb: "slept", object: "by midnight" },
                    { id: "neg-e6", english: "Rahul won't have left for office by 9 AM.", hindi: "राहुल सुबह 9 बजे तक दफ़्तर के लिए नहीं निकल चुका होगा।", subject: "Rahul", aux: "won't have", verb: "left", object: "for office by 9 AM" },
                    { id: "neg-e7", english: "You will not have forgotten this lesson.", hindi: "आप इस पाठ को नहीं भूले होंगे।", subject: "You", aux: "will not have", verb: "forgotten", object: "this lesson" },
                    { id: "neg-e8", english: "It won't have stopped raining by noon.", hindi: "दोपहर तक बारिश नहीं रुकी होगी।", subject: "It", aux: "won't have", verb: "stopped", object: "raining by noon" },
                    { id: "neg-e9", english: "She will not have cooked dinner by 7 PM.", hindi: "वह शाम 7 बजे तक खाना नहीं बना चुकी होगी।", subject: "She", aux: "will not have", verb: "cooked", object: "dinner by 7 PM" },
                    { id: "neg-e10", english: "They won't have arrived before meeting starts.", hindi: "मीटिंग शुरू होने से पहले वे नहीं पहुँचे होंगे।", subject: "They", aux: "won't have", verb: "arrived", object: "before meeting starts" }
                ],
                medium: [
                    { id: "neg-m1", english: "The doctor will not have examined all patients by 11 AM.", hindi: "डॉक्टर सुबह 11 बजे तक सभी मरीजों की जांच नहीं कर चुके होंगे।", subject: "The doctor", aux: "will not have", verb: "examined", object: "all patients by 11 AM" },
                    { id: "neg-m2", english: "She won't have submitted her thesis before Monday.", hindi: "वह सोमवार से पहले अपना शोधप्रबंध जमा नहीं कर चुकी होगी।", subject: "She", aux: "won't have", verb: "submitted", object: "her thesis before Monday" },
                    { id: "neg-m3", english: "The team will not have finished testing before launch.", hindi: "लॉन्च से पहले टीम टेस्टिंग पूरी नहीं कर चुकी होगी।", subject: "The team", aux: "will not have", verb: "finished", object: "testing before launch" },
                    { id: "neg-m4", english: "We won't have cleared debt by end of this quarter.", hindi: "हम इस तिमाही के अंत तक कर्ज नहीं चुका चुके होंगे।", subject: "We", aux: "won't have", verb: "cleared", object: "debt by end of this quarter" },
                    { id: "neg-m5", english: "He will not have repaired motor by evening.", hindi: "वह शाम तक मोटर की मरम्मत नहीं कर चुका होगा।", subject: "He", aux: "will not have", verb: "repaired", object: "motor by evening" },
                    { id: "neg-m6", english: "The teacher won't have graded papers before Friday.", hindi: "शिक्षक शुक्रवार से पहले कॉपियों का मूल्यांकन नहीं कर चुके होंगे।", subject: "The teacher", aux: "won't have", verb: "graded", object: "papers before Friday" },
                    { id: "neg-m7", english: "They will not have gathered all documents by noon.", hindi: "वे दोपहर तक सभी दस्तावेज एकत्र नहीं कर चुके होंगे।", subject: "They", aux: "will not have", verb: "gathered", object: "all documents by noon" },
                    { id: "neg-m8", english: "I won't have received my salary before 5th.", hindi: "मुझे 5 तारीख से पहले वेतन नहीं मिल चुका होगा।", subject: "I", aux: "won't have", verb: "received", object: "my salary before 5th" },
                    { id: "neg-m9", english: "The manager will not have processed refunds today.", hindi: "मैनेजर आज रिफंड की प्रक्रिया पूरी नहीं कर चुका होगा।", subject: "The manager", aux: "will not have", verb: "processed", object: "refunds today" },
                    { id: "neg-m10", english: "She won't have saved enough money by next month.", hindi: "वह अगले महीने तक पर्याप्त पैसे नहीं बचा चुकी होगी।", subject: "She", aux: "won't have", verb: "saved", object: "enough money by next month" }
                ],
                hard: [
                    { id: "neg-h1", english: "Engineers will not have restored server by peak traffic hours.", hindi: "इंजीनियर पीक ट्रैफिक ऑवर्स से पहले सर्वर बहाल नहीं कर चुके होंगे।", subject: "Engineers", aux: "will not have", verb: "restored", object: "server by peak traffic hours" },
                    { id: "neg-h2", english: "The committee won't have reviewed all files before conference.", hindi: "सम्मेलन से पहले समिति सभी फाइलों की समीक्षा नहीं कर चुकी होगी।", subject: "The committee", aux: "won't have", verb: "reviewed", object: "all files before conference" },
                    { id: "neg-h3", english: "Scientists will not have verified experimental data by weekend.", hindi: "वैज्ञानिक सप्ताहांत तक प्रायोगिक आंकड़ों का सत्यापन नहीं कर चुके होंगे।", subject: "Scientists", aux: "will not have", verb: "verified", object: "experimental data by weekend" },
                    { id: "neg-h4", english: "The company won't have achieved annual targets by Q4 end.", hindi: "कंपनी चौथी तिमाही के अंत तक वार्षिक लक्ष्य हासिल नहीं कर चुकी होगी।", subject: "The company", aux: "won't have", verb: "achieved", object: "annual targets by Q4 end" },
                    { id: "neg-h5", english: "Auditors will not have signed compliance report before deadline.", hindi: "लेखा परीक्षक समय-सीमा से पहले अनुपालन रिपोर्ट पर हस्ताक्षर नहीं कर चुके होंगे।", subject: "Auditors", aux: "will not have", verb: "signed", object: "compliance report before deadline" },
                    { id: "neg-h6", english: "Airlines won't have resumed flights before weather clears.", hindi: "मौसम साफ होने से पहले एयरलाइंस उड़ानें फिर से शुरू नहीं कर चुकी होंगी।", subject: "Airlines", aux: "won't have", verb: "resumed", object: "flights before weather clears" },
                    { id: "neg-h7", english: "She will not have gathered sufficient evidence before trial.", hindi: "वह मुकदमे से पहले पर्याप्त सबूत नहीं जुटा चुकी होगी।", subject: "She", aux: "will not have", verb: "gathered", object: "sufficient evidence before trial" },
                    { id: "neg-h8", english: "The tribunal won't have published final order before vacation.", hindi: "छुट्टियों से पहले न्यायाधिकरण अंतिम आदेश प्रकाशित नहीं कर चुका होगा।", subject: "The tribunal", aux: "won't have", verb: "published", object: "final order before vacation" },
                    { id: "neg-h9", english: "Research labs will not have finalized formula by next fiscal year.", hindi: "शोध प्रयोगशालाएं अगले वित्तीय वर्ष तक सूत्र को अंतिम रूप नहीं दे चुकी होंगी।", subject: "Research labs", aux: "will not have", verb: "finalized", object: "formula by next fiscal year" },
                    { id: "neg-h10", english: "The administration won't have resolved public grievances by tomorrow.", hindi: "प्रशासन कल तक जन शिकायतों का निवारण नहीं कर चुका होगा।", subject: "The administration", aux: "won't have", verb: "resolved", object: "public grievances by tomorrow" }
                ]
            }
        },

        // 7. Interrogative Sentences / प्रश्नवाचक वाक्य (30 Items)
        interrogative: {
            title: "Interrogative Sentences",
            titleHindi: "प्रश्नवाचक वाक्य (Will + Subject + have + V3...?)",
            formula: "Will + Subject + have + V3 + Object?",
            explanation: "Form Yes/No questions by placing 'Will' before the Subject, followed by 'have' and V3.",
            explanationHindi: "प्रश्नवाचक वाक्यों में 'Will' को कर्ता से पहले लाएं, फिर 'have' और V3 का प्रयोग करें।",
            
            sentences: {
                easy: [
                    { id: "int-e1", english: "Will you have finished the work by 6 PM?", hindi: "क्या आप शाम 6 बजे तक काम पूरा कर चुके होंगे?", subject: "you", aux: "Will...have", verb: "finished", object: "the work by 6 PM" },
                    { id: "int-e2", english: "Will she have completed the project by tomorrow?", hindi: "क्या वह कल तक प्रोजेक्ट पूरा कर चुकी होगी?", subject: "she", aux: "Will...have", verb: "completed", object: "the project by tomorrow" },
                    { id: "int-e3", english: "Will they have reached Delhi by night?", hindi: "क्या वे रात तक दिल्ली पहुँच चुके होंगे?", subject: "they", aux: "Will...have", verb: "reached", object: "Delhi by night" },
                    { id: "int-e4", english: "Will we have eaten dinner before you arrive?", hindi: "क्या आपके पहुँचने से पहले हम खाना खा चुके होंगे?", subject: "we", aux: "Will...have", verb: "eaten", object: "dinner before you arrive" },
                    { id: "int-e5", english: "Will he have slept by midnight?", hindi: "क्या वह आधी रात तक सो चुका होगा?", subject: "he", aux: "Will...have", verb: "slept", object: "by midnight" },
                    { id: "int-e6", english: "Will Rahul have left for office by 9 AM?", hindi: "क्या राहुल सुबह 9 बजे तक दफ़्तर के लिए निकल चुका होगा?", subject: "Rahul", aux: "Will...have", verb: "left", object: "for office by 9 AM" },
                    { id: "int-e7", english: "Will the rain have stopped by afternoon?", hindi: "क्या दोपहर तक बारिश रुक चुकी होगी?", subject: "the rain", aux: "Will...have", verb: "stopped", object: "by afternoon" },
                    { id: "int-e8", english: "Will you have learned grammar by next month?", hindi: "क्या आप अगले महीने तक व्याकरण सीख चुके होंगे?", subject: "you", aux: "Will...have", verb: "learned", object: "grammar by next month" },
                    { id: "int-e9", english: "Will she have cooked dinner by 7 PM?", hindi: "क्या वह शाम 7 बजे तक खाना बना चुकी होगी?", subject: "she", aux: "Will...have", verb: "cooked", object: "dinner by 7 PM" },
                    { id: "int-e10", english: "Will children have slept before story starts?", hindi: "क्या कहानी शुरू होने से पहले बच्चे सो चुके होंगे?", subject: "children", aux: "Will...have", verb: "slept", object: "before story starts" }
                ],
                medium: [
                    { id: "int-m1", english: "Will doctor have examined all patients by noon?", hindi: "क्या डॉक्टर दोपहर तक सभी मरीजों की जांच कर चुके होंगे?", subject: "doctor", aux: "Will...have", verb: "examined", object: "all patients by noon" },
                    { id: "int-m2", english: "Will she have submitted her paper by Friday?", hindi: "क्या वह शुक्रवार तक अपना पत्र जमा कर चुकी होगी?", subject: "she", aux: "Will...have", verb: "submitted", object: "her paper by Friday" },
                    { id: "int-m3", english: "Will team have presented proposal before meeting?", hindi: "क्या मीटिंग से पहले टीम प्रस्ताव प्रस्तुत कर चुकी होगी?", subject: "team", aux: "Will...have", verb: "presented", object: "proposal before meeting" },
                    { id: "int-m4", english: "Will you have paid all bills by month end?", hindi: "क्या आप महीने के अंत तक सभी बिलों का भुगतान कर चुके होंगे?", subject: "you", aux: "Will...have", verb: "paid", object: "all bills by month end" },
                    { id: "int-m5", english: "Will they have launched new store by Diwali?", hindi: "क्या वे दिवाली तक नया स्टोर लॉन्च कर चुके होंगे?", subject: "they", aux: "Will...have", verb: "launched", object: "new store by Diwali" },
                    { id: "int-m6", english: "Will manager have reviewed all applications by 5 PM?", hindi: "क्या मैनेजर शाम 5 बजे तक सभी आवेदनों की समीक्षा कर चुका होगा?", subject: "manager", aux: "Will...have", verb: "reviewed", object: "applications by 5 PM" },
                    { id: "int-m7", english: "Will we have booked hotel rooms before traveling?", hindi: "क्या हम यात्रा करने से पहले होटल के कमरे बुक कर चुके होंगे?", subject: "we", aux: "Will...have", verb: "booked", object: "hotel rooms before traveling" },
                    { id: "int-m8", english: "Will he have repaired computer system by evening?", hindi: "क्या वह शाम तक कंप्यूटर सिस्टम की मरम्मत कर चुका होगा?", subject: "he", aux: "Will...have", verb: "repaired", object: "computer system by evening" },
                    { id: "int-m9", english: "Will flight have landed at airport by 10 PM?", hindi: "क्या उड़ान रात 10 बजे तक हवाई अड्डे पर उतर चुकी होगी?", subject: "flight", aux: "Will...have", verb: "landed", object: "at airport by 10 PM" },
                    { id: "int-m10", english: "Will she have graduated by next year?", hindi: "क्या वह अगले साल तक स्नातक कर चुकी होगी?", subject: "she", aux: "Will...have", verb: "graduated", object: "by next year" }
                ],
                hard: [
                    { id: "int-h1", english: "Will software engineers have deployed update by midnight?", hindi: "क्या सॉफ्टवेयर इंजीनियर आधी रात तक अपडेट तैनात कर चुके होंगे?", subject: "software engineers", aux: "Will...have", verb: "deployed", object: "update by midnight" },
                    { id: "int-h2", english: "Will board of directors have approved budget before Q3?", hindi: "क्या निदेशक मंडल तीसरी तिमाही से पहले बजट को मंजूरी दे चुका होगा?", subject: "board of directors", aux: "Will...have", verb: "approved", object: "budget before Q3" },
                    { id: "int-h3", english: "Will scientists have published research findings by year end?", hindi: "क्या वैज्ञानिक साल के अंत तक शोध निष्कर्ष प्रकाशित कर चुके होंगे?", subject: "scientists", aux: "Will...have", verb: "published", object: "findings by year end" },
                    { id: "int-h4", english: "Will workers have completed highway before monsoon?", hindi: "क्या मजदूर मानसून से पहले हाईवे का निर्माण पूरा कर चुके होंगे?", subject: "workers", aux: "Will...have", verb: "completed", object: "highway before monsoon" },
                    { id: "int-h5", english: "Will auditors have verified records by Monday?", hindi: "क्या लेखा परीक्षक सोमवार तक अभिलेखों का सत्यापन कर चुके होंगे?", subject: "auditors", aux: "Will...have", verb: "verified", object: "records by Monday" },
                    { id: "int-h6", english: "Will authorities have evacuated villagers before storm?", hindi: "क्या तूफान आने से पहले अधिकारी ग्रामीणों को बाहर निकाल चुके होंगे?", subject: "authorities", aux: "Will...have", verb: "evacuated", object: "villagers before storm" },
                    { id: "int-h7", english: "Will she have written her thesis before deadline?", hindi: "क्या वह समय-सीमा से पहले अपना शोधप्रबंध लिख चुकी होगी?", subject: "she", aux: "Will...have", verb: "written", object: "thesis before deadline" },
                    { id: "int-h8", english: "Will court bench have delivered judgment by Friday?", hindi: "क्या कोर्ट की पीठ शुक्रवार तक फैसला सुना चुकी होगी?", subject: "court bench", aux: "Will...have", verb: "delivered", object: "judgment by Friday" },
                    { id: "int-h9", english: "Will analysts have compiled market data by quarter end?", hindi: "क्या विश्लेषक तिमाही के अंत तक बाजार डेटा संकलित कर चुके होंगे?", subject: "analysts", aux: "Will...have", verb: "compiled", object: "market data by quarter end" },
                    { id: "int-h10", english: "Will government have implemented reforms by next budget?", hindi: "क्या सरकार अगले बजट तक सुधारों को लागू कर चुकी होगी?", subject: "government", aux: "Will...have", verb: "implemented", object: "reforms by next budget" }
                ]
            }
        },

        // 8. WH Questions / WH प्रश्न (30 Items)
        whQuestions: {
            title: "WH Questions",
            titleHindi: "WH प्रश्न (WH + will + Subject + have + V3...?)",
            formula: "WH-word + will + Subject + have + V3 + Object?",
            explanation: "Place the WH-word first, followed by 'will', Subject, 'have', and V3.",
            explanationHindi: "WH प्रश्नों में सबसे पहले WH-शब्द, फिर 'will', कर्ता, 'have' और V3 लगाएं।",
            
            sentences: {
                easy: [
                    { id: "wh-e1", english: "What will you have finished by 6 PM?", hindi: "आप शाम 6 बजे तक क्या पूरा कर चुके होंगे?", subject: "you", aux: "will...have", verb: "finished", object: "by 6 PM", whWord: "What" },
                    { id: "wh-e2", english: "Where will she have reached by night?", hindi: "वह रात तक कहाँ पहुँच चुकी होगी?", subject: "she", aux: "will...have", verb: "reached", object: "by night", whWord: "Where" },
                    { id: "wh-e3", english: "When will they have completed the project?", hindi: "वे प्रोजेक्ट कब पूरा कर चुके होंगे?", subject: "they", aux: "will...have", verb: "completed", object: "the project", whWord: "When" },
                    { id: "wh-e4", english: "Why will he have left before sunset?", hindi: "वह सूर्यास्त से पहले क्यों निकल चुका होगा?", subject: "he", aux: "will...have", verb: "left", object: "before sunset", whWord: "Why" },
                    { id: "wh-e5", english: "Who will have finished the assignment first?", hindi: "असाइनमेंट सबसे पहले कौन पूरा कर चुका होगा?", subject: "Who", aux: "will...have", verb: "finished", object: "assignment first", whWord: "Who" },
                    { id: "wh-e6", english: "Which book will Rahul have read by end of day?", hindi: "राहुल दिन के अंत तक कौन सी किताब पढ़ चुका होगा?", subject: "Rahul", aux: "will...have", verb: "read", object: "by end of day", whWord: "Which book" },
                    { id: "wh-e7", english: "How will she have solved the issue before meeting?", hindi: "वह मीटिंग से पहले समस्या कैसे हल कर चुकी होगी?", subject: "she", aux: "will...have", verb: "solved", object: "issue before meeting", whWord: "How" },
                    { id: "wh-e8", english: "Whose car will they have borrowed for trip?", hindi: "वे यात्रा के लिए किसकी कार उधार ले चुके होंगे?", subject: "they", aux: "will...have", verb: "borrowed", object: "for trip", whWord: "Whose car" },
                    { id: "wh-e9", english: "How much money will he have saved by next year?", hindi: "वह अगले साल तक कितना पैसा बचा चुका होगा?", subject: "he", aux: "will...have", verb: "saved", object: "by next year", whWord: "How much money" },
                    { id: "wh-e10", english: "Where will we have parked our vehicle by noon?", hindi: "हम दोपहर तक अपना वाहन कहाँ खड़ा कर चुके होंगे?", subject: "we", aux: "will...have", verb: "parked", object: "our vehicle by noon", whWord: "Where" }
                ],
                medium: [
                    { id: "wh-m1", english: "What will doctor have suggested for recovery by then?", hindi: "तब तक डॉक्टर रिकवरी के लिए क्या सुझाव दे चुके होंगे?", subject: "doctor", aux: "will...have", verb: "suggested", object: "for recovery by then", whWord: "What" },
                    { id: "wh-m2", english: "Why will she have resigned before contract end?", hindi: "वह अनुबंध समाप्त होने से पहले इस्तीफा क्यों दे चुकी होगी?", subject: "she", aux: "will...have", verb: "resigned", object: "before contract end", whWord: "Why" },
                    { id: "wh-m3", english: "How will team have achieved quarterly target by Friday?", hindi: "टीम शुक्रवार तक तिमाही लक्ष्य कैसे हासिल कर चुकी होगी?", subject: "team", aux: "will...have", verb: "achieved", object: "target by Friday", whWord: "How" },
                    { id: "wh-m4", english: "Where will they have constructed plant by 2030?", hindi: "वे 2030 तक संयंत्र कहाँ बना चुके होंगे?", subject: "they", aux: "will...have", verb: "constructed", object: "plant by 2030", whWord: "Where" },
                    { id: "wh-m5", english: "When will manager have evaluated annual reports?", hindi: "मैनेजर वार्षिक रिपोर्टों का मूल्यांकन कब कर चुका होगा?", subject: "manager", aux: "will...have", verb: "evaluated", object: "annual reports", whWord: "When" },
                    { id: "wh-m6", english: "Which candidate will voters have supported by election day?", hindi: "चुनाव के दिन तक मतदाता किस उम्मीदवार का समर्थन कर चुके होंगे?", subject: "voters", aux: "will...have", verb: "supported", object: "by election day", whWord: "Which candidate" },
                    { id: "wh-m7", english: "How many targets will he have achieved by year end?", hindi: "वह साल के अंत तक कितने लक्ष्य हासिल कर चुका होगा?", subject: "he", aux: "will...have", verb: "achieved", object: "by year end", whWord: "How many targets" },
                    { id: "wh-m8", english: "Why will students have gathered outside hall by 10 AM?", hindi: "सुबह 10 बजे तक छात्र हॉल के बाहर क्यों एकत्र हो चुके होंगे?", subject: "students", aux: "will...have", verb: "gathered", object: "outside hall by 10 AM", whWord: "Why" },
                    { id: "wh-m9", english: "Who will have organized the tech conference by Friday?", hindi: "शुक्रवार तक टेक सम्मेलन का आयोजन कौन कर चुका होगा?", subject: "Who", aux: "will...have", verb: "organized", object: "tech conference by Friday", whWord: "Who" },
                    { id: "wh-m10", english: "Where will she have hidden secret documents before audit?", hindi: "ऑडिट से पहले वह गुप्त दस्तावेज कहाँ छिपा चुकी होगी?", subject: "she", aux: "will...have", verb: "hidden", object: "documents before audit", whWord: "Where" }
                ],
                hard: [
                    { id: "wh-h1", english: "What security patch will engineers have implemented by midnight?", hindi: "इंजीनियर आधी रात तक क्या सुरक्षा पैच लागू कर चुके होंगे?", subject: "engineers", aux: "will...have", verb: "implemented", object: "by midnight", whWord: "What security patch" },
                    { id: "wh-h2", english: "Why will board of directors have rejected the proposal by Q3?", hindi: "निदेशक मंडल तीसरी तिमाही तक प्रस्ताव क्यों खारिज कर चुका होगा?", subject: "board of directors", aux: "will...have", verb: "rejected", object: "proposal by Q3", whWord: "Why" },
                    { id: "wh-h3", english: "How will scientists have synthesized the compound before deadline?", hindi: "समय-सीमा से पहले वैज्ञानिक यौगिक का संश्लेषण कैसे कर चुके होंगे?", subject: "scientists", aux: "will...have", verb: "synthesized", object: "compound before deadline", whWord: "How" },
                    { id: "wh-h4", english: "Where will authorities have set up relief camps before cyclone?", hindi: "चक्रवात से पहले अधिकारी राहत शिविर कहाँ स्थापित कर चुके होंगे?", subject: "authorities", aux: "will...have", verb: "set up", object: "relief camps before cyclone", whWord: "Where" },
                    { id: "wh-h5", english: "When will auditors have submitted tax compliance report?", hindi: "लेखा परीक्षक टैक्स अनुपालन रिपोर्ट कब जमा कर चुके होंगे?", subject: "auditors", aux: "will...have", verb: "submitted", object: "tax compliance report", whWord: "When" },
                    { id: "wh-h6", english: "Which policies will government have amended by next session?", hindi: "अगले सत्र तक सरकार किन नीतियों में संशोधन कर चुकी होगी?", subject: "government", aux: "will...have", verb: "amended", object: "by next session", whWord: "Which policies" },
                    { id: "wh-h7", english: "How many delegates will have registered for global summit by Monday?", hindi: "सोमवार तक वैश्विक शिखर सम्मेलन के लिए कितने प्रतिनिधि पंजीकरण करा चुके होंगे?", subject: "delegates", aux: "will...have", verb: "registered", object: "for global summit by Monday", whWord: "How many delegates" },
                    { id: "wh-h8", english: "Why will tribunal have reviewed previous judgment by next week?", hindi: "न्यायाधिकरण अगले सप्ताह तक पिछले फैसले की समीक्षा क्यों कर चुका होगा?", subject: "tribunal", aux: "will...have", verb: "reviewed", object: "judgment by next week", whWord: "Why" },
                    { id: "wh-h9", english: "Whose application will committee have approved by month end?", hindi: "महीने के अंत तक समिति किसका आवेदन स्वीकृत कर चुकी होगी?", subject: "committee", aux: "will...have", verb: "approved", object: "by month end", whWord: "Whose application" },
                    { id: "wh-h10", english: "Where will research team have conducted clinical trials by next year?", hindi: "अगले साल तक शोध टीम नैदानिक परीक्षण कहाँ आयोजित कर चुकी होगी?", subject: "research team", aux: "will...have", verb: "conducted", object: "trials by next year", whWord: "Where" }
                ]
            }
        },

        // 9. Common Mistakes & Corrections / सामान्य गलतियाँ (At least 15 Items)
        commonMistakes: {
            title: "Common Mistakes",
            titleHindi: "सामान्य गलतियाँ और सुधार (Common Mistakes & Corrections)",
            intro: "Avoid these 15 common errors when forming Future Perfect Tense sentences.",
            introHindi: "Future Perfect Tense का प्रयोग करते समय इन 15 सामान्य गलतियों से बचें।",
            mistakes: [
                {
                    wrong: "She will has finished the work by 6 PM.",
                    correct: "She will have finished the work by 6 PM.",
                    why: "Never use 'will has'. Modern auxiliary is always 'will have' for ALL subjects (I, You, He, She, They).",
                    whyHindi: "कभी भी 'will has' का प्रयोग न करें। सभी कर्ताओं के लिए केवल 'will have' ही आता है।"
                },
                {
                    wrong: "They will had completed the project.",
                    correct: "They will have completed the project.",
                    why: "Never use 'will had'. Always use base modal auxiliary 'will have'.",
                    whyHindi: "भविष्यत् काल में 'will had' का प्रयोग गलत है, केवल 'will have' लगाएं।"
                },
                {
                    wrong: "I will have finish the report by tomorrow.",
                    correct: "I will have finished the report by tomorrow.",
                    why: "Use V3 (finished) after 'will have', not V1 (finish).",
                    whyHindi: "'will have' के बाद क्रिया का 3rd form (V3 - finished) आता है, V1 नहीं।"
                },
                {
                    wrong: "She will have wrote the letter before sunset.",
                    correct: "She will have written the letter before sunset.",
                    why: "Use V3 (written) after 'will have', not V2 (wrote).",
                    whyHindi: "'will have' के बाद V2 (wrote) न लगाएं, V3 (written) का प्रयोग करें।"
                },
                {
                    wrong: "They will finished the work by 6 PM.",
                    correct: "They will have finished the work by 6 PM.",
                    why: "Future Perfect requires auxiliary 'have' between 'will' and V3. Missing 'have' makes it ungrammatical.",
                    whyHindi: "'will' और V3 के बीच 'have' लगाना अनिवार्य है।"
                },
                {
                    wrong: "I have finished the work by tomorrow 6 PM.",
                    correct: "I will have finished the work by tomorrow 6 PM.",
                    why: "Use 'will have' for future deadline, not present auxiliary 'have'.",
                    whyHindi: "भविष्य की समय-सीमा (tomorrow) के लिए Present Perfect नहीं, Future Perfect लगाएं।"
                },
                {
                    wrong: "She will have not finished the work.",
                    correct: "She will not have finished the work. / She won't have finished the work.",
                    why: "Place 'not' between 'will' and 'have' (will not have), not after 'have'.",
                    whyHindi: "नकारात्मक वाक्य में 'not' 'will' और 'have' के बीच आता है।"
                },
                {
                    wrong: "Will have she completed the project?",
                    correct: "Will she have completed the project?",
                    why: "In interrogative sentences, place the Subject ('she') between 'Will' and 'have'.",
                    whyHindi: "प्रश्नवाचक वाक्य में कर्ता (she) 'Will' और 'have' के बीच आता है।"
                },
                {
                    wrong: "Why she will have completed the work?",
                    correct: "Why will she have completed the work?",
                    why: "In WH questions, auxiliary 'will' must come BEFORE the subject ('she').",
                    whyHindi: "WH प्रश्नों में 'will' कर्ता (she) से पहले आता है।"
                },
                {
                    wrong: "They will have go to Delhi by night.",
                    correct: "They will have gone to Delhi by night.",
                    why: "Use V3 (gone) after 'will have', not V1 (go).",
                    whyHindi: "'will have' के बाद 'go' नहीं, V3 'gone' आता है।"
                },
                {
                    wrong: "She will finish the work by 6 PM tomorrow.",
                    correct: "She will have finished the work by 6 PM tomorrow.",
                    why: "When emphasizing completion prior to a specific future time ('by 6 PM'), Future Perfect ('will have finished') is preferred over Simple Future.",
                    whyHindi: "समय-सीमा (by 6 PM) से पहले काम पूरा होने पर 'will have finished' अधिक सटीक है।"
                },
                {
                    wrong: "When you will arrive, she will have left.",
                    correct: "When you arrive, she will have left.",
                    why: "In time clauses starting with 'when/before', use Simple Present ('arrive'), not Simple Future ('will arrive').",
                    whyHindi: "Time clause (When/Before से शुरू) में Simple Present (arrive) का प्रयोग होता है।"
                },
                {
                    wrong: "I will have working at 6 PM tomorrow.",
                    correct: "I will have finished working by 6 PM tomorrow. / I will be working at 6 PM tomorrow.",
                    why: "Do not mix Future Continuous ('will be working') with Future Perfect ('will have finished').",
                    whyHindi: "Future Continuous और Future Perfect के सूत्रों को आपस में न मिलाएं।"
                },
                {
                    wrong: "They will have completed the work since 6 PM.",
                    correct: "They will have completed the work by 6 PM.",
                    why: "Use preposition 'by' (तक) for future completion deadlines, not 'since' (जो कि past point of time के लिए होता है).",
                    whyHindi: "भविष्य की समय-सीमा के लिए 'by' (तक) का प्रयोग करें, 'since' का नहीं।"
                },
                {
                    wrong: "He will has eaten dinner before 9 PM.",
                    correct: "He will have eaten dinner before 9 PM.",
                    why: "Even with singular subject 'He', modal auxiliary 'will' is followed by base form 'have', never 'has'.",
                    whyHindi: "ही (He) कर्ता होने पर भी modal 'will' के बाद हमेशा base 'have' ही आता है, 'has' नहीं।"
                }
            ]
        },

        // 10. Summary & Revision / सारांश एवं दोहराव (15 Revision Examples)
        summary: {
            title: "Summary & Revision",
            titleHindi: "पाठ सारांश एवं दोहराव (Summary & Memory Anchors)",
            keyPoints: [
                "1. Core Concept ➔ Describes an action that will be completed before a specified future time or another event.",
                "2. Golden Rule ➔ ALL SUBJECTS take WILL HAVE + V3.",
                "3. Main Verb Rule ➔ Main verb MUST stay in V3 (Past Participle) form. Never use V1 or V2.",
                "4. Negative Form ➔ Subject + will not have (won't have) + V3.",
                "5. Interrogative Form ➔ Will + Subject + have + V3...?",
                "6. 5 Core Uses ➔ Completed before specific future time, completed before another event, deadline completion, future result viewed from future reference, expected milestone.",
                "7. Key Signals ➔ by tomorrow, by 8 PM, by next week, before you arrive, by the end of the day."
            ],

            formulaSummary: {
                positive: "Subject + will have + V3 + Object",
                negative: "Subject + will not have (won't have) + V3 + Object",
                interrogative: "Will + Subject + have + V3 + Object?",
                whQuestion: "WH-word + will + Subject + have + V3 + Object?"
            },

            revisionExamples: {
                easy: [
                    { id: "sum-e1", english: "I will have finished the work by 6 PM.", hindi: "मैं शाम 6 बजे तक काम पूरा कर चुका होऊँगा।", note: "Completion before specific future time" },
                    { id: "sum-e2", english: "She won't have completed the project by tomorrow.", hindi: "वह कल तक प्रोजेक्ट पूरा नहीं कर चुकी होगी।", note: "Negative with won't have + V3" },
                    { id: "sum-e3", english: "Will you have finished the work before meeting?", hindi: "क्या आप मीटिंग से पहले काम पूरा कर चुके होंगे?", note: "Interrogative question with Will...have + V3" },
                    { id: "sum-e4", english: "When will she have completed the project?", hindi: "वह प्रोजेक्ट कब पूरा कर चुकी होगी?", note: "WH question with When will...have + V3" },
                    { id: "sum-e5", english: "They will have reached Delhi by night.", hindi: "वे रात तक दिल्ली पहुँच चुके होंगे।", note: "Expected future completion" }
                ],
                medium: [
                    { id: "sum-m1", english: "The doctor will have examined all patients by noon.", hindi: "डॉक्टर दोपहर तक सभी मरीजों की जांच कर चुके होंगे।", note: "Deadline completion by noon" },
                    { id: "sum-m2", english: "We won't have cleared debt by end of this quarter.", hindi: "हम इस तिमाही के अंत तक कर्ज नहीं चुका चुके होंगे।", note: "Negative milestone projection" },
                    { id: "sum-m3", english: "Will team have presented proposal before client meeting?", hindi: "क्या मीटिंग से पहले टीम प्रस्ताव प्रस्तुत कर चुकी होगी?", note: "Interrogative event comparison" },
                    { id: "sum-m4", english: "She will have left before you arrive.", hindi: "तुम्हारे पहुँचने से पहले वह निकल चुकी होगी।", note: "Completed before another future event" },
                    { id: "sum-m5", english: "Where will they have constructed plant by 2030?", hindi: "वे 2030 तक संयंत्र कहाँ बना चुके होंगे?", note: "WH question with Where will...have V3" }
                ],
                hard: [
                    { id: "sum-h1", english: "Software engineers will have deployed update by midnight.", hindi: "सॉफ्टवेयर इंजीनियर आधी रात तक अपडेट तैनात कर चुके होंगे।", note: "Technical completion milestone" },
                    { id: "sum-h2", english: "Auditors won't have signed report before deadline.", hindi: "लेखा परीक्षक समय-सीमा से पहले रिपोर्ट पर हस्ताक्षर नहीं कर चुके होंगे।", note: "Formal professional negative" },
                    { id: "sum-h3", english: "Will rescue teams have evacuated villagers before cyclone hits?", hindi: "क्या चक्रवात आने से पहले बचाव दल ग्रामीणों को बाहर निकाल चुके होंगे?", note: "Emergency event comparison" },
                    { id: "sum-h4", english: "What security patch will engineers have implemented by midnight?", hindi: "इंजीनियर आधी रात तक क्या सुरक्षा पैच लागू कर चुके होंगे?", note: "Complex technical WH question" },
                    { id: "sum-h5", english: "Scientists will have published research findings by year end.", hindi: "वैज्ञानिक साल के अंत तक शोध निष्कर्ष प्रकाशित कर चुके होंगे।", note: "Target date achievement" }
                ]
            }
        },

        // 11. Practice Exercises / अभ्यास (120 Practice Sentences Total)
        exercises: {
            title: "Future Perfect Practice Sentences",
            titleHindi: "पूर्ण भविष्यत् काल — अभ्यास (120 Practice Sentences)",
            introduction: "Practice all 120 sentences across Positive, Negative, Interrogative, and WH Questions to master Future Perfect Tense.",
            introductionHindi: "Future Perfect Tense के 120 अभ्यास वाक्यों (सकारात्मक, नकारात्मक, प्रश्नवाचक एवं WH प्रश्न) के माध्यम से पूरा अभ्यास करें।",
            categories: []
        },

        // 12. Quiz Configuration / ज्ञान परीक्षा (12 Quiz Combinations)
        quiz: {
            title: "Future Perfect Quiz",
            titleHindi: "पूर्ण भविष्यत् काल — ज्ञान परीक्षा",
            questions: []
        }
    }
};

// Initialize categories referencing existing sections (120 Practice Sentences total)
futurePerfectLesson.sections.exercises.categories = [
    {
        id: "positive",
        title: "Positive Sentences Practice",
        titleHindi: "1. सकारात्मक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Positive Sentence",
        sentences: futurePerfectLesson.sections.positive.sentences
    },
    {
        id: "negative",
        title: "Negative Sentences Practice",
        titleHindi: "2. नकारात्मक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Negative Sentence",
        sentences: futurePerfectLesson.sections.negative.sentences
    },
    {
        id: "interrogative",
        title: "Interrogative Sentences Practice",
        titleHindi: "3. प्रश्नवाचक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Yes/No Question",
        sentences: futurePerfectLesson.sections.interrogative.sentences
    },
    {
        id: "whQuestions",
        title: "WH Questions Practice",
        titleHindi: "4. WH प्रश्न अभ्यास (30 Sentences)",
        typeLabel: "WH Question",
        sentences: futurePerfectLesson.sections.whQuestions.sentences
    }
];

/**
 * Get the complete Future Perfect lesson object
 * @returns {object}
 */
export function getFuturePerfectLesson() {
    return { ...futurePerfectLesson };
}

/**
 * Get a specific section of Future Perfect lesson data
 * @param {string} sectionName 
 * @returns {object|Array|null}
 */
export function getFuturePerfectSection(sectionName) {
    if (!sectionName || !futurePerfectLesson.sections) return null;
    return futurePerfectLesson.sections[sectionName] || null;
}
