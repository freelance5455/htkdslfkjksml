/**
 * Central Lesson Data for Simple Future Tense (सामान्य भविष्यत् काल)
 * Single Source of Truth for Simple Future Tense Module.
 * Follows proven reference architecture established in completed Present & Past Tenses.
 */

const simpleFutureLesson = {
    id: "simple-future",
    title: "Simple Future",
    titleHindi: "सामान्य भविष्यत् काल (Subject + will + V1)",
    description: "Learn Simple Future Tense in simple Hindi & English: Subject + will + V1 + Object.",

    sections: {
        // 1. Identification / पहचान और अवधारणा
        identification: {
            title: "Identification",
            titleHindi: "पहचान और अवधारणा (Identification & Concept)",
            english: "Simple Future Tense is used to express an action, event, decision, prediction, promise, or offer that will happen in the future.",
            hindi: "Simple Future Tense का प्रयोग भविष्य (Future) में होने वाले कार्यों, निर्णयों, भविष्यवाणियों, वादों या प्रस्तावों को व्यक्त करने के लिए किया जाता है।",
            hindiIdentityRule: "पहचान (Hindi Clues): वाक्य की मुख्य क्रिया के अंत में - गा, गी, गे (जैसे: करूँगा, करेगी, करेंगे, जाएगा, आएगी, होगा, होगी, होंगे) आता है।",
            points: [
                {
                    english: "The action will take place at a time later than now.",
                    hindi: "कार्य वर्तमान समय के बाद (भविष्य में) संपन्न होगा।"
                },
                {
                    english: "Auxiliary Verb: Use 'will' for ALL subjects (I, You, He, She, It, We, They, Singular, Plural).",
                    hindi: "सहायक क्रिया: सभी कर्ताओं के साथ केवल 'will' का प्रयोग होता है।"
                },
                {
                    english: "Main Verb: Always use V1 (Base Form of the verb) after 'will'. Never use V2 or V3.",
                    hindi: "मुख्य क्रिया: 'will' के बाद हमेशा V1 (Base Form) का प्रयोग किया जाता है। भूलकर भी V2 या V3 न लगाएं।"
                },
                {
                    english: "Common Future Time Signals: tomorrow, tonight, next week, next month, next year, soon, later, in the future, one day.",
                    hindi: "सामान्य भविष्यत् काल सूचक शब्द: tomorrow (कल), tonight (आज रात), next week (अगले सप्ताह), soon (शीघ्र), later (बाद में) आदि।"
                },
                {
                    english: "Context-Based: Time markers are helpful signals but not strictly mandatory when future context is clear.",
                    hindi: "संदर्भ-आधारित: समय सूचक शब्द सहायक हैं, लेकिन संदर्भ स्पष्ट होने पर इनका होना अनिवार्य नहीं है।"
                }
            ],
            comparison: {
                title: "Concept Comparison: Simple Present vs Simple Future vs Future Arrangement vs Going to",
                simplePresent: {
                    name: "Simple Present (सामान्य वर्तमान)",
                    formula: "Subject + V1 / V1+s",
                    concept: "Routine or daily habit (रोज़ का काम)",
                    example: "I go to office every day. (मैं रोज़ दफ़्तर जाता हूँ।)"
                },
                simpleFuture: {
                    name: "Simple Future (सामान्य भविष्यत्)",
                    formula: "Subject + will + V1",
                    concept: "Future action or decision (भविष्य का कार्य)",
                    example: "I will go to office tomorrow. (मैं कल दफ़्तर जाऊँगा।)"
                },
                presentContinuousFuture: {
                    name: "Present Continuous (Future Plan)",
                    formula: "Subject + am/is/are + V1+ing",
                    concept: "Planned future arrangement (पक्की योजना)",
                    example: "I am meeting the boss tomorrow. (मैं कल बॉस से मिल रहा हूँ।)"
                },
                goingToFuture: {
                    name: "Going to Future (इरादा / संकेत)",
                    formula: "Subject + am/is/are + going to + V1",
                    concept: "Prior intention or clear present evidence (इरादा या संकेत)",
                    example: "Look at the dark clouds! It is going to rain. (बारिश होने वाली है।)"
                }
            }
        },

        // 2. Uses & Scenarios / उपयोग और परिस्थितियाँ (Exactly 6 Major Uses)
        uses: {
            title: "Uses & Scenarios",
            titleHindi: "कब प्रयोग करें (6 मुख्य उपयोग)",
            intro: "Simple Future Tense is used for future decisions, instant decisions, predictions, promises, offers, and future facts.",
            introHindi: "Simple Future Tense का प्रयोग भविष्य के निर्णयों, तुरंत लिए गए निर्णयों, भविष्यवाणियों, वादों, प्रस्तावों और भविष्य के तथ्यों के लिए किया जाता है।",
            list: [
                {
                    title: "1. Future Decisions and Intentions",
                    titleHindi: "भविष्य के निर्णय और इरादे (Future Decisions)",
                    explanation: "Expresses planned or intended decisions about future actions.",
                    explanationHindi: "भविष्य में किए जाने वाले निर्णयों और इरादों को व्यक्त करने के लिए।",
                    whyUsed: "States what a person intends to do later.",
                    whyUsedHindi: "यह बताता है कि कोई व्यक्ति बाद में क्या करने वाला है।",
                    examples: [
                        { english: "I will call him tonight.", hindi: "मैं आज रात उसे फोन करूँगा।", note: "Decision for tonight" },
                        { english: "She will start her new job next Monday.", hindi: "वह अगले सोमवार से अपनी नई नौकरी शुरू करेगी।", note: "Future start date" },
                        { english: "They will visit Delhi next month.", hindi: "वे अगले महीने दिल्ली जाएँगे।", note: "Future travel plan" }
                    ]
                },
                {
                    title: "2. Instant Decisions at the Moment of Speaking",
                    titleHindi: "बोलते समय तुरंत लिया गया निर्णय (Instant Decisions)",
                    explanation: "Used when making a quick decision right at the time of speaking.",
                    explanationHindi: "बातचीत के दौरान उसी क्षण तुरंत निर्णय लेने के लिए।",
                    whyUsed: "Spontaneous response to a present situation.",
                    whyUsedHindi: "वर्तमान स्थिति पर तत्काल प्रतिक्रिया दिखाता है।",
                    examples: [
                        { english: "The phone is ringing. I will answer it.", hindi: "फोन बज रहा है। मैं इसे उठाऊँगा।", note: "Instant reaction to phone ring" },
                        { english: "It is cold outside. I will close the window.", hindi: "बाहर ठंड है। मैं खिड़की बंद कर दूँगा।", note: "Instant decision due to cold" },
                        { english: "You look tired. I will bring you a cup of tea.", hindi: "आप थके हुए लग रहे हैं। मैं आपके लिए एक कप चाय लाऊँगा।", note: "Instant offer of help" }
                    ]
                },
                {
                    title: "3. Predictions about the Future",
                    titleHindi: "भविष्यवाणियाँ और अनुमान (Predictions)",
                    explanation: "Used to express what we think, believe, or guess will happen in the future.",
                    explanationHindi: "भविष्य में क्या होगा, इस बारे में अपना अनुमान या विचार बताने के लिए।",
                    whyUsed: "Often used with words like 'think', 'believe', 'sure', 'probably', 'maybe'.",
                    whyUsedHindi: "अक्सर think, believe, sure, probably जैसे शब्दों के साथ प्रयोग होता है।",
                    examples: [
                        { english: "I think it will rain tomorrow.", hindi: "मुझे लगता है कि कल बारिश होगी।", note: "Prediction with 'I think'" },
                        { english: "They will probably win the match.", hindi: "वे शायद मैच जीतेंगे।", note: "Prediction with 'probably'" },
                        { english: "I am sure she will pass the exam.", hindi: "मुझे यकीन है कि वह परीक्षा पास करेगी।", note: "Confidence prediction with 'sure'" }
                    ]
                },
                {
                    title: "4. Promises and Commitments",
                    titleHindi: "वादे और प्रतिबद्धता (Promises)",
                    explanation: "Used to give a personal pledge or guarantee to someone.",
                    explanationHindi: "किसी को दिया गया व्यक्तिगत वादा या भरोसा व्यक्त करने के लिए।",
                    whyUsed: "Expresses reliability and solemn commitment.",
                    whyUsedHindi: "भरोसा और प्रतिबद्धता दर्शाता है।",
                    examples: [
                        { english: "I will help you with your project.", hindi: "मैं आपके प्रोजेक्ट में आपकी मदद करूँगा।", note: "Promise of assistance" },
                        { english: "I will not tell anyone your secret.", hindi: "मैं किसी को तुम्हारा राज़ नहीं बताऊँगा।", note: "Promise of secrecy" },
                        { english: "We will support you in difficult times.", hindi: "हम कठिन समय में आपका समर्थन करेंगे।", note: "Promise of support" }
                    ]
                },
                {
                    title: "5. Offers and Willingness",
                    titleHindi: "प्रस्ताव और तत्परता (Offers & Willingness)",
                    explanation: "Used when volunteering or offering to do something for someone.",
                    explanationHindi: "किसी के लिए स्वेच्छा से कुछ करने का प्रस्ताव रखने के लिए।",
                    whyUsed: "Shows helpful attitude and willingness.",
                    whyUsedHindi: "मदद करने की तत्परता और इच्छा दिखाता है।",
                    examples: [
                        { english: "I will carry your heavy bag.", hindi: "मैं आपका भारी बैग उठा दूँगा।", note: "Offer to carry bag" },
                        { english: "She will guide you through the venue.", hindi: "वह स्थल में आपका मार्गदर्शन करेगी।", note: "Offer of guidance" },
                        { english: "We will drive you to the airport.", hindi: "हम आपको हवाई अड्डे तक ले जाएँगे।", note: "Offer of transportation" }
                    ]
                },
                {
                    title: "6. Future Facts and Scheduled Events",
                    titleHindi: "भविष्य के तथ्य और तय घटनाएँ (Future Facts & Events)",
                    explanation: "Used to state certainty about future events based on timetables or natural order.",
                    explanationHindi: "भविष्य के ऐसे तथ्यों और घटनाओं को बताने के लिए जो समय-सारणी या प्राकृतिक नियम से निश्चित हैं।",
                    whyUsed: "States objective future reality.",
                    whyUsedHindi: "वस्तुनिष्ठ भविष्य की सच्चाई बताता है।",
                    examples: [
                        { english: "The meeting will start at 10 AM tomorrow.", hindi: "मीटिंग कल सुबह 10 बजे शुरू होगी।", note: "Scheduled event" },
                        { english: "The sun will rise at 6:15 AM tomorrow.", hindi: "कल सूर्योदय सुबह 6:15 बजे होगा।", note: "Natural future fact" },
                        { english: "He will turn twenty next month.", hindi: "वह अगले महीने बीस साल का हो जाएगा।", note: "Age fact" }
                    ]
                }
            ]
        },

        // 3. Sentence Structure & Formulas / वाक्य संरचना और सूत्र
        structure: {
            title: "Structure & Formulas",
            titleHindi: "वाक्य संरचना और सूत्र (Formulas)",
            intro: "Simple Future formulas use WILL + V1 for all subjects across Positive, Negative, Interrogative, and WH Questions.",
            introHindi: "Simple Future में सभी कर्ताओं के साथ WILL + V1 का प्रयोग किया जाता है।",
            formulas: {
                positive: {
                    name: "Positive Formula",
                    rule: "Subject + will + V1 + Object / Complement",
                    example: "She will complete the project tomorrow.",
                    breakdown: {
                        subject: "She",
                        aux: "will",
                        verb: "complete (V1)",
                        object: "the project",
                        time: "tomorrow"
                    }
                },
                negative: {
                    name: "Negative Formula",
                    rule: "Subject + will not (won't) + V1 + Object",
                    example: "She will not (won't) complete the project tomorrow.",
                    breakdown: {
                        subject: "She",
                        aux: "will not / won't",
                        verb: "complete (V1)",
                        object: "the project",
                        time: "tomorrow"
                    }
                },
                interrogative: {
                    name: "Interrogative Formula (Yes/No)",
                    rule: "Will + Subject + V1 + Object?",
                    example: "Will she complete the project tomorrow?",
                    breakdown: {
                        aux: "Will",
                        subject: "she",
                        verb: "complete (V1)",
                        object: "the project tomorrow?"
                    }
                },
                whQuestion: {
                    name: "WH Question Formula",
                    rule: "WH-word + will + Subject + V1 + Object?",
                    example: "When will she complete the project?",
                    breakdown: {
                        wh: "When",
                        aux: "will",
                        subject: "she",
                        verb: "complete (V1)",
                        object: "the project?"
                    }
                }
            }
        },

        // 4. Subject + Verb Rules / कर्ता-क्रिया नियम
        subjectVerbRules: {
            title: "Subject + Verb Rules",
            titleHindi: "कर्ता + क्रिया नियम (Golden Rule: ALL SUBJECTS ➔ WILL + V1)",
            goldenRule: "Golden Rule: Every subject (I, You, He, She, It, We, They, Singular, Plural) takes WILL + V1 in Simple Future.",
            goldenRuleHindi: "स्वर्ण नियम: Simple Future Tense में सभी कर्ताओं (I, You, He, She, It, We, They, एकवचन, बहुवचन) के साथ केवल WILL + V1 का प्रयोग होता है।",
            
            table: [
                { subject: "I", aux: "will", verb: "V1 (go / work / study)", example: "I will study." },
                { subject: "You", aux: "will", verb: "V1 (go / work / study)", example: "You will study." },
                { subject: "He", aux: "will", verb: "V1 (go / work / study)", example: "He will study." },
                { subject: "She", aux: "will", verb: "V1 (go / work / study)", example: "She will study." },
                { subject: "It", aux: "will", verb: "V1 (rain / work)", example: "It will rain." },
                { subject: "We", aux: "will", verb: "V1 (go / work / study)", example: "We will study." },
                { subject: "They", aux: "will", verb: "V1 (go / work / study)", example: "They will study." },
                { subject: "Singular Name (Rahul)", aux: "will", verb: "V1 (go / work / study)", example: "Rahul will study." },
                { subject: "Plural Noun (Students)", aux: "will", verb: "V1 (go / work / study)", example: "Students will study." }
            ],

            v1Rules: {
                title: "Will + V1 (Base Form) Rule & Note on 'Shall'",
                titleHindi: "Will + V1 नियम और 'Shall' पर संक्षिप्त टिप्पणी",
                intro: "After 'will', the main verb MUST remain in V1 (Base Form). Never use V2, V3, or V1+ing.",
                introHindi: "'will' के बाद मुख्य क्रिया हमेशा V1 रूप में रहती है। V2, V3 या V1+ing न लगाएं।",
                correctExamples: "✅ Correct: I will go | She will come | They will write | He will pass",
                incorrectExamples: "❌ Incorrect: I will went | She will came | They will written | He will passing",
                shallNote: "💡 Reference Note on Shall: Traditional grammar used 'shall' with I and We, but modern standard English commonly uses 'will' for all subjects. (पारंपरिक व्याकरण में I/We के साथ 'shall' का प्रयोग होता था, लेकिन आधुनिक मानक अंग्रेजी में सभी कर्ताओं के लिए 'will' का प्रयोग सर्वमान्य है।)"
            }
        },

        // 5. Positive Sentences / सकारात्मक वाक्य (30 Items)
        positive: {
            title: "Positive Sentences",
            titleHindi: "सकारात्मक वाक्य (Subject + will + V1 + Object)",
            formula: "Subject + will + V1 + Object/Complement",
            explanation: "Expresses positive future actions, plans, predictions, and promises.",
            explanationHindi: "सकारात्मक वाक्यों में सभी कर्ताओं के साथ 'will' और मुख्य क्रिया का V1 रूप लगाएं।",
            
            sentences: {
                easy: [
                    { id: "pos-e1", english: "I will finish the report tonight.", hindi: "मैं आज रात रिपोर्ट पूरी करूँगा।", subject: "I", aux: "will", verb: "finish", object: "the report tonight" },
                    { id: "pos-e2", english: "She will join the meeting tomorrow.", hindi: "वह कल मीटिंग में शामिल होगी।", subject: "She", aux: "will", verb: "join", object: "the meeting tomorrow" },
                    { id: "pos-e3", english: "They will visit Delhi next week.", hindi: "वे अगले सप्ताह दिल्ली जाएँगे।", subject: "They", aux: "will", verb: "visit", object: "Delhi next week" },
                    { id: "pos-e4", english: "We will learn English together.", hindi: "हम एक साथ अंग्रेजी सीखेंगे।", subject: "We", aux: "will", verb: "learn", object: "English together" },
                    { id: "pos-e5", english: "He will buy a new smartphone soon.", hindi: "वह जल्द ही एक नया स्मार्टफोन खरीदेगा।", subject: "He", aux: "will", verb: "buy", object: "a new smartphone soon" },
                    { id: "pos-e6", english: "Rahul will call you in the evening.", hindi: "राहुल आपको शाम को फोन करेगा।", subject: "Rahul", aux: "will", verb: "call", object: "you in the evening" },
                    { id: "pos-e7", english: "You will pass the examination easily.", hindi: "आप आसानी से परीक्षा पास कर लेंगे।", subject: "You", aux: "will", verb: "pass", object: "the examination easily" },
                    { id: "pos-e8", english: "It will rain tomorrow afternoon.", hindi: "कल दोपहर बारिश होगी।", subject: "It", aux: "will", verb: "rain", object: "tomorrow afternoon" },
                    { id: "pos-e9", english: "My mother will cook special dinner tonight.", hindi: "मेरी माँ आज रात विशेष भोजन बनाएगी।", subject: "My mother", aux: "will", verb: "cook", object: "special dinner tonight" },
                    { id: "pos-e10", english: "The train will arrive at 8 PM.", hindi: "ट्रेन रात 8 बजे पहुँचेगी।", subject: "The train", aux: "will", verb: "arrive", object: "at 8 PM" }
                ],
                medium: [
                    { id: "pos-m1", english: "The doctor will examine the patient tomorrow morning.", hindi: "डॉक्टर कल सुबह मरीज की जांच करेंगे।", subject: "The doctor", aux: "will", verb: "examine", object: "the patient tomorrow morning" },
                    { id: "pos-m2", english: "She will launch her online course next month.", hindi: "वह अगले महीने अपना ऑनलाइन कोर्स लॉन्च करेगी।", subject: "She", aux: "will", verb: "launch", object: "her online course next month" },
                    { id: "pos-m3", english: "The team will present the project proposal to the client.", hindi: "टीम ग्राहक को प्रोजेक्ट प्रस्ताव प्रस्तुत करेगी।", subject: "The team", aux: "will", verb: "present", object: "project proposal to client" },
                    { id: "pos-m4", english: "I will submit the tax documents before Friday.", hindi: "मैं शुक्रवार से पहले टैक्स दस्तावेज जमा करूँगा।", subject: "I", aux: "will", verb: "submit", object: "tax documents before Friday" },
                    { id: "pos-m5", english: "They will open the new branch in January.", hindi: "वे जनवरी में नई शाखा खोलेंगे।", subject: "They", aux: "will", verb: "open", object: "the new branch in January" },
                    { id: "pos-m6", english: "The teacher will explain the new chapter tomorrow.", hindi: "शिक्षक कल नया अध्याय समझाएंगे।", subject: "The teacher", aux: "will", verb: "explain", object: "the new chapter tomorrow" },
                    { id: "pos-m7", english: "We will book the holiday tickets this weekend.", hindi: "हम इस सप्ताहांत छुट्टियों के टिकट बुक करेंगे।", subject: "We", aux: "will", verb: "book", object: "holiday tickets this weekend" },
                    { id: "pos-m8", english: "He will repair the computer system by evening.", hindi: "वह शाम तक कंप्यूटर सिस्टम की मरम्मत कर देगा।", subject: "He", aux: "will", verb: "repair", object: "computer system by evening" },
                    { id: "pos-m9", english: "The passengers will board the flight at gate four.", hindi: "यात्री गेट नंबर चार पर विमान में सवार होंगे।", subject: "The passengers", aux: "will", verb: "board", object: "the flight at gate four" },
                    { id: "pos-m10", english: "She will receive her certificate at the convocation.", hindi: "उसे दीक्षांत समारोह में प्रमाण पत्र मिलेगा।", subject: "She", aux: "will", verb: "receive", object: "her certificate at convocation" }
                ],
                hard: [
                    { id: "pos-h1", english: "The software engineers will deploy the system security patch tonight.", hindi: "सॉफ्टवेयर इंजीनियर आज रात सिस्टम सुरक्षा पैच तैनात करेंगे।", subject: "The software engineers", aux: "will", verb: "deploy", object: "system security patch tonight" },
                    { id: "pos-h2", english: "The board of directors will approve the annual budget next week.", hindi: "निदेशक मंडल अगले सप्ताह वार्षिक बजट को मंजूरी देगा।", subject: "The board of directors", aux: "will", verb: "approve", object: "annual budget next week" },
                    { id: "pos-h3", english: "Scientists will publish the research findings in international journal.", hindi: "वैज्ञानिक अंतर्राष्ट्रीय पत्रिका में शोध निष्कर्ष प्रकाशित करेंगे।", subject: "Scientists", aux: "will", verb: "publish", object: "findings in international journal" },
                    { id: "pos-h4", english: "The municipality will construct a new bridge over the river.", hindi: "नगरपालिका नदी पर नए पुल का निर्माण करेगी।", subject: "The municipality", aux: "will", verb: "construct", object: "a new bridge over river" },
                    { id: "pos-h5", english: "The financial auditors will inspect the balance sheets next Monday.", hindi: "वित्तीय लेखा परीक्षक अगले सोमवार को बैलेंस शीट का निरीक्षण करेंगे।", subject: "The financial auditors", aux: "will", verb: "inspect", object: "balance sheets next Monday" },
                    { id: "pos-h6", english: "The authorities will evacuate low-lying coastal areas before storm.", hindi: "अधिकारी तूफान से पहले तटीय निचले इलाकों को खाली कराएंगे।", subject: "The authorities", aux: "will", verb: "evacuate", object: "coastal areas before storm" },
                    { id: "pos-h7", english: "She will complete her master degree thesis by end of semester.", hindi: "वह सेमेस्टर के अंत तक अपने मास्टर डिग्री का शोधप्रबंध पूरा करेगी।", subject: "She", aux: "will", verb: "complete", object: "her thesis by end of semester" },
                    { id: "pos-h8", english: "The high court will deliver the landmark verdict on Friday.", hindi: "उच्च न्यायालय शुक्रवार को ऐतिहासिक फैसला सुनाएगा।", subject: "The high court", aux: "will", verb: "deliver", object: "landmark verdict on Friday" },
                    { id: "pos-h9", english: "The research lab will patent the artificial intelligence algorithm.", hindi: "अनुसंधान प्रयोगशाला कृत्रिम बुद्धिमत्ता एल्गोरिदम का पेटेंट कराएगी।", subject: "The research lab", aux: "will", verb: "patent", object: "AI algorithm" },
                    { id: "pos-h10", english: "The government will implement economic reforms in upcoming budget.", hindi: "सरकार आगामी बजट में आर्थिक सुधारों को लागू करेगी।", subject: "The government", aux: "will", verb: "implement", object: "economic reforms in upcoming budget" }
                ]
            }
        },

        // 6. Negative Sentences / नकारात्मक वाक्य (30 Items)
        negative: {
            title: "Negative Sentences",
            titleHindi: "नकारात्मक वाक्य (Subject + will not / won't + V1)",
            formula: "Subject + will not (won't) + V1 + Object",
            explanation: "Use 'will not' or contraction 'won't' followed by V1 to state an action will not happen in the future.",
            explanationHindi: "नकारात्मक वाक्यों में 'will not' या उसका संक्षिप्त रूप 'won't' लगाकर मुख्य क्रिया का V1 रूप लगाएं।",
            
            sentences: {
                easy: [
                    { id: "neg-e1", english: "I will not forget your kindness.", hindi: "मैं आपकी दयालुता को नहीं भूलूँगा।", subject: "I", aux: "will not", verb: "forget", object: "your kindness" },
                    { id: "neg-e2", english: "She won't attend the party tonight.", hindi: "वह आज रात पार्टी में शामिल नहीं होगी।", subject: "She", aux: "won't", verb: "attend", object: "the party tonight" },
                    { id: "neg-e3", english: "They will not arrive late.", hindi: "वे देर से नहीं पहुँचेंगे।", subject: "They", aux: "will not", verb: "arrive", object: "late" },
                    { id: "neg-e4", english: "We won't waste our precious time.", hindi: "हम अपना कीमती समय बर्बाद नहीं करेंगे।", subject: "We", aux: "won't", verb: "waste", object: "our precious time" },
                    { id: "neg-e5", english: "He will not sell his old vehicle.", hindi: "वह अपना पुराना वाहन नहीं बेचेगा।", subject: "He", aux: "will not", verb: "sell", object: "his old vehicle" },
                    { id: "neg-e6", english: "Rahul won't accept this proposal.", hindi: "राहुल इस प्रस्ताव को स्वीकार नहीं करेगा।", subject: "Rahul", aux: "won't", verb: "accept", object: "this proposal" },
                    { id: "neg-e7", english: "You will not regret this decision.", hindi: "आपको इस फैसले पर पछतावा नहीं होगा।", subject: "You", aux: "will not", verb: "regret", object: "this decision" },
                    { id: "neg-e8", english: "It won't rain today.", hindi: "आज बारिश नहीं होगी।", subject: "It", aux: "won't", verb: "rain", object: "today" },
                    { id: "neg-e9", english: "She will not tolerate disrespect.", hindi: "वह अनादर बर्दाश्त नहीं करेगी।", subject: "She", aux: "will not", verb: "tolerate", object: "disrespect" },
                    { id: "neg-e10", english: "They won't break their promise.", hindi: "वे अपना वादा नहीं तोड़ेंगे।", subject: "They", aux: "won't", verb: "break", object: "their promise" }
                ],
                medium: [
                    { id: "neg-m1", english: "The doctor will not perform surgery without consent.", hindi: "डॉक्टर बिना सहमति के सर्जरी नहीं करेंगे।", subject: "The doctor", aux: "will not", verb: "perform", object: "surgery without consent" },
                    { id: "neg-m2", english: "She won't reveal confidential company information.", hindi: "वह गोपनीय कंपनी की जानकारी उजागर नहीं करेगी।", subject: "She", aux: "won't", verb: "reveal", object: "confidential information" },
                    { id: "neg-m3", english: "The team will not compromise on product quality.", hindi: "टीम उत्पाद की गुणवत्ता से समझौता नहीं करेगी।", subject: "The team", aux: "will not", verb: "compromise", object: "on product quality" },
                    { id: "neg-m4", english: "We won't extend the deadline further.", hindi: "हम समय-सीमा को और नहीं बढ़ाएंगे।", subject: "We", aux: "won't", verb: "extend", object: "the deadline further" },
                    { id: "neg-m5", english: "He will not approve the budget without verification.", hindi: "वह सत्यापन के बिना बजट को मंजूरी नहीं देगा।", subject: "He", aux: "will not", verb: "approve", object: "budget without verification" },
                    { id: "neg-m6", english: "The students won't miss the special lecture.", hindi: "छात्र विशेष व्याख्यान को नहीं छोड़ेंगे।", subject: "The students", aux: "won't", verb: "miss", object: "the special lecture" },
                    { id: "neg-m7", english: "She will not ignore customer feedback.", hindi: "वह ग्राहकों की प्रतिक्रिया को नज़रअंदाज़ नहीं करेगी।", subject: "She", aux: "will not", verb: "ignore", object: "customer feedback" },
                    { id: "neg-m8", english: "The bank won't charge extra fees on online transactions.", hindi: "बैंक ऑनलाइन लेनदेन पर अतिरिक्त शुल्क नहीं लेगा।", subject: "The bank", aux: "won't", verb: "charge", object: "extra fees on transactions" },
                    { id: "neg-m9", english: "They will not cancel the scheduled conference.", hindi: "वे निर्धारित सम्मेलन को रद्द नहीं करेंगे।", subject: "They", aux: "will not", verb: "cancel", object: "the scheduled conference" },
                    { id: "neg-m10", english: "I won't repeat this mistake again.", hindi: "मैं इस गलती को दोबारा नहीं दोहराऊँगा।", subject: "I", aux: "won't", verb: "repeat", object: "this mistake again" }
                ],
                hard: [
                    { id: "neg-h1", english: "The software engineers will not deploy untested code to production server.", hindi: "सॉफ्टवेयर इंजीनियर प्रोडक्शन सर्वर पर अप्रमाणित कोड तैनात नहीं करेंगे।", subject: "The software engineers", aux: "will not", verb: "deploy", object: "untested code to server" },
                    { id: "neg-h2", english: "The board of directors won't sanction unapproved financial expenditure.", hindi: "निदेशक मंडल गैर-मंजूर वित्तीय व्यय को मंजूरी नहीं देगा।", subject: "The board of directors", aux: "won't", verb: "sanction", object: "unapproved expenditure" },
                    { id: "neg-h3", english: "The municipality will not permit unauthorized building construction.", hindi: "नगरपालिका अनधिकृत भवन निर्माण की अनुमति नहीं देगी।", subject: "The municipality", aux: "will not", verb: "permit", object: "unauthorized construction" },
                    { id: "neg-h4", english: "Research scholars won't publish unverified experimental data.", hindi: "शोध विद्वान असत्यापित प्रयोगात्मक डेटा प्रकाशित नहीं करेंगे।", subject: "Research scholars", aux: "won't", verb: "publish", object: "unverified experimental data" },
                    { id: "neg-h5", english: "The security team will not allow entry without valid credentials.", hindi: "सुरक्षा टीम वैध क्रेडेंशियल्स के बिना प्रवेश की अनुमति नहीं देगी।", subject: "The security team", aux: "will not", verb: "allow", object: "entry without valid credentials" },
                    { id: "neg-h6", english: "The airline won't operate flights during severe weather conditions.", hindi: "खराब मौसम के दौरान एयरलाइन उड़ानें संचालित नहीं करेगी।", subject: "The airline", aux: "won't", verb: "operate", object: "flights during severe weather" },
                    { id: "neg-h7", english: "The company will not share user data with third-party vendors.", hindi: "कंपनी तीसरे पक्ष के विक्रेताओं के साथ उपयोगकर्ता डेटा साझा नहीं करेगी।", subject: "The company", aux: "will not", verb: "share", object: "user data with third parties" },
                    { id: "neg-h8", english: "Investigators won't close the case without conclusive evidence.", hindi: "जांचकर्ता निर्णायक सबूत के बिना मामला बंद नहीं करेंगे।", subject: "Investigators", aux: "won't", verb: "close", object: "case without conclusive evidence" },
                    { id: "neg-h9", english: "The government will not compromise national security interest.", hindi: "सरकार राष्ट्रीय सुरक्षा हित से समझौता नहीं करेगी।", subject: "The government", aux: "will not", verb: "compromise", object: "national security interest" },
                    { id: "neg-h10", english: "The contractor won't delay the road construction project.", hindi: "ठेकेदार सड़क निर्माण परियोजना में देरी नहीं करेगा।", subject: "The contractor", aux: "won't", verb: "delay", object: "road construction project" }
                ]
            }
        },

        // 7. Interrogative Sentences / प्रश्नवाचक वाक्य (30 Items)
        interrogative: {
            title: "Interrogative Sentences",
            titleHindi: "प्रश्नवाचक वाक्य (Will + Subject + V1 + Object?)",
            formula: "Will + Subject + V1 + Object?",
            explanation: "Start with WILL followed by Subject and V1 for Yes/No future questions.",
            explanationHindi: "प्रश्नवाचक वाक्यों में 'Will' से शुरुआत करें, फिर कर्ता और क्रिया का V1 रूप लगाएं।",
            
            sentences: {
                easy: [
                    { id: "int-e1", english: "Will you help me with this task?", hindi: "क्या आप इस कार्य में मेरी मदद करेंगे?", subject: "you", aux: "Will", verb: "help", object: "me with this task" },
                    { id: "int-e2", english: "Will she come to school tomorrow?", hindi: "क्या वह कल स्कूल आएगी?", subject: "she", aux: "Will", verb: "come", object: "to school tomorrow" },
                    { id: "int-e3", english: "Will they finish the work on time?", hindi: "क्या वे समय पर काम पूरा करेंगे?", subject: "they", aux: "Will", verb: "finish", object: "the work on time" },
                    { id: "int-e4", english: "Will we attend the seminar tomorrow?", hindi: "क्या हम कल सेमिनार में शामिल होंगे?", subject: "we", aux: "Will", verb: "attend", object: "the seminar tomorrow" },
                    { id: "int-e5", english: "Will he buy the car this week?", hindi: "क्या वह इस सप्ताह कार खरीदेगा?", subject: "he", aux: "Will", verb: "buy", object: "the car this week" },
                    { id: "int-e6", english: "Will Rahul call you tonight?", hindi: "क्या राहुल आपको आज रात फोन करेगा?", subject: "Rahul", aux: "Will", verb: "call", object: "you tonight" },
                    { id: "int-e7", english: "Will it rain in the evening?", hindi: "क्या शाम को बारिश होगी?", subject: "it", aux: "Will", verb: "rain", object: "in the evening" },
                    { id: "int-e8", english: "Will the train arrive on schedule?", hindi: "क्या ट्रेन समय पर पहुँचेगी?", subject: "the train", aux: "Will", verb: "arrive", object: "on schedule" },
                    { id: "int-e9", english: "Will she cook dinner for guests?", hindi: "क्या वह मेहमानों के लिए खाना बनाएगी?", subject: "she", aux: "Will", verb: "cook", object: "dinner for guests" },
                    { id: "int-e10", english: "Will they lock the gates at night?", hindi: "क्या वे रात में गेट बंद करेंगे?", subject: "they", aux: "Will", verb: "lock", object: "the gates at night" }
                ],
                medium: [
                    { id: "int-m1", english: "Will the doctor examine the patient today?", hindi: "क्या डॉक्टर आज मरीज की जांच करेंगे?", subject: "the doctor", aux: "Will", verb: "examine", object: "the patient today" },
                    { id: "int-m2", english: "Will she launch her new book next month?", hindi: "क्या वह अगले महीने अपनी नई किताब लॉन्च करेगी?", subject: "she", aux: "Will", verb: "launch", object: "her new book next month" },
                    { id: "int-m3", english: "Will the team present the project proposal?", hindi: "क्या टीम प्रोजेक्ट प्रस्ताव प्रस्तुत करेगी?", subject: "the team", aux: "Will", verb: "present", object: "the project proposal" },
                    { id: "int-m4", english: "Will you submit the application before deadline?", hindi: "क्या आप समय-सीमा से पहले आवेदन जमा करेंगे?", subject: "you", aux: "Will", verb: "submit", object: "application before deadline" },
                    { id: "int-m5", english: "Will they open a new office branch in Mumbai?", hindi: "क्या वे मुंबई में एक नई कार्यालय शाखा खोलेंगे?", subject: "they", aux: "Will", verb: "open", object: "new office branch in Mumbai" },
                    { id: "int-m6", english: "Will the teacher explain the lesson again?", hindi: "क्या शिक्षक पाठ दोबारा समझाएंगे?", subject: "the teacher", aux: "Will", verb: "explain", object: "the lesson again" },
                    { id: "int-m7", english: "Will we book hotel rooms in advance?", hindi: "क्या हम पहले से होटल के कमरे बुक करेंगे?", subject: "we", aux: "Will", verb: "book", object: "hotel rooms in advance" },
                    { id: "int-m8", english: "Will he repair the computer system today?", hindi: "क्या वह आज कंप्यूटर सिस्टम की मरम्मत करेगा?", subject: "he", aux: "Will", verb: "repair", object: "computer system today" },
                    { id: "int-m9", english: "Will the passengers board the flight soon?", hindi: "क्या यात्री जल्द ही विमान में सवार होंगे?", subject: "the passengers", aux: "Will", verb: "board", object: "the flight soon" },
                    { id: "int-m10", english: "Will she receive her certificate tomorrow?", hindi: "क्या उसे कल अपना प्रमाण पत्र मिलेगा?", subject: "she", aux: "Will", verb: "receive", object: "her certificate tomorrow" }
                ],
                hard: [
                    { id: "int-h1", english: "Will software engineers deploy the security patch tonight?", hindi: "क्या सॉफ्टवेयर इंजीनियर आज रात सुरक्षा पैच तैनात करेंगे?", subject: "software engineers", aux: "Will", verb: "deploy", object: "security patch tonight" },
                    { id: "int-h2", english: "Will the board of directors sanction the annual budget?", hindi: "क्या निदेशक मंडल वार्षिक बजट को मंजूरी देगा?", subject: "the board of directors", aux: "Will", verb: "sanction", object: "the annual budget" },
                    { id: "int-h3", english: "Will scientists publish their research findings in international journal?", hindi: "क्या वैज्ञानिक अंतर्राष्ट्रीय पत्रिका में अपने शोध निष्कर्ष प्रकाशित करेंगे?", subject: "scientists", aux: "Will", verb: "publish", object: "findings in journal" },
                    { id: "int-h4", english: "Will municipality construct a new bridge over the river?", hindi: "क्या नगरपालिका नदी पर नए पुल का निर्माण करेगी?", subject: "municipality", aux: "Will", verb: "construct", object: "new bridge over river" },
                    { id: "int-h5", english: "Will financial auditors inspect the company accounts?", hindi: "क्या वित्तीय लेखा परीक्षक कंपनी के खातों का निरीक्षण करेंगे?", subject: "financial auditors", aux: "Will", verb: "inspect", object: "company accounts" },
                    { id: "int-h6", english: "Will authorities evacuate residents before cyclone hits?", hindi: "क्या चक्रवात आने से पहले अधिकारी निवासियों को बाहर निकालेंगे?", subject: "authorities", aux: "Will", verb: "evacuate", object: "residents before cyclone" },
                    { id: "int-h7", english: "Will she complete her master degree thesis this semester?", hindi: "क्या वह इस सेमेस्टर में अपने मास्टर डिग्री का शोधप्रबंध पूरा करेगी?", subject: "she", aux: "Will", verb: "complete", object: "thesis this semester" },
                    { id: "int-h8", english: "Will the high court deliver the verdict on Friday?", hindi: "क्या उच्च न्यायालय शुक्रवार को फैसला सुनाएगा?", subject: "the high court", aux: "Will", verb: "deliver", object: "verdict on Friday" },
                    { id: "int-h9", english: "Will research lab patent the medical innovation?", hindi: "क्या अनुसंधान प्रयोगशाला चिकित्सा नवाचार का पेटेंट कराएगी?", subject: "research lab", aux: "Will", verb: "patent", object: "medical innovation" },
                    { id: "int-h10", english: "Will government announce economic relief package before election?", hindi: "क्या सरकार चुनाव से पहले आर्थिक राहत पैकेज की घोषणा करेगी?", subject: "government", aux: "Will", verb: "announce", object: "relief package before election" }
                ]
            }
        },

        // 8. WH Questions / WH प्रश्न (30 Items)
        whQuestions: {
            title: "WH Questions",
            titleHindi: "WH प्रश्न (WH-word + will + Subject + V1 + Object?)",
            formula: "WH-word + will + Subject + V1 + Object?",
            explanation: "Place WH question word (When, Where, Why, What, Who, How) before WILL + Subject + V1.",
            explanationHindi: "WH प्रश्नों में WH-शब्द (जैसे When, What, Where) के तुरंत बाद 'will', कर्ता और V1 लगाएं।",
            
            sentences: {
                easy: [
                    { id: "wh-e1", english: "When will you arrive at the station?", hindi: "आप स्टेशन कब पहुँचेंगे?", subject: "you", aux: "will", verb: "arrive", object: "at the station", whWord: "When" },
                    { id: "wh-e2", english: "Where will she stay in Delhi?", hindi: "वह दिल्ली में कहाँ रुकेगी?", subject: "she", aux: "will", verb: "stay", object: "in Delhi", whWord: "Where" },
                    { id: "wh-e3", english: "Why will they leave the meeting early?", hindi: "वे बैठक जल्दी क्यों छोड़ कर जाएँगे?", subject: "they", aux: "will", verb: "leave", object: "the meeting early", whWord: "Why" },
                    { id: "wh-e4", english: "What will you do tomorrow?", hindi: "आप कल क्या करेंगे?", subject: "you", aux: "will", verb: "do", object: "tomorrow", whWord: "What" },
                    { id: "wh-e5", english: "Who will come to the event tomorrow?", hindi: "कल कार्यक्रम में कौन आएगा?", subject: "Who", aux: "will", verb: "come", object: "to event tomorrow", whWord: "Who" },
                    { id: "wh-e6", english: "Which book will Rahul buy from store?", hindi: "राहुल स्टोर से कौन सी किताब खरीदेगा?", subject: "Rahul", aux: "will", verb: "buy", object: "from store", whWord: "Which book" },
                    { id: "wh-e7", english: "How will she solve this complex issue?", hindi: "वह इस जटिल मुद्दे को कैसे हल करेगी?", subject: "she", aux: "will", verb: "solve", object: "this complex issue", whWord: "How" },
                    { id: "wh-e8", english: "Whose car will they borrow for the trip?", hindi: "वे यात्रा के लिए किसकी कार उधार लेंगे?", subject: "they", aux: "will", verb: "borrow", object: "for the trip", whWord: "Whose car" },
                    { id: "wh-e9", english: "Why will the flight delay today?", hindi: "आज उड़ान में देरी क्यों होगी?", subject: "the flight", aux: "will", verb: "delay", object: "today", whWord: "Why" },
                    { id: "wh-e10", english: "Where will we park our vehicle?", hindi: "हम अपना वाहन कहाँ खड़ा करेंगे?", subject: "we", aux: "will", verb: "park", object: "our vehicle", whWord: "Where" }
                ],
                medium: [
                    { id: "wh-m1", english: "What will the doctor suggest for treatment?", hindi: "डॉक्टर इलाज के लिए क्या सुझाव देंगे?", subject: "the doctor", aux: "will", verb: "suggest", object: "for treatment", whWord: "What" },
                    { id: "wh-m2", english: "Why will she resign from her post?", hindi: "वह अपने पद से इस्तीफा क्यों देगी?", subject: "she", aux: "will", verb: "resign", object: "from her post", whWord: "Why" },
                    { id: "wh-m3", english: "How will the team achieve target this quarter?", hindi: "टीम इस तिमाही में लक्ष्य कैसे हासिल करेगी?", subject: "the team", aux: "will", verb: "achieve", object: "target this quarter", whWord: "How" },
                    { id: "wh-m4", english: "Where will they set up new manufacturing plant?", hindi: "वे नया विनिर्माण संयंत्र कहाँ स्थापित करेंगे?", subject: "they", aux: "will", verb: "set up", object: "new manufacturing plant", whWord: "Where" },
                    { id: "wh-m5", english: "When will the manager approve leave applications?", hindi: "मैनेजर छुट्टी के आवेदनों को कब मंजूरी देगा?", subject: "the manager", aux: "will", verb: "approve", object: "leave applications", whWord: "When" },
                    { id: "wh-m6", english: "Which candidate will win the election?", hindi: "कौन सा उम्मीदवार चुनाव जीतेगा?", subject: "Which candidate", aux: "will", verb: "win", object: "the election", whWord: "Which candidate" },
                    { id: "wh-m7", english: "How much money will he invest in stocks?", hindi: "वह शेयरों में कितना पैसा निवेश करेगा?", subject: "he", aux: "will", verb: "invest", object: "in stocks", whWord: "How much money" },
                    { id: "wh-m8", english: "Why will students protest against new rules?", hindi: "छात्र नए नियमों का विरोध क्यों करेंगे?", subject: "students", aux: "will", verb: "protest", object: "against new rules", whWord: "Why" },
                    { id: "wh-m9", english: "Who will design company new website?", hindi: "कंपनी की नई वेबसाइट कौन डिजाइन करेगा?", subject: "Who", aux: "will", verb: "design", object: "company new website", whWord: "Who" },
                    { id: "wh-m10", english: "Where will she store official documents?", hindi: "वह आधिकारिक दस्तावेज कहाँ संग्रहीत करेगी?", subject: "she", aux: "will", verb: "store", object: "official documents", whWord: "Where" }
                ],
                hard: [
                    { id: "wh-h1", english: "What security features will engineers implement in update?", hindi: "इंजीनियर अपडेट में क्या सुरक्षा सुविधाएं लागू करेंगे?", subject: "engineers", aux: "will", verb: "implement", object: "in update", whWord: "What security features" },
                    { id: "wh-h2", english: "Why will board of directors reject proposal?", hindi: "निदेशक मंडल प्रस्ताव को क्यों खारिज करेगा?", subject: "board of directors", aux: "will", verb: "reject", object: "proposal", whWord: "Why" },
                    { id: "wh-h3", english: "How will scientists synthesize the compound?", hindi: "वैज्ञानिक यौगिक का संश्लेषण कैसे करेंगे?", subject: "scientists", aux: "will", verb: "synthesize", object: "the compound", whWord: "How" },
                    { id: "wh-h4", english: "Where will authorities establish relief camps?", hindi: "अधिकारी राहत शिविर कहाँ स्थापित करेंगे?", subject: "authorities", aux: "will", verb: "establish", object: "relief camps", whWord: "Where" },
                    { id: "wh-h5", english: "When will auditor present audit report?", hindi: "अंकेक्षक ऑडिट रिपोर्ट कब प्रस्तुत करेगा?", subject: "auditor", aux: "will", verb: "present", object: "audit report", whWord: "When" },
                    { id: "wh-h6", english: "Which policies will government amend in budget?", hindi: "सरकार बजट में किन नीतियों में संशोधन करेगी?", subject: "government", aux: "will", verb: "amend", object: "in budget", whWord: "Which policies" },
                    { id: "wh-h7", english: "How many delegates will attend global conference?", hindi: "वैश्विक सम्मेलन में कितने प्रतिनिधि शामिल होंगे?", subject: "delegates", aux: "will", verb: "attend", object: "global conference", whWord: "How many delegates" },
                    { id: "wh-h8", english: "Why will tribunal review previous judgment?", hindi: "न्यायाधिकरण पिछले फैसले की समीक्षा क्यों करेगा?", subject: "tribunal", aux: "will", verb: "review", object: "previous judgment", whWord: "Why" },
                    { id: "wh-h9", english: "Whose application will committee select for grant?", hindi: "समिति अनुदान के लिए किसका आवेदन चुनेगी?", subject: "committee", aux: "will", verb: "select", object: "for grant", whWord: "Whose application" },
                    { id: "wh-h10", english: "Where will research team conduct clinical trials?", hindi: "शोध टीम नैदानिक परीक्षण कहाँ आयोजित करेगी?", subject: "research team", aux: "will", verb: "conduct", object: "clinical trials", whWord: "Where" }
                ]
            }
        },

        // 9. Common Mistakes & Corrections / सामान्य गलतियाँ (At least 15 Items)
        commonMistakes: {
            title: "Common Mistakes",
            titleHindi: "सामान्य गलतियाँ और सुधार (Common Mistakes & Corrections)",
            intro: "Avoid these 15 common errors when forming Simple Future Tense sentences.",
            introHindi: "Simple Future Tense का प्रयोग करते समय इन 15 सामान्य गलतियों से बचें।",
            mistakes: [
                {
                    wrong: "I will went there tomorrow.",
                    correct: "I will go there tomorrow.",
                    why: "After 'will', always use V1 (go), never V2 (went).",
                    whyHindi: "will के बाद हमेशा V1 (go) का प्रयोग होता है, V2 (went) का नहीं।"
                },
                {
                    wrong: "She will comes tomorrow.",
                    correct: "She will come tomorrow.",
                    why: "Do not add '-s' or '-es' to the verb after 'will'. Use plain V1 (come).",
                    whyHindi: "will के बाद क्रिया में -s/-es न जोड़ें, केवल V1 (come) लगाएं।"
                },
                {
                    wrong: "They will written the letter.",
                    correct: "They will write the letter.",
                    why: "V3 (written) cannot follow 'will' in Simple Future active voice. Use V1 (write).",
                    whyHindi: "Simple Future active में will के बाद V3 (written) नहीं, V1 (write) आता है।"
                },
                {
                    wrong: "He will going to school tomorrow.",
                    correct: "He will go to school tomorrow.",
                    why: "Do not put V1+ing directly after 'will'. Use V1 (go).",
                    whyHindi: "will के तुरंत बाद V1+ing (going) गलत है, V1 (go) का प्रयोग करें।"
                },
                {
                    wrong: "Does she will come tomorrow?",
                    correct: "Will she come tomorrow?",
                    why: "Do not combine 'does' with 'will'. Start interrogative sentences directly with 'Will'.",
                    whyHindi: "'does' और 'will' का एक साथ प्रयोग न करें। प्रश्नवाचक वाक्य 'Will' से शुरू करें।"
                },
                {
                    wrong: "Did they will join the meeting?",
                    correct: "Will they join the meeting?",
                    why: "Do not combine 'did' with 'will'. Simple Future questions begin with 'Will'.",
                    whyHindi: "'did' और 'will' को न मिलाएं। Simple Future प्रश्न 'Will' से शुरू होते हैं।"
                },
                {
                    wrong: "I won't went to the party.",
                    correct: "I won't go to the party.",
                    why: "Even after negative contraction 'won't', the main verb must be V1 (go).",
                    whyHindi: "won't के बाद भी मुख्य क्रिया हमेशा V1 (go) ही रहती है।"
                },
                {
                    wrong: "She will to help us tomorrow.",
                    correct: "She will help us tomorrow.",
                    why: "Do not use 'to' infinitive after 'will'. 'Will' is followed by bare infinitive V1.",
                    whyHindi: "will के बाद 'to' का प्रयोग न करें।"
                },
                {
                    wrong: "I will can solve this problem.",
                    correct: "I will be able to solve this problem. / I can solve this problem.",
                    why: "Do not combine modal verbs 'will' and 'can' together.",
                    whyHindi: "will और can दो modal क्रियाओं को एक साथ न लगाएं।"
                },
                {
                    wrong: "When you will come, I will meet you.",
                    correct: "When you come, I will meet you.",
                    why: "In time clauses (starting with when/if/before), use Simple Present (come), not future (will come).",
                    whyHindi: "Time clause (When/If से शुरू) में will come की जगह Simple Present (come) का प्रयोग होता है।"
                },
                {
                    wrong: "Why she will arrive late?",
                    correct: "Why will she arrive late?",
                    why: "In WH questions, auxiliary 'will' must come BEFORE the subject ('she').",
                    whyHindi: "WH प्रश्नों में 'will' कर्ता (she) से पहले आना चाहिए।"
                },
                {
                    wrong: "He will works hard next year.",
                    correct: "He will work hard next year.",
                    why: "After 'will', the verb is always in base form (work), regardless of third-person singular subject.",
                    whyHindi: "He होने पर भी will के बाद work आएगा, works नहीं।"
                },
                {
                    wrong: "They won't finished the work.",
                    correct: "They won't finish the work.",
                    why: "Use V1 (finish) after 'won't', not V3 (finished).",
                    whyHindi: "won't के बाद V3 (finished) नहीं, V1 (finish) आता है।"
                },
                {
                    wrong: "I am going to will buy a car.",
                    correct: "I am going to buy a car. / I will buy a car.",
                    why: "Do not combine 'going to' and 'will' in the same clause.",
                    whyHindi: "'going to' और 'will' को एक ही वाक्य खंड में न मिलाएं।"
                },
                {
                    wrong: "Will she to join us?",
                    correct: "Will she join us?",
                    why: "No 'to' is needed before the main verb after 'will'.",
                    whyHindi: "will के बाद मुख्य क्रिया से पहले 'to' न लगाएं।"
                }
            ]
        },

        // 10. Summary & Revision / सारांश एवं दोहराव (15 Revision Examples)
        summary: {
            title: "Summary & Revision",
            titleHindi: "सारांश एवं दोहराव (Revision Summary)",
            introduction: "Quick summary of Simple Future rules, formulas, comparisons, and memory anchors.",
            introductionHindi: "Simple Future Tense के मुख्य नियमों, सूत्रों और याद रखने योग्य बिंदुओं का त्वरित सारांश।",
            
            goldenRules: [
                "1. Golden Formula ➔ Subject + WILL + V1 + Object",
                "2. All Subjects ➔ WILL is used for I, You, He, She, It, We, They, Singular, Plural.",
                "3. Main Verb Rule ➔ Always use V1 (Base Form) after will / won't. Never use V2, V3, or V1+ing.",
                "4. Negative Form ➔ Subject + will not (won't) + V1",
                "5. Interrogative Form ➔ Will + Subject + V1?",
                "6. 6 Core Uses ➔ Future decisions, Instant decisions, Predictions, Promises, Offers, Future facts.",
                "7. Note on Shall ➔ Traditional I/We shall is replaced by universal 'will' in modern standard English."
            ],

            formulaSummary: {
                positive: "Subject + will + V1 + Object",
                negative: "Subject + will not (won't) + V1 + Object",
                interrogative: "Will + Subject + V1 + Object?",
                whQuestion: "WH-word + will + Subject + V1 + Object?"
            },

            revisionExamples: {
                easy: [
                    { id: "sum-e1", english: "I will finish the report tonight.", hindi: "मैं आज रात रिपोर्ट पूरी करूँगा।", note: "All subjects take WILL + V1" },
                    { id: "sum-e2", english: "She won't attend the meeting tomorrow.", hindi: "वह कल मीटिंग में शामिल नहीं होगी।", note: "Negative with won't + V1" },
                    { id: "sum-e3", english: "Will you help me with this task?", hindi: "क्या आप इस काम में मेरी मदद करेंगे?", note: "Interrogative starting with Will" },
                    { id: "sum-e4", english: "When will she arrive?", hindi: "वह कब पहुंचेगी?", note: "WH question with When will" },
                    { id: "sum-e5", english: "The phone is ringing. I will answer it.", hindi: "फोन बज रहा है। मैं इसे उठाऊँगा।", note: "Instant decision at speaking moment" }
                ],
                medium: [
                    { id: "sum-m1", english: "The doctor will examine the patient tomorrow.", hindi: "डॉक्टर कल मरीज की जांच करेंगे।", note: "Doctor + will + V1" },
                    { id: "sum-m2", english: "We won't compromise on product quality.", hindi: "हम उत्पाद की गुणवत्ता से समझौता नहीं करेंगे।", note: "Contraction won't + V1" },
                    { id: "sum-m3", english: "Will the team present the project proposal?", hindi: "क्या टीम प्रोजेक्ट प्रस्ताव प्रस्तुत करेगी?", note: "Yes/No interrogative" },
                    { id: "sum-m4", english: "How will they achieve the target this quarter?", hindi: "वे इस तिमाही में लक्ष्य कैसे हासिल करेंगे?", note: "WH question with How will" },
                    { id: "sum-m5", english: "I think it will rain tomorrow.", hindi: "मुझे लगता है कि कल बारिश होगी।", note: "Prediction with 'I think'" }
                ],
                hard: [
                    { id: "sum-h1", english: "Software engineers will deploy security patch tonight.", hindi: "सॉफ्टवेयर इंजीनियर आज रात सुरक्षा पैच तैनात करेंगे।", note: "Technical context with will + V1" },
                    { id: "sum-h2", english: "The board won't sanction unapproved expenditure.", hindi: "बोर्ड गैर-मंजूर व्यय को मंजूरी नहीं देगा।", note: "Formal negative" },
                    { id: "sum-h3", english: "Will authorities evacuate coastal areas before storm?", hindi: "क्या अधिकारी तूफान से पहले तटीय इलाकों को खाली कराएंगे?", note: "Emergency context question" },
                    { id: "sum-h4", english: "What security features will engineers implement?", hindi: "इंजीनियर क्या सुरक्षा सुविधाएं लागू करेंगे?", note: "Complex WH question" },
                    { id: "sum-h5", english: "The government will implement economic reforms.", hindi: "सरकार आर्थिक सुधारों को लागू करेगी।", note: "Future policy statement" }
                ]
            }
        },

        // 11. Practice Exercises / अभ्यास (120 Practice Sentences Total)
        exercises: {
            title: "Simple Future Practice Sentences",
            titleHindi: "सामान्य भविष्यत् काल — अभ्यास (120 Practice Sentences)",
            introduction: "Practice all 120 sentences across Positive, Negative, Interrogative, and WH Questions to master Simple Future Tense.",
            introductionHindi: "Simple Future Tense के 120 अभ्यास वाक्यों (सकारात्मक, नकारात्मक, प्रश्नवाचक एवं WH प्रश्न) के माध्यम से पूरा अभ्यास करें।",
            categories: []
        },

        // 12. Quiz Configuration / ज्ञान परीक्षा (12 Quiz Combinations)
        quiz: {
            title: "Simple Future Quiz",
            titleHindi: "सामान्य भविष्यत् काल — ज्ञान परीक्षा",
            questions: []
        }
    }
};

// Initialize categories referencing existing sections (120 Practice Sentences total)
simpleFutureLesson.sections.exercises.categories = [
    {
        id: "positive",
        title: "Positive Sentences Practice",
        titleHindi: "1. सकारात्मक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Positive Sentence",
        sentences: simpleFutureLesson.sections.positive.sentences
    },
    {
        id: "negative",
        title: "Negative Sentences Practice",
        titleHindi: "2. नकारात्मक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Negative Sentence",
        sentences: simpleFutureLesson.sections.negative.sentences
    },
    {
        id: "interrogative",
        title: "Interrogative Sentences Practice",
        titleHindi: "3. प्रश्नवाचक वाक्य अभ्यास (30 Sentences)",
        typeLabel: "Yes/No Question",
        sentences: simpleFutureLesson.sections.interrogative.sentences
    },
    {
        id: "whQuestions",
        title: "WH Questions Practice",
        titleHindi: "4. WH प्रश्न अभ्यास (30 Sentences)",
        typeLabel: "WH Question",
        sentences: simpleFutureLesson.sections.whQuestions.sentences
    }
];

/**
 * Get the complete Simple Future lesson object
 * @returns {object}
 */
export function getSimpleFutureLesson() {
    return { ...simpleFutureLesson };
}

/**
 * Get a specific section of Simple Future lesson data
 * @param {string} sectionName 
 * @returns {object|Array|null}
 */
export function getSimpleFutureSection(sectionName) {
    if (!sectionName || !simpleFutureLesson.sections) return null;
    return simpleFutureLesson.sections[sectionName] || null;
}
