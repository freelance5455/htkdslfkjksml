/**
 * Central Platform Menu Configuration
 * Single Source of Truth for the English Learning Platform menu hierarchy.
 * Vanilla ES6 JavaScript Module.
 */

export const platformMenu = [
    {
        id: "dashboard",
        title: "Dashboard",
        type: "page",
        icon: "dashboard"
    },
    {
        id: "tenses",
        title: "Tenses",
        type: "section",
        icon: "clock",
        children: [
            {
                id: "present-tenses",
                title: "Present",
                type: "section",
                children: [
                    { id: "simple-present", title: "Simple Present", type: "page" },
                    { id: "present-continuous", title: "Present Continuous", type: "page" },
                    { id: "present-perfect", title: "Present Perfect", type: "page" },
                    { id: "present-perfect-continuous", title: "Present Perfect Continuous", type: "page" }
                ]
            },
            {
                id: "past-tenses",
                title: "Past",
                type: "section",
                children: [
                    { id: "simple-past", title: "Simple Past", type: "page" },
                    { id: "past-continuous", title: "Past Continuous", type: "page" },
                    { id: "past-perfect", title: "Past Perfect", type: "page" },
                    { id: "past-perfect-continuous", title: "Past Perfect Continuous", type: "page" }
                ]
            },
            {
                id: "future-tenses",
                title: "Future",
                type: "section",
                children: [
                    { id: "simple-future", title: "Simple Future", type: "page" },
                    { id: "future-continuous", title: "Future Continuous", type: "page" },
                    { id: "future-perfect", title: "Future Perfect", type: "page" },
                    { id: "future-perfect-continuous", title: "Future Perfect Continuous", type: "page" }
                ]
            }
        ]
    },
    {
        id: "modal-verbs",
        title: "Modal Verbs",
        type: "section",
        icon: "sparkles",
        children: [
            { id: "modal-can", title: "Can", type: "page" },
            { id: "modal-could", title: "Could", type: "page" },
            { id: "modal-may", title: "May", type: "page" },
            { id: "modal-might", title: "Might", type: "page" },
            { id: "modal-will", title: "Will", type: "page" },
            { id: "modal-would", title: "Would", type: "page" },
            { id: "modal-shall", title: "Shall", type: "page" },
            { id: "modal-should", title: "Should", type: "page" },
            { id: "modal-must", title: "Must", type: "page" },
            { id: "modal-ought-to", title: "Ought to", type: "page" },
            { id: "modal-need", title: "Need", type: "page" },
            { id: "modal-dare", title: "Dare", type: "page" },
            { id: "modal-used-to", title: "Used to", type: "page" }
        ]
    },
    {
        id: "verbs-library",
        title: "V1–V5 Verbs Library",
        type: "section",
        icon: "book-open",
        children: [
            { id: "verbs-easy", title: "Easy", type: "page" },
            { id: "verbs-medium", title: "Medium", type: "page" },
            { id: "verbs-hard", title: "Hard", type: "page" }
        ]
    },
    {
        id: "grammar",
        title: "Grammar",
        type: "section",
        icon: "academic-cap",
        children: [
            { id: "grammar-foundation", title: "Foundation", type: "page" },
            { id: "grammar-intermediate", title: "Intermediate", type: "page" },
            { id: "grammar-advanced", title: "Advanced", type: "page" }
        ]
    },
    {
        id: "speaking-english",
        title: "Speaking English",
        type: "section",
        icon: "chat-alt",
        children: [
            { id: "daily-conversation-basics", title: "Daily Conversation Basics", type: "page" },
            { id: "office-workplace-english", title: "Office & Workplace English", type: "page" },
            { id: "asking-questions-fluently", title: "Asking Questions Fluently", type: "page" },
            { id: "giving-answers-elaborating", title: "Giving Answers & Elaborating", type: "page" },
            { id: "making-requests-politely", title: "Making Requests Politely", type: "page" },
            { id: "giving-advice-suggestions", title: "Giving Advice & Suggestions", type: "page" },
            { id: "asking-giving-permission", title: "Asking & Giving Permission", type: "page" },
            { id: "agreement-disagreement", title: "Expressing Agreement & Disagreement", type: "page" },
            { id: "telephone-online-call", title: "Telephone & Online Call English", type: "page" },
            { id: "meetings-presentations", title: "Meetings & Presentations English", type: "page" },
            { id: "professional-email-writing", title: "Professional Email Writing", type: "page" },
            { id: "job-interview-preparation", title: "Job Interview Preparation", type: "page" },
            { id: "travel-airport-english", title: "Travel & Airport English", type: "page" },
            { id: "shopping-restaurant-english", title: "Shopping & Restaurant English", type: "page" },
            { id: "social-event-conversations", title: "Social & Event Conversations", type: "page" },
            { id: "english-fluency-confidence-mastery", title: "English Fluency & Confidence Mastery", type: "page" }
        ]
    },
    {
        id: "practice-quiz",
        title: "Practice & Quiz",
        type: "page",
        icon: "pencil-alt"
    },
    {
        id: "search",
        title: "Search",
        type: "page",
        icon: "search"
    },
    {
        id: "bookmarks",
        title: "Bookmarks",
        type: "page",
        icon: "bookmark"
    },
    {
        id: "my-notes",
        title: "My Notes",
        type: "page",
        icon: "document-text"
    },
    {
        id: "my-progress",
        title: "My Progress",
        type: "page",
        icon: "chart-bar"
    },
    {
        id: "quick-reference",
        title: "Quick Reference",
        type: "page",
        icon: "light-bulb"
    }
];

/**
 * Helper function to find a menu item by ID recursively
 * @param {string} id 
 * @param {Array} items 
 * @returns {object|null}
 */
export function getMenuItemById(id, items = platformMenu) {
    for (const item of items) {
        if (item.id === id) return item;
        if (item.children && item.children.length > 0) {
            const found = getMenuItemById(id, item.children);
            if (found) return found;
        }
    }
    return null;
}
