/**
 * Central Modal Verbs Metadata & Schema Structure
 * Single Source of Truth for the 13 English Modal Verbs (Hindi Medium).
 * Vanilla ES6 JavaScript Module.
 */

export const modalsData = [
    {
        id: "modal-can",
        name: "Can",
        title: "Can",
        titleHindi: "Can (सकना / क्षमता)",
        hindiMeaning: "सकना / क्षमता (Ability)",
        category: "Primary Modal",
        categoryHindi: "प्राथमिक मोडल",
        status: "Foundation Ready",
        shortDescription: "Used for present ability, informal permission, possibility, and request.",
        shortDescriptionHindi: "वर्तमान क्षमता (Ability), अनौपचारिक अनुमति (Permission), और संभावना व्यक्त करने के लिए।"
    },
    {
        id: "modal-could",
        name: "Could",
        title: "Could",
        titleHindi: "Could (सका / सकता था)",
        hindiMeaning: "सका / सकता था / नम्र निवेदन (Past Ability / Polite Request)",
        category: "Primary Modal",
        categoryHindi: "प्राथमिक मोडल",
        status: "Foundation Ready",
        shortDescription: "Used for past ability, polite requests, and conditional possibility.",
        shortDescriptionHindi: "भूतकाल की क्षमता (Past Ability), नम्र निवेदन, और संभावना व्यक्त करने के लिए।"
    },
    {
        id: "modal-may",
        name: "May",
        title: "May",
        titleHindi: "May (सकता है / अनुमति)",
        hindiMeaning: "सकता है / अनुमति / संभावना (Formal Permission / Possibility)",
        category: "Primary Modal",
        categoryHindi: "प्राथमिक मोडल",
        status: "Foundation Ready",
        shortDescription: "Used for formal permission, strong possibility, wishes, and purpose.",
        shortDescriptionHindi: "औपचारिक अनुमति (Formal Permission), संभावना, और शुभकामनाएँ व्यक्त करने के लिए।"
    },
    {
        id: "modal-might",
        name: "Might",
        title: "Might",
        titleHindi: "Might (शायद ही / कम संभावना)",
        hindiMeaning: "शायद ही / कम संभावना (Low Possibility)",
        category: "Primary Modal",
        categoryHindi: "प्राथमिक मोडल",
        status: "Foundation Ready",
        shortDescription: "Used for weak possibility and hesitant requests.",
        shortDescriptionHindi: "कम या बहुत ही क्षीण संभावना (Weak Possibility) दर्शाने के लिए।"
    },
    {
        id: "modal-will",
        name: "Will",
        title: "Will",
        titleHindi: "Will (गा/गी/गे / संकल्प)",
        hindiMeaning: "गा/गी/गे / संकल्प / इच्छा (Future / Determination)",
        category: "Primary Modal",
        categoryHindi: "प्राथमिक मोडल",
        status: "Foundation Ready",
        shortDescription: "Used for future action, promises, willingness, and determination.",
        shortDescriptionHindi: "भविष्य के कार्य, वादे (Promises), और दृढ़ संकल्प दर्शाने के लिए।"
    },
    {
        id: "modal-would",
        name: "Would",
        title: "Would",
        titleHindi: "Would (गा/गी/गे / पुरानी आदत)",
        hindiMeaning: "गा/गी/गे / पुरानी आदत / नम्र निवेदन (Past Habit / Polite Offer)",
        category: "Primary Modal",
        categoryHindi: "प्राथमिक मोडल",
        status: "Foundation Ready",
        shortDescription: "Used for past habits, polite offers, preferences, and hypotheticals.",
        shortDescriptionHindi: "अतीत की आदतों (Past Routine), नम्र प्रस्ताव, और काल्पनिक स्थितियों के लिए।"
    },
    {
        id: "modal-shall",
        name: "Shall",
        title: "Shall",
        titleHindi: "Shall (गा/गी/गे / सुझाव)",
        hindiMeaning: "गा/गी/गे / सुझाव / प्रस्ताव (Formal Offer / Suggestion)",
        category: "Primary Modal",
        categoryHindi: "प्राथमिक मोडल",
        status: "Foundation Ready",
        shortDescription: "Used for formal offers, suggestions, and future predictions.",
        shortDescriptionHindi: "सुझाव (Suggestions), प्रस्ताव, और औपचारिक वादों के लिए।"
    },
    {
        id: "modal-should",
        name: "Should",
        title: "Should",
        titleHindi: "Should (चाहिए / सलाह)",
        hindiMeaning: "चाहिए / सलाह / कर्तव्य (Advice / Obligation)",
        category: "Primary Modal",
        categoryHindi: "प्राथमिक मोडल",
        status: "Foundation Ready",
        shortDescription: "Used for giving advice, recommendations, and mild obligations.",
        shortDescriptionHindi: "सलाह (Advice), सुझाव, और सामान्य कर्तव्य बताने के लिए।"
    },
    {
        id: "modal-must",
        name: "Must",
        title: "Must",
        titleHindi: "Must (अवश्य चाहिए / अनिवार्यता)",
        hindiMeaning: "अवश्य चाहिए / अनिवार्यता (Compulsion / Strong Advice)",
        category: "Primary Modal",
        categoryHindi: "प्राथमिक मोडल",
        status: "Foundation Ready",
        shortDescription: "Used for strong obligation, necessity, rule, and certainty.",
        shortDescriptionHindi: "अनिवार्यता (Compulsion), पक्का इरादा, और नियम दर्शाने के लिए।"
    },
    {
        id: "modal-ought-to",
        name: "Ought to",
        title: "Ought to",
        titleHindi: "Ought to (नैतिक कर्तव्य)",
        hindiMeaning: "चाहिए / नैतिक कर्तव्य (Moral Duty / Social Obligation)",
        category: "Semi-Modal",
        categoryHindi: "अर्ध-मोडल",
        status: "Foundation Ready",
        shortDescription: "Used for moral duty, social obligations, and respectful advice.",
        shortDescriptionHindi: "नैतिक कर्तव्य (Moral Duty) और सामाजिक जिम्मेदारी बताने के लिए।"
    },
    {
        id: "modal-need",
        name: "Need",
        title: "Need",
        titleHindi: "Need (आवश्यकता / जरूरत)",
        hindiMeaning: "आवश्यकता होना / जरूरत (Necessity / Requirement)",
        category: "Semi-Modal",
        categoryHindi: "अर्ध-मोडल",
        status: "Foundation Ready",
        shortDescription: "Used for necessity, requirement, and absence of obligation (needn't).",
        shortDescriptionHindi: "ज़रूरत (Requirement) और अनवाश्यकता (Lack of necessity) व्यक्त करने के लिए।"
    },
    {
        id: "modal-dare",
        name: "Dare",
        title: "Dare",
        titleHindi: "Dare (साहस होना / हिम्मत)",
        hindiMeaning: "साहस होना / हिम्मत करना (Courage / Challenge)",
        category: "Semi-Modal",
        categoryHindi: "अर्ध-मोडल",
        status: "Foundation Ready",
        shortDescription: "Used for courage, challenge, and bold action (how dare you).",
        shortDescriptionHindi: "साहस (Courage) और चुनौती (Challenge) दर्शाने के लिए।"
    },
    {
        id: "modal-used-to",
        name: "Used to",
        title: "Used to",
        titleHindi: "Used to (किया करता था / अतीत की स्थिति)",
        hindiMeaning: "किया करता था / पुरानी आदत (Past Routine / Habitual State)",
        category: "Semi-Modal",
        categoryHindi: "अर्ध-मोडल",
        status: "Foundation Ready",
        shortDescription: "Used for discontinued past habits and past states.",
        shortDescriptionHindi: "अतीत की छूटी हुई आदतों (Discontinued Habits) और पुरानी स्थितियों के लिए।"
    }
];

/**
 * Get all 13 modal objects
 * @returns {Array<object>}
 */
export function getAllModals() {
    return modalsData;
}

/**
 * Get modal object by ID
 * @param {string} id 
 * @returns {object|null}
 */
export function getModalById(id) {
    if (!id) return null;
    return modalsData.find(m => m.id === id) || null;
}

/**
 * Get central modal lesson schema structure for detail renderer
 * Returns full 12-section layout foundation for a given modal ID.
 * @param {string} id 
 * @returns {object|null}
 */
export function getModalLesson(id) {
    const modalMeta = getModalById(id);
    if (!modalMeta) return null;

    return {
        id: modalMeta.id,
        title: modalMeta.title,
        titleHindi: modalMeta.titleHindi,
        hindiMeaning: modalMeta.hindiMeaning,
        description: modalMeta.shortDescription,
        descriptionHindi: modalMeta.shortDescriptionHindi,
        category: modalMeta.category,
        status: modalMeta.status,
        sections: {
            // Section 1: Identification
            identification: {
                title: "Identification",
                titleHindi: "पहचान और अवधारणा (Identification & Concept)",
                english: `Concept overview and identification rules for modal verb '${modalMeta.name}'.`,
                hindi: `'${modalMeta.name}' (${modalMeta.hindiMeaning}) की पहचान और प्रयोग का मुख्य नियम।`,
                hindiIdentityRule: `पहचान: वाक्य के संदर्भ में ${modalMeta.hindiMeaning} का भाव प्रकट होता है।`,
                points: [
                    {
                        english: `Core Function: Used to express ${modalMeta.shortDescription.toLowerCase()}`,
                        hindi: `मुख्य कार्य: ${modalMeta.shortDescriptionHindi}`
                    },
                    {
                        english: "Verb Form: Followed by Base Verb V1 (Infinitive without 'to') in standard active voice.",
                        hindi: "क्रिया का रूप: सामान्यतः मुख्य क्रिया V1 (Base Form) का प्रयोग होता है।"
                    }
                ]
            },

            // Section 2: Uses
            uses: {
                title: "Uses & Scenarios",
                titleHindi: "प्रमुख उपयोग (Uses & Scenarios)",
                list: [
                    {
                        id: "use-1",
                        number: 1,
                        title: `Primary Usage of ${modalMeta.name}`,
                        titleHindi: `1. ${modalMeta.name} का मुख्य प्रयोग`,
                        explanation: `Expressing ${modalMeta.shortDescription.toLowerCase()}`,
                        explanationHindi: modalMeta.shortDescriptionHindi,
                        examples: [
                            { english: `Example sentence for ${modalMeta.name} will be populated in lesson step.`, hindi: `उदाहरण वाक्य अगले पाठ चरण में उपलब्ध होगा।` }
                        ]
                    }
                ]
            },

            // Section 3: Structure & Formulas
            structure: {
                title: "Structure & Formulas",
                titleHindi: "संरचना और सूत्र (Grammar Formulas)",
                formulas: [
                    {
                        type: "positive",
                        name: "Positive Formula",
                        formula: `Subject + ${modalMeta.name} + V1 + Object`,
                        example: `Subject + ${modalMeta.name} + V1 + Object`
                    },
                    {
                        type: "negative",
                        name: "Negative Formula",
                        formula: `Subject + ${modalMeta.name} + not + V1 + Object`,
                        example: `Subject + ${modalMeta.name} not + V1 + Object`
                    },
                    {
                        type: "interrogative",
                        name: "Interrogative Formula",
                        formula: `${modalMeta.name} + Subject + V1 + Object?`,
                        example: `${modalMeta.name} + Subject + V1 + Object?`
                    },
                    {
                        type: "whQuestions",
                        name: "WH Question Formula",
                        formula: `WH-word + ${modalMeta.name} + Subject + V1 + Object?`,
                        example: `WH + ${modalMeta.name} + Subject + V1 + Object?`
                    }
                ]
            },

            // Section 4: Subject + Verb Rules
            subjectVerbRules: {
                title: "Subject + Verb Rules",
                titleHindi: "कर्ता और क्रिया के नियम (Universal Rules)",
                goldenRule: `UNIVERSAL RULE: '${modalMeta.name.toUpperCase()}' REMAINS UNCHANGED FOR ALL SUBJECTS`,
                goldenRuleHindi: `सर्वव्यापी नियम: '${modalMeta.name.toUpperCase()}' का रूप सभी कर्ताओं के लिए समान रहता है।`,
                notes: [
                    `Modals do not take -s/-es with he/she/it.`,
                    `Always use V1 (Base Form) after ${modalMeta.name}.`
                ]
            },

            // Section 5: Positive Sentences
            positive: {
                title: "Positive Sentences",
                titleHindi: "सकारात्मक वाक्य (Positive Sentences)",
                description: `Positive sentences using '${modalMeta.name} + V1'.`,
                easy: [],
                medium: [],
                hard: []
            },

            // Section 6: Negative Sentences
            negative: {
                title: "Negative Sentences",
                titleHindi: "नकारात्मक वाक्य (Negative Sentences)",
                description: `Negative sentences using '${modalMeta.name} + not + V1'.`,
                easy: [],
                medium: [],
                hard: []
            },

            // Section 7: Interrogative Sentences
            interrogative: {
                title: "Interrogative Sentences",
                titleHindi: "प्रश्नवाचक वाक्य (Interrogative Sentences)",
                description: `Question sentences using '${modalMeta.name} + Subject + V1?'.`,
                easy: [],
                medium: [],
                hard: []
            },

            // Section 8: WH Questions
            whQuestions: {
                title: "WH Questions",
                titleHindi: "WH प्रश्नवाचक वाक्य (WH Questions)",
                description: `WH questions using 'WH + ${modalMeta.name} + Subject + V1?'.`,
                easy: [],
                medium: [],
                hard: []
            },

            // Section 9: Common Mistakes
            commonMistakes: {
                title: "Common Mistakes",
                titleHindi: "आम गलतियाँ और निवारण (Common Mistakes)",
                list: [
                    {
                        id: "err-1",
                        wrong: `Incorrect usage placeholder for ${modalMeta.name}`,
                        correct: `Correct usage placeholder for ${modalMeta.name}`,
                        why: "Always follow standard modal auxiliary rules.",
                        whyHindi: "मोडल क्रिया के सर्वव्यापी नियमों का पालन करें।"
                    }
                ]
            },

            // Section 10: Summary & Revision
            summary: {
                title: "Summary & Revision",
                titleHindi: "सारांश और पुनरावृत्ति (Summary & Revision)",
                goldenFormula: `GOLDEN RULE: Subject + ${modalMeta.name} + V1 + Object`,
                goldenFormulaHindi: `मुख्य नियम: Subject + ${modalMeta.name} + V1 + Object`,
                conceptSummary: `${modalMeta.name} (${modalMeta.hindiMeaning}) foundation architecture module is active.`
            },

            // Section 11: Practice Exercises
            exercises: {
                title: "Practice Exercises",
                titleHindi: "अभ्यास प्रश्न (Practice Exercises)",
                categories: [
                    { id: "positive", title: "Positive Sentences", count: 0 },
                    { id: "negative", title: "Negative Sentences", count: 0 },
                    { id: "interrogative", title: "Interrogative Sentences", count: 0 },
                    { id: "whQuestions", title: "WH Questions", count: 0 }
                ]
            },

            // Section 12: Quiz
            quiz: {
                title: "Modal Quiz Engine",
                titleHindi: "मोडल परीक्षा (Quiz Engine)",
                categories: [
                    { id: "positive", title: "Positive Sentences" },
                    { id: "negative", title: "Negative Sentences" },
                    { id: "interrogative", title: "Interrogative Sentences" },
                    { id: "whQuestions", title: "WH Questions" }
                ],
                difficulties: ["easy", "medium", "hard"],
                questionsPerCombination: 10
            }
        }
    };
}
