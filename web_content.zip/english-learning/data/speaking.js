/**
 * Central Speaking English Curriculum Data
 * Data-driven structure for all 16 Speaking English categories and lessons.
 */

export const speakingCategories = [
    {
        id: "daily-conversation-basics",
        title: "Daily Conversation Basics",
        description: "Greetings, introductions, asking how someone is, and small talk phrases.",
        category: "speaking",
        difficulty: {
            easy: true,
            medium: true,
            hard: true
        },
        lessons: [
            {
                id: "basic-greetings-introductions",
                title: "Basic Greetings & Introductions",
                description: "Learn essential phrases to greet people naturally and introduce yourself in everyday conversations.",
                difficulty: "easy",
                order: 1,
                categoryId: "daily-conversation-basics",

                introduction: {
                    english: "Greeting someone properly is the first step in any spoken English interaction. Knowing how to introduce yourself politely builds instant confidence.",
                    hindi: "किसी से सही तरीके से बातचीत शुरू करना अंग्रेजी बोलने का पहला कदम है। अपना परिचय देना आत्मविश्वास बढ़ाता है।",
                    whatYouWillLearn: "Common formal and informal greetings, self-introduction templates, and response phrases.",
                    whyUseful: "Essential for starting any daily conversation smoothly without hesitation.",
                    whereUsed: "Parties, social gatherings, workplace introductions, and casual meetings."
                },

                objective: {
                    english: "By the end of this lesson, you will be able to confidently greet people in formal and casual settings and introduce yourself smoothly.",
                    hindi: "इस पाठ के अंत में, आप औपचारिक और अनौपचारिक स्थितियों में लोगों का आत्मविश्वास से अभिवादन कर पाएंगे।"
                },

                vocabulary: [
                    {
                        word: "Greetings",
                        meaning: "Words or actions used to welcome someone",
                        pronunciation: "gree-tings",
                        example: "Warm greetings to everyone!",
                        hindiExample: "सभी को हार्दिक नमस्कार!"
                    },
                    {
                        word: "Acquaintance",
                        meaning: "A person you know slightly, but who is not a close friend",
                        pronunciation: "uh-kwayn-tuhnss",
                        example: "He is a business acquaintance.",
                        hindiExample: "वह एक व्यापारिक परिचित है।"
                    }
                ],

                patterns: [
                    {
                        pattern: "Hello, my name is [Name]. Nice to meet you.",
                        meaning: "Standard formal introduction",
                        usage: "Used when meeting someone for the first time in a professional or formal setting.",
                        hindiExplanation: "जब आप पहली बार किसी से औपचारिक माहौल में मिलते हैं।",
                        examples: [
                            {
                                english: "Hello, my name is Rahul. Nice to meet you.",
                                hindi: "नमस्ते, मेरा नाम राहुल है। आपसे मिलकर खुशी हुई।"
                            }
                        ]
                    },
                    {
                        pattern: "Hi, I'm [Name]. How are you doing?",
                        meaning: "Casual friendly greeting and inquiry",
                        usage: "Used with peers, friends, or informal social gatherings.",
                        hindiExplanation: "दोस्तों या अनौपचारिक माहौल में बातचीत शुरू करने के लिए।",
                        examples: [
                            {
                                english: "Hi, I'm Priya. How are you doing today?",
                                hindi: "हाय, मैं प्रिया हूँ। आज आप कैसे हैं?"
                            }
                        ]
                    }
                ],

                examples: [
                    {
                        english: "Good morning! How has your day been so far?",
                        hindi: "शुभ प्रभात! अब तक आपका दिन कैसा रहा?",
                        difficulty: "easy",
                        explanation: "Polite morning greeting suitable for office or casual talk.",
                        hindiExplanation: "ऑफिस या दोस्तों में सुबह बोलने के लिए विनम्र वाक्य।"
                    }
                ],

                conversation: [
                    {
                        title: "Meeting a New Neighbor",
                        situation: "Two people meeting in an apartment elevator for the first time.",
                        difficulty: "easy",
                        dialogue: [
                            {
                                speaker: "Alex",
                                english: "Hi there! I'm Alex from apartment 4B.",
                                hindi: "नमस्ते! मैं अपार्टमेंट 4B से एलेक्स हूँ।"
                            },
                            {
                                speaker: "Sara",
                                english: "Nice to meet you, Alex! I'm Sara from 4A.",
                                hindi: "आपसे मिलकर खुशी हुई, एलेक्स! मैं 4A से सारा हूँ।"
                            },
                            {
                                speaker: "Alex",
                                english: "Welcome to the building! Let me know if you need anything.",
                                hindi: "इमारत में आपका स्वागत है! अगर आपको किसी चीज़ की ज़रूरत हो तो मुझे बताएं।"
                            }
                        ],
                        explanation: "Short friendly interaction showcasing natural turns of phrase and positive responses."
                    }
                ],

                speakingPractice: [
                    {
                        instruction: "Introduce yourself to a new colleague at work.",
                        hindiInstruction: "काम पर किसी नए सहकर्मी से अपना परिचय दें।",
                        prompt: "Say your name, your role, and express pleasure in meeting them.",
                        expectedPattern: "Hi, I'm [Name], the new [Role]. Great to meet you!",
                        difficulty: "easy"
                    }
                ],

                whyExplanation: [
                    {
                        point: "Why use 'Nice to meet you' instead of just 'Hello'?",
                        englishExplanation: "Adding 'Nice to meet you' demonstrates warmth and opens the door for further conversation.",
                        hindiExplanation: "केवल 'हेलो' कहने के बजाय 'Nice to meet you' जोड़ना विनम्रता दर्शाता है और बातचीत को आगे बढ़ाता है।",
                        examples: [
                            "Hello! Nice to meet you."
                        ]
                    }
                ],

                commonMistakes: [
                    {
                        incorrect: "Myself Rahul.",
                        correct: "My name is Rahul / I am Rahul.",
                        explanation: "Using 'Myself' followed by a name is grammatically incorrect in standard English.",
                        hindiExplanation: "नाम बताने के लिए 'Myself' का प्रयोग अशुद्ध माना जाता है। 'My name is' या 'I am' कहें।"
                    }
                ],

                summary: {
                    keyPoints: [
                        "Use formal greetings (Good morning/afternoon) in professional contexts.",
                        "Use 'My name is...' or 'I'm...' for introductions.",
                        "Always respond politely with 'Nice to meet you too'."
                    ],
                    importantPatterns: [
                        "Hello, my name is [Name].",
                        "Nice to meet you.",
                        "How are you doing?"
                    ],
                    importantExpressions: [
                        "Pleasure to meet you",
                        "How's it going?"
                    ],
                    hindiSummary: "हमेशा विनम्रता से अभिवादन करें और 'Myself Rahul' कहने से बचें। 'My name is' या 'I am' का प्रयोग करें।"
                }
            },
            {
                id: "small-talk-weather-hobbies",
                title: "Small Talk & Weather Phrases",
                description: "Master everyday small talk, talking about the weather, and sharing hobbies easily.",
                difficulty: "easy",
                order: 2,
                categoryId: "daily-conversation-basics",

                introduction: {
                    english: "Small talk is informal conversation about light topics like weather or weekends that helps break the ice.",
                    hindi: "स्मॉल टॉक मौसम या सप्ताहांत जैसे हल्के विषयों पर की जाने वाली अनौपचारिक बातचीत है।",
                    whatYouWillLearn: "Weather expressions, talking about free time, and keeping a chat going.",
                    whyUseful: "Fills uncomfortable silences and builds friendly rapport.",
                    whereUsed: "Coffee breaks, waiting rooms, commuting, and informal events."
                },

                objective: {
                    english: "By the end of this lesson, you will be able to initiate small talk about weather and hobbies comfortably.",
                    hindi: "इस पाठ के अंत में, आप मौसम और शौक के बारे में आसानी से हल्की बातचीत शुरू कर सकेंगे।"
                },

                vocabulary: [
                    {
                        word: "Small talk",
                        meaning: "Polite conversation about unimportant matters",
                        pronunciation: "smawl tawk",
                        example: "We made small talk while waiting for the bus.",
                        hindiExample: "हमने बस का इंतजार करते हुए सामान्य बातचीत की।"
                    }
                ],

                patterns: [
                    {
                        pattern: "Lovely weather today, isn't it?",
                        meaning: "Common weather icebreaker",
                        usage: "Used to start a quick friendly chat with someone nearby.",
                        hindiExplanation: "पास खड़े व्यक्ति से हल्की बातचीत शुरू करने के लिए।",
                        examples: [
                            {
                                english: "Lovely weather today, isn't it?",
                                hindi: "आज मौसम बहुत सुहावना है, है न?"
                            }
                        ]
                    }
                ],

                examples: [
                    {
                        english: "What do you like to do in your free time?",
                        hindi: "आप अपने खाली समय में क्या करना पसंद करते हैं?",
                        difficulty: "easy",
                        explanation: "Friendly question to ask about personal hobbies.",
                        hindiExplanation: "शौक के बारे में पूछने के लिए सरल प्रश्न।"
                    }
                ],

                conversation: [
                    {
                        title: "Chatting by the Coffee Machine",
                        situation: "Two coworkers taking a short break.",
                        difficulty: "easy",
                        dialogue: [
                            {
                                speaker: "Mark",
                                english: "It's quite chilly outside today, isn't it?",
                                hindi: "आज बाहर काफी ठंड है, है न?"
                            },
                            {
                                speaker: "Nina",
                                english: "Yes, absolutely! Hot coffee is definitely needed today.",
                                hindi: "हाँ, बिल्कुल! आज गरम कॉफी की बहुत ज़रूरत है।"
                            }
                        ],
                        explanation: "Demonstrates natural casual responses during work breaks."
                    }
                ],

                speakingPractice: [
                    {
                        instruction: "Ask a friend about their weekend plans.",
                        hindiInstruction: "किसी दोस्त से उनके सप्ताहांत की योजनाओं के बारे में पूछें।",
                        prompt: "Ask what they plan to do this coming weekend.",
                        expectedPattern: "Do you have any plans for the weekend?",
                        difficulty: "easy"
                    }
                ],

                whyExplanation: [
                    {
                        point: "Why is talking about weather popular in English?",
                        englishExplanation: "Weather is a neutral, safe topic that anyone can relate to without controversy.",
                        hindiExplanation: "मौसम एक सुरक्षित और निष्पक्ष विषय है जिससे कोई भी आसानी से जुड़ सकता है।",
                        examples: [
                            "Nice day today, right?"
                        ]
                    }
                ],

                commonMistakes: [
                    {
                        incorrect: "Today climate is good.",
                        correct: "The weather is nice today.",
                        explanation: "Use 'weather' for daily atmospheric conditions, not 'climate'.",
                        hindiExplanation: "दैनिक मौसम के लिए 'weather' का उपयोग करें, 'climate' (जलवायु) का नहीं।"
                    }
                ],

                summary: {
                    keyPoints: [
                        "Use 'weather' for short-term daily conditions.",
                        "Ask open questions about hobbies to keep conversations flowing."
                    ],
                    importantPatterns: [
                        "Lovely weather today, isn't it?",
                        "What do you do in your free time?"
                    ],
                    importantExpressions: [
                        "Break the ice",
                        "Catch up soon"
                    ],
                    hindiSummary: "मौसम के लिए 'weather' शब्द का प्रयोग करें और बातचीत शुरू करने के लिए सरल प्रश्न पूछें।"
                }
            }
        ]
    },
    {
        id: "office-workplace-english",
        title: "Office & Workplace English",
        description: "Talking to boss, colleagues, reporting progress, and professional etiquette.",
        category: "speaking",
        difficulty: {
            easy: true,
            medium: true,
            hard: true
        },
        lessons: [
            {
                id: "reporting-work-progress",
                title: "Reporting Work Progress to Manager",
                description: "Learn how to give clear, professional status updates on your ongoing tasks.",
                difficulty: "easy",
                order: 1,
                categoryId: "office-workplace-english",

                introduction: {
                    english: "Communicating project status clearly to your manager shows accountability and professionalism.",
                    hindi: "प्रबंधक को काम की प्रगति की स्पष्ट जानकारी देना आपकी पेशेवर जिम्मेदारी को दर्शाता है।",
                    whatYouWillLearn: "Phrases for reporting completed tasks, ongoing work, and upcoming steps.",
                    whyUseful: "Helps avoid misunderstandings and keeps projects on schedule.",
                    whereUsed: "1-on-1 manager check-ins, team huddles, and status reporting."
                },

                objective: {
                    english: "By the end of this lesson, you will be able to structure a concise 3-part work update (Done, In Progress, Next).",
                    hindi: "इस पाठ के अंत में, आप अपने काम का संक्षिप्त 3-चरणीय अपडेट दे सकेंगे।"
                },

                vocabulary: [
                    {
                        word: "Status update",
                        meaning: "A report on the current progress of a project",
                        pronunciation: "stay-tuss up-dayt",
                        example: "I will provide a status update by 3 PM.",
                        hindiExample: "मैं दोपहर 3 बजे तक स्थिति की अद्यतन रिपोर्ट दूंगा।"
                    }
                ],

                patterns: [
                    {
                        pattern: "I have completed [Task], and currently I am working on [Next Task].",
                        meaning: "Structured work progress statement",
                        usage: "Used in daily standups or status meetings with manager.",
                        hindiExplanation: "पूरे हुए काम और वर्तमान में चल रहे काम के बारे में बताने के लिए।",
                        examples: [
                            {
                                english: "I have completed the report analysis, and currently I am working on the presentation slides.",
                                hindi: "मैंने रिपोर्ट विश्लेषण पूरा कर लिया है, और वर्तमान में मैं प्रेजेंटेशन स्लाइड पर काम कर रहा हूँ।"
                            }
                        ]
                    }
                ],

                examples: [
                    {
                        english: "Everything is on track for the Friday release.",
                        hindi: "शुक्रवार की रिलीज़ के लिए सब कुछ समय पर चल रहा है।",
                        difficulty: "easy",
                        explanation: "Reassuring sentence confirming deadline compliance.",
                        hindiExplanation: "काम समय पर होने का आश्वासन देने वाला वाक्य।"
                    }
                ],

                conversation: [
                    {
                        title: "Quick Standup with Manager",
                        situation: "Employee briefing manager during morning check-in.",
                        difficulty: "easy",
                        dialogue: [
                            {
                                speaker: "Manager",
                                english: "Hi Amit, how is the client presentation coming along?",
                                hindi: "हाय अमित, क्लाइंट प्रेजेंटेशन की प्रगति कैसी है?"
                            },
                            {
                                speaker: "Amit",
                                english: "It's going well! I've finished the draft slides and will finalize them by noon.",
                                hindi: "यह बढ़िया चल रहा है! मैंने ड्राफ्ट तैयार कर लिया है और दोपहर तक इसे अंतिम रूप दे दूंगा।"
                            }
                        ],
                        explanation: "Clear and proactive communication highlighting completed and pending milestones."
                    }
                ],

                speakingPractice: [
                    {
                        instruction: "Give a 2-sentence progress update to your manager.",
                        hindiInstruction: "अपने मैनेजर को 2 वाक्यों में काम का अपडेट दें।",
                        prompt: "Mention one completed task and one task scheduled for today.",
                        expectedPattern: "I finished [Task A]. Today I will focus on [Task B].",
                        difficulty: "easy"
                    }
                ],

                whyExplanation: [
                    {
                        point: "Why use 'Everything is on track'?",
                        englishExplanation: "It is a standard business idiom that instantly confirms deadlines will be met.",
                        hindiExplanation: "यह व्यापारिक भाषा का मानक मुहावरा है जो तुरंत स्पष्ट करता है कि काम तय समय पर पूरा होगा।",
                        examples: [
                            "The project is on track."
                        ]
                    }
                ],

                commonMistakes: [
                    {
                        incorrect: "I am doing the work since morning.",
                        correct: "I have been working on this since morning.",
                        explanation: "Use present perfect continuous ('have been working') for actions started in past and continuing now.",
                        hindiExplanation: "सुबह से चल रहे काम के लिए 'have been working' का प्रयोग करें।"
                    }
                ],

                summary: {
                    keyPoints: [
                        "Structure updates into: Completed, In Progress, Next Steps.",
                        "Use 'have been working on' for ongoing tasks."
                    ],
                    importantPatterns: [
                        "I have completed...",
                        "Everything is on track."
                    ],
                    importantExpressions: [
                        "Status update",
                        "On track"
                    ],
                    hindiSummary: "प्रगति रिपोर्ट के लिए 3-चरणीय मॉडल (पूरा हुआ, जारी, अगला चरण) का उपयोग करें।"
                }
            }
        ]
    },
    {
        id: "asking-questions-fluently",
        title: "Asking Questions Fluently",
        description: "Polite ways to ask questions without sounding rude or intrusive.",
        category: "speaking",
        difficulty: {
            easy: true,
            medium: true,
            hard: true
        },
        lessons: []
    },
    {
        id: "giving-answers-elaborating",
        title: "Giving Answers & Elaborating",
        description: "Avoiding one-word answers and using connectors to explain reasons.",
        category: "speaking",
        difficulty: {
            easy: true,
            medium: true,
            hard: true
        },
        lessons: []
    },
    {
        id: "making-requests-politely",
        title: "Making Requests Politely",
        description: "Could you please..., Would you mind..., I would be grateful if...",
        category: "speaking",
        difficulty: {
            easy: true,
            medium: true,
            hard: true
        },
        lessons: []
    },
    {
        id: "giving-advice-suggestions",
        title: "Giving Advice & Suggestions",
        description: "Why don't we..., How about..., You ought to..., If I were you...",
        category: "speaking",
        difficulty: {
            easy: true,
            medium: true,
            hard: true
        },
        lessons: []
    },
    {
        id: "asking-giving-permission",
        title: "Asking & Giving Permission",
        description: "May I..., Can I..., Do you mind if I..., Feel free to...",
        category: "speaking",
        difficulty: {
            easy: true,
            medium: true,
            hard: true
        },
        lessons: []
    },
    {
        id: "agreement-disagreement",
        title: "Expressing Agreement & Disagreement",
        description: "I completely agree, I see your point but..., Respectfully I disagree.",
        category: "speaking",
        difficulty: {
            easy: true,
            medium: true,
            hard: true
        },
        lessons: []
    },
    {
        id: "telephone-online-call",
        title: "Telephone & Online Call English",
        description: "Answering calls, leaving messages, network issue phrases, ending calls.",
        category: "speaking",
        difficulty: {
            easy: true,
            medium: true,
            hard: true
        },
        lessons: []
    },
    {
        id: "meetings-presentations",
        title: "Meetings & Presentations English",
        description: "Starting a meeting, interrupting politely, summarizing points, concluding.",
        category: "speaking",
        difficulty: {
            easy: true,
            medium: true,
            hard: true
        },
        lessons: []
    },
    {
        id: "professional-email-writing",
        title: "Professional Email Writing",
        description: "Subject lines, opening salutations, formal requests, attachments, professional closing.",
        category: "speaking",
        difficulty: {
            easy: true,
            medium: true,
            hard: true
        },
        lessons: []
    },
    {
        id: "job-interview-preparation",
        title: "Job Interview Preparation",
        description: "Tell me about yourself, strengths/weaknesses, career goals answer templates.",
        category: "speaking",
        difficulty: {
            easy: true,
            medium: true,
            hard: true
        },
        lessons: []
    },
    {
        id: "travel-airport-english",
        title: "Travel & Airport English",
        description: "Check-in, immigration, asking directions, hotel booking phrases.",
        category: "speaking",
        difficulty: {
            easy: true,
            medium: true,
            hard: true
        },
        lessons: []
    },
    {
        id: "shopping-restaurant-english",
        title: "Shopping & Restaurant English",
        description: "Ordering food, asking prices, bargaining, paying bills.",
        category: "speaking",
        difficulty: {
            easy: true,
            medium: true,
            hard: true
        },
        lessons: []
    },
    {
        id: "social-event-conversations",
        title: "Social & Event Conversations",
        description: "Parties, weddings, networking events, making new friends.",
        category: "speaking",
        difficulty: {
            easy: true,
            medium: true,
            hard: true
        },
        lessons: []
    },
    {
        id: "english-fluency-confidence-mastery",
        title: "English Fluency & Confidence Mastery",
        description: "Overcoming hesitation, thinking in English, tone modulation, and daily practice habit.",
        category: "speaking",
        difficulty: {
            easy: true,
            medium: true,
            hard: true
        },
        lessons: []
    }
];

/**
 * Get category by ID
 * @param {string} id 
 * @returns {object|null}
 */
export function getCategoryById(id) {
    return speakingCategories.find(cat => cat.id === id) || null;
}

/**
 * Get previous and next category relative to current ID
 * @param {string} currentId 
 * @returns {{ prev: object|null, next: object|null }}
 */
export function getAdjacentCategories(currentId) {
    const index = speakingCategories.findIndex(cat => cat.id === currentId);
    if (index === -1) return { prev: null, next: null };
    return {
        prev: index > 0 ? speakingCategories[index - 1] : null,
        next: index < speakingCategories.length - 1 ? speakingCategories[index + 1] : null
    };
}

/**
 * Get lesson by category ID and lesson ID
 * @param {string} categoryId 
 * @param {string} lessonId 
 * @returns {object|null}
 */
export function getLessonById(categoryId, lessonId) {
    const category = getCategoryById(categoryId);
    if (!category || !category.lessons) return null;
    return category.lessons.find(l => l.id === lessonId) || null;
}

/**
 * Get previous and next lesson relative to current lesson ID within a category
 * @param {string} categoryId 
 * @param {string} currentLessonId 
 * @returns {{ prev: object|null, next: object|null }}
 */
export function getAdjacentLessons(categoryId, currentLessonId) {
    const category = getCategoryById(categoryId);
    if (!category || !category.lessons || category.lessons.length === 0) {
        return { prev: null, next: null };
    }
    const index = category.lessons.findIndex(l => l.id === currentLessonId);
    if (index === -1) return { prev: null, next: null };
    return {
        prev: index > 0 ? category.lessons[index - 1] : null,
        next: index < category.lessons.length - 1 ? category.lessons[index + 1] : null
    };
}
