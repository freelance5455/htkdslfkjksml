/**
 * Central Tenses Curriculum Data & Metadata Structure
 * Single Source of Truth for the 12 English Tenses (Hindi Medium).
 * Vanilla ES6 JavaScript Module.
 */

export const tensesData = {
    present: {
        id: "present-tenses",
        title: "Present Tenses",
        titleHindi: "वर्तमान काल",
        tenses: [
            {
                id: "simple-present",
                title: "Simple Present",
                titleHindi: "सामान्य वर्तमान काल",
                groupId: "present-tenses"
            },
            {
                id: "present-continuous",
                title: "Present Continuous",
                titleHindi: "अपूर्ण वर्तमान काल",
                groupId: "present-tenses"
            },
            {
                id: "present-perfect",
                title: "Present Perfect",
                titleHindi: "पूर्ण वर्तमान काल",
                groupId: "present-tenses"
            },
            {
                id: "present-perfect-continuous",
                title: "Present Perfect Continuous",
                titleHindi: "पूर्ण निरंतर वर्तमान काल",
                groupId: "present-tenses"
            }
        ]
    },

    past: {
        id: "past-tenses",
        title: "Past Tenses",
        titleHindi: "भूतकाल",
        tenses: [
            {
                id: "simple-past",
                title: "Simple Past",
                titleHindi: "सामान्य भूतकाल",
                groupId: "past-tenses"
            },
            {
                id: "past-continuous",
                title: "Past Continuous",
                titleHindi: "अपूर्ण भूतकाल",
                groupId: "past-tenses"
            },
            {
                id: "past-perfect",
                title: "Past Perfect",
                titleHindi: "पूर्ण भूतकाल",
                groupId: "past-tenses"
            },
            {
                id: "past-perfect-continuous",
                title: "Past Perfect Continuous",
                titleHindi: "पूर्ण निरंतर भूतकाल",
                groupId: "past-tenses"
            }
        ]
    },

    future: {
        id: "future-tenses",
        title: "Future Tenses",
        titleHindi: "भविष्यत् काल",
        tenses: [
            {
                id: "simple-future",
                title: "Simple Future",
                titleHindi: "सामान्य भविष्यत् काल",
                groupId: "future-tenses"
            },
            {
                id: "future-continuous",
                title: "Future Continuous",
                titleHindi: "अपूर्ण भविष्यत् काल",
                groupId: "future-tenses"
            },
            {
                id: "future-perfect",
                title: "Future Perfect",
                titleHindi: "पूर्ण भविष्यत् काल",
                groupId: "future-tenses"
            },
            {
                id: "future-perfect-continuous",
                title: "Future Perfect Continuous",
                titleHindi: "पूर्ण निरंतर भविष्यत् काल",
                groupId: "future-tenses"
            }
        ]
    }
};

/**
 * Get a specific tense object by ID
 * @param {string} id - Tense ID (e.g. 'simple-present')
 * @returns {object|null}
 */
export function getTenseById(id) {
    if (!id) return null;
    const all = getAllTenses();
    return all.find(tense => tense.id === id) || null;
}

/**
 * Get a tense group object by group ID or group key
 * @param {string} id - Group ID ('present-tenses', 'past-tenses', 'future-tenses' or 'present', 'past', 'future')
 * @returns {object|null}
 */
export function getTenseGroupById(id) {
    if (!id) return null;
    for (const key of Object.keys(tensesData)) {
        const group = tensesData[key];
        if (group.id === id || key === id) {
            return group;
        }
    }
    return null;
}

/**
 * Get all 12 tense objects as a flat array
 * @returns {Array<object>}
 */
export function getAllTenses() {
    const all = [];
    Object.keys(tensesData).forEach(key => {
        const group = tensesData[key];
        if (group && group.tenses) {
            all.push(...group.tenses);
        }
    });
    return all;
}
