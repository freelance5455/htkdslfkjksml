# Mavic Sig App — Version 1

A mobile-first, rules-based trading signal analyzer. The strategy engine is deterministic; optional AI only explains verified app state and cannot create or approve trades.

## Included
- React/Vite mobile UI: Home, Signals, Analyzer, Settings, MT5 Bridge
- Node/Express API and persistent SQLite database
- Binance BTCUSDT market feed; Twelve Data forex/XAUUSD candles and quotes
- M5/M15 EMA(50), RSI(14), configurable demand/supply zones, sweep + M15 structure-break (CHoCH) checks
- Optional Finnhub economic calendar gate; when unavailable, new entries are blocked
- Optional OpenAI explanation endpoint; never used to make trading decisions
- Manual MT5 copy bridge; no broker execution

## Requirements
- Node.js 20+
- API keys: Twelve Data (forex + XAUUSD), Finnhub (economic calendar). Optional OpenAI key for conversational explanations.
- Internet connection

## Run locally
1. Copy `.env.example` to `server/.env` and fill keys.
2. In a terminal:
   ```bash
   cd server
   npm install
   npm run dev
   ```
3. In another terminal:
   ```bash
   cd client
   npm install
   npm run dev
   ```
4. Open the Vite URL shown (usually http://localhost:5173).

SQLite database is created at `server/data/mavic.sqlite` and persists across restarts.

## Configure zones first
Open Settings → Zones. Add the exact price ranges you want monitored. Example values supplied in the brief are historical examples, not assumed-current zones. A zone requires pair, side (BUY demand / SELL supply), low and high.

## Strategy implementation and explicit assumptions
- BUY setup: demand-zone downside sweep (wick below zone low, candle closes back above zone low), followed by a closed M15 candle closing above the most recent confirmed swing high.
- SELL setup: supply-zone upside sweep (wick above zone high, candle closes back below zone high), followed by a closed M15 candle closing below the most recent confirmed swing low.
- Swing pivots use 2 candles on each side. Only closed candles are used.
- EMA50 and RSI14 must confirm on BOTH M5 and M15: BUY close above EMA50 and RSI 45–70; SELL close below EMA50 and RSI 30–55.
- Sideways filter is a conservative EMA slope check against ATR; see `server/src/strategy.js`.
- Exact entry is the close of the confirming closed M15 candle. SL is beyond the sweep extreme plus an ATR buffer. TP1 = 1R and TP2 = 2R. These are operational defaults because the brief did not define an SL/TP formula; adjust in code before live use.
- A price reaching a zone is not enough. No M15 CHoCH means no trade.
- A setup that reaches TP before a valid entry is marked MISSED only when the engine can verify the zone sweep/target path; it never recommends chasing.
- Signal status updates are evaluated from subsequent prices. This is an analyzer, not an execution system.

## News gate
Set `FINNHUB_API_KEY`. The server checks the next 60 minutes for high-impact calendar events matching Eurozone/EU, USD, CPI, ADP, FOMC, or NFP. If the calendar feed is missing or errors, the engine fails closed and does not create new signals. This keyword-based calendar filter is not a substitute for checking the broker's calendar.

## Data feed notes
- Binance provides BTCUSDT, used as the BTCUSD proxy.
- Twelve Data must support your subscribed symbols/intervals for EUR/USD, GBP/USD, USD/JPY and XAU/USD.
- Market data vendors can delay quotes, impose quotas, or have outages. The app shows feed timestamps and refuses to invent prices.
- The backend refresh loop runs every 5 seconds, but vendor requests are throttled/cached to respect API limits. It does NOT guarantee a new vendor tick every 5 seconds.

## Android APK
The client is a responsive web app. To package it:
1. Build: `cd client && npm run build`
2. Install Android Studio and Capacitor:
   ```bash
   cd client
   npm install @capacitor/core @capacitor/cli @capacitor/android
   npx cap init "Mavic Sig App" "com.mavic.sigapp"
   ```
3. Add `server.url` only for development; for production deploy the API and serve the built client from a secure HTTPS host. Then:
   ```bash
   npm run build
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
4. In Android Studio choose Build → Generate Signed Bundle / APK.

Push notifications and FBS/MT5 notification reading require native Android integration and explicit OS permissions; they are not included in this V1 web build. Android apps cannot silently read another app's notifications. Do not grant notification access to untrusted apps.

## Production checklist (required before deployment)
- Add user authentication and per-user authorization.
- Use HTTPS, secrets manager, rate limiting, backups, monitoring.
- Configure push delivery (VAPID + service worker/native plugin).
- Validate data vendor entitlements and calendar coverage.
- Backtest the exact implementation and paper-trade it. Do not rely on this app as financial advice.
