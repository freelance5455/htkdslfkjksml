const ema = (a,n) => {
 if(a.length<n) return null;
 const k=2/(n+1); let v=a.slice(0,n).reduce((x,y)=>x+y,0)/n;
 for(const x of a.slice(n)) v=x*k+v*(1-k);
 return v;
};
const rsi = (a,n=14) => {
 if(a.length<n+1) return null;
 let g=0,l=0;
 for(let i=a.length-n;i<a.length;i++){const d=a[i]-a[i-1]; if(d>0)g+=d;else l-=d;}
 if(l===0) return 100;
 return 100-100/(1+g/l);
};
const atr = (c,n=14) => {
 if(c.length<n+1)return null;
 const tr=[];
 for(let i=1;i<c.length;i++) tr.push(Math.max(c[i].high-c[i].low,Math.abs(c[i].high-c[i-1].close),Math.abs(c[i].low-c[i-1].close)));
 return tr.slice(-n).reduce((a,b)=>a+b,0)/n;
};
function pivots(c) {
 const highs=[],lows=[];
 for(let i=2;i<c.length-2;i++){
  if(c[i].high>Math.max(...c.slice(i-2,i).map(x=>x.high)) && c[i].high>=Math.max(...c.slice(i+1,i+3).map(x=>x.high))) highs.push({i,p:c[i].high});
  if(c[i].low<Math.min(...c.slice(i-2,i).map(x=>x.low)) && c[i].low<=Math.min(...c.slice(i+1,i+3).map(x=>x.low))) lows.push({i,p:c[i].low});
 }
 return {highs,lows};
}
function trend(c,dir) {
 const closes=c.map(x=>x.close), e=ema(closes,50), rv=rsi(closes,14), a=atr(c);
 if(e===null||rv===null||a===null) return {ok:false,reason:'Not enough candles for EMA50 / RSI14'};
 const last=c.at(-1);
 const emaOk=dir==='BUY'?last.close>e:last.close<e;
 const rsiOk=dir==='BUY'?rv>=45&&rv<=70:rv>=30&&rv<=55;
 const slope=Math.abs(e-ema(closes.slice(0,-5),50) || 0);
 const sideways=slope < a*0.08;
 return {ok:emaOk&&rsiOk&&!sideways,ema:e,rsi:rv,sideways,reason:sideways?'Price is sideways':!emaOk?'Price is on the wrong side of EMA50':!rsiOk?'RSI14 is outside the allowed range':'EMA50 and RSI14 confirm'};
}
export function analyzeSetup(pair,zone,m5,m15,price) {
 if(!m5.available||!m15.available||m5.candles.length<60||m15.candles.length<60)
  return {ready:false,status:'DO NOT ENTER',reason:'Price feed or candle history unavailable. No confirmation can be verified.'};
 const c=m15.candles, last=c.at(-1), piv=pivots(c);
 const recent=c.slice(-12,-1);
 let sweepIndex=-1, extreme=null, direction=zone.side;
 if(direction==='BUY') {
  for(let i=recent.length-1;i>=0;i--) if(recent[i].low<zone.low && recent[i].close>zone.low){sweepIndex=c.length-12+i;extreme=recent[i].low;break;}
 } else {
  for(let i=recent.length-1;i>=0;i--) if(recent[i].high>zone.high && recent[i].close<zone.high){sweepIndex=c.length-12+i;extreme=recent[i].high;break;}
 }
 if(sweepIndex<0) return {ready:false,status:'WAITING',reason:price.available?'Waiting for price to sweep the configured zone.':'Price feed unavailable, check TradingView'};
 const after=c.slice(sweepIndex+1);
 const priorPiv=direction==='BUY'?piv.highs.filter(x=>x.i<=sweepIndex).at(-1):piv.lows.filter(x=>x.i<=sweepIndex).at(-1);
 if(!priorPiv) return {ready:false,status:'WAITING',reason:'Zone sweep seen; waiting for a confirmed M15 swing level and CHoCH.'};
 const confirm=after.find(x=>direction==='BUY'?x.close>priorPiv.p:x.close<priorPiv.p);
 const choch=!!confirm;
 if(!choch) return {ready:false,status:'WAITING',reason:'Sweep detected. NO M15 CHoCH = NO TRADE.'};
 const t5=trend(m5.candles,direction), t15=trend(c,direction);
 if(!t5.ok||!t15.ok) return {ready:false,status:'WAITING',reason:`M15 CHoCH confirmed, but trend filter failed: M5 ${t5.reason}; M15 ${t15.reason}. Waiting — no reliable trade.`,indicators:{m5:t5,m15:t15}};
 const a=atr(c), buffer=a*0.15, entry=confirm.close;
 const sl=direction==='BUY'?extreme-buffer:extreme+buffer;
 const risk=Math.abs(entry-sl);
 if(!risk || !Number.isFinite(risk)) return {ready:false,status:'DO NOT ENTER',reason:'Invalid risk distance; no trade.'};
 const tp1=direction==='BUY'?entry+risk:entry-risk, tp2=direction==='BUY'?entry+2*risk:entry-2*risk;
 return {ready:true,status:'ACTIVE',pair,direction,zone_low:zone.low,zone_high:zone.high,entry,sl,tp1,tp2,rr:'1:2',reason:`${direction==='BUY'?'Demand':'Supply'} zone sweep + confirmed bullish/bearish M15 CHoCH + M5/M15 EMA50 and RSI14 confirmation`,indicators:{m5:t5,m15:t15},sweepExtreme:extreme};
}
export function explainNoEntry(pair,price,zone,analysis) {
 if(!price?.available) return `Nothing new — still no entry ready, ${pair}. Price feed unavailable, check TradingView. DO NOT ENTER.`;
 const away=zone?Math.max(0,zone.low-price.price,price.price-zone.high):null;
 return `Nothing new — still no entry ready, ${pair} ~${price.price}. ${analysis?.reason || (zone?'Waiting for a valid zone sweep and M15 CHoCH.':'No zone configured.')}${away!==null?` Price is ${away.toPrecision(5)} away from the zone.`:''} DO NOT ENTER.`;
}
