const pairs = {
 'EUR/USD': {td:'EUR/USD', binance:null},
 'GBP/USD': {td:'GBP/USD'},
 'XAUUSD': {td:'XAU/USD'},
 'USD/JPY': {td:'USD/JPY'},
 'BTCUSD': {binance:'BTCUSDT'}
};
const cache = new Map();
const candlesCache = new Map();
const now = () => Date.now();

async function json(url) {
 const r = await fetch(url, {headers:{'User-Agent':'MavicSigApp/1.0'}});
 if (!r.ok) throw new Error(`Provider HTTP ${r.status}`);
 const data = await r.json();
 if (data.status === 'error' || data.code) throw new Error(data.message || data.msg || 'Provider error');
 return data;
}
export async function getPrice(pair) {
 const cached = cache.get(pair);
 if (cached && now()-cached.at < 5000) return cached.value;
 try {
  let price, source;
  if (pair==='BTCUSD') {
   const d=await json('https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT');
   price=Number(d.price); source='Binance BTCUSDT';
  } else {
   const key=process.env.TWELVE_DATA_API_KEY;
   if (!key) throw new Error('Twelve Data API key not configured');
   const symbol=pairs[pair]?.td;
   if (!symbol) throw new Error('Unsupported pair');
   const d=await json(`https://api.twelvedata.com/price?symbol=${encodeURIComponent(symbol)}&apikey=${key}`);
   price=Number(d.price); source='Twelve Data';
  }
  if (!Number.isFinite(price) || price<=0) throw new Error('Invalid provider price');
  const value={pair,price,source,time:new Date().toISOString(),available:true};
  cache.set(pair,{at:now(),value}); return value;
 } catch(e) {
  const value={pair,available:false,error:e.message,time:new Date().toISOString()};
  cache.set(pair,{at:now(),value}); return value;
 }
}
export async function getCandles(pair, interval='15min', outputsize=180) {
 const k=`${pair}:${interval}`, old=candlesCache.get(k);
 // Candles are cached 60 seconds; the strategy uses closed candles only.
 if(old && now()-old.at<60000) return old.value;
 try {
  let rows, source;
  if(pair==='BTCUSD') {
   const int=interval==='5min'?'5m':'15m';
   const d=await json(`https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=${int}&limit=${Math.min(outputsize,500)}`);
   rows=d.map(x=>({time:new Date(x[0]).toISOString(),open:+x[1],high:+x[2],low:+x[3],close:+x[4],volume:+x[5],closed:Date.now()>x[6]}));
   source='Binance BTCUSDT';
  } else {
   const key=process.env.TWELVE_DATA_API_KEY;
   if(!key) throw new Error('Twelve Data API key not configured');
   const symbol=pairs[pair]?.td;
   const d=await json(`https://api.twelvedata.com/time_series?symbol=${encodeURIComponent(symbol)}&interval=${interval}&outputsize=${outputsize}&apikey=${key}`);
   if(!Array.isArray(d.values)) throw new Error(d.message || 'No candle data');
   rows=d.values.reverse().map(x=>({time:new Date(x.datetime.replace(' ','T')+'Z').toISOString(),open:+x.open,high:+x.high,low:+x.low,close:+x.close,volume:+(x.volume||0),closed:true}));
   source='Twelve Data';
  }
  const value={pair,interval,source,candles:rows.filter(x=>x.closed),available:true,time:new Date().toISOString()};
  candlesCache.set(k,{at:now(),value}); return value;
 } catch(e) {
  const value={pair,interval,available:false,error:e.message,candles:[]};
  candlesCache.set(k,{at:now(),value}); return value;
 }
}
export const supportedPairs=Object.keys(pairs);
