import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import {db,event} from './db.js';
import {getPrice,getCandles,supportedPairs} from './market.js';
import {analyzeSetup,explainNoEntry} from './strategy.js';

const app=express(); app.use(cors({origin:process.env.ALLOW_ORIGIN||'*'})); app.use(express.json());
const port=process.env.PORT||8787;
const stmt=(sql,...args)=>db.prepare(sql).all(...args);
const one=(sql,...args)=>db.prepare(sql).get(...args);
const run=(sql,...args)=>db.prepare(sql).run(...args);
const latestZone=pair=>one('SELECT * FROM zones WHERE pair=? AND enabled=1 ORDER BY created_at DESC LIMIT 1',pair);
async function newsGate(){
 const key=process.env.FINNHUB_API_KEY;
 if(!key)return {available:false,blocked:true,reason:'Economic calendar unavailable — configure FINNHUB_API_KEY. New signals are blocked.'};
 try{
  const from=new Date().toISOString().slice(0,10), to=new Date(Date.now()+86400000).toISOString().slice(0,10);
  const r=await fetch(`https://finnhub.io/api/v1/calendar/economic?from=${from}&to=${to}&token=${key}`);
  if(!r.ok)throw new Error('Calendar request failed');
  const d=await r.json(), now=Date.now();
  const hits=(d.economicCalendar||[]).filter(e=>{
   const title=(e.event||'').toLowerCase(), country=(e.country||'').toLowerCase();
   const relevant=/cpi|adp|fomc|nonfarm|non-farm|employment change/.test(title) || /euro|eur|united states|usd/.test(country)&&/inflation|employment|rate|fed/.test(title);
   const impact=String(e.impact||'').toLowerCase();
   const time=Date.parse(e.time||e.date||'');
   return relevant&&(impact.includes('high')||impact==='3')&&time>=now&&time<=now+3600000;
  });
  return {available:true,blocked:hits.length>0,events:hits.map(x=>({event:x.event,country:x.country,time:x.time})),reason:hits.length?'Headline-risk — check economic calendar before entering':'No matching high-impact event found in next hour'};
 }catch(e){return {available:false,blocked:true,reason:`Economic calendar unavailable (${e.message}); new signals are blocked.`};}
}
async function snapshot(pair){
 const [price,m5,m15]=await Promise.all([getPrice(pair),getCandles(pair,'5min'),getCandles(pair,'15min')]);
 if(price.available) run('INSERT INTO prices(pair,price,source,time) VALUES(?,?,?,?)',pair,price.price,price.source,price.time);
 return {price,m5,m15};
}
async function analyzePair(pair){
 const snap=await snapshot(pair), zone=latestZone(pair), news=await newsGate();
 if(!zone)return {pair,price:snap.price,ready:false,status:'WAITING',reason:'No active zone configured. Add a Buy/Demand or Sell/Supply zone in Settings.',news};
 const analysis=analyzeSetup(pair,zone,snap.m5,snap.m15,snap.price);
 if(analysis.ready && news.blocked)return {pair,price:snap.price,ready:false,status:'DO NOT ENTER',reason:news.reason,news,indicators:analysis.indicators};
 if(analysis.ready){
  const exists=one("SELECT id FROM signals WHERE pair=? AND status IN ('ACTIVE','TP1 HIT') AND created_at>=datetime('now','-1 day')",pair);
  if(!exists){
   run(`INSERT INTO signals(pair,direction,zone_low,zone_high,entry,sl,tp1,tp2,rr,reason,status) VALUES(?,?,?,?,?,?,?,?,?,?,?)`,
    pair,analysis.direction,analysis.zone_low,analysis.zone_high,analysis.entry,analysis.sl,analysis.tp1,analysis.tp2,analysis.rr,analysis.reason,'ACTIVE');
   event('SIGNAL_READY',`${pair} ${analysis.direction} signal created`);
  }
 }
 return {pair,price:snap.price,zone,news,...analysis};
}
async function updateStatuses(){
 const active=stmt("SELECT * FROM signals WHERE status IN ('ACTIVE','TP1 HIT')");
 for(const s of active){
  const p=await getPrice(s.pair); if(!p.available)continue;
  let status=s.status;
  if(s.direction==='BUY'){
   if(p.price<=s.sl)status='SL HIT'; else if(p.price>=s.tp2)status='TP2 HIT'; else if(p.price>=s.tp1)status='TP1 HIT';
  }else{
   if(p.price>=s.sl)status='SL HIT'; else if(p.price<=s.tp2)status='TP2 HIT'; else if(p.price<=s.tp1)status='TP1 HIT';
  }
  if(status!==s.status){
   run('UPDATE signals SET status=?,result=?,exit_price=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',status,status.includes('HIT')?status:null,p.price,s.id);
   event(status,`${s.pair} ${status} at ${p.price}`);
  }
 }
}
app.get('/health',(req,res)=>res.json({ok:true,service:'Mavic Sig App API',time:new Date().toISOString()}));
app.get('/get-prices',async(req,res)=>{const pairs=req.query.pair?[req.query.pair]:supportedPairs;res.json(await Promise.all(pairs.map(getPrice)));});
app.get('/get-candles',async(req,res)=>{const pair=req.query.pair||'EUR/USD';const interval=req.query.interval||'15min';res.json(await getCandles(pair,interval));});
app.post('/analyze',async(req,res)=>{try{const pairs=req.body.pairs||supportedPairs;res.json(await Promise.all(pairs.map(analyzePair)));}catch(e){res.status(500).json({error:e.message});}});
app.get('/get-signals',(req,res)=>res.json(stmt('SELECT * FROM signals ORDER BY id DESC LIMIT 300')));
app.post('/update-signal-status',async(req,res)=>{await updateStatuses();res.json({ok:true,signals:stmt('SELECT * FROM signals ORDER BY id DESC LIMIT 300')});});
app.get('/settings',(req,res)=>res.json(one('SELECT * FROM settings WHERE id=1')));
app.post('/save-settings',(req,res)=>{
 const b=req.body; run('UPDATE settings SET lot_size=?,risk_pct=?,notifications=?,sound=?,followed=? WHERE id=1',String(b.lot_size||'0.01'),Number(b.risk_pct??2),b.notifications?1:0,b.sound?1:0,JSON.stringify(b.followed||supportedPairs));res.json(one('SELECT * FROM settings WHERE id=1'));
});
app.get('/zones',(req,res)=>res.json(stmt('SELECT * FROM zones ORDER BY id DESC')));
app.post('/zones',(req,res)=>{
 const {pair,side,low,high}=req.body;
 if(!supportedPairs.includes(pair)||!['BUY','SELL'].includes(side)||!Number.isFinite(+low)||!Number.isFinite(+high)||+low>=+high)return res.status(400).json({error:'Invalid zone'});
 const info=run('INSERT INTO zones(pair,side,low,high) VALUES(?,?,?,?)',pair,side,+low,+high);res.json(one('SELECT * FROM zones WHERE id=?',info.lastInsertRowid));
});
app.delete('/zones/:id',(req,res)=>{run('DELETE FROM zones WHERE id=?',req.params.id);res.json({ok:true});});
app.get('/events',(req,res)=>res.json(stmt('SELECT * FROM events ORDER BY id DESC LIMIT 100')));
app.get('/stats',(req,res)=>{
 const rows=stmt("SELECT status,COUNT(*) n FROM signals GROUP BY status");
 const closed=one("SELECT COUNT(*) n FROM signals WHERE status IN ('TP2 HIT','SL HIT')");
 const wins=one("SELECT COUNT(*) n FROM signals WHERE status='TP2 HIT'");
 const week=one("SELECT COUNT(*) n FROM signals WHERE created_at>=datetime('now','-7 days')");
 res.json({byStatus:Object.fromEntries(rows.map(x=>[x.status,x.n])),today:one("SELECT COUNT(*) n FROM signals WHERE date(created_at)=date('now')")?.n||0,week:week.n||0,wins:wins.n||0,closed:closed.n||0,winRate:closed.n?100*wins.n/closed.n:0});
});
app.post('/assistant',async(req,res)=>{
 const {question,pair='EUR/USD'}=req.body; const p=await getPrice(pair), zone=latestZone(pair);
 const recent=one('SELECT * FROM signals WHERE pair=? ORDER BY id DESC LIMIT 1',pair);
 const context=`Pair ${pair}; price ${p.available?p.price:'UNAVAILABLE'}; zone ${zone?`${zone.side} ${zone.low}-${zone.high}`:'not configured'}; latest signal ${recent?`${recent.direction} ${recent.status}`:'none'}.`;
 if(process.env.OPENAI_API_KEY){
  try{
   const r=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:'gpt-4o-mini',messages:[{role:'system',content:'You are Mavic, a cautious trading assistant. Explain only the supplied verified app state. Never invent prices, signals, or confirmations. You cannot override the rules engine. If price is unavailable say exactly: Price feed unavailable, check TradingView. This is not financial advice.'},{role:'user',content:`${context}\nQuestion: ${question}`}],temperature:0.2})});
   const d=await r.json(); if(r.ok)return res.json({answer:d.choices?.[0]?.message?.content||'No answer returned.'});
  }catch{}
 }
 res.json({answer:!p.available?'Price feed unavailable, check TradingView.':`Nothing new — still no entry ready, ${pair} ~${p.price}. ${zone?'A live zone is configured; the rules engine must confirm sweep, M15 CHoCH, EMA50 and RSI14.':'No zone configured yet.'} DO NOT ENTER. AI explanation key is optional; this response uses verified app data only.`});
});
setInterval(()=>updateStatuses().catch(e=>console.error('status loop',e)),5000);
app.listen(port,()=>console.log(`Mavic Sig API listening on ${port}`));
