import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.resolve(here, '../data');
fs.mkdirSync(dataDir, {recursive:true});
export const db = new Database(path.join(dataDir, 'mavic.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS settings (
 id INTEGER PRIMARY KEY CHECK(id=1), lot_size TEXT NOT NULL DEFAULT '0.01',
 risk_pct REAL NOT NULL DEFAULT 2, notifications INTEGER NOT NULL DEFAULT 1,
 sound INTEGER NOT NULL DEFAULT 1, followed TEXT NOT NULL DEFAULT '["EUR/USD","GBP/USD","XAUUSD","USD/JPY","BTCUSD"]'
);
INSERT OR IGNORE INTO settings(id) VALUES(1);
CREATE TABLE IF NOT EXISTS zones (
 id INTEGER PRIMARY KEY AUTOINCREMENT, pair TEXT NOT NULL, side TEXT NOT NULL,
 low REAL NOT NULL, high REAL NOT NULL, enabled INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS signals (
 id INTEGER PRIMARY KEY AUTOINCREMENT, pair TEXT NOT NULL, direction TEXT NOT NULL,
 zone_low REAL NOT NULL, zone_high REAL NOT NULL, entry REAL NOT NULL, sl REAL NOT NULL,
 tp1 REAL NOT NULL, tp2 REAL NOT NULL, rr TEXT NOT NULL, reason TEXT NOT NULL,
 status TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 result TEXT, exit_price REAL, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS prices (
 id INTEGER PRIMARY KEY AUTOINCREMENT, pair TEXT NOT NULL, price REAL NOT NULL,
 source TEXT NOT NULL, time TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_prices_pair_time ON prices(pair,time);
CREATE TABLE IF NOT EXISTS events (
 id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, message TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);
export function event(kind,message) {
 db.prepare('INSERT INTO events(kind,message) VALUES(?,?)').run(kind,message);
}
