# kisu-game-booster Android build

Use Node 22+, Android Studio and the Java/Android SDK versions required by Capacitor 7 (JDK 21).

1. Run `npm install`.
2. Run `npm run build`.
3. Generate the native project with `npx cap add android`. This repository contains documentation only under android; if the CLI refuses the existing documentation directory, move this README outside it before adding Android, then restore it.
4. Run `npx cap sync android`.
5. Run `npx cap open android` or build from the generated project with Gradle.

Verify these permissions in the generated app/src/main/AndroidManifest.xml, directly under <manifest>:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.VIBRATE" />
```

These are normal permissions, not runtime prompts. Plugin manifests may merge them automatically. Do not request QUERY_ALL_PACKAGES, usage access, accessibility access, notification policy access, overlay, storage or task-killing permissions.

App ID: com.kisufire.kisugamebooster. Display name: kisu-game-booster.

Game and settings links use best-effort intent URLs from the WebView. Capacitor/OEM WebViews may block these links. There is no custom intent plugin and no guarantee that a shortcut opens. The UI provides manual fallback instructions and never claims settings were changed. Test on target devices before distribution. No installed-package scanning is performed.

Battery readings use Capacitor Device with a browser Battery API fallback. Network type is not a latency or speed measurement. Checklist progress is user-confirmed, not performance telemetry. The app performs no RAM clearing, FPS manipulation, CPU control, injection or game modification.

Library data uses Capacitor Preferences on Android. Browser storage and the standalone preview have separate local data. No backend, analytics or account is included. The SVG is an in-app logo; Android launcher icons remain generated defaults until explicitly replaced in Android Studio.

For the browser demo, open preview.html directly. It is fully self-contained and clearly labels preview-only behavior.
