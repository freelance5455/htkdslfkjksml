import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = { appId: 'com.kisufire.kisugamebooster', appName: 'kisu-game-booster', webDir: 'dist' };
export default config;
