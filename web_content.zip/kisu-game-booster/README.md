# kisu-game-booster

- Real device model and operating system information
- Battery and network status when supported
- User-confirmed gaming preparation checklist
- Haptic feedback on preparation
- Locally persisted game names and Android package IDs
- Best-effort Android launcher and settings intent links with manual fallback instructions
- Offline self-contained browser preview
- No accounts, analytics or remote backend

Generated with KisuFire AI. This archive contains source code only — it has not been compiled.

## Requirements
- Node.js 20+
- For Android: Java 17, Android Studio / Android SDK

## Run in the browser
```bash
npm install
npm run dev
```

## Build an Android APK
```bash
npm run build
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
```
The APK appears in `android/app/build/outputs/apk/debug/`.

## Android permissions
- android.permission.INTERNET
- android.permission.ACCESS_NETWORK_STATE
- android.permission.VIBRATE

## Known limitations
- Cannot increase FPS, free other apps' RAM, cool hardware, change CPU clocks or guarantee improved performance.
- No cheats, injection, memory editing or modification of other apps.
- Battery and network data depend on platform support; unavailable data is explicitly labeled.
- Game and settings intent URLs are best-effort; some Android WebViews block them. No custom native intent plugin is included.
- The app cannot verify that a game is installed or that system settings were changed.
- DND and battery settings must be changed manually by the user. No DND policy access is requested.
- Browser preview does not launch installed Android games or change system settings.

## Dependencies
- react ^18.3.1
- react-dom ^18.3.1
- @capacitor/core ^7.0.0
- @capacitor/android ^7.0.0
- @capacitor/app ^7.0.0
- @capacitor/device ^7.0.0
- @capacitor/network ^7.0.0
- @capacitor/haptics ^7.0.0
- @capacitor/preferences ^7.0.0
- vite ^6.0.0
- @vitejs/plugin-react ^4.3.4
- typescript ^5.7.2
- @types/react ^18.3.12
- @types/react-dom ^18.3.1
- @capacitor/cli ^7.0.0

## Environment
Copy `.env.example` to `.env` and fill in any values you need. Never commit real secrets.
