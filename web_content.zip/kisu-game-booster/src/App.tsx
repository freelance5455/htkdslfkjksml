import { useEffect, useRef, useState } from 'react';
import { App as NativeApp } from '@capacitor/app';
import { Capacitor } from '@capacitor/core';
import BottomNav, { type Tab } from './components/BottomNav';
import Home from './screens/Home';import Games from './screens/Games';import Guide from './screens/Guide';
import { initialStatus, readStatus } from './services/device';
import { loadGames, saveGames, type Game } from './services/storage';
import { pulse } from './services/actions';
export default function App() {
 const [tab,setTab]=useState<Tab>('Home');const tabRef=useRef(tab);tabRef.current=tab;
 const [status,setStatus]=useState(initialStatus);const [games,setGames]=useState<Game[]>([]);const [ready,setReady]=useState(false);const [checks,setChecks]=useState([false,false,false]);const [toast,setToast]=useState('');const [review,setReview]=useState(false);
 const refresh=async()=>setStatus(await readStatus());
 useEffect(()=>{let live=true;const read=()=>readStatus().then(s=>{if(live)setStatus(s);});void read();void loadGames().then(g=>{if(live){setGames(g);setReady(true);}}).catch(()=>{if(live)setToast('Could not load saved games. Restart the app to retry; existing data will not be overwritten.');});const interval=window.setInterval(read,30000);return()=>{live=false;clearInterval(interval);};},[]);
 useEffect(()=>{if(!toast)return;const id=setTimeout(()=>setToast(''),6500);return()=>clearTimeout(id);},[toast]);
 useEffect(()=>{if(!Capacitor.isNativePlatform())return;const p=NativeApp.addListener('backButton',()=>{if(tabRef.current!=='Home')setTab('Home');else NativeApp.exitApp();});return()=>{void p.then(h=>h.remove());};},[]);
 async function update(next:Game[]) {try{await saveGames(next);setGames(next);return true;}catch{setToast('Could not save. Your library has not been changed.');return false;}}
 return <><header className="app-header"><img src={new URL('./assets/logo.svg',import.meta.url).href} alt=""/><div><strong>kisu<span> / </span>game booster</strong><small>MAKE ROOM FOR PLAY</small></div><span className="header-badge">K</span></header><main>{tab==='Home'?<Home status={status} checks={checks} setChecks={setChecks} refresh={()=>{void refresh();setToast('Refreshing available device readings.');}} prepare={()=>{void pulse();setReview(true);}}/>:tab==='Games'?<Games games={games} update={update} notify={setToast} ready={ready}/>:<Guide notify={setToast}/>}</main><BottomNav tab={tab} onChange={t=>{setTab(t);window.scrollTo(0,0);}}/>{toast&&<div className="toast" role="status">{toast}<button aria-label="Dismiss message" onClick={()=>setToast('')}>×</button></div>}{review&&<div className="modal-backdrop"><section className="modal" role="dialog" aria-modal="true" aria-labelledby="review-title"><span className="eyebrow">SAFE GAMING PREPARATION</span><h2 id="review-title">Your setup, your control.</h2><p>{checks.filter(Boolean).length} of 3 checklist items confirmed. Review the checklist on Home, then use Guide to open system settings if needed.</p><p className="muted">No apps were closed, no settings were changed and no FPS or RAM boost was applied.</p><button autoFocus className="primary wide" onClick={()=>{setReview(false);setTab('Guide');}}>Explore settings & tips</button><button className="secondary wide" onClick={()=>setReview(false)}>Back to checklist</button></section></div>}</>;
}
