import { Preferences } from '@capacitor/preferences';
export type Game = {id:string;name:string;packageId:string};
export async function loadGames(): Promise<Game[]> {
  const { value } = await Preferences.get({key:'kisu.games'});
  if (!value) return [];
  const data: unknown = JSON.parse(value);
  if (!Array.isArray(data)) throw new Error('Invalid library');
  return data.filter((g): g is Game => !!g && typeof g.id === 'string' && typeof g.name === 'string' && typeof g.packageId === 'string' && /^[a-zA-Z][\w]*(\.[a-zA-Z][\w]*)+$/.test(g.packageId));
}
export async function saveGames(games:Game[]) { await Preferences.set({key:'kisu.games',value:JSON.stringify(games)}); }
