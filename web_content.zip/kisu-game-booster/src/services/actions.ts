import { Capacitor } from '@capacitor/core';
import { Haptics, ImpactStyle } from '@capacitor/haptics';
export async function pulse() { try { await Haptics.impact({style:ImpactStyle.Light}); } catch {} }
export function openIntent(kind:'battery'|'dnd'|'game', notify:(message:string)=>void, packageId?:string) {
  if (!Capacitor.isNativePlatform()) { notify('Preview: on Android this attempts a system shortcut. No settings or apps were changed.'); return; }
  if (kind === 'game' && (!packageId || !/^[a-zA-Z][\w]*(\.[a-zA-Z][\w]*)+$/.test(packageId))) {notify('Enter a valid Android package ID.');return;}
  notify(kind === 'game' ? 'Trying game shortcut. If nothing opens, launch the game from your home screen.' : 'Trying settings shortcut. If blocked, open Android Settings manually.');
  const url = kind === 'game' ? `intent:#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;package=${packageId};end` : `intent:#Intent;action=android.settings.${kind === 'battery' ? 'BATTERY_SAVER_SETTINGS' : 'ZEN_MODE_SETTINGS'};end`;
  const a = document.createElement('a'); a.href=url; document.body.appendChild(a); a.click(); a.remove();
}
