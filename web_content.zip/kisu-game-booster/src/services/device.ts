import { Device } from '@capacitor/device';
import { Network } from '@capacitor/network';
import { Capacitor } from '@capacitor/core';
export type Status = { model: string; os: string; battery: string; network: string; charging: string; native: boolean };
export const initialStatus: Status = {model:'Checking device',os:'Checking system',battery:'Checking',network:'Checking',charging:'Battery status',native:Capacitor.isNativePlatform()};
export async function readStatus(): Promise<Status> {
  const s: Status = {...initialStatus,model:'Browser device',os:'Web preview',battery:'Unavailable',network:'Unavailable',charging:'Battery status'};
  try { const i = await Device.getInfo(); s.model = i.model || 'Android device'; s.os = `${i.operatingSystem} ${i.osVersion}`; } catch {}
  try { const b = await Device.getBatteryInfo(); if (typeof b.batteryLevel === 'number') { s.battery = `${Math.round(b.batteryLevel * 100)}%`; s.charging = b.isCharging ? 'Charging' : 'On battery'; } } catch {}
  if (s.battery === 'Unavailable') { try { const n = navigator as Navigator & {getBattery?:()=>Promise<{level:number;charging:boolean}>}; const b = await n.getBattery?.(); if (b) {s.battery = `${Math.round(b.level*100)}%`;s.charging=b.charging?'Charging':'On battery';} } catch {} }
  try { const n = await Network.getStatus(); s.network = n.connected ? (n.connectionType === 'unknown' ? 'Connected' : n.connectionType.toUpperCase()) : 'Offline'; } catch {}
  return s;
}
