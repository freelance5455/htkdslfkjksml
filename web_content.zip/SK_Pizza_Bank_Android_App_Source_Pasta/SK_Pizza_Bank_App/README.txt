SK Pizza Bank — Android WebView starter project

Included:
- index.html: responsive menu + cart + WhatsApp ordering + in-app order summary
- assets/sk-pizza-bank-logo.png: stylized SK Pizza Bank logo based on the supplied logo photo
- assets/original-menu-reference.jpg: original menu photo for reference

Menu items and prices are transcribed from the supplied photo. Please verify any unclear print before publishing. WhatsApp ordering currently opens a chat to 0309-9572934. The second number from the menu is 0345-6722511.

IMPORTANT:
This ZIP is the app source, not a compiled APK. An APK needs to be built using an Android WebView project or a phone-based builder such as Kodular / AndroidIDE. To package it, copy index.html and the assets folder into the WebView app's local assets folder and load file:///android_asset/index.html. Enable JavaScript and internet access (for WhatsApp links). Test on your phone before publishing.
