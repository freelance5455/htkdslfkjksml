<?php
session_start();
// সার্ভার যেন টাইমআউট না করে
set_time_limit(0); 
ini_set('max_execution_time', 300);
ini_set('memory_limit', '512M');

$host = 'localhost';
$username = 'ecobdhwl_ecobcpanel';
$password = 'ecobshakil1234';
$dbname = 'ecobdhwl_ecob_database';

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("❌ Database Connection Error");
}

$conn->set_charset("utf8mb4");

// --- TAB / FILTER LOGIC ---
$active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'overall';

if ($active_tab == 'season1') {
    $header_title = "SEASON 1 - 2026 LEADERBOARD";
    $header_tagline = "Season 1 (2026) competitive rankings & player stats";
} else {
    $header_title = "OVERALL RANKINGS";
    $header_tagline = "All-time leaderboard of eFootball Community Of Bangladesh";
}

// --- SEARCH LOGIC ---
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$search_where = "";

if (!empty($search)) {
    $search_safe = $conn->real_escape_string($search);
    $search_where = " WHERE (reg.player_name LIKE '%$search_safe%' OR c.club_name LIKE '%$search_safe%') ";
}

// --- PAGINATION LOGIC ---
$limit = 150; 
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
$offset = ($page - 1) * $limit;

$count_sql = "SELECT COUNT(r.rank) AS total 
              FROM player_ranking2 r
              LEFT JOIN player_register reg ON r.player_id = reg.player_id
              LEFT JOIN club_register c ON reg.club_id = c.id
              $search_where";

$total_result = $conn->query($count_sql);
$total_rows = $total_result ? $total_result->fetch_assoc()['total'] : 0;
$total_pages = ceil($total_rows / $limit);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Player Ranking — ECOB</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    
    <style>
        :root {
            --bg-color: #000000; --text-color: #ffffff; --text-muted: #94a3b8;
            --border-color: #27272a; --card-bg: #121212;
            --input-bg: #18181b; --btn-bg: #3b82f6; --btn-hover: #2563eb;
            --item-hover: rgba(255, 255, 255, 0.05);
            --skeleton-bg: #1e1e1e;
            --tab-active-bg: #3b82f6;
            --tab-active-text: #ffffff;
            --table-hover: rgba(255,255,255,0.02);
        }

        body.light-mode {
            --bg-color: #f8fafc; --text-color: #0f172a; --text-muted: #64748b;
            --border-color: #e2e8f0; --card-bg: #ffffff;
            --input-bg: #f1f5f9; --btn-bg: #3b82f6; --btn-hover: #2563eb;
            --item-hover: rgba(0, 0, 0, 0.03);
            --skeleton-bg: #e2e8f0;
            --tab-active-bg: #0f172a;
            --tab-active-text: #ffffff;
            --table-hover: #f8fafc;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; -webkit-tap-highlight-color: transparent; transition: background-color 0.3s, color 0.3s, border-color 0.3s; }

        body {
            background-color: var(--bg-color);
            color: var(--text-color);
            padding: 16px 10px;
            min-height: 100vh;
            display: flex;
            justify-content: center;
        }

        .ranking-container {
            max-width: 800px;
            width: 100%;
            padding: 0 5px;
        }

        .header-section { margin-bottom: 16px; }
        .header-title { font-size: 20px; font-weight: 800; color: var(--text-color); letter-spacing: -0.5px; text-transform: uppercase; }
        .header-tagline { font-size: 12px; color: var(--text-muted); font-weight: 500; margin-top: 4px; }

        /* Search */
        .search-container { margin-bottom: 16px; }
        .search-form { display: flex; gap: 8px; width: 100%; }
        .search-input-wrap { position: relative; flex-grow: 1; }
        .search-input {
            width: 100%; padding: 12px 14px 12px 38px; font-size: 14px; font-weight: 500;
            border: 1px solid var(--border-color); border-radius: 10px; background-color: var(--input-bg);
            color: var(--text-color); outline: none;
        }
        .search-input:focus { border-color: #3b82f6; }
        .search-icon { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); width: 16px; height: 16px; fill: var(--text-muted); pointer-events: none; }
        .search-btn { padding: 12px 18px; background-color: var(--btn-bg); color: #fff; font-size: 14px; font-weight: 700; border: none; border-radius: 10px; cursor: pointer; white-space: nowrap; }
        .search-btn:active { background-color: var(--btn-hover); }
        .clear-btn { padding: 12px 14px; background-color: var(--card-bg); color: var(--text-muted); font-size: 14px; font-weight: 600; border: 1px solid var(--border-color); border-radius: 10px; text-decoration: none; display: flex; align-items: center; cursor: pointer; }

        /* Tabs */
        .filter-nav { display: flex; gap: 8px; margin-bottom: 16px; overflow-x: auto; padding-bottom: 5px; scrollbar-width: none; }
        .filter-nav::-webkit-scrollbar { display: none; }
        .btn-tab {
            padding: 8px 16px; border-radius: 8px; font-size: 13px; font-weight: 600; cursor: pointer; text-decoration: none;
            white-space: nowrap; border: 1px solid var(--border-color); background-color: var(--card-bg); color: var(--text-muted);
            display: inline-flex; align-items: center; justify-content: center;
        }
        .btn-tab.active { background-color: var(--tab-active-bg); color: var(--tab-active-text); border-color: var(--tab-active-bg); }

        /* Table */
        .table-responsive { width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch; border: 1px solid var(--border-color); border-radius: 12px; background: var(--card-bg); }
        table { width: 100%; border-collapse: collapse; min-width: 450px; table-layout: fixed; }
        thead th { background-color: var(--card-bg); color: var(--text-muted); padding: 12px 4px; font-size: 11px; font-weight: 700; text-transform: uppercase; border-bottom: 1px solid var(--border-color); text-align: center; }
        thead th:nth-child(2) { text-align: left; padding-left: 10px; }
        
        tbody tr { border-bottom: 1px solid var(--border-color); transition: background 0.2s; }
        tbody tr:hover { background-color: var(--table-hover); }
        tbody tr:last-child { border-bottom: none; }
        tbody td { padding: 10px 4px; font-size: 13px; color: var(--text-color); text-align: center; vertical-align: middle; }

        .rank-num { font-size: 14px; font-weight: 700; color: var(--text-muted); }
        .player-cell { display: flex; align-items: center; gap: 10px; text-align: left; }
        .player-avatar { width: 38px; height: 38px; border-radius: 50%; object-fit: cover; border: 2px solid var(--border-color); background: var(--input-bg); flex-shrink: 0; }
        .player-meta { display: flex; flex-direction: column; justify-content: center; overflow: hidden; width: 100%; }
        .player-name-wrap { display: flex; align-items: center; gap: 4px; overflow: hidden; }
        
        .player-name { 
            font-size: 14px; font-weight: 700; color: var(--text-color); text-decoration: none; 
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis; cursor: pointer;
        }
        
        .player-club-wrap { display: flex; align-items: center; gap: 4px; overflow: hidden; margin-top: 2px; }
        .player-club { font-size: 11px; color: var(--text-muted); font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .verified-badge { width: 12px; height: 12px; fill: #3b82f6; flex-shrink: 0; }

        .pts-val { font-weight: 800; color: var(--text-color); font-size: 13px; }
        .stat-val { font-weight: 600; color: var(--text-muted); }

        /* Pagination */
        .pagination-container { display: flex; justify-content: center; align-items: center; gap: 6px; margin-top: 20px; flex-wrap: wrap; }
        .pagination-btn { display: inline-flex; align-items: center; justify-content: center; min-width: 34px; height: 34px; padding: 0 10px; border-radius: 8px; background: var(--card-bg); color: var(--text-color); text-decoration: none; font-size: 13px; font-weight: 600; border: 1px solid var(--border-color); cursor: pointer; }
        .pagination-btn.active { background: var(--btn-bg); color: #fff; border-color: var(--btn-bg); }
        .pagination-btn.disabled { opacity: 0.4; pointer-events: none; }
        .pagination-dots { color: var(--text-muted); }
        .footer-info { text-align: center; color: var(--text-muted); margin-top: 15px; font-size: 12px; font-weight: 500; }

        /* Back Button */
        .back-btn {
            color: var(--text-color); background: var(--card-bg); padding: 8px 14px; 
            border-radius: 8px; text-decoration: none; font-size: 13px; font-weight: 600; 
            border: 1px solid var(--border-color); display: inline-block; cursor: pointer;
        }

        /* ================= SKELETON LOADING ================= */
        .skeleton { background-color: var(--skeleton-bg); border-radius: 6px; animation: pulse 1.5s infinite ease-in-out; }
        @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.4; } 100% { opacity: 1; } }

        .skeleton-title { width: 50%; height: 20px; margin-bottom: 8px; }
        .skeleton-subtitle { width: 70%; height: 14px; margin-bottom: 20px; }
        .skeleton-search { width: 100%; height: 44px; margin-bottom: 20px; border-radius: 10px; }
        .skeleton-tabs { width: 100%; height: 34px; margin-bottom: 20px; border-radius: 8px; }
        .skeleton-table { width: 100%; height: 300px; border-radius: 12px; }
        
        #realContent { display: none; }
    </style>
</head>
<body>

    <div class="ranking-container">
        
        <!-- ১. SKELETON LOADING -->
        <div id="skeletonLoader">
            <div class="skeleton skeleton-title"></div>
            <div class="skeleton skeleton-subtitle"></div>
            <div class="skeleton skeleton-search"></div>
            <div class="skeleton skeleton-tabs"></div>
            <div class="skeleton skeleton-table"></div>
        </div>

        <!-- ২. আসল ডেটা -->
        <div id="realContent">
            
            <!-- Back Button -->
            <div style="margin-bottom: 15px;">
                <span class="back-btn" onclick="window.location.href='dashboard.php'">← Back</span>
            </div>

            <div class="header-section">
                <h1 class="header-title"><?php echo $header_title; ?></h1>
                <p class="header-tagline"><?php echo $header_tagline; ?></p>
            </div>

            <!-- SEARCH BOX -->
            <div class="search-container">
                <form action="" method="GET" class="search-form">
                    <input type="hidden" name="tab" value="<?php echo htmlspecialchars($active_tab); ?>">
                    <div class="search-input-wrap">
                        <svg class="search-icon" viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>
                        <input type="text" name="search" class="search-input" placeholder="Search player or club..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <button type="submit" class="search-btn">Search</button>
                    
                    <!-- Clear Button -->
                    <?php if (!empty($search)): ?>
                        <span onclick="window.location.href='?tab=<?php echo htmlspecialchars($active_tab); ?>'" class="clear-btn">Clear</span>
                    <?php endif; ?>
                </form>
            </div>

            <!-- Tabs -->
            <div class="filter-nav">
                <span onclick="window.location.href='?tab=overall<?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>'" class="btn-tab <?php echo ($active_tab == 'overall') ? 'active' : ''; ?>" style="cursor: pointer;">
                    🏆 Overall Rank
                </span>
                <span onclick="window.location.href='?tab=season1<?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>'" class="btn-tab <?php echo ($active_tab == 'season1') ? 'active' : ''; ?>" style="cursor: pointer;">
                    ⚡ Season 1-2026
                </span>
            </div>

            <!-- Table -->
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th style="width: 8%;">#</th>
                            <th style="width: 56%;">Player</th>
                            <th style="width: 12%;">PL</th>
                            <th style="width: 12%;">W</th>
                            <th style="width: 12%;">PTS</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql = "SELECT 
                                    r.rank, r.player_id, r.pl, r.w, r.pts,
                                    reg.player_name, reg.image_link,
                                    c.club_name
                                FROM player_ranking2 r
                                LEFT JOIN player_register reg ON r.player_id = reg.player_id
                                LEFT JOIN club_register c ON reg.club_id = c.id
                                $search_where
                                ORDER BY r.rank ASC
                                LIMIT $limit OFFSET $offset";
                        
                        $result = $conn->query($sql);

                        if ($result && $result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                $rank = $row['rank'];
                                $player_id = htmlspecialchars($row['player_id']);
                                $player_name = htmlspecialchars($row['player_name'] ?? 'Unknown Player');
                                $image_link = htmlspecialchars($row['image_link'] ?? '');
                                $club_name = htmlspecialchars($row['club_name'] ?? '');
                                $pl = $row['pl']; $w = $row['w']; $pts = $row['pts'];

                                if (empty($image_link)) {
                                    $image_link = 'https://ui-avatars.com/api/?name=' . urlencode($player_name) . '&background=f1f5f9&color=0f172a&bold=true&size=50';
                                }
                                ?>
                                <tr>
                                    <td class="rank-num"><?php echo $rank; ?></td>
                                    <td>
                                        <div class="player-cell">
                                            <img src="<?php echo $image_link; ?>" alt="<?php echo $player_name; ?>" class="player-avatar" loading="lazy" onerror="this.src='https://ui-avatars.com/api/?name=<?php echo urlencode($player_name); ?>&background=f1f5f9&color=0f172a&bold=true&size=50'">
                                            <div class="player-meta">
                                                <div class="player-name-wrap">
                                                    <span class="player-name" onclick="window.location.href='my-ranking.php?id=<?php echo $player_id; ?>'" title="<?php echo $player_name; ?>">
                                                        <?php echo $player_name; ?>
                                                    </span>
                                                    <svg class="verified-badge" viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/></svg>
                                                </div>
                                                <div class="player-club-wrap">
                                                    <?php if (!empty($club_name)): ?>
                                                        <span class="player-club"><?php echo $club_name; ?></span>
                                                    <?php else: ?>
                                                        <span class="player-club no-club">Without Club</span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="stat-val"><?php echo $pl; ?></td>
                                    <td class="stat-val"><?php echo $w; ?></td>
                                    <td class="pts-val"><?php echo $pts; ?></td>
                                </tr>
                                <?php
                            }
                        } else {
                            echo '<tr><td colspan="5" style="padding: 30px; color: #64748b;">❌ No results found matching "' . htmlspecialchars($search) . '"</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
            <div class="pagination-container">
                <?php $search_param = !empty($search) ? '&search=' . urlencode($search) : ''; ?>
                <span onclick="window.location.href='?tab=<?php echo $active_tab . $search_param; ?>&page=<?php echo $page - 1; ?>'" class="pagination-btn <?php echo ($page <= 1) ? 'disabled' : ''; ?>">« Prev</span>

                <?php if ($page > 2): ?>
                    <span onclick="window.location.href='?tab=<?php echo $active_tab . $search_param; ?>&page=1'" class="pagination-btn">1</span>
                    <?php if ($page > 3): ?><span class="pagination-dots">...</span><?php endif; ?>
                <?php endif; ?>

                <?php
                $start = max(1, $page - 1);
                $end = min($total_pages, $page + 1);
                for ($i = $start; $i <= $end; $i++):
                ?>
                    <span onclick="window.location.href='?tab=<?php echo $active_tab . $search_param; ?>&page=<?php echo $i; ?>'" class="pagination-btn <?php echo ($i == $page) ? 'active' : ''; ?>"><?php echo $i; ?></span>
                <?php endfor; ?>

                <?php if ($page < $total_pages - 1): ?>
                    <?php if ($page < $total_pages - 2): ?><span class="pagination-dots">...</span><?php endif; ?>
                    <span onclick="window.location.href='?tab=<?php echo $active_tab . $search_param; ?>&page=<?php echo $total_pages; ?>'" class="pagination-btn"><?php echo $total_pages; ?></span>
                <?php endif; ?>

                <span onclick="window.location.href='?tab=<?php echo $active_tab . $search_param; ?>&page=<?php echo $page + 1; ?>'" class="pagination-btn <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>">Next »</span>
            </div>
            <?php endif; ?>

            <div class="footer-info">Total Players: <?php echo $total_rows; ?> | Page <?php echo $page; ?> of <?php echo max(1, $total_pages); ?></div>
        </div>

    </div>

    <script>
        // ---- লোডিং সিমুলেশন ----
        window.addEventListener('load', function() {
            setTimeout(function() {
                document.getElementById('skeletonLoader').style.display = 'none';
                document.getElementById('realContent').style.display = 'block';
            }, 1000); 
        });

        // ---- থিম সিস্টেম ----
        window.onload = function() {
            var savedTheme = localStorage.getItem('ecob-theme');
            if (savedTheme === 'light') {
                document.body.classList.add('light-mode');
            } else if (savedTheme === 'system' || !savedTheme) {
                if (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches) {
                    document.body.classList.add('light-mode');
                }
            }
        };
    </script>

</body>
</html>