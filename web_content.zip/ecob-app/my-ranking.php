<?php
session_start();
// error_reporting(E_ALL);
// ini_set('display_errors', 1);

$host = 'localhost';
$username = 'ecobdhwl_ecobcpanel';
$password = 'ecobshakil1234';
$dbname = 'ecobdhwl_ecob_database';

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("❌ Database Connection Error");
}

$conn->set_charset("utf8mb4");

// --- লজিক আপডেট: অন্য প্লেয়ারের আইডি থাকলে সেটা নেবে, নাহলে নিজের ---
$profile_id = isset($_GET['id']) ? trim($_GET['id']) : '';

if (!empty($profile_id)) {
    $player_id = $profile_id;
} else {
    $player_id = $_SESSION['player_id'] ?? '';
}

if (empty($player_id)) {
    header("Location: login.php");
    exit;
}

$logged_in_id = $_SESSION['player_id'] ?? '';

// 1. Fetch Player Personal Info & Overall Rank
$stmt = $conn->prepare("
    SELECT 
        pr.player_id, pr.player_name, pr.image_link, pr.konami_user_id, 
        pr.device_name, pr.fb_link, pr.country, pr.district, pr.blood,
        rk.rank, rk.motm
    FROM player_register pr
    LEFT JOIN player_ranking2 rk ON pr.player_id = rk.player_id
    WHERE pr.player_id = ?
");
$stmt->bind_param("s", $player_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $player = $result->fetch_assoc();
} else {
    die("❌ Player not found.");
}
$stmt->close();

// 2. Fetch & Calculate Overall Stats
$pl = $w = $d = $l = $gf = $ga = 0;
$hat_trick = 0;
$double_hat_trick = 0;

$stmt_rank = $conn->prepare("
    SELECT player_id_home, player_score_home, player_score_away, player_id_away 
    FROM player_ranking 
    WHERE player_id_home = ? OR player_id_away = ?
");
$stmt_rank->bind_param("ss", $player_id, $player_id);
$stmt_rank->execute();
$rank_result = $stmt_rank->get_result();

while ($row = $rank_result->fetch_assoc()) {
    $pl++;
    $is_home = ($row['player_id_home'] === $player_id);
    
    $p_score = $is_home ? (int)$row['player_score_home'] : (int)$row['player_score_away'];
    $o_score = $is_home ? (int)$row['player_score_away'] : (int)$row['player_score_home'];
    
    $gf += $p_score;
    $ga += $o_score;
    
    if ($p_score > $o_score) { $w++; } 
    elseif ($p_score == $o_score) { $d++; } 
    else { $l++; }
    
    if ($p_score >= 6) { $double_hat_trick++; } 
    elseif ($p_score >= 3) { $hat_trick++; }
}
$stmt_rank->close();

$s2026_rank = 'Unranked';
$s2026_w = 0;

if ($pl > 0) {
    $stmt_s2026 = $conn->prepare("SELECT rank, w FROM player_ranking2 WHERE player_id = ?");
    $stmt_s2026->bind_param("s", $player_id);
    $stmt_s2026->execute();
    $res_s2026 = $stmt_s2026->get_result();

    if ($res_s2026 && $res_s2026->num_rows > 0) {
        $row_s2026 = $res_s2026->fetch_assoc();
        $s2026_rank = !empty($row_s2026['rank']) ? '#' . htmlspecialchars($row_s2026['rank'], ENT_QUOTES, 'UTF-8') : 'Unranked';
        $s2026_w = (int)($row_s2026['w'] ?? 0);
    }
    $stmt_s2026->close();
}

// 3. Fetch Last 5 Matches Form
$stmt_last5 = $conn->prepare("
    SELECT player_id_home, player_score_home, player_score_away, player_id_away 
    FROM player_ranking 
    WHERE player_id_home = ? OR player_id_away = ?
    ORDER BY id DESC LIMIT 5
");
$stmt_last5->bind_param("ss", $player_id, $player_id);
$stmt_last5->execute();
$last5_result = $stmt_last5->get_result();

$last5_form = [];
$last5_wins = 0;

while ($row = $last5_result->fetch_assoc()) {
    $is_home = ($row['player_id_home'] === $player_id);
    $p_score = $is_home ? (int)$row['player_score_home'] : (int)$row['player_score_away'];
    $o_score = $is_home ? (int)$row['player_score_away'] : (int)$row['player_score_home'];

    if ($p_score > $o_score) { $last5_form[] = 'W'; $last5_wins++; } 
    elseif ($p_score == $o_score) { $last5_form[] = 'D'; } 
    else { $last5_form[] = 'L'; }
}
$stmt_last5->close();

if ($pl == 0) { $player_category = 'E'; } 
elseif ($last5_wins >= 4) { $player_category = 'A+'; } 
elseif ($last5_wins == 3) { $player_category = 'B'; } 
elseif ($last5_wins >= 1) { $player_category = 'C'; } 
else { $player_category = 'D'; }

// 4. MONTHLY RANK & HISTORY CALCULATION
$all_months_query = "
    SELECT m_year, m_month, player_id, PL, W, D, L, GF, GA,
        ((W * 10) + (D * 5) + (GF * 15)) AS Monthly_Rating,
        ROW_NUMBER() OVER (PARTITION BY m_year, m_month ORDER BY ((W * 10) + (D * 5) + (GF * 15)) DESC, (GF - GA) DESC, GF DESC) AS m_rank
    FROM (
        SELECT YEAR(create_date) AS m_year, MONTH(create_date) AS m_month, player_id, COUNT(*) AS PL,
            SUM(CASE WHEN p_score > o_score THEN 1 ELSE 0 END) AS W,
            SUM(CASE WHEN p_score = o_score THEN 1 ELSE 0 END) AS D,
            SUM(CASE WHEN p_score < o_score THEN 1 ELSE 0 END) AS L,
            SUM(p_score) AS GF, SUM(o_score) AS GA
        FROM (
            SELECT create_date, player_id_home AS player_id, player_score_home AS p_score, player_score_away AS o_score 
            FROM player_ranking WHERE create_date IS NOT NULL AND create_date != '0000-00-00 00:00:00'
            UNION ALL
            SELECT create_date, player_id_away AS player_id, player_score_away AS p_score, player_score_home AS o_score 
            FROM player_ranking WHERE create_date IS NOT NULL AND create_date != '0000-00-00 00:00:00'
        ) AS all_unweighted
        GROUP BY YEAR(create_date), MONTH(create_date), player_id
    ) AS aggregated_monthly ORDER BY m_year DESC, m_month DESC
";

$monthly_res = $conn->query($all_months_query);
$raw_monthly_data = [];
if ($monthly_res) { while ($m_row = $monthly_res->fetch_assoc()) { $raw_monthly_data[] = $m_row; } }

$player_monthly_history = [];
foreach ($raw_monthly_data as $m_item) {
    if ($m_item['player_id'] === $player_id) {
        $yr = (int)$m_item['m_year']; $mo = (int)$m_item['m_month']; $curr_rank = (int)$m_item['m_rank'];
        $prev_mo = ($mo == 1) ? 12 : ($mo - 1); $prev_yr = ($mo == 1) ? ($yr - 1) : $yr;
        $prev_rank = null;
        foreach ($raw_monthly_data as $check_item) {
            if ($check_item['player_id'] === $player_id && (int)$check_item['m_year'] === $prev_yr && (int)$check_item['m_month'] === $prev_mo) {
                $prev_rank = (int)$check_item['m_rank']; break;
            }
        }

        if ($prev_rank === null) { $trend_type = 'NEW'; $trend_text = 'NEW'; } 
        else {
            $diff = $prev_rank - $curr_rank;
            if ($diff > 0) { $trend_type = 'UP'; $trend_text = '▲ +' . $diff; } 
            elseif ($diff < 0) { $trend_type = 'DOWN'; $trend_text = '▼ ' . abs($diff); } 
            else { $trend_type = 'SAME'; $trend_text = '● 0'; }
        }

        $month_ts = mktime(0, 0, 0, $mo, 1, $yr);
        $player_monthly_history[] = [
            'rank' => '#' . $curr_rank, 'rank_num' => $curr_rank, 'trend_type' => $trend_type, 'trend_text' => $trend_text,
            'month_title' => date('F Y', $month_ts), 'short_month' => date('M Y', $month_ts),
            'date_range'  => date('Y-m-01', $month_ts) . ' to ' . date('Y-m-t', $month_ts),
            'pl' => $m_item['PL'], 'w'  => $m_item['W'], 'd'  => $m_item['D'], 'rating' => $m_item['Monthly_Rating']
        ];
    }
}

$chart_labels = []; $chart_ranks  = []; $best_top_rank = null;
if (!empty($player_monthly_history)) {
    $reversed_history = array_reverse($player_monthly_history);
    foreach ($reversed_history as $item) {
        $chart_labels[] = $item['short_month']; $chart_ranks[]  = $item['rank_num'];
        if ($best_top_rank === null || $item['rank_num'] < $best_top_rank) { $best_top_rank = $item['rank_num']; }
    }
}
$top_rank_display = ($best_top_rank !== null) ? '#' . $best_top_rank : 'N/A';

// 6. Fetch Last 50 Matches
$stmt_last50 = $conn->prepare("
    SELECT pr.id AS match_id, pr.player_id_home, pr.player_score_home, pr.player_score_away, pr.player_id_away,
        p_home.player_name AS home_name, p_home.image_link AS home_img, p_away.player_name AS away_name, p_away.image_link AS away_img
    FROM player_ranking pr
    LEFT JOIN player_register p_home ON pr.player_id_home = p_home.player_id
    LEFT JOIN player_register p_away ON pr.player_id_away = p_away.player_id
    WHERE pr.player_id_home = ? OR pr.player_id_away = ?
    ORDER BY pr.id DESC LIMIT 50
");
$stmt_last50->bind_param("ss", $player_id, $player_id);
$stmt_last50->execute();
$last50_result = $stmt_last50->get_result();

$l50_w = $l50_d = $l50_l = $l50_total = 0; $recent_form_badges = []; $official_matches = [];
while ($row = $last50_result->fetch_assoc()) {
    $l50_total++; $is_home = ($row['player_id_home'] === $player_id);
    $p_score = $is_home ? (int)$row['player_score_home'] : (int)$row['player_score_away'];
    $o_score = $is_home ? (int)$row['player_score_away'] : (int)$row['player_score_home'];

    if ($p_score > $o_score) { $l50_w++; $outcome = 'W'; $pts = '+3'; } 
    elseif ($p_score == $o_score) { $l50_d++; $outcome = 'D'; $pts = '+1'; } 
    else { $l50_l++; $outcome = 'L'; $pts = '0'; }
    
    $recent_form_badges[] = $outcome;
    $row['user_outcome'] = $outcome; $row['user_pts'] = $pts;
    $official_matches[] = $row;
}
$stmt_last50->close();

$rating = ($w * 3) + ($d * 1);
$win_rate = ($pl > 0) ? round(($w / $pl) * 100, 1) : 0;
$l50_win_rate = ($l50_total > 0) ? round(($l50_w / $l50_total) * 100, 1) : 0;

$raw_image_link = trim($player['image_link'] ?? ''); $raw_player_name = trim($player['player_name'] ?? '');
$raw_player_id = trim($player['player_id'] ?? ''); $raw_konami_user_id = trim($player['konami_user_id'] ?? '');
$raw_device_name = trim($player['device_name'] ?? ''); $raw_fb_link = trim($player['fb_link'] ?? '');
$raw_country = trim($player['country'] ?? ''); $raw_district = trim($player['district'] ?? '');
$raw_blood = trim($player['blood'] ?? '');

$player_rank = ($pl > 0 && !empty($player['rank'])) ? trim($player['rank']) : null;
$player_motm = isset($player['motm']) && $player['motm'] !== '' ? trim($player['motm']) : '0';

if (empty($raw_image_link)) { $image_link = 'https://ui-avatars.com/api/?name=' . urlencode($raw_player_name) . '&background=00f2fe&color=0b0e14&size=200'; } 
else { $image_link = htmlspecialchars($raw_image_link, ENT_QUOTES, 'UTF-8'); }

$player_name = htmlspecialchars($raw_player_name, ENT_QUOTES, 'UTF-8');
$konami_user_id = htmlspecialchars($raw_konami_user_id, ENT_QUOTES, 'UTF-8');
$device_name = htmlspecialchars($raw_device_name, ENT_QUOTES, 'UTF-8');
$fb_link = htmlspecialchars($raw_fb_link, ENT_QUOTES, 'UTF-8');
$country = htmlspecialchars($raw_country, ENT_QUOTES, 'UTF-8');
$district = htmlspecialchars($raw_district, ENT_QUOTES, 'UTF-8');
$blood = htmlspecialchars($raw_blood, ENT_QUOTES, 'UTF-8');
$js_encoded_name = json_encode($raw_player_name, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $player_name; ?> - Ranking Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Teko:wght@600;700&family=Rajdhani:wght@600;700&family=Plus+Jakarta+Sans:wght@500;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        :root {
            --bg-dark: #07090e; --card-glass: rgba(15, 20, 32, 0.75); --card-border: rgba(255, 255, 255, 0.08);
            --neon-cyan: #00f2fe; --neon-purple: #7928ca; --neon-green: #10b981; --neon-yellow: #f59e0b;
            --neon-red: #ff0055; --text-main: #ffffff; --text-muted: #8a99ad;
            --skeleton-bg: #1e1e1e;
        }

        body.light-mode {
            --bg-dark: #f8fafc; --card-glass: rgba(255, 255, 255, 0.9); --card-border: #e2e8f0;
            --text-main: #0f172a; --text-muted: #64748b;
            --skeleton-bg: #e2e8f0;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; -webkit-tap-highlight-color: transparent; transition: background-color 0.3s, color 0.3s, border-color 0.3s; }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg-dark); color: var(--text-main);
            min-height: 100vh; display: flex; justify-content: center; align-items: flex-start; padding: 16px 10px;
            background-image: radial-gradient(circle at 10% 10%, rgba(0, 242, 254, 0.08) 0%, transparent 40%), radial-gradient(circle at 90% 90%, rgba(121, 40, 202, 0.1) 0%, transparent 40%);
            background-attachment: fixed; overflow-x: hidden;
        }

        .profile-container { max-width: 420px; width: 100%; display: flex; flex-direction: column; gap: 14px; }

        .header-card {
            background: var(--card-glass); backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px);
            border-radius: 20px; border: 1px solid var(--card-border); overflow: hidden; position: relative; box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        }

        .banner { height: 125px; background: linear-gradient(135deg, #090e17 0%, #1a103c 50%, #002b47 100%); position: relative; border-bottom: 1px solid rgba(255, 255, 255, 0.05); }

        .rank-form-container { position: absolute; top: 12px; left: 12px; display: flex; flex-direction: column; gap: 6px; z-index: 5; }

        .rank-badge {
            display: inline-flex; align-items: center; gap: 6px; background: rgba(7, 9, 14, 0.85);
            border: 1px solid rgba(245, 158, 11, 0.5); border-radius: 8px; padding: 4px 10px;
            color: var(--neon-yellow); font-family: 'Rajdhani', sans-serif; font-size: 13px; font-weight: 700; text-transform: uppercase; width: fit-content;
        }

        .last5-badge-wrapper { display: flex; align-items: center; gap: 4px; }

        .mini-form-badge { width: 18px; height: 18px; border-radius: 4px; display: flex; align-items: center; justify-content: center; font-size: 10px; font-weight: 800; color: #ffffff; box-shadow: 0 2px 5px rgba(0,0,0,0.4); }
        .mini-form-badge.W { background: var(--neon-green); }
        .mini-form-badge.D { background: var(--neon-yellow); color: #000; }
        .mini-form-badge.L { background: var(--neon-red); }

        .avatar-wrapper { text-align: center; margin-top: -65px; position: relative; z-index: 2; }
        .avatar-ring { display: inline-block; padding: 4px; border-radius: 50%; background: linear-gradient(135deg, var(--neon-cyan), var(--neon-purple)); box-shadow: 0 0 20px rgba(0, 242, 254, 0.4); position: relative; }
        .avatar { width: 125px; height: 125px; border-radius: 50%; object-fit: cover; border: 4px solid #0f1420; background: var(--bg-dark); display: block; }

        .category-badge { position: absolute; bottom: 4px; right: 4px; min-width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-family: 'Rajdhani', sans-serif; font-size: 15px; font-weight: 800; color: #ffffff; border: 2px solid #0f1420; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.6); z-index: 5; padding: 0 4px; }
        .badge-a-plus { background: linear-gradient(135deg, #10b981, #059669); box-shadow: 0 0 12px rgba(16, 185, 129, 0.6); }
        .badge-b { background: linear-gradient(135deg, #00f2fe, #0284c7); box-shadow: 0 0 12px rgba(0, 242, 254, 0.6); }
        .badge-c { background: linear-gradient(135deg, #f59e0b, #d97706); box-shadow: 0 0 12px rgba(245, 158, 11, 0.6); }
        .badge-d { background: linear-gradient(135deg, #ff0055, #be123c); box-shadow: 0 0 12px rgba(255, 0, 85, 0.6); }
        .badge-e { background: linear-gradient(135deg, #64748b, #334155); box-shadow: 0 0 12px rgba(100, 116, 139, 0.6); color: #cbd5e1; }

        .player-info { text-align: center; padding: 12px 14px 16px; }
        .player-name { font-family: 'Teko', 'Plus Jakarta Sans', sans-serif; font-size: 30px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase; background: linear-gradient(180deg, #ffffff 0%, #a5b4fc 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; line-height: 1.1; margin-bottom: 6px; }
        body.light-mode .player-name { background: linear-gradient(180deg, #0f172a 0%, #3b82f6 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }

        .inline-summary-stats { font-size: 12px; font-weight: 700; color: var(--text-muted); display: flex; flex-wrap: wrap; align-items: center; justify-content: center; gap: 5px; }
        .inline-summary-stats strong { color: var(--neon-cyan); }
        .inline-summary-stats .dot { color: rgba(255, 255, 255, 0.2); }
        body.light-mode .inline-summary-stats .dot { color: rgba(0, 0, 0, 0.2); }

        .navigation-card { background: var(--card-glass); backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); border-radius: 14px; border: 1px solid var(--card-border); padding: 5px; display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 6px; }

        .nav-btn { padding: 10px 4px; background: transparent; color: var(--text-muted); border: none; border-radius: 10px; font-family: 'Rajdhani', sans-serif; font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 5px; transition: color 0.2s ease, background 0.2s ease; }
        .nav-btn.active { background: linear-gradient(135deg, var(--neon-cyan), #0072ff); color: #000; box-shadow: 0 4px 12px rgba(0, 242, 254, 0.25); }

        .rank-cards-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }

        .overall-rank-card { background: linear-gradient(135deg, rgba(245, 158, 11, 0.08) 0%, var(--card-glass) 100%); backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); border-radius: 16px; border: 1px solid rgba(245, 158, 11, 0.25); padding: 12px; display: flex; flex-direction: column; justify-content: space-between; box-shadow: 0 6px 20px rgba(0, 0, 0, 0.3); position: relative; overflow: hidden; }
        .overall-rank-card::before { content: ''; position: absolute; top: 0; left: 0; width: 4px; height: 100%; background: linear-gradient(180deg, var(--neon-yellow), #d97706); }

        .season-2026-card { background: linear-gradient(135deg, rgba(0, 242, 254, 0.08) 0%, var(--card-glass) 100%); backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); border-radius: 16px; border: 1px solid rgba(0, 242, 254, 0.25); padding: 12px; display: flex; flex-direction: column; justify-content: space-between; box-shadow: 0 6px 20px rgba(0, 0, 0, 0.3); position: relative; overflow: hidden; }
        .season-2026-card::before { content: ''; position: absolute; top: 0; left: 0; width: 4px; height: 100%; background: linear-gradient(180deg, var(--neon-cyan), #0072ff); }

        .rank-label-group, .season-label-group { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }

        .rank-icon-wrapper, .season-icon-wrapper { width: 32px; height: 32px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 14px; }
        .rank-icon-wrapper { background: rgba(245, 158, 11, 0.15); border: 1px solid rgba(245, 158, 11, 0.3); color: var(--neon-yellow); }
        .season-icon-wrapper { background: rgba(0, 242, 254, 0.15); border: 1px solid rgba(0, 242, 254, 0.3); color: var(--neon-cyan); }

        .rank-text-info, .season-text-info { display: flex; flex-direction: column; }
        .rank-title, .season-title { font-family: 'Rajdhani', sans-serif; font-size: 13px; font-weight: 700; color: var(--text-main); text-transform: uppercase; line-height: 1.1; }
        .rank-subtitle { font-size: 10px; color: var(--text-muted); font-weight: 600; }
        .season-win-tag { font-size: 10px; color: var(--neon-green); font-weight: 700; margin-top: 2px; }

        .rank-number-value, .season-rank-value { font-family: 'Teko', sans-serif; font-size: 32px; font-weight: 700; line-height: 1; text-align: right; }
        .rank-number-value { color: var(--neon-yellow); text-shadow: 0 0 12px rgba(245, 158, 11, 0.3); }
        .season-rank-value { color: var(--neon-cyan); text-shadow: 0 0 12px rgba(0, 242, 254, 0.3); }

        .stats-card-container { background: var(--card-glass); backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); border-radius: 18px; border: 1px solid var(--card-border); padding: 16px; }

        .section-title { font-family: 'Rajdhani', sans-serif; font-size: 16px; font-weight: 700; color: var(--text-main); margin-bottom: 4px; display: flex; align-items: center; gap: 8px; text-transform: uppercase; letter-spacing: 0.5px; }
        .section-subtitle { font-size: 11px; color: var(--text-muted); margin-bottom: 14px; font-weight: 600; }

        .form-badge-container { display: flex; flex-wrap: wrap; gap: 5px; margin-top: 10px; max-height: 75px; overflow-y: auto; padding-right: 4px; }
        .form-badge-item { width: 24px; height: 24px; border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 800; color: #ffffff; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3); }
        .form-badge-item.W { background: var(--neon-green); }
        .form-badge-item.D { background: var(--neon-yellow); color: #000; }
        .form-badge-item.L { background: var(--neon-red); }

        .trend-card-dark { background: var(--card-glass); backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); border-radius: 18px; border: 1px solid var(--card-border); padding: 16px; box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4); }
        .trend-header-dark { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 14px; }
        .trend-title-dark { font-family: 'Rajdhani', sans-serif; font-size: 18px; font-weight: 700; color: var(--text-main); text-transform: uppercase; letter-spacing: 0.5px; }
        .trend-subtitle-dark { font-size: 11px; color: var(--text-muted); font-weight: 600; margin-top: 2px; }
        .top-rank-badge-dark { background: rgba(0, 242, 254, 0.1); color: var(--neon-cyan); border: 1px solid rgba(0, 242, 254, 0.3); padding: 4px 12px; border-radius: 20px; font-family: 'Rajdhani', sans-serif; font-size: 13px; font-weight: 700; text-transform: uppercase; box-shadow: 0 0 10px rgba(0, 242, 254, 0.15); }
        .chart-container-dark { position: relative; height: 220px; width: 100%; }

        .info-wrapper { display: flex; flex-direction: column; gap: 8px; }
        .info-card { background: rgba(255, 255, 255, 0.02); border-radius: 10px; border: 1px solid rgba(255, 255, 255, 0.04); padding: 10px 12px; display: flex; justify-content: space-between; align-items: center; }
        body.light-mode .info-card { background: rgba(0, 0, 0, 0.02); border: 1px solid rgba(0, 0, 0, 0.05); }
        .info-card .label { color: var(--text-muted); font-size: 11px; font-weight: 700; text-transform: uppercase; display: flex; align-items: center; gap: 6px; }
        .info-card .value { color: var(--text-main); font-size: 12px; font-weight: 700; }

        .stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin-bottom: 10px; }
        .stat-box { background: rgba(255, 255, 255, 0.02); border: 1px solid rgba(255, 255, 255, 0.04); border-radius: 10px; padding: 8px; text-align: center; }
        body.light-mode .stat-box { background: rgba(0, 0, 0, 0.02); border: 1px solid rgba(0, 0, 0, 0.05); }
        .stat-box .stat-val { font-family: 'Teko', sans-serif; font-size: 22px; font-weight: 700; line-height: 1; color: var(--text-main); }
        .stat-box .stat-lbl { font-size: 9px; font-weight: 800; color: var(--text-muted); text-transform: uppercase; }
        .stat-box.highlight-win .stat-val { color: var(--neon-green); }
        .stat-box.highlight-draw .stat-val { color: var(--neon-yellow); }
        .stat-box.highlight-loss .stat-val { color: var(--neon-red); }
        .stat-box.highlight-gold .stat-val { color: #facc15; }

        .winrate-wrapper { background: rgba(255, 255, 255, 0.02); border: 1px solid rgba(255, 255, 255, 0.04); border-radius: 10px; padding: 10px 12px; }
        body.light-mode .winrate-wrapper { background: rgba(0, 0, 0, 0.02); border: 1px solid rgba(0, 0, 0, 0.05); }
        .winrate-info { display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px; font-size: 11px; font-weight: 700; }
        .winrate-bar-bg { height: 6px; width: 100%; background: rgba(255, 255, 255, 0.06); border-radius: 10px; overflow: hidden; }
        body.light-mode .winrate-bar-bg { background: rgba(0, 0, 0, 0.1); }
        .winrate-bar-fill { height: 100%; background: linear-gradient(90deg, var(--neon-cyan), var(--neon-purple)); border-radius: 10px; }

        .monthly-table-container { display: flex; flex-direction: column; gap: 8px; }
        .monthly-table-header { display: grid; grid-template-columns: 38px 45px 1fr 28px 28px 28px 34px; align-items: center; padding: 6px 8px; font-size: 10px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; }
        .monthly-table-header .th-icon { display: inline-flex; align-items: center; justify-content: center; background: rgba(255, 255, 255, 0.05); border-radius: 4px; padding: 2px 4px; font-size: 9px; }

        .monthly-row { background: rgba(255, 255, 255, 0.02); border: 1px solid rgba(255, 255, 255, 0.04); border-radius: 12px; padding: 10px 8px; display: grid; grid-template-columns: 38px 45px 1fr 28px 28px 28px 34px; align-items: center; transition: background 0.15s ease; }
        body.light-mode .monthly-row { background: rgba(0, 0, 0, 0.02); border: 1px solid rgba(0, 0, 0, 0.05); }

        .m-rank-pill { background: rgba(255, 255, 255, 0.06); color: var(--text-main); border-radius: 6px; padding: 3px 5px; font-size: 11px; font-weight: 800; width: fit-content; }
        body.light-mode .m-rank-pill { background: rgba(0, 0, 0, 0.08); }
        .m-trend-badge { font-size: 10px; font-weight: 800; padding: 2px 5px; border-radius: 4px; display: inline-block; text-align: center; width: fit-content; }
        .m-trend-badge.UP { color: #10b981; background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.3); }
        .m-trend-badge.DOWN { color: #ff0055; background: rgba(255, 0, 85, 0.15); border: 1px solid rgba(255, 0, 85, 0.3); }
        .m-trend-badge.SAME { color: #8a99ad; background: rgba(138, 153, 173, 0.15); border: 1px solid rgba(138, 153, 173, 0.3); }
        .m-trend-badge.NEW { color: #00f2fe; background: rgba(0, 242, 254, 0.15); border: 1px solid rgba(0, 242, 254, 0.3); }

        .m-month-info { display: flex; flex-direction: column; padding-right: 4px; }
        .m-month-title { font-size: 12px; font-weight: 800; color: var(--text-main); line-height: 1.1; }
        .m-date-range { font-size: 9px; color: var(--text-muted); font-weight: 600; margin-top: 2px; }

        .m-val { font-size: 11px; font-weight: 700; color: var(--text-main); text-align: center; }
        .m-val.rating { font-weight: 800; color: var(--neon-cyan); }

        .official-matches-wrapper { display: flex; flex-direction: column; gap: 10px; }
        .match-card { background: rgba(255, 255, 255, 0.02); border: 1px solid rgba(255, 255, 255, 0.05); border-radius: 12px; padding: 10px 12px; display: flex; flex-direction: column; gap: 8px; }
        body.light-mode .match-card { background: rgba(0, 0, 0, 0.02); border: 1px solid rgba(0, 0, 0, 0.05); }
        .match-header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(255, 255, 255, 0.04); padding-bottom: 6px; }
        body.light-mode .match-header { border-bottom: 1px solid rgba(0, 0, 0, 0.05); }
        .match-status-badge { font-size: 10px; font-weight: 800; padding: 2px 8px; border-radius: 4px; color: #ffffff; text-transform: uppercase; }
        .match-status-badge.W { background: var(--neon-green); }
        .match-status-badge.D { background: var(--neon-yellow); color: #000; }
        .match-status-badge.L { background: var(--neon-red); }
        .match-rating-tag { font-size: 10px; font-weight: 700; color: var(--text-muted); }
        .match-rating-tag span { color: var(--neon-yellow); font-weight: 800; }
        .match-teams-container { display: flex; align-items: center; justify-content: space-between; }
        .team-box { display: flex; flex-direction: column; align-items: center; gap: 4px; width: 35%; text-align: center; }
        .team-avatar { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; border: 2px solid rgba(255, 255, 255, 0.1); background: var(--bg-dark); }
        .team-name { font-size: 11px; font-weight: 700; color: var(--text-main); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 100%; }
        .score-box { display: flex; align-items: center; justify-content: center; gap: 6px; width: 30%; }
        .score-num { font-family: 'Teko', sans-serif; font-size: 22px; font-weight: 700; color: var(--text-main); background: rgba(0, 0, 0, 0.1); padding: 0 8px; border-radius: 6px; border: 1px solid rgba(255, 255, 255, 0.08); line-height: 1.2; }
        body.light-mode .score-num { background: rgba(0, 0, 0, 0.05); }
        .score-divider { font-weight: 800; color: var(--neon-cyan); font-size: 12px; }
        .tab-content { display: flex; flex-direction: column; gap: 14px; }
        .footer-text { text-align: center; color: var(--text-muted); font-size: 10px; text-transform: uppercase; font-weight: 700; letter-spacing: 1px; margin-top: 4px; }

        /* ================= SKELETON LOADING ================= */
        .skeleton { background-color: var(--skeleton-bg); border-radius: 6px; animation: pulse 1.5s infinite ease-in-out; }
        @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.4; } 100% { opacity: 1; } }

        .skeleton-header-card { height: 280px; width: 100%; border-radius: 20px; margin-bottom: 14px; }
        .skeleton-nav-card { height: 50px; width: 100%; border-radius: 14px; margin-bottom: 14px; }
        .skeleton-stats-card { height: 150px; width: 100%; border-radius: 18px; margin-bottom: 14px; }
        
        #realContent { display: none; }
    </style>
</head>
<body>

<div class="profile-container">
    
    <!-- Back Button -->
    <div style="position: absolute; top: 20px; left: 20px; z-index: 100;">
        <a href="player-ranking.php" style="color: var(--text-main); background: var(--card-glass); padding: 8px 12px; border-radius: 8px; text-decoration: none; border: 1px solid var(--card-border); font-weight: 600; font-size: 13px;">← Back</a>
    </div>

    <!-- ১. SKELETON LOADING -->
    <div id="skeletonLoader" style="margin-top: 60px;">
        <div class="skeleton skeleton-header-card"></div>
        <div class="skeleton skeleton-nav-card"></div>
        <div class="skeleton skeleton-stats-card"></div>
        <div class="skeleton skeleton-stats-card"></div>
    </div>

    <!-- ২. আসল ডেটা -->
    <div id="realContent">
        
        <div class="header-card">
            <div class="banner">
                <div class="rank-form-container">
                    <?php if ($player_rank !== null): ?>
                        <div class="rank-badge"><i class="fa-solid fa-trophy"></i> Rank #<?php echo htmlspecialchars($player_rank, ENT_QUOTES, 'UTF-8'); ?></div>
                    <?php else: ?>
                        <div class="rank-badge" style="opacity: 0.6; color: var(--text-muted); border-color: rgba(255,255,255,0.15);"><i class="fa-solid fa-user-slash"></i> Unranked</div>
                    <?php endif; ?>

                    <?php if (!empty($last5_form)): ?>
                        <div class="last5-badge-wrapper">
                            <?php foreach ($last5_form as $form): ?>
                                <span class="mini-form-badge <?php echo $form; ?>"><?php echo $form; ?></span>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="avatar-wrapper">
                <div class="avatar-ring">
                    <img src="<?php echo $image_link; ?>" alt="<?php echo $player_name; ?>" class="avatar" id="playerAvatar">
                    <div class="category-badge badge-<?php echo strtolower(str_replace('+', '-plus', $player_category)); ?>">
                        <?php echo $player_category; ?>
                    </div>
                </div>
            </div>

            <div class="player-info">
                <div class="player-name"><?php echo $player_name; ?></div>
                <div class="inline-summary-stats">
                    <span><strong><?php echo $pl; ?></strong> matches</span>
                    <span class="dot">•</span>
                    <span><strong><?php echo $w; ?></strong> wins</span>
                    <span class="dot">•</span>
                    <span><strong><?php echo $win_rate; ?>%</strong> WR</span>
                    <span class="dot">•</span>
                    <span><strong><?php echo $gf; ?></strong> GF</span>
                    <span class="dot">•</span>
                    <span><strong><?php echo htmlspecialchars($player_motm, ENT_QUOTES, 'UTF-8'); ?></strong> MOTM</span>
                </div>
            </div>
        </div>

        <div class="navigation-card">
            <button class="nav-btn active" id="btnOverview" onclick="switchTab('overview')"><i class="fa-regular fa-compass"></i> Overview</button>
            <button class="nav-btn" id="btnStats" onclick="switchTab('stats')"><i class="fa-solid fa-chart-line"></i> Statistics</button>
            <button class="nav-btn" id="btnOfficial" onclick="switchTab('official')"><i class="fa-solid fa-gamepad"></i> Official Match</button>
        </div>

        <div id="tabOverview" class="tab-content">
            <div class="rank-cards-grid">
                <div class="overall-rank-card">
                    <div class="rank-label-group">
                        <div class="rank-icon-wrapper"><i class="fa-solid fa-crown"></i></div>
                        <div class="rank-text-info"><span class="rank-title">Overall Rank</span><span class="rank-subtitle">Community</span></div>
                    </div>
                    <div class="rank-number-value"><?php echo ($player_rank !== null) ? '#' . htmlspecialchars($player_rank, ENT_QUOTES, 'UTF-8') : 'Unranked'; ?></div>
                </div>

                <div class="season-2026-card">
                    <div class="season-label-group">
                        <div class="season-icon-wrapper"><i class="fa-solid fa-trophy"></i></div>
                        <div class="season-text-info"><span class="season-title">Season 2026</span><span class="season-win-tag"><i class="fa-solid fa-shield-halved"></i> <?php echo $s2026_w; ?> Wins</span></div>
                    </div>
                    <div class="season-rank-value"><?php echo $s2026_rank; ?></div>
                </div>
            </div>

            <div class="stats-card-container">
                <div class="section-title"><i class="fa-solid fa-fire" style="color:var(--neon-yellow);"></i> Last 50 Matches Form</div>
                <div class="section-subtitle">Recent match results and performance trend</div>

                <div class="stats-grid" style="margin-top: 10px;">
                    <div class="stat-box highlight-win"><div class="stat-val"><?php echo $l50_w; ?></div><div class="stat-lbl">Victory</div></div>
                    <div class="stat-box highlight-draw"><div class="stat-val"><?php echo $l50_d; ?></div><div class="stat-lbl">Draw</div></div>
                    <div class="stat-box highlight-loss"><div class="stat-val"><?php echo $l50_l; ?></div><div class="stat-lbl">Defeat</div></div>
                </div>

                <div class="winrate-wrapper" style="margin-bottom: 12px;">
                    <div class="winrate-info"><span style="color: var(--text-muted);">Last 50 Win Rate</span><span style="color: var(--neon-cyan);"><?php echo $l50_win_rate; ?>%</span></div>
                    <div class="winrate-bar-bg"><div class="winrate-bar-fill" style="width: <?php echo $l50_win_rate; ?>%;"></div></div>
                </div>

                <?php if (!empty($recent_form_badges)): ?>
                    <div style="font-size: 10px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Recent Sequence (Latest First)</div>
                    <div class="form-badge-container">
                        <?php foreach ($recent_form_badges as $f_badge): ?>
                            <span class="form-badge-item <?php echo $f_badge; ?>"><?php echo $f_badge; ?></span>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div style="font-size: 12px; color: var(--text-muted); text-align: center; padding: 10px 0;">No recent match sequence available.</div>
                <?php endif; ?>
            </div>

            <div class="stats-card-container">
                <div class="section-title"><i class="fa-solid fa-user"></i> Personal Information</div>
                <div class="info-wrapper" style="margin-top: 10px;">
                    <div class="info-card"><span class="label"><i class="fa-regular fa-id-card"></i> Konami User ID</span><span class="value"><?php echo !empty($konami_user_id) ? $konami_user_id : 'Not provided'; ?></span></div>
                    <div class="info-card"><span class="label"><i class="fa-regular fa-mobile-screen-button"></i> Device</span><span class="value"><?php echo !empty($device_name) ? $device_name : 'Not provided'; ?></span></div>
                    <div class="info-card"><span class="label"><i class="fa-brands fa-facebook"></i> Facebook</span><span class="value"><?php if (!empty($fb_link)): ?><a href="<?php echo $fb_link; ?>" target="_blank" style="color:var(--neon-cyan);text-decoration:none;">Profile <i class="fa-solid fa-arrow-up-right-from-square" style="font-size:9px;"></i></a><?php else: echo 'Not provided'; endif; ?></span></div>
                    <div class="info-card"><span class="label"><i class="fa-regular fa-earth-americas"></i> Country</span><span class="value"><?php echo !empty($country) ? $country : 'Not provided'; ?></span></div>
                    <div class="info-card"><span class="label"><i class="fa-regular fa-location-dot"></i> District</span><span class="value"><?php echo !empty($district) ? $district : 'Not provided'; ?></span></div>
                    <div class="info-card"><span class="label"><i class="fa-regular fa-droplet"></i> Blood Group</span><span class="value"><?php echo !empty($blood) ? $blood : 'Not provided'; ?></span></div>
                </div>
            </div>

            <div class="stats-card-container">
                <div class="section-title"><i class="fa-solid fa-chart-simple"></i> Overall Ranking</div>
                <div class="stats-grid" style="margin-top: 10px;">
                    <div class="stat-box"><div class="stat-val"><?php echo $pl; ?></div><div class="stat-lbl">PL</div></div>
                    <div class="stat-box highlight-win"><div class="stat-val"><?php echo $w; ?></div><div class="stat-lbl">W</div></div>
                    <div class="stat-box highlight-draw"><div class="stat-val"><?php echo $d; ?></div><div class="stat-lbl">D</div></div>
                    <div class="stat-box highlight-loss"><div class="stat-val"><?php echo $l; ?></div><div class="stat-lbl">L</div></div>
                    <div class="stat-box"><div class="stat-val"><?php echo $gf; ?></div><div class="stat-lbl">GF</div></div>
                    <div class="stat-box"><div class="stat-val"><?php echo $ga; ?></div><div class="stat-lbl">GA</div></div>
                    <div class="stat-box highlight-gold"><div class="stat-val"><?php echo $hat_trick; ?></div><div class="stat-lbl">Hat-trick</div></div>
                    <div class="stat-box highlight-gold"><div class="stat-val"><?php echo $double_hat_trick; ?></div><div class="stat-lbl">2x Hat-trick</div></div>
                    <div class="stat-box highlight-gold"><div class="stat-val"><?php echo $rating; ?></div><div class="stat-lbl">Rating</div></div>
                </div>

                <div class="winrate-wrapper">
                    <div class="winrate-info"><span style="color: var(--text-muted);"><i class="fa-solid fa-fire" style="color:var(--neon-cyan);"></i> Win Rate</span><span style="color: var(--neon-cyan);"><?php echo $win_rate; ?>%</span></div>
                    <div class="winrate-bar-bg"><div class="winrate-bar-fill" style="width: <?php echo $win_rate; ?>%;"></div></div>
                </div>
            </div>
        </div>

        <div id="tabStats" class="tab-content" style="display: none;">
            <div class="trend-card-dark">
                <div class="trend-header-dark">
                    <div><div class="trend-title-dark"><i class="fa-solid fa-chart-line" style="color:var(--neon-cyan); margin-right:6px;"></i> Monthly Trend</div><div class="trend-subtitle-dark">Lower rank number is better</div></div>
                    <div class="top-rank-badge-dark">Top Rank <?php echo $top_rank_display; ?></div>
                </div>
                <div class="chart-container-dark"><canvas id="monthlyTrendChart"></canvas></div>
            </div>

            <div class="stats-card-container">
                <div class="section-title"><i class="fa-solid fa-calendar-days"></i> Monthly Table</div>
                <div class="section-subtitle">Monthly rank, match volume and rating history.</div>
                <div class="monthly-table-container">
                    <div class="monthly-table-header">
                        <span class="th-icon">#</span><span>Trend</span><span>Month</span><span class="th-icon"><i class="fa-solid fa-stop"></i></span><span class="th-icon">W</span><span class="th-icon">D</span><span class="th-icon"><i class="fa-solid fa-soccer-ball"></i></span>
                    </div>
                    <?php if (!empty($player_monthly_history)): ?>
                        <?php foreach ($player_monthly_history as $m_item): ?>
                            <div class="monthly-row">
                                <div><span class="m-rank-pill"><?php echo $m_item['rank']; ?></span></div>
                                <div><span class="m-trend-badge <?php echo $m_item['trend_type']; ?>"><?php echo $m_item['trend_text']; ?></span></div>
                                <div class="m-month-info"><span class="m-month-title"><?php echo $m_item['month_title']; ?></span><span class="m-date-range"><?php echo $m_item['date_range']; ?></span></div>
                                <div class="m-val"><?php echo $m_item['pl']; ?></div>
                                <div class="m-val"><?php echo $m_item['w']; ?></div>
                                <div class="m-val"><?php echo $m_item['d']; ?></div>
                                <div class="m-val rating"><?php echo $m_item['rating']; ?></div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div style="text-align: center; color: var(--text-muted); padding: 20px 0; font-size: 12px;">No monthly stats available yet.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div id="tabOfficial" class="tab-content" style="display: none;">
            <div class="stats-card-container">
                <div class="section-title"><i class="fa-solid fa-trophy"></i> Official Matches</div>
                <div class="official-matches-wrapper" style="margin-top: 10px;">
                    <?php if (!empty($official_matches)): ?>
                        <?php foreach ($official_matches as $m): 
                            $home_name = htmlspecialchars($m['home_name'] ?? 'Home Player', ENT_QUOTES, 'UTF-8');
                            $away_name = htmlspecialchars($m['away_name'] ?? 'Away Player', ENT_QUOTES, 'UTF-8');
                            $h_img = !empty($m['home_img']) ? htmlspecialchars($m['home_img'], ENT_QUOTES, 'UTF-8') : 'https://ui-avatars.com/api/?name='.urlencode($home_name).'&background=00f2fe&color=0b0e14';
                            $a_img = !empty($m['away_img']) ? htmlspecialchars($m['away_img'], ENT_QUOTES, 'UTF-8') : 'https://ui-avatars.com/api/?name='.urlencode($away_name).'&background=00f2fe&color=0b0e14';
                            $outcome = $m['user_outcome']; $pts = $m['user_pts'];
                        ?>
                            <div class="match-card">
                                <div class="match-header">
                                    <span class="match-status-badge <?php echo $outcome; ?>"><?php echo ($outcome === 'W') ? 'VICTORY' : (($outcome === 'D') ? 'DRAW' : 'DEFEAT'); ?> (<?php echo $outcome; ?>)</span>
                                    <span class="match-rating-tag">Rating: <span><?php echo $pts; ?> Pts</span></span>
                                </div>
                                <div class="match-teams-container">
                                    <div class="team-box"><img src="<?php echo $h_img; ?>" alt="<?php echo $home_name; ?>" class="team-avatar"><span class="team-name"><?php echo $home_name; ?></span></div>
                                    <div class="score-box"><span class="score-num"><?php echo (int)$m['player_score_home']; ?></span><span class="score-divider">-</span><span class="score-num"><?php echo (int)$m['player_score_away']; ?></span></div>
                                    <div class="team-box"><img src="<?php echo $a_img; ?>" alt="<?php echo $away_name; ?>" class="team-avatar"><span class="team-name"><?php echo $away_name; ?></span></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div style="text-align: center; color: var(--text-muted); padding: 20px 0; font-size: 12px;">No official matches recorded yet.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="footer-text"><i class="fa-regular fa-shield-halved"></i> Player Profile</div>
    </div>

</div>

<script>
    function switchTab(tabName) {
        const tabOverview = document.getElementById('tabOverview');
        const tabStats = document.getElementById('tabStats');
        const tabOfficial = document.getElementById('tabOfficial');
        
        const btnOverview = document.getElementById('btnOverview');
        const btnStats = document.getElementById('btnStats');
        const btnOfficial = document.getElementById('btnOfficial');

        tabOverview.style.display = 'none'; tabStats.style.display = 'none'; tabOfficial.style.display = 'none';
        btnOverview.classList.remove('active'); btnStats.classList.remove('active'); btnOfficial.classList.remove('active');

        if (tabName === 'overview') { tabOverview.style.display = 'flex'; btnOverview.classList.add('active'); } 
        else if (tabName === 'stats') { tabStats.style.display = 'flex'; btnStats.classList.add('active'); } 
        else if (tabName === 'official') { tabOfficial.style.display = 'flex'; btnOfficial.classList.add('active'); }
    }

    // ---- লোডিং ও চার্ট সিমুলেশন ----
    window.addEventListener('load', function() {
        setTimeout(function() {
            document.getElementById('skeletonLoader').style.display = 'none';
            document.getElementById('realContent').style.display = 'block';

            // চার্ট লোড করা
            const ctx = document.getElementById('monthlyTrendChart');
            if (ctx) {
                const labels = <?php echo json_encode($chart_labels); ?>;
                const ranks  = <?php echo json_encode($chart_ranks); ?>;

                new Chart(ctx.getContext('2d'), {
                    type: 'line',
                    data: { labels: labels, datasets: [{ label: 'Monthly Rank', data: ranks, borderColor: '#00f2fe', backgroundColor: 'rgba(0, 242, 254, 0.1)', borderWidth: 3, pointBackgroundColor: '#00f2fe', pointBorderColor: '#ffffff', pointBorderWidth: 2, pointRadius: 5, pointHoverRadius: 7, tension: 0.3, fill: true }] },
                    options: {
                        responsive: true, maintainAspectRatio: false,
                        plugins: { legend: { display: false }, tooltip: { backgroundColor: '#0f1420', titleColor: '#00f2fe', bodyColor: '#ffffff', borderColor: 'rgba(255, 255, 255, 0.1)', borderWidth: 1, padding: 10, callbacks: { label: function(context) { return ' Rank: #' + context.raw; } } } },
                        scales: { y: { reverse: true, beginAtZero: false, grid: { color: 'rgba(255, 255, 255, 0.05)' }, ticks: { color: '#8a99ad', font: { size: 11, weight: '600' } }, title: { display: true, text: 'Rank', color: '#8a99ad', font: { size: 12, weight: '700' } } }, x: { grid: { display: false }, ticks: { color: '#8a99ad', font: { size: 11, weight: '600' } } } }
                    }
                });
            }

        }, 1000); 
    });

    // ---- থিম চেক ----
    window.onload = function() {
        var savedTheme = localStorage.getItem('ecob-theme');
        if (savedTheme === 'light') {
            document.body.classList.add('light-mode');
        } else if (savedTheme === 'system' || !savedTheme) {
            if (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches) {
                document.body.classList.add('light-mode');
            }
        }

        // প্লেয়ার ছবি ভাঙলে ফলব্যাক
        const avatar = document.getElementById('playerAvatar');
        if (avatar) {
            avatar.addEventListener('error', function() {
                const rawName = <?php echo $js_encoded_name; ?>;
                this.src = 'https://ui-avatars.com/api/?name=' + encodeURIComponent(rawName) + '&background=00f2fe&color=0b0e14&size=200';
            });
        }
    };
</script>

</body>
</html>