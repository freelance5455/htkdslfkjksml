<?php
// ecob-app/profile.php
session_start();

if (!isset($_SESSION['player_id'])) {
    header('Location: /ecob-app/login.php');
    exit;
}

$host     = 'localhost';
$dbname   = 'ecobdhwl_ecob_database';
$username = 'ecobdhwl_ecobcpanel';
$password = 'ecobshakil1234';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("❌ Connection failed: " . $e->getMessage());
}

// ---- ইমেজ পাথ ফাংশন ----
function getImgPath($img) {
    if (empty($img) || $img == 'default.png') {
        return 'https://cdn-icons-png.flaticon.com/512/149/149071.png'; 
    }
    if (strpos($img, 'http') === 0) return $img; 
    if (strpos($img, 'uploads/') === 0) return '/' . $img;
    return '/uploads/' . $img; 
}

$player_id = $_SESSION['player_id'];
$success_msg = '';

// ---- ডাটা সেভ করার লজিক ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $konami_id   = trim($_POST['konami_user_id'] ?? '');
    $device      = trim($_POST['device_name'] ?? '');
    $fb_link     = trim($_POST['fb_link'] ?? '');
    $player_name = trim($_POST['player_name'] ?? ''); 

    $update_sql = "UPDATE player_register SET konami_user_id = ?, device_name = ?, fb_link = ?, player_name = ? WHERE player_id = ?";
    $stmt = $pdo->prepare($update_sql);
    
    if ($stmt->execute([$konami_id, $device, $fb_link, $player_name, $player_id])) {
        $_SESSION['player_name'] = $player_name; 
        $success_msg = "Your information has been updated successfully!";
    }
}

// ---- ইউজারের বর্তমান ডাটা রিড করা ----
$stmt = $pdo->prepare("SELECT konami_user_id, device_name, fb_link, player_name, image_link FROM player_register WHERE player_id = ?");
$stmt->execute([$player_id]);
$user_data = $stmt->fetch(PDO::FETCH_ASSOC);

$current_konami = $user_data['konami_user_id'] ?? '';
$current_device = $user_data['device_name'] ?? '';
$current_fb     = $user_data['fb_link'] ?? '';
$current_name   = $user_data['player_name'] ?? '';
$current_image  = $user_data['image_link'] ?? ''; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>My Profile — ECOB</title>
    <style>
        :root {
            --bg-color: #000000; --text-color: #ffffff; --text-muted: #94a3b8;
            --border-color: #27272a; --card-bg: #121212;
            --input-bg: #18181b; --btn-bg: #3b82f6; --btn-hover: #2563eb;
            --item-hover: rgba(255, 255, 255, 0.05);
            --skeleton-bg: #1e1e1e;
        }

        body.light-mode {
            --bg-color: #f8fafc; --text-color: #0f172a; --text-muted: #64748b;
            --border-color: #e2e8f0; --card-bg: #ffffff;
            --input-bg: #f1f5f9; --btn-bg: #3b82f6; --btn-hover: #2563eb;
            --item-hover: rgba(0, 0, 0, 0.03);
            --skeleton-bg: #e2e8f0;
        }

        * {
            margin: 0; padding: 0; box-sizing: border-box;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            -webkit-tap-highlight-color: transparent;
            transition: background-color 0.3s, color 0.3s, border-color 0.3s;
        }

        body {
            background-color: var(--bg-color); color: var(--text-color);
            min-height: 100vh; padding-bottom: 40px;
        }

        /* ---------- Top Header ---------- */
        .top-header {
            display: flex; align-items: center; justify-content: space-between;
            padding: 20px; position: sticky; top: 0; background: var(--bg-color);
            z-index: 10;
        }

        .header-left { display: flex; align-items: center; gap: 15px; }
        .back-btn { color: var(--text-color); text-decoration: none; display: flex; align-items: center; }
        .page-title { font-size: 20px; font-weight: 700; }

        /* ডান কর্নারের প্লেয়ার ইনফো (বড় ছবি ও পুরো নাম) */
        .header-right { 
            display: flex; align-items: center; gap: 14px; 
        }
        
        .player-name-top {
            font-size: 18px; 
            font-weight: 700;
            color: var(--text-color);
            text-align: right;
            max-width: 160px; 
            line-height: 1.2;
            word-wrap: break-word;
            letter-spacing: 0.3px;
        }
        
        .player-img-top {
            width: 65px; height: 65px; border-radius: 50%; object-fit: cover;
            border: 2px solid #3b82f6; background: var(--card-bg);
            flex-shrink: 0;
            box-shadow: 0 4px 10px rgba(59, 130, 246, 0.2);
        }

        /* ---------- List Sections ---------- */
        .section-title {
            font-size: 14px; font-weight: 600; color: var(--text-muted);
            margin: 20px 20px 10px 20px; text-transform: uppercase; letter-spacing: 0.5px;
        }

        .list-container {
            padding: 0 20px; display: flex; flex-direction: column; gap: 12px;
        }

        .list-item {
            display: flex; align-items: center; justify-content: space-between;
            background: var(--card-bg); border: 1px solid var(--border-color);
            padding: 16px; border-radius: 16px; cursor: pointer;
            text-decoration: none; color: var(--text-color);
        }

        .list-item:active { background: var(--item-hover); transform: scale(0.98); }
        .item-left { display: flex; align-items: center; gap: 15px; }

        .icon-box {
            width: 46px; height: 46px; border-radius: 14px;
            display: flex; align-items: center; justify-content: center;
            flex-shrink: 0; box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        .icon-box svg { width: 24px; height: 24px; fill: #ffffff; }

        .bg-fb { background: linear-gradient(135deg, #1877F2, #0a58ca); }
        .bg-uid { background: linear-gradient(135deg, #f59e0b, #d97706); }
        .bg-mail { background: linear-gradient(135deg, #8b5cf6, #6d28d9); }
        .bg-info { background: linear-gradient(135deg, #10b981, #047857); }
        .bg-rank { background: linear-gradient(135deg, #facc15, #d97706); }

        .item-text { display: flex; flex-direction: column; gap: 4px; }
        .item-title { font-size: 15px; font-weight: 600; }
        .item-desc { font-size: 12px; color: var(--text-muted); }
        .arrow-icon { width: 20px; height: 20px; fill: var(--text-muted); }

        .edit-form-container {
            display: none; padding: 20px; margin-top: 10px;
            animation: slideDown 0.3s ease;
        }

        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-size: 13px; color: var(--text-muted); margin-bottom: 8px; font-weight: 500; }
        .form-group input {
            width: 100%; padding: 14px 16px; font-size: 15px;
            background: var(--input-bg); border: 1px solid var(--border-color);
            border-radius: 12px; color: var(--text-color); outline: none;
        }
        .form-group input:focus { border-color: #3b82f6; }
        
        .save-btn {
            width: 100%; padding: 16px; background: var(--btn-bg);
            color: white; border: none; border-radius: 12px; font-size: 16px;
            font-weight: 600; cursor: pointer; margin-top: 10px;
        }
        .save-btn:active { background: var(--btn-hover); }

        .success-msg {
            background: rgba(34, 197, 94, 0.15); border: 1px solid rgba(34, 197, 94, 0.4);
            color: #4ade80; padding: 14px; border-radius: 12px;
            font-size: 14px; font-weight: 500; margin: 20px 20px 0 20px;
            text-align: center; animation: slideDown 0.3s ease;
        }

        /* ================= SKELETON LOADING ================= */
        .skeleton {
            background-color: var(--skeleton-bg);
            border-radius: 6px;
            animation: pulse 1.5s infinite ease-in-out;
        }

        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.4; }
            100% { opacity: 1; }
        }

        /* হেডারের জন্য স্কেলিটন (বড় সাইজ) */
        .skeleton-header-name { width: 100px; height: 18px; }
        .skeleton-header-img { width: 65px; height: 65px; border-radius: 50%; }

        /* লিস্টের জন্য স্কেলিটন */
        .skeleton-section-title { width: 100px; height: 16px; margin: 20px 20px 10px 20px; }
        
        .skeleton-list-item {
            display: flex; align-items: center; justify-content: space-between;
            background: var(--card-bg); border: 1px solid var(--border-color);
            padding: 16px; border-radius: 16px;
        }
        
        .skeleton-item-left { display: flex; align-items: center; gap: 15px; width: 100%; }
        .skeleton-icon { width: 46px; height: 46px; border-radius: 14px; flex-shrink: 0; }
        .skeleton-text-container { display: flex; flex-direction: column; gap: 6px; width: 60%; }
        .skeleton-line1 { width: 70%; height: 14px; }
        .skeleton-line2 { width: 100%; height: 12px; }

        /* ডাটা লোড হওয়ার পর দেখাবে */
        #realHeader { display: none; }
        #realContent { display: none; }
    </style>
</head>
<body>

    <!-- Top Header -->
    <div class="top-header">
        <div class="header-left">
            <a href="dashboard.php" class="back-btn">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
            </a>
            <div class="page-title">My Profile</div>
        </div>

        <!-- ১. হেডার স্কেলিটন লোডিং -->
        <div class="header-right" id="skeletonHeader">
            <div class="skeleton skeleton-header-name"></div>
            <div class="skeleton skeleton-header-img"></div>
        </div>

        <!-- ২. হেডার আসল ডেটা -->
        <div class="header-right" id="realHeader">
            <span class="player-name-top"><?= htmlspecialchars($current_name) ?></span>
            <img src="<?= htmlspecialchars(getImgPath($current_image)) ?>" alt="Player" class="player-img-top">
        </div>
    </div>

    <!-- ১. বডি SKELETON LOADING -->
    <div id="skeletonLoader">
        <div class="skeleton skeleton-section-title"></div>
        <div class="list-container">
            <div class="skeleton-list-item">
                <div class="skeleton-item-left">
                    <div class="skeleton skeleton-icon"></div>
                    <div class="skeleton-text-container">
                        <div class="skeleton skeleton-line1"></div>
                        <div class="skeleton skeleton-line2"></div>
                    </div>
                </div>
            </div>
            <div class="skeleton-list-item">
                <div class="skeleton-item-left">
                    <div class="skeleton skeleton-icon"></div>
                    <div class="skeleton-text-container">
                        <div class="skeleton skeleton-line1"></div>
                        <div class="skeleton skeleton-line2"></div>
                    </div>
                </div>
            </div>
            <div class="skeleton-list-item">
                <div class="skeleton-item-left">
                    <div class="skeleton skeleton-icon"></div>
                    <div class="skeleton-text-container">
                        <div class="skeleton skeleton-line1"></div>
                        <div class="skeleton skeleton-line2"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ২. বডি আসল ডেটা -->
    <div id="realContent">
        
        <?php if (!empty($success_msg)): ?>
            <div class="success-msg">✅ <?= htmlspecialchars($success_msg) ?></div>
        <?php endif; ?>

        <!-- My Ranking Button -->
        <div class="list-container" style="margin-top: 20px;">
            <div class="list-item" onclick="window.location.href='my-ranking.php'" style="border-color: #3b82f6;">
                <div class="item-left">
                    <div class="icon-box bg-rank">
                        <svg viewBox="0 0 24 24"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
                    </div>
                    <div class="item-text">
                        <span class="item-title" style="color: #facc15;">My Ranking</span>
                        <span class="item-desc">View your full player stats</span>
                    </div>
                </div>
                <svg class="arrow-icon" viewBox="0 0 24 24"><path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z"/></svg>
            </div>
        </div>

        <!-- Accounts Section -->
        <div class="section-title">Accounts</div>
        <div class="list-container">
            
            <!-- Facebook Profile -->
            <div class="list-item" onclick="toggleForm('form-fb')">
                <div class="item-left">
                    <div class="icon-box bg-fb">
                        <svg viewBox="0 0 24 24"><path d="M14 13.5h2.5l1-4H14v-2c0-1.03 0-2 2-2h1.5V2.14c-.326-.043-1.557-.14-2.857-.14C11.928 2 10 3.657 10 6.7v2.8H7v4h3V22h4v-8.5z"/></svg>
                    </div>
                    <div class="item-text">
                        <span class="item-title">Facebook Profile</span>
                        <span class="item-desc">Update name and Facebook link</span>
                    </div>
                </div>
                <svg class="arrow-icon" viewBox="0 0 24 24"><path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z"/></svg>
            </div>

            <!-- UID & Device -->
            <div class="list-item" onclick="toggleForm('form-uid')">
                <div class="item-left">
                    <div class="icon-box bg-uid">
                        <svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-7 12h-2v-2h2v2zm0-4h-2V6h2v4z"/></svg>
                    </div>
                    <div class="item-text">
                        <span class="item-title">UID & Device</span>
                        <span class="item-desc">Update Konami UID and device</span>
                    </div>
                </div>
                <svg class="arrow-icon" viewBox="0 0 24 24"><path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z"/></svg>
            </div>

            <!-- Email & Password -->
            <div class="list-item">
                <div class="item-left">
                    <div class="icon-box bg-mail">
                        <svg viewBox="0 0 24 24"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/></svg>
                    </div>
                    <div class="item-text">
                        <span class="item-title">Email & Password</span>
                        <span class="item-desc">Update email and password</span>
                    </div>
                </div>
                <svg class="arrow-icon" viewBox="0 0 24 24"><path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z"/></svg>
            </div>

            <!-- Other Info -->
            <div class="list-item">
                <div class="item-left">
                    <div class="icon-box bg-info">
                        <svg viewBox="0 0 24 24"><path d="M11 7h2v2h-2zm0 4h2v6h-2zm1-9C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/></svg>
                    </div>
                    <div class="item-text">
                        <span class="item-title">Other Information</span>
                        <span class="item-desc">Blood, birthday, country, etc.</span>
                    </div>
                </div>
                <svg class="arrow-icon" viewBox="0 0 24 24"><path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z"/></svg>
            </div>
        </div>

        <!-- Edit Forms -->
        
        <!-- Facebook Form -->
        <div id="form-fb" class="edit-form-container">
            <form method="POST" action="">
                <div class="form-group">
                    <label>Player Name</label>
                    <input type="text" name="player_name" value="<?= htmlspecialchars($current_name) ?>" placeholder="Enter your Name" required>
                </div>
                <div class="form-group">
                    <label>Facebook Profile Link</label>
                    <input type="url" name="fb_link" value="<?= htmlspecialchars($current_fb) ?>" placeholder="https://facebook.com/yourprofile" required>
                </div>
                
                <input type="hidden" name="konami_user_id" value="<?= htmlspecialchars($current_konami) ?>">
                <input type="hidden" name="device_name" value="<?= htmlspecialchars($current_device) ?>">
                
                <button type="submit" class="save-btn">Save Details</button>
            </form>
        </div>

        <!-- UID & Device Form -->
        <div id="form-uid" class="edit-form-container">
            <form method="POST" action="">
                <div class="form-group">
                    <label>Konami User ID</label>
                    <input type="text" name="konami_user_id" value="<?= htmlspecialchars($current_konami) ?>" placeholder="Enter your Konami ID" required>
                </div>
                <div class="form-group">
                    <label>Device Name</label>
                    <input type="text" name="device_name" value="<?= htmlspecialchars($current_device) ?>" placeholder="e.g. iPhone 13, PC" required>
                </div>
                
                <input type="hidden" name="fb_link" value="<?= htmlspecialchars($current_fb) ?>">
                <input type="hidden" name="player_name" value="<?= htmlspecialchars($current_name) ?>">
                
                <button type="submit" class="save-btn">Save UID & Device</button>
            </form>
        </div>
    </div>

    <script>
        function toggleForm(formId) {
            var forms = document.querySelectorAll('.edit-form-container');
            forms.forEach(function(form) {
                if (form.id !== formId) {
                    form.style.display = 'none';
                }
            });

            var selectedForm = document.getElementById(formId);
            if (selectedForm.style.display === 'block') {
                selectedForm.style.display = 'none';
            } else {
                selectedForm.style.display = 'block';
                selectedForm.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }

        // ---- লোডিং সিমুলেশন ----
        window.addEventListener('load', function() {
            setTimeout(function() {
                // হেডার লোডিং সরিয়ে আসল হেডার দেখাবে
                document.getElementById('skeletonHeader').style.display = 'none';
                document.getElementById('realHeader').style.display = 'flex';

                // বডি লোডিং সরিয়ে আসল বডি দেখাবে
                document.getElementById('skeletonLoader').style.display = 'none';
                document.getElementById('realContent').style.display = 'block';
            }, 1000); 
        });

        window.onload = function() {
            var savedTheme = localStorage.getItem('ecob-theme');
            if (savedTheme === 'light') {
                document.body.classList.add('light-mode');
            }
        };
    </script>

</body>
</html>