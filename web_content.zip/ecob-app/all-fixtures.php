<?php
// ecob-app/all-fixtures.php
session_start();

if (!isset($_SESSION['player_id'])) {
    header('Location: /ecob-app/login.php');
    exit;
}

$host     = 'localhost';
$dbname   = 'ecobdhwl_ecob_database';
$username = 'ecobdhwl_ecobcpanel';
$password = 'ecobshakil1234';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("❌ Connection failed: " . $e->getMessage());
}

function getImgPath($img) {
    if (empty($img) || $img == 'default.png') {
        return 'https://cdn-icons-png.flaticon.com/512/149/149071.png'; 
    }
    if (strpos($img, 'http') === 0) return $img; 
    if (strpos($img, 'uploads/') === 0) return '/' . $img;
    return '/uploads/' . $img; 
}

$search = isset($_GET['search']) ? trim($_GET['search']) : '';

$sql = "SELECT 
            ms.tour_name,
            ms.match_date,
            ms.details_id,
            hc.club_name AS home_name,
            hc.logo AS home_logo,
            ac.club_name AS away_name,
            ac.logo AS away_logo
        FROM match_schedule ms
        LEFT JOIN club_register hc ON ms.club_id_home = hc.id
        LEFT JOIN club_register ac ON ms.club_id_away = ac.id
        WHERE NOW() <= DATE_ADD(ms.match_date, INTERVAL 2 DAY)";

$params = [];
if (!empty($search)) {
    $sql .= " AND (hc.club_name LIKE ? 
               OR ac.club_name LIKE ? 
               OR ms.tour_name LIKE ? 
               OR ms.details_id LIKE ?)";
    $searchParam = "%" . $search . "%";
    $params = [$searchParam, $searchParam, $searchParam, $searchParam];
}

$sql .= " ORDER BY ms.match_date ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$fixtures = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>All Fixtures — ECOB</title>
    <style>
        :root {
            --bg-color: #000000;
            --text-color: #ffffff;
            --text-muted: #94a3b8;
            --border-color: #27272a;
            --card-bg: #121212;
            --team-box-bg: #18181b;
            --meta-bg: #18181b;
            --skeleton-bg: #1e1e1e; /* নতুন */
        }

        body.light-mode {
            --bg-color: #f8fafc;
            --text-color: #0f172a;
            --text-muted: #64748b;
            --border-color: #e2e8f0;
            --card-bg: #ffffff;
            --team-box-bg: #f1f5f9;
            --meta-bg: #f8fafc;
            --skeleton-bg: #e2e8f0; /* নতুন */
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            -webkit-tap-highlight-color: transparent;
            transition: background-color 0.3s, color 0.3s, border-color 0.3s;
        }

        body {
            background-color: var(--bg-color);
            color: var(--text-color);
            min-height: 100vh;
            padding: 24px 20px;
        }

        .top-header {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            gap: 12px;
        }

        .back-btn {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            color: var(--text-color);
            padding: 10px 14px;
            border-radius: 10px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
            display: flex;
            align-items: center;
        }

        .page-title {
            font-size: 18px;
            font-weight: 700;
        }

        .search-box {
            display: flex;
            gap: 8px;
            margin-bottom: 20px;
        }

        .search-box input {
            flex: 1;
            padding: 14px 16px;
            font-size: 14px;
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            color: var(--text-color);
            outline: none;
        }

        .search-box input:focus {
            border-color: #3b82f6;
        }

        .search-btn {
            background: #3b82f6;
            color: white;
            border: none;
            padding: 0 20px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
        }

        .fixture-list {
            display: flex;
            flex-direction: column;
            gap: 12px;
            width: 100%;
        }

        .match-card {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 14px;
            padding: 16px;
            display: flex;
            flex-direction: column;
            cursor: pointer;
            -webkit-user-select: none;
            user-select: none;
            width: 100%;
            overflow: hidden; 
        }

        .match-card:active {
            transform: scale(0.98);
        }

        .tour-name { 
            font-size: 13px; 
            font-weight: 600; 
            color: var(--text-muted); 
            margin-bottom: 12px; 
        }

        .match-teams {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 8px;
            margin-bottom: 14px;
            width: 100%;
        }

        .team-box {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            background: var(--team-box-bg);
            padding: 10px 8px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 13px;
            flex: 1;
            min-width: 0; 
        }

        .team-box img {
            width: 28px;
            height: 28px;
            object-fit: contain;
            border-radius: 50%;
            background: var(--card-bg);
            padding: 2px;
            border: 1px solid var(--border-color);
            flex-shrink: 0; 
        }

        .team-box span {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            display: block;
        }

        .vs {
            font-size: 12px;
            font-weight: 700;
            color: #3b82f6;
            background: rgba(59, 130, 246, 0.1);
            padding: 4px 8px;
            border-radius: 20px;
            flex-shrink: 0;
        }

        .match-meta {
            font-size: 12px;
            color: var(--text-muted);
            display: flex;
            justify-content: space-between;
            gap: 8px;
            flex-wrap: wrap;
            width: 100%;
        }

        .match-meta span {
            background: var(--meta-bg);
            padding: 6px 10px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .no-data {
            text-align: center;
            padding: 40px 20px;
            color: var(--text-muted);
            font-size: 14px;
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
        }

        /* ================= SKELETON LOADING ================= */
        .skeleton {
            background-color: var(--skeleton-bg);
            border-radius: 6px;
            animation: pulse 1.5s infinite ease-in-out;
        }

        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.4; }
            100% { opacity: 1; }
        }

        .skeleton-card {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 14px;
            padding: 16px;
            display: flex;
            flex-direction: column;
            gap: 12px;
            width: 100%;
        }

        .skeleton-title { width: 40%; height: 14px; }
        .skeleton-teams { display: flex; justify-content: space-between; gap: 8px; }
        .skeleton-team { 
            flex: 1; display: flex; align-items: center; justify-content: center; gap: 6px;
            background: var(--team-box-bg); padding: 10px 8px; border-radius: 10px; 
        }
        .skeleton-circle { width: 28px; height: 28px; border-radius: 50%; flex-shrink: 0; }
        .skeleton-line { width: 60%; height: 14px; }
        .skeleton-footer { width: 100%; height: 24px; }
    </style>
</head>
<body>

    <div class="top-header">
        <a href="dashboard.php" class="back-btn">← Back</a>
        <div class="page-title">All Fixtures</div>
    </div>

    <form method="GET" action="" class="search-box">
        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search club, tournament...">
        <button type="submit" class="search-btn">Search</button>
    </form>

    <!-- ১. SKELETON LOADING (প্রথমে এটা দেখাবে) -->
    <div class="fixture-list" id="skeletonLoader">
        <div class="skeleton-card">
            <div class="skeleton skeleton-title"></div>
            <div class="skeleton-teams">
                <div class="skeleton-team">
                    <div class="skeleton skeleton-circle"></div>
                    <div class="skeleton skeleton-line"></div>
                </div>
                <div class="skeleton-team">
                    <div class="skeleton skeleton-circle"></div>
                    <div class="skeleton skeleton-line"></div>
                </div>
            </div>
            <div class="skeleton skeleton-footer"></div>
        </div>
        <div class="skeleton-card">
            <div class="skeleton skeleton-title"></div>
            <div class="skeleton-teams">
                <div class="skeleton-team">
                    <div class="skeleton skeleton-circle"></div>
                    <div class="skeleton skeleton-line"></div>
                </div>
                <div class="skeleton-team">
                    <div class="skeleton skeleton-circle"></div>
                    <div class="skeleton skeleton-line"></div>
                </div>
            </div>
            <div class="skeleton skeleton-footer"></div>
        </div>
        <div class="skeleton-card">
            <div class="skeleton skeleton-title"></div>
            <div class="skeleton-teams">
                <div class="skeleton-team">
                    <div class="skeleton skeleton-circle"></div>
                    <div class="skeleton skeleton-line"></div>
                </div>
                <div class="skeleton-team">
                    <div class="skeleton skeleton-circle"></div>
                    <div class="skeleton skeleton-line"></div>
                </div>
            </div>
            <div class="skeleton skeleton-footer"></div>
        </div>
    </div>

    <!-- ২. আসল ডেটা (পরে এটা দেখাবে) -->
    <div class="fixture-list" id="realContent" style="display: none;">
        <?php if (count($fixtures) > 0): ?>
            <?php foreach ($fixtures as $row): 
                $home = $row['home_name'] ?? 'Unknown';
                $away = $row['away_name'] ?? 'Unknown';
                $tour = $row['tour_name'] ?? '';
                $link = "match-id.php?details_id=" . $row['details_id'];
            ?>
                <div class="match-card" onclick="window.location.href='<?= $link ?>'">
                    <div class="tour-name">🏆 <?= htmlspecialchars($tour) ?></div>
                    
                    <div class="match-teams">
                        <div class="team-box">
                            <?php if (!empty($row['home_logo'])): ?>
                                <img src="<?= htmlspecialchars(getImgPath($row['home_logo'])) ?>" alt="logo">
                            <?php endif; ?>
                            <span><?= htmlspecialchars($home) ?></span>
                        </div>
                        <span class="vs">VS</span>
                        <div class="team-box">
                            <?php if (!empty($row['away_logo'])): ?>
                                <img src="<?= htmlspecialchars(getImgPath($row['away_logo'])) ?>" alt="logo">
                            <?php endif; ?>
                            <span><?= htmlspecialchars($away) ?></span>
                        </div>
                    </div>

                    <div class="match-meta">
                        <span>📅 <?= date("d M, g:i A", strtotime($row['match_date'])) ?></span>
                        <span>📌 <?= htmlspecialchars($row['details_id']) ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="no-data">No fixtures found.</div>
        <?php endif; ?>
    </div>

    <script>
        // ---- লোডিং সিমুলেশন ----
        window.addEventListener('load', function() {
            // ১ সেকেন্ড পর লোডিং সরিয়ে আসল ডেটা দেখাবে
            setTimeout(function() {
                document.getElementById('skeletonLoader').style.display = 'none';
                document.getElementById('realContent').style.display = 'flex';
            }, 1000); // ১০০০ = ১ সেকেন্ড
        });

        // ---- থিম চেক ----
        window.onload = function() {
            var savedTheme = localStorage.getItem('ecob-theme');
            if (savedTheme === 'light') {
                document.body.classList.add('light-mode');
            }
        };
    </script>

</body>
</html>