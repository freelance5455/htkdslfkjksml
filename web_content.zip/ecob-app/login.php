<?php
// ecob-app/login.php
session_start();

// ---- Database connection ----
$host     = 'localhost';
$dbname   = 'ecobdhwl_ecob_database';
$username = 'ecobdhwl_ecobcpanel';
$password = 'ecobshakil1234';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("❌ Connection failed: " . $e->getMessage());
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $gmail = trim($_POST['gmail'] ?? '');

    if ($gmail === '') {
        $error = 'Please enter your email address.';
    } elseif (!filter_var($gmail, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM player_register WHERE gmail = ? LIMIT 1");
        $stmt->execute([$gmail]);
        $player = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($player) {
            $_SESSION['player_id']    = $player['player_id'];
            $_SESSION['player_name']  = $player['player_name'];
            $_SESSION['player_gmail'] = $player['gmail'];
            $_SESSION['player_image'] = $player['image_link'];

            header('Location: /ecob-app/dashboard.php');
            exit;
        } else {
            $error = 'No account found with this email.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Login — ECOB</title>
    <style>
        /* ---- CSS Variables ---- */
        :root {
            --brand-blue: #3b82f6;
            --brand-dark: #0f172a;
            --input-bg: rgba(255, 255, 255, 0.05);
            --border-color: rgba(255, 255, 255, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            background-color: #000000;
            color: #ffffff;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        /* ---------- Top Image ---------- */
        .top-image-container {
            width: 100%;
            height: 40vh;
            position: relative;
            overflow: hidden;
            display: flex;
            justify-content: center;
        }

        .top-image-container img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: top center;
            opacity: 0.85; /* ছবিটা একটু ডার্ক করলাম যাতে নিচের ডিজাইন ফুটে ওঠে */
        }

        .fade-overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 150px;
            background: linear-gradient(to bottom, transparent, #000000);
            z-index: 1;
        }

        /* ---------- Content Section ---------- */
        .content-container {
            width: 100%;
            max-width: 400px;
            padding: 0 24px;
            margin-top: -40px;
            position: relative;
            z-index: 2;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        /* ECOB Logo Style */
        .logo-text {
            font-size: 40px;
            font-weight: 800;
            letter-spacing: 5px;
            color: #ffffff;
            text-shadow: 0 2px 10px rgba(59, 130, 246, 0.5);
            margin-bottom: 8px;
            text-transform: uppercase;
        }

        /* নতুন টেক্সট */
        .custom-tagline {
            text-align: center;
            color: #94a3b8;
            font-size: 14px;
            line-height: 1.5;
            margin-bottom: 32px;
            padding: 0 10px;
        }

        /* ---------- Gmail Input (Icon inside) ---------- */
        .input-group {
            width: 100%;
            position: relative;
            margin-bottom: 20px;
        }

        .input-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
            width: 20px;
            height: 20px;
        }

        .input-group input {
            width: 100%;
            padding: 16px 16px 16px 48px; /* বাম পাশে আইকনের জন্য জায়গা */
            background: var(--input-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            color: #ffffff;
            font-size: 15px;
            outline: none;
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .input-group input::placeholder {
            color: #64748b;
        }

        .input-group input:focus {
            border-color: var(--brand-blue);
            background: rgba(255, 255, 255, 0.08);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
        }

        /* ---------- Professional Button ---------- */
        .btn-continue {
            width: 100%;
            padding: 16px;
            background: var(--brand-blue);
            color: #ffffff;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            margin-bottom: 24px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);
        }

        .btn-continue:hover {
            background: #2563eb;
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.5);
            transform: translateY(-1px);
        }

        .btn-continue:active {
            transform: translateY(1px);
        }

        /* ---------- Error Box ---------- */
        .error-box {
            width: 100%;
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.2);
            color: #fca5a5;
            padding: 12px;
            border-radius: 10px;
            font-size: 13px;
            margin-bottom: 16px;
            text-align: center;
        }

        /* ---------- Footer Link ---------- */
        .guest-link {
            color: #64748b;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            transition: color 0.2s;
        }

        .guest-link:hover {
            color: #ffffff;
        }
    </style>
</head>
<body>

    <!-- Top Image -->
    <div class="top-image-container">
        <img src="https://i.postimg.cc/fTBZrh0v/inbound2965506802037387077.jpg" alt="Player">
        <div class="fade-overlay"></div>
    </div>

    <!-- Main Content -->
    <div class="content-container">
        
        <!-- Logo -->
        <div class="logo-text">ECOB</div>
        
        <!-- Custom Text (No Copy) -->
        <p class="custom-tagline">
            Welcome to the official ECOB platform. Sign in to manage your profile, join tournaments, and connect with the community.
        </p>

        <!-- Error Message -->
        <?php if ($error): ?>
            <div class="error-box">⚠️ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <!-- Form -->
        <form method="POST" action="" style="width: 100%;">
            
            <!-- Gmail Input with Icon -->
            <div class="input-group">
                <!-- Email SVG Icon -->
                <svg class="input-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                </svg>
                <input type="email" name="gmail" required placeholder="Enter your Gmail">
            </div>

            <!-- Professional Button -->
            <button type="submit" class="btn-continue">Sign In to ECOB</button>
        </form>

        <!-- Guest Link -->
        <a href="#" class="guest-link">Continue as Guest</a>

    </div>

</body>
</html>