<?php
// ecob-app/error.php
http_response_code(503);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>ECOB - Error</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
        body {
            background-color: #000000; color: #ffffff; min-height: 100vh; 
            display: flex; align-items: center; justify-content: center; padding: 20px;
            text-align: center;
        }
        .error-box {
            background: #121212; border: 1px solid #27272a; border-radius: 16px;
            padding: 40px 24px; max-width: 400px; width: 100%;
        }
        .icon { font-size: 50px; margin-bottom: 16px; }
        h1 { font-size: 22px; font-weight: 700; margin-bottom: 10px; color: #ffffff; }
        p { font-size: 14px; color: #94a3b8; margin-bottom: 24px; line-height: 1.5; }
        .btn {
            display: inline-block; padding: 14px 24px; background: #3b82f6;
            color: #ffffff; text-decoration: none; border-radius: 10px;
            font-weight: 600; font-size: 15px; cursor: pointer;
        }
        .btn:active { background: #2563eb; }
    </style>
</head>
<body>
    <div class="error-box">
        <div class="icon">⚠️</div>
        <h1>Oops! Something went wrong</h1>
        <p>The ECOB server is currently busy or you have a connection issue. Please try again later.</p>
        <a href="dashboard.php" class="btn">Try Again</a>
    </div>
</body>
</html>