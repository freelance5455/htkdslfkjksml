/**
 * app.js - Main Application Logic & UI Controller
 */

// Global State
let currentTab = 'dashboard';
let activeCustomerId = null;
let activeItemId = null;
let currencySymbol = '₹';

// Format currency
function formatMoney(amount) {
  const val = parseFloat(amount) || 0;
  return `${currencySymbol}${val.toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
}

// Format date
function formatDate(isoStr) {
  if (!isoStr) return '';
  const d = new Date(isoStr);
  return d.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

// Format date short
function formatDateShort(isoStr) {
  if (!isoStr) return '';
  const d = new Date(isoStr);
  return d.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
}

// Toast notification
function showToast(message, type = 'info') {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = message;
  toast.className = `toast show toast-${type}`;
  setTimeout(() => {
    toast.className = 'toast';
  }, 3000);
}

// ----------------- TAB NAVIGATION -----------------

function switchTab(tabName) {
  currentTab = tabName;
  
  // Update nav buttons
  document.querySelectorAll('.nav-item').forEach(btn => {
    if (btn.dataset.tab === tabName) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });

  // Update sections
  document.querySelectorAll('.tab-section').forEach(sec => {
    if (sec.id === `section-${tabName}`) {
      sec.classList.add('active');
    } else {
      sec.classList.remove('active');
    }
  });

  // Load section data
  if (tabName === 'dashboard') loadDashboard();
  if (tabName === 'goods-in') loadGoodsInForm();
  if (tabName === 'goods-out') loadGoodsOutForm();
  if (tabName === 'customers') loadCustomersList();
  if (tabName === 'inventory') loadInventoryList();
}

// ----------------- DASHBOARD -----------------

async function loadDashboard() {
  try {
    const stats = await getDashboardStats();
    
    document.getElementById('stat-stock-value').textContent = formatMoney(stats.totalStockValue);
    document.getElementById('stat-stock-units').textContent = `${stats.totalStockUnits} Units (${stats.itemCount} Products)`;
    
    document.getElementById('stat-customer-due').textContent = formatMoney(stats.totalCustomerDue);
    document.getElementById('stat-customer-count').textContent = `From ${stats.customerCount} Customers`;

    document.getElementById('stat-low-stock').textContent = stats.lowStockCount;
    document.getElementById('stat-today-in').textContent = `${stats.todayInCount} Entries`;
    document.getElementById('stat-today-out').textContent = `${stats.todayOutCount} Bills`;
    document.getElementById('stat-today-cash').textContent = formatMoney(stats.todayCollectedCash);

    // Recent activity
    const recentTxns = await getAllTransactions(10);
    const activityList = document.getElementById('recent-activity-list');
    activityList.innerHTML = '';

    if (recentTxns.length === 0) {
      activityList.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">📦</div>
          <p>No transactions yet.<br>Record Goods In or Goods Out to get started!</p>
        </div>`;
      return;
    }

    recentTxns.forEach(t => {
      const isOut = t.type === 'OUT';
      const itemEl = document.createElement('div');
      itemEl.className = 'activity-card';
      
      itemEl.innerHTML = `
        <div class="activity-badge ${isOut ? 'badge-out' : 'badge-in'}">
          ${isOut ? 'OUT' : 'IN'}
        </div>
        <div class="activity-info">
          <div class="activity-title">
            <strong>${isOut ? t.customerName : t.itemName}</strong>
            <span class="activity-qty ${isOut ? 'text-red' : 'text-green'}">
              ${isOut ? '-' : '+'}${t.quantity} ${t.unit || 'pcs'}
            </span>
          </div>
          <div class="activity-subtitle">
            ${isOut ? `Item: ${t.itemName}` : `Cost: ${formatMoney(t.totalAmount)}`} • ${formatDateShort(t.timestamp)}
          </div>
        </div>
        <div class="activity-amount">
          ${formatMoney(t.totalAmount)}
          ${isOut && t.dueAmount > 0 ? `<div class="badge-due-sm">Due: ${formatMoney(t.dueAmount)}</div>` : ''}
        </div>
      `;
      activityList.appendChild(itemEl);
    });

  } catch (err) {
    console.error('Failed to load dashboard:', err);
  }
}

// ----------------- GOODS IN (STOCK RESTOCK) -----------------

async function loadGoodsInForm() {
  const select = document.getElementById('in-item-select');
  const items = await getAllItems();
  
  select.innerHTML = '<option value="">-- Select Product / Item --</option>';
  items.forEach(it => {
    select.innerHTML += `<option value="${it.id}" data-price="${it.purchasePrice}" data-stock="${it.currentStock}" data-unit="${it.unit}">
      ${it.name} (Stock: ${it.currentStock} ${it.unit})
    </option>`;
  });

  // Reset form fields
  document.getElementById('in-qty').value = '';
  document.getElementById('in-price').value = '';
  document.getElementById('in-supplier').value = '';
  document.getElementById('in-notes').value = '';
  document.getElementById('in-stock-preview').textContent = 'Select an item to see current stock';
  
  // Set current date/time
  const now = new Date();
  now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
  document.getElementById('in-date').value = now.toISOString().slice(0, 16);
}

function onGoodsInItemChange() {
  const select = document.getElementById('in-item-select');
  const selectedOpt = select.options[select.selectedIndex];
  if (selectedOpt && selectedOpt.value) {
    const price = selectedOpt.dataset.price || '';
    const stock = selectedOpt.dataset.stock || '0';
    const unit = selectedOpt.dataset.unit || 'pcs';
    document.getElementById('in-price').value = price;
    document.getElementById('in-stock-preview').innerHTML = `Current Stock: <strong>${stock} ${unit}</strong>`;
  } else {
    document.getElementById('in-stock-preview').textContent = 'Select an item to see current stock';
  }
}

async function handleGoodsInSubmit(e) {
  e.preventDefault();
  const itemId = document.getElementById('in-item-select').value;
  const quantity = document.getElementById('in-qty').value;
  const purchasePrice = document.getElementById('in-price').value;
  const supplier = document.getElementById('in-supplier').value;
  const notes = document.getElementById('in-notes').value;
  const date = document.getElementById('in-date').value;

  if (!itemId) {
    showToast('Please select an item', 'error');
    return;
  }
  if (!quantity || parseFloat(quantity) <= 0) {
    showToast('Please enter a valid quantity', 'error');
    return;
  }

  try {
    await recordGoodsIn({
      itemId,
      quantity,
      purchasePrice,
      supplier,
      notes,
      date
    });

    showToast('Stock Added Successfully! (+ Goods In)', 'success');
    loadGoodsInForm();
    loadDashboard();
  } catch (err) {
    showToast(err.message || 'Error recording Goods In', 'error');
  }
}

// ----------------- GOODS OUT (CUSTOMER DISPATCH) -----------------

async function loadGoodsOutForm() {
  const [items, customers] = await Promise.all([getAllItems(), getAllCustomers()]);

  // Customer Select
  const custSelect = document.getElementById('out-customer-select');
  custSelect.innerHTML = '<option value="">-- Select Customer --</option>';
  customers.forEach(c => {
    custSelect.innerHTML += `<option value="${c.id}" data-due="${c.balanceDue || 0}">
      ${c.name} ${c.phone ? `(${c.phone})` : ''} ${c.balanceDue > 0 ? `[Due: ${formatMoney(c.balanceDue)}]` : ''}
    </option>`;
  });

  // Item Select
  const itemSelect = document.getElementById('out-item-select');
  itemSelect.innerHTML = '<option value="">-- Select Item to Dispatch --</option>';
  items.forEach(it => {
    const isOut = (it.currentStock || 0) <= 0;
    itemSelect.innerHTML += `<option value="${it.id}" data-price="${it.sellingPrice}" data-stock="${it.currentStock}" data-unit="${it.unit}" ${isOut ? 'disabled' : ''}>
      ${it.name} (Stock: ${it.currentStock} ${it.unit})${isOut ? ' - OUT OF STOCK' : ''}
    </option>`;
  });

  // Reset fields
  document.getElementById('out-qty').value = '';
  document.getElementById('out-price').value = '';
  document.getElementById('out-total').value = '';
  document.getElementById('out-paid').value = '';
  document.getElementById('out-due').value = '';
  document.getElementById('out-notes').value = '';
  document.getElementById('out-stock-preview').textContent = 'Select an item to view available stock';

  // Current date/time
  const now = new Date();
  now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
  document.getElementById('out-date').value = now.toISOString().slice(0, 16);
}

function onGoodsOutItemChange() {
  const select = document.getElementById('out-item-select');
  const selectedOpt = select.options[select.selectedIndex];
  if (selectedOpt && selectedOpt.value) {
    const price = selectedOpt.dataset.price || '';
    const stock = parseFloat(selectedOpt.dataset.stock) || 0;
    const unit = selectedOpt.dataset.unit || 'pcs';
    document.getElementById('out-price').value = price;
    
    if (stock <= 0) {
      document.getElementById('out-stock-preview').innerHTML = `<span class="text-red">⚠️ OUT OF STOCK! Available: 0 ${unit}</span>`;
    } else {
      document.getElementById('out-stock-preview').innerHTML = `Available in Stock: <strong>${stock} ${unit}</strong>`;
    }
  } else {
    document.getElementById('out-stock-preview').textContent = 'Select an item to view available stock';
  }
  calculateGoodsOutTotals();
}

function calculateGoodsOutTotals() {
  const qty = parseFloat(document.getElementById('out-qty').value) || 0;
  const price = parseFloat(document.getElementById('out-price').value) || 0;
  const total = qty * price;
  
  document.getElementById('out-total').value = total > 0 ? total.toFixed(2) : '';

  const paidInput = document.getElementById('out-paid');
  const paid = parseFloat(paidInput.value);

  // If user hasn't typed paid yet, default to full payment
  let actualPaid = isNaN(paid) ? total : paid;
  const due = Math.max(0, total - actualPaid);

  document.getElementById('out-due').value = due.toFixed(2);
}

function onGoodsOutPaidChange() {
  const total = parseFloat(document.getElementById('out-total').value) || 0;
  const paid = parseFloat(document.getElementById('out-paid').value) || 0;
  const due = Math.max(0, total - paid);
  document.getElementById('out-due').value = due.toFixed(2);
}

async function handleGoodsOutSubmit(e) {
  e.preventDefault();
  const customerId = document.getElementById('out-customer-select').value;
  const itemId = document.getElementById('out-item-select').value;
  const quantity = document.getElementById('out-qty').value;
  const sellingPrice = document.getElementById('out-price').value;
  const total = parseFloat(document.getElementById('out-total').value) || 0;
  const paidAmount = document.getElementById('out-paid').value === '' ? total : parseFloat(document.getElementById('out-paid').value);
  const paymentMode = document.getElementById('out-payment-mode').value;
  const notes = document.getElementById('out-notes').value;
  const date = document.getElementById('out-date').value;

  if (!customerId) {
    showToast('Please select a customer', 'error');
    return;
  }
  if (!itemId) {
    showToast('Please select an item', 'error');
    return;
  }
  if (!quantity || parseFloat(quantity) <= 0) {
    showToast('Please enter a valid quantity', 'error');
    return;
  }

  try {
    await recordGoodsOut({
      customerId,
      itemId,
      quantity,
      sellingPrice,
      paidAmount,
      paymentMode,
      notes,
      date
    });

    const [item, customer] = await Promise.all([getItemById(itemId), getCustomerById(customerId)]);
    const dueAmount = Math.max(0, total - paidAmount);

    showToast('Goods Out Recorded Successfully! (- Stock)', 'success');
    
    // Open Bill / WhatsApp share modal
    showSuccessBillModal({
      customerName: customer.name,
      customerPhone: customer.phone,
      itemName: item.name,
      quantity: quantity,
      unit: item.unit,
      totalAmount: total,
      paidAmount: paidAmount,
      dueAmount: dueAmount,
      newTotalDue: customer.balanceDue
    });

    loadGoodsOutForm();
    loadDashboard();
  } catch (err) {
    showToast(err.message || 'Error recording Goods Out', 'error');
  }
}

// ----------------- CUSTOMERS DIRECTORY & LEDGER -----------------

async function loadCustomersList(searchQuery = '') {
  const listEl = document.getElementById('customers-list');
  const allCustomers = await getAllCustomers();

  let filtered = allCustomers;
  if (searchQuery.trim()) {
    const q = searchQuery.toLowerCase().trim();
    filtered = allCustomers.filter(c => 
      c.name.toLowerCase().includes(q) || 
      (c.phone && c.phone.includes(q))
    );
  }

  // Sort by balance due descending (highest debtor on top)
  filtered.sort((a, b) => (b.balanceDue || 0) - (a.balanceDue || 0));

  listEl.innerHTML = '';
  if (filtered.length === 0) {
    listEl.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">👥</div>
        <p>No customers found.<br>Click <strong>"+ Add Customer"</strong> to create one!</p>
      </div>`;
    return;
  }

  filtered.forEach(c => {
    const due = parseFloat(c.balanceDue) || 0;
    const card = document.createElement('div');
    card.className = 'customer-card';
    card.onclick = () => openCustomerDetail(c.id);

    card.innerHTML = `
      <div class="customer-avatar">${c.name.charAt(0).toUpperCase()}</div>
      <div class="customer-info">
        <div class="customer-name">${c.name}</div>
        <div class="customer-phone">${c.phone ? `📞 ${c.phone}` : 'No phone number'}</div>
        <div class="customer-subtext">Lifetime Purchases: ${formatMoney(c.totalPurchases)}</div>
      </div>
      <div class="customer-balance-block">
        <div class="customer-balance-label">${due > 0 ? 'Balance Due' : 'Status'}</div>
        <div class="customer-balance-amount ${due > 0 ? 'text-due' : 'text-clear'}">
          ${due > 0 ? formatMoney(due) : 'Clear ✓'}
        </div>
      </div>
    `;
    listEl.appendChild(card);
  });
}

async function openCustomerDetail(customerId) {
  activeCustomerId = customerId;
  const customer = await getCustomerById(customerId);
  if (!customer) return;

  const timeline = await getCustomerHistory(customerId);

  document.getElementById('modal-customer-name').textContent = customer.name;
  document.getElementById('modal-customer-phone').textContent = customer.phone ? `📞 ${customer.phone}` : 'No phone';
  document.getElementById('modal-customer-purchases').textContent = formatMoney(customer.totalPurchases);
  document.getElementById('modal-customer-paid').textContent = formatMoney(customer.totalPaid);
  
  const dueEl = document.getElementById('modal-customer-due');
  const due = parseFloat(customer.balanceDue) || 0;
  dueEl.textContent = formatMoney(due);
  dueEl.className = due > 0 ? 'stat-value text-red' : 'stat-value text-green';

  // Render Ledger Timeline
  const timelineEl = document.getElementById('customer-ledger-timeline');
  timelineEl.innerHTML = '';

  if (timeline.length === 0) {
    timelineEl.innerHTML = `<div class="empty-state"><p>No history yet for this customer.</p></div>`;
  } else {
    timeline.forEach(item => {
      const isPayment = item.recordCategory === 'PAYMENT';
      const el = document.createElement('div');
      el.className = `ledger-entry ${isPayment ? 'entry-payment' : 'entry-goods-out'}`;

      if (isPayment) {
        el.innerHTML = `
          <div class="ledger-icon">💳</div>
          <div class="ledger-details">
            <div class="ledger-title">Payment Received (${item.paymentMode || 'Cash'})</div>
            <div class="ledger-date">${formatDate(item.timestamp)} ${item.notes ? `• ${item.notes}` : ''}</div>
          </div>
          <div class="ledger-amount text-green">
            - ${formatMoney(item.amount)}
          </div>
        `;
      } else {
        el.innerHTML = `
          <div class="ledger-icon">📦</div>
          <div class="ledger-details">
            <div class="ledger-title">Took: ${item.quantity} ${item.unit || 'pcs'} of ${item.itemName}</div>
            <div class="ledger-date">${formatDate(item.timestamp)} • Paid: ${formatMoney(item.paidAmount)}</div>
          </div>
          <div class="ledger-amount ${item.dueAmount > 0 ? 'text-red' : 'text-slate'}">
            ${formatMoney(item.totalAmount)}
            ${item.dueAmount > 0 ? `<span class="badge-due-sm">+${formatMoney(item.dueAmount)} Due</span>` : ''}
          </div>
        `;
      }
      timelineEl.appendChild(el);
    });
  }

  // Setup WhatsApp statement button
  const waBtn = document.getElementById('btn-whatsapp-statement');
  waBtn.onclick = () => sendWhatsAppStatement(customer);

  openModal('customer-detail-modal');
}

function sendWhatsAppStatement(customer) {
  const due = parseFloat(customer.balanceDue) || 0;
  const message = `Hello ${customer.name},\n\nThis is an account statement from our store:\n` +
    `• Total Purchases: ${formatMoney(customer.totalPurchases)}\n` +
    `• Total Payments: ${formatMoney(customer.totalPaid)}\n` +
    `• Current Outstanding Balance: ${formatMoney(due)}\n\n` +
    (due > 0 ? `Please clear your pending balance at your earliest convenience. Thank you!` : `Your account is fully cleared. Thank you for your business!`);

  let cleanPhone = (customer.phone || '').replace(/[^0-9]/g, '');
  if (cleanPhone.length === 10) {
    cleanPhone = '91' + cleanPhone; // India country code default
  }

  const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
  window.open(url, '_blank');
}

// ----------------- RECEIVE PAYMENT MODAL -----------------

function openReceivePaymentModal() {
  if (!activeCustomerId) return;
  getCustomerById(activeCustomerId).then(c => {
    document.getElementById('pay-customer-name').textContent = c.name;
    document.getElementById('pay-current-due').textContent = formatMoney(c.balanceDue);
    document.getElementById('pay-amount').value = c.balanceDue > 0 ? c.balanceDue : '';
    document.getElementById('pay-notes').value = '';
    
    const now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    document.getElementById('pay-date').value = now.toISOString().slice(0, 16);

    openModal('receive-payment-modal');
  });
}

async function handleReceivePaymentSubmit(e) {
  e.preventDefault();
  const amount = document.getElementById('pay-amount').value;
  const paymentMode = document.getElementById('pay-mode').value;
  const notes = document.getElementById('pay-notes').value;
  const date = document.getElementById('pay-date').value;

  if (!amount || parseFloat(amount) <= 0) {
    showToast('Please enter a valid payment amount', 'error');
    return;
  }

  try {
    await recordCustomerPayment({
      customerId: activeCustomerId,
      amount,
      paymentMode,
      notes,
      date
    });

    showToast('Payment Recorded Successfully!', 'success');
    closeModal('receive-payment-modal');
    openCustomerDetail(activeCustomerId); // Refresh customer modal
    loadCustomersList();
    loadDashboard();
  } catch (err) {
    showToast(err.message || 'Error recording payment', 'error');
  }
}

// ----------------- INVENTORY LIST -----------------

async function loadInventoryList(searchQuery = '', filterType = 'all') {
  const listEl = document.getElementById('inventory-list');
  const allItems = await getAllItems();

  let filtered = allItems;
  if (searchQuery.trim()) {
    const q = searchQuery.toLowerCase().trim();
    filtered = allItems.filter(it => it.name.toLowerCase().includes(q));
  }

  if (filterType === 'low') {
    filtered = filtered.filter(it => it.currentStock <= it.minStockAlert && it.currentStock > 0);
  } else if (filterType === 'out') {
    filtered = filtered.filter(it => it.currentStock <= 0);
  }

  listEl.innerHTML = '';
  if (filtered.length === 0) {
    listEl.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">📦</div>
        <p>No items found.<br>Click <strong>"+ Add Item"</strong> to create your product list!</p>
      </div>`;
    return;
  }

  filtered.forEach(it => {
    const stock = parseFloat(it.currentStock) || 0;
    const alertLevel = parseFloat(it.minStockAlert) || 5;
    const assetVal = stock * (parseFloat(it.purchasePrice) || 0);

    let stockBadgeClass = 'badge-stock-ok';
    let stockStatusText = 'In Stock';
    if (stock <= 0) {
      stockBadgeClass = 'badge-stock-out';
      stockStatusText = 'Out of Stock';
    } else if (stock <= alertLevel) {
      stockBadgeClass = 'badge-stock-low';
      stockStatusText = 'Low Stock';
    }

    const card = document.createElement('div');
    card.className = 'item-card';
    card.onclick = () => openItemDetail(it.id);

    card.innerHTML = `
      <div class="item-header">
        <div class="item-title">${it.name}</div>
        <div class="item-badge ${stockBadgeClass}">${stockStatusText}</div>
      </div>
      <div class="item-body">
        <div class="item-metric">
          <span class="metric-label">Current Stock</span>
          <span class="metric-value font-bold">${stock} ${it.unit}</span>
        </div>
        <div class="item-metric">
          <span class="metric-label">Sale Rate</span>
          <span class="metric-value">${formatMoney(it.sellingPrice)}</span>
        </div>
        <div class="item-metric">
          <span class="metric-label">Stock Value</span>
          <span class="metric-value">${formatMoney(assetVal)}</span>
        </div>
      </div>
    `;
    listEl.appendChild(card);
  });
}

async function openItemDetail(itemId) {
  activeItemId = itemId;
  const item = await getItemById(itemId);
  if (!item) return;

  const history = await getItemHistory(itemId);

  document.getElementById('modal-item-name').textContent = item.name;
  document.getElementById('modal-item-stock').textContent = `${item.currentStock} ${item.unit}`;
  document.getElementById('modal-item-cost').textContent = formatMoney(item.purchasePrice);
  document.getElementById('modal-item-sell').textContent = formatMoney(item.sellingPrice);

  const historyEl = document.getElementById('item-history-timeline');
  historyEl.innerHTML = '';

  if (history.length === 0) {
    historyEl.innerHTML = `<div class="empty-state"><p>No stock movement history for this item yet.</p></div>`;
  } else {
    history.forEach(h => {
      const isOut = h.type === 'OUT';
      const el = document.createElement('div');
      el.className = `ledger-entry ${isOut ? 'entry-goods-out' : 'entry-goods-in'}`;
      el.innerHTML = `
        <div class="ledger-icon">${isOut ? '📤' : '📥'}</div>
        <div class="ledger-details">
          <div class="ledger-title">${isOut ? `Goods Out: to ${h.customerName}` : `Goods In: Restock ${h.supplier ? `(${h.supplier})` : ''}`}</div>
          <div class="ledger-date">${formatDate(h.timestamp)}</div>
        </div>
        <div class="ledger-amount ${isOut ? 'text-red' : 'text-green'}">
          ${isOut ? '-' : '+'}${h.quantity} ${h.unit || item.unit}
        </div>
      `;
      historyEl.appendChild(el);
    });
  }

  openModal('item-detail-modal');
}

// ----------------- MODALS & POPUPS -----------------

function openModal(modalId) {
  const m = document.getElementById(modalId);
  if (m) m.classList.add('active');
}

function closeModal(modalId) {
  const m = document.getElementById(modalId);
  if (m) m.classList.remove('active');
}

// Add Item Modal
function openAddItemModal(prefilledName = '') {
  document.getElementById('form-item').reset();
  document.getElementById('item-modal-id').value = '';
  document.getElementById('item-modal-title').textContent = 'Add New Product';
  if (prefilledName) {
    document.getElementById('item-name').value = prefilledName;
  }
  openModal('add-item-modal');
}

async function handleItemFormSubmit(e) {
  e.preventDefault();
  const id = document.getElementById('item-modal-id').value;
  const name = document.getElementById('item-name').value;
  const unit = document.getElementById('item-unit').value;
  const purchasePrice = document.getElementById('item-purchase-price').value;
  const sellingPrice = document.getElementById('item-selling-price').value;
  const currentStock = document.getElementById('item-initial-stock').value;
  const minStockAlert = document.getElementById('item-min-stock').value;

  try {
    await saveItem({
      id: id || undefined,
      name,
      unit,
      purchasePrice,
      sellingPrice,
      currentStock,
      minStockAlert
    });

    showToast(`Product "${name}" saved!`, 'success');
    closeModal('add-item-modal');
    loadInventoryList();
    loadDashboard();
    if (currentTab === 'goods-in') loadGoodsInForm();
    if (currentTab === 'goods-out') loadGoodsOutForm();
  } catch (err) {
    showToast(err.message || 'Error saving item', 'error');
  }
}

// Add Customer Modal
function openAddCustomerModal() {
  document.getElementById('form-customer').reset();
  document.getElementById('customer-modal-id').value = '';
  document.getElementById('customer-modal-title').textContent = 'Add New Customer';
  openModal('add-customer-modal');
}

async function handleCustomerFormSubmit(e) {
  e.preventDefault();
  const id = document.getElementById('customer-modal-id').value;
  const name = document.getElementById('customer-name-input').value;
  const phone = document.getElementById('customer-phone-input').value;
  const address = document.getElementById('customer-address-input').value;
  const notes = document.getElementById('customer-notes-input').value;

  try {
    await saveCustomer({
      id: id || undefined,
      name,
      phone,
      address,
      notes
    });

    showToast(`Customer "${name}" saved!`, 'success');
    closeModal('add-customer-modal');
    loadCustomersList();
    loadDashboard();
    if (currentTab === 'goods-out') loadGoodsOutForm();
  } catch (err) {
    showToast(err.message || 'Error saving customer', 'error');
  }
}

// Success Bill & WhatsApp Share Modal
function showSuccessBillModal(bill) {
  document.getElementById('bill-customer-name').textContent = bill.customerName;
  document.getElementById('bill-item-details').textContent = `${bill.quantity} ${bill.unit} x ${bill.itemName}`;
  document.getElementById('bill-total-amount').textContent = formatMoney(bill.totalAmount);
  document.getElementById('bill-paid-amount').textContent = formatMoney(bill.paidAmount);
  document.getElementById('bill-due-amount').textContent = formatMoney(bill.dueAmount);
  document.getElementById('bill-total-due').textContent = formatMoney(bill.newTotalDue);

  const waBtn = document.getElementById('btn-bill-whatsapp');
  waBtn.onclick = () => {
    const msg = `Hello ${bill.customerName},\n\nThank you for your purchase!\n` +
      `• Item: ${bill.itemName} (${bill.quantity} ${bill.unit})\n` +
      `• Total Amount: ${formatMoney(bill.totalAmount)}\n` +
      `• Paid: ${formatMoney(bill.paidAmount)}\n` +
      (bill.dueAmount > 0 ? `• Balance Due Today: ${formatMoney(bill.dueAmount)}\n` : `• Status: Fully Paid ✓\n`) +
      `• Total Outstanding Balance: ${formatMoney(bill.newTotalDue)}\n\nThank you!`;

    let cleanPhone = (bill.customerPhone || '').replace(/[^0-9]/g, '');
    if (cleanPhone.length === 10) cleanPhone = '91' + cleanPhone;
    window.open(`https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  openModal('bill-success-modal');
}

// ----------------- BACKUP & EXCEL EXPORT -----------------

async function handleExportJSON() {
  try {
    const backup = await exportFullBackup();
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(backup, null, 2));
    const dlAnchorElem = document.createElement('a');
    const dateStr = new Date().toISOString().slice(0, 10);
    dlAnchorElem.setAttribute("href", dataStr);
    dlAnchorElem.setAttribute("download", `retail_stock_backup_${dateStr}.json`);
    dlAnchorElem.click();
    showToast('Backup downloaded successfully!', 'success');
  } catch (err) {
    showToast('Failed to generate backup: ' + err.message, 'error');
  }
}

async function handleImportJSON(e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = async (event) => {
    try {
      const data = JSON.parse(event.target.result);
      if (confirm('Restoring this backup will replace current records. Are you sure?')) {
        await importFullBackup(data);
        showToast('Backup restored successfully!', 'success');
        switchTab('dashboard');
      }
    } catch (err) {
      showToast('Error restoring backup file: ' + err.message, 'error');
    }
  };
  reader.readAsText(file);
}

async function handleExportCSV(type) {
  try {
    let csvContent = "";
    const dateStr = new Date().toISOString().slice(0, 10);
    let fileName = `export_${type}_${dateStr}.csv`;

    if (type === 'inventory') {
      const items = await getAllItems();
      csvContent = "Item Name,Unit,Purchase Cost,Sale Price,Current Stock,Min Alert,Stock Value\n";
      items.forEach(it => {
        const val = (it.currentStock || 0) * (it.purchasePrice || 0);
        csvContent += `"${it.name}","${it.unit}",${it.purchasePrice},${it.sellingPrice},${it.currentStock},${it.minStockAlert},${val}\n`;
      });
    } else if (type === 'customers') {
      const customers = await getAllCustomers();
      csvContent = "Customer Name,Phone,Address,Total Purchases,Total Paid,Balance Due\n";
      customers.forEach(c => {
        csvContent += `"${c.name}","${c.phone || ''}","${c.address || ''}",${c.totalPurchases || 0},${c.totalPaid || 0},${c.balanceDue || 0}\n`;
      });
    } else if (type === 'transactions') {
      const txns = await getAllTransactions(1000);
      csvContent = "Date,Type,Item Name,Customer/Supplier,Quantity,Unit,Unit Price,Total Amount,Paid,Due\n";
      txns.forEach(t => {
        const party = t.type === 'OUT' ? t.customerName : t.supplier;
        csvContent += `"${formatDate(t.timestamp)}","${t.type}","${t.itemName}","${party || ''}",${t.quantity},"${t.unit || ''}",${t.unitPrice},${t.totalAmount},${t.paidAmount || 0},${t.dueAmount || 0}\n`;
      });
    }

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", fileName);
    link.click();
    showToast(`${type.toUpperCase()} exported to CSV!`, 'success');
  } catch (err) {
    showToast('Export failed: ' + err.message, 'error');
  }
}

// ----------------- INITIALIZATION -----------------

window.addEventListener('DOMContentLoaded', async () => {
  try {
    await openDatabase();
    
    // Setup Nav Clicks
    document.querySelectorAll('.nav-item').forEach(btn => {
      btn.addEventListener('click', () => switchTab(btn.dataset.tab));
    });

    // Form submits
    document.getElementById('form-goods-in').addEventListener('submit', handleGoodsInSubmit);
    document.getElementById('form-goods-out').addEventListener('submit', handleGoodsOutSubmit);
    document.getElementById('form-item').addEventListener('submit', handleItemFormSubmit);
    document.getElementById('form-customer').addEventListener('submit', handleCustomerFormSubmit);
    document.getElementById('form-receive-payment').addEventListener('submit', handleReceivePaymentSubmit);

    // Dynamic calculations
    document.getElementById('in-item-select').addEventListener('change', onGoodsInItemChange);
    document.getElementById('out-item-select').addEventListener('change', onGoodsOutItemChange);
    document.getElementById('out-qty').addEventListener('input', calculateGoodsOutTotals);
    document.getElementById('out-price').addEventListener('input', calculateGoodsOutTotals);
    document.getElementById('out-paid').addEventListener('input', onGoodsOutPaidChange);

    // Customer search
    document.getElementById('customer-search').addEventListener('input', (e) => {
      loadCustomersList(e.target.value);
    });

    // Inventory search & filter
    document.getElementById('inventory-search').addEventListener('input', (e) => {
      const filter = document.querySelector('.filter-btn.active')?.dataset.filter || 'all';
      loadInventoryList(e.target.value, filter);
    });

    document.querySelectorAll('.filter-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const search = document.getElementById('inventory-search').value;
        loadInventoryList(search, btn.dataset.filter);
      });
    });

    // Service worker registration
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('./sw.js').catch(err => {
        console.log('Service Worker registration skipped or failed:', err);
      });
    }

    // Default tab
    switchTab('dashboard');
  } catch (err) {
    console.error('App init error:', err);
  }
});
