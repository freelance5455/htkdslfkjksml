/**
 * Kanha Shop - Mobile POS & Receipt System
 * Currency: Khmer Riel (៛ / KHR)
 * Language: Khmer
 */

// Initial Default Catalog (Prices in Khmer Riel ៛)
const DEFAULT_PRODUCTS = [
  { id: 1, name: "ទឹកសុទ្ធ Vital 500ml", price: 1500, category: "ភេសជ្ជៈ", emoji: "💧" },
  { id: 2, name: "កាហ្វេទឹកដោះគោទឹកកក", price: 5000, category: "ភេសជ្ជៈ", emoji: "☕" },
  { id: 3, name: "តែបៃតងទឹកដោះគោ", price: 6000, category: "ភេសជ្ជៈ", emoji: "🧋" },
  { id: 4, name: "កូកាកូឡា 330ml", price: 2500, category: "ភេសជ្ជៈ", emoji: "🥤" },
  { id: 5, name: "បាកាស / Carabao", price: 2500, category: "ភេសជ្ជៈ", emoji: "⚡" },
  { id: 6, name: "នំបុ័ងសាំងវិច", price: 4000, category: "អាហារ", emoji: "🥪" },
  { id: 7, name: "មីម៉ាម៉ា / វ៉ៃវ៉ៃ កំប៉ុង", price: 3000, category: "អាហារ", emoji: "🍜" },
  { id: 8, name: "ដំឡូងបារាំង Lay's", price: 5000, category: "នំចំណី", emoji: "🥔" },
  { id: 9, name: "ស្ករកៅស៊ូ / Mentos", price: 2000, category: "នំចំណី", emoji: "🍬" },
  { id: 10, name: "សាប៊ូដុសខ្លួន Lux", price: 3500, category: "សម្ភារប្រើប្រាស់", emoji: "🧼" },
  { id: 11, name: "ថ្នាំដុសធ្មេញ Darlie", price: 6000, category: "សម្ភារប្រើប្រាស់", emoji: "🪥" },
  { id: 12, name: "ក្រដាសជូតមាត់ (Tissue)", price: 2000, category: "សម្ភារប្រើប្រាស់", emoji: "🧻" }
];

// Helper to sanitize saved products if they were in old USD format
function loadProducts() {
  const saved = localStorage.getItem('kanha_products');
  if (!saved) return DEFAULT_PRODUCTS;
  try {
    const parsed = JSON.parse(saved);
    // If prices are too small (from old USD demo like 0.35 or 1.25), convert to Riel
    const needsConversion = parsed.some(p => p.price < 100);
    if (needsConversion) {
      return parsed.map(p => ({
        ...p,
        price: p.price < 100 ? Math.round(p.price * 4000) : p.price
      }));
    }
    return parsed;
  } catch (e) {
    return DEFAULT_PRODUCTS;
  }
}

// App State
const state = {
  products: loadProducts(),
  cart: [],
  settings: JSON.parse(localStorage.getItem('kanha_settings')) || {
    shopName: "Kanha Shop",
    shopKhmerName: "ហាង កញ្ញា",
    phone: "012 345 678 / 098 765 432",
    address: "ផ្សារធំថ្មី រាជធានីភ្នំពេញ",
    cashier: "កញ្ញា",
    paperSize: "58mm", // 58mm or 80mm
    qrText: "https://qr.bakong.nbc.org.kh/kanha-shop-khqr",
    footerMsg: "សូមអរគុណចំពោះការគាំទ្រ!\nទំនិញទិញរួចមិនអាចប្តូរប្រាក់វិញបានទេ"
  },
  history: JSON.parse(localStorage.getItem('kanha_history')) || [],
  currentCategory: "ទាំងអស់",
  currentInvoice: null,
  paymentMethod: "cash"
};

// DOM Ready
document.addEventListener('DOMContentLoaded', () => {
  initApp();
});

function initApp() {
  applyPaperSize();
  renderProducts();
  renderCart();
  setupEventListeners();
  updateHistoryStats();
}

// Helper to convert Khmer numerals (០-៩) to Latin digits (0-9)
function convertKhmerNumerals(str) {
  if (!str) return '';
  const khmerDigits = ['០','១','២','៣','៤','៥','៦','៧','៨','៩'];
  let res = String(str);
  for (let i = 0; i < 10; i++) {
    res = res.replaceAll(khmerDigits[i], String(i));
  }
  return res;
}

function parseKhmerOrLatinNumber(val, defaultValue = 0) {
  if (val === null || val === undefined) return defaultValue;
  let str = convertKhmerNumerals(val).trim();
  str = str.replace(/[^0-9]/g, '');
  const parsed = parseInt(str, 10);
  return isNaN(parsed) ? defaultValue : parsed;
}

// Helper to parse decimal/fractional numbers (e.g. 0.5, 1.35, 5,25 or ០.៥, ១.៣៥)
function parseKhmerOrLatinFloat(val, defaultValue = 1) {
  if (val === null || val === undefined) return defaultValue;
  let str = convertKhmerNumerals(val).trim();
  if (!str) return defaultValue;
  // Convert comma to dot
  str = str.replace(/,/g, '.');
  // Keep only digits and dot
  str = str.replace(/[^0-9.]/g, '');
  const parts = str.split('.');
  if (parts.length > 2) {
    str = parts[0] + '.' + parts.slice(1).join('');
  }
  const parsed = parseFloat(str);
  return (isNaN(parsed) || parsed <= 0) ? defaultValue : parsed;
}

// Setup Event Listeners
function setupEventListeners() {
  // Search
  document.getElementById('searchInput').addEventListener('input', (e) => {
    renderProducts(e.target.value);
  });

  // Custom Item Add
  const customPriceInput = document.getElementById('customPrice');
  const customQtyInput = document.getElementById('customQty');
  const customNameInput = document.getElementById('customName');

  document.getElementById('btnAddCustom').addEventListener('click', addCustomItem);

  customPriceInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addCustomItem();
    }
  });
  customPriceInput.addEventListener('input', (e) => {
    const converted = convertKhmerNumerals(e.target.value);
    if (converted !== e.target.value) {
      e.target.value = converted;
    }
  });
  customPriceInput.addEventListener('focus', function() {
    this.select();
  });

  customQtyInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addCustomItem();
    }
  });
  customQtyInput.addEventListener('input', (e) => {
    const converted = convertKhmerNumerals(e.target.value);
    if (converted !== e.target.value) {
      e.target.value = converted;
    }
  });
  customQtyInput.addEventListener('focus', function() {
    this.select();
  });

  customNameInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      customPriceInput.focus();
    }
  });

  // Cashier inputs in payment modal
  const cashKhr = document.getElementById('cashReceivedKhr');
  cashKhr.addEventListener('input', (e) => {
    const converted = convertKhmerNumerals(e.target.value);
    if (converted !== e.target.value) {
      e.target.value = converted;
    }
    calculateChange();
  });
  cashKhr.addEventListener('focus', function() {
    this.select();
  });
}

// Paper Size
function applyPaperSize() {
  if (state.settings.paperSize === '80mm') {
    document.body.classList.add('paper-80mm');
  } else {
    document.body.classList.remove('paper-80mm');
  }
}

// Render Product Catalog
function renderProducts(searchQuery = '') {
  const container = document.getElementById('productsGrid');
  const chipsContainer = document.getElementById('categoryChips');
  container.innerHTML = '';

  // Get categories
  const categories = ["ទាំងអស់", ...new Set(state.products.map(p => p.category || "ទូទៅ"))];
  chipsContainer.innerHTML = categories.map(cat => `
    <button class="chip ${cat === state.currentCategory ? 'active' : ''}" onclick="selectCategory('${cat}')">
      ${cat}
    </button>
  `).join('');

  // Filter products
  const filtered = state.products.filter(p => {
    const matchesCat = state.currentCategory === "ទាំងអស់" || p.category === state.currentCategory;
    const matchesSearch = !searchQuery || p.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  if (filtered.length === 0) {
    container.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; padding: 40px; color: var(--gray-600);">
        រកមិនឃើញទំនិញទេ
      </div>
    `;
    return;
  }

  filtered.forEach(p => {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.onclick = () => addToCart(p);
    card.innerHTML = `
      <div class="card-emoji">${p.emoji || '🛍️'}</div>
      <div class="card-name">${p.name}</div>
      <div class="card-category">${p.category || 'ទូទៅ'}</div>
      <div class="card-pricing">
        <div class="card-price-khr">${Math.round(p.price).toLocaleString()} ៛</div>
      </div>
    `;
    container.appendChild(card);
  });
}

function selectCategory(cat) {
  state.currentCategory = cat;
  const search = document.getElementById('searchInput').value;
  renderProducts(search);
}

// Custom Item Add (Allows direct price and decimal/fractional qty entry)
function addCustomItem() {
  const nameInput = document.getElementById('customName');
  const priceInput = document.getElementById('customPrice');
  const qtyInput = document.getElementById('customQty');

  let name = nameInput.value.trim();
  const price = parseKhmerOrLatinNumber(priceInput.value, 0);
  const qty = parseKhmerOrLatinFloat(qtyInput.value, 1);

  if (price <= 0) {
    alert("សូមបញ្ចូលតម្លៃគិតជារៀល (៛) ឲ្យបានត្រឹមត្រូវ!");
    priceInput.focus();
    return;
  }

  if (qty <= 0) {
    alert("សូមបញ្ចូលចំនួនឲ្យបានត្រឹមត្រូវ!");
    qtyInput.focus();
    return;
  }

  // If no name is provided, automatically use "ទំនិញទូទៅ"
  if (!name) {
    name = "ទំនិញទូទៅ";
  }

  const customItem = {
    id: 'c_' + Date.now(),
    name: name,
    price: price,
    qty: qty
  };

  addToCart(customItem, qty);

  // Clear inputs and keep ready for next item
  nameInput.value = '';
  priceInput.value = '';
  qtyInput.value = '1';
  priceInput.focus();
}

// Cart Operations
function addToCart(product, qtyToAdd = 1) {
  const existing = state.cart.find(item => item.id === product.id);
  const qty = parseKhmerOrLatinFloat(qtyToAdd, 1);
  if (existing) {
    existing.qty = Math.round((existing.qty + qty) * 1000) / 1000;
  } else {
    state.cart.push({
      id: product.id,
      name: product.name,
      price: Math.round(product.price),
      qty: qty
    });
  }
  renderCart();
}

function changeQty(index, delta) {
  if (state.cart[index]) {
    let newQty = Math.round((state.cart[index].qty + delta) * 1000) / 1000;
    if (newQty <= 0) {
      state.cart.splice(index, 1);
    } else {
      state.cart[index].qty = newQty;
    }
  }
  renderCart();
}

function clearCart() {
  if (state.cart.length === 0) return;
  if (confirm("តើអ្នកពិតជាចង់លុបទំនិញទាំងអស់ក្នុងកន្រ្តកមែនទេ?")) {
    state.cart = [];
    renderCart();
  }
}

function getCartCalculations() {
  const subtotal = Math.round(state.cart.reduce((sum, item) => sum + (item.price * item.qty), 0));
  const discountInput = document.getElementById('cartDiscount');
  const discountVal = discountInput ? parseKhmerOrLatinNumber(discountInput.value, 0) : 0;
  
  let discount = Math.min(subtotal, Math.max(0, discountVal));
  const total = Math.max(0, subtotal - discount);

  return { subtotal, discount, total };
}

function renderCart() {
  const container = document.getElementById('cartItems');
  const countBadge = document.getElementById('cartCount');
  
  const totalItemsCount = state.cart.reduce((sum, item) => sum + item.qty, 0);
  countBadge.textContent = `${totalItemsCount} មុខ`;

  if (state.cart.length === 0) {
    container.innerHTML = `
      <div class="cart-empty">
        <div class="cart-empty-icon">🛒</div>
        <div>មិនទាន់មានទំនិញក្នុងកន្រ្តក</div>
        <div style="font-size: 12px; color: var(--gray-600);">ចុចលើទំនិញដើម្បីបន្ថែម</div>
      </div>
    `;
    updateCartTotals(0, 0, 0);
    return;
  }

  container.innerHTML = state.cart.map((item, index) => {
    const itemTotalKhr = Math.round(item.price * item.qty).toLocaleString();
    return `
      <div class="cart-item">
        <div class="cart-item-info">
          <div class="cart-item-name">${item.name}</div>
          <div class="cart-item-unit-price">${item.price.toLocaleString()} ៛ / ឯកតា</div>
        </div>
        <div class="cart-item-qty">
          <button class="btn-qty" onclick="changeQty(${index}, -1)">-</button>
          <input type="text" class="qty-input" value="${item.qty}" onchange="setCartQty(${index}, this.value)" onfocus="this.select()" inputmode="decimal">
          <button class="btn-qty" onclick="changeQty(${index}, 1)">+</button>
        </div>
        <div class="cart-item-total">
          <div class="cart-item-total-khr" style="font-size: 14px; font-weight: 700; color: var(--primary);">${itemTotalKhr} ៛</div>
        </div>
      </div>
    `;
  }).join('');

  const calc = getCartCalculations();
  updateCartTotals(calc.subtotal, calc.discount, calc.total);
}

function setCartQty(index, newQty) {
  const qty = parseKhmerOrLatinFloat(newQty, 0);
  if (state.cart[index]) {
    if (qty <= 0) {
      state.cart.splice(index, 1);
    } else {
      state.cart[index].qty = qty;
    }
  }
  renderCart();
}

function updateCartTotals(subtotal, discount, total) {
  document.getElementById('summarySubtotal').textContent = `${subtotal.toLocaleString()} ៛`;
  document.getElementById('summaryTotalKhr').textContent = `${total.toLocaleString()} ៛`;
}

// Payment Modal
function openPaymentModal() {
  if (state.cart.length === 0) {
    alert("សូមជ្រើសរើសទំនិញចូលកន្រ្តកជាមុនសិន!");
    return;
  }

  const calc = getCartCalculations();
  document.getElementById('payTotalKhr').textContent = `${calc.total.toLocaleString()} ៛`;

  const cashKhr = document.getElementById('cashReceivedKhr');
  cashKhr.value = '';

  document.getElementById('changeKhr').textContent = '0 ៛';

  document.getElementById('paymentModal').classList.add('active');
  cashKhr.focus();
}

function closePaymentModal() {
  document.getElementById('paymentModal').classList.remove('active');
}

function setQuickCash(val) {
  if (val === 0) {
    document.getElementById('cashReceivedKhr').value = '';
  } else {
    document.getElementById('cashReceivedKhr').value = val;
  }
  calculateChange();
}

function setExactCash() {
  const calc = getCartCalculations();
  document.getElementById('cashReceivedKhr').value = calc.total;
  calculateChange();
}

function calculateChange() {
  const calc = getCartCalculations();
  let receivedKhr = parseKhmerOrLatinNumber(document.getElementById('cashReceivedKhr').value, 0);

  let changeKhr = receivedKhr - calc.total;

  if (changeKhr < 0) {
    document.getElementById('changeKhr').textContent = `ខ្វះប្រាក់ ${(Math.abs(changeKhr)).toLocaleString()} ៛`;
    document.getElementById('changeKhr').style.color = 'var(--danger)';
  } else {
    document.getElementById('changeKhr').textContent = `${changeKhr.toLocaleString()} ៛`;
    document.getElementById('changeKhr').style.color = 'var(--success)';
  }
}

// Generate Invoice Object
function generateInvoiceData() {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const h = String(now.getHours()).padStart(2, '0');
  const min = String(now.getMinutes()).padStart(2, '0');
  const sec = String(now.getSeconds()).padStart(2, '0');

  const invNo = `INV-${y}${m}${d}-${String(state.history.length + 1).padStart(4, '0')}`;
  const dateStr = `${d}/${m}/${y} ${h}:${min}:${sec}`;

  const calc = getCartCalculations();
  let receivedKhr = parseKhmerOrLatinNumber(document.getElementById('cashReceivedKhr').value, 0);
  if (receivedKhr === 0) receivedKhr = calc.total; // QR pay or exact
  let changeKhr = Math.max(0, receivedKhr - calc.total);

  const invoice = {
    invNo,
    date: dateStr,
    timestamp: now.getTime(),
    cashier: state.settings.cashier,
    items: [...state.cart],
    subtotal: calc.subtotal,
    discount: calc.discount,
    total: calc.total,
    received: receivedKhr,
    change: changeKhr,
    shopName: state.settings.shopName,
    shopKhmerName: state.settings.shopKhmerName,
    shopPhone: state.settings.phone,
    shopAddress: state.settings.address,
    footerMsg: state.settings.footerMsg
  };

  return invoice;
}

// Build Receipt HTML (Only Khmer Riel ៛)
function renderReceiptHTML(invoice, targetElementId) {
  const target = document.getElementById(targetElementId);
  target.innerHTML = `
    <div class="receipt-header">
      <div class="receipt-shop-logo">🏪</div>
      <div class="receipt-shop-name">${invoice.shopKhmerName}</div>
      <div style="font-size: 13px; font-weight: 700;">${invoice.shopName}</div>
      <div class="receipt-shop-info">
        ${invoice.shopAddress ? `<div>${invoice.shopAddress}</div>` : ''}
        ${invoice.shopPhone ? `<div>ទូរស័ព្ទ: ${invoice.shopPhone}</div>` : ''}
      </div>
    </div>

    <div class="receipt-meta">
      <div class="receipt-meta-row">
        <span>វិក័យបត្រ #:</span>
        <strong>${invoice.invNo}</strong>
      </div>
      <div class="receipt-meta-row">
        <span>កាលបរិច្ឆេទ:</span>
        <span>${invoice.date}</span>
      </div>
      <div class="receipt-meta-row">
        <span>អ្នកគិតលុយ:</span>
        <span>${invoice.cashier}</span>
      </div>
    </div>

    <table class="receipt-table">
      <thead>
        <tr>
          <th class="col-item">ទំនិញ</th>
          <th class="col-qty">ចំនួន</th>
          <th class="col-price">តម្លៃ (៛)</th>
        </tr>
      </thead>
      <tbody>
        ${invoice.items.map(item => `
          <tr>
            <td class="col-item">${item.name}</td>
            <td class="col-qty">${item.qty}</td>
            <td class="col-price">${Math.round(item.price * item.qty).toLocaleString()} ៛</td>
          </tr>
        `).join('')}
      </tbody>
    </table>

    <div class="receipt-divider"></div>

    <div class="receipt-total-row">
      <span>សរុបរង (Subtotal):</span>
      <span>${invoice.subtotal.toLocaleString()} ៛</span>
    </div>
    ${invoice.discount > 0 ? `
      <div class="receipt-total-row">
        <span>បញ្ចុះតម្លៃ (Discount):</span>
        <span>-${invoice.discount.toLocaleString()} ៛</span>
      </div>
    ` : ''}
    <div class="receipt-grand-total">
      <span>សរុប (TOTAL):</span>
      <span>${invoice.total.toLocaleString()} ៛</span>
    </div>

    <div class="receipt-divider"></div>

    <div class="receipt-total-row">
      <span>ប្រាក់ទទួល (Received):</span>
      <span>${invoice.received.toLocaleString()} ៛</span>
    </div>
    <div class="receipt-total-row">
      <span>ប្រាក់អាប់ (Change):</span>
      <strong>${invoice.change.toLocaleString()} ៛</strong>
    </div>

    ${state.settings.qrText ? `
      <div class="receipt-qr-wrap">
        <div id="receiptQr_${targetElementId}" class="receipt-qr-img"></div>
        <div style="font-size: 9px; margin-top: 2px;">ស្កេនទូទាត់ប្រាក់ (KHQR)</div>
      </div>
    ` : ''}

    <div class="receipt-footer">
      ${invoice.footerMsg.split('\n').map(line => `<div>${line}</div>`).join('')}
    </div>
  `;

  // Generate QR if enabled
  if (state.settings.qrText) {
    const qrContainer = document.getElementById(`receiptQr_${targetElementId}`);
    if (qrContainer && typeof QRCode !== 'undefined') {
      qrContainer.innerHTML = '';
      new QRCode(qrContainer, {
        text: state.settings.qrText,
        width: 90,
        height: 90,
        colorDark: "#000000",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.M
      });
    }
  }
}

// Complete Order and Print
function completeSaleAndPrint(mode = 'system') {
  const invoice = generateInvoiceData();
  state.currentInvoice = invoice;

  // Save to History
  state.history.unshift(invoice);
  localStorage.setItem('kanha_history', JSON.stringify(state.history));

  // Render to both preview and hidden print element
  renderReceiptHTML(invoice, 'printableReceipt');
  renderReceiptHTML(invoice, 'previewReceiptPaper');

  closePaymentModal();
  updateHistoryStats();

  if (mode === 'system') {
    setTimeout(() => {
      window.print();
    }, 200);
  } else if (mode === 'bluetooth') {
    printViaBluetooth(invoice);
  }

  // Clear cart
  state.cart = [];
  renderCart();

  // Show receipt preview modal
  openReceiptPreview();
}

function openReceiptPreview() {
  document.getElementById('receiptModal').classList.add('active');
}

function closeReceiptPreview() {
  document.getElementById('receiptModal').classList.remove('active');
}

function triggerSystemPrint() {
  window.print();
}

async function printViaBluetooth(invoice = state.currentInvoice) {
  if (!invoice) return;

  if (!window.BluetoothPrinter.isSupported()) {
    alert("Browser របស់អ្នកមិនគាំទ្រ Web Bluetooth ទេ។ សូមប្រើ Google Chrome លើ Android ឬ PC ឬប្រើប៊ូតុង 'បោះពុម្ពតាមប្រព័ន្ធ (Print)' ជំនួសវិញ!");
    return;
  }

  try {
    if (!window.BluetoothPrinter.isConnected) {
      const devName = await window.BluetoothPrinter.connect();
      alert(`បានភ្ជាប់ជាមួយ ${devName} ជោគជ័យ! កំពុងបោះពុម្ព...`);
    }

    await window.BluetoothPrinter.printEscPos(invoice);
    alert("បានបោះពុម្ពវិក័យបត្រតាម Bluetooth រួចរាល់!");
  } catch (err) {
    console.error("Bluetooth print error:", err);
    alert("ការបោះពុម្ពតាម Bluetooth បរាជ័យ៖ " + err.message);
  }
}

// History & Report Management
function updateHistoryStats() {
  const today = new Date().toDateString();
  const todayInvoices = state.history.filter(inv => new Date(inv.timestamp).toDateString() === today);

  const count = todayInvoices.length;
  const totalKhr = todayInvoices.reduce((sum, inv) => sum + (inv.total || inv.totalKhr || 0), 0);

  const countEl = document.getElementById('historyCount');
  const khrEl = document.getElementById('historyTotalKhr');

  if (countEl) countEl.textContent = `${count} វិក័យបត្រ`;
  if (khrEl) khrEl.textContent = `${totalKhr.toLocaleString()} ៛`;
}

function openHistoryModal() {
  const listContainer = document.getElementById('historyList');
  updateHistoryStats();

  if (state.history.length === 0) {
    listContainer.innerHTML = `
      <div style="text-align: center; padding: 30px; color: var(--gray-600);">
        មិនទាន់មានប្រវត្តិវិក័យបត្រនៅឡើយទេ
      </div>
    `;
  } else {
    listContainer.innerHTML = state.history.map((inv, idx) => {
      const invTotal = (inv.total || inv.totalKhr || 0).toLocaleString();
      return `
        <div style="padding: 12px; border: 1px solid var(--gray-200); border-radius: 8px; margin-bottom: 8px; background: white; display: flex; justify-content: space-between; align-items: center;">
          <div>
            <div style="font-weight: 700; color: var(--dark);">${inv.invNo}</div>
            <div style="font-size: 11px; color: var(--gray-600);">${inv.date} | ${inv.items.length} មុខ</div>
          </div>
          <div style="text-align: right;">
            <div style="font-weight: 700; color: var(--primary); font-size: 15px;">${invTotal} ៛</div>
          </div>
          <button class="btn-header" style="background: var(--primary); color: white; padding: 6px 12px;" onclick="reprintHistory(${idx})">
            🖨️ បោះពុម្ពឡើងវិញ
          </button>
        </div>
      `;
    }).join('');
  }

  document.getElementById('historyModal').classList.add('active');
}

function closeHistoryModal() {
  document.getElementById('historyModal').classList.remove('active');
}

function reprintHistory(idx) {
  const invoice = state.history[idx];
  if (!invoice) return;

  state.currentInvoice = invoice;
  renderReceiptHTML(invoice, 'printableReceipt');
  renderReceiptHTML(invoice, 'previewReceiptPaper');
  closeHistoryModal();
  openReceiptPreview();
}

function clearAllHistory() {
  if (confirm("តើអ្នកពិតជាចង់លុបប្រវត្តិវិក័យបត្រទាំងអស់មែនទេ?")) {
    state.history = [];
    localStorage.removeItem('kanha_history');
    updateHistoryStats();
    openHistoryModal();
  }
}

// Settings Modal
function openSettingsModal() {
  document.getElementById('settingShopName').value = state.settings.shopName;
  document.getElementById('settingShopKhmer').value = state.settings.shopKhmerName;
  document.getElementById('settingPhone').value = state.settings.phone;
  document.getElementById('settingAddress').value = state.settings.address;
  document.getElementById('settingCashier').value = state.settings.cashier;
  document.getElementById('settingPaperSize').value = state.settings.paperSize;
  document.getElementById('settingQrText').value = state.settings.qrText;
  document.getElementById('settingFooter').value = state.settings.footerMsg;

  document.getElementById('settingsModal').classList.add('active');
}

function closeSettingsModal() {
  document.getElementById('settingsModal').classList.remove('active');
}

function saveSettings() {
  state.settings.shopName = document.getElementById('settingShopName').value.trim() || "Kanha Shop";
  state.settings.shopKhmerName = document.getElementById('settingShopKhmer').value.trim() || "ហាង កញ្ញា";
  state.settings.phone = document.getElementById('settingPhone').value.trim();
  state.settings.address = document.getElementById('settingAddress').value.trim();
  state.settings.cashier = document.getElementById('settingCashier').value.trim() || "កញ្ញា";
  state.settings.paperSize = document.getElementById('settingPaperSize').value;
  state.settings.qrText = document.getElementById('settingQrText').value.trim();
  state.settings.footerMsg = document.getElementById('settingFooter').value.trim();

  localStorage.setItem('kanha_settings', JSON.stringify(state.settings));

  applyPaperSize();
  renderProducts();
  renderCart();
  closeSettingsModal();
  alert("បានរក្សាទុកការកំណត់ជោគជ័យ!");
}

// Product Management Modal
function openProductsModal() {
  renderProductManagerList();
  document.getElementById('productsModal').classList.add('active');
}

function closeProductsModal() {
  document.getElementById('productsModal').classList.remove('active');
}

function renderProductManagerList() {
  const container = document.getElementById('productManagerList');
  container.innerHTML = state.products.map((p, idx) => `
    <div style="display: flex; justify-content: space-between; align-items: center; padding: 8px 12px; border: 1px solid var(--gray-200); border-radius: 8px; margin-bottom: 6px;">
      <div>
        <span style="font-size: 18px; margin-right: 6px;">${p.emoji || '🛍️'}</span>
        <strong>${p.name}</strong>
        <span style="font-size: 11px; color: var(--gray-600); margin-left: 8px;">(${p.category || 'ទូទៅ'})</span>
      </div>
      <div style="display: flex; align-items: center; gap: 10px;">
        <span style="font-weight: 700; color: var(--primary);">${Math.round(p.price).toLocaleString()} ៛</span>
        <button style="background: none; border: none; color: var(--danger); cursor: pointer; font-size: 16px;" onclick="deleteProduct(${idx})">🗑️</button>
      </div>
    </div>
  `).join('');
}

function saveNewProductCatalogItem() {
  const name = document.getElementById('newProdName').value.trim();
  const price = parseKhmerOrLatinNumber(document.getElementById('newProdPrice').value, 0);
  const category = document.getElementById('newProdCategory').value.trim() || "ទូទៅ";
  const emoji = document.getElementById('newProdEmoji').value.trim() || "🛍️";

  if (!name || price <= 0) {
    alert("សូមបញ្ចូលឈ្មោះ និងតម្លៃគិតជារៀល (៛) ឲ្យបានត្រឹមត្រូវ!");
    return;
  }

  state.products.push({
    id: Date.now(),
    name,
    price,
    category,
    emoji
  });

  localStorage.setItem('kanha_products', JSON.stringify(state.products));
  renderProductManagerList();
  renderProducts();

  document.getElementById('newProdName').value = '';
  document.getElementById('newProdPrice').value = '';
}

function deleteProduct(idx) {
  if (confirm(`តើអ្នកចង់លុបទំនិញ "${state.products[idx].name}" នេះមែនទេ?`)) {
    state.products.splice(idx, 1);
    localStorage.setItem('kanha_products', JSON.stringify(state.products));
    renderProductManagerList();
    renderProducts();
  }
}
