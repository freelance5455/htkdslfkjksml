#!/system/bin/sh
# G60 — DeviceConfig / GServices Google flag kill
# Uses `device_config` (API 29+) to disable Google-side experiment
# flags that re-enable telemetry & background jobs even after we
# disable them. Also strips key GServices analytics rows.
MODULE_ID="G60_deviceconfig_google_flags_off"
. "$(dirname "$0")/../lib/plus_core.sh"
vopl_init

apply() {
    vopl_apply_or_skip G60_DEVICECONFIG_GOOGLE_FLAGS_OFF || return 0
    vopl_need_api 29 || return 0

    # DeviceConfig namespaces to lock down
    vopl_run "$MODULE_ID: sync disable" device_config set_sync_disabled_for_tests persistent
    vopl_run "$MODULE_ID"               device_config put activity_manager max_cached_processes 32
    vopl_run "$MODULE_ID"               device_config put activity_manager_native default_background_fgs_starts_restricted true
    vopl_run "$MODULE_ID"               device_config put activity_manager default_background_activity_starts_enabled false
    vopl_run "$MODULE_ID"               device_config put jobscheduler enable_api_quotas true
    vopl_run "$MODULE_ID"               device_config put jobscheduler qc_max_job_count_rare 5
    vopl_run "$MODULE_ID"               device_config put jobscheduler qc_max_job_count_restricted 1
    vopl_run "$MODULE_ID"               device_config put netd_native doh_early_data false
    vopl_run "$MODULE_ID"               device_config put connectivity mobile_data_always_on false
    vopl_run "$MODULE_ID"               device_config put statsd_java disable_all_metrics true

    # GServices analytics kill
    vopl_run "$MODULE_ID: gsvc analytics"    settings put global analytics.tracking_id ""
    vopl_run "$MODULE_ID: gsvc reportuncaught"  settings put global send_action_app_error 0
    vopl_run "$MODULE_ID: gsvc autopush"     settings put global upload_apk_enable_checksum 0
    vopl_run "$MODULE_ID: gsvc autotransport" settings put global installer_download_data_via_wifi_only 1
}

revert() {
    vopl_run "revert $MODULE_ID" device_config set_sync_disabled_for_tests none
    vopl_run "revert $MODULE_ID" device_config delete activity_manager max_cached_processes
    vopl_run "revert $MODULE_ID" device_config delete activity_manager_native default_background_fgs_starts_restricted
    vopl_run "revert $MODULE_ID" device_config delete activity_manager default_background_activity_starts_enabled
    vopl_run "revert $MODULE_ID" device_config delete jobscheduler qc_max_job_count_rare
    vopl_run "revert $MODULE_ID" device_config delete jobscheduler qc_max_job_count_restricted
    vopl_run "revert $MODULE_ID" device_config delete statsd_java disable_all_metrics
}
case "${1:-apply}" in apply) apply ;; revert) revert ;; *) exit 1 ;; esac
