# M&J's Riverside V3.0 — Test Build
Built from the uploaded UPDATE 2.0 UPDATE FIX.zip. Existing booking flow, Supabase URL/public key, OneSignal App ID, logo, background and worker were retained.

## Included
- Existing Supabase Auth session restore and `is_admin()` authorization check retained.
- OneSignal `role=admin` tag applied after login and restored session; removal attempted on logout.
- Philippine Time clock (Asia/Manila).
- Admin booking search by customer, contact, date, status, type and notes.
- CSV export of currently loaded booking records.
- Current-month approved customer booking count and estimated sales.
- Supabase Realtime listener for changes to `public.bookings`, with manual Refresh fallback.

## Not implemented / requires more source information
- Archive & Restore: not implemented because the source does not include the bookings schema or `public_booking_availability` view definition. Guessing status values or changing the view could cause archived bookings to keep blocking customer slots or make active slots bookable incorrectly.
- OneSignal webhook HTTP 401: not fixed in this browser package. This requires inspection of the webhook/Edge Function and server-side secret configuration. Never place a OneSignal REST API key in `index.html`.
- Realtime depends on `public.bookings` being enabled in Supabase Realtime publication.
- Monthly sales are estimates (approved customer booking hours × existing RATE_PER_HOUR = ₱150/hour), not verified payments/cash receipts.

## Safe test process
Deploy this ZIP to a Netlify preview, not over production. Test customer booking submission, availability conflict prevention, admin login/session restore, approve/decline, realtime refresh, CSV export and logout. Back up the database before production deployment.

## Supabase migration
No SQL migration is included intentionally; the features in this test build do not require a schema change. For archive/restore, provide the full `bookings` table schema, RLS policies/triggers/status values and the SQL definition of `public_booking_availability`.


## V3.0.1 Admin Password Change
- Added a Password button in the admin dashboard.
- Requires the current admin password and re-authenticates the signed-in Supabase Auth user before changing credentials.
- New password and confirmation must match; minimum 8 characters.
- Password is submitted through Supabase Auth `updateUser({ password })`; it is not written to app tables or local storage.
- After success, the current session remains active; use the new password for the next login.
