package com.matyka.proxy;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(10, 10, 12));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(10, 10, 12));
        getWindow().getDecorView().setSystemUiVisibility(0);
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(10, 10, 12));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBridge(), "MatykaAndroid");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void launchPackage(String packageName) {
            runOnUiThread(() -> {
                if (packageName == null || packageName.trim().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Informe o pacote do jogo.", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    Intent launch = getPackageManager().getLaunchIntentForPackage(packageName.trim());
                    if (launch == null) {
                        webView.evaluateJavascript("window.onGameLaunchResult(false)", null);
                    } else {
                        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(launch);
                        webView.evaluateJavascript("window.onGameLaunchResult(true)", null);
                    }
                } catch (Exception e) {
                    webView.evaluateJavascript("window.onGameLaunchResult(false)", null);
                }
            });
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
