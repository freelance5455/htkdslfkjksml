# MATYKA CHEATS — PROXY ANDROID

Projeto Android nativo (Activity Java + WebView local) com interface premium em HTML/CSS/JS.

## Abrir e compilar
1. Extraia o ZIP.
2. Abra a pasta `MATYKA_CHEATS_PROXY_ANDROID` no Android Studio ou em um construtor que aceite projetos Android Gradle.
3. Aguarde a sincronização do Gradle.
4. Gere o APK em **Build > Build APK(s)**.

Requisitos: Android Gradle Plugin 8.7.3, Gradle 8.9 ou compatível, JDK 17 e Android SDK 35. `minSdk` 23.

## Personalização
- O wallpaper pode ser adicionado em `app/src/main/assets/` e conectado à variável CSS `--hero-bg` no início de `index.html`.
- A identidade, cores, textos e categorias ficam em `index.html`.
- Nome do pacote: `com.matyka.proxy`.

## Comportamento
- As opções da aba FUNÇÕES são controles locais de estado visual.
- CONEXÕES salva perfis localmente e permite marcar/desmarcar um perfil ativo na interface; não cria túnel, VPN ou proxy de tráfego.
- INJETAR executa apenas uma sequência de interface e, ao final, pode solicitar ao Android a abertura normal do pacote informado. Não injeta arquivos, altera processos ou modifica jogos.
- O projeto não solicita permissão de internet nem acesso a arquivos do dispositivo.
