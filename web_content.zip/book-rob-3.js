/* JOSTECH — MANUEL 08 : ROBOTIQUE NIVEAU 3 */
registerLessonDetail(8, 3, "rob-3-1-1", {
  title: "Leçon 1 : Temps Réel, Bus Embarqués (I2C/SPI/CAN) et Régulateur PID",
  duration: "45 min (Manuel universitaire complet)",
  objectives: [
    "Éliminer les délais bloquants grâce à la programmation temps réel non-bloquante (millis / RTOS).",
    "Choisir entre les bus de communication embarqués UART, I2C, SPI et CAN.",
    "Maîtriser les 3 termes de l'asservissement en boucle fermée PID (Proportionnel, Intégral, Dérivé)."
  ],
  prerequisites: ["Niveau 2 — Arduino et notions de dérivation/intégration."],
  sections: [
    {
      type: "table",
      title: "1. Les 4 bus matériels de communication embarquée",
      headers: ["Bus", "Fils / Architecture", "Vitesse & Usage industriel"],
      rows: [
        ["UART (Série)", "2 fils (TX, RX) point-à-point", "Simple : modules GPS, Bluetooth, débogage PC."],
        ["I2C", "2 fils (SDA, SCL) multi-esclaves par adresse", "Moyen (~400 kHz) : capteurs IMU, écrans OLED."],
        ["SPI", "4 fils (MOSI, MISO, SCK, CS) Full-Duplex", "Très rapide (MHz) : cartes SD, écrans rapides."],
        ["CAN Bus", "Paire différentielle anti-parasites", "Industriel critique : automobiles, drones, usines."]
      ]
    },
    {
      type: "definition",
      term: "Asservissement en Boucle Fermée et Régulateur PID",
      text: "En boucle ouverte (envoyer « PWM = 150 »), si le robot monte une pente, il ralentit sans le savoir. En boucle fermée, des encodeurs sur les roues mesurent la vitesse réelle et la comparent à la Consigne : Erreur e(t) = Consigne - Mesure.\nLe Régulateur PID calcule automatiquement la commande :\n• P (Proportionnel : Kp·e) : réagit tout de suite proportionnellement à l'erreur actuelle.\n• I (Intégral : Ki·∫e dt) : corrige les petites erreurs persistantes (frottements, pente).\n• D (Dérivé : Kd·de/dt) : anticipe la vitesse de rapprochement pour freiner à temps et éviter les oscillations."
    },
    {
      type: "code",
      lang: "Temps Réel non-bloquant (Remplacer delay() par millis())",
      code: [
        "unsigned long dernierTick = 0;",
        "void loop() {",
        "  unsigned long maintenant = millis();",
        "  if (maintenant - dernierTick >= 20) { // Toutes les 20 ms (50 Hz) sans bloquer !",
        "    dernierTick = maintenant;",
        "    executerCalculPID();",
        "  }",
        "  lireCapteursUrgence(); // Tourne en continu des milliers de fois/sec !",
        "}"
      ].join("\n")
    },
    {
      type: "warning",
      title: "Danger critique dans les systèmes embarqués : delay()",
      text: "Appeler delay(1000) gèle le processeur pendant 1 seconde entière : pendant ce temps, un drone ne corrige plus son équilibre et s'écrase ! Utilisez toujours millis() ou un noyau temps réel (FreeRTOS)."
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Réglage d'un PID de bras robotisé",
      question: "Un bras robotisé équipé uniquement d'un terme Proportionnel (P) s'arrête systématiquement à 2° de sa cible par manque de couple face à la gravité. Quel terme (I ou D) devez-vous ajouter pour annuler cette erreur statique finale ?",
      solution: "Le terme Intégral (I) ! En cumulant cette petite erreur persistante de 2° au fil des millisecondes, la composante I augmente la puissance moteur jusqu'à atteindre exactement 0° d'erreur."
    },
    {
      title: "Exercice 2 — Choix de bus matériel",
      question: "Vous devez relier 6 capteurs environnementaux simples sur la même carte en économisant les broches du microcontrôleur. Choisissez-vous SPI ou I2C ?",
      solution: "I2C ! Car I2C ne consomme que 2 broches au total (SDA et SCL) quel que soit le nombre de capteurs (chacun ayant sa propre adresse), alors que SPI exige un fil CS séparé par capteur."
    }
  ],
  summary: "La robotique avancée repose sur les bus embarqués (I2C, SPI, CAN), la programmation temps réel non-bloquante (millis / FreeRTOS) et l'asservissement précis par régulateur PID.",
  references: ["Siciliano, B. — Robotics: Modelling, Planning and Control, Springer.", "Åström & Murray — Feedback Systems."]
});