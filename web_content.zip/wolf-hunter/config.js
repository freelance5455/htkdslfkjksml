/**
 * WOLF-HUNTER · Valores de balance y configuración.
 *
 * Todos los números jugables viven aquí: se ajustan sin tocar el resto del
 * código. El host replica estos valores al validar a los clientes (Fase 2+).
 */
export const CONFIG = {
  // ─────────────────────────── Jugador ───────────────────────────
  HUNTER_SPEED: 4.5, // velocidad de caminar del Hunter en unidades/segundo
  HUNTER_HP: 100, // salud inicial del Hunter
  HUNTER_FOV: 75, // campo de visión de la cámara en modo Hunter (grados)
  WOLF_SPEED: 7.0, // velocidad del Wolf (más rápido que el Hunter)
  WOLF_HP: 180, // salud del Wolf (aguanta más fuego coordinado)
  WOLF_FOV: 85, // FOV del Wolf (sensación de velocidad)
  PLAYER_RADIUS: 0.4, // radio de la cápsula de colisión del jugador
  PLAYER_HEIGHT: 1.7, // altura total de la cápsula
  JUMP_HEIGHT: 1.2, // altura máxima de salto en unidades
  GRAVITY: 20, // aceleración de gravedad en unidades/segundo²

  // ─────────────────────────── Combate ───────────────────────────
  BULLET_DAMAGE: 25, // daño por bala del Hunter
  BULLET_RANGE: 60, // alcance máximo del raycast de disparo
  BULLET_COOLDOWN_MS: 150, // tiempo mínimo entre disparos
  MAGAZINE_SIZE: 8, // balas por cargador
  RESERVE_AMMO: 24, // munición de reserva
  RELOAD_TIME_MS: 1500, // duración de la recarga manual
  CLAW_DAMAGE: 60, // daño de zarpazo del Wolf
  CLAW_RANGE: 2.0, // alcance cuerpo a cuerpo del Wolf
  CLAW_COOLDOWN_MS: 600, // tiempo entre zarpazos

  // ─────────────────────── Transformación ────────────────────────
  WOLF_DURATION_MS: 20000, // duración del modo Wolf tras recoger el Núcleo
  CORE_PICKUP_RANGE: 1.5, // distancia máxima para recoger el Núcleo
  RESPAWN_INVULNERABILITY_MS: 2000, // invulnerabilidad tras reaparecer

  // ──────────────────────────── Ronda ────────────────────────────
  ROUND_DURATION_MS: 180000, // duración de la ronda (3 minutos)
  SCORE_PER_KILL: 1, // puntos por eliminación
  SCORE_PER_WOLF_SECOND: 1, // puntos por segundo sobrevivido como Wolf

  // ─────────────── Adiciones de la Fase 3 (combate) ───────────────
  RESPAWN_DELAY_MS: 3000, // espera antes de reaparecer
  CLAW_ARC_DEG: 100, // amplitud del arco frontal del zarpazo
  SHOOT_ORIGIN_TOLERANCE_M: 1.5, // desvío máximo del origen del disparo (anti-trampa)
  COOLDOWN_TOLERANCE_MS: 30, // margen de reloj al validar cadencias (jitter de red)
  WOLF_CAM_EXTRA: 0.6, // la cámara 3ª persona se aleja un poco más siendo Wolf
  WOLF_EYE_HEIGHT: 1.0, // altura de ojos del Wolf (más bajo que el Hunter)
  HIT_FLASH_MS: 140, // duración del destello rojo al recibir daño
  KILL_FEED_MAX: 3, // líneas visibles del registro de bajas
  SCOREBOARD_AUTO_MS: 12000, // vuelta automática al lobby tras el marcador

  // ───────────────────────────── Red ─────────────────────────────
  TICK_RATE_HZ: 20, // frecuencia de envío de estado del host
  INTERP_DELAY_MS: 100, // retardo del buffer de interpolación de remotos
  MAX_PLAYERS: 4, // aforo máximo de la sala
  MAX_MSG_PER_SEC: 30, // límite de mensajes por cliente (anti-flood)
  LOBBY_TICK_HZ: 5, // frecuencia de STATE en sala de espera
  INPUT_SEND_HZ: 20, // frecuencia de envío de INPUT del cliente
  PING_INTERVAL_MS: 2000, // cadencia del reloj (PING/PONG)
  JOIN_TIMEOUT_MS: 10000, // tiempo máximo esperando WELCOME/REJECT
  RECONCILE_HARD_M: 0.12, // error (m) que fuerza reconciliación dura
  RECONCILE_SOFT_M: 0.004, // error (m) que activa corrección suave
  ROOM_CODE_LEN: 4, // caracteres del código de sala

  // ───────────────── Cámara y controles ──────────────────────────
  CAMERA_SENSITIVITY: 1.0, // multiplicador global de sensibilidad
  INVERT_Y: false, // invertir eje vertical de la cámara
  AIM_ASSIST_STRENGTH: 0.15, // fuerza de la asistencia de apuntado
  AIM_ASSIST_RADIUS: 3.0, // radio de captura del aim assist

  // ───────────── Tercera persona (botón de cámara) ─────────────
  CAMERA_MODE: 'first', // 'first' | 'third' — preferencia inicial (se persiste)
  CAMERA_BLEND_MS: 260, // duración de la transición 1ª ↔ 3ª persona
  THIRD_DISTANCE: 3.4, // distancia de la cámara al pivot (cabeza)
  THIRD_SHOULDER: 0.5, // desplazamiento lateral (hombro derecho)
  THIRD_HEIGHT: 0.18, // altura extra del pivot sobre los ojos
  THIRD_MIN_DISTANCE: 0.6, // distancia mínima al chocar con pared

  // ───────────────────── Cielo (sky.js) ────────────────────────
  SKY_TOP: 0x2f63b5, // azul profundo del cenit
  SKY_HORIZON: 0xbcd6ee, // bruma clara del horizonte
  SKY_BOTTOM: 0x9fb4cc, // neblina bajo el horizonte
  SKY_SUN: 0xfff2d8, // color del disco solar
  SKY_FOG: 0xc3d9ee, // color de la niebla (acorde al horizonte)
  SKY_FOG_NEAR: 55, // distancia donde empieza la bruma
  SKY_FOG_FAR: 150, // distancia donde todo se funde con el cielo
  SKY_CLOUDS: 14, // número de nubes procedurales (0 = desactivadas)

  // ──────────────────────────── Debug ────────────────────────────
  SHOW_FPS: false, // mostrar contador de FPS en el HUD
  SHOW_NET_DEBUG: false, // overlay de métricas de red (Fase 2+)
  SHOW_DEBUG: false, // activar los logs de debug.js en consola

  // ─────── Adiciones de la Fase 4 (presentación y ajustes) ───────
  SETTINGS_KEY: 'wh-settings', // localStorage del objeto de ajustes
  SENS_MIN: 0.3, // límite inferior del slider de sensibilidad
  SENS_MAX: 2.5, // límite superior del slider de sensibilidad

  // Retículo dinámico (px de separación de las marcas)
  CROSSHAIR_BASE_PX: 4, // separación en reposo
  CROSSHAIR_MOVE_PX: 6, // px extra a plena marcha
  CROSSHAIR_FIRE_PX: 10, // px del impacto de cada disparo (decae)
  CROSSHAIR_DECAY_S: 9, // velocidad de decaimiento del spread (1/s)
  CROSSHAIR_WOLF_SCALE: 0.65, // el retículo del lobo es más compacto

  // Viewmodel de primera persona
  VM_KICK_DECAY: 11, // decaimiento del retroceso (1/s)
  VM_KICK_POS: 0.055, // metros que retrocede el arma por disparo
  VM_KICK_ROT: 0.11, // radianes que bascula por disparo
  VM_SWAY_RATE: 9, // suavizado del balanceo por mirada (1/s)
  VM_SWAY_MAX: 0.035, // tope del balanceo (rad/m)
  VM_BOB_HZ: 7.4, // frecuencia del balanceo al caminar
  VM_BOB_AMT: 0.011, // amplitud del balanceo (m)
  VM_RELOAD_DIP: 0.16, // metros que baja el arma al recargar
  VM_RELOAD_ROT: 0.55, // radianes que bascula el arma al recargar
  VM_CLAW_TIME_MS: 240, // duración del barrido de zarpazo en pantalla

  // Audio posicional (todo sintetizado: cero descargas)
  AUDIO_MAX_DIST_M: 48, // a esta distancia un efecto remoto es casi inaudible
  AUDIO_PAN_MAX: 0.75, // separación estéreo máxima (0..1)

  // ─────── Adiciones de la Fase 1 (física y render, documentadas) ───────
  EYE_HEIGHT: 1.6, // altura de los ojos sobre los pies (cámara en 1ª persona)
  STEP_HEIGHT: 0.55, // escalón máximo salvable sin saltar (rampas y bordes)
  TERMINAL_VELOCITY: 30, // velocidad de caída máxima (unidades/segundo)
  MAX_DELTA_S: 0.05, // recorte de delta time por frame (anti-túnel al volver de 2º plano)
  CAMERA_NEAR: 0.05, // plano cercano de la cámara
  CAMERA_FAR: 160, // plano lejano de la cámara
  SHADOWS: 'auto' // 'auto' | true | false — sombras dinámicas ('auto' decide por hardware)
};
