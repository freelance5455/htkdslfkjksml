/**
 * WOLF-HUNTER · settings-menu.js (Fase 4)
 * Controlador de la pantalla de Ajustes: sincroniza los controles DOM con
 * el objeto `settings` y aplica los cambios EN CALIENTE.
 *
 * La pantalla es un OVERLAY (screens.open), no un estado de la máquina:
 * se abre sobre el menú, el lobby o la PARTIDA en curso — la sesión
 * sigue viva debajo (los ajustes de sensibilidad y volumen son live).
 * Cualquier transición de estado (p. ej. el host arranca la ronda) la
 * cierra sola porque ScreenManager.show() recoge los overlays abiertos.
 *
 * Nada de lógica de juego aquí: los efectos reales viven en callbacks
 * (onQuality, onFps) que main.js inyecta, porque solo él toca el renderer.
 */

import { settings } from './settings.js';

/** @param {string} id @returns {HTMLElement} */
const $ = (id) => document.getElementById(id);

export class SettingsMenu {
  /**
   * @param {object} deps
   * @param {object} deps.screens ScreenManager (overlays adicionales)
   * @param {object} deps.audio GameAudio (volúmenes + clics de interfaz)
   * @param {(q: 'auto'|'high'|'low') => void} deps.onQuality aplica calidad al renderer
   * @param {(show: boolean) => void} deps.onFps muestra/oculta el chip de FPS
   * @param {() => void} [deps.onColorblind] remapea los colores ya pintados
   * @param {() => void} [deps.onOpen] aviso de apertura (main.js suelta los dedos)
   */
  constructor({ screens, audio, onQuality, onFps, onColorblind, onOpen }) {
    this.screens = screens;
    this.audio = audio;
    this.onQuality = onQuality || (() => {});
    this.onFps = onFps || (() => {});
    this.onColorblind = onColorblind || (() => {});
    this.onOpen = onOpen || (() => {});

    this.els = {
      screen: $('screen-settings'),
      sens: $('set-sens'),
      sensVal: $('set-sens-val'),
      invert: $('set-invert'),
      vibration: $('set-vibration'),
      colorblind: $('set-colorblind'),
      volMaster: $('set-vol-master'),
      volMasterVal: $('set-vol-master-val'),
      volSfx: $('set-vol-sfx'),
      volSfxVal: $('set-vol-sfx-val'),
      volUi: $('set-vol-ui'),
      volUiVal: $('set-vol-ui-val'),
      fps: $('set-fps'),
      qualityBtns: { auto: $('q-auto'), high: $('q-high'), low: $('q-low') },
      reset: $('btn-settings-reset'),
      done: $('btn-settings-done')
    };

    this._wire();
  }

  /** Cableado de todos los controles (una sola vez). */
  _wire() {
    // Puntos de entrada: menú, lobby y engranaje del HUD
    $('btn-settings-menu').addEventListener('click', () => this.open());
    $('btn-settings-lobby').addEventListener('click', () => this.open());
    $('btn-settings-game').addEventListener('click', () => this.open());

    // Sliders: cambio en vivo + persistencia al soltar
    this.els.sens.addEventListener('input', () => {
      const v = parseFloat(this.els.sens.value);
      this.els.sensVal.textContent = `${v.toFixed(2)}×`;
      settings.apply('sens', v); // live sin disco: player.js lo lee por frame
    });
    this.els.sens.addEventListener('change', () => {
      settings.set('sens', parseFloat(this.els.sens.value)); // persiste
      this.audio.uiClick();
    });
    for (const [key, el, valEl] of [
      ['volMaster', this.els.volMaster, this.els.volMasterVal],
      ['volSfx', this.els.volSfx, this.els.volSfxVal],
      ['volUi', this.els.volUi, this.els.volUiVal]
    ]) {
      el.addEventListener('input', () => {
        const v = parseFloat(el.value);
        valEl.textContent = `${Math.round(v * 100)}%`;
        this.audio.setVolumes({ [key]: v });
      });
      el.addEventListener('change', () => {
        settings.set(key, parseFloat(el.value));
        this.audio.uiClick(); // confirmación al soltar
      });
    }

    // Interruptores (botones role=switch)
    for (const [key, el] of [
      ['invertY', this.els.invert],
      ['vibration', this.els.vibration],
      ['colorblind', this.els.colorblind],
      ['showFps', this.els.fps]
    ]) {
      el.addEventListener('click', () => {
        const next = el.getAttribute('aria-checked') !== 'true';
        el.setAttribute('aria-checked', String(next));
        settings.set(key, next);
        this.audio.uiToggle(next);
        if (key === 'showFps') this.onFps(next);
        if (key === 'colorblind') this.onColorblind(); // repinta avatares YA creados
      });
    }

    // Calidad: segmentado Auto / Alta / Baja
    for (const q of ['auto', 'high', 'low']) {
      this.els.qualityBtns[q].addEventListener('click', () => {
        this._setQualityUI(q);
        settings.set('quality', q);
        this.onQuality(q);
      });
    }

    // Restablecer: valores de fábrica + re-sincronizar la UI
    this.els.reset.addEventListener('click', () => {
      settings.reset();
      this.audio.setVolumes(settings.data);
      this.onQuality(settings.data.quality);
      this.onFps(settings.data.showFps);
      this.syncUI();
      // El clic suena por la delegación global de main.js (una sola vez)
    });

    this.els.done.addEventListener('click', () => this.close());
  }

  /** Marca el botón activo del segmentado de calidad. */
  _setQualityUI(q) {
    for (const key of ['auto', 'high', 'low']) {
      const on = key === q;
      this.els.qualityBtns[key].classList.toggle('is-active', on);
      this.els.qualityBtns[key].setAttribute('aria-pressed', String(on));
    }
  }

  /** Abre el overlay con los controles sincronizados. */
  open() {
    this.syncUI();
    this.onOpen();
    this.screens.open('screen-settings');
  }

  /** Cierra el overlay (idempotente). */
  close() {
    this.screens.close('screen-settings');
  }

  /** @returns {boolean} si está abierto ahora mismo */
  get isOpen() {
    return this.screens.isOpen('screen-settings');
  }

  /** Vuelca `settings.data` en los controles (apertura y Restablecer). */
  syncUI() {
    const d = settings.data;

    this.els.sens.value = String(d.sens);
    this.els.sensVal.textContent = `${d.sens.toFixed(2)}×`;

    this.els.invert.setAttribute('aria-checked', String(d.invertY));
    this.els.vibration.setAttribute('aria-checked', String(d.vibration));
    this.els.colorblind.setAttribute('aria-checked', String(d.colorblind));
    this.els.fps.setAttribute('aria-checked', String(d.showFps));

    this.els.volMaster.value = String(d.volMaster);
    this.els.volMasterVal.textContent = `${Math.round(d.volMaster * 100)}%`;
    this.els.volSfx.value = String(d.volSfx);
    this.els.volSfxVal.textContent = `${Math.round(d.volSfx * 100)}%`;
    this.els.volUi.value = String(d.volUi);
    this.els.volUiVal.textContent = `${Math.round(d.volUi * 100)}%`;

    this._setQualityUI(d.quality);
  }
}
