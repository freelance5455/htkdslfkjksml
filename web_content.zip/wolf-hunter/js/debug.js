/**
 * WOLF-HUNTER · debug.js
 * Sustituto de console.log: en producción no imprime nada salvo errores.
 * Actívalo con CONFIG.SHOW_DEBUG = true o con ?debug en la URL.
 * El contador de FPS se activa con CONFIG.SHOW_FPS o con ?fps.
 */
import { CONFIG } from '../config.js';

const params = new URLSearchParams(location.search);
const debugEnabled = CONFIG.SHOW_DEBUG || params.has('debug');
const fpsEnabled = CONFIG.SHOW_FPS || params.has('fps');

/** Último FPS medido; lo lee el panel de diagnóstico de error-handler.js. */
const state = { lastFps: 0, lastMs: 0 };

export const debug = {
  /** @returns {boolean} si el modo debug está activo */
  get enabled() {
    return debugEnabled;
  },

  /** @returns {boolean} si el contador de FPS debe verse en el HUD */
  get fpsEnabled() {
    return fpsEnabled;
  },

  /** Log informativo, silenciado en producción. */
  log(...args) {
    if (debugEnabled) console.info('[wolf]', ...args);
  },

  /** Aviso, silenciado en producción. */
  warn(...args) {
    if (debugEnabled) console.warn('[wolf]', ...args);
  },

  /** Error: SIEMPRE visible (necesario para diagnosticar). */
  error(...args) {
    console.error('[wolf]', ...args);
  },

  state
};

/**
 * Contador de FPS con media por ventana de medio segundo.
 * Actualiza un chip del HUD con código de color y guarda la última
 * lectura en debug.state para el diagnóstico de errores.
 */
export class FpsCounter {
  /** @param {HTMLElement} el chip del HUD donde pintar el FPS */
  constructor(el) {
    this.el = el;
    this.frames = 0;
    this.acc = 0;
  }

  /**
   * Acumula un frame.
   * @param {number} dt delta time del frame en segundos
   */
  tick(dt) {
    this.frames += 1;
    this.acc += dt;
    if (this.acc < 0.5) return;
    const fps = Math.round(this.frames / this.acc);
    const ms = (this.acc / this.frames) * 1000;
    state.lastFps = fps;
    state.lastMs = ms;
    this.frames = 0;
    this.acc = 0;
    this._render(fps, ms);
  }

  _render(fps, ms) {
    this.el.textContent = `${fps} FPS`;
    this.el.dataset.level = fps >= 50 ? 'good' : fps >= 30 ? 'mid' : 'bad';
    this.el.title = `${ms.toFixed(1)} ms por fotograma`;
  }
}
