/**
 * WOLF-HUNTER · network.js
 * Capa P2P sobre PeerJS con host autoritativo. Dos roles:
 *
 *  HOST  · startHost(): crea la sala con código corto de 4 caracteres.
 *        · Valida cada HELLO (versión, aforo, contraseña, partida en curso).
 *        · Aplica rate-limit por conexión (MAX_MSG_PER_SEC, token bucket).
 *        · Recibe INPUT validados y los entrega al juego (game-session).
 *        · Difunde STATE a la cadencia que marque la sesión.
 *  CLIENT · join(): conecta al `wh-<CODIGO>`, hace el handshake y
 *        · reenvía al juego todo lo que llega del host.
 *
 * Señalización: broker público de PeerJS (0.peerjs.com) — solo para
 * PRESENTARSE; los datos del juego viajan P2P directo por la WiFi local.
 *
 * Todos los errores de PeerJS se traducen a español antes de llegar a la
 * UI (eventos 'net-error' con título y texto listos para pintar).
 */

import { CONFIG } from '../config.js';
import {
  MSG,
  REJECT,
  REJECT_TEXT,
  isValidMessage,
  validateHello,
  validateInput,
  validatePing,
  msgHello,
  msgPong,
  msgReject,
  msgWelcome
} from './protocol.js';
import { loadPeerJS } from './lib/peerjs-loader.js';
import { debug } from './debug.js';

// Alfabeto sin caracteres confusos (sin 0/O, 1/I/L) → códigos legibles
const CODE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';

/** Paleta de jugadores (índice = id; el host es 0 = rojo coral). */
export const PLAYER_COLORS = [0xff6b6b, 0x4dc9b0, 0xf2b94b, 0x7a9ff0];

/** @param {number} hex color numérico @returns {string} '#rrggbb' */
export function colorToCss(hex) {
  return '#' + hex.toString(16).padStart(6, '0');
}

/** Emisor de eventos mínimo (on/off/emit) sin dependencias. */
class Emitter {
  constructor() {
    this._handlers = new Map();
  }

  /**
   * Suscribe un evento.
   * @param {string} ev nombre del evento
   * @param {Function} fn manejador
   * @returns {Function} función para desuscribir
   */
  on(ev, fn) {
    if (!this._handlers.has(ev)) this._handlers.set(ev, new Set());
    this._handlers.get(ev).add(fn);
    return () => this.off(ev, fn);
  }

  /** Desuscribe. */
  off(ev, fn) {
    const set = this._handlers.get(ev);
    if (set) set.delete(fn);
  }

  /** Emite un evento de forma segura (un manejador que lanza no rompe el resto). */
  emit(ev, payload) {
    const set = this._handlers.get(ev);
    if (!set) return;
    for (const fn of [...set]) {
      try {
        fn(payload);
      } catch (e) {
        debug.error(`[net] manejador de '${ev}' falló:`, e);
      }
    }
  }
}

/** Cubo de tokens por conexión: N mensajes/segundo con ráfaga inicial. */
class TokenBucket {
  constructor(capacity, refillPerSec) {
    this.capacity = capacity;
    this.refill = refillPerSec;
    this.tokens = capacity;
    this.last = performance.now();
    this.strikes = 0;
    this.strikeAt = 0;
  }

  /**
   * ¿Pasa este mensaje?
   * @returns {boolean} true si consume un token
   */
  take() {
    const now = performance.now();
    this.tokens = Math.min(this.capacity, this.tokens + ((now - this.last) / 1000) * this.refill);
    this.last = now;
    if (this.tokens >= 1) {
      this.tokens -= 1;
      return true;
    }
    // Infracción: 3 en menos de 10 s = expulsión (lo decide network.js)
    if (now - this.strikeAt > 10000) this.strikes = 0;
    this.strikes += 1;
    this.strikeAt = now;
    return false;
  }
}

/**
 * Traduce un error de PeerJS a un texto en español para el jugador.
 * @param {Error} err error crudo de PeerJS (err.type define el caso)
 * @param {string} [code] código de sala para contextualizar
 * @returns {{title: string, text: string}}
 */
export function translatePeerError(err, code) {
  const type = err && err.type ? err.type : '';
  switch (type) {
    case 'peer-unavailable':
      return {
        title: 'Sala no encontrada',
        text: `No hay ninguna sala «${code || '?'}» con ese código. ` +
          'Comprueba que el anfitrión sigue en el lobby y que escribiste el código tal cual.'
      };
    case 'network':
      return {
        title: 'Sin conexión',
        text: 'Se perdió el acceso a internet. La señal P2P necesita internet solo para presentar a los jugadores; revisa la WiFi y reintenta.'
      };
    case 'server-error':
      return {
        title: 'Servidor ocupado',
        text: 'El servidor de encuentro de PeerJS no responde. Suele ser momentáneo: espera unos segundos y vuelve a intentarlo.'
      };
    case 'browser-incompatible':
      return {
        title: 'Navegador incompatible',
        text: 'Este navegador no soporta WebRTC. Actualiza Chrome o usa otro navegador moderno.'
      };
    default:
      return {
        title: 'Error de red',
        text: (err && err.message ? err.message : String(err)) +
          '\n\nTipo: ' + (type || 'desconocido')
      };
  }
}

export class NetworkManager extends Emitter {
  constructor() {
    super();
    /** @type {'host'|'client'|null} */
    this.role = null;
    /** @type {string} código legible de la sala ('' hasta abrir) */
    this.code = '';
    /** @type {string} contraseña de la sala (solo host) */
    this.roomPass = '';
    /** @type {Array<{id:number,name:string,color:number,host:boolean}>} roster del host */
    this.roster = [];
    /** El juego está en marcha: bloquea unions a mitad de ronda (host). */
    this.gameInProgress = false;

    this._peer = null;
    /** @type {Map<number, object>} id → DataConnection (host) */
    this._conns = new Map();
    /** @type {Map<object, number>} DataConnection → id (host) */
    this._connIds = new Map();
    this._buckets = new Map(); // DataConnection → TokenBucket (host)
    this._hostConn = null; // DataConnection hacia el host (cliente)
    this._destroyed = false;
    this._joinTimer = null;
    this._helloTimers = new Map();
    /** Rechazo pendiente de la operación en curso (lo invoca destroy()). */
    this._pendingReject = null;

    this._msgsIn = 0;
    this._msgsOut = 0;
    this._clientReady = false; // WELCOME recibido

    // Callback que la sesión instala para validar contraseñas custom
    this.onHelloExtra = null;
  }

  // ═════════════════════════ HOST ═════════════════════════

  /**
   * Crea una sala como anfitrión.
   * @param {object} opts
   * @param {string} opts.name nombre saneado del anfitrión
   * @param {string} [opts.pass] contraseña opcional de la sala
   * @returns {Promise<string>} código de la sala
   */
  async startHost({ name, pass }) {
    if (this.role) throw new Error('Ya hay una sesión de red activa.');
    this._destroyed = false; // nueva sesión: los eventos vuelven a contar
    await loadPeerJS();

    for (let attempt = 0; attempt < 3; attempt++) {
      const code = this._makeCode();
      try {
        await this._openHostPeer(code, name, pass || '');
        this.role = 'host';
        this.code = code;
        this.roomPass = pass || '';
        this.roster = [{ id: 0, name, color: PLAYER_COLORS[0], host: true }];
        return code;
      } catch (err) {
        // 'unavailable-id' = otra sala del mundo usa el código: reintenta
        if (err && err.type === 'unavailable-id' && attempt < 2) continue;
        throw err;
      }
    }
    throw new Error('No se pudo reservar un código de sala. Reintenta en unos segundos.');
  }

  /** Abre el Peer del host y espera a que el broker acepte el ID. */
  _openHostPeer(code, name, pass) {
    return new Promise((resolve, reject) => {
      const peer = new window.peerjs.Peer(`wh-${code}`, { debug: 0 });
      this._peer = peer;
      this._pendingReject = reject; // destroy() puede cancelar la creación
      const onOpen = () => {
        cleanup();
        this._pendingReject = null;
        resolve();
      };
      const onError = (err) => {
        cleanup();
        this._pendingReject = null;
        try {
          peer.destroy();
        } catch (e) { /* ya muerto */ }
        reject(err);
      };
      const cleanup = () => {
        peer.off('open', onOpen);
        peer.off('error', onError);
      };
      peer.on('open', onOpen);
      peer.on('error', onError); // errores tardíos los maneja _wireHostPeer
      this._wireHostPeer(peer, pass);
    });
  }

  /** Registra los eventos permanentes del Peer del host. */
  _wireHostPeer(peer, pass) {
    peer.on('connection', (conn) => this._acceptConnection(conn, pass));

    peer.on('disconnected', () => {
      if (this._destroyed) return;
      // Perdimos el broker: las conexiones existentes SIGUEN vivas (son
      // P2P directas), pero no entran jugadores nuevos hasta reconectar.
      this.emit('status', { text: 'Reconectando con el servidor de encuentro…', level: 'warn' });
      try {
        peer.reconnect();
      } catch (e) {
        debug.warn('[net] reconnect falló:', e);
      }
    });

    peer.on('error', (err) => {
      if (this._destroyed) return;
      debug.error('[net] error peer host:', err.type, err.message);
    });
  }

  /** Reserva una conexión entrante y espera su HELLO. */
  _acceptConnection(conn, pass) {
    if (this._destroyed) {
      try { conn.close(); } catch (e) { /* noop */ }
      return;
    }
    debug.log('[net] conexión entrante');

    // Timeout de HELLO: si no se presenta en 6 s, se va
    const helloTimer = setTimeout(() => {
      if (!this._connIds.has(conn)) {
        debug.warn('[net] HELLO no llegó: cerrando conexión');
        try { conn.close(); } catch (e) { /* noop */ }
      }
    }, 6000);
    this._helloTimers.set(conn, helloTimer);

    this._buckets.set(conn, new TokenBucket(CONFIG.MAX_MSG_PER_SEC, CONFIG.MAX_MSG_PER_SEC));

    conn.on('data', (m) => this._onHostData(conn, m, pass));
    conn.on('close', () => this._onConnClosed(conn));
    conn.on('error', (err) => {
      debug.warn('[net] error en conexión:', err && err.message);
      this._onConnClosed(conn);
    });
  }

  /** Procesa un mensaje recibido por el host. */
  _onHostData(conn, m, pass) {
    if (this._destroyed) return;
    this._msgsIn += 1;

    const bucket = this._buckets.get(conn);
    if (bucket && !bucket.take()) {
      if (bucket.strikes >= 3) {
        debug.warn('[net] flooding: expulsando conexión');
        this.emit('status', { text: 'Conexión expulsada por exceso de mensajes.', level: 'warn' });
        try { conn.close(); } catch (e) { /* noop */ }
      } else {
        debug.warn('[net] mensaje fuera de límite ignorado');
      }
      return;
    }

    if (!isValidMessage(m)) {
      debug.warn('[net] mensaje malformado ignorado:', m);
      return;
    }

    const id = this._connIds.get(conn);

    switch (m.t) {
      case MSG.HELLO: {
        if (id !== undefined) return; // ya presentado
        this._handleHello(conn, m, pass);
        return;
      }
      case MSG.INPUT: {
        if (id === undefined) return;
        if (!validateInput(m)) {
          debug.warn(`[net] INPUT inválido de #${id}: ignorado`);
          return;
        }
        this.emit('input', { id, msg: m });
        return;
      }
      case MSG.PING: {
        if (!validatePing(m)) return;
        this._safeSend(conn, msgPong(m.c0, performance.now()));
        return;
      }
      default: {
        // SHOOT y demás mensajes de juego (Fase 3): la sesión decide
        if (id !== undefined) this.emit('message', { id, msg: m });
      }
    }
  }

  /** Handshake: valida y acepta o rechaza. */
  _handleHello(conn, m, pass) {
    const check = validateHello(m);
    if (!check.ok) {
      this._reject(conn, check.reason);
      return;
    }
    if (this.gameInProgress) {
      this._reject(conn, REJECT.GAME);
      return;
    }
    if (this.roster.length >= CONFIG.MAX_PLAYERS) {
      this._reject(conn, REJECT.FULL);
      return;
    }
    if (pass && m.pass !== pass) {
      this._reject(conn, REJECT.PASSWORD);
      return;
    }

    // Id libre más bajo (1..MAX-1; el 0 es el anfitrión)
    const used = new Set(this.roster.map((p) => p.id));
    let id = 1;
    while (used.has(id)) id += 1;

    const player = {
      id,
      name: m.name,
      color: PLAYER_COLORS[id % PLAYER_COLORS.length],
      host: false
    };
    this.roster.push(player);
    this._connIds.set(conn, id);
    this._conns.set(id, conn);

    const timer = this._helloTimers.get(conn);
    if (timer) clearTimeout(timer);
    this._helloTimers.delete(conn);

    this._safeSend(conn, msgWelcome({
      you: id,
      color: player.color,
      roomCode: this.code,
      roster: this.roster
    }));
    debug.log(`[net] jugador #${id} «${m.name}» aceptado`);
    this.emit('peer-joined', { player });
  }

  /** Rechaza una conexión con la razón traducida y la cierra. */
  _reject(conn, reason) {
    this._safeSend(conn, msgReject(reason));
    const text = REJECT_TEXT[reason] || 'Conexión rechazada.';
    debug.warn('[net] conexión rechazada:', reason);
    // Da tiempo al mensaje de salir antes de cerrar el canal
    setTimeout(() => {
      try { conn.close(); } catch (e) { /* noop */ }
    }, 120);
    this.emit('rejected-echo', { reason, text });
  }

  /** Limpieza cuando una conexión se cierra (voluntaria o no). */
  _onConnClosed(conn) {
    const timer = this._helloTimers.get(conn);
    if (timer) {
      clearTimeout(timer);
      this._helloTimers.delete(conn);
    }
    this._buckets.delete(conn);

    const id = this._connIds.get(conn);
    if (id === undefined) return;
    this._connIds.delete(conn);
    this._conns.delete(id);

    const idx = this.roster.findIndex((p) => p.id === id);
    if (idx >= 0) this.roster.splice(idx, 1);
    debug.log(`[net] jugador #${id} desconectado`);
    this.emit('peer-left', { id });
  }

  /**
   * Iterador de [id, conexión] de los clientes aceptados (host).
   * @yields {[number, object]}
   */
  *connections() {
    for (const [id, conn] of this._conns) {
      yield [id, conn];
    }
  }

  /**
   * Envía un mensaje a UN cliente por id (host).
   * @param {number} id id del jugador
   * @param {object} msg mensaje del protocolo
   */
  sendTo(id, msg) {
    const conn = this._conns.get(id);
    if (conn) this._safeSend(conn, msg);
  }

  /**
   * Difunde un mensaje a todos los clientes conectados.
   * @param {object} msg mensaje del protocolo
   */
  broadcast(msg) {
    for (const conn of this._conns.values()) {
      this._safeSend(conn, msg);
    }
  }

  // ═════════════════════════ CLIENTE ═════════════════════════

  /**
   * Se une a la sala de un anfitrión.
   * @param {object} opts
   * @param {string} opts.code código de 4 caracteres
   * @param {string} opts.name nombre saneado
   * @param {string} [opts.pass] contraseña si la sala la tiene
   * @returns {Promise<void>} resuelve con WELCOME, rechaza con error traducido
   */
  async join({ code, name, pass }) {
    if (this.role) throw new Error('Ya hay una sesión de red activa.');
    this._destroyed = false; // nueva sesión: los eventos vuelven a contar
    const clean = String(code || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (clean.length !== CONFIG.ROOM_CODE_LEN) {
      throw new Error('El código de sala tiene 4 caracteres (letras y números).');
    }
    await loadPeerJS();

    return new Promise((resolve, reject) => {
      const peer = new window.peerjs.Peer(undefined, { debug: 0 });
      this._peer = peer;
      let settled = false;
      this._pendingReject = reject; // destroy() puede cancelar el emparejamiento

      const fail = (err) => {
        if (settled) return;
        settled = true;
        this._pendingReject = null;
        clearTimeout(this._joinTimer);
        this.destroy();
        reject(err);
      };
      const ok = (payload) => {
        if (settled) return;
        settled = true;
        this._pendingReject = null;
        clearTimeout(this._joinTimer);
        resolve(payload);
      };

      peer.on('error', (err) => {
        if (this._destroyed) return;
        if (err.type === 'peer-unavailable') {
          fail(new Error(translatePeerError(err, clean).text));
        } else if (!settled) {
          const t = translatePeerError(err, clean);
          fail(new Error(t.title + ' — ' + t.text));
        }
      });

      peer.on('open', () => {
        if (this._destroyed) return;
        const conn = peer.connect(`wh-${clean}`, { reliable: true });
        this._hostConn = conn;

        conn.on('open', () => {
          conn.send(msgHello(name, pass || ''));
          this.emit('status', { text: 'Presentándose con el anfitrión…', level: 'info' });
        });

        conn.on('data', (m) => this._onClientData(m, ok, fail));

        conn.on('close', () => {
          if (this._destroyed) return;
          if (!settled) {
            fail(new Error('El anfitrión cerró la conexión durante el emparejamiento.'));
            return;
          }
          // Partida en marcha: la caída del host termina la sesión
          if (this.role === 'client') {
            this.emit('host-closed', {});
          }
        });

        conn.on('error', (err) => {
          debug.error('[net] error de canal:', err && err.message);
        });

        this._joinTimer = setTimeout(() => {
          if (!settled) {
            fail(new Error('La sala no respondió a tiempo. ¿Está el anfitrión en el lobby?'));
          }
        }, CONFIG.JOIN_TIMEOUT_MS);
      });

      // Broker caído en plena partida: los datos P2P siguen, avisamos
      peer.on('disconnected', () => {
        if (this._destroyed) return;
        this.emit('status', { text: 'Reconectando con el servidor de encuentro…', level: 'warn' });
        try {
          peer.reconnect();
        } catch (e) {
          debug.warn('[net] reconnect falló:', e);
        }
      });
    });
  }

  /** Datos recibidos por el cliente (fase de emparejamiento y juego). */
  _onClientData(m, ok, fail) {
    if (this._destroyed) return;
    this._msgsIn += 1;

    if (!isValidMessage(m)) {
      debug.warn('[net] mensaje malformado del host:', m);
      return;
    }

    switch (m.t) {
      case MSG.WELCOME: {
        this.role = 'client';
        this.code = m.roomCode;
        this._clientReady = true;
        ok(m);
        this.emit('welcome', m);
        return;
      }
      case MSG.REJECT: {
        const text = REJECT_TEXT[m.reason] || 'Conexión rechazada.';
        fail(new Error(text));
        this.emit('rejected', { reason: m.reason, text });
        return;
      }
      default: {
        // STATE, ROUND_START, PONG, efectos… los consume la sesión
        this.emit('message', { msg: m });
      }
    }
  }

  /**
   * Envía un mensaje al host (cliente).
   * @param {object} msg
   */
  sendToHost(msg) {
    if (this._hostConn && this._hostConn.open) {
      this._hostConn.send(msg);
      this._msgsOut += 1;
    }
  }

  // ═════════════════════════ Común ═════════════════════════

  /** Envío tolerante a fallos (conexión a medio cerrar). */
  _safeSend(conn, msg) {
    try {
      if (conn.open) {
        conn.send(msg);
        this._msgsOut += 1;
      }
    } catch (e) {
      debug.warn('[net] envío falló:', e && e.message);
    }
  }

  /** @returns {boolean} true si el canal hacia el host sigue abierto */
  get isConnected() {
    return !!(
      (this.role === 'client' && this._hostConn && this._hostConn.open) ||
      (this.role === 'host')
    );
  }

  /** Estadísticas para el overlay de depuración de red. */
  getStats() {
    return {
      role: this.role,
      code: this.code,
      players: this.role === 'host' ? this.roster.length : 0,
      msgsIn: this._msgsIn,
      msgsOut: this._msgsOut,
      conns: this._conns.size
    };
  }

  /** Cierra TODO ordenadamente (volver al menú, error fatal). */
  destroy() {
    if (this._destroyed && !this.role && !this._peer) return;
    this._destroyed = true;
    clearTimeout(this._joinTimer);

    // Cancela la operación en curso (crear sala / emparejar) para que
    // quien la esperaba no quede colgado.
    if (this._pendingReject) {
      const r = this._pendingReject;
      this._pendingReject = null;
      try {
        r(new Error('Conexión cancelada.'));
      } catch (e) {
        /* el await ya se fue */
      }
    }

    for (const t of this._helloTimers.values()) clearTimeout(t);
    this._helloTimers.clear();

    for (const conn of this._conns.values()) {
      try { conn.close(); } catch (e) { /* noop */ }
    }
    this._conns.clear();
    this._connIds.clear();
    this._buckets.clear();

    if (this._hostConn) {
      try { this._hostConn.close(); } catch (e) { /* noop */ }
      this._hostConn = null;
    }
    if (this._peer) {
      try { this._peer.destroy(); } catch (e) { /* noop */ }
      this._peer = null;
    }

    // Reinicia el estado visible para poder volver a jugar sin recargar.
    // _destroyed queda en true: los eventos residuales de PeerJS se
    // ignoran hasta que startHost()/join() abran una sesión nueva.
    this.role = null;
    this.code = '';
    this.roomPass = '';
    this.roster = [];
    this.gameInProgress = false;
    this._clientReady = false;
  }

  /** Código de sala aleatorio legible. */
  _makeCode() {
    let s = '';
    for (let i = 0; i < CONFIG.ROOM_CODE_LEN; i++) {
      s += CODE_ALPHABET[Math.floor(Math.random() * CODE_ALPHABET.length)];
    }
    return s;
  }
}
