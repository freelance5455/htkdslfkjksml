/**
 * Versión del juego y de la fase actual.
 * El host usa GAME_VERSION para rechazar clientes desactualizados
 * ("Actualiza la página") en el handshake; la Fase 4 no cambia el
 * protocolo (audio, viewmodel y ajustes son presentación local), pero
 * sube la versión para no mezclar builds en la misma sala.
 *
 * 0.4.1 · hotfix de rotación: botón «Girar pantalla» (fullscreen +
 * orientation.lock) con modo horizontal forzado de respaldo para
 * navegadores que no rotan solos (iPhone, navegadores in-app).
 */
export const GAME_VERSION = '0.4.1';
export const PHASE = 4;
