/**
 * WOLF-HUNTER · ui-connection.js
 * Toda la UI de conexión: menú principal, creación de sala (con contraseña
 * opcional), unirse por código, pantalla de conexión y lobby con código
 * grande + QR (carga la librería de QR solo cuando se muestra).
 *
 * Esta clase NO toca la red: delega en un objeto con las acciones reales
 * (main.js lo implementa sobre NetworkManager + GameSession). Así la UI
 * se puede probar sin PeerJS y la lógica de red vive en un solo sitio.
 *
 * Micro-interacciones según las skills de Emil Kowalski: pulsado con
 * scale() instantáneo, entradas desde 0.96 + 10 px, stagger de 40 ms,
 * errores en rojo con altura animada (nunca saltos de layout).
 */

import { sanitizeName, loadName, saveName } from './player-names.js';
import { GameState } from './game-states.js';
import { settings } from './settings.js';
import { debug } from './debug.js';

const QR_CDNS = [
  'https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.js',
  'https://unpkg.com/qrcode-generator@1.4.4/qrcode.js'
];

/** Carga perezosa de la librería de QR (solo al abrir el lobby del host). */
function loadQrLib() {
  if (window.qrcode) return Promise.resolve(window.qrcode);
  if (loadQrLib._p) return loadQrLib._p;
  loadQrLib._p = new Promise((resolve, reject) => {
    let i = 0;
    const tryNext = () => {
      if (i >= QR_CDNS.length) {
        loadQrLib._p = null;
        reject(new Error('QR no disponible'));
        return;
      }
      const s = document.createElement('script');
      s.src = QR_CDNS[i++];
      s.onload = () => (window.qrcode ? resolve(window.qrcode) : tryNext());
      s.onerror = () => {
        s.remove();
        tryNext();
      };
      document.head.appendChild(s);
    };
    tryNext();
  });
  return loadQrLib._p;
}

/** @param {string} el id de elemento @returns {HTMLElement} */
const $ = (el) => document.getElementById(el);

export class ConnectionUI {
  /**
   * @param {object} deps
   * @param {GameStateMachine} deps.machine
   * @param {object} deps.delegate acciones reales:
   *   getName/setName, createRoom(pass), joinRoom(code, pass),
   *   exploreSolo(), startRound(), leave(), cancelConnect()
   */
  constructor({ machine, delegate }) {
    this.machine = machine;
    this.delegate = delegate;
    this.busy = false;
    this._cancelled = false;
    this._qrCode = null;
    this._rosterSig = '';

    this.els = {
      name: $('field-name'),
      menuError: $('menu-error'),
      hostPass: $('host-pass'),
      hostError: $('host-error'),
      joinCode: $('join-code'),
      joinPass: $('join-pass'),
      joinError: $('join-error'),
      connectingText: $('connecting-text'),
      lobbyCode: $('lobby-code'),
      qrBox: $('qr-box'),
      lobbyPlayers: $('lobby-players'),
      lobbyCount: $('lobby-count'),
      lobbyWait: $('lobby-wait'),
      btnStart: $('btn-start')
    };

    // Nombre persistido
    this.els.name.value = loadName();

    this._wire();
    this._wireMachine();

    // Deep link ?join=CODE: abre directamente la pantalla de unirse
    const params = new URLSearchParams(location.search);
    const pre = (params.get('join') || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (pre.length === 4) {
      this.els.joinCode.value = pre;
      machine.go(GameState.JOIN);
    }
  }

  // ═══════════════════════ Cableado DOM ═══════════════════════

  _wire() {
    const go = (fn) => (e) => {
      e.preventDefault();
      if (!this.busy) fn();
    };

    $('btn-create').addEventListener('click', go(() => {
      this._commitName();
      this.machine.go(GameState.HOST_SETUP);
    }));

    $('btn-join').addEventListener('click', go(() => {
      this._commitName();
      this.machine.go(GameState.JOIN);
    }));

    $('btn-explore').addEventListener('click', go(() => {
      this._commitName();
      this.delegate.exploreSolo();
    }));

    // — Crear sala —
    $('btn-host-back').addEventListener('click', go(() => this.machine.go(GameState.MENU)));
    $('btn-host-go').addEventListener('click', go(() => this._createRoom()));

    // — Unirse —
    $('btn-join-back').addEventListener('click', go(() => this.machine.go(GameState.MENU)));
    $('btn-join-go').addEventListener('click', go(() => this._joinRoom()));

    // — Conectando —
    $('btn-connect-cancel').addEventListener('click', go(() => {
      this._cancelled = true; // el error de "cancelado" no debe verse como fallo
      this.busy = false;
      this.delegate.cancelConnect();
    }));

    // — Lobby —
    this.els.btnStart.addEventListener('click', go(() => this.delegate.startRound()));
    $('btn-leave-lobby').addEventListener('click', go(() => this._leave()));

    // — Nombre: saneado al salir del campo, guardado al cambiar —
    this.els.name.addEventListener('blur', () => this._commitName());
    this.els.name.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        this.els.name.blur();
      }
    });

    // — Código: mayúsculas y solo alfanumérico en vivo —
    this.els.joinCode.addEventListener('input', () => {
      const v = this.els.joinCode.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
      this.els.joinCode.value = v.slice(0, 4);
    });
    this.els.joinCode.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        this._joinRoom();
      }
    });
    this.els.hostPass.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        this._createRoom();
      }
    });
    this.els.joinPass.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        this._joinRoom();
      }
    });
  }

  /** Reacciona a cambios de estado globales. */
  _wireMachine() {
    this.machine.on((from, to) => {
      if (to === GameState.MENU) {
        this._error(this.els.menuError, null);
        this._error(this.els.hostError, null);
        this._error(this.els.joinError, null);
      }
      if (to === GameState.HOST_SETUP) this._error(this.els.hostError, null);
      if (to === GameState.JOIN) {
        this._error(this.els.joinError, null);
        // El teclado abre el campo inmediato en móvil: bien
      }
    });
  }

  // ═══════════════════════ Acciones ═══════════════════════

  _commitName() {
    const clean = sanitizeName(this.els.name.value);
    this.els.name.value = clean;
    saveName(clean);
    return clean;
  }

  async _createRoom() {
    if (this.busy) return;
    const pass = this.els.hostPass.value;
    this._cancelled = false;
    this.busy = true;
    this._error(this.els.hostError, null);
    this.els.connectingText.textContent = 'Creando sala…';
    this.machine.go(GameState.CONNECTING);
    try {
      await this.delegate.createRoom(pass);
      // El lobby lo abre la sesión (becomeHost) — aquí solo limpiamos
      this.els.hostPass.value = '';
    } catch (err) {
      if (!this._cancelled) {
        this.machine.go(GameState.HOST_SETUP);
        this._error(this.els.hostError, err.message || String(err));
      }
    } finally {
      this.busy = false;
    }
  }

  async _joinRoom() {
    if (this.busy) return;
    const code = this.els.joinCode.value;
    if (code.length !== 4) {
      this._error(this.els.joinError, 'El código tiene 4 caracteres (por ejemplo: 7K2M).');
      this.els.joinCode.focus();
      return;
    }
    this._cancelled = false;
    this.busy = true;
    this._error(this.els.joinError, null);
    this.els.connectingText.textContent = `Conectando a la sala ${code}…`;
    this.machine.go(GameState.CONNECTING);
    try {
      await this.delegate.joinRoom(code, this.els.joinPass.value);
    } catch (err) {
      if (!this._cancelled) {
        this.machine.go(GameState.JOIN);
        this._error(this.els.joinError, err.message || String(err));
      }
    } finally {
      this.busy = false;
    }
  }

  _leave() {
    this.busy = false;
    this.delegate.leave();
  }

  // ═══════════════════════ Estado del lobby ═══════════════════════

  /**
   * Pinta el lobby (código, QR y lista de jugadores).
   * @param {object} opts
   * @param {string} opts.code código de sala
   * @param {Array<{id:number,name:string,color:number,host:boolean}>} opts.roster
   * @param {boolean} opts.isHost true si este dispositivo es el anfitrión
   */
  setLobby({ code, roster, isHost }) {
    this.els.lobbyCode.textContent = (code || '----')
      .split('')
      .join(' ');

    // QR solo en el anfitrión (es quien comparte la invitación) y solo
    // cuando cambia el código (no lo regeneramos en cada refresco)
    if (isHost) {
      this.els.qrBox.parentElement.removeAttribute('hidden');
      if (this._qrCode !== code) {
        this._qrCode = code;
        this._renderQr(code);
      }
    } else {
      this.els.qrBox.parentElement.setAttribute('hidden', '');
    }

    // Lista de jugadores: punto de color + nombre + insignia
    // (se reconstruye solo si cambió algo: la firma evita parpadeos;
    // incluye el modo daltonismo para repintar al conmutarlo)
    const sig = roster.map((p) => `${p.id}:${p.name}:${p.color}`).join('|') +
      (isHost ? '#h' : '') + (settings.data.colorblind ? '#cb' : '');
    if (sig !== this._rosterSig) {
      this._rosterSig = sig;
      const ul = this.els.lobbyPlayers;
      ul.textContent = '';
      for (const p of roster) {
        const li = document.createElement('li');
        const dot = document.createElement('span');
        dot.className = 'dot';
        dot.style.background = '#' + settings.mapColor(p.color).toString(16).padStart(6, '0');
        const name = document.createElement('span');
        name.className = 'p-name';
        name.textContent = p.name; // textContent: cero XSS
        li.appendChild(dot);
        li.appendChild(name);
        if (p.host) {
          const badge = document.createElement('span');
          badge.className = 'badge';
          badge.textContent = 'anfitrión';
          li.appendChild(badge);
        }
        ul.appendChild(li);
      }
      this.els.lobbyCount.textContent = `${roster.length}/4 jugadores`;
      this.els.btnStart.hidden = !isHost;
      this.els.lobbyWait.hidden = isHost;
    }
  }

  /**
   * Dibuja el QR de invitación (con degradado a texto si el CDN falla).
   * @param {string} code código de sala
   */
  async _renderQr(code) {
    const url = location.origin + location.pathname + '?join=' + code;
    try {
      await loadQrLib();
      const qr = window.qrcode(0, 'M');
      qr.addData(url);
      qr.make();
      let svg;
      try {
        svg = qr.createSvgTag(4, 2); // celda 4 px, margen 2 módulos
      } catch (e) {
        svg = null;
      }
      this.els.qrBox.textContent = '';
      if (svg) {
        this.els.qrBox.innerHTML = svg; // SVG generado por la librería, no por usuarios
        const el = this.els.qrBox.querySelector('svg');
        if (el) {
          el.removeAttribute('width');
          el.removeAttribute('height');
        }
      } else {
        const img = document.createElement('img');
        img.alt = 'QR de invitación';
        img.src = qr.createDataURL(4, 2);
        this.els.qrBox.appendChild(img);
      }
    } catch (e) {
      debug.warn('[ui] librería QR no disponible:', e);
      this.els.qrBox.textContent = '';
      const a = document.createElement('a');
      a.href = url;
      a.textContent = url;
      a.className = 'qr-fallback';
      this.els.qrBox.appendChild(a);
    }
  }

  /**
   * Texto de estado transitorio (conectando, reconectando…).
   * @param {string} text
   */
  setStatusText(text) {
    if (this.machine.current === GameState.CONNECTING && text) {
      this.els.connectingText.textContent = text;
    }
  }

  // ═══════════════════════ Utilidades ═══════════════════════

  /**
   * Muestra/oculta un mensaje de error en línea.
   * @param {HTMLElement} el elemento <p class="form-error">
   * @param {?string} text null = ocultar
   */
  _error(el, text) {
    if (text) {
      el.textContent = text;
      el.hidden = false;
    } else {
      el.hidden = true;
      el.textContent = '';
    }
  }
}
