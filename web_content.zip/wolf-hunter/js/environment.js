/**
 * WOLF-HUNTER · environment.js
 * Mapa blockout simétrico y su física estática.
 *
 * Diseño (vista superior, X este / Z sur, muros interiores en ±24):
 *  · Plaza central 16×16 con pedestal del Núcleo en el origen.
 *  · 4 pasillos radiales de 7 de ancho hacia N/S/E/O con coberturas.
 *  · 2 nidos de francotirador elevados (2.2) en los extremos N y S con
 *    rampa de acceso desde la plaza (los lados quedan como carril bajo).
 *  · Anillo perimetral de 5 de ancho que conecta las 4 esquinas de spawn.
 *
 * Física sin raycasts por frame:
 *  · Colisión horizontal: círculo (radio del jugador) contra AABBs.
 *  · Suelo: máximo "top" de colliders pisables + rampas analíticas
 *    (interpolación lineal exacta de la superficie).
 *  · Un collider deja de bloquear cuando su cara superior está a menos de
 *    STEP_HEIGHT por encima de los pies (permite subir rampas y escalones,
 *    impide atravesar muros y cajas altas).
 */
import * as THREE from 'three';
import { CONFIG } from '../config.js';

// ─────────────────────── Constantes del mapa ───────────────────────
const MAP = {
  half: 24, // cara interior de los muros perimetrales
  wallT: 1, // grosor de muro
  wallH: 4, // altura de muro
  plazaHalf: 8, // semi-ancho de la plaza central
  corridorHalf: 3.5, // semi-ancho de pasillo
  blockH: 3.5, // altura de los bloques que cierran los cuadrantes
  platformH: 2.2, // altura de las zonas elevadas
  platformXHalf: 2, // semi-ancho de la plataforma (deja carril bajo lateral)
  platformZFrom: 15.5, // inicio de la plataforma (desde la plaza)
  platformZTo: 19, // fin de la plataforma
  rampXHalf: 1.5, // semi-ancho de rampa
  rampZFrom: 11, // pie de la rampa
  rampSegs: 8, // segmentos del collider de rampa
  pedestalR: 1.3, // radio del pedestal del Núcleo
  pedestalH: 0.6, // altura del pedestal (saltable, no pisable directo)
  pillarH: 3.2
};

// Paleta plana distinguible por zona
const COLORS = {
  baseFloor: 0x4b5568,
  plazaFloor: 0x68748c,
  nsFloor: 0x525d73,
  ewFloor: 0x4d576b,
  ringFloor: 0x434b5e,
  wall: 0x262c3b,
  block: 0x2c3344,
  stub: 0x323a4d,
  platform: 0x7d6146,
  ramp: 0x8a6a4b,
  cover: 0xa8875a,
  lowWall: 0x93a0b4,
  pillar: 0x5d7fa8,
  pedestal: 0xcf7f5f,
  core: 0xff8a3d
};

// ─────────────── Cachés de geometría y materiales ───────────────
let unitBox = null;
let unitPlane = null;
const matCache = new Map();

/** BoxGeometry unitaria compartida (se escala por mesh, no por geometría). */
function sharedBox() {
  if (!unitBox) unitBox = new THREE.BoxGeometry(1, 1, 1);
  return unitBox;
}

/** PlaneGeometry unitaria compartida para todos los suelos. */
function sharedPlane() {
  if (!unitPlane) unitPlane = new THREE.PlaneGeometry(1, 1);
  return unitPlane;
}

/**
 * Material Lambert cacheado por color (los mapas comparten instancia).
 * @param {number} color color plano
 * @param {{flat?: boolean}} [opts]
 * @returns {THREE.MeshLambertMaterial}
 */
function lambert(color, opts = {}) {
  const key = `${color}|${opts.flat ? 1 : 0}`;
  if (!matCache.has(key)) {
    matCache.set(key, new THREE.MeshLambertMaterial({ color, flatShading: !!opts.flat }));
  }
  return matCache.get(key);
}

/**
 * Textura de rejilla sutil (canvas 128px, celda de 2 unidades) para que
 * el suelo transmita velocidad y escala sin coste de assets.
 * @returns {THREE.CanvasTexture}
 */
function makeGridTexture() {
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const g = c.getContext('2d');
  g.fillStyle = '#ffffff';
  g.fillRect(0, 0, 128, 128);
  g.strokeStyle = 'rgba(0, 0, 0, 0.18)';
  g.lineWidth = 2;
  g.strokeRect(0, 0, 128, 128);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  return t;
}

let baseGrid = null;

/**
 * Material de suelo con rejilla al tamaño indicado.
 * @param {number} color color base
 * @param {number} w ancho en unidades
 * @param {number} d profundidad en unidades
 * @returns {THREE.MeshLambertMaterial}
 */
function floorMaterial(color, w, d) {
  if (!baseGrid) baseGrid = makeGridTexture();
  const tex = baseGrid.clone();
  tex.repeat.set(w / 2, d / 2);
  return new THREE.MeshLambertMaterial({ color, map: tex });
}

// ─────────────────────── Constructores ───────────────────────

/**
 * Añade una caja sólida: malla + collider AABB.
 * @param {THREE.Scene} scene
 * @param {Array} colliders lista de colliders del mundo
 * @param {object} p {x, z, w, d, h, y?, color, cast?, receive?, ground?, flat?}
 * @returns {THREE.Mesh}
 */
function addBox(scene, colliders, p) {
  const y = p.y || 0;
  const mesh = new THREE.Mesh(sharedBox(), lambert(p.color, { flat: p.flat }));
  mesh.scale.set(p.w, p.h, p.d);
  mesh.position.set(p.x, y + p.h / 2, p.z);
  mesh.castShadow = p.cast !== false;
  mesh.receiveShadow = p.receive !== false;
  scene.add(mesh);
  colliders.push({
    minX: p.x - p.w / 2,
    maxX: p.x + p.w / 2,
    minZ: p.z - p.d / 2,
    maxZ: p.z + p.d / 2,
    minY: y,
    top: y + p.h,
    ground: p.ground !== false
  });
  return mesh;
}

/**
 * Añade una rampa: losa visual inclinada + rampa analítica (suelo exacto)
 * + colliders segmentados (bloquean laterales sin frenar la subida).
 * @param {THREE.Scene} scene
 * @param {Array} colliders
 * @param {Array} ramps
 * @param {object} p {x, z0, z1, xHalf, h0, h1, color}
 */
function addRamp(scene, colliders, ramps, p) {
  const len = Math.abs(p.z1 - p.z0);
  const rise = p.h1 - p.h0;
  const slopeLen = Math.hypot(len, rise);

  // Losa visual: la cara superior coincide con la recta (z0,h0)→(z1,h1)
  const geo = new THREE.BoxGeometry(p.xHalf * 2, 0.28, slopeLen);
  const mesh = new THREE.Mesh(geo, lambert(p.color));
  mesh.position.set(p.x, (p.h0 + p.h1) / 2 - 0.14, (p.z0 + p.z1) / 2);
  // Signo: el extremo +Z baja con rotación X positiva
  const sign = Math.sign(p.z1 - p.z0) || 1;
  mesh.rotation.x = -sign * Math.atan2(rise, len);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  scene.add(mesh);

  // Suelo analítico: interpolación exacta (liso, sin escalones)
  ramps.push({
    minX: p.x - p.xHalf,
    maxX: p.x + p.xHalf,
    z0: p.z0,
    z1: p.z1,
    h0: p.h0,
    h1: p.h1
  });

  // Colliders por segmento: cada tramo solo bloquea si su borde superior
  // supera STEP_HEIGHT sobre los pies (ver resolveCollisions)
  for (let i = 0; i < MAP.rampSegs; i++) {
    const za = p.z0 + ((p.z1 - p.z0) * i) / MAP.rampSegs;
    const zb = p.z0 + ((p.z1 - p.z0) * (i + 1)) / MAP.rampSegs;
    const ha = p.h0 + (rise * i) / MAP.rampSegs;
    const hb = p.h0 + (rise * (i + 1)) / MAP.rampSegs;
    colliders.push({
      minX: p.x - p.xHalf,
      maxX: p.x + p.xHalf,
      minZ: Math.min(za, zb),
      maxZ: Math.max(za, zb),
      minY: 0,
      top: Math.max(ha, hb),
      ground: false // el suelo lo da la rampa analítica
    });
  }
}

/**
 * Añade un suelo decorativo (plano con rejilla) sobre el suelo base.
 * @param {THREE.Scene} scene
 * @param {number} x centro X
 * @param {number} z centro Z
 * @param {number} w ancho
 * @param {number} d profundidad
 * @param {number} color
 */
function addFloor(scene, x, z, w, d, color) {
  const mesh = new THREE.Mesh(sharedPlane(), floorMaterial(color, w, d));
  mesh.rotation.x = -Math.PI / 2;
  mesh.scale.set(w, d, 1);
  mesh.position.set(x, 0.01, z);
  mesh.receiveShadow = true;
  scene.add(mesh);
}

/**
 * Puntos de aparición: las 4 esquinas, mirando al pedestal central.
 * Puro (sin THREE): lo reutilizará la Fase 2 para asignar spawns por orden.
 * @returns {Array<{x: number, z: number, yaw: number}>}
 */
export function getSpawnPoints() {
  const c = 21.3;
  const pts = [
    { x: c, z: c },
    { x: -c, z: c },
    { x: -c, z: -c },
    { x: c, z: -c }
  ];
  for (const p of pts) {
    // Yaw que orienta la mirada (-Z local) hacia el origen
    p.yaw = Math.atan2(p.x, p.z);
  }
  return pts;
}

/**
 * Construye el mapa completo en la escena.
 * @param {THREE.Scene} scene escena destino
 * @returns {object} mundo {colliders, ramps, spawnPoints, pedestalPosition, update}
 */
export function buildEnvironment(scene) {
  const colliders = [];
  const ramps = [];
  const spawnPoints = getSpawnPoints();
  const H = MAP.half;

  // ── Suelos (el base recibe todo; las zonas tiñen por encima) ──
  const base = new THREE.Mesh(sharedPlane(), floorMaterial(COLORS.baseFloor, 50, 50));
  base.rotation.x = -Math.PI / 2;
  base.scale.set(50, 50, 1);
  base.receiveShadow = true;
  scene.add(base);

  addFloor(scene, 0, 0, MAP.plazaHalf * 2, MAP.plazaHalf * 2, COLORS.plazaFloor);
  // Pasillos N/S y E/W (de plaza al anillo)
  addFloor(scene, 0, -13.5, MAP.corridorHalf * 2, 11, COLORS.nsFloor);
  addFloor(scene, 0, 13.5, MAP.corridorHalf * 2, 11, COLORS.nsFloor);
  addFloor(scene, 13.5, 0, 11, MAP.corridorHalf * 2, COLORS.ewFloor);
  addFloor(scene, -13.5, 0, 11, MAP.corridorHalf * 2, COLORS.ewFloor);
  // Anillo perimetral (N/S completos; E/W recortados para no solaparse)
  addFloor(scene, 0, -21.5, 50, 5, COLORS.ringFloor);
  addFloor(scene, 0, 21.5, 50, 5, COLORS.ringFloor);
  addFloor(scene, 21.5, 0, 5, 43, COLORS.ringFloor);
  addFloor(scene, -21.5, 0, 5, 43, COLORS.ringFloor);

  // ── Muros perimetrales ──
  addBox(scene, colliders, { x: 0, z: -H - 0.5, w: 50, d: 1, h: MAP.wallH, color: COLORS.wall });
  addBox(scene, colliders, { x: 0, z: H + 0.5, w: 50, d: 1, h: MAP.wallH, color: COLORS.wall });
  addBox(scene, colliders, { x: -H - 0.5, z: 0, w: 1, d: 50, h: MAP.wallH, color: COLORS.wall });
  addBox(scene, colliders, { x: H + 0.5, z: 0, w: 1, d: 50, h: MAP.wallH, color: COLORS.wall });

  // ── Bloques que cierran los cuadrantes (brazo + tacón por cuadrante) ──
  for (const sx of [1, -1]) {
    for (const sz of [1, -1]) {
      // Brazo: adyacente al pasillo E/O, de la plaza al anillo
      addBox(scene, colliders, {
        x: sx * 13.5,
        z: sz * 11.25,
        w: 11,
        d: 15.5,
        h: MAP.blockH,
        color: COLORS.block
      });
      // Tacón: cierra la esquina de la plaza
      addBox(scene, colliders, {
        x: sx * 5.75,
        z: sz * 13.5,
        w: 4.5,
        d: 11,
        h: MAP.blockH,
        color: COLORS.stub
      });
    }
  }

  // ── Nidos elevados N y S (plataforma + rampa desde la plaza) ──
  const platformMidZ = (MAP.platformZFrom + MAP.platformZTo) / 2;
  const platformD = MAP.platformZTo - MAP.platformZFrom;
  addBox(scene, colliders, {
    x: 0,
    z: platformMidZ,
    w: MAP.platformXHalf * 2,
    d: platformD,
    h: MAP.platformH,
    color: COLORS.platform
  });
  addBox(scene, colliders, {
    x: 0,
    z: -platformMidZ,
    w: MAP.platformXHalf * 2,
    d: platformD,
    h: MAP.platformH,
    color: COLORS.platform
  });
  addRamp(scene, colliders, ramps, {
    x: 0,
    z0: MAP.rampZFrom,
    z1: MAP.platformZFrom,
    xHalf: MAP.rampXHalf,
    h0: 0,
    h1: MAP.platformH,
    color: COLORS.ramp
  });
  addRamp(scene, colliders, ramps, {
    x: 0,
    z0: -MAP.rampZFrom,
    z1: -MAP.platformZFrom,
    xHalf: MAP.rampXHalf,
    h0: 0,
    h1: MAP.platformH,
    color: COLORS.ramp
  });

  // ── Coberturas en pasillos E/W (dos cajas + muro bajo cada uno) ──
  for (const sx of [1, -1]) {
    addBox(scene, colliders, { x: sx * 12.5, z: 1.9, w: 2.4, d: 1, h: 1.1, color: COLORS.cover });
    addBox(scene, colliders, { x: sx * 15.5, z: -1.9, w: 2.4, d: 1, h: 1.1, color: COLORS.cover });
    addBox(scene, colliders, { x: sx * 16.8, z: 0, w: 0.6, d: 5, h: 1.1, color: COLORS.lowWall });
  }

  // ── Coberturas flanqueando las rampas N/S ──
  for (const sz of [1, -1]) {
    for (const sx of [1, -1]) {
      addBox(scene, colliders, {
        x: sx * 2.4,
        z: sz * 10.5,
        w: 1,
        d: 2.4,
        h: 1.1,
        color: COLORS.cover
      });
    }
  }

  // ── Coberturas del anillo ──
  addBox(scene, colliders, { x: 21.5, z: 0, w: 1, d: 2.4, h: 1.1, color: COLORS.cover });
  addBox(scene, colliders, { x: -21.5, z: 0, w: 1, d: 2.4, h: 1.1, color: COLORS.cover });
  addBox(scene, colliders, { x: 0, z: 21.5, w: 2.4, d: 1, h: 1.1, color: COLORS.cover });
  addBox(scene, colliders, { x: 0, z: -21.5, w: 2.4, d: 1, h: 1.1, color: COLORS.cover });

  // ── Pilares de la plaza ──
  for (const sx of [1, -1]) {
    for (const sz of [1, -1]) {
      addBox(scene, colliders, {
        x: sx * 5.5,
        z: sz * 5.5,
        w: 1,
        d: 1,
        h: MAP.pillarH,
        color: COLORS.pillar,
        flat: true
      });
    }
  }

  // ── Pedestal del Núcleo (cilindro; collider AABB inscrito) ──
  // El Núcleo de Fiera que flota encima lo gestiona beast-core.js (Fase 3):
  // aparece en el pedestal al empezar la ronda y donde muere un lobo.
  const pedestal = new THREE.Mesh(
    new THREE.CylinderGeometry(MAP.pedestalR, MAP.pedestalR * 1.15, MAP.pedestalH, 8),
    lambert(COLORS.pedestal, { flat: true })
  );
  pedestal.position.set(0, MAP.pedestalH / 2, 0);
  pedestal.castShadow = true;
  pedestal.receiveShadow = true;
  scene.add(pedestal);
  colliders.push({
    minX: -MAP.pedestalR,
    maxX: MAP.pedestalR,
    minZ: -MAP.pedestalR,
    maxZ: MAP.pedestalR,
    minY: 0,
    top: MAP.pedestalH,
    ground: true
  });

  return {
    colliders,
    ramps,
    spawnPoints,
    pedestalPosition: new THREE.Vector3(0, MAP.pedestalH, 0),
    get meshCount() {
      return scene.children.length;
    }
  };
}

// ═══════════════════ Consultas físicas reutilizables ═══════════════════
// round-manager.js (Fase 3) reutiliza estas funciones en el host para
// validar los disparos: raycast contra muros + alturas de suelo.

/**
 * Altura del suelo en (x,z) para unos pies dados: máximo entre el suelo
 * base (0), los colliders pisables bajo el límite de escalón y las rampas
 * analíticas.
 * @param {object} world mundo devuelto por buildEnvironment
 * @param {number} x
 * @param {number} z
 * @param {number} feetY altura actual de los pies
 * @returns {number} altura de suelo resultante
 */
export function groundHeightAt(world, x, z, feetY) {
  let ground = 0;
  const limit = feetY + CONFIG.STEP_HEIGHT;

  for (const c of world.colliders) {
    if (!c.ground) continue;
    if (x < c.minX || x > c.maxX || z < c.minZ || z > c.maxZ) continue;
    if (c.top <= limit && c.top > ground) ground = c.top;
  }

  for (const r of world.ramps) {
    if (x < r.minX || x > r.maxX) continue;
    const zMin = Math.min(r.z0, r.z1);
    const zMax = Math.max(r.z0, r.z1);
    if (z < zMin || z > zMax) continue;
    const t = (z - r.z0) / (r.z1 - r.z0);
    const h = r.h0 + (r.h1 - r.h0) * t;
    if (h <= limit + 0.02 && h > ground) ground = h;
  }

  return ground;
}

/**
 * Resuelve la colisión horizontal de un círculo (jugador) contra los AABBs
 * del mundo, empujando la posición fuera de los sólidos. Dos pasadas para
 * estabilizar esquinas.
 * @param {object} world mundo devuelto por buildEnvironment
 * @param {THREE.Vector3} pos posición de los PIES (muta x y z)
 * @param {number} radius radio del jugador
 * @param {number} [feetY=pos.y] altura de los pies para el escalón
 */
export function resolveCollisions(world, pos, radius, feetY) {
  const fy = typeof feetY === 'number' ? feetY : pos.y;
  const limit = fy + CONFIG.STEP_HEIGHT;

  for (let pass = 0; pass < 2; pass++) {
    for (const c of world.colliders) {
      if (c.top <= limit) continue; // pisable: no bloquea
      // Rechazo rápido por AABB ampliado
      if (pos.x + radius <= c.minX || pos.x - radius >= c.maxX) continue;
      if (pos.z + radius <= c.minZ || pos.z - radius >= c.maxZ) continue;

      // Punto más cercano del AABB al centro del círculo
      const cx = Math.min(Math.max(pos.x, c.minX), c.maxX);
      const cz = Math.min(Math.max(pos.z, c.minZ), c.maxZ);
      const dx = pos.x - cx;
      const dz = pos.z - cz;
      const d2 = dx * dx + dz * dz;
      if (d2 >= radius * radius) continue; // no toca

      if (d2 > 1e-8) {
        // Empuje normal al punto de contacto
        const d = Math.sqrt(d2);
        const push = radius - d;
        pos.x += (dx / d) * push;
        pos.z += (dz / d) * push;
      } else {
        // Centro dentro del AABB (teleport o spawn): salir por el eje
        // de menor penetración
        const left = pos.x - c.minX;
        const right = c.maxX - pos.x;
        const back = pos.z - c.minZ;
        const front = c.maxZ - pos.z;
        const m = Math.min(left, right, back, front);
        if (m === left) pos.x = c.minX - radius;
        else if (m === right) pos.x = c.maxX + radius;
        else if (m === back) pos.z = c.minZ - radius;
        else pos.z = c.maxZ + radius;
      }
    }
  }
}

// Objetos temporales reutilizados por raycastColliders (cero allocations)
const _ray = new THREE.Ray();
const _box = new THREE.Box3();
const _hit = new THREE.Vector3();

/**
 * Lanza un rayo contra los colliders del mundo y devuelve la distancia al
 * primer impacto. Se usa para que la cámara no atraviese paredes y, en
 * fases posteriores, para los disparos del servidor autoritativo.
 * @param {object} world mundo devuelto por buildEnvironment
 * @param {THREE.Vector3} origin origen del rayo
 * @param {THREE.Vector3} dir dirección NORMALIZADA
 * @param {number} maxDist longitud máxima
 * @returns {?number} distancia al impacto o null si no hay
 */
export function raycastColliders(world, origin, dir, maxDist) {
  _ray.origin.copy(origin);
  _ray.direction.copy(dir);
  let best = null;
  for (const c of world.colliders) {
    _box.min.set(c.minX, c.minY, c.minZ);
    _box.max.set(c.maxX, c.top, c.maxZ);
    const p = _ray.intersectBox(_box, _hit);
    if (!p) continue;
    const d = origin.distanceTo(p);
    if (d <= maxDist && (best === null || d < best)) best = d;
  }
  return best;
}
