/**
 * WOLF-HUNTER · loading-screen.js
 * Pantalla de carga con pasos reales y barra de progreso (scaleX, no width).
 * Se muestra desde el HTML estático ANTES de que los módulos se descarguen.
 */

/**
 * Controla la pantalla de carga estática de index.html.
 */
export class LoadingScreen {
  constructor() {
    this.root = document.getElementById('loading-screen');
    this.stepEl = document.getElementById('loading-step');
    this.fillEl = document.getElementById('loading-fill');
    this.closed = false;
  }

  /**
   * Actualiza el texto del paso y (opcionalmente) el progreso 0..1.
   * @param {string} text texto del paso en español
   * @param {number} [progress] progreso entre 0 y 1
   */
  setStep(text, progress) {
    if (this.closed || !this.root) return;
    this.stepEl.textContent = text;
    if (typeof progress === 'number') {
      const p = Math.min(1, Math.max(0, progress));
      this.fillEl.style.transform = `scaleX(${p})`;
    }
  }

  /**
   * Cierra la pantalla con un fundido suave y la elimina del DOM.
   * @returns {Promise<void>} se resuelve cuando el fundido terminó
   */
  async finish() {
    if (this.closed || !this.root) return;
    this.setStep('Listo', 1);
    await wait(140);
    this.root.removeAttribute('data-open');
    this.closed = true;
    // Espera la transición antes de retirar el nodo del DOM
    await wait(320);
    this.root.remove();
    this.root = null;
  }

  /**
   * Convierte la pantalla de carga en un mensaje de error fatal
   * (el overlay de error detallado lo gestiona error-handler.js).
   * @param {string} message motivo del fallo
   */
  fail(message) {
    if (this.closed || !this.root) return;
    const spinner = this.root.querySelector('.loading-spinner');
    if (spinner) spinner.style.display = 'none';
    const bar = this.root.querySelector('.loading-bar');
    if (bar) bar.style.display = 'none';
    this.stepEl.textContent = message;
    this.closed = true;
  }
}

/**
 * Espera sincrónica no bloqueante.
 * @param {number} ms milisegundos a esperar
 * @returns {Promise<void>}
 */
function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
