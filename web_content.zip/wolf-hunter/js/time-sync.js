/**
 * WOLF-HUNTER · time-sync.js
 * Sincronización de reloj estilo NTP sobre PING/PONG:
 *
 *   cliente envía PING{c0} —— rtt/2 ——▶ host responde PONG{c0, h1}
 *
 *   offset = h1 - (c0 + rtt/2)   ·   rtt = t2 - c0 (al recibir el PONG)
 *
 * `now()` devuelve la estimación del reloj del host (performance.now()
 * del host) en términos del reloj local. Se usa para estampar los
 * snapshots de STATE y poder interpolar a los remotos en una línea de
 * tiempo común pese a que cada móvil arrancó su reloj cuando quiso.
 *
 * Robustez: mediana de las últimas 8 muestras (ignora picos de GC/WiFi)
 * y el RTT mínimo observado como cota de calidad.
 */

const WINDOW = 8; // muestras para la mediana

export class TimeSync {
  /** @param {() => void} sendPing llamada que envía un PING por la red */
  constructor(sendPing) {
    this._sendPing = sendPing;
    /** @type {Array<{offset:number, rtt:number}>} */
    this._samples = [];
    this._offset = 0; // mediana actual
    this._minRtt = Infinity;
    this._lastSentAt = -Infinity;
    this._sent = 0;
    this._received = 0;
    this._dirty = true; // recalcula la mediana con la próxima consulta
  }

  /**
   * Registra un PONG recibido.
   * @param {{c0: number, h1: number}} msg mensaje PONG
   */
  onPong(msg) {
    const t2 = performance.now();
    const rtt = Math.max(0, t2 - msg.c0);
    if (rtt > 2000) return; // eco absurdo (pestaña dormida): se ignora
    const offset = msg.h1 - (msg.c0 + rtt / 2);
    this._samples.push({ offset, rtt });
    if (this._samples.length > WINDOW) this._samples.shift();
    this._minRtt = Math.min(this._minRtt, rtt);
    this._received += 1;
    this._dirty = true;
  }

  /**
   * Envía PING a la cadencia configurada (llamar cada frame).
   * @param {number} intervalMs cadencia en milisegundos
   */
  update(intervalMs) {
    const now = performance.now();
    if (now - this._lastSentAt >= intervalMs) {
      this._lastSentAt = now;
      this._sent += 1;
      this._sendPing();
    }
  }

  /** Recalcula la mediana del offset si hay muestras nuevas. */
  _recalc() {
    if (!this._dirty) return;
    this._dirty = false;
    if (!this._samples.length) return;
    const sorted = this._samples.map((s) => s.offset).sort((a, b) => a - b);
    const mid = sorted.length >> 1;
    this._offset =
      sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
  }

  /**
   * Estimación del reloj del host AHORA (en ms, dominio performance.now
   * del host pero legible con el reloj local).
   * @returns {number}
   */
  now() {
    this._recalc();
    return performance.now() + this._offset;
  }

  /** @returns {number} offset mediano en ms */
  get offset() {
    this._recalc();
    return this._offset;
  }

  /** @returns {number} RTT de la última muestra (ms) */
  get rtt() {
    return this._samples.length ? this._samples[this._samples.length - 1].rtt : 0;
  }

  /** @returns {number} RTT mínimo observado (ms) */
  get minRtt() {
    return Number.isFinite(this._minRtt) ? this._minRtt : 0;
  }

  /** @returns {boolean} true tras el primer PONG (offset fiable) */
  get ready() {
    return this._received > 0;
  }

  /** Reinicia el estado (reconexión). */
  reset() {
    this._samples.length = 0;
    this._offset = 0;
    this._minRtt = Infinity;
    this._lastSentAt = -Infinity;
    this._dirty = true;
    this._received = 0;
    this._sent = 0;
  }
}
