/**
 * WOLF-HUNTER · remote-players.js
 * Representación de los OTROS jugadores: avatar del color que asignó el
 * host (forma Hunter o Wolf) + etiqueta con barra de vida, animados por
 * INTERPOLACIÓN.
 *
 * Cada avatar tiene un buffer de muestras {t, x, y, z, yaw, wolf, hp, dead,
 * inv} estampadas en el RELOJ DEL HOST (STATE.time) y se pinta en
 *
 *     renderTime = relojHost estimado − INTERP_DELAY_MS (100 ms)
 *
 * El retardo compra estabilidad: con muestras cada 50 ms (20 Hz) siempre
 * hay una a cada lado del instante a pintar y el movimiento es fluido
 * aunque lleguen a ráfagas. Si hay un hueco > 400 ms (lagWiFi), el buffer
 * se vacía y el avatar SALTA a la última muestra en vez de cruzar el mapa
 * a toda velocidad.
 */
import { CONFIG } from '../config.js';
import { createAvatar } from './avatar.js';
import { settings } from './settings.js';

const MAX_SAMPLES = 60; // 3 s de buffer a 20 Hz
const GAP_MS = 400; // hueco que fuerza salto

/** Interpolación angular por el camino corto (evita dar la vuelta). */
function lerpAngle(a, b, t) {
  let d = (b - a) % (Math.PI * 2);
  if (d > Math.PI) d -= Math.PI * 2;
  if (d < -Math.PI) d += Math.PI * 2;
  return a + d * t;
}

export class RemotePlayers {
  /** @param {THREE.Scene} scene escena donde viven los avatares */
  constructor(scene) {
    this.scene = scene;
    /** @type {Map<number, {avatar:object, buffer:Array, speed01:number, grounded:boolean}>} */
    this.map = new Map();
  }

  /**
   * Ingiere la lista `players` de un STATE.
   * @param {Array<{id:number,name:string,color:number,x:number,y:number,z:number,yaw:number,wolf?:boolean,hp?:number,dead?:boolean,inv?:boolean}>} players
   * @param {number} myId id propio (su entrada se ignora)
   * @param {number} hostTime marca de tiempo del STATE (reloj del host)
   */
  updateFromState(players, myId, hostTime) {
    const seen = new Set();

    for (const p of players) {
      if (p.id === myId) continue;
      seen.add(p.id);

      let rec = this.map.get(p.id);
      if (!rec) {
        // El color se remapea al modo daltonismo LOCAL (Fase 4): lo que
        // ve este jugador no cambia lo que ven los demás.
        const avatar = createAvatar({ color: settings.mapColor(p.color), name: p.name });
        this.scene.add(avatar.group);
        rec = { avatar, buffer: [], speed01: 0, grounded: true, color: p.color };
        this.map.set(p.id, rec);
      }

      const buf = rec.buffer;
      const last = buf[buf.length - 1];
      if (last && hostTime - last.t > GAP_MS) buf.length = 0; // salto, no interpolar
      if (last && hostTime <= last.t) continue; // fuera de orden: ignora
      buf.push({
        t: hostTime,
        x: p.x,
        y: p.y,
        z: p.z,
        yaw: p.yaw,
        wolf: !!p.wolf,
        hp: typeof p.hp === 'number' ? p.hp : -1,
        dead: !!p.dead,
        inv: !!p.inv
      });
      if (buf.length > MAX_SAMPLES) buf.shift();
    }

    // Jugadores que desaparecieron del STATE: fuera de la escena
    for (const [id, rec] of this.map) {
      if (!seen.has(id)) {
        this.scene.remove(rec.avatar.group);
        rec.avatar.dispose();
        this.map.delete(id);
      }
    }
  }

  /**
   * Interpola y pinta todos los avatares.
   * @param {number} renderTime instante a representar (reloj del host − 100 ms)
   * @param {number} dt delta time en segundos (para la animación de caminar)
   */
  render(renderTime, dt) {
    for (const rec of this.map.values()) {
      const buf = rec.buffer;
      if (!buf.length) continue;

      // Busca el segmento [a, b] que rodea renderTime (clamp en bordes)
      let a = buf[0];
      let b = buf[0];
      if (renderTime <= buf[0].t) {
        a = b = buf[0];
      } else if (renderTime >= buf[buf.length - 1].t) {
        a = b = buf[buf.length - 1];
      } else {
        for (let i = buf.length - 2; i >= 0; i--) {
          if (buf[i].t <= renderTime) {
            a = buf[i];
            b = buf[i + 1];
            break;
          }
        }
      }

      const span = b.t - a.t;
      const u = span > 1e-6 ? Math.min(1, Math.max(0, (renderTime - a.t) / span)) : 1;
      const x = a.x + (b.x - a.x) * u;
      const y = a.y + (b.y - a.y) * u;
      const z = a.z + (b.z - a.z) * u;
      const yaw = lerpAngle(a.yaw, b.yaw, u);

      const g = rec.avatar.group;
      g.position.set(x, y, z);
      rec.avatar.setYaw(yaw);

      // Estado de combate de la muestra destino (los cambios son discretos)
      rec.avatar.setWolf(b.wolf);
      rec.avatar.setDead(b.dead);
      const maxHp = b.wolf ? CONFIG.WOLF_HP : CONFIG.HUNTER_HP;
      rec.avatar.setHp(b.hp >= 0 && b.hp < maxHp ? b.hp / maxHp : -1);

      // Invulnerable: parpadeo (visible ~7 de cada 12 ticks de 120 ms)
      g.visible = !(b.inv && !b.dead && Math.floor(renderTime / 120) % 12 > 7);

      // Velocidad estimada del segmento → amplitud de zancada
      if (span > 1e-6) {
        const dist = Math.hypot(b.x - a.x, b.z - a.z);
        rec.speed01 = dist / (span / 1000) / CONFIG.HUNTER_SPEED;
        rec.grounded = Math.abs((b.y - a.y) / (span / 1000)) < 0.9;
      }
      rec.avatar.setWalk(rec.speed01, dt, rec.grounded);
    }
  }

  /**
   * Avatar de un jugador remoto (para el destello de daño de fx.js).
   * @param {number} id
   * @returns {?object} avatar o null
   */
  getAvatar(id) {
    const rec = this.map.get(id);
    return rec ? rec.avatar : null;
  }

  /**
   * Repinta los colores con el modo daltonismo ACTUAL (Fase 4): se llama
   * al conmutar el ajuste, con los avatares ya creados.
   */
  refreshColors() {
    for (const rec of this.map.values()) {
      rec.avatar.setColor(settings.mapColor(rec.color));
    }
  }

  /** Elimina todos los avatares (fin de partida). */
  clear() {
    for (const rec of this.map.values()) {
      this.scene.remove(rec.avatar.group);
      rec.avatar.dispose();
    }
    this.map.clear();
  }

  /** @returns {number} jugadores remotos representados */
  get count() {
    return this.map.size;
  }
}
