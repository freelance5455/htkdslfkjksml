/**
 * WOLF-HUNTER · hud.js
 * HUD de combate: vida, munición, temporizadores (ronda y lobo), puntos,
 * registro de bajas, marcadores de daño, retículo dinámico (Fase 4) y las
 * pantallas de muerte y fin de ronda.
 *
 * Este módulo SOLO pinta: no conoce la red ni la física. GameSession le
 * empuja el estado (que llega del host por STATE/HIT/DEATH/…) y él decide
 * cómo se ve. Los botones (disparar/recargar) no viven aquí: input.js es
 * el dueño del tacto; aquí solo se activan/desactivan visualmente.
 *
 * Feedback según las skills de Emil Kowalski: los cambios de número
 * escalan un frame (kicker .pop), la barra de vida cambia de color por
 * umbrales, los avisos de daño entran rápido y salen suave, y (Fase 4)
 * el retículo se ABRE al moverse/disparar y respira cuando queda poca
 * vida o poco lobo.
 */

import { CONFIG } from '../config.js';
import { settings } from './settings.js';

const HP_COLOR_OK = '#3ddc97';
const HP_COLOR_MID = '#f2b94b';
const HP_COLOR_LOW = '#ff5c5c';

/** @param {string} id @returns {HTMLElement} */
const $ = (id) => document.getElementById(id);

export class CombatHUD {
  constructor() {
    this.els = {
      roundInfo: $('round-info'),
      roundTimer: $('round-timer'),
      scoreChip: $('score-chip'),
      killFeed: $('kill-feed'),
      hpWrap: $('hp-wrap'),
      hpFill: $('hp-fill'),
      hpNum: $('hp-num'),
      ammo: $('ammo'),
      ammoMag: $('ammo-mag'),
      ammoReserve: $('ammo-reserve'),
      ammoHint: $('ammo-hint'),
      wolfTimer: $('wolf-timer'),
      wolfFill: $('wolf-fill'),
      wolfNum: $('wolf-num'),
      crosshair: $('crosshair'),
      hitVignette: $('hit-vignette'),
      hitMarker: $('hit-marker'),
      dmgArrow: $('dmg-arrow'),
      lowVignette: $('low-vignette'),
      transformBanner: $('transform-banner'),
      transformFlash: $('transform-flash'),
      deathOverlay: $('death-overlay'),
      deathBy: $('death-by'),
      deathCount: $('death-count'),
      roundEnd: $('round-end'),
      scoreboard: $('scoreboard-body'),
      roundEndNote: $('round-end-note'),
      btnContinue: $('btn-continue')
    };

    /** @returns {number} reloj para los temporizadores visuales */
    this._now = () => performance.now();

    // Relojes de efectos
    this._vignetteUntil = 0;
    this._markerUntil = 0;
    this._markerKill = false;
    this._arrowUntil = 0;
    this._feedTimers = [];

    // ── Fase 4: retículo dinámico y kickers ──
    /** @type {boolean} forma lobo (retículo más compacto) */
    this._wolf = false;
    /** px de spread de disparo (decae solo en update) */
    this._fireSpread = 0;
    /** último --ch-spread pintado (evita tocar CSS sin cambio real) */
    this._spreadPx = -1;
    /** últimos valores pintados (para el kicker solo en CAMBIO) */
    this._lastHp = -1;
    this._lastMag = -1;
    this._lastScore = -1;

    /** Callback que instala main.js (host: volver al lobby). */
    this.onContinue = null;
    this.els.btnContinue.addEventListener('click', () => {
      if (this.onContinue) this.onContinue();
    });
  }

  // ═══════════════════════ Ciclo de vida de la partida ═══════════════════════

  /** Estado inicial de ronda (lo llama ROUND_START). */
  reset() {
    this.setForm(false);
    this.setHp(CONFIG.HUNTER_HP, CONFIG.HUNTER_HP);
    this.setAmmo(CONFIG.MAGAZINE_SIZE, CONFIG.RESERVE_AMMO, false);
    this.setWolfTime(null);
    this.setScore(0);
    this.hideDeath();
    this.hideScoreboard();
    this.clearFeed();
    this._playing(true);
  }

  /** Fin de sesión: oculta todo el HUD de combate. */
  clear() {
    this._playing(false);
    this.hideDeath();
    this.hideScoreboard();
    this.clearFeed();
    this.setWolfTime(null);
    this.els.roundInfo.hidden = true;
    this.els.lowVignette.classList.remove('show');
    this.els.transformBanner.classList.remove('show');
    this.els.transformFlash.classList.remove('show');
    this._fireSpread = 0;
    this._spreadPx = -1;
    this._lastHp = -1;
    this._lastMag = -1;
    this._lastScore = -1;
  }

  /** Muestra u oculta el conjunto del HUD de combate. */
  _playing(on) {
    this.els.hpWrap.hidden = !on;
    this.els.ammo.hidden = !on;
    if (on) this.els.roundInfo.hidden = false;
    this._setCrosshair(on);
  }

  // ═══════════════════════ Forma y barras ═══════════════════════

  /**
   * Cambia la presentación Hunter ↔ Wolf (icono de botón, munición vs
   * temporizador de lobo, retículo).
   * @param {boolean} wolf
   */
  setForm(wolf) {
    this._wolf = !!wolf;
    document.body.dataset.form = wolf ? 'wolf' : 'hunter';
    this.els.ammo.hidden = wolf || this.els.hpWrap.hidden;
    this.els.wolfTimer.hidden = !wolf;
    if (wolf) this.els.roundInfo.hidden = this.els.hpWrap.hidden;
    this._setCrosshair(!this.els.hpWrap.hidden);
  }

  /**
   * Barra de vida (el máximo depende de la forma).
   * @param {number} hp vida actual
   * @param {number} maxHp máximo (HUNTER_HP o WOLF_HP)
   */
  setHp(hp, maxHp) {
    const pct = Math.max(0, Math.min(1, hp / maxHp));
    this.els.hpFill.style.transform = `scaleX(${pct})`;
    this.els.hpFill.style.background =
      pct > 0.5 ? HP_COLOR_OK : pct > 0.25 ? HP_COLOR_MID : HP_COLOR_LOW;
    const shown = Math.max(0, Math.ceil(hp));
    if (shown !== this._lastHp) {
      this._kick(this.els.hpNum);
      this._lastHp = shown;
    }
    this.els.hpNum.textContent = String(shown);
    this.els.hpWrap.classList.toggle('is-low', pct <= 0.25);
    // Fase 4: la viñeta de vida baja respira mientras el HUD esté activo
    this.els.lowVignette.classList.toggle('show', pct <= 0.25 && !this.els.hpWrap.hidden);
  }

  /**
   * Munición del Hunter.
   * @param {number} mag cargador
   * @param {number} reserve reserva
   * @param {boolean} reloading recarga en curso
   */
  setAmmo(mag, reserve, reloading) {
    if (mag !== this._lastMag) {
      this._kick(this.els.ammoMag);
      this._lastMag = mag;
    }
    this.els.ammoMag.textContent = String(mag);
    this.els.ammoReserve.textContent = String(reserve);
    this.els.ammo.classList.toggle('is-empty', mag === 0);
    this.els.ammoHint.hidden = !reloading;
    this.els.ammoHint.textContent = reloading ? 'Recargando…' : '';
    this.els.crosshair.classList.toggle('is-reloading', !!reloading);
  }

  /**
   * Temporizador de lobo (null = forma Hunter).
   * @param {?number} remainingMs milisegundos restantes
   */
  setWolfTime(remainingMs) {
    if (remainingMs === null || remainingMs === undefined) {
      this.els.wolfTimer.hidden = true;
      this.els.wolfTimer.classList.remove('is-urgent');
      return;
    }
    this.els.wolfTimer.hidden = false;
    const ms = Math.max(0, remainingMs);
    this.els.wolfNum.textContent = String(Math.ceil(ms / 1000));
    this.els.wolfFill.style.transform =
      `scaleX(${Math.min(1, ms / CONFIG.WOLF_DURATION_MS)})`;
    // Fase 4: los últimos 5 s del lobo laten
    this.els.wolfTimer.classList.toggle('is-urgent', ms <= 5000 && ms > 0);
  }

  /**
   * Reloj de ronda (null = sin ronda, modo Explorar).
   * @param {?number} remainingMs
   */
  setRoundTime(remainingMs) {
    if (remainingMs === null || remainingMs === undefined) {
      this.els.roundInfo.hidden = true;
      return;
    }
    this.els.roundInfo.hidden = false;
    const s = Math.max(0, Math.ceil(remainingMs / 1000));
    const mm = Math.floor(s / 60);
    const ss = String(s % 60).padStart(2, '0');
    this.els.roundTimer.textContent = `${mm}:${ss}`;
    this.els.roundTimer.classList.toggle('is-urgent', s <= 30);
  }

  /**
   * Puntos del jugador local.
   * @param {number} pts
   */
  setScore(pts) {
    if (pts !== this._lastScore) {
      this._kick(this.els.scoreChip);
      this._lastScore = pts;
    }
    this.els.scoreChip.textContent = `${pts} pts`;
  }

  // ═══════════════════════ Feedback de daño ═══════════════════════

  /**
   * Recibí daño: viñeta roja + flecha hacia el agresor.
   * @param {?number} angleRel rumbo del atacante menos mi yaw (rad);
   *                   0 = delante, positivo = a la izquierda del jugador
   */
  damage(angleRel) {
    this._vignetteUntil = this._now() + 280;
    this.els.hitVignette.classList.add('show');
    if (angleRel !== null && angleRel !== undefined && isFinite(angleRel)) {
      this._arrowUntil = this._now() + 750;
      // CSS rota en sentido horario: se niega para que "izquierda" sea izquierda
      this.els.dmgArrow.style.transform =
        `rotate(${(-angleRel * 180) / Math.PI}deg)`;
      this.els.dmgArrow.classList.add('show');
    }
  }

  /**
   * Mi disparo/zarpazo impactó (marcador en el retículo).
   * @param {boolean} kill true si además fue letal
   */
  hitMark(kill) {
    this._markerUntil = this._now() + (kill ? 420 : 220);
    this._markerKill = !!kill;
    this.els.hitMarker.classList.toggle('is-kill', !!kill);
    this.els.hitMarker.classList.add('show');
  }

  // ═══════════════════════ Retículo y transformación (Fase 4) ═══════════════════════

  /**
   * Un disparo propio abre el retículo (decae solo en update).
   */
  addFireSpread() {
    this._fireSpread = Math.min(
      CONFIG.CROSSHAIR_FIRE_PX * 2,
      this._fireSpread + CONFIG.CROSSHAIR_FIRE_PX
    );
  }

  /**
   * El momento grande: banner + destello al cambiar de forma.
   * @param {boolean} wolf true = me convierto en lobo
   */
  transformBanner(wolf) {
    const b = this.els.transformBanner;
    b.textContent = wolf ? '¡ERES EL LOBO!' : 'LA FURIA SE APAGA';
    b.classList.toggle('is-calm', !wolf);
    // Reinicio de la animación (reflow) para que se pueda re-disparar
    b.classList.remove('show');
    void b.offsetWidth;
    b.classList.add('show');
    if (wolf) {
      this.els.transformFlash.classList.remove('show');
      void this.els.transformFlash.offsetWidth;
      this.els.transformFlash.classList.add('show');
    }
  }

  /**
   * Kicker: el número nuevo salta un frame (solo en cambio de valor).
   * @param {HTMLElement} el
   */
  _kick(el) {
    el.classList.remove('pop');
    void el.offsetWidth; // reinicia la animación CSS
    el.classList.add('pop');
  }

  // ═══════════════════════ Registro de bajas ═══════════════════════

  /**
   * Añade una línea libre al registro (recogidas del Núcleo, avisos).
   * @param {string} texto línea ya formada
   */
  feedLine(texto) {
    const li = document.createElement('li');
    li.textContent = texto;
    this.els.killFeed.appendChild(li);
    while (this.els.killFeed.children.length > CONFIG.KILL_FEED_MAX) {
      this.els.killFeed.removeChild(this.els.killFeed.firstChild);
    }
    const t = setTimeout(() => {
      li.classList.add('fade');
      setTimeout(() => li.remove(), 400);
    }, 4200);
    this._feedTimers.push(t);
  }

  /**
   * Añade una línea al registro ("X abatió a Y").
   * @param {string} killerName
   * @param {string} victimName
   * @param {boolean} wolfKill true si el autor era lobo ("destrozó")
   */
  feedKill(killerName, victimName, wolfKill) {
    this.feedLine(`${killerName} ${wolfKill ? 'destrozó a' : 'abatió a'} ${victimName}`);
  }

  /** Vacía el registro. */
  clearFeed() {
    for (const t of this._feedTimers) clearTimeout(t);
    this._feedTimers.length = 0;
    this.els.killFeed.textContent = '';
  }

  // ═══════════════════════ Muerte y respawn ═══════════════════════

  /**
   * Pantalla de muerte (no bloquea la mirada: se puede observar).
   * @param {string} killerName
   */
  showDeath(killerName) {
    this.els.deathBy.textContent = killerName
      ? `Te abatió ${killerName}`
      : 'Has caído';
    this.els.deathOverlay.setAttribute('data-open', '');
  }

  /**
   * Cuenta atrás textual del respawn.
   * @param {number} ms milisegundos restantes
   */
  setRespawnCountdown(ms) {
    const s = Math.max(0, Math.ceil(ms / 1000));
    this.els.deathCount.textContent = `Reapareces en ${s}…`;
  }

  hideDeath() {
    this.els.deathOverlay.removeAttribute('data-open');
  }

  // ═══════════════════════ Marcador final ═══════════════════════

  /**
   * Pantalla de fin de ronda con el marcador ordenado.
   * @param {Array<{id:number,name:string,color:number,kills:number,wolfSec:number,score:number}>} scores
   * @param {boolean} isHost true si este dispositivo decide la vuelta al lobby
   */
  showScoreboard(scores, isHost) {
    const tbody = this.els.scoreboard;
    tbody.textContent = '';
    scores.forEach((row, i) => {
      const tr = document.createElement('tr');
      if (i === 0 && row.score > 0) tr.className = 'winner';

      const pos = document.createElement('td');
      pos.textContent = `${i + 1}.`;

      const name = document.createElement('td');
      name.className = 'sb-name';
      const dot = document.createElement('span');
      dot.className = 'dot';
      dot.style.background = '#' + settings.mapColor(row.color).toString(16).padStart(6, '0');
      const span = document.createElement('span');
      span.textContent = row.name;
      name.appendChild(dot);
      name.appendChild(span);

      const kills = document.createElement('td');
      kills.textContent = String(row.kills);
      const wolf = document.createElement('td');
      wolf.textContent = `${row.wolfSec}s`;
      const score = document.createElement('td');
      score.className = 'sb-score';
      score.textContent = String(row.score);

      tr.append(pos, name, kills, wolf, score);
      tbody.appendChild(tr);
    });

    this.els.btnContinue.hidden = !isHost;
    this.els.roundEndNote.hidden = isHost;
    this.els.roundEnd.setAttribute('data-open', '');
  }

  hideScoreboard() {
    this.els.roundEnd.removeAttribute('data-open');
  }

  // ═══════════════════════ Bucle ═══════════════════════

  /**
   * Apaga los efectos temporales y anima el retículo.
   * @param {number} dt delta time en segundos
   * @param {number} [moveMag=0] magnitud de movimiento 0..1 (abre el retículo)
   */
  update(dt, moveMag = 0) {
    const now = this._now();
    if (now >= this._vignetteUntil) this.els.hitVignette.classList.remove('show');
    if (now >= this._arrowUntil) this.els.dmgArrow.classList.remove('show');
    if (now >= this._markerUntil) this.els.hitMarker.classList.remove('show');
    this._updateCrosshair(dt, moveMag || 0);
  }

  /**
   * Retículo: base + marcha + decaimiento del disparo, compacto si lobo.
   * Solo se toca el CSS cuando el valor cambia de verdad (0.25 px).
   */
  _updateCrosshair(dt, moveMag) {
    if (this._fireSpread > 0.01) {
      this._fireSpread *= Math.exp(-CONFIG.CROSSHAIR_DECAY_S * dt);
    } else {
      this._fireSpread = 0;
    }
    const wolfScale = this._wolf ? CONFIG.CROSSHAIR_WOLF_SCALE : 1;
    const px = (CONFIG.CROSSHAIR_BASE_PX +
      moveMag * CONFIG.CROSSHAIR_MOVE_PX +
      this._fireSpread) * wolfScale;
    if (Math.abs(px - this._spreadPx) >= 0.25) {
      this._spreadPx = px;
      this.els.crosshair.style.setProperty('--ch-spread', `${px.toFixed(1)}px`);
    }
  }

  /** Retículo visible solo jugando; en forma lobo es más pequeño. */
  _setCrosshair(on) {
    this.els.crosshair.style.opacity = on ? '' : '0';
  }
}
