/**
 * WOLF-HUNTER · weapon-wolf.js
 * Las garras del Wolf: melee en arco frontal, sin munición.
 *
 * El lobo NO dispara: su arma es el cuerpo (docs/wolfteam-analysis.md §2).
 * El cliente solo PIDE el zarpazo (CLAW); el host valida la forma, la
 * cadencia y el arco, y aplica el daño a todos los Hunters dentro del
 * alcance. El arco visual propio se dibuja al instante (la garra debe
 * responder en el mismo frame que el dedo); el de los rivales llega con
 * CLAW_FX.
 */

import { CONFIG } from '../config.js';
import { msgClaw } from './protocol.js';

export class WolfWeapon {
  /**
   * @param {object} deps
   * @param {object} deps.fx CombatFX (arco de zarpazo local)
   * @param {(msg:object) => void} deps.send Sale del CLAW (red o host local)
   * @param {() => void} [deps.onClaw] zarpazo lanzado (audio + viewmodel, Fase 4)
   */
  constructor({ fx, send, onClaw }) {
    this.fx = fx;
    this._send = send;
    this._onClaw = onClaw || null;
    this._seq = 0;
    this._lastClawAt = -1e9;
  }

  /** Reinicia la cadencia (respawn / inicio de ronda). */
  reset() {
    this._lastClawAt = -1e9;
  }

  /**
   * Bucle del arma (forma Wolf, vivo y con la ronda en marcha).
   * @param {number} dt delta en segundos (no usado: cadencia por reloj)
   * @param {number} now performance.now()
   * @param {object} ctx
   * @param {boolean} ctx.fireHeld botón/clic de atacar mantenido
   * @param {number} ctx.x,ctx.z pies del jugador local
   * @param {number} ctx.yaw orientación del jugador local
   */
  update(dt, now, ctx) {
    void dt;
    if (!ctx.fireHeld) return;
    if (now - this._lastClawAt < CONFIG.CLAW_COOLDOWN_MS) return;
    this._lastClawAt = now;

    // Feedback inmediato propio (el host confirmará con CLAW_FX a los demás)
    this.fx.claw(ctx.x, ctx.z, ctx.yaw);
    if (this._onClaw) this._onClaw();
    this._send(msgClaw(this._seq++));
  }
}
