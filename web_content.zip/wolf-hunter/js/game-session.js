/**
 * WOLF-HUNTER · game-session.js
 * Orquestador de una partida: une la red (network.js), la física compartida
 * (movement.js), la predicción del cliente (prediction.js), los remotos
 * interpolados (remote-players.js) y —desde la Fase 3— el COMBATE:
 * round-manager.js (árbitro), armas locales, transformación, Núcleo y HUD.
 *
 * TRES modos de sesión:
 *
 *  · 'solo'  — Exploración sin red. El árbitro corre en local: el Núcleo
 *              del pedestal se puede recoger y la transformación completa
 *              funciona (pista de pruebas de la Fase 3).
 *  · 'host'  — Anfitrión AUTORITATIVO: simula a todos con los INPUT que
 *              recibe, arbitra el combate (SHOOT/CLAW/RELOAD) y difunde
 *              STATE a 20 Hz + los efectos (SHOOT_FX/HIT/DEATH/…). Sus
 *              PROPIOS efectos pasan por el mismo conducto que los de la
 *              red: una sola ruta de presentación, cero divergencia.
 *  · 'client'— Predice su movimiento, pide disparos/zarpazos/recargas y
 *              reconcilia; interpola a los remotos con 100 ms de retardo.
 *
 * El bucle de la Cacería por Oleadas vive en round-manager.js; aquí solo
 * se cablea quién habla con quién.
 */

import { CONFIG } from '../config.js';
import {
  MSG,
  msgInput,
  msgPing,
  msgState,
  msgRoundStart,
  validateShoot,
  validateSimple
} from './protocol.js';
import { createCharacter, stepCharacter } from './movement.js';
import { PredictedController } from './prediction.js';
import { DirectPhysics } from './player.js';
import { TimeSync } from './time-sync.js';
import { RoundManager } from './round-manager.js';
import { HunterWeapon } from './weapon-hunter.js';
import { WolfWeapon } from './weapon-wolf.js';
import { LocalTransform } from './transform.js';
import { ScoreBoard } from './score.js';
import { settings } from './settings.js';
import { debug } from './debug.js';

// Vectores temporales reutilizados (dirección de mira + oreja del audio)
import * as THREE from 'three';
const _view = new THREE.Vector3();
const _ear = new THREE.Vector3();

export class GameSession {
  /**
   * @param {object} deps
   * @param {object} deps.net NetworkManager
   * @param {object} deps.world mundo de environment.js
   * @param {object} deps.localPlayer LocalPlayer (main.js lo construye)
   * @param {object} deps.remotePlayers RemotePlayers
   * @param {object} deps.machine GameStateMachine
   * @param {object} deps.hud CombatHUD (Fase 3)
   * @param {object} deps.fx CombatFX (Fase 3)
   * @param {object} deps.beastCore BeastCore (Fase 3)
   * @param {object} [deps.audio] GameAudio (Fase 4; null = juego mudo)
   * @param {object} [deps.viewmodel] ViewModel de 1ª persona (Fase 4)
   */
  constructor({ net, world, localPlayer, remotePlayers, machine, hud, fx, beastCore, audio, viewmodel }) {
    this.net = net;
    this.world = world;
    this.player = localPlayer;
    this.remotes = remotePlayers;
    this.machine = machine;
    this.hud = hud;
    this.fx = fx;
    this.beastCore = beastCore;
    this.audio = audio || null; // Fase 4: todo el sonido
    this.viewmodel = viewmodel || null; // Fase 4: brazos en 1ª persona

    /** @type {'solo'|'host'|'client'|null} */
    this.mode = null;
    /** Ronda en marcha (mueve al jugador local y envía INPUT). */
    this.playing = false;
    /** id propio (host: 0, cliente: el del WELCOME). */
    this.myId = 0;
    /** Último roster visto (para HUD y lobby del cliente). */
    this.roster = [];

    // Host: personajes simulados de los clientes (id → char + lastSeq)
    this._chars = new Map();
    this._tickTimer = null;
    this._tickHz = 0;

    // Cliente
    this.prediction = null;
    this.sync = null;
    this._sendAcc = 0;
    this._lastStateAt = 0;
    this._pausedNotice = false;

    // ── Combate (Fase 3) ──
    /** @type {RoundManager|null} árbitro (host y solo). */
    this.roundMgr = null;
    /** Transformación local (avatar + cámara + HUD). */
    this.transform = new LocalTransform({
      avatar: localPlayer.avatar,
      rig: localPlayer.rig,
      hud
    });
    /** Forma local actual (alimenta la speedFn de la física). */
    this._formWolf = false;
    /** Muerte local en curso. */
    this._deadLocal = false;
    /** Fin del respawn y de la ronda, en RELOJ DEL HOST (ms). */
    this._respawnEndsHost = 0;
    this._roundEndsAt = 0;
    /** Formas conocidas de todos (verbos del registro de bajas). */
    this._forms = new Map();
    /** Marcador en vivo del jugador local. */
    this._liveKills = 0;
    this._liveWolfMs = 0;
    /** Timer de vuelta automática al lobby tras el marcador. */
    this._lobbyTimer = null;
    /** Objetivos para el aim assist (reutilizado, cero allocations). */
    this._targets = [];

    // ── Fase 4: estado del feel (salto/aterrizaje, sway del viewmodel) ──
    this._wasGrounded = true;
    this._lastYaw = 0;
    this._lastPitch = 0;

    /** Velocidad según la forma: la leen TODOS los motores de física. */
    this.speedFn = () => (this._formWolf ? CONFIG.WOLF_SPEED : CONFIG.HUNTER_SPEED);

    /** Color propio asignado por el host (para el remapeo daltonismo). */
    this._myColor = 0;

    /** Envío de peticiones de combate (cliente: red · host/solo: árbitro). */
    const sendCombat = (msg) => {
      if (this.mode === 'client') {
        this.net.sendToHost(msg);
        return;
      }
      const mgr = this.roundMgr;
      if (!mgr) return;
      const now = performance.now();
      if (msg.t === MSG.SHOOT) mgr.handleShoot(this.myId, msg, now);
      else if (msg.t === MSG.CLAW) mgr.handleClaw(this.myId, msg, now);
      else if (msg.t === MSG.RELOAD) mgr.handleReload(this.myId, msg, now);
    };

    this.weapons = {
      hunter: new HunterWeapon({
        hud,
        send: sendCombat,
        // Feedback local del frame exacto (Fase 4): sonido, retroceso
        // del arma en pantalla y retículo que se abre.
        onFire: () => {
          if (this.audio) this.audio.shoot();
          if (this.viewmodel) this.viewmodel.kick();
          this.hud.addFireSpread();
        },
        onReload: () => {
          if (this.audio) this.audio.reload();
          if (this.viewmodel) this.viewmodel.startReload(CONFIG.RELOAD_TIME_MS);
        }
      }),
      wolf: new WolfWeapon({
        fx,
        send: sendCombat,
        onClaw: () => {
          if (this.audio) this.audio.claw();
          if (this.viewmodel) this.viewmodel.clawSwipe();
        }
      })
    };

    /** Callbacks que instala main.js (avisos al jugador). */
    this.onNotice = null; // (title, text) => void
    this.onStatus = null; // (text, level) => void

    this._unbind = [];
    this._wire();
  }

  // ═══════════════════════ Cableado de eventos ═══════════════════════

  _wire() {
    const net = this.net;

    // — Eventos de host —
    this._keep(net.on('input', (e) => this._applyInput(e)));
    this._keep(net.on('peer-joined', ({ player }) => {
      const spawn = this.world.spawnPoints[player.id % this.world.spawnPoints.length];
      this._chars.set(player.id, { ...createCharacter(spawn), lastSeq: 0 });
      if (this.roundMgr) this.roundMgr.addPlayer(player.id);
      // El lobby del host refresca la lista con el próximo STATE
    }));
    this._keep(net.on('peer-left', ({ id }) => {
      const ch = this._chars.get(id);
      // Si se va EL LOBO, el Núcleo cae donde estaba: la oleada no se atasca
      if (this.roundMgr && ch && this.roundMgr.isWolf(id)) {
        this.roundMgr.dropCoreAt(ch.x, ch.z);
      }
      this._chars.delete(id);
      if (this.roundMgr) this.roundMgr.removePlayer(id);
      this._forms.delete(id);
    }));
    this._keep(net.on('status', (s) => {
      if (this.onStatus) this.onStatus(s.text, s.level);
    }));

    // — Eventos de cliente —
    this._keep(net.on('welcome', (m) => this._onWelcome(m)));
    this._keep(net.on('message', ({ id, msg }) => this._onNetMessage(id, msg)));
    this._keep(net.on('host-closed', () => {
      this._notify(
        'El anfitrión cerró la partida',
        'La sesión terminó porque el anfitrión salió. Vuelve al menú para crear o buscar otra sala.'
      );
      this.leave();
    }));
  }

  _keep(unsubscribe) {
    this._unbind.push(unsubscribe);
  }

  _notify(title, text) {
    if (this.onNotice) this.onNotice(title, text);
  }

  /** Estimación del RELOJ DEL HOST con el reloj local. */
  _hostNow() {
    return this.mode === 'client' && this.sync && this.sync.ready
      ? this.sync.now()
      : performance.now();
  }

  /** Difunde un efecto del árbitro: a la red Y a la vista local del host. */
  _emitCombat(msg) {
    if (this.mode === 'host') this.net.broadcast(msg);
    this._onMessage(msg);
  }

  // ═══════════════════════ Arranque de modos ═══════════════════════

  /**
   * Modo exploración sin red: pista de pruebas de la Fase 3 (el Núcleo del
   * pedestal transforma de verdad; disparar y zarpar funcionan sin rivales).
   */
  startSolo() {
    this.mode = 'solo';
    this.myId = 0;
    this.playing = true;
    this._spawnLocal(this.world.spawnPoints[0]);
    this.player.physics.speedFn = this.speedFn;
    this.player.speedFn = this.speedFn;

    // Primero el estado común (que oculta el Núcleo), DESPUÉS el árbitro:
    // su reset() emite CORE_SPAWN y el Núcleo debe quedar visible
    this._startPlayingCommon(null);

    this.roundMgr = new RoundManager({
      world: this.world,
      chars: this._chars,
      emit: (m) => this._onMessage(m),
      mode: 'solo'
    });
    this.roundMgr.reset([{ id: 0, name: 'Tú', color: 0xd8dee9 }], performance.now());

    debug.log('[session] modo Explorar con combate de pruebas');
  }

  /**
   * El anfitrión entra en su lobby (tras net.startHost).
   * @param {string} code código de la sala
   */
  becomeHost(code) {
    void code;
    this.mode = 'host';
    this.myId = 0;
    this.playing = false;
    this.roster = this.net.roster;
    this._spawnLocal(this.world.spawnPoints[0]);
    this.player.physics.speedFn = this.speedFn;
    this.player.speedFn = this.speedFn;

    this.roundMgr = new RoundManager({
      world: this.world,
      chars: this._chars,
      emit: (m) => this._emitCombat(m),
      mode: 'round'
    });
    this.roundMgr.addPlayer(0);
    this._startTick(CONFIG.LOBBY_TICK_HZ);
    this.machine.go('lobby');
  }

  /**
   * Un cliente fue aceptado (tras net.join → WELCOME).
   * @param {object} m mensaje WELCOME
   */
  _onWelcome(m) {
    this.mode = 'client';
    this.myId = m.you;
    this.roster = m.roster;
    this.playing = false;

    // Física local → predicción con reconciliación
    this.prediction = new PredictedController({
      world: this.world,
      speedFn: this.speedFn
    });
    this.player.speedFn = this.speedFn;
    const my = m.roster.find((p) => p.id === m.you);
    this.player.setPhysics(this.prediction);
    this._spawnLocal(this.world.spawnPoints[m.you % this.world.spawnPoints.length]);

    // Reloj compartido: PING/PONG para interpolar en el tiempo del host
    this.sync = new TimeSync(() => this.net.sendToHost(msgPing(performance.now())));
    this.net.sendToHost(msgPing(performance.now())); // primera muestra YA

    // Color propio (guardado SIN remapear: el remapeo daltonismo es local
    // y reversible al desactivar el ajuste)
    this._myColor = my ? my.color : 0xd8dee9;
    this.player.avatar.setColor(settings.mapColor(this._myColor));

    this.machine.go('lobby');
  }

  /**
   * El anfitrión lanza la ronda (botón Empezar del lobby).
   */
  startRound() {
    if (this.mode !== 'host') return;
    const now = performance.now();
    const spawns = {};
    this.net.roster.forEach((p, i) => {
      spawns[p.id] = this.world.spawnPoints[i % this.world.spawnPoints.length];
    });

    // Teleporta a todos (el propio y los simulados)
    for (const p of this.net.roster) {
      const sp = spawns[p.id];
      if (p.id === 0) {
        this._spawnLocal(sp); // también re-liga _chars[0] (corregido en Fase 3)
      } else {
        const ch = this._chars.get(p.id);
        if (ch) {
          const fresh = createCharacter(sp);
          Object.assign(ch, fresh, { lastSeq: ch.lastSeq });
        }
      }
    }

    this.net.gameInProgress = true;
    this.playing = true;
    this._startTick(CONFIG.TICK_RATE_HZ);

    // Orden garantizado por canal fiable: primero la ronda, luego el Núcleo
    const start = msgRoundStart({ spawns, endsAt: now + CONFIG.ROUND_DURATION_MS });
    this.net.broadcast(start);
    this._onRoundStart(start);

    this.roundMgr.reset(this.net.roster, now); // emite CORE_SPAWN (pedestal)
    this.machine.go('playing');
    debug.log('[session] ronda iniciada');
  }

  /** Teleporta al jugador local Y mantiene viva la referencia del árbitro. */
  _spawnLocal(point) {
    this.player.spawnAt(point);
    this._chars.set(this.myId, this.player.character);
  }

  /** Estado común al empezar a jugar (ronda o exploración). */
  _startPlayingCommon(endsAt) {
    this.playing = true; // cliente incluido: sin esto no enviaría INPUT
    this._roundEndsAt = endsAt || 0;
    this._formWolf = false;
    this._deadLocal = false;
    this.player.alive = true;
    this.player.avatar.setDead(false);
    this.transform.reset();
    if (this.viewmodel) this.viewmodel.reset();
    this.weapons.hunter.reset();
    this.weapons.wolf.reset();
    this._liveKills = 0;
    this._liveWolfMs = 0;
    this._forms.clear();
    this.beastCore.hide();
    this.fx.clear();
    this.hud.reset();
    this.hud.setRoundTime(endsAt || null);
    this.machine.go('playing');
  }

  // ═══════════════════════ Bucle por frame ═══════════════════════

  /**
   * Avanza la sesión un frame (lo llama el bucle de main.js SIEMPRE).
   * @param {number} dt delta time en segundos
   */
  update(dt) {
    // El jugador local solo se mueve con la partida en marcha (así el
    // teclado WASD no mueve nada detrás de los menús).
    if (this.playing) {
      this.player.update(dt);
      this._updateWeapons(dt);
      this._updateFeel();
    }

    // Brazos en 1ª persona (Fase 4): se actualiza SIEMPRE porque él
    // mismo decide si toca verse (menú/3ª persona/muerto = oculto).
    if (this.viewmodel) {
      const p = this.player;
      const dyaw = p.yaw - this._lastYaw;
      const dpitch = p.pitch - this._lastPitch;
      this._lastYaw = p.yaw;
      this._lastPitch = p.pitch;
      this.viewmodel.update(dt, {
        playing: this.playing,
        alive: p.alive,
        blend: p.rig.blend,
        moveMag: this.playing ? p.inputMag : 0,
        grounded: !!p.character.grounded,
        dyaw,
        dpitch
      });
    }

    if (this.mode === 'client' && this.playing) {
      // Envío de INPUT a cadencia fija + reloj
      this._sendAcc += dt;
      const period = 1 / CONFIG.INPUT_SEND_HZ;
      if (this._sendAcc >= period) {
        this._sendAcc %= period;
        const pkt = this.prediction.flush();
        if (pkt) this.net.sendToHost(msgInput(pkt.seq, pkt.steps));
      }
      this.sync.update(CONFIG.PING_INTERVAL_MS);
    }

    // Árbitro local (solo el host lo tiene en su tick de red)
    if (this.mode === 'solo' && this.roundMgr) {
      this.roundMgr.tick(performance.now());
    }

    // Remotos interpolados (host en reloj propio; cliente en reloj sincronizado)
    if (this.playing || this.machine.current === 'lobby') {
      if (this.mode === 'host') {
        this.remotes.render(performance.now() - CONFIG.INTERP_DELAY_MS, dt);
      } else if (this.mode === 'client' && this.sync && this.sync.ready) {
        this.remotes.render(this.sync.now() - CONFIG.INTERP_DELAY_MS, dt);
      }
    }

    // Vistas de combate (baratas: casi siempre no hacen nada)
    this.beastCore.update(dt);
    this.fx.update(dt);
    this.hud.update(dt, this.playing ? this.player.inputMag : 0);
    if (this.playing) this._updateCombatHud(dt);
  }

  /**
   * Feel del frame (Fase 4): saltos y aterrizajes con su sonido, a partir
   * de las transiciones de `grounded` del personaje compartido.
   */
  _updateFeel() {
    const ch = this.player.character;
    const g = !!ch.grounded;
    if (g && !this._wasGrounded) {
      if (this.audio) this.audio.land();
    } else if (!g && this._wasGrounded && ch.velocityY > 0.5) {
      if (this.audio) this.audio.jump();
    }
    this._wasGrounded = g;
  }

  /**
   * Paneo+ganancia de una posición del mundo para el oído del jugador.
   * @param {number} x,y,z posición del evento
   * @returns {{pan:number, gain:number}}
   */
  _spatial(x, y, z) {
    if (!this.audio) return { pan: 0, gain: 0 };
    const ear = this.player.getEyePosition(_ear);
    return this.audio.spatial(x, y, z, ear, this.player.yaw);
  }

  /** Armas locales: recarga pedida + disparo/zarpazo según la forma. */
  _updateWeapons(dt) {
    const input = this.player.input;
    const now = performance.now();
    const canAct = this.player.alive;

    if (input && input.consumeReload() && !this._formWolf) {
      this.weapons.hunter.reload(now);
    }

    const fireHeld = !!(input && input.fireHeld && canAct);
    if (this._formWolf) {
      const ch = this.player.character;
      this.weapons.wolf.update(dt, now, {
        fireHeld,
        x: ch.x,
        z: ch.z,
        yaw: ch.yaw
      });
    } else {
      const eye = this.player.getEyePosition();
      const yaw = this.player.yaw;
      const pitch = this.player.pitch;
      const cp = Math.cos(pitch);
      _view.set(-Math.sin(yaw) * cp, Math.sin(pitch), -Math.cos(yaw) * cp);
      this.weapons.hunter.update(dt, now, {
        fireHeld,
        eye,
        dir: _view,
        targets: this._assistTargets()
      });
    }
  }

  /** Objetivos vivos para el aim assist (posiciones interpoladas). */
  _assistTargets() {
    this._targets.length = 0;
    for (const rec of this.remotes.map.values()) {
      const buf = rec.buffer;
      const last = buf[buf.length - 1];
      if (!last || last.dead) continue;
      this._targets.push({ pos: rec.avatar.group.position, alive: true });
    }
    return this._targets;
  }

  /** Temporizadores y marcador en vivo del HUD. */
  _updateCombatHud(dt) {
    const nowHost = this._hostNow();

    this.hud.setRoundTime(this._roundEndsAt ? this._roundEndsAt - nowHost : null);

    const wolfRem = this.transform.remaining(nowHost);
    this.hud.setWolfTime(this._deadLocal ? null : wolfRem);
    if (this.transform.wolf && !this._deadLocal) this._liveWolfMs += dt * 1000;

    this.hud.setScore(
      this._liveKills * CONFIG.SCORE_PER_KILL +
        Math.floor(this._liveWolfMs / 1000) * CONFIG.SCORE_PER_WOLF_SECOND
    );

    if (this._deadLocal && this._respawnEndsHost) {
      this.hud.setRespawnCountdown(this._respawnEndsHost - nowHost);
    }
  }

  // ═══════════════════════ Host: simulación y tick ═══════════════════════

  /** Aplica un INPUT validado al personaje del cliente correspondiente. */
  _applyInput({ id, msg }) {
    const ch = this._chars.get(id);
    if (!ch) return;
    // Velocidad según la forma AUTORITATIVA (la carrera del lobo)
    const speed = this.roundMgr && this.roundMgr.isWolf(id)
      ? CONFIG.WOLF_SPEED
      : CONFIG.HUNTER_SPEED;
    for (const s of msg.steps) {
      stepCharacter(ch, s, s.dt, this.world, speed);
    }
    ch.lastSeq = msg.seq;
  }

  /** (Re)arranca el tick de difusión de STATE con la frecuencia indicada. */
  _startTick(hz) {
    if (this._tickTimer) clearInterval(this._tickTimer);
    this._tickHz = hz;
    this._tickTimer = setInterval(() => this._tick(), 1000 / hz);
  }

  /** Construye y difunde un STATE; también alimenta los remotos locales. */
  _tick() {
    if (this.net.role !== 'host') return;
    const now = performance.now();
    if (this.roundMgr && this.playing) this.roundMgr.tick(now);
    const players = this._buildPlayers(now);
    const paused = document.hidden;

    // Estado base común + 'you' personalizado por cliente
    const base = { time: now, players, paused };
    for (const [id] of this.net.connections()) {
      const ch = this._chars.get(id);
      if (!ch) continue;
      const st = this.roundMgr ? this.roundMgr.stateOf(id, now) : null;
      const am = this.roundMgr ? this.roundMgr.ammoOf(id) : null;
      this.net.sendTo(id, msgState({
        ...base,
        you: {
          seq: ch.lastSeq,
          x: ch.x,
          y: ch.y,
          z: ch.z,
          hp: st ? st.hp : CONFIG.HUNTER_HP,
          wolf: st ? st.wolf : false,
          dead: st ? st.dead : false,
          mag: am ? am.mag : CONFIG.MAGAZINE_SIZE,
          reserve: am ? am.reserve : CONFIG.RESERVE_AMMO
        }
      }));
    }

    // El anfitrión también interpola a sus clientes (con su propio reloj)
    this.remotes.updateFromState(players, 0, now);
  }

  /** players[] del STATE a partir del roster y los personajes simulados. */
  _buildPlayers(now) {
    return this.net.roster.map((p) => {
      const ch = this._chars.get(p.id) || this.player.character;
      const st = this.roundMgr ? this.roundMgr.stateOf(p.id, now) : null;
      return {
        id: p.id,
        name: p.name,
        color: p.color,
        x: ch.x,
        y: ch.y,
        z: ch.z,
        yaw: ch.yaw,
        wolf: st ? st.wolf : false,
        hp: st ? st.hp : CONFIG.HUNTER_HP,
        dead: st ? st.dead : false,
        inv: st ? st.inv : false
      };
    });
  }

  // ═══════════════════════ Enrutado de mensajes ═══════════════════════

  /**
   * Todo lo que llega por la red al juego. El host despacha aquí las
   * PETICIONES de combate de sus clientes; el resto es presentación.
   * @param {number} id id de la conexión (solo tiene sentido en el host)
   * @param {object} msg mensaje ya con forma válida
   */
  _onNetMessage(id, msg) {
    if (this.mode === 'host') {
      switch (msg.t) {
        case MSG.SHOOT:
          if (validateShoot(msg) && this.roundMgr) {
            this.roundMgr.handleShoot(id, msg, performance.now());
          }
          return;
        case MSG.CLAW:
          if (validateSimple(msg) && this.roundMgr) {
            this.roundMgr.handleClaw(id, msg, performance.now());
          }
          return;
        case MSG.RELOAD:
          if (validateSimple(msg) && this.roundMgr) {
            this.roundMgr.handleReload(id, msg, performance.now());
          }
          return;
        default:
          break;
      }
    }
    this._onMessage(msg);
  }

  /**
   * Presentación: mensajes de efecto del árbitro (todos los modos los
   * reciben por aquí, incluido el host con los suyos propios).
   * @param {object} msg
   */
  _onMessage(msg) {
    switch (msg.t) {
      case MSG.STATE:
        this._onState(msg);
        return;
      case MSG.ROUND_START:
        this._onRoundStart(msg);
        return;
      case MSG.PONG:
        if (this.sync) this.sync.onPong(msg);
        return;
      case MSG.SHOOT_FX:
        this.fx.tracer(msg.ox, msg.oy, msg.oz, msg.ex, msg.ey, msg.ez);
        // El disparo propio ya sonó al apretar el gatillo; el de un
        // rival se oye con la distancia y el lado (Fase 4).
        if (this.audio && msg.id !== this.myId) {
          this.audio.shootRemote(this._spatial(msg.ox, msg.oy, msg.oz));
        }
        return;
      case MSG.CLAW_FX:
        if (msg.id !== this.myId) {
          const av = this.remotes.getAvatar(msg.id);
          if (av) {
            this.fx.claw(av.group.position.x, av.group.position.z, av.group.rotation.y);
            if (this.audio) {
              const p = av.group.position;
              this.audio.clawRemote(this._spatial(p.x, p.y + 0.9, p.z));
            }
          }
        }
        return;
      case MSG.HIT:
        this._onHit(msg);
        return;
      case MSG.DEATH:
        this._onDeath(msg);
        return;
      case MSG.RESPAWN:
        this._onRespawn(msg);
        return;
      case MSG.CORE_SPAWN:
        this.beastCore.spawnAt(msg.x, msg.z);
        if (this.audio) this.audio.coreSpawn(this._spatial(msg.x, 1.2, msg.z));
        return;
      case MSG.CORE_PICKUP:
        this.beastCore.pickup();
        this._feedCorePickup(msg.id);
        if (msg.id === this.myId) {
          if (this.audio) this.audio.howl(); // EL aullido del lobo nuevo
          settings.vibrate(40);
        } else if (this.audio) {
          this.audio.pickupOther();
        }
        return;
      case MSG.TRANSFORM:
        this._onTransform(msg);
        return;
      case MSG.ROUND_END:
        this._onRoundEnd(msg);
        return;
      default:
        debug.log('[session] mensaje sin tratamiento:', msg.t);
    }
  }

  // ═══════════════════════ Efectos de combate (presentación) ═══════════════════════

  /** Daño aplicado: HUD de la víctima, destello del avatar, marcador del autor. */
  _onHit(m) {
    const maxHp = m.victim === this.myId && this._formWolf ? CONFIG.WOLF_HP : CONFIG.HUNTER_HP;

    if (m.victim === this.myId) {
      this.hud.setHp(m.hp, maxHp);
      // m.dir ya es el rumbo víctima→agresor: relativo a mi mirada
      this.hud.damage(m.dir - this.player.yaw);
      if (this.audio) this.audio.hurt();
      settings.vibrate(45); // golpe háptico corto
    } else {
      const av = this.remotes.getAvatar(m.victim);
      if (av) av.flashHit();
    }

    if (m.by === this.myId && m.victim !== this.myId) {
      this.hud.hitMark(m.hp <= 0);
      if (this.audio) this.audio.hitConfirm(); // "toc" de impacto
    }
  }

  /** Una muerte: registro, pose de caído y estado local si es la mía. */
  _onDeath(m) {
    if (m.by !== -1 && m.by !== m.id) {
      if (m.by === this.myId) {
        this.hud.feedLine(`Tú ${this._formWolf ? 'destrozaste a' : 'abatiste a'} ${this._nameOf(m.id)}`);
      } else {
        const killerWolf = !!this._forms.get(m.by);
        this.hud.feedKill(this._nameOf(m.by), this._nameOf(m.id), killerWolf);
      }
    }

    if (m.by === this.myId && m.by !== m.id) {
      this._liveKills += 1;
      if (this.audio) this.audio.kill(); // recompensa audible
      settings.vibrate(25);
    }

    if (m.id === this.myId) {
      this._deadLocal = true;
      this.player.alive = false;
      this.player.avatar.setDead(true);
      this._respawnEndsHost = this._hostNow() + CONFIG.RESPAWN_DELAY_MS;
      this.hud.showDeath(this._nameOf(m.by));
      this.hud.setWolfTime(null);
      // Cámara de muerte: ver el propio cuerpo desde fuera (sin persistir)
      this.player.rig.setMode('third', true, false);
      if (this.audio) this.audio.death();
      settings.vibrate([90, 60, 120]);
      debug.log('[session] has caído');
    } else {
      const av = this.remotes.getAvatar(m.id);
      if (av) av.setDead(true);
      this._forms.delete(m.id);
    }
  }

  /** Reaparición: teleport + vuelta a la vida (y a la forma Hunter). */
  _onRespawn(m) {
    if (m.id === this.myId) {
      this._deadLocal = false;
      this._formWolf = false;
      this._respawnEndsHost = 0;
      this.player.alive = true;
      this.player.avatar.setDead(false);
      this._spawnLocal({ x: m.x, z: m.z, yaw: m.yaw });
      this.transform.reset();
      this.weapons.hunter.reset();
      this.weapons.wolf.reset();
      if (this.viewmodel) this.viewmodel.reset();
      this.hud.hideDeath();
      this.hud.setHp(CONFIG.HUNTER_HP, CONFIG.HUNTER_HP);
      if (this.audio) this.audio.respawn();
    } else {
      const av = this.remotes.getAvatar(m.id);
      if (av) av.setDead(false);
      this._forms.set(m.id, false);
    }
  }

  /** Transformación Hunter↔Wolf de cualquiera. */
  _onTransform(m) {
    this._forms.set(m.id, !!m.wolf);

    if (m.id !== this.myId) {
      const av = this.remotes.getAvatar(m.id);
      if (av) {
        av.setWolf(!!m.wolf);
        if (this.audio) {
          const p = av.group.position;
          this.audio.remoteTransform(this._spatial(p.x, p.y + 0.9, p.z));
        }
      }
      return;
    }

    this._formWolf = !!m.wolf;
    this.transform.apply(!!m.wolf, m.endsAt || 0);
    if (this.viewmodel) this.viewmodel.setForm(!!m.wolf);
    // El momento grande de la Cacería: titular + destello + rugido (Fase 4)
    this.hud.transformBanner(!!m.wolf);
    if (this.audio) {
      if (m.wolf) this.audio.transformTo();
      else this.audio.transformBack();
    }
    settings.vibrate(70);
    // La velocidad cambia: resincroniza la predicción con el próximo STATE
    if (this.prediction) this.prediction.markResync();
    // El HUD de vida cambia de máximo
    this.hud.setHp(
      m.wolf ? CONFIG.WOLF_HP : CONFIG.HUNTER_HP,
      m.wolf ? CONFIG.WOLF_HP : CONFIG.HUNTER_HP
    );
    debug.log(`[session] transformación: ${m.wolf ? 'WOLF' : 'HUNTER'}`);
  }

  /** Fin de ronda: marcador y vuelta al lobby (botón del host o auto). */
  _onRoundEnd(m) {
    this._roundEndsAt = 0;
    this.roundMgr && this.roundMgr.stop();
    this.hud.setRoundTime(null);
    this.hud.setWolfTime(null);
    // En Explorar, el jugador local decide: mismo botón que el anfitrión
    this.hud.showScoreboard(m.scores || [], this.mode === 'host' || this.mode === 'solo');
    if (this.audio) this.audio.roundEnd(); // la "música" del marcador
    if (this._lobbyTimer) clearTimeout(this._lobbyTimer);
    this._lobbyTimer = setTimeout(
      () => this._endRoundToLobby(),
      CONFIG.SCOREBOARD_AUTO_MS
    );
    debug.log('[session] fin de ronda (marcador)');
  }

  /** Vuelta al lobby tras el marcador (idempotente). */
  _endRoundToLobby() {
    if (this._lobbyTimer) {
      clearTimeout(this._lobbyTimer);
      this._lobbyTimer = null;
    }
    if (this.machine.current !== 'playing') return;

    this.playing = false;
    this._formWolf = false;
    this._deadLocal = false;
    this.player.alive = true;
    this.player.avatar.setDead(false);
    this.transform.reset();
    if (this.viewmodel) this.viewmodel.reset();
    this.beastCore.hide();
    this.fx.clear();
    this.hud.clear();

    if (this.mode === 'host') {
      this.net.gameInProgress = false;
      this.roundMgr.clearCombat();
      this._startTick(CONFIG.LOBBY_TICK_HZ);
    }
    // Explorar no tiene lobby: el fin de ronda devuelve al menú
    if (this.mode === 'solo') {
      this.leave();
      return;
    }
    this.machine.go('lobby');
  }

  /**
   * El anfitrión pulsa "Volver al lobby" en el marcador: sale sin esperar
   * al temporizador automático (los clientes volverán con el suyo o con
   * la siguiente ROUND_START).
   */
  continueToLobby() {
    this._endRoundToLobby();
  }

  // ═══════════════════════ Cliente: STATE y ronda ═══════════════════════

  _onState(m) {
    this._lastStateAt = performance.now();
    this.roster = m.players;

    // Reconciliación con mi posición autoritativa (solo con la ronda en
    // marcha: en el lobby no hay predicción que corregir y el seq es 0)
    if (m.you && this.prediction && (this.playing || m.you.seq > 0)) {
      this.prediction.reconcile(m.you.seq, m.you.x, m.you.y, m.you.z);
    }

    // Red de seguridad de combate (los mensajes dedicados llegan antes)
    if (m.you) {
      const wolf = !!m.you.wolf;
      if (wolf !== this._formWolf) {
        this._onTransform({ id: this.myId, wolf, endsAt: 0 });
      }
      if (!!m.you.dead !== this._deadLocal) {
        if (m.you.dead) this._onDeath({ id: this.myId, by: -1, x: m.you.x, z: m.you.z });
        else this._onRespawn({ id: this.myId, x: m.you.x, z: m.you.z, yaw: 0 });
      }
      if (typeof m.you.hp === 'number') {
        this.hud.setHp(m.you.hp, wolf ? CONFIG.WOLF_HP : CONFIG.HUNTER_HP);
      }
      if (typeof m.you.mag === 'number') {
        this.weapons.hunter.syncFromState(m.you.mag, m.you.reserve, performance.now());
      }
    }

    // Remotos (buffer de interpolación)
    this.remotes.updateFromState(m.players, this.myId, m.time);

    // Aviso de anfitrión en segundo plano
    if (m.paused && !this._pausedNotice) {
      this._pausedNotice = true;
      this._notify(
        'Esperando al anfitrión…',
        'El anfitrión puso la app en segundo plano. La partida se reanuda sola cuando vuelva.'
      );
    } else if (!m.paused && this._pausedNotice) {
      this._pausedNotice = false;
      if (this.onNotice) this.onNotice(null); // señal de cerrar el aviso
    }
  }

  _onRoundStart(m) {
    if (this._lobbyTimer) {
      clearTimeout(this._lobbyTimer);
      this._lobbyTimer = null;
    }
    const sp = m.spawns && m.spawns[this.myId];
    // _spawnLocal (no player.spawnAt): re-liga la referencia del árbitro,
    // que player.spawnAt reemplaza por un objeto nuevo
    if (sp) this._spawnLocal(sp);
    this._startPlayingCommon(m.endsAt || 0);
    if (this.audio) this.audio.roundStart(); // llamada a la caza
  }

  // ═══════════════════════ Utilidades ═══════════════════════

  /** Nombre de un jugador (roster del host o del STATE del cliente). */
  _nameOf(id) {
    if (id === this.myId) return 'Tú';
    if (id === -1) return '';
    const list = this.mode === 'host' ? this.net.roster : this.roster;
    const p = list.find((e) => e.id === id);
    return p ? p.name : '¿?';
  }

  /** Línea del registro cuando alguien recoge el Núcleo. */
  _feedCorePickup(id) {
    if (id === this.myId) {
      this.hud.feedLine('¡Recogiste el Núcleo de Fiera!');
    } else {
      this.hud.feedLine(`${this._nameOf(id)} recogió el Núcleo`);
    }
  }

  // ═══════════════════════ Cierre ═══════════════════════

  /**
   * Abandona la sesión y vuelve al menú (anfitrión o cliente). Idempotente.
   * Si el anfitrión se va, los clientes reciben 'host-closed' por su lado.
   */
  leave() {
    if (this._lobbyTimer) {
      clearTimeout(this._lobbyTimer);
      this._lobbyTimer = null;
    }
    if (this._tickTimer) {
      clearInterval(this._tickTimer);
      this._tickTimer = null;
    }
    this._chars.clear();
    this.roundMgr = null;

    this.playing = false;
    this.mode = null;
    this.prediction = null;
    this.sync = null;
    this._pausedNotice = false;
    this._formWolf = false;
    this._deadLocal = false;
    this._respawnEndsHost = 0;
    this._roundEndsAt = 0;
    this._forms.clear();

    // Vistas de combate a cero
    this.transform.reset();
    if (this.viewmodel) this.viewmodel.reset();
    this.beastCore.hide();
    this.fx.clear();
    this.hud.clear();
    this.player.alive = true;
    this.player.avatar.setDead(false);

    // La física local vuelve al modo directo (sin reconciliación)
    if (!(this.player.physics instanceof DirectPhysics)) {
      this.player.setPhysics(new DirectPhysics(this.world, () => CONFIG.HUNTER_SPEED));
    }
    this.player.speedFn = () => CONFIG.HUNTER_SPEED;
    this._spawnLocalToMenu();
    this.remotes.clear();
    this.net.destroy();

    if (this.machine.current !== 'menu') this.machine.go('menu');
  }

  /** spawn de menú (id 0 en el mapa, sin árbitro). */
  _spawnLocalToMenu() {
    this.myId = 0;
    this.player.spawnAt(this.world.spawnPoints[0]);
  }

  /**
   * Repinta TODOS los colores con el modo daltonismo actual (Fase 4):
   * lo llama el menú de ajustes al conmutar el interruptor.
   */
  refreshColors() {
    this.player.avatar.setColor(settings.mapColor(this._myColor || 0xd8dee9));
    this.remotes.refreshColors();
  }

  /** Desuscribe eventos (fin del programa). */
  dispose() {
    for (const off of this._unbind) off();
    this._unbind.length = 0;
    if (this._tickTimer) clearInterval(this._tickTimer);
  }

  // ═══════════════════════ Info para HUD / depuración ═══════════════════════

  /**
   * Resumen para el chip de red del HUD.
   * @returns {{role:string, code:string, players:number, rtt:number}}
   */
  getHudInfo() {
    const players = this.mode === 'host'
      ? this.net.roster.length
      : this.roster.filter((p) => p.id !== this.myId).length + 1;
    return {
      role: this.mode || '—',
      code: this.net.code,
      players,
      rtt: this.sync ? Math.round(this.sync.rtt) : 0
    };
  }

  /** Detalle para el overlay de depuración de red (?netdebug). */
  getNetDebug() {
    return {
      ...this.net.getStats(),
      mode: this.mode,
      rtt: this.sync ? Math.round(this.sync.rtt) : 0,
      offset: this.sync ? Math.round(this.sync.offset) : 0,
      pendingInputs: this.prediction ? this.prediction.stats.pending : 0,
      hardReconciles: this.prediction ? this.prediction.stats.hardReconciles : 0,
      remoteAvatars: this.remotes.count,
      tickHz: this._tickHz,
      roundActive: this.roundMgr ? this.roundMgr.roundActive : false,
      coreActive: this.roundMgr ? this.roundMgr.core.active : false
    };
  }

  /** Marcador completo (para el gancho de depuración __wolf). */
  get scores() {
    return this.roundMgr ? this.roundMgr.score.build() : [];
  }
}

// ScoreBoard se reexporta para el gancho de depuración de main.js
export { ScoreBoard };
