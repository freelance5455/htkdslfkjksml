/**
 * WOLF-HUNTER · audio.js (Fase 4)
 * TODO el sonido del juego, SINTETIZADO con WebAudio: cero descargas y
 * el presupuesto de assets queda intacto (la voz del juego sale de
 * osciladores y ruido blanco, no de archivos).
 *
 *  · Un AudioContext perezoso: se crea en el PRIMER gesto del jugador
 *    (política de autoplay de iOS/Android) y a partir de ahí todo suena.
 *  · Tres canales con volumen independiente: master → (sfx | ui).
 *  · Efectos remotos ESPACIALIZADOS baratos: ganancia por distancia y
 *    paneo estéreo por ángulo (sin PannerNode: dos multiplicaciones).
 *  · Los sonidos son recetas cortas (osciladores con envolventes y un
 *    buffer de ruido compartido); nada de audio posicional por frame:
 *    todo se dispara por eventos, así el bucle de render no paga nada.
 *
 * Este módulo NUNCA lanza excepción hacia fuera: si no hay WebAudio el
 * juego sigue siendo 100 % jugable en silencio.
 */

import { CONFIG } from '../config.js';

/** @param {number} v @param {number} min @param {number} max @returns {number} */
function clamp(v, min, max) {
  return v < min ? min : v > max ? max : v;
}

export class GameAudio {
  constructor() {
    /** @type {AudioContext|null} */
    this.ctx = null;
    this._master = null;
    this._sfx = null;
    this._ui = null;
    this._noiseBuf = null;
    this._vol = { master: 0.8, sfx: 1, ui: 0.8 };

    // El gesto que desbloquea el audio (main.js lo engancha)
    this._unlockBound = () => this.unlock();
  }

  /** Engancha el desbloqueo al primer gesto (idempotente, se auto-limpia). */
  attachUnlock() {
    document.addEventListener('pointerdown', this._unlockBound, { capture: true });
    document.addEventListener('touchend', this._unlockBound, { capture: true });
  }

  /** @returns {boolean} hay contexto y está corriendo */
  get unlocked() {
    return !!this.ctx && this.ctx.state === 'running';
  }

  /**
   * Crea/reanuda el contexto. Llamar DENTRO de un gesto del usuario.
   * Si el navegador no tiene WebAudio, queda en silencio sin errores.
   */
  unlock() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      try {
        this.ctx = new AC();
        this._master = this.ctx.createGain();
        this._master.connect(this.ctx.destination);
        this._sfx = this.ctx.createGain();
        this._sfx.connect(this._master);
        this._ui = this.ctx.createGain();
        this._ui.connect(this._master);

        // Ruido blanco compartido (1 s): base de disparos, zarpazos y viento
        const len = Math.floor(this.ctx.sampleRate);
        this._noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
        const ch = this._noiseBuf.getChannelData(0);
        for (let i = 0; i < len; i++) ch[i] = Math.random() * 2 - 1;

        this._applyVolumes();
        document.removeEventListener('pointerdown', this._unlockBound, true);
        document.removeEventListener('touchend', this._unlockBound, true);
      } catch (e) {
        this.ctx = null;
        return;
      }
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => { /* sin permiso: silencio */ });
    }
  }

  /**
   * Volúmenes por canal (0..1). Se pueden cambiar sin contexto: se
   * guardan y se aplican cuando exista.
   * @param {{master?:number, sfx?:number, ui?:number}} v
   */
  setVolumes(v) {
    if (typeof v.master === 'number') this._vol.master = clamp(v.master, 0, 1);
    if (typeof v.sfx === 'number') this._vol.sfx = clamp(v.sfx, 0, 1);
    if (typeof v.ui === 'number') this._vol.ui = clamp(v.ui, 0, 1);
    this._applyVolumes();
  }

  _applyVolumes() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    try {
      this._master.gain.setTargetAtTime(this._vol.master, t, 0.03);
      this._sfx.gain.setTargetAtTime(this._vol.sfx, t, 0.03);
      this._ui.gain.setTargetAtTime(this._vol.ui, t, 0.03);
    } catch (e) {
      /* algún navegador viejo sin setTargetAtTime */
    }
  }

  /** @returns {number} instante actual del contexto (s) */
  get _t() {
    return this.ctx.currentTime;
  }

  /**
   * Cadena de salida de un sonido: gain → (pan) → canal.
   * @param {'sfx'|'ui'} channel
   * @param {number} gain volumen pico del sonido (se multiplica por el canal)
   * @param {number} [pan=-2] paneo -1..1; < -1 = sin paneo (centro)
   * @returns {?GainNode} nodo de entrada, o null si no hay contexto
   */
  _out(channel, gain, pan) {
    if (!this.ctx) return null;
    const g = this.ctx.createGain();
    g.gain.value = gain;
    let node = g;
    if (pan !== undefined && pan > -1.01 && pan < 1.01 && this.ctx.createStereoPanner) {
      try {
        const p = this.ctx.createStereoPanner();
        p.pan.value = clamp(pan, -1, 1);
        node.connect(p);
        node = p;
      } catch (e) {
        /* sin paneo estéreo: suena al centro */
      }
    }
    node.connect(channel === 'ui' ? this._ui : this._sfx);
    return g;
  }

  /**
   * Un oscilador con envolvente de ataque/decay y glissando opcional.
   * @param {object} o {type, from, to?, dur, gain, channel, pan?, at?, attack?}
   */
  _osc(o) {
    const t0 = this._t + (o.at || 0);
    const out = this._out(o.channel || 'sfx', o.gain, o.pan);
    if (!out) return;
    const osc = this.ctx.createOscillator();
    osc.type = o.type || 'sine';
    osc.frequency.setValueAtTime(Math.max(20, o.from), t0);
    if (o.to && o.to !== o.from) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(20, o.to), t0 + o.dur);
    }
    const a = o.attack || 0.005;
    out.gain.setValueAtTime(0.0001, t0);
    out.gain.exponentialRampToValueAtTime(Math.max(0.0002, o.gain), t0 + a);
    out.gain.exponentialRampToValueAtTime(0.0002, t0 + o.dur);
    osc.connect(out);
    osc.start(t0);
    osc.stop(t0 + o.dur + 0.02);
  }

  /**
   * Ráfaga de ruido filtrada con barrido de frecuencia.
   * @param {object} o {dur, gain, type?, from, to?, q?, channel, pan?, at?}
   */
  _noise(o) {
    const t0 = this._t + (o.at || 0);
    const out = this._out(o.channel || 'sfx', o.gain, o.pan);
    if (!out) return;
    const src = this.ctx.createBufferSource();
    src.buffer = this._noiseBuf;
    src.loop = true;
    src.playbackRate.value = 0.9 + Math.random() * 0.2; // cada ráfaga suena distinta
    const f = this.ctx.createBiquadFilter();
    f.type = o.type || 'bandpass';
    f.frequency.setValueAtTime(Math.max(40, o.from), t0);
    if (o.to && o.to !== o.from) {
      f.frequency.exponentialRampToValueAtTime(Math.max(40, o.to), t0 + o.dur);
    }
    f.Q.value = o.q || 1;
    out.gain.setValueAtTime(0.0001, t0);
    out.gain.exponentialRampToValueAtTime(Math.max(0.0002, o.gain), t0 + (o.attack || 0.006));
    out.gain.exponentialRampToValueAtTime(0.0002, t0 + o.dur);
    src.connect(f);
    f.connect(out);
    src.start(t0);
    src.stop(t0 + o.dur + 0.02);
  }

  /**
   * Paneo y ganancia de una fuente 3D respecto al jugador local.
   * @param {number} x,y,z posición del evento en el mundo
   * @param {{x:number,y:number,z:number}} ear ojos del oyente
   * @param {number} yaw orientación del oyente (rad)
   * @returns {{pan:number, gain:number}} gain 0..1 (0 = inaudible)
   */
  spatial(x, y, z, ear, yaw) {
    const dx = x - ear.x;
    const dy = y - ear.y;
    const dz = z - ear.z;
    const dist = Math.hypot(dx, dy, dz);
    if (dist > CONFIG.AUDIO_MAX_DIST_M) return { pan: 0, gain: 0 };
    const atten = clamp(1 - dist / CONFIG.AUDIO_MAX_DIST_M, 0, 1);
    const gain = Math.pow(atten, 1.35) * 0.85 + 0.05;
    // Proyección sobre el vector "derecha" del oyente (misma convención que camera.js)
    const rx = Math.cos(yaw);
    const rz = -Math.sin(yaw);
    const pan = dist > 0.01 ? clamp((dx * rx + dz * rz) / dist, -1, 1) * CONFIG.AUDIO_PAN_MAX : 0;
    return { pan, gain };
  }

  // ═════════════════════ Combate ═════════════════════

  /** Disparo propio (siempre a tope: es la acción que manda). */
  shoot() {
    if (!this.unlocked) return;
    const d = 0.9 + Math.random() * 0.2; // micro-variación: no suena a metrónomo
    this._noise({ dur: 0.07, gain: 0.5 * d, from: 2400, to: 800, q: 0.8 });
    this._osc({ type: 'square', from: 160 * d, to: 95, dur: 0.09, gain: 0.3 });
    this._osc({ type: 'sine', from: 58, to: 42, dur: 0.06, gain: 0.3 });
  }

  /**
   * Disparo de un rival (más apagado y filtrado con la distancia).
   * @param {{pan:number, gain:number}} s salida de spatial()
   */
  shootRemote(s) {
    if (!this.unlocked || s.gain <= 0.01) return;
    const lp = 500 + 3300 * s.gain; // lejos = apagado y sordo
    this._noise({ dur: 0.08, gain: 0.42 * s.gain, from: lp, to: lp * 0.35, q: 0.7, pan: s.pan });
    this._osc({ type: 'square', from: 130, to: 80, dur: 0.08, gain: 0.2 * s.gain, pan: s.pan });
  }

  /** Zarpazo propio. */
  claw() {
    if (!this.unlocked) return;
    this._noise({ dur: 0.17, gain: 0.42, from: 420, to: 2900, q: 1.4, attack: 0.03 });
    this._osc({ type: 'sine', from: 90, to: 58, dur: 0.13, gain: 0.2 });
  }

  /** Zarpazo de un rival. @param {{pan:number, gain:number}} s */
  clawRemote(s) {
    if (!this.unlocked || s.gain <= 0.01) return;
    this._noise({ dur: 0.18, gain: 0.3 * s.gain, from: 350, to: 2200 * s.gain + 500, q: 1.4, pan: s.pan });
  }

  /** Mi disparo impactó (confirmación seca, "toc"). */
  hitConfirm() {
    if (!this.unlocked) return;
    this._osc({ type: 'square', from: 1150, dur: 0.035, gain: 0.2 });
    this._osc({ type: 'square', from: 1560, dur: 0.03, gain: 0.16, at: 0.045 });
  }

  /** Mi disparo/zarpazo fue letal (campanita de recompensa). */
  kill() {
    if (!this.unlocked) return;
    this._osc({ type: 'sine', from: 740, dur: 0.14, gain: 0.26 });
    this._osc({ type: 'sine', from: 1110, dur: 0.22, gain: 0.22, at: 0.1 });
    this._osc({ type: 'triangle', from: 370, dur: 0.26, gain: 0.14 });
  }

  /** Recibo daño (golpe sordo). */
  hurt() {
    if (!this.unlocked) return;
    this._osc({ type: 'triangle', from: 175, to: 92, dur: 0.16, gain: 0.42 });
    this._noise({ type: 'lowpass', dur: 0.09, gain: 0.3, from: 320, to: 160 });
  }

  /** Muerte propia (caída descendente). */
  death() {
    if (!this.unlocked) return;
    this._osc({ type: 'sawtooth', from: 290, to: 68, dur: 0.6, gain: 0.28 });
    this._noise({ type: 'lowpass', dur: 0.45, gain: 0.26, from: 600, to: 130 });
  }

  /** Reaparición (listo para volver). */
  respawn() {
    if (!this.unlocked) return;
    this._osc({ type: 'sine', from: 520, to: 880, dur: 0.13, gain: 0.2 });
  }

  /**
   * Recarga: secuencia mecánica programada de una vez (sale-magazine,
   * entra-cargador, corredera) a lo largo de la duración real.
   * @param {number} [durMs=1500] duración de la recarga
   */
  reload(durMs = CONFIG.RELOAD_TIME_MS) {
    if (!this.unlocked) return;
    const d = durMs / 1000;
    this._noise({ type: 'highpass', dur: 0.03, gain: 0.28, from: 1900 }); // sale el cargador
    this._osc({ type: 'square', from: 230, dur: 0.025, gain: 0.16 });
    this._noise({ dur: 0.05, gain: 0.3, from: 850, q: 2, at: d * 0.45 }); // entra el nuevo
    this._osc({ type: 'square', from: 175, dur: 0.03, gain: 0.18, at: d * 0.45 });
    this._noise({ dur: 0.09, gain: 0.34, from: 1500, to: 550, q: 1.2, at: d * 0.88 }); // corredera
  }

  /** Salto propio (soplo discreto). */
  jump() {
    if (!this.unlocked) return;
    this._noise({ dur: 0.12, gain: 0.1, from: 480, to: 1200, q: 1.6, attack: 0.04 });
  }

  /** Aterrizaje (golpe suave). */
  land() {
    if (!this.unlocked) return;
    this._osc({ type: 'sine', from: 108, to: 70, dur: 0.09, gain: 0.2 });
    this._noise({ type: 'lowpass', dur: 0.07, gain: 0.14, from: 340, to: 170 });
  }

  // ═════════════════════ Transformación ═════════════════════

  /** Me convierto en lobo: rugido ascendente + gruñido grave. */
  transformTo() {
    if (!this.unlocked) return;
    this._osc({ type: 'sawtooth', from: 110, to: 440, dur: 0.55, gain: 0.22 });
    this._noise({ type: 'highpass', dur: 0.5, gain: 0.1, from: 300, to: 1800, attack: 0.2 });
    this._growl(0.62, 0.2);
  }

  /** Vuelvo a ser Hunter: desfase descendente, más suave. */
  transformBack() {
    if (!this.unlocked) return;
    this._osc({ type: 'sawtooth', from: 380, to: 130, dur: 0.45, gain: 0.16 });
    this._noise({ type: 'lowpass', dur: 0.4, gain: 0.12, from: 900, to: 220, attack: 0.06 });
  }

  /** Gruñido con trémolo (modula la ganancia a 26 Hz). */
  _growl(dur, gain) {
    const t0 = this._t;
    const out = this._out('sfx', gain);
    if (!out) return;
    const osc = this.ctx.createOscillator();
    osc.type = 'square';
    osc.frequency.setValueAtTime(64, t0);
    osc.frequency.linearRampToValueAtTime(52, t0 + dur);
    const lfo = this.ctx.createOscillator();
    lfo.frequency.value = 26;
    const lfoGain = this.ctx.createGain();
    lfoGain.gain.value = gain * 0.6;
    out.gain.setValueAtTime(0.0001, t0);
    out.gain.exponentialRampToValueAtTime(gain, t0 + 0.05);
    out.gain.exponentialRampToValueAtTime(0.0002, t0 + dur);
    lfo.connect(lfoGain);
    lfoGain.connect(out.gain);
    osc.connect(out);
    osc.start(t0);
    lfo.start(t0);
    osc.stop(t0 + dur + 0.02);
    lfo.stop(t0 + dur + 0.02);
  }

  /**
   * EL AULLIDO: la voz del lobo al recoger el Núcleo. Dos senos
   * desafinados con vibrato, glissando de subida y caída, y eco de
   * cañón (dos retardos realimentados). 1,4 s de gloria.
   */
  howl() {
    if (!this.unlocked) return;
    const t0 = this._t;
    const dur = 1.4;
    const out = this._out('sfx', 0.3);
    if (!out) return;

    // Eco: dos retardos con realimentación cruzada
    const delay = this.ctx.createDelay(0.6);
    delay.delayTime.value = 0.21;
    const fb = this.ctx.createGain();
    fb.gain.value = 0.34;
    const wet = this.ctx.createGain();
    wet.gain.value = 0.5;
    out.connect(delay);
    delay.connect(fb);
    fb.connect(delay);
    delay.connect(wet);
    wet.connect(this._sfx);

    const lp = this.ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 1500;
    lp.connect(out);

    for (const detune of [0, 5]) {
      const osc = this.ctx.createOscillator();
      osc.type = 'sine';
      // Subida (0.34 s) → sostén → caída (0.5 s)
      osc.frequency.setValueAtTime(370 + detune, t0);
      osc.frequency.exponentialRampToValueAtTime(590 + detune, t0 + 0.34);
      osc.frequency.setValueAtTime(590 + detune, t0 + 0.8);
      osc.frequency.exponentialRampToValueAtTime(310 + detune, t0 + dur);
      // Vibrato de lobo
      const vib = this.ctx.createOscillator();
      vib.frequency.value = 5.2;
      const vibG = this.ctx.createGain();
      vibG.gain.value = 9;
      vib.connect(vibG);
      vibG.connect(osc.frequency);
      vib.start(t0);
      vib.stop(t0 + dur);
      osc.connect(lp);
      osc.start(t0);
      osc.stop(t0 + dur);
    }

    // La cola del eco sigue ~1 s tras el aullido: desmontar DESPUÉS
    setTimeout(() => {
      try {
        out.disconnect();
        lp.disconnect();
        delay.disconnect();
        fb.disconnect();
        wet.disconnect();
      } catch (e) {
        /* ya desmontado */
      }
    }, (dur + 1.1) * 1000);
  }

  /** Otro jugador recogió el Núcleo (destello lejano). */
  pickupOther() {
    if (!this.unlocked) return;
    this._osc({ type: 'sine', from: 1318, dur: 0.09, gain: 0.12 });
    this._osc({ type: 'sine', from: 988, dur: 0.14, gain: 0.1, at: 0.07 });
  }

  /** El Núcleo aparece/cae en el mundo (campana espacial). */
  coreSpawn(s) {
    if (!this.unlocked || !s || s.gain <= 0.01) return;
    this._osc({ type: 'sine', from: 987, dur: 0.3, gain: 0.18 * s.gain, pan: s.pan });
    this._osc({ type: 'sine', from: 1480, dur: 0.2, gain: 0.08 * s.gain, at: 0.02, pan: s.pan });
  }

  /** Un rival se transformó (gruñido lejano). */
  remoteTransform(s) {
    if (!this.unlocked || !s || s.gain <= 0.01) return;
    this._osc({ type: 'sawtooth', from: 95, to: 58, dur: 0.42, gain: 0.16 * s.gain, pan: s.pan });
  }

  // ═════════════════════ Ronda e interfaz ═════════════════════

  /** Comienzo de ronda (llamada a la caza: bocina + tambor). */
  roundStart() {
    if (!this.unlocked) return;
    this._noise({ type: 'lowpass', dur: 0.2, gain: 0.32, from: 240, to: 90 });
    this._osc({ type: 'sine', from: 62, to: 48, dur: 0.22, gain: 0.3 });
    this._osc({ type: 'sawtooth', from: 98, dur: 0.3, gain: 0.2, at: 0.16 });
    this._osc({ type: 'sawtooth', from: 147, dur: 0.34, gain: 0.18, at: 0.34 });
  }

  /** Fin de ronda (la "música del marcador": arpegio corto). */
  roundEnd() {
    if (!this.unlocked) return;
    const notes = [659.3, 784, 987.8, 1318.5];
    notes.forEach((f, i) => {
      this._osc({ type: 'sine', from: f, dur: 0.18, gain: 0.2, at: i * 0.13 });
      this._osc({ type: 'triangle', from: f / 2, dur: 0.2, gain: 0.1, at: i * 0.13 });
    });
    this._osc({ type: 'triangle', from: 330, dur: 0.6, gain: 0.1, at: 0.52 });
  }

  /** Clic de botón (canal UI). */
  uiClick() {
    this.unlock(); // todo clic es un gesto válido para despertar el audio
    if (!this.unlocked) return;
    this._noise({ type: 'highpass', dur: 0.014, gain: 0.16, from: 3000, channel: 'ui' });
    this._osc({ type: 'square', from: 480, dur: 0.018, gain: 0.08, channel: 'ui' });
  }

  /** Conmutador de ajustes (dos alturas distintas según estado). */
  uiToggle(on) {
    this.unlock();
    if (!this.unlocked) return;
    this._osc({ type: 'square', from: on ? 880 : 540, dur: 0.03, gain: 0.12, channel: 'ui' });
    this._osc({ type: 'square', from: on ? 1170 : 420, dur: 0.025, gain: 0.08, at: 0.04, channel: 'ui' });
  }
}
