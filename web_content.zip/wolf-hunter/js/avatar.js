/**
 * WOLF-HUNTER · avatar.js
 * Personaje geométrico low-poly (cajas planas, cero assets). Cada avatar
 * contiene DOS formas construidas de forma perezosa:
 *
 *  · Hunter — humanoide con visor (Fases 1–2).
 *  · Wolf   — cuadrúpedo con galope (Fase 3): la silueta oscura y larga se
 *             lee contra el cielo claro, y las orejas/cola/ojos llevan el
 *             COLOR DEL JUGADOR para que los rivales se distingan.
 *
 * La Fase 5 sustituirá ambas formas por modelos GLTF manteniendo esta misma
 * interfaz (setYaw/setWalk/setWolf/…), así el resto del juego no cambia.
 *
 *  · Caminar/galope PROCEDURAL: las patas oscilan con la fase avanzada por
 *    la velocidad real (no reloj) y el torso rebota.
 *  · Etiqueta de nombre (sprite canvas) con barra de vida integrada.
 *  · setDead: pose de caído (tumbado) hasta el respawn.
 *  · flashHit: destello emisivo rojo al recibir daño (Lambert emissive).
 */
import * as THREE from 'three';

const BOX = new THREE.BoxGeometry(1, 1, 1); // compartida por todas las partes

/** Color base del pelaje del lobo (silueta oscura legible a contraluz). */
const WOLF_FUR = 0x262c38;

/**
 * Crea un avatar con las dos formas (Hunter/Wolf).
 * @param {object} opts
 * @param {number|string} opts.color color plano del traje (hex CSS o número)
 * @param {string} [opts.name=''] nombre flotante ('' = sin etiqueta)
 * @param {boolean} [opts.showLabel=true] dibujar la etiqueta de nombre
 * @returns {object} avatar {group, setYaw, setWalk, setColor, setWolf,
 *                           setHp, setDead, flashHit, setLabelVisible, dispose}
 */
export function createAvatar(opts = {}) {
  const color = new THREE.Color(opts.color || 0x8a93a8);

  // Materiales PROPIOS de este avatar (el destello de daño no se filtra)
  const humanMat = new THREE.MeshLambertMaterial({ color: color.clone() });
  const darkMat = new THREE.MeshLambertMaterial({ color: 0x1a2030 });
  const wolfMat = new THREE.MeshLambertMaterial({ color: WOLF_FUR });
  const accentMat = new THREE.MeshLambertMaterial({ color: color.clone() });
  const glowMat = new THREE.MeshBasicMaterial({ color: color.clone() });
  const allMats = [humanMat, darkMat, wolfMat, accentMat];

  const group = new THREE.Group(); // posiciona/yawea quien lo posea (pies en Y=0)

  /** Pieza estática (o con pivote propio) colgada de un padre. */
  function part(parent, mat, w, h, d, x, y, z) {
    const mesh = new THREE.Mesh(BOX, mat);
    mesh.scale.set(w, h, d);
    mesh.position.set(x, y, z);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    parent.add(mesh);
    return mesh;
  }

  /** Extremidad con pivote arriba (cuelga y oscila). */
  function limb(parent, mat, w, h, d, x, y, z) {
    const pivot = new THREE.Group();
    pivot.position.set(x, y, z);
    part(pivot, mat, w, h, d, 0, -h / 2, 0);
    parent.add(pivot);
    return pivot;
  }

  // ══════════════════ Forma HUMANA ══════════════════
  const human = buildHuman();
  function buildHuman() {
    const root = new THREE.Group();
    const body = new THREE.Group(); // recibe el rebote del caminar
    root.add(body);

    // Torso y cabeza
    part(body, humanMat, 0.46, 0.58, 0.26, 0, 1.06, 0);
    const head = part(body, humanMat, 0.26, 0.24, 0.26, 0, 1.5, 0);
    head.name = 'head';
    // Visor oscuro en la cara (mira hacia -Z, como la cámara)
    part(body, darkMat, 0.2, 0.08, 0.03, 0, 1.52, -0.135);
    // Hombreras de color (legibilidad de silueta a distancia)
    part(body, darkMat, 0.16, 0.1, 0.3, 0.27, 1.28, 0);
    part(body, darkMat, 0.16, 0.1, 0.3, -0.27, 1.28, 0);

    const armL = limb(body, humanMat, 0.12, 0.5, 0.12, 0.31, 1.3, 0);
    const armR = limb(body, humanMat, 0.12, 0.5, 0.12, -0.31, 1.3, 0);
    const legL = limb(body, darkMat, 0.16, 0.74, 0.16, 0.12, 0.76, 0);
    const legR = limb(body, darkMat, 0.16, 0.74, 0.16, -0.12, 0.76, 0);

    /** Caminar humano (velocidad 0..1 respecto a HUNTER_SPEED). */
    function animate(speed01, dt, grounded) {
      const s = Math.min(Math.max(speed01, 0), 1.6);
      if (grounded) {
        phase += s * dt * 9.5;
        swing += (s - swing) * Math.min(1, dt * 12);
      } else {
        swing += (0 - swing) * Math.min(1, dt * 8);
      }
      const inAir = !grounded;
      const legAmp = 0.62 * swing;
      const armAmp = 0.5 * swing;
      const air = Math.min(1, Math.max(0, 1 - swing * 4)) * (inAir ? 1 : 0);

      legL.rotation.x = Math.sin(phase) * legAmp - air * 0.45;
      legR.rotation.x = -Math.sin(phase) * legAmp + air * 0.3;
      armL.rotation.x = -Math.sin(phase) * armAmp - air * 0.5;
      armR.rotation.x = Math.sin(phase) * armAmp - air * 0.5;
      armL.rotation.z = 0.06 + air * 0.25;
      armR.rotation.z = -0.06 - air * 0.25;
      body.position.y = Math.abs(Math.sin(phase)) * 0.035 * swing;
    }

    /** Pose de muerto (humano): tumbado de lado. */
    function deadPose(on) {
      body.rotation.z = on ? Math.PI * 0.47 : 0;
      body.position.y = on ? 0.32 : 0;
    }

    return { root, animate, deadPose };
  }

  // ══════════════════ Forma LOBO ══════════════════
  let wolf = null;
  function buildWolf() {
    const root = new THREE.Group();
    const body = new THREE.Group(); // bob + cabeceo del galope
    root.add(body);

    // Cuerpo alargado (adelante = -Z) + pecho más profundo
    part(body, wolfMat, 0.42, 0.4, 1.0, 0, 0.74, 0.04);
    part(body, wolfMat, 0.48, 0.48, 0.42, 0, 0.72, -0.3);
    // Franja dorsal del color del jugador
    part(body, accentMat, 0.14, 0.05, 0.92, 0, 0.97, 0.02);

    // Cabeza + hocico + orejas de color + ojos brillantes
    const head = new THREE.Group();
    head.position.set(0, 0.94, -0.66);
    body.add(head);
    part(head, wolfMat, 0.3, 0.26, 0.3, 0, 0, 0);
    part(head, wolfMat, 0.16, 0.13, 0.24, 0, -0.045, -0.24);
    part(head, accentMat, 0.09, 0.17, 0.06, 0.1, 0.2, -0.02);
    part(head, accentMat, 0.09, 0.17, 0.06, -0.1, 0.2, -0.02);
    part(head, glowMat, 0.05, 0.04, 0.02, 0.09, 0.03, -0.16);
    part(head, glowMat, 0.05, 0.04, 0.02, -0.09, 0.03, -0.16);

    // Cola: base oscura + punta del color del jugador, levantada
    const tail = new THREE.Group();
    tail.position.set(0, 0.86, 0.52);
    body.add(tail);
    part(tail, wolfMat, 0.09, 0.09, 0.34, 0, 0, 0.17);
    part(tail, accentMat, 0.1, 0.1, 0.16, 0, 0.02, 0.4);
    tail.rotation.x = -0.55;

    // Patas: par delantero y par trasero (galope a pares)
    const legFL = limb(body, wolfMat, 0.11, 0.56, 0.13, 0.17, 0.58, -0.34);
    const legFR = limb(body, wolfMat, 0.11, 0.56, 0.13, -0.17, 0.58, -0.34);
    const legBL = limb(body, wolfMat, 0.12, 0.58, 0.14, 0.17, 0.58, 0.36);
    const legBR = limb(body, wolfMat, 0.12, 0.58, 0.14, -0.17, 0.58, 0.36);

    /** Galope del lobo (velocidad 0..1 respecto a HUNTER_SPEED, >1 al correr). */
    function animate(speed01, dt, grounded) {
      const s = Math.min(Math.max(speed01, 0), 1.6);
      if (grounded) {
        phase += s * dt * 7.5; // zancada más larga que el humano
        swing += (s - swing) * Math.min(1, dt * 10);
      } else {
        swing += (0 - swing) * Math.min(1, dt * 7);
      }
      const inAir = !grounded;
      const amp = 0.72 * swing;
      const air = Math.min(1, Math.max(0, 1 - swing * 4)) * (inAir ? 1 : 0);

      // Salto a pares (delanteras contra-fase de traseras) + salto en vuelo
      const f = Math.sin(phase);
      const b = Math.sin(phase + Math.PI);
      legFL.rotation.x = f * amp - air * 0.85;
      legFR.rotation.x = f * amp - air * 0.85;
      legBL.rotation.x = b * amp + air * 0.75;
      legBR.rotation.x = b * amp + air * 0.75;

      // Rebote + cabeceo del lomo y balanceo de la cola
      body.position.y = Math.abs(Math.sin(phase)) * 0.055 * swing;
      body.rotation.x = Math.sin(phase) * 0.05 * swing - air * 0.12;
      tail.rotation.y = Math.sin(phase * 0.6) * 0.3;
    }

    /** Pose de muerto (lobo): tumbado sobre el costado. */
    function deadPose(on) {
      body.rotation.z = on ? Math.PI * 0.47 : 0;
      body.rotation.x = 0;
      body.position.y = on ? 0.3 : 0;
      tail.rotation.x = on ? -0.1 : -0.55;
    }

    return { root, animate, deadPose };
  }

  // ══════════════════ Etiqueta de nombre + barra de vida ══════════════════
  let label = null;
  let labelCanvas = null;
  let labelTex = null;
  let hp01 = -1; // -1 = sin barra (lleno)
  const name = opts.name || '';

  function buildLabel() {
    labelCanvas = document.createElement('canvas');
    labelCanvas.width = 256;
    labelCanvas.height = 72;
    labelTex = new THREE.CanvasTexture(labelCanvas);
    labelTex.colorSpace = THREE.SRGBColorSpace;
    const mat = new THREE.SpriteMaterial({
      map: labelTex,
      transparent: true,
      depthTest: true,
      fog: true
    });
    label = new THREE.Sprite(mat);
    label.scale.set(1.5, 0.42, 1);
    label.position.set(0, 2.02, 0);
    group.add(label);
    redrawLabel();
  }

  function redrawLabel() {
    if (!labelCanvas) return;
    const g = labelCanvas.getContext('2d');
    g.clearRect(0, 0, 256, 72);
    // Pastilla redondeada translúcida + borde del color del jugador
    g.fillStyle = 'rgba(10, 13, 20, 0.72)';
    g.strokeStyle = '#' + color.getHexString();
    g.lineWidth = 4;
    const r = 16;
    g.beginPath();
    g.moveTo(r + 4, 4);
    g.arcTo(252, 4, 252, 68, r);
    g.arcTo(252, 68, 4, 68, r);
    g.arcTo(4, 68, 4, 4, r);
    g.arcTo(4, 4, 252, 4, r);
    g.closePath();
    g.fill();
    g.stroke();
    g.font = '700 30px system-ui, sans-serif';
    g.fillStyle = '#f2f5fb';
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText(name || '???', 128, 26, 232);

    // Barra de vida bajo el nombre (solo si el jugador está herido)
    if (hp01 >= 0) {
      const bw = 150;
      const bh = 9;
      const bx = (256 - bw) / 2;
      const by = 48;
      g.fillStyle = 'rgba(6, 8, 13, 0.85)';
      g.fillRect(bx, by, bw, bh);
      const pct = Math.min(1, Math.max(0, hp01));
      g.fillStyle = pct > 0.5 ? '#3ddc97' : pct > 0.25 ? '#f2b94b' : '#ff5c5c';
      g.fillRect(bx + 1.5, by + 1.5, (bw - 3) * pct, bh - 3);
    }
    labelTex.needsUpdate = true;
  }

  const wantLabel = opts.showLabel !== false;
  if (wantLabel && name) buildLabel();

  // ══════════════════ Estado compartido de animación ══════════════════
  let phase = 0;
  let swing = 0; // amplitud suavizada de la zancada
  let isWolf = false;
  let dead = false;
  let flash = 0; // 0..1 destello de daño (decae solo)

  /**
   * Orienta el avatar.
   * @param {number} yaw yaw del personaje (rad)
   */
  function setYaw(yaw) {
    group.rotation.y = yaw;
  }

  /**
   * Cambia de forma (Hunter ↔ Wolf). La forma destino se construye la
   * primera vez que se pide: hasta entonces el avatar pesa lo mismo que
   * en las fases 1–2.
   * @param {boolean} v true = Wolf
   */
  function setWolf(v) {
    const want = !!v;
    if (want === isWolf) return;
    if (want && !wolf) {
      wolf = buildWolf();
      group.add(wolf.root);
    }
    isWolf = want;
    human.root.visible = !isWolf;
    if (wolf) wolf.root.visible = isWolf;
    // La etiqueta del lobo baja un poco: la cabeza está más atrás
    if (label) label.position.set(0, isWolf ? 1.7 : 2.02, isWolf ? -0.2 : 0);
  }

  /**
   * Anima la forma activa a partir de la velocidad horizontal real.
   * También decae el destello de daño (se llama cada frame).
   * @param {number} speed01 velocidad 0..1 respecto a HUNTER_SPEED (>1 lobo)
   * @param {number} dt delta time en segundos
   * @param {boolean} [grounded=true] false = pose de salto/caída
   */
  function setWalk(speed01, dt, grounded = true) {
    if (flash > 0) {
      flash = Math.max(0, flash - dt / 0.35); // ~350 ms de destello
      const e = Math.round(flash * 0.55 * 255);
      for (const m of allMats) {
        m.emissive.setRGB(e / 255, 0.07 * flash, 0.05 * flash);
      }
    }
    if (dead) return; // congelado en la pose de caído
    if (isWolf) wolf.animate(speed01, dt, grounded);
    else human.animate(speed01, dt, grounded);
  }

  /**
   * Barra de vida en la etiqueta (-1 oculta la barra).
   * @param {number} v 0..1, o -1 para "sin barra"
   */
  function setHp(v) {
    const next = v === -1 ? -1 : Math.min(1, Math.max(0, v));
    if (next === hp01) return;
    hp01 = next;
    redrawLabel();
  }

  /**
   * Pose de muerto: tumbado hasta el respawn (congela la animación).
   * @param {boolean} v
   */
  function setDead(v) {
    if (v === dead) return;
    dead = !!v;
    human.deadPose(dead);
    if (wolf) wolf.deadPose(dead);
    if (label) label.material.opacity = dead ? 0.45 : 1;
  }

  /** Dispara el destello rojo de daño (decae en setWalk). */
  function flashHit() {
    flash = 1;
  }

  /**
   * Recolorea el avatar (el host asigna un color único por jugador).
   * @param {number|string} hex color nuevo
   */
  function setColor(hex) {
    color.set(hex);
    humanMat.color.copy(color);
    accentMat.color.copy(color);
    glowMat.color.copy(color);
    redrawLabel();
  }

  /**
   * Muestra u oculta la etiqueta de nombre.
   * @param {boolean} v
   */
  function setLabelVisible(v) {
    if (label) label.visible = v;
  }

  /** Libera recursos GPU (al expulsar al jugador de la partida). */
  function dispose() {
    for (const m of [...allMats, glowMat]) m.dispose();
    if (labelTex) labelTex.dispose();
    if (label) label.material.dispose();
  }

  group.add(human.root);
  human.root.visible = true;

  return {
    group,
    setYaw,
    setWalk,
    setColor,
    setLabelVisible,
    setWolf,
    setHp,
    setDead,
    flashHit,
    get isWolf() {
      return isWolf;
    },
    dispose
  };
}
