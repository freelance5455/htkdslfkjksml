/**
 * WOLF-HUNTER · orientation.js (0.4.1 · hotfix de rotación)
 * ═══════════════════════════════════════════════════════════════════
 * ¿Por qué existe este módulo?
 *
 * El aviso «Gira el dispositivo» era solo CSS (@media orientation).
 * Si el navegador del móvil NO rota solo —rotación automática
 * desactivada, navegador integrado de WhatsApp/Instagram, o iPhone
 * con la rotación bloqueada— el jugador se quedaba atrapado en ese
 * aviso para siempre: las páginas web no pueden mostrar el botón de
 * rotación del sistema operativo.
 *
 * Solución en dos capas, disparadas por el botón «Girar pantalla»:
 *
 *  1. GIRO NATIVO (preferido, Android/Chrome/Firefox):
 *     requestFullscreen() + screen.orientation.lock('landscape').
 *     El juego pasa a pantalla completa y el SO gira la pantalla
 *     aunque la rotación automática esté apagada.
 *
 *  2. MODO HORIZONTAL FORZADO (respaldo universal, iOS/WebView):
 *     si el navegador no puede fijar la orientación, giramos TODO
 *     el juego 90° con un transform CSS y remapeamos las
 *     coordenadas táctiles al nuevo espacio. El usuario sostiene
 *     el móvil en vertical y ve el juego en horizontal.
 *
 * El modo forzado se recuerda en localStorage ('wh-rotate') para
 * arrancar ya girado en la siguiente visita, se desactiva solo si
 * el dispositivo acaba rotando de verdad, y se puede deshacer con
 * el botón ↺ que aparece en la esquina.
 *
 * Coordenadas del giro (transform-origin 0 0, rotate(90deg)
 * translateY(-100%)): el punto de juego (gx, gy) se pinta en el
 * pixel físico (innerWidth − gy, gx); por tanto un toque físico en
 * (cx, cy) cae, en el espacio del juego, en (cy, innerWidth − cx).
 */

const STORAGE_KEY = 'wh-rotate';
const WAIT_REAL_ROTATION_MS = 900; // margen para la animación de giro del SO
const POLL_MS = 90;

/** ¿El viewport físico es ya horizontal? */
function isRealLandscape() {
  return window.innerWidth > window.innerHeight;
}

/** ¿Parece iOS? (sin API de orientation.lock ni fullscreen en iPhone) */
function looksLikeIOS() {
  return /iPad|iPhone|iPod/.test(navigator.userAgent) ||
    (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
}

export class OrientationManager {
  constructor() {
    this._forced = false;
    this._busy = false;
    /** Callback que main.js usa para re-ajustar cámara/renderer. */
    this.onViewportChange = null;

    this._btnRotate = null;
    this._btnUnrotate = null;
    this._hint = null;
    this._bound = [];
    this._autoForced = false; // ¿el forzado de arranque ya se evaluó?
  }

  /** Registro de listeners y botones. Idempotente. */
  attach() {
    if (this._bound.length) return;

    this._btnRotate = document.getElementById('btn-rotate');
    this._btnUnrotate = document.getElementById('btn-unrotate');
    this._hint = document.getElementById('rotate-hint');

    // iPhone/iPad: adelantamos la explicación (no pueden fijar orientación)
    if (this._hint && looksLikeIOS()) {
      this._hint.textContent =
        'En iPhone/iPad no se puede forzar el giro: usa el botón y ' +
        'activaremos el modo horizontal integrado.';
    }

    const add = (target, type, fn, opts) => {
      target.addEventListener(type, fn, opts);
      this._bound.push([target, type, fn, opts]);
    };

    if (this._btnRotate) {
      // pointerdown + preventDefault para que el tap no arrastre ni haga
      // zoom doble en ningún navegador; el click dispara la acción.
      add(this._btnRotate, 'pointerdown', (e) => e.preventDefault());
      add(this._btnRotate, 'click', () => this.requestLandscape());
    }

    if (this._btnUnrotate) {
      // El botón ↺ vive ENCIMA de la zona de cámara: nunca debe girar
      // la mira ni disparar.
      add(this._btnUnrotate, 'pointerdown', (e) => {
        e.preventDefault();
        e.stopPropagation();
      });
      add(this._btnUnrotate, 'click', (e) => {
        e.stopPropagation();
        this.disableForced(true);
      });
    }

    // El viewport cambia (giro real, barra de direcciones, teclado):
    // re-medir el cuerpo girado y recuperarnos si por fin hay landscape.
    add(window, 'resize', () => this._sync());
    add(window, 'orientationchange', () => setTimeout(() => this._sync(), 60));

    // Unidades de layout en px reales (más fiables que 1vh con barra de
    // URL dinámica) e intercambiadas en modo girado.
    this._applyViewportUnits();

    // Arranque: si este navegador ya necesitó el modo forzado y seguimos
    // en vertical, giramos sin esperar otra vez al botón.
    if (!this._autoForced) {
      this._autoForced = true;
      let remembered = null;
      try {
        remembered = localStorage.getItem(STORAGE_KEY);
      } catch (e) { /* almacenamiento bloqueado: seguimos sin él */ }
      if (remembered === 'forced' && isRealLandscape() === false) {
        this.enableForced(false); // no re-escribe el flag
      }
    }
  }

  // ═══════════════ API de viewport virtual ═══════════════

  /**
   * Dimensiones del juego (lógicas). En modo forzado están
   * intercambiadas: el juego cree que la pantalla es horizontal.
   * @returns {{w: number, h: number}}
   */
  viewport() {
    if (this._forced) {
      return { w: window.innerHeight, h: window.innerWidth };
    }
    return { w: window.innerWidth, h: window.innerHeight };
  }

  /**
   * Traduce un punto táctil FÍSICO (clientX/clientY) al espacio del
   * juego. Identidad salvo en modo forzado, donde se aplica la inversa
   * del giro de 90°.
   * @param {number} cx clientX físico
   * @param {number} cy clientY físico
   * @returns {{x: number, y: number}}
   */
  mapPointer(cx, cy) {
    if (!this._forced) return { x: cx, y: cy };
    return { x: cy, y: window.innerWidth - cx };
  }

  /** ¿Activo el modo horizontal forzado? */
  get forced() {
    return this._forced;
  }

  // ═══════════════ Acción del botón «Girar pantalla» ═══════════════

  /**
   * Cadena completa: fullscreen → fijar landscape → esperar el giro
   * real → si nada funciona, modo forzado.
   */
  async requestLandscape() {
    if (this._busy || isRealLandscape() || this._forced) return;
    this._busy = true;
    this._setBusyUI(true);
    try {
      // 1) Pantalla completa: requisito para fijar la orientación en
      //    Android, y de paso el juego gana toda la pantalla.
      try {
        const el = document.documentElement;
        if (el.requestFullscreen) {
          await el.requestFullscreen({ navigationUI: 'hide' });
        } else if (el.webkitRequestFullscreen) {
          el.webkitRequestFullscreen(); // Safari antiguo / iPadOS
        }
      } catch (e) {
        // Denegado o no existe (iPhone): seguimos con el plan B.
      }

      // 2) Fijar landscape (esto es lo que «pulsa el botón de rotación»
      //    que el SO muestra en otras apps).
      try {
        const so = screen.orientation;
        if (so && typeof so.lock === 'function') {
          await so.lock('landscape');
        } else {
          throw new Error('orientation.lock no disponible');
        }
      } catch (e) {
        // iOS, WebViews y navegadores in-app: no soportado.
      }

      // 3) El SO anima el giro: esperamos a ver si el viewport rota.
      const rotated = await this._waitForRealLandscape(WAIT_REAL_ROTATION_MS);
      if (rotated) return; // el aviso CSS desaparece solo

      // 4) Este navegador no va a rotar: modo horizontal forzado.
      this.enableForced(true);
    } finally {
      this._busy = false;
      this._setBusyUI(false);
    }
  }

  /** Resuelve true en cuanto el viewport físico pasa a horizontal. */
  _waitForRealLandscape(timeoutMs) {
    return new Promise((resolve) => {
      const t0 = performance.now();
      const tick = () => {
        if (isRealLandscape()) return resolve(true);
        if (performance.now() - t0 >= timeoutMs) return resolve(false);
        setTimeout(tick, POLL_MS);
      };
      tick();
    });
  }

  // ═══════════════ Modo horizontal forzado ═══════════════

  /**
   * Gira el juego 90° dentro de una pantalla vertical.
   * @param {boolean} persist true para recordarlo en la próxima visita
   */
  enableForced(persist = true) {
    if (this._forced) return;
    this._forced = true;
    document.documentElement.classList.add('forced-landscape');
    this._applyBodySize();
    this._applyViewportUnits();
    if (persist) {
      try { localStorage.setItem(STORAGE_KEY, 'forced'); } catch (e) { /* sin Storage */ }
    }
    if (this.onViewportChange) this.onViewportChange();
  }

  /**
   * Devuelve el juego a la orientación física.
   * @param {boolean} clearPersist true si el usuario lo pidió: no
   *        volver a forzar en el próximo arranque
   */
  disableForced(clearPersist = false) {
    if (!this._forced) return;
    this._forced = false;
    document.documentElement.classList.remove('forced-landscape');
    document.body.style.width = '';
    document.body.style.height = '';
    this._applyViewportUnits();
    if (clearPersist) {
      try { localStorage.removeItem(STORAGE_KEY); } catch (e) { /* sin Storage */ }
    }
    if (this.onViewportChange) this.onViewportChange();
  }

  /** Cuerpo con las dimensiones intercambiadas (px exactos, no 100vh). */
  _applyBodySize() {
    // En vertical: el juego mide alto de pantalla de ancho y viceversa.
    document.body.style.width = `${window.innerHeight}px`;
    document.body.style.height = `${window.innerWidth}px`;
  }

  /**
   * Publica --vw/--vh (1% del viewport DEL JUEGO) en px reales.
   * Todo el CSS dimensiona paneles con estas unidades: así el layout
   * del modo girado es calcado al landscape real, y de paso el alto
   * refleja la ventana visible (sin sorpresas de la barra de URL).
   */
  _applyViewportUnits() {
    const v = this.viewport();
    const style = document.documentElement.style;
    style.setProperty('--vw', `${v.w / 100}px`);
    style.setProperty('--vh', `${v.h / 100}px`);
  }

  /** Reacción a cambios del viewport físico. */
  _sync() {
    // Las unidades de layout siguen al viewport SIEMPRE (barra de URL,
    // teclado, giro). En modo forzado quedan intercambiadas.
    this._applyViewportUnits();

    if (!this._forced) {
      // Recuperación del aviso: nada que hacer (CSS manda).
      return;
    }
    if (isRealLandscape()) {
      // El dispositivo por fin rotó de verdad: el giro forzado sobra
      // (estaría 90° torcido). Mantenemos el recuerdo para otra visita.
      this.disableForced(false);
      return;
    }
    // Seguimos en vertical: re-medir por si cambió la barra de URL, etc.
    this._applyBodySize();
    if (this.onViewportChange) this.onViewportChange();
  }

  /** Estado «Girando…» del botón mientras se intenta el giro nativo. */
  _setBusyUI(busy) {
    if (!this._btnRotate) return;
    this._btnRotate.classList.toggle('is-busy', busy);
    this._btnRotate.disabled = busy;
    const label = this._btnRotate.querySelector('.btn-rotate-label');
    if (label) label.textContent = busy ? 'Girando…' : 'Girar pantalla';
  }
}
