/**
 * WOLF-HUNTER · error-handler.js
 * Captura window.onerror y unhandledrejection y muestra un overlay legible
 * con botón "Copiar diagnóstico" (versión, hardware, red, FPS, último error).
 * Se instala lo primero de todo desde main.js.
 */
import { GAME_VERSION, PHASE } from './version.js';
import { debug } from './debug.js';

let installed = false;
let reported = false;
let errorCount = 0;

/** Detección de WebGL2 cacheada (no crear contextos de más). */
let webgl2Support = null;
function supportsWebGL2() {
  if (webgl2Support === null) {
    try {
      webgl2Support = !!document.createElement('canvas').getContext('webgl2');
    } catch (e) {
      webgl2Support = false;
    }
  }
  return webgl2Support;
}

/**
 * Registra los capturadores globales. Idempotente.
 */
export function installGlobalErrorHandler() {
  if (installed) return;
  installed = true;

  window.addEventListener('error', (e) => {
    reportError({
      message: e.message || 'Error desconocido',
      stack: e.error && e.error.stack ? e.error.stack : '',
      source: e.filename ? `${e.filename}:${e.lineno}:${e.colno}` : ''
    });
  });

  window.addEventListener('unhandledrejection', (e) => {
    const reason = e.reason;
    reportError({
      message:
        'Promesa rechazada: ' +
        (reason && reason.message ? reason.message : String(reason)),
      stack: reason && reason.stack ? reason.stack : '',
      source: ''
    });
  });

  debug.log('error-handler instalado');
}

/**
 * Construye el texto de diagnóstico completo.
 * @returns {string} diagnóstico multilínea listo para copiar
 */
export function getDiagnostics() {
  const lines = [
    `WOLF-HUNTER v${GAME_VERSION} (Fase ${PHASE})`,
    `Hora: ${new Date().toISOString()}`,
    `Agente: ${navigator.userAgent}`,
    `Plataforma: ${navigator.platform || '—'}`,
    `Protocolo: ${location.protocol}`,
    `DPR: ${window.devicePixelRatio}`,
    `Núcleos: ${navigator.hardwareConcurrency || '—'}`,
    `WebGL2: ${supportsWebGL2() ? 'sí' : 'no'}`,
    `Puntero: ${navigator.maxTouchPoints > 0 ? 'táctil' : 'sin táctil'}`,
    `FPS último: ${debug.state.lastFps} (${debug.state.lastMs.toFixed(1)} ms)`,
    `Errores totales: ${errorCount}`
  ];
  return lines.join('\n');
}

/**
 * Reporta un error: registra, loguea y muestra el overlay (solo el primero
 * abre el overlay; los siguientes solo incrementan el contador).
 * @param {{message: string, stack?: string, source?: string}} info
 */
export function reportError(info) {
  errorCount += 1;
  debug.error(info.message, info.source || '', info.stack || '');

  const details = [
    info.message,
    info.source ? `\nOrigen: ${info.source}` : '',
    info.stack ? `\n\n${info.stack.split('\n').slice(0, 8).join('\n')}` : '',
    `\n\n— Diagnóstico —\n${getDiagnostics()}`
  ].join('');

  const overlay = document.getElementById('error-overlay');
  document.getElementById('error-message').textContent = info.message;
  document.getElementById('error-details').textContent = details;
  overlay.setAttribute('data-open', '');

  if (!reported) {
    reported = true;
    wireButtons(overlay);
  }
}

/** Conecta los botones del overlay una única vez. */
function wireButtons(overlay) {
  overlay.dataset.wired = '1';

  document.getElementById('btn-reload').addEventListener('click', () => {
    location.reload();
  });

  document.getElementById('btn-dismiss-error').addEventListener('click', () => {
    overlay.removeAttribute('data-open');
  });

  document.getElementById('btn-copy-diag').addEventListener('click', async () => {
    const text = document.getElementById('error-details').textContent;
    const btn = document.getElementById('btn-copy-diag');
    try {
      await navigator.clipboard.writeText(text);
      btn.textContent = 'Copiado';
    } catch (e) {
      // Fallback para navegadores sin permiso de clipboard
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.cssText = 'position:fixed;opacity:0';
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand('copy');
        btn.textContent = 'Copiado';
      } catch (e2) {
        btn.textContent = 'Copia manual';
      }
      ta.remove();
    }
    // El botón recupera su etiqueta tras un momento (estado, no animación)
    setTimeout(() => {
      btn.textContent = 'Copiar diagnóstico';
    }, 1600);
  });
}
