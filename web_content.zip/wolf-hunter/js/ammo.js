/**
 * WOLF-HUNTER · ammo.js
 * Estado de munición del arma del Hunter: cargador + reserva + recarga
 * manual de 1,5 s.
 *
 * La MISMA clase vive en los dos lados con la MISMA semántica:
 *  · Cliente (weapon-hunter.js): predice en local para que el HUD responda
 *    al instante ("8 → 7" en el mismo frame que se pulsa disparar).
 *  · Host (round-manager.js): contador AUTORITATIVO; un SHOOT con cargador
 *    vacío se rechaza, sin importar lo que diga el cliente.
 *
 * Regla de reloj (igual que movement.js): NADA de performance.now() dentro;
 * el "ahora" llega como parámetro, así el host y el cliente pueden ejecutar
 * las mismas transiciones aunque sus relojes no coincidan.
 */

import { CONFIG } from '../config.js';

export class AmmoState {
  constructor() {
    this.reset();
  }

  /** Cargador lleno + reserva completa (inicio de ronda y respawn). */
  reset() {
    this.mag = CONFIG.MAGAZINE_SIZE;
    this.reserve = CONFIG.RESERVE_AMMO;
    this.reloading = false;
    this.reloadEndAt = 0;
  }

  /**
   * ¿Queda una bala disponible (no recargando)?
   * @param {number} now reloj actual (ms)
   * @returns {boolean}
   */
  canFire(now) {
    this._finishReload(now);
    return !this.reloading && this.mag > 0;
  }

  /**
   * Consume una bala (el llamador ya validó canFire).
   * @param {number} now reloj actual (ms)
   */
  consume(now) {
    this._finishReload(now);
    if (this.reloading || this.mag <= 0) return;
    this.mag -= 1;
  }

  /**
   * ¿Se puede iniciar una recarga ahora?
   * @param {number} now reloj actual (ms)
   * @returns {boolean}
   */
  canReload(now) {
    this._finishReload(now);
    return (
      !this.reloading &&
      this.mag < CONFIG.MAGAZINE_SIZE &&
      this.reserve > 0
    );
  }

  /**
   * Arranca la recarga manual (dura RELOAD_TIME_MS).
   * @param {number} now reloj actual (ms)
   * @returns {boolean} true si se inició
   */
  startReload(now) {
    if (!this.canReload(now)) return false;
    this.reloading = true;
    this.reloadEndAt = now + CONFIG.RELOAD_TIME_MS;
    return true;
  }

  /**
   * Cierra la recarga si su tiempo ya pasó. Público: el host lo llama en su
   * tick para que STATE.you lleve siempre la munición ya trasvasada.
   * @param {number} now reloj actual (ms)
   */
  update(now) {
    this._finishReload(now);
  }

  /**
   * Cierra la recarga si su tiempo ya pasó (trasvase reserva→cargador).
   * @param {number} now reloj actual (ms)
   */
  _finishReload(now) {
    if (!this.reloading || now < this.reloadEndAt) return;
    const need = CONFIG.MAGAZINE_SIZE - this.mag;
    const move = Math.min(need, this.reserve);
    this.mag += move;
    this.reserve -= move;
    this.reloading = false;
  }

  /**
   * Acepta el valor autoritativo del host (STATE.you).
   * El HUD del cliente solo lo adopta si no está en mitad de una recarga
   * local: su temporizador es el que pinta la animación.
   * @param {number} mag cargador autoritativo
   * @param {number} reserve reserva autoritativa
   * @param {number} now reloj actual (ms)
   */
  adopt(mag, reserve, now) {
    if (this.reloading && now < this.reloadEndAt + 250) return;
    this.mag = mag;
    this.reserve = reserve;
  }
}
