/**
 * WOLF-HUNTER · transform.js
 * Presentación LOCAL de la forma Hunter ↔ Wolf. El host decide (TRANSFORM),
 * este módulo traduce la decisión a todo lo que el jugador ve y toca:
 *
 *  · Avatar propio: modelo de lobo con el color del jugador.
 *  · Cámara: FOV más abierto (sensación de velocidad), tercera persona un
 *    poco más lejos y, como en Wolfteam, el lobo JUEGA en 3ª persona por
 *    defecto (el botón sigue ahí: el override del jugador manda).
 *  · HUD: munición ↔ temporizador de lobo.
 *
 * La velocidad y el salto NO van aquí: la física lee la forma por la
 * speedFn que GameSession inyecta en el motor (misma fuente para el host
 * y para la predicción del cliente).
 */

export class LocalTransform {
  /**
   * @param {object} deps
   * @param {object} deps.avatar avatar del jugador local
   * @param {object} deps.rig CameraRig
   * @param {object} deps.hud CombatHUD
   */
  constructor({ avatar, rig, hud }) {
    this.avatar = avatar;
    this.rig = rig;
    this.hud = hud;
    /** @type {boolean} forma local actual */
    this.wolf = false;
    /** Fin de la transformación en el RELOJ DEL HOST (ms). */
    this.endsAt = 0;
  }

  /**
   * Aplica la forma (idempotente).
   * @param {boolean} wolf
   * @param {number} [endsAt] reloj del host en que expira (0 = indefinido)
   */
  apply(wolf, endsAt = 0) {
    this.endsAt = endsAt || 0;
    if (wolf === this.wolf) return;
    this.wolf = !!wolf;

    this.avatar.setWolf(this.wolf);
    this.rig.setForm(this.wolf); // FOV + distancia + modo de cámara por forma
    this.hud.setForm(this.wolf);
  }

  /**
   * Vuelve a Hunter (inicio de ronda, respawn, fin de sesión). A diferencia
   * de apply(), NO abrevia aunque ya estuviéramos en Hunter: la cámara debe
   * recuperar siempre el modo que el jugador eligió (p. ej. tras la cámara
   * de muerte en tercera persona).
   */
  reset() {
    this.wolf = false;
    this.endsAt = 0;
    this.avatar.setWolf(false);
    this.rig.setForm(false);
    this.hud.setForm(false);
  }

  /**
   * Milisegundos de lobo restantes (para el HUD), en null si forma Hunter.
   * @param {number} nowHost estimación local del reloj del host
   * @returns {?number}
   */
  remaining(nowHost) {
    return this.wolf ? Math.max(0, this.endsAt - nowHost) : null;
  }
}
