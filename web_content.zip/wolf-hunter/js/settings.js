/**
 * WOLF-HUNTER · settings.js (Fase 4)
 * Ajustes del jugador: UN objeto persistido en localStorage y viviendo
 * en un único módulo, para que cualquier parte del juego lea el mismo
 * valor sin cableados repetidos.
 *
 *  · sens        — multiplicador de sensibilidad de cámara (se vuelca en
 *                  CONFIG.CAMERA_SENSITIVITY: player.js ya la lee por frame).
 *  · invertY     — se vuelca en CONFIG.INVERT_Y.
 *  · vibration   — gate de navigator.vibrate (iOS lo ignora sin romper nada).
 *  · colorblind  — remapa los colores de jugador a una paleta segura
 *                  (Okabe-Ito) SOLO en este dispositivo: es una necesidad
 *                  del que lo activa, no una regla de la sala.
 *  · volMaster / volSfx / volUi — volúmenes por canal (audio.js).
 *  · showFps     — chip de FPS visible sin ?fps.
 *  · quality     — 'auto' | 'high' | 'low' (DPR + sombras, main.js aplica).
 *
 * La persistencia es tolerante a fallos (modo privado) y a versiones
 * viejas del objeto: solo se conservan claves conocidas con tipo correcto.
 */

import { CONFIG } from '../config.js';

/** Valores por defecto (un solo sitio: el botón Restablecer los usa). */
export const SETTINGS_DEFAULTS = Object.freeze({
  sens: 1.0,
  invertY: false,
  vibration: true,
  colorblind: false,
  volMaster: 0.8,
  volSfx: 1.0,
  volUi: 0.8,
  showFps: false,
  quality: 'auto'
});

/**
 * Paleta segura para daltonismo (Okabe-Ito), keyed por el color ORIGINAL
 * de PLAYER_COLORS (network.js). El mapeo es local: el host sigue
 * asignando sus colores; este dispositivo los traduce al pintar.
 */
export const COLORBLIND_MAP = Object.freeze({
  0xff6b6b: 0x56b4e9, // rojo → azul cielo
  0x4dc9b0: 0xe69f00, // verde azulado → naranja
  0xf2b94b: 0xcc79a7, // ámbar → púrpura rojizo
  0x7a9ff0: 0xf0e442 // azul → amarillo
});

/** @param {number} v @param {number} min @param {number} max @returns {number} */
function clampNum(v, min, max) {
  return Math.min(max, Math.max(min, v));
}

/**
 * Carga y sanea el objeto guardado.
 * @returns {object} copia con solo claves válidas
 */
function load() {
  const data = { ...SETTINGS_DEFAULTS };
  try {
    const raw = localStorage.getItem(CONFIG.SETTINGS_KEY);
    if (!raw) return data;
    const saved = JSON.parse(raw);
    if (!saved || typeof saved !== 'object') return data;

    if (typeof saved.sens === 'number' && isFinite(saved.sens)) {
      data.sens = clampNum(saved.sens, CONFIG.SENS_MIN, CONFIG.SENS_MAX);
    }
    if (typeof saved.invertY === 'boolean') data.invertY = saved.invertY;
    if (typeof saved.vibration === 'boolean') data.vibration = saved.vibration;
    if (typeof saved.colorblind === 'boolean') data.colorblind = saved.colorblind;
    if (typeof saved.volMaster === 'number') {
      data.volMaster = clampNum(saved.volMaster, 0, 1);
    }
    if (typeof saved.volSfx === 'number') data.volSfx = clampNum(saved.volSfx, 0, 1);
    if (typeof saved.volUi === 'number') data.volUi = clampNum(saved.volUi, 0, 1);
    if (typeof saved.showFps === 'boolean') data.showFps = saved.showFps;
    if (saved.quality === 'auto' || saved.quality === 'high' || saved.quality === 'low') {
      data.quality = saved.quality;
    }
  } catch (e) {
    /* modo privado o JSON corrupto: se quedan los defaults */
  }
  return data;
}

/**
 * Módulo-ajustes (singleton): leer `settings.data`, escribir con
 * `settings.set(key, value)` (persiste) y `settings.reset()`.
 */
export const settings = {
  /** @type {object} valores vivos (no mutar a mano: usar set) */
  data: load(),

  /**
   * Cambia un ajuste, persiste y re-aplica lo que es live (CONFIG).
   * @param {string} key clave de SETTINGS_DEFAULTS
   * @param {boolean|number|string} value valor ya validado por la UI
   */
  set(key, value) {
    this.apply(key, value);
    this.save();
  },

  /**
   * Cambia un ajuste EN CALIENTE sin tocar el disco (arrastrar un slider
   * dispara decenas de eventos: persistir es cosa del 'change').
   * @param {string} key clave de SETTINGS_DEFAULTS
   * @param {boolean|number|string} value
   */
  apply(key, value) {
    if (!(key in SETTINGS_DEFAULTS)) return;
    this.data[key] = value;
    this.applyToConfig();
  },

  /** Persiste (tolerante a modo privado). */
  save() {
    try {
      localStorage.setItem(CONFIG.SETTINGS_KEY, JSON.stringify(this.data));
    } catch (e) {
      /* sin almacenamiento: los ajustes viven hasta recargar */
    }
  },

  /** Vuelve a los valores de fábrica y persiste. */
  reset() {
    this.data = { ...SETTINGS_DEFAULTS };
    this.save();
    this.applyToConfig();
  },

  /**
   * Vuelca los ajustes live en CONFIG (sensibilidad e inversión Y las
   * lee player.js en cada frame: cambiarlas aquí es inmediato).
   */
  applyToConfig() {
    CONFIG.CAMERA_SENSITIVITY = this.data.sens;
    CONFIG.INVERT_Y = !!this.data.invertY;
  },

  /**
   * Color de jugador tal y como debe VERLO este dispositivo.
   * @param {number} hex color asignado por el host (PLAYER_COLORS)
   * @returns {number} color remapeado si el modo daltonismo está activo
   */
  mapColor(hex) {
    if (!this.data.colorblind) return hex;
    return COLORBLIND_MAP[hex] !== undefined ? COLORBLIND_MAP[hex] : hex;
  },

  /**
   * Vibración háptica (si el ajuste lo permite y el navegador la tiene).
   * @param {number|number[]} pattern ms o patrón de ms
   */
  vibrate(pattern) {
    if (!this.data.vibration) return;
    try {
      if (typeof navigator.vibrate === 'function') navigator.vibrate(pattern);
    } catch (e) {
      /* algunos WebViews la lanzan sin permiso */
    }
  }
};

// Aplicación inicial (antes de que el jugador mueva la cámara)
settings.applyToConfig();
