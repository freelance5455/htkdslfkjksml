/**
 * WOLF-HUNTER · movement.js
 * Física de personaje COMPARTIDA entre el cliente (predicción) y el host
 * (simulación autoritativa). La Fase 1 la tenía dentro de player.js; para
 * la red hace falta que ambos lados ejecuten EXACTAMENTE el mismo código
 * con los mismos sub-pasos de tiempo, o la reconciliación nunca convergería.
 *
 * Reglas de determinismo (no tocar sin leer):
 *  · Nada de performance.now()/Date.now() dentro del paso: el tiempo llega
 *    como parámetro acumulado (ch.simTime) que avanza exactamente igual en
 *    ambos lados.
 *  · El buffer de salto y el "mantener pulsado" se deciden en el cliente y
 *    viajan como banderas del sub-paso (jump/hold), nunca se re-deciden aquí.
 *  · El orden de operaciones es fijo: mover → colisionar → suelo/salto →
 *    gravedad. Cambiarlo invalida las partidas en curso (versión +0.1).
 */

import * as THREE from 'three';
import { CONFIG } from '../config.js';
import { groundHeightAt, resolveCollisions } from './environment.js';

const JUMP_VELOCITY = Math.sqrt(2 * CONFIG.GRAVITY * CONFIG.JUMP_HEIGHT);
const HOLD_JUMP_S = 0.26; // re-salto manteniendo pulsado (determinista: en tiempo de simulación)
const MAP_BOUND = 26.5; // límite absoluto de seguridad (muros en ±24, radio 0.4)

// Objeto temporal reutilizado (cero allocations por paso)
const _pos = new THREE.Vector3();

/**
 * Crea el estado físico de un personaje en un punto de aparición.
 * @param {{x: number, z: number, yaw?: number}} point spawn
 * @returns {object} estado mutable del personaje
 */
export function createCharacter(point) {
  return {
    x: point.x,
    y: 0,
    z: point.z,
    velocityY: 0,
    grounded: true,
    yaw: point.yaw || 0,
    simTime: 0, // tiempo de simulación acumulado (determinista)
    lastJumpAt: -1e9 // en segundos de simTime
  };
}

/**
 * Copia el estado de un personaje sobre otro (reconciliación, respawn).
 * @param {object} dst destino
 * @param {object} src origen
 */
export function copyCharacter(dst, src) {
  dst.x = src.x;
  dst.y = src.y;
  dst.z = src.z;
  dst.velocityY = src.velocityY;
  dst.grounded = src.grounded;
  dst.yaw = src.yaw;
  dst.simTime = src.simTime;
  dst.lastJumpAt = src.lastJumpAt;
}

/**
 * Clona un estado de personaje.
 * @param {object} ch estado original
 * @returns {object} copia independiente
 */
export function cloneCharacter(ch) {
  const c = createCharacter({ x: ch.x, z: ch.z, yaw: ch.yaw });
  copyCharacter(c, ch);
  return c;
}

/**
 * Avanza la física de un personaje un sub-paso.
 *
 * Un "sub-paso" es la unidad mínima de simulación: el cliente simula un
 * sub-paso por frame (dt variable) y envía la lista exacta de sub-pasos en
 * cada INPUT; el host los reproduce en el mismo orden con los mismos dt,
 * lo que produce la MISMA trayectoria bit a bit.
 *
 * @param {object} ch estado del personaje (muta x, y, z, velocityY…)
 * @param {object} input sub-paso {mx, my, yaw, jump, hold}
 *   mx: strafe [-1..1] · my: adelante [-1..1] · yaw: orientación en rad
 *   jump: borde de pulsación de salto · hold: botón mantenido
 * @param {number} dt segundos del sub-paso (0.001..0.12)
 * @param {object} world mundo de environment.js
 * @param {number} speed velocidad máxima (HUNTER_SPEED / WOLF_SPEED)
 */
export function stepCharacter(ch, input, dt, world, speed) {
  ch.simTime += dt;
  ch.yaw = input.yaw;

  // 1) Movimiento horizontal relativo a la orientación
  const sin = Math.sin(ch.yaw);
  const cos = Math.cos(ch.yaw);
  const vx = (cos * input.mx - sin * input.my) * speed;
  const vz = (-sin * input.mx - cos * input.my) * speed;
  ch.x += vx * dt;
  ch.z += vz * dt;

  // 2) Colisión de cápsula (círculo en XZ) contra el mundo
  _pos.set(ch.x, ch.y, ch.z);
  resolveCollisions(world, _pos, CONFIG.PLAYER_RADIUS);
  ch.x = _pos.x;
  ch.z = _pos.z;

  // Cinturón de seguridad: jamás fuera del recinto (idéntico en ambos lados)
  if (ch.x < -MAP_BOUND) ch.x = -MAP_BOUND;
  if (ch.x > MAP_BOUND) ch.x = MAP_BOUND;
  if (ch.z < -MAP_BOUND) ch.z = -MAP_BOUND;
  if (ch.z > MAP_BOUND) ch.z = MAP_BOUND;

  // 3) Suelo, salto y gravedad
  const groundY = groundHeightAt(world, ch.x, ch.z, ch.y);

  if (ch.grounded) {
    const wantJump =
      input.jump ||
      (input.hold && ch.simTime - ch.lastJumpAt > HOLD_JUMP_S);
    if (wantJump) {
      ch.velocityY = JUMP_VELOCITY;
      ch.grounded = false;
      ch.lastJumpAt = ch.simTime;
    } else if (ch.y - groundY > CONFIG.STEP_HEIGHT + 0.02) {
      // caminó fuera de un borde
      ch.grounded = false;
    } else {
      // pegado al suelo: sube rampas y escalones de forma continua
      ch.y = groundY;
    }
  }

  if (!ch.grounded) {
    ch.velocityY = Math.max(ch.velocityY - CONFIG.GRAVITY * dt, -CONFIG.TERMINAL_VELOCITY);
    ch.y += ch.velocityY * dt;
    if (ch.velocityY <= 0 && ch.y <= groundY) {
      ch.y = groundY;
      ch.velocityY = 0;
      ch.grounded = true;
    }
  }
}

/**
 * Valida un sub-paso recibido por red antes de aplicarlo en el host.
 * Es la primera barrera anti-trampa: dt absurdos se descartan enteros.
 * @param {object} s sub-paso {dt, mx, my, yaw, jump, hold}
 * @returns {boolean} true si el sub-paso es aplicable
 */
export function isValidSubStep(s) {
  if (!s || typeof s !== 'object') return false;
  if (typeof s.dt !== 'number' || !Number.isFinite(s.dt)) return false;
  if (s.dt < 0.001 || s.dt > 0.12) return false;
  if (typeof s.mx !== 'number' || typeof s.my !== 'number') return false;
  if (Math.abs(s.mx) > 1.01 || Math.abs(s.my) > 1.01) return false;
  if (typeof s.yaw !== 'number' || !Number.isFinite(s.yaw)) return false;
  return true;
}
