/**
 * WOLF-HUNTER · sky.js
 * Cielo azul realista 100 % procedural (0 bytes de descarga):
 *
 *  · Cúpula con shader propio: gradiente cenit→horizonte, bruma baja y
 *    disco solar con halo (la dirección del sol coincide con la luz
 *    direccional de lighting.js para que las sombras casen).
 *  · Nubes: sprites con textura de gradiente radial dibujada en canvas,
 *    a la deriva lenta. Desactivables con CONFIG.SKY_CLOUDS = 0.
 *  · Niebla de escena acorde al horizonte: los muros lejanos se funden
 *    con el cielo (perspectiva aérea) en lugar de cortarse en negro.
 *
 * El shader mezcla en espacio lineal y convierte a sRGB al final
 * (mismos chunks que usan los materiales Lambert: colores coherentes).
 */
import * as THREE from 'three';
import { CONFIG } from '../config.js';

/** Dirección del sol, compartida con la luz direccional (normalizada). */
export const SUN_DIRECTION = new THREE.Vector3(22, 32, 14).normalize();

const VERT = /* glsl */ `
  varying vec3 vDir;
  void main() {
    vDir = position; // la cúpula está centrada en la cámara: posición ≈ dirección
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

const FRAG = /* glsl */ `
  varying vec3 vDir;
  uniform vec3 uTop;
  uniform vec3 uHorizon;
  uniform vec3 uBottom;
  uniform vec3 uSunColor;
  uniform vec3 uSunDir;
  void main() {
    vec3 d = normalize(vDir);
    // Gradiente: cenit arriba, bruma en el horizonte, neblina por debajo
    vec3 sky = mix(uHorizon, uTop, pow(clamp(d.y, 0.0, 1.0), 0.62));
    sky = mix(uBottom, sky, smoothstep(-0.10, 0.02, d.y));
    // Sol: disco nítido + halo suave hacia la dirección de la luz
    float sd = dot(d, uSunDir);
    float disc = smoothstep(0.99930, 0.99965, sd);
    float halo = pow(clamp(sd, 0.0, 1.0), 320.0) * 0.55
               + pow(clamp(sd, 0.0, 1.0), 12.0) * 0.10;
    vec3 col = sky + uSunColor * (disc * 1.25 + halo);
    gl_FragColor = vec4(col, 1.0);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

/** Dibuja un "copo" suave en un canvas y lo devuelve como textura. */
function makeCloudTexture() {
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const g = c.getContext('2d');
  const grad = g.createRadialGradient(64, 64, 8, 64, 64, 62);
  grad.addColorStop(0, 'rgba(255, 255, 255, 0.95)');
  grad.addColorStop(0.45, 'rgba(255, 255, 255, 0.55)');
  grad.addColorStop(1, 'rgba(255, 255, 255, 0)');
  g.fillStyle = grad;
  g.fillRect(0, 0, 128, 128);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/**
 * Construye el cielo y ajusta la niebla de la escena.
 * @param {THREE.Scene} scene escena del juego
 * @returns {{ update: (dt: number, camera: THREE.Camera) => void }}
 */
export function createSky(scene) {
  const uniforms = {
    uTop: { value: new THREE.Color(CONFIG.SKY_TOP) },
    uHorizon: { value: new THREE.Color(CONFIG.SKY_HORIZON) },
    uBottom: { value: new THREE.Color(CONFIG.SKY_BOTTOM) },
    uSunColor: { value: new THREE.Color(CONFIG.SKY_SUN) },
    uSunDir: { value: SUN_DIRECTION.clone() }
  };

  // Cúpula: esfera invertida grande, sin niebla ni escritura de profundidad
  const dome = new THREE.Mesh(
    new THREE.SphereGeometry(120, 32, 15),
    new THREE.ShaderMaterial({
      vertexShader: VERT,
      fragmentShader: FRAG,
      uniforms,
      side: THREE.BackSide,
      depthWrite: false,
      fog: false
    })
  );
  dome.frustumCulled = false; // siempre visible: es el fondo
  scene.add(dome);

  // Fondo de respaldo (color plano mientras la cúpula no cubre algún píxel)
  scene.background = new THREE.Color(CONFIG.SKY_HORIZON);

  // Niebla de escena acorde al horizonte (perspectiva aérea diurna)
  scene.fog = new THREE.Fog(CONFIG.SKY_FOG, CONFIG.SKY_FOG_NEAR, CONFIG.SKY_FOG_FAR);

  // Nubes a la deriva
  const cloudGroup = new THREE.Group();
  const cloudTex = makeCloudTexture();
  const cloudCount = Math.max(0, Math.floor(CONFIG.SKY_CLOUDS));
  for (let i = 0; i < cloudCount; i++) {
    const mat = new THREE.SpriteMaterial({
      map: cloudTex,
      transparent: true,
      opacity: 0.24 + Math.random() * 0.26,
      depthWrite: false,
      fog: false
    });
    const s = new THREE.Sprite(mat);
    const azimuth = Math.random() * Math.PI * 2;
    const elevation = (18 + Math.random() * 38) * (Math.PI / 180);
    const radius = 82 + Math.random() * 22;
    s.position.set(
      Math.cos(azimuth) * Math.cos(elevation) * radius,
      Math.sin(elevation) * radius,
      Math.sin(azimuth) * Math.cos(elevation) * radius
    );
    const size = 16 + Math.random() * 20;
    s.scale.set(size, size * (0.42 + Math.random() * 0.2), 1);
    cloudGroup.add(s);
  }
  scene.add(cloudGroup);

  /**
   * Anima el cielo: la cúpula sigue a la cámara y las nubes derivan.
   * @param {number} dt delta time en segundos
   * @param {THREE.Camera} camera cámara activa
   */
  function update(dt, camera) {
    dome.position.copy(camera.position);
    cloudGroup.rotation.y += dt * 0.0045;
  }

  return { update };
}
