/**
 * WOLF-HUNTER · main.js (Fase 2)
 * Raíz de composición: arranca el motor, construye el mundo, la cámara
 * (1ª/3ª persona), el cielo, el jugador local y la máquina de estados, y
 * ejecuta el bucle de render delegando la simulación en GameSession.
 *
 * Pantallas: Menú → Crear/Unirse → Lobby → Jugando → Menú.
 * Transversales cubiertos aquí:
 *  · webglcontextlost / webglcontextrestored
 *  · visibilitychange (pausa el render; el host degrada su tick, no muere)
 *  · botón Atrás de Android consciente del estado (menú/subpantalla/juego)
 *  · resize con visualViewport · watchdog de sombras · ?debug · ?netdebug
 */
import { CONFIG } from '../config.js';
import { GAME_VERSION, PHASE } from './version.js';
import { installGlobalErrorHandler, reportError } from './error-handler.js';
import { debug, FpsCounter } from './debug.js';
import { LoadingScreen } from './loading-screen.js';
import * as THREE from 'three';
import { setupLighting } from './lighting.js';
import { buildEnvironment } from './environment.js';
import { createSky } from './sky.js';
import { TouchInput } from './input.js';
import { CameraRig } from './camera.js';
import { LocalPlayer, DirectPhysics } from './player.js';
import { RemotePlayers } from './remote-players.js';
import { NetworkManager } from './network.js';
import { GameSession } from './game-session.js';
import { GameState, GameStateMachine, ScreenManager, SCREEN_OF } from './game-states.js';
import { ConnectionUI } from './ui-connection.js';
import { CombatHUD } from './hud.js';
import { CombatFX } from './fx.js';
import { BeastCore } from './beast-core.js';
import { loadName } from './player-names.js';
import { GameAudio } from './audio.js';
import { ViewModel } from './viewmodel.js';
import { SettingsMenu } from './settings-menu.js';
import { settings } from './settings.js';
import { OrientationManager } from './orientation.js';

installGlobalErrorHandler();

const loading = new LoadingScreen();
const t0 = performance.now();
debug.log(`WOLF-HUNTER v${GAME_VERSION} · Fase ${PHASE}`);

/** Espera un frame de pintado para que la pantalla de carga respire. */
function nextPaint() {
  return new Promise((resolve) => requestAnimationFrame(() => resolve()));
}

/**
 * Capacidades del dispositivo: decide pixelRatio y sombras sin preguntar.
 * @returns {{dpr:number, cores:number, touch:boolean, webgl2:boolean,
 *            shadows:boolean, pixelRatio:number, highDpr:boolean}}
 */
function detectCapabilities() {
  const dpr = window.devicePixelRatio || 1;
  const cores = navigator.hardwareConcurrency || 2;
  const touch = navigator.maxTouchPoints > 0 || matchMedia('(pointer: coarse)').matches;
  let webgl2 = false;
  try {
    webgl2 = !!document.createElement('canvas').getContext('webgl2');
  } catch (e) {
    webgl2 = false;
  }
  const shadows =
    CONFIG.SHADOWS === true ||
    (CONFIG.SHADOWS === 'auto' && webgl2 && cores >= 6 && dpr <= 2.6);
  const pixelRatio = Math.min(dpr, cores >= 6 ? 2 : 1.5);
  return { dpr, cores, touch, webgl2, shadows, pixelRatio, highDpr: dpr >= 2 };
}

/**
 * Crea el renderer WebGL con ajustes móviles.
 * @param {object} caps resultado de detectCapabilities
 * @param {object} orientation OrientationManager: viewport virtual
 *        (en modo girado las dimensiones están intercambiadas)
 * @returns {THREE.WebGLRenderer}
 */
function createRenderer(caps, orientation) {
  const canvas = document.getElementById('game-canvas');
  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: !caps.highDpr,
      powerPreference: 'high-performance'
    });
  } catch (e) {
    throw new Error('Este navegador no soporta WebGL: ' + (e.message || e));
  }
  const view = orientation.viewport();
  renderer.setPixelRatio(caps.pixelRatio);
  renderer.setSize(view.w, view.h, false);
  renderer.shadowMap.enabled = caps.shadows;
  renderer.shadowMap.type = THREE.PCFShadowMap;
  return renderer;
}

async function boot() {
  loading.setStep('Comprobando capacidades…', 0.08);
  await nextPaint();
  const caps = detectCapabilities();
  debug.log('Capacidades:', caps);

  // Gestor de orientación (0.4.1): botón «Girar pantalla» + modo
  // horizontal forzado. attach() va tras onResize (más abajo).
  const orientation = new OrientationManager();

  loading.setStep('Iniciando motor 3D…', 0.22);
  await nextPaint();
  const renderer = createRenderer(caps, orientation);
  const canvas = renderer.domElement;

  const scene = new THREE.Scene();

  const view0 = orientation.viewport();
  const camera = new THREE.PerspectiveCamera(
    CONFIG.HUNTER_FOV,
    view0.w / view0.h,
    CONFIG.CAMERA_NEAR,
    CONFIG.CAMERA_FAR
  );
  scene.add(camera);

  loading.setStep('Construyendo la arena…', 0.38);
  await nextPaint();
  const world = buildEnvironment(scene);

  loading.setStep('Encendiendo el cielo…', 0.52);
  await nextPaint();
  const sky = createSky(scene);
  setupLighting(scene, { shadows: caps.shadows });

  loading.setStep('Preparando controles…', 0.68);
  await nextPaint();
  const input = new TouchInput({
    moveZone: document.getElementById('zone-move'),
    lookZone: document.getElementById('zone-look'),
    joystick: document.getElementById('joystick'),
    knob: document.getElementById('joystick-knob'),
    jumpButton: document.getElementById('btn-jump'),
    fireButton: document.getElementById('btn-fire'),
    reloadButton: document.getElementById('btn-reload'),
    orientation // remapeo táctil en modo girado
  });
  input.attach();

  // Rig de cámara 1ª/3ª persona + jugador local (física directa al arrancar)
  const rig = new CameraRig({ camera, world });
  const player = new LocalPlayer({
    rig,
    world,
    input,
    physics: new DirectPhysics(world, () => CONFIG.HUNTER_SPEED)
  });
  scene.add(player.avatar.group);
  player.spawnAt(world.spawnPoints[0]); // coloca también la cámara de arranque

  // Vistas de combate de la Fase 3 (HUD, efectos, Núcleo) + red y sesión
  const hud = new CombatHUD();
  const fx = new CombatFX(scene);
  const beastCore = new BeastCore(scene, world);
  const remotes = new RemotePlayers(scene);
  const net = new NetworkManager();
  const machine = new GameStateMachine();
  const screens = new ScreenManager();

  // ── Fase 4: sonido sintetizado + brazos en primera persona ──
  const audio = new GameAudio();
  audio.setVolumes(settings.data); // volúmenes persistidos
  audio.attachUnlock(); // el primer gesto del usuario despierta el audio

  const viewmodel = new ViewModel({ camera });

  const session = new GameSession({
    net,
    world,
    localPlayer: player,
    remotePlayers: remotes,
    machine,
    hud,
    fx,
    beastCore,
    audio,
    viewmodel
  });

  // El botón del marcador (host) vuelve al lobby sin esperar al temporizador
  hud.onContinue = () => session.continueToLobby();

  // Las pantallas las abre/cierra la máquina de estados: nunca dos a la vez
  machine.on((from, to) => screens.show(SCREEN_OF[to] || null));

  // ───────────── Diálogos (aviso / confirmación) ─────────────
  const confirmOverlay = document.getElementById('confirm-overlay');
  const confirmTitle = document.getElementById('confirm-title');
  const confirmText = document.getElementById('confirm-text');
  const btnExit = document.getElementById('btn-exit');
  const btnStay = document.getElementById('btn-stay');
  let confirmAction = null;
  let dialogOpen = false;

  function closeConfirm() {
    confirmOverlay.removeAttribute('data-open');
    dialogOpen = false;
    confirmAction = null;
    btnExit.hidden = false;
    btnStay.hidden = false;
    btnExit.textContent = 'Salir';
    btnStay.textContent = 'Seguir jugando';
  }

  btnExit.addEventListener('click', () => {
    const a = confirmAction;
    closeConfirm();
    if (a) a();
  });
  btnStay.addEventListener('click', closeConfirm);

  /** Aviso informativo con un solo botón (Aceptar). */
  function showNotice(title, text) {
    confirmTitle.textContent = title;
    confirmText.textContent = text;
    btnExit.hidden = true;
    btnStay.hidden = false;
    btnStay.textContent = 'Aceptar';
    confirmAction = null;
    dialogOpen = true;
    confirmOverlay.setAttribute('data-open', '');
  }

  /** Confirmación para abandonar la partida hacia el menú. */
  function askToMenu() {
    confirmTitle.textContent = '¿Volver al menú?';
    confirmText.textContent = 'Se cerrará tu conexión con la sala.';
    btnExit.hidden = false;
    btnStay.hidden = false;
    btnExit.textContent = 'Salir al menú';
    btnStay.textContent = 'Quedarme';
    confirmAction = () => session.leave();
    dialogOpen = true;
    confirmOverlay.setAttribute('data-open', '');
  }

  /** Confirmación para cerrar la app (doble Atrás en el menú). */
  function askExitApp() {
    confirmTitle.textContent = '¿Salir de WOLF-HUNTER?';
    confirmText.textContent = 'Puedes volver cuando quieras.';
    btnExit.hidden = false;
    btnStay.hidden = false;
    btnExit.textContent = 'Salir';
    btnStay.textContent = 'Quedarme';
    confirmAction = () => {
      leavingApp = true;
      history.back();
      setTimeout(() => {
        if (leavingApp) {
          leavingApp = false;
          history.back();
        }
      }, 350);
    };
    dialogOpen = true;
    confirmOverlay.setAttribute('data-open', '');
  }

  session.onNotice = (title, text) => {
    if (title === null) {
      // Señal de "cierra el aviso" (anfitrión volvió)
      if (dialogOpen) closeConfirm();
    } else {
      showNotice(title, text);
    }
  };
  session.onStatus = (text) => ui.setStatusText(text);

  // ───────────── UI de conexión (menús + lobby) ─────────────
  const ui = new ConnectionUI({
    machine,
    delegate: {
      createRoom: async (pass) => {
        const code = await net.startHost({ name: loadName(), pass });
        session.becomeHost(code);
        ui.setLobby({ code, roster: net.roster, isHost: true });
      },
      joinRoom: async (code, pass) => {
        await net.join({ code, name: loadName(), pass });
        ui.setLobby({ code: net.code, roster: session.roster, isHost: false });
      },
      exploreSolo: () => session.startSolo(),
      startRound: () => session.startRound(),
      leave: () => session.leave(),
      cancelConnect: () => {
        net.destroy();
        machine.go(GameState.MENU);
      }
    }
  });

  // ───────────── Botón de cámara (1ª ↔ 3ª persona) ─────────────
  const btnCam = document.getElementById('btn-camera');
  const camHint = document.getElementById('cam-hint');
  let camHintTimer = 0;

  function flashCamHint(text) {
    camHint.textContent = text;
    camHint.classList.remove('show');
    void camHint.offsetWidth; // reinicia la animación
    camHint.classList.add('show');
    clearTimeout(camHintTimer);
    camHintTimer = setTimeout(() => camHint.classList.remove('show'), 1300);
  }

  btnCam.addEventListener('click', () => rig.toggle());
  rig.onModeChange = (mode) => {
    btnCam.classList.toggle('is-third', mode === 'third');
    btnCam.setAttribute('aria-pressed', String(mode === 'third'));
    flashCamHint(mode === 'third' ? 'Tercera persona' : 'Primera persona');
  };
  btnCam.classList.toggle('is-third', rig.mode === 'third');
  btnCam.setAttribute('aria-pressed', String(rig.mode === 'third'));

  // Tecla C (escritorio), sin robar teclas cuando se escribe el nombre
  window.addEventListener('keydown', (e) => {
    if (e.repeat) return;
    const tag = e.target && e.target.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA') return;
    if (e.code === 'KeyC') rig.toggle();
  });

  // HUD: escritorio sin táctil oculta joystick, salto y botones de combate
  const isCoarse = matchMedia('(pointer: coarse)').matches;
  if (isCoarse) {
    document.body.classList.add('touch-ui');
  } else {
    document.getElementById('joystick').style.display = 'none';
    document.getElementById('btn-jump').style.display = 'none';
    document.getElementById('hint-desktop').hidden = false;
  }

  // Contador de FPS (Fase 4: también conmutable desde Ajustes, sin ?fps)
  const fpsChip = document.getElementById('fps-chip');
  const fpsCounter = new FpsCounter(fpsChip); // barato: mide siempre
  const fpsVisible = () => debug.fpsEnabled || settings.data.showFps;
  fpsChip.hidden = !fpsVisible();

  // ───────────── Ajustes (Fase 4): overlay desde menú, lobby o partida ─────────────

  /**
   * Aplica la calidad gráfica pedida al renderer (Ajustes → Pantalla).
   * 'auto' restaura lo que detectó el arranque del dispositivo.
   * @param {'auto'|'high'|'low'} q
   */
  function applyQuality(q) {
    let pr;
    let sh;
    if (q === 'high') {
      pr = Math.min(caps.dpr, 2);
      sh = true;
    } else if (q === 'low') {
      pr = 1;
      sh = false;
    } else {
      pr = caps.pixelRatio;
      sh = caps.shadows;
    }
    renderer.setPixelRatio(pr);
    if (renderer.shadowMap.enabled !== sh) {
      renderer.shadowMap.enabled = sh;
      // Los materiales hay que recompilarlos al cambiar de idea sobre sombras
      scene.traverse((o) => {
        if (o.material) o.material.needsUpdate = true;
      });
    }
    debug.log(`[calidad] ${q} → dpr ${pr.toFixed(2)}, sombras ${sh ? 'sí' : 'no'}`);
  }

  const settingsMenu = new SettingsMenu({
    screens,
    audio,
    onQuality: applyQuality,
    onFps: (show) => {
      fpsChip.hidden = !(show || debug.fpsEnabled);
    },
    onColorblind: () => session.refreshColors(), // repinta avatares ya creados
    onOpen: () => input.releaseAll() // la partida sigue: suelta los dedos
  });

  // Ajustes persistidos que no son los de por defecto: aplicar ya
  if (settings.data.quality !== 'auto') applyQuality(settings.data.quality);

  // Clic de interfaz audible en todos los botones de pantallas + engranaje
  // (los interruptores suenan aparte, con su propia altura de tono)
  document.addEventListener(
    'click',
    (e) => {
      const b = e.target.closest('.screen button, .gear-btn');
      if (b && !b.classList.contains('switch')) audio.uiClick();
    },
    true
  );

  // ───────────── Refrescos periódicos (chip red, lobby, netdebug) ─────────────
  const netChip = document.getElementById('net-chip');
  const netDebugEl = document.getElementById('netdebug');
  const netDebugOn = CONFIG.SHOW_NET_DEBUG || new URLSearchParams(location.search).has('netdebug');
  if (netDebugOn) netDebugEl.hidden = false;

  setInterval(() => {
    // Chip de red del HUD
    if (session.mode === 'host' || session.mode === 'client') {
      const info = session.getHudInfo();
      netChip.hidden = false;
      const tail = info.role === 'client' ? ` · ${info.rtt} ms` : ' · anfitrión';
      netChip.textContent = `Sala ${info.code} · ${info.players}/4${tail}`;
    } else {
      netChip.hidden = true;
    }

    // Lobby: roster fresco (host desde su red; cliente desde el STATE)
    if (machine.current === 'lobby' && session.mode) {
      ui.setLobby({
        code: net.code,
        roster: session.mode === 'host' ? net.roster : session.roster,
        isHost: session.mode === 'host'
      });
    }

    // Overlay de depuración de red
    if (netDebugOn) {
      const d = session.getNetDebug();
      netDebugEl.textContent =
        `modo ${d.mode || '—'} · sala ${d.code || '—'}\n` +
        `jugadores ${d.players} · avatares ${d.remoteAvatars}\n` +
        `rtt ${d.rtt} ms · offset ${d.offset} ms\n` +
        `in ${d.msgsIn} · out ${d.msgsOut} · tick ${d.tickHz} Hz\n` +
        `inputs pendientes ${d.pendingInputs} · reconciliaciones ${d.hardReconciles}`;
    }
  }, 500);

  loading.setStep('Listo', 1);
  await nextPaint();
  await loading.finish();
  debug.log(`Arranque completo en ${(performance.now() - t0).toFixed(0)} ms`);

  // Al menú, salvo que un deep-link ?join=CODE ya haya abierto la pantalla
  // de unirse durante la construcción de la UI.
  if (!machine.current) machine.go(GameState.MENU);

  // ───────────────────── Bucle de render ─────────────────────
  const clock = new THREE.Clock();
  let rafId = 0;
  let running = false;
  let elapsed = 0;
  let shadowsKilled = false;

  let wdFrames = 0;
  let wdTime = 0;
  let wdStrikes = 0;

  function frame() {
    rafId = requestAnimationFrame(frame);
    const dt = Math.min(clock.getDelta(), CONFIG.MAX_DELTA_S);
    elapsed += dt;

    session.update(dt); // jugador + red + remotos + combate (Fase 3)
    sky.update(dt, camera); // la cúpula sigue a la cámara
    renderer.render(scene, camera);
    if (fpsCounter) fpsCounter.tick(dt);

    if (caps.shadows && !shadowsKilled && elapsed < 15) {
      wdFrames += 1;
      wdTime += dt;
      if (wdTime >= 2) {
        const fps = wdFrames / wdTime;
        wdFrames = 0;
        wdTime = 0;
        if (fps < 30) {
          wdStrikes += 1;
          if (wdStrikes >= 2) {
            shadowsKilled = true;
            renderer.shadowMap.enabled = false;
            scene.traverse((o) => {
              if (o.material) o.material.needsUpdate = true;
            });
            debug.warn(`Sombras desactivadas por rendimiento (FPS medio ${fps.toFixed(0)})`);
          }
        }
      }
    }
  }

  function startLoop() {
    if (running) return;
    running = true;
    clock.getDelta(); // descarta el tiempo acumulado en pausa
    rafId = requestAnimationFrame(frame);
  }

  function stopLoop() {
    running = false;
    if (rafId) cancelAnimationFrame(rafId);
    rafId = 0;
  }

  // ───────────────────── Eventos de ciclo de vida ─────────────────────

  function onResize() {
    // Viewport VIRTUAL: en modo horizontal forzado las dimensiones
    // físicas están intercambiadas y el renderer debe pensar en horizontal.
    const view = orientation.viewport();
    camera.aspect = view.w / view.h;
    camera.updateProjectionMatrix();
    renderer.setSize(view.w, view.h, false);
    input._onResize();
  }
  window.addEventListener('resize', onResize);
  window.addEventListener('orientationchange', onResize);
  if (window.visualViewport) {
    window.visualViewport.addEventListener('resize', onResize);
  }

  // Botón de rotación operativo desde ya: si este navegador ya usó el
  // modo forzado, attach() lo re-activa y dispara onResize él solo.
  orientation.onViewportChange = onResize;
  orientation.attach();

  // Pestaña oculta: pausa el render y suelta los dedos. La red sigue:
  // el host degrada su tick a ~1 Hz con flag `paused` y el cliente deja
  // de enviar INPUT (su avatar se congela para los demás, sin errores).
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      stopLoop();
      input.releaseAll();
      debug.log('Pestaña oculta: render en pausa');
    } else {
      startLoop();
      debug.log('Pestaña visible: render reanudado');
    }
  });

  canvas.addEventListener('webglcontextlost', (e) => {
    e.preventDefault();
    stopLoop();
    showNotice('Restaurando gráficos…', 'El sistema liberó la GPU. El juego se reanuda solo.');
    debug.warn('webglcontextlost');
  });
  canvas.addEventListener('webglcontextrestored', () => {
    closeConfirm();
    startLoop();
    debug.log('webglcontextrestored: render reanudado');
  });

  // Botón Atrás de Android, consciente del estado del juego
  installBackGuard();

  startLoop();

  // Gancho de QA/depuración
  if (debug.enabled) {
    window.__wolf = {
      version: GAME_VERSION,
      phase: PHASE,
      CONFIG,
      caps,
      session,
      net,
      machine,
      player,
      world,
      rig,
      remotes,
      input,
      hud,
      fx,
      beastCore,
      audio,
      viewmodel,
      settingsMenu,
      orientation,
      renderer,
      scene,
      camera,
      ui,
      ready: true
    };
  }

  // ───────────── Guardia del botón Atrás ─────────────

  let leavingApp = false;

  function installBackGuard() {
    const push = () => history.pushState({ wolf: 1 }, '', location.href);
    push();

    window.addEventListener('popstate', () => {
      if (leavingApp) {
        leavingApp = false;
        history.back(); // segunda pulsación: salida real
        return;
      }
      if (settingsMenu.isOpen) {
        settingsMenu.close(); // Atrás cierra Ajustes antes de nada
        push();
        return;
      }
      if (dialogOpen) {
        closeConfirm();
        push();
        return;
      }
      const st = machine.current;
      if (st === GameState.PLAYING || st === GameState.LOBBY || st === GameState.CONNECTING) {
        askToMenu();
        push();
        return;
      }
      if (st === GameState.HOST_SETUP || st === GameState.JOIN) {
        machine.go(GameState.MENU);
        push();
        return;
      }
      // En el menú: confirmar antes de salir de la app
      askExitApp();
      push();
    });
  }
}

boot().catch((err) => {
  debug.error('Fallo de arranque:', err);
  loading.fail('No se pudo iniciar el juego');
  reportError({
    message: 'Fallo de arranque: ' + (err && err.message ? err.message : String(err)),
    stack: err && err.stack ? err.stack : ''
  });
});
