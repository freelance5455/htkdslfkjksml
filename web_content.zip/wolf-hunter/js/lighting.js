/**
 * WOLF-HUNTER · lighting.js
 * Iluminación base optimizada para móvil: hemisférica (ambiente barato) +
 * direccional con sombra opcional de mapa 1024 en un frustum ajustado.
 * Los materiales del mapa son Lambert (sin PBR): iluminación estable y barata.
 */
import * as THREE from 'three';

/**
 * Configura las luces de la escena.
 * @param {THREE.Scene} scene escena del juego
 * @param {{shadows?: boolean}} [opts] sombras dinámicas on/off
 * @returns {{ dirLight: THREE.DirectionalLight }} luces creadas
 */
export function setupLighting(scene, opts = {}) {
  const shadows = opts.shadows === true;

  // Ambiente: cielo frío arriba, rebote cálido del suelo abajo.
  // Intensidades calibradas con sondas de píxel: el suelo de la plaza queda
  // a ~1.4× su albedo (legible) sin quemar las caras iluminadas.
  const hemi = new THREE.HemisphereLight(0xaebfe4, 0x3a352e, 2.2);
  hemi.position.set(0, 30, 0);
  scene.add(hemi);

  // Sol: dirección cálida, ligeramente rasante para modelar el blockout
  const dirLight = new THREE.DirectionalLight(0xffe9d0, 3.2);
  dirLight.position.set(22, 32, 14);
  dirLight.target.position.set(0, 0, 0);
  scene.add(dirLight);
  scene.add(dirLight.target);

  if (shadows) {
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.set(1024, 1024);
    const cam = dirLight.shadow.camera;
    // Frustum ortográfico justo al tamaño de la arena (±26) para no
    // desperdificar texels de sombra
    cam.left = -26;
    cam.right = 26;
    cam.top = 26;
    cam.bottom = -26;
    cam.near = 4;
    cam.far = 70;
    cam.updateProjectionMatrix();
    dirLight.shadow.bias = -0.0006;
    dirLight.shadow.normalBias = 0.02;
  }

  return { dirLight };
}
