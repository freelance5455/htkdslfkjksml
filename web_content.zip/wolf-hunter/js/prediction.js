/**
 * WOLF-HUNTER · prediction.js
 * Predicción del lado cliente + reconciliación con el host autoritativo.
 *
 * Funcionamiento (el estándar de los FPS, adaptado a WebRTC):
 *
 *  1. Cada frame el cliente simula su física localmente (stepCharacter con
 *     el MISMO código que usa el host) y guarda el sub-paso aplicado.
 *  2. Cada 50 ms (INPUT_SEND_HZ) los sub-pasos acumulados se empaquetan en
 *     un INPUT con número de secuencia; se conserva el resultado previsto
 *     (posición tras aplicar ese paquete) en `pending`.
 *  3. El STATE del host llega con `you.seq` (último paquete procesado) y
 *     la posición AUTORITATIVA tras ese paquete.
 *  4. Se compara con la prevista: error grande → se adopta la del host y
 *     SE REPRODUCEN los paquetes aún no confirmados encima (replay).
 *     Error pequeño → corrección suave por interpolación (imperceptible).
 *
 * Como ambos lados ejecutan exactamente los mismos sub-pasos con los
 * mismos dt (movement.js es determinista), el error debería ser 0 salvo
 * teleport/respawn, pérdida de paquetes o manipulación: eso es justo lo
 * que la reconciliación dura repara.
 */

import { CONFIG } from '../config.js';
import { createCharacter, stepCharacter } from './movement.js';

const MAX_PENDING = 40; // ~2 s de histórico a 20 Hz: suficiente para cualquier RTT de WiFi

export class PredictedController {
  /**
   * @param {object} deps
   * @param {object} deps.world mundo de environment.js
   * @param {() => number} deps.speedFn velocidad máxima actual
   */
  constructor({ world, speedFn }) {
    this.world = world;
    this.speedFn = speedFn;
    this.character = createCharacter({ x: 0, z: 0 });

    /** @type {Array<{seq:number, steps:Array, res:{x:number,y:number,z:number}}>} */
    this.pending = [];
    /** Sub-pasos simulados que aún no viajaron en un INPUT. */
    this._current = [];
    this._seq = 0;
    /** Resincronización pendiente (transformación). */
    this._resync = false;

    this.stats = { pending: 0, lastError: 0, hardReconciles: 0, packets: 0 };
  }

  /**
   * Un sub-paso de simulación local (llamar una vez por frame).
   * @param {{mx:number, my:number, yaw:number, jump?:boolean, hold?:boolean}} input
   * @param {number} dt segundos
   */
  step(input, dt) {
    const s = {
      dt,
      mx: input.mx,
      my: input.my,
      yaw: input.yaw,
      jump: !!input.jump,
      hold: !!input.hold
    };
    this._current.push(s);
    stepCharacter(this.character, s, dt, this.world, this.speedFn());
    this.stats.pending = this.pending.length + (this._current.length ? 1 : 0);
  }

  /**
   * Cierra el paquete actual y lo devuelve listo para enviar.
   * @returns {?{seq:number, steps:Array}} null si no hay nada que enviar
   */
  flush() {
    if (!this._current.length) return null;
    this._seq += 1;
    const entry = {
      seq: this._seq,
      steps: this._current,
      res: { x: this.character.x, y: this.character.y, z: this.character.z }
    };
    this._current = [];
    this.pending.push(entry);
    while (this.pending.length > MAX_PENDING) this.pending.shift();
    this.stats.packets += 1;
    this.stats.pending = this.pending.length;
    return { seq: entry.seq, steps: entry.steps };
  }

  /**
   * Corrección autoritativa recibida en STATE.you.
   * @param {number} seqAck último paquete procesado por el host
   * @param {number} ax posición autoritativa x
   * @param {number} ay posición autoritativa y
   * @param {number} az posición autoritativa z
   */
  reconcile(seqAck, ax, ay, az) {
    // Resincronización pedida (transformación: la velocidad cambia a mitad
    // de paquete y el replay dejaría deriva): se adopta el estado del host
    // y se borra lo no confirmado.
    if (this._resync) {
      this._resync = false;
      this._snapTo(ax, ay, az);
      this.stats.hardReconciles += 1;
      return;
    }

    const idx = this.pending.findIndex((e) => e.seq === seqAck);

    if (idx === -1) {
      // ACK de un paquete que ya salió del buffer (throttling extremo del
      // navegador o lag spike): solo corrige si el ERROR REAL lo pide,
      // no dispara snaps fantasma cuando la física ya coincide.
      const err = Math.hypot(
        this.character.x - ax,
        this.character.y - ay,
        this.character.z - az
      );
      this.stats.lastError = err;
      if (err > CONFIG.RECONCILE_HARD_M) {
        this._snapTo(ax, ay, az);
        this.stats.hardReconciles += 1;
      } else if (err > CONFIG.RECONCILE_SOFT_M) {
        this.character.x += (ax - this.character.x) * 0.35;
        this.character.y += (ay - this.character.y) * 0.35;
        this.character.z += (az - this.character.z) * 0.35;
      }
      return;
    }

    const entry = this.pending[idx];
    const err = Math.hypot(entry.res.x - ax, entry.res.y - ay, entry.res.z - az);
    this.stats.lastError = err;

    if (err > CONFIG.RECONCILE_HARD_M) {
      // Error grave: estado host + replay de lo no confirmado
      this._snapTo(ax, ay, az);
      for (let i = idx + 1; i < this.pending.length; i++) {
        const e = this.pending[i];
        for (const s of e.steps) {
          stepCharacter(this.character, s, s.dt, this.world, this.speedFn());
        }
        e.res.x = this.character.x;
        e.res.y = this.character.y;
        e.res.z = this.character.z;
      }
      // Y los sub-pasos que aún no se enviaron (siguen siendo válidos)
      for (const s of this._current) {
        stepCharacter(this.character, s, s.dt, this.world, this.speedFn());
      }
      this.stats.hardReconciles += 1;
    } else if (err > CONFIG.RECONCILE_SOFT_M) {
      // Deriva mínima: corrección suave (35 % por STATE; converge en <1 s)
      this.character.x += (ax - entry.res.x) * 0.35;
      this.character.y += (ay - entry.res.y) * 0.35;
      this.character.z += (az - entry.res.z) * 0.35;
    }

    // Retira lo confirmado
    this.pending.splice(0, idx + 1);
    this.stats.pending = this.pending.length;
  }

  /**
   * Teleport incondicional (spawn de ronda, respawn de la Fase 3).
   * @param {{x:number, z:number, yaw?:number}} point destino
   */
  spawnAt(point) {
    this.character = createCharacter(point);
    this.pending.length = 0;
    this._current.length = 0;
    this._resync = false;
    this.stats.pending = 0;
  }

  /**
   * Pide una resincronización total con el próximo STATE.you (lo usa la
   * Fase 3 al transformarse: la velocidad cambia y el replay histórico
   * dejaría una deriva molesta).
   */
  markResync() {
    this._resync = true;
  }

  /** Adopta una posición autoritativa sin replay. */
  _snapTo(x, y, z) {
    this.character.x = x;
    this.character.y = y;
    this.character.z = z;
    this.character.velocityY = 0;
    this.character.grounded = true;
    this.pending.length = 0;
    this._current.length = 0;
  }
}
