/**
 * WOLF-HUNTER · fx.js
 * Efectos visuales de combate, todos PROCEDURALES y con pool (cero
 * allocations por disparo: en un móvil de gama baja el GC no puede entrar
 * en mitad de un tiroteo).
 *
 *  · Trazadora: caja finísima aditiva estirada del origen al impacto,
 *    vida ~90 ms (lo que tarda una bala hipersónica en "leerse").
 *  · Zarpazo: arco horizontal delante del lobo que se expande y apaga
 *    en ~180 ms.
 *
 * Los disparos del propio jugador se pintan SOLO con el SHOOT_FX del host
 * (el punto de impacto autoritativo puede diferir del previsto por el aim
 * assist); el zarpazo propio sí se pinta al instante para que la garra
 * responda en el mismo frame que el dedo.
 */

import * as THREE from 'three';

const TRACER_POOL = 10;
const TRACER_LIFE = 0.09;
const TRACER_THICK = 0.022;
const CLAW_POOL = 5;
const CLAW_LIFE = 0.18;

/** Un objeto efímero del pool: malla + reloj de vida. */
function makePooledMesh(geometry, material) {
  const mesh = new THREE.Mesh(geometry, material);
  mesh.visible = false;
  mesh.frustumCulled = false;
  return mesh;
}

export class CombatFX {
  /** @param {THREE.Scene} scene */
  constructor(scene) {
    this.scene = scene;

    // ── Trazadoras ──
    const tracerGeo = new THREE.BoxGeometry(TRACER_THICK, TRACER_THICK, 1);
    this._tracers = [];
    for (let i = 0; i < TRACER_POOL; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xffd9a8,
        transparent: true,
        opacity: 0,
        depthWrite: false,
        blending: THREE.AdditiveBlending
      });
      const m = makePooledMesh(tracerGeo, mat);
      this._tracers.push({ mesh: m, life: 0 });
      scene.add(m);
    }

    // ── Zarpazos: arco plano centrado en el frente (-Z tras el giro) ──
    const arc = 1.7; // radianes de barrido
    const clawGeo = new THREE.RingGeometry(0.55, 1.45, 20, 1, Math.PI / 2 - arc / 2, arc);
    this._claws = [];
    for (let i = 0; i < CLAW_POOL; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xf3f6ff,
        transparent: true,
        opacity: 0,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide
      });
      const m = makePooledMesh(clawGeo, mat);
      m.rotation.x = -Math.PI / 2; // el anillo pasa al plano horizontal
      this._claws.push({ mesh: m, life: 0 });
      scene.add(m);
    }

    this._dir = new THREE.Vector3();
    this._mid = new THREE.Vector3();
    this._q = new THREE.Quaternion();
    this._fwd = new THREE.Vector3(0, 0, 1);
  }

  /** Busca un slot libre (o el más viejo si todos viven). */
  static _slot(pool) {
    let best = null;
    for (const p of pool) {
      if (p.life <= 0) return p;
      if (!best || p.life < best.life) best = p;
    }
    return best;
  }

  /**
   * Trazadora de un disparo aceptado.
   * @param {number} ox,oy,oz origen (boca/cámara del tirador)
   * @param {number} ex,ey,ez fin del rayo (muro, jugador o alcance máximo)
   */
  tracer(ox, oy, oz, ex, ey, ez) {
    const p = CombatFX._slot(this._tracers);
    this._dir.set(ex - ox, ey - oy, ez - oz);
    const len = this._dir.length();
    if (len < 0.05) return;
    this._dir.divideScalar(len);
    this._mid.set((ox + ex) / 2, (oy + ey) / 2, (oz + ez) / 2);
    p.mesh.position.copy(this._mid);
    p.mesh.quaternion.setFromUnitVectors(this._fwd, this._dir);
    p.mesh.scale.set(1, 1, len);
    p.mesh.material.opacity = 0.9;
    p.mesh.visible = true;
    p.life = TRACER_LIFE;
  }

  /**
   * Arco de zarpazo delante de un lobo.
   * @param {number} x posición X de los pies del lobo
   * @param {number} z posición Z de los pies del lobo
   * @param {number} yaw orientación del lobo (rad)
   */
  claw(x, z, yaw) {
    const p = CombatFX._slot(this._claws);
    p.mesh.position.set(x, 0.95, z);
    p.mesh.rotation.set(-Math.PI / 2, 0, 0);
    p.mesh.rotateZ(yaw); // el arco nace mirando a -Z (frente del lobo)
    p.mesh.scale.setScalar(0.75);
    p.mesh.material.opacity = 0.85;
    p.mesh.visible = true;
    p.life = CLAW_LIFE;
  }

  /**
   * Avanza los relojes de vida y apaga lo caducado.
   * @param {number} dt delta time en segundos
   */
  update(dt) {
    for (const p of this._tracers) {
      if (p.life <= 0) continue;
      p.life -= dt;
      p.mesh.material.opacity = Math.max(0, p.life / TRACER_LIFE) * 0.9;
      if (p.life <= 0) p.mesh.visible = false;
    }
    for (const p of this._claws) {
      if (p.life <= 0) continue;
      p.life -= dt;
      const u = 1 - p.life / CLAW_LIFE; // 0→1
      p.mesh.scale.setScalar(0.75 + u * 0.45); // se expande al barrer
      p.mesh.material.opacity = Math.max(0, p.life / CLAW_LIFE) * 0.85;
      if (p.life <= 0) p.mesh.visible = false;
    }
  }

  /** Apaga todo (fin de ronda / salida al menú). */
  clear() {
    for (const p of [...this._tracers, ...this._claws]) {
      p.life = 0;
      p.mesh.visible = false;
    }
  }

  /** Libera GPU. */
  dispose() {
    const geos = new Set();
    const mats = new Set();
    for (const p of [...this._tracers, ...this._claws]) {
      this.scene.remove(p.mesh);
      geos.add(p.mesh.geometry);
      mats.add(p.mesh.material);
    }
    for (const g of geos) g.dispose();
    for (const m of mats) m.dispose();
  }
}
