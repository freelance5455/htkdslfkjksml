/**
 * WOLF-HUNTER · player.js
 * Jugador local: rotación de cámara (táctil/ratón/teclado), muestreo de
 * entrada y delegación de la física en un "motor" intercambiable:
 *
 *  · DirectPhysics      → juego solo y ANFITRIÓN (la física local ES la
 *                         autoridad, no hay nada que reconciliar).
 *  · PredictedController→ CLIENTE (predicción + reconciliación, Fase 2).
 *
 * El avatar geométrico propio solo se dibuja cuando la cámara está (o va
 * camino de) la tercera persona; la etiqueta de nombre nunca (es uno mismo).
 */
import * as THREE from 'three';
import { CONFIG } from '../config.js';
import { createCharacter, stepCharacter } from './movement.js';
import { createAvatar } from './avatar.js';

const PITCH_LIMIT = 1.51; // ≈ 86.5°: evita el volteo de la cámara
const LOOK_SENS = 0.0042; // rad por "px táctil" antes de CAMERA_SENSITIVITY

/** Acota un valor al rango [min, max]. */
function clamp(v, min, max) {
  return v < min ? min : v > max ? max : v;
}

/**
 * Motor de física directa: simula y listo (solo / anfitrión).
 */
export class DirectPhysics {
  /**
   * @param {object} world mundo de environment.js
   * @param {() => number} speedFn velocidad máxima actual
   */
  constructor(world, speedFn) {
    this.world = world;
    this.speedFn = speedFn;
    this.character = createCharacter({ x: 0, z: 0 });
  }

  /** @param {object} input @param {number} dt */
  step(input, dt) {
    stepCharacter(this.character, input, dt, this.world, this.speedFn());
  }

  /**
   * Teleport (spawn).
   * @param {{x:number, z:number, yaw?:number}} point
   */
  spawnAt(point) {
    this.character = createCharacter(point);
  }
}

export class LocalPlayer {
  /**
   * @param {object} deps
   * @param {object} deps.rig CameraRig (cámara 1ª/3ª persona)
   * @param {object} deps.world mundo de environment.js
   * @param {object} deps.input instancia de TouchInput
   * @param {object} deps.physics motor de física (DirectPhysics | PredictedController)
   * @param {() => number} [deps.speedFn] velocidad para la animación del avatar
   */
  constructor({ rig, world, input, physics, speedFn }) {
    this.rig = rig;
    this.world = world;
    this.input = input;
    this.physics = physics;
    this.speedFn = speedFn || (() => CONFIG.HUNTER_SPEED);

    this.yaw = 0;
    this.pitch = 0;

    /** Vivo (false = muerto: la mirada sigue, el cuerpo no se mueve). */
    this.alive = true;

    // Avatar propio (visible solo en 3ª persona). El scene lo añade
    // quien construye el jugador (main.js).
    this.avatar = createAvatar({ color: 0xd8dee9, name: '', showLabel: false });
    this.avatar.group.visible = false;

    this._lastInputMag = 0;
  }

  /** @returns {object} el estado del personaje del motor de física actual */
  get character() {
    return this.physics.character;
  }

  /**
   * Magnitud de movimiento del último frame (0..1) — la lee el HUD para
   * abrir el retículo y el viewmodel para el balanceo (Fase 4).
   * @returns {number}
   */
  get inputMag() {
    return this._lastInputMag;
  }

  /**
   * Cambia el motor de física (p. ej. Direct → Predicted al entrar como
   * cliente a una sala).
   * @param {object} physics nuevo motor
   */
  setPhysics(physics) {
    this.physics = physics;
  }

  /**
   * Coloca al jugador en un punto de aparición.
   * @param {{x: number, z: number, yaw: number}} point spawn orientado
   */
  spawnAt(point) {
    this.physics.spawnAt(point);
    this.yaw = point.yaw;
    this.pitch = 0;
    this._syncVisuals(0);
  }

  /**
   * Avanza un frame: mira, mueve, anima y coloca la cámara.
   * @param {number} dt delta time en segundos (ya acotado por MAX_DELTA_S)
   */
  update(dt) {
    const input = this.input;

    // 1) Rotación de cámara (client-side siempre: el host no valida ángulos)
    const look = input.consumeLook();
    const sens = LOOK_SENS * CONFIG.CAMERA_SENSITIVITY;
    this.yaw -= look.dx * sens;
    const invert = CONFIG.INVERT_Y ? -1 : 1;
    this.pitch = clamp(this.pitch - invert * look.dy * sens, -PITCH_LIMIT, PITCH_LIMIT);

    // 2) Entrada del frame → un sub-paso de física
    //    Muerto: sub-pasos NULOS pero SE SIMULAN igual en cliente y host
    //    (misma física → reconciliación exacta; el respawn teleporta).
    const mv = this.alive ? input.getMove() : { x: 0, y: 0 };
    const step = {
      mx: mv.x,
      my: mv.y,
      yaw: this.yaw,
      jump: this.alive ? input.consumeJump(performance.now()) : false,
      hold: this.alive ? input.jumpHeld : false
    };
    this.physics.step(step, dt);
    this._lastInputMag = Math.hypot(mv.x, mv.y);

    // 3) Cámara y avatar
    this._syncVisuals(dt);
  }

  /** Coloca cámara + avatar según el estado físico actual. */
  _syncVisuals(dt) {
    const ch = this.physics.character;

    // Cámara (1ª/3ª persona con transición y anti-muros)
    this.rig.update(dt, ch, this.pitch);

    // Avatar propio: visible en (o transitando hacia) 3ª persona, o muerto
    // (cámara de muerte: uno ve su propio cuerpo caído)
    const show = this.rig.blend > 0.02 || !this.alive;
    this.avatar.group.visible = show;
    if (show) {
      this.avatar.group.position.set(ch.x, ch.y, ch.z);
      this.avatar.setYaw(ch.yaw);
      const speed01 = this._lastInputMag * (this.speedFn() / CONFIG.HUNTER_SPEED);
      this.avatar.setWalk(speed01, dt, ch.grounded);
    }
  }

  /**
   * Posición de los ojos (origen de disparos en la Fase 3).
   * @param {THREE.Vector3} [out]
   * @returns {THREE.Vector3}
   */
  getEyePosition(out = new THREE.Vector3()) {
    return this.rig.getEyePosition(out);
  }
}
