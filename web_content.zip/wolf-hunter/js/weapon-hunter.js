/**
 * WOLF-HUNTER · weapon-hunter.js
 * El arma del Hunter: hitscan de una sola arma con cargador de 8 + reserva
 * de 24 y recarga manual de 1,5 s (ver docs/wolfteam-analysis.md §6: el
 * límite de balas es lo que hace importar la puntería).
 *
 * Flujo de un disparo:
 *  1. El jugador mantiene DISPARAR → el arma consume una bala LOCAL al
 *     instante (el HUD responde en el mismo frame) y envía SHOOT con el
 *     origen en los ojos y la dirección asistida.
 *  2. El host valida TODO (cadencia con su reloj, munición con SU contador,
 *     origen cerca del personaje autoritativo) y difunde SHOOT_FX con el
 *     punto de impacto real: la trazadora se pinta con ese punto, nunca con
 *     el previsto, para no mentir sobre aciertos.
 *
 * Aim assist (táctil): si el retículo cae cerca de un rival, la dirección
 * se desvía sutilmente hacia su centro (AIM_ASSIST_STRENGTH). Es ayuda de
 * pulso, no auto-apuntado: no corrige una puntería equivocada.
 */

import * as THREE from 'three';
import { CONFIG } from '../config.js';
import { AmmoState } from './ammo.js';
import { msgShoot, msgReload } from './protocol.js';

const ASSIST_MAX_ANGLE = (12 * Math.PI) / 180; // tope del cono de captura

export class HunterWeapon {
  /**
   * @param {object} deps
   * @param {object} deps.hud CombatHUD (munición y avisos)
   * @param {(msg:object) => void} deps.send Sale del SHOOT/RELOAD (red o host local)
   * @param {() => void} [deps.onFire] disparo consumido (audio + viewmodel, Fase 4)
   * @param {() => void} [deps.onReload] recarga iniciada (audio + viewmodel, Fase 4)
   */
  constructor({ hud, send, onFire, onReload }) {
    this.hud = hud;
    this._send = send;
    this._onFire = onFire || null;
    this._onReload = onReload || null;
    this.ammo = new AmmoState();
    this._seq = 0;
    this._lastShotAt = -1e9;
    this._dir = new THREE.Vector3();
    this._toTarget = new THREE.Vector3();
  }

  /** Munición llena (respawn / inicio de ronda). */
  reset() {
    this.ammo.reset();
    this._lastShotAt = -1e9;
    this._paint();
  }

  /**
   * Bucle del arma (forma Hunter, vivo y con la ronda en marcha).
   * @param {number} dt delta en segundos
   * @param {number} now performance.now()
   * @param {object} ctx
   * @param {boolean} ctx.fireHeld botón/clic de disparar mantenido
   * @param {THREE.Vector3} ctx.eye origen del rayo (ojos del jugador local)
   * @param {THREE.Vector3} ctx.dir dirección de mirada NORMALIZADA
   * @param {Array<{pos:THREE.Vector3, alive:boolean}>} ctx.targets rivales
   */
  update(dt, now, ctx) {
    void dt; // la cadencia va por reloj absoluto, no por delta
    this.ammo.update(now); // cierra la recarga LOCAL vencida (solo no tiene STATE)
    if (ctx.fireHeld) this._tryFire(now, ctx);
    this._paint();
  }

  /**
   * Recarga manual (botón RECARGAR o tecla R).
   * @param {number} now performance.now()
   */
  reload(now) {
    if (!this.ammo.startReload(now)) return;
    this._send(msgReload(this._seq++));
    if (this._onReload) this._onReload();
    this._paint();
  }

  /**
   * Disparo (con auto-recarga al apretar el gatillo en vacío).
   * @param {number} now
   * @param {object} ctx ver update()
   */
  _tryFire(now, ctx) {
    if (now - this._lastShotAt < CONFIG.BULLET_COOLDOWN_MS) return;
    if (!this.ammo.canFire(now)) {
      // Gatillo en vacío: la recarga arranca sola (1,5 s de vulnerabilidad)
      this.reload(now);
      return;
    }

    this.ammo.consume(now);
    this._lastShotAt = now;

    // Feedback local inmediato (Fase 4): el arma responde en el mismo
    // frame que el dedo; el host confirmará con SHOOT_FX a los demás.
    if (this._onFire) this._onFire();

    const dir = this._assist(ctx.eye, ctx.dir, ctx.targets);
    this._send(
      msgShoot(this._seq++, ctx.eye.x, ctx.eye.y, ctx.eye.z, dir.x, dir.y, dir.z)
    );
  }

  /**
   * Desvío sutil hacia el rival más alineado con la mira.
   * @param {THREE.Vector3} eye
   * @param {THREE.Vector3} dir dirección de mira
   * @param {Array<{pos:THREE.Vector3, alive:boolean}>} targets
   * @returns {THREE.Vector3} dirección final (normalizada)
   */
  _assist(eye, dir, targets) {
    this._dir.copy(dir);
    if (CONFIG.AIM_ASSIST_STRENGTH <= 0 || !targets || !targets.length) {
      return this._dir;
    }

    let best = null; // {angle, to}
    for (const t of targets) {
      if (!t.alive) continue;
      this._toTarget.copy(t.pos);
      this._toTarget.y += 0.9; // centro de masa de la cápsula
      this._toTarget.sub(eye);
      const dist = this._toTarget.length();
      if (dist < 0.8 || dist > CONFIG.BULLET_RANGE) continue;
      this._toTarget.divideScalar(dist);
      const angle = Math.acos(Math.min(1, Math.max(-1, this._dir.dot(this._toTarget))));
      // Cono de captura: radio de captura a la distancia del blanco
      const limit = Math.min(ASSIST_MAX_ANGLE, Math.atan2(CONFIG.AIM_ASSIST_RADIUS, dist));
      if (angle > limit) continue;
      if (!best || angle < best.angle) best = { angle, to: this._toTarget };
    }

    if (best) {
      // Mezcla leve hacia el centro del blanco (nunca un 100 %)
      this._dir.lerp(best.to, CONFIG.AIM_ASSIST_STRENGTH).normalize();
    }
    return this._dir;
  }

  /**
   * Adopción de la munición autoritativa del STATE.you (con el margen de
   * la recarga local para no pisar la animación en curso).
   * @param {number} mag
   * @param {number} reserve
   * @param {number} now performance.now()
   */
  syncFromState(mag, reserve, now) {
    this.ammo.adopt(mag, reserve, now);
    this._paint();
  }

  /** Refresca el HUD de munición. */
  _paint() {
    this.hud.setAmmo(this.ammo.mag, this.ammo.reserve, this.ammo.reloading);
  }
}
