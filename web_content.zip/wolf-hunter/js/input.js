/**
 * WOLF-HUNTER · input.js
 * Entrada táctil multitouch real (pointerId independientes) + teclado/ratón
 * de desarrollo para escritorio.
 *
 *  · Joystick dinámico: aparece DONDE tocas en la zona izquierda.
 *  · Fase TRACK (skill gestures): el knob sigue al dedo 1:1 sin transición.
 *  · Fase RELEASE: al levantar el dedo, CSS anima el retorno (interruptible).
 *  · Zona derecha: arrastre = rotación de cámara; puntero fino adicional:
 *    clic captura el ratón (pointer lock), Esc libera.
 *  · Espacio / botón = salto con buffer de 160 ms (perdona pulsaciones
 *    ligeramente anticipadas, como en los FPS de móvil).
 *  · Fase 3: botón DISPARAR (mantener = fuego automático al ritmo del
 *    cargador), botón RECARGAR, tecla R y clic del ratón capturado.
 */

const MOVE_RADIUS_PX = 42; // recorrido máximo del knob
const DEADZONE = 0.14; // zona muerta del joystick
const JUMP_BUFFER_MS = 160; // ventana de buffer de salto
const MOUSE_FACTOR = 0.5; // 1 px de ratón ≈ 0.5 px de arrastre táctil
const JOYSTICK_SIZE = 116; // px (coincide con styles.css)

/** Lee los safe-area insets resueltos por CSS (0 si no aplican). */
function safeInsets() {
  const cs = getComputedStyle(document.documentElement);
  const num = (v) => parseFloat(v) || 0;
  return {
    left: num(cs.getPropertyValue('--safe-l')),
    bottom: num(cs.getPropertyValue('--safe-b'))
  };
}

export class TouchInput {
  /**
   * @param {object} refs elementos del HUD
   * @param {HTMLElement} refs.moveZone zona izquierda (joystick)
   * @param {HTMLElement} refs.lookZone zona derecha (cámara)
   * @param {HTMLElement} refs.joystick contenedor del joystick
   * @param {HTMLElement} refs.knob knob del joystick
   * @param {HTMLElement} refs.jumpButton botón de salto
   * @param {HTMLElement} [refs.fireButton] botón de disparo/zarpazo (Fase 3)
   * @param {HTMLElement} [refs.reloadButton] botón de recarga (Fase 3)
   */
  constructor(refs) {
    this.moveZone = refs.moveZone;
    this.lookZone = refs.lookZone;
    this.joystick = refs.joystick;
    this.knob = refs.knob;
    this.jumpButton = refs.jumpButton;
    this.fireButton = refs.fireButton || null;
    this.reloadButton = refs.reloadButton || null;

    // Estado del joystick
    this.movePointer = -1;
    this.moveOrigin = { x: 0, y: 0 };
    this.moveVec = { x: 0, y: 0 }; // x: strafe, y: adelante

    // Estado de la cámara
    this.lookPointer = -1;
    this.lookLast = { x: 0, y: 0 };
    this.lookAcc = { x: 0, y: 0 }; // px acumulados sin consumir

    // Teclado, salto y combate
    this.keys = new Set();
    this.jumpHeld = false;
    this.jumpAt = -1e9;
    this.fireHeld = false;
    this.reloadRequested = false;

    this.homeX = 0;
    this.homeY = 0;
    this._onResize = this._onResize.bind(this);
    this._bound = [];
  }

  /** Registra todos los listeners. Idempotente. */
  attach() {
    if (this._bound.length) return;
    const add = (target, type, fn, opts) => {
      target.addEventListener(type, fn, opts);
      this._bound.push([target, type, fn, opts]);
    };

    // — Joystick (zona izquierda) —
    add(this.moveZone, 'pointerdown', (e) => this._onMoveDown(e));
    add(this.moveZone, 'pointermove', (e) => this._onMoveMove(e));
    add(this.moveZone, 'pointerup', (e) => this._onMoveUp(e));
    add(this.moveZone, 'pointercancel', (e) => this._onMoveUp(e));
    add(this.moveZone, 'lostpointercapture', (e) => this._onMoveUp(e));

    // — Cámara (zona derecha; también acepta arrastre de ratón sin lock) —
    add(this.lookZone, 'pointerdown', (e) => this._onLookDown(e));
    add(this.lookZone, 'pointermove', (e) => this._onLookMove(e));
    add(this.lookZone, 'pointerup', (e) => this._onLookUp(e));
    add(this.lookZone, 'pointercancel', (e) => this._onLookUp(e));
    add(this.lookZone, 'lostpointercapture', (e) => this._onLookUp(e));

    // — Botón de salto —
    add(this.jumpButton, 'pointerdown', (e) => this._onJumpDown(e));
    add(this.jumpButton, 'pointerup', () => this._onJumpUp());
    add(this.jumpButton, 'pointercancel', () => this._onJumpUp());
    add(this.jumpButton, 'lostpointercapture', () => this._onJumpUp());

    // — Disparo/Zarpazo (Fase 3): mantener = automático —
    if (this.fireButton) {
      add(this.fireButton, 'pointerdown', (e) => this._onFireDown(e));
      add(this.fireButton, 'pointerup', () => this._onFireUp());
      add(this.fireButton, 'pointercancel', () => this._onFireUp());
      add(this.fireButton, 'lostpointercapture', () => this._onFireUp());
    }

    // — Recarga (Fase 3) —
    if (this.reloadButton) {
      add(this.reloadButton, 'pointerdown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.reloadRequested = true;
      });
    }

    // — Teclado (modo desarrollo en escritorio) —
    add(window, 'keydown', (e) => this._onKeyDown(e));
    add(window, 'keyup', (e) => this._onKeyUp(e));

    // — Ratón con captura (pointer lock) —
    add(this.lookZone, 'click', () => this._tryLockPointer());
    add(document, 'mousemove', (e) => this._onMouseMove(e));
    add(document, 'mousedown', (e) => this._onMouseDown(e));
    add(document, 'mouseup', (e) => this._onMouseUp(e));

    // — Robustez: gestos del navegador y pérdida de foco —
    add(window, 'blur', () => this.releaseAll());
    add(document, 'contextmenu', (e) => e.preventDefault());
    add(document, 'gesturestart', (e) => e.preventDefault());
    add(window, 'resize', this._onResize);

    this._onResize();
  }

  /** Desregistra todos los listeners (tests). */
  detach() {
    for (const [t, type, fn, opts] of this._bound) t.removeEventListener(type, fn, opts);
    this._bound = [];
  }

  /** Recoloca el punto de reposo del joystick (resize / rotación). */
  _onResize() {
    const insets = safeInsets();
    this.homeX = 30 + insets.left;
    this.homeY = window.innerHeight - 30 - JOYSTICK_SIZE - insets.bottom;
    if (this.movePointer === -1) this._placeBase(this.homeX, this.homeY);
  }

  // ═════════════════════ Joystick ═════════════════════

  _onMoveDown(e) {
    if (this.movePointer !== -1) return; // multitouch: un solo joystick
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    e.preventDefault();
    this.movePointer = e.pointerId;
    this.moveZone.setPointerCapture(e.pointerId);
    this.moveOrigin.x = e.clientX;
    this.moveOrigin.y = e.clientY;
    // El joystick nace donde tocas: aparición inmediata, sin viaje
    this._placeBase(e.clientX - JOYSTICK_SIZE / 2, e.clientY - JOYSTICK_SIZE / 2);
    this.joystick.classList.add('is-active');
    this._setKnob(0, 0);
    this._setJoystick(0, 0);
  }

  _onMoveMove(e) {
    if (e.pointerId !== this.movePointer) return;
    e.preventDefault();
    let dx = e.clientX - this.moveOrigin.x;
    let dy = e.clientY - this.moveOrigin.y;
    const len = Math.hypot(dx, dy);
    if (len > MOVE_RADIUS_PX) {
      // Fase TRACK: seguimiento 1:1 con tope circular (el knob no escapa)
      dx = (dx / len) * MOVE_RADIUS_PX;
      dy = (dy / len) * MOVE_RADIUS_PX;
    }
    this._setKnob(dx, dy);
    this._setJoystick(dx, dy);
  }

  _onMoveUp(e) {
    if (e.pointerId !== this.movePointer) return;
    this.movePointer = -1;
    this.moveVec.x = 0;
    this.moveVec.y = 0;
    // RELEASE: quitamos .is-active → CSS anima knob al centro y base a casa
    this.joystick.classList.remove('is-active');
    this._setKnob(0, 0);
    this._placeBase(this.homeX, this.homeY);
  }

  /** Vector de movimiento desde píxeles del knob (con zona muerta). */
  _setJoystick(dx, dy) {
    const vx = dx / MOVE_RADIUS_PX;
    const vy = -dy / MOVE_RADIUS_PX; // arriba del pantalla = adelante
    const m = Math.hypot(vx, vy);
    if (m < DEADZONE) {
      this.moveVec.x = 0;
      this.moveVec.y = 0;
      return;
    }
    const scaled = Math.min(1, (m - DEADZONE) / (1 - DEADZONE));
    this.moveVec.x = (vx / m) * scaled;
    this.moveVec.y = (vy / m) * scaled;
  }

  /** Coloca la base (top-left) con transform (compositor, no layout). */
  _placeBase(x, y) {
    this.joystick.style.transform = `translate3d(${x}px, ${y}px, 0)`;
  }

  /** Coloca el knob relativo al centro de la base. */
  _setKnob(dx, dy) {
    this.knob.style.transform = `translate3d(${dx}px, ${dy}px, 0)`;
  }

  // ═════════════════════ Cámara ═════════════════════

  _onLookDown(e) {
    if (this.lookPointer !== -1) return;
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    e.preventDefault();
    this.lookPointer = e.pointerId;
    this.lookZone.setPointerCapture(e.pointerId);
    this.lookLast.x = e.clientX;
    this.lookLast.y = e.clientY;
  }

  _onLookMove(e) {
    if (e.pointerId !== this.lookPointer) return;
    e.preventDefault();
    const f = e.pointerType === 'mouse' ? MOUSE_FACTOR : 1;
    this.lookAcc.x += (e.clientX - this.lookLast.x) * f;
    this.lookAcc.y += (e.clientY - this.lookLast.y) * f;
    this.lookLast.x = e.clientX;
    this.lookLast.y = e.clientY;
  }

  _onLookUp(e) {
    if (e.pointerId !== this.lookPointer) return;
    this.lookPointer = -1;
  }

  _tryLockPointer() {
    // Solo con puntero fino: en táctil no tiene sentido capturar
    if (!matchMedia('(pointer: fine)').matches) return;
    if (document.pointerLockElement) return;
    const p = this.lookZone.requestPointerLock();
    if (p && p.catch) p.catch(() => { /* iframe o permiso denegado: seguimos con arrastre */ });
  }

  _onMouseMove(e) {
    if (!document.pointerLockElement) return;
    this.lookAcc.x += e.movementX * MOUSE_FACTOR;
    this.lookAcc.y += e.movementY * MOUSE_FACTOR;
  }

  // Clic con el ratón YA capturado = disparar (Fase 3)
  _onMouseDown(e) {
    if (!document.pointerLockElement) return;
    if (e.button !== 0) return;
    this.fireHeld = true;
  }

  _onMouseUp(e) {
    if (e.button !== 0) return;
    this.fireHeld = false;
  }

  // ═════════════════════ Teclado y salto ═════════════════════

  _onKeyDown(e) {
    if (e.repeat) return;
    switch (e.code) {
      case 'Space':
        e.preventDefault();
        this.jumpHeld = true;
        this.jumpAt = performance.now();
        break;
      case 'KeyR':
        this.reloadRequested = true;
        break;
      case 'ArrowUp':
      case 'ArrowDown':
      case 'ArrowLeft':
      case 'ArrowRight':
        e.preventDefault();
        this.keys.add(e.code);
        break;
      case 'KeyW': case 'KeyA': case 'KeyS': case 'KeyD':
        this.keys.add(e.code);
        break;
      default:
        break;
    }
  }

  _onKeyUp(e) {
    if (e.code === 'Space') this.jumpHeld = false;
    this.keys.delete(e.code);
  }

  _onJumpDown(e) {
    e.preventDefault();
    this.jumpHeld = true;
    this.jumpAt = performance.now();
  }

  _onJumpUp() {
    this.jumpHeld = false;
  }

  _onFireDown(e) {
    e.preventDefault();
    e.stopPropagation(); // el botón NUNCA gira la cámara
    this.fireHeld = true;
  }

  _onFireUp() {
    this.fireHeld = false;
  }

  // ═════════════════════ API de consumo por frame ═════════════════════

  /**
   * Vector de movimiento combinado (joystick + WASD), magnitud ≤ 1.
   * x: strafe derecho positivo; y: adelante positivo.
   * @returns {{x: number, y: number}}
   */
  getMove() {
    let x = this.moveVec.x;
    let y = this.moveVec.y;
    if (this.keys.size) {
      x += (this.keys.has('KeyD') || this.keys.has('ArrowRight') ? 1 : 0) -
        (this.keys.has('KeyA') || this.keys.has('ArrowLeft') ? 1 : 0);
      y += (this.keys.has('KeyW') || this.keys.has('ArrowUp') ? 1 : 0) -
        (this.keys.has('KeyS') || this.keys.has('ArrowDown') ? 1 : 0);
    }
    const m = Math.hypot(x, y);
    if (m > 1) {
      x /= m;
      y /= m;
    }
    return { x, y };
  }

  /**
   * Consume el arrastre acumulado de cámara desde la última llamada.
   * @returns {{dx: number, dy: number}} píxeles equivalentes de táctil
   */
  consumeLook() {
    const out = { dx: this.lookAcc.x, dy: this.lookAcc.y };
    this.lookAcc.x = 0;
    this.lookAcc.y = 0;
    return out;
  }

  /**
   * Consume el buffer de salto si sigue vivo.
   * @param {number} now performance.now() del frame actual
   * @returns {boolean} true si hay un salto pendiente de ejecutar
   */
  consumeJump(now) {
    if (now - this.jumpAt <= JUMP_BUFFER_MS) {
      this.jumpAt = -1e9;
      return true;
    }
    return false;
  }

  /**
   * Consume la petición de recarga (botón o tecla R).
   * @returns {boolean}
   */
  consumeReload() {
    if (this.reloadRequested) {
      this.reloadRequested = false;
      return true;
    }
    return false;
  }

  /** Libera todo el estado (pestaña oculta, pérdida de foco, gestures). */
  releaseAll() {
    this.movePointer = -1;
    this.lookPointer = -1;
    this.moveVec.x = 0;
    this.moveVec.y = 0;
    this.lookAcc.x = 0;
    this.lookAcc.y = 0;
    this.keys.clear();
    this.jumpHeld = false;
    this.fireHeld = false;
    this.reloadRequested = false;
    this.joystick.classList.remove('is-active');
    this._setKnob(0, 0);
    this._placeBase(this.homeX, this.homeY);
  }
}
