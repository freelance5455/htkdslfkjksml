/**
 * WOLF-HUNTER · score.js
 * Marcador de la ronda: pura contabilidad, cero THREE y cero red.
 *
 * Puntos (modo Cacería por Oleadas):
 *  · SCORE_PER_KILL por cada eliminación.
 *  · SCORE_PER_WOLF_SECOND por cada segundo COMPLETO sobrevivido como Wolf:
 *    convertirse en lobo es el premio que hay que arrebatarle al rival,
 *    así que aguantar la transformación es lo que más puntúa.
 *
 * El host es el único que escribe; el mensaje ROUND_END lleva la lista ya
 * ordenada y con el total calculado.
 */

import { CONFIG } from '../config.js';

export class ScoreBoard {
  constructor() {
    /** @type {Map<number, {id:number, name:string, color:number, kills:number, wolfMs:number}>} */
    this.map = new Map();
  }

  /**
   * (Re)crea el marcador con el roster de la ronda.
   * @param {Array<{id:number,name:string,color:number}>} roster
   */
  reset(roster) {
    this.map.clear();
    for (const p of roster) {
      this.map.set(p.id, {
        id: p.id,
        name: p.name,
        color: p.color,
        kills: 0,
        wolfMs: 0
      });
    }
  }

  /**
   * Una eliminación.
   * @param {number} id autor de la baja
   */
  addKill(id) {
    const e = this.map.get(id);
    if (e) e.kills += 1;
  }

  /**
   * Tiempo sobrevivido como Wolf (lo acumula el tick del host).
   * @param {number} id jugador
   * @param {number} ms milisegundos transcurridos desde el tick anterior
   */
  addWolfTime(id, ms) {
    const e = this.map.get(id);
    if (e) e.wolfMs += ms;
  }

  /**
   * Puntos totales de una entrada.
   * @param {{kills:number, wolfMs:number}} e
   * @returns {number}
   */
  static scoreOf(e) {
    return (
      e.kills * CONFIG.SCORE_PER_KILL +
      Math.floor(e.wolfMs / 1000) * CONFIG.SCORE_PER_WOLF_SECOND
    );
  }

  /**
   * Lista para el mensaje ROUND_END: ordenada por puntos (desc) y lista
   * para pintar el marcador tal cual.
   * @returns {Array<{id:number,name:string,color:number,kills:number,wolfSec:number,score:number}>}
   */
  build() {
    const out = [];
    for (const e of this.map.values()) {
      out.push({
        id: e.id,
        name: e.name,
        color: e.color,
        kills: e.kills,
        wolfSec: Math.floor(e.wolfMs / 1000),
        score: ScoreBoard.scoreOf(e)
      });
    }
    out.sort((a, b) => b.score - a.score || b.kills - a.kills || a.id - b.id);
    return out;
  }
}
