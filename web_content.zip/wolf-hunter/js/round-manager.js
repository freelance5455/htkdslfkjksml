/**
 * WOLF-HUNTER · round-manager.js
 * El ÁRBITRO autoritativo del modo Cacería por Oleadas (Fase 3). Vive en
 * el host (y en modo Explorar solo, con la misma clase). Nada de esto se
 * ejecuta en los clientes: ellos piden (SHOOT/CLAW/RELOAD) y pintan lo que
 * el árbitro difunde.
 *
 * EL MODO (docs/wolfteam-analysis.md §2, §5):
 *  · Ronda de ROUND_DURATION_MS, todos contra todos, UN solo lobo activo.
 *  · El Núcleo de Fiera aparece en el pedestal central: recogerlo te
 *    transforma en Wolf durante WOLF_DURATION_MS (cura a 180 HP: un
 *    momento de poder, como en Wolfteam).
 *  · Si el lobo MUERE, suelta el Núcleo donde cayó → siguiente oleada.
 *  · Si el lobo SOBREVIVE su tiempo, vuelve a ser Hunter y el Núcleo
 *    regresa al pedestal → la cacería sigue rodando.
 *  · Puntos: SCORE_PER_KILL por baja + SCORE_PER_WOLF_SECOND por segundo
 *    completo sobrevivido como lobo.
 *
 * ANTI-TRAMAS (todo se valida aquí):
 *  · Disparo: cadencia con el reloj del host, munición con el contador del
 *    host, origen a menos de SHOOT_ORIGIN_TOLERANCE_M del personaje
 *    autoritativo, dirección normalizada.
 *  · Zarpazo: solo en forma lobo, cadencia, arco y alcance reales.
 *  · Invulnerabilidad de respawn: se pierde al disparar.
 *
 * El campo `mode` ('round' | 'solo') existe para poder añadir Deathmatch
 * por equipos más adelante sin refactorizar (decisión del análisis).
 */

import { CONFIG } from '../config.js';
import * as THREE from 'three';
import { AmmoState } from './ammo.js';
import { ScoreBoard } from './score.js';
import { raycastColliders } from './environment.js';
import {
  msgShootFx,
  msgClawFx,
  msgHit,
  msgDeath,
  msgRespawn,
  msgCoreSpawn,
  msgCorePickup,
  msgTransform,
  msgRoundEnd
} from './protocol.js';
import { debug } from './debug.js';

/** Medio arco del zarpazo (rad) precalculado. */
const CLAW_HALF_ARC = ((CONFIG.CLAW_ARC_DEG / 2) * Math.PI) / 180;

// Temporales reutilizados (cero allocations por disparo)
const _origin = new THREE.Vector3();
const _dir = new THREE.Vector3();

/**
 * Interseca un rayo con la esfera de impacto de un jugador (cápsula
 * aproximada por su esfera de torso: generosa, amable con el pulso táctil).
 * @param {number} ox,oy,oz origen del rayo
 * @param {number} dx,dy,dz dirección NORMALIZADA
 * @param {number} cx,cy,cz centro de la esfera
 * @param {number} r radio
 * @returns {?number} distancia al impacto o null
 */
function raySphere(ox, oy, oz, dx, dy, dz, cx, cy, cz, r) {
  const px = ox - cx;
  const py = oy - cy;
  const pz = oz - cz;
  const b = px * dx + py * dy + pz * dz;
  const c = px * px + py * py + pz * pz - r * r;
  const disc = b * b - c;
  if (disc < 0) return null;
  const t = -b - Math.sqrt(disc);
  return t > 0.05 ? t : null; // 5 cm de margen: no pegarse a uno mismo
}

export class RoundManager {
  /**
   * @param {object} deps
   * @param {object} deps.world mundo de environment.js
   * @param {Map<number, object>} deps.chars id → personaje simulado (vivos, mutables)
   * @param {(msg:object) => void} deps.emit difunde un mensaje (red + vista local del host)
   * @param {'round'|'solo'} [deps.mode='round']
   */
  constructor({ world, chars, emit, mode = 'round' }) {
    this.world = world;
    this.chars = chars;
    this._emit = emit;
    this.mode = mode;

    this.score = new ScoreBoard();

    /** @type {Map<number, object>} id → estado de combate */
    this._p = new Map();
    /** Núcleo activo en el mundo. */
    this.core = { active: false, x: 0, z: 0 };
    /** Ronda en marcha (modo 'round'). */
    this.round = { active: false, endsAt: 0 };
    this._lastTickAt = 0;
  }

  // ═══════════════════════ Ciclo de ronda ═══════════════════════

  /**
   * Nueva ronda (host) o nuevo paseo (solo): todo a cero y el Núcleo al
   * pedestal. El ROUND_START lo emite GameSession (necesita los spawns).
   * @param {Array<{id:number,name:string,color:number}>} roster
   * @param {number} now reloj del host
   */
  reset(roster, now) {
    this._p.clear();
    for (const r of roster) this.addPlayer(r.id);
    this.score.reset(roster);

    this.core.active = false;
    this._spawnCoreAt(this.world.pedestalPosition.x, this.world.pedestalPosition.z);

    this.round.active = this.mode === 'round';
    this.round.endsAt = now + CONFIG.ROUND_DURATION_MS;
    this._lastTickAt = now;
  }

  /** Fin/abandono: no más ticks de combate (el Núcleo lo oculta la vista). */
  stop() {
    this.round.active = false;
    this.core.active = false;
  }

  /**
   * Añade un jugador al combate (uniones en lobby).
   * @param {number} id
   */
  addPlayer(id) {
    if (this._p.has(id)) return;
    this._p.set(id, {
      hp: CONFIG.HUNTER_HP,
      wolf: false,
      wolfUntil: 0,
      dead: false,
      respawnAt: 0,
      invulnUntil: 0,
      lastShotAt: -1e9,
      lastClawAt: -1e9,
      ammo: new AmmoState()
    });
  }

  /**
   * Elimina a un jugador (se fue). Su línea de marcador sobrevive para el
   * ROUND_END; su estado de combate no (no respawnea un fantasma).
   * @param {number} id
   */
  removePlayer(id) {
    this._p.delete(id);
  }

  /**
   * Tick autoritativo (lo llama el host en cada STATE; en solo, cada frame).
   * @param {number} now reloj del host (performance.now del host)
   */
  tick(now) {
    const dt = now - this._lastTickAt;
    this._lastTickAt = now;
    if (dt <= 0 || dt > 2000) return; // salto gigante (pestaña dormida): no puntúa

    for (const [id, v] of this._p) {
      v.ammo.update(now); // cierra recargas vencidas (STATE.you las verá)

      // Expiración de la transformación: el lobo aguanta y vuelve
      if (v.wolf && !v.dead && now >= v.wolfUntil) {
        v.wolf = false;
        v.hp = Math.min(v.hp, CONFIG.HUNTER_HP); // el traje humano no guarda 180
        this._emit(msgTransform({ id, wolf: false, endsAt: 0 }));
        // La oleada sigue: el Núcleo vuelve al pedestal
        this._spawnCoreAt(this.world.pedestalPosition.x, this.world.pedestalPosition.z);
      }

      // Puntos por segundo sobrevivido como lobo
      if (v.wolf && !v.dead) this.score.addWolfTime(id, dt);

      // Reapariciones
      if (v.dead && now >= v.respawnAt) this._respawn(id, v, now);
    }

    // Recogida del Núcleo (el más cercano dentro del anillo; solo vivos)
    if (this.core.active) {
      let taker = -1;
      let bestD2 = Infinity;
      for (const [id, v] of this._p) {
        if (v.dead) continue;
        const ch = this.chars.get(id);
        if (!ch) continue;
        const dx = ch.x - this.core.x;
        const dz = ch.z - this.core.z;
        const d2 = dx * dx + dz * dz;
        if (d2 <= CONFIG.CORE_PICKUP_RANGE * CONFIG.CORE_PICKUP_RANGE && d2 < bestD2) {
          bestD2 = d2;
          taker = id;
        }
      }
      if (taker !== -1) this._pickupCore(taker, now);
    }

    // Fin de ronda
    if (this.round.active && now >= this.round.endsAt) {
      this.round.active = false;
      this.core.active = false;
      this._emit(msgRoundEnd({ scores: this.score.build() }));
      debug.log('[round] fin de ronda');
    }
  }

  /** Reaparición: spawn más lejos del peligro + invulnerabilidad breve. */
  _respawn(id, v, now) {
    const sp = this._safestSpawn(id);
    v.dead = false;
    v.hp = CONFIG.HUNTER_HP;
    v.wolf = false;
    v.invulnUntil = now + CONFIG.RESPAWN_INVULNERABILITY_MS;
    v.ammo.reset();
    v.lastShotAt = -1e9;
    v.lastClawAt = -1e9;

    // Teleport autoritativo del personaje (host: mismo objeto que simula)
    const ch = this.chars.get(id);
    if (ch) {
      ch.x = sp.x;
      ch.y = 0;
      ch.z = sp.z;
      ch.velocityY = 0;
      ch.grounded = true;
      ch.yaw = sp.yaw;
    }

    this._emit(msgRespawn({ id, x: sp.x, z: sp.z, yaw: sp.yaw }));
  }

  /** Punto de aparición más alejado de los demás jugadores vivos. */
  _safestSpawn(selfId) {
    const spawns = this.world.spawnPoints;
    let best = spawns[0];
    let bestScore = -1;
    for (const sp of spawns) {
      let nearest = Infinity;
      for (const [id, v] of this._p) {
        if (id === selfId || v.dead) continue;
        const ch = this.chars.get(id);
        if (!ch) continue;
        nearest = Math.min(nearest, Math.hypot(ch.x - sp.x, ch.z - sp.z));
      }
      if (nearest > bestScore) {
        bestScore = nearest;
        best = sp;
      }
    }
    return best;
  }

  // ═══════════════════════ Núcleo y transformación ═══════════════════════

  /** Aparece el Núcleo en un punto y lo anuncia. */
  _spawnCoreAt(x, z) {
    this.core.active = true;
    this.core.x = x;
    this.core.z = z;
    this._emit(msgCoreSpawn({ x, z }));
  }

  /**
   * El lobo abandonó la partida: el Núcleo cae donde estaba para que la
   * oleada no se quede atascada sin él.
   * @param {number} x
   * @param {number} z
   */
  dropCoreAt(x, z) {
    if (this.core.active) return; // ya hay uno en juego
    this._spawnCoreAt(x, z);
  }

  /** Limpia los estados de combate (vuelta al lobby) sin emitir nada. */
  clearCombat() {
    this._p.clear();
    this.core.active = false;
    this.round.active = false;
  }

  /**
   * Recogida validada: transformación en momento de poder (cura completa).
   * @param {number} id afortunado
   * @param {number} now
   */
  _pickupCore(id, now) {
    const v = this._p.get(id);
    if (!v || v.wolf) return;
    this.core.active = false;
    v.wolf = true;
    v.wolfUntil = now + CONFIG.WOLF_DURATION_MS;
    v.hp = CONFIG.WOLF_HP; // transformarse cura: se siente poderoso
    this._emit(msgCorePickup({ id }));
    this._emit(msgTransform({ id, wolf: true, endsAt: v.wolfUntil }));
    debug.log(`[round] #${id} recogió el Núcleo`);
  }

  // ═══════════════════════ Peticiones de los clientes ═══════════════════════

  /**
   * SHOOT validado → daño hitscan. Devuelve true si el disparo salió.
   * @param {number} id tirador
   * @param {{ox:number,oy:number,oz:number,dx:number,dy:number,dz:number}} m
   * @param {number} now
   * @returns {boolean}
   */
  handleShoot(id, m, now) {
    const v = this._p.get(id);
    const ch = this.chars.get(id);
    if (!v || !ch || v.dead || v.wolf) return false; // el lobo NO dispara
    if (this.mode === 'round' && !this.round.active) return false;

    // Cadencia con el reloj del host (con tolerancia de jitter)
    if (now - v.lastShotAt < CONFIG.BULLET_COOLDOWN_MS - CONFIG.COOLDOWN_TOLERANCE_MS) {
      return false;
    }
    // Munición autoritativa
    if (!v.ammo.canFire(now)) return false;
    // Origen creíble: cerca de los ojos del personaje simulado
    const ex = ch.x;
    const ey = ch.y + CONFIG.EYE_HEIGHT;
    const ez = ch.z;
    if (Math.hypot(m.ox - ex, m.oy - ey, m.oz - ez) > CONFIG.SHOOT_ORIGIN_TOLERANCE_M) {
      debug.warn(`[round] SHOOT de #${id} con origen imposible: ignorado`);
      return false;
    }

    v.ammo.consume(now);
    v.lastShotAt = now;
    v.invulnUntil = 0; // disparar anula la protección de respawn

    // Rayo: muro más cercano…
    _origin.set(m.ox, m.oy, m.oz);
    _dir.set(m.dx, m.dy, m.dz);
    const wall = raycastColliders(this.world, _origin, _dir, CONFIG.BULLET_RANGE);
    const wallDist = wall === null ? CONFIG.BULLET_RANGE : wall;

    // …y jugador más cercano (esfera de torso, sin invulnerables)
    let victim = -1;
    let victimT = wallDist;
    for (const [oid, ov] of this._p) {
      if (oid === id || ov.dead || now < ov.invulnUntil) continue;
      const oc = this.chars.get(oid);
      if (!oc) continue;
      const t = raySphere(
        m.ox, m.oy, m.oz, m.dx, m.dy, m.dz,
        oc.x, oc.y + 0.85, oc.z, 0.55
      );
      if (t !== null && t < victimT) {
        victimT = t;
        victim = oid;
      }
    }

    const end = {
      ex: m.ox + m.dx * victimT,
      ey: m.oy + m.dy * victimT,
      ez: m.oz + m.dz * victimT
    };
    this._emit(
      msgShootFx({
        id,
        ox: m.ox, oy: m.oy, oz: m.oz,
        dx: m.dx, dy: m.dy, dz: m.dz,
        ...end,
        victim
      })
    );

    if (victim !== -1) {
      this._applyDamage(victim, id, CONFIG.BULLET_DAMAGE, now, ch);
    }
    return true;
  }

  /**
   * CLAW validado → zarpazo en arco frontal (daña a TODOS los Hunters
   * dentro del arco: las garras barren).
   * @param {number} id lobo
   * @param {object} m mensaje (sin campos extra necesarios)
   * @param {number} now
   * @returns {boolean}
   */
  handleClaw(id, m, now) {
    void m;
    const v = this._p.get(id);
    const ch = this.chars.get(id);
    if (!v || !ch || v.dead || !v.wolf) return false; // solo el lobo zarpa
    if (this.mode === 'round' && !this.round.active) return false;

    if (now - v.lastClawAt < CONFIG.CLAW_COOLDOWN_MS - CONFIG.COOLDOWN_TOLERANCE_MS) {
      return false;
    }
    v.lastClawAt = now;

    this._emit(msgClawFx({ id }));

    // Arco frontal: forward = (-sin(yaw), -cos(yaw)) (convención de movement.js)
    const fx = -Math.sin(ch.yaw);
    const fz = -Math.cos(ch.yaw);
    for (const [oid, ov] of this._p) {
      if (oid === id || ov.dead || now < ov.invulnUntil) continue;
      const oc = this.chars.get(oid);
      if (!oc) continue;
      const dx = oc.x - ch.x;
      const dz = oc.z - ch.z;
      const dist = Math.hypot(dx, dz);
      if (dist > CONFIG.CLAW_RANGE + CONFIG.PLAYER_RADIUS) continue;
      if (Math.abs(oc.y - ch.y) > 1.8) continue; // otro nivel de altura
      if (dist < 0.001) continue;
      const dot = (dx / dist) * fx + (dz / dist) * fz;
      if (dot < Math.cos(CLAW_HALF_ARC)) continue; // fuera del arco

      this._applyDamage(oid, id, CONFIG.CLAW_DAMAGE, now, ch);
    }
    return true;
  }

  /**
   * RELOAD validado → el host programa el mismo temporizador de 1,5 s.
   * @param {number} id tirador
   * @param {object} m mensaje
   * @param {number} now
   * @returns {boolean}
   */
  handleReload(id, m, now) {
    void m;
    const v = this._p.get(id);
    if (!v || v.dead || v.wolf) return false;
    return v.ammo.startReload(now);
  }

  // ═══════════════════════ Daño y muerte ═══════════════════════

  /**
   * Aplica daño a una víctima y difunde HIT (y DEATH si toca).
   * @param {number} victimId
   * @param {number} byId autor
   * @param {number} dmg daño
   * @param {number} now
   * @param {object} byChar personaje del autor (para la dirección del golpe)
   */
  _applyDamage(victimId, byId, dmg, now, byChar) {
    const v = this._p.get(victimId);
    const vc = this.chars.get(victimId);
    if (!v || !vc || v.dead || now < v.invulnUntil) return;

    v.hp -= dmg;

    // Dirección del golpe (horizontal, agresor → víctima) para el indicador
    const dir = Math.atan2(vc.x - byChar.x, vc.z - byChar.z);

    this._emit(msgHit({ victim: victimId, hp: Math.max(0, v.hp), by: byId, dir }));

    if (v.hp <= 0) this._kill(victimId, byId, now, vc);
  }

  /**
   * Muerte de un jugador: respawn diferido, punto para el autor y, si era
   * lobo, el Núcleo cae donde murió (¡la siguiente oleada empieza ahí!).
   * @param {number} id
   * @param {number} byId
   * @param {number} now
   * @param {object} ch personaje de la víctima (posición de la caída)
   */
  _kill(id, byId, now, ch) {
    const v = this._p.get(id);
    if (!v) return;
    v.dead = true;
    v.hp = 0;
    v.respawnAt = now + CONFIG.RESPAWN_DELAY_MS;
    v.invulnUntil = 0;

    if (byId !== id) this.score.addKill(byId);

    this._emit(msgDeath({ id, by: byId, x: ch.x, z: ch.z }));

    if (v.wolf) {
      // El lobo cae y suelta el Núcleo en el sitio: la cacería se reanuda
      this._spawnCoreAt(ch.x, ch.z);
    }
    debug.log(`[round] #${id} eliminado por #${byId}`);
  }

  // ═══════════════════════ Consultas (STATE del host) ═══════════════════════

  /**
   * Estado de combate resumido para el STATE.
   * @param {number} id
   * @param {number} now reloj del host (para la invulnerabilidad)
   * @returns {?{hp:number, wolf:boolean, dead:boolean, inv:boolean}}
   */
  stateOf(id, now) {
    const v = this._p.get(id);
    if (!v) return null;
    return {
      hp: Math.max(0, Math.round(v.hp)),
      wolf: v.wolf,
      dead: v.dead,
      inv: now < v.invulnUntil
    };
  }

  /** @param {number} id @returns {boolean} */
  isWolf(id) {
    const v = this._p.get(id);
    return !!(v && v.wolf && !v.dead);
  }

  /** @param {number} id @returns {boolean} */
  isDead(id) {
    const v = this._p.get(id);
    return !!(v && v.dead);
  }

  /**
   * Munición autoritativa (STATE.you).
   * @param {number} id
   * @returns {?{mag:number, reserve:number}}
   */
  ammoOf(id) {
    const v = this._p.get(id);
    if (!v) return null;
    return { mag: v.ammo.mag, reserve: v.ammo.reserve };
  }

  /** @returns {boolean} ronda en marcha */
  get roundActive() {
    return this.round.active;
  }
}
