/**
 * WOLF-HUNTER · camera.js
 * Rig de cámara con DOS modos y transición continua entre ellos:
 *
 *  · 'first' — cámara en los ojos (FPS clásico, modo Hunter por defecto).
 *  · 'third' — cámara sobre el hombro (TPS; en Wolfteam el LOBO se juega
 *    así, y el botón del HUD permite alternar a gusto del jugador).
 *
 * La transición interpola posición (lerp) y orientación (slerp de
 * cuaterniones) con curva ease-out fuerte — nunca un corte seco.
 * En tercera persona un raycast contra el mundo acerca la cámara cuando
 * hay pared entre ella y la cabeza (jamás atraviesa muros).
 *
 * La preferencia se persiste en localStorage ('wh-camera'). Los cambios
 * automáticos por FORMA (Fase 3: el lobo juega en 3ª persona) también
 * usan el rig pero NO sobrescriben la preferencia guardada del jugador.
 */
import * as THREE from 'three';
import { CONFIG } from '../config.js';
import { raycastColliders } from './environment.js';

const STORAGE_KEY = 'wh-camera';
const PITCH_LIMIT = 1.51; // ≈ 86.5°
const FOV_BLEND = 7; // velocidad del fundido de FOV (1/s)

/** Curva ease-out cúbica: arranque rápido, llegada suave. */
function easeOutCubic(t) {
  const u = 1 - t;
  return 1 - u * u * u;
}

export class CameraRig {
  /**
   * @param {object} deps
   * @param {THREE.PerspectiveCamera} deps.camera
   * @param {object} deps.world mundo de environment.js
   */
  constructor({ camera, world }) {
    this.camera = camera;
    this.world = world;
    camera.rotation.order = 'YXZ';

    /** @type {'first'|'third'} modo actual */
    this.mode = this._loadMode();
    /** Preferencia del jugador (los cambios por forma no la tocan). */
    this._userMode = this.mode;
    /** @type {'hunter'|'wolf'} forma actual (FOV + distancia + altura). */
    this.form = 'hunter';
    /** 0 = primera persona · 1 = tercera (valor animado) */
    this.blend = this.mode === 'third' ? 1 : 0;
    this._animT = 1; // progreso de la transición en curso (1 = terminada)
    this._from = this.blend;
    this._fov = this.camera.fov; // FOV animado

    // Temporales reutilizados (cero allocations por frame)
    this._eye = new THREE.Vector3();
    this._pivot = new THREE.Vector3();
    this._camPos = new THREE.Vector3();
    this._lookAt = new THREE.Vector3();
    this._fwd = new THREE.Vector3();
    this._right = new THREE.Vector3();
    this._euler = new THREE.Euler(0, 0, 0, 'YXZ');
    this._qFirst = new THREE.Quaternion();
    this._qThird = new THREE.Quaternion();
    this._mThird = new THREE.Matrix4();
    this._up = new THREE.Vector3(0, 1, 0);

    /** Callback opcional al cambiar de modo (el HUD actualiza el icono). */
    this.onModeChange = null;
  }

  /** Lee la preferencia guardada (con saneado). */
  _loadMode() {
    try {
      const v = localStorage.getItem(STORAGE_KEY);
      return v === 'third' ? 'third' : v === 'first' ? 'first' : CONFIG.CAMERA_MODE;
    } catch (e) {
      return CONFIG.CAMERA_MODE;
    }
  }

  /**
   * Fija el modo de cámara con transición animada.
   * @param {'first'|'third'} mode modo destino
   * @param {boolean} [animated=true] true = transición visible
   * @param {boolean} [fromUser=true] false = cambio automático por forma:
   *        no persiste la preferencia del jugador
   */
  setMode(mode, animated = true, fromUser = true) {
    if (mode !== 'first' && mode !== 'third') return;
    if (mode === this.mode) return;
    this.mode = mode;
    if (fromUser) {
      this._userMode = mode;
      this._persist();
    }
    if (animated) {
      this._animT = 0;
      this._from = this.blend;
    } else {
      this.blend = mode === 'third' ? 1 : 0;
      this._animT = 1;
    }
    if (this.onModeChange) this.onModeChange(this.mode);
  }

  /**
   * Alterna entre primera y tercera persona (botón del HUD / tecla C).
   */
  toggle() {
    this.setMode(this.mode === 'first' ? 'third' : 'first', true, true);
  }

  /**
   * Cambia de forma (Fase 3): FOV objetivo, distancia de la 3ª persona y
   * modo de cámara por defecto — el lobo se juega en 3ª persona, como en
   * Wolfteam, pero el jugador puede seguir alternando con el botón.
   * @param {boolean} wolf true = forma Wolf
   */
  setForm(wolf) {
    this.form = wolf ? 'wolf' : 'hunter';
    // Cambio automático ANIMADO y sin tocar la preferencia guardada:
    // al volver a Hunter se restaura el modo que el jugador eligió.
    const target = wolf ? 'third' : this._userMode;
    if (target !== this.mode) this.setMode(target, true, false);
  }

  _persist() {
    try {
      localStorage.setItem(STORAGE_KEY, this.mode);
    } catch (e) {
      /* modo privado */
    }
  }

  /**
   * Avanza la transición y coloca la cámara para el estado del jugador.
   * @param {number} dt delta time en segundos
   * @param {object} ch estado del personaje (x, y pies, z, yaw)
   * @param {number} pitch inclinación de mirada del jugador (rad)
   */
  update(dt, ch, pitch) {
    const p = Math.max(-PITCH_LIMIT, Math.min(PITCH_LIMIT, pitch));

    // 1) Progreso de la transición (solo si hay una en marcha)
    if (this._animT < 1) {
      this._animT = Math.min(1, this._animT + dt * 1000 / CONFIG.CAMERA_BLEND_MS);
      const target = this.mode === 'third' ? 1 : 0;
      const e = easeOutCubic(this._animT);
      this.blend = this._from + (target - this._from) * e;
    } else {
      this.blend = this.mode === 'third' ? 1 : 0;
    }

    // 2) Puntos clave: ojos (1ª persona) y pivot sobre el hombro (3ª)
    //    El lobo mira desde más abajo: sus ojos están a la altura del lomo.
    const eyeH = this.form === 'wolf' ? CONFIG.WOLF_EYE_HEIGHT : CONFIG.EYE_HEIGHT;
    this._eye.set(ch.x, ch.y + eyeH, ch.z);
    this._pivot.copy(this._eye);
    this._pivot.y += CONFIG.THIRD_HEIGHT;

    // FOV de la forma (85 el lobo: sensación de velocidad), fundido suave
    const fovTarget = this.form === 'wolf' ? CONFIG.WOLF_FOV : CONFIG.HUNTER_FOV;
    if (Math.abs(this._fov - fovTarget) > 0.05) {
      this._fov += (fovTarget - this._fov) * Math.min(1, dt * FOV_BLEND);
      this.camera.fov = this._fov;
      this.camera.updateProjectionMatrix();
    }

    // Dirección de mirada a partir de yaw/pitch (convención YXZ de three)
    const cp = Math.cos(p);
    this._fwd.set(-Math.sin(ch.yaw) * cp, Math.sin(p), -Math.cos(ch.yaw) * cp);
    this._right.set(Math.cos(ch.yaw), 0, -Math.sin(ch.yaw));

    // 3) Posición deseada en tercera persona (algo más lejos siendo lobo)
    let dist = CONFIG.THIRD_DISTANCE +
      (this.form === 'wolf' ? CONFIG.WOLF_CAM_EXTRA : 0);
    this._camPos
      .copy(this._pivot)
      .addScaledVector(this._fwd, -dist)
      .addScaledVector(this._right, CONFIG.THIRD_SHOULDER)
      .addScaledVector(this._up, 0.12);

    // Anti-muros: raycast del pivot hacia la cámara; si hay pared, acerca
    this._lookAt.copy(this._camPos).sub(this._pivot);
    const desired = this._lookAt.length();
    this._lookAt.normalize();
    const hit = raycastColliders(this.world, this._pivot, this._lookAt, desired + 0.1);
    if (hit !== null && hit < desired) {
      dist = Math.max(hit - 0.15, CONFIG.THIRD_MIN_DISTANCE);
      this._camPos
        .copy(this._pivot)
        .addScaledVector(this._lookAt, dist);
    }

    // 4) Orientaciones
    this._euler.set(p, ch.yaw, 0, 'YXZ');
    this._qFirst.setFromEuler(this._euler);

    this._lookAt.copy(this._pivot).addScaledVector(this._fwd, 1.8);
    this._mThird.lookAt(this._camPos, this._lookAt, this._up);
    this._qThird.setFromRotationMatrix(this._mThird);

    // 5) Mezcla final (lerp de posición + slerp de orientación)
    const b = this.blend;
    this.camera.position.lerpVectors(this._eye, this._camPos, b);
    this.camera.quaternion.slerpQuaternions(this._qFirst, this._qThird, b);
  }

  /**
   * Posición de los ojos del jugador (para Fase 3: origen de disparos).
   * @param {THREE.Vector3} [out] vector de salida opcional
   * @returns {THREE.Vector3}
   */
  getEyePosition(out = new THREE.Vector3()) {
    return out.copy(this._eye);
  }

  /** @returns {boolean} true si la vista está (total o casi) en 3ª persona */
  get isThirdPerson() {
    return this.blend > 0.5;
  }
}
