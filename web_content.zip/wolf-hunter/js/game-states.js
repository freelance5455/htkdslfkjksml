/**
 * WOLF-HUNTER · game-states.js
 * Máquina de estados del juego + gestor de pantallas.
 *
 *   MENU ──▶ HOST_SETUP ──▶ LOBBY ──▶ PLAYING ──┐
 *     │                                        │
 *     └──▶ JOIN ──▶ CONNECTING ──▶ LOBBY ◀─────┘ (volver al menú)
 *
 * Cada estado tiene UNA pantalla asociada (o ninguna, como PLAYING) y el
 * gestor se encarga de que solo haya una abierta: imposible quedarse con
 * dos overlays solapados. El HUD solo recibe eventos en PLAYING.
 *
 * La Fase 4 (screen-manager.js) ampliará esto con transiciones coreogra-
 * fiadas; la interfaz pública (go/on) se mantiene.
 */

/** Estados del juego. */
export const GameState = Object.freeze({
  MENU: 'menu',
  HOST_SETUP: 'host-setup',
  JOIN: 'join',
  CONNECTING: 'connecting',
  LOBBY: 'lobby',
  PLAYING: 'playing'
});

/** Pantalla DOM de cada estado (null = sin pantalla, juego a la vista). */
export const SCREEN_OF = {
  [GameState.MENU]: 'screen-menu',
  [GameState.HOST_SETUP]: 'screen-host',
  [GameState.JOIN]: 'screen-join',
  [GameState.CONNECTING]: 'screen-connecting',
  [GameState.LOBBY]: 'screen-lobby',
  [GameState.PLAYING]: null
};

/** Transiciones permitidas (lo que no está aquí es un bug del caller). */
const ALLOWED = Object.freeze({
  [GameState.MENU]: [GameState.HOST_SETUP, GameState.JOIN, GameState.PLAYING],
  [GameState.HOST_SETUP]: [GameState.MENU, GameState.LOBBY, GameState.CONNECTING],
  [GameState.JOIN]: [GameState.MENU, GameState.CONNECTING],
  [GameState.CONNECTING]: [GameState.MENU, GameState.LOBBY, GameState.JOIN, GameState.HOST_SETUP],
  [GameState.LOBBY]: [GameState.MENU, GameState.PLAYING, GameState.CONNECTING],
  // Fase 3: tras ROUND_END todos vuelven al lobby (marcador → sala)
  [GameState.PLAYING]: [GameState.MENU, GameState.LOBBY]
});

/**
 * Gestor de pantallas: garantiza una sola pantalla abierta.
 */
export class ScreenManager {
  constructor() {
    /** @type {Set<string>} ids abiertos (pantallas + overlays) */
    this._open = new Set();
  }

  /**
   * Abre una pantalla (cerrando las demás pantallas de estado).
   * @param {string|null} id elemento con [data-open], o null para cerrar todas
   */
  show(id) {
    for (const openId of [...this._open]) {
      const el = document.getElementById(openId);
      if (el) el.removeAttribute('data-open');
    }
    this._open.clear();
    if (id) this.open(id);
  }

  /**
   * Abre un overlay adicional sin cerrar el actual (avisos sobre pantallas).
   * @param {string} id
   */
  open(id) {
    const el = document.getElementById(id);
    if (el) el.setAttribute('data-open', '');
    this._open.add(id);
  }

  /**
   * Cierra un overlay concreto.
   * @param {string} id
   */
  close(id) {
    const el = document.getElementById(id);
    if (el) el.removeAttribute('data-open');
    this._open.delete(id);
  }

  /** @param {string} id @returns {boolean} */
  isOpen(id) {
    return this._open.has(id);
  }
}

/**
 * Máquina de estados del juego.
 */
export class GameStateMachine {
  constructor() {
    /** @type {string|null} estado actual */
    this.current = null;
    this._listeners = new Set();
  }

  /**
   * Suscribe cambios de estado.
   * @param {(from: string|null, to: string) => void} fn
   * @returns {() => void} desuscriptor
   */
  on(fn) {
    this._listeners.add(fn);
    return () => this._listeners.delete(fn);
  }

  /**
   * Cambia de estado (con guardia de transiciones).
   * @param {string} to estado destino (GameState.*)
   * @param {object} [ctx] contexto opcional para los listeners
   */
  go(to, ctx) {
    if (to === this.current) return;
    if (this.current && ALLOWED[this.current] && !ALLOWED[this.current].includes(to)) {
      // Transición no prevista: en desarrollo se ve; en producción se permite
      // (mejor un salto raro que un jugador atascado en una pantalla).
      console.warn('[states] transición no prevista:', this.current, '→', to);
    }
    const from = this.current;
    this.current = to;
    document.body.dataset.state = to;
    for (const fn of [...this._listeners]) {
      try {
        fn(from, to, ctx);
      } catch (e) {
        console.error('[states] listener falló:', e);
      }
    }
  }
}
