/**
 * WOLF-HUNTER · protocol.js
 * Protocolo P2P explícito sobre PeerJS. TODOS los mensajes son objetos
 * `{ t: MSG.<TIPO>, … }` — nunca arrays ni valores sueltos — para poder
 * validar forma y contenido antes de tocar el estado del juego.
 *
 * Direcciones: C→H cliente a host · H→C host a cliente · H→∀ difusión.
 *
 * Modelo de autoridad (fijado en diseño):
 *  · El host valida TODO: versión, sala llena, contraseña, dt de sub-pasos,
 *    límite de mensajes por segundo, y es quien simula las posiciones.
 *  · El cliente predice su movimiento local y se reconcilia con STATE.you.
 *  · Los remotos se interpolan con 100 ms de retardo (INTERP_DELAY_MS).
 *
 * Los mensajes de combate (SHOOT…TRANSFORM, ROUND_END) se declaran aquí
 * con su contrato completo; la Fase 3 los procesa de verdad y AÑADE tres
 * tipos que el diseño original no preveía: RELOAD (petición de recarga),
 * CLAW (petición de zarpazo) y CLAW_FX (efecto del zarpazo aceptado).
 * Recibir un tipo desconocido o inválido NUNCA tira el juego: se ignora
 * y se cuenta como advertencia.
 */

import { GAME_VERSION } from './version.js';

/** Tipos de mensaje del protocolo (congelados: nadie los muta por accidente). */
export const MSG = Object.freeze({
  /** C→H · Presentación del cliente al conectar. {v, name, pass?} */
  HELLO: 'HELLO',
  /** H→C · Acepta al jugador y le entrega el estado de la sala. {you, color, roomCode, roster} */
  WELCOME: 'WELCOME',
  /** H→C · Rechaza la conexión y la cierra. {reason} — ver REJECT_TEXT */
  REJECT: 'REJECT',
  /** C→H · Paquete de sub-pasos de entrada. {seq, steps:[{dt,mx,my,yaw,jump,hold}]} */
  INPUT: 'INPUT',
  /** H→∀ · Instantánea autoritativa. {time, you?, players[], paused} */
  STATE: 'STATE',
  /** C→H · Disparo solicitado (el host valida origen, cadencia y munición). {seq, ox,oy,oz, dx,dy,dz} */
  SHOOT: 'SHOOT',
  /** C→H · Recarga solicitada (el host programa sus 1,5 s). {seq} */
  RELOAD: 'RELOAD',
  /** C→H · Zarpazo solicitado (solo Wolf; el host valida forma y cadencia). {seq} */
  CLAW: 'CLAW',
  /** H→∀ · Efecto de disparo aceptado (línea + sonido en todos). {id, ox..dz, ex,ey,ez, victim} */
  SHOOT_FX: 'SHOOT_FX',
  /** H→∀ · Efecto de zarpazo aceptado (arco delante del lobo). {id} */
  CLAW_FX: 'CLAW_FX',
  /** H→∀ · Daño aplicado a una víctima. {victim, hp, by, dir} */
  HIT: 'HIT',
  /** H→∀ · Un jugador murió (y soltará el Núcleo si era Wolf). {id, by, x, z} */
  DEATH: 'DEATH',
  /** H→∀ · Reaparición de un jugador (invulnerable 2 s). {id, x, z, yaw} */
  RESPAWN: 'RESPAWN',
  /** H→∀ · El Núcleo de Fiera aparece en el mundo. {x, z} */
  CORE_SPAWN: 'CORE_SPAWN',
  /** H→∀ · Un jugador recogió el Núcleo. {id} */
  CORE_PICKUP: 'CORE_PICKUP',
  /** H→∀ · Transformación Hunter↔Wolf. {id, wolf, endsAt} */
  TRANSFORM: 'TRANSFORM',
  /** H→∀ · Comienza la ronda con los spawns asignados. {spawns, endsAt} */
  ROUND_START: 'ROUND_START',
  /** H→∀ · Fin de ronda con marcador. {scores:[{id,name,kills,wolfSec,score}]} */
  ROUND_END: 'ROUND_END',
  /** C→H · Sondeo de reloj. {c0} */
  PING: 'PING',
  /** H→C · Respuesta de reloj. {c0, h1} */
  PONG: 'PONG'
});

/** Razones de REJECT (viajan por la red como string corto). */
export const REJECT = Object.freeze({
  VERSION: 'version', // versión de protocolo distinta
  FULL: 'full', // sala llena (MAX_PLAYERS)
  PASSWORD: 'password', // contraseña incorrecta
  GAME: 'game' // partida en curso: se une al inicio de la siguiente
});

/** Texto en español para cada razón de rechazo. */
export const REJECT_TEXT = Object.freeze({
  [REJECT.VERSION]: 'Versión distinta: ambos jugadores deben actualizar la página.',
  [REJECT.FULL]: 'Sala llena (máx. 4 jugadores).',
  [REJECT.PASSWORD]: 'Contraseña incorrecta.',
  [REJECT.GAME]: 'Partida en curso: podrás entrar al final de la ronda.'
});

// ═══════════════════════ Fábricas (cliente) ═══════════════════════
// Una fábrica por mensaje que envía el cliente: imposible olvidar un campo.

/**
 * @param {string} name nombre saneado del jugador
 * @param {string} [pass] contraseña de la sala (si el host la puso)
 * @returns {object} HELLO
 */
export function msgHello(name, pass) {
  return { t: MSG.HELLO, v: GAME_VERSION, name, pass: pass || '' };
}

/**
 * @param {number} seq número de secuencia del paquete de entrada
 * @param {Array<{dt:number,mx:number,my:number,yaw:number,jump:boolean,hold:boolean}>} steps
 * @returns {object} INPUT
 */
export function msgInput(seq, steps) {
  return { t: MSG.INPUT, seq, steps };
}

/**
 * @param {number} seq secuencia local (depuración)
 * @param {number} ox,oy,oz origen del rayo (ojos del tirador)
 * @param {number} dx,dy,dz dirección NORMALIZADA
 * @returns {object} SHOOT
 */
export function msgShoot(seq, ox, oy, oz, dx, dy, dz) {
  return { t: MSG.SHOOT, seq, ox, oy, oz, dx, dy, dz };
}

/** @param {number} seq secuencia local @returns {object} RELOAD */
export function msgReload(seq) {
  return { t: MSG.RELOAD, seq };
}

/** @param {number} seq secuencia local @returns {object} CLAW */
export function msgClaw(seq) {
  return { t: MSG.CLAW, seq };
}

/** @param {number} c0 performance.now() local en el envío @returns {object} PING */
export function msgPing(c0) {
  return { t: MSG.PING, c0 };
}

// ═══════════════════════ Fábricas (host) ═══════════════════════

/**
 * @param {object} p datos del jugador aceptado
 * @param {number} p.you id asignado (1..MAX-1; el host es 0)
 * @param {number} p.color color del jugador
 * @param {string} p.roomCode código de sala legible
 * @param {Array<{id:number,name:string,color:number,host:boolean}>} p.roster
 * @returns {object} WELCOME
 */
export function msgWelcome({ you, color, roomCode, roster }) {
  return { t: MSG.WELCOME, you, color, roomCode, roster };
}

/** @param {string} reason una de REJECT @returns {object} REJECT */
export function msgReject(reason) {
  return { t: MSG.REJECT, reason };
}

/** @param {object} s estado completo @returns {object} STATE */
export function msgState(s) {
  return { t: MSG.STATE, ...s };
}

/** @param {object} r arranque de ronda @returns {object} ROUND_START */
export function msgRoundStart(r) {
  return { t: MSG.ROUND_START, ...r };
}

/** @param {number} c0 eco del PING @param {number} h1 reloj del host @returns {object} PONG */
export function msgPong(c0, h1) {
  return { t: MSG.PONG, c0, h1 };
}

/**
 * Efectos de combate que difunde el host: una fábrica por tipo, imposible
 * olvidar un campo.
 */

/** @param {object} e {id, ox,oy,oz, dx,dy,dz, ex,ey,ez, victim} @returns {object} SHOOT_FX */
export function msgShootFx(e) {
  return { t: MSG.SHOOT_FX, ...e };
}

/** @param {object} e {id} @returns {object} CLAW_FX */
export function msgClawFx(e) {
  return { t: MSG.CLAW_FX, ...e };
}

/** @param {object} e {victim, hp, by, dir} @returns {object} HIT */
export function msgHit(e) {
  return { t: MSG.HIT, ...e };
}

/** @param {object} e {id, by, x, z} @returns {object} DEATH */
export function msgDeath(e) {
  return { t: MSG.DEATH, ...e };
}

/** @param {object} e {id, x, z, yaw} @returns {object} RESPAWN */
export function msgRespawn(e) {
  return { t: MSG.RESPAWN, ...e };
}

/** @param {object} e {x, z} @returns {object} CORE_SPAWN */
export function msgCoreSpawn(e) {
  return { t: MSG.CORE_SPAWN, ...e };
}

/** @param {object} e {id} @returns {object} CORE_PICKUP */
export function msgCorePickup(e) {
  return { t: MSG.CORE_PICKUP, ...e };
}

/** @param {object} e {id, wolf, endsAt} @returns {object} TRANSFORM */
export function msgTransform(e) {
  return { t: MSG.TRANSFORM, ...e };
}

/** @param {object} e {scores:[{id,name,kills,wolfSec,score}]} @returns {object} ROUND_END */
export function msgRoundEnd(e) {
  return { t: MSG.ROUND_END, ...e };
}

// ═══════════════════════ Validación (host) ═══════════════════════

/**
 * ¿Tiene forma de mensaje del protocolo? (t string conocida)
 * @param {any} m lo que llegó por el canal de datos
 * @returns {boolean}
 */
export function isValidMessage(m) {
  return !!m && typeof m === 'object' && !Array.isArray(m) &&
    typeof m.t === 'string' && Object.prototype.hasOwnProperty.call(MSG, m.t);
}

/**
 * Valida un HELLO completo (versión, nombre, contraseña).
 * @param {any} m mensaje candidato
 * @returns {{ok: boolean, reason?: string}} ok o razón de REJECT
 */
export function validateHello(m) {
  if (m.v !== GAME_VERSION) return { ok: false, reason: REJECT.VERSION };
  if (typeof m.name !== 'string' || m.name.length < 1 || m.name.length > 12) {
    return { ok: false, reason: REJECT.VERSION }; // nombre inválido = paquete roto
  }
  if (m.pass !== undefined && m.pass !== null && typeof m.pass !== 'string') {
    return { ok: false, reason: REJECT.PASSWORD };
  }
  return { ok: true };
}

/**
 * Valida un INPUT completo: secuencia entera creíble y sub-pasos aplicables.
 * El límite total (0.3 s) impide "acelerar el tiempo" desde un cliente
 * manipulado: aunque los dt individuales sean válidos, un paquete no puede
 * simular más de 300 ms de una vez.
 * @param {any} m mensaje candidato
 * @returns {boolean} true si se puede aplicar tal cual
 */
export function validateInput(m) {
  if (typeof m.seq !== 'number' || !Number.isInteger(m.seq) || m.seq < 0) return false;
  if (!Array.isArray(m.steps) || m.steps.length === 0 || m.steps.length > 16) return false;
  let total = 0;
  for (const s of m.steps) {
    if (typeof s.dt !== 'number' || !Number.isFinite(s.dt)) return false;
    if (s.dt < 0.001 || s.dt > 0.12) return false;
    if (typeof s.mx !== 'number' || typeof s.my !== 'number') return false;
    if (Math.abs(s.mx) > 1.01 || Math.abs(s.my) > 1.01) return false;
    if (typeof s.yaw !== 'number' || !Number.isFinite(s.yaw)) return false;
    total += s.dt;
  }
  return total <= 0.3;
}

/**
 * Valida un PING.
 * @param {any} m mensaje candidato
 * @returns {boolean}
 */
export function validatePing(m) {
  return typeof m.c0 === 'number' && Number.isFinite(m.c0);
}

/**
 * Valida un SHOOT: campos numéricos finitos, dirección casi normalizada y
 * origen dentro del mapa. La cadencia y la munición las comprueba el host
 * contra SU reloj y SU contador; aquí solo la forma del paquete.
 * @param {any} m mensaje candidato
 * @returns {boolean}
 */
export function validateShoot(m) {
  const nums = [m.ox, m.oy, m.oz, m.dx, m.dy, m.dz];
  for (const n of nums) {
    if (typeof n !== 'number' || !Number.isFinite(n)) return false;
  }
  const len = Math.hypot(m.dx, m.dy, m.dz);
  if (len < 0.98 || len > 1.02) return false;
  if (Math.abs(m.ox) > 30 || Math.abs(m.oz) > 30 || m.oy < -2 || m.oy > 12) return false;
  return true;
}

/**
 * Valida un RELOAD o CLAW (solo portan la secuencia opcional).
 * @param {any} m mensaje candidato
 * @returns {boolean}
 */
export function validateSimple(m) {
  return m.seq === undefined || typeof m.seq === 'number';
}
