/**
 * WOLF-HUNTER · beast-core.js
 * El Núcleo de Fiera: la reliquia que convierte a quien la recoge en Wolf
 * durante WOLF_DURATION_MS.
 *
 * Este módulo es solo la VISTA del Núcleo (malla + haz + anillo en el suelo
 * + animación). Quién puede recogerlo y cuándo lo decide SIEMPRE el host
 * (round-manager.js); en modo Explorar solo, la propia GameSession.
 *
 * Estados:
 *  · spawnAt(x, z) — aparece flotando sobre el suelo de ese punto.
 *  · pickup()      — lo recogen: se oculta con un pulso rápido.
 *  · update(dt)    — rota, flota y respira mientras está visible.
 */

import * as THREE from 'three';
import { CONFIG } from '../config.js';
import { groundHeightAt } from './environment.js';

const CORE_COLOR = 0xff8a3d;

export class BeastCore {
  /**
   * @param {THREE.Scene} scene
   * @param {object} world mundo de environment.js (para apoyarse en el suelo)
   */
  constructor(scene, world) {
    this.world = world;
    this.active = false;
    this.position = new THREE.Vector3();

    // Cristal central: octaedro naranja (mismo lenguaje que el pedestal)
    this._core = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.3),
      new THREE.MeshBasicMaterial({ color: CORE_COLOR })
    );

    // Halo suave alrededor (aditivo, sin depthWrite para no manchar el cielo)
    this._halo = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.44),
      new THREE.MeshBasicMaterial({
        color: CORE_COLOR,
        transparent: true,
        opacity: 0.22,
        depthWrite: false,
        blending: THREE.AdditiveBlending
      })
    );

    // Haz vertical: baliza visible desde cualquier pasillo
    this._beam = new THREE.Mesh(
      new THREE.CylinderGeometry(0.14, 0.14, 6, 8, 1, true),
      new THREE.MeshBasicMaterial({
        color: CORE_COLOR,
        transparent: true,
        opacity: 0.15,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide
      })
    );

    // Anillo en el suelo: marca el radio de recogida (CORE_PICKUP_RANGE)
    this._ring = new THREE.Mesh(
      new THREE.RingGeometry(CONFIG.CORE_PICKUP_RANGE - 0.09, CONFIG.CORE_PICKUP_RANGE, 40),
      new THREE.MeshBasicMaterial({
        color: CORE_COLOR,
        transparent: true,
        opacity: 0.5,
        depthWrite: false,
        side: THREE.DoubleSide
      })
    );
    this._ring.rotation.x = -Math.PI / 2;

    this._group = new THREE.Group();
    this._group.add(this._core, this._halo, this._beam, this._ring);
    this._group.visible = false;
    scene.add(this._group);

    this._baseY = 0;
    this._t = 0;
    this._fade = 0; // 1 = pulso de recogida en marcha
  }

  /**
   * Hace aparecer el Núcleo en un punto del mapa (pedestal o muerte del lobo).
   * @param {number} x
   * @param {number} z
   */
  spawnAt(x, z) {
    this.active = true;
    const ground = groundHeightAt(this.world, x, z, 12);
    this._baseY = Math.max(ground, 0) + 0.85; // flota a la altura del pecho
    this.position.set(x, this._baseY, z);
    this._group.position.set(x, 0, z);
    this._group.visible = true;
    this._fade = 0;
  }

  /** Lo recogen: se oculta (la animación de "absorción" la hace el HUD). */
  pickup() {
    this.active = false;
    this._group.visible = false;
  }

  /** Ocultación forzada (fin de ronda, salida al menú). */
  hide() {
    this.active = false;
    this._group.visible = false;
  }

  /**
   * Anima rotación, flotación y respiración del haz.
   * @param {number} dt delta time en segundos
   */
  update(dt) {
    if (!this.active) return;
    this._t += dt;
    this._core.rotation.y += dt * 1.6;
    this._core.rotation.x = Math.sin(this._t * 1.1) * 0.18;
    this._halo.rotation.y -= dt * 0.9;
    this._halo.rotation.x = Math.sin(this._t * 1.1 + 1) * 0.22;
    this._core.position.y = this._baseY + Math.sin(this._t * 2.2) * 0.12;
    this._halo.position.y = this._core.position.y;
    this._beam.position.y = this._baseY + 2.4;
    this._ring.position.y = Math.max(this._baseY - 0.85, 0) + 0.03;
    this._beam.material.opacity = 0.12 + (Math.sin(this._t * 2.2) + 1) * 0.03;
    this._ring.material.opacity = 0.38 + (Math.sin(this._t * 3.4) + 1) * 0.12;
  }

  /** Libera GPU (fin del programa). */
  dispose() {
    for (const m of [this._core, this._halo, this._beam, this._ring]) {
      m.geometry.dispose();
      m.material.dispose();
    }
  }
}
