/**
 * WOLF-HUNTER · viewmodel.js (Fase 4)
 * Los brazos en primera persona: el rifle del Hunter y las garras del
 * Lobo, colgados de la CÁMARA (viajan con ella sin tocar su lógica).
 *
 *  · Hunter: rifle geométrico a dos manos + fogonazo en la boca.
 *  · Wolf: dos zarpas que barren en pantalla, alternando el lado.
 *  · Vida propia: retroceso por disparo (muelle exponencial), recarga
 *    (el arma se baja y bascula 1,5 s), balanceo al caminar (figura-8
 *    con la fase de la zancada) y SWAY que persigue la mirada (el arma
 *    llega un pelín más tarde que el ojo: así el mundo se siente físico).
 *  · Cero allocations por frame: solo se escriben transformaciones.
 *
 * Render: los materiales llevan depthTest desactivado y renderOrder alto
 * para que el arma JAMÁS atraviese muros al pegarse a ellos (el clásico
 * clip del viewmodel) ni la tapen las trazadoras.
 */

import * as THREE from 'three';
import { CONFIG } from '../config.js';

const BOX = new THREE.BoxGeometry(1, 1, 1); // compartida por todas las piezas

/** Pieza rectangular colgada de un padre, en metros (espacio de cámara). */
function part(parent, mat, w, h, d, x, y, z) {
  const m = new THREE.Mesh(BOX, mat);
  m.scale.set(w, h, d);
  m.position.set(x, y, z);
  m.castShadow = false;
  m.receiveShadow = false;
  m.renderOrder = 950; // después de trazadoras y mundo (no se hereda: por pieza)
  parent.add(m);
  return m;
}

/**
 * Material del viewmodel: opaco pero en la cola transparente (con
 * renderOrder alto se pinta después de las trazadoras) y sin test de
 * profundidad (no hay clip contra muros).
 */
function vmMat(color) {
  return new THREE.MeshLambertMaterial({
    color,
    transparent: true,
    opacity: 1,
    depthTest: false,
    depthWrite: false
  });
}

export class ViewModel {
  /**
   * @param {object} deps
   * @param {THREE.PerspectiveCamera} deps.camera la cámara del juego
   *        (main.js ya la añadió a la escena: sus hijos se dibujan)
   */
  constructor({ camera }) {
    this._cam = camera;

    // root decide la VISIBILIDAD; pose recibe sway/bob/recoil/recarga
    this._root = new THREE.Group();
    this._pose = new THREE.Group();
    this._root.add(this._pose);
    camera.add(this._root);

    // ── Materiales (paleta del juego: grises fríos + acento naranja) ──
    const gunMat = vmMat(0x232a3a); // cuerpo del arma
    const darkMat = vmMat(0x161b26); // guantes y detalles
    const sleeveMat = vmMat(0x8d97ac); // mangas
    const accentMat = vmMat(0xff8a3d); // remate naranja
    const furMat = vmMat(0x262c38); // pelaje del lobo (como avatar.js)
    const clawMat = vmMat(0xe8ecf4); // garras claras
    this._mats = [gunMat, darkMat, sleeveMat, accentMat, furMat, clawMat];

    // ═════════════════ Rifle del Hunter ═════════════════
    const hunter = new THREE.Group();
    // Cuerpo, cañón, alza, cargador y culata (apunta a -Z, como la mira)
    part(hunter, gunMat, 0.055, 0.095, 0.4, 0, -0.135, -0.36);
    part(hunter, gunMat, 0.03, 0.034, 0.24, 0, -0.118, -0.62);
    part(hunter, darkMat, 0.02, 0.035, 0.07, 0, -0.072, -0.5);
    part(hunter, darkMat, 0.038, 0.11, 0.075, 0, -0.215, -0.33);
    part(hunter, gunMat, 0.045, 0.075, 0.16, 0, -0.15, -0.13);
    part(hunter, accentMat, 0.058, 0.012, 0.05, 0, -0.09, -0.46); // remate
    // Brazos: derecho al gatillo, izquierdo sosteniendo el cañón
    part(hunter, sleeveMat, 0.075, 0.075, 0.3, 0.15, -0.21, -0.24);
    part(hunter, darkMat, 0.085, 0.095, 0.11, 0.075, -0.185, -0.34);
    part(hunter, sleeveMat, 0.07, 0.07, 0.26, -0.13, -0.24, -0.3);
    part(hunter, darkMat, 0.08, 0.085, 0.1, -0.06, -0.215, -0.43);
    this._hunter = hunter;

    // Fogonazo: destello aditivo en la boca del cañón (~50 ms)
    const flashMat = new THREE.MeshBasicMaterial({
      color: 0xffd9a8,
      transparent: true,
      opacity: 0.95,
      depthTest: false,
      depthWrite: false,
      blending: THREE.AdditiveBlending
    });
    this._mats.push(flashMat);
    this._flash = new THREE.Group();
    part(this._flash, flashMat, 0.075, 0.075, 0.02, 0, 0, 0);
    part(this._flash, flashMat, 0.03, 0.14, 0.02, 0, 0, 0).rotation.z = Math.PI / 4;
    part(this._flash, flashMat, 0.14, 0.03, 0.02, 0, 0, 0).rotation.z = Math.PI / 4;
    this._flash.position.set(0, -0.118, -0.76);
    this._flash.visible = false;
    this._flash.traverse((o) => {
      if (o.isMesh) o.renderOrder = 1000; // el fogonazo, encima de todo
    });
    hunter.add(this._flash);

    // ═════════════════ Zarpas del Wolf ═════════════════
    // Cada zarpa es un pivote (muñeca) para poder barrerla en pantalla
    const wolf = new THREE.Group();
    this._pawR = this._buildPaw(wolf, 1, furMat, clawMat);
    this._pawL = this._buildPaw(wolf, -1, furMat, clawMat);
    this._wolfG = wolf; // el GRUPO (zarpas); this._wolf es el booleano de forma

    this._pose.add(hunter, wolf);
    hunter.visible = true;
    wolf.visible = false;

    // ── Estado de animación ──
    /** @type {boolean} forma activa (Hunter = false) */
    this._wolf = false;
    this._recoil = 0; // 0..1 impulso del último disparo (decae solo)
    this._flashT = 0; // s restantes de fogonazo
    this._reloadT = -1; // -1 = sin recarga; >= 0 progreso en s
    this._reloadDur = CONFIG.RELOAD_TIME_MS / 1000;
    this._bobPhase = 0; // fase de la zancada (figura-8)
    this._swayX = 0; // balanceo suavizado (rad), persigue a la mirada
    this._swayY = 0;
    this._clawT = 1; // 1 = reposo; 0..1 barrido en curso
    this._clawSide = 0; // 0 zarpa derecha, 1 izquierda (alternan)
    this._idleT = 0; // reloj de la respiración
  }

  /**
   * Una zarpa (antebrazo peludo + 3 garras) colgada de su muñeca.
   * @param {THREE.Group} parent
   * @param {number} side +1 derecha, -1 izquierda
   * @param {THREE.Material} furMat
   * @param {THREE.Material} clawMat
   * @returns {THREE.Group} el pivote de la muñeca
   */
  _buildPaw(parent, side, furMat, clawMat) {
    const pivot = new THREE.Group();
    pivot.position.set(0.185 * side, -0.27, -0.33);
    parent.add(pivot);
    part(pivot, furMat, 0.095, 0.1, 0.36, 0, 0, -0.12);
    part(pivot, furMat, 0.105, 0.11, 0.13, 0, -0.01, -0.32);
    for (let i = -1; i <= 1; i++) {
      part(pivot, clawMat, 0.018, 0.022, 0.085, i * 0.028, 0.012 - Math.abs(i) * 0.004, -0.42);
    }
    pivot.rotation.set(-0.22, 0.18 * side, 0.1 * side);
    return pivot;
  }

  // ═════════════════════ Eventos de juego ═════════════════════

  /** Disparo aceptado: retroceso + fogonazo. */
  kick() {
    this._recoil = 1;
    this._flashT = 0.05;
    this._flash.rotation.z = Math.random() * Math.PI; // cada disparo estalla distinto
  }

  /**
   * Recarga en curso: el arma se baja y bascula durante la duración real.
   * @param {number} [durMs] duración de la recarga (CONFIG por defecto)
   */
  startReload(durMs = CONFIG.RELOAD_TIME_MS) {
    this._reloadDur = Math.max(0.2, durMs / 1000);
    this._reloadT = 0;
  }

  /** Zarpazo: barre la zarpa alternada. */
  clawSwipe() {
    this._resetPose(); // por si un barrido anterior quedó a medias (lag)
    this._clawT = 0;
    this._clawSide ^= 1;
  }

  /**
   * Cambia la forma visible (lo decide la TRANSFORM del host).
   * @param {boolean} wolf
   */
  setForm(wolf) {
    this._wolf = !!wolf;
    this._hunter.visible = !this._wolf;
    this._wolfG.visible = this._wolf;
    this._reloadT = -1;
    this._clawT = 1;
    this._resetPose();
  }

  /** Vuelta a reposo (spawn, respawn, fin de ronda). */
  reset() {
    this._recoil = 0;
    this._flashT = 0;
    this._reloadT = -1;
    this._clawT = 1;
    this._flash.visible = false;
    this._resetPose();
  }

  /** Pose neutra de zarpas y pose compartida. */
  _resetPose() {
    this._pose.position.set(0, 0, 0);
    this._pose.rotation.set(0, 0, 0);
    this._pawR.rotation.set(-0.22, 0.18, 0.1);
    this._pawL.rotation.set(-0.22, -0.18, -0.1);
    this._pawR.position.set(0.185, -0.27, -0.33);
    this._pawL.position.set(-0.185, -0.27, -0.33);
  }

  // ═════════════════════ Bucle ═════════════════════

  /**
   * Avanza la animación (lo llama GameSession cada frame).
   * @param {number} dt delta en segundos
   * @param {object} s estado del jugador local:
   *   playing, alive, blend (0 = 1ª persona), moveMag (0..1), grounded,
   *   dyaw/dpitch (rad girados este frame, para el sway)
   */
  update(dt, s) {
    // Visible solo en (o casi en) primera persona, vivo y jugando
    const show = s.playing && s.alive && s.blend < 0.35;
    this._root.visible = show;
    if (!show) {
      this._flashT = 0;
      this._flash.visible = false;
      return;
    }

    // ── Sway: el arma persigue la mirada con retraso ──
    const invDt = dt > 1e-4 ? 1 / dt : 60;
    const k = Math.min(1, dt * CONFIG.VM_SWAY_RATE);
    const tgtX = Math.max(-CONFIG.VM_SWAY_MAX,
      Math.min(CONFIG.VM_SWAY_MAX, -(s.dyaw || 0) * invDt * 0.05));
    const tgtY = Math.max(-CONFIG.VM_SWAY_MAX,
      Math.min(CONFIG.VM_SWAY_MAX, (s.dpitch || 0) * invDt * 0.05));
    this._swayX += (tgtX - this._swayX) * k;
    this._swayY += (tgtY - this._swayY) * k;

    // ── Bob: figura-8 con la fase de la zancada (solo en el suelo) ──
    if (s.grounded) {
      this._bobPhase += (s.moveMag || 0) * dt * CONFIG.VM_BOB_HZ * Math.PI * 2;
    }
    const bobA = CONFIG.VM_BOB_AMT * (s.grounded ? Math.min(1, (s.moveMag || 0) + 0.15) : 0.25);
    const bobX = Math.cos(this._bobPhase) * bobA;
    const bobY = Math.sin(this._bobPhase * 2) * bobA * 0.6;

    // ── Retroceso (muelle exponencial) ──
    this._recoil *= Math.exp(-CONFIG.VM_KICK_DECAY * dt);

    // ── Recarga: envolvente de bajada/subida durante su duración ──
    let dip = 0;
    let dipRot = 0;
    if (this._reloadT >= 0) {
      this._reloadT += dt;
      const u = this._reloadT / this._reloadDur;
      if (u >= 1) {
        this._reloadT = -1;
      } else {
        const env = Math.sin(u * Math.PI); // baja y sube suave
        dip = env * CONFIG.VM_RELOAD_DIP;
        dipRot = env * CONFIG.VM_RELOAD_ROT;
      }
    }

    // ── Aplicar la pose compartida ──
    this._idleT += dt;
    const breathe = Math.sin(this._idleT * 1.7) * 0.0022;
    this._pose.position.set(bobX + this._swayX * 0.4, bobY + breathe - dip, this._recoil * CONFIG.VM_KICK_POS);
    this._pose.rotation.set(
      this._recoil * CONFIG.VM_KICK_ROT + dipRot + this._swayY,
      this._swayX,
      dipRot * 0.4
    );

    // ── Fogonazo ──
    if (this._flashT > 0) {
      this._flashT -= dt;
      this._flash.visible = this._flashT > 0;
    } else {
      this._flash.visible = false;
    }

    // ── Zarpazo: la zarpa activa barre en pantalla (240 ms) ──
    if (this._clawT < 1) {
      this._clawT = Math.min(1, this._clawT + dt / (CONFIG.VM_CLAW_TIME_MS / 1000));
      const paw = this._clawSide ? this._pawL : this._pawR;
      const side = this._clawSide ? -1 : 1;
      const swing = Math.sin(this._clawT * Math.PI); // sube y baja
      paw.rotation.x = -0.22 + swing * 1.05;
      paw.rotation.z = 0.1 * side - swing * 0.55 * side;
      paw.position.y = -0.27 + swing * 0.1;
      paw.position.x = 0.185 * side - swing * 0.12 * side;
      if (this._clawT >= 1) this._resetPose();
    }
  }

  /** Libera GPU (fin del programa). */
  dispose() {
    this._cam.remove(this._root);
    BOX.dispose(); // geometría compartida: una sola vez
    for (const m of this._mats) m.dispose();
  }
}
