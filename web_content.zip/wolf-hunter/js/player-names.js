/**
 * WOLF-HUNTER · player-names.js
 * Nombre del jugador: saneado (sin HTML, sin controles, máx. 12 caracteres)
 * y persistido en localStorage. El saneado es la primera línea anti-XSS:
 * el nombre se pinta SIEMPRE con textContent, pero tampoco entra sucio.
 */

const KEY = 'wh-name';
const MAX_LEN = 12;

/**
 * Sanea un nombre: recorta espacios, elimina <>, controles y emojis
 * problemáticos, acorta a 12 caracteres y pone un fallback con número.
 * @param {string} raw nombre tal como lo escribió el usuario
 * @returns {string} nombre seguro
 */
export function sanitizeName(raw) {
  let s = String(raw || '');
  // Fuera etiquetas, controles y caracteres de formato
  s = s.replace(/[<>&"'`\\]/g, '').replace(/[\u0000-\u001f\u007f-\u009f]/g, '');
  // Fuera espacios múltiples y bordes
  s = s.trim().replace(/\s+/g, ' ');
  if (s.length > MAX_LEN) s = s.slice(0, MAX_LEN).trim();
  if (!s) s = 'Lobo' + Math.floor(10 + Math.random() * 90);
  return s;
}

/**
 * Carga el nombre guardado (o genera uno por defecto estable por sesión).
 * @returns {string}
 */
export function loadName() {
  try {
    const v = localStorage.getItem(KEY);
    if (v) return sanitizeName(v);
  } catch (e) {
    /* modo privado */
  }
  return 'Lobo' + Math.floor(10 + Math.random() * 90);
}

/**
 * Guarda el nombre (ya saneado).
 * @param {string} name
 */
export function saveName(name) {
  try {
    localStorage.setItem(KEY, sanitizeName(name));
  } catch (e) {
    /* modo privado */
  }
}
