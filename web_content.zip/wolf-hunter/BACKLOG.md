# BACKLOG · WOLF-HUNTER

Registro de mejoras **aplazadas a propósito**. Nada de esta lista se olvida:
cada fase nueva la repasa y decide qué entra.

---

## 🗺️ Pendiente directo del jugador (prioridad cuando se pida)

### Ampliar el terreno de juego
- **Qué**: mapa más grande y más abierto ("más libre"), no solo el anillo actual.
- **Por qué no ahora**: el usuario pidió explícitamente dejarlo para después.
- **Cómo cuando toque** (plan técnico ya pensado):
  1. `environment.js` está parametrizado por el objeto `MAP`: crecer
     `half` (24 → 36-40), ensanchar pasillos y añadir un segundo anillo
     con coberturas nuevas no cuesta nada al motor (la física es AABB
     + rampas analíticas, escala sin coste).
  2. El presupuesto de memoria sigue igual: geometría compartida
     (una sola `BoxGeometry` unitaria escalada por mesh).
  3. Ajustar `CAMERA_FAR`, la niebla del cielo (`sky.js`) y el frustum
     de sombra a las nuevas dimensiones.
  4. Ampliar `spawnPoints` si se añaden más de 4 (los spawns ya son
     un array puro, la red no asume exactamente 4).
- **Riesgo conocido**: partida P2P con mapa grande y 4 jugadores sigue
  siendo barato (STATE ≈ 200 B a 20 Hz); el límite será visual, no de red.

---

## 🐺 Devolución del análisis de Wolfteam (docs/wolfteam-analysis.md)

Ideas del juego original **fuera del alcance del prototipo** pero anotadas
para una versión 2:

- **Trepar/rodar paredes del Wolf** (correr hacia un muro y saltar sobre él):
  exigiría colisiones verticales con estados (pegado a pared, salto entre
  paredes). Añadir sólo si se pide; el `raycastColliders` ya existe.
- **Lobos avanzados como power-ups raros** (Fantasma: invisible al estar
  quieto; Guardián: lento, 850 HP, puede bloquear; Berserker; Hielo;
  Veneno): encajarían como variantes del Núcleo con probabilidad.
- **Modos extra**: Deathmatch por equipos, Ice Hold (eliminar equipo
  completo para puntuar), Conquista (puntos de control). El
  `round-manager.js` de la Fase 3 se diseña con `mode` enchufable.
- **WP System** (cargar 2 presets de armas y cambiar al instante): posible
  con el `weapon-hunter.js` previsto (dos loadouts y un botón de ciclo).

---

## 🔧 Técnico acumulado de las fases

- [x] Fase 4 ✔: viewmodel de brazos en primera persona (`js/viewmodel.js`):
      rifle con retroceso, recarga, sway y balanceo; zarpas alternas de lobo.
- [x] Fase 4 ✔: audio vía WebAudio 100 % sintetizado (`js/audio.js`):
      disparo, zarpazo, transformación, **aullido al recoger el Núcleo**,
      música del marcador, impactos, recarga, salto/aterrizaje, UI.
      Cero descargas (presupuesto intacto).
- [x] Fase 4 ✔: menú de ajustes (`js/settings-menu.js` + `js/settings.js`):
      sensibilidad, inversión Y, vibración, daltonismo (Okabe-Ito local),
      volúmenes por canal, FPS visibles y calidad (DPR/sombras) — §7 del
      análisis. En partida vía engranaje, sin pausar la ronda.
- [ ] Fase 5: reemplazar los avatares geométricos por modelos GLTF
      (lobo y soldado) sin tocar la lógica (`avatar.js` expone la misma
      interfaz: setYaw/setWalk/setWolf/setHp/setDead/flashHit).
- [ ] Fase 6: PWA offline completa (manifest + service worker ya previstos).
- [ ] Algún día: migración de host si el anfitrión se va (hoy: fin de
      partida, decisión fijada con el usuario).
- [ ] Algún día: cámara de muerte que siga al asesino (hoy: tercera
      persona fija sobre el propio cuerpo).
- [ ] Idea Fase 5+: pasos de sonido al caminar (requiere material del
      suelo o un loop genérico con volumen por velocidad).
