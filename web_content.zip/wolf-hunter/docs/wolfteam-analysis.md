# Análisis de WOLFTEAM · Referencia para WOLF-HUNTER

> Investigación en la red (15-11-2026) sobre el juego original en el que se
> inspira este prototipo: cómo funciona, sus mecánicas, modos, animaciones y
> ajustes, y qué decisiones tomamos de él para cada fase.
>
> Fuentes consultadas (verificadas):
> - Steam — *Wolfteam: Reboot* (Neosonyx, 2022): https://store.steampowered.com/app/2170050
> - Guía *How To Play Wolfteam* (Steam Community): https://steamcommunity.com/sharedfiles/filedetails/?id=2974660347
> - Giant Bomb — wiki WolfTeam: https://www.giantbomb.com/wolfteam/
> - Reimaru Files — *Wolfteam: The Reawakening of the Wolves* (2013): https://www.reimarufiles.com/2013/02/17/wolfteam-reawakening-wolves
> - All The Tropes — Wolf Team (tipos de lobo): https://allthetropes.org/wiki/Wolf_Team
> - MMOs.com — *Wolf Team Game Review*: https://www.mmos.com/review/wolf-team

---

## 1. Qué es Wolfteam

FPS *arena* gratuito nacido en 2007 (original de Softnyx, distribuido en
Occidente por Aeria Games; versión moderna *Wolfteam: Reboot* de Neosonyx,
dic. 2022). Su seña de identidad: **cada soldado puede transformarse en
hombre lobo en mitad del combate**, lo que convierte cada duelo en una
decisión de forma ("¿pego o disparo?").

El perfil técnico que interesa para este prototipo: es un juego **ligero de
geometría y textura** (corre en PCs modestísimos de 2007). El peso visual
recae en los **modelos de personaje**, no en el mapa. Eso valida nuestra
arquitectura: blockout plano barato + presupuesto de descarga gastado casi
íntegro en el personaje (Fase 5).

## 2. La transformación (mecánica central)

- El jugador **cambia de forma en caliente**: humano con armas de fuego ↔
  hombre lobo cuerpo a cuerpo. Steam lo resume: *"Switch forms during
  battle, adapt your combat style"*.
- La transformación es **estratégica, no cosmética**: humano = combate a
  distancia y precisión; lobo = velocidad, movilidad vertical y daño
  devastador en corto alcance.
- El lobo NO puede usar armas: sus garras son el arma. El humano NO tiene
  melee letal equivalente.
- **Cámara**: los humanos juegan en **primera persona** y el lobo se juega
  en **tercera persona** (por eso Steam etiqueta el juego a la vez como
  First-Person y Third-Person Shooter). Esto justifica el botón de cambio
  de cámara recién añadido al prototipo: en la Fase 3 el modo Wolf usará
  tercera persona por defecto, exactamente como Wolfteam.

**Adaptación en WOLF-HUNTER**: en nuestro modo *Cacería por Oleadas* la
transformación no es libre: hay que **arrebatársela al rival** recogiendo el
Núcleo de Fiera que suelta al morir, y dura 20 s. Mantenemos el contraste
humano-a-distancia / lobo-cuerpo-a-cuerpo y el cambio de cámara por forma.

## 3. Movimiento y controles del lobo

Según la guía oficial de Steam Community y la página de Reboot:

| Capacidad | Descripción en Wolfteam |
| --- | --- |
| Correr | El lobo es **mucho más rápido** que el humano |
| Saltar | Salta **más alto** y encadena saltos |
| **Trepar/rodar paredes** | Corres hacia un muro y saltas sobre él; con Espacio puedes **saltar a otro muro** encadenando escaladas |
| Ataque | Zarpazo letal a corta distancia; el *lunge* (embestida) cierra distancias |
| Cámara | Tercera persona (ver §2) |

**Adaptación**: Wolf = velocidad 7.0 vs 4.5, HP 180, melee 60 de daño,
alcance 2.0 (ver `config.js`). Trepar paredes queda anotado en
`BACKLOG.md` como mejora futura: exige un estado físico nuevo
(pegado-a-muro) que no cabe en el prototipo sin romper la predicción
cliente/host, y la decisión debe ser consciente, no improvisada.

## 4. Lobos avanzados (variantes)

Wolfteam ofrece variantes con reglas propias (All The Tropes, fichas del
juego):

- **Power Wolf**: fuerza bruta mejorada.
- **Ghost Wolf**: se **camufla si permanece quieto** y corre muy rápido.
- **Guardian Wolf**: el más lento (velocidad humana) pero **~850 HP** y
  puede **bloquear** con los brazos.
- **Berserker Wolf**: agresividad/daño potenciados.
- Variantes elementales (hielo, veneno) con efectos de estado.

**Adaptación**: anotado en `BACKLOG.md` como power-ups raros del Núcleo
para una versión 2 (p. ej. 10 % de que el Núcleo suelte "Fantasma" en vez
de lobo básico). No entra en el prototipo: cada variante duplica el coste
de testeo de balance.

## 5. Modos de juego

Wolfteam rota estos modos (Steam Reboot + MMOs.com + Giant Bomb):

1. **Death Match** (por equipos): primer equipo en alcanzar el límite de
   bajas gana.
2. **Conquest / Position Control**: capturar y mantener puntos.
3. **Ice Hold**: eliminar a todo el equipo rival para puntuar la ronda
   (sin reaparición hasta la siguiente).
4. **Destruction / Deactivation**: bomba estilo clásico (atacantes/defensores).
5. **Wolf Hunt / Occupation EX**: variantes con reglas de transformación
   especiales (equipos enteros de lobos, ocupación con zonas).
6. **Annihilation con revivificación**.

**Adaptación**: nuestro *Cacería por Oleadas* es una reinterpretación
asimétrica y sin equipos (todos contra todos con un único lobo activo a la
vez), pensada para 2-4 jugadores locales. `round-manager.js` (Fase 3) se
escribirá con un campo `mode` para poder añadir *Deathmatch por equipos*
después sin refactorizar.

## 6. Armas y sistema humano

- Arsenal moderno (rifles, subfusiles, francotirador…) con **WP System**:
  2 presets de armas intercambiables al instante para adaptar el loadout
  sin pasar por el menú.
- El coste real de "equipo" está en el personaje, no en el mapa (coincide
  con la observación del usuario).

**Adaptación**: prototipo con UNA arma (8 balas + 24 de reserva, recarga
manual de 1,5 s) para que el limador de balas importe. El WP System queda
en `BACKLOG.md` (la interfaz de `weapon-hunter.js` ya prevé "loadouts").

## 7. Ajustes y accesibilidad (referencia)

Wolfteam: Reboot expone: sensibilidad ajustable, alternativas de color,
controles de contraste, volúmenes por canal y sonido estéreo.

**Adaptación** (Fase 4, `settings-menu.js`): sensibilidad, inversión Y,
vibración, volumen, FPS visibles, calidad (DPR/sombras), daltonismo para
colores de jugador (etiqueta de nombre siempre visible).

## 8. Qué replica WOLF-HUNTER y en qué fase

| Elemento de Wolfteam | Fase | Dónde |
| --- | --- | --- |
| Humano en 1ª persona | 1 ✓ | `camera.js` |
| Lobo en 3ª persona (cámara configurable con botón) | 1.5 ✓ / 3 | `camera.js` + botón HUD |
| Contraste velocidad/HP humano vs lobo | 3 | `transform.js` + `config.js` |
| Zarpazo letal melee | 3 | `weapon-wolf.js` |
| Balas limitadas + recarga | 3 | `ammo.js` |
| Ronda con fin y marcador | 3 | `round-manager.js`, `score.js` |
| Muerte → suelta Núcleo → transformación | 3 | `beast-core.js` |
| Animaciones: correr, zarpazo, muerte, transformación | 5 | `animation.js` (GLTF Mixer) |
| Trepar paredes, lobos avanzados, más modos | backlog | `BACKLOG.md` |

## 9. Conclusiones para el prototipo

1. El motor de Wolfteam es barato porque **el mapa es barato**; nosotros
   igual (colores planos, cero texturas pesadas). El presupuesto se reserva
   para el personaje (Fase 5: modelo GLTF de lobo).
2. El **cambio de cámara por forma** es parte del lenguaje del juego
   original: mantenerlo (1ª humano / 3ª lobo) pero con override manual
   (botón) para comodidad del jugador.
3. La **decisión de transformarse** debe SENTIRSE: en Wolfteam es un
   momento de poder. Nuestro Núcleo + 20 s de lobo + marcador por segundo
   sobrevivido captura ese loop sin copiar el F2P.
4. Nada de Wolfteam exige texturas realistas: la legibilidad viene del
   **contraste de siluetas y color**. El cielo azul realista recién
   añadido ayuda exactamente a eso (el lobo oscuro se lee contra el cielo).
