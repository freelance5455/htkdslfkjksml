# WOLF-HUNTER

FPS multijugador local (P2P por WebRTC) para navegador móvil, inspirado en
la transformación Hunter/Wolf de Wolfteam. Prototipo en fases.

**Estado: FASE 4 completa** — HUD pulido (retículo dinámico, kickers,
viñetas de estado), **brazos y arma en primera persona**, **audio 100 %
sintetizado** (disparos, zarpazos, transformación y EL AULLIDO, sin
descargar ni un byte) y **menú de Ajustes** en caliente (sensibilidad,
inversión Y, vibración, daltonismo, volúmenes, FPS y calidad), sobre el
combate y el multijugador P2P de las fases anteriores.

## Cómo se juega: Cacería por Oleadas (Fase 3)

Una ronda dura **3 minutos**, todos contra todos, con **un solo lobo activo**
a la vez:

1. Al empezar, el **Núcleo de Fiera** aparece flotando sobre el pedestal
   central (sigue su haz de luz naranja).
2. Quien lo toque se **transforma en lobo durante 20 s**: corre más rápido
   (7.0 vs 4.5), salta igual pero aguanta mucho más (180 HP) y sus **garras**
   barren un arco frontal de 60 de daño. La cámara pasa a tercera persona,
   como en Wolfteam (el botón sigue permitiendo alternar).
3. Los **hunters** disparan con la única arma del prototipo: **8 balas +
   24 de reserva** y recarga manual de 1,5 s. El límite de munición es lo
   que hace importar la puntería.
4. Si el lobo **muere**, suelta el Núcleo donde cayó: la siguiente oleada
   empieza ahí mismo. Si **sobrevive** sus 20 s, vuelve a ser hunter y el
   Núcleo regresa al pedestal.
5. **Puntos**: 1 por eliminación + **1 por cada segundo sobrevivido como
   lobo**. Aguantar la transformación es el premio gordo; arrebatársela al
   rival, el corazón del modo.
6. Al acabar el tiempo: marcador final y vuelta al lobby para la revancha.

El modo **Explorar solo** es la pista de pruebas: el Núcleo del pedestal se
puede recoger y la transformación completa funciona sin rivales.

## Cómo servirlo (obligatorio: HTTPS para la red, nunca file://)

Los módulos ES y WebRTC no funcionan abriendo `index.html` con doble clic.

```bash
# Opción A · Python (en tu PC) — vale para probar SOLO (Explorar)
python3 -m http.server 8080
# → abre http://TU_IP_LOCAL:8080 en el móvil (misma WiFi)

# Opción B · Node
npx serve .

# Para partidas P2P REALES entre móviles hace falta HTTPS:
# GitHub Pages (recomendado, gratis) · Netlify Drop · ngrok http 8080
```

> La señal P2P se presenta a través del broker público de PeerJS (usa
> internet un momento); los datos del juego viajan DIRECTO entre los
> móviles por la WiFi local.

## Cómo se juega en grupo

1. Un móvil **crea la sala** (contraseña opcional) y obtiene un **código
   de 4 caracteres + QR**.
2. Los demás **escanean el QR** (o escriben el código) desde la misma WiFi.
3. El anfitrión pulsa **Empezar partida**: Núcleo al pedestal y ¡a cazar!
4. Al terminar la ronda, el marcador corona al mejor cazador y todos
   vuelven al lobby.
5. Atrás o "Volver al menú" cierra tu conexión; si el anfitrión se va,
   la partida termina para todos (decisión de diseño: sin migración de host).

## Controles

| Acción | Móvil (táctil) | Escritorio (desarrollo) |
| --- | --- | --- |
| Moverse | Joystick dinámico en la mitad izquierda | WASD / flechas |
| Cámara | Arrastre en la mitad derecha | Arrastre o clic (captura ratón), Esc libera |
| Saltar | Botón inferior derecho | Espacio |
| Disparar / Zarpazo | Botón grande (mantener = automático) | Clic con el ratón capturado |
| Recargar | Botón pequeño junto al salto | R |
| Cámara 1ª↔3ª persona | Botón redondo (esquina sup. derecha) | Tecla C |
| Ajustes (en partida) | Engranaje (junto al botón de cámara) | — |

La preferencia de cámara se recuerda en el dispositivo. La forma lobo usa
tercera persona por defecto (como en Wolfteam); el botón siempre manda.

## Estructura

```
wolf-hunter/
├── index.html            Bootstrap: CDN con fallback + importmap + pantallas
├── styles.css            Design system (tokens de movimiento de Emil Kowalski)
├── config.js             TODOS los valores de balance/red/cielo, sin tocar código
├── BACKLOG.md            Mejoras aplazadas (terreno más grande, ideas Wolfteam)
├── docs/
│   └── wolfteam-analysis.md  Análisis del juego original (fuentes citadas)
└── js/
    ├── version.js        Versión del juego/protocolo (0.4.0)
    ├── main.js           Arranque, composición, bucle de render, ciclo de vida
    ├── environment.js    Mapa blockout + física estática (colisiones/suelo/rayos)
    ├── lighting.js       HemisphereLight + DirectionalLight con sombra opcional
    ├── sky.js            Cielo procedural: gradiente + sol + nubes + niebla
    ├── camera.js         Rig 1ª/3ª persona, FOV y distancia según la forma
    ├── avatar.js         Hunter geométrico + LOBO cuadrúpedo (galope) + etiqueta
    ├── input.js          Multitouch real, joystick, disparo/recarga, teclado/ratón
    ├── movement.js       Física COMPARTIDA cliente/host (determinista)
    ├── player.js         Jugador local (delega la física; muerto = mira sin mover)
    ├── prediction.js     Predicción cliente + reconciliación + resync por forma
    ├── remote-players.js Remotos interpolados (forma, vida, muerte, invulnerabilidad)
    ├── protocol.js       Los 20 mensajes del protocolo + validación
    ├── network.js        PeerJS: host autoritativo, rate-limit, errores ES
    ├── time-sync.js      Reloj común estilo NTP (PING/PONG, mediana)
    ├── ammo.js           Munición compartida cliente/host (cargador + recarga)
    ├── weapon-hunter.js  Hitscan local + aim assist sutil + recarga pedida
    ├── weapon-wolf.js    Garra local (el arco visual propio es inmediato)
    ├── transform.js      Presentación local de la forma (avatar/cámara/HUD)
    ├── beast-core.js     El Núcleo de Fiera: vista (cristal, haz, anillo)
    ├── round-manager.js  ÁRBITRO: daño, muertes, respawn, Núcleo, rondas
    ├── score.js          Marcador (bajas + segundos de lobo)
    ├── hud.js            HUD de combate: vida, munición, timers, feed, marcador
    ├── fx.js             Trazadoras y arcos de zarpazo (pools, cero GC)
    ├── game-session.js   Orquestador: solo / host / cliente + combate
    ├── game-states.js    Máquina de estados + gestor de pantallas
    ├── ui-connection.js  Menú, crear/unirse, lobby con QR
    ├── player-names.js   Nombres saneados y persistentes
    ├── audio.js          (F4) Motor WebAudio sintetizado: cero descargas
    ├── viewmodel.js      (F4) Brazos/rifle/garras en 1ª persona
    ├── settings.js       (F4) Ajustes persistentes + daltonismo + vibración
    ├── settings-menu.js  (F4) Pantalla de Ajustes (overlay en caliente)
    ├── debug.js          log() silenciable + contador de FPS
    ├── error-handler.js  Overlay de error con diagnóstico copiable
    ├── loading-screen.js Pantalla de carga con pasos y progreso
    └── lib/
        └── peerjs-loader.js  Carga perezosa de PeerJS (doble CDN)
```

## Arquitectura de red y combate (resumen)

- **Host autoritativo**: valida HELLO (versión, aforo, contraseña, partida
  en curso), simula a TODOS con los sub-pasos exactos que recibe y difunde
  STATE a 20 Hz (5 Hz en lobby) con vida/forma/munición de cada uno.
- **Combate arbitrado**: el cliente solo PIDE (SHOOT/CLAW/RELOAD); el host
  valida cadencia con su reloj, munición con su contador, origen creíble,
  forma y arco, y difunde los efectos (SHOOT_FX/CLAW_FX/HIT/DEATH/…).
  Los efectos del propio host pasan por el mismo conducto: una sola ruta
  de presentación, cero divergencia entre host y clientes.
- **Predicción exacta**: el cliente simula cada frame con la misma física
  y envía los sub-pasos con su dt real; al transformarse (la velocidad
  cambia) fuerza una resincronización limpia con el próximo STATE.
- **Interpolación 100 ms**: los remotos se pintan en el reloj del host
  menos 100 ms, con salto automático si hay un hueco > 400 ms.
- **Anti-flood**: cubo de tokens por conexión (30 msg/s, expulsión a la 3ª
  infracción en 10 s).
- Verifica tu propia partida con `?netdebug`.

## Flags de depuración (URL)

- `?debug` — logs en consola + gancho `window.__wolf` (estado del juego)
- `?fps` — contador de FPS en el HUD
- `?netdebug` — overlay de métricas de red (rtt, offset, tick, ronda, núcleo)
- `?join=CODE` — abre directo la pantalla de unirse (es lo que codifica el QR)

## Ajustes rápidos

Todo vive en `config.js`: velocidades, vida, daño, cadencias, munición,
duración del lobo y de la ronda, puntuación, cámara, cielo, red, etc.

## Desarrollo con Git

```bash
git init && git add -A && git commit -m "Fase 4: HUD pulido, audio sintetizado y ajustes"
```

## Ajustes (Fase 4)

Botón **Ajustes** en el menú y el lobby, o el **engranaje** durante la
partida (la ronda sigue: es un overlay). Todo persiste en el dispositivo
y se aplica en caliente:

- **Sensibilidad** de cámara (0,3×–2,5×) e **inversión del eje Y**.
- **Vibración** (daño, muerte, baja, transformación).
- **Colores aptos para daltonismo**: paleta Okabe-Ito solo en tu pantalla.
- **Volumen** general / efectos / interfaz.
- **Mostrar FPS** y **calidad gráfica** (Auto / Alta / Baja: resolución y
  sombras) para móviles justitos.

## Sonido y viewmodel (Fase 4)

- **Audio 100 % sintetizado** con WebAudio: disparos, zarpazos, impactos,
  recarga mecánica, salto/aterrizaje, transformación, **aullido** al
  recoger el Núcleo, campana de aparición del Núcleo, inicio y fin de
  ronda, y clics de interfaz. Los efectos de los RIVALES suenan con
  distancia y lado (paneo estéreo). Cero MB de descarga.
- **Brazos en primera persona**: rifle a dos manos con retroceso,
  recarga animada (1,5 s), balanceo al caminar y sway que persigue la
  mirada; fogonazo en la boca del cañón. En forma lobo, dos zarpas que
  barren alternándose. Nunca atraviesa muros (sin test de profundidad).
- **Retículo dinámico**: se abre al correr y al disparar, compacto en
  forma lobo, tenue al recargar.
- **Jugos de HUD**: los números saltan al cambiar (kicker), la viñeta
  roja respira con vida baja, el temporizador del lobo late en su final,
  y la transformación estrena titular + destello.

## Hoja de ruta

| Fase | Contenido | Estado |
| --- | --- | --- |
| 1 | Entorno y base jugable | Completada |
| 1.5 | Cámara 1ª/3ª persona + cielo realista | Completada |
| 2 | Multijugador PeerJS (P2P, QR, predicción) | Completada |
| 3 | Combate, Núcleo, transformación, rondas | Completada |
| 4 | HUD pulido + audio + ajustes | Completada |
| 5 | Modelo del lobo con animaciones (GLTF) | Pendiente |
| 6 | PWA + despliegue | Pendiente |
