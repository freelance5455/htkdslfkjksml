// ======================
// مذكرة - Notes App
// ======================

const STORAGE_KEY = 'mudakira_notes_v1';
const SETTINGS_KEY = 'mudakira_settings_v1';

// Default settings
const defaultSettings = {
  accentColor: '#8b5cf6',
  fontSize: 'medium',
  density: 'comfortable',
  sortBy: 'updated',
  categories: [
    { id: 'cat1', name: 'شخصي', color: '#8b5cf6' },
    { id: 'cat2', name: 'عمل', color: '#3b82f6' },
    { id: 'cat3', name: 'أفكار', color: '#10b981' }
  ]
};

// App State
let notes = [];
let settings = { ...defaultSettings };
let currentNoteId = null;
let currentFilter = 'all'; // all | pinned | categoryId | trash
let searchQuery = '';
let pendingUnlockNoteId = null;

// DOM Elements
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

// ======================
// Initialization
// ======================
document.addEventListener('DOMContentLoaded', () => {
  loadData();
  applySettings();
  render();
  bindEvents();
  lucide.createIcons();
});

function loadData() {
  try {
    const savedNotes = localStorage.getItem(STORAGE_KEY);
    notes = savedNotes ? JSON.parse(savedNotes) : [];
    
    const savedSettings = localStorage.getItem(SETTINGS_KEY);
    if (savedSettings) {
      settings = { ...defaultSettings, ...JSON.parse(savedSettings) };
    }
  } catch (e) {
    console.error('Load error', e);
    notes = [];
  }
}

function saveNotes() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
}

function saveSettings() {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

// ======================
// Rendering
// ======================
function render() {
  renderCategoriesFilter();
  renderNotesList();
  updateNotesCount();
  lucide.createIcons();
}

function updateNotesCount() {
  const activeCount = notes.filter(n => !n.deleted).length;
  $('#notes-count').textContent = `${activeCount} ملاحظة`;
}

function renderCategoriesFilter() {
  const container = $('#categories-filter');
  let html = `
    <button class="cat-pill px-3.5 py-1.5 rounded-full text-sm font-medium bg-dark-700 ${currentFilter === 'all' ? 'active' : ''}" data-filter="all">
      الكل
    </button>
    <button class="cat-pill px-3.5 py-1.5 rounded-full text-sm font-medium bg-dark-700 ${currentFilter === 'pinned' ? 'active' : ''}" data-filter="pinned">
      مثبتة
    </button>
  `;
  
  settings.categories.forEach(cat => {
    html += `
      <button class="cat-pill px-3.5 py-1.5 rounded-full text-sm font-medium bg-dark-700 ${currentFilter === cat.id ? 'active' : ''}" 
              data-filter="${cat.id}" style="${currentFilter === cat.id ? `background:${cat.color}` : ''}">
        ${cat.name}
      </button>
    `;
  });
  
  container.innerHTML = html;
  
  // Bind filter clicks
  container.querySelectorAll('.cat-pill').forEach(btn => {
    btn.addEventListener('click', () => {
      currentFilter = btn.dataset.filter;
      render();
    });
  });
}

function getFilteredNotes() {
  let list = notes.filter(n => !n.deleted);
  
  // Search
  if (searchQuery.trim()) {
    const q = searchQuery.trim().toLowerCase();
    list = list.filter(n => 
      (n.title || '').toLowerCase().includes(q) || 
      (n.content || '').toLowerCase().includes(q)
    );
  }
  
  // Filter
  if (currentFilter === 'pinned') {
    list = list.filter(n => n.pinned);
  } else if (currentFilter !== 'all') {
    list = list.filter(n => n.categoryId === currentFilter);
  }
  
  // Sort
  list.sort((a, b) => {
    // Pinned always first
    if (a.pinned && !b.pinned) return -1;
    if (!a.pinned && b.pinned) return 1;
    
    if (settings.sortBy === 'title') {
      return (a.title || '').localeCompare(b.title || '', 'ar');
    } else if (settings.sortBy === 'created') {
      return b.createdAt - a.createdAt;
    } else {
      return b.updatedAt - a.updatedAt;
    }
  });
  
  return list;
}

function renderNotesList() {
  const container = $('#notes-list');
  const list = getFilteredNotes();
  
  if (list.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <i data-lucide="notebook-pen"></i>
        <p class="text-base font-medium mb-1">لا توجد ملاحظات</p>
        <p class="text-sm">اضغط + لإنشاء ملاحظتك الأولى</p>
      </div>
    `;
    lucide.createIcons();
    return;
  }
  
  container.innerHTML = list.map(note => {
    const cat = settings.categories.find(c => c.id === note.categoryId);
    const preview = (note.content || '').replace(/[#*_`>-]/g, '').trim().slice(0, 100);
    const dateStr = formatDate(note.updatedAt);
    
    return `
      <div class="note-card bg-dark-800 rounded-2xl px-4 cursor-pointer border border-white/5 hover:border-white/10 ${note.locked ? 'locked-indicator' : ''}" 
           data-id="${note.id}">
        <div class="flex items-start gap-3">
          <div class="flex-1 min-w-0">
            <div class="flex items-center gap-2 mb-1">
              ${note.pinned ? '<i data-lucide="pin" class="w-3.5 h-3.5 text-accent shrink-0"></i>' : ''}
              ${note.locked ? '<i data-lucide="lock" class="w-3.5 h-3.5 text-white/40 shrink-0"></i>' : ''}
              <h3 class="font-semibold truncate ${note.title ? '' : 'text-white/40'}">
                ${escapeHtml(note.title || 'بدون عنوان')}
              </h3>
            </div>
            <p class="text-sm text-white/50 line-clamp-2 leading-relaxed">
              ${note.locked ? '••••••••••••' : escapeHtml(preview) || 'فارغة'}
            </p>
            <div class="flex items-center gap-2 mt-2.5">
              ${cat ? `<span class="text-xs px-2 py-0.5 rounded-full" style="background:${cat.color}22;color:${cat.color}">${cat.name}</span>` : ''}
              <span class="text-xs text-white/30">${dateStr}</span>
            </div>
          </div>
        </div>
      </div>
    `;
  }).join('');
  
  // Bind click
  container.querySelectorAll('.note-card').forEach(card => {
    card.addEventListener('click', () => openNote(card.dataset.id));
  });
  
  lucide.createIcons();
}

function renderCategoriesSettings() {
  const container = $('#categories-list');
  if (settings.categories.length === 0) {
    container.innerHTML = `<div class="px-4 py-4 text-sm text-white/40 text-center">لا توجد تصنيفات</div>`;
    return;
  }
  
  container.innerHTML = settings.categories.map(cat => `
    <div class="px-4 py-3 flex items-center justify-between">
      <div class="flex items-center gap-3">
        <div class="w-4 h-4 rounded-full" style="background:${cat.color}"></div>
        <span>${escapeHtml(cat.name)}</span>
      </div>
      <button class="text-red-400/80 text-sm delete-cat" data-id="${cat.id}">حذف</button>
    </div>
  `).join('');
  
  container.querySelectorAll('.delete-cat').forEach(btn => {
    btn.addEventListener('click', () => {
      if (confirm('حذف هذا التصنيف؟')) {
        settings.categories = settings.categories.filter(c => c.id !== btn.dataset.id);
        // Remove category from notes
        notes.forEach(n => {
          if (n.categoryId === btn.dataset.id) n.categoryId = '';
        });
        saveSettings();
        saveNotes();
        renderCategoriesSettings();
        render();
      }
    });
  });
}

function renderTrash() {
  const container = $('#trash-list');
  const trashed = notes.filter(n => n.deleted).sort((a,b) => b.updatedAt - a.updatedAt);
  
  if (trashed.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <i data-lucide="trash-2"></i>
        <p class="text-base font-medium">السلة فارغة</p>
      </div>
    `;
    lucide.createIcons();
    return;
  }
  
  container.innerHTML = trashed.map(note => `
    <div class="bg-dark-800 rounded-2xl px-4 py-3.5 flex items-center justify-between">
      <div class="min-w-0 flex-1">
        <h3 class="font-medium truncate">${escapeHtml(note.title || 'بدون عنوان')}</h3>
        <p class="text-xs text-white/40 mt-0.5">${formatDate(note.updatedAt)}</p>
      </div>
      <div class="flex gap-2 shrink-0 mr-2">
        <button class="restore-btn px-3 py-1.5 rounded-lg bg-dark-700 text-sm" data-id="${note.id}">استعادة</button>
        <button class="delete-forever-btn px-3 py-1.5 rounded-lg bg-red-500/20 text-red-400 text-sm" data-id="${note.id}">حذف</button>
      </div>
    </div>
  `).join('');
  
  container.querySelectorAll('.restore-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const note = notes.find(n => n.id === btn.dataset.id);
      if (note) {
        note.deleted = false;
        note.updatedAt = Date.now();
        saveNotes();
        renderTrash();
        showToast('تم استعادة الملاحظة');
      }
    });
  });
  
  container.querySelectorAll('.delete-forever-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      if (confirm('حذف نهائي؟ لا يمكن التراجع.')) {
        notes = notes.filter(n => n.id !== btn.dataset.id);
        saveNotes();
        renderTrash();
        showToast('تم الحذف نهائيًا');
      }
    });
  });
}

// ======================
// Navigation
// ======================
function showScreen(id) {
  ['home', 'editor', 'settings', 'trash'].forEach(s => {
    $(`#screen-${s}`).classList.toggle('hidden', s !== id);
  });
}

function openNote(id) {
  const note = notes.find(n => n.id === id);
  if (!note) return;
  
  if (note.locked) {
    pendingUnlockNoteId = id;
    $('#lock-password').value = '';
    $('#lock-modal').classList.remove('hidden');
    setTimeout(() => $('#lock-password').focus(), 100);
    return;
  }
  
  currentNoteId = id;
  fillEditor(note);
  showScreen('editor');
}

function fillEditor(note) {
  $('#note-title').value = note.title || '';
  $('#note-content').value = note.content || '';
  $('#note-date').textContent = formatDate(note.updatedAt, true);
  
  // Categories select
  const select = $('#note-category');
  select.innerHTML = `<option value="">بدون تصنيف</option>` + 
    settings.categories.map(c => 
      `<option value="${c.id}" ${note.categoryId === c.id ? 'selected' : ''}>${c.name}</option>`
    ).join('');
  
  // Pin & Lock icons state
  updateEditorIcons(note);
  updateWordCount();
}

function updateEditorIcons(note) {
  const pinBtn = $('#btn-pin-note');
  const lockBtn = $('#btn-lock-note');
  
  pinBtn.innerHTML = note.pinned 
    ? '<i data-lucide="pin-off" class="w-5 h-5 text-accent"></i>' 
    : '<i data-lucide="pin" class="w-5 h-5"></i>';
    
  lockBtn.innerHTML = note.locked 
    ? '<i data-lucide="lock" class="w-5 h-5 text-accent"></i>' 
    : '<i data-lucide="lock-open" class="w-5 h-5"></i>';
    
  lucide.createIcons();
}

function createNewNote() {
  const id = 'note_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
  const now = Date.now();
  const note = {
    id,
    title: '',
    content: '',
    categoryId: currentFilter !== 'all' && currentFilter !== 'pinned' ? currentFilter : '',
    pinned: false,
    locked: false,
    password: '',
    deleted: false,
    createdAt: now,
    updatedAt: now
  };
  notes.unshift(note);
  saveNotes();
  currentNoteId = id;
  fillEditor(note);
  showScreen('editor');
  setTimeout(() => $('#note-title').focus(), 100);
}

// ======================
// Note Actions
// ======================
function saveCurrentNote() {
  if (!currentNoteId) return;
  const note = notes.find(n => n.id === currentNoteId);
  if (!note) return;
  
  note.title = $('#note-title').value.trim();
  note.content = $('#note-content').value;
  note.categoryId = $('#note-category').value;
  note.updatedAt = Date.now();
  saveNotes();
  $('#note-date').textContent = formatDate(note.updatedAt, true);
}

function deleteCurrentNote() {
  if (!currentNoteId) return;
  if (!confirm('نقل الملاحظة إلى سلة المحذوفات؟')) return;
  
  const note = notes.find(n => n.id === currentNoteId);
  if (note) {
    note.deleted = true;
    note.updatedAt = Date.now();
    saveNotes();
    showToast('تم النقل إلى السلة');
    showScreen('home');
    render();
  }
}

function togglePin() {
  const note = notes.find(n => n.id === currentNoteId);
  if (!note) return;
  note.pinned = !note.pinned;
  note.updatedAt = Date.now();
  saveNotes();
  updateEditorIcons(note);
  showToast(note.pinned ? 'تم التثبيت' : 'تم إلغاء التثبيت');
}

function toggleLock() {
  const note = notes.find(n => n.id === currentNoteId);
  if (!note) return;
  
  if (note.locked) {
    // Unlock
    note.locked = false;
    note.password = '';
    note.updatedAt = Date.now();
    saveNotes();
    updateEditorIcons(note);
    showToast('تم إزالة القفل');
  } else {
    // Show set password modal
    $('#set-password-input').value = '';
    $('#set-password-confirm').value = '';
    $('#set-password-modal').classList.remove('hidden');
    setTimeout(() => $('#set-password-input').focus(), 100);
  }
}

function exportCurrentNote() {
  const note = notes.find(n => n.id === currentNoteId);
  if (!note) return;
  
  const text = `# ${note.title || 'بدون عنوان'}\n\n${note.content || ''}`;
  const blob = new Blob([text], { type: 'text/markdown;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${(note.title || 'note').slice(0, 30)}.md`;
  a.click();
  URL.revokeObjectURL(url);
  showToast('تم التصدير');
}

// ======================
// Settings & Customization
// ======================
function applySettings() {
  // Accent color
  document.documentElement.style.setProperty('--accent', settings.accentColor);
  document.documentElement.style.setProperty('--accent-hover', adjustColor(settings.accentColor, -20));
  
  // Update accent color buttons
  $$('#accent-colors button').forEach(btn => {
    const isActive = btn.dataset.color === settings.accentColor;
    btn.classList.toggle('ring-2', isActive);
    btn.classList.toggle('ring-offset-2', isActive);
    btn.classList.toggle('ring-offset-dark-800', isActive);
    btn.classList.toggle('ring-white', isActive);
  });
  
  // Font size
  document.body.classList.remove('font-small', 'font-medium', 'font-large');
  document.body.classList.add(`font-${settings.fontSize}`);
  
  // Density
  document.body.classList.remove('density-compact', 'density-comfortable');
  document.body.classList.add(`density-${settings.density}`);
  
  // Form values
  $('#setting-font-size').value = settings.fontSize;
  $('#setting-density').value = settings.density;
  $('#setting-sort').value = settings.sortBy;
}

// ======================
// Events
// ======================
function bindEvents() {
  // Navigation
  $('#btn-new-note').addEventListener('click', createNewNote);
  $('#btn-back-editor').addEventListener('click', () => {
    saveCurrentNote();
    showScreen('home');
    render();
  });
  $('#btn-settings').addEventListener('click', () => {
    renderCategoriesSettings();
    showScreen('settings');
  });
  $('#btn-back-settings').addEventListener('click', () => {
    showScreen('home');
    render();
  });
  $('#btn-trash').addEventListener('click', () => {
    renderTrash();
    showScreen('trash');
  });
  $('#btn-back-trash').addEventListener('click', () => {
    showScreen('settings');
  });
  
  // Search
  $('#btn-search-toggle').addEventListener('click', () => {
    const bar = $('#search-bar');
    bar.classList.toggle('hidden');
    if (!bar.classList.contains('hidden')) {
      $('#search-input').focus();
    } else {
      searchQuery = '';
      $('#search-input').value = '';
      render();
    }
  });
  $('#search-input').addEventListener('input', (e) => {
    searchQuery = e.target.value;
    renderNotesList();
  });
  
  // Editor auto-save
  let saveTimeout;
  const autoSave = () => {
    clearTimeout(saveTimeout);
    saveTimeout = setTimeout(saveCurrentNote, 400);
    updateWordCount();
  };
  $('#note-title').addEventListener('input', autoSave);
  $('#note-content').addEventListener('input', autoSave);
  $('#note-category').addEventListener('change', autoSave);
  
  // Editor actions
  $('#btn-pin-note').addEventListener('click', togglePin);
  $('#btn-lock-note').addEventListener('click', toggleLock);
  $('#btn-export-note').addEventListener('click', exportCurrentNote);
  $('#btn-delete-note').addEventListener('click', deleteCurrentNote);
  
  // Lock modal
  $('#btn-lock-cancel').addEventListener('click', () => {
    $('#lock-modal').classList.add('hidden');
    pendingUnlockNoteId = null;
  });
  $('#btn-lock-confirm').addEventListener('click', () => {
    const pass = $('#lock-password').value;
    const note = notes.find(n => n.id === pendingUnlockNoteId);
    if (note && note.password === pass) {
      $('#lock-modal').classList.add('hidden');
      currentNoteId = pendingUnlockNoteId;
      pendingUnlockNoteId = null;
      fillEditor(note);
      showScreen('editor');
    } else {
      showToast('كلمة المرور غير صحيحة');
      $('#lock-password').value = '';
      $('#lock-password').focus();
    }
  });
  $('#lock-password').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') $('#btn-lock-confirm').click();
  });
  
  // Set password modal
  $('#btn-set-pass-cancel').addEventListener('click', () => {
    $('#set-password-modal').classList.add('hidden');
  });
  $('#btn-set-pass-confirm').addEventListener('click', () => {
    const p1 = $('#set-password-input').value;
    const p2 = $('#set-password-confirm').value;
    if (!p1 || p1.length < 3) {
      showToast('كلمة المرور قصيرة جدًا');
      return;
    }
    if (p1 !== p2) {
      showToast('كلمتا المرور غير متطابقتين');
      return;
    }
    const note = notes.find(n => n.id === currentNoteId);
    if (note) {
      note.locked = true;
      note.password = p1;
      note.updatedAt = Date.now();
      saveNotes();
      updateEditorIcons(note);
      $('#set-password-modal').classList.add('hidden');
      showToast('تم تأمين الملاحظة');
    }
  });
  
  // Settings
  $$('#accent-colors button').forEach(btn => {
    btn.addEventListener('click', () => {
      settings.accentColor = btn.dataset.color;
      saveSettings();
      applySettings();
    });
  });
  
  $('#setting-font-size').addEventListener('change', (e) => {
    settings.fontSize = e.target.value;
    saveSettings();
    applySettings();
  });
  $('#setting-density').addEventListener('change', (e) => {
    settings.density = e.target.value;
    saveSettings();
    applySettings();
  });
  $('#setting-sort').addEventListener('change', (e) => {
    settings.sortBy = e.target.value;
    saveSettings();
  });
  
  // Add category
  $('#btn-add-category').addEventListener('click', () => {
    const name = prompt('اسم التصنيف الجديد:');
    if (!name || !name.trim()) return;
    const colors = ['#8b5cf6', '#ec4899', '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#06b6d4'];
    const color = colors[settings.categories.length % colors.length];
    settings.categories.push({
      id: 'cat_' + Date.now(),
      name: name.trim(),
      color
    });
    saveSettings();
    renderCategoriesSettings();
    showToast('تمت إضافة التصنيف');
  });
  
  // Export all
  $('#btn-export-all').addEventListener('click', () => {
    const data = {
      notes: notes.filter(n => !n.deleted),
      categories: settings.categories,
      exportedAt: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mudakira-backup-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('تم تصدير النسخة الاحتياطية');
  });
  
  // Import
  $('#btn-import').addEventListener('click', () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        try {
          const data = JSON.parse(ev.target.result);
          if (data.notes && Array.isArray(data.notes)) {
            // Merge notes (avoid duplicates by id)
            const existingIds = new Set(notes.map(n => n.id));
            let added = 0;
            data.notes.forEach(n => {
              if (!existingIds.has(n.id)) {
                notes.push(n);
                added++;
              }
            });
            if (data.categories) {
              data.categories.forEach(c => {
                if (!settings.categories.find(sc => sc.id === c.id)) {
                  settings.categories.push(c);
                }
              });
            }
            saveNotes();
            saveSettings();
            render();
            showToast(`تم استيراد ${added} ملاحظة`);
          }
        } catch {
          showToast('ملف غير صالح');
        }
      };
      reader.readAsText(file);
    };
    input.click();
  });
}

// ======================
// Helpers
// ======================
function formatDate(ts, full = false) {
  const d = new Date(ts);
  const now = new Date();
  const diff = now - d;
  
  if (diff < 60000) return 'الآن';
  if (diff < 3600000) return `${Math.floor(diff/60000)} د`;
  if (diff < 86400000 && d.getDate() === now.getDate()) {
    return d.toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' });
  }
  if (full) {
    return d.toLocaleDateString('ar', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  }
  return d.toLocaleDateString('ar', { month: 'short', day: 'numeric' });
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function updateWordCount() {
  const text = $('#note-content').value.trim();
  const words = text ? text.split(/\s+/).length : 0;
  $('#word-count').textContent = `${words} كلمة`;
}

function showToast(msg) {
  const toast = $('#toast');
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 2200);
}

function adjustColor(hex, amount) {
  let c = hex.replace('#', '');
  if (c.length === 3) c = c[0]+c[0]+c[1]+c[1]+c[2]+c[2];
  const num = parseInt(c, 16);
  let r = Math.min(255, Math.max(0, (num >> 16) + amount));
  let g = Math.min(255, Math.max(0, ((num >> 8) & 0x00FF) + amount));
  let b = Math.min(255, Math.max(0, (num & 0x0000FF) + amount));
  return `#${(r<<16 | g<<8 | b).toString(16).padStart(6, '0')}`;
}
