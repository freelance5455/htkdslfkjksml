MERA AI — FREE-TIER AI CHAT STARTER
==================================

Zaroori baat:
- Yeh ChatGPT ka exact clone nahi hai; yeh ek simple AI chat app starter hai.
- App mein subscription/premium payment code nahi hai.
- AI replies ke liye Google Gemini API ki zaroorat hai. Google AI Studio par free API key mil sakti hai, lekin free-tier limits, availability aur terms badal sakte hain. Unlimited free use ki guarantee nahi hai.
- API key ko public website ya kisi ke saath share na karein. Is demo mein key isi browser ke local storage mein save hoti hai; personal testing ke liye rakhein.

ANDROID PAR ISTEMAL:
1. ZIP extract karein.
2. index.html ko browser mein kholkar test kar sakte hain, lekin kuch phones par file:// se API request block ho sakti hai.
3. Behtar tareeqa: project ko kisi free static hosting par deploy karein (jaise GitHub Pages/Cloudflare Pages), phir HTTPS link Chrome mein kholein.
4. Google AI Studio: https://aistudio.google.com/ par sign in karein aur API key banayein.
5. App kholein -> ⚙️ Settings -> API key paste karein -> Save.
6. Ab chat mein sawaal likhein aur ➤ dabayein.
7. Chrome menu se “Add to Home screen” / “Install app” chun sakte hain (hosting ke baad).

FILES:
- index.html: chat UI aur API integration
- manifest.json: PWA metadata
- sw.js: basic offline app-shell cache

LIMITATIONS:
- Internet required for AI replies.
- Free API quota/rate limits apply.
- Chat history is kept only in the current page session and is not uploaded to your own database.
- Do not use this client-side demo for a public multi-user service. For that, use a backend to protect API keys.
