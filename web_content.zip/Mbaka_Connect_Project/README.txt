MBAKA CONNECT — STARTER PROJECT v0.3
Made by Lewis Mbaka Nyangau

WHAT'S NEW IN v0.3
- Added the custom Mbaka Connect logo to the header and home welcome area.
- Added the creator credit: Made by Lewis Mbaka Nyangau.
- Added a Files & Documents screen prototype for selecting PDF, ZIP, APK and other files.
- Added demo Groups & Channels screen and a shortcut from Messages.
- Kept the green social feed, stories, demo likes, friends, chats, profile, reels/video preview, settings, and local post saving.

HOW TO OPEN
Keep the folder structure intact. Open index.html in a browser, or use a ZIP-to-APK tool that accepts website project ZIPs.

IMPORTANT LIMITATIONS
This is a front-end prototype, not a finished online social network. Posts and likes are saved locally in the browser on this device. The file picker only selects and reports a file; it does not upload it to other people. Real user accounts, cross-user chat, calls, cloud media uploads, a reliable 50 MB daily quota, background midnight delivery, native fingerprint/pattern AppLock, screenshot blocking, and true offline message delivery require a connected backend and/or native Android implementation. An internet connection is required to deliver queued messages.

FREE BUILD NOTE
Only continue with an APK builder if it offers a free build. Do not pay just to test this project.
