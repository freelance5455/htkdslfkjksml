
"use strict";

const KEY = "motorcare_v1_data";
const $ = id => document.getElementById(id);
const today = () => {
  const d = new Date();
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 10);
};

const blankData = () => ({
  km: 0,
  reminders: [],
  services: [],
  fuel: [],
  taxDate: "",
  stnkDate: ""
});

let data = blankData();

try {
  const saved = localStorage.getItem(KEY);
  if (saved) {
    const parsed = JSON.parse(saved);
    if (parsed && typeof parsed === "object") {
      data = {
        ...blankData(),
        ...parsed,
        reminders: Array.isArray(parsed.reminders) ? parsed.reminders : [],
        services: Array.isArray(parsed.services) ? parsed.services : [],
        fuel: Array.isArray(parsed.fuel) ? parsed.fuel : []
      };
    }
  }
} catch (error) {
  alert("Data lokal tidak bisa dibaca. Jangan hapus data browser jika belum punya cadangan.");
}

function persist() {
  try {
    localStorage.setItem(KEY, JSON.stringify(data));
    return true;
  } catch (error) {
    toast("Penyimpanan gagal. Ekspor cadangan dan periksa ruang penyimpanan.");
    return false;
  }
}

function commit(previous, message) {
  if (!persist()) {
    data = previous;
    render();
    return false;
  }
  render();
  if (message) toast(message);
  return true;
}

function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.remove("show"), 2600);
}

function rupiah(value) {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0
  }).format(Number(value) || 0);
}

function number(value) {
  return new Intl.NumberFormat("id-ID").format(Number(value) || 0);
}

// Menerima angka yang diketik dengan atau tanpa titik pemisah.
function parseNumber(value) {
  const digits = String(value ?? "").replace(/\D/g, "");
  return digits === "" ? NaN : Number(digits);
}

// Format titik langsung saat mengetik, tanpa mengubah nilai datanya.
function setupThousandsInput(id) {
  const input = $(id);
  if (!input) return;

  input.addEventListener("input", () => {
    const original = input.value;
    const cursor = input.selectionStart ?? original.length;
    const digitsBefore = original.slice(0, cursor).replace(/\D/g, "").length;
    const digits = original.replace(/\D/g, "");

    input.value = digits
      ? Number(digits).toLocaleString("id-ID", { maximumFractionDigits: 0 })
      : "";

    let pos = 0;
    let count = 0;
    while (pos < input.value.length && count < digitsBefore) {
      if (/\d/.test(input.value[pos])) count++;
      pos++;
    }

    try { input.setSelectionRange(pos, pos); } catch (_) {}
  });
}

[
  "kmInput", "reminderKm", "serviceKm",
  "serviceCost", "fuelKm", "fuelCost"
].forEach(setupThousandsInput);

function dateLabel(value) {
  if (!value) return "Belum ditentukan";
  const d = new Date(value + "T00:00:00");
  return Number.isNaN(d.getTime()) ? value :
    d.toLocaleDateString("id-ID", {
      day: "numeric", month: "long", year: "numeric"
    });
}

function daysUntil(value) {
  if (!value) return null;
  const target = new Date(value + "T00:00:00");
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  return Math.round((target - now) / 86400000);
}

function makeId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

function itemCard(title, details, onDelete) {
  const el = document.createElement("article");
  el.className = "list-item";

  const h = document.createElement("h3");
  h.textContent = title;
  el.appendChild(h);

  details.forEach(text => {
    const p = document.createElement("p");
    p.textContent = text;
    el.appendChild(p);
  });

  if (onDelete) {
    const actions = document.createElement("div");
    actions.className = "item-actions";
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "delete";
    btn.textContent = "Hapus";
    btn.addEventListener("click", onDelete);
    actions.appendChild(btn);
    el.appendChild(actions);
  }

  return el;
}

function removeRecord(listName, recordId) {
  if (!confirm("Hapus catatan ini?")) return;
  const previous = structuredClone(data);
  data[listName] = data[listName].filter(item => item.id !== recordId);
  commit(previous, "Catatan dihapus.");
}

function renderReminders() {
  const box = $("reminderList");
  box.replaceChildren();

  [...data.reminders]
    .sort((a, b) => (a.date || "9999").localeCompare(b.date || "9999"))
    .forEach(r => {
      const details = [];
      if (r.date) details.push("Tanggal: " + dateLabel(r.date));
      if (r.km !== null && r.km !== undefined)
        details.push("Target: " + number(r.km) + " km");

      const dueKm = r.km != null && Number(r.km) <= Number(data.km);
      const dueDate = r.date && daysUntil(r.date) <= 0;
      details.push(dueKm || dueDate ? "Perlu diperiksa" : "Belum jatuh tempo");

      box.appendChild(itemCard(r.name, details,
        () => removeRecord("reminders", r.id)));
    });

  if (!box.children.length) {
    const p = document.createElement("p");
    p.className = "empty";
    p.textContent = "Belum ada pengingat perawatan.";
    box.appendChild(p);
  }
}

function renderServices() {
  const box = $("serviceList");
  box.replaceChildren();

  [...data.services]
    .sort((a, b) => b.date.localeCompare(a.date))
    .forEach(s => {
      box.appendChild(itemCard(s.name, [
        "Tanggal: " + dateLabel(s.date),
        "Kilometer: " + number(s.km) + " km",
        "Biaya: " + rupiah(s.cost)
      ], () => removeRecord("services", s.id)));
    });

  if (!box.children.length) {
    const p = document.createElement("p");
    p.className = "empty";
    p.textContent = "Riwayat servis masih kosong.";
    box.appendChild(p);
  }
}

function calculateFuel() {
  const full = [...data.fuel]
    .filter(f => f.full)
    .sort((a, b) => Number(a.km) - Number(b.km));

  const intervals = [];
  for (let i = 1; i < full.length; i++) {
    const distance = Number(full[i].km) - Number(full[i - 1].km);
    const liters = Number(full[i].liters);
    if (distance > 0 && liters > 0) intervals.push({ distance, liters });
  }

  if (!intervals.length) {
    $("fuelAverage").textContent = "Belum cukup data";
    $("fuelExplanation").textContent =
      "Catat dua pengisian penuh pada kilometer berbeda.";
    return null;
  }

  const distance = intervals.reduce((sum, r) => sum + r.distance, 0);
  const liters = intervals.reduce((sum, r) => sum + r.liters, 0);
  const average = distance / liters;

  $("fuelAverage").textContent =
    average.toLocaleString("id-ID", { maximumFractionDigits: 2 }) + " km/l";
  $("fuelExplanation").textContent =
    "Perkiraan dari " + intervals.length +
    " interval pengisian penuh. Kondisi pemakaian dapat memengaruhi hasil.";

  return average;
}

function renderFuel() {
  const box = $("fuelList");
  box.replaceChildren();

  [...data.fuel]
    .sort((a, b) => b.date.localeCompare(a.date))
    .forEach(f => {
      box.appendChild(itemCard("Isi BBM · " + dateLabel(f.date), [
        "Odometer: " + number(f.km) + " km",
        "Jumlah: " + Number(f.liters).toLocaleString("id-ID") + " liter",
        "Biaya: " + rupiah(f.cost),
        f.full ? "Pengisian penuh" : "Pengisian tidak penuh"
      ], () => removeRecord("fuel", f.id)));
    });

  if (!box.children.length) {
    const p = document.createElement("p");
    p.className = "empty";
    p.textContent = "Belum ada catatan pengisian BBM.";
    box.appendChild(p);
  }

  calculateFuel();
}

function renderDocuments() {
  const box = $("documentList");
  box.replaceChildren();

  [
    ["Pajak tahunan", data.taxDate],
    ["Lima tahunan / STNK", data.stnkDate]
  ].forEach(([name, date]) => {
    if (!date) return;
    const days = daysUntil(date);
    let status;

    if (days < 0) status = "Tanggal terlewati " + Math.abs(days) + " hari";
    else if (days === 0) status = "Jatuh tempo hari ini";
    else status = "Tersisa " + days + " hari";

    box.appendChild(itemCard(name, [status]));
  });

  if (!box.children.length) {
    const p = document.createElement("p");
    p.className = "empty";
    p.textContent = "Belum ada tanggal dokumen.";
    box.appendChild(p);
  }
}

function renderAdvice() {
  const box = $("adviceList");
  box.replaceChildren();
  const advice = [];
  const km = Number(data.km) || 0;

  function add(title, text, type = "good") {
    advice.push({ title, text, type });
  }

  if (km <= 0) {
    add("Mulai dari kilometer motor",
      "Masukkan odometer sekarang agar pengingat kilometer berfungsi.");
  }

  data.reminders.forEach(r => {
    const dueKm = r.km != null && Number(r.km) <= km;
    const dueDate = r.date && daysUntil(r.date) <= 0;
    const nearKm = r.km != null && Number(r.km) > km &&
      Number(r.km) - km <= 200;
    const nearDate = r.date && daysUntil(r.date) > 0 &&
      daysUntil(r.date) <= 14;

    if (dueKm || dueDate) {
      add("Periksa: " + r.name,
        "Target sudah tercapai. Periksa buku pedoman untuk memastikan perawatan yang diperlukan.",
        "warn");
    } else if (nearKm || nearDate) {
      add("Jadwal mendekat: " + r.name,
        "Siapkan jadwal perawatan berikutnya.");
    }
  });

  if (data.services.length) {
    const latest = [...data.services].sort((a, b) =>
      b.date.localeCompare(a.date))[0];

    if (Number(latest.km) > km) {
      add("Periksa catatan kilometer",
        "Kilometer servis terakhir melebihi odometer saat ini. Pastikan angka benar.",
        "warn");
    } else {
      add("Servis terakhir tercatat",
        latest.name + " pada " + number(latest.km) +
        " km. Tentukan jadwal berikutnya berdasarkan buku servis.");
    }
  } else {
    add("Lengkapi riwayat servis",
      "Catat servis terakhir yang kamu ketahui agar perawatan lebih mudah dipantau.");
  }

  const average = calculateFuel();
  if (average === null) {
    add("Kumpulkan catatan BBM",
      "Catat dua pengisian penuh dengan odometer berbeda untuk mulai menghitung km/liter.");
  } else {
    add("Konsumsi BBM tercatat",
      "Rata-rata " + average.toLocaleString("id-ID", {
        maximumFractionDigits: 2
      }) + " km/l. Bandingkan beberapa periode pemakaian.");
  }

  [
    ["Pajak tahunan", data.taxDate],
    ["Lima tahunan / STNK", data.stnkDate]
  ].forEach(([name, date]) => {
    if (!date) {
      add("Lengkapi " + name,
        "Masukkan tanggal resmi untuk menghitung sisa waktu.");
    } else if (daysUntil(date) <= 30) {
      const days = daysUntil(date);
      add(name + " perlu diperhatikan",
        days < 0
          ? "Tanggal yang dimasukkan telah terlewati. Verifikasi melalui kanal resmi."
          : days === 0
            ? "Jatuh tempo hari ini."
            : "Jatuh tempo dalam " + days + " hari.",
        "warn");
    }
  });

  advice.slice(0, 8).forEach(a => {
    const el = document.createElement("article");
    el.className = "advice-item " + a.type;
    const title = document.createElement("strong");
    title.textContent = a.title;
    const p = document.createElement("p");
    p.textContent = a.text;
    el.append(title, p);
    box.appendChild(el);
  });
}

function render() {
  $("dashboardKm").textContent = number(data.km);
  $("serviceCount").textContent = number(data.services.length);
  $("totalCost").textContent = rupiah(
    data.services.reduce((sum, s) => sum + (Number(s.cost) || 0), 0)
  );

  renderReminders();
  renderServices();
  renderFuel();
  renderDocuments();
  renderAdvice();
}

// Navigasi
document.querySelectorAll(".tab").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(t =>
      t.classList.toggle("active", t === btn));
    document.querySelectorAll(".panel").forEach(panel =>
      panel.hidden = panel.id !== btn.dataset.target);
  });
});

// Kilometer
$("kmForm").addEventListener("submit", e => {
  e.preventDefault();
  const value = parseNumber($("kmInput").value);

  if (!Number.isSafeInteger(value) || value < 0) {
    toast("Masukkan kilometer yang valid.");
    return;
  }

  if (value < Number(data.km) &&
      !confirm("Kilometer lebih rendah dari catatan sebelumnya. Simpan?")) {
    return;
  }

  const previous = structuredClone(data);
  data.km = value;
  $("kmInput").value = "";
  commit(previous, "Kilometer diperbarui.");
});

// Pengingat
$("reminderForm").addEventListener("submit", e => {
  e.preventDefault();

  const name = $("reminderName").value.trim();
  const date = $("reminderDate").value;
  const kmText = $("reminderKm").value.trim();
  const km = kmText ? parseNumber(kmText) : null;

  if (!name || (!date && km === null)) {
    toast("Isi nama serta tanggal atau kilometer target.");
    return;
  }
  if (km !== null && (!Number.isSafeInteger(km) || km < 0)) {
    toast("Kilometer target tidak valid.");
    return;
  }

  const previous = structuredClone(data);
  data.reminders.push({ id: makeId(), name, date, km });
  if (commit(previous, "Pengingat ditambahkan.")) e.target.reset();
});

// Riwayat servis
$("serviceForm").addEventListener("submit", e => {
  e.preventDefault();

  const name = $("serviceName").value.trim();
  const date = $("serviceDate").value;
  const km = parseNumber($("serviceKm").value);
  const cost = parseNumber($("serviceCost").value);

  if (!name || !date ||
      !Number.isSafeInteger(km) || km < 0 ||
      !Number.isSafeInteger(cost) || cost < 0) {
    toast("Periksa kembali data servis.");
    return;
  }

  const previous = structuredClone(data);
  data.services.push({ id: makeId(), name, date, km, cost });
  if (commit(previous, "Riwayat servis tersimpan.")) e.target.reset();
});

// BBM
$("fuelForm").addEventListener("submit", e => {
  e.preventDefault();

  const date = $("fuelDate").value;
  const km = parseNumber($("fuelKm").value);
  const liters = Number($("fuelLiters").value);
  const cost = parseNumber($("fuelCost").value);
  const full = $("fuelFull").checked;

  if (!date || !Number.isSafeInteger(km) || km < 0 ||
      !Number.isFinite(liters) || liters <= 0 ||
      !Number.isSafeInteger(cost) || cost < 0) {
    toast("Periksa tanggal, kilometer, liter, dan biaya.");
    return;
  }

  const previous = structuredClone(data);
  data.fuel.push({ id: makeId(), date, km, liters, cost, full });
  if (km > Number(data.km)) data.km = km;

  if (commit(previous, "Catatan BBM tersimpan.")) e.target.reset();
});

// Pajak dan STNK
$("documentForm").addEventListener("submit", e => {
  e.preventDefault();
  const previous = structuredClone(data);
  data.taxDate = $("taxDate").value;
  data.stnkDate = $("stnkDate").value;
  commit(previous, "Tanggal dokumen disimpan.");
});

// Ekspor cadangan
$("exportBtn").addEventListener("click", () => {
  const blob = new Blob([JSON.stringify(data, null, 2)], {
    type: "application/json"
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "motorcare-backup.json";
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
});

// Pulihkan cadangan
$("importFile").addEventListener("change", async e => {
  const file = e.target.files[0];
  if (!file) return;

  try {
    const parsed = JSON.parse(await file.text());

    if (!parsed || typeof parsed !== "object" ||
        !Array.isArray(parsed.reminders) ||
        !Array.isArray(parsed.services) ||
        !Array.isArray(parsed.fuel) ||
        !Number.isFinite(Number(parsed.km)) ||
        Number(parsed.km) < 0) {
      throw new Error("Format tidak cocok");
    }

    if (!confirm("Pulihkan cadangan? Data saat ini akan diganti.")) return;

    const previous = structuredClone(data);
    data = {
      ...blankData(),
      ...parsed,
      reminders: parsed.reminders,
      services: parsed.services,
      fuel: parsed.fuel
    };
    commit(previous, "Cadangan berhasil dipulihkan.");
  } catch (_) {
    toast("File cadangan tidak valid.");
  } finally {
    e.target.value = "";
  }
});

// Hapus data
$("resetBtn").addEventListener("click", () => {
  if (!confirm("Hapus semua data MotorCare? Ekspor cadangan terlebih dahulu jika perlu.")) return;

  const previous = structuredClone(data);
  data = blankData();
  commit(previous, "Semua data dihapus.");
});

// Inisialisasi
$("taxDate").value = data.taxDate || "";
$("stnkDate").value = data.stnkDate || "";
$("serviceDate").value = today();
$("fuelDate").value = today();
render();
