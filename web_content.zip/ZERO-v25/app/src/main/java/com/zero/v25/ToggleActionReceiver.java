package com.zero.v25;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * ZERO — Notification Toggle Action (29 سبتمبر 2026)
 * ═══════════════════════════════════════════════════════════════════════
 * يستقبل ضغطة زر "تشغيل/إيقاف" على إشعار BgService الدائم — يتيح تبديل محرك
 * الإلغاء (toggleAI في JS) من خارج التطبيق تماماً (الشاشة الرئيسية/سحب لوحة
 * الإشعارات) دون فتح الواجهة إطلاقاً، طالما عملية التطبيق لا تزال حيّة — وهو
 * بالضبط ما تضمنه BgService كخدمة أمامية (foreground service) أصلاً: طالما
 * الإشعار ظاهر، الـWebView وسياق JS بداخله لا يزالان مقيمَين في الذاكرة، حتى
 * لو لم تكن MainActivity مرئية على الشاشة — فـ evaluateJavascript() ينفَّذ
 * مباشرة على ذلك السياق الحيّ بلا حاجة لإعادة إنشاء أي شيء.
 *
 * الحالة النادرة (العملية بأكملها قُتلت رغم الخدمة الأمامية — ضغط ذاكرة حاد
 * من النظام): activeInstance تكون null، فيُعاد فتح النشاط بدلاً من ذلك مع
 * علامة autoToggle=true يقرأها MainActivity بعد اكتمال تحميل الصفحة — حلٌّ
 * احتياطي وحيد ممكن، إذ لا مفرَّ من وجود JS حيّ في مكان ما لتشغيل/إيقاف محرك
 * صوت فعلي.
 */
public class ToggleActionReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        MainActivity active = MainActivity.getActiveInstance();
        if (active != null) {
            active.toggleEngineFromNotification();
        } else {
            Intent launch = new Intent(context, MainActivity.class);
            launch.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            launch.putExtra("autoToggle", true);
            context.startActivity(launch);
        }
    }
}
