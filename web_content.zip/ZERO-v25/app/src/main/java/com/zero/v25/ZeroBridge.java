package com.zero.v25;

import android.Manifest;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Debug;
import android.os.Environment;
import android.os.StatFs;
import android.webkit.JavascriptInterface;

/**
 * ZERO AI v25 — JavaScript Bridge
 * Exposes native Android capabilities to the web app.
 * Accessible in JavaScript as: window.ZeroAndroid
 */
public class ZeroBridge {
    private final Context ctx;
    private boolean bgRunning = false;
    // ميزة 29 سبتمبر 2026 — زر تشغيل/إيقاف على إشعار الخلفية: هذا الحقل هو المصدر الوحيد الذي
    // تعرف منه BgService حالة محرك الإلغاء الفعلية (isRun في JS) لتسمية زرّها بشكل صحيح.
    // يُحدَّث حصرياً من نقطتَي الاتصال الموجودتين أصلاً بين JS ← Java (لا نداء جديد من JS
    // مطلوب): updateBGStatus() لا تُستدعى إلا أثناء تشغيل المحرك فعلياً (06-detection-engine-
    // core.js، داخل حلقة startCL المشروطة بـisRun) فتعني ضمنياً "يعمل الآن"؛ stopBG() تُستدعى
    // فقط عند إيقافه (نفس الملف، stopAll()). onPause() في MainActivity يستدعي startBG() في كل
    // مرة يُخلَّف فيها التطبيق للخلفية بصرف النظر عن حالة المحرك — فالقيمة المخزَّنة هنا (لا حالة
    // الخدمة نفسها) هي وحدها الموثوقة لحظة بناء أول إشعار.
    private volatile boolean engineRunning = false;

    public ZeroBridge(Context ctx) {
        this.ctx = ctx;
    }

    /* ════════════════════════════
       FILE STORAGE
       ════════════════════════════ */

    /** Returns the app's internal files directory path */
    @JavascriptInterface
    public String getInternalPath() {
        return ctx.getFilesDir().getAbsolutePath() + "/" + ZeroStorage.APP_DIR;
    }

    /** Returns the user-accessible export directory path */
    @JavascriptInterface
    public String getExportPath() {
        return ZeroStorage.getExportDir(ctx).getAbsolutePath();
    }

    /** Returns the dedicated program Data directory path (My Files) */
    @JavascriptInterface
    public String getDataPath() {
        return ZeroStorage.getDataDir(ctx).getAbsolutePath();
    }

    /** Save file to internal storage
     *  subdir: "sessions" | "freqdb" | "nn_weights" | "logs"
     *  Returns true on success */
    @JavascriptInterface
    public boolean saveFile(String subdir, String filename, String content) {
        filename = filename.replaceAll("[^a-zA-Z0-9_\\-.]", "_");
        subdir   = subdir.replaceAll("[^a-zA-Z_]", "");
        return ZeroStorage.write(ctx, subdir, filename, content);
    }

    /** 2-param overload — saves directly to sessions subdir. */
    @JavascriptInterface
    public boolean saveFile(String filename, String content) {
        return saveFile(ZeroStorage.SESSIONS, filename, content);
    }

    /** Read file from internal storage. Returns null if not found. */
    @JavascriptInterface
    public String readFile(String subdir, String filename) {
        filename = filename.replaceAll("[^a-zA-Z0-9_\\-.]", "_");
        subdir   = subdir.replaceAll("[^a-zA-Z_]", "");
        return ZeroStorage.read(ctx, subdir, filename);
    }

    /** List files in a subdir. Returns JSON array of filenames. */
    @JavascriptInterface
    public String listFiles(String subdir) {
        subdir = subdir.replaceAll("[^a-zA-Z_]", "");
        return ZeroStorage.listFiles(ctx, subdir);
    }

    /** Export file to user-accessible export location (My Files/Export) */
    @JavascriptInterface
    public boolean exportFile(String filename, String content) {
        filename = filename.replaceAll("[^a-zA-Z0-9_\\-.]", "_");
        return ZeroStorage.export(ctx, filename, content);
    }

    /**
     * Save data file to dedicated program Data directory (My Files).
     * Used by PERSIST for bans, NN weights, FC counters, categories.
     */
    @JavascriptInterface
    public boolean saveData(String filename, String content) {
        filename = filename.replaceAll("[^a-zA-Z0-9_\\-.]", "_");
        return ZeroStorage.saveToData(ctx, filename, content);
    }

    /**
     * Load data file from dedicated program Data directory.
     * Returns file content string, or null if not found.
     */
    @JavascriptInterface
    public String loadData(String filename) {
        filename = filename.replaceAll("[^a-zA-Z0-9_\\-.]", "_");
        return ZeroStorage.loadFromData(ctx, filename);
    }

    /**
     * List all files in the Data directory.
     * Returns JSON array of filenames.
     */
    @JavascriptInterface
    public String listData() {
        return ZeroStorage.listDataFiles(ctx);
    }

    /** Delete a file from internal storage */
    @JavascriptInterface
    public boolean deleteFile(String subdir, String filename) {
        filename = filename.replaceAll("[^a-zA-Z0-9_\\-.]", "_");
        subdir   = subdir.replaceAll("[^a-zA-Z_]", "");
        return ZeroStorage.delete(ctx, subdir, filename);
    }

    /** Get total storage used by ZERO AI in bytes */
    @JavascriptInterface
    public long getStorageUsed() {
        return ZeroStorage.getTotalSize(ctx);
    }

    /* ════════════════════════════
       PERMISSIONS
       ════════════════════════════ */

    /**
     * Check if a specific permission is currently granted.
     * id: "MANAGE_STORAGE" | "POST_NOTIFICATIONS" | "RECORD_AUDIO" | "MEDIA_AUDIO"
     * Returns true if granted OR if the permission is not required on this Android version.
     */
    @JavascriptInterface
    public boolean isPermissionGranted(String id) {
        // minSdk = 24, so runtime permissions always apply — no API < M guard needed
        switch (id) {
            case "MANAGE_STORAGE":
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
                    return Environment.isExternalStorageManager();
                // API 24-29: WRITE_EXTERNAL_STORAGE covers legacy storage access
                return ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED;

            case "POST_NOTIFICATIONS":
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    return ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        == PackageManager.PERMISSION_GRANTED;
                return true; // Not required below API 33

            case "RECORD_AUDIO":
                return ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED;

            case "MEDIA_AUDIO":
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    return ctx.checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO)
                        == PackageManager.PERMISSION_GRANTED;
                // API 29-32 and API ≤ 28: READ_EXTERNAL_STORAGE covers this
                return ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED;

            default:
                return false;
        }
    }

    /**
     * Request a specific permission individually from the permission checklist UI.
     * id: "MANAGE_STORAGE" | "POST_NOTIFICATIONS" | "RECORD_AUDIO" | "MEDIA_AUDIO"
     * Result is delivered via window.onPermResult(id, granted) in index.html.
     */
    @JavascriptInterface
    public void requestPermission(String id) {
        if (ctx instanceof MainActivity) {
            ((MainActivity) ctx).handlePermissionRequest(id);
        }
    }

    /**
     * Open this app's system Settings page so the user can grant a
     * permanently-denied permission manually.
     */
    @JavascriptInterface
    public void openAppSettings() {
        try {
            Intent intent = new Intent(
                android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(android.net.Uri.fromParts("package", ctx.getPackageName(), null));
            ctx.startActivity(intent);
        } catch (Exception e) { /* ignore */ }
    }

    /**
     * Called from perm_check.html "متابعة" button.
     * Loads the main app (index.html) in the WebView.
     */
    @JavascriptInterface
    public void launchApp() {
        if (ctx instanceof MainActivity) {
            ((MainActivity) ctx).closePermOverlay();
        }
    }

    /* ════════════════════════════
       BACKGROUND SERVICE
       ════════════════════════════ */

    /** Start foreground service to prevent background kill */
    @JavascriptInterface
    public void startBG(String status) {
        if (bgRunning) {
            updateBGStatus(status);
            return;
        }
        Intent svc = new Intent(ctx, BgService.class);
        svc.putExtra("status", status != null ? status : "Processing frequencies...");
        svc.putExtra("running", engineRunning);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(svc);
        } else {
            ctx.startService(svc);
        }
        bgRunning = true;
    }

    /** Stop foreground service */
    @JavascriptInterface
    public void stopBG() {
        ctx.stopService(new Intent(ctx, BgService.class));
        bgRunning = false;
        engineRunning = false;
    }

    /** Update notification text in foreground service */
    @JavascriptInterface
    public void updateBGStatus(String status) {
        // تُستدعى فقط أثناء تشغيل المحرك فعلياً (انظر تعليق engineRunning أعلاه) — تُحدَّث هنا
        // بصرف النظر عن bgRunning (الخدمة قد لا تكون قد بدأت بعد إن كان التطبيق لا يزال
        // بالواجهة الأمامية) كي تكون صحيحة لحظة استدعاء startBG() لاحقاً عند التخليف للخلفية.
        engineRunning = true;
        if (!bgRunning || status == null) return;
        Intent svc = new Intent(ctx, BgService.class);
        svc.putExtra("status", status);
        svc.putExtra("running", true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(svc);
        } else {
            ctx.startService(svc);
        }
    }

    /** Is background service currently running? */
    @JavascriptInterface
    public boolean isBGRunning() {
        return bgRunning;
    }

    /* ════════════════════════════
       DEVICE INFO
       ════════════════════════════ */

    /** Android SDK version */
    @JavascriptInterface
    public int getAndroidVersion() {
        return Build.VERSION.SDK_INT;
    }

    /** Device model string */
    @JavascriptInterface
    public String getDeviceModel() {
        return Build.MANUFACTURER + " " + Build.MODEL;
    }

    /** App package name */
    @JavascriptInterface
    public String getPackageName() {
        return ctx.getPackageName();
    }

    /* ════════════════════════════
       DEVICE MONITOR
       ════════════════════════════ */

    /**
     * RAM usage from ActivityManager.
     * Returns JSON: {totalMB, availMB, usedMB, usedPct}
     */
    @JavascriptInterface
    public String getRamInfo() {
        try {
            ActivityManager am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            long totalMB = mi.totalMem  / (1024 * 1024);
            long availMB = mi.availMem  / (1024 * 1024);
            long usedMB  = totalMB - availMB;
            int  pct     = (totalMB > 0) ? (int)(usedMB * 100L / totalMB) : 0;
            return "{\"totalMB\":" + totalMB + ",\"availMB\":" + availMB +
                   ",\"usedMB\":"  + usedMB  + ",\"usedPct\":" + pct + "}";
        } catch (Exception e) { return "{}"; }
    }

    /**
     * Battery temperature, level, voltage and health.
     * Returns JSON: {tempC, levelPct, voltageMV, isCharging, health}
     */
    @JavascriptInterface
    public String getBatteryInfo() {
        try {
            Intent bat = ctx.registerReceiver(null,
                new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (bat == null) return "{}";
            int   tempRaw  = bat.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);
            float tempC    = tempRaw / 10.0f;
            int   level    = bat.getIntExtra(BatteryManager.EXTRA_LEVEL,   -1);
            int   scale    = bat.getIntExtra(BatteryManager.EXTRA_SCALE,  100);
            int   pct      = (scale > 0) ? (int)(level * 100.0f / scale) : -1;
            int   voltage  = bat.getIntExtra(BatteryManager.EXTRA_VOLTAGE,  0);
            int   status   = bat.getIntExtra(BatteryManager.EXTRA_STATUS,  -1);
            boolean chg    = (status == BatteryManager.BATTERY_STATUS_CHARGING ||
                              status == BatteryManager.BATTERY_STATUS_FULL);
            int   health   = bat.getIntExtra(BatteryManager.EXTRA_HEALTH,   0);
            String hlStr;
            switch (health) {
                case BatteryManager.BATTERY_HEALTH_GOOD:         hlStr = "جيدة";        break;
                case BatteryManager.BATTERY_HEALTH_OVERHEAT:     hlStr = "⚠ ساخنة جداً"; break;
                case BatteryManager.BATTERY_HEALTH_DEAD:         hlStr = "ميتة";         break;
                case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE: hlStr = "⚠ جهد زائد";  break;
                case BatteryManager.BATTERY_HEALTH_COLD:         hlStr = "بردة";         break;
                default:                                          hlStr = "عادية";        break;
            }
            return "{\"tempC\":"     + tempC   +
                   ",\"levelPct\":"  + pct     +
                   ",\"voltageMV\":" + voltage +
                   ",\"isCharging\":" + chg    +
                   ",\"health\":\""  + hlStr   + "\"}";
        } catch (Exception e) { return "{}"; }
    }

    /**
     * All thermal zones from /sys/class/thermal/ with type and temperature.
     * Returns JSON array: [{name, tempC}, ...]
     */
    @JavascriptInterface
    public String getThermalZones() {
        try {
            java.io.File dir = new java.io.File("/sys/class/thermal");
            if (!dir.exists()) return "[]";
            java.io.File[] zones = dir.listFiles();
            if (zones == null) return "[]";
            StringBuilder sb = new StringBuilder("[");
            boolean first = true;
            for (java.io.File z : zones) {
                if (!z.getName().startsWith("thermal_zone")) continue;
                try {
                    String tempStr = readSysFile(new java.io.File(z, "temp")).trim();
                    if (tempStr.isEmpty()) continue;
                    java.io.File tf = new java.io.File(z, "type");
                    String type = tf.exists() ? readSysFile(tf).trim() : z.getName();
                    // Clamp type length for safe JSON
                    if (type.length() > 30) type = type.substring(0, 30);
                    int raw = Integer.parseInt(tempStr);
                    // Most zones report millidegrees; some report degrees
                    float c = (raw > 1000) ? raw / 1000.0f : (float) raw;
                    if (c < -40 || c > 200) continue; // sanity check
                    if (!first) sb.append(",");
                    sb.append("{\"name\":\"").append(type.replace("\"","'"))
                      .append("\",\"tempC\":").append(String.format("%.1f", c)).append("}");
                    first = false;
                } catch (Exception ex) { /* skip bad zone */ }
            }
            sb.append("]");
            return sb.toString();
        } catch (Exception e) { return "[]"; }
    }

    /**
     * CPU core count and current / max frequency of cpu0.
     * Returns JSON: {cores, curMHz, maxMHz, freqPct}
     */
    @JavascriptInterface
    public String getCpuInfo() {
        try {
            int  cores    = Runtime.getRuntime().availableProcessors();
            long curKHz   = parseSysLong("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq");
            long maxKHz   = parseSysLong("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq");
            long curMHz   = curKHz / 1000;
            long maxMHz   = maxKHz / 1000;
            int  freqPct  = (maxMHz > 0) ? (int)(curMHz * 100L / maxMHz) : 0;
            return "{\"cores\":"   + cores   +
                   ",\"curMHz\":"  + curMHz  +
                   ",\"maxMHz\":"  + maxMHz  +
                   ",\"freqPct\":" + freqPct + "}";
        } catch (Exception e) { return "{\"cores\":" + Runtime.getRuntime().availableProcessors() + "}"; }
    }

    // ── helpers ─────────────────────────────────────────
    private String readSysFile(java.io.File f) {
        // مراجعة "المشروع بالكامل": br.close() كانت تُستدعى بعد br.readLine() مباشرة دون
        // try-with-resources — لو رمى readLine() استثناءً (وارد فعلاً على عقد sysfs افتراضية
        // متقطعة كملفات /sys/class/thermal/*)، يُقفَز فوق close() ويتسرَّب واصف الملف الأساسي.
        // getThermalZones()/getCpuInfo() تستدعي هذه الدالة بشكل متكرر لوحدة رصد جهاز حيّة، فأي
        // عقدة sysfs متقطعة تتراكم واصفات مسرّبة إلى أن يُستنفَد حدّ العملية. try-with-resources
        // يضمن الإغلاق دوماً، حتى عند استثناء أثناء القراءة نفسها.
        try (java.io.BufferedReader br = new java.io.BufferedReader(new java.io.FileReader(f))) {
            String line = br.readLine();
            return line != null ? line : "";
        } catch (Exception e) { return ""; }
    }
    private long parseSysLong(String path) {
        try { return Long.parseLong(readSysFile(new java.io.File(path)).trim()); }
        catch (Exception e) { return 0L; }
    }

    /**
     * Internal + external storage usage.
     * Returns JSON: {intTotalMB, intUsedMB, intFreeMB, intUsedPct,
     *                extAvail, extTotalMB, extUsedMB, extFreeMB}
     */
    @JavascriptInterface
    public String getStorageInfo() {
        try {
            StatFs intFs  = new StatFs(ctx.getFilesDir().getAbsolutePath());
            long  iTotal  = intFs.getTotalBytes()     / (1024 * 1024);
            long  iFree   = intFs.getAvailableBytes() / (1024 * 1024);
            long  iUsed   = iTotal - iFree;
            int   iPct    = (iTotal > 0) ? (int)(iUsed * 100L / iTotal) : 0;

            // External (SD card / secondary storage)
            java.io.File extDir = ctx.getExternalFilesDir(null);
            String extPart = "";
            if (extDir != null) {
                StatFs extFs  = new StatFs(extDir.getAbsolutePath());
                long   eTotal = extFs.getTotalBytes()     / (1024 * 1024);
                long   eFree  = extFs.getAvailableBytes() / (1024 * 1024);
                long   eUsed  = eTotal - eFree;
                extPart = ",\"extTotalMB\":" + eTotal +
                          ",\"extUsedMB\":"  + eUsed  +
                          ",\"extFreeMB\":"  + eFree;
            }
            return "{\"intTotalMB\":" + iTotal +
                   ",\"intUsedMB\":"  + iUsed  +
                   ",\"intFreeMB\":"  + iFree  +
                   ",\"intUsedPct\":" + iPct   +
                   ",\"extAvail\":"   + (extDir != null) +
                   extPart + "}";
        } catch (Exception e) { return "{}"; }
    }

    /**
     * Current network type and connectivity status.
     * Returns JSON: {connected, type, subtype}
     * type: "wifi" | "cellular" | "ethernet" | "none"
     * subtype (cellular only): "2G" | "3G" | "4G" | "5G"
     */
    @JavascriptInterface
    public String getNetworkType() {
        try {
            ConnectivityManager cm = (ConnectivityManager)
                ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return "{\"connected\":false,\"type\":\"none\"}";

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Network net = cm.getActiveNetwork();
                if (net == null) return "{\"connected\":false,\"type\":\"none\"}";
                NetworkCapabilities caps = cm.getNetworkCapabilities(net);
                if (caps == null) return "{\"connected\":false,\"type\":\"none\"}";
                boolean wifi = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
                boolean cell = caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR);
                boolean eth  = caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET);
                String type  = wifi ? "wifi" : cell ? "cellular" : eth ? "ethernet" : "other";
                // Estimate cellular generation by downstream bandwidth (approximate)
                String sub = "";
                if (cell) {
                    int bw = caps.getLinkDownstreamBandwidthKbps();
                    sub = ",\"subtype\":\"" + (bw >= 100000 ? "5G" : bw >= 5000 ? "4G" :
                                               bw >= 384   ? "3G" : "2G") + "\"";
                }
                return "{\"connected\":true,\"type\":\"" + type + "\"" + sub + "}";
            } else {
                @SuppressWarnings("deprecation")
                android.net.NetworkInfo ni = cm.getActiveNetworkInfo();
                if (ni == null || !ni.isConnected())
                    return "{\"connected\":false,\"type\":\"none\"}";
                @SuppressWarnings("deprecation")
                String type = ni.getTypeName().toLowerCase();
                return "{\"connected\":true,\"type\":\"" + type + "\"}";
            }
        } catch (Exception e) { return "{\"connected\":false,\"type\":\"none\"}"; }
    }

    /**
     * App process memory usage (native + Java heap).
     * Returns JSON: {heapUsedMB, heapMaxMB, nativeMB, totalPssMB}
     */
    @JavascriptInterface
    public String getAppMemory() {
        try {
            Runtime rt = Runtime.getRuntime();
            long heapUsed  = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024);
            long heapMax   = rt.maxMemory() / (1024 * 1024);

            // Native memory via Debug.MemoryInfo
            Debug.MemoryInfo mi = new Debug.MemoryInfo();
            Debug.getMemoryInfo(mi);
            int nativeMB = mi.nativePss / 1024;
            int totalPss = mi.getTotalPss() / 1024;

            return "{\"heapUsedMB\":" + heapUsed  +
                   ",\"heapMaxMB\":"  + heapMax   +
                   ",\"nativeMB\":"   + nativeMB  +
                   ",\"totalPssMB\":" + totalPss  + "}";
        } catch (Exception e) { return "{}"; }
    }

    /* ════════════════════════════
       DISPLAY
       ════════════════════════════ */

    /**
     * Heat fix #4: JS-controlled screen-on flag.
     * JS calls setKeepScreenOn(true) ONLY while ANC/ENC is actively processing,
     * and setKeepScreenOn(false) when processing stops — prevents permanent GPU wake.
     * Usage in JS: window.ZeroAndroid.setKeepScreenOn(true/false)
     */
    @JavascriptInterface
    public void setKeepScreenOn(final boolean on) {
        if (ctx instanceof MainActivity) {
            ((MainActivity) ctx).runOnUiThread(() ->
                ((MainActivity) ctx).getWindow().getDecorView().setKeepScreenOn(on));
        }
    }

    /* ════════════════════════════
       VIBRATION
       ════════════════════════════ */

    /** Vibrate device with pattern */
    @JavascriptInterface
    public void vibrate(int ms) {
        try {
            android.os.Vibrator v = (android.os.Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null && v.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(android.os.VibrationEffect.createOneShot(ms,
                        android.os.VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    v.vibrate(ms);
                }
            }
        } catch (Exception e) { /* ignore */ }
    }
}
