# ZERO — Android Project

## Project layout — سطر تشغيل مباشر + ملف واحد بلا أي وساطة

**تحديث 29 سبتمبر 2026 ("حذف build.py" ← "index.html فقط… أمر تشغيل مباشر" ←
"حذف الوساطة من كل المشروع")**: بعد تجربة عدة أشكال وسيطة (سكربت بناء
`build.py`، ثم 18 وسم `<script>` منفصل مباشرة في `index.html`، ثم مصدر مقسّم
يُعاد تجميعه بأداة خاصة لدى Claude خارج المشروع) — استقرّ المشروع أخيراً على
**الشكل الأبسط الممكن، بلا أي طبقة وسيطة إطلاقاً في أي مكان منه**:
`index.html` سطران فقط بالضبط:
```
<!DOCTYPE html>
<body><script src="ZERO-v25/web/app.js" charset="utf-8"></script>
```
و`ZERO-v25/web/app.js` هو **الملف الوحيد والمصدر الفعلي الوحيد** — يُعدَّل
مباشرة وحرفياً، بلا أي خطوة توليد أو تجميع أو إعادة تجميع بينه وبين ما يُحمَّل
فعلياً في التطبيق. لا `build.py` داخل المشروع، ولا مصدر مقسّم (`web/js/*.js`،
`web/css/style.css`) يحتاج دمجاً، ولا أداة خاصة لدى Claude تُعيد شيئاً من مكان
لآخر — **لا وسيط من أي نوع، لا داخل المشروع ولا خارجه.** (نفس المبدأ طُبِّق
لاحقاً أيضاً على مستوى الشيفرة نفسها: انظر "إعادة الهيكلة إلى Classes/Modules"
أدناه لحذف جسر `Object.defineProperty` الذي كان يُزامِن حالة قسم 00 مع
`window` — لم يعد له وجود، `appState` يُقرأ/يُكتَب مباشرة من كل مكان.)

```
android-complete/
├── index.html          ← سطرا كود فقط بالضبط —
│                          DOCTYPE + <script src="ZERO-v25/web/app.js">
│                          هذا ما يُحمِّله MainActivity؛ لا يُعدَّل أبداً
└── ZERO-v25/
    ├── web/
    │   └── app.js       ← الملف الوحيد، المصدر الفعلي المُعدَّل يدوياً مباشرة
    │                        (لا ناتج تجميع، لا مصدر منفصل يقابله في مكان آخر):
    │                        IIFE يحقن head/CSS/بنية الشاشة الكاملة في DOM، ثم
    │                        محرك JS كاملاً — 18 قسماً حسب الوظيفة (فواصل تعليق
    │                        `/* ── name ── */` فقط بينها، بلا أي غلاف/بناء؛
    │                        ترتيب الأقسام أدناه)، ثم بقية الملف — هو وحده
    │                        (مع index.html) ما يُحزَّم كأصل (asset) في الـ APK
    └── app/…                ← هذا المشروع: غلاف Android أصلي (Java)
```

ترتيب الأقسام الثمانية عشر داخل `app.js` (نفس ترتيب التنفيذ التاريخي — انظر
"لماذا هذا الترتيب" أدناه)، بعناوينها الأصلية القديمة (قبل الدمج) للتوثيق فقط
— لم تعد هذه ملفات منفصلة، بل أقسام متتالية داخل نفس الملف:
- `00-core-state-metrics` [IIFE+class مُحوَّل] الحالة العامة + مقاييس الإشارة الأساسية
- `01-spectral-analysis` تحليل طيفي متقدم (chroma/rolloff/harmonics/…)
- `02-classification-thermal-nn` تصنيف الترددات + مراقبة الحرارة + الشبكة العصبية
- `03-notch-inverse-engine` مرشحات Notch + محرك الموجة المعاكسة + toggleAI
- `04-panels-ui-system` نظام اللوحات المشترك (open/close/closeAll)
- `05-presets-scenes-tracking` الإعدادات المسبقة + تصنيف البيئة + المشاهد
- `06-detection-engine-core` محرك الكشف والمعالجة الحي (startAll/detectAll/…)
- `07a-ai-command-library` مكتبة أوامر AI الضخمة (AI_LIB)
- `07b-ai-exec-engine` محرك التنفيذ الذاتي (aiExecCycle/UCB1 bandit) + واجهة التنفيذ/الأذونات
- `07c-freq-bans-partitions` تقسيمات الترددات وحظرها (buildFreqPartitions/banFreq/…)
- `08a-persist-bans-store` كائن PERSIST (الحفظ المزدوج) + تطهير/تحميل الحظر الافتراضي
- `08b-interference-permsettings` كشف التداخل + تصعيد المناطق + إعدادات الأذونات
- `08c-background-db` خلفية النجوم المتحركة + طبقة IndexedDB (initDB + udsWrite*)
- `09-sessions-export-wtafs` الجلسات + جسر الأندرويد + بداية WTAFS
- `10-wtafs-backup-achievements` تكملة WTAFS + الإنجازات
- `11-terminal-logging` الطرفية ونظام السجلّ
- `12-session-features-extra` غرفة الصمت + النوم الذكي + مؤقت النوم + الفيزياء
- `13-zero-integration-aicore` طبقة تكامل ZERO-v25 + نواة AI (آخر قسم)

### سير العمل
عدِّل `ZERO-v25/web/app.js` **مباشرة** — ابحث عن فاصل التعليق
`/* ── name ── */` الخاص بالقسم المطلوب (نفس الأسماء أعلاه) للتنقّل بسرعة، أو
عن CSS/بنية الشاشة عبر وسم `<style>` أو محتوى الحقن في بداية الملف. **لا خطوة
بينية بعد الآن**: التعديل في `app.js` هو التعديل الفعلي والنهائي — لا سكربت
بناء، ولا مصدر آخر يُزامَن، ولا أداة (حتى خاصة لدى Claude) تُعيد توليد أي جزء
منه. `index.html` لا يُعدَّل أبداً (يبقى سطرين ثابتين).

### لماذا `charset="utf-8"` على وسم `<script>` الوحيد في index.html
`app.js` يحوي نصاً عربياً حرفياً (رسائل الطرفية، تسميات الواجهة المُحقَنة في
DOM). أثبت اختبار Playwright فعلي أن Chromium يقرأ ملف `.js` خارجياً محمَّلاً
بمسار نسبي عبر `file://` بترميز احتياطي خاطئ (Latin-1 تقريباً) ما لم يوجد
تصريح `charset` صريح على وسم `<script>` نفسه (`<meta charset="UTF-8">` في
`<head>` يضبط ترميز الوثيقة نفسها فقط، لا ملفات JS منفصلة) — فيتحوّل كل نص
عربي فيه إلى محارف مشوَّهة (mojibake). BOM (U+FEFF) صريح في أول `app.js`
(ترميز `utf-8-sig`) تصحيح مكمِّل لنفس السبب من جهة أخرى.

### لماذا هذا الترتيب تحديداً لأقسام app.js
الأقسام الثمانية عشر كانت أصلاً أجزاءً متتالية من سكربت واحد؛ فُصلت مرحلياً
(أثناء إعادة الهيكلة) بلا أي إعادة ترتيب، ثم أُعيد دمجها بنفس الترتيب حرفياً
داخل `app.js` — فالترتيب أعلاه هو ترتيب التنفيذ الفعلي الأصلي، وهو الترتيب
الوحيد الذي يجب الحفاظ عليه عند أي تعديل مستقبلي مباشر في `app.js`. لا يستدعي
أي قسم — داخل تنفيذه الفوري عند التحميل، لا داخل دالة — شيئاً لم يُعرَّف بعد؛
أي دالة/متغير مُعرَّف في قسم لاحق يُستخدم فقط داخل دوال تُستدعى لاحقاً (بعد
اكتمال تحميل الملف كله)، ما عدا كتلة ربط "السحب للإغلاق" (`_wireSheetDrag`)
لكل اللوحات، والمنقولة عمداً إلى نهاية قسم `13-zero-integration-aicore` (آخر
قسم في الملف) لهذا السبب بالتحديد.

### إعادة الهيكلة إلى Classes/Modules (جارية، تدريجياً — بدأت 29 سبتمبر 2026)
بطلب صريح ("تغيير طريقة كتابة المشروع… تغييرات جذرية" → "إعادة هيكلة إلى
Classes/Modules")، تُحوَّل أقسام `app.js` الثمانية عشر تدريجياً، **قسماً واحداً
في كل مرة** مع تشغيل كل مجموعة الاختبارات (`_analysis/test_*.js`) بعدها، من
متغيرات/دوال مبعثرة على نطاق `window` العام إلى أصناف (`class`) حقيقية بدل
الكائنات الحرفية ذات الدوال حيثما كان ذلك منطقياً (مثال: `JITTER`→`class
JitterAnalyzer`، `POLAR_HIST`→`class PolarHistory`) وتغليف كل قسم داخل IIFE
خاص به (عزل حقيقي لنطاقه الداخلي — "module" بمعناها الكلاسيكي في جافاسكربت)،
دون تغيير أي سلوك أو واجهة استدعاء خارجية إطلاقاً. **هذا تعديل مباشر داخل
`app.js` نفسه** — لا ملفات منفصلة تُحوَّل ثم تُدمَج، القسم يُحوَّل في مكانه.

**ملاحظة مهمة: لماذا *لا* تُستخدَم وحدات ES الحقيقية (`export`/`import`)** —
جُرِّبت فعلياً أولاً (لا افتراضاً): تحميل `<script type="module">` عبر
`file://` (بالضبط طريقة تشغيل هذا التطبيق —
`file:///android_asset/index.html` داخل WebView) يُرفَض كلياً بخطأ CORS صريح
من Chromium نفسه:
> Access to script … from origin 'null' has been blocked by CORS policy:
> Cross origin requests are only supported for protocol schemes: chrome,
> chrome-extension, …, http, https, …

وهذا يحدث حتى لسكربت الوحدة الأول نفسه (لا حتى استيراده لملف آخر) — أي ES
modules الحقيقية **مستحيلة كلياً** في بيئة التشغيل الفعلية لهذا التطبيق، بصرف
النظر عن أي أداة تجميع (bundler/esbuild). لذا استُبعِدت هذه الفكرة كلياً بعد
تأكيدها عملياً، لصالح نمط IIFE + class أدناه — جافاسكربت عادي بلا أي قيد CORS،
يعيش كقسم عادي ضمن `app.js` (سكربت كلاسيكي واحد، لا وحدة ES ولا أداة بناء
خارجية) تماماً كبقية الأقسام غير المُحوَّلة بعد.

**الحالة الآن:** قسم `00-core-state-metrics` فقط (أول قسم، الأصغر والأبسط
اعتماديات) — بقية الـ17 قسماً لا تزال خامة كما كانت.

**الآلية (لماذا تعمل الأقسام المُحوَّلة وغير المُحوَّلة معاً بلا أي تغيير في
بقية الأقسام) — تحديث 29 سبتمبر 2026 ("شدد أكثر… حذف الوساطة من كل المشروع"):
لا جسر إطلاقاً بعد الآن.** المحاولة الأولى (وثّقتها نسخة سابقة من هذا الملف)
استخدمت حلقة `Object.defineProperty(window, name, {get,set})` لكل اسم من
أسماء `AppState` لتُبقي بقية الأقسام تقرأ/تكتب `isOn`/`FREQ_THRESH`/… كمتغيرات
عامة عادية دون تعديلها. هذا **جسر حقيقي** — نسختان منطقيتان (حقل الصنف
الداخلي، وخاصية `window` المزامَنة) لنفس القيمة — وهو بالضبط نوع "الوساطة" ‏
التي طلب المستخدم حذفها من كل المشروع، فحُذف كلياً:
- لا `Object.defineProperty` ولا حلقة جسر إطلاقاً بعد الآن.
- `appState` (نسخة `AppState` الوحيدة) يُعرَض حرفياً وحيداً:
  `window.appState = appState;` — تماماً بنفس أسلوب عرض `JITTER`/`POLAR_HIST`/
  بقية الكائنات الثابتة في هذا الملف، لا خاصية مُصطنَعة لكل حقل.
- **كل الأقسام الـ17 الأخرى (وسطر `onclick=` الحرفي الوحيد الذي يحتاج ذلك —
  شريحة `FREQ_THRESH` في الشاشة الرئيسية) عُدِّلت لتقرأ/تكتب `appState.NAME`
  مباشرة** بدل الاسم المجرَّد — 1019 موضعاً فعلياً عبر كامل `app.js` (خارج
  قسم 00 نفسه، الذي يستخدم `this.NAME` داخلياً كما هو منذ التحويل الأول).
  الخصائص المختصرة في الكائنات الحرفية (`{isOn}`) وُسِّعت صراحةً
  (`{isOn: appState.isOn}`) لأن الاختصار لا يقبل تعبيراً بنقطة.
- **كيف حُدِّدت الـ1019 موضعاً بأمان بلا أي تخمين أو regex أعمى**: تحليل
  بنيوي حقيقي (AST) عبر `acorn` + تحليل نطاقات (`eslint-scope`) لكل الملف —
  أي مرجع مجرَّد (`Identifier`) يحمل أحد الأسماء الـ57 ولا ينحل داخل أي نطاق
  محلي (معامل دالة، `let/const` محلي، نمط تفكيك) يُصنَّف كإشارة إلى الجسر
  القديم ويُستبدَل؛ خاصية كائن غير محسوبة (`.isOn`) ومفتاح كائن حرفي غير
  مختصر (`{isOn: …}`) لا يُصنَّفان مراجع أصلاً (سلوك `eslint-scope` القياسي)
  فبقيا بلا مساس تلقائياً. بعد التطبيق أُعيد نفس التحليل على الناتج للتأكد من
  صفر مراجع مجرَّدة متبقية لأي من الأسماء الـ57 خارج قسم 00 — ثم شُغِّلت كل
  اختبارات `_analysis/test_*.js` الثلاثة وأثبتت نجاحاً كاملاً بلا انحدار.
- لا حاجة لأي معالجة خاصة عند التعامل مع الأقسام: كل قسم — بنمط IIFE+class أو
  خاماً كما كان — يتبع نفس الترتيب داخل نفس الملف الواحد (فاصل تعليق باسم كل
  قسم بينها فقط، بلا أي غلاف إضافي)، وكلها جافاسكربت كلاسيكي يتشارك نطاق
  `window` نفسه تلقائياً. `'use strict'` في أول قسم 00 يسري على تنفيذ ذلك
  المقطع من `app.js` فقط؛ هذا لا يغيّر شيئاً عملياً: كل قسم كان يعمل بصرامة
  أصلاً منذ أن كانت كل الأقسام مُدمَجة سابقاً خلف تصريح واحد في `build.py`
  القديم، وأي قسم آخر يريد نفس الصرامة يضيف `'use strict';` كأول سطر فيه.

كل هذا (رفض CORS لـ`type="module"` عبر `file://`، ثم لاحقاً إزالة الجسر
وإعادة كل مرجع مباشرة إلى `appState.NAME` بلا أي وساطة) اختُبر فعلياً
(Chromium/Playwright، لا افتراضاً) قبل كتابته هنا، إضافة إلى تشغيل كل ملفات
`_analysis/test_*.js` الثلاثة كاملة بعد كل تعديل فعلي — بلا أي انحدار. (ملاحظة
للصيانة: سكربتات اختبار Playwright نفسها كانت تقرأ الحالة من المتصفح عبر
أسماء مجرَّدة أيضاً — `page.evaluate(() => isOn)` مثلاً — فعُدِّلت هي الأخرى
إلى `page.evaluate(() => appState.isOn)` بنفس المبدأ.)

**لتحويل القسم التالي (`01-spectral-analysis` وما بعده):** حدِّد حدود القسم
داخل `app.js` نفسه (بين فاصلَي التعليق الخاصَّين به)، غلِّفه داخل
`(function(){ … })();`، حدِّد أي المتغيّرات `let` تُعاد كتابتها بالكامل من
مكان آخر (تدقيق آلي، لا تخمين) وأضفها لصنف حالة ذلك القسم، ثم اعرض تلك النسخة
الوحيدة مباشرة (`window.spectralState = spectralState;` مثلاً) **بلا أي جسر
لكل حقل** — وأعد كتابة كل مرجع خارجي لتلك الحقول عبر تحليل AST/scope حقيقي
(نفس أسلوب قسم 00 أعلاه، وليس regex أعمى: مرجع لا ينحل محلياً = يحتاج
`spectralState.NAME`)، ثم تحقّق بإعادة نفس التحليل أن صفر مراجع مجرَّدة تبقّت،
ثم شغّل كل اختبارات `_analysis/` — **لا خطوة بينية بينهما إطلاقاً**: عدِّل
`app.js` في مكانه، أعد تحميل `index.html`، انتهى.

`app/build.gradle` يوجّه `sourceSets.main.assets.srcDirs` مباشرة إلى `../../`
(أي `android-complete/`) مع `include 'index.html', 'ZERO-v25/web/app.js'`
(الأصلان الفعليان الوحيدان، ولا شيء غيرهما — لا مصدر آخر يُستبعَد لأنه لا يوجد
مصدر آخر أصلاً). `MainActivity` يحمّل `index.html` عبر:
`webView.loadUrl("file:///android_asset/index.html")` — الذي يحمّل بدوره
`ZERO-v25/web/app.js` بمسار نسبي (سلوك WebView قياسي داخل
`file:///android_asset/`، بلا أي طلب شبكة)، و`app.js` نفسه يحقن CSS/بنية
الشاشة في DOM قبل تنفيذ محرك JS.

## Storage Architecture
```
INTERNAL (private, /data/data/com.zero.v25/files/ZeroAI_v25/):
  sessions/       → JSON session files (auto-saved every 2 min + on stop)
  freqdb/         → Frequency database snapshots
  nn_weights/     → Neural network weight files
  logs/           → Startup, shutdown, error logs

DATA (dedicated program data — freq bans, NN weights, FC counters, categories):
  Android 11+:  /sdcard/ZeroAI/v25/Data/
  Android 10:   /sdcard/Android/data/com.zero.v25/files/Data/
  Android 9-:   /sdcard/ZeroAI/v25/Data/

EXPORT (user-visible exports):
  Android 11+:  /sdcard/ZeroAI/v25/Export/
  Android 10:   /sdcard/Android/data/com.zero.v25/files/Export/
  Android 9-:   /sdcard/ZeroAI/v25/Export/
```

## JavaScript Bridge (window.ZeroAndroid)

### Internal storage
| Method | Description |
|--------|-------------|
| `getInternalPath()` | Returns internal storage path |
| `saveFile(subdir, name, content)` | Save to internal storage (`sessions`\|`freqdb`\|`nn_weights`\|`logs`) |
| `saveFile(name, content)` | 2-arg overload — saves directly to `sessions` |
| `readFile(subdir, name)` | Read from internal storage; `null` if not found |
| `listFiles(subdir)` | List files in a subdir as a JSON array |
| `deleteFile(subdir, name)` | Delete a file from internal storage |
| `getStorageUsed()` | Total bytes used by ZERO AI |

### Program Data & Export
| Method | Description |
|--------|-------------|
| `getDataPath()` | Returns the dedicated program Data directory path |
| `saveData(name, content)` | Save to the Data directory (bans, NN weights, FC counters, categories) |
| `loadData(name)` | Load from the Data directory; `null` if not found |
| `listData()` | List all files in the Data directory as a JSON array |
| `getExportPath()` | Returns the user-accessible export directory path |
| `exportFile(name, content)` | Save to the user-accessible Export location |

### Permissions
| Method | Description |
|--------|-------------|
| `isPermissionGranted(id)` | `id`: `MANAGE_STORAGE`\|`POST_NOTIFICATIONS`\|`RECORD_AUDIO`\|`MEDIA_AUDIO`. True if granted or not required on this Android version |
| `requestPermission(id)` | Requests one permission from the checklist UI; result delivered via `window.onPermResult(id, granted)` |
| `openAppSettings()` | Opens this app's system Settings page (for a permanently-denied permission) |
| `launchApp()` | Loads the main app (`index.html`) in the WebView, called from the permission-check screen |

### Background service
| Method | Description |
|--------|-------------|
| `startBG(status)` | Starts the foreground service to prevent background kill |
| `stopBG()` | Stops the foreground service |
| `updateBGStatus(status)` | Updates the foreground notification text |
| `isBGRunning()` | Whether the background service is currently running |

**Notification toggle action (29 سبتمبر 2026)**: the persistent background
notification carries a "▶ تشغيل / ⏻ إيقاف" action button that toggles the ANC
engine (`toggleAI()`) without opening the app. No new JS-facing bridge method
was needed — `updateBGStatus()` is only ever called while the engine is
actually running (`06-detection-engine-core.js`'s `isRun`-gated closed loop),
and `stopBG()` only when it stops, so `ZeroBridge` tracks a private
`engineRunning` flag from those two existing call sites alone and passes it
to `BgService` as an intent extra to label the action correctly. Tapping the
action fires `ToggleActionReceiver`, which calls
`MainActivity.getActiveInstance().toggleEngineFromNotification()` — a direct
`webView.evaluateJavascript("toggleAI({})", null)` against the still-resident
WebView (kept alive by this very foreground service, whether or not the
Activity is visible). If the process was killed outright despite the
foreground service (rare), the receiver instead relaunches `MainActivity`
with an `autoToggle` extra, consumed once `index.html` finishes loading.

### Device & diagnostics
| Method | Description |
|--------|-------------|
| `getAndroidVersion()` | Android SDK version (int) |
| `getDeviceModel()` | Device model string |
| `getPackageName()` | App package name |
| `getRamInfo()` | JSON `{totalMB, availMB, usedMB, usedPct}` |
| `getBatteryInfo()` | JSON `{tempC, levelPct, voltageMV, isCharging, health}` |
| `getThermalZones()` | JSON array `[{name, tempC}, ...]` from `/sys/class/thermal/` |
| `getCpuInfo()` | JSON `{cores, curMHz, maxMHz, freqPct}` for cpu0 |
| `getStorageInfo()` | JSON `{intTotalMB, intUsedMB, intFreeMB, intUsedPct, extAvail, extTotalMB, extUsedMB, extFreeMB}` |
| `getNetworkType()` | JSON `{connected, type, subtype}` — type: wifi\|cellular\|ethernet\|none |
| `getAppMemory()` | JSON `{heapUsedMB, heapMaxMB, nativeMB, totalPssMB}` |

### Misc
| Method | Description |
|--------|-------------|
| `setKeepScreenOn(on)` | JS-controlled screen-wake flag — call `true` only while ANC/ENC is actively processing, `false` when stopped |
| `vibrate(ms)` | Haptic feedback |

## Web UI features (`ZERO-v25/web/app.js`)

**First-run onboarding screen (29 سبتمبر 2026)**: `onbOverlay`
(markup injected into the DOM directly by `app.js`, styled by its `.onb-*`
rules in the same file's injected `<style>` block) is a full-screen
overlay shown once, on the very first page load, before the user can touch
anything else. It explains — in the app's own existing terms, not new
marketing copy — that cancellation here works through five real silent
frequency mechanisms (Infrasound <20Hz, Ultrasound >20kHz, Phase Coherent
Field, Sub-1Hz Reset, Piezoelectric Structural — the exact same labels and
descriptions shown as toggles in Settings), plus a one-line mention of the
16-class frequency classification engine. Persistence is a single
`localStorage['zero_onboarded']` flag (same fallback-persistence convention
as `08a-persist-bans-store.js`), checked synchronously at the top of the
"SINGLE UNIFIED INIT" `window.addEventListener('load', ...)` handler in
`11-terminal-logging.js` — before the `setTimeout`-deferred storage/DB init —
so the overlay appears with the first paint rather than after a delay.
Dismissing it (`dismissOnboarding()`, wired to the "ابدأ" button) hides it and
writes the flag; it never reappears afterward. The overlay sits at
`z-index:9999`, one above `.dm-alert` (9000, previously the highest tier), to
guarantee it renders over anything else that could theoretically be present
on a first launch.

**"مضاد الفيروسات" — Antivirus panel (29 سبتمبر 2026)**: a 13th menu
destination (`avPanel`, `openAVPanel()`/`closeAVPanel()`) requested by name
by the user, to protect the *project itself* (not the user's hearing) from
frequencies that cause it problems. No new detection/banning logic was
written — the panel surfaces three real mechanisms that already existed but
were scattered or entirely invisible:
1. `THERMAL.thermBanned` (`02-classification-thermal-nn.js`, `sampleThermal`)
   — frequencies auto-banned after 8 repeated correlations with rising
   device heat.
2. `ANTI_IDLE.lagFreqs` (same file, `monitorSlugFreqs`) — frequencies
   auto-banned after 8 repeated correlations with frame drops >50ms.
3. `_purgeInvalidFrequencies()` (`08a-persist-bans-store.js`) — an integrity
   scan for corrupted (NaN/<1Hz) entries in `AI_BAN`/`INTERFERENCE_BAN.zones`/
   `freqDB`/`BAN_VOTE`, previously wired to only 3 automatic trigger points
   (startup, session restore, JSON import) with **no manual button and no
   result ever shown anywhere**. The panel adds a "فحص الآن" button that
   calls the same function and displays its real result.

`updateAVPanel()` filters live `AI_BAN` entries by `category==='thermal'`/
`'lag'` (fields that already existed on every ban entry) to render the
status line, per-category counts, and a threat log (reusing the previously
orphaned `.ban-row2` CSS variants, which existed in `style.css` but were
never referenced by any template until now). It refreshes at the same 6Hz
cadence as thermal sampling, gated on `avOpen` like every other panel's
live-update code in this codebase. `PERM_BAN_CATS.thermal`/`.lag` (their
toggles in Settings) are unchanged and still the way to disable either
category entirely.

**Sessions History Trend chart (29 سبتمبر 2026)**: a small canvas chart
(`sessHistCv`, drawn by `drawSessHist()` in
`09-sessions-export-wtafs.js`) added to the AI Brain → FILES tab, between
"Recent Sessions" and "Storage Log", plotting `bestSilence` across the last
10 saved sessions (oldest→newest) — the same hand-rolled canvas style as
`drawSQIHist()` (DPR-aware, dashed 50/80 guide lines, grayscale area fill).

## Build
```bash
# Debug APK
./gradlew assembleDebug
# Output: app/build/outputs/apk/debug/app-debug.apk

# Release APK (needs signing)
./gradlew assembleRelease
# Output: app/build/outputs/apk/release/app-release-unsigned.apk
```
Requires the Android SDK (`compileSdk 34` / `minSdk 24` / `targetSdk 34`) — set
`sdk.dir` in `local.properties` (not checked in) to your local SDK path.

## Permissions
- `RECORD_AUDIO`, `MODIFY_AUDIO_SETTINGS` — microphone capture
- `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MICROPHONE` — background mic capture stays alive
  on Android 12+ (`MEDIA_PLAYBACK` type does **not** cover background-mic restrictions —
  must be `MICROPHONE` specifically)
- `WAKE_LOCK` — keep-alive during active processing
- `POST_NOTIFICATIONS` — runtime prompt on Android 13+
- `READ_EXTERNAL_STORAGE` (maxSdk 32), `WRITE_EXTERNAL_STORAGE` (maxSdk 29) — legacy storage, Android 9 and below
- `MANAGE_EXTERNAL_STORAGE` — unrestricted storage access, Android 11+
- `READ_MEDIA_AUDIO` — scoped audio-file access, Android 13+
- `VIBRATE` — haptic feedback
- `android.hardware.microphone` (`required="true"`) — declares the app needs a mic

## Requirements
- Android 7.0+ (API 24)
- Microphone hardware
- No internet required — 100% local, no network permission requested
