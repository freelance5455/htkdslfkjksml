package com.socialmediamart.v2

import org.junit.Assert.assertTrue
import org.junit.Test

class AppConfigTest {
    @Test fun productIdIsExpected() {
        assertTrue("smm_premium_monthly".isNotEmpty())
    }
}
