package com.socialmediamart.v2

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.android.billingclient.api.*
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private lateinit var billing: BillingClient
    private var premium = false
    private val productId = "smm_premium_monthly"
    private val allowedSchemes = setOf("http", "https", "tel", "mailto", "geo", "market")

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        configureWebView()
        setupBilling()
        handleDeepLink(intent)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (webView.canGoBack()) webView.goBack() else finish() }
        })
    }

    private fun configureWebView() {
        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            builtInZoomControls = false
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = true
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest) = handleUrl(request.url)
            @Deprecated("Deprecated in API 24") override fun shouldOverrideUrlLoading(view: WebView, url: String) = handleUrl(Uri.parse(url))
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: android.webkit.WebResourceError) {
                if (request.isForMainFrame) view.post { webView.evaluateJavascript("window.nativeError&&window.nativeError('Unable to open that service. Check your connection and try again.')", null) }
            }
        }
        webView.addJavascriptInterface(AndroidBridge(), "Android")
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun handleUrl(uri: Uri): Boolean {
        if (uri.scheme.equals("file", true) && uri.path?.endsWith("index.html") == true) return false
        val scheme = uri.scheme?.lowercase() ?: return true
        if (scheme !in allowedSchemes) return true
        openExternal(uri)
        return true
    }

    private fun openExternal(uri: Uri) {
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
        catch (_: ActivityNotFoundException) { showJs("window.nativeError&&window.nativeError(${JSONObject.quote("No compatible app or browser is available.")})") }
    }

    private fun showJs(js: String) { if (::webView.isInitialized) runOnUiThread { webView.evaluateJavascript(js, null) } }

    private fun handleDeepLink(intent: Intent?) {
        val uri = intent?.data ?: return
        if (!uri.scheme.equals("socialmediamart", true) || !uri.host.equals("open", true)) return
        val target = uri.getQueryParameter("service")?.take(80) ?: return
        showJs("window.openDeepLinkedService&&window.openDeepLinkedService(${JSONObject.quote(target)})")
    }

    private fun setupBilling() {
        billing = BillingClient.newBuilder(this).setListener { result, purchases ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) purchases?.forEach(::handlePurchase)
            else showJs("window.billingMessage&&window.billingMessage(${JSONObject.quote(result.debugMessage)})")
        }.enablePendingPurchases().build()
        billing.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) { if (result.responseCode == BillingClient.BillingResponseCode.OK) queryPurchases() }
            override fun onBillingServiceDisconnected() {}
        })
    }

    private fun queryPurchases() {
        if (!billing.isReady) return
        billing.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build()) { _, purchases ->
            premium = purchases.any { it.products.contains(productId) && it.purchaseState == Purchase.PurchaseState.PURCHASED }
            showJs("window.setPremium&&window.setPremium($premium)")
            purchases.filter { it.products.contains(productId) && it.purchaseState == Purchase.PurchaseState.PURCHASED && !it.isAcknowledged }.forEach { p ->
                billing.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(p.purchaseToken).build()) {}
            }
        }
    }

    private fun handlePurchase(purchase: Purchase) {
        if (!purchase.products.contains(productId)) return
        if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
            premium = true
            if (!purchase.isAcknowledged) billing.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.purchaseToken).build()) {}
            showJs("window.setPremium&&window.setPremium(true)")
        }
    }

    private fun purchasePremium() {
        if (!billing.isReady) { showJs("window.billingUnavailable&&window.billingUnavailable()") ; return }
        val params = QueryProductDetailsParams.newBuilder().setProductList(listOf(QueryProductDetailsParams.Product.newBuilder().setProductId(productId).setProductType(BillingClient.ProductType.SUBS).build())).build()
        billing.queryProductDetailsAsync(params) { result, details ->
            if (result.responseCode != BillingClient.BillingResponseCode.OK || details.isEmpty()) { showJs("window.billingUnavailable&&window.billingUnavailable()"); return@queryProductDetailsAsync }
            val detail = details.first(); val offer = detail.subscriptionOfferDetails?.firstOrNull()
            if (offer == null) { showJs("window.billingUnavailable&&window.billingUnavailable()"); return@queryProductDetailsAsync }
            val pp = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(detail).setOfferToken(offer.offerToken).build()
            runOnUiThread { billing.launchBillingFlow(this, BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(pp)).build()) }
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface fun purchasePremium() = runOnUiThread { purchasePremium() }
        @JavascriptInterface fun restorePurchases() = runOnUiThread { showJs("window.billingMessage&&window.billingMessage('Checking Google Play purchases…')"); queryPurchases() }
        @JavascriptInterface fun isPremium(): Boolean = premium
        @JavascriptInterface fun openExternal(url: String) = runOnUiThread {
            val uri = try { Uri.parse(url) } catch (_: Exception) { return@runOnUiThread }
            val scheme = uri.scheme?.lowercase()
            if (scheme in allowedSchemes) openExternal(uri) else showJs("window.nativeError&&window.nativeError('Blocked unsafe link.')")
        }
    }

    override fun onNewIntent(intent: Intent?) { super.onNewIntent(intent); setIntent(intent); handleDeepLink(intent) }
    override fun onDestroy() { if (::billing.isInitialized) billing.endConnection(); webView.removeJavascriptInterface("Android"); webView.stopLoading(); webView.destroy(); super.onDestroy() }
}
