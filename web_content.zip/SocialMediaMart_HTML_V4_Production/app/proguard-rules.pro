# Social Media Mart release rules. Add backend-specific rules if required.
