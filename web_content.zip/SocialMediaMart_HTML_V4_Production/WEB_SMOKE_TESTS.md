# Web Frontend Smoke Tests

- index.html loads from `file:///android_asset/index.html`
- CSS and JS assets resolve locally.
- Search filters services.
- Favorites persist.
- Recent services persist.
- Settings opens and persists theme.
- Emergency actions invoke Android bridge.
- External HTTPS URLs are handed to Android safely.
- Invalid deep-link service values do not execute arbitrary script.
