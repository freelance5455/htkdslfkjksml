# Social Media Mart — V5 Release Candidate Verification

This package is prepared as a release candidate. Before Play submission, verify on a real Android build environment:

1. `./gradlew clean assembleRelease`
2. Install the release APK on Android 12+ and current Android versions.
3. Test cold/warm deep links: `socialmediamart://open`.
4. Test every category, search, favorites, recent history, settings and theme persistence.
5. Test external app/browser fallback.
6. Test emergency `tel:` actions on a physical device.
7. Configure and test the real Google Play subscription `smm_premium_monthly` using Play test tracks.
8. Verify restore purchases and entitlement revocation.
9. Publish the final privacy policy URL.
10. Generate signed AAB with your own release keystore.
11. Complete Play Console Data Safety, content rating, screenshots and store listing.
12. For paid Premium access, use server-side Play purchase verification before granting durable entitlement.

Note: This environment does not contain a complete Android SDK/Gradle toolchain, so no claim of a successful APK compilation is made here.
