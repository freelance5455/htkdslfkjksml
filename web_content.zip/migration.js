"use strict";

// Le premier format stockait uniquement un total de réussites et des dates actives.
function oldData(raw) {
  try {
    let x = JSON.parse(raw);
    return x && x.version === undefined && Array.isArray(x.grades) && Array.isArray(x.activity) && x.activity.every(d => typeof d === "string" && /^\d{4}-\d\d-\d\d$/.test(d) && day(new Date(d + "T12:00:00")) === d) && Number.isSafeInteger(x.correct) && x.correct >= 0 && x.grades.every(g => g && typeof g.subject === "string" && g.subject.trim() && typeof g.label === "string" && Number.isFinite(g.score) && Number.isFinite(g.outof) && g.outof > 0 && g.score >= 0 && g.score <= g.outof && Number.isFinite(g.coef) && g.coef > 0) ? x : null;
  } catch (e) {
    return null;
  }
}
function legacyDialog(x) {
  let d = fresh();
  dlg("Reprendre mon ancien carnet", '<form><p>' + x.grades.length + ' note(s) détectée(s). L’ancien carnet ne précisait ni la date, ni le trimestre, ni la branche de spécialité. Choisis les valeurs initiales, puis ajuste chaque évaluation dans Moyennes.</p>' + choose("Trimestre d’affectation", "t", terms(term(d))) + field("Date de classement", "date", day(), "date", "required") + choose("Classement initial des notes de spécialité", "cat", catOptions("pc")) + '<p class="small">Les ' + x.correct + ' anciennes réussites et les jours actifs seront archivés à part. Les flammes V3 commencent avec les séances de cinq réponses.</p><button class="primary">Restaurer cet ancien carnet</button></form>', f => {
    let e = f.elements,
      next = fresh();
    for (let g of x.grades) {
      let sub = next.subjects.find(s => s.name === g.subject || s.id === "tech" && g.subject === "2I2D / Ingénierie");
      if (!sub) {
        sub = {
          id: uid(),
          name: g.subject,
          show: true,
          coef: 1
        };
        next.subjects.push(sub);
      }
      next.grades.push({
        id: uid(),
        sub: sub.id,
        cat: sub.id === "pcm" ? e.cat.value : "",
        t: +e.t.value,
        date: e.date.value,
        name: g.label || "Évaluation importée",
        score: g.score,
        max: g.outof,
        coef: g.coef,
        comment: "Import V1 · date de classement et trimestre à vérifier."
      });
    }
    next.legacy = {
      correct: x.correct,
      days: [...new Set(x.activity)].sort()
    };
    if (!valid(next)) {
      notice("Certaines valeurs dépassent les limites du carnet V3.");
      return;
    }
    confirmAction("Remplacer toutes les données V3 par cet ancien carnet ?", () => {
      if (replaceData(next)) notice("Ancien carnet restauré.");
    });
  });
}
function localLegacy() {
  try {
    let x = oldData(localStorage.getItem("sti2d-revision-v1"));
    return x ? btn("Reprendre le carnet V1 présent sur cet appareil", "legacyDialog(oldData(localStorage.getItem('sti2d-revision-v1')))") : "";
  } catch (e) {
    return "";
  }
}
