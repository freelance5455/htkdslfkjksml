# STRICT FILE INSPECTOR AI — starter monorepo

A starter scaffold for a defensive file-inspection product with:
- `web/`: static web UI (six tabs, local file selection, SHA-256, basic signature/name heuristics)
- `android/`: Android Studio Java starter (selects files via Android's document picker; no broad storage access)
- `backend/`: Node.js + Express API starter for health checks and scan-result metadata
- `docs/SECURITY.md`: boundaries and deployment checklist

## Important limitations
This is a **starter prototype**, not a production malware scanner. It does not use an AI model, threat-intelligence feed, antivirus engine, or sandbox. Its heuristics cannot prove that a file is safe. Do not upload private files to an untrusted service.

## Recommended build order
1. Test the web prototype locally.
2. Push this repository to GitHub.
3. Publish `web/` with GitHub Pages (static UI only).
4. Deploy `backend/` to a Node-compatible host; GitHub Pages cannot run Express.
5. Configure Firebase Authentication and server-side token verification before enabling accounts.
6. Open `android/` in Android Studio on a computer to build an APK. A phone alone can edit/upload the source, but compiling may require a supported Android IDE/build environment.

## Run backend locally
Requires Node.js 18+:
```bash
cd backend
npm install
npm start
```
Default port: 3000. `GET /api/health` returns a health status. `POST /api/scan/metadata` accepts metadata only; it does not upload or scan file bytes.

## Publish web on GitHub Pages
In the repository settings, enable Pages and choose the branch and `/web` folder if the GitHub UI offers that source. Otherwise move/copy the contents of `web/` to the configured publishing root. The exact Pages source options may vary by repository settings.
