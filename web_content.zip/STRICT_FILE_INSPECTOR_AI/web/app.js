const input=document.querySelector('#fileInput'), info=document.querySelector('#fileInfo'), btn=document.querySelector('#scanBtn'), out=document.querySelector('#results'), toast=document.querySelector('#toast');
let selected=null;
input.addEventListener('change',()=>{selected=input.files?.[0]||null;info.textContent=selected?`${selected.name} • ${formatSize(selected.size)}`:'ยังไม่ได้เลือกไฟล์';out.hidden=true;});
function formatSize(n){if(n<1024)return `${n} B`;if(n<1048576)return `${(n/1024).toFixed(1)} KB`;return `${(n/1048576).toFixed(2)} MB`;}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
btn.addEventListener('click',async()=>{if(!selected){info.textContent='กรุณาเลือกไฟล์ก่อน';return;}if(selected.size>50*1024*1024){info.textContent='ไฟล์ใหญ่กว่า 50 MB — เดโมนี้จำกัดขนาดไว้เพื่อป้องกันหน่วยความจำเต็ม';return;}btn.disabled=true;btn.textContent='กำลังตรวจ…';try{
 const buf=await selected.arrayBuffer(), bytes=new Uint8Array(buf);let signature='ไม่สามารถระบุจากลายเซ็นพื้นฐานได้';
 if(bytes[0]===0x50&&bytes[1]===0x4b)signature='ZIP container (อาจเป็น ZIP/APK/DOCX ฯลฯ)';
 else if(bytes[0]===0x4d&&bytes[1]===0x5a)signature='Windows PE executable (MZ)';
 else if(bytes[0]===0x7f&&bytes[1]===0x45&&bytes[2]===0x4c&&bytes[3]===0x46)signature='ELF executable';
 else if(bytes[0]===0x25&&bytes[1]===0x50&&bytes[2]===0x44&&bytes[3]===0x46)signature='PDF';
 else if(bytes[0]===0x89&&bytes[1]===0x50&&bytes[2]===0x4e&&bytes[3]===0x47)signature='PNG image';
 else if(bytes[0]===0xff&&bytes[1]===0xd8&&bytes[2]===0xff)signature='JPEG image';
 const hash=await crypto.subtle.digest('SHA-256',buf), hex=[...new Uint8Array(hash)].map(b=>b.toString(16).padStart(2,'0')).join('');
 const doubleExt=/\.(pdf|jpg|jpeg|png|txt|mp3|wav)\.(exe|apk|js|bat|cmd|scr)$/i.test(selected.name);
 out.hidden=false;out.innerHTML=`<span class="pill">ผลตรวจเบื้องต้นเท่านั้น</span><h2>รายงานการตรวจ</h2><p><b>ชื่อไฟล์:</b> ${escapeHtml(selected.name)}</p><p><b>ขนาด:</b> ${formatSize(selected.size)}</p><p><b>ลายเซ็นที่ตรวจพบ:</b> ${signature}</p><p><b>นามสกุลซ้อนที่น่าสงสัย:</b> ${doubleExt?'พบรูปแบบที่ควรตรวจเพิ่ม':'ไม่พบรูปแบบที่ตรงกับกฎนี้'}</p><p><b>SHA-256:</b><br>${hex}</p><p class="muted">ไม่พบสัญญาณจากกฎพื้นฐาน ≠ ปลอดภัย การตรวจนี้ไม่วิเคราะห์พฤติกรรม ไม่ตรวจโค้ดทั้งหมด และไม่ได้เทียบฐานข้อมูลมัลแวร์</p><button id="downloadReport">ดาวน์โหลดรายงาน JSON</button>`;
 document.querySelector('#downloadReport').onclick=()=>{const blob=new Blob([JSON.stringify({fileName:selected.name,size:selected.size,signature,sha256:hex,doubleExtensionSuspicious:doubleExt,scanType:'local-basic-heuristics',disclaimer:'Not a malware verdict'},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='scan-report.json';a.click();URL.revokeObjectURL(a.href);};
 }catch(e){out.hidden=false;out.textContent='ตรวจไม่สำเร็จในเบราว์เซอร์นี้: '+e.message;}finally{btn.disabled=false;btn.textContent='เริ่มตรวจสอบ';}});
document.querySelectorAll('.bottom-nav button').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.bottom-nav button').forEach(x=>x.classList.remove('active'));b.classList.add('active');if(b.dataset.tab!=='หน้าหลัก'){toast.textContent=`เมนู “${b.dataset.tab}” เป็นโครงหน้าจอ ยังไม่ได้เชื่อม Backend`;toast.style.display='block';setTimeout(()=>toast.style.display='none',2600);}}));
