# Android starter

Open this folder in Android Studio on a supported computer, allow Gradle sync, then build/run. The app uses Android's document picker, hashes the selected file (max 50 MiB), and does not upload it.

This is intentionally a small starter, not a finished six-tab app. Notification channel is created, but posting notifications and requesting runtime notification permission are not implemented yet. Google/email/phone authentication and Backend API calls are not connected. Do not treat the prototype as a malware detector.
