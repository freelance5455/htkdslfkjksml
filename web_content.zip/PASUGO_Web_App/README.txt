PASUGO Lopez Jaena — Web App Prototype

HOW TO USE
1. Extract the ZIP file.
2. Open index.html in a modern browser (Chrome recommended).
3. Allow internet access for map tiles, address search and road routing.
4. Search for pickup and drop-off addresses, press Enter, or tap the map after selecting the pickup/drop-off field.
5. Drag pins to adjust locations. Actual driving-road distance and estimated fare update automatically when both pins are set or moved. If the routing service is unavailable, booking remains disabled rather than estimating from straight-line distance.

FARE RULES INCLUDED
- Pasakay and Pahatod: first 2 km PHP 30
- Pasugo and Papalit: first 2 km PHP 40 (base fare increased by PHP 10)
- Additional distance: PHP 8 per km (pro-rated)
- First 5 minutes waiting: free; then PHP 2 per minute
- Additional stops: PHP 10 each

IMPORTANT LIMITATIONS
- This is a front-end prototype. It does not include customer/rider accounts, live dispatch, a database, payment processing, push notifications, or a production admin dashboard.
- Map/address/routing features require internet access and use OpenStreetMap, Nominatim and the public OSRM demo endpoint. Public services have usage limits and are not guaranteed for commercial production.
- The displayed rates are the proposed PASUGO rates and are not verified official Maxim rates.
- Before public launch, configure a production geocoding/routing provider, backend, privacy notice, and order management.
