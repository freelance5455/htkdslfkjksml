const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const target = `      try {
        if (typeof audioEngine?.init === 'function') {
          await audioEngine.init();
        }
        if (typeof offlineCache?.init === 'function') {
          await offlineCache.init();
        }
      } catch (err) {`;
const replace = `      try {
        if (typeof (audioEngine as any)?.init === 'function') {
          await (audioEngine as any).init();
        }
        if (typeof (offlineCache as any)?.init === 'function') {
          await (offlineCache as any).init();
        }
      } catch (err) {`;

if (code.includes(target)) {
  code = code.replace(target, replace);
  console.log("Fixed TS error");
}
fs.writeFileSync('src/App.tsx', code);
