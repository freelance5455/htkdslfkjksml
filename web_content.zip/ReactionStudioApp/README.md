# Reaction Studio — Android App Project

Ye ek build-ready Android Studio project hai jo aapke Reaction Studio web-app ko
ek real Android app (.apk) me package karta hai. Camera aur photo/video pick
dono native tareeke se kaam karenge.

**Important:** Maine yahan seedha ek compiled `.apk` file nahi di hai — is
environment me Android SDK aur internet access nahi hai jo APK build karne ke
liye chahiye. Lekin ye poora project ready hai, aapko sirf Android Studio me
kholkar "Build" dabana hai.

## APK banane ke steps

1. **Android Studio install karein** (free): https://developer.android.com/studio
2. Is poore folder (`ReactionStudioApp`) ko apne computer me unzip karein.
3. Android Studio kholein → **Open** → is folder ko select karein.
4. Pehli baar Gradle sync hone dein (internet chahiye, thoda time lagega).
5. Menu se: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
6. Build complete hone ke baad "locate" link dabayein — apko
   `app/build/outputs/apk/debug/app-debug.apk` milega.
7. Ye `.apk` file apne Android phone me bhejein (WhatsApp/Drive/USB) aur install
   kar lein (Settings me "Install from unknown sources" allow karna padega).

## Isme kya hai

- `app/src/main/assets/index.html` — aapka poora Reaction Studio app (wahi jo
  claude.ai artifact me hai), ab ek native WebView ke andar chalega.
- `MainActivity.java` — WebView setup karta hai, camera/photo picker ko sahi
  se open karta hai (ye hi cheez browser preview me kaam nahi kar rahi thi),
  aur final video ko seedha phone ke storage me save karne ka bridge deta hai.
- Camera aur microphone permissions manifest me already add hain.

## Agar app ka HTML update karna ho

Bas naya `reaction-studio.html` file ko `app/src/main/assets/index.html` par
copy-replace kar dein aur dobara Build APK karein — Java code me kuch badalne
ki zaroorat nahi.

## Turant use karna ho, APK banaye bina

Web version already yahan available hai aur wahan bhi camera + upload theek
kaam karta hai:
https://claude.ai/artifact/LYjiBNu7BuZcrA4D663yFy

Chrome me kholkar menu → **"Add to Home screen"** dabayein — icon phone ki
home screen par aa jaayega aur app jaisa hi khulega, bina kisi build ke.
