BoostNest SMM App Starter — FREE DEMO

Files:
- index.html: mobile-friendly customer and admin demo panels.

Test on TECNO Android:
1. Download the ZIP and extract it using your file manager.
2. Open index.html in Chrome.
3. Customer Panel: create a demo order.
4. Admin Panel: enter demo PIN 2468.
5. Change order status and demo service prices.

Limitations:
- This is NOT an APK yet.
- Orders are stored only in the current browser on one device.
- Customers on other phones cannot send orders to your admin phone.
- PIN is visible in source and is not secure.
- No real payments, supplier connection, server/database, or automatic delivery.
- Never collect social media passwords.

To launch for real:
1. Host the site on a free static host.
2. Add a secure online backend/database (for example Firebase) with proper admin authentication and database rules.
3. Build an Android WebView wrapper or use Android Studio to generate and sign an APK.
4. Test security, privacy notice, payment and refund flow before launch.

Use lawful marketing services and follow the relevant social platform terms.
