FRUIT LEGENDS ANDROID WRAPPER (V29)

This is an Android WebView wrapper project containing the V29 game HTML locally.
It is not a compiled APK. This environment does not have the Android SDK/Gradle build toolchain, so the APK must be built by GitHub Actions or Android Studio.

EASIEST BUILD USING GITHUB ACTIONS:
1. Create a new GitHub repository named fruit-legends-android.
2. Upload the CONTENTS of this folder (including app, .github, build.gradle, settings.gradle, gradle.properties) to the repository root.
3. Open the repository's Actions tab.
4. Select "Build Fruit Legends APK" and press "Run workflow" (or wait for the push build).
5. When it finishes, open the workflow run and download the "Fruit-Legends-debug-apk" artifact.
6. Extract the artifact ZIP; install app-debug.apk on your Android phone. If Android asks, allow installation from that source.

NOTES:
- Landscape orientation, immersive fullscreen, WebGL hardware acceleration and internet permission are enabled.
- Three.js is loaded from jsDelivr, so first launch needs an internet connection.
- This APK is a local single-player test wrapper, NOT online multiplayer.
- Debug APK is for testing, not Play Store release signing.
