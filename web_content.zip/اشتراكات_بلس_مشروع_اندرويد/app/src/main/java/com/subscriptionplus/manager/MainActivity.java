package com.subscriptionplus.manager;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final String ORIGIN = "appassets.androidplatform.net";
    private static final String HOME = "https://" + ORIGIN + "/index.html";
    private static final int PICK_BACKUP = 121;
    private static final int SAVE_EXPORT = 122;
    private WebView webView;
    private ValueCallback<Uri[]> selectedFiles;
    private byte[] exportBytes;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16,37,40));
        getWindow().setNavigationBarColor(Color.rgb(247,248,245));
        if (Build.VERSION.SDK_INT >= 26) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(true);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        webView.getSettings().setSupportMultipleWindows(false);
        webView.getSettings().setDefaultTextEncodingName("UTF-8");
        if (Build.VERSION.SDK_INT >= 26) webView.getSettings().setSafeBrowsingEnabled(true);
        webView.addJavascriptInterface(new AppBridge(), "AndroidApp");
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!"https".equals(uri.getScheme()) || !ORIGIN.equals(uri.getHost())) return notFound();
                String path = uri.getPath();
                if (!"/index.html".equals(path)) return notFound();
                try {
                    InputStream file = getAssets().open("index.html");
                    return new WebResourceResponse("text/html", "UTF-8", 200, "OK", java.util.Collections.singletonMap("Cache-Control", "no-store"), file);
                } catch (IOException e) { return notFound(); }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equals(uri.getScheme()) && ORIGIN.equals(uri.getHost()))
                    return false;
                // لا نسمح بالانتقال إلى صفحات مجهولة داخل WebView.
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (selectedFiles != null) selectedFiles.onReceiveValue(null);
                selectedFiles = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.setType("application/json");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/json","text/plain","application/octet-stream"});
                try {startActivityForResult(intent,PICK_BACKUP);} catch (ActivityNotFoundException ex) {
                    selectedFiles.onReceiveValue(null);selectedFiles=null;
                    Toast.makeText(MainActivity.this,"لا يوجد تطبيق لاختيار الملفات",Toast.LENGTH_LONG).show();
                }
                return true;
            }
            @Override public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton("حسنًا",(d,w)->result.confirm())
                  .setOnCancelListener(d->result.cancel()).show();return true;
            }
            @Override public boolean onJsConfirm(WebView view,String url,String message,JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setMessage(message)
                  .setPositiveButton("موافق",(d,w)->result.confirm())
                  .setNegativeButton("إلغاء",(d,w)->result.cancel())
                  .setOnCancelListener(d->result.cancel()).show();return true;
            }
        });
        setContentView(webView);
        webView.loadUrl(HOME);
    }

    private WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
           java.util.Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));
    }

    private class AppBridge {
        @JavascriptInterface public void openExternal(String address) {
            // فقط روابط واتساب الموثوقة؛ لا نستقبل أوامر أو عناوين عشوائية.
            Uri uri;
            try {uri = Uri.parse(address);}catch(Exception e){return;}
            if (!"https".equals(uri.getScheme()) || !"wa.me".equals(uri.getHost())) return;
            runOnUiThread(()->{
                try {startActivity(new Intent(Intent.ACTION_VIEW,uri));}
                catch (ActivityNotFoundException e) {Toast.makeText(MainActivity.this,"لم يُعثر على تطبيق لفتح واتساب",Toast.LENGTH_LONG).show();}
            });
        }
        @JavascriptInterface public void saveBase64(String base64,String filename,String mimeType) {
            if (base64==null || filename==null || !(filename.endsWith(".json") || filename.endsWith(".csv"))) return;
            if (base64.length()>28_000_000) return;
            try {
                byte[] content=Base64.decode(base64,Base64.DEFAULT);
                if(content.length>20_000_000)return;
                runOnUiThread(()->{
                    exportBytes=content;
                    Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.setType(filename.endsWith(".json")?"application/json":"text/csv");
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.putExtra(Intent.EXTRA_TITLE,filename);
                    try {startActivityForResult(intent,SAVE_EXPORT);}
                    catch (ActivityNotFoundException ex) {exportBytes=null;Toast.makeText(MainActivity.this,"تعذر فتح نافذة الحفظ",Toast.LENGTH_LONG).show();}
                });
            } catch (IllegalArgumentException ignored) { }
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_BACKUP) {
            if(selectedFiles!=null) {
                Uri[] values=resultCode==RESULT_OK && data!=null && data.getData()!=null ? new Uri[]{data.getData()}:null;
                selectedFiles.onReceiveValue(values);selectedFiles=null;
            }
        } else if(requestCode==SAVE_EXPORT) {
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null && exportBytes!=null) {
                try (OutputStream out=getContentResolver().openOutputStream(data.getData())) {
                    if(out==null)throw new IOException("Stream is null");
                    out.write(exportBytes);out.flush();
                    Toast.makeText(this,"تم حفظ الملف بنجاح",Toast.LENGTH_SHORT).show();
                }catch(IOException e){Toast.makeText(this,"فشل حفظ الملف",Toast.LENGTH_LONG).show();}
            }
            exportBytes=null;
        }
    }

    @Override public void onBackPressed() {
        if(webView==null){super.onBackPressed();return;}
        webView.evaluateJavascript("window.appHandleBack ? window.appHandleBack() : false", value -> {
            if(!"true".equals(value)) {
                new AlertDialog.Builder(this).setTitle("اشتراكات بلس")
                  .setMessage("هل تريد إغلاق التطبيق؟")
                  .setNegativeButton("إلغاء",(d,w)->{})
                  .setPositiveButton("إغلاق",(d,w)->finish())
                  .show();
            }
        });
    }
    @Override protected void onDestroy() {
        if(selectedFiles!=null){selectedFiles.onReceiveValue(null);selectedFiles=null;}
        if(webView!=null){webView.destroy();webView=null;}
        super.onDestroy();
    }
}
