የአላማጣ መካነ ኢየሱስ መዝሙር ደብተር — Professional Offline Edition

Files:
- index.html
- style.css
- script.js (168 songs: 121 Hā + 47 Lē)

Highlights:
- Fully local song lyrics for offline APK packaging
- Bible verse on the home hero: መዝሙረ ዳዊት 150:6
- Multiple visual themes
- Font controls moved to the top of the song reader
- Professional entrance, hover/tap, and reader animations
- Favorites, notes, history, font size and local storage

For an offline APK builder, upload the ZIP contents/project and choose local/ZIP/offline mode, not Website URL mode.
