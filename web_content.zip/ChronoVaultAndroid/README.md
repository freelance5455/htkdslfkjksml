# ChronoVault POS Android project

This is a WebView wrapper project for the supplied single-file Watch Shop POS HTML app.

## Build APK
1. Install Android Studio on a computer and let it install Android SDK Platform 35.
2. Open this folder (`ChronoVaultAndroid`) in Android Studio.
3. Wait for Gradle sync to finish.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).

The HTML app is bundled locally in `app/src/main/assets/index.html`; it does not need a hosted website. LocalStorage data persists in the app WebView. Invoice printing is routed to Android's print dialog. JSON backup restore uses Android's file picker. Downloads are handled by Android DownloadManager.

## Notes
- The source HTML had malformed newline string literals in CSV export; they were corrected in the packaged copy.
- Android SDK/Gradle are not present in the build environment used to prepare this project, so an APK could not be compiled here.
