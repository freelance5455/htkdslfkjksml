RP COOK Web App files

index.html: Main RP COOK website/app prototype.

To use:
1. Open index.html in a browser to preview.
2. To publish it free, upload this folder's index.html to Netlify Drop (https://app.netlify.com/drop) or GitHub Pages.
3. To install on Android like an app, first publish it online, then use a trusted website-to-APK/PWA method. APK builds may require additional permissions and review.

Note: This is a web app prototype. Orders are directed to WhatsApp number configured in the HTML.
