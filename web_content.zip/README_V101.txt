CryptoPulse V101
Shared LBank live hub + 1-minute canonical cache. Higher timeframes are aggregated from 1m data. Asset chart no longer opens an independent LBank WebSocket.
