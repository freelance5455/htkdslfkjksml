plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ghostframe.overlay"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ghostframe.overlay"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}
