package com.ghostframe.overlay

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var overlay: FrameLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Сначала разреши показ поверх других приложений", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        if (overlay == null) showOverlay()
        return START_NOT_STICKY
    }

    private fun showOverlay() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val density = resources.displayMetrics.density
        val width = (360 * density).toInt()
        val height = (540 * density).toInt()
        val root = FrameLayout(this).apply { setBackgroundColor(Color.TRANSPARENT) }
        val web = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            loadUrl("file:///android_asset/index.html")
        }
        root.addView(web, FrameLayout.LayoutParams(width, height))

        val close = TextView(this).apply {
            text = "×"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(0xDD252525.toInt())
            setOnClickListener { stopSelf() }
            contentDescription = "Закрыть плавающее меню"
        }
        val closeSize = (36 * density).toInt()
        val closeParams = FrameLayout.LayoutParams(closeSize, closeSize, Gravity.TOP or Gravity.END)
        root.addView(close, closeParams)

        val params = WindowManager.LayoutParams(
            width,
            height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = (24 * density).toInt()
            title = "GHOSTFRAME overlay"
        }
        try {
            windowManager.addView(root, params)
            overlay = root
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось открыть плавающее меню: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    override fun onDestroy() {
        overlay?.let { view ->
            try { windowManager.removeView(view) } catch (_: Exception) { }
        }
        overlay = null
        super.onDestroy()
    }
}
