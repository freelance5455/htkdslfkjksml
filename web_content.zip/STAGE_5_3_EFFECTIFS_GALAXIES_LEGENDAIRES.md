# CGD — Étape 5.3 : effectifs, galaxies et légendaires

## Effectifs des clubs
- Les 36 clubs actifs (12 en Super League, 12 en Ligue A, 12 en Ligue B) disposent chacun de deux damistes nommés.
- Chaque profil comporte notamment un niveau, une forme, un âge, une nationalité, une spécialité et un potentiel.
- Les identifiants de joueurs restent liés au club pour préserver les calendriers, contrats et transferts.

## Effectifs des galaxies
- Les 24 galaxies possèdent chacune deux représentants nommés avec leurs caractéristiques sportives.
- Ces données sont enregistrées dans `state.world.galaxies[].damistes`.

## 24 damistes légendaires
- Les 24 légendaires historiques et leurs pouvoirs/origines sont conservés.
- Ils sont disponibles dans le marché des transferts tant qu'ils ne sont pas recrutés.
- Le recrutement se fait dans le bureau du club : le manager choisit le légendaire et le titulaire remplacé.
- Prix catalogue : 2 500 000 Gold. Le budget est contrôlé ; le club conserve exactement deux damistes.
- Un légendaire recruté est marqué comme indisponible dans le catalogue et rejoint l'effectif avec le niveau 99.

## Migration et vérification
- Les sauvegardes existantes sont complétées automatiquement si elles contiennent encore les noms génériques « Damiste 1/2 ».
- Les profils déjà personnalisés sont conservés.
- Validation : 261 tests automatisés réussis ; syntaxe `src/app.js` vérifiée avec Node.js.
