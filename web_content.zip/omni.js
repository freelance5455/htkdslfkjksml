/* Apkomini — age gate, social footer, share buttons */
var TIKTOK_URL = "https://www.tiktok.com/@omniowner?_r=1&_t=ZS-992CdkkzXyH";
var TIKTOK_IMG = "https://i.ibb.co/35BYqL7F/5d63c857404bab94c94a3f5b719628f2.jpg";
var AGE_KEY = "omni_age_18";

/* ---------- Age gate (shown on every entry until confirmed) ---------- */
(function () {
  function ok() { try { return localStorage.getItem(AGE_KEY) === "yes"; } catch (e) { return false; } }
  function save() { try { localStorage.setItem(AGE_KEY, "yes"); } catch (e) {} }
  if (ok()) return;

  function build() {
    var d = document.createElement("div");
    d.className = "overlay agegate";
    d.id = "omniAgeGate";
    d.innerHTML =
      '<div class="box center">' +
        '<img src="favicon.png" alt="Apkomini" style="width:64px;height:64px;object-fit:contain" />' +
        '<h2 style="font-size:18px">Age verification</h2>' +
        '<p class="muted">This site contains 18+ content. Please confirm your age to continue.</p>' +
        '<p><button type="button" id="omniAge18"><b>I am 18 years old or older</b></button></p>' +
        '<p><button type="button" id="omniAgeNo">I am under 18</button></p>' +
        '<p id="omniAgeMsg" class="err"></p>' +
      '</div>';
    document.body.appendChild(d);
    document.documentElement.style.overflow = "hidden";
    document.getElementById("omniAge18").onclick = function () {
      save();
      d.parentNode.removeChild(d);
      document.documentElement.style.overflow = "";
    };
    document.getElementById("omniAgeNo").onclick = function () {
      document.getElementById("omniAgeMsg").textContent =
        "Sorry, you must be 18 or older to use Apkomini.";
    };
  }
  if (document.body) build();
  else document.addEventListener("DOMContentLoaded", build);
})();

/* ---------- Social footer (Telegram, Facebook, TikTok, TikTok Coins) ---------- */
function omniSocialHTML() {
  return '' +
    '<div class="social">' +
      '<a href="https://t.me/josephminmin" target="_blank" rel="noopener noreferrer"><img src="https://i.ibb.co/chz5PwSp/5c2df0b57b5f55fc60a408c4a1dfae79-1.jpg" alt="Telegram channel" /></a>' +
      '<a href="https://www.facebook.com/share/1LSwV1Lt6W/" target="_blank" rel="noopener noreferrer"><img src="https://i.ibb.co/mCGQrR1N/e7c15488d7a9ef341d79bbe19c5bac30-1.jpg" alt="Facebook page" /></a>' +
      '<a href="https://www.facebook.com/share/1LcpCojbyq/" target="_blank" rel="noopener noreferrer"><img src="https://i.ibb.co/mCGQrR1N/e7c15488d7a9ef341d79bbe19c5bac30-1.jpg" alt="Facebook page 2" /></a>' +
      '<a href="' + TIKTOK_URL + '" target="_blank" rel="noopener noreferrer"><img src="' + TIKTOK_IMG + '" alt="TikTok account" /></a>' +
    '</div>';
}

/* ---------- MultiTag inpage ad ---------- */
var MULTITAG_SRC = "//prizefamily.com/bkXqV.ssdJGZl-0DYDWLcu/SeJm/9QuUZMUOl-kcP/TBcDzqN/D/Uu0PNITQcstiNyzJMQ0QN/TIQB2aMPQV";
function omniMultiTag(slot) {
  if (!slot || slot.getAttribute("data-loaded") === "1") return;
  slot.setAttribute("data-loaded", "1");
  var s = document.createElement("script");
  s.settings = {};
  s.src = MULTITAG_SRC;
  s.async = true;
  s.referrerPolicy = "no-referrer-when-downgrade";
  slot.appendChild(s);
}


/* ---------- Screenshot lightbox (tap to view) ---------- */
function omniLightbox(src, alt) {
  var d = document.createElement("div");
  d.className = "lightbox";
  d.innerHTML = '<button type="button" class="lbclose" aria-label="Close">✕ Close</button>' +
                '<img src="' + src + '" alt="' + (alt || "Screenshot") + '" />';
  d.addEventListener("click", function () {
    if (d.parentNode) d.parentNode.removeChild(d);
    document.documentElement.style.overflow = "";
  });
  document.body.appendChild(d);
  document.documentElement.style.overflow = "hidden";
}
document.addEventListener("click", function (e) {
  var img = e.target;
  if (!img || img.tagName !== "IMG") return;
  if (!img.closest || !img.closest(".shots")) return;
  e.preventDefault();
  omniLightbox(img.getAttribute("src"), img.getAttribute("alt"));
}, true);


/* ---------- Share ---------- */
function omniShare(url, title) {
  var full = new URL(url, location.href).toString();
  if (navigator.share) {
    navigator.share({ title: title || document.title, url: full }).catch(function () {});
    return;
  }
  if (navigator.clipboard) {
    navigator.clipboard.writeText(full).then(function () { alert("Link copied: " + full); },
      function () { prompt("Copy this link:", full); });
  } else {
    prompt("Copy this link:", full);
  }
}
document.addEventListener("click", function (e) {
  var b = e.target.closest ? e.target.closest("[data-share]") : null;
  if (!b) return;
  e.preventDefault();
  e.stopPropagation();
  omniShare(b.getAttribute("data-share"), b.getAttribute("data-share-title") || "");
}, true);
