WAVELENGTH
web/      -> upload these files to Netlify Drop (installable app, no Android Studio)
app/      -> Android Studio project files (optional, best background play)
See chat for steps. API key: tap the gear badge at the top right.
