package com.example.wavelength

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader

/**
 * WebView that never reports "window hidden". Without this, Android tells the page it is
 * invisible when the screen locks or the app is minimised, and YouTube pauses the video.
 */
class BgWebView(context: Context) : WebView(context) {
    override fun onWindowVisibilityChanged(visibility: Int) {
        if (visibility != View.GONE && visibility != View.INVISIBLE) {
            super.onWindowVisibilityChanged(visibility)
        }
    }
}

/** Called from index.html so the notification shows the current song. */
class Bridge {
    @JavascriptInterface
    fun nowPlaying(title: String?, artist: String?, playing: Boolean) {
        KeepAliveService.update(title ?: "", artist ?: "", playing)
    }
}

class MainActivity : AppCompatActivity() {

    companion object {
        private var webViewRef: WebView? = null

        /** Used by the notification buttons to control the page. */
        fun runJs(js: String) {
            val wv = webViewRef ?: return
            wv.post { wv.evaluateJavascript(js, null) }
        }
    }

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = BgWebView(this)
        webView.setBackgroundColor(0xFF0B0B0F.toInt())
        setContentView(webView)
        webViewRef = webView

        // Serves app/src/main/assets/index.html at a real https address,
        // which the YouTube player needs in order to load.
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)
        }
        webView.webChromeClient = WebChromeClient()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true            // keeps liked songs and the API key
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
        }
        webView.addJavascriptInterface(Bridge(), "AndroidBridge")

        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        // Back button sends the app to the background so the music keeps playing.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                moveTaskToBack(true)
            }
        })

        ContextCompat.startForegroundService(this, Intent(this, KeepAliveService::class.java))

        if (!askNotificationPermission()) askBatteryExemption()
    }

    /** Returns true if a permission dialog was shown. */
    private fun askNotificationPermission(): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1
            )
            return true
        }
        return false
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        askBatteryExemption()
    }

    /** Samsung and other phones kill background apps; ask once to be exempt. */
    private fun askBatteryExemption() {
        if (Build.VERSION.SDK_INT < 23) return
        val prefs = getSharedPreferences("wavelength", MODE_PRIVATE)
        if (prefs.getBoolean("asked_battery", false)) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) return
        prefs.edit().putBoolean("asked_battery", true).apply()
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            // Settings screen not available on this phone
        }
    }

    override fun onDestroy() {
        webViewRef = null
        super.onDestroy()
    }

    // Important: we do NOT call webView.onPause() here, so audio continues
    // when the screen is locked or the app goes to the background.
}
