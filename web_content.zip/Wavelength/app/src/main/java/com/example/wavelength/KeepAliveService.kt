package com.example.wavelength

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat

/**
 * Foreground service: keeps the app alive while music plays and shows a
 * notification with Previous / Play-Pause / Next buttons.
 */
class KeepAliveService : Service() {

    companion object {
        const val CHANNEL = "wavelength_playback"
        const val ACT_PLAY = "com.example.wavelength.PLAY_PAUSE"
        const val ACT_NEXT = "com.example.wavelength.NEXT"
        const val ACT_PREV = "com.example.wavelength.PREV"
        private const val NOTIF_ID = 1

        @Volatile private var instance: KeepAliveService? = null
        private var title = "Wavelength"
        private var artist = "Pick a song"
        private var playing = false

        /** Called from the web page through the bridge. */
        fun update(t: String, a: String, p: Boolean) {
            title = t
            artist = a
            playing = p
            instance?.refresh()
        }
    }

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this

        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL, "Music playback", NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }

        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, notification)
        }

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "wavelength:playback").apply {
            acquire(6 * 60 * 60 * 1000L)
        }
    }

    private fun actionIntent(action: String, requestCode: Int): PendingIntent =
        PendingIntent.getService(
            this, requestCode,
            Intent(this, KeepAliveService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val playIcon = if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play

        return NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle(title)
            .setContentText(artist)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(openApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(android.R.drawable.ic_media_previous, "Previous", actionIntent(ACT_PREV, 1))
            .addAction(playIcon, if (playing) "Pause" else "Play", actionIntent(ACT_PLAY, 2))
            .addAction(android.R.drawable.ic_media_next, "Next", actionIntent(ACT_NEXT, 3))
            .build()
    }

    fun refresh() {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIF_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACT_PLAY -> MainActivity.runJs("document.getElementById('btn-play').click()")
            ACT_NEXT -> MainActivity.runJs("document.getElementById('btn-next').click()")
            ACT_PREV -> MainActivity.runJs("document.getElementById('btn-prev').click()")
        }
        return START_STICKY
    }

    // User swiped the app away from recent apps: stop music and the service.
    override fun onTaskRemoved(rootIntent: Intent?) {
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        instance = null
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
