AL SAIF COMMUNICATION — Starter App

Files:
- index.html: working mobile-friendly app.

How to use:
1. Open index.html in a browser on your phone or computer.
2. Add sales, stock and Easypaisa/JazzCash ledger entries.
3. Use Export Backup regularly to save a JSON backup.
4. Restore Backup lets you load a previously exported backup.

Important:
- This starter version stores records locally in the browser on that device.
- It is not yet an Android APK. To install as a native APK, this project needs an Android wrapper/build step.
- Avoid clearing browser/app storage unless you have exported a backup.
- Wallet transactions are manually entered; this app does not connect to Easypaisa or JazzCash systems.
