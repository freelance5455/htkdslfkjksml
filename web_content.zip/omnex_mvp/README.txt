OMNEX MVP v0.2
================

HOW TO TEST ON PHONE
1. Extract omnex_mvp.zip.
2. Open index.html in a mobile browser or HTML viewer.
3. Add name, 10-digit phone and address in Profile.
4. Add products to cart and place a Cash-on-Delivery order.
5. Tap the role button at the top to switch between Customer, Store, Delivery, and Admin.
6. In Store mode add/delete products and accept/prepare orders.
7. In Delivery mode change order status; GPS button asks for permission and shows this device's coordinates.

IMPORTANT LIMITATION
This is a functional single-device MVP. It stores information in this browser's local storage. It does NOT yet sync between different phones, authenticate users securely, send orders to real shops, share live GPS with customers, or process online payments. Those production features require a hosted backend, authentication/security rules, maps setup and payment gateway account. Do not use real customer information for testing.
