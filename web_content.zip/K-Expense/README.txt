K-Expense — HTML Expense Tracker
Created by Kanon Chowdhury.

1. Extract this ZIP and keep index.html and assets folder together.
2. Open index.html in Chrome or another modern browser.
3. Add expenses; data is saved locally in this browser on this device.
4. Use CSV download or JSON backup to keep a backup.
Note: This is an HTML web app, not a compiled APK. Clearing browser data may erase entries.
