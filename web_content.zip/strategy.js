import { MINUTE } from './data.js';
// Every update receives a closed bar. Pivots are published only after w right bars.
export class Layer {
  constructor(period, window) {
    this.period = period; this.window = window; this.bars = []; this.count = 0;
    this.atr = null; this.sumTR = 0; this.previousClose = null;
    this.high = null; this.low = null; this.displacement = null;
  }
  add(bar, multiple = 1.2) {
    const previous = this.previousClose;
    const tr = previous === null ? 0 : Math.max(bar.high - bar.low, Math.abs(bar.high - previous), Math.abs(bar.low - previous));
    this.count++;
    // Match TA-Lib ATR initialization: exclude the first candle's true range.
    if (this.count > 1 && this.count <= this.period + 1) this.sumTR += tr;
    if (this.count === this.period + 1) this.atr = this.sumTR / this.period;
    else if (this.count > this.period + 1) this.atr = (this.atr * (this.period - 1) + tr) / this.period;
    this.previousClose = bar.close;
    this.bars.push(bar);
    if (this.bars.length > Math.max(64, this.window * 2 + 3)) this.bars.shift();
    const w = this.window; const i = this.bars.length - 1 - w;
    if (i >= w) {
      const center = this.bars[i];
      const left = this.bars.slice(i - w, i); const right = this.bars.slice(i + 1, i + w + 1);
      if (left.every(b => center.high > b.high) && right.every(b => center.high >= b.high)) this.high = { value: center.high, t: center.t, confirmed: bar.t };
      if (left.every(b => center.low < b.low) && right.every(b => center.low <= b.low)) this.low = { value: center.low, t: center.t, confirmed: bar.t };
    }
    const range = bar.high - bar.low;
    if (this.atr !== null && this.atr > 0 && range >= multiple * this.atr && range > 0) {
      let side = null;
      if (bar.close > bar.open && bar.close >= bar.low + 0.75 * range) side = 'BUY';
      if (bar.close < bar.open && bar.close <= bar.low + 0.25 * range) side = 'SELL';
      if (side) this.displacement = { side, low: bar.low, high: bar.high, mid: (bar.high + bar.low) / 2, t: bar.t };
    }
  }
}
// Reject partial buckets (including gaps) rather than treating them as closed HTF bars.
export class Aggregator {
  constructor(minutes) { this.minutes = minutes; this.bucket = null; }
  add(bar) {
    const duration = this.minutes * MINUTE;
    const end = (Math.floor((bar.t - 1) / duration) + 1) * duration;
    if (!this.bucket || this.bucket.t !== end) this.bucket = { ...bar, t: end, first: bar.t, last: bar.t, count: 1, valid: true };
    else {
      const b = this.bucket;
      b.valid = b.valid && bar.t - b.last === MINUTE;
      b.high = Math.max(b.high, bar.high); b.low = Math.min(b.low, bar.low); b.close = bar.close;
      b.volume += bar.volume; b.last = bar.t; b.count++;
    }
    if (bar.t !== end) return null;
    const b = this.bucket; this.bucket = null;
    return b.valid && b.count === this.minutes && b.first === end - duration + MINUTE ? b : null;
  }
}
export class CRT {
  constructor(params, log) {
    this.p = params; this.log = log;
    this.m1 = new Layer(params.atr, params.pivot);
    this.m15 = new Layer(params.atr, params.pivot);
    this.h4 = new Layer(params.atr, params.pivot);
    this.a15 = new Aggregator(15); this.a4 = new Aggregator(240);
    this.zoneSignature = ''; this.confirmSignature = '';
    this.stats = { h4Bars: 0, m15Bars: 0, h4Aligned: 0, m15Confirmed: 0, triggers: 0 };
  }
  update(bar) {
    this.m1.add(bar);
    const b15 = this.a15.add(bar); const b4 = this.a4.add(bar);
    if (b15) this.m15.add(b15, 1.2);
    if (b4) this.h4.add(b4, 1.5);
    this.stats.h4Bars = this.h4.count; this.stats.m15Bars = this.m15.count;
    const d = this.h4.displacement;
    if (d && String(d.t) !== this.zoneSignature) {
      this.zoneSignature = String(d.t);
      this.log(bar.t, 'CRT H4 zone update', `${d.side} | zone=${d.low.toFixed(8)}..${d.high.toFixed(8)}`);
    }
  }
  signal(bar) {
    const p = this.p; const h = this.h4; const m = this.m15; const one = this.m1;
    if (h.count < Math.max(62, p.atr + 2) || !h.high || !h.low || !h.displacement || !h.atr || !m.atr || !one.atr) return null;
    const d = h.displacement; const midpoint = (h.high.value + h.low.value) / 2;
    const tolerance = p.tolerance * h.atr;
    if (bar.close < d.low - tolerance || bar.close > d.high + tolerance) return null;
    if ((d.side === 'BUY' && bar.close < midpoint) || (d.side === 'SELL' && bar.close > midpoint)) return null;
    this.stats.h4Aligned++;
    if (!m.high || !m.low || !m.displacement || m.displacement.side !== d.side || m.bars.length < 8) return null;
    const last = m.bars[m.bars.length - 1]; const tol15 = p.tolerance * m.atr;
    const interacted = m.bars.slice(-8).some(b => b.low <= d.high + tol15 && b.high >= d.low - tol15);
    const bos = d.side === 'BUY' ? last.close > m.high.value : last.close < m.low.value;
    const retrace = last.close >= d.low - tol15 && last.close <= d.high + tol15;
    const displacementInside = m.displacement.mid >= d.low && m.displacement.mid <= d.high;
    if (!interacted || !bos || !(retrace || displacementInside)) return null;
    this.stats.m15Confirmed++;
    const signature = `${last.t}:${d.side}`;
    if (signature !== this.confirmSignature) {
      this.confirmSignature = signature;
      this.log(bar.t, 'CRT M15 zone interaction/MSS', `${d.side} | BOS=true | retracement=${retrace}`);
    }
    const pivot = d.side === 'BUY' ? one.low : one.high;
    const range = bar.high - bar.low;
    if (!pivot || range <= 0 || range < 1.2 * one.atr || Math.abs(bar.close - bar.open) < 0.6 * range) return null;
    const bullish = d.side === 'BUY';
    const swept = bullish ? bar.low < pivot.value && bar.close > pivot.value : bar.high > pivot.value && bar.close < pivot.value;
    const displaced = bullish ? bar.close > bar.open && bar.close >= bar.low + 0.75 * range : bar.close < bar.open && bar.close <= bar.low + 0.25 * range;
    const tol1 = p.tolerance * Math.max(one.atr, h.atr);
    if (!swept || !displaced || bar.close < d.low - tol1 || bar.close > d.high + tol1) return null;
    this.stats.triggers++;
    const stop = bullish ? Math.min(pivot.value, bar.low) - one.atr * p.buffer : Math.max(pivot.value, bar.high) + one.atr * p.buffer;
    this.log(bar.t, 'CRT M1 trigger', `${d.side} | sweep=${pivot.value.toFixed(8)} | signal close=${bar.close.toFixed(8)}`);
    return { side: d.side, stop, signalTime: bar.t, level: pivot.value, atr: one.atr };
  }
}
