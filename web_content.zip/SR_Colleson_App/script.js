const $ = id => document.getElementById(id);
const STORAGE_KEY = "sr_colleson_accounts_v1";
let entries = [];
try { entries = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); if (!Array.isArray(entries)) entries = []; } catch { entries = []; }
$("date").value = new Date().toISOString().slice(0,10);
const money = n => "रु " + Number(n || 0).toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2});
const labels = {income:"आमदनी", expense:"खर्च", due:"उधार बाकी", paid:"उधार वसूली"};
function save(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(entries)); render(); }
function totals(){
  const income = entries.filter(e=>e.type==="income").reduce((s,e)=>s+e.amount,0);
  const expense = entries.filter(e=>e.type==="expense").reduce((s,e)=>s+e.amount,0);
  const due = entries.filter(e=>e.type==="due").reduce((s,e)=>s+e.amount,0)-entries.filter(e=>e.type==="paid").reduce((s,e)=>s+e.amount,0);
  const balance = income-expense;
  $("income").textContent=money(income); $("expense").textContent=money(expense);
  $("balance").textContent=money(balance); $("due").textContent=money(Math.max(0,due));
}
function render(){
  totals();
  const q=$("search").value.trim().toLowerCase(), type=$("filter").value, month=$("month").value;
  const filtered=entries.filter(e=>(type==="all"||e.type===type)&&(!month||e.date.startsWith(month))&&(!q||(e.title+" "+e.note+" "+e.category).toLowerCase().includes(q)));
  $("rows").innerHTML="";
  filtered.slice().sort((a,b)=>b.date.localeCompare(a.date)||b.id-a.id).forEach(e=>{
    const tr=document.createElement("tr");
    const cells=[e.date,e.title+(e.note?` — ${e.note}`:""),e.category];
    cells.forEach(v=>{const td=document.createElement("td");td.textContent=v;tr.appendChild(td);});
    const typeTd=document.createElement("td"), tag=document.createElement("span");
    tag.className="tag tag-"+e.type;tag.textContent=labels[e.type];typeTd.appendChild(tag);tr.appendChild(typeTd);
    const amountTd=document.createElement("td");amountTd.className="money";amountTd.textContent=(e.type==="expense"?"−":"+")+money(e.amount);tr.appendChild(amountTd);
    const actionTd=document.createElement("td"),btn=document.createElement("button");btn.className="delete";btn.textContent="हटाएँ";btn.setAttribute("aria-label","हिसाब हटाएँ");
    btn.addEventListener("click",()=>{if(confirm("क्या यह हिसाब हटाना चाहते हैं?")){entries=entries.filter(x=>x.id!==e.id);save();}});actionTd.appendChild(btn);tr.appendChild(actionTd);
    $("rows").appendChild(tr);
  });
  $("empty").style.display=filtered.length?"none":"block";
  $("count").textContent=filtered.length;
  $("shownTotal").textContent=money(filtered.reduce((s,e)=>s+e.amount,0));
}
$("entryForm").addEventListener("submit",ev=>{
  ev.preventDefault();
  const amount=Number($("amount").value);
  if(!Number.isFinite(amount)||amount<=0){alert("कृपया सही रकम डालें।");return;}
  entries.push({id:Date.now()+Math.floor(Math.random()*1000),title:$("title").value.trim(),amount,type:$("type").value,category:$("category").value,date:$("date").value,note:$("note").value.trim()});
  save();$("entryForm").reset();$("date").value=new Date().toISOString().slice(0,10);$("title").focus();
});
["search","filter","month"].forEach(id=>$(id).addEventListener(id==="search"?"input":"change",render));
$("clearBtn").addEventListener("click",()=>{if(confirm("सारे हिसाब हमेशा के लिए हट जाएँगे। क्या आप जारी रखना चाहते हैं?")){entries=[];save();}});
$("exportBtn").addEventListener("click",()=>{
  if(!entries.length){alert("डाउनलोड करने के लिए अभी कोई हिसाब नहीं है।");return;}
  const esc=v=>'"'+String(v??"").replace(/"/g,'""')+'"';
  const lines=[["तारीख","विवरण","रकम","प्रकार","कैटेगरी","नोट"],...entries.map(e=>[e.date,e.title,e.amount,labels[e.type],e.category,e.note])];
  const csv="\uFEFF"+lines.map(row=>row.map(esc).join(",")).join("\r\n");
  const blob=new Blob([csv],{type:"text/csv;charset=utf-8;"}),url=URL.createObjectURL(blob),a=document.createElement("a");
  a.href=url;a.download="SR-Colleson-Hisab.csv";a.click();URL.revokeObjectURL(url);
});
render();