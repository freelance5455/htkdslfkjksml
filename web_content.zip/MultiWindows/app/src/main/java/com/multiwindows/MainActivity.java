package com.multiwindows;
import android.app.Activity; import android.content.Intent; import android.net.Uri; import android.os.Bundle;
import android.view.View; import android.webkit.*; import androidx.webkit.WebViewAssetLoader;
import java.io.IOException;
public class MainActivity extends Activity {
  WebView wv; ValueCallback<Uri[]> cb;
  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    wv = new WebView(this); setContentView(wv);
    WebSettings s = wv.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    s.setMediaPlaybackRequiresUserGesture(false); s.setAllowFileAccess(false);
    final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
      .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
    wv.setWebViewClient(new WebViewClient() {
      @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
        Uri u = r.getUrl();
        if (u.getPath() != null && u.getPath().endsWith(".wasm")) {
          try { return new WebResourceResponse("application/wasm", null, getAssets().open(u.getPath().substring("/assets/".length()))); }
          catch (IOException e) { return null; }
        }
        return loader.shouldInterceptRequest(u);
      }
    });
    wv.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> c, FileChooserParams p) {
        if (cb != null) cb.onReceiveValue(null);
        cb = c;
        Intent i = new Intent(Intent.ACTION_GET_CONTENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
        startActivityForResult(i, 1); return true;
      }
    });
    wv.loadUrl("https://appassets.androidplatform.net/assets/engine/index.html");
  }
  @Override protected void onActivityResult(int rq, int rc, Intent d) {
    if (rq == 1 && cb != null) { cb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rc, d)); cb = null; }
  }
  @Override public void onWindowFocusChanged(boolean f) {
    super.onWindowFocusChanged(f);
    if (f) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
  }
  @Override public void onBackPressed() { if (wv.canGoBack()) wv.goBack(); else super.onBackPressed(); }
}
