MISSING MONEY — ANDROID APP PROJECT

This project wraps your supplied Missing Money HTML app inside an Android WebView. It is configured with an app name/icon label and launcher entry. Your records remain stored locally on the device in the WebView browser storage; uninstalling/clearing app data may remove them, so use Export backup regularly.

IMPORTANT: This ZIP is the Android Studio source project, not a compiled APK. This environment does not have the Android SDK/Gradle build tools installed, so it cannot compile and sign the APK here.

HOW TO BUILD THE APK (free):
1. On a computer, install Android Studio from the official Android developer website.
2. Extract this ZIP.
3. Open Android Studio > Open, and choose the extracted MissingMoneyAndroid folder.
4. Allow Gradle sync and install the Android SDK Platform 35 if Android Studio asks.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When finished, click “locate” in the notification. The APK is usually at app/build/outputs/apk/debug/app-debug.apk.
7. Transfer app-debug.apk to your Android phone, tap it, and allow “Install unknown apps” for the app used to open it if Android asks.

No payment is required to build/install a debug APK this way. Publishing on Google Play is a separate process and may have fees.
