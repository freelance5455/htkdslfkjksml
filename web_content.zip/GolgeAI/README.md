# Gölge AI

Android uygulaması: koyu Gölge arayüzü, sohbet geçmişi, kalıcı hafıza, API ayarları, GGUF Model Merkezi ve native llama.cpp tabanlı yerel çıkarım.

## Önemli
- APK'ya devasa bir GGUF dosyası gömülmez. Model Merkezi telefondan `.gguf` seçip uygulamanın özel model klasörüne kopyalar.
- Native motor llama.cpp kaynaklarını CMake ile derleme sırasında indirir. Bu nedenle ilk derlemede internet gerekir; GitHub hesabı gerekmez.
- Bu proje ARM64 içindir (`arm64-v8a`) ve Android 8+ hedefler. Güncel resmi llama.cpp Android örneği daha yeni cihazlar için minSdk 33 kullanıyor; burada daha eski cihazlara uyum için daha düşük minSdk seçildi, fakat gerçek cihazda derleme/performans doğrulaması yapılmalıdır.
- Model üretimi CPU tarafında ayarlanmıştır; düşük RAM'li telefonlarda küçük quantize GGUF kullanmak gerekir.

## Derleme
Android Studio/uygun Android IDE ile projeyi açıp Gradle build yap. Gerekli Android SDK, NDK ve CMake sürümleri Gradle dosyasında belirtilmiştir.
