package com.golge.ai

import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import java.util.concurrent.Executors

class GolgeBridge(private val webView: WebView, private val activity: MainActivity) {
    private val models = ModelManager(activity)
    private val executor = Executors.newSingleThreadExecutor()

    @JavascriptInterface fun pickGGUF(requestId: String) { activity.pickModel(requestId) }

    @JavascriptInterface fun listModels(requestId: String) {
        val arr = org.json.JSONArray()
        models.list().forEach { f -> arr.put(JSONObject().apply {
            put("name", f.name); put("path", f.absolutePath); put("size", f.length())
        }) }
        send(requestId, JSONObject().put("ok", true).put("models", arr))
    }

    @JavascriptInterface fun deleteModel(requestId: String, name: String) {
        send(requestId, JSONObject().put("ok", models.delete(name)))
    }

    @JavascriptInterface fun loadModel(requestId: String, path: String) {
        executor.execute {
            try { NativeEngine.loadModel(path); send(requestId, JSONObject().put("ok", true).put("message", "Model yüklendi.")) }
            catch (e: Throwable) { send(requestId, JSONObject().put("ok", false).put("error", e.message ?: "Model yüklenemedi.")) }
        }
    }

    @JavascriptInterface fun generate(requestId: String, prompt: String, maxTokens: Int) {
        executor.execute {
            try { send(requestId, JSONObject().put("ok", true).put("text", NativeEngine.generate(prompt, maxTokens))) }
            catch (e: Throwable) { send(requestId, JSONObject().put("ok", false).put("error", e.message ?: "Üretim hatası.")) }
        }
    }

    @JavascriptInterface fun stop(requestId: String) { NativeEngine.stop(); send(requestId, JSONObject().put("ok", true)) }

    fun onPicked(requestId: String, uri: android.net.Uri) {
        executor.execute {
            try {
                val file = models.importUri(uri)
                send(requestId, JSONObject().put("ok", true).put("message", "Kuruldu.").put("path", file.absolutePath))
            } catch (e: Throwable) { send(requestId, JSONObject().put("ok", false).put("error", e.message ?: "Dosya kurulamadı.")) }
        }
    }

    private fun send(id: String, obj: JSONObject) {
        webView.post { webView.evaluateJavascript("window.GolgeNativeResult(${JSONObject.quote(id)},${JSONObject.quote(obj.toString())})", null) }
    }
}
