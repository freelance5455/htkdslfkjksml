package com.golge.ai

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

class ModelManager(private val context: Context) {
    private val dir = File(context.filesDir, "models").apply { mkdirs() }

    fun importUri(uri: Uri): File {
        val name = (uri.lastPathSegment ?: "model.gguf").substringAfterLast('/').ifBlank { "model.gguf" }
        require(name.lowercase().endsWith(".gguf")) { "Sadece .gguf dosyası seçebilirsin." }
        val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val out = File(dir, safe)
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Dosya açılamadı." }
            FileOutputStream(out).use { output -> input.copyTo(output, 1024 * 1024) }
        }
        return out
    }

    fun list(): List<File> = dir.listFiles { f -> f.isFile && f.name.endsWith(".gguf", true) }
        ?.sortedBy { it.name.lowercase() } ?: emptyList()

    fun delete(name: String): Boolean = File(dir, name).delete()
}
