package com.golge.ai

object NativeEngine {
    init { System.loadLibrary("golge") }
    external fun loadModel(path: String): Boolean
    external fun generate(prompt: String, maxTokens: Int): String
    external fun stop()
    external fun unload()
}
