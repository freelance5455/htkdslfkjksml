#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include "llama.h"
#include "ggml.h"

static llama_model * g_model = nullptr;
static llama_context * g_ctx = nullptr;
static std::mutex g_mutex;
static bool g_stop = false;

extern "C" JNIEXPORT jboolean JNICALL
Java_com_golge_ai_NativeEngine_loadModel(JNIEnv *env, jobject, jstring jpath) {
    std::lock_guard<std::mutex> lock(g_mutex);
    const char *path = env->GetStringUTFChars(jpath, nullptr);
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    ggml_backend_load_all();
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    g_model = llama_model_load_from_file(path, mp);
    env->ReleaseStringUTFChars(jpath, path);
    if (!g_model) return JNI_FALSE;
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = 4096;
    cp.n_batch = 512;
    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) { llama_model_free(g_model); g_model = nullptr; return JNI_FALSE; }
    return JNI_TRUE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_golge_ai_NativeEngine_generate(JNIEnv *env, jobject, jstring jprompt, jint maxTokens) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_model || !g_ctx) return env->NewStringUTF("Model yüklü değil.");
    const char *prompt = env->GetStringUTFChars(jprompt, nullptr);
    std::string p(prompt);
    env->ReleaseStringUTFChars(jprompt, prompt);
    const llama_vocab *vocab = llama_model_get_vocab(g_model);
    int n = -llama_tokenize(vocab, p.c_str(), (int)p.size(), nullptr, 0, true, true);
    if (n <= 0) return env->NewStringUTF("Prompt işlenemedi.");
    std::vector<llama_token> tokens(n);
    if (llama_tokenize(vocab, p.c_str(), (int)p.size(), tokens.data(), n, true, true) < 0) return env->NewStringUTF("Tokenizasyon hatası.");
    llama_batch batch = llama_batch_get_one(tokens.data(), tokens.size());
    if (llama_decode(g_ctx, batch) != 0) return env->NewStringUTF("Model decode hatası.");
    llama_sampler_chain_params sp = llama_sampler_chain_default_params();
    llama_sampler *sampler = llama_sampler_chain_init(sp);
    llama_sampler_chain_add(sampler, llama_sampler_init_greedy());
    std::string out;
    g_stop = false;
    for (int i = 0; i < maxTokens && !g_stop; ++i) {
        llama_token id = llama_sampler_sample(sampler, g_ctx, -1);
        if (llama_vocab_is_eog(vocab, id)) break;
        char buf[512];
        int len = llama_token_to_piece(vocab, id, buf, sizeof(buf), 0, true);
        if (len > 0) out.append(buf, len);
        batch = llama_batch_get_one(&id, 1);
        if (llama_decode(g_ctx, batch) != 0) break;
    }
    llama_sampler_free(sampler);
    return env->NewStringUTF(out.c_str());
}

extern "C" JNIEXPORT void JNICALL Java_com_golge_ai_NativeEngine_stop(JNIEnv *, jobject) { g_stop = true; }
extern "C" JNIEXPORT void JNICALL Java_com_golge_ai_NativeEngine_unload(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
}
