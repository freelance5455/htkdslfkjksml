'use strict';
/* =========================================================
 * UI.js — интерфейс: HP/энергия, имена, таймер, раунды,
 * объявления (ROUND 1 / FIGHT! / PHASE 2) и DOM-экраны.
 * ========================================================= */

TCF.UI = class {
  constructor(game) {
    this.game = game;
    this.announceText = ''; this.announceSub = ''; this.announceT = 0;
    this.announceDur = 0;
    this.$ = id => document.getElementById(id);
    this.bindMenus();
  }

  /* ---------- DOM-экраны ---------- */

  bindMenus() {
    const g = this.game;
    this.$('btn-start').onclick     = () => g.state.startMatch();
    this.$('btn-characters').onclick = () => this.showScreen('characters');
    this.$('btn-settings').onclick  = () => this.showScreen('settings');
    this.$('btn-chars-back').onclick = () => this.showScreen('menu');
    this.$('btn-set-back').onclick  = () => { g.state.saveSettings(); this.showScreen('menu'); };
    this.$('btn-rematch').onclick   = () => { g.state.startMatch(); };
    this.$('btn-end-menu').onclick  = () => g.state.toMenu();

    // настройки
    const s = g.state.settings;
    this.$('set-difficulty').value = s.difficulty;
    this.$('set-music').checked = s.music;
    this.$('set-shake').checked = s.shake;
    this.$('set-difficulty').onchange = e => { s.difficulty = e.target.value; g.state.saveSettings(); };
    this.$('set-music').onchange = e => { s.music = e.target.checked; g.state.saveSettings(); e.target.checked ? g.music.start() : g.music.stop(); };
    this.$('set-shake').onchange = e => { s.shake = e.target.checked; g.state.saveSettings(); };

    // картинки персонажей на экране CHARACTERS
    const tImg = TCF.AnimLib.img('assets/sprites/tashimara/idle_01.png');
    const fImg = TCF.AnimLib.img('assets/sprites/faceless/idle_01.png');
    if (tImg) this.$('char-img-t').src = tImg.src;
    if (fImg) this.$('char-img-f').src = fImg.src;
  }

  showScreen(name) {
    for (const sc of ['menu', 'characters', 'settings', 'end'])
      this.$('screen-' + sc).classList.toggle('hidden', sc !== name);
  }

  showEndScreen(win) {
    this.$('end-title').textContent = win ? 'YOU WIN' : 'YOU LOSE';
    this.$('end-title').style.color = win ? '#ff3300' : '#8a2be2';
    this.$('end-sub').textContent = win ? 'TASHIMARA WINS' : 'FACELESS WINS';
    this.showScreen('end');
  }

  /* ---------- Объявления ---------- */

  announce(text, sub, dur) {
    this.announceText = text; this.announceSub = sub || '';
    this.announceT = 0; this.announceDur = dur || 1;
  }

  /* ---------- HUD на canvas ---------- */

  updateRounds(wp, we) { this.rounds = [wp, we]; }

  draw(ctx) {
    const g = this.game, c = g.combat;
    if (!c.player) return;
    const C = TCF.CFG, col = C.COLORS;

    // --- Имена ---
    ctx.font = '700 26px "Courier New", monospace';
    ctx.textBaseline = 'top';
    ctx.fillStyle = col.uiText;
    ctx.textAlign = 'left';
    ctx.fillText(C.PLAYER.name, 50, 22);
    ctx.textAlign = 'right';
    ctx.fillText(C.ENEMY.name, C.W - 50, 22);

    // --- Полоски HP ---
    const bw = 460, bh = 22, y0 = 54;
    this.bar(ctx, 50, y0, bw, bh, c.player.hp / C.PLAYER.hp, col.hpPlayer, true);
    this.bar(ctx, C.W - 50 - bw, y0, bw, bh, c.enemy.hp / C.ENEMY.hp, col.hpEnemy, false);

    // --- Энергия ---
    const eh = 10, ey = y0 + bh + 6;
    this.bar(ctx, 50, ey, bw * 0.7, eh, c.player.energy / C.PLAYER.energyMax, col.energy, true);
    this.bar(ctx, C.W - 50 - bw * 0.7, ey, bw * 0.7, eh, c.enemy.energy / C.ENEMY.energyMax, col.energy, false);

    // подписи
    ctx.font = '700 14px "Courier New", monospace';
    ctx.fillStyle = '#bbb';
    ctx.textAlign = 'left';
    ctx.fillText(`HP ${Math.ceil(c.player.hp)}`, 50, y0 + bh + 20);
    ctx.fillText(`ENERGY ${Math.floor(c.player.energy)}${c.player.energy >= C.PLAYER.flame.cost ? '  ⚡CURSED FLAME READY' : ''}`, 50, ey + 14);
    ctx.textAlign = 'right';
    ctx.fillText(`HP ${Math.ceil(c.enemy.hp)}`, C.W - 50, y0 + bh + 20);

    // --- Таймер ---
    ctx.textAlign = 'center';
    ctx.font = '900 44px "Courier New", monospace';
    ctx.fillStyle = this.timer <= 10 ? '#ff4444' : '#ffffff';
    ctx.fillText(Math.ceil(c.timer), C.W / 2, 40);

    // --- Победы в раундах (кружки) ---
    const wins = this.rounds || [0, 0];
    for (let i = 0; i < C.WINS_NEEDED; i++) {
      ctx.beginPath();
      ctx.arc(C.W / 2 - 40 - i * 30, 108, 9, 0, 6.29);
      ctx.fillStyle = i < wins[0] ? col.hpPlayer : 'rgba(255,255,255,0.15)';
      ctx.fill();
      ctx.beginPath();
      ctx.arc(C.W / 2 + 40 + i * 30, 108, 9, 0, 6.29);
      ctx.fillStyle = i < wins[1] ? col.hpEnemy : 'rgba(255,255,255,0.15)';
      ctx.fill();
    }

    // --- Объявление по центру ---
    if (this.announceT < this.announceDur) {
      const p = this.announceT / this.announceDur;
      const scale = 1 + Math.max(0, 0.25 - p) * 2;
      ctx.save();
      ctx.translate(C.W / 2, C.H / 2 - 60);
      ctx.scale(scale, scale);
      ctx.globalAlpha = p > 0.8 ? 1 - (p - 0.8) / 0.2 : 1;
      ctx.textAlign = 'center';
      ctx.font = '900 72px "Courier New", monospace';
      ctx.lineWidth = 8; ctx.strokeStyle = '#000';
      ctx.strokeText(this.announceText, 0, 0);
      ctx.fillStyle = '#ff3300';
      ctx.fillText(this.announceText, 0, 0);
      if (this.announceSub) {
        ctx.font = '700 30px "Courier New", monospace';
        ctx.lineWidth = 6;
        ctx.strokeText(this.announceSub, 0, 70);
        ctx.fillStyle = '#ffb08a';
        ctx.fillText(this.announceSub, 0, 70);
      }
      ctx.restore();
    }
  }

  bar(ctx, x, y, w, h, pct, color, fromLeft) {
    const col = TCF.CFG.COLORS;
    ctx.fillStyle = col.hpBack;
    ctx.fillRect(x, y, w, h);
    ctx.fillStyle = color;
    const fw = w * TCF.clamp(pct, 0, 1);
    // полоска убывает в сторону центра экрана (как в классических файтингах)
    if (fromLeft) ctx.fillRect(x, y, fw, h);
    else ctx.fillRect(x + w - fw, y, fw, h);
    ctx.strokeStyle = 'rgba(0,0,0,0.6)';
    ctx.lineWidth = 2;
    ctx.strokeRect(x, y, w, h);
  }
};
