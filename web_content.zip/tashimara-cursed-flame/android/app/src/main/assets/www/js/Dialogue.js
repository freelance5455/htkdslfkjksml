'use strict';
/* =========================================================
 * Dialogue.js — диалог перед боем (печать текста по буквам).
 * ========================================================= */

TCF.Dialogue = class {
  constructor(game) {
    this.game = game;
    this.lines = [
      { who: 'FACELESS',  text: 'Ты снова решил сражаться со мной?' },
      { who: 'TASHIMARA', text: 'Я вообще-то хотел приготовить ужин.' },
      { who: 'FACELESS',  text: '...' },
      { who: 'TASHIMARA', text: 'Но ладно.' },
    ];
    this.idx = 0;
    this.charIdx = 0;
    this.typing = false;
    this.onDone = null;
    this.timer = null;

    const box = document.getElementById('dlg-box');
    box.addEventListener('pointerdown', e => { e.preventDefault(); this.next(); });
    window.addEventListener('keydown', e => {
      if (!document.getElementById('dialogue').classList.contains('hidden') &&
          (e.code === 'Space' || e.code === 'Enter' || e.code === 'KeyJ')) this.next();
    });
  }

  play(onDone) {
    this.idx = 0;
    this.onDone = onDone;
    document.getElementById('dialogue').classList.remove('hidden');
    this.showLine();
  }

  showLine() {
    const line = this.lines[this.idx];
    document.getElementById('dlg-name').textContent = line.who;
    document.getElementById('dlg-name').style.color =
      line.who === 'TASHIMARA' ? '#ff5500' : '#a86cff';
    document.getElementById('dlg-text').textContent = '';
    this.charIdx = 0;
    this.typing = true;
    clearInterval(this.timer);
    this.timer = setInterval(() => {
      this.charIdx++;
      document.getElementById('dlg-text').textContent = line.text.slice(0, this.charIdx);
      if (this.charIdx >= line.text.length) { clearInterval(this.timer); this.typing = false; }
    }, 28);
  }

  /** Тап/кнопка: допечатать или следующая реплика. */
  next() {
    const line = this.lines[this.idx];
    if (this.typing) {   // мгновенно допечатать
      clearInterval(this.timer);
      this.typing = false;
      document.getElementById('dlg-text').textContent = line.text;
      return;
    }
    this.idx++;
    if (this.idx >= this.lines.length) {
      document.getElementById('dialogue').classList.add('hidden');
      const cb = this.onDone; this.onDone = null;
      if (cb) cb();
    } else {
      this.showLine();
    }
  }
};
