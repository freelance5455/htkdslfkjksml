'use strict';
/* =========================================================
 * main.js — точка входа: загрузка, игровой цикл, музыка.
 *
 * ПЛАВНОСТЬ: симуляция идёт фиксированным шагом 120 Гц
 * (накопитель времени + substepping). На экранах 60/90/120 Гц
 * физика и анимации движутся одинаково плавно, на слабых
 * устройствах не происходит «провалов» сквозь текстуры.
 * ========================================================= */

/* ---------- Процедурная chiptune-музыка (WebAudio) ---------- */
TCF.Music = class {
  constructor() {
    this.ctx = null;
    this.tempoMul = 1;
    this.playing = false;
    this.step = 0;
    this.nextTime = 0;
    this.timer = null;
    this.bass  = [45, 0, 45, 0, 43, 0, 41, 0, 45, 0, 45, 0, 48, 0, 43, 0];
    this.lead  = [69, 0, 72, 0, 76, 72, 69, 0, 67, 0, 71, 0, 74, 71, 67, 0];
  }
  ensure() {
    if (!this.ctx) this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    if (this.ctx.state === 'suspended') this.ctx.resume();
  }
  midi(m) { return 440 * Math.pow(2, (m - 69) / 12); }
  setTempo(m) { this.tempoMul = m; }
  start() {
    if (this.playing) return;
    this.ensure();
    this.playing = true;
    this.step = 0;
    this.nextTime = this.ctx.currentTime + 0.06;
    this.timer = setInterval(() => this.schedule(), 30);
  }
  stop() { this.playing = false; clearInterval(this.timer); }
  schedule() {
    if (!this.playing) return;
    const stepDur = (60 / 132 / 2) / this.tempoMul;   // восьмые на 132 BPM
    while (this.nextTime < this.ctx.currentTime + 0.12) {
      const s = this.step % 16;
      if (this.bass[s]) this.tone(this.midi(this.bass[s]), this.nextTime, stepDur * 0.9, 'square', 0.10);
      if (this.lead[s]) this.tone(this.midi(this.lead[s]), this.nextTime, stepDur * 0.7, 'sawtooth', 0.045);
      this.step++;
      this.nextTime += stepDur;
    }
  }
  tone(freq, t, dur, type, vol) {
    const o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type = type; o.frequency.value = freq;
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g); g.connect(this.ctx.destination);
    o.start(t); o.stop(t + dur + 0.02);
  }
  /** Короткие звуковые эффекты. */
  blip(freq, dur, type = 'square', vol = 0.12) {
    if (!this.game || !this.game.state.settings.music) return;
    this.ensure();
    this.tone(freq, this.ctx.currentTime, dur, type, vol);
  }
  hit()        { this.blip(220, 0.08, 'square', 0.14); this.blip(110, 0.12, 'sawtooth', 0.10); }
  hurt()       { this.blip(160, 0.15, 'sawtooth', 0.12); }
  flameCharge(){ this.blip(330, 0.25, 'sawtooth', 0.08); }
  flameShot()  { this.blip(520, 0.2, 'sawtooth', 0.12); this.blip(260, 0.3, 'square', 0.08); }
  bolt()       { this.blip(440, 0.18, 'triangle', 0.12); }
  hunger()     { this.blip(90, 0.4, 'sine', 0.16); this.blip(180, 0.3, 'triangle', 0.08); }
  phase2()     { this.blip(70, 0.8, 'sawtooth', 0.16); this.blip(140, 0.6, 'square', 0.10); }
};

/* ---------- Игра ---------- */
TCF.Game = class {
  constructor() {
    this.canvas = document.getElementById('game');
    this.ctx = this.canvas.getContext('2d');
    this.ctx.imageSmoothingEnabled = false;

    this.music = new TCF.Music();
    this.audio = this.music;                      // удобный доступ из других модулей
    this.state = new TCF.GameState(this);
    this.music.game = this;
    this.arena = new TCF.Arena();
    this.combat = new TCF.Combat(this);
    this.controls = new TCF.MobileControls();
    this.dialogue = new TCF.Dialogue(this);
    this.ui = null;                               // после загрузки спрайтов
    this.acc = 0;                                 // накопитель фиксированного шага

    this.resize();
    window.addEventListener('resize', () => this.resize());
    // первый звук — только после жеста пользователя (правила браузеров)
    window.addEventListener('pointerdown', () => this.music.ensure(), { once: true });
  }

  resize() {
    // Масштабируем canvas, сохраняя 16:9 (1280x720) с letterbox
    const aw = window.innerWidth, ah = window.innerHeight;
    const scale = Math.min(aw / TCF.CFG.W, ah / TCF.CFG.H);
    this.canvas.style.width = (TCF.CFG.W * scale) + 'px';
    this.canvas.style.height = (TCF.CFG.H * scale) + 'px';
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = TCF.CFG.W * dpr;
    this.canvas.height = TCF.CFG.H * dpr;
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.ctx.imageSmoothingEnabled = false;
  }

  async init() {
    await TCF.AnimLib.load();
    this.ui = new TCF.UI(this);
    this.state.toMenu();
    let last = performance.now();
    const loop = now => {
      // dt в секундах, защита от скачков после сворачивания вкладки
      const dt = Math.min((now - last) / 1000, 0.1);
      last = now;
      this.frame(dt);
      requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);
  }

  frame(dt) {
    const ctx = this.ctx;
    this.state.update(dt);
    this.arena.update(dt);
    if (this.ui) this.ui.update(dt);

    // --- Фиксированный шаг симуляции 120 Гц ---
    const STEP = 1 / 120;
    this.acc = Math.min(this.acc + dt, 0.12);   // не копим больше 120 мс
    const fighting = this.state.screen === 'fight' || this.state.screen === 'end';
    const input = this.controls.consume();      // ввод читаем каждый кадр — без задержек
    let first = true;
    while (this.acc >= STEP) {
      if (fighting) {
        // одиночное нажатие применяем только в первом substep кадра
        const inp = first ? input
          : { held: input.held, tapped: { jump: false, dodge: false, attack: false, special: false } };
        this.combat.step(STEP, inp);
      }
      first = false;
      this.acc -= STEP;
    }

    // --- Отрисовка ---
    ctx.save();
    if (this.combat.shake > 0)
      ctx.translate((Math.random() - 0.5) * this.combat.shake, (Math.random() - 0.5) * this.combat.shake);

    this.arena.draw(ctx);

    if (fighting) {
      this.combat.draw(ctx);
      this.ui.draw(ctx);
    }
    ctx.restore();
  }
};

window.addEventListener('load', () => {
  const game = new TCF.Game();
  TCF.game = game;
  game.init();
});
