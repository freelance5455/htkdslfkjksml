'use strict';
/* =========================================================
 * config.js — все константы игры в одном месте.
 * Персонажи, урон, энергия, физика, арена.
 * ========================================================= */
window.TCF = {};

TCF.CFG = {
  W: 1280, H: 720,              // игровое разрешение
  GROUND: 620,                  // линия пола (ступни персонажей)
  WALL_L: 90, WALL_R: 1190,     // границы арены
  GRAVITY: 2300,
  ROUND_TIME: 60,               // секунд на раунд
  WINS_NEEDED: 2,               // раундов для победы в матче
  HITSTOP: 0.06,                // фриз кадров при попадании (сек)

  PLAYER: {
    name: 'TASHIMARA',
    hp: 100,
    energyMax: 100,
    walkSpeed: 235,
    runSpeed: 385,
    jumpVel: -800,
    // Обычные атаки: комбо attack1 → attack2 → attack3
    // chain — размер окна в КОНЦЕ атаки, в которое можно продолжить комбо
    attacks: {
      attack1: { dmg: 6,  kb: 140, range: 100, active: [0.09, 0.20], dur: 0.32, chain: 0.14 },
      attack2: { dmg: 7,  kb: 160, range: 105, active: [0.09, 0.21], dur: 0.34, chain: 0.16 },
      attack3: { dmg: 13, kb: 460, range: 120, active: [0.15, 0.30], dur: 0.52, chain: 0 },
    },
    // Спецатака CURSED FLAME
    flame: { cost: 40, windup: 0.5, speed: 660, dmg: 22, radius: 36 },
    // Уклонение DODGE: короткая неуязвимость
    dodge: { dur: 0.34, speed: 560, iframes: [0.02, 0.28] },
    // Энергия
    gainOnHit: 9,    // за нанесённый удар
    gainOnHurt: 6,   // за полученный удар
  },

  ENEMY: {
    name: 'FACELESS',
    hp: 100,
    energyMax: 100,
    walkSpeed: 165,
    runSpeed: 285,
    jumpVel: -800,
    attack:  { dmg: 9,  kb: 300, range: 150, active: [0.28, 0.48], dur: 0.85 },
    darkbolt:{ dmg: 8,  speed: 430, radius: 26, cost: 15 },
    hunger:  { cost: 35, cooldown: 9, dur: 5.0, radius: 58, dmg: 8, kb: 380 },
    darkzone:{ cost: 50, cooldown: 13, telegraph: 0.9, dur: 3.2, radius: 155, dps: 15 },
    // PHASE 2 (HP <= 50)
    phase2: {
      speedMul: 1.35,      // скорость движения
      cdMul: 0.6,          // перезарядки способностей
      maxSpheres: 2,       // больше сфер HUNGER
    },
  },

  // Агрессивность ИИ по сложности (интервал решений, сек)
  DIFFICULTY: {
    easy:   { decide: 1.4, aggression: 0.45 },
    normal: { decide: 0.9, aggression: 0.65 },
    hard:   { decide: 0.55, aggression: 0.85 },
  },

  COLORS: {
    hpBack: '#3a1216', hpPlayer: '#ff3300', hpEnemy: '#8a2be2',
    energy: '#ff9900', energyBack: '#26262e',
    uiText: '#ffffff',
  },
};

// Маленькие помощники
TCF.clamp = (v, a, b) => Math.max(a, Math.min(b, v));
TCF.lerp  = (a, b, t) => a + (b - a) * t;
TCF.rand  = (a, b) => a + Math.random() * (b - a);
