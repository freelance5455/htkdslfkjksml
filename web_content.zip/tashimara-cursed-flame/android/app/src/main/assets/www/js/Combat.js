'use strict';
/* =========================================================
 * Combat.js — боевая логика: урон, HP, энергия, уклонения,
 * столкновения, таймер раунда, проверка PHASE 2 и победы.
 * ========================================================= */

TCF.Combat = class {
  constructor(game) {
    this.game = game;
    this.player = null;   // задаётся в resetRound
    this.enemy = null;
    this.flames = [];     // снаряды Ташимары
    this.bolts = [];      // тёмные заряды Безликой
    this.spheres = [];    // HUNGER
    this.zones = [];      // DARK ZONE
    this.sparks = [];
    this.timer = TCF.CFG.ROUND_TIME;
    this.hitstop = 0;
    this.shake = 0;
    this.winner = null;
  }

  resetRound() {
    const P = TCF.CFG.PLAYER, E = TCF.CFG.ENEMY;
    this.player = new TCF.Player(this, 330);
    this.enemy  = new TCF.Enemy(this, 950);
    this.flames = []; this.bolts = []; this.spheres = []; this.zones = []; this.sparks = [];
    this.timer = TCF.CFG.ROUND_TIME;
    this.winner = null;
    this.game.ui.updateRounds(this.game.state.winsPlayer, this.game.state.winsEnemy);
  }

  /** Полный сброс матча (REMATCH). */
  resetMatch() {
    this.game.state.phase2 = false;
    this.game.arena.setIntensity(0);
    this.game.music.setTempo(1);
    this.resetRound();
  }

  /* ---------- Спавн способностей (вызывают Player/Enemy) ---------- */

  spawnFlame(x, y, dir, dmg) { this.flames.push(new TCF.FlameProjectile(x, y, dir, dmg)); }
  spawnBolt(x, y, dir, dmg)  { this.bolts.push(new TCF.DarkBolt(x, y, dir, dmg)); }
  spawnSphere(x)             { this.spheres.push(new TCF.HungerSphere(x)); }
  spawnZone(x)               { this.zones.push(new TCF.DarkZone(x)); }
  spawnSpark(x, y)           { this.sparks.push(new TCF.Spark(x, y)); }

  /* ---------- Удары ---------- */

  /**
   * Ближняя атака: attacker бьёт по target в радиусе range перед собой.
   * Возвращает true, если попали.
   */
  meleeHit(attacker, target, atk) {
    if (target.invuln > 0 || target.state === 'defeat') return false;
    const dx = (target.x - attacker.x) * attacker.facing;
    const dy = Math.abs(target.y - attacker.y);
    if (dx > -10 && dx < atk.range && dy < 130) {
      this.applyDamage(target, atk.dmg, atk.kb * attacker.facing, attacker);
      return true;
    }
    return false;
  }

  applyDamage(target, dmg, kb, from) {
    target.takeHit(dmg, kb, from);
    // энергия
    const C = TCF.CFG;
    if (target === this.enemy) {
      this.player.energy = Math.min(C.PLAYER.energyMax, this.player.energy + C.PLAYER.gainOnHit);
      // PHASE 2 Безликой при HP <= 50
      if (!this.game.state.phase2 && this.enemy.hp <= 50) this.game.state.enterPhase2();
    } else {
      this.enemy.energy = Math.min(C.ENEMY.energyMax, this.enemy.energy + C.PLAYER.gainOnHurt);
    }
    this.spawnSpark(target.x - target.facing * 20, target.y - 85);
    this.hitstop = C.HITSTOP;
    if (this.game.state.settings.shake) this.shake = 6;
  }

  /* ---------- Основной шаг симуляции ---------- */

  step(dt, input) {
    if (this.hitstop > 0) { this.hitstop -= dt; return; }  // фриз кадров
    this.shake = Math.max(0, this.shake - dt * 30);

    const active = this.game.state.fightActive && !this.winner;

    if (active) {
      this.timer -= dt;
      if (this.timer <= 0) { // конец раунда по таймеру — побеждает у кого больше HP
        this.timer = 0;
        return this.finishRound(this.player.hp >= this.enemy.hp ? 'player' : 'enemy');
      }
      this.player.update(dt, input, this.enemy);
      this.enemy.update(dt, this.player);
    } else {
      this.player.update(dt, null, this.enemy);   // анимации вне боя
      this.enemy.update(dt, null);
    }

    // ПЕРСОНАЖИ МОГУТ ПРОХОДИТЬ СКВОЗЬ ДРУГ ДРУГА
    // (разделение тел отключено — можно проходить насквозь и делать cross-up)

    // Снаряды Ташимары
    for (const f of this.flames) {
      f.update(dt);
      if (!f.dead && this.enemy.invuln <= 0 && this.enemy.state !== 'defeat' &&
          Math.abs(this.enemy.x - f.x) < f.radius + 24 && Math.abs((this.enemy.y - 80) - f.y) < 90) {
        this.applyDamage(this.enemy, f.dmg, 300 * f.dir, this.player);
        f.dead = true;
      }
    }
    // Заряды Безликой
    for (const b of this.bolts) {
      b.update(dt);
      if (!b.dead && this.player.invuln <= 0 && this.player.state !== 'defeat' &&
          Math.abs(this.player.x - b.x) < b.radius + 22 && Math.abs((this.player.y - 80) - b.y) < 90) {
        this.applyDamage(this.player, b.dmg, 260 * b.dir, this.enemy);
        b.dead = true;
      }
    }
    // Сферы HUNGER
    for (const s of this.spheres) {
      s.update(dt);
      if (this.player.invuln <= 0 && s.canHit(this.player)) {
        this.applyDamage(this.player, TCF.CFG.ENEMY.hunger.dmg, TCF.CFG.ENEMY.hunger.kb * Math.sign(this.player.x - s.x || 1), this.enemy);
        s.markHit();
      }
    }
    // Зоны DARK ZONE
    for (const z of this.zones) {
      z.update(dt);
      if (z.active && this.player.invuln <= 0 && z.contains(this.player) && z.tick <= 0) {
        this.applyDamage(this.player, TCF.CFG.ENEMY.darkzone.dps * 0.5, 120 * Math.sign(this.player.x - z.x || 1), this.enemy);
        z.tick = 0.5;
      }
    }
    for (const s of this.sparks) s.update(dt);

    this.flames = this.flames.filter(o => !o.dead);
    this.bolts  = this.bolts.filter(o => !o.dead);
    this.spheres = this.spheres.filter(o => !o.dead);
    this.zones  = this.zones.filter(o => !o.dead);
    this.sparks = this.sparks.filter(o => !o.dead);

    // Проверка поражения
    if (active) {
      if (this.enemy.hp <= 0) this.finishRound('player');
      else if (this.player.hp <= 0) this.finishRound('enemy');
    }
  }

  separate() {
    const p = this.player, e = this.enemy;
    if (p.state === 'defeat' || e.state === 'defeat') return;
    const dx = e.x - p.x, minDist = 46;
    if (Math.abs(dx) < minDist && Math.abs(p.y - e.y) < 120) {
      const push = (minDist - Math.abs(dx)) / 2 * Math.sign(dx || 1);
      p.x = TCF.clamp(p.x - push, TCF.CFG.WALL_L, TCF.CFG.WALL_R);
      e.x = TCF.clamp(e.x + push, TCF.CFG.WALL_L, TCF.CFG.WALL_R);
    }
  }

  finishRound(winner) {
    if (this.winner) return;
    this.winner = winner;
    const loser = winner === 'player' ? this.enemy : this.player;
    loser.hp = Math.max(0, loser.hp);
    loser.state = 'defeat';
    loser.stateT = 0;
    const winAnim = winner === 'player' ? this.player : this.enemy;
    winAnim.state = 'victory';
    winAnim.stateT = 0;
    setTimeout(() => this.game.state.onRoundEnd(winner), 1600);
  }

  /** Финальная анимация после матча (победная поза / поражение). */
  playOutro(winner) {
    if (winner === 'player') { this.player.state = 'victory'; this.enemy.state = 'defeat'; }
    else { this.enemy.state = 'victory'; this.player.state = 'defeat'; }
    this.player.stateT = 0; this.enemy.stateT = 0;
  }

  draw(ctx) {
    for (const z of this.zones) z.draw(ctx);
    for (const s of this.spheres) s.draw(ctx);
    for (const f of this.flames) f.draw(ctx);
    for (const b of this.bolts) b.draw(ctx);
    this.enemy.draw(ctx);
    this.player.draw(ctx);
    for (const s of this.sparks) s.draw(ctx);
  }
};
