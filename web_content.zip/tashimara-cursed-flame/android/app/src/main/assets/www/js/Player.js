'use strict';
/* =========================================================
 * Player.js — Ташимара (управляет игрок).
 *
 * Состояния (state):
 *   idle | move | jump | attack1/2/3 (комбо) | flame | dodge
 *   hurt | victory | defeat
 *
 * Плавность: разгон/торможение через экспоненциальное
 * сглаживание скорости (не мгновенный vx).
 * ========================================================= */

TCF.Player = class {
  constructor(combat, x) {
    this.combat = combat;
    const C = TCF.CFG.PLAYER;
    this.x = x; this.y = TCF.CFG.GROUND;
    this.vx = 0; this.vy = 0;
    this.facing = 1;
    this.hp = C.hp;
    this.energy = 30;             // немного стартовой энергии
    this.state = 'idle';
    this.stateT = 0;
    this.invuln = 0;
    this.onGround = true;
    this.attackChain = 0;         // 0..3 — этап комбо
    this.attackHitDone = false;
    this.anim = new TCF.Animator('tashimara', 'idle', 8);
  }

  /* Плавное приближение скорости к целевой. */
  approach(target, dt, rate = 14) {
    this.vx += (target - this.vx) * Math.min(1, rate * dt);
  }

  /* ---------- Входные команды ---------- */

  update(dt, input, enemy) {
    const C = TCF.CFG.PLAYER;
    this.stateT += dt;
    this.invuln = Math.max(0, this.invuln - dt);
    if (enemy) this.facing = enemy.x >= this.x ? 1 : -1;

    const busy = ['attack1', 'attack2', 'attack3', 'flame', 'dodge', 'hurt', 'victory', 'defeat']
      .includes(this.state);

    if (!busy) {
      // Движение
      let move = 0;
      if (input) {
        if (input.held.left) move -= 1;
        if (input.held.right) move += 1;
      }
      const speed = this.onGround ? C.runSpeed : C.walkSpeed * 1.15;
      this.approach(move * speed, dt);

      // Состояние по положению
      if (!this.onGround) {
        this.state = 'jump';               // ИСПРАВЛЕНО: анимация прыжка больше не прерывается
        this.anim.set('jump', 10);
      } else if (Math.abs(this.vx) > 30) {
        this.state = 'move';
        this.anim.set('run', 12);
      } else {
        this.state = 'idle';
        this.anim.set('idle', 8);
      }

      // Прыжок
      if (input && input.tapped.jump && this.onGround) {
        this.vy = C.jumpVel;
        this.onGround = false;
        this.state = 'jump';
        this.anim.set('jump', 10, { force: true });
        this.combat.game.audio.blip(500, 0.08, 'triangle', 0.06);
      }
      // Уклонение DODGE — короткая неуязвимость
      if (input && input.tapped.dodge && this.onGround) {
        this.state = 'dodge';
        this.stateT = 0;
        const dir = move !== 0 ? move : this.facing;
        this.vx = dir * C.dodge.speed;     // рывок — импульс, дальше торможение
        this.anim.set('dodge', 18, { loop: false });
      }
      // Комбо-атаки ATTACK
      if (input && input.tapped.attack && this.onGround) {
        this.startAttack('attack1', C.attacks.attack1);
      }
      // Спецатака CURSED FLAME
      if (input && input.tapped.special && this.energy >= C.flame.cost && this.onGround) {
        this.energy -= C.flame.cost;
        this.state = 'flame';
        this.stateT = 0;
        this.vx = 0;
        this.attackHitDone = false;
        this.anim.set('flame', 14, { loop: false });
        this.combat.game.audio.flameCharge();
      }
    } else {
      // Логика текущего состояния
      if (this.state === 'attack1' || this.state === 'attack2' || this.state === 'attack3') {
        this.updateAttack(dt, input, C);
      } else if (this.state === 'flame') {
        this.updateFlame(dt, C);
      } else if (this.state === 'dodge') {
        this.approach(0, dt, 5);           // плавное затухание рывка
        const [a, b] = C.dodge.iframes;
        this.invuln = (this.stateT >= a && this.stateT <= b) ? 0.05 : this.invuln;
        if (this.stateT >= C.dodge.dur) this.state = 'idle';
      } else if (this.state === 'hurt') {
        this.vx *= Math.exp(-6 * dt);      // плавное затухание отброса (не зависит от FPS)
        if (this.stateT >= 0.42) this.state = 'idle';
      }
      // victory/defeat — застыть
    }

    // Физика
    this.vy += TCF.CFG.GRAVITY * dt;
    this.x += this.vx * dt;
    this.y += this.vy * dt;
    if (this.y >= TCF.CFG.GROUND) {
      this.y = TCF.CFG.GROUND;
      this.vy = 0;
      if (!this.onGround && this.state === 'jump') this.state = 'idle';
      this.onGround = true;
    }
    this.x = TCF.clamp(this.x, TCF.CFG.WALL_L, TCF.CFG.WALL_R);
    this.anim.update(dt);
  }

  startAttack(name, atk) {
    this.state = name;
    this.stateT = 0;
    this.attackHitDone = false;
    this.attackData = atk;
    this.vx = 0;
    this.anim.set(name, 14, { loop: false, force: true });
  }

  updateAttack(dt, input, C) {
    const atk = this.attackData;
    // Активные кадры — проверяем попадание один раз
    if (!this.attackHitDone && this.stateT >= atk.active[0] && this.stateT <= atk.active[1]) {
      if (this.combat.meleeHit(this, this.combat.enemy, atk)) {
        this.attackHitDone = true;
        this.combat.game.audio.hit();
      }
    }
    // Цепочка комбо: ATTACK в окне chain
    if (atk.chain > 0 && this.stateT >= atk.dur - atk.chain && input && input.tapped.attack) {
      const next = this.state === 'attack1' ? 'attack2' : 'attack3';
      return this.startAttack(next, C.attacks[next]);
    }
    if (this.stateT >= atk.dur) { this.state = 'idle'; this.vx = 0; }
  }

  updateFlame(dt, C) {
    // Задержка (windup) — противник может успеть увернуться
    if (!this.attackHitDone && this.stateT >= C.flame.windup) {
      this.attackHitDone = true;
      this.combat.spawnFlame(this.x + this.facing * 60, this.y - 85, this.facing, C.flame.dmg);
      this.combat.game.audio.flameShot();
    }
    if (this.stateT >= 0.85) this.state = 'idle';
  }

  takeHit(dmg, kb, from) {
    if (this.state === 'defeat') return;
    this.hp = Math.max(0, this.hp - dmg);
    this.state = 'hurt';
    this.stateT = 0;
    this.vx = kb;
    this.invuln = 0.35;
    this.anim.set('hurt', 12, { loop: false, force: true });
    this.combat.game.audio.hurt();
    if (this.hp <= 0) { this.state = 'defeat'; this.anim.set('defeat', 10, { loop: false, holdLast: true, force: true }); }
  }

  draw(ctx) {
    // Мигание во время неуязвимости
    if (this.invuln > 0 && this.state !== 'dodge' && Math.floor(this.invuln * 20) % 2 === 0) return;
    if (this.state === 'victory') this.anim.set('victory', 6);
    if (this.state === 'defeat' && this.anim.animName !== 'defeat')
      this.anim.set('defeat', 10, { loop: false, holdLast: true });
    const h = TCF.AnimLib.data.tashimara.height;
    this.anim.draw(ctx, this.x, this.y, this.facing < 0, h);
  }
};
