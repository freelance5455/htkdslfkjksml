'use strict';
/* =========================================================
 * Animations.js — загрузка sprite sheets и проигрывание кадров.
 *
 * AnimLib  : грузит manifest.json и все PNG один раз.
 * Animator : проигрывает список кадров с нужным FPS,
 *            рисует с масштабом по высоте (единый масштаб персонажей).
 * ========================================================= */

TCF.AnimLib = {
  data: null,
  images: {},

  /** Загрузить манифест и все изображения. */
  load() {
    return fetch('assets/sprites/manifest.json')
      .then(r => r.json())
      .then(data => {
        this.data = data;
        const urls = new Set();
        const walk = o => {
          for (const k in o) {
            if (Array.isArray(o[k])) o[k].forEach(u => urls.add(u));
            else if (typeof o[k] === 'object') walk(o[k]);
          }
        };
        walk(data);
        return Promise.all([...urls].map(u => new Promise(res => {
          const im = new Image();
          im.onload = () => { this.images[u] = im; res(); };
          im.onerror = () => { console.warn('Не найден спрайт:', u); this.images[u] = im; res(); };
          im.src = u;
        })));
      });
  },

  img(url) { return this.images[url]; },
};

TCF.Animator = class {
  /**
   * @param {string} person   'tashimara' | 'faceless'
   * @param {string} animName ключ анимации из манифеста
   */
  constructor(person, animName, fps = 10, opts = {}) {
    this.person = person;
    this.fps = fps;
    this.loop = opts.loop !== false;
    this.holdLast = !!opts.holdLast;
    this.set(animName, fps, opts);
  }

  /** Переключить анимацию (без сброса, если та же самая). */
  set(animName, fps, opts = {}) {
    if (this.animName === animName && !opts.force) return;
    const person = TCF.AnimLib.data[this.person];
    const frames = person.animations[animName];
    if (!frames) { console.warn('Нет анимации', this.person, animName); return; }
    this.animName = animName;
    this.frames = frames;
    this.fps = fps || this.fps;
    this.loop = opts.loop !== false;
    this.holdLast = !!opts.holdLast;
    this.frame = 0;
    this.t = 0;
    this.done = false;
  }

  update(dt) {
    if (this.done) return;
    this.t += dt;
    const step = 1 / this.fps;
    while (this.t >= step) {
      this.t -= step;
      this.frame++;
      if (this.frame >= this.frames.length) {
        if (this.loop) this.frame = 0;
        else if (this.holdLast) { this.frame = this.frames.length - 1; this.done = true; }
        else { this.done = true; }
      }
    }
  }

  /**
   * Рисуем кадр. (x, feetY) — точка между ступнями персонажа.
   * flip — зеркалим по горизонтали, height — высота спрайта в игре.
   */
  draw(ctx, x, feetY, flip, height) {
    const im = TCF.AnimLib.img(this.frames[this.frame]);
    if (!im || !im.width) return;
    const s = height / im.height;
    const w = im.width * s, h = im.height * s;
    ctx.save();
    ctx.translate(x, feetY);
    if (flip) ctx.scale(-1, 1);
    ctx.drawImage(im, -w / 2, -h, w, h);
    ctx.restore();
  }
};
