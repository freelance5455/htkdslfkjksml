'use strict';
/* =========================================================
 * Enemy.js — Безликая (FACELESS). Искусственный интеллект.
 *
 * Стиль боя: контроль пространства и мощные спецатаки.
 *   attack    — широкая ближняя атака
 *   darkbolt  — дальний энергетический заряд
 *   hunger    — тёмная сфера на арене
 *   darkzone  — большая область (только PHASE 2)
 *
 * PHASE 2 (HP <= 50): быстрее, способности чаще, 2 сферы,
 * появляется анимация phase2.
 * ========================================================= */

TCF.Enemy = class {
  constructor(combat, x) {
    this.combat = combat;
    const C = TCF.CFG.ENEMY;
    this.x = x; this.y = TCF.CFG.GROUND;
    this.vx = 0; this.vy = 0;
    this.facing = -1;
    this.hp = C.hp;
    this.energy = 40;
    this.state = 'idle';
    this.stateT = 0;
    this.invuln = 0;
    this.onGround = true;
    this.phase2 = false;
    this.decideT = 1.0;
    this.cool = { attack: 0, bolt: 0, hunger: 2.5, zone: 5 };
    this.attackHitDone = false;
    this.anim = new TCF.Animator('faceless', 'idle', 8);
  }

  /** Включение PHASE 2 (вызывает GameState). */
  onPhase2() {
    this.phase2 = true;
    this.state = 'phase2';
    this.stateT = 0;
    this.vx = 0;
    this.anim.set('phase2', 12, { loop: false });
    this.combat.game.audio.phase2();
  }

  get speedMul() { return this.phase2 ? TCF.CFG.ENEMY.phase2.speedMul : 1; }
  get cdMul()     { return this.phase2 ? TCF.CFG.ENEMY.phase2.cdMul : 1; }
  get maxSpheres(){ return this.phase2 ? TCF.CFG.ENEMY.phase2.maxSpheres : 1; }

  update(dt, player) {
    const C = TCF.CFG.ENEMY;
    this.stateT += dt;
    this.invuln = Math.max(0, this.invuln - dt);
    this.regenEnergy(dt);
    if (player) this.facing = player.x >= this.x ? 1 : -1;
    for (const k in this.cool) this.cool[k] = Math.max(0, this.cool[k] - dt);

    const busy = ['attack', 'darkattack', 'hunger', 'hurt', 'phase2', 'victory', 'defeat']
      .includes(this.state);

    if (!busy && player) {
      const diff = TCF.CFG.DIFFICULTY[this.combat.game.state.settings.difficulty] || TCF.CFG.DIFFICULTY.normal;
      this.decideT -= dt;
      const dist = Math.abs(player.x - this.x);
      const dir = Math.sign(player.x - this.x || 1);

      // --- Принятие решения ---
      if (this.decideT <= 0) {
        this.decideT = diff.decide * TCF.rand(0.7, 1.3) * this.cdMul;
        this.decide(dist, dir, player, diff);
      }
      // Продолжаем задуманное движение (плавный разгон)
      const target = (this.moveDir || 0) * C.walkSpeed * this.speedMul;
      this.vx += (target - this.vx) * Math.min(1, 10 * dt);
      if (Math.abs(this.vx) > 25) this.anim.set('run', 10);
      else this.anim.set('idle', 8);
    } else if (this.state === 'attack') {
      this.updateAttack(dt, C, player);
    } else if (this.state === 'darkattack') {
      if (!this.attackHitDone && this.stateT >= 0.5) {
        this.attackHitDone = true;
        this.combat.spawnBolt(this.x + this.facing * 50, this.y - 95, this.facing, C.darkbolt.dmg);
        this.combat.game.audio.bolt();
      }
      if (this.stateT >= 0.8) this.state = 'idle';
    } else if (this.state === 'hunger') {
      if (!this.attackHitDone && this.stateT >= 0.55) {
        this.attackHitDone = true;
        // сфера появляется между Безликой и игроком
        this.combat.spawnSphere(player.x + TCF.rand(-40, 40));
        this.combat.game.audio.hunger();
      }
      if (this.stateT >= 1.0) this.state = 'idle';
    } else if (this.state === 'hurt') {
      this.vx *= Math.exp(-6 * dt);      // плавное затухание отброса
      if (this.stateT >= 0.45) this.state = 'idle';
    } else if (this.state === 'phase2') {
      if (this.stateT >= 0.9) this.state = 'idle';
    }
    // victory/defeat — застыть

    // Физика
    this.vy += TCF.CFG.GRAVITY * dt;
    this.x += this.vx * dt;
    this.y += this.vy * dt;
    if (this.y >= TCF.CFG.GROUND) { this.y = TCF.CFG.GROUND; this.vy = 0; this.onGround = true; }
    this.x = TCF.clamp(this.x, TCF.CFG.WALL_L, TCF.CFG.WALL_R);
    this.anim.update(dt);
  }

  /** Выбор действия ИИ в зависимости от дистанции и перезарядок. */
  decide(dist, dir, player, diff) {
    const C = TCF.CFG.ENEMY;
    this.moveDir = 0;
    const roll = Math.random();

    // Сфера HUNGER: если игрок держит дистанцию или сфер ещё нет
    if (this.cool.hunger <= 0 && this.energy >= C.hunger.cost &&
        this.combat.spheres.length < this.maxSpheres &&
        (dist > 260 || roll < 0.3)) {
      this.energy -= C.hunger.cost;
      this.cool.hunger = C.hunger.cooldown * this.cdMul;
      return this.cast('hunger', 10);
    }
    // DARK ZONE (только фаза 2): под игрока
    if (this.phase2 && this.cool.zone <= 0 && this.energy >= C.darkzone.cost && dist < 420) {
      this.energy -= C.darkzone.cost;
      this.cool.zone = C.darkzone.cooldown * this.cdMul;
      this.combat.spawnZone(player.x);       // область появляется под игроком
      this.combat.game.audio.hunger();
      return this.cast('darkattack', 8);
    }
    // Дальний заряд
    if (this.cool.bolt <= 0 && this.energy >= C.darkbolt.cost && dist > 330 && roll < diff.aggression) {
      this.energy -= C.darkbolt.cost;
      this.cool.bolt = 2.2 * this.cdMul;
      return this.cast('darkattack', 8);
    }
    // Ближняя широкая атака
    if (dist < C.attack.range + 30 && this.cool.attack <= 0 && roll < diff.aggression + 0.25) {
      this.cool.attack = 1.1 * this.cdMul;
      return this.cast('attack', 9);
    }
    // Движение: держим комфортную дистанцию
    if (dist > 300) this.moveDir = dir;                    // приближаемся
    else if (dist < 150) this.moveDir = -dir;              // отходим
    else if (roll < 0.4) this.moveDir = dir;               // иногда давим
  }

  cast(stateName, fps) {
    this.state = stateName;
    this.stateT = 0;
    this.attackHitDone = false;
    this.vx = 0;
    // DARK ZONE появляется сразу при касте (телеграф зоны виден игроку)
    if (stateName === 'darkattack' && this.phase2 && this.cool.zone > 12) { /* noop */ }
    this.anim.set(stateName, fps, { loop: false });
  }

  updateAttack(dt, C, player) {
    if (!this.attackHitDone && this.stateT >= C.attack.active[0] && this.stateT <= C.attack.active[1]) {
      if (player && this.combat.meleeHit(this, player, C.attack)) {
        this.attackHitDone = true;
        this.combat.game.audio.hit();
      }
    }
    if (this.stateT >= C.attack.dur) this.state = 'idle';
  }

  takeHit(dmg, kb, from) {
    if (this.state === 'defeat') return;
    this.hp = Math.max(0, this.hp - dmg);
    // ИСПРАВЛЕНО: если удар прервал каст до выстрела — возвращаем энергию
    if (!this.attackHitDone) {
      const C = TCF.CFG.ENEMY;
      if (this.state === 'darkattack') this.energy += C.darkbolt.cost;
      if (this.state === 'hunger') this.energy += C.hunger.cost;
    }
    // лёгкая стойкость: не прерываем атаки в PHASE 2 с вероятностью 50%
    const armored = this.phase2 && (this.state === 'attack') && Math.random() < 0.5;
    if (!armored) {
      this.state = 'hurt';
      this.stateT = 0;
      this.anim.set('hurt', 12, { loop: false });
    }
    this.vx = kb * 0.7;
    this.invuln = 0.3;
    this.combat.game.audio.hurt();
    if (this.hp <= 0) { this.state = 'defeat'; this.anim.set('defeat', 10, { loop: false, holdLast: true }); }
  }

  /** Медленный реген энергии, чтобы бой не застревал. */
  regenEnergy(dt) {
    this.energy = Math.min(TCF.CFG.ENEMY.energyMax, this.energy + dt * 3);
  }

  draw(ctx) {
    if (this.invuln > 0 && Math.floor(this.invuln * 20) % 2 === 0 && this.state !== 'defeat') return;
    if (this.state === 'victory') this.anim.set('idle', 8);
    if (this.state === 'defeat' && this.anim.animName !== 'defeat')
      this.anim.set('defeat', 10, { loop: false, holdLast: true });
    const h = TCF.AnimLib.data.faceless.height;
    this.anim.draw(ctx, this.x, this.y, this.facing < 0, h);
  }
};
