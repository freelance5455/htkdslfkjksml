'use strict';
/* =========================================================
 * Arena.js — фон «PURGATORY».
 * Полностью 2D: тёмное небо, разрушенные платформы, огромные
 * цепи, энергетические разломы, частицы, далёкие развалины.
 * intensity 0..1 — обычная фаза / PHASE 2 (ярче, быстрее).
 *
 * ОПТИМИЗАЦИЯ: статичная часть фона (небо, развалины, пол)
 * пререндерится в offscreen-canvas один раз на фазу —
 * это убирает дорогие градиенты и сотни fillRect за кадр.
 * ========================================================= */

TCF.Arena = class {
  constructor() {
    this.intensity = 0;
    this.t = 0;
    this.bgCache = {};            // {0: canvas, 1: canvas} — статика по фазам
    this.stars = this.makeStars(90);
    this.ruins = this.makeRuins();
    this.chains = this.makeChains(5);
    this.rifts = this.makeRifts(6);
    this.embers = this.makeEmbers(45);
    this.cracks = this.makeCracks(14);
  }

  seeded(seed) { let s = seed; return () => (s = (s * 16807) % 2147483647) / 2147483647; }

  makeStars(n) {
    const r = this.seeded(11);
    return Array.from({ length: n }, () => ({
      x: r() * TCF.CFG.W, y: r() * 380, s: 1 + r() * 2, tw: r() * 6.28,
    }));
  }

  makeRuins() {
    // далёкие разрушенные измерения — силуэты башен и обломков
    const r = this.seeded(77);
    const layers = [];
    for (let L = 0; L < 3; L++) {
      const items = [];
      let x = -50;
      while (x < TCF.CFG.W + 100) {
        const w = 40 + r() * 120, h = 60 + r() * (170 - L * 40);
        items.push({ x, w, h, tilt: (r() - 0.5) * 0.12, broken: r() > 0.5 });
        x += w + 20 + r() * 90;
      }
      layers.push(items);
    }
    return layers;
  }

  makeChains(n) {
    const r = this.seeded(1234);
    return Array.from({ length: n }, () => ({
      x: r() * TCF.CFG.W, y0: -30, len: 250 + r() * 320,
      sway: r() * 6.28, amp: 8 + r() * 18, speed: 0.3 + r() * 0.5,
      scale: 0.7 + r() * 0.9,
    }));
  }

  makeRifts(n) {
    const r = this.seeded(555);
    return Array.from({ length: n }, () => ({
      x: 80 + r() * (TCF.CFG.W - 160), y: 430 + r() * 150,
      w: 50 + r() * 120, h: 8 + r() * 26, hue: r() > 0.5 ? '255,60,20' : '150,40,255',
      phase: r() * 6.28,
    }));
  }

  makeEmbers(n) {
    return Array.from({ length: n }, () => this.newEmber(true));
  }

  newEmber(anywhere) {
    return {
      x: TCF.rand(0, TCF.CFG.W),
      y: anywhere ? TCF.rand(200, TCF.CFG.GROUND) : TCF.CFG.GROUND + TCF.rand(-10, 10),
      vx: TCF.rand(-18, 18), vy: TCF.rand(-46, -14),
      s: TCF.rand(1.5, 4), life: TCF.rand(3, 7),
    };
  }

  makeCracks(n) {
    const r = this.seeded(909);
    return Array.from({ length: n }, () => ({
      x: r() * TCF.CFG.W, y: TCF.CFG.GROUND + 8 + r() * 60,
      len: 30 + r() * 90, ang: (r() - 0.5) * 0.5,
    }));
  }

  setIntensity(v) { this.intensity = v; }

  update(dt) {
    this.t += dt * (1 + this.intensity * 0.6);
    for (const e of this.embers) {
      e.x += e.vx * dt; e.y += e.vy * dt; e.life -= dt;
      if (e.life <= 0 || e.y < 150) Object.assign(e, this.newEmber(false));
    }
  }

  /* ---------- Статичный слой: рисуем ОДИН РАЗ в offscreen ---------- */

  getStaticLayer(key) {
    if (this.bgCache[key]) return this.bgCache[key];
    const { W, H, GROUND } = TCF.CFG;
    const k = key;
    const cv = document.createElement('canvas');
    cv.width = W; cv.height = H;
    const ctx = cv.getContext('2d');

    // Небо
    const sky = ctx.createLinearGradient(0, 0, 0, H);
    sky.addColorStop(0, `rgb(${8 + k * 18},${6},${14 + k * 8})`);
    sky.addColorStop(0.6, `rgb(${26 + k * 30},${10 + k * 6},${26 + k * 10})`);
    sky.addColorStop(1, '#1a0d12');
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, W, H);

    // Развалины (3 слоя параллакса)
    this.ruins.forEach((items, L) => {
      const shade = 16 + L * 9 + k * 10;
      ctx.fillStyle = `rgb(${shade + 6},${shade},${shade + 10})`;
      for (const it of items) {
        ctx.save();
        ctx.translate(it.x + it.w / 2, GROUND - 60);
        ctx.rotate(it.tilt);
        ctx.fillRect(-it.w / 2, -it.h, it.w, it.h);
        if (it.broken) {
          ctx.fillRect(-it.w / 2, -it.h - 12, it.w * 0.4, 12);
          ctx.fillRect(it.w * 0.2, -it.h - 6, it.w * 0.3, 6);
        }
        ctx.restore();
      }
    });

    // Платформа
    const gr = ctx.createLinearGradient(0, GROUND, 0, H);
    gr.addColorStop(0, `rgb(${46 + k * 26},${30},${36})`);
    gr.addColorStop(1, '#120a10');
    ctx.fillStyle = gr;
    ctx.fillRect(0, GROUND, W, H - GROUND);
    ctx.fillStyle = `rgb(${70 + k * 40},${44},${52})`;
    ctx.fillRect(0, GROUND, W, 6);

    // Трещины
    ctx.strokeStyle = 'rgba(10,6,10,0.8)';
    ctx.lineWidth = 2;
    for (const c of this.cracks) {
      ctx.beginPath();
      ctx.moveTo(c.x, c.y);
      ctx.lineTo(c.x + Math.cos(c.ang) * c.len, c.y + Math.sin(c.ang) * c.len * 0.3 + 4);
      ctx.stroke();
    }

    this.bgCache[key] = cv;
    return cv;
  }

  /* ---------- Кадр ---------- */

  draw(ctx) {
    const { W, H, GROUND } = TCF.CFG;
    const k = this.intensity;

    // статика — один drawImage вместо сотен примитивов
    ctx.drawImage(this.getStaticLayer(k < 0.5 ? 0 : 1), 0, 0);

    // звёзды (мигание — дешёвые fillRect)
    ctx.fillStyle = '#cfd8ff';
    for (const s of this.stars) {
      ctx.globalAlpha = 0.35 + 0.3 * Math.sin(this.t * 2 + s.tw);
      ctx.fillRect(s.x, s.y, s.s, s.s);
    }
    ctx.globalAlpha = 1;

    // Огромные цепи (качаются)
    for (const c of this.chains) {
      const sway = Math.sin(this.t * c.speed + c.sway) * c.amp * (1 + k);
      ctx.strokeStyle = `rgba(${40 + k * 30},${38},${48},0.9)`;
      ctx.lineWidth = 7 * c.scale;
      ctx.beginPath();
      ctx.moveTo(c.x, c.y0);
      ctx.quadraticCurveTo(c.x + sway, c.y0 + c.len / 2, c.x + sway * 1.6, c.y0 + c.len);
      ctx.stroke();
      ctx.lineWidth = 2.5 * c.scale;
      ctx.strokeStyle = 'rgba(90,80,105,0.85)';
      for (let i = 0; i < c.len; i += 16 * c.scale) {
        const tt = i / c.len;
        const lx = c.x + sway * (1.6 * tt * tt + tt * (1 - tt) * 2);
        ctx.beginPath();
        ctx.ellipse(lx, c.y0 + i, 5 * c.scale, 8 * c.scale, sway * 0.01, 0, 6.29);
        ctx.stroke();
      }
    }

    // Энергетические разломы (пульсируют)
    for (const r of this.rifts) {
      const pulse = 0.55 + 0.45 * Math.sin(this.t * 3 + r.phase);
      const glow = ctx.createRadialGradient(r.x, r.y, 0, r.x, r.y, r.w);
      glow.addColorStop(0, `rgba(${r.hue},${0.35 * pulse + k * 0.25})`);
      glow.addColorStop(1, `rgba(${r.hue},0)`);
      ctx.fillStyle = glow;
      ctx.fillRect(r.x - r.w, r.y - r.w, r.w * 2, r.w * 2);
      ctx.fillStyle = `rgba(${r.hue},${0.5 * pulse + k * 0.3})`;
      ctx.fillRect(r.x - r.w / 2, r.y, r.w, r.h * 0.5);
    }

    // Частицы (угли)
    for (const e of this.embers) {
      ctx.globalAlpha = Math.min(1, e.life) * (0.5 + k * 0.4);
      ctx.fillStyle = k > 0.5 ? '#ff5522' : '#ff7733';
      ctx.fillRect(e.x, e.y, e.s, e.s);
    }
    ctx.globalAlpha = 1;
  }
};
