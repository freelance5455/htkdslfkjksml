'use strict';
/* =========================================================
 * Abilities.js — всё, что летает и висит на арене:
 *
 * FlameProjectile : CURSED FLAME Ташимары (снаряд огня)
 * DarkBolt        : дальняя энергетическая атака Безликой
 * HungerSphere    : тёмная сфера (стоит на арене, бьёт при приближении)
 * DarkZone        : большая область тёмной энергии (фаза 2)
 * Spark           : вспышка при попадании
 * ========================================================= */

/* --- CURSED FLAME: поток Проклятого Огня --- */
TCF.FlameProjectile = class {
  constructor(x, y, dir, dmg) {
    this.x = x; this.y = y; this.dir = dir;
    this.dmg = dmg;
    this.speed = TCF.CFG.PLAYER.flame.speed;
    this.radius = TCF.CFG.PLAYER.flame.radius;
    this.dead = false;
    this.animFrames = TCF.AnimLib.data.fx.flameProjectile;
    this.frame = 0; this.t = 0;
  }
  update(dt) {
    this.x += this.dir * this.speed * dt;
    this.t += dt;
    this.frame = Math.floor(this.t * 16) % this.animFrames.length;
    if (this.x < 40 || this.x > TCF.CFG.W - 40) this.dead = true;
  }
  draw(ctx) {
    const im = TCF.AnimLib.img(this.animFrames[this.frame]);
    if (!im || !im.width) return;
    const w = this.radius * 3.2, h = this.radius * 2;
    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.scale(this.dir, 1);
    // свечение под снарядом
    const g = ctx.createRadialGradient(0, 0, 2, 0, 0, w * 0.7);
    g.addColorStop(0, 'rgba(255,120,20,0.5)');
    g.addColorStop(1, 'rgba(255,60,0,0)');
    ctx.fillStyle = g;
    ctx.fillRect(-w, -w, w * 2, w * 2);
    ctx.drawImage(im, -w * 0.4, -h / 2, w, h);
    ctx.restore();
  }
};

/* --- Тёмный заряд Безликой --- */
TCF.DarkBolt = class {
  constructor(x, y, dir, dmg) {
    this.x = x; this.y = y; this.dir = dir; this.dmg = dmg;
    this.speed = TCF.CFG.ENEMY.darkbolt.speed;
    this.radius = TCF.CFG.ENEMY.darkbolt.radius;
    this.dead = false;
    this.frames = TCF.AnimLib.data.fx.hungerSphere;
    this.frame = 0; this.t = 0;
  }
  update(dt) {
    this.x += this.dir * this.speed * dt;
    this.t += dt;
    this.frame = Math.floor(this.t * 14) % this.frames.length;
    if (this.x < 30 || this.x > TCF.CFG.W - 30) this.dead = true;
  }
  draw(ctx) {
    const im = TCF.AnimLib.img(this.frames[this.frame]);
    if (!im || !im.width) return;
    const s = this.radius * 3;
    ctx.save();
    ctx.globalAlpha = 0.85;
    ctx.drawImage(im, this.x - s / 2, this.y - s / 2, s, s);
    ctx.restore();
  }
};

/* --- HUNGER: тёмная сфера на арене --- */
TCF.HungerSphere = class {
  constructor(x) {
    this.x = TCF.clamp(x, TCF.CFG.WALL_L + 40, TCF.CFG.WALL_R - 40);
    this.y = TCF.CFG.GROUND - 46;
    this.radius = TCF.CFG.ENEMY.hunger.radius;
    this.life = TCF.CFG.ENEMY.hunger.dur;
    this.hitCooldown = 0;
    this.dead = false;
    this.frames = TCF.AnimLib.data.fx.hungerSphere;
    this.frame = 0; this.t = 0;
  }
  update(dt) {
    this.life -= dt;
    this.hitCooldown -= dt;
    this.t += dt;
    this.frame = Math.floor(this.t * 8) % this.frames.length;
    if (this.life <= 0) this.dead = true;
  }
  /** Может ли сфера ударить сейчас. */
  canHit(fighter) {
    if (this.hitCooldown > 0) return false;
    const dx = Math.abs(fighter.x - this.x);
    const dy = Math.abs((fighter.y - 60) - this.y);
    return dx < this.radius + 26 && dy < 110;
  }
  markHit() { this.hitCooldown = 1.0; }
  draw(ctx) {
    const im = TCF.AnimLib.img(this.frames[this.frame]);
    if (!im || !im.width) return;
    const fade = Math.min(1, this.life / 0.8);
    const s = this.radius * 2.4;
    ctx.save();
    ctx.globalAlpha = fade;
    // аура на полу
    ctx.fillStyle = 'rgba(120,40,200,0.18)';
    ctx.beginPath();
    ctx.ellipse(this.x, TCF.CFG.GROUND + 6, this.radius * 1.2, 10, 0, 0, 6.29);
    ctx.fill();
    ctx.drawImage(im, this.x - s / 2, this.y - s / 2, s, s);
    ctx.restore();
  }
};

/* --- DARK ZONE: большая область тёмной энергии (фаза 2) --- */
TCF.DarkZone = class {
  constructor(x) {
    this.x = TCF.clamp(x, TCF.CFG.WALL_L + 100, TCF.CFG.WALL_R - 100);
    this.y = TCF.CFG.GROUND;
    this.radius = TCF.CFG.ENEMY.darkzone.radius;
    this.telegraph = TCF.CFG.ENEMY.darkzone.telegraph;
    this.life = TCF.CFG.ENEMY.darkzone.dur;
    this.tick = 0;
    this.dead = false;
    this.warned = false;
    this.frames = TCF.AnimLib.data.fx.darkZone;
    this.frame = 0; this.t = 0;
  }
  get active() { return this.telegraph <= 0; }
  update(dt) {
    this.t += dt;                       // время идёт всегда — телеграф зоны мигает
    if (this.telegraph > 0) { this.telegraph -= dt; return; }
    this.life -= dt;
    this.tick -= dt;
    this.frame = Math.floor(this.t * 8) % this.frames.length;
    if (this.life <= 0) this.dead = true;
  }
  contains(fighter) { return Math.abs(fighter.x - this.x) < this.radius; }
  draw(ctx) {
    ctx.save();
    if (!this.active) {
      // предупреждение: мигающий контур
      const blink = Math.sin(this.t * 20) > 0;
      ctx.strokeStyle = blink ? 'rgba(160,60,255,0.8)' : 'rgba(160,60,255,0.25)';
      ctx.lineWidth = 3;
      ctx.setLineDash([12, 8]);
      ctx.beginPath();
      ctx.ellipse(this.x, this.y + 4, this.radius, 16, 0, 0, 6.29);
      ctx.stroke();
    } else {
      const im = TCF.AnimLib.img(this.frames[this.frame]);
      if (im && im.width) {
        const fade = Math.min(1, this.life / 0.6);
        ctx.globalAlpha = fade;
        ctx.drawImage(im, this.x - this.radius, this.y - 60, this.radius * 2, 90);
      }
      // столб энергии
      const g = ctx.createLinearGradient(0, this.y - 260, 0, this.y);
      g.addColorStop(0, 'rgba(90,20,140,0)');
      g.addColorStop(1, 'rgba(120,30,190,0.30)');
      ctx.fillStyle = g;
      ctx.fillRect(this.x - this.radius, this.y - 260, this.radius * 2, 260);
    }
    ctx.restore();
  }
};

/* --- Вспышка попадания --- */
TCF.Spark = class {
  constructor(x, y) {
    this.x = x; this.y = y;
    this.frames = TCF.AnimLib.data.fx.spark;
    this.frame = 0; this.t = 0;
    this.dead = false;
  }
  update(dt) {
    this.t += dt;
    this.frame = Math.floor(this.t * 22);
    if (this.frame >= this.frames.length) this.dead = true;
  }
  draw(ctx) {
    if (this.dead) return;
    const im = TCF.AnimLib.img(this.frames[this.frame]);
    if (!im || !im.width) return;
    ctx.drawImage(im, this.x - 40, this.y - 40, 80, 80);
  }
};
