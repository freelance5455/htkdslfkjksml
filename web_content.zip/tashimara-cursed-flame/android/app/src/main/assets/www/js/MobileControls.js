'use strict';
/* =========================================================
 * MobileControls.js — сенсорные кнопки для телефона.
 *
 * held   : удерживаемые кнопки (LEFT / RIGHT)
 * tapped : одиночные нажатия (JUMP / DODGE / ATTACK / SPECIAL),
 *          сбрасываются игрой после каждого кадра.
 *
 * Есть и клавиатура для теста на ПК:
 *   ← → / A D — движение,  ↑ / W / Space — прыжок,
 *   J — атака,  K — спецатака,  L / Shift — уклонение.
 * ========================================================= */

TCF.MobileControls = class {
  constructor() {
    this.held = { left: false, right: false };
    this.tapped = { jump: false, dodge: false, attack: false, special: false };
    this.bindTouch();
    this.bindKeyboard();
    this.isTouch = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
  }

  setVisible(v) {
    const el = document.getElementById('touch-controls');
    el.classList.toggle('visible', v);
  }

  bindBtn(id, key) {
    const el = document.getElementById(id);
    const down = e => {
      e.preventDefault();
      el.classList.add('pressed');
      if (key in this.held) this.held[key] = true;
      else this.tapped[key] = true;
    };
    const up = e => {
      e.preventDefault();
      el.classList.remove('pressed');
      if (key in this.held) this.held[key] = false;
    };
    el.addEventListener('pointerdown', down);
    el.addEventListener('pointerup', up);
    el.addEventListener('pointercancel', up);
    el.addEventListener('pointerleave', up);
  }

  bindTouch() {
    this.bindBtn('tc-left', 'left');
    this.bindBtn('tc-right', 'right');
    this.bindBtn('tc-jump', 'jump');
    this.bindBtn('tc-dodge', 'dodge');
    this.bindBtn('tc-attack', 'attack');
    this.bindBtn('tc-special', 'special');
  }

  bindKeyboard() {
    const km = {
      ArrowLeft: 'left', KeyA: 'left',
      ArrowRight: 'right', KeyD: 'right',
      ArrowUp: 'jump', KeyW: 'jump', Space: 'jump',
      KeyJ: 'attack', KeyZ: 'attack',
      KeyK: 'special', KeyX: 'special',
      KeyL: 'dodge', ShiftLeft: 'dodge', ShiftRight: 'dodge', KeyC: 'dodge',
    };
    window.addEventListener('keydown', e => {
      const k = km[e.code];
      if (!k) return;
      e.preventDefault();
      if (k in this.held) this.held[k] = true;
      else if (!e.repeat) this.tapped[k] = true;
    });
    window.addEventListener('keyup', e => {
      const k = km[e.code];
      if (k && k in this.held) this.held[k] = false;
    });
  }

  /** Прочитать и сбросить одиночные нажатия (в конце кадра). */
  consume() {
    const t = { ...this.tapped };
    this.tapped.jump = this.tapped.dodge = this.tapped.attack = this.tapped.special = false;
    return { held: this.held, tapped: t };
  }
};
