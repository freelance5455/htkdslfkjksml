'use strict';
/* =========================================================
 * GameState.js — конечный автомат экранов и логика матча.
 *
 * Экраны: menu → select(через characters) / dialogue → fight → end
 * Матч:   раунды, до 2 побед; PHASE 2 у Безликой при HP <= 50.
 * ========================================================= */

TCF.GameState = class {
  constructor(game) {
    this.game = game;               // ссылка на main.js (оркестратор)
    this.screen = 'menu';           // menu | dialogue | fight | end
    this.round = 0;
    this.winsPlayer = 0;
    this.winsEnemy = 0;
    this.phase2 = false;            // вторая фаза Безликой
    this.roundIntro = 0;            // таймер заставки ROUND/FIGHT
    this.fightActive = false;       // можно ли двигаться
    this.settings = this.loadSettings();
  }

  loadSettings() {
    try {
      return Object.assign({ difficulty: 'normal', music: true, shake: true },
        JSON.parse(localStorage.getItem('tcf-settings') || '{}'));
    } catch (e) { return { difficulty: 'normal', music: true, shake: true }; }
  }
  saveSettings() {
    localStorage.setItem('tcf-settings', JSON.stringify(this.settings));
  }

  /* ---------- Переходы между экранами ---------- */

  toMenu() {
    this.screen = 'menu';
    this.game.ui.showScreen('menu');
    this.game.controls.setVisible(false);
  }

  /** START → диалог перед боем → раунд 1. */
  startMatch() {
    this.round = 0;
    this.winsPlayer = 0;
    this.winsEnemy = 0;
    this.phase2 = false;
    this.game.arena.setIntensity(0);
    this.game.music.setTempo(1);
    this.screen = 'dialogue';
    this.game.ui.showScreen(null);
    this.game.dialogue.play(() => this.startRound());
  }

  startRound() {
    this.round++;
    this.screen = 'fight';
    this.fightActive = false;
    this.game.combat.resetRound();
    this.game.controls.setVisible(true);
    this.game.ui.showScreen(null);
    this.roundIntro = 2.6;          // "ROUND N" → "FIGHT!"
    this.game.ui.announce('ROUND ' + this.round, '', 1.1);
    this._announcedFight = false;
  }

  /** Конец раунда (winner: 'player' | 'enemy'). */
  onRoundEnd(winner) {
    if (this.screen !== 'fight') return;
    this.fightActive = false;
    if (winner === 'player') this.winsPlayer++;
    else this.winsEnemy++;
    this.game.ui.updateRounds(this.winsPlayer, this.winsEnemy);

    if (this.winsPlayer >= TCF.CFG.WINS_NEEDED) return this.endMatch('player');
    if (this.winsEnemy  >= TCF.CFG.WINS_NEEDED) return this.endMatch('enemy');

    this.game.ui.announce(winner === 'player' ? 'TASHIMARA TAKES THE ROUND' : 'FACELESS TAKES THE ROUND', '', 1.6);
    setTimeout(() => { if (this.screen === 'fight') this.startRound(); }, 2000);
  }

  endMatch(winner) {
    this.screen = 'end';
    this.game.controls.setVisible(false);
    this.game.combat.playOutro(winner);
    const win = winner === 'player';
    this.game.ui.announce(win ? 'YOU WIN' : 'YOU LOSE',
                          win ? 'TASHIMARA WINS' : 'FACELESS WINS', 2.2);
    setTimeout(() => this.game.ui.showEndScreen(win), 2400);
  }

  /** Включить PHASE 2: Безликая усиливается, арена и музыка — тоже. */
  enterPhase2() {
    if (this.phase2) return;
    this.phase2 = true;
    this.game.arena.setIntensity(1);
    this.game.music.setTempo(1.25);
    this.game.enemy.onPhase2();
    this.game.ui.announce('PHASE 2', 'FACELESS AWAKENS', 1.8);
  }

  /** Обновление состояния матча (вызывается каждый кадр). */
  update(dt) {
    if (this.screen !== 'fight') return;
    // Заставка начала раунда
    if (this.roundIntro > 0) {
      this.roundIntro -= dt;
      if (this.roundIntro <= 1.4 && !this._announcedFight) {
        this._announcedFight = true;
        this.game.ui.announce('FIGHT!', '', 0.9);
        if (this.settings.music) this.game.music.start();   // уважаем настройку звука
      }
      if (this.roundIntro <= 0) this.fightActive = true;
    }
  }
};
