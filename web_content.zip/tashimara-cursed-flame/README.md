# TASHIMARA: CURSED FLAME — FACELESS

2D файтинг 1 на 1 в пиксель-арт стиле для браузера и мобильных устройств.
Ташимара против Безликой на арене Пургатория.

## Запуск

Игра написана на чистом JavaScript + HTML5 Canvas — сборка не нужна.

**Вариант 1 (просто открыть):** откройте `index.html` двойным кликом.

**Вариант 2 (правильный, через локальный сервер):**
```bash
cd tashimara-cursed-flame
python3 -m http.server 8000
# открыть http://localhost:8000
```
Локальный сервер нужен, чтобы браузер разрешил загрузку спрайтов (`fetch`).

## Управление

| Действие | Клавиатура | Сенсор |
|---|---|---|
| Движение | ← → / A D | ◀ ▶ |
| Прыжок | ↑ / W / Space | JUMP |
| Атака (комбо ×3) | J / Z | ATTACK |
| CURSED FLAME (40 энергии) | K / X | SPECIAL |
| Уклонение (неуязвимость) | L / Shift / C | DODGE |

## Структура проекта

```
tashimara-cursed-flame/
├── index.html            # все экраны + сенсорные кнопки
├── css/style.css         # pixel-UI, крупные тач-кнопки
├── js/
│   ├── config.js         # ВЕСЬ баланс игры (урон, энергия, физика, PHASE 2)
│   ├── Animations.js     # загрузка спрайтов, проигрывание кадров
│   ├── Arena.js          # фон PURGATORY (цепи, разломы, частицы)
│   ├── Abilities.js      # FlameProjectile, DarkBolt, HungerSphere, DarkZone, Spark
│   ├── Combat.js         # урон, HP, энергия, столкновения, таймер раунда
│   ├── Player.js         # Ташимара: состояния, комбо, уклонение
│   ├── Enemy.js          # Безликая: ИИ, способности, PHASE 2
│   ├── UI.js             # HUD, экраны меню, объявления ROUND/FIGHT
│   ├── Dialogue.js       # диалог перед боем
│   ├── MobileControls.js # мультитач-кнопки + клавиатура
│   ├── GameState.js      # автомат экранов, раунды, PHASE 2
│   └── main.js           # игровой цикл, музыка WebAudio
├── assets/sprites/       # нарезанные спрайты + manifest.json
├── tools/
│   └── slice_sprites.py  # нарезка своих sprite sheets
└── android/              # готовый Android-проект для сборки APK
```

## Как добавить свои спрайты

1. Положите кадры анимации в `assets/sprites/<персонаж>/` как отдельные PNG
   с прозрачным фоном (например `mychar/attack_00.png`, `attack_01.png`...).
   Рекомендуемая высота кадров ~90–160 px (в игре спрайт масштабируется
   по параметру `height` в манифесте).
2. Зарегистрируйте их в `assets/sprites/manifest.json`:
   ```json
   "mychar": {
     "height": 150,
     "animations": {
       "idle":   ["assets/sprites/mychar/idle_00.png", "..."],
       "attack": ["assets/sprites/mychar/attack_00.png", "..."]
     }
   }
   ```
3. Используйте класс персонажа по образцу `js/Player.js` и подключите
   `new TCF.Animator('mychar', 'idle', 10)`.

**Нарезка из целого sprite sheet:** запустите `tools/slice_sprites.py`
(нужен Python + Pillow). В начале файла — блок `REGIONS` с координатами
панелей `(x0, y0, x1, y1)` и числом кадров. Скрипт удалит фон
(flood-fill от краёв), очистит подписи и сохранит кадры в `assets/sprites/`.

## Сборка APK (мобильная версия)

Игра — это статический сайт, поэтому APK собирается как обёртка
`WebView` поверх `android/`-проекта.

### Вариант A: Android Studio (рекомендуется)
1. Установите [Android Studio](https://developer.android.com/studio).
2. `File → Open` → выберите папку `android/` из этого проекта.
3. Дождитесь синхронизации Gradle.
4. `Build → Build APK(s)` → готовый APK: `android/app/build/outputs/apk/debug/app-debug.apk`.

### Вариант B: командная строка
```bash
cd android
# нужны JDK 17 и Android SDK (переменная ANDROID_HOME)
./gradlew assembleDebug
```

### Вариант C: без установки SDK — GitHub Actions
Загрузите проект в репозиторий GitHub и используйте workflow:
`.github/workflows/apk.yml` (см. пример в android/apk-workflow.yml):
пуш в ветку `main` → Actions соберёт APK и сохранит его как артефакт сборки.

### Вариант D: Cordova / Capacitor
```bash
npm install -g cordova
cordova create tcf-app ru.tcf.game TCF
# скопируйте файлы игры в tcf-app/www
cd tcf-app
cordova platform add android
cordova build android
```

## Боевая система (для балансировки)

Всё настраивается в `js/config.js`:
- Комбо Ташимары: `attack1 → attack2 → attack3` (урон/отброс/дистанция).
- `CURSED FLAME`: цена 40 энергии, задержка 0.5 с (можно увернуться).
- `DODGE`: 0.34 с рывка, окно неуязвимости `iframes`.
- Безликая: `attack` (близко), `darkbolt` (далеко), `HUNGER` (сфера),
  `DARK ZONE` (фаза 2).
- `PHASE 2` при HP ≤ 50: `speedMul`, `cdMul`, `maxSpheres` в `ENEMY.phase2`.
