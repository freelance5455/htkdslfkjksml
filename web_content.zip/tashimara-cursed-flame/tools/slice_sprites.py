#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
slice_sprites.py — нарезка sprite sheet на отдельные кадры.

Что делает:
  1. Режет панель анимации на равные кадры.
  2. Удаляет фон flood-fill'ом от краёв (фон должен быть однотонным).
  3. Стирает текстовые подписи в верхней зоне панели (label_zone).
  4. Обрезает кадры по содержимому и сохраняет PNG с прозрачностью.

Зависимости:  pip install pillow numpy
Запуск:       python3 slice_sprites.py sheet.png out_dir
"""
import sys, os, collections
import numpy as np
from PIL import Image

# ---------------------------------------------------------------
# НАСТРОЙКА: панели вашего sprite sheet
# (имя, (x0, y0, x1, y1) — границы панели, число кадров)
# Подберите координаты в любом редакторе изображений.
# ---------------------------------------------------------------
REGIONS = [
    # пример (замените на свои координаты):
    # ("idle",   (10,  48, 572, 200), 6),
    # ("run",    (580, 48, 1530, 205), 8),
]
LABEL_ZONE = 40      # высота верхней зоны, где стираются подписи (px)
BG_TOL = 38          # допуск цвета фона

def floodkey_bg(arr, bg, tol=BG_TOL):
    h, w, _ = arr.shape
    dist = np.abs(arr[:, :, :3].astype(int) - bg).sum(axis=2)
    mask = dist <= tol
    visited = np.zeros((h, w), bool)
    dq = collections.deque()
    for x in range(w):
        for y in (0, h - 1):
            if mask[y, x] and not visited[y, x]:
                visited[y, x] = True; dq.append((y, x))
    for y in range(h):
        for x in (0, w - 1):
            if mask[y, x] and not visited[y, x]:
                visited[y, x] = True; dq.append((y, x))
    while dq:
        y, x = dq.popleft()
        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            ny, nx = y + dy, x + dx
            if 0 <= ny < h and 0 <= nx < w and mask[ny, nx] and not visited[ny, nx]:
                visited[ny, nx] = True; dq.append((ny, nx))
    out = arr.copy()
    alpha = np.where(visited, 0, 255).astype(np.uint8)
    out[:, :, 3] = np.minimum(out[:, :, 3], alpha)
    return out

def slice_region(img, box, frames, outdir, prefix, label_zone=LABEL_ZONE, pad=2):
    x0, y0, x1, y1 = box
    W = (x1 - x0) // frames
    region = np.array(img.crop(box)).astype(int)
    h, w, _ = region.shape
    bg = region[2, 2, :3].copy()                 # цвет фона до очисток
    rgb = region[:, :, :3]
    light = (rgb.sum(axis=2) > 280) & (region[:, :, 3] > 0)
    counts = light.sum(axis=1)
    for y in range(min(label_zone, h)):          # стираем подписи панели
        if counts[y] > 0.04 * w:
            region[y, :, 3] = 0
    os.makedirs(outdir, exist_ok=True)
    for i in range(frames):
        fr = Image.fromarray(region[:, i * W:(i + 1) * W].astype(np.uint8))
        a = floodkey_bg(np.array(fr), bg)
        fr = Image.fromarray(a)
        bbox = fr.getbbox()
        if bbox:
            l, tp, r, bt = bbox
            fr = fr.crop((max(0, l - pad), max(0, tp - pad),
                          min(fr.width, r + pad), min(fr.height, bt + pad)))
        fr.save(os.path.join(outdir, f'{prefix}_{i:02d}.png'))
    print(f'  {prefix}: {frames} кадров -> {outdir}')

def main():
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(1)
    sheet = Image.open(sys.argv[1]).convert('RGBA')
    outdir = sys.argv[2]
    print(f'Лист: {sys.argv[1]} {sheet.size}')
    for name, box, n in REGIONS:
        slice_region(sheet, box, n, os.path.join(outdir, name), name)
    print('Готово. Обновите manifest.json новыми кадрами.')

if __name__ == '__main__':
    main()
