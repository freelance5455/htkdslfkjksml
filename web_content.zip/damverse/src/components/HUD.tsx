import React from 'react';
import { 
  Droplet, 
  Zap, 
  Coins, 
  Sun, 
  CloudRain, 
  Volume2, 
  VolumeX, 
  AlertTriangle 
} from 'lucide-react';
import { ReservoirState, Finances, GridState, WeatherType } from '../types/game';
import { soundManager } from '../lib/audio';

interface HUDProps {
  reservoir: ReservoirState;
  finances: Finances;
  grid: GridState;
  gameTimeHours: number;
  weather: WeatherType;
  onToggleWeather: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  reservoir,
  finances,
  grid,
  gameTimeHours,
  weather,
  onToggleWeather,
  isMuted,
  onToggleMute,
}) => {
  // Format game time (HH:MM)
  const hours = Math.floor(gameTimeHours);
  const minutes = Math.floor((gameTimeHours - hours) * 60);
  const formattedTime = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;

  const waterLevelPct = Math.min(100, Math.max(0, ((reservoir.waterLevelM - reservoir.minOperatingLevelM) / (reservoir.maxLevelM - reservoir.minOperatingLevelM)) * 100));

  return (
    <div className="absolute top-0 left-0 right-0 p-3 pointer-events-none z-10 select-none">
      {/* Flood Alarm Alert Banner */}
      {reservoir.floodAlarm && (
        <div className="mx-auto mb-2 w-max bg-red-600/90 text-white font-bold text-xs tracking-wider px-4 py-1.5 rounded-full flex items-center gap-2 border border-red-300 shadow-xl animate-bounce">
          <AlertTriangle className="w-4 h-4 text-amber-300" />
          <span>FLOOD ALERT: RESERVOIR LEVEL CRITICAL ({reservoir.waterLevelM.toFixed(1)}m) — OPEN SPILLWAY GATES!</span>
        </div>
      )}

      {/* Main Glass Telemetry Bar */}
      <div className="bg-slate-950/80 backdrop-blur-md border border-slate-700/80 rounded-2xl px-4 py-2 flex items-center justify-between shadow-2xl text-slate-100 max-w-5xl mx-auto">
        {/* Reservoir Telemetry */}
        <div className="flex items-center gap-3 border-r border-slate-800 pr-4">
          <div className="w-8 h-8 rounded-xl bg-cyan-950/80 border border-cyan-500/50 flex items-center justify-center text-cyan-400">
            <Droplet className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-sm font-extrabold text-cyan-300 font-mono">
                {reservoir.waterLevelM.toFixed(1)}m
              </span>
              <span className="text-[10px] text-slate-400 font-mono">/ {reservoir.maxLevelM}m</span>
            </div>
            {/* Water progress bar */}
            <div className="w-24 h-1.5 bg-slate-800 rounded-full overflow-hidden mt-0.5">
              <div 
                className={`h-full rounded-full transition-all duration-300 ${
                  reservoir.waterLevelM > 152 ? 'bg-red-500' : 'bg-cyan-400'
                }`}
                style={{ width: `${waterLevelPct}%` }}
              />
            </div>
          </div>

          <div className="text-[10px] text-slate-400 font-mono leading-tight pl-1">
            <div>IN: <span className="text-cyan-200 font-bold">{Math.round(reservoir.inflowCms)}</span> m³/s</div>
            <div>OUT: <span className="text-slate-200 font-bold">{Math.round(reservoir.totalOutflowCms)}</span> m³/s</div>
          </div>
        </div>

        {/* Power & Grid Stability */}
        <div className="flex items-center gap-3 border-r border-slate-800 pr-4">
          <div className="w-8 h-8 rounded-xl bg-emerald-950/80 border border-emerald-500/50 flex items-center justify-center text-emerald-400">
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <div className="text-sm font-extrabold text-emerald-300 font-mono">
              {Math.round(grid.totalGenerationMW)} MW
            </div>
            <div className="flex items-center gap-1.5 text-[10px] font-mono">
              <span className="text-slate-400">GRID:</span>
              <span className={`font-bold ${grid.blackoutRisk ? 'text-red-400' : 'text-emerald-400'}`}>
                {grid.frequencyHz.toFixed(2)} Hz
              </span>
            </div>
          </div>
        </div>

        {/* Financial Treasury */}
        <div className="flex items-center gap-3 border-r border-slate-800 pr-4">
          <div className="w-8 h-8 rounded-xl bg-amber-950/80 border border-amber-500/50 flex items-center justify-center text-amber-400">
            <Coins className="w-4 h-4" />
          </div>
          <div>
            <div className="text-sm font-extrabold text-amber-300 font-mono">
              RM {(finances.fundsRM / 1_000_000).toFixed(2)}M
            </div>
            <div className="text-[10px] text-emerald-400 font-mono">
              +RM {Math.round(finances.netRevenueRateRMPerHour)}/hr
            </div>
          </div>
        </div>

        {/* Time, Weather and Mute controls */}
        <div className="flex items-center gap-2 pointer-events-auto">
          {/* Time display */}
          <div className="bg-slate-900 border border-slate-700 px-2.5 py-1 rounded-xl text-xs font-mono font-bold text-slate-300">
            {formattedTime}
          </div>

          {/* Weather trigger button */}
          <button
            onClick={() => {
              soundManager.playClick();
              onToggleWeather();
            }}
            className={`p-1.5 rounded-xl border transition-all active:scale-95 flex items-center gap-1 text-xs font-bold ${
              weather === 'monsoon_rain'
                ? 'bg-blue-600/90 text-white border-blue-400 shadow-md animate-pulse'
                : 'bg-slate-900 border-slate-700 text-amber-300'
            }`}
            title="Toggle Monsoon Storm"
          >
            {weather === 'monsoon_rain' ? (
              <>
                <CloudRain className="w-4 h-4" />
                <span className="text-[10px]">MONSOON</span>
              </>
            ) : (
              <>
                <Sun className="w-4 h-4" />
                <span className="text-[10px]">TROPICAL</span>
              </>
            )}
          </button>

          {/* Sound Toggle */}
          <button
            onClick={() => {
              onToggleMute();
            }}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-white active:scale-95 transition-all"
            title="Toggle Sound"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
          </button>
        </div>
      </div>
    </div>
  );
};
