import React from 'react';
import { X, Target, CheckCircle2, Award } from 'lucide-react';
import { GameMission } from '../types/game';
import { soundManager } from '../lib/audio';

interface MissionsModalProps {
  missions: GameMission[];
  onClaimReward: (missionId: string, rewardRM: number) => void;
  onClose: () => void;
}

export const MissionsModal: React.FC<MissionsModalProps> = ({
  missions,
  onClaimReward,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 z-50 select-none">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-xl rounded-2xl p-5 text-slate-100 shadow-2xl relative max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-rose-950 border border-rose-500/50 flex items-center justify-center text-rose-400">
              <Target className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-wide">DAM ENGINEERING MISSIONS & CONTRACTS</h2>
              <p className="text-xs text-slate-400">Complete hydrological and grid objectives for government grants</p>
            </div>
          </div>
          <button
            onClick={() => { soundManager.playClick(); onClose(); }}
            className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mission List */}
        <div className="space-y-3">
          {missions.map((m) => {
            const isReadyToClaim = m.progressPercent >= 100 && !m.isCompleted;

            return (
              <div
                key={m.id}
                className={`p-3.5 rounded-xl border transition-all ${
                  m.isCompleted
                    ? 'bg-slate-950/40 border-slate-800/80 opacity-60'
                    : isReadyToClaim
                    ? 'bg-rose-950/40 border-rose-500/70 shadow-lg'
                    : 'bg-slate-800/80 border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between mb-1">
                  <div>
                    <h3 className="text-xs font-extrabold text-white flex items-center gap-1.5">
                      {m.isCompleted && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                      {m.title}
                    </h3>
                    <p className="text-[11px] text-slate-300 mt-0.5">{m.objective}</p>
                  </div>
                  <div className="text-right shrink-0 ml-3">
                    <span className="text-xs font-mono font-bold text-amber-300">
                      +RM {(m.rewardRM / 1_000_000).toFixed(1)}M
                    </span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="mt-2.5 flex items-center gap-3">
                  <div className="flex-1 h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        m.isCompleted ? 'bg-emerald-500' : 'bg-rose-500'
                      }`}
                      style={{ width: `${Math.min(100, m.progressPercent)}%` }}
                    />
                  </div>
                  <span className="text-[10px] font-mono text-slate-400 w-9 text-right">
                    {m.isCompleted ? '100%' : `${m.progressPercent}%`}
                  </span>

                  {isReadyToClaim && (
                    <button
                      onClick={() => {
                        soundManager.playClick();
                        onClaimReward(m.id, m.rewardRM);
                      }}
                      className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold px-3 py-1 rounded-lg text-xs flex items-center gap-1 shadow-md active:scale-95 transition-all"
                    >
                      <Award className="w-3.5 h-3.5" />
                      CLAIM
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
