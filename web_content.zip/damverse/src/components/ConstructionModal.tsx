import React from 'react';
import { X, Hammer, CheckCircle2, ChevronRight, HardHat, TrendingUp } from 'lucide-react';
import { soundManager } from '../lib/audio';

interface ConstructionModalProps {
  stage: number;
  fundsRM: number;
  onAdvanceStage: (nextStage: number, cost: number) => void;
  onClose: () => void;
}

const STAGES = [
  {
    stage: 1,
    name: 'River Diversion & Cofferdam',
    desc: 'Blasting 1.2km horseshoe diversion tunnel through the granite abutment to dewater the riverbed.',
    cost: 4500000,
    concrete: '85,000 m³',
    height: 'EL 35m',
  },
  {
    stage: 2,
    name: 'Foundation Excavation & Curtain Grouting',
    desc: 'Excavating weathered bedrock down to competent rock and pressure-injecting cement grout curtain.',
    cost: 6200000,
    concrete: '140,000 m³',
    height: 'EL 48m',
  },
  {
    stage: 3,
    name: 'Dam Monolithic Concrete Pours',
    desc: 'Continuous mass concrete placement using tower cranes and cooling water pipes to control hydration heat.',
    cost: 9800000,
    concrete: '550,000 m³',
    height: 'EL 95m',
  },
  {
    stage: 4,
    name: 'Radial Spillway Gates & Crest Road',
    desc: 'Erecting heavy steel radial tainter gates, spillway bridge, and asphalt crest roadway for utility trucks.',
    cost: 7500000,
    concrete: '780,000 m³',
    height: 'EL 148m (Crest)',
  },
  {
    stage: 5,
    name: 'Intake Towers & Steel Penstocks',
    desc: 'Fabricating 4.8m diameter high-tensile steel penstocks anchored into the downstream cliff face.',
    cost: 8400000,
    concrete: '920,000 m³',
    height: 'Intake EL 135m',
  },
  {
    stage: 6,
    name: 'Powerhouse & Francis Turbines',
    desc: 'Installing 4x 100MW vertical Francis turbine runner assemblies, scroll cases, and generator rotors.',
    cost: 11000000,
    concrete: '1,100,000 m³',
    height: 'Powerhouse 130m',
  },
  {
    stage: 7,
    name: 'Switchyard & 275kV Grid Lines',
    desc: 'Constructing outdoor GIS switchyard, SF6 breakers, step-up transformers, and mountain transmission towers.',
    cost: 6500000,
    concrete: '1,150,000 m³',
    height: '275kV Grid',
  },
  {
    stage: 8,
    name: 'Reservoir Impoundment & Commissioning',
    desc: 'Closing the diversion gates to impound the upper reservoir and starting full commercial power generation!',
    cost: 5000000,
    concrete: '1,200,000 m³',
    height: 'EL 160m (Max Full)',
  },
];

export const ConstructionModal: React.FC<ConstructionModalProps> = ({
  stage,
  fundsRM,
  onAdvanceStage,
  onClose,
}) => {
  const currentStageInfo = STAGES[Math.min(STAGES.length - 1, stage - 1)];
  const nextStageInfo = stage < 8 ? STAGES[stage] : null;

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 z-50 select-none">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-2xl rounded-2xl p-5 text-slate-100 shadow-2xl relative max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-950 border border-amber-500/50 flex items-center justify-center text-amber-400">
              <HardHat className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-wide">DAM CIVIL ENGINEERING & CONSTRUCTION</h2>
              <p className="text-xs text-slate-400">Current Progress: Stage {stage} of 8 — {currentStageInfo.name}</p>
            </div>
          </div>
          <button
            onClick={() => { soundManager.playClick(); onClose(); }}
            className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Active Milestone Card */}
        {nextStageInfo ? (
          <div className="bg-amber-950/40 border border-amber-500/50 rounded-xl p-4 mb-4 flex items-center justify-between">
            <div>
              <div className="text-[11px] font-bold text-amber-400 flex items-center gap-1.5 mb-1">
                <TrendingUp className="w-3.5 h-3.5" />
                <span>NEXT MAJOR MILESTONE: STAGE {nextStageInfo.stage}</span>
              </div>
              <h3 className="text-sm font-extrabold text-white">{nextStageInfo.name}</h3>
              <p className="text-xs text-slate-300 max-w-md mt-0.5">{nextStageInfo.desc}</p>
              <div className="flex items-center gap-4 mt-2 text-xs font-mono">
                <span className="text-slate-400">ESTIMATED COST: <span className="text-amber-300 font-bold">RM {(nextStageInfo.cost / 1_000_000).toFixed(1)}M</span></span>
                <span className="text-slate-400">TARGET: <span className="text-cyan-300 font-bold">{nextStageInfo.height}</span></span>
              </div>
            </div>

            <button
              disabled={fundsRM < nextStageInfo.cost}
              onClick={() => {
                soundManager.playConcretePour();
                onAdvanceStage(nextStageInfo.stage, nextStageInfo.cost);
              }}
              className="bg-amber-500 hover:bg-amber-400 disabled:opacity-40 disabled:pointer-events-none text-slate-950 font-extrabold px-4 py-3 rounded-xl text-xs flex items-center gap-2 shadow-xl active:scale-95 transition-all shrink-0 ml-3"
            >
              <Hammer className="w-4 h-4" />
              <span>POUR & ADVANCE</span>
            </button>
          </div>
        ) : (
          <div className="bg-emerald-950/40 border border-emerald-500/50 rounded-xl p-4 mb-4 flex items-center gap-3">
            <CheckCircle2 className="w-8 h-8 text-emerald-400" />
            <div>
              <h3 className="text-sm font-extrabold text-emerald-300">DAM COMMISSIONING COMPLETED (STAGE 8)</h3>
              <p className="text-xs text-slate-300">The hydroelectric facility is in full commercial operation supplying clean renewable energy to the national grid.</p>
            </div>
          </div>
        )}

        {/* 8-Stage Timeline List */}
        <div className="space-y-2">
          {STAGES.map((s) => {
            const isCompleted = stage > s.stage;
            const isCurrent = stage === s.stage;

            return (
              <div
                key={s.stage}
                className={`p-3 rounded-xl border flex items-center justify-between text-xs transition-all ${
                  isCurrent
                    ? 'bg-slate-800/90 border-amber-500/70 shadow-md'
                    : isCompleted
                    ? 'bg-slate-900/40 border-slate-800 text-slate-400'
                    : 'bg-slate-950/30 border-slate-800/60 text-slate-500'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-xs ${
                    isCompleted ? 'bg-emerald-500 text-slate-950' : isCurrent ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {isCompleted ? <CheckCircle2 className="w-4 h-4" /> : s.stage}
                  </div>
                  <div>
                    <span className={`font-bold block ${isCurrent ? 'text-white' : isCompleted ? 'text-slate-300' : 'text-slate-500'}`}>
                      {s.name}
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">
                      {s.height} • {s.concrete}
                    </span>
                  </div>
                </div>

                <div className="text-right font-mono">
                  <span className={`font-bold ${isCompleted ? 'text-emerald-400' : isCurrent ? 'text-amber-400' : 'text-slate-500'}`}>
                    {isCompleted ? 'COMPLETED' : isCurrent ? 'IN PROGRESS' : `RM ${(s.cost / 1_000_000).toFixed(1)}M`}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
