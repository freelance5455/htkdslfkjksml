import React, { useRef, useState, useCallback, useEffect } from 'react';
import { 
  Car, 
  ArrowUp, 
  Zap, 
  Sliders, 
  Hammer, 
  Activity, 
  Building2, 
  Target, 
  Menu
} from 'lucide-react';
import { soundManager } from '../lib/audio';

interface TouchControlsProps {
  onMove: (input: { x: number; y: number }) => void;
  onRotateCamera: (deltaYaw: number, deltaPitch: number) => void;
  onJump: () => void;
  onSprintToggle: (sprint: boolean) => void;
  isSprinting: boolean;
  nearVehicle: boolean;
  inVehicle: boolean;
  onToggleVehicle: () => void;
  onOpenSpillway: () => void;
  onOpenTurbines: () => void;
  onOpenConstruction: () => void;
  onOpenTownship: () => void;
  onOpenMissions: () => void;
  onOpenMenu: () => void;
}

export const TouchControls: React.FC<TouchControlsProps> = ({
  onMove,
  onRotateCamera,
  onJump,
  onSprintToggle,
  isSprinting,
  nearVehicle,
  inVehicle,
  onToggleVehicle,
  onOpenSpillway,
  onOpenTurbines,
  onOpenConstruction,
  onOpenTownship,
  onOpenMissions,
  onOpenMenu,
}) => {
  // Joystick state
  const joystickBaseRef = useRef<HTMLDivElement>(null);
  const [knobPos, setKnobPos] = useState({ x: 0, y: 0 });
  const [isJoystickActive, setIsJoystickActive] = useState(false);
  const joystickTouchId = useRef<number | null>(null);

  // Camera Drag state
  const cameraTouchId = useRef<number | null>(null);
  const lastTouchPos = useRef<{ x: number; y: number } | null>(null);

  // Joystick touch handlers
  const handleJoystickStart = useCallback((e: React.TouchEvent) => {
    if (joystickTouchId.current !== null) return;
    const touch = e.changedTouches[0];
    joystickTouchId.current = touch.identifier;
    setIsJoystickActive(true);
    updateJoystickPos(touch.clientX, touch.clientY);
  }, []);

  const updateJoystickPos = (clientX: number, clientY: number) => {
    if (!joystickBaseRef.current) return;
    const rect = joystickBaseRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const maxRadius = 45;
    let dx = clientX - centerX;
    let dy = clientY - centerY;
    const dist = Math.sqrt(dx * dx + dy * dy);

    if (dist > maxRadius) {
      dx = (dx / dist) * maxRadius;
      dy = (dy / dist) * maxRadius;
    }

    setKnobPos({ x: dx, y: dy });
    onMove({ x: dx / maxRadius, y: dy / maxRadius });
  };

  const handleJoystickMove = useCallback((e: TouchEvent) => {
    if (joystickTouchId.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === joystickTouchId.current) {
        updateJoystickPos(touch.clientX, touch.clientY);
        break;
      }
    }
  }, [onMove]);

  const handleJoystickEnd = useCallback((e: TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === joystickTouchId.current) {
        joystickTouchId.current = null;
        setIsJoystickActive(false);
        setKnobPos({ x: 0, y: 0 });
        onMove({ x: 0, y: 0 });
        break;
      }
    }
  }, [onMove]);

  // Camera Drag handlers (right half of screen)
  const handleCameraTouchStart = useCallback((e: React.TouchEvent) => {
    if (cameraTouchId.current !== null) return;
    const touch = e.changedTouches[0];
    cameraTouchId.current = touch.identifier;
    lastTouchPos.current = { x: touch.clientX, y: touch.clientY };
  }, []);

  const handleCameraTouchMove = useCallback((e: TouchEvent) => {
    if (cameraTouchId.current === null || !lastTouchPos.current) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === cameraTouchId.current) {
        const dx = touch.clientX - lastTouchPos.current.x;
        const dy = touch.clientY - lastTouchPos.current.y;
        lastTouchPos.current = { x: touch.clientX, y: touch.clientY };

        const sensitivity = 0.005;
        onRotateCamera(dx * sensitivity, dy * sensitivity);
        break;
      }
    }
  }, [onRotateCamera]);

  const handleCameraTouchEnd = useCallback((e: TouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === cameraTouchId.current) {
        cameraTouchId.current = null;
        lastTouchPos.current = null;
        break;
      }
    }
  }, []);

  useEffect(() => {
    window.addEventListener('touchmove', handleJoystickMove, { passive: false });
    window.addEventListener('touchend', handleJoystickEnd);
    window.addEventListener('touchcancel', handleJoystickEnd);

    window.addEventListener('touchmove', handleCameraTouchMove, { passive: false });
    window.addEventListener('touchend', handleCameraTouchEnd);
    window.addEventListener('touchcancel', handleCameraTouchEnd);

    return () => {
      window.removeEventListener('touchmove', handleJoystickMove);
      window.removeEventListener('touchend', handleJoystickEnd);
      window.removeEventListener('touchcancel', handleJoystickEnd);

      window.removeEventListener('touchmove', handleCameraTouchMove);
      window.removeEventListener('touchend', handleCameraTouchEnd);
      window.removeEventListener('touchcancel', handleCameraTouchEnd);
    };
  }, [handleJoystickMove, handleJoystickEnd, handleCameraTouchMove, handleCameraTouchEnd]);

  return (
    <div className="absolute inset-0 pointer-events-none select-none z-20 flex flex-col justify-between">
      {/* Top right quick shortcuts */}
      <div className="flex justify-end p-3 gap-2 pointer-events-auto">
        <button
          onClick={() => { soundManager.playClick(); onOpenSpillway(); }}
          className="bg-slate-900/80 backdrop-blur-md border border-cyan-500/40 text-cyan-300 px-3 py-2 rounded-xl flex items-center gap-1.5 shadow-lg active:scale-95 transition-all"
        >
          <Sliders className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-bold tracking-wide">SPILLWAY</span>
        </button>

        <button
          onClick={() => { soundManager.playClick(); onOpenTurbines(); }}
          className="bg-slate-900/80 backdrop-blur-md border border-emerald-500/40 text-emerald-300 px-3 py-2 rounded-xl flex items-center gap-1.5 shadow-lg active:scale-95 transition-all"
        >
          <Zap className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-bold tracking-wide">TURBINES</span>
        </button>

        <button
          onClick={() => { soundManager.playClick(); onOpenConstruction(); }}
          className="bg-slate-900/80 backdrop-blur-md border border-amber-500/40 text-amber-300 px-3 py-2 rounded-xl flex items-center gap-1.5 shadow-lg active:scale-95 transition-all"
        >
          <Hammer className="w-4 h-4 text-amber-400" />
          <span className="text-xs font-bold tracking-wide">BUILD</span>
        </button>

        <button
          onClick={() => { soundManager.playClick(); onOpenTownship(); }}
          className="bg-slate-900/80 backdrop-blur-md border border-indigo-500/40 text-indigo-300 px-3 py-2 rounded-xl flex items-center gap-1.5 shadow-lg active:scale-95 transition-all"
        >
          <Building2 className="w-4 h-4 text-indigo-400" />
          <span className="text-xs font-bold tracking-wide">TOWN</span>
        </button>

        <button
          onClick={() => { soundManager.playClick(); onOpenMissions(); }}
          className="bg-slate-900/80 backdrop-blur-md border border-rose-500/40 text-rose-300 px-3 py-2 rounded-xl flex items-center gap-1.5 shadow-lg active:scale-95 transition-all"
        >
          <Target className="w-4 h-4 text-rose-400" />
          <span className="text-xs font-bold tracking-wide">MISSION</span>
        </button>

        <button
          onClick={() => { soundManager.playClick(); onOpenMenu(); }}
          className="bg-slate-900/80 backdrop-blur-md border border-slate-700 text-slate-200 p-2 rounded-xl shadow-lg active:scale-95 transition-all"
        >
          <Menu className="w-5 h-5" />
        </button>
      </div>

      {/* Middle touch area for camera dragging */}
      <div 
        className="w-1/2 h-44 self-end pointer-events-auto touch-none"
        onTouchStart={handleCameraTouchStart}
      />

      {/* Bottom controls: Joystick (left) and Action buttons (right) */}
      <div className="flex justify-between items-end p-4 pb-6">
        {/* Virtual Joystick */}
        <div
          ref={joystickBaseRef}
          onTouchStart={handleJoystickStart}
          className="w-32 h-32 rounded-full bg-slate-900/60 backdrop-blur-md border-2 border-slate-500/40 flex items-center justify-center pointer-events-auto touch-none shadow-2xl relative"
        >
          <div
            className={`w-14 h-14 rounded-full transition-transform duration-75 flex items-center justify-center shadow-lg ${
              isJoystickActive ? 'bg-cyan-500 border border-white' : 'bg-slate-700/80 border border-slate-400/50'
            }`}
            style={{
              transform: `translate(${knobPos.x}px, ${knobPos.y}px)`,
            }}
          >
            <div className="w-4 h-4 rounded-full bg-white/60" />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3 pointer-events-auto">
          {/* Sprint Toggle */}
          {!inVehicle && (
            <button
              onClick={() => {
                soundManager.playClick();
                onSprintToggle(!isSprinting);
              }}
              className={`w-14 h-14 rounded-2xl flex flex-col items-center justify-center border font-bold text-xs shadow-xl active:scale-95 transition-all ${
                isSprinting
                  ? 'bg-amber-500 text-slate-950 border-amber-300'
                  : 'bg-slate-900/70 backdrop-blur-md text-slate-300 border-slate-700'
              }`}
            >
              <Activity className="w-5 h-5 mb-0.5" />
              RUN
            </button>
          )}

          {/* Jump Button */}
          {!inVehicle && (
            <button
              onClick={() => {
                soundManager.playClick();
                onJump();
              }}
              className="w-16 h-16 rounded-2xl bg-cyan-600/90 text-white flex flex-col items-center justify-center border border-cyan-400 font-bold text-xs shadow-xl active:scale-95 transition-all"
            >
              <ArrowUp className="w-6 h-6 mb-0.5" />
              JUMP
            </button>
          )}

          {/* Vehicle Enter / Exit Button */}
          {(nearVehicle || inVehicle) && (
            <button
              onClick={() => {
                soundManager.playClick();
                onToggleVehicle();
              }}
              className={`px-4 h-16 rounded-2xl flex items-center gap-2 border font-bold text-xs shadow-xl active:scale-95 transition-all ${
                inVehicle
                  ? 'bg-rose-600 text-white border-rose-400'
                  : 'bg-blue-600 text-white border-blue-400 animate-pulse'
              }`}
            >
              <Car className="w-6 h-6" />
              <span>{inVehicle ? 'EXIT 4x4' : 'DRIVE 4x4'}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
