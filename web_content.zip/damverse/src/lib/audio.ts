class AudioManager {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private ambientGain: GainNode | null = null;

  private waterNoiseNode: AudioNode | null = null;
  private waterGain: GainNode | null = null;
  private turbineGain: GainNode | null = null;
  private engineGain: GainNode | null = null;
  private rainGain: GainNode | null = null;
  private engineOsc: OscillatorNode | null = null;

  private masterVol = 0.8;
  private sfxVol = 0.85;
  private ambientVol = 0.75;
  private isMuted = false;

  private init() {
    if (this.ctx) return;
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;

    this.ctx = new AudioContextClass();

    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.value = this.masterVol;
    this.masterGain.connect(this.ctx.destination);

    this.sfxGain = this.ctx.createGain();
    this.sfxGain.gain.value = this.sfxVol;
    this.sfxGain.connect(this.masterGain);

    this.ambientGain = this.ctx.createGain();
    this.ambientGain.gain.value = this.ambientVol;
    this.ambientGain.connect(this.masterGain);

    this.setupAmbientLoops();
  }

  public resume() {
    this.init();
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  private setupAmbientLoops() {
    if (!this.ctx || !this.ambientGain) return;

    // 1. Water Rush / Waterfall procedural pink noise generator
    const bufferSize = this.ctx.sampleRate * 2;
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      b3 = 0.86650 * b3 + white * 0.3104856;
      b4 = 0.55000 * b4 + white * 0.5329522;
      b5 = -0.7616 * b5 - white * 0.0168980;
      output[i] = b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362;
      output[i] *= 0.11;
      b6 = white * 0.115926;
    }

    const waterNoise = this.ctx.createBufferSource();
    waterNoise.buffer = noiseBuffer;
    waterNoise.loop = true;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 650;

    this.waterGain = this.ctx.createGain();
    this.waterGain.gain.value = 0.15;

    waterNoise.connect(filter);
    filter.connect(this.waterGain);
    this.waterGain.connect(this.ambientGain);
    waterNoise.start();
    this.waterNoiseNode = waterNoise;

    // 2. Turbine Hum (50Hz / 100Hz deep industrial drone)
    const turbineOsc1 = this.ctx.createOscillator();
    turbineOsc1.type = 'sine';
    turbineOsc1.frequency.value = 50.0; // 50 Hz grid frequency

    const turbineOsc2 = this.ctx.createOscillator();
    turbineOsc2.type = 'sawtooth';
    turbineOsc2.frequency.value = 100.0;

    const turbineFilter = this.ctx.createBiquadFilter();
    turbineFilter.type = 'lowpass';
    turbineFilter.frequency.value = 180;

    this.turbineGain = this.ctx.createGain();
    this.turbineGain.gain.value = 0.05;

    turbineOsc1.connect(turbineFilter);
    turbineOsc2.connect(turbineFilter);
    turbineFilter.connect(this.turbineGain);
    this.turbineGain.connect(this.ambientGain);

    turbineOsc1.start();
    turbineOsc2.start();

    // 3. Rain generator
    const rainNoise = this.ctx.createBufferSource();
    rainNoise.buffer = noiseBuffer;
    rainNoise.loop = true;

    const rainFilter = this.ctx.createBiquadFilter();
    rainFilter.type = 'bandpass';
    rainFilter.frequency.value = 2400;
    rainFilter.Q.value = 0.8;

    this.rainGain = this.ctx.createGain();
    this.rainGain.gain.value = 0.0; // Starts silent until rain triggers

    rainNoise.connect(rainFilter);
    rainFilter.connect(this.rainGain);
    this.rainGain.connect(this.ambientGain);
    rainNoise.start();

    // 4. Vehicle Engine Sound
    this.engineOsc = this.ctx.createOscillator();
    this.engineOsc.type = 'triangle';
    this.engineOsc.frequency.value = 45; // idle rpm

    const engineFilter = this.ctx.createBiquadFilter();
    engineFilter.type = 'lowpass';
    engineFilter.frequency.value = 220;

    this.engineGain = this.ctx.createGain();
    this.engineGain.gain.value = 0.0;

    this.engineOsc.connect(engineFilter);
    engineFilter.connect(this.engineGain);
    this.engineGain.connect(this.sfxGain);
    this.engineOsc.start();
  }

  public updateSimulationAudio(spillwayDischarge: number, activeTurbinesMW: number, isRaining: boolean) {
    if (!this.ctx) return;

    // Adjust water sound according to discharge
    if (this.waterGain) {
      const targetGain = Math.min(0.8, 0.08 + (spillwayDischarge / 600) * 0.6);
      this.waterGain.gain.setTargetAtTime(this.isMuted ? 0 : targetGain, this.ctx.currentTime, 0.5);
    }

    // Adjust turbine sound
    if (this.turbineGain) {
      const targetGain = activeTurbinesMW > 0 ? Math.min(0.4, 0.05 + (activeTurbinesMW / 500) * 0.25) : 0;
      this.turbineGain.gain.setTargetAtTime(this.isMuted ? 0 : targetGain, this.ctx.currentTime, 0.5);
    }

    // Adjust rain sound
    if (this.rainGain) {
      const targetRain = isRaining ? 0.35 : 0.0;
      this.rainGain.gain.setTargetAtTime(this.isMuted ? 0 : targetRain, this.ctx.currentTime, 0.8);
    }
  }

  public updateVehicleAudio(inVehicle: boolean, speedRatio: number) {
    if (!this.ctx || !this.engineGain || !this.engineOsc) return;

    if (!inVehicle) {
      this.engineGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.2);
    } else {
      const targetGain = this.isMuted ? 0 : 0.25;
      this.engineGain.gain.setTargetAtTime(targetGain, this.ctx.currentTime, 0.1);
      const targetFreq = 45 + speedRatio * 85; // 45Hz idle to 130Hz full rev
      this.engineOsc.frequency.setTargetAtTime(targetFreq, this.ctx.currentTime, 0.1);
    }
  }

  public playClick() {
    this.resume();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(400, this.ctx.currentTime + 0.04);
    gain.gain.setValueAtTime(0.15, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.04);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.05);
  }

  public playSiren() {
    this.resume();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    const t = this.ctx.currentTime;
    osc.frequency.setValueAtTime(650, t);
    osc.frequency.linearRampToValueAtTime(950, t + 0.7);
    osc.frequency.linearRampToValueAtTime(650, t + 1.4);

    gain.gain.setValueAtTime(0.35, t);
    gain.gain.linearRampToValueAtTime(0.01, t + 1.5);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 1.5);
  }

  public playConcretePour() {
    this.resume();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(140, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(60, this.ctx.currentTime + 0.4);
    gain.gain.setValueAtTime(0.3, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.4);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.45);
  }

  public setVolumes(master: number, sfx: number, ambient: number) {
    this.masterVol = master;
    this.sfxVol = sfx;
    this.ambientVol = ambient;
    if (this.ctx && this.masterGain && this.sfxGain && this.ambientGain) {
      this.masterGain.gain.value = master;
      this.sfxGain.gain.value = sfx;
      this.ambientGain.gain.value = ambient;
    }
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.value = this.isMuted ? 0 : this.masterVol;
    }
    return this.isMuted;
  }
}

export const soundManager = new AudioManager();
