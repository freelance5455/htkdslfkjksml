import * as THREE from 'three';
import { GraphicsPreset, WeatherType } from '../../types/game';

export class GameEngine {
  public scene: THREE.Scene;
  public camera: THREE.PerspectiveCamera;
  public renderer: THREE.WebGLRenderer;
  public sunLight: THREE.DirectionalLight;
  public ambientLight: THREE.AmbientLight;
  public hemiLight: THREE.HemisphereLight;
  
  private rainParticles: THREE.Points | null = null;
  private rainCount = 1200;
  private lightningLight: THREE.PointLight;

  private isDisposed = false;
  private animationFrameId: number | null = null;
  private onUpdateCallbacks: Array<(delta: number) => void> = [];

  constructor(container: HTMLElement, preset: GraphicsPreset = 'HIGH') {
    // 1. Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x87ceeb);
    this.scene.fog = new THREE.FogExp2(0x87ceeb, 0.0018);

    // 2. Camera
    const aspect = container.clientWidth / (container.clientHeight || 1);
    this.camera = new THREE.PerspectiveCamera(58, aspect, 0.5, 2500);
    this.camera.position.set(0, 150, 60);

    // 3. Renderer with hardware acceleration
    this.renderer = new THREE.WebGLRenderer({
      antialias: preset !== 'PERFORMANCE',
      powerPreference: 'high-performance',
      alpha: false,
    });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.applyGraphicsPreset(preset);

    container.appendChild(this.renderer.domElement);

    // 4. Lighting
    this.ambientLight = new THREE.AmbientLight(0xffffff, 0.45);
    this.scene.add(this.ambientLight);

    this.hemiLight = new THREE.HemisphereLight(0xddeeff, 0x334422, 0.4);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xfff8ee, 1.8);
    this.sunLight.position.set(180, 260, 140);
    this.sunLight.castShadow = preset !== 'PERFORMANCE';
    this.sunLight.shadow.mapSize.width = preset === 'HIGH' ? 2048 : 1024;
    this.sunLight.shadow.mapSize.height = preset === 'HIGH' ? 2048 : 1024;
    this.sunLight.shadow.camera.near = 10;
    this.sunLight.shadow.camera.far = 1000;
    const shadowD = 280;
    this.sunLight.shadow.camera.left = -shadowD;
    this.sunLight.shadow.camera.right = shadowD;
    this.sunLight.shadow.camera.top = shadowD;
    this.sunLight.shadow.camera.bottom = -shadowD;
    this.sunLight.shadow.bias = -0.0003;
    this.scene.add(this.sunLight);

    // Lightning light for monsoon thunderstorms
    this.lightningLight = new THREE.PointLight(0xccddff, 0, 800);
    this.lightningLight.position.set(0, 300, 0);
    this.scene.add(this.lightningLight);

    // Setup rain system
    this.initRainSystem();

    // Resize listener
    window.addEventListener('resize', this.onWindowResize);

    // Start loop
    this.startLoop();
  }

  private initRainSystem() {
    const rainGeom = new THREE.BufferGeometry();
    const positions = new Float32Array(this.rainCount * 3);
    for (let i = 0; i < this.rainCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 500;
      positions[i * 3 + 1] = Math.random() * 200 + 40;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 500;
    }
    rainGeom.setAttribute('position', new THREE.BufferAttribute(positions, 3));

    const rainMat = new THREE.PointsMaterial({
      color: 0xaaaaee,
      size: 1.4,
      transparent: true,
      opacity: 0.0, // hidden initially
    });

    this.rainParticles = new THREE.Points(rainGeom, rainMat);
    this.scene.add(this.rainParticles);
  }

  public applyGraphicsPreset(preset: GraphicsPreset) {
    const maxDPR = preset === 'HIGH' ? 1.5 : preset === 'BALANCED' ? 1.0 : 0.8;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, maxDPR));

    if (preset === 'PERFORMANCE') {
      this.renderer.shadowMap.enabled = false;
      this.sunLight.castShadow = false;
    } else {
      this.renderer.shadowMap.enabled = true;
      this.renderer.shadowMap.type = preset === 'HIGH' ? THREE.PCFSoftShadowMap : THREE.PCFShadowMap;
      this.sunLight.castShadow = true;
    }
  }

  public updateAtmosphere(gameTimeHours: number, weather: WeatherType) {
    // 0 to 24 hours day-night cycle
    const dayProgress = (gameTimeHours % 24) / 24;
    const sunAngle = dayProgress * Math.PI * 2 - Math.PI / 2;
    const sunDist = 320;

    const sunY = Math.sin(sunAngle) * sunDist;
    const sunX = Math.cos(sunAngle) * sunDist;
    this.sunLight.position.set(sunX, Math.max(-50, sunY), 120);

    const isNight = sunY < 15;
    const isDawnDusk = sunY >= 15 && sunY < 80;

    if (isNight) {
      // Night sky
      this.scene.background = new THREE.Color(0x060c18);
      if (this.scene.fog) {
        (this.scene.fog as THREE.FogExp2).color.setHex(0x060c18);
        (this.scene.fog as THREE.FogExp2).density = 0.0022;
      }
      this.sunLight.intensity = 0.15;
      this.sunLight.color.setHex(0x7799cc); // Moonlight
      this.ambientLight.intensity = 0.22;
    } else if (isDawnDusk) {
      // Golden hour
      this.scene.background = new THREE.Color(0xdf8450);
      if (this.scene.fog) {
        (this.scene.fog as THREE.FogExp2).color.setHex(0xd57b45);
        (this.scene.fog as THREE.FogExp2).density = 0.0025;
      }
      this.sunLight.intensity = 1.4;
      this.sunLight.color.setHex(0xffaa66);
      this.ambientLight.intensity = 0.45;
    } else {
      // Daylight
      if (weather === 'monsoon_rain') {
        this.scene.background = new THREE.Color(0x3a4552);
        if (this.scene.fog) {
          (this.scene.fog as THREE.FogExp2).color.setHex(0x3a4552);
          (this.scene.fog as THREE.FogExp2).density = 0.0045;
        }
        this.sunLight.intensity = 0.6;
        this.ambientLight.intensity = 0.5;
      } else {
        this.scene.background = new THREE.Color(0x7bc4ef);
        if (this.scene.fog) {
          (this.scene.fog as THREE.FogExp2).color.setHex(0x7bc4ef);
          (this.scene.fog as THREE.FogExp2).density = 0.0016;
        }
        this.sunLight.intensity = 1.9;
        this.sunLight.color.setHex(0xfffaea);
        this.ambientLight.intensity = 0.55;
      }
    }

    // Rain particles
    if (this.rainParticles) {
      const mat = this.rainParticles.material as THREE.PointsMaterial;
      if (weather === 'monsoon_rain') {
        mat.opacity = 0.75;
        // Random lightning strike
        if (Math.random() < 0.015) {
          this.lightningLight.intensity = 18;
          setTimeout(() => {
            if (this.lightningLight) this.lightningLight.intensity = 0;
          }, 80);
        }
      } else {
        mat.opacity = 0.0;
        this.lightningLight.intensity = 0;
      }
    }
  }

  private onWindowResize = () => {
    if (!this.renderer.domElement.parentElement) return;
    const parent = this.renderer.domElement.parentElement;
    const width = parent.clientWidth;
    const height = parent.clientHeight;
    this.camera.aspect = width / (height || 1);
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  public onUpdate(callback: (delta: number) => void) {
    this.onUpdateCallbacks.push(callback);
  }

  private startLoop() {
    let lastTime = performance.now();
    const animate = (time: number) => {
      if (this.isDisposed) return;
      this.animationFrameId = requestAnimationFrame(animate);

      const delta = Math.min((time - lastTime) / 1000, 0.1);
      lastTime = time;

      // Update rain particle positions
      if (this.rainParticles && (this.rainParticles.material as THREE.PointsMaterial).opacity > 0.05) {
        const positions = this.rainParticles.geometry.attributes.position.array as Float32Array;
        for (let i = 0; i < this.rainCount; i++) {
          positions[i * 3 + 1] -= delta * 180;
          if (positions[i * 3 + 1] < 20) {
            positions[i * 3 + 1] = 200 + Math.random() * 40;
          }
        }
        this.rainParticles.geometry.attributes.position.needsUpdate = true;
      }

      for (const cb of this.onUpdateCallbacks) {
        cb(delta);
      }

      this.renderer.render(this.scene, this.camera);
    };

    this.animationFrameId = requestAnimationFrame(animate);
  }

  public dispose() {
    this.isDisposed = true;
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    window.removeEventListener('resize', this.onWindowResize);
    this.renderer.dispose();
  }
}
