import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { GameEngine } from '../game/engine/GameEngine';
import { DamWorld } from '../game/world/DamWorld';
import { WaterSystem } from '../game/water/WaterSystem';
import { PlayerController } from '../game/character/PlayerController';
import { VehicleController } from '../game/vehicles/VehicleController';
import { HydrologySim } from '../game/simulation/HydrologySim';
import { PowerGridSim } from '../game/simulation/PowerGridSim';

import { HUD } from '../components/HUD';
import { TouchControls } from '../components/TouchControls';
import { SpillwayModal } from '../components/SpillwayModal';
import { TurbineModal } from '../components/TurbineModal';
import { ConstructionModal } from '../components/ConstructionModal';
import { TownshipModal } from '../components/TownshipModal';
import { MissionsModal } from '../components/MissionsModal';
import { SettingsModal } from '../components/SettingsModal';

import { 
  GameSaveData, 
  GameSettings, 
  UserProfile, 
  WeatherType, 
  GraphicsPreset, 
  TownshipInfrastructure 
} from '../types/game';
import { SaveManager } from '../lib/gameSave';
import { soundManager } from '../lib/audio';

interface GameScreenProps {
  initialSaveData: GameSaveData;
  user: UserProfile | null;
  settings: GameSettings;
  onUpdateSettings: (newSettings: GameSettings) => void;
  onExitToMenu: () => void;
}

export const GameScreen: React.FC<GameScreenProps> = ({
  initialSaveData,
  user,
  settings,
  onUpdateSettings,
  onExitToMenu,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  // Engine refs
  const engineRef = useRef<GameEngine | null>(null);
  const worldRef = useRef<DamWorld | null>(null);
  const waterRef = useRef<WaterSystem | null>(null);
  const playerRef = useRef<PlayerController | null>(null);
  const vehicleRef = useRef<VehicleController | null>(null);

  // Simulation State
  const [saveData, setSaveData] = useState<GameSaveData>(initialSaveData);
  const [gridState, setGridState] = useState(() => PowerGridSim.updateGrid(174, 180));
  const [inVehicle, setInVehicle] = useState(false);
  const [nearVehicle, setNearVehicle] = useState(false);
  const [isSprinting, setIsSprinting] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [saveStatus, setSaveStatus] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  // Modal Dialogs State
  const [activeModal, setActiveModal] = useState<
    'spillway' | 'turbines' | 'construction' | 'township' | 'missions' | 'settings' | null
  >(null);

  // Movement input
  const moveInputRef = useRef({ x: 0, y: 0 });

  // Initialize 3D World
  useEffect(() => {
    if (!containerRef.current) return;

    soundManager.resume();

    // 1. Create Engine
    const engine = new GameEngine(containerRef.current, settings.graphicsPreset);
    engineRef.current = engine;

    // 2. Create Dam World
    const world = new DamWorld(engine.scene, saveData.damType);
    worldRef.current = world;

    // 3. Create Water System
    const water = new WaterSystem(engine.scene);
    waterRef.current = water;

    // 4. Create Player & Vehicle
    const player = new PlayerController(engine.scene, new THREE.Vector3(saveData.playerPos.x, saveData.playerPos.y, saveData.playerPos.z));
    playerRef.current = player;

    const vehicle = new VehicleController(engine.scene, new THREE.Vector3(12, 150.2, 0));
    vehicleRef.current = vehicle;

    // Simulation Loop
    let simAccumulator = 0;
    engine.onUpdate((delta) => {
      simAccumulator += delta;

      // Update atmosphere & day/night
      engine.updateAtmosphere(saveData.gameTimeHours, saveData.reservoir.weather);

      const isNight = Math.sin(((saveData.gameTimeHours % 24) / 24) * Math.PI * 2 - Math.PI / 2) * 320 < 15;
      world.updateNightLighting(isNight);
      world.updateGates(saveData.reservoir.spillwayGatePercent);

      // Water visual update
      water.update(delta, saveData.reservoir.waterLevelM, saveData.reservoir.spillwayGatePercent);

      // Player or Vehicle control
      if (inVehicle) {
        vehicle.update(delta, moveInputRef.current, isNight, engine.camera);
        // Sound for vehicle
        soundManager.updateVehicleAudio(true, Math.abs(vehicle.speed) / 32.0);
      } else {
        player.update(delta, moveInputRef.current, isSprinting, engine.camera);
        soundManager.updateVehicleAudio(false, 0);

        // Check proximity to vehicle
        const distToVehicle = player.position.distanceTo(vehicle.position);
        setNearVehicle(distToVehicle < 4.2);
      }

      // Discrete step hydrology & power physics every 0.1s
      if (simAccumulator >= 0.1) {
        const simDelta = simAccumulator;
        simAccumulator = 0;

        // Head across dam
        const netHeadM = Math.max(0, saveData.reservoir.waterLevelM - saveData.reservoir.tailwaterLevelM);

        // Update turbines
        const { updatedTurbines, totalPowerMW, totalFlowCms } = PowerGridSim.updateTurbines(
          saveData.turbines,
          netHeadM
        );

        // Update grid frequency
        const grid = PowerGridSim.updateGrid(totalPowerMW, 180);
        setGridState(grid);

        // Update finances
        const finances = PowerGridSim.updateFinances(saveData.finances, totalPowerMW, simDelta);

        // Update hydrology
        const res = HydrologySim.update(saveData.reservoir, totalFlowCms, simDelta);

        // Update game time (1 real sec = 2.5 in-game minutes)
        const nextTime = (saveData.gameTimeHours + (simDelta * 2.5) / 60) % 24;

        setSaveData((prev) => ({
          ...prev,
          reservoir: res,
          turbines: updatedTurbines,
          finances,
          gameTimeHours: nextTime,
          playerPos: {
            x: player.position.x,
            y: player.position.y,
            z: player.position.z,
            inVehicle,
          },
        }));

        // Update procedural Web Audio
        soundManager.updateSimulationAudio(
          res.spillwayDischargeCms,
          totalPowerMW,
          res.weather === 'monsoon_rain'
        );
      }
    });

    return () => {
      engine.dispose();
    };
  }, []); // Run once on mount

  // Auto-Save interval every 60 seconds
  useEffect(() => {
    const timer = setInterval(async () => {
      await SaveManager.saveGame(saveData, user?.id);
    }, 60000);
    return () => clearInterval(timer);
  }, [saveData, user]);

  // Touch Movement Input
  const handleMove = useCallback((input: { x: number; y: number }) => {
    moveInputRef.current = input;
  }, []);

  const handleRotateCamera = useCallback((deltaYaw: number, deltaPitch: number) => {
    if (playerRef.current && !inVehicle) {
      playerRef.current.rotateCamera(deltaYaw, deltaPitch);
    }
  }, [inVehicle]);

  const handleJump = useCallback(() => {
    if (playerRef.current && !inVehicle) {
      playerRef.current.jump();
    }
  }, [inVehicle]);

  const handleToggleVehicle = useCallback(() => {
    if (!vehicleRef.current || !playerRef.current) return;

    if (!inVehicle) {
      // Enter Vehicle
      vehicleRef.current.isPlayerInside = true;
      playerRef.current.setVisible(false);
      setInVehicle(true);
    } else {
      // Exit Vehicle
      vehicleRef.current.isPlayerInside = false;
      const exitPos = vehicleRef.current.getDriverExitPos();
      playerRef.current.position.copy(exitPos);
      playerRef.current.mesh.position.copy(exitPos);
      playerRef.current.setVisible(true);
      setInVehicle(false);
    }
  }, [inVehicle]);

  const handleToggleWeather = useCallback(() => {
    setSaveData((prev) => {
      const nextWeather: WeatherType = prev.reservoir.weather === 'monsoon_rain' ? 'clear' : 'monsoon_rain';
      return {
        ...prev,
        reservoir: {
          ...prev.reservoir,
          weather: nextWeather,
        },
      };
    });
  }, []);

  const handleManualSave = async () => {
    setIsSaving(true);
    const res = await SaveManager.saveGame(saveData, user?.id);
    setIsSaving(false);
    if (res.cloud) {
      setSaveStatus('Synced to Supabase Cloud Database!');
    } else {
      setSaveStatus('Saved securely to local storage!');
    }
    setTimeout(() => setSaveStatus(null), 3500);
  };

  return (
    <div className="fixed inset-0 bg-slate-950 overflow-hidden select-none">
      {/* 3D WebGL Canvas Viewport */}
      <div ref={containerRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Top HUD Telemetry */}
      <HUD
        reservoir={saveData.reservoir}
        finances={saveData.finances}
        grid={gridState}
        gameTimeHours={saveData.gameTimeHours}
        weather={saveData.reservoir.weather}
        onToggleWeather={handleToggleWeather}
        isMuted={isMuted}
        onToggleMute={() => setIsMuted(soundManager.toggleMute())}
      />

      {/* Touch Controls (Virtual Joystick, Camera drag, Actions) */}
      <TouchControls
        onMove={handleMove}
        onRotateCamera={handleRotateCamera}
        onJump={handleJump}
        onSprintToggle={setIsSprinting}
        isSprinting={isSprinting}
        nearVehicle={nearVehicle}
        inVehicle={inVehicle}
        onToggleVehicle={handleToggleVehicle}
        onOpenSpillway={() => setActiveModal('spillway')}
        onOpenTurbines={() => setActiveModal('turbines')}
        onOpenConstruction={() => setActiveModal('construction')}
        onOpenTownship={() => setActiveModal('township')}
        onOpenMissions={() => setActiveModal('missions')}
        onOpenMenu={() => setActiveModal('settings')}
      />

      {/* Modals */}
      {activeModal === 'spillway' && (
        <SpillwayModal
          reservoir={saveData.reservoir}
          onUpdateGates={(pct) => {
            setSaveData((prev) => ({
              ...prev,
              reservoir: { ...prev.reservoir, spillwayGatePercent: pct },
            }));
          }}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'turbines' && (
        <TurbineModal
          turbines={saveData.turbines}
          grid={gridState}
          onToggleTurbine={(id) => {
            setSaveData((prev) => ({
              ...prev,
              turbines: prev.turbines.map((t) => (t.id === id ? { ...t, active: !t.active } : t)),
            }));
          }}
          onUpdateWicketGate={(id, pct) => {
            setSaveData((prev) => ({
              ...prev,
              turbines: prev.turbines.map((t) => (t.id === id ? { ...t, wicketGatePercent: pct } : t)),
            }));
          }}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'construction' && (
        <ConstructionModal
          stage={saveData.constructionStage}
          fundsRM={saveData.finances.fundsRM}
          onAdvanceStage={(nextStage, cost) => {
            setSaveData((prev) => ({
              ...prev,
              constructionStage: nextStage,
              finances: {
                ...prev.finances,
                fundsRM: Math.max(0, prev.finances.fundsRM - cost),
              },
            }));
          }}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'township' && (
        <TownshipModal
          township={saveData.township}
          fundsRM={saveData.finances.fundsRM}
          onUpgrade={(field, cost) => {
            setSaveData((prev) => {
              const currentVal = prev.township[field];
              const nextVal = typeof currentVal === 'number' ? currentVal + (field === 'housesCount' ? 6 : field === 'solarFarmPanels' ? 25 : 15) : true;
              return {
                ...prev,
                finances: {
                  ...prev.finances,
                  fundsRM: Math.max(0, prev.finances.fundsRM - cost),
                },
                township: {
                  ...prev.township,
                  [field]: nextVal,
                },
              };
            });
          }}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'missions' && (
        <MissionsModal
          missions={saveData.missions}
          onClaimReward={(missionId, reward) => {
            setSaveData((prev) => ({
              ...prev,
              finances: {
                ...prev.finances,
                fundsRM: prev.finances.fundsRM + reward,
              },
              missions: prev.missions.map((m) => (m.id === missionId ? { ...m, isCompleted: true } : m)),
            }));
          }}
          onClose={() => setActiveModal(null)}
        />
      )}

      {activeModal === 'settings' && (
        <SettingsModal
          settings={settings}
          user={user}
          onUpdatePreset={(preset) => {
            if (engineRef.current) engineRef.current.applyGraphicsPreset(preset);
            onUpdateSettings({ ...settings, graphicsPreset: preset });
          }}
          onUpdateVolume={(master, sfx, ambient) => {
            soundManager.setVolumes(master, sfx, ambient);
            onUpdateSettings({ ...settings, masterVolume: master, sfxVolume: sfx, ambientVolume: ambient });
          }}
          onManualSave={handleManualSave}
          isSaving={isSaving}
          saveStatus={saveStatus}
          onExitToMenu={onExitToMenu}
          onClose={() => setActiveModal(null)}
        />
      )}
    </div>
  );
};
