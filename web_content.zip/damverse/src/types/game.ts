export type DamType = 'concrete_gravity' | 'rock_fill' | 'earth_fill';

export interface RegionInfo {
  id: string;
  name: string;
  state: string;
  district: string;
  damName: string;
  defaultDamType: DamType;
  catchmentAreaSqKm: number;
  annualRainfallMm: number;
  normalInflowCms: number;
  designCapacityMCM: number;
  maxHeightM: number;
  crestLengthM: number;
  installedCapacityMW: number;
  isPlayable: boolean;
  description: string;
  coordinates: { lat: number; lng: number };
}

export interface TurbineState {
  id: number;
  name: string;
  active: boolean;
  flowCms: number; // m3/s
  maxFlowCms: number;
  outputMW: number;
  ratedCapacityMW: number;
  efficiency: number; // 0.85 - 0.95
  bearingTempC: number;
  vibrationMmS: number;
  wicketGatePercent: number; // 0 - 100
}

export type WeatherType = 'clear' | 'overcast' | 'monsoon_rain';

export interface ReservoirState {
  waterLevelM: number; // e.g. 142.5m
  maxLevelM: number; // e.g. 160.0m
  crestLevelM: number; // e.g. 155.0m
  minOperatingLevelM: number; // e.g. 110.0m
  tailwaterLevelM: number; // e.g. 35.0m
  currentVolumeMCM: number; // Million Cubic Meters
  maxVolumeMCM: number;
  inflowCms: number; // m3/s
  spillwayGatePercent: number; // 0 - 100%
  spillwayDischargeCms: number; // calculated discharge
  environmentalFlowCms: number; // min required downstream flow
  totalOutflowCms: number;
  weather: WeatherType;
  floodAlarm: boolean;
  netStorageRateCms: number;
}

export interface GridState {
  frequencyHz: number; // Target 50.00 Hz
  targetDemandMW: number;
  totalGenerationMW: number;
  stabilityIndex: number; // 0.0 - 1.0
  blackoutRisk: boolean;
}

export interface Finances {
  fundsRM: number;
  totalRevenueRM: number;
  tariffPerKWhRM: number; // e.g. RM 0.38
  operatingExpensesPerHourRM: number;
  netRevenueRateRMPerHour: number;
}

export interface TownshipInfrastructure {
  housesCount: number;
  industrialParksCount: number;
  substationLevel: number;
  solarFarmPanels: number;
  batteryStorageMWh: number;
  waterTreatmentPlant: boolean;
  fishLadder: boolean;
  floodProtectionDyke: boolean;
  scadaAutomatedGates: boolean;
}

export interface ConstructionProgress {
  currentStage: number; // 1 to 8
  stageName: string;
  stageProgressPercent: number; // 0 - 100
  concretePouredM3: number;
  requiredConcreteM3: number;
  damHeightM: number;
  targetHeightM: number;
}

export interface GameMission {
  id: string;
  title: string;
  objective: string;
  rewardRM: number;
  isCompleted: boolean;
  progressPercent: number;
  category: 'construction' | 'energy' | 'hydrology' | 'township';
}

export interface GameSaveData {
  id?: string;
  userId?: string;
  slotNumber: number;
  saveName: string;
  regionId: string;
  damType: DamType;
  constructionStage: number;
  reservoir: ReservoirState;
  turbines: TurbineState[];
  finances: Finances;
  township: TownshipInfrastructure;
  missions: GameMission[];
  playerPos: { x: number; y: number; z: number; inVehicle: boolean };
  gameTimeHours: number; // 0 - 24
  updatedAt: string;
}

export interface UserProfile {
  id: string;
  email?: string;
  username: string;
  isGuest: boolean;
  reputation: number;
}

export type GraphicsPreset = 'HIGH' | 'BALANCED' | 'PERFORMANCE';

export interface GameSettings {
  graphicsPreset: GraphicsPreset;
  resolutionScale: number;
  shadows: boolean;
  postProcessing: boolean;
  masterVolume: number;
  sfxVolume: number;
  ambientVolume: number;
  musicVolume: number;
  touchSensitivity: number;
  invertY: boolean;
}
