# Ръководство за пускане само с телефон

## Какво е променено във v0.4
- Добавен е Docker/Render шаблон за публикуване на backend.
- Android APK build workflow приема `HORARY_API_BASE_URL` от GitHub Secret.
- Поправена е предварителната проверка за Луна без курс чрез пробване във времето; тя все още се нуждае от експертна валидация.
- Това не е компилиран APK и не е публикуван backend.

## Публикуване от телефон (необходимо е да се направи веднъж)
1. Направи GitHub repository и качи съдържанието на този ZIP (разархивирай го първо).
2. В Render създай Web Service от същия repository. Root directory: `backend`; Dockerfile path: `Dockerfile`. Задай `OPENAI_API_KEY` само ако искаш AI обяснения и имаш собствен API ключ. След успешен deploy тествай `https://ИМЕТО.onrender.com/health`.
3. В GitHub → Settings → Secrets and variables → Actions → New repository secret добави `HORARY_API_BASE_URL` със стойност `https://ИМЕТО.onrender.com` (без наклонена черта накрая).
4. В GitHub → Actions → Build debug APK → Run workflow. Изтегли artifact `HoraryAI-debug-apk` и отвори APK на телефона.

## Важно
- Ако не зададеш `OPENAI_API_KEY`, астрономическите факти ще се изчисляват, но няма да има пълно AI обяснение.
- Без `HORARY_API_BASE_URL` правилно зададен, Android приложението няма да се свърже.
- Free hosting може да заспива и да стартира бавно.
- Проектът още не е валидиран като пълна реализация на традиционните хорарни правила. Не използвай процента като реална вероятност.
