# Blade Android build

This is a ready-to-open Android Studio project wrapping the V5 Blade HTML game in a fullscreen Android WebView.

App name: Blade
Package: com.blade.game
Orientation: landscape

Open the project folder in Android Studio, let Gradle sync, then Build > Build APK(s).
The generated APK will be under app/build/outputs/apk/debug/.
