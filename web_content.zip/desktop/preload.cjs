// Безопасный мост между UI и Electron
const { contextBridge, ipcRenderer } = require("electron");
contextBridge.exposeInMainWorld("nova", {
  isDesktop: true,
  openExternal: (url) => ipcRenderer.invoke("nova:open-external", url),
  platform: () => ipcRenderer.invoke("nova:platform"),
  onDownload: (cb) => ipcRenderer.on("nova:download", (_e, d) => cb(d)),
  onOpenUrl: (cb) => ipcRenderer.on("nova:open-url", (_e, u) => cb(u)),
});
