const app=document.getElementById('app'); let time=''; let selected=new Set();
const seats=Array.from({length:60},(_,i)=>String.fromCharCode(65+Math.floor(i/10))+(i%10+1));
function home(){app.innerHTML=`<div class="wrap"><div class="logo">RMS MOVIE PLACE</div><div class="poster">MOVIE POSTER</div><button class="btn" style="width:100%" onclick="showtimes()">BOOK NOW • ₹50</button></div>`}
function showtimes(){app.innerHTML=`<div class="wrap"><h1>SELECT SHOWTIME</h1><div class="times">${['10:00 AM','1:00 PM','4:00 PM','7:00 PM'].map(t=>`<button class="btn" onclick="seatScreen('${t}')">${t}</button>`).join('')}</div></div>`}
function seatScreen(t){time=t;selected=new Set();renderSeats()}
function renderSeats(){app.innerHTML=`<div class="wrap"><h1>SELECT YOUR SEATS</h1><div>SCREEN</div><div class="seats">${seats.map(s=>`<button class="seat ${selected.has(s)?'selected':''}" onclick="toggle('${s}')">${s}</button>`).join('')}</div><div class="bar"><div><b>Selected:</b> ${selected.size} seats &nbsp; <b>Total:</b> ₹${selected.size*50}</div><button class="btn" ${selected.size?'':'disabled'} onclick="confirmBooking()">BOOK TICKETS</button></div></div>`}
function toggle(s){selected.has(s)?selected.delete(s):selected.add(s);renderSeats()}
function confirmBooking(){app.innerHTML=`<div class="wrap"><div class="card"><h1>✓ BOOKING CONFIRMED</h1><p>RMS MOVIE PLACE</p><p>Show: ${time}</p><p>Seats: ${[...selected].sort().join(', ')}</p><h2>TOTAL ₹${selected.size*50}</h2><div class="qr"></div><button class="btn" onclick="home()">BACK TO HOME</button></div></div>`}
home();