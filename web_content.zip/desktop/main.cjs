// NovaBrowser Desktop — Electron (Chromium). Запуск: npm run desktop
// Загружает UI NovaBrowser (Next.js) и предоставляет нативные возможности:
// реальный Chromium <webview> вместо прокси-iframe, загрузки, системные уведомления.
const { app, BrowserWindow, session, shell, ipcMain, Menu, nativeTheme } = require("electron");
const path = require("path");

const APP_URL = process.env.NOVA_APP_URL || "http://localhost:3000";
const TRACKERS = ["doubleclick.net", "googlesyndication.com", "google-analytics.com", "googletagmanager.com", "mc.yandex.ru", "an.yandex.ru", "connect.facebook.net", "scorecardresearch.com", "hotjar.com", "criteo.com", "adfox.ru"];

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 480,
    minHeight: 600,
    title: "NovaBrowser",
    backgroundColor: nativeTheme.shouldUseDarkColors ? "#0b1020" : "#f8fafc",
    titleBarStyle: process.platform === "darwin" ? "hiddenInset" : "default",
    icon: path.join(__dirname, "..", "public", "icon.png"),
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      webviewTag: true, // настоящий Chromium-движок для вкладок
      sandbox: false,
    },
  });

  // Блокировка трекеров на уровне сети (все вкладки/webview)
  session.defaultSession.webRequest.onBeforeRequest({ urls: ["*://*/*"] }, (details, cb) => {
    const blocked = TRACKERS.some((t) => details.url.includes(t));
    cb({ cancel: blocked });
  });

  // HTTPS-проверка: предупреждение о невалидных сертификатах
  session.defaultSession.setCertificateVerifyProc((req, cb) => cb(req.verificationResult === "net::OK" ? 0 : -2));

  // Менеджер загрузок
  session.defaultSession.on("will-download", (_e, item) => {
    item.once("done", (_ev, state) => {
      win.webContents.send("nova:download", { filename: item.getFilename(), url: item.getURL(), size: item.getTotalBytes(), state });
    });
  });

  win.webContents.setWindowOpenHandler(({ url }) => {
    win.webContents.send("nova:open-url", url);
    return { action: "deny" };
  });

  win.loadURL(APP_URL);
  Menu.setApplicationMenu(null);
}

ipcMain.handle("nova:open-external", (_e, url) => shell.openExternal(url));
ipcMain.handle("nova:platform", () => ({ platform: process.platform, electron: process.versions.electron, chrome: process.versions.chrome }));

app.whenReady().then(() => {
  createWindow();
  app.on("activate", () => BrowserWindow.getAllWindows().length === 0 && createWindow());
});
app.on("window-all-closed", () => process.platform !== "darwin" && app.quit());
