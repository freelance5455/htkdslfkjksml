Agrawal Medical — Android Studio प्रोजेक्ट

यह Android WebView प्रोटोटाइप है। इसमें HTML expiry tracker ऐप में बंडल है।
यह APK फ़ाइल नहीं है; APK बनाने के लिए Android Studio और Android SDK चाहिए।

APK बनाने के चरण:
1. Android Studio इंस्टॉल करें (developer.android.com/studio).
2. Android Studio में इस फ़ोल्डर को Open करें।
3. Gradle sync पूरा होने दें और Android SDK Platform 35 इंस्टॉल करें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK आम तौर पर app/build/outputs/apk/debug/app-debug.apk में मिलेगा।

सीमाएँ:
- ऐप का डेटा इसी डिवाइस के WebView में लोकल सेव होता है।
- यह अभी कई कर्मचारियों के बीच डेटा साझा नहीं करता।
- यह बैकग्राउंड expiry notification नहीं भेजता।
- CSV डाउनलोड को APK में पूरी तरह सपोर्ट करने के लिए अगला डेवलपमेंट चरण चाहिए।
- असली मेडिकल उपयोग से पहले टेस्ट करें और स्थानीय नियमों के अनुसार expired medicines को अलग रखें।
