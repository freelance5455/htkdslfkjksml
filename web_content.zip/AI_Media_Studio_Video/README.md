# AI Media Studio — Android

A ready-to-open Android Studio project using a native Android WebView wrapper around a self-contained AI Media Studio web app.

## Included

- 18+ age gate
- Non-explicit adult glamour / boudoir / lingerie / pin-up / romance / fashion styles
- Text-to-image generation through the Pollinations image endpoint
- Multiple images: 1, 2, 4 or 6
- Aspect ratios: 1:1, 16:9, 9:16, 4:3
- Image size selection
- Image upload
- Client-side image editor: rotate, flip, brightness, contrast and saturation
- Generation history using localStorage, with individual delete and Delete All History
- Open/save image controls
- Responsive Android UI
- No app-imposed total generation quota (provider/account limits still apply)

## Open in Android Studio

1. Extract this ZIP.
2. Open the `AI_Media_Studio_Android` folder in Android Studio.
3. Let Gradle sync and download the Android Gradle Plugin/dependencies.
4. Run on an Android phone/emulator.
5. To create an APK: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.

The app needs Internet access for AI image generation.

## Important

The app is designed for non-explicit adult imagery. It blocks prompts containing common explicit sexual-act/minor terms before sending them to the image service.


## Video generation
The Video tab supports text-to-video and image-to-video job submission through provider APIs. Add your own provider API key in the app. Video providers are asynchronous and usage-based; the app does not include a generation quota. Current provider documentation confirms asynchronous text/image-to-video workflows.
