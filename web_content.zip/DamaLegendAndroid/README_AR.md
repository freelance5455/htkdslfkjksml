# داما الأسطورة V8 — مشروع Android

هذا المشروع يغلّف ملف اللعبة HTML الأصلي داخل WebView ليصبح تطبيق Android.

## البناء
1. افتح المجلد `DamaLegendAndroid` في Android Studio.
2. انتظر مزامنة Gradle.
3. اختر Build ثم Build APK(s).
4. ثبّت ملف APK الناتج على الهاتف.

اللعبة تعمل محليًا من داخل التطبيق، وتدعم JavaScript وLocalStorage والصوت الموجود في اللعبة.
