پاکستانی کوائن ٹاس — Android پروجیکٹ

یہ ایک Android Studio پروجیکٹ ہے، تیار شدہ APK نہیں۔
APK بنانے کے لیے:
1) Android Studio میں اس فولڈر کو کھولیں۔
2) Gradle sync مکمل ہونے دیں۔
3) Build > Build Bundle(s) / APK(s) > Build APK(s) منتخب کریں۔
4) APK عام طور پر app/build/outputs/apk/debug/app-debug.apk میں ملے گی۔

گیم آف لائن چلتی ہے اور صرف فرضی پوائنٹس استعمال کرتی ہے۔
اس میں حقیقی رقم، ڈپازٹ، ادائیگی یا رقم نکلوانے کی سہولت شامل نہیں۔
