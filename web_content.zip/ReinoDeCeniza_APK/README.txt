REINO DE CENIZA - PROYECTO ANDROID

Este proyecto envuelve Reino_de_Ceniza_v44.html en un WebView Android.

REQUISITOS:
- Android Studio reciente
- Android SDK con Android 35

COMO SACAR EL APK:
1. Abrir esta carpeta en Android Studio.
2. Esperar a que Gradle sincronice.
3. Build > Build APK(s).
4. El APK aparecerá en app/build/outputs/apk/debug/app-debug.apk

El HTML original v44 se encuentra en:
app/src/main/assets/Reino_de_Ceniza.html

NOTA: En este entorno no está instalado Android SDK/Gradle, por eso no se pudo compilar el APK binario aquí. El proyecto está preparado para abrirlo y compilarlo en Android Studio.
