# ZEIN — Android starter

واجهة أولية مستقلة لتطبيق ZEIN، تجمع مساحة شخصية ومساحة أعمال في تجربة واحدة.

## ما يعمل الآن
- واجهة عربية RTL متجاوبة مع الهاتف والكمبيوتر.
- التنقل بين المساحة الشخصية ومساحة الأعمال.
- لوحة رئيسية وبطاقات إحصائية تجريبية.
- دليل جهات اتصال محلي.
- حفظ قنوات المنصات المختارة في Local Storage.
- صفحات صندوق وارد وAI وملفات ونشاط مع توضيح أنها نماذج أولية وليست تكاملات حقيقية.

## ما لم يتم تفعيله بعد
- تسجيل دخول حقيقي ومزامنة سحابية.
- استقبال/إرسال رسائل حقيقية من المنصات.
- مكالمات صوت وفيديو.
- نموذج AI متصل.
- تخزين ملفات سحابي.

كل منصة تحتاج OAuth وموافقة API رسمية وصلاحيات محددة. لا تطلب أو تخزن كلمات مرور حسابات التواصل. يجب وضع أسرار API في backend وليس داخل APK.

## المتطلبات
- Node.js 20 أو أحدث
- Android Studio حديث
- Android SDK وJDK متوافقان مع إصدار Android Gradle Plugin الذي ينشئه Capacitor

## إنشاء مشروع Android محلياً
من مجلد المشروع:

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

من Android Studio اختر Build > Build Bundle(s) / APK(s) > Build APK(s).

ملف APK الناتج يكون عادة في:
`android/app/build/outputs/apk/debug/app-debug.apk`

لإعادة تحديث ملفات الواجهة بعد أي تعديل:
```bash
npm run build
npx cap sync android
```

## الهيكل
- `index.html` نقطة دخول Vite.
- `app.js` منطق الواجهة التجريبية.
- `style.css` التصميم.
- `capacitor.config.json` هوية تطبيق Android: `com.zein.one`.
- `www/` نسخة الواجهة الساكنة المرجعية.

## المرحلة التالية
1. ربط Supabase Auth مع فصل personal/business عبر workspaces وعضويات.
2. جداول RLS للملفات وجهات الاتصال والقنوات والرسائل.
3. backend موحد للموصلات وwebhooks.
4. ربط المنصات واحدة تلو الأخرى حسب صلاحيات كل API.
5. اختبارات Android وتوقيع إصدار Release.


## Database foundation (next milestone)
A first ZEIN schema migration is included at `supabase/migrations/20261112000100_zein_foundation.sql`.
It is intentionally not applied to the existing HANIMEX Supabase project. Apply it only after creating a separate ZEIN project and reviewing the SQL/RLS policies.

## Guest-first startup update

The app opens directly in local guest mode. No login dialog is shown on launch. The profile menu exposes optional ZEIN authentication setup, which remains unavailable until a dedicated authentication backend is configured. Local features remain usable without an account. External platform cards do not claim a real connection; they explain that official OAuth/API integration is still required.

Validation performed: JavaScript syntax checks and a startup/interaction smoke test passed. A production Vite build was not completed because dependency installation timed out in this environment.


## ZEIN V5 — الواجهات العشر
- تم اعتماد الصفحة الرئيسية بأسلوب ZEIN الأزرق/البنفسجي مع بطاقة ترحيب وبانر رئيسي وشبكة 8 خدمات وأحدث المحادثات.
- من زر الإعدادات اختر «واجهة ZEIN كاملة» للتبديل بين 10 تصاميم: الملكي، المحيط، الغروب، الزمرد، الوردي، منتصف الليل، البساطة، الرمال، نيون المستقبل، والأناقة الرمادية.
- الاختيار يغيّر لوحة الألوان وشكل البطاقات والحواف والخلفيات، ويحفظ محلياً على الجهاز.
- تمت إضافة زر الإضافة السريعة في شريط الهاتف.
- تظل تكاملات المنصات والرسائل الحقيقية ومساعد AI بحاجة إلى ربط خدماتها الرسمية؛ لا تعرض النسخة التجريبية بيانات وهمية على أنها متصلة فعلياً.
