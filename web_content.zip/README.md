# MindMate AI — Flutter Local LLM Project

This is a Flutter source project reconstructed from the recovered MindMate web source. It is **not an APK** and no APK compilation has been performed.

## What is included

- Flutter/Dart application with a responsive MindMate-inspired dark workspace.
- Chat creation, recent conversations, saved/unsaved filters, rename and delete.
- Local chat persistence using SharedPreferences.
- JSON chat backup import/export.
- Dark/light/system theme selection.
- Qwen2.5-0.5B-Instruct GGUF Q4_K_M model download from Hugging Face on first setup.
- llama.cpp-backed Android inference through `llama_flutter_android`.
- No Gemini key, cloud inference endpoint, or AI API call.

## Requirements

- Flutter 3.24+ and Dart 3.3+
- Android Studio with Android SDK 35
- Android NDK 27.0.12077973
- Android 8.0 / API 26 or newer
- ARM64 Android device recommended; model requires several hundred MB of storage and adequate free RAM.

## Open and prepare

1. Extract this ZIP.
2. Open the `MindMate_Flutter` folder in Android Studio (or run `flutter pub get` there).
3. If Android Studio reports missing generated Flutter platform files, run `flutter create --platforms=android .` from the project root, then keep the app's `applicationId`, `minSdk`, NDK, manifest permission and `MainActivity` settings from this project.
4. Install Android SDK 35 and NDK `27.0.12077973` from SDK Manager.
5. Run `flutter pub get`.
6. Run on a physical ARM64 Android device.

This repository is source-only. Build an APK yourself from Android Studio when ready.

## Model

- Repository: https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF
- File: `qwen2.5-0.5b-instruct-q4_k_m.gguf`
- Direct download: `https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf`
- Approximate size: 491 MB (Hugging Face lists 491 MB).
- Saved under app-private Application Support storage in `models/`.
- First download requires internet. Later model inference runs on-device without an AI API or internet.

## Notes

- The native inference dependency is `llama_flutter_android: ^0.2.6`; see https://pub.dev/packages/llama_flutter_android.
- The model is Apache-2.0 licensed per its Hugging Face model card. Check the repository license before redistributing model weights.
- The model is not bundled in this ZIP. The app downloads it at first setup.
- The app currently targets Android. iOS and desktop local inference are not configured.
- A real device test is still required. No claim is made that this source has been built or run in this environment.
- The 0.5B model is lightweight; answer quality and speed depend on device memory and processor.
