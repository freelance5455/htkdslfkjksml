# AppsFuture AI — JARVIS Edition (Termux)

A beginner-friendly Android voice assistant project. It runs inside Termux and provides:
- Gemini AI chat (free-tier availability and limits depend on your Google AI Studio account/model)
- English/Hindi prompts and replies
- Speech input using Termux:API's Android speech recognizer
- Spoken replies using Termux:API TTS
- Launch a small allowlist of Android apps
- YouTube music/search via browser
- Coding help
- Basic phone actions: battery, torch, vibration, clipboard (where supported)

## Important
This is a **Termux Python project**, not a standalone APK. It does not secretly listen in the background, bypass Android permissions, unlock the phone, send messages, or change protected settings. Voice listening starts only when you tap the microphone button or type `voice` in the terminal. Android versions and device manufacturers may restrict some Termux:API actions.

## 1) Install apps
Install **Termux** and **Termux:API** from F-Droid (or the official Termux GitHub releases). Install both from the same source/signature:
- https://f-droid.org/packages/com.termux/
- https://f-droid.org/packages/com.termux.api/

Open Termux:API once if needed. Grant microphone, camera/torch and notification permissions when Android asks.

## 2) Install dependencies in Termux
Run:
```bash
pkg update && pkg upgrade -y
pkg install python termux-api -y
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 3) Configure Gemini
Create an API key at https://aistudio.google.com/apikey.
Then in Termux:
```bash
cd ~/AppsFutureAI
cp .env.example .env
nano .env
```
Put your key after `GEMINI_API_KEY=`. Save with Ctrl+O, Enter, Ctrl+X.
Never share your API key or commit `.env` to a public repository.

The default model is `gemini-2.5-flash`. If Google AI Studio does not offer that model to your key, change `GEMINI_MODEL` in `.env` to a currently available Flash model shown in AI Studio.

## 4) Start
Unzip/copy this folder to `~/AppsFutureAI`, then:
```bash
cd ~/AppsFutureAI
python app.py
```
Open the local dashboard in your Android browser:
`http://127.0.0.1:8765`

Keep Termux open while using the dashboard. To stop: press Ctrl+C in Termux.

## 5) Voice and commands
Tap the microphone in the dashboard, or type `voice` in the Termux terminal.
Examples:
- "Open YouTube"
- "Open WhatsApp"
- "Play Arijit Singh songs on YouTube"
- "What is numerical aperture?"
- "Write a C program for factorial"
- "Battery status"
- "Turn on torch" / "Turn off torch"

For music, the assistant opens a YouTube search page; playback and ads are controlled by YouTube.

## 6) Optional phone permissions
Termux:API commands are used only when available:
- `termux-speech-to-text`
- `termux-tts-speak`
- `termux-battery-status`
- `termux-torch`
- `termux-vibrate`
- `termux-clipboard-get`

If a command fails, check Termux:API installation and Android permissions. Not every phone supports every command.

## Troubleshooting
- **Gemini error 400/404:** check model name and API key; select an available Flash model in AI Studio.
- **429 quota:** free-tier rate limits or quota may have been reached. Wait or check AI Studio usage.
- **No speech input:** grant microphone permission and test `termux-speech-to-text` directly.
- **No TTS:** test `termux-tts-speak "Hello"` and check Android text-to-speech engine.
- **Dashboard not opening:** use `http://127.0.0.1:8765` on the same phone; keep the Python process running.
- **App not opening:** Android package names vary; edit `APP_PACKAGES` in `actions.py`.

## Security
This app only launches a fixed allowlist of app package IDs and exposes its local dashboard on loopback (`127.0.0.1`). Do not change the host to `0.0.0.0` unless you understand the security implications. API keys are stored locally in `.env`.
