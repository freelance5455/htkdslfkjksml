# Forex Signal Desk: build guide

Contents: `www/` holds the app (index.html, manifest, service worker, icons).

## Option A: Android APK (Capacitor)
Needs: Node.js 18+, Android Studio (with an Android SDK).

    npm install
    npx cap add android
    npx cap sync android
    npx cap open android

In Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
The debug APK is under android/app/build/outputs/apk/debug/.
To share it or publish it, use Build > Generate Signed Bundle / APK.

## Option B: Installable web app (no build, no APK)
Upload the contents of `www/` to any HTTPS static host (Netlify Drop, GitHub Pages, Cloudflare Pages).
Open the link in Chrome (Android) or Safari (iPhone) and use "Install app" / "Add to Home Screen".
It then opens full screen and works offline after the first load.

## Notes
- Change the app id in capacitor.config.json (appId) before publishing to Google Play.
- The font loads from Google Fonts online; offline it falls back to the phone's default font.
