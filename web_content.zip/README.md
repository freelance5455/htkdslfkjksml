# XJOX Tools

Alat harian berbahasa Indonesia: teks, generator, kalkulator, konversi, waktu, QR, dan berkas.

Semua pemrosesan berjalan di perangkat. Tidak ada akun. Isi alat tidak dikirim ke server.

## Yang bisa dipakai

- Penghitung dan perapian teks, salin, serta bagikan
- UUID, kata sandi kriptografis (tidak disimpan), angka acak, warna, teks pengisi
- Kalkulator, persentase, dan konversi panjang, berat, suhu, volume, serta ukuran berkas
- Jam, stopwatch, timer dengan alarm, selisih tanggal, dan hitung menuju tanggal
- Pembuat dan pemindai QR, pemeriksaan URL
- Info berkas lewat pemilih berkas
- Tema terang, gelap, atau mengikuti sistem
- Favorit dan riwayat lokal yang bisa dihapus

## Batasan

APK Android tidak dibuat di lingkungan ini karena Android SDK tidak tersedia. Aplikasi yang berjalan adalah versi web dengan perilaku yang sama: kamera, papan klip, berbagi, unduhan QR, dan notifikasi mengikuti kemampuan peramban.

Timer berhenti jika tab ditutup. Menolak izin kamera hanya mematikan pemindai.
