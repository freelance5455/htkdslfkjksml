# Streamly Android starter

This is an Android Studio project ZIP, **not a prebuilt APK**. It packages a mobile WebView shell and a small offline UI prototype.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder as an existing Gradle project.
3. Let Android Studio sync Gradle and install the Android SDK Platform 35 if prompted.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location.

## Current limitations
- Demo UI only; sample video cards are placeholders, not real video streams.
- Authentication, cloud database, uploads, comments/subscriptions, creator studio and moderation are not connected.
- No backend credentials or paid services are included.
- This starter has not been built or device-tested in this environment.

The project uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21.
