# Apex Circuit

A standalone 3D browser racing game built from the supplied Apex Circuit bundle. The runtime includes its bundled Three.js renderer and game logic; it has no npm runtime dependencies. The fonts are loaded from Google Fonts when online and fall back to system fonts offline.

## Play

Open `index.html` in a current desktop browser with WebGL 2 enabled. If your browser blocks local files, start the included server from this folder:

```powershell
node serve.mjs
```

Then open `http://127.0.0.1:4173` in your browser.

## Game features

- Five circuits and four selectable cars with different performance characteristics
- Race setup for 1, 2, 3, 5, or 8 laps; up to 7 AI opponents; three difficulty levels
- Day, dusk, and night racing with sunny, cloudy, and rainy weather
- Keyboard, gamepad, and touch controls; chase, cockpit, bumper, and TV cameras
- Speed, RPM, gear, position, lap timing, minimap, damage, pause, and results UI
- Tire smoke, rain spray, surface effects, shadows, bloom, motion blur, and adaptive render resolution
- Local persistence for settings and race selections

## Controls

- **W / Up:** accelerate
- **S / Down:** brake; hold while stopped to reverse
- **A / D / Left / Right:** steer
- **Space:** handbrake
- **C** or **1–4:** change camera
- **B:** look back while held
- **R:** reset car
- **Esc / P:** pause
- **M:** mute audio
- **F:** performance overlay

Touch devices display steering and pedal controls automatically. Gamepad input is supported where the browser exposes a connected controller.

## Project files

- `index.html` — game shell and menus
- `assets/index-CCT6ho80.css` — responsive UI and effects styling
- `assets/index-DmprUrSg.js` — bundled game runtime, rendering, physics, AI, tracks, cars, and HUD
- `serve.mjs` — dependency-free local development server

The supplied archive contained a production bundle rather than the original modular source project or standalone art files. The bundled JavaScript is included as delivered, with the accessibility, saved preferences, startup fallback, and reduced-motion improvements applied.
