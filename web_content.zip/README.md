# Snake Escape — Premium HTML5 Puzzle Game

A complete, production-ready, jungle-themed HTML5 mobile puzzle game built with pure Vanilla JavaScript ES6+, HTML5, CSS3, SVG, and the Web Audio API. Inspired by modern casual game aesthetics with 12 complete screens, 50 playable handcrafted mazes, and zero external runtime dependencies.

---

## 🎮 Game Concept & Rules

Guide cute cartoon snakes from their starting positions to their matching glowing exit portals inside ancient stone mazes.

- **Movement**: Snake slithers along available maze paths with smooth easing animations.
- **Walls & Obstacles**: Snakes cannot pass through ancient stone walls or maze boundaries.
- **Multi-Snake Coordination**: Higher levels feature 2, 3, or 4 snakes (Green, Blue, Orange, Purple) with color-matched exit portals. Coordinate moves so snakes don't block each other's paths!
- **Star Rating**:
  - ⭐⭐⭐ (3 Stars): Completed within par moves.
  - ⭐⭐ (2 Stars): Completed within par + 5 moves.
  - ⭐ (1 Star): Completed with extra moves.
- **Hints**: Powered by a Breadth-First Search (BFS) pathfinder that illuminates the shortest escape route.
- **Undo & Reset**: Full move history stack allowing multi-step undos or instant level reset.

---

## 📱 Supported Controls

### Mobile
- **Swipe Gestures**: Swipe UP, DOWN, LEFT, or RIGHT anywhere on the maze board.
- **Tap**: Tap adjacent tiles to move in that direction, or tap another snake to switch active control.

### Desktop & Keyboard
- **Arrow Keys** or **W / A / S / D**: Move active snake.
- **Mouse Click**: Click adjacent tiles to move, or click any snake to select.
- **H**: Activate Hint.
- **R**: Reset Level.
- **Ctrl + Z** or **Z**: Undo Move.
- **ESC** or **P**: Pause / Resume Game.

---

## 📂 Project Structure

```
/
├── index.html           # Master game entry with all 12 screens & modals
├── game.html            # Standalone gameplay route
├── levels.html          # Standalone level select route
├── settings.html        # Standalone settings route
├── how-to-play.html     # Standalone tutorial route
│
├── css/
│   ├── style.css        # Core design tokens, wooden banners, juicy 3D buttons
│   ├── responsive.css   # Viewport clamps, safe-area-insets, mobile/tablet/desktop
│   ├── animations.css   # Dynamic animations: snake breathing, fireflies, stars, confetti
│   └── game.css         # Maze grid, stone walls, glowing portals, HUD
│
├── js/
│   ├── app.js           # Bootstrapper, screen routing, and button wiring
│   ├── game.js          # Central game state orchestrator & loop
│   ├── levels.js        # 50 validated level definitions (Easy, Normal, Hard, Expert)
│   ├── player.js        # Movement execution, turn handling, multi-snake selection, undo stack
│   ├── snake.js         # Snake entity, segment interpolation, blinking eyes, tongue flick
│   ├── maze.js          # SVG maze renderer, 3D stone walls, glowing exit portals
│   ├── collision.js     # Collision engine (walls, grid borders, snake bodies, exits)
│   ├── level-manager.js # Level validator & BFS pathfinding solver
│   ├── progress.js      # Star calculation, completion tracking, level unlocking
│   ├── audio.js         # Web Audio API procedural sound & music synthesizer
│   ├── animation.js     # Particle system, confetti, star bursts, haptics
│   ├── input.js         # Unified touch, swipe, mouse, and keyboard listeners
│   ├── ui.js            # HUD updates, modal controller, toast notifications
│   ├── settings.js      # Settings management, dark mode, English/Hindi localization
│   └── storage.js       # Safe LocalStorage persistence with in-memory fallback
│
├── assets/
│   ├── svg/             # Scalable vector graphics (mascot, logo banner, sad snake, group)
│   ├── icons/           # Crisp SVG iconography (play, pause, home, restart, hint, undo, etc.)
│   └── audio/           # Procedural Web Audio documentation
│
└── README.md            # Game documentation and setup instructions
```

---

## 🚀 Setup & Launch Instructions

No build steps, compilers, or external servers are required.

### 1. Direct File Opening
Double-click `index.html` to launch the game directly in any modern browser (Chrome, Safari, Firefox, Edge).

### 2. Static Web Hosting
Host the folder directly with any static server:
```bash
# Python 3
python -m http.server 8080

# Or any web host (GitHub Pages, Netlify, Vercel, Firebase Hosting, Apache, Nginx)
```

---

## 🎨 Visual Features & Aesthetics

- **12 Dedicated Screens & Modals**:
  1. Splash Screen with animated loading bar and mascot
  2. Main Menu with 4 juicy 3D action buttons and floating leaves
  3. Level Select with 50 level cards across 4 difficulty tabs (Easy, Normal, Hard, Expert)
  4. Gameplay Screen with HUD, stone maze board, and action toolbar
  5. Level Complete Modal with popping golden stars and confetti
  6. Level Failed / Game Over Modal with worried snake and retry option
  7. Hint Modal with illuminated solution path
  8. Settings Screen with sound, music, vibration, dark mode, and language toggles
  9. How to Play Screen with illustrated step-by-step instructions
  10. Level Failed Screen
  11. Board Cleared Celebration Screen with 4 celebrating snakes
  12. Pause Screen with blur backdrop
- **Procedural Web Audio**: Zero external audio downloads. All pops, chimes, fanfares, and ambient pentatonic jungle marimba music are synthesized in real-time.
- **Original Vector Artwork**: 100% vector SVG graphics that scale crisply on 4K displays and mobile retina screens.

---

## 🌐 Browser Compatibility

Tested and compatible with:
- Desktop Chrome / Edge (Windows, macOS, Linux)
- Desktop Firefox
- Desktop Safari (macOS)
- Mobile Chrome (Android)
- Mobile Safari (iOS)

Responsive breakpoints tested:
- 320×568 (iPhone SE / compact)
- 375×667 (iPhone 8)
- 390×844 (iPhone 14)
- 412×915 (Pixel 7)
- 768×1024 (iPad Portrait)
- 1024×768 (iPad Landscape)
- 1366×768 / 1920×1080 (Desktop)

---

## 📄 License
MIT License. Free for casual gaming, commercial distribution, and mobile packaging.
