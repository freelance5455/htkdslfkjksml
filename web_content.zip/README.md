# Cubelyra Launcher — Web APK Builder Edition

This ZIP is a self-contained HTML/CSS/JavaScript launcher-style web app designed for converters that wrap web projects into Android APKs.

## How to use
1. Upload this ZIP to a web-to-APK service that accepts HTML/CSS/JavaScript projects.
2. Set `index.html` as the entry page if asked.
3. Set app name to `Cubelyra Launcher`.
4. Set orientation to portrait (or auto).
5. Build and install the APK.

## Important limits
This is a polished launcher-style interface and a web wrapper prototype. It does **not** contain Minecraft Java Edition, a Java runtime, Microsoft authentication, or the game-launching engine. Browsers and ordinary web-to-APK converters cannot launch Java Edition merely by displaying a Play button. The Play button checks whether an Android-compatible Java launcher has been installed; web wrappers generally cannot reliably open arbitrary Android packages. Use the official Minecraft website and a reputable compatible launcher for game files and account sign-in.

No passwords or account information are collected. No external scripts or remote assets are required for the UI.
