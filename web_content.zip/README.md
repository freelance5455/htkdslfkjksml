# Star 6 ⭐

مشروع Android بسيط لتطبيق متابعة المباريات.

## فتح المشروع
1. افتح المجلد في Android Studio.
2. انتظر انتهاء Gradle Sync.
3. اختر جهاز Android أو المحاكي.
4. اضغط Run ▶.
5. لإنشاء APK: Build > Generate App Bundles or APKs > Generate APKs.

## تعديل المباريات
افتح:
app/src/main/assets/script.js

ثم غيّر أسماء الفرق والأوقات.

## ملاحظة قانونية
التطبيق لا يحتوي على بث مباريات محمي بحقوق النقل. استخدم فقط روابط بث رسمية ومرخّصة.
