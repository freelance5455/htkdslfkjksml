# NASLAN WORLD ONLINE — Full Starter Package

Tamil + English Flutter Android UI for Flight, Hotel and Taxi booking requests.

## Included
- Flutter Android source (`lib/main.dart`)
- Firebase Core and Cloud Firestore dependencies
- Bilingual UI and request forms
- Date picker and required-field validation
- Local session request list
- Optional Firestore write (only after Firebase is configured)
- Firebase starter rules file
- Admin panel starter (read-only demo; needs Firebase web setup)
- Setup checklist

## Before you run
You need a computer (Windows/macOS/Linux), Flutter SDK and Android Studio.
This package does not include the generated Android Gradle/platform folders.

1. Extract the ZIP.
2. Open terminal in this folder and run:
   `flutter create .`
3. Run:
   `flutter pub get`
4. Configure Firebase for Android:
   - Create a project at https://console.firebase.google.com/
   - Add an Android app with your final package ID.
   - Install FlutterFire CLI and run `flutterfire configure`.
   - Enable Cloud Firestore.
5. Run `flutter run`.

## Build an APK
`flutter build apk --release`
Output: `build/app/outputs/flutter-apk/app-release.apk`

## Firestore security warning
Do not publish with open Firestore rules. Use Firebase Authentication, restrict admin access, and validate data server-side. The included `firestore.rules.example` denies all client access until you replace it with a reviewed, authenticated policy. This means cloud requests will not work until you configure proper rules.

## Admin panel
Open `admin_panel/index.html` as a UI preview. It is not yet connected to Firebase. Connect it using Firebase Web configuration and Authentication; do not expose service-account keys in a browser.

## Not included / requires third-party approval
- Live airline inventory and ticket issuance
- Live hotel inventory and reservations
- Taxi dispatch integration
- Payment gateway
- Production admin authentication and role permissions
- Business registration, legal terms, privacy policy and verified contact details

API keys and credentials must remain on a secure backend, not in the mobile app.
