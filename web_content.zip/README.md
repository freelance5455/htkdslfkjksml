# Detox

Quit what holds you back. A live timer, a ball pit, and an elephant who gets happier with every clean day.

**What you pick from:** NoScroll, NoFap, NoBooze, Drug free.

## Get your APK (pick one)

This zip is a complete Capacitor project: the app itself (`www/`) plus everything needed to wrap it as an Android app. The `android/` folder is generated for you in the first step, so it is not included.

### A. GitHub Actions (easiest, no installs, works from a phone browser)

1. Create a new **private** repository on GitHub and upload everything from this zip.
   - The workflow lives in `.github/workflows/build-apk.yml`. If your upload tool skipped hidden folders, create that path yourself and paste in the contents of `GITHUB-build-apk.yml`.
2. Open the **Actions** tab. The build starts by itself on every push (or press **Run workflow**).
3. After about 5 to 8 minutes, open the finished run and download **Detox-debug-apk** from *Artifacts*.
4. Unzip it, send `app-debug.apk` to your phone and tap it. Allow "install unknown apps" for your browser or files app when Android asks.

### B. Android Studio (on a computer)

Needs Node 20+, Java 21 and Android Studio.

```bash
npm install
npx cap add android
node scripts/patch-android.js
npx cap sync android
cd android && ./gradlew assembleDebug
```

The APK lands in `android/app/build/outputs/apk/debug/app-debug.apk`. (`npx cap open android` opens it in Android Studio instead.)

### C. A "website to APK" converter

Use `Detox-web.zip` (the same app, with `index.html` at the top level) in any HTML-to-APK tool. Everything works there except the native extras: the 8:00 reminder notification, haptics and the native share sheet fall back to nothing or to the browser equivalents.

## How it works

1. **Pick** what you are quitting, then **type when you last did it**. The date can be in the past.
2. The **timer** appears with the exact time since, counting live to the second. A ball is tossed into the air.
3. **Scroll down.** The night sky turns to day and you are in the **ball pit**. A mesh bag hangs at the top, the pit is nearly empty, and an elephant walks in and starts to play. A short story explains it all the first time.
4. Every clean day drops balls from the mesh bag into the pit. More balls, happier elephant. Milestones (7, 14, 30, 60, 90, 180, 365 days) drop a bonus.
5. **At 8:00 every morning** you confirm you were clean the day before. The bag cracks a little wider and the balls fall.
6. Scroll back up for the three buttons:

| Button | Meaning | What happens |
|---|---|---|
| Blue | Day passed | Nice blue balls drop into the pit |
| Yellow | Lapse | Different-coloured (yellow) balls roll in. The timer restarts by default (switch that off in Settings if you want a lapse to leave it running) |
| Purple | Relapse | One ball leaves the pit and the timer restarts |

Every action has an **Undo**. If you forget a few days, the app asks you about each missed day in order.

The **calendar** icon (top right) shows your whole journey in colour with a key at the bottom. The **gear** opens settings: reminder, lapse behaviour, adjust the last time, guardians, replay the story, start over.

## Guardians (two people who can press Lapse or Relapse for you)

Guardians do not need the app. They open a private link in any browser and get a small page with a live timer and two buttons: **Lapse** and **Relapse**. They can never press *Day passed*. Your app picks up what they pressed within about 20 seconds of being open.

For that to work, your phone and your guardians need a tiny shared mailbox (a "relay"). It is free, and you set it up once:

1. Make a free Cloudflare account and open **Workers & Pages**.
2. Create a Worker, choose **Edit code**, paste in `server/worker.js` and deploy.
3. In the Worker settings add a **KV namespace** binding named `DETOX`.
4. Copy the Worker address (it ends in `workers.dev`).
5. In Detox: **Settings → Guardians**, paste the address, **Connect**, then **Invite someone**. Share the link it gives you.

The relay stores only your timer state and guardian names. Your key is hashed, guardians use their own bearer links, they are rate limited, and you can remove a guardian at any time (their link dies instantly).

## Project layout

```
www/                 the app (plain HTML, CSS, JS, no build step)
  js/core.js         all the rules: days, check-ins, rewards, moods (unit tested)
  js/elephant.js     the elephant, drawn in code
  js/pitballs.js     ball physics and rendering
  js/bag.js          the mesh bag and its cracks
  js/pit.js          the pit scene and the first-run story
server/worker.js     the guardian relay (Cloudflare Worker)
scripts/             icon generator and the Android patch script
resources/           generated launcher and notification icons
tests/, server/test.js   run with: npm test
```

## Troubleshooting

- **The workflow did not start:** check that `.github/workflows/build-apk.yml` exists in the repository, and that Actions is enabled for it.
- **"App not installed" on the phone:** uninstall any older Detox first, then install again.
- **No 8:00 notification:** allow notifications for Detox in Android settings. On some phones also set the app's battery use to *Unrestricted*.
- **Time zones:** the 8:00 rule uses the phone's local time.
- **Release build for the Play Store:** this produces a debug APK, which is fine for your own phone. For the store, build a signed release in Android Studio (*Build → Generate Signed Bundle / APK*).
