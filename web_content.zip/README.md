# MathScore 14 — Student & Excel Update

Added:
- Edit student names and index numbers directly from the Students screen.
- Enter key moves to the next student while entering weekly scores; Tab also moves naturally to the next score field.
- Import Excel: full MathScore backup files restore all classes, students and scores; simple Name/Index spreadsheets are also supported.
- Export Excel: creates one workbook containing Classes, Students and Scores sheets for all classes.

All previous features are retained: multiple classes, academic years/terms, Edit Class, 14-week scoring and mobile-friendly UI.
