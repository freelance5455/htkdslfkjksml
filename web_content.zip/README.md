# AS Enterprises (v2)
Offline stock / sales / labour / wastage / expense / finance app. Data in phone localStorage (key AS_ENTERPRISES_V2); old V1 data is auto-migrated and never deleted.

## Quick use (no build)
Host the `www` folder (or open `www/index.html`) in Chrome on Android -> menu -> Add to Home screen.

## Build APK (Capacitor; needs Node 18+, Android Studio/JDK 17)
    npm install
    npm test
    npx cap add android
    npx cap sync android
    npx cap open android      # Build > Build APK(s)
Or: cd android && ./gradlew assembleDebug  -> android/app/build/outputs/apk/debug/app-debug.apk

## Rules
Available = Opening + Added - DirectSold - LabourTaken + Returned - StandaloneWastage (labour sold & wastage are inside "taken").
Labour Due = sum(sold x rate) + sum(wastage x wastage rate); Outstanding = Due - Online - Cash - Extra + Underpaid.
Cash Balance = direct sales + labour online + labour cash + extra - standalone wastage - expenses - finance - morning cash.
