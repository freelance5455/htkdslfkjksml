# KenZz Nokos

Website toko NOKOS dengan frontend HTML/CSS/JS dan backend Node.js/Express.

## Menjalankan di komputer / hosting Node
1. Install Node.js 20 atau lebih baru.
2. Ekstrak ZIP ini.
3. Buka terminal di folder proyek, jalankan `npm install`.
4. Jalankan `npm start`.
5. Buka `http://localhost:3000`.

## Menjalankan di Android
Gunakan editor/terminal Android yang mendukung Node.js, ekstrak proyek, lalu jalankan perintah yang sama. Untuk website publik, deploy ke hosting Node.js dan gunakan HTTPS.

## Fitur
- Daftar dan login (password di-hash dengan scrypt).
- Beranda dengan video promo terpasang, autoplay muted, tombol suara.
- Katalog 3 produk dan harga sesuai brief, dengan pilihan 190 negara/wilayah untuk tiap permintaan.
- Video promo diulang otomatis (loop). Autoplay audio tetap memerlukan tindakan pengguna karena aturan browser.
- Permintaan deposit dan riwayat deposit.
- Riwayat pesanan NOKOS.
- Profil dan unggah foto profil.
- Penyimpanan demo berbasis `data.json`.

## Penting sebelum dipakai sungguhan
- Ini starter project yang berjalan, belum sistem toko produksi. Data JSON cocok untuk uji coba satu server, bukan trafik besar.
- Deposit hanya dicatat sebagai permintaan. Integrasikan payment gateway resmi dan verifikasi webhook sebelum memberi saldo.
- Pesanan hanya dicatat sebagai antrean; belum terhubung ke pemasok nomor. Integrasikan pemasok legal dengan kontrak dan API resmi.
- Tidak ada jaminan WhatsApp centang biru. Verified badge/Meta Verified hanya dapat diterbitkan melalui proses resmi WhatsApp/Meta. Jangan menjual klaim centang biru palsu.
- Tambahkan HTTPS, rate limiting, validasi email, reset password, audit log, backup database, panel admin dengan otorisasi kuat, dan database produksi (PostgreSQL) sebelum peluncuran.
- Jangan gunakan nomor untuk spam, penipuan, atau menerima OTP tanpa izin.

Video promosi berada di `public/promo.mp4`. Browser biasanya memblokir autoplay dengan audio; video mulai otomatis dalam keadaan mute dan pengguna dapat menekan tombol suara.
