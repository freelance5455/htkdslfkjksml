Medical Study Hub — Version 3

Changes:
- Full-screen layout; removed narrow centered card.
- Removed accidental date/time text.
- Added Android media/file permissions.
- File chooser uses Android WebChromeClient and persistent app storage.
- Notes and pictures persist with localStorage.
- PDFs are stored in the app's private files directory.
- Package: com.medicalstudyhub.app
- Version 3.0
