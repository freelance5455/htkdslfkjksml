# Desejos PT

Mapa comunitário de desejos e descobertas para brasileiros em Portugal.

## Executar

```bash
npm start
```

Abra `http://localhost:3001`.

O servidor não precisa de dependências externas. O modo de demonstração transmite novas descobertas por SSE a cada alguns segundos para que o comportamento em tempo real possa ser testado. Em produção, substitua a memória do servidor por banco gerenciado e mantenha somente dados consentidos e localizações aproximadas.

## API

- `GET /api/wishes` — lista filtrável (`q`, `category`, `city`).
- `GET /api/summary` — métricas agregadas.
- `GET /api/events` — stream SSE de atualizações.
- `POST /api/wishes` — cria um novo desejo com consentimento.
