GESTIONNAIRE COMPLET - PATISSERIE & BOULANGERIE
Ready to upload to a website-to-APK builder
===========================================

WHAT IS IN THIS PACKAGE
  index.html     your whole app (the entry page, already at the root)
  manifest.json  app name, colours and icon
  icon.jpg       app icon - replace it with your own logo if you want
  README.md      this file


HOW TO GET THE APK (no account, no GitHub)
------------------------------------------
  1. Open a free "website to app" / "HTML to APK" builder that accepts a ZIP,
     for example webintoapp.com or appsgeyser.com.
  2. Choose the option to import your own HTML files / upload a ZIP.
  3. Upload THIS ZIP as it is (do not unzip it, do not rename it).
  4. Start page / entry page  ->  index.html
  5. App name                 ->  Gestionnaire Complet - Pâtisserie & Boulangerie
     (shorter name, for under the icon: Pâtisserie)
  6. Icon                     ->  icon.jpg (or your own 512x512 PNG)
  7. Start the build. The builder compiles the APK on its servers and gives you
     the download link or sends it to you.

  If the builder asks for a website address instead of files, give it the URL of
  your hosted app (see below) - but the ZIP is better: the files are then inside
  the app and it works without internet.


IMPORTANT SETTINGS IN THE BUILDER
---------------------------------
  - DOM storage / localStorage   ->  ON   (this is what keeps your ingredients,
                                           recipes and units saved on the phone)
  - JavaScript                   ->  ON
  - File access / downloads      ->  ON   (only needed for the backup/restore buttons)
  - Offline mode / bundled files ->  ON   (the app then works without internet)

  Without DOM storage the app forgets everything as soon as it is closed.


GOOD TO KNOW
------------
  - The app works offline. Its data is stored inside the app on the phone.
  - Free builders usually add their own splash screen or advertisement; paid
    plans remove it. Compare two builders before publishing.
  - index.html was not modified in any way.
