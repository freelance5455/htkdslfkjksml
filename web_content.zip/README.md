# Pulguita IA v1.1 — núcleo propio y auditado

Esta versión conserva la interfaz y las funciones principales de v1.0, pero separa mejor el núcleo propio de cualquier servicio externo.

## Incluye

- Memoria local independiente por instalación.
- Perfil y relaciones del usuario.
- Perspectiva correcta: "tu mujer", "tu hijo", etc.
- Español e inglés con detección básica.
- Corrección de errores claros en ambos idiomas.
- Base lingüística compacta y ampliable.
- Matemáticas locales antes de cualquier conocimiento externo.
- Fracciones exactas.
- Álgebra simple.
- Raíces cuadradas/cúbicas/cuarta/quinta.
- Números escritos en español e inglés.
- Historial local.
- Recuperación de conocimiento local con umbral de confianza.
- Modo oscuro.
- Núcleo sin modelo comercial incorporado.

## Importante sobre "100% propio"

El código de Pulguita que está en `index.html` y `main.py` es el código específico desarrollado para este proyecto. La aplicación sigue necesitando Kivy y PyJNIus para ejecutarse como APK Android. Esas son dependencias técnicas de terceros con licencias abiertas y deben conservar sus avisos/licencias.

Esta versión NO incrusta un diccionario comercial ni un modelo de lenguaje de terceros.

La búsqueda web quedó desacoplada del núcleo: `searchAndLearn()` acepta una fuente externa como interfaz, guarda solamente el resumen, fuente y fecha. No hay una API comercial ni código de un buscador incrustado en la aplicación.

Para registrar el software, revisar las licencias y los componentes finales con un profesional si se va a comercializar o presentar formalmente.
