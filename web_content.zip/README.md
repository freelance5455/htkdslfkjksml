# NumberOne Android

Clean offline Android WebView wrapper for NumberOne.

- App: NumberOne
- Package: com.numberone.app
- Local HTML is bundled inside the APK
- No INTERNET permission
- No camera / microphone / SMS / contacts / location permissions
- Hardware acceleration enabled
- No advertising SDKs
- WebView lifecycle cleanup included

## Build
Open this folder in Android Studio, let Gradle sync, then:
Build -> Build App Bundle(s) / APK(s) -> Build APK(s)

Debug APK:
app/build/outputs/apk/debug/app-debug.apk
