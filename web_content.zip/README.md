# KILILA V16 FINAL — APKForge

ZIP listo para cargar en un constructor HTML/PWA → APK.

- `index.html` está en la raíz.
- No requiere Supabase para funcionar como prototipo local.
- Supabase queda preparado para una etapa posterior.
- Usuarios iniciales: Administrador PIN 1234 / Empleado PIN 1111.
- El administrador puede cambiar ambos PIN desde: Administración → Configuración → Usuarios y Seguridad.
- Los datos locales se guardan en el dispositivo mediante LocalStorage.
- La sincronización central real se implementará posteriormente con Supabase.
