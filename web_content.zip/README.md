# iPad OS Android

Progetto iniziale Android Studio: app APK con interfaccia tablet ispirata a iPadOS, responsive in verticale e orizzontale.

## Stato del progetto
- Sorgenti Android inclusi.
- Interfaccia Home HTML inclusa negli asset.
- Icone, Dock, widget dimostrativi, ricerca app, centro di controllo dimostrativo.
- Note salvate localmente, calcolatrice semplice e pannelli dimostrativi.
- **L'APK non è precompilato**: va generato con Android Studio.

## Come creare l'APK
1. Installa Android Studio sul computer dal sito ufficiale: https://developer.android.com/studio
2. Estrai lo ZIP.
3. In Android Studio scegli **Open** e seleziona la cartella `iPad_OS_Android`.
4. Attendi la sincronizzazione Gradle e installa i componenti SDK richiesti.
5. Per generare un APK di prova: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio mostrerà un collegamento al file APK generato. Copialo sul tablet e aprilo per installarlo, autorizzando l'installazione da quella sorgente se Android lo richiede.

## Limiti della prima versione
Questa è una normale app Android che mostra un'interfaccia simile a un sistema operativo, non un sistema operativo completo. I controlli Wi-Fi/Bluetooth, luminosità e volume del pannello sono dimostrativi e non cambiano le impostazioni reali di Android. I widget sono integrati nella schermata dell'app e non sono ancora widget di sistema Android. Per diventare un launcher predefinito e usare widget Android autentici servono ulteriori integrazioni native.
