# BuildMate AI Red + Preview

Added Preview and Code/AI Result tabs. When AI output includes a single-file HTML page, it is shown in a sandboxed iframe preview and can be downloaded as `index.html`.

Run on Node.js 18+: `npm install`, copy `.env.example` to `.env`, add the API key privately on the server, then `npm start`.

This remains a starter web project, not an APK or automatic native app compiler. Preview supports generated HTML/CSS/JS only.