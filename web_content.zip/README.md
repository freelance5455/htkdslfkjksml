# TrueMe

Folder-ka app-ka: **`web/`** (`web/index.html` waa app-ka oo dhan, `web/logo.png` waa logo-ga).

## Dhis APK (GitHub Actions)
1. Soo geli dhammaan faylasha repo-ga GitHub (isla qaabkan, `web/` oo ku jira).
2. **Actions → Build APK → Run workflow**.
3. Soo deji **TrueMe-debug-apk** (Artifacts) oo ku rakib telefoonka.

## Haddii aad isticmaasho APK builder kale (HTML → APK)
Isticmaal `TrueMe_flat.zip`: `index.html` wuxuu ku jiraa **xididka** zip-ka. Haddii builder-kaagu raadiyo `web/index.html`, isticmaal zip-ka mashruuca (wuxuu leeyahay `web/index.html` iyo `index.html` redirect ah).
Qalad "Web page not available / ERR_HTTP_RESPONSE_CODE_FAILURE" macnaheedu waa: builder-ku ma helin `index.html` meesha uu ka raadinayay.

## Firebase
- Config-ka waa `FB` ee `web/index.html` (project `trueme-59043`).
- Firebase Console: **Authentication → Sign-in method → Email/Password = Enabled**.
- **Firestore → Rules**: koobiyee `firestore.rules` oo **Publish** samee.
- App-ka: **Settings → Account & sync → Test connection** wuxuu hubiyaa dhammaan.
- Haddii builder-kaagu isticmaalo `appassets.androidplatform.net`, ku dar domain-kaas **Authentication → Settings → Authorized domains**.

## Ogeysiisyo
Ogeysiisyada asalka ah (background) waxay shaqeeyaan kaliya APK-ga Capacitor (workflow-ga halkan). Builder kale oo WebView caadi ah ma taageero.
