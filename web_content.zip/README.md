# CHALA GENERAL TRADING PLC — Android Studio Project

This project packages the supplied CHALA GENERAL TRADING PLC web app inside an Android WebView.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync and install any requested Android SDK components.
3. Select **Build > Generate App Bundles or APKs > Generate APKs**.
4. The debug APK will be under `app/build/outputs/apk/debug/`.

## Notes
- The original web assets are in `app/src/main/assets/`.
- JavaScript and DOM storage are enabled.
- The application ID is `com.coffeetrade.erp`.
- For a Play Store release, create a signed release build and configure a release keystore.


## WebView fix
The app uses AndroidX WebViewAssetLoader and loads the bundled web app from `https://appassets.androidplatform.net/assets/index.html`. Service-worker requests are routed through the same asset loader.
