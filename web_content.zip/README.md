# Fast & Fluffy — Android Studio project

This is the Android WebView shell around the self-contained HTML/JavaScript app. It supports a native **persistent notification countdown** while a fast is running, and a completion notification. The app works offline except for Open Food Facts lookups.

## Build an APK
1. Install Android Studio (with Android SDK 35 and JDK 17).
2. Open this directory as a project and let Gradle sync.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be in `app/build/outputs/apk/debug/app-debug.apk`. Copy it to your phone and install it, allowing installs from that source if prompted.

## Runtime
- The first launch prompts for Android 13+ notification permission. Allow for completion alerts.
- Starting a fast starts the foreground timer and persistent Android notification. The Android notification includes the system-rendered countdown chronometer.
- Ending or resetting the fast stops the timer service. A completion alert is generated when the service reaches the finish timestamp (roughly within 10 seconds when running).
- Android can terminate background services due to device/vendor battery settings. Completion alerts are **not guaranteed exact** under power restrictions.
- On relaunch, the app syncs the saved fast timestamp to the native service.
- Previous water entries remain stored in milliliters internally for backward compatibility, but **all displayed quantities and entry fields are in US fluid ounces**.

**Developer note:** `specialUse` foreground-service type is specified for Android 14+; Play Store distribution of this type may require a policy declaration and approval. This project is intended for personal installation.

## Verification
JavaScript syntax checked and mobile browser interaction tests run. **Native Android compilation, device installation, and real notification delivery require Android Studio/SDK; they were not verified in this environment.**
