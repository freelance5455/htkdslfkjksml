# TRAPBOUND: THE FINAL RUN

## Play
Open index.html in a current desktop browser. No network, account, external library, paid API, or downloaded asset is required. On Android, serve the folder over HTTP or package it in a WebView: some Android file managers do not launch local HTML with script permission. Landscape is recommended; portrait is supported with a following camera.

Optional local server: python3 -m http.server 8080
Then open http://localhost:8080. For a phone on the same LAN, use the computer's LAN address and port 8080. Network/firewall configuration is outside the game.

## Project
index.html: semantic shell and Canvas.
style.css: responsive menu and touch layout.
game.js: original Canvas art, 120 Hz simulation, Web Audio synthesis, deterministic level generation, menus, progression, settings, input, and engine checks.
tests.html: in-browser checks and manual QA checklist.
manifest.webmanifest: optional packaging metadata; not an offline service worker.

There are exactly 26 stages with 5 generated, deterministic arrangements each, not 5 levels reused under new labels. Every level has a spawn, floor geometry, hazards, and physical exit. Difficulty and traps vary by stage and slot. Geometry generation is constrained by the player's jump range. This is not evidence that every dynamic combination has been playtested.

## Controls
Default movement: A / D, Left / Right. Jump: Space / W / Up. Pause: Escape. Restart: R. Settings > Custom Controls remaps keys, swaps conflicts, adjusts touch size and horizontal/vertical offsets, and binds canvas left-click optionally. Touch buttons accept simultaneous pointers. Pause clears held inputs. Re-press held keys after resuming.

## Saves
Progress and settings use trapbound.v1 and trapbound.backup in localStorage. Saves are local to the browser and origin. Private browsing, blocked storage, or clearing site data can lose progress. Sequential completion unlocks the next level; completing slot 5 unlocks the next stage immediately. Replay never erases unlocks. Reset Progress requires confirmation.

## Audio
Press any game button to initialize Web Audio. Settings control master, music, effects, and mute. All effects and environment music are synthesized locally. Browser or OS mute still applies.

## Verification status
Executable checks cover stage counts, sequential unlocks, terminal progression, duplicate completion, save round-trips, malformed save sanitization, deterministic trap resets, baseline jump geometry, portal overlap guards, end/start/end relocation, collision overlap, and death/transition one-shot guards. Checks execute in the user's browser. The generated artifact has not been executed in a browser by the assistant, and no desktop/Android audio, pointer, or full 130-level playthrough is claimed. Review tests.html and record actual results before release.

## Android packaging
This is a web game, NOT an APK. A later Capacitor wrapper can use a www directory containing index.html, style.css, game.js, and manifest.webmanifest. Configure webDir as www and appId as an appropriate reverse-domain identifier, add Android, sync, and build using Android Studio and its SDK. Capacitor and Android build tools are development dependencies; the game runtime needs none. Verify safe areas, multitouch, audio focus, Android Back behavior, orientation, signing, and localStorage persistence in the actual wrapper. A manifest alone does not make an installable offline PWA.

## Release caveats
130 layouts are generated from deterministic design rules, not individually hand-authored or certified beatable by a solver. Collapsing and disappearing floors regenerate, pursuing hazards stop before the final terrace, reverse controls time out, and relocated exits retain traversable ground routes. The engine is intentionally lightweight rather than a production physics library. Static geometry checks cannot validate all hazard timing, landing order, or device-specific browser behavior. Run full playthrough and device QA before calling this a finished release.
