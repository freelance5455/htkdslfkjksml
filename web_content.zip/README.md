# My Sales Book - build the APK

You need: Node.js (LTS) and Android Studio (free). Windows, Mac or Linux.

1. Open a terminal in this folder and run:  npm install
2. Run:  npx cap add android
3. Run:  npx cap sync
4. Run:  npx cap open android   (opens Android Studio; wait for Gradle to finish)
5. In Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s)
6. Click "locate" in the popup. The file is android/app/build/outputs/apk/debug/app-debug.apk
7. Copy it to your phone, open it, and allow "install unknown apps" when asked.

Updating the app later: replace www/index.html, run  npx cap sync, then build again.

Important
- Your data lives inside the app. Uninstalling it deletes the data. Use Home > Save backup first.
- Installing over an older version keeps data only if both were signed with the same key.
  If Android asks you to uninstall first, save a backup, then restore it in the new app.
- For Play Store or a long-lived personal copy: Build > Generate Signed App Bundle / APK,
  create a keystore, and keep that keystore file and password safe forever.
