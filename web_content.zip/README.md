# TranzIndia AI Hiring Agent V1.0 – Mobile Prototype

This ZIP is a mobile-first PWA dashboard prototype that can be opened in a browser or wrapped by a compatible web-to-APK builder.

## Included and working
- Candidate creation, listing, status updates, deletion (stored locally on this device)
- Manual call-attempt log (does not place a phone call)
- Dashboard counts
- Backend HTTPS URL setting
- PWA manifest and service worker

## Not yet connected
- Real AI speech recognition / speech generation
- Real inbound or outbound telephone calls
- Cloud database / authentication / multi-device sync
- Exotel or another telephony provider

These require a separately deployed secure backend and provider credentials. Never put API keys or Exotel secrets in the Android app.

## Build
Upload this ZIP to a trusted HTML/PWA-to-APK cloud builder from your Android browser. Configure the app name as `TranzIndia AI Hiring Agent`, package ID `com.tranzindia.hiringagent`, and microphone permission only when the later voice-call module is integrated. Test the resulting APK before using it with candidates.
