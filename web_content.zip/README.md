# Strategy Tester Pro — Professional HTML Build

## Upload
This ZIP is deliberately structured so `index.html` is at the ZIP root. Upload the ZIP directly to an HTML-to-APK builder that accepts website ZIPs.

## What works offline
- Mobile-first professional terminal UI
- No hard-coded 5,000-candle ceiling
- Synthetic data generation: 12k default, 100k and 500k buttons
- CSV OHLCV import
- Bar-by-bar backtesting
- Long/short
- Risk sizing
- TP/SL
- Commission, slippage and spread
- Leverage
- Cooldown and max trades/day
- EMA, RSI, Bollinger, liquidity sweep/volume and HTF regime strategy adapters
- Equity curve
- Trade history
- CSV/JSON export
- Strategy rule builder
- Parameter sweep UI
- Monte Carlo resampling
- Walk-forward/robustness module foundation
- Portfolio workspace
- Market replay
- Local settings/backup
- Print/save-PDF through the device/browser print dialog

## Real-data note
Synthetic candles are for software testing only. For meaningful performance research, import real historical OHLCV data from your chosen exchange/broker/data vendor.

## Future adapters
The UI contains clean extension points for:
- Live exchange/broker APIs
- Tick/bid/ask data
- Historical news/events
- AI analysis
- Cloud sync
- Native notifications
- Advanced portfolio/corporate-action data

Those services require external APIs or native bridges and are not falsely represented as connected in this offline build.

## CSV
Recommended header:
time,open,high,low,close,volume

`time` may be an ISO date/time or a numeric timestamp.
