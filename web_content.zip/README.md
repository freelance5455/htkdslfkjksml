CryptoTrader v4.4 TR Teste

Alterações:
- Nome atualizado para "CryptoTrader v4.4 TR Teste".
- Removido o aviso informativo do topo.
- No primeiro arranque, a app analisa primeiro o histórico de 1h antes de permitir compras.
- São necessárias 3 análises iniciais e 2 confirmações consecutivas do sinal antes da primeira compra.
- O motor mostra quando está a analisar e quando está a confirmar um sinal.
- O trailing passa a adaptar o nível de ativação e o recuo à volatilidade de cada moeda:
  baixa: 2,5% / recuo 0,9%
  média: 3,5% / recuo 1,3%
  alta: 5,0% / recuo 1,8%
- Mantido PAPER TRADING e o restante funcionamento da v4.4.
