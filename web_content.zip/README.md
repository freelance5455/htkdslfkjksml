# Evolve Practice Test app

A mobile-friendly, installable web app built only from the supplied `Evolve_Mock_Computer_Test_with_Answers.pdf`. Once opened online the first time, the app and all question illustrations are saved for offline practice.

## Run it

1. Upload the complete folder to a static website host (for example, GitHub Pages or Netlify).
2. Open the hosted link in a browser. The app needs HTTPS for install and offline features; `localhost` also works for development.
3. Choose a section or the full 236-question test, then press **Start practice**.
4. Install it from the browser menu: choose **Install app** on desktop or **Add to Home Screen** on mobile.

The app has no account or build step. After the first load, practice works offline. Unfinished practice is saved in this browser on this device, so you can resume later. Completed results are not stored.

## Publish it

Upload the complete folder contents to any static website host. Keep `manifest.webmanifest`, `service-worker.js`, `index.html`, `styles.css`, `app.js`, `questions.js`, `questions.json`, and the `assets` folder at the same relative paths. No server code or environment variables are needed.

## What's included

- All 236 numbered questions, their three choices, and the correct answers marked in the PDF.
- Original question wording, extracted as selectable text; source illustrations for road signs and vehicle controls.
- Road rules, road signs, Motorcycle, combined Code 8 & Code 10, or full-test practice, with saved-session resume, question progress, instant feedback, scoring, answer review, and a searchable 236-question study answer key on the welcome screen.
- Clear question images sized to stay readable without taking over the screen.
- Keyboard arrow-key navigation between answer choices.
- `questions.json` for the question data and `questions.js` as the local browser-ready copy used by the page.

The quiz uses the answer markings present in the supplied PDF. It does not add or update driving-law information beyond that source.
