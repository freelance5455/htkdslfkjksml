
# Tala - Android App

This is your SMS + Dialer app packaged for Android.

## Features enabled for Android
- REAL SMS via android.permission.SEND_SMS - sends without opening other app
- REAL CALLS via android.permission.CALL_PHONE
- READ_CONTACTS, READ_SMS, READ_CALL_LOG
- Dialer FAB positioned higher with keyboard avoidance

## Quick Build (5 mins)

1. Install Node.js 18+ and Android Studio

2. Install deps:
   npm install

3. Add Android platform:
   npx cap add android

4. Sync web build:
   npx cap sync android

5. Open in Android Studio:
   npx cap open android

6. In Android Studio, edit:
   android/app/src/main/AndroidManifest.xml -> Add permissions:

   <uses-permission android:name="android.permission.SEND_SMS" />
   <uses-permission android:name="android.permission.READ_SMS" />
   <uses-permission android:name="android.permission.RECEIVE_SMS" />
   <uses-permission android:name="android.permission.CALL_PHONE" />
   <uses-permission android:name="android.permission.READ_CONTACTS" />
   <uses-permission android:name="android.permission.READ_CALL_LOG" />

7. For direct SMS sending, in MainActivity.java add SMS plugin.

8. Build APK: Build > Build Bundle(s) / APK(s) > Build APK(s)

The APK will be at android/app/build/outputs/apk/debug/app-debug.apk

## How Real SMS Works in This Build
In www/index.html we detect Capacitor:

if (window.Capacitor) {
  // use @capacitor/sms or custom native plugin to send
  SmsManager.send({ numbers: [number], text: message })
} else {
  // fallback to sms: intent
}

The file already has fallback logic - on Android it will use native.

## PWA Install Option
You can also install as PWA: open index.html in Chrome on Android > Add to Home Screen.

