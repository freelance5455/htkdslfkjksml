# P.A GAMING — protótipo

## Como testar
- Extraia o ZIP e abra `index.html` em um navegador moderno.
- Para instalar como PWA e testar o cache offline, publique os arquivos em HTTPS ou use um servidor local; Service Workers não funcionam em todo contexto de arquivo local.
- Este pacote ainda não é um APK. Para gerar APK é necessário empacotar/compilar com ferramentas Android.

## Incluído
- Interface responsiva em português brasileiro, tema escuro azul/verde neon.
- Cadastro/login local e senha mínima de 10 caracteres.
- Configuração inicial de administrador local.
- Seis pacotes fictícios editáveis, oferta especial e ativação/desativação.
- Pedidos simulados, código automático, ID do jogador, Pix/cartão simulados, estados e cancelamento.
- Painel administrativo com resumo e busca por código/ID.
- Perfil, FAQ, ajuste de texto, redução de efeitos, backup/importação JSON e reset com confirmação dupla.
- Cache PWA básico e aviso ao voltar a conexão sem envio automático.

## Limitações e segurança
- Não é APK compilado; é protótipo web/PWA.
- Armazenamento apenas local; não sincroniza entre dispositivos.
- Autenticação e proteção administrativa são demonstrativas e não equivalem a backend seguro. Não usar dados reais.
- Exportação usa JSON, não ZIP, e não inclui senhas.
- Recuperação segura de senha, bloqueio após tentativas, bloqueio administrativo após 5 minutos, notificações nativas Android e som/vibração reais ainda exigem desenvolvimento adicional.
- Compras e pagamentos são exclusivamente fictícios; não há integração de pagamento ou entrega de diamantes.
