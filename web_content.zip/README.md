# NIFTY SkillBacktest V1
PWA starter for NIFTY historical skill practice.

Included:
- Candlestick chart
- 2016–2026 year selector
- Replay / next-candle mode
- Drawing-tool UI
- BUY CE / BUY PE practice
- Entry / SL / Target
- Trade journal
- Win/loss/win-rate dashboard
- CSV export
- PWA manifest

IMPORTANT: The bundled candles are DEMO data, not real NIFTY market data. Real 2016–2026 data must be supplied through a properly licensed source.

Run locally with:
python -m http.server 8080

Then open http://localhost:8080

Next V2: real CSV import, persistent drawings, true date selection, indicators, P&L/R-multiple, IndexedDB persistence and richer replay.
