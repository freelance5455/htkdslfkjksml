# Finance Tracker
Upload these 4 files to the repo root (no folders): index.html, package.json, capacitor.config.json, README.md.
Create .github/workflows/build-apk.yml in the GitHub web editor and paste the text of build-apk.yml.
Run Actions -> Build APK, then download app-debug.apk from Releases.
