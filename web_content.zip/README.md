# GM Pay — version autonome

## Démarrage
Aucune installation ni Firebase n'est nécessaire pour tester cette version.

1. Ouvrir `index.html` dans un navigateur Android ou un ordinateur.
2. Créer un compte.
3. Pour tester un transfert, créer deux comptes sur le même appareil/navigateur et utiliser leurs numéros respectifs.
4. Les données de démonstration sont stockées dans `localStorage`.

## Important
Cette version est un prototype fonctionnel local. Elle ne constitue pas encore un service de paiement réel : il n'y a pas de serveur, de vraie monnaie électronique, de KYC, de chiffrement serveur, ni de connexion à une banque ou un opérateur mobile.

## Structure
- `index.html` : interface
- `style.css` : design responsive
- `app.js` : logique et stockage local

## Passage en vraie application
Pour un déploiement réel, il faudra ajouter un backend sécurisé, authentification robuste, base de données serveur, API de paiement, journalisation, contrôles antifraude et conformité réglementaire.
