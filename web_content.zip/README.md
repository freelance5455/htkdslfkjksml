# Laden Console (Flutter)

Горизонтальная консоль **Laden Console** — Flutter-проект для Android.

## Важно

В корне есть файл **`pubspec.yaml`** — это Flutter-проект.

## Требования

- Flutter 3.16+ (stable)
- Android Studio / VS Code
- Android SDK 34

## Запуск

```bash
# 1. Распакуйте архив и перейдите в папку
cd laden_console_flutter

# 2. Установите зависимости
flutter pub get

# 3. Подключите устройство / эмулятор
flutter devices

# 4. Запуск
flutter run

# 5. Сборка APK
flutter build apk --debug
# или
flutter build apk --release
```

APK будет здесь:
```
build/app/outputs/flutter-apk/app-debug.apk
```

## Возможности

- Главный экран (landscape)
- Laden Games / Приложения / Проводник / Магазин
- Установщик: `.zip` · `.apk` · `.html` · `.aik` · `.exe`
- Laden ID (гость или аккаунт)
- Виртуальная память ~30 ТБ
- Встроенный браузер
- HTML-игры внутри WebView

## Package

- Application ID: `com.laden.console`
- Orientation: landscape only
- Min SDK: 24
