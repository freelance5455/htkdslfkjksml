# MAHDI PLATFORM — Spck starter (v1)

## What this starter includes
- Email/password sign up and login via Supabase Auth
- Profile name and signed-in users list
- Text posts and optional media URL
- Likes and comments
- Private direct messages with row-level security
- White/blue responsive interface

## Important limitations in this first version
- Media is linked by URL; direct image/video upload and avatar upload are not enabled yet.
- Messages refresh when you open/refresh Chat; live Realtime subscriptions and unread counters are planned for the next step.
- This is a mobile web app source project, not an APK by itself.
- Do not use real sensitive information until you have tested policies thoroughly.

## Setup
1. Create a Supabase project at https://supabase.com/ and choose the Free plan if available.
2. Open SQL Editor -> New query. Paste all of `supabase-schema.sql`, then Run.
3. Open Project Settings -> API. Copy the Project URL and the anon/publishable key.
4. In `app.js`, replace:
   - `PASTE_YOUR_SUPABASE_PROJECT_URL_HERE`
   - `PASTE_YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY_HERE`
   with your project's values.
   Never put a `service_role` or secret key in `app.js`.
5. In Spck Editor, create a project and put `index.html`, `style.css`, and `app.js` in its root. Keep `supabase-schema.sql` for database setup.
6. Preview `index.html`. If module imports are blocked by a local-file preview, use a local/static HTTP preview or deploy the files to a static host, then test.
7. Create a test account, sign in from two separate test accounts/devices, create posts, and verify direct messages are visible only to the sender and receiver.

## Android APK plan
Spck edits the source but does not compile it into an APK. After the web app works, package it using a supported Android build workflow (for example Capacitor with an Android SDK/build environment or a cloud build service). That next stage may require additional setup and could have costs. Keep the Supabase backend and schema; the Android packaging layer can be added later.

## Security reminders
- Keep RLS enabled.
- Use only the anon/publishable key in client code.
- Never disable RLS to make an error disappear.
- Don't add admin/service-role keys to frontend files.
