# DreamyPlan — zero default subjects + Firebase login/cloud sync

This package updates the **existing DreamyPlan HTML app**. It does not create a separate demo.

## What changed

- **Zero predefined subjects**: the app starts with an empty subject list and has no startup/default subject array, no fallback subject, and no reset-to-default action.
- The Add Task and Calendar subject dropdowns show only user-created subjects. With no subjects, they show an empty-state prompt and task creation is blocked until the user adds a subject.
- Manage Subjects supports add, rename, delete, and remove-all-custom-subjects. Renames update linked tasks; deletes preserve task history and offer reassignment.
- Old local tasks, focus sessions, and preferences are not silently deleted. They can be explicitly imported after sign-in. Former subject labels remain task history only, not dropdown choices, until reassigned to a custom subject.
- Real Firebase Authentication integration: email/password sign-up/login, unique username reservation, username+password login through the included HTTPS callable function, email verification, password reset, session restoration, logout, and optional Google sign-in.
- Firestore app data is stored under each authenticated user's UID and Firestore rules enforce this separation. The account's subjects, tasks by date, completed tasks, progress inputs, focus sessions, and preferences live in that account's state document.
- Keeps DreamyPlan's pink/lavender theme, navigation, Home, Calendar, Progress, Focus, Settings, and the footer credit.

## Important: authentication requires your Firebase project

The source contains intentionally blank Firebase web configuration values. Real login/cloud sync will not work until you configure them. Do not claim accounts work before this setup is complete.

### Setup steps

1. Open the [Firebase Console](https://console.firebase.google.com/) and create a project.
2. In Project settings → Your apps, add a **Web app**. Copy `apiKey`, `authDomain`, `projectId`, and `appId` into the `firebaseConfig` object inside `public/index.html` (and `DreamyPlan.html` if you use that copy directly). Firebase web config is public app configuration; **never paste a service-account private key into HTML**.
3. In Authentication → Sign-in method, enable **Email/Password**. To enable Google, enable the **Google** provider and configure the authorized HTTPS domain.
4. Create a Cloud Firestore database.
5. Deploy the included `firestore.rules` in the Firebase Console or using Firebase CLI. These rules keep profile and app-data reads/writes tied to the signed-in UID; app data additionally requires a verified email. Do not replace them with public read/write rules.
6. Configure and deploy the username-login Cloud Function. Install the Firebase CLI in a development environment, run `firebase login`, select your project with `firebase use --add`, then run `firebase deploy --only functions`. On the first deployment, the CLI will ask for the `FIREBASE_WEB_API_KEY` string parameter; enter the Web API key from the Firebase app configuration. This key is a public web-app identifier, not a service-account private key. Deployment may require enabling billing for Cloud Functions depending on the current Firebase plan and region.
7. In Authentication settings, configure the email verification and password reset templates. Add the HTTPS hosting domain to authorized domains.
8. Deploy the site to Firebase Hosting from the project root with `firebase deploy --only hosting` after choosing the Firebase project. The page needs an HTTPS origin for Firebase modules, redirects, OAuth, and persistence; a local `file://` HTML file is not a supported production origin. The provided `firebase.json` uses `public/` as the Hosting directory.
9. Deploy Firestore rules from the project root with `firebase deploy --only firestore:rules`. You can deploy Hosting, rules, and Functions together with `firebase deploy --only hosting,firestore:rules,functions` after project setup is complete. Test with two separate accounts before storing real personal data. For an Android WebView wrapper, ensure it loads the HTTPS hosted page or a secure app origin and supports the Firebase SDK. Google popup/redirect support varies by wrapper; email/password is the baseline.

## Username login security

The Firestore `usernames/{normalizedUsername}` document contains only the Firebase UID, not an email address. The `usernameLogin` Cloud Function checks the supplied username and verifies the supplied password through Firebase Identity Toolkit before returning the email to the client. It never stores passwords. This callable is required for username login; email login works directly through Firebase Authentication.

## Existing local data migration

The app **does not automatically copy or delete** the old shared local-storage record. After you sign into the account that should own the old planner data, open More/Settings and choose **Import existing local data**. The import merges tasks by date and ID, deduplicates focus sessions, merges preferences, and leaves the old local backup intact. It intentionally does not import the former subject list because an old list may have included predefined subjects; old task subject labels remain historical labels and can be reassigned after you create custom subjects. This avoids silently assigning another person's device-local data to the wrong account.

## Known limitations / honest status

- A connected Firebase project, configured API values, enabled sign-in providers, published Firestore rules, and deployed `usernameLogin` function are required for live auth/cloud features; this source package cannot provide your project credentials. Live signup/login/security tests have not been run against your Firebase project because those credentials and deployment do not exist in this workspace.
- The planner stores app state in one Firestore document per user for simplicity. If a user grows to a very large history, split tasks/focus sessions into per-record documents to stay under Firestore document size limits.
- Focus timer is interactive and completed sessions are recorded. Existing Calendar and Progress features remain available; legacy task labels are flagged until reassigned.
- Google sign-in requires the Google provider and authorized HTTPS domain. Some APK/WebView wrappers block OAuth popups/redirects; verify support in your chosen wrapper.

## Files

- `DreamyPlan.html`: updated one-file app copy.
- `public/index.html`: same source intended for HTTPS/Firebase Hosting.
- `firestore.rules`: user-isolation rules.
- `functions/index.js`: secure username-login callable function.
- `functions/package.json`: Cloud Function dependencies.
- `firebase.json`: Hosting, Firestore, and Functions configuration.
