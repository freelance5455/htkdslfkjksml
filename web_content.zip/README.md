# Aster Coding Agent — Android starter project

A mobile-first coding-agent shell with an Android WebView wrapper and a configurable OpenAI-compatible chat endpoint.

## What works
- Chat-style coding assistant UI with plan / build / review prompt modes.
- Configurable API base URL, model name, and API key.
- Android app shell that loads the local UI from assets.
- Request cancellation, error states, copyable assistant output, and session-only chat history.
- No telemetry by default.

## Important limitations
- This starter is **not an APK**; it is source code that can be built into an APK with Android Studio or Gradle.
- Android apps cannot safely execute arbitrary shell commands on the phone by default. This project does not run generated code or commands.
- Connect only to an API provider/server you trust. The API key is stored in browser local storage inside the WebView in this starter, which is convenient but not ideal for production. For public distribution, implement a backend proxy and never embed shared provider secrets in the app.
- “Claude Sonnet-style” means a workflow and UI style; it does not include Anthropic’s proprietary model or guarantee equivalent performance.
- The endpoint must accept OpenAI-compatible `POST /chat/completions` requests. For a local model server, use a reachable LAN URL and ensure the server allows requests from the Android device.

## Build the APK
1. Install Android Studio and a recent JDK (17 recommended).
2. Open the `android/` folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 (or the version requested by the IDE).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK is typically at `android/app/build/outputs/apk/debug/app-debug.apk`.

Alternatively, from the `android/` directory, run:
```bash
./gradlew assembleDebug
```
The Gradle wrapper JAR is not included in this source archive; Android Studio can generate/download the wrapper, or you can run `gradle wrapper` after installing Gradle.

## API setup
Open Settings in the app and enter:
- Base URL, e.g. `https://api.openai.com/v1`
- Model name supported by your provider
- Your own API key

Do not use a provider API key that you do not own. Do not commit keys into source control.

## Phone-only cloud build with GitHub Actions

This archive includes `.github/workflows/build-android-apk.yml`. To run it from a phone:

1. Extract this ZIP using your file manager or an archive app.
2. Create a GitHub repository in your browser. Keep it private if you do not want the source publicly visible.
3. Upload the extracted **contents** to the repository root (the `.github` folder and `android` folder must be at the root, not inside another wrapper folder). GitHub's web upload can be awkward for many files; if it fails, use GitHub's browser editor to add the workflow and upload project files, or use a trusted cloud development environment.
4. Open the repository's **Actions** tab and select **Build Aster Android APK**. Choose **Run workflow** if the workflow is not already triggered by a push to `main`.
5. When the run finishes successfully, open that run and download the `aster-debug-apk` artifact. Extract the downloaded artifact ZIP to get `app-debug.apk`.
6. Install the APK only after checking the build succeeded and you trust the source. Android may ask you to allow installs from the browser or file manager; enable that only for the app you are using and turn it off afterward if no longer needed.

The workflow is a build recipe, not proof that a build has succeeded. A successful GitHub Actions run is required before an APK exists. It builds a **debug APK**, not a Play Store release. The app remains a starter: it does not execute generated code or provide a sandboxed terminal. AI chat needs a compatible endpoint and a user-provided API key. Do not commit API keys or other secrets to the repository.
