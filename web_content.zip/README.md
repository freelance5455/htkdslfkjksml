# Sindh Rescue Rover — Android v1.1 (Wi-Fi native transport fix)

**Source package, not an APK.** Compatible with ESP32-S3 firmware v3.2 and new v3.3. This build does not add Bluetooth. The Android app contains the school's existing government/school branded dashboard and sensor/drive controls.

## What was fixed

1. **Native Wi-Fi transport:** The previous app used JavaScript `fetch()` from Android WebView, which can fail on Android's *connected without internet* ESP32 network. v1.1 sends API requests through `Network.openConnection(URL)` on the explicit Wi-Fi network selected by Android, without using the cellular/default Internet route. An Android `NetworkCallback` updates the selected network when Wi-Fi changes. The bundled page still renders offline, and never needs an external server.
2. **Unambiguous connection state:** The connection indicator shows green only after a valid HTTP JSON response from `192.168.4.1`. On missing responses it shows `API NOT RESPONDING`, explaining that the phone may still be associated with Wi-Fi. Automatic HTTP retries continue without reloading the dashboard.
3. **Command ordering:** Switching modes/directions no longer triggers an overlapping asynchronous STOP from the old held direction. Explicit STOP uses an independent priority network executor, and a redundant Java native STOP on the top toolbar. Each controller sends a `cid` session ID to firmware v3.3 to prevent old controller timestamps from blocking new commands; firmware v3.2 ignores this parameter and remains compatible.
4. **Forward diagnostics:** Missing/blocked IR or ultrasonic sensor appears as an explicit FORWARD BLOCKED safety message, rather than quietly pretending movement succeeded. Safety checks are not disabled. The firmware refuses forward motion if the front echo is invalid.
5. **No dashboard redesign**: the same dark green dashboard, school logos, three drive modes, 0–100% speed, servo and all sensors remain.

## Newly Cloud APK Builder

Upload the complete **Android v1.1 source ZIP**, with the `app/`, `gradle/`, `settings.gradle`, and `build.gradle` directories/files at ZIP root. Set the package ID to `pk.edu.khairpur.sindhrover` and build. The project requires Android Gradle Plugin 8.7.3, Gradle **8.9** (in `gradle/wrapper/gradle-wrapper.properties`), JDK 17, and Android SDK 35. Download the resulting `.apk` from the builder after a successful build; this ZIP cannot be installed directly.

You can also build it using Android Studio's **Build > Build Bundle(s) / APK(s) > Build APK(s)** or the included GitHub Actions workflow.

If Android warns that the app is already installed under the same package ID but signed by a different builder, uninstall the old app, then install the new build. Uninstalling removes its local app state (not ESP32 firmware).

## How to test reliably

1. Put the rover on a secure stand with **all wheels raised** and an accessible **physical motor power cutoff**.
2. Turn the ESP32 on, and join `RescueRover-S3` in the phone Wi-Fi settings. Android may report *No internet access*; choose **Stay connected**. For a first diagnostic run disable mobile data and Android Wi-Fi auto-switch/smart-network-switch features if available; native v1.1 is designed not to require this once connected.
3. In a phone browser, open `http://192.168.4.1/api/diag`. If this page itself fails while Wi-Fi remains associated, the issue is **ESP32 HTTP service, AP power, RF congestion or Android network selection**; no app-only patch can prove a permanent fix. Check Serial uptime and AP drops.
4. Launch the new app, ensure it shows `ROVER CONNECTED` and a changing **UPTIME** with live DHT20/MQ/IR/sonar values. Observe for several minutes before driving.
5. Set **Manual** and hold **Reverse** or **Left** with wheels raised, then release; this tests the L298N path without the forward sonar gate. It must stop on release. Check motor PWM and last command. Then use Forward only when the front distance is valid and >28 cm and IR reads CLEAR. If it refuses forward, the app displays why.
6. Select **Cruise**, tap forward to latch, and tap STOP to stop. Select **Autonomous** only after the servo test visibly sweeps. Check scan direction and obstacle stopping with all wheels raised.
7. If any problem persists, provide **`http://192.168.4.1/api/diag` text**, a screenshot of dashboard **UPTIME/AP DROPS**, and a Serial Monitor snippet at 115200 baud including `[CMD]`, `[MOTOR]`, and `[SAFETY]`. These distinguish software requests from sensor gates, motor wiring and brownout.

## Critical safety and electrical notes

- **No software guarantees uninterrupted Wi-Fi or instantaneous braking.** Android and ESP32 hardware, voltage drops under servo/motor load, routers/radio traffic and network switching may still interrupt HTTP. Firmware's Manual hold-timeout and global link timeout stop motors if communication is lost. Never rely on software alone near an edge, people or obstacles.
- Forward protection needs a fresh valid center HC-SR04 measurement plus clear forward digital IR. Neither rear collisions nor cliffs/drop-offs can be detected with your existing sensors.
- The ESP32-S3 inputs are **3.3V only**. Provide proper dividers/level-shifting for 5V HC-SR04 ECHO and MQ analog outputs, keep ground common, and **remove L298N ENA/ENB jumpers** when PWM is connected to GPIO15/16. This is different from L298N's `5V-EN` regulator jumper.
- If motors do not turn in **any** direction while telemetry shows motion/positive motor PWM, verify L298N motor supply, enable PWM, common ground, IN1–IN4 pins, and motor battery voltage under load.
- MQ2/MQ135 and flame measurements are raw uncalibrated values and must not be represented as certified smoke/gas/flame alarms.

## Test status

Tested: JavaScript syntax; headless browser simulation of the **native bridge** including connection, live sensor telemetry, Manual hold/release/STOP, Cruise latch, Autonomous selection, simulated API timeout and automatic recovery; C++ firmware was compiled with lightweight mocked Arduino API headers for syntax verification.

Not performed: compiling a real APK with Android SDK/Gradle, compiling firmware with the actual ESP32 board package, testing with the user’s ESP32, verifying motor/servo supply, or testing real Wi-Fi radio conditions. Hardware verification is essential before a public demonstration.
