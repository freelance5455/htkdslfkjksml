# Nexus Effect Studio

Interface HTML melhorada para escolher vídeos, experimentar filtros e exportar uma gravação com efeitos visuais.

## Como usar
1. Abre `web/index.html` num navegador atualizado (Chrome recomendado).
2. Escolhe um vídeo no telemóvel ou computador.
3. Seleciona efeitos, ajusta a intensidade e toca em **Aplicar efeitos**.
4. Toca em **Exportar vídeo**. A exportação é gravada em tempo real e descarregada em formato WebM.

## Importante
- Esta pasta contém o projeto-fonte, não um APK compilado.
- A exportação utiliza MediaRecorder e depende do suporte do navegador.
- O reverso é uma pré-visualização experimental e não é exportado nesta versão.
- A gravação exporta a duração reproduzida; vídeos longos podem demorar bastante.
