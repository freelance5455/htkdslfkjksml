# JJP — NYC Studios Phone-Only Capacitor Build

**Game:** Jujutsu kaisen Prepatures (JJP)

**Studio:** 𐌍_𐌙_𐌂 Studios

This is the phone-friendly Capacitor 8 package for the JJP HTML5 prototype.

It contains the web game plus a GitHub Actions workflow that builds a debug Android APK in the cloud, so Android Studio does not need to be installed on the phone.

See `BUILD_ON_PHONE.md` for the exact phone steps.
