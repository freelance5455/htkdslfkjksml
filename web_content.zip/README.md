# AI Money Agent — connectivity fix

## Main fixes
- Fixed Bitstamp ticker/markets symbol normalization. The old code compared `BTC/USD` from markets with `btcusd` from ticker and filtered every market out, leaving the app permanently OFFLINE.
- Added explicit API diagnostics and error details in the dashboard.
- Added refresh re-entry guard.
- Android Settings > Enable Notifications now schedules the background market check and sends a test notification, so notification permission/delivery can be verified on-device.
- Background receiver uses `goAsync()` so Android does not finish the receiver before its network request ends.
- Last background check time/error/score are stored locally for diagnostics.

## Data
Official Bitstamp public market-data API only. Demo signals only; no real orders.

## Test notes
JavaScript syntax and ZIP integrity are checked. This environment has no DNS/network access to Bitstamp and no Android SDK/Gradle installation, so live exchange requests and APK build cannot be truthfully certified here. After installing the APK, open Settings and tap **הפעל התראות**: the app should show a test notification. If market status still says OFFLINE, the exact API error now appears in the diagnostic line.
