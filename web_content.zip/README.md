# Prahaar — Android source project (MVP with offline OCR)

This is the Android Studio project source for Prahaar, an offline-first NEET CBT practice app.

## Implemented in the project
- CBT-style question screen and clickable A–D options
- question palette and question navigation
- answered / unanswered / marked-for-review / answered-and-review counts
- clear response, mark/unmark review, countdown timer, submit confirmation
- score calculation for questions with answer keys
- local persistence for imported questions and saved attempts
- import formatted `.txt` / `.csv` question banks
- **Android native offline OCR for images and PDF pages** using the bundled ML Kit Latin text-recognition model
- editable OCR output before the best-effort question parser runs
- PDFs rendered page-by-page on-device, limited to 80 pages per import

## Important limitations
- **This is source code, not a compiled or verified APK.** No APK has been built or tested in this environment.
- OCR recognises printed Latin text best. Complex equations, multi-column layouts, handwriting, low-resolution scans, and diagrams may be misread or omitted.
- The question detector expects question blocks with four options labelled A-D. For textbook pages with unusual layouts, review/edit OCR text and format the question blocks before importing.
- Correct answers are not inferred from a textbook; provide `Answer: A/B/C/D` if you want automatic scoring.
- The app is not an official NTA application.
- Local WebView storage may be erased by clearing app data or uninstalling. Export/backup is not included.

## Build an APK
1. Install Android Studio on a computer with the Android SDK.
2. Open this folder as an Android Studio project.
3. Allow Gradle sync. Install Android SDK Platform 35 if prompted.
4. Wait for Gradle to download the ML Kit dependency (internet is needed for the initial build; OCR itself uses the bundled model after installation).
5. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. For a distributable release, use **Build > Generate Signed Bundle / APK** and keep the signing key private.
7. Test PDF/image imports and CBT behaviour on your Samsung tablet before relying on the app.

Expected debug APK output after a successful build:
`app/build/outputs/apk/debug/app-debug.apk`

Package: `com.prahaar.neet`

## Import text format
Separate blocks with a blank line:
```
Subject: Physics
Question: Which quantity is measured in coulombs?
A) Electric current
B) Electric charge
C) Potential difference
D) Resistance
Answer: B
```
Subjects: Physics, Chemistry, Botany, Zoology. The answer line is optional, but scoring requires verified answer keys.
