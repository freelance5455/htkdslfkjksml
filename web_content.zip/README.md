# WBS MOBI — MVP v2 (corridas em tempo real)

Inclui:
- Passageiros e motoristas (carro/moto)
- Comissão de 15% calculada no servidor
- Cadastro e login com JWT
- Aprovação administrativa de motoristas
- Localização GPS enviada pelo app do motorista
- Busca de motoristas próximos por raio e categoria
- Distribuição de chamada via Socket.IO
- Aceitação atômica de corrida (evita dois motoristas aceitarem)
- Painel administrativo básico

## Requisitos
Node.js 20+ e Docker Desktop.

## Iniciar localmente
1. Extraia o ZIP.
2. Copie `.env.example` para `.env`.
3. Altere `JWT_SECRET` e `ADMIN_PASSWORD`.
4. Execute `docker compose up -d db`.
5. Execute `cd server && npm install && npm run db:init && npm run dev`.
6. Painel: http://localhost:3000/admin.html

O primeiro administrador é criado na inicialização do banco.

## Socket.IO
O cliente conecta ao mesmo host da API e envia o JWT:
`io(API_URL, { auth: { token } })`

Eventos do motorista:
- `driver:location` com `{ lat, lng }` — envia posição GPS
- `ride:offer` — recebe uma chamada
- `ride:offer-expired` — chamada expirou/foi tomada

Eventos do passageiro:
- `ride:status` — recebe mudanças de status e motorista atribuído

O servidor envia ofertas aos motoristas aprovados, online, com localização recente e categoria compatível. Para o MVP, a chamada é oferecida aos 5 motoristas mais próximos, em um raio inicial de 8 km.

## REST API adicional
- `POST /api/driver/online` — motorista aprovado fica online
- `POST /api/driver/offline` — fica offline
- `POST /api/driver/location` — `{lat,lng}`; atualiza GPS
- `GET /api/driver/rides/available` — corridas compatíveis ainda disponíveis
- `POST /api/rides/:id/accept` — aceita chamada
- `POST /api/rides/:id/complete` — conclui corrida
- `GET /api/rides/:id` — passageiro/motorista consulta a corrida

## Atenção — não é produção
Esta entrega é código-base executável para desenvolvimento local. Antes de operar de verdade:
- configurar domínio, HTTPS, firewall, backups e monitoramento;
- revisar segurança, LGPD, termos e política de privacidade;
- integrar mapas/rotas e estimativa real de preço;
- integrar um provedor de pagamentos Pix e conciliação;
- implementar upload privado e análise de CNH/documentos;
- implementar notificações push e testes de carga;
- revisar requisitos legais e regulatórios para transporte de passageiros.
A localização enviada pelo navegador/app exige permissão do usuário. Não rastreia motoristas sem consentimento.
