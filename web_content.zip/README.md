# Turbo Road Racing — Full Project

## Included
- `public/index.html`: responsive arcade racing game
- `server.js`: Express + Socket.IO room server
- `package.json`: server dependencies

## Run locally
1. Install Node.js 18 or newer.
2. In this folder run `npm install`
3. Run `npm start`
4. Open `http://localhost:3000`

Offline play works without the server. Online play requires the server to be deployed and reachable over HTTPS.

## Deploy the server on Render
1. Upload these project files to your GitHub repository. Keep `server.js` and `package.json` in the repository root and `index.html` in `public/`.
2. In Render, create a **New Web Service** and connect the repository.
3. Runtime: Node. Build command: `npm install`. Start command: `npm start`.
4. Deploy and wait for the service to become live.
5. Copy the HTTPS service URL, e.g. `https://your-service.onrender.com`.
6. Open the game and select **HOST ONLINE** or **JOIN ROOM**. Enter that URL and use the same room code for every friend.
7. For an online web page, deploy the same repository as a Node web service (it serves the game page and Socket.IO server together). Do not use GitHub Pages for the multiplayer server because Pages only hosts static files.

## Important notes
- This is a starter multiplayer implementation. It synchronizes racer positions, not a fully authoritative competitive physics engine.
- Online mode needs an internet connection and Socket.IO client CDN access. Offline mode is playable without a connection after the page is cached/downloaded, but the online library itself is fetched from a CDN.
- Add authentication, rate limiting, server-side race validation, and stronger room capacity limits before a public commercial launch.
