# SSC PYQ Bank — V1.7.8

An offline-first, Android-friendly Progressive Web App (PWA) prototype for personal SSC practice.

## V1.7.8 changes

- Increased the four subject names slightly: 16px on standard screens and 14.5px on narrow screens.
- Increased spacing between the subject strips from 10px to 13px on standard screens, and from 9px to 11px on narrow screens.
- Strip dimensions, icons, section position, navigation, menu, search, settings, themes, and functionality remain unchanged.
- Updated About and the offline service-worker cache to V1.7.8.

## V1.7.6 changes

- Home now contains only the **Subjects** section with four subject strips in a 2-column × 2-row grid. The Performance Overview and More sections have been removed from the Home dashboard.
- Increased strip height from 42px to 50px (48px on screens 360px wide or narrower), with slightly larger text and icons. Strips remain sharp-corner rectangular bars with equal spacing, subject names on the left, and theme-adaptive icons on the right.
- The top navigation bar, hamburger menu and all drawer entries, search controls, settings, themes, other screens, and existing app behavior remain unchanged.
- Performance Overview, Achievements, and Progress Report placeholder destinations remain defined for compatibility, but no longer appear as Home dashboard sections.
- Updated About and the offline service-worker cache to V1.7.6.

## V1.7.0 features retained

- The original V1.7.0 dashboard introduced Subjects, Performance Overview, and More sections. In V1.7.6, the latter two sections are removed from Home; their placeholder destinations remain in the app code for continuity.
- The four Subject controls use enlarged sharp-corner rectangular strips in a 2-column × 2-row layout, with the name on the left and theme-adaptive icon on the right.
- Moved Display Mode into **Settings → Appearance**. Its one-click sun/moon button toggles Light/Dark mode and remembers the selection. The single-click inverse toggle interaction and sun/moon presentation reuse only the Display Mode control pattern from V1.0.0; V1.7.0 was built by modifying the V1.6.0 project, not the V1.0.0 files.
- Kept the existing five-colour **Theme** palette mechanism in Appearance, below Display Mode.
- Updated About and the offline service-worker cache to V1.7.6.

## Existing functionality retained

- Four subject destinations. Legacy Performance Overview, Achievements, and Progress Report placeholder destinations remain available by direct route, but are not displayed on Home.
- Dynamic page titles, Home hamburger drawer, and back arrow on inner screens.
- Drawer entries: Home, Settings, and About.
- Five accent palettes: Red, Blue, Purple, Green, and Amber.
- Settings → Appearance navigation.
- Chapter search replaces the top bar and includes a Back arrow, search field, and microphone control.
- Browser speech dictation uses the Web Speech API when supported; typed input remains available as fallback.
- Local preference persistence, PWA launcher icons, and offline service-worker caching after the first successful load.
- Legacy `#bookmarkedQuestions` routes continue to resolve to Bookmarked Questions.

## Run locally

Run a local web server from this directory (for example, `python -m http.server 8000`) and open `http://localhost:8000`. Service workers work on localhost and secure HTTPS origins; they do not work from a direct `file://` open.

## Install on Android

1. Host this folder on an HTTPS static host or use a secure development host.
2. Open the app in Chrome on Android while online.
3. Choose **Install app** or **Add to Home screen** from Chrome's menu.
4. Launch from the home screen. Offline caching is available after the first successful load.

## Validation

Run `node --check app.js` and `node tests/smoke-test.js` from this directory.

## Known limitations

- This is a PWA source project, not a signed native Android APK or Android Studio project.
- Performance Overview counters currently display static zero values because the question database, attempt tracking, and bookmark storage have not yet been implemented.
- Achievements and Progress Report are placeholder destinations; achievement rules, progress calculations, and report visualizations are not implemented yet.
- Chapter search is a UI entry point only; actual chapter lookup requires the future chapter/topic catalogue.
- Voice dictation depends on browser Web Speech API support and microphone permission.
- Physical Android-device testing has not been performed in this build session.

## Project continuity

Use this V1.7.8 project as the single continuing master project. Future versions must update this implementation incrementally, preserve completed features and local preferences, and update only requested functionality. Never recreate the app from scratch.
