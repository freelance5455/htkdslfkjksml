# Xpressfood — APKForge-ready starter

A premium, mobile-first food-delivery **frontend starter** with restaurant discovery, category/search UI, local cart, checkout validation, address capture, local demo order history, and rating UI.

## Important honesty / launch status
This ZIP is a working frontend prototype, **not yet a live nationwide marketplace**. Demo orders are stored on the current device only and are not sent to restaurants or riders. It does not fake successful payment, Google login, live courier GPS, courier chat/calls, or uploaded delivery photos. Those features require production services and an actual network of onboarded merchants and couriers.

## Use with APKForge
1. Extract `Xpressfood.zip`.
2. Import `index.html` (and keep `styles.css` + `app.js` beside it) into APKForge's website/HTML app workflow. If it only accepts a single HTML file, ask for a single-file bundled version.
3. Enable internet access so fonts and remote integrations can load.
4. Test in the APKForge preview and on a real Android phone.
5. For public launch, host the frontend over HTTPS and connect the backend described below. A local HTML package alone cannot safely hold payment secrets or run a nationwide dispatch service.

## Production integration plan
### 1. Authentication + database
Use Firebase Authentication (email/password + Google) and Firestore or Cloudflare Workers + D1. Never claim a user is authenticated until the provider confirms it. For Firebase web setup:
- Create a Firebase project and register a Web app.
- Enable Email/Password and Google in Authentication.
- Add the actual APKForge/WebView/host domain to authorized domains.
- Put the public Firebase web config into the app integration layer (it is not a server secret); never put service-account keys in the client.
- Set database security rules before storing customer profiles, addresses, orders, or messages.

Official docs: https://firebase.google.com/docs/auth/web/start
Google sign-in: https://firebase.google.com/docs/auth/web/google-signin

### 2. Maps and address lookup
Use Google Maps Platform Maps/Places/Routes or an alternative with suitable coverage and licensing. Create and restrict keys by app/domain/API. Request location permission only when needed. GPS coordinates are not a delivery address; collect unit/house, street, barangay, city, and landmarks too. Official docs: https://developers.google.com/maps/documentation

### 3. Payments (Philippines)
Integrate through a merchant-approved payment gateway and a server-side checkout endpoint. GCash acceptance through Maya depends on an active Maya merchant account and the relevant payment product being enabled. Add Maya, PayPal, and cards only after approval and provider credentials. Verify payment using signed server webhooks; never trust a browser redirect or a button click as proof of payment. Keep COD as an option if operationally supported.
- Maya / GCash docs: https://developers.maya.ph/docs/gcash
- PayPal developer docs: https://developer.paypal.com/docs/

### 4. Live delivery
A real delivery backend needs:
- Restaurant onboarding, menus, opening hours, service zones, stock, and merchant order acceptance.
- Courier accounts, identity/onboarding process, availability, dispatch, delivery zones, and proof-of-delivery workflow.
- Server-side order state machine (placed → accepted → preparing → picked up → en route → delivered/cancelled).
- Courier GPS updates with explicit permissions and only while on an active delivery; authorized customer sees the assigned rider location.
- Secure per-order chat, call actions, image upload/storage, notification delivery, cancellation/refund rules, and abuse reporting.
- Reviews restricted to completed orders; separate food/store and courier ratings.
- Admin dashboard, customer support, audit logs, privacy policy, terms, retention/deletion controls, and incident handling.

Cloudflare Pages Functions can connect to D1, KV, R2, and Durable Objects: https://developers.cloudflare.com/pages/functions/bindings/
Suggested architecture: frontend hosted on Cloudflare Pages; API on Pages Functions/Workers; D1 for relational order data; R2 for photos; Durable Objects/WebSockets or a suitable managed real-time service for order/chat updates; push notifications via a supported provider.

## Current prototype behavior
- Restaurant cards, categories, text search, favorites (in-memory), menu selection, cart quantities, subtotal/fees, checkout address validation, geolocation permission request, local COD demo orders, order history, local 1–5 star rating.
- No fake live restaurants: the menu content is sample/demo data and should be replaced with onboarded restaurant data before launch.
- Non-COD checkout deliberately refuses to proceed because no gateway is connected.
- Google/email sign-in deliberately reports that Firebase must be configured first.
- Courier tracking, chat/calls and proof photos are previews, not live services.

## Security and operations checklist before real launch
- Configure server-side secrets and signed webhooks.
- Write and test database access rules and role-based access for customer, merchant, rider, support, and admin.
- Use server-side price calculations; never trust prices submitted by the app.
- Validate restaurant service area, operating hours, menu availability, delivery fee and taxes server-side.
- Add privacy policy, consent, customer support, refunds/cancellations, merchant and rider agreements.
- Test with sandbox payments, test users, and a small pilot zone before accepting real orders.
