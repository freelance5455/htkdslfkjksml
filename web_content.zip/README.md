# ITBN CAMP REPORT Android App

Android wrapper for the supplied ITBN CAMP REPORT HTML application.

Application ID: com.itbn.campreport
Version: 1.0
Target SDK: 35
