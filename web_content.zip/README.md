# AI Money Agent – Fixed Demo

## What was fixed
- Web build now contains `app.js`, matching the script loaded by `index.html`.
- Demo entries are now monitored against live ticker prices.
- Demo positions automatically close when TP or SL is reached.
- P/L is calculated and returned to the demo balance.
- Duplicate open demo positions for the same pair are blocked.
- Positions and signal history are rendered correctly.
- All Markets, Data, Settings reset, and Advanced Chart pages are wired.
- Advanced Chart now uses the selected candle series.
- Scanner remains Demo-only and does not place real exchange orders.
- Backtest uses historical candle data and is deterministic rather than random.

## Data source
The demo uses official Bitstamp public market-data endpoints only:
- Markets
- Ticker
- OHLC
- Order Book

## Important
This is a demo signal agent. It does NOT place real trades. Reliable phone push notifications while the app is closed require an FCM/backend service.

## Android
Open the `android` folder in Android Studio. The project intentionally loads:
`file:///android_asset/public/index.html`

A Gradle wrapper is not included, so Android Studio may ask to use/install a compatible Gradle distribution.
