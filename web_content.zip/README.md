# TRAPBOUND: THE FINAL RUN — CHAPTER 2  ·  level.hard.clud2.end (v1.4)

## Play
Open index.html in a current browser. No network, account, external library, paid API, or downloaded asset is required. On Android, serve the folder over HTTP or package it in a WebView: some Android file managers do not launch local HTML with script permission.

## Landscape (v1.1)
The game is landscape from the first frame, with no button or setting. On a touch device held upright (or with auto-rotate off) the whole stage is rotated 90 degrees by CSS, so the player simply turns the phone sideways. On the first tap the game also tries fullscreen plus a real landscape lock; where the browser allows it the OS rotation takes over, otherwise the CSS rotation keeps working. Menus, death, win and stage-complete screens use a compact two-column layout and fit on one landscape screen without scrolling (only the stage list scrolls). For the final Android APK also set the activity to `android:screenOrientation="sensorLandscape"` (Capacitor: AndroidManifest.xml), which makes the OS-level lock permanent.

## Camera
The camera is closer: about 420 world units of height are visible instead of 600 (the character is roughly 40% larger on screen). Change `420` / `480` in `resize()` in game.js to zoom more or less.

## Hidden traps (v1.1)
No trap is telegraphed any more: no warning marks, dotted lines, glow, cracks, shaking, blinking tiles, vent bases, gate outlines, rune zones, hanging sign, or hint text. Traps appear without warning: spikes shoot up from the floor, spikes/rocks/signs fall from above within a fraction of a second, saw blades dash in from the left or right (stage 6+, `dash`), fire bursts from the ground, gates slam shut, and collapsing/vanishing/timed floors look like ordinary stone. Traps are deterministic, so a player can learn them by memory. Patrolling saws, the moving wall and the ceiling crusher stay visible because they are moving obstacles.

## Project
index.html: semantic shell and Canvas.
style.css: responsive menu and touch layout.
game.js: original Canvas art, 120 Hz simulation, Web Audio synthesis, deterministic level generation, menus, progression, settings, input, and engine checks.
tests.html: in-browser checks and manual QA checklist.
manifest.webmanifest: optional packaging metadata; not an offline service worker.

There are exactly 26 stages with 5 generated, deterministic arrangements each, not 5 levels reused under new labels. Every level has a spawn, floor geometry, hazards, and physical exit. Difficulty and traps vary by stage and slot. Geometry generation is constrained by the player's jump range. This is not evidence that every dynamic combination has been playtested.

## Controls
Default movement: A / D, Left / Right. Jump: Space / W / Up. Pause: Escape. Restart: R. Settings > Custom Controls remaps keys, swaps conflicts, adjusts touch size and horizontal/vertical offsets, and binds canvas left-click optionally. Touch buttons accept simultaneous pointers. Pause clears held inputs. Re-press held keys after resuming.

## Saves
Progress and settings use trapbound.v1 and trapbound.backup in localStorage. Saves are local to the browser and origin. Private browsing, blocked storage, or clearing site data can lose progress. Sequential completion unlocks the next level; completing slot 5 unlocks the next stage immediately. Replay never erases unlocks. Reset Progress requires confirmation.

## Audio
Press any game button to initialize Web Audio. Settings control master, music, effects, and mute. All effects and environment music are synthesized locally. Browser or OS mute still applies.

## Verification status
Executable checks cover stage counts, sequential unlocks, terminal progression, duplicate completion, save round-trips, malformed save sanitization, deterministic trap resets, baseline jump geometry, portal overlap guards, end/start/end relocation, collision overlap, and death/transition one-shot guards. Checks execute in the user's browser. The generated artifact has not been executed in a browser by the assistant, and no desktop/Android audio, pointer, or full 130-level playthrough is claimed. Review tests.html and record actual results before release.

## Android packaging
This is a web game, NOT an APK. A later Capacitor wrapper can use a www directory containing index.html, style.css, game.js, and manifest.webmanifest. Configure webDir as www and appId as an appropriate reverse-domain identifier, add Android, sync, and build using Android Studio and its SDK. Capacitor and Android build tools are development dependencies; the game runtime needs none. Verify safe areas, multitouch, audio focus, Android Back behavior, orientation, signing, and localStorage persistence in the actual wrapper. A manifest alone does not make an installable offline PWA.

## Release caveats
130 layouts are generated from deterministic design rules, not individually hand-authored or certified beatable by a solver. Collapsing and disappearing floors regenerate, pursuing hazards stop before the final terrace, and relocated exits retain traversable ground routes. The engine is intentionally lightweight rather than a production physics library. Static geometry checks cannot validate all hazard timing, landing order, or device-specific browser behavior. Run full playthrough and device QA before calling this a finished release.

## Level Hard Claud 3 (v1.3)
Changes made after play feedback on Claud 2:

**Floors you can trust (forward and back).** Collapsing, vanishing and timed floors are rarer than before and are never the first or last stone of a level and never next to each other, so there is always ordinary solid ground both ahead of and behind every one of them. Collapsing floors now hold for about 0.85 s (vanishing 0.75 s) instead of under half a second, they grow back after 1.4 s everywhere, and a timed floor never disappears while you are standing on or just above it.

**No control reversal.** The left/right reversal trap has been removed completely: no zones, no flipped movement, in any stage. (The old level title "Reversal" is now "Ambush".)

**A trap in the long place.** From stage 2 two neighbouring solid stones are fused into one very long stone, with hidden floor spikes in the middle (two spikes from stage 12).

**A trap in the high places.** The optional upper stones (from stage 3) carry hidden spikes; from stage 10 they carry two, which is harder.

**Verification.** `Settings > Run Engine Checks` has new checks for the points above. They were run under Node with a stubbed DOM (all 14 checks passed); the game itself has not been played in a real browser by the assistant, so please play-test the new zones and traps.

## Earlier notes
Spikes ride their platform (moving platforms carry them, collapsing platforms remove them).

## level.hard.clud2.end (v1.4)
**Menus scroll again.** On an upright phone the stage is rotated by CSS, so the browser's native vertical pan pointed the wrong way and Settings, Controls and the stage list (it stopped at Stage 24) could not scroll. Menus now scroll by touch-drag in the stage's own axes (also works unrotated; mouse wheel still works). Every long screen also has a sticky BACK button at the top.

**Whole screen.** FULLSCREEN button in the main menu and in Settings (plus the automatic try on first tap). The play area no longer stops at 1800 units, so wide phones are filled edge to edge, and the page is dark everywhere (`color-scheme: dark`). On iPhone, Safari has no real fullscreen: use Share > Add to Home Screen.

**Gentler start, harder later.** Gaps are 30% smaller in stages 1-3 and 15% smaller in 4-7; they are larger in the forest (8-16) and larger still from the fire biome (17+). Traps arrive later: long-stone trap from stage 4, floor spikes from 3, upper-stone spikes from 5, saw and the exit-mode puzzles from 5-7, falling spikes/signs from 6, pursuer from 8, jump trap from 9, dash saw from 10 (second one 16). Stages 1-4 start with a free shield.

**New things, not just spikes.** Spiked swinging ball (stage 9+), gusts of wind that push you (stage 8+, visible streaks), lava fireballs jumping out of the gaps (stage 17+), and a second saw in the forest.

**Energy and morale.** 3 stars per level (counted on the level list and main menu), a shield orb that absorbs one hit (not a pit), a checkpoint flag halfway (death screen offers "try again at checkpoint" or "from the start"), and an encouraging line on every death screen.

Engine checks now include stars/shield/checkpoint, the difficulty curve and the shield rule. Not played in a real browser by the assistant.
