Medical Study Hub Android — Version 2

Persistent storage:
• Notes use localStorage.
• Pictures are stored persistently as Data URLs.
• PDFs are copied to the app's private files directory and their paths are saved.

Package: com.medicalstudyhub.app
Version: 2.0

Open in Android Studio and build/sign the APK.
