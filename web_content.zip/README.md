# Generador de Órdenes — PWA

Esta carpeta contiene la versión PWA de la app.

## Archivos
- `index.html` — aplicación completa.
- `manifest.webmanifest` — configuración instalable.
- `service-worker.js` — caché para mejorar el uso offline.
- `icons/` — iconos de la aplicación.

## Publicación
Sube **todo el contenido de esta carpeta**, respetando las carpetas, a un hosting HTTPS.
Después abre la dirección desde Chrome en Android y usa **Agregar a pantalla de inicio / Instalar aplicación**.

Para convertirla posteriormente en una APK tipo TWA, necesitaremos la URL HTTPS final y configurar Digital Asset Links.

## Nota sobre funciones del teléfono
La PWA usa las APIs del navegador para selección de archivos, compartir y `window.print()`. En Android conviene probarla directamente en Chrome antes de empaquetarla como TWA.
