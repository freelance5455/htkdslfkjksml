# কাযা নামাজ হিসাব — Android Studio Project

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be under `app/build/outputs/apk/debug/`.

The app is a local WebView wrapper around the included offline HTML app.
No internet permission is required. Data is stored locally by the WebView.
