# Minha Rotina Diária — protótipo 0.1

Este é um protótipo funcional de interface para organização doméstica, em português brasileiro.

## O que já funciona
- Checklist diário e barra de progresso.
- Marcação de tarefas concluídas.
- Tarefas diárias personalizadas.
- Organização por cômodo e tarefas adicionais por cômodo.
- Sugestão de plano semanal.
- Desafio de 15 minutos.
- Salvamento local no navegador do mesmo dispositivo.
- Manifesto e service worker básicos para testar como PWA.

## Como testar sem programar
1. Descompacte o arquivo ZIP.
2. Abra `index.html` no navegador do computador para uma demonstração básica.
3. Para testar a instalação como PWA, os arquivos precisam ser hospedados por HTTPS (por exemplo, num serviço de hospedagem estática). Depois abra o endereço no Chrome do Android e procure a opção de instalar/adicionar à tela inicial.
4. As tarefas são salvas apenas neste navegador/dispositivo. Não há conta, sincronização em nuvem ou backup.

## Importante: ainda não é um APK nem está publicado na Google Play
Este pacote é um protótipo web. Para publicar como app Android será necessário empacotar a interface com uma ferramenta Android (por exemplo, Capacitor), configurar ícone e identificador do app, testar em aparelhos reais, gerar um Android App Bundle (.aab), e completar a configuração no Google Play Console.

## Monetização por pagamento único
A tela Premium é apenas ilustrativa. Nenhuma cobrança está ativa. Antes de vender recursos digitais dentro do app distribuído pela Google Play, implemente o Google Play Billing, configure um produto de compra única no Play Console e teste compras, restauração/consulta de propriedade, cancelamentos e tratamento de erros. Não solicite nem armazene dados de cartão diretamente.

## Próximas etapas recomendadas
1. Confirmar nome, logotipo e lista de tarefas.
2. Testar com algumas pessoas e corrigir a experiência.
3. Definir política de privacidade compatível com os dados realmente coletados.
4. Empacotar para Android e adicionar compras Google Play.
5. Gerar o AAB, testar conforme os requisitos vigentes da Play Console e publicar.

Este projeto é um ponto de partida e não uma garantia de aprovação, vendas ou renda.
