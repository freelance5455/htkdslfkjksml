# NutriTrack Community — CEP Topic 47

This is an Android Studio project for a simple educational nutrition and health-habit tracker.

## Features
- Meal notes (no calorie counting)
- Water glass counter
- Daily habit checklist (food variety, fruit/vegetables, movement, sleep routine)
- Simple daily summary/export text
- Local storage on the device only; no login or server
- Responsive, colorful design

## Build an installable APK
1. Install Android Studio on a computer and open this project folder.
2. Allow Android Studio to sync Gradle and download the Android SDK/build tools if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. After a successful build, choose **locate** in the notification. The APK is typically at:
   `app/build/outputs/apk/debug/app-debug.apk`
5. Transfer that APK to your Android phone and install it. Android may ask you to allow installation from that file source.

## Important
- This chat environment cannot compile/sign the Android APK directly; this ZIP contains the Android Studio source project, not an APK.
- This project is for general education and habit reflection, not medical advice or diagnosis.
- Entries are stored locally in app WebView storage. Avoid entering sensitive health information.
- If you only have a phone and no computer, ask a teacher/lab assistant to build the APK from this project.
