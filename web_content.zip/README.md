# Aaj — Calendar, Puja & Weather

A installable web app (PWA). Files: index.html, manifest.webmanifest, sw.js, icons/.

## Try it on your computer
    python3 -m http.server 8080      # then open http://localhost:8080

(Opening index.html by double-click works, but install and offline mode need http://localhost or https.)

## Put it on a phone
1. Upload this folder to any HTTPS host: Netlify Drop (app.netlify.com/drop), GitHub Pages, Cloudflare Pages or Vercel.
2. Open the link in Chrome on Android, then tap "Install app" (or menu > Add to Home screen). On iPhone, use Safari > Share > Add to Home Screen.

## Make an Android APK / Play Store app
1. Host the folder over HTTPS (step above).
2. Go to https://www.pwabuilder.com, paste your link and choose Android. It gives you a signed package.
   (Alternative: Capacitor — `npm i @capacitor/core @capacitor/cli @capacitor/android`, set webDir to this folder, `npx cap add android`.)

## Notes
- Personal events are saved on the device (localStorage). Weather comes from Open-Meteo and needs internet.
- To add festivals, edit the FESTIVALS list near the top of the script in index.html. Dates use YYYY-MM-DD.
- After editing files, change V='aaj-v4' in sw.js so phones fetch the update.
