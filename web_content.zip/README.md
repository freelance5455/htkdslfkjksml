# DuoChat V2
Firebase + vanilla JS messenger. Web (Hosting) and Android (Capacitor, `com.duochat.app`).

## Owner must provide (nothing is invented)
1. A Firebase project on the **Blaze** plan (Functions require it).
2. Web app config -> paste into `public/js/firebase-config.js`.
3. Enable: Authentication (Email/Password), Firestore, Realtime Database, Storage.
4. reCAPTCHA v3 site key (App Check) -> `APPCHECK_SITE_KEY`; register it in Console > App Check, then add `ENFORCE_APPCHECK=true` to `functions/.env` and enforce in Firestore/Storage/RTDB.
5. Android release keystore (you generate it, step below).

## Deploy
```
npm i -g firebase-tools && firebase login
firebase use --add            # choose your project
cd functions && npm install && cd ..
firebase deploy               # hosting, functions, firestore (rules+indexes), storage, database
```
First deploy of Storage rules asks to grant cross-service IAM (rules read Firestore) - accept.

## Super Admin
`functions/.env` holds `SUPER_ADMIN_EMAIL`. Register with that email, verify it, log in: the `bootstrapSuperAdmin` function (server-side, checks the verified token email) sets the `superadmin` custom claim. The frontend never decides roles; Admins cannot touch Super Admin (enforced in `setRole`/`setSuspended`).

## Android APK
```
npm install
npx cap add android
npm run assets        # icon/splash from resources/*.svg
npm run sync
keytool -genkey -v -keystore duochat.jks -alias duochat -keyalg RSA -keysize 2048 -validity 10000
```
Add to `android/app/build.gradle` (`android{}` block): a `signingConfigs.release` pointing at `duochat.jks` (storeFile, storePassword, keyAlias, keyPassword) and `signingConfig signingConfigs.release` in `buildTypes.release`. Then:
```
cd android && ./gradlew assembleRelease   # android/app/build/outputs/apk/release/
```
Add your Android SHA-256 and `localhost` handling for App Check (Play Integrity or debug token) before enforcing App Check for the app. Keep `duochat.jks` out of git.

## Notes
- Clients never write messages/chats/roles directly; Cloud Functions validate membership, sanitize text, rate-limit (15 msgs/10s), and verify image URLs.
- Untested against a live project (no credentials). Run `firebase emulators:start` and test: register/verify, DM, image, group add/remove, suspend, presence on two devices.
