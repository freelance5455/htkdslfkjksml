# NexGallery Puro

Versión de proyecto Android deliberadamente mínima para NexGallery.

## Objetivo

Evitar el wrapper genérico que produjo el APK anterior y reducir al mínimo la
superficie de ataque y los componentes que pueden provocar detecciones.

## Incluye

- Una sola `Activity`.
- WebView del sistema.
- `index.html` incluido localmente en `assets/`.
- IndexedDB/DOM storage para la biblioteca local.
- Selector de archivos/carpetas mediante WebView.
- Sin SDKs externos.
- Sin anuncios.
- Sin Firebase/Analytics/Push.
- Sin permiso `INTERNET`.
- Sin permisos de cámara, micrófono, ubicación, teléfono, contactos o SMS.
- Bloqueo de cargas de red desde el WebView.
- Sin depuración WebView en release.

## No incluye

No es un APK todavía. En el entorno donde se preparó este proyecto no están
instalados Gradle ni el Android SDK, por lo que no sería correcto afirmar que
el APK ha sido compilado o probado.

## Verificación recomendada

1. Abrir el proyecto en Android Studio.
2. Sincronizar Gradle.
3. Compilar un APK release.
4. Instalarlo en un dispositivo de prueba.
5. Probar selección de imágenes/videos y la persistencia de la galería.
6. Subir el APK nuevo a VirusTotal.
7. Comparar especialmente cualquier detección de `Malct` con el APK anterior.
