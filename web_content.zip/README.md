# MAZO HUB Commerce + Real Mobile Push

One MAZO HUB system with two interfaces and one backend/database:
- Public Online Store: `/`
- Private POS/Admin: `/admin/`
- Mobile notification setup: `/mobile-notifications.html`
- API: `/api/*`
- PostgreSQL: shared by both

## Real mobile order notifications
When a customer places an Online Store order:
1. The order is committed to PostgreSQL.
2. Stock is deducted transactionally and the stock movement is logged.
3. The backend sends a Web Push notification to registered **mobile** devices.
4. The laptop POS does not need to be open for the push to be sent.
5. A mobile device that is temporarily offline may receive the push after it reconnects, subject to browser/OS push delivery rules.

The system does **not** claim that a phone with Wi-Fi/mobile data completely disabled can receive a brand-new network notification at that exact moment.

## Enable notifications on the phone
1. Deploy this project over **HTTPS** (required for production Web Push).
2. Install dependencies with `npm install`.
3. Generate VAPID keys:
   `npm run generate-vapid`
4. Copy the generated `VAPID_PUBLIC_KEY` and `VAPID_PRIVATE_KEY` into `.env`.
5. Start the server.
6. Open `https://YOUR-DOMAIN/mobile-notifications.html` **on the phone**.
7. Sign in with the MAZO HUB admin/manager account and tap **ENABLE MOBILE NOTIFICATIONS**.
8. Tap **SEND TEST NOTIFICATION** to verify the phone.

Only devices registered through the mobile notification page are targeted by the push sender (`device_type=mobile`).

## Run locally
1. Install Node 20+ and Docker.
2. Copy `.env.example` to `.env` and set a strong JWT secret/admin password.
3. `docker compose up -d`
4. `npm install`
5. Generate VAPID keys and put them in `.env`.
6. `npm start`
7. Store: `http://localhost:5000/`
8. POS/Admin: `http://localhost:5000/admin/`
9. Mobile setup: `http://localhost:5000/mobile-notifications.html`

For real phone push from a deployed site, use HTTPS and a real domain.

## Push events included
- New Online Store order
- Order status update from POS/Admin
- Admin test notification

The public store remains customer-facing; the POS/Admin stays private at `/admin/`.
