# Coffee Trade ERP — Android Studio Project

This project packages the supplied Coffee Trade ERP web app inside an Android WebView.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync and install any requested Android SDK components.
3. Select **Build > Generate App Bundles or APKs > Generate APKs**.
4. The debug APK will be under `app/build/outputs/apk/debug/`.

## Notes
- The original web assets are in `app/src/main/assets/`.
- JavaScript and DOM storage are enabled.
- The application ID is `com.coffeetrade.erp`.
- Version 1.1 adds on-device sign-in/sign-up, session handling, sign-out, and per-account user profiles.
- For a Play Store release, create a signed release build and configure a release keystore.
- Account credentials are stored locally on the device for this standalone build; production multi-device authentication requires a secure backend.


## WebView fix
The app uses AndroidX WebViewAssetLoader and loads the bundled web app from `https://appassets.androidplatform.net/assets/index.html`. Service-worker requests are routed through the same asset loader.

## Firebase multi-device cloud login
- Version 1.2 is prepared for Firebase Authentication (email/password) and Cloud Firestore.
- Configure `app/src/main/assets/firebase-config.js` with the Firebase Web app configuration.
- Enable Email/Password authentication and publish `firestore.rules`.
- User data is stored per Firebase UID; credentials are handled by Firebase Auth rather than local password hashes.
- See `FIREBASE_SETUP.md` for setup instructions.
