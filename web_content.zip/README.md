# OSINT Hub

لوحة OSINT بواجهة طرفية (Terminal): تبني روابط بحث جاهزة لمصادر عامة، وتحفظ بحوثك في **حالات (Cases)** قابلة للتصدير، مع حسابات وصلاحيات وتحقق بخطوتين.
**للاستخدام القانوني والمصرّح فقط.**

## المميزات
- **بحث ذكي:** الصق أي قيمة والأداة تتعرف على نوعها: `email · domain · ip · url · img · hash · cve · asn · crypto · phone` (و`user` و`name` بالأمر).
- **12 نوع بحث**، ~70 مصدر، وأدوات مخصصة يضيفها الأدمن (`{q}` للقيمة المشفّرة، `{r}` للرابط كما هو، `{n}` للأرقام فقط).
- **حالات (Cases):** ملاحظات وروابط وبحوث محفوظة بالسيرفر، وتصدير تقرير **Markdown / JSON**، وخاصة بكل مستخدم.
- **سجل بحث** شخصي وأزرار إعادة البحث، و**نسخ كل الروابط**.
- **تبويب CLI TOOLS** (أوامر تثبيت وتشغيل أدوات OSINT) و**FRAMEWORK** (فهرس مصادر).
- **الأمان:** bcrypt، جلسات HttpOnly/SameSite=Strict، CSRF، CSP صارم، **2FA (TOTP) + رموز استرجاع**، قفل محاولات فاشلة لكل مستخدم، حدود طلبات، سياسة كلمات مرور (12+)، تنظيف دوري للجلسات والسجل.
- **النشر:** Docker + Caddy (HTTPS تلقائي)، حاوية read-only بلا صلاحيات، healthcheck، وسكربت نسخ احتياطي.

## التشغيل المحلي
```bash
npm install
npm run create-admin -- admin "كلمة-مرور-قوية-12+"
npm start            # http://localhost:3000
npm test             # اختبارات الوحدة + API + الواجهة
```

## النشر على VPS
اتبع **[DEPLOY.md](DEPLOY.md)**.

## أوامر الصيانة
| الأمر | الوظيفة |
|---|---|
| `npm run create-admin -- <user> <pass>` | إنشاء/تحديث أدمن |
| `npm run reset-2fa -- <user>` | تعطيل 2FA لمستخدم |
| `npm run backup` | نسخة احتياطية متسقة (آخر 14) |

## متغيرات البيئة
| المتغير | الوصف |
|---|---|
| `PORT` | افتراضي 3000 |
| `DB_PATH` | مسار قاعدة SQLite (افتراضي `data/osint.db`) |
| `ADMIN_USER` / `ADMIN_PASS` | الأدمن الأول عند أول تشغيل. بدون `ADMIN_PASS` يتولّد باسورد ويظهر مرة وحدة في اللوغ |
| `LOG_SEARCH_VALUES` | `0` = سجل النشاط يخزن نوع البحث فقط |
| `BACKUP_DIR` / `BACKUP_KEEP` | مجلد النسخ وعددها |
| `RL_API_MAX` / `RL_LOGIN_MAX` / `RL_SENSITIVE_MAX` / `FAIL_MAX` | حدود الطلبات والمحاولات (للضبط والاختبار) |

## الهيكل
```
server.js            الـ API والأمان
db.js                SQLite والترقيات
lib/                 policy.js (كلمات المرور) · totp.js (2FA)
scripts/             create-admin · reset-2fa · backup
public/              index.html · app.js (الواجهة)
test/                unit · api · client
Dockerfile · docker-compose.yml · Caddyfile · .env.example · DEPLOY.md
```

## ملخص الـ API
كل الطلبات غير GET لازم تحمل الهيدر `X-Requested-With: fetch`. الأخطاء بالشكل `{ "e": "..." }`.

| المسار | الوصف |
|---|---|
| `GET /healthz` | فحص الصحة (بدون تسجيل دخول) |
| `POST /api/login` `{n,p,c?}` · `POST /api/logout` · `GET /api/me` | الجلسة. إذا 2FA مفعّل ولا رمز: `{need2fa:1}` |
| `POST /api/me/password` · `POST /api/me/2fa/{setup,enable,disable}` | الحساب |
| `GET /api/tools` | الأدوات المخصصة |
| `POST /api/search` `{t,v}` · `GET/DELETE /api/history` | سجل البحث |
| `GET/POST /api/cases` · `GET/PUT/DELETE /api/cases/:id` · `POST /api/cases/:id/items` · `DELETE /api/cases/:id/items/:iid` | الحالات |
| `/api/admin/*` | مستخدمون · reset2fa · أدوات · سجل · تصدير (أدمن فقط) |
