# Looksmax OS · Android beta (v1.0)

Bản Android của Looksmax Master OS, đóng gói bằng Capacitor 6.
Nhắc nhiệm vụ là thông báo cục bộ, được lên lịch ngay trên điện thoại và vẫn chạy khi không có mạng.

## Có gì trong bản beta
- Toàn bộ app web: Nhiệm vụ, Status, Needling, Bí kíp, Trang bị
- Thông báo trên máy cho các mốc chính mỗi ngày (5 ngày tới), báo động tắt đèn 23:00,
  nhắc mewing / tư thế / uống nước mỗi 60 phút từ 09:00 đến 20:30 (đổi 30/60/90 phút hoặc tắt ở tab Status),
  và nhắc 20:00 tối hôm trước mỗi khoản bị trừ tiền.
  Tick xong một nhiệm vụ thì thông báo của nhiệm vụ đó tự hủy.
- Rung qua Haptics, âm thanh hệ thống, icon và màn hình khởi động riêng
- Dữ liệu lưu trên máy (chưa đồng bộ với bản web trên claude.ai)

## Cách 1: GitHub Actions (không cần cài gì)
1. Tạo repo private trên GitHub, đẩy toàn bộ thư mục này lên nhánh `main`.
2. Vào tab **Actions** → workflow **Build Android APK (beta)** chạy tự động (khoảng 5–8 phút).
3. Mở lần chạy đã xong → tải **looksmax-os-beta-apk** → giải nén ra `app-debug.apk`.

## Cách 2: Tự build trên máy tính Windows
1. Cài **Android Studio** (developer.android.com/studio, chọn Standard) và **Node.js LTS** (nodejs.org).
2. Giải nén zip vào `C:\looksmax-os-android`.
3. Mở thư mục đó, gõ `cmd` vào thanh địa chỉ, Enter. Chạy:
   `npm install`
   `npx cap sync android`
4. Android Studio → **Open** → chọn thư mục `android` → đợi Gradle sync xong (lần đầu 5–15 phút).
   Nếu hỏi nâng cấp Android Gradle Plugin: chọn **Don't remind me again**.
5. **Build → Build App Bundle(s) / APK(s) → Build APK(s)** → bấm **locate**.
   File: `android\app\build\outputs\apk\debug\app-debug.apk`
6. Lỗi "Unsupported class file major version": **File → Settings → Build Tools → Gradle → Gradle JDK** → chọn JDK 17 (Download JDK nếu chưa có) → sync lại.

## Cài lên điện thoại
1. Chép `app-debug.apk` vào điện thoại, mở file, cho phép "Cài ứng dụng không rõ nguồn gốc".
2. Mở app → cho phép **Thông báo**.
3. Tab Status → **GỬI THỬ** để kiểm tra.
4. Nếu thông báo đến trễ: Cài đặt → Ứng dụng → Looksmax OS → Pin → **Không hạn chế**.
   Samsung: thêm app vào danh sách "Ứng dụng không bao giờ ngủ".

## Cập nhật bản mới
Thay `www/index.html` bằng bản mới, push lại, tải APK mới, cài đè lên bản cũ (dữ liệu được giữ).
