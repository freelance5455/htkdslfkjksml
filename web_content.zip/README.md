# Haneesh OS 3.0 — Native Android Launcher Project

Haneesh OS is a phone-first Android **launcher concept**. This project combines a native Kotlin Android shell with an animated HTML/CSS/JavaScript interface. It is an installable Android project, not just a standalone website ZIP.

## What's improved in 3.0
- Smooth screen transitions, floating logo motion, animated gradients, tap feedback, and reduced-motion accessibility support.
- A clearer introduction describing what Haneesh OS is designed to do.
- Native Kotlin integration for Android's official Home-app settings, light haptic feedback, and opening Android Settings.
- Android `HOME` and `LAUNCHER` intent filters so the installed app can be opened normally and can be offered as a Home app.
- Updated app version to 3.0.

## Languages used (each has a purpose)
- **Kotlin** — Android activity, launcher registration integration, haptics, and system-settings bridge.
- **HTML** — structure of the mobile interface.
- **CSS** — responsive layout, visual styling, animations, and reduced-motion support.
- **JavaScript** — navigation between screens, app search, clock updates, previews, and communication with Kotlin.
- **Gradle Kotlin DSL (`.gradle.kts`)** — Android build configuration.
- **XML** — Android manifest and native theme resources.

Adding unrelated languages would not make the app better; these are the appropriate technologies for this design. This project does not include a custom Android kernel or replace the Android operating system.

## Build on Android
Use a mobile IDE that can import and compile a **native Android Gradle project**. Extract the ZIP first, then open the extracted project folder (the folder containing `settings.gradle.kts`). Allow the IDE to sync/download Android Gradle dependencies, then use its Build APK option. A basic website-to-APK wrapper may ignore Kotlin and `AndroidManifest.xml`, so it will not produce the launcher behavior.

## Set Haneesh OS as the Home app
1. Install the APK built from this project.
2. Open Haneesh OS.
3. Tap **Set as your OS**.
4. On Android's official Home-app/default-app screen, select **Haneesh OS** and confirm.

Exact setting names differ between Android brands. Android must ask you to choose the default launcher; an app cannot silently replace it.

## Honest feature notes
The home/app drawer, control center, notifications, settings, and theme screens in this version are polished interface previews. The Wi-Fi, Bluetooth, mobile-data, brightness, and volume controls shown in the concept are not all connected to real system controls. Android restricts what ordinary third-party apps can change. This is a launcher, not a complete replacement OS; it does not replace the lock screen, Android system UI, notification shade, or built-in system apps.

## Project structure
- `app/src/main/java/com/haneesh/os/MainActivity.kt` — native Kotlin launcher shell.
- `app/src/main/assets/index.html` — HTML, CSS, and JavaScript interface.
- `app/src/main/AndroidManifest.xml` — launcher and app declarations.
- `app/src/main/res/values/styles.xml` — native theme.
- `app/build.gradle.kts` — Android app build settings.
