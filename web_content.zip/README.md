# Neon Rush 3D — PWA va APK qo'llanmasi

Papka tuzilishi:
- `www/`  — tayyor PWA (index.html, manifest, sw.js, icons/). Shuni hostingga qo'ysangiz PWA bo'ladi.
- `capacitor.config.json`, `package.json` — Android ilova (APK) uchun.
- `get-three.sh` / `get-three.bat` — Three.js ni `www/three.min.js` ga yuklaydi (oflayn uchun SHART).

## 0) Avval (bir marta, internet bilan)
    sh get-three.sh        # Windows: get-three.bat
`www/three.min.js` paydo bo'lishi kerak. Bo'lmasa, o'yin birinchi ochilishda CDN dan yuklab kesh qiladi,
lekin APK ichida to'liq oflayn bo'lishi uchun faylni qo'shing.

## A) Eng oson: PWABuilder (kod yozmasdan APK)
1. `www/` ichidagilarni HTTPS hostingga yuklang (GitHub Pages, Netlify, Cloudflare Pages).
2. https://www.pwabuilder.com ga saytingiz manzilini kiriting → "Package for stores" → Android.
3. APK/AAB yuklab oling. (Play Store uchun AAB kerak.)

## B) Capacitor (APK ni o'zingiz yig'asiz) — oflayn va WebRTC uchun tavsiya
Kerak: Node.js 18+, Android Studio (SDK bilan).
    npm install
    npx cap add android
    npx cap sync android
    npx cap open android      # Android Studio ochiladi → Build > Build APK(s)
Qo'shimcha sozlamalar (android/app/src/main/AndroidManifest.xml, <activity> ichida):
    android:screenOrientation="portrait"
Ilova ikonkasi: Android Studio → res → New → Image Asset (www/icons/icon-512.png dan).

## Do'st bilan (hotspot) rejimi
WebRTC kodlari (xona kodi / javob kodi) ilova ichida ham ishlaydi. Ikkala telefon bir hotspot/Wi-Fi da bo'lsin.
Ayrim qurilmalarda (mDNS/izolyatsiya) ulanish ishlamasligi mumkin — haqiqiy telefonlarda sinab ko'ring.

## Keyingi qadamlar (Play Store uchun)
- Reklama: AdMob (Capacitor plugin) — hozirgi "reklama (demo)" tugmasi o'rniga.
- Pullik Neon Pass: Google Play Billing — hozirgi "Pass (demo)" o'rniga.
- Mashina nomlari (Porsche, Bugatti, Lamborghini) — do'konga qo'yishdan oldin litsenziya yoki nomini almashtiring.
- Maxfiylik siyosati va ikonka/skrinshotlar.
