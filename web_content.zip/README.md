# 120tik Android

هذا مشروع Android Studio لتغليف واجهة 120tik الحالية داخل تطبيق Android باسم 120tik.

## بناء APK

افتح المشروع في Android Studio ثم Build > Build APK(s).

أو استخدم GitHub Actions بعد رفع المشروع إلى GitHub؛ الملف workflow غير مرفق هنا لأن البناء المحلي في هذه البيئة لا يحتوي Android SDK/Gradle.

## ملاحظة مهمة

الواجهة الحالية تعتمد على FFmpeg.wasm من CDN، لذلك هذا الإصدار كتغليف Android يحتاج اتصال إنترنت لتحميل محرك FFmpeg. إذا ظهر خطأ Engine Loading داخل التطبيق، فالمشكلة من قيود WebView/FFmpeg.wasm وليست من واجهة 120tik. النسخة النهائية الأفضل تحتاج دمج FFmpeg أصلي داخل APK بدل الاعتماد على WebView.
