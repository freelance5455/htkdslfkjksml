# 🍱 Maa Annapurna Tiffin Service - Smart Tiffin & QR Return Tracking System

**Location**: Kunwar Singh Nagar | **Contact / WhatsApp**: +91 9311155593 | **Working Days**: Monday to Saturday (Sunday Off)

A modern, aesthetic, high-speed mobile web application (PWA / APK) engineered for commercial tiffin operations delivering 100 to 150+ daily boxes.

---

## 🌟 Latest Business & System Upgrades

### 1. 🔄 System Reset Options (Daily Operations Reset & Factory Reset)
- **Daily Operations Reset (नया दिन शुरू करें)**:
  - 1-tap in Settings marks all dispatched boxes as returned/available in the kitchen for tomorrow's run.
  - Keeps all registered client accounts, history, and payment ledgers 100% safe!
- **Clear Activity Logs**: Clears today's dispatch and return logs from the dashboard.
- **Complete Factory Reset (फ़ैक्टरी रीसेट)**:
  - Gives the option to wipe all demo/test clients so you can start completely fresh with 0 clients for your live business!

---

### 2. 🏷️ 6-Digit Unique Box Codes & Instant QR Allotment
- Each container is assigned a unique 6-digit identifier:
  - `MAT001` to `MAT150` (Maa Annapurna Tiffin + 3 digits) or numeric `100001` to `100150`.
- **Instant QR Allotment**: Scanning the box's QR code opens the Allotment modal, instantly binding that specific 6-digit container to the customer with full order details and timestamps.
- **Batch Sticker Generator**: Printable A4 sticker sheet with 6-digit JetBrains Mono badges, cutting lines, and official company branding.

---

### 3. 🍲 Menu Customization During Tiffin Allotment
- When dispatching/allotting a tiffin, you can customize the meal on the fly:
  - **Editable Dishes Textarea**: Easily edit the dish descriptions (e.g., "Less spicy", "Jain / No Garlic", "Extra gravy").
  - **1-Tap Quick Add Dish Chips**:
    - `+2 Roti (+₹15)`
    - `+Sweet / Gulab Jamun (+₹20)`
    - `+Boondi Raita (+₹20)`
    - `+Extra Paneer (+₹35)`
    - `+Extra Daal (+₹20)`
    - `+Salad & Achar (+₹10)`
  - **Custom Dish Input**: Type any dish name (e.g. Papad, Chaas) and price (+₹) and tap "+ Add" — automatically adds to the dish list and recalculates the bill total!

---

### 4. ⚡ One-Time / Occasional Orders (बिना सब्सक्रिप्शन वाले ग्राहक)
- Not all customers have a monthly subscription; many order occasionally or on a trial basis.
- **Dedicated One-Time Order Tab in Allotment**:
  - Quickly enter customer name, phone, address, and room/office number.
  - Automatically bills at the single meal rate (e.g. ₹80 or ₹90) instead of the monthly ₹2500 plan!
  - Tracks the allotted 6-digit box under unreturned containers so boxes are never lost.
  - Shows distinct `⚡ ONE-TIME ORDER` badges in the Client Directory.
  - **1-Tap Upgrade**: "Make Monthly" button to convert trial customers into permanent subscribers!

---

### 5. 💳 Custom Payment QR Code Photo Upload & UPI Setup
- **Configurable UPI ID**: Set your business UPI ID (`9311155593@paytm`).
- **Upload Merchant QR Standee Photo**: Upload a photo of your shop's PhonePe, Google Pay, or Paytm QR standee directly in Settings.
- **On-Screen Live QR Display**: Tap "Show QR" anywhere in the app to display your official merchant QR code to the customer.
- **WhatsApp Delivery Slip & Bill**:
  - Automatically lists all dishes, extra items, total bill amount, and payment status (Cash Received / Paid via UPI / Due).
  - Includes direct UPI payment link: `upi://pay?pa=...`
  - Includes scan-to-pay online QR link so customers can scan and pay directly from WhatsApp!

---

### 6. 💵 Cash Collection Tracking
- Choose payment method at dispatch: **Cash Received (💵)**, **UPI Online (📱)**, or **Pay Later (⏳)**.
- Collect cash dues upon container return with a single checkbox.
- Real-time financial split on the dashboard: Today's Cash Collected vs Today's UPI Received vs Total Revenue.

---

### 7. ☀️ Lunch vs 🌙 Dinner Menus (Monday to Saturday, Sunday Off)
- Dedicated meal schedules for Monday through Saturday.
- Exact recipes integrated:
  - **Monday Lunch**: 🥘 Shahi Paneer, 🍲 Kali Masoor Daal Tadka, 🫓 Fresh Tawa Roti with Desi Ghee, 🍚 Jeera Rice, 🥗 Fresh Salad 🥒, 🍋🟩 Achar/Chutney 🍀
  - **Wednesday Lunch**: 🥘 Special Kadi Pakoda, 🍲 Mix Daal Tadka, 🫓 Fresh Tawa Roti with Desi Ghee, 🍚 Jeera Rice, 🥗 Fresh Salad 🥒, 😋 Achar
  - **Thursday Lunch**: 🥘 Rajma Masala, 🍲 Bundi Raita Or Arhar Daal Tadka, 🫓 Fresh Tawa Roti with Desi Ghee, 🍚 Jeera Rice, 🥗 Fresh Salad 🥒, 🍋🟩 Achar/Chutney 🍀

---

### 8. ☁️ AWS Cognito Authentication & DynamoDB Cloud Partitioning
- **Complete Auth Flow**:
  - **Sign Up**: Register kitchen staff / owner with email, mobile number (+91), and business name.
  - **Verify OTP**: 6-digit verification code sent directly to email via AWS Cognito.
  - **Sign In**: Secure session with `USER_PASSWORD_AUTH` and persistent tokens.
  - **Keep User Logged In**: Automatic token refresh and persistent login session across device restarts.
  - **Forgot Password**: Password reset with email verification OTP.
  - **Sign Out**: Clears session securely.
- **Zero Business Data in `localStorage`**:
  - `localStorage` is restricted **strictly** to authentication tokens (`idToken`, `accessToken`, `refreshToken`, `userId`).
  - All clients, delivery logs, meal menus, and box states are stored exclusively in **AWS DynamoDB** partitioned by the logged-in user's Cognito User ID (`userId`).
- **Cross-Device Cloud Synchronization**:
  - Log in from any Android phone, iPhone, tablet, or laptop — your business data automatically loads in real-time from DynamoDB!
- **Dual Mode (Live AWS + Instant Sandbox)**:
  - Works immediately out-of-the-box in Developer Sandbox mode.
  - 1-tap in the **AWS Setup** modal connects directly to live AWS once your User Pool and API Gateway are deployed.

---

### 9. 🏷️ Secure Serialized QR Code Generator & Cloud Database (Starts from 081026)
- **Admin QR Code Generator**:
  - Generates unique 6-digit serialized QR stickers starting strictly from **`081026`** (`081026`, `081027`, `081028`...).
  - Next available serial auto-increments sequentially without duplicates.
  - Quick generation presets: `+1`, `+5`, `+10`, `+25`, `+50`, and `+100`.
- **Permanent Cloud QR Database**:
  - Every generated QR code is stored permanently in AWS DynamoDB.
  - Full schema support: `QR Number`, `Status` (`Available`, `Allotted`, `Returned`, `Lost`), `Customer ID`, `Customer Name`, `Allotment Date`, `Return Date`, `Delivery Partner`, `Last Updated`.
- **Strict QR Code Validation**:
  - Accepts ONLY QR codes generated by this application.
  - If any external QR Code is scanned (WhatsApp, UPI, website, or foreign app), system immediately blocks it with:
    `"Invalid QR Code. This QR Code does not belong to this system."`
- **Dedicated Tiffin Return Screen (`🔄 Return Tiffin`)**:
  - Separate screen featuring live real-time counters: `Currently Out`, `Returned Today`, `In Kitchen`.
  - Camera QR scanner button + Manual search by:
    - **QR Number** (e.g. `081026`)
    - **Customer Name**
    - **Mobile Number**
  - Instant 1-tap return workflow: marks container as `Returned`, clears customer assignment, records return timestamp, and makes container `Available` again for future allotment.
- **Complete Lifecycle Audit History**:
  - Modal audit trail tracking full chronological history for every container:
    - QR Code Created Date & Initial Status
    - All past Allotments (Customer, Date/Time, Meal Type, Price, Delivery Partner)
    - All past Returns (Date/Time, Cash collection status).
- **Printable Sticker Sheet (A4 Ready)**:
  - Generates printable sheets with 6-digit JetBrains Mono serial badges and company branding for container labeling.

---

## 📖 AWS Serverless Deployment Guide
For complete, click-by-click instructions on setting up AWS Cognito, DynamoDB, Lambda, API Gateway, S3 Hosting, and IAM Roles, see:
👉 **[AWS_DEPLOYMENT_GUIDE.md](AWS_DEPLOYMENT_GUIDE.md)**

---

## 📱 How to Run as a Mobile App (APK / PWA)

### Quickest Method (Install in 1 Minute via Chrome):
1. Open `index.html` in **Google Chrome** on your Android phone.
2. Tap the **3 dots (⋮)** in the top-right corner.
3. Tap **"Install app"** or **"Add to Home screen"** (होम स्क्रीन में जोड़ें).
4. The **Maa Annapurna Tiffin** app icon will appear on your phone screen, opening full-screen just like a native APK.

### Converting to Standalone `.apk` File:
1. Visit **[PWABuilder.com](https://www.pwabuilder.com/)** or **[WebIntoApp.com](https://www.webintoapp.com/)**.
2. Provide your hosted URL or upload the folder.
3. Click "Package for Android" to download your `.apk` file for distribution to delivery staff.

