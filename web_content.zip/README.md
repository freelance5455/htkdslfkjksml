# Domino Elite — Android Project

This project packages the supplied `Domino Elite` HTML scorekeeper inside an Android WebView.

## Build in Android Studio
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select the `app` configuration.
4. Build > Build APK(s).
5. The debug APK will normally be under:
   `app/build/outputs/apk/debug/app-debug.apk`

## Notes
- The original HTML is stored at `app/src/main/assets/index.html`.
- JavaScript and DOM storage are enabled because the app uses JavaScript and `localStorage`.
- No internet permission is required by the wrapper.
