# MK Mobile Accessories POS — 5-page project

## Pages
1. Dashboard
2. Billing / POS
3. Products & Stock
4. Customers & Ledger
5. Reports & Settings

## Features
- Add, edit and delete products, with purchase price, sale price and stock
- Create bills, calculate discount/received/due, deduct stock
- Customer list, outstanding balance and receive-payment action
- Sales history, estimated gross profit, CSV export
- WhatsApp invoice text sharing and printable invoice / Save as PDF
- JSON backup and restore
- Offline-first browser storage using localStorage
- Mobile-friendly Blue & White interface

## Important limitations
- This is a working HTML/CSS/JavaScript web-app project, not a prebuilt APK.
- Data is saved in the browser on this device. Clearing browser data can delete it; use Backup regularly.
- WhatsApp opens with invoice text filled in. You must review and press Send yourself. The web version does not attach a PDF automatically to WhatsApp.
- To share an actual PDF file through Android share sheet, a native wrapper must implement Android file sharing / share intents.
- Language dropdown is a placeholder; the current interface labels are English. Urdu/Pashto product and customer text can be entered, but a complete translated UI is not included yet.
- Profit is estimated using recorded purchase price and discount; other business expenses are not included.

## Test on your phone
1. Extract the ZIP to a folder.
2. Open `index.html` in Chrome, or upload the folder to a static host that serves HTTPS.
3. Add a product under Products & Stock.
4. Go to Billing / POS, tap a product, enter received amount and Save Bill.
5. Test WhatsApp sharing and printing.
6. Under Reports & Settings, download a JSON backup.

## Build an APK using only a mobile phone (online wrapper)
A web-to-APK service can package the site, but the availability and requirements of third-party sites can change. Use a reputable wrapper that accepts an HTML website or hosted HTTPS URL and supports offline assets.
1. First host this folder as a static website with HTTPS, or use a wrapper that can import a ZIP/HTML project directly.
2. In the wrapper, set app name to `MK Mobile Accessories POS`.
3. Set start page to `index.html` (or your hosted HTTPS URL).
4. Set app icon to `assets/mk-icon.svg` or use the included SVG as a reference to create a PNG icon.
5. Enable offline/local assets if the wrapper supports it. Do not use a remote-only website if you need offline operation.
6. Build/download the APK, then open the APK on your phone and allow installation from that source if Android asks.
7. Test billing, storage after closing/reopening, printing and WhatsApp sharing on the installed APK.
8. Keep the project ZIP and a JSON backup in a safe location.

## Suggested native Android route for later
For a more reliable APK, use a WebView wrapper with local assets and Android share intents. The wrapper should preserve local storage and expose Android's print/share functionality. For Google Play Store publishing, you will generally need an Android App Bundle (AAB), signing key, app privacy details and current Play Console compliance.

## Project files
- `index.html`: all five pages and app logic
- `manifest.json`: PWA metadata
- `sw.js`: basic offline cache for HTTPS-hosted use
- `assets/mk-icon.svg`: app logo/icon
