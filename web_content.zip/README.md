# SAVETUBE — başlangıç projesi

Siyah temalı, mobil uyumlu video/Shorts arayüzü ve Express + MongoDB API başlangıç projesi.

## Gerekenler
- Node.js 18 veya üzeri
- MongoDB bağlantısı
- Video dönüştürme kullanılacaksa sistemde FFmpeg

## Kurulum
1. Bu ZIP'i çıkar.
2. Proje klasöründe `.env.example` dosyasını `.env` olarak kopyala.
3. `.env` içindeki `JWT_SECRET` değerini en az 32 karakterli rastgele bir sırla değiştir. Gerçek sırları kaynak koduna koyma.
4. `MONGODB_URI` değerini MongoDB bağlantına göre ayarla.
5. Terminalde `npm install` ve ardından `npm start` çalıştır.
6. Tarayıcıda `http://localhost:5000` adresini aç.

## API uçları
- `GET /api/health` — sunucu durumu
- `POST /api/auth/register` — `{ "username":"...", "email":"...", "password":"en az 10 karakter" }`
- `POST /api/auth/login` — `{ "username":"...", "password":"..." }`
- `GET /api/videos` — son 50 video
- `GET /api/videos?type=shorts` — Shorts
- `POST /api/videos` — Bearer token ile video kaydı; JSON alanları: `title`, `videoUrl`, `type`, `duration` (isteğe bağlı: `description`, `thumbnailUrl`)
- `POST /api/videos/:id/view` — görüntülenme sayacını bir artırır
- `GET /api/admin/users` — admin token gerektirir
- `POST /api/comments/filter-preview` — yorum filtreleme örneği

## Güvenlik notları
- Bu proje başlangıç iskeletidir; üretime hazır tam video barındırma sistemi değildir.
- Kasıtlı arka kapı/gizli yönetici hesabı kaldırıldı. Admin yetkisini yalnızca güvenilir bir hesabın veritabanındaki `role` alanını elle `admin` yaparak verin.
- Sahte izlenme/beğeni/abone enjeksiyonu uçları eklenmedi; sayaçları gerçek etkileşimlerden türetin ve kötüye kullanımı sunucu tarafında sınırlandırın.
- Üretimde HTTPS, e-posta doğrulama, parola sıfırlama, CSRF/CSP başlıkları, yükleme doğrulama, dosya depolama, gerçek beğeni/yorum şemaları, moderasyon ve izlenme başına tekilleştirme eklenmelidir.
- CORS ayarını yayınlayacağınız gerçek alan adına göre değiştirin.
- `videoProcessor.js` FFmpeg ikilisinin kurulu olduğunu varsayar; dosya yükleme ve iş kuyruğu entegrasyonu ayrıca kurulmalıdır.
- Aktivite kontrolü yalnızca hatırlatmadır; platform algoritmasının erişimi düşürdüğünü ölçmez.
