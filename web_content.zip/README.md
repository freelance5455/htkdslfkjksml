# MSS Satpam • PT. Mitracomm (Web App)

Aplikasi web mobile-friendly untuk patroli barcode + laporan kejadian.

## Cara Pakai

1. Extract semua file.
2. Buka `index.html` di browser HP (Chrome recommended).
3. Untuk kamera scan barcode bekerja optimal:
   - Jalankan lewat localhost, atau
   - Upload ke hosting (Netlify / Vercel / GitHub Pages) agar HTTPS.

## Fitur

**Petugas**
- Scan barcode (kamera otomatis) atau pilih manual
- Kondisi Aman / Temuan (+ detail max 100 kata)
- Wajib 3 foto
- Laporan kejadian lengkap
- Lihat riwayat sendiri

**Admin**
- Semua fitur petugas
- Tambah / hapus / generate barcode (CODE128)
- Lihat semua data + filter
- Edit status kejadian
- Export Excel & PDF

## Login
- Isi nama → pilih peran (Petugas / Admin)

Data tersimpan di LocalStorage browser.
