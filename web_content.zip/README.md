# SHOHAN KING ENGINE - Android App & APK Build Guide

Built for mobile users without a computer. Follow these steps to build your Android APK using free GitHub Actions!

## How to Build the APK Using Only Your Android Phone:

1. **Upload this project to GitHub**:
   - Go to [github.com](https://github.com) on your phone browser.
   - Tap **New Repository** (e.g., `shohan-king-engine`).
   - Upload the files from this ZIP to the repository.

2. **Run the Automated Cloud APK Builder**:
   - In your repository, tap the **Actions** tab.
   - Tap **Build Android APK (SHOHAN KING Engine)**.
   - Tap **Run workflow** -> select branch `main` -> tap **Run workflow**.

3. **Download Your APK**:
   - Wait ~2 minutes for the workflow to complete (green checkmark).
   - Tap the completed workflow run.
   - Scroll down to the **Artifacts** section.
   - Tap **SHOHAN-KING-ENGINE-debug-apk** to download the `.zip` containing `app-debug.apk`.
   - Install the APK directly on your Android phone!

## Engine Features:
- Carrom Practice Mode & Playable Physics Simulator
- Precision Aim-Line & Angle Calculator (cushion bounces, cut angles, double-coin carom)
- Floating Companion Overlay Interface (with SYSTEM_ALERT_WINDOW support)
- Mobile-first esports silver & neon electric-blue design
