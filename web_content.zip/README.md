# HANDOFLOGIC TOOL WA — Android starter

Ini adalah **project sumber Android**, belum berupa APK terkompilasi.

## Buka dan build
1. Ekstrak ZIP.
2. Buka folder `HandoflogicToolWA` melalui Android Studio.
3. Pastikan Android SDK 35 dan JDK yang sesuai tersedia.
4. Pilih **Build > Build APK(s)**.
5. APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.

## Status fitur
- UI Matrix Hacker: tersedia.
- Dashboard Owner demo: tersedia.
- Form teks dan pemilihan gambar: UI demo tersedia.
- Preview kampanye: tersedia.
- Pengiriman WhatsApp sungguhan: belum diaktifkan.
- Autentikasi aman: belum diaktifkan.

## Penting sebelum produksi
Login pada starter ini hanya demonstrasi antarmuka: username `handoflogical` dan password apa pun yang tidak kosong akan membuka dashboard. Jangan gunakan untuk melindungi data atau akun sungguhan.

Untuk produksi:
- Buat backend (misalnya Node.js) dan autentikasi server-side.
- Simpan password dengan Argon2id/bcrypt; jangan hardcode password/token di APK.
- Simpan token WhatsApp Cloud API hanya di backend.
- Integrasikan Meta WhatsApp Business Platform resmi.
- Kirim hanya kepada penerima yang telah memberi persetujuan (opt-in), gunakan template yang disetujui bila diwajibkan, patuhi rate limit, dan sediakan mekanisme berhenti berlangganan.
- Tambahkan audit log, pembatasan peran OWNER, dan proteksi endpoint.

Starter ini tidak melakukan pengiriman massal dan tidak mengotomatisasi WhatsApp pribadi.
