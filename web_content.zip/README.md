# CYBERGUARD AI — pacote do aplicativo + backend

Este ZIP contém:
- `index.html`: aplicativo CYBERGUARD com painel, ferramentas educativas e tela Cyber AI.
- `server.js`: backend Node.js que chama a API da OpenAI sem expor a chave no aplicativo.
- `.env.example`: modelo das variáveis necessárias.
- `package.json`: dependências e comando de inicialização.

## Importante
A integração está preparada, mas a IA NÃO funciona até publicar o backend e configurar uma chave válida da OpenAI API. A chave nunca deve ser colocada no `index.html`, no APK ou compartilhada no chat. O uso da API pode gerar cobrança na conta da plataforma.

## Como ativar o backend
1. Publique esta pasta em um serviço de hospedagem que execute Node.js (por exemplo, Render, Railway ou outro).
2. Configure o comando de instalação `npm install` e inicialização `npm start`.
3. Nas variáveis secretas do serviço, configure:
   - `OPENAI_API_KEY`: sua chave secreta da OpenAI API.
   - `OPENAI_MODEL`: `gpt-4.1-mini` (ou outro modelo disponível na sua conta).
   - `ALLOWED_ORIGIN`: origem HTTPS do site/app, se aplicável. Para testes pode deixar sem definir; em produção, restrinja à origem correta.
4. Depois de publicar, teste `https://SEU-SERVIDOR/health`.
5. Abra o CYBERGUARD, vá em **Cyber AI** e cole o endereço HTTPS do backend.

## Como gerar o APK
O `index.html` é a interface web. Um conversor ZIP-para-APK pode empacotar a interface, mas isso NÃO hospeda o backend. A IA só responderá depois que o backend estiver publicado e acessível pela internet. Se o conversor exigir um ZIP específico com `index.html` na raiz, use o arquivo `CYBERGUARD_HTML_para_APK.zip` separado; para este projeto com IA, primeiro configure o backend e depois atualize o endereço HTTPS no app.

## Segurança e limites
- O backend aplica limite simples de 20 pedidos por minuto por IP e limite de tamanho.
- Não envie senhas, códigos de autenticação, documentos ou dados sensíveis.
- A Cyber AI é educativa: não faz varredura real do telefone, não confirma que links/arquivos são seguros e não substitui ferramentas profissionais.
- Configure limites de gastos e monitore o uso na sua conta de API.
