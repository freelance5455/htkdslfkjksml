# Daily Progress Manager V2 - Fixed

This package fixes the previous **Missing HTML** problem by including a complete standalone `web/index.html`.

## Easiest way to make an APK
Use the `web` folder as the source for a web-to-APK/PWA wrapper. It is self-contained and works offline using local storage.

## Native Android project
The `android` folder contains the original Android project.
