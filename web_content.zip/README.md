# StudyTrack Premium — Android Studio WebView Project

Includes:
- Stream selection: Commerce, Science, Arts / Humanities, Other
- Stream-wise subjects
- Attendance: Present / Absent / Half Day
- Study timer
- Progress and history
- Premium Practice Papers
- Premium plans: ₹49 for 2 months and ₹299 for 1 year
- Local browser storage inside the WebView

## Generate APK
Open this project in Android Studio, sync Gradle, then choose:
Build → Build APK(s)

Debug APK:
app/build/outputs/apk/debug/app-debug.apk

## Premium payments
The ₹49 and ₹299 buttons are currently UI/demo selections. Real purchases require Google Play Billing or another payment service and entitlement verification.
