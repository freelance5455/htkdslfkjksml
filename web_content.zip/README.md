# Blender Syaoran 1.1.2 — parche del selector de archivos

Esta versión corrige el botón Abrir modelo para Android WebView:
- El botón llama explícitamente al selector de archivos.
- El selector usa ACTION_GET_CONTENT con chooser para mejor compatibilidad.
- Se añade permiso INTERNET para cargar Three.js desde CDN.
- Se muestran errores de importación en pantalla.

Formatos de prueba: `.glb` y `.obj`. GLTF `.gltf` puede requerir archivos externos (por ejemplo `.bin` y texturas) y todavía no está garantizado si se selecciona solo el `.gltf`.

## Compilar
Con Android SDK y Gradle: `gradle assembleDebug`
Salida: `app/build/outputs/apk/debug/app-debug.apk`.

Este ZIP es código fuente corregido, no un APK ya compilado.


Paquete Android: `com.blender.syaoran`. Versión: `1.1.2` (versionCode 3). El selector de archivos usa `ACTION_OPEN_DOCUMENT` y el puente WebView `onShowFileChooser`.
