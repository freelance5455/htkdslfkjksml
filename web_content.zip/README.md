# VLOGGER BHAU STUDIO — In-House AI Edition

This edition is intentionally self-contained and does not integrate external AI/media/social APIs.

## Stack
- React 18
- Vite
- Tailwind CSS
- Lucide React
- Context API
- Browser Web Speech API for RK
- Async local neural-runtime simulation classes

## Architecture

`src/engine/`
- `LocalLLMEngine.js` — guarded local script generation + fact index
- `ImageStudioEngine.js` — local image-rendering simulation
- `AcousticVoiceSynthesizer.js` — local acoustic synthesis simulation
- `AvatarLipSyncRenderer.js` — local identity/motion/lip-sync simulation
- `PipelineEngine.js` — independent seven-stage orchestration

Every engine emits internal logs and measured runtime durations using asynchronous processing. The implementation is a deterministic product prototype: it demonstrates the orchestration and security boundaries without claiming that a browser can perform production-scale neural inference.

## Run

```bash
npm install
npm run dev
```

Open the Vite URL shown in the terminal.

## Login
The UI starts locked. Username and password fields are blank. Any non-empty credentials unlock the local prototype.

## Important production security note
Client-side security controls are UX/security simulations, not a substitute for server-side authentication, authorization, secure key storage, cryptographic key management, CSRF protections, audit logging, and a real identity provider. The current build deliberately keeps all AI processing local/simulated and contains no third-party service credentials.

## 730-day matrix
The dashboard exposes the requested 48,180 = 730 × 3 × 22 model and a Maharashtra-first state sequencing policy. The prototype does not claim that 48,180 pieces of factual content have already been generated.
