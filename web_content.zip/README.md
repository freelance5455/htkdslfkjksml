# Balance Tracker Web App

Fresh, mobile-friendly balance tracker using plain HTML, CSS and JavaScript.

## Run
Open `index.html` in any modern browser.

Data is stored locally in the browser using localStorage. No server is required.
