# GuitarMaster Pro — Android APK

Projet Android minimal qui embarque `index.html` dans une WebView. Les fonctions HTML/JavaScript sont embarquées et les fonctions principales peuvent fonctionner hors ligne.

## Générer l'APK avec GitHub Actions depuis un téléphone

1. Créez un dépôt GitHub (par exemple `GuitarMasterPro`) et choisissez **Public** ou **Private**.
2. Décompressez ce ZIP sur le téléphone.
3. Dans le dépôt GitHub, utilisez **Add file → Upload files** pour envoyer tous les fichiers et dossiers du projet, y compris `.github/workflows/build-apk.yml`. Vérifiez que `app/`, `build.gradle`, `settings.gradle` et `.github/` sont à la racine du dépôt.
4. Validez avec **Commit changes**.
5. Ouvrez l'onglet **Actions**, choisissez **Build GuitarMaster Pro APK**, puis **Run workflow** si nécessaire.
6. Attendez que le workflow soit terminé en vert.
7. Ouvrez le workflow terminé et téléchargez l'artifact **GuitarMasterPro-APK**. Décompressez l'archive téléchargée : elle contient `app-debug.apk`.
8. Ouvrez `app-debug.apk` sur Android. Si Android le demande, autorisez temporairement l'installation depuis cette source dans les paramètres, puis installez.

## Notes
- APK de test/debug, non signé pour publication sur Play Store.
- Les fonctions HTML sont intégrées localement. Pas besoin d'Internet après installation pour les fonctions locales.
- Le rappel à 18 h 30 du HTML peut ne pas fonctionner lorsque l'application est fermée, car un rappel fiable en arrière-plan nécessite une intégration Android native distincte.
