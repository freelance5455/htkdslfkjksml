# ANMOL FIGHTERS v0.3 — Multiplayer Prototype

This package contains a real WebSocket room server and a lightweight browser client.

## Run server
1. Install Node.js.
2. In `server/`, run `npm install`.
3. Run `npm start`.
4. Open the client through a web server pointing at the same host/port.

## What is implemented
- Room creation with a 6-character room code
- Join room
- Up to 8 players
- Server-authoritative player IDs, positions and HP
- Shooting damage messages
- Ability events
- Lightweight client rendering

This is an early networking prototype, not a finished anti-cheat production server.
Google authentication, matchmaking, proper third-person 3D rendering, mobile controls,
persistent accounts, and production hosting still need to be added.
