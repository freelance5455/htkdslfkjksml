# KOTA'S DAILY ROUTINE — PWA

This package is an installable Progressive Web App version of KOTA'S DAILY ROUTINE.

## Install on iPad
1. Host this folder on an HTTPS web address.
2. Open the address in Safari.
3. Tap Share → Add to Home Screen.
4. Open KOTA from the new Home Screen icon.

## Install on Android
1. Open the HTTPS address in Chrome.
2. Use the browser's Install app / Add to Home screen option.
3. Open KOTA from the new icon.

## Important
PWA installation requires HTTPS (or localhost). Opening index.html directly as a file will not enable service-worker installation.

The Supabase cloud-sync configuration from the current KOTA app is preserved.
