# 🍱 Maa Annapurna Tiffin Service - Smart Tiffin & QR Return Tracking System

**Location**: Kunwar Singh Nagar | **Contact / WhatsApp**: +91 9311155593 | **Working Days**: Monday to Saturday (Sunday Off)

A modern, aesthetic, high-speed mobile web application (PWA / APK) engineered for commercial tiffin operations delivering 100 to 150+ daily boxes.

---

## 🌟 Latest Upgrades & Key Features

### 1. 💳 WhatsApp Payment QR Code & Instant UPI Link
- Whenever a delivery slip or payment reminder is sent via WhatsApp, it includes:
  - **Instant UPI Deep Link**: Directly opens Google Pay, PhonePe, Paytm with payee `9311155593@paytm` and exact bill amount.
  - **Scan-to-Pay QR Code Link**: A clickable link (`api.qrserver.com`) that displays the exact UPI payment QR code on the customer's phone.
- **On-Screen UPI QR Modal**: Need the customer to scan on delivery? Tap the **"Show QR"** button anywhere in the app to display a dynamic payment QR code right on your mobile screen.

---

### 2. 💵 Cash Collection Tracking (Cash vs UPI)
- During dispatch, choose payment status:
  - **Paid via Cash**: Recorded immediately in today's cash collections.
  - **Paid via UPI**: Recorded under UPI collections.
  - **Payment Due / Later**: Marked as pending balance.
- **On Box Return**: If the customer had pending dues, the return modal allows you to collect cash on the spot with a single checkmark (`Collect ₹80 Cash Due Now`).
- **Dashboard Financials**: Real-time breakdown of **Today's Cash Collected (💵)** vs **Today's UPI Payments (📱)** vs **Total Revenue**.

---

### 3. 🏷️ Attractive 6-Digit Box Code & Dedicated QR Generator
- **6-Digit Formats Supported**:
  - `MAT001` to `MAT150` (Maa Annapurna Tiffin + 3 digits)
  - `100001` to `100150` (Pure 6-digit numeric IDs)
- **Batch Sticker Generator**:
  - Set box range (e.g. 1 to 150).
  - Generates crisp high-contrast QR codes with 6-digit JetBrains Mono badges.
  - Print-ready A4 layout with cutting lines and company branding.

---

### 4. 🎨 Aesthetic SaaS UI & Mobile-First Experience
- Designed with **Plus Jakarta Sans** and **JetBrains Mono** typography.
- Glassmorphic translucent cards (`backdrop-filter: blur(12px)`), warm saffron-orange gradients, smooth micro-interactions, and high-contrast badges.
- Bottom floating navigation bar with central highlighted **"Scan"** action button.

---

### 5. 🔍 Real-Time Searchable Client Selection
- Live instant search box filters by customer name, phone number, or delivery route as you type.
- On-the-spot "+ Add New Client" tab for rapid zero-delay registrations during delivery.

---

### 6. ☀️ Lunch vs 🌙 Dinner Menus (Monday to Saturday, Sunday Off)
- Dedicated meal schedules for Monday through Saturday.
- Exact custom recipes integrated:
  - **Monday Lunch**: 🥘 Shahi Paneer, 🍲 Kali Masoor Daal Tadka, 🫓 Fresh Tawa Roti with Desi Ghee, 🍚 Jeera Rice, 🥗 Fresh Salad 🥒, 🍋🟩 Achar/Chutney 🍀
  - **Wednesday Lunch**: 🥘 Special Kadi Pakoda, 🍲 Mix Daal Tadka, 🫓 Fresh Tawa Roti with Desi Ghee, 🍚 Jeera Rice, 🥗 Fresh Salad 🥒, 😋 Achar
  - **Thursday Lunch**: 🥘 Rajma Masala, 🍲 Bundi Raita Or Arhar Daal Tadka, 🫓 Fresh Tawa Roti with Desi Ghee, 🍚 Jeera Rice, 🥗 Fresh Salad 🥒, 🍋🟩 Achar/Chutney 🍀
- Custom Extras Checklist (Extra Roti, Sweet/Gulab Jamun, Papad, Raita).

---

### 7. 📧 Email Login & Daily Data Backup
- Pre-configured for `+91 9311155593` and `annapurna.tiffin@gmail.com`.
- 1-tap automated email sync with complete box status, pending return clients list, payment summaries, and full `.json` database file.

---

## 📱 How to Run as a Mobile App (APK / PWA)

### Quickest Method (Install in 1 Minute via Chrome):
1. Copy or host the project files or open `index.html` in **Google Chrome** on your Android phone.
2. Tap the **3 dots (⋮)** in the top-right corner.
3. Tap **"Install app"** or **"Add to Home screen"** (होम स्क्रीन में जोड़ें).
4. The **Maa Annapurna Tiffin** app icon will appear on your phone screen, opening full-screen just like a native APK.

### Converting to Standalone `.apk` File:
1. Visit **[PWABuilder.com](https://www.pwabuilder.com/)** or **[WebIntoApp.com](https://www.webintoapp.com/)**.
2. Provide your hosted URL or upload the folder.
3. Click "Package for Android" to download your `.apk` file for distribution to delivery staff.

---

## 🖨️ Printing Box QR Stickers

1. Open the app and navigate to **"QR Stickers"**.
2. Select 6-Digit Format (`MAT-001` or `100001`).
3. Set your box range (e.g., 1 to 150) and tap **"Generate QR Stickers"**.
4. Tap **"Print / Save PDF"** to print directly onto adhesive sticker sheets.
