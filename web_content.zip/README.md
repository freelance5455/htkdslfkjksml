# Arazi Sicili — Android (APK) projesi

Oyun, Capacitor ile bir Android uygulamasına sarılmıştır (oyunun kendisi `www/index.html`).
Bilgisayarına Android Studio kurmana gerek yok; GitHub APK'yı senin yerine derler.

## Yöntem 1 — GitHub ile (önerilen, kurulum yok)
1. github.com'da ücretsiz hesap aç → **New repository** (adı: `arazi-sicili`, Private olabilir).
2. Bu klasörün içindekileri repoya yükle (**Add file → Upload files**).
   **Önemli:** `.github/workflows/build-apk.yml` dosyası gizli klasörde olduğu için bazı bilgisayarlarda
   sürükle-bırak ile gelmeyebilir. Gelmediyse: **Add file → Create new file** de, dosya adına
   `.github/workflows/build-apk.yml` yaz ve bu zip'teki dosyanın içeriğini yapıştır.
3. Repoda **Actions** sekmesi → soldan **APK derle** → **Run workflow**.
4. 4-6 dakika sonra iş yeşile dönünce, çalışmanın sayfasının en altındaki **Artifacts** bölümünden
   `arazi-sicili-apk` dosyasını indir. Zip'in içinde `app-debug.apk` vardır.
5. APK'yı telefona gönder (Drive, kablo, e-posta). Telefonda dosyaya dokun →
   "Bilinmeyen kaynaklardan yüklemeye izin ver" → **Yükle**.

## Yöntem 2 — Kendi bilgisayarında (Android Studio varsa)
```
npm install
npx cap add android
npx cap sync android
npx cap open android      # Android Studio açılır: Build > Build APK(s)
```

## Oyunu güncellemek
Yeni sürümü `www/index.html` olarak kopyala, repoya yükle; "APK derle"yi tekrar çalıştır.

## Bilinmesi gerekenler
- Mobil uyumlu sürüm: parmakla kaydırma, iki parmakla yakınlaştırma ve +/− düğmeleri eklendi.
- Bu **debug** APK'dır: kendi telefonunda/arkadaşlarında kurulur, Play Store'a doğrudan yüklenmez
  (onun için imzalı "release" derlemesi gerekir).
- Oyun harita ve iller için internetten veri çekiyor; uygulama internetsiz açılırsa harita gelmeyebilir.
- Oyundaki yapay zekâ özellikleri (api.anthropic.com çağrıları) Claude'un içinde çalışacak şekilde yazılmış;
  uygulamada kendi API anahtarın olmadan çalışmaz.
- Kayıtlar (localStorage) uygulamanın içinde tutulur; uygulamayı silersen kayıtlar da silinir.
