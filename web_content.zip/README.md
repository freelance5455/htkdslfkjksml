# NIVEX Editor Mobile V3.2
A mobile-first creative editor foundation with an original identity and a modular compositor architecture.

## Toolchain
React + TypeScript + Vite 8.3.0. The create-vite 9.2.1 source provided by the user is preserved in `vendor/create-vite-9.2.1/`.

## Run
Node 20.19+ is expected. Run `npm install`, then `npm run dev`. Build with `npm run build`.

## Notes
Bolt.new, Lovable, Muse, Windsurf and Cursor are development tools; they are documented as handoff options but are not embedded runtime dependencies. The editor is designed to expand by optional modules/packs instead of forcing a 200 MB initial payload.
