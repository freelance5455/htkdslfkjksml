KEDRICK AI FULL PROJECT

This is a complete AI nursing-assistant starter project. It requires a server and secret API key; do NOT put the key in the APK/frontend.

SETUP:
1. Extract ZIP.
2. Deploy backend/ to Python hosting.
3. Add OPENAI_API_KEY as a secret.
4. Add NURSING_VECTOR_STORE_ID for your approved nursing documents.
5. Install requirements.txt.
6. Start with gunicorn server:app.
7. Test the URL.
8. Connect the frontend to that URL and package it into your existing Android app.

The knowledge base must contain only documents you are legally allowed to use. Always verify clinical decisions with current authoritative guidelines.