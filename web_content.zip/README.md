# Exness Gold Bot — Phone-Only Android Edition

## Architecture

This edition is designed to run entirely on an Android phone:

Android APK
  ├─ Local XAUUSD strategy/risk engine
  ├─ Local trade journal
  └─ Open Exness/MT5 mobile for order execution

There is no VPS, PC, Python bridge, or MQL5 Expert Advisor.

## Important execution limitation

The Android MT5 application does not support custom MQL5 Expert Advisors. Exness provides mobile trading through Exness Trade and MT5 mobile, but this project does not embed broker credentials or pretend to have an unsupported direct order API.

Therefore this phone-only build can calculate signals, risk, lot-size estimates, SL/TP levels, and keep a local journal. Actual broker order placement is handed off to the official Exness/MT5 mobile app.

Do not put an MT5 master password into this APK.

## Default strategy inputs

- Symbol: XAUUSD
- Risk: 0.25%
- Daily loss limit: 1%
- Maximum trades/day: 3
- EMA: 20 / 50
- RSI: 14
- Demo-first workflow

The strategy calculator uses values entered on the phone. It does not claim to receive live broker quotes.

## Build

Open the project in Android Studio, sync Gradle, then:

Build > Build Bundle(s) / APK(s) > Build APK(s)

APK:
`app/build/outputs/apk/debug/app-debug.apk`

## Phone-only workflow

1. Install the APK.
2. Enter account balance, current XAUUSD price and strategy values.
3. Tap CALCULATE SIGNAL.
4. Review the signal, estimated position size, SL and TP.
5. Tap OPEN EXNESS to continue in the official mobile trading app/site.
6. Place the order yourself and record it in the journal.
7. Start with a demo account.

This build is intentionally manual at the broker-execution step so it does not require a VPS or PC and does not store broker passwords.
