# ZIP to APK Builder

A starter application that lets a user upload a ZIP containing an Android/Gradle project, sends it to a FastAPI backend, builds it inside an isolated Docker container, and downloads the resulting APK.

## Project structure

- `index.html` — browser UI requested for the project
- `backend/main.py` — FastAPI upload/build/download API
- `backend/requirements.txt` — Python dependencies
- `builder/Dockerfile` — isolated Android/Gradle build image
- `docker-compose.yml` — starts the API
- `backend/build_worker.py` — build orchestration
- `backend/static/` — optional place for frontend assets

## Run

Requirements: Docker Desktop / Docker Engine and Docker Compose.

```bash
docker compose up --build
```

Then open:

http://localhost:8000

The backend accepts Android/Gradle project ZIPs. It validates ZIP paths and runs the Gradle build in a temporary container.

## Supported project

The ZIP should contain a Gradle Android project, for example:

my-project.zip
  settings.gradle(.kts)
  build.gradle(.kts)
  gradlew
  app/
    build.gradle(.kts)
    src/main/AndroidManifest.xml

The MVP builds a debug APK. Release builds require a signing configuration.

## Security

Uploaded projects are untrusted code. The worker uses Docker isolation, a timeout, temporary directories, and resource/network restrictions. Do not expose this service publicly without adding authentication, quotas, stronger sandboxing, malware scanning, and persistent job storage.

Android installation is intentionally delegated to the normal Android package installer; an ordinary app cannot silently bypass Android's installation/security controls.
