# FX Trader

A forex trading research toolkit: indicator/ML strategies, a risk-managed backtester,
a local paper broker, and an OANDA practice-account trading loop.

> **Not financial advice.** Most retail FX traders lose money. A good backtest does not
> guarantee future results. Start with backtests, then the practice account, and never risk
> money you can't afford to lose. Live trading is disabled unless you pass explicit flags.

## The app (easiest)
Double-click **Run FX Trader.bat**. Your browser opens the FX Trader app: pick your price data (or upload a CSV),
pick a strategy, press **Run backtest**. Keep the black window open while using it.

## Setup
```bash
pip install -r requirements.txt
```

## Backtest
```bash
# synthetic data (demo only)
python -m fx_trader backtest --strategy trend
python -m fx_trader backtest --strategy ml

# your own OHLC CSV (columns: time,open,high,low,close)
python -m fx_trader backtest --csv EURUSD_H1.csv --pair EURUSD --strategy ml --out trades.csv
```

## Practice trading (OANDA demo account)
```bash
export OANDA_TOKEN=...      # from your OANDA practice account
export OANDA_ACCOUNT=...
python -m fx_trader live --strategy trend --pair EURUSD
```
Real money needs `--live --i-understand-the-risk`. Test on practice for weeks first.

## How it works
- **trend**: EMA(20/50) trend filter + RSI confirmation.
- **brain**: gradient-boosting model that learns which setups hit their take-profit before their stop; walk-forward, only trades above a break-even probability; drawdown governor halves size at 10% DD and stops at 30%.
- **ml**: walk-forward logistic regression on returns/RSI/EMA-gap/ATR/z-score features; retrained
  on an expanding window with no lookahead; trades only when probability > 55%.
- **Risk**: each trade risks 1% of equity with an ATR-based stop, 2:1 take-profit, leverage cap,
  spread cost, cooldown, and a daily-loss halt in the live loop.
- Signals use closed bars and execute on the next bar's open. Stops are checked conservatively.

## Limitations
Single pair, one position at a time, P&L assumes quote currency ≈ account currency (exact for
xxxUSD pairs), no swaps/commissions, no news filter. Extend `strategy.py` to add your own ideas.
