# English Tenses Quest — Vivid Aurora revision

This revision intentionally uses one vivid visual direction for now instead of a set of dark palettes.

## Changes
- Reworked the dashboard and internal topic/lesson cards with vivid cyan, violet and magenta gradients inspired by the supplied reference; removed drop shadows and the old black-heavy treatment.
- Removed the five-theme selector. Aurora is the current theme; selecting a wallpaper activates wallpaper-matched accent sampling.
- Fixed the wallpaper picker path: the file input is no longer inside a hidden parent, and Android `MainActivity` now returns the chosen image URI through `onActivityResult` to WebView.
- Kept background selection as the only file picker. Lessons and audio remain app-local.
- Categories with no actual content remain hidden; Vocabulary and Grammar are not shown as placeholders.
- Wallpaper and settings are stored locally on the device.

## Notes
The Android project source is provided in this archive. A physical-device visual test and a release APK build have not been performed in this environment. Build with Android Studio or AndroidIDE and verify the picker on the target Android version.
