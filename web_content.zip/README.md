# JZst Games — Chess Arena

A mobile-friendly, offline-capable chess website project for Spck Editor.

## Files
- `index.html` — game page, results popup, and local profile dialog
- `style.css` — responsive layout and board styling
- `script.js` — chess rules, move handling, sound effects, and local profile demo
- `assets/` — transparent chess piece images adapted from the reference image supplied for this project

## Run in Spck Editor
1. Import this ZIP as a project.
2. Open `index.html`.
3. Tap Run/Preview.

## Accounts note
The Sign up / Sign in feature is a **local demo profile** stored in this browser on this device. It is not connected to a server, does not sync between devices, and should not be used with a password from another service. Real online accounts require a backend/authentication provider.

The chess game and sound effects work offline. Browser audio starts after a user interaction.
