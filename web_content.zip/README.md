# MindTrace Android project

This is the Android app wrapper for **MindTrace**, the detective-style AI assistant inspired by the general observation and reasoning traits associated with Patrick Jane in *The Mentalist*. The app itself is named MindTrace; the GitHub repository may remain named `AutoClicker`, and the archive may be named `project.zip`.

## Build APK with GitHub Actions

1. Upload the contents of this ZIP to the root of your existing GitHub repository, alongside the existing `.github` folder. Do not upload the ZIP inside itself as a replacement for the extracted project files.
2. Keep the workflow that searches for `settings.gradle.kts` and builds `:app:assembleDebug`.
3. Run Actions. The APK artifact will be named `MindTrace` if you change the workflow artifact name, or `AutoClicker` if you leave the old artifact name unchanged.

## App features

- Mobile-first detective-style chat interface
- Offline question prompts and structured reasoning
- Screenshot and video upload (video is sampled into a few frames)
- Voice input/output where Android WebView/browser support allows it
- Optional online AI backend configured in the app's settings

## Online AI and API keys

The included web app's server proxy currently uses an OpenAI-compatible chat-completions endpoint. It does not directly accept a Gemini key in the browser. If using Gemini, configure a trusted backend that speaks the app's `/api/chat` interface and stores the Gemini API key as a server environment secret. Never put a private API key in the app's JavaScript or commit it to GitHub.

The app can open and run in offline mode without an API key. Offline mode uses rule-based prompts and does not truly understand uploaded image pixels.
