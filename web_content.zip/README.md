# Isidore — Android Calibre Repository Client & Bulk Downloader

Isidore is a modern Android client (Kotlin + Jetpack Compose) for browsing and bulk-downloading publications from the Calibre web repository at https://isidore.co/CalibreLibrary/.

## Features
- Direct SQLite parsing of Calibre's native `metadata.db`
- Streaming media poster grid layout (2:3 aspect ratio) with high-contrast typography
- Full search and sorting ("By Publication Name" & "By Author")
- WorkManager background bulk downloader with Storage Access Framework (SAF)
- Works with physical SD cards, USB OTG, internal storage, and mounted SMB/NFS network drives

## Building the APK
1. Open this directory in **Android Studio Ladybug (2024.2+)** or newer.
2. Allow Gradle sync to complete with JDK 17+.
3. Run or assemble the APK:
   ```bash
   ./gradlew assembleDebug
   ```
4. The generated APK will be at `app/build/outputs/apk/debug/app-debug.apk`.
