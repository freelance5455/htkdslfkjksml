# MathScore 14 — Final Class Dialog Fix

Fixed the Add Class / Edit Class dialog not disappearing after Save or Cancel.

Root cause:
The `.modal` CSS rule set `display:flex` after the generic `.hidden` rule, so the hidden class could not actually hide the modal.

Fixes:
- `.modal.hidden { display:none !important; }`
- Cancel explicitly hides the modal.
- Save explicitly hides the modal and returns to Home.
- Mobile-friendly one-field-per-row class form retained.
- Multiple classes, academic years, Edit Class, 14-week scores and Excel/CSV import retained.
