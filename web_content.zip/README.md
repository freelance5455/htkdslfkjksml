# TM Otimizações Beta v1.0

Plugin oficial do canal TM Otimizações (YouTube: @Tm.optimization) para
o AxManager. Foco em ajustes conservadores de desempenho para jogos,
sem necessidade de root — tudo via ADB/Shizuku.

## Recursos

**Desempenho e jogos**
- Animações do sistema ajustáveis (desativada / rápida / padrão / lenta)
- Ajustes conservadores para jogos (indicadores de toque e ponteiro desativados)
- Game Driver (ANGLE) — ativar/desativar
- Renderização gráfica — alternar entre OpenGL (SkiaGL) e Vulkan (SkiaVK)
- Taxa de atualização da tela — travar em 60/90/120 Hz ou automático
- Modo Foco de Jogo — silencia notificações durante a sessão (Zen Mode)

**Rede**
- Varredura Wi-Fi em segundo plano — ativar/desativar
- DNS Privado — desativado, automático ou Cloudflare (one.one.one.one)

**Manutenção e diagnóstico**
- Limpeza de cache sob demanda
- 34 overlays de depuração visual desativados (HWUI, SurfaceFlinger, EGL)
- Log leve — reduz verbosidade de 15 serviços do sistema para WARN, sem apagar nada
- Diagnóstico do aparelho (modelo, fabricante, Android, SDK, ABI, Game Mode)
- Diagnóstico avançado somente leitura (ZRAM, governor de CPU, zona térmica,
  taxa de atualização, renderer HWUI)
- Restauração completa (settings e propriedades) via backup automático

**Interface**
- WebUI completa com botões funcionais (não é só um painel informativo)
- Suporte a 4 idiomas: Português, English, Español, Français

## Segurança

O plugin não desativa proteções térmicas nem encerra aplicativos
aleatoriamente. Todas as mudanças usam apenas `settings put` e
propriedades `debug.*` / `log.tag.*`, que funcionam via ADB/Shizuku
sem necessidade de root.

## Estrutura

- `action.sh` — aplica o perfil de otimização e mostra diagnóstico
- `service.sh` — reaplica animações e overlays de depuração no boot
- `uninstall.sh` — restaura todas as configurações originais
- `functions/` — scripts individuais de cada ajuste
- `webroot/` — WebUI (painel de controle)
- `lib/common.sh` — funções de backup/restauração de settings e propriedades
