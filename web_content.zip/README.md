# Hallway

A mobile-first school community website designed to be packaged as an Android app later.

## Current build
- School code: 21511
- Mobile-first UI
- Home feed
- Create posts
- Student search
- Chat area
- Profiles/settings
- Report/block UI foundation
- PWA manifest
- Supabase-ready authentication and database schema
- Local preview mode when Supabase variables are not configured

## Make it a real multi-user site
1. Create a Supabase project.
2. Open SQL Editor and run `supabase/schema.sql`.
3. Copy `.env.example` to `.env`.
4. Put your Supabase URL and anonymous key in `.env`.
5. Run:
   npm install
   npm run dev
6. For production:
   npm run build

## Important
The school code is set to 21511 for the project. A real school deployment should also verify membership against an approved school roster; a shared code by itself is not sufficient for access control.

## Turn the website into an Android app
After the website is deployed, use a trusted web-to-app/PWA wrapper or Android WebView wrapper. The website is already mobile-first and includes a web app manifest.
