# Physics Formula Hub (Android-ready ZIP)

## Included
- Searchable high-school physics formula library (mechanics, waves, thermal physics, electricity, magnetism, optics, modern physics, mathematics/units).
- Formula explanations, SI units and usage notes.
- Add-your-own formula feature.
- Save/favourite formulas.
- Offline multiple-choice practice package with explanations and score review.
- Responsive interface designed for phone screens.
- PWA service worker for offline caching when first loaded from a supported local/web origin.

## Run / package as an APK
This ZIP is a web-app source project, not a compiled APK.
1. Extract the ZIP.
2. Open `index.html` in a browser for a quick preview. For reliable offline caching, serve the folder from localhost or HTTPS once.
3. To make an APK, import the folder into an Android WebView wrapper project or a trusted web-to-APK builder. Set `index.html` as the start page and enable JavaScript and local asset access.
4. Test the APK in airplane mode. Confirm formula search, custom formulas, favourites and offline quizzes work.
5. For Android WebView file access, no file picker is needed for the included features.

## AI online exam generator
The app includes an AI setup panel but intentionally does not ship with an AI API key or pretend that an online model is connected. To activate it:
- Build a server-side endpoint such as `/api/generate-physics-quiz`.
- Store your AI provider key on the server, never in the APK or JavaScript.
- Have the endpoint return a JSON array with question, options, correct answer index, explanation and topic.
- Add an online-only UI call to that endpoint. Keep the bundled `data/questions.json` package as the offline fallback.

## Data editing
- `data/formulas.json`: array entries `[topic, name, equation, explanation, unit, usage_note]`.
- `data/questions.json`: question objects with `q`, `options`, `a` (zero-based correct option index), `why`, and `topic`.

## Notes
- This is a broad high-school reference, not a replacement for your current textbook or teacher.
- Sign conventions can vary, especially in optics and thermodynamics. Follow the convention in your course.
- The formula list is a useful starter library and can be expanded.


## Expanded explanations
The app now has a **Learn more** panel on each built-in formula, including meaning, symbol guidance, SI unit, when to use it, worked example or worked method, and common cautions. The full reading guide is `PHYSICS_FORMULA_EXPLANATIONS.md`; detailed app data is in `data/formulas_detailed.json`. For some advanced relationships, a step-by-step substitution method is provided instead of a fixed numerical example.
