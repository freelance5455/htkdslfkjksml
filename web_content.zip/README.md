# Ganesh Enterprises Solar App

A mobile-first solar business app for Ganesh Enterprises, Raichur.

## Included
- Professional solar-themed home screen
- Tata Power Solar, Adani Solar and Avaada Solar product sections
- Tap-to-call button for 9019093871
- WhatsApp contact button
- Customer enquiry form that prepares a WhatsApp message
- Installable PWA manifest and basic offline cache

## Preview
Open `index.html` in a browser. For installation/offline features, serve the folder over HTTPS (or localhost); service workers do not run from ordinary `file://` URLs.

## Install on Android (without Play Store)
1. Upload the files to an HTTPS website/hosting service.
2. Open the site in Chrome on the Android phone.
3. Open Chrome's menu and choose **Install app** or **Add to Home screen** (wording may vary).

## To create a native Android APK
This ZIP contains the app's web source, not a signed APK. To make a native Android package, use Android Studio with a WebView wrapper or package this site with Capacitor, then build and sign the APK. An Android developer account or Play Store publishing is not included.

## Important notes
- Enquiry details are sent only after the customer reviews and sends the prepared WhatsApp message.
- This starter app does not include a database, admin dashboard, payment system, or live product pricing.
- Confirm product availability, official brand authorizations, warranty terms, and installation coverage before publishing claims.
