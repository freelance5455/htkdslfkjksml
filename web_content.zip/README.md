# Sf2 Bundle Editor — Android APK Project

- **App Name**: Sf2 Bundle Editor
- **Application ID / Package**: `com.illuminxs.sf2bundleeditor`
- **Export Output Directory**: `Android/media/com.illuminxs.sf2bundleeditor/` (resolved via `context.externalMediaDirs`, no special storage permissions needed on Android 10–15+)
- **Embedded HTML**: `app/src/main/assets/www/index.html`
- **Launcher Icon**: `app/src/main/res/mipmap-*` & adaptive icon `mipmap-anydpi-v26`

## Build the APK

### Option 1: Android Studio
1. Extract this ZIP archive.
2. Open the extracted folder in **Android Studio** (File -> Open).
3. Wait for Gradle sync to finish, then click **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
4. Find the compiled APK at `app/build/outputs/apk/debug/app-debug.apk`.

### Option 2: Command Line (Gradle 8.7 + JDK 17 + Android SDK 34)
```bash
gradle assembleDebug
```

### Option 3: GitHub Actions (No local Android Studio required)
1. Push the extracted folder to a GitHub repository.
2. Open the **Actions** tab and run **Build Sf2 Bundle Editor APK** (or let it trigger on push).
3. Download `Sf2-Bundle-Editor-debug-apk` from the workflow artifacts.
