# Product Inventory Android

مشروع Android Studio لتحويل النسخة التجريبية إلى تطبيق Android.

## البناء
افتح المجلد في Android Studio ثم Build > Build APK(s).

الحد الأدنى Android 6.0 (API 23)، والهدف API 35.

التطبيق يستخدم WebView لعرض واجهة المخزن، والبيانات محفوظة محلياً داخل التطبيق.
