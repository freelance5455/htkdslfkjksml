MIÉRCOLES — EDICIÓN WINDOWS 10 EN ADELANTE
===========================================

Compatibilidad prevista:
- Windows 10 (con Microsoft Edge o Google Chrome actualizado).
- Windows 11 y versiones posteriores de Windows.
- No depende de una versión concreta como 22H2, 23H2 o 26H2.
- También puede abrirse en otros sistemas con un navegador moderno.

Esta es una aplicación web instalable (PWA), no un .EXE nativo.

CÓMO INICIAR EN WINDOWS
1. Extrae el ZIP en una carpeta.
2. Instala Python 3 desde https://www.python.org/downloads/windows/ si no lo tienes.
3. Ejecuta INICIAR-WINDOWS.bat.
4. Se abrirá http://localhost:8765 en tu navegador.
5. En Microsoft Edge: menú (...) > Aplicaciones > Instalar este sitio como una aplicación.
   En Google Chrome: menú (...) > Guardar y compartir > Instalar página como aplicación
   (el texto exacto puede variar según la versión).

DISEÑO
Interfaz adaptable a ventanas pequeñas y grandes, optimizada para escritorio y ratón/teclado,
con los colores morado, azul y negro originales de Miércoles.

GROQ Y SEGURIDAD
La APK de origen contenía una clave API expuesta. Se retiró de este paquete para no
redistribuir una credencial comprometida. Genera una clave nueva y configúrala en los
ajustes de Miércoles si la versión de la aplicación admite conexión directa.
Una clave puesta en JavaScript o dentro de una aplicación de escritorio puede extraerse.
Para distribuirla a otras personas, utiliza un backend y guarda el secreto en el servidor.
Este paquete no incorpora un backend ni se ha validado una respuesta real de Groq.

PRIVACIDAD DE CHATS
Las conversaciones se guardan en el almacenamiento local del perfil del navegador.
No se sincronizan automáticamente entre equipos. En un PC compartido, cada persona debe
usar su propia cuenta de Windows o un perfil separado del navegador.
