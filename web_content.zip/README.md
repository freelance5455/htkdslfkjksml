# iPhone Launcher Pro — Android Launcher

A fully functional Android Home/Launcher application with iPhone 17 Pro Max-inspired design, Dynamic Island, App Library, Control Center, and real app discovery.

## Architecture

This is a real Android launcher configured through:
- `android/app/src/main/AndroidManifest.xml` — Declares `HOME`, `DEFAULT`, and `LAUNCHER` intent filters
- `capacitor.config.ts` — Capacitor configuration for native Android build
- `src/App.tsx` — Full launcher UI with pages, folders, search, settings, control center

## How to Build as Android APK

### 1. Build the web app
```bash
npm run build
```

### 2. Sync with Capacitor
```bash
npx cap sync android
```

### 3. Open Android Studio / Build APK
```bash
npx cap open android
# Then build APK or AAB through Android Studio
```

Or directly:
```bash
npx cap build android
```

## Key Features

- **Real Android Home Intent** — Appears in Android's default Home app picker and opens the real Home-app settings screen
- **Onboarding Flow** — Welcome, permissions, Set as Default Launcher, wallpaper, theme, Dynamic Island setup
- **Home Screen** — Multi-page grid, dock, folders, wallpapers, smooth swipe transitions
- **Dynamic Island** — Media playback, notifications, system events
- **App Library** — Categorized launcher apps, with native Android app discovery support
- **Control Center** — Wi-Fi, Bluetooth, Airplane, Brightness, Volume, Flashlight, Rotation, Battery, Music
- **Search** — Quick app search with swipe-down gesture
- **Settings** — Default launcher selection, layout, icons, dock, theme, animations, notifications
- **Native App Launching** — Tapping a launcher app opens its real Android package instead of showing a simulation alert
- **Persistent Setup** — Completed onboarding is remembered across launches

## Default Launcher Setup

After installing the APK:
1. Open the app
2. Tap **Set as Default Launcher** during onboarding
3. In Android system settings, select **iPhone Launcher Pro** as the default Home app
4. Press Home — the launcher will appear
5. Open any other app — press Home again to return to the launcher

## Permissions

Only legitimate Android permissions are declared:
- `INTERNET`, `ACCESS_NETWORK_STATE`
- `BLUETOOTH`, `ACCESS_WIFI_STATE`
- `QUERY_ALL_PACKAGES` (for real app discovery)
- `POST_NOTIFICATIONS` (for Dynamic Island notifications)
- `RECEIVE_BOOT_COMPLETED`

No private message reading, screen capture, or silent system changes.

## Security & Privacy

- Does not collect personal data
- Uses only official Android APIs
- Does not bypass Android security restrictions
- Does not silently change system settings
- All settings changes require user interaction
