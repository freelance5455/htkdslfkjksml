# William & Rani — mobile/PWA build

This is a mobile-first Progressive Web App foundation made from the original William & Rani HTML.

## Included

- Eight real animal photographs and eight real animal sound recordings.
- A new, bright real photograph of a mother duck with ducklings (CC0), replacing the previous image.
- A genuine mallard field recording labelled “Quack quack quack quack.” It is not synthesized, and the full 3.5-second call is allowed to play.
- Bubbles, xylophone, sparkles, touch-first layout, parent lock, app icons, and PWA setup.
- Offline media preparation: on first successful online launch of the hosted/installed PWA, the service worker downloads the photos and sound files into browser Cache Storage. The app displays **Offline ready** only after every animal has a cached photo and at least one cached sound format.

## Important note about the media bundle

After running `python tools/bundle_media.py`, the project physically contains all photographs and recorded sounds under `assets/media/`. The app then loads media locally rather than from external URLs, so media playback does not require internet.

The standalone `Toddler_Playland_Mobile.html` is for quick browser preview. For reliable offline use, host the project on HTTPS and install it as a PWA; service workers do not work from a `file://` HTML file.

## Create a physically bundled media build

On an internet-connected computer, run `python tools/bundle_media.py` from any directory. The script downloads and verifies every source asset first; only after all downloads succeed does it rewrite the HTML and service worker to use the local files. Re-zip or deploy the resulting project folder.

## Preview locally

From this directory run:

```bash
python -m http.server 8080
```

Then open `http://localhost:8080` in a browser. Service workers require `localhost` or HTTPS. Leave the page open while the top badge changes to **Offline ready** before testing airplane mode.

## Install on a phone

Deploy the folder to an HTTPS static host. Open it on the phone. On Android, use Chrome's **Install app** or **Add to Home screen**. On iPhone/iPad, open it in Safari and choose **Share → Add to Home Screen**. Open the installed app once while online and wait for **Offline ready**.

## Media licenses

Detailed source attribution and licensing information is in `credits.html`. Re-check those terms before a commercial release. This is an installable web app, not a signed native iOS/Android app-store package.
