# WA-OSINT PRO v7.0 (single file: WA-OSINT-PRO-v7.py)

## Pydroid 3
1. Pip menu: install `phonenumbers` (required). Optional: `dnspython`, `colorama`, `opencv-python` (QR image decoding).
2. Put WA-OSINT-PRO-v7.py anywhere writable, open it, tap Run. Data goes to `wa_osint_data/` next to the file.
3. Settings > 5 = dependency checker (can try pip installs). Settings > 9 = optional API keys.
## Termux
    pkg install python -y && pip install phonenumbers dnspython colorama && python WA-OSINT-PRO-v7.py

## Menus
1-13 unchanged from v4.1 (Phone, Business, Scam reports, Batch, Reports, WebGuard, IP incl. .me, Email, Device, Settings, Web Security Scanner, Secure Browser (safe text mode), Dashboard).
Menu labels: 1 = Phone Number Lookup, 7 = IP-WA-TRACE, 8 = Email Lookup (functions/reports unchanged). The main menu shows an educational-use notice; connectivity is still checked internally.
New: 14 Digital Footprint, 15 Threat Intelligence Center, 16 DNS Intelligence, 17 Evidence Vault, 18 Username Checker, 19 File Hash Analyzer, 20 QR Code Security, 21 Subdomain Intelligence, 22 Metadata Viewer, 23 HTML Report Center.

## What is sent to third parties (always HTTPS, always after you confirm)
- IP lookups: ipinfo.io, ipwho.is, ipapi.co, ipapi.is, ipquery.io (the IP). DNS: your resolver or dns.google. RDAP: rdap.org. Wayback: archive.org.
- Subdomains: crt.sh, Certspotter, HackerTarget, jldc.me (the domain). Username checks: the platforms themselves (your IP + username).
- Threat feeds (OpenPhish, URLhaus, Feodo, Spamhaus DROP, Tor list) are downloaded and matched on your device: the indicator is not sent.
- Optional keys (VirusTotal, abuse.ch Auth-Key) are user-entered, never hardcoded; only the URL/domain/IP or the file's SHA-256 is sent, never files.
- Evidence, metadata and HTML reports stay local.

## Limitations
- QR image decoding needs opencv-python (or pyzbar+zbar); otherwise paste the decoded text. Nothing is ever opened automatically.
- Username results: FOUND only for GitHub, Reddit, YouTube, Roblox (public APIs/pages). Instagram, TikTok, X, LinkedIn block bots, so they return UNKNOWN with a link to check by hand.
- IP geolocation is approximate; VPN/proxy flags are provider estimates. Reputation matches concern indicators, never people.
- Metadata: JPEG EXIF, PNG text/EXIF, Office/ODF and PDF Info only.
- True Android WebView is not possible from Pydroid/Termux scripts.

## Photo GPS Intelligence (inside menu 22)
Reads EXIF/GPS from your own local JPEG/PNG files: coordinates, Google Maps/OpenStreetMap links (text only), altitude, GPS date/time, direction, camera info; folder scan for photos that contain GPS; creates a metadata-free JPEG copy (original untouched). EXIF can be edited and proves nothing about who took a photo.
