# Fenix Pro

Protótipo de aplicativo de comunicação inspirado em plataformas modernas.

Inclui:
- login/criação de conta local
- servidores e códigos de convite (protótipo local)
- canais de texto
- mensagens persistentes no aparelho
- interface responsiva para celular
- canais de voz
- microfone e WebRTC/PeerJS
- controles de mute/desconectar

## Importante sobre o backend
Esta versão é um protótipo local. Contas, servidores e mensagens não são sincronizados entre aparelhos.
Para transformar em uma plataforma realmente multiusuário, é necessário um backend (API + banco + WebSocket/sinalização + autenticação segura).

Para testar chamadas, abra o app por HTTPS/localhost, permita o microfone e compartilhe o ID de Peer exibido com o outro usuário. A função de conexão pode ser ligada a um campo de convite de voz em uma próxima versão.
