# RED — Assistente pessoal (versão inicial)

Aplicativo inicial com interface escura/vermelha, personalidade do RED, histórico local, configuração do Google Gemini e shell offline instalável como PWA.

## O que funciona nesta versão
- Interface adaptada a celular.
- Histórico local no navegador/aplicativo.
- Configuração manual do Google Gemini.
- Chat online via API do Google Gemini quando uma chave válida estiver configurada.
- Respostas locais simples quando o modo offline é selecionado.
- Cache básico da interface para reabrir sem internet.
- Preparação de empacotamento Android com Capacitor.

## Limitações importantes
- O modo offline **ainda não inclui um modelo generativo local**. As respostas offline são regras simples, não uma IA completa.
- A chave da API é guardada no armazenamento local do aparelho e enviada ao Google quando você usa o modo online. Isso é apenas para teste pessoal; não publique nem distribua o app com sua chave salva.
- O uso gratuito, os modelos disponíveis e os limites da API dependem das condições atuais do Google.
- A interface web não pode controlar livremente outros aplicativos ou todas as funções do Android.
- O PWA/service worker precisa ser servido por HTTPS ou localhost para funcionar plenamente; abrir o HTML diretamente como arquivo pode limitar o cache offline.

## Testar no computador
1. Instale Node.js LTS.
2. Extraia o ZIP.
3. Abra um terminal nesta pasta.
4. Execute `npm install`.
5. Execute `npm run start`.
6. Abra o endereço local informado no terminal.

## Gerar projeto Android
É necessário um computador com Node.js, Android Studio e Android SDK.
1. Execute `npm install`.
2. Execute `npm run android:add` uma vez.
3. Execute `npm run android:sync`.
4. Execute `npm run android:open` para abrir no Android Studio.
5. No Android Studio, teste no emulador ou conecte o telefone com depuração USB habilitada e compile o app.

Se `android/` já existir, não execute `android:add` novamente; use `npm run android:sync`.

## Configurar o Google Gemini
1. Consulte o Google AI Studio oficial e verifique disponibilidade, termos e limites atuais.
2. Crie uma chave para uso pessoal.
3. No RED, toque em “Configurar Google IA”, cole a chave e salve.
4. Selecione “Google online” ou “Automático”.

Nunca compartilhe a chave em capturas de tela, código público ou APK distribuído. Para um produto público, coloque a chamada de API atrás de um backend seguro, em vez de embutir uma chave no cliente.

## Próximas etapas para um RED offline de verdade
Integrar um runtime compatível com Android (por exemplo, uma implementação baseada em llama.cpp ou MLC LLM) e um modelo pequeno que caiba na memória e no armazenamento do aparelho. Isso exige escolher um modelo compatível, verificar licença, testar desempenho e implementar integração nativa. Não foi simulado nesta versão.
