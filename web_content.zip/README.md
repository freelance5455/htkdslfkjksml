# DakFlow AI — Android APK Builder

This project wraps the supplied DakFlow AI / barcode scanner HTML prototype in an Android app using Capacitor and builds a debug APK with GitHub Actions.

## Build the APK without a computer build setup

1. Extract this ZIP.
2. Create a new repository at https://github.com/new (name it `dakflow-ai-apk`).
3. Upload the **contents** of this folder to the repository (make sure `.github/workflows/build-apk.yml` is included).
4. Open the repository's **Actions** tab. If prompted, enable Actions.
5. Select **Build DakFlow AI APK** → **Run workflow** (or push/commit the uploaded files).
6. When the run finishes successfully, open the run and download the artifact named **DakFlow-AI-APK**.
7. Extract the downloaded artifact ZIP; it contains `app-debug.apk`. Transfer it to Android and install it. Android may ask you to allow installation from that source.

## Important limitations

- This APK packages the supplied HTML design as a WebView app. The supplied screen's camera/torch buttons are visual prototype interactions; they do not implement real barcode decoding, AI extraction, or Excel writing. Those features need to be implemented and tested separately before relying on the app operationally.
- Camera permission is declared in AndroidManifest, but declaring permission alone does not implement scanning. Real scanning should use a tested scanner library/plugin and runtime permission handling.
- This is a **debug APK**, not a Play Store release build. It is not signed with a personal release key.
- The HTML references external CDN fonts and Tailwind, so some styling resources need an internet connection.

## App details

- App name: DakFlow AI
- Application ID: `in.gov.dakflow.app`
