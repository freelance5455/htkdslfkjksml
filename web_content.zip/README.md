# Scrap अड्डा — HTML Converter Package

## Upload target
Use **index.html** as the main HTML file for an HTML→APK converter.

## Included
- index.html — latest Scrap अड्डा UI
- dummy_dataset.json — demo materials, prices, recyclers, lots, offers, transactions and notifications
- README.md — this file
- CONVERTER_NOTES.md — packaging/permissions notes
- assets/ — placeholder for optional app logo/assets

## Important
The in-app top clock/time display was removed because Android already shows the device time in the system status bar.

The HTML still contains the Scrap अड्डा app UI, camera/gallery flow, nearby buyer/pooling navigation fixes, persistent 3D map modal, and voice-once behavior.

For APK conversion, enable:
- Camera permission
- Location permission
- Microphone only if the selected converter requires it for camera/media APIs

Use the HTML file as the app entry point. If the converter requires a ZIP, upload this complete package.
