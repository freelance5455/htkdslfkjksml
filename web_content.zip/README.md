# Meridian World Clock

A minimal Android world-clock app with live local time, world cities, time-zone offsets, date/day indicators, and searchable add/remove city selection. It uses the device's clock and time-zone database; no network permission is needed.

## Build an APK
1. Open this folder as a project in Android Studio.
2. Allow Gradle sync to finish (Android SDK 35 and Android Gradle Plugin 8.7.3 are specified).
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be under `app/build/outputs/apk/debug/app-debug.apk`.

This source package does not include a precompiled APK. It must be built with Android's SDK/Gradle toolchain.
