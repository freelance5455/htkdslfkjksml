# DK GYM — Offline Ultra Luxury Edition

This build is **offline-first** and stores demo data in the browser with `localStorage`.

### Working without an API
- Member add/search/profile
- Payment ledger and pending dues
- Local payment collection simulation
- Attendance records
- Dashboard calculations
- Inventory demo
- Trainer/workout/report screens
- Role/setting UI
- DK AI rule-based assistant
- WhatsApp reminder via the user's WhatsApp web/app link (requires internet and user action)

### Important limitation
A **real payment gateway** cannot be created purely offline: a bank/UPI/payment provider must authorize transactions.
Real SMS delivery also requires an SMS provider/network service.
A real cloud multi-device database and real account authentication require a server or managed backend.
The QR screen uses the browser's native BarcodeDetector when supported; otherwise manual Member ID check-in is provided.

### Run
Extract the ZIP and open `index.html`.
No build step is required.
