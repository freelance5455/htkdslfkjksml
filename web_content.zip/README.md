# Manutenção Átala — gerar o APK

## O que instalar (uma vez)
1. Node.js 18 ou mais novo (nodejs.org)
2. Android Studio (developer.android.com/studio) — ele traz o JDK 17 e o SDK do Android

## Passo a passo
Abra o terminal dentro desta pasta e rode:

    npm install
    npm run setup
    npm run open

O último comando abre o Android Studio. Espere terminar o "Gradle sync" e vá em:
**Build > Build Bundle(s) / APK(s) > Build APK(s)**.
O arquivo sai em `android/app/build/outputs/apk/debug/app-debug.apk`. Mande para o celular e instale (permita "instalar apps desconhecidos").

Se mudar algo na pasta `www`, rode `npm run sync` e gere o APK de novo.

## Como o app funciona
- Os dados ficam **dentro de cada celular** (não são compartilhados entre aparelhos).
- **Backup:** gera um arquivo e abre o menu de compartilhar (e-mail, WhatsApp...). O envio é manual.
- **Restaurar backup:** na tela Backup, escolha o arquivo .json. Serve também para trazer os dados da versão do site (as fotos antigas não vêm).
- **Escanear QR:** botão na tela inicial; lê as etiquetas e abre a máquina. A câmera do celular, fora do app, não abre o app.
- **Imprimir:** o app gera um arquivo "imprimir.html" e abre o compartilhar; abra no Chrome e imprima de lá.
