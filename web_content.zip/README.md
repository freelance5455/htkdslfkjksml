# Familienzeit – kostenlose Firebase-Variante

Eine Familien-App für Android mit einer browserbasierten `index.html`. Die App enthält Familien- und Einzelchats, gemeinsame oder private Termine und Aufgaben sowie eine Galerie für Bildlinks. Sie nutzt Firebase Authentication mit E-Mail und Passwort sowie Cloud Firestore.

## Was enthalten ist

- Dunkles, einfaches Design mit Übersicht und Navigation
- Familienchat und Einzelchats
- Kalendertermine und Aufgaben, jeweils gemeinsam oder privat
- Familiengalerie zum Teilen von HTTPS-Bildlinks
- Anmeldung per E-Mail und Passwort sowie Beitritt über einen zufällig erzeugten 16-stelligen Familiencode
- Firestore-Sicherheitsregeln und benötigte Abfrageindizes

## Kosten und Grenzen

Das Projekt ist auf Firebase Spark ausgelegt: keine Cloud Functions und kein Firebase Storage. Es verlangt keine Zahlungsdaten und aktiviert keine Abrechnung. Die Galerie speichert Links zu Bildern, keine hochgeladenen Bilddateien. Profilbild-Uploads und die frühere PIN-Anmeldung sind in dieser kostenlosen Fassung nicht enthalten.

Firestore hat im Spark-Tarif kostenlose Nutzungskontingente. Wenn ein Kontingent erreicht wird, kann der betreffende Firebase-Dienst bis zur Erneuerung des Kontingents pausieren. Die kostenlose Nutzung ist deshalb nicht unbegrenzt, führt aber nicht automatisch zu einer Rechnung. Siehe die aktuellen Bedingungen im Firebase-Preisplan.

## Einrichten

Du brauchst einmalig einen Computer mit Android Studio und Firebase CLI. Das ZIP ist Quellcode, noch keine installierbare APK.

1. Erstelle in der Firebase Console ein Projekt und belasse es im kostenlosen Spark-Tarif. Verknüpfe kein Abrechnungskonto.
2. Aktiviere unter **Authentication → Sign-in method** den Anbieter **E-Mail/Passwort**.
3. Erstelle unter **Firestore Database** eine Datenbank.
4. Registriere die Android-App mit der Paket-ID `de.familienzeit.app`, lade `google-services.json` herunter und lege sie unter `app/` ab.
5. Installiere die Firebase CLI, melde dich an und wähle dein Projekt:

   ```sh
   firebase login
   firebase use --add
   ```

6. Stelle nur Firestore-Regeln und Indizes bereit:

   ```sh
   firebase deploy --only firestore:rules,firestore:indexes
   ```

7. Öffne `familienzeit-android` in Android Studio, synchronisiere Gradle und erstelle die APK über **Build → Build APK(s)**.

Für die Browserfassung registrierst du zusätzlich in Firebase eine Web-App. Trage deren `apiKey`, `authDomain`, `projectId`, `messagingSenderId` und `appId` in `index.html` im Objekt `firebaseConfig` ein. Ein `storageBucket` wird nicht benötigt.

## Familiencode und Konten

Die erste Person erstellt die Familie und erhält in ihrem Profil einen zufälligen Familiencode. Sie teilt diesen Code privat mit Angehörigen. Jedes Mitglied tritt mit dem Code bei und verwendet ein eigenes E-Mail-Konto. Der Code ist der Zugang zur Familie; behandle ihn daher wie ein gemeinsames Geheimnis.

## Projektdateien

- `index.html` – Browserfassung und Einstieg für HTML-zu-APK-Konverter
- `app/` – native Android-App in Kotlin und Jetpack Compose
- `firestore.rules` und `firestore.indexes.json` – Datenzugriff und Abfrageindizes
- `firebase.json` – Firestore-only Deployment-Konfiguration

Der Quellcode wurde in dieser Umgebung nicht gegen ein Android SDK gebaut. Für die APK-Erstellung ist Android Studio mit Android SDK 35 und JDK 17 erforderlich.
