# ConnectMe — Android-friendly messaging starter

This is a runnable React progressive web app with Supabase email/password sign-up and login, profile creation, phone-number lookup RPC, direct chats, live message subscriptions, text status posts (24-hour expiry), basic group creation, and in-chat voice-note recording/upload.

**Important:** this is a functional starter/MVP, not a finished WhatsApp replacement. Calls, push notifications, media picker/camera, message editing/reactions/read receipts, group invitations/admin workflows, status privacy/viewers, and end-to-end encryption are not implemented. The UI does not pretend those features are live. Do not publish as a production messenger until the security checklist below is completed.

## 1. Create the free backend
1. Create a project at https://supabase.com (free tier availability/limits can change).
2. In Project Settings → API, copy the Project URL and anon/public key.
3. Copy `.env.example` to `.env` and fill in `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
4. In Supabase SQL Editor, run all of `supabase/schema.sql`.
5. In Authentication → Providers, enable Email. For development, you can disable email confirmation in Auth settings. This avoids SMS verification costs. Use test accounts only.
6. In Authentication → URL Configuration, add your local development URL (for example `http://localhost:5173`).

## 2. Run
Install Node.js 20+ then:
```bash
npm install
npm run dev
```
Open the local URL shown by Vite. For a production web build:
```bash
npm run build
```
The output is in `dist/`.

## 3. Android testing
This project is responsive and can be installed as a PWA from a compatible Android browser once hosted over HTTPS. For a native APK, wrap the built web app with Capacitor:
```bash
npm install @capacitor/core @capacitor/cli
npx cap init ConnectMe com.connectme.app --web-dir=dist
npm install @capacitor/android
npx cap add android
npm run build
npx cap sync android
npx cap open android
```
Build an APK in Android Studio. Native camera, gallery, and notification permissions still need native integration.

## 4. What is genuinely connected
- Email/password sign-up and login via Supabase Auth.
- Profile row creation.
- Direct conversation creation through a protected database RPC.
- Text messages stored in Postgres and received live through Supabase Realtime.
- Text status posts stored with a 24-hour expiry.
- Browser microphone recording and audio upload to the private `chat-media` bucket (voice-note playback uses the saved media URL flow; configure signed URLs before production).
- Basic group shell and group creation (membership/invitation administration is not complete).

## 5. Costs and limits
No subscription or payment is built into ConnectMe. Supabase offers a free tier with quotas and possible project pausing/limits; check its current pricing before launch. Email delivery, hosting, TURN relay bandwidth for WebRTC, and higher storage/egress may incur costs. No SMS provider is required for this development sign-up flow.

## 6. Production security work required
- The supplied SQL is a development baseline. Have the RLS policies reviewed before public launch; do not expose phone numbers in a public directory. Add contact-consent and per-user privacy controls.
- Replace the simple public media URL usage with authenticated signed URLs and full membership-based storage policies.
- Add rate limits, abuse reporting, blocking, account deletion cleanup, audit logs, and data retention controls.
- Add message delivery/read state, typing presence, push notifications, and end-to-end encryption (not currently included).
- Configure WebRTC signaling plus STUN/TURN. STUN may be free; reliable TURN relay often has bandwidth costs. No calling service is falsely claimed as working.
- Configure email templates and production redirect URLs.
