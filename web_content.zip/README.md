# LIND-US Navigation V2.1

## V2.1 újdonságok
- Új, sötét-lilás/lilakék prémium arculat a telefonos webes felületen és a natív térképi útvonalon.
- Javítva egy hibás Kotlin import sor, amely a korábbi forrásban megakadályozta volna a fordítást.
- Android projekt verzió: 2.1 (versionCode 21).
- GitHub Actions munkafolyamat került a projektbe: `Build Android APK`. `main` push vagy kézi indítás esetén megpróbálja lefordítani a debug APK-t, majd 14 napig letölthető build-artifactként közzéteszi.

## APK készítése telefonról
1. Töltsd le és csomagold ki a ZIP-et.
2. Hozz létre egy GitHub repositoryt, majd töltsd fel a projekt teljes tartalmát.
3. A GitHub repositoryban nyisd meg az **Actions** fület.
4. Válaszd a **Build Android APK** workflow-t, majd a **Run workflow** lehetőséget.
5. Sikeres build után az adott futás alján az **Artifacts** részből tölthető le a `LIND-US-Navigation-debug-apk`.

A workflow felhőben fut, nem a telefonodon. GitHub-fiók és a projekt repositoryba feltöltése szükséges. A debug APK tesztelésre való, nem Play Áruházba publikálható kiadás.

## Fontos korlátok
- Ebben a környezetben nincs Android SDK/Gradle build, ezért az APK-t itt nem fordítottam le, és a workflow sikerességét sem tudtam futtatással ellenőrizni.
- Az Android Auto integrációt még nem teszteltük valódi autóban vagy Desktop Head Unitban.
- A magyar hangutasítás a telefon TTS-motorjától és telepített magyar hangadatától függ.
- A sebességhatár OSM-alapú, hiányos vagy pontatlan lehet; mindig a közúti jelzések az irányadók.
- A projekt jelenleg fejlesztői prototípus.
