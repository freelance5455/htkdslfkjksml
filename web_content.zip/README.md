# Olymp Trade OTC 1-Min Signal App

This is a signal-engine UI prototype for Olymp Trade OTC assets.

Important:
Olymp Trade states that OTC quotes are determined using OTC data sources. The app intentionally does NOT substitute Binance or another exchange feed for Olymp Trade OTC. An official/authorized real-time OTC feed is required before enabling live OTC signals.

Indicators:
RSI(14), EMA(9/21), MACD(12/26/9).

No automatic trade execution is included.
