# Galaxy Shooter: Tank Wars

A starter React + Vite + TypeScript arcade game based on the game data you shared.

## Run on a computer
1. Install Node.js (LTS).
2. Extract this ZIP.
3. Open a terminal in this folder.
4. Run `npm install`
5. Run `npm run dev`
6. Open the local URL shown by Vite.

## Create an Android project (after testing)
This project is a web app, not an APK yet. To package it with Capacitor:

```bash
npm install @capacitor/core @capacitor/cli
npx cap init "Galaxy Shooter: Tank Wars" "com.galaxyshooter.tankwars" --web-dir=dist
npm install @capacitor/android
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

In Android Studio, build the APK using **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Notes
- This is a newly assembled starter game based on the partial code and feature list supplied in chat.
- Profile progress is stored locally in the browser/WebView.
- The leaderboard is a local demo; real online accounts and rankings need a backend.
- Google/Facebook sign-in, multiplayer arena, server rewards, and cloud saves are not connected.
