# Tontine Solidaire BF — projet Android hors connexion

Ce dossier contient le **projet source Android Studio** qui embarque la version HTML améliorée de Tontine Solidaire BF dans une WebView locale. L'application ne demande pas la permission Internet et ses ressources visuelles (Tailwind compilé et Font Awesome) sont incluses dans `app/src/main/assets`.

## Fonctions prises en charge par l'enveloppe Android

- Démarrage de l'interface locale depuis les ressources de l'application.
- Stockage local WebView (`localStorage`) pour les groupes, membres, signatures et paiements.
- Sélecteur de fichiers Android pour importer une sauvegarde, choisir une image ou un PDF.
- Proposition d'ouvrir l'appareil photo pour les champs d'image.
- Export de sauvegarde JSON par la boîte de dialogue Android « Enregistrer sous ».
- Ouverture des liens externes (par exemple téléphone ou WhatsApp) dans l'application Android correspondante.

## Générer l'APK

1. Installer Android Studio sur un ordinateur et ouvrir le dossier `tontine_android`.
2. Laisser Gradle synchroniser le projet. La première compilation a besoin d'Internet pour récupérer les dépendances et Android SDK requis.
3. Installer Android SDK Platform 35 si Android Studio le demande.
4. Choisir **Build > Build APK(s)**.
5. L'APK de débogage sera normalement produit dans `app/build/outputs/apk/debug/app-debug.apk`.
6. Transférer l'APK sur le téléphone Android et l'installer. Android peut demander d'autoriser l'installation depuis cette source.

## Limites importantes

- Ce livrable est le **projet source**, pas un APK déjà compilé. Aucun Android SDK ni outil de compilation Gradle n'est installé dans l'environnement qui a préparé ces fichiers ; il n'était donc pas possible de compiler et tester un APK ici.
- Le code HTML garde la vérification de licence RSA existante. Le générateur administrateur et la clé privée RSA ne sont pas inclus : ils doivent rester séparés et protégés.
- La durée des licences (3 jours, 6 mois, 1 an, 5 ans) doit être définie par le générateur qui signe les licences. L'application vérifie la signature et les champs de la licence existante ; cette enveloppe Android ne fabrique pas de clés.
- Les données sont stockées localement sur un seul téléphone. Désinstaller l'application ou effacer ses données peut les supprimer ; exportez régulièrement une sauvegarde et gardez-la dans un endroit sûr.
- Les données de membre, signatures, photos et CNIB sont sensibles. Ce prototype n'ajoute pas encore de chiffrement applicatif des données locales.
- Le Mobile Money n'est pas débité par cette application hors ligne : le choix d'un mode de paiement enregistre la transaction dans le registre local. Un vrai débit exige le réseau et un prestataire de paiement.
- Le code doit être testé sur le téléphone cible, notamment l'appareil photo, l'import/export, l'impression et la validation RSA, avant un usage réel avec des fonds ou des pièces d'identité.

## Alternative : compilation dans GitHub Actions

Le projet inclut aussi `.github/workflows/android-build.yml`. Après avoir placé ce dossier dans un dépôt GitHub, la compilation peut être lancée depuis l'onglet **Actions** avec **Build Tontine Solidaire BF APK** puis **Run workflow**. Une fois le travail terminé, télécharger l'artefact `Tontine-Solidaire-BF-debug-apk`. Cette méthode compile un APK de débogage ; une distribution publique nécessite une signature de publication gérée séparément.
