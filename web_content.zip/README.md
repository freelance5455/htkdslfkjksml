========================================================================
NEXA Student Safety Network — Paquete Completo para Conversión a APK
========================================================================

Este archivo ZIP contiene la aplicación NEXA completamente compilada,
optimizada y lista con su "index.html" en la raíz para ser convertida a APK.

ESTRUCTURA DEL ARCHIVO ZIP:
- index.html              -> Archivo principal compilado con rutas relativas
- assets/                 -> Códigos JavaScript y estilos CSS compilados
- manifest.json           -> Configuración de la aplicación móvil PWA
- manifest.webmanifest    -> Manifiesto web estándar
- sw.js                   -> Service Worker para funcionamiento Offline
- pwa-192x192.png         -> Icono de la aplicación en alta resolución
- pwa-512x512.png         -> Icono para la pantalla de inicio y splash screen
- pwa-maskable-512x512.png-> Icono adaptable para Android (círculo/cuadrado)
- apple-touch-icon.png    -> Icono para dispositivos iOS
- icon.svg                -> Icono vectorial oficial
- config.xml              -> Archivo de configuración para empaquetadores Android
- source_code/            -> Copia completa del código fuente original TypeScript/React

------------------------------------------------------------------------
CÓMO CONVERTIR ESTE ZIP EN UN ARCHIVO APK PARA ANDROID:
------------------------------------------------------------------------

MÉTODO 1: Convertidores Web / ZIP a APK (El más rápido sin programar)
1. Ingresa a una plataforma externa de conversión como:
   - Website 2 APK Builder (https://websitetoapk.com)
   - AppsGeyser (https://appsgeyser.com)
   - WebviewGold / GoNative
2. Selecciona la opción "Local HTML / ZIP Website".
3. Sube este archivo ZIP tal como está. El convertidor detectará automáticamente el archivo "index.html" en la raíz.
4. Asigna el nombre: "NEXA Safety" y selecciona el icono "pwa-512x512.png".
5. Haz clic en "Build APK" / "Generar APK". ¡Listo!

MÉTODO 2: PWABuilder (Herramienta oficial de Microsoft)
1. Ingresa a https://www.pwabuilder.com
2. Introduce la URL de tu aplicación en línea.
3. PWABuilder validará automáticamente el manifest.json y sw.js incluidos.
4. Presiona "Package for Android" para descargar tu APK firmado.

MÉTODO 3: Con Capacitor / Android Studio (Nativo)
1. Descomprime la carpeta "source_code/".
2. Ejecuta:
   npm install
   npm run build
   npx cap init "NEXA Safety" com.nexa.studentsafety --web-dir dist
   npx cap add android
   npx cap open android
3. En Android Studio presiona: Build > Build APK.

========================================================================
NEXA Student Safety Network · 2026
========================================================================
