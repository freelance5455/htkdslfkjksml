# Dinpel Fishing Game — source project

A React + TypeScript + Vite starter project for the Dinpel Fishing Game.

## Included
- Arcade fishing loop: cast, wait for a bite, reel in, and earn coins.
- 60 fish species with rarity tiers, coin values, habitats, and custom SVG fish artwork.
- 20 rod upgrades with prices and power progression.
- Three fishing locations with unlock requirements.
- Fish journal with search and rarity filter.
- Progress saved in browser `localStorage`.
- Responsive layout for desktop and mobile.

## Run locally
You need Node.js (18 or newer recommended).

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

## Build
```bash
npm run build
npm run preview
```

## Notes
- This is a portable source project for continuing development. It is not an export of AppDeploy's deployment internals.
- The project uses inline SVG illustrations, so no separate image assets are required.
- Google Fonts are loaded remotely; the app uses fallback fonts if unavailable.
