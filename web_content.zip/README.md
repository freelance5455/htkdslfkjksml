# Stock dan Produksi by Akhtara.ID — APK standalone

Proyek Android (WebView) siap build. Aplikasi memuat `app/src/main/assets/index.html`
langsung dari dalam APK: tanpa hosting, tanpa browser, tanpa dependensi library.

## Cara build

**A. Android Studio (paling mudah)**
1. Ekstrak ZIP → `File > Open` → pilih folder proyek, tunggu Gradle sync.
2. `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
3. APK ada di `app/build/outputs/apk/debug/app-debug.apk`.

**B. GitHub Actions (tanpa PC)**
Unggah isi folder ke repo GitHub → tab *Actions* → *Build APK* → *Run workflow* →
unduh artifact `StokProduksi-APK` (berisi APK debug dan release; keduanya langsung bisa dipasang).

**C. Command line**
`gradle assembleDebug` (butuh JDK 17 + Android SDK, Gradle 8.7).
Jika ingin memakai `./gradlew`, jalankan sekali: `gradle wrapper --gradle-version 8.7`.

## Yang ditambahkan ke aplikasi Anda

| Permintaan | Hasil |
|---|---|
| Layar pembuka cukup sekali | Splash bawaan Android 12+ dibuat polos (tanpa ikon), jadi hanya splash animasi di dalam aplikasi yang tampil: logo pop + bar tipis, ±0,7 dtk, keluar dengan efek iris. |
| Transisi slide antar tab | Ketuk tab di navigasi bawah → halaman lama bergeser keluar, halaman baru masuk dari kiri/kanan sesuai arah tab (300 ms). |
| Tanpa pop up salin/tempel | Tekan lama dimatikan di level native (WebView) dan di CSS/JS. |
| Statusbar dipaksa ikut tema | Statusbar dan navigation bar **digambar oleh aplikasi sendiri** (bukan diserahkan ke sistem), jadi selalu sama dengan warna header/latar tema, juga di Android 15+. Warna ikon (terang/gelap) menyesuaikan otomatis. |
| Color wheel di pengaturan tema | Atur › Tema tampilan: roda warna + slider kecerahan + kode HEX + mode Gelap/Terang. Satu warna dibuat menjadi seluruh palet tema, tampilan dan statusbar berubah langsung. Tema siap pakai yang lama tetap ada. |
| Warna bahan | Pemilih warna bahan (kemeja/celana) juga memakai color wheel yang sama. |

Semua fitur lain (tracking, produksi, stok, upah, pencarian, backup, riwayat, font, dll.) tidak diubah.

## Penyimpanan data
Data disimpan di WebView dan **diduplikasi ke file** `data.json` di penyimpanan internal aplikasi
(fungsi `Android.saveData / loadData` yang sudah ada di kode Anda). Backup/pulihkan file `.json`
memakai pemilih file Android.

## Catatan
- `INTERNET` hanya agar pilihan *Google Font* bisa diunduh. Hapus baris itu di `AndroidManifest.xml` jika ingin 100% offline.
- Splash bawaan Android 12+ berwarna tetap (`res/values/colors.xml › splash_bg`, default = header tema Sequoia). Ubah nilainya bila tema favorit Anda berbeda.
- Pemilih teks dimatikan, jadi menempel teks dengan tekan-lama tidak tersedia; gunakan *Pulihkan dari file* untuk restore backup.
- Ikon aplikasi dibuat dari logo di HTML Anda (`res/mipmap-*`).

## Aturan transisi visual (v10)

- Pindah tab: fade-through + geser 110 ms keluar, 260 ms masuk. Tanpa clone DOM, hanya transform dan opacity.
- Bottom sheet, color wheel, dan pencarian: animasi buka dan tutup, tidak mengulang saat isi di-render ulang.
- Akordeon Atur: buka dan tutup dengan tinggi halus, chevron ikut berputar.
- Nav bawah: bubble ikon bergeser halus, ikon aktif "pop".
- Sentuhan: tombol dan kartu mengecil sedikit saat ditekan.
- Mengikuti pengaturan "kurangi animasi" di HP (prefers-reduced-motion).
