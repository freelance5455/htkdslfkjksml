# AERORE phone-first Android + web starter (v0.2)

This version adds Supabase-powered email/password authentication, Google OAuth hook, and realtime public `#general` messages. Phone emojis work as normal Unicode text through the device keyboard.

## 1. Create the backend
1. Create a Supabase project.
2. Open SQL Editor and run `supabase_schema.sql` from this folder.
3. In Authentication > Providers, enable Email. Enable Google and configure its OAuth client in Google Cloud if you want Continue with Google.
4. In Project Settings > API, copy Project URL and the publishable/anon key.

## 2. Configure web app
In `web`, copy `.env.example` to `.env` and replace values:
```
VITE_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_PUBLIC_ANON_OR_PUBLISHABLE_KEY
```
Never put a Supabase `service_role` key in the app or GitHub.

## 3. Build APK using GitHub Actions from a phone
1. Extract this ZIP on your phone.
2. Create a private GitHub repository and upload the extracted project contents (not the ZIP itself).
3. In the repository, open Actions. The workflow `.github/workflows/android-apk.yml` builds a debug APK in GitHub's cloud.
4. Open the completed workflow run > Artifacts > download `AERORE-debug-apk`.
5. Extract the artifact ZIP and install the APK on your Android phone. Android may ask you to allow installs from your browser/files app.

The GitHub workflow needs no signing key for a debug APK. A public Play Store release needs a signed release build and Play Console setup.

## 4. Run website locally (optional)
Requires Node.js 20+:
```
cd web
npm install
npm run dev
```

## What's implemented / not yet
- Implemented starter: email/password signup/login, Google OAuth call (after provider setup), realtime `#general` chat, standard Unicode emoji entry, responsive light/dark interface, APK cloud-build workflow.
- Not yet implemented: friend requests, private DMs, server creation/roles/invites, custom emoji upload, 10 MB file storage, Plus billing/boosts, voice/video calls, moderation and production admin console.
- Plus buttons are placeholders; do not collect payments until billing, refund handling and age/guardian requirements are properly set up.
- Use only public/publishable Supabase client keys in the app. Configure database backups and test restore. Do not promise zero data loss.
