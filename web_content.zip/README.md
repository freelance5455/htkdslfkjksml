# UrduSubs — Offline Urdu Subtitle Studio (Web)

Mobile-first web app that plays **local video files** and generates **Urdu subtitles** from the
spoken audio, **entirely on-device** after a one-time model download.

```
video file → mono 16 kHz audio → Whisper (30 s windows, word timestamps)
          → readable segments → M2M100 / NLLB-200 (→ urd_Arab)
          → synced Urdu SRT/VTT → library + RTL player overlay
```

No cloud API is ever called. The only network traffic is the one-time download of model files
from official sources (huggingface.co / official npm CDN). The **Tests** tab proves offline
inference with a live network-request spy.

## Run it

```bash
npm install
npm run dev        # development
npm run build      # production single-file build (dist/index.html)
```

## First-time setup (online)

1. **Models** tab → install a **Whisper** speech model:
   - `Xenova/whisper-tiny` — int8 ≈ 68 MB — fastest, 2 GB+ RAM
   - `Xenova/whisper-base` — int8 ≈ 135 MB — **recommended**
   - `Xenova/whisper-small` — int8 ≈ 280 MB — 4 GB+ RAM
2. **Models** tab → install the **Urdu translation model**:
   - `Xenova/m2m100_418M` — int8 ≈ 940 MB, MIT, 41 languages → Urdu — smallest real option
   - `Xenova/nllb-200-distilled-600M` — int8 ≈ 1 GB, **CC-BY-NC (non-commercial)**, higher quality
3. Optionally install the **FFmpeg media engine** (≈ 33 MB) for MKV/MOV/Opus files.
   MP4/MP3/WAV/OGG/FLAC usually work without it (browser-native decoder is tried first).
4. **Player** → choose a local video → **Generate** → pick the spoken language → start.

Afterwards everything is offline: models persist in **Cache Storage**, subtitle sets and
(optionally) stored video files persist in **IndexedDB**.

## Verified models (checked on huggingface.co via API at build time)

| Model | Role | Source | Download (int8) | License | RAM guide |
|---|---|---|---|---|---|
| Whisper Tiny | ASR | Xenova/whisper-tiny | ≈ 68 MB | CC-BY-4.0 | 2 GB+ |
| Whisper Base | ASR | Xenova/whisper-base | ≈ 135 MB | CC-BY-4.0 | 3 GB+ |
| Whisper Small | ASR | Xenova/whisper-small | ≈ 280 MB | CC-BY-4.0 | 4 GB+ |
| M2M100 418M | MT → Urdu | Xenova/m2m100_418M | ≈ 940 MB | MIT | 6 GB+ |
| NLLB-200 Distilled 600M | MT → Urdu | Xenova/nllb-200-distilled-600M | ≈ 1 GB | CC-BY-NC-4.0 | 8 GB+ |
| FFmpeg core 0.12.6 | audio fallback | unpkg @ffmpeg/core (official npm) | ≈ 33 MB | LGPL | 2 GB+ |

Runtime: `@huggingface/transformers` v3 (ONNX Runtime Web, bundled). Whisper **transcribes**
multilingual speech — it does not translate; Urdu script always comes from the MT model.

**Honest note:** no small ONNX English→Urdu model exists on the Hub yet (verified by searching).
M2M100 int8 is the smallest real in-browser option; the app warns when a model likely exceeds
device RAM/storage and recovers cleanly on failure.

## Testing offline (acceptance checklist)

Run the **Tests** tab for the technical half (real checks, no simulation):

- WASM runtime, Cache API, storage quota, audio decode + 16 kHz resample
- FFmpeg core cached/valid
- **Whisper offline inference** on a synthetic tone — reports external network requests made
- **Urdu translation offline** — verifies output is Urdu script + external requests
- RTL rendering + bundled Noto Nastaliq Urdu font
- SRT parse ↔ serialize round-trip
- Model files still present in cache after restart

Then complete the 18-point device checklist (Docs tab): real English video, second source
language, sync + RTL visual checks, SRT/VTT export, close/reopen, airplane mode, offline
replay + offline subtitle load, offline generation of a new video, long-video limits.

## Known limitations

- Urdu MT download is ~1 GB (int8); phones with < 6 GB RAM may be too slow or fail — generate on
  a desktop (same code) or use the APK path.
- Audio memory ≈ 32 KB/s of video; > 45–60 min is risky on phones (UI warns above 45 min).
- Auto language: MT source tag inferred from script (Latin defaults to English) — pick the
  language explicitly for best results.
- Browser storage can be cleared by the user/OS — export SRT/VTT as backup; models re-download.
- Codec support depends on browser + FFmpeg core (H.264/VP9/Opus solid; AV1/AC3 varies).
- NLLB is non-commercial licensed; Whisper (CC-BY-4.0) and M2M100 (MIT) are permissive.

## Android APK

- **Quick wrap (works):** Capacitor/TWA around the built app — verify every feature offline;
  wrapping does not automatically make anything offline.
- **Production (recommended):** native app reusing this project's pipeline/subtitle/storage
  modules (framework-agnostic TypeScript):
  - ASR: **whisper.cpp** (ggml tiny/base) — far faster than WASM.
  - Urdu MT: **ctranslate2** with
    `manancode/opus-mt-en-ur-ctranslate2-android` (int8 OPUS-MT en→Urdu, ≈ 10 MB, permissive) —
    the small Urdu model the web cannot host — or NLLB via TFLite/ONNX.
  - Native file access (SAF) + app-private model storage.

## Architecture

```
src/
  lib/
    catalog.ts        verified model + language catalog
    db.ts             IndexedDB (videos, subtitles, files, settings, translation cache)
    modelManager.ts   HF Hub downloads w/ progress, cache verification, removal, storage info
    engines.ts        ONNX pipeline holders (ASR / MT)
    audio.ts          16 kHz mono extraction: browser decoder → FFmpeg WASM fallback
    pipeline.ts       generation pipeline + shared cue translator (no double translation)
    subtitles.ts      SRT/VTT/ASS parse & serialize, segmentation, script detection, RTL
    selftest.ts       device self-tests with network-request spy
  components/         Player, Generate, Models, Library, Tests, Docs tabs + UI kit
```
