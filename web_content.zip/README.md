# FRA — versão melhorada (protótipo social)

## O que está incluído
- Interface responsiva para telemóvel e computador, com tema preto e azul-esverdeado.
- Ecrã de início de sessão mais claro, criação de conta e mostrar/ocultar palavra-passe.
- Feed social, Momentos, publicações, gostos, partilha, pesquisa e perfis.
- Mensagens demonstrativas, notificações e comunidades.
- Dados de demonstração e contas guardados localmente no navegador.
- Ícone FRA e manifesto PWA para preparar instalação como aplicação web.

## Como testar no Android
1. Extrai o ficheiro ZIP.
2. Abre `index.html` num navegador compatível, ou publica a pasta num serviço de alojamento estático.
3. Escolhe **Criar conta grátis**, preenche os campos e entra.
4. Depois de publicado num endereço HTTPS, podes usar o menu do Chrome e escolher **Adicionar ao ecrã inicial** (o nome pode variar).

## Importante
Este ZIP é um **protótipo front-end funcional**, não é ainda uma rede social pública com servidor. Contas, mensagens, gostos e publicações ficam guardados no dispositivo/navegador; não são sincronizados entre utilizadores ou telemóveis. A palavra-passe deste protótipo é guardada localmente e não deve ser usada para contas reais. A recuperação por e-mail, autenticação segura no servidor, sincronização, notificações push, moderação, chamadas, Stories/Reels reais e publicação na Play Store precisam de backend, testes e configuração adicionais.

O ficheiro ZIP não é um APK. Para gerar um APK será necessário empacotar a aplicação com uma ferramenta Android/PWA ou um projecto Android e testar a instalação.
