# Windows 11 Offline Android app project

This Android Studio project wraps the provided offline Windows 11 HTML file in an Android WebView.

## Build an APK in Android Studio
1. Open this folder in Android Studio.
2. Let Gradle sync and install the requested Android SDK (API 35) if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The APK will be created at `app/build/outputs/apk/debug/app-debug.apk`.

## Build APK using GitHub Actions
1. Create a GitHub repository and upload the contents of this ZIP.
2. Open the repository's **Actions** tab.
3. Run **Build Windows 11 Offline APK** (or push to `main`).
4. Open the completed workflow run and download the `Windows11Offline-debug-apk` artifact.

## Notes
- The HTML is bundled inside the APK, so the main screen works offline.
- This is a debug APK configuration, not a Play Store release/signing setup.
- Browser features depend on what the original HTML implements; WebView cannot make unsupported HTML features work automatically.
