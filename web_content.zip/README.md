# Mindloom for Android

A WebView app that bundles the Mindloom brain-training game (app/src/main/assets/index.html). Works offline. No ads, no tracking, no network permission.

Requires Android 8.0 (API 26) or newer.

## Get the APK (pick one)

### A. GitHub, no installs
1. Create a new empty repository on github.com and upload everything in this folder (keep the `.github` folder).
2. Open the repository's **Actions** tab, choose **Build APK**, then **Run workflow**.
3. When it finishes (about 3 minutes), open the run and download the **Mindloom-apk** artifact. Unzip it to get `app-debug.apk`.

### B. Android Studio
1. Open this folder in Android Studio (it installs the SDK pieces it needs).
2. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. The file is at `app/build/outputs/apk/debug/app-debug.apk`.

### C. Command line
Needs JDK 17 and the Android SDK (platform 34).

    ./gradlew assembleDebug

## Install on your phone
Copy `app-debug.apk` to the phone, open it, and allow "Install unknown apps" for your file manager or browser when asked.

## Edit the game
All game code is in `app/src/main/assets/index.html`. Change it, rebuild, reinstall. Progress is stored on the device in the WebView's local storage and survives app restarts, but is removed if you uninstall.

## Release signing
The debug APK is signed with a debug key and is fine for personal use. To publish on Google Play, create a release keystore and add a `signingConfigs` block to `app/build.gradle`.
