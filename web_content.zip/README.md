# WDKX AI Rap Radio Studio — Personal Edition (MVP)

## What's included
- Tone.js procedural instrumental beat generator (boom bap, trap, bounce)
- BPM control and live playback
- 20-second beat recording to WebM/Opus where supported
- Import and play personal audio files
- Playlist saved in IndexedDB on the device
- Playlist metadata export
- Installable PWA shell / service worker

## Important limitations
- This is an independent personal project, not an official WDKX app or broadcast.
- It does not transmit an over-the-air or internet radio station.
- It does not generate rap vocals or imitate any specific artist.
- YouTube video rendering and YouTube account upload are not implemented in this MVP.
- Uploaded audio is stored locally in the browser on this device. Clearing browser site data can erase it. Exporting the playlist JSON does not back up the audio files.
- Tone.js is loaded from jsDelivr, so first-time beat generation requires an internet connection. The local audio library and player are separate.

## Run on Android
1. Put these files on a static HTTPS host (or run a local development server).
2. Open the HTTPS site in Chrome on Android.
3. Tap Chrome's menu and choose **Install app** or **Add to Home screen**.
4. Open the installed app and allow audio playback.
5. Use **Choose audio files** to import your own tracks.

For local computer testing, serve this folder with any simple static server. Do not open index.html as a `file://` URL because browser storage and service workers may be restricted.

## Next development milestone
Add server-side media rendering with FFmpeg, secure account connection using Google OAuth, and YouTube Data API upload after the user explicitly connects their own channel. Keep credentials on the server, never in client-side HTML.
