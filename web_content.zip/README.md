# Dushanbe Purple Map

Харитаи замонавии Душанбе бо:
- UI-и glassmorphism / transparent
- Purple design
- OpenStreetMap + Leaflet
- Ҷустуҷӯи ҷойҳо
- GPS/Location permission аз браузер
- менюи шаффоф ва responsive

## Иҷро
`index.html`-ро дар браузери муосир кушоед.

### Муҳим барои Location
Браузер одатан Geolocation-ро танҳо дар **HTTPS** ё `localhost` иҷозат медиҳад. Барои GitHub Pages ё дигар hosting-и HTTPS, тугмаи "Ҷойгиршавии ман"-ро пахш кунед ва Location permission-ро Allow кунед.

Папкаи `examples/` дорои намунаҳои Python, Java ва C++ аст. Версияи асосии харитаи веб бо JavaScript кор мекунад.
