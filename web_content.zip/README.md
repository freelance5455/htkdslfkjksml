# PREDX APP STUDIO — Front-end Website Project

A responsive, mobile-friendly PREDX APP STUDIO interface inspired by the supplied reference image.

## Run
1. Extract the ZIP.
2. Open `index.html` in a modern browser.
3. For best results, serve the folder with a local static server.

## Included screens
- Dashboard and recent projects
- HTML Studio with editable code and local iframe preview
- APK Builder interface with ZIP file selection and project metadata validation
- Website Studio preview
- App Store demo listings and search/filter
- Hosting Panel interface
- AI Assistant chat interface (demo response)
- My Projects and Profile/Settings

## Important functionality notes
This ZIP is a front-end website prototype. It does **not** compile Android APKs, publish websites to the public internet, provide real app downloads, or call a live AI model. Those features require secure backend services and external provider/API credentials. Do not place private API keys in browser JavaScript.

## Files
- `index.html` — app structure and screens
- `style.css` — responsive black/neon-green visual design
- `app.js` — navigation and demo interactions
