# KIRU AI — first working version

A mobile-friendly voice-first AI assistant interface.

## Run
Open `index.html` in Chrome, or deploy the folder to any static hosting service.

## Voice
Chrome/Edge support the Web Speech Recognition API on supported devices. The browser asks for microphone permission.

## Make it a real AI
Replace `localReply()` in `app.js` with a secure backend call to your chosen AI API. Do NOT put a private API key directly in browser JavaScript. A backend/proxy is required for production.
