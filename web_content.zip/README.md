# CryptoTrader v4.4 TR Teste — 100 USD Enhanced

Paper Trading, começando com 100 USD e carteira limpa.

Melhorias desta versão:
- 3 análises iniciais antes da primeira compra.
- 2 confirmações consecutivas por ativo.
- Filtro BTC em 1h + confirmação em 15m.
- Filtro de mercado: pausa novas compras quando há pressão geral de queda.
- Confirmação 1h + 15m para entradas.
- Evita comprar quando o preço está demasiado esticado acima da EMA20 ou RSI elevado.
- Trailing adaptativo e proteção de lucro mantidos.
- Registo de decisões e Paper Trading mantidos.
