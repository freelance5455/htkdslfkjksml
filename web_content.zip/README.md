# Android build configuration

The APK contains only the backend API URL. PayPal client secrets, webhook secrets, JWT secrets, owner passwords, database credentials, and provider credentials stay on the backend.

Build a release with:

`./gradlew :app:assembleRelease -PAPI_URL=https://YOUR-DEPLOYED-BACKEND`

Do not put provider secrets in Gradle properties, resources, Kotlin source, or the APK.
