# CutLab – projet de compilation

Le code de l'appli est dans `www/index.html` (un seul fichier).

## Option 1 : APK automatique avec GitHub (sans rien installer)
1. Crée un dépôt GitHub et envoie-y tout le contenu de ce dossier.
2. Onglet Actions > "Build APK" > Run workflow.
3. Télécharge `CutLab-apk` en bas de la page du run, puis installe `app-debug.apk`.

## Option 2 : en local (Node 18+, Android Studio)
    npm install
    npx cap add android
    cp native/MainActivity.java android/app/src/main/java/com/cutlab/app/MainActivity.java
    bash native/add-permissions.sh
    npx cap sync android
    npx cap open android     # puis Build > Build APK

## Option 3 : site web
Envoie `www/index.html` sur n'importe quel hébergement (Netlify, GitHub Pages…).

Après chaque modification de `www/index.html` : `npx cap sync android`.

## Notes APK
- `native/MainActivity.java` autorise la lecture audio/vidéo sans geste (nécessaire dans la WebView).
- L'export est enregistré via les plugins Filesystem + Share : une fenêtre de partage s'ouvre, choisis « Enregistrer sur l'appareil ».
- `native/add-permissions.sh` + `MainActivity.java` ajoutent et demandent l'accès aux vidéos, images et sons de l'appareil (Android 13+ : READ_MEDIA_*).
- Plein écran : bouton ⛶ ; le bouton Retour d'Android le quitte.
- Bouton 🐞 (en haut) : journal de diagnostic. En cas de souci d'import, ouvre-le et envoie une capture.
