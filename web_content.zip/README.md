# Fruit Mazes — Independent Online Build

This project is independent from Manus at runtime. It runs as a static HTML/JavaScript app and uses only the external Supabase project configured in `online-adapter.js` for optional accounts, rooms, chat, and realtime state.

## Run locally

```bash
python3 -m http.server 4173
```

Open `http://localhost:4173/`.

Do not open `index.html` with `file://`; browser storage, WebSocket, and module/resource behavior are more reliable over HTTP.

## Supabase setup

Run `supabase-schema.sql` in the Supabase SQL editor, enable Email authentication, and ensure the listed tables are enabled for Supabase Realtime. Never put a Supabase service-role key in this project.

## Independence

- No Manus SDK, runtime, host, API, or account is used.
- The project can be copied to any static host or run locally.
- Supabase is optional for offline play and is the only runtime backend dependency for online features.

## Lobby and Audio Update

The current build includes an original, asset-free lobby layout with:

- Offline entry button
- Online entry button
- Shop entry button
- Player profile and progress cards
- Level select panel
- Audio Lounge controls

Audio is generated locally with the Web Audio API, so no paid audio service or runtime asset host is required. It includes separate procedural themes for the lobby, maze exploration, online race, and victory, plus fruit pickup, click, unlock, win, lose, and caught effects.
