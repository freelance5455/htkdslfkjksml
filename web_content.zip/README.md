# EC Technologie V4 PRO — projet récupéré et corrigé

Ce dossier est reconstruit à partir de l'APK fourni. Il contient le projet Android Studio et les fichiers Web récupérés.

## Correction principale
L'APK original affichait `https://appassets.androidplatform.net/web/index.html` mais la ressource locale n'était pas correctement exposée à cette URL. `MainActivity.java` ajoute maintenant explicitement le mapping `/web/` vers `assets/web/`.

## Important
- Aucun APK n'est inclus dans ce projet.
- Le code source Android est reconstruit : ce n'est pas le projet original exact.
- Ouvrir le dossier dans Android Studio, laisser Gradle récupérer les dépendances, puis compiler l'application.
