# Color Rush — Production-Ready Android Game Project

> **"Tap Fast. Stay Alive."**  
> An addictive, fast-paced, high-FPS color-matching mobile arcade game with Fever Mode, Danger Bombs, Golden Bonuses, Daily Challenges, Achievements, and unlockable Themes.

---

## 📱 Project Specifications

| Property | Value |
| :--- | :--- |
| **App Name** | `Color Rush` |
| **Package ID** | `com.colorrush.game` |
| **Target Platform** | Android 7.0+ (API 24 to API 34+) |
| **Framework** | Vite + React + TypeScript + Tailwind CSS |
| **Mobile Runtime** | Native Android via Capacitor 8 |
| **Audio Engine** | Web Audio API (Zero external audio files, 100% offline) |
| **Orientation** | Portrait (locked in `AndroidManifest.xml`) |

---

## 🚀 Quick Start Guide

### 1. Install Dependencies
Open your terminal inside the project root directory and run:

```bash
npm install
```

### 2. Build the Web Project
Compile the optimized production assets:

```bash
npm run build
```

This compiles your HTML, CSS, JavaScript, and SVG assets into the `dist/` folder.

---

## 🤖 Android Packaging with Capacitor

The project is already pre-configured with Capacitor:
- **`capacitor.config.ts`** and **`capacitor.config.json`** with `appId: "com.colorrush.game"` and `appName: "Color Rush"`.
- **`android/`** native project directory with all Gradle build scripts, AndroidManifest with portrait lock, and `VIBRATE` permission.

### 3. Add Android Platform (if starting fresh)
If you ever need to recreate the `android` folder:

```bash
npx cap add android
```

### 4. Sync Web Assets to Android
Whenever you modify your game code or run `npm run build`, sync the assets into the Android native project:

```bash
npm run build:android
# or:
npx cap sync android
```

### 5. Open in Android Studio
Launch Android Studio with the native Android project:

```bash
npx cap open android
```

Alternatively, open Android Studio manually, choose **Open an Existing Project**, and select the `android/` directory inside this project.

---

## 📦 Generating Android APK and AAB

### Method A: Using the Command Line (Gradle)

#### Generate Debug APK (for instant testing on your phone)
From the project root:

```bash
cd android
./gradlew assembleDebug
```
The output APK will be located at:
```
android/app/build/outputs/apk/debug/app-debug.apk
```
Transfer this `.apk` to any Android phone or install directly via ADB:
```bash
adb install android/app/build/outputs/apk/debug/app-debug.apk
```

#### Generate Release APK
```bash
cd android
./gradlew assembleRelease
```
The output will be at:
```
android/app/build/outputs/apk/release/app-release-unsigned.apk
```

#### Generate Android App Bundle (.aab) for Google Play Store
Google Play requires an `.aab` (Android App Bundle) for new store submissions:

```bash
cd android
./gradlew bundleRelease
```
The output `.aab` will be located at:
```
android/app/build/outputs/bundle/release/app-release.aab
```

---

### Method B: Using Android Studio (Visual GUI)

1. Run `npx cap open android`.
2. Wait for Gradle to finish indexing.
3. In the top menu bar, click **Build** → **Generate Signed Bundle / APK...**.
4. Choose **Android App Bundle** (for Google Play) or **APK** (for direct testing).
5. Click **Next**, create or choose your keystore file.
6. Select **release** build variant and click **Finish**.
7. Android Studio will generate the signed `.aab` / `.apk` and show a notification with a direct link to the folder!

---

## 🔑 Signing Your Release Build (Keystore)

To generate a production keystore for Google Play:

```bash
keytool -genkey -v -keystore colorrush-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias colorrush
```

Store `colorrush-release-key.jks` in a secure location and configure signing in `android/app/build.gradle`.

---

## 🎨 Game Assets & Structure

```
├── android/                   # Complete native Android Studio project
│   ├── app/
│   │   ├── src/main/AndroidManifest.xml  # Configured with portrait & vibration
│   │   ├── src/main/res/values/strings.xml # "Color Rush" & package id
│   │   └── build.gradle       # Android build configs
│   ├── build.gradle
│   └── gradlew
├── dist/                      # Production web assets
├── public/                    # Static assets & web manifest
│   ├── manifest.json          # PWA / Android web manifest
│   ├── icon-192.svg           # High-resolution 192x192 icon
│   └── icon-512.svg           # 512x512 adaptive launcher icon
├── src/                       # Complete TypeScript game codebase
│   ├── components/            # UI Modals, HUD, buttons, particle engine
│   ├── audio.ts               # Web Audio API procedural sound engine
│   ├── haptics.ts             # Native vibration feedback
│   ├── storage.ts             # Local persistence (scores, themes, coins)
│   ├── firebase.ts            # Optional Google Sign-In & Leaderboard
│   ├── types.ts               # Complete game type definitions
│   └── App.tsx                # Main game orchestrator
├── capacitor.config.ts        # Capacitor configuration
├── capacitor.config.json      # Capacitor backup config
├── package.json               # NPM packages & build scripts
└── README.md                  # This documentation
```

---

## 🎮 Gameplay Features Overview

1. **Target Color Orb**: Dynamic shrinking circular timer with color name & speed indicator.
2. **Ergonomic Buttons**: 4 large circular buttons in the natural bottom thumb zone.
3. **Fever Mode**: 10 consecutive taps ignite 6 seconds of 2x score overdrive.
4. **Danger Bombs**: Spawns randomly in higher rounds—tapping ends the game!
5. **Golden Bonuses**: +5 points, +3 coins, and sparkling gold star particles.
6. **Coin Economy**: Earn coins to unlock themes and customize your profile.
7. **Themes**: Neon (Default), Space, Fire, Ocean, and Galaxy.
8. **Daily Challenges**: Rotates every 24 hours with bonus coin payouts.
9. **Achievements**: 9 structured achievements with progress tracking.
10. **Offline Native Experience**: 100% playable anywhere without internet.
