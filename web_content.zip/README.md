# AQEEM by SAFAR — Offline Android Package

Monthly Salah Tracker (Farz, Sunnat, Witr, Nafl, weekly view, monthly summary), fully offline.

## ZIP layout (index.html is at the ZIP root)
index.html · css/style.css · js/app.js · images/ (logo, splash) · icons/ (app icons) · fonts/ · assets/ · manifest.json

Zip the CONTENTS of this folder, so index.html sits at the top level of the ZIP, not inside a subfolder.

## Import into HTML to APK Builder
1. Choose the "ZIP / local HTML project" option (not "Website URL").
2. Upload AQEEM.zip. Confirm the entry file is `index.html`.
3. App name: AQEEM · Package: com.safar.aqeem · Version name 1.0 · Version code 1.
4. App icon: icons/icon-512.png · Splash image: images/splash.png.
5. Theme / status bar colour: #071C18.
6. Leave any "website URL" field EMPTY. Do not enter an https address.
7. Enable JavaScript and DOM storage (usually on by default). Internet permission is not needed.
8. Build, install the APK, then test once in airplane mode.

Builder option names differ between versions; I could not run the real builder, so check that the entry file is index.html and that the URL field stays empty.

## Offline and data
- No external URLs, CDNs, fonts, APIs or PHP anywhere (checked by search and by loading the app with the network disabled).
- Records are saved in IndexedDB plus a localStorage copy, so they persist after closing the app and rebooting.
- Each phone has its own separate data. Sharing the APK shares only the app.
- Uninstalling or using Android "Clear data" erases records. Use Export Backup now and then.

## Changes from the original
Features, logic and Roman-Urdu labels are unchanged. Changes: emerald/gold theme, AQEEM branding and splash, safe-area spacing, text selection off, and custom in-app dialogs instead of confirm(). Backup now offers Copy text / Share / Save file, and Import accepts pasted text or a file. A date rollover refresh was added. The Jumu'ah rakat layout is still the assumed Hanafi default noted in the original code (see JUM in js/app.js).

## Limitations
- "Save as File" and file import depend on the builder's WebView. Copy/paste backup works regardless.
- Android Back closes an open dialog; pressing it on the main screen exits the app (builder-controlled).
- Not tested on a physical device or the real builder.
