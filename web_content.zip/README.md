# آئیڈیا والٹ — Idea Vault

ایک خوبصورت RTL/اردو web app جو ایپ، SaaS، AI، گیم اور کاروباری آئیڈیاز کو الگ الگ structured fields میں محفوظ کرتی ہے۔

## خصوصیات
- مکمل اردو RTL UI
- Jameel Noori Nastaleeq web font کی ترجیح، ساتھ local Noto Nastaliq fallback
- ہر آئیڈیا کے لیے عنوان، قسم، بنیادی خیال، مسئلہ، حل، فنکشنز، ٹارگٹ یوزر، بزنس ماڈل اور ٹیکنالوجی/نوٹس
- خودکار تاریخ
- رنگ منتخب کرنے کی سہولت
- آٹو سیو
- سرچ اور category filter
- Favorites اور Recent views
- JSON Backup / Restore
- LocalStorage persistence
- PWA/service worker: ایپ کو installable/offline shell بنایا گیا ہے

## چلانے کا طریقہ
سادہ static hosting کافی ہے۔ بہتر تجربے کے لیے کسی local server سے چلائیں:

```bash
python -m http.server 8080
```
پھر browser میں `http://localhost:8080` کھولیں۔

## اہم نوٹ
ڈیٹا اس browser/device کے localStorage میں محفوظ ہوتا ہے؛ browser data صاف ہونے یا device خراب ہونے کی صورت میں local copy ختم ہو سکتی ہے۔ اسی لیے Backup بٹن سے JSON backup وقتاً فوقتاً محفوظ رکھیں۔

Jameel Noori Nastaleeq web font کے لیے app میں CDN source شامل ہے؛ اگر internet دستیاب نہ ہو تو bundled Noto Nastaliq Urdu fallback استعمال ہوگا۔ اگر آپ کے پاس Jameel Noori Nastaleeq کی licensed TTF/WOFF فائل ہے تو اسے `assets/fonts/` میں رکھ کر CSS میں local `@font-face` source کو ترجیح دی جا سکتی ہے۔
