# AZ-JEK - Web Application
Aplikasi Ojek Online untuk Balai Dusun Pinggir, Watupatok, Kabupaten Pacitan, Jawa Timur.

## Kredensial Driver:
Username: driverpinggir
Password: AZJEK123

## Kredensial Admin:
Username: Handika
Password: Handika123