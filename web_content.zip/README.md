# Rewarded SSV Android + Node Backend

Starter project for an Android WebView app using Google AdMob Rewarded Ads with
server-side verification (SSV).

## Project structure

- `android/` — Android Studio / AndroidIDE project
- `backend/` — Node.js + Express + PostgreSQL backend
- `backend/sql/schema.sql` — database schema
- `backend/.env.example` — backend configuration
- `android/app/src/main/assets/index.html` — WebView demo

## Security model

The client-side `onUserEarnedReward` callback is UI-only. The authoritative
reward is granted by the backend after:

1. Google sends the SSV callback.
2. The backend verifies Google's ECDSA signature.
3. The transaction ID is checked for replay/idempotency.
4. `user_id` and `custom_data` are checked against the pending reward session.
5. The database transaction records the reward and updates the user's balance.

For production, replace the demo anonymous-user bootstrap with your real
authentication/session system.

## AdMob setup

Development uses Google's official test App ID and rewarded test ad unit ID.
Replace them with your own IDs before release.

In AdMob, configure the rewarded ad unit's SSV callback URL:

`https://YOUR_DOMAIN/v1/admob/ssv`

## Backend

Requirements:
- Node.js 20+
- PostgreSQL

```bash
cd backend
cp .env.example .env
npm install
# create the PostgreSQL database, then:
psql "$DATABASE_URL" -f sql/schema.sql
npm start
```

For local Android emulator testing, the Android client defaults to:
`http://10.0.2.2:3000`

For a physical Android device, set `API_BASE_URL` to your computer's LAN IP
or to your deployed HTTPS backend.

SSV itself must be reachable by Google's servers over a public HTTPS URL.

## Important

Do not treat an Android-generated user ID as authentication in a production
app. It is only suitable for this starter/demo. Use your existing Messenger
login/session/JWT system and bind reward sessions to the authenticated account.
