# Mamun Studio Ultimate

This is an expanded mobile-first browser video-editing prototype. It includes many common editor controls, but **cannot honestly be described as having every feature in CapCut**.

## Features in this version
- Video import and preview
- Play/pause, seek, jump back/forward
- Trim in/out points
- Text overlays with position, size, color, weight
- Emoji sticker overlay
- Image/logo overlay
- Brightness, contrast, saturation, hue, blur, sepia
- Cinema, vivid, monochrome, warm, cool and fade presets
- Fit/crop, rotation, horizontal flip/mirror
- Playback speed preview
- Audio file selection and volume settings (separate music mixing is not exported yet)
- Manual subtitle/caption workspace
- PNG still-frame export
- Original video download
- Save/load project settings as JSON
- Aspect ratio choices: original, 9:16, 16:9, 1:1
- WebM export with bitrate options

## Android setup
1. Download and extract the ZIP.
2. Upload `index.html` to an HTTPS static host such as Cloudflare Pages or GitHub Pages.
3. Open the hosted URL in updated Chrome.
4. Import a short video first and test each tool.

## Limitations
- This is a browser prototype, not a native APK or complete professional editor.
- Export is WebM, not MP4/H.264.
- No multi-track timeline, real transitions, keyframes, speed-ramp rendering, chroma key, masking, stabilization, auto-caption speech recognition, AI video generation, background removal, cloud sync, proxy media, LUT import, or professional audio mixing.
- Music import and fade controls are settings/UI only; audio mixing is not implemented.
- Some filters/effects may render differently between preview and export.
- Large 4K files can exceed Android phone memory or heat up the device.
- The export engine relies on browser `MediaRecorder`; codec support varies.
- A real CapCut-class editor needs a native rendering engine or robust server pipeline, codec integration, testing, licensing and considerable development. Adding ZIP file size does not add functionality.

## Security
No API keys are used. Never place private API keys in client-side JavaScript. If AI/cloud rendering is added, use a secure backend and review service costs.
