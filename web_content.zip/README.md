# GBN PRESS24 — Complete App + Admin Panel

## What is included
- Screenshot-style mobile news frontend
- Firebase Firestore news database
- Firebase Authentication admin login
- Admin CRUD for news
- Video manager for YouTube/Facebook/embed URLs
- Live TV URL manager
- Social/contact settings
- Firebase Cloud Messaging device-token registration
- Cloud Function for admin-only push sending
- Firestore security rules
- PWA manifest/service worker

## Firebase setup

### 1. Create Firebase project
Go to Firebase Console and create a project.

### 2. Add a Web App
Project settings -> Your apps -> Web app.
Copy the `firebaseConfig` into:
- `firebase-config.js`
- `firebase-messaging-sw.js`

### 3. Authentication
Firebase Console -> Authentication -> Sign-in method -> enable Email/Password.
Create the admin email/password.

### 4. Firestore
Create Firestore Database and deploy `firestore.rules`.

### 5. Make the first admin
After the admin account is created, copy its Firebase Auth UID.
In Firestore create:
`users/{UID}`
with:
`role: "admin"`

Do not put a password in Firestore.

### 6. Push notifications
Firebase Console -> Cloud Messaging -> Web Push certificates.
Create a Web Push certificate and copy the VAPID key into:
`firebase-config.js`

The browser must be served from HTTPS (localhost is also allowed for development).

### 7. Deploy Cloud Functions
From the `functions` folder:
- `npm install`
- `firebase deploy --only functions`

The included `sendPush` function checks the Firestore admin role before sending.

### 8. Hosting
Firebase Hosting can host the frontend. Put all root files in the hosting public directory and deploy.

## Important production notes
- Keep Firebase Admin SDK/service-account private keys out of HTML/JavaScript.
- Use only your own/authorized news images, videos, live streams and social embeds.
- For an `.m3u8` stream, a browser HLS player may be required; the sample frontend handles it as a direct video source where supported.
- Facebook embedding depends on Meta's current embed rules and the URL being embeddable.
- Before publishing, replace placeholder contact/social links.
