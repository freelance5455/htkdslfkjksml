# 📦 Retail Stock & Customer Ledger App

A complete, lightweight, offline mobile application built specifically for retail counters and shopkeepers to manage:
1. **Goods In (Stock Inflow / Restocking)**
2. **Goods Out (Sales / Customer Dispatches)**
3. **Real-time Inventory Tracking & Low Stock Alerts**
4. **Customer Udhaar Ledger (Debt Tracking, Payment Settlements & WhatsApp Statements)**
5. **1-Click Local Data Backups & Excel/CSV Exports**

---

## 🚀 How to Run the App (No Coding Needed!)

### Step 1: Launch the App
1. Open this folder: `d:\gemini project\retail_stock_app\`
2. Double-click **`Start_App.bat`** (or **`Start_Stock_App.bat`** in the main folder).
3. A black terminal window will open and automatically launch the app in your computer's browser.

---

### Step 2: Open & Install on Your Android Phone
1. Make sure your Android phone is connected to the **same Wi-Fi network** as your computer.
2. In the black terminal window, you will see an **ASCII QR Code** and a link like:
   `http://192.168.X.X:8080`
3. Point your Android phone's camera at the QR code (or type the URL into Google Chrome on your phone).
4. **Install to Phone Home Screen:**
   - In Google Chrome on your phone, tap the **three dots menu (⋮)** in the top-right.
   - Tap **"Install app"** or **"Add to Home screen"**.
   - Confirm by tapping **"Install"**.
5. **Done!** The **"Stock & Ledger"** icon will appear on your phone's home screen.
6. Once opened, it runs **100% offline**, saving all data directly inside your phone.

---

## 📱 Core Features & How to Use

### 1. Dashboard (Home)
* **Total Stock Value:** Automatically computes current stock multiplied by purchase cost.
* **Customer Due (Udhaar):** Total money owed to you across all customers.
* **Low Stock Items:** Alerts you when any product falls below its reorder limit.
* **Today's Activity:** Quick view of bills generated and cash collected today.
* **Quick Buttons:** Instant shortcuts to `+ GOODS IN` and `- GOODS OUT`.

### 2. Goods In (Restock Inventory)
* Select an item (or tap **"+ New Product"** to create one on the fly).
* Enter the quantity received and purchase cost.
* Tap **"Add to Stock (+ Goods In)"**.
* Inventory count is updated immediately.

### 3. Goods Out (Sales & Customer Ledger)
* Select the customer (or tap **"+ New Customer"**).
* Select the product and enter quantity. Available stock is checked in real-time to prevent overselling.
* Enter selling rate: The app automatically calculates **Total Bill**.
* Enter **Paid Today**:
  * If the customer pays fully, balance due is ₹0.
  * If the customer pays partially or takes it on credit (Udhaar), the remaining balance is automatically added to their ledger.
* Tap **"Confirm Goods Out & Update Ledger"**.
* A confirmation popup appears with a **"Send Bill on WhatsApp"** button to message the customer with 1 tap.

### 4. Customers & Udhaar Ledger
* Search any customer by name or phone number.
* Each card displays their current balance due in **RED** (if money owed) or **GREEN** (if clear).
* Tap any customer to open their **Customer Profile**:
  * See lifetime purchases, lifetime payments, and net outstanding due.
  * View chronological history of every product taken and every payment made.
  * Tap **"Receive Payment"** when a customer pays their old balance.
  * Tap **"Send WhatsApp"** to send them a friendly balance statement with 1 tap.

### 5. Inventory Management
* View all products, units (pcs, kg, box, etc.), purchase rate, sale price, and current stock.
* Filter by **"All Items"**, **"Low Stock"**, or **"Out of Stock"**.
* Tap any product to view its complete audit log of all stock inflows and outflows.

### 6. Data Safety & Excel Export
* Tap the **💾 icon** in the top-right header:
  * **1-Click Full Backup:** Download a `.json` backup file.
  * **Restore Backup:** Easily restore your data if you switch phones.
  * **Export to CSV / Excel:** Export your Inventory list, Customer Balances, or Movement history into spreadsheets.

---

## 🔒 100% Privacy & Zero Monthly Fees
* All data is stored in your device's internal **IndexedDB** database.
* No third-party servers, no monthly subscriptions, and no internet required for daily counter billing.
