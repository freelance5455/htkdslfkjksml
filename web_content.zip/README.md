# ⎯꯭‌❃⃪꯭‌𝆺꯭𝅥𝐃𝐄🅥︎𝐈𝐋♡︎𝐌𝐀🅗︎𝐈𝐑⎯꯭🥵 — v5

Facebook / Messenger browser-call microphone engine (Manifest V2).

**Developer:** ⎯꯭‌❃⃪꯭‌𝆺꯭𝅥𝐃𝐄🅥︎𝐈𝐋♡︎𝐌𝐀🅗︎𝐈𝐑⎯꯭🥵

## v5
- New premium 3D rose-gold interface with animated Gain dial, 3D mode keys and 3D sliders.
- Studio HD / Royal Clear / Lord sound modes.
- Noise gate, de-esser, mud cut, tone EQ and advanced DSP controls.

## Use
1. Install as an unpacked / signed extension.
2. Open Facebook or Messenger Web and **reload the tab** before joining a call.
3. Open the popup and pick a sound mode. Use headphones with raw mic lock on.

Change the profile picture by replacing `assets/avatar.jpg`.
