# VOID — kaise use kare (Hinglish)

## 1. Sabse aasan: LIVE PREVIEW (port 8000)
Workspace me **`VOID app`** naam ka live preview khol lo (`https://8000-ivg3fujrg76y751gmsev7.e2b.app`).
Yeh server wala version hai — sab kuch chalega.

## 2. Static / offline: `index.html` (single file, koi server nahi)
`index.html` **poora app hai ek file me** — 220 KB, koi backend nahi, key seedha Groq ko jaati hai.

Use karne ke 3 tareeke:
- **Phone/laptop pe:** file download karo → Chrome me kholo (file:// bhi chalega).
- **Host karna hai (Netlify jaisa):** https://app.netlify.com/drop pe `index.html` drag-drop karo → URL mil jayega.
- **Preview iframe me mat kholo** — usme internet blocked hota hai, isliye Groq call fail hoti hai (app khud banner dikha dega).

## 3. Setup (ek hi baar)
1. ⚙ (gear) dabao → **Groq API key** me `gsk_...` paste karo (https://console.groq.com/keys).
2. **Save key** → turant test hoga, `✓ Working! N models` aayega.
3. **⟳ Check models available to my key** → tumhari key ke saare models load ho jayenge.
4. Chat model + Photo/vision model select karo.
5. **Reply language** (Hinglish / Hindi / English / Auto) aur **Answer length** (Short / Balanced / Detailed) chuno.
6. **Save all settings** → done.

## Features
- Real Groq streaming (typing effect, live)
- **Auto model fallback**: koi model key pe na chale → apne aap agla model (chat: llama-3.3-70b → gpt-oss-120b → kimi-k2 → qwen3-32b → llama-3.1-8b → gemma2-9b; vision: llama-4-maverick → scout → llama-3.2-vision)
- 📎 **photo attach** (`+` button) → vision model automatically
- 🎤 voice input (Chrome)
- Code block pe **copy** + **download** (file `.py/.sh/...` ban jaati hai)
- Chats browser me save (drawer ☰ se purani chat khulo, export JSON)
- Key + settings sirf browser ke localStorage me — koi server pe nahi
- Error messages seedhe kaam ke: 401 key invalid, 429 rate limit, model access, network blocked

## Files
| file | kya hai |
|---|---|
| `index.html` | **main deliverable** — standalone app (single file) |
| `void_standalone_src.html` | same app, galaxy image placeholder ke saath (edit karne ke liye) |
| `void.py` / `void-app/void.py` | FastAPI server version (server-side file save/run ke saath), port 8000 |
| `assets/galaxy.jpg` | tumhari di hui galaxy photo (bg me inline hai) |

## Note
`Run` button server version me hai (code sandbox me chalata hai) — standalone me security ke liye sirf `copy` + `download` hai.
