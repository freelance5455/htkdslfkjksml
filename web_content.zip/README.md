# KOTA'S DAILY ROUTINE — Android project

This Android Studio project packages the current cloud-sync HTML app as a native Android WebView app.

## Features
- KOTA'S DAILY ROUTINE UI
- Supabase authentication and cloud sync
- Local/offline browser storage
- Roadmap, tasks, calendar, focus, books, and Space sections
- Portrait Android app
- Rocket app icon

## Build
Open this folder in Android Studio, let Gradle sync, then:
Build > Build Bundle(s) / APK(s) > Build APK(s)

The debug APK will normally be under:
app/build/outputs/apk/debug/app-debug.apk

## Important
The Supabase publishable key is embedded in the HTML because it is intended for browser/client use. Never embed a Supabase secret/service-role key in the app.

The SQL setup must already have been run in the Supabase project.
