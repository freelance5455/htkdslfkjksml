# Nova AI — starter project

This project includes:
- AI chat (uses a configured OpenAI-compatible chat-completions API)
- Google web search shortcut
- AI-generated single-file HTML game downloads
- AI-generated single-file website downloads
- A basic age-appropriate safety instruction in the assistant system prompt

## Run locally
1. Install Node.js 18 or newer.
2. Extract this ZIP and open a terminal in the project folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Add your own AI provider API key to `AI_API_KEY` in `.env`, and set `AI_BASE_URL` and `AI_MODEL` if your provider requires different values.
6. Run `npm start`.
7. Open `http://localhost:3000`.

## Important
- The HTML page alone cannot provide AI responses. The Node.js server and a compatible AI API account are required.
- Never publish your API key in the HTML/JavaScript or share it in chat. Keep `.env` private and do not upload it to a public repository.
- The Search tab opens Google results; it is not an integrated live web-search engine.
- The safety prompt is a basic safeguard, not a complete moderation system.
- API usage may cost money depending on your provider and account. Check with a parent/guardian before creating paid accounts or deploying services.
