# Shri Parshwnatha Rice Mill — Android App Source

This is a new offline-first Android WebView/Capacitor project based on the supplied SPRM requirements.

## What is implemented in this build candidate
- Offline-first mobile interface and IndexedDB storage.
- Dashboard and modules for Hulling, Paddy Purchase, Paddy Dispatch, Sales, Parties, Expenses, Labour, Electricity, Reports, Outstanding Ledger, Audit Log, and Settings.
- Paddy dispatch gross/deduction/net weight calculations, KG/QTL conversion, manual overrides, recalculate action, validation, stock balance validation, and FIFO allocation records.
- Purchase, dispatch, sales, hulling, expense, labour, electricity and party records can be created, edited and deleted, with audit entries.
- Paddy stock is calculated from purchase lots and recorded paddy dispatch/sale allocations. Purchase lots with active allocations cannot be deleted or reduced below allocated stock.
- JSON backup and restore; CSV export; local data only.
- GitHub Actions workflow to build a free debug APK.

## Important limits
This is a working development build candidate, not yet certified as production-ready accounting software. Test it using dummy records first. Specifically:
- Rice/bran/husk production yield tracking, complete GST tax treatment, bill-photo attachment, and full PDF report formatting are not fully implemented.
- Google Drive is manual backup only: export JSON, then save/share the file to Drive. No automatic cloud sync.
- Local data stays on the device/app installation. Clearing app data or uninstalling can remove records. Export backups regularly.
- The app does not provide multi-user cloud sync.
- No automated weighbridge hardware integration.

Do not use it as the only record system for live business until you have tested all cases and confirmed balances against your books.

## Build an APK for free using GitHub Actions
You do not need Android Studio on your own computer, but you do need a GitHub account and internet access for the build.

1. Download and unzip this source package.
2. Open https://github.com and create a new repository (for example `sprm-rice-mill-app`). A free private repository is fine.
3. On the new repository page, choose **Add file → Upload files**. Upload the contents inside this folder (including `.github` and `www`) — not just the ZIP file. If GitHub does not show `.github`, upload that folder through the website or use GitHub Desktop.
4. Commit the uploaded files.
5. Open the repository's **Actions** tab. Enable Actions if GitHub asks.
6. Select **Build SPRM Android APK** and press **Run workflow**. If it does not appear, make sure `.github/workflows/build-apk.yml` was uploaded.
7. Wait for the workflow to finish with a green tick.
8. Open the completed workflow run, scroll to **Artifacts**, and download `SPRM-debug-apk`.
9. Extract the downloaded artifact ZIP. It contains `app-debug.apk`. Transfer it to your Android phone and install it. Android may ask you to allow installation from that source.

The first build may take several minutes. GitHub Actions provides free minutes for public repositories and limited free usage for private repositories; check your account's current quota. Do not publish a private repository publicly if it contains private data. This source contains no customer data.

## Updating the app
Upload changed source files to the repository and rerun the workflow. Installing a new APK with the same app ID normally updates the existing installation if signatures match. Keep backups before updates. Do not uninstall the existing app before checking that your backup restores successfully.

## Run in a browser
Serve the `www` folder from localhost/HTTPS. Opening `index.html` directly may prevent some offline/PWA features.
