# Ilostan — bez kont + dodawanie zdjęć

Wersja webowa bez rejestracji i logowania, przygotowana do spakowania jako APK.

Funkcje:
- katalog i wyszukiwanie pojazdów
- strony szczegółowe
- dodawanie wielu zdjęć z galerii/aparatu telefonu
- galeria zdjęć na stronie pojazdu
- usuwanie zdjęć
- komentarze bez kont
- dodawanie pojazdów
- statystyki
- zapis danych lokalnie na urządzeniu
- interfejs mobilny

Zdjęcia i dane są przechowywane lokalnie w pamięci przeglądarki/aplikacji. Nie są automatycznie wysyłane do internetu.

Cały folder można spakować do ZIP i wgrać do buildera ZIP → APK.
