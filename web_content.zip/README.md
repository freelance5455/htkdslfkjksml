# Bee-Blox Ultimate

Bee-Blox is a bee-themed Android Roblox companion/launcher.

## Access
- Users sign in first.
- Current build key: `Bee-Blox26`
- The key itself never expires.
- Every successful activation grants 24 hours of access.
- After the 24 hours end, the user must enter a current key again.
- No VIP tier.

## Get the current key
Join the Bee-Blox Discord:
https://discord.gg/bee-blox

## Major features
- Animated bee login/key screens
- 24-hour live countdown
- Discord key button/link
- Home dashboard and stats
- Library with live search and categories
- Games tab with official Roblox launcher shortcuts
- Editor with save/copy/clear and live statistics
- Tools hub, usage stats and note stats
- Expanded settings and accent themes
- Haptics, animation and compact mode preferences
- Help & Support and bug-fix notes
- About page
- Bottom navigation
- Official Roblox launcher with website fallback

## Important safety
Bee-Blox is a standalone companion. It does not inject, execute, modify, or bypass Roblox security and it does not request Roblox passwords.

## Bug fixes in this edition
- Fixed invalid `styledButton` helper reference
- Fixed sections being attached twice
- Fixed Games navigation selection
- Added live access timer updates
- Added expiry routing back to the key gate
- Added real Discord launch action
- Added working library search filtering
- Improved navigation refresh behavior
- Added safe Android vibration compatibility
- Reduced duplicate UI state issues


### Login removal
This build has no account login, registration, email/password, Google sign-in, or logout system. The Bee-Blox access key is the only gate. Each successful activation grants 24 hours.


## ZIP-to-APK / web-builder compatibility
Added a root `index.html` so builders that specifically require an HTML entry point no longer report `No index.html found`. The original Android Gradle project remains included. Also added `manifest.webmanifest` and `bee-icon.svg` for web/PWA-capable builders.
