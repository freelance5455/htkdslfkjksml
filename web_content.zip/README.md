Daily Progress Manager V2

IMPORTANT: The Android app now loads the actual web app from android/app/src/main/assets/index.html using Android WebView. The same app is also available at web/index.html for web-to-APK builders.

Features include:
- Add unlimited items and delete/restore them.
- Daily progress and visit history.
- Previous-day float given is automatically accumulated and subtracted from the target.
- Monthly dashboard: total items, items visited this month, items visited 5+ times, total visits, and total remaining.
- Offline storage using browser/device local storage.

To build the Android project, open the android folder in Android Studio/AndroidIDE and build the APK.
