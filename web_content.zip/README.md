# Imposed Entertainment Portal

Static site (HTML, CSS, JS) backed by Supabase. Deploy the folder to Netlify as is.

1. config.js holds your Supabase URL and anon key.
2. Supabase, Authentication, URL Configuration: add your Netlify address as the Site URL and a Redirect URL.
3. Supabase, Authentication, Sign In / Providers: enable Google, and turn on Allow manual linking so artists can link Google in Settings.
4. Sign in as the label admin. Invite artists and label members from Roster & invites.

See DATABASE.md for how the data is organised.

Code is split into js/ files. Read ARCHITECTURE.md before editing.

## Quality and security notes

- `netlify.toml` adds baseline security headers and a Content Security Policy for the current third-party dependencies. Test Google sign-in and Turnstile in a Netlify deploy preview before production.
- `BACKEND-SECURITY-REVIEW.md` documents database advisor items that need review inside Supabase; this ZIP does not alter the live database.
- `QA-CHECKLIST.md` lists the key workflows to verify before promotion.
- The Supabase URL and publishable/anon key are public browser configuration. Never add service-role keys or other secrets to this static site.

### Language support
The portal includes a language picker for English, Spanish, French, German, Portuguese and Polish. Supported interface labels are translated, browser language is detected on first visit, dates and numbers use the selected locale, and signed-in users have their preference stored in `profiles.preferred_language` in Supabase. Before sign-in, the preference is kept in browser storage and synced to the profile on login. Some detailed screen copy, validation and system/error messages may still appear in English. Release metadata and user-generated content are not translated.


### v21 visual refresh
The interface now uses a persistent desktop sidebar, a compact mobile navigation, an editorial light workspace with indigo actions, and a redesigned split-screen login. The actual application logic and Supabase data model are retained. Run a Netlify deploy preview before production; confirm Turnstile hostname and matching Supabase secret first.

### v23
Adds the Discography page (drafts, edit and resubmit, per-release stats the label enters), neutral artist-facing status wording and a reliability pass. See CHANGELOG.md. Run the v23 section of QA-CHECKLIST.md on a Netlify deploy preview before promoting.

