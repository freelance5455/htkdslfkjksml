# Aura Player

**Tu música, tu atmósfera.** Un reproductor de música 100 % local: sin cuentas,
sin anuncios, sin backend y sin conexión. El fondo y los colores de la
interfaz cambian solos según la canción que suena — cada tema crea su propio
"aura".

- **Privado por diseño**: tu música nunca sale del teléfono. No hay servidores,
  ni analítica, ni rastreadores.
- **Progresivo (PWA)**: se puede instalar como app desde Chrome y funciona
  sin internet (caché propia + librerías incluidas en el proyecto).
- **Sin dependencias de framework**: HTML + CSS + JavaScript puro.

---

## Tabla de contenidos

1. [Características](#características)
2. [Estructura del proyecto](#estructura-del-proyecto)
3. [Cómo se carga tu música (importante)](#cómo-se-carga-tu-música-importante)
4. [Cómo probarlo en tu teléfono (sin computadora)](#cómo-probarlo-en-tu-teléfono-sin-computadora)
5. [Instalarlo como app (PWA)](#instalarlo-como-app-pwa)
6. [Empaquetar el APK (HTML & ZIP File to APK Builder)](#empaquetar-el-apk-html--zip-file-to-apk-builder)
7. [Limitaciones conocidas y mitigación](#limitaciones-conocidas-y-mitigación)
8. [Motor de fondos: cómo elige el color cada canción](#motor-de-fondos-cómo-elige-el-color-cada-canción)
9. [Atajos de teclado y gestos](#atajos-de-teclado-y-gestos)
10. [Solución de problemas](#solución-de-problemas)
11. [Privacidad](#privacidad)
12. [Créditos y licencias](#créditos-y-licencias)

---

## Características

| Área | Qué hace |
| --- | --- |
| Biblioteca | Carga una **carpeta completa** (memoria interna o SD) con sus subcarpetas, o archivos sueltos |
| Metadatos | Título, artista, álbum y género desde etiquetas ID3v1/ID3v2, MP4 y FLAC (jsmediatags) |
| Fondos dinámicos | 5 niveles de prioridad: portada → carpeta → género → artista → neutro (ver abajo) |
| Reproducción | Aleatorio (sin repeticiones), repetición (ninguna/todas/una), volumen, retomar donde quedaste |
| Notificación | Controles en la barra de notificaciones de Android (Media Session API) |
| Biblioteca grande | Lista paginada (80 filas por lote), metadatos con concurrencia máxima de 5, miniaturas 300×300 |
| Interfaz | Glassmorphism, modo automático/claro/oscuro, mini reproductor, reproductor a pantalla completa, swipe en la portada |
| Accesibilidad | Roles ARIA, navegación por teclado, `prefers-reduced-motion`, textos alternativos |
| Persistencia | Última canción y posición, volumen, modo de color, orden — en `localStorage` |
| Formatos | MP3, M4A/AAC, OGG/OGA, OPUS, WAV, FLAC, WebM-audio (según códecs del navegador) |

## Estructura del proyecto

```
aura-player/
├── index.html              Punto de entrada (pantallas, reproductor, sprite SVG)
├── styles.css              Estilo glassmorphism, fondos animados, claro/oscuro
├── app.js                  Toda la lógica (temas, biblioteca, reproducción, UI)
├── sw.js                   Service Worker: caché offline de la app
├── manifest.webmanifest    Manifiesto PWA (instalable en pantalla de inicio)
├── icons/
│   ├── icon-192.png        Icono 192×192
│   └── icon-512.png        Icono 512×512 (también maskable)
├── vendor/
│   ├── jsmediatags.min.js  Lector de etiquetas (MIT) — copia local
│   └── color-thief.umd.js  Extractor de paleta (MIT) — copia local
└── README.md               Este archivo
```

Las librerías van **incluidas en el proyecto** para que todo funcione sin
internet. Si por algún motivo faltaran, `app.js` intenta cargarlas desde CDN
(jsdelivr) y, si tampoco puede, la app sigue funcionando (solo se pierden las
etiquetas y la paleta de la portada: el fondo saldrá del nombre de la carpeta,
del género o del artista).

---

## Cómo se carga tu música (importante)

Aura Player es una app web y, por seguridad, **los navegadores no permiten
escanear todo el dispositivo en silencio** — ni siquiera Spotify web lo hace.
Por eso la app usa una **cadena de 3 mecanismos**, el mejor disponible en tu
navegador se muestra primero:

### Nivel A — Carpeta permanente (File System Access API)
- Dónde existe: **Chrome/Edge de escritorio** (Chrome 86+).
- Flujo: eliges la carpeta **una sola vez**; queda guardada (IndexedDB) y la
  biblioteca **se relee sola** en cada apertura. Si el sistema notifica
  cambios (FileSystemObserver, experimental), se refresca en vivo.
- "Se actualiza sola": **sí, totalmente.**

### Nivel B — Elegir carpeta por sesión (`webkitdirectory`)
- Dónde existe: **Chrome Android (desde v18), Samsung Internet, Firefox,
  Safari** — es el mecanismo que usarás en el teléfono.
- Flujo: tocas "Elegir mi carpeta de música" → el selector del sistema
  muestra **memoria interna y tarjeta SD** → eliges tu carpeta de música
  (p. ej. `Music`) → se leen todas las subcarpetas.
- Límite del navegador: al cerrar la app/pestaña, el permiso **caduca**
  (nadie puede evitarlo: los `File` de un `<input>` solo viven en esa página).
  Al volver a abrirla, vuelves a elegir la carpeta con **un toque** y la
  biblioteca aparece completa, incluidas las canciones nuevas.
- "Se actualiza sola": al reabrir eliges la carpeta con un toque; mientras
  la app esté abierta, todo queda en memoria (incluso si cambias de app).

### Nivel C — Archivos sueltos (`<input type="file">`)
- Funciona en cualquier navegador. Útil para elegir algunas canciones.

### Recomendación de organización

```
Music/                  ← eliges esta carpeta (interna o SD)
├── Rock/
│   ├── 01 - Cancion.mp3
│   └── ...
├── Reggaeton/
├── Jazz/
└── LoFi/
```

- **Los nombres de las carpetas alimentan los colores**: "Rock" pinta rojos,
  "LoFi" pasteles, "Reggaeton" naranjas… (si la canción no tiene portada).
- Canciones con portada de álbum usan los colores de esa portada.
- Al añadir música nueva al teléfono, vuelve a elegir la carpeta (o usa el
  botón ↻ **Actualizar**) y verás un aviso tipo "Biblioteca actualizada:
  +3 nuevas".

### Soporte verificado (MDN browser-compat-data, nov. 2026)

| Función | Chrome Android | Chrome escritorio | Firefox | Samsung Internet |
| --- | --- | --- | --- | --- |
| Elegir carpeta (`webkitdirectory`) | ✅ v18+ | ✅ | ✅ 50+ | ✅ |
| Carpeta permanente (`showDirectoryPicker`) | ❌ | ✅ 86+ | ❌ | ❌ |
| Controles en notificación (Media Session) | ✅ | parcial | ✅ | ✅ |
| Instalar PWA (Service Worker) | ✅ | ✅ | ✅ | ✅ |

> La app detecta todo esto sola: muestra "Conectar carpeta permanente"
> únicamente donde existe la API.

---

## Cómo probarlo en tu teléfono (sin computadora)

### Opción 1 — GitHub Pages (recomendada)

1. Crea una cuenta gratis en [github.com](https://github.com) (solo la primera vez).
2. Toca **New repository** → nombre `aura-player` → **Public** → Create.
3. En el repositorio: **Add file → Upload files** → sube **todos los archivos
   del ZIP** (importante: `index.html` debe quedar en la raíz, no dentro de
   una subcarpeta; sube el contenido, no el ZIP).
4. **Settings → Pages** → Source: **Deploy from a branch** → Branch:
   `main` / `(root)` → Save.
5. Espera 1–2 min y abre `https://TU_USUARIO.github.io/aura-player/`.
6. Guárdala en favoritos o "Añadir a pantalla de inicio" (ver abajo).

Necesitas internet solo para este paso inicial; después el Service Worker
guarda la app y abre sin conexión.

### Opción 2 — Servidor local en el teléfono

1. Instala desde Play Store un servidor HTTP (p. ej. **"Simple HTTP Server"**
   o similar que permita servir una carpeta).
2. Copia la carpeta `aura-player` a `Descargas` o `Documents`.
3. En la app de servidor, elige esa carpeta y pulsa **Start** (puerto 8080).
4. Abre Chrome en `http://localhost:8080/`.

### Opción 3 — Abrir el archivo directo (`file://…/index.html`)

Funciona para probar rápido desde un gestor de archivos, **pero**:
- No hay Service Worker (no se "instala", no hay caché offline).
- Las librerías locales sí cargan (son scripts clásicos), así que las
  etiquetas y los colores de portada funcionan igual.
- Algunas funciones del navegador (instalación PWA) no existen en `file://`.

---

## Instalarlo como app (PWA)

En Chrome Android, con la página abierta desde **https://** (Opción 1):

1. Menú ⋮ → **"Añadir a pantalla de inicio"** / **"Instalar aplicación"**.
2. Se abre en pantalla completa, con su icono y sin barra de navegador.
3. Con la app instalada, el permiso de carpeta permanente (donde exista)
   se conserva entre sesiones con más facilidad.

---

## Empaquetar el APK (HTML & ZIP File to APK Builder)

Esta app de Play Store envuelve tu proyecto en un **WebView** y genera un APK
**sin computadora**. Pasos:

### Preparar el ZIP

1. El ZIP debe contener **`index.html` en la raíz** y toda la estructura:
   `styles.css`, `app.js`, `sw.js`, `manifest.webmanifest`, `icons/`,
   `vendor/`. (Este proyecto ya entrega `AuraPlayer-v1.0.zip` listo.)
2. No importa el nombre del ZIP; lo que importa es la estructura interna.

### Construir el APK

1. Instala **"HTML & ZIP File to APK Builder"** (SoftSpring) en Play Store.
2. Abre la app → elige **ZIP** → selecciona `AuraPlayer-v1.0.zip`.
3. Configura:
   - App name: `Aura Player`
   - Package name: algo único, p. ej. `com.tunombre.auraplayer`
   - Version: `1.0`
   - Icono: usa `icons/icon-512.png`
4. Toca **Build/Convert** y espera el APK terminado.
5. Instala el APK: al abrirlo, Android pedirá permitir **"instalar apps
   desconocidas"** para esa app → activa el permiso → Instalar.
6. Abre Aura Player desde el cajón de apps.

### Advertencias del WebView (léelas antes de decidir)

Un WebView **no es un Chrome completo**. Qué esperar:

| Función | En el APK (WebView) | En Chrome/PWA |
| --- | --- | --- |
| Reproducción, fondos dinámicos, lista | ✅ | ✅ |
| Librerías (van incluidas en el ZIP) | ✅ sin internet | ✅ |
| Service Worker / instalación | ❌ (file:// no lo soporta) | ✅ |
| Controles en la barra de notificaciones | ⚠️ puede no aparecer | ✅ |
| Selector de carpeta (`webkitdirectory`) | ⚠️ depende del constructor | ✅ |
| Reproducción con pantalla apagada | ⚠️ inestable | ✅ con notificación activa |

**Recomendación**: usa el APK como curiosidad o para regalar la app, pero la
experiencia completa (notificación, instalación, actualizaciones de carpeta)
está en **Chrome + "Añadir a pantalla de inicio"**. Si en el APK el botón
"Elegir mi carpeta" no abre nada, usa "Elegir archivos sueltos": ese selector
casi siempre está implementado en los constructores.

---

## Limitaciones conocidas y mitigación

1. **El navegador no recuerda la carpeta en Android** (nivel B): el permiso
   caduca al cerrar. *Mitigación*: un toque para reconectar + botón ↻; en
   escritorio (nivel A) sí es permanente.
2. **Reproducción en segundo plano**: Chrome Android continúa la música con
   la notificación de medios mientras no cierres la app del todo; si el
   sistema la mata, se pausa. *Mitigación*: mantén la PWA instalada y evita
   limpiarla de "recientes".
3. **Códecs**: Chrome Android reproduce MP3, M4A, OGG, OPUS, WAV, FLAC; si
   un archivo falla, la app lo anuncia y salta a la siguiente (máx. 5 seguidas).
4. **Portadas gigantes**: se reducen a miniaturas 300×300 en segundo plano.
5. **Bibliotecas enormes** (1000+): la lista se pinta por lotes y los
   metadatos se leen de 5 en 5; la primera carga puede tardar unos segundos.
6. **Modo privado**: si `localStorage` está bloqueado, los ajustes no se
   guardan (la app avisa indirectamente al no recordar nada).
7. **`showDirectoryPicker` en Android**: no existe hoy; el código lo detecta
   y, si Google lo activa en el futuro, la app lo usará sin cambios.

---

## Motor de fondos: cómo elige el color cada canción

`getThemeForSong(song)` aplica **la primera regla que cumpla**:

1. **Portada del álbum** → ColorThief saca 3 colores dominantes → degradado
   animado. El color de acento de la interfaz (botones, ecualizador) es el
   color más vivo de la paleta.
2. **Nombre de la carpeta** → palabras clave (español e inglés, sin tildes):

   | Carpeta contiene | Colores |
   | --- | --- |
   | Rock, Metal, Punk, Grunge, Indie | rojo / naranja / negro |
   | Chill, Relax, LoFi, Ambient | azul / verde / pastel |
   | Electrónica, EDM, Techno, House, Trance, Dubstep | púrpura / magenta / cian neón |
   | Pop, K-Pop | rosa / amarillo |
   | Clásica, Ópera, Soundtrack | marrón / dorado / beige |
   | Jazz, Blues, Bossa, Soul | azul profundo / ámbar |
   | Hip Hop, Rap, Trap | gris / dorado |
   | Latina, Salsa, Reggaetón, Cumbia, Bachata, Merengue, Vallenato | naranja / rojo / amarillo |

3. **Género ID3** → misma tabla.
4. **Artista** → hash del nombre → color HSL **determinista** (el mismo
   artista siempre produce el mismo tono).
5. **Neutro** → gris azulado con acento azul.

La transición dura 1,5 s (fundido cruzado entre dos capas) y el degradado se
mueve lentamente (10 s por ciclo). Con `prefers-reduced-motion` activado, la
animación se desactiva.

---

## Atajos de teclado y gestos

| Acción | Teclado / gesto |
| --- | --- |
| Reproducir / pausar | `Espacio` |
| ±10 s | `←` / `→` |
| Anterior / siguiente | `Shift+←` / `Shift+→` |
| Volumen | `↑` / `↓` |
| Silencio | `M` |
| Aleatorio / repetición | `S` / `R` |
| Reproductor completo | `F` (cerrar: `Esc`) |
| Cambiar canción (móvil) | deslizar la portada hacia los lados |

---

## Solución de problemas

- **"No se encontró música compatible"** → revisa que la carpeta tenga
  archivos MP3/M4A/OGG/OPUS/WAV/FLAC y que no estén dentro de carpetas
  ocultas o de `Android/` (se omiten a propósito).
- **Los títulos salen como el nombre del archivo** → el archivo no tiene
  etiquetas ID3; la app limpia "01 - " del nombre automáticamente.
- **No aparecen los colores de la portada** → el archivo no tiene portada
  incrustada o ColorThief no está disponible; se usará carpeta/género/artista.
- **La música se detiene al apagar la pantalla** → en Android, desliza la
  notificación de medios hacia abajo y dale a reproducir, o desactiva la
  optimización de batería para Chrome.
- **Quiero re-leer la carpeta** → botón ↻ junto al nombre de la carpeta
  (en escritorio con carpeta permanente ni hace falta: es automático).

---

## Privacidad

- **Cero permisos de Android**, cero acceso a red para reproducir música.
- Los archivos se leen **en tu dispositivo** con File API; nunca se suben.
- Únicos almacenamientos locales: `localStorage` (ajustes) e IndexedDB (solo
  para recordar la carpeta permanente, donde existe la API).
- Sin analítica, sin cookies, sin huellas. El código es auditable: son 4
  archivos.

---

## Créditos y licencias

- **[jsmediatags](https://github.com/aadsm/jsmediatags)** (MIT) — lectura de
  etiquetas ID3v1/ID3v2, MP4 y FLAC. Copia local en `vendor/`.
- **[ColorThief](https://github.com/lokesh/color-thief)** (MIT) — extracción
  de paleta de colores de la portada. Copia local en `vendor/`.
- Iconos de interfaz: SVG propios dibujados a mano (libre uso).
- Datos de compatibilidad de navegadores: [MDN browser-compat-data](https://github.com/mdn/browser-compat-data)
  (CC0), consultados en noviembre de 2026.

Aura Player se entrega tal cual, sin garantía. Haz con él lo que quieras.
