# Catatan Keuangan (Versi Web)

Versi HTML dari aplikasi pencatat keuangan — satu file, bisa langsung dibuka
di browser atau di-zip untuk tool "Situs ter-zip" / pengubah situs-ke-APK
lain, karena `index.html` sudah ada di root.

## Cara Pakai

1. Buka `index.html` langsung di browser, **atau**
2. Zip folder ini (pastikan `index.html` ada di root zip, bukan di dalam
   subfolder) lalu upload ke tool "Situs ter-zip" Anda.

## Fitur

- Catat pemasukan/pengeluaran + kategori
- Data tersimpan otomatis di perangkat (localStorage) — tidak hilang saat
  aplikasi ditutup
- Ganti tema terang/gelap (ikon ◐ di pojok kanan atas)
- **Analisis AI**: tap kartu "✨ Analisis AI" untuk ringkasan pola
  pengeluaran & saran hemat

## Mengaktifkan Fitur AI

1. Tap ikon ⚙︎ di pojok kanan atas.
2. Masukkan API key Anthropic Anda (dapatkan di console.anthropic.com).
3. Key disimpan hanya di perangkat ini, dikirim langsung ke Anthropic saat
   Anda minta analisis — tidak lewat server lain.

**Catatan**: karena API key dimasukkan langsung dari browser, siapa pun yang
membuka pengaturan di perangkat yang sama bisa melihatnya. Cocok untuk
pemakaian pribadi; kalau aplikasi ini akan dibagikan ke banyak orang,
sebaiknya pakai backend sendiri untuk menyembunyikan key.
