# NEON Windows 11 Launcher — v1 prototype

Questo progetto contiene una prima interfaccia ispirata a Windows 11 e due workflow GitHub Actions per tentare la compilazione remota di un APK Android e di un installer EXE Windows.

## Prima prova senza installare strumenti sul tablet

1. Scarica ed estrai `NEON_Windows_11_Launcher_v2.zip`.
2. Apri `www/index.html` nel browser per provare la demo.
3. Per ottenere i pacchetti installabili, carica il contenuto della cartella del progetto in un repository GitHub.

## Caricare il progetto su GitHub

1. Accedi a GitHub e crea un repository nuovo, per esempio `neon-windows-11`.
2. Seleziona **Add file > Upload files**.
3. Carica tutti i file e le cartelle estratte, inclusa la cartella nascosta `.github` con i due workflow.
4. Conferma con **Commit changes** sul ramo `main`.
5. Apri la scheda **Actions** del repository. Se compare una richiesta di abilitare le Actions, abilitala.
6. Avvia **Build Android APK** e **Build Windows EXE** con **Run workflow** se non partono automaticamente dopo il commit.
7. Apri l'esecuzione completata e cerca la sezione **Artifacts** in fondo alla pagina.
8. Scarica `NEON-Windows-11-APK` per Android o `NEON-Windows-11-EXE` per Windows. Gli artifact sono ZIP da estrarre; l'APK debug è destinato ai test.

## Importante

- Questo è codice sorgente con workflow di compilazione: non include APK o EXE già compilati.
- La prima compilazione potrebbe fallire se il progetto necessita di aggiustamenti alle versioni degli strumenti o alle dipendenze. In tal caso apri il log dell'esecuzione rossa e correggiamo l'errore.
- L'APK prodotto dal workflow è un APK **debug** per test, non una release firmata per la pubblicazione sul Play Store.
- Il progetto non è un sistema operativo e non può "consentire tutto": Android e Windows limitano accesso ai file, impostazioni e funzioni di sistema per sicurezza.
- Per usare NEON come launcher Android predefinito bisogna aggiungere una vera integrazione nativa con il ruolo HOME e testarla sul dispositivo.
- I collegamenti Microsoft 365 aprono servizi web. Office 2024 desktop non è incluso e richiede installazione/licenza separate.
- Non pubblicare credenziali, password o chiavi di firma nel repository.

## Compilazione locale

Windows EXE:
1. Installa Node.js LTS.
2. Apri un terminale nella cartella del progetto.
3. Esegui `npm install`.
4. Esegui `npm run build:win`.
5. L'installer viene creato nella cartella `dist`.

Android APK:
1. Installa Node.js e Android Studio con Android SDK.
2. Esegui `npm install`.
3. Esegui `npx cap add android`.
4. Esegui `npx cap sync android`.
5. Esegui `npx cap open android`.
6. In Android Studio usa **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
