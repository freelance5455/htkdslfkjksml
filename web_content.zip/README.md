# AS Enterprises (v2)
Offline stock / sales / labour / wastage / expense / finance app. Data in phone localStorage (key AS_ENTERPRISES_V2); old V1 data is auto-migrated and never deleted.

## Quick use (no build)
Host the `www` folder (or open `www/index.html`) in Chrome on Android -> menu -> Add to Home screen.

## Build APK (Capacitor; needs Node 18+, Android Studio/JDK 17)
    npm install
    npm test                 # accounting regressions + source integration checks
    npx cap add android
    npx cap sync android
    npx cap open android      # Build > Build APK(s)
Or: cd android && ./gradlew assembleDebug  -> android/app/build/outputs/apk/debug/app-debug.apk

## Rules
Available = Opening + Added - DirectSold - LabourTaken + Returned - StandaloneWastage (labour sold & wastage are inside "taken").
Labour Total = sum(sold x rate) - (wastage qty x wastage rate); Net = Labour Total + Morning - Cash - Online (plus = receivable, minus = credit).
Cash Balance (dashboard) = today's Final Benefit: Sale + Previous + Labour Credit - Labour Receivable - Labour Wastage - Expenses - Finance - Loan - School - Own Purchase paid + Bank credit - Bank debit. Labour cash/online are not added separately.
Previous: first day typed by user (editable/deletable); every later day = previous day Final Benefit. Finance & Loan have Credit (+) / Debit (-, default).

## Login / Cloud sync (new phone me data)
App > "Login / Sync" tab: Email+Password (recommended, works in APK too) or Google. After login every change auto-saves to Firestore doc `as_enterprises/{uid}`; on a new phone just login and data is loaded.
One-time Firebase Console setup (project rrprohub):
1. Authentication > Sign-in method: enable **Email/Password** (and Google if wanted).
2. Authentication > Settings > Authorized domains: add the domain where `www` is hosted.
3. Firestore Database: create it, then Rules:

    rules_version = '2';
    service cloud.firestore {
      match /databases/{db}/documents {
        match /as_enterprises/{uid} { allow read, write: if request.auth != null && request.auth.uid == uid; }
      }
    }
Without login the app works fully offline; Backup tab export/restore also moves data between phones.

## Kadhai
Tab "Kadhai": items created there (or via Labour entry type "Kadhai") have `cat:'kadhai'` -> separate stock list; sales (direct + labour) are included in Today Sale / Total Sale. Labour accounts are shared (one hisaab per labour).
Dashboard: Total Sale = Previous Date Gross Sale + Today Sale (gross, wastage not subtracted). Previous Date Gross Sale is the actual direct + labour sale on the prior calendar date, not the carried Final Balance. The notebook Final Benefit separately carries forward the prior Final Balance. Previous sale does not affect stock. Labour Cash Received / Online Payment are display-only (grey box, not connected to anything). Labour "Credit" is now called "Extra Money".
Labour entry: Returned qty is automatic = Taken - Sold - Wastage Qty (spread over lines in order). Dashboard has "Aaj ka Hisaab" notebook card (item x rate = amount, Total Sale, Previous, Extra Money, Receivable, Wastage, expenses, finance, loan, purchase, school, bank, FINAL) with date picker.
Labour list/notebook columns: Sold ₹, Wastage −, Morning +, Actual ₹ (= Sold − Wastage + Morning), Total Amount diya (cash+online), Receivable (if less), Extra Money (if more).
Labour list/notebook columns: Sold ₹ | Wastage − | Morning + | Actual ₹ (= Sold − Wastage + Morning) | Total Amount diya (Cash+Online) | Receivable | Extra Money. Full end-to-end test: tests/full.js
Purchase ledger: standalone Wastage (qty x rate) is minus from the same item's Own Purchase (oldest first): Net = Qty x Rate + Freight - Wastage; Remaining = Net - Paid (auto). Dashboard "Own Purchase Paid" is reduced by that wastage (never below 0). Own Sale rate rows and Purchase rows have Edit. Tests: tests/edits.js

## V18 additions
Dashboard "Group-wise" card: Chair / Stand / Kadhai / Palta (brands mixed) - Subah gaya, Bika, Sale (date + total), Stock; Total Sale includes Kadhai+Palta, Total Stock = Chair+Stand only. Item group is guessed from name (chair/kursi, stand, kadhai, palta) or set manually via "Item ka group badlo".
Own Profit: Kiraya/pc = total freight / total qty of that item's purchases, auto-added to cost per piece; Group-wise Own Profit card; "Purchase Payment (sirf paisa)" quick entry (purchasePayments) feeds Own Purchase Paid + Final Benefit.


## V34 additions
- Own Sale screen includes a separate item/rate-wise sale breakdown, so different Palta selling rates appear on separate lines.
- Edit an item and set its Short form and/or comma-separated aliases. Typing a saved alias in sale, stock, wastage, or labour entry resolves to the full existing item name (leave Brand blank when using the alias).


## V50 AI / Photo / Account Fixes
- Migrated old saved Gemini model IDs such as `gemini-2.5-flash` and `gemini-3.7-flash` to `gemini-3.8-flash` without touching accounting data. Both AI Madad and Photo Auto Entry use the current saved model; requests no longer send the obsolete sampling parameter, and the API key is sent via the `x-goog-api-key` header rather than the URL query string.
- AI Madad now receives real app context: previous carried balance, current sales/final balance, item/brand stock, labour ledgers, receivables/Extra Money and recent entries. It supports additional confirmed actions for Labour Jama, Wastage, Finance, Loan, Bank, Purchase Payment, Own Purchase, School and Factory. Entries remain preview-first; the AI never executes a deletion.
- Photo capture first tries the Capacitor Camera plugin, then falls back to an Android file input with `capture="environment"` so the device camera/chooser can handle capture instead of relying on WebView `getUserMedia` permission. Gallery remains separate. A preview is shown and AI-read entries require manual review and Save; the photo reader no longer auto-saves a fully matched result.
- Labour Extra now has a searchable labour-name list. Tapping a name opens its complete balance summary and date-wise ledger, with item details, sold value, wastage, morning cash, cash/online payments, daily difference and running balance.
- Previous-balance carry-forward now includes days on which the only financial record is a Purchase Payment. Date strings are normalized consistently.
- Previous Sale is now separate from carried Final Balance: Dashboard Previous Sale uses the prior calendar date gross direct + labour sale; Total Sale adds that gross sale to today only once. Notebook Final Benefit continues using the prior carried Final Benefit. Opening `firstPrev` remains intact as a starting-value fallback where no earlier dated sales/labour records exist. Previous Sale never changes stock.
- AI Madad and Photo Auto Entry both use the Gemini Interactions REST endpoint with `gemini-3.8-flash` by default and structured JSON output (`store:false`). Old retired model names saved in settings are migrated without clearing business records.
- The app storage key (`AS_ENTERPRISES_V2`), schema and existing records have not been reset or replaced. No data is shipped in the code patch.

### Camera on a Capacitor Android build
The Capacitor Camera plugin is included as a project dependency. From this project folder run:

    npm install
    npm test                 # accounting regressions + source integration checks
    npx cap add android        # only if android/ does not exist yet
    npx cap sync android
    npx cap open android

Build a new APK after syncing; an already-installed APK does not gain newly added native plugins automatically. When using a third-party HTML-to-APK builder instead, enable its camera permission and Android file chooser / `onShowFileChooser` support. Android WebView does not open file-input choosers unless the wrapper handles that callback; this is a builder-side requirement, not something HTML alone can override. The in-app `capture="environment"` fallback needs the builder to correctly forward file inputs to Android's camera chooser.

### Gemini API note
The model default is `gemini-3.8-flash` to resolve the screenshot's retired-for-new-users model error. Requests use the current Interactions API endpoint and are stateless (`store:false`). Gemini API access, available models and possible billing depend on the Google AI Studio project/key. The key is stored on the phone for this personal-app setup; a public distributed app should call Gemini through a server-side proxy because a key stored inside an APK or browser storage cannot be kept truly secret.
