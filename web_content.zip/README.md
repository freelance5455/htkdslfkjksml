# FitTrack Weight Loss — Android-friendly prototype

## Included
- Daily food logging with editable calorie estimates and quick-add presets
- Daily calorie goal (default 2,000 kcal)
- Weight entries and target tracking (79 kg to 70.5 kg)
- Walking minutes and a 30-minute goal
- 7-day food/walking snapshot
- Local backup export/import
- Optional browser notification permission prompt
- PWA manifest, service worker and app icons

## Run it
A Progressive Web App needs to be served from HTTPS (or localhost). Opening `index.html` directly from a file manager will show the tracker, but install/offline features generally won't work.

Simplest test:
1. Upload this folder to a static HTTPS host you control (for example, a static site host).
2. Open the HTTPS URL in Chrome on Android.
3. Use Chrome menu → **Install app** or **Add to Home screen**.

## Important limitations
- This is a web-based installable prototype, not a signed Android APK and not published to Google Play.
- To create an APK, this project must be wrapped/built with Android tooling (e.g. Capacitor/Android Studio) and signed. That build is not included here.
- Food calorie values are estimates; the app does not scan food or connect to a nutrition database.
- Data is stored only in the browser on that device. Export a backup before clearing browser data or changing devices.
- Browser notifications/background reminders are not guaranteed on all Android devices. Reliable scheduled reminders need native Android scheduling or a suitable push-notification setup.
- The starting weigh-in shown is 79 kg dated 23 Oct 2026 based on the user's reported reading; edit/delete it if incorrect.
- This app is for general wellness tracking, not medical diagnosis or treatment.
