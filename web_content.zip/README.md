# Taiwan Mandarin Dictionary V3.0 (Android project)

An offline-first learning app for Taiwan Mandarin using Traditional Chinese.

## Included
- 387+ dictionary entries (English, Traditional Chinese, Pinyin, Zhuyin where available, and Tagalog)
- 60+ practical conversation phrases, including Taiwan daily life, work, shopping, parcels, food, and motorcycle repair
- Search across English, Chinese, Pinyin, Zhuyin, and Tagalog
- Category filters and favorites
- Taiwan Mandarin voice playback (uses the Android device's zh-TW text-to-speech voice, if installed)
- Random vocabulary quiz
- Offline data bundled in the app

## Build an APK on your Android phone
1. Install AndroidIDE from its official source / Play Store if available for your device.
2. Extract this ZIP.
3. Open the extracted project folder in AndroidIDE.
4. Allow Gradle sync and download required build components (internet is needed for the first build).
5. Choose **Build > Assemble Debug**.
6. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.
7. Install the APK. If Android asks, allow installation from that source.

## Important
This ZIP is the Android Studio/AndroidIDE project source, not a precompiled APK. It is a large practical starter dictionary, not literally every word in Mandarin. Pinyin and Zhuyin are provided for the curated entries; a dash means Zhuyin is not supplied. Taiwan speakers may use colloquial terms that differ by region or context.
