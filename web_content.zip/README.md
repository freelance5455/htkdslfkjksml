# NEXUS CONVERTER STUDIO ULTRA

Projeto inicial funcional dividido em frontend web e backend de compilação Android.

## O que funciona no frontend
- Importação de arquivos e pastas (suporte depende do navegador).
- Explorador, remoção de arquivos e armazenamento local básico.
- Criar e extrair ZIP com JSZip.
- Gerar HTML único (CSS/JS locais referenciados por caminhos relativos).
- Editor CodeMirror, salvamento na sessão e prévia HTML.
- Análise básica, minificação de HTML/CSS/JS em ZIP.
- Histórico de operações da sessão.
- Envio de projeto ZIP ao backend para solicitar APK real.

## Limitações honestas
- RAR e 7Z não estão implementados. São formatos que exigem ferramentas/bibliotecas específicas.
- TAR/GZIP ainda não estão implementados.
- A incorporação para HTML único cobre referências locais simples; não reescreve todos os casos de CSS, módulos JS, fontes ou URLs dinâmicas.
- O frontend não compila APK sozinho. A compilação exige servidor com Java 17, Gradle, Android SDK e licenças aceitas.
- O APK gerado pelo modelo incluído é um APK **debug**, sem assinatura de distribuição/Play Store. Ícone adaptativo, tela inicial nativa, preferências completas de status/navigation bar e permissões sob demanda ainda precisam ser adicionados ao template Android.
- Use apenas projetos e bibliotecas confiáveis. O conteúdo importado será empacotado como assets; não é executado pelo backend.

## Executar frontend
Abra `frontend/index.html` em um navegador moderno. Para melhor compatibilidade com módulos/arquivos locais, rode um servidor estático na pasta `frontend`, por exemplo:

```bash
python -m http.server 8080
```

Acesse `http://localhost:8080`.

## Executar backend local
Requisitos:
- Node.js 20+
- Java JDK 17
- Gradle 8.9 ou compatível
- Android SDK com platform 35 e build-tools 35.0.0

```bash
cd backend
npm install
cp .env.example .env
```

Defina uma chave longa em `NEXUS_API_KEY`, configure `ALLOWED_ORIGIN` para a origem do frontend e carregue as variáveis de ambiente. Depois:

```bash
npm start
```

No frontend, configure a URL do backend e informe a mesma chave de API. Para desenvolvimento local, `http://localhost:8787` é a URL padrão.

## Backend em Docker
O Dockerfile instala Java/Gradle e Android command-line tools. Revise e atualize versões de SDK/build-tools conforme necessário antes de usar em produção:

```bash
cd backend
docker build -t nexus-build .
docker run --rm -p 8787:8787 \
  -e NEXUS_API_KEY='uma-chave-forte' \
  -e ALLOWED_ORIGIN='http://localhost:8080' \
  nexus-build
```

## Segurança antes de publicar
- Hospede o backend somente em infraestrutura sob seu controle, com HTTPS.
- Não exponha a chave de API em um site público: neste protótipo, ela é digitada pelo usuário no cliente, portanto qualquer usuário com acesso ao navegador pode inspecioná-la. Para produção, implemente autenticação por usuário e tokens curtos emitidos por um servidor de sessão.
- Restrinja CORS, limite taxa/tamanho, use isolamento de build e cotas por usuário.
- Considere builds em contêineres efêmeros sem acesso a segredos e sem privilégios.
- Não use o servidor como serviço público aberto de compilação.

## Estrutura
- `frontend/`: interface HTML/CSS/JS.
- `backend/server.js`: API de build.
- `backend/android-template/`: projeto Gradle Android WebView usado para gerar APK.
