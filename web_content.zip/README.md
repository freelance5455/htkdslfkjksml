# MAVRAD — Android ilova uchun boshlang‘ich loyiha

## Ichida
- `www/index.html` — ishlaydigan mobil do‘kon prototipi
- `package.json` — Capacitor sozlamalari
- `capacitor.config.json` — ilova nomi va identifikatori

## Hozir ishlaydigan imkoniyatlar
- Mahsulotlar katalogi va qidiruv
- Kategoriyalar
- Savatchaga qo‘shish, sonini o‘zgartirish va o‘chirish
- Jami narxni hisoblash
- Ism va telefon bilan demo buyurtma
- Savatcha va demo buyurtmalarni qurilma xotirasida saqlash

## Muhim
Bu hozircha demo do‘kon. Buyurtmalar operatorga yoki serverga yuborilmaydi, haqiqiy to‘lov ham ulanmagan. Haqiqiy savdo uchun mahsulotlaringiz, aloqa raqami, yetkazib berish qoidalari va buyurtmalarni qabul qiladigan backend/API kerak bo‘ladi.

## APK yig‘ish
Kompyuterda Node.js va Android Studio o‘rnatilgan bo‘lishi kerak. Loyiha papkasida:
1. `npm install`
2. `npx cap add android`
3. `npx cap sync android`
4. `npx cap open android`

Android Studio ochilgach, Build menyusidan APK yig‘ish mumkin. Android SDK va Gradle sozlamalari kompyuterda tayyor bo‘lishi kerak.

## APKni GitHub Actions orqali olish
1. ZIP faylni oching va ichidagi fayllarni yangi GitHub repository'ga yuklang.
2. Repository ichida **Actions** bo‘limini oching.
3. **Build MAVRAD APK** workflow'ini tanlab, **Run workflow** bosing.
4. Build tugagach, workflow sahifasidagi **Artifacts** bo‘limidan `MAVRAD-debug-APK` faylini yuklab oling va ZIP ichidan APKni ajrating.

Eslatma: bu debug APK sinov uchun. Play Store yoki ommaviy tarqatish uchun alohida release signing kaliti bilan imzolash kerak.
