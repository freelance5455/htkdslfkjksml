# Saraskana Block App

Android project for **Saraskana Block App**.

Main sections:
- Home
- News
- Government Schemes
- Festivals
- Emergency Contact
- Bus Information
- Photo Gallery
- Problem Report
- Map

## Build APK
Open this folder in Android Studio, let Gradle sync, then use **Build > Build APK(s)**.
