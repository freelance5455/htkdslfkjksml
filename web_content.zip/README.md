# UPLAY.IND

Offline-first media player. Dark, minimal, and local — your files stay on the device.

This environment serves a **web edition** of UPLAY.IND (browser preview). A native Android APK cannot be compiled or installed here (no Android SDK). The product maps the same architecture onto web platform APIs instead of inventing fake ExoPlayer controls.

## Architecture

```
UI (Compose analog: React + TanStack Router)
  Home / Library / Player / Browser / Downloads / Settings
        │
Stores (MVVM analog: Zustand)
  library-store  player-store  settings-store  download-store  browser-store
        │
Data
  IndexedDB  — media metadata, thumbs, download history, browser history
  localStorage — settings
  File registry — session File / Object URLs (never uploaded)
        │
Playback
  HTMLMediaElement + optional Web Audio equalizer
  Subtitles parsed in-app (SRT / VTT)
```

## What works

- Local video/audio via file and folder pickers
- Network playback of **direct** HTTP(S) media URLs
- Play / pause / seek / speed / fullscreen / PiP
- Double-tap seek, swipe seek, volume & brightness gestures, lock
- Resume position, favourites, continue watching
- SRT/VTT load, size / colour / position / delay
- Real 10-band equalizer, bass boost, stereo/mono, compressor limiter
- Library scan off the UI thread (chunked), search / sort / grid-list
- Rename / remove / share / save copy / open / file info (with confirmations)
- Sandboxed in-app browser (no camera/mic/location)
- Direct-URL download queue (refuses HTML pages and non-media URLs)

## Honest limits (not faked)

| Native Android ask | Web edition |
| --- | --- |
| Media3 HW / SW / HW+ decoder switch | Browser chooses the decoder. UI shows **Browser auto** and the real MIME/`canPlayType` result. |
| MediaStore / SAF file move | Relink, save-a-copy, share. Arbitrary filesystem moves are not available in a browser. |
| MKV / AVI playback | Only if **this** browser can decode them (usually no). Error explains conversion to MP4/WebM. |
| HLS `.m3u8` | Plays on Safari; refused elsewhere rather than shipping a silent fake. |
| DRM / YouTube / Hotstar grabbers | Not implemented. Direct media URLs only. |
| Background audio while leaving the player | Mini-player returns you to the player route. Tabs may throttle media; Media Session is registered while the player is open. |

## Privacy

No accounts, no analytics, no media upload. History is local and can be cleared in Settings.

## Develop

```
npm run dev        # preview
npm run typecheck
npm run build
```

Unit tests: `node --experimental-strip-types --test src/lib/subtitles.test.ts src/lib/utils.test.ts`
