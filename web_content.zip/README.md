# Zayro Gemini Studio
Interface Gemini avec bouton de navigation vers le studio Animés et gestionnaire de clés multiples.