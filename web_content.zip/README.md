# FocusFit AI: make the APK

Your app is in `www/index.html`. Two ways to get an APK.

## Option A: no installs (GitHub builds it for you)
1. Create a free GitHub account and a new empty repository.
2. Upload everything in this folder (keep the `.github` folder).
3. Open the repo's **Actions** tab, run **Build APK**, wait about 5 minutes.
4. Download `focusfit-apk` from the finished run, unzip, send `app-debug.apk` to your phone and open it (allow "install unknown apps").

## Option B: on your computer
1. Install Node 20+, JDK 17 and Android Studio.
2. In this folder run: `npm install`, `npx cap add android`, `npx cap sync android`.
3. `npx cap open android`, then Build > Build APK(s) in Android Studio.

## Before you publish to Google Play
- The debug APK is for testing. Play needs a signed release build (Android Studio: Build > Generate Signed Bundle).
- Accounts and data are stored on the phone only. Cloud sync and the AI Coach's live answers only work inside Claude. In the APK the Coach uses built-in safe answers until you add a backend (an API server that holds your AI key).
- Add a privacy policy page. FocusFit is used by teens, so state how data is stored and deleted.
- Changing the app: edit `www/index.html`, then sync and rebuild.
