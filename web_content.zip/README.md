# Kedrick AI Story-to-Video

## Run
1. Install Node.js 20+
2. Extract the ZIP.
3. Run `npm install`
4. Copy `.env.example` to `.env`
5. Put your real fal.ai key into `FAL_KEY`
6. Run `npm start`
7. Open `http://localhost:3000`

The backend keeps the API key off the Android frontend. The app uploads a character reference image, turns the story into scenes, generates image-to-video clips, and merges them into one MP4.

For Android, deploy this backend over HTTPS and point your WebView/Capacitor app to the deployed URL.

Video generation requires a provider account/credits. The supplied photo is included only as `sample-character-photo.jpg`.
