# Interior Designer Assistant - HTML/JS

This is a lightweight HTML/JavaScript hourly reminder app.

Features:
- Hourly interior-design work schedule
- Browser notification permission
- Task completion and daily progress
- Start/end reminder hour settings
- LocalStorage persistence
- Mobile-friendly UI

For ZIP-to-APK services, upload this ZIP as a web app/project.
Note: Web notifications depend on the APK wrapper/browser. A native Android app is more reliable for background notifications.
