# ساخت APK — مدیریت نیروها و کارکردها

پیش‌نیاز: Node.js 18+، JDK 17، Android Studio (همراه Android SDK)

```
npm install
npx cap add android
npx cap sync android
npx cap open android
```
در Android Studio: Build ▸ Build APK(s)
یا در ترمینال:
```
cd android
./gradlew assembleDebug
```
خروجی: android/app/build/outputs/apk/debug/app-debug.apk

## دسترسی‌ها
- اینترنت (INTERNET): به‌صورت خودکار توسط Capacitor اضافه می‌شود؛ برای ارسال بک‌آپ به تلگرام.
- ذخیره‌سازی: نیاز به مجوز جداگانه نیست. بک‌آپ/PDF/Excel از پنجرهٔ «اشتراک‌گذاری» اندروید ذخیره می‌شوند (Files، تلگرام، ...). بارگذاری بک‌آپ هم با انتخاب‌گر فایل سیستم انجام می‌شود.

## تلگرام
1. به ربات خود /start بفرستید.
2. در برنامه: تنظیمات ▸ «یافتن چت‌آیدی» و بعد «تست ارسال».
3. توکن را بعد از اتمام کار در BotFather با /revoke عوض کنید (توکن در چت منتشر شده است).
