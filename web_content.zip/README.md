# Voter Finder - Android app (offline + online) with Salesforce backend

How it works
- The roll (955 voters, EPIC IDs, addresses) is built into the app, so it works offline from the first launch.
- After login the app downloads every Voter__c from Salesforce and then only the records changed since the last sync.
  Records added or edited in Salesforce (by admins or other users) appear on every phone. Data is cached on the phone.
- Tag changes (TDP/YCP/NA) are queued locally and sent when online. Offline taps are kept and retried every 30 s while the app is open.
- If two users tag the same voter, the later timestamp wins (trigger VoterPartyGuard). Updated_By = Salesforce user id / device id.

## 1. Prerequisites
Salesforce CLI (sf), Android Studio Koala 2024.1.1 or newer, a Salesforce Developer Edition org.

## 2. Deploy the Salesforce data model
  sf org login web -a voterdev
  cd salesforce
  sf project deploy start -d force-app -o voterdev
Creates Voter__c (picklists Party, Section, Surname Group, Gender, Relation Type; address, EPIC, roll fields;
formula Full_Address__c), the tab, the trigger VoterPartyGuard and the permission set Voter_User.

## 3. Load the 955 voters
  cd ..
  sf data upsert bulk -s Voter__c -f data/voters.csv -i Voter_Key__c -o voterdev --wait 10
Check Setup > Object Manager > Voter, or the Voters tab: 955 records.

## 4. Create the External Client App (login for the phone)
Setup > "External Client App Manager" > New External Client App (wording of screens may differ by release):
- Name: Voter Finder. Contact email: yours.
- Enable OAuth. Callback URL: com.example.voterfinder://oauth
- Selected OAuth scopes: "Manage user data via APIs (api)" and "Perform requests at any time (refresh_token, offline_access)".
- Flow: enable Authorization Code with PKCE. Turn OFF "Require secret for Web Server Flow" and
  "Require secret for Refresh Token Flow".
- Save. Open the app's OAuth settings and copy the Consumer Key.
- In the app's policies, allow your users (all users, or admin-approved users with the Voter_User permission set).

## 5. Users
For every user: assign permission set Voter_User (Setup > Permission Sets > Voter User > Manage Assignments).
Their profile must allow API access (Voter_User includes the API Enabled permission).

## 6. Build and install the APK
- Android Studio > Open the android/ folder > let Gradle sync > Build > Build APK(s).
- Copy app/build/outputs/apk/debug/app-debug.apk to the phone, tap it, allow "install unknown apps".

## 7. Connect the app
- Open the app > tap "Salesforce".
- My Domain URL: Setup > My Domain, e.g. https://yourorg-dev-ed.my.salesforce.com
- Consumer Key from step 4. Log in on the browser page and approve. You return to the app and it syncs.
- Status line shows Synced / n pending. "Sync now" pushes every tag already on the phone.

## 8. Test
1. Tag a voter TDP; open the record in Salesforce: Party = TDP, Party Updated At and Updated By are filled; History shows the change.
2. Edit the voter's address or name in Salesforce; within ~30 s (or Sync now) it changes in the app.
3. Airplane mode: tag 3 voters, switch back on: status goes from "3 pending" to "Synced".
4. Log in as a second user on another phone: tags from the first user appear.

## Troubleshooting
- Login page error "redirect_uri mismatch": callback URL in step 4 must be exactly com.example.voterfinder://oauth.
- "invalid_grant": PKCE not enabled or secret still required (step 4).
- "INVALID_FIELD" / "INSUFFICIENT_ACCESS": assign Voter_User (step 5), redeploy step 2.
- "n records rejected": a picklist value outside the allowed list (Party, Section, Surname Group are restricted).
