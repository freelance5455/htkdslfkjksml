# Frases+

Aplicativo web/PWA responsivo em HTML, CSS e JavaScript.

## Recursos
- 30 frases motivacionais originais.
- Sorteio sem repetir a frase imediatamente.
- Narração usando a voz disponível no aparelho em português do Brasil.
- Favoritos persistentes com localStorage.
- Criação de frases próprias.
- Ativação/cancelamento da frase das 05:30.
- Contagem regressiva até 05:00.
- Notificação Web quando permitido pelo navegador.
- Manifesto PWA e ícone incluídos para futura instalação/conversão Android.

## Importante sobre 05:00
Uma página HTML comum não pode garantir uma notificação exata quando o navegador/app está totalmente fechado. Para a versão Android publicada como aplicativo, mantenha esta interface e adicione um serviço nativo de notificações (por exemplo, AlarmManager/WorkManager + Notification) ou push via FCM. A opção de ativar/cancelar já está organizada para essa integração.

## Como testar
Abra `index.html` em um servidor local/HTTPS para que recursos de PWA e notificações funcionem corretamente. Para transformar em APK/AAB, pode ser usado um wrapper Android/WebView ou uma solução PWA/Trusted Web Activity.


## Comportamento desejado no Android
A mensagem da manhã deve ser silenciosa e permanecer disponível até o usuário abrir o celular e dispensá-la. Para esse comportamento com o aparelho bloqueado, a camada Android nativa deve usar uma notificação silenciosa/atividade de tela apropriada, respeitando as regras do Android e as permissões do usuário.
