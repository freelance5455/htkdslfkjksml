# ChatConnect Firebase Real Chat

A WhatsApp-style, independent real-time chat starter.

Includes: email/password authentication, user profiles, user list/search, one-to-one real-time text messaging, mobile UI.

## Setup
1. Create a Firebase project.
2. Add a Web App and copy its config.
3. Enable Authentication > Email/Password.
4. Create Firestore Database.
5. In www/index.html replace YOUR_API_KEY, YOUR_PROJECT, YOUR_PROJECT_ID, YOUR_SENDER_ID and YOUR_APP_ID.
6. Host the www folder on a static HTTPS host.

Do not put service-account/private keys in this app. Before public launch, configure strict Firestore security rules.

This is not WhatsApp and does not connect to WhatsApp. It can later be wrapped into an Android APK.
