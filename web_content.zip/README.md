# BROKER PARÁ — Projeto Android Studio

## Base
O aplicativo usa o arquivo `app/src/main/assets/index.html` como interface principal.
Esse arquivo é a versão fornecida do BROKER PARÁ, com:
- autenticação local;
- catálogo original protegido;
- lançamento;
- CX / EXB / UN e conversão;
- cadastro manual;
- painel;
- histórico;
- backup/restauração;
- exportação CSV;
- sincronização Supabase;
- interface mobile.

## Android
`MainActivity.kt` fornece o contêiner WebView e:
- permissão de câmera;
- acesso da câmera ao JavaScript (`getUserMedia`);
- armazenamento DOM/localStorage;
- seletor de arquivo para restauração de backup;
- acesso à internet para Supabase;
- navegação interna do WebView.

## Abrir no Android Studio
1. Extraia o ZIP.
2. Abra a pasta `BROKER-PARA` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Conecte um celular Android com Depuração USB ou use um emulador.
5. Execute `app`.
6. Para gerar APK: Build > Generate App Bundles or APKs > Generate APKs.

## Observação importante sobre o leitor
O HTML atual depende de `BarcodeDetector`/câmera do navegador. O projeto já libera a câmera para o WebView, mas o suporte do BarcodeDetector pode variar conforme a versão do Android System WebView.
Para uma versão de produção, a próxima evolução recomendada é substituir o leitor web por um leitor nativo com ML Kit/CameraX, mantendo o mesmo catálogo e fluxo do HTML.

## Supabase
A área Nuvem do HTML já usa URL/chave pública e a tabela `broker_records`.
Não coloque chave secreta/service-role dentro do APK.
