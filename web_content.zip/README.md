# SHADOW OF THE ABYSS — vertical slice (Phase 1–7)
Developer: t.me/PengodeHandal01

## Main langsung
Buka `index.html` di Chrome (HP/PC). Satu file, tanpa server, tanpa internet. Save otomatis di localStorage.
Kontrol PC: A/D gerak · W/Space lompat · J serang (tahan = auto-combo) · K/I/O skill 1-3 · L/Shift dodge · R ultimate · Q/E potion · Esc pause.

## Jadikan APK Android (offline)
Butuh Node.js 18+, Android Studio (SDK), JDK 17. Dari folder `android/`:
    npm install
    npx cap add android
    npx cap sync android
    npx cap open android        # lalu Build > Build APK di Android Studio
Kunci landscape: di `android/app/src/main/AndroidManifest.xml` tambahkan
`android:screenOrientation="sensorLandscape"` pada `<activity>`.

## Struktur modular
- `src/1-data-audio.js`  DATA.chars / DATA.enemies / DATA.maps (tambah karakter, monster, stage di sini) + save + audio sintesis
- `src/2-gameplay.js`    combat, AI musuh (kind: melee/proj/charge/leap/aoe/summon/dive/tele/slam/spin), bos, wave, level
- `src/3-render.js`      parallax, sprite, efek, HUD
- `src/3b-rig-anim.js`   rig boneka 2D: pedang/perisai/sayap/kaki dipotong dari sprite lalu digerakkan per sendi (RIGDEF + pose per state)
- `src/4-ui-input-main.js` layar UI, kontrol sentuh, loop
- `assets/`              sprite/ kartu/ background — ganti file lalu jalankan `python3 src/build.py`

## Layar penuh
Layar lebar (HP 19.5:9 dst) otomatis terisi penuh tanpa pita hitam. Di browser tekan tombol ⛶ FULLSCREEN (atau tombol F);
game juga meminta layar penuh saat MULAI stage (bisa dimatikan di Pengaturan). Untuk APK, aktifkan mode immersive di
`android/app/src/main/java/.../MainActivity.java` (onCreate):
    getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);

## Animasi sprite-sheet (Slayer)
Frame di `assets/frames/` (run_01-12, dash_01-16, atk1_01-06, atk2_01-06) + `assets/framemeta.json` (ukuran & anchor kaki).
Pemetaan state -> frame ada di `src/3b-rig-anim.js` (`slayerFrame()` dan tabel `SL_SEQ`). Untuk animasi baru: tambah frame,
daftarkan di `ANIM`, lalu atur urutannya di `SL_SEQ`. Rig boneka lama tetap ada sebagai cadangan (dipakai musuh).
