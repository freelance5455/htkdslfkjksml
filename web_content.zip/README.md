# Distritiendas Tolú — Android

Este proyecto envuelve la aplicación HTML existente en una aplicación Android mediante Capacitor.

## Preparación

1. Instala Node.js LTS y Android Studio.
2. En esta carpeta ejecuta:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
3. En Android Studio selecciona un emulador o teléfono Android y ejecuta la aplicación.
4. Para generar una APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

## Importante sobre el modo sin Internet

La aplicación HTML ya guarda pedidos pendientes localmente y los sincroniza con Supabase cuando vuelve Internet. La interfaz puede abrirse dentro de la APK sin depender de Netlify. Sin embargo, el inicio de sesión y la sincronización con Supabase requieren conexión, porque dependen del servicio remoto.

Para un modo 100% autónomo sin Internet (incluyendo inicio de sesión y consulta de todos los datos), habría que implementar una base de datos local y una sincronización posterior con Supabase.
