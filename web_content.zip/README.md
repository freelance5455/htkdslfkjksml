# S.K.A.T.E. — generar el APK para Android

Este paquete contiene la app web (`www/index.html`, con el SKATE GAME y LEARNING)
y el logo ya preparado (silueta de skate en rojo neón, carpeta `icons/`).

**Importante:** no fue posible compilar el APK aquí mismo porque este entorno
no tiene el SDK de Android ni acceso a internet, que son necesarios para descargar
las herramientas de compilación (Gradle, plataforma Android, etc.). Los pasos de
abajo lo generan en tu propia computadora en unos 15-20 minutos, casi todo
automático.

## Lo que necesitas instalar (una sola vez)

1. **Node.js** (LTS): https://nodejs.org
2. **Android Studio**: https://developer.android.com/studio
   Al abrirlo por primera vez, deja que instale el "Android SDK" que te proponga
   por defecto.

## Pasos

Abre una terminal **dentro de esta carpeta** (`skate-apk-project`) y ejecuta:

```bash
npm init -y
npm install @capacitor/core @capacitor/cli
npx cap init "S.K.A.T.E." com.tuusuario.skate --web-dir www
```

(Puedes cambiar `com.tuusuario.skate` por el identificador que prefieras, pero
debe tener ese formato: dos o más palabras separadas por puntos, sin espacios.)

```bash
npm install @capacitor/android
npx cap add android
```

Esto crea una carpeta `android/` con un proyecto nativo completo.

### Poner el logo

Copia el contenido de la carpeta `res-icons/` de este paquete dentro de
`android/app/src/main/res/`, reemplazando los archivos `ic_launcher.png` y
`ic_launcher_round.png` que ya existen ahí. Con eso el logo (la silueta de skate
en rojo neón) queda puesto en todos los tamaños que necesita Android.

*(Alternativa más visual: abre el proyecto en Android Studio, clic derecho en
`app/res` → `New` → `Image Asset`, y en "Foreground Layer" elige
`icons/icon-foreground-1024.png` y en "Background Layer"
`icons/icon-background-1024.png`.)*

### Compilar

```bash
npx cap sync android
npx cap open android
```

Esto abre Android Studio. Espera a que termine de sincronizar (la primera vez
descarga varias cosas, necesita internet).

Luego, en el menú de Android Studio:

**Build → Build Bundle(s) / APK(s) → Build APK(s)**

Cuando termine, aparece un aviso abajo a la derecha; haz clic en **locate** para
encontrar el archivo. Normalmente queda en:

```
android/app/build/outputs/apk/debug/app-debug.apk
```

## Instalarlo en el celular

Pasa ese `.apk` al teléfono (cable USB, WhatsApp, Google Drive, etc.) y ábrelo
desde el explorador de archivos del celular. Si es la primera vez que instalas
una app fuera de Google Play, Android pedirá activar **"Instalar apps de
fuentes desconocidas"** para esa app (por ejemplo, para "Archivos" o "Chrome").
Actívalo solo para esa instalación.

## Notas

- Este `app-debug.apk` es perfecto para instalar en tu propio celular o
  compartirlo directamente. Si más adelante quieres subirlo a Google Play,
  hace falta además un `.aab` firmado con una clave propia
  (**Build → Generate Signed Bundle / APK**), que Android Studio también genera.
- Si prefieres no instalar Android Studio, existe otra vía: subir `www/index.html`
  a un hosting gratuito (por ejemplo Netlify o GitHub Pages) y usar
  https://www.pwabuilder.com pegando esa URL: analiza la página y genera un
  APK/AAB firmado para descargar, sin instalar nada en tu computadora. Es más
  rápido, pero necesitas primero tener el archivo publicado en una URL pública.
- La lista de trucos y todo el contenido de Learning siguen en
  `www/index.html`, en la constante `TRICKS`, exactamente igual que antes.
