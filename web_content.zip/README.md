# Заметки → APK

Папка `www/` — готовое веб-приложение (работает офлайн, без внешних ресурсов).

## Способ 1: Capacitor (нужны Node.js и Android Studio)
1. `npm install`
2. `npx cap add android`
3. `npx cap sync android`
4. `npx cap open android` — в Android Studio: Build → Build APK(s).
   Или в консоли: `cd android && ./gradlew assembleDebug` (APK в `android/app/build/outputs/apk/debug/`).

Свои `appId` и `appName` меняй в `capacitor.config.json` до шага 2.
Иконку приложения: положи `icons/icon-512.png` в Android Studio через Image Asset (res/mipmap).

## Способ 2: без Android Studio
Выложи содержимое `www/` на любой HTTPS-хостинг (GitHub Pages, Netlify) и загрузи адрес на pwabuilder.com, он соберёт APK/AAB.

## Что уже учтено
- манифест, иконки (в т.ч. maskable), service worker (только на http/https)
- без Google Fonts и CDN, системный шрифт
- кнопка «Назад» на Android закрывает настройки, редактор и режим редактора интерфейса
- запрет зума и pull-to-refresh, выделение текста только в полях
- цвет статус-бара (`theme-color`) следует за темой
- данные в localStorage (в WebView сохраняются между запусками)
