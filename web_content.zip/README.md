# 🍔 Swiggy Login Telegram Bot

A clean, direct Python Telegram bot (python-telegram-bot v20+) designed for personal use.

---

## 🚀 Exact Workflow

1. Send `/start` ➡️ Displays:
   ```
   🍔 Welcome to Swiggy Login Bot!
   [ 🍔 Login to Swiggy ]
   ```
2. Click **"Login to Swiggy"** ➡️ Prompts:
   ```
   📱 Enter your 10-digit mobile number:
   ```
3. Enter mobile number ➡️ Bot sends OTP request.
4. Enter received OTP in chat (or verify via official WebApp button).
5. Bot verifies OTP ➡️ Displays:
   ```
   🍔 Successfully authenticated with Swiggy!
   ```
6. Send `/logout` ➡️ Wipes all data from memory instantly.

---

## 🤖 Deploy on Your "Bot Hosting Bot"

Aapke paas Telegram bot hosting bot hai, toh bas ye karo:

1. **Download/Copy these 2 files**:
   - `main.py`
   - `requirements.txt`
2. **Send to your Hosting Bot**:
   - Hosting bot ke chat me `main.py` aur `requirements.txt` upload karo.
3. **Set Environment Variable**:
   - `TELEGRAM_BOT_TOKEN` = `your_token_from_botfather`
4. **Run**:
   - Start pe click karo, bot live ho jayega!

---

## ☁️ Deploy on Render (Free 24/7)

1. Push to GitHub.
2. Render.com pe **New Web Service** select karo.
3. Settings:
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `python main.py`
   - **Environment Variable**: `TELEGRAM_BOT_TOKEN = <your_botfather_token>`
4. Deploy!
