# MovieMora HTML/CSS/JS

A pure frontend prototype inspired by the supplied MovieMora UI references.

## Files
- index.html — user app
- admin.html — admin panel
- css/style.css — user UI
- css/admin.css — admin UI
- js/app.js — user interactions
- js/admin.js — admin content management
- assets/ — intentionally empty of cartoon/poster content

## Run
Open `index.html` in a modern browser. For best results, use a small local server (VS Code Live Server, for example).

## Admin
Open `admin.html`. This is a frontend/local demo, not secure production authentication.
Content added in the admin panel is stored in browser localStorage and appears in the user app in the same browser.

## Important
Pure HTML/CSS/JS cannot securely send Gmail verification codes or provide real multi-user authentication. For production, connect a backend/auth provider and never put a Gmail password in JavaScript.
