# Ramen Shift

A mobile-first, seven-night psychological-horror prototype about working at a family ramen stand while investigating a killer and being stalked by something outside.

## Run

From this folder, start a local static server:

```sh
npx http-server . -p 8080 -c-1
```

Open the server URL in a browser on the same device. ES modules and GLB loading need HTTP; opening `index.html` directly as a `file://` URL will not work. The page uses local libraries and makes no CDN requests.

## Controls

- Mobile: left virtual stick to move, drag the right side to look, tap **Interact** to use the computer.
- Desktop: WASD or arrows to move, mouse drag to look, E or Space to use the computer, C to open it directly.
- Use **CCTV** to read visitor plates, **Plate Lookup** to identify a visitor, and **Case File** to compare clues. Submit the matching identity to unlock sleep and continue to the next night.
- Choose Low, Medium, or High from the menu to change internal render resolution, fog, dithering, and color depth.

## Game icon

The launcher icon is `assets/icon.png` (512×512); the matching SVG is `assets/icon.svg`. Use the PNG in an APK builder’s app icon field.

## Rendering and assets

Three.js, GLTFLoader, and BufferGeometryUtils are available locally. `three-psx` is vendored in `libs/three-psx/` and provides the vertex-snapped, affine-texture, dithered PS1 rendering pipeline. No shadows are enabled, fixed scenery is merged, and scene rendering stops when the game is paused or backgrounded.

Models extracted from the supplied packs are in `assets/models/`: ramen bowl, induction stove, stock pot, and stools. The original `assets/game_assets.zip` is preserved. Code-built blockout props stay as fallbacks when a model cannot load.
