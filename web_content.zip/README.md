# TikTok Integrity Reporter — Website + Android-ready PWA

This is a working front-end prototype with an English interface. It can run as a website and can be installed on supported Android browsers as a Progressive Web App (PWA).

## Features
- Save a TikTok username and reuse it on the same browser/device
- Prepare drafts for suspected fake followers, fake likes, or fake views
- Attach small evidence files; evidence is stored locally in the browser
- Report history, view drafts, copy report text, export JSON, and delete records
- Link to TikTok Support's official reporting guidance
- Basic offline caching after first successful load

## Important limitations
- It does not submit reports to TikTok, access private TikTok data, determine whether an account violated rules, or guarantee account enforcement.
- Data is stored in the browser's local storage on that device/browser. It is not synced across devices and can be lost if site data is cleared.
- Evidence files are embedded locally in the browser database for this prototype. Keep files small and do not include private/sensitive data.
- This is not affiliated with or endorsed by TikTok.
- For a production multi-device app, add a secure backend, authentication, encrypted file storage, privacy policy, retention controls, and abuse protections.

## Run locally
You can open `index.html` for basic use, but install/offline features require serving the folder over HTTPS or localhost.

### Option A: Python local server
From this folder run:
```bash
python -m http.server 8000
```
Then open `http://localhost:8000`.

### Option B: Android installation
1. Deploy the folder to an HTTPS static host (for example, GitHub Pages, Netlify, or Cloudflare Pages).
2. Open the deployed URL in Chrome on Android.
3. Use Chrome's menu and choose **Install app** or **Add to Home screen** when available.

This PWA method creates an installable app-like experience. It does not automatically create a standalone APK.

### Option C: Build a native Android APK
A native APK requires Android Studio and a wrapper such as Capacitor. General outline:
1. Install Node.js and Android Studio.
2. Create a Capacitor project and copy these web assets into its web directory.
3. Add the Android platform, build, and sign the APK/AAB.
4. Follow current Capacitor documentation for exact commands and requirements.

## Official reporting
The app links to: https://support.tiktok.com/en/safety-hc/report-a-problem
Always make truthful, good-faith reports. Do not use repeated duplicate reports to target someone.
