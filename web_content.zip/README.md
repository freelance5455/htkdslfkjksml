Daily Progress Manager V2 - Fixed

This version includes the missing HTML and updates float calculations.

Float calculation behavior:
- Each daily float amount is stored against its date.
- Given MTD is automatically calculated as the previous recorded daily amounts plus today's amount (Android also preserves the existing legacy Given MTD value as a starting balance).
- Remaining = Float Target - cumulative Given MTD.
- Adding a float amount on any previous date automatically affects the current remaining amount.
- History shows the cumulative MTD and remaining amount for each date.

Web version: open web/index.html or upload the web folder to a web-to-APK builder.
Android version: android/ is the native Android project.
