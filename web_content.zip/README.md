# JARVIS Offline AI for Android (v2.0)

JARVIS now uses a local language model through Google's LiteRT-LM Android runtime. The app does **not** call Gemini, OpenAI, or another online AI API. After the model has been downloaded and loaded, prompts and generated answers are processed on the phone.

## What it includes

- Existing futuristic teal JARVIS chat UI.
- Multiple chats and local conversation history (WebView local storage).
- On-device Qwen3-0.6B language model using LiteRT-LM 0.18.0.
- First-run model download manager with progress and file-size validation.
- Model stored in the app's private internal files directory.
- Local inference on CPU; no network connection is used for answering prompts.
- Built-in local calculator, date/time, and starter lessons.
- Voice input/output where Android's installed speech services support it.

## Phone requirements and model

- Designed for Android API 24+.
- Suggested for this device: 6 GB RAM and at least about 850 MB free storage before downloading. The model file is about 586 MB; runtime memory use varies by device and context length.
- Model: `Qwen3-0.6B.litertlm` from `litert-community/Qwen3-0.6B` on Hugging Face (Apache-2.0 model card license).
- The first download requires internet. After download and loading, airplane-mode testing should still produce AI answers.

## Build APK using GitHub Actions

1. Download and extract this ZIP.
2. Create a **private** GitHub repository.
3. Upload the *contents* of the extracted folder, including `.github/workflows/build.yml`.
4. Open **Actions → Build JARVIS APK → Run workflow**.
5. When complete, download the `JARVIS-Assistant-APK` artifact and extract `app-debug.apk`.
6. Install the APK on your Android phone.
7. Open JARVIS → menu → **AI Settings** → **Download model**. Use stable Wi-Fi and do not close the app while downloading.
8. Tap **Load model**. The first load may take a while; close other heavy apps if memory is low.
9. Ask a general question. Then enable airplane mode and ask another general question to verify local inference.

## Privacy and network behavior

- The only intended app network request is the one-time model file download from Hugging Face.
- There are no AI API keys, no Gemini request code, and no online AI generation endpoint.
- Chat history remains in WebView local storage; the model is kept in app-private storage.
- Android's speech recognition provider may still use its own service depending on the device. Text prompts and model responses themselves are handled locally. For strict offline voice input, install an offline speech-recognition language pack and test it in airplane mode.
- The Android `INTERNET` permission remains solely for the optional first-time model download.

## Important limitations

This is a compact 0.6B-parameter model, not a copy of ChatGPT. It can answer many everyday questions and help with code, but it may be less accurate, may not know current events, and can make mistakes. It cannot browse the web while offline. Model loading and speed vary by phone chipset and available RAM.

## Build verification

The source package and JavaScript/XML structure should be checked by CI. This project was not compiled on the authoring machine because a local Android SDK/Gradle build environment was not available. Use the GitHub Actions build result to confirm compilation before installing.
