# FORGE Planner — MVP

A responsive, English, dark-mode personal planner. The first version is a local-first web app that can be wrapped into an Android APK.

## Included features
- Overview dashboard with today's task/habit progress
- Tasks with priority, due date, completion, and delete
- Daily habits with date-based check-ins and streak counts
- Goals with target dates and progress controls
- Weekly review notes
- JSON export/import backup
- Local browser storage; no account or server required
- PWA shell for offline use after first load when served over HTTP(S)

## Fastest way to test
Open `index.html` in a desktop browser. Most features work locally. For offline/PWA service-worker testing, serve the folder over HTTP instead of opening the file directly.

## Build an Android APK with Capacitor
You need a computer with Node.js LTS, npm, and Android Studio installed. The Android build tools are not bundled in this ZIP.

1. Install Node.js LTS and Android Studio.
2. Extract this folder.
3. Open a terminal in this folder and run:

   ```bash
   npm init -y
   npm install @capacitor/core @capacitor/android
   npm install -D @capacitor/cli
   npx cap init FORGE com.ashkan.forge --web-dir .
   npx cap add android
   npx cap sync android
   npx cap open android
   ```

4. In Android Studio, wait for Gradle sync to finish.
5. For a test build, select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show a notification with **Locate**. The debug APK is typically at `android/app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer the APK to your phone and open it. You may need to allow installation from that file manager.

### Important note about Capacitor configuration
Depending on the Capacitor CLI version, `npx cap init` may ask questions and create `capacitor.config.*`. If it doesn't accept `.` as the web directory, create `capacitor.config.json` in the project root with:

```json
{
  "appId": "com.ashkan.forge",
  "appName": "FORGE",
  "webDir": ".",
  "bundledWebRuntime": false
}
```

Then run `npx cap add android` and `npx cap sync android`.

## Run on a phone without compiling
You can also host this folder on a static HTTPS host and open it in Chrome on Android, then use **Add to Home screen**. This creates an installable web app, not a standalone APK.

## Data and privacy
Planner records are saved in local browser storage on the device. Clearing browser/app data can erase them, so use **Review > Export backup** regularly. Exported JSON files contain your planner data; keep them private.
