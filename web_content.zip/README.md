# SPIDER SYSTEM 1.0 — HOMECORE

Reconstrucción desde cero de la interfaz HUD de SPIDER SYSTEM. La aplicación entra directamente al visor: no hay pantalla de inicio, menú HUB ni panel de módulos. Los únicos controles principales son **VOICE CHAT** y **CAMERA**.

## Qué incluye

- HUD inmersivo a pantalla completa, adaptable a PC, móvil vertical y móvil horizontal.
- Visor de cámara en directo con retícula, guías de encuadre, telemetría y estados visibles.
- Botón de cámara para iniciar y detener la transmisión local del sensor.
- Botón VOICE CHAT para abrir/cerrar una sesión de escucha continua.
- KAREN responde con voz y texto. En Android usa `SpeechRecognizer` y `TextToSpeech` nativos; en navegadores compatibles usa Web Speech API.
- Comandos por voz para cámara, cambio entre cámara frontal/trasera, ubicación/GPS, hora, fecha, ayuda y diagnóstico.
- Indicador de conexión y reloj local.
- Solicitud de permisos de cámara, micrófono y ubicación en Android.
- No descarga ni transmite el vídeo de la cámara a un servidor.

## Importante sobre KAREN

Esta versión trae reconocimiento de voz, síntesis de voz y un motor local de comandos. **Todavía no está conectada a un modelo de IA conversacional externo**, por lo que las respuestas generales explican esa limitación en lugar de simular una conexión inexistente. El canal de voz permanece activo después de cada respuesta mientras la sesión esté abierta.

## Estructura

```text
SPIDER-SYSTEM-1.0/
├── index.html                 # versión PC/web independiente
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── assets/index.html
│       ├── java/com/spidersystem/app/MainActivity.kt
│       └── res/
├── .github/workflows/build-apk.yml
├── build.gradle.kts
├── gradle.properties
├── settings.gradle.kts
└── README.md
```

## Generar el APK

### GitHub Actions

1. Extraé el contenido del ZIP en la raíz del repositorio `SPIDER-SYSTEMM`.
2. Subí los archivos al repositorio.
3. Abrí **Actions → Build SPIDER SYSTEM APK**.
4. Cuando termine correctamente, descargá el artefacto `SPIDER-SYSTEM-1.0-debug-APK`.

### Compilación local

Se requiere JDK 17, Android SDK 35 y Gradle 8.9 o posterior:

```bash
gradle --no-daemon assembleDebug
```

El APK de depuración se genera en:

`app/build/outputs/apk/debug/app-debug.apk`

## Uso

- **CAMERA**: solicita el permiso y abre el sensor trasero. Al volver a tocarlo, detiene la cámara.
- **VOICE CHAT**: solicita permiso de micrófono y abre el canal de voz. Tocarlo otra vez cierra la sesión.
- Decí “KAREN, activa la cámara”, “apaga la cámara”, “cambia la cámara”, “consulta mi ubicación”, “qué hora es”, “estado del sistema” o “ayuda”.

En PC, usá el `index.html` que está en la raíz del ZIP. Abrilo mediante HTTPS o `localhost` desde un navegador compatible (por ejemplo, con Live Server). El acceso a la cámara y al micrófono está restringido por los navegadores cuando una página se abre como archivo local (`file://`). La carpeta `app/src/main/assets/` contiene la misma interfaz que utiliza la APK.

## Compatibilidad

- Android 6.0 o posterior. La disponibilidad de reconocimiento de voz nativo depende de que el dispositivo tenga un servicio de reconocimiento configurado y disponible.
- En PC, Chrome/Edge ofrecen el soporte más habitual para cámara y Web Speech; el soporte de reconocimiento puede variar según navegador y sistema operativo.
- Los permisos se conceden desde el sistema. La cámara solo se activa después de tocar el botón.
