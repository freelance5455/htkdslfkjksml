# AI & AK — Colorful Android-friendly AI Studio

## Included
- Colorful, responsive mobile UI for AI photo generation, photo editing, character sheets, photo-to-video, text-to-video, gallery, download/share.
- Server-side Node/Express routes that call the Google GenAI Interactions API for image and video outputs.
- Login screen clearly marked as **demo only**. Real authentication is not implemented in this starter.
- Gallery is session-only. It clears when the page is refreshed.

## What is real vs. not yet connected
- **UI:** included.
- **Image generation, editing, character sheets:** real API calls after server setup, valid API key, supported model access, and quota are configured.
- **Text-to-video and photo-to-video:** real API calls after server setup, valid API key, supported video model access, and quota are configured. Video model support and API response details can change; verify current official documentation if a model returns an error.
- **Login/accounts:** demo screen only. Do not enter a real password. Connect a trusted authentication provider with proper database rules before real users use the app.
- **Android install:** this is a web app project, not a compiled APK. First host/run it, then package it as a PWA or Android app.

## Setup (computer or Node-capable hosting)
1. Install current Node.js LTS.
2. Extract this ZIP.
3. Copy `.env.example` to `.env`.
4. Add your own Gemini API key as `GEMINI_API_KEY=...`.
5. Run `npm install`, then `npm start`.
6. Open `http://localhost:3000`.

## Phone-only path
Use Google AI Studio Build or another hosting environment that supports server-side Node.js routes. Recreate/import `public/index.html` and `server.js`, then set `GEMINI_API_KEY` in its server-side Secrets manager. Do not paste the key into HTML, browser JavaScript, screenshots, or chat messages.

## Model defaults
- Image: `gemini-nano-banana-2.1`
- Video: `gemini-omni-1.1-flash`

Model access can vary by account and change over time. See the official Gemini API documentation:
- https://ai.google.dev/gemini-api/docs/image-generation
- https://ai.google.dev/gemini-api/docs/video-generation

## Safety and privacy
- API usage may have quotas or costs. Check current pricing and limits before using.
- Never share `.env` or your API key.
- Before public launch, add authentication, authorization, per-user rate limits, request timeouts, storage policies, consent/privacy information, and abuse prevention.
- Do not upload images you do not have permission to use.
