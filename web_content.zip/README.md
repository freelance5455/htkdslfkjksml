# Limite — projeto Android

Este projeto empacota o HTML original em um aplicativo Android usando WebView. O HTML foi mantido como asset local; o armazenamento local do navegador (localStorage) fica habilitado.

## Gerar o APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `LimiteAndroid` no Android Studio.
3. Aguarde a sincronização do Gradle e a instalação dos componentes de SDK solicitados.
4. No menu **Build**, escolha **Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de debug será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

O projeto requer Android SDK 35 e Gradle/Android Gradle Plugin compatível. A primeira compilação exige internet para baixar dependências.
