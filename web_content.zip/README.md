# WidMate Browser

A colorful Android WebView browser/download app inspired by modern media-browser layouts.

Features:
- Google, YouTube and general websites
- URL/search bar
- Back / Forward / Home / Refresh
- Web history
- File chooser for uploads
- Android DownloadManager for normal downloadable files
- JavaScript, DOM storage and cookies
- Colorful WidMate branding
- No built-in YouTube video extraction/downloader

Open the `android-project` folder in Android Studio and build the APK.
