# ◈ TEMPO·ESPAÇO ◈ v9.0 — com Scanner de Energia por Câmera

## NOVIDADE v9: Scanner de Energia (câmera + análise REAL de pixel)
- Câmera traseira ao vivo com análise frame a frame (7fps, 160x120 p/ performance)
- Mede de verdade: luminosidade média, movimento (diferença entre frames), mudança de matiz (hue)
- Índice de flutuação 0-100 calculado (movimento 50% + luz 25% + cor 25%)
- Detecção automática de picos acima do limiar (ajustável) → registra em log c/ horário + valor + vibra
- Overlay AR HUD: direção dos waypoints sobreposta na imagem da câmera (bússola+GPS reais)
- Botão capturar frame (snapshot PNG)
- Log de detecções salvo em localStorage (20 últimas)

## Mantido: v8 completo
Bússola c/ filtro, GPS, magnetômetro µT, espectro de áudio, pulsos, radar de waypoints,
módulo pineal 7min (963Hz ao vivo + TTS pt-BR + respiração + vibração).

## Robustez anti-quebra (APK)
- Todo sensor envolto em try/catch — se um falhar, o app continua
- Câmera desliga automaticamente ao trocar de tela (economia bateria)
- Sem dependências externas (sem CDN, sem fontes externas) — funciona 100% offline
- Áudio: getUserMedia com fallback silencioso se negado
- service worker v9 com cache offline + fallback index.html

## Pacote (tudo na raiz)
index.html · manifest.json · sw.js · icon-192.png · icon-512.png · GUIA_XIAOMI.txt · README.md
(~55KB — abaixo do limite 5MB dos conversores gratuitos)

## Validado
- JS embutido: node --check ✅
- sw.js: node --check ✅
- manifest.json: JSON válido ✅
