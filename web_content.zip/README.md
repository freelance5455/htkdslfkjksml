# JAZZY Social 2.0 — Android + Node.js

An independent social-app prototype rebuilt from the UI assets of the uploaded `JAZZY-1.1.2.apk`, plus the previous JAZZY Android build skeleton. **This ZIP is source code, not a ready-to-install APK.** The latest JAZZY 1.1.2 *backend source was not present in the upload*, so this is a **new social backend** and not a drop-in replacement for the running JAZZY private-chat server.

## Implemented in this source package

- Username/password account registration and login, multiple accounts, 30-day per-device sessions (passwords hashed using scrypt).
- User search, searchable profiles, bio, public/private account, pending follow requests, followers/following.
- Image and text posts; hashtags and hashtag search; feed, likes, comments, saved posts, delete own posts.
- Conversation inbox and one-to-one text messaging **only after both accounts follow each other**; message read state. Messages are **NOT end-to-end encrypted** in this social prototype.
- Settings: edit name, bio, privacy, change password, logout, delete account, block/unblock accounts, account reports stored in DB (moderation review NOT implemented).
- Uses SQLite for app data and media bytes, keeps everything when the database file is on **persistent storage**.
- Android 8+ WebView, reusable styles, Android Keystore-based local session storage (`readSocialVault`, `writeSocialVault`). Uses separate Android package `app.jazzy.social`, so it does not overwrite your existing JAZZY app or access its stored private keys.

## What it does not yet do

- Does NOT automatically migrate the existing 1.1.2 users, private encrypted messages, passwords, invitations or rooms.
- Does NOT include end-to-end encryption for social messages, push notifications, videos, production moderation/dashboard, large media hosting, offline outbox, or scalable production storage.
- NOT independently audited for security or load testing.
- Doesn't promise reliable storage on Render free hosting. Render free disk is ephemeral and services can sleep. **Do not use this for important message or post history until persistent storage and backups are configured.**

## Test locally

Requires Node >=22.13 (Node 24 recommended). No npm packages needed.

```bash
npm test
npm run server
```

Optional browser preview in a second terminal:

```bash
node scripts/preview.mjs
```

Visit http://localhost:8000 in a desktop browser. For browser preview, `app.mjs` points to local http://127.0.0.1:8787. Registration happens on local data only.

## Deploy a separate server (important!)

Your old production URL `https://jazzy-2.onrender.com` was running an **older JAZZY API** and should be left alone until you have safely migrated/backed up data.

1. Extract this ZIP and upload the **contents** (including `server/`, `app/`, `.github/` and `render.yaml`) into a new **private** GitHub repository. Avoid another enclosing folder inside the repo.
2. In Render, create a **new Web Service**, choose your GitHub repo, environment **Docker**, root directory `server`, and select the Free instance for **temporary tests only**. Alternatively use New → Blueprint with `render.yaml` at the repository root. Do not overwrite the old `jazzy-2` service.
3. When deployment reports Live, open `<NEW_URL>/health`. Expected: `{"ok":true,"app":"JAZZY SOCIAL","protocol":3,...}`.
4. Edit `app/src/main/assets/app.mjs` and replace the existing `https://jazzy-2.onrender.com` string in `API_BASE` with your **new** Render HTTPS URL. Do not append `/health` or `/v3`.
5. Commit the change. Then use GitHub **Actions → Build JAZZY 2 APK → Run workflow**. The Android build runs in GitHub's cloud; no Android Studio is required.
6. When the build succeeds, download artifact `JAZZY-2-Android-test-APK`, extract `JAZZY-2.0-test.apk`, and install on a phone. **APK build has not been executed or verified in this environment.**
7. Sign up for two test accounts and verify follows, messages and posts. Don't post personal/private information during testing.

### Cloud storage warning

Free Render does not include persistent local storage, so the SQLite file may disappear on deployment or instance replacement. The tests confirm persistence on a **persistent filesystem**, not on Render free. Before public use, move to durable managed database/media storage or provision a durable disk/host with backups. SQLite is suitable for small testing systems but not yet a robust large social platform.

### Security / moderation

- Never place the old `JAZZY_SETUP_TOKEN` in this APK or public GitHub repo. This social server does not need that token.
- If you previously shared the old token, rotate it on the **old** server separately.
- Block/report are present, but reports are only recorded: there is **no automatic moderation or staff dashboard** yet.
- Ensure account recovery, password reset, abuse prevention, child safety controls, backup/restore, privacy policy, and operations processes before real public launch.
- Browser preview uses a session stored for the browser tab; Android sessions use Keystore encryption. Never share session tokens.

## Source map

- `server/social.mjs` — authenticated social REST API, tables, access control.
- `server/server.mjs` — web server adapter; `server/Dockerfile` — Docker runtime.
- `app/src/main/assets/app.mjs` — social app UI, API requests, event handling.
- `app/src/main/assets/styles.css` — light-blue JAZZY UI.
- `docs/reference/` — extracted JAZZY 1.1.2 JS/CSS modules for reference only; not part of social runtime.
- `tests/social.test.mjs` — end-to-end API tests using in-memory and disk SQLite.
- `.github/workflows/build-apk.yml` — cloud Android build.

## API overview

`/health`, `/v3/auth/register`, `/v3/auth/login`, `/v3/auth/logout`, `/v3/me`, `/v3/me/password`, `/v3/users?q=`, `/v3/users/:username`, `/v3/users/:username/follow`, `/v3/users/:username/posts`, `/v3/users/:username/followers`, `/v3/users/:username/following`, `/v3/follow-requests`, `/v3/feed`, `/v3/posts`, `/v3/posts/:id`, `/v3/posts/:id/like`, `/v3/posts/:id/save`, `/v3/posts/:id/comments`, `/v3/tags`, `/v3/tags/:tag`, `/v3/saved`, `/v3/inbox`, `/v3/messages/:username`, `/v3/blocked`, `/v3/users/:username/block`, `/v3/users/:username/report`, `/v3/media/:id`.
