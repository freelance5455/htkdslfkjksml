# NARAYANA GAMES - Offline Analytics Web Application

## Features Included:
1. **Red & White Minimalist Theme:** Clean modern dashboard built with Tailwind CSS.
2. **Offline Local Storage Data Persistence:** Automatically saves all entries locally.
3. **24-Hour Inactivity Auto Data Clear:** Real-time countdown timer that resets data automatically 24 hours after the last record entry.
4. **Jori Matrix (00 to 99):** Complete numeric grid dashboard with record logs, entry creation, editing, deleting, and history drawers.
5. **Crossing Combination Engine:** 
   - Supports **Jora Samet** and **Jora Cut** modes.
   - Allows bulk amount entry that syncs all generated pairs directly into the Jori matrix (00–99).
6. **Haruf Tracker (Feature A & Feature B):** 
   - Digit position tracking (Feature A = Inside/Andar, Feature B = Outside/Bahar).
   - Automatically auto-maps digit values into corresponding 10 Jori matrix numbers.
7. **Graph Analytics:** Interactive Chart.js visual analytics graph tracking record performance across all numbers 00 to 99.
8. **Live Leaderboard:** Real-time leaderboard listing all numbers sorted from highest record total down to unused numbers.
9. **JSON Data Backup Export:** Export system backup state to `.json` anytime.

## How to Run:
Extract the zip file and double-click `index.html` to open it in any web browser (Chrome, Edge, Firefox, Safari, Mobile Browser). No internet or server installation required!
