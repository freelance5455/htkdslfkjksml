# Suesa AI — Android + HTML birleşik sürüm

Bu proje, Suesa AI HTML arayüzünü Android tarafındaki kamera/dosya/izin özellikleriyle birleştirir.

## Dahil olanlar
- Suesa AI HTML sohbet arayüzü
- Sohbet geçmişi ve yeni sohbet
- Gemini API anahtarını Ayarlar'dan kaydetme
- Fotoğraf seçimi
- Kamera çekimi ve Android kamera izni
- Tüm dosya türleri için sistem dosya seçicisi
- İlk kullanımda fotoğraf/dosya bilgilendirme penceresi
- "Paneli aç" hızlı paneli
- Android sesli sohbet ve mikrofon izni
- Android WebView köprüsü
- 25 MB dosya sınırı

## Android Studio
Projeyi Android Studio ile açıp `app` modülünü çalıştırabilirsin.

Gemini API anahtarı uygulamaya sabitlenmedi; HTML'deki Ayarlar bölümünden girilir.

Sesli sohbet uygulama açıkken çalışır. Uygulama tamamen kapalıyken sürekli uyandırma için ayrıca Android foreground-service ve cihaz üreticisi kısıtlarına uygun bir servis gerekir.
