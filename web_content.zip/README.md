# Ramen Shift

A mobile-first, seven-night psychological-horror prototype about working at a family ramen stand while investigating a killer and being stalked by something outside.

## Run

From this folder, start a local static server:

```sh
npx http-server . -p 8080 -c-1
```

Open the server URL in a browser on the same device. ES modules and GLB loading need HTTP; opening `index.html` directly as a `file://` URL will not work. The page uses local libraries and makes no CDN requests.

## Controls

The title screen has Play, Settings, and About pages, with a moving low-resolution scene behind it. Settings includes graphics, sound, and jumpscare intensity. Night 1 is a quiet introduction: the ghost does not appear or interfere. From Night 2 onward, the computer can log its CCTV image several seconds before it appears outside; later it watches from the road, interrupts the lights, and triggers scares.

Your investigation carries between nights. Open each email, check the archived CCTV clip, and look up the killer’s plate for a deeper file note. The final ending depends on how much evidence you found: an unfinished file, a partial case, or the full family-account truth. The Case File tab tracks your archive progress.


- Mobile: left virtual stick to move, drag the right side to look, tap **Interact** near a customer or kitchen station.
- Desktop: WASD or arrows to move, mouse drag to look, E or Space to interact, C to open the computer.
- Each night brings four or five customers. Serve each one at the service window. Waiting customers honk every 14 seconds; there is no patience countdown. Wrong station interactions count as mistakes. Served customers pay in US dollars and their car drives away. Shoyu, miso, tonkotsu, and spicy ramen unlock first; salmon nigiri, tuna cucumber maki, and California rolls follow on Nights 5–7. Check **Recipes** on the computer for ingredients and preparation steps. Use **CCTV**, **Plate Lookup**, **Case File**, and **Notes** to investigate between customers. After everyone has arrived and been served, end the shift and choose a suspect. A wrong choice ends the run; a correct choice lets you walk to the bedroom and sleep to continue.
- Collision blocks the counter, furniture, walls, bedroom desk and parked car. The counter has a pass-through opening so you can reach the service window; interactions are proximity-based, and you can sleep only at the bed. Press **Pause** or Escape to pause. Night progress and notes save on the device.
- Choose Low, Medium, or High from the menu to change internal render resolution, fog, dithering, and color depth. The game generates its own quiet night ambience, low-key music, and interaction/scare cues with Web Audio; use the Sound button to mute or restore them.
- The app requests fullscreen and portrait orientation when Play is tapped. Some APK wrappers ignore a web page’s orientation request; on touch devices that report a short landscape viewport, the game rotates its own stage as a fallback. If the wrapper blocks fullscreen, use its own fullscreen setting.

## Game icon

The launcher icon is `assets/icon.png` (512×512); the matching SVG is `assets/icon.svg`. Use the PNG in an APK builder’s app icon field.

## Rendering and assets

Three.js, GLTFLoader, and BufferGeometryUtils are available locally. `three-psx` is vendored in `libs/three-psx/` and provides the vertex-snapped, affine-texture, dithered PS1 rendering pipeline. No shadows are enabled, fixed scenery is merged, and scene rendering stops when the game is paused or backgrounded.

Models in `assets/models/` include the ramen bowl, induction stove, stock pot, stools, a PS1-style customer, a white ghost, and small Japanese food props for ramen and sushi. Three.js loads local GLB files; code-built props remain as fallbacks if a model cannot load.
