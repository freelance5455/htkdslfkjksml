# BOOP Music - Android APK Project

## What's inside
- www/ - Your BOOP Music PWA (ready, with FAB nav, Albums/Artists/Genres, Storage Access, Equalizer tab, Offline)
- www/icons/ - BOOP icons (192, 512, maskable + transparent logo)
- www/manifest.json - PWA manifest set to BOOP
- capacitor.config.json - Capacitor config (appId: com.boop.music)
- android-template/ - AndroidManifest.xml with permissions

## Build APK in 3 steps

1. Install deps:
   npm install
   npm install -g @capacitor/cli

2. Add Android:
   npx cap add android
   npx cap copy

3. Open in Android Studio:
   npx cap open android
   -> In Android Studio: Build > Build APK > app-debug.apk

Replace android/app/src/main/AndroidManifest.xml with the one in android-template/ to get storage permissions.

## Features included
- FAB navigation (Home/Search/Now Playing/Equalizer/Library)
- Categories: Songs/Albums/Artists/Genres
- Device Storage Access: picks local MP3s via File System Access API
- Offline: IndexedDB downloads
- Equalizer: 5-band with Web Audio API
- PWA installable as BOOP

Icon source: icons/icon-512.png - replace android/app/src/main/res/mipmap icons with it for launcher icon.

