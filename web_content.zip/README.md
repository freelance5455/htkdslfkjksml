# NeonTap Auto Clicker

A starter Android project using Kotlin, Jetpack Compose, and an Android Accessibility Service. It can dispatch tap gestures at configured screen coordinates and show a small floating control panel over other apps when the required permissions are enabled.

## Important limitations
- Android and individual apps can restrict or block automated gestures. This is not a bypass tool and is not guaranteed to work in every game/app.
- Use only where automation is permitted and respect each app's rules.
- Accessibility access is powerful. Enable it only after reviewing the permission screen.
- The floating panel requires the “Display over other apps” permission.
- Coordinates are physical screen pixels from the top-left; different screen sizes/orientations may need new coordinates.
- This repository includes `index.html` as a visual/feature preview, not as the native Android app. The Android functionality is implemented in Kotlin.

## Build and install
1. Install the current Android Studio and its Android SDK.
2. Open this folder in Android Studio and allow Gradle sync.
3. Connect an Android phone with USB debugging enabled, or use an emulator.
4. Choose **Build > Build APK(s)**. Android Studio will show the APK location after the build completes.
5. Install the APK on your device.
6. Open NeonTap, tap **Grant overlay permission**, and allow **Display over other apps**.
7. Return to the app and tap **Open Accessibility Settings**. Find **NeonTap Auto Clicker**, enable it, and confirm Android's warning.
8. Return to NeonTap. Set interval and point coordinates, then tap **Show floating panel**. The panel appears when the accessibility service is enabled and overlay permission is granted.
9. Switch to an app where you are allowed to automate taps. Use Start/Pause/Stop on the floating panel.

## Configure click points
Enter one or more `x,y` coordinate pairs separated by semicolons, for example `500,900;700,1200`. Coordinates are pixels from the top-left of the display. Test carefully in a harmless screen first.

## Included
- Compose dashboard and neon dark theme
- Interval, repeat count, coordinate list and preset saving
- Accessibility service gesture dispatch
- Floating overlay controls
- Permission checks and basic status/error feedback
- `index.html` browser preview

## Not included
A prebuilt APK or Gradle wrapper. Build the APK locally in Android Studio so it is signed and built with your installed SDK.


## `hshsh` cross-app mode
The dashboard now includes an option named **hshsh** for enabling cross-app mode. Its button opens Android Accessibility Settings; select NeonTap Auto Clicker and enable the service. Also grant Display over other apps for the floating panel. Android requires these permissions to be confirmed by the user, so the app cannot enable them silently.
