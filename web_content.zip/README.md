# GardenPro Web MVP (v0.2)

Responsive, mobile-first web app designed for preview and packaging into an Android WebView APK.

## Included
- English and Macedonian UI toggle
- Customer discovery, category filters and search
- Provider cards, profiles and starting prices
- Booking request flow (provider approval required)
- Provider studio: accept/decline/complete demo bookings
- Add a service form
- Customer bookings and profile/preferences
- Local persistence with browser localStorage
- PWA manifest and service worker for installable web preview

## Important demo limitations
This is a front-end prototype. It does not have real authentication, a remote database, real messaging, real provider verification, push notifications, payment processing or server-side booking conflict protection. Bookings and custom offers are stored only on the current browser/device. No actual provider is contacted. Demo data includes sample provider names and ratings and must not be treated as real listings.

## Run locally
Open `index.html` in a browser. For PWA/service-worker behavior, serve the folder over HTTPS or localhost.

## Prepare for a WebView APK
Upload the contents of this folder (or the ZIP) to a compatible HTML-to-APK builder. Configure:
- App name: GardenPro
- Package ID suggestion: `com.gardenpro.app`
- Start page: `index.html`
- Orientation: portrait (or auto)
- Internet access: enabled (for remote garden photos and Google Fonts)
- Status/navigation bar: dark forest green `#183f2b`

If the builder requests a website URL instead of ZIP/source files, host this folder as a static site over HTTPS first, then enter that URL. Do not publish the demo as a real booking marketplace until backend authentication, provider verification, privacy and booking APIs are implemented.
