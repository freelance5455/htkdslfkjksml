# Capri Mobile 2.0 — App control

Preserves the pink/red, yellow, neon green, black and purple character-inspired interface.

## Commands
- `open YouTube` — launch a matching installed app.
- `show apps` — browse installed launcher apps.
- `type Hello there` — type into the currently focused text field in another app.
- `take a screenshot` — save a phone screenshot to Pictures/Capri (Android 11+).
- `go back`, `go home`, `recent apps`.
- Tap the microphone for Android speech recognition; replies can be spoken aloud.

## Enable cross-app control
After installing, open Android Settings → Accessibility → Installed/Downloaded apps → Capri App Control → enable it. Android will show its standard warning. Only enable if comfortable. Capri asks for confirmation before typing, launching an app, or capturing a screenshot. Focus the destination app's text field yourself before using `type`.

## Build
Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17. Run `gradle assembleDebug`; APK output is `app/build/outputs/apk/debug/app-debug.apk`.

## Limits
This starter can launch apps visible in Android's launcher and type into a focused editable field when Accessibility is enabled. Some apps block text injection; secure fields, login screens, CAPTCHA, payments and protected content are not bypassed. Screenshots require Android 11+ and Accessibility permission. General AI chat and on-demand code generation require a secure AI backend; none is bundled and API keys should never be placed in the APK.


## Conversational chat update
Capri now has built-in responses for everyday greetings and small talk (for example, “hi” and “how’s your day?”). Ask “what should we play today?” and it randomly selects a launchable app from the phone's installed-app list, then asks before opening it. These local conversation responses do not require an API. This is still not a full AI language model; open-ended reasoning and generated code need an AI backend.


## Floating Capri and typing sounds
When the Capri App Control accessibility service is enabled, a small neon floating Capri button stays above other apps. Drag it to reposition it and tap it to return to Capri. Typing characters in the chat input plays a brief high-pitched chirp with a slightly randomized pitch for each character. The floating assistant requires the user to explicitly enable the accessibility service in Android Settings.


## First-launch name setup
On first launch, Capri asks what to call the user. The name is stored in the WebView's local persistent storage and reused on later launches. It can be changed at any time in Settings → Your name → CHANGE. Clearing app data or uninstalling the app can erase this local setting.


## Reset, photo gallery and photobombs (v2.1)
- **Settings → Reset Capri** (tap twice to confirm) forgets your saved name, clears the chat, wipes the gallery and shows the name prompt again.
- **Settings → Photo gallery → OPEN** starts a camera view. Android asks for camera permission the first time (and microphone permission the first time you record a clip). Use SNAP for photos, REC/STOP for video (2 minute cap) and the flip button for front/back camera.
- Photos and clips are kept **in memory only**. Nothing is written to storage, so they disappear when Capri restarts or the phone reboots.
- Every photo has a **1 in 25** chance that Capri photobombs it. Video clips are never photobombed.
- The Android back button closes the photo viewer/gallery before leaving the app.

