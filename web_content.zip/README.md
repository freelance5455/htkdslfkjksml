# Smart — ZIP-to-APK package

This ZIP is prepared with `index.html` at the ZIP root for a web-to-APK service.

It contains the complete current Smart web interface, command UI, local activity history, quick actions, and guidance for Android permissions.

IMPORTANT:
A ZIP-to-APK web wrapper cannot itself obtain Android Accessibility permission or control arbitrary other apps. Those capabilities require native Android code and explicit Android user permission. This package therefore does not falsely claim to provide unrestricted phone control.

Upload this ZIP to a service that specifically accepts a ZIP containing HTML/CSS/JS with index.html at the root.
