# SkinLab 3D — textura padrão atualizada

A textura padrão foi substituída pela última imagem 64x64 enviada pelo usuário (1001501161.png). A imagem anterior foi descartada.

- A textura é aplicada às faces do modelo 3D ao abrir o editor.
- O botão Restaurar chama `setup()` e recupera esta mesma textura.
- A imagem PNG original também fica em `app/src/main/assets/default_steve_skin.png`.
- O download/exportação PNG e a inicialização do modelo permanecem com as correções anteriores.

Projeto Android em código-fonte; o APK não foi compilado nem testado neste ambiente.
