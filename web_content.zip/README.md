# Stocklab Mini Offline — proyek Android

Game simulasi pasar saham offline mode Karier, kesulitan Normal.

## Isi
- `app/src/main/assets/index.html`: game lengkap, dapat dibuka langsung di browser.
- Folder Android Studio: WebView membungkus game lokal; tidak memuat situs eksternal.
- Saham: BANK, TELEKOMUNIKASI, INDUSTRI, KONSUMSI.
- Beli/jual, kejadian ekonomi, kartu aksi, portofolio, target karier, simpan progres lokal.

## Main langsung tanpa APK
Pindahkan `index.html` ke ponsel lalu buka dengan browser. Untuk menyimpan progres, izinkan penyimpanan situs lokal bila browser memintanya. Cara paling andal: pasang APK hasil build di bawah.

## Membuat APK yang bisa dipasang
1. Di komputer, pasang Android Studio dan Android SDK (API 35).
2. Ekstrak seluruh folder `StocklabMiniOffline`.
3. Android Studio → **Open** → pilih folder `StocklabMiniOffline` (folder yang berisi `settings.gradle`).
4. Tunggu Gradle Sync selesai. Build pertama mungkin perlu internet untuk mengunduh Android Gradle Plugin dan SDK; sesudah terpasang, game tidak membutuhkan internet untuk dimainkan.
5. Pilih **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.
7. Pindahkan APK ke Android, buka file tersebut, lalu izinkan instalasi dari sumber itu jika Android meminta.

## Catatan
- Proyek ini adalah prototipe edukasi buatan sendiri, bukan salinan resmi permainan komersial.
- Harga dan efek kartu disederhanakan untuk gameplay. Simulasi ini bukan saran investasi.
- Jika Android Studio menyarankan pembaruan plugin/SDK, ikuti petunjuknya lalu build ulang.
