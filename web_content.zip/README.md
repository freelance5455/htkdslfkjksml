# PACE X

A private, offline-first GPS fitness tracker for Android built with **HTML/CSS/vanilla JavaScript**, **Capacitor 6**, Leaflet, Chart.js, and small native Android Java services.

> **Privacy model:** no account, no sign-in, no advertising SDK, no analytics SDK, no cloud database, and no server. Workouts, profile, challenges, achievements and step history are held in Android app-private JSON files. GPS data leaves the device only when the user explicitly exports a JSON file.

## What is implemented

### Web app / UX

- Premium dark PACE X design system, responsive navigation and minimal motion logo.
- Splash, first-use onboarding, permission explanation, Home, Track, GPS prep, live/paused activity, summary, History, Details, Progress, Achievements, Challenges, Profile, Settings and data-deletion/export confirmations.
- Five-tab navigation: Home, Track, History, Progress and Profile.
- Home activity cards, animated daily-step ring, adjustable step goal, quick starts, weekly chart, streak, recent workout and personal best.
- Activity modes for running, walking and cycling.
- Live metrics: distance, duration, speed, average speed, average pace, estimated calories and GPS accuracy.
- Leaflet map with Street and key-free Esri Satellite base-layer choices, a neon route polyline, start/finish markers and a live current-position marker. The tracker continues to collect valid native GPS points if map tiles are unavailable; it does not draw a fake route without points.
- Haversine route distance and layered GPS quality filtering (25 m accuracy cap, accuracy-aware stationary-noise floor, duplicate rejection, impossible jump/speed limits and large speed-change rejection).
- Finish/cancel confirmation, review-before-save workout summary, speed chart, history filters, detail route map, delete and JSON export.
- 7/30/90/all-time charts for steps, distance and duration; records and good empty states.
- Local XP/levels, achievements, built-in personal challenges and custom private challenges.
- Profile data, unit preferences, permission guidance, backup export and permanent local-data deletion.

### Native Android capabilities

The Java code under `android/app/src/main/java/app/pacex/tracker/` contains functionality that is deliberately not implemented as a browser pedometer or browser background-Geolocation workaround:

- `PaceXLocationService` is an Android **location foreground service** using Google Fused Location Provider. It uses a persistent notification while a workout is active, saves an app-private active-session JSON snapshot as it records points, filters locations natively, and resumes a persisted active session when its process is recreated.
- `PaceXStepService` listens to **`Sensor.TYPE_STEP_COUNTER`**. `StepDataStore` turns reboot-relative cumulative values into daily totals with stored baselines. A lower counter value becomes a new baseline and adds **zero** invented steps.
- Step tracking is opt-in after Android `ACTIVITY_RECOGNITION` permission; when enabled it runs as a native foreground service and can be restarted after reboot by `StepBootReceiver`.
- `PaceXNativePlugin` exposes only the native functions the web UI needs: feature-based permission requests, current location, active tracking controls/restoration, steps, Android settings and an Android Storage Access Framework JSON export picker.
- `ACTION_CREATE_DOCUMENT` handles export without broad storage permission.

### Local files

On Android, Capacitor Filesystem and native services use the app-private data directory. The principal files are:

```text
pace-x-data/
  profile.json
  daily-steps.json
  workouts.json
  achievements.json
  challenges.json
  settings.json
  active-workout.json
  pending-workout.json
  active-workout-native.json       # foreground-service crash-recovery record
  step-service-enabled.json        # opt-in marker only
```

Writes use a temporary file followed by replacement wherever the platform API permits it. JSON parsing is defensive: a malformed file is contained and falls back to a safe state rather than crashing the UI. Exported files contain a schema label and timestamp.

## Prerequisites

- Node.js 20+ and npm
- Android Studio (current stable), Android SDK Platform 34, Build Tools 34, and an emulator or physical Android device
- **JDK 17** configured as `JAVA_HOME` for Android Gradle Plugin 8.2
- A device with Google Play services for the fused-location provider (most consumer Android devices have this)

## Install and run

```bash
cd pace-x
npm install
npm run sync:android
npm run open:android
```

Open the generated `android` folder in Android Studio, let Gradle install any requested SDK pieces, then choose an emulator/device and press **Run**.

Command-line debug APK:

```bash
npm run sync:android
npm run android:debug
# output: android/app/build/outputs/apk/debug/app-debug.apk
```

The exact project uses Android SDK 34 and target SDK 34. If your installed SDK is newer, Android Studio can update `compileSdkVersion`/`targetSdkVersion` after reviewing Android foreground-service policy changes.

## Build a release APK

A release build is unsigned until you provide your own signing key. Do not commit a keystore or its passwords.

1. Create/import a signing key in Android Studio: **Build → Generate Signed Bundle / APK**.
2. Select **APK**, the `release` variant and your private keystore.
3. Or add your own non-secret `keystore.properties` and signing configuration locally, then run:

```bash
npm run sync:android
npm run android:release
```

The unsigned output, if applicable, is `android/app/build/outputs/apk/release/app-release-unsigned.apk`. A signed release APK has intentionally **not** been included because no signing credentials were supplied.

## Permissions, timing and user explanation

| Permission / capability | Requested when | Why |
| --- | --- | --- |
| Fine/coarse location | GPS preparation or starting a workout | Route, distance, pace, speed and live map |
| Notifications (Android 13+) | Starting a workout | Foreground-service status notification |
| Activity recognition (Android 10+) | User enables native steps | `TYPE_STEP_COUNTER` daily step history |
| Background location | Only from the optional permission guidance screen | Android settings route for users who explicitly choose stronger background/recovery access |
| Foreground services | Declared, not a runtime dialog | Required by active location/opt-in health tracking services |
| Boot completed | Declared | Restarts only the previously opt-in step service after reboot |

If a permission is denied, PACE X leaves the rest of the app usable, explains the missing feature, and offers Android Settings. It never requests location, motion or notifications on the splash screen.

## Important Android background behaviour

The foreground service implementation is present in source, but reliable real-world operation is affected by Android version, device vendor battery rules and user permission choices. The source does **not** claim that it was physically device-tested in this workspace.

For a production release, test on physical Android 10, 11, 13 and 14+ devices after allowing the relevant permissions. On Android 11+, background-location choices are intentionally directed to system settings because Android requires that flow. Some OEM power managers can still delay or kill even a foreground service; document device-specific battery-unrestricted guidance only after testing it on that OEM.

## Technical notes

- **GPS:** Selecting an activity automatically requests a high-accuracy fix from the phone's GPS system. `PaceXLocationService` uses approximately 2-second / 2-metre minimum high-accuracy Fused Location sampling. Both native and JavaScript layers reject readings poorer than 25 m, stationary GPS noise and implausible transitions. Native route points are periodically persisted independently from the WebView.
- **Distance:** route distance is accumulated with Android `Location.distanceTo` natively and Haversine in the UI. The final UI retains its locally filtered route and merges any independently saved native points after a service-only interval.
- **Pace/speed:** pace is minutes per km/mile from elapsed active time and filtered distance; speed is km/h or mi/h. Paused time is excluded.
- **Steps:** Android’s step-counter reports steps since device reboot. `StepDataStore` increments daily JSON totals based on deltas and resets its baseline when the counter becomes lower after reboot. It never simulates unavailable sensor data.
- **Calories:** conservative MET/distance-based estimates depend on activity, duration, distance and optional profile weight. They are labelled estimates and not medical measurements.
- **Map:** Leaflet includes an in-map Street/Satellite layer switcher. Street is OpenStreetMap; Satellite is Esri World Imagery; both retain attribution. The map needs connectivity for tiles, but tracking itself does not need map-tile connectivity. Check each selected tile provider’s terms before a high-volume commercial distribution.
- **Storage:** Capacitor Filesystem uses app-private `Directory.Data`; no database or network storage is used.

## Testing checklist

### Completed in this workspace

- [x] `npm install`
- [x] Vendoring Leaflet and Chart.js for the Capacitor web bundle
- [x] `npm run sync:android`
- [x] JavaScript syntax check for `app.js`, `storage.js` and `native.js`
- [x] Source review of all native service/manifest/plugin paths

### Must be completed on a physical device before shipping

Functional:

- [ ] Complete onboarding and continue without setup.
- [ ] Start, pause, resume, finish, save, reopen and delete each activity mode.
- [ ] Change profile weight, units and daily step goal; relaunch and confirm persistence.
- [ ] Export an individual workout and all data through Android’s file picker; inspect JSON.
- [ ] Force-stop/reopen during an active route and validate recovery.

GPS:

- [ ] Grant precise location; verify a live marker/polyline and Haversine distance outdoors.
- [ ] Deny location; check graceful explanatory state and Android Settings flow.
- [ ] Test weak signal, poor accuracy, duplicate samples and a temporary GPS outage.
- [ ] Lock screen, switch apps and reopen during an active foreground-service workout.
- [ ] Test no-network map tiles: no fabricated route and GPS points still save.

Steps:

- [ ] On a sensor-equipped device, grant activity recognition and walk enough steps to verify native daily increment.
- [ ] Test unavailable sensor and denied permission messages.
- [ ] Reboot device and verify the next counter value establishes a fresh baseline without a false spike.
- [ ] Cross midnight and time-zone changes with service enabled; inspect `daily-steps.json`.
- [ ] Verify notification and reboot restoration behavior under the device vendor’s battery settings.

UI/reliability:

- [ ] Test phone/tablet widths, text scaling, long profile names and empty states.
- [ ] Check all navigation, history filters, charts, achievements and challenge progress.
- [ ] Test background service on Android 10/11/13/14+ physical devices.
- [ ] Build/verify a signed APK with the release keystore supplied by the distributor.

## Project layout

```text
pace-x/
  www/                         HTML/CSS/vanilla JS app
    js/app.js                  Screen rendering, tracking calculations and interactions
    js/storage.js              Capacitor Filesystem JSON storage + browser development fallback
    js/native.js               Native plugin bridge
    vendor/                    Vendored Leaflet and Chart.js assets
  android/app/src/main/
    AndroidManifest.xml        Android foreground-service and runtime permission declarations
    java/app/pacex/tracker/    Native plugin, GPS service, step service and JSON stores
  capacitor.config.json
  package.json
```

## Known limitations

1. **Physical-device testing is still required.** This environment did not provide Android SDK/JDK 17 or a physical Android device, so it could not produce or certify an APK or assert lock-screen/background behaviour. The foreground-service and native sensor code are implemented, but must be validated using the checklist above.
2. **Map tiles are online.** Route collection is offline-capable; a visible map base layer depends on the selected OpenStreetMap-compatible tile endpoint. No offline tile pack is bundled.
3. **No medical claims.** Calorie values and GPS-derived pace/speed are estimates subject to hardware, signal and user-profile variability.
4. **OEM battery policies vary.** Android foreground services substantially improve continuity but cannot override every manufacturer’s aggressive task killing policy.
5. **Android export is user-initiated.** The system document picker appears; PACE X does not silently write outside app-private storage.

## License / attribution

Add your product’s license before distribution. Leaflet is BSD-2-Clause. OpenStreetMap contributors require attribution, which is visible on the in-app map.
