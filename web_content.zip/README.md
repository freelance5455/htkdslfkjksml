# ILSOTRA Distribution — Android Studio project

This project wraps the supplied ILSOTRA mobile HTML app in a native Android WebView.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK is usually created at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- The app opens the local `app/src/main/assets/index.html` file.
- JavaScript and browser local storage are enabled for app functionality.
- Order data is stored locally on the device/browser storage; it is not cloud-synced.
- This is an Android Studio project source ZIP, not a compiled APK.
