# Kahani Studio — Mobile Web App

A no-build, static web app for generating a scene list from a story topic, previewing a simple cartoon stage, using browser Text-to-Speech, animating a character mouth while speech is playing, and exporting scene prompts to a text file.

## Run
- Extract the ZIP.
- Open `index.html` in a modern browser (Chrome recommended).
- For best voice support, use Chrome with Hindi voices available in Android settings. Some browsers restrict speech synthesis for local files; if so, run this folder from a local/static web server.

## Lip-sync limitation
The mouth animation is a visual timing approximation while the browser speech engine is speaking. It is **not phoneme-accurate AI lip sync** and does not export a rendered video. Real AI voices and full scene animation require a connected speech/video generation API and usually a backend API key. Never put private API keys in client-side HTML/JS.

## Files
- `index.html` — UI
- `src/style.css` — responsive layout and cartoon preview
- `src/app.js` — story scene generation, browser TTS, mouth animation, prompt/text export
- `manifest.webmanifest` — installable-app metadata
