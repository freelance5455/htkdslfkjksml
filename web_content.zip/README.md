# Shiksha Android App

This project packages the supplied MR. AKASH LABS HTML website into a native Android WebView app.

## Build APK
1. Open this folder in Android Studio.
2. Let Gradle sync/download the Android Gradle Plugin and SDK 35 if prompted.
3. Select **Build > Build APK(s)**.
4. The debug APK will be generated under `app/build/outputs/apk/debug/`.

## App
- Name: Shiksha: Your Education Friend
- Package: `com.mrakashlabs.shiksha`
- Portrait orientation
- JavaScript + local storage enabled
- External web links open in the device browser
- Android back button navigates WebView history

The original HTML is kept as `app/src/main/assets/index.html`.
