# Road Survey Manager — local-first PWA starter

## Run it
- Serve this folder from `localhost` or an HTTPS static host to enable installation and offline service-worker caching.
- On Android Chrome: open the hosted app, menu ⋮ → **Add to Home screen** / **Install app**.
- For a quick desktop preview, open `index.html`; browser storage works, but PWA install/offline caching require localhost or HTTPS.

## Local-only design
- Metadata and imported file blobs are stored in browser IndexedDB on the device.
- The app contains no login, cloud database, upload endpoint, analytics, or sync code.
- The system file picker supports multiple files and the browser keeps app-managed copies in local IndexedDB where storage permits.
- Browser storage is not the same as native Android private app storage. Android/Chrome may clear it, quotas vary, and very large files may fail.

## Important implementation limitations
- This is a working PWA starter, not a signed native APK.
- Android's Storage Access Framework and native content-provider APIs are not directly available to a web app. The browser file picker can import user-selected files but cannot freely crawl folders.
- JSON backups currently export metadata only; file bytes are deliberately not embedded. Keep separate copies of originals. Full ZIP backup, robust restore of binary files, native camera integration, Android share intents, and CAD/PDF viewer integration need additional implementation/testing.
- PDF preview uses the browser's built-in PDF support. DWG/DXF files are passed out as downloads; opening depends on a compatible installed app.
- Demo records are clearly labelled and do not contain real sample PDFs/images/CAD data.

## Next step for a true native Android app
Implement in Kotlin with Android Storage Access Framework (`ACTION_OPEN_DOCUMENT` with `EXTRA_ALLOW_MULTIPLE`), Room/SQLite, app-private files directory, `FileProvider`, Android Sharesheet, and a ZIP backup/restore workflow. This PWA is a useful functional prototype for the workflow but must not be represented as a native Android APK.
