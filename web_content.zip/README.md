# Petit Français – PWA

Offline-fähige Lern-App (Vokabeln aus „À toi!“ Band 1–3, Verben, Grammatik, Lernplan).

## Dateien
- `index.html` – die komplette App (Daten, Logik, Design)
- `sw.js` – Service Worker (Offline-Cache, optionale Erinnerung im Hintergrund)
- `manifest.webmanifest`, `icon.svg`, `assets/icons/*` – Installierbarkeit
- `assets/images/*` – Maskottchen (Katze, Hase, Bär), `assets/sounds/*` – Soundeffekte
- `capacitor.config.json` – Vorlage für eine Android-App (nicht gebaut/getestet)

## Installation
**Android (PWA):** Ordner auf einen Webserver mit HTTPS legen → in Chrome öffnen → Menü „App installieren“ / „Zum Startbildschirm“.
Service Worker und Installation funktionieren nur über `https://` oder `http://localhost`, nicht über `file://`.
**Desktop:** `python -m http.server` (oder `npx serve`) im Ordner starten und `http://localhost:8000` öffnen.
Ohne Server läuft die App auch per Doppelklick auf `index.html`, dann aber ohne Installation/Offline-Cache.
**Im bestehenden Projekt (client/):** `index.html` → `client/index.html`, alle anderen Dateien/Ordner → `client/public/`.
**APK (Capacitor):** `npm i @capacitor/core @capacitor/cli @capacitor/android @capacitor/local-notifications`, Dateien nach `www/` kopieren, `npx cap add android && npx cap sync && npx cap open android`. Dieser Weg wurde hier nicht ausprobiert.

## Erinnerungen – was technisch geht
- Echte Push-Nachrichten bei geschlossener App zur genauen Uhrzeit brauchen einen Push-Server (Web Push/VAPID) oder eine native App. Beides ist **nicht** enthalten.
- Funktioniert: Banner beim Öffnen; Hinweis zur Uhrzeit, solange die App offen ist; auf Chrome/Android mit installierter App eine experimentelle Hintergrund-Erinnerung (Zeitpunkt bestimmt Chrome).
- Exakte Uhrzeit: nur mit Capacitor + Local Notifications (Code vorhanden, ungetestet).

## Schrift
Patrick Hand ist **nicht** mitgeliefert (kein Download beim Bauen möglich). Lege `PatrickHand-Regular.woff2` nach `assets/fonts/` und ergänze in `index.html` eine `@font-face`-Regel, wenn du sie fest einbinden willst. Ohne Datei nutzt die App Segoe Print / Comic Sans / System-Handschrift.
