# ForgeFPS Ultra 1.0.0

Original black-and-white Android gaming utility. The implementation uses a lightweight custom Canvas UI so it does not require a UI framework dependency.

## Implemented
- ForgeFPS Ultra original monochrome branding and vector launcher icon.
- 1.75-second frame-progress intro with persistent startup setting and replay.
- Responsive phone/tablet/portrait/landscape custom UI.
- Dashboard, FPS Booster, Game Profiles, Theme Bubbles, Organized Wall, Settings and Game Tools.
- FPS modes: Standard, Performance, Maximum FPS, Custom.
- Targets: 60/90/120/144/165, Device Maximum and Uncapped request state.
- Per-app display refresh request using Android's supported display modes where the platform exposes them.
- Shizuku 13.1.5 API + Provider integration, binder state and user permission request callback.
- Battery-optimization settings handoff without silently disabling power saving.
- Persistent local game profiles, bubbles, wall order and preferences.
- User-controlled Android app settings/permission handoff.
- No copied TurboFPS Pro, Netflix, Apple, or other proprietary assets.

## Platform truth
An ordinary Android app cannot universally force another game's internal renderer to an arbitrary FPS. ForgeFPS Ultra therefore never fabricates an in-game FPS reading. The FPS target/uncap controls represent requested configuration and display capability; the actual game engine, Android version, OEM, thermal state and panel still control the final result.

The current build does not use Shizuku to silently modify another app. Shizuku is only authorized through its normal user-controlled permission flow.

## Build configuration
- AGP 8.7.3
- Gradle 8.9 required by AGP 8.7
- compileSdk 35
- targetSdk 35
- minSdk 26
- Java 17
- Shizuku API/provider 13.1.5

## Verification
This environment has Java 21 but no Android SDK, Android build-tools, Gradle executable, Gradle distribution cache, emulator, or ADB device. DNS/network access for downloading the missing Android/Gradle components is also unavailable. Therefore an APK cannot truthfully be claimed as compiled or device-tested here. The project files were created and reviewed, but compilation must be performed in an environment containing the official Android toolchain.

## Web UI integration
The ForgeFPS Ultra dashboard is bundled at `app/src/main/assets/index.html` and rendered by the native Android shell. The page remains offline-first and uses localStorage for its UI state. Android-only operations are exposed through the `ForgeAndroid` JavaScript bridge: Shizuku authorization, battery settings, application settings, and maximum refresh-rate requests. The browser version of `index.html` continues to work without that bridge.
