# Fly OS: Android uygulaması

Bu proje `www/index.html` içindeki Fly OS'u Capacitor ile Android uygulamasına çevirir.
`capacitor.config.json` içinde **CapacitorHttp** açıktır: uygulamadaki tüm `fetch` istekleri
tarayıcı yerine telefonun yerel HTTP katmanından geçer. Böylece CORS engeli olmaz ve
Fly Web, vekile gerek kalmadan çoğu siteyi doğrudan okur.

## Yol A: Telefondan, bilgisayarsız (GitHub ile)

1. github.com'da ücretsiz hesap aç, yeni bir **boş depo** oluştur (adı: `fly-os`).
2. Bu klasörün **içindekileri** depoya yükle (en önemlisi kökteki `index.html`; `www` klasörü yüklenmese de olur, akış onu kendisi oluşturur) (Add file > Upload files).
   `.github` klasörünün de yüklendiğinden emin ol. Yüklemede gizli klasör görünmezse
   bilgisayardan ya da GitHub'ın web düzenleyicisinden `.github/workflows/apk.yml`
   dosyasını elle oluşturup içeriği yapıştır.
3. Depoda **Actions** sekmesine gir, **APK derle** akışını seç, **Run workflow**'a bas.
4. 4 ila 8 dakika sonra akış bitince en alttaki **Artifacts** bölümünden `fly-os-apk`
   dosyasını indir, zip'in içinden `app-debug.apk`'yı çıkar.
5. APK'ya dokunup kur. "Bilinmeyen kaynaklara izin ver" diye sorarsa izin ver.

## Yol B: Bilgisayarda

Gerekenler: Node 18+, JDK 17, Android Studio (ya da Android SDK).

```
npm install
npx cap add android
npx cap sync android
npx cap open android      # Android Studio açılır, Run ile telefona kur
```

## Fly OS'u güncellemek

`www/index.html` dosyasını yeni `fly-os.html` ile değiştir, depoya yükle ve akışı
yeniden çalıştır (Yol A) ya da `npx cap sync android` yap (Yol B).

## Notlar

- Üretilen APK "debug" sürümüdür: kendi telefonunda kullanmak için yeterlidir,
  Play Store'a yüklemek için imzalı sürüm gerekir.
- "Gömülü aç" (iframe) hâlâ sitelerin kendi X-Frame-Options korumasına takılır.
  Fly Web'in okuma görünümü ise CORS'a takılmadığı için çalışır.
- Instagram, YouTube gibi giriş isteyen ve JS ile çizilen siteler yine tam açılmaz.
