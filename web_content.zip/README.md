# Contractor Pro V18.0.0 — Global (App + Server)

- `app/index.html` — the APK-ready app (put `app/` contents in your HTML-to-APK tool; root `index.html` required).
- `server/` — Termux/VPS server 1.2.0 (`node server/server.js`). See `server/` env vars in the previous README notes below.
- `docs/ARCHITECTURE.md` — architecture, sync model, security, limits, roadmap.

## Quick start (phone only, Termux)
```sh
pkg install nodejs && cd contractor-pro && node server/server.js
```
In the app: Settings > Cloud & Sync > set *Server endpoint* `http://<phone-ip>:8787`, enable sync, **Connect & Sync**.
Dev OTP codes are printed in the Termux console. For internet use put the server behind HTTPS (Android blocks cleartext
to public hosts) and set `CP_JWT_SECRET`, `CP_ADMIN_KEY`, `CP_CORS_ORIGIN`, `CP_TRUST_PROXY=1`.

## Tests
`npm test` · `npm i -D playwright && npx playwright install chromium && npm run test:e2e`

Env: `PORT HOST CP_DATA_FILE CP_JWT_SECRET CP_ADMIN_KEY CP_CORS_ORIGIN CP_PUBLIC_BASE_URL CP_OTP_MODE CP_TRUST_PROXY CP_MAX_BODY_MB CP_SYNC_KEEP CP_OTP_IP_LIMIT CP_OTP_VERIFY_LIMIT`
