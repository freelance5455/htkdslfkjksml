# JoelPanel

Standalone frontend/backend gaming-style UI.

## Run
1. Install Node.js.
2. In this folder run `npm install`
3. Run `npm start`
4. Open `http://localhost:3000`

The feature switches are UI-only and do not modify, inject into, bypass, or interact with any game.
