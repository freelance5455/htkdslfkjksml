# GO GO GO — FUZAIL Android Studio Project

This project packages the supplied GO GO GO HTML game into an Android WebView app.

## Open in Android Studio
1. Extract this ZIP.
2. Open the extracted folder in Android Studio.
3. Let Gradle sync.
4. Connect an Android phone or start an emulator.
5. Run the `app` configuration.

## Build an APK
Android Studio:
Build > Build Bundle(s) / APK(s) > Build APK(s)

The generated debug APK will normally be under:
app/build/outputs/apk/debug/

## App details
- App name: GO GO GO
- Package: com.fuzail.gogogo
- Developer branding: FUZAIL
- Minimum Android: 6.0 (API 23)
- Target SDK: 35
- Game assets: app/src/main/assets/index.html
- JavaScript and DOM storage are enabled for the game's local progress.

The original HTML game logic and presentation are kept as the app's bundled web asset.
