# MindMate AI — Offline Qwen integration starter

This ZIP is an integration starter for a **React Native source project**. It is not an installable APK and cannot be applied directly to a compiled `base.apk`.

## Files
- `OfflineAIModelManager.js`: downloads, checks, loads, and runs a local GGUF model.
- `ManualModeAndDownloadExamples.js`: example manual Online/Offline selector and model download UI.

## Install dependencies in your React Native project
```bash
npm install react-native-fs llama.rn
```
Then follow the native installation/build instructions for the exact versions of `react-native-fs` and `llama.rn` you install. Rebuild the Android app; these native modules cannot be added by editing an APK.

## Integrate
1. Copy `OfflineAIModelManager.js` into your app's source folder.
2. Copy/adapt the selector and download components from `ManualModeAndDownloadExamples.js`.
3. Add a mode state in your chat screen: `online` or `offline`.
4. In the send-message handler, call `OfflineAIModelManager.generate(text, onToken)` only when the user selected `offline`.
5. Keep your existing Gemini call only in the `online` branch. Do not add automatic switching.
6. Add an Offline Model screen where the user can download the model over Wi-Fi/mobile data.
7. Test on a real Android device with enough free storage and RAM.

## Important limitations
- The model download is large (roughly around 1 GB; exact size can change). Show storage/download errors to the user.
- A 1.5B model can be slow on lower-end phones and may use substantial RAM. This starter uses `n_gpu_layers: 0` for broad compatibility; GPU offload requires a compatible native build/device and testing.
- The Qwen prompt template is for a single user turn. For proper multi-turn chat, pass conversation history using the chat API supported by your installed `llama.rn` version, or build the full Qwen chat template from stored messages.
- Confirm the `completion()` callback and `release()` API against the installed `llama.rn` version; package APIs can change.
- Never put a Gemini API key in a public client build. Use secure key handling or a backend proxy.
- Only download model weights from a trusted source and review the model's license/terms before distribution.
