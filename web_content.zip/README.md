# Dawa — Android app with background adhan

## أسهل طريقة لبناء الـ APK (من غير Android Studio)
1. اعمل repo جديد على GitHub وارفع محتويات هذا المجلد كلها (بما فيها `.github`).
2. افتح تبويب **Actions** ← **Build APK** ← انتظر (≈5 دقايق).
3. نزّل الملف من **Artifacts → Dawa-apk** (جواه `app-debug.apk`) وثبّته.

> التطبيق متوقّع بمفتاح debug مختلف عن الـ APK القديم، فاحذف النسخة القديمة قبل التثبيت.

## تعديل الواجهة
الواجهة في `app/src/main/assets/web/index.html`.
