# PrivateVault

PrivateVault is a simple private vault web app.

## Run
1. Install Node.js.
2. Open this folder in a terminal.
3. Run:
   `npm install`
4. Then:
   `npm run dev`

## Important
Vault entries are encrypted with AES-GCM using a password-derived key and stored locally in the browser. This is a project implementation, not a substitute for a professionally audited password manager. If the password is lost, the vault cannot be recovered.
