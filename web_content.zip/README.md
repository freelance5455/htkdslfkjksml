# Vibe AI v4 — APK/WebView

Эта версия рассчитана на упаковку HTML/CSS/JS в Android APK.

Что изменено:
- встроенный OpenRouter API-ключ;
- режим «Использовать свой API-ключ»;
- голос → текст;
- загрузка фото;
- история чатов;
- темы;
- админ-панель;
- закрытие бокового меню свайпом;
- убраны необязательные `HTTP-Referer` / `X-Title` из API-запроса;
- добавлена кнопка проверки соединения с OpenRouter;
- ошибка `Failed to fetch` преобразуется в понятное сообщение о проблеме WebView/сети.

OpenRouter API использует POST /api/v1/chat/completions с Authorization Bearer и Content-Type application/json.

ВАЖНО ДЛЯ APK:
Если ваш конструктор APK делает приложение из local HTML/WebView, он должен разрешать интернет-доступ. Для Android проекта обычно требуется:
<uses-permission android:name="android.permission.INTERNET" />

Если после этого остаётся `Failed to fetch`, причина находится в настройках самого APK-конструктора/WebView, а не в HTML-файле: он должен разрешать сетевые HTTPS-запросы из локального WebView.

Фото требуют multimodal/vision модель OpenRouter.

Встроенный API-ключ намеренно находится в script.js по запросу владельца приложения. Любой пользователь APK теоретически сможет извлечь этот ключ.
