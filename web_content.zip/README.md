# TalkMate — Real-time Calling Prototype

This version adds real-time peer-to-peer voice/video calling using WebRTC through PeerJS.

TEST:
1. Host the `www` folder on HTTPS (camera/microphone permissions normally require a secure origin).
2. Open it on two phones.
3. Each phone gets a different Call ID.
4. On phone A press Voice/Video and enter phone B's Call ID.
5. Allow microphone/camera permissions.
6. End the call with the red phone button.

IMPORTANT:
- This is a prototype, not a production calling service.
- It does not include login, payments, moderation, call history, push notifications, or a private signaling infrastructure.
- For a production app, use a proper authenticated backend and a managed WebRTC/calling provider or your own signaling/TURN infrastructure.
- Never collect payment or sensitive personal information until authentication, security, privacy, and legal requirements are implemented.
