# JARVIS (Android, sab features ek project mein)

## Build (Android Code Studio / Android Studio)
1. Zip extract karo, project folder kholo.
2. Build > Build APK. Install karo.
3. App kholo, phir ⚙ Settings mein:
   - Gemini API key daalo (aistudio.google.com)
   - Phone control: Accessibility ON karo
   - Notification access ON karo
   - Brightness control ON karo
   - Message padh ke batao: ON (optional, API use badhta hai)
   - Wake word ON karo (optional, foreground service)
4. Termux ke liye: ~/.termux/termux.properties mein allow-external-apps=true likho, Termux restart karo.

## Kya kaise bolna hai
- Chhoti baatein: "hi", "bore ho raha hoon", "mood badlo"
- Phone: "youtube pe arijit singh chalao", "spotify pe kesariya bajao", "aage", "peeche", "pause", "volume badhao", "torch on", "battery kitni hai", "brightness 50"
- Calls/SMS/WhatsApp: "rahul ko call karo", "rahul ko sms bhejo ...", "rahul ko whatsapp message bhejo ...". JARVIS pehle "haan" maangega.
- Notifications: "notification padho", "reply: kal milte hain" (haan se bhejega)
- Yaad: "yaad rakho ...", "kya yaad hai", "note karo ...", "mere notes"
- Camera: "ye kya hai" (photo lekar batayega)
- Files: "pdf banao <topic>", "word banao <topic>", "excel banao <topic>"
- Image: "image banao <kuch>"
- Monster: "monster kholo", "monster band karo"
- Termux: "termux install python", "termux mein <command>" (haan se chalega)

## Limitations
- Ye code compile/test nahi hua. Build error aaye to uska message dena.
- Wake word Hindi mein phone ke speech recognizer par depend karta hai.
- Cohere/ChatGPT, Edge-TTS, desktop Maya functions abhi nahi hain.
- Gemini ki accuracy 100% nahi hai. Sensitive kaam (call, message) user ki confirmation se hi hote hain.

## v2 naye commands
- "play store pe <app> install karo" / "<app> download karo": Play Store search khulega, install aap tap karenge
- "google se <app> apk dhoondo": Google par official APK ka search khulega (download aap khud karenge)
- "aaj ki photos dikhao": latest photos ki list
- "photo delete karo" / "3 photos delete karo": pehle "haan" maangega, phir Android ka confirmation popup
- "photo WhatsApp par bhejo": WhatsApp share screen khulegi, contact aap chunenge
- "photo lo": camera khulega, photo aap click karenge

Safety: Jarvis bina aapki confirmation ke na delete karta hai, na kisi ko message bhejta hai, na APK install karta hai.
Note: Ye code Android SDK ke bina test nahi hua hai. Build error aaye to message bhejiye.

## v4 (final) — kya badla
- API key ab encrypted store (EncryptedSharedPreferences) mein hai. Purani plain-text key apne aap migrate ho jaati hai.
- Gemini key URL mein nahi, header (x-goog-api-key) mein jaati hai.
- Gemini model band ho to agla model apne aap try hota hai (gemini-2.0-flash -> gemini-1.5-flash).
- Gemini errors ka saaf message: key galat, limit khatam, server busy, etc.
- Chat history app band hone ke baad bhi yaad rehti hai (last 40 messages).
- Hindi awaaz na mile to English awaaz par fallback, aur chat mein batata hai ki Hindi data install karo.
- Unit tests: Persona (mood tag parse) aur LocalBrain. Chalane ke liye: ./gradlew test

## Pehle se aaye features (v2, v3)
- Play Store search, Google par APK search (download aap karte hain), photos dekhna/delete (Android confirmation ke saath), photo WhatsApp par share (contact aap chunte hain), photo lena.
- Home page: red monster (vision core) poori screen par, neeche type box aur mic. Jawab bolkar aur likh kar dono.
- HOME category: Jarvis ko default launcher bana sakte hain.

## Abhi bhi baaki (code se nahi hoga)
- Ye code Android SDK ke bina compile/test nahi hua. Pehli build par error aa sakte hain, unhe theek karna hoga.
- Play Store par publish ke liye SMS, Call log, Accessibility aur Notification permissions ka policy declaration zaroori hai.
- Release build mein minify/ProGuard band hai. Publish se pehle enable karke test karein.
- Strings (Hinglish) code mein hard-coded hain, multi-language ke liye strings.xml mein shift karna baaki hai.
- Accessibility service sirf phone control ke liye hai; screen content padhne ka code abhi khaali hai.
- Termux wali neural awaaz (edge-tts) Android app mein nahi hai, yahan phone ka TTS hai.
