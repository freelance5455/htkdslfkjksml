# PokeChile — versión HTML/CSS/JavaScript

Esta carpeta contiene una web estática, no un proyecto Expo: `index.html`, `styles.css`, `app.js` y `manifest.json`.

## Abrir
Para probar el diseño, abre `index.html` en un navegador moderno. Para usar `fetch` contra la API sin restricciones del navegador, normalmente conviene servirlo en HTTPS o mediante servidor local.

## API
La web deja introducir la API key en Ajustes y la guarda en `localStorage` de ese navegador. No he incluido ninguna clave en los archivos. Las claves de API incrustadas en frontend son visibles para cualquiera que use la web; no publiques una clave real así. Como la clave se compartió en el chat, se recomienda rotarla.

La integración de ejemplo intenta consultar `https://api.pkmnprices.com/v1/cards` y `/cards/{id}` con la cabecera `X-API-Key`. Antes de producción, confirma en la documentación de tu cuenta de PkmnPrices los endpoints, campos y permisos exactos: https://www.pkmnprices.com/es/docs

## Convertir a APK
HTML no se convierte directamente en APK instalable sin envolverlo. Opciones:
- Capacitor: añadir un proyecto Android y compilar con Android Studio.
- PWA: alojar en HTTPS y permitir instalar desde el navegador; no genera necesariamente un APK.
- Para un APK firmado, usa Android Studio/Gradle con un WebView o Capacitor.

Los tipos de cambio USD_CLP y EUR_CLP en `app.js` son valores de ejemplo. Los precios son referencias internacionales convertidas, no precios verificados de tiendas chilenas. La cobertura de español depende de tu plan.
