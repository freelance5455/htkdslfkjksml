# Ajuda Eventos Magyver — versão GitHub Pages

Esta versão foi adaptada para funcionar como site estático no GitHub Pages.

## O que foi corrigido
- Login e cadastro não dependem mais de `/api/...` no GitHub Pages.
- Dados do aplicativo são armazenados no `localStorage` do navegador.
- Caminho da imagem do emblema foi ajustado para funcionar em GitHub Pages.
- QR Code PIX usa geração no navegador através de um serviço de imagem externo.
- O botão de teste de e-mail informa corretamente que envio SMTP automático precisa de backend.

## Como publicar
1. Substitua o `index.html` do seu repositório por este.
2. Mantenha `static/emblema-magyver.png` dentro da pasta `static`.
3. Em Settings > Pages, use a ramificação `principal` e a pasta `/(raiz)`.
4. Abra o endereço do GitHub Pages e faça um novo cadastro.

Observação: como o GitHub Pages não executa o `server.py`, recursos que exigem servidor (como envio SMTP automático) não funcionam nesta versão estática.
