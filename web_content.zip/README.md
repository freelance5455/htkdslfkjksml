# MOHALLA (محلہ) - Trusted Local Services Marketplace for Pakistan

> **"Trusted Services. Right Nearby."**  
> Karachi-first, expanding to Lahore, Islamabad, and nationwide.

---

## 🌟 Overview

**Mohalla** is an on-demand, trusted local-services marketplace engineered specifically for Pakistan. It directly connects customers with verified local technicians (electricians, plumbers, AC specialists, auto mechanics, home cleaners, carpenters, etc.) with real-time distance proximity, "Available Now" instant dispatch, transparent Trust Scores, bilingual English/Urdu support, and cash-on-completion guarantees.

---

## 🏗️ Project Architecture & Folder Structure

```
├── /src
│   ├── /components
│   │   ├── /admin
│   │   │   └── AdminDashboard.tsx        # Verification queue, commission rates, categories, safety reports
│   │   ├── /chat
│   │   │   └── ChatModal.tsx             # Booking-linked chat, quick Pakistani coordination chips
│   │   ├── /common
│   │   │   ├── Header.tsx                # Brand, Karachi neighborhood selector, language, role switcher
│   │   │   ├── ReportModal.tsx           # Incident & fraud reporting to admin
│   │   │   └── TrustScoreModal.tsx       # Algorithmic trust score transparency breakdown
│   │   ├── /customer
│   │   │   ├── BookingModal.tsx          # Booking request with problem symptoms, time slots, photo upload
│   │   │   ├── BookingTracker.tsx        # Real-time job lifecycle stepper (PENDING -> ARRIVING -> COMPLETED)
│   │   │   ├── CategoryList.tsx          # Responsive service categories with live provider counts
│   │   │   ├── EmergencyBanner.tsx       # 🚨 Urgent rapid response SOS modal (15-min dispatch)
│   │   │   ├── ProviderCard.tsx          # Provider card with distance (km), rating, visit fee, available badge
│   │   │   └── ProviderDetailModal.tsx   # Detailed provider profile with portfolio, reviews & schedule
│   │   ├── /provider
│   │   │   └── ProviderDashboard.tsx     # "Available Now" toggle, job accept/decline, billing settlement
│   │   └── /reviews
│   │       └── ReviewModal.tsx           # 1-5 star verified reviews, praise tags, customer comments
│   ├── /context
│   │   └── MohallaContext.tsx            # Global state, booking state machine, localStorage sync
│   ├── /data
│   │   └── mockData.ts                   # Realistic Karachi providers, initial bookings, reviews, categories
│   ├── /types
│   │   └── index.ts                      # Domain models, enums, status steps
│   ├── /utils
│   │   ├── geo.ts                        # Haversine distance calculations, Karachi neighborhoods coordinates
│   │   └── i18n.ts                       # Bilingual English & Urdu (اردو) translation dictionary
│   ├── App.tsx                           # Main application controller & bottom mobile navigation
│   ├── index.css                         # Tailwind CSS base and typography
│   └── main.tsx                          # React 19 entry point
├── /schema.sql                           # Full PostgreSQL relational schema with indexes & enums
├── index.html                            # HTML entry with Plus Jakarta Sans & Noto Sans Arabic fonts
├── metadata.json                         # AI Studio applet metadata
├── package.json                          # App dependencies & scripts
└── tsconfig.json                         # TypeScript configuration
```

---

## ⚡ Core Features

1. **Nearby Proximity & Karachi Coverage**:
   - Built-in coordinates for Karachi neighborhoods (Gulshan-e-Iqbal, Clifton, DHA, PECHS, North Nazimabad, Gulistan-e-Jauhar, Saddar, Federal B Area, Korangi, Bahria Town, Malir Cantt).
   - Real-time Haversine distance calculation (e.g. `1.2 km away`).

2. **Available Now Toggle**:
   - Providers toggle their live availability with 1 tap.
   - Customers can filter solely for technicians who are ready to head out immediately.

3. **Trust & Verification**:
   - Masked CNIC representation (`42101-*******-3`) prevents sensitive data exposure.
   - Admin moderation queue for reviewing and approving government identity documents.
   - Transparent **Trust Score (e.g. 96/100)** broken down by verification (+30), rating (+40), completed volume (+20), and punctuality (+10).

4. **Complete Marketplace Booking Lifecycle**:
   - `PENDING` ➔ Provider gets request with distance and symptom details.
   - `ACCEPTED` ➔ Provider confirms and prepares toolkit.
   - `ARRIVING` ➔ Provider is on motorcycle en route.
   - `IN_PROGRESS` ➔ Diagnostic and repair underway.
   - `COMPLETED` ➔ Provider enters spare parts/extra charges, system calculates platform commission and net take-home, cash collected.
   - `REVIEW` ➔ Verified customer leaves 1–5 star rating and feedback tags.

5. **Urgent Emergency Dispatch (🚨 SOS)**:
   - Priority booking for electrical short circuits, bursting water pipes, and vehicle breakdowns.

6. **In-App Messaging**:
   - Direct coordination between customer and provider without exposing raw personal numbers before booking acceptance.

7. **Bilingual Localization**:
   - Instant toggle between English and Urdu (اردو) with RTL typography.

---

## 🔐 Complete Three-Tier Authentication System

Mohalla features server-authoritative role-based authentication with password hashing (`crypto.scryptSync`) and secure Bearer token sessions.

### Default Test Accounts

| Role | Email / Phone | Password | Capabilities |
| :--- | :--- | :--- | :--- |
| **Customer** | `ahmed.tariq@gmail.com` (or `0300-8245199`) | `Customer@123` | Book services, track arrival, in-app chat, rate & review |
| **Technician (Provider)** | `ali.electrician@mohalla.pk` (or `0321-9456781`) | `Provider@123` | Toggle "Available Now", accept/reject jobs, job stepper, earnings wallet |
| **Admin Operations** | `admin@mohalla.pk` | `Admin@Mohalla2026` | KYC verification approval, platform commission rate, categories, safety reports |

---

## 🛡️ Secure Admin Configuration

To ensure absolute security:
1. **Never commit raw admin credentials to public git repositories or client code.**
2. Admin passwords are authenticated purely on the Express server (`server.ts`).
3. Set your custom initial admin credentials in `.env`:

```env
ADMIN_EMAIL="your_operations_email@mohalla.pk"
ADMIN_PASSWORD="YourStrongCustomAdminPassword_2026!"
SESSION_SECRET="generate_a_random_32_character_string_here"
```

4. **Public registration as Admin is strictly blocked (HTTP 403)**. Ordinary users can only create Customer or Service Provider accounts.

---

## 📱 How to Build Android APK (Free-Tier, No Play Store Required)

You can package Mohalla into a standalone native Android `.apk` file that installs directly on any Android smartphone without paying Google Play Console developer fees.

### Method 1: Using Capacitor (Recommended - 100% Free & Open Source)

1. **Install Capacitor CLI**:
```bash
npm install @capacitor/core
npm install -D @capacitor/cli @capacitor/android
```

2. **Initialize Capacitor in Mohalla**:
```bash
npx cap init "Mohalla" "pk.mohalla.app" --web-dir dist
```

3. **Build the production web assets**:
```bash
npm run build
```

4. **Add Android platform**:
```bash
npx cap add android
npx cap sync
```

5. **Build the Debug or Release APK using Gradle**:
```bash
cd android
./gradlew assembleDebug
```
The output APK is generated at:
`android/app/build/outputs/apk/debug/app-debug.apk`

---

## 📲 How to Install the APK on Your Android Phone

1. **Enable Unknown Sources**:
   - On your Android phone, go to **Settings** ➔ **Security** (or **Apps & Notifications**).
   - Enable **"Install Unknown Apps"** for Files, WhatsApp, or Chrome.
2. **Transfer the APK to your phone**:
   - Via USB cable to your phone's *Download* folder.
   - Or send it to yourself via WhatsApp / Telegram / Google Drive.
   - Or use ADB from terminal:
     ```bash
     adb install android/app/build/outputs/apk/debug/app-debug.apk
     ```
3. **Open and Install**:
   - Tap on `app-debug.apk` on your phone and tap **Install**.
   - Mohalla will install with the native app icon and full mobile viewport presence!

---

## 🚀 Running Locally

```bash
# 1. Install dependencies
npm install

# 2. Run Full-Stack dev server (Express + Vite)
npm run dev

# 3. Access in browser
http://localhost:3000
```

