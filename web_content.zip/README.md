# Khandaghosh Saw Mill Android App — Photo Measurement Reader

Offline Android WebView app for log CFT and cutting-charge calculations.

## Features
- Manual entry of log length and girth, with multiple rows and total CFT / cutting charge.
- Default cutting rate ₹55 per CFT (editable).
- Select or take a photo of a measurement page.
- On-device Google ML Kit Latin text recognition; photos are processed on the phone and are not uploaded.
- Measurement-row extraction for common notations such as `12-6 x 2-4`, `12'6" x 2'4"`, `12 6 x 2 4`, and table rows containing four numeric cells (optionally preceded by a row number).
- EXIF camera orientation correction before OCR.
- Recognized text and extracted measurements are shown for review and correction.
- Print / Save PDF through Android print service.

## CFT calculation
The app uses: `CFT = length in feet × girth in inches² ÷ 2304`. Length and girth are each entered as feet plus inches. Girth means the full circumference around the log. Confirm that this is the measurement convention used by your sawmill before billing.

## Accuracy and limitations — please read
This is an **offline OCR-assisted reader**, not a trained sawmill-specific handwriting AI and not a measuring instrument. OCR may confuse handwritten digits, page columns, faint marks, or unusual notation. The reader deliberately does not invent values when it cannot confidently identify a complete row. Always compare every populated row with the original photograph and correct it before relying on CFT or charges. A photograph cannot establish the physical log's true dimensions.

## Build
Requirements: JDK 17, Android SDK Platform 35 / Build Tools 35.0.0, and Gradle 8.9.

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`. A GitHub Actions workflow is included to build a debug APK.
