# RAYNOX AI — Minimalist Executive Full-Stack Project

RAYNOX AI is a complete, full-stack personal AI assistant featuring a **Node.js backend** (`server.js` + `/api/health.js` + `/api/chat.js`) connected to **Google Gemini (`gemini-3.5-flash` / `gemini-3.5-flash-lite`)**, and a responsive mobile-first frontend (`index.html`, `style.css`, `script.js`) at the project root that connects to its own backend endpoint automatically without requiring manual URL entry.

---

## 1. Root File Structure

- `index.html` — Root entry point UI (Minimalist Executive theme, scrollable Settings modal, Test Ping card, Chat, Voice, IST Calendar, Device Tools)
- `style.css` — Responsive stylesheet (mobile-safe scrollable modals, non-overlapping header close button, connection status pills)
- `script.js` — Frontend client logic (automatic built-in `/api/health` & `/api/chat` discovery across same-origin and local ports `127.0.0.1:3000` / `localhost:3000` / `10.0.2.2:3000`, duplicate-submit lock, Hindi/Hinglish/English STT & TTS)
- `server.js` — Complete Node.js & Serverless backend (`GET /api/health`, `POST /api/chat`, `POST /api/chat/stream`, CORS support, IP rate limiting, static file serving)
- `api/health.js` & `api/chat.js` — Serverless API route delegates for zero-config Vercel deployment
- `package.json` — Node.js project manifest (`npm start` runs `node server.js`)
- `.env.example` — Server environment variable template (`GEMINI_API_KEY=MY_GEMINI_API_KEY`)
- `render.yaml` & `vercel.json` — Cloud deployment configurations for Render and Vercel
- `manifest.json` & `icon.png` — PWA manifest and 512x512 app icon

---

## 2. How Automatic Backend Connection Works (No Manual URL Required)

The frontend (`script.js`) is pre-configured to connect to the application's own backend automatically:
1. **Same-Origin Automatic Mode (`/api/health` & `/api/chat`):** When the project is started with `npm start` (`node server.js`) or deployed on Render/Vercel/Railway, `server.js` serves both `index.html` and the `/api/*` endpoints from the same origin. The app connects automatically on startup.
2. **Automatic Local Discovery (`127.0.0.1:3000`, `localhost:3000`, `10.0.2.2:3000`):** When opened from an Android WebView, local preview server, or emulator while the local backend (`node server.js` or the Android app's built-in `LocalBackendServer` on `127.0.0.1:3000`) is running, `script.js` automatically detects and locks onto the active local backend without asking the user to enter a URL.
3. **Zero Frontend Secrets:** `GEMINI_API_KEY` is read strictly on the server from `process.env.GEMINI_API_KEY` (`.env`) and is never placed in `index.html`, `script.js`, or `localStorage`.

---

## 3. Running Locally (`npm start`)

1. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
2. Open `.env` and set your Google Gemini API key (from [https://aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey)):
   ```env
   GEMINI_API_KEY=your_real_gemini_api_key_here
   PORT=3000
   ```
3. Start the built-in server:
   ```bash
   npm start
   ```
4. Open `http://localhost:3000` in your browser.
   - The app automatically connects to `/api/health` and `/api/chat` with **Connected** status.

---

## 4. Full-Stack Cloud Deployment (Render or Vercel)

If you want to host the full project online so it works from anywhere without running `node server.js` locally:

1. Push this project folder to a GitHub repository.
2. Connect the repository to **Render** (Web Service) or **Vercel** (`render.yaml` and `vercel.json` are pre-configured).
3. In the hosting dashboard's **Environment Variables** section, add:
   - Key: `GEMINI_API_KEY`
   - Value: *(Your Google Gemini API Key)*
4. Deploy the service. Opening the deployed app URL serves both `index.html` and `/api/chat` from the same server automatically — no backend URL needs to be typed in the app.

---

## 5. HTML-to-APK Converter Notes

- Static HTML-to-APK converters only bundle `index.html`, `style.css`, and `script.js` inside an Android WebView (`file://`) and cannot execute Node.js (`server.js`) by themselves.
- **Automatic Local Mode on Android:** When the native Raynox AI Android app (or Termux running `node server.js`) is active on the device, it runs a local backend on `http://127.0.0.1:3000`. The HTML-to-APK app automatically discovers `http://127.0.0.1:3000/api/health` and connects without any manual URL input.
- **Full-Stack Hosted Mode:** If you deploy the project on Render or Vercel (Section 4), use your deployed URL in your APK wrapper so the frontend and `/api/chat` backend run on the same origin automatically.
