# CLASH 2.0 – Android source starter

This is a Firebase-backed Android-ready starter for a **free community tournament app**. Cash deposits, paid entries, cash withdrawals and cash prizes are intentionally not implemented. Wallet figures are non-transferable demo reward points only.

## Included
- Email/password sign-up and login
- Player profile fields (name, username, game UID/name, mobile, gender, DOB, optional referral)
- Tournament list and free join flow
- My Contests
- Reward-points wallet summary
- Admin-only tournament creation and announcements
- Firestore security rules and Capacitor Android wrapper

## 1. Create Firebase project
1. Create a project in Firebase Console.
2. Add a Web App and copy its config into `src/firebase.js`.
3. Enable **Authentication > Email/Password**.
4. Create **Cloud Firestore** in production mode.
5. Publish `firestore.rules` in Firestore Rules.
6. In Authentication settings, configure authorized domains if you host the web build.

## 2. Install and test
Install Node.js (18+ recommended) and Android Studio on a computer:
```bash
npm install
npm run dev
```
Open the local Vite address to test in a browser.

## 3. Build Android project
```bash
npm run build
npx cap add android
npx cap sync android
npx cap open android
```
In Android Studio, build a debug APK using **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
For later web-code changes:
```bash
npm run build
npx cap sync android
```
The generated Android project is in `android/`. This source ZIP does not contain a prebuilt/signed APK.

## 4. Give admin access safely
Do not add an `isAdmin` field from the client and do not allow users to promote themselves. After creating the admin account, use a trusted private environment with Firebase Admin SDK and set a custom claim:
```js
await getAuth().setCustomUserClaims("FIREBASE_AUTH_UID", { admin: true });
```
Then sign out and sign in again (or refresh the ID token). Never put Firebase Admin SDK credentials in this app.

## 5. Important implementation notes
- Admin role is checked using Firebase Authentication custom claims.
- For production, move tournament joining and joined-count changes into a trusted Cloud Function. Firestore client transactions alone are not sufficient protection against all abuse.
- Add server-side validation, App Check, rate limits, backups, audit logs and abuse reporting before public release.
- Room ID/password release is not included in this starter. Implement it through a server-verified participant-only endpoint; never expose room credentials in public tournament documents.
- Username sign-in is not included; users sign in with their registered email. Usernames are unique profile identifiers.
- DOB and mobile are personal data. Collect only what is necessary, publish a privacy policy, restrict staff access, and obtain appropriate parent/guardian involvement and legal review before launching to minors.
- Do not connect real-money payment or withdrawal services without qualified legal review, eligible adult/business ownership and provider approval.
