# Counter CM — Fixed HTML/WebView Package

Entry point utama: `index.html` (langsung di root project).

Jika APK builder meminta folder website/HTML, gunakan folder yang berisi:
- `index.html`
- `manifest.json`

Fungsi:
- Hasil Baik = Baik Sekarang - Baik Sebelumnya
- Hasil Jelek = Jelek Sekarang - Jelek Sebelumnya
- Hasil = Hasil Baik + Hasil Jelek
- Persentase Baik = Hasil Baik / Hasil × 100%
- Persentase Jelek = Hasil Jelek / Hasil × 100%
- Tombol JUMLAH menampilkan hasil
- Tombol RESET mengosongkan input
- Tidak membutuhkan internet

Entry point sengaja dipindahkan dari `web/index.html` menjadi `index.html` untuk menghindari error `appassets.androidplatform.net/web/index.html`.
