# YouTube SEO Studio Pro

A responsive YouTube thumbnail + SEO assistant with:
- Thumbnail score (AI estimate, 0-100)
- SEO score (AI estimate, 0-100)
- Title, description, tags, hashtags and category
- Focus keywords, alternative titles and improvement suggestions
- Copy buttons for every output section
- YouTube URL support for watch, Shorts, youtu.be, embed and live URLs

## Requirements
- Node.js 18 or newer
- An Anthropic API key. API usage may be paid; this is not an unlimited free AI service.

## Run locally
1. Extract the ZIP.
2. Open a terminal in the extracted folder.
3. Run: `npm install`
4. Set your API key as an environment variable (do not paste it into `public/index.html`).

macOS/Linux:
```bash
export ANTHROPIC_API_KEY="your_key_here"
npm start
```

Windows PowerShell:
```powershell
$env:ANTHROPIC_API_KEY="your_key_here"
npm start
```

5. Open `http://localhost:3000`.

## Deploy
Deploy the project to a Node.js host that supports environment variables. Set `ANTHROPIC_API_KEY` in the host's secret/environment settings, then run `npm start`.

## Security
The API key is used only by `server.js` and is never sent to the browser. Do not commit `.env` or publish your API key. For public deployments, add rate limiting and authentication before sharing the app widely.

## Notes
- Scores are AI-generated estimates, not official YouTube metrics and not predictions of CTR, views or ranking.
- The model analyzes the thumbnail only. It cannot reliably infer the full video contents, so review generated metadata for accuracy before publishing.
- Thumbnail score assesses visible design qualities such as focal point, contrast and text readability; it does not measure actual audience response.
