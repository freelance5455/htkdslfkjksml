# TailleurPro Android

Projet Capacitor Android de TailleurPro.

## Migration Supabase obligatoire pour le logo atelier
Dans Supabase > SQL Editor, exécuter une fois : `TAILLEURPRO_MIGRATION_LOGO.sql`.
Elle ajoute `logo_url` à `public.ateliers`.

Le build utilise Capacitor 8.5.2 et conserve le deep link `tailleurpro://auth/callback`.


## Correctif synchronisation owner_id (2026-10-09)
- Les payloads clients, commandes et paiements incluent `owner_id` de l’utilisateur Supabase authentifié.
- Les UUID des clients sont stabilisés avant synchronisation et les références de commande sont remappées.
- La connexion restaure la sauvegarde locale associée à l’e-mail avant la lecture serveur.
- La lecture fusionne les enregistrements serveur avec les données locales et ne remplace pas les collections locales par une réponse vide ou une erreur.
- La synchronisation remonte les erreurs d’écriture précises; le pull-to-refresh exécute écriture puis lecture.
