# BD BLOOD DONATION
> **"রক্তের প্রয়োজনে, পাশে আছি আমরা।"**

**Developer:** Ibna Mahmud Robin  
**Developer Email:** [robinokh@gmail.com](mailto:robinokh@gmail.com)  
**Android Package Name:** `com.ibnamahmudrobin.bdblooddonation`  
**Firebase Project ID:** `bd-blood-dontion`  
**Firebase Android App ID:** `1:279297430175:android:a33ae4b047aa072be088aa`  
**Firebase iOS App ID:** `1:279297430175:ios:5aa9dd54bf4d1c4fe088aa`  
**Version:** 1.0.0 Production Release  

---

## 🩸 Overview
**BD BLOOD DONATION** is a complete, real-world, production-ready blood donation application built specifically for Bangladesh. It connects voluntary blood donors with patients and recipients in critical need across all 8 divisions and 64 districts of Bangladesh.

The application is built with a clean, high-performance **HTML5 + CSS3 + Vanilla JavaScript (ES6+ modular architecture)** frontend packaged with **Capacitor** for native Android and iOS apps, powered by a real **Firebase** backend.

---

## ✨ Key Features

1. **Authentication System:**
   - Email & Password Registration & Login
   - Google Account Sign-In
   - Password Reset via Email
   - Persistent Firebase Authentication Session
   - Safe Logout & Profile Management

2. **Accurate Bangladesh Location Hierarchy:**
   - 8 Divisions: Dhaka, Chattogram, Rajshahi, Khulna, Barishal, Sylhet, Rangpur, Mymensingh
   - All 64 Districts
   - Complete Upazila & Thana mappings
   - Bilingual (English & Bengali) display names and standardized matching keys

3. **Real-Time Blood Matching & Instant Push Notification:**
   - Matches blood group compatibility (e.g. O- universal donor, matching identical antigens)
   - Matches requested District and Upazila
   - Filters only available, active donors
   - Excludes the requester and blocked users
   - Real-time in-app and FCM push notifications

4. **Emergency Blood Request:**
   - One-tap Urgent Emergency Request trigger
   - High-priority notification broadcast
   - Pulsating emergency badges & red alert styling

5. **Donor Directory & Smart Search:**
   - Interactive blood group pills (A+, A-, B+, B-, AB+, AB-, O+, O-)
   - Division, District, and Upazila dependent dropdowns
   - Availability filter
   - Donor cards with ratings, verified donation count, direct call (`tel:`) and chat triggers

6. **In-App Real-Time Chat:**
   - Direct, secure donor-to-requester chat using Cloud Firestore listeners (`onSnapshot`)
   - Unread message counters and real-time message notifications
   - Conversation history

7. **Verified Donation History & Rating Enforcement:**
   - Verified completion workflow: donation counts only increment when confirmed by the recipient
   - 1-5 Star Ratings and authentic feedback reviews
   - Mandatory rating enforcement: recipients must review their donor before posting subsequent requests

8. **Safety, Report & Block System:**
   - Report fake donors, fraud, or inappropriate behavior
   - Block users to prevent unwanted interactions

9. **Google AdMob Integration:**
   - Non-intrusive banner advertisements
   - Configured with official test ad unit IDs for development and ready for production IDs

10. **Bilingual & Dark Mode Support:**
    - Seamless 1-tap language switch (বাংলা ↔ English)
    - Full Light and Dark Mode theme support

---

## 📁 Project Structure

```
bd-blood-donation/
├── index.html                   # Mobile-first app shell
├── manifest.json                # PWA Web App Manifest
├── capacitor.config.json        # Capacitor configuration (Android/iOS)
├── package.json                 # Dependencies & build scripts
├── README.md                    # Project documentation
├── bd-blood-donation.zip        # Complete downloadable project archive
├── public/
│   ├── google-services.json     # Android Firebase configuration
│   ├── GoogleService-Info.plist # iOS Firebase configuration
│   └── service-worker.js        # Offline caching & push notifications
├── css/
│   ├── style.css                # Global base styles, theme variables
│   ├── components.css           # Buttons, cards, modals, form controls
│   ├── auth.css                 # Login, register, forgot password
│   ├── dashboard.css            # Home dashboard, donor cards, chat
│   ├── responsive.css           # Desktop device frame & mobile reflow
│   └── dark-mode.css            # Dark mode theme overrides
├── js/
│   ├── firebase-config.js       # Real Firebase modular initialization
│   ├── app.js                   # Main application router & controller
│   ├── auth.js                  # Firebase Auth & Google Sign-In
│   ├── auth-views.js            # Login & Register views
│   ├── location.js              # 64 Bangladesh Districts & Upazilas dataset
│   ├── home.js                  # Home Dashboard view
│   ├── donor-search.js          # Donor directory & search view
│   ├── blood-request.js         # Blood request creation & matching
│   ├── my-requests.js           # Request tracking & rating modal
│   ├── chat.js                  # Real-time In-App Chat
│   ├── notifications.js         # Notification Center
│   ├── rating.js                # Rating & Review submission
│   ├── donation-history.js      # Verified donation history & badges
│   ├── profile.js               # Profile editing & safety reporting
│   ├── ads.js                   # Google AdMob banner integration
│   ├── export-zip.js            # In-browser full project ZIP exporter
│   └── utils.js                 # Helpers, i18n dictionary, validators
├── firebase/
│   ├── firestore.rules          # Production security rules
│   ├── storage.rules            # Firebase Storage security rules
│   └── firestore.indexes.json   # Composite indexes configuration
└── functions/
    ├── package.json             # Cloud Functions dependencies
    └── index.js                 # Server-side matching & FCM trigger
```

---

## 🚀 Deployment & Build Guide

### 1. Web Deployment (Firebase Hosting)
```bash
# 1. Install Firebase CLI
npm install -g firebase-tools

# 2. Login to your Firebase account
firebase login

# 3. Select your existing Firebase project
firebase use bd-blood-dontion

# 4. Build web production bundle
npm run build

# 5. Deploy Firestore Rules, Storage Rules, and Hosting
firebase deploy --only firestore:rules,storage,hosting
```

---

### 2. Android APK & AAB Build (Capacitor)

#### Step 1: Add Android Platform
```bash
npx cap add android
```

#### Step 2: Ensure `google-services.json` is in Place
Copy `public/google-services.json` into `android/app/google-services.json`:
```bash
cp public/google-services.json android/app/google-services.json
```

#### Step 3: Build & Sync
```bash
npm run build
npx cap sync android
```

#### Step 4: Open in Android Studio
```bash
npx cap open android
```

#### Step 5: Build Debug APK / Release APK
- In Android Studio:
  - **Debug APK:** `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`
  - **Release APK:** `Build` → `Generate Signed Bundle / APK...` → Select `APK` → Choose your Keystore → Select `release` → Click `Finish`.
- Output APK location:
  `android/app/build/outputs/apk/release/app-release.apk`

#### Step 6: Build Android App Bundle (AAB) for Google Play Store
- In Android Studio:
  - `Build` → `Generate Signed Bundle / APK...` → Select `Android App Bundle` → Choose your Keystore → Click `Finish`.
- Output AAB location:
  `android/app/build/outputs/bundle/release/app-release.aab`

---

### 3. iOS App Build (Capacitor)

#### Step 1: Add iOS Platform
```bash
npx cap add ios
```

#### Step 2: Ensure `GoogleService-Info.plist` is in Place
Copy `public/GoogleService-Info.plist` into `ios/App/App/GoogleService-Info.plist`:
```bash
cp public/GoogleService-Info.plist ios/App/App/GoogleService-Info.plist
```

#### Step 3: Sync and Open in Xcode
```bash
npm run build
npx cap sync ios
npx cap open ios
```

#### Step 4: Archive in Xcode
- In Xcode, select `Any iOS Device (arm64)`.
- Choose `Product` → `Archive`.
- Follow the Organizer prompts to distribute to the Apple App Store or Ad-Hoc testing.

---

### 4. Deploying Cloud Functions (FCM & Real-Time Matching)

```bash
cd functions
npm install
cd ..
firebase deploy --only functions
```

---

## 👨‍💻 Developer Information
- **Name:** Ibna Mahmud Robin
- **Email:** [robinokh@gmail.com](mailto:robinokh@gmail.com)
- **Tagline:** রক্তের প্রয়োজনে, পাশে আছি আমরা।
- **Platform:** BD BLOOD DONATION

Made with dedication and heart to save human lives in Bangladesh.
