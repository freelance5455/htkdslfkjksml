# ANAS BEST WAY TO SUCCESS ACADEMY — Hybrid APK starter

This is a starter project, **not a compiled APK**. It requires Firebase configuration and a build environment.

## 1. Configure Firebase
1. In Firebase Console, open Project settings → Your apps → the registered Web app.
2. Copy the `firebaseConfig` values.
3. Edit `www/index.html` and replace every `REPLACE_WITH_...` value.
4. In Authentication, enable Email/Password.
5. In Firestore, publish `firestore.rules` using Firebase Console → Firestore Database → Rules.
6. Create an administrator role document in the `admins` collection whose document ID is the administrator's Firebase Authentication UID. Do this only as the project owner using trusted tooling; never make admin-role writes public.
7. Create a `users/{uid}` profile if you want a profile list. Do not store plain-text passwords.

## 2. Build the Android APK
Requires Node.js/npm and Android Studio on a computer:
1. Unzip this folder.
2. In the folder run: `npm install`
3. Run: `npx cap add android`
4. Run: `npx cap sync android`
5. Run: `npx cap open android`
6. In Android Studio, build a debug APK using Build → Build Bundle(s) / APK(s) → Build APK(s).

Official docs: https://capacitorjs.com/docs/android and https://firebase.google.com/docs/web/setup

## Important limitations
- This starter demonstrates Firebase email/password login, lesson-note reads/publishing, local caching, and result saving.
- It is not a finished school management system. The current student list requires profile documents, and administrator provisioning must be done securely.
- Offline local records do not automatically merge to cloud in every case; robust conflict handling, durable sync queue, CBT/theory workflow, class-based authorization, and production testing still need implementation.
- Firestore web offline persistence can require HTTPS and may not work in every WebView configuration. Test on the target Android device.
- Never put service-account keys or private credentials in the app.
- Do not use real student data until you have tested security rules and privacy protections.
