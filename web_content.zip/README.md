# Japan Quiz

Japan Quiz is a mobile-first, installable PWA. It includes 300 questions across 12 categories, seven game modes, local player progression, achievements, settings, and an on-device leaderboard.

## Run locally

Serve this folder over HTTP (service workers require `localhost` or HTTPS):

```powershell
python -m http.server 8000
```

Open `http://localhost:8000` in a browser. On Android Chrome, use **Install app** or **Add to Home screen** from the browser menu. The app shell and question bank are cached for offline play; progress is saved in the browser's local storage on that device.

## Notes

- Leaderboards are local personal rankings; there is no online account or backend.
- Quiz content and interface are currently in English. The language preference is saved locally.
- This project is a PWA, not a native Android package; APK generation is not configured.
