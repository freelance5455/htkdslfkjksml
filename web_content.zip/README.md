# Shanju (শানজু) - SaaS E-Commerce Platform

A high-performance modern multi-tenant SaaS e-commerce platform built with React 19, TypeScript, Vite, and Tailwind CSS.
Includes Merchant Stores, Storefront Customizer, Order Management, Customer Checkout, Super Admin Dashboard, and Payment Gateway configurations (AamarPay, Shohoz Pay, ShurjoPay, bKash, Nagad, Rocket).

---

## 🚀 Quick Start (Local Development)

### 1. Install Node.js
Make sure you have Node.js 18+ or 20+ installed on your computer.

### 2. Extract & Install Dependencies
Open your terminal in the extracted project folder:
```bash
npm install
```

### 3. Run Development Server
```bash
npm run dev
```
Open your browser at `http://localhost:3000`.

---

## 📦 Production Build & Deployment

### Build for Production:
```bash
npm run build
```
This generates an optimized, minified `dist/` directory ready to upload to any web hosting!

---

## 🌐 How to Deploy to Web Hosting

### Option 1: cPanel / Shared Hosting / Namecheap / Hostinger
1. Run `npm run build` locally (or download the pre-built `shanju-production-dist.zip`).
2. Log into your **cPanel** and open **File Manager**.
3. Go to `public_html` (or your subdomain folder).
4. Upload all files from the `dist/` folder directly into `public_html`.
5. Ensure `.htaccess` is present for Single Page Application routing (already included in this guide).

### Option 2: Vercel (Free & 1-Click)
1. Push this project to GitHub or GitLab.
2. Go to [vercel.com](https://vercel.com) and import the repository.
3. Framework Preset: **Vite**
4. Click **Deploy**. Vercel will build and assign your custom domain with free SSL!

### Option 3: Netlify (Drag & Drop)
1. Go to [netlify.com](https://netlify.com).
2. Simply drag & drop the `dist/` folder into the Netlify Sites dashboard.
3. Your website is live in seconds with HTTPS!

### Option 4: Cloudflare Pages
1. Log in to Cloudflare Dashboard -> Pages.
2. Connect your Git repository.
3. Build command: `npm run build`, Build directory: `dist`.
4. Deploy!

---

## 📄 License & Ownership
Full ownership belongs to the project owner. You may customize, deploy, and scale as needed.
