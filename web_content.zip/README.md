# Creator Toolkit

AI-powered productivity workspace for short-form creators (YouTube, YouTube Shorts, TikTok, Instagram Reels).

**Core promise:** create better content in minutes.

## Feature map

| Tool | Route | Plan |
| --- | --- | --- |
| Viral Title Generator | `/create?tool=titles` | Free |
| Hook Generator (3s, curiosity, story, fear, educational, controversy) | `/create?tool=hooks` | Free |
| AI Script Writer (15s / 30s / 60s / long-form) | `/create?tool=scripts` | 60s = Creator, long-form = Pro |
| Caption Generator (short, emotional, funny, suspenseful, professional) | `/create?tool=captions` | Free |
| Hashtag Generator | `/create?tool=hashtags` | Free |
| Thumbnail Text Generator | `/create?tool=thumbnail` | Free |
| Content Idea Engine (11+ niches) | `/ideas` | Free |
| Content Calendar (7 / 30 / 90 day) | `/calendar` | Creator |
| Content Analyzer | `/analyze` | Pro |

Everything a user generates can be copied, saved to their library, edited and deleted.

## Architecture

- **Next.js App Router** (server components for data, client components for interaction)
- **Drizzle ORM + PostgreSQL** — `src/db/schema.ts`
- **Auth** — scrypt password hashing, httpOnly session cookies (`src/lib/auth`)
- **AI layer** — `src/lib/ai/*`
  - `tools.ts` — single registry of tools, inputs, plan gating and credit cost. Add an entry and the UI, API and admin dashboard pick it up.
  - `prompts`/`generate.ts` — structured prompts with strict JSON output coercion (`coerceOutput`) so the UI always receives a predictable shape.
  - `provider.ts` — server-only provider abstraction. Keys are **never** exposed to the browser.
  - `fallback.ts` — deterministic template engine so all features work without an API key.
- **Usage limits** — `src/lib/usage.ts`. Credits are reserved inside a transaction that locks the user row (`FOR UPDATE`) and a per-minute burst limit blocks request spam, so refreshing or firing parallel requests cannot bypass limits.

## Environment variables

| Variable | Purpose |
| --- | --- |
| `DATABASE_URL` | PostgreSQL connection string (required) |
| `OPENAI_API_KEY` / `OPENAI_MODEL` / `OPENAI_BASE_URL` | Any OpenAI-compatible provider |
| `ANTHROPIC_API_KEY` / `ANTHROPIC_MODEL` / `ANTHROPIC_BASE_URL` | Anthropic Messages API |
| `ADMIN_EMAIL` / `ADMIN_PASSWORD` | Seeded admin account (defaults `admin@creatortoolkit.app` / `Admin12345`) |
| `ENABLE_DEMO_BILLING` | Set to `false` to disable the demo checkout endpoint |

If no AI key is present the app runs on the template engine (`engine: "template"`), which keeps every feature functional for demos and tests.

## Billing

Plans live in the `plans` table and are fully editable from `/admin` (name, price, monthly limit, feature bullets, availability). Subscriptions are recorded in `subscriptions`; swap `activateSubscription` in `src/lib/plans.ts` for a Stripe webhook in production.

Generated output is always labelled as a suggestion — the product never claims guaranteed views or virality.

## Local commands

```bash
npx drizzle-kit push   # apply schema
npm run build          # production build
npm start              # start server
```
