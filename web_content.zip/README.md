# صيد الهدف — مشروع Android

هذا مشروع Android جاهز لتغليف لعبة HTML داخل تطبيق أندرويد.

## المتطلبات
- Android Studio حديث
- Android SDK
- اتصال إنترنت أول مرة لتنزيل Gradle/Android Gradle Plugin

## البناء
1. افتح مجلد `صيد_الهدف_Android` في Android Studio.
2. انتظر Gradle Sync.
3. اختر Build > Build APK(s).
4. ستجد APK التجريبي داخل:
   `app/build/outputs/apk/debug/`

التطبيق يعمل بدون إنترنت لأن اللعبة موجودة داخل `assets`.
