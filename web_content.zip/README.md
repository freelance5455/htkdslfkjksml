# ZIP to APK Studio v2.0 (Premium UI)

Dark glass-style UI, gradient hero, status card with colour states, new app icon, safe-area (edge-to-edge) support.
Scan logic, ZIP safety limits and HTML preview are unchanged. No ads, no network permission.

## APK baniye nebar 2 upay
**A) Phone/browser theke (PC lagbe na):** ei folder GitHub repo-te upload koro -> Actions tab -> "Build APK" -> Run workflow ->
shesh hole Artifacts theke `app-debug.apk` download koro.

**B) Android Studio (PC):** folder open -> Gradle sync (JDK 17, SDK 35) -> Build > Build APK(s).
Output: `app/build/outputs/apk/debug/app-debug.apk`

`index.html` (root) = web version of the same screen, so HTML-to-APK converters and the in-app scan both find an index.html.

Note: minSdk 26 (Android 8.0+). A ZIP itself cannot be converted to an APK on the phone; this app only scans and previews.
