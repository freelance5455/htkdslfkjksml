# MasterFlow Trading — Scanner Semua Saham

Web-mobile APK package untuk MasterFlow Trading.

## Scanner universe
- Indonesia: seluruh saham IDX/BEI yang dikembalikan backend/provider
- Amerika: seluruh saham NYSE/NASDAQ yang dikembalikan backend/provider
- Hong Kong, Jepang, Singapura
- Global: gabungan semua pasar yang didukung backend

Mode tanpa backend hanya demo beberapa ticker. Untuk benar-benar memindai SEMUA saham, backend `/scan?market=...&universe=all` wajib terhubung ke provider data pasar berlisensi dan mengembalikan universe lengkap + data harga/volume/indikator.

Tidak ada auto-order, cancel order, withdrawal, atau transfer dana.
