# TaskApp — Beginner Starter

Features planned:
- Add task
- Mark task complete
- Delete task
- Task list
- Local saving

This starter contains a simple working web version. Open `index.html` in a browser.
