# Súper Útil — Versión 0.3 — hábitos y calendario

Aplicación personal para celular y tablet Android, con selección de español/inglés (algunas etiquetas de esta primera versión continúan en español), con temas Lavanda, Rosa, Salvia, Oscuro y Crema. Incluye agenda y tareas, presupuesto por moneda, registro de humor, medicamentos, hábitos y frases diarias.

## Cambios de la versión 0.3

- Corregido el botón **Marcar realizado/Desmarcar**, y disponible una casilla para cada hábito. El registro queda asociado a la fecha seleccionada.
- En **Agenda**, los días con hábitos realizados muestran un indicador verde ✓ (con cantidad si hay más de uno). Un punto lavanda señala hábitos pendientes y otro punto identifica tareas.
- Al tocar cualquier día del calendario, se abre una lista de hábitos previstos y tareas de esa fecha, que pueden marcarse.
- Al crear hábitos hay un selector con 18 sugerencias, opción personalizada y programación diaria o semanal (con día de la semana).
- Corregida la interacción de las casillas de tareas; se preserva el almacenamiento y el formato de copias de versiones previas.
- Se actualizaron las versiones de recursos para reducir problemas con archivos en caché de Netlify y el service worker.

## Estado actual y limitaciones importantes

- **Esta entrega no es un archivo APK**: es el código completo de una **PWA** (aplicación web instalable) con configuración de Capacitor para compilarla como APK mediante Android Studio.
- Los registros se guardan en `localStorage` **en este dispositivo/navegador**; **NO existe sincronización entre tablet y celular ni cuenta en la nube** en esta versión. Exportar/importar JSON permite trasladar los datos manualmente.
- Las notificaciones de medicamentos de esta versión se emiten **solo cuando la aplicación está abierta**. No pueden garantizar recordatorios con la app cerrada. Necesitan permiso de notificaciones y un origen seguro (`https` o `localhost`). Medicamentos semanales y según necesidad no activan alarma; solo los diarios.
- La moneda se selecciona desde Ajustes. Cada movimiento conserva la moneda con la que fue registrado y los resúmenes únicamente suman movimientos de la moneda seleccionada: **NO realiza conversión de divisas ni usa cotizaciones automáticas**. Los presupuestos son independientes por moneda.
- Es una versión inicial para evaluación personal, no un sistema sanitario. No almacenes datos que requieran confidencialidad elevada en un dispositivo compartido. No sustituye indicaciones médicas.

## Probar en una computadora

Desde la carpeta del proyecto ejecuta `python -m http.server 8080` y abre `http://localhost:8080`. No abras el HTML con `file://` si quieres funciones PWA.

## Instalar la PWA en Android

1. Sube el contenido de la carpeta a un hosting con **HTTPS** (por ejemplo, un servicio de alojamiento de sitios estáticos).
2. Abre la URL en Chrome de tu Android y selecciona **Instalar aplicación** o **Añadir a pantalla de inicio**.
3. La interfaz se adapta a celular y tablet. La sincronización entre dispositivos no está disponible todavía.

## Compilar un APK con Android Studio + Capacitor

En una computadora con **Node.js**, **Android Studio** y el **Android SDK** configurados:

```bash
npm install
npm run prepare:web
npx cap add android
npx cap sync android
npx cap open android
```

Android Studio → **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Normalmente se genera bajo `android/app/build/outputs/apk/debug/app-debug.apk`. El APK será de prueba, no una versión lista para publicar en Google Play.

**Importante:** envolver el sitio en Capacitor no implementa las notificaciones fiables en segundo plano ni la sincronización; esas funciones requieren desarrollo adicional con APIs nativas y un backend seguro, respectivamente.

## Archivos

- `index.html`, `styles.css`, `app.js`: aplicación completa.
- `manifest.webmanifest`, `sw.js`: instalabilidad y caché offline de la PWA.
- `icons/`: iconos de la marca.
- `package.json`, `capacitor.config.json`: preparación de APK mediante Capacitor.

## Cambios v0.2 (20 nov 2026)
- Los hábitos ahora tienen un botón claro **Marcar realizado**, que cambia a **Realizado ✓** al pulsarlo. Pulsar de nuevo deshace la marca.
- El progreso diario se actualiza y el historial se conserva mediante la misma clave localStorage `superutil-v1` (no se eliminan los registros existentes).
- Se cambió la estrategia de caché del service worker para recuperar la versión actualizada de Netlify cuando haya conexión.
- **Despliegue:** vuelve a publicar el contenido de `super-util-app` en el mismo sitio de Netlify (no uses un sitio nuevo si quieres mantener los datos de ese dominio). Si ves el diseño anterior, cierra y vuelve a abrir la pestaña, recarga y comprueba si aparece el botón «Marcar realizado». Antes de cualquier cambio de dominio, exporta tus datos desde Ajustes.

## Actualizar tu sitio existente en Netlify

1. Antes de actualizar, entra en **Ajustes → Exportar copia de seguridad (JSON)** de la versión actual, por precaución.
2. En Netlify despliega el contenido de la carpeta `super-util-app` **en el mismo sitio y dominio** que ya usabas.
3. Recarga la web. Si sigue mostrando la versión anterior, haz una recarga forzada o elimina la caché del sitio (sin borrar sus datos locales).
4. Prueba crear un hábito, marcarlo y abrir Agenda.

**Importante:** No crees un sitio nuevo si quieres conservar automáticamente tus datos de `localStorage`; el almacenamiento depende del dominio. El proyecto sigue sin ser un archivo APK.


## v0.5 — Medicamentos y recordatorios
- Acceso a Medicamentos (✚) desde la barra inferior en Android.
- Crear y editar medicamentos, dosis, hora, frecuencia diaria/semanal y activar recordatorio.
- Panel visible de avisos, estado de permisos y botón de prueba.
- Registro de tomas y recordatorios programados del día.
- **Limitación de seguridad:** los avisos JavaScript funcionan únicamente mientras la web esté abierta y activa. Una APK empaquetada con un conversor HTML/WebView tampoco garantiza notificaciones locales con la app cerrada. Para recordatorios fiables se necesita implementación nativa con notificaciones locales y permisos Android. No se debe depender de esta versión para medicación esencial.
- Los datos permanecen localmente en el navegador; exportar copia antes de cambiar de dominio o instalar APK.
