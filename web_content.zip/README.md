# Ledger – Personal Expense Tracker

Files: index.html (the app), config.js (your Supabase keys), setup.sql (database + security).

## Setup (about 10 minutes)
1. Create a free project at supabase.com.
2. SQL Editor → New query → paste all of setup.sql → Run. This creates the tables, Row Level Security and the signup trigger.
3. Project Settings → API: copy the Project URL and the anon public key into config.js.
4. Authentication → URL Configuration: set Site URL to where you host the app (for example https://yourname.netlify.app). Add the same address under Redirect URLs. This makes password-reset emails work.
5. Host the folder: drag it onto netlify.com/drop, or use Vercel / GitHub Pages. For a quick local test, run `python3 -m http.server` in this folder and open http://localhost:8000 (add that address to Redirect URLs).
6. Optional: Authentication → Providers → Email → turn off "Confirm email" if you want to log in right after signing up.

## Security notes
- Only the public anon key is used in the browser. RLS policies in setup.sql restrict every table to rows where user_id = the logged-in user.
- Never paste the service_role key anywhere in this folder.

## How numbers work
- Remaining balance = income - expenses. Savings rate = (income - expenses) / income.
- Recurring items count once on their start date and again on every repeat date up to today.
- Budgets apply from the month you set them until you change them.
