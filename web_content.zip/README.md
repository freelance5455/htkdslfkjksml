# NABD Messenger UI
واجهة ويب تجريبية لـ NABD مستوحاة من تخطيط تطبيقات المحادثة، مع هوية وألوان NABD الخاصة.
افتح `index.html` في Chrome.
