# Programme de musculation — Android

Application Android hors ligne qui affiche les cinq pages HTML fournies. Les liens entre les séances restent dans l'application et le bouton Retour Android revient à la page précédente.

## Générer l'APK

Ouvrir ce dossier dans Android Studio avec un JDK 17 et le SDK Android 35 installés, puis choisir **Build > Build Bundle(s) / APK(s) > Build APK(s)**. En ligne de commande, depuis ce dossier, lancer `gradle assembleDebug` avec Gradle 8.9 et un JDK 17. L'APK debug apparaîtra dans `app/build/outputs/apk/debug/app-debug.apk`.

Configuration : Android 6.0 minimum (API 23), cible API 35. Aucun accès réseau n'est demandé.
