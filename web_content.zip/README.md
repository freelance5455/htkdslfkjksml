# RadLedger v2

ساختار: `www/` (اپ)، `worker/` (سرور لایسنس + ربات تلگرام)، `tools/gen-keys.mjs`، `test/`، `.github/workflows/`.

## ۱) Worker (Cloudflare)
1. محتوای `worker/worker.js` را در Worker پیست کنید (دیگر هیچ رمزی داخل فایل نیست).
2. Settings ▸ Variables and Secrets:
   - `BOT_TOKEN` (Secret) · `WEBHOOK_SECRET` (Secret) · `SIGN_KEY` (Secret، کل JSON کلید خصوصی) · `ADMIN_ID` (Text)
3. Bindings ▸ KV با نام `DB`.
4. (اختیاری) Triggers ▸ Cron: `0 5 * * *` برای گزارش روزانهٔ انقضا.
5. یک‌بار باز کنید: `https://<worker>.workers.dev/setup?key=<WEBHOOK_SECRET>`

## ۲) اپ و APK
1. `www/config.js` ← `api` را با آدرس Worker پر کنید (بیلد بدون آن متوقف می‌شود).
2. همهٔ فایل‌ها (با `.github`) را در گیت‌هاب بگذارید ▸ Actions ▸ Build RadLedger APK ▸ Run workflow (تیک Release برای لینک دانلود).
3. کلید امضای `resources/debug.keystore` را عوض نکنید؛ در غیر این صورت نسخهٔ جدید روی قبلی نصب نمی‌شود.

## تست
`node test/run.mjs`

## چرخش کلیدها (توصیهٔ امنیتی)
- توکن ربات: BotFather ▸ `/revoke` ▸ توکن جدید در `BOT_TOKEN`.
- کلید امضا: `node tools/gen-keys.mjs` ▸ `SIGN_KEY` جدید در Cloudflare و `pub` جدید در `config.js` ▸ APK جدید پخش شود.
