# Instagram Signup Queue Dashboard

## Purpose
A mobile-friendly queue for manually completing official Instagram signup flows.

Workflow:
Email List -> Pending -> Start Signup -> Manual OTP/CAPTCHA -> Completed -> Next Email

## Important
This prototype does NOT:
- bypass OTP/CAPTCHA
- bypass rate limits or anti-bot controls
- automatically create accounts without user verification
- store Instagram passwords or OTPs

## Run
Backend:
  cd backend
  pip install fastapi uvicorn pydantic[email]
  uvicorn app:app --host 0.0.0.0 --port 8000

Frontend:
  cd frontend
  python -m http.server 5500

Open:
  http://localhost:5500

For an Android APK, host the backend on a reachable HTTPS server and change
the frontend API constant from http://localhost:8000 to your backend URL.
