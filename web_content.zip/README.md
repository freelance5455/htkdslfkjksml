# تطبيق أبناء د. سراج — أندرويد

## 1) بيانات Firebase (الخطوة الأهم)
1. Firebase Console ← مشروعك ← Project settings ← Add app ← **Web** ← انسخ `firebaseConfig`.
2. ألصقه في `src/firebase-config.js`.
3. Authentication ← Sign-in method ← فعّل **Anonymous**.
4. Firestore Database ← Rules:
```
rules_version = '2';
service cloud.firestore {
  match /databases/{db}/documents {
    match /artifacts/{app}/public/data/residents/{doc} {
      allow read, write: if request.auth != null;
    }
  }
}
```
(ملف google-services.json غير مطلوب لهذا التطبيق لأنه يستخدم Web SDK.)

## 2) البناء
```
npm install
npm run build
npx cap add android
npm run android      # يبني ويفتح Android Studio
```
في Android Studio: Build ← Build APK(s).
تحتاج Node 20+ وAndroid Studio.

## الجرب على الحاسوب
`npm run dev`

## الأيقونة وشاشة البداية
الأيقونة مولّدة في `assets/` (يمكنك استبدالها بصورتك بنفس الأسماء). بعد `npx cap add android` نفّذ:
```
npm run assets
```

## النشر (APK موقّع)
Android Studio ← Build ← Generate Signed Bundle / APK ← أنشئ keystore واحتفظ به ولا تفقده.
زد `versionCode` في `android/app/build.gradle` عند كل تحديث.
