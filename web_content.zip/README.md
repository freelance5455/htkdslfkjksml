# DUEL: Wild West Showdown
## Phase 1 / Part 1: Core 3D Duel

This is a from-scratch, mobile-first Three.js prototype. It is intentionally limited to the core duel and a local CPU opponent.

### Run
Because `main.js` uses an ES module loaded from a CDN, serve the folder from a web server.

Examples:
- Replit: create a new HTML/CSS/JS project and upload these files, then run it.
- Local: `python -m http.server 8000` inside this folder, then open `http://localhost:8000`.

Open in landscape orientation.

### Implemented
- Procedural 3D Western town, buildings, fences, barrels, crates, mountains, sunset light, fog and dust
- First-person camera
- Procedural 3D hands and revolver
- Lowered/drawing/raised weapon motion controlled continuously by bottom-left drag fader
- Manual touch-look aiming with no crosshair, lock-on, aim assist or bullet magnetism
- Countdown: 3, 2, 1, DRAW!
- Real raycast shooting from the camera's actual aim direction
- Separate head/torso/arm hit regions
- Non-graphic hit/fall reactions and dust-capable environment
- Recoil and muzzle feedback
- Haptic wrapper using `navigator.vibrate`, safely no-op when unsupported
- Best-of-3 round tracking
- CPU opponent with EASY/MEDIUM/HARD configuration in code

### Intentionally not included yet
- Online multiplayer
- Matchmaking/private rooms
- Accounts
- Coins/economy
- Gun/skin shops
- Profile/Infamy/medals
- Leaderboards/rewards
- Production-grade character rigs/animations
- Full audio asset pipeline
- Server-authoritative anti-cheat

### Important prototype note
The CPU currently uses a simple reaction/accuracy model and the player's hit test uses a raycast against explicit opponent hit-region meshes. This is suitable for a playable prototype, not yet production multiplayer networking.


## Phase 1 update
This build adds:
- Visible CPU draw motion after DRAW
- Stronger cinematic camera response for shots/hits
- Procedural muzzle/impact dust bursts
- Non-graphic weapon drop on decisive opponent hit
- A haptic abstraction with an `hapticsEnabled` flag for the future Settings menu
- More explicit prototype feedback for CPU misses and player hits

Still intentionally deferred to later phases: real online networking, accounts, economy, shops, profile, leaderboard and production character rigs.


## Phase 1 v3 update
- Added a real 3D game-start menu overlay with functional PLAY.
- Added functional CPU difficulty cycling: EASY / MEDIUM / HARD.
- Gameplay input is gated until PLAY is pressed.
- Round start resets camera aim cleanly.
- Improved match result messaging.
- Kept all deferred online/economy/shop systems out of this build.


## Phase 1 v4 update
- Player shot ray now originates from the revolver muzzle instead of the camera.
- CPU shot direction is generated from its revolver muzzle toward the player.
- Added lightweight WebAudio shot/draw/hit feedback with graceful fallback.
- Added stronger haptic feedback abstraction.
- Increased procedural dust/impact particles.
- Added mobile touch polish.


## Phase 1 v5 character update
- Added **The Black Outlaw** as the featured high-status criminal/gunslinger CPU character.
- Added layered black Western coat, scarf, black cowboy hat, gold hat band, belt and buckle.
- Added Black Outlaw identity card to the main menu.
- Player and CPU ray origins are now tied to actual revolver muzzle objects.

\n## v6: Offline / Online split
- Separate **OFFLINE DUEL** and **ONLINE 1v1** modes.
- Offline uses the local CPU duel.
- Online has a separate interface and does not pretend a server connection exists.
- Added a clean integration point for a future authoritative multiplayer server.

\n### v6.1 stability fix
- Restored the menu state declarations and button handlers.
- OFFLINE DUEL starts the CPU match.
- ONLINE 1v1 remains visually separate and explicitly server-dependent.

\n## v7: Arenas + Character Intros
- Four selectable duel arenas: Sunset Main Street, Red Rock Canyon, Ghost Town, Old Train Yard.
- Four selectable characters: Classic Cowboy, Sheriff, Desert Rider, The Black Outlaw.
- Each character has a unique short dialogue and procedural music cue before the duel.
- The Black Outlaw gets a dark funk/bass entrance, black/red animated aura, and the line “Your card is up.”
- Arena selection rebuilds the environment for the duel.
- Audio is generated locally with WebAudio, so no copyrighted music assets are bundled.

\n## v8 Mobile Install Edition
- Added Android-friendly PWA packaging.
- Fullscreen landscape mode and mobile web-app metadata.
- Added 192px/512px original launcher icons.
- Added service worker for app-shell caching and first-load caching of the Three.js CDN module.
- Added an INSTALL GAME button when the browser exposes the install prompt.
- The game can be installed to an Android home screen and launched like an app once served from HTTPS (or localhost during development).
- This package is not an APK. A native signed APK requires an Android build environment; the PWA is the immediately installable mobile version.
