# Voice Orb Assistant

A React + Capacitor Android-ready voice assistant interface inspired by the supplied reference videos.

## Run

```bash
npm install
npm run dev
```

For the backend in another terminal:

```bash
npm run server
```

Then open the Vite URL.

## Android

Install Android Studio and the Capacitor CLI dependencies, then:

```bash
npm install
npx cap add android
npm run android:sync
npx cap open android
```

Build the web app and sync again whenever you change the UI:

```bash
npm run android:sync
```

## AI security

Do not place API keys in `src/` or `VITE_*` variables. Keep secrets in the backend `.env` file and make the `/api/chat` route call your selected AI provider.

## Notes

- Browser/device speech recognition availability varies by Android WebView.
- Text-to-speech uses the device/browser speech engine.
- The UI has Idle, Listening, Thinking and Speaking visual states.
