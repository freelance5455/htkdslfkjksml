# Distritiendas Tolú — Android (modo offline corregido)

Proyecto Android con Capacitor para Distritiendas Tolú.

## Qué se corrigió
- Los pedidos nuevos se pueden guardar sin Internet.
- Si Android indica que hay conexión pero Supabase no responde, el pedido pasa automáticamente al almacenamiento local en lugar de mostrar un error.
- Los pedidos pendientes aparecen como “Pendiente de sincronización”.
- Al volver Internet, la app intenta cargar Supabase y sincroniza los pedidos pendientes.
- La sesión/perfil usado anteriormente se conserva localmente para poder abrir la pantalla de pedidos sin conexión.
- La aplicación ya no depende de que el script de Supabase esté disponible al momento de abrirla para poder guardar un pedido offline.

## Primera vez
La primera configuración e inicio de sesión necesitan Internet. Después de iniciar sesión correctamente en el teléfono, se puede crear pedidos sin conexión.

## Preparar y generar la APK
1. Instala Node.js LTS y Android Studio.
2. En esta carpeta ejecuta `npm install`.
3. Ejecuta `npx cap add android` si todavía no existe la carpeta `android`.
4. Ejecuta `npx cap sync android`.
5. Ejecuta `npx cap open android`.
6. En Android Studio genera la APK desde Build > Build Bundle(s) / APK(s) > Build APK(s).

Nota: este ZIP es el proyecto fuente para generar la APK; no contiene una APK ya compilada.
