# LUMAY BUSINESS — esqueleto inicial

## Estrutura
- `index.html`: loja do cliente.
- `admin.html`: demonstração inicial do painel administrativo.
- `assets/css/styles.css`: estilos adaptáveis a telemóvel e computador.
- `assets/js/app.js`: catálogo, pesquisa, carrinho e preparação de pedido no WhatsApp.
- `assets/js/admin.js`: demonstração local para adicionar/remover produtos.
- `manifest.json`: metadados básicos de PWA.

## Abrir no SPCK
1. Faça uma cópia de segurança do projecto actual.
2. Crie um projecto novo no SPCK (recomendado para não substituir os ficheiros originais).
3. Crie a estrutura de pastas indicada acima.
4. Copie cada conteúdo para o ficheiro com o mesmo nome.
5. Abra `index.html` com a pré-visualização do SPCK.

## Limitações importantes desta versão
- Os dados ficam no `localStorage` do navegador/dispositivo.
- O painel administrativo não tem autenticação e NÃO deve ser publicado como sistema de administração real.
- Não existe ainda base de dados central, registo de encomendas, pagamentos online, gestão real de stock ou sincronização entre dispositivos.
- O botão de pedido abre uma mensagem pré-preenchida no WhatsApp; o cliente ainda tem de confirmar o envio.
- O `manifest.json` não transforma sozinho o site num APK e não resolve, por si só, alertas do Google Play Protect.
- Antes de publicar, implementar backend, autenticação, permissões, validação de dados e testes de segurança.
