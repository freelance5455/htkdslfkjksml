# Matrícula Collector — versión HTML

Aplicación web móvil preparada para servicios que convierten proyectos HTML en APK.

## Archivos
- index.html
- style.css
- app.js

## Funcionamiento
Usa localStorage del dispositivo para guardar las combinaciones conseguidas.

Sistema español: 20 letras válidas:
BCDFGHJKLMNPRSTVWXYZ

20³ = 8.000 combinaciones.

No necesita servidor ni conexión a Internet para la lógica de la aplicación una vez cargada.
