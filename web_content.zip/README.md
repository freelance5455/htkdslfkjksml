# MONEY TRACKER PRO — HTML/CSS/JavaScript + Android WebView

This project includes a working web finance tracker and an Android WebView shell.

## Web app
Open `web/index.html` in a browser, or serve the `web/` folder with a local web server.
Features: dashboard, income/expense entries, category selection, search/filter, dark/light theme,
monthly budget, savings goal, CSV export, JSON backup/restore, localStorage persistence.

## Android
Open this project in Android Studio and sync Gradle. The Android app loads `web/` assets from
`app/src/main/assets/www/`. Build a debug APK with Android Studio, or with a configured Gradle
wrapper and Android SDK.

## Cloud sync
The current app stores data locally in the browser/WebView. Cloud sync is an integration point,
not yet active. Add a backend/Firebase service and authentication before enabling cross-device sync.
Do not put private API keys in frontend JavaScript.
