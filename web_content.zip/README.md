# KOTA Daily Routine — APK PDF Upload Fix

This build keeps the existing Supabase cloud sync and changes the Books PDF picker
to a WebView-friendly file input. Rebuild the APK from this ZIP and install the new
APK over the old one.

Use the same Supabase account. PDFs are still stored locally in the app's IndexedDB;
they are not cloud-synced between devices in this version.
