# MasterFlow Trading v7 — Trusted Data Terminal

- Premium mobile trading-analysis UI
- Twelve Data as the sole quote/historical provider
- No demo rows and no Yahoo fallback
- Explicit market-data timing labels (`REALTIME`, `EOD`, `PROVIDER`)
- Candlestick/line chart from provider OHLCV
- RSI, MACD, volume, momentum, trend and confluence analysis
- Watchlist and scanner
- API keys stay on backend
- Auto-trading OFF

### Data integrity rule
If Twelve Data is unavailable, the UI shows that market data is unavailable. It does **not** invent or silently substitute prices/signals.
