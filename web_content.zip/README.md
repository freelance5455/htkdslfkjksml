# ZAYRO AI — Studio créatif

Application web mobile en HTML/CSS/JavaScript, prête à être placée dans un ZIP pour un convertisseur site-vers-APK. `index.html` est à la racine.

## Fonctions de l'interface
- Historique local : les deux points et le menu ouvrent les discussions ; une discussion peut être rouverte.
- Assistant conversationnel relié à un serveur configuré dans Réglages.
- Espace ZAYRO AMV STUDIO : demande de chanson seule ou de clip complet avec musique et vidéo.
- Espace manga/webtoon, bibliothèque de créations, lecteur audio et vidéo et téléchargement.
- Les états et l'historique sont conservés localement dans le navigateur.

## Important : moteur IA nécessaire
Ce ZIP est l'interface, pas un modèle IA. Pour obtenir de vraies vidéos, de la musique chantée et des réponses IA, il faut un serveur HTTPS qui connecte les fournisseurs compatibles. Configure l'adresse du serveur dans Réglages. Les clés API doivent rester dans les variables secrètes du serveur, jamais dans le ZIP ou dans le navigateur.

Routes attendues (adaptables dans Réglages) :
- `POST /api/chat` avec `{message, conversation_id, history}` ; réponse `{reply, conversation_id}`.
- `POST /api/amv` avec `{prompt, music_style, visual_style, duration_seconds, aspect_ratio, generate_music, generate_video, assemble_clip}` ; réponse `{video_url, audio_url, lyrics}` ou `{job_id, status}`.
- `POST /api/music` avec les paramètres musicaux ; réponse `{audio_url, lyrics}` ou `{job_id, status}`.
- `POST /api/manga` avec `{prompt, format}` ; réponse `{text, image_urls}`.
- Pour les tâches longues, `GET /api/jobs/{job_id}` doit retourner `{status, video_url?, audio_url?, error?}`.

La route d'image peut être configurée pour un backend qui la prend en charge ; aucune image ne sera présentée comme une vidéo. Le serveur doit gérer CORS pour le domaine de l'application et retourner des URL de médias accessibles en HTTPS.

## Sécurité et âge
Ne colle pas de clés secrètes dans les champs du navigateur. Demande à un adulte responsable de configurer et gérer les comptes fournisseurs, en vérifiant leurs conditions d'âge et d'utilisation.
