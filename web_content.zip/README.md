# Konverter MIDI ke SMDL (Android)

Mengubah file .mid menjadi .smdl (60 tuts F#1-F6). Tombol simpan membuka dialog Simpan sebagai milik Android.

## Membuat APK

### A. Lewat GitHub (tanpa memasang apa pun)
1. Buat repositori baru di github.com, unggah SEMUA isi folder ini (termasuk folder `.github`).
2. Tab **Actions** -> **Build APK** -> **Run workflow**.
3. Setelah hijau, buka run-nya dan unduh artifact **apk** (berisi `app-debug.apk`).

### B. Lewat Android Studio
1. File -> Open -> pilih folder ini, tunggu Gradle selesai sinkronisasi.
2. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
   Hasil: `app/build/outputs/apk/debug/app-debug.apk`.

## Memasang
Salin APK ke ponsel, buka, izinkan "pasang dari sumber tidak dikenal" bila diminta.

## Catatan
- APK debug (kunci debug), cukup untuk pemakaian pribadi.
- Isi aplikasi ada di `app/src/main/assets/index.html`; ubah lalu build ulang.
