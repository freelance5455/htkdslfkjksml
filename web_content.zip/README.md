INTERIOR DESIGNER ASSISTANT - EDITABLE HTML/JS APP

This version lets you:
- Edit any existing task (time + task name)
- Add new tasks
- Delete tasks
- Mark tasks Done/Undo
- Reset to the default Interior Designer schedule
- Save tasks/settings on the device using localStorage

Upload this ZIP to an HTML/ZIP-to-APK builder.

IMPORTANT:
A simple HTML-to-APK wrapper may not provide reliable background hourly notifications when the app is fully closed. For dependable Android background reminders, a native Android notification implementation is required.
