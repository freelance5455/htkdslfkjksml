# PhysiX Maroc Android v5

Projet Android natif (WebView + contenu local) pour FSSM Marrakech, S1.

## Ajouts v5
- Interface d'accueil modernisée.
- Paramètres intégrés.
- Choix Français / العربية avec mémorisation.
- Mode RTL automatique en arabe.
- Réinitialisation de la progression et des résultats.
- Icône Android adaptive.
- Fonctionnement hors ligne pour les contenus locaux.
- Quiz, scores, progression, TD, corrigés et recherche conservés.

## Important
Le projet source est configuré pour Android 16 / API 36. Pour produire l'APK, ouvrir le dossier dans Android Studio avec un SDK Android 36 installé puis Build > Build APK(s).
