# UK Police Knowledge Base

A professional React and TypeScript reference site for UK police roleplay and structured learning.

## Content

- UK legal jurisdictions and police force directory
- PACE caution, arrest, stop and search, entry, force and traffic powers
- Incident response, crime scenes, evidence, custody, victims and intelligence
- Missing people, domestic abuse, mental health, safeguarding, sudden death and traffic incidents
- Body-worn video, PPE, restraints, defensive equipment and police communications
- Code of Ethics, information management, pursuits, complaints and human rights
- Printable A4 quick-reference sheet

## Legal Scope

The site clearly distinguishes England and Wales, Scotland, and Northern Ireland. It uses the PACE caution rather than US Miranda terminology. Content is for training and roleplay; real-world users must check current legislation, College of Policing guidance and local force policy.

## Development

```bash
npm run dev
npm run build
```