# OPUX 2.1 — Android WebView project

OPUX is an Android-first personal time/life-management app. This source project keeps the original local WebView application and its `h24v1` tracker data model. The 2.1 pass adds clock-based check-ins, hour/minute entry and a more dimensional Home experience without replacing the tracker engine.

## Project structure

- `app/src/main/assets/index.html` — application UI, tracker logic, navigation, branch system, RDBD, statistics, history, settings and local storage.
- `app/src/main/assets/fonts/` — locally bundled Lato and DejaVu Serif fonts plus license files.
- `app/src/main/assets/opux-logo.jpg` — existing app artwork.
- `DESIGN_RESEARCH/` — research reference PDF and implementation/evidence notes; not loaded into the runtime.
- `QA/` — browser regression test notes and feature verification results.

## New in 2.1

- Home shows the Android device's local clock and a Check in action. After the configured interval (45/60/90/120 minutes; 60 by default), OPUX can ask what you have been doing.
- You select an activity and confirm/edit the suggested hours and minutes before saving. Nothing is auto-classified or silently recorded. The default suggestion is capped at 12 hours. Remind me later snoozes the prompt for 30 minutes; Not now snoozes it for 60 minutes.
- Tracker activity entry accepts hours and minutes directly; the underlying record remains a duration in minutes for compatibility with the original model.
- Home's orbit responds to pointer movement with a layered CSS 3D parallax effect and glowing elements. It does not require WebGL or Three.js.
- Tracker, Statistics, History, Records, Sounds, Themes and Settings receive a consistent editorial screen treatment; Settings includes check-in controls.

## Build an APK

Requirements: JDK 17, Android SDK platform 35, Android Gradle Plugin 8.7.3 and a compatible Gradle installation.

From this directory run:

```bash
gradle assembleDebug
```

The expected debug APK is `app/build/outputs/apk/debug/app-debug.apk`.

This archive does not contain a Gradle wrapper. The source was not compiled in the authoring environment because Android SDK and Gradle were unavailable; do not treat the source ZIP as a verified APK.

## Offline and storage

The HTML, logo and fonts are bundled locally. The app does not require a CDN for its normal UI. Tracker data continues to use Android WebView DOM storage / LocalStorage under the original `h24v1` key. Export backups from Settings before reinstalling or moving devices. Existing backups without the new preferences remain importable.

## Important implementation notes

- Branch opens in View Mode. Use **Edit branch** to change nodes/layout; **Save changes** commits the edit session and **Cancel** restores the pre-edit branch snapshot.
- RDBD is presentation-first; **Edit RDBD** reveals season and entry management. The quote carousel supports timed progression and manual navigation.
- Date format and 12/24-hour time format are selectable in Settings.
- Check-in uses elapsed time since the last in-app check-in. It cannot inspect Android Digital Wellbeing, screen-time history, notification history or activity recognition. It runs while the app is open/active; no background notification service was added.
- The original tracker stores durations rather than true timestamped start/end intervals. Check-in entries therefore add confirmed durations to the selected day; they do not create precise event timestamps.
- Three.js 0.187.0 was inspected but not integrated. The supplied package is ESM-only for browser use and the current `file:///android_asset/` WebView shell has no local module asset-origin setup. Home uses CSS 3D parallax instead.
- The original project has no separate Work, Intelligence, Music or Utilities destinations/data models. These were not fabricated as placeholder screens.
- Android-native callbacks in `MainActivity.java` (file chooser, file save, haptics, WebView back) remain inherited from v1.4 and require real-device verification.

## Data migration

Chrome and the Android app have separate LocalStorage spaces. Export the existing tracker JSON from the current app/browser, install OPUX, then use **Settings → Import JSON**. The app does not delete the source browser data.
