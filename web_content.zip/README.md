# Pixel Arena 3v3 — Android Project

Project ini membungkus `index.html` asli ke dalam Android WebView.

## Cara build APK

1. Buka folder `PixelArena3v3_Android` dengan Android Studio.
2. Tunggu Gradle selesai melakukan sync.
3. Pilih `Build > Build App Bundle(s) / APK(s) > Build APK(s)`.
4. APK debug akan berada di:
   `app/build/outputs/apk/debug/app-debug.apk`

## Konfigurasi

- Landscape
- Fullscreen / immersive
- JavaScript aktif
- DOM storage aktif
- HTML berjalan secara lokal dari APK
- Tidak membutuhkan internet untuk file game ini

## Catatan

Game asli menggunakan Canvas dan Web Audio API. Project ini tidak mengubah kode gameplay.
