# COL TMS Mobile Starter

دا د COL TMS د موبایل لپاره ساده MVP starter دی.

## Replit
فایلونه Upload/Import کړه او `index.html` خلاص کړه. دا نسخه د browser/mobile preview لپاره ده.

## مهم
- دا لا د production backend/Firebase نسخه نه ده.
- معلومات اوس په browser localStorage کې ساتل کېږي.
- وروسته Firebase/Database، login، admin permissions، PDF receipt، WhatsApp notifications او Android APK اضافه کېدای شي.
