# Exness Gold Bot — Android + VPS + MT5 Bridge

## Architecture

Android APK (control/monitoring)
    ↓ HTTPS + API token
FastAPI bridge on VPS
    ↓ HTTPS + API token
MT5 Expert Advisor on Windows VPS
    ↓
MetaTrader 5 terminal
    ↓
Broker account

The APK never stores or transmits the MT5 broker password. The bridge provides authenticated health/status and a small command queue. The included EA polls that queue and reports MT5 account status.

## Safety state

- XAUUSD
- Risk 0.25%
- Daily loss limit 1%
- Maximum 3 trades/day
- DemoOnly=true in the EA
- No order execution is implemented in the supplied EA

## 1. VPS bridge

On a Windows/Linux VPS with Python 3.11+:

    cd bridge
    python -m venv .venv
    # Windows: .venv\\Scripts\\activate
    # Linux: source .venv/bin/activate
    pip install -r requirements.txt
    uvicorn main:app --host 0.0.0.0 --port 8080

For production use HTTPS and a long random API token. Do not expose plain HTTP on the public internet.

## 2. MT5 EA

Open `mt5/Experts/ExnessGoldBotBridge.mq5` in MetaEditor, set `BridgeUrl` and `ApiToken`, compile, and attach to XAUUSD. Add the exact HTTPS domain to MT5 WebRequest allowed URLs.

## 3. Android

Open the project in Android Studio, build the debug APK, install it, enter the VPS HTTPS URL and API token, then press TEST and STATUS. START/STOP only queue commands; the EA prints them and remains demo-safe.

## Production expansion

If you later add an actual strategy/execution layer, keep it server-side, enforce authentication, risk limits, idempotency, audit logs, and an emergency stop. Test on a demo account before any live execution.
