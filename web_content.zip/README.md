# PromptVerse (Flutter + Adivery)

## ساختار
- `assets/web/index.html` و `assets/web/ads.js`: رابط کاربری (همان طراحی قبلی)
- `lib/main.dart`: اجرای WebView و SDK رسمی Adivery
- `.github/workflows/build.yml`: ساخت خودکار APK در GitHub

## ساخت APK فقط با گوشی
1. در github.com حساب بسازید و یک مخزن (Repository) جدید بسازید.
2. زیپ را در گوشی از حالت فشرده خارج کنید.
3. در مخزن: **Add file ← Upload files** و فایل‌های `pubspec.yaml` و پوشه‌های `lib` و `assets` را آپلود کنید.
4. پوشهٔ `.github` معمولاً در آپلود نمایش داده نمی‌شود. به جایش **Add file ← Create new file** را بزنید، در کادر نام دقیقاً بنویسید `.github/workflows/build.yml` و محتوای فایل `build.yml` همراه زیپ را در آن بچسبانید. سپس Commit کنید.
5. تب **Actions** را باز کنید، **Build APK** را انتخاب و **Run workflow** را بزنید.
6. بعد از چند دقیقه روی اجرای تمام‌شده بزنید و پایین صفحه، بخش **Artifacts**، فایل `PromptVerse-apk` را دانلود کنید. داخل آن APK است.

## فعال‌سازی تبلیغ
- در `lib/main.dart` مقدار `kRewardedPlacementId` را با شناسهٔ جایگاه تبلیغ پاداشی از پنل Adivery پر کنید.
- نام بسته برنامه `com.aniya.prompt` است و باید با برنامهٔ ثبت‌شده در Adivery یکی باشد.

## سیاست‌ها (در `assets/web/ads.js`)
- `onEarlyClose: "block"` یعنی اگر کاربر تبلیغ را زودتر ببندد، پرامپت کپی نمی‌شود.
- `onUnavailable: "copy"` یعنی اگر تبلیغ نبود (آفلاین، خطا، جایگاه خالی)، کپی مستقیم انجام می‌شود. برای اجباری کردن، `"block"` بگذارید.
