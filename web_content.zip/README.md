# QUBE PARTY X ULTIMATE v9

## What's new
- BINGO PARTY
- SNAKE ARENA
- QUBE CITY
- Reaction Rush
- MILLION DUEL local multiplayer
- Local Party lobby for 2–4 phones
- Original embedded music + sfx
- 3D/Neon motion graphics
- Large editable offline question bank
- Question Studio import/export

## Android local multiplayer
The Android wrapper uses Google Nearby Connections with P2P_STAR. Google documents P2P_STAR as one-to-N topology, useful for one hub with multiple nearby players; multiplayer gaming with smaller payloads can also use the cluster strategy. Nearby Connections advertises/discovers a unique serviceId and establishes nearby connections after runtime permissions. See official docs.

### Player flow
1. Phone A opens QUBE -> Local Party -> Create Room.
2. Phone A is the host.
3. Phones B/C/D open QUBE -> Local Party -> Search.
4. They select the host. The app asks for Nearby-device permissions, then the connection handshake is accepted on both phones.
5. The lobby shows connected players.
6. Host taps Start Million Duel.
7. Questions are synchronized over Nearby Connections. Answers are sent as small JSON payloads and the host broadcasts the round result. QUBE v9 uses P2P_STAR: one host can accept multiple nearby players; for this first duel flow the UI is optimized for 2 players.
8. No internet connection is required for the local session.

### Permissions
For Android 13+ the app requests NEARBY_WIFI_DEVICES plus Bluetooth scan/connect/advertise as needed. For older Android versions, ACCESS_FINE_LOCATION is requested for the relevant Nearby/Wi-Fi APIs.

Build:
- Open this folder in Android Studio.
- Sync Gradle.
- Build > Build APK(s).

Dependency:
com.google.android.gms:play-services-nearby:19.4.0
