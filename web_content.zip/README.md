# TALK YOUR AI — prototype

A mobile-first installable web app prototype. It can run in a modern browser on Android, iPhone, and desktop.

## Run
1. Extract the ZIP.
2. Open `index.html` in a browser to explore the basic interface.
3. For camera permission and install/offline testing, host the folder on an HTTPS static host or run a local web server.
4. On Android use Chrome → menu → Install app / Add to Home Screen. On iPhone use Safari → Share → Add to Home Screen.

## What's working
- Responsive navigation and chat UI with sample local responses.
- Local image/video/file attachment preview.
- Avatar reference image preview and session settings.
- 40 selectable voice preset profiles; speech preview uses a voice installed on the device.
- Local audio recording playback.
- Camera preview after explicit browser permission.
- Basic PWA manifest and service worker.

## Important prototype limits
This is not yet connected to a real AI model. Chat answers are sample responses. Voice preset names are interface presets, not 40 separate generated voices. Uploaded voice audio is played locally and is not cloned. Live camera is only a local preview; AI video understanding, two-way realtime conversation, avatar generation, and lip-sync require a secure backend and appropriate AI/media services. Do not put API keys in browser code.
