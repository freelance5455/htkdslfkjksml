# AB Électricité & Sécurité — version Android/web

Cette version utilise le logo fourni par l'utilisateur dans `assets/logo-ab.png` : il apparaît dans l'en-tête de l'application et comme icône de page (favicon / touch icon).

## Coordonnées configurées
- WhatsApp : +216 29 646 604 (`21629646604` au format international pour le lien WhatsApp)
- Téléphone : +216 26 947 066 (`21626947066`)
- Adresse : Ben Gardane, Médenine, Tunisie

## Lancer l'interface
Ouvrir `index.html` dans un navigateur récent. Les formulaires préparent les demandes via WhatsApp. Les paramètres et demandes sont enregistrés localement dans le navigateur de cet appareil.

## Android
Le dossier fourni est une interface web mobile. Pour obtenir un APK installable, elle doit être emballée dans un projet Android (par exemple via Android Studio avec WebView ou un wrapper Capacitor) puis compilée et testée. L'archive ZIP n'est pas elle-même un APK.

## Sécurité
Le code administrateur initial `1234` est uniquement une protection locale de démonstration, pas une authentification sécurisée pour un déploiement public. Modifiez-le avant usage réel.
