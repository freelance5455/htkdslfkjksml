# AirTouch (Android) – hands-free control of ANY app

Front camera → MediaPipe Hand Landmarker → pointer dot drawn over all apps → pinch gestures
become real taps / swipes / Back / Home / Recents through an AccessibilityService.
See **BUILD.md** for ZIP2APK / build-server settings.

## Build
* ZIP2APK or any server: `./gradlew assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`
* Android Studio: open this folder and press Run.
* The hand model is bundled if the build machine has internet, otherwise the app downloads it once
  (button "Download hand model" in the app, needs internet on the phone).

## First run on the phone
1. Open AirTouch → **Allow camera & notifications**.
2. If shown, **Download hand model**.
3. **Open Accessibility settings** → AirTouch → ON.
   Android 13+ (sideloaded APK): if greyed out → Settings → Apps → AirTouch → ⋮ → *Allow restricted settings*.
4. **Start AirTouch**, then go to any app and show your hand to the front camera.

## Gestures
| Gesture | Action |
|---|---|
| Move palm | Dot moves |
| Thumb + index pinch | Tap |
| Two quick pinches | Double tap (the 1st pinch also taps) |
| Pinch, hold, move, release | Swipe / scroll |
| Thumb + middle | Back |
| Thumb + ring | Home |
| Thumb + little finger | Recents |

## Built-in browser
Tap **Open AirTouch Browser** in the app. It starts hand tracking (if ready) and opens a browser whose start page is
HTML (`app/src/main/assets/www/home.html`, `home.css`, `home.js`) with big shortcut tiles: YouTube, Google, Instagram,
Facebook, X, WhatsApp Web, Telegram, Gmail, Maps, Spotify, Hotstar, Amazon, Flipkart, Reddit, Wikipedia, plus your own
shortcuts. The toolbar has Back, Forward, Reload, Home, 🎤 voice search and Close. Videos can go fullscreen.
The same gestures work inside it (tap, scroll, double tap, Back = thumb + middle). Edit the HTML files to change the start page.
Note: Google sign-in may be refused inside any embedded browser; browsing and watching YouTube works without signing in.

## Background operation
`HandTrackingService` is a foreground service of type `camera` (permanent notification with Stop button).
Start it from the app screen (Android only allows starting camera services while the app is visible).

## Known limits
* Camera is used continuously → battery drain and the green camera indicator are expected.
* Many phones stop camera use when the screen is locked/off. Set battery to "Unrestricted" for AirTouch.
* Some apps (banking, DRM video, password screens) block or ignore accessibility input.
* Accessibility apps need Play Store policy approval to publish; for personal use sideload the APK.

## HTML version (`web/` folder)
`web/index.html` is the browser/PWA version (same gestures, works only inside its own page).
Run: `cd web && python -m http.server 8000` (camera needs HTTPS or localhost) or upload `web/` to any HTTPS host.
The Gradle build ignores `web/`.
