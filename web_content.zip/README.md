# GemTrack - build the APK

You need: Node.js (LTS) and Android Studio (free). Windows, Mac or Linux.

1. In a terminal in this folder:  npm install
2. npx cap add android
3. npx @capacitor/assets generate --android    (creates the GemTrack launcher icons from the assets folder)
4. npx cap sync
5. npx cap open android   (opens Android Studio; wait for Gradle to finish)
6. Build > Build Bundle(s) / APK(s) > Build APK(s), then click "locate"
7. The file is android/app/build/outputs/apk/debug/app-debug.apk. Copy it to your phone and install it.

Updating the app later: replace www/index.html, run  npx cap sync, then build again.

Birthday reminders
- The first time you save a customer with a birthday, Android asks to allow notifications. Tap Allow.
- Reminders are scheduled inside the phone, so they work offline. Change the time or days-before on the Home tab.

Important
- Your data lives inside the app. Uninstalling it deletes the data. Use Home > Save backup first.
- Installing over an older version keeps data only if both were signed with the same key.
  If Android asks you to uninstall first, save a backup, then restore it in the new app.
- For a long-lived copy or Play Store: Build > Generate Signed App Bundle / APK, create a keystore,
  and keep that keystore file and password safe forever.
