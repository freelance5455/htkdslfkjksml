# Saifullah – Personal & Office Management
# سیف اللہ – ذاتی و دفتری منتظم

## 1. APK Forge سے اینڈرائیڈ ایپ (APK) بنانے کا طریقہ:
یہ زپ فائل خصوصی طور پر **APK Forge**، **Website 2 APK Builder** یا **WebIntoApp** کے لیے تیار کی گئی ہے:
1. APK Forge یا ویب سائٹ کھولیں۔
2. "Upload ZIP File" یا "HTML5 to APK" کا آپشن منتخب کریں۔
3. اس زپ فائل (`Saif_Ullah_Manager_Complete_Package.zip`) کو اپلوڈ کریں۔
4. زپ کے روٹ (Root) پر `index.html` موجود ہے جو ایپ بنتے ہی خودکار کھلے گا۔
5. آپ کی مکمل اینڈرائیڈ APK تیار ہو جائے گی اور بغیر انٹرنیٹ کے موبائل پر 100% چلے گی!

---

## 2. کمپیوٹر یا موبائل پر بغیر کسی سافٹ ویئر کے فوراً چلانے کا طریقہ:
- زپ فائل کو ان زپ (Extract) کریں۔
- فولڈر میں موجود `index.html` یا `Saif_Ullah_Manager_Offline.html` پر ڈبل کلک کریں۔
- یہ کسی بھی براؤزر میں فوراً کھل جائے گی اور آپ کے تمام ڈیٹا کو محفوظ رکھے گی۔

---

## 3. تمام ماڈیولز اور فیچرز:
1. **نیا ریفرنس ڈیش بورڈ:**
   - Quick Overview (Home, Factory, Personal, Tasks, Reports)
   - 5 وائبرنٹ ایکشن بٹنز:
     - Home (Ghar ka Kharcha)
     - Factory (Leave & Office Work)
     - Personal (Loan & Committee)
     - Settings (Customize App)
     - Reports (View & Export)
   - Recent Activities اور Backup & Restore (Google Drive)
   - گرین سلوگن بار: "⭐ Saifullah App – Smart Management for a Better Life"
   - ہر اسکرین پر "← واپسی ڈیش بورڈ (Back to Dashboard)" کا بٹن!

2. **آٹا خریداری ٹریکر (Atta Tracker):**
   - 1 من = 40 کلوگرام
   - من میں اندراج، فی من اور فی کلو ریٹ کا خودکار حساب
   - مساوی کلوگرام اور کل رقم کا لائیو حساب
   - مکمل ریکارڈز اور ڈیلیٹ/ایڈٹ سہولت

3. **گھریلو اخراجات (Household Expenses):**
   - راشن، بجلی، گیس، کرایہ، علاج، پیٹرول وغیرہ
   - کیٹیگری کے مطابق خرچ اور خلاصہ

4. **فیکٹری رخصت (Factory Leave Management):**
   - CL 10 دن، SL 8 دن کوٹہ
   - CPL لاٹس اور 40 روزہ FIFO ایکسپائری سسٹم
   - دستیاب اور استعمال شدہ بیلنس کا لائیو ٹریکر

5. **دفتری ٹاسک (Office Tasks):**
   - ٹاسک شیڈول، ڈیو ڈیٹس، ارجنٹ اور ہائی الرٹس
   - ون کلک پر ٹاسک کو "مکمل" مارک کرنے کی سہولت

6. **قرض واجب الادا (Personal Loan Payable):**
   - قرض واجب الادا = وصول شدہ قرض − واپس کیا گیا قرض
   - کمیٹی کے کھاتوں سے مکمل الگ
   - شخص وار بیلنس لیجر

7. **کمیٹی کا انتظام (Kameti Management):**
   - اقساط اور پے آؤٹ کا آزاد کھاتہ

8. **ترتیبات اور بیک اپ:**
   - کوٹہ کی ترتیبات، JSON بیک اپ اور ریسٹور
