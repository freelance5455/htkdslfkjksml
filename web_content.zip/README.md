# FitTrack
A simple offline-first fitness tracker.

Features:
- Workout logging: exercise, sets, reps, weight, duration
- Food/calorie and protein logging
- Weight and waist history
- Daily dashboard
- Calorie/protein targets
- Local phone storage; no login required

Open index.html in a browser. On Android Chrome, use "Add to Home screen" to install it as a PWA.
