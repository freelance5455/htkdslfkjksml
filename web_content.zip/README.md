# RMS Movie Place
Cinema booking starter for Android and computer.

Features:
- Movie poster home screen
- Showtime selection
- 60 seats (A1-F10)
- ₹50 per seat
- Automatic total
- Booking confirmation with ticket/QR placeholder

## Android
Open `android` in Android Studio and run the app.

## Computer
Install Node.js, then:
`cd desktop`
`npm install`
`npm start`

This is a starter app. Payment gateway, database, admin login, real QR generation and production deployment still need to be connected.
