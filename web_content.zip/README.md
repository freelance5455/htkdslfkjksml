# Rimba VR

A React, TypeScript, and Three.js nature experience with an Indonesian interface.

## Run

```sh
npm install
npm run dev
```

Open the Vite URL. For motion sensors on a physical phone, serve the application over HTTPS. A phone opening a computer's plain HTTP LAN address is not a secure context.

## Features

- Three explorable locations: a reflective mountain lake, pine woodland, and a wildflower meadow.
- Genuine side-by-side stereo cameras, with an optional single-camera view.
- Per-eye lake reflections, gentle water ripples, flying birds, trees, rocks, deer, a boat, and a jetty.
- Device motion locomotion with three-axis gravity compensation, adjustable sensitivity, and automatic stop.
- Optional device orientation look controls, mouse/touch dragging, and keyboard movement.
- Locally synthesized stereo birdsong, water, wind, and footsteps. No audio downloads or microphone access are required.
- Persistent preferences, scene favorites, pause/resume, and journey reset.

Use W or Space to walk, S to move backward, A/D to turn, or hold the on-screen forward button. Escape pauses the journey. On a phone, rotate to landscape before using a Cardboard-style viewer.

The sensors detect physical phone movement. The Vibration API only commands a vibration motor and is not a vibration detection API; motor vibrations may be too weak for a phone's available motion samples. Do not shake the phone hard. Stay seated or in a safe, stationary position.

## Verification

```sh
npx tsc --noEmit
npm run build
npx playwright install chromium
npx playwright install-deps chromium
node scripts/check-rimba.mjs
```

The browser check uses the running Vite development server at localhost:5173. It covers navigation, favorites, audio controls, persistent preferences, stereo/single views, keyboard and synthetic sensor locomotion, stopping, pause/reset, and mobile layouts. Physical phone sensors, headphones, and headset comfort still require real-device testing.

## Assets

The menu photography is stored locally in `public/images`. Photographs are by eberhard grossgasteiger, Dongdilac, and Edit Krizsan via Pexels. Menu photographs are destination previews; the playable world is an original procedural 3D landscape. Local fonts are DM Sans and Instrument Serif from Google Fonts. Icons are from Lucide.