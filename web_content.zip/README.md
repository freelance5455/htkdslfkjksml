# BIBLE — Église Assemblée des Saints de Kinseso

## Édition complète hors ligne · v1.1.0

Le lecteur inclut le texte Louis Segond 1910 provenant du paquet HTML officiel d’eBible.org. Les 66 livres et les 1 189 chapitres ont été extraits ; le contrôle de cette édition a trouvé 31 170 marqueurs de verset uniques. Le corpus est intégré au HTML, sans téléchargement à l’ouverture : lecture, navigation par livre/chapitre, recherche de mots et références (par exemple « Jean 3:16 » ou « Psaume 23 ») fonctionnent hors ligne.

Le dossier `web/` est la version utilisée par Capacitor et la PWA. Le fichier `index.html` à la racine du projet est servi par `npm run serve`. Le fichier `/home/ubuntu/index.html` est une copie HTML autonome à ouvrir ou à remettre séparément. L’interface, les styles, le texte biblique et le JavaScript sont embarqués dans chaque HTML. Le zoom par pincement est désactivé dans l’interface et dans Android ; cela peut gêner les personnes qui ont besoin d’agrandir l’écran, qui peuvent utiliser l’agrandissement système du téléphone. Le service worker a une nouvelle clé de cache afin que l’ancienne version ne soit pas réutilisée après mise à jour.

## Fonctions conservées

L’application conserve le nom « Église Assemblée des Saints de Kinseso », le mode enfant ludique avec histoires et étoiles, ainsi que les coordonnées cliquables du créateur : WhatsApp/téléphone **0830962621** et e-mail **josiasmayema@gmail.com**. Favoris, notes, préférences, progression et conversations YELE restent enregistrés sur l’appareil.

YELE est un assistant local à règles, et non un modèle d’IA générale. Il peut retrouver les versets et passages du corpus complet, en plus de ses réponses hors ligne sur quelques sujets bibliques, scolaires, géographiques, historiques, scientifiques et mathématiques. Il peut encore répondre de façon incomplète ou erronée ; cette limite est indiquée dans l’application.

## Provenance et droits du texte

La page de droits d’eBible.org déclare que cette édition Louis Segond 1910 est dans le domaine public. La provenance exacte, l’empreinte SHA-256 de l’archive utilisée et la distinction avec une autre distribution LS1910 figurent dans [`legal/NOTICE-LSG1910.md`](legal/NOTICE-LSG1910.md) et [`legal/LSG1910-PROVENANCE.json`](legal/LSG1910-PROVENANCE.json).

Cette déclaration de la source ne remplace pas un avis juridique dans les pays où l’application sera commercialisée. Le catalogue GetBible décrit une autre distribution LS1910 avec une permission de diffusion réservée à CrossWire ; cette distribution n’a pas été utilisée. Faites confirmer localement la portée des droits et gardez la notice avec les dossiers de publication.

## Lancer la PWA et construire Android

Prérequis : Node.js, Android Studio/SDK pour Android, et les dépendances npm du projet.

```bash
npm install
npm run serve
```

Ouvrez `http://localhost:8080`. Pour synchroniser le contenu web avec le projet natif, puis ouvrir Android Studio :

```bash
npx cap sync android
npx cap open android
```

Dans Android Studio, laissez Gradle synchroniser, puis construisez un APK avec **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Une publication demande une clé de signature d’éditeur protégée, puis un APK/AAB de production signé. Le ZIP livré contient le projet et ses sources, pas une signature de boutique ni un AAB de production.

Le fichier autonome `index.html` peut être ouvert dans un navigateur moderne. L’installation PWA et son service worker demandent un hébergement HTTP(S). L’application Capacitor embarque les fichiers nécessaires pour fonctionner hors ligne après installation.

## Réextraire ou vérifier le texte

Le script `tools/build_full_bible.py` lit le ZIP HTML eBible.org, vérifie les livres, les chapitres, le numérotage des versets et leur présence, puis régénère les copies HTML du projet et le fichier autonome. Il est reproductible ; si vous l’utilisez, installez Beautiful Soup et lancez :

```bash
python3 -m pip install beautifulsoup4
python3 tools/build_full_bible.py /chemin/vers/fraLSG_html.zip
```

Avant d’assembler ou de diffuser une version, le contrôle du corpus peut être relancé ainsi :

```bash
python3 tools/verify_full_bible.py
```

## À terminer avant une commercialisation publique

Cette livraison apporte le corpus intégral et les principales fonctions hors ligne, mais ne constitue pas encore une validation de publication en boutique. Il reste notamment à faire confirmer localement la licence, à préparer les mentions légales et la politique de confidentialité adaptées aux pays et magasins ciblés, à définir l’âge cible, à tester un APK/AAB signé sur les appareils Android visés, et à finaliser les éléments de marque et la fiche boutique. Il n’y a pas de compte utilisateur, de synchronisation cloud ni de modèle IA général. Les fonctions vocales dépendent des voix et services installés par le système.
