# Celtic Kingdoms – Android

Das ist ein vollständiges Android-Studio-Projekt für die aktuelle Spielversion.
- Hochformat gesperrt
- App-ID: com.celtickingdoms.app
- Offline spielbar
- Spielstand über localStorage
- Spieloberfläche aus assets/index.html

APK bauen:
1. Projekt in Android Studio öffnen.
2. Gradle synchronisieren lassen.
3. Build > Build APK(s).
4. Die erzeugte APK auf das Android-Handy kopieren und installieren.

Für die echte Online-Version werden anschließend Backend, Accounts, Datenbank und Multiplayer ergänzt.
