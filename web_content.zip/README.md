# FF Mod Menu Simulator (Android)

Aplikasi ini adalah simulator UI lokal bertema Black Red dengan floating panel. Ini **bukan cheat Free Fire** dan tidak terhubung ke proses/game, tidak membaca atau menulis memori, serta tidak memiliki bypass anti-ban, anti-report, ESP/aimbot untuk gameplay, atau auto-clear report.

## Build APK
1. Buka folder proyek ini di Android Studio.
2. Tunggu Gradle Sync selesai (gunakan Android Gradle Plugin 8.7.3 dan JDK 17).
3. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.

## Jalankan
Instal APK debug di perangkat Android. Panel mengambang di dalam aplikasi dapat dibuka/tutup dengan tombol bulat FF. Semua toggle, slider FOV, profil sensitivitas, simpan config, dan reset bekerja hanya pada simulator lokal.

## Struktur
- `MainActivity.java`: WebView Android.
- `app/src/main/assets/index.html`: antarmuka dan logika simulator.
