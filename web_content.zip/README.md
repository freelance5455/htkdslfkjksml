# JARVIS APK
1. Maak op github.com een nieuwe, PRIVÉ repository en upload alle bestanden uit deze map (ook de verborgen map .github).
2. Open het tabblad Actions, kies Build APK en tik op Run workflow (duurt ca. 5 minuten).
3. Download onder Artifacts het bestand JARVIS-apk, pak de zip uit en installeer app-debug.apk op je telefoon (sta installeren uit onbekende bronnen toe).
4. Open de app, tik op Activeer en voer je Anthropic API-sleutel in (console.anthropic.com). Later wijzigen: lang op de titel tikken.
