# ProBill Cafe PRO — Offline Billing

## Features
- Cafe-specific bill creation with customer, table/order number, bill date, GSTIN and phone.
- Menu items with quantity, selling price and optional cost price.
- Automatic subtotal, discount, tax and total.
- UPI payment QR (QR image is fetched from QRServer; internet is required to generate/load the QR).
- Print or Save as PDF, WhatsApp bill sharing, and QR image saving.
- Local dashboard: today's revenue, bill count, all-time revenue and estimated gross profit.
- Bill history saved in browser localStorage.
- Export/import JSON backup.
- Mobile-responsive premium dark UI.
- PWA manifest and service worker for installation/offline app shell when hosted over HTTPS.

## Run
1. Unzip the package.
2. Open `index.html` in a modern browser. For best PWA/offline behavior, serve the folder from a local web server or HTTPS hosting.
3. Enter cafe details and UPI ID, then add items or use “Load Cafe Sample Menu”.
4. Click “Save Bill & Update Revenue” to store the bill locally.
5. Use Export Backup regularly.

## Important limitations
- Data is stored only in the browser on this device. Clearing browser data can erase it; export backups.
- No cloud sync, multi-device sync, login, or server database in this offline version.
- UPI QR only opens a payment intent; it does not confirm payment. Verify payments in your UPI app.
- The QR image endpoint needs internet access. Billing and saved local history work offline after the app files are available.
- Tax is a configurable estimate; confirm applicable tax/GST treatment for your cafe with a qualified professional.
- This is a starter project, not a certified POS/accounting system.
