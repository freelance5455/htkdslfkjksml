# Islam Salah — مشروع جاهز لتحويله إلى APK

## الطريقة 1 (الأسهل، بدون تثبيت أي برامج): GitHub
1. اعمل حساب على github.com، وأنشئ Repository جديد.
2. ارفع كل محتويات هذا المجلد كما هي (بما فيها مجلد .github).
3. ادخل تبويب Actions ← Build APK ← Run workflow.
4. بعد ~5 دقايق افتح التشغيلة وانزل من Artifacts الملف islam-salah-apk (فيه app-debug.apk).
5. انقل الـ APK للتليفون وثبّته (اسمح بالتثبيت من مصادر غير معروفة).

## الطريقة 2: على الكمبيوتر
المطلوب: Node 18+ و Android Studio (JDK 17).
    npm install
    npx cap add android
    (أضف الصلاحيات الموجودة في build-apk.yml إلى AndroidManifest.xml)
    npx cap sync android
    npx cap open android   ← ثم Build > Build APK

## بعد التثبيت
- افتح التطبيق واضغط «تفعيل الإشعارات والصوت» واسمح بالإشعارات والمنبهات الدقيقة.
- في إعدادات أندرويد: البطارية ← التطبيق ← «بدون قيود» عشان التنبيه ما يتأخرش.
- التنبيهات بتتجدول يوميًا وبتشتغل والتطبيق مقفول والشاشة مقفولة.
- لصوت أذان مخصص: ضع ملف salah.mp3 في android/app/src/main/res/raw
  وأضف sound:'salah.mp3' في createChannel وفي إشعار schedule داخل www/index.html (ثم ثبّت التطبيق من جديد لأن قناة الإشعار تُنشأ مرة واحدة).
