# VACLAV PEINTURE

Prototype fonctionnel de visualisation de peinture, conçu pour Android.

## Fonctions incluses
- Photo depuis l'appareil ou import d'une image
- Palette de couleurs + couleur personnalisée HEX
- Remplissage par toucher d'une zone claire entourée de traits foncés
- Pinceau et gomme tactiles
- Annuler, réinitialiser
- Comparaison avant/après
- Enregistrement PNG et partage via le menu de partage Android lorsque pris en charge
- Interface noire et or, slogan de l'application

## Tester sur Android
1. Décompressez le dossier.
2. Hébergez le dossier sur un hébergement HTTPS (ou lancez un serveur local).
3. Ouvrez l'adresse dans Chrome Android.
4. Menu Chrome > « Installer l'application » ou « Ajouter à l'écran d'accueil ».

Le mode hors connexion est disponible après le premier chargement via le service worker, sur un hébergement HTTPS.

## À propos du remplissage automatique
Le prototype remplit une région claire contiguë délimitée par des traits foncés. Les contours ouverts, les photos complexes et les murs photographiés sans séparation nette peuvent nécessiter le pinceau. La détection IA avancée des murs/façades et la génération d'un APK natif signé sont des étapes de développement ultérieures.

## Pour produire un APK natif
Le projet peut être enveloppé avec Capacitor puis compilé dans Android Studio. Il faut un environnement Android SDK/JDK et une clé de signature pour publier un APK signé. Ce ZIP contient le projet web fonctionnel, pas encore un APK compilé.
