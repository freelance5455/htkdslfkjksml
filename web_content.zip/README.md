# Anjo da Guarda — Fundação Técnica do Marketplace

**"A solução que você precisa."**

Este projeto evoluiu do protótipo single-file (`legado/index-mvp-single-file-backup.html`)
para uma estrutura multi-página, multi-usuário, com camadas separadas de dados,
regras de negócio e autenticação — pronta para, no futuro, ser ligada a um backend real.

## ⚠️ Limitação honesta (leia antes de tudo)

**Não existe servidor/backend real neste projeto.** Tudo roda 100% no navegador,
com os dados salvos em `localStorage`. Isso significa:

- Não há banco de dados compartilhado entre usuários/dispositivos — cada navegador
  tem seus próprios dados.
- A "autenticação" e as verificações de permissão (`Auth.exigirPerfil(...)`) rodam
  no cliente. Qualquer pessoa com acesso ao DevTools do navegador pode alterar
  esses dados. **Isto não é seguro para produção.**
- Fotos de imóveis são convertidas em Base64 e guardadas no `localStorage`
  (sem armazenamento de arquivos real).

O que foi entregue é a **arquitetura em camadas** (models → db → services → páginas)
já organizada para que, quando um backend real existir, baste substituir o
conteúdo de `js/db.js` por chamadas HTTP — sem precisar reescrever `services/*.js`
nem as páginas.

## ✅ Como abrir e testar (validado nesta etapa)

Este projeto é **HTML + CSS + JavaScript puro** — sem React/Vue/Vite, sem
`package.json`, sem etapa de build/compilação. É por isso que não existe
`npm install` nem `npm run build` aqui: não há nada para compilar.

**Opção 1 — mais simples:** dê duplo clique em `index.html`. Ele abre no seu
navegador padrão e o app funciona (precisa de internet só para carregar 3
bibliotecas visuais via CDN — Tailwind, ícones Lucide e a fonte Google Fonts).

**Opção 2 — via servidor local (opcional):**
- Windows: dê duplo clique em `iniciar-servidor.bat`
- Mac/Linux: rode `./iniciar-servidor.sh` (ou `sh iniciar-servidor.sh`)
- Depois acesse **http://localhost:8080** no navegador.

Login de teste (ambiente de desenvolvimento):
```
admin@anjodaguarda.dev / admin123   (perfil: administrador)
```
Ou cadastre-se pela tela de Cadastro como Anfitrião ou Profissional.

### Validação feita nesta etapa

- ✅ As 8 páginas (`index, login, cadastro, home-anfitriao, imovel-form,
  home-profissional, perfil, admin`) foram servidas via HTTP local e todas
  retornaram código 200.
- ✅ Todas as referências locais (`<script src>`, `<link href>`, imagens) em
  todas as páginas apontam para arquivos que realmente existem — nenhum link
  quebrado.
- ✅ `node --check` em todos os 20 arquivos `.js` — nenhum erro de sintaxe.
- ✅ Fluxo de negócio revalidado ponta a ponta (cadastro → login → cadastro de
  imóvel → cadastro de profissional → aprovação pelo admin).
- ⚠️ **Não foi possível** testar cliques/toques reais numa tela de navegador,
  pois este ambiente de geração de código não tem um navegador interativo.
  Recomenda-se abrir o `index.html` e clicar pelas telas rapidamente para
  confirmar visualmente.

### Sobre gerar um APK

**Não foi gerado nenhum APK nesta etapa** — este ambiente não tem SDK Android
nem ferramentas de build mobile (Capacitor/Cordova/Android Studio), e nada foi
simulado nesse sentido. O projeto já está em HTML/CSS/JS puro, o que é
compatível com ferramentas como o **Capacitor** para empacotar como APK no
futuro, mas isso é um passo à parte, ainda não executado.

## Estrutura de pastas

```
anjo-da-guarda-app/
├── index.html                 Landing + login/cadastro
├── login.html
├── cadastro.html
├── home-anfitriao.html        Painel do anfitrião (meus imóveis)
├── imovel-form.html           Cadastro/edição de imóvel
├── home-profissional.html     Painel do profissional (perfil + disponibilidade)
├── perfil.html                Dados da conta (comum aos 3 perfis) + logout
├── admin.html                 Painel do administrador
├── css/
│   └── style.css              Identidade visual do Anjo da Guarda (preservada)
├── assets/
│   └── logo-anjo-da-guarda.png
├── js/
│   ├── config.js              Ambiente DEV/PROD, prefixo de storage, constantes
│   ├── db.js                  Camada de "banco de dados" (hoje: localStorage)
│   ├── models.js               Formato/validação de cada entidade
│   ├── geo.js                  Brasil → Estado → Cidade → Bairro (piloto: Praia Grande/SP)
│   ├── auth.js                  Cadastro, login, logout, sessão, guardas de perfil
│   ├── legal.js                 Termos de Uso / Política de Privacidade (modal)
│   ├── utils.js                  Helpers (toast, ícones, formatação, sessão no header)
│   ├── seed.js                   Dados fictícios — SÓ em ambiente 'dev'
│   ├── services/                 Regras de negócio por entidade (ver abaixo)
│   └── pages/                    JS específico de cada página HTML
└── legado/
    └── index-mvp-single-file-backup.html   Backup do protótipo anterior (intacto)
```

## Entidades implementadas (em `js/models.js` + `js/db.js`)

`users`, `providers`, `properties`, `service_categories`, `availability`,
`notifications`, `audit_logs`, `reviews` — todas as colunas pedidas no
briefing foram incluídas. Nenhuma exclusão física: imóveis e usuários usam
`status` (`ativo/inativo`, `ativo/suspenso`) em vez de `DELETE`.

## Serviços (`js/services/`)

Cada serviço concentra as regras de negócio e checagens de autorização de uma
entidade (ex.: `propertiesService.atualizar()` valida se `owner_id` bate com o
usuário logado antes de editar — a mesma checagem que precisaria existir num
backend real). Isso separa "regra de negócio" de "código de tela".

## Autenticação (`js/auth.js`)

- `Auth.signUp({nome,email,telefone,tipo_usuario,senha})` — cria conta (perfis
  públicos: `anfitriao` ou `profissional`; `administrador` só existe via seed).
- `Auth.login(email,senha)` / `Auth.logout()` / `Auth.getSessao()`.
- `Auth.exigirLogin()` / `Auth.exigirPerfil('anfitriao', ...)` — usados no topo
  do JS de cada página protegida; redirecionam se não autorizado.
- Senhas passam por SHA-256 + salt (Web Crypto API) antes de ir ao "banco" —
  reduz o óbvio (senha em texto puro), mas não substitui um backend real.

## Geolocalização (`js/geo.js`)

Estrutura genérica `Estado → Cidade → Bairro`. Bairros só estão preenchidos
para **Praia Grande/SP** (cidade piloto) — Santos, São Vicente, Guarujá,
Mongaguá e Itanhaém já existem na estrutura, prontos para receber bairros.
Os `<select>` de cidade/bairro em `imovel-form.html` são montados
dinamicamente a partir deste arquivo (nada hardcoded na interface).

## Dados fictícios (`js/seed.js`)

Só rodam se `APP_CONFIG.ENV !== 'prod'`. Criam apenas as categorias de serviço
padrão e 1 usuário administrador de teste — nenhum imóvel/profissional fictício
é criado, para não misturar dados de demonstração com dados reais.

## Testes realizados nesta etapa

1. `node --check` em todos os arquivos `.js` — sem erros de sintaxe.
2. Simulação de ponta a ponta em Node (mock de `localStorage`/`crypto`) cobrindo:
   cadastro de anfitrião, logout/login, login com senha errada (deve falhar),
   cadastro de imóvel, tentativa de edição por usuário sem permissão (deve
   bloquear), ativar/desativar imóvel (sem exclusão física), cadastro de
   profissional + aprovação pelo administrador, criação de reviews e
   recálculo automático de reputação, e checagem da trilha de auditoria.
   **Resultado: todos os cenários passaram.**
3. Verificação de tags HTML balanceadas e ausência de `id` duplicado em cada
   página.
4. **Não testado nesta etapa** (por não haver navegador disponível neste
   ambiente de geração de código): clique-a-clique manual na interface real.
   Recomenda-se um teste manual rápido antes de considerar a etapa
   definitivamente fechada.

## O que NÃO foi implementado nesta etapa (conforme solicitado)

Mapa de oportunidades, chat, pagamentos, GPS operacional, disputas, ranking
avançado, e qualquer correspondência automática entre solicitações e
profissionais (as telas de "Solicitações" mostram um estado vazio honesto,
explicando que o módulo vem na próxima etapa — nada foi simulado como se
estivesse pronto).

---

## Etapa 2 — Marketplace de oportunidades (concluída)

### Novidades

- **Solicitação de serviço** (`solicitar-servico.html`, wizard de 3 passos): o
  anfitrião escolhe imóvel → categoria (Limpeza / Pequenos Reparos / Roupa de
  cama/Enxoval) com campos específicos de cada uma → vê o preço calculado
  antes de publicar.
- **Snapshot imutável**: ao publicar, `ServiceRequestsService.publicar()`
  congela imóvel, detalhes, fotos, data/horário e precificação em
  `service_requests.snapshot`. Após um profissional ser aceito, qualquer
  mudança passa obrigatoriamente por `alterarFormalmente()`, que grava a
  alteração em `historico_alteracoes` e notifica o profissional — nunca é
  silenciosa.
- **Motor de precificação** (`js/pricingConfig.js` + `js/pricingService.js`):
  regras configuráveis (sem ML) que consideram categoria, tamanho do imóvel,
  quantidade de enxoval, fim de semana, feriados fixos, temporada alta
  (verão), horário fora do comercial e urgência. Separa claramente **valor do
  anfitrião**, **valor do profissional**, **comissão da plataforma** e **taxa
  de conveniência**, e registra cada componente do cálculo (`componentes[]`)
  para uma futura análise estatística.
- **Mapa de oportunidades** (`oportunidades.html`) — tela principal do
  profissional, com Leaflet + OpenStreetMap (CDN), geolocalização **real** do
  navegador (`js/geoLocation.js`, wrapper de `navigator.geolocation`) com
  tratamento de permissão negada / GPS desligado / indisponível / baixa
  precisão — nunca inventa uma posição. Painel inferior com filtros por
  categoria, distância (Haversine), urgência e valor estimado.
- **Matching** (`js/matching.js`): filtra por categoria compatível e
  capacidade simultânea (máx. configurável de serviços simultâneos), ordena
  por distância/urgência/recência. Documentado como regra de 1ª geração, sem
  IA.
- **Fluxo de interesse completo** (`js/services/interestsService.js`):
  profissional demonstra interesse → anfitrião vê perfil/reputação/histórico
  em `solicitacao-detalhe.html` → aceita ou rejeita → ao aceitar, a
  oportunidade é **bloqueada** (demais interesses viram "recusado"
  automaticamente e são notificados).
- **Notificações** (`notificacoes.html`): interesse recebido, interesse
  aceito/recusado, alteração formal e conclusão já geram notificações reais
  (não simuladas) — visíveis com contador no sino do topo.
- **Status implementados de ponta a ponta**: `DRAFT → PUBLISHED → ACCEPTED →
  IN_PROGRESS → COMPLETED`, além de `CANCELLED`. Os demais da lista do
  briefing (`PAYMENT_PENDING`, `PAID`, `HELD`, `TRAVELING`, `DISPUTED`, etc.)
  estão **definidos como constantes** em `js/statusMachine.js` para uso nas
  próximas etapas, mas **sem transição funcional ainda** — isso está
  comentado no próprio arquivo para não serem confundidos com prontos.
- **Admin**: nova seção "Solicitações de serviço" lista todas as solicitações
  com status, imóvel e anfitrião.

### Limitações reais desta etapa

- O mapa usa Leaflet + tiles do OpenStreetMap via CDN — **precisa de
  internet** para carregar os tiles (assim como Tailwind/Lucide/Google Fonts).
- Reputação do profissional só existe a partir de `reviews` reais — nenhuma
  nota é inventada; profissional novo aparece com reputação `0.0` até
  receber a primeira avaliação.
- "Distância do profissional" só aparece quando o navegador concede
  permissão de geolocalização E o imóvel tem lat/lng cadastrados; caso
  contrário a oportunidade aparece sem distância, nunca com um valor falso.
- Oferta/demanda como fator de precificação **não foi implementado**
  (precisaria de estatísticas históricas que ainda não existem) — o motor
  já está estruturado para receber esse fator depois.
- Como no restante do projeto, tudo roda em `localStorage`: não há
  compartilhamento real entre dispositivos.
- **Não implementado nesta etapa** (conforme escopo do pedido): pagamento,
  disputas/contestação, deslocamento em tempo real (GPS ao vivo durante o
  atendimento), vídeos em anexo (só fotos).

### Testes realizados

1. `node --check` nos 26 arquivos `.js` do projeto — sem erros.
2. Todas as 12 páginas servidas via HTTP local — todas HTTP 200; nenhuma
   referência local quebrada; nenhum `id` duplicado por página.
3. Simulação de ponta a ponta em Node (15 cenários), cobrindo exatamente o
   roteiro pedido: criar imóvel → criar solicitação → publicar (snapshot +
   preço) → matching mostra a oportunidade para profissionais compatíveis →
   dois profissionais demonstram interesse → anfitrião vê os dois → aceita um
   → o outro é automaticamente recusado e notificado → solicitação some da
   lista de publicadas → tentativa de aceitar de novo falha → alteração
   formal pós-aceite fica no histórico e notifica o profissional → transições
   IN_PROGRESS → COMPLETED (bloqueando profissional não-atribuído) →
   capacidade simultânea bloqueia novas oportunidades no 4º serviço →
   categoria "Pequenos Reparos" com "necessita avaliação" não gera cobrança →
   auditoria contém todos os eventos-chave. **Todos os 15 passaram.**
4. Teste isolado do motor de precificação: multiplicador de fim de semana,
   feriado fixo, temporada alta, urgência, horário fora do comercial e
   dedução por deslocamento — **todos os 7 checks passaram**.
5. **Não testado nesta etapa**: interação real por toque/mouse num navegador
   (mapa arrastando, cliques nos marcadores, popup do Leaflet) — este
   ambiente de geração de código não tem navegador interativo. Recomenda-se
   abrir `oportunidades.html` manualmente e testar o mapa/filtros/popup antes
   de seguir para pagamentos.

---

## Etapa 3 — Operação, chat oficial e arquitetura financeira (concluída)

### Novidades

- **Chat oficial por solicitação** (`chat.html`, `js/services/chatService.js`): cada `service_request` tem seu próprio chat (`chat_messages.service_request_id`). Suporta texto, fotos, vídeos e documentos (base64), além de **mensagens automáticas do sistema** disparadas em eventos-chave (aceite, deslocamento, chegada, conferência, divergência, finalização).
- **Bloqueio real de contato externo** (`js/contactFilter.js`): detecta telefone (com/sem separadores), WhatsApp/zap/wpp, e-mail, `@usuário`, links, domínios (`.com`, gmail, instagram, telegram etc.) e uma heurística para números escritos por extenso. A checagem roda **dentro de `ChatService.enviarMensagem`** — é o único caminho para gravar uma mensagem, então mesmo chamando o serviço diretamente (sem usar a tela) a mensagem bloqueada não é salva. Tentativas ficam em `contact_violations` e na auditoria; reincidência (3×) gera alerta e (8×) suspende a conta automaticamente.
- **Arquitetura financeira real, mas em sandbox** (`js/services/paymentsService.js` + `js/paymentGatewayAdapter.js`): uma linha em `payments` por solicitação, sempre separando valor do anfitrião / valor do profissional / comissão / taxa de conveniência / taxa de deslocamento. Estados `PENDING → AUTHORIZED → HELD → RELEASE_PENDING → RELEASED`, mais `DISPUTED`, `REFUNDED`, `PARTIALLY_REFUNDED`. **Nenhum dinheiro real é movimentado** — o adapter simula os retornos que Stripe Connect/Mercado Pago Marketplace dariam, para que trocar por uma integração real signifique reescrever só esse arquivo.
- **Deslocamento e chegada com GPS real** (`ServiceRequestsService.iniciarDeslocamento/registrarChegada`): usa `GeoLocation` (Etapa 2) para capturar a posição real do profissional; valida proximidade com o imóvel via distância Haversine com tolerância configurável (`APP_CONFIG.TOLERANCIA_CHEGADA_KM`). Fora do raio não bloqueia (GPS de celular erra), mas fica registrado como evidência.
- **Conferência obrigatória** (tela `execucao.html`): "A solicitação corresponde ao que você encontrou?" → SIM avança para `IN_PROGRESS`; NÃO abre o protocolo de divergência.
- **Protocolo de divergência e contestação completo** (`js/services/disputesService.js`): profissional abre divergência com motivo (lista fechada), descrição, fotos e GPS → anfitrião é notificado e responde → **decisão é sempre um ato humano registrado** (hoje pelo administrador, em `admin.html`) considerando ambas as versões — a plataforma nunca decide sozinha nem acredita automaticamente em nenhum dos lados. Durante a disputa o pagamento fica em `DISPUTED` e a liberação é bloqueada.
- **Taxa de deslocamento/disponibilidade configurável**: aplicada apenas por decisão explícita do administrador, com valor livre (não fixo) e motivo registrado; descontada dos fundos retidos e destinada ao profissional na liberação.
- **Reparos "nova avaliação" e recontagem de enxoval sem execução forçada** (`ServiceRequestsService.proporAlteracao/responderPropostaAlteracao`): o profissional propõe um novo escopo/preço, e **nada muda até o anfitrião aprovar** — fica registrado em `historico_alteracoes` e, se aprovado, cria ou ajusta o pagamento.
- **Finalização em duas etapas**: profissional envia fotos/checklist/observações/horário (`UNDER_REVIEW`) → anfitrião revisa e confirma (`COMPLETED`) → isso dispara `RELEASE_PENDING` → uma ação separada libera de fato (`RELEASED`). Nunca é automático/instantâneo.
- **Evidências centralizadas** (`js/services/evidencesService.js`): toda ocorrência (deslocamento, chegada, divergência, finalização) grava quem/quando/onde(GPS)/solicitação/tipo/texto/mídia — é o material citado na tomada de decisão de uma disputa.
- **Permissões por solicitação**: `ChatService._garantirParticipante` só deixa acessar o chat quem é o anfitrião dono, o profissional aceito ou um profissional que já demonstrou interesse; `PropertiesService`/`ServiceRequestsService`/`DisputesService` continuam checando `owner_id`/`accepted_provider_id` em cada ação (não só escondendo botão na tela).

### Limitações reais desta etapa

- **Pagamento é 100% sandbox.** `PaymentGatewayAdapter` não se conecta a nenhum gateway real — está desenhado para ser substituído por uma integração real de marketplace (Stripe Connect, Mercado Pago Marketplace etc.) trocando só esse arquivo. Nenhuma cobrança, retenção ou repasse real acontece.
- Não existem **webhooks de rede** de verdade (este projeto não tem servidor); o "webhook" documentado em `paymentGatewayAdapter.js` é só o contrato de dados esperado para quando houver backend.
- O filtro de contato externo é uma **lista de heurísticas/regex**, não é infalível — números muito disfarçados ou codificados de formas incomuns podem escapar. Está estruturado para adicionar mais padrões facilmente.
- A validação de proximidade de chegada depende da precisão do GPS do aparelho; por isso ela **alerta, mas não bloqueia** o profissional fora do raio.
- A decisão de disputa é tomada por um administrador humano dentro do próprio app — não há um time de "confiança e segurança" real nem SLA.
- Vídeo é aceito como anexo no chat/divergência (arquivo bruto em base64), mas sem compressão/streaming — arquivos grandes deixam o `localStorage` pesado rapidamente (limitação inerente a usar localStorage como "banco").
- Como em toda a aplicação, tudo é local ao navegador — sem sincronização entre dispositivos.

### Testes realizados

1. `node --check` em todos os arquivos `.js` do projeto (34 arquivos) — sem erros.
2. Todas as 14 páginas servidas via HTTP local — todas HTTP 200; nenhuma referência quebrada; nenhum `id` duplicado por página.
3. Bloco de filtro de contato — 9 casos (telefones em 3 formatos, e-mail, @usuário, link, "zap", 2 mensagens legítimas que não devem ser bloqueadas) — **todos corretos**.
4. Fluxo feliz completo simulado em Node: aceite → pagamento vai a `HELD` automaticamente → mensagem com contato externo é bloqueada e registrada → deslocamento → chegada dentro do raio → conferência SIM → execução → finalização → confirmação do anfitrião → `RELEASE_PENDING` → liberação manual → `RELEASED`. **Todos os passos passaram.**
5. Fluxo de divergência simulado: chegada → conferência NÃO → abertura de divergência (motivo + fotos + GPS) → status vira `DISPUTED` e pagamento também → anfitrião notificado → anfitrião responde → tentativa de liberar pagamento durante a disputa **falha corretamente** → administrador decide com taxa de deslocamento de R$ 25 → serviço retomado (`IN_PROGRESS`) → pagamento volta a `HELD` com a taxa registrada em `ajustes`. **Todos os passos passaram.**
6. Fluxo de reparo "necessita avaliação": publicado sem pagamento → aceito sem pagamento → profissional propõe novo orçamento → fica pendente (profissional não é obrigado a executar sem aprovação) → anfitrião aprova → preço aplicado formalmente → pagamento criado agora com valor definido. **Todos os passos passaram.**
7. Reconstrução da negociação via auditoria: 16 tipos de ação-chave (publicar, aceitar, pagamento autorizado, mensagem de chat, tentativa bloqueada, deslocamento, chegada, conferência, finalização, confirmação, liberação, abrir/responder/decidir divergência, aplicar taxa, propor alteração) confirmados presentes no log.
8. Teste de regressão final após integrar as telas: o pipeline completo (aceite → pagamento `HELD` → operação → `RELEASED`) foi re-executado sobre os arquivos definitivos e passou.
9. **Não testado nesta etapa**: interação real por toque/mouse num navegador (chat rolando, upload de arquivo real, popup de permissão de geolocalização do navegador). Recomendo abrir `execucao.html` e `chat.html` manualmente e testar o fluxo com o navegador pedindo localização de verdade.
