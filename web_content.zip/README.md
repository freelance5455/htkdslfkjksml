# NVK FREE REDEEM — Mobile Prototype

Open `index.html` in a browser to test the UI.

Included:
- NVK branding
- Home
- Tasks
- Points
- Redeem
- Profile
- Basic point/redeem demo logic

Important:
This is a front-end prototype. It does not create real Free Fire redeem codes,
process payments, or connect to a real database. Real rewards must come from
legitimate/authorized sources.

Next development stage:
1. Real login/signup
2. Firebase/Supabase database
3. Secure server-side points
4. Admin dashboard
5. Legitimate reward management
6. Android APK build
