# پلنر جامع مطالعاتی - اپ اندروید

فایل HTML بدون تغییر در `app/src/main/assets/index.html` قرار دارد و اپ کاملاً آفلاین است.

## ساخت APK با GitHub
1. در github.com یک Repository جدید بسازید (Public یا Private).
2. محتویات این پوشه را آپلود کنید (Add file > Upload files). پوشه‌ی `.github` باید در ریشه‌ی مخزن دیده شود.
3. تب **Actions** > **Build APK** > **Run workflow**.
4. بعد از چند دقیقه، در پایین صفحه‌ی اجرا، فایل **StudyPlanner-APK** را دانلود و unzip کنید: `app-release.apk`.
5. روی تبلت نصب کنید.

نکته: همه‌ی نسخه‌ها با یک کلید ثابت امضا می‌شوند، پس نسخه‌ی جدید روی قبلی نصب می‌شود و اطلاعات پاک نمی‌شود.

## ساخت با Android Studio
پوشه را Open کنید، سپس Build > Generate Signed App Bundle / APK یا از ترمینال: `gradle assembleRelease`
