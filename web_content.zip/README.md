# Vida Urbana RP — V5
Versão mobile landscape-first com foco em jogabilidade.

## Controles
- Joystick esquerdo: movimento 360° / aceleração e direção do carro.
- Arrastar no lado direito: câmera.
- INTERAGIR: entrar/sair do carro e interações.
- TRABALHO: iniciar/concluir entrega.

## Tela horizontal
O projeto inclui PWA com `orientation: landscape` e, ao entrar no jogo, tenta usar fullscreen + `screen.orientation.lock('landscape')`.
Em navegador comum, o sistema operacional pode impedir a rotação automática; como PWA instalado, o manifesto permite abrir em landscape.

## Execução
`npm install`
`npm start`

O multiplayer usa WebSocket no mesmo servidor.
