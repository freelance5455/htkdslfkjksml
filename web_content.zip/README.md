# ByteMart Uganda — Electronics E-commerce ICT Project

A mobile-friendly electronics shop starter project using HTML, CSS, JavaScript and Node.js/Express. It displays sample products in UGX, supports search and category filters, maintains a cart in the browser, accepts demo orders, stores orders on the server, and provides a simple protected admin order dashboard.

## Important: payment status

**MTN MoMo and Airtel Money are demo-only in this code.** Choosing either option records an order marked `DEMO_NOT_PAID`. The project does not contact either mobile-money provider, send a payment prompt, verify a transaction, or collect money. Do not tell customers that a demo order is paid.

For live payments, register with the relevant payment provider or an approved payment aggregator, complete business/KYC requirements, obtain production credentials, and implement server-side payment initiation plus callback/status verification. Never put secret API credentials in browser JavaScript. Review the official MTN MoMo developer portal: https://momo.mtn.com/api/ and MTN Uganda Open API information: https://www.mtn.co.ug/helppersonal/mtn-open-api/. Uganda aggregator documentation that describes MTN and Airtel collection options is available at https://apidoc.govbill.ug/ and https://docs.govbill.ug/utility-functions/payment-options. Check current eligibility, fees, requirements and availability directly with the provider.

## Run on a laptop/desktop

Requirements: Node.js 18 or newer.

1. Extract the ZIP file.
2. Open a terminal in the extracted project folder.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Copy `.env.example` to `.env` and set a long random `ADMIN_KEY`. The app currently reads environment variables from the process; it does not automatically load `.env`. If you use a terminal, set variables before starting, or install/configure a dotenv loader yourself.
   - Linux/macOS:
     ```bash
     export ADMIN_KEY='replace-with-a-long-random-secret'
     export PAYMENT_MODE=demo
     npm start
     ```
   - Windows PowerShell:
     ```powershell
     $env:ADMIN_KEY='replace-with-a-long-random-secret'
     $env:PAYMENT_MODE='demo'
     npm start
     ```
5. Open `http://localhost:3000` in your browser.
6. Admin orders: open `http://localhost:3000/admin.html` and enter the same `ADMIN_KEY`.

## Run using only an Android phone

One practical option is a browser-based development workspace such as Replit, if available to your account:

1. Create a new Node.js project/workspace.
2. Upload the contents of this ZIP (or upload the files individually).
3. Make sure `package.json`, `server.js`, `public/`, and `data/` are in the project root structure shown below.
4. In the workspace's Shell/Secrets settings, install dependencies with `npm install`, set `ADMIN_KEY` as a secret/environment variable, and run `npm start`.
5. Use the workspace's web preview to open the shop. For a public link, deploy to a Node.js hosting service and set `ADMIN_KEY` in its environment settings.

Hosting platforms differ, and free tiers, persistence and workspace availability can change. Confirm that the chosen host keeps `data/orders.json` persistent; some temporary workspaces reset files when stopped or redeployed.

## Project structure

```text
ug-electronics-shop/
├── server.js
├── package.json
├── .env.example
├── README.md
├── data/
│   └── orders.json
└── public/
    ├── index.html
    ├── styles.css
    ├── app.js
    └── admin.html
```

The `data/orders.json` file is created automatically on first start. Back it up before redeploying or moving the project.

## Features included

- Responsive product catalogue with sample electronics
- UGX price formatting
- Search and category filters
- Add/remove cart items and quantity controls
- Checkout form with name, phone and delivery address
- Server-side validation and order totals calculated from server catalogue prices
- Order IDs and order storage
- Admin order list and order status updates
- Demo labels to prevent false claims that mobile-money payment was received

## Limitations before real-world launch

This is a learning prototype, not a production-ready store. Before handling real customers or money, add persistent database storage, secure admin authentication and sessions, HTTPS, CSRF/rate-limit protections, privacy notice and data retention policy, server-side inventory reservation, order notifications, tested backups, and verified payment callbacks. The simple admin key header is for a controlled project demo only. Do not store customer data on an untrusted public demo.
