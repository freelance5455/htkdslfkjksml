# تعليمي

https://freewan-studio-ai-vi-xsi5.bolt.host

## Project Structure

This is a Capacitor project export. The web app is in `www/`; Capacitor creates the native Android project after setup.

## Prerequisites

- Node.js 18+
- Android Studio
- Java JDK 17

## Build Instructions

### Build an APK or AAB with Capacitor

```bash
npm install
npx cap add android
npx cap sync android
npx cap build android
```

The APK is created at `android/app/build/outputs/apk/debug/app-debug.apk`.
The AAB is created at `android/app/build/outputs/bundle/release/app-release.aab`.

### Build with Android Studio

1. Run the commands above once so Capacitor creates the native project.
2. Open the generated `android/` folder in Android Studio.
3. Wait for Gradle sync.
4. Choose **Build > Build Bundle(s) / APK(s)**.

### Option 3: Cloud Build (GitHub Actions)

Push this project to GitHub and use any CI service with Android SDK to build.

## App Details

- **Name:** تعليمي
- **Package:** app.generated
- **Description:** https://freewan-studio-ai-vi-xsi5.bolt.host
- **Screens:** اسم التطبيق, الوظائف الرئيسية, المحتوى التعليمي
- **Navigation:** التنقل
- **Functions:** الوظائف الرئيسية, المحتوى التعليمي, الأصول المطلوبة

## Capacitor Config

The project includes a pre-configured `capacitor.config.json`. The ZIP does not claim to contain an APK. Android Studio and Capacitor must create the native Android project on a computer with the Android SDK installed.
