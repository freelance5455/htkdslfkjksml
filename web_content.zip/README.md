# Finance Calculator — Offline Web/App Bundle

A mobile-first finance calculator UI designed to be bundled into an Android APK. Core calculations run locally in the browser/webview and do not require a network connection.

## Included calculators
- Loan Payment
- Mortgage
- Loan Payoff
- Mutual Fund Return
- Compound Interest
- Investment Return
- Savings Growth
- Savings Goal
- Tax / VAT
- Tip Calculator
- Percentage

## Local features
- Recent calculation history
- Saved calculations
- Scenario comparison
- What-if rate slider on growth/loan calculators
- Share results using the Android/browser share sheet when available
- Light / dark / system theme
- Display currency selector

## Packaging
The folder is self-contained and uses no external runtime assets or CDNs. Zip the folder contents and upload them to an HTML-to-APK/webview packaging service of your choice.
