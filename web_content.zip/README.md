# School Manager v1.1

Offline-first school database for a private school.

## Changes
- Algerian school-year fields: 1AP–5AP, 1AM–4AM, 1AS–3AS.
- Student, session, and schedule records store the school year.
- Fixed monthly fees are calculated from the student cycle; no manual monthly price entry.
- One payment can include yearly registration plus multiple monthly subjects.
- Payment subjects are validated against the student’s active registrations.
- Unpaid registration list includes every unpaid student with direct profile/payment actions.
- Student creation/editing includes Save and Save & record payment.
- Profiles show paid-through / next-due information for the selected month.
- Existing data is migrated without deleting records; older students may need a year selected when edited.
