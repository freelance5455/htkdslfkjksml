# Bhagyalaxmi Delivery Challan (offline)

This is a local, single-device delivery-challan app. It does not use a server, account, or internet connection (WhatsApp sharing opens WhatsApp only when you press the button). Challans, saved recipients, and transport names stay in the browser storage on the device where you use it.

## Start it

Open `index.html` in Chrome or Edge.

## Use it on an Android phone

1. Copy the complete app folder to the phone. Keep `index.html`, `app.js`, `styles.css`, and the `assets` folder together.
2. In the phone's Files app, open `index.html` using Chrome. If the Files app only offers a viewer, use its **Open with browser** option.
3. Use the same browser each time. Saved challans are stored only in that browser on that phone.
4. To send a challan: press **Share on WhatsApp**. WhatsApp opens with the message pre-filled. Choose the contact or group, check the message, and press send yourself. Nothing is sent automatically.
5. If WhatsApp does not open, the message appears in the "WhatsApp message" box. Press **Copy message** and paste it into WhatsApp.
6. **Print / Save PDF** only works where the app wrapper supports printing (see `APKFORGE-NOTES.md`). In Chrome it opens the browser print dialog, where you can choose **Save as PDF**.

## Use it

1. Enter the recipient, transport, vehicle, and items.
2. Leave challan number on **Automatic** to get the next `DC-0001` style number, or choose **Manual** to type your own. Challan numbers must be unique.
3. For an item, enter NOS or SET. The blank one becomes `–` in the printable challan. Leave amount blank when it should not be included in the total.
4. Click **Save challan**. Use the Previous challans list to find and reopen a saved challan. Changing a reopened challan and saving it updates the same record.
5. A challan needs a challan number, and at least a recipient or one item, before it can be saved or shared.

## Important

- Browser data is local to this browser profile. Do not clear browser site data if you want to keep the saved challans.
- The app has no multi-user synchronization or network access. A later version can add backups or shared access.
- Saved data that cannot be read (for example, damaged storage) is ignored rather than crashing the app. A save that the browser refuses shows a "NOT saved" message.

## Files

- `index.html` - page layout and printable challan.
- `app.js` - all behaviour: saving, loading, WhatsApp message, printing.
- `styles.css` - design and print layout.
- `assets/company-logo.png` - company logo.
- `tests/smoke-test.py` - optional browser test (see `APKFORGE-NOTES.md`).
- `APKFORGE-NOTES.md` - how to import and rebuild the APK, and what the wrapper must provide.
