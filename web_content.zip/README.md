# CGD – Championnat Galactique de Dames

Ce dossier est une nouvelle base indépendante. Il ne modifie pas l'archive V116.

## Fonctions actuellement présentes
- hiérarchie à cinq divisions : Super League, Ligue A, Ligue B, Ligue C, Ligue D ;
- activation différée de C en saison 3 et D en saison 5, avec 12 clubs disponibles requis ;
- exactement deux damistes par club dans les données initiales ;
- génération aller-retour (22 journées pour 12 clubs) ;
- registre central de rencontres avec identifiants déterministes et protection contre le double traitement d'un résultat ;
- cinq niveaux de divisions et huit compétitions distinctes : sept historiques et la Coupe Fédéral ajoutée ;
- sauvegarde locale versionnée et validation de cohérence ;
- interface horizontale avec défilement horizontal des divisions sur petits écrans ;
- moteurs Coupe Galactique, Coupe des Clubs, Coupe Fédéral et Champions League raccordés au calendrier ;
- calendrier central avec événements séparés d’au moins un jour complet, contrôle des chevauchements et dates officielles non inventées.

## Limites explicites
Ce n'est pas encore le jeu complet ni un portage final des règlements. Les huit compétitions sont conservées distinctement. La Coupe Galactique, la Coupe des Clubs, la Coupe Fédéral et la Champions League disposent maintenant de moteurs raccordés au calendrier central. La Champions League reprend le format V116 audité : 32 clubs, 8 groupes de 4, 6 journées aller-retour, deux qualifiés par groupe, puis huitièmes, quarts, demi-finales et finale. La phase de groupes compte 96 matchs et le tournoi 111 matchs au total. La Coupe Lunaire AGD est désormais auditée et raccordée : huit représentants, élimination directe en trois tours, 7 matchs au total et fenêtre du 12e mois lunaire. Les deux compétitions intergalactiques AGD et la Dame d’Or restent à intégrer après audit. Les données des clubs affichées sont des données de démonstration et ne remplacent pas l'import des identités historiques de la V116. Le moteur de plateau 10×10 et sa simulation IA sont disponibles, mais l’IA reste heuristique. Les systèmes complets de finances, transferts, staff, carrière, récompenses et les moteurs des compétitions encore non portées restent à développer.

## Étape 1.5 — Champions League Galactique
- Audit du code V116 : 32 clubs, 4 chapeaux de 8, 8 groupes de 4, 6 journées aller-retour, deux qualifiés par groupe.
- Tableau final à 16 clubs : huitièmes, quarts, demi-finales et finale, en match unique, sans petite finale.
- 96 matchs de groupes + 15 matchs à élimination directe = 111 matchs.
- Qualification des 32 clubs selon les points puis le niveau ; classement des groupes selon points, différence de buts et buts marqués, comme dans V116.
- Calendrier central : une date de mardi distincte par journée, sans déplacer les dates déjà protégées lorsqu’un nouveau tour est créé. Le planificateur réserve les créneaux du mardi actuellement établis pour la Coupe Galactique, la Coupe Fédéral et la Champions League, sans chevaucher les jeudis lunaires ni les samedis de championnat. La Coupe Lunaire AGD utilise les trois créneaux du mois 12 hérités du planificateur V116 (offsets 342, 349 et 356).
- Matchs IA simulés par le moteur commun de dames ; le match du club dirigé reste jouable ; résultats et statistiques distincts du championnat.
- 107 tests automatisés réussis. Le test réel navigateur/mobile reste à effectuer.

## Lancer les tests
Node.js 18+ : `npm test`

## Ouvrir
Servir le dossier avec un serveur HTTP local (les modules JavaScript ES sont chargés via `type="module"`).

## Exigence fonctionnelle centrale
Lire `SPEC_FONCTIONNEL_FOOTBALL_MANAGER_V117.md` : la CGD doit devenir un jeu de gestion complet, avec les huit compétitions réellement jouables (sept historiques et la Coupe Fédéral), un moteur de dames commun aux matchs manuels et simulés, un calendrier central et une carrière cohérente. Le socle 0.1 n'est pas encore le jeu complet.

## Étape 0.2 — premier moteur de dames jouable
- moteur pur 10×10 isolé dans `src/draughts.js` ;
- règles reprises de l'orientation de la V116 : pions, dames volantes, prise obligatoire, prise multiple et prise maximale ;
- partie d'essai contre une IA heuristique jouable depuis l'interface ;
- tests unitaires supplémentaires pour les coups légaux, prises, promotion, fin de partie et choix de l'IA.

**Limite de cette étape :** cette partie d'essai valide le moteur de plateau, mais elle n'est pas encore reliée aux sept compétitions ni au calendrier de carrière. Les compétitions ne doivent pas être annoncées comme entièrement jouables avant cette intégration et les tests de progression jusqu'aux finales.

## Étape 0.3 — calendrier et simulation de journée
- Simulation déterministe des rencontres à partir de la force moyenne des deux damistes et d'un avantage du terrain.
- À chaque journée, les matchs des autres clubs peuvent être simulés automatiquement tandis que la rencontre du club dirigé reste en attente.
- Le match du club dirigé peut aussi être simulé ; son score alimente immédiatement les statistiques et le classement, sans double comptabilisation.
- Affichage des prochaines rencontres et des derniers résultats.
- Cette simulation de championnat est distincte du damier jouable d'essai : le damier n'est pas encore relié à la rencontre de carrière.


## Étape 0.4 — chronométrage et patrimoine V116
- Catalogue historique intégré à l’état de carrière : 24 galaxies, 60 emplacements d’arènes de clubs, 9 arènes spéciales à règles, 11 variantes visuelles, 24 damistes légendaires (13 historiques + 11 nouveaux profils), 10 banques, 12 sponsors, 8 promoteurs, 16 partenaires et 22 entreprises.
- Les anciennes sauvegardes reçoivent le catalogue patrimonial si celui-ci manque.
- Le moteur d’application refuse désormais les coups illégaux.
- La règle V117 demandée est de 20 secondes de réflexion par tour : à l’échéance, le joueur perd la main et l’adversaire joue ; aucune pièce n’est retirée.
- Rapport de vérification détaillé : `AUDIT_HERITAGE_V116_V117.md`.

**Limite :** le temps global de 5 minutes, la prolongation de 3 minutes et les modificateurs de règles des arènes sont inventoriés mais restent à intégrer. Les pouvoirs des légendes, l’affectation des 60 arènes aux clubs historiques et les systèmes économiques complets restent en cours.

## Étape 0.5 — moteur de chronométrage global (module isolé)
- Nouveau module `src/match-clock.js` : temps standard de 5 minutes, prolongation de 3 minutes en cas d'égalité du nombre de pièces à l'expiration initiale ; décision au nombre de pièces à l'expiration finale.
- Règles chronométriques spécifiques relevées dans V116 : arène Néon (2 minutes), Galactique Suprême (2 min 30), arène Temporelle (pas de chrono global, 40 tours par camp puis comparaison des pièces).
- Tests dédiés des transitions et des décisions temporelles.

**Limite de l’étape 0.5 :** à ce jalon, le module était encore isolé. Son raccordement au moteur de dames et au calendrier est décrit à l’étape 0.7 ci-dessous.

## Étape 0.7 — arènes, horloges et calendrier central reliés
- Nouveau registre `src/arena-rules.js` : neuf arènes spéciales, avec les règles exactes relevées dans V116 séparées des variantes purement visuelles.
- Le moteur `src/draughts.js` reçoit désormais l'identifiant d'arène et applique les effets sur les coups légaux et les déplacements : cristaux, lave, gravité, prises océaniques, promotion dimensionnelle.
- Le chrono global est branché sur la partie : standard 5 min + 3 min de prolongation si égalité de pièces, Néon 2 min, Galactique Suprême 2 min 30, Temporelle 40 coups par camp sans chrono global.
- Chaque camp dispose de 20 secondes par tour. À l'échéance, la main passe à l'adversaire, sans retrait de pièce.
- La règle de nulle des 50 demi-coups sans prise ni déplacement de pion est également appliquée dans la partie jouable.
- La rencontre du club dirigé peut être lancée depuis le calendrier central. À la fin, le résultat est inscrit une seule fois, les statistiques des clubs et le classement sont mis à jour, et les détails de l'arène/partie sont conservés sur la rencontre.
- Les rencontres de carrière gardent leur moteur de simulation automatique séparé ; le match sur damier est utilisé lorsque l'utilisateur lance sa propre rencontre.
- Tests unitaires ajoutés pour les effets d'arènes et le raccordement calendrier-classement.

**Limites de validation :** les tests automatisés couvrent les modules et l'intégration métier du résultat. Aucun test complet dans un navigateur réel n'est revendiqué ici. Les 7 compétitions autres que le championnat de division, les pouvoirs des légendaires et les effets des arènes sur les matchs simulés automatiquement restent à intégrer.


## Socle 0.9 — moteur commun des rencontres simulées

- Les rencontres automatiques de championnat sont désormais jouées par deux IA sur un damier 10×10 via `src/board-simulation.js`.
- La simulation utilise les coups légaux, prises obligatoires, prises maximales, dames volantes, promotions, règles spéciales des arènes et conditions de fin du moteur `draughts.js`.
- Le chronométrage global propre à l'arène est appliqué ; la réflexion simulée de chaque camp reste inférieure ou égale à 20 secondes.
- Les simulations sont déterministes pour une même rencontre/saison et enregistrent le détail du moteur, l'arène, le nombre de demi-coups, les pièces restantes, les temps et les tours.
- Le calendrier central et le classement sont mis à jour via `recordResult`, avec protection contre le double enregistrement.
- Les rencontres du club dirigé peuvent toujours être laissées en attente pour une partie manuelle ou simulées à la demande.

**Limites restantes :** l'IA est heuristique et non un moteur de niveau expert ; le moteur commun est raccordé aux rencontres de championnat, mais les règlements et calendriers propres aux sept compétitions restent à inventorier/implémenter. La Dame d'Or est une course individuelle et ne doit pas être traitée comme une coupe de matchs. Aucun test navigateur réel n'est revendiqué à cette étape.


## Huitième compétition — Coupe Fédéral

La Coupe Fédéral est une nouvelle compétition ajoutée à la demande de l'utilisateur. Elle s'inspire du format de coupe à élimination directe de l'EFL/Carabao Cup, sans remplacer ni fusionner les sept compétitions historiques.

- Participants : tous les clubs des divisions actuellement actives (36 clubs au lancement initial ; 48 puis 60 lorsque les divisions C et D seront activées).
- Tirage au sort déterministe pour une sauvegarde et une saison données.
- Élimination directe sur une rencontre unique, sans match retour.
- En cas d'égalité, départage aux tirs au but ; aucun match nul ne qualifie un club.
- Finale sur terrain neutre.
- Toutes les rencontres sont inscrites dans le calendrier central avec `competitionId: coupe-federal`.
- Les statistiques de coupe sont séparées des statistiques du championnat.
- Les résultats font avancer automatiquement le tableau ; le vainqueur est archivé dans l'état de compétition.

La Coupe Fédéral est une compétition de clubs. Dame d'Or reste une distinction individuelle. Les sept compétitions historiques restent inchangées.


## Socle 1.0 — Coupe Galactique raccordée au moteur commun

- Audit de la règle V116 : 8 clubs au total, dont le club dirigé et 7 autres clubs tirés parmi les clubs disponibles ; tableau à élimination directe en trois tours : quarts, demi-finales, finale.
- Les trois tours sont programmés aux journées 6, 12 et 18 du championnat, conformément au calendrier V116 (`CUPJ`). Un tour ne peut pas être simulé ou joué avant sa journée prévue.
- Chaque match de la Coupe Galactique est inscrit dans le calendrier central avec un identifiant propre et un `competitionId` distinct. Ses statistiques restent séparées du championnat.
- Les rencontres IA utilisent `simulateBoardMatch`, donc le moteur de dames commun et les règles de l’arène. Le match du club dirigé peut être joué manuellement ; sa victoire/défaite fait progresser le tableau.
- Les résultats nuls sont départagés de manière déterministe pour garantir une reprise identique d’une sauvegarde. Ce départage technique ne prétend pas reproduire une séance de tirs au but : V116 utilisait un choix aléatoire à 50 % en cas de nul.
- Correction du calendrier : les tours de coupe ne peuvent plus perturber le calcul de la prochaine journée de championnat.

**Vérifications du socle 1.0 :** 72 tests automatisés réussis, 0 échec ; vérification syntaxique de tous les modules et tests JavaScript. Une tentative de lancement Chromium headless n’a pas abouti dans l’environnement : le rendu navigateur et le parcours tactile restent donc non validés.

**Limites historiques du socle 1.0 :** cette liste décrit l’état de cette étape ancienne. Consulter les sections de progression 1.1 à 1.6 pour l’état actuel. La Dame d’Or a reçu son moteur individuel au socle 2.0 ; consulter le document de cette étape pour les limites restantes. La Coupe Fédéral demeure une huitième compétition indépendante.

## Socle 1.1 — Coupe des Clubs raccordée

- Règlement V116 porté : 36 clubs des divisions initiales, match unique, entrée progressive Ligue B au 1er tour, Ligue A au 2e, Super League au 3e.
- Tableau calculé : 12 → 18 → 21 → 11 → 6 → 3 → 2 → 1 ; exemptions automatiques en cas de nombre impair. Le parcours comporte six tours puis la finale, soit 35 matchs au total.
- Tirage sans têtes de série, prolongation puis tirs au but en cas d'égalité.
- Calendrier révisé selon la règle confirmée : Coupe des Clubs pendant la saison régulière, chaque jeudi du mois lunaire, jusqu'à la finale. Les anciennes dates fixes du mois 8 (jours 6 à 30) sont abandonnées. Le moteur attend les jeudis lunaires issus du calendrier de référence ; aucune date n'est inventée.
- Répartition institutionnelle confirmée : la FGD organise les championnats et les coupes des clubs ; l'AGD organise les deux compétitions galactiques (Coupe Intergalactique des galaxies et Intergalactique des Clubs). Les championnats sont placés le samedi, une journée par semaine ; la Coupe des Clubs est réservée aux jeudis lunaires officiels ; les coupes FGD disposant de rencontres utilisent des créneaux du mardi libres. Un jour complet de repos est protégé entre deux événements de compétition. Les deux événements AGD sont placés après la date officielle de fin de saison régulière fournie par la FGD, aux dates officielles AGD. Les dates lunaires et AGD ne sont jamais fabriquées.
- Tous les matchs sont ajoutés au calendrier central, simulables par le moteur commun ; le match du club dirigé peut être joué sur le damier. Statistiques de coupe distinctes du championnat.
- Tests automatisés : 77/77 réussis ; vérification syntaxique JavaScript réussie.

**Limites historiques du socle 1.1 :** l'exécution réelle dans un navigateur n'avait pas été validée à cette étape. Depuis, les moteurs Champions League et Coupe Lunaire ont été intégrés. L'Intergalactique des Clubs, la Coupe Intergalactique des galaxies et la Dame d'Or restent à développer.


## Socle 1.3 — Planificateur central FGD / AGD

Le calendrier de carrière adopte une semaine-type inspirée du football réel : championnats le samedi ; créneaux de coupes FGD le mardi ; Coupe des Clubs le jeudi lunaire officiel. Le jour 1 de la saison est un lundi dans le calendrier interne. Les dates de compétition sont enregistrées dans `calendar.competitionEvents`, et les rencontres portent leur `scheduledDay`, `scheduledWeekday` et leur autorité organisatrice. Le bouton « Avancer au prochain événement » déplace la carrière au prochain rendez-vous daté et simule automatiquement les rencontres des autres clubs ; le match du club dirigé reste à jouer et bloque l'avancement jusqu'à sa résolution.

L'AGD organise la **Coupe Intergalactique des galaxies** et l'**Intergalactique des Clubs**. La FGD fournit la borne officielle de fin de saison régulière ; l'AGD fournit séparément les dates de ses deux compétitions, qui doivent être postérieures à cette borne et séparées d'au moins un jour complet. Les dates lunaires et fédérales restent à fournir par les calendriers de référence. À la date du socle 1.3, la Champions League et la Coupe Lunaire restaient à auditer. La Champions League a depuis été auditée et intégrée au socle 1.5. La Coupe Lunaire a été confirmée par l’utilisateur comme compétition AGD et intégrée au socle 1.6 selon les règles et le planificateur tardif du V116. Le démarrage de la saison est protégé : il reste bloqué tant que les huit moteurs de compétition ne sont pas prêts, que les sept jeudis lunaires officiels, la date de fin FGD et les deux dates AGD ne sont pas chargés.

**Contrôle du socle 1.3 :** 90 tests automatisés réussis, vérification syntaxique des modules JavaScript et contrôle du registre/calendrier. Le test navigateur reste à effectuer. La saison reste volontairement verrouillée tant que les moteurs encore manquants et les calendriers officiels ne sont pas intégrés ; aucun calendrier incomplet ne doit être joué.

## Socle 1.4 — administration des calendriers
Le panneau « Administration des calendriers officiels » permet de saisir les sept jeudis lunaires de la Coupe des Clubs, la fin de saison régulière FGD et les deux dates AGD. Les entrées sont validées sur une copie avant d'être enregistrées, afin qu'une erreur ne corrompe pas la carrière. Les dates officielles ne sont jamais inventées. Voir `STAGE_1_4_ADMIN_CALENDRIERS.md`.


## Socle 1.6 — Coupe Lunaire AGD
Portage du moteur V116 : huit représentants galactiques, élimination directe en quarts, demi-finales et finale (7 matchs), en mois lunaire 12 sur trois créneaux espacés de sept jours (offsets internes 342, 349 et 356). Matchs intégrés au calendrier central, jouables pour la galaxie choisie ou simulés par l'IA. Voir `STAGE_1_6_COUPe_LUNAIRE.md`.


## Socle 1.7 — Coupe Intergalactique des galaxies (AGD)

Le moteur AGD à 24 sélections est porté depuis la génération la plus récente de V116. Il comprend 6 groupes de 4 et 36 matchs de groupes. La règle confirmée est : les deux premiers de chaque groupe et les quatre meilleurs troisièmes, soit 16 qualifiés. Ils disputent les huitièmes, quarts, demi-finales et finale, soit 51 matchs au total. L'édition est triennale. Le match de la sélection choisie par l'utilisateur peut être joué manuellement ; les autres sont simulés par le moteur commun. Les sept étapes sont espacées de deux jours dans la fenêtre officielle AGD. Voir `STAGE_1_7_COUPE_INTERGALACTIQUE_AGD.md`.


## Socle 1.8 — Intergalactique des Clubs (AGD)

Le format V116 est porté : 32 clubs réels, 4 chapeaux, 8 groupes de 4, 48 matchs de groupes, 16 qualifiés, huitièmes, quarts, demi-finales et finale, soit 63 rencontres. L'édition est quadriennale. Le moteur vérifie les licences et suspensions et bloque l'édition si moins de 32 clubs réels sont éligibles ; aucun club fictif n'est généré. Les matchs sont inscrits au calendrier AGD central, avec le programme historique de jours 8, 12, 16, 20, 24, 27 et 30 du mois réservé. Voir `STAGE_1_8_INTERGALACTIQUE_CLUBS_AGD.md`.


## Socle 2.0 — Dame d’Or

Le moteur individuel de la Dame d’Or est intégré : statistiques de résultats homologués, sélection du titulaire pour les rencontres du club dirigé, classement mixte, sauvegarde et palmarès de saison. Les critères détaillés et l’autorité organisatrice restent explicitement à confirmer. Voir `STAGE_2_0_DAME_OR_MOTEUR_INDIVIDUEL.md`.


### Socle 2.1 — statistiques techniques de la Dame d’Or

Le moteur enregistre désormais les coups joués, prises, promotions et déplacements de dames depuis les parties réelles ou simulées, sur les rencontres de clubs homologuées. Ces indicateurs complètent le classement individuel et sont utilisés uniquement après les critères sportifs principaux.


### Socle 2.2 — gouvernance, relations et négociations
La Dame d’Or est officiellement attribuée à la FGD avec la collaboration de l’AGD. Les règles fonctionnelles de messagerie/presse (damistes, supporters, direction, médias), de négociation des contrats des damistes et d’offres commerciales entrantes (sponsors, partenaires et autres structures qui approchent les clubs) sont consignées dans `STAGE_2_2_GOUVERNANCE_RELATIONS_NEGOCIATIONS.md`. À cette étape, seule l’autorité de la Dame d’Or est modifiée dans le moteur ; les systèmes complets de relations et de négociation restent à construire.

### Socle 2.3 — validation saison complète de la Dame d’Or
Ajout d'un test de bout en bout couvrant les 396 rencontres de championnat des trois divisions actives de départ. Le classement individuel est contrôlé après chaque match, avec vérification des titulaires, des statistiques techniques, de l'absence de doublons et de l'idempotence. La cérémonie officielle FGD et l'archive du vainqueur sont vérifiées en fin de saison. Les sept autres compétitions doivent rester strictement inchangées. Résultat : 134 tests automatisés réussis ; syntaxe JavaScript vérifiée. Le navigateur reste à tester.

### Socle 2.4 — messagerie, presse et offres commerciales entrantes
Ajout d'une boîte de réception persistante pour les damistes, supporters, direction et presse, avec effets sur le moral, la confiance et la réputation. Les résultats du club dirigé peuvent déclencher des réactions contextualisées. Le moteur de propositions commerciales entrantes permet acceptation, refus, contre-proposition et signature gagnant-gagnant ; aucune prospection sortante ni signature automatique. Les contrats des damistes et la génération automatique des offres entrantes restent à finaliser sans inventer de barèmes. Voir `STAGE_2_4_RELATIONS_PRESSE_OFFRES_ENTRANTES.md`.

## Socle 2.5 — contrats et offres entrantes automatiques

Le module `player-contracts.js` gère les propositions contractuelles individuelles, les contre-propositions des damistes, l'accord explicite du manager, la signature et l'engagement de masse salariale. Le module `relations.js` déclenche des offres commerciales entrantes du catalogue aux jalons des 3e, 6e et 9e matchs de championnat du club dirigé. Les coefficients financiers commerciaux et les demandes salariales sont des paramètres de simulation provisoires, non des données historiques. Voir `STAGE_2_5_CONTRATS_DAMISTES_OFFRES_AUTOMATIQUES.md`.


## Socle 2.6 — Identité visuelle

Le Socle 2.6 ajoute un éditeur d’identités de club et de galaxie : 25 motifs de maillot, 25 d’emblème et 25 de drapeau, palettes de couleurs, aperçu et sauvegarde. Chaque club et chaque galaxie possède une combinaison initiale distincte. Le validateur interdit les identités identiques. Le damier reçoit un premier relief CSS ; un véritable moteur 3D photoréaliste reste un chantier graphique séparé. Voir `STAGE_2_6_IDENTITE_VISUELLE_ET_PRESENTATION_3D.md`.

## Socle 2.7 — contrats, transferts et immersion

Le Socle 2.7 ajoute des clauses contractuelles détaillées (clause libératoire, primes, revalorisation, non-transfert), un marché d'échanges de damistes avec indemnité, le suivi des décisions du manager et une vue immersive en perspective CSS du damier. Le marché préserve deux damistes par club. Les huit moteurs de compétition sont inchangés. Voir `STAGE_2_7_CONTRATS_TRANSFERTS_IMMERSION.md`.

## Socle 2.8 — scène 3D WebGL
Le mode immersif dispose désormais d'un vrai rendu WebGL local : plateau en perspective, géométrie volumique des pions et dames, éclairage et synchronisation avec la partie. Les interactions et les règles continuent d'être pilotées par le moteur de dames existant. Voir `STAGE_2_8_MOTEUR_3D_WEBGL.md` pour les limites et les prochaines étapes vers les modèles animés et les stades détaillés.


### Socle 2.9 — Arènes 3D et animations de match
Le moteur WebGL inclut désormais une enceinte avec tribunes, public géométrique stylisé et pylônes d’éclairage. La caméra peut être tournée par glissement et rapprochée par zoom ; les coups sont interpolés segment par segment, y compris les prises multiples. Les cases interactives continuent de transmettre les actions au moteur réglementaire des dames. Voir `STAGE_2_9_ARENE_3D_ANIMATIONS_CAMERA.md`. Le rendu reste une scène 3D stylisée : personnages humains détaillés, foule animée et photoréalisme ne sont pas encore disponibles.


### Socle 3.0 — Figurines humanoïdes 3D des damistes
Le moteur WebGL remplace les jetons cylindriques par des figurines humanoïdes stylisées : tunique, tête, bras, jambes et couronne spécifique aux dames. Les déplacements sont animés avec impulsion et inclinaison, segment par segment pour les prises multiples. Le modèle arrivé est utilisé après le coup, y compris lorsqu’un pion est promu en dame. Les règles du jeu et les huit moteurs de compétition restent inchangés. Il s’agit d’une géométrie 3D stylisée, pas encore de personnages photoréalistes ni d’animations squelettiques. Voir `STAGE_3_0_MODELES_DAMISTES_3D.md`.

### Socle 3.1 — attitudes 3D
Les figurines disposent maintenant de postures de présentation, de réflexion, de préparation à la prise, de célébration et de déception. Les animations sont déclenchées par le déroulement de la rencontre sans modifier le moteur de règles.
Voir `STAGE_3_1_ATTITUDES_EMOTIONS_DAMISTES_3D.md`.

## Socle 3.4 — Fondation de carrière et navigation mobile
- Profil manager persistant : identité, galaxie, mode, club de départ et réputation.
- Modes Club, Club & International et Sans emploi (démarrage sans club ; candidatures à venir).
- Rail de huit rubriques et affichage d'un écran à la fois, avec adaptation portrait/paysage.
- Réglage du niveau IA, sauvegarde manuelle et badge des messages non lus.
- Voir `STAGE_3_4_CARRIERE_PROFIL_NAVIGATION.md` pour le périmètre livré et les étapes restantes.

- Spécification directrice complète : `SPEC_CARRIERE_MANAGER_CGD_V117.md`.

## Socle 3.5 — quotidien du manager
- Progression jour par jour via le bouton CONTINUER, avec traitement des événements du calendrier central.
- Le bouton conserve les priorités : réponse obligatoire, match du club, puis progression quotidienne.
- Première console d'administration du club : finances paramétrables, installations, staff, délégations, objectifs et demandes au conseil.
- Les recettes et charges quotidiennes sont à zéro par défaut ; le manager les paramètre explicitement.

## Étape 3.6 — gouvernance, recrutement et staff
- Le conseil traite automatiquement les demandes à l'avancement journalier et archive ses décisions ; une démission approuvée libère le manager.
- Marché de l'emploi pour managers sans club : offres accessibles selon la réputation, candidatures, réponse simulée des clubs, proposition de poste et nomination après acceptation.
- Une proposition d'emploi devient un événement prioritaire qui bloque CONTINUER jusqu'à la décision du manager.
- Profils des cinq fonctions du staff personnalisables (nom, profil et compétence).
- 213 tests automatisés réussis ; les moteurs des compétitions, du calendrier, des dames et de la scène 3D restent inchangés.


## Socle 5.12 — Registre galactique

Voir `STAGE_5_12_REGISTRE_GALACTIQUE_MANAGERS.md` pour le registre des 60 clubs, 120 damistes, 60 managers de clubs et 24 sélectionneurs. Les sources originales sont archivées dans `data/galactique_data/`.
