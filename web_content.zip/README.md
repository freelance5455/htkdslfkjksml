# Kz Tarefa

Projeto inicial completo da aplicação web.

## O que já funciona
- Cadastro local
- Login automático no dispositivo
- Tarefas e recompensas de teste
- Saldo em Kz
- Histórico
- Pedido de levantamento
- Perfil
- PWA/instalação pelo navegador

## Importante para dinheiro real
O código não pode fabricar dinheiro. Para pagamentos reais é necessário:
1. uma fonte real de receita (anúncios, vendas, afiliados etc.);
2. backend/servidor;
3. base de dados;
4. autenticação segura;
5. provedor de pagamentos disponível no país;
6. regras antifraude;
7. configuração de AdMob para Android ou AdSense para um site elegível.

Os valores das tarefas neste pacote são apenas valores de teste. Não devem ser apresentados aos utilizadores como dinheiro já disponível para saque.

## Publicar
A pasta `www` pode ser publicada num serviço de hospedagem estática. Depois de obter o domínio/URL real, configure-o no serviço de anúncios.

## Android
Esta pasta pode ser empacotada como aplicativo Android usando Capacitor, depois de instalar Node.js e as ferramentas Android. O pacote não inclui uma assinatura APK nem credenciais privadas.
