# LU Maths Hub — mobile app

This is an installable Progressive Web App (PWA) that recreates the mobile class-hub workflow from `rvs.mnopdf.com`:

- Searchable academics and campus-life sections
- Study, timetable, exams, groups, photos, participation and playground links loaded from the existing Supabase project
- Roll-number/PIN profile login using the existing `login_student` RPC
- WhatsApp, student directory, teacher directory, music and holidays actions
- Light/dark mode, home-screen installation and offline app-shell caching

## Use it on a phone

Upload every file in this folder to the same HTTPS host as the class hub (or a separate HTTPS subdomain). Then open the deployed URL on a phone:

- **Android / Chrome:** use the **Install app** button, or Chrome’s **Install app / Add to Home screen** menu item.
- **iPhone / Safari:** tap **Share → Add to Home Screen**.

The live lists need an internet connection. The app shell stays available after the first successful load.

## Local preview

Run any static web server in this folder, then open its local URL. For example, if Node.js is installed:

```powershell
npx serve .
```

Use HTTPS for deployment; service-worker installation is intentionally unavailable when opened directly as a `file://` URL.

## Important backend note

The project uses the same public browser credentials that the existing website uses. The application never stores the 4-digit PIN; it only stores the returned student name and roll number locally after a successful login. Keep Supabase Row Level Security enabled, and never replace the public key in `app.js` with a service-role key.
