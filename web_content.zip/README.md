# FieldScan Android Native & Web APK Bundle
متوافق بنسبة 100% مع أداة Mevada Labs Android Builder (ZIP to APK):
https://mevadalabs.com/android-builder-tool/

## طريقة التحويل إلى APK على Mevada Labs:
1. ارفع هذا الملف المضغوط (.zip) مباشرة إلى Mevada Labs.
2. يتعرف الموقع تلقائياً على `index.html` و `manifest.json` و `icon.png` ومصادر Android.
3. اختر APK (Direct Install) ثم اضغط Build Application.
4. حمل ملف الـ APK النهائي وثبته على هاتفك!
