# VoxForge AI — self-hosted voice studio

A deployable starter for a cloud-hosted multilingual speech app. It includes a FastAPI API, browser UI, Docker setup, consent-gated voice-reference uploads, and a model-adapter boundary.

## Important reality check
This repository is an **implementation starter**, not a pretrained model. The default engine uses a clearly labelled demo fallback so the app boots without a GPU. To generate neural audio, configure a compatible model adapter in `backend/app/engine.py` and install the model's dependencies and weights. Do not advertise the demo fallback as realistic neural speech.

## Features
- Text-to-speech API and browser UI
- 50 distinct *voice presets* (descriptors and settings; real vocal identity depends on the model)
- Language/voice settings, rate and pitch controls
- Voice-reference upload with explicit permission confirmation
- Custom voice records, health endpoint, Docker deployment
- Audio output as WAV when a neural engine is configured

## Quick start (demo mode)
Requirements: Docker Desktop or Python 3.11+.

```bash
cp .env.example .env
docker compose up --build
```
Open http://localhost:8000

Or run locally:
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r backend/requirements.txt
uvicorn app.main:app --app-dir backend --host 0.0.0.0 --port 8000 --reload
```

The demo engine returns a helpful `501` for synthesis until a real model adapter is enabled. This is deliberate: a fake audio file would be misleading.

## Production architecture
- API: FastAPI
- Model worker: separate GPU worker/container for inference
- Storage: S3-compatible private bucket for uploaded references and generated audio
- Database: PostgreSQL for users, voice metadata, consent receipts and job status
- Queue: Redis + worker for long synthesis jobs
- Auth/rate limits: add before public deployment
- Model license: review each model's weights/code license and commercial-use conditions.

## Voice cloning safety
Only upload audio you own or have explicit permission to use. The API requires an affirmative consent flag, limits upload size, accepts audio formats only, and stores uploads in a private local directory. For public deployment, add authentication, retention/deletion workflows, malware scanning, signed upload URLs, and auditable consent records. Do not clone a person's voice to impersonate them or mislead listeners.

## Configure a real model
Edit `backend/app/engine.py` and implement `synthesize()` with a supported multilingual TTS/cloning model. The adapter contract is:
```python
synthesize(text: str, language: str, preset: dict, reference_path: str | None) -> bytes
```
Return valid WAV bytes. Keep model loading in a dedicated GPU worker rather than loading huge weights per request. See `docs/MODEL_ADAPTER.md`.

## API
- `GET /api/health`
- `GET /api/voices`
- `POST /api/synthesize` JSON: `{ "text": "...", "language": "en", "voice_id": "warm_narrator", "rate": 1.0, "pitch": 1.0 }`
- `POST /api/voices/clone` multipart: `name`, `audio`, `consent=true`
- `GET /api/voices/custom`

## Production checklist
- Add authentication and per-user ownership.
- Use HTTPS and private object storage.
- Put GPU inference behind a queue and set request timeouts.
- Add quota/rate limits, observability, backups, and deletion controls.
- Test language/accent quality with native speakers before claiming support.

## Neural engine adapter
An optional Qwen3-TTS adapter is included. Install `backend/requirements-gpu.txt`, configure CUDA/PyTorch and set `VOXFORGE_ENGINE=qwen3`; full steps and language limits are in `docs/MODEL_ADAPTER.md`. The default remains disabled so the app will not pretend to generate neural audio before a model is installed.
