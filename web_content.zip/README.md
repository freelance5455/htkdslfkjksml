# Four Ball Scorecard (Android)

A WebView app that wraps the scorecard page in `app/src/main/assets/index.html`.

## Get the APK (no Android Studio needed)

1. Create a free account at github.com and make a new repository (private is fine).
2. Upload everything in this folder to it, including the hidden `.github` folder.
   Easiest: on the new repository page choose "uploading an existing file", drag the
   unzipped contents in, and commit.
3. Open the repository's Actions tab. The "Build APK" run starts on its own.
   If it doesn't, choose "Build APK" on the left and press "Run workflow".
4. When the run turns green (about 5 minutes), open it and download
   "four-ball-scorecard-apk" from the Artifacts list at the bottom. Unzip it to get app-debug.apk.
5. Copy app-debug.apk to your phone, tap it, and allow "Install unknown apps" for
   your file manager or browser when Android asks.

Rounds are saved on the phone. Reinstalling or clearing the app's storage erases them.
