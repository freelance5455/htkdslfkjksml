# RedBeat — Offline Local Music Player

A pitch-black offline music player web application with a `#FF2D55` crimson red accent system, local IndexedDB storage, dual-deck Web Audio engine, and AI features.

## Included Files
- `index.html` — Complete standalone offline music player application (HTML, CSS, and JavaScript).
- `README.md` — Setup and feature overview.

## How to Run
1. Extract this ZIP archive.
2. Open `index.html` in any modern mobile or desktop browser (Chrome, Safari, Edge, Firefox).
3. Tap **Import** to add local audio files (`.mp3`, `.flac`, `.wav`, `.m4a`, `.ogg`, `.aac`) or convert device gallery videos into playable offline audio tracks.
