# MHC Cashbook Android Project

This project wraps the latest MHC Cashbook HTML app in an Android WebView.

## Build APK
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build App Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK on Android.

The HTML app is bundled at `app/src/main/assets/index.html` and runs offline. JavaScript and localStorage are enabled. File/image selection is supported for the app's photo/logo inputs.
