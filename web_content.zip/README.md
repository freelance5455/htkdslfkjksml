# Phoenix Project Manager (Android)

Comprehensive Fire Safety Project Management, Client Assurance Portal, Field Task Allocation, and Statutory Document Management application for **Phoenix Fire Safety Equipments Pvt. Ltd.**, Chennai, Tamil Nadu, India.

Built with modern **Android Jetpack Compose**, Material Design 3, Kotlin Coroutines & Flow, and Clean Architecture.

---

## 🏛️ Company & Regulatory Context
- **Organization**: Phoenix Fire Safety Equipments Pvt. Ltd.
- **Headquarters**: Chennai, Tamil Nadu, India
- **Statutory Standards**: IS 3844 Code of Practice for Fire Safety in Buildings, NBC 2016 Part 4 (Fire & Life Safety)
- **State Authority**: Tamil Nadu Fire and Rescue Services (TNFRS) Form B Compliance

---

## 🚀 Key Features Ported

1. **Executive Operations Command (Dashboard)**:
   - High-level KPIs: Active projects, pending field tasks, contract pipeline value in Lakhs/Crores, client accounts, statutory compliance indicators.
   - Critical overdue audit alerts with real-time urgency banners.
   - Quick action shortcuts: New Project, Allocate Task, Zoho Books CRM Sync.

2. **Fire Protection Systems Management (Projects)**:
   - Complete project catalog covering:
     - *Fire Alarm Systems* (addressable optical/heat multisensors, repeater panels)
     - *Hydrant & Sprinkler Networks* (150mm MS ring mains, deluge valves, pendant heads)
     - *CO2 & Clean Agent Gas* (Novec 1230 server room flooding, VESDA aspirating lasers)
     - *Extinguisher & AMC* (portable extinguisher hydrostatic audits)
     - *TNFRS NOC Compliance* (statutory Form B renewal documentation)
   - Real-time progress computation dynamically derived from completed milestone checklists.

3. **Detailed Project Command Center**:
   - Tabbed view:
     - **Milestones**: Interactive inspection checklist that updates progress automatically.
     - **Tasks**: Work item cards with assignee PFS codes, deadlines, and completion checkboxes.
     - **Field Inspection Feed**: Real-time progress reports with percentage logs, notes, and attachment records.
     - **Engineering Documents**: As-built CAD blueprints (.dwg), hydraulic calculations, Form B NOC dossiers, and completion certificates with preview.
     - **Multi-Role Messaging**: Integrated text communication and synthesized voice note playback with animated waveforms.

4. **Field Task Allocation & Tracking**:
   - Filterable work item registry with priority badges (Critical, High, Medium, Low) and task status tags (Pending, To Do, In Progress, Completed, Overdue).
   - Instant completion toggle.

5. **Client Assurance Portal**:
   - Role-based portal for client executives (e.g. Apollo Hospitals, Hyundai Motor, Olympia Tech Park).
   - Restricted client-safe visibility for milestone roadmaps, approved drawings, and direct voice/text channel with site supervisors.

6. **Field Engineer & Supervisor Workspace**:
   - Personalized task board for engineers (e.g., PFS-0001 Senthil Nathan, PFS-0002 Priya Balan, PFS-0003 Murugan K.).
   - Instant progress logger with completion slider, notes, and photo log submission.

7. **Staff & Engineering Directory**:
   - Complete statutory profile management: PFS employee code, department, Aadhaar & PAN verification, blood group, emergency contacts, and assigned site installations.

8. **Zoho Books CRM Integration**:
   - Connected organization webhook configuration for real-time contact and purchase order synchronization.
   - Interactive Zoho contacts import dialog.

9. **Multi-Persona Switcher**:
   - Instant role switching between Managing Director (Admin), Project Engineers (Employees), and Facilities Directors (Clients) to audit role-gated workflows.

---

## 🏗️ Architecture & Technology Stack
- **Language**: Kotlin 2.0+
- **UI Framework**: Jetpack Compose (Material Design 3)
- **Design System**: M3 dark color palette themed around Phoenix Flame Red (`#DC2626`), Slate (`#0F172A`, `#1E293B`), and Safety Emerald (`#10B981`)
- **State Management**: Android `ViewModel`, Kotlin `MutableStateFlow` and `StateFlow`
- **Application ID**: `com.aistudio.phoenixpm.kznr`
- **Adaptive Icon**: Custom launcher icon featuring Phoenix company emblem with adaptive round masking per Android guidelines.
