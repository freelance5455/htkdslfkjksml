# JARVIS 2.0 Android starter

## Open/build
1. Extract this ZIP.
2. In AndroidIDE choose **Open project** and select this folder.
3. Allow AndroidIDE to install its build tools and wait for Gradle sync.
4. Run the app's debug assemble/build task. The debug APK, if the build succeeds, is normally under `app/build/outputs/apk/debug/`.

## Included in this starter
- WebView-based dark JARVIS interface
- Tap-to-speak Android speech recognition and Android TextToSpeech
- Basic local commands: time, battery, launch a few installed apps
- Optional device-admin permission for user-requested screen lock
- Basic Android InCallService hooks and default-dialer role request

## Important limitations
- This is source code, not a prebuilt APK. It has not been compiled or tested on your device.
- AndroidIDE versions and SDK availability can require Gradle or manifest adjustments.
- Call handling is a basic starter integration, not a fully tested replacement dialer. Android may require additional dialer UI/behavior and permissions.
- Screen lock works only after you explicitly activate the device-admin permission in Android settings.
- Voice recognition starts only when you tap SPEAK; there is no always-on wake word.
- Online AI conversations and a secure AI backend are not included. Do not put private API keys in the APK.
- TextToSpeech voice gender/accent depends on voices installed on the phone.
