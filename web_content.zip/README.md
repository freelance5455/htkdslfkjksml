# Slab (Android app project)

The game is in `www/index.html`. This project wraps it with Capacitor so it can be built into an APK.

## Option A: build online with GitHub (no PC tools needed)

1. Create a free GitHub account and a new empty repository.
2. Upload everything in this folder, including the hidden `.github` folder.
3. Open the repository's **Actions** tab, choose **Build APK**, and press **Run workflow**.
4. When it finishes (about 5 minutes), open the run and download the `slab-apk` file under **Artifacts**.
5. Unzip it and copy `app-debug.apk` to your phone. Open it and allow "Install unknown apps" when asked.

## Option B: build on your computer

Requires Node.js 20+, Java 17 and Android Studio (for the Android SDK).

```
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

The APK is at `android/app/build/outputs/apk/debug/app-debug.apk`.

## Notes

- Fonts load from Google Fonts when online and fall back to system fonts offline.
- The debug APK is fine for personal use. Publishing on Google Play needs a signed release build.
- To change the app name or id, edit `capacitor.config.json` before running `npx cap add android`.
