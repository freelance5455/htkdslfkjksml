# Assignment Reminder Android Project

This project packages the supplied Assignment Reminder HTML dashboard into an Android WebView app
and adds native Android exact-alarm scheduling.

## Included
- `app/src/main/assets/index.html` — supplied dashboard, patched to call native alarms.
- `app/src/main/res/raw/reminder.mp3` — supplied alarm sound.
- Native Kotlin `AlarmScheduler`, `AlarmReceiver`, and `BootReceiver`.
- Exact alarm permission and notification permission handling.
- Re-scheduling after device reboot/app update.

## Build
Open this folder in Android Studio (Hedgehog or newer), let Gradle sync, then:
Build -> Generate App Bundles or APKs -> Generate APKs.

Install the generated APK on the Android phone.

## Important Android behavior
Android 12+ requires the user to allow exact alarms. Android 13+ requires notification permission.
The app requests these permissions. Battery-management restrictions can still vary by manufacturer;
for maximum reliability, allow notifications and exact alarms and do not restrict the app's battery use.

## Note about reboot persistence
The HTML dashboard remains in localStorage. The native boot receiver can restore alarms from
SharedPreferences, but the current WebView bridge does not yet mirror every localStorage change into
that preference store. For guaranteed reboot restoration, the next iteration should persist the
native alarm list directly whenever a reminder is added/edited/deleted.

## Alarm sound fix (v2)
The updated project uses a new notification channel ID (`assignment_alarm_v2`) so Android does not reuse the previous channel's saved sound configuration. The alarm receiver starts a foreground media-playback service, which plays `res/raw/reminder.mp3` as an alarm and keeps it playing until stopped (or until the service is stopped by the app/system).

After installing this updated APK, allow Notifications and Exact alarms when Android asks. If the phone has an app-specific battery setting, set Assignment Reminder to Unrestricted/No restrictions.

Important: Android notification-channel settings are controlled by the phone. If you later change the alarm sound in code, use a new channel ID or uninstall/reinstall the app so Android does not retain the old channel configuration.
