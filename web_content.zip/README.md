# Cubelyra Minecraft Launcher — Bridge ZIP

## What is included
A responsive purple Cubelyra HTML interface, profile/setup/diagnostics panels, PWA metadata, and an attempt to hand off to an already-installed Android Java launcher.

## Critical limitation
**This ZIP does not contain a self-contained Minecraft Java engine.** A small HTML ZIP cannot provide the Android JVM, native graphics libraries, game version manager, authorized game downloads, and authentication simply by adding a Play button. This package does not bundle Minecraft files or claim actual gameplay is embedded/tested.

The Launch button tries Android intent handoffs to several common launcher package IDs. IDs can differ by build, and some HTML-to-APK converters block intents. If nothing opens, use the compatible native launcher directly.

## Try it
1. Extract this ZIP and open `index.html` to test the UI.
2. If using an HTML-to-APK converter, choose one that supports local HTML/CSS/JS and Android intent links.
3. For actual Minecraft Java gameplay, install a compatible native Android Java launcher from its official project/release source, sign in through its official Microsoft flow, and install a version you are licensed to play.
4. Test gameplay in that native launcher. This Cubelyra wrapper does not yet embed the engine.

## Official open-source reference
Amethyst Android source: https://github.com/AngelAuraMC/Amethyst-Android
The project describes a Java Edition launcher for Android/iOS and is licensed under LGPLv3. Its native runtime and graphics code are substantial; reuse requires following its license and all third-party licenses. This ZIP does not copy or redistribute that engine.

## Security and licensing
- Independent project; not an official Mojang/Microsoft product.
- No Minecraft game files are bundled.
- Never put Microsoft passwords, private tokens, or client secrets into this ZIP.
- Microsoft authentication is not implemented in this HTML package; use a compatible native launcher's official authentication flow.
