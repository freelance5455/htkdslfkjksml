# EMPIRES — WORLD AT WAR  (Phase 9: World Map and Navy)

Offline HTML5/Canvas grand strategy game. No servers, no external assets, no libraries.

## Run it
- **Desktop:** open `index.html` in Chrome/Edge/Firefox (double-click works).
- **Android phone (quick test):** unzip, then open `index.html` with a file manager that opens in Chrome, or
  host the folder with any static file app. Landscape is recommended. Saves use the browser's localStorage.

## Convert to APK (HTML-to-APK)
Any of these work because the project is plain static files with relative paths:
1. **Online HTML-to-APK tools** (e.g. WebIntoApp-style / "HTML to APK" converters): zip the *contents* of this
   folder so that `index.html` sits at the zip root, upload, choose landscape orientation, build.
2. **Capacitor:** `npm i @capacitor/cli @capacitor/core @capacitor/android`, `npx cap init`, set `webDir` to this folder,
   `npx cap add android`, `npx cap sync`, open in Android Studio, Build > Build APK.
3. **Cordova:** copy this folder's contents into `www/`, `cordova platform add android`, `cordova build android`.
Make sure DOM storage / localStorage is enabled (default in all of the above) so saving works.

## Controls
| Action | Touch | Mouse |
|---|---|---|
| Pan | drag one finger | drag |
| Zoom | pinch | wheel, or + / − buttons |
| Select province | tap | click |
| Deselect | tap sea / ✕ | click sea / ✕ |
| Select army | tap its flag banner | click it |
| Move army | ➜ Move, then tap a province you own | same |
| Recruit | ⚔ button, or ＋ Recruit here | same |
| Declare war / ceasefire | Country tab of that nation | same |
| Build fort | province panel (own province) | same |
| Industry | 🏭 button, or 🏗 Build… in a province | same |
| Select fleet | tap its banner (⚓ button lists fleets) | click it |
| Sail fleet | ➜ Sail, then tap a sea zone or own port | same |
| Select sea zone | tap the sea (nothing selected) | click |
| Amphibious landing | army panel ⛴ Sail (docked transports needed), or load, sail, Land at | same |
| Map modes | 🗺 cycles Political / Terrain / Diplomacy / Naval / Economy | same |
| Pause / play | ▶ button | ▶ button or Space |

## Project layout
```
index.html          page shell
css/style.css       UI styling (responsive, portrait + landscape)
js/countries.js     scenario data: nations, layout grid, province names, terrain table
js/landdata.js      simplified real coastlines (Natural Earth 1:50m, public domain)
js/flags.js         c. 1936 national flags for the Old World scenario (drawn with canvas shapes)
js/worlddata.js     Old World 1936 scenario data (44 nations, seeds, cities, straits)
js/world.js         builds provinces (grid or polygon world), adjacency, sea zones, ports, straits
js/naval.js         ships, fleets, shipbuilding, naval combat, blockades, amphibious landings
js/naval-ai.js      AI shipbuilding, fleet control, blockades, invasions
js/naval-ui.js      Navy screen, fleet panel, sea-zone panel, port block
js/simulation.js    game state, calendar, daily/monthly economy tick, time controls
js/military.js      units, equipment, recruit queues, armies, generals, movement
js/army-ui.js       army panel, Army Command (Recruit / Queue / Armies / Generals)
js/war.js           war declarations, ceasefire, elimination, basic enemy responses
js/combat.js        battles, casualties, retreat, occupation, capital capture, forts, reinforcements
js/war-ui.js        war/ceasefire buttons, fort/occupation info, battle notifications
js/economy.js       factories, production lines, resources, budget, construction, tax, trade, shortages
js/economy-ui.js    Industry panel (Overview / Production / Construction / Trade)
js/save.js          save/load (localStorage: autosave + 3 slots)
js/map.js           canvas renderer, zoom/pan/pinch, hit-testing, flags, labels
js/ui.js            start screen, top bar, province/country panel, menu
js/main.js          boot, game loop, monthly autosave
```

## Phase 9 — scenarios and navy
Start screen offers two scenarios: **Empires** (7 fictional nations, 61 provinces) and **Old World 1936**
(44 nations on the real world map, Miller projection; 377 provinces, 64 sea zones).
Coastlines are real (simplified); country borders are approximate; flags are generated designs, not real flags.
Navy: Destroyer, Submarine, Cruiser, Battleship, Transport. Build at a province with Port + Shipyard (⚓ in Industry).
Fleets sail between sea zones and ports; enemy fleets in the same zone fight each day. Warships next to an enemy port
blockade it (tax and trade fall). Straits (Gibraltar, Suez, Turkish, Danish, Panama, Otranto, Hormuz, Aland) are closed to
fleets of nations at war with the controller. Transports carry armies (3 units each); landing on an enemy coast is an
amphibious assault (weaker for 8 days). New naval tech branch (6 techs). Old saves still load.

## Testing on an Android phone
Open `index.html` in Chrome (landscape). Start → choose *Old World 1936* → pick e.g. United Kingdom → ⚓ → Build → order ships;
tap a fleet banner → ➜ Sail → tap a sea; declare war on a neighbour, park warships by its port (🗺 until Naval mode shows blockade markers),
or load an army into transports and Land at an enemy coast.
