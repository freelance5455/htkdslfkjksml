# Chethix Live Wallpaper

This is a native Android project with your WebView/HTML Studio UI plus a real Android WallpaperService.

How it works:
1. Select a video in the app.
2. The Android side copies it to app storage.
3. Tap Set Live Wallpaper.
4. Android opens the real live-wallpaper preview/chooser.
5. Confirm/apply it from Android's wallpaper UI.

Important:
- Android decides whether the wallpaper is applied to Home, Lock, or both on the device/launcher.
- The HTML preview is only a preview. The actual wallpaper is rendered by WallpaperService.
- The video is muted.
- Very large videos may use significant storage/memory.
