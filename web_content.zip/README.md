
# Marine Air Compressors v2 - Android App
Features: Search, Bookmarks, Night Mode, Chapter Quizzes, Applications/Uses

Build:
1. Open Android Studio -> Open folder MarineAirCompressorAppFinal
2. Gradle sync -> Run on phone
3. Or Build -> Build APK -> app/build/outputs/apk/debug/app-debug.apk

All content offline: 12 chapters, 60+ quiz questions, comparison tables, application map, troubleshooting.

Quiz scores, bookmarks, theme saved via localStorage (WebView domStorage enabled).
