# Moiz AI — Chat-style mobile web app

**Primary author:** Muhammad Moiz  
**Project evolution/collaboration context:** Bar Hussain acknowledged where applicable; no individual code contributions are inferred.

## Import
This ZIP has `index.html` at its root. Import it into a ZIP-to-site app that requires a root `index.html`.

## Features in this build
- ChatGPT-inspired responsive chat layout with sidebar and mobile menu.
- Manual Cloud AI / Offline AI mode selection. It does not automatically switch modes.
- Gemini API key and model saved in browser/app local storage; enter once per browser/app installation.
- Chat history is saved locally, including conversations created in Offline mode.
- Saved Chats page and JSON chat-backup export.
- Separate Maps page with demo city records and device geolocation request.
- Service worker caches the app shell for reopening offline (on supported HTTPS origins).

## Important limitations
- Offline mode is currently an explicit placeholder, not a real language model. To get useful answers with no internet, integrate a real on-device model/runtime and download its model files.
- Maps page does not download actual map tiles, provide offline geocoding, or routing. Integrate a licensed offline map provider and local spatial database.
- Gemini API key is saved in local browser storage for convenience. This is not secure against extraction from a client app. For a public app, route requests through a protected backend.
- Browser local storage persists across visits in the same app origin/profile, but clearing app data, changing origin, or reinstalling may remove it. Export chat backups regularly.
- Device geolocation requires permission and usually HTTPS; GPS hardware may provide location without internet.

## APK
The ZIP is a web app source package, not an APK. Import it into your ZIP-to-site builder and use its APK/build/export feature, or wrap it with Capacitor and build with Android Studio.
