# Nexora — WhatsApp-style Messaging App Prototype

Nexora is an original UI/UX prototype inspired by the general category of private messaging apps. It does NOT use WhatsApp branding, logo, source code, or proprietary assets.

## Direct use
1. ZIP extract करें.
2. `index.html` पर double-click करें.
3. Chrome/Edge में app तुरंत खुलेगा.
4. किसी server, database, API key या installation की जरूरत नहीं है for this prototype.

## Included
- Chats list + search
- 1-to-1 chat screen
- Message sending
- Read/check marks
- New chat
- Attachments menu UI: photo/video, document, location, contact
- Voice/video call UI actions
- Status/Updates
- Channels-style Updates
- Communities
- Calls history
- Disappearing-message setting UI
- Profile/settings/Privacy UI
- LocalStorage persistence
- Mobile-first responsive UI
- Original Nexora branding and icon

## Important
This ZIP is a functional FRONTEND PROTOTYPE. Messages are stored locally in the browser. It does not send messages to another phone over the internet and the call buttons are UI simulations.

For a production app, a backend is required for:
- Phone OTP/authentication
- Real-time messaging (WebSocket/Firebase)
- Push notifications
- Media/file storage
- Real voice/video calls (WebRTC + signaling)
- Real end-to-end encryption
- Contacts/sync
- Groups, admin controls, blocking/reporting
- Cloud backup and multi-device sessions
- Android/iOS builds and app-store signing

## Current WhatsApp feature research
The design scope was checked against WhatsApp's public product information: messaging, voice/video calls, groups, status, communities, files/media, reactions/stickers, disappearing messages and linked devices are part of the current feature set.
