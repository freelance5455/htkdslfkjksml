# MrJinwoo App

A standalone Minecraft-inspired gamer/community web app demo.

## Included
- Home dashboard
- Gamer profile
- Username/account management
- Gamer connection system
- Chat and message sending
- Call interface placeholder
- Ad-account demo section
- Settings
- Responsive mobile/desktop UI
- LocalStorage persistence

## Run
Open `index.html` in a browser.

## Production notes
The chat, accounts, ads, and calls are front-end demo features. For real multi-user authentication, messaging, ads, and voice/video calls, connect a backend such as Firebase/Supabase and a calling provider.
