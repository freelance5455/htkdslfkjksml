# LIVE MICE SHAKIL — Call Output Routing Patch

This build fixes several effect controls that were not wired to the audio graph:
- Echo Mix / Echo Delay Mix controls the echo wet signal.
- Feedback controls the echo feedback loop.
- Master ON/OFF bypasses boost and effect wet paths on existing processed graphs.
- Attempts to resume suspended Web Audio contexts.

## Install
1. Extract this ZIP.
2. Open `chrome://extensions` (desktop Chrome/Edge), enable Developer mode, and choose **Load unpacked**.
3. Select the extracted folder.
4. Test on a supported browser-based call page and allow microphone access.

## Important
This is a code-level patch, not a verified Messenger-call fix. It hooks standard WebRTC APIs on supported web pages; it cannot affect the native Android Messenger app. Whether Messenger's current web call path uses these hooks must be confirmed in a real call with the other caller. A status saying a track was attached does not prove the remote caller hears the effects.

Use moderate levels and headphones. Strong boost/effects can cause clipping or unclear speech.
