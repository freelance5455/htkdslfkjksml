# Miss Escola — Site de votação

Este projeto cria uma página responsiva em `/votacao/` com:
- candidatas e fotos;
- botão "Votar nesta candidata";
- confirmação do voto;
- contagem de votos;
- ranking Top 10;
- visual adaptado para telemóvel.

## 1. Testar sem banco de dados

Abra `votacao/index.html`. O site entra em "Modo demonstração".
Os votos ficam apenas no navegador.

## 2. Colocar votação online

A forma simples é usar Supabase como banco de dados.

1. Crie uma conta/projeto no Supabase.
2. Abra o SQL Editor.
3. Cole e execute `supabase.sql`.
4. Vá a Project Settings > API.
5. Copie a Project URL e a chave `anon/public`.
6. Abra `assets/config.js` e substitua:
   SUPABASE_URL
   SUPABASE_ANON_KEY
7. Teste novamente.

NUNCA coloque uma chave `service_role` no site.

## 3. Colocar o site na internet

Uma opção simples é Cloudflare Pages ou GitHub Pages.

A estrutura deve permanecer:
- `/votacao/index.html`
- `/assets/style.css`
- `/assets/app.js`
- `/assets/config.js`

Com Cloudflare Pages, o endereço poderá ser parecido com:
`https://nome-do-seu-site.pages.dev/votacao/`

Depois pode ligar um domínio próprio, ficando:
`https://seusite.co.mz/votacao/`

## 4. Fotos

Substitua:
- assets/candidate-01.jpg
- assets/candidate-02.jpg
- ...
pelas fotos reais.

Mantenha os nomes dos ficheiros ou altere os caminhos em `assets/app.js`.

## 5. Para uma votação oficial

O código atual reduz votos repetidos usando um identificador guardado no navegador. Não é um sistema antifraude forte.

Para uma eleição oficial, use códigos individuais de eleitor, autenticação, ou um mecanismo equivalente, e defina claramente:
- período de votação;
- quem pode votar;
- regra de um voto por eleitor;
- como serão tratados votos inválidos;
- quem terá acesso aos resultados.
