# TOMTOM CHESS ONLINE V11

این بسته برای Deploy عمومی با Node.js + WebSocket آماده است.

## Deploy روی Render

1. پروژه را در GitHub قرار دهید.
2. در Render یک **Web Service** بسازید و Repository را انتخاب کنید.
3. Build Command: `npm install`
4. Start Command: `npm start`
5. Health Check: `/health`
6. بعد از Deploy یک آدرس شبیه `https://YOUR-SERVICE.onrender.com` می‌گیرید.
7. همان آدرس را داخل بخش «آدرس سرور اینترنتی» بازی وارد و «ذخیره سرور» کنید.
8. «تست اتصال» باید پیام «سرور آنلاین است» بدهد.

Render برای Web Service از WebSocket ورودی پشتیبانی می‌کند و اتصال عمومی باید با `wss://` روی HTTPS انجام شود.

## تست واقعی دو گوشی

- گوشی اول: آدرس سرور را وارد → ساخت اتاق → کد را ارسال کن.
- گوشی دوم: همان آدرس سرور → ورود به اتاق → کد.
- برای تست واقعی، بهتر است دو دستگاه روی دو اینترنت متفاوت باشند.
- بعد از اتصال، حرکت و چت باید لحظه‌ای منتقل شوند.

## نکته ذخیره اطلاعات

این نسخه برای تست آنلاین مناسب است. فایل `tomtom-data.json` روی فایل‌سیستم محلی ذخیره می‌شود؛ برای سرویس دائمی با داده‌های پایدار، بعداً باید دیتابیس مثل PostgreSQL اضافه شود.


## V11 changes
- Mobile drag no longer rebuilds the board during pointer movement; this prevents the visual double/jump effect.
- Uses pointer capture and a fixed drag ghost for touch/mouse gestures.
- Reuses a single Web Audio `AudioContext` and provides separate synthesized cues for move, capture, check, castle, promotion, win, loss, draw, and clock tick.
- Online panel is branded as TOMTOM ARENA.
- Animation lookup works correctly when the board is flipped.

Note: Render Free services have an ephemeral filesystem; server-side account/game data stored only in local files can be lost after restart/redeploy/spin-down. For permanent accounts, use Postgres.
