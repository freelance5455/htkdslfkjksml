# Capri Mobile 2.3 — Local app control

Pink/red, yellow, neon green, black and purple character-inspired interface. **No cloud AI is bundled** — replies are local templates and device actions only.

## Commands
- `open YouTube` / `switch to Maps` — launch a matching installed app (loose name match + common aliases).
- `show apps` — browse installed launcher apps.
- `type Hello there` — type into the currently focused text field in another app.
- `take a screenshot` — save to Pictures/Capri (Android 11+).
- `go back`, `go home`, `recent apps`, `last app`.
- Tap the microphone for Android speech recognition; replies can be spoken aloud (variety of local lines).

## Tools tab (no AI)
- **Camera** — photos, video, optional hand/face tracking.
- Screenshot, Open apps, Last app, Home, Recents.
- Focus timer (local 25‑minute countdown).
- Device help.

## Floating Capri (hover over any app)
Enable **Capri App Control** in Android Settings → Accessibility. A yellow ✦ overlay sits above other apps: drag to move, tap to return to Capri. Toggle it in **Settings → Floating Capri**.

## Enable cross-app control
Settings → Accessibility → Capri App Control. Capri asks for confirmation before typing, launching an app, or capturing a screenshot. Focus the destination text field yourself before `type`.

## Build
Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17.

```bash
# From project root (or open in Android Studio)
./gradlew assembleDebug
# APK → app/build/outputs/apk/debug/app-debug.apk
```

If the Gradle wrapper jar is missing, Android Studio will generate it automatically, or run:
```bash
gradle wrapper --gradle-version 8.9
```

## Limits
Launches launcher-visible apps and types into focused editable fields when Accessibility is enabled. Some apps block text injection; secure fields are not bypassed. Screenshots need Android 11+ and Accessibility. Camera frames and MediaPipe models stay on-device after first download. No AI backend, code generation, or web research is included.
