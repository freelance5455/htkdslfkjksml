# Python Master — النسخة الكاملة
تطبيق تعليمي عربي للجوال والكمبيوتر يضم 36 درسًا مرتبة من الصفر إلى المشاريع الأولية، مع بحث وفلترة وتقدم محفوظ وXP ومستويات ووضع ليلي وأمثلة واختبار ومختبر كود مبسط.
الموضوعات تشمل: أساسيات Python، المتغيرات، الأنواع، العمليات، Strings، input، المقارنات، if، المنطق، for، while، break/continue، Lists، Tuples، Sets، Dictionaries، Functions، Scope، Lambda، Comprehensions، Modules، pip، الملفات، Exceptions، OOP، Inheritance، Generators، Decorators، JSON، Regex، datetime، Debugging، مراجعة ومشاريع.
التشغيل: فك ZIP وافتح index.html.
تحويل APK: ارفع ZIP إلى أداة HTML-to-APK.
ملاحظة: المختبر تعليمي مبسط وليس مفسر Python كاملًا.
