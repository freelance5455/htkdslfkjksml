# Load Ledger

Vehicle logistics sheet. Type a day, reuse vehicle numbers, and export real Excel dates. Data stays in the browser.

## Deploy on Vercel

1. Import this repository in Vercel.
2. Framework preset: Vite (or Other).
3. Build command: `npm run build`
4. Output: leave the default. This app uses TanStack Start + Nitro.
5. Do not set `DATABASE_URL` unless you add your own database. The ledger does not need one.

The app has no login. Shipments are saved in the visitor's browser.
