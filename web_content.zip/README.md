# PROFE LARRY IA — v2

Versión rediseñada como app educativa moderna, sencilla y mobile-first.

## Incluye
- Inicio con 4 accesos grandes.
- Clases por materia.
- Cuestionarios básicos.
- Progreso local.
- Tutor con selector de modo (niño/joven/adulto).
- Selector de profundidad: muy fácil, normal, profundo, experto.
- Contenido educativo básico disponible sin internet.
- PWA + configuración Capacitor para Android.
- Backend preparado para conectar un proveedor de IA sin exponer la API key en la app.

## Importante
Esta entrega es el proyecto fuente. No es un APK firmado.
Para producción hay que desplegar el backend, configurar el proveedor de IA, HTTPS, autenticación y políticas de privacidad, y generar el proyecto Android con Capacitor/Android Studio o un CI de Android.

## Ejecutar
npm install
npm start

Luego abrir http://localhost:3000

## Android
npx cap add android
npx cap sync android
npx cap open android
