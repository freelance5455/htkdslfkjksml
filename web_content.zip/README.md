# Sangita Pest Control Solutions LLP – Service Management App

This ZIP contains a functional front-end prototype with:
- Admin Login
- Employee Login
- Admin-created Employee Login ID and password
- Client/task assignment
- Service Choice options
- Service Done / Not Done / Pending
- Employee daily task dashboard
- Google Maps link/location field
- Online-only access behavior
- Responsive mobile interface

## Demo Admin Login
Login ID: `admin`
Password: `admin123`

## Important
This is a front-end prototype. For real production use, replace localStorage authentication/data with a secure online backend such as Firebase Authentication + Firestore/Storage, enforce role-based security rules, and store passwords only through the authentication provider. Do not deploy the demo Admin credentials publicly.

## Google Maps
Admin can enter a Google Maps URL or client address in the location field. Production version should use the Google Maps Platform/Maps SDK and secure API configuration.

## Company
Sangita Pest Control Solutions LLP
Near Ranbaxy Chowk, Paonta Sahib, Himachal Pradesh - 173025, India
Email: sangitapestcontrolsolutions@zohomail.in
Mobile: +91 9805507099
