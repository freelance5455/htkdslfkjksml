# SPIDER SYSTEM — Homecoming HUD

Reconstrucción Android nativa con interfaz HUD WebView a pantalla completa y reconocimiento/síntesis de voz Android.

## Requisitos
- Android Studio
- JDK 17
- Android SDK 35
- Gradle 8.9 o compatible con Android Gradle Plugin 8.7.3

## Compilar
Abre esta carpeta en Android Studio y espera la sincronización de Gradle.
Luego: Build > Build Bundle(s) / APK(s) > Build APK(s).

## Voz
Al iniciar, concede el permiso de micrófono. El reconocimiento depende del servicio de voz configurado en Android y puede necesitar conexión a Internet. La voz de KAREN usa el motor TTS instalado en el dispositivo.

Comandos reconocidos (pueden decirse con o sin “KAREN”):
- “KAREN, ayuda”
- “KAREN, qué hora es”
- “KAREN, qué fecha es”
- “KAREN, estado del sistema”
- “KAREN, abre la cámara”
- “KAREN, abre ajustes”
- “KAREN, silencio”
- “KAREN, habla”
- “KAREN, quién eres”

El proyecto no incluye bibliotecas externas ni recursos pesados. El tamaño de la APK dependerá del empaquetado, ABI y recursos de Android.
