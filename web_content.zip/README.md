# Fluxo — Projeto Android nativo

Versão: 1.0.0 (versionCode 1)
Package ID: br.com.fluxo.financeiro
Idioma/moeda iniciais: pt-BR / BRL

## O que este projeto faz
- Empacota o HTML localmente em uma WebView Android.
- Habilita JavaScript e DOM Storage para que os dados do Fluxo fiquem no armazenamento local da aplicação.
- Expõe uma ponte nativa que transforma exportações JSON, CSV e PDF em arquivos e abre o seletor nativo do Android para compartilhar/salvar.
- Não pede permissões genéricas de armazenamento: a exportação é feita por intents e FileProvider.

## Gerar o APK
Abra esta pasta no Android Studio com JDK 17 + Android SDK 35; sincronize o projeto e execute **Build > Build APK(s)**. Ou use a workflow GitHub Actions incluída em .github/workflows/build-apk.yml: envie o projeto para um repositório GitHub e execute a workflow manualmente. Ela publica o APK debug como artefato.

Este ZIP contém fontes e configuração de build, não um APK pré-compilado. A compilação requer Gradle, Android SDK e acesso aos repositórios de dependências. O APK debug não equivale a um APK de lançamento assinado com sua própria chave.
