# ELYSIA — Futuristic Personal AI Assistant

> **Tagline:** *Your World. Your Intelligence.*

ELYSIA is a cinematic, mobile-first personal AI assistant engineered for both mobile web browsers and native Android packaging. It pairs an interactive, procedural 3D holographic Three.js core with a secure Gemini API proxy backend, natural speech recognition, voice synthesis, a safe calculation engine, web navigation, and message drafting capabilities.

---

## 🌟 Key Features

1. **Exact Visual Match & Futuristic Holographic HUD**
   - Full-screen portrait-first composition based on the futuristic reference specification.
   - Deep midnight navy gradient background with glowing cyan and violet illuminated perimeter frame with beveled corners, mid-wing indentations, and bottom reticle.
   - Live digital clock and date in the top-left, updating every second.
   - Real-time online/offline connection status and secure connection badge in the top-right.
   - Centered widely-spaced ELYSIA branding with "Your AI Assistant" subtitle.
   - 3D Holographic Core with concentric cyan radar rings, center star singularity with optical flares, 3D undulating sinusoidal particle ribbon (cyan-to-violet gradient), and perspective 3D cyan grid floor.
   - Left side telemetry: SYSTEMS OPTIMAL (with live animated ECG pulse line), MEMORY (truthful utilization), and BATTERY (real Battery API query).
   - Right side telemetry: SPEECH ACTIVE/STANDBY (with animated vertical equalizer bars), AI CORE ONLINE, and LEARNING ACTIVE.
   - Centered glowing audio frequency waveform directly below the core.
   - Bottom command bar with keyboard button, capsule input bar ("Type your command..."), send arrow, and prominent circular microphone toggle button.

2. **Continuous Voice Conversation Mode**
   - User-controlled toggle via the large circular microphone button (Default: OFF).
   - Automatic conversational loop: Listening &rarr; Understanding &rarr; Responding &rarr; Auto-Resume Listening.
   - Full state machine: `OFF`, `REQUESTING_PERMISSION`, `LISTENING`, `PROCESSING`, `SPEAKING`, `RECONNECTING`, and `ERROR`.
   - Anti-feedback loop protection: recognition is suspended while ELYSIA speaks, preventing self-transcription.
   - Invalidation session tokens prevent stale callbacks from restarting listening after the user turns the mode OFF.
   - Local command interception: "Stop speaking" interrupts active speech immediately; "Turn voice mode off" disables the mode instantly.

3. **Real AI Intelligence (Google Gemini API)**
   - Backend Express proxy (`/api/chat` and `/api/status`) utilizing the modern `@google/genai` TypeScript SDK with model `gemini-3.8-flash`.
   - Conversational multi-turn history with memory context.
   - Multilingual support: English (US & UK), Bengali (বাংলা), and Hindi (हिंदी).
   - Server-only API key isolation — no secrets bundled into client code.

3. **Natural Voice Interaction & Speech Synthesis**
   - Tap-to-talk speech recognition via Web Speech API.
   - Browser speech synthesis with localized accents, pitch adjustment, and speech rate control.
   - Procedural Web Audio API sound synthesis (futuristic chimes for activation, completion, listening, and alerts).

4. **Safe Local Command Engine**
   - **Time & Date:** Immediate answers to *"What time is it?"*, *"What is today's date?"*.
   - **Safe Math Evaluator:** Evaluates expressions (e.g., *"calculate 245 multiplied by 18"*, *"15% of 850"*) via a custom lexical tokenizer and recursive descent parser without `eval()`.
   - **Web Navigation:** Opens YouTube, Gmail, Google Maps, WhatsApp Web, and custom URLs safely.
   - **Search:** Dispatches formatted queries to Google Search.
   - **Message Drafting:** Drafts messages for WhatsApp or SMS with one-click copy and pre-filled WhatsApp links without claiming automated transmission.

5. **Local Privacy-First Memory**
   - Configurable session history stored in browser `localStorage` using versioned keys (`elysia_settings_v1`, `elysia_history_v1`).
   - One-tap history clear and ability to disable history persistence entirely.

---

## 🚀 Running the Project

### Development Server
```bash
# Install dependencies
npm install

# Start full-stack development server on port 3000
npm run dev
```

### Production Build
```bash
npm run build
npm start
```

---

## 🔑 AI Service Configuration

The server securely reads the Gemini API key from the environment:
```bash
GEMINI_API_KEY="your-gemini-api-key"
```
In Google AI Studio, this is automatically injected into the container environment. For local testing, define it in `.env`.

---

## 📱 Android APK Packaging Roadmap

### Option 1: Quick Packaging via Capacitor (Recommended)
You can bundle ELYSIA into an installable Android APK with standard Capacitor tools:

```bash
# 1. Install Capacitor
npm install @capacitor/core @capacitor/cli @capacitor/android

# 2. Initialize Capacitor project
npx cap init ELYSIA com.elysia.assistant --web-dir dist

# 3. Build web distribution
npm run build

# 4. Add Android platform
npx cap add android

# 5. Build debug APK
cd android
./gradlew assembleDebug
```
The output file will be generated at:
`android/app/build/outputs/apk/debug/app-debug.apk`

### Option 2: Building directly on an Android Phone (via Termux)
1. Install **Termux** from F-Droid.
2. In Termux, install Node.js:
   ```bash
   pkg update && pkg install nodejs-lts git
   ```
3. Run the development server and open `http://localhost:3000` in Chrome on your phone.
4. Tap Chrome menu (&vellip;) &rarr; **Add to Home screen** / **Install app** for full-screen PWA mode!

---

## 🛡️ Security & Privacy Architecture

- **No Secrets in Frontend:** API keys are never stored in `localStorage`, cookies, or client bundles.
- **Explicit Permissions:** Microphone access is requested only when the user explicitly taps the microphone.
- **No Background Surveillance:** Browser tabs cannot and do not record continuously.
- **Transparent Action Execution:** External links and message drafts require explicit user interaction before sending.
