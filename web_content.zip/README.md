# DZ SHORTS v3000

نسخة Full Stack تجريبية لمنصة فيديوهات قصيرة جزائرية.

## المكونات
- Frontend: HTML/CSS/JavaScript
- Backend: Node.js + Express
- Database: PostgreSQL
- Docker Compose
- رفع فيديو تجريبي محلي
- إعجاب ومشاهدة وواجهة اكتشاف
- API جاهز للتوسعة

## التشغيل
```bash
docker compose up --build
```

ثم افتح:
http://localhost:3000

> هذه النسخة لا تتصل بـ TikTok ولا تدّعي أنها تطبيق TikTok الرسمي.
