# Website X-Ray AI – Deep Website Analyzer & Master Prompt Generator

Website X-Ray AI is a full-stack Next.js, Node.js, Playwright, and SQLite application that inspects publicly accessible websites in a real headless Chromium browser, tests safe interactive UI elements, separates observed facts from inferred or unverified behavior, and generates a complete, non-truncated Master Development Prompt to recreate the target site.

## Core Capabilities

- **SSRF-Protected URL Scanner**: Validates `http://` and `https://` URLs, blocks embedded credentials, rejects private/loopback/link-local/CGNAT IPv4 & IPv6 ranges (`127.0.0.0/8`, `10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16`, `169.254.0.0/16`, `::1`, `fc00::/7`, `fe80::/10`), resolves DNS prior to navigation, and enforces `page.route` interception inside Playwright.
- **Deep Multi-Page Inspection**: Discovers internal links, builds a sitemap, extracts sections, headings, computed typography, hex color palettes, spacing metrics, images, SVGs, forms, and network JSON/API endpoints across **Desktop (1440×900)** and **Mobile (390×844)** viewports with full-page PNG screenshots.
- **Safe Interactive Functionality Testing**: Identifies visible buttons, links, tabs, dropdowns, menus, and forms; tests non-destructive interactions individually and records URL navigation, modal dialogs, `aria-expanded` toggles, tab switches, DOM mutations, and console errors. Automatically skips destructive actions and never bypasses authentication, CAPTCHA, or `robots.txt` restrictions.
- **AI Analysis Engine**: Supports OpenAI, Google Gemini, and Anthropic via server-side API keys (with retries, timeouts, and an evidence-only deterministic fallback if no API key is set). Strictly separates **Observed Facts**, **Inferred Behavior**, and **Unverified / Inaccessible Functionality**.
- **Master Prompt Generator & Copy Interface**: Produces an exhaustive 14-section development prompt inside a large scrollable non-truncated box with **Copy Full Prompt**, **Download TXT**, version history, and **Refine & Regenerate** controls.
- **Persistent Background Queue & History**: SQLite (`better-sqlite3` in WAL mode) stores scans, pages, interactions, AI reports, and prompt versions with live progress polling and rate limiting.

## Prerequisites

- **Node.js** 18.18+ or 20+
- **npm** 9+
- **Chromium** (installed automatically via Playwright)

## Setup & Installation

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Install Playwright Chromium browser**:
   ```bash
   npx playwright install chromium
   ```

3. **Configure environment variables**:
   ```bash
   cp .env.example .env.local
   ```
   Edit `.env.local` and set your preferred AI provider key (`OPENAI_API_KEY`, `GEMINI_API_KEY`, or `ANTHROPIC_API_KEY`) and `AI_PROVIDER` (`openai`, `gemini`, or `anthropic`). Keys are read strictly on the server.

4. **Run in development**:
   ```bash
   npm run dev
   ```
   Open `http://localhost:3000`.

5. **Build & run for production**:
   ```bash
   npm run build
   npm start
   ```

## Project Structure

```text
src/
├── app/
│   ├── api/
│   │   ├── scans/route.ts                # POST (create + SSRF + rate limit), GET (history)
│   │   ├── scans/[id]/route.ts           # GET (full details + live progress), DELETE
│   │   ├── scans/[id]/refine-prompt/     # POST (refine/regenerate Master Prompt)
│   │   └── screenshots/[...path]/        # GET (serve desktop/mobile PNGs safely)
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx                          # Dark-themed dashboard & live progress UI
├── components/
│   ├── MasterPromptPanel.tsx             # Non-truncated prompt viewer, Copy, Download TXT, Refine
│   └── ScanResultsDashboard.tsx          # AI Report, Sitemap, Interactive Tests, Design & Screenshots
├── lib/
│   ├── ai/
│   │   ├── analyzer.ts                   # Evidence-grounded AI report generator
│   │   ├── llm-client.ts                 # Multi-provider server LLM client (OpenAI/Gemini/Anthropic)
│   │   └── prompt-generator.ts           # 14-section Master Prompt Generator
│   ├── db/index.ts                       # SQLite (better-sqlite3) schema & CRUD
│   ├── queue/scan-worker.ts              # Background job queue, concurrency & timeout controls
│   ├── scanner/playwright-scanner.ts     # Playwright multi-page crawler & interaction tester
│   └── security/
│       ├── rate-limit.ts                 # Sliding-window rate limiter
│       └── ssrf.ts                       # SSRF URL & DNS/IP guard
└── types/xray.ts                         # TypeScript domain models
```

## Verification

Run typechecking and SSRF security tests:
```bash
npm run typecheck
npm run test:ssrf
```
