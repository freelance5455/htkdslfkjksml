# Nexo 2.0

Versão funcional do aplicativo Nexo.

## O que foi corrigido
- Chat IA real via backend `/api/chat`.
- Chave da OpenAI fica no servidor, nunca no HTML.
- Histórico da conversa salvo localmente.
- Indicador de IA online/offline.
- Botões de categorias agora selecionam e abrem o Nexo IA.
- Busca filtra as categorias em tempo real.
- Menu > Configurações permite trocar o endpoint.
- PWA/offline-first mantido.
- Service Worker atualizado para a versão 2.

## Rodar no computador
1. Instale Node.js.
2. Abra um terminal nesta pasta.
3. Execute `npm install`.
4. Defina `OPENAI_API_KEY` no ambiente usando `.env.example` como referência.
5. Execute `npm start`.
6. Abra `http://localhost:3000`.

A API da OpenAI é chamada somente pelo servidor. Não coloque sua chave no `index.html`.
