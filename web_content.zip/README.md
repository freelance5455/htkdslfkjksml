# Dunn Tech Repairs - Repair Business Manager

Futuristic responsive Flask app for:
- Phone, computer, laptop and printer repairs
- Software services
- Admin login
- Editable business information
- Editable service prices
- Customer management
- Repair tracking
- Invoice creation
- PDF invoices
- Emailing invoices through SMTP
- SQLite database

## Run
1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Run:
   `python -m pip install -r requirements.txt`
4. Copy `.env.example` to `.env` and change the secret/admin password.
5. Run:
   `python app.py`
6. Open `http://127.0.0.1:5000`

Default username is `admin`.
The initial password comes from `ADMIN_PASSWORD`; if it is not set, the fallback is `admin123`.
Change it immediately in Admin > Settings.

For Gmail, use an App Password rather than your normal Gmail password.
This starter app is suitable for local/testing use. Before public production deployment, add HTTPS, CSRF protection, rate limiting, backups and stronger authentication.
