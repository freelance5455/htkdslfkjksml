# WhatsApp Ledger — APKForge HTML project

This ZIP is a mobile-first HTML/CSS/JavaScript project intended for APKForge's ZIP-to-APK workflow. `index.html` is at the archive root.

## APKForge import
1. In APKForge, choose the ZIP / HTML project source and upload this archive.
2. App name: **WhatsApp Ledger**.
3. Suggested package ID: `com.whatsapp.ledger`.
4. Enable JavaScript.
5. Enable Android WebView file chooser / file upload support (required to select the WhatsApp export from device storage).
6. Allow downloads or file saving if APKForge exposes that option; this is needed for Excel and JSON backup exports.
7. Build the APK, install it, and test selecting a small WhatsApp export before importing a large archive.

## How to use
1. In WhatsApp, open one group, choose **Export chat**, and include media. Save the ZIP to device storage.
2. Open WhatsApp Ledger, enter a clear ledger/group name, and select the ZIP using the on-screen file picker.
3. Import and analyse. The app reads the chat text and attempts OCR on image files.
4. Review every transaction. OCR is imperfect; do not treat unverified values as final accounts.
5. Select a group and export its Excel workbook. The workbook contains a summary and month tabs. Use **Download data backup** regularly.

## Processing and privacy
- The app code does not send chat ZIPs, images, or extracted records to an application server. ZIP parsing and OCR run inside the app's WebView.
- JSZip, Tesseract.js, and SheetJS are loaded from public CDNs. Internet access is therefore required to load these libraries unless APKForge or the user bundles them locally. This is not fully offline operation.
- Data is stored in the WebView's localStorage. It is not encrypted, can be cleared by Android/app data clearing, and may be subject to WebView storage limits. Back up regularly.
- OCR and Excel exports require successful loading of their respective libraries. A missing OCR engine is reported; imported chat transactions can still be saved.

## Supported input and safeguards
- One WhatsApp ZIP export per import, with exactly one `.txt` conversation file.
- Numeric WhatsApp date formats such as `16/11/2026, 10:30 AM`; date parsing assumes day/month/year (Nigeria). Unsupported formats stop the import rather than silently guessing.
- ZIP input limited to 100 MB; extracted content limited to approximately 500 MB and 3,000 files.
- Images up to 15 MB are attempted with English OCR. Other image formats and non-English receipt text may need manual review.
- Transactions without a reliable date remain under **Date not identified** rather than being silently assigned to the current month.
- Receipt/message association is limited: a receipt is linked to a message only when its exact filename appears in the message text. Otherwise, filename date may be used; if unavailable, the date remains unknown.
- Amount extraction is heuristic. Currency, recipient, sender, reference, payment direction, and successful status must be checked against the original receipt. A detected amount is not proof of payment.
- The app deduplicates exact matching records and flags some possible duplicates, but cannot guarantee perfect duplicate detection.
- Separate ledgers are keyed by the group name entered by the user. Reuse the same name for imports belonging to the same ledger; use distinct names for different projects.

## Validation notes
This package has been statically checked for JavaScript syntax and exercised with targeted parser tests. It has not been built by APKForge or tested across every Android device/WebView version. APKForge's native file chooser and download handling must be verified in the generated APK on the target phone before relying on it for accounting records.
