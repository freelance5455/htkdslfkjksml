# FitTrack HTML → APK

This ZIP is a mobile-friendly HTML/CSS/JavaScript starter app.

## Included
- Home dashboard
- Calorie, protein and water tracking
- Exact saved Monday–Saturday workout plan with separate Exercises and Workout History sections
- Exercise sets/reps and completion history
- Food search with gram/ml/piece/bowl/glass/tbsp measurement
- Quantity-based nutrition calculation
- Packaged-food camera/file input
- Progress tracking
- Goals/profile
- Dark mode
- LocalStorage
- JSON backup/restore
- Notification permission test

## Convert to APK with Capacitor

Install Node.js, then run these commands from this folder:

```bash
npm init -y
npm install @capacitor/core @capacitor/cli
npx cap init FitTrack com.example.fittrack --web-dir .
npm install @capacitor/android
npx cap add android
npx cap copy
npx cap open android
```

Then build the APK in Android Studio.

## Worldwide food database

The offline starter contains sample foods so it works without a server. For a true worldwide food database, connect a nutrition API/database such as Open Food Facts or another licensed provider.

## Automatic packet-photo detection

The camera/file UI is included. To automatically identify a packaged food and read calories/protein from its label, connect an OCR/vision API and show the detected values for confirmation before saving.

Do not put private API keys directly in index.html; use a backend/proxy for paid or secret APIs.


## Exact workout template included

Monday — Push A:
Barbell Floor Press; Feet-Elevated Push-ups; DB Shoulder Press; DB Lateral Raise; EZ-Bar Skull Crusher; Reverse Crunch.

Tuesday — Pull A:
Barbell Bent-Over Row; One-Arm DB Row; DB Rear-Delt Fly; EZ-Bar Curl; DB Hammer Curl.

Wednesday — Legs A:
Barbell Squat; Romanian Deadlift; Bulgarian Split Squat; Standing Calf Raise; Reverse Crunch.

Thursday — Push B:
Barbell Floor Press; Weighted Push-ups; DB Shoulder Press; DB Lateral Raise; Overhead Triceps Extension; Leg Raise.

Friday — Pull B:
Barbell Bent-Over Row; One-Arm DB Row; DB Rear-Delt Fly; EZ-Bar Curl; Hammer Curl; Plank.

Saturday — Legs B:
Bulgarian Split Squat; Romanian Deadlift; Goblet Squat; Standing Calf Raise; Leg Raise; Reverse Crunch.

Sunday — Rest.


## Workout History
Workout History is a separate full page. From Workout, tap "Open Workout History →".
Each saved date is clickable and shows the exercises completed that day, sets/reps, calories, protein, water, and food logged for that date.


## Save a complete workout by date (v5)
On the Workout page, choose the day and tap **Save full workout to history** after finishing.
The app saves the whole selected day's exercise list together under the current date, including each exercise name, sets and reps. In History, tap that date to view the entire saved workout in one page. Snapshots remain unchanged if the weekly template is edited later.


## Search and delete history (v6)
- Workout History has a date picker. Select an exact date to filter to that date; tap **Show all dates** to clear the filter.
- Open a date to see the full saved day's workout, sets/reps, food, nutrition and water.
- **Delete this date** removes saved workout, food, water and history records for that date after confirmation.
- History is stored locally in the browser/app's LocalStorage. It may remain available for many years on the same device, but is not guaranteed for 100 years: clearing app data, uninstalling the app or changing devices can erase it. Use Export backup periodically and keep the backup file safe.


## Final version additions
- Profile includes editable current weight (kg) and waist measurement (cm); only latest values are stored, with no measurement history.
- Food search supplements built-in foods with USDA FoodData Central and Open Food Facts online.
- Homemade recipe calculator totals calories and protein from ingredient weights using the built-in food list. Other nutrient data may be missing.
- No database guarantees every food worldwide; online results may omit regional foods or nutrients. Verify packaged labels.
- USDA DEMO_KEY is rate-limited; production deployment should use a registered key protected behind a backend.
