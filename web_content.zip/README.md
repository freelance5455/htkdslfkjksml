# CALISTEN 2.0

Aplicação mobile-first de calistenia, offline-first e baseada em dados reais.

## Executar

Pode ser servido por qualquer servidor HTTP estático. Service Workers não funcionam de forma confiável em `file://`.

Exemplo:

```bash
python -m http.server 8000
```

Depois abrir `http://localhost:8000`.

## Arquitetura

- `state.js`: estado central.
- `database.js`: IndexedDB.
- `storage.js`: persistência, migração, backup e importação.
- `data.js`: exercícios, treinos, skills e conquistas.
- `workout-player.js`: máquina de estados do treino.
- `timer.js`: timer baseado em `performance.now()` e timestamps.
- `progression.js`: progressões e skills.
- `analytics.js`: métricas calculadas.
- `planner.js`: planeamento persistente.
- `settings.js`: preferências e backup.
- `sw.js`: cache offline.

## Persistência

O estado completo é guardado no IndexedDB. Preferências simples também têm uma cópia em localStorage para fallback.

## Offline

Os ficheiros essenciais são precacheados pelo Service Worker. Depois de uma instalação/carregamento inicial bem-sucedido, o núcleo da aplicação pode continuar a funcionar sem Internet.

## Adicionar exercício

Adicione um objeto ao array `EXERCISES` em `js/data.js`, usando um `id` estável e referenciando esse ID nos treinos/progressões.

## Adicionar treino

Adicione um objeto ao array `WORKOUTS`. Os `exerciseId` devem existir em `EXERCISES`.

## Adicionar skill

Adicione um objeto ao array `SKILLS`, definindo requisitos e limiar de domínio.

## APK

A aplicação foi estruturada como PWA e pode posteriormente ser empacotada num WebView/empacotador Android. Isso não cria, por si só, um APK nesta entrega.

## Limitações técnicas reais

- Notificações dependem do suporte/permissões do navegador ou WebView.
- Áudio e vibração dependem do ambiente.
- O Service Worker requer contexto seguro ou localhost.
- O armazenamento do navegador pode ser removido pelo sistema.
- Não há servidor ou sincronização de conta: os dados são locais ao dispositivo.
