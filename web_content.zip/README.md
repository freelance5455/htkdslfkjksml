# ULTROPEIRA — Android project

Este projeto empacota o HTML fornecido como um app Android em modo paisagem, com WebView, tela cheia e ícone de uma toupeira segurando uma escopeta.

O jogo original carrega Three.js por CDN, então o APK precisa de internet para carregar essa dependência na primeira execução.

Abra a pasta no Android Studio e use Build > Build APK(s).
