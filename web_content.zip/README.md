# Poralekha CC Cam Monitor v2

Enhanced CCTV Student Monitor with live Bangla activity detection and automatic Session Summary Preview when stopped.
