# Job Tracker Android App

This is a ready-to-open Android Studio project wrapping the clickable Job Tracker prototype in a native Android WebView.

## Build APK
1. Install Android Studio on Windows, macOS, or Linux.
2. Open this folder (`JobTrackerAndroid`) in Android Studio.
3. Let Gradle sync/download the Android build tools.
4. Choose Build > Build App Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will normally be under:
   app/build/outputs/apk/debug/app-debug.apk

The UI is the same as the supplied prototype and uses local browser storage for jobs and expenses.
