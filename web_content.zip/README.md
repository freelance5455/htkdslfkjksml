# Editor Mobile V3.0
Projeto-base de um editor mobile de vídeo/foto com arquitetura modular.

## Objetivo
Interface própria, otimizada para toque, com timeline multicamadas, projetos, efeitos,
keyframes, máscaras, áudio, exportação e espaço para recursos avançados/IA.

## Stack planejada
TypeScript, React, Canvas/WebGL/WebGPU, WebCodecs, FFmpeg/WASM, Web Audio,
IndexedDB, Web Workers e integração nativa Android/iOS.

A lista completa de tecnologias pretendidas está em `docs/TECH_STACK.md`.
