# Ritika Knowledge — starter app

React + Vite web app that can be packaged for Android with Capacitor. Includes video feed, likes/views, PDF notes, a Ritika chat UI, live-stream link, upload form, and admin dashboard.

## 1. Requirements
- Node.js 20+ and npm
- A free Firebase project (Authentication, Firestore, Storage)
- Android Studio only if building an Android APK

## 2. Run locally
```bash
npm install
cp .env.example .env
npm run dev
```
Open the local URL printed by Vite. Without Firebase keys, the UI opens in demo mode; cloud uploads and real-time content need Firebase configured.

## 3. Firebase setup
1. Create a project at https://console.firebase.google.com/
2. Add a Web App and copy its config values into `.env`.
3. Enable Authentication → Google provider.
4. Create Firestore Database and enable Storage.
5. Put your Google login email in `VITE_OWNER_EMAIL`. Put approved teacher emails, comma-separated, in `VITE_ADMIN_EMAILS`.
6. Restart the dev server after editing `.env`.

Important: the email checks in the UI are only a convenience, NOT secure authorization. Before publishing, set Firebase Authentication + Firestore/Storage Security Rules that enforce admin/teacher roles on the server. Never rely on frontend-only checks for permissions. Use Firebase App Check and upload size/type validation in production.

## 4. Ritika AI
The chat UI works as a demo. To enable real AI replies, deploy a small server endpoint and set `VITE_RITIKA_AI_ENDPOINT` to its URL. The endpoint should accept JSON `{ "message": "..." }` and return `{ "reply": "..." }`. Keep provider API keys on the server, never in Vite variables or browser code. Add rate limits and age-appropriate safeguards.

## 5. Live classes
Set `VITE_LIVE_STREAM_URL` to a live room/player URL from a provider you use. This starter opens the configured link; it does not itself host or broadcast live video. Hosting real live video generally requires a streaming service and may have usage charges.

## 6. Video ads / monetization
Set up a supported ad network account, get approval, and follow its policies before adding ad scripts/placements. `VITE_ADSENSE_CLIENT` is a placeholder only; ad monetization is not implemented in this starter. Views do not guarantee payment. Do not show ads to children in ways that violate applicable ad-network or child-privacy policies.

## 7. Build website
```bash
npm run build
```
Deploy the generated `dist/` folder to Firebase Hosting, Netlify, or another static host. Configure environment variables in the hosting dashboard.

## 8. Build Android APK with Capacitor
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "Ritika Knowledge" "com.laksh.ritikaknowledge" --web-dir=dist
npm run build
npx cap add android
npx cap sync android
npx cap open android
```
In Android Studio, build an APK from **Build → Build Bundle(s) / APK(s) → Build APK(s)**. For changes, run `npm run build` then `npx cap sync android`.

## Starter limitations
- No teacher approval workflow; owner manually adds approved emails in `.env`.
- Likes/views are basic counters, not protected against repeat clicks or abuse.
- Live video requires a third-party provider.
- Real AI endpoint and ads require separate setup.
- For a public launch, add security rules, moderation/reporting, privacy policy, terms, accessibility checks, backups, and test on real devices.
