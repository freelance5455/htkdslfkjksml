# Travel Invoice Generator v2 — APK-ready

This version fixes the reported logo and invoice file problems and adds a full invoice dashboard.

## Fixed / added
- Reliable logo upload for PNG/JPG/WEBP/SVG, with image resizing/compression so it is not lost because of local-storage size limits.
- Invoice data and dashboard records are stored in IndexedDB (with a small localStorage fallback).
- **Download Invoice File** now creates a standalone A4 HTML invoice. In a normal browser it starts a real file download.
- In a Capacitor Android build, the app writes the invoice into the app's Documents area and opens the Android share/open dialog so the user can choose **Files/Downloads** instead of receiving a misleading success toast.
- **Print / Save as PDF** opens a clean invoice-only print page. On Android, use the system print dialog and select **Save as PDF**.
- Dashboard shows all saved invoices with invoice number, booking date, generated date, customer, total and Open / Download / Print / Delete actions.
- Every invoice is saved as a snapshot when **Save Invoice**, **Download Invoice File**, or Dashboard save is used.
- Continuous invoice numbering remains available with manual editing.
- Supporting documents are stored in IndexedDB instead of trying to put large binary files into localStorage.
- A4 layout remains aligned with the supplied reference invoice.

## Important Android build steps

1. Extract this ZIP.
2. Install Node.js and Android Studio.
3. Run `npm install`.
4. Run `npx cap add android` (only the first time).
5. Run `npx cap sync`.
6. Run `npx cap open android`.
7. In Android Studio, build a debug APK or signed release APK.

The Capacitor Filesystem and Share plugins are included in `package.json`, so the Android build can save/share invoice files instead of relying on the unreliable WebView `<a download>` behavior.

### File behavior
- Browser/PWA: Download creates `CompanyNameInvoiceNumber.html` in the browser download location.
- Android APK: Download writes the file to the app Documents directory and opens the Android share/open sheet. Choose Files and then move/save it to Downloads if desired.
- Print: opens an A4 print view; select **Save as PDF** in the Android/desktop print dialog.

## Default payment values
The payment defaults remain the values from the supplied screenshot and are fully editable.

## ZIP size
No `node_modules` or generated Android folder is included, keeping the project ZIP well below 5 MB.
