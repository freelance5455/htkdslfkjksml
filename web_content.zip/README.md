# TGT Pathshala – Functional App UI

This is a React + Vite project based on the supplied TGT Pathshala mockup.

## Included
- Splash/loading screen
- Home screen
- Courses and subject/topic navigation
- PDF Notes with tabs, search, bookmark and download-state actions
- Test Series and a working demo question screen
- Video Lectures and video detail screen
- About Us
- Bookmarks and Downloads screens
- Purchase Course screen
- Settings and Privacy Policy
- Side navigation drawer
- Share App action
- Mobile responsive design

## Important
The app is a functional UI/demo. Real PDFs, videos, login, payment gateway, database and server APIs must be connected to your own services before production release.

## Build
Run:
1. `npm install`
2. `npm run build`

The production website will be in `dist/`.
