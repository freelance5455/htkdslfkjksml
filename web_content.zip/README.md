# FanciStrike V4 — Operator + Emotes

V4 menambahkan:
- Operator lobby baru dengan desain tactical FPS original yang jauh lebih detail.
- Pose idle, armor, helmet, visor, gloves, boots, dan rifle.
- Tombol emoji untuk membuka emote wheel.
- Emote DANCE dengan animasi badan/tangan/kaki.
- Emote WAVE, LAUGH, dan SALUTE.
- Animasi otomatis berhenti setelah beberapa detik.
- Tetap mempertahankan Android landscape wrapper dari V3.

Catatan:
- Karakter V4 ini adalah karakter 3D-style yang dirender dari HTML/CSS agar ringan.
- Ini belum merupakan mesh 3D glTF/FBX sungguhan. Tahap berikutnya bisa diganti dengan operator low-poly 3D nyata saat gameplay 3D dibuat.
