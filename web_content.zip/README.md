
# English Afaan Oromoo — Android Source Project

App barnoota English kan Afaan Oromoo dubbatanif.

## Wantoota keessa jiran
- Beginner → Intermediate → Advanced
- Lessons 30
- English 🔊 fi Afaan Oromoo 🔊 Text-to-Speech
- Quiz
- XP, streak, badges
- Progress
- Offline-first local data
- Android WebView app
- minSdk 23 (Android 6.0+)

## Akka APK ijaartu
1. Project kana Android Studio keessatti bani.
2. Gradle sync eegi.
3. `app` > `build` > `assembleDebug` filadhu.
4. APK argamu: `app/build/outputs/apk/debug/app-debug.apk`

Release/Play Store:
- Signing key (keystore) kee uumuu
- `assembleRelease` ykn Android Studio Generate Signed App Bundle/APK fayyadamu
- Google Play Console irratti AAB olkaa'uu.

## Audio
Appichi Android Text-to-Speech fayyadama. Afaan Oromoo voice yoo device irratti hin jirre, Android Text-to-Speech settings irraa voice Afaan Oromoo yoo argamu fe'i.


Updated version: 100 lessons. Each lesson includes an English word, an English sentence, Afaan Oromoo meaning/sentence, and audio buttons. Progress is tracked offline.
