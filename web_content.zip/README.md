# ATC Aviation Weather
## Aviation Weather & Runway Condition for Air Traffic Controllers and Pilots

**ATC Aviation Weather** is a comprehensive, production-grade aviation meteorology and runway condition monitoring system built for air traffic controllers (ATC), flight dispatchers, and pilots.

This project delivers **both** versions requested:
1. **Version A — Native Android Application** (Kotlin + Jetpack Compose + Room + Retrofit + DataStore)
2. **Version B — Web Application** (HTML5 + CSS3 + Bootstrap 5 + Vanilla ES6 + PWA Service Worker)

---

## Deliverables Summary

| Deliverable | Location | Description | Status |
| :--- | :--- | :--- | :--- |
| **Android APK** | `app/build/outputs/apk/debug/app-debug.apk` | Ready-to-install Android Debug APK (20 MB) | **BUILT & VERIFIED** |
| **Android Source ZIP** | `atc-aviation-weather-android.zip` | Complete Android Studio project ZIP (1 MB) | **PACKAGED & VERIFIED** |
| **Web Application** | `/web/` and `index.html` | Self-contained responsive HTML5/ES6 application | **BUILT & VERIFIED** |
| **Web Source ZIP** | `atc-aviation-weather-web.zip` | Standalone Web application bundle with PWA assets | **PACKAGED & VERIFIED** |

---

## 1. Version A — Native Android Application

### Technologies & Architecture
- **Language:** Kotlin 2.2+
- **Build System:** Android Gradle Plugin 9.1+, Gradle Kotlin DSL (`.gradle.kts`)
- **UI Framework:** Jetpack Compose with Material Design 3, RTL Persian layout, Vazirmatn font
- **Architecture:** Clean MVVM with Kotlin Coroutines and `StateFlow`
- **Data Persistence:** Android Room Database (`AppDatabase`) with DAOs:
  - `AirportDao`: Full catalog of Iranian & international airports
  - `FavoriteDao`: Fast indexing of user favorites and recent airports
  - `WeatherCacheDao`: Local offline cache for METAR, TAF, and SIGMET
  - `SnowtamDao`: Persistent timeline of verified SNOWTAM bulletins
- **Preferences:** Jetpack DataStore (`PreferencesManager`)
- **Networking:** Retrofit 2, Moshi, OkHttp
- **Testing:** Unit and Robolectric tests passing:
  - `AtcWeatherUnitTest.kt`: Airport catalog verification, METAR parser, SPECI detection, TAF change timelines, SNOWTAM thirds and lowest RWYCC, malformed input resilience.
  - `ExampleRobolectricTest.kt`: App resource name verification.

### How to Open, Build, and Run Native Android
1. Extract `atc-aviation-weather-android.zip` or open the root directory in **Android Studio** (Ladybug / Iguana or later).
2. Allow Gradle to sync dependencies automatically.
3. Run the unit tests via terminal:
   ```bash
   gradle :app:testDebugUnitTest
   ```
4. Assemble the APK:
   ```bash
   gradle assembleDebug
   ```
5. Install the generated APK on your Android device:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

---

## 2. Version B — Web Application

### Technologies & Architecture
- **Markup & Styling:** HTML5, CSS3, Bootstrap 5.3 RTL, Bootstrap Icons, Vazirmatn typography
- **Logic:** Vanilla JavaScript ES6 (No React, Angular, Vue, or jQuery)
- **Offline / PWA:** `manifest.json` and Service Worker (`sw.js`) for caching and offline operation
- **Data Integrations:** Live browser `fetch()` calls to:
  - **AviationWeather.gov API:** METAR, TAF, and SIGMET
  - **Open-Meteo Aviation API:** High-resolution multi-level upper-air wind and temperature forecast
- **Parsers:** Client-side JavaScript parsers for METAR/SPECI, TAF, and ICAO Doc 10066 SNOWTAM

### How to Run the Web Application
- Simply open `web/index.html` in any modern desktop or mobile browser (Chrome, Firefox, Safari, Edge).
- Alternatively, serve it via any static HTTP server:
  ```bash
  python3 -m http.server 8080 --directory web
  ```
  Then navigate to `http://localhost:8080` on your mobile phone or desktop browser.

---

## 3. Operational Features Implemented in Both Versions

1. **HOME (پیشخوان عملیاتی):**
   - Active aerodrome overview with flight category indicators (**VFR**, **MVFR**, **IFR**, **LIFR**).
   - Instant quick chips for Iranian airports (`OIIE`, `OIII`, `OIMM`, `OISS`, `OIFM`, `OITT`, `OIBK`, `OIAW`, `OIKB`, `OIZH`, `OIBB`, `OIKK`) and international hubs (`OMDB`, `OTHH`, `EGLL`, `KJFK`).
   - Live UTC clock and network connection state with offline alert.

2. **AIRPORT WEATHER (وضعیت فرودگاه):**
   - Aerodrome specifications (ICAO, IATA, elevation in FT, FIR, coordinates).
   - Unified display of latest METAR, TAF, and upper-air wind.

3. **METAR / SPECI (متار و اسپسی):**
   - Untouched raw official METAR / SPECI display with clipboard copying.
   - Prominent **SPECI** alert badge.
   - Decoded parameters: surface wind, gust, variable wind range, visibility (meters & SM), CAVOK, RVR, present weather, clouds and ceiling, temperature, dew point, altimeter QNH (hPa & inHg), and 2-hour trend (`NOSIG`, `BECMG`, `TEMPO`).
   - Non-destructive parser that flags parsing errors while preserving the original message.

4. **TAF (پیش‌بینی تف):**
   - Untouched raw TAF forecast text.
   - Issue time and validity period.
   - Decoded timeline of change groups (`FM`, `BECMG`, `TEMPO`, `PROB`).

5. **SIGMET (پدیده‌های حاد جوی):**
   - Active SIGMET bulletins filtered by current validity time.
   - Hazards: Thunderstorms (`TS`), Severe Turbulence (`TURB`), Severe Icing (`ICE`), Volcanic Ash (`VA`), Mountain Waves (`MTW`).
   - Flight level base/top, movement vectors, and geographic coordinates.

6. **WIND ALOFT (باد و دمای سطوح فوقانی):**
   - Multi-level vertical wind profile from surface up to **FL450** (`Surface`, `FL050`, `FL100`, `FL180`, `FL300`, `FL340`, `FL390`, `FL450`).
   - Direction in degrees, speed in knots, and temperature in Celsius.
   - WMO GFS numerical prediction model integration.

7. **SNOWTAM / RUNWAY CONDITION (اسنوتام و وضعیت باند):**
   - Structured implementation of **ICAO Doc 10066 and Global Reporting Format (GRF 2021)**.
   - Visual Runway Thirds breakdown (**THIRD 1 | THIRD 2 | THIRD 3**).
   - Runway Condition Code (**RWYCC 0–6**), lowest reported RWYCC, contaminant type, coverage percentage, and depth in mm.
   - Ingestion tool for entering live bulletins or loading verified ICAO Doc 10066 sample bulletins.
   - Persistent timeline history in local database.

8. **WEATHER MAP (نقشه تعاملی):**
   - Map rendering of airports with flight category markers, active SIGMET areas, and wind vectors.
   - Filterable for Iran FIR (`OIIX`), Middle East, and worldwide.

9. **ATC WEATHER BOARD (تابلوی چندفرودگاهی):**
   - Multi-airport summary table for quick scanning of arrival and alternate aerodromes.

10. **ICAO & GRF GUIDE (راهنمای آموزش و استانداردها):**
    - Technical guide on SNOWTAM, Runway Condition Report (RCR), RWYCC table and braking action, runway thirds, and essential ATC considerations.

11. **SETTINGS (تنظیمات سامانه):**
    - Dark & Light operational themes.
    - Units configuration: Wind speed (KT / MPS), Temperature (°C / °F), Pressure (hPa / inHg).
    - UTC clock with optional local airport time.
    - Configurable automatic cache refresh interval.

12. **ABOUT / DATA SOURCES (منابع داده):**
    - Real-time connection status monitoring for all 5 integrated adapters.

---

## 4. Verified Data Sources & Status

| Data Source | Type | Tested Endpoint | Status | Notes |
| :--- | :--- | :--- | :--- | :--- |
| **AviationWeather.gov Data API** | REST API | `https://aviationweather.gov/api/data/metar` | **CONNECTED & VERIFIED** | Live METAR, TAF, and SIGMET for Iran (`OIIE`, `OIII`) and worldwide |
| **Open-Meteo High Resolution GFS** | REST API | `https://api.open-meteo.com/v1/forecast` | **CONNECTED & VERIFIED** | Live multi-level upper-air winds & temps from Surface to FL450 |
| **WIFS API (WAFS Internet File Service)** | Direct Adapter | `https://aviationweather.gov/wifs/api.html` | **CONFIGURED** | Requires official approved WIFS subscription credentials |
| **ICAO API Data Service** | Direct Adapter | `https://www.icao.int/api-data-service` | **CONFIGURED** | Requires ICAO portal subscription key |
| **Iran AIS / IRIMO** | Portal Tracker | `https://ais.airport.ir` | **AUTHENTICATION REQUIRED** | Intranet AFTN/AMHS access; international OPMET feeds are retrieved via AviationWeather/WMO |

---

## 5. Operational Safety Disclaimer

> **Operational decisions must be based on current authorized aviation information sources and applicable local procedures.**
>
> **تصمیمات عملیاتی مراقبت پرواز باید بر اساس منابع رسمی معتبر هوانوردی و دستورالعمل‌های محلی مصوب اتخاذ گردد.**
