KILILA FINAL — build compatible con APKForge.

Subir este ZIP con index.html en la raíz. Estado inicial limpio: 0 barriles, 0 ventas, 0 producción, 0 stock. El empleado debe abrir el local antes de vender.


KILILA FINAL 4 — soporte corregido. El botón SOPORTE usa un enlace HTTPS de WhatsApp Business y evita el esquema whatsapp:// que provocaba ERR_HTTP_RESPONSE_CODE_FAILURE en el WebView.
