# My Savings — Android-friendly savings tracker

This is a mobile-first Progressive Web App (PWA) based on your reference image.

## Features
- ₹1, ₹2, ₹5, ₹10, ₹20, ₹50, ₹100, ₹200 and ₹500 quick-add tiles
- Custom whole-rupee amount
- Quantity plus/minus controls and automatic total
- Multiple named savings accounts
- Coin/note tap-count crosscheck by denomination
- Transaction history with date, account and note
- Local device storage and JSON backup export
- Coin-clatter sound for coins and ATM-style cash-dispensing sound for notes
- Installable on Android as a home-screen app when served over HTTPS

## Quick test
Open `index.html` in a modern browser. Savings are stored in that browser on that device. For the most reliable install/offline behavior, serve the folder through HTTPS.

## Install on Android
1. Upload the contents of this folder to a static host that provides HTTPS (for example, GitHub Pages or Netlify).
2. Open the hosted URL in Chrome on Android.
3. Open Chrome's menu (⋮) and choose **Install app** or **Add to Home screen**.
4. Launch **My Savings** from your home screen.

## Important
This starter stores data locally on the device/browser; it does not connect to a bank or move real money. Clearing browser storage can erase savings records, so use **↗** in the top-right to export a JSON backup regularly. This version accepts whole-rupee amounts only.


Updated edition: user-provided coin and banknote photos are included in the assets folder. The ₹10 and ₹20 selections use the supplied banknote images; denominations without a supplied image retain the previous illustration.


## Updated behavior
- Tap any coin or note on Home to add one item instantly to the first savings account.
- Each tap creates its own transaction, so tapping ₹1 ten times shows a count of 10 in Check.
- Coin denominations play a coin-clink sound; banknote denominations play a paper flick sound.
- The Summary tab has been removed.
- Accounts includes a one-tap “Add Savings Account” button.


Audio troubleshooting (v4): the uploaded sound is embedded in index.html, so the sound no longer depends on the separate assets path. Open the extracted index.html in a regular browser, tap a coin/note, and ensure media volume is on. Some in-app previews block audio until the page is tapped.


Version under 5 MB for HTML uploaders: index.html references the bundled money-selection.mp3 file. Keep both files in the same folder when opening the app. If your phone's HTML viewer still refuses local audio, open the folder in a browser that allows local files or host both files together on a free static website.
