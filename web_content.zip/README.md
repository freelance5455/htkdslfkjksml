# صلاتي Pro — HTML إلى APK

هذه نسخة أولية متطورة بواجهة عربية RTL ومهيأة للتحويل إلى Android عبر Capacitor.

## التشغيل
1. ثبّت Node.js وAndroid Studio.
2. داخل المجلد شغّل:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
3. من Android Studio اختر Build > Build APK(s).

## ملاحظة
مواقيت الصلاة الموجودة حاليًا بيانات تجريبية للواجهة. قبل النشر يجب ربطها بمصدر/خوارزمية موثوقة لمواقيت الصلاة حسب الموقع وطريقة الحساب، ثم إضافة إشعارات الأذان والقبلة والقرآن والأذكار بشكل فعلي.
