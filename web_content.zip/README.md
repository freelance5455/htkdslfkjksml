# AnimeApp REAL v1.1

## Nova função desta versão

O painel do dono agora possui **Gerenciamento de contas**.

Ao lado de cada membro aparecem:
- foto de perfil
- Nick
- Nick permanente
- email
- cargo
- botão **Alterar senha**

Ao abrir:
- Novo Nick
- Novo Nick permanente
- Novo email
- Nova senha
- informações atuais da conta
- Cancelar
- Salvar alterações

É obrigatório alterar pelo menos um campo.

### Segurança importante

A senha **não é exibida** no painel e não é armazenada em texto puro.
Ela é guardada usando `bcrypt`.

Se um membro esquecer a senha, o dono pode simplesmente criar uma nova senha para a conta através do botão **Alterar senha**.

## Primeiro usuário

A primeira conta registrada recebe automaticamente:
`role = owner`

Somente essa conta pode acessar `/api/admin/users` e alterar contas.

## Rodar

```bash
npm install
npm start
```

Abra:
http://localhost:3000

Para produção, troque `SESSION_SECRET` por uma chave forte e configure HTTPS.

## Observação

Esta v1.1 preserva a base de autenticação e adiciona o gerenciamento seguro de contas. As outras funções do projeto podem ser conectadas a esta mesma API/banco na próxima versão.


## v1.2.0 - Personalização pelo painel

O dono agora tem uma área **Personalizar o app**.

### Cores
É possível alterar:
- Cor principal
- Cor do fundo
- Cor dos cartões
- Cor dos textos

Você pode digitar nomes CSS como `blue`, `white`, `red` ou códigos como `#367dff`.

### Ícone
O dono pode escolher uma imagem do próprio celular para ser o ícone da página inicial.
Aceita PNG, JPG, WEBP e GIF, com limite de 2 MB.

### Salvar
Tudo fica dentro de um único botão azul:
**Salvar personalização**

As alterações ficam salvas no banco do projeto e aparecem para os usuários.

## v1.3.0 - Conexões
A quinta opção de configurações é **Conexões**. O usuário pode enviar uma foto e um link.
No painel do dono, **Ver conexões** mostra foto, Nick e link, com a opção de proibir links automaticamente.
O botão **＋** abre a área de restrição e a lista de usuários restringidos. A restrição pode ser retirada pelo botão ao lado do perfil.
