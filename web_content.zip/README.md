# Ktiba — APK (بلا Android Studio)

1. دير حساب مجاني على github.com ثم New repository (مثلا ktiba).
2. ارفع كل محتوى هاد الدوسي (www, assets, native, package.json, capacitor.config.json).
3. الدوسي المخفي `.github/workflows/android.yml`: فـ GitHub دير Add file ← Create new file، اكتب فـ الاسم `.github/workflows/android.yml` والصق محتوى الملف.
4. ادخل Actions ← Build APK ← Run workflow. تسنى حوالي 8 دقايق.
5. نزّل Artifact `Ktiba-APK`، فك الضغط، وثبّت `app-debug.apk` على التلفون (اسمح بـ unknown sources).

فالنسخة هاد: Save كيدخل مباشرة لألبوم Ktiba فالمعرض، وShare كيفتح share sheet ديال أندرويد بالملف.
إذا طلع error فـ Actions ابعثلي الـ log.

Instagram Story / Post / TikTok كيتحلو مباشرة (native plugin فـ native/). إذا التطبيق ما مثبتش كيطلع share sheet عادي.
