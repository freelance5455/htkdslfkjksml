# WONDER SHIFT — Production Web

Application de gestion bureautique mobile-first, en FC, conçue pour fonctionner hors ligne et être transformée en APK avec Capacitor.

## Contenu
- Tableau de bord inspiré de la maquette fournie
- Opérations recettes/dépenses, réduction, paiement, client et observations
- Historique avec recherche, filtres et pagination
- Rapports et export CSV / impression PDF navigateur
- Stock avec seuils, entrées/sorties et alertes
- Caisse avec ouverture, mouvements et fermeture
- Administration Développeur : utilisateurs, services, tâches et tarifs
- Notifications locales
- IndexedDB + Service Worker pour le hors-ligne
- File de synchronisation prête pour Supabase
- PWA + structure Capacitor

## Démarrage local
Un serveur HTTP est recommandé car Service Worker et certaines API navigateur ne fonctionnent pas correctement avec `file://`.

Python :
```bash
python -m http.server 8080
```
Puis ouvrir `http://localhost:8080`.

## Comptes de démonstration
- FLORY / Flory@2026
- AUGUSTIN / Augustin@2026
- SUPERVISEUR / Superviseur@2026
- DEVELOPPEUR / Dev@2026

Les mots de passe des comptes de démonstration sont transformés en SHA-256 avant stockage local. En production multi-utilisateur, utiliser Supabase Auth.

## Supabase
1. Créer un projet Supabase.
2. Exécuter `supabase-schema.sql` dans SQL Editor.
3. Copier `config.example.js` en `config.js`.
4. Renseigner l'URL du projet et la clé `anon` publique.
5. Créer les utilisateurs dans Supabase Auth et leurs lignes `profiles`.
6. Déployer le dossier sur un hébergement HTTPS.

**Ne jamais mettre une clé `service_role` dans le navigateur.**

## APK avec Capacitor
```bash
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "WONDER SHIFT" "com.wondershift.app" --web-dir .
npx cap add android
npx cap copy
npx cap open android
```
Puis compiler depuis Android Studio. Pour caméra, notifications, biométrie et Bluetooth, ajouter les plugins Capacitor correspondants et demander les permissions Android nécessaires.

## Déploiement
Héberger en HTTPS (Netlify, Vercel, Cloudflare Pages, serveur Nginx, etc.). Ne pas ouvrir directement le fichier HTML par double-clic pour tester le Service Worker.

## Sécurité de production
Cette archive fournit une base frontend production-ready, mais le déploiement connecté doit impérativement utiliser Supabase Auth + RLS. Les comptes de démonstration locaux sont destinés aux tests. Vérifier les politiques RLS et les flux de récupération de mot de passe avant mise en service.

## Limites connues de cette release
- La synchronisation Supabase est préparée pour les opérations et nécessite la configuration du projet.
- L'envoi réel d'e-mails/WhatsApp nécessite un fournisseur backend ou une Edge Function ; les clés privées ne doivent pas être embarquées dans le frontend.
- L'impression PDF utilise l'impression du navigateur dans cette release ; une génération jsPDF serveur/client peut être branchée sans modifier les données métier.
- La biométrie, le Bluetooth et le lecteur code-barres nécessitent les plugins Capacitor lors de la construction APK.

## Administration Développeur

Le compte `DEVELOPPEUR` dispose d'un centre d'administration distinct des autres utilisateurs. Il peut :

- modifier le nom et l'identifiant de connexion des agents ;
- réinitialiser les mots de passe ;
- modifier les rôles Agent / Superviseur / Développeur ;
- activer ou désactiver les comptes ;
- ajouter, modifier, désactiver et supprimer des services ;
- ajouter, modifier, désactiver et supprimer des tâches ;
- modifier les prix par défaut en FC ;
- ajouter, modifier et supprimer les consommables ;
- modifier les seuils d'alerte et les unités du stock ;
- ajouter/modifier la photo d'un utilisateur ;
- exporter le journal d'audit ;
- accéder aux paramètres globaux développeur ;
- configurer l'identité de l'application et les destinataires principaux ;
- exporter et restaurer une sauvegarde locale.

Le compte principal `DEVELOPPEUR` est protégé contre sa désactivation et la modification de son identifiant principal depuis l'administration.


## Synchronisation V11
La synchronisation est additive et non bloquante : IndexedDB reste la couche de fonctionnement local, tandis que l’API Supabase conserve une copie synchronisée. Les conflits sont détectés côté API et peuvent être examinés/résolus ultérieurement.
