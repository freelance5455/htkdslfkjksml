# Drumps Online App Prototype

Drumps (DRP) is a fictional in-app currency for this prototype.

## Included
- Login / create account screen
- Username + password demo authentication
- 1,000 DRP starting balance
- Send Drumps to another account
- Receive Drumps
- Transaction history
- Logout
- Mobile-friendly UI

## Important
This version is a front-end demo. It stores accounts in the browser with localStorage, so it is NOT secure and does not actually work across different phones/computers.

For a real online version, use:
- a real authentication service
- a server-side database
- server-side transaction validation
- hashed passwords
- HTTPS
- rate limiting and fraud protection

Open `index.html` to try the prototype.
