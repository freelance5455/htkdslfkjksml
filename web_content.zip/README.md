# My Kitchen IA — prototype

Prototype web mobile-first de l'application de recettes.

## Inclus
- Explorer par continent/pays
- Recherche
- Fiches recettes
- Nombre de personnes + recalcul automatique des quantités
- Programmation dans un calendrier
- Accès direct à la recette depuis le calendrier
- "Mes ingrédients" agrégés depuis les repas programmés
- Cases à cocher pour les ingrédients déjà disponibles
- Mode cuisine étape par étape
- Écran d'abonnement à 2 000 FCFA/mois (paiement non connecté)

## Lancer
Ouvrir `index.html` dans un navigateur moderne.

Les données de démonstration sont stockées localement dans le navigateur. Pour une vraie application multi-utilisateurs, il faudra ensuite ajouter un backend, une base de données, l'authentification, un vrai système de paiement et des sources de recettes/images/vidéos sous licence.
