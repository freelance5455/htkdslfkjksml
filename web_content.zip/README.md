# KOR Overseas Employment Institute — Mobile Web App

## Included
- Mobile-friendly KOR dashboard
- Trainee registration, attendance and inventory
- Excel export and report sharing
- Camera/file attachment support
- PWA install support and basic offline app-shell caching

## Run on Android
1. Extract this ZIP.
2. Upload the folder to a static HTTPS host (or run a local web server).
3. Open the HTTPS address in Chrome on Android.
4. Chrome menu → **Install app** or **Add to Home screen**.

The browser-based app works as an installable mobile app. Camera access and offline installation require HTTPS (except localhost).

## Build a native Android project (optional)
Install Node.js, then in this folder run:
```bash
npm init -y
npm install @capacitor/core @capacitor/cli
npx cap init "KOR Institute" "com.kor.institute" --web-dir .
npm install @capacitor/android
npx cap add android
npx cap sync android
npx cap open android
```
Build the APK from Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

## Important notes
- Data is currently saved in the browser's local storage on that device. It does not automatically synchronize between phones/computers. Export backups regularly.
- This ZIP is the app source/project, not a prebuilt APK.
- External CDN libraries (Tailwind, Lucide, SheetJS, Google Fonts) need internet access.
- Labour ID is manually entered and retained as typed. An `EM` or `EF` prefix determines the saved gender. Series number remains auto-incremented.
- The “Generate Monthly Batch” feature creates sample/demo trainee records; review them before treating them as real registrations.
