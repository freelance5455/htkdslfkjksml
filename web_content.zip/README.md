# NexaCircle — HTML Web App + Android APK Wrapper

This package converts the NexaCircle social UI into a self-contained HTML/CSS/JS app
and provides a Capacitor Android wrapper project.

## Open the web app
Open `www/index.html` in a browser.

## Build Android APK
1. Install Node.js and Android Studio.
2. In this folder run:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
3. In Android Studio choose Build > Generate App Bundles or APKs > Generate APKs.

The included Android wrapper configuration is prepared for Capacitor. A real online
social network still needs a production backend for authentication, database, media,
moderation, reporting, and secure server-side authorization.

## Demo behavior
The HTML app stores demo profile/posts locally in the browser. It is not a real
multi-user server. Do not treat localStorage as production authentication or storage.
