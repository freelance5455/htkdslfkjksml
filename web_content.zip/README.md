# Addis Jeans - Quick Bill POS 👖🧾

A modern, fast, mobile-friendly Quick Billing POS Web Application designed for retail stores (Addis Jeans). 
Built with responsive HTML5, Tailwind CSS, FontAwesome, Web Bluetooth ESC/POS engine, and Android Wireless/WiFi Printing support.

## ✨ Features

- **Receipt Bill Customizer**:
  - Live interactive receipt design tool with real-time preview.
  - Show / Hide Store Tagline, Address, Phone Number, and GSTIN.
  - Choose header title font size (Normal, Large, Extra Large).
  - Paper roll width selector: 80mm Standard POS vs 58mm Mini POS.
  - Customizable Bill Number prefix (e.g., `Bill #`, `INV-`, `AJ-`).
  - Toggle columns: Show/Hide Serial Number (SR) and Rate column.
  - Toggle Date & Timestamp, Customer Name, Total Quantity, and Payment Mode.
  - Custom Footer Note & Terms/Exchange policy.
  - Optional UPI QR Code for instant scan-to-pay.
- **Tactile Calculator Keyboard**: Fast numeric Qty and Rate inputs with mechanical key click audio synthesized via Web Audio API.
- **Smart Rate Matching**: Automatically suggests item names when typing selling rates.
- **Thermal Receipt Printing**:
  - **Web Bluetooth**: Direct ESC/POS byte-level commands (Init, Feed, Auto-Cutter `GS V 66 0`).
  - **WiFi / Network Printing**: Direct IP/Port configuration & Android Wireless System Spooler.
- **Multi-App Bill Sharing**: Share bill receipts via WhatsApp, SMS, clipboard, or JPEG file directly to other apps.
- **Save as JPEG**: Export crisp 80mm thermal receipt slips directly to device storage using HTML5 Canvas.
- **Everyday Sales & Inventory**:
  - Daily sales audit with KPI summaries (Total Bills, Total Qty, Total Sales Amount).
  - Modify and delete saved bills with live stock reconciliation.
  - Complete product inventory catalog with stock counters.

## 🚀 How to Run on GitHub Pages

1. Fork or upload all files to your GitHub repository.
2. Go to **Settings** > **Pages**.
3. Under **Branch**, select `main` (or `master`) and folder `/ (root)`.
4. Click **Save**.
5. Your live app will be accessible at: `https://<your-username>.github.io/<repo-name>/`

> **Note on Web Bluetooth**: Web Bluetooth requires a secure HTTPS connection (automatically provided by GitHub Pages).
