# APKForge Termux Mobile (v1.1)

Compilateur local d'applications Android (.html ou .zip -> .apk) directement sur téléphone Android.

## Nouveautés v1.1
- Correction de l'importation de fichiers `.html` et `.zip` sur Android (sélecteur natif `<label>` + `accept="*/*"`).
- Support natif de `onShowFileChooser` et des téléchargements `blob:` / `data:` dans le `MainActivity.java` généré.

## Installation rapide dans Termux
1. `termux-setup-storage`
2. `cd ~/storage/downloads/APKForge-Termux-Mobile`
3. `chmod +x install.sh && ./install.sh`
4. `npm start`
5. Ouvrez `http://localhost:3000` dans Chrome.
