# MealWise AI — Android-ready offline meal tracker

A responsive, offline-first nutrition tracker designed for Android. All meal, pantry and weight data is saved locally in the browser/device using `localStorage`. No account or API key is required.

## Features
- Meal diary with date, meal type, calories, protein, carbs and fat
- Daily nutrition summary and progress bars
- Pantry inventory with quantity, category and expiry reminders
- Weight history with a chart
- Personalized meal ideas based on logged nutrition and pantry items
- Installable PWA shell with service-worker caching
- Delete controls for correcting entries

## Important AI note
This first build uses a lightweight on-device rules engine for personalized suggestions. It does not call a hosted generative AI model and does not claim computer-vision food recognition. That keeps the app private, offline-capable and API-key-free. True generative AI or photo-based food recognition requires an on-device model or a remote service.

## Run locally
Serve this folder over localhost or HTTPS (service workers do not run on ordinary `file://` URLs). For example, on a computer with Python:
`python -m http.server 8080`
Then open `http://localhost:8080`.

## Install on Android for testing
1. Host this folder on an HTTPS static host, or serve it from your local development machine.
2. Open the URL in Chrome on Android.
3. Open Chrome menu → **Install app** / **Add to Home screen**.
4. Data stays in that browser's local storage. Clearing browser data can erase it, so export/backup is not included in this first version.

## Android APK
This package is the app source/PWA, not a compiled APK. An APK needs an Android build environment and signing/build step (for example, wrapping this web app with Capacitor and building with Android Studio). This environment did not compile or publish an APK, so no APK or live deployment URL is claimed.

## Privacy / health note
Weight and meal records are stored on this device/browser. This is a wellness logging tool, not medical advice. Nutrition estimates entered by users may be inaccurate.
