# Detox

Quit what holds you back. A live timer, a ball pit, and an elephant who gets happier with every clean day.

**What you pick from:** NoScroll, NoFap, NoBooze, Drug free.

## Get your APK

This zip is a complete Capacitor project: the app (`www/`), the Android code for the nudge (`native/`) and everything that wraps it into an APK. The `android/` folder is generated for you in the first step, so it is not included.

### A. GitHub Actions (easiest, no installs, works from a phone browser)

1. Create a new **private** repository on GitHub and upload everything from `Detox-android-project.zip`.
   - The workflow lives in `.github/workflows/build-apk.yml`. If your upload skipped hidden folders, create that path yourself and paste in the contents of `GITHUB-build-apk.yml`.
2. Open the **Actions** tab. The build starts by itself on every push (or press **Run workflow**).
3. After about 6 to 10 minutes, open the finished run and download **Detox-debug-apk** from *Artifacts*.
4. Unzip it, send `app-debug.apk` to your phone and tap it. Allow "install unknown apps" for your browser or files app when Android asks.

The build downloads the Block List Project adult list and packs it into the app, so it needs nothing from you.

### B. Android Studio (on a computer)

Needs Node 20+, Java 21 and Android Studio.

```bash
npm install
npm install --no-save @capacitor-mlkit/barcode-scanning   # optional: the built-in QR scanner
node scripts/build-blocklist.js                              # downloads and packs the nudge list
npx cap add android
node scripts/patch-android.js --require-list
npx cap sync android
cd android && ./gradlew assembleDebug
```

The APK lands in `android/app/build/outputs/apk/debug/app-debug.apk`. (`npx cap open android` opens it in Android Studio instead.) If you already downloaded the list, pass it in: `node scripts/build-blocklist.js path/to/porn.txt`.

### C. A "website to APK" converter

`Detox-web.zip` is the same app with `index.html` at the top, for any HTML-to-APK site. It works there, **except the nudge**, which needs the Android code in this project (route A or B). Guardians work, but the converter's app may not let the camera scan; the code can always be pasted instead.

## How it works

1. **Pick** what you are quitting, then **type when you last did it**. The date can be in the past.
2. The **timer** appears with the exact time since, counting live to the second. A ball is tossed into the air.
3. **Scroll down.** The night sky turns to day and you are in the **ball pit**. A mesh bag hangs at the top, the pit is nearly empty, and an elephant walks in and starts to play. A short story explains it the first time.
4. Every clean day drops balls from the mesh bag into the pit. More balls, happier elephant. Milestones (7, 14, 30, 60, 90, 180, 365 days) drop a bonus.
5. **At 8:00 every morning** you confirm you were clean the day before. The bag cracks a little wider and the balls fall.
6. Scroll back up for the three buttons:

| Button | Meaning | What happens |
|---|---|---|
| Blue | Day passed | Nice blue balls drop into the pit |
| Yellow | Lapse | Different-coloured (yellow) balls roll in. The timer restarts by default (switch that off in Settings to leave it running) |
| Purple | Relapse | One ball leaves the pit and the timer restarts |

Every action has an **Undo**. If you forget a few days, the app asks you about each missed day in order. The **calendar** icon shows your whole journey in colour with a key. The **gear** opens settings.

## Guardians (QR code, nothing to set up)

Two people you trust can press **Lapse** or **Relapse** for you if you cannot. They can never press *Day passed*.

- **You:** Settings, Guardians, **Invite someone**, type their name. A QR code appears.
- **Them:** open Detox, tap **Go guardian** (bottom of the first screen, or in Settings, Guardians), scan your code (or paste the text code you send them), and add their own name.
- They now see your live timer and two buttons. Everything they press shows up on your phone with their name on it.

How it travels: your QR holds a secret key that only your two phones know. Messages are scrambled with it (AES-256) and dropped in a public mailbox (ntfy.sh). The mailbox only ever sees scrambled text, nobody else can read or forge a message, and there is no account and no server for you to run. You can remove a guardian at any time.

Things to know:
- Your phone picks up a press when Detox is open (checked every 20 seconds) or the next time you open it. The mailbox keeps messages for about 12 hours, so if your phone was closed for a long time, a guardian's Detox re-sends whenever they open it until your phone confirms it got the message.
- Guarding needs an internet connection on both phones.
- Advanced: Settings, Guardians, Advanced lets you use your own ntfy server instead of ntfy.sh.

## Nudge (Android app only)

Settings, **Nudge**. Three screens: what it does, the permission, and your list.

- It uses Android **Accessibility** to read the address bar of web browsers, and to draw a ball over the screen. It never reads page content, passwords or messages, and nothing leaves your phone.
- When you open a site on the list it starts a quiet session, waits a random 90 to 180 seconds, and then:
  - **70% of the time** a slow ball drifts across the screen with "Please don't" written on it. If you ignore it, it leaves on its own, with no sound or notification.
  - **30% of the time** nothing happens at all. No ball, no message, no trace.
  - Tap the ball and you go to the home screen. One anonymous tap is counted on your phone.
- It **never blocks anything**. The page keeps playing underneath.
- The list is the Block List Project adult list (built in during the build) plus any sites you add.

Setup tips:
- Android shows a stern warning for Accessibility. That is the standard wording for every accessibility service.
- If the switch is greyed out: Android blocks it for apps installed from a file. Open **App info, the three dots at the top right, Allow restricted settings**, then try again.
- Set Detox battery use to **Unrestricted**, or some phones will stop the service.
- Supported browsers: Chrome, Firefox, Samsung Internet, Brave, Edge, Opera, DuckDuckGo, Vivaldi, Kiwi, Tor, Yandex, Ecosia and a few others. Apps with their own built-in web view are not covered.
- To refresh the list, rebuild (route A pulls the newest list every time).

## Project layout

```
www/                 the app (plain HTML, CSS, JS, no build step)
  js/core.js         the rules: days, check-ins, rewards, moods (unit tested)
  js/qr.js, p2p.js   QR code generator, pairing codes, encryption, mailbox
  js/sync.js         owner side of guardians;  js/guard.js  guardian mode
  js/nudge.js        the three nudge setup screens
native/android/      Java for the nudge: accessibility service, ball overlay, plugin
scripts/             packs the blocklist, patches the Android project, makes icons
resources/           generated launcher and notification icons
tests/               run with: npm test
```

## Troubleshooting

- **The workflow did not start:** check that `.github/workflows/build-apk.yml` exists in the repository and that Actions is enabled.
- **"App not installed" on the phone:** uninstall any older Detox first, then install again.
- **No 8:00 notification:** allow notifications for Detox in Android settings.
- **Time zones:** the 8:00 rule uses the phone's local time.
- **The scan button is missing:** the camera scanner is optional. Paste the code instead.
- **Release build for the Play Store:** this produces a debug APK for your own phone. The Play Store restricts apps that use Accessibility like the nudge does, so it is meant for sideloading.
