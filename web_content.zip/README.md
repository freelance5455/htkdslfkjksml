# STI2D Révision V3

Application locale en français pour la terminale STI2D, enseignement spécifique ITEC, année 2026–2027. Le premier démarrage ouvre un carnet vide.

## Ouvrir l’application

Décompresser toute l’archive dans un même dossier, puis ouvrir **index.html** dans un navigateur avec JavaScript activé. Garder les sous-dossiers à leur place. Ouvrir le fichier depuis l’archive ou depuis un aperçu de pièce jointe peut empêcher le chargement des autres ressources.

Les scripts, les cours, les graphiques et les illustrations sont locaux. Aucun compte, service distant, appel à une IA, téléchargement de police, suivi publicitaire ou service worker. L’application bloque les connexions initiées par ses scripts.

## Convertir le ZIP en APK

1. Dans un convertisseur HTML-to-APK qui sait **embarquer un projet local multifichier**, choisir « Local HTML », « ZIP » ou « Assets » selon le service.
2. Importer le ZIP entier. Choisir **index.html** comme page d’entrée, directement à la racine. Le convertisseur doit inclure tous les fichiers et leurs chemins relatifs dans l’APK.
3. Activer **JavaScript** et **DOM storage / localStorage** dans la WebView. Choisir une version récente d’Android System WebView. Pour un emballage Android personnalisé, WebViewAssetLoader permet de servir les assets de l’application depuis une origine locale stable. La documentation Android est indiquée plus bas.
4. Donner à l’application un identifiant de paquet stable. Pour une mise à jour, conserver cet identifiant, la signature et l’origine de chargement. Exporter les données avant une désinstallation ou un changement de convertisseur.
5. Générer l’APK. Pour la recette sur le téléphone, activer le mode avion avant le premier lancement. Ouvrir un cours, terminer cinq réponses, saisir une note puis fermer et rouvrir l’application. Vérifier aussi l’export et la restauration avant d’y transférer un carnet important.

### Si la WebView limite les fichiers

L’export propose le téléchargement du JSON et sa sélection intégrale. Si le convertisseur ignore le téléchargement, appuyer sur **Sélectionner le texte**, utiliser **Copier** dans le menu Android, puis coller dans un fichier texte UTF-8 à extension .json. À l’import, **coller directement** le texte dans Profil fonctionne aussi sans sélecteur de fichiers. Les confirmations de l’application sont intégrées à l’interface HTML.

Si le stockage persistant est bloqué ou plein, un bandeau indique le mode temporaire. Les nouvelles données sont alors en mémoire jusqu’à la fermeture. Les exporter avant de quitter. Le fonctionnement exact du sélecteur de fichiers, des téléchargements et de la conservation des données dépend de l’APK hôte. Le ZIP livré est le projet web à convertir.

## Utiliser le carnet

Dans **Moyennes**, choisir le trimestre puis **Ajouter une note**. Un changement de date dans le formulaire présélectionne le trimestre d’après les dates définies dans Profil. Le trimestre reste modifiable à la main. Les dates initiales sont des propositions à adapter au calendrier du lycée.

- Chaque évaluation vaut 20 × note / barème. Sa contribution est pondérée par son coefficient.
- En spécialité physique-chimie et mathématiques, choisir la branche pour chaque évaluation. Par défaut, le calcul utilise toutes les notes de cette matière ensemble. Le mode alternatif calcule d’abord les deux moyennes de branche et les combine avec leurs poids. Les branches vides sont ignorées.
- La moyenne générale utilise les moyennes des matières et les coefficients de bulletin. Une matière vide n’entre pas au dénominateur. Une note de zéro compte normalement. Les calculs utilisent la précision complète, l’affichage arrondit à deux décimales maximum.
- Pour grouper 2I2D et ITEC, ouvrir **Profil → Regroupements et trimestres**. Leurs coefficients de matière servent de poids internes. Le groupe a son propre coefficient dans le bulletin. Les mathématiques communes restent distinctes.
- La vue annuelle calcule la moyenne simple des trimestres renseignés. Pour la moyenne générale annuelle, elle part des trois moyennes générales trimestrielles. Cette convention est indiquée à l’écran.
- Un coefficient de bulletin nul exclut une matière du calcul. La masquer agit uniquement sur l’affichage et les recommandations. La supprimer efface ses évaluations après confirmation.
- La moyenne officielle Pronote s’applique à une matière ou à la moyenne générale d’un trimestre. Décocher l’option permet de retrouver immédiatement le calcul à partir des notes.
- Le simulateur évalue le résultat d’une prochaine note sur 20 et la note minimale nécessaire pour une cible de matière ou de moyenne générale. Le minimum est arrondi au centième supérieur. Rien n’est ajouté au carnet.

## Révisions et récompenses

**41 cours**, **231 questions de chapitre**, six familles d’interactions (choix multiples, vrai/faux, nombre, texte à compléter, associations et vocabulaire), deux études chronométrées de cinq questions et deux sujets blancs à rédiger avec barèmes détaillés.

L’application propose une question à la fois. La séance comporte cinq questions différentes. Le choix tient compte des résultats passés, des erreurs, de la difficulté et du temps écoulé depuis la dernière réponse. Un chapitre est considéré comme maîtrisé après cinq questions distinctes traitées et au moins 80 % de réussite sur ses dix dernières réponses disponibles. Un taux inférieur à 70 % signale un point faible. Ce sont des indicateurs de révision internes.

Les nombres acceptent point ou virgule. Saisir le nombre seul dans l’unité indiquée. Une tolérance absolue est attachée à chaque question numérique. Les champs de langue acceptent les différences de casse et d’espacement. Les accents restent significatifs. Les réponses libres des sujets longs sont à rédiger sur papier puis à autocorriger.

Chaque bonne réponse vaut 10 XP, avec 5 XP de plus à partir du niveau 4. Une séance complète vaut 20 XP, avec 5 XP supplémentaires pour un chapitre initialement faible. La première séance complète de la journée rapporte 10 XP et valide la date locale. Trois jours consécutifs rapportent 30 XP et trente jours 100 XP. Les badges obtenus aux seuils dépendent du record personnel. Le niveau vaut 1 + partie entière de la racine carrée de (XP / 100).

Le temps de révision mesuré correspond au temps visible passé à répondre. La lecture d’une fiche ou d’un corrigé et les périodes où l’application est en arrière-plan ne s’y ajoutent pas. Quitter un quiz conserve les réponses déjà validées. Le compteur de séance et la flamme exigent cinq réponses. Un sujet chronométré interrompu par le délai conserve le score réellement atteint sur cinq.

## Contenus disponibles et couverture

| Domaine | Contenu intégré |
| --- | --- |
| Mathématiques communes | Suites, dérivation et variations, exponentielles et logarithme décimal, probabilités et loi binomiale, ajustement affine, algorithmique |
| Spécialité PCM | Énergie, rendement, thermique, cinématique, forces, changements d’état, signaux, électricité, acides et bases, mesures, primitives et intégrales, équations différentielles, complexes |
| 2I2D et ITEC | Transmissions, commande, capteurs, cahier des charges, simulation, tolérances, CAO, fabrication additive, analyse du cycle de vie, choix de matériaux et traction |
| ETLV, anglais et espagnol | Présentation d’une chaîne hydrogène, comparaison énergétique, compréhension écrite, passé et présent, reformulation, description orale d’une œuvre et métissages |
| Philosophie | Les sept notions de la voie technologique, regroupées en quatre fiches thématiques, et une fiche de méthode sur la dissertation et l’explication |
| Histoire-géographie et EMC | France de la Seconde Guerre mondiale, puissances depuis 1945, démocratie française, espaces maritimes, délibération et pluralisme |
| EPS et français anticipé | Carnet, objectif EPS et saisie des résultats anticipés |

Le sommaire de Révisions distingue les fiches ouvertes des repères encore à développer. La couverture reste partielle, notamment pour les réseaux, certains procédés de fabrication, les transformations chimiques, les situations expérimentales, les autres études de cas en géographie et les séquences culturelles complètes en langues. L’audio et l’évaluation automatique de la prise de parole restent à développer. Les manipulations en laboratoire et en CAO se préparent avec les fiches, les études de cas et les consignes de l’enseignant.

Les intégrales sont placées dans la composante mathématique de spécialité. Travail, conscience, bonheur, devoir et langage sont des pistes de réflexion liées aux notions de philosophie de la voie technologique. Les entrées en vigueur de 2026 en langues vivantes et en EMC sont prises en compte. Le programme commun de mathématiques de terminale applicable à cette cohorte reste celui de 2019.

## Bac 2027

Le simulateur est réglé pour un candidat scolaire sans enseignements optionnels. Les coefficients obligatoires totalisent 100. Le contrôle continu compte pour 40, les anticipées pour 12 et les autres épreuves terminales pour 48. En 2I2D, l’écrit vaut 9 et la pratique 7. Les résultats du bulletin, les entraînements et les notes saisies pour le bac sont indépendants.

Indiquer **Connue** pour un résultat déjà obtenu et **Estimée** pour une hypothèse. Les points connus et projetés sont affichés séparément. Jusqu’à ce que les 100 coefficients soient renseignés, la moyenne affichée est partielle. Les seuils de 1 000, 1 200, 1 400 et 1 600 points correspondent respectivement à l’admission et aux mentions assez bien, bien et très bien. Les calculs ne simulent pas de décision de jury, de dispense ou d’options.

Les deux sujets à rédiger sont des créations pour cet outil. Les réponses sont travaillées sur papier, puis évaluées avec le barème. Le total enregistré est identifié comme autoévaluation. Les deux études courtes chronométrées proposent une correction automatique. Les exemples de préparation au Grand oral et à la pratique ITEC sont accessibles dans le même onglet.

## Sauvegardes et architecture

Profil exporte et importe le JSON version 3. La restauration vérifie notamment les identifiants, les coefficients, les champs numériques, les dates, les liens entre matières et notes, les bornes des scores et les trimestres. Un import invalide laisse les données existantes en place. Une sauvegarde V3 illisible détectée au démarrage peut être exportée brute avant récupération.

Les exports de la première application « sti2d-revision-web » sont reconnus. Le premier format n’enregistrait pas les dates d’évaluation, le trimestre ni la branche de spécialité. Le formulaire de reprise demande comment classer les notes. L’ancien total de réussites et les dates d’activité sont archivés séparément, sans produire de nouvelles flammes. Une ancienne sauvegarde accessible à la même origine peut aussi être reprise depuis Profil.

- **index.html, style.css, icons/** — interface et ressources embarquées.
- **model.js** — données par défaut, coefficients, calculs, séries et validation.
- **app.js** — navigation, sauvegarde et tableau de bord.
- **carnet.js, revision.js, profil.js, migration.js, dossiers.js** — écrans et opérations métier.
- **data/cours.js** — tableau JSON compact dans un script local classique. Cette enveloppe évite les restrictions de chargement de JSON par fetch en ouverture locale.
- **data/bac.js, data/dossiers.js** — repères, études chronométrées et sujets à rédiger.

Pour ajouter un chapitre, conserver l’identifiant des chapitres existants, donner un identifiant unique au nouveau cours et choisir une matière. Ajouter les sections de cours et au moins cinq questions. Pour préserver l’historique, ajouter les questions en fin de liste et conserver l’ordre des anciennes. Les questions numériques définissent une valeur attendue et une tolérance absolue. Les questions de choix ont une clé textuelle et les propositions sont mélangées à l’affichage. Les données de progression sont indépendantes des fichiers pédagogiques.

## Références de programme et d’épreuves

Références consultées le 23 novembre 2026. Ces liens sont documentaires et facultatifs pour utiliser l’application.

- [Éduscol — coefficients du bac STI2D](https://eduscol.education.gouv.fr/5640/baccalaureat-technologique-serie-sciences-et-technologies-de-l-industrie-et-du-developpement-durable-sti2d)
- [BO du 17 septembre 2026 — épreuves terminales STI2D](https://www.education.gouv.fr/bo/2026/Hebdo4/MENE2622646N)
- [BO du 8 octobre 2026 — épreuve pratique 2I2D](https://www.education.gouv.fr/bo/2026/Hebdo38/MENE2624111N)
- [Éduscol — mathématiques et calendrier des programmes](https://eduscol.education.gouv.fr/5817/programmes-et-ressources-en-mathematiques-voie-gt)
- [Programme de spécialité physique-chimie et mathématiques de terminale STI2D](https://eduscol.education.gouv.fr/sites/default/files/document/spe261annexe1158935pdf-84513.pdf)
- [Éduscol — enseignements technologiques STI2D](https://eduscol.education.gouv.fr/5856/programmes-et-ressources-en-serie-sti2d)
- [Éduscol — langues vivantes](https://eduscol.education.gouv.fr/5811/programmes-et-ressources-en-langues-vivantes-voie-gt)
- [Programme de philosophie de la voie technologique](https://eduscol.education.gouv.fr/sites/default/files/document/spe238annexe21159161pdf-83643.pdf)
- [Éduscol — histoire-géographie](https://eduscol.education.gouv.fr/5799/programmes-et-ressources-en-histoire-geographie-voie-gt)
- [Éduscol — enseignement moral et civique](https://eduscol.education.gouv.fr/5787/programmes-et-ressources-en-enseignement-moral-et-civique-voie-gt)
- [Android Developers — charger les ressources locales](https://developer.android.com/develop/ui/views/layout/webapps/load-local-content)

