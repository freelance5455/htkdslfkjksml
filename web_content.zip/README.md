# GuitarMaster Pro — programme bilingue

Projet Android WebView avec interface rose/blanc et contenu pédagogique original en français et malagasy.

## Contenu
- Parcours de 4 niveaux : Débutant, Intermédiaire, Avancé, Professionnel.
- Bibliothèque de leçons bilingues disponible hors ligne : accords, intervalles, gammes majeures/mineures et pentatoniques, 12 tonalités, transposition, CAGED, alternate picking, fingerstyle P-I-M-A, techniques de solo, oreille, harmonie et rythme.
- Exercices pratiques, minuterie, métronome, progression et historique local.
- Liste de morceaux d’étude avec accords simplifiés et objectifs.
- Liens de recherche YouTube pour trouver des démonstrations vidéo (connexion Internet requise).
- Manuel PDF de progression.
- Pont Android prévu pour le rappel quotidien à 18:30. Le rappel doit être testé sur un APK installé et dépend des permissions Android.

## Compilation
Ouvrir dans Android Studio ou utiliser le workflow GitHub Actions `Build GuitarMaster Pro APK`.

## Notes
Les leçons intégrées sont des explications et exercices originaux. Les liens vidéo sont des recherches YouTube, pas des vidéos embarquées ; il faut Internet pour les regarder. Le projet n'a pas été compilé ni testé sur un téléphone dans cette mise à jour.


Paramètres ajoutés : choix de langue des leçons (français, malagasy ou bilingue), taille du texte 14–22 px, mode jour/nuit et réinitialisation des préférences. Les préférences sont conservées localement dans le navigateur/WebView.
