# Cast Reader APK project

Builds the Cast Reader web app into an Android APK using Capacitor.
The app is in www/index.html. No Android Studio needed: GitHub builds it for free.

## Steps (easiest on a computer)
1. Make a free account at github.com and create a new repository (public or private).
2. Upload everything in this folder, keeping the folders: www/, .github/workflows/build.yml,
   package.json, capacitor.config.json, .gitignore.
   (On a phone, use Add file > Create new file, type the path .github/workflows/build.yml
   as the name, and paste the file contents. Repeat for each file.)
3. Open the Actions tab, pick "Build APK", tap Run workflow, and wait about 5 to 8 minutes.
4. Open the finished run, download the artifact "cast-reader-apk", unzip it,
   and install app-debug.apk on your Android phone (allow "install unknown apps" when asked).

## Voices from other TTS apps
The app includes a small native plugin (native/NativeTTSPlugin.java). On Android it lists every
text-to-speech engine installed on the phone in an engine dropdown and reads each engine's voices directly.
The workflow copies the plugin into the Android project automatically, so keep the native/ folder in the repo.

## Notes
- The first AI voice load downloads about 90 MB and needs internet.
- This is a debug APK for your own phone, not for the Play Store.
- To update the app later, replace www/index.html and run the workflow again.
