# World Audio Studio 4.1 (hybrid)

- `app/src/main/assets/index.html` is the whole screen: player, Studio sliders and a System tab.
- Native Java code (no third-party libraries) attaches EQ, virtualizer and loudness effects to audio
  sessions that other apps announce to Android, while the System tab's service is running.
- Limits: only apps that announce their audio session are affected; room ambience and width below
  100% apply only to audio played inside this app.

Build: push this folder to GitHub and run Actions -> Build APK, or `./gradlew :app:assembleDebug`.
