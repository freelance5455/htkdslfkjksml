# Mataimaki · Assistant — Online AI Project

This ZIP combines the Mataimaki Assistant chat interface with a Node.js server that calls the OpenAI Responses API. The supplied HTML AI guide is included as `HTML_AI_GUIDE.html` for reference.

## Important: what works, and what you need

- The app is designed for online AI responses in English and Hausa.
- **You must provide your own API key on the server** and deploy/run the server. The key is not included in this ZIP.
- Opening `public/index.html` directly as a local file will not activate online AI. Open the app through the running server or your deployed website.
- API usage may cost money and is separate from a ChatGPT subscription. Check API pricing and usage limits before using it.
- The app stores recent chat history in the browser on that device. It is not cloud-synced across devices.

## Run it on a computer

1. Install Node.js 20 or newer.
2. Extract the ZIP.
3. Open a terminal inside the extracted project folder.
4. Copy `.env.example` to a new file named `.env`.
5. Open `.env` and replace `put_your_api_key_here` with your own API key. Keep this file private.
6. Run `npm install`.
7. Run `npm start`.
8. Open `http://localhost:3000` in a browser.

Do not send your API key in chat or put it in the HTML/JavaScript frontend.

## Put it online

Deploy the whole project folder to a Node.js hosting service that supports environment variables. Set:
- `OPENAI_API_KEY` = your secret API key (use the hosting dashboard's environment-variable/secret settings)
- `OPENAI_MODEL` = `gpt-5.5` (or another model available to your API account)
- Build/install command: `npm install`
- Start command: `npm start`

After deployment, open the public HTTPS website address from the hosting provider. The server and API key must stay on the hosting service; do not put the key in the browser.

## How the app works

1. You type a message in the website.
2. The browser sends the message and recent conversation context to `/api/chat` on this project's server.
3. The server reads `OPENAI_API_KEY` from its private environment and sends the request to the OpenAI Responses API.
4. The AI's reply is returned to the browser and shown in the chat.
5. Recent messages are saved in browser local storage to help with follow-up questions on the same device.

## Common problems

- **“Server not connected”**: you opened the HTML file directly or the server is not running; use the server URL.
- **“API key needed”**: configure `OPENAI_API_KEY` in `.env` or the hosting dashboard, then restart/redeploy.
- **API key rejected**: check the key on the server and replace it if exposed.
- **Limit/billing message**: the API account may have reached a usage limit or may not have billing/credits available.
- **Model error**: set `OPENAI_MODEL` to a model your API account can access.

## Included files

- `public/index.html` — Mataimaki Assistant chat interface.
- `server.js` — secure server endpoint that calls the AI API.
- `package.json` — project dependencies and start command.
- `.env.example` — environment-variable template (not a real key).
- `HTML_AI_GUIDE.html` — the HTML AI guide you supplied.

Official reference: OpenAI API quickstart — https://developers.openai.com/api/docs/quickstart
