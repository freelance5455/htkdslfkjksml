# Smart v10 — Unified AI Phone Agent

This project merges the distinct useful pieces from the previous Smart ZIP generations into one native Android project. Duplicate/obsolete build configurations were not blindly copied because they would conflict with the working native project.

## Included
- ChatGPT-style Smart chat UI and left menu
- Voice command button
- Background foreground voice service
- Floating Smart button/overlay
- “Hey Smart” phrase detection through Android SpeechRecognizer
- Spoken responses with Android Text-to-Speech
- Open installed apps (including WhatsApp, Facebook, Instagram, YouTube, Chrome, Telegram, Gmail, Maps, TikTok and app-name discovery)
- Web search and websites
- Contact lookup and calling/dialer fallback
- SMS composer with user review
- Back/Home/Recents/Notifications/Quick Settings via Accessibility
- Scroll and gesture control foundation
- Screenshot capture through Accessibility on Android 11+
- Camera, Wi-Fi, Bluetooth, Settings, alarm and timer
- Notification listener foundation
- Gesture Mode
- Smart Pro / free-usage and Google Play Billing module from the commercial project
- Configurable AI backend client (no API key embedded in the APK)
- Backend, web companion, database schemas and commercial documentation
- GitHub Actions Android build workflow
- Smart logo asset

## Important
“Hey Smart” is implemented using Android SpeechRecognizer in a foreground microphone service. It is not a dedicated offline hotword engine and Android/device battery/privacy policies can interrupt continuous recognition. The floating button requires overlay permission. Phone-wide UI control requires Accessibility permission. Android security protections cannot be bypassed.

The commercial backend still needs a real HTTPS deployment and its environment variables before cloud AI works. Google Play subscriptions need products configured in Play Console and secure purchase verification before Pro access is granted.

## Build
Upload the project contents to GitHub and run the included `.github/workflows/android-build.yml` workflow. The workflow builds a debug APK artifact.


## Smart Chat
The native Smart app includes a ChatGPT-style chat area with message bubbles, new-chat control, quick prompts, text input, and voice input. Phone commands are routed to the native command engine. Connecting `SmartAiClient` to a deployed AI backend enables open-ended AI responses.

## Smart 10.3 UI note
The web companion now has a visible MENU button and a complete feature drawer. The native Android app also has an Everything Smart can do panel. The browser preview is only a UI/demo and cannot perform native phone actions; those require the native Android build plus the required Android permissions.
