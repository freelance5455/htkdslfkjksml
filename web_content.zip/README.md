# ZIYAUL EDITING V9 — Android editor project

V9 changes:
- Professional dark editor styling and card/timeline polish.
- Timeline clips can be dragged left/right to reorder.
- A selected clip can be removed with Delete button (or keyboard Delete where supported).
- New media inserted after the currently selected clip, so another video can be placed immediately after a video.
- Multiple media can be added in one selection.
- Horizontal timeline remains the main editing area.

Important: drag/reorder is implemented in the WebView UI. For a production-grade editor, native Media3/FFmpeg timeline editing should be added for frame-accurate trimming, transitions and permanent MP4 rendering.
