# ELECTRICAL HUB INC. Job Manager

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/ELECTRICAL-HUB-INC/pen/01a14f0b-23e7-72e2-b859-ae29bce2505a](https://codepen.io/editor/ELECTRICAL-HUB-INC/pen/01a14f0b-23e7-72e2-b859-ae29bce2505a).

