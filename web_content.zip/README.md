# AgentBase workspace export

An export of an AgentBase workspace: every app's source and named queries, the
table schema, the sidebar layout, and the platform runtime the apps run on. It
contains **no credentials**, and **no rows** unless you exported with sample
rows (at most 200 per table, in `sample-data.json`).

## Quickstart

```bash
npx serve .
```

Open `http://localhost:3000/dev/host.html`, then pick an app from the list (or
open `dev/host.html#app=<app_id>`).

To change an app, edit `apps/<app_id>/src/` and `apps/<app_id>/queries.json`
and reload the page. `AGENTS.md` has the rules for AI coding tools (Cursor,
Claude Code, Codex).

## What is in here

| Path | What |
|---|---|
| `apps/<app_id>/src/` | The app's files exactly as stored (no platform code injected) |
| `apps/<app_id>/queries.json` | Named queries the app calls through `window.agentdb.executeQuery` |
| `apps/<app_id>/app.json` | Name, scope, bound table, entry file, version |
| `schema.sql` | PostgreSQL DDL for the workspace tables (names unqualified) |
| `schema.json` | The same tables, structured; `dev/host.js` builds its local database from it |
| `sample-data.json` | Sample rows as PostgreSQL text values (only if exported with sample rows) |
| `layout.json` | Sidebar and view configuration |
| `runtime/` | Platform code: Bridge SDK, dashboard kit, theme. Do not edit |
| `dev/` | The local host page. Do not edit |
| `manifest.json` | Format version, runtime version, app list, anything skipped |

If `manifest.json` lists entries under `skipped`, those apps (or files) could
not be read when the export was made.

## How the local host works

`dev/host.html` stands in for the AgentBase app viewer. For the selected app it:

1. fetches `src/<entry_file>` and inlines the app's own relative scripts,
   stylesheets and images (the sandboxed frame cannot fetch them itself);
2. injects the runtime the same way the platform does — Bridge SDK, export
   guard, theme, dashboard kit, workspace palette, chart fixes;
3. loads the result into `<iframe sandbox="allow-scripts allow-popups allow-forms">`;
4. answers the app's bridge requests (`executeQuery`, `getSchema`, `getAppInfo`)
   from an in-browser PostgreSQL ([PGlite](https://pglite.dev/), about 3 MB,
   loaded from jsdelivr on first open) built from `schema.sql` and
   `sample-data.json`.

The queries run exactly as written — it is Postgres, not a translation — and
results come back in the shape AgentBase sends them (dates and timestamps as
ISO strings, `numeric` as numbers, `json` / `jsonb` as strings). Mutations run
against that local database only; nothing reaches AgentBase, and reloading the
page resets it.

Sample rows are the newest (highest primary key) up to 200 per table, so a
query that needs older rows, or rows a capped table left out, returns less
than it does in AgentBase. Rows are loaded with foreign-key checks off, since
a sampled child row may point at a parent that was not sampled.

To load the schema into your own Postgres instead:

```bash
docker run -d --name agentbase-pg -e POSTGRES_PASSWORD=dev -p 5432:5432 postgres:17
psql postgresql://postgres:dev@localhost:5432/postgres -f schema.sql
```

`schema.sql` creates foreign keys after the tables, so sample rows can be
loaded in between.

## Debugging

The host's **Console** button shows the app's captured console output (the
same buffer AgentBase reads with `getConsoleLogs`). From the browser console,
`agentdbHost.command('executeJs', { code: 'document.title' })` runs code in the
app frame.
