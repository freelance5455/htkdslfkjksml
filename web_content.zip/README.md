# Word Hunt Android Project

This is an Android Studio project.

IMPORTANT:
The HTML game is NOT at the project root.
The correct location is:

app/src/main/assets/index.html

The Android app loads it with:
file:///android_asset/index.html

Open the project root (the folder containing settings.gradle and the app folder) in Android Studio.
