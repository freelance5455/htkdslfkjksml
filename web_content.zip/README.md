# NovaBrowser

Кроссплатформенный браузер с ИИ-ассистентом **Nova AI**. Один код UI (Next.js/React) работает:

| Платформа | Оболочка | Движок рендеринга |
|---|---|---|
| Web / PWA | браузер пользователя | Nova Proxy (серверный рендер страниц в sandbox-iframe) |
| Windows / macOS / Linux | **Electron** (`desktop/`) | Chromium (Electron, `<webview>`, сетевая блокировка трекеров) |
| Android / iOS | **Capacitor** (`mobile/`) | Chromium WebView / WKWebView |

## 1. Структура проекта

```
NovaBrowser/
├── src/
│   ├── app/
│   │   ├── layout.tsx                 # корневой layout, тема до гидрации, PWA-мета
│   │   ├── page.tsx                   # точка входа → <Browser/>
│   │   ├── globals.css                # Tailwind v4, dark-вариант по классу, стили Markdown
│   │   └── api/
│   │       ├── proxy/route.ts         # ★ Nova Proxy: загрузка страниц, перепись HTML, блок трекеров, кодировки, SSRF-защита
│   │       ├── suggest/route.ts       # автодополнение: история + закладки + Google/Yandex Suggest
│   │       ├── search/route.ts        # веб-поиск (Google CSE / Yandex XML / DDG / Bing / Wikipedia)
│   │       ├── page-text/route.ts     # извлечение текста страницы для ИИ
│   │       ├── ai/chat/route.ts       # ★ Nova AI: RAG с веб-поиском, суммаризация, перевод, код, анализ вкладок
│   │       ├── ai/providers/route.ts  # какие провайдеры настроены
│   │       ├── ai/conversations/      # история диалогов (список / сообщения / удаление)
│   │       ├── history/route.ts       # история просмотров
│   │       ├── bookmarks/route.ts     # закладки (toggle)
│   │       ├── downloads/route.ts     # менеджер загрузок
│   │       ├── downloads/file/route.ts# скачивание через сервер с записью в менеджер
│   │       ├── sync/route.ts          # аккаунт синхронизации (sync-код)
│   │       └── health/route.ts
│   ├── components/
│   │   ├── Browser.tsx                # ★ оболочка: вкладки, навигация, hotkeys, жесты, усыпление вкладок
│   │   ├── AddressBar.tsx             # адресная строка, автодополнение, выбор поисковика, голос
│   │   ├── TabBar.tsx                 # вкладки (ПК)
│   │   ├── HomePage.tsx               # nova://home — поиск, speed-dial, недавние
│   │   ├── AIChat.tsx                 # боковая панель Nova AI (чат, голос, TTS, история)
│   │   ├── Panels.tsx                 # история / закладки / загрузки / настройки / расширения / синхронизация
│   │   └── ui.tsx                     # иконки, кнопки, Markdown-рендер
│   ├── lib/
│   │   ├── browser.ts                 # поисковые системы, нормализация ввода, список трекеров
│   │   ├── websearch.ts               # поисковые провайдеры для ИИ
│   │   ├── ai.ts                      # OpenAI / Gemini / YandexGPT / автономный режим
│   │   └── store.ts                   # типы Tab/Settings, localStorage, тема
│   └── db/
│       ├── schema.ts                  # Drizzle: profiles, history, bookmarks, downloads, conversations, messages
│       └── index.ts
├── desktop/
│   ├── main.cjs                       # Electron main: окно, webview, сетевой блок трекеров, загрузки, HTTPS
│   ├── preload.cjs                    # безопасный IPC-мост
│   └── electron-builder.yml           # сборка Win/macOS/Linux
├── mobile/
│   ├── capacitor.config.json          # Android/iOS
│   └── www/index.html
├── public/manifest.webmanifest, icon.svg   # PWA
├── .env.example                       # все ключи API
└── drizzle.config.json
```

## 2. Как это работает

**Загрузка страниц (веб-режим).** `/api/proxy?url=` скачивает страницу, определяет кодировку (utf-8/windows-1251…), вырезает CSP/X-Frame-Options, вставляет `<base>` и скрипт-мост, который перехватывает клики по ссылкам, GET-формы, `window.open`, свайпы и горячие клавиши и передаёт их оболочке через `postMessage`. Трекер-скрипты (`doubleclick`, `mc.yandex`, `googletagmanager`, `fbq`, …) вырезаются из HTML — счётчик показывается в адресной строке (🛡). В Electron вместо прокси используется нативный Chromium с блокировкой трекеров через `webRequest`.

**Nova AI.** Запрос → веб-поиск в реальном времени (Google CSE → Yandex Search API → DuckDuckGo → Bing → Wikipedia) → контекст страницы (текст берётся прямо из открытого iframe или через `/api/page-text`) → LLM (OpenAI / Gemini / YandexGPT). Без единого ключа работает **автономный режим**: экстрактивная суммаризация и ответ из найденных источников. Все диалоги сохраняются в PostgreSQL.

**Безопасность.** sandbox-iframe, SSRF-фильтр (локальные адреса запрещены), индикатор HTTPS 🔒/🔓, режим «Только HTTPS», приватные вкладки (не пишут историю и не сохраняются), блокировка `serviceWorker.register` внутри страниц.

**Память.** Неактивные вкладки через 10 минут «засыпают» (iframe выгружается, состояние хранится), и восстанавливаются при переключении.

**Горячие клавиши.** `Ctrl+T` новая вкладка, `Ctrl+Shift+N` приватная, `Ctrl+W` закрыть, `Ctrl+L` адрес, `Ctrl+D` закладка, `Ctrl+R` обновить, `Ctrl+K` Nova AI, `Ctrl+H` история, `Ctrl+J` загрузки, `Ctrl+Tab` переключение, `Alt+←/→` назад/вперёд. В адресной строке: `g запрос` — Google, `y запрос` — Яндекс.

## 3. Сборка

### Сервер / Web / PWA
```bash
cp .env.example .env            # заполните DATABASE_URL и ключи
npm install
npx drizzle-kit push            # создать таблицы
npm run dev                     # http://localhost:3000
npm run build && npm start      # production
```
PWA: на телефоне откройте адрес сервера → «Добавить на главный экран».

### Windows / macOS / Linux (Electron)
```bash
npm install -D electron electron-builder
# скрипты в package.json:
#   "desktop": "electron desktop/main.cjs",
#   "desktop:build": "electron-builder --config desktop/electron-builder.yml"
NOVA_APP_URL=https://ваш-сервер.ru npm run desktop            # запуск
npm run desktop:build -- --win nsis portable                  # Windows (.exe)
npm run desktop:build -- --mac dmg                            # macOS (.dmg), нужен macOS + Xcode CLT; подпись: CSC_LINK/CSC_KEY_PASSWORD
npm run desktop:build -- --linux AppImage deb rpm             # Linux
```
Готовые пакеты появятся в `dist-desktop/`. Для автономной работы без внешнего сервера упакуйте Next.js standalone-сборку (`output: "standalone"` в `next.config.ts`) и запускайте её из `main.cjs` дочерним процессом перед `loadURL`.

### Android (Capacitor)
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
# в mobile/capacitor.config.json укажите server.url = адрес вашего сервера (HTTPS)
npx cap init NovaBrowser app.novabrowser.mobile --web-dir mobile/www --config mobile/capacitor.config.json
npx cap add android
npx cap sync android
npx cap open android      # Android Studio → Build → Generate Signed Bundle/APK
# CLI: cd android && ./gradlew assembleRelease   → android/app/build/outputs/apk/release/
```
Требования: Android Studio, JDK 17, SDK 34. Для публикации в Google Play подпишите AAB keystore-файлом.

### iOS (Capacitor)
```bash
npm install @capacitor/ios
npx cap add ios
npx cap sync ios
npx cap open ios          # Xcode → выберите Team (Apple Developer) → Product → Archive → Distribute
```
Требования: macOS, Xcode 15+, CocoaPods (`sudo gem install cocoapods`), аккаунт Apple Developer для установки на устройство/App Store.

Жесты (свайп от края назад/вперёд), нижняя панель навигации, переключатель вкладок и полноэкранная панель ИИ включаются автоматически на экранах < 640px.

## 4. Подключение API

Все ключи — в `.env` (сервер). В браузер они не попадают: все внешние вызовы идут через `src/app/api/*`.

### ИИ-провайдеры (нужен любой один)
| Провайдер | Переменные | Где взять |
|---|---|---|
| OpenAI (и совместимые: OpenRouter, Groq, Ollama/LM Studio) | `OPENAI_API_KEY`, `OPENAI_MODEL`, `OPENAI_BASE_URL` | platform.openai.com/api-keys |
| Google Gemini | `GEMINI_API_KEY`, `GEMINI_MODEL` | aistudio.google.com/app/apikey |
| YandexGPT | `YANDEX_GPT_API_KEY`, `YANDEX_FOLDER_ID`, `YANDEX_GPT_MODEL` | console.cloud.yandex.ru → сервисный аккаунт → роль `ai.languageModels.user` → API-ключ; Folder ID — в карточке каталога |

`AI_PROVIDER=auto` выбирает первый настроенный; пользователь может переключить провайдера в Настройках → Nova AI.

### Поиск для ИИ (опционально, без ключей работают DDG/Bing/Wikipedia)
| Система | Переменные | Как получить |
|---|---|---|
| Google | `GOOGLE_SEARCH_API_KEY`, `GOOGLE_SEARCH_CX` | 1) programmablesearchengine.google.com → создать поисковик «Весь интернет» → скопировать **cx**; 2) console.cloud.google.com → включить **Custom Search API** → создать API-ключ. 100 запросов/день бесплатно |
| Яндекс | `YANDEX_SEARCH_API_KEY`, `YANDEX_FOLDER_ID` | cloud.yandex.ru/services/search-api → подключить Search API к каталогу → сервисный аккаунт с ролью `search-api.webSearch.user` → API-ключ |

### Поисковые системы адресной строки
Настраиваются в `src/lib/browser.ts` (`SEARCH_ENGINES`): Google (по умолчанию), Яндекс, DuckDuckGo, Bing. Добавить свою — одна запись в объект. Подсказки берутся из `suggestqueries.google.com` / `suggest.yandex.ru` плюс локальные история и закладки.

### Синхронизация между устройствами
Настройки → Аккаунт → «Создать аккаунт синхронизации». Генерируется код вида `XXXX-XXXX-XXXX`; ввод кода на другом устройстве объединяет историю, закладки, загрузки, диалоги ИИ и настройки (хранятся в PostgreSQL, таблица `profiles`).
