# OpenBuilder — Lovable-style starter

This is an original, lightweight Lovable-style AI website-builder UI starter. It is NOT a copy of Lovable's proprietary code, branding, backend, or services.

## Included
- Project sidebar
- Prompt-to-project UI
- Responsive preview
- One-click deployment UI
- Hosting/project controls
- Vite + React

## Run
1. Install Node.js 18+.
2. `npm install`
3. `npm run dev`

## Important
The "Generate" and "Deploy" buttons are front-end demos. Real AI generation, authentication, persistent project storage, custom-domain DNS, and unlimited hosting require backend/infrastructure integrations.

A truly free custom domain is generally not something an app can guarantee: domain registration itself normally costs money. You can support free subdomains (for example, project.your-builder.example) and let users connect domains they already own.
