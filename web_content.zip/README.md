# FF Panel v2
ไฟล์นี้ประกอบด้วย:
- index.html: หน้า panel + Aim Trainer สำหรับสนามฝึก
- server.js: API Key binding แบบ 1 Key ต่อ 1 device
- package.json: dependencies สำหรับ API

Normal มีตัวอย่าง 10 keys; Premium มีตัวอย่าง 3 keys.
เปลี่ยน example keys และ ADMIN_TOKEN ก่อนใช้งานจริง

Aim Trainer ไม่อ่านหรือแก้หน่วยความจำ/ทราฟฟิกของ Free Fire
ไม่มี anti-ban, anti-cheat bypass, inject หรือการล็อกหัวจริงในเกม
