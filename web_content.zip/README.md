# UrbaAlerte — Application citoyenne (Kinshasa · Mont-Ngafula)

Application mobile de signalement des incidents urbains, issue du mémoire (côté citoyens).
**Fichier d'entrée : `index.html` à la racine** — tout est en chemins relatifs, sans dépendance externe ni CDN.

## Fonctionnalités
1. Inscription (nom complet, téléphone RDC, mot de passe)
2. Connexion (téléphone + mot de passe)
3. Signalement avec photo / vidéo (caméra ou galerie, 4 médias max) et description (≥ 20 caractères, 5 signalements/jour max)
4. Géolocalisation automatique (GPS) avec ajustement manuel du repère
5. Carte des incidents en temps réel (moteur de carte intégré, filtres par type)
6. Notifications de proximité dans un rayon de 5 km (réglable 1–10 km)
7. Alertes SMS en mode hors ligne (SMS pré-rempli, format compact)
8. Zones à risques (densité pondérée des signalements récents — **indicatif, non officiel**)
9. Historique des signalements avec suivi de statut
10. Profil et réglages

## Tester dans un navigateur
Servez le dossier en HTTP(S) (la géolocalisation et les notifications exigent un contexte sécurisé ; `localhost` convient) :
`python3 -m http.server 8080` puis ouvrez `http://localhost:8080` sur mobile/émulateur.
Ouvrir `index.html` directement par `file://` fonctionne pour l'interface, mais pas pour le service worker.

## Générer l'APK (3 voies)
**A. PWABuilder (le plus simple)** — hébergez le dossier en HTTPS (GitHub Pages, Netlify…), puis https://www.pwabuilder.com → Android → téléchargez l'APK/AAB.

**B. Capacitor (recommandé pour push et SMS natifs)**
```
npm init -y && npm i @capacitor/core @capacitor/cli @capacitor/android
npx cap init UrbaAlerte cd.urbaalerte.app --web-dir=.
npx cap add android
npx cap sync && npx cap open android      # Android Studio → Build > Build APK
```
Utilisez `assets/icons/adaptive-foreground-1024.png` et `adaptive-background-1024.png` pour l'icône adaptative, `icon-1024.png` pour le Play Store. Permissions Android à déclarer : `ACCESS_FINE_LOCATION`, `CAMERA`, `POST_NOTIFICATIONS`, `INTERNET`.

**C. Convertisseurs en ligne « HTML → APK »** (WebIntoApp, AppsGeyser…) : zippez le dossier tel quel ; `index.html` est à la racine.

## Ce qui est réel et ce qui est simulé (à lire)
- **Mode démo local (par défaut, `API_BASE` vide)** : comptes, signalements et médias sont stockés **sur l'appareil** (IndexedDB). Le mot de passe est haché (PBKDF2) mais ce n'est **pas** une authentification serveur.
- **Données DÉMO** : ~50 incidents fictifs (badge « DÉMO ») sont générés autour de la position de l'utilisateur au premier lancement. La « simulation de démonstration » ajoute de nouveaux incidents fictifs et fait avancer le statut de vos signalements (désactivable dans Profil).
- **Temps réel / notifications push** : en mode démo, les alertes sont déclenchées localement. Un **vrai** push en arrière-plan (app fermée) et le temps réel multi-utilisateurs nécessitent un backend (API + WebSocket/FCM) et le plugin `@capacitor/push-notifications`. L'adaptateur `js/api.js` prévoit les routes (`/api/auth/*`, `/api/incidents`, médias) à aligner sur l'API du mémoire ; il n'a **pas** été testé face à un serveur réel.
- **SMS** : l'application ouvre l'application SMS du téléphone avec le message pré-rempli (l'utilisateur appuie sur Envoyer). L'envoi silencieux demande un plugin natif. Renseignez le numéro de la passerelle dans `js/config.js` (`SMS_GATEWAY`) ou dans Profil ; la réception/traitement côté serveur est à développer.
- **Carte** : tuiles OpenStreetMap (internet requis ; sans réseau, grille hors ligne). L'usage des serveurs OSM publics est limité : en production, utilisez un fournisseur de tuiles adapté (`TILE_URL`). Le centre par défaut de Mont-Ngafula est **approximatif**.
- **Images** : les visuels de Mont-Ngafula fournis sont des **illustrations** générées (pas des photos). Déposez vos photos réelles dans `assets/photos/` (voir `LISEZMOI.txt`).
- **Zones à risques** : calcul statistique simple, à valider avec les services compétents avant tout usage opérationnel.

## Structure
`index.html` · `manifest.webmanifest` · `sw.js` · `css/` · `js/` (config, util, db, geo, api, risk, map, demo, app, screens, report) · `assets/icons` (jeu d'icônes complet, maskable, adaptive) · `assets/anim` (splash radar SVG/GIF, loaders, onboarding) · `assets/illustrations` · `assets/fonts` (Inter, licence OFL) · `store/` (captures d’écran)
