# Taksi — online taksi tizimi
Uch qism: passenger.html, driver.html, admin.html.
Firebase Auth + Firestore, OpenStreetMap/Leaflet.
README asosidagi boshlang'ich ishlaydigan loyiha.
