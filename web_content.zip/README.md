# ScoreCastPro Studio — Guia de Publicação e Geração de APK

Este pacote contém os ficheiros prontos para alojar/publicar a aplicação web e empacotar num **APK Android** (`com.scorecastpro.studio`).

## Ficheiros incluídos
- `www/index.html` — Aplicação completa (720p/1080p, zoom 0.6x–5.0x à esquerda, ecrã inteiro com controlos diretos, destaques -15s/+15s, exemplo ao vivo e comando remoto via QR Code).
- `www/manifest.json` — Manifesto PWA para instalação e modo ecrã inteiro.
- `www/sw.js` — Service Worker para cache e arranque rápido.
- `capacitor.config.json` — Configuração base para empacotamento Android via Capacitor.

## Passo 1: Publicar na Web (HTTPS)
Para o acesso à câmara, microfone e ligação WebRTC/QR Code funcionarem sem bloqueios no telemóvel, publica a pasta `www/` num serviço HTTPS (por exemplo: **GitHub Pages**, **Netlify**, **Vercel** ou **Cloudflare Pages**).

## Passo 2: Gerar o APK com PWABuilder ou Capacitor

### Opção A — Mais rápida (PWABuilder)
1. Publica a pasta `www/` numa URL `https://...`.
2. Abre o [PWABuilder](https://www.pwabuilder.com/) e cola a URL publicada.
3. Escolhe **Android** e descarrega o pacote/APK gerado.

### Opção B — Local com Capacitor & Android Studio
1. Cria uma pasta de projeto e coloca `capacitor.config.json` na raiz e os ficheiros de `www/` dentro de `www/`.
2. No terminal:
   ```bash
   npm init -y
   npm install @capacitor/core @capacitor/cli @capacitor/android
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
3. No **Android Studio**, certifica-te de que o `AndroidManifest.xml` inclui as permissões de câmara e áudio (`CAMERA`, `RECORD_AUDIO`, `INTERNET`) e gera o APK em **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
