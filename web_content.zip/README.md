# Protwave

Select text, press your hotkey, see the result. Protwave has no window, no icon on screen and no mascot: it stays invisible and a small card appears next to your cursor only when you use it, then hides itself.

**What the card tells you**
- Token count and cost for the AI tool you use, plus the cheapest capable model (one-tap Switch).
- Reply-length and hidden-thinking forecast, agent-loop cost (context re-sent each step), and a cost range.
- Prompt shortener with a red/green diff and one-tap copy.
- Local secret/PII check (API keys, JWTs, private keys, emails, cards, SSNs) with a mask toggle.
- Files, folders and image-size estimates (tray menu > Analyze files, or drop onto the card).
- Currencies (USD, EUR, GBP, INR, JPY), custom models, budget guardrail, calibration with a measured-accuracy readout.

**Keyboard**: Enter = switch to the cheaper model, C = copy the shorter prompt, M = copy masked, D = diff, comma = settings, Esc = close. A thin bar at the top of the card shows when it will auto-hide; hovering pauses it.

**First run** is a short guided setup: welcome, a live demo of what you'll see, OS-specific unsigned-app help, hotkey choice and test, done.

**Accuracy extras**: besides input-token calibration, enter the real reply token count (settings) and Protwave learns reply length per kind of request, and shows a likely cost range that tightens as it learns.

**Transparency**: tap ⓘ on any result for "How this was calculated" (tokenizer used, ratios, reply forecast reasoning, price source and date, why a model was picked). "Privacy & data" shows a live network log, what is stored, export and erase. See PRIVACY.md.

**Speed & robustness**: the answer appears first and extras (shortener, secret scan, exact DeepSeek) fill in a moment later; tokenizer warms at launch; counting runs off the UI thread; huge selections are capped (1.5M chars counted, scans skipped over 300k); hotkey mashing is ignored while a capture runs; only one Protwave instance runs; clipboard is never cleared unless it held text.

**Cached agent loops**: turn on "Context is cached" in settings to price repeated context at the cache-read rate (Claude: 10%, verify with Anthropic); other providers have no discount applied until their rate is added to the ledger.

**Defaults**: hotkey Alt+Shift+T (rebindable; Ctrl/Cmd+Shift+T is offered in first-run setup but clashes with browsers' "reopen closed tab"). Auto-hides after 10 s. Starts at login if you allow it. The tray menu has Settings, Analyze files, Quit. On macOS there is no Dock icon.

**Privacy**: text is analyzed on your device and never sent anywhere. Optional, off by default: anonymous usage ping and in-app feedback (only if you configure Supabase in `src/config.js`). Price updates are accepted only if signed with your Ed25519 key.

**Accuracy**: real BPE tokenizer for OpenAI models (near-exact); optional exact DeepSeek via `src-tauri/tokenizers/deepseek.json`; Claude/Gemini/Muse are calibrated estimates because their tokenizers aren't public.
