# Personal Rizz Android Project

This is a native Android project wrapping the single-file Personal Rizz web app in an Android WebView.
Open the project in Android Studio and build the debug APK:
Build > Build Bundle(s) / APK(s) > Build APK(s).

The resulting APK is normally under app/build/outputs/apk/debug/app-debug.apk.
