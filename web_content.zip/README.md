# আল-ইনসাফ মানব কল্যাণ ফাউন্ডেশন (Al-Insaf Human Welfare Foundation)

**ঠিকানা:** মালতিপুর, পাথালিয়া, মুক্তাগাছা, মোমেনশাহী  
**লোগো ও ব্র্যান্ডিং:** ইসলামিক গ্রিন, সফট গোল্ড ও মার্জিত ৩ডি কার্ড ডিজাইন  
**প্ল্যাটফর্ম:** Vanilla HTML5, CSS3, JavaScript (ES6+), Firebase (Auth, Firestore, Storage) এবং Android Native App (Edge-to-Edge WebView)

---

## পূর্ণাঙ্গ সেটআপ ও ডিপ্লয়মেন্ট নির্দেশিকা (Setup & Deployment Manual)

### ১. কোন Firebase project তৈরি করতে হবে?
1. যান [Firebase Console](https://console.firebase.google.com/)-এ।
2. **"Add Project"**-এ ক্লিক করে প্রোজেক্টের নাম দিন (যেমনঃ `al-insaf-welfare`)।
3. Google Analytics ঐচ্ছিক, অন বা অফ রেখে **Create Project** চাপুন।

---

### ২. Firebase Authentication কীভাবে চালু করতে হবে?
1. Firebase Console-এ বাম পাশের মেনু থেকে **Build > Authentication**-এ যান।
2. **"Get Started"** ক্লিক করুন।
3. **Sign-in method** ট্যাবে গিয়ে **"Email/Password"** নির্বাচন করে **Enable** করুন এবং **Save** করুন।

---

### ৩. Cloud Firestore কীভাবে চালু করতে হবে?
1. বাম পাশের মেনু থেকে **Build > Firestore Database**-এ যান।
2. **"Create database"** চাপুন।
3. লোকেশন নির্বাচন করুন (যেমনঃ `asia-south1` - মুম্বাই বা নিকটস্থ রিজিয়ন)।
4. সিকিউরিটি রুলস হিসেবে **Start in production mode** সিলেক্ট করে **Create** করুন।
5. ডাটাবেজে নিচের কালেকশনগুলো স্বয়ংক্রিয়ভাবে ব্যবহৃত হবে:
   - `settings`, `directors`, `members`, `memberApplications`, `memberPayments`, `helpApplications`, `beneficiaries`, `activities`, `distributions`, `fundTransactions`, `expenses`, `donations`, `auditLogs`, `admins`

---

### ৪. Firebase Storage কীভাবে চালু করতে হবে?
1. বাম পাশের মেনু থেকে **Build > Storage**-এ যান।
2. **"Get Started"** ক্লিক করে প্রোডাকশন মোডে বালতি (bucket) তৈরি সম্পন্ন করুন।
3. ফোল্ডার রুলস অনুযায়ী স্বয়ংক্রিয়ভাবে নিম্নলিখিত ডিরেক্টরিগুলোতে ফাইল আপলোড হবে:
   - `/directors/`, `/members/`, `/applicants/`, `/beneficiaries/`, `/documents/`, `/receipts/`

---

### ৫. Super Admin কীভাবে তৈরি করবেন?
1. Firebase Console-এর **Authentication > Users** ট্যাবে যান।
2. **"Add user"** বাটনে ক্লিক করে সুপার এডমিনের ইমেইল ও পাসওয়ার্ড প্রদান করুন (যেমনঃ `jubairahmad8000@gmail.com`)।
3. ব্যবহারকারী তৈরির পর পাওয়া **User UID** কপি করুন।
4. Firestore Database-এ গিয়ে **`users`** কালেকশনের ভেতর ঐ ব্যবহারকারীর **`UID`**-কে Document ID হিসেবে দিয়ে ডকুমেন্ট তৈরি করুন:
   - Collection: `users`
   - Document ID: `<User UID>`
   - Fields:
     ```json
     {
       "name": "মুহাম্মদ যুবায়ের আহমদ",
       "email": "jubairahmad8000@gmail.com",
       "role": "super_admin"
     }
     ```
5. ওয়েবসাইট বা অ্যাপের লগইন মডালে গিয়ে ঐ ইমেইল ও পাসওয়ার্ড দিয়ে লগইন করলে সিস্টেম স্বয়ংক্রিয়ভাবে `users/{uid}` থেকে `role === "super_admin"` যাচাই করে সুপার এডমিন এক্সেস প্রদান করবে।

---

### ৬. Firebase config কোথায় বসাতে হবে?
`firebase-config.js` ফাইলের মধ্যে আপনার Firebase Web App ক্রেডেনশিয়াল বসিয়ে দিন:
```javascript
const FIREBASE_CONFIG_PLACEHOLDER = {
  apiKey: "আপনার_FIREBASE_API_KEY",
  authDomain: "আপনার_PROJECT_ID.firebaseapp.com",
  projectId: "আপনার_PROJECT_ID",
  storageBucket: "আপনার_PROJECT_ID.appspot.com",
  messagingSenderId: "আপনার_SENDER_ID",
  appId: "আপনার_APP_ID"
};
```
*অথবা*, এডমিন প্যানেলে লগইন করে সরাসরি ব্রাউজার থেকেও কনফিগারেশন আপডেট করা যায়।

---

### ৭. GitHub-এ কোন files upload করতে হবে?
GitHub Repository তৈরি করে রুট ফোল্ডারে নিচের ফাইলগুলো আপলোড করতে হবে:
```
/
├── index.html
├── style.css
├── code.js
├── firebase-config.js
├── firestore.rules
├── storage.rules
├── assets/
│   ├── logo/logo.png
│   └── icons/
└── README.md
```

---

### ৮. GitHub Pages কীভাবে চালু করতে হবে?
1. আপনার GitHub Repository-র **Settings** ট্যাবে যান।
2. বাম মেনুর **Pages** অপশনে ক্লিক করুন।
3. **Build and deployment > Source** থেকে **Deploy from a branch** নির্বাচন করুন।
4. Branch ড্রপডাউন থেকে `main` (বা `master`) এবং ফোল্ডার `/ (root)` সিলেক্ট করে **Save** করুন।
5. কয়েক মিনিটের মধ্যেই আপনার ওয়েবসাইটটি লাইভ হয়ে যাবে (যেমনঃ `https://username.github.io/repository-name/`)।

---

### ৯. bKash/Nagad Real API Integration-এর জন্য কোন Backend Configuration প্রয়োজন?
বাস্তব মার্চেন্ট পেমেন্ট গেটওয়ের ক্ষেত্রে সিকিউরিটির জন্য ফ্রন্টএন্ডে সরাসরি মার্চেন্ট সিক্রেট কি রাখা নিষিদ্ধ। এর জন্য একটি নিরাপদ Cloud Function বা Express Server প্রয়োজন:
1. **bKash Tokenized Checkout API:**
   - App Key, App Secret, Username, Password সার্ভার-সাইড এনভায়রনমেন্ট ভ্যারিয়েবলে রাখতে হবে।
   - Endpoint: `/api/bkash/create-payment` এবং `/api/bkash/execute-payment`
2. **Nagad Direct Payment API:**
   - Merchant ID, Merchant Public Key, Merchant Private Key ব্যাকএন্ড ফাংশনে রাখতে হবে।
3. বর্তমান সিস্টেমে ট্রানজেকশন ট্র্যাকিং মেকানিজম যুক্ত আছে: দাতা Send Money করার পর ট্রানজেকশন আইডি (TrxID) ইনপুট দিলে তা `Pending Verification` অবস্থায় এডমিন প্যানেলে জমা হয়। এডমিন ব্যাংকিং স্টেটমেন্ট দেখে ভেরিফাই করলেই তা স্বয়ংক্রিয়ভাবে মোট ফান্ডে যুক্ত হয়।

---

### ১০. কোন কোন Security Rules deploy করতে হবে?
প্রোজেক্টের রুট ডিরেক্টরির `firestore.rules` এবং `storage.rules` ফাইল দুটি Firebase CLI দিয়ে ডেপ্লয় করুন:
```bash
firebase deploy --only firestore:rules,storage
```
এতে কোনো সাধারণ ভিজিটর অনুমতি ছাড়া সংবেদনশীল ডাটা (যেমনঃ NID কার্ড বা ব্যক্তিগত ফোন নম্বর) দেখতে পারবে না এবং সুপার এডমিন ব্যতীত কেউ সদস্য বা হিসাব পরিবর্তন করতে পারবে না।
