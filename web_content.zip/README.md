# FitForge AI — Free Offline Edition

A standalone workout app for gym and calisthenics. No backend, payment, Premium tier, OPay flow, or API key is required.

## Fixed
- All navigation and action buttons use working tap handlers.
- Six bottom navigation buttons fit correctly on mobile.
- Picture Guide opens a real local exercise illustration and instructions.
- Custom workout, progress, profile, settings, logging, and completion actions work offline.
- No external image URLs are required for the picture guides.
