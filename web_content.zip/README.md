# Motor Policy Manager (Android starter project)
Gujarati/English motor-insurance policy manager prototype.

## Features in this prototype
- Dashboard counts (total, monthly new, monthly renewals, 30-day expiry)
- Policy entry fields, including Broker Name and Agent Name
- Policies search/list/delete
- Renewal list
- Monthly report and Broker/Agent report
- CSV export
- Local browser storage

## PDF/OCR status
The PDF file picker is included as a UI entry point, but OCR extraction is not implemented in this starter. PDF auto-extraction requires integrating a PDF text parser/OCR engine (e.g. ML Kit OCR plus PDF rendering) and handling scanned PDFs.

## Build APK
Open this folder in Android Studio, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).
This environment does not have Android SDK/Gradle installed, so an APK was not compiled here.

## Data note
Prototype data is stored locally in WebView storage on the device. No cloud sync/backup yet.

## Build from mobile using GitHub Actions (no PC)
1. On phone, create a GitHub account if needed and a new repository.
2. Upload this project ZIP contents to repository (extract ZIP first if GitHub mobile upload supports files; use browser Desktop site if needed).
3. Ensure the `.github/workflows/build-apk.yml` file is in repository.
4. Open repository Actions tab, select `Build Motor Policy Manager APK`, and tap Run workflow.
5. When run finishes, open the run and download the `MotorPolicyManager-debug-apk` artifact. Extract it on phone to get `app-debug.apk`.
