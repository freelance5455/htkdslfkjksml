# ELS STUDIO PRO
Professional offline studio by ELS | ELSELEK

- Websites / documents: 25 section types (grouped), add / remove / duplicate / reorder
- Photos from the phone gallery: logo, hero background, products, gallery, team, menu, news...
- Store template = real shop (categories, search, cart, order via WhatsApp)
- Live preview before download, real ZIP download
