# Nayeem Online Messenger — Firebase Ready

এই ZIP-টি Nayeem-এর online messenger-এর Firebase-ready foundation।

## যেগুলো এখন real backend-এর সাথে যুক্ত করার কোড আছে
- Firebase account registration
- Username + Lock দিয়ে cross-device login
- Firestore user profiles
- Real-time chat listener
- Username search
- Online/offline presence using Realtime Database
- Logout
- Chat list
- Voice/video call-এর production integration hook

Firebase-এর realtime listeners পরিবর্তন হলে client-এ নতুন data পাঠাতে পারে; presence-এর জন্য Firebase-এর recommended pattern হলো Realtime Database + Cloud Functions/Firestore integration। Push notification-এর জন্য FCM ব্যবহার করা যায়।

## সবচেয়ে গুরুত্বপূর্ণ
এই ZIP-এ `firebase-config.js`-এ তোমার Firebase project-এর config বসাতে হবে। আমি তোমার হয়ে Firebase project/account তৈরি করতে পারি না এবং তোমার secret credentials নেওয়া উচিতও নয়।

### Firebase setup
1. Firebase Console-এ একটি project তৈরি করো।
2. Web App যোগ করো।
3. Authentication > Sign-in method > Email/Password চালু করো।
4. Firestore Database তৈরি করো।
5. Realtime Database তৈরি করো।
6. Storage চালু করো।
7. `firebase-config.js`-এ Web App config বসাও।
8. Firestore Rules, Realtime Database Rules ও Storage Rules বসাও।
9. HTTPS hosting ব্যবহার করো।

## Username + Lock সম্পর্কে
Firebase-এর standard password authentication email/password credential ব্যবহার করে। এখানে username থেকে একটি internal email address তৈরি করা হয়েছে, যাতে ব্যবহারকারীর কাছে email verification দরকার না হয়। এটি একটি prototype approach। Production-এ custom auth/backend দিয়ে username+PIN system করা ভালো।

৬ সংখ্যার PIN একা খুব দুর্বল। বাস্তব public app-এ শক্তিশালী password/lock এবং recovery ব্যবস্থা রাখা উচিত।

## Voice/Video
Real voice/video call-এর জন্য WebRTC signaling এবং TURN server প্রয়োজন। শুধু button/UI দিয়ে reliable calling হয় না। Android WebView/HTML-to-APK wrapper-এ microphone/camera permissions-ও ঠিকভাবে configure করতে হবে।

## Thousands of users
Firebase scalable backend দিতে পারে, কিন্তু হাজার হাজার active users-এর জন্য indexes, security rules, rate limits, storage limits, notification architecture, moderation/reporting এবং billing/quotas ঠিকভাবে configure করতে হবে।

## HTML-to-APK
প্রথমে HTTPS hosting-এ web app চালিয়ে Firebase কাজ করছে কিনা পরীক্ষা করো। তারপর তোমার HTML-to-APK tool দিয়ে wrapper APK বানাও।


## v3 network/performance improvements
- Online/offline indicator
- Automatic retry for sending messages during temporary network failures
- Lightweight service-worker shell cache for faster repeat loading
- PWA manifest
- Real-time Firebase listeners remain the main chat transport
- Keep images/videos compressed before upload to reduce data use

Note: no software can increase a user's actual ISP/mobile-network speed.
