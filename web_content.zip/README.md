# Exam Tabulation Portal — Android Project

This project wraps the supplied `index.html` in a native Android WebView.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select **Build > Build APK(s)**.
4. The debug APK will be under:
   `app/build/outputs/apk/debug/app-debug.apk`

App name: **Exam Tabulation Portal**
Application ID: `com.pradip.examtabulation`

The original HTML is kept unchanged in:
`app/src/main/assets/index.html`
