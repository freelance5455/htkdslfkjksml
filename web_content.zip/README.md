# Kegel Challenge — proyecto Capacitor
La app completa está en `www/index.html` (un solo archivo, funciona sin internet).

## Probar en el navegador
`npx serve www` (notificaciones y voz nativa solo funcionan en el APK)

## Generar el APK
```
npm i @capacitor/core @capacitor/android @capacitor/local-notifications @capacitor-community/text-to-speech
npm i -D @capacitor/cli
npx cap add android
npx cap sync
npx cap open android
```
En Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
Tras editar `www/index.html`, ejecuta `npx cap sync` otra vez.

## Permisos
- Notificaciones: la app los pide al guardar o probar un recordatorio (Android 13+).
- Voz: el saludo usa la voz del teléfono; no pide permisos.
Requisitos: Node.js 18+, JDK 17, Android Studio.
