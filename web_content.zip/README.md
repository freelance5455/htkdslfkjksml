# Brotherhood to Degree — Mobile Package

This package contains:
1. `web/` — an installable offline-capable web/PWA version.
2. `android/` — an Android Studio project that wraps the same game in a native Android WebView.

## Web version
Open `web/index.html` in a browser. For an installable PWA, serve the `web` folder over HTTPS (or use localhost during development).

## Android version
Open the `android` folder in Android Studio, allow Gradle to sync, then use:
Build → Build App Bundle(s) / APK(s) → Build APK(s).

The project is configured for portrait mode and requires no camera, microphone, location, or account permissions.
