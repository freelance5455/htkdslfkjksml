# DriveGo Car Travel Booking App

A responsive front-end prototype for an online car travel booking service.

## Included
- Customer booking flow
- Pickup/drop and date/time
- Car selection and fare estimate
- Booking details
- Payment selection
- Booking confirmation and live-trip tracking UI
- Driver dashboard with ride request
- Admin dashboard with bookings, drivers, revenue and statistics

## Run
Open `index.html` in any modern browser.

This is a front-end prototype. Real online payments, GPS tracking, authentication, driver dispatch, databases and APIs require a backend and service integrations.
