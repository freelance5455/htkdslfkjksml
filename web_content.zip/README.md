# BuildMate QuickBuild AI — Starter Project

This version prioritizes **small MVPs/prototypes** that can sometimes be created and tried in 2–5 minutes, such as a one-file HTML utility, dashboard, or tiny browser game.

It cannot promise every app/game will be finished in that time. Complex apps, online multiplayer, native Android features, and 3D games need more time and extra tools.

## Run (requires a computer or hosted Node.js server)
1. Install Node.js 18+.
2. Extract ZIP and open a terminal in this folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env` and add your API key privately on the server.
5. Run `npm start`, then open `http://localhost:3000`.

Never place your API key in public browser code or share it. API use may cost money.

## Current limitations
This is a starter scaffold. It requests a plan/code from an AI API but does not yet create project files automatically, execute code, or compile APKs. Add secure sandboxing and a build/signing pipeline before attempting automatic builds.
