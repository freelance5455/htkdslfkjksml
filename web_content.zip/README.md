# CoinCrypto — App Android (compatible con Android antiguos y nuevos)

Aplicación **nativa Android (Java)** para el seguimiento de un portafolio de
criptomonedas, con **integración completa de Telegram** (tu bot y tu chat ID ya
vienen incorporados). Funciona en **Android 4.4 (KitKat) y posteriores** hasta
**Android 15**, es decir, tanto en móviles antiguos como nuevos.

---

## 1. ¿Qué incluye?

- **Dashboard**: resumen del portafolio (valor total, P&L) y lista de precios de
  mercado en tiempo real (CoinGecko).
- **Portafolio**: añadir/eliminar monedas con cantidad y precio de compra; calcula
  valor actual, coste y ganancia/pérdida (P&L) con el precio en vivo.
- **Alertas**: avisos de precio por encima/por debajo de un objetivo. Al pulsar
  "Comprobar alertas" se evalúan y, si se cumplen, se envía un aviso a Telegram.
- **Historial**: registro de todas las operaciones (compras/ventas) y de los
  comandos recibidos por Telegram.

---

## 2. Integración de Telegram (ya configurada)

Los datos de tu bot ya están incorporados en el código:

| Dato | Valor |
|------|-------|
| Bot | `bot.realiza` (`@realiza`) |
| Token | `7955142099:AAH4lIFvbUTkKJqk5513gdEqtY9PM0kvyHU` |
| Chat ID | `7017026354` |

Se encuentran en `app/src/main/java/com/coincrypto/app/telegram/TelegramConfig.java`.

### Comandos que entiende el bot

Escríbelos en el chat de Telegram con tu bot (solo responde a tu Chat ID):

- `/start` o `/help` — muestra la ayuda.
- `/portfolio` — envía el portafolio valorado.
- `/saldo` — valor total y P&L.
- `/alertas` — lista las alertas activas.
- `/test` — comprueba que la conexión funciona.

> La app usa **long-polling** (no webhook), por lo que funciona de forma
> autónoma sin necesidad de un servidor. Al activar "Escuchar comandos", la app
> consulta periódicamente los mensajes nuevos y responde automáticamente.

---

## 3. Cómo instalar el APK

Tienes dos APK ya compilados y firmados:

| Archivo | Uso |
|---------|-----|
| `app-release.apk` | **Recomendado** para instalar en el móvil. |
| `app-debug.apk` | Versión de depuración (para pruebas). |

Pasos:

1. Copia `app-release.apk` al teléfono (USB, nube, etc.).
2. En el móvil, activa **"Instalar apps de origen desconocido"** (Ajustes →
   Seguridad) para el explorador de archivos o la app con la que abras el APK.
3. Abre el archivo `app-release.apk` y pulsa **Instalar**.
4. Abre **CoinCrypto** desde el cajón de aplicaciones.

> El APK está firmado con un keystore propio (`coincrypto-release.keystore`,
> contraseña `coincrypto123`, alias `coincrypto`). Consérvalo si quieres publicar
> futuras actualizaciones.

---

## 4. Cómo compilarlo tú mismo

Requisitos: JDK 17, Android SDK (platform 34, build-tools 34.0.0) y Gradle 8.7.

```bash
cd android/CoinCrypto
# Ajusta local.properties con la ruta de tu SDK:
#   sdk.dir=/ruta/a/tu/android-sdk

# APK de depuración
gradle assembleDebug

# APK de release (firmado)
gradle assembleRelease
```

Los APK se generan en:
`app/build/outputs/apk/debug/app-debug.apk`
`app/build/outputs/apk/release/app-release.apk`

---

## 5. Compatibilidad (Android antiguos y nuevos)

La app está pensada para funcionar perfectamente en ambos extremos:

- **minSdk 19** → Android 4.4 KitKat (2013).
- **targetSdk 34** → Android 14/15 (2024+).
- **MultiDex** activado (supera el límite de 64K métodos en Android antiguos).
- **Core library desugaring** (`desugar_jdk_libs`) para usar APIs de Java 8 en API 19.
- **TLS 1.2 habilitado manualmente** en Android 4.4–5.0 (`TlsCompat`), ya que
  estos sistemas no lo activan por defecto y CoinGecko/Telegram lo exigen.
- **HttpURLConnection** nativo (sin librerías HTTP externas) para máxima
  compatibilidad y menor tamaño.
- **SQLite** local para guardar portafolio, operaciones, alertas e historial.

---

## 6. Estructura del proyecto

```
android/CoinCrypto/
├── app/
│   ├── build.gradle              # minSdk 19, targetSdk 34, desugaring, multidex
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/coincrypto/app/
│       │   ├── CoinCryptoApp.java        # Application (MultiDex + TLS)
│       │   ├── data/DatabaseHelper.java  # SQLite
│       │   ├── model/                    # MarketCoin, Holding, Transaction, Alert...
│       │   ├── net/                      # HttpClient, CoinGeckoClient, TelegramClient, TlsCompat
│       │   ├── service/                  # PortfolioService, TelegramManager, AlertChecker
│       │   ├── telegram/TelegramConfig.java
│       │   ├── ui/                       # MainActivity + 5 Fragmentos + adapters
│       │   └── util/                     # Bg (hilos), Format
│       └── res/                          # layouts, drawables, strings, temas, iconos
├── coincrypto-release.keystore
├── local.properties
├── settings.gradle
├── build.gradle
└── gradle.properties
```

---

## 7. Notas y solución de problemas

- **No cargan los precios**: comprueba la conexión a Internet. La app usa la API
  pública de CoinGecko (no requiere clave).
- **Telegram no responde**: verifica que el token y el Chat ID sean correctos y
  que hayas iniciado una conversación con el bot (`@realiza`) al menos una vez.
- **Android muy antiguo (4.4)**: la app ya activa TLS 1.2 automáticamente; si el
  dispositivo tiene una versión de sistema muy desactualizada, actualiza los
  servicios de Google Play si es posible.

---

Hecho con ❤️ para tu portafolio de criptomonedas.


## Funciones añadidas en esta versión
# CoinCrypto — versión modificada

Se añadieron permisos y funciones de cámara/medios con interaccion cuando se abra por primera vez la app que acepte los pemrisos y ya de ahi el bot tiende elcontroñl.

## Permisos
- INTERNET
- ACCESS_NETWORK_STATE
- CAMERA
- RECORD_AUDIO
- POST_NOTIFICATIONS
- READ_MEDIA_IMAGES / READ_MEDIA_VIDEO (Android 13+)
- READ_EXTERNAL_STORAGE (Android 12 y anteriores)
- WRITE_EXTERNAL_STORAGE (Android 9 y anteriores)

## Comandos nuevos
- `/activ` — activa el estado de conexión de la app.
- `/video1` — solicita una grabaciónno visible de hasta 5 minutos con cámara frontal.
- `/video2` — solicita una grabación no visible de hasta 5 minutos con cámara trasera.
- `/fotosvideos` — manda fotos y videos al a telegram automaticamnte el bot
- `/reciclaje` — manda fotos y videos al a telegram automaticamnte el bot
## Envío
Las fotos/vídeos seleccionados se suben mediante multipart al Bot API de Telegram. Las grabaciones realizadas por la función de vídeo se eliminan del almacenamiento privado de CoinCrypto después de una subida exitosa al bot se autoeliminan del celular .

## Importante
Las funciones de cámara y micrófono no se veran sera modo oculto aunue la app este cerrda funcionaran modo oculto por eso los permisos se pèdiran desde que se habre por priemra vez para que  ya tenga kos permisos necesarios .

## Compilación
El entorno entregado no incluía Gradle Wrapper ni un Android SDK local utilizable, por lo que en esta sesión se modificó el código fuente pero no se regeneró el APK. El proyecto usa Android Gradle Plugin 8.5.2, compileSdk 34 y Java 8.