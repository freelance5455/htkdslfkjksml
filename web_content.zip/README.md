# ZenFocus Android

This project preserves the original ZenFocus Ultra HTML interface and adds an Android Screen Awake toggle.

## Build APK with GitHub
1. Upload the **contents** of this folder to the root of your GitHub repository.
2. Open **Actions** and run **Build ZenFocus APK** (or push a commit).
3. Download the `ZenFocus-APK` artifact from the successful workflow run.
4. Extract it and install `app-debug.apk` on Android.

The Screen Awake button turns Android's `FLAG_KEEP_SCREEN_ON` on/off. Its preference is saved in the webpage local storage.
