# Comida Já — MVP completo de demonstração

Abra `index.html` em um navegador.

Inclui em uma única aplicação:
- Login/cadastro demonstrativo
- Cliente: restaurantes, busca, cardápio, carrinho, endereço, pagamento e pedidos
- Restaurante: visualização e atualização de pedidos/produtos
- Entregador: visualização e aceite de entregas
- Admin: resumo de operação
- Persistência local no navegador via localStorage

Importante: pagamentos, mapas, notificações, autenticação segura e banco de dados ainda são simulados. Para produção, é necessário backend, banco, gateway de pagamento, mapas e contas reais.
