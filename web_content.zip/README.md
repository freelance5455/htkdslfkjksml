# Suesa AI - Kişisel Türkçe Android Telefon Asistanı

Suesa AI, Android telefonlarda Siri benzeri çalışan, sesli iletişim kurabilen, telefon uygulamalarını ve sistem ayarlarını açabilen, rehberden arama yapabilen, canlı web araması gerçekleştirebilen ve yerel bilgi tabanına sahip gelişmiş bir kişisel yapay zekâ asistanıdır.

## 🌟 Öne Çıkan Özellikler

1. **Siri Benzeri Sesli Asistan**:
   - Android yerel `SpeechRecognizer` (Konuşmayı Metne Çevirme) ve `TextToSpeech` (Türkçe Ses Sentezi).
   - Canlı ses göstergesi, mor-mavi gradyanlı animasyonlu Siri tarzı asistan orbu.
   - Konuşmayı durdurma, konuşma hızı ayarlama ve otomatik sesli okuma (TTS).

2. **Telefon ve Sistem İşlemleri (`AndroidActionManager`)**:
   - "YouTube'u aç" -> YouTube uygulamasını veya aramasını başlatır.
   - "Kamerayı aç" / "Fotoğraf çek" -> Cihaz kamerasını başlatır.
   - "Ahmet'i ara" / "Annemi ara" -> Rehberden kişiyi sorgular ve güvenli telefon aramasını başlatır.
   - "Wi-Fi ayarlarını aç" -> Android kablosuz ağ ayarlarına yönlendirir.
   - "Bluetooth ayarlarını aç" -> Bluetooth ayarlarına yönlendirir.
   - "Galeri'yi aç", "Mesajları aç", "Saat ve Alarmları aç", "Hesap Makinesini aç".

3. **Yapay Zekâ Motoru (`AIEngine`)**:
   - `IntentDetection`: Kullanıcı komutlarını niyetlerine göre ayrıştırır.
   - `LocalKnowledge`: Çevrimdışı çalışabilen zengin Türkçe bilgi tabanı (asistan kimliği, Minecraft rehberi, matematiksel işlem çözücü, bilim & coğrafya).
   - `WebSearch`: Güncel sorular, hava durumu, haber ve internet bilgileri için canlı web araması ve kaynak referansları.
   - `ConversationMemory`: Sohbet akışını ve bağlamını yönetir.
   - `ResponseGenerator`: Yerel bilgi, web sonuçları ve (varsa) Gemini API entegrasyonuyla doğal ve güvenilir yanıtlar üretir.

4. **Modern Koyu Temalı Arayüz (`#171717`)**:
   - WebView tabanlı, tamamen mobil ve dokunmatik uyumlu HTML5 / CSS3 / JavaScript arayüzü (`assets/index.html`).
   - Android ↔ JavaScript iki yönlü güvenli köprü (`SuesaBridge`).
   - Hızlı öneri butonları, kopyalama, dinleme ve görsel ekleme özellikleri.

5. **Gizlilik ve Güvenlik**:
   - Sohbet geçmişi Room yerel veritabanında saklanır.
   - Kullanıcının açık izni olmadan hiçbir arama veya sistem işlemi gizli yürütülmez.
   - API anahtarları kaynak kodunda sabit tutulmaz, şifreli/güvenli yerel SharedPreferences'ta saklanır.

## 🚀 Android Studio ile Çalıştırma

1. `SuesaAI.zip` arşivini bir klasöre çıkartın.
2. Android Studio'yu açıp **Open...** seçeneğiyle proje klasörünü seçin.
3. Gradle senkronizasyonunun tamamlanmasını bekleyin.
4. Android cihazınızı veya emülatörü seçerek **Run 'app'** butonuna basın.
