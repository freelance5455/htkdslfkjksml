# Passat B6 Bird

Joc Android 2D inspirat de jocurile arcade cu obstacole, cu o mașină stilizată inspirată de Volkswagen Passat B6.

## Deschidere și rulare
1. Instalează Android Studio pe un calculator.
2. Deschide folderul `PassatB6Bird` în Android Studio.
3. Lasă Gradle să sincronizeze proiectul (este necesară conexiune la internet pentru descărcarea dependențelor).
4. Conectează telefonul Android cu USB debugging activat sau folosește un emulator și apasă Run.

## Construire APK
În Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
Fișierul APK de debug se găsește de obicei în `app/build/outputs/apk/debug/app-debug.apk`.

## Construire AAB pentru Google Play
În Android Studio: **Build > Generate Signed Bundle / APK > Android App Bundle**. Creează și păstrează în siguranță cheia de semnare. Pentru publicare este necesar un cont Google Play Console și trebuie verificate cerințele Google Play valabile la momentul publicării.

## Notă
Acesta este un proiect sursă de pornire, nu un APK/AAB deja compilat și semnat. Numele și grafica sunt independente; pentru publicare, verifică drepturile asupra mărcilor și resurselor grafice.
