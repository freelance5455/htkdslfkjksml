# Better-Clips v2.0.0

A mobile-first Better-Clips project browser with authentication, project creation, image/video previews, history, search/filtering, reactions, local fallback storage, and optional Firebase cloud sharing.

## Firebase
Enable Email/Password Authentication. For shared projects, the Firebase Realtime Database and Storage rules must allow signed-in users to read/write the projects path.

Realtime Database example:
```json
{
  "rules": {
    "projects": {
      ".read": "auth != null",
      ".write": "auth != null"
    }
  }
}
```

Storage example:
```txt
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /projects/{projectId}/{fileName} {
      allow read, write: if request.auth != null;
    }
  }
}
```

## APK / WebView file picking
The page uses normal HTML file inputs with image/* and video/* plus transparent label overlays. An Android WebView wrapper still must support the native file chooser (`WebChromeClient.onShowFileChooser`) for those inputs to open a device picker. In APK Forge, enable file upload/file picker support and internet access if those options are available.

## Local fallback
If Firebase Storage upload is unavailable, projects are kept locally in browser storage so creation still works.
