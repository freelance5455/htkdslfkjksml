# Tavar’s — Velosiped zapchastlari boshqaruv ilovasi

Tavar’s — velosiped zapchastlarini ombor, sotuv, olib kelish va moliya bo‘yicha boshqarish uchun **offline-first** web ilova.

## Nimalar bor?
- Bosh sahifa / Dashboard
- Zapchastlar ombori
- Yangi zapchast qo‘shish
- Sotish va qoldiqni avtomatik kamaytirish
- Kam qolgan zapchastlarni “Olib kelish” sahifasi
- Oylik tushum, foyda, zarar va xarajatlar
- Xarajat kiritish
- LocalStorage orqali qurilmada saqlash
- JSON backup chiqarish / tiklash
- Glass UI
- Responsive mobil dizayn
- SUDO harflari bilan loading animatsiyasi

## ZIP → APK
Bu loyiha ataylab **oddiy HTML/CSS/JS** ko‘rinishida tayyorlandi, shuning uchun ZIP-to-APK WebView xizmatlariga mos.

ZIPni ochganda `index.html` fayli ZIPning eng yuqori darajasida turishi kerak.

Masalan:

```text
Tavars.zip
├── index.html
├── dashboard.html
├── inventory.html
├── add-product.html
├── sales.html
├── restock.html
├── finance.html
├── settings.html
├── app.js
├── styles.css
├── icon.svg
├── manifest.json
└── README.md
```

## Muhim
Ma’lumotlar brauzer/WebView localStorage xotirasida saqlanadi. Ilova o‘chirib tashlansa, uning lokal ma’lumotlari ham qurilmadan o‘chishi mumkin. Shuning uchun **Settings → Backup** orqali vaqti-vaqti bilan JSON backup oling.

Internetga bog‘langan kutubxonalar ishlatilmagan: asosiy UI va hisob-kitoblar offline ishlashi uchun yozilgan.
