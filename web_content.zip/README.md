# Royal Number Showdown — Zero-Hassle Hotspot/LAN Setup (Android APK)

সাধারণ মানুষের জন্য কোনো টার্মিনাল, কমান্ড বা IP মুখস্থ করার ঝামেলা ছাড়া **Hotspot অন করে শুধু `Host` আর `Connect` বাটনে** অফলাইন মাল্টিপ্লেয়ার চালাতে গেমটিকে Android অ্যাপ (APK) হিসেবে প্যাক করার স্টার্টার সেটআপ এখানে দেওয়া হলো।

## ফোল্ডার কাঠামো
- `www/index.html` — মূল গেমের কোড (`royal-number-showdown-v5-lan.html`)
- `package.json` — Capacitor Android ডিপেন্ডেন্সি ও স্ক্রিপ্ট
- `capacitor.config.ts` — অ্যাপ আইডি ও ওয়েব ডিরেক্টরি কনফিগারেশন

## ধাপসমূহ (APK বানানোর জন্য)
1. Node.js ও Android Studio ইনস্টল করা পিসিতে `capacitor-pack` ফোল্ডার খুলে চালান:
   ```bash
   npm install
   npm run cap:add:android
   npm run cap:sync
   npm run cap:open:android
   ```
2. Android Studio থেকে **Build > Build Bundle(s) / APK(s) > Build APK(s)** দিয়ে APK তৈরি করুন।
3. নেটিভ Hotspot/LAN অটো-ডিসকভারি ও লোকাল সার্ভার প্লাগইন যুক্ত করলে ইউজারদের জন্য:
   - Phone 1: Hotspot অন করে অ্যাপ খুলে **Host** চাপবে
   - Phone 2+: ওই Hotspot/Wi-Fi-তে যুক্ত হয়ে অ্যাপ খুলে **Connect** চাপবে
