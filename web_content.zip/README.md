# Dagba Digital Academy: website + Android + iOS ecosystem (delivery pack)

**One backend, one database.** The apps are a new client for your existing Flask site; your website code was changed only minimally (list in `11`).

## Honest status
| Area | Status |
|---|---|
| Backend mobile API (auth, catalogue, learning, quizzes, assignments, certificates, notifications, discussions, articles, paths, Faith, payments history, account deletion) | **Built and automatically tested** |
| Automatic website→app sync (ETag revalidation + DB-trigger content version) | **Built and tested** |
| Push notifications (server side) | Built; **needs your Firebase credentials**; not delivered to a real phone |
| In-app purchases (Play Billing / Apple IAP): server ledger, verification, entitlements, idempotency, refund revoke | **Built; logic tested with a fake store; never run against live Google/Apple**. Renewal/refund webhooks **not** built (`04`) |
| Mobile app (web layer: 5-tab UI, all screens, offline cache, secure tokens, deep links, share, back button, network banner) | **Built; tested headlessly; never seen on a real device** |
| Live (web-layer) updates | Server side built and tested; device side not run (`03`) |
| Android and iOS native projects, signed `.aab`, Xcode archive, TestFlight | **Not generated** (need network + SDKs/Mac). Complete scripts, patcher, CI templates and step-by-step guides provided (`07`, `08`) |
| Production hosting kit and migration scripts | Data scripts tested on sample data; server bootstrap/systemd/tunnel **not run on a real server** (`05`, `06`) |
| Store listing text, data-safety answers, privacy addendum, checklists | Written (`09`, `store/`). **No screenshots** (no device) |
| Approval / publication | **None claimed**. Nothing has been submitted |

## Read in this order
`01` audit → `12` what you must supply → `05` hosting/migration (safe, non-destructive) → `04` billing (read before charging anyone) → `07`/`08` builds → `09` submission → `03` how to update after launch → `06` backups → `10` security → `13` test report.

## Folder map
`backend/` your Flask project with the additions · `mobile/` Capacitor app · `docs/` guides · `store/` listing and privacy text.
Nothing destructive has been done to any data; the original upload is untouched.
