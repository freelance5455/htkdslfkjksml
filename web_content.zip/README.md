# ODA Educational App — Full-stack starter

Bilingual (English / Afaan Oromoo) learning platform starter with React, Express, Prisma and PostgreSQL.

## Included
- Student registration and login (bcrypt password hashing, JWT in HttpOnly cookie)
- Role-based access control (`STUDENT`, `ADMIN`)
- Student dashboard and admin dashboard
- Grades, subjects, chapters, lessons, video/PDF resource metadata
- MCQs with answers and explanations
- Payment submission and admin approval workflow
- English / Afaan Oromoo UI toggle
- Zod input validation, Helmet, rate limiting, CORS allow-list, parameterized Prisma queries
- Prisma schema and seed script

## Requirements
- Node.js 20+
- PostgreSQL 15+
- npm

## Run locally
1. Copy `.env.example` to `.env` and replace every placeholder with strong secrets.
2. Create a PostgreSQL database, e.g. `oda_learning`.
3. Install dependencies:
   ```bash
   npm install
   npm run install:all
   ```
4. Run migrations and seed demo curriculum:
   ```bash
   npm run db:migrate
   npm run db:seed
   ```
5. Start API and frontend:
   ```bash
   npm run dev
   ```
   Frontend: http://localhost:5173; API: http://localhost:4000/api/health

## Create the first admin
Public registration always creates a STUDENT. To promote a user, use a secure database/admin operation after registering:
```sql
UPDATE "User" SET role = 'ADMIN' WHERE email = 'your-admin-email@example.com';
```
Do this only on your own database and only for an account you control. Never add public admin signup.

## Important production steps
- Use HTTPS and secure cookie settings behind a correctly configured reverse proxy.
- Set `COOKIE_SECURE=true`, `NODE_ENV=production`, and an exact `CLIENT_ORIGIN`.
- Use a strong `JWT_SECRET` (at least 32 random bytes); never commit `.env`.
- Configure backups, database access restrictions, logging/monitoring, email verification, password reset, and privacy/retention policies.
- Upload videos/PDFs to private object storage (S3-compatible, etc.) and store only metadata in PostgreSQL; do not serve arbitrary user-supplied file paths.
- Integrate a legitimate payment provider before accepting real payments. The included payment flow is manual review only and does not process money.
- Review security and local legal/privacy requirements before public launch.

This is a runnable starter, not a deployed production service. No real credentials or payment integration are included.
