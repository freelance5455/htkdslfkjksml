# CryptoTrader Mobile v3

Versão mobile/PWA para importar numa ferramenta HTML-to-APK.

## Novidades
- Analisa várias criptomoedas e pode manter várias posições em simultâneo.
- Score multi-indicador por ativo.
- Limite de posições, exposição máxima, reserva e máximo por ativo.
- Compras automáticas em paper trading quando os filtros são atingidos.
- Trailing profit: deixa a posição subir e procura uma reversão confirmada antes de vender.
- Venda parcial em duas etapas e saída final.
- Registo detalhado de operações/memória.
- Backtest histórico simples por ativo.
- Exportação do estado/memória em JSON.
- PWA/offline para a interface.

## Importante
Esta versão NÃO envia ordens reais para a Binance. As cotações são públicas e o motor simula compras/vendas.

O navegador/Android pode suspender a aplicação em segundo plano. Para execução 24/7 real, o motor deve correr num backend/worker persistente e o telemóvel servir como painel.

Os resultados do backtest não garantem resultados futuros. A lógica deve ser validada com mais dados, custos reais, slippage, períodos de mercado diferentes e paper trading prolongado antes de qualquer capital real.
