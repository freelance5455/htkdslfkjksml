# Danger Chat
Mobile-first React/Vite starter for a social chat app.

Included UI/working browser features:
- Demo Gmail-style login entry
- Profiles, name editing UI and DP UI
- Private chat UI
- Friend search, add-request and accept/reject UI
- Voice chat room UI with microphone permission
- Voice/video call screens
- Chat composer
- Danger Mic/Danger Chat visual theme and supplied artwork

Production backend required for:
- real Google/Gmail OAuth
- real multi-user real-time chat
- cloud profile photos
- push notifications
- real voice/video calls (WebRTC signaling)
- persistent rooms and friend relationships
- secure authentication/database rules

Build:
npm install
npm run build
