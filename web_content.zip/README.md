# CryptoTrader Mobile
Versão com atualização automática a cada 10 segundos.

## Alteração
- Atualização automática: 10s em vez de 30s.
- Mantida a proteção progressiva de lucro.
- Mantidas as restantes funcionalidades da versão anterior.

> Nota: a velocidade real dos dados também depende da API/Internet e dos limites do serviço de mercado.
