# Battle Royale Mobile 3D

Jogo de tiro e sobrevivência **Battle Royale 3D** completo, jogável no navegador e instalável no Android.

## Como instalar no celular (3 formas)

### 1. Mais fácil — Instalar como PWA (recomendado)

1. Abra o jogo no **Chrome** do Android
2. Toque no menu **⋮** (três pontinhos)
3. Escolha **"Adicionar à tela inicial"** ou **"Instalar aplicativo"**
4. Confirme. O ícone aparece na tela inicial e abre em tela cheia.

Funciona offline depois da primeira abertura.

---

### 2. Gerar APK de verdade (arquivo .apk instalável)

O arquivo **`BattleRoyaleMobile3D.zip`** já está pronto.

1. Acesse um conversor online gratuito:
   - https://www.htmltoapp.net/  (recomendado — grátis, sem marca d'água)
   - ou https://html2app.dev/
2. Faça upload do arquivo **BattleRoyaleMobile3D.zip**
3. Configure:
   - Nome: `Battle Royale Mobile 3D`
   - Orientação: **Landscape** (horizontal)
   - Ícone: use o `assets/icon-512.png` se pedir
4. Clique em **Build / Generate APK**
5. Baixe o `.apk` e instale no celular (ative "Fontes desconhecidas" se necessário)

Tempo médio: 1–3 minutos.

---

### 3. Servidor local (para testar na mesma rede Wi-Fi)

```bash
cd battle-royale-mobile-3d
python3 -m http.server 8080
```

No celular abra: `http://IP-DO-SEU-PC:8080`

---

## Controles

**Touch (celular):**
- Joystick esquerdo → Movimentação
- Arrastar lado direito da tela → Girar câmera
- Botão TIRO grande → Atirar
- MIRA / PULAR / AGACHAR / CORRER / REC / TROCAR / PEGAR

**Teclado (PC):**
- WASD + mouse (botão direito pressionado)
- Clique esquerdo → Atirar
- Espaço / Shift / C / R / F / Q

---

## Arquivos importantes

| Arquivo | Uso |
|---------|-----|
| `BattleRoyaleMobile3D.zip` | Enviar para geradores de APK |
| `index.html` + pasta `js/` | Código do jogo |
| `manifest.json` + `sw.js` | PWA (instalação nativa) |

O jogo usa Three.js local (não depende de internet depois de carregar).
