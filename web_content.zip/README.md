# BFF 2.0 — Arkadaş & Sohbet

Bu sürüm BFF'nin mobil/PWA arayüzünü ciddi şekilde yeniler ve Android paketlemeye hazırlar.

## Çalıştırma
```bash
npm install
npm start
```
Sonra `http://localhost:3000` aç.

## Online yayın
Bu klasörü statik hosting'e (Netlify, Vercel, Cloudflare Pages vb.) yükleyebilirsin. `index.html` giriş noktasıdır. PWA manifesti + service worker hazırdır.

> Önemli: Mevcut veri katmanı hâlâ tarayıcı `localStorage` kullanıyor. Bu nedenle siteyi internete koymak, tek başına farklı cihazlardaki hesapların birbirleriyle mesajlaşmasını sağlamaz. Gerçek çok-cihazlı hesap/mesajlaşma için bir backend (ör. Supabase/Firebase veya özel Node/WebSocket sunucusu) eklenmelidir.

## Android / APK
Capacitor yapılandırması eklendi:
```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```
Android Studio'da **Build > Generate App Bundles or APKs > Generate APKs** ile APK alınabilir.

Bu çalışma ortamında Android SDK/Gradle kurulu olmadığı için hazır binary `.apk` derlenmedi; proje doğrudan Android Studio/SDK bulunan bir makinede paketlenmeye hazırdır.

## Yapılan UI iyileştirmeleri
- Mobil-first responsive düzen
- Cam efektli modern üst/alt navigasyon
- Daha iyi kartlar, gölgeler ve odak durumları
- Safe-area desteği (çentik/navigation bar)
- Tablet/masaüstü için iki kolonlu sohbet görünümü
- PWA kurulumu ve offline cache
- Uygulama ikonu + tema rengi
- `prefers-reduced-motion` desteği
- Online sunucu için basit Node static server + health endpoint
