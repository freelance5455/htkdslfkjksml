# Satisfy Premium Balanced Final

Preview-first offline cleanup game.

- The actual next-level board is visible before START.
- START begins a 4-second countdown.
- The same layout is used after countdown, so the preview is useful.
- Timing is based on item count and gradually becomes harder, with a realistic safety buffer.
- More items/tighter layout at higher levels.
- Final 5 seconds use an urgent timer state and warning sound.
- Score and high score persist with localStorage.
- Fully offline: no external libraries, APIs, images, fonts, or server required.

Open index.html directly or upload it to static hosting.
