# Lucifer AI — Android HTML-to-APK Package

## Features Included
- **Gemini 3.8 Flash Ready**: Uses `gemini-3.8-flash` via Google's official Generative Language REST API with your personal API key stored locally on your phone.
- **File Reading & File Creation**: Attach images, PDFs, code, or text files for Lucifer to analyze, or ask Lucifer to generate and download files directly to your device.
- **Android Device Actions**: Built-in tool calling for battery status, GPS location, vibration, timers, native share sheet, URL launching, and WebView flashlight bridges.
- **Voice Input & Spoken Replies**: Uses Web Speech recognition and text-to-speech.

## How to Convert into an APK on Android
1. Extract or select `Lucifer-AI-APK.zip` inside your HTML-to-APK builder app (such as **HTML to APK Builder** or **Website 2 APK Builder**).
2. Enable **Offline Support / Bundle Local Files**, **Microphone**, **GPS/Location**, **Vibration**, and **File Access / Storage** permissions in the builder settings.
3. Build and install the signed APK on your Android device.
4. Open **Lucifer**, tap the **Gear (⚙️)** icon, paste your Gemini API key from Google AI Studio, and tap **Save & Activate**.
