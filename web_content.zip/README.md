# Galaxy My Files AI (Native Android • One UI 7 Style)

A mobile-first file manager replicating the Samsung Galaxy **My Files** experience with Storage Access Framework (SAF), real device storage telemetry, USB OTG hardware detection, magic-byte & APK manifest inspection, ZIP compression/extraction, three-tier global animations, dynamic theming, and multimodal **Firebase Gemini AI Logic** tools.

---

## Core Capabilities

1. **StorageProvider Architecture (`DeviceAndSafStorageAdapter` & `UsbOtgMonitor`)**
   - Strict real-device storage: operates on app-scoped Internal Workspace directories, user-granted Android Storage Access Framework (`OpenDocumentTree`) folders with persisted URI permissions, and physical USB OTG / removable volumes.
   - Full file lifecycle: `listRoots()`, `list()`, `read()`, `write()`, `copy()`, `move()`, `deleteToTrash()`, `rename()`, `mkdir()`, `stat()`, `compressToZip()`, `extractZip()`, and `analyzeStorage()`.
   - Interactive conflict resolution (**Skip**, **Replace**, **Keep both** with *Apply to all*) and real-time byte progress with cancellation.

2. **Magic-Byte File Detection & Security Inspection (`FileTypeInspector`)**
   - Inspects both extensions and leading magic bytes (`PK`, `MZ`, `%PDF`, `PNG`, `JPEG`, `7z`, `RAR`, `GZIP`, `MP4 ftyp`).
   - Flags suspicious double extensions (e.g., `photo.jpg.exe`) and warns when Windows PE binaries (`.exe`, `.msi`) cannot execute on Android.
   - Parses `.apk` package info via `PackageManager.getPackageArchiveInfo()` and `.xapk`/`.apks` bundle manifests.

3. **Gemini AI Suite (Firebase AI Logic + App Check)**
   - **Smart Search**: Natural-language query parsing (`gemini-3.8-flash` with JSON `responseSchema`).
   - **AI Image Editor**: Crop, rotate, filters, brightness/contrast, Remove Background, AI Enhance, and Edit with Prompt (`gemini-nano-banana-2.1`).
   - **AI Video Studio**: Trim, clip merge, speed, audio mute, and text burn-in export via Jetpack **Media3 Transformer**, paired with `gemini-3.8-flash` keyframe auto-captions, summaries, and scene highlights.

---

## Wrapping or Bridging with Capacitor (Cross-Platform Hybrid Reference)

Because this project already implements a clean `StorageProvider` interface in Kotlin, it runs natively as a standalone Android APK today. If you also maintain a web/PWA counterpart and wish to wrap it with **Capacitor** for native hardware parity, configure the following plugins:

1. **Initialize Capacitor**
   ```bash
   npm install @capacitor/core @capacitor/cli @capacitor/android
   npx cap init "My Files" com.aistudio.myfiles.vqxkpl
   npx cap add android
   ```

2. **Recommended Native Capacitor Plugins**
   - **Filesystem (`@capacitor/filesystem`)**: Bridges `Directory.ExternalStorage` and `Directory.Documents` to `StorageProvider.list()`, `read()`, `write()`, `mkdir()`, and `rename()`.
   - **Camera (`@capacitor/camera`)**: Replaces `getUserMedia` capture flows with native intent/CameraX photo & video capture.
   - **Share (`@capacitor/share`)**: Maps multi-file sharing to Android `FileProvider` `ACTION_SEND` intents.
   - **USB / OTG Mass Storage Bridge**: Expose `UsbOtgMonitor.kt` (`UsbManager` + `StorageManager` + `OpenDocumentTree`) via a custom `@CapacitorPlugin(name = "UsbOtgStorage")` annotation to enumerate `FAT32`, `exFAT`, `NTFS`, and `ext4` volumes.
   - **APK Archive Inspector & Installer Intent**: Expose `FileTypeInspector.inspectApkArchive()` via a Capacitor plugin method; if building an enterprise/sideload distribution outside Google Play's `REQUEST_INSTALL_PACKAGES` restriction, invoke `Intent(Intent.ACTION_VIEW)` with MIME `application/vnd.android.package-archive` via `FileProvider`.
