# TempBox — Disposable Email & Temporary Phone Number App

TempBox is a production-grade privacy platform providing disposable email addresses and temporary phone numbers for receiving SMS verification codes and activation links.

---

## 🏗️ Architecture & Tech Stack

### 1. Mobile (React Native / Expo)
- **Framework**: Expo v51 + Expo Router v3 (file-based routing) + TypeScript
- **State Management**: Zustand
- **Data Fetching**: TanStack React Query v5
- **Security & Privacy**: Sandboxed WebView, blocked remote tracking pixels by default with manual toggle, zero tracking/analytics SDKs
- **Haptics & Animations**: Expo Haptics, React Native Reanimated

### 2. Backend (Node.js & Fastify)
- **Server**: Fastify v4 with TypeScript & Zod schema validation
- **Database**: PostgreSQL 16 managed via Prisma ORM
- **Cache & Rate Limiting**: Redis 7 (TTL expirations, request rate limiting, message queues)
- **Real-Time Push**: WebSockets (`/ws`) for instant inbox updates
- **Security & Cryptography**:
  - All email bodies and SMS text encrypted at rest using **AES-256-GCM**
  - HTML email sanitization via **DOMPurify**, neutralizing `<script>`, `<iframe>`, and 1x1 tracker pixels
  - Zero plaintext logging of email or SMS bodies
  - Signature verification on all inbound webhooks (HMAC SHA-256 for Mailgun, Ed25519 for Telnyx, x-twilio-signature for Twilio)
- **Automatic Refund Guard**: If a rented temporary number receives 0 SMS during its window, credits are refunded automatically to the user's ledger.

---

## 📁 Repository Structure

```
├── backend/
│   ├── prisma/
│   │   ├── schema.prisma       # 11 models with composite indexes on expiresAt & address
│   │   └── seed.ts             # Admin and initial mock data
│   ├── src/
│   │   ├── config/env.ts       # Validated environment configuration (Zod)
│   │   ├── lib/
│   │   │   ├── crypto.ts       # AES-256-GCM encryption & decryption at rest
│   │   │   ├── otp.ts          # Regex engine detecting 4-8 digit OTPs & links
│   │   │   ├── sanitize.ts     # DOMPurify HTML sanitizer & tracker stripper
│   │   │   ├── prisma.ts       # Prisma database client
│   │   │   └── redis.ts        # Redis client with in-memory resilient fallback
│   │   ├── services/
│   │   │   ├── sms/            # Provider-agnostic interface (Twilio, Telnyx, Mock)
│   │   │   ├── email/          # Inbound email webhook processing & size cap checks
│   │   │   └── credits.service.ts # Credit ledger transactions & auto-refund scheduler
│   │   ├── routes/             # Fastify REST endpoints (/auth, /mailboxes, /numbers, etc.)
│   │   ├── websocket/hub.ts    # Real-time WebSocket event broadcaster
│   │   └── server.ts           # Fastify server entrypoint with Swagger OpenAPI (/docs)
│   ├── tests/
│   │   └── api.test.ts         # Jest test suite (OTP detection, AES encryption, sanitization)
│   └── Dockerfile
├── mobile/
│   ├── app/                    # Expo Router screens
│   ├── src/store/useAppStore.ts # Zustand global state
│   └── app.json                # Expo mobile configuration
├── docker-compose.yml          # Postgres 16, Redis 7, Fastify API
└── src/                        # Interactive browser simulator & admin control room
```

---

## 🚀 Quickstart: Local Development via Docker Compose

1. Clone repository and set up environment:
   ```bash
   cp .env.example .env
   ```
2. Start PostgreSQL, Redis, and Backend API in one command:
   ```bash
   docker compose up --build -d
   ```
3. Run database migrations and seed initial data:
   ```bash
   cd backend
   npx prisma migrate dev --name init
   npx prisma db seed
   ```
4. Access:
   - **Interactive Web App & Simulator**: `http://localhost:3000`
   - **Backend API**: `http://localhost:4000`
   - **OpenAPI Swagger Documentation**: `http://localhost:4000/docs`

---

## 🛠️ Inbound Email Setup (Mailgun / Cloudflare)

### 1. DNS Records
Configure your custom domain DNS records:
- **MX Record**: Priority `10` -> `mxa.mailgun.org`
- **MX Record**: Priority `10` -> `mxb.mailgun.org`
- **TXT Record (SPF)**: `v=spf1 include:mailgun.org ~all`
- **TXT Record (DKIM)**: Values provided in Mailgun domain settings

### 2. Inbound Routing Webhook
In the Mailgun dashboard:
1. Navigate to **Receiving -> Routes -> Create Route**.
2. **Expression Type**: Match Recipient:
   `match_recipient(".*@tempbox.io")`
3. **Actions**: Store and notify (Forward):
   `forward("https://api.tempbox.io/webhooks/inbound-email")`
4. Set `MAILGUN_WEBHOOK_SIGNING_KEY` in `.env` to verify HMAC signatures.

---

## 📞 SMS Provider Setup (Twilio & Telnyx)

### 1. Twilio Setup
1. In Twilio Console, set `TWILIO_ACCOUNT_SID` and `TWILIO_AUTH_TOKEN`.
2. Under Phone Numbers -> Active Numbers -> Webhook Configuration:
   - URL: `https://api.tempbox.io/webhooks/sms`
   - HTTP Method: `POST`

### 2. Telnyx Setup
1. In Telnyx Portal, create a Messaging Profile.
2. Webhook URL: `https://api.tempbox.io/webhooks/sms`.
3. Set `TELNYX_API_KEY` and `TELNYX_PUBLIC_KEY` in `.env`.

---

## 📱 Building the Mobile App (Expo / Android APK & iOS)

1. Navigate to the mobile directory:
   ```bash
   cd mobile
   npm install
   ```
2. Build Android APK:
   ```bash
   npx eas-cli build -p android --profile preview
   ```
3. Build iOS IPA / TestFlight:
   ```bash
   npx eas-cli build -p ios --profile preview
   ```

---

## 🧪 Testing Checklist (End-to-End Verification)

- [x] **Email Generation**: Generate randomized addresses or custom usernames with domain selector.
- [x] **Live Countdown**: Expiry badges count down in real time; "Extend" button adds +24h.
- [x] **Real-Time Push**: Incoming webhook triggers real-time WebSocket push into user inbox.
- [x] **OTP Auto-Detection**: Verification codes and links extracted automatically with a 1-tap "Copy Code" chip.
- [x] **Sandboxed HTML Reader**: Dangerous `<script>` and tracker pixels neutralized; toggle remote images on/off.
- [x] **Phone Number Rental**: Browse country lines (US, UK, DE, CA, FR) with duration selection (20m, 24h, 7d, 30d).
- [x] **Credit Ledger**: Deduction on rental, top-ups via IAP/RevenueCat, zero-waste auto-refund when 0 SMS received.
- [x] **GDPR Compliance**: Instant JSON data export and permanent account/data purge.
- [x] **Admin Control Room**: System health, active allocations, abuse resolution, and user banning.
