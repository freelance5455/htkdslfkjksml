# مولد القالب الإخباري

مشروع Android Studio لتطبيق مولد القالب الإخباري.

## الوظائف
- اختيار صورة الخبر.
- اختيار الشعار.
- كتابة عنوان الخبر.
- إنشاء القالب بمقاس 1080x1350.
- حفظ النتيجة بصيغة PNG.

## إنشاء APK
1. افتح المجلد في Android Studio.
2. انتظر اكتمال Gradle Sync.
3. اختر Build ثم Generate App Bundles or APKs ثم Generate APKs.
4. ستجد ملف APK داخل:
   app/build/outputs/apk/debug/

اسم التطبيق:
مولد القالب الإخباري

معرّف التطبيق:
com.aljanoubia.news
