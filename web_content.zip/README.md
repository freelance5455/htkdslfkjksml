# Vetri AI starter

A beginner-friendly AI assistant web backend and mobile-first chat interface. It can be opened in an Android browser and wrapped in an Android WebView app.

## 1. API key
Create an API key at https://platform.openai.com/api-keys. API usage may cost money.
Never put the API key in HTML, JavaScript, or the Android app.

Set these environment variables in your hosting provider:
- `OPENAI_API_KEY` = your secret API key
- `OPENAI_MODEL` = `gpt-5.5` (optional; change to a model available to your API project)

## 2. Deploy backend
Deploy this folder to a Python host that supports Flask/Gunicorn. The included `Procfile` starts the server. Set the environment variables above in the host dashboard. Use HTTPS.
Do not publish a secret `.env` file.

## 3. Open on Android
Visit your deployed HTTPS URL in Chrome. In Chrome, open the menu and choose "Add to Home screen" or "Install app" if offered. This creates an app-like shortcut, not a Play Store APK.

## 4. Make an APK
Open the `android_wrapper` folder as an Android project in Android Studio on a computer. Replace `https://YOUR-DEPLOYED-SITE.example` in `MainActivity.kt` with your real HTTPS deployment URL. Build > Build APK(s).
The wrapper requires a deployed HTTPS site; it does not run the Python backend locally.

## 5. Local testing
Use Python 3.10+:
    pip install -r requirements.txt
Set `OPENAI_API_KEY` in your shell, then:
    python app.py
Open http://127.0.0.1:5000 on the same computer. To access from a phone on the same Wi-Fi, configure Flask to bind to your LAN interface and use your computer's LAN IP; do not expose a development server to the public internet.
