# PlayMitra – real-time multiplayer voice chat (LiveKit)

Real WebRTC voice between devices via LiveKit. No simulation. Stack: Node/Express + `livekit-server-sdk` (backend), plain HTML/CSS/JS + `livekit-client` (frontend).

## 1. Get LiveKit credentials (5 min, free)
1. Sign up at https://cloud.livekit.io and create a project.
2. Settings → Keys → create a key. Copy **WebSocket URL** (`wss://…livekit.cloud`), **API Key**, **API Secret**.
   (Self-hosting LiveKit also works – use its `wss://` URL behind TLS.)

## 2. Run the backend
```bash
cd playmitra
npm install
cp .env.example .env      # fill in LIVEKIT_* values and a long random JWT_SECRET
npm start                 # http://localhost:3000
```
`.env` is read only by the server. The API secret is never sent to the browser; the browser only receives a short-lived (2h) token scoped to one room.

## 3. HTTPS / WSS (required for microphone on phones)
Browsers and WebViews only allow `getUserMedia` on **HTTPS** (localhost excepted). Phones can't reach your laptop's localhost, so deploy:
- **Easiest:** Render / Railway / Fly.io – push the folder, set the env vars from `.env.example`, `NODE_ENV=production`. They provide HTTPS automatically.
- **VPS:** run `npm start` behind Caddy (`yourdomain.com { reverse_proxy localhost:3000 }`, auto-HTTPS) or Nginx + Let's Encrypt.
- **Quick test from your laptop:** `ngrok http 3000` and open the https URL on both phones.

In production the server redirects HTTP→HTTPS and sends HSTS; LiveKit signalling uses `wss://`.

## 4. Test with two phones
Open the HTTPS URL on phone A → sign up → **Create Voice Room** → share the 6-character code. On phone B → sign up with another username → enter the code → **Join Room**. Talk; the speaker's card glows green. Use headphones to avoid echo.

## Security built in
- Passwords hashed with scrypt + per-user salt; sessions are signed JWTs (7 days).
- Every room/token endpoint requires login; tokens bind identity to the authenticated user ID.
- Rooms are created only by the server (max 8 players); join requires the code of an existing room, else 404. Join/create are rate limited against code guessing.
- Helmet CSP, HSTS, input validation, 2 KB body limit, usernames rendered with `textContent` (no XSS).
- Production note: `data/users.json` is a simple file store. Use PostgreSQL/MongoDB for real scale, and on hosts with ephemeral disks (Render free) users reset on redeploy.

## Android WebView
Manifest:
```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.RECORD_AUDIO"/>
<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS"/>
```
Activity (Kotlin) – also request `RECORD_AUDIO` at runtime (e.g. `ActivityResultContracts.RequestPermission`) before loading the page:
```kotlin
webView.settings.apply {
    javaScriptEnabled = true
    domStorageEnabled = true                 // needed for login persistence
    mediaPlaybackRequiresUserGesture = false
}
webView.webChromeClient = object : WebChromeClient() {
    override fun onPermissionRequest(request: PermissionRequest) {
        runOnUiThread {
            if (request.origin.toString().startsWith("https://YOUR-DOMAIN")) request.grant(request.resources)
            else request.deny()
        }
    }
}
webView.loadUrl("https://YOUR-DOMAIN")
```

## Files
`server.js` (API, auth, LiveKit tokens) · `public/index.html|style.css|app.js` (UI, i18n EN/हिन्दी, LiveKit client) · `.env.example` · `package.json`
`livekit-client` is served by your own server from `node_modules`, so no third-party CDN is needed.
