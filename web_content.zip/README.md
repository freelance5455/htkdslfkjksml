# VINZ Hybrid Android project

Package/applicationId: `com.vinz.app`

This project includes `app/src/main/assets/index.html` for the panel UI and native Android Java code that exposes a restricted JavaScript bridge to Shizuku.

## What works in this source
- HTML panel is hosted inside native Android WebView.
- Native `VinzNative.requestShizuku()` requests Shizuku runtime permission.
- Binder connection and permission status are reported back to the HTML panel.
- X/Y sliders (0-200), acceleration toggle, local preset save/reset.
- Launch Free Fire MAX (`com.dts.freefiremax`) or Free Fire (`com.dts.freefireth`) if installed.

## What does NOT work as a game modification
Shizuku permission is not a universal sensitivity API. The project does not modify Free Fire's internal sensitivity, touchscreen firmware/driver acceleration, game memory, or inject touch events. Apply currently saves a local preset only. Do not present it as applied to the game.

## Build
Requirements: JDK 17, Android SDK Platform 35, Gradle 8.9, Android Gradle Plugin 8.7.3.
Open this folder as a native Gradle Android project and build `:app:assembleDebug`.
APK: `app/build/outputs/apk/debug/app-debug.apk`.

## ApkForge compatibility
ApkForge's HTML-to-app / ZIP-site mode can package an HTML website, but it cannot compile this Java Activity, AndroidManifest, or Shizuku dependencies. The presence of `index.html` does not make a native Shizuku bridge possible in a pure HTML wrapper. Use a native Android Gradle build environment for this project.
