# 미궁의 출구 — 안드로이드 · 아이폰 앱 프로젝트

게임(`www/index.html`)을 Capacitor로 감싼 프로젝트입니다. 가로 화면 고정, 전체 화면, 터치 조작(방향키·돌기·공격·줍기·사용 버튼, 화면 드래그로 둘러보기)이 들어 있습니다.

## 안드로이드 APK 만들기

### 방법 1. 내 컴퓨터에서 (Android Studio 필요)
1. Node.js 18 이상과 Android Studio를 설치합니다.
2. 이 폴더에서 `npm install` → `npx cap sync android`
3. `npx cap open android`로 Android Studio를 열고 메뉴 **Build > Build APK(s)** 를 누릅니다.
   - 터미널로 하려면: `cd android && ./gradlew assembleDebug` (Windows는 `gradlew.bat`)
4. `android/app/build/outputs/apk/debug/app-debug.apk` 가 생깁니다. 폰으로 옮겨 설치하세요. (설정에서 "출처를 알 수 없는 앱 설치" 허용 필요)

### 방법 2. 설치 없이 GitHub에서 자동 빌드
1. 이 폴더를 GitHub 저장소에 올립니다.
2. 저장소의 **Actions** 탭에서 "안드로이드 APK 빌드"를 실행합니다.
3. 끝나면 결과물(Artifacts)에서 `migung-exit-apk`를 내려받습니다.

구글 플레이에 올리려면 디버그 APK가 아니라 서명한 `.aab`(Build > Generate Signed Bundle)가 필요하고, 구글 개발자 계정이 있어야 합니다.

## 아이폰 앱 만들기 (맥 필요)
아이폰 앱은 애플 규정상 맥의 Xcode로만 빌드할 수 있습니다.
1. 맥에 Xcode와 CocoaPods(`sudo gem install cocoapods`)를 설치합니다.
2. 이 폴더에서 `npm install` → `npx cap sync ios` → `npx cap open ios`
3. Xcode에서 **App > Signing & Capabilities**의 Team에 본인 애플 계정을 고릅니다. (무료 계정이면 본인 아이폰에서 7일간 실행 가능)
4. 아이폰을 연결해 실행(▶)합니다. 앱스토어나 TestFlight 배포는 유료 애플 개발자 프로그램(연 99달러)이 필요하며 **Product > Archive**로 올립니다.

## 알아둘 점
- 공유 랭킹은 Claude 페이지 안에서만 작동합니다. 앱에서는 자동으로 "연결할 수 없음"으로 표시되고, 기록은 기기 안에만 저장됩니다. 닉네임 로그인과 게임 진행은 그대로 됩니다.
- 글꼴은 구글 폰트를 인터넷에서 받아 씁니다. 오프라인이면 기본 글꼴로 보입니다.
- 게임 내용을 바꾸려면 `www/index.html`을 고친 뒤 `npx cap sync`를 다시 실행하세요.

## 앱을 열었을 때 "웹페이지를 사용할 수 없음"이 뜨면
앱 안에 게임 파일(`www/index.html`)이 들어가지 않았다는 뜻입니다.
- 압축을 풀고 **폴더 전체**(`www`, `android`, `.github`, `capacitor.config.json`, `package.json` 포함)를 저장소 맨 위(루트)에 올렸는지 확인하세요. 웹에서 올릴 때는 `.github` 같은 점(.)으로 시작하는 폴더가 빠지기 쉽습니다.
- 빌드 전에 반드시 `npm install` → `npx cap sync android`를 실행하세요. (Android Studio에서 바로 Run만 누르면 안 됩니다.)
- 예전 앱이 깔려 있으면 **먼저 삭제**한 뒤 새 APK를 설치하세요. 앱 정보에서 버전이 `1.3-android10plus`인지 확인하면 새 빌드입니다.
- `sh check.sh`를 실행하면 빠진 파일을 알려줍니다.

## 지원 안드로이드 버전
안드로이드 10(API 29)부터 최신 버전까지 지원합니다. 가로 고정은 매니페스트 + 앱 코드 + 플러그인으로 이중 적용되어 있고, 상태바/내비게이션 바 숨김도 10~최신 모두 같은 방식(WindowInsetsController)으로 동작합니다. 안드로이드 9 이하는 지원하지 않습니다.
