# Kaushik OS v1.1

## What this build adds
- Hash-based multi-page public routing
- Home, About, Projects, Project detail, Updates, Gallery, Now, Contact
- Private Admin OS
- CRUD managers for projects, updates and media
- Local activity history
- Local analytics counters
- Settings
- JSON backup export
- Local-first persistence via localStorage
- PWA manifest + service worker
- Responsive mobile/tablet/desktop UI
- Premium glass/lighting/motion system
- Reduced-motion support
- Command/search launcher
- Explicitly avoids pretending frontend-only authentication, backend, email or server analytics are real

## Run
Open `index.html` in a browser/editor preview. For full PWA/service-worker behavior, serve the folder through a local/static HTTP server.

## Important
This is still a frontend-only build. Real authentication, authorization, database, uploads, server-side validation, rate limiting, CSRF/XSS hardening and production analytics require a backend.
