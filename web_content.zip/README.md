# Vault + Ludo World — one Firebase, one app

`vault_9914033.html` is the whole app: the Vault private messenger with a **Games** tab (Ludo World, Candy Cascade, VEKTRA, Snake).
Vault and Ludo World now share **one Firebase Realtime Database**, one sign-in and one friends list:

| What | Where it lives in Firebase |
|---|---|
| Player directory (find people by user ID or 12-digit code) | `users/`, `names/` |
| Friend requests, chat messages, Ludo invites | `inbox/` (delivered even if the friend is offline) |
| Online dots (who has Vault open) | `peers/` heartbeat |
| Live Ludo rooms, quick match, in-room chat | `inbox/` relay between the players' devices |
| Ludo World progress (XP, coins, wins, settings) | `ludo/<your code>` — follows your account |

Everything is under one root, `vault9914033`, so you can reuse a Firebase project that already holds other data.

---

## 1 · Set up Firebase (about 10 minutes, once)

1. <https://console.firebase.google.com> → **Add project**.
2. **Build ▸ Realtime Database ▸ Create database** (any region, start in *locked mode*).
3. **Project settings ▸ General ▸ Your apps ▸ Web (`</>`)** → register an app. Copy the config snippet it shows
   (`apiKey`, `databaseURL`, `projectId`, …). If `databaseURL` is missing, it is
   `https://<projectId>-default-rtdb.firebaseio.com`.
4. **Secure setup (recommended):** *Build ▸ Authentication ▸ Sign-in method ▸ Anonymous ▸ Enable*, then
   *Realtime Database ▸ Rules* → paste the contents of **`database.rules.json`** → **Publish**.
   **Quick setup:** skip step 4's authentication part and publish **`database.rules.open.json`** instead
   (anyone who knows your database URL could read and write — fine for a private test, not for real use).
5. Open the app → **Games ▸ the status chip** (top right) → paste the config snippet → **Test connection** → **Save**.
   The test checks reachability, sign-in, the rules and live updates, and tells you which step to fix.

Every friend needs the same Firebase config. After saving it you can tap **Copy setup link** and send the link
(when the app is hosted, see §3) — opening it offers to use your Firebase and sets everything up in one tap.

To bake the config into the file for every device, search the HTML for `FIREBASE_DEFAULT` and fill in `databaseURL` and `apiKey`.

## 2 · Using it

* **Add friend** (Chats ▸ ＋): type a *user ID* or a *12-digit code*. The request arrives on their device even if they are offline.
* **Ludo World ▸ Private Room**: tap a friend chip or enter their 12-digit code. The invite lands in their Vault chat; one tap on it joins the room.
  If they are offline, the invite waits for them (the room must still be open when they join).
* **Ludo World ▸ Quick Match**: you are matched automatically with other people searching at the same moment.
* **Room chat** (💬) exists only in private rooms and works during the game.
* Without any Firebase config the app keeps working in its earlier peer-to-peer mode (both friends must be online at the same time).

## 3 · Install it as an app

**On Android / desktop Chrome / iPhone (no build needed):** host the `app/` folder and use *Add to Home screen / Install*.
With the Firebase CLI (`npm i -g firebase-tools`):

```
firebase login
firebase use --add          # pick your project
firebase deploy             # publishes the database rules AND the app (Hosting)
```

You get `https://<project>.web.app` — open it on the phone and choose *Install app*.

**As an APK:** open the `android-app/` folder in **Android Studio** (Hedgehog or newer; it downloads Gradle by itself on the first sync) → *Build ▸ Build APK(s)*.
This project could not be compiled where it was prepared, so the first build in Android Studio is its first real test — if Studio proposes an Android Gradle Plugin upgrade, accept it.
It is a thin shell around the same page (`app/src/main/assets/index.html`), served from a real https origin so storage and Firebase streaming work like in a browser.
Alternative without Android Studio: put your hosted URL into <https://www.pwabuilder.com> and download the Android package.

## 4 · Good to know

* **Privacy:** accounts and chat history stay on the device. Messages that travel online pass through *your* Firebase database over HTTPS;
  they are **not end-to-end encrypted**, and with the secure rules only the recipient's device can read its inbox.
* **Firebase free plan (Spark):** ~100 simultaneous connections. Each signed-in phone uses one live connection (two or three while searching for a quick match).
* **Anonymous sign-in** gives each browser its own identity; clearing the browser's data also clears the Vault account stored there.
* If your Firebase API key has *website restrictions*, allow the address you host the app on (or open it from a file, which needs no restriction).
* Old messages and used invites are removed from the inbox when delivered. Stale presence entries are harmless and can be deleted from the console at any time.
