# Ahmadi WiFi ISP Manager (Starter v1)

PHP 8.1+ / MySQL 8+ web application starter for managing Hotspot and PPPoE subscribers on MikroTik RouterOS v6.

## Included
- Pashto RTL admin login and dashboard
- Customer records (Hotspot / PPPoE)
- Package records
- Billing/payment ledger starter
- MikroTik connection settings page (credentials are stored encrypted with APP_KEY)
- RouterOS API adapter using `evilfreelancer/routeros-api-php`
- SQL schema and sample packages

## Important network/security requirement
This is a hosting deployment. **Do not expose MikroTik API TCP 8728/8729 to the public internet.**
Connect the hosting server to the router's LAN using a site-to-site VPN (for example an appropriately secured IPsec/L2TP setup supported by your RouterOS v6 build), then permit API access only from the VPN address. Your router LAN address `192.168.22.1` is not directly reachable from public hosting unless a VPN/routed connection exists.

The app is a starter, not a finished production billing platform. Test on a lab router and take backups before applying changes. It does not automatically create/disable users or charge customers yet; those actions need explicit tested workflows and business rules.

## Install
1. Upload this folder to a PHP 8.1+ hosting account with HTTPS enabled.
2. Create a MySQL database and user.
3. Copy `.env.example` to `.env`; set database details and a long random `APP_KEY` (32+ characters).
4. Run `composer install --no-dev` in the project root.
5. Import `database/schema.sql` into the database.
6. Point the website document root to `public/` (recommended). If hosting cannot set a document root, move private folders outside `public_html` and adjust paths; never expose `.env`, `src/`, `database/`, or `vendor/`.
7. Create the first admin using `php scripts/create_admin.php admin@example.com 'StrongPasswordHere'`.
8. Sign in at `/login.php`.

## MikroTik
- Enable API only after VPN connectivity is working.
- Create a dedicated RouterOS user with the minimum required policy. Do not use the full `admin` account.
- Configure the router host as the VPN-reachable router address. `192.168.22.1` is the LAN address and works only if the VPN routes that subnet.
- API default port is 8728; API-SSL is usually 8729. Prefer API-SSL if supported and correctly configured.
- Add a firewall rule allowing the API port only from the hosting VPN peer address.
- Enter router username/password in Settings > MikroTik. Credentials are encrypted at rest using `APP_KEY`.
- Use the Test connection button before attempting any management action.

## Known limits
- RouterOS v6 has no native REST API. This project uses the RouterOS binary API library.
- Mikhmon v3 can continue to manage Hotspot vouchers independently; this application is a separate ISP/customer/billing panel. Avoid having both systems modify the same users until synchronization rules are designed.
- Configure backups, HTTPS, strong passwords, database least-privilege access, and server updates before production use.
