# Script Studio APK తయారీ (GitHub తో, ఉచితం)

## మీకు కావాల్సినవి
- GitHub ఖాతా (github.com లో ఉచితంగా)
- Anthropic API కీ (console.anthropic.com → API Keys). ఖాతాలో కొంచెం క్రెడిట్ ఉండాలి.

## దశలు
1. GitHub లో **New repository** తయారు చేయండి. పేరు: `script-studio`. Private పెట్టవచ్చు.
2. ఈ ZIP లోని అన్ని ఫైల్స్ (www ఫోల్డర్, package.json, capacitor.config.json, .github ఫోల్డర్) ఆ repository లో అప్‌లోడ్ చేయండి: **Add file → Upload files**.
   - `.github` ఫోల్డర్ అప్‌లోడ్ కాకపోతే: **Add file → Create new file** లో పేరు బాక్స్‌లో `.github/workflows/build-apk.yml` అని టైప్ చేసి, ఈ ZIP లోని ఆ ఫైల్ లోపలి టెక్స్ట్ పేస్ట్ చేసి Commit చేయండి.
3. repository లో **Actions** ట్యాబ్ తెరవండి. "Build APK" ఎంచుకుని **Run workflow** నొక్కండి. సుమారు 5-8 నిమిషాలు పడుతుంది.
4. పూర్తయ్యాక ఆ రన్ తెరిస్తే కిందన **script-studio-apk** అనే ఫైల్ కనిపిస్తుంది. దాన్ని డౌన్‌లోడ్ చేసి ZIP విప్పితే `app-debug.apk` వస్తుంది.
5. ఫోన్‌లో ఆ APK ను తెరిచి ఇన్‌స్టాల్ చేయండి. "తెలియని సోర్స్" అనుమతి అడిగితే ఇవ్వండి.
6. యాప్ తెరిచి, పైన 🔑 బాక్స్‌లో మీ API కీ పేస్ట్ చేసి **సేవ్** నొక్కండి. కీ ఫోన్‌లోనే ఉంటుంది.

## జాగ్రత్తలు
- API కీని ఎవరితోనూ షేర్ చేయకండి, GitHub లో కూడా పెట్టకండి. కీ యాప్ లోపల మాత్రమే టైప్ చేయండి.
- పొరపాటున కీ బయటపడితే console.anthropic.com లో వెంటనే దాన్ని తొలగించి కొత్తది తీసుకోండి.
- ఇది debug APK. ఇన్‌స్టాల్ అవుతుంది కానీ Play Store కు పెట్టడానికి కాదు.
