# TO‘LOVCHI Super Admin Dashboard

A responsive, privacy-first web console for owner-level TO‘LOVCHI operations. It is separate from the customer finance app. The dashboard contains no personal financial-record views and does not ingest a customer’s debts, balances, income, zakat information or financial history.

## Features

Aggregate registration/activity, Premium and advertising figures; user growth and revenue charts; anonymized incident/support examples; release metadata; backend usage/storage/cost estimates; persisted feature settings and announcement/release registers; role-based administrators with password + TOTP/recovery codes; and an administrative audit log. All administrative data APIs require a verified admin session and CSRF token.

**Important:** statistics, crash/support items, service costs and sample releases are demonstration data. Live sources are not connected. Feature settings and announcement/release records are persisted in this admin database but are not yet delivered to the customer app or app stores. See the [Android owner manual](docs/OWNER-MANUAL-ANDROID.md) and [deployment guide](docs/DEPLOYMENT.md).

## Development

Requires Node 22, pnpm 10.18 and a MySQL-compatible database for login/persistent administration.

```sh
pnpm install --frozen-lockfile
pnpm db:migrate
pnpm dev
```

The app listens on `PORT` (default `3000`). `GET /api/health` is the unauthenticated health check. Configure `DATABASE_URL`, `ADMIN_SETUP_TOKEN` and `TOTP_ENCRYPTION_KEY` privately before first owner enrollment. Never commit secrets. For schema changes, commit additive files under `drizzle/` and apply migrations deliberately.

## Owner-controlled operation

The Dockerfile and deployment instructions support migration to cloud accounts, a database, domain and repository owned by the application owner. This initialized workspace is a managed development/Preview environment; it does not transfer an owner’s cloud, GitHub, domain or app-store accounts. Source export and the complete self-host path are described in [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md).
