# PLANT WARS: EVOLUTION — Prototype 0.1

A playable browser-based 3D lane-defense prototype built with Babylon.js.

## Run
1. Extract the ZIP.
2. Open `index.html` in a modern browser with an internet connection.
3. Press **ENTER THE GARDEN**.
4. Select a plant card, then tap/click a tile to deploy it.
5. Collect floating solar orbs by clicking/tapping them.
6. Press **START WAVE** to begin zombie attacks.
7. Place matching plants on occupied tiles to evolve them up to level 3.

For best results, run from a local web server:
- Python: `python -m http.server 8000`
- Then open `http://localhost:8000`

## Included in this prototype
- 3D isometric battlefield with 5 lanes and 8 columns
- Solar Bloom resource generators
- Pea Blaster ranged attacker
- Root Guard defensive blocker
- Frost Lily slowing attacker
- Collectible solar energy
- Wave spawning and scaling difficulty
- Zombie health, movement, attacks, and base damage
- Boss zombie every fifth wave
- Plant leveling/evolution through matching placement
- Responsive HUD and touch/mouse input

## Important prototype scope
This is a genuine playable vertical slice, not yet a complete commercial game. The scene uses procedural 3D primitives and Babylon.js from its public CDN, so an internet connection is required to load the engine. The current build is a browser prototype that can be used as a foundation for Android/iOS/PC packaging.

## Next development milestones
1. Replace primitive models with original rigged 3D character assets and animations.
2. Add plant fusion recipes, custom plant editor, skill trees, and save data.
3. Add world progression, level selection, boss phases, and campaign missions.
4. Add audio, particle effects, accessibility, and balance tooling.
5. Package for Android/iOS/PC and optimize device performance.
