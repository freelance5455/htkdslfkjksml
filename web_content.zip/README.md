# YACKUZA UNBAN AI V5 — DIGITAL EMPIRE

Accès libre : les cinq canaux sont toujours visibles et ouvrables, mais aucun clic n'est obligatoire.

Nouveautés : outils d'import/export JSON, copie du dernier résultat, journal local, Message Lab entièrement personnalisable, fond + musique, Mode Boost et Mini Yackuza AI.

Pour l'IA, ajouter OPENAI_API_KEY dans les variables d'environnement Netlify.

Le Message Lab est une simulation locale de texte fourni par l'utilisateur et ne modifie aucun compte WhatsApp.
