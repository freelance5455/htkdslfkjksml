# Everday — Personal Life OS

## Open the app
Open `index.html` in a modern browser. Everday is a local-first web app prototype; it is not a compiled Android APK.

## Habit challenges
- New habits default to a 30-day challenge.
- Set the challenge length to another number of calendar days, or set it to `0` for an ongoing habit.
- Choose a start date. Challenge progress counts the days marked complete during the challenge period.
- After the challenge end date, the habit moves to **Finished challenges** and no longer appears in the active daily checklist.
- Use **Delete** to remove a habit and its completion history. Deletion asks for confirmation and cannot be undone.
- Editing a habit preserves its existing completion history.

## Privacy and backup
App data is stored in the browser's local storage on that device. Use the in-app Backup export before clearing browser data or moving to a different browser/device. This prototype does not sync data to a cloud account.

## Limitations
Opening a local HTML file is not the same as installing a native Android app. An APK has not been built as part of this package.
