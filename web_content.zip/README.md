# Sumrid Holidays Adventure® — Same Design Build
Customer UI follows the supplied reference: dark blue/gold header, mountain hero, search bar, services grid, 4-step booking area, assigned-vehicle panel, seat selection and booking summary.
Business rule: customer never chooses a vehicle. Manager publishes the vehicle for a route/date/time. The customer sees only that assigned vehicle's seat layout and the current Manager-set fare.
Route is centered on Chandigarh → Sarkaghat → Dharampur → Khaddar → Lad Bharol.
No business fare is hard-coded.
