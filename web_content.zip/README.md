# Bubble Clicker — вечное противостояние

Это готовый мобильный web-кликер по мотивам присланного скриншота.

## Правила
- Каждый тап = +1.
- На каждом тапе ровно 1% шанс мгновенно сбросить счёт в 0.
- Рекорд специально НЕ сохраняется после сброса.
- Топ 100 сортируется по текущему счёту.
- При изменениях рейтинг обновляется в реальном времени через Supabase Realtime.
- Имя игрока сохраняется на его устройстве, счёт — только текущий.

## Что нужно для настоящего общего Топ 100

1. Создай бесплатный проект Supabase.
2. В SQL Editor выполни `supabase.sql`.
3. В Supabase возьми Project URL и anon/public key.
4. Открой `app.js` и замени:
   SUPABASE_URL = "PASTE_YOUR_SUPABASE_URL";
   SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_ANON_KEY";
5. Загрузи `index.html`, `style.css`, `app.js` на Netlify/Vercel/GitHub Pages.
6. Открой сайт на двух телефонах: оба увидят общий живой Топ 100.

## Важно про честность
Этот MVP хранит score на клиенте, поэтому технически продвинутый пользователь может подделать запрос.
Для настоящего рейтинга с защитой от читеров нужно сделать server-side RPC/Edge Function:
клиент отправляет только "клик", а сервер сам увеличивает счёт или выполняет 1% сброс.

## Если нужен APK
Сайт можно завернуть в Android WebView/Capacitor. Для лучшей плавности уже используются pointer events, CSS-анимации и минимальный DOM.


## Никнейм = ID
При первом запуске игра ОБЯЗАТЕЛЬНО просит ник:
- минимум 3 символа;
- максимум 10 символов;
- ник является уникальным ID игрока;
- одинаковый ник у двух игроков означает одного и того же игрока в базе.


## PWA
Проект уже подготовлен как PWA:
- `manifest.json`
- `sw.js`
- `icon.svg`
- `index.html` подключает manifest и Service Worker.

Размещай ВСЕ файлы в корне сайта по HTTPS. После открытия сайта в Chrome/Edge можно установить игру на телефон как приложение через «Установить приложение» / «Добавить на главный экран».

Для общего Top 100 всё равно нужно заполнить `SUPABASE_URL` и `SUPABASE_ANON_KEY` в `app.js`.


## Visual update
- Fantasy waterfall background is now used across the main screen.
- Bottom navigation uses the new TOP / ACHIEVEMENTS / SHOP / SETTINGS artwork.
- The old GAME button was removed from the bottom navigation.
- Added a lightweight CSS water-shimmer animation to make the waterfalls/water feel slightly alive without adding a heavy video layer.
