# Dompetku Aman — proyek awal

Ini adalah prototipe aplikasi keuangan pribadi berbasis web responsif yang dapat dijadikan dasar untuk aplikasi Android.

## Fitur yang tersedia
- Pencatatan pemasukan dan pengeluaran
- Kategori standar serta kategori "Lainnya" yang bisa diketik
- Edit dan hapus transaksi
- Filter harian, mingguan, bulanan, dan semua waktu
- Ringkasan saldo, pemasukan, dan pengeluaran
- Peringatan anggaran bulanan Rp500.000; peringatan mendekati batas mulai Rp400.000
- Penyimpanan lokal browser
- Ekspor dan impor cadangan JSON
- Antarmuka biru toska, responsif untuk HP

## Cara mencoba di HP
1. Ekstrak ZIP ini jika diperlukan.
2. Buka `www/index.html` di browser atau unggah folder `www` ke layanan hosting statis yang tepercaya.
3. Untuk pengalaman seperti aplikasi, host di HTTPS lalu gunakan menu browser "Tambahkan ke layar utama" jika tersedia.

## Catatan penting
- Ini belum berupa APK Android native.
- Penyimpanan localStorage terkait browser/perangkat dan dapat hilang jika data browser dibersihkan. Gunakan fitur ekspor cadangan.
- Notifikasi anggaran ditampilkan saat aplikasi digunakan dan saat transaksi disimpan; alarm latar belakang tidak berjalan ketika aplikasi/browser benar-benar ditutup.
- Jangan masukkan data keuangan sensitif ke hosting yang tidak dipercaya.
- Untuk APK, bungkus web app dengan alat Android/PWA yang sesuai atau bangun aplikasi native di MIT App Inventor; langkah build dan pengujian masih diperlukan.
