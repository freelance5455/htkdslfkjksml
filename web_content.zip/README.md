# MathScore 14 — Complete Update

This version includes all three requested features:

1. Academic-year management
   - Every class stores its own academic year.
   - Example: 2026/2027.
   - The year appears on the class card and dashboard header.

2. Edit Class
   - Home → My Classes → Edit.
   - Change class name, subject, academic year, term, or maximum mark.
   - Existing students and scores are preserved.

3. Excel student import
   - Students screen → choose an Excel/CSV file.
   - First worksheet is read.
   - Supported name columns: Name, Student Name, Student.
   - Supported index columns: Index, Index Number, Student ID, ID.
   - Imported students are added to the currently selected class.

Important: Excel parsing uses the SheetJS browser library loaded from its CDN. If the APK is configured without network access, use CSV import instead or enable network access in the wrapper.
