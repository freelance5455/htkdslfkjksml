# Metal Kent interaktiv darvozalar katalogi

## Hozirgi prototip
- `index.html` faylini brauzerda ochib katalogni sinab ko'ring.
- `+ Model qo‘shish` orqali model, rasm, o‘lcham, karkas, qoplama va profil/material qatorlarini kiriting.
- Model kartasini bosganda texnik sahifa va karkasning sxematik chizmasi ochiladi.
- Ma'lumotlar brauzerning localStorage xotirasida saqlanadi; brauzer ma'lumotlarini tozalash ularni o'chirishi mumkin.
- Boshlang'ich MK-001 — faqat namuna. Haqiqiy profil o'lchamlari va sarflari kiritilmagan.

## Android APK yig'ish
`android/` papkasini Android Studio'da oching, Gradle sync qiling, so'ng Build > Build APK(s) ni tanlang. APK odatda `android/app/build/outputs/apk/debug/app-debug.apk` ichida hosil bo'ladi.

## Muhim cheklovlar
- Bu loyiha hozircha boshlang'ich prototip. Katalog havolasini ommaga berish uchun hostingga joylashtirish kerak.
- Brauzer xotirasida saqlangan modellar boshqa telefonlarga avtomatik o'tmaydi. Hamma mijozlar uchun bir xil katalog bo'lishi uchun ma'lumotlar bazasi va serverga joylash kerak.
- Karkas SVG chizmasi hozir sxematik; ishlab chiqarish chizmasi o'rnini bosmaydi.


## Brend logotipi
`metalkent-logo.png` katalog sarlavhasida va Android WebView ichida ishlatiladi.

## Android ilova ichidan boshqarish
Android WebView uchun galereya/fayl tanlash oynasini ochish qo‘llab-quvvatlashi qo‘shildi. APK yig‘ilgach, foydalanuvchi ilova ichidagi `Rasm tanlash` maydoni orqali telefonidan rasm tanlay oladi. Kiritilgan modellar va rasmlar ilova ichidagi brauzer xotirasida saqlanadi; ilovani o‘chirib qayta o‘rnatish ma’lumotlarni yo‘qotishi mumkin. Hozircha APK kompilyatsiya qilinmagan.
