# OPTUS Image V1.2.0

A responsive, browser-based image editor. Photos are handled locally in the browser.

## Features
- Open JPG, PNG and WEBP images (up to 25 MB).
- Brightness, contrast, saturation, blur and six filters.
- Rotate and flip controls.
- Text overlay with Arabic-capable browser fonts, color, size, shadow and tap-to-position.
- Crop selection with free, 1:1, 4:5, 3:2 and 16:9 ratios.
- Resize with optional aspect-ratio lock.
- Export as transparent PNG.
- AI background removal with ORMBG through Transformers.js.
- WebGPU acceleration when available; single-thread WASM fallback.
- English and Arabic UI.

## Run
Open `index.html` in a modern browser. For best compatibility, serve the folder through a local static server or HTTPS hosting because browsers may restrict JavaScript modules on `file://` URLs.

## AI model
The first AI background-removal run downloads the Transformers.js runtime and the ORMBG ONNX model from their public repositories. The model is approximately 40–85 MB depending on execution backend and selected model precision. Download sizes can change by model revision. The inference itself runs in the browser; OPTUS does not receive the image.

Model: `Orangebot/ormbg-ONNX` (Apache-2.0)
Runtime: `@huggingface/transformers` 3.8.1 (Apache-2.0)

The model is optimized for human subjects. Hair, pets, transparent objects and busy backgrounds may produce imperfect edges. WebGPU availability varies by browser/device; the WASM CPU fallback may be slower and more battery-intensive on phones.

## Notes
- Internet is required for the first AI model download.
- Local file processing and the non-AI editor tools work without uploading images.
- Large images may use significant phone memory. Keep other heavy apps closed on lower-memory devices.
