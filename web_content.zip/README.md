# FF VIP PANEL — Android starter

A small Android WebView project with a red/black/gold VIP-style dashboard.

## Included
- Native Android launcher activity (Java)
- Local HTML/CSS/JS dashboard
- Four standalone demo-module switches
- No network permission and no game integration

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync (Android Gradle Plugin 8.7.3; compile SDK 35).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated debug APK on your Android device.

## Scope
The controls are UI/demo controls for standalone companion features. This project does not inject into Free Fire, manipulate game memory, automate aiming in a live match, or bypass anti-cheat.
