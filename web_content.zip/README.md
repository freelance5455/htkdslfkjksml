# RN Enterprises Android Project

This is an Android Studio project for the RN Enterprises Electrical Quotation & Billing app.

Features in the bundled app:
- Android-style mobile dashboard
- New Quotation
- New Bill
- Materials & rates
- Customer details
- GST, discount and labour
- Paid / Unpaid / Partial
- History
- Local storage

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select Build > Build APK(s).
4. The debug APK will be in app/build/outputs/apk/debug/app-debug.apk.

Important:
This source project is provided because this environment does not contain a working Android SDK/Gradle build toolchain, so a compiled APK cannot be produced here.
