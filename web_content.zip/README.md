# 🚀 GERÇEK KRİPTO TRADING BOT - Binance API Entegrasyonu

Bu proje, **gerçek kripto fiyat verileri** kullanarak otomatik trading yapan bir bottur.

---

## 📊 Sürümler

### 1️⃣ **Frontend Only** (Real_Crypto_Trading_Bot.html)
✅ **Avantajlar:**
- Kurulum kolay (sadece HTML dosyası)
- Binance Public API kullan (API Key gerekmez)
- Gerçek fiyat verileri alır

❌ **Dezavantajlar:**
- Gerçek trading yapamaz (simülasyon)
- CORS sınırlaması yaşayabilir
- Hassas işlemler için uygun değil

**Kullanım:**
```bash
# Dosyayı tarayıcıda aç
Real_Crypto_Trading_Bot.html
```

---

### 2️⃣ **Backend + Frontend** (Node.js Server)
✅ **Avantajlar:**
- API Key güvenli saklanır (.env dosyasında)
- Gerçek trading yapabilir
- Veritabanı ile veri saklama
- Production ready
- WebSocket real-time updates

❌ **Dezavantajlar:**
- Kurulum daha karmaşık
- Server çalıştırma gerekli
- Binance API Key gerekli

---

## 🔧 Setup - Backend Versiyonu

### 1. Node.js Yükle
```bash
# https://nodejs.org/ adresinden yükle (v14 veya üstü)
node --version  # Kontrol et
npm --version
```

### 2. Dosyaları Kopyala
```bash
mkdir trading-bot
cd trading-bot
# server.js, package.json, .env.example dosyalarını buraya kopyala
```

### 3. Dependencies Yükle
```bash
npm install
# Veya
npm install express axios cors dotenv ws
```

### 4. Binance API Key Al
```
1. https://www.binance.com adresine git
2. "Hesap" → "API Management" tıkla
3. "API Key Oluştur" → "Sistem Tarafından Oluştur"
4. Restrictions: "IP Whitelist" → Sadece kendi IP'nı ekle
5. Enable Spot & Margin Trading, Read-only API key oluştur
6. API Key ve Secret Key'i kopyala
```

### 5. Environment Dosyası Oluştur
```bash
# .env.example'ı .env olarak kopyala
cp .env.example .env

# Dosyayı edit et ve API Key'leri gir
nano .env
# veya
cat > .env << EOF
BINANCE_API_KEY=your_api_key_here
BINANCE_API_SECRET=your_secret_here
PORT=3000
NODE_ENV=development
EOF
```

### 6. Server Başlat
```bash
# Production
npm start

# Development (auto-reload)
npm run dev
```

---

## 📡 API Endpoints

### Fiyat Bilgisi
```bash
# Gerçek fiyat
curl http://localhost:3000/api/price/BTCUSDT

# 24 saatlik veriler
curl http://localhost:3000/api/ticker24h/ETHUSDT

# Mum verileri (1 saat aralıklı, 30 mum)
curl http://localhost:3000/api/klines/BNBUSDT?interval=1h&limit=30
```

### Bot Status
```bash
curl http://localhost:3000/api/bot/status
```

### Pozisyon İşlemleri
```bash
# Pozisyon aç
curl -X POST http://localhost:3000/api/bot/open-position \
  -H "Content-Type: application/json" \
  -d '{"symbol": "BTCUSDT", "quantity": 0.01}'

# Pozisyon kapat
curl -X POST http://localhost:3000/api/bot/close-position \
  -H "Content-Type: application/json" \
  -d '{"positionId": 1234567890}'

# Açık pozisyonları listele
curl http://localhost:3000/api/bot/positions
```

---

## 🎯 Trading Mantığı

### Otomatik İşlemler
1. **Fiyat Takibi**: Her 5 saniyede bir kripto fiyatlarını kontrol et
2. **Trend Analizi**: Fiyat hareketlerini analiz et
3. **Pozisyon Aç**: Alım sinyali görürse pozisyon aç
4. **Risk Yönetimi**: 
   - **Stop-Loss**: -2% zarar durumunda otomatik kapat
   - **Take-Profit**: +5% kar durumunda otomatik kapat
5. **Pozisyon Kapat**: Koşullar sağlanırsa pozisyonu kapat

### Örnek Flow
```
BTC Fiyatı Düşüyor (-2%) → STOP LOSS Tetiklendi → Pozisyon Kapatıldı
BTC Fiyatı Yükseliyor (+5%) → TAKE PROFIT Tetiklendi → Pozisyon Kapatıldı
```

---

## ⚠️ ÖNEMLİ UYARILAR

### 1. **API Key Güvenliği**
```
🚨 API Secret'ı ASLA paylaşma!
🚨 .env dosyasını public repo'ya commit etme!
🚨 Production'da sadece "Read-only" API Key kullan!
```

### 2. **Testable Başlat**
```bash
# Küçük miktarlarla başla
INITIAL_BALANCE=100  # $100 ile başla

# İlk 1-2 haftayı gözlemle
# Algoritma geliştir
# Sonra büyük miktarları dene
```

### 3. **Risk Yönetimi**
```javascript
// Asla tüm balansı kullanma
MAX_POSITIONS=3         // Max 3 açık pozisyon
TRADE_AMOUNT=50         // Trade başı $50
STOP_LOSS_PERCENT=2     // -2% stop loss
TAKE_PROFIT_PERCENT=5   // +5% take profit
```

### 4. **Market Volatility**
- Kripto pazarı 24/7 açıktır
- Beklenmedik fiyat hareketleri olabilir
- Bot her zaman çevrimiçi olması önerilir

---

## 🔍 Troubleshooting

### "CORS Error" hatası
```
Sorun: Frontend'den backend'e erişemiyor
Çözüm: Backend'in CORS kurulu olduğundan emin ol
```

### "API Key Invalid"
```
Sorun: Binance API Key'i yanlış
Çözüm: 
1. .env dosyasını kontrol et
2. API Key'i yeniden kopyala
3. Boşluk/tab karakteri olmadığını emin ol
```

### "Insufficient Balance"
```
Sorun: Pozisyon açmak için yeterli para yok
Çözüm: Balance'ı arttır veya trade amount'u azalt
```

---

## 📈 İleri Kullanım

### WebSocket Bağlantısı (Real-time Data)
```javascript
// Binance WebSocket Stream
const ws = new WebSocket('wss://stream.binance.com:9443/ws/btcusdt@ticker');

ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    console.log('BTC Fiyatı:', data.c); // current price
};
```

### Machine Learning Integration
```python
# Python ile trend prediction
import numpy as np
from sklearn.linear_model import LinearRegression

# Geçmiş verileri al
klines = get_klines('BTCUSDT', limit=100)

# Model eğit
model.fit(X_train, y_train)

# Gelecek fiyatı tahmin et
next_price = model.predict(X_test)
```

### Database Entegrasyonu (MongoDB)
```javascript
// Tüm işlemleri veritabanına kaydet
const trade = {
    symbol: 'BTCUSDT',
    entryPrice: 45000,
    exitPrice: 46000,
    profit: 1000,
    timestamp: new Date()
};

db.trades.insertOne(trade);
```

---

## 📊 Monitoring

### Logs
```
[14:30:45] 🚀 Bot başlatıldı
[14:30:50] 📊 BTC: $45,234 | ETH: $2,456
[14:31:00] 📈 Yeni pozisyon: BTCUSDT x 0.01 @ $45,234
[14:31:30] 💰 TAKE PROFIT: ETHUSDT Kar: +$12.30
[14:32:00] 🛡️ STOP LOSS: BNBUSDT Zarar: -$5.50
```

### Analytics
```
Toplam İşlem: 45
Kazanan İşlem: 28 (62.2%)
Kaybeden İşlem: 17 (37.8%)
Toplam Kar: +$234.50
Win Rate: 62.2%
```

---

## 🚀 Next Steps

1. ✅ Temel bot kurulu
2. ⏳ RSI/MACD Indicators ekle
3. ⏳ Better Entry/Exit Signals
4. ⏳ Machine Learning Integration
5. ⏳ Email/SMS Alerts
6. ⏳ Dashboard UI

---

## 📞 Destek

### Hatalar ve Sorular
1. GitHub Issues açma
2. Logs'ları kontrol et
3. API'nın working olduğundan emin ol

### Kaynaklar
- Binance API Docs: https://binance-docs.github.io/apiDocumentation/
- Node.js Docs: https://nodejs.org/docs/
- Express.js: https://expressjs.com/

---

## ⚖️ Disclaimer

```
⚠️ Bu bot eğitim amaçlıdır!
❌ Gerçek para ile kullanmadan önce backtest yap!
❌ Hiçbir garanti verilmez!
❌ Kripto yatırımı risklidir - sadece kaybedebileceğini yatır!
```

---

**Happy Trading! 📈🚀**
