# Jumping Meadow – Android-Projekt

Dieses Projekt verpackt die bereitgestellte `index.html` als native Android-App mit einer WebView.
Die Spielmechanik, Touch-Steuerung, Wetter, Plattformen, Booster, Highscore, Kostüme und die
im HTML enthaltene Audio-Logik bleiben erhalten.

## APK bauen
1. Projekt in Android Studio öffnen.
2. Gradle-Synchronisierung abwarten.
3. `Build > Build APK(s)` wählen.
4. Die Debug-APK liegt anschließend unter `app/build/outputs/apk/debug/app-debug.apk`.

Hinweis: Die bereitgestellte HTML-Datei enthält den Spielcode. Eine separate `charakter.jpg` wurde
nicht benötigt, weil der Charakter im Canvas gezeichnet wird.
