# Ohm's Law Lab - Ready for APK

This zip is ready to convert to APK.

## What you have
- www/index.html = complete self-contained app (no build needed)
- capacitor.config.json + package.json

## Fastest way to APK (Capacitor)

1. Install Node.js + Android Studio
2. In this folder:
   npm install
   npx cap add android
   npx cap sync
   npx cap open android   # opens Android Studio

3. In Android Studio: Build > Build APK > Debug APK
   APK will be at android/app/build/outputs/apk/debug/app-debug.apk

## No-code alternative (instant APK)

If you don't want Android Studio:
- Upload www/index.html to https://www.pwabuilder.com or https://appsgeyser.com or https://gonative.io
- Or use https://appmaker.xyz - just zip the www folder.

## Also includes WebView wrapper
android-simple/ folder has a minimal native Java wrapper if you don't want Capacitor.

Icon: generate from https://icon.kitchen - use ⚡
