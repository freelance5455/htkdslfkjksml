# DeutschTojik 69 - APK

Номи барнома: **DeutschTojik** (appId: tj.deutschtojik.app)

## Роҳи 1: PWA (бе компютер)
1. Папкаи `www` -ро ба ҳостинги HTTPS бор кунед (Netlify, GitHub Pages).
2. Дар Chrome кушоед, Menu -> "Add to Home screen". Номи барнома DeutschTojik мешавад.

## Роҳи 2: APK (Capacitor, Node 18+ ва Android Studio лозим)
```
npm install
npx cap add android
npx capacitor-assets generate --android   # аз icon.png ва icon-foreground.png
npx cap sync android
cd android && ./gradlew assembleDebug
```
APK: `android/app/build/outputs/apk/debug/app-debug.apk`.
Барои Play Store: Android Studio -> Build -> Generate Signed Bundle.

## Роҳи 3: PWABuilder.com
URL-и ҳостшударо диҳед -> Android -> Download.

## Эзоҳ
- Маълумоти кӯҳна (v67/v68) нигоҳ дошта мешавад; нусха: Танзимот -> Нусха (JSON).
- AI-и онлайн калиди API-ро дар дохили барнома нигоҳ намедорад; бэкенд лозим аст.
