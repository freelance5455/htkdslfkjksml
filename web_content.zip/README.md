# NEXYVERA + Health Connect starter

Included the existing NEXYVERA HTML from NEXYVERA_UPDATE_V3.

## What this starter does
- Wraps the existing NEXYVERA HTML in an Android WebView.
- Requests Health Connect read permission for steps, heart-rate samples, and sleep sessions.
- Reads the last 7 days from Health Connect and passes the result to JavaScript.

## Important limitations
- This does NOT directly connect to the Redmi Watch over Bluetooth.
- It can only read records that another app has actually written into Health Connect.
- If Mi Fitness does not appear in Health Connect or does not write the desired data types, this app will return empty records. The Android app cannot manufacture real readings.
- This is source code, not a compiled APK. Open the folder in Android Studio, sync Gradle, build, install, and test on your own phone.
- Health data permissions are sensitive. Only grant the types you intend to test.

## Connect the HTML UI
The Android bridge is exposed as `window.NexyveraHealth.readHealthData()`.
The native app calls `window.showNexyveraHealthData(data)` if present, otherwise `window.showHealthData(data)`.
To display results in the UI, add a JavaScript function in index.html, for example:
```js
window.showNexyveraHealthData = function(data) {
  console.log("Health Connect result", data);
  // Update the relevant NEXYVERA screen with data.stepsTotal,
  // data.latestHeartRateBpm, and data.sleepSessions.
};
```
You can trigger a read from a button:
```js
window.NexyveraHealth?.readHealthData();
```

## Build
1. Install Android Studio on the Windows laptop.
2. Open this project folder.
3. Let Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Test first on the Redmi 13. If Health Connect says no data, verify the source app writes records and the requested permissions are granted.
