# Sora 4 UI — v2

Внутри:
- логотип из предоставленного изображения;
- экран входа/регистрации без обязательной проверки в UI;
- Text-to-Video и Image-to-Video;
- выбор фото из телефона;
- Omni 1.1 Flash: 8/10 сек + 360p/720p;
- Seedance 2.0: 10 сек, качество скрыто;
- 16:9 / 9:16;
- длинная плавная последовательность этапов;
- история генераций;
- Developer Menu для загрузки видео по ID;
- Supabase polling для автоматического появления результата;
- очень плавные переходы, blur, glow и micro-interactions.

## Запуск на телефоне
Распакуй ZIP и открой `index.html` в Acode/браузере.

## Supabase
Открой Settings и вставь URL и Anon Key.

Создай Storage bucket `videos` и таблицу:

create table video_results (
  job_id uuid primary key,
  video_url text not null,
  created_at timestamptz default now()
);

Нужны подходящие RLS policies для твоего проекта.

Важно: экран входа сделан как UI-вход без обязательной верификации. Если подключать реальную Supabase Auth позже, можно заменить функцию enter() на signIn/signUp.
