# VIP Like Generator

VIP Like Generator es un command center responsive para gestionar solicitudes de likes de Free Fire con una interfaz gaming premium. La aplicación muestra siempre el estado real devuelto por el backend: una solicitud pendiente no se presenta como una entrega confirmada.

## Stack

El proyecto usa React + TypeScript + Vite en el cliente, Node.js + Express en el servidor, Fetch API para la comunicación con el proveedor y Drizzle/MySQL para conservar solicitudes y métricas administrativas. El starter de Webdev aporta la autenticación Manus OAuth; el panel admin utiliza el rol `admin` validado server-side.

## Desarrollo local

```bash
pnpm install
pnpm check
pnpm dev
```

El servidor escucha en `http://localhost:3000` (o en el valor de `PORT`). El esquema de base de datos ya incluye la migración `drizzle/0001_hot_medusa.sql`; para aplicar migraciones pendientes se puede ejecutar:

```bash
pnpm db:migrate
```

La interfaz también es compatible con WebViews móviles usadas al convertir el proyecto en app. Si Android o iOS bloquean `localStorage`, la aplicación continúa renderizando y usa valores temporales para el historial y los temas.

No se necesita una clave del proveedor en el navegador. La URL del proveedor está definida como configuración de integración del servidor: `https://vip-like-api-ehd8.onrender.com`.

## Integración con la API de Render

La aplicación server-side consulta los endpoints reales del proveedor:

| Operación | Endpoint del proveedor | Uso |
| --- | --- | --- |
| Salud | `GET /api/health` | Estado de conexión y latencia |
| Solicitud | `POST /api/likes` | Envía `{ "playerId": "123456789" }` |
| Raíz | `GET /` | Endpoint disponible para diagnóstico manual |

El navegador llama a `/api/provider-health` y `/api/likes` en la aplicación VIP. Express actúa como proxy con timeout de 12 segundos, valida el ID como una cadena de 6 a 15 dígitos y conserva la respuesta JSON del proveedor. Solo se muestra `Confirmado` cuando la respuesta contiene una señal explícita de confirmación; cualquier respuesta pendiente se muestra como `Pendiente de proveedor autorizado`.

## Render

Para desplegar el proyecto en Render, usa un Web Service con el repositorio del proyecto. El comando de build es `pnpm install --frozen-lockfile && pnpm build`, el comando de inicio es `pnpm start`, y el health check es `/api/health`. El servicio debe escuchar en `PORT`, que el servidor ya respeta y que por defecto es `3000`. Configura `DATABASE_URL` con una base MySQL compatible si el despliegue no utiliza la base gestionada de Manus. No pongas credenciales en archivos del cliente ni en el repositorio.

En el proyecto gestionado, la configuración de contenedor ya declara `Dockerfile` y `/api/health`. La base gestionada se comparte entre desarrollo y publicación; ejecuta migraciones solo cuando corresponda y evita borrar tablas o datos existentes.

## Panel de administración

El panel `/` se abre desde la pestaña Administración, pero las métricas solo se entregan a una sesión autenticada cuyo rol sea `admin`. La sesión real se valida mediante el starter Manus OAuth y la misma política server-side de `sdk.authenticateRequest` + rol `admin` que usa `adminProcedure`; no existe una contraseña hardcodeada ni un bypass de frontend. El endpoint protegido es `GET /api/admin/stats`.

Para que la cuenta propietaria quede como admin, se conserva la regla del starter que asigna el rol `admin` al `ownerOpenId`. Para otros administradores, cambia el rol desde la base de datos con un procedimiento operativo seguro, nunca desde JavaScript del navegador.

## Pruebas realizadas

- `pnpm check`: correcto.
- `pnpm build`: correcto; genera cliente Vite y bundle Express.
- `GET /api/health`: responde estado del servicio VIP.
- `GET /manus-routes.json`: responde el manifiesto de rutas válido.
- `GET https://vip-like-api-ehd8.onrender.com/api/health`: comprobado con respuesta HTTP 200 durante la validación.
- `POST /api/likes` con un ID inválido: devuelve HTTP 400 sin contactar al proveedor.
- Capturas de revisión visual en escritorio y móvil: layout responsive correcto.

## Estructura relevante

- `client/src/pages/Home.tsx`: dashboard, generador, historial, temas, configuración y panel admin.
- `client/src/index.css`: sistema visual Neon Command Center, temas oscuros/claros y responsive.
- `server/_core/index.ts`: health, proxy, validación y endpoint admin.
- `drizzle/schema.ts`: usuarios y tabla `like_requests`.
- `server/db.ts`: consultas de usuarios, historial y métricas.
- `client/public/manus-routes.json`: rutas públicas declaradas.
