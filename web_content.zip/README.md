# Reading PDF — base inicial

Este paquete es el punto de partida del proyecto Reading PDF.

## Estado honesto
Esta entrega contiene una base de interfaz PWA y un esqueleto Android nativo con WebView e intención para recibir PDF. **Todavía no es un lector PDF terminado ni una APK compilada**. No están implementados aún el motor PDF, desbloqueo/exportación, firma, impresión ni pruebas en dispositivo.

## Estructura
- `pwa/`: interfaz web instalable y recursos PWA.
- `app/`: esqueleto Android nativo.
- El icono original proporcionado se conserva sin modificar en `pwa/icons/` y en los assets Android.

## Próxima etapa
Integrar y probar un motor PDF Android que soporte visualización, contraseña válida, exportación descifrada y firma manuscrita; luego completar el puente nativo para SAF, compartir, imprimir y apertura externa.

## Compilar Android
Abrir la carpeta raíz en Android Studio una vez completados los archivos Gradle del proyecto. Esta base requiere completar la configuración Gradle/SDK antes de compilarse.
