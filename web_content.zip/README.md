# Хорар AI — Android + API

Българско приложение за хорарни въпроси с традиционна западна хорарна рамка, обяснения на достъпен език и проверки за несъответствия.

## Важно за статуса
Това е разширен стартов проект с работещ интерфейс и backend scaffold. Не е подписан APK/AAB и не е готов за публикуване в Google Play, преди да бъдат изпълнени проверките в RELEASE_CHECKLIST.md. Не твърди, че астрологията е научно валидирано предсказване.

## Компоненти
- `android/`: Kotlin + Jetpack Compose app.
- `backend/`: FastAPI endpoint, изчислителен слой чрез Swiss Ephemeris (pyswisseph) и optional OpenAI explanation endpoint.
- `docs/`: правила за интерпретация, поверителност и checklist.

## Лицензиране
`pyswisseph`/Swiss Ephemeris има лицензионни условия, които трябва да се проверят преди публично или търговско публикуване. Swiss Ephemeris обичайно се предлага под AGPL или търговски лиценз; избери съвместим лиценз за цялото приложение, преди да го пускаш. Не включвай ефемеридни файлове, без да провериш правата за разпространение.

## Backend setup
Python 3.11+ recommended.

```bash
cd backend
python -m venv .venv
# activate venv
pip install -r requirements.txt
cp .env.example .env
# Set OPENAI_API_KEY only in backend environment, never in Android code.
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Open `http://127.0.0.1:8000/docs` to inspect the API.
For Android emulator, `10.0.2.2:8000` reaches the host machine. For real devices and release builds, use a secured HTTPS endpoint.

## Android build
Open `android/` in Android Studio (JDK 17). Sync Gradle, run on emulator/device.
The app currently includes an optional manual location coordinate entry. The included default coordinates are for Burgas, Bulgaria. Update the backend base URL in `Api.kt` before using on a physical device or publishing.

## Accuracy model
The application separates:
1. Ephemeris/chart facts (deterministic calculations).
2. Traditional rule-based indicators.
3. Bulgarian-language AI explanation of supplied facts.
4. A transparent internal consistency score.

The percentage is not a calibrated real-world probability. Never display it as “40% chance that the event will happen.” It reflects only clarity/consistency of the symbolic interpretation.

## Build a debug APK in GitHub Actions
A workflow is included at `.github/workflows/build-apk.yml`. If you upload this project to a GitHub repository, open **Actions → Build debug APK → Run workflow**. After the run succeeds, download the `HoraryAI-debug-apk` artifact and install `app-debug.apk` on your Android phone. This is a debug build, not a Play Store release.

## Current prototype limitations
The ephemeris layer calculates planetary longitudes and Placidus houses, but the rule-based judgment is intentionally preliminary. Moon void-of-course and applying/separating aspect detection are not yet a validated full traditional horary implementation. Do not use the current verdict as a dependable prediction until the rule engine is tested and reviewed.
