# Helix City (Android app project)

The game is in `www/index.html`. The 3D engine (three.js) is copied into `www/` by the build, so the finished app works offline.

## Build the APK online with GitHub (no PC tools needed)

1. Create a free GitHub account and a new empty repository.
2. Upload everything in this folder, including the hidden `.github` folder.
3. Open the repository's **Actions** tab, choose **Build APK**, and press **Run workflow**.
4. When it finishes (about 5 minutes), open the run and download `helix-city-apk` under **Artifacts**.
5. Unzip it and copy `app-debug.apk` to your phone. Open it and allow "Install unknown apps" when asked.

## Build on your computer

Needs Node.js 20+, Java 17 and Android Studio.

```
npm install
cp node_modules/three/build/three.min.js www/three.min.js
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
```

The APK is at `android/app/build/outputs/apk/debug/app-debug.apk`.

## Notes

- The app runs in landscape. Drag on the left to move or steer, drag on the right to look. Buttons change with your mode: on foot, driving or hero.
- The debug APK is for your own phone. Google Play needs a signed release build.
