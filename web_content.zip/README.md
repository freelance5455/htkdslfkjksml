# CryptoTrader Mobile v4 — Server Panel

Este pacote é o painel móvel. O motor de análise corre no servidor 24/7.

1. Importa `index.html` na tua ferramenta HTML-to-APK.
2. Abre a aba **Servidor** e coloca o endereço do motor.
3. Na mesma Wi‑Fi podes usar, por exemplo, `http://192.168.1.50:8000`.
4. Para acesso pela Internet, usa HTTPS e autenticação no servidor.

O painel mostra património, caixa, posições, exposição, operações e estado do motor.
Continua em paper trading e não contém chaves da Binance.
