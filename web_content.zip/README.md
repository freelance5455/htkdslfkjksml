# NeruNeruNeruNe Music Maker Studio – DAW Beatmaker

Aplicativo Android baseado em HTML5 + JavaScript + Capacitor. Inclui sequenciador de 16 passos, seis pads sintetizados, controle de BPM, gravação pelo microfone, salvamento de projeto JSON e exportação de áudio WAV/MP3.

## Requisitos
- Node.js 20 ou superior (recomendado)
- Android Studio atualizado
- Android SDK instalado
- JDK 17 ou compatível com a versão do Android Gradle Plugin instalada pelo Capacitor

## 1. Preparar o projeto
Extraia o ZIP, abra um terminal na pasta do projeto e execute:

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

Se a pasta `android` já existir, não execute `npx cap add android` novamente. Basta usar `npm run android:sync` e `npm run android:open`.

## 2. Gerar APK no Android Studio
1. Aguarde o Gradle concluir a sincronização.
2. Conecte um Motorola por USB com Depuração USB ativada, ou escolha um emulador.
3. Para testar, clique em **Run**.
4. Para gerar APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O Android Studio mostrará o caminho do APK, normalmente `android/app/build/outputs/apk/debug/app-debug.apk`.
6. Copie o APK para o telefone e abra-o para instalar. Se necessário, autorize a instalação desse arquivo pelo gerenciador de arquivos.

Para APK de distribuição, use **Build > Generate Signed Bundle / APK** e crie/seleciona uma chave de assinatura. Guarde a chave com segurança.

## 3. Como usar
- Toque nos quadradinhos para ativar/desativar cada batida.
- Ajuste o BPM e toque em **Tocar**.
- Use os pads para disparar sons.
- **Gravar microfone** pede permissão de áudio; pare a gravação para ouvir.
- **Exportar MP3** renderiza o padrão atual e salva/compartilha o arquivo.
- **Exportar WAV** gera uma cópia sem compressão.
- **Salvar projeto** baixa/compartilha um JSON com o padrão e o BPM.

## Observações importantes
- A exportação MP3 usa o codificador `lamejs` empacotado na compilação. A primeira compilação requer internet para baixar dependências.
- A interface carrega a fonte Nunito do Google Fonts; sem internet, usa uma fonte local de sistema.
- O app gera sons originais por síntese; não inclui músicas comerciais.
- A gravação do microfone usa o formato de gravação suportado pelo WebView/Android (geralmente WebM/Opus). A exportação do padrão musical é MP3 ou WAV.
- Para publicar na Play Store, configure política de privacidade, classificação etária, ícone definitivo e assinatura de lançamento.
