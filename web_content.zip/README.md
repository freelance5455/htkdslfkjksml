# HTML TO APK STUDIO — Your Website. Your Android App.

HTML, CSS ve JavaScript web projelerini **Kotlin Android WebView + Android SDK / Gradle** tabanlı gerçek, imzalanmış Android `.apk` paketlerine dönüştüren; kullanıcı hesapları, Adaptive Android İkon Stüdyosu, Premium abonelik ve promosyon kodu sistemi, HMAC imzalı ödeme doğrulaması ve tam yönetici konsoluna sahip profesyonel SaaS platformu.

## Mimari Genel Bakış

- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Açık ve Koyu (Light / Dark) çift tema desteği (`Plus Jakarta Sans`, `DM Sans`, `JetBrains Mono`), Lucide Icons, sözdizimi vurgulu kod inceleyicisi
- **Backend**: Node.js, Express.js REST API, `better-sqlite3` (WAL modunda kalıcı SQLite veritabanı), `multer` + `adm-zip` güvenli dosya/ZIP işleme (ZIP Slip & Path Traversal koruması), HttpOnly JWT oturum çerezleri, double-submit CSRF koruması, `express-rate-limit`
- **Android Şablonu**: Kotlin (`MainActivity.kt`, `SplashActivity.kt`), `WebViewAssetLoader` (`https://appassets.androidplatform.net/assets/www/` üzerinden çevrimdışı önbellek destekli güvenli asset sunumu), `AndroidManifest.xml`, `build.gradle.kts`, Adaptive Icon (`mipmap-anydpi-v26/ic_launcher.xml` ve `mdpi`–`xxxhdpi` çoklu yoğunluk kaynakları)
- **Derleme Altyapısı**: Yerel Android SDK 34 (`aapt2`, `d8`, `zipalign`, `apksigner` + OpenJDK 17) veya `android-build/Dockerfile` üzerinden izole Docker Gradle derleme konteyneri

## Veritabanı Tabloları (`data/studio.db`)

- `roles`, `users`, `password_resets`
- `projects`, `project_files`
- `builds`, `build_files`
- `subscription_plans` (`Aylık Premium 150 TL / 30 gün`, `Yıllık Premium 1.000 TL / 365 gün`, `Kalıcı Premium 2.000 TL / Süresiz`)
- `subscriptions`, `build_usage`, `system_limits`, `system_settings`
- `payments`, `payment_events` (HMAC-SHA256 webhook imza doğrulaması ve replay/idempotency koruması)
- `promo_codes`, `promo_redemptions`
- `notifications`, `error_logs`, `audit_logs`

## Kurulum ve Çalıştırma

```bash
npm install
cp .env.example .env
# .env içinde JWT_SECRET, PAYMENT_WEBHOOK_SECRET ve ADMIN_PASSWORD değerlerini tanımlayın
npm run dev
```

Sunucu varsayılan olarak `http://localhost:3000` adresinde çalışır.

## Android APK Derleme Altyapısı (Yerel Android SDK / Docker)

Platform, yerel **Android SDK 34 + OpenJDK 17** (`direct_apk`) veya **Docker izole Gradle konteyneri** (`docker_gradle`) ile doğrudan Android cihazlara kurulabilir ve imzalanmış `.apk` dosyaları üretir.

Docker ile izole derleyici kurmak için:

```bash
docker build -t html-to-apk-builder:latest ./android-build
```

Yerel Android SDK veya Docker aktif olmadığında tam derlenebilir Kotlin/Gradle proje paketi (`.zip`) üretilir.

## API Uç Noktaları

- **Kimlik Doğrulama & Hesap**: `POST /api/auth/register`, `POST /api/auth/login`, `POST /api/auth/logout`, `GET /api/auth/me`, `PUT /api/auth/profile`, `PUT /api/auth/password`, `POST /api/auth/avatar`, `POST /api/auth/forgot-password`, `POST /api/auth/reset-password`
- **Projeler & Dosyalar**: `POST /api/projects/upload`, `POST /api/projects/create`, `GET /api/projects`, `GET /api/projects/:id`, `PUT /api/projects/:id/file`, `PUT /api/projects/:id/config`, `DELETE /api/projects/:id`, `GET /api/projects/:id/android-preview`
- **APK Derleme Hattı**: `POST /api/build`, `GET /api/builds`, `GET /api/build/:id/status`, `GET /api/build/:id/download`, `POST /api/build/:id/cancel`
- **Bildirimler**: `GET /api/notifications`, `POST /api/notifications/:id/read`, `POST /api/notifications/read-all`
- **Premium, Promosyon & Ödeme**: `GET /api/plans`, `POST /api/promo-codes/validate`, `POST /api/payments/checkout`, `POST /api/payments/webhook/verify` (`GET /api/auth/me` satın alma geçmişini içerir)
- **Yönetici Paneli (`role === 'admin'`)**: `GET /api/admin/overview`, `PUT /api/admin/users/:id/role`, `POST /api/admin/subscriptions/grant`, `POST /api/admin/subscriptions/:id/extend`, `POST /api/admin/subscriptions/:id/cancel`, `PUT /api/admin/plans/:id`, `PUT /api/admin/limits/:tier`, `PUT /api/admin/settings`, `POST /api/admin/promo-codes`, `PUT /api/admin/promo-codes/:id`, `DELETE /api/admin/promo-codes/:id`
- **Yöneticiye Özel Kaynak Kodu ve Dosya Gezgini (`role === 'admin'`)**: `GET /api/admin/code-explorer/tree`, `GET /api/admin/code-explorer/project-file`, `GET /api/admin/code-explorer/project-zip`, `GET /api/admin/code-explorer/android-files`, `GET /api/admin/builds/:id/download`, `GET /api/system/source-files`, `GET /api/system/source-file`, `GET /api/system/source-archive`

## Yönetici Hesabı Kurulumu

- Yönetici e-postası varsayılan olarak `ADMIN_EMAIL` (`admin@htmltoapk.studio`) ortam değişkeninden okunur.
- İlk yönetici parolası yalnızca güvenli ortam değişkeni (`ADMIN_PASSWORD`) üzerinden tanımlanır ve veritabanında `bcrypt` hash'i olarak saklanır. `ADMIN_PASSWORD` tanımlı değilse sistem ilk kurulumda rastgele tek seferlik bir parola üretip yalnızca sunucu konsoluna yazar; arayüzde veya dokümantasyonda varsayılan parola bulundurulmaz.
