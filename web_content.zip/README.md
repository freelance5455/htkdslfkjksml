# Raynox AI — HTML package

This is a standalone, mobile-first HTML version of the Raynox AI interface. The original ZIP was a native Kotlin/Jetpack Compose Android Studio project, so this package provides a separate web interface that an HTML-to-APK wrapper can load.

## Files
- `index.html` — main app interface
- `style.css` — responsive dark Raynox theme
- `script.js` — chat, date/time context, Gemini API calls, local settings/history, voice input/output
- `manifest.json` — basic web app metadata

## Run it
1. Extract the ZIP.
2. Open `index.html` in a modern browser, or import the folder into your HTML-to-APK converter.
3. Open **Settings & API key** and enter your own Google AI Studio Gemini API key.
4. Save settings and send a message. An internet connection is required for AI replies.
5. Allow microphone permission if you want to use voice input.

## Important limitations
- The clock and date context use the device's current time formatted for India Standard Time (`Asia/Kolkata`).
- Voice input depends on browser support for the Web Speech API and may need an internet connection. Voice output depends on browser speech synthesis support.
- An HTML page cannot reliably listen for a wake word while the screen is off, run a persistent Android foreground service, or control phone settings/apps like a native Android app. Those capabilities require a native Android implementation and explicit Android permissions.
- The Gemini key is entered by the user and stored in the browser's local storage. This is convenient for personal testing but is **not safe for a publicly distributed app** because browser-side keys can be extracted. For a public release, use a backend service to protect the key and apply usage limits.
- This web package is not an APK. Use a trusted HTML-to-APK wrapper to package it; some wrappers restrict microphone access or cross-origin API requests.

## Troubleshooting
- If you see “Gemini is not connected,” open Settings and add a valid API key.
- If an API request fails, check the key, selected model, internet connection, and whether your API key has access/quota for that model.
- If voice input does not work, try a current Chrome-based browser and grant microphone permission.
