# NOVA ULTIMATE AI STUDIO

Application web légère (HTML/CSS/JS, sans Node) : `index.html` est à la racine. Zippez/convertissez en APK tel quel (le dossier `backend/` n'est pas utilisé par l'APK ; vous pouvez le retirer du ZIP envoyé au convertisseur).

## Ce qui fonctionne réellement
Assistant, images, vidéo (par séquences), musique, voix, film par chapitres (chapitres → scènes → image → clip vidéo, progression sauvegardée et reprise), bibliothèque, export ZIP. **Tout passe par votre serveur** : sans serveur, ces fonctions affichent « indisponible ». Aucun faux résultat.

## Limites honnêtes
- Aucun moteur d'IA ne tourne dans l'APK et aucun service de qualité n'est gratuit, illimité et sans compte. Il faut des comptes (OpenAI ou compatible, Replicate…) : les générations sont payantes ou limitées selon le fournisseur.
- Les clips vidéo IA durent quelques secondes ; un film = plusieurs clips. La lecture enchaîne les clips dans l'app. **L'assemblage MP4 unique (ffmpeg), le montage avancé, les sous-titres incrustés, le mixage voix/musique, les mangas paginés et l'export PDF ne sont pas inclus** : ils exigent un serveur ffmpeg et un moteur de mise en page non fournis ici.
- La cohérence des personnages repose sur une fiche texte réinjectée dans chaque prompt et l'image de départ des vidéos ; elle n'est pas parfaite.
- Les entrées des modèles Replicate varient (`prompt`, `image`) : adaptez `VIDEO_MODEL`/`MUSIC_MODEL` si besoin.
- Le convertisseur de projets web en APK n'est pas intégré : il demande une chaîne de compilation Android.

## Installer le serveur (gratuit pour démarrer, sans terminal)
1. Compte gratuit sur cloudflare.com → Workers & Pages → Créer un Worker → collez `backend/worker.js` → Déployer.
2. Réglages du Worker → Variables et secrets : `APP_TOKEN` (mot de passe de votre choix), `CHAT_KEY`, `CHAT_MODEL`, `IMAGE_KEY`, `IMAGE_MODEL`, `TTS_KEY`, `TTS_MODEL`, `REPLICATE_KEY`, `VIDEO_MODEL` (ex. `owner/modele`), `MUSIC_MODEL`. Facultatif : `CHAT_URL`, `IMAGE_URL`, `TTS_URL` (autre fournisseur compatible OpenAI), `ALLOWED_ORIGIN`.
3. Dans l'app → Réglages : URL du Worker + `APP_TOKEN` → « Tester la connexion » (indique quels moteurs sont configurés).
Le jeton `APP_TOKEN` est saisi sur l'appareil ; les clés des moteurs ne quittent jamais le serveur.
