# MI ORGANIZADOR — Native Master V3

Esta versión conserva la interfaz de MI ORGANIZADOR y refuerza la integración Android nativa.

## Cambios de esta V3
- Selector nativo con dos rutas: Fotos y videos (Photo Picker cuando está disponible) o Documentos/otros archivos (Storage Access Framework).
- Cámara mediante `MediaStore.ACTION_IMAGE_CAPTURE` + `FileProvider`, sin depender de un `<input capture>` de la WebView.
- Persistencia de los archivos importados en almacenamiento privado de la app.
- Compartir mediante Android `ACTION_SEND` + `FileProvider`.
- Recepción de contenido compartido desde otras aplicaciones.
- Notificaciones y recordatorios nativos.
- Diagnóstico visible en Ajustes para comprobar que el puente Android realmente está activo.
- Se eliminó la dependencia innecesaria del permiso CAMERA para el flujo de cámara mediante Intent.

## Importante
Este proyecto es una aplicación Android nativa/híbrida real. Un servicio que solamente empaquete `index.html` en un APK no ejecutará esta capa Java y volverá a producir el comportamiento de "maqueta" observado anteriormente.

## Construcción
Abrir la carpeta raíz en Android Studio y ejecutar `app` en un dispositivo Android. Este entorno de ChatGPT no contiene el Android SDK/build-tools, por lo que no se afirma que aquí se haya generado un APK final.

## Reconocimiento IA
La clasificación incluida conserva una primera capa local basada en nombre/metadatos. La visión/OCR avanzado queda desacoplada para incorporar un motor real de visión/OCR sin modificar la organización por proyectos.
