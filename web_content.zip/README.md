# M. Ayaz Business Manager — Android Project

یہ Android Studio/Gradle project ہے۔ موجودہ functional web prototype کو Android WebView کے اندر offline app کے طور پر package کرتا ہے۔

## اہم بات
یہ source project ہے، APK نہیں۔ اس ماحول میں Android SDK/Gradle build tools دستیاب نہ ہونے کی وجہ سے APK یہاں compile نہیں کی گئی۔

## Build
Android Studio میں project folder کھولیں، Gradle sync ہونے دیں، پھر:
Build > Build APK(s)

APK عام طور پر:
app/build/outputs/apk/debug/app-debug.apk

## موجودہ prototype
app/src/main/assets/webapp/

اس فولڈر میں موجود web app کو Android app کے اندر load کیا جاتا ہے۔


## GitHub Actions — APK build
1. اس پورے project کو GitHub repository میں upload کریں۔
2. اوپر **Actions** کھولیں۔
3. **Build Android APK** workflow منتخب کریں۔
4. **Run workflow** دبائیں۔
5. Build مکمل ہونے کے بعد **M-Ayaz-Business-Manager-APK** artifact سے APK حاصل کریں۔
