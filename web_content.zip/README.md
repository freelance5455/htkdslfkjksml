# Masroufi DH - Package Mobile Android & PWA

Hada l-package l-kamel dyal Masroufi pour Android et mobile.

## 3 Tora9 sahlin bach t-khedmo f telephone (Android / Google Pixel):

### 1. Tari9a 1 (As-hal w Asra3 tari9a - WebAPK direct bla PC):
L'application m9ada b les normes PWA (Progressive Web App):
- Khoud l-fichier `index.html` w hlo f Google Chrome f l-portable dyalek.
- F Chrome, cliqui 3la l-menu (3 no9at l-fo9 3la limen ⋮).
- Cliqui 3la **"Installer l'application"** (أو "Ajouter à l'écran d'accueil").
- Google Play Services ghadi t-générer lik **WebAPK automatique** f telephone m3a l'icône, splash screen w plein écran sans barre d'adresse ! Katkhedem bhal ay application native.

### 2. Tari9a 2 (Générer l-fichier .APK en 1 clic en ligne):
Ila bghiti fichier `.apk` direct li t9der tsiftou f WhatsApp aw t-installih:
- Dkhol l site gratuit: **https://www.pwabuilder.com** (dyal Microsoft) ou **https://web2apk.com**
- Upload l-projet dyalek (aw hoto f hébergement gratuit bhal GitHub Pages / Vercel / Netlify f 1 minute).
- Cliqui 3la "Build APK" -> ghadi يعطيك fichier `Masroufi.apk` téléchargeable direct !

### 3. Tari9a 3 (Android Studio - Code source fourni):
Ila bghiti t-compilih b yeddek f Android Studio:
- Le dossier `android_studio_project` fih le code source Kotlin complet m3a WebView configuré.
- Ouvre le dossier dans Android Studio -> Clic sur **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
