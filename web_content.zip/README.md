# ROTA YKS - Planlayıcı & Net Takip

YKS Hazırlık süreciniz için ders programı ve TYT/AYT deneme net takip web uygulaması.