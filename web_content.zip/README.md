# Rinkaj Wiring Waale Android App

This Android Studio project wraps the supplied Rinkaj Wiring Waale HTML website in a native Android WebView.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select **Build > Build APK(s)**.
4. Install the generated APK on an Android phone.

The supplied website is included at `app/src/main/assets/index.html`.
