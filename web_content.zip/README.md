# JURITI GAMER TURBO — ajustes do painel flutuante

- Os estados dos perfis Priorizar bateria, Equilibrado e Modo gamer aparecem como selo pequeno e centralizado no clique. “Ativado” usa ✓ verde; “Desativado” usa ✗ vermelho.
- As transições do painel e a mudança de perfil foram suavizadas.
- A bolinha fica sobre a borda superior do painel aberto; ao arrastá-la, o painel acompanha sua posição.
- Projeto-fonte ZIP; não é um APK compilado nem testado em dispositivo físico.

# JURITI GAMER TURBO — v1.8.0

Ajuste visual dos selos de estado dos perfis Priorizar bateria, Equilibrado e Modo gamer. Os selos ATIVADO e DESATIVADO agora usam o mesmo tamanho compacto, ficam na parte inferior do botão e não truncam o nome do perfil. Nenhuma ação ou ordem de botões foi alterada.

Esta entrega é o projeto-fonte ZIP; não representa um APK compilado ou testado em dispositivo.

# JURITI GAMER TURBO 1.6.5

Atualização da aba **Otimização**, baseada no projeto 1.6.4.

## Organização
- Recursos Shizuku disponíveis
- Jogos e desempenho: Game Mode, impulso gamer, prioridade de espera e otimização ART
- Sistema e memória: limpeza de cache e Não Perturbe
- Tela e interface: escalas de animação e taxa de atualização suportada
- Conectividade: DNS privado
- Diagnóstico de compatibilidade CPU/GPU

## Observações técnicas
- É necessário iniciar o Shizuku e conceder autorização ao JURITI para os comandos shell.
- Game Mode depende de Android 12+ e suporte do fabricante.
- ART solicita compilação `speed-profile`; não promete aumento de FPS.
- Limpeza usa `pm trim-caches`; o Android decide o que pode ser removido. Não apaga dados pessoais.
- DNS privado e taxa de atualização são confirmados pela leitura de estado/modos quando possível.
- CPU/GPU não são forçadas: muitos aparelhos bloqueiam frequências/governadores sem root ou interface OEM.
- Não Perturbe usa a API de política de notificações e exige autorização específica do Android.
- Este pacote contém o projeto-fonte. Não é um APK compilado.


## v1.6.7 — Ações rápidas e limpeza segura
- Restaurada a seção Ações Rápidas na aba Otimização: Não Perturbe, animações 0,5x/1x, limpeza de cache recuperável e encerramento de processos em cache via `am kill-all`.
- `am kill-all` solicita ao Android encerrar processos em cache; não força encerramento de apps em primeiro plano ou processos protegidos e não garante RAM livre permanentemente.
- CPU/GPU/kernel: não há escrita forçada de frequência/governador ou parâmetros do kernel. Shizuku executa como shell/ADB, não como root; sysfs e controles do fabricante normalmente permanecem protegidos. Limites térmicos não são desativados.
- A limpeza usa `pm trim-caches`; não apaga dados, contas, fotos ou arquivos pessoais.


## v1.7.0 — Gravador flutuante
- Segunda bolinha de gravação aparece somente quando o painel flutuante é aberto.
- Usa a autorização MediaProjection do Android; tocar novamente encerra a gravação.
- Vídeo MP4 salvo em Filmes/JURITI (Android 10+) ou pasta privada de filmes do app em versões anteriores.
- Esta implementação grava vídeo sem áudio; captura de áudio interno do jogo ainda não está implementada.
- A gravação pode ser interrompida pelo Android ou pelo fabricante e exige autorização a cada sessão.

## v1.7.3 — permissões manuais do gravador e atalhos compactos
- Fluxo de autorização do gravador solicita a permissão de notificações (Android 13+) e microfone por diálogos do sistema, seguindo depois para a autorização oficial de captura de tela do Android.
- Se o usuário negar o microfone, a captura de tela ainda pode iniciar sem áudio; a autorização de captura de tela continua obrigatória a cada sessão.
- Cartões das nove Ações Rápidas reduzidos para dimensões mais proporcionais em telas pequenas, mantendo grade de três colunas.
- A compilação do APK ainda precisa ser executada em ambiente com distribuição Gradle disponível.

## v1.7.4 — Gravador integrado ao painel flutuante
- Removida a segunda bolinha independente do gravador.
- Incluído cartão GRAVADOR DE TELA dentro do painel flutuante, com botão iniciar/parar.
- O botão inicia o fluxo de autorização oficial MediaProjection e atualiza o estado enquanto o serviço de gravação está ativo.
- Mantido o painel compacto com ações rápidas e métricas.
- A captura continua limitada ao vídeo e ao áudio do microfone quando autorizado; áudio interno, resoluções selecionáveis e ferramentas de desenho ainda não fazem parte desta versão.


## v1.7.5 — Redesign visual do painel flutuante
- Atualização somente visual do painel flutuante: acabamento neon roxo, cartões e indicadores com estilo gamer.
- Mantidos os IDs, callbacks e funções existentes dos controles.
- Perfis permanecem juntos na última fileira, na sequência: Priorizar Bateria, Equilíbrio e Modo Gamer.
- Nenhuma função nova ou promessa de compatibilidade foi adicionada nesta revisão.
- Projeto fonte; requer compilação e teste no dispositivo.


## Versão 1.7.8 — remoção do gravador de tela
- Removido o cartão e os controles de gravação do painel flutuante.
- Removidos os serviços e a tela de autorização MediaProjection.
- Removidas as permissões RECORD_AUDIO e FOREGROUND_SERVICE_MEDIA_PROJECTION, que não são mais necessárias.
- As demais opções e ações do painel foram preservadas.


## v1.8.1 — ampliação da aba Otimização
- Adicionados atalhos para configurações nativas de bateria, entrada, áudio, driver de jogos, tela, armazenamento e Não Perturbe.
- Adicionado Turbo Tester com consultas predefinidas de informações do aparelho, bateria, estado térmico, memória, tela e DNS/rede via Shizuku.
- Adicionado catálogo de consultas de leitura do Turbo Shell; não aceita comandos livres vindos da WebView.
- Adicionada consulta de propriedades selecionadas do Android em modo somente leitura. Propriedades arbitrárias não são alteradas.
- Os recursos existentes de Game Mode, ART, DNS privado, taxa de atualização, espera de apps e animações foram preservados.
- As consultas de diagnóstico requerem Shizuku iniciado e autorização concedida. Saída e compatibilidade dependem do fabricante/versão Android.
- Não foram implementados add-ons executáveis de terceiros nem escrita arbitrária em propriedades, por segurança e porque o projeto não possui um formato/API de plugins definido.
- Projeto-fonte; requer compilação e teste em dispositivo físico.


## Addons Juriti extensíveis (ZIP)
Os pacotes ZIP aceitam `manifest.json` na raiz com `id`, `name`, `version`, `description` e `actions`. Cada ação gera um botão no cartão do add-on. Os botões encaminham para ferramentas e telas compatíveis do JURITI. Não são executados scripts, binários nem código nativo arbitrário do ZIP.

Exemplo de manifest:
```json
{
  "id": "juriti-tools-plus",
  "name": "Juriti Tools Plus",
  "version": "1.0",
  "description": "Atalhos extras de ferramentas do Android",
  "actions": ["open_battery_settings", "open_display_settings", "open_performance", "open_shizuku"]
}
```
Ações aceitas: `open_game_tools`, `open_dns_settings`, `open_animation_settings`, `open_performance`, `open_shizuku`, `open_battery_settings`, `open_sound_settings`, `open_input_settings`, `open_display_settings`, `open_game_driver_settings`, `open_battery_optimization`, `open_private_dns_settings`.
