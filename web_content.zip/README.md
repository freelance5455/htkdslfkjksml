# CelengKu — Source aplikasi celengan digital

## Isi folder
- `index.html` — struktur halaman dan formulir.
- `style.css` — tampilan responsif biru gelap.
- `script.js` — saldo, celengan, transaksi, grafik, PIN, misi, pencapaian, backup/restore.

## Cara menguji dari HP Android
1. Instal/buka Acode atau TrebEdit.
2. Buat folder proyek bernama `CelengKu`.
3. Buat tiga file sesuai nama di atas, lalu salin isi file dari ZIP ini.
4. Buka `index.html` dengan preview/browser.
5. Buat celengan, misalnya Laptop dengan target Rp5.000.000.
6. Catat transaksi masuk Rp50.000. Coba catat uang keluar Rp10.000.
7. Coba uang keluar melebihi saldo; aplikasi seharusnya menolak.
8. Coba menu Misi & Pencapaian, Pengaturan PIN, Backup data, dan Restore data.
9. Uji setelah menutup dan membuka lagi preview. LocalStorage biasanya tetap ada selama data situs/browser tidak dihapus.

## Cara membuat APK
File dalam ZIP ini adalah source web, bukan APK yang sudah dikompilasi.
1. Pastikan `index.html`, `style.css`, dan `script.js` berada pada lokasi yang sama.
2. Unggah ZIP atau folder ke layanan pembungkus web-to-APK yang Anda pilih, jika layanan tersebut menerima proyek HTML lokal. Ikuti petunjuk layanan itu untuk menghasilkan APK.
3. Jika layanan meminta URL website, file lokal tidak otomatis menjadi URL; hosting source terlebih dahulu atau gunakan pembungkus Android WebView yang mendukung aset lokal.
4. Unduh APK hasil build dan periksa ukuran file serta sumbernya. Aktifkan izin instalasi dari sumber tersebut hanya jika Anda mempercayai layanan dan file yang dihasilkan.
5. Jika APK gagal dipasang, coba build ulang dengan opsi Android yang didukung, pastikan unduhan lengkap, lalu periksa pesan kesalahan Android. Jangan menginstal APK yang tidak dikenal atau meminta izin tidak relevan.

## Catatan keamanan dan keterbatasan
- Ini adalah pencatat tabungan, bukan rekening bank atau dompet digital.
- Data disimpan di LocalStorage browser/WebView pada perangkat. Menghapus data aplikasi/browser bisa menghapus catatan; lakukan backup.
- PIN disimpan di penyimpanan lokal dan bukan enkripsi. Jangan gunakan PIN rahasia yang dipakai untuk akun lain.
- Untuk penggunaan produksi, gunakan autentikasi native/penyimpanan aman Android dan enkripsi data melalui pengembangan aplikasi native.
- Grafik dibuat dengan Canvas, tanpa library chart eksternal.
- Font Inter diambil dari Google Fonts bila internet tersedia; aplikasi tetap memakai font sistem jika offline.
