# MY HAIR TRACKER

A lightweight, single-user personal hair serum tracker.

## Features
- Manual monthly calendar (no pre-filled dates)
- Application history and simple progress
- Daily reminder configuration
- Notification sound preview
- Dark/light theme
- Developer contact section
- Local personal data storage

## Run as a web app
1. Install Node.js (LTS).
2. Open this folder in a terminal.
3. Run `npm install`
4. Run `npm run start`

## Build Android project
1. Install Android Studio and Android SDK.
2. In this folder run `npm install`.
3. Run `npm run build`.
4. Run `npx cap add android` (only once).
5. Run `npx cap sync android`.
6. Run `npx cap open android`.
7. In Android Studio, wait for Gradle sync.
8. Connect an Android phone with USB debugging enabled, or use Build > Build Bundle(s) / APK(s) > Build APK(s).
9. For a debug APK, Android Studio shows a link to the generated APK.

## Important notes
- This starter keeps calendar data in this browser/app installation using local storage. It is designed for one person's use and does not include accounts or cloud sync.
- If app data is cleared or the app is uninstalled, local records may be lost.
- Native reminder scheduling requires the Capacitor Android platform and local notification plugin to be installed and built. Test notification permission and scheduling on a real Android device.
- Android may restrict exact/background alarm delivery based on OS version, battery settings and device manufacturer.
- This project is source code, not a precompiled APK. Android Studio and Android SDK are required to compile the APK.
