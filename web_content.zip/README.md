# ARENA 7X: setup (test mode)

1. Create a free project at supabase.com.
2. SQL Editor → paste `schema.sql` → Run. (Creates tables, row-level security, wallet ledger, secure functions, storage buckets.)
3. Authentication → Providers → keep Email on. Under URL Configuration, add the address where you host the app.
4. Project Settings → API: copy the Project URL and anon key into `config.js`.
5. Host this folder on any static host that serves HTTPS (Netlify, Vercel, Cloudflare Pages, Firebase Hosting). HTTPS is required for PWA install.
6. Open `index.html`, register your own account, then run in the SQL Editor:
   `update profiles set role='admin' where email='YOUR@EMAIL';`
7. Open `/admin.html`, log in, go to Settings and upload the payment QR, then create your first tournament.

## How the money rules are enforced (all in the database)
- Users have no write access to wallets or the ledger. Every balance change goes through one internal function that also appends an immutable ledger row.
- Deposits: duplicate UTRs are blocked by a unique index. Only an admin can approve, and approving is the only thing that credits the wallet.
- Withdrawals: the amount is held at request time, one open request per user, and Paid needs a payout reference. Rejecting refunds the hold once.
- Room ID and password live in a separate table that only registered players can read, and only after you tick "show room details".
- Results: Finalize credits kill earnings plus prize exactly once, then locks the tournament.

## Before real money
Keep `testMode: true` in `config.js` until you have the legal and payment approvals you need. Real-money gaming and wallets are regulated in India and vary by state. Check this with a lawyer.
Also: add PNG icons (192 and 512) to `manifest.json` for the best Android install experience, and schedule match-reminder notifications with Supabase pg_cron (or use the Notify button in admin).
