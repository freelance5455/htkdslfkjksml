# MATYKA CHEATS — FREE FIRE ASSISTANT (PREMIUM EDITION)

Aplicativo Android completo desenvolvido com identidade visual gamer profissional (fundo preto, vermelho neon `#ff0033`, detalhes em roxo `#9c27b0`), sistema robusto de autenticação por KEY, painel administrativo integrado e módulos de alta performance para Free Fire.

## Estrutura do Projeto
- `index.html`: Interface principal estruturada em abas mobile-first responsivas.
- `styles.css`: Estilização completa com efeitos luminosos neon, fontes Orbitron/Inter e animações fluidas.
- `script.js`: Lógica completa de autenticação, validação de servidor/key, painel admin, gerador de sensibilidade (5 fabricantes e 125+ modelos), boosters de HZ e FPS, Headtracker, No Recoil e Otimização Rápida.
- `README.md`: Instruções de uso e compilação.

## Key Inicial do Sistema
A primeira Key cadastrada por padrão no sistema é:
`MATYKA-E43V-STU6-39CP`

## Como Compilar para APK Android
Você pode compilar este projeto HTML5/CSS3/JS diretamente em um aplicativo nativo Android (`.apk`) utilizando ferramentas como **Capacitor**, **Cordova** ou conversores HTML-to-APK (como WebIntoApp ou Website 2 APK Builder).
