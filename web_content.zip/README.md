# سوقي الرقمي V2 — Secure Marketplace Starter

هيكلية إنتاجية كبداية:
- Frontend: HTML/CSS/JS
- Backend: Node.js + Express + TypeScript
- Database: PostgreSQL + Prisma
- Authentication: JWT access token + refresh token cookie
- Password hashing: Argon2id
- Security middleware: Helmet + CORS + rate limiting + validation
- Marketplace: sellers/products/orders
- Commission: 10% محسوبة على الخادم
- Seller wallet: available/pending balance
- Withdrawals: طلب سحب ومراجعة إدارية
- Social links للبائع
- Uploads: لا تُحفظ داخل public؛ نقطة الرفع مصممة لتخزين خاص
- Payment: Adapter interface؛ لا توجد مفاتيح سرية داخل المشروع

## التشغيل المحلي
المتطلبات: Node.js 20+ وPostgreSQL.

1. انسخ `backend/.env.example` إلى `backend/.env`.
2. ضع DATABASE_URL وJWT secrets قوية عشوائية.
3. داخل backend:
   npm install
   npx prisma generate
   npx prisma migrate dev --name init
   npm run dev
4. افتح frontend/index.html من استضافة محلية أو static server.

## مهم
هذا Starter آمن كبنية، لكنه ليس شهادة أمنية ولا يضمن استحالة الاختراق. قبل استقبال أموال حقيقية:
- استخدم HTTPS.
- ضع secrets في Secret Manager/Environment.
- اربط بوابة دفع رسمية عبر webhook على الخادم.
- راجع القوانين والضرائب وسياسات الدفع في بلد التشغيل.
- نفّذ اختبار اختراق ومراجعة أمنية مستقلة.
- اجعل تنزيل الملفات بعد تأكيد الدفع فقط.
