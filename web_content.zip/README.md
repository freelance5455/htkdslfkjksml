Medical Study Hub Android V4

This version keeps the full-screen layout and adds a more reliable Android Storage Access Framework file picker.
It explicitly opens the Android Documents/Files picker for images and PDFs and requests media/storage permission where Android requires it.
Notes and picture metadata remain persistent through localStorage; PDFs are copied into the app private storage.
