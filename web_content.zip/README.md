# SoundBoard APK

## APK üretmek
1. GitHub'da yeni repo aç, bu klasörün içeriğini yükle.
2. Actions > "Build APK" > Run workflow.
3. Bitince artifact'tan APK'yı indir.

## Yerel (Android Studio)
Klasörü aç, Sync, Run.
