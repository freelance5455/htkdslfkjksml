# Aaj — Calendar & Calculator

An installable web app (PWA): a Bengali/Indian festival calendar with your own events, plus a calculator with history.
Files: index.html, manifest.webmanifest, sw.js, icons/.

## Try it on your computer
    python3 -m http.server 8080      # then open http://localhost:8080

## Put it on a phone
1. Upload this folder to any HTTPS host: Netlify Drop (app.netlify.com/drop), GitHub Pages, Cloudflare Pages or Vercel.
2. Open the link in Chrome on Android, then tap "Install app" (or menu > Add to Home screen). On iPhone: Safari > Share > Add to Home Screen.

## Make an Android APK / Play Store app
Host the folder over HTTPS, then paste the link into https://www.pwabuilder.com and choose Android.
(Alternative: Capacitor — `npm i @capacitor/core @capacitor/cli @capacitor/android`, set webDir to this folder, `npx cap add android`.)

## Notes
- Works fully offline. Events and calculator history are saved on the device (localStorage).
- Calculator: type with the keypad or keyboard. Percent works like a phone: 200 + 10% = 220. Tap the result to copy it.
- To add festivals, edit the FESTIVALS list near the top of the script in index.html (dates are YYYY-MM-DD).
- After editing, change V='aaj-v6' in sw.js so phones fetch the update.
