# Smart Study AI – Std 9 Gujarati Medium (v2)

Offline-first Android Studio project. No API key, account, backend, or internet permission is required.

## Open
1. Extract this ZIP.
2. Open the `SmartStudyAI_Std9` folder in Android Studio.
3. Let Android Gradle Plugin sync (Android Studio may download build tools).
4. Run on an Android device/emulator (minSdk 23).

## Included
- Gujarati-medium dashboard, S.S., Science, Maths, English
- Notes, classwork and homework study panels
- 25-question chapter quiz: 10 easy, 10 medium, 5 hard
- Per-session question shuffle and duplicate avoidance within a quiz
- Score report card saved on device using local storage

## Important offline-AI limitation
This build works without an API key. It uses a local question template engine and sample curriculum prompts, not a hosted generative AI model. It cannot guarantee perfect GSEB textbook accuracy for every chapter until chapter-specific verified content is added. The included chapter list is editable in `app/src/main/assets/index.html`.
