# Aventura da Neve — jogo HTML/CSS/JS

Jogo de exploração inspirado em aventuras aconchegantes de inverno, com identidade própria.

## Como jogar
Abra `index.html` em um navegador moderno.

### Celular
Use o direcional na tela.
- ✋ Coletar: pega recursos próximos / conclui a missão no acampamento.
- 💨 Correr: ativa uma corrida curta.
- 🎒 Mochila: mostra recursos.

### PC
- WASD ou setas: mover
- Shift: correr
- E: coletar

## Objetivo
Colete 5 madeiras e encontre o acampamento para concluir a missão.

Não usa bibliotecas externas e funciona offline.
