# v3.80 — TRANSFORMATION ONCE PER LEVEL
- A skin goes through its forms (up to the third / final power) only ONCE in each level. When it is in the final form and you hit a trap, the transformation shield breaks (with the scream), and from then on that level gives no more transformations: the skin stays in its base look and a trap hits normally.
- The count is kept when you die and retry the same level, and the next level lets the skin transform once again. Starting a level from the menu or with RESTART FROM START also gives the transformation back.
- Applies to the ad-unlock skins (Naruto, Goku and all other shield skins). Star-price skins are unchanged.
- Tune: `SKIN_FINAL_LIMIT` (top of game.js; 1 = once per level) and `session.skin`.
- REMOVED: the RUN ENGINE CHECKS button in Settings, its results screen and the `?test=1` address trigger, so players can no longer see the game's internal checks. `tests.html` (the QA runner for that screen) is no longer shipped.
- Project file name: 80 level hard game.

# v3.73 — SKIN LIST ORDER
- In the SKINS screen the four star-price skins now sit together at the top (right after Classic) and the ad-unlock skins come below them. Only the display order changed; skin numbers, prices, unlocks and saves are untouched.

# v3.72 — SKIN SCREAMS
- When a skin is in its final form and touches a trap, the character now screams and the transformation shield breaks together with it (Naruto, Goku and every other shield skin).
- Each skin has a voice slot: `voices/naruto.mp3`, `voices/goku.mp3`, ... (also .ogg/.wav/.m4a). If a file is there it is played; if not, a synthesized stand-in scream with its own pitch, length and vowel is played. See `voices/README.txt` for all 16 names.
- `npm run web` now copies the `voices/` folder into the Android build.

# v3.71 — REAL AdMob REWARDED ADS
- `AdBridge` now uses the real Google AdMob SDK through Capacitor (`@capacitor-community/admob`): initialize, prepare, show, and the counter only goes up on the SDK's *reward earned* event (not on close, not on error). Also still supports the `AndroidAds` WebView bridge. Browser test ads are OFF (`SKIN_ADS_TEST=false`).
- Locked skins show dots, `n / 5` and `x ADS LEFT`. 5 verified ads unlock + equip the skin. Saved in `save.skins`.
- Google TEST ids are in `ADMOB` (game.js). Replace with your own, see ADMOB_SETUP.md. Level and settings code untouched.

# v3.70 — COLOURFUL MENUS + SKIN BUY FIX

# v3.36 — SKIN STATES + UPDATED UNLOCKS
- The first state is the clean base character with no aura or spawned effects. Power effects appear only in states two and three.
- Star skins have exactly two detail states and no shield. Ad skins have three detail states; the final state has a defensive shield.
- Naruto's final state holds a visible Rasengan; Luffy has Gear-style steam/Haki fist; Goku moves from black base hair to gold, then cycles blue-to-silver in the final state; Saitama's final state has intense black eyes, a torn cape, impact wave and shield.
- Shield hit protection is limited to ad-unlocked skins; star skins do not receive it.

- SKIN ECONOMY UPDATE: Classic is free. Four selected lower-power skins (Alchemist, Moon Sailor, Pink Pilot, Blue Maid) cost 240 stars each and have 2 states with no shield. All other anime skins, including Naruto, Luffy, Goku and Saitama, require 5 rewarded ads and have 3 states; their final state includes a one-hit shield. Save: `save.skins.own`.
- Every menu screen now has its own colour and background: SKINS (purple/pink), LEVELS (lava orange), SETTINGS (sea teal), CONTROLS (forest green), PAUSE (royal blue), YOU DIED (red), COMPLETED/WIN (gold + green), GUIDE (indigo). Main menu is unchanged. Tune: `panelTheme` (game.js) and the `v3.70` block at the end of style.css.
- FIX: buying a skin with stars did nothing on phones, because the browser `confirm()` popup is blocked in app/WebView. It is replaced by an in-game YES / NO box (`skinConfirm`).

# v3.36 — NEW MAIN MENU (illustrated, like a mobile action game)
- The main menu is now a full-screen picture drawn live in code (no image files): night sky + moon, castle with an evil face and a glowing portal, floating islands, lava, saw blades, wooden bridge, chains, a cliff with a torn banner. Your EQUIPPED SKIN stands on the cliff (tap it and it smiles).
- Top left: your spendable STARS (with a green + that opens Level Select). NO coins, NO gems, NO event box, NO shop: they were removed on purpose.
- Top right: SKINS / SETTINGS / SOUND. Centre: big PLAY (opens the guide as before), LEVELS, SKINS, SETTINGS, CONTROLS, FULL SCREEN. Bottom: progress line.
- Persian is fully supported (right-to-left labels, Persian digits). Works in the auto-rotated portrait mode too (layout is sized by the stage height).
- Light on the phone: the picture is drawn once (again only when the screen size changes); only the hero (~22 fps) and a few CSS effects move. The game canvas is not redrawn while the menu is open.
- Code: `mmBgDraw` (picture), `mmBuild` (buttons), `mmHeroDraw` (skin), `.mm` rules at the end of style.css. The old menu is kept as `mainMenuClassic` and is used automatically if the new one ever throws an error.
- Engine check: the same 3 older failures as before, nothing new.

# v3.35 — SKINS: 16 anime-style skins (main menu > SKINS)
- NEW SKINS screen with the classic character (free) and exactly 16 skins, all drawn live in code (no image files): Orange Ninja, Straw Hat Captain, Super Warrior, Demon Hunter, Green Hero, Soul Reaper, Triple Blade, Alchemist, Moon Sailor, Scarf Scout, Blindfold Mage, Dark Avenger, Spark Hood, Cape Hero, Pink Pilot, Blue Maid. Names are generic on purpose (edit `n` in `SKINS`). The chosen skin is used everywhere: levels, death scenes, guide and cutscenes.
- RULES (updated in v3.36): the classic character is free. Alchemist, Moon Sailor, Pink Pilot and Blue Maid cost 240 stars each (`SKIN_STAR_INDICES`, `SKIN_STAR_PRICE`) and have two states without a shield. All other anime skins require 5 rewarded ads (`SKIN_ADS_NEEDED`) and have three states; their final state has a one-hit defensive shield. Stars are spent from the skin balance (`save.skins.spent`); level completion stars are never reduced.
- SAVE: `save.skins = {pick, spent, ads:{index:count}, equip}`, validated in `sanitize`. Reset Saved Progress keeps skins.
- ADS: everything goes through `AdBridge.show()`. NO real ad network is included. Connect yours: (1) Android WebView object `AndroidAds.showRewarded()` + call `window.__rewardedAdDone(true/false)` when the ad ends, or (2) Capacitor AdMob plugin with `SKIN_AD_UNIT`. With `SKIN_ADS_TEST=true` a 5-second placeholder "TEST AD" is shown so the flow can be tried in a browser: set it to `false` for the release build, otherwise skins unlock without a real ad.
- Persian texts added to `FA`. Engine check added (rules, save bounds, every skin in every pose); the 3 older failures are unchanged. Not played on a real phone yet.

# v3.34c — Outer Core (the orange lava biome before the core): the portal now looks like in every other biome (blue when locked, mint when open), also its off-screen arrow.

# v3.34b — SMOOTHER: removed the animated menu effects that forced a repaint every frame (menu was ~6x slower), no shadow blur in the guide pictures, the world behind the guide redraws every 6th frame, magic motes drawn in 2 batched paths. Gameplay speed equals v3.33.

# v3.34 — FANTASY GUIDE: illustrated how-to-survive pages before the game starts
- START on the main menu now opens a 7-page illustrated guide (live animated pictures, English + Persian): welcome, natural dangers (rain, sandstorm, blizzard, eruption, soil downpour, giant mole, core blast), run to a shelter, flags / save points, the shield, stars (useful in the next update; some guard a trap), controls. NEXT / PREVIOUS / SKIP GUIDE; the last page has START, which opens the stage select. Tune: `GPAGES` and the `gd*` scene functions (block `v3.34 FANTASY GUIDE`).
- FANTASY LOOK: glowing aurora menu background with drifting sparks, shimmering gradient title, rune line, ornament corners, golden glow on the main button (see the end of style.css).
- MAGIC MOTES: soft glowing fireflies drift over every level, tinted with the biome's glow colour (`drawMotes`, 16 motes, halved on low-effects).
- Persian texts for all new strings added at the top of `FA`.

# v3.33 — STAR MIX: sometimes nothing, sometimes a surprise from above, sometimes a spike from below
- Shelters stay as in v3.32 (liked). Every star from stage 4 on (not in the lava biomes) is decided without random numbers: ~40% no trap at all, ~30% a stone that drops from above a moment after you take it (ground stars), ~30% a hidden spike under the star (marked `starTrap`, on ground or high stones, never in the Mantle). Accidental traps under stars are still moved away. Tune: the `v3.33 STAR MIX` block (`mode` = 0-3 none, 4-6 above, 7-9 below).
- Project file name: LVEL_260Hard_59_LavaRafts.

# v3.32 — ONE SAVE, ONE SHIELD, 1-2 SHELTERS, STARS WITHOUT A TRAP UNDER THEM (both chapters)
- HARD vs EASY: a level is HARD from effective stage 14 on (Chapter 1 stages 14-26, Chapter 2 from stage 11; Chapter 2 stages map to effective stages 8-26). Tune: `isHardStage` (the `14`).
- SHELTERS: hard levels have 2 shelters, easy levels have 1 (wherever a storm exists; stages 1-3 of Chapter 1 and the first levels of a biome have no storm, so no shelter). The storm count follows the shelter count (easy: 1 storm). Tune: `wantSh` in the weather block of `makeLevel`.
- SAVES: at most ONE save per level (a flag or a shelter, whichever is nearest the middle). The other shelter still protects but does not save. Tune: `saveCount`.
- SHIELDS: exactly ONE per level, only in hard levels, lying beside the level's only save. None in easy levels. Tune: `shieldsFor`.
- STARS: (1) the hidden spikes on the high stones are gone (the star always sat right above them). (2) No star hangs over a hidden trap any more (floor spikes, pit-grabber, crack, fire vent): each star is moved to a clean spot of its stone, or to the nearest clean stone; if there is none, the trap under it is removed. Tune: the `v3.32 STARS` block at the end of `makeLevel` (`CLEAR` distance = 72 + half the trap width).
- SURPRISE FROM ABOVE (hard levels, about 15% of them, not in the lava biomes): the ground star can hide a stone in the dark above the ledge. It sleeps until you take the star, then comes down after 0.18 s and lands 100-200 px ahead of the star and shatters. It never wakes for a star taken before a save. Same fairness rule as every other falling object (floors near it never collapse or vanish). Tune: `AMB_DELAY`, the `AMB_DX` list, the `(id+stage)%3` line.
- SIDE EFFECT: removing the high-stone spikes freed spots, so Rock Layer cracks and grabbers can now be placed where they were blocked before (each level gets the number its rules ask for).
- Engine checks: updated to the new rules and 3 new ones (all 290 levels: 1 save, shield/shelter counts; no star over a trap; the ambush wakes only after its star). Run in headless Chromium: all pass except 3 older failures that were already there in v3.31 (stage name 225, pit-grabber swallow test, and the dumb test bot, which cannot jump over cracks / time crumbling stones, so it now stops in 19 Chapter 2 levels instead of 19 other ones - 239 and 252 are the lava levels with a long crumbling stone that used to carry a shelter). Not played by a human yet: please play-test stage 14 level 4 and a Rock Layer level.
- Project file name: LVEL_260Hard_58_LavaRafts (was 57).

# v3.31 — INNER CORE: SAFE SHELTERS, ATOM EXPLOSION DEATH, SMALLER HOUSES, GENTLE START / HARD END (Chapter 2, stages 26-32)
- SHELTER = SAFE: while you stand inside an Inner Core shelter nothing can hurt you (atoms, dash atoms, the big atom bomb, rocks, chasers). Lava and the heat bar are not affected. Tune: the `v3.31` line at the start of `hit`.
- ATOM HIT: touching an atom (saw, dash atom or the big atom bomb) now makes it explode: a blue-white flash and ring, your body bursts into black powder that flies out and settles into a small black pile. No white-out for these deaths. Tune: death kind `atomash` (`sdKind`, `sdPlayer`, `sdOver`); death texts now say "turned you into black powder" (Persian in `FA`).
- SMALLER SHELTERS: the Earth-core house is smaller (width 96 -> 72, height 94 -> 74), the hitbox is smaller too. Tune: `HW` (theme 9) in `makeLevel`, `rx`/`ry` in `drawCoreHouse`.
- REMOVED: the rectangle that fell, swung or broke onto you at the start of Inner Core levels (the sign / chunk). Tune: the `v3.31` block at the end of `makeLevel`.
- STONE BUG FIXED: the glowing zigzag lines under the stones flickered on moving stones because they were placed by world position. They are now fixed to the stone. Tune: `moltenCoreDecor`.
- DIFFICULTY RAMP: `lp` goes from 0 (stage 26 level 1) to 1 (stage 32 level 5). Dash atoms start at 0.10, rocks at 0.18, chasers at 0.28; the atom bomb starts at 0.22 (every level from 0.70) and falls more often towards the end (period 9.2 s -> 4.5 s, first bomb 7 s -> 3.5 s). Saws, dash atoms and chasers get faster and wider with `lp`. The heat bar fills slower at the start (14 s -> 10 s). Tune: the `v3.31` block (`thr`, the speed lines) and `updateCoreHeat`.
- Engine checks give the same result as v3.30 (the same 5 older checks fail under the stubbed test DOM). Drew all 35 Inner Core levels, the death animation at several times, and checked that hits do nothing inside a shelter. Not played by a human yet.
- Project file name: LVEL_260Hard_57_LavaRafts (was 56).

# v3.30 — INNER CORE: NO ROPE ATOMS, BURNING YELLOW LAVA IN FRONT, EARTH-CORE SHELTERS (Chapter 2, stages 26-32)
- REMOVED: the atoms that hung on a blue energy line and swung (the swinging saw) are gone from every Inner Core level. Atoms that wobble, move up-down or left-right stay. Tune: the `v3.30` line at the end of `makeLevel`.
- YELLOW LAVA UNDER YOUR FEET: the sea is now drawn in FRONT of the stones and the player (like the lava biome) and has a much richer look: white-yellow to deep-orange body, flowing bright veins and darker swirls, drifting dark crust plates with glowing cracks, a white-hot rim, popping bubbles, leaping spits and rising sparks. Tune: `drawCoreLavaFront` (`Y`, gradient stops, crust / vein / bubble loops).
- FALLING IN BURNS YOU: touching the lava kills at once (new cause `corelava`). Your body chars black, yellow flames burn on it and you crumble to ash (the same burn death as the eruptions, no white-out). Death text: "You fell into the molten core lava and burned to ash. Stay on the stones!" (Persian added to `FA`). Kill line: `player.y>462` while in the air; a sinking stone only kills when it has sunk all the way (`player.y>=496`), so standing on one is still fair. Tune: the `corelava` line in `physics`.
- SHELTERS ARE EARTH-CORE HOUSES: the Inner Core shelter is now a dome made of the real layers of the planet: a dark cracked crust with glowing seams, a red mantle, a flowing orange outer core, and a hollow chamber where you stand. The white-hot INNER CORE ball glows at the top as the lamp of the house and pulses faster when the core blast warns. Shelters still protect and still save exactly as before (same hitbox, `s.x .. s.x+s.w`); the save flag stands on top of the dome. Tune: `drawCoreHouse` (`rx`/`ry` dome size, ring sizes, `ir` ball radius).
- Engine checks give the same result as v3.29 (the same older checks still fail under the stubbed test DOM). Drew all 35 Inner Core levels (houses + lava) without errors; a fall into a gap gives the burn death, standing on a normal stone never kills. Not played by a human yet: please play-test stage 26 level 1 and stage 32 level 5 for feel.
- Project file name: LVEL_260Hard_56_LavaRafts (was 55).

# v3.29 — INNER CORE: BLUE NUCLEAR ATOMS REPLACE SAWS AND DASH BLADES; THE FALLING METEOR IS A BIG ATOM BOMB (Chapter 2, stages 26-32)
- SMALL ATOMS: every spinning saw and every dash blade (the ones that fly in from the front or the back) is now a glowing blue atom: a bright nucleus of 5 particles, three electron orbit bands with flowing light and electrons, and three blue bands that circle the whole atom. Hitboxes and movement are unchanged (swing saws now hang on a blue energy line). The dash warning is a small blue atom with a ! on the screen edge. Dash atoms leave a blue trail. Tune: `drawAtomBlue`.
- BIG ATOM BOMB: the meteor that starts falling about 3.5 s after the level starts (and every ~5 s after) is a big atom (`atomBomb`, `drawAtomBomb`, constants in `ATOM`). Timeline: 0.95 s warning (a blue ring on the ground shows the blast reach), 0.55 s fall (touching it kills), 0.70 s armed on the ground (it pulses faster and flashes; touching it kills), then a blue-white blast sphere grows to 235 px in 0.35 s and lasts 0.45 s more. Anything inside the sphere dies. Running away at full speed from the moment it lands always escapes (290 px/s x 1.05 s is more than 235 px); standing still dies. Shelters and safe zones still protect you.
- DEATH: new cause `atomblast` ("The big atom exploded and swallowed you. Run the moment it lands!"); saw and dash deaths in the Inner Core read "A blue atom ...". Persian added to `FA`.
- Falling rocks (`rock`) and the chasers are unchanged. Other biomes keep their saws, dash blades and meteors.
- Engine checks give the same result as v3.28 (the same 4 older checks still fail).
- Project file name: LVEL_260Hard_55_LavaRafts (was 54).

# v3.28 — INNER CORE: HIDDEN YELLOW LAVA ERUPTIONS REPLACE THE FIRE VENTS, LAVA BURNS YOU (Chapter 2, stages 26-32)
- CHANGED: the fire vents of the Inner Core are now hidden lava eruptions. Nothing is drawn before the burst (no vent, no glow, no warning). Every 3.7 s the ground throws up a yellow-white molten column (about 250 px tall, 0.95 s) and 12 glowing droplets that fly out and fall back (about 2 s). Other biomes keep their old vents and geysers.
- DEADLY: touching the column OR a single droplet kills you (`hit('lavaburn')`), even when you are far from the column. A shield absorbs one hit as usual. The timing is the same on every attempt, so it can be learned after the first surprise.
- BURN DEATH: new death animation `burn` (`sdPlayer` / `sdOver`): your body chars black, yellow-orange flames burn on it, then you crumble into ash, with embers and a bright flash. No white-out for this death. Death text: "Yellow lava burst out of the ground and burned you to ash." (Persian added to `FA`).
- FAIR PLACE: eruptions are removed within 150 px of every save flag and every shelter. Tune: `coreEruption` (`P` = cycle, `te=t-1.9` = when it bursts), `coreDrops`, `drawCoreEruption`; the safe-distance filter is the `v3.28` line at the end of `makeLevel`.
- Engine checks give the same result as v3.27 (the same 4 older checks still fail).
- Project file name: LVEL_260Hard_54_LavaRafts (was 53).

# v3.27 — INNER CORE BACKGROUND: YELLOW TRIANGLES REMOVED, NEW CORE-ONLY DETAILS (Chapter 2, stages 26-32)
- FIXED: the yellow-edged diamonds/triangles floating in the backdrop are gone. They came from the generic cave-layer loop in `bgUnder` (dark cones from floor and ceiling + yellow-outlined diamonds), which no longer runs for the Inner Core (`b===4`). The dark diamond shapes inside the iron ball were also replaced by soft round iron grains.
- KEPT: the big white-hot iron ball, its pulsing rim, the five liquid-iron rings and the pressure waves are unchanged.
- NEW (suits the Earth's core): glowing magnetic field-line loops that flow around the ball (the geodynamo), and slow soft convection plumes of hot liquid iron rising from the sea. Tune: `drawCoreBackdrop` (`v3.27` comments).
- Project file name: LVEL_260Hard_53_LavaRafts (was 52).

# v3.26 — INNER CORE BACKGROUND: THE REAL CENTRE OF THE EARTH (Chapter 2, stages 26-32)
- NEW LOOK: a huge white-hot iron ball (the inner core) glows behind the level. Its surface slowly turns with crystal lattice lines and dark iron crystals, a bright rim pulses, and pressure waves spread out from it. Around it, five rings of liquid iron (the outer core) flow in both directions. The old jagged crack lines are gone from the backdrop. Magma blobs, magma falls and embers stay.
- Tune: `drawCoreBackdrop` (`cy`/`R` set the ball position and size, the `k<5` loop the flowing rings, the `k<3` loop the pressure waves).
- Project file name: LVEL_260Hard_52_LavaRafts (was 50).

# v3.25 — LANGUAGE SETTING: ENGLISH / فارسی (all chapters)
- NEW: Settings has a LANGUAGE · زبان row with two buttons, English and فارسی. The choice is saved (`save.lang`) and applied at once.
- Persian is right-to-left in menus, the toast and the HUD label; the playfield and the touch buttons keep their place. Digits turn into Persian digits, letter spacing is switched off so the letters stay joined.
- Everything is translated: menus, settings, controls, stage and level select, pause, death and win screens, hints, toasts, death messages, storm warnings, cutscene captions and the text drawn on the canvas.
- HOW IT WORKS: English stays the source text. `tr()` looks the string up in `FA` (exact text) or `FA_PAT` (text with numbers). `trDom()` translates every menu after `panel()`, `ctx.fillText` is wrapped for canvas text, `notify()` and `updateHud()` call `tr()`. To add a text: write it in English in the code and add `"English":"فارسی"` to `FA`. CSS for Persian: the `html.fa` rules at the end of `style.css`.
- Engine checks give the same result as v3.24 in both languages (4 older checks that already failed in v3.24 still fail: stage name 225, pit-grabber swallow, bot on 19 Chapter 2 levels, Thermal Veins geysers).

# v3.24 — INNER CORE: ALL THORNS AND GROUND TRAPS REMOVED (Chapter 2, stages 26-32)
- Removed from every Inner Core level: floor thorns (`spikes`), ceiling thorns (`dropSpike`), pit-grabbers (`maw`) and `crack`. Saws, fire, dash blades, rocks and chasers stay. Tune: `v3.24` line at the end of `makeLevel`.

# v3.23 — INNER CORE FIXED: MOLTEN YELLOW-WHITE, HEAT TIMER, BLAST RESTARTS THE LEVEL (Chapter 2, stages 26-32)
- LOOK: no gold and no tech/electric look any more (the lightning, rotating rays, shock rings and gold nuggets are gone). The biome is pure molten: white-yellow glowing magma in the background (soft drifting magma blobs, magma falls from the ceiling, glowing cracks, rising bubbles), dark charred stones with glowing yellow-white veins, and a yellow-white lava sea with dark crust slabs, popping bubbles and spits. Tune: `drawCoreBackdrop`, `drawCoreSea`, `moltenCoreDecor`, Inner Core entries in `THEMES` and `UPAL`.
- REMOVED: the extra gold pickups (only stars and the original shields are left) and the red spiky crusher that moved up and down in the air (`ceiling` hazard, removed from this biome).
- CORE BLAST: the `!` sign gives 3 seconds, then everything turns completely white. Outside a shelter you die and the level restarts from the very beginning after the white-out (no death screen). Inside a shelter you survive. Shelters are the same obsidian houses as the lava biome.
- CORE HEAT (new): outside a shelter the heat climbs and kills you after about 10 seconds. The screen edges glow yellow-white, a CORE HEAT bar shows at the bottom, and your character glows and drips molten while you melt. Inside a shelter the heat drops fast (about 1.2 s). Tune: `updateCoreHeat` (`dt/10` rise, `dt/1.2` fall), `drawHeatMelt`, `drawHeatHud`.
- Other deaths in the Inner Core (traps, bombs, falling) still end with a white flash.
- Checked on all 35 Inner Core levels: no gold, no crusher, blast kills outside a shelter and restarts, heat kills at 10 s and never inside a shelter, drawing runs without errors. Not played by a human yet.

# v3.22 — THE INNER CORE REBUILT: CORE BLAST, WHITE-HOT GOLD (Chapter 2, stages 26-32 only)
- LOOK: the last biome is now the heart of the Earth. A white-hot core pulses in the background with rotating rays, expanding shock rings, flickering lightning and floating gold flakes; the far spikes are gold; the floor is a sea of white-gold plasma with jets; the stones have gold edges, veins and nuggets; golden sparks rise through the air. Tune: `drawCoreBackdrop`, `drawCoreSea`, `coreGoldDecor`, the Inner Core entry in `THEMES` and `UPAL`.
- CORE BLAST replaces the soil rain here. When you pass a trigger a `!` sign shows for 3 seconds (the screen glows gold and cracks). When the 3 seconds end everything explodes in white: if you are not inside a golden crystal shelter you die. Shelters are still save points. Tune: storm kind `nova` (`dur` 1.2 s, `updateStorm`, `drawNova`, `drawCoreBunker`).
- WHITE-OUT: any death in the Inner Core (blast, trap, bomb, falling) ends with the whole screen flashing white and fading out. Tune: `drawWhiteout`, `world.whiteAt` in `die`.
- NEW GOLD: 4 to 10 gold nuggets per level on the stones and over the gaps. HUD shows `◆ got/total`. They are only a bonus: stars and progress are unchanged. Tune: `v3.22 INNER CORE` block at the end of `makeLevel`.
- Engine Checks: the two weather checks now allow the core blast in stages 26-32. Rendered all 35 Inner Core levels, checked 3 s warning, death outside a shelter and survival inside one. Not played by a human yet: please play-test stage 26 level 1 and stage 32 level 5 for feel.

# v3.21 — SAFE HOUSES IN THE LAVA BIOME (Chapter 2, stages 20-25 only)
- Around every obsidian shelter (the house you run into when the molten rain warns) and every save point, nothing can appear or hurt you any more: geysers, sea jets, crumbling stones and every other trap are removed from the zone (the whole shelter plus 30 px each side; the save flag plus 60 px each side; a geyser also needs its spray radius of about 70 px clear).
- Lava bombs do not spawn while you stand in a safe zone, and a bomb already in the air cannot hit you there. Tune: `v3.21 SAFE HOUSES` block at the end of `makeLevel`, `inSafe` in `updateMeteors`.
- Other biomes and the rest of the levels are unchanged.

# v3.20 — LAVA BIOME DIFFICULTY RAMP + TWO NEW TRAPS (Chapter 2, stages 20-25 only)
- Only levels 225-254 (the lava biome) changed; the other 260 levels are identical to v3.19 (checked level by level).
- RAMP: the start of the biome is gentle, the end is hard. Position in the biome = `lp` from 0 (stage 20, level 1) to 1 (stage 25, level 5).
  - Geysers: 0 in the very first level, 1 early, up to 5 at the end. Tune: `nG` in the lava block of `makeLevel` (`1+floor(LP*5.6)`).
  - Double-burst geysers become more common with `lp` (none at the start, most at the end).
  - Lava pools with rafts: 1 early, up to 3 late; rafts drift faster (`speed`), pools may sit closer together late.
  - Lava bombs from the ceiling start at about 1/4 of the biome (every level from then on) and fall more often, period 8.4 s down to 5 s.
- NEW TRAP 1, SEA JETS: lava shoots up out of the lava sea in gaps between stones (not at rafts), with the same glowing-swell warning, deadly spray and single or double bursts as geysers. From about 1/5 into the biome, 1 to 2 per level. Tune: `nJ`, `sea:true`.
- NEW TRAP 2, CRUMBLING CRUST: some stones have bright glowing cracks; about 0.85 s after you land they drop into the lava and re-form later (flash red and shake while it is about to go). From about 1/3 into the biome, one per level. Never on a stone with a save flag or shelter, never next to a raft pool. Tune: `nC`, `drawCrustWarn`.
- Geysers are now placed after the old traps were removed from this biome (before, those blocked most spots, so levels had fewer geysers than intended).
- Engine Checks: 45, same 4 failures under the stubbed test DOM as v3.19 (identical list). Rendered all 25 lava levels without errors. Not played by a human yet: please play-test stage 20 level 1, stage 22 level 3 and stage 25 level 5 for feel.

# v3.19 — LAVA IN FRONT, SCATTERING ERUPTIONS, NEW GEYSER TRAPS (Chapter 2, stages 20-25 only)
- Only the lava biome (Chapter 2, stages 20-25, levels 225-254) changed. All other 260 levels are byte-identical to v3.18 (checked by comparing every generated level).
- LAVA IN THE FOREGROUND: the lava is now drawn over the stones and over the character (bright rim, heat glow, crust islands, bubbles, leaping spits), at the same height where falling kills. Before, it was a backdrop and you died "inside the background". Falling in now clearly means swimming in lava. Tune: `drawLavaFront` (`Y=492`).
- Melt: when you die in lava or a geyser, the character glows and drips molten for the death scene.
- Eruptions scatter and kill: geyser hitbox is wider (32x76) and the spray drops it throws out sideways are deadly too (same positions are drawn and hit-tested, `geyserDrops`). Stay clear while a vent glows.
- Two geyser types, chosen without random numbers (`mode`): single burst (as before) and DOUBLE BURST (two eruptions in a row, the vent keeps glowing between them). Extra geyser from level 2 (`.46`) and another from level 4 (`.66`), same fair spacing as before.
- Engine Checks: 45, same 4 failures under the stubbed test DOM as v3.18 (identical list). Rendered all 25 lava levels and a lava death without errors. Not played by a human yet.

# v3.18 — MOLTEN ERUPTIONS, BLACK BASALT, MOLTEN SHELTERS
- Chapter 2, stages 20-25 (the biome before the Inner Core): the stones are now almost black basalt with glowing lava veins (darker body and darker top lip). Tune: the `v3.17 basalt slab` block in `drawPlatformRaw`.
- Lava geysers redrawn as real eruptions from underground: a jagged fissure in the stone with cracks, the ground bulges and glows while magma bubbles pop (the warning), then a turbulent magma column with a white-hot core, a splashing crown, arcing drops, and dark rock chunks blasted out of the fissure. The round smooth pillar is gone. Hitbox, timing and warning are unchanged. Tune: `drawLavaGeyser`, `h.et` (eruption time) in `updateHazards`.
- One more geyser per level from level 2 on (`placeFire(.46,...)`), placed by the same spacing rules as before (never at an edge, never near other traps).
- Obsidian shelters stand in a molten setting: cracked obsidian curb with glowing seams, lava creeping down the stone face, drips from the roof, warm glow. Looks only; shelters still protect exactly as before. Tune: `drawMoltenSurround`.
- Engine Checks: 45, the same old failures as before (checked against v3.17 in a stubbed-DOM run: identical list). Rendered all 25 lava levels for 420 frames without errors. Not played by a human yet.

# v3.17 — THERMAL VEINS: LAVA POOLS, RAFTS, NO MORE ROPE SAW
- Lava pools: in every level of stages 20-25 one to three stones are removed and the gap is filled with open lava. Cross it on a drifting basalt raft that glides from bank to bank. Tune: the `v3.17 THERMAL VEINS` block in `makeLevel` (`want`, raft `amplitude`/`speed`).
- Falling into the lava now kills at once (the old "stuck in the pit, jump out in 1.45 s" behaviour is gone).
- Removed from this biome: the rope/hammer saws (left-right, up-down, swinging) and the hidden grabbing pressure pits. Everything is visible now: lava, rafts, geysers, bombs, molten rain.
- Shaking fixed: the glowing veins on stones were positioned in world coordinates, so they flickered and "rotated" on moving or sinking stones. They are now drawn relative to the stone. The ceiling lava drips no longer jitter sideways; they melt and stretch downward smoothly.
- Atmosphere: distant lava falls pour from the ceiling into the sea.
- Engine Checks: 45, same 3 old failures, the Thermal Veins check was rewritten for the new rules. Not played by a human yet.

# v3.16 — THERMAL VEINS: MOLTEN BIOME (before the Inner Core)
- Chapter 2, stages 20-25 (the biome between the Mantle and the Inner Core) is now fully molten. All the blue/teal metal colours are gone.
- Look: real lava sea (crust slabs, bubbles, lava fountains, heat haze), black basalt stones with glowing lava veins, orange cracks in the background, embers in the air, obsidian heat shelters.
- New rain: MOLTEN RAIN (3 s warning with the ! sign, then glowing lava streaks and blobs; the ceiling drips lava). Hide under an obsidian shelter. Same rules as the soil/goo storm, max 7 s. Death burial scene is lava coloured. Tune: `drawStorm` (`MOLTEN RAIN` block), `drawLavaCeiling`.
- New traps: LAVA GEYSERS on the stones (warning glow and bubbling, then a tall lava column; 2 per level from level 3), LAVA BOMBS (even stages, levels 3-5). Pressure cracks, molten rotors, sinking stones and belts stay. Tune: `drawLavaGeyser`, `placeFire`, `w.meteor` line for bio 3.
- Own death texts for geyser, bomb, molten rain.
- Engine Checks: 45, same 3 old failures as before, nothing new. Rendered in headless Chromium without errors. Not played by a human yet.

# v3.15 — MANTLE STONE ENDS, LANDSCAPE & FULLSCREEN
- Mantle (Chapter 2): the floating mantle-coloured piece at the end of the stones is gone. The round bumps painted on the stone surface used to stick out past the stone's end on some widths (a blob hanging in the air a little away from the rectangle, plus a small dark one under it). Bumps are now only drawn fully inside the stone. This fixes the upper stones and the ground stones. Tune: `drawPlatformRaw`, mantle block (`dx`/`dr` check).
- Mantle: the extra small upper stone (105 wide, 5 px lower than the others) that sat beside or overlapping the normal upper stones in some levels is no longer built in the Mantle. Stars simply use the normal stones. Tune: the `platform(w.width*.76-120,360,...)` line in `makeLevel`.
- Landscape: after a rotation or a fullscreen change the layout is measured again several times (0.12, 0.35, 0.8, 1.6 s), because phones often report the new size late. Also listens to `screen.orientation`, `fullscreenchange` and `visualViewport`. Tune: `relayout` in game.js.
- Fullscreen: a new button (four corners) next to Pause in the HUD turns fullscreen on or off. Once you leave fullscreen (to pull the phone's top panel down for Wi-Fi) the game never forces it back; tap the button or the menu's FULLSCREEN to return. Tune: `toggleFs`, `onFsChange`, `#fsButton`.
- A web page cannot open the phone's Wi-Fi panel itself. Leave fullscreen, then pull the top panel down as usual.
- Not tested on a real phone yet. Same three old engine-check failures as version 40.

# v3.14 — MANTLE GOO LOOK: JELLY DROPS (same storm as before)
- Mantle (Chapter 2, stages 13-19) sticky goo storm: the ! sign with the seconds countdown, the whole-screen goo fall, the shelters, the exposure timer and the "buried by sticky goo" death are all exactly as in version 40. Only the look of the drops changed: each drop is now a glossy, wobbling jelly blob with a stretchy tail and a bright highlight, not a thin ribbon.
- A version with big drops that fell in groups of 2, 3, 5 was tried and removed again (not wanted).
- Tune: the `v3.14 jelly goo` block in `drawStorm` (`r` = blob size, `len` = tail length, `wb` = wobble) in game.js.
- Not played by a human yet.

# v3.13 — MOLE NO LONGER VANISHES, FLAG ON THE ROOF
- Giant mole: every mole event now keeps its own mole. Before, when a second event started while the first mole was still running, the first mole vanished and a new one appeared behind or ahead of you. Now each mole runs on by itself and is only drawn while on screen. Tune: `updateStorm` (`s.mx`, `S.moles`), `drawMoleStorm`.
- Rock Layer shelter save flag: the pole now stands on the stone roof (it floated about 11 px above it before). Tune: `drawShelters`, `cpS` block (`fo`).

# v3.12 — MOLE SHAKE FIX & NO GRAPHICS DROP
- Giant mole (Chapter 2, Rock Layer): the screen now shakes only when the mole arrives (the warning and the first 0.7 s of its run). While it runs to the end there is no shake.
- If the mole catches you, the shake comes back (stronger when the rocks start falling) while it digs the ground and you are buried.
- The shake can no longer lower the graphics: frames during a shake or mole run are ignored by the automatic quality downgrade (`perfBusy`, `adaptQuality`). Shake offsets are whole pixels (`shakeAmt`), and the mole fur is drawn in one stroke instead of ~90 (`drawMole`).
- Tune: `shakeAmt`, `updateStorm` (`s.t<.7`), `perfBusy` in game.js.

# v3.11 — FULL DEPTH CRACK & ATTACHED SAVE FLAG\n- Cracked ground now splits the supporting platform into separated edges so the gap is physically open; the player falls into the fissure instead of taking an immediate hit at the lip.\n- Added a save flag directly to the Chapter 2 burrow save-house.\n\n# v3.10 — SPLITTING GROUND
- Rock Layer ground crack: it shakes the screen while it opens, then the ground splits in two halves that tilt away to the left and right and fall, with dust and flying chips and a stronger quake. Jump over the gap to reach the ground on the other side. Tune: `drawCrack`, `crack` in game.js.
- The blue + pink crystal pair on the Rock Layer stones is removed (v3.9).

# v3.9 — ROCK LAYER LOOK
- Rock Layer background: the angular stone blocks are now smooth, rounded stones (circles, ovals, rounded squares and lumpy pebbles) drawn with bezier curves, like boulders packed in an underground wall. Big boulders are smooth too. Tune: `blobPath`, `rockWall` in game.js.
- The blue and pink crystal blades standing on the stones in the Rock Layer are removed. The floating blue sparkles are now neutral grey dust.
- Not played by a human yet.

# v3.8 — ROCK LAYER POLISH
- Darker, more realistic stone-wall background; brighter walkable stone. Falling rocks are now jagged faceted stones with cracks (no circles).
- Shelters, flags and burrow saves in the Rock Layer are plain grey/black stone (no colours).
- Giant mole redrawn (shaded fur, pink nose, claws, teeth).
- The pit-grabber is gone from the Rock Layer. New **ground cracks**: when you come near, a crack shakes for 1.1 s, then the ground splits open; jump over it or fall in. Tune: `crack` in game.js.
- Not played by a human yet.

# v3.7 — CHAPTER 2 REWORK
- **Rock Layer look:** the background is now a stone wall of blocks and boulders (no more cave spikes). Thorns there are sharp grey **stone shards** (1-4 points, varied).
- **Centipede and creeper removed from the Rock Layer.** Instead: **giant mole** event. A ! sign gives 3 seconds, the cave shakes and pebbles fall, then a screen-sized mole runs through the level from behind to the end. Hide in a **white-glowing shelter**. If it catches you it bites you, drags you down into the ground and the cry scene plays. Tune: `drawMole`, `updateStorm` (`S.moleX`).
- **Trap variety (chapter 2):** the saw now comes in 4 kinds by level: wobbling, up-down, left-right, and swinging on a rope from the ceiling. Saws also start earlier (stage 3, every second level).
- Not played by a human yet.

# v3.6 — FIXES
- **Chapter 1 mechanism:** the blue beam and floating blue ball are gone. It is now a simple floor lever; the knob is red, turns green when pulled.
- **Sandstorm / blizzard death:** you turn into sand / snow powder and get blown away (no burial).
- **Soil death:** soil pours over the whole screen from the top and buries everything, then the cry.

# v3.5 — FIXES
- Only the **chapter 2** creatures (centipede, creeper) hop over chasms; chapter 1 saws behave like before.
- Dying in the air during a slow death: you fall to the ground first, then it happens there.
- **Freezing (cold) death:** you shiver, turn to ice, topple over and shatter, then the cry.

# v3.4 — FIXES
- **Centipede (ch.2) and creeper both hop over every chasm** in a high arc, no more crawling on thin air.
- **Flood:** a wall of water sweeps across the whole screen, carries you off and fills everything.
- **Soil / sand / snow:** it pours over the whole screen and piles on top of you until you are covered, ground still visible; then the cry.
- **Ash (volcano):** no slash line any more; you burst into powder at once.
- Not played by a human yet.

# v3.3 — CHASER JUMPS GAPS, RUNS TO THE END, SLOW DEATHS
- **Chaser creatures jump over chasms** (arc over every gap) instead of gliding across the empty air, and now keep running all the way to the end of the level instead of stopping near the portal.
- **Slow deaths for weather:** rain = a flood sweeps you away; soil downpour = you are buried under a mound with a little cross; sandstorm = sand piles into a grave; blizzard = snow burial; volcano ash = a glowing slash, then you crumble to ash. You cannot move; then the crying scene comes (death now lasts 3.6 s for these). Tune: `sdOver`, `sdPlayer`, `world.deathLen`.
- Not played by a human yet.

# v3.2 — CHAPTER 2 UPDATE: SOIL, THORNS, CENTIPEDES, WOODEN LEVER
- **Soil downpour (Crust, stages 1-6, from level 2 of stage 1):** the ground-level storm of Chapter 1 is now a cave-in. A yellow **!** sign counts down **3 seconds** (the ceiling darkens and shakes), then a lot of soil pours down from the top of the screen. Stand under a shelter (timber roof with a soil mound on top) or the soil buries you. Every shelter is also a save point. Deeper biomes have no downpour. Tune in game.js: look for `'dirt'`, `drawDirtCeiling`.
- **Wooden thorns instead of the red spikes** (Crust and Rock Layer): the traps that rise out of the ground are now sharp thorny wooden stakes (roots in the Crust, dry grey wood in the Rock Layer). The deeper biomes keep their glowing spikes. Tune: `drawSpikeSkin`, branch `th===5||th===6`.
- **Centipedes instead of bats (chapter 2):** a long centipede crawls along the ground toward you; jump over it. Chapter 1 keeps its bats. In the Crust the number of centipedes now changes from level to level (1, 2 or 3).
- **Wooden lever (chapter 2):** the golden mechanism is now a wooden lever. Before you touch it the knob and the little plate are **blue**; when you pull it down they turn **green** and the blue light beam goes away. Tune: `drawWoodLever`.
- Engine Checks: 43, all pass in headless Chromium (2 new: soil downpour, centipede/thorns/lever; 1 updated: Chapter 2 may only have the soil downpour as weather).
- Not played by a human yet: please check the feel of Crust stages 1-6 (how fast the shelters are to reach, how long the centipede takes to arrive).

# v3.1 — CHAPTER 2 UPDATE: BENEATH
- **Graphics freeze fix (medium/high):** removed the `desynchronized` canvas option (can freeze the picture after a resize on some phones); the frame loop can no longer die from one failed frame; repeated render errors fall back to LOW; medium/high lower their load faster when the phone struggles; switching graphics restarts timing cleanly; canvas context loss is recovered. Not verified on a real phone.
- **Hidden pit-grabber (`maw`):** invisible until you step on it; pulls you down for up to 2.7 s. Tap JUMP fast (about 4 taps) to break free, otherwise you are swallowed. While held, other traps cannot kill you and the chaser waits. Mostly in the Crust and Rock Layer, fewer deeper. Tune in game.js: look for `maw`, `grabStep`.
- **Creepers:** the chaser is now a living creature (grass/root creeper, gravel beetle, magma worm) and starts from level 3 of each stage.
- **Burrow save-house:** chapter 2 saves are small burrows dug into the soil (lantern lights up when saved).
- **Layer chunk:** the falling LEVEL HARD sign is a soil clod / rock slab / molten block in chapter 2.
- **Layer debris:** each layer drops its own material from the ceiling (soil, stone chips, hot ash, sparks). No clouds, no rain.
- Engine Checks: 41, all pass in headless Chromium (1 new for the grabber).

# v3.0 — CHAPTER 2: BENEATH (first version)
- **Story link:** entering the exit portal of Chapter 1, stage 26, level 5 now plays a ~21 s video-style cutscene (SKIP button / Enter / Space): portal vortex -> a lift -> the lift ceiling goes black -> the long ride down in the dark (depth counter) -> arrival, still black -> the ceiling lamps switch on one by one and reveal the underground -> title card -> Chapter 2, stage 1, level 1.
- **Chapter 2 = 32 stages x 5 levels (160 levels, ids 130-289).** Five biomes: **The Crust** 1-6 (roots, soil, cave bats, light rockfall) · **The Rock Layer** 7-12 (granite, glowing crystals, rockfall, drafts, deep darkness) · **The Mantle** 13-19 (glowing rock, magma conveyor belts, fire vents, magma bombs) · **The Outer Core** 20-25 (molten metal sea, sinking plates, fire, ceiling crushers) · **The Inner Core** 26-32 (white-hot, pressure gusts, everything at once).
- Difficulty ramps from the middle of Chapter 1 up to its hardest. No sky storms or cold underground. Tune in game.js: `makeLevel` (look for `ch2`, `bio`, `cs`) and `bioOf()`.
- Stage select shows both chapters; progress is one save (290 levels, 870 stars).
- Engine Checks: 40, all pass in headless Chromium (Chapter 1 checks unchanged; 6 new ones for Chapter 2, the bot crossing all 160 levels, the cutscene flow and rendering every cutscene moment).
- Not played by a human yet: please play-test the feel of stages 1, 7, 13, 20, 26 of Chapter 2 and watch the cutscene once.

# v2.4
- **Fire (volcano, stage 22+):** the fire vent now sits on a real stone, well inside it (at least 46 units from either edge, never over a gap or at a corner). It is always visible as a dark obsidian lip with a glowing crack; it glows and throws embers while it warns, then burns with layered flame tongues, a glow and sparks, and shrinks away smoothly. The vent now rides its stone, so when the stone sinks and rises the fire goes down and up with it.
- **Removed** the red gate that popped out near the exit and went away again (stage 24+), together with the small stone beside it.
- **Saves:** every level has exactly 2 saves (was 2 or 3).
- **Shields:** stages 1-6 have none, stages 7-16 have 1 per level (at the last save), stages 17-26 have 2 per level (1 at each save). You still hold at most 1. Tune in game.js: shieldsFor(stage), saveCount(), MAX_SHIELDS.
- Engine Checks: 34, all pass in headless Chromium (2 updated, 1 new for the fire).

# v2.3
- **Touch controls rewritten:** the held buttons are rebuilt from the fingers really on the screen on every touch event, so left/right can no longer get stuck; hit areas are 10px bigger than the drawn buttons; sliding a finger from LEFT to RIGHT switches direction; jump is queued the instant the finger lands.
- **Bigger buttons:** default size 76 -> 108 (old default is upgraded), slider up to 150, JUMP is 1.3x the size of the arrows, more gap between the arrows.
- **Less lag in HIGH (same look):** glow (bloom) refreshes every 2nd frame, solid canvas without alpha blending, and if a phone still cannot reach about 45 FPS it automatically refreshes the glow/background less often (and only as a last resort drops from 3x to 2x sharpness). Slow frames were what made jump feel delayed.

# v2.2
- **Removed** the red-toothed wall that rose and sank at the ground (stage 15+). The ceiling crusher (stage 22+) is unchanged.
- **Weather sounds:** each storm now has its own real noise-based sound that fades in with the storm and is muffled under a shelter: rain = steady rain hiss, sandstorm = gusting wind with grit, blizzard = howling whistling wind, eruption = deep rumble with crackling. The old beeps at storm start were removed.

# TRAPBOUND: THE FINAL RUN — CHAPTER 2  ·  v2.1

## v2.1 — fewer shields, lever pull animation, FPS limit up to 360
- **Shields:** exactly 1 shield per save, and you can hold only 1 at a time (was up to 2 per save in hard levels, hold 2). Tune with SHIELDS_EASY / SHIELDS_HARD / MAX_SHIELDS in game.js.
- **Lever (blue key):** touching it now plays a short pull-down animation; the lever turns from blue to green, the tall blue light beam above it and the blue beam on the exit lock fade out (a brief green flash) instead of vanishing instantly, and the message says the blue light is gone and the exit is open.
- **Settings > FPS LIMIT:** 60 / 120 / 144 / 240 / 360 (default 360). The old hard cap of about 100 frames per second is gone. The player and camera are interpolated between the 120 Hz physics steps, so motion is smooth at any FPS. A screen can never show more frames than its refresh rate, so on a 60 Hz phone you still see 60.
- Graphics unchanged (HIGH keeps full sharpness, bloom and effects); the bloom downsample is a bit cheaper.
- Engine Checks: 33, all pass in headless Chromium. Not measured on a real phone/GPU.

# TRAPBOUND: THE FINAL RUN — CHAPTER 2  ·  v2.0

## v2.0 — fewer saves, shield counter, prettier volcano, graphics levels
- **Saves:** every level has exactly 2 (easier levels: crypt 1-6, forest levels 1-3) or 3 saves (harder levels). Flags and shelters count together; unused shelters still protect from storms but do not save. A save placed after the golden mechanism restores with the exit already open.
- **Shields:** 1 per save in 2-save levels, 2 per save in 3-save levels. You can hold at most 2; each hit uses one. Tune with SHIELDS_EASY / SHIELDS_HARD in game.js.
- **Volcano:** obsidian spikes with glowing edges and cracks; the lava is now an animated sea with layered waves, bubbles and sparks.
- **Settings > GRAPHICS:** LOW (old look, fast), MEDIUM (default, sharper), HIGH (up to 3x sharpness, full-res background every frame, bloom glow, more effects, no auto-reduce). Saved between sessions.
- Engine Checks: 33, all pass in Node. HIGH rendered in headless Chromium without errors. Not tested on a real phone.

# TRAPBOUND: THE FINAL RUN — CHAPTER 2  ·  v1.9 (shelters are saves, small log tripod, gentler blizzard, sharper picture)

## v1.9 — shelters are save points, log-tripod fire, gentler blizzard, a little more graphics
- **Every shelter is also a save.** Walk into a shelter (the fire in the snow, the shade in the desert, the roofs elsewhere) and it is saved; if you die afterwards you wake up INSIDE that shelter, never at an older flag or at the start. Shelters carry a small pennant (grey until saved, gold after); in the snow the fire flares up once it is saved. Flags still work as before, and all saves are ordered left to right, so the newest one always wins. (In levels with the blue key, shelters beyond the key zone are not saves, so you cannot respawn past the key.)
- **Snow shelter = three logs and a fire.** The log hut is gone. It is now a small tripod of three logs leaning together with a campfire in the middle and a little snow on the legs (80 units wide instead of 96 + a big separate fire). Standing at the fire is still the safe spot for the blizzard and the cold.
- **Blizzard is much gentler** (Frozen Peaks only): the blizzard now starts later in the level (never in the first ~30%), warns **5 seconds** instead of 3, and standing outside takes about **4 seconds** to kill instead of under 2. The white-out fog is lighter. Rain, sand and ash storms keep their old timing.
- **Cold bar is longer:** 18 s on stage 18 down to about 16 s on stage 21 (was 9.5 to 7.5 s); fires warm you from a bit further away and the start of the level is always warm.
- **Graphics (small step up):** sharper far background (it was drawn at half resolution; now 60% on phones, 75% on desktop), the quality fallback now drops effects first and resolution much more gently (it used to fall to 0.75x, which looked blurry), stones have a light top edge and soft shading, a soft vignette, and a contact shadow under the character.
- Engine Checks: 31 (4 new: shelters are saves and ordered, dying wakes you in the shelter, tripod + later/gentler blizzard + long cold bar, 2 s of exposure never kills). All pass in headless Chromium. Not played on a real phone by the assistant: please check the feel of stages 18-21.

## v1.8 — weather from under the clouds, 2 good shelters, one shield per save, surprise stalactites
- **Weather comes from the clouds.** Rain, sandstorm streaks, snow and ash now start at the cloud base (84 units below the top of the view) instead of the very top of the screen, and the cloud bank is drawn over the top edge of the drops. The calm snowfall of the Frozen Peaks also starts under the cloud layer and fades in. Nothing falls under a roof.
- **Shelters: exactly 2 per storm level, 3 only when the level is long (2300+ wide) or the exit hops to the start / needs the blue key**, always spaced at least ~225 units apart (normally 300+). Storm triggers are placed about 340 units before a shelter so one is always ahead of you.
- **Snow hut + big fire.** On the Frozen Peaks a shelter is a log hut (walls, glowing window) with a large campfire beside it. A shelter and its fire now also count as warm: your warmth bar refills there (before, the cold ignored shelters, so it felt like standing in nothing).
- **One shield per save flag, none anywhere else** (the extra shield orbs along the way were removed).
- **Stalactites, icicles and boulders fall with no warning** (no rumble, ring, shadow or grit). They only wake while you stand on the ground and are still ahead of the object, and they land ahead of you, so it is a surprise but not a cheap kill. Meteors and earthquakes keep their short warning.
- Engine Checks: 27 (new: weather starts under the clouds and not under roofs, a shelter in the cold is warm and has a fire, one shield per flag, shelter counts/spacing, stalactites without warning). All pass under Node; the storms were also rendered in headless Chromium without errors. Not played on a real phone by the assistant.

## v1.7 — storms, shelters, real clouds, less lag, calmer exit portals
**Less lag (desert and ice were the worst).** (1) The platform art (sand strata, snow caps, icicles, gravestones...) used to be re-drawn path by path every frame for every stone; it is now drawn once per stone into a small cached picture. (2) The far background is drawn at half resolution and only every second frame. (3) The game watches its own frame rate: if it stays under about 35 fps it lowers the render resolution (down to 1x, then 0.75x) and switches on a low-effects mode (fewer particles). (4) Phones start at 1.5x instead of 2x pixel density, the screen is not redrawn faster than ~100 Hz, and the little face canvas on the death screen is only drawn when that screen is open.

**Real clouds.** The two-circle clouds are gone. Clouds are soft, layered puffs (shaded underside, lit top, feathered edge) drawn from small cached pictures. Every biome has its own sky clouds (misty crypt, green forest haze, dusty desert, white snow clouds, smoky volcano) and storms bring a dark cloud bank that covers the top of the screen.

**Whole-screen storms (stage 4+).** At a fixed spot in the level the sky turns black: a black warning sign with a countdown shows **3 seconds**, then the storm hits everywhere. Stand under a **shelter** (a small roof on posts: wooden roof, leaf roof, striped desert shade, snow roof, rock overhang) or a protection bar drains and you die; the bar refills under a roof. Shelters glow with a yellow arrow during the warning and the storm. Later stages have more storms (up to 3), stronger and longer ones.
- Crypt 4-6: light rain (1 storm).  Forest 7-11: rain with lightning.
- Desert 12-16: sandstorm and heat: tinted orange, sand streaks, and it also pushes you sideways.
- Frozen Peaks 17-21: blizzard: heavy snow that nearly whites out the screen; only shelters, the character and the exit stay clearly visible.
- Volcanic Core 22-26: eruption: red sky, falling embers and ash, rumble and screen shake at the start.
Stage 1-3 have no storms, and the first level of every biome has none either. The old small acid/hail rain patches were removed (the storms replace them). A shelter stone loses its hidden floor spikes so it is a safe place; the long trap stone keeps its trap and the shelter is placed beside it.

**Exit portal: fewer tricks.** Only three kinds are left: a normal exit, an exit that jumps **once** from the end to the start, and an exit with a **blue lock** that a blue switch opens. The roundtrip (end, start, end), vanish, fake door, jump/landing shift and high-route variants are no longer used. The blue lock is drawn as a blue padlock with a tall blue light beam so it can be seen from far away and through snow; the switch has the same beam and an off-screen arrow says BLUE KEY.

**Checks.** `Settings > Run Engine Checks` has 24 checks (the old moving-portal check was replaced; new ones cover the portal modes, storm placement per biome, 2+ safe shelters per storm level, the 3-second warning, shelter protection, and cloud art). All pass under Node with a stubbed DOM, and every storm type was rendered through a stubbed canvas without errors. It has NOT been run on a real phone or in a real browser by the assistant, so frame rate and the look of the clouds still need your eyes.

## v1.6 — five biomes, medium difficulty, many more saves
**Biomes (26 stages):** Haunted Crypt 1-6 (scary, bats, skeleton hands from the ground) · Enchanted Forest 7-11 (thorn vines, acid rain, wind) · Scorched Desert 12-16 (cactus, scorpion claws and snakes pop out of the sand, quicksand, small earthquakes, acid rain) · Frozen Peaks 17-21 (real snow drifts, icicles, ice spikes from the floor, slippery ice, icy hail, and from stage 18 the COLD: a warmth bar drains away from fires, flags are campfires that refill it, reach the next fire or you freeze) · Volcanic Core 22-26 (lava spikes, lava flow belts, fire bursts, sinking stones, meteors, acid rain). The old "Final Nightmare" theme was replaced by the volcano as the last biome.

**Medium difficulty:** gaps are narrower (about 10-15% on top of v1.5) and more stones are joined into continuous ground; collapsing/vanishing/timed floors are rarer and start later; one signature gimmick per biome; only one falling object per level; only one dash blade (stage 10+, with a 0.65 s red arrow warning); the chaser starts at stage 6 and is slower; exit tricks start at stage 10 and only in levels 3-5 of a stage; saws from stage 5; the ceiling crusher, wall, gate and fire are rarer.

**More saves:** 2 flags in stages 1-3, 3 flags in stages 4-9, 4 flags from stage 10 (3 on the cold peaks, where flags are campfires). Two shield orbs per level up to stage 10, one later, plus one beside every flag.

**Falling things are fair now:** the jump-triggered ceiling trap is gone (nothing falls because you jumped). Falling stalactites/boulders only wake while you stand on the ground, give a 0.8 s warning (rumble, grit from the top of the screen, a red ring and shadow on the floor), are drawn as real stalactites/icicles/boulders (not a flat bar), and shatter on landing. The floor never collapses, vanishes or times out near where something falls or acid rains. Meteors/quakes wait until you are on the ground and give about a second of warning.

**Graphics:** meteors are fireballs with a flame and smoke trail, an explosion with a shockwave, rising smoke and a glowing charcoal scorch mark that stays on the ground. Per-biome backgrounds (desert dunes, mesas and cacti; snowy mountains, pines, aurora), platform art (sand strata and dry grass; snow caps with icicles; lava veins; gravestones, skulls and cobwebs), ambient life (sand, snowfall that gets heavier in the cold, embers, fireflies, fog), bats with flapping wings, campfires, frost on the screen edges when you are freezing.

**Hidden ground traps** still wake up suddenly, but now with a puff of dust and a sound, a little earlier and slower so a good player can react. Bats (crypt) fly in from the right and aim at your head, jump over them.

**Verification:** Engine Checks (Settings > Run Engine Checks) were updated and extended (biome bands, bats only in the crypt, cold only on the peaks, fairness of floors near falling objects, 3-4 flags in hard stages, cold bar). They pass in headless Chromium together with a render smoke test of all 130 levels. No human playthrough was done by the assistant; please play-test stages 3, 9, 13, 19, 23 for feel. Old saves keep their unlocks (flag indexes of older runs are ignored if the layout changed).


## Play
Open index.html in a current browser. No network, account, external library, paid API, or downloaded asset is required. On Android, serve the folder over HTTP or package it in a WebView: some Android file managers do not launch local HTML with script permission.

## Landscape (v1.1)
The game is landscape from the first frame, with no button or setting. On a touch device held upright (or with auto-rotate off) the whole stage is rotated 90 degrees by CSS, so the player simply turns the phone sideways. On the first tap the game also tries fullscreen plus a real landscape lock; where the browser allows it the OS rotation takes over, otherwise the CSS rotation keeps working. Menus, death, win and stage-complete screens use a compact two-column layout and fit on one landscape screen without scrolling (only the stage list scrolls). For the final Android APK also set the activity to `android:screenOrientation="sensorLandscape"` (Capacitor: AndroidManifest.xml), which makes the OS-level lock permanent.

## Camera
The camera is closer: about 420 world units of height are visible instead of 600 (the character is roughly 40% larger on screen). Change `420` / `480` in `resize()` in game.js to zoom more or less.

## Hidden traps (v1.1)
No trap is telegraphed any more: no warning marks, dotted lines, glow, cracks, shaking, blinking tiles, vent bases, gate outlines, rune zones, hanging sign, or hint text. Traps appear without warning: spikes shoot up from the floor, spikes/rocks/signs fall from above within a fraction of a second, saw blades dash in from the left or right (stage 6+, `dash`), fire bursts from the ground, gates slam shut, and collapsing/vanishing/timed floors look like ordinary stone. Traps are deterministic, so a player can learn them by memory. Patrolling saws, the moving wall and the ceiling crusher stay visible because they are moving obstacles.

## Project
index.html: semantic shell and Canvas.
style.css: responsive menu and touch layout.
game.js: original Canvas art, 120 Hz simulation, Web Audio synthesis, deterministic level generation, menus, progression, settings, input, and engine checks.
tests.html: in-browser checks and manual QA checklist.
manifest.webmanifest: optional packaging metadata; not an offline service worker.

There are exactly 26 stages with 5 generated, deterministic arrangements each, not 5 levels reused under new labels. Every level has a spawn, floor geometry, hazards, and physical exit. Difficulty and traps vary by stage and slot. Geometry generation is constrained by the player's jump range. This is not evidence that every dynamic combination has been playtested.

## Controls
Default movement: A / D, Left / Right. Jump: Space / W / Up. Pause: Escape. Restart: R. Settings > Custom Controls remaps keys, swaps conflicts, adjusts touch size and horizontal/vertical offsets, and binds canvas left-click optionally. Touch buttons accept simultaneous pointers. Pause clears held inputs. Re-press held keys after resuming.

## Saves
Progress and settings use trapbound.v1 and trapbound.backup in localStorage. Saves are local to the browser and origin. Private browsing, blocked storage, or clearing site data can lose progress. Sequential completion unlocks the next level; completing slot 5 unlocks the next stage immediately. Replay never erases unlocks. Reset Progress requires confirmation.

## Audio
Press any game button to initialize Web Audio. Settings control master, music, effects, and mute. All effects and environment music are synthesized locally. Browser or OS mute still applies.

## Verification status
Executable checks cover stage counts, sequential unlocks, terminal progression, duplicate completion, save round-trips, malformed save sanitization, deterministic trap resets, baseline jump geometry, portal overlap guards, end/start/end relocation, collision overlap, and death/transition one-shot guards. Checks execute in the user's browser. The generated artifact has not been executed in a browser by the assistant, and no desktop/Android audio, pointer, or full 130-level playthrough is claimed. Review tests.html and record actual results before release.

## Android packaging
This is a web game, NOT an APK. A later Capacitor wrapper can use a www directory containing index.html, style.css, game.js, and manifest.webmanifest. Configure webDir as www and appId as an appropriate reverse-domain identifier, add Android, sync, and build using Android Studio and its SDK. Capacitor and Android build tools are development dependencies; the game runtime needs none. Verify safe areas, multitouch, audio focus, Android Back behavior, orientation, signing, and localStorage persistence in the actual wrapper. A manifest alone does not make an installable offline PWA.

## Release caveats
130 layouts are generated from deterministic design rules, not individually hand-authored or certified beatable by a solver. Collapsing and disappearing floors regenerate, pursuing hazards stop before the final terrace, and relocated exits retain traversable ground routes. The engine is intentionally lightweight rather than a production physics library. Static geometry checks cannot validate all hazard timing, landing order, or device-specific browser behavior. Run full playthrough and device QA before calling this a finished release.

## v1.5.1 fixes
- **Movement button dropping out / hitching when jumping:** every tap (including the jump button) asked the browser for fullscreen, and that triggered a resize that cleared all held buttons and re-created the canvas. Now resize does nothing unless the window size really changed, never clears held buttons, fullscreen is only requested from menus (max 6 tries), and gameplay taps never trigger it.
- The "Download project zip" option was removed from Settings.

## Level Hard Clud 2 · End (v1.5)
- **Fullscreen fixed.** Browsers refuse fullscreen on a touch *pointerdown*; v1.4 asked at that moment. It now asks on pointerup / touchend / click (every tap until granted) and keeps the FULL SCREEN buttons. If the game is opened inside another app (file manager, in-app viewer) that app draws its own title and navigation bars and no web page can remove them: open index.html in Chrome, or use Add to Home Screen (manifest is fullscreen).
- **Save flags.** 1 flag in stages 1-3, 2 flags from stage 4. Touching a flag saves it (also to the device: closing the game keeps it). Dying, R and RESTART return to the last flag; the Play button resumes from it; Pause has BACK TO LAST FLAG and RESTART FROM START. Collected stars up to the flag are kept; finishing a level clears its flag.
- **Shields at flags.** Every flag has a shield orb beside it (it respawns each time you come back). A shield absorbs one hit; you can take another orb later. Stages 1-7 also have one more orb on the way.
- **Softer map.** Neighbouring solid stones now join into continuous ground (about half of the joins in the castle, two thirds in the forest, three quarters later) and gaps are 12-20% narrower, so there are far fewer valleys.
- **One signature trap per band, never repeated afterwards:** wind 8-10 (and a light return in 25), ice floors 11-13, earthquakes (shaking, three falling rocks with ground shadows) 14-16 and 26, meteors 17-19, conveyor belts 20-22 and 26, darkness only 23-24, sinking stones 22 and 25. No stage has more than two of them. The first level of each band is gentler.
- **Life in each biome:** drifting dust (castle), fireflies (forest), rising embers (fire), purple ash (nightmare).
- Engine Checks: 18 + 5 v1.4/v1.5 checks, including the invulnerable bot crossing all 130 levels.

## Level Hard Clud 2 · End (v1.6)
Changes made after play feedback on Claud 3:

**Menus scroll everywhere.** The stage list stopped at stage 24 because long panels could not be scrolled when the game is rotated by CSS (the browser's own scrolling pointed the wrong way). Panels now scroll by touch drag, mouse wheel and two on-screen arrows (▲ ▼) that appear whenever there is more below. Settings, Controls, Stage select and Level select have a sticky BACK button at the top, Settings has LEVEL SELECT and (from pause) RESUME GAME, and Settings/Controls use two columns so far less scrolling is needed.

**Whole screen.** Every touch asks for fullscreen + landscape lock until it is granted; FULL SCREEN buttons exist in the main menu and Settings; the page uses a dark colour scheme (no white scrollbars or edges) and a fixed full-viewport body. iPhone Safari has no fullscreen API: use Share > Add to Home Screen.

**Easier opening (stages 1-7, Haunted Castle).** About 18% smaller gaps; the first collapsing stone starts at level 3 and the first vanishing stone at level 5 of stage 1; no saw before stage 4, no falling spike before 5, no jump trap before 6, no dash blade before 8, no chaser before level 4 of stage 5-7; falling traps trigger earlier so they land behind you; exit tricks start at stage 7; ordinary floor spikes start at stage 5 (the long and high stones keep theirs).

**Energy and morale.** 3 stars per level (the high ones sit on spiked upper stones: risk and reward, saved per level, shown in HUD and menus), shield orbs (block one hit, then brief invulnerability; 2 per level in stages 1-7, 1 in 8-16, only on even levels from 17), a checkpoint flag near the middle of most levels (restart after death returns there; the death screen also offers a restart from the start; R on the death screen uses the checkpoint), cheerful messages, how the player died, % of the way and attempt number.

**Harder from the Nature biome, with new kinds of danger, not only blades.** Wind gusts that push you in the air (stage 8+, 1 to 3 zones, drifting streaks show them), sinking stones (9+), ice floors that slide (10+), conveyor belts (12+, chevrons show direction), meteor showers with a short ground warning (17+), and darkness that hides everything outside a lantern radius (22+, radius shrinks to stage 26). Levels also get longer and gaps wider after stage 7, and some traps trigger later so they land on you.

**Verification.** `Settings > Run Engine Checks` now has 5 more checks (stars/shields/checkpoint, biome gating, gentle opening, an invulnerable bot that must cross the main route of ALL 130 levels, and a 12-second smoke run). They pass under Node with a stubbed DOM and in headless Chromium (menus, rotated and unrotated scrolling, play screens, no uncaught errors). The bot is not a human: it does not prove that every hidden-trap combination is fair. Please play-test stages 8, 10, 12, 17 and 22 for feel.

## Level Hard Claud 3 (v1.3)
Changes made after play feedback on Claud 2:

**Floors you can trust (forward and back).** Collapsing, vanishing and timed floors are rarer than before and are never the first or last stone of a level and never next to each other, so there is always ordinary solid ground both ahead of and behind every one of them. Collapsing floors now hold for about 0.85 s (vanishing 0.75 s) instead of under half a second, they grow back after 1.4 s everywhere, and a timed floor never disappears while you are standing on or just above it.

**No control reversal.** The left/right reversal trap has been removed completely: no zones, no flipped movement, in any stage. (The old level title "Reversal" is now "Ambush".)

**A trap in the long place.** From stage 2 two neighbouring solid stones are fused into one very long stone, with hidden floor spikes in the middle (two spikes from stage 12).

**A trap in the high places.** The optional upper stones (from stage 3) carry hidden spikes; from stage 10 they carry two, which is harder.

**Verification.** `Settings > Run Engine Checks` has new checks for the points above. They were run under Node with a stubbed DOM (all 14 checks passed); the game itself has not been played in a real browser by the assistant, so please play-test the new zones and traps.

## Earlier notes
Spikes ride their platform (moving platforms carry them, collapsing platforms remove them).


## Version 33 — Mantle biome overhaul
- Reworked the Mantle palette and background around compacted brown soil and wet clay, not lava or fire.
- Repainted mantle platforms with thick, layered soil and viscous drips.
- Removed mantle fire vents and increased the ground-grabber hazards.
- Added three-second soil-downpour events with shelter/checkpoint houses in mantle stages.
- Kept Chapter 1 and the Crust/Rock Layer generation and palettes unchanged.

### v3.8 — Outer Core biome refresh
- Reworked Chapter 2 stages 20–25 into a cooler liquid-metal/magnetic-current biome, distinct from the volcanic Inner Core.
- Replaced the orange lava sea, embers, and volcanic platform accents with dark steel, teal metallic currents, and muted brass highlights.
- Removed ground spikes, falling spikes, fire vents, rocks, chasers, ceiling crushers, and dash-blade hazards from the Outer Core. Kept the sinking/belt-floor variety and added magnetic pressure wells using the existing grab-trap mechanic.
- Outer Core saw hazards render as smooth magnetic rotors rather than sharp toothed blades.
- Added an engine regression check for Outer Core hazard exclusions and magnetic wells.
- Verification in this build: JavaScript syntax check and ZIP integrity check. Full browser run timed out in this environment; visual/gameplay behavior still needs in-game confirmation.
