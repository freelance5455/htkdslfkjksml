V84 update: Removed the non-working "Download Excel template" control from the Excel import dialog. Paste Excel Data remains available and working; Choose File remains unchanged.

# Daily Progress Manager — V51 baseline

V56 is the current stored baseline. It fixes the Android Choose File and Download Excel controls with native fallbacks and preserves existing Supabase/import behavior.

V49 is based directly on V47 and fixes the Android Excel picker path with an explicit native bridge.

V43 is based on V42 and hardens the three Excel import actions for Android.

## V44 — Excel Import Root Fix
Choose File now uses a real label/file-input control for Android WebView compatibility; native Android parsing runs once and feeds the preview directly. Download Template uses the system save flow.

## V42 — Excel Import Buttons Fix
Based directly on V41. Download Excel template, Choose File, and the Excel import path have been repaired for Android/Web without changing the Supabase schema. Android native file/save dialogs now run on the UI thread.


## V37 — Excel Item Import
Dashboard now includes **Import Excel** for bulk item creation. It accepts .xlsx, .xls and .csv files, previews rows, and imports them in batches.
# Daily Progress Manager V3 — Supabase setup

The Android/Web app is already configured with the Supabase Project URL and publishable key supplied for this project.

## A. Run the database SQL

1. Open your Supabase project dashboard.
2. Open **SQL Editor** → **New query**.
3. Open `supabase-schema.sql` from this ZIP and paste the whole file.
4. Click **Run**.

## B. Create the first administrator

1. Open **Authentication → Users**.
2. Choose **Add user** / **Create user**.
3. Enter the administrator email and password and create the user.
4. Return to **SQL Editor** and run this, replacing the email:

```sql
update public.profiles
set role = 'admin'
where email = 'YOUR_ADMIN_EMAIL';
```

The profile row is created automatically by the trigger in `supabase-schema.sql`.

## C. Deploy the admin-create-user Edge Function

The app's administrator screen calls:

`/functions/v1/admin-create-user`

The source is in:

`supabase/functions/admin-create-user/index.ts`

Deploy that function from the Supabase dashboard's Edge Functions area, or with the Supabase CLI. The function uses the server-side `SUPABASE_SERVICE_ROLE_KEY` automatically supplied by Supabase. **Do not put that key in the Android app.**

### Dashboard deployment

1. Open **Edge Functions**.
2. Create a function named exactly `admin-create-user`.
3. Replace its generated code with the contents of `supabase/functions/admin-create-user/index.ts`.
4. Deploy it.

No service-role key needs to be copied into the app.

### D. Deploy the admin-delete-user Edge Function

The administrator screen uses:

`/functions/v1/admin-delete-user`

The source is in:

`supabase/functions/admin-delete-user/index.ts`

In Supabase Dashboard → **Edge Functions**, create a function named exactly `admin-delete-user`, replace the generated code with that file, and deploy it. The function uses the server-side `SUPABASE_SERVICE_ROLE_KEY` that Supabase provides to the Edge Function. **Never put the service-role key in the Android app or HTML.**

This function refuses self-deletion and requires the caller to be an enabled administrator. Because `profiles` and `items` are linked with `on delete cascade`, deleting the Auth user removes the associated profile and the user's items/history as well.

## E. Build the Android app

Open the `android` folder in Android Studio or AndroidIDE and build the APK.

The app includes the Android `INTERNET` permission and is already configured to use the supplied Supabase project.

## Security

The publishable key is intended for client-side use. Database security is enforced with Row Level Security. Never place a Supabase service-role/secret key in the APK, HTML, JavaScript, or any other client-side file.

## Password change and forgotten-password reset

The app now supports two password flows:

1. **My Password** (while logged in): the user can enter the current password and set a new one.
2. **Forgot password?** (from the login screen): Supabase sends a recovery email, and on Android the link returns to the app using the custom deep link `dpm://reset-password`.

### Required Supabase Auth redirect URL

In Supabase go to **Authentication → URL Configuration → Redirect URLs** and add:

`dpm://reset-password`

For a web-hosted copy of the app, also add the exact HTTPS URL where the web app is hosted if you want password reset to work from the browser.

Password reset emails require Supabase Auth email delivery. For production use, configure a custom SMTP provider; the default email service is rate-limited and intended for testing/trial use.


## V62 Excel picker fix
- Version 2.28 / versionCode 32.
- Excel Choose File uses the HTML file input from the user's tap.
- Android WebView routes the file input to the in-app Downloads picker first, avoiding the broken DocumentsUI path on affected Android 14 builds.
- Selected files are returned to WebView for the existing Excel/CSV parser.


## V66 Excel native picker result fix
- Version 2.32 / versionCode 36.
- Choose File launches Android's native document picker directly and handles its returned content URI in MainActivity.
- The native XLSX/CSV/TXT parser feeds the selected rows back into the import preview.
- If a device has no system document picker, the app falls back to an in-app Downloads list without doing the MediaStore query on the UI thread.


# V71 Excel Choose File Fix
Built from V70. Fixed Android Choose File flow by removing the READ_EXTERNAL_STORAGE permission gate and separating native picker requests from WebView file-input callbacks. Native picker now launches ACTION_GET_CONTENT directly without extra MIME/permission restrictions; onActivityResult now parses native selections and sends rows to the existing preview.

# V72 Excel Buttons Final Android Flow Fix
- Dedicated Android request code for the native Choose File flow.
- ACTION_OPEN_DOCUMENT with explicit Excel/CSV support.
- Fallback to the app-owned Downloads picker if no Android document picker exists.
- Separate WebView file chooser request handling.
- Download Excel template falls back to Android Save As if direct Downloads creation fails.
- Existing Supabase setup and banked-entry delete functionality preserved.


V78 Excel picker fix: Choose File now uses a custom dpm-import:// URL intercepted by MainActivity, so it does not depend on the WebView JavascriptInterface bridge or onShowFileChooser callback.

## V121 — VIEW VISITS TODAY
The dashboard now has a **VIEW VISITS TODAY** button. It opens a list filtered to the current date and includes a date picker to review other days. Only items with stored daily activity (visits, amounts given, cash pulls, Banked/MTN SENT entries, or notes) are displayed. The feature is available in both the web app and Android WebView assets. See `VIEW_VISITS_TODAY_V121.md`.
