# 🤖 ASION AI — Google Agent

AI lokal berbasis Ollama (qwen2.5:7b) yang bisa **browsing Google otomatis** menggunakan Puppeteer.
Tanpa API key berbayar. 100% gratis dan berjalan di komputer kamu.

---

## ✅ Yang Dibutuhkan

| Kebutuhan | Download |
|-----------|----------|
| Node.js (v18+) | https://nodejs.org |
| Ollama | https://ollama.com |
| RAM minimal 8GB | Untuk model 7B |

---

## 🚀 Cara Jalankan

### Windows
```
klik 2x file: start.bat
```

### Linux / Mac
```bash
chmod +x start.sh
./start.sh
```

### Manual
```bash
# 1. Jalankan Ollama
ollama serve

# 2. Download model (sekali saja)
ollama pull qwen2.5:7b

# 3. Install dependensi Node
npm install
npx puppeteer browsers install chrome

# 4. Jalankan server
node server.js

# 5. Buka browser
# http://localhost:3000
```

---

## 🌐 Cara Kerja

```
Kamu tanya → Server deteksi → Perlu Google? → Scraping → Ollama proses → Jawab
                                    ↓ Tidak
                               Langsung Ollama
```

**Auto-browse aktif untuk pertanyaan tentang:**
- Berita terbaru, kejadian hari ini
- Harga produk, kurs mata uang
- Cuaca, suhu daerah tertentu
- Siapa presiden/pejabat sekarang
- Film, lagu, aplikasi terbaru
- Kata kunci: "sekarang", "terbaru", "hari ini", dll.

**Tombol 🌐 biru** = Paksa cari di Google untuk pertanyaan apapun.

---

## 📁 Struktur File

```
ai-google-agent/
├── server.js          ← Server utama (Express + Puppeteer + Ollama)
├── package.json       ← Dependensi Node.js
├── start.bat          ← Jalankan di Windows
├── start.sh           ← Jalankan di Linux/Mac
├── public/
│   └── index.html     ← Tampilan chat web
└── README.md
```

---

## ⚙️ Konfigurasi

Edit `server.js` bagian atas:
```js
const OLLAMA_URL = 'http://localhost:11434'; // URL Ollama
const MODEL = 'qwen2.5:7b';                  // Ganti model jika mau
const PORT = 3000;                           // Port server
```

**Model alternatif:**
- `llama3.2:3b` — lebih ringan (3GB RAM)
- `qwen2.5:14b` — lebih pintar (butuh 10GB RAM)
- `mistral:7b` — bagus untuk bahasa Inggris

---

## 🛠️ Troubleshooting

**Ollama tidak jalan:**
```bash
ollama serve
```

**Model belum ada:**
```bash
ollama pull qwen2.5:7b
```

**Puppeteer error:**
```bash
npx puppeteer browsers install chrome
```

**Port 3000 sudah terpakai:**
Ganti `PORT = 3000` di `server.js` jadi `3001` atau lainnya.
