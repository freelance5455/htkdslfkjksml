# Eswatini Scholars Network — improved release candidate

This ZIP contains the PWA website files, suitable for upload to a web-to-app wrapper.

## Included improvements
- Dedicated Learning Resources section with filters for resource category, study level and subject.
- Categories for Past Papers, Marking Schemes, Examiner's Reports, Notes, Practical Guides and Revision Materials.
- School detail pages offer Google Maps search and directions links; map results are not independently verified school pins.
- Updated service-worker cache name so devices can refresh to the latest release.
- Administrator sign-in checks the Supabase Auth session rather than relying on a hard-coded client-side passcode hash.

## Important limitations before public launch
- The resource library shows only materials actually published to the configured `learning_resources` table; this ZIP does not include a collection of exam papers.
- Verify Supabase Row Level Security (RLS) policies for `learning_resources`, `achievements`, storage buckets and any request tables. Client-side UI checks do not replace database permissions.
- Test school map links, all tabs, authentication, uploads, dark/light mode and offline behaviour in the generated APK on a real phone.
- The Google Maps embed uses a search query and may show approximate or multiple results. Confirm a school's exact location before using directions.
- Do not upload copyrighted examination material unless you have permission or it is officially made available for redistribution.

## Files
- `index.html`: application interface and logic
- `manifest.webmanifest`: PWA metadata
- `sw.js`: service worker
- `icons/`: app icons
