# Street Rush Android – Expanded

Features added:
- City and village tracks
- Morning, Day and Night
- Clear, Rain and Winter weather
- Summer, Monsoon and Winter season selector
- 11 fictional Indian-market-inspired car generations spanning 1989–2026
- Garage and unlock progression
- 4-player Friends lobby (host + 3 friends)
- Touch controls, PC keyboard controls, boost, coins and sound effects

## Multiplayer
The 4-player lobby is included, but real-time online racing needs a deployed multiplayer backend (for example WebSocket/WebRTC or a dedicated multiplayer service), matchmaking, and player accounts. This project does not pretend that local UI alone is online multiplayer.

## Real cars and logos
For a commercial release, use licensed vehicle names, logos and 3D models. The included roster uses fictional names so it can be used without copying manufacturer assets.

## Build
Open in Android Studio and choose:
Build > Generate Signed Bundle / APK
For Google Play, generate a signed `.aab`.
