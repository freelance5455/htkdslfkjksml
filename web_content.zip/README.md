# CryptoTrader v5 — compatibilidade Android 9

Versão preparada para Android 9/WebView antigo, com foco na página Configurações.

Alterações principais:
- campos de configuração isolados da navegação por swipe;
- navegação por toque reescrita com APIs mais conservadoras;
- removido o feedback global por Pointer Events;
- removido o pedido de Wake Lock ao primeiro toque;
- service worker/cache desativado para evitar ficheiros antigos presos no WebView;
- novo identificador de build e armazenamento de configuração v5;
- proteção de mercado e configurações de venda mantidas.
