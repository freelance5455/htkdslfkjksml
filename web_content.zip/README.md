# Block Blast

Мобильная головоломка в стиле Block Blast: поле 8×8, три фигуры, очистка рядов и столбцов, комбо‑серии, рекорды.

**Стек:** TypeScript · Phaser 3 · Vite · CSS · LocalStorage (React используется только как тонкий хост для canvas).

## Запуск

```bash
npm install
npm run dev      # разработка
npm run build    # production: dist/index.html (один файл, всё инлайнится)
npm run preview  # локальный просмотр сборки
```

## Геймплей

- Перетащите фигуру из лотка на поле — она «приподнимается» над пальцем, на поле показывается призрак и подсвечиваются линии, которые будут очищены.
- Полный ряд или столбец исчезает. Очки: `1 за каждый блок + 10 × T(линий) × комбо`, где T(1)=1, T(2)=3, T(3)=6, T(4)=10…
- Комбо растёт при каждой очистке и сбрасывается после **3 ходов подряд без очистки** (как в оригинале).
- Игра заканчивается, когда ни одну из оставшихся фигур нельзя поставить.
- Прогресс сохраняется после каждого хода (кнопка **CONTINUE** в меню), рекорд и статистика — в LocalStorage.

## Оптимизация под Android

- Автоопределение класса устройства (память, ядра, GPU, разрешение) → профили **low / mid / high**:
  лимит DPR (1 / 1.5 / 2), количество частиц, тени, аддитивные вспышки, размытые тени текста, анимация меню.
- Адаптивный FPS‑монитор: при просадках в режиме **AUTO** понижает профиль (и разрешение canvas) на лету и запоминает результат.
- Все текстуры генерируются процедурно в один атлас → минимум draw‑calls; пулы спрайтов для поля, призраков, вспышек и попапов.
- Звук синтезируется через Web Audio (без файлов), AudioContext разблокируется первым касанием.
- Вибрация через Vibration API (`navigator.vibrate`).
- `touch-action: none`, запрет зума/выделения/контекстного меню, учёт safe‑area (вырезы экрана).

Профиль графики можно переключить вручную в меню: **GRAPHICS: AUTO / LOW / HIGH**.

## Сборка APK (Capacitor)

```bash
npm run build
npm i -D @capacitor/cli && npm i @capacitor/core @capacitor/android
npx cap add android
npx cap sync android
npx cap open android      # Android Studio → Build → Build APK
```

Рекомендации для нативной сборки:

1. В `android/app/src/main/AndroidManifest.xml` добавьте
   `<uses-permission android:name="android.permission.VIBRATE" />`
   и у `MainActivity` установите `android:screenOrientation="portrait"`.
2. Для полностью офлайн‑приложения поместите шрифт Fredoka локально (например, в `public/fonts/`)
   и подключите его через `@font-face` в `src/index.css` вместо ссылки на Google Fonts.
3. Для иммерсивного режима (скрытие системных панелей) используйте плагин
   `@capacitor-community/safe-area` или `StatusBar.hide()` из `@capacitor/status-bar`.
