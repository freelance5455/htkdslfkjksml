# MOMEE — Fashion Affiliate App Prototype

## Run it quickly
1. Extract `MOMEE_prototype.zip` on your computer.
2. Open `index.html` in Chrome, Edge, or Firefox. Most features work locally.
3. On Android, transfer/extract the folder and open `index.html` in Chrome, or host the folder on an HTTPS static host for installable PWA behavior.
4. For best PWA install experience, serve over HTTPS and open the URL in Chrome; choose **Install app** or **Add to Home screen**.

## What works in this prototype
- Mobile-first home screen and product cards.
- Search demo products.
- Save/unsave products; browser-local persistence.
- Add your own product name, price and affiliate URL; open the URL.
- Generate editable Reel caption and hashtag text; copy it.
- Create a fashion image prompt and switch the concept preview between female/male looks.
- Demo sign-in form to personalize profile (not secure authentication).

## Important limitations
- Product names, prices, discounts and emoji visuals are sample data, not live offers.
- AI fashion model is a prompt/concept preview. Real image generation needs an image-generation API and backend.
- Login is demo-only and stores the profile in local browser storage. Do not enter a real/reused password. Production needs secure authentication.
- No live affiliate-network integration, click analytics, commission tracking, payment, or earnings payouts yet.
- Browser storage is device-specific and can be cleared by the browser.

## Production Android app roadmap
1. Backend API + database for accounts, products, saved items and click events.
2. Secure login (OAuth / Firebase Authentication or equivalent).
3. Approved marketplace affiliate APIs and compliant deep links.
4. AI image-generation service with consent, safety checks, usage limits and storage.
5. Analytics dashboard for clicks, orders and confirmed commissions.
6. Package using a native Android stack (Kotlin) or a cross-platform stack (e.g. React Native/Flutter), test, then publish through Google Play Console.

## Project files
- `index.html` — prototype UI and interactions
- `manifest.json` — installable web app metadata
- `sw.js` — basic offline caching
- `icon.svg` — MOMEE icon
