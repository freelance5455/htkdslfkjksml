# DualPlay - Android APK Source Package

This is the complete Android Studio project for DualPlay.

## How to Build the APK:

### Option 1: Using Android Studio (GUI)
1. Unzip this package.
2. Open Android Studio -> Select **Open an Existing Project** -> Choose this unzipped folder.
3. Click **Build** menu -> **Build Bundle(s) / APK(s)** -> **Build APK(s)**.
4. Android Studio will generate the signed/debug `app-debug.apk` in `app/build/outputs/apk/debug/`!
5. Transfer `app-debug.apk` to your Android phone and install!

### Option 2: Command Line (Linux / Mac / Windows)
```bash
./gradlew assembleDebug
```
The APK will be located at:
`app/build/outputs/apk/debug/app-debug.apk`
