# Agenda scolaire — projet Android (Capacitor)

Ce dossier transforme ton application en vraie application Android, avec accès
aux notifications locales natives : elles se déclenchent même si l'application
est complètement fermée, car c'est maintenant le système Android lui-même qui
les programme (et non plus une page web ouverte).

## Ce que ça change par rapport à ta version HTML actuelle

- Les rappels (notification et alarme) de chaque devoir/interrogation/révision
  et chaque examen sont programmés auprès du système Android dès que tu ouvres
  l'application une fois (pour les enregistrer). Ensuite, même app fermée,
  Android les déclenche lui-même à l'heure prévue.
- **Limite à connaître** : pour une alarme programmée à l'avance (app fermée),
  Android utilisera son propre son de notification par défaut — pas tes
  mélodies personnalisées ni un son importé. Les mélodies et le son importé
  continuent de fonctionner normalement quand l'app est ouverte.
- Le reste de l'application (horaire, examens, notes, design...) fonctionne
  exactement pareil, rien n'a changé côté interface.

## Comment obtenir l'APK (aucune installation nécessaire sur ton téléphone)

1. Crée un compte gratuit sur [github.com](https://github.com) si tu n'en as pas.
2. Crée un nouveau dépôt (bouton vert **New**), par exemple nommé
   `agenda-scolaire`. Laisse-le **public** ou **privé**, les deux fonctionnent.
3. Mets tous les fichiers de ce dossier dans ce dépôt (le plus simple : sur la
   page du dépôt, clique **Add file → Upload files**, puis glisse tout le
   contenu de ce dossier — y compris le dossier caché `.github`).
4. Valide l'envoi (**Commit changes**).
5. Va dans l'onglet **Actions** du dépôt. Une construction (« Build Android
   APK ») se lance automatiquement — ou clique **Run workflow** si rien ne
   démarre.
6. Patiente 3 à 6 minutes. Une fois terminé (coche verte), clique sur
   l'exécution, puis tout en bas sur **agenda-scolaire-debug-apk** pour
   télécharger le fichier `.zip` qui contient `app-debug.apk`.
7. Transfère ce `.apk` sur ton téléphone et installe-le (Android demandera
   d'autoriser l'installation depuis une source inconnue, comme d'habitude).

## À chaque mise à jour de l'application

Quand je te donne un nouveau fichier `index.html` mis à jour, remplace le
fichier `www/index.html` de ce dépôt par le nouveau (toujours via **Add file →
Upload files** sur GitHub, en gardant le même nom et chemin), puis valide —
la construction se relance automatiquement et un nouvel APK est prêt quelques
minutes après dans l'onglet Actions.

## Pour une vraie installation sur le Play Store plus tard

Cet APK de débogage (« debug ») s'installe très bien pour un usage personnel,
mais n'est pas signé pour une publication sur le Play Store. Si un jour tu
veux publier l'application, dis-le-moi : il faut alors une clé de signature
et quelques réglages supplémentaires.
