# Universal AI Complete 2.0

Evolução do arquivo original `universal_ai_web.zip`. Mantém a interface web e adiciona backend modular, Supabase, Firebase Admin, modelo substituível, pesquisa web e extensão Chrome com captura manual.

## O que está realmente implementado
- **Supabase/PostgreSQL** como banco principal: histórico, documentos, códigos de pareamento e tokens da extensão.
- **Pesquisa interna** PostgreSQL full-text search (GIN + `tsvector`), com ranking.
- **Pesquisa web** via Brave Search API; fallback DuckDuckGo Instant Answer é limitado e não equivale a resultados completos.
- **IA híbrida** via API compatível com OpenAI Chat Completions. O endpoint/modelo podem ser trocados por variáveis de ambiente. Hugging Face Router pode ser configurado como provedor.
- **Firebase Authentication** validado no servidor com Firebase Admin.
- **Chrome Clipper Manifest V3**: captura somente a aba ativa quando a pessoa clica no botão. Pareamento por código de uso único, token de extensão armazenado como hash no servidor.
- **Frontend original** atualizado para conversar com API, pesquisar e gerar código de pareamento Chrome.

## 1. Preparar Supabase
1. Abra o projeto `universal-ai` no Supabase.
2. Vá em SQL Editor.
3. Execute todo o arquivo `supabase/schema.sql`.
4. Em Project Settings > API, copie Project URL e `service_role` key.
5. A chave `service_role` fica SOMENTE no backend. Nunca coloque no HTML, extensão ou GitHub.

O tamanho da base depende do plano e do armazenamento disponível no projeto. Não existe espaço ilimitado gratuito.

## 2. Preparar Firebase
1. No Firebase Console, use o mesmo projeto da autenticação que a interface já usa.
2. Em Project Settings > Service Accounts, gere uma chave privada para Firebase Admin.
3. Salve como `firebase-service-account.json` na raiz deste projeto.
4. Não publique esse arquivo nem o envie para a extensão.

## 3. Instalar backend
Requer Node.js 20+.
```bash
npm install
cp .env.example .env
```
Edite `.env` e preencha:
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `FIREBASE_SERVICE_ACCOUNT`
- `AI_BASE_URL`
- `AI_API_KEY`
- `AI_MODEL`
- `BRAVE_SEARCH_API_KEY` (opcional, mas recomendado)

Depois:
```bash
npm start
```
Acesse `http://localhost:3000`. `GET /health` mostra quais integrações estão configuradas.

### Modelo de IA
O backend usa `/chat/completions` de um provedor compatível com OpenAI. Exemplo de configuração com Hugging Face Router:
- `AI_BASE_URL=https://router.huggingface.co/v1`
- `AI_API_KEY=...`
- `AI_MODEL=...` (modelo que sua conta/provedor disponibilizar)

A disponibilidade, cota e preço do modelo dependem do provedor. O backend não cria capacidade de IA por si só e não torna APIs pagas gratuitas.

### Pesquisa web
Para resultados web mais completos, configure uma chave Brave Search. Sem chave, a API usa DuckDuckGo Instant Answer, que pode devolver poucos resultados ou nenhum.

## 4. Instalar extensão Chrome
1. Inicie o backend.
2. No Chrome, abra `chrome://extensions`.
3. Ative Developer mode.
4. Clique em Load unpacked e selecione a pasta `chrome-extension`.
5. Abra a Universal AI no mesmo backend e entre na conta.
6. Clique em **Conectar Chrome** e copie o código de 6 dígitos.
7. Abra a extensão, informe o código e clique Conectar.
8. Em qualquer página pública, clique na extensão e depois em **Salvar página atual na base**.

A extensão não lê histórico, cookies, senhas, outras abas ou dados ocultos. Usa `activeTab` e captura texto visível da aba ativa somente após clique explícito.

Depois de carregar a extensão, copie seu ID em `chrome://extensions` e configure `CHROME_EXTENSION_ORIGIN=chrome-extension://SEU_ID` no `.env`, reiniciando o servidor. Para usar fora do computador local, altere `host_permissions` no `manifest.json` para o domínio HTTPS exato do backend e use esse mesmo endereço no popup. Não use curingas amplos sem necessidade.

## 5. Endpoints principais
- `GET /health`
- `POST /api/chat`
- `GET /api/history`
- `DELETE /api/history`
- `GET /api/knowledge`
- `POST /api/knowledge`
- `DELETE /api/knowledge/:id`
- `GET /api/search?q=...`
- `POST /api/chrome/pair-code`
- `POST /api/chrome/pair`
- `POST /api/chrome/clip`
- `POST /api/chrome/revoke`

As rotas normais exigem Firebase ID token. A rota de captura Chrome exige token exclusivo de extensão.

## 6. Segurança e produção
- Nunca exponha a chave Supabase service role, Firebase service account ou API key do modelo no frontend.
- Configure HTTPS e `APP_ORIGIN` para o domínio publicado.
- Configure Firebase Admin antes de publicar. Sem Firebase Admin, o modo local só é aceito quando `NODE_ENV` não é `production`.
- Restrinja `host_permissions` da extensão ao domínio real.
- Revise cotas, limites e política de retenção do Supabase e do provedor de IA.
- A busca web e documentos importados são conteúdo não confiável. O modelo recebe instrução para não obedecer a comandos embutidos nas páginas.
- Esta versão não rastreia usuários, não coleta IPs dos visitantes e não lê histórico do Chrome.

## Limitações desta entrega
O pacote é a implementação do código e do esquema. Não está conectado automaticamente às contas Supabase/Firebase nem possui suas chaves. É necessário preencher `.env`, executar o SQL e instalar a extensão. Não foi possível testar contra os projetos privados sem as credenciais e sem executar a instalação no seu ambiente.
