# KhetCycle Professional APK-Ready Web App

This package is a complete offline-first KhetCycle frontend suitable for HTML-to-APK wrapping.

## Included
- Professional responsive KhetCycle UI
- Sign in / Create account / Logout
- Demo Mode
- Farmer dashboard
- Buyer marketplace
- Crop residue listing flow
- Camera/gallery image input
- AI-assisted residue analysis simulation with confirmation
- Search and crop filters
- Match scoring
- Listing details
- Purchase request flow
- Farmer accept/reject requests
- Saved listings
- Notifications
- Profile editing
- Local persistence using localStorage
- Firebase-ready configuration file

## Important
The included authentication is a functional local/offline authentication layer so the APK can run without a server.

For real production authentication, connect Firebase Authentication and Firestore. Do not place private service-account credentials in the APK.

## HTML-to-APK
Set `index.html` as the start page. Keep all project files together.

## Firebase
Edit `firebase-config.js` with your Firebase Web App configuration and add the Firebase SDK/auth/firestore integration when moving to production. Demo Mode remains available.

## Build/Run locally
Open `index.html` in a modern browser, or serve the folder through a local static server.

## Brand
KhetCycle
Turning Farm Waste into Farmer Income
