# JB PS4 Theme Creator — Android source project

An Android WebView app with a compact dark console-utility interface inspired by modding utility layouts (original styling; no copied logos/assets).

## Features
- Wallpaper selection through Android's file picker
- Nine custom icon image slots
- Live preview, theme name, author, accent colour
- Export JSON settings/project to Downloads
- Export a theme-source ZIP containing `theme.xml`, wallpaper resized to 1920×1080 PNG when decodable, uploaded icon artwork, and a clear status note
- Android APK build workflow in `.github/workflows/build-apk.yml`

## Build APK
Upload the contents of this folder to the root of a GitHub repository (so `.github`, `app`, `build.gradle`, and `settings.gradle` are at the repository root), then run the `Build Android APK` workflow under Actions. Download the artifact `JBPS4ThemeCreator-debug-apk` and extract `app-debug.apk`. You can also open the project in Android Studio and run `assembleDebug` with Android SDK Platform 35.

## Important packaging limitation
This project **does not generate an installable PS4 `.pkg`**. It exports editable theme source assets only. A genuine PS4 theme package requires the correct theme descriptor and SFO/package metadata plus a compatible PS4 package-building toolchain. The known existing creator workflow depends on external Windows publishing binaries that are not bundled with this project; those binaries are proprietary and cannot simply be embedded in this Android app. This project intentionally labels the source ZIP as not a PKG rather than pretending it is installable.
