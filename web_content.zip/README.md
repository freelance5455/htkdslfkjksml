# CryptoTrader v4.9

Versão com histórico de preços e proteções de queda ajustáveis na Configuração.

## Parâmetros ajustáveis
- Histórico de preços: 1–30 min (padrão 5 min)
- Intervalo de atualização: 5–60 s (padrão 10 s)
- Queda da moeda e janela para bloquear novas compras
- Queda do BTC e janela para bloquear novas compras
- Trailing único: ativação e recuo desde o máximo

A janela de histórico é mantida acima das janelas de proteção escolhidas.
