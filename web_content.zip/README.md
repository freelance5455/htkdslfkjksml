# PC Builder

PC Builder is a static, mobile-first PC planning application built with plain HTML, CSS, and JavaScript. It uses a local editable parts database and `localStorage`; it does not need a backend, account, or paid API.

## Open locally

1. Keep `index.html`, `style.css`, `data.js`, and `app.js` in the same folder.
2. From that folder, run a static server. With Python:

   ```bash
   python3 -m http.server 3000
   ```

3. Open `http://localhost:3000` on a desktop browser or Android phone on the same network. The app also works from the hosted Preview URL.

Opening `index.html` directly usually renders the app too, but a local static server is recommended for consistent browser behavior and later WebView packaging.

## Package as an Android APK later

The simplest path is Capacitor:

```bash
npm init -y
npm install @capacitor/core @capacitor/cli
npx cap init "PC Builder" "com.example.pc_builder" --web-dir .
npx cap add android
npx cap copy android
npx cap open android
```

In Android Studio, select an emulator or connected phone, then use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Before packaging, replace the example app ID with a valid reverse-domain ID such as `com.yourname.pc_builder`, add the supplied logo as the Android app icon, and test portrait mode on a low-end device.

## Editing the database

Edit `data.js`. Each item contains an `id`, display `name`, example `price`, and `specs`. Compatibility rules in `app.js` read those spec fields, so keep the field names consistent when adding new parts.

## Data and limitations

Saved builds, settings, and the current build are stored in the browser's localStorage. Prices are example prices, not live prices. FPS values are estimates based on simple local performance scores and do not replace real benchmarks.
