Custom Fullscreen Timer V10

V10 adds a safety invariant: there is always at least one usable way to open the settings editor. The last visible settings button or the last gesture mapped to "Abrir editor" cannot be removed or disabled; an explanatory message is shown instead. Other settings access routes may still be removed normally.
