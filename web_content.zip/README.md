# SHADOW WARS — Battle Royale prototype (Landscape)

- Android wrapper is forced to landscape orientation.
- Browser version displays a rotate-phone notice when opened in portrait.
- Solo battle royale prototype against 11 AI opponents.
- Intro plane flyover, jump/fall, deployable parachute, desert map, soldier placeholders, four weapon types, reload/ammo, health, enemy AI and synthesized placeholder sound.
- Touch controls for movement/fire/jump and keyboard/mouse controls for desktop.

## Browser
Open `web/index.html` in a modern browser with internet access. Three.js is loaded from jsDelivr CDN.

## Android APK
Open `android/` in Android Studio, sync Gradle, then Build > Build APK(s). Requires Android SDK 35. Internet is required at runtime for the Three.js CDN.

## Scope and honest limitations
This is an early playable prototype, not a finished AAA game. Character models are procedural placeholders, not photorealistic rigged assets. The bots are basic AI. It does not yet include online multiplayer, loot pickup, vehicles, shrinking safe zone, polished animation, or professional recorded audio. The archive size is not a measure of finished-game quality; licensed 3D models, textures, maps and audio will increase it naturally as they are added.
