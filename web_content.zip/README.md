# DaneshGostar

Generated with HTML Viewer & Creator Suite (Advanced WebApp Studio).
- **Package**: com.aksonsa.daneshgostar
- **Version**: 1.0.0 (1)
- **Orientation**: portrait
- **Splash Screen**: Enabled (2000ms)
- **Pull to Refresh**: Enabled
- **Download Manager**: Enabled
- **Camera & WebRTC**: Enabled
- **Geolocation**: Disabled

### How to run:
1. Extract this zip file.
2. Open the folder in Android Studio.
3. Click **Run** or build with `./gradlew assembleRelease`.
