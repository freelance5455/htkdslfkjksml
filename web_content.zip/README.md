# Maktab BSB & CHSB Android

HTML fayl Android WebView ilovasiga joylandi.

Tillar:
- O'zbek
- English
- Русский

Mavjud HTML interfeysining kunduzgi/kechki rejimi ham saqlanadi.

APK yaratish:
1. Android Studio'ni oching.
2. Ushbu papkani Open qiling.
3. Gradle sync tugashini kuting.
4. Build -> Build APK(s) ni tanlang.
5. APK: app/build/outputs/apk/debug/app-debug.apk

Eslatma:
Bu paket hozircha frontend/demo ilova. Haqiqiy OneID, server bazasi, foydalanuvchi autentifikatsiyasi va serverdagi saqlash hali ulanmagan.
