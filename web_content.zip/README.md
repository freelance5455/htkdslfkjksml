# FamilyVault Demo

A self-contained HTML/CSS/JavaScript prototype for a family digital credential wallet.

## Run
Open `index.html` in a modern browser.

## Included
- Mobile/password demo unlock
- Local browser storage
- Family profiles
- Credential records
- Credential verification screen
- Shareable profile links
- Activity history
- Responsive mobile-first UI

## Important
This is a front-end prototype, not a production identity or authentication system.
It does not verify government documents, perform real identity proofing, or provide cryptographic credential issuance.

For production, use a backend, HTTPS, passkeys/WebAuthn, secure session management, encrypted storage, server-issued signed credentials, issuer verification, revocation/status checking, audit logging, rate limiting, consent management, and applicable privacy/identity regulations.
