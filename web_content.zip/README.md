# Watermark Eraser Pro — Android Studio project

Premium Black + Red Android WebView app with:
- Pick an image from device gallery
- Touch/drag brush to mark an area
- Undo and clear mask
- Basic manual cleanup using nearby-pixel blending (best for small marks/simple backgrounds; not professional inpainting)
- PNG export and share
- Optional AI backend integration

## Build APK
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Let Gradle sync complete.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK is usually under `app/build/outputs/apk/debug/app-debug.apk`.

## Important AI limitation
AI Auto Remove requires a compatible backend URL. In the app, enter your server endpoint under **AI backend endpoint**. The endpoint must:
- Accept `POST multipart/form-data` with fields `image` (PNG image) and `mask` (PNG mask; white pixels mark the removal region)
- Return the processed image directly as `image/png` or `image/jpeg`
- Allow requests from the app/WebView (CORS if required)

No paid AI API key or hosted model is bundled. Do not paste secret API keys into a public HTML file or APK. For production, keep secrets on your server and implement image inpainting there.

## Notes
- This project is an Android Studio source project, not a precompiled APK.
- It needs Android Studio/Gradle to compile. On Android-only devices, building may be possible with a compatible cloud build service, but the steps differ.
- Use only on images you own or have permission to edit.
