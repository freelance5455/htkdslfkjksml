# عصر الأبطال | HEROES ERA

نموذج أولي للعبة مغامرات وقتال خيالي، باللغة العربية، يعمل على الويب والهاتف.

## تجربة اللعبة على الويب
افتح `www/index.html` في متصفح حديث. اللعبة لا تحتاج إلى مكتبات خارجية أو اتصال بالإنترنت.

## تجهيز Android APK باستخدام Capacitor
المتطلبات: Node.js حديث وAndroid Studio مع Android SDK.

افتح الطرفية داخل مجلد المشروع ونفذ:
```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```
بعد فتح Android Studio وانتظار اكتمال Gradle Sync:
- للتجربة على جهاز أو محاكي: اضغط Run.
- لإنشاء APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
- لإصدار موقّع: Build > Generate Signed Bundle / APK ثم اتبع الخطوات.

ملحوظة: ملف APK لا يتضمنه هذا الأرشيف؛ يجب بناؤه باستخدام بيئة أندرويد محلية.
يمكن تغيير `appId` في `capacitor.config.json` قبل النشر إلى معرّف حزمة فريد.
