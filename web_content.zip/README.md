# Hisaab for Android

A small Android app that wraps the Hisaab money tracker (`app/src/main/assets/index.html`) in a WebView.
Records are stored on the phone. Backups and CSV exports are saved to the Downloads folder.

This project has not been compiled yet. It was written without an Android SDK available, so the first
build is its first test.

## Get the APK, option 1: Android Studio (on a computer)

1. Install Android Studio.
2. File > Open, then choose this folder. Let Gradle sync finish.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Open the folder it shows (`app/build/outputs/apk/debug/app-debug.apk`) and copy the file to your phone.
5. On the phone, open the file and allow "Install unknown apps" if asked.

## Get the APK, option 2: GitHub (no software to install)

1. Create a free GitHub account and a new empty repository.
2. Upload everything in this folder, including the hidden `.github` folder.
3. Open the repository's Actions tab, choose "Build APK", and press "Run workflow".
4. When it turns green, open the run and download the `Hisaab-apk` file. Unzip it to get `app-debug.apk`.

## Changing the app

Edit `app/src/main/assets/index.html`, then build again. The icon lives in
`app/src/main/res/drawable/ic_launcher_foreground.xml`.

The debug APK is fine for your own phone. To publish on Google Play you need a signed release build.
