# परळे डेअरी फार्म — Android WebView project

## APK build (Android Studio)
1. Extract `ParaleDairyFarmAndroid.zip`.
2. Android Studio → **Open** → select the `ParaleDairyFarmAndroid` folder.
3. Wait for Gradle Sync. If prompted, install Android SDK Platform 35.
4. Build → **Build Bundle(s) / APK(s)** → **Build APK(s)**.
5. The debug APK will be at:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Copy the APK to your Android phone and install it. If prompted, allow installing apps from that source.

## Notes
- Your original Marathi HTML is bundled as `app/src/main/assets/index.html`.
- WebView JavaScript and DOM storage are enabled so the HTML's `localStorage` dairy records work.
- Data is stored locally on that device. Use the app's **बॅकअप डाउनलोड** before changing phones.
- This is a simple offline WebView wrapper. No network permission is requested.
