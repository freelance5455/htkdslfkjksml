<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/97cdf4e6-2fb9-4942-aa30-a49f16f7678f

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## MindSparq subscription preview

The existing project now includes a subscription pricing screen accessible from the sidebar's **Explore Plus & Pro** link. Pricing is centralized in `src/config/subscription-plans.ts`, and the same catalog is exposed by `GET /api/plans`. The screen shows the proposed Free, Plus (₹199/month or ₹1,990/year), and Pro (₹499/month or ₹4,990/year) tiers.

**Important:** this is a pricing and upgrade-flow preview, not live billing. No account authentication, subscription database, or payment provider is configured. The app explicitly tells users that no payment was taken and does not mark a paid plan as active. Before accepting money, connect a supported payment provider, authentication, persistent subscription records, verified webhooks, and server-side feature entitlements. See `docs/MINDSparq-subscription-master-prompt.md` for the implementation brief.


### Private UPI payment-request preview

The existing subscription screen can prepare a one-time UPI intent through `POST /api/billing/upi-intent`. The destination UPI ID and payment-contact email are read only by the Express server from `PAYMENT_UPI_ID` and `PAYMENT_SUPPORT_EMAIL`; they are not hardcoded into the frontend source and are not printed as plain text in the pricing page. The UPI app will show the recipient to the payer before they confirm a transfer, which is required for a UPI payment.

For local setup, create a private `.env` file from `.env.example` and set `PAYMENT_UPI_ID` and `PAYMENT_SUPPORT_EMAIL` to the intended receiving account and payment-contact address. Keep `.env` out of Git and never use `VITE_` prefixes for these settings. For a hosted deployment, add them in the host's private Secrets/Environment settings instead of uploading a file containing them. The submitted account details have intentionally not been copied into source code or the distributable archive.

**This is not live subscription billing.** A UPI intent only opens a payment app; it does not prove that money was transferred. Payments require manual verification, the page does not activate a paid plan, and the direct payment request does not renew automatically. To sell verified recurring subscriptions, configure an eligible payment provider and use its verified server-side webhooks and persistent subscription records. Do not request a buyer's UPI PIN or OTP. Have a parent/guardian help with payment-provider onboarding and business requirements before accepting real payments.
