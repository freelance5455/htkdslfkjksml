# EthioEvents Pro - Event File & Seating Management System

A professional Wedding & Event Management System designed for event organizers in Ethiopia. Operates fully offline using browser IndexedDB storage and optimized for mobile Android usage.

---

## 🌟 Key Features

### 1. File Upload & Download Hub (First Page - `index.html`)
- **File Upload:** Select files (JSON, CSV, PDF, DOCX, TXT) directly from your Android device.
- **Sitting Permission Pass:** Assign sitting permission levels during file upload:
  - `VIP Reserved` (Front Row / Head Table)
  - `Standard Granted` (Regular Table Seating)
  - `Restricted` (Standing Pass / Staff Pass Only)
  - `Pending Approval` (Awaiting Table Allocation)
- **Filtered JSON Download:** Export system backup files filtered by assigned sitting permission status.
- **Local File Records Table:** View, inspect, and re-download saved files offline.

### 2. IndexedDB Persistence Layer
- Local database engine (`js/db.js`) requiring zero internet connection or paid server APIs.
- Stores documents, guest data, and sitting permission passes securely on-device.

### 3. Luxury Black & Gold Design System
- Dark mode by default with light mode toggle support.
- Mobile-responsive navigation sidebar designed for Android touch controls.

---

## 📁 Project Structure

```text
ethioevents_pro/
├── index.html        # Main entry view featuring File Hub & Sitting Permissions
├── README.md         # System documentation & usage guide
├── css/
│   └── styles.css    # Premium black and gold CSS design system
└── js/
    ├── db.js         # IndexedDB storage engine wrapper
    └── app.js        # Main application controller & file manager logic
```

---

## 📱 How to Run & Test on Android

1. Download and extract `ethioevents_pro.zip` using your phone's File Manager or archive app.
2. Open the extracted folder and tap on **`index.html`**.
3. Choose **Open with Chrome** (or any mobile browser).
4. Select a **Sitting Permission** option, tap **Choose & Upload File**, or click **Download Export** to export JSON system data.
