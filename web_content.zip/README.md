# Kaved Browser

Navegador Android leve: casca em Java + WebView do sistema + página inicial em HTML (assets/i.html, 506 bytes).
Sem bibliotecas, sem telemetria, sem contas. minSdk 26 (Android 8.0), targetSdk 35.

## Como gerar o APK (sem Android Studio)
1. Crie um repositório no GitHub e envie todo o conteúdo desta pasta (inclusive a pasta .github).
2. Abra a aba Actions, rode "build" (ou faça um push).
3. Ao terminar, baixe o artefato "Kaved-APK" e instale o .apk (permita "instalar apps desconhecidos").

## Como gerar com Android Studio ou Gradle
Abra a pasta no Android Studio e use Build > Build APK, ou rode `gradle assembleRelease` (Gradle 8.9, JDK 17).
O APK sai em build/outputs/apk/release/ assinado com a chave de debug.

## O que tem
- Barra de endereço com pesquisa (DuckDuckGo), https por padrão, atalhos @w (Wikipédia) e @yt (YouTube)
- Remove utm_*, fbclid, gclid e parecidos dos links
- Bloqueia ~40 domínios de rastreio e anúncio em todos os sites (contador no menu)
- Cookies de terceiros desligados; localização, câmera e microfone negados
- Downloads, envio de arquivos, vídeo em tela cheia, versão para computador, compartilhar, limpar dados
- Pode ser definido como navegador padrão (abre links http/https)

## Observações
- O Safe Browsing do WebView continua ativo (segurança); ele pode consultar o Google quando o aparelho tem Play Services.
- Cookies de terceiros desligados podem quebrar login em alguns sites.
