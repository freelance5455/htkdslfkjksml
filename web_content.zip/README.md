# StudyQ — Android APK conversion package

This folder contains the complete StudyQ web app, ready to upload to an HTML-to-APK converter.

## File to upload

**Upload `StudyQ_APK_Converter.zip`** to your chosen HTML-to-APK converter.

The ZIP is structured with `index.html` at its root, which is the required start page for most HTML-to-APK/WebView converters.

## Package contents

- `index.html` — app entry page (at ZIP root)
- `styles.css` — existing app styles
- `app.js` — existing app logic and interactions
- `assets/studyq-logo.png` — StudyQ logo asset

## Beginner instructions

1. Download `StudyQ_APK_Converter.zip`.
2. Open your chosen HTML-to-APK converter.
3. Select its **Upload ZIP / Website ZIP** option and upload `StudyQ_APK_Converter.zip`.
4. If it asks for a start page or entry file, enter/select `index.html`.
5. Set the app name to **StudyQ**.
6. Build/export the APK, then follow the converter's install/signing instructions.

## Dependencies and internet

- The app's CSS and JavaScript are included locally; no npm, Node.js, build step, or package installation is required.
- The Poppins font is loaded from Google Fonts in `index.html`. An internet connection is needed for that font; the page has a system sans-serif fallback if it cannot load.
- The countdown and study tracker run locally in the browser/WebView.
- Progress is stored in the WebView/browser's local storage on that device. It does not automatically sync between devices. Use the app's Export feature to make backups.
- No backend, API key, or server is required for the included features.

## Notes

- The requested personal countdown target remains **1 January 2027**.
- The package preserves the supplied StudyQ project UI and features; it only moves the existing CSS, JavaScript, and embedded logo into separate files and sets `index.html` as the root entry page.
- HTML-to-APK converters differ. If a converter only accepts a website URL rather than a ZIP upload, use a converter that supports uploading a local HTML/ZIP project.
