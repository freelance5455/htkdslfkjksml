# RBoyyz Music Website

A responsive, neumorphic music landing page inspired by the supplied reference image.

## Links
- Home: https://rboyyz.ismyradio.com/
- Player: https://rboyyz.ismyradio.com/player

## Files
- `index.html` — page structure
- `style.css` — professional responsive design
- `script.js` — progress animation, share, favourites and buttons

## GitHub Pages
Upload all three files to the same repository folder, then enable GitHub Pages from:
Settings → Pages → Deploy from branch.
