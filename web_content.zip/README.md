# Stock dan Produksi by Akhtara.ID — v4 (APK standalone)

100% offline, tanpa browser/hosting. Aplikasi web ada di `app/src/main/assets/index.html`.

## Cara build (pilih satu)

**A. Android Studio** — File > Open > pilih folder ini, tunggu sync, lalu
Build > Build APK(s). Hasil: `app/build/outputs/apk/release/app-release.apk`.

**B. GitHub (tanpa install apa pun)** — upload isi folder ini ke repo baru,
buka tab Actions > "Build APK" > Run workflow. Unduh APK dari bagian Artifacts.

Instal APK di HP (izinkan "install dari sumber tidak dikenal").

## Penyimpanan data
Setiap perubahan langsung ditulis ke file internal aplikasi, localStorage, dan IndexedDB.
Force close aman. Data lama (kunci `stokprod6p`) otomatis terbaca bila diimpor lewat Atur > Pulihkan.
