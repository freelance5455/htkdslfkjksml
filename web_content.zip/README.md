# Text Design Studio Pro — Complete Android Studio Project

This is a complete Android Studio project, not just the web source ZIP. It includes:
- Native Android `MainActivity.java` with WebView host.
- HTML/CSS/JavaScript Facebook post designer.
- HTML/CSS/JavaScript code editor and sandboxed live preview.
- Native PNG save bridge that writes exported PNG files to Android MediaStore at `Pictures/Text Design Studio`.
- Android manifest, theme, Gradle project files and build instructions.

## Build the APK
Requirements: Android Studio with Android SDK Platform 35 installed, and a compatible JDK (Android Studio's bundled JDK is recommended).

1. Extract this ZIP.
2. Open the extracted `Text_Design_Studio_Android_Complete` folder in Android Studio (**Open**, not Import).
3. Let Gradle sync. If prompted, install Android SDK Platform 35 and Build Tools.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`. Install it on your Android phone.

## Save location
Tap **Save PNG** in the app. The native Android bridge saves images to `Pictures/Text Design Studio`, which should appear in Gallery/Photos after media indexing. Android 10+ uses MediaStore without requesting broad storage permission.

## Important security note
The JavaScript bridge is exposed to the main local app page only. The user-editable HTML preview uses a sandboxed iframe. Do not add remote content or untrusted navigable pages to this WebView while keeping the bridge enabled.

## Build notes
This project uses Android Gradle Plugin 8.7.3 and compileSdk 35. If Android Studio offers a Gradle/SDK upgrade prompt, the current settings should work with a recent Android Studio installation. The ZIP contains project source; the APK must be built in Android Studio because the build SDK/toolchain is not included.
