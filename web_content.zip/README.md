# ROCKY RUMBLE — High Quality Playable Demo

This is a self-contained mobile/browser fighting-game demo.

## Run
Open `index.html` in a modern browser. For best Android results, serve the folder from a local web server (for example Python's `http.server`) because some browsers restrict local file asset loading.

## Included
- Rockycat character from the supplied reference image
- Character selection screen
- Six arena/map selection screen
- Playable fight
- 8-way D-pad
- Up = jump; down = crouch
- Punch, kick, block, special, grab
- High / mid / low attack levels
- Matching high / mid / low guard
- Hit stun, block stun, knockback, meter, combos and KO
- Touch controls and keyboard controls
- Procedural sound effects (no external audio dependencies)

## Controls
Mobile: use the on-screen D-pad and five buttons.
Keyboard: W/A/S/D = movement; J = punch; K = kick; L = block; I = special; O = grab.

## Note
The supplied Rockycat image is used as the hero visual. The gameplay cutout is automatically processed from that image. A production Unity build should replace it with a rigged/animated model or authored sprite atlas for frame-perfect animation.
