# Flappy Bird 2026 - app package

The game is one web page (`www/index.html`) made into an installable app. It works as:
a website, an installable "web app" (PWA), an Android APK/AAB, and an iOS app.

```
www/                  <- the game (this folder is what you publish)
  index.html          game
  manifest.webmanifest  app name, colours, icons
  sw.js               makes the game work offline after the first visit
  icons/              app icons (192, 512, maskable, iOS)
store-assets/         512 px store icon + 1024x500 Play Store feature graphic
package.json, capacitor.config.json   Android / iOS wrapper (Capacitor)
```

## Before you publish (important)
1. **Rename the game.** "Flappy Bird" is a registered trademark of its creator and Google Play / Apple
   often reject apps using it. Pick your own unique name and change it in:
   `www/index.html` (the <title> and the "FLAPPY BIRD / 2026" text), `www/manifest.webmanifest`,
   `capacitor.config.json` (appName).
2. **Change the app id** in `capacitor.config.json` -> `appId` to something unique, e.g. `com.yourname.coinflap`.
3. **Make the world map work offline (recommended).** Download
   https://cdn.jsdelivr.net/npm/world-atlas@2.0.2/countries-110m.json and save it as
   `www/countries-110m.json`. Without it the game downloads the map on first launch (needs internet once).
4. **Privacy policy.** The game saves progress only on the player's device. It does make two kinds of
   internet requests: the Lilita One font (Google Fonts) and the world map (jsDelivr). Mention this in a
   simple privacy policy (free generators exist). Stores require a link to one.

## Option A - website + "Install app" (free, easiest, Android and iPhone)
1. Upload the contents of `www/` to any static host: Netlify (drag & drop the folder), GitHub Pages,
   Cloudflare Pages, Vercel or your own site. It must be served over **https**.
2. Share the link. Android Chrome: menu -> *Install app*. iPhone Safari: Share -> *Add to Home Screen*.
3. After the first visit the game also opens offline.

## Option B - Android APK / AAB without Android Studio (free)
1. Do Option A first so the game has a public https link.
2. Go to https://www.pwabuilder.com , paste your link, press *Package for stores* -> *Android*.
3. Download the package. It contains an `.apk` (install directly on phones / share the file) and an
   `.aab` (upload this to Google Play) plus your signing key. **Keep the signing key safe** - you need
   the same key for every update.

## Option C - Android app with Android Studio (full control, works offline inside the app)
Needs Node.js 18+ and Android Studio.
```
npm install
npx cap add android
npx cap sync
npx cap open android
```
In Android Studio: *Build -> Generate Signed Bundle / APK*. Choose **Android App Bundle (.aab)** for
Google Play or **APK** to share the file. Set the launcher icon with
*File -> New -> Image Asset* using `www/icons/icon-maskable-512.png`.
The Android back button is already handled by the game (it pauses, goes back through menus, and exits from the home screen).
iPhone version: `npx cap add ios` then `npx cap open ios` (needs a Mac with Xcode and an Apple developer account).
If npm complains about Capacitor versions, replace `^6.0.0` with the newest version number.

## Option D - other platforms
* **itch.io / Newgrounds / Game Jolt:** zip the *contents* of `www/` (index.html at the top level) and
  upload as an HTML5 game.
* **Amazon Appstore / Samsung Galaxy Store:** upload the APK from Option B or C.

## Store checklist (Google Play)
* Developer account (one-time fee), app name, short + full description, privacy policy link.
* Icon 512x512 and feature graphic 1024x500: ready in `store-assets/`.
* 2-8 phone screenshots (take them from the running game), content rating questionnaire,
  target audience (the game has no ads, no accounts and no purchases with real money).
* Test with a few friends before releasing.

## Local test
`npx serve www` (or any static server), then open the address on your computer or phone.
Opening `www/index.html` directly also plays the game (offline features need a server).
