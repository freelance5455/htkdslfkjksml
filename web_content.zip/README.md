# TrafficPulse - Automated Web Traffic & Analytics Testing Suite

TrafficPulse is a specialized automated web testing client designed for website owners, backend developers, and DevOps engineers to test and verify how servers handle unique traffic.

---

## 📦 What's in this Download?

This ZIP bundle includes two ready-to-use editions:

1. **Standalone Web Client (`index.html`)**:
   - Double-click `index.html` in any browser to open the browser-based TrafficPulse simulator immediately.
   - Run tests, type custom visit amounts (e.g., 35, 100), adjust pacing, inspect simulated profiles, and export audit reports without installing anything.

2. **Full Native Android Project (`/app`)**:
   - Modern Android application built with Kotlin, Jetpack Compose, Material 3, and OkHttp.
   - Dual-engine architecture:
     - **High-Speed HTTP Socket Engine**: Direct network calls with isolated cookie jars for load testing and server access logs.
     - **Full Browser Engine (Headless WebKit WebView)**: Real DOM rendering with JavaScript execution to fire client-side tags (Google Analytics 4, Plausible, Facebook Pixel).

---

## 🚀 How to Run the Android App

### Option A: Android Studio
1. Open Android Studio.
2. Select **Open an Existing Project** and choose the extracted root folder.
3. Allow Gradle to sync dependencies.
4. Click **Run (Shift + F10)** on an emulator or physical device.

### Option B: Build APK via Terminal
```bash
# Build the Debug APK
./gradlew assembleDebug

# Output APK location:
# app/build/outputs/apk/debug/app-debug.apk
```

### Option C: Run Local JVM & Robolectric Tests
```bash
./gradlew testDebugUnitTest
```

---

## 🔍 How to Verify Real Visits on Your Web Server

1. **Inspect Server Access Logs**:
   Open a terminal on your web server:
   ```bash
   # NGINX:
   tail -f /var/log/nginx/access.log

   # Apache:
   tail -f /var/log/apache2/access.log
   ```
   Run a 35-visit simulation in TrafficPulse. You will see 35 distinct HTTP requests arriving with varied User-Agents (Chrome, Safari, Firefox, Edge, iPhone, Android), IP forward headers (`X-Forwarded-For`), and diverse referrers.

2. **Verify with `httpbin.org/get`**:
   Set the Target URL to `https://httpbin.org/get` and tap **"Verify Real Connection (Test 1 Ping)"**. `httpbin` echoes back the exact request headers, User-Agent, and IP address received by the remote server.

---

## 🛡️ Session Isolation & Fingerprinting Features

- **Isolated Cookie Jars**: Zero cookie leakage between visits. Every request arrives as a brand-new unique visitor, prompting servers to create new sessions.
- **Multi-Device User-Agent Entropy**: Desktop Windows (Chrome/Edge), macOS Sonoma (Safari/Chrome), Linux (Firefox), Android 14 (Pixel 8 / Galaxy S24), iOS 17 (iPhone 15 Pro, iPad).
- **Client Hints**: Dispatches matching `Sec-CH-UA`, `Sec-CH-UA-Mobile`, and `Sec-CH-UA-Platform`.
- **IP Forwarding**: Dispatches geo-distributed public IPs to `X-Forwarded-For`, `Client-IP`, `X-Real-IP`, and `CF-Connecting-IP`.
- **Referrer Simulation**: Google Search, Reddit, Twitter/X, LinkedIn, DuckDuckGo, and Direct navigation.
