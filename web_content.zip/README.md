# Web Hosting GSK Web (dibuat oleh Reza)

1. Pasang Node.js 18+.
2. Simpan gambar QR GoPay sebagai public/qr-gopay.png.
3. Jalankan: ADMIN_KEY=kunci-rahasia-kamu node server.js

HTTPS: CERT_FILE=/path/fullchain.pem KEY_FILE=/path/privkey.pem PORT=443 node server.js
Atau di belakang Caddy/Nginx, lalu jalankan dengan TRUST_PROXY=1.

Konfirmasi pembayaran (admin):
- GET /api/admin/orders (header x-admin-key)
- POST /api/admin/approve dengan body {"id":"ID_PESANAN"} (header x-admin-key)

Akun dan pesanan disimpan di data.json.
