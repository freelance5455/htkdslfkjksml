# TATAMI LEGENDS — Android APK project

This project wraps the existing single-file HTML game in an Android WebView. JavaScript and DOM storage are enabled so the game can run and save locally.

## Build an APK without installing Android Studio on your phone

1. Sign in to GitHub and create a new **private** repository.
2. Upload all files and folders from this project ZIP to the repository root.
3. Open the repository's **Actions** tab.
4. Choose **Build TATAMI LEGENDS APK** and press **Run workflow** (or push to `main`).
5. Open the finished workflow run, scroll to **Artifacts**, and download `TATAMI-LEGENDS-APK`.
6. Unzip the artifact. The file `app-debug.apk` is the installable test APK.
7. Send the APK to Telegram. Tell users Android may ask them to allow installing apps from that source.

## Important
- This is a **debug APK** suitable for testing/sharing directly. It is not a Play Store release and is not signed with a private release key.
- The game's current local save is stored by Android WebView on the device. It is separate from the browser's save.
- App id: `com.tatamilegends.game`; version: `1.0`.
- Before public release, add a proper app icon, privacy/contact information, and a release signing key.
