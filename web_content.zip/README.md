# Text Design Studio — HTML/CSS/JavaScript

A responsive, local-first editor for creating Facebook post graphics. Includes multiple text layers, font choices, bold/italic, colour, outline, shadow, alignment, line spacing, positioning, gradient backgrounds, canvas presets, undo, delete, and PNG export.

## Run it in a browser
1. Extract this ZIP.
2. Open `www/index.html` in Chrome or another modern browser.
3. Edit your text and tap **Download high-quality PNG**.
4. On Android, if the browser blocks local-file downloads, open the folder using a local web server or package it as an Android app below.

## Build an Android APK with Capacitor
You need a computer with Node.js LTS, npm, and Android Studio installed. An APK cannot be compiled from HTML alone; Capacitor wraps the web app in an Android project.

1. Install Node.js LTS and Android Studio.
2. Create a working folder and copy the included `www` folder into it.
3. In a terminal, run:

   ```bash
   mkdir TextDesignStudioAndroid
   cd TextDesignStudioAndroid
   npm init -y
   npm install @capacitor/core @capacitor/cli @capacitor/android
   npx cap init "Text Design Studio" "com.textdesignstudio.app" --web-dir=www
   ```

4. Copy the provided `www` folder into `TextDesignStudioAndroid/www`.
5. Add Android platform and open it:

   ```bash
   npx cap add android
   npx cap sync android
   npx cap open android
   ```

6. In Android Studio, let Gradle sync. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. Android Studio will show the output location, usually `android/app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- PNG export uses the browser Canvas API and runs locally; it does not upload your design.
- Use HTTPS or a local server when testing browser downloads if your browser restricts `file://` downloads.
- The current app is a complete front-end editor, not a cloud project or signed Play Store release. A Play Store release needs a release keystore and app signing.
- If you plan to distribute widely, test export and touch-drag behavior on your target Android versions.
