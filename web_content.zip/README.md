# Vice City server

Run locally:  `node server.js`  then open http://localhost:3000 (the server also serves the game).

Deploy (Render / any Node host): start command `node server.js`.
IMPORTANT: set env `DATA_DIR` to a persistent disk path, or accounts are lost on restart.

If the game HTML is hosted elsewhere (Vercel), set `LOGIN_CFG.apiBase` in the HTML to this server's URL.
