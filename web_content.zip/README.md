# Roxy - Sassy AI Voice Assistant & Voice Controller

A real-time, voice-to-voice AI assistant web application with full voice-control capabilities powered by **Gemini Live API** (`@google/genai`).

## Features
- **100% Real-Time Voice-to-Voice**: Streams mic audio (16kHz PCM) and plays synthesized voice (24kHz PCM) with gapless Web Audio scheduling and instantaneous interruption handling.
- **Full Voice Command Control (Function Calling)**:
  - 🌐 **Open Any Website/App**: "Open YouTube", "WhatsApp kholo", "Check GitHub", "Open Instagram"
  - 🔍 **Web Search**: "Google pe search karo React 19", "Search Wikipedia for black holes"
  - ⏱️ **Timer & Alarm**: "5 minute ka timer lagao", "Set a 30 second timer"
  - 📝 **Notes & Reminders**: "Take a note: Buy groceries", "Yeh yaad rakhna"
  - 🎵 **Music & Lo-Fi Vibes**: "Play chill music", "Party vibe shuru karo", "Stop music"
  - 💾 **Download Project Zip**: "Download zip file", "Project ka zip de do"
  - 📱 **Device Controls**: Copy to clipboard, toggle fullscreen, mute/unmute
  - 🎨 **Mood Themes**: "Change theme to Midnight Emerald", "Vibe badlo"
  - 😏 **Facial Expressions**: Roxy reacts with animated smirks, winks, laughs, and sassy vibes.
- **Multilingual & Hinglish**: Understands English, Hindi, and Hinglish voice commands seamlessly.

## Getting Started Locally

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Set your Gemini API Key**:
   Create a `.env` file (or copy from `.env.example`):
   ```bash
   GEMINI_API_KEY="your-gemini-api-key"
   ```

3. **Start the development server**:
   ```bash
   npm run dev
   ```
   Open `http://localhost:3000` in your browser.

4. **Build for production**:
   ```bash
   npm run build
   npm start
   ```
