# El Caso Blackwood — App móvil

Esta carpeta contiene una versión móvil instalable como PWA.

## Cómo instalarla
1. Sirve esta carpeta desde un servidor HTTPS (por ejemplo GitHub Pages, Netlify o Vercel).
2. Abre la dirección en Chrome en Android.
3. Menú ⋮ → "Añadir a pantalla de inicio" / "Instalar aplicación".

La app funciona como juego independiente y guarda el estado de la partida mientras la página permanezca abierta.

## Contenido
- Escena investigable
- 8 pistas
- Interrogatorio de 4 sospechosos
- Cuaderno de detective
- Sistema de acusación
- Final correcto/incorrecto
- Diseño responsive y orientación horizontal
