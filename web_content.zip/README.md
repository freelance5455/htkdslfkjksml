# Pajarito Pro AI — Android / Google Play

Este proyecto está preparado como una app Android nativa que contiene la interfaz de Pajarito Pro AI.

## Antes de publicar
1. En `app/src/main/assets/index.html`, cambia `https://TU-SITIO.netlify.app` por la dirección HTTPS real de tu backend.
2. El backend debe guardar la clave de IA en el servidor; nunca la pongas en este HTML ni en el AAB.
3. Genera un Android App Bundle (.aab) en modo Release y firma el bundle con tu clave de firma.
4. Sube el AAB a Google Play Console.

## Requisitos actuales
El proyecto usa compileSdk/targetSdk 36 (Android 16), que cumple el requisito de nuevas apps de Google Play vigente desde el 31 de agosto de 2026.

## Importante
Este proyecto NO incluye una API key. Sin un backend de IA configurado, el chat no podrá producir respuestas reales.
