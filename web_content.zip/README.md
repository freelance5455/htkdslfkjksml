# OmniVoice • AI Long-Form Text-to-Speech Studio

## Package Contents

1. **`OmniVoice-TTS.apk`**: Direct Android APK package.
   - Built with Jetpack Compose & Android native speech synthesizer (`android.speech.tts.TextToSpeech`).
   - Supports 100% free, unlimited long-form synthesis (YouTube scripts, audiobooks, educational narrations).
   - Generates and exports studio-grade uncompressed 16-bit PCM RIFF WAV audio files directly to device storage (`Music/OmniVoice`).
   - Automatic natural sentence & paragraph chunking without cutting words.
   - Project library with SQLite Room persistence.

2. **`index.html` / `OmniVoice-HTML5-Studio.zip`**: Standalone HTML5 Web App.
   - Run directly in any web browser (Chrome, Edge, Safari, Firefox, Android Chrome, iPhone Safari).
   - No server or Node.js installation needed: just double-click `index.html`.
   - Dynamic voice synthesis, natural chunking, speed/pitch/pause controls, sample presets, and local project storage.
