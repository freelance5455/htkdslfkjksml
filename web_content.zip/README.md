# SNHS Warriors — Android APK project

Offline-first Android fallback if SoftSpring keeps showing `net::ERR_HTTP_RESPONSE_CODE_FAILURE`: this packages the complete HTML Canvas game inside a standalone Android app project. It loads the bundled file at `file:///android_asset/index.html`, does **not** load the broken `appassets.androidplatform.net/web/index.html` converter URL, and declares no Android INTERNET permission.

## What is fixed

- Your latest HTML game is bundled at `app/src/main/assets/index.html`.
- Android loads the bundled page directly using `file:///android_asset/index.html`.
- The game opens in landscape and immersive full-screen mode.
- The game HTML is self-contained: no external scripts, fonts, images, or network requests are required at runtime.
- The app manifest declares **no INTERNET permission**, so the installed game cannot access the network through Android networking APIs.
- The KP launcher icon is included.
- A workflow builds a directly installable APK using GitHub Actions.

## Build the installable APK for free

I packaged and checked the offline source/project, but could not compile the APK in this environment because the Android SDK and Gradle are not installed. The included GitHub Actions workflow compiles it for you; the build process needs internet access, but the installed game itself does not.

1. On GitHub, create a **Private** repository named `snhs-warriors-android`. Keep it private so your source code is not publicly exposed.
2. Install GitHub Desktop from https://desktop.github.com/ and sign in.
3. In GitHub Desktop, choose **File → Clone Repository**, select your new private repository, and clone it to your PC.
4. Open the cloned repository folder in Windows File Explorer. Copy **all contents** of this project folder into it, including the `.github` folder. Do not copy the outer ZIP file itself and do not put the project inside a second nested folder.
5. In GitHub Desktop, enter a summary such as `Add SNHS Warriors Android app`, click **Commit to main**, then click **Push origin**.
6. On GitHub.com, open your repository and select **Actions**. The `Build SNHS Warriors APK` workflow should start automatically after the push. Open the latest run and wait until it finishes successfully.
7. At the bottom of that successful run, under **Artifacts**, download `SNHS-Warriors-Installable-APK`.
8. Extract that downloaded ZIP. It contains `app-debug.apk`. Send that APK to your Android phone, open it, allow installation from that source if prompted, then install and launch **SNHS Warriors**.

If the workflow does not start automatically, open **Actions → Build SNHS Warriors APK → Run workflow → Run workflow**.

The resulting APK is debug-signed and suitable for direct installation/testing. It is not prepared for publishing to Google Play. Keep the GitHub repository Private if you do not want the source publicly visible. GitHub Actions availability depends on your account's current usage limits.

## Technical details

- Game file: `app/src/main/assets/index.html`
- Android entry point: `app/src/main/java/com/kpchangames/snhswarriors/MainActivity.java`
- Startup URL: `file:///android_asset/index.html`
- Workflow APK output: `app/build/outputs/apk/debug/app-debug.apk`
