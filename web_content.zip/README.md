# Elisei VPN — Android VpnService

Это Android-проект с HTML-интерфейсом и нативной `VpnService`.

Что делает текущая версия:
- создаёт локальный TUN VPN-интерфейс;
- направляет DNS endpoint `10.7.0.1` в TUN;
- читает IPv4/UDP DNS-пакеты;
- блокирует домены из встроенного списка рекламных/трекерных доменов;
- остальные DNS-запросы пересылает на `1.1.1.1:53`;
- защищает upstream UDP socket от попадания обратно в VPN через `VpnService.protect()`;
- HTML управляет сервисом через JavaScript bridge.

Ограничение этой версии: это именно DNS-фильтр, а не универсальный VPN-туннель. Она не проксирует весь TCP/UDP трафик через сервер. Приложения, использующие Android Private DNS/DoT/DoH напрямую, могут обходить такой DNS-фильтр.

Для сборки нужен Android Studio и Android SDK.

## Fix applied (2026-09-26)
- Added Android foreground-service permissions required by targetSdk 35.
- Added the `specialUse` foreground-service subtype declaration.
- Changed VPN startup to `startForegroundService()` on Android 8+.
- Added handling for cancelled VPN permission requests.
- Added error reporting when the foreground VPN service cannot be started.
