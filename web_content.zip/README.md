# THE BLACK DOOR — Dreamcore Mobile Prototype

Protótipo mobile inspirado na imagem fornecida.

## Como jogar
Abra `index.html` em um navegador de celular. O protótipo usa controles por toque:
- 🎒 Mochila no canto superior esquerdo
- 🔦 Lanterna
- ✋ Interagir/pegar
- CORRER
- Analógico virtual no canto inferior esquerdo
- 3 slots rápidos de item
- Inventário com 10 espaços
- Equipamentos, Status e Configurações
- Volume, gráficos, sensibilidade e idioma
- Atmosfera com vinheta, névoa e granulação

## Observação
Este pacote é um protótipo web jogável. Ele não é um APK nativo; o ambiente atual não possui a cadeia Android/Godot necessária para compilar um APK aqui.
