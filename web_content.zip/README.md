# RAHIM CALC

Calculatrice moderne hors ligne.

## Utilisation
Ouvrir `index.html` dans un navigateur moderne. Pour une installation comme application, servir le dossier sur HTTPS et utiliser un navigateur compatible PWA.

Fonctions : calculs de base, pourcentage, historique, mode scientifique, clavier et fonctionnement hors ligne.
