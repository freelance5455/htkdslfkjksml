# OBD2 FixMaster v3

## New in v3
- Vehicle + engine + DTC + symptom driven diagnostic plans
- Guided PASS/FAIL diagnostic tree
- Vehicle-specific video queries for each diagnostic step
- Pending-code scan (Mode 07)
- Freeze-frame request hook (Mode 02)
- Stored-code scan (Mode 03)
- Clear codes (Mode 04)
- Live PID hook
- First detailed vehicle workflow: 2015 Hyundai Elantra 1.8L
  - P0340
  - P0017
  - P0014
- Generic fallback workflow for other vehicles/codes

## Design principle
A DTC is treated as a monitored fault, not automatic proof that a named part has failed. The app prioritizes inspection, power/ground checks, signal checks, correlation and manufacturer procedures before recommending parts.

## Important
Generic OBD-II standards cover emissions-related diagnostic information. Manufacturer-specific modules, bidirectional controls, ABS/SRS/body systems and proprietary data can require additional protocols/adapters. Exact test values should come from appropriate service information.

## Build
Open in Android Studio and build the `app` module. Pair a Bluetooth Classic ELM327-compatible adapter with Android first. Android 12+ requires runtime Bluetooth permissions for scanning/connecting to nearby devices.
