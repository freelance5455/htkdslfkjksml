# Roll Maze 3D — Android app / تطبيق أندرويد

A complete Android project (Kotlin + WebView) that packages the game as an installable APK.
مشروع أندرويد كامل يحوّل اللعبة إلى تطبيق قابل للتثبيت.

## الطريقة الأسهل: بناء APK بدون برامج (GitHub) / Easiest: build online, no software
1. أنشئ حساباً مجانياً في github.com ثم مستودعاً جديداً (New repository) — Create a free account and a new repository.
2. ارفع **محتويات** هذا المجلد كما هي (Add file → Upload files)، بما فيها مجلد `.github` — Upload the **contents** of this folder, including the hidden `.github` folder.
3. افتح تبويب **Actions** ← **Build APK** ← **Run workflow** — Open Actions → Build APK → Run workflow.
4. بعد دقائق افتح التشغيلة المكتملة وحمّل **RollMaze3D-apk** (ملف مضغوط فيه `app-debug.apk`) — Download the artifact when it finishes.
5. انقله إلى الهاتف وثبّته (اسمح بـ "التثبيت من مصادر غير معروفة" إن طُلب) — Copy to your phone and install (allow "install unknown apps" if asked).

## Android Studio
Open this folder in Android Studio → wait for Gradle sync → **Build ▸ Build APK(s)**. The APK is in `app/build/outputs/apk/debug/`.

## Notes / ملاحظات
- The build downloads Three.js (r128) once and bundles it, so the game then works offline. If the download is blocked, the app loads it from the internet instead.
- Forces landscape, keeps the screen on, hides system bars, pauses when you leave the app, handles the Back button (pause → resume, menus → main menu, main menu → exit).
- "Add my song" opens the phone's file picker. Added songs last until the app is closed.
- This is a *debug-signed* APK, fine for installing on your own phone. For Google Play you need a release keystore and `bundleRelease`.
- Min Android 8.0 (API 26).
