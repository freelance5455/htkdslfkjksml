# Öffi HTML / PWA

## Schnell testen
Öffne `index.html` in einem modernen Browser. Lokales Speichern funktioniert; Live-Abfragen hängen von Netzwerk, CORS und der Abdeckung der öffentlichen transport.rest-Schnittstelle ab.

## Als installierbare PWA verwenden
Für Service Worker und zuverlässige PWA-Installation müssen die Dateien über HTTPS bereitgestellt werden (z. B. GitHub Pages). Danach die URL in Chrome auf Android öffnen → Menü ⋮ → „Zum Startbildschirm hinzufügen“ oder „App installieren“.

## Live-Daten und Grenzen
Die App verwendet `https://v6.db.transport.rest`:
- `GET /locations?query=...` zur Haltestellensuche
- `GET /stops/{id}/departures?...` für Abfahrten

Das ist ein öffentlicher Drittanbieter-Dienst, keine offizielle ÖBB-/IVB-API. Österreichische Haltestellen oder Echtzeitinformationen sind nicht garantiert. Bei CORS-Fehlern oder fehlender Abdeckung ist ein offizieller/geeigneter Datenanbieter nötig.

## Widget
Diese HTML-Version ist eine PWA, kein natives Android-Homescreen-Widget. Eine PWA kann eine Homescreen-Verknüpfung und App-Ansicht bieten, aber nicht selbstständig ein echtes Android-App-Widget mit unabhängigem Hintergrundrefresh erstellen.
