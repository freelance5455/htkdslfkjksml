# Virtual USB Drive — versão HTML

Este pacote inclui um `index.html` funcional para navegador/WebView: seleção de arquivos, lista da sessão, tamanho total, salvar cópia/baixar e exportar a lista em JSON.

## Para colocar no APK
Copie `index.html` para `app/src/main/assets/index.html` de um projeto Android com WebView e carregue `file:///android_asset/index.html`. O APK precisa de uma Activity com WebView habilitada para JavaScript e DOM storage, se necessário. O HTML também pode ser aberto diretamente em um navegador Android.

## Limitações honestas
- O navegador não converte o celular em USB Mass Storage nem em pendrive inicializável.
- A lista de arquivos é temporária na sessão e não persiste os bytes dos arquivos.
- “Salvar cópia” baixa/copia o arquivo selecionado através do navegador.
- O app não cria nem valida um instalador macOS.
