# Alight Motion Premium

Web app neo-brutalism, alur 3 langkah: **Email → Verifikasi (link + Order ID) → Hasil**.
Zero dependency — tidak perlu `npm install`. Butuh Node.js 18+.

## Endpoint yang dipakai (via proxy server sendiri)
- `GET /api/send?email=`  →  `https://api.zyvor.my.id/api/am/send`
- `GET /api/verify?email=&link=&orderid=`  →  `https://api.zyvor.my.id/api/am/verifv2`

## Jalankan
```
node server.js
```
Buka http://localhost:3000. Port dari env `PORT` (atau `SERVER_PORT` di Pterodactyl).
Ganti base API lewat env `API_BASE` bila perlu.

## Deploy
- **Pterodactyl / VPS**: upload & extract zip, startup file `index.js` atau `server.js`, port sesuai allocation.
- **Railway / Render / Koyeb**: start command `node server.js`.
- **PM2**: `pm2 start server.js --name alight-premium`
