# CryptoTrader Mobile v4.4 — Phone Only

🧪 **PAPER TRADING — SIMULAÇÃO**. Esta versão não envia ordens reais.

- Funciona diretamente no Android, sem PC e sem VPS pago.
- Analisa 12 criptomoedas.
- Atualiza a janela histórica de até 500 velas de 1h a cada ciclo.
- Recalcula RSI, EMA20/EMA50, volume, máximos/mínimos e score.
- Guarda uma cópia do histórico localmente.
- Se os dados estiverem desatualizados/indisponíveis, o ativo não compra nem vende.
- Trailing profit com ativação, pico, confirmação da reversão e vendas parciais.
- Uma venda parcial só avança se tiver lucro líquido positivo após taxa e slippage.
- Nunca executa uma venda que resulte em prejuízo.
- Ao voltar ao primeiro plano, tenta atualizar imediatamente.
- Migra automaticamente o estado da v3 quando encontrado.

**Limitação:** Android pode suspender a app em segundo plano. A v4.4 melhora a recuperação, mas não garante execução 24/7 com a app fechada/suspensa.

Não contém chaves privadas e não envia ordens reais para a Binance.
