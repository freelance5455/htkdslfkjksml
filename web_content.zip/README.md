# AI സിലബസ്

മൊബൈൽ-ഫ്രണ്ട്‌ലി, offline-first സിലബസ് കാൽക്കുലേറ്ററും ആഴ്ചക്രമ/ടൈംടേബിൾ പ്ലാനറും.

## പ്രധാന സവിശേഷതകൾ

- Mobile bottom navigation; desktop-ൽ sticky top navigation.
- ക്ലാസ്, വിഷയം, പാഠം, ആഴ്ചക്രമം, ടൈംടേബിൾ എന്നിവയുടെ ക്രമീകരണം.
- വിഷയത്തിനുള്ളിലെ Quran planner.
- IndexedDB/local storage, JSON backup/restore, optional Google Sheets backup.
- PDF, Excel, poster export code.
- Installable app icons, Malayalam font, offline service worker cache.

## ഫയലുകൾ

- `public/index.html`: ആപ്പ് മുഴുവൻ (HTML, CSS, JavaScript ഒരുമിച്ച്).
- `public/sw.js`: offline പ്രവർത്തനത്തിനുള്ള service worker. ഓരോ deploy-ലും `CACHE_NAME` മാറ്റണം.
- `public/manifest.json`: ഫോണിൽ install ചെയ്യാനുള്ള വിവരങ്ങൾ.
- `public/icon-192.png`, `public/icon-512.png`: app icons.
- `public/malayalam.ttf`: UI/PDF മലയാളം ഫോണ്ട്.
- `public/syllabus.json`: ക്ലാസ് സിലബസ് ഡാറ്റ.
- `public/google-apps-script.txt`: Google Sheets backup സ്വീകരിക്കുന്ന Apps Script കോഡ്.
- `hatchable.toml`: പ്രോജക്ട് വിവരണം.
- `CLEANUP_REPORT.md`: cleanup, UI മാറ്റങ്ങൾ, പരിശോധനാ വിവരങ്ങൾ.

## ഡാറ്റ എവിടെ സൂക്ഷിക്കുന്നു

ഡാറ്റ ഓരോ browser-ലും (IndexedDB) സൂക്ഷിക്കുന്നു; അത്യാവശ്യം localStorage backup-ഉം ഉപയോഗിക്കുന്നു. ഉപകരണങ്ങൾക്കിടയിൽ സ്വയം sync ഇല്ല. ബാക്കപ്പിനായി JSON ഫയലോ Google Sheets-ഓ ഉപയോഗിക്കുക.

## Google Sheets ബാക്കപ്പ്

1. Google Sheet തുറന്ന് Extensions > Apps Script-ൽ `google-apps-script.txt` ഉള്ളടക്കം ഒട്ടിക്കുക.
2. Web app ആയി Deploy ചെയ്ത് കിട്ടുന്ന `/exec` URL ആപ്പിൽ നൽകുക.
3. Web app-ന്റെ access ക്രമീകരണം ആവശ്യത്തിനനുസരിച്ച് സജ്ജമാക്കി, ആപ്പിൽ URL സേവ് ചെയ്ത ശേഷം backup പരിശോധിക്കുക.

## Deploy ചെയ്യുമ്പോൾ

- നിലവിലെ package-ൽ `CACHE_NAME` `syllabus-calculator-v27` ആണ്. അടുത്ത മാറ്റത്തിന് ശേഷം ഇത് വീണ്ടും പുതുക്കുക.
- അസൽ ഫയലിന്റെ backup സൂക്ഷിച്ച ശേഷം ഘടന മാറ്റാതെ അപ്‌ലോഡ് ചെയ്യുക.
- Deploy ചെയ്ത ശേഷം ഒരിക്കൽ refresh ചെയ്ത് പ്രധാന buttons പരിശോധിക്കുക.
