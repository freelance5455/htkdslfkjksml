# THE ZONE V2

Working mobile-friendly prototype with login/demo profile, tournament join, matches, results and admin tournament creation/deletion.

Real OTP, online database, payment gateway and secure server-side room release require a backend service and credentials.