# Upper Body 5 Hari (APK)

## Cara 1: tanpa PC (GitHub Actions)
1. Buat repo baru di GitHub (branch main), upload semua isi folder ini, termasuk folder .github.
2. Buka tab Actions, jalankan "Build APK" (Run workflow), tunggu sekitar 5-10 menit.
3. Buka run yang selesai, unduh artifact "upper-body-apk", ekstrak, lalu install app-debug.apk di hp
   (izinkan "Install dari sumber tidak dikenal").

## Cara 2: dengan PC (Android Studio)
npm install
npx cap add android
npx cap sync android
npx cap open android   (lalu Build > Build APK)

## Data
Progres dan beban disimpan di penyimpanan internal aplikasi (localStorage WebView).
Tetap ada saat app ditutup atau di-update, hilang jika app di-uninstall atau "Clear data".
