# Darrell Restaurant — Phone-Friendly Online Version

## What is included
- `index.html` — mobile-friendly public restaurant site
- `dashboard.html` — restaurant booking dashboard
- `js/config.js` — Supabase connection settings
- `js/customer.js` — creates bookings
- `js/dashboard.js` — reads and updates bookings
- `schema.sql` — database table + demo RLS policies
- `css/style.css` — responsive design

## Phone-only setup
1. Create a Supabase project.
2. Open Supabase SQL Editor and run `schema.sql`.
3. Open `js/config.js`.
4. Replace the two placeholders with your Supabase project URL and public/anon key.
5. Upload the folder to a static web host.
6. Open the public `index.html` URL in Chrome.
7. Open `dashboard.html` for the restaurant side.

## IMPORTANT SECURITY
The included dashboard policies are intentionally DEMO policies so you can test from a phone. They are NOT suitable for a real restaurant because anyone who obtains the dashboard URL could potentially view/update bookings.

Before going live, add staff authentication and change the RLS policies so only authenticated staff can read/update bookings. Never put a Supabase service-role/secret key in frontend JavaScript.

## Next production upgrades
- Staff login/authentication
- Menu database and online food orders
- Customer order tracking
- Payments
- Email/SMS/WhatsApp notifications through a proper server-side provider
- Table capacity rules
- Rate limiting and anti-spam
- Custom domain + HTTPS
- Restaurant Android app using the same backend
