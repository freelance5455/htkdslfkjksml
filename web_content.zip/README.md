# EquaRoom — Classroom + EquaMeet

A mobile-first, full-stack learning platform starter using **Python / Flask**, **SQLite**, **Flask-SocketIO**, browser **WebRTC**, and vanilla JavaScript/CSS. This is a real application scaffold, not a static screenshot.

## Included
- Account registration and sign-in; password hashes stored in SQLite
- Teacher/student roles
- Create classrooms with generated join codes; students join using a code
- Classroom stream / announcements
- Assignments with due dates and points
- Student work submission and teacher submission listing
- Teacher grading API (`POST /api/submissions/<submission_id>/grade`)
- EquaMeet room with camera/microphone controls, participant tiles, screen-share attempt, meeting signaling, and attendance record
- Responsive UI for mobile and desktop

## Run locally
Requires Python 3.10+.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Open `http://127.0.0.1:5000`. For real camera/microphone and screen sharing, browsers generally require HTTPS except localhost.

## Deployment notes
This ZIP contains a Python server. **Cloudflare Pages static upload does not run Flask/Python**. To keep using Cloudflare, deploy the Python app to a Python-capable host (or your own server) and put your domain/DNS behind Cloudflare. Configure a persistent disk/volume for `equaroom.db`; an ephemeral filesystem can erase accounts and classroom data on redeploy. Set a strong `SECRET_KEY` environment variable. Use HTTPS.

For a production deployment, use a production server setup supported by the hosting provider, persistent database storage, rate limiting, account verification/password reset, CSRF protection for cookie sessions, privacy/retention policy, backups, and monitoring. Do not expose the development server directly to the public internet.

## Important EquaMeet limitations
- EquaMeet uses browser peer-to-peer WebRTC with a basic Socket.IO signaling layer and a public STUN server. It can work for small calls on compatible networks, but it is **not a production-grade Google Meet replacement**.
- Many participants, restrictive NAT/firewalls, mobile browser constraints, and unreliable networks can prevent calls from connecting. Reliable group calls need a TURN relay and usually an SFU media server (for example, a separately deployed LiveKit/Jitsi infrastructure).
- Screen sharing support varies by browser/device; mobile browsers may not support it.
- The meeting signaling implementation is a starter; harden authorization, room lifecycle, peer cleanup, and media-server infrastructure before real classes.

## API overview
- `POST /api/register` — `{name,email,password,role}`
- `POST /api/login` — `{email,password}`
- `POST /api/logout`
- `GET /api/me`
- `GET /api/dashboard`
- `POST /api/classrooms` — teacher
- `POST /api/classrooms/join` — `{code}`
- `GET /api/classrooms/<id>`
- `POST /api/classrooms/<id>/posts` — `{body}`
- `POST /api/classrooms/<id>/assignments` — teacher
- `POST /api/assignments/<id>/submit` — `{answer}`
- `GET /api/assignments/<id>/submissions` — teacher
- `POST /api/submissions/<id>/grade` — `{grade,feedback}`
- `POST /api/classrooms/<id>/attendance` — `{meeting_id}`

## Security and data
This project is an MVP starter. Use a unique password and avoid storing sensitive student records until a production security review has been completed. All classes and user data are stored in SQLite.
