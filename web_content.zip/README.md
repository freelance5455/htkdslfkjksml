# BM K16 Daily Checklist — Android V3

This is a **proper Android Studio / Gradle source project**, not a pre-built APK. It replaces the experimental hand-built V2 APK that crashed and triggered an old-Android warning.

Features preserved: separate K16/Bulk A/B/C/Third Party lighting and CCTV, conditional reported/not-reported FMR, temperatures/humidity, auto Indonesian report, multi-photo evidence, copy report, Android sharing.

## Build APK with Android Studio (recommended)
1. On a Windows/Mac/Linux computer, extract the project ZIP and open the folder in Android Studio.
2. Allow Gradle to sync; install Android SDK Platform 35 when requested.
3. Build > Build APK(s) (or run `gradle assembleDebug`).
4. The APK is `app/build/outputs/apk/debug/app-debug.apk`. Copy it to the Android phone.
5. Uninstall the old crashing BM K16 Checklist APK **before installing V3**, since it was signed with a different key. Any locally stored old draft may be lost; copy the message first if accessible.

## Build in the cloud with GitHub Actions
The included `.github/workflows/build-apk.yml` automatically builds an installable Debug APK when the project files are pushed to the `main` or `master` branch, or via **Actions > Build BM K16 Android APK > Run workflow**. In the completed workflow, download the `BM_K16_Checklist_v3_APK` artifact ZIP and extract `app-debug.apk`.

The app loads only packaged offline HTML through `WebViewAssetLoader` (modern HTTPS local origin); no web hosting or account needed after installation. Photos stay in the app's local draft/temporary cache; sharing opens the Android share sheet. WhatsApp controls whether supplied text becomes a photo caption or a separate message, so if needed use **Copy then Share** and paste the message into WhatsApp's caption field.

## Constraints
This project was created without an Android SDK available locally, so **the Android build and runtime behavior have not been verified** in this environment. The GitHub Actions / Android Studio build is required to produce the working APK.
