# لودو x

مشروع ويب مُنشأ بواسطة Klencod Web.

## الهيكل
- `index.html` — الصفحة الرئيسية
- `style.css` — الأنماط
- `script.js` — التفاعلات
- `favicon.png` — الأيقونة
- `manifest.json` — PWA metadata
- `package.json` — metadata

## البدء

افتح `index.html` في المتصفح مباشرة، أو استخدم خادم محلي:

```bash
npx serve .
```

## التعديل

1. عدّل `index.html` لتغيير المحتوى
2. عدّل `style.css` للتصميم
3. عدّل `script.js` للتفاعلات

## التقنيات
- HTML5
- CSS3 (متغيرات، Grid، Flexbox)
- JavaScript (ES6+)
© 2026 لودو x
