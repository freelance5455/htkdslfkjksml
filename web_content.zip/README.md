# Crônicas de Sartana 3.0 (Android)

Projeto Android nativo com WebView local, sem servidor externo próprio. O aplicativo guarda a campanha no armazenamento privado do app e chama a API xAI diretamente a partir de uma ponte nativa Android.

## Recursos incluídos

- Campanha inicial na Batalha dos Cinco Exércitos, com Sartana/Yuriel.
- Continuação narrativa por Grok, preservando histórico e estado da campanha.
- Memória canônica anexada a cada turno para ajudar a manter continuidade.
- Ficha de poderes, nível, experiência, reputação e anotações.
- Inventário editável.
- Elenco editável e registro de relações com personagens.
- Mapa esquemático com registro de locais visitados.
- Ilustração do capítulo pela API de imagens da xAI e upload de imagem local.
- Exportação/importação de backup JSON.
- Armazenamento local no espaço privado do aplicativo.
- APK debug instalável gerado pelo GitHub Actions.

## Requisitos

- Uma chave de API xAI criada em https://console.x.ai/
- A API xAI pode exigir créditos e cobra conforme os modelos e uso.
- Android Studio/Android SDK para compilação local, ou uma conta GitHub para usar a compilação automática.

## Como gerar o APK sem instalar Android Studio

1. Crie um repositório privado no GitHub.
2. Extraia todos os arquivos deste ZIP e envie-os para a raiz do repositório.
3. Abra a aba **Actions** do repositório.
4. Execute **Build APK Android** (ou aguarde o build automático após enviar para `main`).
5. Quando terminar, abra a execução concluída e baixe o artefato `cronicas-de-sartana-apk`.
6. Extraia o arquivo `app-debug.apk` e instale no Android. Talvez seja necessário autorizar a instalação de apps daquela origem.

O repositório deve permanecer **Private**. O APK é um build de depuração assinado automaticamente com uma chave de debug. Para publicar ou distribuir amplamente, gere uma chave de assinatura própria e configure um build release.

## Compilar localmente

Abra a pasta no Android Studio com JDK 17 e Android SDK Platform 35, sincronize o Gradle e execute `assembleDebug`. Ou, com Gradle 8.9 instalado, execute:

```bash
gradle assembleDebug
```

O APK será criado em `app/build/outputs/apk/debug/app-debug.apk`.

## Configurar Grok

Na primeira abertura, toque em Configuração e informe sua chave xAI. O modelo de texto inicial é `grok-4.7`; o modelo de imagem inicial é `grok-imagine-image-2.0`. Os campos podem ser alterados se sua conta tiver acesso a outros modelos. A chave é guardada no armazenamento local do app e enviada à xAI em cada requisição.

Documentação oficial: https://docs.x.ai/developers/quickstart

## Privacidade e segurança

- Não existe conta de usuário, analytics ou servidor próprio neste projeto.
- Os dados da campanha ficam no armazenamento privado do aplicativo Android. Desinstalar o app pode apagar esses dados. Exporte backups.
- A chave API fica no armazenamento local do WebView. Ela não está criptografada por este projeto. Proteja o aparelho com bloqueio de tela e não compartilhe o APK/dados com terceiros.
- O texto da história e os prompts/imagens enviados são processados pela xAI. Portanto, o aplicativo não pode prometer que o conteúdo enviado à API fique exclusivamente no aparelho.
- O APK debug não deve ser tratado como versão final para distribuição pública.

## Imagens e conteúdo

A geração de imagens usa a API xAI `POST /v1/images/generations` com `grok-imagine-image-2.0`. A disponibilidade, os custos e os resultados dependem da conta e das políticas do provedor. O app também aceita imagens escolhidas do aparelho.

O aplicativo é um projeto de fã não oficial, sem afiliação com Middle-earth Enterprises, Warner Bros., Tolkien Estate ou xAI. Não inclui imagens licenciadas dos filmes.

## Limitações conhecidas

- O mapa é esquemático, não um mapa cartográfico navegável.
- As imagens geradas pela API são referenciadas pela URL retornada pelo provedor. Exporte a campanha e mantenha cópias locais das imagens importantes.
- A memória narrativa é resumida/manual e o histórico completo é enviado no contexto da conversa. Campanhas muito longas podem alcançar limites de contexto ou custos maiores.
- A API Grok não é ilimitada e não garante conteúdo sem restrições. O app não contorna políticas do provedor.
