# Sharma Electricals — starter prototype

## Included
- `web/index.html`: responsive browser demo for product browsing, search/category filtering, cart, checkout, COD demo orders, admin product add/delete, order status, and print/save invoice as PDF.
- `android/`: Android Studio project that wraps the same page in a WebView.

## Build the Android APK
1. Install Android Studio on a computer and install Android SDK Platform 35.
2. Open the `android` folder as an existing project.
3. Let Gradle sync complete.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio shows the generated APK path; install it on a test phone.

## Test the web demo
Open `web/index.html` in a modern browser. Some browser restrictions may affect invoice popups; allow popups for printing.

## Important limitations — do not use this prototype as a live store yet
- This is a front-end prototype. Products, cart and orders are saved in that browser/device only. It does not sync across customer phones and your admin.
- Admin is not password protected. Do not publish this demo with real customer data.
- Online payment is deliberately not enabled. Connect a payment gateway through a secure backend and verify payment server-side before confirming orders.
- No real login, cloud database, inventory locking, OTP, shipping API, refunds, tax calculation or automated notifications.
- GST invoice option is only a label/template. Before issuing real GST tax invoices, configure legal seller details, GSTIN, invoice numbering and applicable tax calculations with an accountant.
- Do not put payment secrets/API secret keys in front-end HTML or APK.
- For production, add secure backend (for example Firebase/Supabase or a custom API), admin authentication, privacy policy, terms, backup and testing.

## Suggested low-cost launch sequence
1. Test product categories, sample prices and order flow.
2. Confirm business name/logo, address, contact number, GSTIN (if applicable), delivery charges and minimum order.
3. Build secure backend and admin login.
4. Integrate payment provider in test mode, then production after verification.
5. Deploy the website with HTTPS and publish the Android app after device testing.
