# Mystery Puzzle Room — Android project

This is a starter Android Studio project for the Mystery Puzzle Room game.
It contains a playable Hindi mystery puzzle game packaged in a WebView.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location.

## Quick preview without Android Studio
Open `app/src/main/assets/index.html` in a mobile browser.

## Notes
- The game currently runs locally and stores best score on the device.
- There is no login, online leaderboard, payments, or server yet.
- To publish on Google Play, review current Play Console requirements and privacy disclosures.
