========================================================================
NEXA Student Safety Network — Paquete Completo Multiplataforma
========================================================================

Este archivo ZIP contiene la aplicación NEXA completamente compilada,
optimizada y lista para funcionar en MÓVILES (Android/iOS) y COMPUTADORAS.

ESTRUCTURA DEL ARCHIVO ZIP:
- index.html                -> Archivo principal compilado con rutas relativas
- assets/                   -> Códigos JavaScript y estilos CSS compilados
- manifest.json             -> Configuración de la aplicación móvil PWA
- manifest.webmanifest      -> Manifiesto web estándar
- sw.js                     -> Service Worker para funcionamiento Offline y Push
- pwa-192x192.png           -> Icono de la aplicación en alta resolución
- pwa-512x512.png           -> Icono para la pantalla de inicio y splash screen
- pwa-maskable-512x512.png  -> Icono adaptable para Android (círculo/cuadrado)
- apple-touch-icon.png      -> Icono para dispositivos iOS Retina (180x180)
- icon.svg                  -> Icono vectorial oficial
- config.xml                -> Archivo de configuración para empaquetadores Android
- Lanzar_NEXA_Windows.bat   -> Lanzador directo para ventana independiente en Windows
- Lanzar_NEXA_Mac.command   -> Lanzador directo para ventana independiente en macOS
- nexa-desktop.desktop      -> Acceso directo para sistemas Linux
- electron-main.js          -> Configuración para empaquetar con Electron (.exe / .dmg)
- source_code/              -> Copia completa del código fuente original TypeScript/React

------------------------------------------------------------------------
OPCIÓN 1: PARA TELÉFONOS MÓVILES (ANDROID & IPHONE)
------------------------------------------------------------------------

MÉTODO A: Convertidores Web / ZIP a APK (Para Android)
1. Ingresa a una plataforma externa de conversión como:
   - Website 2 APK Builder (https://websitetoapk.com)
   - AppsGeyser (https://appsgeyser.com)
   - WebviewGold / GoNative
2. Selecciona la opción "Local HTML / ZIP Website".
3. Sube este archivo ZIP tal como está. El convertidor detectará automáticamente el archivo "index.html" en la raíz.
4. Asigna el nombre: "NEXA Safety" y selecciona el icono "pwa-512x512.png".
5. Haz clic en "Build APK" / "Generar APK".

MÉTODO B: PWABuilder (Oficial de Microsoft para Google Play)
1. Ingresa a https://www.pwabuilder.com
2. Introduce la URL de tu aplicación en línea.
3. PWABuilder validará automáticamente el manifest.json y sw.js incluidos.
4. Presiona "Package for Android" para descargar tu APK firmado.

MÉTODO C: En iPhone (iOS Safari)
1. Abre la URL en Safari.
2. Toca Compartir (icono cuadrado con flecha hacia arriba).
3. Selecciona "Agregar al inicio" (+) y pulsa "Agregar".

------------------------------------------------------------------------
OPCIÓN 2: PARA COMPUTADORAS (WINDOWS, MACOS, LINUX)
------------------------------------------------------------------------

1. EN WINDOWS:
   - Haz doble clic sobre "Lanzar_NEXA_Windows.bat".
   - La aplicación se abrirá en su propia ventana nativa independiente, sin barras de URL.

2. EN MACOS:
   - Haz doble clic sobre "Lanzar_NEXA_Mac.command".

3. DESDE EL NAVEGADOR (PWA Standalone):
   - Abre la aplicación en Google Chrome o Microsoft Edge.
   - Haz clic en el icono de instalación en la barra de URL o en Menú (⋮) > "Instalar NEXA Safety".
   - Se creará un acceso directo en tu Escritorio y menú de inicio que abre la ventana independiente.

========================================================================
NEXA Student Safety Network · 2026
========================================================================
