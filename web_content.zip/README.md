# My Household Budget Plus (offline-first prototype)

This ZIP expands the existing household budget web app with local data structures and screens for accounts/cards, transfers, bills/reminders, savings goals, shopping/inventory, shared expense records, a cash-flow estimate, and a basic PIN setup screen. Existing categories, monthly budgets, transactions, and JSON backup/import are retained.

## Build/use
- Upload the ZIP to your chosen HTML-to-APK builder as local ZIP/HTML assets (not as a hosted URL) so the app content is bundled.
- Data is stored in localStorage on the device/browser. Export a JSON backup before installing an updated build.
- Test on a disposable dataset first. The prototype is not yet a production financial app.

## Important limitations
- Browser notification permission is requested where supported, but reminders are checked while the app is open. Reliable scheduled Android notifications need native Android integration.
- The PIN feature currently stores a hash but does not enforce a startup lock screen; do not treat it as security protection.
- Credit card purchases are also recorded as expenses; card payments are tracked in card history only and do not automatically reconcile a bank account. Account balances are simple manually maintained balances and need reconciliation/testing before financial reliance.
- Shared expenses are records on this device only; no cross-device sync or automatic settlements.
- This is a functional prototype/source package, not a compiled or device-tested APK.
