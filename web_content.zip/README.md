COYOTE APP
1. Installer Node.js 20+.
2. Dans le dossier: npm install
3. Copier .env.example en .env
4. Ajouter OPENAI_API_KEY.
5. npm start
6. Ouvrir http://localhost:3000

L'inscription est obligatoire. L'IA utilise la recherche web côté serveur. Ne mets jamais la clé API dans le navigateur.
