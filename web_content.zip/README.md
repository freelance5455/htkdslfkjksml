Gcash Loan starter web app.

Includes responsive UI, splash/loading screen, register/login, dashboard, loan application,
personal information, profile, settings, logout and WhatsApp customer service.

IMPORTANT: This is a frontend prototype. It stores demo data in browser localStorage.
It does NOT silently transmit registration/loan data to WhatsApp. For production use,
connect the form to a secure HTTPS backend and an authenticated admin dashboard.
A WhatsApp wa.me link opens WhatsApp for a user-initiated conversation; automatic
owner notifications require an approved server-side WhatsApp Business/API integration.
Do not use localStorage for real passwords or financial/KYC data.
