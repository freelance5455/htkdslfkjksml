# CryptoTrader v4.4 TR Teste — 100 USD Enhanced

Paper Trading, começando com 100 USD e carteira limpa.

Melhorias desta versão:
- 3 análises iniciais antes da primeira compra.
- 2 confirmações consecutivas por ativo.
- Filtro BTC em 1h + confirmação em 15m.
- Filtro de mercado: pausa novas compras quando há pressão geral de queda.
- Confirmação 1h + 15m para entradas.
- Evita comprar quando o preço está demasiado esticado acima da EMA20 ou RSI elevado.
- Trailing adaptativo e proteção de lucro mantidos.
- Registo de decisões e Paper Trading mantidos.


### Universo de moedas
A app descobre automaticamente os pares Spot USDT ativos da Binance. Para respeitar os limites públicos da API, os candles de 1h são analisados em lotes rotativos de 80 pares por ciclo, enquanto o ticker atualiza o universo completo. BTC é sempre prioritário. Tokens alavancados (UP/DOWN/BULL/BEAR) e pares de stablecoins são excluídos do universo da estratégia.
