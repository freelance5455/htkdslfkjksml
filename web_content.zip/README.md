# Travel Invoice Generator — APK-ready web app

This is a lightweight, single-page travel invoice application designed to match the supplied Carthikeeya Travels invoice layout on A4 paper.

## Included
- Fully editable company name, tagline, invoice heading and currency.
- Logo upload stored locally on the device/browser.
- Invoice number is editable. **New Invoice** automatically increments the numeric part (for example `INV-0015` → `INV-0016`).
- Date pickers for booking date, generated date and due date.
- Customer/company billing type, customer name, phone and location.
- Vehicle type/number, driver name/contact.
- Editable invoice item table: Item, Qty, Rate, Amount; add/remove rows.
- Subtotal, tax/extra and total.
- Separate Payment Details tab with the default values from the supplied reference invoice; payment details are printed at the bottom of the invoice.
- Supporting document uploads (tax/toll/receipts), stored locally.
- **Print / Save PDF** uses the device/browser print dialog with A4 CSS.
- **Download Invoice** exports a standalone HTML invoice using the filename pattern `CompanyNameInvoiceNumber.html` (example: `ARNAV18.html`).
- Local persistence with browser `localStorage`.

## Convert to Android APK
Requirements: Node.js and Android Studio.

1. Extract the ZIP.
2. Open a terminal in the extracted folder.
3. Run `npm install`.
4. Run `npx cap add android`.
5. Run `npx cap sync android`.
6. Run `npx cap open android`.
7. In Android Studio, build a debug APK or generate a signed release APK.

The ZIP intentionally does **not** contain `node_modules` or the generated `android` folder, keeping it well below 5 MB and making it easy to rebuild with current Capacitor dependencies.

## Important
The app is client-side/local-first. Uploaded logos and supporting documents stay in the browser/WebView local storage and are not sent to a server.
