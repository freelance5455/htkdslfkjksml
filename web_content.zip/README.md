Custom Fullscreen Timer V16

Cronômetro progressivo único. O tempo é fixo no centro da tela em qualquer orientação e só permite configurar tamanho e cor. Play/Pause e Configurações são controles fixos.
