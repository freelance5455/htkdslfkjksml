# KIGO AI Web Prototype

Open `index.html` in a browser.

This is a frontend prototype with:
- ChatGPT-style sidebar
- New chat
- Chat input and demo responses
- Feature navigation
- Mobile responsive layout
- Light/dark theme

It does not yet include a real AI backend. For production, connect a secure server-side AI API and never expose API keys in browser code.
