# Nova Code Editor — Android project

This is an Android WebView app with a lightweight code editor, HTML preview, open-file and save-as actions.

## Build an APK from an Android phone using GitHub Actions
1. Create a GitHub account and a new **public or private** repository, e.g. `NovaCodeEditor`.
2. Download and extract this ZIP on your phone.
3. Upload the *contents* of the extracted folder to the repository root (not the ZIP itself). Make sure `.github/workflows/build-apk.yml` is uploaded too. If GitHub mobile hides `.github`, use GitHub in your browser with Desktop site enabled, or upload through another git-capable app.
4. Open the repository → **Actions** → **Build Nova Code Editor APK**. If prompted, enable Actions, then tap **Run workflow**. A push to `main` also starts a build.
5. Open the completed workflow run → **Artifacts** → download `NovaCodeEditor-APK`. Extract the downloaded artifact ZIP and install `app-debug.apk`.
6. Android may ask you to allow installs from the browser/file manager you used. Only install APKs you built and trust.

## What it does
- Write/edit plain text code with line numbers and Tab indentation.
- Open a text/code file through Android's file picker.
- Save with Android's Save As picker.
- Preview HTML in an embedded browser.
- Supports filename/language selector for HTML, CSS, JavaScript, JSON, Python and plain text.

## Limits
This is a starter editor, not a full IDE: no full syntax highlighting, terminal, Python interpreter, or standalone JavaScript runtime. HTML preview uses a sandboxed iframe. It requires an internet connection only for GitHub Actions build; the installed editor itself works offline.

## Build locally
With Android Studio/Gradle and JDK 17 available, run:
`gradle assembleDebug`
Output: `app/build/outputs/apk/debug/app-debug.apk`
