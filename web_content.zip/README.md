# Poralekha CC Cam Monitor v3 (With Time-Lapse Video)

A CCTV-style student monitoring web app that records time-lapse frames during the study session and generates a fast-motion Time-Lapse Video + Bangla Activity Report when stopped.
