# Banpy AI — Protótipo web

## O que está incluído
- Interface responsiva em português, com tema preto e verde-azulado.
- Ecrã de conversa, atalhos criativos e página “Sobre”.
- Respostas demonstrativas locais e histórico da conversa durante a sessão.
- Manifesto e service worker para permitir instalação como PWA quando servido por HTTPS.

## Como abrir no Android
1. Extrai o ZIP numa pasta.
2. Abre `index.html` num navegador compatível, se o gestor de ficheiros permitir.
3. Para instalar como aplicação no ecrã inicial, publica a pasta num alojamento HTTPS e usa o menu do Chrome → “Adicionar ao ecrã inicial” ou “Instalar app”, se aparecer.

## Importante
Esta é uma base de interface, não uma IA online completa. As respostas são regras locais demonstrativas. Para ter respostas inteligentes reais, é necessário ligar um modelo de IA por um backend/servidor seguro. **Não coloques chaves secretas de API no `app.js` nem no navegador.** Autenticação, base de dados, moderação e políticas de privacidade também precisam de ser implementadas antes de lançar publicamente.

## Estrutura
- `index.html` — ecrãs e estrutura
- `style.css` — estilo responsivo
- `app.js` — interacções e respostas de demonstração
- `manifest.json` / `sw.js` — base para PWA
- `assets/icon.svg` — ícone Banpy
