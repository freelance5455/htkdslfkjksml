# The Shadow Monarch — Android Studio Project

This is an Android Studio project wrapping the playable 2D HTML prototype in a native Android WebView.

## Build
1. Install Android Studio.
2. Open this folder: `TheShadowMonarch-AndroidStudio`.
3. Let Gradle sync.
4. Connect an Android phone or start an emulator.
5. Press **Run** to install the debug APK.
6. For a shareable APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The game is locked to landscape and uses immersive fullscreen mode.

## Current prototype
- 70 mission names
- starting ability selection
- sword + kunai combat
- touch controls
- enemy HP and mission progression
- currency/reward system
- Mission 70 completion / commander reward
- New Game+ button

This is still the prototype version; the full 70-mission branching anime game will need the larger content/asset pass.
