# My AI Assistant — Android starter

## What this is
A starter web app that can be opened on Android. It includes:
- Hindi text chat UI
- Browser speech recognition where supported
- Text-to-speech (tap an assistant reply to hear it)
- Optional OpenAI-compatible Chat Completions API settings
- Local demo replies without an API key

## Important limitations
- This is not a native APK yet. To add it to your home screen, host it over HTTPS first.
- API keys stored in browser local storage are not safe for a public/production app. Do not share this project with your key included. A secure backend is recommended.
- Direct browser API calls may fail due to CORS or provider restrictions.
- API usage may cost money. Free usage is not guaranteed.
- Voice recognition depends on Android/browser support and internet settings.

## Easiest Android-only next steps
1. Extract the ZIP.
2. Host `index.html`, `manifest.json`, and `sw.js` on a trusted HTTPS static host (many have free tiers; account/limits may apply).
3. Open the HTTPS URL in Chrome on Android.
4. Chrome menu ⋮ → Add to Home screen / Install app.
5. Test typing, mic permission, and tapping an assistant response to speak.
6. For real AI replies, configure a compatible endpoint, model, and API key in Settings; keep the key private. For a durable safe app, use a backend rather than putting the key in the browser.

This starter is supplied as source files, not an installed APK.
