# Hallex Cheats — Projeto Android

Projeto Android Studio completo que empacota a interface HTML como um aplicativo Android.

## Como gerar o APK

1. Abra esta pasta no Android Studio.
2. Aguarde o Gradle sincronizar e baixar as dependências.
3. Vá em **Build > Build APK(s)**.
4. O APK de debug será gerado em:
   `app/build/outputs/apk/debug/app-debug.apk`

## Ícone

A foto enviada foi usada como ícone do aplicativo.

## Observação

O app é um WebView local da interface HTML. O botão "Injetar / Abrir Free Fire" mantém o comportamento do HTML: mostra a mensagem e tenta abrir o esquema `freefire://`. Isso não implementa injeção de código no jogo.
