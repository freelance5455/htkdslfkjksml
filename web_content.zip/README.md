# MDCAT/NUMS Prep — next development step

This package moves the project from a local prototype toward a real online app.

## Added now
- Backend student accounts (register/login)
- Password hashing
- JWT sessions
- SQLite database
- Cloud progress/mistake sync
- Remote question-bank API
- Premium-only question records
- Google Play subscription verification endpoint
- Android Internet permission
- Android UI hooks for online login/register and sync

## You still need to supply/configure
- Your backend HTTPS domain (replace API_BASE in `index.html`)
- Google Play Console subscription products
- Google Cloud service-account access for Play Developer API
- Deployment of the backend
- Real original/licensed question bank
- Privacy policy and Play Console compliance
- Signed AAB and Play Console testing/release

Do not send passwords, API keys, service-account JSON, or payment credentials to me.
