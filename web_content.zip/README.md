# DYZ Eye Hospital single-page website

This frontend-only redesign uses plain HTML, CSS and JavaScript. All hospital information is arranged as one continuous page; the navigation scrolls to each section. It includes the home experience, hospital story, Dr. Yawar Zaman’s profile and video, doctor directory, facilities, surgery and specialty information, eye-health resources, patient videos and reviews, location map, timings, contact information and appointment request form.

## Open the website

Open `index.html` in a modern browser. No build step, Node.js, database or custom server is needed. Publish the folder to an HTTPS static host for dependable YouTube inline playback. Some browsers do not supply a usable referrer to YouTube when a page is opened as a local `file://` document, which can cause player error 153.

The website uses the hospital’s original logo, surgery and resource article photos, individual YouTube thumbnails with inline playback, Google Fonts and a Google Maps embed. These remote assets require an internet connection. Resource cards open expanded reading guides on this page; they do not send visitors to another site. Confirm the original URLs and clinic schedules before publishing if the hospital source changes.

## Motion and accessibility

Sections and their content animate into view as visitors scroll. The site also uses hover and focus transitions, a reading-progress bar, an animated specialty ribbon, floating eye-care artwork and interactive specialty controls. Motion is reduced when the visitor’s device requests reduced motion.

## Contact and activity

Phone, WhatsApp, email, address and hospital hours are shown on the page. The appointment form opens WhatsApp with the visitor’s details filled in; the visitor must send the message and the hospital must confirm the appointment. Contact click counts, where recorded, stay in the visitor’s browser and do not provide site-wide analytics.

