# Calculadora SCI — PWA instalable y offline

## Contenido
- `index.html`: calculadora web (iluminación, conversión lux/pie-candela, batería).
- `manifest.webmanifest`: nombre, iconos y modo de presentación.
- `sw.js`: service worker que guarda los archivos esenciales en caché para uso offline.
- `icons/`: iconos PNG de 192 y 512 px.
- `calculadora_iluminacion.md`: archivo de referencia aportado por el usuario.

## Probar en un ordenador
Los service workers necesitan un origen seguro. No abras `index.html` directamente como `file://`.
1. Instala Python 3 si no lo tienes.
2. En una terminal, entra en la carpeta del proyecto.
3. Ejecuta `python -m http.server 8000`.
4. Abre `http://localhost:8000` en el mismo ordenador.
5. Comprueba la consola del navegador si algo no carga. Para probar offline, carga primero la página, espera a que el service worker se active y luego usa las herramientas de desarrollo para simular desconexión.

## Instalar en Android
Para instalar desde Chrome, la aplicación debe estar alojada en HTTPS.
1. Publica todos los archivos conservando exactamente la estructura de carpetas.
2. Abre la URL HTTPS publicada en Chrome para Android.
3. Espera a que cargue una vez con Internet.
4. Abre el menú ⋮ y elige **Instalar aplicación** o **Añadir a pantalla de inicio** (el texto depende de la versión de Chrome).
5. Abre la app instalada una vez y luego activa el modo avión para verificar el uso sin conexión.

## Publicación sencilla
### GitHub Pages
1. Crea un repositorio en GitHub y sube el contenido de esta carpeta.
2. En el repositorio, entra en Settings → Pages.
3. Selecciona la rama principal y la carpeta raíz (`/root` o `/` según la interfaz), guarda y espera a que aparezca la URL HTTPS.
4. Abre esa URL desde Android y sigue los pasos de instalación.

También puedes desplegar esta carpeta en un servicio de hosting estático que ofrezca HTTPS, como Netlify o Cloudflare Pages.

## Cambios y actualizaciones
Cuando modifiques archivos, cambia `CACHE_NAME` en `sw.js` (por ejemplo, `calculadora-sci-v2`) para que los dispositivos descarguen una nueva caché.

## Límites técnicos y seguridad
- La app no se ha publicado automáticamente ni incluye una APK.
- El cálculo `lúmenes ÷ área` es una aproximación de iluminancia media idealizada; no prueba cumplimiento de NFPA/COVENIN.
- `candelas ÷ distancia²` supone fuente puntual y medición perpendicular en condiciones ideales.
- La autonomía de batería es teórica: `V × Ah ÷ W`; no modela eficiencia, envejecimiento, temperatura, descarga ni margen de seguridad.
- Antes de usar en diseño, inspección o certificación, valida fórmulas, datos fotométricos y normativa aplicable.
