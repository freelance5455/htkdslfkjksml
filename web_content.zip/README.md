# SLANGIFY v2

Web/PWA prototype with functional on-page keyboard and Gemini BYOK.

No Gemini key is included. The user supplies their own key.

A PWA can be installed like an app, but a normal web app cannot become Android's system-wide keyboard. A future APK/system IME needs an Android-specific wrapper/IME implementation.

Serve over HTTPS for PWA installation and service worker support.
