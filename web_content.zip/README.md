# Jesma Novels — Platform Prototype v0.5

Offline progressive web app (PWA) that demonstrates a full African storytelling platform with dual user simulation, free/premium tiers for readers and writers, platform and author monetisation, and social features.

## What this version demonstrates

### Dual simulated users
Switch instantly between two personas:

| Persona | Role focus | Account type |
|---------|------------|--------------|
| **Nia Reader** | Discovers, reads, tips, joins community | Free → Premium Reader |
| **Tariro Writer** | Publishes, earns, grows audience | Free Writer → Author Pro |

Guest mode is also available for limited browsing.

### Account tiers

**Readers**
- **Guest** — Browse featured works, limited library
- **Free Reader** — Full free catalogue, community, limited saves
- **Premium Reader** — Unlock all Premium content, unlimited library, exclusive serials, ad-free experience (simulated)

**Writers**
- **Free Writer** — Publish limited works, basic stats, standard visibility
- **Author Pro (Premium Writer)** — Unlimited publishing, featured placement eligibility, higher tip multipliers, earnings dashboard, recruitment tools

### How the platform earns (owner view)
- Monthly Premium Reader subscriptions
- Author Pro subscriptions
- Platform commission on reader tips (virtual currency)
- Simulated featured / boosted placement fees
- Future advertising inventory on the free tier

### How writers earn
- Direct tips from readers (Jesma Coins)
- Revenue share from Premium subscriptions (simulated)
- Higher visibility and tip rates with Author Pro
- Featured placement opportunities

### Social & recruitment
- Activity feed inspired by social platforms
- Follow authors, appreciate posts, leave responses
- Persistent “Become a Jesma Author” recruitment surfaces
- Writing prompts and community challenges

### Technical
- Proper PWA: manifest + service worker (works when served over HTTP/HTTPS)
- Fully offline after first load
- Local storage with memory fallback for restricted WebViews
- Mobile-first responsive layout

## Running the prototype

### Browser / local server (recommended for full PWA)
```bash
python -m http.server 8000
```
Open `http://localhost:8000`. Install via browser “Add to Home Screen” / Install prompt.

### Direct file open
Works for most features. Service worker registration is skipped on `file://` origins.

### Android HTML-to-APK / WebView
1. Import the ZIP
2. Start page: `index.html`
3. Enable JavaScript and DOM / local storage
4. Rebuild APK after import

## Important notes
- All payments, subscriptions, tips and earnings are **simulated**. No real money is charged or transferred.
- Data lives only on the device. Reset is available from Profile.
- This is a product demonstration, not a production backend.

## Licensing
- Application source: MIT License
- Demonstration literary works: CC BY 4.0 (retain author credits)
- User-created writing remains the creator’s property

## Version
Prototype 0.5 — Dual-user simulation, free/premium reader & writer tiers, platform economics, social recruitment, expanded content, PWA.
