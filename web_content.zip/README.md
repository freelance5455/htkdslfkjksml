# CBE School Management Platform

A robust, multi-tenant school management system built with Python Flask and SQLAlchemy, tailored for institutions from PP1 to Grade 12.

## Key Features Included:
1. **Multi-Tenancy Isolation:** Tenant separation via `school_id` across all records.
2. **Standardized Class & Stream Structure:** PP1, PP2, and Grade 1 through Grade 12 support.
3. **Automated Staff Email Generation:** `firstname@cbe.co.ke` auto-assignment.
4. **Strict Staff Roles & Permissions:** Principal, Deputy Principal, Senior Teacher, Class Teacher, Subject Teacher, Subordinate Staff.
5. **Daily Staff Clock-In / Clock-Out:** Locked once completed per day; admin override for edits.
6. **Secure Database Backup Download:** Restricted exclusively to Admin and Principal roles.
7. **Exam Categories & Terms:** Term 1, 2, 3 with Opener, Mid-Term, End-Term, and CAT support from 2023 onwards.
8. **Lesson Planning & Workflows:** Upload limits (max 10 documents/term) with review tracking.
9. **Stream & Overall Ranking:** Multi-stream academic ranking calculations.

## Quick Start
```bash
pip install -r requirements.txt
python app.py
```
