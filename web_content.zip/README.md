# FiberDesk Android App

This is an Android Studio project wrapping the supplied FiberDesk HTML app in an offline WebView.

## Data saving
The HTML app uses localStorage plus IndexedDB with save-on-change/visibility handling. Normal app close/reopen or phone restart should retain data. Clearing app data or uninstalling the app can still erase local app storage, so use the built-in backup/restore feature for important records.

## Build
Open this folder in Android Studio and choose **Build > Build APK(s)**. The generated APK will be under `app/build/outputs/apk/`.
