# Handoflogical Project
Aplikasi tracker konsistensi berbasis HTML, CSS, dan JavaScript.

## Menjalankan versi web
1. Ekstrak ZIP.
2. Buka folder `www`.
3. Buka `index.html` di browser.

## Membuat APK Android dengan Capacitor
Perlu Node.js LTS dan Android Studio.
1. Buka terminal di folder proyek.
2. Jalankan `npm install`.
3. Jalankan `npm install @capacitor/core @capacitor/cli @capacitor/android`.
4. Jalankan `npx cap add android`.
5. Jalankan `npx cap sync android`.
6. Jalankan `npx cap open android`, lalu build APK dari Android Studio.

## Catatan
- Akun awal `handoflogical`: 0 poin, role FREE.
- Poin dan riwayat disimpan di localStorage perangkat/browser.
- Belum ada server, login, atau sinkronisasi cloud.
- Tombol tantangan adalah pencatatan mandiri; aplikasi tidak memverifikasi aktivitas.
