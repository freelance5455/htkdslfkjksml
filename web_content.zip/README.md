# NexusAI HTML

## Isi project
- `public/index.html` — struktur aplikasi
- `public/style.css` — desain hitam-ungu responsif
- `public/app.js` — antarmuka chat
- `server.js` — backend aman untuk memanggil OpenAI Responses API

## Menjalankan
Butuh Node.js 20+ pada server/hosting:
1. Salin `.env.example` menjadi `.env`.
2. Isi `OPENAI_API_KEY` dengan API key milikmu.
3. Jalankan `npm install`.
4. Jalankan `npm start`.
5. Buka alamat server melalui browser HP.

Jangan pernah menaruh API key di `public/app.js`, HTML, atau CSS.
Untuk dipakai dari HP melalui internet, deploy server ini ke hosting yang mendukung Node.js dan HTTPS. Jangan bagikan API key. Atur batas penggunaan/budget di akun API. Model default: `gpt-4.1-mini`.
