# Pampa: Vuelo Andino

Simulador de vuelo 3D para celular (Three.js + TypeScript + Vite). Pilotás el jet **Pampa**
(`assets/models/pampa.glb`, el modelo subido por el usuario) sobre un terreno procedural inspirado
en Mendoza: valle con río y viñedos, precordillera ocre y roja, y cordillera nevada.

- **Palanca virtual (izquierda):** flotante, aparece bajo el pulgar. Cabeceo y alabeo.
- **Acelerador (derecha):** deslizador vertical, de ralentí a potencia máxima.
- **Cámara** en tercera persona que sigue al avión desde atrás, con suavizado y apertura de FOV por velocidad.
- **Colisiones:** sondas en el fuselaje y las alas contra el terreno y el agua; al chocar el avión pasa a
  un cuerpo rígido con rebote, explosión, humo y una pantalla de resultados.
- **Anillos de ruta** con multiplicador y récord local; alarma de proximidad al terreno y de pérdida.
- Teclado (WASD/flechas, Shift/Ctrl, Esc) y gamepad también funcionan.

```bash
pnpm install
pnpm dev        # servidor de desarrollo
pnpm build      # typecheck + build de producción + presupuesto de tamaño
pnpm test       # pruebas unitarias (terreno, vuelo, colisión, reglas, guardado)
pnpm smoke      # tras build: recorrido en Chromium móvil con toques reales, capturas en shots/
```

## Estructura

| Ruta | Función |
| --- | --- |
| `src/game/terrain.ts` | Función de altura, normales y color del terreno (pura, determinista) |
| `src/game/terrainView.ts` | Chunks reciclables de malla, shader de detalle y agua |
| `src/game/flight.ts` | Modelo de vuelo arcade (cabeceo, alabeo, viraje por inclinación, acelerador, pérdida) |
| `src/game/collision.ts` | Contacto con el terreno, tiempo al impacto y cuerpo rígido del siniestro |
| `src/game/aircraft.ts` | Envuelve `pampa.glb`: escala, orientación, llama de motor, versión siniestrada |
| `src/game/chaseCamera.ts` | Cámara de seguimiento y órbita de choque |
| `src/game/rings.ts`, `rules.ts` | Anillos de ruta y reglas de puntaje (puras, con pruebas) |
| `src/game/game.ts` | Orquestador: simulación fija, efectos, HUD |
| `src/game/tuning.ts` | Parámetros ajustables en la vista previa (Tweak) |
| `src/engine/` | Bucle fijo, entrada (táctil/teclado/gamepad), render, audio sintetizado, guardado, textos |
| `src/ui/` | Pantallas HTML/CSS, HUD y controles táctiles |
| `src/i18n/es.json` | Todos los textos (español) |

El modelo se registra en `assets.lock.json` y se sirve desde el almacenamiento del proyecto.
