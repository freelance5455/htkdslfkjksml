# MedOrder PKR Fresh

Fresh offline-first HTML medical-store order and invoice app.

## Features
- Medicine catalog with categories, photos, prices, product discounts and stock fields
- Customer/medical store records and order history
- Order cart, quantity controls, percentage and fixed discounts
- Sequential PKR invoices, PDF download, print and file sharing
- Local browser storage for offline use
- JSON backup, share backup and restore
- Optional Google Drive backup (requires your own Google OAuth Client ID and Drive API configuration)
- Responsive mobile-friendly interface

## Build with an HTML-to-APK wrapper
Create a ZIP with `index.html`, `manifest.json`, `sw.js`, and this README at the ZIP root. Enable JavaScript and local storage in the WebView. For reliable Android file downloads and printing, the APK wrapper must support Android DownloadManager/WebView download handling and WebView Print Framework. The Share PDF/Share backup buttons use Web Share API where supported.

## Notes
- No real customer/product data is preloaded; add your own records or restore a backup.
- Google Drive is optional. Configure OAuth consent screen, Drive API and an appropriate OAuth client in Google Cloud. Never place a client secret in this HTML file.
- Data is stored locally in the app/browser. Clearing app data or uninstalling can erase it; keep regular backups.
