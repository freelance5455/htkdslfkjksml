# BLAZE CLIENT — Playable Launcher Integration Starter

This package is the next implementation step toward a real Minecraft Java launcher. It contains:
- Shared responsive BLAZE-style UI.
- Windows desktop Electron shell that lets the user select and open an already-installed official Minecraft Launcher executable.
- Android Kotlin shell starter with a button to open the maintained Android Java-launcher project page.
- Integration roadmap and build instructions.

## Important: what this build does and does not do
This is **not a finished launcher engine and not a compiled APK/EXE installer**.
- Windows: BLAZE can open the Minecraft Launcher executable that the user selects. The official launcher then handles Microsoft sign-in, game files, and launching Minecraft.
- Android: this starter opens the Android Java-launcher project page; it does not itself run Java Edition. A compatible game engine/runtime and graphics/input integration must be integrated and built.
- The UI sections and quick toggles are not live in-game modules yet.
- No Minecraft game files, credentials, paid assets, or mod jars are bundled.

Use a valid Minecraft account and game entitlement. Do not enter Microsoft passwords into BLAZE; sign in only through the official sign-in flow in the official launcher.

## Windows desktop build
1. Install Node.js LTS and a current version of Git.
2. Open a terminal in `desktop-electron`.
3. Run `npm install`.
4. Run `npm start`.
5. Use **Play Minecraft** to select the installed official launcher executable.

To package:
- Run `npm install`
- Run `npm run dist`
- Output installers are created in `desktop-electron/dist`.

Packaging may require Windows build tools depending on your system.

## Android shell build
1. Open `android-shell` in Android Studio.
2. Install Android SDK 35 and let Gradle sync.
3. Build > Build APK(s).
4. This creates a **shell APK**, not a Java Edition game engine. The Android play integration is deliberately not claimed complete.

For Android Java Edition, review the current maintained successor/project status before integrating an engine:
https://github.com/AngelAuraMC/Amethyst-Android

## Shared UI
Open `shared-ui/index.html` in a browser to preview the responsive UI. For desktop and mobile browser preview, this is the fastest path.

## Next engineering milestones
1. Add official Microsoft OAuth using a registered application/client ID and safe token storage.
2. Implement Mojang version-manifest resolution, asset/library downloads, hashes, and native launch arguments for desktop.
3. Add Fabric/Forge/NeoForge installers and compatibility checks.
4. Integrate an Android-compatible Java runtime, renderer, audio, touch controls, and account flow under the chosen project's license.
5. Connect mod discovery to Modrinth/CurseForge APIs and honor each mod's license and loader/version metadata.
6. Add tests, signing, crash logs, and platform-specific packaging.

Do not ship this as a production launcher until the above integrations are implemented and tested.
