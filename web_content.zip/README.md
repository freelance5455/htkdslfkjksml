# AS Enterprises (v2)
Offline stock / sales / labour / wastage / expense / finance app. Data in phone localStorage (key AS_ENTERPRISES_V2); old V1 data is auto-migrated and never deleted.

## Quick use (no build)
Host the `www` folder (or open `www/index.html`) in Chrome on Android -> menu -> Add to Home screen.

## Build APK (Capacitor; needs Node 18+, Android Studio/JDK 17)
    npm install
    npm test
    npx cap add android
    npx cap sync android
    npx cap open android      # Build > Build APK(s)
Or: cd android && ./gradlew assembleDebug  -> android/app/build/outputs/apk/debug/app-debug.apk

## Rules
Available = Opening + Added - DirectSold - LabourTaken + Returned - StandaloneWastage (labour sold & wastage are inside "taken").
Labour Total = sum(sold x rate) - (wastage qty x wastage rate); Net = Labour Total + Morning - Cash - Online (plus = receivable, minus = credit).
Cash Balance (dashboard) = today's Final Benefit: Sale + Previous + Labour Credit - Labour Receivable - Labour Wastage - Expenses - Finance - Loan - School - Own Purchase paid + Bank credit - Bank debit. Labour cash/online are not added separately.
Previous: first day typed by user (editable/deletable); every later day = previous day Final Benefit. Finance & Loan have Credit (+) / Debit (-, default).

## Login / Cloud sync (new phone me data)
App > "Login / Sync" tab: Email+Password (recommended, works in APK too) or Google. After login every change auto-saves to Firestore doc `as_enterprises/{uid}`; on a new phone just login and data is loaded.
One-time Firebase Console setup (project rrprohub):
1. Authentication > Sign-in method: enable **Email/Password** (and Google if wanted).
2. Authentication > Settings > Authorized domains: add the domain where `www` is hosted.
3. Firestore Database: create it, then Rules:

    rules_version = '2';
    service cloud.firestore {
      match /databases/{db}/documents {
        match /as_enterprises/{uid} { allow read, write: if request.auth != null && request.auth.uid == uid; }
      }
    }
Without login the app works fully offline; Backup tab export/restore also moves data between phones.
