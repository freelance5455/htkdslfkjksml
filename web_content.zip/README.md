# The Village MarketPlace PWA

Deploy steps for permanent link:

## Option 1: Netlify Drop (Fastest - 30 sec)
1. Go to https://app.netlify.com/drop
2. Drag & Drop the entire folder (or ZIP it and drop)
3. Done! You get link like https://village-marketplace-xxxxx.netlify.app
4. You can change site name in Netlify settings to villagemarketplace

## Option 2: Vercel
1. Go to https://vercel.com/new
2. Click "Browse" and upload this folder OR import from GitHub
3. Deploy -> you get permanent link

## Option 3: GitHub Pages
1. Create GitHub repo, upload files
2. Settings > Pages > Deploy from main branch

Files included:
- index.html (your full app)
- manifest.json (for installable)
- sw.js (offline)
- _redirects, vercel.json
- README.md
