# ROTA YKS - Takvimli Planlayıcı & Net Takip

YKS Hazırlık süreciniz için güncel tarihli ders programı ve TYT/AYT deneme net takip web uygulaması.