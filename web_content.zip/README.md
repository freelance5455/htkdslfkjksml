# Counter CM — Final HTML APK Package

Gunakan `index.html` sebagai entry point untuk APK Builder/WebView.

Fitur:
- Baik: Sekarang, Sebelumnya, Hasil Baik
- Jelek: Sekarang, Sebelumnya, Hasil Jelek
- Jelek 2: Sekarang, Sebelumnya, Hasil Jelek 2
- Tombol JUMLAH
- Total = Hasil Baik + Hasil Jelek + Hasil Jelek 2
- Persentase Baik = Hasil Baik / Total × 100
- Persentase Jelek = Hasil Jelek / Total × 100
- Persentase Jelek 2 = Hasil Jelek 2 / Total × 100
- Tombol RESET
- Offline
- Tanpa A1/A2/A3, tanpa rumus, tanpa tanggal/waktu, tanpa Simpan Hasil
