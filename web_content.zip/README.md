# Zigbee Magyar – Android alkalmazás v0.1

Ez egy Android Studio projektindító a saját magyar Zigbee/okosotthon alkalmazáshoz. A telefon a Home Assistant REST API-ján keresztül kommunikál; a Zigbee rádiót nem a telefon kezeli közvetlenül.

## Jelenlegi funkciók
- Home Assistant URL és token megadása
- Entitások listázása (lámpák, kapcsolók, érzékelők, termosztátok stb.)
- Kapcsolható entitások be-/kikapcsolása
- Magyar felület és helyi beállításmentés

## Szükséges központ
Home Assistant OS + MQTT broker + Zigbee2MQTT + kompatibilis USB-s Zigbee koordinátor.

## Fordítás
1. Telepítsd az Android Studio stabil verzióját.
2. Nyisd meg ezt a projektmappát.
3. Várd meg a Gradle szinkronizálását.
4. Android SDK 35 és JDK 17 szükséges.
5. A Build > Build APK(s) menüvel készíthetsz teszt APK-t.

## Első kapcsolódás
1. Home Assistantban: Profil > Hosszú élettartamú hozzáférési tokenek > token létrehozása.
2. A token csak a telefonon add meg; ne töltsd fel GitHubra és ne oszd meg másokkal.
3. A központ címe lehet például `http://192.168.1.50:8123`.
4. A helyi HTTP csak megbízható otthoni hálózaton használandó. Távoli használathoz HTTPS és biztonságos hozzáférés kell.

## Korlátok
Ez első prototípus, nem kész, teljes okosotthon-kezelő. Az automatizálások és a speciális eszközfunkciók kezelése későbbi fejlesztési lépés. A jelenlegi kód a Home Assistant entitásait listázza, ezért az eszközök megjelenése attól függ, hogy a Zigbee2MQTT megfelelően integrálva van-e a Home Assistantba.
