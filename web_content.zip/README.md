# Neon Journal — Android builder ZIP (PDF export removed)

This ZIP is formatted for an HTML-to-APK builder that accepts a ZIP containing `index.html` at the root.

Features retained: local journal entries, mood tracking, prompts, gratitude, habits, tags, search, goals, PIN convenience lock, JSON backup and JSON restore, offline cache.

PDF export has been removed from the interface and source code. Use Settings → Export backup to create a JSON backup that can restore editable journal entries.

Important: the PIN is a convenience lock, not encryption. The journal database is stored in browser local storage and is not encrypted at rest. Test JSON backup and restore before relying on the app.
