# Glassboard Android

Standalone Android wrapper for the Glassboard HTML app. The UI is bundled locally and opens as its own Android app, not a Chrome tab.

## Build
Open this folder in current Android Studio and let Gradle sync. Build **app > Tasks > build > assembleDebug** or use **Build > Build APK(s)**.

The bundled app includes local task/sub-task time periods, repeating reminders, local Android notifications, notification tap-to-open, image/video file chooser support, and the existing Glassboard media viewer.

Android 13+ requires notification permission.
