# Ege & Ece — 120 Bölümlük Tam Web Paketi

ZIP’i çıkarıp `ege-ece-projesi/index.html` dosyasını açın. Bölüm verisi yerel JavaScript içindedir; çift tıklamayla açılış için sunucu gerekmez. Telefon ve tablette dosyaları aynı klasör yapısıyla barındırıp tarayıcıdan açabilir veya Android WebView / Capacitor içine paketleyebilirsiniz. **Bu ZIP APK değildir.**

## İçerik

120 bölüm, 7 dünya, 9 oyun türü: eşleştirme (20), yolu izle (5), renkler (15), sayılar (11), rakam/harf çizimi (37), harf seçimi (12), hafıza (8), sınıflandırma (6), dinle ve bul (6). Çizim ve yol bölümleri tek tur; diğerleri bölüm başına beş rastgele tur.

İlk açılışta oyuncu adını ve Ege ya da Ece’yi seçer. Seçim ve tamamlanan bölümler cihazda saklanır; ana ekrandan isim/karakter değiştirilebilir. İlerleme isim ve karakter bazında ayrıdır. Sesli yönergeler cihazın Türkçe konuşma sentezine bağlıdır; cihazda Türkçe ses yoksa telaffuz farklı olabilir. Ses kapatılabilir. Dinle ve Bul oyununda sesi yeniden dinleme düğmesi vardır.

## Bilinen sınırlar

Bu sürümde çizim kontrolü harfin yaklaşık %58’inin üzerinden geçmeyi ölçer; kalem izi ve doğru yazım yönü değerlendirilmez. Cihazın yerel verileri silinirse ilerleme de silinir. Sesli oyunlar için Türkçe TTS desteği gerekir. Web sürümü dokunmatik için uyarlanmıştır; gerçek Android APK ve farklı telefon/tablet cihazlarındaki kullanım henüz doğrulanmamıştır.

## Klasör

- `index.html`: açılış dosyası
- `data.js`: 120 bölümün içerik verisi
- `app.js`, `style.css`: yeni oyun motoru ve arayüz
- `assets/`: Ege/Ece pozları ve özel açılış görseli
- `sw.js`, `manifest.webmanifest`: sunucuda açıldığında çevrimdışı kullanım altyapısı
