# Tuition Fee Manager BD

A mobile-first tuition fee manager for teachers and tutors in Bangladesh. The app runs entirely in the browser and saves its records in that browser's local storage. It has no Firebase, cloud database, authentication service, or account-based data sync.

## Start using the app

Serve the project with any static HTTPS host (or a local development server). Open the page and use the dashboard; no account or configuration is needed. The app is installable as a PWA when served over HTTPS.

## Data storage and privacy

Students, monthly fee records, payments, reminders, classes, and the teacher profile are saved on the current browser and device. They are not encrypted by this app, synced to other devices, or protected by user accounts. Anyone with access to the browser profile may be able to access the records. Avoid using shared devices and use **Export backup** regularly. Clearing browser/site data can permanently erase records; **Clear all data** in Settings intentionally removes all app records.

CSV export is available for student and report data. WhatsApp and SMS reminders open the device or browser composer with the message ready for the teacher to review and send manually; the app does not send messages automatically.

## Features

- Student profiles, class and section labels, guardian contact details, and duplicate roll checks.
- Monthly fee snapshots, partial/full payments, outstanding balances, payment edits, and printable receipts.
- Dashboard summaries, collection charts, filters, reminders, reports, CSV exports, and print-to-PDF through the browser's print dialog.
- English/Bangla navigation labels, light/dark appearance, and responsive mobile navigation.

## Important limitation

Local browser storage is suitable for personal, single-device use, not secure multi-user or production cloud storage. It does not provide authentication, server-side access control, automatic backups, or cross-device synchronization. For sensitive student records or multiple teachers, use a trusted backend with authentication, authorization rules, encrypted transport, and tested backup and recovery procedures.
