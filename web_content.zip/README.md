# TwinPane

## APK'yı telefondan üretmek (Android Studio gerekmez)
1. GitHub'da yeni bir repo aç, bu klasörün içeriğini (`.github` dahil) yükle.
2. Repo > Actions > "Build APK" > Run workflow. Bitince "TwinPane-debug-apk" çıktısını indir, zip'ten çıkar, APK'yı kur.
3. İlk açılışta "Tüm dosyalara erişim" iznini ver. Uygulama telefonun gerçek dosyalarını gösterir.

## Android Studio ile
Klasörü aç (Ladybug+), Gradle wrapper'ı Studio oluşturur. Mimari: ARCHITECTURE.md
