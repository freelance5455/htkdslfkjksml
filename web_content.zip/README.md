# Daftar Hadir Murid — proyek Android

## Fitur
- Akun lokal dengan nama pengguna dan PIN di perangkat
- Data sekolah/kelas dan tanggal absensi
- Tambah/hapus murid
- Status Hadir, Sakit, Izin, Alpa
- Ringkasan dan rekap berdasarkan tanggal
- Simpan otomatis secara lokal (WebView localStorage)
- Ekspor CSV
- Bisa digunakan offline

## Membuat APK di Android Studio
1. Pasang Android Studio di komputer/laptop dari https://developer.android.com/studio
2. Ekstrak ZIP ini.
3. Android Studio → Open → pilih folder `DaftarHadirMurid`.
4. Tunggu Gradle sync. Jika diminta, pasang Android SDK Platform 35 dan JDK yang direkomendasikan Android Studio.
5. Pilih Build → Build Bundle(s) / APK(s) → Build APK(s).
6. Setelah selesai, klik `locate`. APK debug biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`.
7. Pindahkan APK ke HP Android dan izinkan pemasangan dari sumber tersebut saat diminta.

## Catatan penting
- Login saat ini adalah akun lokal, bukan autentikasi online. PIN tidak dapat dipulihkan jika terlupa; simpan data ekspor CSV secara berkala.
- Data disimpan di perangkat, tidak tersinkron ke cloud.
- Uji APK di HP sebelum dipakai untuk data resmi.
