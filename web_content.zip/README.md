# WHITE ROOM OS — Personal Development Operating System

## Phase 1 — Core MVP Status
- **Database Engine (`src/core/db.js`)**: Local-first IndexedDB (`WhiteRoomOS_DB` v1) with 16 versioned object stores and deterministic in-memory fallback for Node.js tests.
- **Validation Engine (`src/core/schema.js`)**: Runtime schema validation for all entities.
- **Reactive Store (`src/core/store.js`)**: Zustand-compatible state management (`getState`, `setState`, `subscribe`).
- **Time & College Schedule Engine (`src/engines/timeEngine.js`)**: Dynamic, user-editable schedule (default College Days: Saturday, Tuesday, Thursday `06:00–18:00`).
- **Daily OS Engine (`src/engines/dailyOsEngine.js`)**: Generates adaptive daily missions across `Primary`, `Secondary`, `Maintenance`, and `Recovery` slots based on net free time and energy.
- **Persistent Timer Engine (`src/engines/timerEngine.js`)**: Wall-clock timestamp state machine (`Start`, `Pause`, `Resume`, `Finish`, `Cancel`, `Reset`) surviving page refreshes, tab switches, and backgrounding.
- **Performance & Error Seeding Engine (`src/engines/performanceEngine.js`)**: Records completion %, energy, difficulty, confidence, what learned, and mistakes (automatically seeding structured `ErrorRecord` items).
- **Backup & Restore Engine (`src/engines/backupEngine.js`)**: Full database JSON export with FNV-1a checksum and pre-restore schema validation.

## Commands
- Run Unit & Integration Tests: `npm test` (`node --test tests/unit_and_integration.test.mjs`)
- Build Standalone WebApp & Capacitor Dist: `npm run build` (`node scripts/build.mjs`)
- Run End-to-End Headless Browser Tests: `python3 tests/e2e_browser.py`
