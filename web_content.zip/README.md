# Shinobi Sensi — toxzinfps

Mantém o gerador original de sensibilidade e inclui, em uma segunda aba, o calibrador de giroscópio para Blood Strike.

## Seletor de celulares
A lista de marcas foi ampliada e oferece sugestões para vários modelos. Como fabricantes lançam e renomeiam aparelhos continuamente, o campo de modelo também aceita qualquer nome digitado, mesmo quando ele não aparece nas sugestões.

## Calibração do giroscópio
Cada sessão dura 30 segundos. Durante a contagem, mantenha o aparelho imóvel; no fim, o app calcula uma média das leituras recebidas, aplica a referência ao monitor e mostra a confirmação na tela. Há sessões separadas para giroscópio e acelerômetro.

## Instalar e usar
Abra `index.html` para visualizar. Para ler os sensores e instalar como PWA no celular, publique os arquivos em HTTPS e conceda a permissão ao iniciar o monitor.

## Limites
A lista não pretende ser um inventário imutável de todos os aparelhos existentes; modelos não sugeridos podem ser digitados. A calibração salva referências usadas pelo monitor desta página; não recalibra o sensor do Android nem altera a sensibilidade interna do Blood Strike. Quando o navegador não oferece frequência nativa configurável, a frequência escolhida afeta apenas a atualização do gráfico.

Imagem de fundo da interface: `madara-bg.jpg` (imagem fornecida pelo usuário), incluída no cache offline.
