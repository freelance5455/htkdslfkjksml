# EduMentor AI

An adaptive personal AI tutor, academic planner and examination preparation system for **CBSE Class 10 & 12, JEE Main and JEE Advanced** (plus custom exam profiles).

It is a working application, not a UI prototype: study data is stored in D1, PDFs are really parsed and indexed, tests are really generated and evaluated, and every chart is computed from the signed-in student's own activity.

---

## What is inside

| Area | What actually works |
| --- | --- |
| Onboarding | Multi-step academic profile: exam, class/board, dates, target, subjects, weak/strong subjects, school/coaching hours, sleep window, preferred study hours, learning preferences. Rejects profiles built on under 6 hours of sleep. |
| AI Teacher | Chapter-aware tutor with **Beginner / Exam / Advanced** modes, conversation history, verification questions, and document-grounded answers with `[n]` citations (document + page). |
| Resources | Browser-side PDF text extraction (pdf.js), page-aware chunking, hashed TF embedding, cosine retrieval. Summaries, formula extraction, topic mapping and question generation from the document. Original PDFs archived in R2. Pasted text supported for scanned pages. |
| Test Centre | Generate from the bank instantly or with AI; choose exam, subjects, chapters, question types, difficulty, count, duration, negative marking. Real exam marking rules, shortfall reported honestly. |
| Exam simulator | Full-screen timed interface, palette, mark-for-review, prev/next, auto-save, resume, submit confirmation, auto-submit at time-up, per-question time tracking. |
| Evaluation | Exact objective grading (including multiple-correct and numerical tolerance), AI rubric grading for descriptive answers, mistake classification, subject/chapter/difficulty breakdowns and an improvement plan. |
| Planner | Deterministic adaptive scheduler around school/coaching/sleep and daily hour budget; prioritises weak chapters, spaced-repetition dues and exam proximity; inserts breaks and a weekly mock. Missed sessions are moved into free slots, not rebuilt. |
| Revision | SM-2-style spaced repetition for chapters and flashcards, mistake-generated cards, AI flashcards, formula sheet from your documents, instant recall quizzes. |
| Question bank | Filter by subject, chapter, type, difficulty, source, attempt status, bookmark state; inline grading; AI “generate similar” saved with a clear AI label. |
| Analytics | Accuracy trend, subject/chapter maps, mistake distribution, difficulty radar, study consistency and extra practice volume — all from stored attempts. |
| Motivation | Streaks, badges, daily goals, Pomodoro focus timer that logs real study minutes, honest recovery plans. |
| Security | PBKDF2 password hashing, HttpOnly session cookies, per-user query scoping, ownership checks on every resource/attempt, input validation, API keys server-side only. |

### Honest limitations

- AI features need an `OPENAI_API_KEY`; without one they show a setup card.
- Scanned/image-only PDFs are detected but not OCR'd, and doubts must be typed
  or attached as text-based PDFs.
- No previous-year questions ship with the app; the practice bank is original
  content and is labelled as such.

- **OCR is not included.** Image-only/scanned PDFs have no text layer; the app detects this, tells you which pages were skipped, and offers a paste-text path. It never pretends to have read them.
- **No previous-year questions are preloaded.** Every seed question is original and labelled *EduMentor practice*; only items you import/mark as verified are shown as verified.
- **AI features require `OPENAI_API_KEY`.** Without it the tutor, doubt solver, AI papers, document analysis and descriptive grading are disabled with a clear setup message. The planner, bank tests, objective evaluation, analytics and revision cards work without any key.
- Descriptive answers are only auto-marked when AI grading is configured; otherwise they are stored and shown with the model answer rather than receiving a fabricated mark.

---

## Stack

- **Frontend:** React 18, TypeScript, Vite, Tailwind CSS, Recharts, KaTeX, pdf.js
- **Backend:** Hono on Cloudflare Workers (workerd), D1 (SQLite), R2 for original PDFs
- **AI:** any OpenAI-compatible endpoint; defaults to the Freebuff API (`https://freebuff.com/api/v1/paid`), model `gpt-4o-mini` (override with `AI_MODEL`)
- **Retrieval:** local hashed bag-of-words embeddings + cosine similarity, entirely inside the Worker (no vector service, no external embedding cost)

## Local development

```bash
npm install
npm run build          # vite build + worker bundle
npx wrangler dev --port 8787 --ip 0.0.0.0
```

Open http://localhost:8787. Local D1 and R2 are simulated under `.wrangler/`; the schema is applied automatically on first API request and the shared practice bank seeds itself once.

For iterative UI work:

```bash
npm run dev:watch      # vite build --watch + worker rebuild + wrangler dev
```

### Enabling AI

Create `.dev.vars` (never committed):

```
OPENAI_API_KEY=your-key-here
# optional
# AI_MODEL=gpt-4o-mini
# OPENAI_BASE_URL=https://your-openai-compatible-endpoint/v1
```

Get a Freebuff API key from **Account → Developer API** (https://freebuff.com/account/api). On a hosted Sites deployment, add `OPENAI_API_KEY` under **Sites → Secrets** after the first deploy — never in the client bundle.

### Tests

```bash
npm run typecheck
npm run smoke          # requires the dev server on :8787
```

`scripts/smoke-test.mjs` exercises the real API end to end: registration, login, validation, onboarding, syllabus seeding, dashboard metrics, PDF text ingestion + retrieval, empty-PDF rejection, bank test generation, attempt autosave, submission and evaluation, planner generation and constraints, session completion, revision review, quizzes, bookmarks, analytics, per-user isolation, unauthenticated rejection, and graceful AI-key errors.

## Deployment (Cloudflare)

1. Build: `npm run build`.
2. Deploy the Worker with `build/worker.js` as the module, `dist/` as assets (SPA fallback), D1 binding `DB`, optional R2 binding `FILES`, and secret `OPENAI_API_KEY`.
3. The manifest is in [`sites.manifest.json`](sites.manifest.json) for the managed Sites deployer.

## Deployment (Vercel)

The app runs on Vercel too, using a libSQL (Turso) database instead of D1 and a
database-backed bucket instead of R2. `vercel.json` builds the SPA and bundles the
API from `api/index.ts`; Vercel serves the static files and routes `/api/*`
to that function.

1. Create a free libSQL database at [turso.tech](https://turso.tech) (or run any
   libSQL server) and copy its URL and token.
2. Import this repository in Vercel. No framework preset override is needed;
   `vercel.json` sets the build command and output directory.
3. Add these Environment Variables for Production **and** Preview, then redeploy:
   - `TURSO_DATABASE_URL` — `libsql://…` (or `https://…`)
   - `TURSO_AUTH_TOKEN` — the database token
   - `OPENAI_API_KEY` — optional, enables every AI feature
   - `OPENAI_BASE_URL`, `AI_MODEL` — optional overrides
4. Open the deployment and register. The schema is created automatically on the
   first API request; no migration step is required.

Notes:

- Without the two database variables, `/api/*` answers `503` with a plain-language
  setup message instead of failing silently — the sign-in screen shows it.
- Original PDFs are archived in the `resource_files` table on Vercel. Keep uploads
  moderate (a few MB); large archives are a better fit for R2 on Cloudflare.
- `api/index.ts` is a real source file on purpose: Vercel detects API functions
  **before** it runs the build, so a bundle generated during the build is never
  registered. Keep it checked in.
- Vercel does not support catch-all filenames (`[...route].ts`) in a non-Next
  `api/` directory, so `vercel.json` rewrites `/api/(.*)` to that single
  function, which receives the original path. Do not rename it.
- Sign-in also offers **Continue as guest**, which creates a real cookie-backed
  account on the server (isolated data, no credentials).
- `npm run build:vercel` builds the client and a local copy of the API bundle;
  `npm run vercel-dev` runs it against a local `.vercel-local.db` for testing.
- Verify the Vercel code path locally with
  `npm run build:vercel && node scripts/vercel-dev.mjs` and then
  `BASE_URL=http://127.0.0.1:3100 npm run smoke`.

## Data model

`users`, `sessions`, `profiles`, `chapter_progress`, `study_sessions`, `goals`, `plans`, `schedule_items`, `resources`, `resource_chunks`, `resource_insights`, `questions`, `tests`, `attempts`, `question_attempts`, `bookmarks`, `revision_cards`, `chats`, `messages`, `doubts` — see `worker/schema.ts`.

All student data is scoped by `user_id`; the only shared rows are the built-in practice questions (`user_id IS NULL`).

## Notes on academic integrity

EduMentor is a preparation tool. It does not predict marks or ranks, does not claim official exam patterns where the board changes them yearly (the UI labels indicative counts), and tells you when a document or the question bank does not cover what you asked.
