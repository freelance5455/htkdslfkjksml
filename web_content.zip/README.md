# Streit-Detektor 

Dies ist das Quellpaket, mit dem WebToApp die App gebaut hat.

- app_config.json: die Laufzeitkonfiguration, die in der APK steckt. Ein verschlüsselter Build speichert diese Datei als Geheimtext; diese Kopie ist Klartext.
- network_security_config.xml und certs/: Netzvertrauens-Einstellungen. Damit lässt sich die volle Zertifikatskette prüfen (Root und Intermediate).
- content/: lokale HTML-, Frontend-, Galerie-, Startbildschirm- und Audiodateien der App. node_modules und .git fehlen.

Die installierbare APK ist die WebToApp-Shell plus diese Dateien. Dieses Archiv enthält keinen Signatur-Keystore. Es kann Aktivierungsgeheimnisse und Proxy-Zugangsdaten enthalten, die Sie festgelegt haben.