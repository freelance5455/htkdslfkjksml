# FYNK PartnerHub — Android Studio project

This is an Android WebView wrapper with a bundled, responsive FYNK PartnerHub prototype.

## Build an APK
1. Install Android Studio (current stable) and the Android SDK.
2. Open this folder (`FYNK_PartnerHub_Android`) in Android Studio.
3. Allow Gradle sync and install any requested Android SDK platform.
4. Choose **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## Included prototype features
- Dashboard and KPI cards
- Outlet directory and add-outlet form
- Swiggy and Zomato internal status tracking
- Menu item management
- Follow-up task tracking
- CSV export
- Local browser storage for prototype data

## Important limitations
This is a prototype, not a production backend. It does not include server authentication, multi-user sync, secure document upload, or live Swiggy/Zomato API integration. Demo data is illustrative. Do not enter real PAN, bank, or licence data until a secure backend and access controls have been implemented.

For a production deployment, connect a backend such as Supabase, enforce role-based access on the server, use private object storage, and verify any official aggregator integration before enabling it.
