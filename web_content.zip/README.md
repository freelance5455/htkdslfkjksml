# حساب آسان

اپ کاملاً آفلاین. فایل اصلی: `www/index.html`

## اجرای سریع
فایل `www/index.html` را در Chrome اندروید باز کنید (داده‌ها محلی ذخیره می‌شوند).

## ساخت APK (نیازمند Node.js و Android Studio)
```
npm install
npx cap add android
npx cap sync
npx cap open android
```
در Android Studio: Build > Build APK(s).

## نکته Back
برای بسته شدن اپ با Back در Home، در `MainActivity` یا با افزونه `@capacitor/app` رویداد `backButton` را بگیرید:
```
import {App} from '@capacitor/app';
App.addListener('backButton',({canGoBack})=>{canGoBack?history.back():App.exitApp()});
```
این کد را در انتهای `www/index.html` اضافه کنید. (در Home هیچ history ی نیست، پس یک بار Back خروج می‌دهد.)

## Backup
در WebView از Share استفاده می‌شود؛ فایل را می‌توان در Downloads/Drive و ... ذخیره کرد.

## فونت نازنین
فایل `Nazanin.ttf` (فونت B Nazanin با مجوز معتبر) را در `www/fonts/` بگذارید تا قبل از `npx cap sync` در برنامه به‌صورت آفلاین بارگذاری شود. بدون آن، فونت مشابه (Noto Naskh Arabic یا فونت سیستم) نمایش داده می‌شود.

## یادآور و اثر انگشت در APK
- یادآور در نسخهٔ وب فقط وقتی برنامه باز است صدا/اعلان می‌دهد. برای هشدار وقتی برنامه بسته است: `npm i @capacitor/local-notifications` و زمان‌بندی اعلان‌ها با آن.
- اثر انگشت در WebView اندروید همیشه کار نمی‌کند. برای اطمینان: `npm i capacitor-native-biometric`.
