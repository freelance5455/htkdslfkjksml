# NN Library — Library-only prototype

This version focuses on reading and library management. The marketplace navigation is hidden.

## Open on your Samsung tablet
1. Extract `NN_Library_App.zip`.
2. Open the extracted folder in Acode.
3. Open `index.html` and preview it in your browser.
4. Keep `style.css` and `app.js` beside `index.html`.

## Demo admin login
- Username: `admin`
- Password: `NNadmin123!`

Create a member account from Account / sign in.

## Included
- Member registration and sign-in
- Admin dashboard and book registration
- Book catalog search by title, author, ISBN or category
- Digital book links (only when an authorized URL is supplied)
- Physical book borrowing and return tracking
- Three-day / 72-hour due dates and demo overdue-fee calculation
- In-app notifications
- Member list and borrowing activity for administrators
- Responsive design for phones and tablets

## Limitations
This is a front-end prototype. Data is stored only in this browser on this device; it is not a shared online database. It does not automatically send SMS/email/push notifications. Sample entries do not include actual textbook PDFs. Only add books or links you have permission to share. A secure backend is required before real-world use.
