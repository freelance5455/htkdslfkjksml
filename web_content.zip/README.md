# Samarth AI Android App

Personal-use Android project for Samarth AI.

Included:
- Animated dark/neon UI
- Online / Offline mode switch
- Language selector
- Chat interface with typing animation
- Native Android Text-to-Speech bridge
- Male/Female voice preference when the installed Android TTS engine exposes those voices
- Voice speed control
- Tool shortcuts
- Mobile/email login UI demo
- Powered by Aman Saggu branding

Important:
- The Online mode in this starter project is a UI/demo mode. It does NOT contain an OpenAI API key.
- For real online AI, connect the app to your own secure backend and keep provider API keys on the server, not inside the APK.
- The login/OTP screens are UI scaffolding until a real authentication provider is connected.
- Offline AI inference is not included as a model binary; a local model can be integrated later.

Build:
Open the project in Android Studio, let Gradle sync, then Build > Generate App Bundles or APKs > Generate APKs.
