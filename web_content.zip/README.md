# DISCIPLINE — APK-ready Capacitor project

هذه النسخة مجهزة خصيصًا لتغليف مشروع HTML داخل Android باستخدام Capacitor 8.

## ماذا تم تحسينه؟
- `www/` هو مجلد الويب الذي سيُحزم داخل التطبيق.
- `capacitor.config.json` مضبوط على:
  - App ID: `com.youssef.discipline`
  - App name: `DISCIPLINE`
  - Web directory: `www`
- أضيفت إعدادات Capacitor وLocal Notifications.
- أضيفت أيقونة عالية الدقة داخل `resources/icon.png`.
- الخلفية المخصصة تُحفظ محليًا وتظهر خلف واجهة التطبيق بدون رفعها.
- أضيف دعمًا لاستخدام Capacitor Local Notifications عندما يكون التطبيق مغلفًا داخل Android.
- زر الرجوع في Android يعيد المستخدم إلى Home بدل التنقل العشوائي.
- التطبيق لا يعتمد على CDN.

## تحويله إلى APK
يتطلب بناء Android فعليًا Android SDK/Gradle، لذلك لا يوجد مجلد `android/` مولّد مسبقًا داخل ZIP.

على جهاز فيه Node.js وAndroid Studio:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

ثم من Android Studio:
`Build → Generate App Bundles or APKs → Generate APKs`

### الأيقونة
الأيقونة المصدر موجودة في:
`resources/icon.png`

بعد `npx cap add android` يمكن استخدام Android Studio / Capacitor asset generation لتوليد جميع أحجام launcher icons.

## المنبهات
داخل Android، المشروع يحاول استخدام `@capacitor/local-notifications` عند توفره. هذا أفضل من Notification API الخاصة بالمتصفح.

لضبط التنبيهات الدقيقة المتكررة، راجع إعدادات Android الخاصة بالإشعارات/البطارية في الجهاز، لأن بعض الشركات قد تقيد التشغيل في الخلفية.

## الخلفية والصور
اختيار الخلفية يتم من `<input type="file" accept="image/*">` ويستخدم صورة الجهاز محليًا. لا يوجد رفع للخادم.

## ملاحظة
هذه نسخة Web Native: الواجهة HTML/CSS/JS داخل حاوية Android أصلية بواسطة Capacitor، وليست مجرد اختصار لموقع في المتصفح.
