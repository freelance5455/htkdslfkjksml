# Pocket Chess Android

A small offline Android WebView app with a mobile chessboard, legal move generation, castling, en passant, promotion, undo, restart, move history, and a local minimax computer opponent (Easy/Medium/Hard search depths).

## Build an APK
This source project is prepared for Android Gradle Plugin 8.7.3, Java 17+, and Android SDK platform 35.

1. Install Android Studio on a computer.
2. Open this `PocketChessAndroid` folder as a project and allow Gradle sync.
3. Install Android SDK Platform 35 and a compatible Android Build Tools version if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

The current ChatGPT runtime does not have the Android SDK or Gradle installed, so this ZIP is the project source, **not a precompiled APK**. No network access is needed by the app after it has been built. Review and test the APK on a device before distributing it.
