# Khandaghosh Saw Mill Android App

An Android WebView app for sawmill log CFT and cutting-charge calculations, with on-device offline photo text recognition.

## Offline features
- Manual entry of log length and girth.
- Multiple log rows and total CFT / cutting charge calculations.
- Default rate ₹55 per CFT (editable).
- Select or take a measurement-sheet photo.
- On-device Latin text recognition using the bundled Google ML Kit Text Recognition model. The photo is processed on the phone; it is not uploaded to a server.
- Basic automatic extraction for rows written like `12-6 x 2-4` or `12'6" x 2'4"`.
- Recognised text and extracted values can be checked and corrected before calculating.
- Print / Save PDF through the Android print service.

## Important OCR limitation
This is offline OCR, not a handwriting-understanding AI. It works best with clear, high-contrast, well-lit digits and measurements. Handwritten digits, tilted pages, table columns, and unusual notation may be misread or may not be automatically paired. Always verify every extracted measurement before relying on the bill. The calculator remains usable offline even if OCR cannot parse a row.

## Build
Requirements: JDK 17, Android SDK Platform 35 / Build Tools 35.0.0, and Gradle 8.9.

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

The project includes a GitHub Actions workflow for building a debug APK online. Push the project files to a GitHub repository and run the workflow from the Actions tab.
