# Wordwood

**Every word unlocks a new world.**

A mobile-friendly word-clue puzzle game with a classic wood-and-parchment look.

## Game modes
- **Level Mode:** 100 handcrafted levels across 10 chapters.
- **Endless:** 40 bundled food and cooking puzzles, plus optional online general-knowledge questions.
- **Loop:** 40 bundled nature and weather puzzles, plus optional online science questions.
- **Mystery:** 40 bundled art and music puzzles, plus optional online art questions.

The three challenge modes have separate question banks and avoid repeating an answer until the relevant bank is exhausted. There are 220 unique bundled puzzles; optional online refresh adds single-word answers from category-specific requests. The game remains playable offline. No memes are included.

## Online questions and attribution
The **Refresh Online Questions** button uses the Open Trivia Database API when an internet connection is available. Only single-word answers that do not already appear in any question bank are added. Online questions are cached on the device. Open Trivia Database content is licensed under Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0); see https://opentdb.com/api_config.php. Online refresh can fail due to connectivity or API rate limits; the bundled question banks remain available.

## Run in a browser
Open `index.html` in a modern browser. The game saves level progress and online questions in local storage. The optional reward-ad panel is a demo placeholder; it does not play a real advertisement.

## Android packaging
This ZIP contains a web game, not a compiled APK. Use a trusted HTML-to-APK/WebView builder that accepts a ZIP or `index.html`. If the builder expects `index.html` at the archive root, this ZIP is arranged that way. Online refresh requires the wrapper to allow internet access.
