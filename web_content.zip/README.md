# ROBLOX RANDOM — proyecto Android

Incluye los 100 juegos enviados, selector aleatorio, evita repetir el último resultado, filtros por categoría, búsqueda y misión sugerida.

## Cómo generar el APK
1. Instala Android Studio en una computadora.
2. Descomprime `RobloxRandomAndroid.zip`.
3. En Android Studio elige **Open** y selecciona la carpeta `RobloxRandomAndroid`.
4. Espera a que termine la sincronización de Gradle.
5. Ve a **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio generará el APK; usa **locate** en la notificación para encontrarlo.

## Requisitos
- Android Studio reciente
- JDK 17
- Conexión a internet durante la primera sincronización de Gradle

La aplicación funciona sin conexión después de instalarse. No es una aplicación oficial de Roblox y no inicia los juegos automáticamente.
