# GhostConn Monitor — no-account APK builder edition

This version is a self-contained offline web application intended for no-code/no-account
web-to-APK builders that accept a ZIP containing an `index.html` web app.

Important:
- A browser/web APK cannot access all Android hardware telemetry available to a native
  Kotlin app. CPU temperature and low-level CPU usage are therefore best-effort and may
  be unavailable.
- The app itself requires no Internet and has no remote services.
- The interface is designed to remain useful when packaged as an Android WebView/PWA.

Upload the contents of this ZIP (or the ZIP itself) to a builder that accepts static web
apps and produces an APK. The entry point is `www/index.html`.
