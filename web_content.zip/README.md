# Endcord 8.0 — Publishable full-stack starter

Endcord is now a real client/server application rather than a local-only demo.

## Included
- Node.js HTTP backend + WebSocket realtime events
- Persistent server-side JSON database in `data/db.json`
- Secure password hashing with Node `scrypt`
- Session tokens with expiry
- Registration/login/logout/profile/password change
- Owner/member roles and server permissions
- Server + channel creation
- Text and voice-channel UI
- Realtime message delivery over WebSocket
- Message edit/delete/reply
- Search, reactions, member list, notifications/friends UI
- Reports, audit log, owner admin center
- Server invites
- Responsive mobile/desktop UI
- Health endpoint

## Run locally
1. Install Node.js 20+.
2. Copy `.env.example` to `.env` and set a strong `OWNER_PASSWORD`.
3. Install dependencies: `npm install`
4. Start: `npm start`
5. Open `http://localhost:3000`

## Important before public launch
This is a substantial self-hostable foundation, not a claim that it contains every proprietary Discord feature. A production service still needs HTTPS, reverse proxy, backups, rate limiting/WAF, email verification/password reset, CSRF strategy, upload scanning/object storage, database migrations, abuse prevention, moderation tooling, privacy/legal pages, monitoring, TURN for reliable voice/video behind restrictive NATs, and a real database for large scale.

Do not publish a default password. Set `OWNER_PASSWORD` in the deployment environment. The password is never shipped in the browser.
