God's Gift Campus Quest V12 — Reference Match

This version uses the supplied visual references for the home/character-selection presentation and a cut-out rear-view runner sprite for the actual forward runner. During play the camera is behind the student; obstacles, stars, coins and growth books are ahead on the road. Books show Determination, Resilience, Discipline and Courage. Music starts after Select & Run.

Offline single-file build: open index.html.
