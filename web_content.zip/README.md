# Boss JARVIS Android project

This wraps the supplied JARVIS HTML demo in an Android WebView.

## Build APK in GitHub Actions
1. Create a new GitHub repository and upload the contents of this ZIP.
2. Open the repository's Actions tab.
3. Run **Build JARVIS APK** (or push to `main`).
4. Download the `JARVIS-debug-APK` artifact from the completed workflow.
5. Inside it, install `app-debug.apk` on your Android phone.

Notes:
- Microphone permission is requested by Android.
- Speech recognition availability depends on the browser/WebView and installed speech services.
- The HTML demo's OpenAI API-key field still requires a valid API key; an existing ChatGPT account does not automatically provide API API access.
- This is a debug APK, not a Play Store release build.
