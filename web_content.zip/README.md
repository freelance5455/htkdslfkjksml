# Study Quest — نسخه حرفه‌ای + زرین‌پال

این نسخه ظاهر برنامه را حرفه‌ای‌تر کرده و بخش Premium را به یک backend برای زرین‌پال وصل می‌کند.

## نکته مهم
فقط تبدیل HTML به APK برای پرداخت واقعی کافی نیست. Backend باید روی یک سرور HTTPS اجرا شود و APK/HTML به آن وصل شود. Merchant ID داخل APK قرار نمی‌گیرد.

### راه‌اندازی backend
1. Node.js روی سرور نصب باشد.
2. `npm install`
3. `.env.example` را به `.env` تغییر بده.
4. Merchant ID خودت را در `ZARINPAL_MERCHANT_ID` قرار بده.
5. `BASE_URL` را آدرس HTTPS واقعی سرور قرار بده.
6. `npm start`

مبلغ نمونه ۹۹٬۰۰۰ تومان است و از `PREMIUM_AMOUNT_RIAL` قابل تغییر است.

API v4 مورد استفاده:
- درخواست: https://api.zarinpal.com/pg/v4/payment/request.json
- تأیید: https://api.zarinpal.com/pg/v4/payment/verify.json

برای محیط واقعی بهتر است سفارش‌ها در دیتابیس ذخیره شوند و بعد از Verify، Premium برای حساب همان کاربر فعال شود.
