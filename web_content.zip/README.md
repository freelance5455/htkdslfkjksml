# Grade 10 Study Planner — PWA

This folder contains the Progressive Web App (PWA) version of the clickable Grade 10 study planner.

## Included
- `index.html` — the planner
- `manifest.webmanifest` — install metadata
- `sw.js` — service worker for offline caching after the first successful load
- `icons/` — app icons

## Install it on Android
1. Put this entire folder on an HTTPS website (for example, a static hosting service) or run it on `localhost`.
2. Open the website in Chrome on your Android phone.
3. Let the planner load once while online so the service worker can cache it.
4. Open Chrome's menu (⋮) and choose **Install app** or **Add to Home screen**. The exact wording depends on Chrome version.
5. Open it from the new home-screen icon. It should work offline after the initial successful load.

## Important
- A PWA cannot be installed reliably by opening `index.html` directly from your phone's file manager. Service workers generally require HTTPS or localhost.
- This is a web app, not an APK. It does not need an app store.
- Progress persistence depends on the browser storage used by the original planner; keep using the same installed app/browser profile.
