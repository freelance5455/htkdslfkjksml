# TMoo Messenger

MVP funcional de mensageria para navegador móvel, com frontend HTML/CSS/JS, API PHP e armazenamento JSON. Projeto original e independente; não usa código ou serviços internos do WhatsApp.

## O que funciona nesta versão
- Cadastro e login com `password_hash` / `password_verify` e sessão PHP.
- Lista de usuários cadastrados e conversas privadas.
- Envio/recebimento real de mensagens no servidor, com atualização periódica (polling).
- Histórico persistido em `database/data.json`.
- Layout responsivo para Android e alternância de tema.
- API valida destinatário, tamanho e sessão antes de permitir leitura/envio.

## Limitações honestas
Esta é uma primeira versão utilizável, não uma cópia completa de todos os recursos pedidos. Ainda não implementa anexos, voz, status, comunidades, bloqueio, recibos reais de entrega/leitura, push notifications, indicador de digitação, WebSocket, redefinição de senha nem criptografia ponta a ponta. A marcação ✓ é apenas confirmação de que a mensagem foi gravada no servidor. Para produção, migre o JSON para MySQL, adicione CSRF/rate limiting, política de retenção, auditoria, backups, validação MIME e armazenamento isolado de uploads.

## Requisitos
- PHP 8.1+ com extensão `mbstring` recomendada.
- Servidor PHP/Apache/Nginx. Para uso público, HTTPS obrigatório.
- Para versão JSON, não é necessário instalar MySQL.

## Testar no computador
1. Extraia o ZIP.
2. Abra um terminal dentro da pasta do projeto.
3. Execute: `php -S 0.0.0.0:8080`
4. Abra `http://127.0.0.1:8080` no navegador.
5. Crie duas contas usando e-mails diferentes em dois navegadores/dispositivos e envie mensagens entre elas.

## Testar no Android
1. Hospede a pasta em um servidor com PHP; ou execute PHP em um ambiente Android que você já tenha configurado.
2. O telefone e o servidor precisam estar acessíveis pela rede. No teste local em computador, use `http://IP-DO-COMPUTADOR:8080` no navegador do celular, na mesma rede Wi-Fi.
3. Para acesso pela internet, configure domínio, HTTPS e servidor público. Não exponha um servidor de desenvolvimento sem proteção.
4. No navegador Android, use “Adicionar à tela inicial” para um atalho tipo app.

## Converter para APK
O caminho mais simples é criar um projeto Android no Android Studio com uma `WebView` apontando para a URL HTTPS hospedada. Habilite JavaScript apenas para esse conteúdo confiável e implemente tratamento de navegação e permissões conforme necessário. Um APK que aponta para localhost do computador não funcionará fora dessa rede. Alternativamente, use Capacitor, mantendo o backend PHP hospedado separadamente.

## API
Todas as respostas são JSON. As rotas ficam em `api/index.php?action=...`:
- `POST ?action=register` — `{ "name":"Nome", "email":"email@exemplo.com", "password":"mínimo 8 caracteres" }`
- `POST ?action=login` — `{ "email":"...", "password":"..." }`
- `POST ?action=logout`
- `GET ?action=me` — usuário autenticado
- `GET ?action=contacts` — lista de outros usuários
- `GET ?action=messages&with=ID_DO_USUARIO` — histórico de uma conversa privada
- `POST ?action=send` — `{ "to":"ID_DO_USUARIO", "text":"Olá" }`

As rotas privadas usam cookie de sessão. O frontend envia `credentials: same-origin`.

## Segurança e implantação
- Configure HTTPS antes de usar na internet e configure cookies `Secure`, `HttpOnly` e `SameSite`.
- Mantenha `database/` fora da raiz pública quando possível. Se não for possível, aplique as regras do servidor para bloquear acesso direto ao JSON.
- Use usuário de sistema com permissões mínimas e faça backups.
- Adicione limitação de tentativas de login e proteção CSRF antes de uso público.
- Não inclua credenciais reais em arquivos enviados.
