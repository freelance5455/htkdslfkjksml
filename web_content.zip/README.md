# AMAZON GAZA — Amazon-grade Gaza Marketplace V2 Secure

This build moves AMAZON GAZA toward a publishable architecture rather than a static preview.

## Included
- Next.js white marketplace UI
- PostgreSQL schema + rich seed data
- multi-vendor catalog/listings/SKU/stock
- FBN/FBM foundations
- Gaza governorates/districts/GPS delivery zones
- carts/orders/sub-orders/commission/payout ledger
- customer/seller/driver/admin roles
- strict Founder Control Center
- fluorescent `إدارة المؤسس` entry
- internet-only gate + API health monitoring
- Helmet/CORS/rate limiting/JWT/bcrypt/scrypt Founder auth
- audit logs
- Leaflet + OpenStreetMap mapping
- real server-side Gemini AI adapter

## Founder security
The requested Founder password is not written in plaintext anywhere in the frontend. A derived scrypt hash is placed in `.env.example` only so the server can verify it without exposing the password itself. For production, rotate the salt/hash and store them in a secret manager.

## Start
API:
1. `cd apps/api`
2. `cp .env.example .env`
3. Set a strong JWT_SECRET and GEMINI_API_KEY.
4. Create PostgreSQL database and run `database/schema.sql` then `database/seed.sql`.
5. `npm install && npm start`

Web:
1. `cd apps/web`
2. `npm install`
3. Set `NEXT_PUBLIC_API_URL` to the API URL.
4. `npm run dev`

## Important production limitations
Real Jawwal Pay/Paltel Pay payment execution, SMS OTP, Cloudinary/S3, push notifications and production-scale maps require official provider credentials/configuration. The project intentionally does not invent provider endpoints or embed secret keys.
