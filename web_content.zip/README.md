# ट्रैक्टर हिसाब — Kotlin Android Project

यह प्रोजेक्ट आपकी दी हुई `Tractor_Hisab_FINAL_Payment_Diesel_PDF(2).html` फाइल को
एक Kotlin + Android WebView ऐप में पैक करता है।

मुख्य बात:
- HTML फाइल स्थानीय `assets/index.html` में रखी गई है।
- ऐप ऑफलाइन HTML को खोलता है।
- JavaScript और localStorage सक्षम हैं।
- मौजूदा HTML के Payment, Diesel, PDF और अन्य फीचर उसी फाइल से चलते हैं।
- PDF डाउनलोड के लिए Android DownloadManager भी जोड़ा गया है।

Android Studio में इस फ़ोल्डर को खोलकर Gradle sync करें और APK build करें।
