# Báo cáo công việc hàng ngày V2

Android WebView wrapper, đã bỏ mục "Đưa ra màn hình chính".
Giao diện và logic nằm tại app/src/main/assets/index.html.

Thông số:
- applicationId: com.baocaocongviec.v2
- minSdk 26
- targetSdk / compileSdk 35
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21

Mở thư mục bằng Android Studio, Sync Gradle, sau đó Build > Build APK(s).
Dữ liệu HTML dùng localStorage; WebView đã bật DOM Storage/database để giữ dữ liệu trong app.
