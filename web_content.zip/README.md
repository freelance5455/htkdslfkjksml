MEMORIX 2050 — v5 FINAL

ANDROID WEBVIEW-SAFE BUILD

IMPORTANT:
This package intentionally contains BOTH:
  1) /index.html
  2) /web/index.html

Different HTML-to-APK builders look for different locations. The duplicate entry point prevents the Android app from failing with:
appassets.androidplatform.net/web/index.html
net::ERR_HTTP_RESPONSE_CODE_FAILURE

No CDN, module import, service worker, manifest, or remote dependency is required to boot the app.

Features:
- Offline-first mistake vault
- Durable IndexedDB save queue + localStorage fallback
- v4 data migration / normalization
- Photo: Camera + Gallery
- On-device image compression
- Voice recording when WebView exposes microphone permission
- Audio file fallback when recording is unavailable
- Spaced-repetition review system
- Analytics, search, backup/export
- New MEMORIX 2050 app icon

DATA SAFETY:
The app uses the existing MEMORIX database name so prior local mistakes can continue to migrate when the APK uses the same WebView storage profile.

APK BUILDER:
Use the package as-is. Do not rename or remove the /web/ folder.
If the builder has a choice between online/remote URL and local HTML, choose the local HTML/project option.
