# SON OF MOM MARKET — Android Source Code

## Kufungua
Fungua folder hii kwa Android Studio.

## Kujenga APK
1. Sync Gradle.
2. Build > Build Bundle(s) / APK(s) > Build APK(s).
3. APK itapatikana kwenye `app/build/outputs/apk/debug/`.

## Muhimu
- Badilisha namba ya WhatsApp kwenye `app/src/main/assets/index.html` kutoka `255000000000` kwenda namba yako halisi.
- Bidhaa za mfano na bei ziko kwenye HTML; baadaye zinaweza kuhamishwa kwenda backend/database kwa admin system.
