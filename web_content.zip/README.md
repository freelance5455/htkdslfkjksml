# O CAMINHO DO PODER — As 48 Leis do Poder

RPG político 2D de mundo aberto (top-down, pixel art) em que você sobe da Vila de
Cinzas até o Salão do Trono usando as 48 Leis do Poder de Robert Greene como
**mecânicas jogáveis** — não como texto decorativo.

* **48 missões**, uma por lei, cada uma com dilemas próprios, escolhas múltiplas
  e consequências que mudam o reino.
* **5 atributos**: Influência, Reputação, Inteligência, Riqueza e Poder Político.
* **Relacionamentos vivos**: cada NPC tem Confiança, Respeito, Medo, Lealdade e
  Ambição, e **lembra** do que você fez (as memórias aparecem no painel de relações).
* **6 finais** dependentes das suas escolhas (Rei, Conselheiro, Poder Sombra, Nobre,
  Dinastia, Ruína).
* Save/load local, ranking de melhores jornadas, pausa, game over com reinício
  instantâneo.
* Controles de teclado **e** toque (joystick virtual), layout responsivo.
* Interface, missões e narração **100% em português do Brasil**.

---

## Como jogar

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # gera dist/ (um único index.html, ~440 KB)
```

| Ação | Teclado | Toque |
|---|---|---|
| Andar | WASD / setas | joystick virtual (canto inferior esquerdo) |
| Conversar | `E` ou `Espaço` | botão `E` |
| Inventário | `I` | botão `I` |
| Relações | `R` | botão `R` |
| Diário das 48 Leis | `J` | botão `J` |
| Mapa do reino | `M` | botão `M` |
| Pausa | `Esc` | botão `❚❚` |
| Escolher diálogo | `1`–`9` | tocar na opção |

Durante um diálogo, `Espaço` pula a digitação do texto.

---

## Estrutura

```
src/
├── App.tsx                  laço do jogo, input, fluxo das missões, câmera
├── components/              HUD, diálogo, painéis (inventário/relações/diário/mapa),
│                            telas (início/pausa/final), controles de toque
└── game/
    ├── data/
    │   ├── areas.ts         18 áreas com mapa de tiles, props, luz e portais
    │   ├── laws.ts          as 48 leis (título + sabedoria)
    │   ├── missions*.ts     as 48 missões (árvores de diálogo e consequências)
    │   ├── npcs.ts          31 NPCs com personalidade e relações iniciais
    │   └── items.ts         inventário
    ├── art.ts               geração procedural de pixel art (tiles, sprites, retratos)
    ├── render.ts            renderizador do cenário, iluminação e partículas
    ├── engine.ts            regras: efeitos, missões, finais, save/load
    └── audio.ts             trilha e efeitos sonoros sintetizados (WebAudio)
```

## Testes

```bash
npm run build
node scripts/test.mjs            # 37 verificações de lógica (dados, progressão, save/load, finais)
node scripts/gameplay-test.mjs   # 45 verificações em navegador real (Chromium headless)
node scripts/apk-test.mjs        # valida o jogo empacotado dentro do APK
node scripts/perf-test.mjs       # mede FPS com CPU estrangulada (4x / 6x)
```

## Android

Veja **[ANDROID.md](ANDROID.md)**. Resumo:

```bash
export ANDROID_HOME=$HOME/android-sdk
./android/build-apk.sh       # → apk/O-Caminho-do-Poder-1.0.0.apk
```

O APK é gerado sem Gradle (aapt2 + d8 + apksigner), sem dependências externas e
sem internet, e já vem assinado e pronto para instalar.
