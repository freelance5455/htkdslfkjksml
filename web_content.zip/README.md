# CollegeLife v1

A mobile-first, completely free prototype for managing college life.

Open `index.html` in a browser. Data is stored locally in the browser using localStorage.

Included:
- Home dashboard
- Calendar with Present/Absent and date-specific important notes
- Attendance by subject
- Custom subjects
- Timetable
- Notes with search and subject filters
- Exam planner with syllabus progress
- Useful tools: calculator and Pomodoro
- College profile

Next design/build passes can add: full offline PWA install, richer note editor, PDF/image notes, notifications, backup/export, recurring timetable, holidays/events, attendance forecasts, and a more premium visual system.
