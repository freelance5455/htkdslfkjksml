# Velora — Luxury Food App

Premium dark/gold food-ordering UI built with React + Vite.

## Run
1. Install Node.js
2. Open this folder in a terminal
3. Run `npm install`
4. Run `npm run dev`
5. Open the local URL shown by Vite.

## Included
- Luxury black/gold responsive design
- Hero section
- Search
- Category filters
- Food cards
- Favorites
- Cart quantity controls
- Floating checkout bar
- Mobile responsive layout

This is a front-end demo. Real payments, database, authentication, restaurant admin and delivery APIs are not connected yet.
