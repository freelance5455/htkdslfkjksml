# MasterFlow Trading — Public Data Mode

Versi ini memakai sumber publik berkala untuk saham IDX melalui backend. Data diberi label DELAYED/PUBLIC dan **bukan realtime resmi IDX**.

Sumber resmi IDX menyatakan data real-time/delayed didistribusikan sebagai produk berlisensi; karena itu versi gratis ini tidak mengklaim realtime resmi.

Refresh default: 5 menit. Jika sumber publik gagal, aplikasi tidak mengarang harga dan kembali ke mode demo.


## Public multi-market sources
- IDX: GOAPI (delay 3–10 minutes per documentation) when backend key is configured; Yahoo fallback.
- US/global: Alpha Vantage when backend key is configured; Yahoo fallback.
- Data freshness is always shown/treated as public-delayed unless a licensed realtime feed is explicitly configured.
- Provider secrets never belong in the APK.
