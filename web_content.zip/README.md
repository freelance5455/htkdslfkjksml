# LEVEL LIFE — APK Builder Project

This is the web/React version prepared specifically for APK builders that validate for a root `package.json`.

## Build
- `npm install`
- `npm run build`

The production files are generated in `dist/`.

## Important
This APK-builder-compatible version is a web app wrapped by the builder. A web app cannot read Instagram/YouTube/Netflix usage from the Android OS by itself. The current version therefore keeps local progress, missions, XP, streak and focus timer on-device and does not claim OS-level usage access.
