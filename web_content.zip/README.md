# معركة طوبة ورقة مقص (تطبيق)

## تشغيله كتطبيق بدون نت (PWA)
1. ارفع محتوى مجلد www على أي استضافة HTTPS مجانية (GitHub Pages / Netlify / Cloudflare Pages).
2. افتح الرابط من Chrome على الأندرويد > القائمة > "تثبيت التطبيق". على الآيفون: Safari > مشاركة > "إضافة إلى الشاشة الرئيسية".
3. بعد أول فتح يشتغل اللعب الفردي ولعب لاعبين بنفس الهاتف بدون نت.

## ملف APK حقيقي (أندرويد)
محتاج Node.js و Android Studio على الكمبيوتر:
    npm install
    npx cap add android
    npx cap sync
    npx cap open android      # ثم Build > Build APK
للنشر على Google Play محتاج حساب مطوّر.
