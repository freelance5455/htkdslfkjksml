# YPE Expiry Tracker – Android 8+

This build includes a premium offline-first expiry tracker UI with:
- Android 8.0+ compatibility
- Native reminder scheduling and reboot rescheduling
- 5-language UI: English, Arabic, Chinese, Hindi, Spanish
- Dark/light theme
- Home, Items, About Us, Settings navigation
- Urgent (1–7 days), Risky (8–29 days), Safe (30+ days) zone filtering
- 300+ daily-life item mappings with bundled premium packshot-style SVG visuals
- No calendar
- No preset category popup; category is free-form
- Offline/local storage

The bundled item visuals are designed as polished, product-style packshots inspired by the supplied visual reference. They are not trademarked manufacturer photographs and do not require internet access.


## v2.0.7 UI
The Home dashboard now follows the supplied premium YPE reference style: dark purple dashboard, four status cards, prominent Expiring Soon rows, realistic bundled item art, and a compact sun/moon theme control. Existing About Us bottom navigation, zone filtering, save flow, notifications, and 5-language UI are preserved.
