# Tourist Dashboard v4 - Android "Save as" build

Why earlier APKs could not save: your online converter's WebView has no save function (log: AndroidBridge / Capacitor / Web Share all missing),
so NO HTML change can save files there. This project is a small native wrapper that opens the Android "Save as" dialog.
It is NOT a built APK and the Java is not compiled/tested by me. Two ways to build it:

## A. Cloud build (no Android Studio) - needs a computer browser
1. Create a free GitHub repo. Upload ALL files/folders of this project (drag the folder contents, incl. hidden `.github`) to the repo root.
2. Repo > Actions > "Build APK" > Run workflow (it also runs on push).
3. When green, open the run > Artifacts > tourist-dashboard-apk > download, unzip, install app-debug.apk on the phone (allow unknown sources).
If the run fails, send me the red error text.

## B. Android Studio
Open this folder, let Gradle sync, Build > Build APK(s).

## Test in the app (Delivery = auto)
1. `test_save_txt` -> the Android Save-as screen should appear -> choose a folder -> "Saved" toast.
2. Then PDF / Excel / backup buttons the same way. Log line "generated ... header %PDF / PK" proves the file was created.
Delivery list lets you test each path: androidSaveAs (dialog), androidDirect (straight to Downloads), dataUri, anchor, share, capFilesystem.
CDN buttons need internet (or files in app/src/main/assets/www/lib/).
