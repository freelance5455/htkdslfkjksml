# StreetRush 3D — Complete Mobile Game Project

Original browser-based racing game project designed as a foundation for an Android APK.

## Included
- Mobile touch controls
- Keyboard controls for testing
- 3D-style perspective highway
- Traffic obstacles
- Nitro boost
- Coins
- Score and distance
- Multiple unlockable cars
- Career-style race progression
- Day/night cycle
- Local save data
- Pause/restart
- Original vector-style visuals made with Canvas
- No third-party copyrighted game assets

## Important
This is a complete playable web-game project, but it is NOT itself an APK/AAB.
An Android build step is still required to package it for installation and Google Play.
