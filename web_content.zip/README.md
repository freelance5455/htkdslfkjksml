# ZYRUU — Android APK project

## What is included
- `www/index.html`: ZYRUU pink-and-white music discovery player.
- `capacitor.config.json`: Android package name `com.zyruu.music`.
- GitHub Actions workflow: builds a debug APK in the cloud.

## Build an APK using only your phone
1. Create a private or public GitHub repository named `zyruu`.
2. Upload the contents of this folder (make sure `.github/workflows/android-apk.yml` is included).
3. Open the repository's **Actions** tab.
4. Select **Build ZYRUU Android APK**, tap **Run workflow**, and wait for the run to finish.
5. Open the completed run and download the artifact named **ZYRUU-debug-apk**.
6. Extract the artifact ZIP to find `app-debug.apk`, then tap it to install.
7. Android may ask you to allow your browser or file manager to install unknown apps. Only allow this for the APK you built from your own repository.

## Important
- This is a debug APK for personal testing, not a Play Store-signed release.
- The Jamendo API client ID in the HTML is marked TEST ONLY. Replace it with your own ID before relying on the catalog.
- Online streaming needs internet. Jamendo catalog availability and track licenses vary.
- If GitHub Actions fails, open the failed run's log and share the first red error line for troubleshooting.
