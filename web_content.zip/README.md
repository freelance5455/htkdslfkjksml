# আল-ইনসাফ V7

Netlify-ready mobile management app. V7 uses Firebase Compat scripts to avoid mobile Chrome ES-module loading issues.

Firebase Project: al-insaf-460a5
Authorized domain: cheery-clafoutis-40c79c.netlify.app

Deploy the ZIP from its root. Firebase Firestore Rules are included in `firestore.rules`.
