# Friendship — WebView-ready starter

This ZIP contains a root `index.html` suitable as a starting point for HTML-to-APK WebView builders.

## Included now
- Supabase email sign-up and login
- Profile display/edit
- User search and follow
- Direct conversation creation using the existing `create_direct_conversation` RPC
- Realtime text messages (requires the relevant Supabase Realtime publication and RLS policies)
- Public moment feed and text post creation
- Public voice-room listing and creation
- LiveKit token request through the deployed Supabase Edge Function, and basic room connection/microphone controls

## Configuration
`config.js` contains the project's Supabase URL, publishable key, LiveKit WebSocket URL, and the current deployed Edge Function slug (`quick-task`). The function slug is based on the endpoint shown in the project dashboard. If you later rename/redeploy the function with a different slug, update `livekitTokenFunction`.

Only public client configuration is included. **Never add the Supabase service-role key, database password, or LiveKit API Secret to this ZIP.**

## Important limitations
This is an initial functional frontend, not a production-ready full social platform. Photo/video uploads, video calling, room speaker-seat moderation, gifts/wallet transactions, Ludo gameplay, push notifications, blocking/reporting, admin tools, and production security review are not implemented yet. Existing database policies and RPCs should be tested with separate user accounts before public launch. The current voice-room screen provides basic LiveKit connection and microphone enable/leave controls; it does not yet implement seat management or video calling.

## Run locally
Serve this folder over HTTP (not `file://`) or upload it to a static web host. The app requires internet access for Supabase, LiveKit, and CDN libraries.

## HTML-to-APK Builder
Import the ZIP if your builder supports a ZIP with `index.html` at the root. Enable internet access and microphone permission in the builder/WebView. Builder-specific settings may vary, so verify its import options before producing the APK.
