# Cow Health Care - Android Project

This project packages the supplied HTML/CSS/JavaScript Cow Health Care website into an Android WebView app.

## Build APK
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select `app` -> `Build` -> `Build APK(s)`.
4. The debug APK will be generated under:
   `app/build/outputs/apk/debug/app-debug.apk`

## Install on Android
Copy `app-debug.apk` to your phone and install it. If Android asks, allow installation from the source you used to open the APK.

## Notes
- The original website files are in `app/src/main/assets/`.
- JavaScript and DOM storage are enabled.
- Android back button navigates the web app history when possible.
- If the website depends on online APIs (for example EmailJS), Internet permission is enabled.

## Latest fixes
- Fixed Android WebView image/file selection for Add Cow photo upload.
- Farmer Dashboard and Add Cow form translated to Marathi.
- Photo picker rewritten with the AndroidX Activity Result API (with fallbacks) so "गाय जोडा" opens the gallery; the picker callback is always answered so the button never freezes.
- Screen rotation no longer reloads the WebView while the picker is open.
- Add Cow: shows a message if a photo can't be read or storage is full; a previous cow's photo is no longer reused.
