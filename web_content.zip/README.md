# JARVIS AI — HTML app for APK converters

This ZIP is a **single-file HTML app**, with `index.html` at the ZIP root. Extract the ZIP and select `index.html` as the starting page in your HTML/WebView-to-APK converter.

## Features

- Mobile-first JARVIS chat UI with dark/light themes
- Optional browser speech input and spoken replies (depends on browser/WebView support)
- YouTube search, Google web search, Instagram open, WhatsApp draft, and phone dialer handoff
- Settings for backend URL, Gemini model, and English/Hindi voice language
- Chat is kept in memory only; settings are saved on the device

## Connect Gemini chat

The HTML file **does not contain a Gemini API key**. To use AI chat, configure a backend URL in Settings. It must be a publicly reachable HTTPS API base URL ending in `/api` and support:

- `GET /healthz`
- `POST /jarvis/chat` with `{ "message", "history", "model" }`
- JSON CORS access from the app/WebView origin

The Gemini key belongs in a server secret/environment variable such as `GEMINI_API_KEY`, never in `index.html` or the APK. This Replit project has a development API route, but it is not a stable public service URL. Do not expose a public Gemini proxy without authentication and abuse controls.

## Converter notes

- Keep `index.html` at the root of the extracted app files.
- Enable JavaScript and Internet access in the converter.
- For external links, allow the WebView/wrapper to open HTTPS pages, `tel:` links, and WhatsApp links.
- Speech recognition may not be available in a WebView even if it works in Chrome. Text chat remains available.
- This is an HTML app, not a native Android app. A webpage cannot read Android contacts or system notifications. Phone calls open the dialer for the user to confirm; WhatsApp messages open as drafts and are never sent automatically.

The HTML app can be previewed and used for local quick actions without an AI server. Gemini chat requires the HTTPS backend described above.
