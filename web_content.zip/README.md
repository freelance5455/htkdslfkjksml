# معاون نمونه — Android
این پروژه نسخه اندروید اپلیکیشن مدیریت معاون آموزشی است و رابط کامل HTML موجود را داخل WebView اجرا می‌کند.

## ساخت APK با Codemagic
پروژه را در GitHub قرار دهید، سپس در Codemagic به عنوان Android project اضافه کنید. فایل codemagic.yaml به‌صورت خودکار workflow ساخت APK دیباگ را تعریف می‌کند.

برای انتشار نهایی، build release و signing باید تنظیم شود.
