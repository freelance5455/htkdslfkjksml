# סורק קריפטו AI · Crypto Scanner, AI Trading & Financial Hub

אפליקציית Next.js (App Router) + PostgreSQL/Drizzle עם ממשק עברי מלא ו-RTL, מנוע אינדיקטורים דינמי,
מסחר דמו, חיקוי סוחרים, ספר פקודות בזמן אמת, מפת חום, מחקר יסודי ומרכז מיסוי ישראלי.

## ארכיטקטורה

```
src/
  app/
    page.tsx                 מעטפת האפליקציה: 7 טאבים, תג בריאות חיבור, פס טיקרים, התראות
    layout.tsx               RTL + ערכת נושא כהה + אייקון האפליקציה
    api/
      health/                Heartbeat (10-15 שניות) + סטטוס מקור השוק
      market-proxy/          פרוקסי REST אחיד (רשימת דומיינים מאושרת) לנטרול CORS
      market/overview        טיקרים + מדד פחד/חמדנות + נתוני מאקרו
      market/klines          נרות עם Failover
      market/depth           ספר פקודות + סרט עסקאות (גיבוי ל-WebSocket)
      signals/               GET סריקה מרוענת, POST סריקה ידנית (handleManualScan)
      analysis/              ניתוח עומק למטבע בודד
      paper/ , paper/order   מנוע מסחר דמו: מרקט/לימיט, SL/TP, חיסול, היסטוריה
      copy/                  לוח מובילים, עקוב ושכפל, בקרות סיכון, סנכרון
      evaluator/             סוכן בקרה עצמי (Evaluator-Optimizer) + יומן אבחונים
      research/              מחקר יסודי בסגנון Messari + סיכום AI
      finance/               ספר רווח/הפסד, חשבוניות USDT/ILS, חבות מס ישראלית
      notifications/         רישום טוקן Expo Push + יומן התראות
  lib/
    indicators.ts            RSI(14), MACD(12,26,9), EMA(20/50/200), ATR(14), ADX, Volume Profile, דיברגנס
    signals.ts               מנוע קונפלואנס, יעדי כניסה/SL/TP, מינוף לפי ATR, Kelly Criterion
    market.ts                שכבת נתונים עם Failover: Bybit V5 → Binance → Binance Data → MEXC → CoinGecko
    universe.ts              יקום מטבעות + סיווג סקטורים למפת החום
    client/useApi.ts         הוק אחזור עמיד + פולינג רקע
    client/useConnectionHealth.ts  דופק כל 12 שניות, חיבור מחדש לאחר 3 כשלונות
    client/tradeTapeService.ts     WebSocket של Bybit + נפילה חכמה לפולינג REST
    client/notificationsService.ts התראות דפדפן + רישום Expo Push Token
  server/
    engine.ts                סריקה, מנוע דמו, מנוע חיקוי, סוכן הבקרה האדפטיבי
    store.ts                 זריעת נתונים, כללי מנוע מתכווננים, שירות התראות
  components/                ErrorBoundary, Toast, רכיבי UI ומסכים
```

## הגנה מפני מסך ריק
- `ErrorBoundary` עוטף את השורש ואת כל מסך בנפרד.
- כל אחזור נתונים מחזיר מצב בטוח (`Array.isArray(x) ? x : []`, `data?.field`, ערכי ברירת מחדל).
- שלדי טעינה ("טוען נתונים...") וכרטיסי שגיאה עם כפתור "לחץ לנסות שוב" בכל מסך.

## בניית APK לאנדרואיד
```bash
npm i -g eas-cli
eas login
eas build -p android --profile preview   # buildType: apk, package: com.crypto.scanner
```
`app.json` מוגדר עם `./assets/images/crypto_app_icon.png`, הרשאות (INTERNET, POST_NOTIFICATIONS ועוד)
ו-`expo-notifications`. באפליקציית Expo יש לקרוא ל-`registerPushToken()` עם הטוקן מ-
`Notifications.getExpoPushTokenAsync()` והשרת ישלח פושים דרך `exp.host`.

## מסד נתונים
```bash
npx drizzle-kit push
```

## תצוגה מקדימה של Vite / React (index.html)
בשורש הפרויקט קיים `index.html` עם `<html lang="he" dir="rtl">`, מטא-תגים תקניים,
`<div id="root"></div>` וטעינת `<script type="module" src="/src/main.tsx">`.

```
index.html          נקודת הכניסה של Vite + שלד טעינה ("טוען נתונים...") ומסך גיבוי לשגיאת bootstrap
src/main.tsx        createRoot בטוח: יוצר #root אם חסר, StrictMode, fallback עברי במקרה כשל
src/App.tsx         רכיב השורש - עוטף את לוח המחוונים ב-ErrorBoundary
vite.config.mjs     React + Tailwind v4 + alias @ ל-src + proxy של /api לשרת ה-Next (פורט 3000)
```

הרצה מקומית (שני תהליכים):
```bash
npm run start      # שרת ה-API של Next.js על פורט 3000
npx vite           # תצוגת React על פורט 5173 (כל /api מנותב ל-3000)
npx vite build     # בנייה סטטית לתיקיית dist
```
שים לב: אפליקציית הייצור מוגשת על ידי Next.js (`npm run build && npm run start`);
`index.html` נועד לתצוגה מקדימה של Vite/React ואינו משפיע על בניית Next.
