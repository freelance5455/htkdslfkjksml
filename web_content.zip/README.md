# BOLO SERVICE — Cloudflare Final

Final Cloudflare Pages package for BOLO SERVICE.

## Included
- Responsive BOLO SERVICE website
- Customer booking form
- Customer panel / booking tracking
- Technician panel
- Admin panel
- Supabase Auth (email + password)
- Supabase database booking save
- 18-service database-backed service list
- Admin-only service management (RLS protected)
- Booking statuses: New, Assigned, On Way, In Progress, Completed, Cancelled
- 5% BOLO commission fields in database
- ₹199 technician subscription table in database
- WhatsApp booking button to +91 7860493175
- Browser voice input support where supported by the browser

## Cloudflare Pages
Upload this ZIP to Cloudflare Pages using the Pages upload/deploy flow. `index.html` is the entry page.

## Supabase already configured
Project URL: https://mqyhixlojjtlatrzqxdv.supabase.co
The frontend uses the Supabase publishable key only. No service-role/secret key is included.

## Important
WhatsApp button opens a pre-filled WhatsApp chat. This package does NOT claim automatic WhatsApp Cloud API messaging or Meta webhook automation. That would require an external WhatsApp API/provider.

For admin access, create/login with the intended admin email account and ensure its `profiles.role` is `admin` in Supabase. Do not use a hard-coded admin password in production.
