# ULTIMATE FC

An original browser soccer game with a 3D stadium, 11v11 match engine, AI opponents, a 300-player card collection, offline saved progress, and an FC Mobile-inspired team-building lobby.

## Start locally (recommended)

Requirements: Node.js 20.19+ or 22+. Open a terminal in this folder and run:

```bash
npm install
npm run dev
```

Open the local address printed by Vite (usually `http://localhost:5173`).

## Publish to Netlify Drop

**Recommended, self-hosted build:**

```bash
npm install
npm run build
```

Upload the resulting **`dist/` folder** to [Netlify Drop](https://app.netlify.com/drop).

A pre-generated **`dist/`** is also included for convenience. This is a browser-module fallback built without npm packages. **It loads React, Three.js, React Three Fiber, Drei, Rapier and other libraries from esm.sh**, so visitors need an internet connection and availability of that CDN. `npm run build` replaces it with the standard bundled Vite distribution and is recommended before deploying publicly.

## Controls

| Input | Action |
|---|---|
| WASD | Move controlled player |
| Mouse | Aim on the pitch |
| Left-click | Pass |
| Hold and release left mouse | Charge and shoot |
| Shift | Sprint |
| Space (with ball) | Skill move |
| Space (defending) | Switch defender |
| E | Tackle |
| Escape | Pause/resume |

The mouse must point toward an area of the playing field when aiming a pass or shot. Click **Kick off** after the lineup screen.

## How progression works

* New saves start at Gold 1 with 2,200 coins and a weak squad.
* Every ranked win advances exactly one division, a draw stays put, and a loss drops one division. Bronze 1 is the floor.
* At World Champion, a streak of three losses causes demotion to Sapphire 3; a win or draw resets the streak.
* Friendlies award reduced coins but leave rank unchanged.
* Earn coins through matches, daily rewards, and objective claims. Unlock players through the market or packs (virtual coins only).
* Move players between the starting lineup and substitutes. Chemistry, out-of-position assignments, and training affect match attributes.
* Player and progression data are saved to this browser via localStorage. There is no server or cross-device syncing.

## Included systems

React + TypeScript + Vite, Three.js + React Three Fiber, Rapier, Zustand, four selectable formations and tactics, 11v11 AI, goalkeepers, game clock, stamina, shots, passes, interceptions, tackles, offsides, fouls, penalties, set pieces, replays, halftime, full-time statistics, squad chemistry, 300 unique cards, 24 named players (names and original card art only), collectible packs with disclosed virtual-coin probabilities, and nine lobby sections.

## Quality limitations

This is a substantial independent browser-game implementation, not a FIFA-scale commercial release. Player animations are procedural and simplified. Referee decisions, AI tactics, goalkeeper behavior, ball control, replays and the stadium are approximations rather than a full professional simulation. There is no network multiplayer, licensed player portraits, licensed teams, voice commentary, advanced mocap, or online accounts. Matches and rank are designed for offline single-player use.

**Build verification note:** The project was authored in an environment that did not have network access to download npm packages. The TypeScript source was transpiled into the pre-generated `dist` using the globally available compiler, and the generated JavaScript passed syntax checks. Automated no-render simulation tests passed for all four formations, rules, and rank progression. A full Vite bundle and real browser rendering could not be verified in this environment. Run `npm install && npm run build` and test in a modern browser before a public launch.

## Architecture

* `src/data/players.ts` 300-player database, card attributes and formations.
* `src/data/ranking.ts` pure ranked progression rules.
* `src/store.ts` persistent coins, rank, challenges, card inventory, squads, packs, and game preferences.
* `src/game/engine.ts` 11v11 simulation, football rules, decision logic, stats, and replay recording.
* `src/game/Stadium.tsx` pitch texture, spectators, seating, goals, 3D players, floodlights, and collision surfaces.
* `src/game/Match.tsx` browser controls, Rapier ball, match camera, scoreboard, kickoff and match results.
* `src/ui/App.tsx` lobby pages, card interfaces, market, squad management, and player settings.
* `src/styles.css` desktop-first responsive interface.
* `tests/simulation.mjs` deterministic assertions on database, ranking and simulation structure.

To rerun standalone engine tests without Vite, run `npm run test:sim` after installing Node/TypeScript. This produces the CDN-style dist first.


## Mobile controls and club setup (update)

On first launch you must create a club name and choose from 20 original badges. This is saved in the browser. Each new match assigns the CPU another badge. On touch devices the bottom-left movement joystick uses a stable home region with touch-centered dragging, while the bottom-right buttons perform Sprint / Tackle and Skill / Switch. Tap the field to pass; press and hold to aim a charged shot. Mouse and keyboard controls remain supported. Goalkeepers are AI-controlled and now attempt catches, parries, holds and passes after saves. The compact scoreboard is positioned at the top-left.

**Verification limits:** Simulation tests pass, but the 3D rendering and mobile multitouch interactions have not been tested in a real browser/device in this environment. The fallback `dist` build loads dependencies via public CDNs and needs an internet connection. For a normal production bundle, run `npm install && npm run build` on a machine with npm access.

## v1.3 passing and ball indicator

Tapping Pass / Shoot on mobile or clicking on desktop now produces a firm low ground pass with minimal vertical impulse. Holding releases an increasingly powerful lifted shot. A yellow circle tracks the ball on the pitch, approximately six ball diameters across. Tests cover the simulation; visual and real-device input behavior still require browser verification.
