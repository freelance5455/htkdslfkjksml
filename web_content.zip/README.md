# CollegeLife Full

A single-file, mobile-first, completely free college-management app prototype.

## Included in one build
- Premium dark/glass/neon UI
- Home college dashboard
- Smart calendar
- Date-wise Present/Absent
- Important point/note on any date
- Subject-wise attendance
- Attendance percentage + calculator
- Custom subjects
- Recurring weekly timetable with teacher/room
- Notes with search, filters, important flag and delete
- Exam planner + countdown + syllabus progress
- Assignments / tasks / revision list
- College events + holidays
- Study progress + weekly goal
- Calculator
- Scientific-style calculator entry
- Pomodoro timer
- Unit converter
- Maths formula sheet
- Focus/study-time logging
- Backup/export/import JSON
- Print/save-to-PDF through browser
- Profile / college details
- Theme choices
- Browser notification permission
- Installable/offline PWA shell
- Data stored locally on the device
- No paid feature lock in this prototype

## How to use
Open `index.html` in a modern browser. For PWA installation/offline service-worker features, serve the folder through a local/static web server rather than opening the file directly.

## Important
This is a front-end prototype. Real cloud sync, secure multi-device accounts, Android APK packaging, and reliable scheduled push notifications require a backend/app build stage.


## Practical Hub
- Physics + Chemistry practical timetable
- Date-wise practical schedule
- Batch, lab room, teacher and instructions
- Practical attendance tracking
- Practical record book: experiment no., aim, formula, observations, result
- Record submission status
- Viva questions + answers + preparation status
- Lab checklist / required items
- Practical file / notebook / assignment submission tracker
- Upcoming practical dashboard
