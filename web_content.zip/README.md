# You Fuel, I Drive — Functional MVP

Open `index.html` in a browser. The prototype uses localStorage so rider, driver and admin flows work without a backend.

## Demo flow
1. Rider tab → choose a vehicle → enter pickup date/time, duration and destination → request/pay.
2. Driver tab → accept → start trip → complete trip.
3. Admin tab → view bookings and platform 10% fees.

## Production architecture
Recommended backend: PostgreSQL/Supabase + secure authentication + object storage + payment provider (e.g. Paystack/Flutterwave) + server-side booking rules.

`schema.sql` contains the normalized core database model.

## Important production rules
- Enforce the 3-hour cutoff on the server, not just the UI.
- Never trust client-side price calculations; recalculate on the server.
- Hold/reconcile rider payment before releasing driver payout.
- Verify driver identity/licence and vehicle documents before activation.
- Record pre/post-trip condition and fuel evidence.
- Keep immutable booking/payment event logs for disputes.
