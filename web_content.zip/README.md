# 🌸 Shivania AI — Premium Dynamic AI Companion Chat Application

**Shivania AI** is an exquisitely designed, production-grade personal AI chatting application featuring a warm, expressive, playful, and caring female AI companion personality fluent in **Hindi and Hinglish**.

---

## 🌟 Key Features

### 1. Warm & Dynamic Personality
- **Natural Hindi & Hinglish**: Seamlessly blends modern Hindi and English code-switching ("*Arey yaar*", "*Sach me?*", "*Thoda to muskura do!*").
- **Simulated Emotional States**: Expresses lifelike simulated moods:
  - 🌸 **Playful & Teasing** (*Nakhre, witty banter, playful teasing*)
  - 💖 **Sweet & Caring** (*Empathetic, soothing when you are stressed*)
  - 😤 **Mock-Sulking** (*Pretends to sulk or be stubborn, then sweetly reconciles*)
  - ✨ **Cheerful & Energetic** (*Upbeat and enthusiastic*)
  - ☕ **Thoughtful & Deep** (*Philosophical, late-night companion discussions*)
- **Playful Disagreements & Sweet Reconciliation**: If you have a playful tiff, she playfully sulks, but melts warmly and reconciles.
- **Strictly Ethical & Age-Appropriate**: Safe, respectful, non-sexual, and transparent AI companion.

### 2. Chat-Only Focused Experience
- **Real-Time Streaming**: Words appear smoothly in real-time via Google Gemini API Server-Sent Events (SSE).
- **Realistic Typing Indicator**: Authentic animated 3-dot typing bubble with Shivania's avatar while she generates responses.
- **Message Controls**: Timestamp display, double-tick read receipts, one-click copy, and inline retry for failed requests.
- **Persistent Chat History**: All conversations, titles, timestamps, and messages are preserved locally across browser sessions.
- **Conversation Management**: Easily create new chats, search conversations, rename titles, or delete old threads.
- **Smart Quick Chips**: Contextual starter pills and prompt shortcuts ("*Arey suno na...*", "*Mujhe manao abhi! 🥺*", "*Aaj ka din thakane wala tha*").

### 3. Memory & Personalization System
- **Long-Term Memory Bank**: Remembers facts you share (name, favorite foods, hobbies, personal context).
- **Interactive Memory Drawer**: View, add, edit, or delete memories anytime.
- **Personality Tuning Studio**: Real-time sliders for Playfulness, Hindi/Hinglish blend ratio, and Empathy level.

### 4. Realistic Mobile-First Premium UI
- **Refined Aesthetics**: Soft porcelain/warm-white background, subtle lavender (`#7c3aed`) and indigo (`#6366f1`) accents.
- **Zero Emoji Placeholders**: Clean vector SVG icons for all UI elements, plus a photorealistic studio portrait avatar.
- **Responsive Layout**: Designed for mobile browsers and Android touch screens, looks equally stunning on desktop.
- **Audio Cues**: Optional gentle chime synthesized via Web Audio API (no external audio files needed).

---

## 🚀 Quick Start Guide

You can run Shivania AI in **two easy ways**:

### Option A: Direct Client-Side (Easiest — No Server Needed!)
1. Open `index.html` directly in any modern web browser (Google Chrome, Firefox, Safari, Edge) or upload the folder to any static web host (**Netlify, Vercel, GitHub Pages, Firebase Hosting**).
2. Click the **Settings (Gear Icon)** in the top right.
3. Paste your **Google Gemini API Key**.
4. Click **"Test Connection"** to verify, then start chatting!

### Option B: With Node.js Secure Backend Proxy
If you prefer keeping your API key hidden on a server instead of entering it into the browser:
1. Navigate to the project folder in your terminal:
   ```bash
   cd backend
   npm install
   ```
2. Copy `.env.example` to `.env` in the root folder:
   ```bash
   cp ../.env.example ../.env
   ```
3. Open `.env` and paste your Gemini API key:
   ```env
   GEMINI_API_KEY=AIzaSyYourActualKeyHere
   PORT=3000
   GEMINI_MODEL=gemini-3.8-flash
   ```
4. Start the server:
   ```bash
   npm start
   ```
5. Open `http://localhost:3000` in your browser.

---

## 🔑 Where to Get a Gemini API Key

1. Visit [Google AI Studio](https://aistudio.google.com/app/apikey).
2. Sign in with your Google account.
3. Click **"Create API Key"**.
4. Copy your key and paste it into Shivania AI's Settings modal or your `.env` file.

---

## 📁 Project Structure

```
Shivania_AI/
├── index.html              # Core application entrypoint (Root)
├── .env.example            # Backend environment variable template
├── README.md               # Complete application documentation
├── API_SETUP_GUIDE.md      # Detailed step-by-step API tutorial
├── assets/
│   ├── avatar.jpg          # High-resolution photorealistic avatar
│   └── avatar_thumb.jpg    # Web-optimized 300x300 avatar thumbnail
└── backend/
    ├── package.json        # Node.js backend configuration
    └── server.js           # Express proxy server with SSE streaming
```

---

## 🛡️ Privacy & Safety
- Your API key is stored strictly on your own device (in your browser's private `localStorage` or your private `.env` file). It is never sent to any third-party server.
- Shivania AI maintains age-appropriate, non-sexual boundaries and reminds users that she is an AI companion designed for warm, fun, and supportive conversations.
