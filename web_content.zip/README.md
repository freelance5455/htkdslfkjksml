# Ilostan — wersja bez kont

Wersja demonstracyjna działająca bez logowania i rejestracji.

- przeglądanie pojazdów
- wyszukiwanie
- strony szczegółowe
- statystyki
- dodawanie pojazdów zapisywane lokalnie na urządzeniu
- komentarze zapisywane lokalnie na urządzeniu
- responsywny interfejs mobilny

Można spakować cały folder do ZIP i użyć w builderze ZIP → APK.

Uwaga: ta wersja nie wymaga backendu, ale dane są lokalne dla urządzenia/przeglądarki. Nie jest to jeszcze wspólna internetowa baza danych.
