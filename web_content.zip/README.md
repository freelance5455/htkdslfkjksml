# Tavar's V8

Soddalashtirilgan, offline-first ombor boshqaruv ilovasi.

## V8 asosiy funksiyalari
- Kategoriya maydoni olib tashlangan.
- Bir xil nomdagi mahsulot topilsa, qo‘shishdan oldin tasdiqlash oynasi chiqadi.
- Ombor va sotuv ma’lumotlari localStorage’da saqlanadi.
- Sotuvda mahsulotlar tanlanadi va katta **JAMI** summasi ko‘rsatiladi.
- Sotuvni yakunlashdan oldin **Klient qancha berdi?** so‘raladi.
- Qaytim, qarz va klient bergan pulga bog‘langan foyda hisoblanadi.
- Har bir sotuv saqlangan chek ko‘rinishida ko‘rsatiladi.
- Xarajatlar alohida sahifada kiritiladi va sof foydadan ayriladi.
- UI sodda va mobilga mos; mavjud asosiy tugmalar joylashuvi saqlangan.

## APK uchun
1. `npm install`
2. `npx cap add android`
3. `npx cap sync android`
4. `npx cap open android`
5. Android Studio'da APK build qiling.

Ma’lumotlar hozircha telefonning localStorage’ida saqlanadi.


## V11 changes
- Ombor yagona stock manbasi: 0 dona mahsulot avtomatik o‘chiriladi.
- Sotish sahifasida faqat omborda 1+ dona mavjud mahsulotlar ko‘rinadi.
- Oxirgi dona sotilganda mahsulot ombordan avtomatik o‘chadi.
- Menu oynasi: “V11 tez orada chiqadi!”


## V13 changes
- Hisobot sahifasi tushunarli bo‘limlarga ajratildi: bugungi hisob, pul holati va kunlik kirim.
- Statistikadagi “Menda bor pul” kecha + bugun + ertaga kirimlari yig‘indisini ko‘rsatadi.
- Menu tugmasi “V13 tez orada chiqadi!” oynasini ochadi.
- OK tugmasi Home sahifasiga qaytaradi.
- Spy tugmasi parol oynasini ochadi; to‘g‘ri parol kiritilganda RESET chiqadi.
- RESET barcha mahalliy ilova ma’lumotlarini boshidagi qiymatlarga qaytaradi.


Cash balance fix: Menda bor pul is an all-time persistent balance until RESET; sales and repair income increase it, expenses decrease it.
