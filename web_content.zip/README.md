# AI Reseller

**Your AI-powered store. Start free.**

AI Reseller is a free AI-powered ecommerce platform for beginners who want to launch an online store, resell products, or run a dropshipping business. Describe what you want to sell, and AI drafts your store — categories, copy, and product listings — for you to review and publish.

> **Status: fully working MVP, no demo/mock data.** Every endpoint is backed by a real Postgres database, real bcrypt+JWT auth, and (when `OPENAI_API_KEY` is set) the real OpenAI API. Product Finder pulls real, live product data from a public catalog API. Orders, customers, and analytics start empty and only ever show real data — never invented numbers. Checkout is intentionally unimplemented (see below) rather than faked.

## Features

- **AI Store Builder** — describe your store in plain language; AI proposes name, tagline, categories, homepage sections, and copy for you to preview and apply (never auto-applied). Requires `OPENAI_API_KEY`.
- **AI Product Generator** — describe/upload a product photo, get an editable draft: title, description, features, tags, SEO fields. Never invents unverifiable specs. Requires `OPENAI_API_KEY`.
- **AI Business Assistant** — ask for product-page feedback, captions, homepage ideas; scoped only to your own store's real data. Requires `OPENAI_API_KEY`.
- **Product Finder** — browse real products (names, images, prices) from a free public product API, with estimated cost/margin, via a swappable `SupplierProvider` interface. Importing adds a real draft product to your store; it does not place a live supplier order (no fulfillment supplier is connected — that needs a real supplier account and API credentials, which this repo can't fabricate for you).
- **Store Editor & public storefront** — edit your store's name/tagline/description/currency and see a real, live public storefront at `/store/:slug`, reading straight from your database.
- **Orders, Customers, Analytics** — start empty for a new account and populate only from real rows in your database. No sample/seed data is inserted.

## What's genuinely NOT here (and why)

- **Payments/checkout** — intentionally not implemented. The storefront shows "Checkout integration coming soon" rather than a fake successful payment. Wire in a real processor (Stripe, etc.) when you're ready.
- **Live order fulfillment from a supplier** — `SupplierProvider.createOrder()` throws on purpose. There's no real dropshipping account behind this repo; connect one (with real API credentials) and implement that one method.
- **OAuth login** — architecture supports adding it; only email/password is wired up today.

## Tech Stack

- **Frontend:** React + TypeScript + Vite + Tailwind CSS, React Router
- **Backend:** Node.js + Express + TypeScript
- **Database:** PostgreSQL (raw SQL schema, `pg` driver)
- **Auth:** email/password, bcrypt hashing, JWT in httpOnly cookies (architecture allows OAuth later)
- **AI:** OpenAI API, called **only from the backend** — the key never reaches the browser
- **Product data:** [DummyJSON](https://dummyjson.com) public API for real product discovery data (no key required)
- **Storage:** `StorageProvider`-shaped upload handling, ready for S3-compatible backends

## Requirements

- Node.js 20+
- PostgreSQL 14+
- An OpenAI API key — **required** for AI Store Builder / Product Generator / Business Assistant to work. Without it, those three endpoints return a clear "not configured" error instead of any fallback content.

## Installation

```bash
git clone <your-repo-url> ai-reseller
cd ai-reseller

# backend
cd server && npm install
# frontend
cd ../client && npm install
```

## Environment Variables

Copy and fill in:

```bash
cp .env.example .env
```

| Variable | Description |
|---|---|
| `DATABASE_URL` | Postgres connection string |
| `OPENAI_API_KEY` | Server-side only. Required for AI features. Never referenced from client code. |
| `SESSION_SECRET` | Random 32+ char string for signing JWTs/cookies |
| `APP_URL` | Public URL of the frontend (for CORS) |
| `STORAGE_URL` / `STORAGE_ACCESS_KEY` / `STORAGE_SECRET_KEY` | S3-compatible storage for product image uploads |

Never commit `.env`.

## Database Setup

```bash
createdb ai_reseller
psql ai_reseller -f server/src/database/schema.sql
```

This only creates tables — no seed/sample rows are inserted. A brand-new account starts completely empty, by design.

## Development

```bash
# terminal 1
cd server && npm run dev

# terminal 2
cd client && npm run dev
```

Frontend: http://localhost:5173 · API: http://localhost:4000

## Production Build

```bash
cd client && npm run build   # outputs client/dist
cd server && npm run build   # outputs server/dist
```

## Deployment

- **Frontend:** deploy `client/dist` to Vercel or Netlify (set `VITE_API_URL` to your backend URL).
- **Backend:** deploy `server` to Render, Railway, or Fly.io. Set all env vars from `.env.example` in the platform's dashboard.
- **Database:** any managed Postgres (Render, Railway, Neon, RDS).

## Architecture

```
/client   → React SPA (public site, auth, authenticated dashboard, public storefront)
/server   → Express API (REST, JWT auth, OpenAI calls, supplier abstraction)
```

Supplier integrations go through `server/src/providers/SupplierProvider.ts`. `LiveCatalogSupplierProvider` (real public product data) is wired in today; swap in a real fulfillment supplier's SDK without touching route/controller code.

## API Overview

See `server/src/routes/*` — all authenticated routes require a valid session cookie, validate request bodies (zod), and return `{ success, data | error }` JSON. `GET /api/public/stores/:slug` is the one unauthenticated route (the public storefront).

## Security Notes

- Passwords hashed with bcrypt, never stored/logged in plaintext.
- JWT stored in httpOnly, secure, sameSite cookies — not localStorage.
- All DB access is parameterized (no string-built SQL).
- Rate limiting on auth and AI endpoints; helmet security headers; CORS restricted to `APP_URL`.
- No API keys ever ship to the browser bundle.

## Honesty rules baked into the code

- No sample/seed data anywhere — Orders, Customers, Analytics, and Product Finder either show real data or an honest empty/error state.
- The AI endpoints require a real `OPENAI_API_KEY` and return a clear configuration error otherwise — there is no canned fallback text pretending to be AI output.
- The storefront never simulates a successful payment.
