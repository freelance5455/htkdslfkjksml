ResQ mesh+ — Aavishkar Demo

Offline software demo for project presentation.

Main flow:
SOS / Voice SOS -> LoRa Node -> Relay 1 -> Relay 2 (Store & Forward) -> Rescue Dashboard -> Rescue Response

Included:
- SOS demo
- Voice SOS simulation
- Location capture with demo fallback
- Battery / Auto Emergency Mode simulation
- Long-range LoRa relay visualization
- Store & Forward / SOS Priority / Auto Relay / Delivery to Rescue
- Rescue Dashboard
- Local emergency history
- Demo Guide
- Settings / technical status

Important: This is a software simulation for exhibition demonstration. It does not transmit real LoRa radio packets.

Verification performed:
- ZIP integrity: PASS
- JavaScript syntax: PASS
- HTML references app.js and style.css: PASS
- Required demo controls present: PASS
- No external CDN/library dependency: PASS
- Project communication terminology uses LoRa; no ESP32/Wi-Fi/Bluetooth/4G/5G communication path in source text.
