# Wyoming General Hunt

Version 1.0.0

This is the first build of the Wyoming-only hunting/navigation application.

Included:
- Wyoming-only map engine
- GPS position on Samsung/Android-capable browser wrapper
- Mule deer / white-tailed deer combined deer layer
- Elk layer
- General-license-only hunt-area filtering
- Official hunt-area numbers
- Vehicle marking
- Start/stop breadcrumb tracking
- Return-to-vehicle distance and bearing
- LocalStorage persistence for vehicle and track
- Hunt-data download/cache for offline field use after the data has been downloaded
- Controlled paste-in UPDATE APP mechanism
- Separate hunt-data update mechanism
- No requirement to rebuild the APK for ordinary data updates

IMPORTANT DATA NOTE:
Wyoming Game & Fish's publicly indexed 2026 deer GIS layer is available and is used by this build.
The current 2026 elk regulations are used for general-license area status, but the publicly indexed WGFD elk GIS layer is still labeled 2025. This build therefore labels the elk boundary geometry as provisional and does NOT represent it as a 2026 legal boundary. The elk geometry should be replaced with the official 2026 WGFD GIS layer as soon as WGFD publishes it.

The app should never be treated as a legal substitute for the current Wyoming Game & Fish regulations. Written boundary descriptions and current regulations control.

Packaging:
1. Upload index.html to an HTML-to-APK builder or an equivalent Android web-wrapper service.
2. Enable location permission.
3. Install the resulting APK.
4. Before going into the field, open the app while online and press DOWNLOAD / UPDATE HUNT DATA.
5. Test GPS and RETURN TO VEHICLE before relying on it in the field.

Sources:
- Wyoming Game & Fish Department 2026 regulations
- Wyoming Game & Fish Department ArcGIS hunt-area datasets
