# AETHER UNIVERSE AI — Édition Ultimate

Bienvenue dans le code source complet de **AETHER UNIVERSE AI**.

## Structure du ZIP
- `index.html` : Interface principale et structure de l'application mobile.
- `style.css` : Thème futuriste (noir profond, bleu nuit, violet, cyan), animations et styles responsive.
- `app.js` : Moteur complet (Cerveau IA, Constructeur d'univers, Personnages, Studio Manga/Webtoon, Multimédia, Stockage local et configuration serveur).

## Conversion en APK Android
1. Décompressez ce fichier ZIP ou utilisez directement le dossier.
2. Assurez-vous que `index.html` reste à la racine.
3. Importez le dossier dans **Web2APK**, **Cordova**, ou **Capacitor** pour générer votre fichier `.apk` Android.
