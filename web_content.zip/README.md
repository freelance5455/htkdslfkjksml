# Omozon Demo

Browserfähige Omozon-Demo mit Warenkorb, fiktiver Testzahlung, Bestellübersicht und vollständig fiktiver Sendungsverfolgung.

Die Sendungsverfolgung zeigt einen simulierten Zeitplan bis morgen um 18:00 Uhr und endet danach mit „Zustellung verzögert“. Es findet keine echte Zahlung und keine echte Lieferung statt.
