# Mayonin Chronicles — Original Supernatural Tactical RPG

A mobile-first React/Vite prototype built around the Arden / Mayonin concept.

## Included

- 35-episode Chapter 1 structure
- Arden, Seraphine and the 10-fighter squad
- Character dialogue and emotions
- Clash combat
- Break system
- Drag + Connect action planning
- Momentum and counter links
- Status effects
- Formation and fighter instincts
- Enemy families and 12 variant types
- Enemy discovery archive
- Arden SPECIAL system
- Command Strike sequence
- Time Cracker / temporal mechanics
- Anomaly weather
- Manager and fighter levels
- Trust and recruitment
- Discoveries and Lore Archive
- Five-phase Father finale
- Awakened Arden with Clash ???
- Functional localStorage save system
- Low Memory Mode and reduced-motion support
- Functional battle loading asset preparation
- Static Vite build suitable for Cloudflare Pages

## Cloudflare Pages

Build command:

```text
npm run build
```

Build output directory:

```text
dist
```

No server, database, account system, or external API is required by the game prototype.

## Local development

```text
npm install
npm run dev
```

## Chapter 1 Finale Cinematic
Episode 35 now transitions automatically from the Father's defeat into an in-world cinematic scene. It includes the final block, repeated weapon clashes with spark SFX, a black-screen Death Hit, the delayed slash aftermath, Arden's fear and forgiveness, the breaking of the ancient chains, and discovery of the Ancestor's Broken Blade. Story dialogue throughout the play screen is presented over the actual episode environment with two-character staging when a scene has two participants.
