# সমিতি হিসাব ব্যবস্থাপনা (Samity Management)

মোবাইল-ফার্স্ট ওয়েব অ্যাপ — সাধারণ HTML/CSS/JavaScript, কোনো build tool লাগে না।

## ফাইল কাঠামো
| ফাইল | কাজ |
|---|---|
| `index.html` | **মূল ফাইল** — পেজের কাঠামো, `styles.css` ও `app.js` লোড করে |
| `styles.css` | সব ডিজাইন/স্টাইল |
| `app.js` | সম্পূর্ণ অ্যাপ লজিক (সদস্য, জমা/উত্তোলন, এফডিআর, প্রোফিট, হিসাবরক্ষণ, ইউজার রোল, রশিদ, Excel এক্সপোর্ট/ইম্পোর্ট) |
| `manifest.json`, `icon-*.png` | হোম-স্ক্রিন আইকন / PWA তথ্য |

## চালানোর নিয়ম
- `index.html` ব্রাউজারে খুললেই চলবে (ফোল্ডারের ফাইলগুলো একসাথে রাখতে হবে)।
- ডেটা ব্রাউজারের `localStorage`-এ থাকে (key: `samity-db`)। নিয়মিত সেটিংস → "ডেটা এক্সপোর্ট" দিয়ে ব্যাকআপ নিন।
- Excel ফিচারের জন্য SheetJS (cdnjs) ইন্টারনেট থেকে লোড হয়; না পেলে CSV ব্যবহার হয়।
- APK বানাতে: ফোল্ডারটি হোস্ট করে (যেমন Netlify Drop) pwabuilder.com-এ লিংক দিন।

## `app.js`-এর প্রধান অংশ (ফাইলে এই কমেন্ট হেডার খুঁজুন)
STATE & STORAGE · ROLES & PERMISSIONS · STORAGE ADAPTER · AUTH · USER MANAGEMENT · DASHBOARD · MEMBERS · TRANSACTIONS · DEPOSIT: EXCEL EXPORT/IMPORT · FDR · PROFIT & STATEMENT & REPORTS · ACCOUNTING (Chart of Accounts / Journal / Ledger / Trial Balance) · RECEIPTS & VOUCHERS · ORG SETTINGS
