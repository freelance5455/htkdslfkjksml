# NOMIDMAN TRANS: Android app (native project)

A native Android project (Java) that opens the NOMIDMAN TRANS website, bundled inside the app.

## Open and build
1. Install Android Studio (it includes the Android SDK).
2. File > Open, and select this folder.
3. Let Android Studio sync the Gradle files (first sync needs internet).
4. Build > Build Bundle(s) / APK(s) > Build APK(s) for testing, or Build > Generate Signed App Bundle for Google Play.

## Contents
- `app/src/main/assets/`: the website (Flutterwave edition), copied from the website build. After any website change, rebuild the website and copy `dist/NOMIDMAN-TRANS-CO-LTD-Flutterwave/` into this folder's assets.
- `app/src/main/java/.../MainActivity.java`: the screen. Links to other sites, SMS, email and Messenger open in the phone's own apps. The back button goes back through the site's pages.
- `app/src/main/res/`: app name and launcher icons (replace with proper sizes for each density before release).

## Before release
- The live backend must be connected. Until then the app uses demo data stored on each phone.
- Replace the icons with correctly sized images for each density.
- Set the version number (versionCode and versionName in app/build.gradle) for each release.
- Keep the signing key safe. Updates must be signed with the same key.
- Privacy policy and terms must be live at https://nomidtrans.shop.
