# TopeCode V3

A mobile-first coding studio built with React 19, TypeScript, Vite and Tailwind CSS v4. A bright pink/purple interface combines restrained liquid-glass surfaces, tactile controls and clay details. Dark and system themes remain available. No account or application backend is required.

## Run

```sh
npm install
npm run dev
npm run build
npm run preview
```

## Verify

```sh
npx tsc --noEmit -p tsconfig.json
node --import tsx --test tests/core.test.ts
npx playwright install --with-deps chromium
npx playwright test
npm audit
```

## Build, Not Pretend

- The coding agent uses the user's real provider connection. Missing keys and failed calls are shown as errors. Chat never silently substitutes a template response or fake success.
- Agent mode can inspect files, propose changes, apply approved writes and continue from the actual execution results. Runs are bounded to six provider rounds, with at most 20 actions per round. Ask and Plan modes do not execute writes.
- Streaming text is painted at bounded intervals. Provider thinking events animate progress indicators without exposing or fabricating private reasoning.
- The editor has syntax highlighting, persistent drafts, search, a coding keyboard, direct file downloads and Save. Unsaved drafts are protected from agent overwrites.
- File creation, editing, deletion, rename and move are validated inside the selected workspace. Pre-write diffs, per-action permissions, ordered change history and undo are real.

## Your Model Connection

17 presets include OpenAI, Anthropic, DeepSeek, Z.AI, OpenRouter, Gemini, Groq, Mistral, xAI, Together, Fireworks, Moonshot, Qwen, Cerebras, Azure OpenAI, Ollama and LM Studio. Custom providers support the same protocol choices.

All keys, base URLs and exact model IDs are editable. The selected model is remembered separately for each provider. You can replace an exhausted key and retry the original prompt.

- OpenAI Chat Completions and Responses API, with optional reasoning-effort controls.
- Anthropic Messages with native streamed tool proposals and optional budgeted thinking.
- Gemini GenerateContent with correct conversation roles and native function declarations.
- Editable output-token limits. Model support varies; unsupported options produce actual provider errors.
- **Test connection** lists model IDs. This verifies the endpoint, not access to a particular model.
- **Test model generation** makes a small real generation using the exact current fields. It may incur a provider charge. Tests and saves are separate actions.

When Remember on this device is enabled, saved keys are AES-GCM encrypted in IndexedDB using a non-extractable browser CryptoKey. Save commits immediately; reload decrypts locally. This protects against plain-text storage inspection, not malicious scripts on the same origin, browser compromise or an untrusted device. It is not Android Keystore protection. Without encryption support, keys remain in memory rather than being written as plain text to the fallback storage. Disable persistence for shared devices. Conversation exports omit provider keys.

Provider CORS policies, quotas, model availability, billing and account permissions still apply. Preset IDs are editable suggestions, not a promise of access. No paid provider credentials are included.

## Real Browser Preview

The built-in compiler uses Sucrase and a bundled, offline React runtime. It runs actual HTML, React/TSX/JSX, local imports, JSON, plain CSS and SVG in an iframe with `sandbox="allow-scripts"`. Automatic reruns happen after saves; manual Run, viewport controls, compiler/runtime errors and preview console output are available. An error can be attached to an agent prompt.

The example Petal Notes project is editable source, not an image or generated conversation. Its search, favorites, new notes and text editing execute in the preview.

Supported libraries include React, `react-dom/client`, the JSX runtime and a bundle of common Lucide icons. The preview does not install arbitrary npm dependencies, run a Node server, compile Tailwind utilities at runtime, fetch external assets or make network requests. Unsupported imports produce explicit errors. Preview-local storage is ephemeral and isolated; workspace state uses IndexedDB. Unshared credential files are excluded from the preview bundle.

The runtime source is in `scripts/preview-entry.ts`. If its bundled dependencies change, regenerate it before building:

```sh
npx esbuild scripts/preview-entry.ts --bundle --minify --format=iife --define:process.env.NODE_ENV='"production"' --outfile=src/generated/preview-runtime.js
```

## Android And Offline Use

The production build is an installable progressive web app with an app manifest, home-screen icons and an offline shell. Use a supported browser's Install app or Add to Home screen option. Editing and local previews work offline after the initial load; provider requests require network access. The service worker never caches provider requests or API keys.

This is a complete mobile web workspace, **not a signed native Android APK**. Native Storage Access Framework integration, Android Keystore and native npm/git execution are not included. Device directory access depends on browser support; import a folder and export a ZIP when direct access is unavailable. Imported folders are local copies. Device handles must be reconnected after a reload.

The console executes built-in `ls`, `cat`, `tree`, `pwd`, `help` and `clear` commands against the current workspace. It never invents native build or git output.

Folder indexing is bounded to 800 entries, 20 directory levels and 512 KB per text file. Binary/dependency files are excluded; destructive operations containing excluded data are rejected. External file changes are checked before device writes. Multi-file writes are sequential, not filesystem transactions. Keep an external backup of important projects.
