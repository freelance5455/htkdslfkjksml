# Punjab Weather Android App

This Android app wraps the existing 15-city Punjab weather dashboard in a native Android WebView.
It opens as an app from the phone's app drawer/home screen; it does not launch Chrome.

## Build an APK in GitHub (no Android Studio required on your PC)

1. Sign in to GitHub and create a new repository, e.g. `PunjabWeather`.
2. Upload the contents of this folder to the repository (keep the folder structure).
3. Open the repository's **Actions** tab.
4. Choose **Build Punjab Weather APK** and tap **Run workflow** (or push to `main`).
5. When the run finishes, open it and download the **Punjab-Weather-APK** artifact.
6. Extract the downloaded ZIP; inside is `app-debug.apk`.
7. Send the APK to your Android phone and install it. If prompted, allow installing apps from that source.

## Notes
- Internet is required for live weather updates from Open-Meteo.
- This is a debug APK for personal use, not a Play Store release.
- The app contains no location tracking; it fetches weather for the 15 fixed cities in the dashboard.
