# Vida Urbana RP

Jogo 3D urbano para navegador, com:
- personagem em terceira pessoa e controles mobile;
- câmera por toque;
- cidade 3D;
- carro dirigível e entrar/sair;
- HUD, dinheiro, energia e combustível;
- emprego de entregador;
- prefeitura/interação;
- NPCs;
- minimapa;
- chat;
- sincronização multiplayer básica via WebSocket quando executado pelo servidor.

## Rodar no PC
1. Instale Node.js 18+.
2. Abra o terminal nesta pasta.
3. Rode `npm install`.
4. Rode `npm start`.
5. Abra `http://localhost:3000`.

Para multiplayer pela internet, publique o servidor Node em um serviço que aceite WebSocket.
