# ◈ TEMPO·ESPAÇO ◈ v7.0

**Dispositivo alvo:** Xiaomi Redmi Note 14 Pro 5G (HyperOS / Android 14)
**Tipo:** PWA / WebApp empacotável em APK via conversor HTML→APK
**Versão:** 7.0.0

---

## O que é

App de sensores reais para Android: bússola com filtro anti-tremor, GPS
(lat/lon/velocidade/altitude/precisão), magnetômetro, análise de espectro
do microfone em tempo real, pulsos hápticos+áudio, radar de waypoints com
direção e distância reais, câmera traseira ao vivo e síntese de voz pt-BR.

Nenhuma funcionalidade é simulada. Limitações técnicas reais são
declaradas no próprio app (tela "Sobre / Limitações") e abaixo.

---

## Estrutura do pacote (tudo na raiz)

```
index.html                  ← app completo (HTML+CSS+JS num arquivo só)
manifest.json               ← manifest PWA + permissões declaradas
sw.js                       ← service worker / cache offline v7.0.0
icon-192.png                ← ícone 192×192 (gerado)
icon-512.png                ← ícone 512×512 (gerado)
GUIA_XIAOMI_NOTE14_PRO.txt  ← passo a passo de instalação
README.md                   ← este arquivo
```

Sem dependências externas. Funciona offline depois do primeiro carregamento.

---

## Status de cada função (auditoria real)

| Função | Status | Observação |
|---|---|---|
| Bússola (heading) | ✅ IMPLEMENTADO + VALIDADO | `deviceorientationabsolute` com fallback, filtro passa-baixa 0.15, aviso de calibração |
| GPS (lat/lon/vel/alt/precisão) | ✅ IMPLEMENTADO | `watchPosition` alta precisão; altitude via GPS (sem barômetro) |
| Magnetômetro X/Y/Z µT | ⚠️ DEPENDE DO WEBVIEW | Generic Sensor API `Magnetometer`; se não exposto, app avisa e usa bússola (mesmo sensor) |
| Espectro de áudio / freq. dominante | ✅ IMPLEMENTADO + VALIDADO | Web Audio `AnalyserNode` fftSize 1024, canvas ao vivo |
| Detecção de picos (pulso recebido) | ✅ IMPLEMENTADO | pico >180/255 acima de 30Hz → registra no histórico |
| Envio de pulso (vibração+áudio+onda) | ✅ IMPLEMENTADO | `navigator.vibrate` + oscilador real + animação CSS |
| Histórico de pulsos (12 últimos) | ✅ IMPLEMENTADO | persistido em `localStorage` |
| Síntese de voz pt-BR | ✅ IMPLEMENTADO | `speechSynthesis`, depende de voz pt-BR instalada no Android |
| Radar de waypoints | ✅ IMPLEMENTADO + VALIDADO | haversine + bearing real; waypoints salvos no aparelho; 3 cores por tipo |
| Câmera traseira ao vivo | ✅ IMPLEMENTADO | `getUserMedia` facingMode environment |
| Bluetooth | ⚠️ LIMITADO PELA API | Web Bluetooth só permite escolha manual via `requestDevice`; **não** faz varredura contínua/RSSI (restrição de segurança). App deixa isso explícito. |
| Wake Lock (tela ligada) | ✅ IMPLEMENTADO | `navigator.wakeLock`, com re-aquisição ao voltar para app |
| Aviso "travar app em recentes" | ✅ IMPLEMENTADO | `visibilitychange` + notificação |
| Cache offline (Service Worker) | ✅ IMPLEMENTADO + VALIDADO | cache v7.0.0, limpa versões antigas no activate |
| Ícones PNG 192/512 | ✅ GERADOS | gerados com PIL, incluídos |
| 7.83 Hz Schumann | ❌ NÃO DETECTÁVEL | microfone de celular não capta abaixo de ~20Hz. Aparece apenas como linha de referência no espectro. **Não é simulado.** |
| Barômetro / altitude pressão | ❌ INEXISTENTE NO APARELHO | confirmado pela Xiaomi: Note 14 Pro 5G não tem barômetro. App usa altitude do GPS e avisa. |
| Varredura Bluetooth contínua | ❌ NÃO PERMITIDA | restrição da Web Bluetooth API. Não é possível contornar sem plugin nativo no empacotador. |

---

## Correções em relação à v6 (auditoria)

1. **Bug de sintaxe corrigido:** precedência de operadores quebrada na
   linha do radar-info (`&&` + `?:` sem parênteses) — reescrito.
2. **`DeviceMotionEvent.magneticField` removido:** essa propriedade **não
   existe** na API (era código inventado). Substituído pela Generic Sensor
   API `Magnetometer` real, com fallback e aviso honesto.
3. **Bluetooth falso removido:** a v6 simulava "escaneando...". Agora é
   botão real de `requestDevice` com declaração explícita da limitação.
4. **Frequência de referência Schumann:** não é mais apresentada como
   detectável. Linha de referência apenas, com aviso textual.
5. **"Portais" não são mais fictícios:** transformados em waypoints reais
   criados pelo usuário, com coordenadas GPS reais, direção e distância
   calculadas de verdade, persistidos no aparelho.
6. **Câmera adicionada de verdade** (v6 só mencionava).
7. **TTS adicionado de verdade** (v6 só mencionava).
8. **Persistência real** em localStorage (waypoints + histórico de pulsos).
9. **Filtro anti-tremor da bússola** com constante de tempo calibrada.
10. **Service Worker** com versão v7.0.0 e limpeza de caches antigos.
11. **Tratamento de erro** em todos os sensores (negação de permissão,
    API indisponível, stream vazio).
12. **FPS adaptativo:** loops de desenho param quando o app está oculto.

---

## Como gerar o APK

Ver `GUIA_XIAOMI_NOTE14_PRO.txt` — passo a passo completo para conversor
HTML→APK e configurações pós-instalação no HyperOS.

Resumo: zipar a raiz → ativar todas as permissões no conversor → gerar →
instalar → travar app nos recentes → bateria sem restrições → localização
"sempre permitir".

---

## O que precisa ser testado no celular (não validável aqui)

- Se o WebView do seu conversor expõe a Magnetometer API (se não expuser,
  o app funciona com bússola apenas e avisa na tela).
- Se a voz pt-BR do `speechSynthesis` está instalada no Android.
- Estabilidade do GPS em área urbana fechada.
- Se o empacotador respeita o `wakeLock` (alguns bloqueiam).
- Tempo de vida em segundo plano após travar + bateria sem restrições.

---

## Auditoria do pacote

- 7 arquivos na raiz → 0 faltando ✅
- `manifest.json` validado como JSON ✅
- JavaScript embutido validado com `node --check` ✅
- `sw.js` validado com `node --check` ✅
- Ícones PNG 192/512 gerados e presentes ✅
- Nenhuma dependência externa (funciona offline) ✅
- Nenhum segredo/chave no código ✅
- Nenhum caminho quebrado (tudo relativo `./`) ✅
