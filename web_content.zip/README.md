# Mubashir Bumraaa — Multiplayer Arena Strike

A small real-time browser multiplayer arena shooter starter project. It has a live WebSocket server, shared player movement, server-side hit checks, health/respawn/score, three weapon types, keyboard/mouse controls, and a mobile movement stick.

## Run it on your computer

You need Node.js 18 or newer.

```bash
npm install
npm start
```

Open http://localhost:3000 in your browser. To test multiplayer locally, open the same address in two browser tabs.

## Put it online for friends

This project needs a public Node.js host to work over the internet; the ZIP by itself is source code and does not create a public server automatically.

1. Upload/extract this folder into a GitHub repository.
2. Create a new **Web Service** on a Node.js hosting provider such as Render and connect the repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Open the public HTTPS URL from the host and share it with friends.

The client automatically uses secure WebSockets (`wss://`) when served over HTTPS. Use a host that supports long-lived WebSocket connections.

## About the earlier `net::ERR_HTTP_RESPONSE_CODE_FAILURE`

That browser message usually means the requested URL/server returned an HTTP error response. It is not possible to fix every such error inside a ZIP alone: the app must be served from a working server URL. Check the host's deployment logs and make sure the service is running and the URL is the one supplied by the host.

## Notes

- This is a playable starter prototype, not a finished commercial game like Free Fire.
- Graphics are stylized 2D canvas graphics, designed to work on mobile and desktop browsers.
- Multiplayer state is kept in memory. Restarting the server clears the current match.
- Add authentication, abuse protection, persistent stats, room/matchmaking logic, and production-grade server validation before a public competitive release.
