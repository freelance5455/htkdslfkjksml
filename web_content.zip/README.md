# JARVIS Android 2.0

Projeto Android nativo, preparado para virar APK.

## Núcleo incluído
- Interface de chat.
- Entrada por texto.
- Reconhecimento de voz.
- Respostas por Text-to-Speech.
- Memória local com até 200 eventos.
- Descoberta de aplicativos instalados e abertura por nome.
- Pesquisa na web.
- Abertura do cliente de e-mail.
- Atalhos de Home, Voltar e Recentes via AccessibilityService.
- Clique por texto em elementos da interface via AccessibilityService.
- Tela de permissões/configurações.
- Desenho com salvar localmente.
- Manifesto e ícone.
- Estrutura para AI Engine e plugins.

## Arquitetura para a versão realmente "Jarvis"
O app foi feito em módulos para receber:
AI Gateway -> Planner -> Permission Manager -> Plugin Manager -> Android Actions -> Memory.

### AI Gateway
O projeto não finge ter um modelo generativo offline gigante. Para respostas inteligentes, conecte um backend ou modelo compatível. A chave secreta deve ficar no servidor, não no APK.

### Plugins que podem ser adicionados
- E-mail
- Calendário
- Alarmes
- Navegador
- Arquivos
- Desenho/imagem
- Automação de apps
- Pesquisa web
- Calculadora
- Conversão de unidades
- Roblox Studio/API externa, se desejado
- Tarefas e lembretes

### Segurança
Acessibilidade é uma permissão poderosa. O usuário deve ativá-la manualmente. O projeto evita esconder o uso do serviço e mantém ações sensíveis sob controle do usuário.

## Como compilar
Abra esta pasta em Android Studio e faça Build > Build APK(s).
O APK de debug será produzido na pasta:
app/build/outputs/apk/debug/
