# Divine Earn App — Fresh Android Starter

This project starts Divine Earn from scratch.

Included:
- Android app project
- Tap Challenge
- Rewarded Ad integration using Google's official TEST rewarded-ad unit
- Wallet/history demo
- Production AdMob placeholder
- Secure-production notes

Before publishing:
1. Create your AdMob app and production Rewarded Ad Unit.
2. Replace the AdMob App ID in AndroidManifest.xml.
3. Replace REWARDED_AD_UNIT_ID in MainActivity.java.
4. Keep test ads enabled during development.
5. Build a secure backend for accounts, coins, ad verification and withdrawals.
6. Obtain approved Orange Money merchant/business/API access if Orange supports the intended payout flow.
7. Never put API secrets, OTPs, PINs or payment passwords in the APK.
8. Add privacy policy, terms, consent/data-safety disclosures and anti-fraud controls.
