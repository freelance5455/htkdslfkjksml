# CGPA NG Android App

This is the Android version of the CGPA NG website.

## What it uses
- Native Android WebView
- HTML/CSS/JavaScript bundled inside the APK
- No Node.js
- No server required
- LocalStorage keeps calculator data on the device

## Build
1. Open this folder in Android Studio.
2. Let Android Studio sync the Gradle files.
3. Select **Build > Build APK(s)**.
4. The debug APK will be generated under:
   `app/build/outputs/apk/debug/app-debug.apk`

## App ID
`com.cgpang.app`

## Included
- Semester management
- Course/credit/grade entry
- GPA and cumulative CGPA
- Academic classification
- Demo data
- Dark mode
- Saved progress
- Portrait mobile layout
