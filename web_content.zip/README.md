# SAHM Travel Agency — web app starter

A mobile-friendly front-end prototype based on the supplied SAHM Travel Agency screen design.

## Run it
1. Extract the ZIP.
2. Open `index.html` in a browser, or upload the folder contents to your web host (for example, Netlify).
3. The design adapts to mobile and desktop screens.

## Included
- Home page, destination list and destination detail
- Travel enquiry form
- Flight, hotel, bus, train and car rental service cards
- Offers page and local booking-enquiry list
- Customer account registration and sign-in prototype
- Generated customer ID in the form `SAHM123456`
- Google and phone sign-in buttons showing setup guidance
- Contact number: 9500795339

## Demo customer login
Create an account from the **Account** screen. The app generates a Customer ID for that account. Use either the registered email or Customer ID with the password you created to sign in.

There is no universal customer password included: each customer should create their own password.

## Important security and production notes
This ZIP is a front-end prototype, not a production authentication or booking system.
- Prototype account data is stored in browser `localStorage`. Passwords are not securely protected there. Use only test details; do not enter a real/reused password.
- Google sign-in and phone OTP are placeholders. To activate them, create a Firebase project, enable Google and Phone providers in Firebase Authentication, add your web app's Firebase configuration, implement the Firebase SDK sign-in flows, configure authorized domains, and set up appropriate abuse protection.
- For a real customer database, use a secure backend or Firebase/Firestore with security rules. Never store raw passwords yourself.
- Booking enquiries are saved only in the current browser. They are not sent to the travel agency, and this app does not issue tickets or process payments.
- Sample package prices are illustrative and must be confirmed before advertising or accepting bookings.

## Files
- `index.html` — pages and forms
- `styles.css` — responsive visual design
- `app.js` — navigation, demo account flow and local enquiries
- `assets/sahm-app-design.png` — supplied reference image, if included
