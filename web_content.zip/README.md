# PERSPICACE OS — local et en ligne

Le projet corrige l'écran vide en utilisant des sélecteurs DOM explicites.

## Mode local
Créer un profil propriétaire et un PIN. Entrant, Sortie, solde, historique et export/import JSON fonctionnent sans Supabase ni connexion.

## Activer la version en ligne (Firebase)
Le mode en ligne n'est pas activé tant que votre propre configuration Firebase n'est pas renseignée.
1. Créez un projet sur https://console.firebase.google.com/
2. Authentication > Sign-in method > activez Email/Password.
3. Créez une base Firestore.
4. Publiez le contenu de `firestore.rules`.
5. Project settings > General > ajoutez une application Web et copiez la configuration.
6. Dans `public/index.html`, remplacez les valeurs `REMPLACER_...` dans `const CFG` par celles de Firebase.
7. Hébergez le dossier `public` sur un site HTTPS (Netlify ou Firebase Hosting).
8. Dans Firebase Authentication > Settings > Authorized domains, ajoutez le domaine du site.
9. Testez avec deux comptes : chacun doit uniquement voir ses opérations.

Les règles Firestore limitent chaque utilisateur à son propre chemin `users/{uid}`. Vérifiez les règles et quotas Firebase avant d'y mettre des données réelles. La synchronisation des données locales vers le cloud n'est pas automatique.

## APK Android
Ce ZIP contient le projet web, pas encore un APK compilé. Pour compiler, un ordinateur avec Node.js et Android Studio est nécessaire. Copiez `public` dans un dossier `www`, initialisez Capacitor, puis exécutez `npx cap add android`, `npx cap sync android`, `npx cap open android`. Dans Android Studio, utilisez Build > Build APK(s). Générez un APK signé pour la distribution et gardez la clé de signature.
