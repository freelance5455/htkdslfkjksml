بدراک کرفت — نسخهٔ هفتم (آزمایشی)

هدف این نسخه: بهبود پشتیبانی چندزبانه در رابط کاربری موجود، بدون تغییر اساسی در ظاهر و حالت افقی نسخهٔ ششم.

زبان‌های رابط کاربری:
- فارسی (پیش‌فرض)
- انگلیسی
- عربی
- ژاپنی
- چینی
- تایلندی
- اسپانیایی
- فرانسوی
- آلمانی
- روسی

تغییرات نسخهٔ هفتم:
- حفظ زبان انتخاب‌شده در مرورگر با کلید ذخیره‌سازی مخصوص نسخهٔ هفتم؛ تنظیم قبلی هم برای سازگاری خوانده می‌شود.
- به‌روزرسانی عنوان صفحه و جهت نوشتار بر اساس زبان انتخاب‌شده.
- همگام‌سازی متن پنجرهٔ شروع/حالت افقی با زبان رابط کاربری.
- حفظ تصویر اصلی، چیدمان و تلاش برای نمایش افقی بدون برش.

روش آزمایش روی گوشی:
۱) ZIP را در پوشه‌ای جداگانه استخراج کن.
۲) فایل index.html را با Chrome باز کن.
۳) اگر پنجرهٔ شروع نمایش داده شد، دکمهٔ شروع را بزن و گوشی را افقی کن.
۴) از تنظیمات زبان، زبان‌های مختلف را انتخاب کن.
۵) زبان را تغییر بده و بخش‌های تنظیمات، دربارهٔ سایت، حساب نمایشی، ورود، اسکین‌ها و دانلودها را باز کن؛ بررسی کن عنوان‌ها و پیام‌ها عوض شوند.
۶) صفحه را ببند و دوباره باز کن تا ماندگاری زبان انتخابی را بررسی کنی.

محدودیت‌های مهم:
- نوشته‌هایی که داخل تصویر اصلی چاپ شده‌اند بخشی از خود تصویر هستند و با تغییر زبان رابط کاربری ترجمه نمی‌شوند؛ برای آن‌ها باید تصویر جداگانهٔ هر زبان طراحی شود.
- این نسخه نمونهٔ فرانت‌اند است؛ حساب واقعی، پیامک، سرور، آپلود/دانلود واقعی فایل و شبیه‌ساز واقعی Minecraft Bedrock هنوز پیاده‌سازی نشده‌اند.
- قفل جهت صفحه و تمام‌صفحه به مرورگر، شیوهٔ بازکردن فایل و سیاست‌های اندروید بستگی دارد؛ ممکن است لازم باشد چرخش خودکار گوشی را دستی روشن کنی.
- این نسخه هنوز برای انتشار عمومی آماده اعلام نشده است؛ طبق برنامه، پس از نسخهٔ دهم وارد مرحلهٔ آزمایش و رفع ایرادها می‌شویم و انتشار فقط با تأیید تو انجام می‌شود.


## Version 7.2 — main-menu language selector fix
The language selector is now placed directly over the language area at the top-right of the main artwork. It changes language in place without opening a separate language page. The selected language is saved in this browser. The language selection page remains accessible only if opened from other navigation code.


Version 7.3 fix: the main menu artwork contains baked-in Persian text. This build overlays live translated labels for the navigation buttons, skin heading, welcome panel, and language area. Some artwork lettering (especially the large logo) remains part of the image. Please test the selector on device.


## نسخه ۷.۴
- اصلاح جایگاه نوشته‌های ترجمه‌شده تا روی دکمه‌های اصلی قرار بگیرند، نه بیرون از منو.
- حذف پس‌زمینه‌های اضافه‌ای که شبیه دکمه‌های دوم دیده می‌شدند.
- کنترل انتخاب زبان در همان صفحه اصلی حفظ شده است.


Version 7.5: fixes duplicated menu labels by cleaning text areas from the background artwork and rendering translated labels as text only, rather than dark duplicate panels. Keep background-original.png in the same folder as index.html.


Version 7.6 repair: the main artwork is also embedded directly in index.html so it still appears if the browser/file viewer cannot resolve a neighboring image file. The original background PNG is retained in the ZIP. Extract all files before opening index.html for the most reliable experience.
