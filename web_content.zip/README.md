# उन्नती – ग्रामीण महिला कौशल्य विकास

ही ZIP **HTML + CSS + JavaScript** ची offline-friendly application coding आहे. कोणतेही external CDN/library आवश्यक नाही.

## Folder
- `index.html` – main application entry point
- `styles.css` – complete UI/design
- `app.js` – complete application logic
- `assets/unnati-logo.svg` – app logo

## Run
1. ZIP extract करा.
2. Folder उघडा.
3. `index.html` वर double-click करा किंवा VS Code मध्ये उघडा.
4. Create Account करा → Login/Dashboard वापरा.

## Included project points
Registration/Login, Digital Profile, AI Skill Assessment, AI Analysis, Skill Gap, Career/Business recommendation, Training + progress, Government Scheme discovery (DAY-NRLM/PMEGP/PMFME), AI Market Demand concept, Marathi/local voice assistant, Digital Marketplace, seller listing, orders/income demo, Village Skill Mapping, Smart Village concept, AI architecture, technology direction, Digital Safety & Privacy, expected benefits, impact and future scope.

## APK conversion
ही web application APK मध्ये wrap करता येते. Capacitor / Android WebView / Trusted Web Activity सारख्या मार्गांनी पुढे Android project तयार करता येईल. APK बनवताना production backend, secure authentication, HTTPS, real database, real AI/NLP, official government integrations, maps, payments/orders आणि privacy/security controls जोडणे आवश्यक आहे.

## Important
ही academic/demo prototype आहे. `localStorage` मधील password production security साठी योग्य नाही. Launch करण्यापूर्वी secure server-side authentication आणि database वापरा.
