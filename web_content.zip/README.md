# ساخت APK بازی «جاده هراز»

بازی داخل خود برنامه قرار می‌گیرد، بدون مرورگر و بدون آدرس اینترنتی.

## چیزهایی که لازم داری (روی کامپیوتر)
- Node.js (نسخه‌ی LTS) از nodejs.org
- Android Studio (همراه با Android SDK) از developer.android.com/studio

## مراحل
در پوشه‌ی همین پروژه یک ترمینال باز کن و به ترتیب اجرا کن:

```
npm install @capacitor/core @capacitor/android
npm install -D @capacitor/cli @capacitor/assets
npx cap add android
npx capacitor-assets generate --android
npx cap sync android
npx cap open android
```

در Android Studio منتظر بمان تا Gradle تمام شود (بار اول چند دقیقه طول می‌کشد)، بعد:

`Build` ← `Build Bundle(s) / APK(s)` ← `Build APK(s)`

فایل نهایی اینجاست:
`android/app/build/outputs/apk/debug/app-debug.apk`

## نصب روی گوشی
فایل را به گوشی بفرست (کابل، تلگرام، فضای ابری)، رویش بزن و در صورت سؤال، اجازه‌ی «نصب از منبع ناشناس» را بده. بعد از نصب، بازی با آیکون خودش بین برنامه‌هاست.

## نکته‌ها
- فونت فارسی (وزیرمتن و لالزار) از اینترنت لود می‌شود. بدون اینترنت، بازی کار می‌کند ولی متن‌ها با فونت پیش‌فرض گوشی نمایش داده می‌شوند.
- نسخه‌ی debug فقط برای استفاده‌ی شخصی مناسب است. برای انتشار در مارکت‌ها باید نسخه‌ی release امضاشده بسازی.
- اگر دستوری خطا داد، متن خطا را برای من بفرست.
