# 🏎️ Velocity Rush — 3D Street Racer

A high-quality 3D realistic car racing game built with **HTML, CSS, JavaScript and Three.js**.
Fully playable on **Android** (Chrome) and desktop — no build step, no external assets,
no network required (Three.js is bundled locally in `vendor/`).

## ▶ How to Run

**Easiest (Android):** copy the whole folder to your phone and open `index.html` in Chrome.
All assets are local, so it works straight from the file system.

**Desktop:** double-click `index.html`, or serve it (recommended for iOS Safari):

```bash
cd "Default Project"
python -m http.server 8000     # then open http://localhost:8000
```

## 🎮 Controls

### Mobile (touch)
| Control | Action |
|---|---|
| **Steering wheel** (bottom-left) | Drag around the wheel to steer; it springs back to center |
| **GAS pedal** (bottom-right) | Hold to accelerate |
| **BRAKE pedal** | Hold to brake / reverse |
| **▲ / ▼ gear buttons** | Shift up / down (R–N–1–6) |

### Desktop (keyboard)
| Key | Action |
|---|---|
| `W` / `↑` | Throttle |
| `S` / `↓` / `Space` | Brake |
| `A` `D` / `←` `→` | Steer |
| `Shift` / `E` | Shift up |
| `Ctrl` / `Q` | Shift down |
| `P` / `Esc` | Pause |

## ✨ Features

1. **Realistic 3D sports car** — procedurally built body, glass greenhouse, wing,
   splitter, spoked wheels, emissive head/taillights, env-mapped metallic paint.
2. **Mobile steering wheel** — rotatable wheel widget with spring return.
3. **Accelerator & brake pedals** — pressure-style hold pedals.
4. **Gear shifting** — 6-speed + R/N, torque-curve engine, rev limiter,
   clutch cut on shifts, engine braking.
5. **Highway & city environment** — endless recycled road segments with
   alternating CITY (neon-lit towers, billboards) and HIGHWAY (trees) zones,
   streetlights, guardrails, jersey median, dusk sky & fog.
6. **Traffic** — AI cars & trucks in 3 lanes with car-following, lane changes,
   plus oncoming traffic on the far carriageway.
7. **Realistic physics** — mass, aero drag, rolling resistance, lateral grip
   with slip/drift, speed-sensitive steering, body roll & pitch, crash damage.
8. **Third-person camera** — smoothed chase cam, speed-based pull-back & FOV,
   corner lean, crash shake.
9. **Engine sound** — fully synthesized WebAudio V8 (harmonic oscillators +
   exhaust noise + wind + tire hum), pitch/volume follow RPM, throttle & speed;
   shift blips and crash impacts.
10. **Mobile responsive** — viewport-fit HUD, safe-area insets, landscape
    rotate-hint, DPR-capped renderer for Android performance.

## 🗂 Project Structure

```
index.html            — app shell: menus, HUD, touch controls
css/style.css         — responsive UI styling
js/audio.js           — synthesized engine/exhaust/wind audio
js/input.js           — wheel + pedals + gear buttons + keyboard
js/car.js             — player car model + drivetrain/physics
js/environment.js     — endless road, city/highway zones, sky
js/traffic.js         — AI traffic, collisions, overtakes
js/camera.js          — third-person chase camera
js/main.js            — bootstrap, game states, loop, HUD
vendor/three.min.js   — Three.js r160 (local copy)
```

## 🧪 Scoring

Distance driven (m), top speed and overtakes are tracked; best run is
saved in `localStorage`. Fill the damage bar by crashing and the run ends.

## ⚙ Performance Notes (Android)

- Pixel ratio capped at 2×, antialiasing auto-disabled on high-DPI phones
- `MeshStandardMaterial` count kept low; shared geometries/materials for traffic
- No shadows; cheap blob shadows under cars
- Fog-limited draw distance (~600 m)
