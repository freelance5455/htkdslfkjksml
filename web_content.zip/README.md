# Ilostan Web

Webowa wersja Ilostanu przeznaczona do spakowania jako aplikacja mobilna przez builder typu ZIP → APK.

## Uruchomienie
Otwórz `index.html` w przeglądarce albo wrzuć cały folder/ZIP do buildera.

## Backend
Domyślnie aplikacja próbuje łączyć się z:
`http://localhost:3000/api`

Adres API można zmienić w konsoli przeglądarki:
`localStorage.setItem("ilostan_api","https://TWOJ-SERWER/api")`
i odświeżyć stronę.

## Funkcje
- katalog pojazdów i wyszukiwanie
- strony szczegółowe pojazdów
- statystyki
- logowanie/rejestracja
- dodawanie pojazdów
- komentarze
- responsywny interfejs mobilny

Jeżeli backend jest niedostępny, katalog pokazuje przykładowe dane demonstracyjne.

Uwaga: faktyczne logowanie, komentarze i dodawanie danych wymagają działającego backendu HTTPS. Integracja wyboru i wysyłania zdjęć jest pozostawiona do podpięcia konkretnego endpointu uploadu.
