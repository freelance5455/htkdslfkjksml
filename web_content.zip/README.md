# CoinScope Android starter project

This Android Studio project packages the CoinScope HTML dashboard inside an Android WebView. It includes internet permission and uses AndroidX WebKit's appassets origin so the dashboard can request online market data.

## Build an APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the extracted `coinscope-android` folder.
4. Allow Gradle sync and install any requested Android SDK components.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Use Android Studio's **Locate** link when the build finishes. The debug APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.
7. Copy it to your Android phone and install it. Android may ask you to allow installation from that source.

## Live-data notes
- Internet is required.
- The dashboard refreshes every 60 seconds and requests public CoinGecko API data. Rate limits or API/CORS changes may prevent updates.
- This prototype loads 100 coins per page, not every token worldwide.
- For a production app, consider a backend/proxy where provider terms or API keys require it. Never embed private API keys in the APK.

## Release build
Use **Build > Generate Signed Bundle / APK** in Android Studio. Keep the signing key private and backed up.


## Cloud build from GitHub Actions
This project includes `.github/workflows/build-apk.yml`. Upload the extracted project files to a GitHub repository on the `main` branch. GitHub Actions should start automatically on push, or you can run **Build CoinScope APK** from the Actions tab using **Run workflow**. When the run succeeds, open it and download the `CoinScope-debug-APK` artifact. GitHub may require signing in. This produces a debug APK for personal testing, not a signed Play Store release.
