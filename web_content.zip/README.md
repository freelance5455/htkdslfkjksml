# Vorlese App Pro V3 Piper (korrigiert)

Browserbasierte Vorlese-App mit Piper Offline-TTS (Thorsten) und Gerätestimmen-Fallback.

## Quick Start (Netlify)

1. Diese ZIP **unverändert** bei Netlify hochladen (Drag & Drop oder „Deploy manually“).
2. Warten bis **Published**.
3. Text einfügen oder TXT-Datei öffnen.
4. **Piper Deutsch – Thorsten (offline)** wählen → **Start**.
5. Beim **ersten** Start lädt die App das Modell (~63 MB) – Seite offen lassen.

## Was wurde korrigiert

- **Tempo-Slider** wirkt jetzt auch bei Piper (über `audio.playbackRate`).
- Modell-Proxy zeigt auf das offizielle Repo `rhasspy/piper-voices` (stabiler als der frühere Mirror).
- Service Worker interferiert nicht mehr mit `/piper-model/*` und aktualisiert Caches sauber.
- Code lesbarer und robuster, gleiche API und gleiche Tests.

## Architektur

- Piper-Bibliothek lokal unter `vendor/piper-tts-web.bundle.js`.
- Modelle über Netlify-Proxy `/piper-model/*` → Hugging Face (Same-Origin, kein CORS).
- Abschnittsweise Synthese + automatische Fortsetzung.
- Gerätestimmen als Fallback bei Piper-Fehler.

## Offline

Nach dem ersten erfolgreichen Piper-Lauf speichert die Bibliothek das Modell in IndexedDB. Danach funktioniert die Synthese auch offline (Flugmodus), solange der Browser die Seite nicht komplett leert.

## Tests

- `tests/browser_test.py` – Chromium-Integration (Mock-Piper)
- `tests/redirect_config_test.py` – Proxy-Regeln
- `tests/live_piper_test.py` – echter Live-Test gegen deine Netlify-URL

## Wichtig

Der erste Modell-Download braucht Internet und etwas Zeit. Danach ist die Stimme lokal verfügbar.
