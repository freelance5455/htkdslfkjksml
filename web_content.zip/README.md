# Blast King (by Wise Inc)

Block puzzle game wrapped as an Android app with Capacitor. GitHub builds the APK for you.

## First build (test APK)
1. Create a GitHub repository (private is fine), e.g. `blast-king`.
2. Upload these files to the repository root: `index.html`, `package.json`,
   `capacitor.config.json`, `icon-only.png`, `icon-foreground.png`, `icon-background.png`,
   `splash.png`, `splash-dark.png`, `README.md`.
3. Add the workflow: Add file > Create new file > name it `.github/workflows/android.yml`
   (typing the slashes creates the folders) and paste the YAML. Commit.
4. Open the Actions tab > "Build Blast King (Android APK)" > Run workflow (it also runs on every push).
5. When it shows a green tick (about 5-10 minutes), open the run and download the
   `blast-king-apk` artifact. Unzip it and install `app-debug.apk` on your phone
   (allow "install unknown apps" for your browser or file manager).

If a run fails, open the failed step, copy the red error text and send it to me.

## Later: ads
Add the AdMob account, then add an ad plugin in `package.json` and call it from the game:
interstitial after a game over (about every 8 minutes), rewarded ad on the Revive button.
Use Google's TEST ad IDs until the release build.

## Later: Google Play release
Create a signing key (keystore), add the 4 secrets listed at the top of
`.github/workflows/release.yml`, then run that workflow to get a signed `.aab`.
The app id `com.wiseinc.blastking` cannot be changed after the first Play upload.
