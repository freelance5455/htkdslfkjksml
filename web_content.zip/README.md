# GM Pay — projet complet

GM Pay est une base d'application de portefeuille numérique conçue autour de :
- inscription par numéro de téléphone et OTP
- portefeuille multi-devises
- envoi/réception d'argent
- paiements marchands et QR
- facturation
- paiements internationaux
- conversion de devises
- historique et reçus
- sécurité, PIN et contrôles anti-fraude
- frais d'activation proposés à 1 USD
- architecture prête à connecter aux fournisseurs de paiement.

IMPORTANT
Cette version est une base fonctionnelle de démonstration avec backend local sécurisé.
Les mouvements d'argent réels, Mobile Money, banques, cartes, paiements internationaux et
crédit/paiement différé nécessitent des fournisseurs agréés, des clés/API réelles et les
autorisations réglementaires correspondantes. Aucun faux paiement n'est présenté comme réel.

Démarrage:
1. Installer Node.js 20+
2. cd backend && npm install && npm start
3. Ouvrir http://localhost:3000

Variables:
PORT=3000
ACTIVATION_FEE_USD=1
