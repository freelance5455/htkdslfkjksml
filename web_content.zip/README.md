# DRACO PWA

This folder is a cross-platform, installable web app version of DRACO. It uses the same `index.html` on desktop and mobile. Checklist items, chat history, model preference, and extra instructions are saved in this browser on this device.

## OpenAI connection

Use **AI setup** in the app to enter an OpenAI API key, choose a model ID (default: `gpt-6-luna`), and add personal context or response instructions. Without a key, DRACO stays in local demo mode. API calls use OpenAI's Responses API and send the recent chat history plus your instructions; the request sets `store: false`.

The key is held for the session unless **Remember the API key on this device** is checked. The app warns about the risk: OpenAI advises keeping API keys on a backend rather than in browser or mobile apps. This direct-key option is for personal testing only. Do not share an APK containing a key. ChatGPT subscriptions and API usage are billed separately.

## Run and install

For a quick preview, open `index.html` in a browser. For install and offline shell support, publish the contents of this folder to an HTTPS website (or use `localhost` while developing). Service workers and app installation are restricted when opened as a `file://` page.

After hosting, open the HTTPS address in a supported browser and use its **Install app** or **Add to Home Screen** command. The exact install option varies by OS and browser. Voice input availability also varies.

## Convert this ZIP to an Android APK

The ZIP has `index.html` at its root, which HTML-to-APK builders typically require. The APK will be Android-only. Some builders may block network requests from bundled pages; if OpenAI requests fail inside the APK, use the hosted PWA or a secure backend proxy.

## Files

- `index.html` — DRACO app
- `manifest.webmanifest` — app name, icon, and install settings
- `service-worker.js` — offline shell and cached static assets
- `icons/` — app icons for install surfaces

When changing the app shell, increment `CACHE_NAME` in `service-worker.js` so installed copies refresh.
