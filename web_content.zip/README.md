# Wellbeing Officer - Ready for APK

This folder is ready to convert to Android APK.

## Files:
- index.html = your app (single file, offline-ready)
- manifest.json = PWA manifest
- service-worker.js = offline cache
- capacitor.config.json = for Capacitor build

## OPTION 1: Fastest (No Code) - Use PWABuilder / Bubblewrap
1. Go to https://www.pwabuilder.com
2. Upload this folder to your hosting OR host index.html somewhere (Netlify, Vercel, GitHub Pages)
3. Enter URL → PWABuilder will generate APK/AAB
4. Download .apk

## OPTION 2: Capacitor (Local Build - Recommended for Play Store)
```bash
npm install -g @capacitor/cli
npm init -y
npm install @capacitor/core @capacitor/android
npx cap init
# copy this folder contents to www or set webDir
npx cap add android
npx cap copy
npx cap open android
# Then build APK in Android Studio: Build > Build APK
```

## OPTION 3: Use AppsGeyser / WebIntoApp
1. Go to appsgeyser.com or webintoapp.com
2. Choose "Website to App"
3. Upload index.html or enter hosted URL
4. Download APK instantly

## Android Settings Already Done:
- display: standalone (no browser bar)
- theme color set
- offline ready via service worker
- portrait orientation
- appId: com.iswan.wellbeingofficer
- All progress saved in localStorage (works in WebView)

Just host and wrap.
