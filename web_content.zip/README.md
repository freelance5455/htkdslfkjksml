<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/52bf4d79-1b18-4b50-a69e-856831bb2ea4

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.


## Gemini 3+ model configuration

The Android app uses Firebase AI Logic with `gemini-3.8-flash` for standard chat
and `gemini-3.5-flash-lite` for fast background tasks such as chat titles and
memory extraction. The HTML chat offers Gemini 3.8 Flash, 3.7 Flash,
3.5 Flash-Lite, and 3.1 Pro Preview. A Gemini API key is required for the
standalone HTML chat; enter it in FLAMI AI settings. Do not publish the key
inside the project or share it publicly.
