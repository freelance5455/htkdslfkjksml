# HTMLtoAPK FIQYY

Project starter untuk web app pembuat APK berbasis upload HTML/ZIP.

## Fitur
- Splash screen modern bertema navy, biru, dan cyan.
- Tanpa login atau konfigurasi Firebase.
- Dashboard upload file `.html`, `.htm`, atau `.zip`.
- Pengaturan nama aplikasi dan Android package ID.
- Endpoint backend `/api/build` sebagai titik integrasi mesin build Android.

## Menjalankan tampilan
Perlu Node.js 18 atau lebih baru.
```bash
npm install
npm start
```
Buka `http://localhost:3000`.

## Tentang build APK
UI dan upload sudah disiapkan, tetapi APK sungguhan tidak dapat dikompilasi hanya oleh HTML di browser. Build Android memerlukan mesin backend/CI yang memiliki Java JDK, Android SDK, Gradle, dan Capacitor. Endpoint `/api/build` saat ini sengaja mengembalikan HTTP 501 sampai worker build terisolasi dikonfigurasi.

Untuk produksi:
- Jalankan build worker terpisah dalam container/VM.
- Validasi dan ekstrak ZIP secara aman (tolak path traversal, symlink, file terlalu besar).
- Jangan menjalankan file upload sebagai script server.
- Gunakan antrean job, batas waktu, batas CPU/RAM, dan hapus file sementara.
- Jika endpoint dipakai secara publik, lindungi dengan autentikasi server-side dan rate limit.
- Setelah build berhasil, sediakan APK melalui tautan unduhan sementara.


## Struktur
- `public/` — HTML, CSS, JavaScript frontend.
- `server/index.js` — Express backend starter.
- `package.json` — dependency dan perintah menjalankan server.
