# Atlas Quest — World Flag Academy

An original, mobile-first flag quiz prototype designed for Android. Includes a responsive quiz loop, 195 country/observer-state entries, four-choice questions, XP, hearts, streaks, achievements, continent paths, searchable encyclopedia, local progress, sound feedback, confetti and offline caching. The visual globe is a lightweight CSS illustration so this first build stays responsive on mid-range phones.

## Run locally

Requirements: Node.js 20+ and npm.

```bash
npm install
npm run start
```
Open the local URL shown by Vite. For a production web build:

```bash
npm run build
```

## Build an Android APK

Requirements: Node.js 20+, Android Studio, Android SDK (API 35 recommended), and a JDK supported by your installed Android Gradle Plugin.

```bash
npm install
npm run build
npx cap add android       # only once
npx cap sync android
npx cap open android
```

In Android Studio, wait for Gradle sync, choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**. The debug APK is normally at `android/app/build/outputs/apk/debug/app-debug.apk`. To distribute publicly, configure a release signing key and use **Build → Generate Signed Bundle / APK**. This repository does not contain a prebuilt APK; build it on a machine with the Android toolchain.

## Core test checklist

- Quiz generation produces four distinct choices and one correct answer.
- Correct answer adds 10 XP, increments streak and marks the flag as learned.
- Incorrect answer reduces hearts by one and resets the streak.
- Quiz completion shows score and accuracy.
- Country encyclopedia supports name/code search and region filters.
- Progress is stored locally using `localStorage`; the service worker caches app assets for offline use after first successful load.
- Reduced motion is respected by CSS; sound effects can be toggled in Progress → Settings.

## Notes / next production pass

- Flags currently use Unicode regional-indicator emoji, which depends on the Android system emoji font and may render differently by device. For pixel-identical flag art, bundle reviewed SVG flag assets locally.
- The included list contains 193 UN members plus the Holy See and Palestine (195 entries). Regional groupings are for learning-path navigation, not geopolitical classification.
- This is the playable core, not a fully audited commercial release. Add automated unit/e2e tests, device profiling, offline install tests, reviewed flag SVGs, localized accessibility labels and licensing review before publishing. Three.js/R3F 3D globe and rigged animated mascot are a planned premium-animation phase; they are not implemented in this first core build.
