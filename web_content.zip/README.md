# Route Planner – Android build

The Android app is a WebView shell around `app/src/main/assets/index.html`
(your route-planner.html, unchanged).

## Build the APK
1. Open this folder in Android Studio (Hedgehog or newer).
2. Let Gradle sync (it generates the Gradle wrapper automatically).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
   The debug APK appears at app/build/outputs/apk/debug/app-debug.apk.
   Or from a terminal: `gradle assembleDebug` (requires Gradle installed).

## Notes
- Requires internet: map tiles, Leaflet, JSZip and the OSRM routing server load online.
- Min Android version: 10 (API 29). Exports save to the Downloads folder.
- Location: the app asks for location permission when you press "locate me".
- For Play Store release, sign with a release keystore (Build > Generate Signed App Bundle/APK).

## Build in the cloud (no local setup)
Push this folder to a GitHub repository. The workflow in
.github/workflows/build-apk.yml builds the debug APK automatically.
Open the Actions tab, pick the latest run, and download
"route-planner-debug-apk" from the Artifacts section.
