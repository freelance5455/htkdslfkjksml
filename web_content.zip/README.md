# Mi Trastero: crear el APK

Necesitas: Node.js 18+ y Android Studio (gratis).

1. En esta carpeta: `npm install`
2. `npx cap add android`
3. Abre `android/app/src/main/AndroidManifest.xml` y añade, dentro de <manifest>:
   `<uses-permission android:name="android.permission.CAMERA"/>`
   `<uses-permission android:name="android.permission.INTERNET"/>`
4. `npx cap sync android` y luego `npx cap open android`
5. En Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
   El archivo queda en android/app/build/outputs/apk/debug/app-debug.apk. Cópialo al móvil e instálalo.

## Cámara inteligente
La primera vez que hagas una foto, la app pide tu clave de la API de Anthropic (console.anthropic.com).
Se guarda solo en tu móvil. Cada foto cuesta unos céntimos.

## Lo que cambia respecto a la versión web
- La cuenta en la nube no está: los datos se guardan en el móvil. Haz copias desde Ajustes (Copiar copia).
- El lector de códigos de barras depende de que el WebView del móvil lo admita; si no, escribe el código a mano.
- Para una cuenta real (Firebase) o copia en Google Drive hay que añadir ese módulo aparte.
