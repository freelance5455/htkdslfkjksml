# Kushi Nine Star Ki (native Java Android project)

This is a **native Android/Java Gradle project**, not Expo. It embeds the tested single-page offline HTML translator in a WebView and uses the user-supplied complete book cover as the single bottom image.

Project root contains `settings.gradle`, `gradlew`, and the `app` module to match the builder's supported format. There is intentionally no package.json and no bun.lock.

Build locally: `./gradlew assembleDebug` (APK at `app/build/outputs/apk/debug/app-debug.apk`).

The included `gradlew` is a self-contained shell launcher: it uses an installed Gradle command if available, otherwise downloads Gradle 8.13 to the user's Gradle cache. Android Gradle Plugin 8.9.2, Java 17, compile SDK 35. An internet connection or preinstalled/cached Gradle and Android build dependencies are needed for the first build.

The daily star still requires a calendar anchor from a verified Michio Kushi source. The app does not pretend to know an unverified date alignment.

## Month Star addition
The app now calculates natal month and current month using Michio Kushi Figure 12 month table and Figure 10 approximate entry dates, with boundary warnings. Daily cycle still requires an independently verified Kushi anchor.


UI update: centered hero title/description and replaced the intro paragraph with a true app description.

## v3.3.0 — Banner, palaces, PDF export
- The banner centers the existing logo and app title over a soft botanical / Lo Shu-themed gradient.
- Dynamic South-up Lo Shu 3×3 chart: the fixed home palaces are 4-9-2 / 3-5-7 / 8-1-6, while daily stars fly center → NW → W → NE → S → N → SW → E → SE. Center shows the verified daily star, not a fixed 5; the small home label identifies the fixed palace.
- Natal home palace is outlined, with the daily visitor and natal star's current visiting palace explicitly distinguished.
- Export PDF button creates an offline, readable multi-page PDF with daily/natal/month details, palace overlay, and interpretation. In Android it invokes the system Save As PDF document picker via a limited local JavaScript bridge. The standalone HTML uses browser downloads.
- Example: day center 8 gives 7 at natal 4's Southeast home palace; 4 itself visits the North (1) palace. This is an interpretive overlay, not a new natal number.
- Daily date/number accuracy is still conditional on a verified Kushi daily calendar anchor; the app intentionally does not fabricate one.

Build note: Android .apk is NOT included in this v3.3.0 package; the existing uploaded v2 APK does not contain the changes. Use Android Studio or a compatible Android Gradle builder to compile this project's app module.

## v3.4 — Natal home translation subfield
- Keeps the original daily number unchanged, e.g. day 8 remains 8.
- Adds a compact daily-focus subfield showing the visiting star in the user's fixed natal home palace, e.g. natal 4 home receives 7 on an 8 day.
- On the existing dynamic palace grid, the natal home is outlined (with its visitor underlined) and the natal star's actual traveling position is circled. No other reading logic was altered.
- PDF adds an explicit palace-translation entry without changing the daily focus.
