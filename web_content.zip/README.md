# CBE School Manager — Louis Macharia (Android project)

This is an Android Studio source project using the supplied Louis CBE Analyzer image as the app's visual background and a green accent theme. It includes the provided SQLite schema as an app asset.

## Important status
This ZIP is **source code, not a compiled APK**. The current screen is a branded UI preview. The included SQL file is bundled as an asset but is **not yet wired to a live SQLite database**. Learner/marks entry, full database CRUD, online sync, SMS, PDF reports, and production security need implementation and testing before real school use.

## Build an APK
1. Install Android Studio (Giraffe or newer) with Android SDK Platform 35.
2. Open this project folder in Android Studio.
3. Allow Gradle sync and install any requested SDK components.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. For a release APK, configure a signing key in **Build > Generate Signed Bundle / APK**.

Application ID: `ke.louismacharia.cbeschoolmanager`
Minimum Android version: Android 6.0 (API 23)
