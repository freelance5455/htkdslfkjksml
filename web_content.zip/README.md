# XVDO - Video Streaming Web Application

XVDO is a modern, responsive, mobile-first video streaming platform built with **PHP 8+**, **MySQL (PDO)**, **Tailwind CSS**, and **HTML5**. It provides a high-performance streaming environment allowing users to browse, search, and stream videos while empowering administrators with a secure portal to manage content, categories, users, and server upload parameters.

---

## 🚀 Key Features

### 👤 User Experience
- **Mobile-First Dark Interface**: Deep obsidian theme with electric blue and violet accents.
- **Interactive Dashboard**: Hero billboard banner, category filter chips, popular streams, latest uploads, and continue-watching history.
- **HTML5 Streaming Video Player**: Play/pause, seek, volume, speed, fullscreen, and keyboard shortcuts (`Space` toggle, `F` fullscreen, `Arrow` seek).
- **Video Library & Search**: Full-text search with category filters and multiple sorting options (Latest, Most Popular, Oldest).
- **Category Browser**: Thematic browsing by genre (Action, Sci-Fi, Documentaries, Tech, Nature, Music).
- **Personal Profile & Watch History**: Account profile management, password updates, and personal stream history tracking.
- **Zero Framework Bloat**: Clean, native PHP form handling with zero AJAX or client-side framework dependencies.

### 🛡️ Administration Portal (`/xvdo/admin`)
- **Separate Admin Authentication**: Isolated admin login with strict role-based session enforcement.
- **Real-Time Analytics Dashboard**: Live counters for total registered users, video catalog size, total video views, and genres.
- **Video Management**:
  - Upload MP4/WebM video files directly to server storage. Android uploads use 4 MiB chunks to avoid single-request size limits.
  - Support for **External Stream URLs** (Cloud CDN, direct MP4, or YouTube embeds) for files exceeding shared hosting limits.
  - Custom thumbnail uploads (JPG, PNG, WebP) or external image URLs.
  - Instant publish/unpublish toggles and featured hero billboard promotion.
  - Video editing and deletion with automatic file cleanup.
- **User Management**:
  - View all registered accounts and their streaming statistics.
  - Search members by name, email, or phone.
  - Instant account activation/deactivation toggle.
  - Account deletion with cascading history cleanup.
- **Category Management**:
  - Add, edit, or delete categories with custom Font Awesome icons and automatic slug generation.
- **Portal Settings**:
  - Change administrator password with current password verification.
  - Modify website branding (site name, tagline, support contact).
  - Inspect server PHP environment constraints (`upload_max_filesize`, `post_max_size`).


### Android MTX media upload notes
- The Android client sends media to `POST /api/upload/chunk` in sequential 4 MiB binary chunks. The server assembles the chunks and responds with a media URL only after the complete file is written.
- Deploy the updated `server.js` before installing an updated Android build; older server deployments do not include the chunk endpoint.
- The Node server currently writes uploads to its local `uploads/` directory. This is suitable for a persistent VM or disk-backed host, but **not durable storage on ephemeral/serverless instances**. For Cloud Run or similar hosts, configure a persistent object-storage bucket and serve media from that bucket before relying on uploaded videos in production.

### 🔒 Enterprise Security
- **PDO Prepared Statements**: 100% parameter binding against SQL injection.
- **CSRF Protection**: Cryptographically secure token verification on all form submissions.
- **Password Security**: Passwords hashed and verified via `password_hash()` and `password_verify()` (`PASSWORD_BCRYPT`).
- **Session Regeneration**: Protection against session fixation on authentication and logout.
- **File Upload Safeguards**: MIME type checking via `finfo_file`, extension validation, randomized cryptographic file renaming, and execution blocking via `.htaccess`.
- **XSS Prevention**: Context-aware output escaping (`htmlspecialchars`).

---

## 📁 Project Structure

All source files are available in the `/xvdo/` directory ready for deployment to any standard PHP 8+ hosting environment:

```text
xvdo/
├── index.php                  # Public landing / discover page (guest showcase)
├── login.php                  # User sign-in
├── register.php               # User registration
├── logout.php                 # User session termination
├── dashboard.php              # Authenticated user streaming hub
├── watch.php                  # HTML5 video player and watch history logging
├── category.php               # Category-filtered video browser
├── search.php                 # Full catalog search with filters
├── profile.php                # User profile and watch history management
├── config/
│   └── database.php           # PDO connection singleton & environment credentials
├── includes/
│   ├── auth.php               # Authentication checks & session state
│   ├── functions.php          # Security helpers, CSRF, escaping, upload handler
│   ├── header.php             # Responsive top navigation & category dropdown
│   └── footer.php             # Responsive footer with administrative links
├── admin/
│   ├── index.php              # Admin portal router
│   ├── login.php              # Dedicated administrator login
│   ├── logout.php             # Admin session termination
│   ├── dashboard.php          # Admin statistics and activity overview
│   ├── videos.php             # Video catalog manager (status, delete, edit)
│   ├── upload.php             # Video & thumbnail uploader (file & URL support)
│   ├── edit-video.php         # Video metadata & thumbnail editor
│   ├── users.php              # User account management & status toggles
│   ├── categories.php         # Genre CRUD management with icon picker
│   ├── settings.php           # Admin password & platform branding
│   └── includes/
│       ├── header.php         # Admin navigation sidebar & topbar
│       └── footer.php         # Admin footer layout
├── uploads/
│   ├── .htaccess              # Script execution lock & security policy
│   ├── videos/                # Uploaded MP4/WebM video files
│   └── thumbnails/            # Uploaded JPG/PNG/WebP thumbnails
├── assets/
│   ├── css/
│   │   └── custom.css         # Dark theme styling, glowing accents, scrollbar
│   └── js/
│       └── main.js            # Mobile drawer, dropdowns, player shortcuts
├── database.sql               # MySQL database schema & rich seed data
└── README.md                  # Complete documentation
```

---

## 🛠️ Installation & Setup Guide

### 1. Requirements
- **Web Server**: Apache, Nginx, LiteSpeed, or XAMPP / WAMP / MAMP.
- **PHP**: PHP 8.0, 8.1, 8.2, or 8.3 with `pdo_mysql`, `fileinfo`, `session`, and `json` extensions.
- **MySQL**: MySQL 5.7+, 8.0+, or MariaDB 10.3+.

---

### 2. Step-by-Step Installation on Shared Hosting (cPanel / DirectAdmin / Plesk)

#### Step 1: Upload Files
1. Log into your hosting control panel (e.g. cPanel File Manager).
2. Upload the `xvdo` folder (or copy all contents of `xvdo/` directly into your domain's `public_html` root directory).

#### Step 2: Set Folder Permissions
Ensure the upload directories are writable:
- `uploads/videos/` -> `chmod 755` (or `775`)
- `uploads/thumbnails/` -> `chmod 755` (or `775`)

#### Step 3: Create & Import MySQL Database
1. In cPanel, navigate to **MySQL Databases**.
2. Create a new database named `xvdo_db`.
3. Create a MySQL user and grant **ALL PRIVILEGES** to `xvdo_db`.
4. Open **phpMyAdmin**, select `xvdo_db`, click the **Import** tab, choose `database.sql`, and click **Go**.

#### Step 4: Configure Database Credentials
Open `config/database.php` in a text editor and enter your database credentials:

```php
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'xvdo_db');      // Your cPanel db name
define('DB_USER', 'xvdo_user');    // Your cPanel db user
define('DB_PASS', 'your_password'); // Your cPanel db password
```

---

## 🔑 Default Credentials

### Administrator Login (`/admin/login.php`):
- **Email**: `admin@xvdo.com`
- **Password**: `admin123`
*(Remember to change this password in Admin Settings after logging in!)*

### Demo Member Login (`/login.php`):
- **Email**: `demo@xvdo.com`
- **Password**: `user123`
