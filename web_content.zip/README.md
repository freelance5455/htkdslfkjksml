# SURVIVAL: LAST NIGHT — Prototype

First-person 3D browser prototype.

## Run
Open `index.html` in a modern browser with internet access.
The prototype loads Three.js from a CDN.

## Controls
WASD = move
Mouse = look
Click = shoot
Shift = sprint
R = restart after death

## Goal
Survive the creatures and reach the glowing green extraction zone.
