# GODEX — Autonomous Generative Media Studio

GODEX is a React/TypeScript web application with an Express backend. It includes project-aware engineering workflows, starter application templates, deterministic browser media tools, media validation/export utilities, and optional AI/remote-engine integrations. Capabilities that require an external model, credentials, or a local runtime remain dependent on that configuration.

## Requirements

- Node.js 20 or newer
- Dependencies installed from the project manifest and lockfile
- Optional: `GEMINI_API_KEY` for server-side Gemini responses. Never commit or share real credentials.

## Run locally

```bash
npm install
npm run dev
```

The development server is configured to run on port 3000. If your environment uses Bun, `bun install` is supported by the included `bun.lock`.

## Checks

```bash
npm run lint
npm run build
npx tsx run-tests.ts
```

A passing build or unit test does not by itself prove that neural video inference is available. Real neural generation requires a compatible configured provider/runtime and model. Browser-native deterministic media output is a separate capability.

## Security notes

- Keep `.env`, `.env.local`, tokens, and credentials out of exported archives and source control.
- Use `.env.example` only as a placeholder reference; provide your own secrets through the target environment.
- Optional ComfyUI, Hugging Face, Colab, and Kaggle integrations should only be used when configured and intentionally enabled.
