# ANONYMOUX STUDIO 2.5.6

This release includes the screenshot-led visual refresh and Fish Audio Agent Studio endpoint/billing repairs. See `CHANGELOG_2.5.6.md`, `FISH-AUDIO-AGENT-REPAIR-2.5.6.md`, `INSTALLATION_2.5.6.md`, and `TEST_REPORT_2.5.6.md` before deployment.

# ANONYMOUX STUDIO 2.3.2 — Creator Dashboard & Resource Centre

This source package is the ANONYMOUX STUDIO 2.5.1 navigation-repair build. It retains the account-aware creator dashboard, unified Tools & Tutorials centre, administrator resource editor, private tutorial media, existing workspaces, authentication, wallet and provider integrations. Persistence is configured for PDO SQLite only.

**Deploy over the existing application only after backing up the live database, `storage/` and private server configuration. Do not reset the production database or overwrite `config.local.php`.** See [`DEPLOYMENT_GUIDE_2.3.2.md`](DEPLOYMENT_GUIDE_2.3.2.md), [`SOURCE_AUDIT_FILE_BY_FILE.md`](SOURCE_AUDIT_FILE_BY_FILE.md), [`DASHBOARD_IMPLEMENTATION_REPORT.md`](DASHBOARD_IMPLEMENTATION_REPORT.md), [`TOOLS_TUTORIALS_IMPLEMENTATION_REPORT.md`](TOOLS_TUTORIALS_IMPLEMENTATION_REPORT.md) and [`TEST_RESULTS.md`](TEST_RESULTS.md).

Build validation: 49/49 PHP syntax checks and 8/8 JavaScript syntax checks passed; SQLite migration test passed. PHP/PDO live persistence, cURL provider requests, administrator CRUD against a live database and device/browser checks were not available in the build environment.

---

# ANONYMOUX STUDIOS — AI Creative Workspaces

A complete PHP shared-hosting workspace for live Decart video transformation with Lucy 2.5 and Lucy 2.6. The dashboard includes a responsive dual-video workspace, selectable models, a scrollable prompt library, persistent custom prompts, reference-image uploads, and working session controls.

## Integration design

**Default: Decart SDK Direct.** The browser uses Decart's official JavaScript realtime SDK and connects directly to Decart over its realtime transport. PHP mints a short-lived client token immediately before the SDK dials. The camera/video stream is handled by the SDK and WebRTC; the PHP server does not relay live video and does not need a persistent Node process or a WebSocket server.

**Optional: HTTP Signaling.** The project also includes PHP routes for Decart's HTTP Signaling flow. Decart currently marks HTTP Signaling as a private-preview integration. Do not enable it unless Decart has granted your account access. Set `realtime_transport` to `http-signaling` in `config.local.php` to opt in; otherwise leave the default `sdk-direct` setting.

Both models are listed with their exact documented identifiers:

- `lucy-2.5` — pinned Lucy 2.5 realtime model.
- `lucy-2.6` — Lucy 2.6 realtime model and the dashboard default.

Decart's current Lucy 2.5 and Lucy 2.6 model pages explicitly document text prompts and reference images for both versions. The app does not silently fall back to a different model if your API account cannot access the selected one.

## Included features

- Model selector for Lucy 2.5 and Lucy 2.6; switching while live disconnects the current model before starting the newly selected one.
- A horizontally scrollable, touch-friendly prompt strip, search, category filtering, and selected-card state.
- Built-in starter prompts across the ten requested categories.
- Create, edit, duplicate, and delete custom prompts; custom prompts persist in the private SQLite database.
- JPEG, PNG, and WebP reference-image uploads, private previews, validation, metadata, progress feedback, replace, and remove.
- In SDK Direct mode, the browser retrieves the private uploaded file from this PHP app and passes a real `File` to Decart's SDK as the documented `image` input. It is included in `initialState` on session start and passed again in atomic `set()` updates when prompts or images change. The preview itself is not treated as the Decart integration.
- No reference-strength slider: the documented Lucy realtime API does not expose a reference-strength parameter.
- Side-by-side portrait-oriented INPUT and TRANSFORMED OUTPUT frames at the top of the workspace, with session controls immediately beneath the frames and all setup panels (model, prompt library, reference image, and prompt editor) below them on desktop and mobile.
- Start, stop, pause/resume input, camera switch, prompt apply, output-only fullscreen, and reset controls.
- Microphone is not requested; this is a video-only workspace.
- Authenticated user accounts with registration, login, session-backed access control, and administrator-only management. Some legacy workspace records still use browser owner keys for resource ownership; see the deployment notes before relying on those legacy records as account-level billing data.
- The permanent Decart API key is only read by PHP and is never sent to the browser.

## Requirements

- PHP 8.1 or newer recommended.
- PHP extensions: `curl`, `fileinfo`, `mbstring`, `PDO`, and `pdo_sqlite` (PDO SQLite; this build uses SQLite only).
- HTTPS with a valid certificate. Camera access and WebRTC require a secure browser context.
- A Decart API key with realtime access to the requested Lucy models.
- PHP write access to `storage/`.
- Browser access to `https://esm.sh` to load the Decart JavaScript SDK at runtime, unless you replace that CDN import with a locally bundled official SDK build.
- A current browser with MediaDevices, WebRTC, and ES modules (recent Android Chrome and iOS Safari).

## Install on cPanel or ordinary PHP shared hosting

1. Upload the ZIP contents into a web folder, for example `public_html/realtime/`.
2. Enable HTTPS and make sure PHP can write to the `storage/` directory. `750` or `770` is usually appropriate; avoid `777` unless your host specifically requires it.
3. Copy `config.local.example.php` to `config.local.php` on the server and add your newly rotated Decart API key. The deliverable deliberately excludes live credentials.
4. Keep this ZIP and the deployed `config.local.php` private. Do not commit either to a public GitHub repository or share them publicly. The root `.htaccess` denies direct HTTP access to `config.local.php`; on Nginx, add an equivalent deny rule.
5. In cPanel PHP settings, set `upload_max_filesize` to at least `6M` and `post_max_size` to at least `7M` so the 5 MB reference upload limit can be reached. The app uses PDO SQLite automatically; no MySQL database or DSN is needed. The database and built-in prompt library are initialized automatically on first request. Ensure `pdo_sqlite` is enabled and PHP can write to `storage/`.
6. Keep `realtime_transport` set to `sdk-direct` unless Decart has explicitly granted HTTP Signaling private-preview access.
7. Open the workspace over HTTPS, grant camera permission, choose a model, select a prompt/reference image, and click **Start transformation**.

The included `.htaccess` files disable directory listing and deny direct access to local configuration and private storage files. If your host uses Nginx, configure equivalent deny rules in the hosting control panel/server configuration because Nginx does not read `.htaccess`.

## Configuration

Example `config.local.php` (reference only; the delivered ZIP intentionally excludes private credentials):

```php
<?php
return [
    'decart_api_key' => 'YOUR_PERMANENT_DECART_API_KEY',
    'decart_api_base' => 'https://api.decart.ai/v1',
    'realtime_transport' => 'sdk-direct',
];
```

Use the `DECART_API_KEY` environment variable if your host supports it. Database configuration is intentionally not exposed: the app always uses its private SQLite database.

## Request/API map

All local write endpoints require the browser's PHP-session CSRF token and same-origin request.

| Local endpoint | Function |
|---|---|
| `GET api/config.php` | Reports model options, selected preferences, transport, API-key readiness, and reference metadata. |
| `POST api/client-token.php` | Uses the permanent server key to mint a five-minute client token scoped to the selected Lucy model and (when supplied) browser origin. Used by SDK Direct. |
| `GET api/prompts.php` | Loads built-in and this browser's custom prompts. |
| `POST api/prompts.php` | Creates, updates, duplicates, or deletes custom prompts. |
| `GET api/workspace.php` | Reads saved workspace preferences. |
| `POST api/workspace.php` | Saves selected model, prompt, and enhancement preference. |
| `GET api/reference.php` | Reads private reference metadata. |
| `POST api/reference.php?action=upload` | Validates and privately stores a reference image. |
| `GET api/reference.php?action=preview&id=...` | Serves the private same-browser image to the workspace/Decart SDK. |
| `POST api/reference.php?action=delete` | Deletes the active reference image. |
| `POST api/sessions.php` | Optional HTTP Signaling private-preview actions: create, ICE, prompt, image, status, end. Not used by the default SDK Direct transport. |

### SDK Direct reference-image flow

1. The browser uploads the image to `api/reference.php`.
2. PHP validates the file's real MIME type and dimensions, saves it under `storage/references/`, and returns metadata.
3. At connection start, the browser fetches the file from the same-origin private preview endpoint and reconstructs a `File` object.
4. The browser supplies the `File` using Decart's documented `initialState.image`. When the prompt/image changes during the session, the app calls the SDK's atomic `realtimeClient.set({ prompt, image, enhance })` so the image and prompt are kept together. Removing the image sends `image: null`.

Accepted formats are JPEG/JPG, PNG, and WebP. The PHP upload limit is 5 MB. The app checks the detected MIME type and actual image dimensions, and rejects excessively large images/pixel counts. Decart recommends a reference at least 512 × 512 pixels and under 5 MB for best results. Smaller valid images are accepted with an advisory message. Oversized images may be resized/compressed in the browser before upload.

## Optional HTTP Signaling private-preview mode

The implementation includes server-side session, ICE, prompt/image, status, and termination routes for teams that have access to Decart's HTTP Signaling private preview. Enable it only after access is confirmed:

```php
'realtime_transport' => 'http-signaling',
```

This mode uses PHP/cURL for the documented HTTP signaling operations while the media stream travels directly over WebRTC. It does not need a WebSocket relay process. If your account does not have this private-preview access, leave the default SDK Direct mode enabled.

## Troubleshooting

- **Missing Decart configuration:** Set `decart_api_key` in `config.local.php` or `DECART_API_KEY` in the server environment.
- **Camera permission denied:** Allow camera access in browser site settings and reload. Close other apps using the camera.
- **Camera API unavailable:** Confirm the page is HTTPS with a valid SSL certificate.
- **SDK module won't load:** Check browser internet access to `esm.sh`, any content-security policy, and browser console errors. If necessary, bundle the official `@decartai/sdk` package locally through a build pipeline and update the dynamic import in `assets/app.js`.
- **SQLite driver missing:** Enable the PHP `pdo_sqlite` extension in the hosting PHP settings.
- **Storage write failure:** Grant PHP write permissions to `storage/` and verify filesystem ACLs.
- **Decart 401/403:** Check the permanent key and project/organization permissions.
- **Selected model unavailable:** Ask Decart to enable that exact model for your account. The app shows the API/SDK error and never silently substitutes the other model.
- **Reference update fails:** Confirm the model/account supports reference images, the file is one of the accepted formats, and the image is below 5 MB.
- **WebRTC does not connect:** Confirm HTTPS, browser support, network/firewall access, Decart's service status, and browser console errors.
- **HTTP Signaling returns access error:** Switch back to `sdk-direct` unless Decart has enabled private-preview access for your account.

## Local validation

Run inside the project folder:

```bash
php -l index.php
find app api tests -name '*.php' -print0 | xargs -0 -n1 php -l
node --check assets/app.js
php tests/smoke.php
```

`tests/smoke.php` checks the local SQLite database schema and seeded prompt list when PDO SQLite is available. It does not make requests to Decart.

## Live acceptance checklist (requires your Decart key and HTTPS deployment)

1. Load the dashboard and confirm there is no login/registration screen.
2. Select Lucy 2.5, start a session, and verify the input camera and real transformed output.
3. Stop, select Lucy 2.6, and confirm a new session starts using that exact model.
4. Scroll the prompt cards horizontally, search, filter categories, and insert a prompt.
5. Create a custom prompt, refresh, and verify it remains; then edit, duplicate, and delete it.
6. Upload a JPEG, PNG, or WebP reference image, start a session, and verify Decart applies the image rather than only showing a preview.
7. Replace and remove the image; confirm the active Decart state updates accordingly.
8. Apply a new prompt during a live session and verify the transformed output changes.
9. Pause/resume the camera input and switch cameras where a second camera exists.
10. Fullscreen the output frame and confirm the rest of the workspace stays outside fullscreen.
11. Test a narrow Android/iOS viewport and a desktop viewport; verify INPUT and OUTPUT stay side by side and the control area sits underneath.
12. Stop the session and verify the output and camera tracks are cleaned up.

**Live-test limitation:** this ZIP was built without your private Decart API key or access to your Decart organization. I can validate PHP syntax, JavaScript syntax, and local page/assets, but I cannot honestly claim that a billable Lucy 2.5/2.6 session or account-specific permissions have been live-tested until the key is configured and the site is deployed over HTTPS. Follow the checklist above on the deployed host.

## Official Decart documentation

- [Lucy 2.5 Realtime](https://docs.platform.decart.ai/models/realtime/lucy-2.5)
- [Lucy 2.6 Realtime](https://docs.platform.decart.ai/models/realtime/lucy-2.6)
- [Reference Images](https://docs.platform.decart.ai/models/realtime/reference-images)
- [Client Tokens](https://docs.platform.decart.ai/getting-started/client-tokens)
- [JavaScript Realtime SDK](https://docs.platform.decart.ai/sdks/javascript-realtime)
- [HTTP Signaling (private preview)](https://docs.platform.decart.ai/integrations/signaling-proxy-http)

## Mobile responsiveness update

The responsive layout keeps the INPUT and TRANSFORMED OUTPUT frames in a two-column grid at phone widths; the video panes do not switch to a vertical stack. Both panes retain a 3:4 portrait aspect ratio and use `object-fit: contain` so the camera/output image is not cropped. At narrow widths, frame labels and status indicators use a compact two-line header, while the control panel remains below both frames with touch-sized buttons. Horizontal scrolling is reserved for the prompt-card strip; the page itself clips accidental horizontal overflow. Reference-image details and prompt-management controls are allowed to wrap within their own panels.

For device/browser QA after deployment, check these viewport widths: 320, 360, 375, 390, and 430 px (Android/iPhone-sized layouts), plus 768, 1024, and 1440 px (tablet/desktop). Confirm both video frames remain visible side by side, the document has no unintended horizontal scrollbar, prompt cards scroll independently, controls remain tappable, and the output fullscreen action targets only the output frame. The local execution environment used for this revision blocked browser automation, so these are deployment QA targets rather than claimed physical-device test results.

## Workspace UI update 1.0.4

- The INPUT and TRANSFORMED OUTPUT previews now use taller frames on desktop and mobile while remaining side by side.
- The new **Open camera** button requests camera permission and displays the live input preview without starting a Decart transformation. Select **Start transformation** when ready.
- Lucy model selection is simplified to two compact choices: Lucy 2.5 and Lucy 2.6.


## Security notice for this expansion build

The source archive supplied for this expansion contained a live Decart API credential in `config.local.php`. That file has been deliberately excluded from the deployment archive. **Revoke/rotate that credential in the Decart dashboard before deployment**, then create `config.local.php` on the server from `config.local.example.php` and insert the replacement key. Do not upload the original configuration file.

## Navigation expansion milestone

The new `assets/navigation.css` and `assets/navigation.js` provide the collapsible desktop sidebar, mobile off-canvas drawer, keyboard Escape handling, persisted sidebar preference, and light/dark shell preference. The original `assets/app.js`, realtime API handlers, realtime DOM IDs, WebRTC transport and SDK integration are preserved unchanged. Image Studio, batch Video Studio, shared projects/assets/history and administrator modules are not represented as working features in this milestone; they require separate verified provider contracts and implementation/testing.


## Image Studio and Video Studio integration (build 1.2)

### Layout
Both workspaces use two tall, side-by-side source/reference preview frames at all viewport widths, followed by a compact setup panel and a full-width result section. The source and reference frames remain in a two-column grid on narrow phones; the output uses its returned media aspect ratio and is not forced into the portrait input frame.

### Image Studio
- Real `POST /v1/generate/lucy-image-2` multipart request using the server-side `X-API-KEY` header.
- Required source image and prompt; optional reference image, seed, prompt enhancement, and 480p/720p resolution.
- Validates MIME signature and image dimensions; validates that the provider returned a PNG before persisting it.
- Image output is stored under private `storage/platform/outputs` and streamed only after anonymous-session ownership checks.

### Video Studio
- Real batch submission to `POST /v1/jobs/lucy-2.5` or `/v1/jobs/lucy-2.6`.
- Provider job ID is stored before polling. Status polling uses `GET /v1/jobs/{job_id}` and retrieves completed binary output from `GET /v1/jobs/{job_id}/content`.
- UI shows submitted/processing/completed/failed states only; no fabricated percentage.
- Lucy 2.6 batch route is based on the DecartAI Android SDK model registry, which lists `VideoModels.LUCY_2_6` as a batch model with queue path `/v1/jobs/lucy-2.6`. Account entitlements still need live verification.
- Video output is stored privately and served only to the owning anonymous session.

### Database
The original `prompt_library`, `workspace_preferences`, `reference_uploads`, and `realtime_sessions` schema is retained. `app/platform.php` adds the `platform_jobs` and `platform_assets` tables on first platform request, using the same PDO connection. SQLite uses foreign keys, WAL mode and a busy timeout. No database is reset.

### Important deployment configuration
Copy `config.local.example.php` to `config.local.php` and set the replacement Decart API key. Configure `max_image_bytes` and `max_video_bytes` to fit the host's PHP `upload_max_filesize` and `post_max_size`. The current default maximum video upload is 100 MB, but the hosting account may impose a lower limit.

### Tests not claimed
Static PHP and JavaScript checks can be run locally. Actual image generation, video submission, provider polling, content download, and browser-camera regression require a live server with the account's Decart API key, cURL, a supported database driver, and HTTPS. They must be verified after deployment.


## Deployment checklist

1. Extract this archive directly into the target web directory (the ZIP has no extra parent folder).
2. Create `config.local.php` from `config.local.example.php` and add a freshly rotated Decart key.
3. Confirm PHP 8.1+, PDO SQLite, cURL, Fileinfo and mbstring are enabled.
4. Ensure `storage/` is writable by PHP and blocked from direct web access.
5. Set PHP upload/post limits high enough for your chosen image/video limits.
6. Deploy to HTTPS, then test one small image edit and one short video job with the real Decart account.
7. Verify the existing realtime start/stop/model-switch/reference-image workflow on desktop and mobile.


## Image and Video Studio prompt library (Build 1.3.0)

Both upload workspaces now include a reusable prompt library with:
- Horizontally scrollable prompt cards with touch scrolling and scroll snapping.
- Search and category filters.
- Separate Image Studio and Video Studio prompt collections.
- One-click insertion into the existing prompt textarea (no automatic submission).
- A `REFERENCE` label for prompts that work best with a reference image, and a `TEXT` label for text-only prompts.
- Categories covering identity/character replacement, clothing, adult swimwear styling, backgrounds, hair, additions, removals, visual style, lighting and enhancement.

The built-in collection contains 30 Image Studio prompts and 30 Video Studio prompts. The prompt cards are examples and starting points; they do not create new Decart models or guarantee that every edit will work identically on every source. The library does not change the API payload contract or the existing job polling logic.

Prompting guidance follows Decart's official Lucy prompt gallery and onboarding examples:
- https://api-onboarding.decart.ai/prompts
- https://api-onboarding.decart.ai/
- https://platform.decart.ai/models/lucy-vton

For reference-image edits, use a clear, well-lit image with matching framing and unobstructed details. Decart's onboarding guidance recommends a reference of at least 512 × 512 pixels for realtime Lucy reference-image workflows; that is guidance for the realtime reference path, not a verified hard requirement for every batch endpoint. The Image and Video Studio upload validation and provider request contracts remain unchanged.

The prompt collection intentionally supports consensual adult identity transformations and non-explicit clothing/swimwear try-ons. It does not include prompts designed to undress a person or create nude imagery.


## Build 1.4 account and dashboard expansion

This revision adds customer registration/login, logout, a protected account dashboard, projects, generated assets, activity history, profile/security settings, step-by-step tutorials, a creative-tools directory, and a read-only administrator diagnostics page. Passwords use PHP `password_hash`; sessions rotate after login; forms validate CSRF tokens. The first successful registration is atomically assigned administrator privileges when no administrator exists; subsequent registrations receive the member role. Administrator recovery is available through the hosting CLI utility documented in `INSTALLATION-AND-AUDIT.md`.

Copy `config.local.example.php` to `config.local.php`, set your Decart key/database settings, and add trusted admin emails if needed. Use HTTPS. Existing realtime SDK and API implementation files are retained unchanged. Existing media ownership remains browser-session scoped; account-level cross-device media migration is not enabled. Payments, subscriptions, email verification, and password reset are not active without verified provider and mail credentials.


## Cinematic onboarding (Build 1.6)

The public `onboarding.php` route introduces the three implemented workspaces and the existing project/library workflow before sign-in. Unauthenticated visits to `login.php` are routed through the introduction; `login.php?direct=1` opens the actual sign-in form. The original requested destination is preserved through onboarding, sign-in, and registration. Completion is stored in browser localStorage, and authenticated users can replay the introduction from Settings. The five-slide experience uses the existing optimized workspace preview assets and does not advertise voice/audio generation, which is not implemented in this build.

The distributable onboarding ZIP intentionally excludes `config.local.php`. Keep the server-side private config when updating an existing installation; for a fresh installation, copy `config.local.example.php` and configure your own credentials. Rotate any provider key that was included in an uploaded source archive.

## Build 1.7 — Explore, Shorts Studio and Admin Workspace

New authenticated routes:

- `community.php` — masonry-style Explore gallery of creative direction presets. Recreate actions open the existing Video Studio with a prefilled prompt.
- `shorts-studio.php` — responsive Shorts Studio inspiration grid. It uses the existing video upload and Decart batch-job workflow; it is not a separate text-to-video model endpoint.
- `admin.php` — role-protected administration workspace with Overview, Users, Usage, API keys, Models, Audit log and System sections.

### Admin API key vault

Managed Decart keys are encrypted at rest with AES-256-GCM. Before adding keys, configure `ANONYMOUX_KEY_ENCRYPTION_SECRET` (32+ characters) as a server environment variable, or add `admin_api_encryption_key` to the private `config.local.php` array. Generate a secret using:

```sh
php -r "echo bin2hex(random_bytes(32)), PHP_EOL;"
```

Keep this secret stable and backed up. Losing it makes the managed keys unreadable. API requests automatically try the next enabled key after provider authentication, quota/rate-limit, timeout or transient server errors. If no managed key is active, the original `DECART_API_KEY` / `decart_api_key` remains a compatibility fallback.

### Admin boundaries

The existing product does not include a billing ledger, credit wallet or user-to-generation foreign-key relationship. Therefore Usage reports aggregate local job counts only; it does not invent credits, payment totals or per-user provider spend. The model catalog lists the model routes already integrated in this application, and provider-side entitlements remain controlled by Decart.

### Gallery asset note

The `assets/community/` WebP images are cropped from the reference screenshots supplied by the user. They are illustrative design assets. Replace any third-party imagery without confirmed usage rights with original, licensed or consented media before public commercial launch.


## Fish Audio Voice Studio (added in build 1.8)

The authenticated Voice Studio is available at `/voice/` and from the dashboard/sidebar. It uses Fish Audio's hosted REST text-to-speech API from PHP cURL; no Node.js process or WebSocket server is required for the request/response TTS workflow. The workspace now includes account-level credits, persistent generated-audio history, private audio streaming, and paginated voice discovery.

### Configure Fish Audio

1. Create a Fish Audio developer API key at https://fish.audio/app/api-keys.
2. Ensure PHP has `curl` and `openssl` enabled.
3. Configure `ANONYMOUX_KEY_ENCRYPTION_SECRET` with a long random secret (at least 32 characters) in the hosting environment or private `config.local.php` as `admin_api_encryption_key`. This is the same encryption secret used by the existing API key vault. Back it up securely; losing it makes stored keys unreadable.
4. Sign in as an administrator and open **Admin → Voice AI**.
5. Add the Fish Audio API key. It is encrypted with AES-256-GCM and is never returned to the browser. Multiple keys can be stored, enabled/disabled and rotated by priority.
6. Optionally set a default Fish Audio voice reference ID. The ID must be available to the API key/account. Leave it blank to use the API's default voice behavior.
7. Open **Voice Studio**, enter text and generate speech.

### Implementation details and limits

- TTS endpoint: `POST https://api.fish.audio/v1/tts`; model header: `s2.1-pro-free`; response format: MP3.
- PHP endpoint: `api/voice/tts.php`. It requires an authenticated user and CSRF token, enforces a 5,000-character request limit and an account-level limit of 20 attempts per rolling ten-minute window, calls Fish Audio server-to-server, and returns audio bytes to the browser.
- The API key is never placed in JavaScript, HTML, or browser storage. The server records request counts and character counts in `voice_usage`. Successful generated audio and its script are stored in private server storage and indexed in `voice_generations`; audio is streamed only to its owning authenticated account. The storage folder denies direct web access.
- The workspace supports a voice reference ID, browser playback speed, MP3 download, optional browser speech dictation (where supported), and Fish Audio bracketed delivery cues such as `[whisper]`, `[excited]`, and `[laugh]`.
- This is a request/response text-to-speech integration. It is not a full-duplex realtime agent and does not include speech-to-text or an LLM chat backend. Those are separate integrations and should be added explicitly.
- Fish Audio's `s2.1-pro-free` API access is advertised through November 30, 2026 under Fair Use, with no SLA/latency guarantee. Confirm current terms, commercial-use permissions, rate limits and data handling with Fish Audio before production deployment. The free API offer is distinct from the consumer web-app free plan.
- InfinityFree/shared-hosting compatibility depends on outbound HTTPS/cURL being enabled and allowed by the host. If outbound requests are blocked or time out, the provider call will fail; no browser-side API-key workaround is used.

### Voice API smoke test

The standard `php tests/smoke.php` checks that the core application, voice, wallet, credit-ledger, and audio-history tables are created. It does not call Fish Audio or spend provider quota. After adding a key, test speech generation through the authenticated Voice Studio interface.


## Voice Studio — searchable Fish Audio voice library (Build 1.9)

Voice Studio now includes a searchable catalog loaded server-side from Fish Audio. Search filters the currently loaded voices by name, description, language, tag and voice ID. Only the first page loads automatically; use **Load next page** to fetch more voices and avoid loading the entire provider catalogue in the background. **Refresh list** reloads the first page. Selecting a card sets its reference ID for the existing text-to-speech endpoint. A manual voice ID remains available as a fallback.

The browser never receives the Fish Audio API key. The authenticated endpoint `api/voice/voices.php` uses the encrypted server-side key pool and returns only a small allow-list of voice metadata. The provider catalog is not replaced with fake local entries if unavailable; the workspace displays the error.

Voice catalog API: `GET https://api.fish.audio/model` with `page_size` and `page_number`. Text-to-speech remains `POST https://api.fish.audio/v1/tts`. Confirm current endpoint access and account permissions against the official Fish Audio API documentation before production use. Provider availability and voice visibility are controlled by Fish Audio.


## Voice Studio billing and history (Build 2.2.1)

- New wallets are initialized with 200 credits by default. Existing wallets retain their current balances. The initial balance is configurable under **Admin → Voice AI**.
- Default pricing is 1 credit per 100 characters, rounded up per request. Administrators can change the rate or set it to 0 to disable voice credit charging. Confirm your commercial pricing before launch; these defaults are application settings, not Fish Audio pricing.
- Credits are debited before calling Fish Audio. If the provider call fails, the application attempts an automatic refund and writes a matching ledger transaction. Successful and failed requests are recorded against the authenticated user.
- The account-level throttle permits up to 20 voice-generation attempts per rolling ten minutes. This is enforced from the database, not a PHP session variable.
- Recent successful generations appear in Voice Studio history. MP3 files are stored in `storage/voice-audio/` and served through `api/voice/audio.php`, which verifies account ownership. Do not expose this directory through a public static file server; retain the included Apache deny rule and add an equivalent Nginx rule if Nginx serves the site.
- Administrators can grant or deduct credits from **Admin → Users**. Every adjustment is recorded in `credit_transactions` and the admin audit log.

### New voice endpoints

| Endpoint | Purpose |
|---|---|
| `GET api/voice/history.php` | Lists the signed-in user's recent generations and current credit balance. |
| `GET api/voice/audio.php?id=...` | Streams an owned MP3 after an account ownership check. |
| `POST api/voice/tts.php` | Debits credits, applies the account throttle, calls Fish Audio, stores the output, and refunds credits after a failed generation. |

### Deployment checks

1. Upload the updated files over the existing application while preserving `config.local.php` and the existing `storage/` database.
2. Ensure `storage/` is writable by PHP and not directly served by Nginx or another static-file layer.
3. Confirm `pdo_sqlite`, `curl`, and `openssl` are enabled.
4. Sign in as an administrator, configure the Fish Audio encryption secret and key, and review **Admin → Voice AI** credit settings.
5. Sign in as a test member, confirm the starting wallet balance, generate a short script, confirm the debit, refresh the page, and play/download the saved history item.
6. Force a provider failure using a temporary invalid test key and confirm the attempted generation is recorded and the credits are refunded. Restore the valid key immediately afterward.
7. Confirm another user cannot access the first user's audio by copying an audio-history URL while signed into the second account.

**Validation note:** PHP syntax and JavaScript syntax checks pass in the build environment. A live provider request, real hosting test, and database runtime smoke test still need to be performed on the deployment host because this build environment does not have the PDO SQLite driver or the user's Fish Audio credentials.


## 2.3.1 remediation build notes

This remediation build keeps the existing PHP/PDO architecture and provider integrations, with PDO SQLite as the sole database driver. Authentication now derives resource ownership from the authenticated account after a one-time legacy-owner binding at successful login, and rotates the anonymous ownership token at authentication boundaries. Sign-in throttling is persisted under private storage rather than relying only on a browser session. Scoped Decart client-token requests are rate-limited and origin-checked. Voice wallet debit and refund ledger writes are transactional and reject duplicate debit references. Video jobs receive a configurable terminal timeout. Platform uploads are subject to a per-account storage quota.

New optional configuration values (all have server-side defaults) are `force_https`, `max_storage_per_user_bytes`, and `video_job_timeout_seconds`. HTTPS enforcement is enabled by default for non-local HTTP hosts; localhost and CLI use remain available for development. The application emits security headers and Apache static-response headers where `mod_headers` is enabled.

**Verification limitation:** this source package was syntax-checked, but this build environment did not have `pdo_sqlite` or `curl` enabled. Database migration/transaction tests and live Decart/Fish Audio integration tests therefore could not be run here. The separate remediation and security reports state which checks passed and which remain blocked. Supply the original 2.3.0 source audit report to complete finding-ID reconciliation.


## Administrator initialization and Flutterwave credits (2.4.0 audit rebuild)

- The first successful registration is assigned `admin` inside a serialized database transaction. Later registrations are always `member`; role fields supplied by the browser are ignored.
- Administrator recovery is restricted to CLI execution: `php tools-recover-admin.php account@example.com`. Run it only from the hosting account's terminal/CLI, then sign in and review the audit log.
- Credit packages and payment orders are additive tables. Existing users, wallets, credit ledger rows, workspaces and media are not reset.
- This ZIP includes a private `config.local.php` with a generated 256-bit `admin_api_encryption_key`; it is ready for credential encryption. Preserve and back up this file. Do not replace its key after encrypted credentials have been saved.
- Configure Flutterwave under Admin → Payments. Use test credentials and Test mode first. Set the webhook URL to `/api/flutterwave-webhook.php` on your deployed application and configure the exact webhook secret hash in Flutterwave.
- User purchases are created server-side, and credits are posted only after a successful server-side transaction verification that matches reference, amount, currency and order. Webhook notifications are signature-checked and idempotent.
- Upload the complete ZIP to the document root or a subdirectory, retain `.htaccess` protection for `storage/`, and ensure PHP PDO SQLite, OpenSSL and cURL are enabled.
- Do not expose `config.local.php`, the encryption secret, or the SQLite database. Back up `storage/` and the configuration secret securely before upgrades.

---

## 2.4.5 Resources, admin and History updates

The Resources catalogue now supports paginated tool/tutorial listings with combined search and category filters. Resource editors are collapsible, category management is grouped, existing tutorial video URLs are restored during edits, and draft tutorials can be previewed by administrators. The mobile admin navigation is a compact horizontal strip.

History is account-scoped for signed-in users, polls pending Magic Hour Lip Sync and Decart video jobs, and supports inline result previews and downloads. The output media endpoint supports HTTP byte ranges for video seeking.

See `BUILD-REPORT-2.4.5.md` and `RESOURCES-ADMIN-GUIDE-2.4.5.md` for deployment notes and verification limits.


## 2.5.2 corrective repair candidate

See `PRODUCTION_REPAIR_REPORT_2.5.2.md`, `UPGRADE_2.5.2.md`, `SECURITY_CHECKLIST_2.5.2.md`, and `CHANGELOG_2.5.2.md` before deployment. This release requires PDO SQLite and cURL where provider requests are used. It is not a live-provider or InfinityFree compatibility certification.

## 2.5.5 maintenance release

See `CHANGELOG_2.5.5.md`, `INSTALLATION_2.5.5.md`, `AUDIT_REPORT_2.5.5.md` and `TEST_REPORT_2.5.5.md` for the additive package options, Fish Audio Agent API diagnostics/session request repair, Shorts Studio route removal, and the exact validation limits of this build. Explore remains available. Live Fish Audio and Flutterwave acceptance tests must be completed with the deployment owner's credentials on the target host.

## Version 2.5.8 — Glass UI and notifications

This release adds a unified glassmorphism layer and stronger typography across the platform, including Tools & Tutorials, admin, studio, authentication and onboarding screens. Authenticated pages now include a notification bell, unread counter, floating in-app alerts, read controls and an optional multi-tone bell chime. The chime is generated in-browser and requires a first user interaction to unlock audio under normal browser autoplay rules. Notifications are polled while the page remains open; background Web Push is not included.

See `CHANGELOG_2.5.8.md` and `BUILD_REPORT_2.5.8.md` for implementation and verification details.


## 2.5.9 Explore, Realtime & Pricing Recheck

See `CHANGELOG_2.5.9.md` and `REALTIME-PRICING-AND-AUDIT-2.5.9.md` for the retired Explore route, current Decart SDK lifecycle handling, token retry allowance, and the distinction between provider costs and ANONYMOUX credit billing. Realtime wallet deductions are not implemented in this release.

## Version 2.6.0 — Fish Audio Voice Cloning & AI Agent Studio

The user navigation is now grouped consistently across the shared dashboard shell and the separately-rendered Realtime Studio page. The voice workspace is a dedicated **Voice Cloning Studio** with private Fish Audio voice model creation, consent and ownership records, audio upload/compatible browser recording, user-owned voice library, deletion, TTS selection and generation history. The standalone **AI Agent Studio** now includes the public and private voice picker, provider-supported speaking language/model/speed/expressive settings, draft/publish lifecycle, searchable agent cards and WhatsApp Business Calling setup guidance.

Private voice IDs are scoped to their creating Anonymoux user; another user cannot list or select a private clone. Clone credit cost is configurable by an administrator and defaults to zero. WhatsApp number import remains in Fish Audio's console. See `CHANGELOG_2.6.0.md`, `AUDIT-AND-REBUILD-REPORT-2.6.0.md`, `BUILD_REPORT_2.6.0.md` and `FISH-AUDIO-VOICE-CLONING-REBUILD-2.6.0.md` before deploying. Live Fish Audio and InfinityFree acceptance checks remain required on the target host.

## 2.6.1 visual identity and SQLite PDO confirmation

The platform interface now uses the charcoal `#111318`, white `#FFFFFF` and neon-green `#A3FF12` identity. Purple `#8B5CF6`, teal `#00D6C9` and blue `#3897FF` are reserved for occasional supporting accents. Shared workspaces and the onboarding page use Space Grotesk for headings and Inter for interface text, with a restrained grain texture and subtle ambient green lighting.

Persistence remains **PDO SQLite only**. The application opens the private `storage/workspace.sqlite` database through PDO, uses exception mode, associative fetches, native prepared statements and SQLite foreign-key/busy-timeout settings. There is no MySQL fallback or database-driver selector. Enable PHP `pdo_sqlite` and ensure PHP can write to `storage/` before deployment.

## 2.6.2 theme and workspace pricing
The 2.6.2 update centralizes the charcoal/white/neon-green theme across the dashboard, administration pages and realtime shell. Admin → Models now contains editable default prices for Image, Video Edit, Realtime, Lip Sync, Voice and AI Agent workspaces. Realtime is priced at 10 credits per Decart-billed active second and settled from the provider's returned billed_seconds; missing measurements are never estimated from a browser timer. See `CHANGELOG_2.6.2.md` and `BUILD_REPORT_2.6.2.md` for the full pricing and validation record.


## Folder-based workspace URLs (2.6.4 routing update)

The workspace entry points now have dedicated folders: `/image/`, `/video/`, `/realtime/`, `/lip-sync/`, `/voice/`, and `/agents/` (with agent conversations at `/agents/chat.php`). Existing root PHP entry points remain as compatibility targets and redirect to the matching folder URL through the root `.htaccess`. Shared application code, APIs, assets, and private configuration remain at the application root.
