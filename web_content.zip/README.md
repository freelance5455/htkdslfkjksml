# پروژه APK بازی «تاریخ ایران ۲»

این پروژه، فایل HTML بازی ارائه‌شده را داخل یک اپلیکیشن Android WebView قرار می‌دهد و تصویر ارسال‌شده برای آیکون برنامه استفاده شده است.

## مشخصات
- نام برنامه: تاریخ ایران ۲
- Package: `com.tarikhiran2.game`
- Version: 1.0 (versionCode 1)
- Portrait
- JavaScript و Local Storage فعال
- HTML بازی در `app/src/main/assets/index.html`
- آیکون در پوشه‌های `mipmap-*`

## ساخت APK با Android Studio
1. Android Studio را باز کنید.
2. گزینه **Open** را بزنید و پوشه `Tarikh_Iran_2_APK_Project` را انتخاب کنید.
3. صبر کنید Gradle Sync کامل شود.
4. از منوی **Build → Build App Bundle(s) / APK(s) → Build APK(s)** استفاده کنید.
5. برای نسخه انتشار می‌توانید از **Build → Generate Signed App Bundle / APK** استفاده کنید.

## نکته
این پروژه برای Build شدن به Android SDK و ابزارهای Gradle نیاز دارد. Android Studio در صورت نیاز می‌تواند وابستگی‌های Gradle/SDK را دریافت کند.
