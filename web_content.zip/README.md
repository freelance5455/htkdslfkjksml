# Float Browser Android

مشروع Android أصلي يحتوي على WebView حقيقي ونافذة Overlay حقيقية.

## البناء
1. افتح المجلد في Android Studio.
2. انتظر Gradle Sync.
3. Build > Build APK(s).

## الصلاحيات
- INTERNET: لتحميل المواقع داخل WebView.
- SYSTEM_ALERT_WINDOW: يفتح إعداد Android الحقيقي للظهور فوق التطبيقات.
- النافذة العائمة يستخدمها FloatService عبر WindowManager وTYPE_APPLICATION_OVERLAY.

## ملاحظة
ملف HTML هو واجهة التطبيق، لكن صلاحيات Android والنافذة العائمة تنفذها طبقة Java الأصلية.
