# College Hostel Management System (CHMS)
### 🎓 2nd Year Mini Project (CSE / IT)

A clean, standard, and easy-to-use **College Hostel Management Portal** built purely with **HTML5, CSS3, and JavaScript**.

---

## 🚀 How to Run the Website

Simply double click on `index.html` in file explorer or open it in any modern web browser (Google Chrome, Microsoft Edge, Mozilla Firefox, Safari):

```text
d:\CHMS\index.html
```

> **No server, Node.js, Python, or MySQL installation required!**
> Everything runs reliably in the browser and automatically persists changes (new students, room allotments, fee payments, complaints) in `localStorage`.

---

## 🔑 Login Accounts

Open `index.html` and simply click the **Warden Login** or **Student Login** card tab to auto-fill credentials, or enter them manually:

| Portal | Username / Roll No | Password | Role Selection |
| :--- | :--- | :--- | :--- |
| **Warden Login** | `admin` | `admin123` | Click **"Warden Login"** card |
| **Student Login** | `CS2024-001` | `student123` | Click **"Student Login"** card |

---

## 📋 Features & Specifications

1. **Sliding Explorer (Sidebar Drawer)**: Smooth collapsible explorer on desktop with `☰` toggle button and responsive off-canvas sliding drawer on mobile with darkened overlay. No visible horizontal scrollbars.
2. **100 Rooms & 235 Beds Across 5 Floors**:
   - **Block A (Senior Boys)**: Floors 1 to 5 (40 rooms: 101 to 508, AC & Non-AC)
   - **Block B (Junior Boys)**: Floors 1 to 5 (30 rooms: B-101 to B-506, AC & Non-AC)
   - **Block C (Girls Campus)**: Floors 1 to 5 (30 rooms: C-101 to C-506, AC & Non-AC)
   - **60 Resident Students**: Exactly 35 Boys and 25 Girls pre-configured with complete academic, guardian, and room allocation profiles.
3. **AC & Non-AC Room Management**: Categorized into AC and Non-AC rooms with dedicated filters, badges, and capacity controls.
4. **Strict Gender-Segregated Allocation**: Boys are strictly allocated to Boys Hostel (Blocks A & B) and Girls to Girls Hostel (Block C). Mixed-gender allocation is prevented with error alerts.
5. **Compulsory Student Validation**: Student Mobile, Father/Guardian Name, Guardian Mobile, and Permanent Address are mandatory. Mobile numbers are validated for exactly 10 digits.
6. **100% Pure Vegetarian Mess Timetable**: 7-day vegetarian breakfast, lunch, snacks, and dinner meal plan.
7. **Fees & Official Receipts**: Track dues, record fee transactions (UPI, Net Banking, Cash, Card), and print official receipts.
8. **Complaints & Grievance Redressal**: File and track maintenance tickets (Water, Electrical, Internet, Cleaning, Furniture).
9. **Outstation Leave & E-Gate Pass**: Apply for travel leaves and generate authorized security gate pass slips.
10. **Visitors Log**: Record visitor check-in, purpose, student meeting, and check-out timestamps.
11. **Institutional Tail (Footer)**: Clean academic footer with block directories, session info, and 24x7 emergency contacts.

---

## 📁 File Structure

```text
d:\CHMS\
├── index.html           # Main Web Page (Login, Warden & Student Portals)
├── css\
│   └── style.css        # Responsive university styling, drawer animation & print CSS
├── js\
│   ├── data.js          # Default pre-loaded college hostel data (100 rooms, 5 floors, 60 students)
│   └── app.js           # Business logic, state management, search, validation, print handlers
└── README.md            # Project documentation & manual
```
