# StreakFlow Android APK & Mobile Install Guide

## Option 1: Instant Mobile App Install (No Build Required)
1. Open `www/index.html` on your Android phone in Chrome (or host the `www` folder on GitHub Pages / Netlify / Vercel).
2. Tap the Chrome menu (three dots) -> **Add to Home screen** / **Install app**.
3. It installs as a standalone full-screen Android application with offline storage.

## Option 2: Compile a Signed/Debug `.apk` File Using Capacitor
This bundle is pre-configured for **Ionic Capacitor**:
1. Extract `StreakFlow-Android-APK-Project.zip` on your computer with Node.js and Android Studio / Android SDK installed.
2. Run:
   ```bash
   npm install
   npx cap add android
   npx cap sync android
   cd android && ./gradlew assembleDebug
   ```
3. Your compiled `.apk` file will be output at:
   `android/app/build/outputs/apk/debug/app-debug.apk`
