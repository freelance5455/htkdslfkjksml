# KtoGdzie? — Android 17 — telefon

Kod źródłowy wersji webowej. Zawiera ekran mapy, geolokalizację, nagrywanie i historię tras oraz obsługę trybu TV.

## Uruchomienie

1. Rozpakuj cały ZIP. Plik `index.html` i katalog `vendor` muszą pozostać obok siebie.
2. Udostępnij zawartość katalogu na hostingu statycznym HTTPS. Otwórz jego adres na telefonie lub w przeglądarce telewizora.
3. Zezwól przeglądarce na lokalizację, jeśli chcesz używać pozycji i rejestrować trasę. Mapa OpenStreetMap pobiera podkład przez internet.

Do podglądu na komputerze możesz w rozpakowanym katalogu uruchomić `python3 -m http.server 8080` i otworzyć `http://localhost:8080/`.
Wersję opublikowaną znajdziesz pod adresem https://ktogdzie-podglad.tomsky82.chatgpt.site/

## Obsługa

- Telefon obsługuje dotyk, a menu, nagrywanie i lokalizacja są po prawej stronie.
- Tryb TV obsługuje strzałki, OK i Wstecz oraz przesuwanie i skalowanie mapy. Parametry `?tv=1` i `?tv=0` pozwalają przełączyć tryb ręcznie.
- Historia tras jest zapisywana lokalnie w danej przeglądarce. Nagrywanie tras wymaga aktywnej karty i dostępnej lokalizacji urządzenia.
- Paczka zawiera wersję webową. Na telewizorze potrzebna jest przeglądarka przekazująca przyciski pilota do strony.

Biblioteka Leaflet jest dołączona lokalnie. Jej licencja znajduje się w `vendor/leaflet/LICENSE`.
