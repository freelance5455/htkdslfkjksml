# Zuk Proxy v1.0 — projeto Android

Este projeto empacota a interface HTML em um app Android simples usando WebView.

## Recursos
- Tela de KEY (`zukproxy-free`)
- Mensagem de erro quando a KEY está incorreta
- Tela de Depuração sem fio com campo para código de pareamento
- Botão CONECTAR
- Aviso sobre banimentos e divulgação da versão VIP
- Notificação demonstrativa após preencher o campo

## Limitações importantes
Este é somente um protótipo de interface. Não se conecta ao ADB/Depuração sem fio, não injeta código, não altera o Free Fire e não oferece proteção contra banimentos. A KEY está embutida no HTML e não é uma autenticação segura.

## Gerar o APK no Android Studio
1. Instale o Android Studio em um computador.
2. Extraia o ZIP.
3. No Android Studio, escolha **Open** e selecione a pasta `ZukProxy`.
4. Aguarde a sincronização do Gradle. Se for solicitado, instale o Android SDK 35.
5. Para gerar um APK de teste, escolha **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Quando terminar, clique em **locate** na notificação. O APK normalmente fica em `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfira o APK para o Android e abra-o para instalar. Talvez seja necessário autorizar a instalação de apps dessa fonte nas configurações.

## Requisitos
- Android Studio recente
- JDK 17 (o Android Studio normalmente inclui um JDK compatível)
- Android SDK Platform 35
