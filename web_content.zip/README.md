# English AI Teacher — Android Project

This project wraps the supplied `index.html` English AI Teacher app in an Android WebView.

## Build
1. Open this folder in Android Studio.
2. Allow Gradle to sync and install required Android SDK components if prompted.
3. Select **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be under `app/build/outputs/apk/debug/`.

The original HTML app is stored at:
`app/src/main/assets/index.html`
