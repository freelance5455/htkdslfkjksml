# Cosmic Orbit - Android APK Project

Generated with **HTML to APK Compiler**.
This project wraps your HTML5 web application into a high-performance native Android application using AndroidX WebView.

- **Package ID:** `com.arcade.cosmicorbit`
- **Application Name:** `Cosmic Orbit`
- **Minimum Android SDK:** 24 (Android 7.0+)
- **Target Android SDK:** 34 (Android 14+)

---

## ⚡ Method 1: 1-Click Free Cloud Build (GitHub Actions - Easiest!)
*You don't need Android Studio or any developer tools installed on your computer!*

1. Create a new repository on **[GitHub](https://github.com/new)** (public or private).
2. Extract this ZIP and push all files to your GitHub repository:
   ```bash
   git init
   git add .
   git commit -m "Initial HTML to APK app"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```
3. Go to the **Actions** tab on your GitHub repository.
4. You will see **"Build Android APK"** running automatically.
5. In ~2 minutes, click on the completed run and download **`cosmic_orbit-debug.apk`** under Artifacts!

---

## 🛠️ Method 2: Build Locally in Android Studio
1. Download and install **[Android Studio](https://developer.android.com/studio)**.
2. Click **Open Project** and select this unzipped folder.
3. Wait for Gradle sync to complete.
4. In the top menu, go to **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will notify you: *"APK(s) generated successfully"*. Click **locate** to find your `app-debug.apk`.

---

## 💻 Method 3: Build via Command Line
If you have JDK 17 installed:

**Linux / macOS:**
```bash
chmod +x gradlew
./gradlew assembleDebug
```

**Windows:**
```cmd
gradlew.bat assembleDebug
```

The generated APK will be at:
`app/build/outputs/apk/debug/app-debug.apk`

---

## 📲 How to Install the APK on Your Android Device
1. Send the `app-debug.apk` file to your Android phone (via USB cable, Google Drive, WhatsApp, or Telegram).
2. Tap on the file in your phone's file manager.
3. If prompted with *"For security, your phone is not allowed to install unknown apps"*, tap **Settings** and toggle **"Allow from this source"**.
4. Tap **Install** and enjoy your app!

---

## 📁 Web Assets
Your HTML, CSS, JavaScript, and images reside inside:
`app/src/main/assets/`
Any changes made there will immediately be reflected in the app.
