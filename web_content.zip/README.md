# ZIP to APK Builder v2

This version improves the file picker UX. `index.html` has a large **Choose ZIP file** button, a visible selected-file panel, drag/drop support, upload progress, and clearer errors.

Run the web application with Docker Compose:

```bash
docker compose up --build
```

Open http://localhost:8000

Important: this is a server-side builder. Opening `index.html` directly from your phone as a standalone HTML file will NOT perform builds because the `/api/*` backend is not running. Run the backend and open the web address instead.

Supported input: a ZIP containing an Android/Gradle project.

A normal Android device will still require the user to approve APK installation through Android's package installer.
