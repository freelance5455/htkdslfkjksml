# MathScore 14 — Fixed Complete Update

Fixed the Add/Edit Class buttons so Save Class and Cancel work correctly.
Includes academic-year management, Edit Class, multi-class records, and Excel/CSV student import.
