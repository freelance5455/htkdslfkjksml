# Agri Pro — Native Android PERFECT

نسخة Android أصلية لا تعتمد على خيارات Premium في تطبيق HTML→APK.

- صلاحية CAMERA داخل AndroidManifest + طلب وقت التشغيل.
- قارئ باركود أصلي ZXing.
- كاميرا Android أصلية للنبات والحشرة وملصق المبيد.
- FileProvider للصور بدقة كاملة.
- اختيار الملفات/الصور عبر Android.
- OCR يستقبل صورة الكاميرا الأصلية.
- العربية / الكوردية / English.
- العدادات والتشخيص والآفات والمبيدات والمخزون والمبيعات والمزارعين والنسخ الاحتياطي.

البناء: Android Studio أو AndroidIDE → افتح المشروع → Gradle Sync → Build APK.
يحتاج أول مزامنة إلى الإنترنت لتنزيل الاعتمادات.
