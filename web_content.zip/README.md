# DRIP AI // ULTRA KNOWLEDGE — Web App

A complete, static, installable web app (PWA). Unzip, host or wrap, done.

> **This ZIP is web source code, not a compiled APK/AAB.** To get an Android APK,
> upload this ZIP to APKMaker's HTML/ZIP-to-APK builder (steps below).
> **No API key is included.** The app only talks to an AI if you configure one in Settings.

## Features
- **Chat** with any OpenAI-compatible `/chat/completions` API, with streaming.
  Multiple conversations, saved in localStorage. Clear errors for missing settings,
  network failures, HTTP errors and invalid responses. The app never invents answers.
- **Knowledge shelf**: add, edit, delete, search. Import **.txt / .md** files (max 1 MB).
  **PDF import is not supported** (no PDF parser bundled) — paste PDF text as a note.
  Matching notes can be sent to the AI as context. Saved in localStorage.
- **Settings**: base URL, model, API key — or a secure **server proxy** URL (recommended).
- **Export / import** all chats and knowledge as JSON. The API key is never exported.
- **Offline**: banner shows when offline; saved chats and notes stay browsable;
  the AI is not called and no fake replies are shown.

## Files
| File | Purpose |
|------|---------|
| index.html | App shell (at ZIP root) |
| app.js | All app logic |
| theme.css | Neon cyberpunk theme |
| manifest.webmanifest | PWA manifest (standalone, portrait, PNG icons) |
| sw.js | Service worker — offline app shell, never caches API calls |
| icons/app-icon.png | 512×512 app icon (also maskable) |
| icons/icon-192.png | 192×192 icon |
| proxy-example.js | Example Cloudflare Worker proxy that keeps your key server-side |
| README.md | This file |

## API key safety
- **Proxy mode (recommended):** the browser sends requests only to your proxy URL and
  never sends a provider key. Your server adds the key. See `proxy-example.js`.
- **Direct mode:** the key is stored in **sessionStorage only** (cleared when the tab/app
  closes), never in localStorage, never in exports. It is still visible to the browser
  session and anything running in it — use a low-limit key you can revoke.
- The provider must allow browser CORS for direct mode; many do not. Use a proxy if you
  see "Network error".

## Make an Android APK with APKMaker
1. Download `drip-ai-starter.zip` (do **not** unzip — `index.html` is already at the ZIP root).
2. Open APKMaker's **HTML / ZIP to APK** builder.
3. Upload the ZIP. Set app name **DRIP AI** and use `icons/app-icon.png` as the icon.
4. Build, then download the APK it produces.
5. On Android, open the APK and allow "Install unknown apps" when asked.
6. In the app, open **Settings** and enter your proxy URL (or base URL, model and key).

Note: inside an APK wrapper the service worker may be inactive; online chat still works.

## Host it as a website (alternative)
Upload the folder to any HTTPS static host (Netlify Drop, Cloudflare Pages, Vercel).
Open it in Chrome on Android → ⋮ → **Install app**. You can also paste the URL into
pwabuilder.com to generate an Android package.

## Run locally
```
npx serve .
```
Then open http://localhost:3000. (Opening index.html directly works, but without offline caching.)

## License
Use and modify freely.
