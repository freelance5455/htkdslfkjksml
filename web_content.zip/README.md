# Shinobi Sensi — toxzinfps

Protótipo web instalável e responsivo de gerador de sensibilidade alta para Free Fire.

## Arquivos
- `index.html`: interface e lógica do app.
- `manifest.json`, `sw.js`, `icon.svg`: instalação PWA e cache dos arquivos principais.

## Como testar
Abra `index.html` em um navegador. Para instalar como app/PWA e usar o cache offline, publique a pasta em um host com HTTPS (por exemplo GitHub Pages ou Netlify) e abra o endereço no celular; no Chrome Android use **Instalar app** ou **Adicionar à tela inicial**.

## Sobre a recomendação
O app usa o tamanho e a escala de tela expostos pelo navegador, o Hz selecionado pela pessoa, estilo de jogo e quantidade de dedos para calcular um ponto de partida heurístico. Não consegue ler com precisão o hardware, DPI atual ou Hz real em todos os aparelhos. O catálogo inclui marcas e modelos comuns, e o campo de modelo também aceita digitação livre. A DPI é uma recomendação manual e o app não altera configurações do Android.
