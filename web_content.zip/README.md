# WIFI SCOPE (Android WebView + Java)

A small Android app with a responsive HTML/CSS/JavaScript interface in `app/src/main/assets/index.html`, displayed in an Android WebView. The native Java bridge performs local-network reachability checks. It scans the IPv4 subnet of the currently active network using reachability checks and a few TCP connection probes. Use only on your own Wi-Fi or a network you are authorized to inspect.

## Build from an Android phone
1. Create a GitHub account and a new **public** repository named `WifiScope` (public is easiest for the first build).
2. Extract this ZIP and upload the contents (not the outer folder) to the repository.
3. Open the repository's **Actions** tab. Enable Actions if GitHub asks.
4. The included workflow builds a debug APK. Open the newest successful run, then download the `WIFI-SCOPE-debug-apk` artifact.
5. Extract the artifact ZIP on your phone and install `app-debug.apk`. Android may ask you to allow installation from that browser/file manager.

## Limitations
- A scan only lists hosts that answer ICMP reachability or one of the tested TCP ports. Sleeping devices, client isolation, and firewalls can hide devices.
- Android does not generally expose other clients' MAC addresses to ordinary apps. MAC is therefore honestly shown as unavailable.
- Hostnames are best-effort reverse DNS and may show the IP instead.
- Scan is limited to IPv4 subnets up to 1,022 candidate addresses.
- The last 10 scan summaries are saved locally on the phone using app preferences.
