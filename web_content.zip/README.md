# LaguAI — projeto Android padrão

Este ZIP foi ajustado para ser um **projeto Android padrão**, sem dependência ou instrução específica do AndroidIDE.

## Compatibilidade
- Android 8.0 (API 26) ou superior.
- Android Studio / Gradle com Android Gradle Plugin 8.2.2.
- O projeto usa HTTPS para a pesquisa online; não depende de servidor HTTP local, Ollama ou `127.0.0.1`.

## Estrutura
- `app/src/main/java/.../MainActivity.java` — atividade nativa.
- `app/src/main/assets/web/` — interface da LaguAI/LarguIA.
- `app/src/main/res/` — recursos Android.
- `app/build.gradle` — configuração do módulo.

## Gerar o APK
Abra a **pasta raiz deste projeto** em um ambiente Android/Gradle compatível e execute a tarefa padrão de APK, como `assembleDebug`.

Observação: este arquivo é o **projeto-fonte**, não um APK já compilado. Nenhum compilador Android é embutido no ZIP.
