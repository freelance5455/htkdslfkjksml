# MasterFlow Trading — Versi Bahasa Indonesia

Versi web-mobile MasterFlow Trading untuk dikemas menjadi APK.

Seluruh antarmuka utama menggunakan Bahasa Indonesia. Istilah produk/strategi seperti **Ultra Scalp**, **Macro Flow**, **Prime Swing**, dan **Master Call** tetap dipertahankan sebagai nama modul.

- Tidak ada auto-order.
- Tidak ada pembatalan order.
- Tidak ada withdrawal/transfer dana.
- Mode demo tersedia tanpa backend.
- Backend dapat diarahkan melalui Pengaturan API.

`index.html` berada langsung di root ZIP agar kompatibel dengan builder HTML/ZIP ke APK.
