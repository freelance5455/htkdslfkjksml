# FitAI Pro — Admin Version

Purple + Dark Grey + Neon Purple UI starter.

## Run
1. Install Node.js 18+.
2. In this folder run `npm install`
3. Run `npm run dev`
4. Open the local URL shown by Vite.

## Important
This is a runnable front-end UI starter, NOT a finished production app or APK. Login, cloud sync, AI features, barcode database, notifications and secure admin permissions require backend/service integration and testing.
