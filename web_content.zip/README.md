# Kedrick Legacy App

A fully functional, responsive Progressive Web App (PWA) built around the generated Carrara-marble statue.

## Included
- Responsive Android/desktop interface
- Statue museum gallery and fullscreen viewer
- Journey/story section
- Nursing revision cards
- About/developer section
- Offline caching after first load
- Installable PWA support on compatible browsers

## Run
Open `index.html` in a browser for the basic experience.

For PWA installation/offline service-worker behavior, serve the folder from a local web server (for example VS Code Live Server, Python HTTP server, or a static hosting service). Then open the site in Chrome and choose Add to Home screen / Install App.

## Important
The Nursing Hub contains brief educational revision prompts, not a replacement for clinical guidelines, prescriber instructions, or facility protocols.
