# Zubaan - Android project

## Easiest: build the APK online (no Android Studio)
1. Create a free GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the repository's **Actions** tab, run **Build APK** (it also runs on every upload).
3. When it finishes, download **Zubaan-APK** from the run page, unzip it, and install `app-debug.apk` on your phone (allow "install unknown apps").

## Or with Android Studio
File > Open this folder, let Gradle sync, then Build > Build APK(s).
For a Play Store release use Build > Generate Signed Bundle / APK.

## What is included
- Launcher icon (adaptive + legacy) made from your Zubaan artwork, plus `store_icon_512.png`.
- Splash screen: your logo with "Powered by Hammad Ikhlaq" under it, shown ~2.3 s after tapping the icon.
- The app runs offline from `app/src/main/assets/index.html`; spoken words use the phone's Text-to-speech engine.
