# Bhagyalaxmi Delivery Challan (offline)

This is a local, single-device delivery-challan app. It does not use a server, account, or internet connection. Challans and saved transport names stay in the browser storage on the computer where you use it.

## Start it

Double-click `start.bat`, or open `index.html` in Chrome or Edge.

## Use it on an Android phone

1. Copy the complete app folder to the phone. Keep `index.html`, `app.js`, `styles.css`, and the `assets` folder together.
2. In the phone's Files app, open `index.html` using Chrome or Edge. If the Files app only offers a viewer, use its **Open with browser** option.
3. Use the same browser each time. Saved challans, saved recipients, and transport names are stored only in that browser on that phone.
4. Use the browser menu's **Print** or the app's **Print / Save PDF** button to create a PDF. Share that PDF through WhatsApp manually.

## Use it

1. Enter the recipient, transport, vehicle, and items.
2. Leave challan number on **Automatic** to get the next `DC-0001` style number, or choose **Manual** to type your own.
3. For an item, enter NOS or SET. The blank one becomes `–` in the printable challan. Leave amount blank when it should not be included in the total.
4. Click **Save challan**. Use the Previous challans list to find and reopen a saved challan.
5. Click **Print / Save PDF**, then choose **Save as PDF** in the print window. Use A4 portrait and 100% scale for the supplied layout.

## Important

- Browser data is local to this browser profile. Do not clear browser site data if you want to keep the saved challans.
- The app has no multi-user synchronization or network access. A later version can add backups, shared access, or WhatsApp sending.


MOBILE FIX NOTES
- Saved challan rows now attach direct click/touch handlers for Android WebView compatibility.
- Print still depends on the APK converter's WebView print implementation. If it does not show a print dialog, open the same project in a browser that supports printing or use a wrapper with native WebView printing support.
