EC Technologie V3 — Gestion commerciale

Structure Android WebView :
web/index.html est le point d'entrée attendu par le wrapper Android.

V3 améliore notamment l'accueil :
- tableau de bord premium et compact
- identité visuelle EC Technologie avec logo
- accès rapides
- KPI activité
- activité récente et indicateurs
- statut de synchronisation
- interface rectangulaire/mobile

Fonctions conservées : stock, gains, achats, clients/fournisseurs, documents Devis/Proforma/BL/Facture, aperçu, impression/PDF, paramètres, sauvegarde/restauration et préparation synchronisation REST.

Important : la synchronisation entre plusieurs téléphones nécessite un backend/API réel configuré dans Paramètres.
