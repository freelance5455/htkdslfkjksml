# Crypto Max PRO — By Bilel Fridhi

Application crypto HTML/CSS/JS (arabe RTL par défaut, français, anglais) empaquetée en APK Android avec Capacitor.

## Fonctionnalités opérationnelles
- Marché : 15 cryptos, prix réels via l'API publique Binance (repli sur data-api.binance.vision), variation 24 h, recherche, favoris, actualisation toutes les 30 s, heure de dernière mise à jour, erreurs et limites de requêtes gérées.
- Graphiques en chandeliers ou courbe (1H, 1D, 1W, 1M, 1Y).
- Alertes de prix (vérifiées uniquement quand l'app est ouverte).
- Récompenses : suivi personnel de sources que vous vérifiez vous-même (aucune source inventée, aucun gain garanti).
- Langues : arabe, français, anglais, changement sans réinstaller.

## Pas encore disponible
Comptes, chat, groupes, notifications push : ils nécessitent un backend (Supabase ou Firebase, offres gratuites à comparer). Aucun écran ne les présente comme actifs.
Limites : l'API publique Binance est limitée par IP ; en cas de blocage régional l'app affiche une erreur au lieu de données inventées.

## Générer l'APK depuis le téléphone
1. Créez un dépôt GitHub (ou utilisez Crypto-max) et téléversez tout le contenu de ce ZIP, y compris le dossier .github.
2. Onglet **Actions** → **Build APK Debug** → **Run workflow**.
3. Quand le build est vert, ouvrez l'exécution → **Artifacts** → téléchargez `CryptoMaxPRO-debug-apk` (ZIP contenant app-debug.apk), extrayez-le et installez l'APK (autoriser les sources inconnues).
4. Si le build échoue, copiez les dernières lignes du log de l'étape rouge et envoyez-les.

## Développement
`npm install`, `npm test`, `npm run build:web`. Le dossier android/ est généré par la CI (`npx cap add android`).
Release signé : à ajouter plus tard avec des secrets GitHub (jamais de clé dans le dépôt).

## Version 1.1 — thème Binance-like, analyse, assistant IA, chat
- Palette jaune/gris anthracite avec vert et rouge pour hausse/baisse (identité originale, aucun logo Binance).
- **Analyse technique** (onglet IA) : RSI, SMA20/50, support/résistance, volatilité calculés sur les bougies réelles ; ce n'est pas un modèle d'IA.
- **Assistant IA** : désactivé tant qu'un proxy n'est pas configuré. Déployez `backend/ai-worker.js` (Cloudflare Workers, clé en secret), collez son URL https dans l'onglet IA. L'API Anthropic est payante, donc hors budget 0 DT si vous l'activez.
- **Chat** : désactivé tant que Supabase n'est pas configuré. Exécutez `backend/supabase.sql`, puis saisissez l'URL et la clé publique (anon) dans l'onglet Chat. Chat public anonyme avec salons, pseudo et signalement. Comptes, messages privés et blocage restent à faire (Supabase Auth). Vérifiez les quotas actuels de l'offre gratuite Supabase.
