# Marine Boilers Cadet - APK Package (FAB Edition)

Final build: All buttons working, FAB with 5 items (Home, Chapters, Diagrams, Checks, Quiz), 0% default progress.

## Files:
- index.html - Main app (final validated build)
- image_*.webp - 5 boiler diagrams
- capacitor.config.json - Capacitor config
- manifest.json - PWA manifest
- package.json - Dependencies

## Build APK - 3 Methods:

### Method 1: PWABuilder (Fastest - 5 mins, no coding)
1. Go to https://www.pwabuilder.com
2. Enter URL of hosted index.html or upload to Netlify
3. Click Build My PWA -> Android Package
4. Download APK

### Method 2: Capacitor (Recommended)
```bash
npm install
npx cap add android
npx cap copy
npx cap open android
```
Then in Android Studio: Build -> Build Bundle(s) / APK(s) -> Build APK(s)

### Method 3: Android Studio WebView
1. New Project -> Empty Activity
2. Add permission in AndroidManifest.xml: <uses-permission android:name="android.permission.INTERNET" />
3. Replace activity_main.xml with WebView filling parent
4. In MainActivity.kt: webView.loadUrl("file:///android_asset/index.html")
5. Put all files in app/src/main/assets/
6. Build APK

## Features:
- FAB Navigation (Home, Chapters, Diagrams, Checks, Quiz)
- Diagrams screen with 5 diagrams + embedded in chapters
- All buttons working (Start Reading, View All, Reset Progress, Quick Cards)
- 0% default progress, Continue Reading -> Chapter 1
- Chapter-wise quiz, checklists
- No status bar, no zoom buttons

Version: FAB Final - PASSED (0 issues)
