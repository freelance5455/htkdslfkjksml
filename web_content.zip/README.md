# C&E Sales Manager — Netlify

1. Netlify > Add new project > Deploy manually
2. ဒီ folder ထဲက ဖိုင်အားလုံးကို drag & drop လုပ်ပါ။
3. ထွက်လာတဲ့ `*.netlify.app` URL ကို Chrome/Safari နဲ့ဖွင့်ပါ။
4. Android: Browser menu > Add to Home screen / Install app
5. iPhone: Share > Add to Home Screen

ပါဝင်သည့် PWA ဖိုင်များ:
- index.html
- manifest.webmanifest
- sw.js
- icon.jpg
- netlify.toml

မှတ်ချက်: App ရဲ့ မူရင်း Supabase Cloud Sync code ကို မဖျက်ဘဲ ထားထားပါတယ်။
