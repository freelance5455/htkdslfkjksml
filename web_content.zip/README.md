# GhostJump 3D — Pacote do Jogo (Site / WebView)

Este pacote contém o jogo 3D completo **GhostJump 3D** compilado em arquivo único (`index.html`), pronto para rodar na web ou ser embutido diretamente em WebViews de aplicativos móveis.

---

## 🎮 Como Jogar no Computador ou Celular

Basta abrir o arquivo `index.html` em qualquer navegador moderno (Chrome, Edge, Firefox, Safari ou navegadores móveis).
O jogo funciona **100% offline** e salva recordes, configurações e o visual selecionado da mão/faca no armazenamento local do dispositivo.

---

## 🌐 Publicação em Servidores Web (1 Clique)

| Plataforma | Como Publicar |
|---|---|
| **Netlify** | Arraste esta pasta para [app.netlify.com/drop](https://app.netlify.com/drop) |
| **Vercel** | Execute `npx vercel` nesta pasta ou envie para o GitHub |
| **GitHub Pages** | Ative o GitHub Pages na branch e aponte para a raiz com este `index.html` |
| **itch.io** | Crie um projeto HTML5 e envie este ZIP diretamente |
| **Hospedagem Própria** | Copie `index.html` para o diretório público de qualquer servidor Apache, Nginx ou CPanel |

---

## 📱 Como Usar em um Aplicativo Android com WebView

Para transformar este jogo em um aplicativo Android (.apk) usando WebView:

1. Coloque o arquivo `index.html` na pasta `app/src/main/assets/` do seu app.
2. No seu layout XML, adicione uma `WebView`:
```xml
<WebView
    android:id="@+id/webView"
    android:layout_width="match_parent"
    android:layout_height="match_parent" />
```
3. No código da sua Activity, configure o suporte a WebGL e carregue o jogo:
```java
webView.getSettings().setJavaScriptEnabled(true);
webView.getSettings().setDomStorageEnabled(true);
webView.getSettings().setAllowFileAccess(true);
webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
webView.loadUrl("file:///android_asset/index.html");
```

Também funciona perfeitamente com **Capacitor** (`npx cap init` / `npx cap add android`) ou **Cordova**.

---

## ⚡ Recursos Inclusos neste Pacote

- **60 percursos 3D** divididos em 5 níveis de dificuldade (Treinamento, Céu, Neon, Industrial, Extremo + expansão).
- **Física de Parkour:** Bunny hop que preserva e ganha velocidade, air strafe e controle aéreo suave.
- **Mão e faca:** três armas oficiais sem fundo: Butterfly Hello Kitty, Rosa e Baioneta M9 Urbana, além da opção "Sem Arma".
- **Fundo 100% transparente:** canal alfa real sem fundo preto ou halos, integrando-se naturalmente a qualquer iluminação ou mapa.
- **Controles Universais:** Teclado & Mouse, Gamepads USB/Bluetooth (Xbox, PS, Genéricos) e Controles de Toque (Joystick analógico virtual).
- **Modo Tela Cheia e Paisagem** com adaptação automática em celulares e tablets.
