# Auto Business AI — MVP cloud engine

Ce projet est le noyau serveur de l'application que nous avons défini :
- recherche de signaux publics et actualités ;
- analyse d'opportunités avec OpenRouter ;
- création de produits numériques, notamment des ebooks riches ;
- traduction/localisation de **tout** le contenu ;
- pages de vente, emails, FAQ et messages marketing ;
- orchestration PayGate avec une commande unique par paiement ;
- suivi des commandes et livraison ;
- boucle post-achat ;
- notifications de fin d'analyse ;
- tableau de bord téléphone.

## Sécurité portefeuille — point important

Le serveur **ne demande ni ne stocke** la phrase secrète, la clé privée ou le mot de passe de Trust Wallet.
L'adresse de réception publique peut être configurée.

L'IA peut :
1. lire des informations publiques sur le portefeuille ;
2. analyser les risques et opportunités ;
3. préparer une proposition de transaction ;
4. notifier l'administrateur.

Elle ne signe ni n'envoie automatiquement une transaction. La validation finale doit être faite par l'utilisateur dans son portefeuille. C'est volontaire : un agent ne doit pas recevoir les secrets du portefeuille.

Trust Wallet fonctionne en garde autonome et indique que les clés privées ne sont pas accessibles par le service.
Voir : https://trustwallet.com/fr/security

## Lancer

Node.js 18+ recommandé.

1. Copier `config.example.json` vers `config.json`.
2. Renseigner la clé OpenRouter et les paramètres PayGate.
3. Définir `publicBaseUrl` avec l'URL HTTPS du serveur.
4. `node server.js`
5. Ouvrir `/admin`.

Le moteur fonctionne côté serveur : le téléphone peut être éteint.

## PayGate

Le module crée un identifiant de commande et une URL de paiement côté serveur.
Le paiement n'est considéré comme payé qu'après le callback PayGate associé à la commande.
Ne réutilise pas une même URL/callback pour plusieurs commandes.

## Ebook

Un ebook généré doit pouvoir contenir :
- couverture et titre ;
- promesse et avertissement de limites ;
- sommaire détaillé ;
- introduction ;
- chapitres structurés ;
- exemples et études de cas ;
- exercices ;
- checklists ;
- tableaux ;
- modèles/templates ;
- plan d'action ;
- FAQ ;
- ressources ;
- résumé et prochaines étapes ;
- offre complémentaire ;
- métadonnées et version.

La localisation traduit le corps de l'ebook, les exercices, tableaux, couverture, description, page de vente, FAQ, emails et messages marketing.
Une étape QA recherche les passages restant dans la langue source.

## Notifications

Le serveur enregistre les événements dans `data/notifications.json`.
Le tableau de bord téléphone peut les lire via `/api/notifications`.
Pour de vraies notifications Android en arrière-plan, l'APK devra brancher ce flux à son système de notifications (par exemple via son propre service push). Le serveur ne dépend pas du téléphone pour travailler.

## Important

Ce MVP ne promet aucun nombre de ventes. Il mesure les étapes du tunnel et permet d'étendre les produits/niches/langues à partir des données.
