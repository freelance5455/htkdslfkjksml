# Familienzeit – Android-Quellprojekt

Native Android-App in Kotlin und Jetpack Compose, plus eine browserbasierte `index.html` als Einstieg für HTML-zu-APK-Konverter. Beide starten ohne Demo-Modus und ohne vorgefertigte Beispiel-Familie. Neue Installationen starten mit der Einrichtung einer Familie oder der Anmeldung mit Familiencode, Name und achtstelligem PIN.

## Enthalten

- Dunkle Startseite und Navigation
- Familienchat und persönliche Chats
- Kalender-Einträge mit Datum und Sichtbarkeit für alle oder privat
- Aufgaben mit Sichtbarkeit für alle oder privat
- Familiengalerie mit echtem Bild-Upload zu Firebase Storage
- Profilseite mit Abmeldung und Admin-Aktion zum Einladen eines Mitglieds
- Serverseitige PIN-Erzeugung und -Prüfung; PINs werden gesalzen gehasht gespeichert
- Firestore- und Storage-Regeln, Auth über Firebase Custom Tokens, Login-Drosselung und App Check

## Voraussetzungen

- Android Studio mit Android SDK 35 und JDK 17
- Ein eigenes Firebase-Projekt mit Cloud Firestore, Cloud Functions und Storage
- Firebase Blaze-Abrechnung für Cloud Functions 2nd gen und Storage, abhängig von Region/Nutzung
- Node.js 20 und Firebase CLI zum Bereitstellen des Backends

## Einrichten

1. In `app/build.gradle.kts` steht die App-ID `de.familienzeit.app`. Registriere genau diese Android-App im eigenen Firebase-Projekt.
2. Lade die zu diesem Firebase-Projekt gehörende `google-services.json` herunter und lege sie in `app/`. Sie ist absichtlich nicht im ZIP enthalten.
3. Aktiviere in Firebase Authentication die Anmeldung mit benutzerdefiniertem Token. Erstelle Firestore und Storage.
4. Aktiviere App Check für Android mit Play Integrity. Für lokale Debug-Builds muss ein App-Check-Debug-Token in der Firebase Console registriert werden.
5. Installiere die Firebase CLI, melde dich mit deinem Google-Konto an und wähle das Projekt im Projektordner:

   ```sh
   firebase login
   firebase use --add
   ```

6. Stelle Funktionen und Sicherheitsregeln bereit:

   ```sh
   cd functions
   npm install
   npm run build
   cd ..
   firebase deploy --only functions,firestore:rules,storage
   ```

7. Öffne den Projektordner `familienzeit-android` in Android Studio, synchronisiere Gradle und starte die App auf einem Gerät.

## Einrichtung und Zugang

Die erste Person erstellt die Familie. Die App zeigt Familiencode und persönlichen PIN einmalig an; beides sicher notieren. Die eingeladene Person erhält einen Namen und einen einmaligen PIN, der über Profil → Mitglied einladen erstellt wird. Für die Anmeldung werden Familiencode, Name und PIN benötigt. Der Familiencode ist der gemeinsame Familienbezeichner; der PIN allein ist keine ausreichende Anmeldung.

## Wichtige Grenzen dieses Quellstands

Das ist ein echter App-Quellstand ohne Demo-Datensätze, aber noch kein fertig eingerichteter, veröffentlichungsreifer Dienst. Firebase-Projekt, Android-`google-services.json` und bei `index.html` die Firebase-Webkonfiguration samt reCAPTCHA-v3-Site-Key müssen vom Betreiber ergänzt werden. Für die HTML-Version muss die Datei über eine HTTPS-Domain laufen, die in Firebase App Check registriert ist; ein HTML-zu-APK-WebView kann deshalb zusätzliche App-Check-Konfiguration benötigen. Es gibt derzeit noch keine PIN-Wiederherstellung, keinen Kalender-Monatsraster, keine Bearbeitung/Löschung von Chatnachrichten  Die Anmeldung ist auf den ersten Release ausgelegt; vor Veröffentlichung sollten App-Check, Berechtigungen, Datenaufbewahrung, Datenschutztext und Kontowiederherstellung im eigenen Firebase-Projekt geprüft werden.

## Ordner

- `index.html` – browserbasierte Version/HTML-Konverter-Einstieg; verlangt Firebase-Webconfig und App-Check-Site-Key
- `app/` – Android-Client
- `functions/` – Cloud Functions für Familienanlage, Einladungen und PIN-Anmeldung
- `firestore.rules` und `storage.rules` – serverseitige Zugriffsregeln
- `firebase.json` – Firebase-Deployment-Konfiguration

## Versionshinweis

Die Firebase Android BoM ist auf 35.0.2 gesetzt, wie in der aktuellen Firebase-Android-Einrichtungsdokumentation angegeben. Der Quellstand wurde hier nicht gegen ein Android SDK gebaut, da in der Arbeitsumgebung kein Android SDK/Gradle installiert ist.
