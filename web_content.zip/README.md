# Haneesh OS — HTML + Kotlin Android Launcher

This project uses an HTML/CSS/JavaScript interface inside an Android WebView, with Kotlin for Android integration.

## Features
- First-launch welcome popup with **Set as your OS**, **Preview first**, and **Later**.
- HTML design gallery with mock phone-screen previews.
- Home, app drawer, Control Center, notifications, settings, and themes previews.
- Android HOME intent filter, allowing Android to list Haneesh OS as a possible Home app.
- Set-as-home button opens Android's system Home app selection/settings. Android always requires the user to select/approve the default launcher.

## Build APK
1. Extract this ZIP.
2. Open the project folder in Android Studio.
3. Allow Gradle sync/downloads.
4. Choose Build → Build Bundle(s) / APK(s) → Build APK(s).
5. Install the APK, open it, and use the preview gallery.
6. Tap **Set as your OS** and select Haneesh OS in Android's Home app screen. Menu names vary by device.

## Important limitations
This is a launcher app, not a replacement Android operating system. When selected as the default Home app, the phone's Home action can open this interface. It does not replace the lock screen, Android Settings, notification shade, system status bar, or system apps. Wi-Fi/Bluetooth tiles in the HTML are visual demos; ordinary apps cannot freely toggle system radios on current Android versions.
