# أنجز AI - ملفات التطبيق (PWA)

## محتويات الملف
- index.html : التطبيق كاملًا
- manifest.webmanifest و sw.js و icons/ : ملفات التثبيت كتطبيق
- worker.js : خادم وسيط يخفي مفتاح الذكاء الاصطناعي

## 1) ربط الذكاء الاصطناعي
1. في Cloudflare أنشئ Worker والصق worker.js ثم Deploy.
2. أضف سرًّا باسم ANTHROPIC_API_KEY بمفتاحك من console.anthropic.com.
3. ضع رابط الـ Worker في index.html داخل CONFIG.AI_ENDPOINT.
لا تضع المفتاح داخل index.html أبدًا.

## 2) نشر الموقع (لازم HTTPS)
ارفع كل الملفات ما عدا worker.js على Cloudflare Pages أو Netlify (مجاني) مع الحفاظ على مجلد icons.

## 3) التثبيت على الجوال
- أندرويد (كروم): القائمة ثم "تثبيت التطبيق" أو "إضافة إلى الشاشة الرئيسية".
- آيفون (سفاري): مشاركة ثم "إضافة إلى الشاشة الرئيسية".

## 4) ملف APK
1. افتح pwabuilder.com وألصق رابط موقعك المنشور.
2. اختر Android ثم Generate، وحمّل الـ APK (أو الحزمة لرفعها على Google Play).
3. التوقيع: PWABuilder يولّد مفتاح توقيع؛ احتفظ به لتحديث التطبيق لاحقًا.

## 5) الإعلانات
ضع رقم AdSense في CONFIG.ADSENSE_CLIENT وأرقام الوحدات في CONFIG.SLOTS بعد موافقة AdSense على نطاقك.
