# Daily Idioms — Android App

This project wraps the supplied Daily Idioms HTML app in an Android WebView.

## Open
Open this folder in Android Studio.

## Build APK
Android Studio: Build → Build Bundle(s) / APK(s) → Build APK(s)

The generated debug APK will normally be under:
app/build/outputs/apk/debug/app-debug.apk

## Notes
- JavaScript and DOM/local storage are enabled.
- The existing HTML app is kept as `app/src/main/assets/index.html`.
- The app is portrait-only.
- Internet permission is not required for the local HTML itself.
