# Universal Audio Recorder

Application web/PWA locale pour Android.

Fonctions incluses:
- microphone + enregistrement
- pause/reprise/arrêt
- chronomètre
- stockage local IndexedDB
- lecture
- vitesse 0.75x à 2x
- recherche et tri
- renommage
- favoris
- suppression
- import audio
- export
- partage si supporté
- thème clair/sombre
- interface responsive

Pour tester:
1. Ouvrir index.html dans un navigateur compatible.
2. Autoriser le microphone.
3. Pour une PWA installable, servir les fichiers depuis HTTPS ou localhost.
