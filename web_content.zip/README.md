# Wallet Finder Android v36

Android Studio project wrapping `Wallet_Finder_FIXED_v36.html` in a WebView.

## Build
Open this folder in Android Studio, allow Gradle sync, then Build > Build APK(s).

The app includes INTERNET permission because the HTML uses online price/API resources. The HTML remains a demo/simulator and does not provide real wallet access or real transaction execution.


QR scanner fix: camera permission is declared in the Android manifest, requested at runtime when the QR scanner is opened, and the WebView now serves the bundled page through a secure appassets HTTPS origin so getUserMedia can access the camera after permission is granted.
