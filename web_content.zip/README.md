# Real Football 3D — Android Project

Project ini membungkus game HTML/Three.js Real Football 3D ke dalam Android WebView.

## Build
1. Buka folder ini di Android Studio.
2. Tunggu Gradle selesai melakukan sync.
3. Pilih Build > Build APK(s).
4. APK debug akan berada di `app/build/outputs/apk/debug/`.

## Catatan
Game menggunakan Three.js dari CDN pada HTML. Jadi saat game dijalankan, koneksi internet diperlukan untuk mengambil library Three.js kecuali library tersebut nanti disimpan lokal.
