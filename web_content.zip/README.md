# Fingerprint Attendance - HTML + Android Bridge

આ projectમાં `www/index.html` છે.

HTML ભાગમાં:
- Employee Registration
- IN/OUT attendance
- Date/time
- LocalStorage attendance list

મહત્વપૂર્ણ:
index.html પોતે ફોનના fingerprint sensorને સીધું access કરી શકતું નથી.
Native Android WebViewમાં `AndroidBiometric.authenticate(callback)` bridge implement કરવાથી actual Android BiometricPrompt ખોલી શકાય છે.
