CryptoTrader v4.4 — melhorias de interface

- Swipe em qualquer zona do ecrã entre Painel, Mercado, Posições, Histórico, Backtest e Config.
- Gráfico inline por moeda.
- Gráfico com preço, EMA20, EMA50, entrada e pico quando existe posição.
- Score com explicação dos componentes.
- Painel com posições, lucro realizado, taxa de acerto, melhor venda e alertas.
- Backtest com maior queda da carteira.
- Paper Trading continua ativo internamente; sem ordens reais.
