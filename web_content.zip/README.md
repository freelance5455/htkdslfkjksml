# Kalkulator Nilai Ulangan - Mas Didot

Aplikasi kalkulator nilai ulangan dengan icon logo Mas Didot.

## Cara membuat APK

### Opsi 1: Online (Paling Mudah - Gratis)

1. Buka salah satu situs berikut:
   - https://www.htmltoapk.dev/
   - https://appsgeyser.com/
   - https://www.ziptoapk.com/

2. Upload file **MasDidot_Kalkulator_Nilai.zip** (ada di folder ini)
   atau upload folder `www/` (berisi index.html + logo.png)

3. Atur:
   - **App Name**: Kalkulator Nilai Mas Didot
   - **Package Name**: com.masdidot.kalkulatornilai (atau biarkan default)
   - **Icon**: Upload file `res/icon/icon-512.png` atau logo.png

4. Build & Download APK

### Opsi 2: Menggunakan Cordova (Lokal)

```bash
npm install -g cordova
cordova create MasDidotApp com.masdidot.kalkulator "Kalkulator Nilai Mas Didot"
cd MasDidotApp
# Copy isi www/ ke www/
# Ganti icon di res/
cordova platform add android
cordova build android
```

### Opsi 3: Android Studio

Buat project Empty Activity dengan WebView, load file index.html dari assets.

## File yang tersedia

- `www/index.html` : Aplikasi utama (sudah include logo)
- `www/logo.png` : Logo untuk dalam app
- `res/icon/icon-*.png` : Icon berbagai ukuran untuk Android
- `MasDidot_Kalkulator_Nilai.zip` : Siap upload ke online converter

