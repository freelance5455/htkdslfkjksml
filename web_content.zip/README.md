# AirTouch (Android) – hands-free browser + system-wide control

Front camera → MediaPipe Hand Landmarker → pointer dot → gestures. Two ways to use it:

1. **Gesture browser (works right away, no special permission).** A built-in browser (HTML start page with
   YouTube, Google, Instagram, … tiles). The hand control runs inside the browser screen and injects real
   touch events, so toolbar, tiles, YouTube, scrolling, fullscreen video – everything – is controlled by gestures.
2. **System-wide mode (optional).** A foreground service + AccessibilityService draw the dot over ALL apps and
   perform taps, long-press, swipes, Back/Home/Recents in any app, also in the background.

See **BUILD.md** for ZIP2APK / build-server settings.

## Gestures
| Gesture | What happens |
|---|---|
| Move palm | Dot moves |
| Thumb + index pinch | Finger touches the screen: tap · hold = long-press · pinch-and-move = drag/select |
| Two quick pinches | Double tap (YouTube: seek ±10 s) |
| ✌ Index + middle up, others folded, move hand | Smooth scroll up/down/left/right (orange ring) |
| Thumb + middle finger | Back |
| Thumb + ring finger | Forward (browser) · Home (system mode) |
| Thumb + little finger | Home page (browser) · Recents (system mode) |

Browser toolbar (also hand-operable): ◀ ▶ ⟳ ⌂ 🎤 (voice search) ✋ (hand control on/off) ✕ (close), address/search box.

## First run
1. Open AirTouch → **Allow camera & notifications**.
2. **Download hand model** (only if the APK was built without internet; ~8 MB, one time).
3. **Open AirTouch Browser** → show your hand to the FRONT camera.
4. Optional system-wide mode: **Open Accessibility settings** → AirTouch → ON
   (Android 13+ sideloaded: App info → ⋮ → *Allow restricted settings*), then **Start system-wide control**.
   Opening the browser automatically hands the camera over from system mode.

## Build
`./gradlew assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk` (details in BUILD.md).

## Edit the start page
`app/src/main/assets/www/home.html`, `home.css`, `home.js` (plain HTML/CSS/JS). Tiles are in `home.js`.

## Tuning (main screen)
Hand reach, smoothness, pinch sensitivity, scroll speed.

## Known limits
* Camera runs continuously → battery drain + green camera indicator.
* System mode: many phones stop camera use when the screen is locked; set battery to "Unrestricted".
  Scroll in system mode is executed as a swipe when you lower your hand (not live); in the browser it is live.
* Banking apps, DRM video and password screens may block accessibility input.
* Google sign-in is often refused inside any embedded browser; browsing and YouTube work without signing in.
* Accessibility apps need Play Store policy approval to publish; for personal use sideload the APK.

## HTML version (`web/` folder)
`web/index.html` is the older browser/PWA demo (pinch tap, double pinch, pinch-scroll inside its own page only).
`cd web && python -m http.server 8000`. The Gradle build ignores it.
