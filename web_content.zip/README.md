# Deriv DigitMatches Ultra Pro

## Features
- HTML/CSS/JavaScript responsive dashboard.
- Public Deriv WebSocket tick stream.
- Digit extraction, frequency distribution, entropy, streak and volatility metrics.
- Heuristic next-digit ranking with configurable threshold.
- Training/paper mode UI: no real orders are submitted.
- Optional OAuth 2.0 Authorization Code + PKCE backend.

## Run
1. Put `index.html`, `styles.css`, `app.js` in `public/`.
2. Put `server.js` beside `public/`.
3. `npm init -y && npm i express express-session`
4. Register a Deriv OAuth app and configure its redirect URI.
5. Set `DERIV_CLIENT_ID` and `DERIV_REDIRECT_URI`.
6. Run `node server.js`.
7. Open `http://localhost:3000`.

Important: OAuth token exchange belongs on a backend, not in browser JavaScript. Keep access tokens server-side. The public tick stream does not require OAuth. The heuristic is statistical analysis, not a guarantee of the next digit.
