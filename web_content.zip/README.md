# MOVA+ MVP 1.0
Área inicial: Cidade de Maputo + Província de Maputo.

## Conteúdo
- frontend/index.html: protótipo funcional local para fluxo passageiro/motorista/admin.
- backend/server.js: API mínima de referência para a próxima etapa.

## Próxima implementação
1. Base de dados PostgreSQL.
2. Autenticação e perfis.
3. GPS/mapas.
4. Notificações em tempo real.
5. Pagamentos digitais.
6. Hospedagem HTTPS.
7. Publicação Android/iOS/PWA.

A versão incluída ainda não processa pagamentos reais nem envia localização real.
