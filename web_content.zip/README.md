# Fleurie by Elixir — proyecto inicial Android

Este ZIP contiene un **prototipo Android editable** de Fleurie, construido con una actividad Kotlin que muestra una interfaz HTML/CSS/JavaScript local dentro de WebView.

## Abrir y generar APK

1. Descargá y descomprimí el ZIP.
2. Instalá Android Studio.
3. En Android Studio elegí **Open** y seleccioná la carpeta `Fleurie_by_Elixir`.
4. Esperá a que Gradle sincronice el proyecto. Si lo solicita, instalá Android SDK 35 y usa JDK 17.
5. Para generar el APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. El APK de prueba aparecerá en `app/build/outputs/apk/debug/app-debug.apk`.

## Qué incluye esta primera versión

- Navegación principal y catálogo de módulos Fleurie.
- Diseño vintage romántico adaptable.
- Dashboard inicial.
- Agenda y tareas guardadas localmente.
- Hábitos, diario y movimientos financieros locales.
- Perfil con banner de color editable.
- Publicaciones locales de demostración.
- Fleurie Academy con materias, demostración de clase y flashcards.
- Fleurie Career para registrar oportunidades y enlaces.
- Personalización de temas y tipografías de muestra.
- Biblioteca inicial de kaomojis.
- Datos guardados en el almacenamiento local del navegador/WebView.

## Importante: límites del prototipo

Esto **no es todavía la plataforma de producción completa**. No incluye servidor, cuentas reales, sincronización entre dispositivos, feed compartido, mensajería entre usuarios, subida de imágenes, notificaciones push, ofertas laborales en vivo, pagos, suscripciones ni tutor de IA conectado.

Para esas funciones hará falta diseñar e implementar backend, base de datos, almacenamiento seguro, moderación, integraciones externas y políticas de privacidad. No coloques claves privadas de servicios de IA dentro de la APK.

Las funciones Premium no están bloqueadas ni cobradas en este prototipo, porque la lista exacta de funciones que la propietaria había marcado como Premium debe conservarse sin inventar cambios.

## Personalización

La aplicación es editable desde `app/src/main/assets/index.html`. Los datos del prototipo se guardan localmente en el dispositivo y pueden perderse si se borran los datos de la aplicación.

## Requisitos sugeridos

- Android Studio reciente.
- JDK 17.
- Android SDK 35.
- Conexión a Internet para la primera sincronización de Gradle.

Nombre del paquete: `com.elixir.fleurie`
Versión: `0.1.0`
