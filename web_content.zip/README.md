# Kasa – APK yapma adımları

Gerekenler: Node.js (18+) ve Android Studio.

1. Bu klasörde terminal aç:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
2. Android Studio açılınca: Build > Build Bundle(s) / APK(s) > Build APK(s)
   (Yayın için imzalı APK: Build > Generate Signed App Bundle / APK)
3. APK'yı telefona atıp kur ("bilinmeyen kaynaklardan yükleme" izni gerekebilir).

Web dosyalarını (www/) değiştirirsen: npx cap sync android

Alternatif (kodsuz): www/ klasörünü bir HTTPS adrese yükle, https://www.pwabuilder.com ile APK üret.

Önemli: Şifre unutulursa veriler kurtarılamaz. Uygulama silinirse kasa da silinir.
