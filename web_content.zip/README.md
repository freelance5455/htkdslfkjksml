# Isack Meat Supply Android build project

This wraps the updated Isack Meat Supply web app in an Android WebView and provides a GitHub Actions workflow to compile a debug APK for free.

## Build the APK
1. Create a GitHub repository and upload the contents of this folder (not the folder itself).
2. Open Actions and run **Build Isack Meat Supply APK**.
3. Download the `Isack-Meat-Supply-APK` artifact from the completed run; it contains `app-debug.apk`.

This is a build project, not a precompiled APK. This environment does not have the Android SDK/Gradle installed, so it cannot compile and validate the APK here. The web app stores data locally in the app's WebView storage; back up records regularly. Do not clear app data unless backed up.
