# DAGACHAT COMPLET — V2

## Ce qui est inclus
- Comptes réels sur serveur (inscription / connexion)
- Base de données légère JSON pour démarrage rapide
- Liste des utilisateurs
- Messagerie temps réel WebSocket
- Historique des messages
- Envoi de photos, vidéos et petits fichiers (8 Mo)
- Notifications navigateur lorsque l'autorisation est accordée
- Demande d'accès caméra / microphone
- Signalisation WebRTC pour appels audio/vidéo
- Interface mobile responsive
- PWA installable

## Démarrage
1. Installer Node.js 18 ou plus.
2. Dans ce dossier, exécuter:
   `npm install`
3. Puis:
   `npm start`
4. Ouvrir `http://localhost:8080`.

## Pour deux téléphones
Le serveur doit être accessible sur Internet (HTTPS recommandé). Déployer ce dossier sur un serveur/VPS, puis ouvrir l'adresse HTTPS de DAGACHAT sur les deux téléphones.

## Important
Le projet fournit le réseau et la signalisation. Pour une application Android de production, il faut encore:
- HTTPS/WSS avec un vrai domaine;
- une base PostgreSQL/MySQL ou équivalent;
- stockage objet pour gros fichiers;
- authentification renforcée (JWT/session sécurisée, vérification du numéro);
- FCM pour les notifications Android lorsque l'application est fermée;
- TURN (ex. coturn) en complément de STUN pour fiabiliser les appels WebRTC derrière certains réseaux;
- chiffrement de bout en bout si tu veux un niveau de sécurité comparable à WhatsApp;
- gestion réelle des groupes, présence, accusés de réception, blocage et modération.

Cette archive est donc un **projet complet de démarrage fonctionnel**, pas une promesse d'un service Internet déjà hébergé.
