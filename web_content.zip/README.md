# Halo App Maker mobile package

This bundle contains the Halo App Maker installable web app and the full source needed to run its Gemini-backed generation flow.

## What is included

- `web-build/` — production frontend output with PWA metadata
- `app/` — React + Vite source, Material 3 Expressive styling, Material You dynamic color engine, prompt history, attachments, live preview, and ZIP export UI
- `api/` — Express Gemini generation and ZIP export routes
- `shared/` — generated API clients, Zod schemas, and OpenAPI contract

## Wrapping into an APK

Use `web-build/` with a trusted web-to-APK compiler, or host the frontend and API together and wrap the hosted URL. The generated app expects the API at the same origin under `/api` so that prompts can reach the server securely.

Set `GEMINI_API_KEY` only in the server environment. Do not put it in the APK or frontend bundle.

This is a source/PWA package, not a native Android Studio project. No APK is included because this workspace does not have an Android build pipeline.
