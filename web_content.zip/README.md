# FOTO DUEL 2.5.0 — Photo Card Arena

Jogo de cartas colecionáveis para Android e navegador, feito em HTML, CSS e JavaScript. Esta edição preserva os módulos e conteúdos da versão completa anterior e corrige a entrega para APK, a seleção de fotografias e a análise local das imagens.

## 1. O que foi corrigido nesta edição

- O tema visual inteiro foi incorporado em `index.html` e `www/index.html`. O arquivo `www/css/style.css` continua no projeto como fonte do tema e fallback. As três cópias agora são idênticas. Também foi removido um fragmento órfão da antiga importação de Google Fonts que contaminava a primeira regra `:root` e podia fazer parsers simples descartarem o tema.
- A página de entrada da raiz continua em `index.html` e o ponto de entrada exigido por alguns geradores continua em `src/main.js`.
- `www/js/boot.js` passou a carregar o jogo original e exibir um painel explicativo se a inicialização falhar. Também detecta bloqueio de armazenamento local e informa quando o progresso pode não persistir.
- Os seletores de galeria/câmera agora são inputs nativos diretamente dentro dos rótulos tocáveis. O fluxo não depende de disparar `input.click()` em campos ocultos.
- Foi adicionado `www/js/photo-analysis.js`: análise determinística dos pixels da foto. Atributos não são sorteados e não há mais nota de reserva falsa quando a leitura falha.
- Se o Canvas não conseguir analisar uma foto, o usuário recebe uma mensagem e pode escolher explicitamente continuar com atributos manuais.
- A mesma inicialização protegida é usada pela página Android em `www/index.html`.
- A configuração Capacitor agora usa a saída real de produção `dist`. Os comandos Android executam Vite antes de sincronizar o projeto.
- Foram adicionados testes de estrutura, testes de regressão da análise fotográfica e testes do motor de batalha.

## 2. Como abrir no conversor HTML→APK

1. Extraia o ZIP completo.
2. Importe a pasta extraída inteira, mantendo `src/`, `www/` e os demais arquivos juntos.
3. Quando o conversor pedir a página inicial, selecione o `index.html` da raiz do projeto — não escolha apenas o arquivo sem as pastas ao lado.
4. Ative JavaScript e armazenamento DOM/local nas opções do WebView.
5. Para galeria e câmera, o conversor precisa implementar o seletor de arquivos do Android (`WebChromeClient.onShowFileChooser`) e conceder a permissão de câmera quando for solicitada.

O CSS está embutido nas duas páginas para evitar a tela sem estilos mostrada em conversores que descartam folhas CSS externas. Os módulos JavaScript continuam em `www/js/`; por isso, não extraia nem envie somente o HTML isolado.

### Uma limitação importante dos conversores

O HTML consegue solicitar galeria/câmera, mas não consegue obrigar um APK de terceiros a abrir o seletor nativo. Se o conversor não implementa o seletor de arquivos do WebView, o botão pode não abrir — isso exige suporte do próprio gerador de APK. O projeto usa inputs nativos compatíveis com WebView, sem depender de um plugin opcional de câmera.

## 3. Como compilar com Capacitor (Android Studio)

Requisitos: Node.js 20 ou superior, npm, Android Studio e Android SDK instalados.

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

No Android Studio, use **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

- `npm run build` cria a pasta `dist/`.
- `capacitor.config.json` aponta para `dist/`.
- `npx cap add android` só é necessário na primeira criação da pasta `android/`.
- Depois de alterar o jogo, use `npm run android:sync` para reconstruir e sincronizar.
- No Windows, `npm run android:apk:windows` executa build, sync e Gradle Debug APK, desde que Android Studio/SDK e Java estejam instalados.

## 4. Como criar sua primeira carta com foto

1. Entre em **Criar carta**.
2. Toque em **Escolher da galeria** ou **Tirar foto**. São seletores nativos; no Android, a escolha depende do suporte do WebView do conversor.
3. Escolha uma imagem JPEG, PNG ou outro formato de imagem reconhecido pelo aparelho. O limite do arquivo original é 15 MB.
4. O FOTO DUEL comprime a foto para reduzir o armazenamento e mostra a prévia.
5. A análise offline examina uma amostra de 96×96 pixels: luminosidade média, variação de luminosidade/contraste, saturação de cor e gradientes/detalhes.
6. Com essas medições, calcula sugestões de ATQ, DEF, PV, raridade, elemento e habilidade. A mesma imagem sempre produz o mesmo resultado.
7. Edite nome, tipo, elemento, raridade, atributos, custo, habilidade e descrição. Toque em **Salvar carta na coleção**.

A análise local mede propriedades visuais simples. Ela não reconhece semanticamente que a foto mostra um cachorro, dragão, pessoa ou objeto. Também não avalia beleza, identidade ou características pessoais. A análise com modelo de visão é opcional: exige uma chave OpenRouter própria e a autorização explícita na tela; a foto será enviada ao provedor para processamento.

Se a análise local não conseguir ler a imagem, o botão para salvar permanece bloqueado até você escolher **Continuar com atributos manuais**. Assim o jogo não apresenta números inventados como se fossem uma análise real.

## 5. Perfil e primeira entrada

Na primeira execução, a tela de boas-vindas pede:

- Nick/username com pelo menos dois caracteres.
- Foto de perfil escolhida no aparelho.
- Toque em **Entrar na arena**.

O perfil, nick, progresso e coleção são guardados localmente. A foto de perfil é comprimida em tamanho menor. Use a opção de backup no Perfil para exportar/importar os dados.

## 6. O jogo: regras principais

- Cada duelo padrão começa com 100 pontos de vida por duelista.
- Cada jogador começa com cinco cartas na mão.
- O primeiro jogador começa com três energias; o segundo, com duas. A energia aumenta em um por turno até o limite de dez.
- O jogador compra uma carta no começo dos turnos seguintes. Quando o monte acaba, cada compra tentada aumenta o dano de fadiga em cinco pontos.
- O campo aceita uma criatura ativa e até duas criaturas no banco.
- Uma carta de criatura pode ser invocada; magias, equipamentos, armadilhas e suportes ativam seus efeitos.
- Um deck tem exatamente 24 cartas e aceita no máximo três cópias da mesma carta.
- Ataques consideram ATQ, DEF, estados e vantagens elementais. Derrotar uma criatura também causa dano ao duelista.
- Veneno e queimadura causam dano no início do turno do afetado; congelamento e fraqueza reduzem o desempenho; escudo e reflexão ajudam na defesa.
- O duelo termina quando os pontos de vida de um duelista chegam a zero ou quando o limite de turnos é atingido.

## 7. Tipos de cartas

1. **Criatura:** ocupa a posição ativa ou uma das duas reservas, podendo atacar e receber dano.
2. **Magia:** efeito de uso imediato, como dano direto ou cura.
3. **Equipamento:** fortalece uma criatura em campo.
4. **Armadilha:** fica preparada e reage quando o adversário ataca.
5. **Suporte:** efeito tático, como bônus de equipe ou efeito especial.

## 8. Elementos e raridades

Elementos: **Neutro, Flora, Chama, Maré, Raio, Arcano, Terra, Sombra e Luz**. A tabela de vantagens elementais modifica o dano em combate.

Raridades: **Comum, Incomum, Rara, Épica, Lendária e Mítica**. A análise local sugere raridade segundo a pontuação visual calculada.

## 9. As 28 habilidades

| Habilidade | Efeito |
|---|---|
| Sem habilidade | Não possui efeito ativável. |
| Regeneração | Recupera 25 PV do duelista. |
| Chama persistente | Aplica 15 de queimadura por dois turnos. |
| Muralha | Concede 35 pontos de escudo. |
| Dreno vital | Causa 20 de dano e recupera 20 PV. |
| Fúria | Concede +30 ATQ temporário. |
| Atordoamento | Faz o rival perder o próximo turno. |
| Inspiração | Compra duas cartas. |
| Toxina | Aplica 10 de veneno por três turnos. |
| Espelho arcano | Reflete 25 pontos do próximo dano. |
| Golpe duplo | Prepara um segundo golpe com 60% da força. |
| Vácuo | Rouba até duas energias do rival. |
| Perfuração | Ataca ignorando parte da defesa. |
| Congelamento | Reduz ATQ rival por dois turnos. |
| Purificação | Remove veneno, queimadura, fraqueza e congelamento. |
| Último fôlego | Ressuscita a criatura uma vez com 35% dos PV. |
| Postura defensiva | Aumenta DEF temporariamente e dá escudo. |
| Ímpeto | Permite um ataque adicional no turno. |
| Enfraquecer | Reduz ATQ rival por dois turnos. |
| Imitação | Copia o último efeito válido do rival. |
| Bola de fogo | Causa 35 de dano direto. |
| Kit de reparo | Recupera 30 PV. |
| Lâmina | Concede +25 ATQ à criatura ativa. |
| Armadura | Concede +30 DEF e +20 PV à criatura ativa. |
| Armadilha de espinhos | Causa 30 de dano quando você é atacado. |
| Armadilha refletora | Reflete 40 pontos do ataque seguinte. |
| Inspiração de equipe | Concede +15 ATQ e +15 DEF à criatura ativa. |
| Caos fotográfico | Sorteia um efeito de jogo entre cura, dano, escudo, veneno ou fúria. |

Algumas habilidades são passivas e não precisam de ativação manual. Efeitos de cartas de ação podem ter condições, como exigir uma criatura no campo ou uma armadilha livre.

## 10. Modos de jogo

- **Clássico:** duelo contra CPU com dificuldade Aprendiz, Duelista ou Mestre.
- **Zoeira:** desafios de expressão/pose, foto pela câmera frontal ou galeria, medidor de caos ajustável e cartas de zoeira.
- **Duas pessoas — um aparelho:** cada pessoa usa seu turno e a tela de passagem esconde a mão antes de entregar o celular. Não dá recompensas de perfil.
- **Campanha/Chefes:** cinco capítulos e cinco guardiões com vida, elemento e habilidade próprios; vencer libera o próximo capítulo.
- **Sobrevivência:** enfrente ondas sucessivas, com vida carregada para a onda seguinte.
- **Draft:** cria um conjunto temporário de 24 cartas geradas para aquela partida.
- **Relâmpago:** duelo acelerado com 65 PV e limite menor de turnos.
- **Laboratório:** campo de treino para testar cartas, efeitos e combinações.
- **Torneio:** chave local em duas partidas para disputar o título e recompensas.
- **Multiplayer online:** salas por código, sincronizadas via Firebase Realtime Database. Requer configuração no próprio aparelho e no segundo aparelho.

## 11. Coleção, decks e progressão

- Coleção com busca, filtro por tipo, detalhes e exclusão.
- Editor de decks de 24 cartas, limite de três cópias e possibilidade de manter vários decks.
- Forja: evolua cartas até cinco melhorias, gastando moedas e fragmentos; cada melhoria aumenta ATQ, DEF e PV.
- Progressão com XP, níveis, rank, moedas e fragmentos.
- Loja interna com pacotes virtuais; não há compra com dinheiro real.
- Missões diárias e conquistas com recompensas.
- Campanha com desbloqueio progressivo de capítulos.
- Exportação/importação de backup JSON.
- Efeitos sonoros sintetizados no aparelho, com controle de som no Perfil.

O jogo limita a coleção a 80 cartas nesta versão. Fotos são comprimidas, mas coleções muito grandes podem alcançar a cota de armazenamento do WebView. Mantenha armazenamento DOM ativo e faça backups periódicos.

## 12. Multiplayer e IA opcionais

### Firebase

O modo online requer projeto Firebase, login anônimo habilitado e Realtime Database. O passo a passo está em `firebase/README.md`; as regras propostas estão em `firebase/database.rules.json`. A mão e o monte são armazenados em caminhos privados por participante. A versão é um protótipo online e ainda não tem validação anti-trapaça autoritativa no servidor.

### OpenRouter

A chave é guardada no aparelho. A análise por IA só ocorre quando existe chave e a caixa de consentimento de envio da imagem está marcada. Modelos gratuitos podem mudar, impor limites ou deixar de oferecer visão.

## 13. Estrutura principal do projeto

- `index.html`: entrada para conversores HTML→APK.
- `src/main.js`: ponto de entrada exigido por geradores e Vite.
- `www/index.html`: página local para Capacitor/WebView direto.
- `www/css/style.css`: tema-fonte; as páginas também embutem o tema para compatibilidade.
- `www/js/boot.js`: inicialização protegida e diagnóstico.
- `www/js/main.js`: interface, navegação, perfil, coleção, fotos e modos.
- `www/js/photo-analysis.js`: análise determinística de pixels.
- `www/js/engine.js`: regras, turnos, combate, CPU, habilidades e campanha.
- `www/js/data.js`: cartas iniciais, dados locais, coleções e progresso.
- `www/js/firebase.js`: salas e sincronização online.
- `www/js/sfx.js`: efeitos sonoros.
- `firebase/`: documentação e regras do multiplayer.
- `tests/`: testes de estrutura, fumaça e regressão.

## 14. Testes executados nesta edição

Execute com `npm test`. A suíte verifica:

- Sintaxe dos principais módulos JavaScript.
- Presença dos 22 arquivos necessários e caminhos de entrada.
- CSS incorporado nas duas páginas e ausência de importação obrigatória de fontes externas.
- Os cinco seletores de foto como inputs nativos dentro de labels clicáveis.
- Correspondência dos IDs HTML usados pela interface.
- Deck inicial de 24 cartas, limite de cópias, regras de combate, dano, escudo, reflexão, armadilhas, golpe duplo, estados, renascimento, passagem local e inicialização dos modos.
- Análise de pixels determinística, limites dos atributos e resultados diferentes para imagens sintéticas diferentes.

Além da suíte automatizada, a folha CSS foi analisada com parser independente (282 regras, zero erros) e a página inicial foi renderizada em uma prévia estática, confirmando o tema escuro, cartões, botões, grade e navegação. Os caminhos locais das duas páginas e os arquivos JSON foram validados.

**Limite desta validação:** não foi possível executar `npm install` / `vite build` nem gerar um APK real neste ambiente porque a conexão com o registro npm falhou por DNS (`EAI_AGAIN`). Também não há Android SDK/Gradle instalado aqui. Portanto, os testes confirmam o motor, os scripts, os arquivos e a renderização estática; ainda não confirmam uma instalação/execução no seu conversor ou no APK final. A câmera/galeria dentro de um conversor de terceiros depende de ele implementar o seletor nativo de arquivos do WebView (`onShowFileChooser`).
