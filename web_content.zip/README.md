# Meu Orçamento

Aplicativo financeiro pessoal para Android/PWA.

Este pacote está estruturado com `index.html` na raiz para facilitar o uso em geradores de APK/PWA pelo navegador do celular.
