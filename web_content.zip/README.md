# Fluid & Smoke Simulation (improved)

An interactive 2-D lattice-Boltzmann wind-tunnel: place obstacles, blow wind from
any direction, and watch the flow, vortices and aerodynamic forces develop in
real time. The new **realistic fluid smoke** fills the sky with a continuous
smoke density field that advects, curls into spiral vortices and wraps around
your obstacles — just like the classic fluid-simulation clips. Smoke is now
**accumulative**: clouds that reach a barrier pool up against its surface,
coat it and spill around the edges instead of vanishing on contact. A lighter
**puff-particle** style is still available. **Every smoke spawner has its own
colour** — place an Ember plume next to a Sky plume and watch them swirl and
mix. A dedicated **landscape fullscreen** mode letterboxes the simulation
between two slim control bars so the important buttons stay on screen.
Barriers are now **editable objects**: tap any shape with the Select tool to
grab it, then drag it around, stretch it with its corner handles, duplicate,
flip or delete it. The sky can also carry any number of **fans** — wind
generators that each turn the wind inside their own height-band to their own
direction, on top of (or instead of) the single global wind. A fan set
to 180° turns *all* the wind inside its own height-band to 180°, while the
rest of the sky keeps its own direction — and every fan can be **resized**
to command more or less sky, and faded with the **transparency** slider.
Fans also come in **presets**: a sky-wide Jet,
a cone Blast, a hurricane-style Tornado with a spinning spiral, a roaming
Twister, a smoke-eating Vacuum and gusty Chaos. Barriers can also come
**alive**: the Barrier-physics card turns any shape into a rigid body that
**falls to the ground under gravity** (stacking on the floor and on other
barriers, never pushed by the wind) or one that **spins while suspended in
mid-air**, stirring the wind and smoke around it as it turns. And because
sliders are fiddly for precise numbers, **every slider now has a number box**
 beside it — type an exact value and press Enter. The interface is deliberately flat and
clean — solid panels and buttons, no frosted-glass effects, no button
outlines. Works with mouse, touch and pen. No build step, no dependencies —
open `fluid-sim/index.html` in any modern browser.

## Files

| File | Purpose |
|------|---------|
| `fluid-sim/index.html` | App UI, simulation engine (lattice-Boltzmann), drawing tools, realistic + puff smoke, physics barriers |
| `fluid-sim/js/barrierdata.js` | Library of 39 preset shapes (5 groups) |
| `fluid-improved-physics-barriers.zip` | Both files packaged for download |

## Highlights

- **Select, move & resize barriers** — pick the *Select / move* tool and tap
  any barrier: its whole connected shape is selected (bounding box + corner
  handles). Drag inside the box to move the shape anywhere (also while the
  wind is running), drag a corner handle to stretch or shrink it, or use the
  selection buttons: *Delete sel*, *Duplicate sel*, *Flip sel ↔ / ↕* (great
  for re-aiming a car after the wind turns) and *Deselect*. Arrow keys nudge
  the selection (Shift = 5 cells), Delete removes it, Esc deselects. Every
  move/resize is undoable (Z). The Select tool is also in the fullscreen HUD.
- **Realistic fluid smoke (default)** — a high-resolution smoke density field
  is advected through the fluid velocity field with semi-Lagrangian tracing,
  so it splits around barriers, rolls up into the Kármán vortex street and
  fills the wake with soft swirling filaments — never a single round puff.
  - **Every spawner has its own colour** — pick a swatch, tap the canvas, pick
    another swatch, tap again: each spawner keeps emitting in its own colour,
    advected in a separate density channel and composited additively, so
    plumes curl around each other and blend where they overlap (Ember + Sky
    makes a lovely sunset). Tap a placed spawner with the spawner tool to
    cycle its colour, *Recolour all* re-tints every spawner at once, and a
    compact copy of the swatches lives in the fullscreen HUD. The velocity
    field is sampled once per frame for all colours, so extra plumes cost
    very little extra time.
  - **Accumulates against barriers** — solid-aware sampling means smoke that
    hits a wall *piles up*: it pools at the stagnation face, visibly coats the
    barrier surface and slides around the edges, exactly like real smoke in
    an enclosed space. Puff particles deflect and bank up against walls too —
    no more puffs disappearing on contact. Each colour coats the walls in its
    own tint.
  - **Swirl** (vorticity confinement) tightens the spiral curls; **Softness**
    blurs them into a dreamy haze; **Fade** controls how long smoke lingers;
    **Buoyancy** makes it rise like fire smoke even with no wind.
  - **Cinematic colour ramps** — every colour renders as a ramp on the solid
    black backdrop: White/Smoke-grey like classic wind-tunnel footage, Ember
    for fire plumes (black → deep red → orange → white-hot core), plus lime,
    sky and pink.
  - **Emission** and **Smoke size** control how much smoke each spawner
    releases and how wide the source is, *Clear smoke* empties the sky.
  - The smoke layer only *reads* the fluid solver, so the physics, barriers,
    wind direction and stability are exactly as before.
- **Puff-particle style** — the original round puffs are still there: switch
  the Smoke card to *Puff particles* for rate/lifetime/turbulence controls.
  Puffs inherit their spawner's colour, so several coloured plumes can rise
  and drift side by side.
- **Wind direction control** — slider (5° steps) plus four quick buttons
  (→ ↑ ← ↓). A small on-canvas compass arrow always shows where the wind is
  blowing. Keyboard: ← and → rotate the wind by 15°.
- **Fans — resizable wind generators with presets** — the global wind slider
  sets one boundary wind; fans let you add any number of *local* winds. Pick
  the *Place fan* tool and tap the canvas: each fan is a wind generator that
  turns **all the wind inside its own band** — the strip of sky as tall
  (wide) as the fan, running the whole length of the sky along its aim —
  toward its own direction, while air outside the band keeps whatever wind
  it had. Set a fan to 180° and every bit of wind in its height goes to
  180°; move it, resize it or re-aim it and the band follows. The band
  edges fade out smoothly, so fans **interact with other wind directions**:
  where two bands meet (or a band crosses the global wind) the solver
  blends them into shear layers, jets and vortices instead of a hard
  seam. Build cross-winds, stacked counter-flowing jets, updrafts and
  swirling air fields the single global wind can't make.
  - **Six presets** — pick a chip in the Fans card (or the fullscreen HUD
    menu) before placing, or select a placed fan and click a chip to change
    it:
    - **Jet** (blue) — the classic sky-wide wind band described above.
    - **Blast** (amber) — a *finite cone* of wind spreading out from the
      fan along its aim; great for aiming a gust at one smoke plume.
    - **Tornado** (green) — a hurricane-style vortex: a calm **eye**, a
      tight **ring of fastest wind** hugging the eye and three trailing
      **spiral arms** that sweep around with the spin (three arms, seeded
      per fan, rotating slowly with the vortex). The strengthened inward
      feed drags smoke *into* the funnel along the arms, so plumes get
      wrapped into the classic spiral. The aim sets
      the spin (upper half = CCW ↺, lower half = CW ↻ — the Aim readout
      shows it), and **tapping the fan flips the spin**.
    - **Twister** (cyan) — the roaming tornado: it drifts along its aim
      arrow and bounces off the walls, stirring the whole sky.
    - **Vacuum** (violet) — sucks air and smoke inward from all around
      (harder from behind the aim), with a slight swirl and a mild exhaust
      out the front — a smoke-clearing drain.
    - **Chaos** (pink) — gusty, wandering turbulence: every cell inside the
      disc meanders around the aim with its own space-time wobble.
  All presets push the air through the same mass/momentum-conserving
  relaxation, so they all interact with each other, the global wind and
  barriers, and each preset paints its own region in its own tint (band,
  cone, spiral arms, intake arrows or gust arrows).
  Every fan keeps its own preset, aim and size: tap a placed fan with the
  fan tool to spin it 45° (a tornado flips its spin instead), drag its
  middle to move it, **drag its dashed rim to resize it** (the region
  follows), or delete it with the *Remove fan* tool (both tools also live
  in the fullscreen HUD). *Fan power* sets the wind strength, *Fan aim*
  (5° steps) and *Fan size* edit the selected fan — or set the defaults
  for the next fan you place — and the fullscreen HUD carries compact Aim
  & Size, Fade and preset controls while a fan tool is active; *Clear
  fans* removes every fan. The **Fan transparency** slider fades the fan
  overlays (regions, discs, blades, arrows) anywhere from fully solid to
  95% ghostly, so the wind and smoke beneath stay in view — fans remain
  clickable and editable either way, and the setting is saved with your
  layout. Fans are true momentum sources in the
  lattice-Boltzmann solver — they power the force arrow, bend tracers and
  flowlines, form shear layers and vortex streets around barriers, and
  blow both smoke styles around (smoke + an upward fan = a wind-blown fire
  plume). The selected fan glows.
  Fans (including their preset and size) are saved with layouts and
  survive grid-size changes; older layouts load as Jets.
- **Physics barriers — fall & spin** — the *Barrier physics* card gives every
  barrier a body:
  - **Falls to the ground** — pick *Falls* under *New shapes*, then draw with
    the brush, line or rectangle tool (or place a preset): each shape becomes
    a rigid body that **drops under gravity**, lands flush on the floor and
    **stacks** on other barriers and other bodies. Bodies block the wind and
    the smoke exactly like pinned barriers, but the fluid **never pushes
    them** — only gravity moves a falling shape (try dropping one through a
    cross-wind: it falls straight down). If you erase the support beneath a
    resting body it re-falls; *Gravity* (0–0.06) applies live to every
    falling body, and *Reset bodies* re-plays the drop from where each body
    was created.
  - **Spins in mid-air** — pick *Spins* and draw: the shape rotates in place
    while suspended, **stirring the air around it** — fluid next to the body
    is dragged around at the local surface speed of the spin, so spinners
    churn smoke, bend tracers and chew up plumes. *Spin speed* (−8…+8 ° per
    frame, sign = direction) applies live to every spinner.
  - **Converting** — *Drop sel* / *Spin sel* turn the current Select-tool
    selection into a falling / spinning body; *Freeze sel* pins the selected
    body where it is. Bodies get a subtle slate-blue tint; spinners show a
    small violet swirl and falling bodies an amber drop arrow while they
    move. Bodies can be selected, dragged, nudged, duplicated, flipped,
    resized (corner handles) and deleted like ordinary selections. Bodies
    are saved with layouts, survive grid-size changes and undo, and older
    layouts load with everything pinned, as before.
- **Type exact values** — every slider in every card (and the fullscreen
  HUD) now has a small **number box** beside it: type a precise value and
  press Enter (out-of-range entries clamp, and the value snaps onto the
  slider's step), while dragging the slider updates the box — including
  boxes driven programmatically, like the fan rim-resize. Typing in a box
  never triggers keyboard shortcuts.
- **39 presets in 5 groups** — Plates & lines, Bluff bodies, Composite,
  Vehicles (car, airplane, arrow… all nose-into-the-wind) and the new
  **Aerodynamic** group: teardrop, bullet, rocket, NACA airfoil, cambered
  wing, airfoil at 10° angle of attack, glider, paper dart, submarine, cone.
- **Placement rotation** — place any preset at 0° / 90° / 180° / 270°, e.g. to
  align it with a vertical wind.
- **Flip whole drawing** — mirror the current layout left-right or up-down to
  re-aim it after changing the wind.
- **Landscape fullscreen** — the ⛶ button in the canvas corner (or the
  *Fullscreen* button in the App card, or the **F** key) blows the simulation
  up to the whole screen: the canvas is letterboxed at its true 5:2 aspect
  between two slim HUD bars holding the essentials — Start/Pause, Step,
  Reset, Exit on top; tool menu, brush size, Smoke toggle, wind arrows,
  flow-speed slider and Clear smoke below. On phones the browser is asked to
  lock the orientation to landscape (a gentle hint appears if you enter in
  portrait), and every HUD control stays in two-way sync with the main
  panels. Leaving fullscreen (✕ Exit, the F key or the system back/ESC
  gesture) restores the normal page exactly as it was.
- **Flat, clean interface** — solid panel and button colours in both themes,
  no glassmorphism (no backdrop blur or translucent panels), and no borders
  or focus outlines on buttons; hover/press states are plain colour changes.
- **Mobile-first drawing** — unified pointer/touch input with stroke
  interpolation, brush sizes, mirror mode, straight-line and rectangle tools
  with dashed preview, 12-step undo.
- **Display** — density / x-velocity / y-velocity / speed / curl plots with
  contrast control, tracer particles (auto-respawn on the upstream edge for
  any wind direction), flowlines, force vector, movable sensor, PNG
  screenshot export, dark theme, save/load layout (localStorage — spawners
  are saved and restored too, even across grid-size changes).
- **Robust** — if the fluid ever exceeds the lattice stability range (abrupt
  wind turns, low viscosity, high speed), it resets itself quietly and shows a
  short toast instead of a modal alert.

## Keyboard shortcuts

| Key | Action |
|-----|--------|
| Space | run / pause |
| S | single step |
| R | reset fluid |
| C | clear barriers |
| Z | undo |
| M | toggle mirror |
| F | enter / leave fullscreen |
| Esc | deselect the selected barrier |
| Del / Backspace | delete the selected barrier |
| ↑ / ↓ | flow speed (nudges the selection when one is active; Shift = 5 cells) |
| ← / → | wind direction (nudges the selection when one is active) |

## Tips

- Place the **Car**, switch to *Select / move*, tap it and drag it through the
  wind — the force arrow reacts live. *Flip sel ↔* turns it into a
  backwards-facing (high-drag) experiment in one click.
- Recreate the classic vortex-street clip: tick **Smoke**, place the
  **Small circle**, put one wide spawner upstream (*Smoke size* ≈ 26) and
  watch the wake shed soft white spirals.
- Rainbow wake: tick **Smoke**, set the wind to →, then place four spawners
  in a vertical line — Ember, Lime, Sky and Pink (tap a swatch between each
  tap on the canvas). Where the plumes intertwine behind a barrier they mix
  into new tints.
- Fire smoke: set flow speed to 0, pick the **Ember** swatch, raise
  **Buoyancy** to ~0.05 and drop a spawner low on the canvas — a plume rises
  and mushrooms just like the reference footage. Add a **Sky**-coloured
  spawner beside it for a cold-smoke contrast plume.
- Compare drag: place the **Cone**, then the **Square** — same wind, very
  different wakes.
- Turn on **Tracers** and sweep the wind slider slowly to watch the whole flow
  field rotate.
- Place the **Cambered wing** on speed plot and watch the fast low-pressure
  region on top of the wing.
- Gust duel: set the flow speed to **0**, place one fan blowing → on the
  left half and one fan blowing ← on the right half, slightly offset
  vertically — the two wind bands collide along their whole height and
  shear into vortices. Drop a **Small circle** between them and tick Smoke
  with a spawner in one band to see the churn.
- Wind shear layer: set flow speed to 0, place a wide fan blowing → across
  the top half of the sky and another blowing ← across the bottom half —
  watch the two heights roll up against each other along their whole
  shared edge, then tick Tracers to see the Kelvin–Helmholtz curl.
- Turn the wind on with the global slider (→), then drop a fan set to 180°
  in the middle: only the strip of sky inside the fan's height reverses,
  while the air above and below keeps blowing → — resize the fan's rim to
  widen or narrow the reversed channel.
- Wind-tunnel-free lift: aim a fan straight up beneath the **Cambered wing**
  and watch the force arrow react to the artificial updraft.
- Tornado alley: set flow speed to 0, tick Smoke and drop a spawner, then
  add a **Tornado** fan next to it — the plume gets eaten and wraps into
  the three-armed spiral around the calm eye; drag the rim to make the
  storm fill the sky, tap the fan to reverse the spin, or switch it to a
  **Twister** and let it wander around the sky dragging the smoke with
  it. Pull **Fan transparency** up to ~70% so you can watch the wind
  inside the funnel through the overlay.
- Smoke scrubber: place a **Vacuum** fan in a clouded sky and watch the
  haze spiral into the drain; aim it away from your plume so the intake
  pulls from the dirty side.
- Demolition day: build a tower of *Falls* rectangles, then aim a **Blast**
  fan at it and erase a support — bodies drop, stack and topple while the
  wind keeps blowing around them (they never get blown away).
- Spin-stirrer: set flow speed to 0, tick **Smoke** with an Ember spawner,
  then drop a *Spins* blob in the middle of the plume — it shreds the smoke
  into spiral arms; make the spin speed negative to reverse the churn.
- Prefer the old round puffs? Switch the Smoke card to *Puff particles* —
  everything else keeps working the same.
