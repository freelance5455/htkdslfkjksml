# MEMORIX 2050 · v4

Offline-first "turn mistakes into memory" app for NEET prep. Pure HTML/CSS/JS — no build step, no network, no accounts.
Keep `index.html` at the ZIP root for HTML-to-APK converters (the other files are optional PWA extras).

## What's new in v4 (vs. the original build)
**Real spaced repetition** – SM-2-style scheduler with Again/Hard/Good/Easy, per-card ease, lapses, due dates, interval previews on each button, in-session re-queue of failed cards.
**Confidence-before-reveal** – plus a calibration chart (confidence vs. actual recall), over/under-confidence coaching.
**Error-type tracking** – concept gap, silly slip, calculation, misread, time pressure, NCERT line, etc. → "Why you lose marks" donut.
**Capture upgrades** – quick form + optional details, NEET chapter suggestions, camera/gallery photo of the question (auto-compressed), "save & add another".
**Insights** – weakest chapters with one-tap drills, butterfly-effect tags, retention, forecast (next 7 days), 17-week heatmap, 30-day velocity, 14 achievements, XP/levels, live Coach tips.
**Sessions** – due queue, review-ahead, chapter drill, cram, review-from-vault-filter; full keyboard control (1–4, Space, E).
**Focus mode** – 15/25/50 min + break, drift-proof timer, wake-lock, logged to XP.
**Data safety** – JSON backup (share sheet / download / copy), merge-or-replace import with validation, paste-import fallback, CSV export, undo-delete, backup reminders, persistent-storage request, localStorage fallback.
**Polish** – dark / AMOLED / light themes, exam countdown, daily goal ring, command palette (Ctrl/⌘K), hash routing (Android back button works), accessible dialogs & focus traps, pinch-zoom allowed, reduced motion, installable PWA (manifest + service worker).
**Migration** – data from the original build is upgraded automatically on first launch.

## Bugs fixed from the original
- Streak dropped to 0 until you reviewed *today*; now counts from yesterday and shows "at risk".
- `confirm()` and blob downloads fail silently in many APK WebViews → replaced with in-app dialogs and share-sheet/paste fallbacks.
- No due dates (queue was just a sort) → real scheduling.
- "Mastered" after 2 right answers → now means a 21-day+ interval.
- Edit form ignored the saved difficulty; import wasn't validated; subjects hard-coded; text as small as 9px; zoom disabled.

## Honest limits
No cloud sync, accounts or AI model — those need a real backend. Push-notification reminders also need one (or a native wrapper). Back up regularly: clearing app data deletes everything.
