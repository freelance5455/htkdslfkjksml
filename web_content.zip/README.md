# RAJ ELECTRICALS Business Manager

இது ஒரு mobile-friendly installable web-app prototype.

## Demo Login
- Admin / 1234
- Manager / 1234

## Included
- Admin / Manager login UI
- Orange / Ivory luxury theme
- Purchase entry
- Sales entry
- Credit & payment tracker
- Cash / UPI / Bank Transfer / Cheque
- Automatic outstanding calculation
- Basic stock calculation
- Admin orange dot / Manager blue dot
- Local device storage

## Run
1. Open `index.html` in a browser.
2. For phone installation, host the folder on HTTPS and use the browser's "Add to Home screen".

## Important
இந்த prototype தரவுகளை அந்த சாதனத்தின் browser local storage-ல் சேமிக்கிறது. Production பயன்பாட்டுக்கு secure cloud database, user authentication, backups, invoice/GST rules, audit log மற்றும் proper APK build சேர்க்க வேண்டும்.
