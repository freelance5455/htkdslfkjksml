# OPERATION SHADOW — Browser 3D FPS (playable prototype)

An original, modern military first-person shooter that runs in the browser on desktop and mobile. Built with **three.js (WebGL)**, **React 19**, **TypeScript**, **Tailwind CSS 4** and **Vite 7**. It's a single self-contained `dist/index.html`, and every texture, model and sound is generated procedurally at runtime.

## Why not Unreal Engine 5?
The request preferred UE5. The available environment is a Node/Vite web sandbox with **no Unreal Engine, no Android SDK/NDK and no GPU**, so a UE5 project could not be created, compiled or packaged here. I built the best *genuinely playable* alternative instead: a real-time 3D WebGL game. **No APK or EXE was produced.** The steps to make one are below.

## Run it
```bash
npm install
npm run dev        # development server
npm run build      # production build → dist/index.html (single file)
npx vite preview   # serve the production build
```
Tests (headless, Node):
```bash
node tests/run.mjs    # maps, physics, raycasts, nav/A*, AI perception, weapons, save system
node tests/ui.mjs     # renders every UI screen (React SSR smoke test)
node tests/game.mjs   # end-to-end simulation of the real Game class in all 4 modes (renderer faked)
```

## Game modes (all playable offline)
| Mode | Status |
|---|---|
| **Offline Combat** | 5 escalating waves of AI, health regen, one life, victory/defeat |
| **Battle Royale** | Parachute drop, sidearm start, weapon/ammo/armor/medkit loot with rarity, supply crates, optional shrinking zone with escalating damage, 9–21 AI (scales with preset), placement, victory/defeat |
| **Team Deathmatch** | 4v4 to 6v6 (player + AI allies vs AI), respawns, score limit, 6-minute timer, winner screen |
| **Practice Range** | Static plates (10–120 m), moving targets, humanoid dummies (head hitboxes), hits/misses/accuracy/time, in-range armory with every unlocked weapon, reset & end session |
| **Online Multiplayer** | **Not available.** No server is deployed. The menu says so clearly instead of faking online play with bots |

## Weapons
There are **20 weapons in 7 categories** (AR ×5, SMG ×4, SR ×3, SG ×2, LMG ×2, MR ×2, Pistol ×2). Each has its own damage, head multiplier, RPM, magazine, reserve, reload, vertical/horizontal recoil, hip/ADS spread, range falloff, zoom, ADS time, mobility and fire mode (auto/semi/3-round burst/bolt). Each also has a distinct procedural model and a synthesized gunshot.

There are 16 attachments in 6 slots (optic, muzzle, barrel, underbarrel, magazine, stock) that change real stats, plus 9 cosmetic skins and 3 saved loadouts. Incompatible configurations are sanitized automatically.

## Controls
**PC:** WASD · Mouse look (pointer lock) · LMB fire · RMB aim · R reload · Space jump · Shift sprint · C crouch (slide while sprinting) · 1/2/Q/wheel switch weapon · E interact · H medkit · V armor plate · F inspect · B range armory · Esc pause. All keys can be rebound.

**Touch (landscape):** dynamic left joystick (push fully up to sprint), right-side drag to look, plus FIRE (drag to aim while firing), AIM, JUMP, CROUCH, RELOAD, SPRINT toggle, SWAP, USE and PAUSE buttons, with HEAL/PLATE in BR. Multitouch works through per-pointer capture. Settings include button size, opacity, fire-button position and a left-handed layout. Browser gestures are suppressed (`touch-action:none`, no overscroll, fullscreen and landscape lock where supported).

## File map
```
src/App.tsx                 screen router (menus ↔ game, instant restart by remount)
src/game/Game.ts            core: renderer/settings, player controller, weapons, viewmodel, hit detection,
                            modes (combat/BR/TDM/range), loot, zone, effects, canvas HUD, match flow
src/game/ai.ts              enemy AI state machine (patrol/investigate/engage/search/cover/retreat)
src/game/world.ts           AABB colliders + spatial hash, DDA raycast, terrain, character movement, nav grid + A*
src/game/maps.ts            Iron District, Dust Frontier, Shadow Range builders (merged geometry per chunk)
src/game/models.ts          procedural weapon models (attachments visible) and animated soldiers
src/game/effects.ts         pooled GPU particles, tracers, instanced bullet decals, muzzle flash
src/game/audio.ts           procedural Web Audio engine (buses, spatial panner, voice limit, music, ambience)
src/game/input.ts           keyboard/mouse (rebindable) + shared touch state
src/game/save.ts            settings/profile persistence with validation + checksum, progression, high scores
src/game/textures.ts        procedural canvas textures (quality-scaled)
src/game/data/weapons.ts    20 weapons, attachments, skins, stat computation
src/game/data/content.ts    operators, missions, modes, maps, difficulty, XP curve
src/ui/*                    Splash, MainMenu, MenuScene (3D operator), ModeSelect, Loadout/Armory, Settings,
                            Screens (Multiplayer/Operators/Missions/Progression/Credits), GameView, HUD, TouchControls
tests/*                     headless test suites (see TEST_REPORT.md)
```

## Known limitations
- This is a **WebGL prototype**, not a UE5 production game. Visuals are stylized low-poly with procedural textures, and characters are box-built with procedural animation.
- Real-device FPS hasn't been measured: no Android phone or GPU was available. Game-logic CPU cost measured headlessly is about 0.1 ms/frame with 21 AI. Rendering cost depends on the device, and the Low preset plus dynamic resolution exist for weak phones.
- No WebGL pixel output was verified, because no browser exists in the sandbox. All logic was verified headlessly.
- AI navigates on a ground-level grid. AI does not climb stairs to rooftops, although it can see and shoot players there.
- The **Exit** button is disabled in the browser, because pages can't close themselves. It would work in a native wrapper.
- The pointer-lock fallback (drag-free look without lock) is used only if the browser refuses pointer lock.
- Persistence uses `localStorage` with an integrity checksum. That detects corruption, not deliberate cheating, and all progress is **local only**.

## Producing an Android APK (not done here — needs Android SDK + JDK 17)
Wrap the web build with Capacitor:
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "Operation Shadow" com.operationshadow.game --web-dir=dist
npm run build
npx cap add android
# android/app/src/main/AndroidManifest.xml → on <activity>: android:screenOrientation="sensorLandscape"
#   android:configChanges already includes orientation|screenSize; add android:hardwareAccelerated="true"
npx cap sync android
cd android && ./gradlew assembleDebug        # → android/app/build/outputs/apk/debug/app-debug.apk
adb install app/build/outputs/apk/debug/app-debug.apk
```
For a release, create a keystore (`keytool -genkey -v -keystore shadow.jks -alias shadow -keyalg RSA -keysize 2048 -validity 10000`), configure `signingConfigs` in `android/app/build.gradle`, then run `./gradlew assembleRelease` (APK) or `./gradlew bundleRelease`. **Google Play requires the AAB from `bundleRelease`.** Set the app icon in `android/app/src/main/res/mipmap-*` (or use `@capacitor/assets`). Requirements: Android Studio, SDK Platform 34+, Build-Tools, JDK 17.

**Windows:** run in any modern browser, or wrap with Electron/Tauri for an `.exe`. The Exit button could then call the app shell.

## What online multiplayer would require
1. An authoritative server running the simulation tick. `World` (collision, raycast, nav) is renderer-independent and already runs in Node, as the tests show.
2. A WebSocket transport (e.g. Colyseus or uWebSockets) with client prediction and reconciliation, entity interpolation, and lag-compensated hitscan validation.
3. Server-side validation of fire rate, ammunition, damage and eliminations. The client's `shoot → trace → damage → onKill` chain is the single place to replace with server requests.
4. Lobby and matchmaking, accounts, server-verified progression (kept separate from current local progress), reconnection tokens, anti-cheat and hosting.

## Prototype vs production
This is a **complete, playable prototype**: all menus, modes, weapons, AI, loot, progression, settings and controls work and are tested headlessly. A production release would still need professional art and animation, real-device performance tuning, accessibility review, native packaging, and online infrastructure.
