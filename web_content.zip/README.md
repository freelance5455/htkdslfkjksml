# ADNAN ZERO X ACADEMY — Beginner Edition v2

Developer: عدنان زيرو إكس — ADNAN ZERO X
Package ID: `com.adnanzero.xacademy`

Import this ZIP directly into HTML to APK Builder - ZIP APK. `index.html` is at the archive root. If asked, set it as the start page. Enable JavaScript and DOM Storage. Lesson data is bundled for offline WebView use.

Includes 20 Termux/Linux lessons, 20 Python lessons, 40 tools with beginner tips, and 55+ Arabic command references with examples and safety notes. Lessons are designed for students with no prior background. Network tools are for owned systems or explicit authorized labs only.

© جميع الحقوق محفوظة للمطور عدنان زيرو إكس — ADNAN ZERO X.
