# English Tenses Quest — Android project (no Python/Kivy)

This version keeps the original 6 tenses and their 30 levels/120 questions, with a pink mobile layout, English/Arabic interface toggle, local saved progress, star scoring, and level/tense unlocking. It uses a small native Android WebView shell around bundled HTML/CSS/JavaScript. It needs no network connection at runtime and does not use Python, Kivy, SDL2, or any remote web service.

## Build an APK without GitHub

### Option 1 — Android Studio on a computer
1. Install Android Studio and its Android SDK (one-time setup).
2. Open this `EnglishTensesQuestAndroid` folder as a project.
3. Let Gradle sync and install the Android SDK platform requested by the project if prompted.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK will be under `app/build/outputs/apk/debug/app-debug.apk`.

### Option 2 — AndroidIDE on the Android phone
1. Install AndroidIDE from its official distribution and complete its Android SDK/build-tools setup.
2. Copy this entire project folder to the phone.
3. Open/import the project folder in AndroidIDE and let Gradle sync.
4. Build the debug APK from the IDE's build menu.

Both build options still require Android build tools. The project itself is small; no GitHub Actions or Python package compilation is involved. This source package is not itself an APK.

## Quick preview
Open `app/src/main/assets/index.html` in a modern browser. Some browsers restrict local storage on `file://` pages; the Android app uses WebView local storage to remember progress.

## Technical notes
- Package ID: `org.learning.englishtensesquest`
- Minimum Android: Android 7.0 (API 24)
- Runtime permissions: none
- Network permission: none
