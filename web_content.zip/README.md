# SONORA -> APK (Capacitor)

Kerak: Node.js 18+, Android Studio (JDK 17 bilan keladi).

1) Terminalda papka ichida:
   npm install
   npx cap add android
   npx cap sync android

2) Android Studio'da oching:
   npx cap open android

3) APK olish:
   Build > Build Bundle(s) / APK(s) > Build APK(s)
   Fayl: android/app/build/outputs/apk/debug/app-debug.apk

Eslatma: ilova index.html ichida (www/index.html). O'zgartirsangiz,
`npx cap sync android` ni qayta ishga tushiring.
