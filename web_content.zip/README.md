# مطبخي – وصفاتي (PWA يعمل دون إنترنت)

## التشغيل
الـ Service Worker يتطلب HTTPS أو localhost:
`cd matbakhi && python3 -m http.server 8080` ثم افتحي http://localhost:8080
على الهاتف: ارفعي المجلد على استضافة HTTPS مجانية (GitHub Pages / Netlify)، افتحيه في Chrome ← ⋮ ← «تثبيت التطبيق». بعد أول فتح يعمل دون إنترنت.

## التحويل إلى APK (Capacitor)
```
npm init -y && npm i @capacitor/core @capacitor/cli @capacitor/android
npx cap init "مطبخي" com.matbakhi.app --web-dir=www
mkdir www && cp index.html manifest.webmanifest sw.js icon-*.png www/
npx cap add android && npx cap sync
npx cap open android   # Build > Build APK(s) في Android Studio
```
ملاحظة: زر تصدير النسخة الاحتياطية يعمل في المتصفح؛ داخل APK أضيفي إضافة @capacitor/filesystem و@capacitor/share لحفظ الملف.
