# Mi App

Proyecto Android generado desde AppStudio.

## Requisitos
- Node.js 18+ → https://nodejs.org
- Android Studio → https://developer.android.com/studio
- Java 17 (incluido en Android Studio)

## Compilar el APK (con PC)

```bash
npm install
npx cap add android
npx cap sync
npx cap open android
```

En Android Studio:
**Build → Build Bundle(s)/APK(s) → Build APK(s)**

El APK queda en:
`android/app/build/outputs/apk/debug/app-debug.apk`

## Compilar sin instalar nada (GitHub Actions)

1. Subí esta carpeta a un repositorio en GitHub.
2. El workflow `.github/workflows/build.yml` ya está incluido.
3. Andá a la pestaña **Actions** → **Build APK** → **Run workflow**.
4. Cuando termine, descargá el artefacto **app-debug** con el APK.

## Cambiar nombre o icono
- Nombre: en `capacitor.config.json` → `appName`
- appId: en `capacitor.config.json` → `appId` (único, ej: com.tunombre.mi-app)

## Estructura
```
mi-app/
├── package.json
├── capacitor.config.json
├── www/
│   └── index.html
├── .github/
│   └── workflows/
│       └── build.yml
└── README.md
```

Generado el 3/11/2026, 7:53:51 p.m..
