# 🕊️ Cœur Régulé — Application Thérapeutique d'Accompagnement & Co-Régulation

**Cœur Régulé** est une application web moderne, chaleureuse et conçue pour la stabilisation émotionnelle des adultes (angoisses, traumatismes, phobies, dissociation) et la co-régulation parent-enfant (crises émotionnelles, colères, opposition, stress parental).

---

## ⚠️ Avertissement Légal & Déontologique

> **Cette application est un outil d'accompagnement psycho-éducatif et ne remplace en aucun cas un suivi médical ou psychologique professionnel.**
>
> En cas de détresse importante ou de pensées suicidaires, contactez immédiatement :
> - **France** : **3114** (Numéro national de prévention du suicide, gratuit, 24h/24) ou le **15** (SAMU)
> - **Europe** : **112** (Numéro d'urgence européen)
> - **USA & Canada** : **988** (Suicide & Crisis Lifeline)
> - **Belgique** : **0800 32 123** | **Suisse** : **147** ou **143**

---

## 🌟 Fonctionnalités Principales

### 1. Accès Rapide en cas d'Urgence Émotionnelle (6 Gros Boutons 1-Clic)
- 🚨 **Je me sens mal maintenant** : Déclenche immédiatement le Grounding 5-4-3-2-1
- ⚡ **Crise d'angoisse** : Protocole ultra-rapide 60s (soupir physiologique, désactivation de l'adrénaline)
- 🛡️ **Phobie activée** : Découplage sensoriel et double ancrage ici et maintenant
- 🌀 **Flashback / Dissociation** : Sortie de dissociation proprioceptive et orientation spatiale
- 🧸 **Mon enfant est en crise** : Protocole d'urgence de co-régulation relationnelle
- ☕ **J'ai besoin d'aide en tant que parent** : Reset du système nerveux parental en 90 secondes

### 2. Espace Adulte (10 Outils Complets)
Chaque outil propose **une version courte (express)**, **une version complète (approfondie)**, un décompte des pauses bienfaisantes, des ancrages corporels et une évaluation de l'intensité émotionnelle avant/après (0 à 10) :
1. **Grounding Sensoriel 5-4-3-2-1** (avec check-list interactive des 5 sens)
2. **Cohérence Cardiaque 5-5** (avec fleur/cercle de respiration animé et son de cloche 528Hz/396Hz)
3. **EFT / Tapping Somatique Centré sur le Cœur** (avec diagramme interactif des points du corps)
4. **Protocole Crise d'Angoisse** (urgence 60s, soupir physiologique, respiration 4-7-8, réassurance après-crise)
5. **Protocole Phobie** (recadrage visuel, désensibilisation douce, découplage)
6. **Auto-Hypnose du "Lieu Sûr" (Safe Place)** (sanctuaire intérieur multisensoriel, ancre digitale)
7. **Technique du Conteneur Sécurisé (IFS & Hypnose)** (coffre-fort mental pour pensées intrusives)
8. **L'Étreinte du Papillon (Butterfly Hug - EMDR)** (stimulation bilatérale alternée douce)
9. **Pause d'Auto-Compassion (Kristin Neff & CFT)** (Pleine conscience, Humanité partagée, Bienveillance)
10. **Protocole de Sortie de Dissociation Légère** (stimulation thermique, orientation, réveil proprioceptif)

### 3. Espace Parents & Co-Régulation (8 Outils Spécifiques)
1. **Protocole "Mon enfant est en crise"** (la sécurité avant la raison, voix de basse fréquence)
2. **Techniques de désescalade émotionnelle pour enfants** (La Bulle de Savon, Le Volcan Intérieur, Le Miroir)
3. **EFT / Tapping adapté aux enfants + version parent** (les 7 points magiques du petit singe)
4. **Grounding adapté aux enfants** (Le jeu du détective 5 sens, L'Arbre géant, Le Souffleur de nuages)
5. **Script de retour au calme après une crise** (réparation du lien sans honte, câlin d'ancrage)
6. **Gestion du stress parental (Reset en 90 secondes)** (désamorcer avant d'exploser)
7. **Script de reconnexion émotionnelle parent-enfant** (l'art de l'excuse modélisante sans démission)
8. **Guide des piliers de la co-régulation** (Théorie Polyvagale de Stephen Porges vulgarisée)

### 4. Thérapeute Virtuel IA & Détection de Crise
- System prompt humaniste et centré sur le cœur intégré
- Détection instantanée de détresse sévère (mots-clés de crise) avec alerte visuelle et bouton d'appel direct vers le 3114
- Raccourcis directs dans le chat pour ouvrir n'importe quel exercice en un clic

### 5. Multilingue Universel (`react-i18next`)
- Sélecteur de langue accessible dès le bandeau et l'onboarding (Français 🇫🇷, Anglais 🇬🇧, Espagnol 🇪🇸, Allemand 🇩🇪, Italien 🇮🇹).

---

## 🗄️ Base de Données Supabase & Stockage Local

Le fichier SQL complet se trouve dans [`supabase/schema.sql`](./supabase/schema.sql) :
- `profiles` : Profils utilisateurs et préférence de langue
- `sessions` : Historique des exercices réalisés avec scores avant/après
- `emotional_logs` : Journal des émotions et intensités
- `parent_sessions` : Sessions spécifiques d'interventions parent-enfant
- `favorite_tools` : Outils mis en favoris par l'utilisateur

> **Note d'autonomie** : L'application intègre un mode hybride immédiat. Si les variables Supabase ne sont pas configurées, un stockage local (`localStorage`) sécurisé prend automatiquement le relais, rendant l'application 100% utilisable immédiatement.

Pour brancher votre propre projet Supabase :
Ajoutez dans vos variables d'environnement (`.env`) :
```env
VITE_SUPABASE_URL="https://votre-projet.supabase.co"
VITE_SUPABASE_ANON_KEY="votre-cle-anon"
```
Puis copiez le contenu de `supabase/schema.sql` dans le **SQL Editor** de votre tableau de bord Supabase.

---

## 🌍 Comment Ajouter d'Autres Langues

Pour ajouter une nouvelle langue (ex: Portugais `pt`) :

1. Créez un nouveau fichier de traduction dans `src/i18n/locales/pt.ts` en copiant la structure de `fr.ts` ou `en.ts`.
2. Ouvrez `src/i18n/index.ts` et importez le fichier :
```typescript
import { pt } from './locales/pt.ts';

export const supportedLanguages = [
  { code: 'fr', label: 'Français', flag: '🇫🇷' },
  { code: 'en', label: 'English', flag: '🇬🇧' },
  { code: 'es', label: 'Español', flag: '🇪🇸' },
  { code: 'de', label: 'Deutsch', flag: '🇩🇪' },
  { code: 'it', label: 'Italiano', flag: '🇮🇹' },
  { code: 'pt', label: 'Português', flag: '🇵🇹' }, // <- Ajout ici
];

i18n.use(initReactI18next).init({
  resources: {
    fr: { translation: fr },
    en: { translation: en },
    es: { translation: es },
    de: { translation: de },
    it: { translation: it },
    pt: { translation: pt }, // <- Ajout ici
  },
  // ...
});
```

---

## 🤖 Comment Brancher d'Autres APIs de Chat (OpenAI, Claude, DeepSeek, Grok)

Le point d'entrée du chat est dans `server.ts` sur la route `POST /api/chat`.
Par défaut, il utilise `@google/genai` avec le modèle `gemini-3.8-flash`.

### Option A : OpenAI (GPT-4o / GPT-4o-mini)
```typescript
import OpenAI from 'openai';
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const completion = await openai.chat.completions.create({
  model: 'gpt-4o-mini',
  messages: [
    { role: 'system', content: SYSTEM_PROMPT },
    { role: 'user', content: query },
  ],
});
const reply = completion.choices[0].message.content;
```

### Option B : Anthropic Claude (Claude 3.5 Sonnet / Haiku)
```typescript
import Anthropic from '@anthropic-ai/sdk';
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const message = await anthropic.messages.create({
  model: 'claude-3-5-haiku-latest',
  system: SYSTEM_PROMPT,
  max_tokens: 1024,
  messages: [{ role: 'user', content: query }],
});
const reply = message.content[0].text;
```

### Option C : DeepSeek ou Grok (xAI)
DeepSeek et Grok sont 100% compatibles avec le SDK OpenAI :
```typescript
import OpenAI from 'openai';

// Pour DeepSeek
const deepseek = new OpenAI({
  baseURL: 'https://api.deepseek.com',
  apiKey: process.env.DEEPSEEK_API_KEY,
});

// Pour Grok (xAI)
const grok = new OpenAI({
  baseURL: 'https://api.x.ai/v1',
  apiKey: process.env.XAI_API_KEY,
});
```

---

## 🚀 Déploiement

### Déploiement sur Google Cloud Run / Container Docker
L'application est configurée avec un serveur Express plein-stack (`server.ts`) :
```bash
# Compiler le frontend
npm run build

# Lancer le serveur de production
npm run start
```

### Déploiement sur Vercel / Netlify
Pour un déploiement Vercel serverless :
1. Déployez le build Vite en SPA statique.
2. Créez un dossier `api/chat.ts` reprenant la logique de la route Express.

---

## 🩺 Conception Éthique
- **Zéro diagnostic médical**
- **Zéro promesse de guérison magique**
- **Priorité absolue à la stabilisation du système nerveux**
- **Sécurité et orientation vers les urgences (3114) dès le premier signal critique**
