# Nova AI — All-in-One AI Assistant

This ZIP is a frontend starter that implements the requested dark AI-style UI/UX and the 12 requested AI tools plus Memory & Library.

## What works after setup
- Mandatory Google login UI using Firebase Authentication (Google provider)
- AI Chat via Gemini Interactions API
- Study / Writing / Coding / Research / Translation / Agent-style prompts
- Local Library for uploaded files
- PDF analysis for smaller PDFs using Gemini generateContent
- Browser speech recognition where supported
- Browser text-to-speech
- Responsive Android-friendly dark UI
- Chat history stored locally in the browser

## Important
This is NOT a finished production APK and it is not safe to publish with a Gemini API key embedded in browser code.

### 1) Google login
Open `app.js` and replace the `firebaseConfig` placeholders with your Firebase Web App config.
In Firebase Console:
- Create/select a Firebase project
- Add a Web App
- Authentication → Sign-in method → enable Google
- Add your deployed domain to authorized domains

Firebase's current web documentation recommends the Firebase Auth Google provider flow, with redirect being preferred on mobile.

### 2) Gemini API key
Open the app Settings and paste your Gemini API key. It is stored in browser localStorage for this prototype.

For a real public app, DO NOT ship the API key in `app.js` or a browser bundle. Use a backend/server proxy and enforce per-user auth, quotas and abuse protection.

### 3) Serve it
Do not rely on opening `index.html` directly with `file://` for all features. Use a local/static web server or deploy it to a web host.

### 4) Image and Video
The UI includes Image and Video workflows, but generation is intentionally an adapter placeholder because model availability, request schema, quotas and billing can change. Connect those buttons to the current Google image/video API from a secure backend.

### 5) PDF
The included small-PDF path uses inline PDF data. Google documents a 50 MB / 1000 page PDF limit for Gemini document understanding; larger/multi-turn documents are better handled through the Files API.

## Files
- index.html — app shell and screens
- styles.css — responsive dark UI
- app.js — auth hooks, Gemini calls, tools, library and interactions


## Language behavior
The AI is instructed to answer in the same language as the user's latest message. Mixed-language messages use the dominant language unless the user explicitly asks for another language.

## Final setup checklist

1. Configure Firebase Web App values in `app.js`.
2. In Firebase Authentication, enable Google sign-in.
3. Add the deployed site domain to Firebase Authentication authorized domains.
4. Open Nova AI and sign in with Google.
5. Open Settings and paste your Gemini API key.
6. Test AI Chat first.
7. Then test Study, Writing, Coding, PDF, Research and Translation.
8. Image and Video screens are UI/workflow adapters; connect them to the current image/video generation endpoints from a secure backend before production.
9. For a public app, move the Gemini API key to a server-side proxy. Never hard-code a private key into a published APK/static website.

The same-language behavior is built into the system instructions: the assistant replies in the language used by the user's latest message.
