# KisuFire Expense Studio

Generated automatically by **KisuFire AI App Builder**.

## Features
- Real-time balance and expense tracking
- Hindi and English language toggle
- Browser LocalStorage persistent memory
- Mobile-first responsive UI

## Running the Project
Double-click `index.html` or run a local server (e.g. `npx serve .`).