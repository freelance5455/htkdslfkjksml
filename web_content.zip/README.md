# DroidStick Mouse (Android 7.0+)

Turn any Bluetooth Gamepad (Xbox, PlayStation, 8BitDo, generic HID) into a system-wide mouse on Android 7.0 Nougat (API 24) and above.

### Controls:
- **Left Stick**: Move mouse cursor with customizable acceleration and deadzone
- **Right Stick**: Smooth scroll vertical / horizontal
- **Button X / A**: Tap / Click / Long-press drag
- **Button B / Circle**: Back navigation
- **Button Y / Triangle**: Home screen

### Why Android 7.0+?
Android 7.0 (API 24) introduced `AccessibilityService.dispatchGesture`, which allows accessibility services to inject touch taps, swipes, and pinches without root or developer commands!

### How to Build & Install:
1. Open this folder in Android Studio.
2. Connect your Android phone with USB Debugging enabled (or build APK via Build > Build Bundle(s) / APK(s) > Build APK(s)).
3. Install the APK to your phone.
4. Open the DroidStick app, tap **Enable Accessibility Service** -> Turn ON **DroidStick Gamepad Mouse**.
5. Tap **Allow Overlay Permission** -> Grant **Display over other apps**.
6. Pair your Bluetooth controller in Android Settings -> Bluetooth.
7. Move the Left Stick — your cursor will appear immediately across all apps!