(() => {
  "use strict";
  const STORAGE_KEY = "tahbaliya_transactions_v1";
  const TYPES = {
    income: { label: "قروش داخلة", cash: 1, in: 1, out: 0, receivable: 0, payable: 0 },
    expense: { label: "قروش طالعة", cash: -1, in: 0, out: 1, receivable: 0, payable: 0 },
    lend: { label: "دين لزول", cash: -1, in: 0, out: 1, receivable: 1, payable: 0 },
    borrow: { label: "دين عليك", cash: 1, in: 1, out: 0, receivable: 0, payable: 1 },
    collect: { label: "استلام سداد", cash: 1, in: 1, out: 0, receivable: -1, payable: 0 },
    repay: { label: "سداد دين عليك", cash: -1, in: 0, out: 1, receivable: 0, payable: -1 }
  };
  const $ = id => document.getElementById(id);
  const form = $("transactionForm");
  let transactions = loadTransactions();
  let toastTimer;

  function localDate() {
    const now = new Date();
    const offset = now.getTimezoneOffset();
    return new Date(now.getTime() - offset * 60000).toISOString().slice(0, 10);
  }
  $("date").value = localDate();

  function loadTransactions() {
    try {
      const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
      return Array.isArray(parsed) ? parsed.filter(validTransaction) : [];
    } catch (_) { return []; }
  }
  function validTransaction(t) {
    return t && typeof t.id === "string" && TYPES[t.type] &&
      typeof t.amount === "number" && Number.isFinite(t.amount) && t.amount > 0 &&
      typeof t.date === "string";
  }
  function saveAll() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(transactions));
      return true;
    } catch (_) {
      showToast("ما قدرنا نحفظ البيانات. صدّر نسخة احتياطية وافرغ مساحة في الجهاز.");
      return false;
    }
  }
  function money(n) {
    return new Intl.NumberFormat("ar", { maximumFractionDigits: 2 }).format(n || 0);
  }
  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, c => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[c]));
  }
  function showToast(message) {
    const toast = $("toast");
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2800);
  }
  function sums() {
    return transactions.reduce((s, t) => {
      const type = TYPES[t.type], a = t.amount;
      s.cash += a * type.cash;
      s.income += a * type.in;
      s.expense += a * type.out;
      s.receivable += a * type.receivable;
      s.payable += a * type.payable;
      return s;
    }, { cash: 0, income: 0, expense: 0, receivable: 0, payable: 0 });
  }
  function renderSummary() {
    const s = sums();
    $("cashBalance").textContent = money(s.cash);
    $("totalIn").textContent = money(s.income);
    $("totalOut").textContent = money(s.expense);
    $("owedToMe").textContent = money(s.receivable);
    $("iOwe").textContent = money(s.payable);
  }
  function renderTransactions() {
    const query = $("search").value.trim().toLocaleLowerCase();
    const filter = $("filterType").value;
    const shown = [...transactions]
      .sort((a,b) => b.date.localeCompare(a.date) || b.createdAt - a.createdAt)
      .filter(t => (filter === "all" || t.type === filter) &&
        [t.person, t.note, TYPES[t.type].label].join(" ").toLocaleLowerCase().includes(query));
    $("transactionCount").textContent = `${transactions.length} حركة`;
    $("emptyState").classList.toggle("hidden", shown.length !== 0);
    $("transactionsBody").innerHTML = shown.map(t => {
      const meta = TYPES[t.type];
      return `<tr>
        <td>${escapeHtml(t.date)}</td>
        <td><span class="type-pill type-${escapeHtml(t.type)}">${meta.label}</span></td>
        <td>${escapeHtml(t.person || "—")}</td>
        <td class="amount">${money(t.amount)}</td>
        <td>${escapeHtml(t.note || "—")}</td>
        <td><div class="row-actions">
          <button class="small-btn" type="button" data-edit="${escapeHtml(t.id)}">تعديل</button>
          <button class="small-btn delete-btn" type="button" data-delete="${escapeHtml(t.id)}">حذف</button>
        </div></td>
      </tr>`;
    }).join("");
  }
  function render() { renderSummary(); renderTransactions(); }
  function resetForm() {
    form.reset();
    $("editId").value = "";
    $("date").value = localDate();
    $("formTitle").textContent = "إضافة حركة جديدة";
    $("saveBtn").textContent = "حفظ الحركة";
    $("cancelEditBtn").classList.add("hidden");
  }
  form.addEventListener("submit", event => {
    event.preventDefault();
    const amount = Number($("amount").value);
    const type = $("type").value;
    const date = $("date").value;
    const person = $("person").value.trim();
    const note = $("note").value.trim();
    if (!TYPES[type] || !Number.isFinite(amount) || amount <= 0 || !date) {
      showToast("راجع نوع الحركة والمبلغ والتاريخ.");
      return;
    }
    if (["lend", "borrow", "collect", "repay"].includes(type) && !person) {
      showToast("اكتب اسم الشخص للحركات المتعلقة بالدين.");
      $("person").focus();
      return;
    }
    const editId = $("editId").value;
    if (editId) {
      const index = transactions.findIndex(t => t.id === editId);
      if (index < 0) { showToast("الحركة ما لقيناها."); resetForm(); return; }
      transactions[index] = { ...transactions[index], type, person, amount, date, note, updatedAt: Date.now() };
    } else {
      transactions.push({
        id: (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`),
        type, person, amount, date, note, createdAt: Date.now()
      });
    }
    if (!saveAll()) return;
    render();
    resetForm();
    showToast(editId ? "تم تعديل الحركة." : "تم حفظ الحركة.");
  });
  $("cancelEditBtn").addEventListener("click", resetForm);
  $("clearBtn").addEventListener("click", () => setTimeout(() => {
    $("editId").value = "";
    $("date").value = localDate();
    $("formTitle").textContent = "إضافة حركة جديدة";
    $("saveBtn").textContent = "حفظ الحركة";
    $("cancelEditBtn").classList.add("hidden");
  }, 0));
  $("transactionsBody").addEventListener("click", event => {
    const editButton = event.target.closest("[data-edit]");
    const deleteButton = event.target.closest("[data-delete]");
    if (editButton) {
      const t = transactions.find(x => x.id === editButton.dataset.edit);
      if (!t) return;
      $("editId").value = t.id;
      $("type").value = t.type;
      $("person").value = t.person || "";
      $("amount").value = t.amount;
      $("date").value = t.date;
      $("note").value = t.note || "";
      $("formTitle").textContent = "تعديل حركة";
      $("saveBtn").textContent = "حفظ التعديل";
      $("cancelEditBtn").classList.remove("hidden");
      $("entryPanel").scrollIntoView({ behavior: "smooth", block: "start" });
    }
    if (deleteButton) {
      const t = transactions.find(x => x.id === deleteButton.dataset.delete);
      if (!t) return;
      if (!confirm(`متأكد داير تحذف حركة ${TYPES[t.type].label} بمبلغ ${money(t.amount)}؟`)) return;
      transactions = transactions.filter(x => x.id !== t.id);
      if (saveAll()) { render(); showToast("تم حذف الحركة."); }
    }
  });
  $("search").addEventListener("input", renderTransactions);
  $("filterType").addEventListener("change", renderTransactions);

  $("exportBtn").addEventListener("click", () => {
    const payload = {
      app: "TahbaliyaApp", version: 1, exportedAt: new Date().toISOString(),
      transactions
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `tahbaliya-backup-${localDate()}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    $("backupStatus").textContent = "جهزنا ملف النسخة الاحتياطية. اتأكد إنو اتحفظ في جهازك.";
  });
  $("importFile").addEventListener("change", async event => {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      const incoming = Array.isArray(data) ? data : data.transactions;
      if (!Array.isArray(incoming) || !incoming.every(validTransaction)) {
        throw new Error("invalid");
      }
      if (!confirm(`النسخة فيها ${incoming.length} حركة. الاستيراد حيستبدل الحركات الحالية. داير تواصل؟`)) return;
      const seen = new Set();
      transactions = incoming.map(t => {
        let id = t.id;
        if (seen.has(id)) id = `${id}-${Math.random().toString(16).slice(2)}`;
        seen.add(id);
        return { id, type: t.type, amount: t.amount, date: t.date,
          person: String(t.person || ""), note: String(t.note || ""),
          createdAt: Number(t.createdAt) || Date.now() };
      });
      if (saveAll()) {
        render(); resetForm();
        $("backupStatus").textContent = `تم استيراد ${transactions.length} حركة.`;
        showToast("تم استرجاع النسخة الاحتياطية.");
      }
    } catch (_) {
      $("backupStatus").textContent = "الملف غير صالح أو ما تابع لنسخة احتياطية مدعومة.";
      showToast("ما قدرنا نستورد الملف. اختار نسخة JSON صحيحة.");
    } finally { event.target.value = ""; }
  });

  if ("serviceWorker" in navigator && location.protocol !== "file:") {
    window.addEventListener("load", () => navigator.serviceWorker.register("./service-worker.js").catch(() => {}));
  }
  render();
})();