from pathlib import Path
root=Path(__file__).resolve().parents[1]
admin=(root/'admin.php').read_text()
handler=(root/'app/admin.php').read_text()
credits=(root/'app/credits.php').read_text()
voice=(root/'app/voice.php').read_text()
magichour=(root/'app/magichour.php').read_text()
css=(root/'assets/theme-system.css').read_text()
header=(root/'app/platform_header.php').read_text()
index=(root/'index.php').read_text()
checks={
 'admin exposes editable prices for all six workspaces': all(x in admin for x in ['image_credit_price','video_credit_price','realtime_credit_price','lip_sync_credit_price','voice_credit_rate','agent_credits_per_usd']),
 'admin persists all workspace price settings': "save_workspace_credit_prices" in handler and "credit_price_realtime" in handler and "credit_price_lip_sync" in handler,
 'default image/video/realtime/lip-sync prices are present': all(x in credits for x in ["'image'=>20","'video'=>50","'realtime'=>10","'lip_sync'=>30"]),
 'voice and clone defaults are set': "voice_setting('credits_per_100_chars','1')" in (root/'api/voice/config.php').read_text() and "voice_setting('credits_per_voice_clone','100')" in (root/'api/voice/clone.php').read_text(),
 'lip-sync default matches admin default': "mh_setting('credit_price','30')" in magichour,
 'realtime uses provider-measured per-second billing': 'credits per provider-billed active second' in index and 'billed_seconds' in index,
 'theme stylesheet is loaded last in app shell': 'assets/theme-system.css?v=2.6.2' in header,
 'brand tokens are unified': all(x in css for x in ['#111318','#171A21','#FFFFFF','#A3FF12','#8B5CF6','#00D6C9','#3897FF']),
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
if not all(checks.values()): raise SystemExit(1)
