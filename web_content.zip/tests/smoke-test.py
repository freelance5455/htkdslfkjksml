"""
Browser test for the Bhagyalaxmi challan app.
Run:  pip install playwright && playwright install chromium && python tests/smoke-test.py
Opens index.html in headless Chromium (phone-sized and desktop) and checks the core flows.
It does NOT test the APK wrapper or real Android WebView; see APKFORGE-NOTES.md for that.
"""
import asyncio, json, pathlib, sys
from urllib.parse import unquote
from playwright.async_api import async_playwright

APP = (pathlib.Path(__file__).resolve().parent.parent / "index.html").as_uri()
results = []

def check(name, ok, detail=""):
    results.append((name, ok))
    print(("PASS " if ok else "FAIL ") + name + (f"  [{detail}]" if detail and not ok else ""))

async def fresh(browser, mobile=True):
    ctx = await browser.new_context(viewport={"width": 390, "height": 844} if mobile else {"width": 1200, "height": 900},
                                    has_touch=mobile, is_mobile=mobile)
    pg = await ctx.new_page()
    errors = []
    pg.on("pageerror", lambda e: errors.append(str(e)))
    await pg.goto(APP)
    return ctx, pg, errors

async def fill_challan(pg, recipient, vehicle="GJ 01 AB 1234", transport="Porter", items=(("Steel plate", "10", "", "1200"),)):
    await pg.fill("#recipient", recipient)
    await pg.fill("#vehicleNumber", vehicle)
    await pg.select_option("#transportName", transport)
    for i, (desc, nos, set_, amount) in enumerate(items):
        if i >= 1: await pg.click("#addItem")
        row = f"#itemInputs tr:nth-child({i+1})"
        await pg.fill(f"{row} [data-field=description]", desc)
        if nos: await pg.fill(f"{row} [data-field=nos]", nos)
        if set_: await pg.fill(f"{row} [data-field=set]", set_)
        if amount: await pg.fill(f"{row} [data-field=amount]", amount)

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(args=["--no-sandbox"])

        # 1-2. Create, save, appears in list
        ctx, pg, errs = await fresh(browser)
        await fill_challan(pg, "Acme Traders\nAhmedabad", items=(("Steel plate", "10", "", "1200"), ("Bolts", "", "2", "")))
        await pg.click("#saveChallan")
        check("1 save new challan", "Saved DC-0001" in await pg.inner_text("#saveStatus"))
        check("2 appears under Previous challans", "DC-0001" in await pg.inner_text("#historyList"))

        # 3. Tap restores all fields
        await pg.click("#newChallan")
        await pg.tap(".history-entry")
        await pg.wait_for_timeout(600)
        check("3 recipient restored", await pg.input_value("#recipient") == "Acme Traders\nAhmedabad")
        check("3 vehicle restored", await pg.input_value("#vehicleNumber") == "GJ 01 AB 1234")
        check("3 transport restored", await pg.input_value("#transportName") == "Porter")
        check("3 number restored", await pg.input_value("#challanNumber") == "DC-0001")
        check("3 item 1 restored", await pg.input_value('#itemInputs tr:nth-child(1) [data-field=description]') == "Steel plate"
              and await pg.input_value('#itemInputs tr:nth-child(1) [data-field=nos]') == "10"
              and await pg.input_value('#itemInputs tr:nth-child(1) [data-field=amount]') == "1200")
        check("3 item 2 restored (SET)", await pg.input_value('#itemInputs tr:nth-child(2) [data-field=set]') == "2")
        check("3 status says loaded", "Loaded DC-0001" in await pg.inner_text("#saveStatus"))

        # 4. Edit and save does not duplicate
        await pg.fill("#vehicleNumber", "GJ 99 ZZ 0001")
        await pg.click("#saveChallan")
        data = json.loads(await pg.evaluate("localStorage.getItem('bhagyalaxmi-delivery-challans-v1')"))
        check("4 edit updates, no duplicate", len(data) == 1 and data[0]["vehicle"] == "GJ 99 ZZ 0001", str(len(data)))

        # 4b. Duplicate number from another record is refused
        await pg.click("#newChallan")
        await fill_challan(pg, "Second Party")
        await pg.click("#challanNumber") if False else None
        await pg.click('input[name="numberMode"][value="manual"]')
        await pg.fill("#challanNumber", "DC-0001")
        await pg.click("#saveChallan")
        check("4b duplicate number refused", "already used" in await pg.inner_text("#saveStatus"))
        check("4b still one record", len(json.loads(await pg.evaluate("localStorage.getItem('bhagyalaxmi-delivery-challans-v1')"))) == 1)

        # 5. Reload keeps records (localStorage persistence)
        await pg.reload()
        check("5 record survives reload", "DC-0001" in await pg.inner_text("#historyList"))
        check("5 no page errors", not errs, str(errs))
        await ctx.close()

        # 6. WhatsApp message content and encoding
        ctx, pg, errs = await fresh(browser)
        await pg.evaluate("(() => { window.__opened = []; window.open = (url) => { window.__opened.push(String(url)); return window; }; })()")
        await fill_challan(pg, "Acme Traders\nAhmedabad", items=(("Steel plate & rods", "10", "", "1200.5"), ("Bolts", "", "2", "")))
        await pg.click("#shareWhatsapp")
        opened = await pg.evaluate("window.__opened")
        check("6 wa.me URL opened", len(opened) == 1 and opened[0].startswith("https://wa.me/?text="), str(opened))
        msg = unquote(opened[0].split("?text=", 1)[1]) if opened else ""
        for needle in ["Shree Bhagyalaxmi Industries", "Challan No: DC-0001", "Acme Traders", "GJ 01 AB 1234",
                       "Transport: Porter", "Steel plate & rods", "NOS: 10", "Bolts", "SET: 2", "₹1,200.50", "Total: ₹1,200.50"]:
            check(f"6 message contains '{needle}'", needle in msg, msg)
        check("6 no PDF claim", "pdf" not in msg.lower())
        check("6 message box filled", (await pg.input_value("#shareText")) == msg)
        check("6 status says send yourself", "press send yourself" in await pg.inner_text("#saveStatus"))
        await ctx.close()

        # 6b. Blocked WhatsApp -> copy fallback path visible
        ctx, pg, errs = await fresh(browser)
        await pg.evaluate("(() => { window.open = () => null; })()")
        await fill_challan(pg, "Blocked Co")
        await pg.click("#shareWhatsapp")
        check("6b blocked open shows fallback message", "did not open" in await pg.inner_text("#saveStatus"))
        check("6b fallback box visible", await pg.is_visible("#shareBox"))
        await ctx.close()

        # 6c. Native bridge is used when provided
        ctx, pg, errs = await fresh(browser)
        await pg.evaluate("(() => { window.__bridge=[]; window.ChallanNative={shareWhatsApp:(t)=>window.__bridge.push(t)}; })()")
        await fill_challan(pg, "Bridge Co")
        await pg.click("#shareWhatsapp")
        check("6c native bridge receives text", len(await pg.evaluate("window.__bridge")) == 1)
        await ctx.close()

        # 7. Empty and incomplete challans
        ctx, pg, errs = await fresh(browser)
        await pg.click("#saveChallan")
        check("7 empty challan not saved", "Add a recipient" in await pg.inner_text("#saveStatus") and await pg.inner_text("#historyList") == "No saved challans found.")
        await pg.click("#shareWhatsapp")
        check("7 empty challan not shared", "Add a recipient" in await pg.inner_text("#saveStatus"))
        await pg.fill("#recipient", "Only recipient")
        await pg.click("#saveChallan")
        check("7 recipient-only challan saves", "Saved DC-0001" in await pg.inner_text("#saveStatus"))
        await pg.click('#printPdf')
        check("7 print button does not throw", not errs, str(errs))
        await ctx.close()

        # 8. Malformed storage must not crash startup
        ctx, pg, errs = await fresh(browser)
        await pg.evaluate("localStorage.setItem('bhagyalaxmi-delivery-challans-v1', JSON.stringify({a:1}))")
        await pg.evaluate("localStorage.setItem('bhagyalaxmi-transport-names-v1', '{not json')")
        await pg.evaluate("localStorage.setItem('bhagyalaxmi-saved-recipients-v1', JSON.stringify([null, 5, {id:'x'}]))")
        await pg.reload()
        check("8 malformed storage: no page errors", not errs, str(errs))
        check("8 malformed storage: history shows empty state", await pg.inner_text("#historyList") == "No saved challans found.")
        await fill_challan(pg, "Recovered")
        await pg.click("#saveChallan")
        check("8 can save after malformed storage", "Saved" in await pg.inner_text("#saveStatus"))
        await ctx.close()

        # 9. Storage write failure gives a message, no crash
        ctx, pg, errs = await fresh(browser)
        await pg.evaluate("(() => { Storage.prototype.setItem = function(){ throw new Error('QuotaExceededError'); }; })()")
        await fill_challan(pg, "Quota Co")
        await pg.click("#saveChallan")
        check("9 storage failure is reported", "NOT saved" in await pg.inner_text("#saveStatus"))
        check("9 storage failure no page error", not errs, str(errs))
        await ctx.close()

        # 10. Serial numbers after add/remove
        ctx, pg, errs = await fresh(browser)
        await pg.click("#addItem"); await pg.click("#addItem")
        await pg.click("#itemInputs tr:nth-child(8) .remove-item")
        await pg.click("#addItem")
        srs = await pg.eval_on_selector_all("#itemInputs .sr", "els=>els.map(e=>e.textContent)")
        check("10 serial numbers continuous", srs == [str(i) for i in range(1, len(srs)+1)], str(srs))
        await ctx.close()

        # 11. Transport case-insensitive reuse
        ctx, pg, errs = await fresh(browser)
        await pg.fill("#customTransport", "porter")
        await pg.click("#saveTransport")
        check("11 transport keeps existing spelling", await pg.input_value("#transportName") == "Porter")
        await ctx.close()

        # 12. Desktop layout loads and saves
        ctx, pg, errs = await fresh(browser, mobile=False)
        await fill_challan(pg, "Desktop Co")
        await pg.click("#saveChallan")
        await pg.click("#newChallan"); await pg.click(".history-entry"); await pg.wait_for_timeout(400)
        check("12 desktop tap loads record", await pg.input_value("#recipient") == "Desktop Co")
        check("12 desktop no errors", not errs, str(errs))
        await ctx.close()

        await browser.close()
    failed = [n for n, ok in results if not ok]
    print(f"\n{len(results)-len(failed)}/{len(results)} checks passed")
    sys.exit(1 if failed else 0)

asyncio.run(main())
