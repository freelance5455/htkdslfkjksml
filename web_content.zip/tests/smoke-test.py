"""
Browser test for the Bhagyalaxmi challan app.
Run:  pip install playwright && playwright install chromium && python tests/smoke-test.py
Opens index.html in headless Chromium (phone-sized and desktop) and checks the core flows.
It does NOT test the APK wrapper or real Android WebView; see APKFORGE-NOTES.md for that.
"""
import asyncio, json, pathlib, sys
from urllib.parse import unquote
from playwright.async_api import async_playwright

APP = (pathlib.Path(__file__).resolve().parent.parent / "index.html").as_uri()
results = []

def check(name, ok, detail=""):
    results.append((name, ok))
    print(("PASS " if ok else "FAIL ") + name + (f"  [{detail}]" if detail and not ok else ""))

async def fresh(browser, mobile=True):
    ctx = await browser.new_context(viewport={"width": 390, "height": 844} if mobile else {"width": 1200, "height": 900},
                                    has_touch=mobile, is_mobile=mobile)
    pg = await ctx.new_page()
    errors = []
    pg.on("pageerror", lambda e: errors.append(str(e)))
    await pg.goto(APP)
    return ctx, pg, errors

async def fill_challan(pg, recipient, vehicle="GJ 01 AB 1234", transport="Porter", items=(("Steel plate", "10", "", "1200"),)):
    await pg.fill("#recipient", recipient)
    await pg.fill("#vehicleNumber", vehicle)
    await pg.select_option("#transportName", transport)
    for i, (desc, nos, set_, amount) in enumerate(items):
        if i >= 1: await pg.click("#addItem")
        row = f"#itemInputs tr:nth-child({i+1})"
        await pg.fill(f"{row} [data-field=description]", desc)
        if nos: await pg.fill(f"{row} [data-field=nos]", nos)
        if set_: await pg.fill(f"{row} [data-field=set]", set_)
        if amount: await pg.fill(f"{row} [data-field=amount]", amount)

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(args=["--no-sandbox"])

        # 1-2. Create, save, appears in list
        ctx, pg, errs = await fresh(browser)
        await fill_challan(pg, "Acme Traders\nAhmedabad", items=(("Steel plate", "10", "", "1200"), ("Bolts", "", "2", "")))
        await pg.click("#saveChallan")
        check("1 save new challan", "Saved DC-0001" in await pg.inner_text("#saveStatus"))
        check("2 appears under Previous challans", "DC-0001" in await pg.inner_text("#historyList"))

        # 3. Tap restores all fields
        await pg.click("#newChallan")
        await pg.tap(".history-entry")
        await pg.wait_for_timeout(600)
        check("3 recipient restored", await pg.input_value("#recipient") == "Acme Traders\nAhmedabad")
        check("3 vehicle restored", await pg.input_value("#vehicleNumber") == "GJ 01 AB 1234")
        check("3 transport restored", await pg.input_value("#transportName") == "Porter")
        check("3 number restored", await pg.input_value("#challanNumber") == "DC-0001")
        check("3 item 1 restored", await pg.input_value('#itemInputs tr:nth-child(1) [data-field=description]') == "Steel plate"
              and await pg.input_value('#itemInputs tr:nth-child(1) [data-field=nos]') == "10"
              and await pg.input_value('#itemInputs tr:nth-child(1) [data-field=amount]') == "1200")
        check("3 item 2 restored (SET)", await pg.input_value('#itemInputs tr:nth-child(2) [data-field=set]') == "2")
        check("3 status says loaded", "Loaded DC-0001" in await pg.inner_text("#saveStatus"))

        # 4. Edit and save does not duplicate
        await pg.fill("#vehicleNumber", "GJ 99 ZZ 0001")
        await pg.click("#saveChallan")
        data = json.loads(await pg.evaluate("localStorage.getItem('bhagyalaxmi-delivery-challans-v1')"))
        check("4 edit updates, no duplicate", len(data) == 1 and data[0]["vehicle"] == "GJ 99 ZZ 0001", str(len(data)))

        # 4b. Duplicate number from another record is refused
        await pg.click("#newChallan")
        await fill_challan(pg, "Second Party")
        await pg.click("#challanNumber") if False else None
        await pg.click('input[name="numberMode"][value="manual"]')
        await pg.fill("#challanNumber", "DC-0001")
        await pg.click("#saveChallan")
        check("4b duplicate number refused", "already used" in await pg.inner_text("#saveStatus"))
        check("4b still one record", len(json.loads(await pg.evaluate("localStorage.getItem('bhagyalaxmi-delivery-challans-v1')"))) == 1)

        # 5. Reload keeps records (localStorage persistence)
        await pg.reload()
        check("5 record survives reload", "DC-0001" in await pg.inner_text("#historyList"))
        check("5 no page errors", not errs, str(errs))
        await ctx.close()

        # 6. WhatsApp: share sheet receives the full message text (no window.open / wa.me)
        ctx, pg, errs = await fresh(browser)
        await pg.evaluate("""(() => {
          window.__opened = []; window.open = (url) => { window.__opened.push(String(url)); return null; };
          window.__shared = [];
          navigator.share = (data) => { window.__shared.push(data); return Promise.resolve(); };
          navigator.canShare = () => true;
        })()""")
        await fill_challan(pg, "Acme Traders\nAhmedabad", items=(("Steel plate & rods", "10", "", "1200.5"), ("Bolts", "", "2", "")))
        await pg.click("#shareWhatsapp")
        await pg.wait_for_timeout(300)
        shared = await pg.evaluate("window.__shared")
        msg = shared[0]["text"] if shared else ""
        check("6 share sheet opened once", len(shared) == 1)
        check("6 no window.open (no WhatsApp error page)", await pg.evaluate("window.__opened.length") == 0)
        for needle in ["Shree Bhagyalaxmi Industries", "Challan No: DC-0001", "Acme Traders", "GJ 01 AB 1234",
                       "Transport: Porter", "Steel plate & rods", "NOS: 10", "Bolts", "SET: 2", "₹1,200.50", "Total: ₹1,200.50"]:
            check(f"6 message contains '{needle}'", needle in msg, msg)
        check("6 message box filled", (await pg.input_value("#shareText")) == msg)
        check("6 status says send yourself", "press send yourself" in await pg.inner_text("#saveStatus"))
        await ctx.close()

        # 6b. Share sheet unavailable -> copy box, no navigation
        ctx, pg, errs = await fresh(browser)
        await pg.evaluate("(() => { window.__opened=[]; window.open = (u) => { window.__opened.push(String(u)); return null; }; })()")
        await fill_challan(pg, "Blocked Co")
        await pg.click("#shareWhatsapp")
        check("6b no share sheet -> copy message shown", "Copy message" in await pg.inner_text("#saveStatus") and await pg.is_visible("#shareBox"))
        check("6b no window.open either", await pg.evaluate("window.__opened.length") == 0)
        await ctx.close()

        # 6c. Share sheet cancelled by user
        ctx, pg, errs = await fresh(browser)
        await pg.evaluate("(() => { navigator.share = () => { const e = new Error('x'); e.name='AbortError'; return Promise.reject(e); }; })()")
        await fill_challan(pg, "Cancel Co")
        await pg.click("#shareWhatsapp")
        await pg.wait_for_timeout(200)
        check("6c cancel handled", "cancelled" in await pg.inner_text("#saveStatus"))
        await ctx.close()

        # 6d. Share as PDF through the share sheet with a real PDF file
        ctx, pg, errs = await fresh(browser)
        await pg.evaluate("""(() => {
          window.__files = [];
          navigator.canShare = (d) => !!(d && d.files);
          navigator.share = (d) => { window.__files.push({ name: d.files[0].name, type: d.files[0].type, size: d.files[0].size }); return Promise.resolve(); };
        })()""")
        await fill_challan(pg, "PDF Co\nAhmedabad", items=(("Steel plate", "10", "", "1200"),))
        await pg.click("#sharePdf")
        await pg.wait_for_timeout(800)
        files = await pg.evaluate("window.__files")
        check("6d PDF handed to share sheet", len(files) == 1 and files[0]["type"] == "application/pdf", str(files))
        check("6d PDF file name", bool(files) and files[0]["name"] == "Delivery-Challan-DC-0001.pdf", str(files))
        check("6d PDF has content", bool(files) and files[0]["size"] > 1000, str(files))
        check("6d no page errors", not errs, str(errs))
        await ctx.close()

        # 6e. No share sheet -> PDF downloaded as a file
        ctx, pg, errs = await fresh(browser)
        await pg.evaluate("(() => { navigator.share = undefined; navigator.canShare = undefined; })()")
        await fill_challan(pg, "Download Co")
        async with pg.expect_download() as dl_info:
            await pg.click("#sharePdf")
        dl = await dl_info.value
        path = await dl.path()
        head = open(path, "rb").read(5)
        check("6e download starts as PDF", head == b"%PDF-", str(head))
        check("6e download name", dl.suggested_filename == "Delivery-Challan-DC-0001.pdf", dl.suggested_filename)
        check("6e status reports download", "downloaded" in await pg.inner_text("#saveStatus"))
        await ctx.close()

        # 6f. PDF text content matches challan (checked by reading the PDF)
        try:
            import pypdf
            ctx, pg, errs = await fresh(browser)
            await pg.evaluate("(() => { navigator.share = undefined; navigator.canShare = undefined; })()")
            await fill_challan(pg, "Acme Traders\nAhmedabad", vehicle="GJ 01 AB 1234", items=(("Steel plate", "10", "", "1200.5"), ("Bolts", "", "2", "")))
            async with pg.expect_download() as dl_info:
                await pg.click("#sharePdf")
            dl = await dl_info.value
            reader = pypdf.PdfReader(await dl.path())
            text_out = "\n".join(p.extract_text() for p in reader.pages)
            for needle in ["DELIVERY CHALLAN", "SHREE BHAGYALAXMI INDUSTRIES", "DC-0001", "Acme Traders", "GJ 01 AB 1234", "Porter", "Steel plate", "1,200.50", "Bolts", "AUTHORIZED SIGNATORY"]:
                check(f"6f PDF contains '{needle}'", needle in text_out, text_out[:300])
            check("6f PDF is one page", len(reader.pages) == 1, str(len(reader.pages)))
            await ctx.close()
        except ImportError:
            print("SKIP 6f PDF text check (pip install pypdf)")

        # 6g. Long challan spills onto a second page with the table header repeated
        try:
            import pypdf
            ctx, pg, errs = await fresh(browser)
            await pg.evaluate("(() => { navigator.share = undefined; navigator.canShare = undefined; })()")
            many = tuple((f"Item number {i} with a fairly long description text", str(i), "", str(i*10)) for i in range(1, 25))
            await fill_challan(pg, "Long Co", items=many)
            async with pg.expect_download() as dl_info:
                await pg.click("#sharePdf")
            dl = await dl_info.value
            reader = pypdf.PdfReader(await dl.path())
            check("6g long challan has multiple pages", len(reader.pages) >= 2, str(len(reader.pages)))
            check("6g last item present", "Item number 24" in "\n".join(p.extract_text() for p in reader.pages))
            check("6g no page errors", not errs, str(errs))
            await ctx.close()
        except ImportError:
            print("SKIP 6g long challan check (pip install pypdf)")

        # 7. Empty and incomplete challans
        ctx, pg, errs = await fresh(browser)
        await pg.click("#saveChallan")
        check("7 empty challan not saved", "Add a recipient" in await pg.inner_text("#saveStatus") and await pg.inner_text("#historyList") == "No saved challans found.")
        await pg.click("#shareWhatsapp")
        check("7 empty challan not shared", "Add a recipient" in await pg.inner_text("#saveStatus"))
        await pg.fill("#recipient", "Only recipient")
        await pg.click("#saveChallan")
        check("7 recipient-only challan saves", "Saved DC-0001" in await pg.inner_text("#saveStatus"))
        await pg.evaluate("(() => { navigator.share = undefined; navigator.canShare = undefined; })()")
        async with pg.expect_download() as dl_info:
            await pg.fill('#recipient', 'x')
            await pg.click('#sharePdf')
        await dl_info.value
        check("7 share PDF of incomplete challan works", not errs, str(errs))
        await ctx.close()

        # 8. Malformed storage must not crash startup
        ctx, pg, errs = await fresh(browser)
        await pg.evaluate("localStorage.setItem('bhagyalaxmi-delivery-challans-v1', JSON.stringify({a:1}))")
        await pg.evaluate("localStorage.setItem('bhagyalaxmi-transport-names-v1', '{not json')")
        await pg.evaluate("localStorage.setItem('bhagyalaxmi-saved-recipients-v1', JSON.stringify([null, 5, {id:'x'}]))")
        await pg.reload()
        check("8 malformed storage: no page errors", not errs, str(errs))
        check("8 malformed storage: history shows empty state", await pg.inner_text("#historyList") == "No saved challans found.")
        await fill_challan(pg, "Recovered")
        await pg.click("#saveChallan")
        check("8 can save after malformed storage", "Saved" in await pg.inner_text("#saveStatus"))
        await ctx.close()

        # 9. Storage write failure gives a message, no crash
        ctx, pg, errs = await fresh(browser)
        await pg.evaluate("(() => { Storage.prototype.setItem = function(){ throw new Error('QuotaExceededError'); }; })()")
        await fill_challan(pg, "Quota Co")
        await pg.click("#saveChallan")
        check("9 storage failure is reported", "NOT saved" in await pg.inner_text("#saveStatus"))
        check("9 storage failure no page error", not errs, str(errs))
        await ctx.close()

        # 10. Serial numbers after add/remove
        ctx, pg, errs = await fresh(browser)
        await pg.click("#addItem"); await pg.click("#addItem")
        await pg.click("#itemInputs tr:nth-child(8) .remove-item")
        await pg.click("#addItem")
        srs = await pg.eval_on_selector_all("#itemInputs .sr", "els=>els.map(e=>e.textContent)")
        check("10 serial numbers continuous", srs == [str(i) for i in range(1, len(srs)+1)], str(srs))
        await ctx.close()

        # 11. Transport case-insensitive reuse
        ctx, pg, errs = await fresh(browser)
        await pg.fill("#customTransport", "porter")
        await pg.click("#saveTransport")
        check("11 transport keeps existing spelling", await pg.input_value("#transportName") == "Porter")
        await ctx.close()

        # 12. Desktop layout loads and saves
        ctx, pg, errs = await fresh(browser, mobile=False)
        await fill_challan(pg, "Desktop Co")
        await pg.click("#saveChallan")
        await pg.click("#newChallan"); await pg.click(".history-entry"); await pg.wait_for_timeout(400)
        check("12 desktop tap loads record", await pg.input_value("#recipient") == "Desktop Co")
        check("12 desktop no errors", not errs, str(errs))
        await ctx.close()

        await browser.close()
    failed = [n for n, ok in results if not ok]
    print(f"\n{len(results)-len(failed)}/{len(results)} checks passed")
    sys.exit(1 if failed else 0)

asyncio.run(main())
