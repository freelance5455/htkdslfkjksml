/**
 * WHITE ROOM OS — Phase 6 Comprehensive Unit, Integration & Persistence Tests
 * Covers all 25 required Phase 6 verification areas:
 *  1. Empty database and empty reporting periods (honest empty states, zero-denominator null handling)
 *  2. Correct metric calculations using hand-verifiable fixtures
 *  3. Baseline and trend calculations (0, 1, and >=2 observations)
 *  4. Date-range boundaries and period grouping (daily, weekly, monthly, custom)
 *  5. Zero denominators and missing measurements (never misleading 0% or 100%)
 *  6. Activity vs Competence vs Mastery vs Retention separation (hours studied != competence)
 *  7. No duplicate counting of shared evidence
 *  8. Planned-versus-actual time & estimation error calculations
 *  9. Completion, partial completion, skipping, and rescheduling analysis
 * 10. Workload limits, overload reporting, and non-compensatory scheduling recommendations
 * 11. Error recurrence and unresolved-error counts
 * 12. Remediation outcomes and retest comparisons
 * 13. Historical mastery versus current retention
 * 14. Insufficient-data handling and uncertainty labels (observed facts vs hypotheses)
 * 15. Goal and prerequisite bottleneck analysis (preserving ambitious targets & honest forecasts)
 * 16. Daily, weekly, and monthly review creation and retrieval
 * 17. Review history preservation (multiple revisions preserved without overwriting)
 * 18. Filters and aggregation consistency (date range, goal, capability, skill)
 * 19. JSON, CSV, and Markdown export correctness
 * 20. Special characters and RFC-4180 CSV escaping
 * 21. Database persistence of periodic_reviews
 * 22. Backup/restore compatibility (old v4/v5 backup import + v6 33-store round-trip)
 * 23. No mutation of source records during read-only analytics
 * 24. Reactive state updates after relevant data changes
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { createWhiteRoomSystem } from '../src/core/bootstrap.js';
import {
  escapeCsvCell,
  resolvePeriodBoundaries,
} from '../src/engines/analyticsAndReviewEngine.js';

test('Phase 6.1, 6.4 & 6.5: Empty Database, Empty Reporting Periods, Date Boundaries & Zero Denominators', async () => {
  // Create a completely empty system (skipSeed: true)
  const emptySys = await createWhiteRoomSystem({
    forceMemory: true,
    skipSeed: true,
    initialDate: '2026-10-14',
  });
  const { analyticsEngine } = emptySys.engines;

  const emptyReport = await analyticsEngine.getComprehensiveAnalyticsReport({
    referenceDate: '2026-10-14',
  });
  assert.equal(emptyReport.isEmptyDatabase, true, 'Empty DB must produce honest empty state');
  assert.equal(emptyReport.developmentTrends.skills.length, 0);

  // Verify zero denominators return null (not misleading 0% or 100%)
  const dims = emptyReport.nineDimensions;
  assert.equal(dims.activity.value, null);
  assert.equal(dims.learning.value, null);
  assert.equal(dims.competence.value, null);
  assert.equal(dims.mastery.value, null);
  assert.equal(dims.retention.value, null);
  assert.equal(dims.consistency.value, null);
  assert.equal(dims.workload.value, null);
  assert.equal(dims.errors.value, null);
  assert.equal(dims.execution.value, null);

  // Verify empty period review draft
  const emptyDaily = await analyticsEngine.generateReviewDraft('daily', '2026-10-14');
  assert.equal(emptyDaily.snapshot.isEmptyPeriod, true);
  assert.ok(emptyDaily.snapshot.missingDataWarnings.length >= 1);

  // Verify deterministic UTC date boundaries (Daily, Weekly, Monthly including leap year Feb 2024 and Oct 2026)
  const bDaily = resolvePeriodBoundaries('daily', '2026-10-14');
  assert.equal(bDaily.startDate, '2026-10-14');
  assert.equal(bDaily.endDate, '2026-10-14');
  assert.equal(bDaily.dayCount, 1);

  const bWeekly = resolvePeriodBoundaries('weekly', '2026-10-14');
  assert.equal(bWeekly.startDate, '2026-10-14');
  assert.equal(bWeekly.endDate, '2026-10-20');
  assert.equal(bWeekly.dayCount, 7);

  const bMonthlyOct = resolvePeriodBoundaries('monthly', '2026-10-14');
  assert.equal(bMonthlyOct.startDate, '2026-10-01');
  assert.equal(bMonthlyOct.endDate, '2026-10-31');
  assert.equal(bMonthlyOct.dayCount, 31);

  const bMonthlyLeapFeb = resolvePeriodBoundaries('monthly', '2024-02-15');
  assert.equal(bMonthlyLeapFeb.startDate, '2024-02-01');
  assert.equal(bMonthlyLeapFeb.endDate, '2024-02-29');
  assert.equal(bMonthlyLeapFeb.dayCount, 29);
});

test('Phase 6.2, 6.3, 6.6 & 6.7: Hand-Verifiable Fixtures, Baseline & Trend Calculations, 9D Separation & Zero Double-Counting', async () => {
  const sys = await createWhiteRoomSystem({
    forceMemory: true,
    skipSeed: true,
    initialDate: '2026-10-14',
  });
  const { skillEngine, analyticsEngine } = sys.engines;

  // Create 1 capability, 1 goal, and 1 skill with ambitious targetLevel = 9, minTestScore = 85
  await sys.db.put('capabilities', {
    id: 'cap-test-math',
    order: 1,
    name: 'Mathematics',
    nameAr: 'الرياضيات',
    subareas: ['Logic'],
  });
  await sys.db.put('visions', {
    id: 'vis-1',
    title: 'Mastery Vision',
    statement: 'Long term mastery',
    horizonYears: 5,
  });
  await sys.db.put('goals', {
    id: 'goal-math-1',
    visionId: 'vis-1',
    capabilityId: 'cap-test-math',
    title: 'Discrete Math Mastery',
    status: 'active',
    progressPct: 0,
    targetDate: '2026-12-31',
  });

  await skillEngine.createSkill({
    id: 'skill-logic-1',
    name: 'Propositional Logic',
    nameAr: 'المنطق القضوي',
    capabilityId: 'cap-test-math',
    goalId: 'goal-math-1',
    currentLevel: 2,
    targetLevel: 9,
    masteryCriteria: {
      minTestScore: 85,
      minAccuracy: 85,
      minSuccessfulAttempts: 1,
      consistency: 1,
      requiredEvidenceCount: 1,
      prerequisiteMastery: true,
      requireAllSubskillsMastered: false,
    },
  });

  // Case A: Record 120 minutes of training & 2 tasks (1 completed, 1 skipped) WITHOUT any test attempts!
  await skillEngine.recordTrainingSession({
    skillId: 'skill-logic-1',
    durationMinutes: 120,
    evidenceType: 'study',
    evidenceTitle: 'ملخص قوانين دي مورغان',
  });
  await sys.db.put('tasks', {
    id: 't-fix-1',
    title: 'مهمة 1 مكتملة',
    date: '2026-10-14',
    category: 'Primary',
    status: 'completed',
    plannedDurationMin: 40,
    actualDurationMin: 50,
    priority: 1,
    skillId: 'skill-logic-1',
  });
  await sys.db.put('tasks', {
    id: 't-fix-2',
    title: 'مهمة 2 متخطاة',
    date: '2026-10-14',
    category: 'Secondary',
    status: 'skipped',
    plannedDurationMin: 60,
    priority: 2,
    skillId: 'skill-logic-1',
    skipReason: 'DURATION_TOO_LONG',
  });

  const dimsBeforeTest = await analyticsEngine.computeNineDimensions();
  // Hand-verifiable check: 1 completed out of 2 scheduled tasks = 50% Activity & 50% Execution
  assert.equal(dimsBeforeTest.dimensions.activity.value, 50);
  assert.equal(dimsBeforeTest.dimensions.execution.value, 50);
  // Hours studied / tasks completed must NEVER be equated with Competence, Mastery, or Retention!
  assert.equal(
    dimsBeforeTest.dimensions.competence.value,
    null,
    'Competence must be null (unmeasured) when 0 test attempts and 0 competence evidence exist, even with 120m study!'
  );
  assert.equal(dimsBeforeTest.dimensions.mastery.value, 0);
  assert.equal(dimsBeforeTest.dimensions.retention.value, null);
  assert.equal(dimsBeforeTest.evidencePartitionAudit.zeroDoubleCountingVerified, true);

  // Check Trend with 0 test observations -> baseline is null, recentTrend is INSUFFICIENT_DATA
  const trends0 = await analyticsEngine.analyzeDevelopmentTrends();
  assert.equal(trends0.skills[0].observationCount, 0);
  assert.equal(trends0.skills[0].baseline, null);
  assert.equal(trends0.skills[0].currentMeasuredState.directlyMeasuredScore, null);
  assert.equal(trends0.skills[0].recentTrend, 'INSUFFICIENT_DATA');
  assert.equal(trends0.skills[0].configuredTarget.targetLevel, 9, 'Ambitious target must be preserved');

  // Case B: Record first Test Attempt (Score 60%, Accuracy 60% on 2026-10-10) -> Baseline = 60%, 1 observation -> still INSUFFICIENT_DATA for trend delta
  await skillEngine.recordTestAttempt({
    id: 'att-fix-1',
    skillId: 'skill-logic-1',
    score: 60,
    accuracy: 60,
    evidence: 'First diagnostic test',
    timestamp: '2026-10-10T10:00:00.000Z',
  });
  const trends1 = await analyticsEngine.analyzeDevelopmentTrends();
  assert.equal(trends1.skills[0].observationCount, 1);
  assert.equal(trends1.skills[0].baseline.value, 60);
  assert.equal(trends1.skills[0].changeSinceBaseline, null);
  assert.equal(trends1.skills[0].recentTrend, 'INSUFFICIENT_DATA');

  // Case C: Record second Test Attempt (Score 90%, Accuracy 90% on 2026-10-14) -> Delta = +30%, Trend = IMPROVING, Sufficient Evidence = true
  // First resolve the open error from att-fix-1 via remediation + retest
  const openErrors = await sys.db.queryByField('errors', 'skillId', 'skill-logic-1');
  const rem = await sys.engines.diagnosticsEngine.generateTargetedRemediation(openErrors[0].id, {
    date: '2026-10-12',
  });
  for (const ct of rem.correctiveTasks) {
    await skillEngine.completeCorrectiveTask(ct.id, { durationMinutes: 25 });
  }
  await sys.engines.diagnosticsEngine.executeVerifiedRetest({
    id: 'att-fix-2',
    linkedErrorId: openErrors[0].id,
    verificationMode: 'equivalent_questions',
    score: 90,
    accuracy: 90,
    evidence: 'Second verified test attempt',
    timestamp: '2026-10-14T10:00:00.000Z',
  });

  const trends2 = await analyticsEngine.analyzeDevelopmentTrends();
  const skTrend = trends2.skills[0];
  assert.equal(skTrend.observationCount, 2);
  assert.equal(skTrend.baseline.value, 60);
  assert.equal(skTrend.currentMeasuredState.directlyMeasuredScore, 90);
  assert.equal(skTrend.changeSinceBaseline, 30);
  assert.equal(skTrend.recentTrend, 'IMPROVING');
  assert.equal(skTrend.historicalTrend, 'IMPROVING');
  assert.equal(skTrend.evidenceSufficiency.isSufficient, true);
});

test('Phase 6.8–6.15: Scheduling/Execution Analysis, Error/Bottleneck Analysis, Remediation Outcomes & Goal Forecasting', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true, initialDate: '2026-10-14' });
  const { analyticsEngine, diagnosticsEngine, skillEngine, schedulerEngine } = sys.engines;

  // Complete 1 task with actualDurationMin = 60 (planned 45) and skip 1 task on 2026-10-14
  const dayView = await schedulerEngine.getDailyExecutionView('2026-10-14', 7);
  await schedulerEngine.completeTaskExecution(dayView.tasks[0].id, {
    actualDurationMin: 60,
    outcome: 'Completed with slight time underestimation',
  });
  if (dayView.tasks[1]) {
    await schedulerEngine.skipTaskExecution(dayView.tasks[1].id, {
      skipReason: 'DURATION_TOO_LONG',
    });
  }

  // Create a diagnostic error + remediation + retest on skill-python-algo
  const diag = await diagnosticsEngine.runDiagnosticAssessment({
    skillId: 'skill-python-algo',
    subskillId: 'sub-py-arrays',
    score: 50,
    accuracy: 50,
    reportedCategory: 'conceptual_misunderstanding',
    observedNotes: 'اختبار تشخيصي أولي',
    date: '2026-10-14',
  });
  const rem = await diagnosticsEngine.generateTargetedRemediation(diag.createdError.id, {
    date: '2026-10-14',
  });
  for (const ct of rem.correctiveTasks) {
    await skillEngine.completeCorrectiveTask(ct.id, { durationMinutes: 25 });
  }
  await diagnosticsEngine.executeVerifiedRetest({
    linkedErrorId: diag.createdError.id,
    verificationMode: 'new_examples',
    score: 88,
    accuracy: 86,
    evidence: 'تحسن واضح بعد الشرح الموجه',
  });

  const schedAnalysis = await analyticsEngine.analyzeSchedulingAndExecution();
  assert.ok(schedAnalysis.plannedMinutes > 0);
  assert.ok(schedAnalysis.actualMinutes >= 60);
  assert.ok(schedAnalysis.counts.completed >= 1);
  assert.ok(schedAnalysis.counts.skipped >= 1);
  assert.ok(schedAnalysis.counts.rescheduled >= 1);
  // Ensure no recommendation ever suggests compensatory overloading
  for (const rec of schedAnalysis.recommendations) {
    assert.ok(!rec.explanation.includes('مضاعفة الحمل'));
  }

  const errBottleneck = await analyticsEngine.analyzeErrorsAndBottlenecks();
  assert.ok(
    errBottleneck.downstreamBottlenecks.some((b) => b.bottleneckSkillId === 'skill-python-algo'),
    'Must identify skill-python-algo as a bottleneck blocking downstream skill-dp-graphs'
  );
  assert.ok(
    errBottleneck.remediationOutcomes.some(
      (ro) => ro.remediationId === rem.remediation.id && ro.outcomeClassification === 'IMPROVED_AND_VERIFIED'
    ),
    'Must verify remediation outcome improved retest score'
  );
  assert.ok(
    errBottleneck.activityWithoutAssessmentSkills.length >= 1,
    'Must detect seeded skills that have study/practice minutes but 0 test attempts'
  );

  const goalAnalysis = await analyticsEngine.analyzeGoalsAndTargets();
  assert.ok(goalAnalysis.goals.length >= 3);
  for (const g of goalAnalysis.goals) {
    assert.ok(g.configuredTargetDate, 'Must preserve configured target date');
    assert.ok(
      g.completionForecast.status === 'INSUFFICIENT_DATA' ||
        g.completionForecast.status === 'ESTIMATED_FROM_HISTORICAL_VELOCITY' ||
        g.completionForecast.status === 'TARGET_ACHIEVED'
    );
  }
});

test('Phase 6.16–6.24: Periodic Reviews (Daily/Weekly/Monthly), History Preservation, Filters, Exports (JSON/CSV/MD), CSV Escaping, Backup v6 & Read-Only Non-Mutation', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true, initialDate: '2026-10-14' });
  const { analyticsEngine, backupEngine } = sys.engines;

  // 1. Verify Read-Only Analytics do NOT mutate source records
  const beforeSnapshot = await backupEngine.exportBackup();
  await analyticsEngine.getComprehensiveAnalyticsReport({ referenceDate: '2026-10-14' });
  await analyticsEngine.analyzeDevelopmentTrends({ goalId: 'goal-cs-swe' });
  await analyticsEngine.computeNineDimensions({ capabilityId: 'cap-04-cs' });
  const afterSnapshot = await backupEngine.exportBackup();
  assert.equal(
    beforeSnapshot.checksum,
    afterSnapshot.checksum,
    'Read-only analytics must NEVER mutate any source database records'
  );

  // 2. Save Daily, Weekly, and Monthly Reviews and verify History Preservation (two revisions of daily review)
  const dailyRev1 = await analyticsEngine.savePeriodicReview({
    periodType: 'daily',
    referenceDate: '2026-10-14',
    userNotes: 'ملاحظة المراجعة اليومية الأولى',
    decisions: ['التركيز على هياكل البيانات'],
    nextActions: ['حل مسألتين إضافيتين'],
  });
  const dailyRev2 = await analyticsEngine.savePeriodicReview({
    periodType: 'daily',
    referenceDate: '2026-10-14',
    userNotes: 'تحديث المراجعة اليومية بعد المساء',
    decisions: ['النوم المبكر'],
    nextActions: ['بدء جلسة الصباح'],
  });
  assert.notEqual(dailyRev1.id, dailyRev2.id, 'Must preserve historical reviews without overwriting');
  assert.equal(dailyRev1.revisionNumber, 1);
  assert.equal(dailyRev2.revisionNumber, 2);

  await analyticsEngine.savePeriodicReview({
    periodType: 'weekly',
    referenceDate: '2026-10-14',
    userNotes: 'مراجعة الأسبوع الأول',
    decisions: ['الحفاظ على 20% Buffer'],
    nextActions: ['مراجعة البطاقات المستحقة'],
  });

  await analyticsEngine.savePeriodicReview({
    periodType: 'monthly',
    referenceDate: '2026-10-14',
    userNotes: 'مراجعة شهر أكتوبر',
    decisions: ['رفع استمرارية التدريب'],
    nextActions: ['إكمال مسار الخوارزميات'],
  });

  const allSavedReviews = await analyticsEngine.getPeriodicReviews();
  assert.equal(allSavedReviews.length, 4, 'All 4 review records must be preserved in periodic_reviews');

  // 3. Verify Filters (by skillId and date range)
  const filteredReport = await analyticsEngine.getComprehensiveAnalyticsReport({
    skillId: 'skill-python-algo',
    startDate: '2026-10-01',
    endDate: '2026-10-31',
  });
  assert.equal(filteredReport.developmentTrends.skills.length, 1);
  assert.equal(filteredReport.developmentTrends.skills[0].id, 'skill-python-algo');

  // 4. Verify RFC-4180 CSV Escaping with commas, quotes, newlines, and Arabic text
  assert.equal(escapeCsvCell('Simple'), 'Simple');
  assert.equal(escapeCsvCell('Hello, World'), '"Hello, World"');
  assert.equal(escapeCsvCell('Text with "quotes" inside'), '"Text with ""quotes"" inside"');
  assert.equal(escapeCsvCell('Line 1\nLine 2, "quoted"'), '"Line 1\nLine 2, ""quoted"""');
  assert.equal(escapeCsvCell('نص عربي، مع فاصلة "واقتباس"'), '"نص عربي، مع فاصلة ""واقتباس"""');

  // 5. Verify JSON, CSV, and Markdown Report Exports
  const jsonExport = await analyticsEngine.exportReportJSON({ referenceDate: '2026-10-14' });
  const parsedJson = JSON.parse(jsonExport);
  assert.ok(parsedJson.generatedAt);
  assert.ok(parsedJson.metricDefinitions.activity);
  assert.ok(parsedJson.dataLimitations.length >= 2);

  const csvExport = await analyticsEngine.exportReportCSV({ referenceDate: '2026-10-14' });
  assert.ok(csvExport.includes('Section,EntityIdOrKey,NameOrLabel'));
  assert.ok(csvExport.includes('REPORT_METADATA'));
  assert.ok(csvExport.includes('DIMENSION_METRIC'));
  assert.ok(csvExport.includes('SKILL_TREND'));

  const mdExport = await analyticsEngine.exportReportMarkdown({ referenceDate: '2026-10-14' });
  assert.ok(mdExport.includes('# WHITE ROOM OS — تقرير التحليلات والأداء والمراجعات (Phase 6)'));
  assert.ok(mdExport.includes('## 1. المقاييس التسعة المستقلة'));
  assert.ok(mdExport.includes('## 6. القيود المنهجية'));

  // 6. Verify Backup v6 Export (33 stores) & Old Backup (v4/v5) Import Compatibility
  const backupV6 = await backupEngine.exportBackup();
  assert.ok(backupV6.schemaVersion >= 6);
  assert.ok(Object.keys(backupV6.stores).length >= 33);
  assert.equal(backupV6.stores.periodic_reviews.length, 4);

  // Simulate importing an older v4 backup (without periodic_reviews)
  const simulatedV4Stores = { ...backupV6.stores };
  delete simulatedV4Stores.periodic_reviews;
  delete simulatedV4Stores.diagnostic_assessments;
  delete simulatedV4Stores.mastery_history;
  const simulatedV4Bundle = {
    magic: 'WHITE_ROOM_OS_BACKUP',
    schemaVersion: 4,
    dbName: 'WhiteRoomOS_DB',
    exportedAt: new Date().toISOString(),
    stores: simulatedV4Stores,
  };
  const v4Restored = await backupEngine.restoreBackup(simulatedV4Bundle);
  assert.equal(v4Restored.schemaVersion, 4);

  // Now restore full v6 backup and verify all 4 periodic reviews are restored
  await backupEngine.restoreBackup(backupV6);
  const restoredReviews = await analyticsEngine.getPeriodicReviews();
  assert.equal(restoredReviews.length, 4);
});
