/**
 * WHITE ROOM OS — Phase 4 Adaptive Scheduling & Daily Execution Engine Tests
 * Covers:
 * 1. Priority calculation (deterministic, sensitive to goals, errors, prerequisites, overdue reviews)
 * 2. Prerequisite blocking (locked skills/subskills/objectives excluded from eligible queue)
 * 3. Daily schedule generation within available time & safety buffers (college day vs focus day)
 * 4. Conflict detection for overlapping time blocks
 * 5. Task deferral with explicit reasons when time is insufficient or reviews crowd out primary work
 * 6. Task execution lifecycle transitions (Planned -> Ready -> In Progress -> Completed / Partially Completed / Skipped)
 * 7. Timer integration with scheduled tasks
 * 8. Adaptive rescheduling after skipped, partially completed, and failed tasks without doubling tomorrow's workload
 * 9. Overload and sleep/recovery protection
 * 10. Weekly plan distribution across 7 days + persistence across reload & Backup/Restore
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculatePriorityScore,
  checkCandidateEligibility,
  calculateAvailableTimeAndBuffers,
  detectTimeBlockConflicts,
  selectAndDeferTasks,
  validateWorkloadAndRecovery,
} from '../src/engines/priorityEngine.js';
import { createWhiteRoomSystem } from '../src/core/bootstrap.js';

test('Phase 4.1: Pure Priority Engine — deterministic scoring, goal alignment, error urgency & prerequisite blocking sensitivity', () => {
  const baseContext = {
    skillsMap: {
      'skill-python-algo': {
        id: 'skill-python-algo',
        nameAr: 'هندسة الخوارزميات',
        priority: 1,
        currentLevel: 3,
        targetLevel: 8,
        goalId: 'goal-cs-swe',
        progress: { competence: 40 },
      },
      'skill-english-c1': {
        id: 'skill-english-c1',
        nameAr: 'اللغة الإنجليزية',
        priority: 3,
        currentLevel: 5,
        targetLevel: 7,
        goalId: 'goal-lang-en',
        progress: { competence: 75 },
      },
    },
    goalsMap: {
      'goal-cs-swe': { id: 'goal-cs-swe', title: 'Algorithmic Mastery', status: 'active', targetDate: '2026-10-25' },
      'goal-lang-en': { id: 'goal-lang-en', title: 'English Fluency', status: 'paused', targetDate: '2027-06-01' },
    },
    errorsMap: {
      'err-1': { id: 'err-1', skillId: 'skill-python-algo', severity: 'critical', status: 'open' },
    },
    allSkills: [
      { id: 'skill-dp-graphs', prerequisites: ['skill-python-algo'] },
      { id: 'skill-sys-design', prerequisites: ['skill-python-algo'] },
    ],
    allSubskills: [],
    allObjectives: [],
    learningPaths: [{ id: 'lp-1', skillId: 'skill-python-algo', objectiveIds: ['obj-1'] }],
    currentDate: '2026-10-14',
    energyLevel: 7,
    availableNetMin: 180,
  };

  const remediationCandidate = {
    id: 'cand-remed',
    title: 'معالجة خطأ حرج في المؤشرين',
    category: 'Remediation',
    skillId: 'skill-python-algo',
    errorId: 'err-1',
    isCorrective: true,
    plannedDurationMin: 35,
    difficulty: 6,
  };

  const secondaryCandidate = {
    id: 'cand-sec',
    title: 'قراءة مقال إنجليزي عام',
    category: 'Secondary',
    skillId: 'skill-english-c1',
    plannedDurationMin: 40,
    difficulty: 4,
  };

  // Determinism check: identical inputs produce identical score
  const scoreA1 = calculatePriorityScore(remediationCandidate, baseContext);
  const scoreA2 = calculatePriorityScore(remediationCandidate, baseContext);
  assert.equal(scoreA1.priorityScore, scoreA2.priorityScore);
  assert.deepEqual(scoreA1.factors, scoreA2.factors);

  const scoreB = calculatePriorityScore(secondaryCandidate, baseContext);

  assert.ok(
    scoreA1.priorityScore > scoreB.priorityScore,
    `Remediation task for active goal with critical error (${scoreA1.priorityScore}) must outrank low-priority secondary task (${scoreB.priorityScore})`
  );
  assert.ok(scoreA1.explanation.includes('يعالج خطأً حرجاً'));
  assert.ok(scoreA1.consequenceIfSkipped.length > 10);
});

test('Phase 4.2: Pure Prerequisite Blocking & Eligibility Filter', () => {
  const context = {
    skillsMap: {
      'skill-python-algo': { id: 'skill-python-algo', nameAr: 'بايثون', status: 'IN_PROGRESS', prerequisites: [] },
      'skill-dp-graphs': {
        id: 'skill-dp-graphs',
        nameAr: 'البرمجة الديناميكية',
        status: 'LOCKED',
        prerequisites: ['skill-python-algo'],
      },
    },
    subskillsMap: {
      'sub-py-arrays': { id: 'sub-py-arrays', name: 'Arrays', masteryState: 'IN_PROGRESS', prerequisites: [] },
      'sub-py-trees': {
        id: 'sub-py-trees',
        name: 'Trees & Graphs',
        masteryState: 'LOCKED',
        prerequisites: ['sub-py-arrays'],
      },
    },
    objectivesMap: {
      'obj-1': { id: 'obj-1', title: 'Two Pointers', status: 'PRACTICING', prerequisites: [] },
      'obj-2': { id: 'obj-2', title: 'BFS/DFS', status: 'LOCKED', prerequisites: ['obj-1'] },
    },
  };

  const unlockedCheck = checkCandidateEligibility(
    { id: 't1', skillId: 'skill-python-algo', subskillId: 'sub-py-arrays', objectiveId: 'obj-1' },
    context
  );
  assert.equal(unlockedCheck.eligible, true);
  assert.equal(unlockedCheck.prerequisiteStatus, 'SATISFIED');

  const lockedSkillCheck = checkCandidateEligibility(
    { id: 't2', skillId: 'skill-dp-graphs' },
    context
  );
  assert.equal(lockedSkillCheck.eligible, false);
  assert.equal(lockedSkillCheck.prerequisiteStatus, 'BLOCKED');
  assert.ok(lockedSkillCheck.blockingIds.includes('skill-python-algo'));

  const lockedObjCheck = checkCandidateEligibility(
    { id: 't3', skillId: 'skill-python-algo', subskillId: 'sub-py-trees', objectiveId: 'obj-2' },
    context
  );
  assert.equal(lockedObjCheck.eligible, false);
  assert.ok(lockedObjCheck.blockingIds.includes('sub-py-arrays'));
  assert.ok(lockedObjCheck.blockingIds.includes('obj-1'));
});

test('Phase 4.3: Available Time Budget, Safety Buffer, Task Deferral & Review Crowding Cap', () => {
  const config = {
    collegeDays: ['Saturday', 'Tuesday', 'Thursday'],
    collegeStart: '06:00',
    collegeEnd: '18:00',
    sleepHours: 7.5,
    mealsAndPrayerHours: 1.5,
    otherCommitmentsHours: 1.0,
    bufferRatio: 0.2,
    maxCollegeDayWorkloadMin: 95,
    maxDailyWorkloadMin: 300,
  };

  // Tuesday 2026-10-13 is a College Day
  const collegeDayBudget = calculateAvailableTimeAndBuffers(config, '2026-10-13', 7, []);
  assert.equal(collegeDayBudget.isCollegeDay, true);
  assert.equal(collegeDayBudget.collegeHours, 12);
  assert.ok(collegeDayBudget.bufferMin >= 15, 'Must reserve at least 15m safety buffer');
  assert.ok(collegeDayBudget.schedulableWorkMin <= 95, 'Must respect college day workload ceiling');

  // Test Task Selection, Review Crowding Cap, and Budget Deferral
  const candidates = [
    { id: 'c-rev-1', title: 'مراجعة بطاقات 1', category: 'Reviews', isOverdueReview: true, plannedDurationMin: 25, priorityScore: 92 },
    { id: 'c-rev-2', title: 'مراجعة بطاقات إضافية 2', category: 'Reviews', isOverdueReview: true, plannedDurationMin: 30, priorityScore: 90 },
    { id: 'c-prim-1', title: 'تطبيق خوارزميات أساسي', category: 'Primary', plannedDurationMin: 45, priorityScore: 88 },
    { id: 'c-sec-1', title: 'تدريب إضافي طويل', category: 'Secondary', plannedDurationMin: 60, priorityScore: 70 },
  ];

  const selection = selectAndDeferTasks(candidates, collegeDayBudget);
  assert.ok(selection.plannedWorkloadMin <= collegeDayBudget.schedulableWorkMin);
  assert.ok(
    selection.selectedTasks.some((t) => t.id === 'c-prim-1'),
    'Primary foundational work must not be crowded out by excessive reviews'
  );
  assert.ok(
    selection.deferredTasks.some((d) => d.id === 'c-rev-2' && d.limitingConstraint === 'REVIEW_CROWDING_CAP'),
    'Excessive review task must be deferred with REVIEW_CROWDING_CAP reason'
  );
  assert.ok(
    selection.deferredTasks.some((d) => d.id === 'c-sec-1'),
    'Task exceeding safe daily time budget must be deferred with explicit reason'
  );
});

test('Phase 4.4: Time-Block Conflict Detection & Internal Calendar Assignment', async () => {
  const overlappingBlocks = [
    { id: 'b1', date: '2026-10-14', title: 'محاضرة صباحية', startTime: '09:00', endTime: '11:00' },
    { id: 'b2', date: '2026-10-14', title: 'جلسة عمل عميق متداخلة', startTime: '10:30', endTime: '12:00' },
    { id: 'b3', date: '2026-10-14', title: 'جلسة مسائية مستقلة', startTime: '14:00', endTime: '15:00' },
  ];

  const check = detectTimeBlockConflicts(overlappingBlocks);
  assert.equal(check.hasConflicts, true);
  assert.equal(check.conflicts.length, 1);
  assert.equal(check.conflicts[0].overlapWindow, '10:30–11:00');
});

test('Phase 4.5: Full Execution Lifecycle, Timer Integration, Adaptive Rescheduling (No Workload Doubling), Weekly Distribution & Backup/Restore', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true, initialDate: '2026-10-14' });
  const { schedulerEngine, timerEngine, skillEngine, backupEngine } = sys.engines;

  const view = await schedulerEngine.getDailyExecutionView('2026-10-14', 7);
  assert.ok(view.tasks.length >= 2, 'Should generate ordered daily tasks');
  assert.ok(view.excludedBlockedTasks.length >= 1, 'Should explicitly report prerequisite-blocked tasks');
  assert.equal(view.conflictCheck.hasConflicts, false, 'Auto-generated day time blocks must be conflict-free');

  const firstTask = view.tasks[0];
  const secondTask = view.tasks[1];

  // 1. Start Task Execution -> integrates with PersistentTimerEngine & transitions to in_progress
  const started = await schedulerEngine.startTaskExecution(firstTask.id, 1000000);
  assert.equal(started.status, 'in_progress');
  assert.equal(started.executionState, 'in_progress');
  const tState = await timerEngine.getState();
  assert.equal(tState.status, 'running');
  assert.equal(tState.taskId, firstTask.id);

  // 2. Partially Complete first task (50%) -> creates continuation task tomorrow without doubling workload
  const partialRes = await schedulerEngine.partiallyCompleteTaskExecution(firstTask.id, {
    completionPct: 50,
    actualDurationMin: 20,
    energy: 6,
  });
  assert.equal(partialRes.task.status, 'partially_completed');
  assert.equal(partialRes.continuationTask.date, '2026-10-15');
  assert.ok(
    partialRes.continuationTask.plannedDurationMin <= firstTask.plannedDurationMin,
    'Continuation task must only schedule remaining/stepped-down duration, never doubling'
  );

  // 3. Skip second task twice -> triggers root-cause diagnosis & micro-session step-down (<= 25m)
  await sys.db.put('tasks', { ...secondTask, skipCount: 1 });
  const skipRes = await schedulerEngine.skipTaskExecution(secondTask.id, {
    skipReason: 'المهمة طويلة وصعبة بعد يوم مرهق',
    energy: 4,
    difficulty: 9,
  });
  assert.equal(skipRes.task.status, 'skipped');
  assert.ok(skipRes.diagnosis.diagnosedCauses.some((c) => c.includes('REPEATED_MISS') || c.includes('DIFFICULTY_SPIKE')));
  assert.ok(
    skipRes.rescheduledTask.plannedDurationMin <= 25,
    'Repeatedly skipped task must be stepped down into a 25m micro-session tomorrow'
  );

  // 4. Verify tomorrow's plan does NOT blindly double the daily workload ceiling
  const tomorrowPlan = await schedulerEngine.generateSmartDailyPlan('2026-10-15', 7, {
    forceRegenerate: true,
  });
  assert.ok(
    tomorrowPlan.plannedWorkloadMin <= tomorrowPlan.budget.schedulableWorkMin,
    `Tomorrow's planned workload (${tomorrowPlan.plannedWorkloadMin}m) must never exceed tomorrow's safe ceiling (${tomorrowPlan.budget.schedulableWorkMin}m)`
  );

  // 5. Verify Failed Test -> Remediation Task Prioritization on Next Schedule
  await skillEngine.recordTestAttempt({
    skillId: 'skill-python-algo',
    subskillId: 'sub-py-arrays',
    score: 52,
    accuracy: 50,
    evidence: 'Failed sliding window boundary check',
  });
  const regenWithError = await schedulerEngine.generateSmartDailyPlan('2026-10-15', 7, {
    forceRegenerate: true,
  });
  assert.ok(
    regenWithError.tasks.some((t) => t.category === 'Remediation' || t.isCorrective),
    'Unresolved test failure must surface a high-priority Remediation task in the next schedule'
  );

  // 6. Test Overload & Sleep Protection validator
  const overloadReport = validateWorkloadAndRecovery(
    [
      { id: 't1', status: 'ready', category: 'Primary', plannedDurationMin: 200 },
      { id: 't2', status: 'ready', category: 'Secondary', plannedDurationMin: 180 },
    ],
    { schedulableWorkMin: 240, sleepHours: 5.5 },
    { sleepHours: 5.5 }
  );
  assert.equal(overloadReport.isOverloaded, true);
  assert.equal(overloadReport.sleepProtected, false);
  assert.ok(overloadReport.warnings.length >= 2);

  // 7. Test Weekly Plan Distribution across 7 days
  const weekly = await schedulerEngine.generateWeeklyPlan('2026-10-14');
  assert.equal(weekly.days.length, 7);
  assert.ok(weekly.collegeDaysCount >= 2 && weekly.focusDaysCount >= 3);

  // Verify work is distributed and not identical across all 7 days
  const themes = new Set(weekly.days.map((d) => d.dayTheme));
  assert.ok(themes.size >= 3, 'Weekly plan must distribute themes/skills rather than copying one day 7 times');

  // 8. Complete a task today, then regenerate today's plan -> verify completed task and execution_history are preserved!
  const beforeRegen = await schedulerEngine.getDailyExecutionView('2026-10-14', 7);
  await schedulerEngine.completeTaskExecution(beforeRegen.tasks[0].id, {
    actualDurationMin: 40,
    outcome: 'Preserved completed work',
  });

  const afterRegen = await schedulerEngine.generateSmartDailyPlan('2026-10-14', 7, {
    forceRegenerate: true,
  });
  assert.ok(
    afterRegen.tasks.some((t) => t.status === 'completed'),
    'Regenerating daily plan must NEVER delete completed tasks'
  );
  const histAfterRegen = await sys.db.queryByField('execution_history', 'date', '2026-10-14');
  assert.ok(histAfterRegen.length >= 1, 'Regenerating plan must preserve execution_history');

  // 9. Verify Backup & Restore compatibility across all stores
  const backup = await backupEngine.exportBackup();
  assert.ok(backup.schemaVersion >= 4);
  assert.ok(backup.stores.time_blocks.length >= 3);
  assert.ok(backup.stores.weekly_plans.length >= 1);
  assert.ok(backup.stores.execution_history.length >= 1);

  await sys.db.clearAll();
  const restored = await backupEngine.restoreBackup(backup);
  assert.equal(restored.restoredCount, backup.totalRecords);
});
