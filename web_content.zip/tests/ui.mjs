import { build } from 'esbuild';
await build({ entryPoints: ['tests/ui.test.tsx'], bundle: true, platform: 'node', format: 'esm', jsx: 'automatic', outfile: 'tests/.out/ui.mjs', logLevel: 'error', external: ['react', 'react-dom'] });
await import('./.out/ui.mjs');
