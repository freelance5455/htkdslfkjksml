"""Klávesové zkratky (T, S, Caps Lock) a spodní lišta:  python3 -I tests/ui_keys.py"""
import glob, json
from playwright.sync_api import sync_playwright
exe = (glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome') or [None])[0]
SH = '/home/claude/BubbleDefence/tests/shots/'
errs, results = [], []
def check(n, c, x=''): results.append(bool(c)); print(('OK   ' if c else 'FAIL ') + n + (' ' + str(x) if x != '' else ''))
LEVEL = {'w': 12, 'h': 10, 'spawns': [{'side': 'L', 'pos': 8, 'len': 4}], 'exit': {'orb': [[19, 9], [20, 9], [19, 10], [20, 10]]},
         'rocks': [[10, 4, 1], [11, 4, 1], [10, 5, 1], [11, 5, 1]], 'walls': [[14, y] for y in range(0, 10)] + [[14, y] for y in range(12, 20)],
         'towers': [{'type': 'normal', 'x': 4, 'y': 4}], 'lives': 999, 'gold': 321, 'waves': 10, 'hp': 2, 'allowed': ['normal', 'ghost']}
LEVEL['waves'] = 12
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=exe, args=['--no-sandbox'])
    pg = b.new_page(viewport={'width': 1280, 'height': 800})
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type in ('error', 'warning') and 'willReadFrequently' not in m.text else None)
    pg.goto('file:///home/claude/BubbleDefence/index.html'); pg.wait_for_selector('.content:not(.hidden) .intro')
    pg.click('text=Nová lokální hra'); pg.wait_for_selector('.content:not(.hidden) .menu'); pg.wait_for_timeout(300)
    pg.click('.mi:has-text("Editor")'); pg.click('.lcard.add'); pg.wait_for_selector('.edv .ed-cv'); pg.wait_for_timeout(300)
    pg.evaluate("(L=>{const l=BD.store.profile.editor.levels[0]; Object.assign(l, L); BD.debugEditor.buildMasks(); BD.debugEditor.changed(true);})(%s)" % json.dumps(LEVEL))
    pg.click('.smap-head .btn.primary'); pg.wait_for_selector('.gv canvas'); pg.wait_for_timeout(500)
    G = lambda js: pg.evaluate("(()=>{const g=BD.debug.game; return %s})()" % js)
    key = lambda code, key, caps=False, shift=False: pg.evaluate("([c,k,cp,sh])=>window.dispatchEvent(new KeyboardEvent('keydown',{code:c,key:k,modifierCapsLock:cp,shiftKey:sh,bubbles:true}))", [code, key, caps, shift])
    check('T vybere věž Základna k postavení', (key('KeyT', 't'), pg.evaluate('BD.debug.shop.value'))[1] == 'base')
    key('KeyT', 't'); check('druhé T výběr zruší', pg.evaluate('BD.debug.shop.value') is None)
    key('KeyT', 'T', caps=True); check('s Caps Lockem T funguje taky', pg.evaluate('BD.debug.shop.value') == 'base')
    check('Caps Lock se rozpozná (v.caps)', pg.evaluate('BD.debug.v.caps') is True)
    key('KeyT', 't', caps=False); pg.evaluate('BD.debug.shop.value = null')
    check('bez Caps Locku v.caps = false', pg.evaluate('BD.debug.v.caps') is False)
    key('Digit1', '+'); check('česká klávesnice: Digit1 ('+') vybere první věž', pg.evaluate('BD.debug.shop.value') == 'base')
    pg.evaluate("(()=>{const g=BD.debug.game; g.gold=500; const t=g.place('base',8,2); BD.debug.tap({cell:[8,2],pos:[8,2]});})()"); pg.wait_for_timeout(200)
    n0 = G('g.towers.length'); key('KeyS', 's'); pg.wait_for_timeout(100)
    check('S prodá vybranou věž', G('g.towers.length') == n0 - 1, (n0, G('g.towers.length')))
    pg.evaluate("(()=>{const g=BD.debug.game; g.place('base',8,2); BD.debug.tap({cell:[8,2],pos:[8,2]});})()"); pg.wait_for_timeout(100)
    pg.evaluate("window.dispatchEvent(new KeyboardEvent('keydown',{code:'KeyS',key:'s',ctrlKey:true,bubbles:true}))")
    check('Ctrl+S věž neprodá', G('g.towers.length') == n0)
    key('KeyS', 'S', caps=True); check('S s Caps Lockem prodá taky', G('g.towers.length') == n0 - 1)
    # spodní lišta
    check('lišta je zatím schovaná (není v DOM)', pg.locator('.dock').count() == 0)
    pg.evaluate('BD.debug.dock.enabled = true'); pg.wait_for_timeout(300)
    play = pg.locator('.play').bounding_box(); dk = pg.locator('.dock').bounding_box()
    bl = pg.locator('.belt').bounding_box()
    check('zapnutá lišta je široká mezi sloupci (od levého sloupce k pásu vln)', abs(dk['x'] - play['x']) < 2 and abs(dk['x'] + dk['width'] - bl['x']) < 3, (dk['x'], dk['width'], bl['x']))
    check('zasunutá lišta je pod okrajem (vidět jen ouško)', dk['y'] >= play['y'] + play['height'] - 2, (dk['y'], play['y'] + play['height']))
    check('ouško je vidět', pg.locator('[data-act=dock-toggle]').is_visible())
    pg.click('[data-act=dock-toggle]'); pg.wait_for_timeout(500)
    dk2 = pg.locator('.dock').bounding_box(); pg.screenshot(path=SH + 'dock_open.png')
    check('po kliknutí lišta vyjede', dk2['y'] < dk['y'] - 100 and dk2['y'] + dk2['height'] <= play['y'] + play['height'] + 2, (dk['y'], dk2['y']))
    pg.click('[data-act=dock-toggle]'); pg.wait_for_timeout(500)
    check('a zase zajede', pg.locator('.dock').bounding_box()['y'] >= play['y'] + play['height'] - 2)
    b.close()
print('\nvýsledek: %d/%d' % (sum(results), len(results)), '| chyby:', errs or 'žádné')
