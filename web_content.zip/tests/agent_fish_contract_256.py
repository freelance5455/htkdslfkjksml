from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'app/agent.php').read_text()
assert "agents/[A-Za-z0-9_-]{1,160}/config" in s
assert "agents/[A-Za-z0-9_-]{1,160}/publish" in s
assert "sessions/[A-Za-z0-9_-]{1,160}/end" in s
assert "knowledge-sources" in s
assert "duration_seconds" in s and "agent_conversation_usd_per_minute" in s
js=(ROOT/'assets/agent-chat.js').read_text()
assert "@fishaudio/agent-client@0.3.0" in js
assert "sessionToken:s.session" in js
print('Fish Audio Agent route, SDK and measured usage contract checks passed.')
