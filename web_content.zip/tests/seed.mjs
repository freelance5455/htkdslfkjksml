// Test-only helper: fills the open company with demo-like data through the public store API.
export const SEED = `(function(){
    var UI = AN_UI, J = AN_J, s = UI.store, ctx = UI.ctx, co = s.company(ctx), today = s.today(), ago = function (n) { return J.addDaysIso(today, -n); }, ahead = function (n) { return J.addDaysIso(today, n); };
    var big = co.baseCurrency === "IRR" || co.baseCurrency === "IRT" || co.baseCurrency === "JPY", unit = big ? 1 : 100; /* minor units per 1 major unit */
    var M = function (major) { return major * unit; };
    var k = s.postEntry(ctx, { date: ago(55), memo: "Test Capital", lines: [{ accountId: co.sys.BANK, debit: M(big ? 500000000 : 50000) }, { accountId: co.sys.CAPITAL, credit: M(big ? 500000000 : 50000) }] }, { idemKey: "seed-cap" });
    var c1 = s.saveContact(ctx, { name: "Test C1", type: "customer", email: "info@example.com" }), c2 = s.saveContact(ctx, { name: "Test C2", type: "customer" }), v1 = s.saveContact(ctx, { name: "Test V1", type: "supplier" });
    var mk = function (kind, c, d, due, desc, qty, price) { var dr = s.saveInvoiceDraft(ctx, { kind: kind, contactId: c.id, date: d, dueDate: due, lines: [{ desc: desc, qty: qty, unitPrice: M(price) }] }); return s.postInvoice(ctx, dr.id, { idemKey: "seed-" + dr.id }).invoice; };
    var i1 = mk("sale", c1, ago(40), ago(10), "Test S1", 1000, big ? 120000000 : 1200), i2 = mk("sale", c2, ago(12), ahead(18), "Test S2", 2000, big ? 45000000 : 450), i3 = mk("sale", c1, ago(3), ahead(27), "Test S3", 1000, big ? 80000000 : 800);
    var b1 = mk("purchase", v1, ago(30), ahead(0), "Test B1", 1000, big ? 60000000 : 600);
    s.postPayment(ctx, { kind: "receipt", contactId: c1.id, date: ago(25), amount: i1.total, bankAccountId: co.sys.BANK, ref: "TRX-1001", allocations: [{ invoiceId: i1.id, amount: i1.total }] }, { idemKey: "seed-p1" });
    var half = Math.floor(i2.total / 2); s.postPayment(ctx, { kind: "receipt", contactId: c2.id, date: ago(5), amount: half, bankAccountId: co.sys.BANK, allocations: [{ invoiceId: i2.id, amount: half }] }, { idemKey: "seed-p2" });
    s.postEntry(ctx, { date: ago(20), memo: "Test Rent", lines: [{ accountId: "A5200", debit: M(big ? 30000000 : 300) }, { accountId: co.sys.BANK, credit: M(big ? 30000000 : 300) }] }, { idemKey: "seed-rent" });
  })()`;
