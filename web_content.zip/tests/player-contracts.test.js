import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState } from '../src/store.js';
import { getPlayerContractDemand, proposePlayerContract, acceptPlayerCounter, signPlayerContract, validatePlayerContracts } from '../src/player-contracts.js';

function stateWithClub() { return createInitialState(); }

test('la demande contractuelle est calculée à partir du niveau, du budget et du moral', () => {
  const s = stateWithClub();
  const p = s.divisions[0].clubs[0].damistes[0];
  const demand = getPlayerContractDemand(s, p.id);
  assert.ok(demand.wage > 0);
  assert.equal(demand.role, 'rotation');
  s.management.relations.playerMorale[p.id] = 20;
  assert.ok(getPlayerContractDemand(s, p.id).wage > demand.wage);
});

test('un contrat ne se signe qu’après acceptation du damiste et engage la masse salariale', () => {
  const s = stateWithClub();
  const club = s.divisions[0].clubs[0];
  const player = club.damistes[0];
  const demand = getPlayerContractDemand(s, player.id);
  const negotiation = proposePlayerContract(s, player.id, demand);
  assert.equal(negotiation.status, 'player-accepted');
  assert.throws(() => signPlayerContract(s, 'unknown'));
  const contract = signPlayerContract(s, negotiation.id);
  assert.equal(contract.status, 'active');
  assert.equal(club.payrollCommitment, demand.wage);
  assert.equal(s.management.contractNegotiations[0].status, 'signed');
  assert.equal(signPlayerContract(s, negotiation.id).wage, demand.wage);
  assert.equal(club.payrollCommitment, demand.wage);
  assert.equal(validatePlayerContracts(s), true);
});

test('le damiste formule une contre-proposition et le manager doit la valider', () => {
  const s = stateWithClub();
  const p = s.divisions[0].clubs[0].damistes[0];
  const demand = getPlayerContractDemand(s, p.id);
  const negotiation = proposePlayerContract(s, p.id, { wage: 1, bonus: 0, duration: 1, role: 'rotation' });
  assert.equal(negotiation.status, 'player-countered');
  assert.throws(() => signPlayerContract(s, negotiation.id));
  acceptPlayerCounter(s, negotiation.id);
  assert.equal(signPlayerContract(s, negotiation.id).wage, demand.wage);
});

test('une négociation simultanée du même damiste est bloquée', () => {
  const s = stateWithClub();
  const p = s.divisions[0].clubs[0].damistes[0];
  proposePlayerContract(s, p.id, { wage: 1, bonus: 0, duration: 1, role: 'rotation' });
  assert.throws(() => proposePlayerContract(s, p.id, { wage: 1, bonus: 0, duration: 1, role: 'rotation' }));
});

test('la signature est refusée si la masse salariale totale dépasse le budget', () => {
  const s = stateWithClub();
  const club = s.divisions[0].clubs[0];
  const player = club.damistes[0];
  const demand = getPlayerContractDemand(s, player.id);
  club.payrollCommitment = club.budget;
  const negotiation = proposePlayerContract(s, player.id, demand);
  assert.equal(negotiation.status, 'player-accepted');
  assert.throws(() => signPlayerContract(s, negotiation.id), /dépasserait le budget/);
  assert.equal(player.contract, undefined);
});
