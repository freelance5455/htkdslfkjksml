import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState, validateState } from '../src/store.js';
import { createManagerProfile, getReputationTier, updateManagerReputation, getCareerGate, validateCareerProfile } from '../src/career.js';

test('profil manager : création, mode, galaxie et réputation de départ', () => {
  const s = createInitialState();
  const manager = createManagerProfile({ firstName: 'Awa', lastName: 'Kone', galaxy: s.world.galaxies[0].name, sex: 'Femme', reputation: 'Locale', mode: 'club', clubId: s.divisions[0].clubs[0].id }, s);
  assert.equal(manager.displayName, 'Awa Kone');
  assert.equal(manager.reputation, 'Locale');
  assert.equal(s.career.mode, 'club');
  assert.equal(validateCareerProfile(s), true);
  assert.equal(validateState(s), true);
});

test('profil invalide refusé sans écraser la carrière', () => {
  const s = createInitialState();
  assert.throws(() => createManagerProfile({ firstName: '', lastName: 'X', galaxy: 'Inconnue', mode: 'club', sex: 'Homme', clubId: s.divisions[0].clubs[0].id }, s));
  assert.equal(s.career.manager, null);
});

test('réputation évolue avec seuils et plafonds', () => {
  const s = createInitialState();
  createManagerProfile({ firstName: 'A', lastName: 'B', galaxy: s.world.galaxies[0].name, mode: 'club', sex: 'Homme', clubId: s.divisions[0].clubs[0].id }, s);
  assert.equal(updateManagerReputation(s, 28, 'Titre').reputation, 'Locale');
  assert.equal(updateManagerReputation(s, 30, 'Titre majeur').reputation, 'Continentale');
  assert.equal(updateManagerReputation(s, 100, 'Carrière exceptionnelle').score, 100);
  assert.equal(getReputationTier(-5), 'Inconnu');
});

test('boucle de carrière signale un match personnel à la date prévue', () => {
  const s = createInitialState();
  const f = { id: 'mine', home: s.userClubId, away: 'opponent', status: 'scheduled' };
  s.calendar.fixtures.push(f);
  s.calendar.competitionEvents.push({ id: 'event-mine', absoluteDay: 1, fixtureIds: ['mine'] });
  assert.equal(getCareerGate(s).action, 'ALLER AU MATCH');
  s.management.inbox.push({ id: 'required', status: 'unread', requiresResponse: true });
  assert.equal(getCareerGate(s).action, 'RÉPONSE REQUISE');
});

test('mode sans emploi démarre réellement sans club', () => {
  const s = createInitialState();
  createManagerProfile({ firstName: 'M', lastName: 'N', galaxy: s.world.galaxies[1].name, mode: 'unemployed', sex: 'Non précisé' }, s);
  assert.equal(s.userClubId, null);
  assert.equal(s.career.manager.clubId, null);
});

test('message du conseil bloque la progression jusqu’à la réponse', async () => {
  const { addCareerMessage, replyToCareerMessage } = await import('../src/relations.js');
  const s = createInitialState();
  addCareerMessage(s, { id: 'board-required', type: 'board', from: 'Conseil', subject: 'Décision attendue', body: 'Répondre.', choices: [{ id: 'yes', label: 'Accepter', effects: {} }] });
  assert.equal(s.management.inbox[0].requiresResponse, true);
  assert.equal(getCareerGate(s).action, 'RÉPONSE REQUISE');
  replyToCareerMessage(s, 'board-required', 'yes');
  assert.equal(getCareerGate(s).action, 'CONTINUER');
});

test('une proposition d’emploi reçue bloque la progression du manager sans emploi', async () => {
  const { generateJobMarket, applyForJob, processJobApplications } = await import('../src/career.js');
  const s = createInitialState();
  createManagerProfile({ firstName: 'M', lastName: 'N', galaxy: s.world.galaxies[0].name, mode: 'unemployed', sex: 'Homme', reputation: 'Mondiale' }, s);
  const [offer] = generateJobMarket(s);
  const application = applyForJob(s, offer.id);
  assert.equal(getCareerGate(s).action, 'CONTINUER');
  processJobApplications(s);
  assert.equal(getCareerGate(s).action, 'OFFRE À TRAITER');
  assert.equal(getCareerGate(s).applicationId, application.id);
});
