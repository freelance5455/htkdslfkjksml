'use strict';
const assert = require('node:assert/strict');
const http = require('node:http');
const { spawn } = require('node:child_process');
const port = 3187;
const child = spawn(process.execPath, ['server.js'], { env: { ...process.env, PORT: String(port), GEMINI_API_KEY: '', OPENAI_API_KEY: '' }, stdio: 'ignore' });
const wait = ms => new Promise(r => setTimeout(r, ms));
async function get(path) {
  const res = await fetch(`http://127.0.0.1:${port}${path}`);
  return { status: res.status, body: await res.json() };
}
(async () => {
  try {
    let ready = false;
    for (let i=0; i<40; i++) { try { await fetch(`http://127.0.0.1:${port}/health`); ready=true; break; } catch { await wait(150); } }
    assert.equal(ready, true, 'server should start');
    const health = await get('/health');
    assert.equal(health.status, 200);
    assert.equal(health.body.ok, true);
    assert.equal(health.body.version, 'phone-manager-v13');
    const status = await get('/api/status');
    assert.equal(status.status, 200);
    assert.equal(status.body.server, true);
    assert.equal(status.body.aiConfigured, false);
    const integrations = await get('/api/integrations/status');
    assert.equal(integrations.status, 200);
    assert.equal(integrations.body.github.configured, false);
    assert.equal(integrations.body.render.configured, false);
    assert.equal(integrations.body.github.connected, false);
    assert.equal(integrations.body.render.connected, false);
    const discovered = await get('/api/manager/providers');
    assert.equal(discovered.status, 200);
    assert.equal(discovered.body.count, 0);
    const providerCheck = await fetch(`http://127.0.0.1:${port}/api/manager/provider-check`, { method:'POST' });
    assert.equal(providerCheck.status, 503, 'provider check must report missing API key');
    const providerBody = await providerCheck.json();
    assert.equal(providerBody.code, 'AI_NOT_CONFIGURED');
    const tools = await get('/api/tools');
    assert.equal(tools.status, 200);
    assert.ok(tools.body.tools.some(t => t.id === 'project_inspection'));
    const inspect = await fetch(`http://127.0.0.1:${port}/api/manager/inspect`, { method:'POST' });
    assert.equal(inspect.status, 200);
    const inspectBody = await inspect.json();
    assert.ok(inspectBody.checks.some(c => c.name === 'AI provider'));
    const plan = await fetch(`http://127.0.0.1:${port}/api/manager/plan`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({goal:'اختبار خطة',tasks:[]}) });
    assert.equal(plan.status, 503, 'planning must clearly report missing provider key');
    const planBody = await plan.json();
    assert.equal(planBody.code, 'AI_NOT_CONFIGURED');
    const logs = await get('/api/manager/logs');
    assert.equal(logs.status, 200);
    const chat = await fetch(`http://127.0.0.1:${port}/api/chat`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({message:'اختبار'}) });
    assert.equal(chat.status, 503, 'chat must clearly report missing provider key');
    const chatBody = await chat.json();
    assert.equal(chatBody.code, 'AI_NOT_CONFIGURED');
    const badLink = await fetch(`http://127.0.0.1:${port}/api/link/execute`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({action:'self-link'}) });
    assert.equal(badLink.status, 401, 'self-link must reject missing control token');
    const page = await fetch(`http://127.0.0.1:${port}/`);
    assert.equal(page.status, 200);
    const pageText = await page.text();
    assert.match(pageText, /مديرك الشخصي الذكي/);
    assert.equal((pageText.match(/class="bottomnav"/g) || []).length, 1, 'only one navigation bar should exist');
    assert.equal((pageText.match(/class="tabs"/g) || []).length, 0, 'duplicate top navigation should be removed');
    console.log('Nova smoke tests passed: health, status, AI provider discovery, tools, project inspection, unconfigured planning/chat, protected self-link, home page.');
  } catch (e) { console.error(e); process.exitCode=1; }
  finally { child.kill('SIGTERM'); }
})();
