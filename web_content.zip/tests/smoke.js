// Test de fumée : exécute les scripts avec un faux DOM et une API simulée (fetch mocké, aucun réseau).
const fs = require('fs'), path = require('path'), vm = require('vm');
const read = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
let fail = 0; const ok = (c, m) => { console.log((c ? 'OK    ' : 'ÉCHEC ') + m); if (!c) fail++; };
const mk = id => ({ id, innerHTML: '', value: '', style: {}, classList: { on: false, add() { this.on = true; }, remove() { this.on = false; } } });
const els = {}, extra = {};
['#m', '#st', '#nav', '#det', '#toast', '#ls', '#cp', '#cq', '#ao', '#ac', '#am'].forEach(s => els[s] = mk(s));
const store = {};
const doc = { documentElement: { setAttribute(k, v) { this[k] = v; } }, hidden: false, body: { appendChild(e) { extra['#' + e.id] = e; } }, createElement: () => mk(''), querySelector: s => els[s] || extra[s] || null };
const kl = Array.from({ length: 60 }, (_, i) => [i, '10', '12', '9', String(10 + i / 10)]);
const tick = ['BTC', 'ETH', 'BNB'].map((s, i) => ({ symbol: s + 'USDT', lastPrice: '100', priceChangePercent: String(i - 1), highPrice: '110', lowPrice: '90', quoteVolume: '1000' }));
const ctx = vm.createContext({ document: doc, console, Date, JSON, Math, Array, Object, Number, String, Promise, encodeURIComponent, AbortController,
  localStorage: { getItem: k => k in store ? store[k] : null, setItem: (k, v) => { store[k] = String(v); } },
  fetch: async u => ({ ok: true, status: 200, json: async () => /klines/.test(u) ? kl : tick }),
  setInterval() {}, clearInterval() {}, setTimeout, clearTimeout });
ctx.window = ctx; ctx.addEventListener = () => {};
// Exécute les <script> de index.html dans l'ordre du document, comme un navigateur (inline compris).
for (const m of read('index.html').matchAll(/<script(?:\s+src="([^"]+)")?\s*>([\s\S]*?)<\/script>/g)) {
  try { vm.runInContext(m[1] ? read(m[1]) : m[2], ctx, { filename: m[1] || 'script inline' }); }
  catch (e) { ok(false, 'chargement de ' + (m[1] || 'script inline') + ' : ' + e.message); }
}
const run = c => vm.runInContext(c, ctx);
(async () => {
  await new Promise(r => setTimeout(r, 80));
  ok((els['#nav'].innerHTML.match(/<button/g) || []).length === 3, 'barre du bas : 3 boutons');
  ok(/id="hcv"/.test(els['#m'].innerHTML), "graphique présent sur l'accueil");
  ok(/BTC/.test(els['#ls'].innerHTML), 'liste de marché rendue depuis les données mockées');
  ok(extra['#wl'] && extra['#wl'].classList.on && /Crypto Max PRO/.test(extra['#wl'].innerHTML), 'bienvenue affichée au premier lancement');
  run('welcome(3)'); ok(/☰/.test(extra['#wl'].innerHTML), "dernière étape de bienvenue (menu)");
  run('endWelcome()'); ok(store.welcomed === '1' && !extra['#wl'].classList.on, 'bienvenue fermée et mémorisée');
  run('menu()'); const m = extra['#mn'].innerHTML;
  ok(/go\('rewards'\)/.test(m) && /go\('alerts'\)/.test(m) && /go\('settings'\)/.test(m) && /welcome\(0\)/.test(m), 'menu ☰ : récompenses, alertes, réglages, guide');
  run("go('alerts')"); ok(/id="as"/.test(els['#m'].innerHTML), 'navigation vers Alertes depuis le menu');
  run("setLang('en')"); ok(store.lang === 'en', 'changement de langue');
  run("setTheme('light')"); ok(doc.documentElement['data-theme'] === 'light' && store.theme === 'light', 'thème jour appliqué');
  run('toggleTheme()'); ok(doc.documentElement['data-theme'] === 'dark', 'bascule jour/nuit');
  run("setTheme('auto')"); ok(['light', 'dark'].includes(doc.documentElement['data-theme']), 'thème auto résolu');
  run("go('settings')"); ok(/setTheme\(this\.value\)/.test(els['#m'].innerHTML), 'sélecteur de thème dans les réglages');
  ok(/html\[data-theme=light\]/.test(fs.readFileSync(path.join(__dirname, '..', 'assets/css/app.css'), 'utf8')), 'feuille de style jour présente');
  run("go('ai')"); await new Promise(r => setTimeout(r, 80));
  ok(/RSI\(14\)/.test(els['#ao'].innerHTML) && /BTC\/USDT/.test(els['#ao'].innerHTML), 'analyse technique affichée (données mockées)');
  ok(/consult\(\)/.test(els['#m'].innerHTML), 'bouton « consulter Claude » présent');
  els['#cq'].value = 'Test question'; run('consult()'); await new Promise(r => setTimeout(r, 30));
  ok(/https:\/\/claude\.ai\/new/.test(els['#cp'].innerHTML) && /Test question/.test(els['#cp'].innerHTML) && /BTC\/USDT/.test(els['#cp'].innerHTML), 'invite générée avec lien claude.ai et analyse');
  ok(!/undefined|NaN|null/.test(run("buildPrompt('')")), "invite sans 'undefined' / 'NaN' / 'null'");
  console.log(fail ? `\n${fail} test(s) en échec` : '\nTests de fumée OK'); process.exit(fail ? 1 : 0);
})();
