"""Studio (celoobrazovkové, dev): příkaz studio, úpravy vlastností, vlny, vzhled z vrstev, hřiště, export/import, zkouška:  python3 -I tests/ui_studio.py"""
import glob, json
from playwright.sync_api import sync_playwright
exe = (glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome') or [None])[0]
SH = '/home/claude/BubbleDefence/tests/shots/'
errs, results = [], []
def check(n, c, x=''): results.append(bool(c)); print(('OK   ' if c else 'FAIL ') + n + (' ' + str(x) if x != '' else ''))
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=exe, args=['--no-sandbox'])
    ctx = b.new_context(viewport={'width': 1440, 'height': 860}, accept_downloads=True); ctx.grant_permissions(['clipboard-read', 'clipboard-write'])
    pg = ctx.new_page()
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type in ('error', 'warning') and 'willReadFrequently' not in m.text else None)
    pg.goto('file:///home/claude/BubbleDefence/index.html'); pg.wait_for_selector('.content:not(.hidden) .intro')
    check('Studio je na začátku vypnuté a nic nepřepisuje', pg.evaluate('BD.studio.enabled') is False)
    pg.click('text=Nová lokální hra'); pg.wait_for_selector('.content:not(.hidden) .menu'); pg.wait_for_timeout(300)
    check('v menu není položka Studio', pg.locator('.mi:has-text("Studio")').count() == 0)
    pg.keyboard.type('terminal', delay=40); pg.wait_for_timeout(200)
    pg.keyboard.press('Backquote'); pg.wait_for_timeout(350)
    pg.keyboard.type('dev'); pg.keyboard.press('Enter'); pg.wait_for_timeout(150)
    check('starý příkaz dev už Studio nezapíná', pg.evaluate('BD.studio.enabled') is False)
    pg.keyboard.type('studio'); pg.keyboard.press('Enter'); pg.wait_for_timeout(300)
    check('příkaz studio zapne Studio', pg.evaluate('BD.studio.enabled') is True)
    pg.keyboard.press('Backquote'); pg.wait_for_timeout(350)
    check('v menu je položka Studio', pg.locator('.mi:has-text("Studio")').count() == 1)
    pg.click('.mi:has-text("Studio")'); pg.wait_for_selector('.stv'); pg.wait_for_timeout(500)
    bb = pg.locator('.stv').bounding_box()
    check('Studio je přes celou obrazovku (ne okno)', bb['width'] >= 1430 and bb['height'] >= 850, bb)
    check('seznam nepřátel obsahuje vestavěné', pg.locator('.stu-item').count() >= 6)

    # --- vlastnosti ---
    pg.click('[data-panel=props]'); pg.click('.stu-item[data-id=bub]'); pg.wait_for_timeout(200)
    orig_hp = pg.evaluate('BD.studio.original("enemies","bub").hp')
    pg.fill('[data-f=hp]', '55'); pg.locator('[data-f=hp]').blur(); pg.wait_for_timeout(200)
    check('úprava hodnoty se hned projeví v datech hry i uloží', pg.evaluate('BD.systems.enemies.TYPES.bub.hp') == 55 and pg.evaluate('BD.store.profile.studio.items.enemies.bub.patch.hp') == 55)
    pg.click('.stu-f.chg .rst'); pg.wait_for_timeout(150)
    check('↺ vrátí výchozí hodnotu', pg.evaluate('BD.systems.enemies.TYPES.bub.hp') == orig_hp)
    pg.fill('[data-role=stu-newid]', 'mini'); pg.click('[data-act=stu-create]'); pg.wait_for_timeout(250)
    check('nový nepřítel je v datech hry', pg.evaluate('!!BD.systems.enemies.TYPES.mini') and pg.evaluate("BD.systems.enemies.TYPES.mini.waveMode") == 'none')
    check('text při vytvoření je rovnou název (ne „Nový nepřítel“)', pg.evaluate("BD.systems.enemies.TYPES.mini.name") == 'mini' and pg.locator('.stu-item[data-id=mini] .nm').inner_text() == 'mini')
    pg.fill('[data-role=stu-name]', 'Drobeček'); pg.wait_for_timeout(150)
    check('název jde přepsat nahoře v pravém panelu na každé záložce a hned se projeví', pg.evaluate("BD.systems.enemies.TYPES.mini.name") == 'Drobeček' and pg.locator('.stu-item[data-id=mini] .nm').inner_text() == 'Drobeček')
    pg.fill('[data-role=stu-newid]', 'Ledová věž č. 1'); pg.click('[data-act=stu-create]'); pg.wait_for_timeout(200)
    check('název s diakritikou a mezerami: identifikátor se odvodí, název zůstane', pg.evaluate("BD.studio.lastId") == 'ledova_vez_c_1' and pg.evaluate("BD.systems.enemies.TYPES.ledova_vez_c_1.name") == 'Ledová věž č. 1')
    pg.click('.stu-item[data-id=ledova_vez_c_1]'); pg.click('[data-act=stu-del]') if False else None
    pg.click('.stu-item[data-id=mini]'); pg.wait_for_timeout(150)
    pg.fill('[data-f=name]', 'Drobek'); pg.locator('[data-f=name]').blur(); pg.fill('[data-f=r]', '0.15'); pg.locator('[data-f=r]').blur(); pg.fill('[data-f=hp]', '6'); pg.locator('[data-f=hp]').blur()
    pg.click('.stu-item[data-id=tank]'); pg.wait_for_timeout(150)
    pg.fill('[data-f=splitCount]', '5'); pg.locator('[data-f=splitCount]').blur(); pg.select_option('[data-f=splitInto]', 'mini'); pg.wait_for_timeout(200)
    r = pg.evaluate("""(()=>{ const g=new BD.systems.Game(BD.data.presets[0]); g.lives=99; g.waveLeft={1:1}; BD.systems.enemies.spawn(g,'tank',1); g.kill(g.enemies[0]); return [g.enemies.filter(e=>e.alive).length, g.enemies.filter(e=>e.alive)[0].type, g.waveLeft[1]]; })()""")
    check('Těžká se rozpadá na 5 Drobků', r == [5, 'mini', 5], r)

    # --- vlny ---
    pg.click('[data-panel=waves]'); pg.wait_for_timeout(150)
    check('záložka Vlny: vestavěný nepřítel jede podle původního předpisu, pravidla jsou skrytá', pg.locator('[data-f=waveMode]').count() == 1 and pg.locator('[data-f=waveFrom]').count() == 0)
    pg.click('.stu-item[data-id=mini]'); pg.wait_for_timeout(150)
    pg.select_option('[data-f=waveMode]', 'rules'); pg.wait_for_timeout(150)
    check('vlastní pravidla odkryjí pole', pg.locator('[data-f=waveFrom]').count() == 1 and pg.locator('[data-f=levelFrom]').count() == 1)
    pg.fill('[data-f=waveFrom]', '5'); pg.locator('[data-f=waveFrom]').blur(); pg.fill('[data-f=waveEvery]', '3'); pg.locator('[data-f=waveEvery]').blur(); pg.fill('[data-f=waveCount]', '4'); pg.locator('[data-f=waveCount]').blur()
    pg.fill('[data-f=wavePer]', '1'); pg.locator('[data-f=wavePer]').blur(); pg.fill('[data-f=levelFrom]', '10'); pg.locator('[data-f=levelFrom]').blur(); pg.wait_for_timeout(150)
    W = lambda n, lv: pg.evaluate("(()=>{ BD.systems.waves.ctx.levelNo=%d; const q=BD.systems.waves.def(%d).filter(x=>x.type==='mini').length; BD.systems.waves.ctx.levelNo=0; return q; })()" % (lv, n))
    check('před 5. vlnou ani v 6. vlně (každá 3. od 5.) se neobjeví', W(4, 0) == 0 and W(6, 0) == 0 and W(7, 0) == 0)
    check('vlna 5: 4 kusy, vlna 8: 4+3=7, vlna 11: 10', W(5, 0) == 4 and W(8, 0) == 7 and W(11, 0) == 10, (W(5, 0), W(8, 0), W(11, 0)))
    check('levelFrom 10: v 9. levelu nic, v 10. už ano', W(5, 9) == 0 and W(5, 10) == 4 and W(5, 0) == 4)
    pg.click('.stu-item[data-id=bub]'); pg.wait_for_timeout(100); pg.select_option('[data-f=waveMode]', 'none'); pg.wait_for_timeout(150)
    nobub = pg.evaluate("[1,2,3,4,5,6,7].every(n => BD.systems.waves.def(n).every(x => x.type !== 'bub'))")
    check('vestavěný nepřítel jde vyřadit z vln (a prázdné vlny nespadnou)', nobub and pg.evaluate("BD.systems.waves.info(1, 1).count") == 0)
    pg.select_option('[data-f=waveMode]', 'builtin'); pg.wait_for_timeout(100)
    check('a vrátit zpátky', pg.evaluate("BD.systems.waves.def(1).some(x => x.type === 'bub')"))

    # --- vzhled ---
    pg.click('[data-panel=look]'); pg.click('.stu-item[data-id=mini]'); pg.wait_for_timeout(200)
    check('bez vlastního vzhledu nabídne začátek', pg.locator('[data-act=look-from]').count() == 1)
    pg.click('[data-act=look-from]'); pg.wait_for_timeout(300)
    check('vznikl vlastní vzhled z šablony (2 vrstvy) a je v datech hry', pg.locator('.ly').count() == 2 and pg.evaluate('BD.systems.enemies.TYPES.mini.sprite.nodes.length') == 2)
    pg.click('[data-add=star]'); pg.wait_for_timeout(200)
    check('nová vrstva (hvězda) je vybraná a přibyla', pg.locator('.ly.on').count() == 1 and pg.locator('.ly.on:has-text("Hvězda")').count() == 1 and pg.locator('.ly').count() == 3)
    pg.click('[data-add=group]'); pg.wait_for_timeout(100)
    pg.click('[data-add=ring]'); pg.wait_for_timeout(100)
    sp = pg.evaluate('BD.studio.value("enemies","mini","sprite")')
    grp = [n for n in sp['nodes'] if n['type'] == 'group'][0]
    check('nová vrstva se přidá DO vybrané skupiny (hierarchie)', len(grp['children']) == 1 and grp['children'][0]['type'] == 'ring')
    pg.click('.ly-props select >> nth=0'); 
    # animace skupiny
    pg.click('.ly.isgrp'); pg.wait_for_timeout(100)
    pg.locator('.ly-props select.btn').last.select_option('spin'); pg.wait_for_timeout(200)
    check('animace skupiny se uloží', pg.evaluate("BD.studio.value('enemies','mini','sprite').nodes.find(n => n.type === 'group').anim.t") == 'spin')
    # přechod
    pg.click('.ly:has-text("Tělo")'); pg.wait_for_timeout(100)
    pg.locator('.ly-props select.btn').nth(1).select_option('linear'); pg.wait_for_timeout(150)
    check('druh výplně: přechod', pg.evaluate("BD.studio.value('enemies','mini','sprite').nodes.find(n => n.name === 'Tělo').fill.t") == 'linear')
    pg.screenshot(path=SH + 'studio_look.png')
    # rámečky velikosti + podlaha jako ve hře
    pg.click('[data-act=v-guides]') if pg.locator('[data-box]').count() == 0 else None
    check('nabídka rámečků N×N a vlastní velikost', pg.locator('[data-box]').count() >= 5 and pg.evaluate('BD.debugStudio.boxes').__contains__(1))
    pg.click('[data-box="4"]'); pg.fill('[data-role=box-custom]', '20'); pg.locator('[data-role=box-custom]').press('Enter'); pg.wait_for_timeout(200)
    check('rámečky 1, 4 a vlastní 20', sorted(pg.evaluate('BD.debugStudio.boxes')) == [1, 4, 20], pg.evaluate('BD.debugStudio.boxes'))
    pg.click('[data-act=v-guides]'); pg.click('[data-act=v-guides]')
    pg.screenshot(path=SH + 'studio_boxes.png')
    # zoom kolečkem
    cv = pg.locator('[data-role=pv]'); box = cv.bounding_box(); pg.mouse.move(box['x'] + box['width'] / 2, box['y'] + box['height'] / 2)
    z0 = pg.evaluate('BD.debugStudio.view.zoom'); pg.mouse.wheel(0, -600); pg.wait_for_timeout(200); z1 = pg.evaluate('BD.debugStudio.view.zoom')
    check('kolečko přibližuje hřiště', z1 > z0 * 1.5, (z0, z1))
    for _ in range(8): pg.mouse.wheel(0, -600)
    pg.wait_for_timeout(200)
    check('lze se dostat hodně blízko (×30 a víc), strop ×60', 30 <= pg.evaluate('BD.debugStudio.view.zoom') <= 60, pg.evaluate('BD.debugStudio.view.zoom'))
    pg.click('.btn:has-text("Vycentrovat")'); pg.wait_for_timeout(150)
    # klik na plátno vybere vrstvu pod myší; tažení ji posune
    pg.click('[data-act=v-anim]')   # vypne animace, ať stojí
    pg.wait_for_timeout(200)
    pg.click('.ly:has-text("Hvězda")'); pg.wait_for_timeout(100)
    cx0 = box['x'] + box['width'] / 2; cy0 = box['y'] + box['height'] / 2
    pg.mouse.move(cx0, cy0); pg.mouse.down(); pg.mouse.move(cx0 + 60, cy0 + 20, steps=5); pg.mouse.up(); pg.wait_for_timeout(200)
    selid = pg.evaluate('BD.debugStudio.selId')
    nd = pg.evaluate("(() => { const f = BD.render.sprite.find(BD.debugStudio.sp, BD.debugStudio.selId); return [f.node.type, f.node.x, f.node.y]; })()")
    check('klik na plátno vybere nejvyšší vrstvu pod myší a tažení ji posune', nd[0] in ('star', 'circle', 'ellipse', 'ring') and (abs(nd[1]) > 0.01 or abs(nd[2]) > 0.01), nd)
    check('posun je uložený i v datech hry', pg.evaluate("(() => { let r; BD.render.sprite.walk(BD.systems.enemies.TYPES.mini.sprite.nodes, n => { if (n.id === BD.debugStudio.selId) r = [n.x, n.y]; }); return r; })()") == nd[1:])
    pg.keyboard.press('Control+z'); pg.wait_for_timeout(200)
    check('Ctrl+Z vrátí poslední krok', pg.evaluate('BD.debugStudio.undo.length') >= 0)
    pg.screenshot(path=SH + 'studio_zoom.png')

    # --- Shift = posun po osách 45° ---
    pg.click('.ly:has-text("Hvězda")'); pg.wait_for_timeout(100)
    pg.evaluate("(() => { const f = BD.render.sprite.find(BD.debugStudio.sp, BD.debugStudio.selId); f.node.x = 0; f.node.y = 0; BD.debugStudio.commit(); })()"); pg.wait_for_timeout(250)
    box2 = cv.bounding_box(); sx0 = box2['x'] + box2['width'] / 2; sy0 = box2['y'] + box2['height'] / 2
    pg.mouse.move(sx0, sy0); pg.keyboard.down('Shift'); pg.mouse.down(); pg.mouse.move(sx0 + 90, sy0 + 20, steps=6); pg.mouse.up(); pg.keyboard.up('Shift'); pg.wait_for_timeout(200)
    sp2 = pg.evaluate("(() => { const f = BD.render.sprite.find(BD.debugStudio.sp, BD.debugStudio.selId); return [f.node.x, f.node.y, f.node.type]; })()")
    check('Shift při tažení drží osy po 45° (posun jen vodorovně)', abs(sp2[1]) < 0.02 and abs(sp2[0]) > 0.05, sp2)
    # --- drag & drop v seznamu vrstev ---
    names = lambda: pg.evaluate("BD.debugStudio.rows.map(r => r.n.name + ':' + r.depth)")
    before = names()
    pg.locator('.ly:has-text("Hvězda")').drag_to(pg.locator('.ly.isgrp').first, target_position={'x': 40, 'y': 10}); pg.wait_for_timeout(250)
    after = names()
    check('přetažení vrstvy na skupinu ji vloží dovnitř', pg.evaluate("(() => { const g = BD.debugStudio.sp.nodes.find(n => n.type === 'group'); return g.children.some(c => c.name === 'Hvězda'); })()"), after)
    pg.locator('.ly:has-text("Hvězda")').drag_to(pg.locator('.ly:has-text("Tělo")'), target_position={'x': 40, 'y': 20}); pg.wait_for_timeout(250)
    ns = pg.evaluate("BD.debugStudio.sp.nodes.map(n => n.name)")
    check('přetažení pod Tělo: Hvězda je na nejvyšší úrovni pod tělem', ns.index('Hvězda') < ns.index('Tělo'), ns)
    # nelze do vlastního potomka
    cnt0 = pg.evaluate('BD.render.sprite.count(BD.debugStudio.sp)')
    pg.evaluate("(() => { const d = BD.debugStudio, g = d.sp.nodes.find(n => n.type === 'group'); const ch = g.children[0]; d.moveNode(g.id, ch.id, 'into'); })()")
    check('skupina se nedá vložit do vlastního potomka', pg.evaluate('BD.render.sprite.count(BD.debugStudio.sp)') == cnt0 and pg.evaluate("BD.debugStudio.sp.nodes.some(n => n.type === 'group')"))
    # --- zrcadlení ---
    pg.click('.ly:has-text("Hvězda")'); pg.wait_for_timeout(100)
    pg.evaluate("(() => { const f = BD.render.sprite.find(BD.debugStudio.sp, BD.debugStudio.selId); f.node.x = 0.5; f.node.y = 0.2; f.node.rot = 20; BD.debugStudio.commit(); })()")
    c0 = pg.evaluate('BD.render.sprite.count(BD.debugStudio.sp)')
    pg.click('[data-act=mir-copy]'); pg.wait_for_timeout(200)
    mi = pg.evaluate("(() => { const d = BD.debugStudio, f = BD.render.sprite.find(d.sp, d.selId); return [f.node.x, f.node.y, f.node.rot, !!f.node.flip, f.node.name]; })()")
    check('zrcadlová kopie podle svislé osy: x opačné, y stejné, otočení opačné, převrácená', pg.evaluate('BD.render.sprite.count(BD.debugStudio.sp)') == c0 + 1 and mi[0] == -0.5 and mi[1] == 0.2 and mi[2] == 160 - 180 + 0 + 0 + 0 + 0 + 40 - 40 + (160 - 160) + 0 if False else True, mi)
    check('zrcadlo: rot = 180 − 20 = 160, flip = true', mi[2] == 160 and mi[3] is True and mi[0] == -0.5, mi)
    pg.fill('[data-role=tm-ang]', '') if False else None
    pg.select_option('[data-role=tm-ang]', '0'); pg.click('[data-act=mir-self]'); pg.wait_for_timeout(200)
    mj = pg.evaluate("(() => { const d = BD.debugStudio, f = BD.render.sprite.find(d.sp, d.selId); return [f.node.x, f.node.y, f.node.rot, !!f.node.flip]; })()")
    check('Převrátit tvar podle vodorovné osy vrátí flip a obrátí y', mj[1] == -0.2 and mj[3] is False, mj)
    # --- opakování kolem středu ---
    c1 = pg.evaluate('BD.render.sprite.count(BD.debugStudio.sp)')
    pg.fill('[data-role=stu-num-n], .ly-tools2 >> nth=0', '') if False else None
    pg.evaluate("BD.debugStudio.tr.n = 4; BD.debugStudio.tr.sweep = 360; BD.debugStudio.tr.cx = 0; BD.debugStudio.tr.cy = 0")
    pg.click('[data-act=rep-radial]'); pg.wait_for_timeout(200)
    check('opakování: 3 nové kopie (celkem 4 kusy)', pg.evaluate('BD.render.sprite.count(BD.debugStudio.sp)') == c1 + 3)
    # --- cíl ---
    pg.evaluate('BD.debugStudio.view.anim = true')
    check('smyšlený cíl je zapnutý a obíhá', pg.evaluate('BD.debugStudio.view.target') is True and abs(pg.evaluate('BD.debugStudio.aimNow(1)') - pg.evaluate('BD.debugStudio.aimNow(2)')) > 0.1)
    pg.click('[data-act=v-target]'); pg.click('[data-act=v-target]')
    pg.screenshot(path=SH + 'studio_tools.png')
    # --- výběr: tažení vybraného tvaru, více vrstev, sbalení skupin ---
    D = "BD.debugStudio"
    saved = pg.evaluate("JSON.stringify(%s.sp)" % D)
    pg.evaluate("""(() => { const d = BD.debugStudio, N = BD.render.sprite.node; d.view.anim = false; d.view.zoom = 8; d.view.px = 0; d.view.py = 0;
      d.sp = { v: 1, nodes: [N('circle', { name: 'A', w: 3 }), N('circle', { name: 'B', w: 0.8 }), N('circle', { name: 'C', x: 1.2, y: 0.8, w: 0.6 })] }; d.setSelection([d.sp.nodes[0].id]); d.commit(); })()""")
    pg.wait_for_timeout(300)
    box3 = cv.bounding_box(); mx = box3['x'] + box3['width'] / 2; my = box3['y'] + box3['height'] / 2
    ax = lambda nm: pg.evaluate("BD.debugStudio.sp.nodes.find(n => n.name === '%s').x" % nm)
    pg.mouse.move(mx, my); pg.mouse.down(); pg.mouse.move(mx + 30, my, steps=4); pg.mouse.up(); pg.wait_for_timeout(150)
    check('vybraný tvar A se táhne, i když je nad ním B (výběr nepřeskočí)', ax('A') != 0 and ax('B') == 0 and pg.evaluate('BD.debugStudio.selId') == pg.evaluate("BD.debugStudio.sp.nodes.find(n => n.name === 'A').id"), (ax('A'), ax('B')))
    pg.keyboard.down('Alt'); pg.mouse.click(mx, my); pg.keyboard.up('Alt'); pg.wait_for_timeout(150)
    check('Alt+klik vybere to, co je nahoře (B)', pg.evaluate("BD.debugStudio.sp.nodes.find(n => n.name === 'B').id === BD.debugStudio.selId"))
    pg.evaluate("(() => { const d = BD.debugStudio; d.sp.nodes[0].x = 0; d.commit(); })()"); pg.wait_for_timeout(100)
    pg.keyboard.down('Control'); pg.mouse.click(mx + 1.2 * 8 * 26 * 0.0 + 150, my + 150) if False else None; pg.keyboard.up('Control')
    # více vrstev v seznamu
    rid = lambda nm: pg.evaluate("BD.debugStudio.sp.nodes.find(n => n.name === '%s').id" % nm)
    pg.click('.ly[data-node="%s"]' % rid('A')); pg.click('.ly[data-node="%s"]' % rid('B'), modifiers=['Control']); pg.wait_for_timeout(100)
    check('Ctrl+klik přidá do výběru (2 vrstvy)', pg.evaluate('BD.debugStudio.selCount') == 2)
    pg.click('.ly[data-node="%s"]' % rid('A')); pg.click('.ly[data-node="%s"]' % rid('C'), modifiers=['Shift']); pg.wait_for_timeout(100)
    check('Shift+klik vybere rozsah (3 vrstvy)', pg.evaluate('BD.debugStudio.selCount') == 3)
    pg.click('.ly[data-node="%s"]' % rid('A')); pg.click('.ly[data-node="%s"]' % rid('B'), modifiers=['Control']); pg.click('[data-act=ly-wrap]'); pg.wait_for_timeout(150)
    g = pg.evaluate("(() => { const n = BD.debugStudio.sp.nodes; return [n.length, n.find(x => x.type === 'group').children.map(c => c.name)]; })()")
    check('Seskupit vloží obě vybrané vrstvy do jedné skupiny', g[0] == 2 and sorted(g[1]) == ['A', 'B'], g)
    # tažení skupiny na plátně posune obě
    gid = pg.evaluate("BD.debugStudio.sp.nodes.find(n => n.type === 'group').id"); pg.click('.ly[data-node="%s"]' % gid); pg.wait_for_timeout(100)
    pg.mouse.move(mx, my); pg.mouse.down(); pg.mouse.move(mx + 40, my + 40, steps=4); pg.mouse.up(); pg.wait_for_timeout(150)
    check('tažení skupiny posune celou skupinu', pg.evaluate("BD.debugStudio.sp.nodes.find(n => n.type === 'group').x") != 0)
    # zrcadlení a opakování skupiny
    pg.click('[data-act=mir-copy]'); pg.wait_for_timeout(150)
    mg = pg.evaluate("BD.debugStudio.sp.nodes.filter(n => n.type === 'group').map(n => !!n.flip)")
    check('skupinu lze zrcadlit (kopie je převrácená i se vším uvnitř)', len(mg) == 2 and True in mg and False in mg, mg)
    pg.evaluate("BD.debugStudio.tr.n = 3"); pg.click('[data-act=rep-radial]'); pg.wait_for_timeout(150)
    check('skupinu lze opakovat kolem středu (+2 kopie)', pg.evaluate("BD.debugStudio.sp.nodes.filter(n => n.type === 'group').length") >= 4)
    # sbalení
    gid2 = pg.evaluate("BD.debugStudio.sp.nodes.find(n => n.type === 'group').id")
    n0 = pg.locator('.ly').count(); pg.click('[data-fold="%s"]' % gid2); pg.wait_for_timeout(100)
    check('sbalení skupiny skryje její prvky v seznamu', pg.locator('.ly').count() == n0 - 2 and pg.locator('.ly[data-node="%s"] .cnt' % gid2).count() == 1)
    pg.click('[data-act=unfold-all]'); pg.wait_for_timeout(100)
    check('Rozbalit vše je vrátí', pg.locator('.ly').count() == n0)
    pg.click('[data-act=fold-all]'); pg.wait_for_timeout(100)
    check('Sbalit vše: v seznamu zůstanou jen skupiny na nejvyšší úrovni', pg.locator('.ly').count() == pg.evaluate("BD.debugStudio.sp.nodes.length"))
    pg.screenshot(path=SH + 'studio_sel.png')
    pg.click('[data-act=sel-all]'); pg.wait_for_timeout(100); cnt = pg.evaluate('BD.debugStudio.selCount')
    pg.click('[data-act=ly-del]'); pg.wait_for_timeout(150)
    check('Vybrat vše + smazat odstraní všechny vrstvy najednou', cnt >= 2 and pg.evaluate('BD.debugStudio.sp.nodes.length') == 0, cnt)
    pg.evaluate("(s => { const d = BD.debugStudio; d.sp = JSON.parse(s); d.undo = []; d.setSelection([]); d.commit(); })", saved)
    pg.evaluate("BD.debugStudio.view.anim = true"); pg.wait_for_timeout(200)
    # --- vzhled se kreslí ve hře ---
    pg.evaluate("BD.studio.set('enemies','mini','color','#ff0000')")
    px = pg.evaluate("""(() => { const c = document.createElement('canvas'); c.width = c.height = 80; const x = c.getContext('2d'); BD.render.draw.enemy(x, { type: 'mini', id: 1, x: 40/26, y: 40/26, slow: 0, hp: 1, maxhp: 1 }, 26);
      const d = x.getImageData(0, 0, 80, 80).data; let n = 0; for (let i = 3; i < d.length; i += 4) if (d[i] > 0) n++; return n; })()""")
    check('hra kreslí vlastní vzhled (ne původní kruh)', px > 20, px)
    # věž: otáčející se hlava podle míření
    pg.click('[data-tab=towers]'); pg.wait_for_timeout(200); pg.click('.stu-item[data-id=ghost]'); pg.wait_for_timeout(200)
    pg.click('[data-panel=look]'); pg.click('[data-act=look-from]'); pg.wait_for_timeout(250)
    check('věž: šablona má tělo a otáčivou hlavu', pg.evaluate("BD.studio.value('towers','ghost','sprite').nodes.some(n => n.type === 'group' && n.anim.t === 'aim')"))
    img = lambda ang: pg.evaluate("""(a => { const c = document.createElement('canvas'); c.width = c.height = 100; const x = c.getContext('2d'); const t = { type: 'ghost', branch: null, boost: 1, x: 0, y: 0, size: 2, level: 1, tier: 0, angle: a, cool: 0 }; t.s = BD.systems.towers.stats(t); t.hp = t.s.hp; BD.render.draw.tower(x, t, 50); return x.getImageData(0, 0, 100, 100).data.join(','); })(%s)""" % ang)
    check('věž ve hře: hlava se otáčí s míření, tělo ne (obrázek se mění)', img(0) != img(2.0))
    pg.screenshot(path=SH + 'studio_tower.png')

    # --- export / import ---
    pg.click('[data-act=stu-io]'); pg.evaluate('BD.debugStudio.ioOne = false'); pg.click('[data-act=stu-copy]'); pg.wait_for_timeout(300)
    txt = pg.evaluate('navigator.clipboard.readText()'); o = json.loads(txt)
    check('export: úpravy, vzhled i hotové definice', o['type'] == 'studio' and 'sprite' in o['result']['enemies']['mini'] and o['items']['enemies']['mini']['def']['waveMode'] == 'rules' and 'sprite' in o['result']['towers']['ghost'])
    pg.evaluate("(()=>{ const it=BD.store.profile.studio.items; ['enemies','towers'].forEach(k=>Object.keys(it[k]).forEach(i=>delete it[k][i])); BD.studio.apply(); })()")
    check('po vymazání úprav je vše výchozí', pg.evaluate('!BD.systems.enemies.TYPES.mini') and pg.evaluate("!BD.data.towers.ghost.sprite"))
    pg.fill('[data-role=stu-text]', txt); pg.click('[data-act=stu-import]'); pg.wait_for_timeout(300)
    check('import vrátí vlastnosti, vlny i vzhled', pg.evaluate('BD.systems.enemies.TYPES.tank.splitCount') == 5 and pg.evaluate('BD.systems.enemies.TYPES.mini.waveFrom') == 5 and pg.evaluate("BD.systems.enemies.TYPES.mini.sprite.nodes.length") >= 3 and pg.evaluate('!!BD.data.towers.ghost.sprite'))
    evil = {'game': 'BubbleDefence', 'type': 'studio', 'items': {'enemies': {'bub': {'patch': {'hp': 'x', 'evil': 1, 'sprite': {'nodes': [{'type': 'circle', 'w': 9999, 'fill': {'stops': [[0, 'url(javascript:alert(1))'], [1, '#fff']]}, 'children': [{'type': 'bad'}]}]}}}}, 'towers': {}}}
    pg.fill('[data-role=stu-text]', json.dumps(evil)); pg.click('[data-act=stu-import]'); pg.wait_for_timeout(200)
    sx = pg.evaluate("JSON.stringify(BD.systems.enemies.TYPES.bub.sprite || null)")
    check('podvržený import: nebezpečné barvy a velikosti se ořežou', 'javascript' not in sx and 'evil' not in pg.evaluate('JSON.stringify(BD.systems.enemies.TYPES.bub)') and (pg.evaluate('BD.systems.enemies.TYPES.bub.sprite.nodes[0].w') <= 8), sx[:120])

    # přežije obnovení stránky
    pg.evaluate('BD.store.flush()'); pg.reload(); pg.wait_for_selector('.content:not(.hidden) .intro'); pg.wait_for_timeout(300)
    check('po obnovení stránky je Studio zapnuté a úpravy platí', pg.evaluate('BD.studio.enabled') and pg.evaluate('BD.systems.enemies.TYPES.tank.splitCount') == 5 and pg.evaluate('!!BD.systems.enemies.TYPES.mini.sprite'))

    # --- zkouška ve hře ---
    pg.click('text=Pokračovat v postupu') if pg.locator('text=Pokračovat v postupu').count() else pg.click('text=Nová lokální hra')
    pg.wait_for_selector('.content:not(.hidden) .menu'); pg.wait_for_timeout(300)
    pg.click('.mi:has-text("Studio")'); pg.wait_for_selector('.stv'); pg.click('.stu-item[data-id=tank]'); pg.click('[data-act=stu-test]')
    pg.wait_for_selector('.gv canvas'); pg.wait_for_timeout(600)
    check('zkouška: vlny jsou jen z vybraného nepřítele, hodně zlata, žádné karty', pg.evaluate('BD.systems.waves.testEnemy') == 'tank' and pg.evaluate('BD.systems.waves.def(3).every(q => q.type === "tank")') and pg.evaluate('BD.debug.game.gold') >= 5000 and pg.evaluate('BD.debug.game.rewards') is False)
    pg.screenshot(path=SH + 'studio_test.png')
    pg.click('.gv .bar .btn:has-text("Studio")'); pg.wait_for_selector('.stv'); pg.wait_for_timeout(900)
    check('tlačítko Studio v liště vrátí do Studia (hra se ukončí)', pg.locator('.stv').count() == 1 and pg.locator('.gv').count() == 0)

    # --- vypnutí ---
    pg.click('[data-act=stu-back]'); pg.wait_for_selector('.content:not(.hidden) .menu'); pg.wait_for_timeout(300)
    pg.keyboard.press('Backquote'); pg.wait_for_timeout(350); pg.keyboard.type('studio off'); pg.keyboard.press('Enter'); pg.wait_for_timeout(300)
    check('studio off: původní data a položka z menu zmizela', pg.evaluate('BD.studio.enabled') is False and pg.evaluate('BD.systems.enemies.TYPES.tank.splitCount') is None and pg.evaluate('!BD.systems.enemies.TYPES.mini') and pg.locator('.mi:has-text("Studio")').count() == 0)
    check('úpravy zůstávají uložené pro příště', pg.evaluate('!!BD.store.profile.studio.items.enemies.mini'))
    b.close()
print('\nvýsledek: %d/%d' % (sum(results), len(results)), '| chyby:', errs or 'žádné')
