#!/usr/bin/env python3
"""Verify additive voice charge/refund idempotency tables and uniqueness."""
from pathlib import Path
import sqlite3
ROOT = Path(__file__).resolve().parents[1]
sql = (ROOT / 'migrations' / '005_voice_idempotency_sqlite.sql').read_text(encoding='utf-8')
assert 'DROP TABLE' not in sql.upper() and 'DELETE FROM' not in sql.upper()
con = sqlite3.connect(':memory:')
con.executescript(sql)
con.executescript(sql)  # migration is repeatable
con.execute("INSERT INTO voice_request_keys VALUES(7,'request-1234567890','2026-11-12 10:00:00')")
try:
    con.execute("INSERT INTO voice_request_keys VALUES(7,'request-1234567890','2026-11-12 10:00:01')")
    raise AssertionError('duplicate charge request key was accepted')
except sqlite3.IntegrityError:
    pass
con.execute("INSERT INTO voice_refunds VALUES(7,'request-1234567890','2026-11-12 10:00:02')")
try:
    con.execute("INSERT INTO voice_refunds VALUES(7,'request-1234567890','2026-11-12 10:00:03')")
    raise AssertionError('duplicate refund request key was accepted')
except sqlite3.IntegrityError:
    pass
assert con.execute('SELECT COUNT(*) FROM voice_request_keys').fetchone()[0] == 1
assert con.execute('SELECT COUNT(*) FROM voice_refunds').fetchone()[0] == 1
con.close()
print('PASS: additive voice charge/refund idempotency migration is repeatable and rejects duplicate keys per user.')
