// Re-export real three.js but replace WebGLRenderer with a no-GPU fake for headless gameplay tests
export * from '../node_modules/three/build/three.module.js';
const el = () => ({ style: {} as Record<string, string>, addEventListener() {}, removeEventListener() {}, remove() {}, requestPointerLock() { return Promise.resolve(); }, width: 800, height: 450, clientWidth: 800, clientHeight: 450 });
export class WebGLRenderer {
  domElement = el(); shadowMap = { enabled: false, type: 0 }; outputColorSpace = ''; toneMapping = 0; toneMappingExposure = 1; autoClear = true;
  renders = 0;
  setPixelRatio() {} getPixelRatio() { return 1; } setSize() {} clear() {} clearDepth() {} compile() {} dispose() {} forceContextLoss() {}
  render() { this.renders++; } getRenderTarget() { return null; } setRenderTarget() {} getSize(v: { set: (a: number, b: number) => void }) { v.set(800, 450); return v; }
}
