import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
const root=join(dirname(fileURLToPath(import.meta.url)),'..');
const html=readFileSync(join(root,'index.html'),'utf8');
const nav=html.slice(html.indexOf('<nav class="career-rail"'),html.indexOf('</nav>')+6);

test('Socle 5.0-F expose exactement les neuf rubriques principales',()=>{
  const labels=[...nav.matchAll(/<span>([^<]+)<\/span>/g)].map(m=>m[1].replace('&amp;','&'));
  assert.deepEqual(labels,['Accueil','Club','Compétitions','Mercato','Tactique','Calendrier & Matchs','Gestion','Médias','Plus / Paramètres']);
});

test('chaque rubrique principale pointe vers un écran déclaré',()=>{
  const targets=[...nav.matchAll(/data-screen-link="([^"]+)"/g)].map(m=>m[1]);
  const screens=new Set([...html.matchAll(/data-screen="([^"]+)"/g)].map(m=>m[1]));
  assert.equal(targets.length,9);
  for(const target of targets) assert.ok(screens.has(target),`écran non déclaré: ${target}`);
  for(const screen of ['accueil','club','competitions','mercato','arene','calendrier','gestion','messagerie','reglages'])
    assert.ok(screens.has(screen),`rubrique 5.0-F absente: ${screen}`);
});

test('les fonctions de sauvegarde, calendrier et simulation restent présentes',()=>{
  for(const id of ['manualSave','reloadCareer','advanceCalendar','simulateDay','playCalendarMatch','transferMarketPanel','clubOfficePanel','managementPanel'])
    assert.ok(html.includes(`id="${id}"`),`fonction historique absente: ${id}`);
});
