import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
const scene = await readFile(new URL('../src/scene-3d.js', import.meta.url), 'utf8');
test('le public réagit avec des mouvements variables pendant les séquences animées', () => {
  assert.match(scene, /function addArena\(out,time=0\)/);
  assert.match(scene, /Math\.sin\(time\*2\.1\+i\*\.63\+row\*\.9\)/);
  assert.match(scene, /addArena\(out,time\)/);
});
test('la caméra cinématique conserve un léger mouvement organique sans lutter contre le joueur', () => {
  assert.match(scene, /const time=performance\.now\(\)\/1000/);
  assert.match(scene, /Math\.sin\(time\*\.22\)\*\.018/);
  assert.match(scene, /drag\?0:/);
  assert.match(scene, /Math\.sin\(time\*\.17\)\*\.008/);
});
test('le mouvement de caméra se réinitialise proprement après le glissement manuel', () => {
  assert.match(scene, /drag=null;redraw\(\)/);
  assert.match(scene, /function onMove\(e\)/);
});
test('les effets cinématiques restent dans le moteur WebGL et ne remplacent pas les règles de dames', () => {
  assert.match(scene, /gl\.drawArrays\(gl\.TRIANGLES/);
  assert.match(scene, /function animateMove/);
  assert.match(scene, /function playPose/);
});
