/**
 * WHITE ROOM OS — Phase 1 Unit & Integration Test Suite
 * Executed via Node.js native test runner (`node --test`).
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { createWhiteRoomSystem } from '../src/core/bootstrap.js';
import { ValidationError, validateEntity } from '../src/core/schema.js';
import { PersistentTimerEngine } from '../src/engines/timerEngine.js';

test('1. Schema Validation Engine enforces strict rules and rejects invalid payloads', () => {
  assert.throws(
    () =>
      validateEntity('tasks', {
        id: 't1',
        title: '',
        date: 'invalid-date',
        category: 'UnknownCategory',
        status: 'pending',
        plannedDurationMin: -10,
        priority: 9,
      }),
    ValidationError
  );

  const validTask = validateEntity('tasks', {
    id: 'task_valid_1',
    title: 'Solve 5 Graph Problems',
    date: '2026-10-14',
    category: 'Primary',
    status: 'pending',
    plannedDurationMin: 60,
    priority: 1,
    skillId: 'skill-python-algo',
  });
  assert.equal(validTask.id, 'task_valid_1');
});

test('2. Database Initialization & Master Seed preserves 13 Capabilities and 23 Engines Registry', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true, initialDate: '2026-10-14' });
  const state = sys.store.getState();

  assert.equal(state.capabilities.length, 13, 'Must seed all 13 Master Capability domains');
  assert.equal(state.capabilities[0].name, 'Cognitive Development');
  assert.equal(state.capabilities[12].name, 'Character / Identity');
  assert.equal(state.enginesRegistry.length, 23, 'Must register all 23 Master Engines');
  assert.ok(state.skills.length >= 7, 'Must seed initial skills across core capabilities');
});

test('3. College Schedule & Time Management Engine differentiates College Days vs Free Focus Days', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true, initialDate: '2026-10-14' });
  const { timeEngine } = sys.engines;
  const config = await timeEngine.getScheduleConfig();

  // 2026-10-13 is Tuesday (College Day: 06:00-18:00 = 12 hours)
  const tuesdayBudget = timeEngine.calculateDayBudget(config, '2026-10-13', 7);
  assert.equal(tuesdayBudget.dayName, 'Tuesday');
  assert.equal(tuesdayBudget.isCollegeDay, true);
  assert.equal(tuesdayBudget.collegeHours, 12);
  assert.equal(tuesdayBudget.netFreeHours, 2.0); // 24 - (12 + 7.5 + 1.5 + 1.0) = 2.0h

  // 2026-10-14 is Wednesday (Non-College Day: 0 hours college)
  const wednesdayBudget = timeEngine.calculateDayBudget(config, '2026-10-14', 8);
  assert.equal(wednesdayBudget.dayName, 'Wednesday');
  assert.equal(wednesdayBudget.isCollegeDay, false);
  assert.equal(wednesdayBudget.collegeHours, 0);
  assert.equal(wednesdayBudget.netFreeHours, 14.0); // 24 - (0 + 7.5 + 1.5 + 1.0) = 14.0h
  assert.ok(
    wednesdayBudget.recommendedDeepWorkHours > tuesdayBudget.recommendedDeepWorkHours,
    'Focus day must allow more Deep Work than a 12-hour College Day'
  );

  // Verify user can customize College Days and Hours dynamically
  const updated = await timeEngine.updateScheduleConfig({
    collegeDays: ['Sunday', 'Tuesday'],
    collegeStart: '08:00',
    collegeEnd: '16:00',
  });
  assert.deepEqual(updated.collegeDays, ['Sunday', 'Tuesday']);
  const newTuesdayBudget = timeEngine.calculateDayBudget(updated, '2026-10-13', 7);
  assert.equal(newTuesdayBudget.collegeHours, 8);
  assert.equal(newTuesdayBudget.netFreeHours, 6.0);
});

test('4. Adaptive Daily OS Engine generates Primary, Secondary, Maintenance, and Recovery missions', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true, initialDate: '2026-10-14' });
  const { dailyOsEngine } = sys.engines;

  const focusDayPlan = await dailyOsEngine.generateAdaptiveMissions('2026-10-14', 8, true);
  assert.equal(focusDayPlan.tasks.length, 4, 'Should generate 4 balanced mission slots, not all skills');
  const categories = focusDayPlan.tasks.map((t) => t.category);
  assert.deepEqual(categories, ['Primary', 'Secondary', 'Maintenance', 'Recovery']);

  const collegeDayPlan = await dailyOsEngine.generateAdaptiveMissions('2026-10-15', 5, true); // Thursday = College day
  assert.equal(collegeDayPlan.budget.isCollegeDay, true);
  assert.ok(
    collegeDayPlan.tasks[0].plannedDurationMin < focusDayPlan.tasks[0].plannedDurationMin,
    'Primary task duration on a College Day must adapt down compared to Focus Day'
  );
});

test('5. Persistent Timer Engine survives simulated Page Refresh, Pause/Resume, and Finish', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true, initialDate: '2026-10-14' });
  const { timerEngine } = sys.engines;
  const plan = sys.store.getState().dailyPlan;
  const primaryTask = plan.tasks[0];

  const t0 = 1700000000000;
  await timerEngine.start(primaryTask, t0);

  // Simulate 15 minutes (900,000 ms) of active work, then a page refresh (new engine instance reading from same DB)
  const reloadedTimerEngine = new PersistentTimerEngine(sys.db);
  const stateAt15m = await reloadedTimerEngine.getState();
  const liveAt15m = reloadedTimerEngine.computeLiveMetrics(stateAt15m, t0 + 900_000);
  assert.equal(liveAt15m.status, 'running');
  assert.equal(liveAt15m.elapsedActiveSec, 900, 'Must accurately compute 900s elapsed across reload');

  // Pause at t0 + 15m
  await reloadedTimerEngine.pause(t0 + 900_000);
  // Stay paused for 5 minutes (300,000 ms), then resume at t0 + 20m
  await reloadedTimerEngine.resume(t0 + 1_200_000);
  // Run for another 10 minutes (600,000 ms) and finish at t0 + 30m
  const finishedState = await reloadedTimerEngine.finish(t0 + 1_800_000);
  const finalMetrics = reloadedTimerEngine.computeLiveMetrics(finishedState, t0 + 1_800_000);

  assert.equal(finalMetrics.status, 'finished');
  assert.equal(finalMetrics.elapsedActiveSec, 1500, 'Total active time must be 15m + 10m = 1500s');
  assert.equal(finalMetrics.elapsedPauseSec, 300, 'Total pause time must be 5m = 300s');
});

test('6. Performance Log Engine updates Task, Skill Metrics, and seeds Error System on mistakes', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true, initialDate: '2026-10-14' });
  const { performanceEngine } = sys.engines;
  const task = sys.store.getState().dailyPlan.tasks[0];
  const skillBefore = await sys.db.get('skills', task.skillId);

  const result = await performanceEngine.recordPerformanceLog({
    taskId: task.id,
    taskTitle: task.title,
    skillId: task.skillId,
    date: '2026-10-14',
    plannedDurationSec: 5400,
    actualDurationSec: 4800, // 80 minutes
    pauseDurationSec: 300,
    completionPct: 100,
    energy: 8,
    difficulty: 8,
    confidence: 6,
    whatLearned: 'Implemented Dijkstra shortest path with priority queue',
    mistakes: 'Forgot visited set check causing duplicate heap pushes on dense graphs',
    notes: 'Need to re-test on 3 weighted graph problems tomorrow',
  });

  assert.ok(result.log.id.startsWith('perf_'));
  assert.ok(result.createdError, 'Must automatically create a structured ErrorRecord when mistakes are logged');
  assert.equal(result.createdError.severity, 'high');
  assert.equal(result.createdError.status, 'open');

  const updatedTask = await sys.db.get('tasks', task.id);
  assert.equal(updatedTask.status, 'completed');

  const skillAfter = await sys.db.get('skills', task.skillId);
  assert.equal(
    skillAfter.metrics.totalPracticeMinutes,
    skillBefore.metrics.totalPracticeMinutes + 80,
    'Skill practice minutes must increase by actual session minutes'
  );

  const progress = await performanceEngine.computeSystemProgress();
  assert.equal(progress.completedTasks, 1);
  assert.equal(progress.totalSessionsLogged, 1);
  assert.ok(progress.openErrorsCount >= 1);
});

test('7. Backup & Restore Engine exports checksummed snapshot, detects tampering, and restores cleanly', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true, initialDate: '2026-10-14' });
  const { backupEngine, dailyOsEngine } = sys.engines;

  await dailyOsEngine.createCustomTask({
    id: 'task_custom_backup_test',
    title: 'Custom Cybersecurity Lab: Linux Privilege Escalation',
    date: '2026-10-14',
    category: 'Secondary',
    plannedDurationMin: 45,
    priority: 2,
    skillId: 'skill-cyber-linux',
  });

  const backup = await backupEngine.exportBackup();
  assert.equal(backup.magic, 'WHITE_ROOM_OS_BACKUP');
  assert.ok(backup.checksum.length === 8);

  // Tamper with backup and verify checksum rejection
  const tampered = structuredClone(backup);
  tampered.stores.visions[0].title = 'TAMPERED_TITLE';
  assert.throws(() => backupEngine.validateBackupBundle(tampered), /checksum mismatch/);

  // Clear DB completely and restore from valid backup
  await sys.db.clearAll();
  const tasksAfterClear = await sys.db.getAll('tasks');
  assert.equal(tasksAfterClear.length, 0);

  const restoreResult = await backupEngine.restoreBackup(backup);
  assert.equal(restoreResult.restoredCount, backup.totalRecords);

  const restoredTask = await sys.db.get('tasks', 'task_custom_backup_test');
  assert.ok(restoredTask);
  assert.equal(restoredTask.title, 'Custom Cybersecurity Lab: Linux Privilege Escalation');
});
