const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'ui/report/report.html'), 'utf8');
const report = fs.readFileSync(path.join(root, 'ui/report/report.js'), 'utf8');
const jsonText = fs.readFileSync(path.join(root, 'template/ai-result-template.json'), 'utf8');
const json = JSON.parse(jsonText);
const fallback = fs.readFileSync(path.join(root, 'template/ai-result-template.js'), 'utf8');

if (!html.includes('id="download-json-button"')) throw new Error('download button missing');
if (!html.includes('../../template/ai-result-template.js')) throw new Error('template fallback script not wired');
if (!report.includes('window.PenggilasAITemplate')) throw new Error('report fallback not present');
if (!report.includes('fetch(templateURL')) throw new Error('HTTP JSON fallback removed');
if (!fallback.includes('window.PenggilasAITemplate')) throw new Error('fallback template global missing');
if (!fallback.includes(json.template_id)) throw new Error('fallback template does not match JSON template');

const templateFallbackPos = html.indexOf('<script src="../../template/ai-result-template.js');
const mapperPos = html.indexOf('<script src="../../core/json-mapper.js');
const reportPos = html.indexOf('<script src="report.js');
if (templateFallbackPos < 0 || mapperPos < 0 || reportPos < 0) throw new Error('required report assets missing');
if (templateFallbackPos > reportPos) throw new Error('template fallback must load before report.js');
if (mapperPos > reportPos) throw new Error('mapper must load before report.js');

function versionOf(src) {
  const m = src.match(/[?&]v=([^"']+)/);
  return m ? m[1] : null;
}
const mapperTag = html.match(/<script[^>]+src="([^\"]*json-mapper\.js[^\"]*)"/);
const reportTag = html.match(/<script[^>]+src="([^\"]*report\.js[^\"]*)"/);
const fallbackTag = html.match(/<script[^>]+src="([^\"]*ai-result-template\.js[^\"]*)"/);
if (!mapperTag || !reportTag || !fallbackTag) throw new Error('asset script tags not parseable');
if (!versionOf(mapperTag[1])) throw new Error('mapper asset is not cache-versioned');
if (!versionOf(reportTag[1])) throw new Error('report asset is not cache-versioned');
if (!versionOf(fallbackTag[1])) throw new Error('template fallback asset is not cache-versioned');
if (versionOf(mapperTag[1]) !== versionOf(reportTag[1])) throw new Error('mapper/report asset versions differ');

const templateFetch = report.match(/ai-result-template\.json\?v=([^"']+)/);
if (!templateFetch) throw new Error('JSON template fetch is not cache-versioned');
if (templateFetch[1] !== versionOf(fallbackTag[1])) throw new Error('JSON fetch/fallback template versions differ');
if (versionOf(fallbackTag[1]) !== '20261007-v122') throw new Error('unexpected V1.18 report asset version');

const fallbackJsonMatch = fallback.match(/^window\.PenggilasAITemplate = (.*);\s*$/s);
if (!fallbackJsonMatch) throw new Error('fallback template payload is not a simple JSON assignment');
const fallbackJson = JSON.parse(fallbackJsonMatch[1]);
if (JSON.stringify(fallbackJson) !== JSON.stringify(json)) throw new Error('fallback template content differs from JSON template');

console.log('report download wiring: PASS');
