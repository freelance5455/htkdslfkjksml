import test from 'node:test';
import assert from 'node:assert/strict';
import { buildMatchPrep } from '../src/match-prep.js';

const state = {
  userClubId: 'a',
  divisions: [{ clubs: [
    { id: 'a', name: 'Orion Dames', damistes: [{ id: 'p1', name: 'K. Zorin', level: 70, form: 80 }, { id: 'p2', name: 'M. Ielo', level: 82, form: 65 }] },
    { id: 'b', name: 'Vega Stars', damistes: [{ id: 'p3', name: 'Z. Pulsar', level: 76, form: 58 }] }
  ] }]
};

test('la préparation propose le meilleur damiste comme titulaire et décrit l’adversaire', () => {
  const prep = buildMatchPrep(state, { id: 'f1', home: 'b', away: 'a', competitionId: 'championnat' });
  assert.equal(prep.competition, 'Championnat');
  assert.equal(prep.opponentName, 'Vega Stars');
  assert.ok(['p1', 'p2'].includes(prep.starterId));
  assert.equal(prep.side, 'away');
  assert.equal(prep.squad.length, 2);
  assert.equal(prep.opponentLevel, 76);
  assert.equal(prep.title, 'Vega Stars — Orion Dames');
});

test('la préparation reste utilisable sans club joueur ni adversaire connu', () => {
  const prep = buildMatchPrep({ divisions: [] }, { id: 'f2', home: 'x', away: 'y', competitionId: 'coupe-lunaire' });
  assert.equal(prep.competition, 'Coupe lunaire');
  assert.equal(prep.starterId, null);
  assert.equal(prep.opponentLevel, null);
});

test('le titulaire déjà choisi dans le calendrier est repris tel quel', () => {
  const prep = buildMatchPrep(state, { id: 'f3', home: 'a', away: 'b', competitionId: 'championnat', damisteSelections: { home: 'p1' } });
  assert.equal(prep.side, 'home');
  assert.equal(prep.starterId, 'p1');
});
