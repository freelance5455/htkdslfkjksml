import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const scene=readFileSync(new URL('../src/scene-3d.js',import.meta.url),'utf8');
test('les expressions faciales varient selon les attitudes',()=>{
 assert.ok(scene.includes('const headTilt='));
 assert.ok(scene.includes('const eyeScale='));
 assert.ok(scene.includes('const mouthColor='));
 assert.ok(scene.includes('Expressions faciales'));
});
test('les réactions collectives du public suivent la célébration ou la défaite',()=>{
 assert.ok(scene.includes("let arenaReaction='idle'"));
 assert.ok(scene.includes("arenaReaction==='celebrate'"));
 assert.ok(scene.includes("arenaReaction==='defeat'"));
 assert.ok(scene.includes('arenaReaction=pose?.action||\'idle\''));
 assert.ok(scene.includes("action==='celebrate'"));
 assert.ok(scene.includes("action==='defeat'"));
});
test('les yeux et sourcils sont intégrés à la géométrie du visage',()=>{
 assert.ok(scene.includes('eyeScale'));
 assert.ok(scene.includes('ex-.018'));
});
