from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
expected = {
    "image/index.php": ("image-studio.php", "image/"),
    "video/index.php": ("video-studio.php", "video/"),
    "realtime/index.php": ("index.php", "realtime/"),
    "lip-sync/index.php": ("lip-sync.php", "lip-sync/"),
    "voice/index.php": ("voice-studio.php", "voice/"),
    "agents/index.php": ("agent-studio.php", "agents/"),
    "agents/chat.php": ("agent-chat.php", "agents/chat.php"),
}
for path, (source, nav_key) in expected.items():
    body = (ROOT / path).read_text()
    assert source in body and nav_key in body, f"Incorrect folder entry point: {path}"

htaccess = (ROOT / ".htaccess").read_text()
for legacy, target in [
    ("image-studio\\.php", "image/"),
    ("video-studio\\.php", "video/"),
    ("index\\.php", "realtime/"),
    ("lip-sync\\.php", "lip-sync/"),
    ("voice-studio\\.php", "voice/"),
    ("agent-studio\\.php", "agents/"),
    ("agent-chat\\.php", "agents/chat.php"),
]:
    assert f"{legacy}$ {target} [R=301,L,NC]" in htaccess, f"Missing legacy redirect: {legacy}"

assert "RewriteRule ^(image|video|realtime|lip-sync|voice|agents)/index\\.php$ $1/ [R=301,L,NC]" in htaccess, "Missing direct index.php canonical redirect"

bootstrap = (ROOT / "app/bootstrap.php").read_text()
assert "function app_base_path()" in bootstrap
assert "function workspace_legacy_redirect(" in bootstrap
entry_helper = (ROOT / "workspace-entry.php").read_text()
assert "str_ends_with(rtrim($requestPath, '/'), '/index.php')" in entry_helper, "Direct index.php requests are not canonicalized"
assert "$isDirectoryWithoutSlash" in entry_helper, "Directory requests without a trailing slash are not canonicalized"
assert all(f"'{folder}'" in bootstrap for folder in ("image", "video", "realtime", "lip-sync", "voice", "agents"))
for legacy_file, folder in [("image-studio.php", "image/"), ("video-studio.php", "video/"), ("index.php", "realtime/"), ("lip-sync.php", "lip-sync/"), ("voice-studio.php", "voice/"), ("agent-studio.php", "agents/"), ("agent-chat.php", "agents/chat.php")]:
    assert f"workspace_legacy_redirect('{folder}')" in (ROOT / legacy_file).read_text(), f"Missing PHP redirect fallback: {legacy_file}"

auth = (ROOT / "app/auth.php").read_text()
assert "app_base_path().'login.php?next='" in auth, "Nested workspace sign-in redirect is not rooted"

header = (ROOT / "app/platform_header.php").read_text()
assert "$workspaceRoute" in header and "$workspaceNavKey" in header
for href in ("'image/'", "'video/'", "'realtime/'", "'lip-sync/'", "'voice/'", "'agents/'"):
    assert href in header, f"Sidebar does not use clean route {href}"

lip_sync = (ROOT / "lip-sync.php").read_text()
assert "$_GET['mode'] = 'lipsync'" in lip_sync, "Lip Sync route does not select Lip Sync mode"
print("PASS: dedicated workspace folders, canonical redirects, root-aware assets/auth, sidebar routes, and Lip Sync mode.")
