import { createLibp2p } from 'libp2p';
import { kadDHT } from '@libp2p/kad-dht';
import { gossipsub } from '@libp2p/gossipsub';
import { tcp } from '@libp2p/tcp';
import { noise } from '@chainsafe/libp2p-noise';
import { mplex } from '@libp2p/mplex';
import { multiaddr } from '@multiformats/multiaddr';

async function createNode(port: number) {
  const node = await createLibp2p({
    addresses: { listen: [`/ip4/127.0.0.1/tcp/${port}`] },
    transports: [tcp()],
    connectionEncryption: [noise()],
    streamMuxers: [mplex()],
    services: {
      // @ts-ignore
      dht: kadDHT(),
      pubsub: gossipsub()
    }
  });
  return node;
}

async function runSimulator() {
  const nodes = [];
  console.log("🚀 Initializing 10-node mesh network...");
  
  for (let i = 0; i < 10; i++) {
    nodes.push(await createNode(4000 + i));
  }
  
  // Bootstrap nodes
  for (let i = 1; i < 10; i++) {
    await nodes[i].dial(nodes[0].getMultiaddrs()[0]);
  }
  
  console.log("✅ 10 nodes connected in mesh.");
  
  const startTime = Date.now();
  // Simulate propagation measurement
  await nodes[0].services.pubsub.publish('test-topic', new TextEncoder().encode('message'));
  const endTime = Date.now();
  
  console.log(`⏱️ Latency: ${endTime - startTime}ms`);
  
  await Promise.all(nodes.map(n => n.stop()));
}

runSimulator().catch(console.error);
