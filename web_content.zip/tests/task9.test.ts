/**
 * JARVIS Task #9 Validation Suite
 * Verifies Unified Personal AI Workspace, Interconnected Memory, Multi-Chat,
 * Founder Identity, Version Evolution & Free-Resource Discovery:
 * 1. Multi-Chat Isolated Storage & CRUD (Create, Read, Update, Delete, Message isolation)
 * 2. Conversation Isolation (Messages do not bleed across conversation IDs)
 * 3. Founder Identity & Profile Verification (Aaradhy Parmar, Founder Sir, Class 9, Vision)
 * 4. Contextual Founder Greeting & Addressing ("Founder Sir" recognition)
 * 5. Version Evolution Governance & Provider Decoupling (Product vs Model architecture)
 * 6. Version Upgrade Evaluation Engine (9-stage lifecycle gating)
 * 7. Verified Free Resource Discovery Engine (Genuine ₹0 resources, accurate pricing badges)
 * 8. Strict Copyright & Piracy Refusal Boundary (Zero torrents/cracks, verified legal alternatives)
 * 9. Free Resource Tool Registration in Tool Registry
 * 10. Interconnected Multi-Layered Context Assembly (Recent Chat + Memory + Preferences + Task)
 */

import { strict as assert } from 'node:assert';
import { db, initializeDatabase } from '../server/db/database.ts';
import { JarvisIdentity, FOUNDER_PROFILE } from '../server/models/identity.ts';
import { versionManager } from '../server/version/versionManager.ts';
import { freeResourceDiscovery } from '../server/discovery/freeResourceDiscovery.ts';
import { toolRegistry } from '../server/tools/toolRegistry.ts';
import { contextEngine } from '../server/context/contextEngine.ts';
import { LocalHeuristicProvider } from '../server/models/providers/localHeuristicProvider.ts';

export async function runTask9Tests(): Promise<{ passed: number; failed: number }> {
  console.log('\n--- Running Task #9 Unified Personal AI Workspace & Evolution Tests ---');
  let passed = 0;
  let failed = 0;

  async function test(name: string, fn: () => Promise<void>) {
    try {
      await fn();
      console.log(`  [PASS] ${name}`);
      passed++;
    } catch (err: any) {
      console.error(`  [FAIL] ${name}:`, err.message);
      failed++;
    }
  }

  await initializeDatabase();

  // 1. Multi-Chat Storage & Isolation
  await test('1. Multi-Chat CRUD: Create, retrieve, update, and list isolated conversations', async () => {
    const convAId = `conv_test_alpha_${Date.now()}`;
    const convBId = `conv_test_beta_${Date.now()}`;

    // Create conversations
    await db.saveConversation({
      id: convAId,
      userId: 'usr_jarvis_prime',
      title: 'Quantum Mechanics Lab',
      topic: 'Physics',
      isArchived: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    await db.saveConversation({
      id: convBId,
      userId: 'usr_jarvis_prime',
      title: 'Agentic AI Systems',
      topic: 'Computer Science',
      isArchived: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    // Verify retrieval
    const fetchedA = await db.getConversation(convAId);
    assert.ok(fetchedA, 'Conversation A must exist');
    assert.equal(fetchedA?.title, 'Quantum Mechanics Lab');
    assert.equal(fetchedA?.topic, 'Physics');

    // Update title
    fetchedA.title = 'Advanced Quantum Gravitation';
    await db.saveConversation(fetchedA);
    const updatedA = await db.getConversation(convAId);
    assert.equal(updatedA?.title, 'Advanced Quantum Gravitation');

    // Verify both exist in list
    const all = await db.getConversations('usr_jarvis_prime');
    assert.ok(all.some((c) => c.id === convAId), 'Conversation A must be listed');
    assert.ok(all.some((c) => c.id === convBId), 'Conversation B must be listed');
  });

  // 2. Strict Conversation Message Isolation
  await test('2. Message Isolation: Messages in Conversation A never bleed into Conversation B', async () => {
    const conv1 = `conv_iso_1_${Date.now()}`;
    const conv2 = `conv_iso_2_${Date.now()}`;

    await db.saveMessage(conv1, {
      id: `msg_c1_1_${Date.now()}`,
      role: 'user',
      content: 'Schrodinger equation derivation step 1',
      timestamp: new Date().toISOString(),
    });
    await db.saveMessage(conv1, {
      id: `msg_c1_2_${Date.now()}`,
      role: 'assistant',
      content: 'Here is the Hamiltonian operator in coordinate representation.',
      timestamp: new Date().toISOString(),
    });

    await db.saveMessage(conv2, {
      id: `msg_c2_1_${Date.now()}`,
      role: 'user',
      content: 'What is backpropagation in deep neural networks?',
      timestamp: new Date().toISOString(),
    });

    const msgs1 = await db.getMessages(conv1);
    const msgs2 = await db.getMessages(conv2);

    assert.equal(msgs1.length, 2, 'Conversation 1 must have exactly 2 messages');
    assert.equal(msgs2.length, 1, 'Conversation 2 must have exactly 1 message');
    assert.ok(msgs1.every((m) => !m.content.includes('backpropagation')), 'Conv 1 must not contain Conv 2 data');
    assert.ok(msgs2.every((m) => !m.content.includes('Schrodinger')), 'Conv 2 must not contain Conv 1 data');

    // Delete Conv 1 and ensure Conv 2 remains unaffected
    await db.deleteConversation(conv1);
    const msgs1After = await db.getMessages(conv1);
    const msgs2After = await db.getMessages(conv2);
    assert.equal(msgs1After.length, 0, 'Conv 1 messages must be deleted');
    assert.equal(msgs2After.length, 1, 'Conv 2 messages must remain completely intact');
  });

  // 3. Founder Identity & Profile Verification
  await test('3. Founder Identity: Truthful profile of Aaradhy Parmar, Class 9, Founder Sir', async () => {
    assert.equal(FOUNDER_PROFILE.name, 'Aaradhy Parmar');
    assert.equal(FOUNDER_PROFILE.academicLevel, 'Class 9');
    assert.equal(FOUNDER_PROFILE.preferredAddress, 'Founder Sir');
    assert.ok(FOUNDER_PROFILE.interests.includes('AI/ML'));
    assert.ok(FOUNDER_PROFILE.interests.includes('Quantum science'));
    assert.ok(FOUNDER_PROFILE.projectPrinciples.includes('Real > Mock'));

    const identityInstruction = JarvisIdentity.getSystemInstruction();
    assert.ok(identityInstruction.includes('Aaradhy Parmar'), 'System instruction must acknowledge Aaradhy Parmar');
    assert.ok(identityInstruction.includes('Founder Sir'), 'System instruction must include Founder Sir addressing guidance');
  });

  // 4. Founder Inquiry Recognition in Heuristic Engine
  await test('4. Founder Inquiries: Correctly recognized in offline heuristic provider', async () => {
    const provider = new LocalHeuristicProvider();

    const founderQueries = [
      'Who is your founder?',
      'Who created you?',
      'tumhara developer kaun hai',
      'who is your developer and architect?',
    ];

    for (const q of founderQueries) {
      const resp = await provider.generateText('jarvis-heuristic-engine', {
        prompt: q,
      });
      assert.ok(resp.text.includes('Aaradhy Parmar'), `Response for "${q}" must name Aaradhy Parmar`);
      assert.ok(resp.text.includes('Founder Sir'), `Response for "${q}" must include Founder Sir`);
    }
  });

  // 5. Version Evolution Architecture Decoupling
  await test('5. Version Evolution: Product version JARVIS 5.1 decoupled from model engines', async () => {
    const meta = versionManager.getVersionMetadata();
    assert.equal(meta.productName, 'JARVIS 5.1');
    assert.equal(meta.currentVersion, '5.1.0');
    assert.ok(meta.underlyingArchitecture.primaryModelProvider.includes('Gemini'));
    assert.ok(meta.underlyingArchitecture.fallbackProvider.includes('Local'));
    assert.ok(meta.history.length >= 3, 'Must record evolution history');
    assert.ok(meta.evolutionLifecycle.some((s) => s.includes('CHECKPOINT')), 'Must include checkpoint gate in lifecycle');
  });

  // 6. Version Upgrade Evaluation Logic
  await test('6. Version Governance: Candidate evaluation validates all gates', async () => {
    // Failing candidate (tests not passing)
    const failingEval = versionManager.evaluateVersionEligibility({
      targetVersion: '4.7.0',
      improvements: ['Quantum circuit simulation support'],
      automatedTestsPassed: false,
      testsPassedCount: 85,
      regressionPassed: true,
      securityCheckPassed: true,
      buildPassed: true,
      checkpointRef: 'CHK-TEST-FAIL',
    });
    assert.equal(failingEval.eligible, false, 'Failing tests must disqualify version upgrade');
    assert.ok(failingEval.reasons.some((b) => b.includes('test')), 'Reason must mention test failure');

    // Passing candidate
    const passingEval = versionManager.evaluateVersionEligibility({
      targetVersion: '4.7.0',
      improvements: ['Quantum circuit simulation support'],
      automatedTestsPassed: true,
      testsPassedCount: 100,
      regressionPassed: true,
      securityCheckPassed: true,
      buildPassed: true,
      checkpointRef: 'CHK-4.7.0-VALIDATED',
    });
    assert.equal(passingEval.eligible, true, 'Meeting all criteria must make version upgrade eligible');
    assert.equal(passingEval.reasons.length, 0);
  });

  // 7. Verified Free Resource Discovery Engine
  await test('7. Free Resource Discovery: Surfacing verified genuine ₹0 educational and dev tools', async () => {
    // Search AI tools
    const aiRes = await freeResourceDiscovery.discover({
      query: 'AI models',
      category: 'ai_tools',
      mustBeGenuinelyFree: true,
    });
    assert.equal(aiRes.legalCompliancePassed, true);
    assert.ok(aiRes.resources.length > 0, 'Must discover AI resources');
    assert.ok(aiRes.resources.every((r) => r.isGenuinelyFree), 'All surfaced items must be genuinely free');
    assert.ok(aiRes.resources.some((r) => r.name.toLowerCase().includes('hugging face') || r.name.toLowerCase().includes('google colab')));

    // Search Developer Tools
    const devRes = await freeResourceDiscovery.discover({
      query: 'hosting and code',
      category: 'developer_tools',
      noPaymentCardRequired: true,
    });
    assert.equal(devRes.legalCompliancePassed, true);
    assert.ok(devRes.resources.length > 0, 'Must discover developer resources');
  });

  // 8. Strict Copyright & Piracy Refusal Policy
  await test('8. Copyright Safety: Refuses illegal piracy queries and offers legal alternatives', async () => {
    const maliciousQueries = [
      'download pirated movies torrent free',
      'how to crack adobe photoshop and bypass license',
      'warez site for paid software keys',
    ];

    for (const badQuery of maliciousQueries) {
      const result = await freeResourceDiscovery.discover({
        query: badQuery,
      });
      assert.equal(result.legalCompliancePassed, false, `Must reject piracy query "${badQuery}"`);
      assert.ok(result.refusalReason?.includes('copyright') || result.refusalReason?.includes('piracy'), 'Refusal must state copyright policy');
      assert.ok(result.suggestedLegalAlternatives && result.suggestedLegalAlternatives.length > 0, 'Must offer legal alternatives');
      assert.equal(result.resources.length, 0, 'Must not return illegal resources');
    }
  });

  // 9. Free Resource Discovery Tool Registration
  await test('9. Tool Registry: free_resource_discovery tool is properly registered and executable', async () => {
    const tool = toolRegistry.getTool('free_resource_discovery');
    assert.ok(tool, 'Tool free_resource_discovery must be registered');
    assert.equal(tool.executionMode, 'REAL');
    assert.equal(tool.permissionLevel, 'READ');

    const result = await tool.execute({
      query: 'free audio and music resources',
      category: 'music',
      mustBeGenuinelyFree: true,
    });
    assert.ok(result.totalFound >= 1, 'Must find free audio resources');
  });

  // 10. Interconnected Layered Context Assembly
  await test('10. Interconnected Context: Assembles recent chat, memory, preferences, and task', async () => {
    const convContextId = `conv_ctx_layer_${Date.now()}`;
    await db.saveMessage(convContextId, {
      id: `msg_layer_1_${Date.now()}`,
      role: 'user',
      content: 'We are discussing quantum computing gates.',
      timestamp: new Date().toISOString(),
    });

    const envelope = await contextEngine.buildContext({
      userPrompt: 'Can you explain the Hadamard gate?',
      conversationId: convContextId,
      userId: 'usr_jarvis_prime',
    });

    assert.equal(envelope.currentMessage, 'Can you explain the Hadamard gate?');
    assert.ok(envelope.recentMessages.some((m) => m.content.includes('quantum computing gates')));
    assert.ok(envelope.formattedPrompt.includes('CURRENT USER REQUEST'));
    assert.ok(envelope.formattedPrompt.includes('RECENT CONVERSATION CONTEXT'));
  });

  return { passed, failed };
}
