/**
 * JARVIS Automated Configuration Tests
 * Verifies environment parsing, numeric validation, sanitized diagnostics, and secret non-leakage.
 */

import { strict as assert } from 'node:assert';
import {
  configManager,
  generateSanitizedDiagnostics,
  getSanitizedConfig,
  validateEnvironment,
} from '../server/config/index.ts';

export async function runConfigTests(): Promise<{ passed: number; failed: number }> {
  console.log('\n--- Running Config Tests ---');
  let passed = 0;
  let failed = 0;

  function test(name: string, fn: () => void | Promise<void>) {
    try {
      fn();
      console.log(`  [PASS] ${name}`);
      passed++;
    } catch (err: any) {
      console.error(`  [FAIL] ${name}:`, err.message);
      failed++;
    }
  }

  // 1. Valid configuration with default values
  test('valid default configuration', () => {
    const { config, validation } = validateEnvironment({});
    assert.equal(config.runtime.nodeEnv, 'development');
    assert.equal(config.server.port, 3000);
    assert.equal(config.database.provider, 'sqlite');
    assert.equal(config.security.rateLimitMaxRequests, 120);
    assert.equal(validation.isValid, true);
    assert.equal(validation.errors.length, 0);
  });

  // 2. Custom environment variables parsing
  test('custom environment parsing', () => {
    const customEnv: Record<string, string> = {
      NODE_ENV: 'production',
      PORT: '8080',
      SQLITE_DB_PATH: ':memory:',
      SQLITE_WAL: 'false',
      DATABASE_PROVIDER: 'sqlite',
      RATE_LIMIT_MAX_REQUESTS: '250',
      TASK_TIMEOUT_MS: '45000',
      GEMINI_API_KEY: 'test-secret-key-12345',
    };

    const { config, validation } = validateEnvironment(customEnv);
    assert.equal(config.runtime.isProduction, true);
    assert.equal(config.server.port, 8080);
    assert.equal(config.database.sqlitePath, ':memory:');
    assert.equal(config.database.sqliteWal, false);
    assert.equal(config.security.rateLimitMaxRequests, 250);
    assert.equal(config.security.taskTimeoutMs, 45000);
    assert.equal(config.models.hasGeminiApiKey, true);
    assert.equal(config.models.geminiApiKey, 'test-secret-key-12345');
    assert.equal(validation.isValid, true);
  });

  // 3. Invalid numeric values fallback and reporting
  test('invalid numeric values fallback and validation reporting', () => {
    const invalidEnv: Record<string, string> = {
      PORT: 'not-a-number',
      RATE_LIMIT_WINDOW_MS: '-500',
      POOL_MAX: 'zero',
    };

    const { config, validation } = validateEnvironment(invalidEnv);
    // Falls back to safe defaults
    assert.equal(config.server.port, 3000);
    assert.equal(config.security.rateLimitWindowMs, 60000);
    assert.equal(config.database.poolMax, 10);
    // Records validation warnings/errors
    assert.ok(validation.errors.length > 0 || validation.warnings.length > 0);
  });

  // 4. Sanitized diagnostics generation
  test('sanitized diagnostics structure', () => {
    const { config, validation } = validateEnvironment({
      NODE_ENV: 'production',
      PORT: '3000',
      DATABASE_PROVIDER: 'sqlite',
      GEMINI_API_KEY: 'ai-studio-super-secret-key-999',
    });

    const diagnostics = generateSanitizedDiagnostics(config, validation);
    assert.equal(diagnostics.runtime.nodeEnv, 'production');
    assert.equal(diagnostics.server.port, 3000);
    assert.equal(diagnostics.database.activeProvider, 'sqlite');
    assert.equal(diagnostics.models.hasGeminiApiKey, true);
    assert.equal(diagnostics.health.isValid, true);
  });

  // 5. Secret non-leakage verification
  test('secret non-leakage verification in sanitized diagnostics', () => {
    const secret = 'ultra-sensitive-gemini-token-xyz';
    const { config, validation } = validateEnvironment({
      GEMINI_API_KEY: secret,
      DATABASE_URL: 'postgresql://admin:superSecretPass123@db.example.com:5432/jarvis',
    });

    const diagnostics = generateSanitizedDiagnostics(config, validation);
    const serialized = JSON.stringify(diagnostics);

    // Secret must NOT appear anywhere in the sanitized diagnostics JSON
    assert.ok(!serialized.includes(secret), 'Raw GEMINI_API_KEY leaked in sanitized diagnostics');
    assert.ok(!serialized.includes('superSecretPass123'), 'Raw database password leaked in sanitized diagnostics');
    assert.equal((diagnostics.models as any).geminiApiKey, undefined, 'geminiApiKey property must not be exposed');
  });

  return { passed, failed };
}
