import { startCompany } from './helpers.mjs';
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const S='/tmp/';
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium', args:['--no-sandbox'] });
const ctx = await b.newContext({ viewport:{width:1200,height:900}, locale:'fa-IR', acceptDownloads:true });
const p = await ctx.newPage(); const errs=[]; p.on('pageerror',e=>errs.push(e.message)); p.on('console',m=>{if(m.type()=='error')errs.push(m.text())});
let pass=0,fail=0; const ok=(c,n)=>{c?pass++:(fail++,console.log('FAIL',n))};
const tab=async n=>{await p.click(`nav.tabs button:has-text("${n}")`);await p.waitForTimeout(250)};
const sub=async n=>{await p.click(`#view [role=tab]:has-text("${n}")`);await p.waitForTimeout(300)};
await p.goto('file://'+process.cwd()+'/dist/index.html'); await startCompany(p);
const backDis=()=>p.$eval('nav.tabs .back',e=>e.disabled);
ok(await backDis(),'back disabled at start');
await tab('فروش'); await tab('گزارش‌ها'); await tab('تنظیمات'); await sub('بکاپ');
ok(!(await backDis()),'back enabled');
const cur=async()=>p.$eval('nav.tabs .tab.on',e=>e.textContent.trim());
await p.click('nav.tabs .back'); await p.waitForTimeout(300); ok((await p.innerText('#view')).includes('خروجی بکاپ')===false && await cur()==='تنظیمات','back from subtab → settings first subtab: '+await cur());
await p.click('nav.tabs .back'); await p.waitForTimeout(300); ok(await cur()==='گزارش‌ها','back → reports: '+await cur());
await p.click('nav.tabs .back'); await p.waitForTimeout(300); ok(await cur()==='فروش','back → sales');
await p.goBack(); await p.waitForTimeout(300); ok(await cur()==='خانه','browser back → home: '+await cur());
await p.screenshot({path:S+'back.png'});
// password
await tab('تنظیمات'); await sub('رمز عبور');
const pws=p.locator('#view input[type=password]'); await pws.nth(0).fill('abc'); await pws.nth(1).fill('abc'); await p.click('#view button:has-text("تنظیم رمز")'); await p.waitForTimeout(500);
ok(/۶|6|نویسه/.test(await p.innerText('#view')),'weak pw message');
await pws.nth(0).fill('secret-123'); await pws.nth(1).fill('secret-124'); await p.click('#view button:has-text("تنظیم رمز")'); await p.waitForTimeout(500);
ok((await p.innerText('#view')).includes('یکی نیست'),'mismatch message');
await pws.nth(0).fill('secret-123'); await pws.nth(1).fill('secret-123'); await p.click('#view button:has-text("تنظیم رمز")'); await p.waitForTimeout(1200);
ok(await p.evaluate(()=>AN_UI.store.hasPassword(AN_UI.ctx.uid)),'password set');
await p.screenshot({path:S+'sec.png'});
// erase per section (with password)
await sub('داده و حریم'); await p.screenshot({path:S+'erase0.png'});

await p.locator('#view .erase-row:has-text("فروش") button:has-text("حذف…")').first().click(); await p.waitForTimeout(300);
await p.screenshot({path:S+'erase1.png'});
const dlg='dialog[open] ';
await p.fill(dlg+'input[type=password]','wrong'); 
const [dl0]=await Promise.all([p.waitForEvent('download',{timeout:3000}).catch(()=>null),p.click(dlg+'button:has-text("حذف همیشگی")')]); await p.waitForTimeout(800);
ok(!dl0 && (await p.innerText('dialog[open]')).includes('اشتباه'),'wrong password blocks erase (no backup either)');
await p.fill(dlg+'input[type=password]','secret-123');
const [dl]=await Promise.all([p.waitForEvent('download'),p.click(dlg+'button:has-text("حذف همیشگی")')]); await p.waitForTimeout(1200);
console.log('DLNAME',dl.suggestedFilename());ok(dl.suggestedFilename().includes('backup_before_erase'),'backup downloaded first');
const st=await p.evaluate(()=>{const s=AN_UI.store,c=s.company(AN_UI.ctx);return [Object.values(c.invoices).filter(i=>i.kind==='sale').length,Object.values(c.invoices).filter(i=>i.kind==='purchase').length,s.verifyIntegrity(AN_UI.ctx).ok]});
ok(st[0]===0&&st[1]>0&&st[2],'sales erased only, integrity ok '+st);
// reload → lock screen
await p.reload(); await p.waitForTimeout(600);
ok((await p.innerText('body')).includes('قفل'),'lock screen after reload');
await p.screenshot({path:S+'lock.png'});
await p.fill('input[type=password]','nope'); await p.click('button:has-text("باز کردن")'); await p.waitForTimeout(800);
ok((await p.innerText('body')).includes('اشتباه'),'wrong unlock refused');
await p.fill('input[type=password]','secret-123'); await p.click('button:has-text("باز کردن")'); await p.waitForTimeout(900);
ok((await p.$('nav.tabs'))!==null,'unlock works');
// no-password erase uses typed word + English
await tab('تنظیمات'); await sub('رمز عبور'); await p.fill('#view .toolbar input[type=password]','secret-123'); await p.click('#view button:has-text("حذف رمز")'); await p.waitForTimeout(1200);
ok(!(await p.evaluate(()=>AN_UI.store.hasPassword(AN_UI.ctx.uid))),'password removed');
await sub('داده و حریم'); await p.locator('#view .erase-row:has-text("طرف‌حساب") button:has-text("حذف…")').last().click(); await p.waitForTimeout(300);
await p.fill('dialog[open] input.inp','x'); await p.click('dialog[open] button:has-text("حذف همیشگی")'); await p.waitForTimeout(300);
ok((await p.innerText('dialog[open]')).includes('بنویسید'),'typed word required when no password');
console.log('ERRS',errs,{pass,fail}); await b.close();
