const fs = require('fs');
const assert = require('assert');

const p = require('path').join(__dirname, '..', 'template', 'ai-result-template.json');
const d = JSON.parse(fs.readFileSync(p, 'utf8'));

assert.strictEqual(d.source_of_truth, 'MASTER RESULT');
assert.strictEqual(d.ai_semantic_model.model, 'A → B → C');
assert.match(d.ai_semantic_model.A, /WHAT IS THE CHART/);
assert.match(d.ai_semantic_model.B, /WHAT DOES THE CHART MEAN STRUCTURALLY/);
assert.match(d.ai_semantic_model.C, /WHAT HAPPENS WHEN TIME MOVES/);
assert.match(d.ai_semantic_model.boundary, /B is not a second chart/);
assert.match(d.ai_semantic_model.boundary, /C is not a third independent chart/);
assert.match(d.ai_semantic_model.principle, /does not adjudicate/);
assert.ok(d.ai_contract.not_allowed.includes('recalculate'));
assert.ok(d.ai_contract.not_allowed.includes('adjudicate'));
assert.ok(d.ai_contract.not_allowed.includes('promote status'));
assert.ok(d.ai_status_contract.rules.some(x => /CANDIDATE/.test(x) && /FINAL/.test(x)));
assert.ok(d.ai_status_contract.rules.some(x => /UNRESOLVED/.test(x)));
assert.ok(d.ai_status_contract.status_model && d.ai_status_contract.status_model.determination);
assert.ok(d.ai_status_contract.status_model && d.ai_status_contract.status_model.computation);
assert.ok(d.ai_status_contract.status_model && d.ai_status_contract.status_model.verification);

const forbiddenMapperTerms = [
  'preserve_docx_structure', 'preserve_section_order', 'mapping_role',
  'calculation_role', 'determination_role', 'internal_table_identifiers',
  'semantic_records', 'canonical_nodes'
];
const contractText = JSON.stringify({rules:d.rules, ai_contract:d.ai_contract, ai_semantic_model:d.ai_semantic_model, ai_status_contract:d.ai_status_contract});
for (const term of forbiddenMapperTerms) assert.ok(!contractText.includes(term), `unexpected AI contract implementation term: ${term}`);

console.log('AI Interpreter V1.17 contract: PASS');
