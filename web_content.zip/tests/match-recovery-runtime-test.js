const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const source = html.match(/<script>([\s\S]*)<\/script>/)[1] + '\n;globalThis.__test={newCareer,stateRef:()=>state,goMatch,liveMatchMatchesCurrentFixture,restoreLiveMatchRound};';
class Element { constructor(){this.innerHTML='';this.textContent='';this.value='';this.dataset={};this.style={};this.classList={add(){},remove(){},contains(){return false}};} querySelectorAll(){return [];} querySelector(){return new Element();} }
const elements={};
const document={querySelector(s){return elements[s]||(elements[s]=new Element());},querySelectorAll(){return [];},createElement(){return new Element();},body:new Element()};
const localStore={};
const localStorage={getItem(k){return localStore[k]??null;},setItem(k,v){localStore[k]=String(v);},removeItem(k){delete localStore[k];}};
const context={document,localStorage,console,Math,Date,JSON,Blob:function(){},URL:{createObjectURL(){return '';},revokeObjectURL(){}},confirm(){return true;},alert(){},setTimeout(){return 1;},clearTimeout(){},FormData:function(){},FileReader:function(){},navigator:{},performance:{now(){return 0;}}};
context.window=context;vm.createContext(context);vm.runInContext(source,context);
const app=context.__test;
app.newCareer({name:'Teste Partidas',nickname:'Teste',age:18,nation:'Brasileira',pos:'Ponta esquerda',secondary:'Meia-atacante',height:178,weight:72,foot:'Direito',number:10,club:'Internacional',potential:80,skin:'#b87d54',hair:'#30231c'});
const state=app.stateRef();state.day=7;state.liveMatch={season:1900,round:99,home:'Clube Inválido',away:'Outro Clube',phase:'firsthalf',events:[]};
app.goMatch();
if(!state.liveMatch || state.liveMatch.season!==state.season || state.liveMatch.round!==state.round+1 || state.liveMatch.home!==app.stateRef().fixtures[state.round][0].home && state.liveMatch.home!==app.stateRef().p.club) {
  // The important invariant is that the stale lock was replaced by a live session for the current career, not left blocking play.
  if(!state.liveMatch || state.liveMatch.season!==state.season || state.liveMatch.phase!=='halftime') throw new Error('Stale saved session still blocks match start');
}
if(state.liveMatch.phase!=='halftime' || !Array.isArray(state.liveMatch.events)) throw new Error('A new playable halftime session was not created');
console.log('PASS: a stale saved liveMatch is discarded and a new current-season match opens.');

// Regression: the saved match belongs to round 1, but the stale career counter says round 17.
const fixture0=state.fixtures[0].find(f=>f.home===state.p.club||f.away===state.p.club);
if(!fixture0) throw new Error('Test setup could not find player fixture in round 1');
state.round=16;
state.liveMatch={season:state.season,round:1,home:fixture0.home,away:fixture0.away,phase:'halftime',events:[{minute:45,type:'half',text:'INTERVALO!'}],statsUser:{},statsOpp:{},day:7};
if(!app.restoreLiveMatchRound() || state.round!==0) throw new Error('Saved halftime session did not restore the actual fixture round');
if(!app.liveMatchMatchesCurrentFixture()) throw new Error('Recovered halftime session is not recognized as current');
console.log('PASS: stale round 17 counter recovers the saved round 1 match without discarding halftime.');
