/**
 * JARVIS Automated Core Loop Tests
 * Verifies 11-stage pipeline, plan synthesis, tool execution, verification, and permission gating.
 */

import { strict as assert } from 'node:assert';
import { jarvisCore } from '../server/core/jarvisCore.ts';
import { initializeDatabase } from '../server/db/database.ts';
import { securityLayer } from '../server/security/securityLayer.ts';
import type { CoreLoopStage, SystemEvent } from '../server/types.ts';

export async function runCoreLoopTests(): Promise<{ passed: number; failed: number }> {
  console.log('\n--- Running Core Loop Tests ---');
  let passed = 0;
  let failed = 0;

  async function test(name: string, fn: () => Promise<void>) {
    try {
      await fn();
      console.log(`  [PASS] ${name}`);
      passed++;
    } catch (err: any) {
      console.error(`  [FAIL] ${name}:`, err.message);
      failed++;
    }
  }

  // Ensure DB is initialized
  await initializeDatabase();

  // 1. Basic 11-Stage Execution & Verification
  await test('full 11-stage execution and verification stage completion', async () => {
    const stagesSeen = new Set<CoreLoopStage>();

    const unsubscribe = jarvisCore.addEventListener((event: SystemEvent) => {
      if (event.stage) {
        stagesSeen.add(event.stage);
      }
    });

    const result = await jarvisCore.executeTask(
      'Calculate 12 * 12 and verify result',
      'usr_jarvis_prime',
      'conv_default'
    );

    unsubscribe();

    assert.ok(result.task, 'Task object must be returned');
    assert.ok(result.assistantMessage, 'Assistant response message must be returned');
    assert.equal(result.task.status, 'COMPLETED');
    assert.ok(result.task.resultSummary, 'Result summary should be set');

    // Verify key 11-stage milestones occurred
    assert.ok(stagesSeen.has('PERCEIVE'), 'Stage PERCEIVE must be reached');
    assert.ok(stagesSeen.has('PLAN'), 'Stage PLAN must be reached');
    assert.ok(stagesSeen.has('EXECUTE'), 'Stage EXECUTE must be reached');
    assert.ok(stagesSeen.has('VERIFY'), 'Stage VERIFY must be reached');
    assert.ok(stagesSeen.has('RESPOND'), 'Stage RESPOND must be reached');

    // Verify verification result
    const plan = result.task.plan;
    assert.ok(plan, 'Plan must exist on task');
    assert.ok(plan.steps.length > 0, 'Plan must have steps');
    const verifiedStep = plan.steps.find((s) => s.verificationResult !== undefined);
    assert.ok(verifiedStep, 'At least one step must contain verification result');
    assert.equal(verifiedStep?.verificationResult?.passed, true);
  });

  // 2. Permission-Gated Workflow
  await test('permission-gated workflow and approval resumption', async () => {
    // Directly verify security requirement detection
    const requiresSensitiveApproval = securityLayer.requiresApproval('EXTERNAL_ACTION');
    assert.equal(requiresSensitiveApproval, true, 'EXTERNAL_ACTION must require operator authorization');

    const safeWriteRequiresApproval = securityLayer.requiresApproval('SAFE_WRITE');
    assert.equal(safeWriteRequiresApproval, false, 'SAFE_WRITE should not block for operator approval');

    // Execute a task that triggers external action
    const result = await jarvisCore.executeTask(
      'Automate external dispatch to notification webhook',
      'usr_jarvis_prime',
      'conv_default'
    );

    assert.ok(result.task);
    assert.equal(result.task.status, 'WAITING_PERMISSION');
    assert.ok(result.task.pendingPermissionStep);

    // Test approval and resumption
    const resumedTask = await jarvisCore.approveAndResumeTask(result.task.id);
    assert.ok(resumedTask);
    assert.equal(resumedTask.status, 'COMPLETED');
  });

  return { passed, failed };
}
