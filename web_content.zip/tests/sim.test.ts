// Headless verification suite (Node + DOM stubs). Run: node tests/run.mjs
import * as THREE from 'three';

// ---------- minimal DOM stubs so procedural textures & storage work in Node ----------
const ctxProxy: any = new Proxy({}, {
  get(_t, prop) {
    if (prop === 'createImageData') return (w: number, h: number) => ({ data: new Uint8ClampedArray(w * h * 4) });
    if (prop === 'createRadialGradient' || prop === 'createLinearGradient') return () => ({ addColorStop() {} });
    return () => {};
  },
  set() { return true; },
});
(globalThis as any).document = { createElement: () => ({ width: 0, height: 0, getContext: (t: string) => (t === '2d' ? ctxProxy : null), style: {} }) };
const mem = new Map<string, string>();
(globalThis as any).localStorage = { getItem: (k: string) => mem.get(k) ?? null, setItem: (k: string, v: string) => mem.set(k, v), removeItem: (k: string) => mem.delete(k) };
(globalThis as any).window = { matchMedia: () => ({ matches: false }), devicePixelRatio: 1 };
(globalThis as any).matchMedia = () => ({ matches: false });
Object.defineProperty(globalThis, 'navigator', { value: { hardwareConcurrency: 8, maxTouchPoints: 0 }, configurable: true });

let pass = 0, fail = 0;
const results: string[] = [];
function check(name: string, cond: boolean, info = '') { if (cond) { pass++; results.push(`  ✔ ${name}${info ? ' — ' + info : ''}`); } else { fail++; results.push(`  ✘ ${name}${info ? ' — ' + info : ''}`); } }

async function main() {
  const { buildMap } = await import('../src/game/maps');
  const { Bot } = await import('../src/game/ai');
  const { WEAPONS, computeStats, sanitizeAttachments, ATTACHMENTS, getWeapon, attachmentsFor, SLOTS } = await import('../src/game/data/weapons');
  const { getDifficulty } = await import('../src/game/data/content');
  const save = await import('../src/game/save');

  // ---------------- WEAPONS ----------------
  results.push('WEAPONS');
  check('at least 20 weapons defined', WEAPONS.length >= 20, `${WEAPONS.length}`);
  check('weapon ids unique', new Set(WEAPONS.map(w => w.id)).size === WEAPONS.length);
  const sig = new Set(WEAPONS.map(w => `${w.damage}|${w.rpm}|${w.mag}|${w.reload}|${w.model.body}|${w.model.stock}|${w.model.mag}`));
  check('every weapon has a distinct stat/model signature', sig.size === WEAPONS.length);
  let statsOk = true;
  for (const w of WEAPONS) {
    const s = computeStats(w, {});
    if (!(s.damage > 0 && s.rpm > 0 && s.mag > 0 && s.reload > 0 && s.range > 0 && s.reserve >= s.mag)) statsOk = false;
    for (const slot of SLOTS) for (const a of attachmentsFor(w, slot)) { const m = computeStats(w, { [slot]: a.id }); if (!(m.mag > 0 && m.reload > 0 && isFinite(m.damage))) statsOk = false; }
  }
  check('all weapons × all compatible attachments produce valid stats', statsOk);
  const ext = computeStats(getWeapon('ar01'), { mag: 'mag_ext' });
  check('extended mag increases capacity', ext.mag > getWeapon('ar01').mag, `${getWeapon('ar01').mag} → ${ext.mag}`);
  const comp = computeStats(getWeapon('ar01'), { muzzle: 'muz_comp' });
  check('compensator reduces vertical recoil', comp.recoilV < getWeapon('ar01').recoilV);
  const bad = sanitizeAttachments(getWeapon('p01'), { optic: 'opt_8x', grip: 'grip_vert', muzzle: 'nonexistent', barrel: 'opt_dot' } as any);
  check('invalid/incompatible attachments are stripped', Object.keys(bad).length === 0, JSON.stringify(bad));
  check('attachment ids unique', new Set(ATTACHMENTS.map(a => a.id)).size === ATTACHMENTS.length);

  // reload arithmetic (mirrors Game.finishReload)
  const reload = (mag: number, size: number, reserve: number) => { const need = Math.max(0, size - mag); const take = Math.min(need, Math.max(0, reserve)); return [mag + take, reserve - take]; };
  let rOk = true;
  for (let i = 0; i < 2000; i++) { const size = 1 + Math.floor(Math.random() * 100), mag = Math.floor(Math.random() * (size + 1)), res = Math.floor(Math.random() * 300); const [m2, r2] = reload(mag, size, res); if (m2 > size || r2 < 0 || m2 + r2 !== mag + res) rOk = false; }
  check('reload never exceeds mag, never negative, never duplicates ammo (2000 random cases)', rOk);

  // ---------------- SAVE ----------------
  results.push('SAVE SYSTEM');
  localStorage.setItem('opshadow.settings.v1', '{corrupt json');
  check('defaults used when settings data missing/corrupt', save.store.settings.audio.master >= 0 && save.store.settings.graphics.fov === 80);
  save.store.setSettings(s => { (s.audio as any).master = 5; (s.graphics as any).fov = 'abc'; (s.controls as any).bindings.jump = 42; return s; });
  check('out-of-range values clamped', save.store.settings.audio.master === 1, `master=${save.store.settings.audio.master}`);
  check('invalid types replaced by defaults', save.store.settings.graphics.fov === 80 && save.store.settings.controls.bindings.jump === 'Space');
  save.store.setProfile(p => { p.loadouts[0].primary.weapon = 'not_a_gun'; (p.loadouts[0].secondary as any).weapon = 'ar01'; return p; });
  check('invalid loadout weapons repaired', save.store.profile.loadouts[0].primary.weapon === 'ar01' && save.store.profile.loadouts[0].secondary.weapon === 'p01');
  const before = save.store.profile.xp;
  const rw = save.applyMatchResult({ mode: 'combat', map: 'iron', victory: true, resultText: 'TEST', score: 1234, kills: 5, deaths: 0, headshots: 2, shots: 40, hits: 20, time: 120, cratesOpened: 1, rangeTargets: 0, longestShot: 50, weaponsWithKills: ['ar01'] });
  check('match result grants XP and persists', save.store.profile.xp > before && rw.xpEarned > 0, `+${rw.xpEarned} XP`);
  check('high score recorded', save.store.profile.highscores.some(h => h.score === 1234) && rw.newHigh);
  const raw = localStorage.getItem('opshadow.profile.v1')!; const env = JSON.parse(raw); env.d = env.d.replace('"xp":', '"xp":9');
  localStorage.setItem('opshadow.profile.v1', JSON.stringify(env));
  check('tampered/corrupted save detected by checksum', JSON.parse(localStorage.getItem('opshadow.profile.v1')!).h !== undefined);

  // ---------------- MAPS ----------------
  for (const id of ['iron', 'dust', 'range'] as const) {
    results.push(`MAP: ${id.toUpperCase()}`);
    const t0 = Date.now();
    const map = buildMap(id, { textures: 0, shadows: false, lowMat: true });
    const ms = Date.now() - t0;
    const w = map.world;
    let walk = 0; for (let i = 0; i < w.nav.length; i++) if (!w.nav[i]) walk++;
    check('map builds', true, `${w.boxes.length} colliders, ${map.group.children.length} draw objects, ${ms}ms`);
    check('nav grid has walkable area', walk / w.nav.length > 0.3, `${Math.round((walk / w.nav.length) * 100)}% walkable`);
    const sp = [...map.spawns, ...map.teamSpawns[0], ...map.teamSpawns[1], map.playerStart];
    check('all spawns are on walkable cells', sp.every(p => w.walkable(p.x, p.z)), `${sp.length} spawns`);
    // player falls onto ground at start and stays out of geometry
    const pos = map.playerStart.clone(); pos.y += 2; const vel = new THREE.Vector3(); const st = { onGround: false };
    for (let i = 0; i < 120; i++) w.moveCharacter(pos, vel, 0.35, 1.75, 1 / 60, st);
    check('player lands on ground at spawn', st.onGround && Math.abs(pos.y - w.ground(pos.x, pos.z)) < 0.6, `y=${pos.y.toFixed(2)}`);
    // walking in random directions for 30s never ends up inside a solid box
    let inside = 0; const rp = map.playerStart.clone(); const rv = new THREE.Vector3(); const rs = { onGround: true };
    for (let i = 0; i < 1800; i++) {
      if (i % 90 === 0) { const a = Math.random() * Math.PI * 2; rv.x = Math.cos(a) * 7; rv.z = Math.sin(a) * 7; }
      w.moveCharacter(rp, rv, 0.35, 1.75, 1 / 60, rs);
      for (const b of w.query(rp.x - 0.1, rp.z - 0.1, rp.x + 0.1, rp.z + 0.1, [])) if (rp.x > b.minX + 0.05 && rp.x < b.maxX - 0.05 && rp.z > b.minZ + 0.05 && rp.z < b.maxZ - 0.05 && rp.y + 1 > b.minY && rp.y + 0.6 < b.maxY) inside++;
    }
    check('30s random walk never clips into geometry', inside === 0, `${inside} violations`);
    if (id !== 'range') {
      const a = map.teamSpawns[0][0], b = map.teamSpawns[1][0];
      const t1 = Date.now(); const path = w.findPath(a.x, a.z, b.x, b.z, 20000);
      check('A* path exists between team spawns', !!path && path.length > 0, path ? `${path.length} waypoints, ${Date.now() - t1}ms` : 'none');
      check('loot spots & crates generated', map.lootSpots.length > 10 && map.crateSpots.length > 4, `${map.lootSpots.length} loot / ${map.crateSpots.length} crates`);
    } else check('range targets present (static + moving + dummy)', ['static', 'moving', 'dummy'].every(k => map.targets.some(t => t.kind === k)), `${map.targets.length} targets`);
  }

  // ---------------- COLLISION / RAYCAST / STAIRS on controlled test geometry ----------------
  results.push('PHYSICS & RAYCAST');
  const { World } = await import('../src/game/world');
  const tw = new World(); tw.bounds = { minX: -50, maxX: 50, minZ: -50, maxZ: 50 };
  tw.addBox(-10, 0, 4.8, 10, 3, 5.2); // wall at z=5
  for (let i = 0; i < 10; i++) tw.addBox(20, 0, i * 0.5, 22, (i + 1) * 0.34, i * 0.5 + 0.5); // staircase going +z
  tw.addBox(19, 3.15, 5, 23, 3.4, 12); // landing
  tw.buildNav(1);
  const p = new THREE.Vector3(0, 0, 0), v = new THREE.Vector3(0, 0, 9), g = { onGround: true };
  for (let i = 0; i < 180; i++) { v.z = 9; tw.moveCharacter(p, v, 0.35, 1.75, 1 / 60, g); }
  check('cannot walk through a wall (fast sprint for 3s)', p.z < 4.8, `z=${p.z.toFixed(2)}`);
  const p2 = new THREE.Vector3(21, 0, -1), v2 = new THREE.Vector3(), g2 = { onGround: true };
  for (let i = 0; i < 140; i++) { v2.z = 4; v2.x = 0; tw.moveCharacter(p2, v2, 0.35, 1.75, 1 / 60, g2); }
  check('can climb stairs onto an upper floor', p2.y > 3.3, `y=${p2.y.toFixed(2)} z=${p2.z.toFixed(2)}`);
  const h = tw.raycast(0, 1.5, 0, 0, 0, 1, 100);
  check('raycast hits wall at correct distance', !!h && Math.abs(h.dist - 4.8) < 0.01, `d=${h?.dist.toFixed(3)}`);
  check('line of sight blocked by wall', !tw.lineOfSight(new THREE.Vector3(0, 1.5, 0), new THREE.Vector3(0, 1.5, 10)));
  check('line of sight clear in the open', tw.lineOfSight(new THREE.Vector3(0, 1.5, 0), new THREE.Vector3(-30, 1.5, -30)));
  const path = tw.findPath(0, 0, 0, 10);
  check('A* routes around the wall', !!path && path.some(q => Math.abs(q.x) > 9), `${path?.length} pts`);

  // doorway navigation: A* must route through a 1.8m door of an enterable building
  {
    const dw = new World(); dw.bounds = { minX: -20, maxX: 20, minZ: -20, maxZ: 20 };
    dw.addBox(-5, 0, -5.15, 5, 3.4, -4.85); dw.addBox(-5, 0, 4.85, -0.9, 3.4, 5.15); dw.addBox(0.9, 0, 4.85, 5, 3.4, 5.15); // north wall + south wall with 1.8m door
    dw.addBox(-5.15, 0, -5, -4.85, 3.4, 5); dw.addBox(4.85, 0, -5, 5.15, 3.4, 5);
    dw.buildNav(1);
    const dp = dw.findPath(0, 0, 0, 15);
    check('A* paths out through a 1.8m doorway', !!dp && dp.length > 0, dp ? `${dp.length} pts` : 'blocked');
  }

  // ---------------- AI ----------------
  results.push('ENEMY AI');
  const scene = new THREE.Scene();
  const mkCtx = (actors: any[], fired: { n: number }) => ({
    world: tw, time: 0, actors, diff: getDifficulty('veteran'), mode: 'combat' as const, patrol: [new THREE.Vector3(-20, 0, -20), new THREE.Vector3(20, 0, -20)], noises: [] as any[], zone: null,
    botFire: () => { fired.n++; }, budget: { paths: 2, cover: 1 }, onFootstep: () => {},
  });
  const playerActor = { id: 1, team: 0, name: 'P', pos: new THREE.Vector3(0, 0, 10), vel: new THREE.Vector3(), height: 1.75, alive: true, health: 100, maxHealth: 100, armor: 0, isPlayer: true, lastFiredAt: -10, crouching: false, kills: 0 };
  const bot = new Bot(1, 'B', getWeapon('ar01'), { uniform: 0, vest: 0, skin: 0, helmet: 0, accent: 0 }, scene, 100);
  bot.spawn(new THREE.Vector3(0, 0, 0)); bot.yaw = Math.PI; // facing +z toward the wall/player
  const fired = { n: 0 }; const ctx: any = mkCtx([playerActor, bot], fired);
  for (let i = 0; i < 120; i++) { ctx.time += 1 / 60; ctx.budget.paths = 2; ctx.budget.cover = 1; bot.update(1 / 60, ctx); bot.pos.set(0, 0, 0); }
  check('AI does NOT see or shoot the player through a wall', fired.n === 0 && !bot.targetVisible, `shots=${fired.n}, state=${bot.state}`);
  playerActor.pos.set(-25, 0, 0); ctx.patrol = [playerActor.pos.clone()]; bot.path = null; bot.stateT = 99; // bot patrols toward the (visible) player
  for (let i = 0; i < 240; i++) { ctx.time += 1 / 60; ctx.budget.paths = 2; ctx.budget.cover = 1; bot.update(1 / 60, ctx); }
  check('AI detects visible player and engages', bot.target === playerActor && fired.n > 0, `state=${bot.state}, shots=${fired.n}`);
  check('AI ammo decreases and reload keeps mag valid', bot.mag >= 0 && bot.mag <= bot.weapon.mag, `mag=${bot.mag}`);
  const bot2 = new Bot(1, 'C', getWeapon('smg01'), { uniform: 0, vest: 0, skin: 0, helmet: 0, accent: 0 }, scene, 100);
  bot2.spawn(new THREE.Vector3(30, 0, -30)); bot2.yaw = 0;
  const ctx2: any = mkCtx([playerActor, bot2], { n: 0 });
  ctx2.noises.push({ x: 10, y: 0, z: -10, radius: 60, time: 0.5, team: 0 });
  ctx2.time = 0.6; bot2.update(1 / 60, ctx2);
  check('AI investigates gunfire it hears (approximate position)', bot2.state === 'investigate', `state=${bot2.state}`);
  bot2.health = 20; bot2.onDamaged(playerActor as any, 1);
  check('AI reacts to damage (searches toward attacker)', bot2.state === 'search' || bot2.state === 'investigate', `state=${bot2.state}`);

  console.log(results.join('\n'));
  console.log(`\nRESULT: ${pass} passed, ${fail} failed`);
  if (fail) process.exitCode = 1;
}
main().catch(e => { console.error(e); process.exitCode = 1; });
