import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState } from '../src/store.js';
import { generateSeasonCalendar } from '../src/calendar.js';
import { getCurrentMatchday, simulateFixture, simulateNextMatchday, simulateUserMatch } from '../src/season-engine.js';
import { createManagerProfile } from '../src/career.js';
import { ensureClubOffice } from '../src/manager-office.js';

function setup() { const s=createInitialState(); generateSeasonCalendar(s); return s; }
test('une journée simule les rencontres des autres clubs et réserve celle du club dirigé',()=>{
  const s=setup(), day=getCurrentMatchday(s); const user=day.fixtures.find(f=>f.home===s.userClubId||f.away===s.userClubId);
  assert.ok(user); const result=simulateNextMatchday(s);
  assert.equal(result.round,1); assert.ok(result.simulated.length>0); assert.equal(result.userFixture.id,user.id);
  assert.equal(user.status,'scheduled'); assert.equal(s.calendar.processedFixtureIds.length,result.simulated.length);
});
test('le match du club dirigé peut être simulé et met à jour le classement une seule fois',()=>{
  const s=setup(), f=getCurrentMatchday(s).fixtures.find(x=>x.home===s.userClubId||x.away===s.userClubId);
  const before=s.divisions.flatMap(d=>d.clubs).find(c=>c.id===s.userClubId).played;
  assert.equal(simulateUserMatch(s,f.id),true); assert.equal(simulateUserMatch(s,f.id),false);
  const after=s.divisions.flatMap(d=>d.clubs).find(c=>c.id===s.userClubId).played;
  assert.equal(after,before+1); assert.equal(s.calendar.processedFixtureIds.filter(id=>id===f.id).length,1);
});
test('la simulation est reproductible pour une même rencontre',()=>{
  const a=setup(),b=setup(),id=getCurrentMatchday(a).fixtures[0].id;
  simulateFixture(a,id); simulateFixture(b,id);
  assert.deepEqual(a.calendar.fixtures.find(f=>f.id===id).score,b.calendar.fixtures.find(f=>f.id===id).score);
});
test('la journée suivante ne s’ouvre pas tant que le match du club dirigé reste en attente',()=>{
  const s=setup(); const result=simulateNextMatchday(s);
  assert.equal(result.complete,false); assert.equal(s.day,1);
  simulateUserMatch(s,result.userFixture.id);
  const second=simulateNextMatchday(s);
  assert.equal(second.round,2);
});

test('la simulation complète d’une journée traite toutes les rencontres, y compris celle du club',()=>{
  const s=setup(); const first=getCurrentMatchday(s);
  const result=simulateNextMatchday(s,{simulateUser:true});
  assert.equal(result.simulated.length,first.fixtures.length); assert.equal(result.complete,true);
  assert.ok(first.fixtures.every(f=>f.status==='played')); assert.equal(s.day,2);
});


test('delegated assistant preparation is included in the managed club automatic fixture strength',()=>{
 const s=setup();createManagerProfile({firstName:'Awa',lastName:'Diallo',galaxy:s.world.galaxies[0].name,mode:'club',sex:'Femme',reputation:'Locale',clubId:s.divisions[0].clubs[0].id},s);
 const office=ensureClubOffice(s).office;office.staff.find(x=>x.id==='assistant').rating=100;office.delegation['match-preparation']=true;
 const fixture=getCurrentMatchday(s).fixtures.find(f=>f.home===s.userClubId||f.away===s.userClubId);assert.ok(fixture);
 assert.equal(simulateFixture(s,fixture.id),true);assert.equal(fixture.matchDetails.staffPreparationBonus,2.5);
 const managedStrength=fixture.home===s.userClubId?fixture.matchDetails.homeStrength:fixture.matchDetails.awayStrength;
 const damiste=fixture.damisteSelections?.[fixture.home===s.userClubId?'home':'away'];
 assert.ok(managedStrength>=52.5);assert.ok(damiste);
});
