const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const app = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const sw = fs.readFileSync(path.join(__dirname, '..', 'sw.js'), 'utf8');

test('database v5 upgrade keeps existing stores and the duplicate-tracking lookup index', () => {
  assert.match(app, /DB_VERSION=5/);
  assert.match(app, /createIndex\('byPosDayTracking',\['posCode','day','trackingCode'\]/);
  assert.match(app, /indexedDB\.open\(DB_NAME,DB_VERSION\)/);
});

test('sale and stock changes share one IndexedDB read-write transaction', () => {
  assert.match(app, /db\.transaction\(\['sales','stock','movements'\],'readwrite'\)/);
  assert.match(app, /salesStore\.add\(result\.sale\)/);
  assert.match(app, /stockStore\.put\(updatedStock\)/);
  assert.match(app, /transaction\.oncomplete/);
  assert.match(app, /transaction\.onabort/);
});

test('sale domain module is loaded before the application and included in offline cache', () => {
  assert.match(html, /seed\.js[\s\S]*sales-domain\.js[\s\S]*app\.js/);
  assert.match(sw, /mr-khorasani-shell-v7/);
  assert.match(sw, /\.\/sales-domain\.js/);
});

test('historical sale-stock audit is exposed as a read-only control in settings', () => {
  assert.match(app, /SaleDomain\.auditSalesInventory/);
  assert.match(app, /runInventoryAudit/);
  assert.match(app, /هیچ رکوردی را خودکار اصلاح نمی‌کند/);
});

test('old sequential sale write path is no longer present', () => {
  assert.doesNotMatch(app, /await put\('sales',sale\)/);
  assert.doesNotMatch(app, /await put\('stock',st\)/);
});

test('database v5 preserves movement ledger and transfer indexes without replacing existing object stores', () => {
  assert.match(app, /DB_VERSION=5/);
  assert.match(app, /createIndex\('bySourceSale','sourceSaleId'/);
  assert.match(app, /createIndex\('byStockAt',\['stockId','at'\]/);
  assert.match(app, /createIndex\('byTransferId','transferId'/);
});

test('manual inventory movements update stock and ledger in one transaction', () => {
  assert.match(app, /db\.transaction\(\['stock','movements'\],'readwrite'\)/);
  assert.match(app, /function saveInventoryMovementAtomically/);
  assert.match(app, /ledger\.add\(prepared\.movement\)/);
});

test('sale returns atomically update stock and persist source-linked movement rows', () => {
  assert.match(app, /function saveSaleReturnAtomically/);
  assert.match(app, /db\.transaction\(\['sales','stock','movements'\],'readwrite'\)/);
  assert.match(app, /sourceSaleId/);
  assert.match(app, /prepared\.ledgerMovements/);
});

test('accountant-only inventory controls expose count, receipt, issue, adjustment and returns', () => {
  assert.match(app, /ثبت گردش و شمارش موجودی/);
  for (const type of ['COUNT', 'ADJUST_UP', 'ADJUST_DOWN']) assert.ok(app.includes(`value=\"${type}\"`) || app.includes(`value="${type}"`));
  assert.match(app, /ثبت برگشت از فروش/);
});

test('movement ledger audit is available to accountant and stock count resets unknown balance', () => {
  assert.match(app, /SaleDomain\.auditInventoryLedger/);
  assert.match(app, /ممیزی دفتر گردش/);
  assert.match(fs.readFileSync(path.join(__dirname, '..', 'sales-domain.js'), 'utf8'), /movement\.type === 'COUNT'/);
});

test('inventory mutation handlers enforce accountant role in addition to hiding controls', () => {
  assert.match(app, /function saveInventoryMovementAtomically\(input\)\{return new Promise\(\(resolve,reject\)=>\{if\(!isAccountant\(\)\)/);
  assert.match(app, /function saveSaleReturnAtomically\(input\)\{return new Promise\(\(resolve,reject\)=>\{if\(!isAccountant\(\)\)/);
});


test('booth transfer writes paired movements and stock updates in one IndexedDB transaction', () => {
  assert.match(app, /function saveInventoryTransferAtomically/);
  assert.match(app, /db\.transaction\(\['stock','movements'\],'readwrite'\)/);
  assert.match(app, /ledger\.index\('byTransferId'\)/);
  assert.match(app, /SaleDomain\.prepareInventoryTransfer/);
  assert.match(app, /prepared\.sourceStock/);
  assert.match(app, /prepared\.destinationStock/);
  assert.match(app, /for\(const movement of prepared\.movements\)ledger\.add\(movement\)/);
});

test('product cardex has booth/product/date filters and uses the domain balance calculation', () => {
  assert.match(app, /function runProductCardex/);
  assert.match(app, /SaleDomain\.buildProductCardex/);
  assert.match(app, /id="cardexBooth"/);
  assert.match(app, /id="cardexProduct"/);
  assert.match(app, /id="cardexFrom"/);
  assert.match(app, /id="cardexTo"/);
});

test('new transfer movement types appear in recent movement history', () => {
  assert.match(app, /TRANSFER_OUT/);
  assert.match(app, /TRANSFER_IN/);
});

test('booth users are restricted to the sale view in navigation and view routing', () => {
  assert.match(app, /function canAccessView\(view\)/);
  assert.match(app, /if\(!canAccessView\(v\)\)/);
  assert.match(app, /function applyRoleNavigation\(\)/);
  assert.match(app, /booth-mode/);
});

test('sale form supports multiple POS, cash and personnel payment rows and booth-holder receivable', () => {
  assert.match(app, /id="paymentRows"/);
  assert.match(app, /id="addPaymentRow"/);
  assert.match(app, /id="paymentSummary"/);
  assert.match(app, /receivableAccountName/);
  assert.match(app, /settlementStatus/);
});

test('sales are written with settlement data in the same transaction as stock changes', () => {
  assert.match(app, /payments=collectPaymentRows\(\)/);
  assert.match(app, /payments,cart:cart\.map/);
  assert.match(app, /existingSales/);
  assert.match(app, /function boothHolderName\(/);
});

test('navy and gold bold theme applies to the complete workspace', () => {
  assert.match(fs.readFileSync(path.join(__dirname, '..', 'styles.css'), 'utf8'), /\.app-shell[\s\S]*--workspace-navy/);
  assert.match(fs.readFileSync(path.join(__dirname, '..', 'styles.css'), 'utf8'), /font-weight:\s*800/);
});

test('loads the navy and gold stylesheet after the legacy inline styles so the theme wins the cascade', () => {
  const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
  assert.ok(html.indexOf('</style>') < html.indexOf('<link rel="stylesheet" href="styles.css">'));
});

test('booth sales UI never reveals stock quantities while preserving inventory validation', () => {
  assert.ok(app.includes('const stockDetails=isAccountant()?'));
  assert.ok(app.includes('این کالا در حال حاضر قابل ثبت فروش نیست'));
  assert.ok(app.includes('SaleDomain.getCurrentStock(st)'));
});


test('accountant retains mobile navigation while booth users keep it hidden', () => {
  const css = fs.readFileSync(path.join(__dirname, '..', 'styles.css'), 'utf8');
  assert.match(css, /\.bottom-nav\{display:flex\}/);
  assert.match(css, /\.bottom-nav\.hidden\{display:none!important\}/);
});


test('v5 creates a separate purchases store and migrates central stock rows without deleting prior stores', () => {
  assert.match(app, /DB_VERSION=5/);
  assert.match(app, /'movements','purchases'/);
  assert.match(app, /ensureCentralWarehouseRows/);
  assert.match(app, /CENTRAL::\$\{p\.key\}/);
});

test('purchase receipts are accountant-only and atomically update purchases, central stock and movement ledger', () => {
  assert.match(app, /function saveCentralPurchaseAtomically/);
  assert.match(app, /if\(!isAccountant\(\)\)\{reject\(new Error\('ثبت خرید فقط برای حسابدار مجاز است/);
  assert.match(app, /db\.transaction\(\['purchases','stock','movements'\],'readwrite'\)/);
  assert.match(app, /SaleDomain\.prepareCentralPurchase/);
  assert.match(app, /id="purchaseDate" type="date"/);
});

test('central-to-booth warehouse transfers are accountant-only and atomically post paired movements', () => {
  assert.match(app, /function saveCentralTransferAtomically/);
  assert.match(app, /ثبت حواله انبار فقط برای حسابدار مجاز است/);
  assert.match(app, /SaleDomain\.prepareCentralTransfer/);
  assert.match(app, /id="centralTransferBooth"/);
  assert.match(app, /WAREHOUSE_TRANSFER_OUT/);
  assert.match(app, /WAREHOUSE_TRANSFER_IN/);
});

test('accountant controls sales effective date while booth sale date is system-generated and hidden', () => {
  assert.match(app, /isAccountant\(\)\?`<div class="field" style="margin:10px 0"><label>تاریخ فروش/);
  assert.match(app, /<input id="saleDate" type="hidden" value="\$\{localDay\(\)\}">/);
});

test('cardex supports central warehouse as a location and purchases are included in backup and restore', () => {
  assert.match(app, /option value="CENTRAL">انبار مرکزی/);
  assert.match(app, /purchases:await getAll\('purchases'\)/);
  assert.match(app, /'movements','purchases'\]\)for/);
});


test('booth sale write path rejects a manually supplied date other than the device day', () => {
  assert.match(app, /if\(!isAccountant\(\)&&input\.day!==localDay\(\)\)\{reject\(new Error\('تاریخ فروش غرفه‌دار به‌صورت خودکار تعیین می‌شود و قابل تغییر نیست/);
});


test('direct booth IN/OUT movements are blocked so purchase receipts and issues flow through central warehouse', () => {
  assert.match(app, /if\(\['IN','OUT'\]\.includes\(input\.type\)\)\{reject\(new Error\('ورود خرید فقط از رسید انبار مرکزی/);
  assert.doesNotMatch(app, /<option value="IN">ورود کالا<\/option>/);
  assert.doesNotMatch(app, /<option value="OUT">خروج کالا<\/option>/);
});
