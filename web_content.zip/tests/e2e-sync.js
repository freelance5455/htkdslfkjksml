let chromium;try{({chromium}=require('playwright'))}catch(e){try{({chromium}=require('/home/claude/.npm-global/lib/node_modules/playwright'))}catch(e2){console.error('Install playwright first: npm i -D playwright && npx playwright install chromium');process.exit(2)}}
const {spawn}=require('child_process');const fs=require('fs'),assert=require('assert'),path=require('path'),os=require('os');const DB=path.join(os.tmpdir(),'cp-e2e.json');
const APP='file://'+path.resolve(__dirname,'../app/index.html'),PORT='8931',wait=ms=>new Promise(r=>setTimeout(r,ms));
try{fs.unlinkSync(DB)}catch(e){}
const srv=spawn(process.execPath,[path.resolve(__dirname,'../server/server.js')],{env:{...process.env,PORT,HOST:'127.0.0.1',CP_DATA_FILE:DB,CP_JWT_SECRET:'q'.repeat(40),CP_ADMIN_KEY:'k'.repeat(30),CP_OTP_IP_LIMIT:'100',CP_OTP_VERIFY_LIMIT:'100'}});let out='';srv.stdout.on('data',d=>out+=d);srv.stderr.on('data',d=>out+=d);
(async()=>{await wait(900);const b=await chromium.launch();const errs=[];
 async function device(name){const c=await b.newContext({viewport:{width:390,height:800}});const p=await c.newPage();p.on('pageerror',e=>errs.push(name+': '+e.message));p.on('dialog',d=>d.accept().catch(()=>{}));await p.goto(APP);await p.waitForTimeout(500);
  await p.evaluate(ep=>{d.sync.endpoint=ep;d.sync.enabled=true;persist()},'http://127.0.0.1:'+PORT);return p}
 const status=p=>p.evaluate(()=>document.getElementById('clMsg')?.textContent);
 async function login(p,email){await p.evaluate(()=>cp12PrepareSync());await p.fill('#clEmail',email);await p.click('text=ارسال کد');await wait(300);
  const code=out.split('\n').filter(l=>l.includes('[Contractor Pro OTP]')&&l.includes(email)).pop().trim().split(/\s+/).pop();
  await p.fill('#clCode',code);await p.click('text=تأیید و ورود');await wait(1200);}
 const A=await device('A'),B=await device('B');
 await login(A,'owner@example.com');
 console.log('A status:',await status(A));
 await A.evaluate(()=>{d.clients.push({id:'cl1',name:'احمدی',createdAt:new Date().toISOString()});d.projects.push({id:'pr1',name:'پله گرد داربند',client:'cl1',amount:5e7,createdAt:new Date().toISOString()});persist()});
 await A.evaluate(()=>cpCloudSync());await wait(900);
 await login(B,'owner@example.com');
 const B1=await B.evaluate(()=>({c:d.clients.map(x=>x.name),p:d.projects.map(x=>x.name)}));console.log('B after first sync:',JSON.stringify(B1));
 assert.deepEqual(B1.p,['پله گرد داربند']);
 // B edits project, adds inventory; A syncs and receives
 await wait(1100);
 await B.evaluate(()=>{const p=d.projects[0];p.name='پله گرد داربند (ویرایش B)';p.updatedAt=new Date().toISOString();d.inventory.push({id:'iv1',name:'سیمان',unit:'کیسه',status:'in',quantity:40,createdAt:new Date().toISOString()});persist();return cpCloudSync()});await wait(900);
 await A.evaluate(()=>cpCloudSync());await wait(900);
 const A2=await A.evaluate(()=>({p:d.projects[0].name,inv:d.inventory.length}));console.log('A after B edit:',JSON.stringify(A2));assert.equal(A2.inv,1);assert(A2.p.includes('ویرایش B'));
 // A deletes client via real deleteRecord, syncs; B must lose it (no resurrection)
 await A.evaluate(()=>{window.confirm=()=>true;deleteRecord('clients','cl1')});await A.evaluate(()=>cpCloudSync());await wait(900);
 await B.evaluate(()=>cpCloudSync());await wait(900);
 const B3=await B.evaluate(()=>d.clients.length);console.log('B clients after A delete:',B3);assert.equal(B3,0);
 // stale-conflict: B pushes between A pull and push -> A must merge, not overwrite
 await A.evaluate(()=>{d.dailyLogs.push({id:'lg-A',name:'A log',createdAt:new Date().toISOString()});persist()});
 await B.evaluate(()=>{d.dailyLogs.push({id:'lg-B',name:'B log',createdAt:new Date().toISOString()});persist()});
 await Promise.all([A.evaluate(()=>cpCloudSync()),B.evaluate(()=>cpCloudSync())]);await wait(1500);
 await A.evaluate(()=>cpCloudSync());await wait(900);await B.evaluate(()=>cpCloudSync());await wait(900);
 const L=await Promise.all([A,B].map(p=>p.evaluate(()=>d.dailyLogs.map(x=>x.id).sort().join(','))));console.log('logs A/B:',L.join(' | '));assert.equal(L[0],'lg-A,lg-B');assert.equal(L[1],'lg-A,lg-B');
 // merge safety: prototype keys / junk ignored, newer wins, tomb beats older record
 const R=await A.evaluate(()=>{const n=d.projects.length;const o=__cpCloud.mergeIn({data:{projects:[{id:'__proto__',name:'x'},{id:'ok1',name:'new',createdAt:'2030-01-01'},5,null,{id:'bad id!'}],clients:'nope'},tombs:{'__proto__':9e15,'pr-none':1}});return{added:d.projects.length-n,polluted:({}).x!==undefined||Object.keys(Object.prototype).length>0,o}});console.log('merge safety:',JSON.stringify(R));assert.equal(R.added,1);assert(!R.polluted);
 // sign out revokes refresh on server; later sync fails cleanly
 await A.evaluate(()=>cpCloudOut());const rtGone=await A.evaluate(()=>!JSON.parse(localStorage.getItem('cp_cloud_state_v1')).rt);assert(rtGone);
 await A.evaluate(()=>cpCloudSync());await wait(500);console.log('after signout:',await A.evaluate(()=>d.sync.lastError||document.getElementById('clMsg')?.textContent));
 // bad endpoint rejected (https required for public hosts)
 const bad=await A.evaluate(()=>{d.sync.endpoint='http://evil.example.com';let m='';window.alert=x=>m=x;cpCloudOpen();return m});console.log('bad endpoint alert:',bad);assert(bad.includes('https'));
 // secrets never inside synced snapshot
 const snap=await B.evaluate(()=>JSON.stringify(__cpCloud.snapshot()));assert(!/refreshToken|accessToken|passwordHash/.test(snap));
 console.log('page errors:',errs);assert.equal(errs.length,0);console.log('E2E PASSED');await b.close();srv.kill();process.exit(0)})().catch(e=>{console.error('E2E FAILED:',e.message);srv.kill();process.exit(1)});
