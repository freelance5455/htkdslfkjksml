#!/usr/bin/env bash
set -e; cd "$(dirname "$0")/.."
node tests/jalali.test.mjs | tail -1; node tests/core.test.mjs | tail -2; node tests/i18n.test.mjs
node tools/build.mjs; node tests/e2e.mjs | tail -1; node tests/e2e-security.mjs | tail -1; node tests/e2e-lang.mjs | tail -1; node tests/e2e-paid.mjs | tail -1; bash tests/db.test.sh
