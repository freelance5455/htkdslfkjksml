#!/bin/sh
# Menjalankan seluruh tes. Butuh Node.js; tes browser butuh Python + Playwright + Chromium (opsional).
cd "$(dirname "$0")/.." || exit 1
rc=0
for t in static engine store; do node "tests/unit/$t.test.js" | tail -1 || rc=1; done
if python3 -c "import playwright" 2>/dev/null; then python3 tests/integration/browser_test.py | tail -1 || rc=1; else echo "browser: NOT RUN (Playwright tidak terpasang)"; fi
exit $rc
