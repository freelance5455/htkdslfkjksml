const fs = require('fs');
const path = require('path');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
function assert(ok, message) { if (!ok) throw new Error(message); }
assert(html.includes('function liveMatchMatchesCurrentFixture()'), 'live session must be validated against current fixture');
assert(html.includes('function discardInvalidLiveMatch()'), 'invalid session cleanup exists');
assert(html.includes("if(state.liveMatch){if(liveMatchMatchesCurrentFixture()){showHalfTime();return;}state.liveMatch=null;save();"), 'goMatch resumes a valid halftime session and releases stale sessions');
assert(html.includes('discardInvalidLiveMatch();save();recalc();renderMainMenu();return'), 'invalid saved session is cleaned during career load');
assert(html.includes("if(f.played)return say('Esta partida já foi disputada.')"), 'completed fixtures remain protected');
console.log('PASS: live session validation, safe stale-session recovery, halftime resume, and completed-fixture protection.');
