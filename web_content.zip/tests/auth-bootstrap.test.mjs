import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const source = fs.readFileSync(new URL('../auth-bootstrap.js', import.meta.url), 'utf8');
const sandbox = { globalThis: null, window: null };
sandbox.globalThis = sandbox;
sandbox.window = sandbox;
vm.runInNewContext(source, sandbox);
const { resolveAuthenticatedUser, shouldBootstrapOwner } = sandbox.MRKAuth;

test('first authenticated login can bootstrap the owner without a pre-saved email', () => {
  const users = [
    { id: 'u-mrk', name: 'mr,khorasani', role: 'مدیر سیستم', email: '' },
    { id: 'u-pari', name: 'Pari', role: 'حسابدار', email: '' },
  ];
  const authUser = { id: 'auth-1', email: 'owner@example.com', user_metadata: { name: 'mr,khorasani' } };

  const resolved = resolveAuthenticatedUser(users, authUser, 'u-mrk');

  assert.equal(resolved.user.email, 'owner@example.com');
  assert.equal(resolved.user.auth_id, 'auth-1');
  assert.equal(resolved.user.role, 'مدیر سیستم');
  assert.equal(resolved.users[0].email, 'owner@example.com');
  assert.equal(shouldBootstrapOwner(null, true), true);
});

test('an already-created member is not reclassified as owner', () => {
  const member = { id: 'm1', role: 'ACCOUNTANT', is_active: true };
  assert.equal(shouldBootstrapOwner(member, false), false);
});
