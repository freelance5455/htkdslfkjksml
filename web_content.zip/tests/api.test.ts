/**
 * JARVIS Automated API Route Tests
 * Tests health, status, diagnostics, memory, tools, skills, models, and tasks endpoints.
 */

import { strict as assert } from 'node:assert';
import http from 'node:http';
import express from 'express';
import { apiRouter } from '../server/api/index.ts';
import { initializeDatabase } from '../server/db/database.ts';

export async function runApiTests(): Promise<{ passed: number; failed: number }> {
  console.log('\n--- Running API Route Tests ---');
  let passed = 0;
  let failed = 0;

  async function test(name: string, fn: () => Promise<void>) {
    try {
      await fn();
      console.log(`  [PASS] ${name}`);
      passed++;
    } catch (err: any) {
      console.error(`  [FAIL] ${name}:`, err.message);
      failed++;
    }
  }

  // Initialize DB and ephemeral Express test server
  await initializeDatabase();

  const app = express();
  app.use(express.json());
  app.use(apiRouter);

  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', () => resolve()));
  const address = server.address() as { port: number };
  const baseUrl = `http://127.0.0.1:${address.port}`;

  try {
    // 1. GET /health
    await test('GET /health returns healthy status and uptime', async () => {
      const res = await fetch(`${baseUrl}/health`);
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.equal(data.status, 'ok');
      assert.ok(data.uptime !== undefined);
      assert.equal(data.system, 'JARVIS AI Operating System');
    });

    // 2. GET /api/status
    await test('GET /api/status returns comprehensive system state', async () => {
      const res = await fetch(`${baseUrl}/api/status`);
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.equal(data.operationalStatus, 'HEALTHY');
      assert.ok(data.database);
      assert.ok(data.registeredToolsCount > 0);
      assert.ok(data.registeredSkillsCount > 0);
      assert.ok(data.activeAgentsCount > 0);
    });

    // 3. GET /api/config/diagnostics
    await test('GET /api/config/diagnostics returns sanitized diagnostics without leaking secrets', async () => {
      const res = await fetch(`${baseUrl}/api/config/diagnostics`);
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.ok(data.runtime);
      assert.ok(data.server);
      assert.ok(data.database);
      assert.ok(data.security);
      const rawText = JSON.stringify(data);
      assert.ok(!rawText.includes('AIzaSy'));
    });

    // 4. GET /api/tools
    await test('GET /api/tools returns registered tool definitions', async () => {
      const res = await fetch(`${baseUrl}/api/tools`);
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.ok(Array.isArray(data.tools));
      assert.ok(data.tools.length >= 6);
      const names = data.tools.map((t: any) => t.name);
      assert.ok(names.includes('system_diagnostics'));
      assert.ok(names.includes('web_search'));
    });

    // 5. GET /api/skills
    await test('GET /api/skills returns composed skills registry', async () => {
      const res = await fetch(`${baseUrl}/api/skills`);
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.ok(Array.isArray(data.skills));
      assert.ok(data.skills.length >= 4);
    });

    // 6. GET /api/models
    await test('GET /api/models returns available model router targets', async () => {
      const res = await fetch(`${baseUrl}/api/models`);
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.ok(Array.isArray(data.models));
      assert.ok(data.models.length > 0);
    });

    // 7. GET /api/agents
    await test('GET /api/agents returns active agent fleet', async () => {
      const res = await fetch(`${baseUrl}/api/agents`);
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.ok(Array.isArray(data.agents));
      assert.ok(data.agents.length >= 4);
    });

    // 8. POST & GET /api/memory
    await test('POST and GET /api/memory creates and retrieves memories', async () => {
      const memoryKey = `test_key_${Date.now()}`;
      const postRes = await fetch(`${baseUrl}/api/memory`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'fact',
          key: memoryKey,
          content: 'Test automated fact value',
          importance: 4,
          tags: ['automated_test'],
        }),
      });

      assert.equal(postRes.status, 200);
      const postData = await postRes.json();
      assert.ok(postData.memory);
      assert.equal(postData.memory.key, memoryKey);

      // Query it back
      const getRes = await fetch(`${baseUrl}/api/memory?query=${memoryKey}`);
      assert.equal(getRes.status, 200);
      const getData = await getRes.json();
      assert.ok(Array.isArray(getData.memories));
      const found = getData.memories.find((m: any) => m.key === memoryKey);
      assert.ok(found, 'Created memory must be retrieved');
    });

    // 9. GET /api/tasks
    await test('GET /api/tasks returns task list', async () => {
      const res = await fetch(`${baseUrl}/api/tasks`);
      assert.equal(res.status, 200);
      const data = await res.json();
      assert.ok(Array.isArray(data.tasks));
    });

    // 10. POST /api/tools/execute
    await test('POST /api/tools/execute runs safe tool directly and returns results', async () => {
      const res = await fetch(`${baseUrl}/api/tools/execute`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          toolName: 'system_diagnostics',
          params: { deepScan: false },
        }),
      });

      assert.equal(res.status, 200);
      const data = await res.json();
      assert.equal(data.success, true);
      assert.ok(data.output);
      assert.equal(data.output.osStatus, 'OPTIMAL');
    });
  } finally {
    server.close();
  }

  return { passed, failed };
}
