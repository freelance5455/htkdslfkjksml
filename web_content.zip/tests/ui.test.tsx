import { renderToString } from 'react-dom/server';
const ctxProxy: any = new Proxy({}, { get(_t, p) { if (p === 'createImageData') return (w: number, h: number) => ({ data: new Uint8ClampedArray(w * h * 4) }); if (p === 'createRadialGradient' || p === 'createLinearGradient') return () => ({ addColorStop() {} }); return () => {}; }, set() { return true; } });
const mem = new Map<string, string>();
(globalThis as any).localStorage = { getItem: (k: string) => mem.get(k) ?? null, setItem: (k: string, v: string) => mem.set(k, v) };
(globalThis as any).document = { createElement: () => ({ getContext: (t: string) => (t === '2d' ? ctxProxy : null), style: {} }) };
(globalThis as any).window = { matchMedia: () => ({ matches: false }), innerWidth: 800, innerHeight: 450 };
(globalThis as any).matchMedia = () => ({ matches: false });
const { MainMenu } = await import('../src/ui/MainMenu');
const S = await import('../src/ui/Screens');
const L = await import('../src/ui/Loadout');
const { SettingsScreen } = await import('../src/ui/Settings');
const { HUD } = await import('../src/ui/HUD');
const { TouchControls } = await import('../src/ui/TouchControls');
const { Splash } = await import('../src/ui/Splash');
const n = () => {};
const hud: any = { mode: 'br', health: 80, maxHealth: 100, armor: 70, plates: 2, medkits: 1, alive: true, respawnIn: 0, weapon: { name: 'AR-01 Vanguard', category: 'AR', mag: 5, magSize: 30, reserve: 90, rarity: 3, mode: 'AUTO' }, slots: [{ name: 'AR-01 Vanguard', rarity: 3 }, null], active: 0, reload: 0.5, useProgress: 0, useLabel: '', score: 1234, multiplier: 1.5, kills: 3, timeText: '1:23', enemiesLeft: 7, wave: 2, maxWave: 5, teamScore: [3, 4], scoreLimit: 30, killfeed: [{ id: 1, killer: 'A', victim: 'B', weapon: 'AR-01 Vanguard', head: true, kTeam: 0, vTeam: 1, t: 0 }], prompt: '[E] PICK UP', banner: { text: 'WAVE 2', sub: 'x', id: 1 }, zone: { text: 'ZONE', outside: true }, objective: 'obj', range: { hits: 1, misses: 2, acc: 33, time: 65, targets: 1 }, fps: 60, streakText: 'DOUBLE KILL', paused: false };
const cases: [string, () => any][] = [
  ['Splash', () => <Splash onDone={n} />], ['MainMenu', () => <MainMenu go={n} />],
  ['ModeSelect BR', () => <S.ModeSelect initial="br" onBack={n} onDeploy={n} onLoadout={n} />], ['ModeSelect Range', () => <S.ModeSelect initial="range" onBack={n} onDeploy={n} onLoadout={n} />],
  ['Multiplayer', () => <S.Multiplayer onBack={n} onTdm={n} />], ['Operators', () => <S.Operators onBack={n} />], ['Missions', () => <S.Missions onBack={n} />],
  ['Progression', () => <S.Progression onBack={n} />], ['Credits', () => <S.Credits onBack={n} />],
  ['Loadout', () => <L.LoadoutScreen onBack={n} />], ['Armory', () => <L.Armory onBack={n} onCustomize={n} onTest={n} />], ['RangeArmory', () => <L.RangeArmory onEquip={n} onClose={n} />],
  ...(['graphics', 'audio', 'controls', 'gameplay'] as const).map(t => [`Settings ${t}`, () => <SettingsScreen tab={t} onBack={n} />] as [string, () => any]),
  ['HUD (BR, desktop)', () => <HUD h={hud} touch={false} showFps onRangeReset={n} onRangeEnd={n} onArmory={n} />],
  ['HUD (TDM, touch)', () => <HUD h={{ ...hud, mode: 'tdm', range: null, zone: null }} touch showFps={false} onRangeReset={n} onRangeEnd={n} onArmory={n} />],
  ['TouchControls BR', () => <TouchControls mode="br" onPause={n} />], ['TouchControls Range', () => <TouchControls mode="range" onPause={n} onArmory={n} />],
];
let ok = 0, bad = 0;
for (const [name, el] of cases) { try { const html = renderToString(el()); if (html.length < 50) throw new Error('empty'); ok++; console.log('  ✔', name, `(${html.length} chars)`); } catch (e) { bad++; console.log('  ✘', name, (e as Error).message); } }
console.log(`\nUI RESULT: ${ok} passed, ${bad} failed`);
