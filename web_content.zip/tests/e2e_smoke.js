// node tests/e2e_smoke.js — baştan sona oynanış (gerçek arayüz fonksiyonları), hata/takılma kontrolü
const { chromium } = require('playwright'); const path = require('path');
const URL = 'file://' + path.resolve(__dirname, '..') + '/index.html'; let fails = 0, n = 0;
const ok = (c, m) => { n++; console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fails++; };
(async () => {
  const b = await chromium.launch();
  for (const lang of ['tr', 'en']) {
    const p = await b.newPage({ viewport: { width: 420, height: 800 } }); const errs = []; p.on('pageerror', e => errs.push(String(e)));
    await p.goto(URL); await p.waitForTimeout(800);
    await p.evaluate((lang) => { if (L != lang) setLang(); SET.rm = true; newGame(1); }, lang); await p.waitForTimeout(300);
    await p.evaluate(() => { pickC('TUR'); }); await p.waitForTimeout(300);
    ok(await p.evaluate(() => G.sel === 'TUR' && document.getElementById('panel').style.display == 'block' && !!document.getElementById('v7hs')), `${lang}: ülke seçim paneli açıldı (açıklama alanı var)`);
    await p.evaluate(() => v7Confirm()); await p.waitForTimeout(300);
    const log = { attacks: 0, wins: 0, picks: 0, autos: 0, ends: 0, stuck: 0 };
    for (let it = 0; it < 60; it++) {
      const s = await p.evaluate(() => ({ ph: G.ph, mod: document.getElementById('mod').style.display == 'flex', ok: !!document.getElementById('v5ok'), cd: !!document.getElementById('cdok'), moves: G.T && G.T.moves, over: !!G.over, bsOn: document.getElementById('bs').style.display == 'block' }));
      if (s.over) break;
      if (s.mod && s.ok) { await p.evaluate(() => document.getElementById('v5ok').click()); await p.waitForTimeout(120); continue; }
      if (s.mod && s.cd) { await p.evaluate(() => { v7Sel(Math.floor(Math.random() * 5)); v7Ok(); }); log.picks++; await p.waitForTimeout(120); continue; }
      if (s.bsOn) { await p.evaluate(() => { const was = G.autoBonus; if (was) window.__auto = 1; closeBattle(); }); await p.waitForTimeout(150); continue; }
      if (s.ph == 'act') {
        const r = await p.evaluate(() => {
          const tg = Object.keys(TG || {}); if (G.T.moves > 0 && tg.length) { G.sel = tg[Math.floor(Math.random() * tg.length)]; const before = Object.keys(G.owner).filter(k => G.owner[k] === G.pl).length; doAttack(); return { atk: 1 }; }
          v5End(); return { end: 1 }; });
        if (r.atk) log.attacks++; if (r.end) log.ends++; await p.waitForTimeout(150); continue;
      }
      await p.waitForTimeout(150); log.stuck++;
    }
    const fin = await p.evaluate(() => ({ owned: Object.keys(G.owner).filter(k => G.owner[k] === G.pl).length, ph: G.ph, st: st(G.pl).map(v => +v.toFixed(1)), auto: window.__auto || 0 }));
    console.log(lang, JSON.stringify(log), JSON.stringify(fin));
    ok(log.attacks > 3 && log.stuck < 20, `${lang}: oyun ilerledi (saldırı=${log.attacks}, takılma=${log.stuck})`);
    ok(errs.length === 0, `${lang}: sayfa hatası yok ${errs.slice(0, 3).join('|')}`);
    await p.close();
  }
  console.log(fails ? `\n${fails}/${n} BAŞARISIZ` : `\nHEPSİ GEÇTİ (${n})`); await b.close(); process.exit(fails ? 1 : 0);
})();
