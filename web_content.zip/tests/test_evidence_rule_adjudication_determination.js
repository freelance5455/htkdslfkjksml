const fs = require("fs");
const assert = require("assert");

const det = fs.readFileSync("core/determination.js", "utf8");
const evalr = fs.readFileSync("data/rules/classical_rule_evaluator.js", "utf8");
const arch = fs.readFileSync("PRODUCTION_ARCHITECTURE.md", "utf8");

assert(det.includes("const evidenceGate ="));
assert(det.includes("const ruleApplication ="));
assert(det.includes("const adjudication ="));
assert(det.includes("determination: {"));
assert(evalr.includes('ruleApplication: r ?'));
assert(arch.includes("EVIDENCE → RULE APPLICATION → ADJUDICATION → DETERMINATION"));
console.log("PASS: explicit Evidence → Rule Application → Adjudication → Determination contract");

const b1 = fs.readFileSync("core/coreB.js", "utf8");
const rules = fs.readFileSync("data/rules/classical_rules_B_C.js", "utf8");
assert(b1.includes("const primaryStrongDirection = monthSupports && strongRoot && supportEvidence;"));
assert(b1.includes("blockingByPresence: false"));
assert(b1.includes("_classicalDrainControlSignals"));
assert(rules.includes("counterEvidencePolicy"));
assert(rules.includes("presenceIsBlocking: false"));
console.log("PASS: B1 separates draining/control evidence from material blocking counter-evidence");
