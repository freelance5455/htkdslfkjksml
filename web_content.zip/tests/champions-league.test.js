import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState } from '../src/store.js';
import { generateSeasonCalendar } from '../src/calendar.js';
import { createChampionsLeagueSeason, getChampionsLeagueStatus, recordChampionsLeagueResult, validateChampionsLeague } from '../src/champions-league.js';
import { simulateChampionsLeagueRound, recordPlayedGame } from '../src/season-engine.js';
import { weekdayForSeasonDay, validateCompetitionSpacing } from '../src/competition-calendar.js';

function setup(){const s=createInitialState();generateSeasonCalendar(s);createChampionsLeagueSeason(s);return s;}

test('reprend le format Champions League V116 : 32 clubs, 8 groupes de 4 et 6 journées aller-retour',()=>{
 const s=setup(),c=s.competitions.find(x=>x.id==='champions-league');assert.equal(c.format.entrants,32);assert.equal(c.groups.length,8);assert.ok(c.groups.every(g=>g.teams.length===4&&g.rounds.length===6&&g.rounds.every(r=>r.length===2)));assert.equal(c.fixtures.length,96);assert.equal(new Set(c.groups.flatMap(g=>g.teams)).size,32);assert.equal(validateChampionsLeague(s),true);
});

test('la sélection des 32 clubs suit le classement puis le niveau, sans doublon',()=>{
 const s=createInitialState();s.divisions[0].clubs[0].points=40;s.divisions[1].clubs[0].points=30;generateSeasonCalendar(s);createChampionsLeagueSeason(s);const c=s.competitions.find(x=>x.id==='champions-league');const entrants=c.groups.flatMap(g=>g.teams);assert.ok(entrants.includes(s.divisions[0].clubs[0].id));assert.ok(entrants.includes(s.divisions[1].clubs[0].id));assert.equal(entrants.length,32);assert.equal(new Set(entrants).size,32);
});

test('la Champions League refuse de se créer si moins de 32 clubs sont actifs',()=>{const s=createInitialState();s.divisions[2].clubs=[];assert.throws(()=>createChampionsLeagueSeason(s),/exige 32 clubs actifs/);});

test('les journées Champions League sont planifiées sur des mardis distincts dans le calendrier central',()=>{const s=setup(),rows=s.calendar.fixtures.filter(f=>f.competitionId==='champions-league');const days=[...new Set(rows.map(f=>f.scheduledDay))];assert.equal(days.length,6);assert.ok(days.every(d=>weekdayForSeasonDay(d)==='mardi'));assert.equal(validateCompetitionSpacing(s.calendar.competitionEvents).valid,true);assert.equal(s.calendar.scheduleValidation.valid,true);});

test('le moteur attend la date de la journée et réserve le match du club dirigé',()=>{const s=setup(),c=s.competitions.find(x=>x.id==='champions-league'),f=s.calendar.fixtures.find(x=>x.id===c.rounds[0].fixtureIds[0]);assert.equal(simulateChampionsLeagueRound(s).available,false);s.calendar.currentDay=f.scheduledDay;const r=simulateChampionsLeagueRound(s);assert.equal(r.available,true);assert.equal(r.simulated.length,15);assert.ok(r.userFixture);assert.equal(r.userFixture.status,'scheduled');});

test('le match manuel du club dirigé est inscrit dans la phase de groupes',()=>{const s=setup(),c=s.competitions.find(x=>x.id==='champions-league');const f=s.calendar.fixtures.find(x=>x.round===1&&(x.home===s.userClubId||x.away===s.userClubId));s.calendar.currentDay=f.scheduledDay;const r=recordPlayedGame(s,f.id,1,{arena:'terrestrial'});assert.equal(r.accepted,true);assert.equal(f.status,'played');assert.equal(s.calendar.processedFixtureIds.filter(id=>id===f.id).length,1);});

test('les 16 qualifiés disputent les huitièmes, quarts, demies et finale : 111 matchs et un champion',()=>{
 const s=setup(),c=s.competitions.find(x=>x.id==='champions-league');
 for(let day=1;day<=6;day++){const round=c.rounds.find(r=>r.number===day);for(const id of round.fixtureIds)recordChampionsLeagueResult(s,id,3,1);assert.equal(round.completed,true);}
 assert.equal(c.phase,'knockout');assert.equal(c.rounds.find(r=>r.number===7).fixtureIds.length,8);
 for(let r=7;r<=10;r++){const round=c.rounds.find(x=>x.number===r);for(const id of round.fixtureIds){const f=s.calendar.fixtures.find(x=>x.id===id);recordChampionsLeagueResult(s,id,2,0,{winnerId:f.home});}assert.equal(round.completed,true);}
 assert.equal(c.status,'completed');assert.ok(c.championId);assert.equal(c.fixtures.length,111);assert.equal(validateChampionsLeague(s),true);
});

test('un résultat Champions League ne peut pas être comptabilisé deux fois',()=>{const s=setup(),c=s.competitions.find(x=>x.id==='champions-league'),id=c.rounds[0].fixtureIds[0];assert.equal(recordChampionsLeagueResult(s,id,2,1).accepted,true);assert.equal(recordChampionsLeagueResult(s,id,2,1).accepted,false);});

test('les égalités en groupes restent possibles et celles des éliminations sont départagées de façon stable',()=>{const s=setup(),c=s.competitions.find(x=>x.id==='champions-league');for(let day=1;day<=6;day++)for(const id of c.rounds.find(r=>r.number===day).fixtureIds)recordChampionsLeagueResult(s,id,1,1);const f=s.calendar.fixtures.find(x=>x.id===c.rounds.find(r=>r.number===7).fixtureIds[0]);const result=recordChampionsLeagueResult(s,f.id,1,1);assert.equal(result.accepted,true);assert.ok([f.home,f.away].includes(f.winnerId));});


test('la création des huitièmes réserve un nouveau mardi sans déplacer les six journées de groupes',()=>{
 const s=setup(),c=s.competitions.find(x=>x.id==='champions-league');const originalDays=c.rounds.slice(0,6).map(r=>s.calendar.fixtures.find(f=>f.id===r.fixtureIds[0]).scheduledDay);
 for(let day=1;day<=6;day++)for(const id of c.rounds.find(r=>r.number===day).fixtureIds)recordChampionsLeagueResult(s,id,2,0);
 const afterDays=c.rounds.slice(0,6).map(r=>s.calendar.fixtures.find(f=>f.id===r.fixtureIds[0]).scheduledDay);assert.deepEqual(afterDays,originalDays);
 const eighths=c.rounds.find(r=>r.number===7),date=s.calendar.fixtures.find(f=>f.id===eighths.fixtureIds[0]).scheduledDay;assert.ok(date>Math.max(...originalDays));assert.equal(weekdayForSeasonDay(date),'mardi');assert.equal(s.calendar.scheduleValidation.valid,true);
});

test('le statut expose la phase et le total de rencontres',()=>{const s=setup();const status=getChampionsLeagueStatus(s);assert.equal(status.participantCount,32);assert.equal(status.groupCount,8);assert.equal(status.totalMatches,111);assert.equal(status.roundLabel,'Phase de groupes — journée 1');});
