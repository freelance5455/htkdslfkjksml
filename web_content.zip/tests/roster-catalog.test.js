import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState, validateState } from '../src/store.js';
import { getAvailableLegendaryDamistes, recruitLegendaryDamiste, validateRosterCatalog } from '../src/roster-catalog.js';

test('les 36 clubs actifs et les 24 galaxies possèdent chacun deux damistes nommés', () => {
  const state = createInitialState();
  const clubs = state.divisions.flatMap(d => d.clubs);
  assert.equal(clubs.length, 36);
  assert.ok(clubs.every(c => c.damistes.length === 2 && c.damistes.every(p => !/^Damiste [12]$/.test(p.name))));
  assert.equal(state.world.galaxies.length, 24);
  assert.ok(state.world.galaxies.every(g => g.damistes.length === 2));
  assert.equal(new Set(clubs.flatMap(c => c.damistes.map(p => p.id))).size, 72);
  assert.equal(validateRosterCatalog(state), true);
  assert.equal(validateState(state), true);
});

test('les 24 légendaires sont disponibles et un recrutement remplace un titulaire sans agrandir l’effectif', () => {
  const state = createInitialState();
  const club = state.divisions[0].clubs[0];
  const available = getAvailableLegendaryDamistes(state);
  assert.equal(available.length, 24);
  club.budget = 5000000;
  const before = club.budget;
  const result = recruitLegendaryDamiste(state, { legendaryId: available[0].id, replacePlayerId: club.damistes[0].id });
  assert.equal(result.player.name, 'Driss');
  assert.equal(club.damistes.length, 2);
  assert.equal(club.damistes[0].legendary, true);
  assert.equal(club.budget, before - 2500000);
  assert.equal(getAvailableLegendaryDamistes(state).length, 23);
  assert.equal(validateRosterCatalog(state), true);
});

test('le recrutement est refusé si le budget est insuffisant', () => {
  const state = createInitialState();
  const club = state.divisions[0].clubs[0];
  club.budget = 0;
  assert.throws(() => recruitLegendaryDamiste(state, { legendaryId: state.world.legendaryDamistes[0].id, replacePlayerId: club.damistes[0].id }), /Budget insuffisant/);
});

test('chaque légendaire recruté reçoit un contrat détaillé avec durée, primes et clauses', () => {
  const state = createInitialState();
  const club = state.divisions[0].clubs[0];
  club.budget = 5000000;
  const legend = state.world.legendaryDamistes[0];
  const result = recruitLegendaryDamiste(state, { legendaryId: legend.id, replacePlayerId: club.damistes[0].id });
  const c = result.player.contract;
  assert.equal(c.status, 'active');
  assert.equal(c.signedSeason, state.season);
  assert.equal(c.expiresSeason, state.season + c.duration);
  assert.ok(c.wage > 0 && c.signingBonus > 0 && c.appearanceBonus > 0 && c.victoryBonus > 0);
  assert.ok(c.clauses.releaseClause > 0);
  assert.equal(result.player.contractHistory.length, 1);
});
