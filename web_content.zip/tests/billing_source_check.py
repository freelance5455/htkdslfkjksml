#!/usr/bin/env python3
"""Static wiring checks for the shared image/video billing correction."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
image=(ROOT/'api/image-generate.php').read_text()
video=(ROOT/'api/video-jobs.php').read_text()
credits=(ROOT/'app/credits.php').read_text()
admin=(ROOT/'app/admin.php').read_text()
ui=(ROOT/'admin.php').read_text()
checks={
 'image endpoint reserves before provider request': image.index('billing_reserve(')<image.index('decart_platform_curl('),
 'image endpoint settles after output persistence': image.index('platform_save_asset(')<image.index('billing_settle('),
 'video endpoint reserves before provider request': video.index('billing_reserve(')<video.index('decart_platform_curl('),
 'video endpoint settles only after completed output': video.index("status='completed'")<video.index('billing_settle('),
 'video confirmed provider failures refund': 'Video generation confirmed provider failure refund' in video,
 'uncertain outcomes retain reservations': 'Provider outcome is uncertain' in image and 'Provider submission outcome is uncertain' in video,
 'refund service only refunds reserved operations': "if ($op['state']!=='reserved')" in credits,
 'unique job reference protects duplicate reservations': 'job_id TEXT NOT NULL UNIQUE' in credits,
 'admin can set workspace prices': 'save_workspace_credit_prices' in admin and 'Workspace credit pricing' in ui,
 'default image/video rates are available': "'image'=>20" in credits and "'video'=>50" in credits,
}
failed=[name for name,ok in checks.items() if not ok]
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
if failed: raise SystemExit(1)
