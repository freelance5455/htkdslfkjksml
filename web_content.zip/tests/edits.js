const puppeteer=require('/home/claude/.npm-global/lib/node_modules/@mermaid-js/mermaid-cli/node_modules/puppeteer');
(async()=>{const b=await puppeteer.launch({headless:'new',executablePath:'/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome',args:['--no-sandbox']});
const p=await b.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>d.accept());await p.goto('file://'+process.cwd()+'/www/index.html');
const tab=t=>p.evaluate(t=>document.querySelector('[data-tab='+t+']').click(),t),set=o=>p.evaluate(o=>{for(const k in o){const e=document.getElementById(k);if(!e)throw new Error('missing '+k);e.value=o[k]}},o),act=a=>p.evaluate(a=>document.querySelector('[data-a="'+a+'"]').click(),a),txt=()=>p.evaluate(()=>document.getElementById('app').innerText.replace(/\s+/g,' '));
let ok=0,bad=0;const T=(n,c,x)=>{c?ok++:bad++;console.log(c?'PASS':'FAIL',n,c?'':x||'')};
const editRow=async(k)=>{await p.evaluate(k=>document.querySelector('[data-a=edit][data-k='+k+']').click(),k)};
// purchase + wastage
await tab('stock');await set({fItem:'Chair',fBrand:'',fQty:100});await act('saveAdd');
await tab('profit');await set({fQty:30,fItem:'Chair',fRate:20,fPaid:150});await act('saveOP');
await tab('wastage');await set({fItem:'Chair',fBrand:'',fQty:2,fRate:50});await act('saveW');
await tab('profit');let t=await txt();
T('ledger shows Wastage − 100, Net 500, Paid 150, Remaining 350',/Chair 30 ₹20 ₹0 −₹100 ₹500 ₹150 ₹350/.test(t),t.slice(t.indexOf('Purchase Ledger'),t.indexOf('Purchase Ledger')+400));
await editRow('ownPurchases');t=await txt();T('purchase edit opens form with values',await p.evaluate(()=>document.getElementById('fQty')&&document.getElementById('fQty').value==='30'&&document.getElementById('fItem').value==='Chair'));
await set({fQty:40});await act('saveOP');t=await txt();T('purchase edit saved: qty 40 -> net 700',/Chair 40 ₹20 ₹0 −₹100 ₹700 ₹150 ₹550/.test(t),t.slice(t.indexOf('Purchase Ledger'),t.indexOf('Purchase Ledger')+400));
T('only one purchase row (edit not duplicated)',(t.match(/2026-\d\d-\d\d Chair/g)||[]).length===1);
await p.evaluate(()=>document.querySelector('[data-a=del][data-k=ownPurchases]').click());t=await txt();T('purchase delete works',!/Chair 40/.test(t));
await tab('profit');await set({mi0:'Chair',mr0:20});await act('saveMap');t=await txt();T('own profit row saved (cost uses rate 20)',/Own Sale \/ Profit/.test(t));
await editRow('profitRates');T('own sale rate edit prefilled 20',await p.evaluate(()=>document.getElementById('mr0').value==='20'));await set({mr0:30});await act('saveMap');t=await txt();T('own sale rate edited to 30, no duplicate',/Chair ₹30/.test(t)&&!/Chair ₹20/.test(t),t.slice(t.indexOf('Automatic Own'),t.indexOf('Automatic Own')+300));
// other ledgers edit
const cases=[['expenses',{fDesc:'Home',fAmt:100},'saveE','fAmt','100','250'],['finance',{fPerson:'A',fDesc:'x',fType:'cash',fAmt:100},'saveF','fAmt','100','260'],['loans',{fPerson:'B',fAmt:100},'saveLn','fAmt','100','270'],['school',{fFees:100,fExp:0},'saveSch','fFees','100','280'],['prime',{fBank:'HDFC',fType:'credit',fAmt:100},'savePb','fAmt','100','290'],['wastage',{fItem:'Chair',fBrand:'',fQty:3,fRate:50},'saveW','fQty','2','4']];
for(const [tb,vals,save,fid,old,nw] of cases){await tab(tb);await set(vals);await act(save);await editRow(tb);const got=await p.evaluate(id=>document.getElementById(id)&&document.getElementById(id).value,fid);T(tb+' edit opens with old value '+old,got===old,got);await set({[fid]:nw});await act(save);t=await txt();T(tb+' edit saved '+nw,t.includes(nw))}
await tab('sale');await set({fItem:'Chair',fBrand:'',fQty:5,fRate:100});await act('saveSale');await p.evaluate(()=>document.querySelector('[data-a=edit][data-k=sales]').click());T('sales edit opens',await p.evaluate(()=>document.getElementById('fQty').value==='5'));
T('no page errors '+errs.join('|'),errs.length===0);console.log(ok+' ok, '+bad+' bad');await b.close();process.exit(bad?1:0)})();
