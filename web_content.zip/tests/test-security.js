// Security & regression tests for server 1.2.0  (run: node tests/test-security.js)
const assert=require('assert'),fs=require('fs'),path=require('path'),{spawn}=require('child_process');
const PORT='8901',base='http://127.0.0.1:'+PORT,dir=__dirname,J={'Content-Type':'application/json'};
const wait=ms=>new Promise(r=>setTimeout(r,ms));
const rq=async(p,o={})=>{try{const r=await fetch(base+p,o);const t=await r.text();let d;try{d=JSON.parse(t)}catch(e){d={raw:t}};return{s:r.status,d,h:r.headers}}catch(e){return{s:'ERR',d:{}}}};
const H=t=>({...J,Authorization:'Bearer '+t});
function start(tag,env,pre){const f=path.join(dir,tag+'.json');for(const x of [f,path.join(dir,'.cp-secrets.json')])try{fs.unlinkSync(x)}catch(e){};if(pre)pre(f);const c=spawn(process.execPath,[path.join(dir,'../server/server.js')],{env:{...process.env,PORT,HOST:'127.0.0.1',CP_DATA_FILE:f,...env}});const S={c,out:'',f};global.CUR=S;c.stdout.on('data',d=>S.out+=d);c.stderr.on('data',d=>S.out+=d);return S}
async function up(){for(let i=0;i<50;i++){if((await rq('/health')).s===200)return;await wait(100)}throw new Error('server did not start')}
async function stop(S){await new Promise(r=>{S.c.once('exit',r);S.c.kill('SIGTERM');setTimeout(r,5000)});try{fs.unlinkSync(S.f)}catch(e){}}
async function signup(S,email){const q0=await rq('/api/auth/request-otp',{method:'POST',headers:J,body:JSON.stringify({email})});await wait(250);if(!S.out.includes('[Contractor Pro OTP]'))console.log('DEBUG OUT:',JSON.stringify(S.out.slice(0,400)));if(q0.s!==200)console.log('REQUEST-OTP',email,q0.s,JSON.stringify(q0.d));const L=S.out.split('\n').filter(l=>l.includes('[Contractor Pro OTP]')&&l.includes(email)).pop();const r=await rq('/api/auth/verify-otp',{method:'POST',headers:J,body:JSON.stringify({email,code:L.trim().split(/\s+/).pop()})});assert.equal(r.s,200);return r.d}
const ENV={CP_JWT_SECRET:'j'.repeat(40),CP_ADMIN_KEY:'a'.repeat(30),CP_SYNC_KEEP:'3',CP_OTP_IP_LIMIT:'100',CP_OTP_VERIFY_LIMIT:'100'};
(async()=>{
 let S=start('t1',ENV);await up();
 const A=await signup(S,'a@example.com'),B=await signup(S,'b@example.com');
 // logout revokes refresh token
 await rq('/api/auth/logout',{method:'POST',headers:H(A.accessToken),body:JSON.stringify({refreshToken:A.refreshToken})});
 assert.equal((await rq('/api/auth/refresh',{method:'POST',headers:J,body:JSON.stringify({refreshToken:A.refreshToken})})).s,401,'refresh must die on logout');
 assert.equal((await rq('/api/auth/me',{headers:H(A.accessToken)})).s,401);
 // password change revokes other sessions
 const B2=await signup(S,'b@example.com');
 assert.equal((await rq('/api/account/password',{method:'POST',headers:H(B2.accessToken),body:JSON.stringify({password:'LongPassword123!'})})).s,200);
 assert.equal((await rq('/api/auth/me',{headers:H(B.accessToken)})).s,401,'old session must be revoked');
 assert.equal((await rq('/api/auth/me',{headers:H(B2.accessToken)})).s,200,'current session stays');
 assert.equal((await rq('/api/auth/login',{method:'POST',headers:J,body:JSON.stringify({email:'nobody@example.com',password:'x'})})).s,401);
 // Persian multibyte data intact across chunk boundaries
 const C=await signup(S,'c@example.com'),note='ساختمان سنگ و سرامیک پله گرد '.repeat(15000);
 assert.equal((await rq('/api/sync/push',{method:'POST',headers:H(C.accessToken),body:JSON.stringify({snapshot:{note}})})).s,200);
 assert.equal((await rq('/api/sync/pull',{headers:H(C.accessToken)})).d.latest.note,note,'Persian text corrupted');
 // sync: per-workspace retention, seq cursors, conflict detection
 const P=await signup(S,'p@example.com'),Q=await signup(S,'q@example.com');
 await rq('/api/sync/push',{method:'POST',headers:H(P.accessToken),body:JSON.stringify({snapshot:{owner:'P'}})});
 let last;for(let i=0;i<8;i++)last=await rq('/api/sync/push',{method:'POST',headers:H(Q.accessToken),body:JSON.stringify({snapshot:{owner:'Q',i}})});
 assert.equal((await rq('/api/sync/pull',{headers:H(P.accessToken)})).d.latest.owner,'P','other workspace data must survive');
 const pull=await rq('/api/sync/pull?cursor=0',{headers:H(Q.accessToken)});assert(pull.d.items.length<=3);assert.equal(pull.d.cursor,last.d.cursor);
 assert.equal((await rq('/api/sync/pull?cursor='+last.d.cursor,{headers:H(Q.accessToken)})).d.items.length,0);
 const conf=await rq('/api/sync/push',{method:'POST',headers:H(Q.accessToken),body:JSON.stringify({baseSeq:1,snapshot:{owner:'Q',stale:true}})});assert.equal(conf.s,409);assert.equal(conf.d.code,'SYNC_CONFLICT');assert.equal(conf.d.latest.owner,'Q');
 assert.equal((await rq('/api/sync/push',{method:'POST',headers:H(Q.accessToken),body:JSON.stringify({baseSeq:1,force:true,snapshot:{owner:'Q',forced:true}})})).s,200);
 // other user cannot read someone else's workspace
 assert.equal((await rq('/api/sync/pull?workspaceId='+encodeURIComponent(P.user.workspaceId),{headers:H(Q.accessToken)})).s,403);
 // license: no leak to other users; admin brute force blocked (even with right key afterwards)
 await rq('/api/admin/license/provision',{method:'POST',headers:{...J,'X-Admin-Key':ENV.CP_ADMIN_KEY},body:JSON.stringify({userId:P.user.id,licenseId:'LIC-P',plan:'enterprise'})});
 const lv=await rq('/api/license/validate',{method:'POST',headers:H(Q.accessToken),body:JSON.stringify({licenseId:'LIC-P'})});assert.equal(lv.s,404);assert(!lv.d.plan);
 assert.equal((await rq('/api/license/validate',{method:'POST',headers:H(P.accessToken),body:JSON.stringify({licenseId:'LIC-P'})})).d.valid,true);
 for(let i=0;i<12;i++)await rq('/api/admin/license/provision',{method:'POST',headers:{...J,'X-Admin-Key':'bad'+i},body:'{}'});
 assert.equal((await rq('/api/admin/license/provision',{method:'POST',headers:{...J,'X-Admin-Key':ENV.CP_ADMIN_KEY},body:JSON.stringify({userId:P.user.id})})).s,429,'admin must be locked after repeated failures');
 // portal: invite, headers, escaping, revoke
 const inv=await rq('/api/portal/invite',{method:'POST',headers:H(P.accessToken),body:JSON.stringify({clientId:'c1',email:'cl@example.com',portalData:{companyName:'<script>alert(1)</script>',projects:[{name:"x'\"<b>"}]}})});assert.equal(inv.s,200);
 const page=await rq('/portal/'+encodeURIComponent(inv.d.portalToken));assert.equal(page.s,200);assert(!page.d.raw.includes('<script>alert'));assert(String(page.h.get('content-security-policy')).includes("default-src 'none'"));assert.equal(page.h.get('x-content-type-options'),'nosniff');
 assert.equal((await rq('/api/portal/revoke',{method:'POST',headers:H(Q.accessToken),body:JSON.stringify({portalToken:inv.d.portalToken})})).s,404,'other user cannot revoke');
 assert.equal((await rq('/api/portal/revoke',{method:'POST',headers:H(P.accessToken),body:JSON.stringify({portalToken:inv.d.portalToken})})).s,200);
 assert.equal((await rq('/api/portal/'+encodeURIComponent(inv.d.portalToken))).s,404);
 assert.equal((await rq('/portal/%E0%A4%A')).s,404,'bad percent-encoding must not 500');
 // audit log (owner only, workspace-scoped)
 const au=await rq('/api/audit',{headers:H(P.accessToken)});assert.equal(au.s,200);const types=au.d.events.map(e=>e.type);for(const t of ['sync_push','license_provisioned','portal_invite','portal_revoked'])assert(types.includes(t),'missing audit '+t);assert(au.d.events.every(e=>e.workspaceId===P.user.workspaceId));
 assert.equal((await rq('/api/audit')).s,401);
 // body limit -> 413 (server stays alive)
 const big=await rq('/api/sync/push',{method:'POST',headers:{...H(C.accessToken),'Connection':'close'},body:JSON.stringify({snapshot:{x:'a'.repeat(9*1024*1024)}})});assert(big.s===413||big.s==='ERR');assert.equal((await rq('/health')).s,200);
 assert.equal((await rq('/api/auth/request-otp',{method:'POST',headers:J,body:'{bad json'})).s,400);
 await stop(S);
 // generated secrets when env not set; default admin key rejected
 S=start('t2',{CP_JWT_SECRET:'',CP_ADMIN_KEY:'',CP_OTP_IP_LIMIT:'100'});await up();const D=await signup(S,'d@example.com');
 assert((await rq('/api/admin/license/provision',{method:'POST',headers:{...J,'X-Admin-Key':'development-admin-key'},body:JSON.stringify({userId:D.user.id})})).s===401);
 const sec=JSON.parse(fs.readFileSync(path.join(dir,'.cp-secrets.json'),'utf8'));assert(sec.jwt.length>=48&&sec.admin.length>=24);
 assert.equal((await rq('/api/admin/license/provision',{method:'POST',headers:{...J,'X-Admin-Key':sec.admin},body:JSON.stringify({userId:D.user.id})})).s,200);
 await stop(S);
 // legacy data (no seq / audit / sessions) upgrades cleanly; corrupt file is moved aside, not overwritten
 S=start('t3',ENV,f=>fs.writeFileSync(f,JSON.stringify({users:{},workspaces:{w:{id:'w'}},memberships:{},refresh:{},sessions:{},otp:{},sync:[{id:'e1',workspaceId:'w',createdAt:'x',snapshot:{old:1}},{id:'e2',workspaceId:'w',createdAt:'y',snapshot:{old:2}}],licenses:{},portal:{}})));await up();await stop(S);
 S=start('t4',ENV,f=>fs.writeFileSync(f,'{corrupt'));await up();assert(fs.readdirSync(dir).some(x=>x.startsWith('t4.json.corrupt-')),'corrupt file should be preserved');
 await stop(S);fs.readdirSync(dir).filter(x=>/corrupt-|^\.cp-secrets/.test(x)).forEach(x=>fs.unlinkSync(path.join(dir,x)));
 console.log('ALL SECURITY TESTS PASSED');process.exit(0);
})().catch(e=>{console.error('FAILED:',e);try{global.CUR&&global.CUR.c.kill()}catch(x){}process.exit(1)});
