import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const source = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8');

test('cloud login resolves company membership through the secure RPC', () => {
  const marker = "CLOUD.sb.rpc('ensure_my_company_membership',{p_company_id:COMPANY_ID})";
  assert.ok(source.includes(marker));
  assert.equal(source.includes("from('company_members').select('id,role,is_active').eq('company_id',COMPANY_ID).eq('user_id',authUser.id).maybeSingle()"), false);
});
