import { build } from 'esbuild';
await build({ entryPoints: ['tests/sim.test.ts'], bundle: true, platform: 'node', format: 'esm', outfile: 'tests/.out/sim.mjs', logLevel: 'error' });
await import('./.out/sim.mjs');
