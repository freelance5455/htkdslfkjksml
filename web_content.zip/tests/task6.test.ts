/**
 * JARVIS Task #6 Validation Suite
 * Tests General-Purpose Intelligence, Capability Discovery, Bounded Context,
 * Multi-lingual Communication, Personality, and Cognitive Synthesis.
 */

import { strict as assert } from 'node:assert';
import { capabilityRegistry } from '../server/capabilities/capabilityRegistry.ts';
import { contextEngine } from '../server/context/contextEngine.ts';
import { jarvisCore } from '../server/core/jarvisCore.ts';
import { initializeDatabase } from '../server/db/database.ts';
import { LanguageSystem } from '../server/language/languageSystem.ts';
import { preferenceSystem } from '../server/memory/preferenceSystem.ts';
import { JarvisIdentity } from '../server/models/identity.ts';
import { IntentClassifier } from '../server/planner/intentClassifier.ts';

export async function runTask6Tests(): Promise<{ passed: number; failed: number }> {
  console.log('\n--- Running Task #6 Capability & Intelligence Tests ---');
  let passed = 0;
  let failed = 0;

  async function test(name: string, fn: () => Promise<void>) {
    try {
      await fn();
      console.log(`  [PASS] ${name}`);
      passed++;
    } catch (err: any) {
      console.error(`  [FAIL] ${name}:`, err.message);
      failed++;
    }
  }

  await initializeDatabase();

  // 1. Dynamic Capability Registry
  await test('capability registry discovers relevant capabilities for dynamic tasks', async () => {
    const all = capabilityRegistry.getAll();
    assert.ok(all.length >= 8, 'Should have at least 8 registered core capabilities');

    const codingCaps = capabilityRegistry.discoverCapabilities(['code', 'sandbox']);
    assert.ok(codingCaps.length >= 1, 'Should discover coding capabilities');
    assert.ok(codingCaps.some((c) => c.category === 'coding'));

    const researchCaps = capabilityRegistry.discoverCapabilities(['research', 'web']);
    assert.ok(researchCaps.length >= 1, 'Should discover research capabilities');
  });

  // 2. Intent Classification Without Hardcoded Rigid Paths
  await test('intent classifier categorizes educational queries without forcing tool calls', async () => {
    const intent = IntentClassifier.analyze({
      prompt: 'Explain how neural network backpropagation works intuitively',
    });

    assert.equal(intent.intentType, 'EDUCATIONAL_EXPLANATION');
    assert.equal(intent.requiresToolExecution, false);
    assert.ok(intent.requiredCapabilities.length > 0);
  });

  await test('intent classifier identifies coding and tool execution needs dynamically', async () => {
    const intent = IntentClassifier.analyze({
      prompt: 'Execute and test an algorithm to reverse a linked list in TypeScript',
    });

    assert.equal(intent.intentType, 'CODING');
    assert.equal(intent.requiresToolExecution, true);
    assert.equal(intent.recommendedAgent, 'CODING');
  });

  // 3. Multi-Lingual & Hinglish Detection
  await test('detects Hinglish blend and adapts target language', async () => {
    const langHinglish = LanguageSystem.resolveLanguage({
      currentPrompt: 'Bhai database query slow chal rahi hai, thoda explain karo kaise optimize karein',
    });
    assert.equal(langHinglish, 'hinglish');

    const intent = IntentClassifier.analyze({
      prompt: 'Mujhe quick sort algorithm samjhao step by step',
    });
    assert.equal(intent.targetLanguage, 'hinglish');
  });

  await test('detects pure Hindi script and sets target language', async () => {
    const langHindi = LanguageSystem.resolveLanguage({
      currentPrompt: 'कंप्यूटर नेटवर्क कैसे काम करता है?',
    });
    assert.equal(langHindi, 'hi');
  });

  // 4. User Preference Persistence and Propagation
  await test('preference system updates and retrieves persistent preferences', async () => {
    await preferenceSystem.setPreference('explanation_depth', 'in-depth');
    await preferenceSystem.setPreference('preferred_language', 'hinglish');

    const prefs = await preferenceSystem.getPreferences();
    assert.equal(prefs.explanationDepth, 'in-depth');
    assert.equal(prefs.preferredLanguage, 'hinglish');

    // Clean up
    await preferenceSystem.deletePreference('explanation_depth');
    await preferenceSystem.deletePreference('preferred_language');
  });

  // 5. Bounded Context Assembly
  await test('context engine bounds conversation history to prevent context overflow', async () => {
    const envelope = await contextEngine.buildContext({
      userPrompt: 'Summarize our recent discussion',
      conversationId: 'conv_default',
    });

    assert.ok(envelope.recentMessages.length <= 8, 'Context history must be bounded to MAX_RECENT_MESSAGES');
    assert.ok(envelope.formattedPrompt.includes('Summarize our recent discussion'));
    assert.ok(envelope.currentMessage, 'Current message must be preserved');
  });

  // 6. Personality & Cognitive Synthesis
  await test('identity system provides disciplined personality guidelines without sycophancy', async () => {
    const instructions = JarvisIdentity.getSystemInstruction({
      language: 'en',
      depth: 'standard',
    });

    assert.ok(instructions.includes('J.A.R.V.I.S.'));
    assert.ok(instructions.includes('GENERAL-PURPOSE INTELLIGENCE'));
    assert.ok(instructions.includes('GROUNDED CAPABILITIES & HONESTY'));
  });

  // 7. Core Loop Cognitive Synthesis End-to-End Execution
  await test('executes cognitive synthesis path for non-tool knowledge query', async () => {
    const result = await jarvisCore.executeTask(
      'What is the fundamental difference between synchronous and asynchronous execution?',
      'usr_jarvis_prime',
      'conv_default'
    );

    assert.ok(result.task, 'Task must be returned');
    assert.equal(result.task.status, 'COMPLETED');
    assert.ok(result.assistantMessage, 'Assistant message must be generated');
    assert.ok(result.assistantMessage.content.length > 50, 'Response should have substantial explanatory content');

    // Check plan had capability
    assert.ok(result.task.plan, 'Plan must exist');
    assert.ok(result.task.plan.selectedCapabilities, 'Selected capabilities must be present');
    assert.ok(result.task.plan.selectedCapabilities.length > 0);
  });

  return { passed, failed };
}
