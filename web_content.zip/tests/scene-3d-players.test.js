import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const scene=readFileSync(new URL('../src/scene-3d.js',import.meta.url),'utf8');
const match=readFileSync(new URL('../src/match-ui.js',import.meta.url),'utf8');
test('les pièces 3D sont représentées par des figurines humanoïdes avec tête, tunique et membres',()=>{
  for(const token of ['function addSphere','function addLimb','function addPiece','addSphere(out,x+lean,.72+lift-headDrop,z','.59+lift','king)'])assert.ok(scene.includes(token),`modèle 3D incomplet : ${token}`);
});
test('les dames portent une couronne géométrique distincte',()=>{
  assert.ok(scene.includes('if(king){addCylinder'));
  assert.ok(scene.includes('Math.PI*2/5'));
});
test('les déplacements comportent une impulsion verticale et une inclinaison',()=>{
  assert.ok(scene.includes('lift:Math.sin(t*Math.PI)*.28'));
  assert.ok(scene.includes('lean:Math.sin(t*Math.PI)*.035'));
});
test('le couronnement pendant un déplacement conserve le modèle de dame dans l’animation',()=>{
  assert.ok(match.includes('animateMove?.(board,move,board[pr][pc]'));
  assert.ok(match.includes('animateMove?.(board,ai,board[pr][pc]'));
});

test('les attitudes 3D couvrent réflexion, geste de prise, présentation, victoire et défaite',()=>{
  for(const action of ['thinking','capture','presentation','celebrate','defeat'])assert.ok(scene.includes(`action==='${action}'`)||scene.includes(`action='${action}'`),`attitude absente : ${action}`);
  assert.ok(scene.includes('function playPose(board,side,action'));
});
test('une prise déclenche un geste avant le déplacement animé',()=>{
  assert.ok(scene.includes("if(move.captures?.length)"));
  assert.ok(scene.includes("action:'capture'"));
  assert.ok(scene.includes('else begin();'));
});
test('le match présente les deux camps puis joue les réactions de victoire et de défaite',()=>{
  assert.ok(match.includes("playPose?.(board,1,'presentation'"));
  assert.ok(match.includes("playPose?.(board,-1,'presentation'"));
  assert.ok(match.includes("playPose?.(board,winner,'celebrate'"));
  assert.ok(match.includes("playPose?.(board,-winner,'defeat'"));
});
test('la réflexion est montrée pendant la recherche de coup de l’IA et au tour du joueur',()=>{
  assert.ok(match.includes("playPose?.(board,-1,'thinking'"));
  assert.ok(match.includes("playPose?.(board,1,'thinking'"));
});
