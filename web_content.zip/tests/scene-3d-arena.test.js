import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const scene=readFileSync(new URL('../src/scene-3d.js',import.meta.url),'utf8');
const match=readFileSync(new URL('../src/match-ui.js',import.meta.url),'utf8');
const html=readFileSync(new URL('../index.html',import.meta.url),'utf8');
test('la scène 3D comprend une enceinte avec gradins, public et pylônes lumineux',()=>{
  for(const token of ['function addArena','const tiers=','Public stylisé',"Pylônes d'éclairage",'addBox(out'])assert.ok(scene.includes(token),`élément de scène absent : ${token}`);
});
test('la caméra 3D peut tourner et zoomer avec les interactions du pointeur',()=>{
  for(const token of ['pointerdown','pointermove','pointerup','wheel','yaw=','zoom='])assert.ok(scene.includes(token),`contrôle caméra absent : ${token}`);
});
test('les déplacements sont animés par interpolation et suivent chaque segment de prise',()=>{
  assert.match(scene,/function animateMove\(board,move,piece,selected,targets\)/);
  assert.ok(scene.includes('requestAnimationFrame(tick)'));
  assert.ok(scene.includes('segment<steps.length'));
  assert.ok(match.includes('scene3d.animateMove?.(board,move,board[pr][pc]'));
  assert.ok(match.includes('scene3d.animateMove?.(board,ai,board[pr][pc]'));
});
test('la couche WebGL ne bloque pas les cases interactives et indique les commandes de caméra',()=>{
  assert.match(html,/#matchBoard \.cgd-3d-canvas\{[^}]*pointer-events:none/);
  assert.ok(html.includes('glisse pour tourner la caméra'));
});
