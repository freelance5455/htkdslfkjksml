import { chromium } from "playwright";
import { readFileSync } from "node:fs";
// reuse by importing? just open the app after the previous book may be cached. Generate again quickly.
const { default: none } = { default: null };
import { createRequire } from "node:module";
