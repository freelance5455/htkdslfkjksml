const { chromium } = require('playwright');
let ok = 0, mal = [];
const t = (n, c, d) => { if (c) { ok++; console.log('  ✔', n); } else { mal.push(n + (d ? ' → ' + d : '')); console.log('  ✘', n, d || ''); } };
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 390, height: 844 }, locale: 'es-CO', timezoneId: 'America/Bogota', isMobile: true, hasTouch: true, acceptDownloads: true });
  const p = await c.newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message)); p.on('console', (m) => m.type() === 'error' && errs.push(m.text()));
  await p.goto('http://localhost:8765/index.html'); await p.waitForSelector('.vista'); const w = (ms) => p.waitForTimeout(ms || 400);
  const ir = async (h) => { await p.evaluate((h) => { location.hash = '#/' + h; }, h); await w(); };
  console.log('Compartir / guardar archivos');
  await p.evaluate(async () => { await App.guardarVenta({ fecha: MC.hoyISO(), hora: '', referencia: '', cliente: 'X', medio: 'efectivo', monto: 1000, observaciones: '', tipo: 'rapida', descuenta: false }, []); });
  await p.evaluate(() => { window.__s = []; navigator.canShare = () => true; navigator.share = async (d) => { window.__s.push(d.files[0].name + '|' + d.files[0].size); }; });
  await ir('respaldo'); await p.click('[data-a="hacerRespaldo"]'); await w(600);
  const s1 = await p.evaluate(() => window.__s);
  t('Con «Compartir» del teléfono: abre el menú con el archivo .json', s1.length === 1 && /^CafeMeroCampo_respaldo_.*\.json\|\d+$/.test(s1[0]), JSON.stringify(s1));
  t('…y se marca la copia como hecha hoy', await p.evaluate(() => App.S.ajustes.ultimoRespaldo === MC.hoyISO()));
  t('La app sigue abierta y en la pantalla de Respaldo', (await p.locator('.vista').count()) === 1 && /copia/i.test(await p.innerText('#app')));
  await p.evaluate(async () => { App.S.ajustes.ultimoRespaldo = null; await App.guardarConfig('ajustes', App.S.ajustes); await App.recargar(); navigator.share = async () => { const e = new Error('x'); e.name = 'AbortError'; throw e; }; });
  await ir('respaldo'); await p.click('[data-a="hacerRespaldo"]'); await w(600);
  t('Si cancelas el menú, NO se marca como copia hecha', await p.evaluate(() => !App.S.ajustes.ultimoRespaldo));
  await p.evaluate(() => { window.__s = []; navigator.share = async (d) => { window.__s.push(d.files[0].name); }; });
  await ir('informes');
  for (const [accion, ext] of [['expXLSX', 'xlsx'], ['expCSV', 'csv']]) { await p.click(`[data-a="${accion}"]`); await w(500); }
  const s2 = await p.evaluate(() => window.__s);
  t('Informes Excel y CSV también usan «Compartir»', s2.length === 2 && /\.xlsx$/.test(s2[0]) && /\.csv$/.test(s2[1]), JSON.stringify(s2));
  await p.evaluate(() => { navigator.canShare = () => false; });
  await ir('respaldo'); const [dl] = await Promise.all([p.waitForEvent('download'), p.click('[data-a="hacerRespaldo"]')]);
  t('Sin «Compartir» (computador): descarga normal del .json', /\.json$/.test(dl.suggestedFilename()));
  await ir('informes'); const [dl2] = await Promise.all([p.waitForEvent('download'), p.click('[data-a="expXLSX"]')]);
  t('Sin «Compartir»: descarga normal del .xlsx', /\.xlsx$/.test(dl2.suggestedFilename()));
  t('Sin errores en consola', errs.length === 0, errs.join('|'));
  await b.close(); console.log(`\n${ok} correctas, ${mal.length} con fallo`); if (mal.length) { mal.forEach((m) => console.log(' -', m)); process.exit(1); }
})().catch((e) => { console.error(e); process.exit(2); });
