const { chromium } = require('playwright');
let ok = 0, mal = [];
const t = (n, c, d) => { if (c) { ok++; console.log('  ✔', n); } else { mal.push(n + (d ? ' → ' + d : '')); console.log('  ✘', n, d || ''); } };
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 390, height: 844 }, locale: 'es-CO', timezoneId: 'America/Bogota', isMobile: true, hasTouch: true });
  const p = await c.newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message)); p.on('console', (m) => m.type() === 'error' && errs.push(m.text()));
  await p.goto('http://localhost:8765/index.html'); await p.waitForSelector('.vista');
  const txt = () => p.innerText('#app'); const w = (ms) => p.waitForTimeout(ms || 300);
  const venta = async (m) => { await p.evaluate(() => { location.hash = '#/inicio'; }); await w(); await p.click('#fabVenta'); await p.waitForSelector('#fVenta'); await p.fill('#v-monto', m); await p.click('#v-guardar'); await w(500); };
  const ir = async (h) => { await p.evaluate((h) => { location.hash = '#/' + h; }, h); await w(); };
  console.log('Estimación para ventas por total');
  await venta('300.000');
  let x = await txt();
  t('Sin precios de venta: ganancia sigue «Pendiente» (no inventa)', /Ganancia neta estimada\s+i\s+Pendiente/.test(x));
  // precios de venta
  await ir('productos');
  const ids = await p.evaluate(() => App.S.productos.map((q) => [q.id, q.gramos]));
  const precios = { 42: '2.500', 60: '3.500', 125: '7.000', 225: '12.000', 425: '22.000' };
  for (const [id, g] of ids) { const s = `[data-k="prod.${id}.precioTienda"]`; await p.fill(s, precios[g]); await p.press(s, 'Tab'); await w(300); }
  const r = await p.evaluate(() => { const e = App.estimacion(); return { ok: e.ok, razon: e.razon, filas: App.tabla().map((f) => f.total / f.precio) }; });
  const esperada = r.filas.reduce((a, v) => a + v, 0) / r.filas.length;
  t('Razón automática = promedio de costo÷precio de las 5 presentaciones', r.ok && Math.abs(r.razon - esperada) < 1e-9, JSON.stringify(r));
  await ir('inicio'); await p.click('[data-a="kind"][data-r="dash"][data-k="mes"]'); await w(); x = await txt();
  const costoEst = 300000 * r.razon, gb = 300000 - costoEst;
  const fmt = (n) => '$' + Math.round(n).toLocaleString('es-CO');
  t('Dashboard: «Costo de productos vendidos (estimado)» = 300.000 × razón', x.includes('Costo de productos vendidos (estimado)') && x.includes(fmt(costoEst)), fmt(costoEst));
  t('Dashboard: «Ganancia bruta (estimada)» = ventas − costo estimado', x.includes('Ganancia bruta (estimada)') && x.includes(fmt(gb)), fmt(gb));
  t('Dashboard: margen bruto estimado y ganancia neta estimada visibles', /Margen bruto \(estimado\)/.test(x) && /Ganancia neta \(estimada\)/.test(x));
  t('ROI sin inversión: «Pendiente» con explicación (no inventa)', /ROI\s+i\s+Pendiente de datos/.test(x) && /inversión/.test(x));
  // inversión → ROI estimado
  await p.evaluate(async () => { await DB.transaccion(['inversiones'], (a) => a.put('inversiones', { tipo: 'maquinaria', valor: 1000000, fecha: MC.hoyISO(), descripcion: 'Tostadora', creado: Date.now() })); await App.recargar(); });
  await ir('inicio'); await p.click('[data-a="kind"][data-r="dash"][data-k="mes"]'); await w(); x = await txt();
  t('Con inversión de $1.000.000: aparece «ROI (estimado)»', /ROI \(estimado\)/.test(x) && /Estimación sobre \$1\.000\.000/.test(x));
  // manual 62%
  await ir('costos'); await p.click('[data-a="tabCostos"][data-t="tabla"]'); await w();
  await p.selectOption('[data-c="estimModo"]', 'manual'); await w(400);
  await p.fill('[data-c="estimPct"]', '62'); await p.press('[data-c="estimPct"]', 'Tab'); await w(400);
  t('Manual 62%: la pantalla confirma «62,0% de cada venta»', /62,0%/.test(await txt()));
  await ir('inicio'); await p.click('[data-a="kind"][data-r="dash"][data-k="mes"]'); await w(); x = await txt();
  t('Manual 62%: costo $186.000 y ganancia bruta $114.000', x.includes('$186.000') && x.includes('$114.000') && /38,0%/.test(x));
  await ir('costos'); await w();
  await p.fill('[data-c="estimPct"]', 'abc'); await p.press('[data-c="estimPct"]', 'Tab'); await w();
  t('Un % inválido se rechaza', /entre 0 y 100/.test(await p.innerText('#toasts')));
  // persistencia
  await p.reload(); await p.waitForSelector('.vista'); await w(400);
  t('Tras recargar, la configuración manual 62% sigue guardada', await p.evaluate(() => App.S.ajustes.estimacion.modo === 'manual' && App.S.ajustes.estimacion.costoPct === 62));
  // apagar
  await ir('costos'); await p.click('[data-a="tabCostos"][data-t="tabla"]'); await w(); await p.selectOption('[data-c="estimModo"]', 'apagado'); await w(500);
  await ir('inicio'); await p.click('[data-a="kind"][data-r="dash"][data-k="mes"]'); await w(); x = await txt();
  t('Estimación apagada: vuelve a «Pendiente de datos»', /Ganancia neta estimada\s+i\s+Pendiente/.test(x) && !/\(estimad[oa]\)/.test(x));
  // venta por producto real sigue mandando
  await p.evaluate(async () => { const pr = App.S.productos[0], c = App.costoDe(pr); await App.guardarVenta({ fecha: MC.hoyISO(), hora: '', referencia: '', cliente: 'Det', medio: 'efectivo', monto: 25000, observaciones: '', tipo: 'detallada', descuenta: false }, [{ productoId: pr.id, nombre: pr.nombre, cantidad: 10, precioUnit: 2500, costoUnit: c.total, costoFuente: 'x' }]); });
  const real = await p.evaluate(() => { const r = MC.resultadoPeriodo({ ventas: App.S.ventas.filter((v) => v.tipo === 'detallada'), gastos: [], costos: App.S.costos, desde: MC.hoyISO(), hasta: MC.hoyISO(), hoy: MC.hoyISO(), razon: 0.9 }); return { est: r.estimado, cogs: r.cogs }; });
  t('Ventas por producto usan su costo real (la estimación no las toca)', real.est === null && real.cogs > 0);
  t('Sin errores de consola', errs.length === 0, errs.join('|'));
  await b.close();
  console.log(`\n${ok} correctas, ${mal.length} con fallo`); if (mal.length) { mal.forEach((m) => console.log(' -', m)); process.exit(1); }
})().catch((e) => { console.error(e); process.exit(2); });
