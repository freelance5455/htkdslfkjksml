from pathlib import Path
root=Path(__file__).resolve().parents[1]
header=(root/'app/platform_header.php').read_text()
realtime=(root/'index.php').read_text()
dashboard=(root/'dashboard.php').read_text()
voice=(root/'voice-studio.php').read_text()
agent=(root/'agent-studio.php').read_text()
css=(root/'assets/anonymoux-red-overrides.css').read_text()
assert "'CREATIVE WORKSPACES'" in header and "'AI CREATION'" in header and "'YOUR LIBRARY'" in header
for label in ['Voice Cloning Studio','AI Agent Studio','WhatsApp Deployments','Video Edit Studio']:
    assert label in header
assert 'New Project</b>' not in dashboard and 'Upload Reference</b>' not in dashboard
assert 'Voice Cloning Studio' in dashboard and 'AI Agent Studio' in dashboard
assert 'voiceCloneForm' in voice and 'agent_workspace.php' not in voice
assert 'Voice Cloning Studio' in realtime and 'AI Agent Studio' in realtime and 'topbar-balance-chip' in realtime
assert 'agent_workspace.php' in agent
assert '--green:#A3FF12' in css and '--bg:#111318' in css and '--purple:#8B5CF6' in css and '--teal:#00D6C9' in css and '--blue:#3897FF' in css
print('PASS: grouped sidebar, distinct voice/agent workspaces, clean dashboard shortcuts and charcoal / neon-green brand tokens.')
