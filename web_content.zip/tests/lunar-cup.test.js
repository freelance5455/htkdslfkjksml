import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState } from '../src/store.js';
import { generateSeasonCalendar } from '../src/calendar.js';
import { createLunarCupSeason, LUNAR_CUP_ID, LUNAR_GALAXIES, getLunarCupStatus, validateLunarCup, recordLunarCupResult } from '../src/lunar-cup.js';
import { scheduleCompetitionCalendar, validateCompetitionSpacing, setOfficialLunarThursdays, setOfficialRegularSeasonEndDate, setOfficialIntergalacticDate } from '../src/competition-calendar.js';
import { simulateLunarCupRound, advanceToNextCalendarEvent, recordPlayedGame } from '../src/season-engine.js';

function setup(){const s=createInitialState();for(const c of s.competitions)c.calendarEngineReady=true;generateSeasonCalendar(s);createLunarCupSeason(s);return s;}
test('la Coupe Lunaire reprend les huit représentants V116 et une élimination directe en 4+2+1',()=>{
 const s=setup(),c=s.competitions.find(x=>x.id===LUNAR_CUP_ID);assert.deepEqual(c.galaxies,LUNAR_GALAXIES);assert.equal(c.rounds.length,1);assert.equal(c.rounds[0].fixtureIds.length,4);assert.equal(c.format.totalMatches,7);assert.equal(c.format.smallFinal,false);validateLunarCup(s);
});
test('les phases sont inscrites au mois 12, à une semaine d’intervalle',()=>{
 const s=setup();const rows=s.calendar.competitionEvents.filter(e=>e.competitionId===LUNAR_CUP_ID);assert.deepEqual(rows.map(e=>e.absoluteDay),[342]);assert.equal(rows[0].lunarMonth,12);assert.equal(rows[0].legacySeasonOffset,342);assert.equal(rows[0].authority,'AGD');
});
test('les tours suivants sont créés automatiquement et le palmarès conserve le champion',()=>{
 const s=setup(),c=s.competitions.find(x=>x.id===LUNAR_CUP_ID);s.calendar.currentDay=342;
 for(const id of [...c.rounds[0].fixtureIds]){const f=s.calendar.fixtures.find(x=>x.id===id);recordLunarCupResult(s,id,1,0,{winnerId:f.home});}
 assert.equal(c.rounds.length,2);assert.equal(c.rounds[1].fixtureIds.length,2);assert.deepEqual(c.rounds[1].fixtureIds.map(id=>s.calendar.fixtures.find(f=>f.id===id).scheduledDay),[349,349]);
 s.calendar.currentDay=349;for(const id of [...c.rounds[1].fixtureIds]){const f=s.calendar.fixtures.find(x=>x.id===id);recordLunarCupResult(s,id,1,0,{winnerId:f.home});}
 assert.equal(c.rounds.length,3);assert.equal(s.calendar.fixtures.find(f=>f.id===c.rounds[2].fixtureIds[0]).scheduledDay,356);
 s.calendar.currentDay=356;const final=s.calendar.fixtures.find(f=>f.id===c.rounds[2].fixtureIds[0]);recordLunarCupResult(s,final.id,1,0,{winnerId:final.home});
 assert.equal(c.status,'completed');assert.equal(c.championId,final.home);assert.equal(c.history[0].championId,final.home);validateLunarCup(s);
});
test('un résultat lunaire ne modifie jamais le classement des clubs et ne compte pas deux fois',()=>{
 const s=setup(),f=s.calendar.fixtures.find(x=>x.competitionId===LUNAR_CUP_ID),before=s.divisions[0].clubs[0].played;s.calendar.currentDay=342;
 assert.equal(recordLunarCupResult(s,f.id,1,0,{winnerId:f.home}).accepted,true);assert.equal(s.divisions[0].clubs[0].played,before);assert.equal(recordLunarCupResult(s,f.id,1,0,{winnerId:f.home}).accepted,false);
});
test('la sélection du manager laisse son représentant à jouer au jour officiel',()=>{
 const s=setup();s.userGalaxyId='Astra Nova';s.calendar.currentDay=342;
 const result=simulateLunarCupRound(s);assert.equal(result.available,true);assert.ok(result.userFixture);assert.equal(result.simulated.length,3);
 const played=recordPlayedGame(s,result.userFixture.id,1,{engine:'manual-test'});assert.equal(played.accepted,true);
});
test('la progression de carrière attend la rencontre de la galaxie sélectionnée',()=>{
 const s=setup();s.userGalaxyId='Astra Nova';
 setOfficialLunarThursdays(s,Array.from({length:7},(_,i)=>({weekday:'jeudi',lunarMonth:i<4?1:2,lunarDay:4+i*7,absoluteDay:4+i*7})));
 setOfficialRegularSeasonEndDate(s,{absoluteDay:153,phase:'end-of-regular-season'});setOfficialIntergalacticDate(s,'intergalactique',{absoluteDay:156,phase:'after-regular-season'});setOfficialIntergalacticDate(s,'intergalactique-clubs',{absoluteDay:158,phase:'after-regular-season'});s.calendar.currentDay=341;
 const next=advanceToNextCalendarEvent(s);assert.equal(next.event.competitionId,LUNAR_CUP_ID);assert.equal(next.event.absoluteDay,342);assert.ok(next.userFixture);assert.equal(next.simulated.length,3);
});
test('les fenêtres de Coupe Lunaire sont contrôlées avec les autres événements',()=>{
 const s=setup();const c=s.competitions.find(x=>x.id===LUNAR_CUP_ID),f=s.calendar.fixtures.find(x=>x.id===c.rounds[0].fixtureIds[0]);f.scheduledDay=342;scheduleCompetitionCalendar(s);
 assert.equal(validateCompetitionSpacing(s.calendar.competitionEvents).valid,true);
});

test('le match du tour suivant ne devient pas jouable avant sa date officielle',async()=>{
 const s=setup();s.userGalaxyId='Astra Nova';s.calendar.currentDay=342;const cup=s.competitions.find(x=>x.id===LUNAR_CUP_ID);
 for(const id of [...cup.rounds[0].fixtureIds]){const f=s.calendar.fixtures.find(x=>x.id===id);recordLunarCupResult(s,id,1,0,{winnerId:f.home});}
 assert.equal(cup.rounds[1].fixtureIds.length,2);assert.equal((await import('../src/lunar-cup.js')).getLunarUserFixture(s),null);
});
