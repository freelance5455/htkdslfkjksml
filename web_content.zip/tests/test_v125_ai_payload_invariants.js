'use strict';
/**
 * test_v125_ai_payload_invariants.js
 * Tes regresi untuk payload AI hasil json-mapper.js. Tidak terikat pada satu chart:
 * memeriksa invarian struktur dan kosakata status pada beberapa chart sekaligus.
 *
 * Letakkan di tests/ (bersama tests/fixtures/contract_table_headers.json) lalu jalankan:
 *   node tests/test_v125_ai_payload_invariants.js
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const ROOT = path.resolve(__dirname, '..');
global.window = global;
const load = (rel) => vm.runInThisContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), { filename: rel });

const lunar = require(path.join(ROOT, 'engine/lunar.js'));
global.Solar = lunar.Solar;
global.EightChar = lunar.EightChar;
[
  'bazi-data.js', 'engine/solar.js', 'engine/jieqi.js', 'engine/calendar.js',
  'data/sources/classical_sources_B_C.js', 'data/rules/classical_rules_B_C.js',
  'data/rules/classical_rule_evaluator.js', 'data/evidence/closure_signal_contract.js',
  'data/evidence/runtime_evidence_normalizer.js', 'core/coreA.js', 'core/coreB.js',
  'data/determination-rules.js', 'core/determination.js', 'core/coreC.js', 'core/json-mapper.js'
].forEach(load);

global.PenggilasLocation = { resolve: async () => ({
  location: { name: 'Jakarta', admin1: 'DKI Jakarta', country: 'Indonesia' },
  coordinates: { latitude: -6.2088, longitude: 106.8456 },
  timeZone: { iana: 'Asia/Jakarta', utcOffset: 7 },
  referenceMeridian: { degrees: 105 },
  coordinateSource: { provider: 'runtime-fixture' },
  dst: { isDst: false }
}) };

const CHARTS = [
  { name: 'Chart A', birthDate: '1983-06-17', birthTime: '12:15', gender: 'Male' },
  { name: 'Chart B', birthDate: '1983-07-16', birthTime: '06:12', gender: 'Female' },
  { name: 'Chart C', birthDate: '1975-11-03', birthTime: '22:40', gender: 'Female' }
];

async function buildPayload(input) {
  global.masterResult = null;
  const log = console.log; console.log = () => {};
  try {
    await global.PenggilasCoreA.calculate({ ...input, birthPlace: { query: 'Jakarta' } });
    global.PenggilasCoreB.calculate();
    global.PenggilasDetermination.calculate();
    await global.PenggilasCoreC.calculate(new Date('2026-10-07T05:00:00Z'));
  } finally { console.log = log; }
  const template = JSON.parse(fs.readFileSync(path.join(ROOT, 'template/ai-result-template.json'), 'utf8'));
  return { ai: global.PenggilasJSONMapper.buildAIPresentationJSON(global.masterResult, template), template };
}

function* walk(o, p = '') {
  if (Array.isArray(o)) { for (let i = 0; i < o.length; i++) yield* walk(o[i], `${p}[${i}]`); }
  else if (o && typeof o === 'object') { for (const [k, v] of Object.entries(o)) yield* walk(v, `${p}/${k}`); }
  else yield [p, o];
}
function tablesOf(sections) {
  const out = [];
  (function rec(list) { (list || []).forEach((s) => { if (s.table) out.push(s.table); rec(s.subsections); }); })(
    (sections || []).flatMap((sec) => sec.subsections || []));
  return out;
}
const stable = (ai) => JSON.stringify(ai).replace(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z/g, '<ts>');

(async () => {
  for (const input of CHARTS) {
    const label = `${input.name} (${input.gender})`;
    const { ai, template: templateJson } = await buildPayload(input);
    const text = JSON.stringify(ai);
    const strings = [...walk(ai)].filter(([, v]) => typeof v === 'string');
    const sc = ai.status_contract;
    const chain = ai.determination_chain;

    // 1. validator mapper sendiri
    const v = global.PenggilasJSONMapper.validateMachineReadableJSON(ai);
    assert.strictEqual(v.pass, true, `${label}: mapper validator -> ${JSON.stringify(v.violations)}`);

    // 2. setiap status yang dipancarkan terdaftar di kontrak status
    ['determination_state', 'verification_state', 'computation_state', 'synthesis_state'].forEach((k) =>
      assert(Array.isArray(sc[k]) && sc[k].length, `${label}: status_contract.${k} tidak dideklarasikan`));
    chain.claims.forEach((c) => {
      assert(sc.determination_state.includes(c.status), `${label}: status klaim di luar enum: ${c.status}`);
      assert(sc.verification_state.includes(c.verification_status), `${label}: verification_status di luar enum: ${c.verification_status}`);
      assert(sc.computation_state.includes(c.status_detail.computation), `${label}: computation di luar enum: ${c.status_detail.computation}`);
    });
    assert(sc.synthesis_state.includes(chain.synthesis.status), `${label}: synthesis.status di luar enum: ${chain.synthesis.status}`);

    // 3. tidak ada kebocoran nama internal / rujukan menggantung (header kolom ditetapkan kontrak -> dikecualikan)
    const leak = /\bbazi-data(?:\.js)?\b|\bPenggilasCore[ABC]\b|\b(?:RULE_TRACE|CLAIM_EVIDENCE_LINK|EVIDENCE_OWNERSHIP|RULE_EVIDENCE_LINK|DETERMINATION_CHAIN|SOURCE_INTERFERENCE_SCREEN_OPEN)\b|closureRecords/;
    strings.filter(([p]) => !p.includes('/table/headers[')).forEach(([p, s]) =>
      assert(!leak.test(s), `${label}: kebocoran internal di ${p}: ${s.slice(0, 80)}`));

    // 4. tidak ada gloss bilingual bersarang
    strings.forEach(([p, s]) =>
      assert(!/\([^()]*\([^()]*[\u4e00-\u9fff][^()]*\)[^()]*\)/.test(s), `${label}: gloss bersarang di ${p}: ${s.slice(0, 80)}`));

    // 5. bentuk determinations seragam (null eksplisit = source tidak menyuplai)
    ['day_master_strength', 'chart_pattern', 'transformation_following', 'useful_element'].forEach((k) => {
      assert(ai.determinations[k], `${label}: determinations.${k} hilang`);
      ['analytical_context', 'status', 'evidence'].forEach((f) =>
        assert(f in ai.determinations[k], `${label}: determinations.${k}.${f} tidak ada`));
    });

    // 6. basis confidence tidak berakhir dengan pemisah menggantung
    chain.claims.forEach((c) => {
      if (c.confidence && typeof c.confidence.basis === 'string')
        assert(!/[;,]\s*$/.test(c.confidence.basis), `${label}: basis terpotong: "${c.confidence.basis}"`);
    });

    // 7. struktur tabel payload identik dengan docx kontrak (jumlah dan header, berurutan).
    //    Fixture dibuat dari draft_template_bazi.docx; template JSON TIDAK dipakai karena turunan.
    const fx = JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures/contract_table_headers.json'), 'utf8')).table_headers;
    const got = tablesOf(ai.sections);
    assert.strictEqual(got.length, fx.length, `${label}: jumlah tabel ${got.length} != docx ${fx.length}`);
    const deviating = got.map((t, i) => (JSON.stringify(t.headers) === JSON.stringify(fx[i]) ? -1 : i)).filter((i) => i >= 0);
    const KNOWN_DEVIATIONS = []; // header payload harus identik dengan docx
    assert.deepStrictEqual(deviating, KNOWN_DEVIATIONS, `${label}: header menyimpang dari docx di tabel ${JSON.stringify(deviating)} (diharapkan ${JSON.stringify(KNOWN_DEVIATIONS)})`);

    // 7b. template JSON yang dilewati mapper juga harus identik dengan docx
    const tplHeaders = [];
    (function rec(list) { (list || []).forEach((x) => { if (x.table) tplHeaders.push(x.table.headers); rec(x.subsections); }); })(
      templateJson.sections.flatMap((sec) => sec.subsections || []));
    assert.deepStrictEqual(tplHeaders, fx, `${label}: header ai-result-template.json menyimpang dari docx`);

    // 7c. tidak ada objek debug mentah / id evidence internal di dalam string
    strings.forEach(([p, s]) => {
      assert(!/\{"[A-Za-z_]+":/.test(s), `${label}: JSON mentah di ${p}: ${s.slice(0, 80)}`);
      assert(!/Position:\s*[A-Z]+_[A-Z_]+/.test(s), `${label}: token posisi mentah di ${p}`);
    });
    chain.claims.forEach((c) => {
      const refs = c.evidence_refs || [];
      assert.strictEqual(refs.length, c.evidence_count, `${label}: evidence_refs != evidence_count (${c.claim})`);
      assert.strictEqual(new Set(refs).size, refs.length, `${label}: evidence_refs tidak unik (${c.claim})`);
      refs.forEach((r) => assert(!/^[A-Z0-9]+(?:_[A-Z0-9]+)+$/.test(r), `${label}: evidence_refs berupa id internal: ${r}`));
    });

    // 7d. klaim yang masih terbuka tidak boleh berconfidence di atas LIMITED
    chain.claims.filter((c) => ['UNRESOLVED', 'MULTI_METHOD', 'CONFLICT'].includes(c.status)).forEach((c) =>
      assert(!['HIGH', 'MODERATE'].includes(c.confidence && c.confidence.level), `${label}: ${c.status} berconfidence ${c.confidence && c.confidence.level} (${c.claim})`));

    // 8. status klaim tidak berubah oleh presentasi: determinations dan chain tidak boleh saling bertentangan pada FINAL
    chain.claims.filter((c) => c.status === 'FINAL').forEach((c) => {
      assert(c.evidence_count > 0 && (c.supported_by_rules || []).length > 0, `${label}: FINAL tanpa jejak evidence: ${c.claim}`);
    });

    // 9. determinisme: dua kali jalan identik (selain timestamp)
    const again = await buildPayload(input);
    assert.strictEqual(stable(again.ai), stable(ai), `${label}: keluaran tidak deterministik`);

    console.log(`PASS: ${label} — ${chain.claims.length} klaim, ${got.length} tabel, ${(text.length / 1024).toFixed(0)} KB`);
  }
  // Gender: kanonisasi tidak sensitif huruf besar-kecil, nilai tak dikenal ditolak (fail-closed)
  const lower = await buildPayload({ ...CHARTS[0], gender: 'male' });
  const exact = await buildPayload(CHARTS[0]);
  assert.strictEqual(stable(lower.ai), stable(exact.ai), "gender 'male' harus identik dengan 'Male'");
  let rejected = false;
  try { await buildPayload({ ...CHARTS[0], gender: 'x' }); } catch (e) { rejected = /Gender/.test(e.message); }
  assert(rejected, 'gender tidak dikenali harus ditolak, bukan diam-diam dihitung sebagai perempuan');
  console.log('PASS: gender kanonis dan fail-closed');
  console.log('PASS: invarian payload AI (enum, kebocoran, gloss, bentuk, struktur, determinisme)');
})().catch((e) => { console.error(e); process.exit(1); });
