// Stone Pro v14.2 checks: Jalali dates + picker, owner workshop accounts (materials, work by day/meter,
// payments, cheques with alerts + calendar file, invoices, reports), free/paid gating, worker rate + balance.
// Usage: CHROMIUM_PATH=/path/to/chrome node test-stage2.mjs <path to ysp-pwa folder>
import { chromium } from 'playwright';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(process.argv[2]);
const types = { '.html': 'text/html', '.js': 'text/javascript', '.json': 'application/json', '.png': 'image/png' };
const server = http.createServer((req, res) => {
  const p = path.join(root, decodeURIComponent(req.url.split('?')[0]).replace(/^\/$/, '/index.html'));
  if (!p.startsWith(root) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'content-type': types[path.extname(p)] || 'application/octet-stream' });
  fs.createReadStream(p).pipe(res);
});
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const url = `http://127.0.0.1:${server.address().port}/`;

let fails = 0;
const ok = (n, c, extra = '') => { console.log((c ? 'PASS ' : 'FAIL ') + n + (c ? '' : ' -> ' + extra)); if (!c) fails++; };
const PIN = '482913';
const b = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
const errs = [];
const newPage = async () => {
  const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, acceptDownloads: true });
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push(e.message)); p.on('dialog', (d) => d.accept());
  await p.goto(url); await p.waitForTimeout(1700);
  return p;
};
const store = (p, k) => p.evaluate((key) => JSON.parse(localStorage.getItem(key) || 'null'), k);
const isOpen = (p, sel) => p.evaluate((s) => !!document.querySelector(s) && document.querySelector(s).classList.contains('open'), sel);
const visible = (p, sel) => p.evaluate((s) => { const e = document.querySelector(s); return !!e && (e.offsetParent !== null || getComputedStyle(e).position === 'fixed'); }, sel);
const text = (p, sel) => p.evaluate((s) => (document.querySelector(s) || {}).textContent || '', sel);
async function onboard(p, role, trade, name) {
  await p.evaluate(() => { const b = document.querySelector('#ysp-terms .ysp-gate-body'); b.scrollTop = b.scrollHeight; b.dispatchEvent(new Event('scroll')); });
  await p.check('#ysp-terms-check'); await p.click('#ysp-terms-go');
  ok('role chooser title is "نقش خود را انتخاب کنید"', (await text(p, '#ysp-role h2')) === 'نقش خود را انتخاب کنید');
  await p.click(`.ysp-role-card[data-r="${role}"]`);
  if (trade) await p.selectOption('#ysp-trade', { label: trade });
  if (name) await p.fill('#ysp-name', name);
  await p.click('#ysp-role-save'); await p.waitForTimeout(300);
}
async function pickDate(p, iso) { // drives the real picker UI
  const j = await p.evaluate((i) => YSPDate.toJalali(i), iso);
  await p.selectOption('#ysp-jy', String(j.y)); await p.selectOption('#ysp-jm', String(j.m)); await p.selectOption('#ysp-jd', String(j.d));
  await p.click('#ysp-date-ok'); await p.waitForTimeout(150);
}
const sv = (p, id, v) => p.fill('#' + id, v);
const todayISO = (p) => p.evaluate(() => YSP.isoDate());
async function createPin(p) { await p.fill('#ysp-pin-new', PIN); await p.fill('#ysp-pin-new2', PIN); await p.click('#ysp-pin-save'); await p.waitForTimeout(700); }
async function confirmDelete(p, pin = PIN) { await p.fill('#ysp-delete-password', pin); await p.evaluate(() => confirmDeleteModal()); await p.waitForTimeout(500); }

/* ===== A. Jalali conversion ===== */
let p = await newPage();
const jd = await p.evaluate(() => {
  const r = {};
  r.nowruz = YSPDate.toJalali('2026-03-21');
  r.today = YSPDate.toJalali('2026-10-14');
  r.mehr = YSPDate.monthLength(1405, 7); r.farv = YSPDate.monthLength(1405, 1);
  r.back = YSPDate.toGregorian(1405, 8, 1);
  r.invalid = YSPDate.toGregorian(1404, 12, 30);
  let bad = 0, n = 0;
  for (let t = Date.UTC(2001, 2, 21, 12); t < Date.UTC(2072, 2, 21, 12); t += 86400000) {
    const d = new Date(t), iso = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
    const j = YSPDate.toJalali(iso); n++;
    if (YSPDate.toGregorian(j.y, j.m, j.d) !== iso) bad++;
    if (j.m === 12 && j.d === 30 && YSPDate.monthLength(j.y, 12) !== 30) bad++;
  }
  r.bad = bad; r.n = n;
  return r;
});
ok('Nowruz 1405 = 2026-03-21', jd.nowruz.y === 1405 && jd.nowruz.m === 1 && jd.nowruz.d === 1, JSON.stringify(jd.nowruz));
ok('2026-10-14 = 22 Mehr 1405', jd.today.y === 1405 && jd.today.m === 7 && jd.today.d === 22, JSON.stringify(jd.today));
ok('month lengths 31/30', jd.farv === 31 && jd.mehr === 30);
ok('1 Aban 1405 = 2026-10-23', jd.back === '2026-10-23', jd.back);
ok('non-existent Jalali date -> null', jd.invalid === null, String(jd.invalid));
ok(`round trip for ${jd.n} days (1380-1450)`, jd.bad === 0, String(jd.bad));
await onboard(p, 'owner', '', 'سازنده');
ok('owner sees the workshop tile, no worker-only tile', (await visible(p, '.tile[onclick*="YSPSite.open"]')) && !(await visible(p, '.tile[data-for="worker"]')));
ok('plan enforcement is off by default', await p.evaluate(() => YSPPlan.config.enforced === false));

/* ===== B. picker UI ===== */
await p.evaluate(() => { window.__pk = null; YSPDate.pick({ value: '2026-10-14' }).then((v) => { window.__pk = v; }); });
ok('picker opens on the given date', (await p.evaluate(() => document.getElementById('ysp-jy').value + '/' + document.getElementById('ysp-jm').value + '/' + document.getElementById('ysp-jd').value)) === '1405/7/22');
await p.selectOption('#ysp-jm', '12'); await p.selectOption('#ysp-jy', '1404');
ok('Esfand 1404 has 29 days in the picker', (await p.evaluate(() => document.querySelectorAll('#ysp-jd option').length)) === 29);
await p.selectOption('#ysp-jy', '1405'); await p.selectOption('#ysp-jm', '8'); await p.selectOption('#ysp-jd', '1'); await p.click('#ysp-date-ok'); await p.waitForTimeout(150);
ok('picker returns Gregorian ISO', (await p.evaluate(() => window.__pk)) === '2026-10-23');

/* ===== C. owner workshop ===== */
await p.evaluate(() => { newProject(); });
await p.fill('#p-name', 'ویلای شمال'); await p.evaluate(() => saveProject());
const proj = (await store(p, 'ysp_projects'))[0];
await p.evaluate(() => YSPSite.open('accounts'));
ok('empty workshop shows guidance', (await text(p, '#site-main')).includes('هنوز طرف حسابی'));
await p.waitForTimeout(700); await p.screenshot({ path: '/home/claude/sp2_site_empty.png' });

// material purchase with a new supplier, Persian digits typed
await p.evaluate(() => YSPSite.entry('material'));
await sv(p, 'sf-newname', 'بنگاه سیمان'); await sv(p, 'sf-title', 'سیمان'); await sv(p, 'sf-qty', '۱۰'); await sv(p, 'sf-unit', 'کیسه'); await sv(p, 'sf-rate', '۱۵۰٬۰۰۰'); await sv(p, 'sf-invoice', 'F-101');
await p.selectOption('#sf-project', proj.id);
ok('live total shown while typing', (await text(p, '#sf-total')).replace(/[^0-9]/g, '') === '1500000', await text(p, '#sf-total'));
await p.evaluate(() => YSPSite.saveEntry()); await p.waitForTimeout(150);
let parties = await store(p, 'ysp_parties'), entries = await store(p, 'ysp_entries');
ok('supplier created and purchase saved (10 x 150000)', parties.length === 1 && parties[0].kind === 'supplier' && entries.length === 1 && entries[0].amount === 1500000 && entries[0].invoiceNo === 'F-101');
ok('purchase has automatic date + exact time', entries[0].date === (await todayISO(p)) && entries[0].at.includes('T'));
ok('purchase linked to the project', entries[0].projectId === proj.id);
const evs = await store(p, 'ysp_events');
ok('party + entry creation in the event log with time', evs.some((e) => e.entity === 'party' && e.kind === 'create') && evs.some((e) => e.entity === 'entry' && e.kind === 'create' && e.title.includes('سیمان')));
const sup = parties[0];

// validation
await p.evaluate(() => YSPSite.entry('material'));
await p.evaluate(() => YSPSite.saveEntry());
ok('zero amount is refused with a message', (await text(p, '#sf-err')).includes('مبلغ'));
await p.evaluate(() => YSPSite.closeSheet());

// cash payment
await p.evaluate((id) => YSPSite.pay({ partyId: id }), sup.id);
await sv(p, 'sf-amount', '500000');
await p.evaluate(() => YSPSite.savePay()); await p.waitForTimeout(100);
let pays = await store(p, 'ysp_pays');
ok('cash payment saved with date/time', pays.length === 1 && pays[0].method === 'cash' && pays[0].at.includes('T') && pays[0].checkStatus === '');
await p.evaluate((id) => YSPSite.party(id), sup.id);
ok('supplier balance = 1,000,000', (await text(p, '#site-main')).replace(/[^0-9]/g, '').includes('1000000') && (await text(p, '#site-main')).includes('بدهکارم'));
ok('history shows date and clock time', /\d\d?:\d\d/.test(await text(p, '#site-main')) || /[۰-۹]{2}:[۰-۹]{2}/.test(await text(p, '#site-main')));

// work by day: a craftsman with 2 workers for 3 days
await p.evaluate(() => YSPSite.entry('work_day'));
await sv(p, 'sf-newname', 'استاد رضا'); await sv(p, 'sf-qty', '3'); await sv(p, 'sf-count', '2'); await sv(p, 'sf-rate', '800000');
ok('daily-wage work offers only the craftsman kind for new parties', (await p.evaluate(() => [...document.querySelectorAll('#sf-pkind option')].map((o) => o.value).join())) === 'craftsman');
ok('daily-wage total = days x workers x rate', (await text(p, '#sf-total')).replace(/[^0-9]/g, '') === '4800000');
await p.evaluate(() => YSPSite.saveEntry()); await p.waitForTimeout(100);
const rezaId = (await store(p, 'ysp_parties')).find((x) => x.name === 'استاد رضا').id;
// work by meter for the same craftsman
await p.evaluate((id) => YSPSite.entry('work_meter', { partyId: id }), rezaId);
await sv(p, 'sf-title', 'سنگ‌کاری نما'); await sv(p, 'sf-qty', '40'); await sv(p, 'sf-rate', '250000');
await p.evaluate(() => YSPSite.saveEntry()); await p.waitForTimeout(100);
ok('per-meter work saved (40 m x 250000)', (await store(p, 'ysp_entries')).some((e) => e.kind === 'work_meter' && e.amount === 10000000 && e.partyId === rezaId));
await p.evaluate(() => YSPSite.open('work'));
const wt = await text(p, '#site-main');
ok('work tab: person-days 6, meters 40, wages 14.8M', /(^|\D)6(\D|$)/.test(wt.replace(/[٬,]/g, '')) && wt.replace(/[^0-9]/g, '').includes('40') && wt.replace(/[^0-9]/g, '').includes('14800000'), wt.slice(0, 300));

// cheques: due in 2 days (alert), in 10 days (no alert), yesterday (overdue)
const t0 = await todayISO(p);
const addCheck = async (days, amount, no) => {
  await p.evaluate((id) => YSPSite.pay({ partyId: id }), sup.id);
  await sv(p, 'sf-amount', String(amount)); await p.selectOption('#sf-method', 'check'); await sv(p, 'sf-checkno', no);
  await p.click('button:has-text("انتخاب تاریخ سررسید")');
  await pickDate(p, await p.evaluate(([t, d]) => YSPDate.addDays(t, d), [t0, days]));
  await p.evaluate(() => YSPSite.savePay()); await p.waitForTimeout(100);
};
await p.evaluate(() => YSPSite.pay({ partyId: null }));
await p.selectOption('#sf-method', 'check');
await sv(p, 'sf-amount', '100000'); await sv(p, 'sf-newname', 'x');
await p.evaluate(() => YSPSite.savePay());
ok('cheque without due date is refused', (await text(p, '#sf-err')).includes('سررسید'));
await p.evaluate(() => YSPSite.closeSheet());
await addCheck(2, 300000, 'C-2');
await addCheck(10, 400000, 'C-10');
await addCheck(-1, 200000, 'C-OLD');
pays = await store(p, 'ysp_pays');
ok('3 cheques saved pending with the picked due dates', pays.filter((x) => x.method === 'check' && x.checkStatus === 'pending').length === 3 && pays.some((x) => x.checkNo === 'C-2' && x.dueDate === (t0 && pays.find((y) => y.checkNo === 'C-2').dueDate)));
const c2 = pays.find((x) => x.checkNo === 'C-2'), c10 = pays.find((x) => x.checkNo === 'C-10'), cold = pays.find((x) => x.checkNo === 'C-OLD');
ok('due dates are exactly +2, +10, -1 days', c2.dueDate === await p.evaluate(([t]) => YSPDate.addDays(t, 2), [t0]) && c10.dueDate === await p.evaluate(([t]) => YSPDate.addDays(t, 10), [t0]) && cold.dueDate === await p.evaluate(([t]) => YSPDate.addDays(t, -1), [t0]));
ok('alerts list the 2-day and the overdue cheque, not the 10-day one', await p.evaluate(() => { const a = YSPSite.alerts().map((x) => x.checkNo); return a.length === 2 && a.includes('C-2') && a.includes('C-OLD') && !a.includes('C-10'); }));
await p.evaluate(() => go('home'));
ok('home banner shows the cheque alert, tile badge shows 2', (await text(p, '#ysp-banners')).includes('هشدار سررسید') && (await visible(p, '#site-badge')) && (await text(p, '#site-badge')).replace(/[^0-9۰-۹]/g, '').length > 0);
await p.waitForTimeout(700); await p.screenshot({ path: '/home/claude/sp2_home_alert.png' });
await p.evaluate(() => YSPSite.open('checks'));
const ct = await text(p, '#site-main');
ok('cheque list shows overdue / tomorrow-or-days-left states', ct.includes('از سررسید گذشته') && ct.includes('روز مانده'), ct.slice(0, 250));
await p.waitForTimeout(700); await p.screenshot({ path: '/home/claude/sp2_checks.png' });

// calendar file
const [dl] = await Promise.all([p.waitForEvent('download'), p.click(`button[onclick*="calendar('${c2.id}')"]`)]);
const ics = fs.readFileSync(await dl.path(), 'utf8');
ok('calendar file: valid event on the due date with a day-before alarm', ics.startsWith('BEGIN:VCALENDAR\r\n') && ics.includes('DTSTART;VALUE=DATE:' + c2.dueDate.replace(/-/g, '')) && ics.includes('TRIGGER:-P1D') && ics.includes('END:VCALENDAR') && ics.includes('SUMMARY:'));

// statuses change the balance
const balOf = (id) => p.evaluate((i) => YSPSite.balanceOf(i).balance, id);
const b0 = await balOf(sup.id);
await p.evaluate((id) => YSPSite.checkStatus(id, 'bounced'), c2.id);
ok('a bounced cheque stops counting as paid (debt returns)', (await balOf(sup.id)) === b0 + 300000);
ok('bounced cheque no longer raises the alert', await p.evaluate(() => !YSPSite.alerts().some((x) => x.checkNo === 'C-2')));
await p.evaluate((id) => YSPSite.checkStatus(id, 'cleared'), cold.id);
ok('a cleared cheque stays paid and leaves the alerts', (await balOf(sup.id)) === b0 + 300000 && await p.evaluate(() => YSPSite.alerts().length === 0));
await p.evaluate((id) => YSPSite.checkStatus(id, 'pending'), c2.id);

// invoices
await p.evaluate(() => YSPSite.open('invoices'));
ok('invoices tab lists F-101 with its remaining', (await text(p, '#site-main')).includes('F-101') && (await text(p, '#site-main')).includes('مانده'));
const inv = (await store(p, 'ysp_entries')).find((e) => e.invoiceNo === 'F-101');
await p.evaluate((id) => YSPSite.pay({ entryId: id }), inv.id);
ok('payment form opens with the supplier and invoice preselected', (await p.evaluate(() => document.getElementById('sf-party').value)) === sup.id && (await p.evaluate(() => document.getElementById('sf-entry').value)) === inv.id);
await sv(p, 'sf-amount', '1500000'); await p.evaluate(() => YSPSite.savePay()); await p.waitForTimeout(100);
await p.evaluate(() => YSPSite.setFilter('unpaid'));
ok('"unpaid" filter hides the settled invoice', !(await text(p, '#site-main')).includes('F-101'));
await p.evaluate(() => YSPSite.setFilter('all'));
ok('settled invoice shows as settled', (await text(p, '#site-main')).includes('تسویه'));

// reports + sharing
await p.evaluate(() => YSPSite.open('report'));
const rt = await text(p, '#site-main');
ok('report splits cost by project and kind', rt.includes('ویلای شمال') && rt.includes('بدون پروژه') && rt.includes('خرید مصالح') && rt.includes('کارکرد متری'));
await p.evaluate(() => { window.__shared = null; navigator.share = async (d) => { window.__shared = d.text; }; });
await p.evaluate((id) => YSPSite.shareParty(id), rezaId);
const shared = await p.evaluate(() => window.__shared);
ok('statement text has date+time, rows and the balance', shared && shared.includes('صورت‌حساب استاد رضا') && shared.includes('مانده حساب') && /\d\d?:\d\d|[۰-۹]{2}:[۰-۹]{2}/.test(shared) && shared.includes('40'), shared);

// edit keeps the original timestamp; deletes need the PIN
const enRez = (await store(p, 'ysp_entries')).find((e) => e.kind === 'work_meter');
await p.evaluate((id) => YSPSite.entry('', { id }), enRez.id);
await sv(p, 'sf-rate', '300000'); await p.evaluate(() => YSPSite.saveEntry()); await p.waitForTimeout(100);
const edited = (await store(p, 'ysp_entries')).find((e) => e.id === enRez.id);
ok('editing recalculates but keeps the first timestamp', edited.amount === 12000000 && edited.at === enRez.at && edited.updatedAt);
ok('edit is in the event log with the changed fields', (await store(p, 'ysp_events')).some((e) => e.entity === 'entry' && e.kind === 'update' && e.fields.includes('rate')));
const before = (await store(p, 'ysp_entries')).length;
await p.evaluate((id) => YSPSite.delEntry(id), enRez.id);
ok('deleting a record needs a password first', await isOpen(p, '#ysp-sec-modal') && (await store(p, 'ysp_entries')).length === before);
await createPin(p);
await confirmDelete(p, '000111');
ok('wrong password keeps the record', (await store(p, 'ysp_entries')).length === before);
await confirmDelete(p);
ok('right password deletes it', (await store(p, 'ysp_entries')).length === before - 1);
await p.evaluate((id) => YSPSite.delParty(id), rezaId);
await confirmDelete(p);
ok('deleting a party removes its records too', !(await store(p, 'ysp_parties')).some((x) => x.id === rezaId) && !(await store(p, 'ysp_entries')).some((e) => e.partyId === rezaId));

// owner report includes workshop totals
await p.evaluate(() => go('reports'));
ok('owner report shows workshop totals', (await text(p, '#rep-stats')).includes('مانده بدهی کارگاه'));

// backup contains the new collections
await p.evaluate(() => { go('home'); openSettings(); });
ok('settings explains free/paid plan', (await text(p, '#ysp-settings-tools')).includes('همیشه رایگان') && (await text(p, '#ysp-settings-tools')).includes('چک‌های داده‌شده'));
const [dlb] = await Promise.all([p.waitForEvent('download'), p.click('text=دانلود فایل پشتیبان')]);
const bk = JSON.parse(fs.readFileSync(await dlb.path(), 'utf8'));
ok('backup includes parties, entries and payments', bk.data.ysp_parties.length >= 1 && bk.data.ysp_entries.length >= 1 && bk.data.ysp_pays.length >= 4);

/* ===== D. free / paid gating ===== */
await p.evaluate(() => { closeUtilityModal('ysp-settings-modal'); YSPPlan.config.enforced = true; go('home'); YSPSite.open('accounts'); });
await p.evaluate(() => YSPSite.tab('checks'));
ok('paid: cheques tab is locked', (await text(p, '#site-main')).includes('امکان اشتراکی'));
await p.evaluate(() => YSPSite.tab('invoices'));
ok('paid: invoices tab is locked', (await text(p, '#site-main')).includes('امکان اشتراکی'));
await p.evaluate(() => YSPSite.tab('report'));
ok('paid: report tab is locked', (await text(p, '#site-main')).includes('امکان اشتراکی'));
await p.evaluate(() => YSPSite.entry('work_meter'));
ok('paid: per-meter work shows the paywall', (await p.evaluate(() => getComputedStyle(document.getElementById('ysp-plan-modal')).display)) === 'flex' && !(await isOpen(p, '#site-sheet')));
await p.click('#ysp-plan-close');
await p.evaluate(() => YSPSite.pay());
await p.selectOption('#sf-method', 'check');
ok('paid: choosing cheque pops the paywall and resets to cash', (await p.evaluate(() => document.getElementById('sf-method').value)) === 'cash');
await p.click('#ysp-plan-close'); await p.evaluate(() => YSPSite.closeSheet());
await p.evaluate(() => { window.__shared = null; YSPSite.shareReport(); });
ok('paid: sharing is gated', (await p.evaluate(() => window.__shared)) === null && (await p.evaluate(() => getComputedStyle(document.getElementById('ysp-plan-modal')).display)) === 'flex');
await p.click('#ysp-plan-close');
ok('paid: alerts are hidden while locked', await p.evaluate(() => YSPSite.alerts().length === 0));
// free limits
await p.evaluate(() => { const ps = []; for (let i = 0; i < 5; i++) ps.push({ id: 'pt' + i, kind: 'worker', name: 'ک' + i, createdAt: YSP.nowISO() }); setArr('ysp_parties', ps); });
await p.evaluate(() => YSPSite.openParty());
await p.fill('#sf-name', 'ششمی'); await p.evaluate(() => YSPSite.saveParty());
ok('free limit: the 6th party is refused with the paywall', (await store(p, 'ysp_parties')).length === 5 && (await p.evaluate(() => getComputedStyle(document.getElementById('ysp-plan-modal')).display)) === 'flex');
await p.click('#ysp-plan-close'); await p.evaluate(() => YSPSite.closeSheet());
// pro unlock
await p.evaluate(() => localStorage.setItem('ysp_plan', JSON.stringify({ plan: 'pro' })));
await p.evaluate(() => { YSPSite.tab('checks'); });
ok('with a pro plan everything opens again', !(await text(p, '#site-main')).includes('امکان اشتراکی') && await p.evaluate(() => YSPPlan.allowed()));
await p.evaluate(() => { YSPPlan.config.enforced = false; localStorage.removeItem('ysp_plan'); });
await p.close();

/* ===== E. worker: rate, days, holiday, received, balance with employer (always free) ===== */
p = await newPage();
await onboard(p, 'worker', '', 'رضا');
await p.evaluate(() => { YSPPlan.config.enforced = true; });
ok('worker: workshop tile hidden', !(await visible(p, '.tile[onclick*="YSPSite.open"]')));
await p.evaluate(() => YSPRole.openMyLog());
await sv(p, 'wr-rate', '۸۰۰٬۰۰۰'); await sv(p, 'wr-hrate', '1000000');
await p.click('text=ذخیره نرخ‌ها'); await p.waitForTimeout(200);
const me = (await store(p, 'ysp_workers')).find((x) => x.id === 'wself');
ok('rates saved on the worker record', me.wage === 800000 && me.holidayWage === 1000000, JSON.stringify(me));
await p.evaluate(() => { recordWorkerWork('work'); recordWorkerWork('work'); recordWorkerWork('holiday'); });
await sv(p, 'worker-money-amount', '1500000'); await p.evaluate(() => recordWorkerMoney('payment'));
ok('balance = 2 days x 800k + 1 holiday x 1M - 1.5M received = 1.1M', (await text(p, '#worker-ledger-box')).replace(/[٬,]/g, '').includes('1100000'), (await text(p, '#worker-ledger-box')).slice(0, 300));
ok('card says the employer owes the worker', (await text(p, '#worker-ledger-box')).includes('کارفرما به من بدهکار است'));
ok('history uses worker wording', (await text(p, '#worker-ledger-box')).includes('دریافتی من از کارفرما') && !(await text(p, '#worker-ledger-box')).includes('پول داده به کارگر'));
// log an earlier day
const past = await p.evaluate(() => YSPDate.addDays(YSP.isoDate(), -5));
await p.click('button:has-text("تغییر تاریخ")'); await pickDate(p, past);
await p.evaluate(() => recordWorkerWork('work'));
const led = await store(p, 'ysp_worker_ledger');
ok('entry recorded for the chosen past day, with the real time of entry', led.some((r) => r.date === past && r.at.includes('T') && r.at.slice(0, 10) >= past));
ok('worker: no paywall even when enforcement is on', await p.evaluate(() => YSPPlan.allowed()) && !(await isOpen(p, '#site-sheet')));
await p.evaluate(() => go('reports'));
const wrp = await text(p, '#rep-stats');
ok('worker report: rate, earned, received, balance with employer', wrp.includes('نرخ روزمزد') && wrp.includes('مانده حساب نزد کارفرما') && wrp.includes('دریافتی من'), wrp);
await p.waitForTimeout(700); await p.screenshot({ path: '/home/claude/sp2_worker_report.png' });
await p.evaluate(() => YSPRole.openMyLog());
await p.waitForTimeout(700); await p.screenshot({ path: '/home/claude/sp2_worker_log.png' });

console.log('page errors:', errs);
console.log('FAILS', fails + errs.length);
await b.close(); server.close();
