'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const html = fs.readFileSync('public/index.html','utf8');
const server = fs.readFileSync('server.js','utf8');
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)];
if (!scripts.length) throw new Error('No inline app script found');
for (const match of scripts) new vm.Script(match[1], { filename:'public/index.html:inline-script' });
for (const id of ['manager-tools','manager-logs','inspection-result','inspect-project','refresh-manager','test-ai-provider']) {
  if (!html.includes(`id="${id}"`)) throw new Error(`Missing manager UI element: ${id}`);
}
if ((html.match(/class="bottomnav"/g)||[]).length !== 1) throw new Error('Expected exactly one navigation bar');
if ((html.match(/class="tabs"/g)||[]).length !== 0) throw new Error('Duplicate top tabs found');
console.log('Nova UI syntax and manager UI checks passed.');

if (!html.includes('integration-status') || !html.includes('checkIntegrations') || !server.includes('/api/integrations/status')) throw new Error('Automatic integration status check is missing');
console.log('Nova automatic GitHub/Render status check UI checks passed.');

if (!html.includes('autoLinkOnEntry') || !html.includes("localStorage.getItem('nova_control_token')")) throw new Error('Automatic link-on-entry UI check failed');
if (!server.includes('if (pushed.length === 0)')) throw new Error('No-change deployment guard missing');
console.log('Nova automatic link-on-entry checks passed.');
