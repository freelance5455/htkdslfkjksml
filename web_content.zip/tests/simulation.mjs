import assert from 'node:assert/strict';
import {PLAYERS,starterIds,FORMATIONS} from '../dist/data/players.js';
import {nextRank} from '../dist/data/ranking.js';
import {MatchEngine} from '../dist/game/engine.js';
const cfg={graphics:'Low',camera:'Broadcast',sound:false,halfMinutes:2,minimap:true,reducedMotion:false,autoSwitch:true};
assert.equal(PLAYERS.length,300);assert.equal(new Set(PLAYERS.map(p=>p.id)).size,300);assert.equal(new Set(PLAYERS.map(p=>p.name)).size,300);
assert.ok(Math.min(...PLAYERS.map(p=>p.overall))<55);assert.ok(Math.max(...PLAYERS.map(p=>p.overall))>90);
assert.equal(starterIds.length,11);assert.equal(new Set(starterIds).size,11);
assert.deepEqual(nextRank(6,0,'W'),{rank:7,championLosses:0});
assert.deepEqual(nextRank(6,0,'L'),{rank:5,championLosses:0});
assert.deepEqual(nextRank(6,0,'D'),{rank:6,championLosses:0});
assert.deepEqual(nextRank(0,0,'L'),{rank:0,championLosses:0});
assert.deepEqual(nextRank(17,0,'W'),{rank:18,championLosses:0});
assert.deepEqual(nextRank(18,0,'L'),{rank:18,championLosses:1});
assert.deepEqual(nextRank(18,1,'D'),{rank:18,championLosses:0});
assert.deepEqual(nextRank(18,2,'L'),{rank:17,championLosses:0});
function createEngine(formation='4-3-3'){const game=new MatchEngine(starterIds,{},formation,9,cfg,'Balanced',72,starterIds[9]);let pos={x:0,y:.23,z:0},vel={x:0,y:0,z:0};const ball={translation(){return pos;},linvel(){return vel;},setTranslation(p){pos={...p};},setLinvel(v){vel={...v};},setAngvel(){}};game.attachBall(ball);
 function tick(){game.simulate(1/60);if(game.holder===null){pos={x:pos.x+vel.x/60,y:Math.max(.22,pos.y+vel.y/60),z:pos.z+vel.z/60};vel.y-=9.81/60;if(pos.y===.22)vel.y=Math.max(0,-vel.y*.55);vel.x*=.997;vel.z*=.997;}}
 return{game,tick};}
for(const formation of Object.keys(FORMATIONS)){const{game,tick}=createEngine(formation);assert.equal(game.people.length,22);assert.equal(new Set(game.people.map(p=>p.side+':'+p.id)).size,22);assert.equal(game.phase,'kickoff');tick();assert.equal(game.clock,0);game.start();for(let i=0;i<10000;i++){tick();if(game.phase==='half')game.secondHalf();if(game.phase==='full')break;}
 assert.ok(game.clock>1200);assert.ok(game.people.every(p=>Number.isFinite(p.x)&&Number.isFinite(p.z)&&p.stamina>=0));
 console.log(`${formation}: 22 players, clock ${game.clock.toFixed(0)} sec, score ${game.score.join('-')}, passes ${game.statPasses.join('/')}`);
}
{const {game,tick}=createEngine();game.start();game.holder=null;game.placeBall(53.5,1,0);tick();assert.equal(game.phase,'goal');assert.equal(game.score[0],1);}
{const {game,tick}=createEngine();game.start();game.holder=null;game.placeBall(0,.25,35);tick();assert.equal(game.phase,'restart');assert.equal(game.restartName,'THROW-IN');for(let i=0;i<150;i++)tick();assert.equal(game.phase,'playing');}
console.log('PASS: database, ranking, four formations, simulation stability, goals, and restarts');
