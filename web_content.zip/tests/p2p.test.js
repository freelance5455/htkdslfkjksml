const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const P2P = require('../www/js/p2p.js');
const QR = require('../www/js/qr.js');

function fakeMailbox() {
  const topics = {}; let n = 0;
  return async (url, opt = {}) => {
    const u = new URL(url), topic = u.pathname.split('/').filter(Boolean)[0];
    if (opt.method === 'POST') {
      (topics[topic] = topics[topic] || []).push({ id: 'm' + (++n), time: Math.floor(Date.now() / 1000), message: opt.body });
      return { ok: true, status: 200, text: async () => '{}' };
    }
    const since = u.searchParams.get('since');
    const list = (topics[topic] || []).filter(x => since === 'all' || x.time >= +since);
    return { ok: true, status: 200, text: async () => list.map(x => JSON.stringify({ id: x.id, time: x.time, event: 'message', topic, message: x.message })).join('\n') + '\n{"event":"keepalive"}' };
  };
}

test('pairing code round-trips, including awkward names and a custom server', () => {
  const p = P2P.newPair();
  assert.equal(P2P.b64d(p.id).length, 16);
  assert.equal(P2P.b64d(p.key).length, 32);
  for (const name of ['Sam', 'Mr. T', 'Zoë 🐘', 'a.b.c', '']) {
    const code = P2P.encode({ ...p, habit: 'booze', name });
    const back = P2P.decode('Join me: ' + code + ' thanks');
    assert.deepEqual([back.id, back.key, back.habit, back.name, back.server], [p.id, p.key, 'booze', name, 'https://ntfy.sh']);
  }
  const c2 = P2P.encode({ ...p, habit: 'fap', name: 'X', server: 'https://my.box.example.com/' });
  assert.equal(P2P.decode(c2).server, 'https://my.box.example.com');
  assert.equal(P2P.decode('detox://pair/' + P2P.encode({ ...p, habit: 'scroll', name: 'Al' })).name, 'Al');
  assert.equal(P2P.decode('DTX1.short.nope.x.y'), null);
  assert.equal(P2P.decode(''), null);
  assert.equal(P2P.decode(null), null);
});

test('pairing code fits comfortably in a QR code', () => {
  const p = P2P.newPair();
  const code = P2P.encode({ ...p, habit: 'booze', name: 'Alexander-Jones X' });
  const q = QR.encode(code, 'M');
  assert.ok(q.version <= 8, 'version ' + q.version);
});

test('encryption: round trip, tamper, wrong key and wrong topic all fail safely', async () => {
  const p = P2P.newPair(), other = P2P.newPair(), t = P2P.topic(p.id, 'g');
  const sealed = await P2P.seal(p.key, t, { t: 'ev', kind: 'p', id: 'abc' });
  assert.ok(!sealed.includes('"kind"') && !sealed.includes('abc'));
  assert.deepEqual(await P2P.open(p.key, t, sealed), { t: 'ev', kind: 'p', id: 'abc' });
  assert.equal(await P2P.open(other.key, t, sealed), null);
  assert.equal(await P2P.open(p.key, P2P.topic(p.id, 'o'), sealed), null);
  const raw = P2P.b64d(sealed); raw[raw.length - 3] ^= 1;
  assert.equal(await P2P.open(p.key, t, P2P.b64e(raw)), null);
  assert.equal(await P2P.open(p.key, t, 'not base64 !!'), null);
  assert.equal(await P2P.open(p.key, t, ''), null);
  const again = await P2P.seal(p.key, t, { a: 1 });
  assert.notEqual(again, await P2P.seal(p.key, t, { a: 1 }), 'fresh IV every time');
});

test('mailbox: send, pull, since filter, and a guardian-to-owner conversation', async () => {
  P2P.setFetch(fakeMailbox());
  const p = P2P.newPair(), g = P2P.topic(p.id, 'g'), o = P2P.topic(p.id, 'o');
  assert.deepEqual(await P2P.pull('https://ntfy.sh', g, 0), []);
  await P2P.send('https://ntfy.sh', g, await P2P.seal(p.key, g, { t: 'ev', id: 'e1', kind: 'y', at: 1, by: 'Alex' }));
  await P2P.send('https://ntfy.sh', o, await P2P.seal(p.key, o, { t: 'st', habit: 'booze' }));
  const got = await P2P.pull('https://ntfy.sh', g, 0);
  assert.equal(got.length, 1);
  assert.equal((await P2P.open(p.key, g, got[0].message)).by, 'Alex');
  assert.equal((await P2P.pull('https://ntfy.sh', g, Math.floor(Date.now() / 1000) + 100)).length, 0);
  assert.equal((await P2P.pull('https://ntfy.sh', o, 0)).length, 1);
  P2P.setFetch(async () => ({ ok: false, status: 429, text: async () => '' }));
  await assert.rejects(P2P.send('https://ntfy.sh', g, 'x'), /429/);
  P2P.setFetch(null);
});

test('QR encoder basics', () => {
  const h = (t, e) => crypto.createHash('sha256').update(JSON.stringify(QR.encode(t, e).rows)).digest('hex').slice(0, 16);
  const a = QR.encode('HELLO', 'M');
  assert.equal(a.size, 21);
  assert.equal(QR.encode('x'.repeat(200), 'L').version, 9);
  assert.throws(() => QR.encode('x'.repeat(400), 'M'), /too long/);
  assert.equal(h('HELLO', 'M'), h('HELLO', 'M'));
  assert.match(QR.svg('HELLO'), /^<svg[\s\S]*<path d="M/);
});
