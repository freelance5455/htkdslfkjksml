import assert from "node:assert/strict";
import { jarvisCore } from "../server/core/jarvisCore.js";
import { selectModel } from "../server/ai/modelRouter.js";
import { canExecute } from "../server/security/permissions.js";
import { classifyFile } from "../server/files/filePipeline.js";
import { planAgent } from "../server/agents/orchestrator.js";

const r = await jarvisCore.handle("Explain this in detail");
assert.equal(r.depth, "DETAILED");
assert.equal(selectModel("write Python code").model, "coding-model");
assert.equal(canExecute("EXTERNAL_ACTION", false), false);
assert.equal(classifyFile("x.pdf"), "PDF");
assert.equal(planAgent("build website").stages.length, 11);

console.log("JARVIS master smoke tests: PASS");
