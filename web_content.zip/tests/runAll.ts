/**
 * JARVIS Automated Test Suite Runner
 * Executes config, database, and core loop test suites.
 */

// Configure test environment defaults before module loads
process.env.MODEL_TIMEOUT_MS = process.env.MODEL_TIMEOUT_MS || '2000';

import { runConfigTests } from './config.test.ts';
import { runDatabaseTests } from './database.test.ts';
import { runSecurityTests } from './security.test.ts';
import { runApiTests } from './api.test.ts';
import { runModelTests } from './models.test.ts';
import { runCoreLoopTests } from './coreLoop.test.ts';
import { runTask6Tests } from './task6.test.ts';
import { runTask7Tests } from './task7.test.ts';
import { runTask8Tests } from './task8.test.ts';
import { runTask9Tests } from './task9.test.ts';
import { runTask11Tests } from './task11.test.ts';
import { runFilmStudioAndUpgradeTests } from './filmStudioAndUpgrade.test.ts';
import { runAcceptanceTests } from './acceptanceTests.test.ts';

async function main() {
  console.log('====================================================');
  console.log('JARVIS SYSTEM AUTOMATED TEST SUITE EXECUTION');
  console.log('====================================================');

  const startTime = Date.now();
  let totalPassed = 0;
  let totalFailed = 0;

  try {
    const configResults = await runConfigTests();
    totalPassed += configResults.passed;
    totalFailed += configResults.failed;
  } catch (err: any) {
    console.error('Config test suite crashed:', err);
    totalFailed++;
  }

  try {
    const dbResults = await runDatabaseTests();
    totalPassed += dbResults.passed;
    totalFailed += dbResults.failed;
  } catch (err: any) {
    console.error('Database test suite crashed:', err);
    totalFailed++;
  }

  try {
    const securityResults = await runSecurityTests();
    totalPassed += securityResults.passed;
    totalFailed += securityResults.failed;
  } catch (err: any) {
    console.error('Security test suite crashed:', err);
    totalFailed++;
  }

  try {
    const apiResults = await runApiTests();
    totalPassed += apiResults.passed;
    totalFailed += apiResults.failed;
  } catch (err: any) {
    console.error('API test suite crashed:', err);
    totalFailed++;
  }

  try {
    const modelResults = await runModelTests();
    totalPassed += modelResults.passed;
    totalFailed += modelResults.failed;
  } catch (err: any) {
    console.error('Model test suite crashed:', err);
    totalFailed++;
  }

  try {
    const coreResults = await runCoreLoopTests();
    totalPassed += coreResults.passed;
    totalFailed += coreResults.failed;
  } catch (err: any) {
    console.error('Core loop test suite crashed:', err);
    totalFailed++;
  }

  try {
    const task6Results = await runTask6Tests();
    totalPassed += task6Results.passed;
    totalFailed += task6Results.failed;
  } catch (err: any) {
    console.error('Task #6 test suite crashed:', err);
    totalFailed++;
  }

  try {
    const task7Results = await runTask7Tests();
    totalPassed += task7Results.passed;
    totalFailed += task7Results.failed;
  } catch (err: any) {
    console.error('Task #7 test suite crashed:', err);
    totalFailed++;
  }

  try {
    const task8Results = await runTask8Tests();
    totalPassed += task8Results.passed;
    totalFailed += task8Results.failed;
  } catch (err: any) {
    console.error('Task #8 test suite crashed:', err);
    totalFailed++;
  }

  try {
    const task9Results = await runTask9Tests();
    totalPassed += task9Results.passed;
    totalFailed += task9Results.failed;
  } catch (err: any) {
    console.error('Task #9 test suite crashed:', err);
    totalFailed++;
  }

  try {
    const task11Results = await runTask11Tests();
    totalPassed += task11Results.passed;
    totalFailed += task11Results.failed;
  } catch (err: any) {
    console.error('Task #11 test suite crashed:', err);
    totalFailed++;
  }

  try {
    const filmStudioResults = await runFilmStudioAndUpgradeTests();
    totalPassed += filmStudioResults.passed;
    totalFailed += filmStudioResults.failed;
  } catch (err: any) {
    console.error('Film Studio & Upgrade test suite crashed:', err);
    totalFailed++;
  }

  try {
    const acceptanceResults = await runAcceptanceTests();
    totalPassed += acceptanceResults.passed;
    totalFailed += acceptanceResults.failed;
  } catch (err: any) {
    console.error('Acceptance test suite crashed:', err);
    totalFailed++;
  }

  const durationMs = Date.now() - startTime;
  console.log('\n====================================================');
  console.log(`TEST RESULTS SUMMARY (${durationMs}ms)`);
  console.log(`Total Passed: ${totalPassed}`);
  console.log(`Total Failed: ${totalFailed}`);
  console.log(`Status: ${totalFailed === 0 ? 'ALL TESTS PASSED' : 'TESTS FAILED'}`);
  console.log('====================================================');

  if (totalFailed > 0) {
    process.exit(1);
  } else {
    process.exit(0);
  }
}

main().catch((err) => {
  console.error('Test runner fatal error:', err);
  process.exit(1);
});
