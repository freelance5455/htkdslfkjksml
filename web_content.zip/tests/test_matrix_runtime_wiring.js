const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const ROOT = path.resolve(__dirname, '..');
global.window = global;
function load(rel) {
  vm.runInThisContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), { filename: rel });
}
load('data/global_classical_state_matrix.js');
load('data/evidence/closure_signal_contract.js');
load('data/evidence/runtime_evidence_normalizer.js');

const matrix = global.PENGGILAS_GLOBAL_CLASSICAL_STATE_MATRIX;
const runtime = global.PENGGILAS_CLASSICAL_RUNTIME_EVIDENCE_NORMALIZER;
const structural = matrix.audit();
assert.strictEqual(structural.pass, true, 'Matrix structural audit must pass');

const binding = matrix.auditRuntimeBinding(runtime);
assert.strictEqual(binding.errors.length, 0, 'Matrix/runtime family binding must have no errors');
assert.strictEqual(binding.warnings.length, 0, 'Every declared matrix family must have an explicit runtime binding');

matrix.entries.forEach(entry => {
  assert.doesNotThrow(() => runtime.normalize({}, entry.id), `${entry.id}: runtime normalizer must accept declared family`);
});

const source = fs.readFileSync(path.join(ROOT, 'data/evidence/runtime_evidence_normalizer.js'), 'utf8');
const b3CoreFamilies = matrix.entries.filter(e => /^CS-B3-GEJU-(OFFICER|WEALTH|RESOURCE|EATING-GOD|HURTING-OFFICER|SEVEN-KILLINGS|JIAN-LU)$/.test(e.id));
const runtimeBranchArea = source.slice(source.indexOf('function b3GeJuBranch'), source.indexOf('function b3Branches'));
const incomplete = b3CoreFamilies.filter(f => {
  const nonFormation = f.branches.filter(b => b[0] !== 'FORMATION_CLEAN');
  return nonFormation.some(b => runtimeBranchArea.indexOf(b[0]) === -1 && runtimeBranchArea.indexOf(b[1]) === -1);
});
assert.ok(incomplete.length >= 1, 'Audit must detect at least one declared-but-unimplemented B3 branch');
assert.ok(incomplete.some(f => f.id === 'CS-B3-GEJU-WEALTH'), 'Wealth Pattern branch gap must remain visible');

console.log('PASS: matrix structure/family binding are explicit; declared B3 branch gaps are detected and fail-closed.');
