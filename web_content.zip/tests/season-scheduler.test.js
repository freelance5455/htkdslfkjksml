import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState } from '../src/store.js';
import { generateSeasonCalendar } from '../src/calendar.js';
import { createClubCupSeason } from '../src/club-cup.js';
import { createGalacticCupSeason } from '../src/galactic-cup.js';
import { createFederalCupSeason, recordFederalCupResult } from '../src/federal-cup.js';
import { createChampionsLeagueSeason } from '../src/champions-league.js';
import { createIntergalacticCupSeason } from '../src/intergalactic-cup.js';
import { advanceToNextCalendarEvent, recordPlayedGame } from '../src/season-engine.js';
import { scheduleCompetitionCalendar, setOfficialLunarThursdays, setOfficialRegularSeasonEndDate, setOfficialIntergalacticDate, validateCompetitionSpacing, weekdayForSeasonDay } from '../src/competition-calendar.js';

function setup(){const s=createInitialState();s.season=12;for(const c of s.competitions)c.calendarEngineReady=true;generateSeasonCalendar(s);createGalacticCupSeason(s);createClubCupSeason(s);createChampionsLeagueSeason(s);createFederalCupSeason(s);createIntergalacticCupSeason(s);return s;}

test('le calendrier FGD place les 22 journées de championnat le samedi, à une semaine d’intervalle',()=>{
 const s=setup();const rows=s.calendar.fixtures.filter(f=>!f.competitionId);assert.equal(rows.length,396);for(const f of rows){assert.equal(f.scheduledWeekday,'samedi');assert.equal(f.scheduledDay,6+7*(f.round-1));}assert.equal(weekdayForSeasonDay(6),'samedi');
});

test('la Coupe Galactique occupe le mercredi des semaines des journées 6, 12 et 18',()=>{
 const s=setup();const rows=s.calendar.fixtures.filter(f=>f.competitionId==='coupe-galactique');assert.ok(rows.length>0);for(const f of rows){assert.equal(f.scheduledWeekday,'mercredi');assert.equal(f.scheduledDay,3+7*([6,12,18][f.round-1]-1));}
});

test('les tours de Coupe Fédéral reçoivent des dimanches distincts et libres',()=>{
 const s=setup();const rows=s.calendar.fixtures.filter(f=>f.competitionId==='coupe-federal');const dates=[...new Set(rows.map(f=>f.scheduledDay))];assert.equal(dates.length,1);assert.equal(weekdayForSeasonDay(dates[0]),'dimanche');assert.ok(!s.calendar.competitionEvents.some(e=>e.competitionId==='coupe-galactique'&&e.absoluteDay===dates[0]));
});

test('les jeudis lunaires officiels sont affectés aux tours de Coupe des Clubs sans chevauchement',()=>{
 const s=setup();const dates=Array.from({length:7},(_,i)=>({weekday:'jeudi',lunarMonth:i<4?1:2,lunarDay:i<4?4+i*7:2+(i-4)*7,absoluteDay:4+i*7}));setOfficialLunarThursdays(s,dates);const f=s.calendar.fixtures.find(x=>x.competitionId==='coupe-des-clubs');assert.equal(f.scheduledDay,4);assert.equal(f.scheduledWeekday,'jeudi');assert.equal(s.calendar.scheduleValidation.valid,true);const events=s.calendar.competitionEvents;assert.equal(validateCompetitionSpacing(events).valid,true);
});

test('le calendrier bloque les dates AGD tant que la fin FGD n’est pas enregistrée',()=>{
 const s=setup();assert.throws(()=>setOfficialIntergalacticDate(s,'intergalactique',{absoluteDay:156,phase:'after-regular-season'}),/enregistrer la date officielle de fin de saison FGD/);setOfficialRegularSeasonEndDate(s,{absoluteDay:153,phase:'end-of-regular-season'});assert.throws(()=>setOfficialIntergalacticDate(s,'intergalactique',{absoluteDay:154,phase:'after-regular-season'}),/jour complet/);setOfficialIntergalacticDate(s,'intergalactique',{absoluteDay:156,phase:'after-regular-season'});assert.throws(()=>setOfficialIntergalacticDate(s,'intergalactique-clubs',{absoluteDay:157,phase:'after-regular-season'}),/jour complet/);setOfficialIntergalacticDate(s,'intergalactique-clubs',{absoluteDay:170,phase:'after-regular-season'});assert.equal(s.calendar.officialCalendars.AGD.coupeIntergalactiqueGalaxies.absoluteDay,156);assert.equal(s.calendar.officialCalendars.AGD.intergalactiqueClubs.absoluteDay,170);assert.equal(s.calendar.scheduleValidation.valid,true);
});

test('le validateur accepte des jours consécutifs mais détecte deux compétitions le même jour',()=>{
 assert.equal(validateCompetitionSpacing([{competitionId:'championnat',absoluteDay:6},{competitionId:'coupe',absoluteDay:8}]).valid,true);assert.equal(validateCompetitionSpacing([{competitionId:'coupe-a',absoluteDay:6},{competitionId:'coupe-b',absoluteDay:7}]).valid,true);assert.equal(validateCompetitionSpacing([{competitionId:'coupe-a',absoluteDay:6},{competitionId:'coupe-b',absoluteDay:6}]).valid,false);
});

test('l’avancement central simule les matchs IA et attend le match du club dirigé avant le prochain événement',()=>{
 const s=setup();setOfficialLunarThursdays(s,Array.from({length:7},(_,i)=>({weekday:'jeudi',lunarMonth:i<4?1:2,lunarDay:4+i*7,absoluteDay:4+i*7})));setOfficialRegularSeasonEndDate(s,{absoluteDay:153,phase:'end-of-regular-season'});setOfficialIntergalacticDate(s,'intergalactique',{absoluteDay:156,phase:'after-regular-season'});setOfficialIntergalacticDate(s,'intergalactique-clubs',{absoluteDay:170,phase:'after-regular-season'});const first=advanceToNextCalendarEvent(s);assert.equal(first.event.competitionId,'champions-league');assert.equal(s.calendar.currentDay,2);assert.ok(first.userFixture);assert.equal(first.simulated.length,15);const result=recordPlayedGame(s,first.userFixture.id,1);assert.equal(result.accepted,true);const next=advanceToNextCalendarEvent(s);assert.equal(next.event.competitionId,'coupe-des-clubs');assert.equal(s.calendar.currentDay,4);assert.equal(next.simulated.length,6);
});

test('une fenêtre AGD officielle sans moteur ne peut pas être sautée par l’avancement',()=>{
 const s=setup();setOfficialLunarThursdays(s,Array.from({length:7},(_,i)=>({weekday:'jeudi',lunarMonth:i<4?1:2,lunarDay:4+i*7,absoluteDay:4+i*7})));setOfficialRegularSeasonEndDate(s,{absoluteDay:153,phase:'end-of-regular-season'});setOfficialIntergalacticDate(s,'intergalactique',{absoluteDay:156,phase:'after-regular-season'});setOfficialIntergalacticDate(s,'intergalactique-clubs',{absoluteDay:170,phase:'after-regular-season'});s.calendar.currentDay=169;const result=advanceToNextCalendarEvent(s);assert.equal(result.blockedByUnimplementedCompetition,true);assert.equal(s.calendar.currentDay,169);assert.equal(result.event.authority,'AGD');
});

test('la saison ne démarre pas tant que les moteurs des huit compétitions et les dates lunaires ne sont pas prêts',()=>{
 const s=createInitialState();generateSeasonCalendar(s);const result=advanceToNextCalendarEvent(s);assert.equal(result.blockedByIncompleteSeasonSetup,true);assert.ok(!result.readiness.missingCompetitionEngines.some(c=>c.id==='champions-league'));assert.ok(!result.readiness.missingCompetitionEngines.some(c=>c.id==='intergalactique'));assert.ok(!result.readiness.missingCompetitionEngines.some(c=>c.id==='intergalactique-clubs'));assert.ok(!result.readiness.missingCompetitionEngines.some(c=>c.id==='dame-or'));assert.equal(result.readiness.missingLunarThursdays,7);assert.equal(result.readiness.missingFgdEndDate,true);assert.equal(result.readiness.missingAgdDates.length,0);assert.equal(s.calendar.currentDay,1);
});

test('la création d’un nouveau tour de Coupe Fédéral ne déplace pas les journées Champions League déjà réservées',()=>{
 const s=setup();const cl=s.competitions.find(c=>c.id==='champions-league'),fed=s.competitions.find(c=>c.id==='coupe-federal');const before=cl.rounds.map(r=>s.calendar.fixtures.find(f=>f.id===r.fixtureIds[0]).scheduledDay);const first=fed.rounds[0];
 for(const id of first.fixtureIds){const f=s.calendar.fixtures.find(x=>x.id===id);recordFederalCupResult(s,id,1,0,{winnerId:f.home});}
 const after=cl.rounds.map(r=>s.calendar.fixtures.find(f=>f.id===r.fixtureIds[0]).scheduledDay);assert.deepEqual(after,before);assert.equal(s.calendar.scheduleValidation.valid,true);
});

test('le calendrier réserve les 19 créneaux connus, chacun le jour propre à sa compétition sans inventer le calendrier de la Coupe Lunaire',()=>{
 const s=setup();const clubs=s.divisions.flatMap(d=>d.clubs.map(c=>c.id));
 const add=(competitionId,round,competitionName)=>{const home=clubs[(round*3+competitionId.length)%clubs.length],away=clubs[(round*3+competitionId.length+1)%clubs.length];s.calendar.fixtures.push({id:`S${s.season}:${competitionId}:R${round}:reserve`,season:s.season,divisionId:null,competitionId,competitionName,round,roundLabel:`Tour ${round}`,home,away,status:'scheduled',score:null});};
 for(const r of [2,3])add('coupe-galactique',r,'Coupe Galactique');
 for(const r of [2,3,4,5,6])add('coupe-federal',r,'Coupe Fédéral');
 for(const r of [7,8,9,10])add('champions-league',r,'Champions League Galactique');
  setOfficialLunarThursdays(s,Array.from({length:7},(_,i)=>({weekday:'jeudi',lunarMonth:i<4?1:2,lunarDay:4+i*7,absoluteDay:4+i*7})));
 const events=s.calendar.competitionEvents.filter(e=>['coupe-galactique','coupe-federal','champions-league','coupe-lunaire'].includes(e.competitionId));
 const tuesdays=events.map(e=>e.absoluteDay);assert.equal(events.length,19);assert.equal(new Set(tuesdays).size,19);assert.ok(events.every(e=>weekdayForSeasonDay(e.absoluteDay)===({'coupe-galactique':'mercredi','coupe-federal':'dimanche','champions-league':'mardi'})[e.competitionId]&&e.absoluteDay<=154));assert.equal(s.calendar.scheduleValidation.valid,true);assert.equal(s.calendar.scheduleValidation.clubConflicts.length,0);
});


test('la Coupe Lunaire AGD est inscrite en mois 12 sur trois créneaux hebdomadaires',async()=>{
 const s=setup();
 const {createLunarCupSeason}=await import('../src/lunar-cup.js');
 createLunarCupSeason(s);scheduleCompetitionCalendar(s);s.calendar.currentDay=342;
 const rows=s.calendar.competitionEvents.filter(x=>x.competitionId==='coupe-lunaire');
 assert.deepEqual(rows.map(x=>x.absoluteDay),[342]);assert.equal(rows[0].authority,'AGD');
 const cup=s.competitions.find(c=>c.id==='coupe-lunaire');
 for(const id of [...cup.rounds[0].fixtureIds]){const f=s.calendar.fixtures.find(x=>x.id===id);const {recordLunarCupResult}=await import('../src/lunar-cup.js');recordLunarCupResult(s,id,1,0,{winnerId:f.home});}
 assert.deepEqual(s.calendar.competitionEvents.filter(x=>x.competitionId==='coupe-lunaire').map(x=>x.absoluteDay),[342,349]);
});
