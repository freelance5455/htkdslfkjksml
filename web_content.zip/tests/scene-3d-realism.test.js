import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const scene = await readFile(new URL('../src/scene-3d.js', import.meta.url), 'utf8');

test('le rendu 3D utilise un éclairage spéculaire, une lumière de remplissage et un contour lumineux', () => {
  for (const token of ['specular=pow', 'float fill=', 'float rim=', 'uCamera', 'uTime']) {
    assert.ok(scene.includes(token), `amélioration lumineuse absente : ${token}`);
  }
});

test('les figurines possèdent des détails anatomiques et vestimentaires visibles', () => {
  for (const token of ['const headDrop=', 'skin=', 'addBox(out,x-.15', 'addCylinder(out,x+lean,z,.09', 'Yeux, nez et bouche', 'addSphere(out,x+lean+.065']) {
    assert.ok(scene.includes(token), `détail du damiste absent : ${token}`);
  }
});

test('les tribunes comprennent des silhouettes de supporters avec têtes et bras', () => {
  assert.match(scene, /Public stylisé/);
  assert.match(scene, /addSphere\(out,sx,y\+\.235,sz/);
  assert.match(scene, /addLimb\(out,shoulder,hand/);
});

test('les améliorations restent dans le moteur WebGL existant', () => {
  assert.match(scene, /gl\.drawArrays\(gl\.TRIANGLES/);
  assert.match(scene, /function buildScene/);
  assert.match(scene, /function animateMove/);
  assert.match(scene, /function playPose/);
});
