"""Export postupu → smazání dat → import vrátí všechno (postup, levely, Studio, nastavení, dev režim):  python3 -I tests/ui_roundtrip.py"""
import glob, json
from playwright.sync_api import sync_playwright
exe = (glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome') or [None])[0]
results, errs = [], []
def check(n, c, x=''): results.append(bool(c)); print(('OK   ' if c else 'FAIL ') + n + (' ' + str(x) if x != '' else ''))
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=exe, args=['--no-sandbox']); ctx = b.new_context(); pg = ctx.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('file:///home/claude/BubbleDefence/index.html'); pg.wait_for_selector('.content:not(.hidden) .intro')
    pg.evaluate("""(() => { BD.dev.unlocked = true; BD.dev.studio = true; BD.studio.enable(true);
      BD.studio.create('towers', 'Moje'); const id = BD.studio.lastId; BD.studio.moveTower(id, 'normal_b', 1);
      BD.studio.setSprite('towers', id, { v: 1, nodes: [BD.render.sprite.node('circle', { name: 'X' })] });
      BD.studio.set('towers', 'normal', 'base.dmg', 77); BD.studio.remove('towers', 'boost_c'); BD.studio.create('enemies', 'Zlobr');
      const P = BD.store.profile; P.settings.music = 33; P.story.completed = ['x1']; P.bestiary.seen['towers:normal'] = 1;
      P.editor.levels.push({ id: 'abc', name: 'Můj level', w: 10, h: 10, spawns: [{ side: 'L', pos: 8, len: 4 }], exit: { side: 'R', pos: 8, len: 4 }, rocks: [], walls: [], towers: [] }); BD.store.flush(); })()""")
    txt = pg.evaluate('BD.store.exportJSON()'); o = json.loads(txt)
    check('export obsahuje postup, levely, Studio, bestiář, nastavení i dev režim', all(k in o['profile'] for k in ['story', 'free', 'editor', 'studio', 'bestiary', 'settings']) and o.get('dev') == {'unlocked': True, 'studio': True})
    # nový "prohlížeč"
    ctx2 = b.new_context(); pg2 = ctx2.new_page(); pg2.on('pageerror', lambda e: errs.append(str(e)))
    pg2.goto('file:///home/claude/BubbleDefence/index.html'); pg2.wait_for_selector('.content:not(.hidden) .intro')
    check('v čistém prohlížeči nic z toho není', pg2.evaluate("!BD.dev.unlocked && !BD.data.towers.moje && BD.data.towers.normal.base.dmg === 15 && BD.store.profile.editor.levels.length === 0"))
    r = pg2.evaluate('(t) => BD.store.importJSON(t)', txt)
    check('import projde', r.get('ok') is True, r)
    check('Studio je zapnuté a vlastní věž je hned ve hře (pod Silnou), úprava a smazání platí', pg2.evaluate("BD.studio.enabled && BD.data.towers.moje && BD.data.towers.moje.parent === 'normal_b' && !!BD.data.towers.moje.sprite && BD.data.towers.normal.base.dmg === 77 && !BD.data.towers.boost_c && !!BD.systems.enemies.TYPES.zlobr"))
    check('postup, level, bestiář a nastavení jsou zpět', pg2.evaluate("BD.store.profile.settings.music === 33 && BD.store.profile.story.completed[0] === 'x1' && BD.store.profile.bestiary.seen['towers:normal'] === 1 && BD.store.profile.editor.levels.length === 1 && BD.store.profile.editor.levels[0].name === 'Můj level'"))
    check('dev režim je zapnutý (terminál odemčený)', pg2.evaluate('BD.dev.unlocked && BD.dev.studio'))
    o2 = json.loads(pg2.evaluate('BD.store.exportJSON()'))['profile']['studio']['items']; o1 = o['profile']['studio']['items']; check('znovu exportovaný soubor obsahuje stejné položky Studia', {k: sorted(o2[k]) for k in o2} == {k: sorted(o1[k]) for k in o1})
    check('bez chyb', not errs, errs)
    b.close()
print('\nvýsledek: %d/%d' % (sum(results), len(results)), '| chyby:', errs or 'žádné')
