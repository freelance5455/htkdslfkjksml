import { SEED } from './seed.mjs';
// Creates an empty company through the real onboarding form, then (optionally) fills it with test data via the store API.
export async function startCompany(p, { seed = true, user = 'Tester', company = 'Test Co', plan = 'pro' } = {}) {
  if (await p.locator('#legalChk').count()) { await p.check('#legalChk'); await p.click('.onboard button.btn:not(.sec)'); await p.waitForTimeout(300); }
  const inputs = p.locator('.onboard input.inp');
  await inputs.nth(0).fill(user); await inputs.nth(1).fill(company);
  await p.click('.onboard button.btn:not(.sec)'); await p.waitForTimeout(500);
  if (plan) await p.evaluate((pl) => { const T = AN_TEST, S = AN_UI.store, co = S.company(AN_UI.ctx), n = S.now(); const e = T.signEvent({ id: 'evt_t_' + pl, type: 'invoice.paid', created: n, data: { plan: pl, periodEnd: n + 30 * 864e5 } }); return S.handleBillingEvent(co.id, e.raw, e.sig, T.DEMO_SECRET); }, plan);
  if (seed) { await p.evaluate(SEED); await p.evaluate(() => AN_UI.render()); await p.waitForTimeout(300); }
}
