// node tests/e2e_scroll.js — açıklama kaydırma (fare tekerleği + gerçek dokunma), harita kamerası/seçimi etkilenmez
const { chromium } = require('playwright');
const proj = process.argv[2] || require('path').resolve(__dirname, '..');
async function swipe(cdp, x, y, dy) {
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x, y }] });
  for (let i = 1; i <= 14; i++) { await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x, y: y + dy * i / 14 }] }); await new Promise(r => setTimeout(r, 16)); }
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
}
(async () => {
  const b = await chromium.launch(); let fails = 0;
  const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fails++; };
  for (const [name, vw, vh, touch, lgf] of [['desktop', 1100, 700, false, false], ['phone', 360, 640, true, false], ['phone-largefont', 360, 640, true, true]]) {
    const ctx = await b.newContext({ viewport: { width: vw, height: vh }, hasTouch: touch, isMobile: touch });
    const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(String(e)));
    await p.goto('file://' + proj + '/index.html'); await p.waitForTimeout(1000);
    await p.evaluate((lgf) => { newGame(1); closeMod(); if (lgf) document.body.classList.add('lgf'); document.documentElement.classList.add('lgf'); }, lgf);
    await p.waitForTimeout(400);
    await p.evaluate(() => { const o = I18N.hist; window.__oh = o; I18N.hist = function (id, l) { const t = o.call(I18N, id, l) || ''; return (id === 'LUX' || id === 'BHS') ? (t + ' ' + t + ' ' + t) : t; }; });
    for (const lang of ['tr', 'en']) {
      await p.evaluate((l) => { if (L != l) setLang(); closeMod(); }, lang);
      // en uzun açıklamayı bul
      const id = await p.evaluate(() => { let best = null, bl = 0; R.forEach(r => { const n = (I18N.hist(r.id, L) || '').length; if (n > bl && M[r.id]) { bl = n; best = r.id; } }); return best; });
      await p.evaluate((id) => { pickC(id); }, id); await p.waitForTimeout(900);
      const m = await p.evaluate(() => { const h = document.getElementById('v7hs'); return { sh: h.scrollHeight, ch: h.clientHeight, cls: h.className, cam: [CAM.x, CAM.y, CAM.k], sel: G.sel, len: h.textContent.length }; });
      console.log(name, lang, id, JSON.stringify(m));
      // kısa metin: gereksiz kaydırma yok
      const shortId = await p.evaluate(() => { let best = null, bl = 1e9; R.forEach(r => { const n = (I18N.hist(r.id, L) || '').length; if (n < bl && M[r.id]) { bl = n; best = r.id; } }); return best; });
      await p.evaluate((id) => { pickC(id); }, shortId); await p.waitForTimeout(700);
      const sm = await p.evaluate(() => { const h = document.getElementById('v7hs'); return { sh: h.scrollHeight, ch: h.clientHeight, cls: h.className }; });
      ok(sm.sh - sm.ch <= 2 ? !/\b(mb|mt|sc)\b/.test(sm.cls) : true, `${name}/${lang} short text (${shortId}) no scroll artifacts ${JSON.stringify(sm)}`);
      await p.evaluate((id) => { pickC(id); }, id); await p.waitForTimeout(900);
      const m1 = await p.evaluate(() => { const h = document.getElementById('v7hs'); return { sh: h.scrollHeight, ch: h.clientHeight, cls: h.className, cam: [CAM.x, CAM.y, CAM.k], sel: G.sel }; });
      if (m1.sh - m1.ch > 2) {
        ok(/\bmb\b/.test(m1.cls) && !/\bmt\b/.test(m1.cls), `${name}/${lang} long text initially: fade bottom only (${m1.cls})`);
        const box = await p.evaluate(() => { const r = document.getElementById('v7hs').getBoundingClientRect(); return [r.x + r.width / 2, r.y + r.height / 2]; });
        if (!touch) { await p.mouse.move(box[0], box[1]); await p.mouse.wheel(0, 400); }
        else {
          const cdp = await ctx.newCDPSession(p);
          await swipe(cdp, box[0], box[1] + 20, -160);
        }
        await p.waitForTimeout(500);
        const m2 = await p.evaluate(() => { const h = document.getElementById('v7hs'); return { top: h.scrollTop, max: h.scrollHeight - h.clientHeight, cls: h.className, cam: [CAM.x, CAM.y, CAM.k], sel: G.sel }; });
        ok(m2.top >= m2.max - 2, `${name}/${lang} scrolled to end (${m2.top}/${m2.max})`);
        ok(!/\bmb\b/.test(m2.cls) && /\bmt\b/.test(m2.cls), `${name}/${lang} end: bottom fade removed (${m2.cls})`);
        ok(JSON.stringify(m2.cam) === JSON.stringify(m1.cam) && m2.sel === m1.sel, `${name}/${lang} map camera and selection untouched`);
        // yukarı
        if (!touch) await p.mouse.wheel(0, -600); else { const cdp = await ctx.newCDPSession(p); await swipe(cdp, box[0], box[1] - 20, 220); }
        await p.waitForTimeout(500);
        const m3 = await p.evaluate(() => ({ top: document.getElementById('v7hs').scrollTop, cam: [CAM.x, CAM.y, CAM.k] }));
        ok(m3.top <= 2, `${name}/${lang} scrolled back to top (${m3.top})`);
        ok(JSON.stringify(m3.cam) === JSON.stringify(m1.cam), `${name}/${lang} camera still unchanged after scrolling up`);
      } else console.log(`${name}/${lang}: long text fits (${m1.sh}/${m1.ch}) — no scroll needed`);
    }
    if (name === 'phone-largefont') await p.screenshot({ path: '/home/claude/work/tools/scroll-phone.png' });
    ok(errs.length === 0, `${name} no page errors ${errs.join('|')}`);
    await ctx.close();
  }
  console.log(fails ? 'FAILS: ' + fails : 'ALL PASS'); await b.close();
})();
