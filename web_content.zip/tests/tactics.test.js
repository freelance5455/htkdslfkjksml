import test from 'node:test';
import assert from 'node:assert/strict';
import { getTactics, setTactic, tacticsSummary, zoneColumns, DEFAULT_TACTICS } from '../src/tactics.js';

test('les tactiques par défaut sont équilibrées et se rechargent proprement', () => {
  assert.deepEqual(getTactics({}), DEFAULT_TACTICS);
  assert.deepEqual(getTactics({ options: { tactics: { style: 'nimporte', rythme: 'rapide' } } }), { formation: 'centre', style: 'equilibre', rythme: 'rapide' });
});

test('setTactic enregistre une consigne valide et refuse une valeur inconnue', () => {
  const state = {};
  setTactic(state, 'style', 'attaque');
  assert.equal(state.options.tactics.style, 'attaque');
  setTactic(state, 'style', 'inconnu');
  setTactic(state, 'cle-inconnue', 'x');
  assert.deepEqual(getTactics(state), { formation: 'centre', style: 'attaque', rythme: 'normal' });
  assert.match(tacticsSummary(state), /Attaque · rythme normal · formation centre/);
});

test('chaque formation occupe quatre colonnes', () => {
  for (const f of ['centre', 'ailes', 'mixte']) assert.equal(zoneColumns(f).size, 4);
});

import { getTacticBonus } from '../src/tactics.js';

test('les consignes équilibrées ne changent rien et le bonus reste borné', () => {
  assert.equal(getTacticBonus({}, 60, 60, 80), 0);
  const fast = { options: { tactics: { style: 'attaque', rythme: 'rapide' } } };
  assert.equal(getTacticBonus(fast, 70, 60, 80), 5);
  assert.equal(getTacticBonus(fast, 50, 60, 40), -5);
});

test('le style prudent protège un club plus faible et pénalise un club plus fort', () => {
  const prudent = { options: { tactics: { style: 'prudent' } } };
  assert.equal(getTacticBonus(prudent, 50, 60, 65), 3);
  assert.equal(getTacticBonus(prudent, 70, 60, 65), -2);
});
