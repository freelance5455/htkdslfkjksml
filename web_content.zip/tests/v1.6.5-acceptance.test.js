const fs = require('fs');
const assert = require('assert');
const html = fs.readFileSync('android/app/src/main/assets/www/index.html', 'utf8');

function has(pattern, message) {
  assert.match(html, pattern, message);
}

// RED: these should fail until v1.6.5 is implemented.
has(/admin.*123456|123456.*admin/i, 'admin default login must exist');
has(/data-page="filecenter"/, 'file center navigation must exist');
has(/function renderFileCenterV16\(/, 'file center renderer must exist');
has(/function importSectionFileV16\(/, 'section file import must exist');
has(/function reloadLastImportV16\(/, 'last-file reload must exist');
has(/function restoreFullBackupV16\(/, 'full backup restore must exist');
has(/function exportReportV16\(/, 'report export must exist');
has(/u.passwordHash\?\{\}:\{password:u.password\|\|'1234'\}/, 'hashed users must not receive a plaintext fallback password');
has(/saveBlobChosenPathV16|saveBlobToChosenPathV16/, 'chosen-path save must exist');
has(/const writable=\['parties','items','checks','warehouses'\]/, 'only master-data sections may import directly');
has(/mode:'PREVIEW'/, 'accounting-sensitive sections must use preview mode');
has(/fileCenterPreviewTableV16\(/, 'file center must show an import preview');
has(/ACTION_CREATE_DOCUMENT|saveFileWithChooser|saveBlobChosenPathV16/, 'selected save path support must remain connected');
has(/operations:\{label:'عملیات روزانه'/, 'operations template definition must exist');
has(/checks:\{label:'چک‌ها'/, 'checks template definition must exist');
has(/گزارش.*روزانه|گزارش فروش/, 'predefined report templates must exist');

console.log('v1.6.5 acceptance tests passed');
