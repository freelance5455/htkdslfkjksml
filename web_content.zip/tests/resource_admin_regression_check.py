#!/usr/bin/env python3
"""Static and SQLite-backed regression checks for Tools & Tutorials and admin controls."""
from pathlib import Path
import sqlite3
ROOT = Path(__file__).resolve().parents[1]
public = (ROOT / 'tools-tutorials.php').read_text(encoding='utf-8')
service = (ROOT / 'app/resources.php').read_text(encoding='utf-8')
admin = (ROOT / 'admin_resources_view.php').read_text(encoding='utf-8')
handler = (ROOT / 'app/resource_admin.php').read_text(encoding='utf-8')
history = (ROOT / 'history.php').read_text(encoding='utf-8')
media = (ROOT / 'api/media.php').read_text(encoding='utf-8')
assert 'resources_catalog_page($kind, $search, $category, $page, 12)' in public
assert (ROOT / 'app/tools-tutorials.php').is_file()
assert "require_once __DIR__ . '/resources.php'" in (ROOT / 'app/tools-tutorials.php').read_text(encoding='utf-8')
assert 'COUNT(*)' in service and "LIMIT ' . $perPage . ' OFFSET ' . (($page - 1) * $perPage)" in service
assert "WHERE t.status=?" in service and "c.slug=?" in service
assert 'resources-v3-tool-grid' in public and 'resources-v3-tutorial-grid' in public
assert "['page'=>$page-1]" not in public  # pagination is now generated from the shared query state
assert '$videoUrlsText=htmlspecialchars' in admin and '><?=$videoUrlsText?></textarea>' in admin
assert '<details class="resource-editor"' in admin and admin.count('<details') == admin.count('</details>')
assert "DELETE FROM tutorial_media WHERE tutorial_id=? AND media_kind='video'" in handler
assert "resources_slug($slugInput!==''?$slugInput:$name)" in handler
assert 'preview=1' in admin
assert 'resource_bulk_action' in admin and "['publish','draft','delete']" in handler
assert 'resource_delete_category' in admin and 'resource_delete_category' in handler
assert 'resource_q' in admin and 'resource-admin-pagination' in admin
assert 'data-poll="1"' in history and 'api/magichour.php?id=' in (ROOT / 'assets/history.js').read_text(encoding='utf-8')
assert 'api/video-jobs.php?id=' in (ROOT / 'assets/history.js').read_text(encoding='utf-8')
assert 'Accept-Ranges: bytes' in media and 'Content-Range' in media
# Exercise the public prepared-query semantics and pagination against a local SQLite fixture.
con = sqlite3.connect(':memory:')
con.executescript('''
CREATE TABLE tools(id INTEGER PRIMARY KEY, category_id INTEGER, name TEXT, short_description TEXT, full_description TEXT, status TEXT, is_featured INTEGER, updated_at TEXT);
CREATE TABLE tool_categories(id INTEGER PRIMARY KEY, name TEXT, slug TEXT);
INSERT INTO tool_categories VALUES(1,'Video','video');
INSERT INTO tools VALUES(1,1,'OBS Studio','Streaming','Production app','published',1,'2026-11-12');
INSERT INTO tools VALUES(2,1,'Draft tool','Not public','Private','draft',0,'2026-11-12');
''')
query = "SELECT t.*,c.name category_name,c.slug category_slug FROM tools t LEFT JOIN tool_categories c ON c.id=t.category_id WHERE t.status='published' AND (t.name LIKE ? OR t.short_description LIKE ? OR t.full_description LIKE ? OR c.name LIKE ?)"
count_query = query.replace('SELECT t.*,c.name category_name,c.slug category_slug', 'SELECT COUNT(*)')
assert con.execute(count_query, ['%OBS%'] * 4).fetchone()[0] == 1
assert con.execute(query + ' ORDER BY t.is_featured DESC,t.name ASC LIMIT 12 OFFSET 0', ['%OBS%'] * 4).fetchone()[0] == 1
# Admin status changes and safe category deletion semantics.
con.execute("UPDATE tools SET status='draft' WHERE id=1")
assert con.execute('SELECT status FROM tools WHERE id=1').fetchone()[0] == 'draft'
assert con.execute('SELECT COUNT(*) FROM tools WHERE category_id=1').fetchone()[0] == 2
con.close()
print('PASS: Tools & Tutorials query service, filters/pagination, tutorial edit state, admin search, bulk publish/draft/delete, safe category deletion, History polling and range media checks.')
