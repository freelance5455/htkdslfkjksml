const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const ROOT = path.resolve(__dirname, '..');
global.window = global;

function load(rel) {
  vm.runInThisContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), { filename: rel });
}

const lunar = require(path.join(ROOT, 'engine/lunar.js'));
global.Solar = lunar.Solar;
global.EightChar = lunar.EightChar;
load('bazi-data.js');
load('engine/solar.js');
load('engine/jieqi.js');
load('engine/calendar.js');
load('data/sources/classical_sources_B_C.js');
load('data/rules/classical_rules_B_C.js');
load('data/rules/classical_rule_evaluator.js');
load('data/evidence/closure_signal_contract.js');
load('data/evidence/runtime_evidence_normalizer.js');
load('core/coreA.js');
load('core/coreB.js');

const LOCATION = {
  location: { name: 'Jakarta', admin1: 'DKI Jakarta', country: 'Indonesia' },
  coordinates: { latitude: -6.2088, longitude: 106.8456 },
  timeZone: { iana: 'Asia/Jakarta', utcOffset: 7 },
  referenceMeridian: { degrees: 105 },
  coordinateSource: { provider: 'runtime-fixture' },
  dst: { isDst: false }
};
global.PenggilasLocation = { resolve: async () => LOCATION };

async function runFixture(birthDate, birthTime) {
  global.masterResult = null;
  global.PENGGILAS_RAW_CHART = null;

  await global.PenggilasCoreA.calculate({
    birthDate,
    birthTime,
    birthPlace: { query: 'Jakarta' },
    gender: 'male'
  });
  global.PenggilasCoreB.calculate();

  const b13 = global.masterResult.B13_2;
  const candidates = Array.isArray(b13.methodCandidates.result)
    ? b13.methodCandidates.result
    : JSON.parse(b13.methodCandidates.result || '[]');
  const following = candidates.find(x => x.id === 'BC-YONG-ZHUANWANG-001');

  return {
    pillars: global.PENGGILAS_RAW_CHART.raw,
    following,
    signatureEvidence: b13.signatureEvidence || []
  };
}

(async () => {
  const profiles = Object.values(global.PENGGILAS_BC_RULES.specialStructureProfiles || {});
  assert.deepStrictEqual(
    profiles.map(x => x.hanzi).sort(),
    ['从势', '从强', '从旺'].sort(),
    'Current executable Following registry must contain only 从旺 / 从强 / 从势.'
  );
  assert.ok(!profiles.some(x => /从弱|从财|从官|从杀/.test(`${x.hanzi} ${x.english}`)), 'Unsupported Following subtype must not be executable.');

  const dominant = await runFixture('1903-12-02', '21:00');
  assert.strictEqual(dominant.following.evidence.mode, 'FOLLOW THE DOMINANT QI / 从旺');
  assert.strictEqual(dominant.following.evidence.companionDominant, true);
  assert.strictEqual(dominant.following.evidence.resourcePresent, true);
  assert.strictEqual(dominant.following.evidence.effectiveWealthOfficer, false);
  assert.ok(dominant.signatureEvidence.includes('FOLLOWING_CLOSURE_COMPLETE'));

  const strength = await runFixture('1850-10-14', '12:00');
  assert.strictEqual(strength.following.evidence.mode, 'FOLLOW-STRENGTH / 从强');
  assert.strictEqual(strength.following.evidence.companionPresent, true);
  assert.strictEqual(strength.following.evidence.resourcePresent, true);
  assert.strictEqual(strength.following.evidence.monthCommandSupportsDayMaster, true);
  assert.strictEqual(strength.following.evidence.wealthPresent, false);
  assert.strictEqual(strength.following.evidence.officerPresent, false);
  assert.ok(strength.signatureEvidence.includes('FOLLOWING_CLOSURE_COMPLETE'));

  const trend = await runFixture('1981-09-13', '12:17');
  assert.strictEqual(trend.following.evidence.mode, 'FOLLOW-THE-TREND / 从势');
  assert.strictEqual(trend.following.evidence.dmRootPresent, false);
  assert.strictEqual(trend.following.evidence.resourcePresent, false);
  assert.strictEqual(trend.following.evidence.companionPresent, false);
  assert.strictEqual(trend.following.evidence.followingSideCount, 3);
  assert.ok(trend.signatureEvidence.includes('FOLLOWING_CLOSURE_COMPLETE'));

  const unsupportedWealth = await runFixture('1903-11-19', '23:00');
  assert.notStrictEqual(unsupportedWealth.following.evidence.mode, 'FOLLOW-THE-TREND / 从势');
  assert.strictEqual(unsupportedWealth.following.evidence.resourcePresent, false);
  assert.strictEqual(unsupportedWealth.following.evidence.wealthPresent, true);
  assert.strictEqual(unsupportedWealth.following.evidence.officerPresent, false);
  assert.strictEqual(unsupportedWealth.following.evidence.followingSideCount < 3, true);
  assert.ok(!unsupportedWealth.signatureEvidence.includes('FOLLOWING_CLOSURE_COMPLETE'));

  const unsupportedOfficer = await runFixture('1945-09-13', '17:00');
  assert.notStrictEqual(unsupportedOfficer.following.evidence.mode, 'FOLLOW-THE-TREND / 从势');
  assert.strictEqual(unsupportedOfficer.following.evidence.resourcePresent, false);
  assert.strictEqual(unsupportedOfficer.following.evidence.officerPresent, true);
  assert.strictEqual(unsupportedOfficer.following.evidence.wealthPresent, false);
  assert.strictEqual(unsupportedOfficer.following.evidence.followingSideCount < 3, true);
  assert.ok(!unsupportedOfficer.signatureEvidence.includes('FOLLOWING_CLOSURE_COMPLETE'));

  console.log('PASS: Following contract registry = 从旺 / 从强 / 从势 only.');
  console.log('PASS: Follow-Dominant runtime closure.');
  console.log('PASS: Follow-Strength runtime closure.');
  console.log('PASS: unsupported Wealth-side case fails closed and is not promoted to 从势.');
})();
