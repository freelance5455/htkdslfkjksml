import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState, validateState } from '../src/store.js';
import { activateExpansions } from '../src/league.js';
import { getCareerSelectionCatalog } from '../src/career-selection.js';

test('catalogue complet : 60 clubs, 120 damistes et managers galactiques', () => {
  const s = createInitialState();
  assert.equal(s.world.clubCatalog.length, 60);
  assert.equal(s.world.clubManagers.length, 60);
  assert.equal(s.world.selectionManagers.length, 24);
  assert.equal(s.world.clubCatalog.reduce((n,c)=>n+c.damistes.length,0), 120);
  assert.equal(s.world.clubManagers[0].name, 'Xorvanys Khaël');
  assert.equal(s.world.selectionManagers[0].originGalaxy, 'Terra Unie');
  assert.equal(s.world.galaxies.reduce((n,g)=>n+g.damistes.length,0), 48);
  assert.equal(s.world.galaxies[0].damistes[0].name, 'Kaël Orion');
  assert.equal(s.world.galaxies[0].damistes[1].name, 'Amara Solène');
  assert.ok(s.world.clubManagers.every(m => m.originGalaxy && m.originGalaxyId));
  assert.equal(validateState(s), true);
});

test('les noms des 60 clubs sont visibles dans le catalogue sans déverrouiller les Ligues C/D', () => {
  const s = createInitialState();
  const catalog = getCareerSelectionCatalog(s);
  assert.equal(catalog.clubs[36].name, 'Dragons de Véga');
  assert.equal(catalog.clubs[48].name, 'Comètes de Terra');
  assert.equal(catalog.counts.availableClubs, 36);
  assert.equal(catalog.counts.lockedClubs, 24);
});

test('activation des divisions utilise les clubs et managers préenregistrés', () => {
  const s = createInitialState();
  s.season = 3;
  assert.deepEqual(activateExpansions(s), ['ligue-c']);
  const club = s.divisions[3].clubs[0];
  assert.equal(club.name, 'Dragons de Véga');
  assert.equal(club.managerProfile.name, 'Vexalyn Kha');
  assert.equal(club.damistes[0].name, 'Ilyan Végan');
  assert.equal(club.managerProfile.originGalaxy, club.damistes[0].origin);
});
