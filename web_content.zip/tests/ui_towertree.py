"""Vylepšování věží ve hře podle stromu (základna → druh → vylepšení → …):  python3 -I tests/ui_towertree.py"""
import glob, json
from playwright.sync_api import sync_playwright
exe = (glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome') or [None])[0]
errs, results = [], []
def check(n, c, x=''): results.append(bool(c)); print(('OK   ' if c else 'FAIL ') + n + (' ' + str(x) if x != '' else ''))
LEVEL = {'w': 12, 'h': 10, 'spawns': [{'side': 'L', 'pos': 8, 'len': 4}], 'exit': {'side': 'R', 'pos': 8, 'len': 4}, 'rocks': [], 'walls': [], 'towers': [], 'lives': 99, 'gold': 5000, 'waves': 12}
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=exe, args=['--no-sandbox'])
    pg = b.new_page(viewport={'width': 1280, 'height': 800})
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('file:///home/claude/BubbleDefence/index.html'); pg.wait_for_selector('.content:not(.hidden) .intro')
    pg.click('text=Nová lokální hra'); pg.wait_for_selector('.content:not(.hidden) .menu'); pg.wait_for_timeout(300)
    pg.click('.mi:has-text("Editor")'); pg.click('.lcard.add'); pg.wait_for_selector('.edv .ed-cv'); pg.wait_for_timeout(300)
    pg.evaluate("(L=>{const l=BD.store.profile.editor.levels[0]; Object.assign(l, L); BD.debugEditor.buildMasks(); BD.debugEditor.changed(true);})(%s)" % json.dumps(LEVEL))
    pg.click('.smap-head .btn.primary'); pg.wait_for_selector('.gv canvas'); pg.wait_for_timeout(500)
    pg.evaluate("(()=>{BD.debug.game.gold=5000; BD.debug.game.place('base',8,2); BD.debug.tap({cell:[8,2],pos:[8,2]});})()"); pg.wait_for_timeout(300)
    check('základna nabízí 4 druhy (strom) a nemá úrovně ani čtverečky', pg.locator('.btn.choice').count() == 4 and pg.locator('.selbox .pips').count() == 0 and 'Úroveň' not in pg.inner_text('.selbox'))
    pg.click('.btn.choice:has-text("Základní")'); pg.wait_for_timeout(300)
    check('po výběru druhu jsou nabídnutá jeho 3 vylepšení', pg.evaluate("BD.debug.game.towers[0].type") == 'normal' and pg.locator('.btn.choice').count() == 3)
    pg.click('.btn.choice:has-text("Silná")'); pg.wait_for_timeout(300)
    check('vylepšení je samostatná věž; na konci stromu už nic nenabízí', pg.evaluate("BD.debug.game.towers[0].type") == 'normal_b' and pg.locator('.btn.choice').count() == 0 and 'Další vylepšení tahle věž nemá' in pg.inner_text('.selbox'))
    check('sloučení se nenabízí (zatím vypnuté)', pg.locator('.selbox:has-text("Sloučit")').count() == 0 and 'Sloučení' not in pg.inner_text('.selbox'))
    # Studio přidá vlastní vylepšení pod Silnou → ve hře se hned nabídne
    pg.evaluate("(()=>{BD.studio.enable(true); BD.studio.create('towers','Mega'); BD.studio.moveTower(BD.studio.lastId, 'normal_b', 1);})()")
    pg.evaluate("(()=>{BD.debug.tap({cell:[0,0],pos:[0,0]}); BD.debug.tap({cell:[8,2],pos:[8,2]});})()"); pg.wait_for_timeout(300)
    check('vlastní vylepšení ze Studia se ve hře nabídne jako další stupeň', pg.locator('.btn.choice:has-text("Mega")').count() == 1)
    pg.click('.btn.choice:has-text("Mega")'); pg.wait_for_timeout(300)
    check('věž se přeměnila na vlastní věž ze Studia', pg.evaluate("BD.debug.game.towers[0].type") == 'mega')
    pg.screenshot(path='/home/claude/BubbleDefence/tests/shots/game_towertree.png')
    check('bez chyb', not errs, errs)
    b.close()
print('\nvýsledek: %d/%d' % (sum(results), len(results)), '| chyby:', errs or 'žádné')
