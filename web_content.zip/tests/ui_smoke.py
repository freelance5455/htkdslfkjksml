import glob, sys
from playwright.sync_api import sync_playwright
exe = (glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome') or [None])[0]
errs, net = [], []
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=exe, args=['--no-sandbox'])
    pg = b.new_page(viewport={'width': 1280, 'height': 800})
    pg.on('pageerror', lambda e: errs.append('PAGEERROR ' + str(e)))
    pg.on('console', lambda m: errs.append(m.type + ' ' + m.text) if m.type in ('error', 'warning') else None)
    pg.on('request', lambda r: net.append(r.url) if not r.url.startswith(('file:', 'data:')) else None)
    pg.goto('file:///home/claude/BubbleDefence/index.html'); pg.wait_for_timeout(1200)
    pg.screenshot(path='/home/claude/BubbleDefence/tests/shots_intro.png')
    print('title:', pg.inner_text('.intro-title'))
    b.close()
print('chyby:', errs or 'žádné', '| síť:', net or 'žádná')
