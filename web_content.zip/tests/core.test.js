import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState, validateState } from '../src/store.js';
import { roundRobin, generateSeasonCalendar, recordResult } from '../src/calendar.js';
import { activateExpansions, applyPromotionRelegation } from '../src/league.js';
import { validateCompetitionRegistry } from '../src/competitions.js';

test('carrière initiale : trois divisions actives et cinq niveaux connus',()=>{const s=createInitialState();assert.equal(s.divisions.length,5);assert.deepEqual(s.divisions.filter(d=>d.status==='active').map(d=>d.name),['Super League','Ligue A','Ligue B']);validateState(s);});
test('les sept compétitions historiques et la Coupe Fédéral sont conservées séparément',()=>{const s=createInitialState();assert.equal(s.competitions.length,8);assert.deepEqual(s.competitions.slice(0,7).map(c=>c.id),['coupe-galactique','coupe-des-clubs','champions-league','intergalactique-clubs','intergalactique','coupe-lunaire','dame-or']);assert.equal(s.competitions[7].name,'Coupe Fédéral');assert.equal(validateCompetitionRegistry(s),true);});
test('calendrier aller-retour de 12 clubs : 22 journées et 132 matches',()=>{const s=createInitialState();const fs=roundRobin(s.divisions[0].clubs,1,'super-league');assert.equal(fs.length,132);assert.equal(new Set(fs.map(f=>f.round)).size,22);});
test('un résultat ne peut être comptabilisé deux fois',()=>{const s=createInitialState();generateSeasonCalendar(s);const f=s.calendar.fixtures[0];assert.equal(recordResult(s,f.id,2,1),true);assert.equal(recordResult(s,f.id,2,1),false);const c=s.divisions[0].clubs.find(c=>c.id===f.home);assert.equal(c.played,1);assert.equal(c.points,3);});
test('Ligue C et D ne s’ouvrent qu’avec 12 clubs chacune et à leur saison',()=>{const s=createInitialState();s.season=3;const pool=Array.from({length:24},(_,i)=>({id:`pool-${i}`,name:`Club ${i}`,damistes:[{id:`${i}-1`},{id:`${i}-2`}]}));const opened=activateExpansions(s,pool);assert.deepEqual(opened,['ligue-c']);assert.equal(s.divisions[3].clubs.length,12);assert.equal(s.divisions[4].status,'announced');});
test('promotion-relégation échange deux clubs entre divisions adjacentes',()=>{const s=createInitialState();const before=s.divisions.slice(0,2).map(d=>d.clubs.map(c=>c.id));const moves=applyPromotionRelegation(s);assert.equal(moves.length,8);assert.equal(s.divisions[0].clubs.length,12);assert.equal(s.divisions[1].clubs.length,12);assert.notDeepEqual(s.divisions.slice(0,2).map(d=>d.clubs.map(c=>c.id)),before);});
