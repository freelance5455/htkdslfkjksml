process.env.TZ = 'Europe/London';
const test = require('node:test');
const assert = require('node:assert/strict');
const C = require('../www/js/core.js');

const at = (y, m, d, h = 0, mi = 0) => new Date(y, m - 1, d, h, mi).getTime();

test('fresh start has no balls and nothing pending', () => {
  const now = at(2026, 10, 24, 14);
  const s = C.create('scroll', now, now);
  assert.equal(s.startDay, '2026-10-24');
  assert.equal(C.totalBalls(s), 0);
  assert.deepEqual(C.pendingDays(s, now), []);
});

test('first check-in is 8am the morning after the start day', () => {
  const t0 = at(2026, 10, 24, 14);
  const s = C.create('fap', t0, t0);
  assert.deepEqual(C.pendingDays(s, at(2026, 10, 25, 7, 59)), []);
  assert.deepEqual(C.pendingDays(s, at(2026, 10, 25, 8, 0)), ['2026-10-24']);
});

test('typing an older date backfills the days that already passed', () => {
  const now = at(2026, 10, 24, 14);
  const s = C.create('booze', at(2026, 10, 14, 22), now);
  const c = C.counts(s);
  assert.equal(c.b, 10);              // 14th..23rd
  assert.equal(s.days['2026-10-24'], undefined);
  assert.equal(C.totalBalls(s), 3 + 3 + 4 + 4 + 5 + 5 + 6 + 6 + 7 + 7 + 10); // + day-7 bonus
  assert.equal(s.best, 10);
});

test('missed days pile up as pending, in order, across the clock change', () => {
  const t0 = at(2026, 10, 22, 10);
  const s = C.create('drugs', t0, t0);
  const later = at(2026, 10, 27, 9);   // BST ends on 25 Oct 2026
  assert.deepEqual(C.pendingDays(s, later), ['2026-10-22', '2026-10-23', '2026-10-24', '2026-10-25', '2026-10-26']);
});

test('blue grows with the streak and a lapse breaks the chain', () => {
  const t0 = at(2026, 10, 1, 10);
  const s = C.create('scroll', t0, t0);
  const r1 = C.confirmDay(s, '2026-10-01', at(2026, 10, 2, 8), 'me');
  const r2 = C.confirmDay(s, '2026-10-02', at(2026, 10, 3, 8), 'me');
  const r3 = C.confirmDay(s, '2026-10-03', at(2026, 10, 4, 8), 'me');
  assert.deepEqual([r1.blue, r2.blue, r3.blue], [3, 3, 4]);
  C.slip(s, 'y', at(2026, 10, 4, 12), 'me');
  const r5 = C.confirmDay(s, '2026-10-05', at(2026, 10, 6, 8), 'me');
  assert.equal(r5.streak, 1);
  assert.equal(r5.blue, 3);
});

test('yellow gives yellow balls once per day and resets the timer by default', () => {
  const t0 = at(2026, 10, 1, 10), t1 = at(2026, 10, 3, 15);
  const s = C.create('scroll', t0, t0);
  const r = C.slip(s, 'y', t1, 'me');
  assert.equal(r.yellow, 2);
  assert.equal(s.lastAt, t1);
  assert.equal(s.days['2026-10-03'], 'y');
  const again = C.slip(s, 'y', t1 + 1000, 'me');
  assert.equal(again.yellow, 0);
  assert.equal(s.balls.yellow, 2);
});

test('lapse can be set to keep the timer running', () => {
  const t0 = at(2026, 10, 1, 10), t1 = at(2026, 10, 3, 15);
  const s = C.create('scroll', t0, t0);
  s.settings.lapseResets = false;
  C.slip(s, 'y', t1, 'me');
  assert.equal(s.lastAt, t0);
});

test('purple removes exactly one ball, never below zero, and upgrades the day', () => {
  const now = at(2026, 10, 24, 14);
  const s = C.create('fap', at(2026, 10, 20, 22), now);
  const before = C.totalBalls(s);
  C.slip(s, 'y', now, 'me');
  const r = C.slip(s, 'p', now + 60000, 'me');
  assert.equal(r.removed, 1);
  assert.equal(C.totalBalls(s), before + 2 - 1);
  assert.equal(s.days['2026-10-24'], 'p');
  const empty = C.create('fap', now, now);
  const r0 = C.slip(empty, 'p', now, 'me');
  assert.equal(r0.removed, 0);
  assert.equal(C.totalBalls(empty), 0);
});

test('answering a past day with a slip stamps the timer at the end of that day', () => {
  const t0 = at(2026, 10, 20, 10);
  const s = C.create('booze', t0, t0);
  const now = at(2026, 10, 24, 8, 5);
  const day = C.pendingDays(s, now)[0];          // 20th
  C.slip(s, 'p', now, 'me', { day });
  assert.equal(s.days[day], 'p');
  assert.equal(s.lastAt, C.endOfDay(day));
});

test('guardian events apply once and are labelled', () => {
  const t0 = at(2026, 10, 1, 10), now = at(2026, 10, 3, 9);
  const s = C.create('scroll', t0, t0);
  const ev = { id: 'abc', kind: 'p', at: now - 5000, by: 'Sam' };
  const r = C.applyRemote(s, ev, now);
  assert.equal(r.by, 'Sam');
  assert.equal(s.lastAt, now - 5000);
  assert.equal(C.applyRemote(s, ev, now), null);
  assert.equal(s.log[s.log.length - 1].by, 'guardian:Sam');
});

test('mood: sad after a relapse, then follows the pit', () => {
  const now = at(2026, 10, 24, 14);
  const s = C.create('scroll', at(2026, 10, 1, 22), now);
  assert.equal(C.mood(s, now), 'joy');
  C.slip(s, 'p', now, 'me');
  assert.equal(C.mood(s, now + 3600e3), 'sad');
  assert.equal(C.mood(s, now + 7 * 3600e3), 'joy');
});

test('milestones and clock', () => {
  assert.deepEqual(C.clock((86400 * 2 + 3600 * 5 + 60 * 7 + 9) * 1000), { d: 2, h: 5, m: 7, s: 9, total: 86400 * 2 + 3600 * 5 + 429 });
  const m = C.nextMilestone(86400 * 5);
  assert.equal(m.days, 7);
  assert.equal(m.prev, 3);
  assert.ok(Math.abs(m.p - 0.5) < 1e-9);
});

test('day states for the calendar', () => {
  const t0 = at(2026, 10, 20, 10), now = at(2026, 10, 24, 14);
  const s = C.create('scroll', t0, now);
  assert.equal(C.dayState(s, '2026-10-19', now).st, 'none');
  assert.equal(C.dayState(s, '2026-10-20', now).start, true);
  assert.equal(C.dayState(s, '2026-10-21', now).st, 'b');
  assert.equal(C.dayState(s, '2026-10-24', now).st, 'today');
  assert.equal(C.dayState(s, '2026-10-26', now).st, 'future');
  assert.equal(C.dayState(s, '2026-10-23', at(2026, 10, 25, 7)).st, 'b');
});
