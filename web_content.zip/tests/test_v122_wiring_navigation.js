"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
const version = "20261007-v122";
const index = fs.readFileSync(path.join(root, "index.html"), "utf8");
const app = fs.readFileSync(path.join(root, "app.js"), "utf8");
const resultHtml = fs.readFileSync(path.join(root, "template/result-template.html"), "utf8");
const resultJs = fs.readFileSync(path.join(root, "template/result-template.js"), "utf8");
const reportHtml = fs.readFileSync(path.join(root, "ui/report/report.html"), "utf8");
const reportJs = fs.readFileSync(path.join(root, "ui/report/report.js"), "utf8");

// Root engine/core assets must be cache-busted together with the UI so stale wiring cannot survive a versioned input shell.
for (const src of ["app.js", "bazi-data.js", "engine/lunar.js", "engine/location.js", "core/coreA.js", "core/coreB.js", "core/determination.js", "core/coreC.js"]) {
  assert.match(index, new RegExp(src.replace(/[.*+?^${}()|[\\]\\]/g, "\\\\$&") + "\\?v=" + version));
}
assert.match(index, /ui\/chart\/chart\.html\?v=20261007-v122/);
assert.match(index, /ui\/report\/report\.html\?v=20261007-v122/);

// Chart navigation waits for a successful calculation; failure returns to input instead of presenting an empty chart.
assert.match(app, /receiveInputData\(data\.payload\)[\s\S]*?\.then\(function \(\) \{[\s\S]*?goToScreen\(data\.screenId\)/);
assert.match(app, /notifyCalculationError\(err\)/);
assert.match(app, /goToScreen\("screen-input"\)/);
assert.match(app, /data\.type === "BAZI_RETURN_TO_REPORT"/);
assert.match(app, /resetFrameScroll\(reportFrame\)/);

// Full-report Back button must route through the parent shell, not navigate inside the iframe.
assert.match(resultHtml, /id="back-to-report-button"/);
assert.doesNotMatch(resultHtml, /window\.location\.href=.*ui\/report\/report\.html/);
assert.match(resultJs, /BAZI_RETURN_TO_REPORT/);
assert.match(reportHtml, /report\.css\?v=20261007-v122/);
assert.match(reportJs, /ai-result-template\.json\?v=20261007-v122/);

console.log("V1.22 wiring/navigation tests passed.");
