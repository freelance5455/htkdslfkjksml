// Stone Pro v14.3 checks: worker without trade, day workers (work/holiday/overtime/deduction/money taken),
// contractor contract + payments, warehouse in/out, insurance (building/workers) with alerts and monthly renewal.
// Usage: CHROMIUM_PATH=/path/to/chrome node test-stage3.mjs <path to ysp-pwa folder>
import { chromium } from 'playwright';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(process.argv[2]);
const types = { '.html': 'text/html', '.js': 'text/javascript', '.json': 'application/json', '.png': 'image/png' };
const server = http.createServer((req, res) => {
  const p = path.join(root, decodeURIComponent(req.url.split('?')[0]).replace(/^\/$/, '/index.html'));
  if (!p.startsWith(root) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'content-type': types[path.extname(p)] || 'application/octet-stream' });
  fs.createReadStream(p).pipe(res);
});
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const url = `http://127.0.0.1:${server.address().port}/`;

let fails = 0;
const ok = (n, c, extra = '') => { console.log((c ? 'PASS ' : 'FAIL ') + n + (c ? '' : ' -> ' + extra)); if (!c) fails++; };
const PIN = '482913';
const b = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
const errs = [];
const newPage = async () => {
  const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, acceptDownloads: true });
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push(e.message)); p.on('dialog', (d) => d.accept());
  await p.goto(url); await p.waitForTimeout(1700);
  return p;
};
const store = (p, k) => p.evaluate((key) => JSON.parse(localStorage.getItem(key) || 'null'), k);
const isOpen = (p, sel) => p.evaluate((s) => !!document.querySelector(s) && document.querySelector(s).classList.contains('open'), sel);
const visible = (p, sel) => p.evaluate((s) => { const e = document.querySelector(s); return !!e && (e.offsetParent !== null || getComputedStyle(e).position === 'fixed'); }, sel);
const text = (p, sel) => p.evaluate((s) => (document.querySelector(s) || {}).textContent || '', sel);
const digits = (t) => t.replace(/[۰-۹]/g, (d) => d.charCodeAt(0) - 1776).replace(/[٬,\s]/g, '');
const sv = (p, id, v) => p.fill('#' + id, v);
async function onboard(p, role, trade, name) {
  await p.evaluate(() => { const b = document.querySelector('#ysp-terms .ysp-gate-body'); b.scrollTop = b.scrollHeight; b.dispatchEvent(new Event('scroll')); });
  await p.check('#ysp-terms-check'); await p.click('#ysp-terms-go');
  await p.click(`.ysp-role-card[data-r="${role}"]`);
  return { hasTrade: await p.evaluate(() => !!document.getElementById('ysp-trade')), async finish() {
    if (trade) await p.selectOption('#ysp-trade', { label: trade });
    if (name) await p.fill('#ysp-name', name);
    await p.click('#ysp-role-save'); await p.waitForTimeout(300);
  } };
}
async function pickDate(p, iso) {
  const j = await p.evaluate((i) => YSPDate.toJalali(i), iso);
  await p.selectOption('#ysp-jy', String(j.y)); await p.selectOption('#ysp-jm', String(j.m)); await p.selectOption('#ysp-jd', String(j.d));
  await p.click('#ysp-date-ok'); await p.waitForTimeout(150);
}
async function createPin(p) { await p.fill('#ysp-pin-new', PIN); await p.fill('#ysp-pin-new2', PIN); await p.click('#ysp-pin-save'); await p.waitForTimeout(700); }
async function confirmDelete(p, pin = PIN) { await p.fill('#ysp-delete-password', pin); await p.evaluate(() => confirmDeleteModal()); await p.waitForTimeout(500); }

/* ===== A. worker role has no trade ===== */
let p = await newPage();
const step = await onboard(p, 'worker');
ok('worker: no trade question on the details step', step.hasTrade === false);
await step.finish();
let prof = (await store(p, 'ysp_profile'))[0];
ok('worker profile saved without a trade', prof.userType === 'worker' && prof.trade === '');
ok('worker subtitle shows only "کارگر"', (await text(p, '#home-sub')).trim() === 'کارگر');
await p.evaluate(() => { openSettings(); }); await p.click('text=تغییر نقش یا صنف');
await p.click('.ysp-role-card[data-r="contractor"]');
ok('contractor still has the trade question', await p.evaluate(() => !!document.getElementById('ysp-trade')));
await p.click('#ysp-role-back');
await p.click('.ysp-role-card[data-r="owner"]');
ok('owner has no trade question', await p.evaluate(() => !document.getElementById('ysp-trade')));
await p.close();

/* ===== B. owner: day workers ===== */
p = await newPage();
let st = await onboard(p, 'owner'); await st.finish();
ok('owner sees the day-workers tile with owner wording', (await visible(p, '.tile[onclick*="openEntityList(\'worker\')"]')) && (await text(p, '.tile[onclick*="openEntityList(\'worker\')"]')).includes('کارگران روزمزد'));
await p.evaluate(() => openEntityForm('worker', null));
await p.fill('#ef-name', 'حسن'); await p.evaluate(() => saveEntity());
const w = (await store(p, 'ysp_workers')).find((x) => x.name === 'حسن');
await p.evaluate((id) => openEntityForm('worker', id), w.id);
await sv(p, 'wr-rate', '1000000'); await sv(p, 'wr-hrate', '1500000'); await sv(p, 'wr-orate', '150000');
await p.click('text=ذخیره نرخ‌ها'); await p.waitForTimeout(200);
let wk = (await store(p, 'ysp_workers')).find((x) => x.id === w.id);
ok('three rates saved (day, holiday, overtime hour)', wk.wage === 1000000 && wk.holidayWage === 1500000 && wk.overtimeWage === 150000);
ok('owner sees overtime + deduction cards, no "receipt" button', (await visible(p, '#wo-hours')) && (await visible(p, '#wd-amount')) && await p.evaluate(() => !document.querySelector("[onclick=\"recordWorkerMoney('receipt')\"]")));
await p.evaluate(() => { recordWorkerWork('work'); recordWorkerWork('work'); recordWorkerWork('holiday'); });
await sv(p, 'wo-hours', '3'); await p.click('text=ثبت اضافه‌کاری'); await p.waitForTimeout(150);
await sv(p, 'wd-amount', '200000'); await sv(p, 'wd-reason', 'غیبت نیم‌روز'); await p.click('text=ثبت کسری'); await p.waitForTimeout(150);
await sv(p, 'worker-money-amount', '1000000'); await p.evaluate(() => recordWorkerMoney('payment'));
// earned = 2*1,000,000 + 1,500,000 + 3*150,000 = 3,950,000 ; - 200,000 - 1,000,000 = 2,750,000
let led = await store(p, 'ysp_worker_ledger');
ok('overtime saved with hours, rate and amount (3 h x 150k)', led.some((r) => r.type === 'overtime' && r.hours === 3 && r.rate === 150000 && r.amount === 450000));
ok('deduction saved with its reason', led.some((r) => r.type === 'deduction' && r.amount === 200000 && r.details === 'غیبت نیم‌روز'));
ok('every entry has automatic date + exact time', led.length === 6 && led.every((r) => r.date && r.at.includes('T')));
const wtext = digits(await text(p, '#worker-ledger-box'));
ok('worker balance = 2,750,000 and says "I owe the worker"', wtext.includes('2750000') && wtext.includes('بهکارگربدهکارم'), wtext.slice(0, 400));
ok('money wording: "پول گرفته کارگر"', (await text(p, '#worker-ledger-box')).includes('پول گرفته کارگر') && !(await text(p, '#worker-ledger-box')).includes('پول داده به کارگر'));
// rate snapshot: raising the day rate must not change old days
await sv(p, 'wr-rate', '2000000'); await p.click('text=ذخیره نرخ‌ها'); await p.waitForTimeout(200);
ok('changing the day rate keeps the earlier days at the old rate', digits(await text(p, '#worker-ledger-box')).includes('2750000'));
await p.evaluate(() => recordWorkerWork('work'));
ok('a new day uses the new rate (+2,000,000)', digits(await text(p, '#worker-ledger-box')).includes('4750000'));
await p.waitForTimeout(600); await p.screenshot({ path: '/home/claude/sp3_worker_owner.png' });
await p.evaluate(() => openEntityList('worker'));
ok('workers list shows each worker\'s balance', digits(await text(p, '#ef-list, #entity-list, #entities') || await p.evaluate(() => document.body.innerText)).includes('4750000'));
await p.evaluate(() => go('reports'));
// bad input
await p.evaluate((id) => openEntityForm('worker', id), w.id);
const before = (await store(p, 'ysp_worker_ledger')).length;
await p.click('text=ثبت اضافه‌کاری'); await p.click('text=ثبت کسری');
ok('empty overtime/deduction are refused', (await store(p, 'ysp_worker_ledger')).length === before);
// deleting needs the PIN
await p.evaluate((id) => deleteWorkerEntry(id), led[0].id);
ok('deleting a worker entry asks for a password first', await isOpen(p, '#ysp-sec-modal'));
await createPin(p); await confirmDelete(p);
ok('entry removed after the PIN', (await store(p, 'ysp_worker_ledger')).length === before - 1);

/* ===== C. contractor contract + payments ===== */
await p.evaluate(() => { newProject(); });
await p.fill('#p-name', 'ساختمان مسکونی'); await p.fill('#p-client', 'پیمانکار اسکلت'); await p.fill('#p-price', '50000000');
ok('owner project form hides the old single "paid" field', !(await visible(p, '#p-expense')));
await p.evaluate(() => saveProject());
const proj = (await store(p, 'ysp_projects'))[0];
await p.evaluate(() => YSPSite.open('accounts'));
await p.evaluate(() => YSPSite.entry('contract'));
await sv(p, 'sf-newname', 'پیمانکار اسکلت'); await sv(p, 'sf-title', 'قرارداد اسکلت'); await sv(p, 'sf-amount', '50000000');
await p.selectOption('#sf-project', proj.id);
ok('contract form creates a contractor party', await p.evaluate(() => [...document.querySelectorAll('#sf-pkind option')].map((o) => o.value).join()) === 'contractor');
await p.evaluate(() => YSPSite.saveEntry()); await p.waitForTimeout(100);
let parties = await store(p, 'ysp_parties');
ok('contractor party + contract entry saved', parties.length === 1 && parties[0].kind === 'contractor' && (await store(p, 'ysp_entries'))[0].kind === 'contract' && (await store(p, 'ysp_entries'))[0].amount === 50000000);
await p.evaluate(() => YSPSite.pay({ kinds: ['contractor'] }));
ok('"paid to contractor" form lists only contractors', await p.evaluate(() => [...document.querySelectorAll('#sf-party option')].filter((o) => o.value).length === 1) && (await text(p, '#sh-title')).includes('پیمانکار'));
await p.selectOption('#sf-party', parties[0].id); await p.selectOption('#sf-project', proj.id); await sv(p, 'sf-amount', '12000000');
await p.evaluate(() => YSPSite.savePay()); await p.waitForTimeout(100);
const cp = (await store(p, 'ysp_pays'))[0];
ok('payment to the contractor saved with automatic date and time', cp.amount === 12000000 && cp.date && cp.at.includes('T') && cp.projectId === proj.id);
await p.evaluate(() => YSPSite.pay({ kinds: ['contractor'], partyId: null }));
await p.selectOption('#sf-party', parties[0].id); await sv(p, 'sf-amount', '8000000'); await p.evaluate(() => YSPSite.savePay()); await p.waitForTimeout(100);
await p.evaluate((id) => YSPSite.party(id), parties[0].id);
const ct = digits(await text(p, '#site-main'));
ok('contractor account: contract 50M, paid 20M, balance 30M', ct.includes('50000000') && ct.includes('20000000') && ct.includes('30000000'), ct.slice(0, 300));
await p.evaluate(() => go('accounting'));
const oa = digits(await text(p, '#acc-stats') + await text(p, '#acc-list'));
ok('owner payments screen counts the workshop payments (paid 20M, remaining 30M)', oa.includes('20000000') && oa.includes('30000000'), oa.slice(0, 300));
await p.evaluate(() => go('reports'));
const rf = await text(p, '#rep-financial-details');
ok('financial report lists the contractor payments', rf.includes('پیمانکار اسکلت') && rf.includes('پرداخت'));
ok('owner report has day-worker totals', (await text(p, '#rep-stats')).includes('مانده بدهی کارگاه'));

/* ===== D. warehouse ===== */
await p.evaluate(() => YSPSite.open('stock'));
ok('warehouse starts empty', (await text(p, '#site-main')).includes('انبار خالی است'));
await p.evaluate(() => YSPStock.out());
ok('taking out of an empty store only shows a hint', !(await isOpen(p, '#site-sheet')));
await p.evaluate(() => YSPStock.openIn());
await sv(p, 'sk-item', 'سیمان'); await sv(p, 'sk-qty', '۵۰'); await sv(p, 'sk-unit', 'کیسه'); await sv(p, 'sk-from', 'بنگاه الف');
await p.evaluate(() => YSPStock.saveIn()); await p.waitForTimeout(100);
let stock = await store(p, 'ysp_stock');
ok('entry saved with direction, automatic date and exact time', stock.length === 1 && stock[0].dir === 'in' && stock[0].qty === 50 && stock[0].unit === 'کیسه' && stock[0].at.includes('T') && stock[0].date);
await p.evaluate(() => YSPStock.out());
const key = await p.evaluate(() => document.getElementById('sk-pick').value);
await sv(p, 'sk-qty', '60'); await p.evaluate(() => YSPStock.saveOut());
ok('taking out more than the store holds is refused', (await text(p, '#sf-err')).includes('موجودی کافی نیست') && (await store(p, 'ysp_stock')).length === 1);
await sv(p, 'sk-qty', '20'); await sv(p, 'sk-to', 'استاد رضا'); await p.evaluate(() => YSPStock.saveOut()); await p.waitForTimeout(100);
stock = await store(p, 'ysp_stock');
ok('stock out saved with receiver', stock.length === 2 && stock[1].dir === 'out' && stock[1].receiver === 'استاد رضا' && stock[1].at.includes('T'));
ok('balance = 30 bags', await p.evaluate((k) => YSPStock.balanceOf(k) === 30, key));
ok('warehouse list shows the balance', digits(await text(p, '#site-main')).includes('30'));
await p.evaluate((k) => YSPStock.item(k), key);
ok('item history shows both movements with date/time', (await text(p, '#sh-body')).includes('ورود') && (await text(p, '#sh-body')).includes('خروج') && /[۰-۹]{2}:[۰-۹]{2}|\d\d:\d\d/.test(await text(p, '#sh-body')));
await p.evaluate(() => YSPSite.closeSheet());
// purchase -> store
await p.evaluate(() => YSPSite.entry('material'));
ok('purchase form offers "enter into store" (checked by default)', await p.evaluate(() => document.getElementById('sf-tostock').checked));
await sv(p, 'sf-newname', 'سنگ فروشی'); await sv(p, 'sf-title', 'سنگ نما'); await sv(p, 'sf-qty', '40'); await sv(p, 'sf-unit', 'متر مربع'); await sv(p, 'sf-rate', '900000');
await p.evaluate(() => YSPSite.saveEntry()); await p.waitForTimeout(100);
stock = await store(p, 'ysp_stock');
const fromBuy = stock.find((m) => m.item === 'سنگ نما');
ok('the purchase added itself to the store (40 m2)', fromBuy && fromBuy.dir === 'in' && fromBuy.qty === 40 && fromBuy.fromEntryId);
const entryId = fromBuy.fromEntryId;
await p.evaluate((id) => YSPSite.entry('', { id }), entryId);
await sv(p, 'sf-qty', '45'); await p.evaluate(() => YSPSite.saveEntry()); await p.waitForTimeout(100);
ok('editing the purchase updates the store entry', (await store(p, 'ysp_stock')).find((m) => m.fromEntryId === entryId).qty === 45);
await p.evaluate((id) => YSPSite.delEntry(id), entryId); await confirmDelete(p);
ok('deleting the purchase removes its store entry', !(await store(p, 'ysp_stock')).some((m) => m.fromEntryId === entryId));
// removing an "in" that later stock depends on is refused
const inRec = (await store(p, 'ysp_stock')).find((m) => m.dir === 'in' && m.item === 'سیمان');
await p.evaluate(([id, k]) => YSPStock.del(id, k), [inRec.id, key]);
ok('an entry that later stock-outs depend on cannot be deleted', (await store(p, 'ysp_stock')).some((m) => m.id === inRec.id) && !(await isOpen(p, '#ysp-delete-modal')));
const outRec = (await store(p, 'ysp_stock')).find((m) => m.dir === 'out');
await p.evaluate(([id, k]) => YSPStock.del(id, k), [outRec.id, key]); await confirmDelete(p);
ok('a stock-out can be deleted with the password', !(await store(p, 'ysp_stock')).some((m) => m.id === outRec.id));
await p.evaluate(() => { window.__shared = null; navigator.share = async (d) => { window.__shared = d.text; }; YSPStock.share(); });
ok('store report can be shared', (await p.evaluate(() => window.__shared) || '').includes('سیمان'));
await p.screenshot({ path: '/home/claude/sp3_stock.png' });

/* ===== E. insurance ===== */
const t0 = await p.evaluate(() => YSP.isoDate());
await p.evaluate(() => YSPSite.open('insurance'));
ok('insurance tab starts empty', (await text(p, '#site-main')).includes('هنوز بیمه‌ای ثبت نشده'));
await p.evaluate(() => YSPIns.open());
await p.click('#ins-type'); // building by default
await sv(p, 'ins-company', 'بیمه ایران'); await sv(p, 'ins-no', 'B-77'); await p.selectOption('#sf-project', proj.id); await sv(p, 'ins-premium', '5000000');
await p.evaluate(() => YSPIns.save());
ok('a policy needs at least one date', (await text(p, '#sf-err')).includes('تاریخ'));
await p.click('button:has-text("انتخاب تاریخ") >> nth=0');
await pickDate(p, await p.evaluate((t) => YSPDate.addDays(t, 3), t0));
await p.evaluate(() => YSPIns.save()); await p.waitForTimeout(100);
// workers policy, monthly, due today + ends in 10 days
await p.evaluate(() => YSPIns.open());
await p.selectOption('#ins-type', 'workers');
await sv(p, 'ins-company', 'تأمین اجتماعی'); await sv(p, 'ins-subject', 'همه کارگران'); await sv(p, 'ins-premium', '3000000'); await p.selectOption('#ins-repeat', 'monthly');
await p.click('button:has-text("انتخاب تاریخ") >> nth=0'); await pickDate(p, t0);
await p.click('#site-sheet button:has-text("انتخاب تاریخ") >> nth=2'); await pickDate(p, await p.evaluate((t) => YSPDate.addDays(t, 10), t0));
await p.evaluate(() => YSPIns.save()); await p.waitForTimeout(100);
// far-away policy: no alert
await p.evaluate(() => YSPIns.open());
await sv(p, 'ins-company', 'بیمه دانا'); await p.click('button:has-text("انتخاب تاریخ") >> nth=0'); await pickDate(p, await p.evaluate((t) => YSPDate.addDays(t, 60), t0));
await p.evaluate(() => YSPIns.save()); await p.waitForTimeout(100);
let ins = await store(p, 'ysp_insurance');
ok('three policies saved with type, premium, due date', ins.length === 3 && ins.some((x) => x.type === 'building' && x.policyNo === 'B-77' && x.projectId === proj.id) && ins.some((x) => x.type === 'workers' && x.repeat === 'monthly'));
const al = await p.evaluate(() => YSPSite.allAlerts().map((x) => x.text));
ok('alerts: building due in 3 days, workers due today and ending in 10 days; the 60-day one is silent', al.length === 3 && al.some((x) => x.includes('بیمه ایران')) && al.filter((x) => x.includes('تأمین اجتماعی')).length === 2 && !al.some((x) => x.includes('دانا')), JSON.stringify(al));
await p.evaluate(() => go('home'));
ok('home banner lists the insurance alerts', (await text(p, '#ysp-banners')).includes('پرداخت حق بیمه') && (await text(p, '#ysp-banners')).includes('پایان بیمه‌نامه'));
await p.screenshot({ path: '/home/claude/sp3_home_alert.png' });
await p.evaluate(() => YSPSite.open('insurance'));
await p.waitForTimeout(600); await p.screenshot({ path: '/home/claude/sp3_insurance.png' });
// pay the monthly premium: due date moves one Jalali month ahead
const wp = ins.find((x) => x.type === 'workers');
const expected = await p.evaluate((d) => YSPDate.addMonths(d, 1), wp.nextDue);
await p.evaluate((id) => YSPIns.paid(id), wp.id);
const wp2 = (await store(p, 'ysp_insurance')).find((x) => x.id === wp.id);
ok('paying a monthly premium records time and moves the due date one Jalali month', wp2.payments.length === 1 && wp2.payments[0].at.includes('T') && wp2.payments[0].amount === 3000000 && wp2.nextDue === expected && wp2.nextDue > wp.nextDue);
ok('the paid payment alert is gone, the end-date alert remains', await p.evaluate(() => { const a = YSPSite.allAlerts().map((x) => x.text); return a.filter((x) => x.includes('تأمین اجتماعی')).length === 1 && a.some((x) => x.includes('پایان')); }));
const bp = ins.find((x) => x.type === 'building');
const [dl] = await Promise.all([p.waitForEvent('download'), p.click(`button[onclick*="YSPIns.calendar('${bp.id}')"]`)]);
const ics = fs.readFileSync(await dl.path(), 'utf8');
ok('insurance calendar file has the due date and a day-before alarm', ics.includes('DTSTART;VALUE=DATE:' + bp.nextDue.replace(/-/g, '')) && ics.includes('TRIGGER:-P1D') && ics.includes('SUMMARY:'));
// a one-time policy clears its due date once paid
await p.evaluate((id) => YSPIns.paid(id), bp.id);
ok('a one-time premium clears the due date after payment', (await store(p, 'ysp_insurance')).find((x) => x.id === bp.id).nextDue === '');
// edit + event log + delete
await p.evaluate((id) => YSPIns.open(id), bp.id);
await sv(p, 'ins-premium', '6000000'); await p.evaluate(() => YSPIns.save()); await p.waitForTimeout(100);
const evs = await store(p, 'ysp_events');
ok('insurance create/update events are in the log', evs.some((e) => e.entity === 'insurance' && e.kind === 'create') && evs.some((e) => e.entity === 'insurance' && e.kind === 'update' && e.fields.includes('premium')));
await p.evaluate((id) => YSPIns.del(id), bp.id);
ok('deleting a policy asks for the password', await isOpen(p, '#ysp-delete-modal'));
await confirmDelete(p);
ok('policy deleted after the PIN', !(await store(p, 'ysp_insurance')).some((x) => x.id === bp.id));
// addMonths clamping
const am = await p.evaluate(() => { const g = YSPDate.toGregorian(1405, 6, 31); const n = YSPDate.addMonths(g, 1); const j = YSPDate.toJalali(n); const y = YSPDate.addMonths(YSPDate.toGregorian(1405, 12, 29), 1); return { j, y: YSPDate.toJalali(y) }; });
ok('addMonths clamps 31 Shahrivar -> 30 Mehr and rolls over the year', am.j.y === 1405 && am.j.m === 7 && am.j.d === 30 && am.y.y === 1406 && am.y.m === 1 && am.y.d === 29, JSON.stringify(am));

/* ===== F. gating of insurance + backup ===== */
await p.evaluate(() => { YSPPlan.config.enforced = true; YSPSite.open('insurance'); });
ok('paid: insurance tab is locked', (await text(p, '#site-main')).includes('امکان اشتراکی'));
ok('paid: insurance alerts hidden while locked', await p.evaluate(() => !YSPSite.allAlerts().some((x) => x.text.includes('حق بیمه'))));
await p.evaluate(() => { YSPPlan.config.enforced = false; });
await p.evaluate(() => { go('home'); openSettings(); });
const [dlb] = await Promise.all([p.waitForEvent('download'), p.click('text=دانلود فایل پشتیبان')]);
const bk = JSON.parse(fs.readFileSync(await dlb.path(), 'utf8'));
ok('backup includes stock and insurance', bk.data.ysp_stock.length >= 1 && bk.data.ysp_insurance.length >= 2);
ok('backup still verifies', !!(await p.evaluate((t) => YSPData._validate(t), JSON.stringify(bk))).backup);

console.log('page errors:', errs);
console.log('FAILS', fails + errs.length);
await b.close(); server.close();
