from pathlib import Path
from PIL import Image
import hashlib
root=Path(__file__).resolve().parents[1]
# Transparent logo assets and square favicon outputs.
logo=Image.open(root/'assets/branding/anonymoux-studio-logo.png').convert('RGBA')
icon=Image.open(root/'assets/branding/anonymoux-icon-512.png').convert('RGBA')
assert logo.getchannel('A').getextrema()[0] == 0 and logo.getchannel('A').getextrema()[1] == 255
assert icon.size == (512,512) and icon.getchannel('A').getextrema()[0] == 0
assert Image.open(root/'assets/branding/favicon-32.png').size == (32,32)
# Supplied dashboard background was copied byte-for-byte into the project.
assert (root/'assets/branding/dashboard-geometric-background.jpg').exists()
# Both themes get a contrast veil over the supplied image; admin responsive rules exist.
dash=(root/'assets/dashboard.css').read_text()
assert 'dashboard-geometric-background.jpg' in dash and 'data-theme="light"' in dash
assert '.admin-dashboard-shell .admin-layout' in dash and '@media(max-width:640px)' in dash
# Both workspaces use the same server-side voice catalogue and preview metadata.
voice=(root/'app/voice.php').read_text(); vjs=(root/'assets/voice-studio.js').read_text()
ajs=(root/'assets/agent-studio.js').read_text(); agent=(root/'agent-studio.php').read_text()
assert "'preview_url' => $previewUrl" in voice and "'provider' => 'Fish Audio'" in voice
assert 'api/voice/voices.php' in vjs and 'data-preview' in vjs
assert 'api/voice/voices.php' in ajs and 'data-agent-preview' in ajs and 'agentVoiceLoadMore' in ajs
assert 'provider' in (root/'api/agent/create.php').read_text() and 'fish_audio' in (root/'api/agent/update.php').read_text()
# Existing Resources admin/public data paths remain connected to DB-backed service layer.
assert 'resources_seed()' in (root/'tools-tutorials.php').read_text() and 'FROM tools t LEFT JOIN tool_categories' in (root/'app/resources.php').read_text()
# Voice Cloning Studio and AI Agent Studio are separate workspaces; private clones are selectable by the agent builder.
voice_page=(root/'voice-studio.php').read_text(); shared_agent=(root/'app/agent_workspace.php').read_text()
assert 'voiceCloneForm' in voice_page and 'voiceOwnedList' in voice_page
assert 'app/agent_workspace.php' in (root/'agent-studio.php').read_text()
assert 'agentGrid' in shared_agent and 'agentDialog' in shared_agent
assert 'api/voice/owned.php' in (root/'assets/agent-studio.js').read_text()
assert 'resource_bulk_action' in (root/'app/resource_admin.php').read_text()
assert 'resource_admin_handle_post' in (root/'admin.php').read_text()
print('PASS: transparent branding assets, square favicon, dashboard background/theme contrast, responsive admin rules, shared Fish Audio voice browsing/preview wiring, and DB-backed Tools & Tutorials routes.')
