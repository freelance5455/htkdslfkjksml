/**
 * JARVIS Model Abstraction & Intelligent Router Automated Tests
 * Validates provider abstraction, timeouts, retries, health state transitions,
 * deterministic routing, fallback cascades, safe structured output, and secret redaction.
 */

import { strict as assert } from 'node:assert';
import { jarvisCore } from '../server/core/jarvisCore.ts';
import { initializeDatabase } from '../server/db/database.ts';
import { ModelRouter } from '../server/models/modelRouter.ts';
import { GoogleGeminiProvider, redactSecrets } from '../server/models/providers/googleGeminiProvider.ts';
import { LocalHeuristicProvider } from '../server/models/providers/localHeuristicProvider.ts';
import {
  extractJsonString,
  executeStructuredWithRepair,
  parseJsonSafely,
} from '../server/models/structuredOutput.ts';
import {
  IModelProvider,
  ModelDescriptor,
  ModelError,
  ModelHealth,
  ModelRequest,
  ModelResponse,
} from '../server/models/types.ts';

export async function runModelTests(): Promise<{ passed: number; failed: number }> {
  console.log('\n--- Running Model Abstraction & Intelligent Router Tests ---');
  let passed = 0;
  let failed = 0;

  async function test(name: string, fn: () => Promise<void>) {
    try {
      await fn();
      console.log(`  [PASS] ${name}`);
      passed++;
    } catch (err: any) {
      console.error(`  [FAIL] ${name}:`, err.message);
      failed++;
    }
  }

  // Ensure DB initialized
  await initializeDatabase();

  // 1. Provider Abstraction
  await test('provider abstraction conforms to IModelProvider interface', async () => {
    const gemini = new GoogleGeminiProvider();
    const heuristic = new LocalHeuristicProvider();

    assert.equal(gemini.id, 'google-gemini');
    assert.equal(heuristic.id, 'local-heuristic');

    const geminiModels = gemini.getModels();
    assert.ok(geminiModels.length >= 2, 'Gemini provider must declare at least 2 models');
    assert.ok(geminiModels.some((m) => m.id === 'gemini-3.8-flash'));

    const heuristicModels = heuristic.getModels();
    assert.equal(heuristicModels.length, 1);
    assert.equal(heuristicModels[0].id, 'jarvis-heuristic-engine');
  });

  // 2. Successful Model Request
  await test('successful deterministic model execution via local provider', async () => {
    const heuristic = new LocalHeuristicProvider();
    const response = await heuristic.generateText('jarvis-heuristic-engine', {
      prompt: 'Synthesize mission status report',
    });

    assert.equal(response.modelId, 'jarvis-heuristic-engine');
    assert.equal(response.provider, 'local-heuristic');
    assert.ok(response.text.length > 10);
    assert.ok(response.usage.promptTokens > 0);
    assert.ok(response.latencyMs >= 0);
  });

  // 3. Timeout Handling
  await test('timeout handling triggers ModelError with TIMEOUT code', async () => {
    class HangingMockProvider implements IModelProvider {
      readonly id = 'custom-mock' as const;
      readonly name = 'Hanging Mock';
      isConfigured() { return true; }
      getModels(): ModelDescriptor[] { return []; }
      getModel() { return undefined; }
      async checkHealth(): Promise<ModelHealth> {
        return { status: 'healthy', lastChecked: '', consecutiveFailures: 0, isAvailable: true };
      }
      async generateText(_modelId: string, req: ModelRequest): Promise<ModelResponse> {
        const timeout = req.timeoutMs || 50;
        await new Promise((_, reject) =>
          setTimeout(() => reject(new ModelError({
            code: 'TIMEOUT',
            message: `Mock timed out after ${timeout}ms`,
            provider: 'custom-mock',
            modelId: 'mock-hang',
            retryable: true,
          })), timeout)
        );
        throw new Error('Unreachable');
      }
    }

    const hangingProvider = new HangingMockProvider();
    await assert.rejects(
      async () => {
        await hangingProvider.generateText('mock-hang', {
          prompt: 'test hang',
          timeoutMs: 30,
        });
      },
      (err: any) => {
        assert.equal(err.code, 'TIMEOUT');
        return true;
      }
    );
  });

  // 4. Retry on Transient Error
  await test('retries transient 503 error before succeeding', async () => {
    let callCount = 0;
    class TransientFailingProvider implements IModelProvider {
      readonly id = 'custom-mock' as const;
      readonly name = 'Transient Mock';
      isConfigured() { return true; }
      getModels(): ModelDescriptor[] { return []; }
      getModel() { return undefined; }
      async checkHealth(): Promise<ModelHealth> {
        return { status: 'healthy', lastChecked: '', consecutiveFailures: 0, isAvailable: true };
      }
      async generateText(_modelId: string, _req: ModelRequest): Promise<ModelResponse> {
        callCount++;
        if (callCount === 1) {
          throw new ModelError({
            code: 'UNAVAILABLE',
            message: '503 Service Unavailable',
            provider: 'custom-mock',
            modelId: 'transient-model',
            status: 503,
            retryable: true,
          });
        }
        return {
          modelId: 'transient-model',
          provider: 'custom-mock',
          text: 'Recovered after transient error',
          usage: { promptTokens: 10, completionTokens: 10, totalTokens: 20, estimatedCostUsd: 0 },
          latencyMs: 40,
        };
      }
    }

    const provider = new TransientFailingProvider();
    // Simulate retry loop
    let result: ModelResponse | null = null;
    let attempts = 0;
    while (attempts < 3) {
      attempts++;
      try {
        result = await provider.generateText('transient-model', { prompt: 'retry check' });
        break;
      } catch (err: any) {
        if (!err.retryable || attempts >= 3) throw err;
      }
    }

    assert.ok(result);
    assert.equal(callCount, 2, 'Must have attempted twice and succeeded on attempt 2');
    assert.equal(result.text, 'Recovered after transient error');
  });

  // 5. Authentication Error Classification
  await test('unconfigured key or 401 returns non-retryable AUTH_ERROR', async () => {
    const gemini = new GoogleGeminiProvider();
    // In test environment without key, isConfigured returns false
    if (!gemini.isConfigured()) {
      await assert.rejects(
        async () => {
          await gemini.generateText('gemini-3.8-flash', { prompt: 'auth test' });
        },
        (err: any) => {
          assert.equal(err.code, 'AUTH_ERROR');
          assert.equal(err.retryable, false, 'AUTH_ERROR must NOT be retryable');
          return true;
        }
      );
    }
  });

  // 6. Rate Limit Handling
  await test('rate limit error classifies as RATE_LIMIT and marks model rate_limited', async () => {
    const error = new ModelError({
      code: 'RATE_LIMIT',
      message: 'Resource exhausted (quota exceeded)',
      provider: 'google-gemini',
      modelId: 'gemini-3.8-flash',
      status: 429,
      retryable: true,
    });

    assert.equal(error.code, 'RATE_LIMIT');
    assert.equal(error.retryable, true);
  });

  // 7. Fallback Chain Execution
  await test('router gracefully executes fallback chain when primary fails', async () => {
    const testRouter = new ModelRouter();

    // Register a broken primary provider
    class FailingProvider implements IModelProvider {
      readonly id = 'custom-mock' as const;
      readonly name = 'Failing Primary';
      isConfigured() { return true; }
      getModels(): ModelDescriptor[] {
        return [
          {
            id: 'mock-failing-primary',
            name: 'Mock Failing Primary',
            provider: 'custom-mock',
            category: 'general',
            capabilities: ['text'],
            contextWindow: 10000,
            inputCostPer1kTokens: 0,
            outputCostPer1kTokens: 0,
            health: { status: 'healthy', lastChecked: '', consecutiveFailures: 0, isAvailable: true },
            telemetry: { requestCount: 0, successCount: 0, failureCount: 0, timeoutCount: 0, fallbackCount: 0, averageLatencyMs: 0, totalTokens: 0, estimatedTotalCostUsd: 0 },
          },
        ];
      }
      getModel(id: string) { return this.getModels().find((m) => m.id === id); }
      async checkHealth(): Promise<ModelHealth> {
        return { status: 'healthy', lastChecked: '', consecutiveFailures: 0, isAvailable: true };
      }
      async generateText(_modelId: string, _req: ModelRequest): Promise<ModelResponse> {
        throw new ModelError({
          code: 'UNAVAILABLE',
          message: 'Primary server failure',
          provider: 'custom-mock',
          modelId: 'mock-failing-primary',
          retryable: false,
        });
      }
    }

    testRouter.registerProvider(new FailingProvider());

    const response = await testRouter.routeAndGenerate({
      prompt: 'Execute with primary failure',
      requiredCategory: 'general',
    });

    assert.ok(response);
    assert.equal(response.modelId, 'jarvis-heuristic-engine');
    assert.ok(response.routingDecision);
    assert.equal(response.routingDecision?.status, 'ROUTE_FALLBACK');
  });

  // 8. Unavailable Model Handling
  await test('handles unavailable model when all providers fail', async () => {
    const emptyRouter = new ModelRouter();
    emptyRouter.removeProvider('google-gemini');
    emptyRouter.removeProvider('local-heuristic');

    await assert.rejects(
      async () => {
        await emptyRouter.routeAndGenerate({ prompt: 'test empty' });
      },
      (err: any) => {
        assert.equal(err.code, 'UNAVAILABLE');
        return true;
      }
    );
  });

  // 9. Routing Decision Logging
  await test('routing decisions are audited with timestamp and attempt records', async () => {
    const router = new ModelRouter();
    await router.routeAndGenerate({
      prompt: 'Testing decision audit trail',
      requiredCategory: 'general',
    });

    const decisions = router.getRoutingDecisions(5);
    assert.ok(decisions.length > 0, 'Decision must be logged in history');
    const latest = decisions[0];
    assert.ok(latest.id.startsWith('mdec_'));
    assert.ok(latest.timestamp);
    assert.ok(latest.attemptedModels.length > 0);
    assert.ok(latest.reasoning);
  });

  // 10. Capability Filtering
  await test('capability filtering favors reasoning/coding models when requested', async () => {
    const router = new ModelRouter();
    const models = router.getModels();
    const reasoningModel = models.find((m) => m.capabilities.includes('reasoning'));

    assert.ok(reasoningModel, 'Must have at least one reasoning-capable model registered');
    assert.equal(reasoningModel?.category, 'reasoning');
  });

  // 11. Structured Output Validation
  await test('valid structured JSON passes schema validator', async () => {
    interface TestPlan {
      mission: string;
      confidence: number;
    }

    const validator = (data: unknown) => {
      const obj = data as any;
      if (typeof obj?.mission === 'string' && typeof obj?.confidence === 'number') {
        return { valid: true, data: obj as TestPlan };
      }
      return { valid: false, error: 'Missing mission or confidence' };
    };

    const validJson = JSON.stringify({ mission: 'Analyze network telemetry', confidence: 0.99 });
    const parsed = parseJsonSafely(validJson);
    assert.equal(parsed.success, true);
    const validated = validator(parsed.data);
    assert.equal(validated.valid, true);
    assert.equal(validated.data?.mission, 'Analyze network telemetry');
  });

  // 12. Malformed JSON Handling and Single Bounded Repair
  await test('recovers from fenced JSON and bounded single repair attempt', async () => {
    const fencedMarkdown = '```json\n{\n  "status": "ok",\n  "count": 42\n}\n```';
    const extracted = extractJsonString(fencedMarkdown);
    const parsed = JSON.parse(extracted);
    assert.equal(parsed.status, 'ok');
    assert.equal(parsed.count, 42);

    // Test executeStructuredWithRepair with mock provider that repairs on second call
    let attempts = 0;
    class RepairMockProvider implements IModelProvider {
      readonly id = 'custom-mock' as const;
      readonly name = 'Repair Mock';
      isConfigured() { return true; }
      getModels(): ModelDescriptor[] { return []; }
      getModel() { return undefined; }
      async checkHealth(): Promise<ModelHealth> {
        return { status: 'healthy', lastChecked: '', consecutiveFailures: 0, isAvailable: true };
      }
      async generateText(_modelId: string, _req: ModelRequest): Promise<ModelResponse> {
        attempts++;
        if (attempts === 1) {
          // Return malformed JSON
          return {
            modelId: 'mock-repair',
            provider: 'custom-mock',
            text: '{ "mission": "incomplete',
            usage: { promptTokens: 5, completionTokens: 5, totalTokens: 10, estimatedCostUsd: 0 },
            latencyMs: 15,
          };
        }
        // Return repaired valid JSON
        return {
          modelId: 'mock-repair',
          provider: 'custom-mock',
          text: '{"mission": "complete", "valid": true}',
          usage: { promptTokens: 10, completionTokens: 10, totalTokens: 20, estimatedCostUsd: 0 },
          latencyMs: 15,
        };
      }
    }

    const repairProvider = new RepairMockProvider();
    const result = await executeStructuredWithRepair(
      repairProvider,
      'mock-repair',
      { prompt: 'generate structured data' },
      (d: any) => {
        if (d?.mission === 'complete') return { valid: true, data: d };
        return { valid: false, error: 'Expected mission complete' };
      }
    );

    assert.equal(result.repaired, true);
    assert.equal((result.data as any).mission, 'complete');
    assert.equal(attempts, 2, 'Must boundedly stop after 1 repair attempt');
  });

  // 13. Telemetry Tracking
  await test('telemetry tracks request counts, tokens, and average latency', async () => {
    const heuristic = new LocalHeuristicProvider();
    const beforeCount = heuristic.getModel('jarvis-heuristic-engine')?.telemetry.requestCount || 0;

    await heuristic.generateText('jarvis-heuristic-engine', { prompt: 'Count test' });

    const after = heuristic.getModel('jarvis-heuristic-engine')?.telemetry;
    assert.equal(after?.requestCount, beforeCount + 1);
    assert.ok((after?.totalTokens || 0) > 0);
  });

  // 14. Health State Transitions
  await test('health state reflects availability and consecutive failures', async () => {
    const heuristic = new LocalHeuristicProvider();
    const health = await heuristic.checkHealth('jarvis-heuristic-engine');
    assert.equal(health.status, 'healthy');
    assert.equal(health.isAvailable, true);
    assert.equal(health.consecutiveFailures, 0);
  });

  // 15. Secret Redaction
  await test('secret redaction masks Gemini API keys and Bearer tokens', async () => {
    const secretKey = 'AIzaSy' + 'B123456789012345678901234567890123';
    const bearer = 'Bearer ya29.a0AfH6SMA1234567890abcdefgh';
    const rawError = `Request failed using key ${secretKey} and auth header ${bearer}`;

    const redacted = redactSecrets(rawError);
    assert.ok(!redacted.includes(secretKey), 'Raw API key must not be present in output');
    assert.ok(redacted.includes('AIzaSy***[REDACTED]'), 'Must replace API key with redacted marker');
    assert.ok(!redacted.includes(bearer), 'Bearer token must not be present in output');
    assert.ok(redacted.includes('Bearer ***[REDACTED]'), 'Must replace Bearer token with redacted marker');
  });

  // 16. Core Loop Model Integration
  await test('core loop integrates model router for task briefing synthesis', async () => {
    const result = await jarvisCore.executeTask(
      'System status diagnostic check',
      'usr_jarvis_prime',
      'conv_default'
    );

    assert.ok(result.task);
    assert.equal(result.task.status, 'COMPLETED');
    assert.ok(result.task.resultSummary);
    assert.ok(result.assistantMessage.content.length > 0);
    // Verify that task logs contain model selection and synthesis records
    const hasSelectModel = result.task.logs.some((l) => l.includes('[SELECT MODEL]'));
    const hasRespond = result.task.logs.some((l) => l.includes('[RESPOND]'));
    assert.ok(hasSelectModel, 'Task logs must record model selection stage');
    assert.ok(hasRespond, 'Task logs must record model respond synthesis');
  });

  return { passed, failed };
}
