'use strict';
const fs = require('fs');
const assert = require('assert');
const html = fs.readFileSync(require('path').join(__dirname, '..', 'www', 'index.html'), 'utf8');
const engine = fs.readFileSync(require('path').join(__dirname, '..', 'www', 'engine.js'), 'utf8');
const checks = [
  ['current Gemini model default', /DEFAULT_GEMINI_MODEL\s*=\s*'gemini-3\.8-flash'/.test(html)],
  ['old model IDs migrate to current default', /gemini-2\\\.5-flash/.test(html) && /gemini-3\\\.7-flash/.test(html)],
  ['AI Madad uses Interactions API', (html.match(/v1beta\/interactions/g) || []).length >= 2],
  ['AI requests opt out of stored interactions', (html.match(/store:false/g) || []).length >= 2],
  ['photo uses direct camera plugin/native bridge fallback', /nativePromise\('Camera','getPhoto'/.test(html) && /Plugins&&C\.Plugins\.Camera/.test(html)],
  ['photo provides camera capture + gallery input', /accept="image\/\*" capture="environment"/.test(html) && /id="phChoose"/.test(html)],
  ['Retake button opens camera again', /closest\('#phLiveBtn,#phRetake'\)/.test(html)],
  ['Labour Extra has name search and full account details', /id="lxq"/.test(html) && /Complete Account Details/.test(html) && /Running balance/.test(html)],
  ['Previous gross sale separated from carried final balance', /function previousGrossSale\(/.test(engine) && /totalSales:n\(previousGrossSale\(d,date\)\)/.test(engine)],
  ['Purchase-payment-only dates included in carry forward history', /'purchasePayments'/.test(engine.match(/function allDates\(d\)[^\n]*/)?.[0] || '')]
];
for (const [label, ok] of checks) {
  if (!ok) {
    console.error('FAIL', label);
    process.exitCode = 1;
  } else console.log('PASS', label);
}
console.log(`${checks.filter(x => x[1]).length}/${checks.length} source integration checks passed`);
