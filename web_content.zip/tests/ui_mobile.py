"""Průchod na telefonu (dotyk, 390×800):  python3 -I tests/ui_mobile.py"""
import glob
from playwright.sync_api import sync_playwright
exe = (glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome') or [None])[0]
SH = '/home/claude/BubbleDefence/tests/shots/'
errs, results = [], []
def check(n, c, x=''): results.append(bool(c)); print(('OK   ' if c else 'FAIL ') + n + (' ' + str(x) if x != '' else ''))
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=exe, args=['--no-sandbox'])
    ctx = b.new_context(viewport={'width': 390, 'height': 800}, device_scale_factor=2, is_mobile=True, has_touch=True)
    pg = ctx.new_page()
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type in ('error', 'warning') else None)
    def ready(sel, t=8000): pg.wait_for_selector('.content:not(.hidden) ' + sel, timeout=t)
    pg.goto('file:///home/claude/BubbleDefence/index.html'); ready('.intro'); pg.wait_for_timeout(300)
    pg.screenshot(path=SH + 'm01_intro.png')
    pg.tap('text=Nová lokální hra'); ready('.menu'); pg.wait_for_timeout(300)
    pg.screenshot(path=SH + 'm02_menu.png')
    sc = pg.evaluate("({w:document.documentElement.scrollWidth, iw:innerWidth})")
    check('menu bez vodorovného scrollu', sc['w'] <= sc['iw'], sc)
    # dotyk: první klepnutí na „Nová hra“ jen ukáže náhled (Story je už vybraný, sub = new) -> klepnout na Free > Nová hra
    pg.tap('.mi:has-text("Free mód")'); pg.wait_for_timeout(150)
    pg.tap('.ms:has-text("Nová hra")'); pg.wait_for_timeout(200)
    check('Free nová hra: po klepnutí ukáže mapy a nespustí hru', pg.locator('.mright .lcard').count() == 3 and pg.locator('.gv').count() == 0)
    pg.screenshot(path=SH + 'm03_free_maps.png')
    pg.tap('.mi:has-text("Nastavení")'); pg.wait_for_timeout(250); pg.screenshot(path=SH + 'm04_settings.png')
    # story: první klepnutí = náhled, druhé = start
    pg.tap('.mi:has-text("Story mód")'); pg.wait_for_timeout(150)
    pg.tap('.ms:has-text("Nová hra")'); ready('.smap', 8000); pg.wait_for_timeout(300)
    check('story mapa se otevřela', pg.locator('.node').count() == 2)
    pg.screenshot(path=SH + 'm05_map.png')
    pg.tap('.node.open .dot'); pg.wait_for_timeout(250)
    check('dotyk: první klepnutí na uzel ukáže popup', pg.locator('.tip').count() == 1 and pg.locator('.gv').count() == 0)
    pg.screenshot(path=SH + 'm06_map_tip.png')
    pg.tap('.node.open .dot'); ready('.gv', 8000); pg.wait_for_timeout(300)
    check('dotyk: druhé klepnutí spustí level', pg.locator('.gv').count() == 1)
    sc = pg.evaluate("({sh:document.documentElement.scrollHeight, ih:innerHeight, sw:document.documentElement.scrollWidth, iw:innerWidth})")
    check('hra se vejde na jednu obrazovku', sc['sh'] <= sc['ih'] and sc['sw'] <= sc['iw'], sc)
    pg.screenshot(path=SH + 'm07_game_tutorial.png')
    # stavba dotykem
    pg.tap('.tw >> nth=0')
    cv = pg.locator('.stage canvas:not(.mini)').bounding_box(); g = pg.evaluate('({w:BD.debug.game.w,h:BD.debug.game.h})')
    cell = cv['width'] / (g['w'] + 2)
    for (x, y) in [(3, 1), (4, 1), (3, 5)]:        # souřadnice ve věžích; okraj = 1 buňka
        pg.touchscreen.tap(cv['x'] + (1 + x * 2 + 1) * cell, cv['y'] + (1 + y * 2 + 1) * cell); pg.wait_for_timeout(80)
    check('věže postavené dotykem', pg.evaluate('BD.debug.game.towers.length') == 3, pg.evaluate('BD.debug.game.towers.length'))
    pg.evaluate("(()=>{const g=BD.debug.game; g.gold=5000; g.startWave();})()"); pg.wait_for_timeout(1200)
    pg.screenshot(path=SH + 'm08_game_wave.png')
    pg.tap('.gv .bar .btn:has(.lbl)'); pg.wait_for_selector('.pause'); pg.screenshot(path=SH + 'm09_pause.png')
    b.close()
print('\nvýsledek: %d/%d' % (sum(results), len(results)), '| chyby:', errs or 'žádné')
