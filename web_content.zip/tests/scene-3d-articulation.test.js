import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const scene=readFileSync(new URL('../src/scene-3d.js',import.meta.url),'utf8');
test('les jambes humanoïdes sont construites en segments articulés avec genoux',()=>{
 assert.ok(scene.includes('const hipY=.20+lift,kneeY=.125+lift,footY=.055+lift'));
 assert.ok(scene.includes('addSphere(out,knee[0],knee[1],knee[2],.047'));
});
test('les bras possèdent des coudes et deux segments par membre',()=>{
 assert.ok(scene.includes('leftElbow'));
 assert.ok(scene.includes('rightElbow'));
 assert.ok(scene.includes('addLimb(out,leftShoulder,leftElbow'));
 assert.ok(scene.includes('addLimb(out,leftElbow,left'));
 assert.ok(scene.includes('addLimb(out,rightElbow,right'));
});
test('la marche du damiste accompagne la trajectoire du pion',()=>{
 assert.ok(scene.includes('gait:Math.sin(t*Math.PI*2)'));
 assert.ok(scene.includes('sway:Math.cos(t*Math.PI*2)'));
 assert.ok(scene.includes('phase=gait*side'));
});
test('les gestes spécifiques conservent leurs points de flexion',()=>{
 for(const action of ['thinking','capture','celebrate','defeat','presentation'])assert.ok(scene.includes(`action==='${action}'`));
});
