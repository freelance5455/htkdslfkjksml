from pathlib import Path

root = Path(__file__).resolve().parents[1]
header = (root / "app/platform_header.php").read_text()
community = (root / "community.php").read_text()
app = (root / "assets/app.js").read_text()
token = (root / "api/client-token.php").read_text()
index = (root / "index.php").read_text()
pricing = (root / "BILLING-PRICING-PLAN-2.5.4.md").read_text()

assert "['Explore','community.php'" not in header
assert "'community.php'=>['community','Explore'" not in header
assert "Location: dashboard.php" in community
assert "realtimeClient.on('sessionEnded'" in app
assert "finishSdkSession" in app
assert "app_rate_limit('decart_client_token', 30, 600)" in token
assert "US$0.02 per active second" in index
assert "billed_seconds" in index
assert "realtime_settle_measured_seconds" in (root / 'api/sessions.php').read_text()
assert "'http-signaling'" in (root / 'api/config.php').read_text()
assert "realtime_credit_usage" in (root / 'app/credits.php').read_text()
assert "not currently" in pricing.lower() or "not billable" in pricing.lower()
print("Realtime, Explore and pricing source checks passed")
