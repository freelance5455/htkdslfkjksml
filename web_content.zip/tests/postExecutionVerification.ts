/**
 * JARVIS 5.1 Post-Execution Verification Script
 * Validates all 24 post-execution verification requirements:
 * - Intent classification and routing
 * - Short Film Studio artifact generation (Screenplay, shots, bibles, subtitles, ZIP)
 * - Video provider truthful CONFIG_REQUIRED boundary (zero fake MP4)
 * - Image vs SVG diagram generation classification
 * - Autonomous Self-Upgrade 12-stage cycle & SHA-256 state checkpointing
 * - Autonomous Rollback verification
 * - Coding Agent & Code Debugger
 * - Website, PDF, and Document generation regression prevention
 */

import { strict as assert } from 'node:assert';
import { IntentClassifier } from '../server/planner/intentClassifier.ts';
import { plannerEngine } from '../server/planner/plannerEngine.ts';
import { toolRegistry } from '../server/tools/toolRegistry.ts';
import { shortFilmStudio } from '../server/media/shortFilmStudio.ts';
import { mediaEngine } from '../server/media/mediaEngine.ts';
import { selfUpgradeEngine } from '../server/system/selfUpgradeEngine.ts';
import { codingEngine } from '../server/code/codingAgent.ts';
import { websiteGenerator } from '../server/code/websiteGenerator.ts';
import { documentGenerator } from '../server/documents/documentGenerator.ts';

export async function runPostExecutionVerification() {
  console.log('\n=============================================================');
  console.log('JARVIS 5.1 — POST-EXECUTION VERIFICATION SUITE');
  console.log('=============================================================');

  const results: Record<string, 'PASS' | 'FAIL' | 'VERIFIED' | 'CONFIG_REQUIRED'> = {};

  // 1. Intent Classification for 10-Minute AI Short Film
  console.log('\n[CHECK 1] Intent Classification: "Create a 10-minute AI short film..."');
  const filmPrompt = 'Create a 10-minute AI short film about an astronomer decoding a cosmic signal';
  const filmIntent = IntentClassifier.analyze(filmPrompt);
  assert.strictEqual(filmIntent.intentType, 'AI_SHORT_FILM_GENERATION', 'Must classify as AI_SHORT_FILM_GENERATION');
  assert.strictEqual(filmIntent.requiresToolExecution, true, 'Must require tool execution');
  console.log('  -> Intent:', filmIntent.intentType);
  console.log('  -> Requires Tool Execution:', filmIntent.requiresToolExecution);
  console.log('  -> Target Language:', filmIntent.targetLanguage);

  // 2. Planner Engine Integration
  console.log('\n[CHECK 2] Planner Engine: Decomposes into film_studio_generator step');
  const plan = await plannerEngine.createPlan(filmPrompt);
  assert.ok(plan.steps.length >= 1, 'Plan must contain steps');
  const filmStep = plan.steps.find((s) => s.toolName === 'film_studio_generator');
  assert.ok(filmStep, 'Planner must assign film_studio_generator tool');
  assert.strictEqual(filmStep.toolInput.targetDuration, '10m', 'Must parse 10-minute duration');
  console.log('  -> Plan ID:', plan.id);
  console.log('  -> Step Assigned Tool:', filmStep.toolName);
  console.log('  -> Target Duration:', filmStep.toolInput.targetDuration);

  // 3. Tool Registry Integration & Execution
  console.log('\n[CHECK 3] Tool Registry: film_studio_generator tool execution');
  const tool = toolRegistry.getTool('film_studio_generator');
  assert.ok(tool, 'film_studio_generator must be registered in tool registry');
  const filmExecution = await tool.execute({
    prompt: filmPrompt,
    title: 'The Silent Frequency',
    targetDuration: '10m',
    aspectRatio: '16:9',
  });
  assert.ok(filmExecution.id, 'Must produce film package with ID');
  assert.ok(filmExecution.scenes.length >= 3, 'Must produce at least 3 scenes');
  assert.ok(filmExecution.scenes[0].shots.length >= 2, 'Scenes must have shots');
  assert.ok(filmExecution.characterBible.length >= 1, 'Must register characters');
  assert.ok(filmExecution.locationBible.length >= 1, 'Must register world locations');
  assert.ok(filmExecution.subtitlesSrt.includes('-->'), 'Must generate valid SRT subtitles');
  assert.ok(filmExecution.subtitlesVtt.startsWith('WEBVTT'), 'Must generate valid WebVTT subtitles');
  assert.ok(filmExecution.artifactFiles.length >= 8, 'Must bundle production artifacts');
  console.log('  -> Film Project ID:', filmExecution.id);
  console.log('  -> Scenes Count:', filmExecution.scenes.length);
  console.log('  -> Total Shots:', filmExecution.qualityReport.shotCount);
  console.log('  -> Subtitles Synchronized:', filmExecution.qualityReport.subtitlesValid);

  // 4. Production ZIP Deliverable
  console.log('\n[CHECK 4] Deliverable ZIP Archive Verification');
  const zipBuffer = shortFilmStudio.getFilmZip(filmExecution.id);
  assert.ok(zipBuffer && zipBuffer.length > 500, 'ZIP buffer must be created');
  assert.strictEqual(zipBuffer[0], 0x50);
  assert.strictEqual(zipBuffer[1], 0x4b);
  console.log('  -> ZIP Archive Size:', zipBuffer.length, 'bytes (PK zip signature verified)');

  // 5. Truthful Video Provider Boundary (Zero Fake MP4)
  console.log('\n[CHECK 5] Truthful Video Engine Boundary (Zero Fake MP4)');
  const videoJob = await mediaEngine.orchestrateVideo({
    prompt: 'A cinematic hyper-realistic nebula expansion',
    providerPreference: 'luma',
  });
  assert.strictEqual(videoJob.status, 'CONFIG_REQUIRED', 'Must return CONFIG_REQUIRED when LUMA_API_KEY missing');
  assert.strictEqual(videoJob.requiredSecret, 'LUMA_API_KEY');
  assert.strictEqual(videoJob.artifactMetadata, undefined, 'Must not produce fake MP4');
  console.log('  -> Video Provider Status:', videoJob.status);
  console.log('  -> Required Secret:', videoJob.requiredSecret);
  console.log('  -> Artifact Generated:', videoJob.artifactMetadata || 'NONE (truthful zero-mock boundary)');

  // 6. Image Generation vs SVG Diagram Separation
  console.log('\n[CHECK 6] Image Generation vs SVG Diagram Classification');
  const diagramResult = await mediaEngine.generateImage({
    prompt: 'System architecture diagram for microservices orchestration',
    style: 'diagram',
  });
  assert.strictEqual(diagramResult.category, 'IMAGE_DIAGRAM_GENERATION');
  assert.strictEqual(diagramResult.executionStatus, 'SVG_DIAGRAM');
  assert.strictEqual(diagramResult.metadata.isNeuralGenerative, false);
  console.log('  -> Diagram Category:', diagramResult.category, `(Status: ${diagramResult.executionStatus})`);

  const neuralResult = await mediaEngine.generateImage({
    prompt: 'Portrait of a majestic snow leopard in high mountain terrain',
    style: 'photorealistic',
  });
  assert.strictEqual(neuralResult.category, 'AI_IMAGE_GENERATION');
  assert.strictEqual(neuralResult.metadata.isNeuralGenerative, true);
  console.log('  -> Neural Image Category:', neuralResult.category, `(Provider: ${neuralResult.provider})`);

  // 7. Autonomous Self-Upgrade 12-Stage Pipeline
  console.log('\n[CHECK 7] Autonomous Self-Upgrade 12-Stage Pipeline & SHA-256 Checkpointing');
  const upgradeRecord = await selfUpgradeEngine.executeControlledUpgrade({
    targetVersion: '5.1.1',
    improvementDescription: 'Post-execution verification upgrade verification cycle',
  });
  assert.strictEqual(upgradeRecord.status, 'SUCCESS');
  assert.strictEqual(upgradeRecord.currentVersion, '5.1.1');
  assert.strictEqual(upgradeRecord.stages.length, 12, 'Must record all 12 upgrade stages');
  assert.strictEqual(upgradeRecord.checkpointHash.length, 64, 'SHA-256 hash must be 64 hex characters');
  console.log('  -> Upgrade Status:', upgradeRecord.status);
  console.log('  -> Current Version:', upgradeRecord.currentVersion);
  console.log('  -> Checkpoint SHA-256:', upgradeRecord.checkpointHash);
  console.log('  -> Stages Executed:', upgradeRecord.stages.map((s) => s.stage).join(' -> '));

  // 8. Controlled Rollback Verification
  console.log('\n[CHECK 8] Controlled Rollback Verification');
  const currentVer = selfUpgradeEngine.getCurrentVersion();
  const rollbackRecord = await selfUpgradeEngine.executeControlledUpgrade({
    targetVersion: '5.1.2-faulty',
    improvementDescription: 'Canary fault injection test',
    simulateFailureStage: 'VERIFY',
  });
  assert.strictEqual(rollbackRecord.status, 'ROLLED_BACK');
  assert.strictEqual(rollbackRecord.rollback?.triggered, true);
  assert.strictEqual(rollbackRecord.rollback?.restoredVersion, currentVer);
  assert.strictEqual(selfUpgradeEngine.getCurrentVersion(), currentVer);
  console.log('  -> Rollback Triggered:', rollbackRecord.rollback?.triggered);
  console.log('  -> Restored Version:', rollbackRecord.rollback?.restoredVersion);
  console.log('  -> Current Active Version:', selfUpgradeEngine.getCurrentVersion());

  // 9. Coding Agent & Autonomous Code Debugger
  console.log('\n[CHECK 9] Autonomous Code Debugger & Unified Diff');
  const debugResult = await codingEngine.debugCode({
    code: 'function add(a: number, b: number) { const res = eval("a + b"); return res; }',
    errorDescription: 'Unsafe eval anti-pattern',
    filePath: 'src/math.ts',
    language: 'typescript',
  });
  assert.ok(debugResult.fixedCode, 'Must return fixed code');
  assert.ok(debugResult.diff.unifiedDiff.includes('--- a/src/math.ts'), 'Must produce unified diff');
  assert.strictEqual(debugResult.fixedCode.includes('eval('), false, 'Fixed code must not contain eval');
  console.log('  -> Root Cause:', debugResult.rootCause);
  console.log('  -> Syntax Check:', debugResult.validation.syntaxOk ? 'PASS' : 'FAIL');
  console.log('  -> Diff Lines Count:', debugResult.diff.unifiedDiff.split('\n').length);

  // 10. Website Generator Regression Test
  console.log('\n[CHECK 10] Website Generator Regression Check (Pizza Website)');
  const website = await websiteGenerator.generateWebsite({
    title: 'Bella Vista Wood Fired Pizzeria',
    theme: 'ecommerce',
    description: 'Artisan Neapolitan pizza crafted with slow-fermented dough',
  });
  assert.ok(website.id, 'Website must have an ID');
  assert.ok(website.files.length >= 10, 'Must generate full project file tree');
  assert.ok(website.previewUrl.includes('/api/websites/'), 'Must have preview URL');
  console.log('  -> Website ID:', website.id);
  console.log('  -> Files Generated:', website.files.length);
  console.log('  -> Preview URL:', website.previewUrl);

  // 11. PDF Document Generator Regression Test
  console.log('\n[CHECK 11] PDF Document Generator Regression Check (PDF 1.4 Spec)');
  const pdfDoc = await documentGenerator.generateDocument({
    title: 'JARVIS 5.1 Verification Charter',
    format: 'pdf',
    content: 'Autonomous AI Operating System Verification and Compliance Report.\nStatus: VERIFIED COMPLETE.',
  });
  assert.strictEqual(pdfDoc.format, 'pdf');
  assert.ok(pdfDoc.downloadUrl.includes('/api/documents/'), 'Must have download URL');
  assert.ok(pdfDoc.sizeBytes > 500, 'PDF bytes must be non-zero');
  console.log('  -> PDF ID:', pdfDoc.id);
  console.log('  -> Byte Size:', pdfDoc.sizeBytes);
  console.log('  -> Download URL:', pdfDoc.downloadUrl);

  // 12. Markdown Document Generator Regression Test
  console.log('\n[CHECK 12] Markdown Document Generator Regression Check');
  const mdDoc = await documentGenerator.generateDocument({
    title: 'JARVIS System Architecture Notes',
    format: 'md',
    content: '# Architecture Overview\n\nVerified 407 outcomes across 15 system categories.',
  });
  assert.strictEqual(mdDoc.format, 'md');
  assert.ok(mdDoc.downloadUrl.includes('/api/documents/'), 'Must have download URL');
  console.log('  -> Markdown Document ID:', mdDoc.id);
  console.log('  -> Filename:', mdDoc.filename);

  console.log('\n=============================================================');
  console.log('ALL 12 POST-EXECUTION VERIFICATION CHECKS PASSED PERFECTLY!');
  console.log('=============================================================');
}

if (process.argv[1]?.includes('postExecutionVerification.ts')) {
  runPostExecutionVerification()
    .then(() => {
      console.log('\nPost-execution verification exited cleanly (code 0).');
      process.exit(0);
    })
    .catch((err) => {
      console.error('\nPost-execution verification FAILED:', err);
      process.exit(1);
    });
}
