const E=require('../www/engine.js');let pass=0,fail=0;
const eq=(name,a,b)=>{if(Math.abs(a-b)<1e-9){pass++;console.log('PASS',name,a)}else{fail++;console.log('FAIL',name,a,'expected',b)}};
const mk=()=>E.empty();
let d=mk();const ch=E.findOrCreateItem(d,'Chair','A');
eq('T1 10x100',E.calculateSaleTotal(10,100),1000);
// T2 labour takes 20 sells 12 returns 7 wastage 1
d.adds.push({id:'a',date:'2026-10-03',itemId:ch.id,qty:100});
d.lentries.push({id:'e',labourId:'L',date:'2026-10-03',lines:[{itemId:ch.id,taken:20,sold:12,returned:7,wastage:1,rate:100,wRate:50}]});
let s=E.calculateStock(d,ch.id);
eq('T2 store stock (100-20+7)',s.available,87);
eq('T2 net leaving store (sold+wastage)',100-s.available,13);
eq('T2 user figure 20-12+7-1',20-12+7-1,14);
eq('T2 labour reconciles 20-12-7-1',20-12-7-1,0);
eq('T3 wastage 2x50',E.calculateWastageCost(2,50),100);
const e4={lines:[{taken:10,sold:10,rate:100},{taken:5,sold:5,rate:200}]};
eq('T4 10x100+5x200',E.calculateLabourDue(e4).soldValue,2000);
d=mk();const m=E.findOrCreateItem(d,'Mat','');
d.sales.push({id:'1',date:'2026-10-01',itemId:m.id,qty:2,rate:100},{id:'2',date:'2026-10-02',itemId:m.id,qty:2,rate:120});
eq('T5 separate days total',E.calculateDashboardTotals(d,'2026-10-02').totalSales,440);
eq('T5 day1 stays',E.calculateDashboardTotals(d,'2026-10-01').todaySales,200);
// T6-8
d=mk();const t='2026-10-03';E.findOrCreateItem(d,'Mat','');
d.sales.push({id:'x',date:t,itemId:m.id,qty:3,rate:100});
eq('T6 add',E.calculateDashboardTotals(d,t).todaySales,300);
d.sales[0].qty=5;eq('T7 edit',E.calculateDashboardTotals(d,t).todaySales,500);
d.sales=d.sales.filter(x=>x.id!=='x');eq('T8 delete',E.calculateDashboardTotals(d,t).todaySales,0);
// T9/T10 persistence via JSON round trip + migration idempotence
d.sales.push({id:'y',date:t,itemId:m.id,qty:1,rate:10});
const back=E.migrate(JSON.parse(JSON.stringify(d)));eq('T9/10 reload keeps records',back.sales.length,1);
eq('T9 reload no duplicate after 2nd load',E.migrate(JSON.parse(JSON.stringify(back))).sales.length,1);
// labour outstanding, online reduces due
const c=E.calculateLabourDue({morningCash:200,online:300,cash:200,wastageQty:2,wastageRate:50,lines:[{sold:10,rate:100}]});
eq('Labour sold value 10x100',c.soldValue,1000);eq('Wastage 2x50',c.wastageCost,100);eq('Net 1000+200-200-300 = 700 receivable',c.receivable,700);
const c2=E.calculateLabourDue({morningCash:100,cash:700,lines:[{sold:5,rate:100}]});eq('Credit: 500+100-700 = -100 -> credit 100',c2.credit,100);
eq('Default wastage rate 50',E.calculateLabourDue({wastageQty:3,lines:[]}).wastageCost,150);eq('Custom wastage rate 70',E.calculateLabourDue({wastageQty:3,wastageRate:70,lines:[]}).wastageCost,210);
// cash balance
d=mk();const q=E.findOrCreateItem(d,'Stand','');
d.sales.push({id:'s',date:t,itemId:q.id,qty:10,rate:100});
d.expenses.push({id:'x',date:t,desc:'h',amount:100});d.finance.push({id:'f',date:t,person:'p',amount:200});
d.wastage.push({id:'w',date:t,itemId:q.id,qty:2,rate:50});
d.lentries.push({id:'l',labourId:'L',date:t,morningCash:50,online:300,cash:100,extra:0,under:0,lines:[]});
eq('Cash 1000+300+100-100-200-100-50',E.calculateCashBalance(d),950);
eq('Wastage not in sales',E.calculateDashboardTotals(d,t).totalSales,1000);
eq('Validation NaN rejected',E.validate({nums:[['Qty','abc']]}).length,1);
d.school.push({id:'s',date:t,fees:100,expense:50});d.prime.push({id:'p1',date:t,type:'credit',amount:500},{id:'p2',date:t,type:'debit',amount:200});
eq('Cash with school(-150) prime(+500-200)',E.calculateCashBalance(d),950-150+300);
d=mk();const it=E.findOrCreateItem(d,'Chair','A');d.firstPrev=500;d.profitRates.push({id:'p',item:'chair',rate:20});
d.sales.push({id:'1',date:'2026-10-01',itemId:it.id,qty:10,rate:100},{id:'2',date:'2026-10-02',itemId:it.id,qty:5,rate:100});
d.lentries.push({id:'l',labourId:'L',date:'2026-10-02',morningCash:100,online:0,cash:530,lines:[{itemId:it.id,taken:4,sold:4,rate:100,returned:0}]});
d.loans.push({id:'ln',date:'2026-10-02',type:'Bank Loan',amount:200});
eq('Previous sale first day = 500',E.previousSale(d,'2026-10-01'),500);eq('Previous sale day2 = day1 sale',E.previousSale(d,'2026-10-02'),1000);
const h=E.dailyHisaab(d,'2026-10-02');eq('Day sale 500+400',h.sale,900);eq('Final benefit 900+1000+30-(20+100)-200',h.benefit,900+1000+30-200);
d.ownPurchases.push({id:'op',date:'2026-10-01',item:'Chair',qty:30,rate:20,paid:150,remaining:0});
eq('Own sale value 1900',E.ownProfit(d).sale,1900);eq('Own cost 19x20',E.ownProfit(d).cost,380);eq('Own profit 1900-380',E.ownProfit(d).total,1520);eq('Own profit today 900-180',E.ownProfit(d,'2026-10-02').total,720);eq('Own stock 30-19',E.ownProfit(d).rows[0].remaining,11);
console.log(pass+' passed, '+fail+' failed');process.exit(fail?1:0);
