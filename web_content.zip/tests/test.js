const E=require('../www/engine.js');let pass=0,fail=0;
const eq=(name,a,b)=>{if(Math.abs(a-b)<1e-9){pass++;console.log('PASS',name,a)}else{fail++;console.log('FAIL',name,a,'expected',b)}};
const mk=()=>Object.assign(E.empty(),{stockMode:'add'});
let d=mk();const ch=E.findOrCreateItem(d,'Chair','A');
eq('T1 10x100',E.calculateSaleTotal(10,100),1000);
// T2 labour takes 20 sells 12 returns 7 wastage 1
d.adds.push({id:'a',date:'2026-10-03',itemId:ch.id,qty:100});
d.lentries.push({id:'e',labourId:'L',date:'2026-10-03',lines:[{itemId:ch.id,taken:20,sold:12,returned:7,wastage:1,rate:100,wRate:50}]});
let s=E.calculateStock(d,ch.id);
eq('T2 store stock (added 100 - sold 12)',s.available,88);
eq('T2 net leaving store (= sold)',100-s.available,12);
eq('T2 user figure 20-12+7-1',20-12+7-1,14);
eq('T2 labour reconciles 20-12-7-1',20-12-7-1,0);
eq('T3 wastage 2x50',E.calculateWastageCost(2,50),100);
const e4={lines:[{taken:10,sold:10,rate:100},{taken:5,sold:5,rate:200}]};
eq('T4 10x100+5x200',E.calculateLabourDue(e4).soldValue,2000);
d=mk();const m=E.findOrCreateItem(d,'Mat','');
d.sales.push({id:'1',date:'2026-10-01',itemId:m.id,qty:2,rate:100},{id:'2',date:'2026-10-02',itemId:m.id,qty:2,rate:120});
eq('T5 separate days total',E.calculateDashboardTotals(d,'2026-10-02').totalSales,440);
eq('T5 day1 stays',E.calculateDashboardTotals(d,'2026-10-01').todaySales,200);
// T6-8
d=mk();const t='2026-10-03';E.findOrCreateItem(d,'Mat','');
d.sales.push({id:'x',date:t,itemId:m.id,qty:3,rate:100});
eq('T6 add',E.calculateDashboardTotals(d,t).todaySales,300);
d.sales[0].qty=5;eq('T7 edit',E.calculateDashboardTotals(d,t).todaySales,500);
d.sales=d.sales.filter(x=>x.id!=='x');eq('T8 delete',E.calculateDashboardTotals(d,t).todaySales,0);
// T9/T10 persistence via JSON round trip + migration idempotence
d.sales.push({id:'y',date:t,itemId:m.id,qty:1,rate:10});
const back=E.migrate(JSON.parse(JSON.stringify(d)));eq('T9/10 reload keeps records',back.sales.length,1);
eq('T9 reload no duplicate after 2nd load',E.migrate(JSON.parse(JSON.stringify(back))).sales.length,1);
// labour outstanding, online reduces due
const c=E.calculateLabourDue({morningCash:200,online:300,cash:200,wastageQty:2,wastageRate:50,lines:[{sold:10,rate:100}]});
eq('Labour sold value 10x100',c.soldValue,1000);eq('Wastage 2x50',c.wastageCost,100);eq('Labour total 1000-100 wastage',c.labourTotal,900);eq('Net (1000-100)+200-200-300 = 600 receivable',c.receivable,600);
const c2=E.calculateLabourDue({morningCash:100,cash:700,lines:[{sold:5,rate:100}]});eq('Credit: 500+100-700 = -100 -> credit 100',c2.credit,100);
eq('Default wastage rate 50',E.calculateLabourDue({wastageQty:3,lines:[]}).wastageCost,150);eq('Custom wastage rate 70',E.calculateLabourDue({wastageQty:3,wastageRate:70,lines:[]}).wastageCost,210);
// cash balance = today's final benefit
d=mk();const q=E.findOrCreateItem(d,'Stand','');
d.sales.push({id:'s',date:t,itemId:q.id,qty:10,rate:100});
d.expenses.push({id:'x',date:t,desc:'h',amount:100});d.finance.push({id:'f',date:t,person:'p',amount:200});
d.wastage.push({id:'w',date:t,itemId:q.id,qty:2,rate:50});
d.lentries.push({id:'l',labourId:'L',date:t,morningCash:50,online:300,cash:100,extra:0,under:0,lines:[]});
eq('Cash balance 1000 sale - exp100 - fin200 + labour credit 350 (morning already inside credit) =',E.calculateCashBalance(d,t),1000-100-200+350);
eq('Wastage not in sales',E.calculateDashboardTotals(d,t).totalSales,1000);
eq('Validation NaN rejected',E.validate({nums:[['Qty','abc']]}).length,1);
d.school.push({id:'s',date:t,fees:100,expense:50});d.prime.push({id:'p1',date:t,type:'credit',amount:500},{id:'p2',date:t,type:'debit',amount:200});
eq('Cash with school(-150) bank(+500-200)',E.calculateCashBalance(d,t),1000-100-200+350-150+300);
d=mk();const it=E.findOrCreateItem(d,'Chair','A');d.firstPrev=500;d.profitRates.push({id:'p',item:'chair',rate:20});
d.sales.push({id:'1',date:'2026-10-01',itemId:it.id,qty:10,rate:100},{id:'2',date:'2026-10-02',itemId:it.id,qty:5,rate:100});
d.lentries.push({id:'l',labourId:'L',date:'2026-10-02',morningCash:100,online:0,cash:530,lines:[{itemId:it.id,taken:4,sold:4,rate:100,returned:0}]});
d.loans.push({id:'ln',date:'2026-10-02',type:'Bank Loan',amount:200});
eq('Previous first day = 500 (typed)',E.previousSale(d,'2026-10-01'),500);eq('Day2 previous = day1 final balance 1000+500',E.previousSale(d,'2026-10-02'),1500);
const h=E.dailyHisaab(d,'2026-10-02');eq('Day sale 500+400',h.sale,900);eq('Final benefit 900+1500+30-200',h.benefit,900+1500+30-200);
d.ownPurchases.push({id:'op',date:'2026-10-01',item:'Chair',qty:30,rate:20,paid:150,remaining:0});
eq('Own sale value 1900',E.ownProfit(d).sale,1900);eq('Own cost 19x20',E.ownProfit(d).cost,380);eq('Own profit 1900-380',E.ownProfit(d).total,1520);eq('Own profit today 900-180',E.ownProfit(d,'2026-10-02').total,720);eq('Own stock 30-19',E.ownProfit(d).rows[0].remaining,11);
// sold summary (notebook style)
d=mk();const a1=E.findOrCreateItem(d,'Fan','');d.sales.push({id:'1',date:'2026-10-04',itemId:a1.id,qty:2,rate:290});
d.lentries.push({id:'l',labourId:'L',date:'2026-10-04',lines:[{itemId:a1.id,taken:30,sold:25,rate:175,returned:0},{itemId:a1.id,taken:5,sold:5,rate:290,returned:0}]});
const ss=E.soldSummary(d,'2026-10-04');eq('Summary rows (290 merged, 175)',ss.rows.length,2);eq('Summary qty 2+25+5',ss.qty,32);eq('Summary amount 580+4375+1450',ss.amount,6405);
eq('Stock item soldValue',E.calculateStock(d,a1.id).soldValue,6405);eq('Summary other date empty',E.soldSummary(d,'2026-10-05').amount,0);eq('Summary all dates',E.soldSummary(d,'').amount,6405);
// labour ledger: day1 sold 1000 waste 100 morning 50, paid 300; day2 jama 400 -> baki 250 -> 600 then 200
d=mk();const lg=E.findOrCreateItem(d,'Fan','');
d.lentries.push({id:'a',labourId:'R',date:'2026-10-01',morningCash:50,cash:200,online:100,wastageQty:2,wastageRate:50,lines:[{itemId:lg.id,taken:10,sold:10,rate:100,returned:0}]});
let g=E.labourLedger(d,'R');eq('Ledger debit 1000-100+50',g.debit,950);eq('Ledger credit 300',g.credit,300);eq('Ledger baki 650',g.balance,650);
d.lentries.push({id:'b',labourId:'R',date:'2026-10-02',morningCash:0,cash:400,online:0,lines:[]});
g=E.labourLedger(d,'R');eq('After jama 400 baki 250',g.balance,250);eq('Receivable 250',g.receivable,250);eq('Dashboard receivable 250',E.calculateDashboardTotals(d,'2026-10-02').receivable,250);
d.lentries.push({id:'c',labourId:'R',date:'2026-10-03',morningCash:0,cash:300,online:0,lines:[]});g=E.labourLedger(d,'R');eq('Overpaid -> advance 50',g.advance,50);eq('Dashboard credit 50',E.calculateDashboardTotals(d,'2026-10-03').credit,50);eq('Dashboard receivable 0',E.calculateDashboardTotals(d,'2026-10-03').receivable,0);
eq('Labour online box total',E.labourOnline(d).total,100);eq('Labour online rows',E.labourOnline(d).rows.length,1);
// finance/loan credit = plus, debit = minus; carry forward
d=mk();d.firstPrev=100;d.finance.push({id:'f1',date:'2026-10-01',person:'p',amount:30},{id:'f2',date:'2026-10-01',person:'q',amount:50,dc:'credit'});d.loans.push({id:'l1',date:'2026-10-01',type:'Bank Loan',amount:20,dc:'debit'},{id:'l2',date:'2026-10-01',type:'Bank Loan',amount:10,dc:'credit'});d.prime.push({id:'b',date:'2026-10-01',type:'credit',amount:5});
eq('Day1 benefit 100 -30 +50 -20 +10 +5',E.dailyHisaab(d,'2026-10-01').benefit,115);d.expenses.push({id:'e',date:'2026-10-03',desc:'x',amount:15});
eq('Day3 previous carries day1 final',E.previousSale(d,'2026-10-03'),115);eq('Day3 benefit 115-15',E.dailyHisaab(d,'2026-10-03').benefit,100);eq('hisaabAll matches',E.hisaabAll(d).get('2026-10-03').benefit,100);eq('Dashboard finance net 30-50',E.calculateDashboardTotals(d,'2026-10-03').finance,-20);
// kadhai: separate category, stock separate, sale included in total
d=mk();const ch2=E.findOrCreateItem(d,'Chair','');const kd2=E.findOrCreateItem(d,'Kadhai 12','','kadhai');eq('Kadhai item cat',kd2.cat==='kadhai'?1:0,1);eq('Existing item keeps cat on re-find',E.findOrCreateItem(d,'Kadhai 12','').cat==='kadhai'?1:0,1);
d.adds.push({id:'a1',date:t,itemId:kd2.id,qty:50},{id:'a2',date:t,itemId:ch2.id,qty:20});d.sales.push({id:'s1',date:t,itemId:kd2.id,qty:2,rate:300},{id:'s2',date:t,itemId:ch2.id,qty:1,rate:100});
d.lentries.push({id:'l',labourId:'R',date:t,morningCash:0,cash:0,online:0,lines:[{itemId:kd2.id,taken:10,sold:5,rate:200,returned:0}]});
const dt2=E.calculateDashboardTotals(d,t);eq('Today sale includes kadhai 600+100+1000',dt2.todaySales,1700);eq('Kadhai today 1600',dt2.kadhaiToday,1600);eq('Kadhai stock 50 - sold',dt2.kadhaiStock,43);eq('Chair stock 20-1',dt2.stockQty,19);
eq('Summary kadhai only',E.soldSummary(d,t,'kadhai').amount,1600);eq('Summary chair only',E.soldSummary(d,t,'').amount,100);eq('Summary all',E.soldSummary(d,t).amount,1700);
d.firstPrev=500;eq('Total sale = previous + today',E.calculateDashboardTotals(d,t).totalSales,2200);
d.lentries.push({id:'m',labourId:'R',date:t,morningCash:0,cash:30,online:70,lines:[]});const lr2=E.labourReceived(d);eq('Received cash',lr2.cash,30);eq('Received online',lr2.online,70);
// purchase ledger: wastage minus from purchase
d=mk();const pw=E.findOrCreateItem(d,'Chair','');d.ownPurchases.push({id:'p1',date:'2026-10-01',item:'Chair',qty:30,rate:20,freight:0,paid:150},{id:'p2',date:'2026-10-02',item:'Chair',qty:10,rate:20,freight:10,paid:0});
d.wastage.push({id:'w1',date:'2026-10-02',itemId:pw.id,qty:2,rate:50});
let pl=E.purchaseLedger(d);eq('Purchase1 net 600-100',pl[0].net,500);eq('Purchase1 wastage adj 100',pl[0].wastageAdj,100);eq('Purchase1 remaining 500-150',pl[0].remaining,350);eq('Purchase2 untouched net 210',pl[1].net,210);
eq('Final purchase line day1 = paid 150 - wastage 100',E.dailyHisaab(d,'2026-10-01').purchase,50);eq('Wastage w/o purchase day2 no effect',E.dailyHisaab(d,'2026-10-02').purchase,0);
// default stock rule = Open + Added - Sold; 'open' mode ignores Added
{const d=E.empty(),it=E.findOrCreateItem(d,'Futura','Chair');it.opening=383;d.adds.push({id:'a',date:'2026-10-01',itemId:it.id,qty:267});d.labours.push({id:'L',name:'X'});d.lentries.push({id:'e',labourId:'L',date:'2026-10-02',lines:[{itemId:it.id,taken:213,sold:135,returned:52,rate:300}]});eq('default Open + Added - Sold',E.calculateStock(d,it.id).available,515);d.stockMode='open';eq('mode open: Open - Sold (Added ignored)',E.calculateStock(d,it.id).available,248)}

// Previous gross sale is separate from the previous day's carried final balance.
d=mk();const pg=E.findOrCreateItem(d,'Chair','');d.firstPrev=500;
d.sales.push({id:'pg-yday',date:'2026-10-01',itemId:pg.id,qty:2,rate:100},{id:'pg-today',date:'2026-10-02',itemId:pg.id,qty:3,rate:150});
eq('Previous gross sale is yesterday sale only',E.previousGrossSale(d,'2026-10-02'),200);
eq('Total Sale = previous Final Benefit (700) + today sale (450)',E.calculateDashboardTotals(d,'2026-10-02').totalSales,1150);
eq('Carried final balance remains separately calculated from previous day benefit',E.previousSale(d,'2026-10-02'),700);
d=mk();const opg=E.findOrCreateItem(d,'Stand','');d.firstPrev=600;d.sales.push({id:'opg-today',date:'2026-10-02',itemId:opg.id,qty:2,rate:150});
eq('Opening previous amount used before historical sales exist',E.previousGrossSale(d,'2026-10-02'),600);
eq('Opening previous amount contributes to gross total sale',E.calculateDashboardTotals(d,'2026-10-02').totalSales,900);
d=mk();const zpg=E.findOrCreateItem(d,'Mat','');d.sales.push({id:'zpg-old',date:'2026-10-01',itemId:zpg.id,qty:5,rate:100},{id:'zpg-today',date:'2026-10-03',itemId:zpg.id,qty:2,rate:120});
eq('No sale yesterday means previous gross sale is zero, not the carried cash balance',E.previousGrossSale(d,'2026-10-03'),0);
// Previous carry must include a date containing only a purchase-payment entry.
d=mk();const prevItem=E.findOrCreateItem(d,'Chair','');d.firstPrev=1000;
d.sales.push({id:'prev-sale',date:'2026-10-01',itemId:prevItem.id,qty:2,rate:100});
d.purchasePayments.push({id:'only-payment-day',date:'2026-10-02',amount:200,note:'Purchase advance'});
eq('Previous carry considers purchase-payment-only date',E.previousSale(d,'2026-10-03'),1000);
eq('Purchase payment is deducted on its own day',E.dailyHisaab(d,'2026-10-02').benefit,1000);
eq('Purchase-payment date participates in day list',E.allDates(d).includes('2026-10-02')?1:0,1);
console.log(pass+' passed, '+fail+' failed');process.exit(fail?1:0);

