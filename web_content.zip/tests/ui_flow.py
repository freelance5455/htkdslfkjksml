"""Celý průchod hrou v headless Chromiu:  python3 -I tests/ui_flow.py"""
import glob, json
from playwright.sync_api import sync_playwright
exe = (glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome') or [None])[0]
SH = '/home/claude/BubbleDefence/tests/shots/'
errs, net, results = [], [], []
def check(name, cond, extra=''):
    results.append((name, bool(cond))); print(('OK   ' if cond else 'FAIL ') + name + (' ' + str(extra) if extra != '' else ''))

with sync_playwright() as p:
    b = p.chromium.launch(executable_path=exe, args=['--no-sandbox'])
    ctx = b.new_context(viewport={'width': 1280, 'height': 800}, accept_downloads=True)
    pg = ctx.new_page()
    pg.on('pageerror', lambda e: errs.append('PAGEERROR ' + str(e)))
    pg.on('console', lambda m: errs.append(m.type + ' ' + m.text) if m.type in ('error', 'warning') else None)
    pg.on('request', lambda r: net.append(r.url) if not r.url.startswith(('file:', 'data:', 'blob:')) else None)
    def ready(sel, t=6000): pg.wait_for_selector('.content:not(.hidden) ' + sel, timeout=t)
    pg.goto('file:///home/claude/BubbleDefence/index.html'); ready('.intro')

    # 1) úvod -> nová lokální hra -> menu (okno se zvětší)
    w0 = pg.evaluate("document.querySelector('.win').getBoundingClientRect().width")
    pg.click('text=Nová lokální hra'); ready('.menu')
    w1 = pg.evaluate("document.querySelector('.win').getBoundingClientRect().width")
    check('okno se po úvodu zvětšilo', w1 > w0 + 300, '%d -> %d px' % (w0, w1))
    check('okno menu nezabírá celou šířku', w1 < 1280, w1)
    pg.wait_for_timeout(300); pg.screenshot(path=SH + '01_menu_story_new.png')

    # 2) story: pokračovat je zatím vypnuté; free > nová hra ukáže mapy
    check('Story pokračovat je vypnuté bez postupu', 'off' in pg.get_attribute('.ms >> nth=0', 'class'))
    pg.click('.mi:has-text("Free mód")'); pg.hover('.ms:has-text("Nová hra")'); pg.wait_for_timeout(200)
    check('Free nová hra ukazuje seznam map', pg.locator('.mright .lcard').count() == 3, pg.locator('.mright .lcard').count())
    pg.screenshot(path=SH + '02_menu_free_new.png')

    # 3) editor: nový level -> placeholder -> zpět; v seznamu se objeví
    pg.click('.mi:has-text("Editor")'); pg.click('.lcard.add'); ready('.edv')
    check('editor se otevřel (celé okno)', pg.evaluate("document.querySelector('.win').getBoundingClientRect().width") >= 1279)
    pg.screenshot(path=SH + '03_editor_placeholder.png')
    pg.click('text=Menu'); ready('.menu'); pg.click('.mi:has-text("Editor")'); pg.wait_for_timeout(200)
    check('uložený level je v seznamu editoru', pg.locator('.mright .lcard:not(.add)').count() == 1)
    pg.screenshot(path=SH + '04_menu_editor_list.png')

    # 4) nastavení zůstane v okně
    pg.click('.mi:has-text("Nastavení")'); pg.wait_for_timeout(250)
    check('nastavení nezvětšilo okno na celou obrazovku', pg.evaluate("document.querySelector('.win').getBoundingClientRect().width") < 1280)
    pg.screenshot(path=SH + '05_settings.png')
    pg.click('.seg >> nth=0 >> button >> nth=2')      # rychlost 3×
    pg.click('.seg >> nth=1 >> button >> nth=2')      # třesení silné
    check('nastavení se zapsalo do profilu', pg.evaluate("BD.store.profile.settings.gameSpeed === 3 && BD.store.profile.settings.shake === 2"))

    # 5) story nová hra -> mapa: jen tutoriál otevřený, další zamčený, zbytek skrytý
    pg.click('.mi:has-text("Story mód")'); pg.click('.ms:has-text("Nová hra")'); ready('.smap', 8000)
    check('mapa: vidět jen 2 uzly (tutoriál + zamčený další)', pg.locator('.node').count() == 2, pg.locator('.node').count())
    pg.wait_for_timeout(300); pg.screenshot(path=SH + '06_map_start.png')
    box = pg.locator('.node.open .dot').bounding_box(); pg.mouse.move(box['x'] + 10, box['y'] + 10); pg.wait_for_timeout(200)
    check('najetí myší ukáže popup s tvarem levelu', pg.locator('.tip .lp').count() == 1)
    pg.screenshot(path=SH + '07_map_tooltip.png')

    # 6) tutoriál: klik na uzel -> hra, banner, kroky
    pg.click('.node.open .dot'); ready('.gv', 8000); pg.wait_for_timeout(300)
    check('tutoriál: viditelný banner', pg.locator('.tut').count() == 1)
    pg.screenshot(path=SH + '08_tutorial_step1.png')
    pg.keyboard.press('1')
    cv = pg.locator('.stage canvas').bounding_box(); g = pg.evaluate('({w:BD.debug.game.w,h:BD.debug.game.h})')
    cell = cv['width'] / (g['w'] + 2)          # px na buňku; 1 věž = 2×2 buňky, kolem pole je okraj 1 buňka
    def click_cell(tx, ty): pg.mouse.click(cv['x'] + (1 + tx * 2 + 1) * cell, cv['y'] + (1 + ty * 2 + 1) * cell); pg.wait_for_timeout(60)
    for ty in range(6): click_cell(5, ty)      # svislá zeď z věží → cesta se výrazně prodlouží
    pg.wait_for_timeout(300)
    check('tutoriál: kroky postoupily po postavení věží', pg.evaluate('BD.debug.tStep.value') >= 3, pg.evaluate('BD.debug.tStep.value'))
    pg.screenshot(path=SH + '09_tutorial_towers.png')
    pg.keyboard.press(' '); pg.wait_for_timeout(300)
    check('tutoriál: spuštěná vlna posunula krok', pg.evaluate('BD.debug.tStep.value') >= 4)
    # dohrát: nastavit rychlost 3× a doplnit věže přímo přes engine
    pg.evaluate("(()=>{const g=BD.debug.game; g.gold=5000; for(let x=0;x<20;x+=2){ g.place('normal',x,2); g.place('normal',x,12);} BD.debug.v.speed=3;})()")
    for i in range(3):
        pg.evaluate("(()=>{const g=BD.debug.game; if(g.streams.length===0 && !g.won) g.startWave();})()")
        pg.wait_for_function("BD.debug.game.streams.length===0 && BD.debug.game.enemies.length===0", timeout=60000)
        pg.wait_for_timeout(150)
    pg.wait_for_selector('.over:has-text("Level splněn")', timeout=10000)
    check('tutoriál: výhra po 3 vlnách', pg.evaluate("BD.debug.result.value") == 'won')
    pg.screenshot(path=SH + '10_win.png')
    pg.click('text=Zpět na mapu'); ready('.smap', 8000)
    check('po tutoriálu je splněný a odemkl se Základy', pg.locator('.node.done').count() == 1 and pg.locator('.node.open').count() == 1)
    check('po tutoriálu zmizelo tlačítko Přeskočit', pg.locator('text=Přeskočit tutoriál').count() == 0)
    pg.wait_for_timeout(300); pg.screenshot(path=SH + '11_map_after_tutorial.png')

    # 7) level Základy: postavit, odejít do menu mezi vlnami, v menu je náhled s věžemi
    pg.click('.node.open .dot'); ready('.gv', 8000); pg.wait_for_timeout(200)
    check('level Základy nemá tutoriál', pg.locator('.tut').count() == 0)
    pg.evaluate("(()=>{const g=BD.debug.game; g.gold=5000; g.place('normal',10,6); g.place('normal',12,6); g.place('boost',10,13); g.startWave(); BD.debug.v.speed=3;})()")
    pg.wait_for_function("BD.debug.game.streams.length===0 && BD.debug.game.enemies.length===0", timeout=60000)
    pg.evaluate("BD.debug.game.place('normal',8,2)"); pg.wait_for_timeout(250)
    pg.click('text=Menu'); pg.wait_for_selector('.pause'); pg.screenshot(path=SH + '12_pause.png')
    pg.click('.pbox >> text=Hlavní menu'); ready('.menu', 8000)
    pg.click('.mi:has-text("Story mód")'); pg.hover('.ms:has-text("Pokračovat")'); pg.wait_for_timeout(250)
    check('Story pokračovat je zapnuté a ukazuje náhled', pg.locator('.pv-shape .lp').count() == 1 and 'off' not in pg.get_attribute('.ms >> nth=0', 'class'))
    check('náhled obsahuje uložené věže (4)', pg.locator('.pv-shape .lp rect[opacity]').count() == 4, pg.locator('.pv-shape .lp rect[opacity]').count())
    pg.screenshot(path=SH + '13_menu_story_continue.png')
    pg.click('.pv-info .btn.primary'); ready('.gv', 8000); pg.wait_for_timeout(300)
    check('pokračování obnovilo věže, vlnu a zlato', pg.evaluate("BD.debug.game.towers.length === 4 && BD.debug.game.wave === 1"), pg.evaluate("[BD.debug.game.towers.length, BD.debug.game.wave]"))
    pg.click('text=Menu'); pg.click('.pbox >> text=Hlavní menu'); ready('.menu', 8000)

    # 8) free mód: nová hra -> vlna -> odejít -> pokračovat
    pg.click('.mi:has-text("Free mód")'); pg.hover('.ms:has-text("Nová hra")'); pg.click('.lcard >> nth=0'); ready('.gv', 8000)
    check('free hra je nekonečná', pg.evaluate("BD.debug.game.maxWaves") == 0)
    pg.evaluate("(()=>{const g=BD.debug.game; g.gold=5000; for(let x=0;x<12;x+=2) g.place('normal',x,2); g.startWave(); BD.debug.v.speed=3;})()")
    pg.wait_for_function("BD.debug.game.streams.length===0 && BD.debug.game.enemies.length===0", timeout=60000); pg.wait_for_timeout(250)
    pg.click('text=Menu'); pg.click('.pbox >> text=Hlavní menu'); ready('.menu', 8000)
    pg.click('.mi:has-text("Free mód")'); pg.hover('.ms:has-text("Pokračovat")'); pg.wait_for_timeout(250)
    check('Free pokračovat ukazuje uloženou hru', pg.locator('.pv-shape .lp').count() == 1)
    pg.screenshot(path=SH + '14_menu_free_continue.png')

    # 9) export -> smazání -> import
    snap = pg.evaluate("BD.store.exportJSON()")
    pg.click('.mi:has-text("Nastavení")')
    with pg.expect_download() as dl: pg.click('text=Export do JSON')
    path = dl.value.path(); data = json.load(open(path))
    check('export stáhl platný JSON postupu', data.get('game') == 'BubbleDefence' and len(data['profile']['story']['completed']) == 1, dl.value.suggested_filename)
    pg.click('text=Smazat všechna data'); pg.click('.dlg-btns >> text=Smazat vše'); pg.wait_for_timeout(300)
    check('po smazání je postup prázdný', pg.evaluate("BD.store.profile.story.completed.length") == 0)
    pg.set_input_files('.settings input[type=file]', path); pg.wait_for_selector('.dlg'); pg.click('.dlg >> text=Přepsat'); pg.wait_for_timeout(400)
    check('import obnovil postup', pg.evaluate("BD.store.profile.story.completed.length") == 1 and pg.evaluate("BD.store.profile.story.save !== null") and pg.evaluate("BD.store.profile.settings.gameSpeed") == 3)

    # 10) obnova po reloadu stránky + nový start ukáže Pokračovat
    pg.wait_for_timeout(500); pg.reload(); ready('.intro')
    check('po reloadu úvod nabízí Pokračovat v postupu', pg.locator('text=Pokračovat v postupu').count() == 1)
    pg.screenshot(path=SH + '15_intro_with_save.png')
    pg.click('text=Pokračovat v postupu'); ready('.menu', 8000)
    check('postup přežil reload', pg.evaluate("BD.store.profile.story.completed.length") == 1)

    # 11) poškozený JSON se odmítne
    pg.click('.mi:has-text("Nastavení")')
    open('/tmp/bad.json', 'w').write('{"game":"x"}')
    pg.set_input_files('.settings input[type=file]', '/tmp/bad.json'); pg.wait_for_selector('.dlg'); pg.click('.dlg >> text=Přepsat'); pg.wait_for_timeout(300)
    check('cizí JSON se odmítne a postup zůstane', pg.locator('.msg.err').count() == 1 and pg.evaluate("BD.store.profile.story.completed.length") == 1)
    b.close()

bad = [n for n, ok in results if not ok]
print('\nvýsledek: %d/%d' % (len(results) - len(bad), len(results)), '| selhalo:', bad or 'nic')
print('chyby konzole:', errs or 'žádné', '| síť mimo soubor:', net or 'žádná')
