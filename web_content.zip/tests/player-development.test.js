import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState, validateState } from '../src/store.js';
import { trainDamiste, restDamiste, injureDamiste, getDamisteDevelopment } from '../src/player-development.js';
import { getGalaxyManagementOverview, validateGalaxyManagement } from '../src/galaxy-management.js';

test('entraînement développe le talent, l’expérience et fatigue le damiste', () => {
  const s = createInitialState(); const p = s.divisions[0].clubs[0].damistes[0];
  const result = trainDamiste(s, p.id, 'strategy');
  assert.equal(result.talentGain, 2);
  assert.equal(getDamisteDevelopment(p).talents.strategy, 2);
  assert.equal(p.form, 45);
  assert.equal(getDamisteDevelopment(p).trainingSessions, 1);
});

test('repos restaure la forme et réduit une blessure', () => {
  const s = createInitialState(); const p = s.divisions[0].clubs[0].damistes[0];
  injureDamiste(s, p.id, { type: 'genou', days: 10 });
  const result = restDamiste(s, p.id, 3);
  assert.equal(result.injury.daysRemaining, 7);
  assert.equal(result.form, 64);
  restDamiste(s, p.id, 7);
  assert.equal(p.injury, null);
});

test('les blessures refusent une durée invalide et un joueur inconnu', () => {
  const s = createInitialState();
  assert.throws(() => injureDamiste(s, 'absent', { days: 2 }), /introuvable/);
  assert.throws(() => injureDamiste(s, s.divisions[0].clubs[0].damistes[0].id, { days: 181 }), /invalide/);
});

test('le tableau galactique conserve 24 galaxies et calcule un classement stable', () => {
  const s = createInitialState();
  const rows = getGalaxyManagementOverview(s);
  assert.equal(rows.length, 24);
  assert.deepEqual(rows.map(x => x.rank), Array.from({ length: 24 }, (_, i) => i + 1));
  assert.equal(validateGalaxyManagement(s), true);
  assert.equal(validateState(s), true);
});
