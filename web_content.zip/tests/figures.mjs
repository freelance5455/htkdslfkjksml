import assert from "node:assert/strict";
import { chromium } from "playwright";

function imagePdf(jpeg, w, h) {
  const content = "q 595 0 0 842 0 0 cm /Im Do Q";
  const head = Buffer.from(
    `%PDF-1.4\n1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /XObject << /Im 4 0 R >> >> /Contents 5 0 R >>\nendobj\n4 0 obj\n<< /Type /XObject /Subtype /Image /Width ${w} /Height ${h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpeg.length} >>\nstream\n`,
  );
  const mid = Buffer.from(`\nendstream\nendobj\n5 0 obj\n<< /Length ${content.length} >>\nstream\n${content}\nendstream\nendobj\n`);
  const body = Buffer.concat([head, jpeg, mid]);
  const offsets = [9];
  let pos = 9;
  const markers = [Buffer.from("\nendobj\n")];
  // xref from known object starts
  const starts = [];
  let cursor = 0;
  for (let n = 1; n <= 5; n++) {
    const token = Buffer.from(`${n} 0 obj`);
    const at = body.indexOf(token, cursor);
    starts.push(at);
    cursor = at + 1;
  }
  let xref = `xref\n0 6\n0000000000 65535 f \n${starts.map((o) => `${String(o).padStart(10, "0")} 00000 n \n`).join("")}`;
  xref += `trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${body.length}\n%%EOF`;
  return Buffer.concat([body, Buffer.from(xref)]);
}

const browser = await chromium.launch({ headless: true });
try {
  const W = 1240;
  const H = 1754;
  const shot = await browser.newPage({ viewport: { width: W, height: H } });
  await shot.setContent(`<html dir="rtl"><body style="margin:90px 110px;background:#f7f1e4;font-family:'DejaVu Sans';color:#222">
    <p style="font-size:34px;line-height:1.7">این متن بالای نقاشی است و باید جدا خوانده شود.</p>
    <div style="height:760px;margin:30px 0;background:linear-gradient(135deg,#1d4e89,#f2a541 55%,#b42318)"></div>
    <p style="font-size:34px;line-height:1.7">این توضیح زیر نقاشی است و باید بعد از تصویر بیاید.</p>
  </body></html>`);
  const jpeg = await shot.screenshot({ type: "jpeg", quality: 85 });
  await shot.close();

  const page = await browser.newPage({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  const errors = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await page.goto(process.env.TEST_URL || "http://127.0.0.1:5173/");
  await page.locator('input[type="file"]').setInputFiles({
    name: "illustrated.pdf",
    mimeType: "application/pdf",
    buffer: imagePdf(jpeg, W, H),
  });
  await page.getByRole("button", { name: "باز کردن illustrated" }).click();
  await page.locator("img[alt='تصویر']").waitFor({ timeout: 180000 });
  const hint = page.getByRole("button", { name: "فهمیدم" });
  if (await hint.count()) await hint.click().catch(() => undefined);
  const image = page.locator("img[alt='تصویر']").first();
  const box = await image.boundingBox();
  assert(box && box.width > 250 && box.height > 120, "picture should be shown large and unchanged in shape");
  const natural = await image.evaluate((el) => ({ w: el.naturalWidth, h: el.naturalHeight, filter: getComputedStyle(el).filter }));
  assert(natural.w > 400 && natural.h > 200, "stored picture should be the original crop, not a thumbnail");
  assert.equal(natural.filter, "none");
  const max = Number(await page.locator("footer input[type=range]").getAttribute("max"));
  const kinds = [];
  for (let i = 0; i <= max; i++) {
    await page.locator("footer input[type=range]").evaluate((el, value) => {
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(el, String(value));
      el.dispatchEvent(new Event("input", { bubbles: true }));
    }, i);
    await page.waitForTimeout(180);
    kinds.push(await page.evaluate(() => {
      const articles = [...document.querySelectorAll('[role="group"] article')];
      const visible = articles.find((el) => {
        let node = el.parentElement;
        while (node && node.getAttribute("role") !== "group") {
          if (/translate3d\(0px/.test(node.getAttribute("style") || "")) return true;
          node = node.parentElement;
        }
        return false;
      }) ?? articles[0];
      if (visible.querySelector("img[alt='تصویر']")) return "image";
      if (visible.querySelector(".reflow-text")) return "text";
      return "empty";
    }));
  }
  console.log("reading order:", kinds.join(" → "));
  const imageAt = kinds.indexOf("image");
  assert(imageAt > 0, "the painting should come after the text that was above it");
  assert(kinds.slice(imageAt + 1).includes("text"), "the caption below the painting should stay text");
  assert(!kinds.includes("empty"));
  assert.equal(errors.length, 0, errors.join(" | "));
  console.log("PASS non-text picture kept in place between the surrounding text");
} finally {
  await browser.close();
}
