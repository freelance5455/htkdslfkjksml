// node tests/rules5_bonus_test.js — fetih/bonus çekirdek mantığı (rules5.js), arayüzden bağımsız
const R5 = require('../rules5.js'); let fails = 0, n = 0;
const ok = (c, m) => { n++; if (!c) { fails++; console.log('FAIL ' + m); } else console.log('PASS ' + m); };
const eq = (a, b) => JSON.stringify(a) === JSON.stringify(b);
function run(me, foe, usedIds) {
  const state = { stats: { P: me.slice() } }, pend = { loser: 'F', tg: 'X', foeSnap: foe.slice(), destroyed: false, done: false, id: 1 };
  const used = usedIds || {}; const sr = R5.settleConquest(state, 'P', pend, used);
  return { state, pend, sr, used };
}
// Senaryo A — 5/5 üstünlük: seçim yok, bonus otomatik (hepsi ×1,10)
let r = run([80, 75, 90, 85, 70], [60, 65, 80, 70, 50]);
ok(r.sr.mode === 'auto' && r.sr.ok, 'A: 5/5 üstünlük → otomatik');
ok(r.pend.done === true, 'A: seçim beklenmiyor (pend.done)');
ok(eq(r.state.stats.P, [88, 82.5, 99, 93.5, 77]), 'A: bonus beş özelliğe ×1,10 uygulandı ' + JSON.stringify(r.state.stats.P));
// Senaryo B — 4. değer düşük: seçim zorunlu, bonus yok, değerler değişmez
r = run([80, 75, 90, 65, 70], [60, 65, 80, 70, 50]);
ok(r.sr.mode === 'choose' && r.pend.done === false, 'B: 4. değer düşük → seçim zorunlu');
ok(eq(r.state.stats.P, [80, 75, 90, 65, 70]), 'B: değerler değişmedi');
// Senaryo C — eşitlik üstünlük sayılmaz
r = run([80, 75, 90, 70, 70], [60, 65, 80, 70, 50]);
ok(r.sr.mode === 'choose' && !r.pend.done, 'C: eşit değer → seçim zorunlu');
// Senaryo D — tek kategoride düşük (4 yüksek, 1 düşük), her konum için
[0, 1, 2, 3, 4].forEach(k => {
  const me = [80, 75, 90, 85, 70], foe = [60, 65, 80, 70, 50]; me[k] = foe[k] - 1;
  const x = run(me, foe); ok(x.sr.mode === 'choose' && !x.pend.done && eq(x.state.stats.P, me), 'D: ' + (k + 1) + '. değer düşük → seçim zorunlu');
});
// Birden fazla düşük / hepsi düşük / tüm eşit
ok(run([10, 10, 10, 10, 10], [60, 65, 80, 70, 50]).sr.mode === 'choose', 'hepsi düşük → seçim zorunlu');
ok(run([60, 65, 80, 70, 50], [60, 65, 80, 70, 50]).sr.mode === 'choose', 'hepsi eşit → seçim zorunlu');
ok(run([80, 75, 60, 65, 70], [60, 65, 80, 70, 50]).sr.mode === 'choose', 'birden fazla düşük → seçim zorunlu');
// Aynı kategori karşılaştırması (çapraz değil): 1. değer yüksek ama 2. foe değerinden düşük
ok(run([100, 1, 100, 100, 100], [50, 50, 50, 50, 50]).sr.mode === 'choose', 'karşılaştırma aynı kategoriyle (çapraz değil)');
// Geçersiz değerler asla üstünlük sayılmaz
ok(run([NaN, 75, 90, 85, 70], [60, 65, 80, 70, 50]).sr.mode === 'choose', 'NaN → üstünlük yok');
// Çift uygulama önlemi
r = run([80, 75, 90, 85, 70], [60, 65, 80, 70, 50]);
const after1 = r.state.stats.P.slice(); const again = R5.settleConquest(r.state, 'P', r.pend, r.used);
ok(again.mode === 'none' && eq(r.state.stats.P, after1), 'aynı fetih ikinci kez çözülürse bonus tekrar uygulanmaz');
const fresh = { done: false, id: 1, foeSnap: [1, 1, 1, 1, 1] }; const again2 = R5.settleConquest(r.state, 'P', fresh, r.used);
ok(again2.mode === 'auto' && !again2.ok && again2.why === 'already' && eq(r.state.stats.P, after1), 'aynı fetih kimliği (usedIds) ile bonus ikinci kez verilmez');
const nxt = R5.settleConquest(r.state, 'P', { done: false, id: 2, foeSnap: [1, 1, 1, 1, 1] }, r.used);
ok(nxt.mode === 'auto' && nxt.ok, 'yeni fetih (yeni kimlik) yeniden bonus kazanabilir');
// Kopyalama çekirdekte 5/5 üstünlükte reddedilir (UI'yi atlatma girişimi)
const st2 = { stats: { P: [80, 75, 90, 85, 70] }, pend: { foeSnap: [60, 65, 80, 70, 50], done: false } };
const cp = R5.copyStat(st2, 'P', null, 0); ok(!cp.ok && cp.why === 'dominant' && eq(st2.stats.P, [80, 75, 90, 85, 70]), 'copyStat 5/5 üstünlükte reddedilir');
// Kopyalama üstünlük yokken normal çalışır ve tek sefer
const st3 = { stats: { P: [80, 75, 90, 65, 70] }, pend: { foeSnap: [60, 65, 80, 70, 50], done: false } };
const c3 = R5.copyStat(st3, 'P', null, 3); ok(c3.ok && st3.stats.P[3] === 70 && st3.pend.done, 'copyStat üstünlük yokken çalışır (4. değer rakibe eşitlenir)');
ok(!R5.copyStat(st3, 'P', null, 1).ok, 'copyStat ikinci kez reddedilir');
// Rakip değişmez
const foe = [60, 65, 80, 70, 50]; run([80, 75, 90, 85, 70], foe); ok(eq(foe, [60, 65, 80, 70, 50]), 'rakip değerleri değişmez');
console.log(fails ? `\n${fails}/${n} BAŞARISIZ` : `\nHEPSİ GEÇTİ (${n})`); process.exit(fails ? 1 : 0);
