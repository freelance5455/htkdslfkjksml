/**
 * JARVIS 5.1 AI Short Film Studio & Autonomous Self-Upgrade Test Suite
 * Validates:
 * 1. AI Short Film Studio 17-stage production pipeline
 * 2. Character & World Continuity Registry
 * 3. Screenplay, Shot List, Subtitles (SRT/VTT), and Audio Cue Sheets
 * 4. Production ZIP archive deliverable packaging
 * 5. Single shot regeneration capability
 * 6. Video Orchestrator Truthful CONFIG_REQUIRED boundary (zero fake video)
 * 7. Autonomous Self-Upgrade 12-stage lifecycle & SHA-256 state checkpointing
 * 8. Automatic rollback recovery upon canary failure
 * 9. Autonomous Code Debugger (root cause, unified diff, syntax verification)
 * 10. Intent Classifier routing for film generation and code debugging
 */

import { strict as assert } from 'node:assert';
import { shortFilmStudio } from '../server/media/shortFilmStudio.ts';
import { mediaEngine } from '../server/media/mediaEngine.ts';
import { selfUpgradeEngine } from '../server/system/selfUpgradeEngine.ts';
import { codingEngine } from '../server/code/codingAgent.ts';
import { IntentClassifier } from '../server/planner/intentClassifier.ts';

export async function runFilmStudioAndUpgradeTests(): Promise<{ passed: number; failed: number }> {
  console.log('\n--- Running AI Short Film Studio & Autonomous Self-Upgrade Tests ---');
  let passed = 0;
  let failed = 0;

  async function test(name: string, fn: () => Promise<void>) {
    try {
      await fn();
      console.log(`  [PASS] ${name}`);
      passed++;
    } catch (err: any) {
      console.error(`  [FAIL] ${name}:`, err.message);
      failed++;
    }
  }

  // 1. AI Short Film Studio 17-Stage Production Pipeline
  await test('1. Short Film Studio: Generates full 17-stage film production package', async () => {
    const film = await shortFilmStudio.createShortFilm({
      prompt: 'A brilliant young physicist discovers a quantum beacon echoing from the ocean floor.',
      title: 'Echoes of the Abyss',
      genre: 'Sci-Fi / Thriller',
      targetDuration: '10m',
      aspectRatio: '16:9',
      language: 'en',
      tone: 'Cinematic, Nolan-esque realism with high suspense',
    });

    assert.ok(film.id, 'Film must have an ID');
    assert.strictEqual(film.title, 'Echoes of the Abyss');
    assert.strictEqual(film.targetDuration, '10m');
    assert.strictEqual(film.aspectRatio, '16:9');
    assert.ok(film.qualityReport.checks.length >= 8, 'Must record comprehensive QC pipeline checks');
    assert.ok(film.scenes.length >= 3, 'Must produce multi-scene screenplay');
    assert.ok(film.characterBible.length >= 1, 'Must register characters in continuity registry');
    assert.ok(film.locationBible.length >= 1, 'Must register world locations in continuity registry');
    assert.ok(film.subtitlesSrt.includes('-->'), 'Must generate valid SRT subtitles');
    assert.ok(film.subtitlesVtt.startsWith('WEBVTT'), 'Must generate valid WebVTT subtitles');
    assert.ok(film.audioCueSheet.length >= 1, 'Must generate audio cue sheet');
  });

  // 2. Character & World Continuity Registry
  await test('2. Continuity Registry: Characters have consistent visual descriptors & signature palettes', async () => {
    const films = shortFilmStudio.listFilmProjects();
    assert.ok(films.length > 0, 'Project must exist from previous test');
    const film = films[0];
    const protagonist = film.characterBible[0];
    assert.ok(protagonist.name, 'Protagonist must have name');
    assert.ok(protagonist.visualDescriptor, 'Protagonist must have visual descriptor prompt');
    assert.ok(protagonist.signatureItems.length >= 1, 'Protagonist must have defined signature items');
    assert.ok(protagonist.voiceProfile.emotionalTone, 'Protagonist must have voice tone');

    // All shots featuring this character must reference continuity descriptors
    const shotsWithChar = film.scenes
      .flatMap((s) => s.shots)
      .filter((shot) => shot.characterIds.includes(protagonist.id));
    if (shotsWithChar.length > 0) {
      assert.ok(
        shotsWithChar[0].visualPrompt.length > 0,
        'Shot prompt must enforce character visual continuity'
      );
    }
  });

  // 3. Deliverable Production ZIP Packaging
  await test('3. Packaging: Builds valid ZIP archive containing screenplay, bibles, cues, and subtitles', async () => {
    const films = shortFilmStudio.listFilmProjects();
    assert.ok(films.length > 0, 'Project must exist');
    const film = films[0];
    const zipBuffer = shortFilmStudio.getFilmZip(film.id);
    assert.ok(zipBuffer, 'ZIP buffer must be created');
    assert.ok(zipBuffer.length > 500, 'ZIP buffer must have substantial size');

    // Verify standard PK ZIP header: 0x50, 0x4B, 0x03, 0x04
    assert.strictEqual(zipBuffer[0], 0x50);
    assert.strictEqual(zipBuffer[1], 0x4b);
    assert.strictEqual(zipBuffer[2], 0x03);
    assert.strictEqual(zipBuffer[3], 0x04);
  });

  // 4. Single Shot Regeneration
  await test('4. Regeneration: Allows fine-tuning or regenerating individual shot prompts and status', async () => {
    const films = shortFilmStudio.listFilmProjects();
    assert.ok(films.length > 0, 'Project must exist');
    const film = films[0];
    const scene = film.scenes[0];
    const shot = scene.shots[0];

    const updatedShot = shortFilmStudio.regenerateShot(
      film.id,
      scene.id,
      shot.id,
      'Modified prompt: Extreme close-up of eye reflecting beacon coordinates.'
    );

    assert.ok(updatedShot, 'Updated shot must be returned');
    assert.ok(updatedShot.visualPrompt.includes('Extreme close-up'), 'Shot prompt must reflect update');
    assert.strictEqual(updatedShot.renderStatus, 'QUEUED');
  });

  // 5. Truthful Video Provider Boundary (Zero Fake Video)
  await test('5. Video Engine: Truthfully discloses CONFIG_REQUIRED when providers lack API keys', async () => {
    const job = await mediaEngine.orchestrateVideo({
      prompt: 'Cinematic hyperdrive sequence through nebula',
      providerPreference: 'luma',
    });

    assert.strictEqual(job.provider, 'luma');
    assert.strictEqual(job.status, 'CONFIG_REQUIRED', 'Must return CONFIG_REQUIRED when LUMA_API_KEY missing');
    assert.strictEqual(job.requiredSecret, 'LUMA_API_KEY');
    assert.strictEqual(job.artifactMetadata, undefined, 'Zero mock video files generated');
  });

  // 6. Autonomous Self-Upgrade 12-Stage Lifecycle & Checkpoint Hash
  await test('6. Self-Upgrade Engine: Creates SHA-256 state checkpoint and completes non-destructive upgrade', async () => {
    const record = await selfUpgradeEngine.executeControlledUpgrade({
      targetVersion: '5.1.1',
      improvementDescription: 'Integrate AI Short Film Studio Pipeline & Autonomous Self-Upgrade Engine',
    });

    assert.strictEqual(record.status, 'SUCCESS');
    assert.strictEqual(record.currentVersion, '5.1.1');
    assert.ok(record.checkpointHash, 'Must create SHA-256 checkpoint hash');
    assert.strictEqual(record.checkpointHash.length, 64, 'SHA-256 hash must be 64 hexadecimal characters');
    assert.strictEqual(record.stages.length, 12, 'Must record all 12 upgrade stages');
    assert.strictEqual(record.testEvidence.allTestsPassed, true, 'Canary tests must pass');
  });

  // 7. Automated Rollback Recovery Upon Canary Failure
  await test('7. Self-Upgrade Engine: Triggers automated rollback and restores version when canary check fails', async () => {
    const prevVersion = selfUpgradeEngine.getCurrentVersion();
    const rollbackRecord = await selfUpgradeEngine.executeControlledUpgrade({
      targetVersion: '5.1.2-unstable',
      improvementDescription: 'Simulated regression test for canary failure',
      simulateFailureStage: 'TEST',
    });

    assert.strictEqual(rollbackRecord.status, 'ROLLED_BACK', 'Must successfully roll back');
    assert.ok(rollbackRecord.rollback, 'Must include rollback metadata');
    assert.strictEqual(rollbackRecord.rollback?.triggered, true, 'Rollback triggered must be true');
    assert.strictEqual(rollbackRecord.rollback?.restoredVersion, prevVersion, 'Must restore previous stable version');
    assert.strictEqual(selfUpgradeEngine.getCurrentVersion(), prevVersion, 'Current version must remain unchanged');
  });

  // 8. Autonomous Code Debugger
  await test('8. Code Debugger: Isolates root cause, produces unified diff, and validates syntax fix', async () => {
    const buggyCode = `function calculateTotal(price: number, tax: number) {
  const unsafe = eval("price + tax");
  document.write("Result: " + unsafe);
  return unsafe;
}`;

    const result = await codingEngine.debugCode({
      code: buggyCode,
      errorDescription: 'Unsafe eval and document.write anti-patterns',
      filePath: 'src/calc.ts',
      language: 'typescript',
    });

    assert.ok(result.fixedCode, 'Must return fixed code');
    assert.ok(result.rootCause, 'Must provide root cause analysis');
    assert.ok(result.diff.unifiedDiff.includes('--- a/src/calc.ts'), 'Must include unified diff');
    assert.ok(result.validation.syntaxOk, 'Fixed code must pass syntax check');
    assert.strictEqual(result.fixedCode.includes('eval('), false, 'Fixed code must not contain eval()');
  });

  // 9. Intent Classifier Recognition
  await test('9. Intent Classifier: Correctly recognizes film studio and code debug commands', async () => {
    const filmIntent = IntentClassifier.analyze('build a 10-minute AI short film about deep space exploration');
    assert.strictEqual(filmIntent.intentType, 'AI_SHORT_FILM_GENERATION');
    assert.strictEqual(filmIntent.requiresToolExecution, true);

    const debugIntent1 = IntentClassifier.analyze('code debug karo: syntax error in main function');
    assert.strictEqual(debugIntent1.intentType, 'CODE_DEBUG');

    const debugIntent2 = IntentClassifier.analyze('fix this code: Cannot read property of undefined');
    assert.strictEqual(debugIntent2.intentType, 'CODE_DEBUG');

    const appIntent = IntentClassifier.analyze('write an app for expense tracking');
    assert.strictEqual(appIntent.intentType, 'APP_GENERATION');

    const webIntent = IntentClassifier.analyze('create website for artisan bakery');
    assert.strictEqual(webIntent.intentType, 'WEBSITE_GENERATION');
  });

  return { passed, failed };
}

if (process.argv[1]?.includes('filmStudioAndUpgrade.test.ts')) {
  runFilmStudioAndUpgradeTests().then((res) => {
    console.log(`\nFilm Studio & Upgrade Tests Complete: ${res.passed} passed, ${res.failed} failed.`);
    process.exit(res.failed > 0 ? 1 : 0);
  });
}
