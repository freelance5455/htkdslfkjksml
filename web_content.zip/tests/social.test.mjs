import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createSocial} from '../server/social.mjs';

const samplePng='data:image/png;base64,'+Buffer.from('89504e470d0a1a0a00000000','hex').toString('base64');
async function call(app,path,method='GET',session='',body){const headers={};if(session)headers['X-Jazzy-Session']=session;if(body!==undefined)headers['Content-Type']='application/json';const r=await app.handle(new Request('https://backend.local'+path,{method,headers,body:body===undefined?undefined:JSON.stringify(body)}),'test');return {status:r.status,body:r.headers.get('content-type')?.startsWith('application/json')?await r.json():await r.arrayBuffer()};}
const password='samplePassword_12345';
async function createUser(app,username,name=username){const r=await call(app,'/v3/auth/register','POST','',{username,name,password});assert.equal(r.status,201,JSON.stringify(r.body));return r.body;}

test('registration, authentication, public profiles, follows, posts, tags and messages',async()=>{
 const app=createSocial();try{
  const anna=await createUser(app,'anna1','Anna'),ben=await createUser(app,'ben22','Ben');
  assert.equal((await call(app,'/health')).body.protocol,3);
  assert.equal((await call(app,'/v3/me')).status,401);
  assert.equal((await call(app,'/v3/auth/register','POST','',{username:'anna1',name:'Duplicate',password})).status,409);
  assert.equal((await call(app,'/v3/auth/login','POST','',{username:'anna1',password:'wrongpassword'})).status,401);
  assert.equal((await call(app,'/v3/auth/login','POST','',{username:'anna1',password})).status,200);
  assert.equal((await call(app,'/v3/users?q=ann','GET',ben.session)).body.users.length,1);
  assert.equal((await call(app,'/v3/me','PATCH',anna.session,{name:'Anna New',bio:'Testing profile',private:true})).status,200);
  assert.equal((await call(app,'/v3/users/anna1/follow','POST',ben.session)).body.user.followStatus,'pending');
  assert.equal((await call(app,'/v3/follow-requests','GET',anna.session)).body.users.length,1);
  assert.equal((await call(app,'/v3/messages/anna1','POST',ben.session,{body:'hello'})).status,403);
  const post=(await call(app,'/v3/posts','POST',anna.session,{caption:'hello #jazzy #weekend',image:samplePng}));assert.equal(post.status,201);const id=post.body.post.id;
  assert.equal((await call(app,'/v3/posts/'+id,'GET',ben.session)).status,404,'pending follower cannot view private post');
  assert.equal((await call(app,'/v3/media/'+id,'GET',ben.session)).status,404,'private media is gated');
  assert.equal((await call(app,'/v3/follow-requests/'+ben.user.id,'POST',anna.session)).status,200);
  assert.equal((await call(app,'/v3/posts/'+id,'GET',ben.session)).status,200);
  assert.equal((await call(app,'/v3/media/'+id,'GET',ben.session)).status,200);
  assert.equal((await call(app,'/v3/tags?q=jaz','GET',ben.session)).body.tags[0].tag,'jazzy');
  assert.equal((await call(app,'/v3/tags/jazzy','GET',ben.session)).body.posts.length,1);
  assert.equal((await call(app,'/v3/posts/'+id+'/like','POST',ben.session)).body.post.likes,1);
  assert.equal((await call(app,'/v3/posts/'+id+'/save','POST',ben.session)).body.post.saved,true);
  assert.equal((await call(app,'/v3/saved','GET',ben.session)).body.posts.length,1);
  assert.equal((await call(app,'/v3/posts/'+id+'/comments','POST',ben.session,{body:'nice!'})).status,201);
  assert.equal((await call(app,'/v3/posts/'+id+'/comments','GET',anna.session)).body.comments.length,1);
  assert.equal((await call(app,'/v3/posts/'+id,'DELETE',ben.session)).status,403);
  assert.equal((await call(app,'/v3/users/ben22/follow','POST',anna.session)).body.user.followStatus,'accepted');
  assert.equal((await call(app,'/v3/messages/anna1','POST',ben.session,{body:'hello'})).status,201);
  assert.equal((await call(app,'/v3/messages/ben22','GET',anna.session)).body.messages.length,1);
  assert.equal((await call(app,'/v3/inbox','GET',anna.session)).body.conversations.length,1);
  assert.equal((await call(app,'/v3/posts/'+id,'DELETE',anna.session)).status,200);
  assert.equal((await call(app,'/v3/saved','GET',ben.session)).body.posts.length,0);
  assert.equal((await call(app,'/v3/auth/logout','POST',ben.session)).status,200);
  assert.equal((await call(app,'/v3/me','GET',ben.session)).status,401);
 }finally{app.close();}
});

test('persistent SQLite file retains accounts/posts and access controls',async()=>{
 const tmp=mkdtempSync(join(tmpdir(),'jazzy-test-')),file=join(tmp,'jazzy.sqlite');let token;
 try{
  let app=createSocial({database:file});
  const u=await createUser(app,'persist_user','Persistent');token=u.session;
  const r=await call(app,'/v3/posts','POST',token,{caption:'Saved after restart #keep'});assert.equal(r.status,201);app.close();
  app=createSocial({database:file});try{assert.equal((await call(app,'/v3/me','GET',token)).body.username,'persist_user');assert.equal((await call(app,'/v3/feed','GET',token)).body.posts.length,1);}finally{app.close();}
 }finally{rmSync(tmp,{recursive:true,force:true});}
});

test('account deletion cascades to posts, messages, followers',async()=>{
 const app=createSocial();try{
  const a=await createUser(app,'delete_me'),b=await createUser(app,'watching');
  await call(app,'/v3/users/delete_me/follow','POST',b.session);
  await call(app,'/v3/posts','POST',a.session,{caption:'hi'});
  assert.equal((await call(app,'/v3/me','DELETE',a.session,{password})).status,200);
  assert.equal((await call(app,'/v3/me','GET',a.session)).status,401);
  assert.equal((await call(app,'/v3/feed','GET',b.session)).body.posts.length,0);
 }finally{app.close();}
});

test('blocking prevents profiles, following, posts and direct messages',async()=>{
 const app=createSocial();try{
  const a=await createUser(app,'blocked_user'),b=await createUser(app,'blocker_user');
  await call(app,'/v3/users/blocker_user/follow','POST',a.session);
  await call(app,'/v3/users/blocked_user/follow','POST',b.session);
  const post=(await call(app,'/v3/posts','POST',a.session,{caption:'public test'})).body.post;
  assert.equal((await call(app,'/v3/messages/blocked_user','POST',b.session,{body:'hello'})).status,201);
  assert.equal((await call(app,'/v3/users/blocked_user/block','POST',b.session)).status,200);
  assert.equal((await call(app,'/v3/messages/blocked_user','POST',b.session,{body:'hello again'})).status,404);
  assert.equal((await call(app,'/v3/posts/'+post.id,'GET',b.session)).status,404);
  assert.equal((await call(app,'/v3/users/blocked_user','GET',b.session)).status,404);
  assert.equal((await call(app,'/v3/blocked','GET',b.session)).body.users.length,1);
  assert.equal((await call(app,'/v3/users/blocked_user/block','DELETE',b.session)).status,200);
 }finally{app.close();}
});
