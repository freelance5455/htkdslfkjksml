/* Test herního jádra v Node:  node tests/test_systems.js */
global.window = global;
global.btoa = s => Buffer.from(s, 'binary').toString('base64');
global.atob = s => Buffer.from(s, 'base64').toString('binary');
const path = require('path'), root = path.join(__dirname, '..', 'js');
['core/bd.js','data/ammo.js','data/towers/base.js','data/towers/normal.js','data/towers/burst.js','data/towers/ghost.js','data/towers/boost.js',
 'systems/grid.js','systems/towers.js','systems/enemies.js','systems/projectiles.js','systems/waves.js','systems/levels.js','systems/game.js','data/cards.js','systems/cards.js','data/presets.js','data/story.js']
  .forEach(f => require(path.join(root, f)));
const assert = require('assert'); const S = BD.systems, G = S.grid;
let ok = 0; const t = (n, fn) => { try { fn(); ok++; console.log('OK  ', n); } catch (e) { console.log('FAIL', n, '\n    ', e.stack.split('\n').slice(0, 3).join('\n     ')); process.exitCode = 1; } };
/* pole 10×10 věží = 20×20 buněk; vstup vlevo, cíl vpravo (buňky y 8..11), jedna skála */
const gate = (side, pos, len) => ({ side, pos, len });
const L = { name: 't', w: 10, h: 10, spawns: [gate('L', 8, 4)], exit: gate('R', 8, 4), rocks: [[2, 4]], walls: [] };
const mk = (o) => { const g = new S.Game(Object.assign({}, L, o || {})); g.gold = 1e6; return g; };
const E = () => S.enemies; const T = () => S.towers;
const settle = (g, max = 60 * 400) => { for (let i = 0; i < max && !(g.streams.length === 0 && g.enemies.length === 0) && !g.gameOver; i++) g.step(1 / 30); };

t('jemná mřížka: 10×10 věží = 20×20 buněk, věž má velikost 2 buňky', () => {
  const g = mk(); assert.strictEqual(g.w, 20); assert.strictEqual(g.h, 20); assert.strictEqual(g.sub, 2);
  assert.strictEqual(g.place('normal', 5, 5).size, 2);
});
t('věž lze posunout o půl věže (liché buňky) a nepřekrývá se s jinou', () => {
  const g = mk(); assert(g.place('normal', 4, 4)); assert(g.place('normal', 5, 6) && g.towerAt(5, 6), 'o 1 buňku vedle/pod jde');
  assert(!g.place('normal', 5, 5), 'překryv');
});
t('nepřátelé standardně jdou zleva doprava: brány jsou mimo pole', () => {
  const g = mk(); E().spawn(g, 'bub'); const e = g.enemies[0];
  assert(e.x < 0 && e.dx === 1 && e.dy === 0, 'začíná vlevo mimo pole a míří dovnitř');
  const p = g.previewPath(0); assert(p[0][0] === -1 && p[p.length - 1][0] === 20, 'cesta končí v bráně vpravo mimo pole');
});
t('zeď z věží přes celé pole nejde dokončit (cesta se nesmí zablokovat)', () => {
  const g = mk(); let placed = 0;
  for (let y = 0; y < 20; y += 2) if (g.place('normal', 10, y)) placed++;
  assert.strictEqual(placed, 9, 'poslední věž, která by uzavřela cestu, se odmítne');
});
t('nepřítel dojde do cíle ven z pole a ubere život', () => {
  const g = mk(); g.startWave(); settle(g); assert(g.lives < 20 && g.enemies.length === 0);
});
t('level s waves=3 skončí výhrou a pošle události', () => {
  const g = mk({ waves: 3 });
  for (let x = 2; x < 18; x += 2) for (const y of [4, 14]) g.place('normal', x, y);
  let cleared = 0, won = 0; g.on('waveCleared', () => cleared++).on('won', () => won++);
  for (let w = 0; w < 3; w++) { g.startWave(); settle(g); }
  assert.strictEqual(cleared, 3); assert.strictEqual(won, 1); assert(g.won && !g.gameOver);
  assert(!g.startWave(), 'po výhře další vlna nejde');
});
t('serialize → restore zachová věže, vylepšení, zlato, vlnu a cestu', () => {
  const g = mk();
  for (let x = 0; x < 12; x += 2) g.place('normal', x, 0);
  const a = g.place('boost', 14, 14); assert(g.upgrade(a, 'boost_a'));
  g.wave = 5; g.lives = 13;
  const snap = JSON.parse(JSON.stringify(g.serialize()));
  const h = new S.Game(L); assert(h.restore(snap));
  assert.strictEqual(h.towers.length, 7); assert.strictEqual(h.wave, 5); assert.strictEqual(h.lives, 13);
  assert.strictEqual(h.pathLen(0), g.pathLen(0));
  const f = h.towerAt(14, 14); assert(f && f.type === 'boost_a');
  assert(h.sellValue(f) === Math.floor(f.invested * 0.7), 'po obnově není prodej zdarma');
});
t('restore odmítne starý formát (v1) a přežije poškozená data', () => {
  const h = new S.Game(L);
  assert(!h.restore(null)); assert(!h.restore({})); assert(!h.restore({ v: 1, towers: [] }), 'stará hrubá mřížka');
  assert(h.restore({ towers: [{ type: 'nesmysl' }, { type: 'normal', x: 99, y: 99 }, { type: 'normal', x: 2, y: 4 }, null, { type: 'normal', x: 1, y: 1, level: 99, tier: 99 }, { type: 'normal', branch: 'b', x: 6, y: 6 }], wave: 'x', gold: NaN }));
  assert(h.towers.length <= 2 && h.towers.some(w => w.type === 'normal_b'), 'skála a mimo plochu se přeskočí; starý postup (kategorie + větev) se převede na samostatnou věž');
  assert(Number.isFinite(h.gold));
});
t('sloučení je zatím vypnuté (patří do kapitoly Kombinace)', () => {
  const g = mk();
  for (const [x, y] of [[3, 3], [5, 3], [3, 5], [5, 5]]) g.place('normal_a', x, y);
  assert(!g.findMerge(g.towerAt(3, 3)) && !g.merge(g.towerAt(3, 3)));
});
t('životy: ztráta na nule vyvolá lost', () => {
  const g = mk({ lives: 2 }); let lost = 0, lp = 0; g.on('lost', () => lost++).on('lifeLost', n => lp += n);
  g.startWave(); for (let i = 0; i < 60 * 100 && !g.gameOver; i++) g.step(1 / 30);
  assert(g.gameOver && lost === 1 && lp >= 2);
});
t('kód levelu BD2 round-trip (i zdi) a starý BD1 se převede', () => {
  const w = Object.assign({}, L, { walls: [[5, 5], [5, 6]] });
  const r = S.levels.decode(S.levels.encode(w)); assert(r.ok && r.level.rocks.length === 1 && r.level.walls.length === 2);
  const old = 'BD1:' + btoa(unescape(encodeURIComponent(JSON.stringify({ n: 'x', w: 8, h: 10, s: [[3, 0]], e: [4, 9], r: [[1, 3]] }))));
  const o = S.levels.decode(old); assert(o.ok && o.level.rocks.length === 4 && o.level.spawns[0].side === 'T' && o.level.exit.side === 'B');
});
t('validace levelu: rozměr 4–32, max 8 vstupů, brána jen na okraji, překryv, zablokovaná cesta', () => {
  const V = S.levels.validate;
  assert(V(Object.assign({}, L, { w: 32, h: 32 })).ok); assert(!V(Object.assign({}, L, { w: 33 })).ok); assert(!V(Object.assign({}, L, { h: 3 })).ok);
  const many = n => Array.from({ length: n }, (_, i) => gate('T', i * 2, 1));
  assert(V(Object.assign({}, L, { spawns: many(8) })).ok, '8 vstupů je v pořádku'); assert(!V(Object.assign({}, L, { spawns: many(9) })).ok, '9 už ne');
  assert(!V(Object.assign({}, L, { spawns: [gate('L', 18, 4)] })).ok, 'brána přesahuje okraj');
  assert(!V(Object.assign({}, L, { spawns: [gate('L', 8, 4)], exit: gate('L', 10, 4) })).ok, 'překryv bran');
  const wall = []; for (let y = 0; y < 20; y++) wall.push([10, y]);
  assert(!V(Object.assign({}, L, { walls: wall })).ok, 'zeď přes celé pole zavře cestu');
  wall.pop(); assert(V(Object.assign({}, L, { walls: wall })).ok, 's mezerou je to v pořádku');
});
t('brány na všech stranách: nepřátelé dojdou i shora dolů a zespodu nahoru', () => {
  for (const [a, b] of [['T', 'B'], ['B', 'T'], ['R', 'L']]) {
    const g = mk({ spawns: [gate(a, 8, 4)], exit: gate(b, 8, 4), lives: 3 });
    g.startWave(); settle(g); assert(g.lives < 3, a + '→' + b);
  }
});
t('víc vstupů: nepřátelé se střídají mezi branami', () => {
  const g = mk({ spawns: [gate('L', 2, 2), gate('L', 14, 2), gate('T', 4, 2)] });
  for (let i = 0; i < 6; i++) E().spawn(g, 'bub');
  const sides = new Set(g.enemies.map(e => (e.x < 0 ? 'L' : 'T'))); assert(sides.has('L') && sides.has('T'));
});
t('stavba před bránou, která by ji uzavřela, se odmítne', () => {
  const g = mk(); assert(g.place('normal', 0, 8), 'věž před bránou 4 buňky široké, ještě zbývá průchod');
  const c = g.canPlace('normal', 0, 10); assert(!c.ok && /cestu/i.test(c.reason), 'druhá by zavřela celou bránu: ' + c.reason);
});
t('nepřátelé jsou menší než ulička (r < 0,5 buňky)', () => {
  Object.keys(E().TYPES).forEach(k => assert(E().TYPES[k].r < 0.5, k));
});

t('vylepšení: jen na dítě ve stromě, platí se cena dítěte, je nevratné', () => {
  const g = mk(), a = g.place('normal', 1, 1); const gold = g.gold;
  assert(!g.upgrade(a), 'bez volby nejde'); assert(!g.upgrade(a, 'zzz'), 'neexistující věž'); assert(!g.upgrade(a, 'burst_a'), 'cizí věž (není dítě)');
  assert(g.upgrade(a, 'normal_b') && a.type === 'normal_b'); assert.strictEqual(gold - g.gold, S.towers.TYPES.normal_b.cost);
  assert(!g.upgrade(a, 'normal_c'), 'z hotového vylepšení už nejde zpět do sourozence'); assert(S.towers.upgradeCost(a) === null, 'list stromu nemá další vylepšení');
});
t('strom: každá věž kromě základny má rodiče, který existuje, a nevzniká cyklus', () => {
  const T = S.towers.TYPES; Object.keys(T).forEach(k => { const d = T[k]; if (k === 'base') return assert(d.parent === ''); assert(T[d.parent], k + ' má rodiče'); let n = 0, c = d; while (c.parent && n++ < 20) c = T[c.parent]; assert(c.id === 'base', k + ' vede až k základně'); });
  assert.strictEqual(S.towers.children('normal').length, 3); assert.strictEqual(S.towers.categories().length, 4); assert.strictEqual(S.towers.rootKind('boost_c'), 'boost');
});
t('hodnoty úrovně 1 odpovídají zadání (18/35/20/40 zlata, 15/10/20 dmg)', () => {
  const T = S.towers.TYPES;
  assert.deepStrictEqual([T.normal.cost, T.burst.cost, T.ghost.cost, T.boost.cost], [18, 35, 20, 40]);
  assert.deepStrictEqual([T.normal.base.dmg, T.burst.base.dmg, T.ghost.base.dmg, T.boost.base.boost], [15, 10, 20, 1.25]);
});
t('dosah věže je v buňkách (2,3 věže = 4,6 buňky)', () => {
  const g = mk(), a = g.place('normal', 4, 4); assert(Math.abs(a.s.range - 4.6) < 1e-9, a.s.range);
});
t('zesilovač zvyšuje poškození jen dotýkajícím se věžím', () => {
  const g = mk(), a = g.place('normal', 2, 10), b = g.place('normal', 12, 2);
  const before = a.s.dmg; assert.strictEqual(a.boost, 1);
  g.place('boost', 4, 10);
  assert(Math.abs(a.boost - 1.25) < 1e-9, 'sousední zesílena'); assert.strictEqual(b.boost, 1);
  g.sell(g.towerAt(4, 10)); assert.strictEqual(a.boost, 1, 'po prodeji zesílení zmizí');
  assert.strictEqual(a.s.dmg, before);
});
t('duchové: Výbuch je nezasáhne, Proti duchům střílí jen na ně, Základní zasáhne oba', () => {
  const run = type => {
    const g = mk(); g.place(type, 9, 6);
    E().spawn(g, 'ghost'); E().spawn(g, 'bub');
    const [gh, bu] = g.enemies; gh.x = bu.x = 10.5; gh.y = bu.y = 9.5; gh.tx = bu.tx = 10; gh.ty = bu.ty = 9;
    const hp = [gh.hp, bu.hp]; for (let i = 0; i < 60; i++) g.step(1 / 30);
    return [gh.hp < hp[0] || !gh.alive, bu.hp < hp[1] || !bu.alive];
  };
  assert.deepStrictEqual(run('burst'), [false, true]); assert.deepStrictEqual(run('ghost'), [true, false]); assert.deepStrictEqual(run('normal'), [true, true]);
});
t('základna → druh → jeho vylepšení; základna už střílí (slabě)', () => {
  const g = mk(), b = g.place('base', 8, 5);
  assert(b.type === 'base' && b.level === 0 && b.s.dmg === 6 && b.s.range > 0 && b.s.cd > 0);
  assert(!g.upgrade(b, 'zzz') && !g.upgrade(b, 'base') && !g.upgrade(b, 'burst_a'), 'neplatná volba');
  const gold = g.gold; assert(g.upgrade(b, 'burst') && b.type === 'burst' && b.level === 1 && gold - g.gold === 35);
  assert(g.upgrade(b, 'burst_a') && b.type === 'burst_a');
  const h = new S.Game(L); h.gold = 1e6; h.restore(JSON.parse(JSON.stringify(g.serialize())));
  assert(h.towerAt(8, 5).type === 'burst_a');
  const g2 = mk(), c = g2.place('base', 6, 6); assert.strictEqual(g2.sellValue(c), c.invested, 'čerstvá základna se prodá zdarma');
});

/* ---------- body 1–4, 7: brány s mezerou, cíl jako koule, pravidla levelu, předpostavené věže ---------- */
t('brány se nesmí dotýkat (mezera aspoň 1 buňka), vstup–cíl i vstup–vstup', () => {
  const V = S.levels.validate;
  assert(V(Object.assign({}, L, { spawns: [gate('L', 8, 4)], exit: gate('R', 8, 4) })).ok);
  assert(!V(Object.assign({}, L, { spawns: [gate('T', 2, 3), gate('T', 5, 2)] })).ok, 'vstupy těsně vedle sebe');
  assert(V(Object.assign({}, L, { spawns: [gate('T', 2, 3), gate('T', 6, 2)] })).ok, 's jednou buňkou mezery to jde');
  const r = V(Object.assign({}, L, { spawns: [gate('R', 2, 4)], exit: gate('R', 6, 4) })); assert(!r.ok && /dotýkaj/.test(r.error), r.error);
  assert(V(Object.assign({}, L, { spawns: [gate('R', 2, 4)], exit: gate('R', 7, 4) })).ok);
});
t('cíl jako koule uvnitř pole: bubliny dojdou, věž na kouli nejde, cesta se nesmí zavřít', () => {
  const orb = { orb: [[15, 9], [16, 9], [15, 10], [16, 10]] };
  const g = mk({ exit: orb }); assert(g.exitIsOrb && g.orb.reduce((a, b) => a + b, 0) === 4);
  assert(!g.canPlace('normal', 15, 9).ok, 'na kouli nejde stavět');
  assert(g.pathLen(0) > 0, 'cesta ke kouli existuje');
  g.startWave(); settle(g); assert(g.lives < 20, 'bublina vběhne do koule a ubere život');
  const h = mk({ exit: orb, rocks: [], walls: [] }); let n = 0;
  for (let y = 7; y < 13; y += 2) for (const x of [13, 17]) if (h.place('normal', x, y)) n++;
  for (const x of [13, 15, 17]) { h.place('normal', x, 7); h.place('normal', x, 11); }
  const open = h.spawnCells[0].every(c => h.dist[h.idx(c[0], c[1])] >= 0); assert(open, 'koule zůstane dosažitelná');
});
t('koule smaže skály a zdi pod sebou a nesmí sousedit se vstupem', () => {
  const V = S.levels.validate, n = S.levels.normalize;
  const o = n(Object.assign({}, L, { exit: { orb: [[5, 5], [6, 5]] }, rocks: [[5, 5], [8, 8]], walls: [[6, 5], [9, 9]] }));
  assert.strictEqual(o.rocks.length, 1); assert.strictEqual(o.walls.length, 1);
  assert(!V(Object.assign({}, L, { spawns: [gate('L', 8, 4)], exit: { orb: [[0, 9]] } })).ok, 'koule u brány vstupu');
  assert(V(Object.assign({}, L, { spawns: [gate('L', 8, 4)], exit: { orb: [[1, 9]] } })).ok, 'o buňku dál je to v pořádku');
  assert(!V(Object.assign({}, L, { exit: { orb: [[30, 30]] } })).ok, 'koule mimo pole');
});
t('pravidla levelu: životy, zlato, vlny, síla bublin, povolené věže', () => {
  const g = mk({ lives: 7, gold: 123, waves: 12, hp: 2, allowed: ['normal'] }); g.gold = 123;
  assert.strictEqual(g.lives, 7); assert.strictEqual(g.maxWaves, 12); assert.strictEqual(g.hpMul, 2);
  E().spawn(g, 'bub'); assert.strictEqual(g.enemies[0].maxhp, E().TYPES.bub.hp * 2 * E().hpScale(0));
  const t1 = g.place('base', 4, 4); assert(!g.upgrade(t1, 'ghost'), 'nepovolená kategorie'); assert(g.upgrade(t1, 'normal'), 'povolená kategorie');
  const V = S.levels.validate;
  assert(!V(Object.assign({}, L, { lives: 0 })).ok); assert(!V(Object.assign({}, L, { lives: 1000 })).ok); assert(!V(Object.assign({}, L, { gold: -5 })).ok);
  assert(V(Object.assign({}, L, { waves: 0, lives: 1, gold: 0, hp: 0.25 })).ok); assert(!V(Object.assign({}, L, { hp: 9 })).ok);
});
t('předpostavené věže: stojí od začátku zdarma, snapshot je nezdvojí, zavřená cesta se odmítne', () => {
  const lv = Object.assign({}, L, { towers: [{ type: 'normal', x: 4, y: 4 }, { type: 'base', x: 8, y: 4 }], gold: 50 });
  const g = new S.Game(lv); assert.strictEqual(g.towers.length, 2); assert.strictEqual(g.gold, 50);
  assert.strictEqual(g.towers[0].level, 1); assert.strictEqual(g.towers[1].level, 0);
  assert.strictEqual(g.sellValue(g.towers[0]), 0, 'zdarma postavená věž nevrací zlato');
  assert(!g.place('normal', 4, 4), 'na předpostavenou věž nejde stavět');
  const snap = JSON.parse(JSON.stringify(g.serialize())); const h = new S.Game(lv); assert(h.restore(snap)); assert.strictEqual(h.towers.length, 2, 'obnova nezdvojí věže');
  const wall = []; for (let y = 0; y < 20; y += 2) wall.push({ type: 'base', x: 10, y });
  assert(!S.levels.validate(Object.assign({}, L, { towers: wall })).ok, 'věže přes celé pole zavírají cestu');
  assert(!S.levels.validate(Object.assign({}, L, { towers: [{ type: 'base', x: 2, y: 4 }] })).ok, 'věž na skále');
});
t('kód BD2 zachová koule, skupiny skal, pravidla a předpostavené věže', () => {
  const lv = Object.assign({}, L, { exit: { orb: [[15, 9], [16, 9]] }, rocks: [[2, 4, 3], [3, 4, 3], [8, 8]], lives: 9, gold: 70, waves: 15, hp: 1.5, allowed: ['normal', 'boost'], towers: [{ type: 'boost', x: 6, y: 6 }] });
  const r = S.levels.decode(S.levels.encode(lv)); assert(r.ok, r.error);
  assert.deepStrictEqual(r.level.exit, lv.exit); assert.deepStrictEqual(r.level.rocks, lv.rocks);
  assert.deepStrictEqual([r.level.lives, r.level.gold, r.level.waves, r.level.hp, r.level.allowed, r.level.towers], [9, 70, 15, 1.5, ['normal', 'boost'], lv.towers]);
});
t('skupiny skal: souvislá skála se slije, samostatné kamínky ne; koule ve skupinách', () => {
  const F = { rockRects: null };
  const G2 = S.grid;
  const blobs = G2.orbBlobs([[1, 1], [2, 1], [5, 5]]); assert.strictEqual(blobs.length, 2); assert(blobs.every(b => b.r >= 0.62));
  assert.strictEqual(blobs.filter(b => b.cells.length === 2).length, 1);
});
t('všechny předpřipravené mapy i story levely jsou platné i s pravidlem o mezerách', () => {
  BD.data.presets.forEach(p => { const v = S.levels.validate(p); assert(v.ok, p.name + ': ' + v.error); });
  const st = BD.data.story; const lvls = [].concat(st.nodes || st.NODES || []).map(n => n.level).filter(Boolean);
  lvls.forEach(l => { const v = S.levels.validate(l); assert(v.ok, l.name + ': ' + v.error); });
  assert(lvls.length > 3, 'story má levely: ' + lvls.length);
});

t('pás vln: auto-vypouštění po startu, vlny se překrývají a jedou samy', () => {
  const g = mk({ waves: 12, gap: 20 }); assert.strictEqual(g.wave, 0); g.run();
  for (let i = 0; i < 30 * 9; i++) g.step(1 / 30);
  assert.strictEqual(g.wave, 1, 'první vlna po 8 s');
  for (let i = 0; i < 30 * 40; i++) g.step(1 / 30);
  assert.strictEqual(g.wave, 3, 'další po odstupu 20 s, bez zásahu hráče');
});
t('pás vln: belt() vrací eta, boss a součet zdraví', () => {
  const g = mk({ waves: 12 }); const b = g.belt(6);
  assert.strictEqual(b.length, 6); assert.strictEqual(b[0].wave, 1); assert(b[1].eta - b[0].eta === g.gap);
  const bb = S.waves.info(10); assert(bb.boss && bb.hp > 0 && bb.count > 1);
  assert.strictEqual(g.belt(20).length, 12, 'nejvýš do počtu vln');
});
t('pás vln: callWaves(k) vypustí k vln s malým odstupem', () => {
  const g = mk({ waves: 12 }); assert.strictEqual(g.callWaves(5), 5); assert.strictEqual(g.wave, 5);
  const ts = g.streams.map(s => s.t); assert(ts.every((x, i) => i === 0 || x > ts[i - 1]), 'odstup mezi vlnami');
  assert(g.running);
});
t('pravidlo gap se uloží do kódu levelu', () => {
  const lv = Object.assign({}, L, { gap: 45, waves: 15 }); const c = S.levels.decode(S.levels.encode(lv));
  assert(c.ok && c.level.gap === 45);
});

t('základna střílí na bubliny v dosahu, ale ne na duchy', () => {
  const g = mk({ rocks: [] }); const b = g.place('base', 8, 8);
  E().spawn(g, 'bub'); const e = g.enemies[0]; e.x = b.x + 2; e.y = b.y + 1; e.tx = Math.floor(e.x); e.ty = Math.floor(e.y); const hp0 = e.hp;
  for (let i = 0; i < 60; i++) g.step(1 / 30);
  assert(e.hp < hp0 || !e.alive, 'základna zasáhla bublinu');
  const g2 = mk({ rocks: [] }); const b2 = g2.place('base', 8, 8); E().spawn(g2, 'ghost'); const gh = g2.enemies[0]; gh.x = b2.x + 2; gh.y = b2.y + 1; gh.tx = Math.floor(gh.x); gh.ty = Math.floor(gh.y); const h2 = gh.hp;
  for (let i = 0; i < 20; i++) g2.step(1 / 30);
  assert.strictEqual(gh.hp, h2, 'ducha základna nezasáhne');
});
t('story: další level po cestě; na rozcestí náhodný, finále čeká na všechny větve', () => {
  const st = BD.data.story;
  assert.strictEqual(st.pickNext('t1', ['t1'], () => 0).id, 'l2');
  const seen = new Set(); for (let i = 0; i < 30; i++) seen.add(st.pickNext('l2', ['t1', 'l2']).id);
  assert.deepStrictEqual([...seen].sort(), ['a1', 'b1', 'c1'], 'rozcestí: všechny tři větve se můžou vybrat');
  assert.strictEqual(st.pickNext('a1', ['t1', 'l2', 'a1'], () => 0).id, 'a2', 'v koridoru jde další uzel');
  const o = st.pickNext('a3', ['t1', 'l2', 'a1', 'a2', 'a3']); assert(o && ['b1', 'c1'].includes(o.id), 'finále ještě čeká → jiná otevřená větev');
  assert.strictEqual(st.pickNext('a3', ['t1', 'l2', 'a1', 'a2', 'a3', 'b1', 'b2', 'b3', 'c1', 'c2', 'c3'], () => 0).id, 'f1');
  assert.strictEqual(st.pickNext('f1', st.nodes.map(n => n.id)), null, 'po finále není kam');
});

t('karty: za šéfa vždy padne karta, bez rewards ne', () => {
  const g = mk(); g.rewards = true; E().spawn(g, 'boss', 10); g.kill(g.enemies[0]);
  assert.strictEqual(g.cards.length, 1); assert(BD.data.cards.list[g.cards[0]]);
  const h = mk(); h.rewards = false; E().spawn(h, 'boss', 10); h.kill(h.enemies[0]); assert.strictEqual(h.cards.length, 0);
});
t('karty: bezchybná vlna dá kartu podle šance, vlna s prošlou bublinou ne', () => {
  const g = mk({ waves: 5, lives: 99 }); g.rnd = () => 0.01;
  E().spawn(g, 'bub', 1); g.waveLeft[1] = 1; g.kill(g.enemies[0]);
  assert.strictEqual(g.cards.length, 1, 'bezchybná vlna');
  const h = mk({ waves: 5, lives: 99 }); h.rnd = () => 0.01;
  E().spawn(h, 'bub', 1); E().spawn(h, 'bub', 1); h.waveLeft[1] = 2; h.leak(h.enemies[0]); h.kill(h.enemies[1]);
  assert.strictEqual(h.cards.length, 0, 'vlna s prošlou bublinou');
});
t('karty: Atomovka zničí všechny nepřátele a spotřebuje se', () => {
  const g = mk(); g.giveCard('atomic'); for (let i = 0; i < 6; i++) E().spawn(g, 'bub', 1);
  const gold = g.gold; assert.strictEqual(g.useCard(0), 'atomic');
  assert(g.enemies.every(e => !e.alive), 'všichni mrtví'); assert.strictEqual(g.cards.length, 0); assert(g.gold > gold, 'odměna za zabití');
  assert.strictEqual(g.useCard(0), null, 'prázdná lišta');
});
t('karty: Meteorický roj zasáhne část nepřátel a šéfa jen poškodí', () => {
  const g = mk({ waves: 20, lives: 99 }); let k = 0; g.rnd = () => ((k++ * 0.37) % 1);
  g.giveCard('meteor'); for (let i = 0; i < 40; i++) { E().spawn(g, 'swarm', 1); const e = g.enemies[i]; e.x = 2 + (i % 18); e.y = 1 + (i % 17); e.speed = 0; }
  const boss = (E().spawn(g, 'boss', 1), g.enemies[g.enemies.length - 1]); boss.speed = 0; boss.x = 10.5; boss.y = 10.5;
  g.cardFx.push({ kind: 'meteor', x: 10.5, y: 10.5, delay: 0, fall: 0.45, t: 0, hit: false });          // jeden meteorit přesně na šéfa
  g.useCard(0); for (let i = 0; i < 90; i++) g.step(1 / 30);
  const alive = g.enemies.filter(e => e.alive && e.type !== 'boss').length;
  assert(alive < 40, 'meteority někoho zničily'); assert(boss.alive, 'šéf přežil'); assert(boss.hp < boss.maxhp, 'šéf je poškozený');
  assert.strictEqual(g.cardFx.length, 0, 'efekt doběhl');
});
t('karty: uložení a obnova zachová inventář, neznámé karty se zahodí', () => {
  const g = mk(); g.giveCard('atomic'); g.giveCard('meteor'); const s = g.serialize(); assert.deepStrictEqual(s.cards, ['atomic', 'meteor']);
  const h = mk(); s.cards.push('nesmysl'); h.restore(s); assert.deepStrictEqual(h.cards, ['atomic', 'meteor']);
});

t('duchové: letí skrz skály a věže přímo, zdi je obcházejí', () => {
  const col = (x, y0, y1) => { const a = []; for (let y = y0; y <= y1; y++) a.push([x, y]); return a; };
  const rocks = mk({ rocks: col(10, 0, 15), walls: [] }), walls = mk({ rocks: [], walls: col(10, 0, 15) });
  const at = (g) => { const c = g.spawnCenter(0); return [g.dist[g.idx(c[0], c[1])], g.distG[g.idx(c[0], c[1])]]; };
  const [bR, gR] = at(rocks), [bW, gW] = at(walls);
  assert(bR > gR + 8, 'bublina obchází skály, duch letí skrz: ' + bR + ' vs ' + gR);
  assert(bW >= gW, 'bublina nejde kratší cestou než duch');
  { const g = mk({ rocks: [], walls: col(10, 0, 17) }); E().spawn(g, 'ghost', 1); const e = g.enemies[0]; let inWall = 0, n = 0;
    while (e.alive && n++ < 3000) { g.step(1 / 30); if (g.wall[g.idx(Math.floor(e.x), Math.floor(e.y))]) inWall++; }
    assert.strictEqual(inWall, 0, 'duch nikdy neproletí zdí'); assert(g.lives < 20 || n < 3000, 'a přesto dorazil'); }
  const run = (g, type) => { E().spawn(g, type, 1); const e = g.enemies[0]; let n = 0; while (e.alive && g.lives === 20 && n++ < 6000) g.step(1 / 30); return n; };
  const a = run(mk({ rocks: col(10, 0, 15), walls: [], lives: 20 }), 'bub'), b = run(mk({ rocks: col(10, 0, 15), walls: [], lives: 20 }), 'ghost');
  assert(b < a, 'duch dorazí dřív než bublina přes skály: ' + b + ' vs ' + a);
});
t('duchové: věže jim nestojí v cestě (cesta se nemění), míří se podle jejich vzdálenosti', () => {
  const g = mk({ rocks: [], walls: [] }); const c = g.spawnCenter(0), before = g.distG[g.idx(c[0], c[1])];
  for (let y = 0; y < 18; y += 2) g.place('normal', 10, y);
  assert.strictEqual(g.distG[g.idx(c[0], c[1])], before, 'věže pole duchů nemění');
  E().spawn(g, 'ghost', 1);
  const ge = g.enemies[0]; ge.hp = 1e9; let mx = 0; for (let i = 0; i < 600 && ge.alive; i++) { g.step(1 / 30); mx = Math.max(mx, ge.x); }
  assert(mx > 18 && g.lives < 20, 'duch proletěl řadou věží až do cíle');
});
t('duchové: úhlopříčka neřeže roh zdi', () => {
  const g = mk({ rocks: [], walls: [[10, 9], [10, 10], [9, 10], [11, 9]] });
  for (let i = 0; i < g.distG.length; i++) if (g.distG[i] > 0) { const x = i % g.ew - 1, y = ((i / g.ew) | 0) - 1; assert(!g.wall[i], 'dosažitelná buňka není zeď ' + x + ',' + y); }
});

t('duchové: ve všech presetech a story levelech nikdy neproletí zdí (ani když se skála a zeď překrývají)', () => {
  const all = [].concat(Array.isArray(BD.data.presets) ? BD.data.presets : [], (BD.data.story.nodes || []).map(n => n.level).filter(Boolean));
  assert(all.length >= 10, 'levelů: ' + all.length); let samples = 0;
  all.forEach(Lv => {
    const g = new S.Game(JSON.parse(JSON.stringify(Lv))); g.lives = 999;
    for (let s = 0; s < g.spawnCells.length; s++) {
      g.spawnIdx = s; E().spawn(g, 'ghost', 1); const e = g.enemies[g.enemies.length - 1]; e.hp = e.maxhp = 1e9; let px = e.x, py = e.y;
      for (let i = 0; i < 4000 && e.alive; i++) {
        g.step(1 / 60); samples++;
        [[e.x, e.y], [(e.x + px) / 2, (e.y + py) / 2]].forEach(([x, y]) => { const cx = Math.floor(x), cy = Math.floor(y); assert(!(g.inb(cx, cy) && g.wall[g.idx(cx, cy)]), Lv.name + ': duch ve zdi ' + cx + ',' + cy); });
        px = e.x; py = e.y;
      }
    }
  });
  assert(samples > 1000);
});

const withType = (id, def, fn) => { const T0 = E().TYPES[id]; E().TYPES[id] = def; try { fn(); } finally { if (T0) E().TYPES[id] = T0; else delete E().TYPES[id]; } };
t('mechaniky: rozpad na menší – potomci jdou dál, vlna se počítá, rekurze je omezená', () => {
  withType('mini', { name: 'Mini', color: '#fff', hp: 5, speed: 1, reward: 1, r: 0.15, life: 1 }, () => withType('splt', { name: 'S', color: '#f0f', hp: 20, speed: 1, reward: 4, r: 0.3, life: 1, splitCount: 5, splitInto: 'mini' }, () => {
    const g = mk({ waves: 3, lives: 99 }); g.launchWave(0); g.streams = []; g.waveLeft = { 1: 1 };
    E().spawn(g, 'splt', 1); const p = g.enemies[0]; p.x = 6; p.y = 9.5; p.tx = 6; p.ty = 9; g.kill(p);
    const kids = g.enemies.filter(e => e.alive); assert.strictEqual(kids.length, 5); assert(kids.every(e => e.type === 'mini' && e.gen === 1));
    assert.strictEqual(g.waveLeft[1], 5, 'vlna čeká na všech 5');
    settle(g); assert.strictEqual(g.enemies.length, 0); assert(g.waveLeft[1] === undefined, 'vlna dokončena');
  }));
  withType('loop', { name: 'L', color: '#f0f', hp: 5, speed: 1, reward: 0, r: 0.3, life: 1, splitCount: 2, splitInto: 'loop' }, () => {
    const g = mk({ lives: 99 }); g.waveLeft = { 1: 1 }; E().spawn(g, 'loop', 1); g.kill(g.enemies[0]);
    for (let i = 0; i < 6; i++) g.enemies.filter(e => e.alive).forEach(e => g.kill(e));
    assert(g.enemies.filter(e => e.alive).length === 0, 'rozpad se po 3 generacích zastaví');
  });
});
t('mechaniky: odolnost snižuje poškození, regenerace léčí, odolnost proti zpomalení', () => {
  withType('tough', { name: 'T', color: '#888', hp: 100, speed: 0.1, reward: 1, r: 0.3, life: 1, resist: 0.5, regen: 10, slowImmune: true }, () => {
    const g = mk({ lives: 99 }); E().spawn(g, 'tough', 1); const e = g.enemies[0]; e.x = 5; e.y = 9.5; e.tx = 5; e.ty = 9; const hp0 = e.hp;
    g.shots.push({ x: 5, y: 9.5, target: e, lx: 5, ly: 9.5, dmg: 40, splash: 0, slow: 0.5, speed: 100, color: '#fff', big: 0 }); g.step(1 / 30);
    assert(Math.abs(hp0 - e.hp - 20) < 1.5, 'poškození ×0,5: ' + (hp0 - e.hp)); assert.strictEqual(e.slow, 0, 'zpomalení se neuchytí');
    const h1 = e.hp; for (let i = 0; i < 30; i++) g.step(1 / 30); assert(e.hp - h1 > 8, 'regenerace ~10/s');
  });
});
t('mechaniky: nepřítel útočí na věž, věž má životy, po zničení zmizí a cesta se přepočítá', () => {
  withType('biter', { name: 'B', color: '#c33', hp: 1e6, speed: 0.1, reward: 0, r: 0.3, life: 1, atkDmg: 40, atkRange: 1.5, atkCd: 0.5, atkStop: true }, () => {
    const g = mk({ lives: 99 }); const tw = g.place('normal', 6, 8); assert(tw && tw.hp === tw.s.hp && tw.hp > 0, 'věž má životy');
    E().spawn(g, 'biter', 1); const e = g.enemies[0]; e.x = 5.5; e.y = 9.5; e.tx = 5; e.ty = 9; let lost = 0; g.on('towerLost', () => lost++);
    g.step(1 / 30); assert(tw.hp < tw.s.hp, 'poškozená'); const x0 = e.x; g.step(1 / 30); assert.strictEqual(e.x, x0, 'při útoku stojí (atkStop)');
    for (let i = 0; i < 300 && g.towers.length; i++) g.step(1 / 30);
    assert.strictEqual(g.towers.length, 0, 'věž zničena'); assert.strictEqual(lost, 1);
  });
});
t('mechaniky věží: splash, slow a zaměřování z dat', () => {
  const N = BD.data.towers.normal, b0 = Object.assign({}, N.base);
  try {
    N.base.splash = 1; N.base.slow = 0.4; const g = mk(); const tw = g.place('normal', 6, 8);
        const s = T().stats(tw); assert(Math.abs(s.splash - 2) < 1e-9 && Math.abs(s.slow - 0.4) < 1e-9, JSON.stringify(s));
  } finally { Object.assign(N.base, b0); delete N.base.splash; delete N.base.slow; }
});
t('karty: atomovka nerozpadá nepřátele na menší', () => {
  withType('mini', { name: 'Mini', color: '#fff', hp: 5, speed: 1, reward: 1, r: 0.15, life: 1 }, () => withType('splt', { name: 'S', color: '#f0f', hp: 20, speed: 1, reward: 4, r: 0.3, life: 1, splitCount: 5, splitInto: 'mini' }, () => {
    const g = mk({ lives: 99 }); g.waveLeft = { 1: 3 }; for (let i = 0; i < 3; i++) E().spawn(g, 'splt', 1); g.giveCard('atomic'); g.useCard(0);
    assert.strictEqual(g.enemies.filter(e => e.alive).length, 0);
  }));
});

t('střelivo: násobek poškození a rychlosti, výstřel a dopad jako efekty, rovná střela může minout', () => {
  const A = BD.data.ammo, N = BD.data.towers.normal, a0 = N.ammo;
  A.tst = { name: 'T', color: '#fff', dmgMul: 3, flight: 'homing', speedMul: 2, muzzle: { dur: 0.2, size: 1, dist: 0.5, s0: 1, s1: 1, a0: 1, a1: 0, r0: 0, r1: 0, sprite: { v: 1, nodes: [] } },
    shot: { size: 0.3, spin: 0, trail: 0 }, impact: { dur: 0.4, size: 1, s0: 1, s1: 1, a0: 1, a1: 0, r0: 0, r1: 0, sprite: { v: 1, nodes: [] } } };
  try {
    N.ammo = 'tst'; const g = mk({ lives: 99 }); const tw = g.place('normal', 6, 8); const dm = T().stats(tw).dmg;
    E().spawn(g, 'bub', 1); const e = g.enemies[0]; e.x = 6.5; e.y = 6; e.tx = 6; e.ty = 6; tw.cool = 0; g.step(1 / 30);
    const sh = g.shots[0]; assert(sh, 'střela vznikla'); assert.strictEqual(sh.am, 'tst'); assert(Math.abs(sh.dmg - dm * 3) < 1e-6, 'dmgMul ×3');
    assert(Math.abs(sh.speed - T().stats(tw).speed * 2) < 1e-6, 'speedMul ×2');
    assert(g.fx.some(f => f.kind === 'ammo' && f.ph === 'muzzle'), 'výstřel');
    sh.x = sh.lx; sh.y = sh.ly; g.step(1 / 30); assert(g.fx.some(f => f.kind === 'ammo' && f.ph === 'impact'), 'dopad');
    N.ammo = 'nesmysl'; const g2 = mk({ lives: 99 }); const t2 = g2.place('normal', 6, 8); E().spawn(g2, 'bub', 1); const e2 = g2.enemies[0]; e2.x = 6.5; e2.y = 6; e2.tx = 6; e2.ty = 6; t2.cool = 0; g2.step(1 / 30);
    assert.strictEqual(g2.shots[0].am, 'default', 'neznámé střelivo = výchozí'); assert(!g2.fx.some(f => f.kind === 'ammo'), 'výchozí střela bez tvaru nic navíc nekreslí');
    A.tst.flight = 'straight'; const g3 = mk({ lives: 99 }); E().spawn(g3, 'bub', 1); const e3 = g3.enemies[0]; const hp = e3.hp; e3.x = 3; e3.y = 3;
    g3.shots.push({ x: 5, y: 5, target: e3, lx: 5, ly: 5, dmg: 10, splash: 0, slow: 0, speed: 100, color: '#fff', big: 0, am: 'tst', flight: 'straight', trail: [] }); g3.step(1 / 30);
    assert.strictEqual(e3.hp, hp, 'rovná střela mine cíl, který odešel');
  } finally { delete A.tst; if (a0 === undefined) delete N.ammo; else N.ammo = a0; }
});

console.log(ok + ' testů prošlo');
