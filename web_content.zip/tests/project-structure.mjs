import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';

const read = path => readFileSync(new URL('../' + path, import.meta.url), 'utf8');
const rootHtml = read('index.html');
const webHtml = read('www/index.html');
const main = read('www/js/main.js');
const data = read('www/js/data.js');
const css = read('www/css/style.css');
const pkg = JSON.parse(read('package.json'));
const cap = JSON.parse(read('capacitor.config.json'));

const required = [
  'index.html', 'src/main.js', 'vite.config.js', 'package.json', 'capacitor.config.json',
  'www/index.html', 'www/css/style.css', 'www/js/boot.js', 'www/js/main.js',
  'www/js/photo-analysis.js', 'www/js/data.js', 'www/js/engine.js', 'www/js/firebase.js',
  'www/js/sfx.js', 'www/sw.js', 'manifest.json', 'public/manifest.json', 'public/sw.js',
  'tests/smoke.mjs', 'tests/regression.mjs', 'firebase/README.md', 'firebase/database.rules.json'
];
for (const path of required) assert.ok(existsSync(new URL('../' + path, import.meta.url)), `missing project file: ${path}`);

assert.match(rootHtml, /src="\.\/src\/main\.js"/, 'root HTML must expose the expected APK entrypoint');
assert.match(rootHtml, /fotoduel-self-contained-style/, 'root HTML must embed CSS so builders cannot drop it');
assert.match(webHtml, /fotoduel-self-contained-style/, 'www HTML must embed CSS for Android WebView');
assert.match(rootHtml, /--bg:#080d1b/);
assert.match(webHtml, /--bg:#080d1b/);
// The inline stylesheet and the standalone file must stay byte-for-byte aligned.
const inlineCss = html => html.match(/<style id="fotoduel-self-contained-style">([\s\S]*?)<\/style>/i)?.[1]?.trim();
assert.equal(inlineCss(rootHtml), css.trim(), 'root inline CSS must match www/css/style.css exactly');
assert.equal(inlineCss(webHtml), css.trim(), 'www inline CSS must match www/css/style.css exactly');
assert.match(css, /^:root\{/m, 'stylesheet must begin with the root design variables');
assert.doesNotMatch(css, /^\s*600;700;|display=swap['"]\);/m, 'no fragment of the removed Google Fonts import may remain');
assert.match(read('src/main.js'), /\.\.\/www\/js\/boot\.js/, 'root entry must load the guarded bootstrap');
assert.match(read('www/js/boot.js'), /await import\('\.\/main\.js'\)/, 'bootstrap must load the original game modules');
assert.match(webHtml, /src="js\/boot\.js"/, 'Capacitor page must use the same startup guard');
assert.doesNotMatch(css, /@import\s+url\(/, 'CSS must not require remote font imports');

// All five photo selectors must be direct labels, not display:none inputs activated by input.click().
for (const [page, html] of [['root', rootHtml], ['www', webHtml]]) {
  for (const [inputId, labelId] of [
    ['gallery-input', 'gallery-pick'], ['camera-input', 'camera-take'],
    ['funny-camera', 'funny-camera-take'], ['profile-photo-input', 'profile-photo-pick'],
    ['welcome-avatar-input', 'welcome-avatar-pick']
  ]) {
    const label = new RegExp(`<label[^>]*id="${labelId}"[\\s\\S]*?<input[^>]*id="${inputId}"`, 'i');
    assert.match(html, label, `${page}: ${inputId} must sit directly inside its native label`);
    const inputTag = html.match(new RegExp(`<input[^>]*id="${inputId}"[^>]*>`, 'i'))?.[0] || '';
    assert.doesNotMatch(inputTag, /\shidden(?:\s|>)/i, `${page}: ${inputId} must not be display:none`);
  }
  assert.match(html, /id="welcome-screen"/);
  assert.match(html, /id="manual-card-values"/);
}
assert.doesNotMatch(main, /\$\(['"](?:gallery-input|camera-input|funny-camera|profile-photo-input|welcome-avatar-input)['"]\)\.click\(/, 'file picker must be activated by a real label tap');
assert.match(main, /analyzeImageData\(data\)/, 'photo selection must run pixel analysis');
assert.doesNotMatch(main, /imageAnalysis\(/, 'old fallback analysis must be removed');
assert.match(main, /Análise real dos pixels concluída/);
assert.match(main, /Modo manual/);
assert.doesNotMatch(read('www/js/photo-analysis.js'), /Math\.random/, 'photo analysis must be deterministic');
assert.match(read('www/js/photo-analysis.js'), /getImageData/);
assert.match(data, /profilePhoto:'',profileComplete:false/);
assert.equal(cap.webDir, 'dist', 'Capacitor must package the production Vite build');
assert.equal(pkg.scripts.build, 'vite build');
assert.match(pkg.scripts['android:sync'], /npm run build && npx cap sync android/);
assert.match(pkg.scripts['android:apk'], /npm run build && npx cap sync android/);

// Check that the HTML IDs used literally by main.js exist in the shipped www page.
const ids = new Set([...webHtml.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]));
const refs = new Set([...main.matchAll(/\$\(['"]([^'"]+)['"]\)/g)].map(match => match[1]));
const dynamicIds = new Set(['battle-result-open','detail-close','evolve-cancel','evolve-confirm','mode-cancel','mode-deck','mode-deck-2','mode-difficulty','mode-start','online-finish','result-home','result-next','result-rematch']);
for (const id of refs) assert.ok(ids.has(id) || dynamicIds.has(id), `main.js refers to missing static HTML id: ${id}`);

console.log(`FOTO DUEL structure tests: OK (${required.length} required files; inline CSS; native photo inputs; matched UI IDs)`);
