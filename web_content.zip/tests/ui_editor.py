"""Editor levelů, brány, koule cíle, pravidla a herní pole:  python3 -I tests/ui_editor.py"""
import glob, json
from playwright.sync_api import sync_playwright
exe = (glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome') or [None])[0]
SH = '/home/claude/BubbleDefence/tests/shots/'
errs, results = [], []
def check(n, c, x=''): results.append(bool(c)); print(('OK   ' if c else 'FAIL ') + n + (' ' + str(x) if x != '' else ''))
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=exe, args=['--no-sandbox'])
    pg = b.new_page(viewport={'width': 1280, 'height': 800})
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type in ('error', 'warning') else None)
    pg.goto('file:///home/claude/BubbleDefence/index.html'); pg.wait_for_selector('.content:not(.hidden) .intro')
    pg.click('text=Nová lokální hra'); pg.wait_for_selector('.content:not(.hidden) .menu'); pg.wait_for_timeout(300)
    pg.click('.mi:has-text("Editor")'); pg.click('.lcard.add'); pg.wait_for_selector('.edv .ed-cv'); pg.wait_for_timeout(300)
    lv = lambda: pg.evaluate("(()=>{const l=BD.store.profile.editor.levels[0]; return JSON.parse(JSON.stringify(l));})()")
    L0 = lv()
    cv = pg.locator('.ed-cv').bounding_box(); cell = cv['width'] / (L0['w'] * 2 + 2)
    def at(fx, fy): return (cv['x'] + (fx + 1) * cell, cv['y'] + (fy + 1) * cell)       # buňka pole -> pixely
    def drag(a, bb, button='left', steps=10):
        x1, y1 = at(*a); x2, y2 = at(*bb); pg.mouse.move(x1, y1); pg.mouse.down(button=button); pg.mouse.move(x2, y2, steps=steps); pg.mouse.up(button=button)
    def click(a, button='left'): x, y = at(*a); pg.mouse.click(x, y, button=button)
    def msg(): return pg.locator('.ed-tools > .msg.err').inner_text() if pg.locator('.ed-tools > .msg.err').count() else ''

    check('nový level: vstup vlevo, cíl vpravo, výchozí pravidla', L0['spawns'][0]['side'] == 'L' and L0['exit']['side'] == 'R' and L0.get('waves') == 20 and L0.get('lives') == 20 and L0.get('gold') == 100)

    # ---- 5. nástroje pod sebou + klávesové zkratky ----
    rows = pg.locator('.ed-toollist .trow'); n = rows.count(); boxes = [rows.nth(i).bounding_box() for i in range(n)]
    check('nástroje jsou pod sebou (stejné x, rostoucí y)', n == 6 and len({round(bx['x']) for bx in boxes}) == 1 and all(boxes[i]['y'] < boxes[i + 1]['y'] for i in range(n - 1)))
    keys = [rows.nth(i).locator('kbd').inner_text() for i in range(n)]
    check('u každého nástroje je napsaná zkratka', keys == ['S', 'Z', 'G', 'V', 'C', 'T'], keys)
    ok = True
    for k, t in [('s', 'rock'), ('z', 'wall'), ('g', 'erase'), ('v', 'spawn'), ('c', 'exit'), ('t', 'tower')]:
        pg.keyboard.press(k); ok = ok and pg.locator('.trow.on[data-tool=%s]' % t).count() == 1
    check('zkratky S Z G V C T přepínají nástroje', ok)
    pg.keyboard.press('s'); pg.keyboard.press('Digit2'); check('klávesa 2 = štětec 2×2', pg.locator('.seg button.on:has-text("2×2")').count() == 1)
    pg.keyboard.press('Digit1')

    # ---- 8. zeď ----
    pg.keyboard.press('z'); drag((12.5, 0.5), (12.5, 13.5)); L1 = lv()
    check('zeď: nakreslena souvislá čára 14 buněk', len(L1['walls']) == 14 and not L1['rocks'], len(L1['walls']))

    # ---- 6. pravé tlačítko maže ----
    click((12.5, 3.5), 'right'); L2 = lv()
    check('pravé tlačítko smaže zeď', len(L2['walls']) == 13 and [12, 3] not in L2['walls'])
    pg.keyboard.press('s'); click((12.5, 3.5)); check('skála se přidá', len(lv()['rocks']) == 1)
    click((12.5, 3.5), 'right'); check('pravé tlačítko smaže skálu', len(lv()['rocks']) == 0)
    drag((12.5, 6.5), (12.5, 9.5), button='right'); check('pravý tah smaže víc buněk', len(lv()['walls']) == 13 - 4, len(lv()['walls']))
    pg.keyboard.press('Control+z'); pg.keyboard.press('Control+z'); pg.keyboard.press('Control+z'); pg.keyboard.press('Control+z')

    # ---- 9. souvislá skála vs. kamínky ----
    pg.keyboard.press('Control+z'); pg.keyboard.press('Control+z')
    pg.evaluate("(()=>{const l=BD.store.profile.editor.levels[0]; l.walls=[]; BD.debugEditor.buildMasks();BD.debugEditor.changed(false);})()")
    drag((3.5, 14.5), (9.5, 14.5)); R1 = lv()['rocks']
    check('tah skálou: 7 buněk, všechny mají stejné číslo skupiny', len(R1) == 7 and all(len(r) == 3 and r[2] > 0 for r in R1) and len({r[2] for r in R1}) == 1, R1[:2])
    click((14.5, 14.5)); click((15.5, 14.5)); R2 = lv()['rocks']
    g = [r[2] for r in R2 if r[0] in (14, 15)]
    check('dvě klepnutí vedle sebe = dvě samostatné skály (různé skupiny)', len(g) == 2 and g[0] != g[1] and g[0] not in {r[2] for r in R1}, g)
    pg.screenshot(path=SH + 'e03_rocks.png', clip={'x': cv['x'], 'y': cv['y'] + cell * 15, 'width': cv['width'], 'height': cell * 8})

    # ---- 2. brány po tazích ----
    pg.keyboard.press('v'); drag((2.5, -0.5), (7.5, -0.5)); S1 = lv()['spawns']
    check('jeden tah nakreslí vstup dlouhý 6 buněk nahoře', len(S1) == 2 and S1[1]['side'] == 'T' and S1[1]['len'] == 6 and S1[1]['pos'] == 2, S1[1])
    drag((8.5, -0.5), (9.5, -0.5)); check('vstup hned vedle jiného se nenakreslí (dotýkají se)', len(lv()['spawns']) == 2 and 'dotýkat' in msg(), msg())
    drag((9.5, -0.5), (11.5, -0.5)); S2 = lv()['spawns']
    check('s jednou buňkou mezery to jde', len(S2) == 3 and S2[2]['pos'] == 9 and S2[2]['len'] == 3, S2[2] if len(S2) > 2 else '')
    click((14.5, 20.5)); click((16.5, 20.5)); S3 = lv()['spawns']
    check('klepnutí = vstup o 1 buňce (dole)', len(S3) == 5 and S3[3]['len'] == 1 and S3[3]['side'] == 'B', S3[3:])
    # stroke se zastaví před cizí bránou
    drag((13.5, -0.5), (20.5, -0.5)); S4 = lv()['spawns']
    check('tah přes cizí bránu se zastaví s mezerou', S4[-1]['pos'] == 13 and S4[-1]['len'] == 8, S4[-1])

    # ---- 3. start a cíl nesmí vedle sebe ----
    ex = lv()['exit']; ys = ex['pos']
    n0 = len(lv()['spawns']); click((24.5, ys - 0.5)); check('vstup vedle cíle (dotyk) se odmítne', len(lv()['spawns']) == n0 and 'dotýkat' in msg(), msg())
    click((24.5, ys - 1.5)); check('vstup s mezerou od cíle projde', len(lv()['spawns']) == n0 + 1)
    # 8 vstupů max
    pg.keyboard.press('v')
    for i in range(6): click((0.5 + 3 * i, 20.5))
    check('vstupů je nejvýš 8', len(lv()['spawns']) == 8, len(lv()['spawns']))
    check('hláška o maximu', 'Maximum' in msg(), msg())
    check('level s mnoha vstupy je v pořádku', pg.locator('.msg.okk').count() == 1, pg.locator('.ed-grp .msg').first.inner_text())
    pg.screenshot(path=SH + 'e01_editor.png')
    while pg.locator('.ed-grp .kv .btn.danger:not([disabled])').count() > 1: pg.locator('.ed-grp .kv .btn.danger:not([disabled])').last.click()
    check('zůstal jeden vstup (poslední nejde smazat)', len(lv()['spawns']) == 1)

    # ---- 4. cíl: brána na okraji i koule v poli ----
    pg.keyboard.press('c'); drag((9.5, 20.5), (12.5, 20.5)); E1 = lv()['exit']
    check('cíl nakreslený na okraji = brána (nahrazuje původní)', E1.get('side') == 'B' and E1['len'] == 4, E1)
    pg.keyboard.press('Digit2'); click((16.5, 10.5)); E2 = lv()['exit']
    check('cíl nakreslený do pole = koule (2×2 = 4 buňky)', 'orb' in E2 and len(E2['orb']) == 4, E2)
    pg.keyboard.press('Digit1'); click((0.5, 9.5)); check('koule vedle brány vstupu se odmítne', len(lv()['exit'].get('orb', [])) == 4 and 'dotýkat' in msg(), msg())
    check('level s koulí je v pořádku', pg.locator('.msg.okk').count() == 1)
    pg.keyboard.press('s'); click((16.5, 10.5)); check('skála se na kouli nepřidá', [16, 10] not in [r[:2] for r in lv()['rocks']])
    pg.keyboard.press('c'); pg.keyboard.press('Digit3'); drag((14.5, 4.5), (17.5, 4.5)); E3 = lv()['exit']
    check('tah 4×4 uvnitř = větší koule (jedním tahem)', 'orb' in E3 and len(E3['orb']) > 16, len(E3.get('orb', [])))
    pg.keyboard.press('Digit1')
    pg.keyboard.press('g'); click((0.5, 9.5), 'right')
    pg.wait_for_timeout(250); pg.screenshot(path=SH + 'e04_editor_orb.png')

    # ---- 7. pravidla ----
    pg.click('.ed-tabs button:has-text("Pravidla")')
    pg.fill('input[data-rule=lives]', '33'); pg.press('input[data-rule=lives]', 'Enter'); pg.locator('input[data-rule=gold]').fill('250'); pg.press('input[data-rule=gold]', 'Enter')
    R = lv(); check('životy a zlato se uloží', R['lives'] == 33 and R['gold'] == 250, (R.get('lives'), R.get('gold')))
    pg.locator('input[data-rule=waves]').fill('5'); pg.press('input[data-rule=waves]', 'Enter')
    check('minimum vln je 10', lv()['waves'] == 10 and pg.input_value('input[data-rule=waves]') == '10', lv().get('waves'))
    pg.locator('input[data-rule=waves]').fill('45'); pg.press('input[data-rule=waves]', 'Enter'); check('45 vln', lv()['waves'] == 45)
    pg.click('label.tog:has-text("Nekonečno")'); check('nekonečno = 0 vln, pole počtu vln je schované', lv()['waves'] == 0 and pg.locator('input[data-rule=waves]').count() == 0)
    pg.click('label.tog:has-text("Nekonečno")'); check('zrušení nekonečna vrátí 45 vln', lv()['waves'] == 45, lv().get('waves'))
    pg.evaluate("(()=>{const r=document.querySelector('input[data-rule=hp]'); r.value=200; r.dispatchEvent(new Event('input'));})()")
    check('síla bublin 200 %', lv().get('hp') == 2, lv().get('hp'))
    pg.click('input[data-allow=burst]'); A = lv().get('allowed'); check('povolené věže: bez plošného výbuchu', A and 'burst' not in A and len(A) == 3, A)
    pg.click('input[data-allow=ghost]'); pg.click('input[data-allow=boost]'); pg.click('input[data-allow=normal]')
    check('poslední kategorie nejde vypnout', lv().get('allowed') == ['normal'] and 'aspoň' in msg().lower() and pg.locator('input[data-allow=normal]').is_checked(), (lv().get('allowed'), msg()))
    pg.click('input[data-allow=burst]'); pg.click('input[data-allow=ghost]'); pg.click('input[data-allow=boost]'); check('všechny zapnuté = bez omezení', 'allowed' not in lv())
    pg.click('input[data-allow=burst]')

    # ---- předpostavené věže ----
    pg.click('.ed-tabs button:has-text("Kreslení")'); pg.keyboard.press('z'); drag((12.5, 12.5), (12.5, 14.5)); pg.keyboard.press('t')
    click((6.5, 6.5)); T1 = lv().get('towers', []); check('nástroj Věž postaví předpostavenou věž', len(T1) == 1 and T1[0]['type'] == 'base', T1)
    click((6.5, 6.5)); check('na věž se druhá nepostaví', len(lv()['towers']) == 1)
    click((12.5, 12.5)); check('na zeď se věž nepostaví', len(lv()['towers']) == 1 and 'Tady' in msg(), msg())
    click((6.5, 6.5), 'right'); check('pravé tlačítko věž smaže', len(lv().get('towers', [])) == 0)
    pg.keyboard.press('t'); pg.click('.chips button:has-text("Základní")'); click((6.5, 6.5)); click((9.5, 6.5))
    check('věž jiné kategorie', len(lv()['towers']) == 2 and lv()['towers'][0]['type'] == 'normal', lv()['towers'])
    pg.keyboard.press('z'); drag((6.5, 6.5), (6.5, 6.5)); check('zeď přes věž věž smaže', len(lv()['towers']) == 1, lv()['towers'])

    # ---- undo ----
    nT = len(lv()['towers']); pg.keyboard.press('Control+z'); pg.keyboard.press('Control+z'); check('Ctrl+Z vrací', len(lv().get('towers', [])) < nT + 1)

    # ---- po obnovení stránky vše zůstane ----
    L_before = lv(); pg.wait_for_timeout(600); pg.reload(); pg.wait_for_selector('.content:not(.hidden) .intro')
    L_after = pg.evaluate("(()=>{const l=BD.store.profile.editor.levels[0]; return l?JSON.parse(JSON.stringify(l)):null;})()")
    same = L_after and all(L_after.get(k) == L_before.get(k) for k in ['w', 'h', 'spawns', 'exit', 'rocks', 'walls', 'towers', 'lives', 'gold', 'waves', 'hp', 'allowed'])
    check('po refreshi zůstane level včetně koule, skupin skal a pravidel', same, '' if same else (L_before.get('exit'), (L_after or {}).get('exit')))
    b.close()
    b = None
print('\nvýsledek: %d/%d' % (sum(results), len(results)), '| chyby:', errs or 'žádné')
