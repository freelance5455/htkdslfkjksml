"""Hra s levelem z editoru: neviditelné brány, koule cíle, pravidla, předpostavené věže:  python3 -I tests/ui_orb.py"""
import glob, json
from playwright.sync_api import sync_playwright
exe = (glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome') or [None])[0]
SH = '/home/claude/BubbleDefence/tests/shots/'
errs, results = [], []
def check(n, c, x=''): results.append(bool(c)); print(('OK   ' if c else 'FAIL ') + n + (' ' + str(x) if x != '' else ''))
LEVEL = {'w': 12, 'h': 10, 'spawns': [{'side': 'L', 'pos': 8, 'len': 4}], 'exit': {'orb': [[19, 9], [20, 9], [19, 10], [20, 10]]},
         'rocks': [[10, 4, 1], [11, 4, 1], [10, 5, 1], [11, 5, 1]], 'walls': [[14, y] for y in range(0, 10)] + [[14, y] for y in range(12, 20)],
         'towers': [{'type': 'normal', 'x': 4, 'y': 4}], 'lives': 999, 'gold': 321, 'waves': 10, 'hp': 2, 'allowed': ['normal', 'ghost']}
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=exe, args=['--no-sandbox'])
    pg = b.new_page(viewport={'width': 1280, 'height': 800})
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type in ('error', 'warning') and 'willReadFrequently' not in m.text else None)
    pg.goto('file:///home/claude/BubbleDefence/index.html'); pg.wait_for_selector('.content:not(.hidden) .intro')
    pg.click('text=Nová lokální hra'); pg.wait_for_selector('.content:not(.hidden) .menu'); pg.wait_for_timeout(300)
    pg.click('.mi:has-text("Editor")'); pg.click('.lcard.add'); pg.wait_for_selector('.edv .ed-cv'); pg.wait_for_timeout(300)
    pg.evaluate("(L=>{const l=BD.store.profile.editor.levels[0]; Object.assign(l, L); BD.debugEditor.buildMasks(); BD.debugEditor.changed(true);})(%s)" % json.dumps(LEVEL))
    pg.wait_for_timeout(300)
    check('level s koulí, věží a pravidly je platný (Vyzkoušet povoleno)', pg.locator('.smap-head .btn.primary:not([disabled])').count() == 1, pg.locator('.ed-grp .msg').first.inner_text())
    pg.click('.smap-head .btn.primary'); pg.wait_for_selector('.gv canvas'); pg.wait_for_timeout(700)
    G = lambda js: pg.evaluate("(()=>{const g=BD.debug.game; return %s})()" % js)
    check('hra: cíl je koule', G('g.exitIsOrb') is True and G('g.orb.reduce((a,b)=>a+b,0)') == 4)
    check('hra: životy, zlato, vlny, síla bublin z levelu', G('[g.lives,g.gold,g.maxWaves,g.hpMul]') == [999, 321, 10, 2], G('[g.lives,g.gold,g.maxWaves,g.hpMul]'))
    check('hra: předpostavená věž stojí a je zdarma', G('g.towers.length') == 1 and G('g.towers[0].type') == 'normal' and G('g.gold') == 321 and G('g.towers[0].level') == 1)
    check('hra: na kouli nejde stavět', G("g.canPlace('base',19,9).ok") is False)
    check('hra: cesta ke kouli existuje', G('g.pathLen(0)') > 0, G('g.pathLen(0)'))
    # brány ve hře nejsou vidět: pixel v bráně = podlaha, v okraji = zeď
    box = pg.locator('.gv canvas').bounding_box(); c = box['width'] / (24 + 2)
    def px(fx, fy): return pg.evaluate("([x,y])=>{const cv=document.querySelector('.gv canvas'); const d=cv.getContext('2d').getImageData(Math.round(x*cv.width/cv.clientWidth),Math.round(y*cv.height/cv.clientHeight),1,1).data; return [d[0],d[1],d[2]];}", [(fx + 1) * c, (fy + 1) * c])
    gate, wall = px(-0.5, 11.5), px(-0.5, 3.5)
    check('brána ve hře je prázdná (barva podlahy, ne červená)', gate[1] >= gate[2] and gate[0] < 60, gate)
    check('okraj vedle brány je zeď', wall[2] > wall[1], wall)
    pg.screenshot(path=SH + 'g01_orb_game.png')
    # průchod bublin koulí
    G("(g.startWave(), 0)"); pg.evaluate("(()=>{const g=BD.debug.game; for(let i=0;i<4000 && g.lives===999;i++) g.step(1/30);})()")
    check('bubliny doběhnou do koule a ubírají životy', G('g.lives') < 999, G('g.lives'))
    # povolené kategorie věží
    pg.evaluate("(()=>{BD.debug.game.gold=1000; const t=BD.debug.game.place('base',8,2); BD.debug.tap({cell:[8,2],pos:[8,2]});})()"); pg.wait_for_timeout(300)
    check('při upgradu základny jsou jen povolené kategorie', pg.locator('.btn.choice').count() == 2, pg.locator('.btn.choice').count())
    # výhra v levelu z editoru vede zpět do menu
    pg.evaluate("(()=>{const g=BD.debug.game; g.gold=1e6; g.lives=999; g.wave=9; g.streams=[]; g.waveLeft={}; g.enemies=[]; g.startWave(); for(let i=0;i<60000 && !g.won && !g.gameOver;i++) g.step(1/30);})()")
    pg.wait_for_timeout(400)
    check('po 10 vlnách je level splněn', G('g.won') is True and pg.locator('.over h2:has-text("Level splněn")').count() == 1)
    lab = pg.locator('.over .btn.primary.big').inner_text().strip()
    check('tlačítko po výhře zkušební hry vede zpět do editoru', 'editor' in lab.lower(), lab)
    pg.click('.over .btn.primary.big'); pg.wait_for_selector('.smap-head', timeout=5000)
    check('jsme zpět v editoru', pg.locator('.smap-head').count() >= 1)
    b.close()
print('\nvýsledek: %d/%d' % (sum(results), len(results)), '| chyby:', errs or 'žádné')
