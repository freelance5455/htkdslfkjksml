from pathlib import Path
import tomllib

root = Path(__file__).resolve().parents[1]
source = '/piper-model/*'
target = 'https://huggingface.co/rhasspy/piper-voices/resolve/main/:splat'

redirects = (root / '_redirects').read_text(encoding='utf-8')
assert f'{source}  {target}  200!' in redirects, '_redirects-Regel fehlt oder weicht ab'

config = tomllib.loads((root / 'netlify.toml').read_text(encoding='utf-8'))
rules = config.get('redirects', [])
assert any(
    r.get('from') == source
    and r.get('to') == target
    and r.get('status') == 200
    and r.get('force') is True
    for r in rules
), 'netlify.toml-Regel fehlt oder weicht ab'

bundle = (root / 'vendor/piper-tts-web.bundle.js').read_text(encoding='utf-8')
assert 'HF_BASE' in bundle and ('/piper-model' in bundle or '__PIPER_HF_BASE__' in bundle), 'Piper-Bundle HF_BASE fehlt'
print('PASS Netlify redirect declarations, Piper base path')
