import { Chess, Square } from 'chess.js';
import { evaluateBoard, getAiMove, getBestMoveHint } from '../src/services/aiEngine';
import { TIME_CONTROL_PRESETS } from '../src/services/storage';
import {
  getAllSquares,
  isLightSquare,
  squareToWorld,
  worldToSquare,
  get2DBoardGrid,
  squareDistance,
} from '../src/services/chessCoordinates';
import { ChessRulesEngine } from '../src/services/chessRules';

console.log('--- STARTING 3D CHESS TEST SUITE (PROMPTS 1-6) ---');

let passedTests = 0;
let totalTests = 0;

function assert(condition: boolean, testName: string) {
  totalTests++;
  if (condition) {
    passedTests++;
    console.log(`[PASS] ${testName}`);
  } else {
    console.error(`[FAIL] ${testName}`);
    throw new Error(`Assertion failed: ${testName}`);
  }
}

// 1. Strict King Movement & Safety Invariants
function testStrictKingSafety() {
  console.log('\n--- 1. Testing Strict King Safety & Invariants ---');

  // A. King cannot capture opponent king
  const twoKingsGame = new Chess('4k3/8/8/8/8/8/8/4K3 w - - 0 1');
  const kingCaptureValidation = ChessRulesEngine.validateMove(twoKingsGame, 'e1', 'e8');
  assert(!kingCaptureValidation.isValid, 'King cannot capture opponent king');

  // B. Kings cannot occupy the same square
  const sameSquareValidation = ChessRulesEngine.validateMove(twoKingsGame, 'e1', 'e8');
  assert(!sameSquareValidation.isValid, 'Two kings cannot occupy the same square');

  // C. Kings cannot move adjacent to each other (Chebyshev distance must be >= 2)
  const adjacentTestGame = new Chess('4k3/8/8/8/8/4K3/8/8 w - - 0 1'); // White King at e3, Black King at e8
  // Move White king towards e7/e8: if Kings are at e4 and e5 (adjacent)
  const closeKingsGame = new Chess('8/8/8/4k3/8/4K3/8/8 w - - 0 1'); // White King at e3, Black King at e5
  // Moving White King to e4 would place it adjacent to e5
  const moveAdjacentValidation = ChessRulesEngine.validateMove(closeKingsGame, 'e3', 'e4');
  assert(!moveAdjacentValidation.isValid, 'King cannot move adjacent to opponent king');

  // D. King cannot move into check
  const rookAttackingGame = new Chess('4k3/8/8/8/8/8/4r3/4K3 w - - 0 1'); // Black Rook at e2 gives check
  const moveIntoRookAttack = ChessRulesEngine.validateMove(rookAttackingGame, 'e1', 'e2');
  // e2 has the rook (capture is legal if not guarded, but let's test moving to d1 guarded by rook)
  const moveIntoCheck = ChessRulesEngine.validateMove(rookAttackingGame, 'e1', 'd1');
  // Rook on e2 attacks d2, f2, e1.. Does not attack d1 directly, but let's test moving to e1 square
  const queenAttackingGame = new Chess('4k3/8/8/8/8/8/8/r3K3 w - - 0 1'); // Rook on a1 checks e1
  const moveIntoRank1 = ChessRulesEngine.validateMove(queenAttackingGame, 'e1', 'd1');
  assert(!moveIntoRank1.isValid, 'King cannot move into check along attacked rank');

  // E. Pinned piece cannot expose king
  const pinnedGame = new Chess('4k3/8/8/8/8/8/4r3/4R1K1 b - - 0 1'); // Re1 pins against White King
  const pinGameWhite = new Chess('r3k3/8/8/8/8/8/4R3/4K3 b - - 0 1'); // White Rook on e2 checks Black King on e8
  const pinGame2 = new Chess('4k3/8/8/8/4r3/8/4R3/4K3 w - - 0 1'); // Re2 is pinned to King on e1 by Black Re4
  // Moving pinned Rook Re2 to d2 would expose Ke1 to Re4
  const pinnedMove = ChessRulesEngine.validateMove(pinGame2, 'e2', 'd2');
  assert(!pinnedMove.isValid, 'Pinned piece cannot move and expose its king');

  // Capturing the pinning piece with the pinned piece IS legal
  const pinCaptureMove = ChessRulesEngine.validateMove(pinGame2, 'e2', 'e4');
  assert(pinCaptureMove.isValid, 'Pinned piece may capture the pinning piece along the line of pin');
}

// 2. Legal Moves, Checkmate, Stalemate & Turn Alternation
function testRulesAndCheckmate() {
  console.log('\n--- 2. Testing Standard Rules, Checkmate & Stalemate ---');
  const game = new Chess();

  // Turn alternation
  assert(game.turn() === 'w', 'Game starts on White turn');
  const m1 = ChessRulesEngine.executeMove(game, 'e2', 'e4');
  assert(m1.success, 'White opens e4 legally');
  assert(game.turn() === 'b', 'Turn alternates to Black');

  const m2 = ChessRulesEngine.executeMove(game, 'e7', 'e5');
  assert(m2.success, 'Black responds e5 legally');
  assert(game.turn() === 'w', 'Turn alternates to White');

  // Scholar's Mate
  const scholarsGame = new Chess();
  scholarsGame.move('e4');
  scholarsGame.move('e5');
  scholarsGame.move('Qh5');
  scholarsGame.move('Nc6');
  scholarsGame.move('Bc4');
  scholarsGame.move('Nf6');
  scholarsGame.move('Qxf7#');
  assert(scholarsGame.isCheckmate(), 'Scholar\'s mate recognized as checkmate');
  assert(scholarsGame.isGameOver(), 'Game ends on checkmate');

  // Stalemate
  const stalemateGame = new Chess('k7/8/1Q6/8/8/8/8/7K b - - 0 1');
  assert(stalemateGame.isStalemate(), 'Stalemate correctly detected with zero legal moves without check');
  assert(stalemateGame.isDraw(), 'Stalemate is recognized as a draw');
}

// 3. Castling, En Passant & Promotions
function testSpecialMoves() {
  console.log('\n--- 3. Testing Castling, En Passant & Pawn Promotion ---');

  // Castling
  const castlingGame = new Chess('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1');
  const castleO_O = castlingGame.move('O-O');
  assert(castleO_O !== null && castlingGame.get('g1')?.type === 'k', 'Kingside castling executed successfully');

  // Castling blocked through check
  const castlingThroughCheck = new Chess('r3k2r/8/8/8/8/8/3b4/R3K2R w KQkq - 0 1'); // Bishop on d2 attacks d1
  let illegalCastle = false;
  try {
    castlingThroughCheck.move('O-O-O');
  } catch {
    illegalCastle = true;
  }
  assert(illegalCastle, 'Castling through an attacked square (d1) is strictly illegal');

  // En Passant
  const epGame = new Chess();
  epGame.move('e4');
  epGame.move('a6');
  epGame.move('e5');
  epGame.move('d5');
  const epMove = epGame.move('exd6');
  assert(epMove !== null && epMove.captured === 'p', 'En passant captures adjacent advanced pawn');
  assert(!epGame.get('d5'), 'En passant removes captured pawn from d5');

  // All 4 promotions (Q, R, B, N)
  const promoFen = '8/4P3/8/8/8/8/8/4K2k w - - 0 1';
  ['q', 'r', 'b', 'n'].forEach((pieceChoice) => {
    const promoGame = new Chess(promoFen);
    const res = ChessRulesEngine.executeMove(promoGame, 'e7', 'e8', pieceChoice);
    assert(res.success && promoGame.get('e8')?.type === pieceChoice, `Pawn promotes to ${pieceChoice.toUpperCase()}`);
  });
}

// 4. Board Geometry, 64 Squares & Coordinate Conversion
function testBoardGeometry() {
  console.log('\n--- 4. Testing Board Geometry & Coordinate Conversion ---');

  // Exactly 64 squares created
  const squares = getAllSquares();
  assert(squares.length === 64, 'Exactly 64 visible chess squares are generated');

  // Standard Chess Colors:
  // a1 must be Dark
  assert(!isLightSquare('a1'), 'Square a1 is Dark');
  // h1 must be Light (White on right)
  assert(isLightSquare('h1'), 'Square h1 is Light (White on right)');
  // a8 must be Light
  assert(isLightSquare('a8'), 'Square a8 is Light');
  // h8 must be Dark
  assert(!isLightSquare('h8'), 'Square h8 is Dark');
  // e1 (White King) starts on dark square
  assert(!isLightSquare('e1'), 'White King starting square e1 is Dark');
  // d1 (White Queen) starts on her own color (light)
  assert(isLightSquare('d1'), 'White Queen starting square d1 is Light');
  // e8 (Black King) starts on light square
  assert(isLightSquare('e8'), 'Black King starting square e8 is Light');
  // d8 (Black Queen) starts on dark square
  assert(!isLightSquare('d8'), 'Black Queen starting square d8 is Dark');

  // Alternating colors across entire board
  let alternationValid = true;
  for (let r = 0; r < 8; r++) {
    for (let f = 0; f < 7; f++) {
      const sq1 = `${String.fromCharCode(97 + f)}${r + 1}` as Square;
      const sq2 = `${String.fromCharCode(97 + f + 1)}${r + 1}` as Square;
      if (isLightSquare(sq1) === isLightSquare(sq2)) {
        alternationValid = false;
      }
    }
  }
  assert(alternationValid, 'All 64 squares alternate strictly light and dark horizontally');

  // Bi-directional 3D world to square mapping
  for (const sq of squares) {
    const world = squareToWorld(sq);
    const roundTrip = worldToSquare(world.x, world.z);
    assert(roundTrip === sq, `Bi-directional coordinate mapping accurate for square ${sq}`);
  }

  // 2D Grid structure
  const gridWhite = get2DBoardGrid('w');
  assert(gridWhite.length === 8 && gridWhite[0].length === 8, '2D grid has 8 rows and 8 columns');
  assert(gridWhite[0][0].square === 'a8', 'White perspective top-left square is a8');
  assert(gridWhite[7][7].square === 'h1', 'White perspective bottom-right square is h1');

  const gridBlack = get2DBoardGrid('b');
  assert(gridBlack[0][0].square === 'h1', 'Black perspective top-left square is h1');
  assert(gridBlack[7][7].square === 'a8', 'Black perspective bottom-right square is a8');
}

// 5. 2D / 3D Mode Switching State Preservation
function testModeSwitchingStatePreservation() {
  console.log('\n--- 5. Testing 2D / 3D State Preservation ---');

  const game = new Chess();
  game.move('e4');
  game.move('e5');
  game.move('Nf3');
  const fenBefore = game.fen();
  const turnBefore = game.turn();

  // Simulating displayMode switch:
  let displayMode: '3d' | '2d' = '3d';
  // Toggle to 2D
  displayMode = '2d';
  assert(displayMode === '2d', 'Display mode toggled to 2D');
  assert(game.fen() === fenBefore, 'Game FEN completely preserved when switching to 2D');
  assert(game.turn() === turnBefore, 'Game turn completely preserved when switching to 2D');

  // Toggle back to 3D
  displayMode = '3d';
  assert(displayMode === '3d', 'Display mode toggled back to 3D');
  assert(game.fen() === fenBefore, 'Game FEN completely preserved when switching back to 3D');

  // Next move played in 3D
  const m = ChessRulesEngine.executeMove(game, 'b8', 'c6');
  assert(m.success, 'Next legal move committed without interruption');
}

// Run all test suites
async function runAllTests() {
  testStrictKingSafety();
  testRulesAndCheckmate();
  testSpecialMoves();
  testBoardGeometry();
  testModeSwitchingStatePreservation();

  console.log('\n===========================================');
  console.log(`ALL TESTS PASSED! (${passedTests} / ${totalTests} assertions passed)`);
  console.log('===========================================\n');
}

runAllTests().catch((err) => {
  console.error('Test suite failure:', err);
  process.exit(1);
});
