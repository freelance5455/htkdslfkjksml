import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const html = readFileSync(join(root, 'index.html'), 'utf8');
const app = readFileSync(join(root, 'src/app.js'), 'utf8');
const sectionOf = sub => html.match(new RegExp(`<section class="section" data-screen="(\\w+)" data-sub="${sub}"`))?.[1];

test('l’éditeur d’identité est un sous-menu de Club', () => assert.equal(sectionOf('editeur'), 'club'));
test('chaque coupe a son sous-menu sous Compétitions', () => {
  for (const sub of ['coupe-galactique', 'coupe-federal', 'coupe-des-clubs', 'champions-league', 'intergalactique-clubs', 'coupe-intergalactique', 'coupe-lunaire', 'dame-or', 'championnats', 'overview'])
    assert.equal(sectionOf(sub), 'competitions', sub);
});
test('tous les sous-menus déclarés dans app.js ont un panneau', () => {
  const block = app.match(/const SUBS=\{(.*?)\};/s)[1];
  const ids = [...block.matchAll(/\['([a-z-]+)','/g)].map(m => m[1]);
  assert.ok(ids.length >= 14);
  for (const id of ids) assert.ok(sectionOf(id), id);
});
test('le parcours contient la configuration, la compétition officielle et la prise de fonction', () => {
  assert.ok(app.includes('careerConfigForm') && app.includes('competitionContinue') && app.includes('welcomeOverlay'));
  assert.ok(app.includes('COMPETITION_MATCH_DAYS'));
});
