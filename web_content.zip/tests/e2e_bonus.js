// node tests/e2e_bonus.js — gerçek oyun akışı (attack5 → savaş → kapat → seçim/otomatik bonus), headless Chromium
const { chromium } = require('playwright'); const path = require('path');
const URL = 'file://' + path.resolve(__dirname, '..') + '/index.html'; let fails = 0, n = 0;
const ok = (c, m) => { n++; console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fails++; };
const SC = [
  ['A tümü üstün', [80, 75, 90, 85, 70], [60, 65, 80, 70, 50], 'auto'],
  ['B 4. düşük', [80, 75, 90, 65, 70], [60, 65, 80, 70, 50], 'choose'],
  ['C 4. eşit', [80, 75, 90, 70, 70], [60, 65, 80, 70, 50], 'choose'],
  ['D 5. düşük', [80, 75, 90, 85, 40], [60, 65, 80, 70, 50], 'choose'],
  ['E 4. ve 5. düşük', [80, 75, 90, 60, 40], [60, 65, 80, 70, 50], 'choose'],
];
(async () => {
  const b = await chromium.launch();
  for (const lang of ['tr', 'en']) for (const [name, me, foe, expect] of SC) {
    const p = await b.newPage({ viewport: { width: 900, height: 700 } }); const errs = []; p.on('pageerror', e => errs.push(String(e)));
    await p.goto(URL); await p.waitForTimeout(900);
    const res = await p.evaluate(({ me, foe, lang }) => {
      if (L != lang) setLang(); SET.rm = true; Math.random = () => 0.99;
      newGame(1); closeMod(); G.pl = G.cur = G.act = 'TUR'; G.sel = null; G.ph = 'act'; G.pend = null; G.T = { turn: 1, roll: 6, moves: 6, scouted: false }; G.es = G.es || {}; G.ed = {};
      G.es['TUR'] = me.slice(); G.es['GRC'] = foe.slice();
      const tOK = !!targets('TUR', G.owner)['GRC']; const foeBefore = st('GRC').slice();
      const o = { tOK }; if (!tOK) return o;
      const a = V5.attack('TUR', 'GRC', false); o.attacked = a;
      o.win = G.last && G.last.win; o.pendDone = G.pend && G.pend.done; o.pendBonusOk = G.pend && G.pend.bonus && G.pend.bonus.ok;
      o.meAfterBattle = st('TUR').slice(); o.autoBonus = !!G.autoBonus;
      o.battleLine = /🎁/.test(document.getElementById('bs').innerHTML);
      closeBattle();
      o.ph = G.ph; o.modalOpen = document.getElementById('mod').style.display == 'flex'; o.copyBtns = document.querySelectorAll('#box .cd, #box button.big').length;
      o.okDisabled = document.getElementById('cdok') ? document.getElementById('cdok').disabled : null;
      o.v8bonusShown = !!document.getElementById('bnok'); o.meNow = st('TUR').slice(); o.foeNow = st('GRC').slice(); o.foeBefore = foeBefore; o.bpend = !!G.bpend;
      return o;
    }, { me, foe, lang });
    console.log(`[${lang}] ${name}`, JSON.stringify(res));
    ok(res.tOK && res.attacked && res.win, `${lang}/${name}: savaş kazanıldı (test düzeneği)`);
    if (expect === 'auto') {
      ok(res.pendDone === true && res.pendBonusOk === true, `${lang}/${name}: otomatik çözüm (pend.done)`);
      ok(res.ph === 'act' && !res.modalOpen && !res.v8bonusShown && res.okDisabled === null, `${lang}/${name}: beşli seçim ekranı AÇILMADI (faz=${res.ph})`);
      const exp = res.meAfterBattle; ok(exp.every((v, i) => Math.abs(v - Math.round(me[i] * 11) / 10) < 1e-9 || i === 2), `${lang}/${name}: 5 özellik ×1,10 (eko hariç tazminat farkı olabilir) ${JSON.stringify(exp)}`);
      ok(res.battleLine, `${lang}/${name}: savaş sonucunda otomatik bonus bilgisi`);
    } else {
      ok(res.pendDone === false && !res.pendBonusOk, `${lang}/${name}: seçim bekleniyor, bonus yok`);
      ok(res.ph === 'v5pick' && res.modalOpen && res.okDisabled === true, `${lang}/${name}: zorunlu seçim ekranı açık, onay düğmesi seçime kadar kilitli (faz=${res.ph})`);
      ok(!res.v8bonusShown && !res.bpend, `${lang}/${name}: ek bonus ekranı yok`);
      // seçim yapmadan devam edilemez: v7Ok seçimsiz hiçbir şey yapmaz
      const st1 = await p.evaluate(() => { v7Ok(); return { ph: G.ph, pend: !!(G.pend && !G.pend.done) }; });
      ok(st1.ph === 'v5pick' && st1.pend, `${lang}/${name}: seçimsiz "Devam" işlemi tamamlamaz`);
      // seç ve devam: yalnızca kopyalanan özellik değişir, rakip değişmez, bonus yok
      const idx = 3; const after = await p.evaluate((idx) => { const before = st('TUR').slice(), foe = G.pend.foeSnap.slice(); v7Sel(idx); v7Ok(); return { before, foe, now: st('TUR').slice(), foeNow: foe.slice(), ph: G.ph, bp: !!G.bpend, modal: document.getElementById('mod').style.display == 'flex' }; }, idx);
      ok(after.ph === 'act' && !after.modal && !after.bp, `${lang}/${name}: seçimden sonra oyun devam eder (faz=${after.ph})`);
      ok(after.now.every((v, i) => i === idx ? v === after.foe[idx] : v === after.before[i]), `${lang}/${name}: yalnızca seçilen özellik rakibe eşitlendi`);
      ok(after.foe.every((v, k) => k === 2 || v === foe[k]), `${lang}/${name}: rakip anlık görüntüsü fetih anındaki değerlerle aynı (eko tazminat hariç)`);
    }
    ok(errs.length === 0, `${lang}/${name}: sayfa hatası yok ${errs.join('|')}`);
    await p.close();
  }
  console.log(fails ? `\n${fails}/${n} BAŞARISIZ` : `\nHEPSİ GEÇTİ (${n})`); await b.close(); process.exit(fails ? 1 : 0);
})();
