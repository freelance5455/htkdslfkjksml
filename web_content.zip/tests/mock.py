import json, re
from pathlib import Path
T = Path('/tmp/t')
def w(pos, ar, en): return {"position": pos, "text_uthmani": ar, "char_type_name": "word", "translation": {"text": en}}
IKH = [
 ["قُلْ هُوَ ٱللَّهُ أَحَدٌ", ["Say", "He", "Allah", "One"], "Say, \"He is Allah, [who is] One,<sup foot_note=1>1</sup>"],
 ["ٱللَّهُ ٱلصَّمَدُ", ["Allah", "the Eternal Refuge"], "Allah, the Eternal Refuge."],
 ["لَمْ يَلِدْ وَلَمْ يُولَدْ", ["not", "He begets", "and not", "He is begotten"], "He neither begets nor is born,"],
 ["وَلَمْ يَكُن لَّهُۥ كُفُوًا أَحَدٌۢ", ["and not", "is", "for Him", "equivalent", "anyone"], "Nor is there to Him any equivalent."],
]
FAT = [
 ["بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ", ["In (the) name", "(of) Allah", "the Most Gracious", "the Most Merciful"], "In the name of Allah"],
 ["ٱلْحَمْدُ لِلَّهِ رَبِّ ٱلْعَـٰلَمِينَ", ["All praises", "(are) for Allah", "Lord", "(of) the worlds"], "[All] praise is [due] to Allah"],
 ["ٱلرَّحْمَـٰنِ ٱلرَّحِيمِ", ["the Most Gracious", "the Most Merciful"], "The Entirely Merciful"],
 ["مَـٰلِكِ يَوْمِ ٱلدِّينِ", ["Master", "(of the) Day", "(of) the Judgment"], "Sovereign of the Day of Recompense."],
 ["إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ", ["You alone", "we worship", "and You alone", "we ask for help"], "It is You we worship"],
 ["ٱهْدِنَا ٱلصِّرَٰطَ ٱلْمُسْتَقِيمَ", ["Guide us", "(to) the path", "the straight"], "Guide us to the straight path"],
 ["صِرَٰطَ ٱلَّذِينَ أَنْعَمْتَ عَلَيْهِمْ", ["(The) path", "(of) those", "You have bestowed (favor)", "upon them"], "The path of those upon whom You have bestowed favor"],
]
def verses(data):
    out = []
    for i, (txt, ens, tr) in enumerate(data, 1):
        ws = txt.split(' ')
        assert len(ws) == len(ens), (txt, len(ws), len(ens))
        words = [w(j+1, a, e) for j, (a, e) in enumerate(zip(ws, ens))]
        words.append({"position": len(ws)+1, "text_uthmani": "﴿", "char_type_name": "end", "translation": {"text": str(i)}})
        out.append({"verse_number": i, "words": words, "translations": [{"id": 20, "text": tr}]})
    return {"verses": out, "pagination": {"next_page": None}}
CHAPTERS = {"chapters": [
  {"id": 1, "name_arabic": "الفاتحة", "name_simple": "Al-Fatihah", "verses_count": 7},
  {"id": 112, "name_arabic": "الإخلاص", "name_simple": "Al-Ikhlas", "verses_count": 4}]}
def segs_for(data, bounds):
    ts = []
    for i, ((txt, _, _), (a, b)) in enumerate(zip(data, bounds), 1):
        n = len(txt.split(' ')); step = (b-a)/n
        ts.append({"verse_key": f"112:{i}", "timestamp_from": a, "timestamp_to": b, "duration": b-a,
                   "segments": [[k+1, int(a+k*step), int(a+(k+1)*step)] for k in range(n)]})
    return ts
BOUNDS = [(0,3500),(3500,6000),(6000,9000),(9000,12000)]
CORS = {"access-control-allow-origin": "*"}

def install(page, pexels_key="GOODKEY", fail_chapters=False):
    calls = {"chapters":0, "verses":0, "audio":0}
    def h(route):
        u = route.request.url
        if 'fonts.googleapis.com' in u or 'fonts.gstatic.com' in u: return route.abort()
        if u.startswith('https://api.quran.com/api/v4/chapters'):
            calls["chapters"] += 1
            if fail_chapters: return route.abort()
            return route.fulfill(json=CHAPTERS, headers=CORS)
        m = re.match(r'https://api.quran.com/api/v4/verses/by_chapter/(\d+)', u)
        if m:
            calls["verses"] += 1
            return route.fulfill(json=verses(IKH if m.group(1)=='112' else FAT), headers=CORS)
        if 'resources/chapter_reciters' in u:
            return route.fulfill(json={"reciters":[{"id":7,"name":"Mishari","arabic_name":"مشاري العفاسي","style":None},{"id":2,"name":"AbdulBaset","arabic_name":"عبد الباسط","style":{"name":"مرتل"}}]}, headers=CORS)
        m = re.match(r'https://api.quran.com/api/v4/chapter_recitations/(\d+)/(\d+)', u)
        if m:
            rid = m.group(1)
            ts = segs_for(IKH, BOUNDS)
            if rid == '2':
                for t in ts: t["segments"] = []
            return route.fulfill(json={"audio_file":{"audio_url":"https://mock.audio/112.mp3","timestamps":ts}}, headers=CORS)
        if u == 'https://mock.audio/112.mp3':
            calls["audio"] += 1
            return route.fulfill(body=(T/'aud12.mp3').read_bytes(), headers={**CORS, "content-type":"audio/mpeg"})
        if u.startswith('https://api.pexels.com/videos/search'):
            if route.request.headers.get('authorization') != pexels_key:
                return route.fulfill(status=401, body='{}', headers=CORS)
            return route.fulfill(json={"videos":[{"id":111,"image":"https://mock.img/t.png","duration":10,"user":{"name":"Tester"},
               "video_files":[{"file_type":"video/mp4","width":640,"link":"https://mock.pexels/v.webm"}]}]}, headers=CORS)
        if u == 'https://mock.pexels/v.webm':
            return route.fulfill(body=(T/'vid10.webm').read_bytes(), headers={**CORS, "content-type":"video/webm"})
        if u == 'https://mock.img/t.png':
            return route.fulfill(body=(T/'img.png').read_bytes(), headers={"content-type":"image/png"})
        return route.continue_()
    page.route('**/*', h)
    return calls
