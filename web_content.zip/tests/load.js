/* Memuat modul non-DOM ke konteks node (vm) memakai urutan yang sama seperti index.html. */
const fs = require('fs'), path = require('path'), vm = require('vm');
module.exports = function load() {
  const ctx = vm.createContext({ console, Math, JSON, Date, Set, Object, Array, Number, isFinite, parseInt, String, RegExp, Error });
  ctx.globalThis = ctx;
  ['js/core/config.js', 'js/core/machine.js', 'js/gameplay/engine.js', 'js/storage/store.js'].forEach(function (f) {
    vm.runInContext(fs.readFileSync(path.join(__dirname, '..', f), 'utf8'), ctx, { filename: f });
  });
  return ctx.SU;
};
module.exports.seeded = function (seed) { let a = seed >>> 0; return function () { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; };
