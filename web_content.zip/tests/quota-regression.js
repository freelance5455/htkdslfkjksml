const fs=require('fs'),path=require('path'),vm=require('vm');
const html=fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8');
const match=html.match(/<script>([\s\S]*)<\/script>/);if(!match)throw Error('script missing');
const store={};const PER_KEY_LIMIT=50000;
const localStorage={getItem(k){return store[k]??null},setItem(k,v){if(String(v).length>PER_KEY_LIMIT)throw Object.assign(new Error('quota exceeded'),{name:'QuotaExceededError'});store[k]=String(v)},removeItem(k){delete store[k]}};
class El{constructor(){this.innerHTML='';this.textContent='';this.value='';this.dataset={};this.style={};this.classList={add(){},remove(){},contains(){return false}}}querySelectorAll(){return []}querySelector(){return new El()}click(){}}
const document={querySelector(){return new El()},querySelectorAll(){return []},createElement(){return new El()},body:new El()};
const context={document,localStorage,console,Math,Date,JSON,Blob:function(){},URL:{createObjectURL(){return ''},revokeObjectURL(){}},confirm(){return true},alert(){},setTimeout(){return 1},clearTimeout(){},FormData:function(){},FileReader:function(){},navigator:{},performance:{now(){return 0}}};context.window=context;vm.createContext(context);
vm.runInContext(match[1]+'\nglobalThis.__t={setState(v){state=v},brazilWorldResetAll,brazilWorldLoad,brazilWorldSave,brazilWorldStorageKey};',context);
const t=context.__t;const clubs={A:Array.from({length:20},(_,i)=>'A'+i),B:Array.from({length:20},(_,i)=>'B'+i),C:Array.from({length:20},(_,i)=>'C'+i)};
t.setState({season:2026,divisions:clubs});t.brazilWorldResetAll(2026);
for(const div of ['A','B','C']){const key=t.brazilWorldStorageKey(div);if(!store[key])throw Error('missing compact storage '+div);if(store[key].length>PER_KEY_LIMIT)throw Error('division exceeds simulated per-key quota '+div);const d=t.brazilWorldLoad(div);if(d.rounds.length!==38||d.rounds.some(r=>r.length!==10))throw Error('invalid calendar '+div);}
if(store.cc_brazil_world_leagues_v123)throw Error('legacy oversized key remains after reset');
let a=t.brazilWorldLoad('A');a.rounds[0][0].played=true;a.rounds[0][0].homeGoals=2;a.rounds[0][0].awayGoals=1;t.brazilWorldSave('A',a);const reloaded=t.brazilWorldLoad('A');if(!reloaded.rounds[0][0].played||reloaded.rounds[0][0].homeGoals!==2)throw Error('compact result persistence failed');
console.log('PASS: creation calendars fit simulated quota, per-division compact storage, 38 rounds, and saved results survive reload.');
