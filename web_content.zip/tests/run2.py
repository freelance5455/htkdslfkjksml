import sys, time, subprocess, json, os
from playwright.sync_api import sync_playwright
sys.path.insert(0,'/tmp/t')
import mock
R=[]
def ok(n,c,e=''):
    R.append((n,bool(c),e)); print(('PASS ' if c else 'FAIL ')+n, e, flush=True)
def tab(page,t): page.click(f'#tabs button[data-t={t}]')

with sync_playwright() as p:
    b = p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
    ctx = b.new_context(viewport={'width':420,'height':900}, accept_downloads=True)
    page = ctx.new_page(); errs=[]
    page.on('pageerror', lambda e: errs.append(str(e)))
    calls = mock.install(page)
    page.goto('http://localhost:8099/index.html')
    page.wait_for_function("document.querySelector('#surah').options.length>0", timeout=15000)
    page.select_option('#surah','112'); page.wait_for_function("window.__qvm.S.ayat.length==4")
    page.select_option('#to','2'); page.wait_for_function("window.__qvm.S.ayat.length==2")
    # --- states counts with audio ready
    page.click('#play'); page.wait_for_function("window.__qvm.S.audio!==null"); page.click('#play')
    ok('estimated badge hidden for real segs', not page.is_visible('#est'))
    page.select_option('#reciter','2'); page.click('#play'); page.wait_for_function("window.__qvm.S.audio!==null")
    ok('estimated badge visible for reciter w/o segs', page.is_visible('#est'))
    page.click('#play'); page.select_option('#reciter','7')
    page.click('#play'); page.wait_for_function("window.__qvm.S.audio!==null"); page.click('#play')
    tab(page,'style')
    for mode,exp in [('highlight',6),('progressive',6),('ayah',2)]:
        page.click(f'#reveal button[data-v={mode}]')
        ok(f'reveal {mode} -> {exp} states', page.evaluate("window.__qvm.S.states.length")==exp)
    page.click('#reveal button[data-v=highlight]')
    # --- drawCaption outputs: colors via offscreen canvas
    def render(st_over, words_idx=None):
        return page.evaluate("""(o)=>{const q=window.__qvm;Object.assign(q.S.style,o);
          const c=document.createElement('canvas');c.width=540;c.height=960;const x=c.getContext('2d');x.fillStyle='#000';x.fillRect(0,0,540,960);
          const a=q.S.ayat[0]; const words=q.wordsFor(a,0,true,'highlight').filter(w=>w.w.allah);
          q.drawCaption(x,540,960,words,null,'',q.S.style);
          const d=x.getImageData(0,0,540,960).data;let r=0,g=0,b=0,n=0;for(let i=0;i<d.length;i+=4){if(d[i]+d[i+1]+d[i+2]>300){r+=d[i];g+=d[i+1];b+=d[i+2];n++}}
          return n?[Math.round(r/n),Math.round(g/n),Math.round(b/n),n]:[0,0,0,0]}""", st_over)
    gold = render({'allahGold':True,'glow':False,'tr':'none'}); white = render({'allahGold':False,'glow':False,'tr':'none'})
    ok('Allah word gold (r>g>b)', gold[0]>200 and gold[2]<gold[0]-60 and gold[3]>50, str(gold))
    ok('Allah word white (r~g~b)', abs(white[0]-white[2])<25 and white[3]>50, str(white))
    glowon = render({'allahGold':True,'glow':True,'tr':'none'})
    ok('glow adds pixels', glowon[3]>gold[3], f'{glowon[3]} vs {gold[3]}')
    # other color
    other = page.evaluate("""()=>{const q=window.__qvm;Object.assign(q.S.style,{color:'#9AD8FF',glow:false,tr:'none',allahGold:true});
      const c=document.createElement('canvas');c.width=540;c.height=960;const x=c.getContext('2d');x.fillStyle='#000';x.fillRect(0,0,540,960);
      const a=q.S.ayat[0]; const words=q.wordsFor(a,0,true,'highlight').filter(w=>!w.w.allah); q.drawCaption(x,540,960,words,null,'',q.S.style);
      const d=x.getImageData(0,0,540,960).data;let r=0,b=0,n=0;for(let i=0;i<d.length;i+=4){if(d[i]+d[i+1]+d[i+2]>300){r+=d[i];b+=d[i+2];n++}}return [r/n,b/n]}""")
    ok('custom text color applied (blue>red)', other[1]>other[0]+30, str(other))
    page.evaluate("Object.assign(window.__qvm.S.style,{color:'#ffffff',glow:true,tr:'word',allahGold:true})")
    # translation under words: more pixels with word tr than none
    cnt = lambda tr: page.evaluate("""(tr)=>{const q=window.__qvm;q.S.style.tr=tr;const c=document.createElement('canvas');c.width=540;c.height=960;const x=c.getContext('2d');x.fillStyle='#000';x.fillRect(0,0,540,960);
      const a=q.S.ayat[0];q.drawCaption(x,540,960,q.wordsFor(a,0,true,'highlight'),1,a.tr,q.S.style);const d=x.getImageData(0,0,540,960).data;let n=0;for(let i=0;i<d.length;i+=4){if(d[i]>128)n++}return n}""", tr)
    n_none,n_word,n_ayah,n_both = cnt('none'),cnt('word'),cnt('ayah'),cnt('both')
    ok('translation modes differ (none<word, none<ayah, both>=max)', n_none<n_word and n_none<n_ayah and n_both>=max(n_word,n_ayah), f'{n_none},{n_word},{n_ayah},{n_both}')
    page.evaluate("window.__qvm.S.style.tr='word'")
    # bg plan determinism
    plan = lambda seed,sh: page.evaluate("(a)=>window.__qvm.makePlan([{id:'a',type:'video',dur:10},{id:'b',type:'image'},{id:'c',type:'video',dur:30},{id:'d',type:'builtin'}],120,a[0],a[1]).map(p=>p.id+':'+p.off.toFixed(2))", [seed,sh])
    p1,p2,p3 = plan(1,True),plan(1,True),plan(2,True)
    ok('same seed => same plan', p1==p2); ok('different seed => different plan', p1!=p3)
    ok('no immediate repeats', all(p1[i].split(':')[0]!=p1[i+1].split(':')[0] for i in range(len(p1)-1)))
    ids=set(x.split(':')[0] for x in p1); ok('plan uses all selected sources', ids=={'a','b','c','d'})
    tot = page.evaluate("window.__qvm.makePlan([{id:'a',type:'video',dur:10}],100,1,true).reduce((s,p)=>s+p.len,0)")
    ok('plan covers duration', tot>=100, str(tot))
    # --- sizes / presets
    tab(page,'exp')
    dims={}
    for i,(pi) in enumerate(range(4)):
        for qi in range(3):
            page.select_option('#preset',str(pi)); page.select_option('#quality',str(qi))
            dims[(pi,qi)] = page.evaluate("window.__qvm.outSize()")
    ok('presets original', [dims[(i,0)] for i in range(4)]==[[1080,1920],[1920,1080],[1080,1350],[1080,1080]], str([dims[(i,0)] for i in range(4)]))
    ok('720p/540p dims', dims[(0,1)]==[720,1280] and dims[(1,2)]==[960,540] and dims[(2,1)]==[720,900] and dims[(3,2)]==[540,540], str([dims[(0,1)],dims[(1,2)],dims[(2,1)],dims[(3,2)]]))
    ok('info shows actual res', '540×540' in page.inner_text('#expInfo'), page.inner_text('#expInfo'))
    page.select_option('#preset','0'); page.select_option('#quality','0')
    ok('preview aspect follows preset', page.evaluate("(()=>{const c=document.querySelector('#cv');return Math.abs(c.width/c.height-9/16)<0.01})()"))
    page.select_option('#preset','1'); ok('preview landscape', page.evaluate("(()=>{const c=document.querySelector('#cv');return c.width>c.height})()")); page.select_option('#preset','0')
    # --- local background image + video
    tab(page,'bg')
    page.set_input_files('#bgFiles',['/tmp/t/img.png','/tmp/t/vid10.webm'])
    page.wait_for_function("window.__qvm.S.lib.length==6", timeout=10000)
    ok('local bg added (image+video)', page.evaluate("window.__qvm.S.lib.slice(4).map(b=>b.type)")==['image','video'])
    ok('local video duration probed', abs(page.evaluate("window.__qvm.S.lib[5].dur")-10)<0.6, str(page.evaluate("window.__qvm.S.lib[5].dur")))
    labels=page.eval_on_selector_all('#lib label','l=>l.length'); ok('library lists 6 items', labels==6)
    # --- Pexels
    page.fill('#pxKey','BADKEY'); page.click('#pxSave'); page.click('#pxGo')
    page.wait_for_function("document.querySelector('#pxMsg').textContent.includes('غير صحيح')", timeout=8000)
    ok('pexels bad key -> clear message', True)
    page.fill('#pxKey','GOODKEY'); page.click('#pxSave'); page.click('#pxGo')
    page.wait_for_selector('#pxRes > div', timeout=8000); ok('pexels results shown', page.eval_on_selector_all('#pxRes > div','d=>d.length')==1)
    page.click('#pxRes > div'); page.click('#pxDl')
    page.wait_for_function("window.__qvm.S.lib.some(b=>b.id==='pexels_111')", timeout=10000)
    ok('pexels video downloaded into library', True)
    # persistence: reload page keeps saved bg
    page.reload(); page.wait_for_function("document.querySelector('#surah').options.length>0", timeout=15000)
    page.wait_for_function("window.__qvm.S.lib.length>=7", timeout=8000)
    ok('backgrounds persisted across reload (IndexedDB)', page.evaluate("window.__qvm.S.lib.filter(b=>!b.builtin).length")==3, str(page.evaluate("window.__qvm.S.lib.map(b=>b.id)")))
    ok('pexels key persisted', page.input_value('#pxKey')=='GOODKEY')
    # --- font add
    tab(page,'style')
    page.set_input_files('#fontFile','/usr/share/fonts/truetype/freefont/FreeSerif.ttf' if os.path.exists('/usr/share/fonts/truetype/freefont/FreeSerif.ttf') else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
    page.wait_for_function("window.__qvm.S.fonts.length>4", timeout=8000)
    fname=page.evaluate("window.__qvm.S.fonts[4]"); ok('user font added & selected', page.evaluate("window.__qvm.S.style.font")==fname and page.evaluate("(n)=>document.fonts.check('20px \"'+n+'\"')",fname), fname)
    # --- local audio
    tab(page,'text')
    page.select_option('#surah','112'); page.wait_for_function("window.__qvm.S.ayat.length==4")
    page.set_input_files('#localAudio','/tmp/t/local5.mp3')
    page.click('#play'); page.wait_for_function("window.__qvm.S.audio!==null", timeout=8000)
    au=page.evaluate("({s:window.__qvm.S.audio.start,e:window.__qvm.S.audio.end,est:window.__qvm.S.audio.estimated,t:window.__qvm.S.audio.timings.length})")
    ok('local audio: estimated timings over file duration', au['est'] and au['s']==0 and abs(au['e']-5000)<300 and au['t']==4, str(au))
    ok('reciter disabled while local audio', page.is_disabled('#reciter'))
    page.click('#play'); page.click('#clearAudio'); ok('local audio cleared', not page.is_disabled('#reciter'))
    # --- offline error
    print('ERRS', errs)
    print('SUMMARY', sum(1 for r in R if r[1]), '/', len(R))
    b.close()
