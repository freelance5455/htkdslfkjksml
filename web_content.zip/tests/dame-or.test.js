import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState } from '../src/store.js';
import { generateSeasonCalendar, recordResult } from '../src/calendar.js';
import { getDameOrRanking, selectFixtureDamiste, closeDameOrSeason, getDameOrStatus } from '../src/dame-or.js';

test('la Dame d’Or attribue une rencontre homologuée aux titulaires et actualise le classement',()=>{
  const s=createInitialState();generateSeasonCalendar(s);
  const f=s.calendar.fixtures.find(x=>x.divisionId==='super-league');
  const home=s.divisions[0].clubs.find(c=>c.id===f.home),away=s.divisions[0].clubs.find(c=>c.id===f.away);
  selectFixtureDamiste(s,f.id,'home',home.damistes[1].id);
  selectFixtureDamiste(s,f.id,'away',away.damistes[0].id);
  assert.equal(recordResult(s,f.id,3,1, {performance:{home:{moves:12,captures:3,promotions:1,kingMoves:4},away:{moves:10,captures:2,promotions:0,kingMoves:2}}}),true);
  assert.deepEqual(f.damisteSelections,{home:home.damistes[1].id,away:away.damistes[0].id});
  const ranking=getDameOrRanking(s);
  assert.equal(ranking.length,2);
  assert.equal(ranking.find(p=>p.damisteId===home.damistes[1].id).points,3);
  const technical = ranking.find(p=>p.damisteId===home.damistes[1].id);
  assert.deepEqual([technical.moves,technical.captures,technical.promotions,technical.kingMoves],[12,3,1,4]);
  assert.equal(ranking.find(p=>p.damisteId===away.damistes[0].id).points,0);
  assert.equal(recordResult(s,f.id,3,1),false);
  assert.equal(getDameOrStatus(s).recordedMatches,1);
});

test('les choix de titulaire sont limités aux deux damistes du club et aux matchs non joués',()=>{
  const s=createInitialState();generateSeasonCalendar(s);const f=s.calendar.fixtures[0];
  assert.throws(()=>selectFixtureDamiste(s,f.id,'home','unknown'));
  assert.throws(()=>selectFixtureDamiste(s,f.id,'wrong','unknown'));
  recordResult(s,f.id,1,0);
  assert.throws(()=>selectFixtureDamiste(s,f.id,'home',s.divisions[0].clubs[0].damistes[0].id));
});

test('la clôture archive un seul vainqueur et ne duplique pas le palmarès',()=>{
  const s=createInitialState();generateSeasonCalendar(s);const f=s.calendar.fixtures[0];recordResult(s,f.id,1,0);
  const winner=closeDameOrSeason(s,1);assert.ok(winner);
  assert.equal(closeDameOrSeason(s,1),winner);
  assert.equal(s.dameOr.history.length,1);
  assert.equal(s.dameOr.seasons[1].status,'completed');
});

test('la cérémonie de la Dame d’Or se déclenche à la fin officielle quand toutes les rencontres de saison sont terminées',async()=>{
  const { advanceToNextCalendarEvent } = await import('../src/season-engine.js');
  const s=createInitialState();
  s.calendar.currentDay=154;
  s.calendar.officialCalendars={FGD:{regularSeasonEnd:{absoluteDay:154,phase:'end-of-regular-season',authority:'FGD'}}};
  s.calendar.lunarThursdays=Array.from({length:7},(_,i)=>({absoluteDay:4+7*i,lunarMonth:1,lunarDay:1+7*i,weekday:'jeudi'}));
  s.calendar.scheduleValidation={valid:true};
  const result=advanceToNextCalendarEvent(s);
  assert.equal(result.dameOrCeremony,true);
  assert.equal(s.dameOr.seasons[1].status,'completed');
  assert.equal(s.dameOr.history.length,1);
});

test('le moteur de simulation mesure les prises, promotions, déplacements et mouvements de dames', async()=>{
  const { simulateBoardMatch } = await import('../src/board-simulation.js');
  const match=simulateBoardMatch({fixtureId:'DAME-TECH-TEST',season:1});
  for (const side of ['home','away']) {
    assert.ok(match.performance[side].moves > 0);
    for (const key of ['captures','promotions','kingMoves']) assert.ok(Number.isInteger(match.performance[side][key]) && match.performance[side][key] >= 0);
  }
});

test('une simulation homologuée transmet ses statistiques techniques au classement de la Dame d’Or', async()=>{
  const { simulateFixture } = await import('../src/season-engine.js');
  const s=createInitialState();generateSeasonCalendar(s);
  const f=s.calendar.fixtures.find(x=>x.divisionId==='super-league');
  assert.equal(simulateFixture(s,f.id),true);
  const rows=getDameOrRanking(s);assert.equal(rows.length,2);
  assert.ok(rows.every(p=>p.moves>0));
  assert.ok(rows.every(p=>Number.isInteger(p.captures)&&p.captures>=0));
});

test('les anciennes lignes de sauvegarde Dame d’Or sont complétées sans NaN',()=>{
  const s=createInitialState();generateSeasonCalendar(s);const f=s.calendar.fixtures.find(x=>x.divisionId==='super-league');
  const h=s.divisions.flatMap(d=>d.clubs).find(c=>c.id===f.home),a=s.divisions.flatMap(d=>d.clubs).find(c=>c.id===f.away);
  s.dameOr={version:1,seasons:{1:{season:1,status:'in-progress',players:{[h.damistes[0].id]:{damisteId:h.damistes[0].id,name:h.damistes[0].name,clubId:h.id,clubName:h.name,played:0,won:0,drawn:0,lost:0,points:0,goalsFor:0,goalsAgainst:0}},fixtureIds:[]}},history:[]};
  f.damisteSelections={home:h.damistes[0].id,away:a.damistes[0].id};
  recordResult(s,f.id,2,0,{performance:{home:{moves:5,captures:1,promotions:0,kingMoves:2},away:{moves:4,captures:0,promotions:0,kingMoves:1}}});
  const row=getDameOrRanking(s).find(p=>p.damisteId===h.damistes[0].id);assert.equal(row.captures,1);assert.equal(row.moves,5);
});

test('saison complète : le classement Dame d’Or évolue après chacune des 396 rencontres et la cérémonie clôture la saison sans toucher aux sept autres compétitions', async()=>{
  const { simulateFixture } = await import('../src/season-engine.js');
  const { advanceToNextCalendarEvent } = await import('../src/season-engine.js');
  const { setOfficialLunarThursdays, setOfficialRegularSeasonEndDate } = await import('../src/competition-calendar.js');
  const s=createInitialState();
  const fixtures=generateSeasonCalendar(s);
  assert.equal(fixtures.length,396,'deux divisions actives de 12 clubs doivent produire 396 rencontres aller-retour');
  const otherCompetitions=structuredClone(s.competitions.filter(c=>c.id!=='dame-or'));
  const previousPlayed=new Map();
  for(let index=0;index<fixtures.length;index++){
    const fixture=fixtures[index];
    const home=s.divisions.flatMap(d=>d.clubs).find(c=>c.id===fixture.home);
    const away=s.divisions.flatMap(d=>d.clubs).find(c=>c.id===fixture.away);
    const before=getDameOrRanking(s);
    const beforePlayed=new Map(before.map(row=>[row.damisteId,row.played]));
    assert.equal(simulateFixture(s,fixture.id),true,`la rencontre ${fixture.id} doit être homologuée`);
    const ranking=getDameOrRanking(s);
    const status=getDameOrStatus(s);
    assert.equal(status.recordedMatches,index+1,`compteur Dame d’Or après ${fixture.id}`);
    assert.equal(fixture.dameOrRecorded,true,`la rencontre ${fixture.id} doit être enregistrée une seule fois`);
    assert.equal(ranking.length,new Set(ranking.map(row=>row.damisteId)).size,'aucun damiste en double dans le classement');
    assert.ok(ranking.every(row=>Number.isFinite(row.points)&&Number.isFinite(row.moves)&&Number.isFinite(row.captures)&&Number.isFinite(row.promotions)&&Number.isFinite(row.kingMoves)));
    assert.ok(ranking.every((row,i)=>i===0||ranking[i-1].points>=row.points),'classement trié par points');
    const changed=ranking.filter(row=>row.played>(beforePlayed.get(row.damisteId)||0));
    assert.equal(changed.length,2,'exactement deux titulaires progressent après une rencontre');
    assert.deepEqual(new Set(changed.map(row=>row.clubId)),new Set([home.id,away.id]));
    assert.ok(changed.every(row=>row.played===(beforePlayed.get(row.damisteId)||0)+1));
    assert.equal(simulateFixture(s,fixture.id),false,'une rencontre déjà homologuée ne doit pas être comptée deux fois');
    assert.equal(getDameOrStatus(s).recordedMatches,index+1);
    previousPlayed.set(fixture.id,true);
  }
  assert.equal(s.dameOr.seasons[1].fixtureIds.length,396);
  assert.equal(s.calendar.fixtures.filter(f=>f.status==='played').length,396);
  assert.deepEqual(s.competitions.filter(c=>c.id!=='dame-or'),otherCompetitions,'les sept autres compétitions restent strictement inchangées');
  setOfficialLunarThursdays(s,Array.from({length:7},(_,i)=>({absoluteDay:4+7*i,lunarMonth:1,lunarDay:1+7*i,weekday:'jeudi'})));
  setOfficialRegularSeasonEndDate(s,{absoluteDay:154,phase:'end-of-regular-season',authority:'FGD'});
  s.calendar.currentDay=154;
  const ceremony=advanceToNextCalendarEvent(s);
  assert.equal(ceremony.dameOrCeremony,true,'la cérémonie doit être déclenchée à la clôture officielle');
  assert.equal(s.dameOr.seasons[1].status,'completed');
  assert.equal(s.dameOr.seasons[1].finalRanking.length,getDameOrRanking(s).length);
  assert.equal(s.dameOr.history.length,1,'une seule entrée au palmarès');
  assert.equal(s.dameOr.history[0].winnerId,s.dameOr.seasons[1].winnerId);
  assert.equal(closeDameOrSeason(s,1),s.dameOr.seasons[1].winnerId,'la clôture répétée ne change pas le vainqueur');
  assert.equal(s.dameOr.history.length,1,'aucun doublon au palmarès après une seconde clôture');
  assert.deepEqual(s.competitions.filter(c=>c.id!=='dame-or'),otherCompetitions,'les sept autres compétitions restent intactes après la cérémonie');
},{timeout:120000});
