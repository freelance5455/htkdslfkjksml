import assert from 'node:assert/strict';
const memory = new Map();
globalThis.localStorage = {
  getItem: key => memory.has(key) ? memory.get(key) : null,
  setItem: (key, value) => memory.set(key, String(value)),
  removeItem: key => memory.delete(key)
};
globalThis.CustomEvent = class CustomEvent { constructor(type) { this.type = type; } };
globalThis.window = { dispatchEvent() {}, addEventListener() {} };
const Data = await import('../www/js/data.js');
const Engine = await import('../www/js/engine.js');
const deck = Data.DB.decks[0];
assert.equal(deck.cards.length, 24, 'starter deck must have 24 cards');
const deckKinds = deck.cards.map(id => Data.DB.cards.find(card => card.id === id)?.kind);
assert(deckKinds.includes('creature') && deckKinds.some(kind => kind !== 'creature'), 'starter deck contains creatures and action cards');
const creature = Data.DB.cards.find(card => card.kind === 'creature');

// Classic duel: summon, attack, CPU turn, then player's turn.
Engine.startGame({mode:'classic', deckId:deck.id, difficulty:'normal'});
let p1 = Engine.side();
let p2 = Engine.opponent();
p1.hand = [{...creature, id:'test-creature-1', atk:35, cost:2}];
p1.energy = 5;
p2.hand.unshift({...creature, id:'test-cpu-creature', atk:20, cost:2});
Engine.selectHand(0);
Engine.playCard();
assert.equal(p1.active.name, creature.name);
Engine.attack();
assert.equal(p2.life, 65, 'direct attack should reduce opponent life');
Engine.endTurn();
let state = Engine.snapshot();
assert.equal(state.active, 'p1', 'CPU turn should return control to player one');
assert(p2.active, 'CPU should summon a creature from a guaranteed card');
assert(state.sides.p1.energy >= 4, 'player energy should rise at the next turn');

// Status effects and stun skip the complete enemy turn.
Engine.startGame({mode:'classic', deckId:deck.id});
p1 = Engine.side(); p2 = Engine.opponent();
p1.hand = [{...creature,id:'stun-creature',ability:'stun',cost:2}];p1.energy=8;
p1.hand[0].ability='stun';
Engine.selectHand(0);Engine.playCard();
p1.active.ability='stun';
Engine.activateAbility();
assert.equal(p2.stun,1);
const beforeHp=p1.life;
Engine.endTurn();
state=Engine.snapshot();
assert.equal(state.active,'p1');
assert.equal(state.sides.p2.stun,0,'stun clears after skipped turn');
assert.equal(state.sides.p1.life,beforeHp,'stunned CPU cannot attack');

// Same-device mode hides the hand between players and changes active side only after confirmation.
Engine.startGame({mode:'same',deckId:deck.id,secondDeckId:deck.id});
Engine.endTurn();state=Engine.snapshot();
assert.equal(state.pendingPass,true);assert.equal(state.active,'p2');
Engine.passToNext();state=Engine.snapshot();
assert.equal(state.pendingPass,false);assert.equal(state.active,'p2');
Engine.endTurn();state=Engine.snapshot();assert.equal(state.pendingPass,true);assert.equal(state.active,'p1');
Engine.passToNext();assert.equal(Engine.snapshot().active,'p1');

// Boss victory and local duel must not alter ranked profile rewards.
Engine.startGame({mode:'boss',deckId:deck.id});
p1=Engine.side();p1.active={...creature,id:'boss-killer',atk:500,def:50,hp:300,currentHp:300};
Engine.attack();state=Engine.snapshot();assert.equal(state.winner,'p1','defeating the boss must end the battle');
const winsBefore=Data.DB.wins,coinsBefore=Data.DB.coins;
Engine.startGame({mode:'same',deckId:deck.id,secondDeckId:deck.id});
p1=Engine.side();p1.active={...creature,id:'local-killer',atk:500,def:50,hp:300,currentHp:300};
Engine.attack();state=Engine.snapshot();assert.equal(state.winner,'p1');assert.equal(Data.DB.wins,winsBefore);assert.equal(Data.DB.coins,coinsBefore);


// Every active skill in the card catalog executes without throwing, and passive skills stay passive.
for (const [skill, meta] of Object.entries(Data.ABILITIES)) {
  Engine.startGame({mode:'training', deckId:deck.id});
  p1=Engine.side();p2=Engine.opponent();
  p1.active={...creature,id:'skill-'+skill,ability:skill,currentHp:creature.hp};
  p1.energy=10;p1.life=65;p2.active={...creature,id:'target-'+skill,currentHp:creature.hp};
  p2.lastAbility='burn';
  if(['none','revive'].includes(skill)){
    assert.equal(Engine.canUseAbility(),false,skill+' should be passive');
  }else{
    assert.equal(Engine.canUseAbility(),true,skill+' should be activatable with enough energy');
    Engine.activateAbility();
    assert.equal(p1.usedAbility,true,skill+' should consume the ability action');
  }
}

// Action card types use their effects and are removed from the hand.
for (const [kind, ability] of [['spell','fireball'],['gear','equipBlade'],['trap','trapSpike'],['support','boostTeam']]) {
  Engine.startGame({mode:'training',deckId:deck.id});
  p1=Engine.side();p2=Engine.opponent();p1.active={...creature,id:'action-target-'+ability,currentHp:creature.hp};
  p1.energy=10;p1.hand=[{id:'action-'+ability,name:ability,kind,element:'Neutro',cost:1,ability,atk:30,def:20,hp:50}];
  Engine.selectHand(0);Engine.playCard();
  assert.equal(p1.hand.length,0,ability+' card should leave hand after play');
}

// The chapter boss configuration changes the real engine state, not only a UI snapshot.
Engine.startGame({mode:'boss',deckId:deck.id});
Engine.configureBoss({name:'Colosso Carmesim',element:'Chama',attackBonus:12,hp:360,ability:'burn'});
state=Engine.snapshot();
assert.equal(state.sides.p2.name,'Colosso Carmesim');
assert.equal(state.sides.p2.life,360);
assert.equal(state.sides.p2.active.currentHp,360);
assert.equal(state.sides.p2.active.element,'Chama');

// Bench slots and tactical switching are functional.
Engine.startGame({mode:'training',deckId:deck.id});
p1=Engine.side();
p1.active={...creature,id:'front',currentHp:creature.hp};
p1.bench=[{...creature,id:'reserve',name:'Reserva',currentHp:creature.hp}];
p1.energy=5;Engine.switchBench(0);
assert.equal(p1.active.name,'Reserva');assert.equal(p1.bench[0].id,'front');assert.equal(p1.energy,4);

// Basic mode initialization is valid across all solo modes.
for (const mode of ['classic','zoeira','boss','survival','draft','quick','training','tournament']) {
  Engine.startGame({mode,deckId:deck.id});
  state=Engine.snapshot();
  assert.equal(state.mode,mode);
  assert.equal(state.sides.p1.hand.length,5);
  assert(state.sides.p1.deck.length+state.sides.p1.hand.length===24);
}

console.log('FOTO DUEL smoke tests: OK');
