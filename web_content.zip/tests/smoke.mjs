// Run: node tests/smoke.mjs   (no dependencies; uses fake Anthropic + Stripe upstreams)
import http from 'node:http'; import crypto from 'node:crypto'; import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path';
import { createServer } from '../server/server.mjs';
let pass = 0, fail = 0; const ok = (n, c) => { c ? pass++ : (fail++, console.log('FAIL', n)); if (c) console.log('PASS', n); };
const listen = (h) => new Promise(r => { const s = http.createServer(h); s.listen(0, '127.0.0.1', () => r(s)); });
let aiMode = 'ok';
const fakeAi = await listen((req, res) => { req.resume(); req.on('end', () => { if (aiMode === 'fail') { res.writeHead(500); return res.end('{}'); } res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify({ content: [{ type: 'text', text: 'answer' }] })); }); });
const fakeStripe = await listen((req, res) => { req.resume(); req.on('end', () => { res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify({ url: 'https://stripe.test/x', id: 'cs_1' })); }); });
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'an-'));
const app = createServer({ port: 0, dataDir: dir, anthropicKey: 'k', anthropicBase: `http://127.0.0.1:${fakeAi.address().port}`, stripeKey: 'sk', stripeBase: `http://127.0.0.1:${fakeStripe.address().port}`, stripeWebhookSecret: 'whsec_test', priceIds: { pro: 'price_p', business: 'price_b' }, trustProxy: 1, ipAiPerDay: 5, appFile: path.join(process.cwd(), 'index.html'), publicDir: path.join(process.cwd(), 'public') });
await new Promise(r => app.server.listen(0, '127.0.0.1', r)); const base = `http://127.0.0.1:${app.server.address().port}`;
const call = (p, o = {}) => fetch(base + p, { ...o, headers: { 'content-type': 'application/json', ...(o.headers || {}) } });
const cid = 'c_' + crypto.randomBytes(8).toString('hex');
// security headers + CSP
let r = await call('/'); const csp = r.headers.get('content-security-policy') || '';
ok('app served', r.status === 200 && (await r.text()).includes('AccoNova'));
ok('csp has manifest/worker self + frame-ancestors none', csp.includes("manifest-src 'self'") && csp.includes("worker-src 'self'") && csp.includes("frame-ancestors 'none'"));
ok('hsts + nosniff', !!r.headers.get('strict-transport-security') && r.headers.get('x-content-type-options') === 'nosniff');
ok('sw served', (await call('/sw.js')).status === 200); ok('manifest served', (await call('/manifest.webmanifest')).status === 200);
ok('source not served', (await call('/server/server.mjs')).status === 404 && (await call('/tests/smoke.mjs')).status === 404 && (await call('/package.json')).status === 404);
// entitlement token verifies with the published key
const cfg = await (await call('/api/config')).json(); const ent = await (await call('/api/entitlement?cid=' + cid)).json();
const pub = crypto.createPublicKey({ key: cfg.publicKey, format: 'jwk' });
ok('entitlement signature valid', crypto.verify('sha256', Buffer.from(ent.raw), { key: pub, dsaEncoding: 'ieee-p1363' }, Buffer.from(ent.sig, 'base64')));
ok('entitlement free by default', JSON.parse(ent.raw).plan === 'free');
ok('bad cid rejected', (await call('/api/entitlement?cid=../etc')).status === 400);
// AI: per-company daily limit (free = 3)
const ai = (c, xff) => call('/api/ai', { method: 'POST', headers: { 'x-forwarded-for': xff }, body: JSON.stringify({ cid: c, question: 'How is cash?', lang: 'en', context: { a: 1 } }) });
let codes = []; for (let i = 0; i < 4; i++) codes.push((await ai(cid, '9.9.9.9, 10.0.0.1')).status);
ok('free plan: 3 answers then 429', codes.join() === '200,200,200,429');
// spoofing the LEFT side of X-Forwarded-For must not give a fresh IP quota (limit 5/day/IP)
codes = []; for (let i = 0; i < 5; i++) codes.push((await ai('c_' + crypto.randomBytes(6).toString('hex'), `${i}.${i}.${i}.${i}, 10.0.0.1`)).status);
ok('IP quota cannot be bypassed by forging XFF', codes.slice(-1)[0] === 429 && codes.filter(c => c === 200).length === 2);
// upstream failure refunds the quota
aiMode = 'fail'; const c2 = 'c_' + crypto.randomBytes(6).toString('hex'); const bad = await ai(c2, '7.7.7.7, 10.0.0.2'); aiMode = 'ok';
ok('upstream failure -> 502', bad.status === 502);
const good = await (await ai(c2, '7.7.7.7, 10.0.0.2')).json(); ok('quota refunded after failure (3 left -> 2)', good.remaining === 2);
// checkout
r = await call('/api/checkout', { method: 'POST', body: JSON.stringify({ cid, plan: 'pro' }) }); ok('checkout url', (await r.json()).url === 'https://stripe.test/x');
ok('checkout rejects unknown plan', (await call('/api/checkout', { method: 'POST', body: JSON.stringify({ cid, plan: 'admin' }) })).status === 400);
// webhook: signature, replay, upgrade
const ev = { id: 'evt_1', type: 'checkout.session.completed', data: { object: { client_reference_id: cid, metadata: { cid, plan: 'pro' }, customer: 'cus_1', subscription: 'sub_1' } } };
const body = JSON.stringify(ev), t = Math.floor(Date.now() / 1000), sign = (b, tt = t, sec = 'whsec_test') => `t=${tt},v1=${crypto.createHmac('sha256', sec).update(`${tt}.${b}`).digest('hex')}`;
ok('webhook bad signature -> 400', (await call('/api/stripe/webhook', { method: 'POST', headers: { 'stripe-signature': sign(body, t, 'wrong') }, body })).status === 400);
ok('webhook old timestamp -> 400', (await call('/api/stripe/webhook', { method: 'POST', headers: { 'stripe-signature': sign(body, t - 3600) }, body })).status === 400);
ok('webhook ok', (await call('/api/stripe/webhook', { method: 'POST', headers: { 'stripe-signature': sign(body) }, body })).status === 200);
const dup = await (await call('/api/stripe/webhook', { method: 'POST', headers: { 'stripe-signature': sign(body) }, body })).json(); ok('webhook replay ignored', dup.duplicate === true);
const ent2 = await (await call('/api/entitlement?cid=' + cid)).json(); ok('plan upgraded to pro, signed', JSON.parse(ent2.raw).plan === 'pro' && crypto.verify('sha256', Buffer.from(ent2.raw), { key: pub, dsaEncoding: 'ieee-p1363' }, Buffer.from(ent2.sig, 'base64')));
ok('oversized body rejected', (await call('/api/ai', { method: 'POST', body: JSON.stringify({ cid, question: 'x'.repeat(60000) }) })).status === 413);
ok('bad json -> 400', (await call('/api/ai', { method: 'POST', body: '{nope' })).status === 400);
console.log(`\n${pass} passed, ${fail} failed`); app.server.close(); fakeAi.close(); fakeStripe.close(); process.exit(fail ? 1 : 0);
