import assert from "node:assert/strict";
import { chromium } from "playwright";

function textPdf() {
  const lines = Array.from({ length: 42 }, (_, i) =>
    `Sentence ${i + 1}. A readable book keeps every word and gives each line enough room on a phone.`,
  );
  const stream = ["BT", "/F1 9 Tf", "14 TL", "48 800 Td", ...lines.flatMap((line) => [`(${line}) Tj`, "T*"]), "ET"].join("\n");
  const objects = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`,
  ];
  let out = "%PDF-1.4\n";
  const offsets = objects.map((body, i) => {
    const offset = out.length;
    out += `${i + 1} 0 obj\n${body}\nendobj\n`;
    return offset;
  });
  const xref = out.length;
  out += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  offsets.forEach((offset) => { out += `${String(offset).padStart(10, "0")} 00000 n \n`; });
  out += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return Buffer.from(out, "ascii");
}

const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({
  viewport: { width: 390, height: 844 },
  deviceScaleFactor: 2,
  isMobile: true,
  hasTouch: true,
});
const page = await context.newPage();
const failures = [];
page.on("pageerror", (error) => failures.push(error.message));

try {
  await page.goto(process.env.TEST_URL || "http://127.0.0.1:5173/", {
    waitUntil: "domcontentloaded",
  });
  await page.locator('input[type="file"]').setInputFiles({
    name: "smoke-book.pdf",
    mimeType: "application/pdf",
    buffer: textPdf(),
  });
  await page.getByRole("button", { name: "باز کردن smoke-book" }).click();
  await page.locator(".reflow-text").first().waitFor({ timeout: 60000 });
  await page.getByRole("button", { name: "فهمیدم" }).click();
  await page.waitForTimeout(1800);

  const source = await page.locator(".reflow-text").first().textContent();
  assert(source && source.length > 80, "Extracted text should be visible");
  assert.equal(await page.locator("main canvas").count(), 0, "Reader must not display a PDF canvas");
  const initial = await page.locator(".reflow-text").first().evaluate((el) => {
    const css = getComputedStyle(el);
    return {
      fontSize: css.fontSize,
      lines: el.getBoundingClientRect().height / parseFloat(css.lineHeight),
    };
  });
  assert.equal(initial.fontSize, "24px");
  assert(initial.lines <= 25.08, `Page should contain <=25 rendered lines: ${initial.lines}`);
  const readArea = page.locator('[role="group"] .overflow-y-auto').first();
  const readBounds = await readArea.boundingBox();
  assert(readBounds);
  await page.mouse.move(readBounds.x + readBounds.width / 2, readBounds.y + readBounds.height / 2);
  await page.mouse.wheel(0, 280);
  await page.waitForTimeout(150);
  assert(
    (await readArea.evaluate((el) => el.scrollTop)) > 0,
    "Long reflowed pages should remain vertically scrollable",
  );
  const pageBefore = await page.locator("footer input[type=range]").inputValue();
  const rect = await page.locator("main").boundingBox();
  assert(rect);
  await page.mouse.move(rect.x + rect.width * 0.8, rect.y + rect.height * 0.4);
  await page.mouse.down();
  await page.mouse.move(rect.x + rect.width * 0.15, rect.y + rect.height * 0.4, { steps: 8 });
  await page.mouse.up();
  await page.waitForTimeout(480);
  const pageAfter = await page.locator("footer input[type=range]").inputValue();
  assert.equal(Number(pageAfter), Number(pageBefore) + 1, "Horizontal swipe should turn page");
  await page.waitForTimeout(180);
  await page.mouse.move(rect.x + rect.width * 0.5, rect.y + rect.height * 0.4);
  await page.mouse.wheel(95, 0);
  await page.waitForTimeout(440);
  assert.equal(
    Number(await page.locator("footer input[type=range]").inputValue()),
    Number(pageAfter) + 1,
    "Horizontal trackpad scrolling should also turn page",
  );

  await page.getByRole("button", { name: "تنظیمات نوشته" }).click();
  const sheet = page.locator(".fixed.inset-0.z-50");
  const sliders = sheet.locator('input[type="range"]');
  await sliders.nth(0).evaluate((el) => {
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(el, "32");
    el.dispatchEvent(new Event("input", { bubbles: true }));
  });
  await page.waitForTimeout(400);
  await sliders.nth(1).evaluate((el) => {
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(el, "12");
    el.dispatchEvent(new Event("input", { bubbles: true }));
  });
  await page.getByRole("button", { name: "ادامهٔ خواندن" }).click();
  await page.locator(".reflow-text").first().waitFor({ timeout: 60000 });
  await page.waitForTimeout(500);
  const updated = await page.locator(".reflow-text").first().evaluate((el) => {
    const css = getComputedStyle(el);
    return {
      fontSize: css.fontSize,
      lines: el.getBoundingClientRect().height / parseFloat(css.lineHeight),
    };
  });
  assert.equal(updated.fontSize, "32px", "Font setting should change actual text font");
  assert(updated.lines <= 12.08, `New page should contain <=12 lines: ${updated.lines}`);

  const savedPage = await page.locator("footer input[type=range]").inputValue();
  await page.getByRole("button", { name: "بازگشت به کتابخانه" }).click();
  await page.reload({ waitUntil: "domcontentloaded" });
  await page.locator("button.group").first().click();
  await page.locator(".reflow-text").first().waitFor({ timeout: 60000 });
  const reopenedPage = await page.locator("footer input[type=range]").inputValue();
  assert.equal(reopenedPage, savedPage, "Reading position should persist across reload");
  assert.equal(failures.length, 0, `Browser errors: ${failures.join(" | ")}`);
  console.log("PASS mobile PDF text extraction, 25-line layout, swipe, settings, persistence");
} finally {
  await browser.close();
}