import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState } from '../src/store.js';
import { generateSeasonCalendar } from '../src/calendar.js';
import { createClubCupSeason } from '../src/club-cup.js';
import { createGalacticCupSeason } from '../src/galactic-cup.js';
import { createFederalCupSeason } from '../src/federal-cup.js';
import { createChampionsLeagueSeason } from '../src/champions-league.js';
import { setOfficialLunarThursdays, COMPETITION_MATCH_DAYS, weekdayForSeasonDay } from '../src/competition-calendar.js';
import { COMPETITIONS } from '../src/config.js';

function setup(){const s=createInitialState();s.season=12;for(const c of s.competitions)c.calendarEngineReady=true;generateSeasonCalendar(s);createGalacticCupSeason(s);createClubCupSeason(s);createChampionsLeagueSeason(s);createFederalCupSeason(s);setOfficialLunarThursdays(s,Array.from({length:7},(_,i)=>({weekday:'jeudi',lunarMonth:i<4?1:2,lunarDay:4+i*7,absoluteDay:4+i*7})));return s;}

test('chaque compétition de la saison a son propre jour de la semaine, distinct des autres', () => {
  const days = Object.values(COMPETITION_MATCH_DAYS).map(d => d.weekday);
  assert.equal(new Set(days).size, days.length);
  assert.deepEqual(Object.fromEntries(Object.entries(COMPETITION_MATCH_DAYS).map(([k, v]) => [k, v.weekday])), {
    championnat: 'samedi', 'champions-league': 'mardi', 'coupe-galactique': 'mercredi', 'coupe-des-clubs': 'jeudi', 'coupe-federal': 'dimanche'
  });
});

test('aucun événement de saison ne se joue le lundi ni le même jour qu’un autre', () => {
  const s = setup();
  const events = s.calendar.competitionEvents;
  assert.ok(events.length > 0);
  for (const e of events) {
    assert.notEqual(weekdayForSeasonDay(e.absoluteDay), 'lundi');
    const expected = { championnat: 'samedi', 'champions-league': 'mardi', 'coupe-galactique': 'mercredi', 'coupe-des-clubs': 'jeudi', 'coupe-federal': 'dimanche' }[e.competitionId];
    if (expected) assert.equal(e.weekday, expected, e.competitionId);
  }
  assert.equal(new Set(events.map(e => e.absoluteDay)).size, events.length);
  assert.equal(s.calendar.scheduleValidation.valid, true);
});

test('la Coupe Fédéral est organisée par l’AGD', () => {
  assert.equal(COMPETITIONS.find(c => c.id === 'coupe-federal').authority, 'AGD');
  const s = setup();
  assert.ok(s.calendar.competitionEvents.filter(e => e.competitionId === 'coupe-federal').every(e => e.authority === 'AGD'));
});
