import test from 'node:test';
import assert from 'node:assert/strict';
import { MANAGER_AVATARS, MANAGER_EXPERIENCES, MANAGER_PROFILES, MANAGER_NATIONALITIES, validateManagerDraft, saveManagerDraft } from '../src/manager-setup.js';
const valid={firstName:'Awa',lastName:'Koné',avatar:'strategist',nationality:'Terra Unie',sex:'Femme',experience:'confirme',profile:'tacticien'};
test('catalogue de création du manager : avatars, expériences, profils et origines galactiques',()=>{assert.equal(MANAGER_AVATARS.length,6);assert.equal(MANAGER_EXPERIENCES.length,5);assert.equal(MANAGER_PROFILES.length,4);assert.equal(MANAGER_NATIONALITIES.length,24);assert.ok(MANAGER_NATIONALITIES.includes('Terra Unie'));assert.ok(!MANAGER_NATIONALITIES.includes('France'));});
test('validation du profil de manager',()=>{assert.equal(validateManagerDraft(valid).firstName,'Awa');assert.throws(()=>validateManagerDraft({...valid,firstName:''}),/prénom et le nom/);assert.throws(()=>validateManagerDraft({...valid,avatar:'unknown'}),/avatar/);assert.throws(()=>validateManagerDraft({...valid,experience:'expert'}),/expérience/);});
test('sauvegarde du brouillon sans lancer prématurément la carrière',()=>{const state={career:{manager:null,managerDraft:null,started:false}};const draft=saveManagerDraft(state,valid);assert.equal(draft.displayName,'Awa Koné');assert.equal(state.career.manager,null);assert.equal(state.career.started,false);assert.equal(state.career.managerDraft.profile,'tacticien');});

test('interface 5.0-C présente les champs et garde le jeu masqué avant la carrière', async()=>{
  const {readFile}=await import('node:fs/promises');
  const html=await readFile(new URL('../index.html',import.meta.url),'utf8');
  const app=await readFile(new URL('../src/app.js',import.meta.url),'utf8');
  for(const field of ['firstName','lastName','nationality','experience','profile','avatar']) assert.ok(app.includes(field),`champ manquant: ${field}`);
  assert.match(html,/career-setup-only \.career-rail\{display:none\}/);
  assert.match(app,/saveManagerDraft\(state,data\)/);
});
