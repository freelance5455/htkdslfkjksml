const { chromium } = require('playwright');
let ok = 0, mal = [];
const t = (n, c, d) => { if (c) { ok++; console.log('  ✔', n); } else { mal.push(n + (d ? ' → ' + d : '')); console.log('  ✘', n, d || ''); } };
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 390, height: 844 }, locale: 'es-CO', timezoneId: 'America/Bogota', isMobile: true, hasTouch: true, permissions: ['clipboard-read', 'clipboard-write'] });
  const p = await c.newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message)); p.on('console', (m) => m.type() === 'error' && errs.push(m.text()));
  await p.goto('http://localhost:8765/index.html'); await p.waitForSelector('.vista'); await p.waitForFunction(() => App.S.costos && App.S.productos.length);
  const w = (ms) => p.waitForTimeout(ms || 400); const ir = async (h) => { await p.evaluate((h) => { location.hash = '#/' + h; }, h); await w(); };
  console.log('Copia como texto (para apps tipo APK / WebView)');
  // Simula un WebView: sin Compartir, sin descargas ni portapapeles moderno
  await p.evaluate(() => { navigator.canShare = undefined; navigator.share = undefined; Object.defineProperty(navigator, 'clipboard', { value: undefined, configurable: true }); window.__copiado = null; document.execCommand = (c) => { if (c === 'copy') { const a = document.activeElement; window.__copiado = a && a.value; return true; } return false; }; });
  await p.evaluate(async () => { for (const [m, c] of [[300000, 'A'], [120000, 'B']]) await App.guardarVenta({ fecha: MC.hoyISO(), hora: '', referencia: '', cliente: c, medio: 'efectivo', monto: m, observaciones: '', tipo: 'rapida', descuenta: false }, []); await DB.transaccion(['gastos'], (a) => a.put('gastos', { tipo: 'operativo', monto: 5000, fecha: MC.hoyISO(), categoria: 'x', descripcion: 'y', creado: Date.now() })); await App.recargar(); });
  await p.evaluate(async () => { const pr = App.S.productos[0]; pr.precioTienda = 2500; await DB.transaccion(['productos'], (a) => a.put('productos', pr)); await App.recargar(); });
  await ir('respaldo'); await p.click('[data-a="copiarRespaldo"]'); await w(600);
  const copiado = await p.evaluate(() => window.__copiado);
  t('Copia como texto: el texto copiado es un JSON de Café Mero Campo', !!copiado && JSON.parse(copiado).app === 'cafe-mero-campo' && JSON.parse(copiado).datos.ventas.length === 2);
  t('Muestra el texto en pantalla para copiarlo a mano si hace falta', (await p.inputValue('#txtRespaldo')).length > 1000);
  t('La copia queda marcada como hecha hoy', await p.evaluate(() => App.S.ajustes.ultimoRespaldo === MC.hoyISO()));
  // borrar todo y restaurar pegando
  await p.evaluate(async () => { await DB.borrarTodo(); await App.recargar(); await App.sembrar(); });
  t('(Se pierden los datos)', (await p.evaluate(() => App.S.ventas.length)) === 0);
  await ir('respaldo');
  await p.click('[data-a="restaurarTexto"]'); await w(300);
  t('Restaurar sin pegar nada: avisa', /Primero pega/.test(await p.innerText('#toasts')));
  await p.fill('#pegarRespaldo', copiado.slice(0, 500)); await p.click('[data-a="restaurarTexto"]'); await w(300);
  t('Texto incompleto: se rechaza sin tocar nada', /no es una copia válida|incompleto/.test(await p.innerText('#toasts')) && (await p.evaluate(() => App.S.ventas.length)) === 0);
  await p.fill('#pegarRespaldo', copiado); await p.click('[data-a="restaurarTexto"]'); await p.waitForSelector('[data-x="si"]');
  t('Pide confirmación mostrando el contenido', /2 ventas/.test(await p.innerText('#modales')));
  await p.click('[data-x="si"]'); await w(800);
  t('Datos restaurados desde el texto pegado (2 ventas, precio 2.500, gasto)', await p.evaluate(() => App.S.ventas.length === 2 && App.S.productos[0].precioTienda === 2500 && App.S.gastos.length === 1));
  // informe copiar
  await ir('informes'); await p.selectOption('[data-c="tipoInforme"]', 'ventas_detalle'); await w(300);
  await p.evaluate(() => { window.__copiado = null; }); await p.click('[data-a="copiarInforme"]'); await w(400);
  const inf = await p.evaluate(() => window.__copiado);
  t('Informe copiado como texto con encabezados y totales', !!inf && /Fecha;Hora;Referencia/.test(inf) && /420000/.test(inf), (inf || '').slice(0, 80));
  t('Sin errores en consola', errs.length === 0, errs.join('|'));
  await b.close(); console.log(`\n${ok} correctas, ${mal.length} con fallo`); if (mal.length) { mal.forEach((m) => console.log(' -', m)); process.exit(1); }
})().catch((e) => { console.error(e); process.exit(2); });
