import { build } from 'esbuild';
import path from 'path';
const shim = path.resolve('tests/three-shim.ts');
await build({
  entryPoints: ['tests/game.test.ts'], bundle: true, platform: 'node', format: 'esm', outfile: 'tests/.out/game.mjs', logLevel: 'error',
  plugins: [{ name: 'three-shim', setup(b) { b.onResolve({ filter: /^three$/ }, a => (a.importer === shim ? undefined : { path: shim })); } }],
});
await import('./.out/game.mjs');
