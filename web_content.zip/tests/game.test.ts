// End-to-end gameplay simulation of the real Game class (renderer faked). Run: node tests/game.mjs
import * as THREE from 'three';

// ---------- DOM / browser stubs with listener accounting ----------
const listeners = { window: 0, document: 0 };
const ctxProxy: any = new Proxy({}, {
  get(_t, p) {
    if (p === 'createImageData') return (w: number, h: number) => ({ data: new Uint8ClampedArray(w * h * 4) });
    if (p === 'createRadialGradient' || p === 'createLinearGradient') return () => ({ addColorStop() {} });
    return () => {};
  }, set() { return true; },
});
const mkEl = (): any => ({ style: {}, width: 800, height: 450, clientWidth: 800, clientHeight: 450, getContext: (t: string) => (t === '2d' ? ctxProxy : null), appendChild() {}, addEventListener() {}, removeEventListener() {}, remove() {} });
const mem = new Map<string, string>();
(globalThis as any).localStorage = { getItem: (k: string) => mem.get(k) ?? null, setItem: (k: string, v: string) => mem.set(k, v) };
(globalThis as any).document = { createElement: mkEl, addEventListener: () => { listeners.document++; }, removeEventListener: () => { listeners.document--; }, pointerLockElement: null, exitPointerLock() {} };
(globalThis as any).window = { matchMedia: () => ({ matches: false }), devicePixelRatio: 1, innerWidth: 800, innerHeight: 450, addEventListener: () => { listeners.window++; }, removeEventListener: () => { listeners.window--; } };
(globalThis as any).matchMedia = () => ({ matches: false });
Object.defineProperty(globalThis, 'navigator', { value: { hardwareConcurrency: 8, maxTouchPoints: 0 }, configurable: true });
let rafCb: ((t: number) => void) | null = null;
(globalThis as any).requestAnimationFrame = (cb: (t: number) => void) => { rafCb = cb; return 1; };
(globalThis as any).cancelAnimationFrame = () => { rafCb = null; };
let now = 1000;
(globalThis as any).performance = { now: () => now };

let pass = 0, fail = 0; const out: string[] = [];
const check = (n: string, c: boolean, info = '') => { (c ? pass++ : fail++); out.push(`  ${c ? '✔' : '✘'} ${n}${info ? ' — ' + info : ''}`); };

async function main() {
  const { Game } = await import('../src/game/Game');
  const { store, defaultLoadouts } = await import('../src/game/save');
  const { WEAPONS, getWeapon } = await import('../src/game/data/weapons');
  store.setSettings(s => { s.graphics = { ...s.graphics, preset: 'medium', shadows: 0, textures: 0, effects: 1, motionBlur: false, fpsLimit: 0 }; s.controls.touchMode = 'off'; return s; });

  let errors = 0; const origErr = console.error; console.error = (...a: unknown[]) => { errors++; origErr('[console.error]', ...a); };
  let ended: any = null;
  const make = (mode: any, map: any, difficulty: any = 'regular') => {
    ended = null;
    const g = new Game(mkEl(), mkEl(), { mode, map, difficulty, loadout: defaultLoadouts()[0], operator: 'ghost', brZone: true }, { onEnd: r => { ended = r; }, onPause: () => {} });
    return g;
  };
  const step = (g: any, seconds: number, each?: (g: any) => void) => {
    const frames = Math.round(seconds * 60);
    for (let i = 0; i < frames; i++) { each?.(g); now += 1000 / 60; rafCb?.(now); }
  };
  const aimAt = (g: any, target: THREE.Vector3) => {
    const eye = g.camera.position; const dx = target.x - eye.x, dy = target.y - eye.y, dz = target.z - eye.z;
    g.yaw = Math.atan2(-dx, -dz); g.pitch = Math.atan2(dy, Math.hypot(dx, dz)); g.recoilRecover = 0;
  };
  const invariant = (g: any) => g.weapons.every((w: any) => !w || (w.mag >= 0 && w.mag <= w.stats.mag && w.reserve >= 0 && Number.isFinite(w.mag)));

  // ===================== PRACTICE RANGE =====================
  out.push('PRACTICE RANGE');
  let g: any = make('range', 'range');
  step(g, 0.5); g.setPaused(false); // desktop starts paused until click — emulate click/resume
  check('range starts with targets', g.targets.length >= 10, `${g.targets.length} targets`);
  const tgt = g.targets.find((t: any) => t.spec.kind === 'dummy');
  let fired = 0;
  step(g, 7, gg => { aimAt(gg, new THREE.Vector3(tgt.pos.x, 1.2, tgt.pos.z)); gg.input.mouseButtons.add(0); gg.input.mouseButtons.add(2); gg.input.mousePressed.add(0); fired++; });
  g.input.mouseButtons.clear();
  check('shots register hits on range target', g.hits > 0, `hits=${g.hits} shots=${g.shots}`);
  check('targets go down and are counted', g.rangeTargets > 0, `targets=${g.rangeTargets}`);
  check('ammo invariant held while firing', invariant(g));
  // test all 20 weapons can be equipped and fired
  let allFire = true; const failedW: string[] = [];
  for (const w of WEAPONS) {
    g.setWeaponFromArmory(0, w.id, {}, 'default'); g.reloadT = 0;
    step(g, 0.5);
    const before = g.shots; const magBefore = g.weapons[0].mag;
    step(g, 0.4, gg => { aimAt(gg, new THREE.Vector3(tgt.pos.x, 1.2, tgt.pos.z)); gg.input.mouseButtons.add(0); gg.input.mousePressed.add(0); });
    g.input.mouseButtons.clear();
    if (!(g.shots > before && g.weapons[0].mag < magBefore + 0)) { allFire = false; failedW.push(w.id); }
    if (!invariant(g)) { allFire = false; failedW.push(w.id + '(ammo)'); }
  }
  check('all 20 weapons can be selected and fired in gameplay', allFire, failedW.join(','));
  // reload correctness
  g.setWeaponFromArmory(0, 'ar01', {}, 'default'); step(g, 0.5);
  const w0 = g.weapons[0]; w0.mag = 3; w0.reserve = 100;
  g.input.pressedKeys.add('KeyR'); step(g, 0.1);
  const magDuring = w0.mag;
  step(g, 0.3, gg => { gg.input.mouseButtons.add(0); gg.input.mousePressed.add(0); }); g.input.mouseButtons.clear();
  check('cannot fire while reloading', w0.mag === magDuring, `mag ${magDuring} → ${w0.mag}`);
  step(g, 3);
  check('reload fills magazine (range: unlimited reserve)', w0.mag === w0.stats.mag && w0.reserve >= 0, `mag=${w0.mag} reserve=${w0.reserve}`);
  // weapon switching
  g.input.pressedKeys.add('Digit2'); step(g, 0.6);
  check('weapon switching to slot 2', g.active === 1, `active=${g.active} (${g.weapons[1].def.name})`);
  // pause halts simulation
  const tBefore = g.time; g.setPaused(true); step(g, 2); const tAfter = g.time; g.setPaused(false);
  check('pause freezes local simulation', tAfter === tBefore);
  g.endRangeSession(); step(g, 0.5);
  check('range session ends with results', !!ended && ended.mode === 'range', ended ? `score=${ended.score}` : '');
  g.dispose();

  // ===================== OFFLINE COMBAT =====================
  out.push('OFFLINE COMBAT');
  g = make('combat', 'iron', 'recruit'); g.setPaused(false);
  { // exact reload arithmetic in a mode with finite ammo
    step(g, 0.3); const w = g.weapons[g.active]; w.mag = 3; w.reserve = 100; g.input.pressedKeys.add('KeyR'); step(g, w.stats.reload * 1.2 + 0.2);
    check('reload transfers exactly the missing rounds (no duplication)', w.mag === w.stats.mag && w.reserve === 100 - (w.stats.mag - 3), `mag=${w.mag} reserve=${w.reserve}`);
    w.mag = 0; w.reserve = 0; g.input.mousePressed.add(0); step(g, 0.1); check('empty weapon with no reserve cannot fire or go negative', w.mag === 0 && w.reserve === 0);
    w.mag = w.stats.mag; w.reserve = 100;
  }
  g.health = 1e9; g.maxHealth = 1e9; // god-mode to let the scripted player clear waves
  let maxWave = 0; let invOk = true; let botsSeen = 0;
  step(g, 300, gg => {
    const tgtBot = gg.bots.filter((b: any) => b.alive).sort((a: any, b: any) => a.pos.distanceTo(gg.pos) - b.pos.distanceTo(gg.pos))[0];
    botsSeen = Math.max(botsSeen, gg.bots.filter((b: any) => b.alive).length);
    if (tgtBot) {
      // teleport player near target (scripted), aim and shoot
      const chest = new THREE.Vector3(tgtBot.pos.x, tgtBot.pos.y + 1.3, tgtBot.pos.z);
      const eye = new THREE.Vector3(gg.pos.x, gg.pos.y + 1.6, gg.pos.z);
      if (tgtBot.pos.distanceTo(gg.pos) > 14 || !gg.world.lineOfSight(eye, chest)) {
        for (let k = 0; k < 12; k++) { // scripted: find a firing position with line of sight
          const a = (k / 12) * Math.PI * 2, r = 5 + (k % 3) * 2; const p = gg.world.nearestWalkable(tgtBot.pos.x + Math.cos(a) * r, tgtBot.pos.z + Math.sin(a) * r);
          const y = gg.world.ground(p.x, p.z);
          if (gg.world.lineOfSight(new THREE.Vector3(p.x, y + 1.6, p.z), chest)) { gg.pos.set(p.x, y, p.z); gg.vel.set(0, 0, 0); break; }
        }
      }
      aimAt(gg, new THREE.Vector3(tgtBot.pos.x, tgtBot.pos.y + 1.3, tgtBot.pos.z)); gg.input.mouseButtons.add(0); gg.input.mousePressed.add(0);
    } else gg.input.mouseButtons.clear();
    gg.weapons.forEach((w: any) => { if (w) w.reserve = Math.max(w.reserve, 60); });
    maxWave = Math.max(maxWave, gg.wave); if (!invariant(gg)) invOk = false;
  });
  check('enemy waves spawn and progress', maxWave >= 3, `reached wave ${maxWave}, peak alive ${botsSeen}`);
  check('player eliminations counted with score', g.kills > 5 && g.score > 500, `kills=${g.kills} score=${Math.round(g.score)} hs=${g.headshots}`);
  check('ammo invariant held for 4 minutes of combat', invOk);
  check('enemies engaged and damaged the player', g.lastHurt > 0, `last hurt at t=${g.lastHurt.toFixed(1)}s`);
  check('combat victory after final wave', !!ended && ended.victory === true, ended ? ended.resultText : `wave ${g.wave}, remaining ${g.waveRemaining}`);
  g.dispose();
  // defeat path
  g = make('combat', 'dust', 'elite'); g.setPaused(false);
  step(g, 1); g.damagePlayer(500, null, null); step(g, 4);
  check('player death → defeat screen', !!ended && ended.victory === false && ended.deaths === 1, ended?.resultText);
  g.dispose();

  // ===================== BATTLE ROYALE =====================
  out.push('BATTLE ROYALE');
  g = make('br', 'dust', 'regular'); g.setPaused(false);
  const nBots = g.bots.length;
  check('BR spawns AI opponents + loot', nBots >= 9 && g.loot.length > 20 && g.crates.length > 3, `${nBots} bots, ${g.loot.length} loot, ${g.crates.length} crates`);
  check('player starts parachuting with a sidearm only', g.parachute && !g.weapons[0] && !!g.weapons[1]);
  step(g, 12);
  check('player lands from parachute', !g.parachute && g.ground.onGround, `y=${g.pos.y.toFixed(1)}`);
  // loot pickup: weapon into empty slot
  const wl = g.loot.find((l: any) => l.kind === 'weapon');
  g.pos.copy(wl.pos); g.yaw = 0; g.pitch = -1.2; step(g, 0.05);
  const lootCountBefore = g.loot.length; g.input.pressedKeys.add('KeyE'); step(g, 0.05);
  check('weapon pickup fills empty primary slot & item removed', !!g.weapons[0] && g.loot.length === lootCountBefore - 1 && !g.loot.includes(wl), g.weapons[0]?.def.name);
  // swap: both slots full -> old weapon is dropped (no duplication, no loss)
  const wl2 = g.loot.find((l: any) => l.kind === 'weapon' && l !== wl);
  const activeBefore = g.weapons[g.active].def.id; const cnt = g.loot.length;
  g.pos.copy(wl2.pos); g['takeLoot'](wl2); step(g, 0.05);
  const dropped = g.loot.find((l: any) => l.kind === 'weapon' && l.weapon.def.id === activeBefore && l.pos.distanceTo(g.pos) < 2);
  check('weapon swap drops old weapon (count conserved)', g.loot.length === cnt && !!dropped, `loot ${cnt} → ${g.loot.length}`);
  // inventory limits
  g.plates = 3; const armor = g.loot.find((l: any) => l.kind === 'armor'); g.pos.copy(armor.pos); step(g, 0.05); g.input.pressedKeys.add('KeyE'); step(g, 0.05);
  check('inventory limit: plate stays on ground when full', g.plates === 3 && g.loot.includes(armor));
  g.plates = 1; g.input.pressedKeys.add('KeyE'); step(g, 0.05);
  check('plate picked up when space available', g.plates === 2 && !g.loot.includes(armor));
  g.input.pressedKeys.add('KeyV'); step(g, 1.5);
  check('applying plate consumes plate and grants armor', g.plates === 1 && (g.armor === 50 || g.lastHurt > g.time - 1.6), `armor=${g.armor}`);
  // crate
  const crate = g.crates[0]; const lc = g.loot.length; g.pos.set(crate.pos.x + 1, crate.pos.y, crate.pos.z); step(g, 0.05); g.input.pressedKeys.add('KeyE'); step(g, 0.05);
  check('supply crate opens once and drops loot', crate.opened && g.loot.length > lc && g.crateCount === 1, `+${g.loot.length - lc} items`);
  g.input.pressedKeys.add('KeyE'); step(g, 0.05);
  check('crate cannot be looted twice', g.crateCount === 1);
  // zone
  const r0 = g.zone.r; step(g, 70, gg => { gg.health = 100; });
  check('safe zone shrinks over time', g.zone.r < r0, `r ${Math.round(r0)} → ${Math.round(g.zone.r)}`);
  g.pos.set(g.zone.x + g.zone.r + 30, 0, g.zone.z); g.pos.x = Math.min(g.pos.x, g.world.bounds.maxX - 2); g.pos.y = g.world.ground(g.pos.x, g.pos.z);
  if (Math.hypot(g.pos.x - g.zone.x, g.pos.z - g.zone.z) <= g.zone.r) g.pos.set(g.zone.x - g.zone.r - 20, 0, g.zone.z);
  const hb = g.health; g.armor = 0; step(g, 2);
  check('player outside zone takes damage', g.health < hb, `${hb} → ${Math.round(g.health)}`);
  const aliveBefore = g.bots.filter((b: any) => b.alive).length;
  g.health = 1e9; g.maxHealth = 1e9; g.pos.set(g.zone.toX, 0, g.zone.toZ); { const p = g.world.nearestWalkable(g.pos.x, g.pos.z); g.pos.set(p.x, g.world.ground(p.x, p.z), p.z); }
  step(g, 220, gg => { gg.health = 1e9; });
  const aliveAfter = g.bots.filter((b: any) => b.alive).length;
  check('AI opponents are eliminated (by each other / zone)', aliveAfter < aliveBefore, `${aliveBefore} → ${aliveAfter} alive`);
  if (!ended) { for (const b of g.bots) if (b.alive) g['damageBot'](b, 9999, g.player, false, getWeapon('ar01'), b.pos.clone()); step(g, 3); }
  check('BR victory when last operator standing', !!ended && ended.victory && ended.placement === 1, ended?.resultText);
  g.dispose();

  // ===================== TEAM DEATHMATCH =====================
  out.push('TEAM DEATHMATCH');
  g = make('tdm', 'iron', 'veteran'); g.setPaused(false);
  const t0 = g.bots.filter((b: any) => b.team === 0).length, t1 = g.bots.filter((b: any) => b.team === 1).length;
  check('two teams spawned', t0 + 1 === t1, `allies ${t0}+you vs enemies ${t1}`);
  g.damagePlayer(500, g.bots.find((b: any) => b.team === 1), null);
  check('player death awards enemy team point', g.teamScore[1] === 1 && !g.alive);
  step(g, 4);
  check('player respawns after delay', g.alive && g.health === g.maxHealth);
  let respawned = false;
  step(g, 400, gg => { gg.health = 1e9; gg.maxHealth = 1e9; if (gg.bots.some((b: any) => b.alive && b.deadT === 0 && b.respawnAt === 0 && b.kills >= 0)) respawned = true; });
  check('teams score eliminations over time', g.teamScore[0] + g.teamScore[1] > 5, `score ${g.teamScore[0]}–${g.teamScore[1]}`);
  check('match ends at score limit or timer with a winner', !!ended && !!ended.teamScore, ended ? `${ended.resultText} (${ended.teamScore})` : `t=${Math.round(g.matchTime)}`);
  check('bots respawn in TDM', respawned);
  g.dispose();

  // ===================== LIFECYCLE =====================
  out.push('LIFECYCLE');
  const w0l = listeners.window, d0l = listeners.document;
  for (let i = 0; i < 3; i++) { const gg: any = make('combat', 'iron'); step(gg, 0.5); gg.dispose(); }
  check('restarting 3× leaks no window/document listeners', listeners.window === w0l && listeners.document === d0l, `window Δ${listeners.window - w0l}, document Δ${listeners.document - d0l}`);
  const g2: any = make('tdm', 'dust'); const nb = g2.bots.length; g2.dispose(); const g3: any = make('tdm', 'dust');
  check('restart does not duplicate enemies', g3.bots.length === nb, `${nb} → ${g3.bots.length}`); g3.dispose();
  out.push('PERFORMANCE (CPU only — rendering excluded)');
  for (const preset of ['low', 'ultra'] as const) {
    store.setSettings(x => { x.graphics.preset = preset; return x; });
    const gp: any = make('br', 'dust', 'veteran'); gp.setPaused(false); step(gp, 12, q => { q.health = 1e9; });
    const t0 = Date.now(); step(gp, 20, q => { q.health = 1e9; }); const ms = (Date.now() - t0) / (20 * 60);
    check(`BR ${preset} (${gp.bots.length} AI) game-logic CPU per frame < 4ms`, ms < 4, `${ms.toFixed(2)} ms/frame`);
    gp.dispose();
  }
  check('no runtime errors logged during simulations', errors === 0, `${errors} errors`);

  console.log(out.join('\n'));
  console.log(`\nRESULT: ${pass} passed, ${fail} failed`);
  if (fail) process.exitCode = 1;
}
main().catch(e => { console.error(e); process.exitCode = 1; });
