/**
 * WHITE ROOM OS — Phase 5 Comprehensive Unit & End-to-End Domain Integration Tests
 * Covers all 23 required Phase 5 verification scenarios:
 *  1. Diagnostic assessment grounded in 9 recorded evidence signals
 *  2. Configurable Error Taxonomy classification (11 standard + custom domain categories)
 *  3. Explicit Unknown / Unclassified cause handling (`unknown_unclassified`)
 *  4. Root-cause hypotheses with supporting evidence, uncertainty, verification method & respectful language
 *  5. Targeted Remediation selection matched to diagnosed category
 *  6. Corrective task linkage (`errorId`, `remediationId`, `skillId`, `subskillId`, `objectiveId`)
 *  7. Retest linkage (`originalAssessmentId`, `errorId`, `remediationId`, `retestAttemptId`, anti-verbatim repeat guard)
 *  8. Successful retest resolution rules
 *  9. Failed retest escalation & stepped-down drill generation
 * 10. Append-only preservation of all failed test attempts
 * 11. Configurable domain-specific Mastery Criteria (Math, Languages, Chess, Physical/Boxing)
 * 12. Prerequisite blocking enforcement
 * 13. Traceable Mastery Decision Explanation (`decisionExplanation` & `criteriaBreakdown`)
 * 14. Historical Mastery Preservation (`mastery_history` & `historicalMasteryAchieved`)
 * 15. Retention assessment success & rejection of passive review without performance evidence
 * 16. Retention failure creating relearning path without erasing prior mastery history
 * 17. Relearning and Mastery Reactivation after retention failure
 * 18. Maintenance history chronological audit trail
 * 19. 5-Dimensional Progress metric consistency (`Activity`, `Learning`, `Competence`, `Mastery`, `Retention`)
 * 20. Strict Zero Double-Counting of evidence across progress metrics
 * 21. Daily Execution & Adaptive Scheduler integration (prioritizing remediation without doubling workload)
 * 22. Backup/Restore v5 compatibility across all 32 stores
 * 23. End-to-End multi-domain integration paths (both successful and unsuccessful learning paths)
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { createWhiteRoomSystem } from '../src/core/bootstrap.js';

test('Phase 5.1–5.4: Diagnostic Assessment, Configurable Error Taxonomy, Unknown-Cause Handling & Root-Cause Hypotheses', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true, initialDate: '2026-10-14' });
  const { diagnosticsEngine, skillEngine } = sys.engines;

  // Verify default 11-category taxonomy + register custom domain category (e.g. Chess tactical blunder)
  const initialTax = diagnosticsEngine.getErrorTaxonomy();
  assert.ok(initialTax.conceptual_misunderstanding);
  assert.ok(initialTax.missing_prerequisite);
  assert.ok(initialTax.unknown_unclassified);

  diagnosticsEngine.configureErrorTaxonomy({
    chess_tactical_oversight: {
      labelAr: 'إغفال تكتيكي في الشطرنج',
      labelEn: 'Chess tactical oversight',
      defaultRemediationType: 'tactical_pattern_drills',
      defaultStrategy: 'حل 15 لغز تكتيكي مركز على التهديدات المزدوجة',
    },
  });
  const updatedTax = diagnosticsEngine.getErrorTaxonomy();
  assert.ok(updatedTax.chess_tactical_oversight);

  // Run diagnostic assessment with explicit unknown_unclassified cause
  const unknownDiag = await diagnosticsEngine.runDiagnosticAssessment({
    skillId: 'skill-python-algo',
    subskillId: 'sub-py-arrays',
    score: 62,
    accuracy: 60,
    incorrectAnswersCount: 3,
    reportedCategory: 'unknown_unclassified',
    observedNotes: 'تعثر مفاجئ في المسألة الثالثة بدون نمط واضح حتى الآن',
    date: '2026-10-14',
  });

  assert.equal(unknownDiag.isWeak, true);
  assert.equal(unknownDiag.diagnostic.primaryCategory, 'unknown_unclassified');
  assert.equal(unknownDiag.diagnostic.classificationState, 'unclassified');
  assert.ok(unknownDiag.observedFacts.length >= 3, 'Must record observed facts from evidence signals');
  assert.ok(unknownDiag.hypotheses.length >= 1, 'Must propose hypotheses with uncertainty');
  assert.equal(unknownDiag.hypotheses[0].category, 'unknown_unclassified');
  assert.equal(unknownDiag.hypotheses[0].confidenceLevel, 'low');
  assert.ok(unknownDiag.hypotheses[0].uncertaintyNote.length > 10);
  assert.ok(unknownDiag.hypotheses[0].verificationMethod.length > 10);
  assert.ok(unknownDiag.createdError, 'Must create linked ErrorRecord');
  assert.equal(unknownDiag.createdError.classificationState, 'unclassified');

  // Verify no derogatory language is ever generated
  const serialized = JSON.stringify(unknownDiag).toLowerCase();
  assert.equal(serialized.includes('lazy'), false);
  assert.equal(serialized.includes('unintelligent'), false);
  assert.equal(serialized.includes('incapable'), false);
  assert.equal(serialized.includes('كسول'), false);
  assert.equal(serialized.includes('غبي'), false);

  // Test diagnostic assessment detecting missing prerequisites on locked skill (skill-dp-graphs requires skill-python-algo)
  const prereqDiag = await diagnosticsEngine.runDiagnosticAssessment({
    skillId: 'skill-dp-graphs',
    observedNotes: 'محاولة تقييم جاهزية البرمجة الديناميكية قبل إتمام المتطلب السابق',
    date: '2026-10-14',
  });
  assert.equal(prereqDiag.isWeak, true);
  assert.ok(prereqDiag.diagnostic.evidenceSignals.missingPrerequisites.includes('skill-python-algo'));
  assert.equal(prereqDiag.hypotheses[0].category, 'missing_prerequisite');
});

test('Phase 5.5–5.10: Targeted Remediation, Corrective Task Linkage, Verified Retests, Failed Retest Escalation & Attempt Preservation', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true, initialDate: '2026-10-14' });
  const { diagnosticsEngine, skillEngine } = sys.engines;

  // 1. Run diagnostic assessment for a procedural error on sub-py-arrays
  const diagRes = await diagnosticsEngine.runDiagnosticAssessment({
    skillId: 'skill-python-algo',
    subskillId: 'sub-py-arrays',
    objectiveId: 'obj-py-two-pointers',
    score: 55,
    accuracy: 50,
    incorrectAnswersCount: 4,
    reportedCategory: 'procedural_error',
    observedNotes: 'تحريك المؤشر الأيمن بدلاً من الأيسر عند انكسار شرط النافذة',
    date: '2026-10-14',
  });

  const errorId = diagRes.createdError.id;
  assert.equal(diagRes.createdError.category, 'procedural_error');
  assert.equal(diagRes.createdError.goalId, 'goal-cs-swe');
  assert.equal(diagRes.createdError.capabilityId, 'cap-04-cs');
  assert.equal(diagRes.createdError.objectiveId, 'obj-py-two-pointers');

  // 2. Generate targeted remediation -> must produce worked example + independent practice linked to error
  const remRes = await diagnosticsEngine.generateTargetedRemediation(errorId, {
    date: '2026-10-14',
  });
  assert.equal(remRes.remediation.remediationType, 'worked_example_and_independent_practice');
  assert.equal(remRes.remediation.retestAllowed, false);
  assert.equal(remRes.correctiveTasks.length, 2);
  for (const ct of remRes.correctiveTasks) {
    assert.equal(ct.errorId, errorId);
    assert.equal(ct.remediationId, remRes.remediation.id);
    assert.equal(ct.skillId, 'skill-python-algo');
    assert.equal(ct.subskillId, 'sub-py-arrays');
  }

  // 3. Attempting retest BEFORE completing corrective tasks must be blocked
  await assert.rejects(
    async () => {
      await diagnosticsEngine.executeVerifiedRetest({
        linkedErrorId: errorId,
        verificationMode: 'equivalent_questions',
        score: 90,
        accuracy: 90,
        evidence: 'محاولة مبكرة قبل إنهاء المهام التصحيحية',
      });
    },
    /before completing all Corrective Tasks/
  );

  // 4. Complete corrective tasks & record remediation evidence
  for (const ct of remRes.correctiveTasks) {
    await skillEngine.completeCorrectiveTask(ct.id, {
      durationMinutes: 30,
      evidenceTitle: `دليل تصحيحي: ${ct.title}`,
      evidenceContent: 'تتبع المثال المحلول ثم حل مسألة مستقلة بنجاح',
    });
  }
  const unlockedRem = await sys.db.get('remediations', remRes.remediation.id);
  assert.equal(unlockedRem.retestAllowed, true);
  assert.equal(unlockedRem.status, 'ready_for_retest');

  // 5. Reject verbatim repeat retest (`isVerbatimRepeat: true`)
  await assert.rejects(
    async () => {
      await diagnosticsEngine.executeVerifiedRetest({
        linkedErrorId: errorId,
        verificationMode: 'equivalent_questions',
        isVerbatimRepeat: true,
        score: 95,
        accuracy: 95,
        evidence: 'تكرار نفس السؤال المحفوظ حرفياً',
      });
    },
    /Retest rejected/
  );

  // 6. Execute a FAILED retest -> must preserve failed attempt, increment failureCount, escalate remediation, and spawn a drill task
  const failedRetest = await diagnosticsEngine.executeVerifiedRetest({
    linkedErrorId: errorId,
    verificationMode: 'new_examples',
    score: 68,
    accuracy: 65,
    evidence: 'حل مثال جديد ولكن بقي خطأ في حالة الحافة (Edge Case)',
  });
  assert.equal(failedRetest.passed, false);
  assert.equal(failedRetest.updatedError.status, 'escalated');
  assert.equal(failedRetest.updatedError.failureCount, 2);
  assert.ok(failedRetest.spawnedEscalationTask, 'Failed retest must spawn stepped-down corrective drill');

  // Complete the spawned escalation drill task so retest is unlocked again
  await skillEngine.completeCorrectiveTask(failedRetest.spawnedEscalationTask.id, {
    durationMinutes: 35,
    evidenceTitle: 'إتقان حالات الحافة في المؤشرين',
  });

  // 7. Execute a SUCCESSFUL verified retest in varied_context
  const passedRetest = await diagnosticsEngine.executeVerifiedRetest({
    linkedErrorId: errorId,
    verificationMode: 'varied_context',
    score: 94,
    accuracy: 92,
    evidence: 'حل مسألتين في سياق مختلف بتعقيد خطي O(N) بدون أخطاء',
  });
  assert.equal(passedRetest.passed, true);
  assert.equal(passedRetest.updatedError.status, 'resolved');
  assert.equal(passedRetest.updatedError.classificationState, 'verified');
  assert.equal(passedRetest.updatedError.resolvedByAttemptId, passedRetest.attempt.id);
  assert.equal(passedRetest.lineage.originalAssessmentId, diagRes.diagnostic.id);
  assert.equal(passedRetest.lineage.errorId, errorId);
  assert.equal(passedRetest.lineage.remediationId, remRes.remediation.id);

  // 8. Verify failed attempts were preserved in `test_attempts` (append-only, never deleted!)
  const allAttempts = await sys.db.queryByField('test_attempts', 'skillId', 'skill-python-algo');
  assert.ok(
    allAttempts.some((a) => a.id === failedRetest.attempt.id && a.passed === false),
    'Failed retest attempt must remain preserved in database'
  );
  assert.ok(
    allAttempts.some((a) => a.id === passedRetest.attempt.id && a.passed === true),
    'Passed retest attempt must be recorded alongside failed history'
  );
});

test('Phase 5.11–5.18: Domain-Specific Mastery Criteria, Traceable Explanations, Historical Mastery Preservation, Retention Failure & Relearning Reactivation', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true, initialDate: '2026-10-14' });
  const { skillEngine, diagnosticsEngine } = sys.engines;

  // Create two skills in different domains with different domain-specific evidence & independent application requirements
  const chessSkill = await skillEngine.createSkill({
    id: 'skill-chess-tactics',
    name: 'Chess Tactical Calculation',
    nameAr: 'الحساب التكتيكي في الشطرنج',
    capabilityId: 'cap-09-cognitive',
    domain: 'Chess & Strategy',
    masteryCriteria: {
      minTestScore: 85,
      minAccuracy: 85,
      minSuccessfulAttempts: 1,
      consistency: 1,
      requiredEvidenceCount: 1,
      requiredEvidenceTypes: ['tactical_analysis'],
      requireIndependentApplication: true,
      prerequisiteMastery: true,
      requireAllSubskillsMastered: false,
    },
    maintenanceCriteria: {
      intervalDays: 14,
      minRetentionScore: 85,
    },
  });
  assert.equal(chessSkill.status, 'AVAILABLE');

  // Record generic training evidence (NOT 'tactical_analysis') and a standard test -> gate must FAIL with traceable explanation!
  await skillEngine.recordTrainingSession({
    skillId: 'skill-chess-tactics',
    durationMinutes: 45,
    evidenceType: 'training',
    evidenceTitle: 'مشاهدة تحليل مباراة شطرنج',
  });
  await skillEngine.recordTestAttempt({
    skillId: 'skill-chess-tactics',
    score: 90,
    accuracy: 88,
    evidence: 'حل ألغاز تكتيكية قياسية',
  });

  const blockedGate = await skillEngine.evaluateMasteryGate('skill', 'skill-chess-tactics');
  assert.equal(blockedGate.passed, false);
  assert.equal(blockedGate.checks.domainEvidenceTypes, false);
  assert.equal(blockedGate.checks.independentApplication, false);
  assert.ok(blockedGate.decisionExplanation.includes('tactical_analysis'));

  // Now provide the required domain-specific evidence ('tactical_analysis') with independentApplication = true
  await skillEngine.recordTrainingSession({
    skillId: 'skill-chess-tactics',
    durationMinutes: 50,
    evidenceType: 'tactical_analysis',
    independentApplication: true,
    evidenceTitle: 'تحليل تكتيكي مستقل لمباراة كاملة بدون محرك',
  });

  const promotion = await skillEngine.tryPromoteMastery('skill-chess-tactics');
  assert.equal(promotion.skillGate.passed, true);
  assert.ok(promotion.skillGate.decisionExplanation.includes('اجتازت المهارة'));

  const masteredChess = await sys.db.get('skills', 'skill-chess-tactics');
  assert.equal(masteredChess.status, 'MASTERED');
  assert.equal(masteredChess.historicalMasteryAchieved, true);
  assert.ok(masteredChess.firstMasteredAt);
  assert.equal(masteredChess.currentRetentionStatus, 'ACTIVE_MASTERY');

  // Verify passive review without performance evidence is REJECTED
  await assert.rejects(
    async () => {
      await skillEngine.recordMaintenanceSession({
        skillId: 'skill-chess-tactics',
        reviewDate: '2026-10-20',
        performanceVerified: false,
        score: null,
        retentionEvidence: '',
      });
    },
    /requires recorded performance evidence/
  );

  // Record a SUCCESSFUL Retention Check
  const retSuccess = await skillEngine.recordMaintenanceSession({
    skillId: 'skill-chess-tactics',
    reviewDate: '2026-10-28',
    score: 92,
    retentionEvidence: 'حل 10 مواقف تكتيكية معقدة بدقة 92% بدون أخطاء',
  });
  assert.equal(retSuccess.passed, true);
  assert.equal(retSuccess.currentRetentionStatus, 'RETAINED');

  // Record a FAILED Retention Check later -> must preserve historicalMasteryAchieved = true and create Relearning path!
  const retFail = await skillEngine.recordMaintenanceSession({
    skillId: 'skill-chess-tactics',
    reviewDate: '2026-11-18',
    score: 64,
    retentionEvidence: 'تراجع في سرعة ودقة حساب التفريعات الطويلة (64%)',
  });
  assert.equal(retFail.passed, false);
  assert.equal(retFail.historicalMasteryPreserved, true);
  assert.equal(retFail.currentRetentionStatus, 'RETENTION_DECAY_RELEARNING');
  assert.ok(retFail.retentionFailureError);
  assert.ok(retFail.relearningRemediation);

  const decayedChess = await sys.db.get('skills', 'skill-chess-tactics');
  assert.equal(
    decayedChess.historicalMasteryAchieved,
    true,
    'Prior mastery achievement must NEVER be erased when a later retention check fails'
  );
  assert.equal(decayedChess.firstMasteredAt, masteredChess.firstMasteredAt);
  assert.equal(decayedChess.currentRetentionStatus, 'RETENTION_DECAY_RELEARNING');
  assert.equal(decayedChess.status, 'IN_PROGRESS');

  // Complete Relearning Corrective Tasks + Verified Retest + Reactivate Mastery
  for (const task of retFail.relearningRemediation.correctiveTasks) {
    await skillEngine.completeCorrectiveTask(task.id, {
      durationMinutes: 25,
      evidenceTitle: `إتمام إعادة التعلم: ${task.title}`,
    });
  }
  const relearningRetest = await diagnosticsEngine.executeVerifiedRetest({
    linkedErrorId: retFail.retentionFailureError.id,
    verificationMode: 'delayed_retention_check',
    score: 91,
    accuracy: 90,
    evidence: 'استعادة الدقة التكتيكية الكاملة في فحص الاحتفاظ التأكيدي',
  });
  assert.equal(relearningRetest.passed, true);

  const reactivated = await diagnosticsEngine.reactivateMasteryAfterRelearning(
    'skill-chess-tactics',
    null,
    '2026-11-20'
  );
  assert.equal(reactivated.skill.status, 'MAINTENANCE');
  assert.equal(reactivated.skill.historicalMasteryAchieved, true);
  assert.equal(reactivated.skill.currentRetentionStatus, 'RETAINED');

  // Verify mastery_history recorded the entire chronological lifecycle
  const history = await sys.db.queryByField('mastery_history', 'skillId', 'skill-chess-tactics');
  const eventTypes = history.map((h) => h.eventType);
  assert.ok(eventTypes.includes('MASTERY_ACHIEVED'));
  assert.ok(eventTypes.includes('RETENTION_VERIFIED'));
  assert.ok(eventTypes.includes('RETENTION_FAILED_RELEARNING'));
  assert.ok(eventTypes.includes('ENTERED_MAINTENANCE'));
});

test('Phase 5.19–5.23: 5D Progress Partitioning (Zero Double-Counting), Scheduler Integration & Backup/Restore v5 Compatibility', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true, initialDate: '2026-10-14' });
  const { diagnosticsEngine, skillEngine, schedulerEngine, performanceEngine, backupEngine } =
    sys.engines;

  // Create a diagnostic error and targeted remediation on skill-python-algo
  const diag = await diagnosticsEngine.runDiagnosticAssessment({
    skillId: 'skill-python-algo',
    subskillId: 'sub-py-arrays',
    score: 60,
    accuracy: 58,
    reportedCategory: 'conceptual_misunderstanding',
    observedNotes: 'التباس في شرط تقلص النافذة المنزلقة',
    date: '2026-10-14',
  });
  await diagnosticsEngine.generateTargetedRemediation(diag.createdError.id, {
    date: '2026-10-14',
  });

  // Regenerate today's adaptive schedule -> verify corrective work is prioritized while respecting Phase 4 workload/buffer rules
  const plan = await schedulerEngine.generateSmartDailyPlan('2026-10-14', 7, {
    forceRegenerate: true,
  });
  assert.equal(plan.overloadCheck.isOverloaded, false, 'Must respect daily workload ceiling');
  assert.ok(plan.budget.bufferMin >= 15, 'Must preserve safety buffer');
  assert.ok(
    plan.tasks.some((t) => t.isCorrective || t.category === 'Remediation'),
    'Scheduler must prioritize corrective/remediation work'
  );

  // Verify 5-Dimensional Progress & Zero Double-Counting of Evidence
  const skillProg = await skillEngine.calculateSkillProgress('skill-python-algo', '2026-10-14');
  assert.equal(skillProg.evidencePartition.zeroDoubleCountingVerified, true);
  assert.equal(
    skillProg.evidencePartition.learningEvidenceIds.length +
      skillProg.evidencePartition.competenceEvidenceIds.length +
      skillProg.evidencePartition.retentionEvidenceIds.length,
    skillProg.evidencePartition.totalEvidenceCount
  );

  const sysProg = await performanceEngine.computeSystemProgress('2026-10-14');
  assert.equal(sysProg.evidencePartitionAudit.zeroDoubleCountingVerified, true);
  assert.ok(sysProg.dimensions.activity >= 0 && sysProg.dimensions.activity <= 100);
  assert.ok(sysProg.dimensions.learning >= 0 && sysProg.dimensions.learning <= 100);
  assert.ok(sysProg.dimensions.competence >= 0 && sysProg.dimensions.competence <= 100);
  assert.ok(sysProg.dimensions.mastery >= 0 && sysProg.dimensions.mastery <= 100);
  assert.ok(sysProg.dimensions.retention >= 0 && sysProg.dimensions.retention <= 100);
  assert.ok(sysProg.weaknessSummary.unresolvedErrorsCount >= 1);

  // Verify Backup & Restore v5 across all 32 stores
  const backup = await backupEngine.exportBackup();
  assert.ok(backup.schemaVersion >= 5);
  assert.ok(Object.keys(backup.stores).length >= 32);
  assert.ok(backup.stores.diagnostic_assessments.length >= 1);

  await sys.db.clearAll();
  const restored = await backupEngine.restoreBackup(backup);
  assert.equal(restored.restoredCount, backup.totalRecords);
});
