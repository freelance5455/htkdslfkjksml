'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const matches = [...html.matchAll(/data:image\/webp;base64,([A-Za-z0-9+/=]+)/g)];
assert.ok(matches.length >= 24, `expected at least 24 embedded WebP images, got ${matches.length}`);
for (const [index, match] of matches.entries()) {
  const bytes = Buffer.from(match[1], 'base64');
  assert.equal(bytes.toString('ascii', 0, 4), 'RIFF', `image ${index} has no RIFF header`);
  assert.equal(bytes.toString('ascii', 8, 12), 'WEBP', `image ${index} is not WebP`);
  assert.ok(bytes.length > 5000, `image ${index} is unexpectedly small`);
}
for (const rank of ['E','D','C','B','A','S']) {
  assert.ok(html.includes(`"${rank}":{"hero":"data:image/webp;base64,`), `missing hero art for rank ${rank}`);
}
assert.match(html, /weekly_companion_06/);
assert.match(html, /--rank-scene/);
console.log(`RISEUP artwork checks passed: ${matches.length} embedded WebP images are valid and rank themes are wired.`);
