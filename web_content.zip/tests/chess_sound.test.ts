import { Chess } from 'chess.js';
import {
  chessSound,
  triggerMoveAudio,
  playPieceMoveSound,
  playPieceCaptureSound,
  playCheckSound,
  playCheckmateSound,
  playIllegalMoveSound,
  playPieceSelectSound,
  ChessAudioEvent,
} from '../src/services/chessSound';

console.log('--- STARTING CHESS SOUND SYSTEM UTILITY TEST SUITE ---');

let passedTests = 0;
let totalTests = 0;

function assert(condition: boolean, testName: string) {
  totalTests++;
  if (condition) {
    passedTests++;
    console.log(`[PASS] ${testName}`);
  } else {
    console.error(`[FAIL] ${testName}`);
    throw new Error(`Assertion failed: ${testName}`);
  }
}

function testSoundSystemUtility() {
  const eventsReceived: ChessAudioEvent[] = [];
  const unsubscribe = chessSound.addEventListener((evt) => {
    eventsReceived.push(evt);
  });

  // 1. Piece Movement Audio Trigger
  console.log('\n--- 1. Testing Piece Movement Audio Trigger ---');
  const game = new Chess();
  const move1 = game.move('e4');
  const event1 = triggerMoveAudio(move1);
  assert(event1 === 'move', 'Standard pawn advance e4 triggers "move" event');

  const move2 = game.move('e5');
  const event2 = triggerMoveAudio(move2);
  assert(event2 === 'move', 'Black response e5 triggers "move" event');

  // 2. Piece Capture Audio Trigger
  console.log('\n--- 2. Testing Piece Capture Audio Trigger ---');
  game.move('Nf3');
  game.move('Nc6');
  game.move('d4');
  game.move('exd4'); // Capture!
  const captureMove = game.history({ verbose: true }).pop();
  const captureEvent = triggerMoveAudio(captureMove);
  assert(captureEvent === 'capture', 'Capture move exd4 triggers "capture" audio event');

  // 3. Check Event Audio Trigger
  console.log('\n--- 3. Testing Check Event Audio Trigger ---');
  const checkGame = new Chess();
  checkGame.move('e4');
  checkGame.move('e5');
  checkGame.move('Qh5');
  checkGame.move('Nc6');
  checkGame.move('Bc4');
  checkGame.move('Nf6');
  // Check position: Bxf7+ gives check (not mate yet)
  const checkMoveGame = new Chess('r1bqkb1r/pppp1ppp/2n2n2/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4');
  const moveWithCheck = checkMoveGame.move('Bxf7+');
  const checkEvent = triggerMoveAudio(moveWithCheck, { inCheck: checkMoveGame.inCheck() });
  assert(checkEvent === 'check', 'Move giving check triggers "check" audio event');

  // 4. Checkmate Event Audio Trigger
  console.log('\n--- 4. Testing Checkmate Event Audio Trigger ---');
  const mateGame = new Chess();
  mateGame.move('f3');
  mateGame.move('e5');
  mateGame.move('g4');
  const mateMove = mateGame.move('Qh4#');
  const mateEvent = triggerMoveAudio(mateMove, { isCheckmate: true, inCheck: true });
  assert(mateEvent === 'checkmate', 'Checkmate move triggers "checkmate" audio event with victory fanfare');

  // 5. Castling Audio Trigger
  console.log('\n--- 5. Testing Castling Audio Trigger ---');
  const castleGame = new Chess('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1');
  const castleMove = castleGame.move('O-O');
  const castleEvent = triggerMoveAudio(castleMove, { isCastle: true });
  assert(castleEvent === 'castle', 'Kingside castling O-O triggers "castle" audio event');

  // 6. Pawn Promotion Audio Trigger
  console.log('\n--- 6. Testing Pawn Promotion Audio Trigger ---');
  const promoGame = new Chess('8/4P3/8/8/8/8/8/4K2k w - - 0 1');
  const promoMove = promoGame.move({ from: 'e7', to: 'e8', promotion: 'q' });
  const promoEvent = triggerMoveAudio(promoMove, { isPromotion: true });
  assert(promoEvent === 'promotion', 'Pawn promotion triggers triumphant "promotion" audio event');

  // 7. Direct Audio Triggers
  console.log('\n--- 7. Testing Direct Audio Utility Methods ---');
  chessSound.trigger('illegal');
  assert(eventsReceived.some((e) => e.type === 'illegal'), 'Direct trigger for "illegal" received by listeners');

  chessSound.trigger('select');
  assert(eventsReceived.some((e) => e.type === 'select'), 'Direct trigger for "select" received by listeners');

  playPieceMoveSound();
  playPieceCaptureSound();
  playCheckSound();
  playCheckmateSound();
  playIllegalMoveSound();
  playPieceSelectSound();

  // 8. Event Listener Unsubscribe
  console.log('\n--- 8. Testing Listener Cleanup & Audio Controls ---');
  const initialCount = eventsReceived.length;
  unsubscribe();
  chessSound.trigger('move');
  assert(eventsReceived.length === initialCount, 'Unsubscribed listener receives no further events');

  // Mute / Unmute
  chessSound.setSoundEnabled(false);
  assert(!chessSound.isSoundEnabled(), 'Sound correctly disabled');
  chessSound.setSoundEnabled(true);
  assert(chessSound.isSoundEnabled(), 'Sound correctly re-enabled');

  console.log('\n===========================================');
  console.log(`ALL CHESS SOUND SYSTEM TESTS PASSED! (${passedTests} / ${totalTests} assertions passed)`);
  console.log('===========================================\n');
}

testSoundSystemUtility();
