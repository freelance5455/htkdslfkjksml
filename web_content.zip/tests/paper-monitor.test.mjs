import test from 'node:test';
import assert from 'node:assert/strict';
function hit(side, price, sl, tp){ return side==='BUY' ? (price<=sl?'SL':price>=tp?'TARGET':null) : (price>=sl?'SL':price<=tp?'TARGET':null); }
test('BUY triggers stop loss',()=>assert.equal(hit('BUY',99,100,110),'SL'));
test('BUY triggers target',()=>assert.equal(hit('BUY',111,100,110),'TARGET'));
test('BUY stays open between levels',()=>assert.equal(hit('BUY',105,100,110),null));
test('SELL triggers stop loss',()=>assert.equal(hit('SELL',111,110,100),'SL'));
test('SELL triggers target',()=>assert.equal(hit('SELL',99,110,100),'TARGET'));
test('SELL stays open between levels',()=>assert.equal(hit('SELL',105,110,100),null));
