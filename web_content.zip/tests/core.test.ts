import test from "node:test";
import assert from "node:assert/strict";
import { emptyFS, findPath, pathOf, safePath, seedFS } from "../src/lib/fs";
import { applyOperation, runCommand } from "../src/lib/operations";
import { lineDiff } from "../src/lib/diff";
import { planFromPrompt } from "../src/lib/agent";
import {
  requestAgent,
  testProvider,
  validateEndpoint,
  testGeneration,
} from "../src/lib/provider-client";
import { compilePreview } from "../src/lib/preview-compiler";
import { PRESETS, presetToConfig } from "../src/lib/providers";
import {
  attachDirectory,
  disconnectDirectory,
  pickDirectory,
  syncToDirectory,
} from "../src/lib/workspace";
import type { State } from "../src/lib/types";

test("at least 12 popular providers and editable protocol defaults are available", () => {
  assert.ok(PRESETS.length >= 12);
  for (const id of [
    "openai",
    "anthropic",
    "deepseek",
    "zai",
    "openrouter",
    "google",
    "groq",
    "mistral",
    "xai",
    "together",
    "fireworks",
    "moonshot",
  ])
    assert.ok(PRESETS.some((p) => p.id === id));
});

test("preview compiler creates a real React module runtime and strips unshared credentials", () => {
  let s = state();
  s = {
    ...s,
    fs: applyOperation(s, {
      kind: "create_file",
      label: "Create",
      path: ".env",
      content: "THIS_MUST_NOT_ENTER_PREVIEW=secret",
    }).fs,
  };
  const result = compilePreview(
    s.fs,
    "window.__topecodeRuntime={};",
    "test-session",
  );
  assert.equal(result.entry, "src/main.tsx");
  assert.ok(result.fileCount >= 2);
  assert.match(result.html, /__load/);
  assert.match(result.html, /connect-src 'none'/);
  assert.doesNotMatch(result.html, /THIS_MUST_NOT_ENTER_PREVIEW/);
});

test("OpenAI Responses streaming supports real text and function calls", async () => {
  const original = globalThis.fetch;
  let url = "";
  let body: any;
  const args = JSON.stringify({
    summary: "Create a file",
    actions: [
      {
        kind: "create_file",
        label: "Create",
        path: "response.txt",
        content: "actual code",
      },
    ],
  });
  globalThis.fetch = async (input, init) => {
    url = String(input);
    body = JSON.parse(String(init?.body));
    return new Response(
      [
        { type: "response.output_text.delta", delta: "Here is the change. " },
        {
          type: "response.output_item.added",
          output_index: 1,
          item: { type: "function_call", name: "propose_workspace_changes" },
        },
        {
          type: "response.function_call_arguments.delta",
          output_index: 1,
          delta: args,
        },
        {
          type: "response.function_call_arguments.done",
          output_index: 1,
          name: "propose_workspace_changes",
          arguments: args,
        },
        {
          type: "response.completed",
          response: { usage: { output_tokens: 42 } },
        },
      ]
        .map((event) => `data: ${JSON.stringify(event)}\n\n`)
        .join(""),
      { headers: { "content-type": "text/event-stream" } },
    );
  };
  try {
    const response = await requestAgent({
      cfg: {
        ...presetToConfig(PRESETS[0]),
        apiStyle: "responses",
        reasoning: "low",
      },
      model: "exact-id",
      system: "Inside TopeCode",
      history: [{ role: "user", content: "Create" }],
      mode: "agent",
      signal: new AbortController().signal,
      onText: () => {},
    });
    assert.equal(url, "https://api.openai.com/v1/responses");
    assert.equal(body.store, false);
    assert.equal(body.reasoning.effort, "low");
    assert.equal(response.tokens, 42);
    assert.equal(response.tools?.[0].content, "actual code");
    assert.match(response.text, /Here is the change/);
  } finally {
    globalThis.fetch = original;
  }
});

test("incomplete model proposals are never applied", async () => {
  const original = globalThis.fetch;
  globalThis.fetch = async () =>
    new Response(
      JSON.stringify({
        choices: [
          { finish_reason: "length", message: { content: "incomplete" } },
        ],
      }),
      { headers: { "content-type": "application/json" } },
    );
  try {
    await assert.rejects(
      requestAgent({
        cfg: presetToConfig(PRESETS[0]),
        model: "test",
        system: "test",
        history: [{ role: "user", content: "Create" }],
        mode: "agent",
        signal: new AbortController().signal,
        onText: () => {},
      }),
      /output limit/,
    );
  } finally {
    globalThis.fetch = original;
  }
});

test("model generation test sends the exact editable ID and no execution tools", async () => {
  const original = globalThis.fetch;
  let body: any;
  globalThis.fetch = async (_input, init) => {
    body = JSON.parse(String(init?.body));
    return new Response(
      JSON.stringify({ choices: [{ message: { content: "OK" } }] }),
      { headers: { "content-type": "application/json" } },
    );
  };
  try {
    const result = await testGeneration(
      presetToConfig(PRESETS[0]),
      "edited-model-id-6",
    );
    assert.equal(result.ok, true);
    assert.equal(body.model, "edited-model-id-6");
    assert.equal(body.tools, undefined);
    assert.match(result.message, /generated a response successfully/);
  } finally {
    globalThis.fetch = original;
  }
});

test("thinking events drive phase animations without exposing reasoning text", async () => {
  const original = globalThis.fetch;
  const phases: string[] = [];
  let text = "";
  globalThis.fetch = async () =>
    new Response(
      [
        {
          type: "content_block_delta",
          delta: {
            type: "thinking_delta",
            thinking: "PRIVATE_REASONING_MUST_NOT_RENDER",
          },
        },
        {
          type: "content_block_delta",
          delta: { type: "text_delta", text: "A concise answer" },
        },
      ]
        .map((event) => `data: ${JSON.stringify(event)}\n\n`)
        .join(""),
      { headers: { "content-type": "text/event-stream" } },
    );
  try {
    const result = await requestAgent({
      cfg: presetToConfig(PRESETS[1]),
      model: "test",
      system: "system",
      history: [{ role: "user", content: "Ask" }],
      mode: "ask",
      signal: new AbortController().signal,
      onText: (value) => {
        text = value;
      },
      onPhase: (value) => phases.push(value),
    });
    assert.deepEqual(phases, ["thinking", "writing"]);
    assert.equal(result.text, "A concise answer");
    assert.doesNotMatch(text, /PRIVATE_REASONING/);
  } finally {
    globalThis.fetch = original;
  }
});

const state = () =>
  ({
    fs: seedFS(),
    workspacePath: "pocket-notes",
    permissions: {
      read: true,
      create_file: true,
      create_folder: true,
      edit: true,
      rename: true,
      move: true,
      delete: true,
      shell: true,
      network: true,
    },
  }) satisfies Pick<State, "fs" | "workspacePath" | "permissions">;

test("paths cannot escape the granted workspace", () => {
  for (const path of [
    "../secret",
    "a/../../secret",
    "/etc/passwd",
    "C:\\Windows\\file",
    "file\0.txt",
    "a/../b",
  ])
    assert.throws(() => safePath(path));
  assert.equal(safePath("./src//hello.ts"), "src/hello.ts");
});

test("automatic workspace searches do not expose credential-file snippets", () => {
  const s = state();
  const created = applyOperation(s, { kind: "create_file", label: "Create", path: ".env", content: "SECRET_TOKEN=private-value" });
  const result = applyOperation({ ...s, fs: created.fs }, { kind: "search", label: "Search", path: "SECRET_TOKEN" });
  assert.doesNotMatch(result.output ?? "", /private-value/);
  assert.equal(result.note, "0 matches");
});

test("nested file creation is immutable and allows empty edits", () => {
  const s = state();
  const before = JSON.stringify(s.fs);
  const made = applyOperation(s, {
    kind: "create_file",
    label: "Create",
    path: "src/a/b/test.ts",
    content: "hello",
  });
  assert.equal(JSON.stringify(s.fs), before);
  assert.equal(findPath(made.fs, "src/a/b/test.ts")?.content, "hello");
  const edited = applyOperation(
    { ...s, fs: made.fs },
    { kind: "edit", label: "Empty", path: "src/a/b/test.ts", content: "" },
  );
  assert.equal(findPath(edited.fs, "src/a/b/test.ts")?.content, "");
  assert.equal(findPath(made.fs, "src/a/b/test.ts")?.content, "hello");
});

test("create cannot silently overwrite; edit permission is enforced", () => {
  const s = state();
  assert.throws(
    () =>
      applyOperation(s, {
        kind: "create_file",
        label: "Overwrite",
        path: "README.md",
        content: "no",
      }),
    /already exists/,
  );
  s.permissions.edit = false;
  assert.throws(
    () =>
      applyOperation(s, {
        kind: "edit",
        label: "Edit",
        path: "README.md",
        content: "no",
      }),
    /Permission off/,
  );
});

test("mkdir is idempotent; renaming to the same name does not add a suffix", () => {
  const s = state();
  const before = JSON.stringify(s.fs);
  assert.equal(
    applyOperation(s, {
      kind: "create_folder",
      label: "Folder",
      path: "src/components",
    }).fs,
    s.fs,
  );
  const next = applyOperation(s, {
    kind: "rename",
    label: "Rename",
    path: "README.md",
    to: "README.md",
  });
  assert.equal(findPath(next.fs, "README.md")?.name, "README.md");
  assert.equal(JSON.stringify(s.fs), before);
});

test("folder moves cannot form a cycle, and rename collisions fail", () => {
  const s = state();
  assert.throws(
    () =>
      applyOperation(s, {
        kind: "move",
        label: "Move",
        path: "src",
        to: "src/components",
      }),
    /itself/,
  );
  assert.throws(
    () =>
      applyOperation(s, {
        kind: "rename",
        label: "Rename",
        path: "README.md",
        to: "package.json",
      }),
    /already in use/,
  );
});

test("folder operations preserve old snapshots and delete recursively", () => {
  const s = state();
  const before = JSON.stringify(s.fs);
  const moved = applyOperation(s, {
    kind: "move",
    label: "Move",
    path: "notes",
    to: "src",
  });
  const node = findPath(moved.fs, "src/notes/ideas.md");
  assert.ok(node);
  assert.equal(pathOf(moved.fs, node.id), "src/notes/ideas.md");
  assert.equal(JSON.stringify(s.fs), before);
  const deleted = applyOperation(
    { ...s, fs: moved.fs },
    { kind: "delete", label: "Delete", path: "src/notes" },
  );
  assert.equal(findPath(deleted.fs, "src/notes/ideas.md"), null);
  assert.ok(findPath(moved.fs, "src/notes/ideas.md"));
});

test("the console reads current files and never invents native execution", () => {
  const s = state();
  assert.match(runCommand("ls", s.fs, "demo"), /README.md/);
  assert.equal(
    runCommand("cat src/App.tsx", s.fs, "demo"),
    findPath(s.fs, "src/App.tsx")?.content,
  );
  assert.throws(
    () => runCommand("npm run build", s.fs, "demo"),
    /not executed/,
  );
  s.permissions.read = false;
  assert.throws(
    () => applyOperation(s, { kind: "shell", label: "List", cmd: "ls" }),
    /Permission off/,
  );
});

test("line diffs preserve repeated lines and show additions/removals", () => {
  const rows = lineDiff("one\ntwo\none\n", "one\nnew\none\n");
  assert.deepEqual(
    rows
      .filter((r) => r.kind !== "same")
      .map((r) => `${r.kind}:${r.text}`)
      .sort(),
    ["add:new", "remove:two"],
  );
  assert.equal(lineDiff("", "hello")[0].kind, "add");
});

test("template plans contain actual editable source, not magic markers", () => {
  const plan = planFromPrompt("Scaffold a todo app", seedFS(), "demo");
  let s = state();
  for (const tool of plan.tools ?? [])
    s = { ...s, fs: applyOperation(s, tool).fs };
  assert.match(findPath(s.fs, "src/App.tsx")?.content ?? "", /import TodoList/);
  assert.ok(findPath(s.fs, "src/store/todos.ts"));
  assert.equal(findPath(emptyFS("empty"), "src"), null);
});

test("a template scaffold also bootstraps an empty workspace", () => {
  let s = { ...state(), fs: emptyFS("empty") };
  const plan = planFromPrompt("Scaffold a todo app", s.fs, "empty");
  for (const tool of plan.tools ?? [])
    s = { ...s, fs: applyOperation(s, tool).fs };
  assert.match(findPath(s.fs, "src/App.tsx")?.content ?? "", /import TodoList/);
  assert.ok(findPath(s.fs, "src/main.tsx"));
  assert.ok(
    JSON.parse(findPath(s.fs, "package.json")?.content ?? "{}").devDependencies
      .vite,
  );
});

test("remote providers require HTTPS and cannot hide URL credentials", () => {
  assert.equal(
    validateEndpoint("https://api.example.com/v1/"),
    "https://api.example.com/v1",
  );
  assert.equal(
    validateEndpoint("http://127.0.0.1:11434/v1"),
    "http://127.0.0.1:11434/v1",
  );
  assert.throws(() => validateEndpoint("http://untrusted.example/v1"));
  assert.throws(() => validateEndpoint("http://localhost.evil.example/v1"));
  assert.throws(() => validateEndpoint("http://127.0.0.1.evil.example/v1"));
  assert.throws(() => validateEndpoint("https://key:secret@api.example/v1"));
});

test("provider connection errors remain errors, not simulated successes", async () => {
  const original = globalThis.fetch;
  globalThis.fetch = async () =>
    new Response(JSON.stringify({ error: { message: "Invalid API key" } }), {
      status: 401,
    });
  try {
    const response = await testProvider(presetToConfig(PRESETS[0]));
    assert.equal(response.ok, false);
    assert.match(response.message, /Invalid API key/);
  } finally {
    globalThis.fetch = original;
  }
});

test("OpenAI SSE text and tool arguments produce an actionable plan", async () => {
  const original = globalThis.fetch;
  let body: any;
  const proposal = JSON.stringify({
    summary: "Create a test file",
    actions: [
      {
        kind: "create_file",
        label: "Create file",
        path: "test.txt",
        content: "hello",
      },
    ],
  });
  globalThis.fetch = async (_input, init) => {
    body = JSON.parse(String(init?.body));
    return new Response(
      [
        { choices: [{ delta: { content: "I can help. " } }] },
        {
          choices: [
            {
              delta: {
                tool_calls: [
                  {
                    index: 0,
                    function: {
                      name: "propose_workspace_changes",
                      arguments: proposal.slice(0, 60),
                    },
                  },
                ],
              },
            },
          ],
        },
        {
          choices: [
            {
              delta: {
                tool_calls: [
                  { index: 0, function: { arguments: proposal.slice(60) } },
                ],
              },
            },
          ],
        },
      ]
        .map((event) => `data: ${JSON.stringify(event)}\n\n`)
        .join("") + "data: [DONE]\n\n",
      { headers: { "content-type": "text/event-stream" } },
    );
  };
  try {
    let streamed = "";
    const response = await requestAgent({
      cfg: presetToConfig(PRESETS[0]),
      model: "test-model",
      system: "test",
      history: [
        { role: "user", content: "hello" },
        { role: "assistant", content: "hi" },
        { role: "user", content: "create" },
      ],
      mode: "agent",
      signal: new AbortController().signal,
      onText: (text) => {
        streamed = text;
      },
    });
    assert.equal(streamed, "I can help. ");
    assert.equal(response.tools?.[0].content, "hello");
    assert.equal(body.messages[2].role, "assistant");
  } finally {
    globalThis.fetch = original;
  }
});

test("Gemini receives proper user/model parts and read-only mode omits tools", async () => {
  const original = globalThis.fetch;
  let body: any;
  globalThis.fetch = async (_input, init) => {
    body = JSON.parse(String(init?.body));
    return new Response(
      JSON.stringify({
        candidates: [{ content: { parts: [{ text: "A real reply" }] } }],
      }),
      { headers: { "content-type": "application/json" } },
    );
  };
  try {
    const response = await requestAgent({
      cfg: presetToConfig(PRESETS.find((p) => p.id === "google")!),
      model: "test",
      system: "system",
      history: [
        { role: "user", content: "hi" },
        { role: "assistant", content: "hello" },
        { role: "user", content: "question" },
      ],
      mode: "ask",
      signal: new AbortController().signal,
      onText: () => {},
    });
    assert.equal(body.contents[1].role, "model");
    assert.deepEqual(body.contents[1].parts, [{ text: "hello" }]);
    assert.equal(body.tools, undefined);
    assert.equal(response.text, "A real reply");
  } finally {
    globalThis.fetch = original;
  }
});

test("Anthropic SSE uses native tools and reconstructs partial JSON", async () => {
  const original = globalThis.fetch;
  const args = JSON.stringify({
    summary: "A proposal",
    actions: [
      {
        kind: "create_file",
        label: "Create",
        path: "a.ts",
        content: "export {};",
      },
    ],
  });
  let headers: any;
  globalThis.fetch = async (_input, init) => {
    headers = init?.headers;
    return new Response(
      [
        {
          type: "content_block_start",
          index: 0,
          content_block: {
            type: "tool_use",
            name: "propose_workspace_changes",
          },
        },
        {
          type: "content_block_delta",
          index: 0,
          delta: { type: "input_json_delta", partial_json: args },
        },
      ]
        .map((event) => `data: ${JSON.stringify(event)}\n\n`)
        .join(""),
      { headers: { "content-type": "text/event-stream" } },
    );
  };
  try {
    const response = await requestAgent({
      cfg: presetToConfig(PRESETS[1]),
      model: "test",
      system: "system",
      history: [{ role: "user", content: "Create" }],
      mode: "agent",
      signal: new AbortController().signal,
      onText: () => {},
    });
    assert.equal(headers["anthropic-dangerous-direct-browser-access"], "true");
    assert.equal(response.tools?.[0].path, "a.ts");
  } finally {
    globalThis.fetch = original;
  }
});

test("AbortController cancels the underlying provider fetch", async () => {
  const original = globalThis.fetch;
  const ctrl = new AbortController();
  globalThis.fetch = async (_input, init) =>
    new Promise((_resolve, reject) => {
      init?.signal?.addEventListener("abort", () =>
        reject(new DOMException("aborted", "AbortError")),
      );
    });
  try {
    const promise = requestAgent({
      cfg: presetToConfig(PRESETS[0]),
      model: "test",
      system: "system",
      history: [{ role: "user", content: "Hello" }],
      mode: "ask",
      signal: ctrl.signal,
      onText: () => {},
    });
    ctrl.abort();
    await assert.rejects(
      promise,
      (error: Error) => error.name === "AbortError",
    );
  } finally {
    globalThis.fetch = original;
  }
});

class MemoryFile {
  kind = "file";
  content = "";
  constructor(public name: string) {}
  async getFile() {
    return {
      name: this.name,
      size: this.content.length,
      type: "text/plain",
      lastModified: Date.now(),
      text: async () => this.content,
    };
  }
  async createWritable() {
    return {
      write: async (value: string) => {
        this.content = value;
      },
      close: async () => {},
    };
  }
}
class MemoryDirectory {
  kind = "directory";
  entries = new Map<string, MemoryFile | MemoryDirectory>();
  constructor(public name: string) {}
  async *values() {
    yield* this.entries.values();
  }
  async getDirectoryHandle(
    name: string,
    opts?: { create?: boolean },
  ): Promise<MemoryDirectory> {
    let entry = this.entries.get(name);
    if (!entry && opts?.create) {
      entry = new MemoryDirectory(name);
      this.entries.set(name, entry);
    }
    if (!entry) throw new DOMException("missing", "NotFoundError");
    if (!(entry instanceof MemoryDirectory))
      throw new DOMException("file", "TypeMismatchError");
    return entry;
  }
  async getFileHandle(
    name: string,
    opts?: { create?: boolean },
  ): Promise<MemoryFile> {
    let entry = this.entries.get(name);
    if (!entry && opts?.create) {
      entry = new MemoryFile(name);
      this.entries.set(name, entry);
    }
    if (!entry) throw new DOMException("missing", "NotFoundError");
    if (!(entry instanceof MemoryFile))
      throw new DOMException("directory", "TypeMismatchError");
    return entry;
  }
  async removeEntry(name: string) {
    this.entries.delete(name);
  }
}

test("device adapter writes actual handle contents and rejects external conflicts", async () => {
  const originalWindow = (globalThis as any).window;
  const root = new MemoryDirectory("device-project");
  const file = await root.getFileHandle("hello.txt", { create: true });
  file.content = "original";
  (globalThis as any).window = { showDirectoryPicker: async () => root };
  try {
    const { fs, handle } = await pickDirectory();
    attachDirectory(handle);
    const s = { ...state(), fs };
    const edited = applyOperation(s, {
      kind: "edit",
      label: "Edit",
      path: "hello.txt",
      content: "changed",
    });
    await syncToDirectory(fs, edited.fs);
    assert.equal(file.content, "changed");
    file.content = "external change";
    const next = applyOperation(
      { ...s, fs: edited.fs },
      { kind: "edit", label: "Edit", path: "hello.txt", content: "overwrite" },
    );
    await assert.rejects(
      syncToDirectory(edited.fs, next.fs),
      /changed outside Tope/,
    );
    assert.equal(file.content, "external change");
  } finally {
    disconnectDirectory();
    (globalThis as any).window = originalWindow;
  }
});

test("device folder deletion refuses unknown files added after indexing", async () => {
  const originalWindow = (globalThis as any).window;
  const root = new MemoryDirectory("device-project");
  const folder = await root.getDirectoryHandle("notes", { create: true });
  (globalThis as any).window = { showDirectoryPicker: async () => root };
  try {
    const { fs, handle } = await pickDirectory();
    attachDirectory(handle);
    await folder.getFileHandle("unindexed.txt", { create: true });
    const deleted = applyOperation(
      { ...state(), fs },
      { kind: "delete", label: "Delete", path: "notes" },
    );
    await assert.rejects(
      syncToDirectory(fs, deleted.fs),
      /contains new device files/,
    );
    assert.ok(await root.getDirectoryHandle("notes"));
  } finally {
    disconnectDirectory();
    (globalThis as any).window = originalWindow;
  }
});
