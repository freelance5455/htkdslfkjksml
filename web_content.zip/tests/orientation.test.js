import test from 'node:test';
import assert from 'node:assert/strict';
import { shouldShowLandscapeGuidance } from '../src/orientation.js';

test('orientation : le jeu ne présente plus de page bloquante demandant de tourner le téléphone', () => {
  assert.equal(shouldShowLandscapeGuidance({ width: 390, height: 844, coarsePointer: true }), false);
});
test('orientation : aucune fenêtre de guidage en paysage', () => {
  assert.equal(shouldShowLandscapeGuidance({ width: 844, height: 390, coarsePointer: true }), false);
});
