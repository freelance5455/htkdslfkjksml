const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync(require.resolve('../supabase-client.js'), 'utf8');

function clientHarness(fetchImpl) {
  const session = { access_token: 'test-access-token', refresh_token: 'test-refresh-token', expires_at: Math.floor(Date.now()/1000)+3600 };
  const store = new Map([['mrk-supabase-session-v1', JSON.stringify(session)]]);
  const window = { MRK_SUPABASE: { url:'https://example.supabase.co', publishableKey:'public-test-key' } };
  const context = { window, fetch: fetchImpl, localStorage: { getItem:k=>store.get(k)||null, setItem:(k,v)=>store.set(k,v), removeItem:k=>store.delete(k) }, Blob, Response, URL, Math, Date, JSON, String, Number, Error, encodeURIComponent, console };
  vm.runInNewContext(source, context);
  return window.MRKCloud;
}

test('manager export upload uses private manager bucket and company-scoped exports path', async () => {
  let request;
  const api = clientHarness(async (url, options) => { request={url,options}; return new Response(JSON.stringify({Key:'x'}),{status:200}); });
  const out = await api.uploadManagerExport('123e4567-e89b-12d3-a456-426614174000','backup.json',new Blob(['{}'],{type:'application/json'}));
  assert.equal(out.bucket,'mrk-manager-exports');
  assert.equal(out.path,'123e4567-e89b-12d3-a456-426614174000/exports/backup.json');
  assert.match(request.url,/storage\/v1\/object\/mrk-manager-exports/);
  assert.equal(request.options.method,'POST');
});

test('manager export download and delete reject paths outside the company exports folder', async () => {
  const api = clientHarness(async () => new Response('',{status:200}));
  await assert.rejects(()=>api.downloadManagerExport('../private/secret.json'),/مسیر فایل/);
  await assert.rejects(()=>api.deleteManagerExport('another-folder/file.json'),/مسیر فایل/);
});
