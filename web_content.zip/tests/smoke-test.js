/* Dependency-free regression tests for SSC PYQ Bank V1.7.8. */
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const assert = (condition, message) => { if (!condition) throw new Error(`FAIL: ${message}`); };
const root = path.join(__dirname, '..');
const appSource = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const cssSource = fs.readFileSync(path.join(root, 'styles.css'), 'utf8');
const htmlSource = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const manifestSource = fs.readFileSync(path.join(root, 'manifest.webmanifest'), 'utf8');
const serviceWorkerSource = fs.readFileSync(path.join(root, 'service-worker.js'), 'utf8');
const windowEvents = {};
const documentEvents = {};
function makeNode(id) {
  return {
    id, dataset: {}, attrs: {}, listeners: {}, innerHTML: '', hidden: false,
    title: '', textContent: '', value: '', focused: false,
    classList: {
      values: new Set(),
      add(value) { this.values.add(value); },
      remove(value) { this.values.delete(value); },
      contains(value) { return this.values.has(value); },
      toggle(value, enabled) { enabled ? this.values.add(value) : this.values.delete(value); }
    },
    setAttribute(name, value) { this.attrs[name] = value; },
    removeAttribute(name) { delete this.attrs[name]; },
    getAttribute(name) { return this.attrs[name] ?? null; },
    addEventListener(name, callback) { this.listeners[name] = callback; },
    focus() { this.focused = true; },
    querySelector() { return makeNode(`${id}-child`); }
  };
}
const nodes = Object.fromEntries([
  'mainContent', 'pageTitle', 'topbarStandard', 'topbarSearch', 'menuButton', 'searchButton',
  'searchBackButton', 'chapterSearchInput', 'micButton', 'navigationDrawer', 'drawerScrim'
].map(id => [id, makeNode(id)]));
const drawerItems = ['home', 'settings', 'about'].map(screen => { const item = makeNode(screen); item.dataset.screen = screen; return item; });
const themeMeta = makeNode('theme-meta');
const document = {
  body: { dataset: {} }, documentElement: { dataset: {} },
  getElementById(id) { return nodes[id] || null; },
  querySelector(selector) { return selector === 'meta[name="theme-color"]' ? themeMeta : null; },
  querySelectorAll(selector) { return selector === '.drawer-item' ? drawerItems : []; },
  addEventListener(name, callback) { documentEvents[name] = callback; }
};
let historyEntries = [];
const history = {
  state: null,
  replaceState(state) { this.state = state; if (!historyEntries.length) historyEntries.push(state); else historyEntries[historyEntries.length - 1] = state; },
  pushState(state) { this.state = state; historyEntries.push(state); },
  back() { if (historyEntries.length > 1) { historyEntries.pop(); this.state = historyEntries[historyEntries.length - 1]; windowEvents.popstate({ state: this.state }); } }
};
const window = { addEventListener(name, callback) { windowEvents[name] = callback; }, scrollTo() {} };
const storage = {};
const localStorage = { getItem(key) { return storage[key] ?? null; }, setItem(key, value) { storage[key] = String(value); } };
const context = { document, window, history, location: { hash: '' }, localStorage, navigator: {}, console };
vm.runInNewContext(appSource, context);
function clickMain(selector, result) {
  nodes.mainContent.listeners.click({ target: { closest: candidate => candidate === selector ? result : null } });
}
function clickDrawer(screen) {
  const item = drawerItems.find(entry => entry.dataset.screen === screen);
  assert(item, `drawer entry ${screen} should exist`);
  nodes.navigationDrawer.listeners.click({ target: { closest: selector => selector === '[data-screen]' ? item : null } });
}
function clickTopNavigation() { nodes.menuButton.listeners.click(); }

// Home now shows only four enlarged Subject strips; lower dashboard sections are removed.
const home = nodes.mainContent.innerHTML;
assert((home.match(/class="tile subject-tile"/g) || []).length === 4, 'Home must show four Subject strips');
assert((home.match(/class="tile collection-tile"/g) || []).length === 0, 'Performance Overview tiles must be removed from Home');
assert((home.match(/class="tile more-tile"/g) || []).length === 0, 'More tiles must be removed from Home');
assert((home.match(/class="tile-icon"/g) || []).length === 4, 'only the four subject icons must render on Home');
assert((home.match(/class="tile-label"/g) || []).length === 4, 'only the four subject labels must render on Home');
assert(home.includes('Subjects') && !home.includes('Performance Overview') && !home.includes('Achievements') && !home.includes('Progress Report'), 'Home must contain only the Subjects section');
for (const label of ['Mathematics', 'English', 'Reasoning', 'General Studies']) {
  assert(home.includes(label), `Home must include ${label}`);
}
const subjectMarkup = [...home.matchAll(/<button class="tile subject-tile"[\s\S]*?<\/button>/g)].map(match => match[0]);
assert(subjectMarkup.length === 4, 'four subject strip blocks should exist');
for (const tile of subjectMarkup) {
  assert(tile.indexOf('class="tile-label"') < tile.indexOf('class="tile-icon"'), 'subject name markup should precede its right-side symbol');
}
assert(home.includes('class="home-screen"'), 'Home must use its dedicated screen wrapper');
assert(cssSource.includes('height: calc(100dvh - var(--topbar-height));'), 'Home layout must use available viewport height');
assert(cssSource.includes('.home-screen {\n  height: auto;\n  max-height: none;\n  display: block;\n  align-self: flex-start;'), 'Home content should start below the top bar without stretching the strips');
assert(cssSource.includes('.subjects-section .subject-grid {') && cssSource.includes('grid-template-columns: repeat(2, minmax(0, 1fr));'), 'subjects should use a two-column strip layout');
assert(cssSource.includes('grid-template-rows: repeat(2, 50px);'), 'subject strips should be enlarged to 50px');
assert(cssSource.includes('min-height: 50px;') && cssSource.includes('height: 50px;') && cssSource.includes('padding: 7px 12px;'), 'subject strips should use enlarged dimensions');
assert(cssSource.includes('font-size: 16px;') && cssSource.includes('width: 30px;'), 'subject text and icons should be slightly larger');
assert(cssSource.includes('grid-template-rows: repeat(2, 48px);'), 'narrow screens should use 48px strips');
assert(cssSource.includes('.subjects-section { gap: 10px; margin-top: 8px; }'), 'Subjects heading and strips should shift down slightly together');
assert(cssSource.includes('align-content: start;\n  gap: 13px;'), 'standard strip spacing should increase slightly');
assert(cssSource.includes('gap: 11px; grid-template-rows: repeat(2, 48px);'), 'narrow strip spacing should increase slightly');
const subjectTileStyle = cssSource.slice(cssSource.indexOf('.subjects-section .subject-tile {'), cssSource.indexOf('.subjects-section .subject-tile .tile-label {'));
const subjectIconStyle = cssSource.slice(cssSource.indexOf('.subjects-section .subject-tile .tile-icon {'), cssSource.indexOf('.subjects-section .subject-tile .tile-icon svg'));
assert(subjectTileStyle.includes('border-radius: 0') && subjectTileStyle.includes('box-shadow: none'), 'Subject strips must keep sharp corners and no shadow');
assert(subjectIconStyle.includes('border-radius: 0') && subjectIconStyle.includes('background: transparent'), 'subject icons must remain directly on the strips without badges');
assert(nodes.pageTitle.textContent === 'Home' && nodes.mainContent.classList.contains('home-active'), 'Home title and viewport state initialize correctly');
assert(drawerItems.length === 3, 'drawer remains Home, Settings, About');
assert(nodes.topbarStandard.hidden === false && nodes.topbarSearch.hidden === true, 'normal topbar should be visible initially');
assert(nodes.searchButton.hidden === false && nodes.menuButton.innerHTML.includes('M4 6h16'), 'Home retains search and hamburger');
assert(htmlSource.includes('SSC PYQ Bank'), 'drawer branding remains');

// Settings -> Appearance now holds both Display Mode and Theme controls.
clickTopNavigation();
assert(nodes.navigationDrawer.classList.contains('open'), 'Home hamburger opens drawer');
clickDrawer('settings');
assert(nodes.pageTitle.textContent === 'Settings', 'Settings page title updates');
assert(nodes.mainContent.innerHTML.includes('data-screen="appearance"'), 'Settings offers Appearance destination');
assert(!nodes.mainContent.innerHTML.includes('data-theme-toggle'), 'Display Mode control must not be outside Appearance');
assert(!nodes.mainContent.innerHTML.includes('data-theme-choice'), 'old Light/Dark choice buttons must be removed');
clickMain('[data-screen]', { dataset: { screen: 'appearance' } });
assert(nodes.pageTitle.textContent === 'Appearance', 'Appearance page title updates');
assert(nodes.mainContent.innerHTML.includes('Display Mode') && nodes.mainContent.innerHTML.includes('Theme'), 'Appearance has Display Mode and Theme options');
assert(nodes.mainContent.innerHTML.includes('data-theme-toggle'), 'Appearance includes one-click display mode button');
assert(!nodes.mainContent.innerHTML.includes('data-theme-choice'), 'old segmented display selector is removed');
assert((nodes.mainContent.innerHTML.match(/class="palette-option"/g) || []).length === 5, 'five theme palette options render');
assert((nodes.mainContent.innerHTML.match(/class="palette-color-dot"/g) || []).length === 5, 'every theme palette has a left colour dot');
assert((nodes.mainContent.innerHTML.match(/class="palette-indicator"/g) || []).length === 5, 'every theme palette has right selected indicator');
assert(nodes.mainContent.innerHTML.includes('Switch to dark mode'), 'Light mode shows action to switch to Dark');
assert(nodes.mainContent.innerHTML.includes('class="sun-icon"') && nodes.mainContent.innerHTML.includes('class="moon-icon"'), 'V1.0.0 sun/moon icon mechanism is reused');

// One click toggles the display mode and persists it; the same control toggles back.
clickMain('[data-theme-toggle]', { dataset: {} });
assert(document.body.dataset.theme === 'dark' && document.documentElement.dataset.theme === 'dark', 'one click applies Dark mode globally');
assert(storage['ssc-theme'] === 'dark', 'Dark mode is saved using the existing preference key');
assert(nodes.mainContent.innerHTML.includes('Switch to light mode'), 'Dark mode updates the action label');
clickMain('[data-theme-toggle]', { dataset: {} });
assert(document.body.dataset.theme === 'light' && storage['ssc-theme'] === 'light', 'second click switches back to Light mode and persists');
assert(nodes.mainContent.innerHTML.includes('Switch to dark mode'), 'Light mode action label is restored');
assert(cssSource.includes('body[data-theme="dark"] .display-mode-button .moon-icon { display: block; }'), 'moon icon appears in Dark mode');
assert(cssSource.includes('body[data-theme="dark"]'), 'dark theme variables apply globally');

// Theme selection retains the previous colour-palette mechanism and does not alter display mode.
clickMain('[data-palette]', { dataset: { palette: 'blue' } });
assert(document.body.dataset.palette === 'blue', 'selected palette applies');
assert(themeMeta.attrs.content === '#245bd8', 'browser theme colour follows selected palette');
assert(nodes.mainContent.innerHTML.includes('data-palette="blue" aria-pressed="true"'), 'selected palette shows its filled indicator');
assert(document.body.dataset.theme === 'light', 'changing Theme does not change Display Mode');
clickMain('[data-theme-toggle]', { dataset: {} });
assert(document.body.dataset.theme === 'dark' && document.body.dataset.palette === 'blue', 'Display Mode toggle preserves selected Theme');

// Navigation back stack preserves Settings -> Appearance hierarchy.
clickTopNavigation();
assert(nodes.pageTitle.textContent === 'Settings', 'back from Appearance returns to Settings');
clickTopNavigation();
assert(nodes.pageTitle.textContent === 'Home', 'back from Settings returns Home');
clickTopNavigation();
clickDrawer('about');
assert(nodes.pageTitle.textContent === 'About' && nodes.mainContent.innerHTML.includes('Version 1.7.8'), 'About displays version 1.7.8');
clickTopNavigation();
assert(nodes.pageTitle.textContent === 'Home', 'back from About returns Home');

// Search remains a full topbar replacement with voice input fallback.
nodes.searchButton.listeners.click();
assert(nodes.topbarStandard.hidden === true && nodes.topbarSearch.hidden === false, 'search replaces the standard topbar');
assert(nodes.searchButton.getAttribute('aria-expanded') === 'true' && nodes.chapterSearchInput.focused, 'search sets expanded state and input focus');
nodes.micButton.listeners.click();
assert(nodes.micButton.getAttribute('title').includes('not supported'), 'unsupported speech recognition has graceful typed-input fallback');
let mockRecognition;
class MockRecognition { start() { mockRecognition = this; } abort() { if (this.onend) this.onend(); } }
window.SpeechRecognition = MockRecognition;
nodes.micButton.listeners.click();
assert(nodes.micButton.classList.contains('recording'), 'microphone enters recording state');
mockRecognition.onresult({ results: [[{ transcript: 'Number System' }]] });
assert(nodes.chapterSearchInput.value === 'Number System', 'voice transcript populates search input');
mockRecognition.onend();
assert(!nodes.micButton.classList.contains('recording'), 'microphone exits recording state');
nodes.searchBackButton.listeners.click();
assert(nodes.topbarStandard.hidden === false && nodes.topbarSearch.hidden === true, 'search back restores standard topbar');
nodes.searchButton.listeners.click();
documentEvents.keydown({ key: 'Escape' });
assert(nodes.topbarSearch.hidden === true, 'Escape exits replacement search');

// Subject and retained legacy destinations have matching placeholder screens.
for (const [screen, expectedTitle] of [
  ['mathematics', 'Mathematics'], ['english', 'English'], ['reasoning', 'Reasoning'],
  ['generalStudies', 'General Studies'], ['totalAttemptedQuestions', 'Attempted Questions'],
  ['correctQuestions', 'Correct Questions'], ['incorrectQuestions', 'Incorrect Questions'],
  ['bookmarkQuestions', 'Bookmarked Questions'], ['achievements', 'Achievements'], ['progressReport', 'Progress Report']
]) {
  clickMain('[data-screen]', { dataset: { screen } });
  assert(nodes.pageTitle.textContent === expectedTitle, `${expectedTitle} title should update`);
  assert(nodes.mainContent.innerHTML.includes('placeholder-card'), `${expectedTitle} destination should render placeholder`);
  assert(nodes.menuButton.innerHTML.includes('m15 18-6-6'), `${expectedTitle} should show inner-screen back arrow`);
  assert(nodes.searchButton.hidden === true, `${expectedTitle} should hide Home search control`);
  clickTopNavigation();
  assert(nodes.pageTitle.textContent === 'Home', `back returns Home from ${expectedTitle}`);
}

// Legacy bookmark hash, PWA shell and service-worker version remain valid.
assert(cssSource.includes('--topbar-height: 52px'), 'compact palette-coloured top bar remains');
assert(cssSource.includes('background: var(--accent);') && cssSource.includes('color: #ffffff;'), 'topbar retains palette background and white controls');
assert(htmlSource.includes('id="topbarSearch"') && htmlSource.includes('id="searchBackButton"') && htmlSource.includes('id="micButton"'), 'replacement topbar search controls remain');
assert(manifestSource.includes('"short_name": "SSC PYQ Bank"'), 'PWA launcher branding remains');
assert(serviceWorkerSource.includes('ssc-personal-practice-v1.7.8'), 'service-worker cache advances to V1.7.8');
assert(appSource.includes("const LEGACY_SCREEN_ALIASES = { bookmarkedQuestions: 'bookmarkQuestions' }"), 'legacy bookmark route remains compatible');
windowEvents.popstate({ state: { screen: 'bookmarkedQuestions' } });
assert(nodes.pageTitle.textContent === 'Bookmarked Questions', 'legacy bookmark route resolves');
assert(appSource.includes("const APP_VERSION = '1.7.8'"), 'app version advances to V1.7.8');
assert(!/Version 1\.[0-6]\.0/.test(appSource + htmlSource), 'active UI does not show an older version');
assert(appSource.includes("setTheme(document.body.dataset.theme === 'dark' ? 'light' : 'dark')"), 'one-click toggle is an explicit inverse of the current display mode');
assert(cssSource.includes('gap: 13px;'), 'subject strip spacing is increased on standard screens');
assert(cssSource.includes('font-size: 16px;'), 'subject labels are slightly larger on standard screens');
assert(cssSource.includes('gap: 11px;'), 'subject strip spacing is increased on narrow screens');
assert(cssSource.includes('font-size: 14.5px;'), 'subject labels are slightly larger on narrow screens');
console.log('PASS: V1.7.8 Home-only enlarged sharp-corner Subject strips; lower Home sections removed; top navigation, drawer, search, settings, themes, retained placeholder routes, PWA shell and cache version.');
