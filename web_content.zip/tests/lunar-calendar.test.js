import test from 'node:test';
import assert from 'node:assert/strict';
import { getLunarDate, getSeasonDayFromLunarDate, LUNAR_MONTHS, LUNAR_WEEKDAYS } from '../src/lunar-calendar.js';

test('le calendrier CGD contient douze mois de trente jours et sept jours lunaires',()=>{
  assert.equal(LUNAR_MONTHS.length,12);
  assert.equal(LUNAR_WEEKDAYS.length,7);
  assert.equal(getLunarDate(360).month,12);
  assert.equal(getLunarDate(360).day,30);
});
test('les frontières de mois et de cycle sont converties sans date terrestre',()=>{
  assert.deepEqual([getLunarDate(1).month,getLunarDate(1).day],[1,1]);
  assert.deepEqual([getLunarDate(30).month,getLunarDate(30).day],[1,30]);
  assert.deepEqual([getLunarDate(31).month,getLunarDate(31).day],[2,1]);
  assert.deepEqual([getLunarDate(361).year,getLunarDate(361).month,getLunarDate(361).day],[2,1,1]);
  assert.equal(getSeasonDayFromLunarDate({year:1,month:12,day:30}),360);
});
