"""Karty (odměny) ve hře: lišta, použití, vodorovný posun, odměny, přenos do dalšího levelu:  python3 -I tests/ui_cards.py"""
import glob, json
from playwright.sync_api import sync_playwright
exe = (glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome') or [None])[0]
SH = '/home/claude/BubbleDefence/tests/shots/'
errs, results = [], []
def check(n, c, x=''): results.append(bool(c)); print(('OK   ' if c else 'FAIL ') + n + (' ' + str(x) if x != '' else ''))
LEVEL = {'w': 12, 'h': 10, 'spawns': [{'side': 'L', 'pos': 8, 'len': 4}], 'exit': {'orb': [[19, 9], [20, 9], [19, 10], [20, 10]]},
         'rocks': [[10, 4, 1], [11, 4, 1], [10, 5, 1], [11, 5, 1]], 'walls': [[14, y] for y in range(0, 10)] + [[14, y] for y in range(12, 20)],
         'towers': [{'type': 'normal', 'x': 4, 'y': 4}], 'lives': 99, 'gold': 321, 'waves': 12, 'hp': 2, 'allowed': ['normal', 'ghost']}
WIN = "(()=>{const g=BD.debug.game; g.lives=99; g.wave=g.maxWaves-1; g.streams=[]; g.waveLeft={}; g.enemies=[]; g.startWave(); for(let i=0;i<20000&&!g.won&&!g.gameOver;i++) g.step(1/30);})()"
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=exe, args=['--no-sandbox'])
    pg = b.new_page(viewport={'width': 1280, 'height': 800})
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type in ('error', 'warning') and 'willReadFrequently' not in m.text else None)
    pg.goto('file:///home/claude/BubbleDefence/index.html'); pg.wait_for_selector('.content:not(.hidden) .intro')
    pg.click('text=Nová lokální hra'); pg.wait_for_selector('.content:not(.hidden) .menu'); pg.wait_for_timeout(300)
    pg.click('.mi:has-text("Editor")'); pg.click('.lcard.add'); pg.wait_for_selector('.edv .ed-cv'); pg.wait_for_timeout(300)
    pg.evaluate("(L=>{const l=BD.store.profile.editor.levels[0]; Object.assign(l, L); BD.debugEditor.buildMasks(); BD.debugEditor.changed(true);})(%s)" % json.dumps(LEVEL))
    pg.click('.smap-head .btn.primary'); pg.wait_for_selector('.gv canvas'); pg.wait_for_timeout(500)
    G = lambda js: pg.evaluate("(()=>{const g=BD.debug.game; return %s})()" % js)
    check('o kartách hráč neví: lišta není vidět, záložka v bestiáři taky ne', pg.locator('.dock').count() == 0 and pg.evaluate('BD.bestiary.anyCard()') is False)

    G("g.giveCard('meteor')"); pg.wait_for_timeout(400)
    check('první karta: lišta se ukáže a vyjede', pg.locator('.dock.open').count() == 1 and pg.locator('.cardi').count() == 1)
    check('oznámení o získané kartě', pg.locator('.toast').count() == 1 and 'Meteorický roj' in pg.locator('.toast').inner_text(), pg.locator('.toast').inner_text() if pg.locator('.toast').count() else '')
    check('bestiář: karta je „viděná“ a odemkla záložku', pg.evaluate("BD.bestiary.state('cards','meteor')") == 1 and pg.evaluate('BD.bestiary.anyCard()'))
    dk = pg.locator('.dock').bounding_box(); bl = pg.locator('.belt').bounding_box(); lc = pg.locator('.col.l').bounding_box()
    check('lišta je mezi levým sloupcem a pásem vln', abs(dk['x'] - (lc['x'] + lc['width'])) < 3 and abs(dk['x'] + dk['width'] - bl['x']) < 3, (dk['x'], dk['width'], lc['width'], bl['x']))
    pg.screenshot(path=SH + 'cards_dock.png')
    pg.keyboard.press('c'); pg.wait_for_timeout(450)
    check('klávesa C lištu schová', pg.locator('.dock.open').count() == 0)
    pg.keyboard.press('c'); pg.wait_for_timeout(450); check('a zase ukáže', pg.locator('.dock.open').count() == 1)

    # Atomovka
    G("g.giveCard('atomic')"); pg.wait_for_timeout(300)
    G("(()=>{ for (let i=0;i<8;i++) BD.systems.enemies.spawn(g, 'bub', 1); g.waveLeft[1]=8; g.wave=1; })()")
    n0 = G("g.enemies.filter(e=>e.alive).length"); pg.click('.cardi[data-card=atomic]'); pg.wait_for_timeout(300)
    check('Atomovka: všichni nepřátelé jsou pryč', n0 >= 8 and G("g.enemies.filter(e=>e.alive).length") == 0, n0)
    check('použitá karta zmizí z lišty a zůstane Meteorický roj', pg.locator('.cardi').count() == 1 and pg.locator('.cardi[data-card=meteor]').count() == 1)
    check('bestiář: použitá karta je „poznaná“', pg.evaluate("BD.bestiary.state('cards','atomic')") == 2)
    pg.screenshot(path=SH + 'cards_atomic.png')

    # Meteory
    G("(()=>{ for (let i=0;i<30;i++) { BD.systems.enemies.spawn(g, 'swarm', 1); const e=g.enemies[g.enemies.length-1]; e.speed=0; } g.wave=1; g.waveLeft[1]=30; })()")
    pg.click('.cardi[data-card=meteor]'); pg.wait_for_timeout(4500)
    check('Meteorický roj: spadly meteority', G("g.cardFx.length") == 0, G("JSON.stringify([g.cardFx.length,g.gameOver,g.won,g.cards.join(),g.enemies.filter(e=>e.alive).length])"))
    pg.screenshot(path=SH + 'cards_meteor.png')

    # odměna za šéfa
    n = G("g.cards.length")
    G("(()=>{ BD.systems.enemies.spawn(g, 'boss', 10); g.waveLeft[10]=1; g.kill(g.enemies[g.enemies.length-1]); })()"); pg.wait_for_timeout(300)
    check('šéf zabit → padla karta a je v liště', G("g.cards.length") >= n + 1 and pg.locator('.cardi').count() == G("g.cards.length"), G("JSON.stringify([g.cards.length, g.rewards, g.gameOver, g.won, g.enemies.length])") + ' n=' + str(n) + ' dom=' + str(pg.locator('.cardi').count()))

    # hodně karet: vodorovný posun kolečkem
    G("(()=>{ for (let i=0;i<14;i++) g.giveCard(i % 2 ? 'atomic' : 'meteor'); })()"); pg.wait_for_timeout(300)
    sc = pg.evaluate("(()=>{const e=document.querySelector('.dock-body'); return [e.scrollWidth, e.clientWidth, e.scrollLeft]})()")
    check('plná lišta: karty se nevejdou a lišta se dá posouvat', sc[0] > sc[1], sc)
    r = pg.locator('.dock-body').bounding_box(); pg.mouse.move(r['x'] + r['width'] / 2, r['y'] + r['height'] / 2); pg.mouse.wheel(0, 300); pg.wait_for_timeout(200)
    check('kolečko myši posouvá lištu vodorovně', pg.evaluate("document.querySelector('.dock-body').scrollLeft") > 100, pg.evaluate("document.querySelector('.dock-body').scrollLeft"))
    pg.screenshot(path=SH + 'cards_full.png')

    # uložení: karty jsou ve snapshotu
    check('karty jsou součástí uložené hry', len(G("g.serialize().cards")) == G("g.cards.length"))

    # story: tutoriál a první levely bez karet, dál se karty přenášejí
    pg.click('.gv .bar .btn:has-text("Menu")'); pg.wait_for_timeout(200)
    pg.evaluate("window.location.reload()"); pg.wait_for_selector('.content:not(.hidden) .intro')
    pg.click('text=Pokračovat v postupu') if pg.locator('text=Pokračovat v postupu').count() else pg.click('text=Nová lokální hra')
    pg.wait_for_selector('.content:not(.hidden) .menu'); pg.wait_for_timeout(300)
    pg.click('.mi:has-text("Story mód")'); pg.click('.ms:has-text("Nová hra")'); pg.wait_for_timeout(300)
    pg.click('.dlg .btn.primary') if pg.locator('.dlg').count() else None
    pg.wait_for_selector('.content:not(.hidden) .smap', timeout=8000); pg.wait_for_timeout(300)
    pg.click('.node.open .dot'); pg.wait_for_selector('.content:not(.hidden) .gv', timeout=8000); pg.wait_for_timeout(400)
    check('tutoriál: karty nepadají a lišta se neukáže', G('g.rewards') is False and pg.locator('.dock').count() == 0)
    pg.evaluate(WIN); pg.wait_for_timeout(500)
    pg.click('[data-act=next-level]'); pg.wait_for_selector('.content:not(.hidden) .gv', timeout=8000); pg.wait_for_timeout(400)
    check('2. level (Základy): taky bez karet', pg.evaluate('BD.debug.session.nodeId') == 'l2' and G('g.rewards') is False)
    pg.evaluate(WIN); pg.wait_for_timeout(500)
    pg.click('[data-act=next-level]'); pg.wait_for_selector('.content:not(.hidden) .gv', timeout=8000); pg.wait_for_timeout(400)
    check('3. level: karty už padají', G('g.rewards') is True and pg.evaluate('BD.debug.session.nodeId') in ('a1', 'b1', 'c1'))
    G("g.giveCard('atomic')"); pg.wait_for_timeout(300)
    check('karta ze story se ukládá do postupu', pg.evaluate('BD.store.profile.story.cards') == ['atomic'], pg.evaluate('BD.store.profile.story.cards'))
    pg.evaluate(WIN); pg.wait_for_timeout(500)
    pg.click('[data-act=next-level]'); pg.wait_for_selector('.content:not(.hidden) .gv', timeout=8000); pg.wait_for_timeout(500)
    check('karta se přenese do dalšího levelu', G("g.cards.join(',')") == 'atomic' and pg.locator('.cardi[data-card=atomic]').count() == 1, G("g.cards.join(',')"))
    b.close()
print('\nvýsledek: %d/%d' % (sum(results), len(results)), '| chyby:', errs or 'žádné')
