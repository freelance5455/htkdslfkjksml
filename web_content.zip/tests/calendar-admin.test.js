import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState } from '../src/store.js';
import { generateSeasonCalendar } from '../src/calendar.js';
import { createGalacticCupSeason } from '../src/galactic-cup.js';
import { createClubCupSeason } from '../src/club-cup.js';
import { createFederalCupSeason } from '../src/federal-cup.js';
import { applyOfficialCalendarConfiguration } from '../src/calendar-admin.js';

function setup(){const state=createInitialState();state.season=12;generateSeasonCalendar(state);createGalacticCupSeason(state);createClubCupSeason(state);createFederalCupSeason(state);return state;}
function config(){return {lunarThursdays:Array.from({length:7},(_,i)=>({weekday:'jeudi',lunarMonth:i<4?1:2,lunarDay:i<4?4+i*7:2+(i-4)*7,absoluteDay:4+i*7})),fgdRegularSeasonEnd:{absoluteDay:153},agdGalaxiesDate:{absoluteDay:156},agdClubsDate:{absoluteDay:170}};}

test('le formulaire administratif applique les calendriers FGD et AGD de façon atomique',()=>{
 const original=setup();const result=applyOfficialCalendarConfiguration(original,config());
 assert.equal(original.calendar.lunarThursdays.length,0);
 assert.equal(result.state.calendar.lunarThursdays.length,7);
 assert.equal(result.state.calendar.officialCalendars.FGD.regularSeasonEnd.absoluteDay,153);
 assert.equal(result.state.calendar.officialCalendars.AGD.coupeIntergalactiqueGalaxies.absoluteDay,156);
 assert.equal(result.state.calendar.officialCalendars.AGD.intergalactiqueClubs.absoluteDay,170);
 assert.equal(result.state.calendar.scheduleValidation.valid,true);
});

test('une configuration invalide ne modifie jamais la sauvegarde d’origine',()=>{
 const original=setup();const invalid=config();invalid.agdClubsDate.absoluteDay=169;
 assert.throws(()=>applyOfficialCalendarConfiguration(original,invalid),/fenêtres des deux compétitions AGD se chevauchent/);
 assert.equal(original.calendar.lunarThursdays.length,0);
 assert.deepEqual(original.calendar.officialCalendars,{});
});

test('le formulaire refuse une configuration incomplète sans créer de dates fictives',()=>{
 const original=setup();const invalid=config();invalid.lunarThursdays.pop();
 assert.throws(()=>applyOfficialCalendarConfiguration(original,invalid),/Sept jeudis lunaires/);
 assert.equal(original.calendar.lunarThursdays.length,0);
});
