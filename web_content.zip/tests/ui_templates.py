"""Limit 160 vrstev + počítadlo; šablony vzhledů (záložka Šablony, tvar „Šablona“), export/import:  python3 -I tests/ui_templates.py"""
import glob, json
from playwright.sync_api import sync_playwright
exe = (glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome') or [None])[0]
errs, results = [], []
def check(n, c, x=''): results.append(bool(c)); print(('OK   ' if c else 'FAIL ') + n + (' ' + str(x) if x != '' else ''))
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=exe, args=['--no-sandbox'])
    ctx = b.new_context(viewport={'width': 1440, 'height': 860}); pg = ctx.new_page()
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type in ('error', 'warning') and 'willReadFrequently' not in m.text else None)
    pg.goto('file:///home/claude/BubbleDefence/index.html'); pg.wait_for_selector('.content:not(.hidden) .intro')
    pg.evaluate("BD.dev.unlocked = true; BD.dev.studio = true; BD.studio.enable(true); BD.dev.save && BD.dev.save()")
    check('limit vrstev je 160', pg.evaluate('BD.render.sprite.LIMIT.nodes') == 160)
    # sanitize drží 160
    n = pg.evaluate("(() => { const SP = BD.render.sprite, a = []; for (let i = 0; i < 200; i++) a.push(SP.node('circle')); return SP.count(SP.sanitize({ v: 1, nodes: a })); })()")
    check('import / uložení ořízne na 160 vrstev', n == 160, n)
    # záložka Šablony
    pg.click('text=Nová lokální hra'); pg.wait_for_selector('.content:not(.hidden) .menu'); pg.wait_for_timeout(300)
    pg.click('.mi:has-text("Studio")')
    pg.wait_for_selector('.stv'); pg.wait_for_timeout(400)
    check('je záložka Šablony', pg.locator('[data-tab=templates]').count() == 1)
    pg.click('[data-tab=templates]'); pg.wait_for_timeout(300)
    check('zatím žádná šablona, záložka Vlastnosti tu není', pg.locator('.stu-item').count() == 0 and pg.locator('[data-panel=props]').count() == 0)
    pg.fill('[data-role=stu-newid]', 'Křídlo'); pg.click('[data-act=stu-create]'); pg.wait_for_timeout(400)
    check('šablona vznikla s jedním tvarem', pg.evaluate("Object.keys(BD.studio.KINDS.templates).length === 1 && BD.studio.KINDS.templates.kridlo.sprite.nodes.length === 1"))
    check('v šabloně je tlačítko Šablona, ale sama sebe nenabídne', pg.locator('[data-add=ref]').count() == 1 and pg.evaluate('BD.debugStudio.tplIds.length') == 0)
    check('počítadlo ukazuje 1 / 160', '1 / 160' in pg.inner_text('[data-role=node-count]'), pg.inner_text('[data-role=node-count]'))
    # změna barvy tvaru v šabloně
    pg.evaluate("BD.studio.KINDS.templates.kridlo.sprite.nodes[0].id")
    # věž s vloženou šablonou
    pg.click('[data-tab=towers]'); pg.wait_for_timeout(300)
    pg.click('[data-id=normal_a]'); pg.wait_for_timeout(300)
    pg.fill('[data-role=stu-newid]', 'Okřídlená'); pg.click('[data-act=stu-create]'); pg.wait_for_timeout(400)
    pg.click('[data-act=look-empty]'); pg.wait_for_timeout(300)
    check('v tvarech je „Šablona“', pg.locator('[data-add=ref]').count() == 1)
    pg.click('[data-add=ref]'); pg.wait_for_timeout(300)
    check('vložený odkaz míří na první šablonu', pg.evaluate("(() => { const sp = BD.studio.KINDS.towers[BD.studio.lastId].sprite; return sp.nodes.some(n => n.type === 'ref' && n.ref === 'kridlo'); })()"))
    check('vlastnosti odkazu: výběr šablony a měřítko', pg.locator('[data-role=ref-pick]').count() == 1)
    # vykreslení: bod uvnitř šablony vybere odkaz, ne vnitřek
    px = pg.evaluate("""(() => { const SP = BD.render.sprite, c = document.createElement('canvas'); c.width = c.height = 100; const x = c.getContext('2d');
      const ref = SP.node('ref', { ref: 'kridlo', w: 1 }); const sp = { v: 1, nodes: [ref] };
      SP.draw(x, sp, 50, 50, 40, {}, {}); const d = x.getImageData(50, 50, 1, 1).data; const hit = SP.draw(x, sp, 50, 50, 40, {}, { pick: { x: 50, y: 50 } });
      return { a: d[3], hit: hit === ref.id }; })()""")
    check('šablona se vykreslí a klik na ni patří odkazu', px['a'] > 200 and px['hit'], px)
    # změna šablony se projeví ve vzhledu věže (barva)
    pg.evaluate("BD.studio.set('templates', 'kridlo', 'sprite', Object.assign(BD.render.sprite.clone(BD.studio.KINDS.templates.kridlo.sprite), {}))")
    pg.evaluate("""(() => { const sp = BD.render.sprite.clone(BD.studio.KINDS.templates.kridlo.sprite); sp.nodes[0].w = 0.1; BD.studio.set('templates', 'kridlo', 'sprite', sp); })()""")
    px2 = pg.evaluate("""(() => { const SP = BD.render.sprite, c = document.createElement('canvas'); c.width = c.height = 100; const x = c.getContext('2d');
      const ref = SP.node('ref', { ref: 'kridlo', w: 1 }); SP.draw(x, { v: 1, nodes: [ref] }, 50, 50, 40, {}, {}); return x.getImageData(70, 50, 1, 1).data[3]; })()""")
    check('po zmenšení tvaru v šabloně se změní všechny vložené kopie (okraj už nic nekreslí)', px2 == 0, px2)
    # použití
    check('počet použití šablony = 1', pg.evaluate("BD.studio.templateUsage('kridlo')") == 1)
    # limit refs a vnořování ve sanitize
    r = pg.evaluate("""(() => { const SP = BD.render.sprite; const a = []; for (let i = 0; i < 40; i++) a.push(SP.node('ref', { ref: 'kridlo' }));
      const n1 = SP.count(SP.sanitize({ v: 1, nodes: a })); const n2 = SP.sanitize({ v: 1, nodes: [SP.node('circle'), SP.node('ref', { ref: 'kridlo' })] }, { noRef: true }); return [n1, SP.count(n2)]; })()""")
    check('odkazů je nejvýš 30 a v šabloně žádný nesmí být', r == [30, 1], r)
    # šablona na šabloně
    pg.evaluate("BD.studio.create('templates', 'Dvojkřídlo')")
    pg.evaluate("""(() => { const SP = BD.render.sprite, S = BD.studio; const sp = { v: 1, nodes: [SP.node('ref', { ref: 'kridlo', x: 1 }), SP.node('ref', { ref: 'kridlo', x: -1, flip: true })] }; S.setSprite('templates', 'dvojkridlo', sp); })()""")
    r = pg.evaluate("(() => { const S = BD.studio; return [S.KINDS.templates.dvojkridlo.sprite.nodes.length, S.tplReaches('dvojkridlo', 'kridlo'), S.tplReaches('kridlo', 'dvojkridlo')]; })()")
    check('šablona jde vložit do jiné šablony', r == [2, True, False], r)
    pg.evaluate("""(() => { const SP = BD.render.sprite, S = BD.studio; const sp = SP.clone(S.KINDS.templates.kridlo.sprite); sp.nodes.push(SP.node('ref', { ref: 'dvojkridlo' }), SP.node('ref', { ref: 'kridlo' })); S.setSprite('templates', 'kridlo', sp); })()""")
    r = pg.evaluate("BD.studio.KINDS.templates.kridlo.sprite.nodes.filter(n => n.type === 'ref').length")
    check('smyčka (šablona sama v sobě, i oklikou) se zahodí', r == 0, r)
    pg.evaluate("(() => { const S = BD.studio; const e = BD.store.profile.studio.items.templates; e.kridlo.def.sprite.nodes.push(BD.render.sprite.node('ref', { ref: 'dvojkridlo' })); S.apply(); })()")
    pxn = pg.evaluate("""(() => { const SP = BD.render.sprite, c = document.createElement('canvas'); c.width = c.height = 100; const x = c.getContext('2d');
      SP.draw(x, { v: 1, nodes: [SP.node('ref', { ref: 'kridlo' }), SP.node('ref', { ref: 'dvojkridlo', y: 0.8 })] }, 50, 50, 20, {}, {}); return true; })()""")
    check('podvržená smyčka nezasekne kreslení', pxn is True)
    pg.evaluate("(() => { const SP = BD.render.sprite, S = BD.studio; const sp = SP.clone(S.KINDS.templates.kridlo.sprite); sp.nodes[0].w = 1.2; sp.nodes[0].h = 0.5; sp.nodes[0].type = 'ellipse'; S.setSprite('templates', 'kridlo', sp); })()")
    pxn = pg.evaluate("""(() => { const SP = BD.render.sprite, c = document.createElement('canvas'); c.width = 200; c.height = 100; const x = c.getContext('2d');
      const ref = SP.node('ref', { ref: 'dvojkridlo' }); SP.draw(x, { v: 1, nodes: [ref] }, 100, 50, 20, {}, {}); const L = x.getImageData(76, 50, 1, 1).data[3], R = x.getImageData(124, 50, 1, 1).data[3];
      const hit = SP.draw(x, { v: 1, nodes: [ref] }, 100, 50, 20, {}, { pick: { x: 76, y: 50 } }); return [L, R, hit === ref.id]; })()""")
    check('vnořená šablona se vykreslí oboustranně a klik patří vnějšímu odkazu', pxn[0] > 200 and pxn[1] > 200 and pxn[2], pxn)
    check('počet použití se počítá i přes vnořenou šablonu', pg.evaluate("BD.studio.templateUsage('kridlo')") >= 1)
    # počítadlo a plno
    pg.evaluate("""(() => { const SP = BD.render.sprite, id = 'okridlena', sp = SP.clone(BD.studio.KINDS.towers[id].sprite); while (SP.count(sp) < 160) sp.nodes.push(SP.node('circle')); BD.studio.setSprite('towers', id, sp); BD.debugStudio.loadSp(); })()""")
    pg.wait_for_timeout(300)
    check('počítadlo 160 / 160 a tlačítka přidání jsou vypnutá', '160 / 160' in pg.inner_text('[data-role=node-count]') and pg.locator('[data-add=circle]').is_disabled(), pg.inner_text('[data-role=node-count]'))
    # export / import
    txt = pg.evaluate('BD.studio.exportText()'); o = json.loads(txt)
    check('export Studia obsahuje šablonu', 'kridlo' in o['items']['templates'])
    full = pg.evaluate('BD.store.exportJSON()')
    ctx2 = b.new_context(); pg2 = ctx2.new_page(); pg2.on('pageerror', lambda e: errs.append(str(e)))
    pg2.goto('file:///home/claude/BubbleDefence/index.html'); pg2.wait_for_selector('.content:not(.hidden) .intro')
    r = pg2.evaluate('(t) => BD.store.importJSON(t)', full)
    check('import celého postupu vrátí šablonu i věž s odkazem', r.get('ok') and pg2.evaluate("!!BD.studio.KINDS.templates.kridlo && Object.values(BD.data.towers).some(t => t.sprite && t.sprite.nodes.some(n => n.type === 'ref'))"), r)
    # smazání šablony
    pg.click('[data-tab=templates]'); pg.wait_for_timeout(300); pg.click('[data-id=kridlo]'); pg.wait_for_timeout(200)
    pg.click('[data-act=stu-remove]'); pg.wait_for_timeout(300)
    pg.click('.modal .btn.primary, .dlg .btn.primary, button:has-text("Smazat") >> nth=-1') if pg.locator('.modal, .dlg').count() else None
    pg.wait_for_timeout(400)
    check('šablona jde smazat, věž dál funguje', pg.evaluate("!BD.studio.KINDS.templates.kridlo && !!BD.data.towers.okridlena"), pg.evaluate("Object.keys(BD.studio.KINDS.templates)"))
    check('bez chyb', not errs, errs)
    b.close()
print('\nvýsledek: %d/%d' % (sum(results), len(results)), '| chyby:', errs or 'žádné')
