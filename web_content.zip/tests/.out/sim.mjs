var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// node_modules/three/build/three.module.js
function generateUUID() {
  const d0 = Math.random() * 4294967295 | 0;
  const d1 = Math.random() * 4294967295 | 0;
  const d2 = Math.random() * 4294967295 | 0;
  const d3 = Math.random() * 4294967295 | 0;
  const uuid = _lut[d0 & 255] + _lut[d0 >> 8 & 255] + _lut[d0 >> 16 & 255] + _lut[d0 >> 24 & 255] + "-" + _lut[d1 & 255] + _lut[d1 >> 8 & 255] + "-" + _lut[d1 >> 16 & 15 | 64] + _lut[d1 >> 24 & 255] + "-" + _lut[d2 & 63 | 128] + _lut[d2 >> 8 & 255] + "-" + _lut[d2 >> 16 & 255] + _lut[d2 >> 24 & 255] + _lut[d3 & 255] + _lut[d3 >> 8 & 255] + _lut[d3 >> 16 & 255] + _lut[d3 >> 24 & 255];
  return uuid.toLowerCase();
}
function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}
function euclideanModulo(n, m) {
  return (n % m + m) % m;
}
function mapLinear(x, a1, a2, b1, b2) {
  return b1 + (x - a1) * (b2 - b1) / (a2 - a1);
}
function inverseLerp(x, y, value) {
  if (x !== y) {
    return (value - x) / (y - x);
  } else {
    return 0;
  }
}
function lerp(x, y, t) {
  return (1 - t) * x + t * y;
}
function damp(x, y, lambda, dt) {
  return lerp(x, y, 1 - Math.exp(-lambda * dt));
}
function pingpong(x, length = 1) {
  return length - Math.abs(euclideanModulo(x, length * 2) - length);
}
function smoothstep(x, min, max) {
  if (x <= min) return 0;
  if (x >= max) return 1;
  x = (x - min) / (max - min);
  return x * x * (3 - 2 * x);
}
function smootherstep(x, min, max) {
  if (x <= min) return 0;
  if (x >= max) return 1;
  x = (x - min) / (max - min);
  return x * x * x * (x * (x * 6 - 15) + 10);
}
function randInt(low, high) {
  return low + Math.floor(Math.random() * (high - low + 1));
}
function randFloat(low, high) {
  return low + Math.random() * (high - low);
}
function randFloatSpread(range) {
  return range * (0.5 - Math.random());
}
function seededRandom(s) {
  if (s !== void 0) _seed = s;
  let t = _seed += 1831565813;
  t = Math.imul(t ^ t >>> 15, t | 1);
  t ^= t + Math.imul(t ^ t >>> 7, t | 61);
  return ((t ^ t >>> 14) >>> 0) / 4294967296;
}
function degToRad(degrees) {
  return degrees * DEG2RAD;
}
function radToDeg(radians) {
  return radians * RAD2DEG;
}
function isPowerOfTwo(value) {
  return (value & value - 1) === 0 && value !== 0;
}
function ceilPowerOfTwo(value) {
  return Math.pow(2, Math.ceil(Math.log(value) / Math.LN2));
}
function floorPowerOfTwo(value) {
  return Math.pow(2, Math.floor(Math.log(value) / Math.LN2));
}
function setQuaternionFromProperEuler(q, a, b, c, order) {
  const cos = Math.cos;
  const sin = Math.sin;
  const c2 = cos(b / 2);
  const s2 = sin(b / 2);
  const c13 = cos((a + c) / 2);
  const s13 = sin((a + c) / 2);
  const c1_3 = cos((a - c) / 2);
  const s1_3 = sin((a - c) / 2);
  const c3_1 = cos((c - a) / 2);
  const s3_1 = sin((c - a) / 2);
  switch (order) {
    case "XYX":
      q.set(c2 * s13, s2 * c1_3, s2 * s1_3, c2 * c13);
      break;
    case "YZY":
      q.set(s2 * s1_3, c2 * s13, s2 * c1_3, c2 * c13);
      break;
    case "ZXZ":
      q.set(s2 * c1_3, s2 * s1_3, c2 * s13, c2 * c13);
      break;
    case "XZX":
      q.set(c2 * s13, s2 * s3_1, s2 * c3_1, c2 * c13);
      break;
    case "YXY":
      q.set(s2 * c3_1, c2 * s13, s2 * s3_1, c2 * c13);
      break;
    case "ZYZ":
      q.set(s2 * s3_1, s2 * c3_1, c2 * s13, c2 * c13);
      break;
    default:
      console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: " + order);
  }
}
function denormalize(value, array) {
  switch (array.constructor) {
    case Float32Array:
      return value;
    case Uint32Array:
      return value / 4294967295;
    case Uint16Array:
      return value / 65535;
    case Uint8Array:
      return value / 255;
    case Int32Array:
      return Math.max(value / 2147483647, -1);
    case Int16Array:
      return Math.max(value / 32767, -1);
    case Int8Array:
      return Math.max(value / 127, -1);
    default:
      throw new Error("Invalid component type.");
  }
}
function normalize(value, array) {
  switch (array.constructor) {
    case Float32Array:
      return value;
    case Uint32Array:
      return Math.round(value * 4294967295);
    case Uint16Array:
      return Math.round(value * 65535);
    case Uint8Array:
      return Math.round(value * 255);
    case Int32Array:
      return Math.round(value * 2147483647);
    case Int16Array:
      return Math.round(value * 32767);
    case Int8Array:
      return Math.round(value * 127);
    default:
      throw new Error("Invalid component type.");
  }
}
function arrayNeedsUint32(array) {
  for (let i = array.length - 1; i >= 0; --i) {
    if (array[i] >= 65535) return true;
  }
  return false;
}
function createElementNS(name) {
  return document.createElementNS("http://www.w3.org/1999/xhtml", name);
}
function SRGBToLinear(c) {
  return c < 0.04045 ? c * 0.0773993808 : Math.pow(c * 0.9478672986 + 0.0521327014, 2.4);
}
function LinearToSRGB(c) {
  return c < 31308e-7 ? c * 12.92 : 1.055 * Math.pow(c, 0.41666) - 0.055;
}
function serializeImage(image) {
  if (typeof HTMLImageElement !== "undefined" && image instanceof HTMLImageElement || typeof HTMLCanvasElement !== "undefined" && image instanceof HTMLCanvasElement || typeof ImageBitmap !== "undefined" && image instanceof ImageBitmap) {
    return ImageUtils.getDataURL(image);
  } else {
    if (image.data) {
      return {
        data: Array.from(image.data),
        width: image.width,
        height: image.height,
        type: image.data.constructor.name
      };
    } else {
      console.warn("THREE.Texture: Unable to serialize Texture.");
      return {};
    }
  }
}
function satForAxes(axes, v0, v1, v2, extents) {
  for (let i = 0, j = axes.length - 3; i <= j; i += 3) {
    _testAxis.fromArray(axes, i);
    const r = extents.x * Math.abs(_testAxis.x) + extents.y * Math.abs(_testAxis.y) + extents.z * Math.abs(_testAxis.z);
    const p0 = v0.dot(_testAxis);
    const p1 = v1.dot(_testAxis);
    const p2 = v2.dot(_testAxis);
    if (Math.max(-Math.max(p0, p1, p2), Math.min(p0, p1, p2)) > r) {
      return false;
    }
  }
  return true;
}
function hue2rgb(p, q, t) {
  if (t < 0) t += 1;
  if (t > 1) t -= 1;
  if (t < 1 / 6) return p + (q - p) * 6 * t;
  if (t < 1 / 2) return q;
  if (t < 2 / 3) return p + (q - p) * 6 * (2 / 3 - t);
  return p;
}
function checkIntersection$1(object, material, raycaster, ray, pA, pB, pC, point) {
  let intersect;
  if (material.side === BackSide) {
    intersect = ray.intersectTriangle(pC, pB, pA, true, point);
  } else {
    intersect = ray.intersectTriangle(pA, pB, pC, material.side === FrontSide, point);
  }
  if (intersect === null) return null;
  _intersectionPointWorld.copy(point);
  _intersectionPointWorld.applyMatrix4(object.matrixWorld);
  const distance = raycaster.ray.origin.distanceTo(_intersectionPointWorld);
  if (distance < raycaster.near || distance > raycaster.far) return null;
  return {
    distance,
    point: _intersectionPointWorld.clone(),
    object
  };
}
function checkGeometryIntersection(object, material, raycaster, ray, uv, uv1, normal, a, b, c) {
  object.getVertexPosition(a, _vA$1);
  object.getVertexPosition(b, _vB$1);
  object.getVertexPosition(c, _vC$1);
  const intersection = checkIntersection$1(object, material, raycaster, ray, _vA$1, _vB$1, _vC$1, _intersectionPoint);
  if (intersection) {
    const barycoord = new Vector3();
    Triangle.getBarycoord(_intersectionPoint, _vA$1, _vB$1, _vC$1, barycoord);
    if (uv) {
      intersection.uv = Triangle.getInterpolatedAttribute(uv, a, b, c, barycoord, new Vector2());
    }
    if (uv1) {
      intersection.uv1 = Triangle.getInterpolatedAttribute(uv1, a, b, c, barycoord, new Vector2());
    }
    if (normal) {
      intersection.normal = Triangle.getInterpolatedAttribute(normal, a, b, c, barycoord, new Vector3());
      if (intersection.normal.dot(ray.direction) > 0) {
        intersection.normal.multiplyScalar(-1);
      }
    }
    const face = {
      a,
      b,
      c,
      normal: new Vector3(),
      materialIndex: 0
    };
    Triangle.getNormal(_vA$1, _vB$1, _vC$1, face.normal);
    intersection.face = face;
    intersection.barycoord = barycoord;
  }
  return intersection;
}
function cloneUniforms(src) {
  const dst = {};
  for (const u in src) {
    dst[u] = {};
    for (const p in src[u]) {
      const property = src[u][p];
      if (property && (property.isColor || property.isMatrix3 || property.isMatrix4 || property.isVector2 || property.isVector3 || property.isVector4 || property.isTexture || property.isQuaternion)) {
        if (property.isRenderTargetTexture) {
          console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms().");
          dst[u][p] = null;
        } else {
          dst[u][p] = property.clone();
        }
      } else if (Array.isArray(property)) {
        dst[u][p] = property.slice();
      } else {
        dst[u][p] = property;
      }
    }
  }
  return dst;
}
function mergeUniforms(uniforms) {
  const merged = {};
  for (let u = 0; u < uniforms.length; u++) {
    const tmp = cloneUniforms(uniforms[u]);
    for (const p in tmp) {
      merged[p] = tmp[p];
    }
  }
  return merged;
}
function convertArray(array, type, forceClone) {
  if (!array || // let 'undefined' and 'null' pass
  !forceClone && array.constructor === type) return array;
  if (typeof type.BYTES_PER_ELEMENT === "number") {
    return new type(array);
  }
  return Array.prototype.slice.call(array);
}
function isTypedArray(object) {
  return ArrayBuffer.isView(object) && !(object instanceof DataView);
}
var REVISION, FrontSide, BackSide, DoubleSide, NormalBlending, AddEquation, SrcAlphaFactor, OneMinusSrcAlphaFactor, NeverDepth, AlwaysDepth, LessDepth, LessEqualDepth, EqualDepth, GreaterEqualDepth, GreaterDepth, NotEqualDepth, MultiplyOperation, UVMapping, RepeatWrapping, ClampToEdgeWrapping, MirroredRepeatWrapping, LinearFilter, LinearMipmapLinearFilter, UnsignedByteType, FloatType, RGBAFormat, InterpolateDiscrete, InterpolateLinear, InterpolateSmooth, ZeroCurvatureEnding, ZeroSlopeEnding, WrapAroundEnding, TangentSpaceNormalMap, NoColorSpace, SRGBColorSpace, LinearSRGBColorSpace, LinearTransfer, SRGBTransfer, KeepStencilOp, AlwaysStencilFunc, StaticDrawUsage, WebGLCoordinateSystem, WebGPUCoordinateSystem, EventDispatcher, _lut, _seed, DEG2RAD, RAD2DEG, MathUtils, Vector2, Matrix3, _m3, ColorManagement, REC709_PRIMARIES, REC709_LUMINANCE_COEFFICIENTS, D65, LINEAR_REC709_TO_XYZ, XYZ_TO_LINEAR_REC709, _canvas, ImageUtils, _sourceId, Source, _textureId, Texture, Vector4, Quaternion, Vector3, _vector$c, _quaternion$4, Box3, _points, _vector$b, _box$4, _v0$3, _v1$7, _v2$4, _f0, _f1, _f2, _center, _extents, _triangleNormal, _testAxis, _box$3, _v1$6, _v2$3, Sphere, _vector$a, _segCenter, _segDir, _diff, _edge1, _edge2, _normal$1, Ray, Matrix4, _v1$5, _m1$4, _zero, _one, _x, _y, _z, _matrix$2, _quaternion$3, Euler, Layers, _object3DId, _v1$4, _q1, _m1$3, _target, _position$3, _scale$2, _quaternion$2, _xAxis, _yAxis, _zAxis, _addedEvent, _removedEvent, _childaddedEvent, _childremovedEvent, Object3D, _v0$2, _v1$3, _v2$2, _v3$2, _vab, _vac, _vbc, _vap, _vbp, _vcp, _v40, _v41, _v42, Triangle, _colorKeywords, _hslA, _hslB, Color, _color, _materialId, Material, MeshBasicMaterial, _vector$9, _vector2$1, BufferAttribute, Uint16BufferAttribute, Uint32BufferAttribute, Float32BufferAttribute, _id$2, _m1$2, _obj, _offset, _box$2, _boxMorphTargets, _vector$8, BufferGeometry, _inverseMatrix$3, _ray$3, _sphere$6, _sphereHitAt, _vA$1, _vB$1, _vC$1, _tempA, _morphA, _intersectionPoint, _intersectionPointWorld, Mesh, BoxGeometry, PlaneGeometry, alphahash_fragment, alphahash_pars_fragment, alphamap_fragment, alphamap_pars_fragment, alphatest_fragment, alphatest_pars_fragment, aomap_fragment, aomap_pars_fragment, batching_pars_vertex, batching_vertex, begin_vertex, beginnormal_vertex, bsdfs, iridescence_fragment, bumpmap_pars_fragment, clipping_planes_fragment, clipping_planes_pars_fragment, clipping_planes_pars_vertex, clipping_planes_vertex, color_fragment, color_pars_fragment, color_pars_vertex, color_vertex, common, cube_uv_reflection_fragment, defaultnormal_vertex, displacementmap_pars_vertex, displacementmap_vertex, emissivemap_fragment, emissivemap_pars_fragment, colorspace_fragment, colorspace_pars_fragment, envmap_fragment, envmap_common_pars_fragment, envmap_pars_fragment, envmap_pars_vertex, envmap_vertex, fog_vertex, fog_pars_vertex, fog_fragment, fog_pars_fragment, gradientmap_pars_fragment, lightmap_pars_fragment, lights_lambert_fragment, lights_lambert_pars_fragment, lights_pars_begin, envmap_physical_pars_fragment, lights_toon_fragment, lights_toon_pars_fragment, lights_phong_fragment, lights_phong_pars_fragment, lights_physical_fragment, lights_physical_pars_fragment, lights_fragment_begin, lights_fragment_maps, lights_fragment_end, logdepthbuf_fragment, logdepthbuf_pars_fragment, logdepthbuf_pars_vertex, logdepthbuf_vertex, map_fragment, map_pars_fragment, map_particle_fragment, map_particle_pars_fragment, metalnessmap_fragment, metalnessmap_pars_fragment, morphinstance_vertex, morphcolor_vertex, morphnormal_vertex, morphtarget_pars_vertex, morphtarget_vertex, normal_fragment_begin, normal_fragment_maps, normal_pars_fragment, normal_pars_vertex, normal_vertex, normalmap_pars_fragment, clearcoat_normal_fragment_begin, clearcoat_normal_fragment_maps, clearcoat_pars_fragment, iridescence_pars_fragment, opaque_fragment, packing, premultiplied_alpha_fragment, project_vertex, dithering_fragment, dithering_pars_fragment, roughnessmap_fragment, roughnessmap_pars_fragment, shadowmap_pars_fragment, shadowmap_pars_vertex, shadowmap_vertex, shadowmask_pars_fragment, skinbase_vertex, skinning_pars_vertex, skinning_vertex, skinnormal_vertex, specularmap_fragment, specularmap_pars_fragment, tonemapping_fragment, tonemapping_pars_fragment, transmission_fragment, transmission_pars_fragment, uv_pars_fragment, uv_pars_vertex, uv_vertex, worldpos_vertex, vertex$h, fragment$h, vertex$g, fragment$g, vertex$f, fragment$f, vertex$e, fragment$e, vertex$d, fragment$d, vertex$c, fragment$c, vertex$b, fragment$b, vertex$a, fragment$a, vertex$9, fragment$9, vertex$8, fragment$8, vertex$7, fragment$7, vertex$6, fragment$6, vertex$5, fragment$5, vertex$4, fragment$4, vertex$3, fragment$3, vertex$2, fragment$2, vertex$1, fragment$1, ShaderChunk, UniformsLib, ShaderLib, PHI, INV_PHI, _axisDirections, mat4array, mat3array, mat2array, reversedFuncs, Group, Scene, CanvasTexture, CylinderGeometry, PolyhedronGeometry, IcosahedronGeometry, SphereGeometry, MeshStandardMaterial, MeshLambertMaterial, Interpolant, CubicInterpolant, LinearInterpolant, DiscreteInterpolant, KeyframeTrack, BooleanKeyframeTrack, ColorKeyframeTrack, NumberKeyframeTrack, QuaternionLinearInterpolant, QuaternionKeyframeTrack, StringKeyframeTrack, VectorKeyframeTrack, LoadingManager, DefaultLoadingManager, Loader, _RESERVED_CHARS_RE, _reservedRe, _wordChar, _wordCharOrDot, _directoryRe, _nodeRe, _objectRe, _propertyRe, _trackRe, _supportedObjectNames, Composite, PropertyBinding, _controlInterpolantsResultBuffer;
var init_three_module = __esm({
  "node_modules/three/build/three.module.js"() {
    REVISION = "170";
    FrontSide = 0;
    BackSide = 1;
    DoubleSide = 2;
    NormalBlending = 1;
    AddEquation = 100;
    SrcAlphaFactor = 204;
    OneMinusSrcAlphaFactor = 205;
    NeverDepth = 0;
    AlwaysDepth = 1;
    LessDepth = 2;
    LessEqualDepth = 3;
    EqualDepth = 4;
    GreaterEqualDepth = 5;
    GreaterDepth = 6;
    NotEqualDepth = 7;
    MultiplyOperation = 0;
    UVMapping = 300;
    RepeatWrapping = 1e3;
    ClampToEdgeWrapping = 1001;
    MirroredRepeatWrapping = 1002;
    LinearFilter = 1006;
    LinearMipmapLinearFilter = 1008;
    UnsignedByteType = 1009;
    FloatType = 1015;
    RGBAFormat = 1023;
    InterpolateDiscrete = 2300;
    InterpolateLinear = 2301;
    InterpolateSmooth = 2302;
    ZeroCurvatureEnding = 2400;
    ZeroSlopeEnding = 2401;
    WrapAroundEnding = 2402;
    TangentSpaceNormalMap = 0;
    NoColorSpace = "";
    SRGBColorSpace = "srgb";
    LinearSRGBColorSpace = "srgb-linear";
    LinearTransfer = "linear";
    SRGBTransfer = "srgb";
    KeepStencilOp = 7680;
    AlwaysStencilFunc = 519;
    StaticDrawUsage = 35044;
    WebGLCoordinateSystem = 2e3;
    WebGPUCoordinateSystem = 2001;
    EventDispatcher = class {
      addEventListener(type, listener) {
        if (this._listeners === void 0) this._listeners = {};
        const listeners = this._listeners;
        if (listeners[type] === void 0) {
          listeners[type] = [];
        }
        if (listeners[type].indexOf(listener) === -1) {
          listeners[type].push(listener);
        }
      }
      hasEventListener(type, listener) {
        if (this._listeners === void 0) return false;
        const listeners = this._listeners;
        return listeners[type] !== void 0 && listeners[type].indexOf(listener) !== -1;
      }
      removeEventListener(type, listener) {
        if (this._listeners === void 0) return;
        const listeners = this._listeners;
        const listenerArray = listeners[type];
        if (listenerArray !== void 0) {
          const index = listenerArray.indexOf(listener);
          if (index !== -1) {
            listenerArray.splice(index, 1);
          }
        }
      }
      dispatchEvent(event) {
        if (this._listeners === void 0) return;
        const listeners = this._listeners;
        const listenerArray = listeners[event.type];
        if (listenerArray !== void 0) {
          event.target = this;
          const array = listenerArray.slice(0);
          for (let i = 0, l = array.length; i < l; i++) {
            array[i].call(this, event);
          }
          event.target = null;
        }
      }
    };
    _lut = ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "0a", "0b", "0c", "0d", "0e", "0f", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "1a", "1b", "1c", "1d", "1e", "1f", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "2a", "2b", "2c", "2d", "2e", "2f", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "3a", "3b", "3c", "3d", "3e", "3f", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "4a", "4b", "4c", "4d", "4e", "4f", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "5a", "5b", "5c", "5d", "5e", "5f", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "6a", "6b", "6c", "6d", "6e", "6f", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "7a", "7b", "7c", "7d", "7e", "7f", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "8a", "8b", "8c", "8d", "8e", "8f", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "9a", "9b", "9c", "9d", "9e", "9f", "a0", "a1", "a2", "a3", "a4", "a5", "a6", "a7", "a8", "a9", "aa", "ab", "ac", "ad", "ae", "af", "b0", "b1", "b2", "b3", "b4", "b5", "b6", "b7", "b8", "b9", "ba", "bb", "bc", "bd", "be", "bf", "c0", "c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9", "ca", "cb", "cc", "cd", "ce", "cf", "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "da", "db", "dc", "dd", "de", "df", "e0", "e1", "e2", "e3", "e4", "e5", "e6", "e7", "e8", "e9", "ea", "eb", "ec", "ed", "ee", "ef", "f0", "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "fa", "fb", "fc", "fd", "fe", "ff"];
    _seed = 1234567;
    DEG2RAD = Math.PI / 180;
    RAD2DEG = 180 / Math.PI;
    MathUtils = {
      DEG2RAD,
      RAD2DEG,
      generateUUID,
      clamp,
      euclideanModulo,
      mapLinear,
      inverseLerp,
      lerp,
      damp,
      pingpong,
      smoothstep,
      smootherstep,
      randInt,
      randFloat,
      randFloatSpread,
      seededRandom,
      degToRad,
      radToDeg,
      isPowerOfTwo,
      ceilPowerOfTwo,
      floorPowerOfTwo,
      setQuaternionFromProperEuler,
      normalize,
      denormalize
    };
    Vector2 = class _Vector2 {
      constructor(x = 0, y = 0) {
        _Vector2.prototype.isVector2 = true;
        this.x = x;
        this.y = y;
      }
      get width() {
        return this.x;
      }
      set width(value) {
        this.x = value;
      }
      get height() {
        return this.y;
      }
      set height(value) {
        this.y = value;
      }
      set(x, y) {
        this.x = x;
        this.y = y;
        return this;
      }
      setScalar(scalar) {
        this.x = scalar;
        this.y = scalar;
        return this;
      }
      setX(x) {
        this.x = x;
        return this;
      }
      setY(y) {
        this.y = y;
        return this;
      }
      setComponent(index, value) {
        switch (index) {
          case 0:
            this.x = value;
            break;
          case 1:
            this.y = value;
            break;
          default:
            throw new Error("index is out of range: " + index);
        }
        return this;
      }
      getComponent(index) {
        switch (index) {
          case 0:
            return this.x;
          case 1:
            return this.y;
          default:
            throw new Error("index is out of range: " + index);
        }
      }
      clone() {
        return new this.constructor(this.x, this.y);
      }
      copy(v) {
        this.x = v.x;
        this.y = v.y;
        return this;
      }
      add(v) {
        this.x += v.x;
        this.y += v.y;
        return this;
      }
      addScalar(s) {
        this.x += s;
        this.y += s;
        return this;
      }
      addVectors(a, b) {
        this.x = a.x + b.x;
        this.y = a.y + b.y;
        return this;
      }
      addScaledVector(v, s) {
        this.x += v.x * s;
        this.y += v.y * s;
        return this;
      }
      sub(v) {
        this.x -= v.x;
        this.y -= v.y;
        return this;
      }
      subScalar(s) {
        this.x -= s;
        this.y -= s;
        return this;
      }
      subVectors(a, b) {
        this.x = a.x - b.x;
        this.y = a.y - b.y;
        return this;
      }
      multiply(v) {
        this.x *= v.x;
        this.y *= v.y;
        return this;
      }
      multiplyScalar(scalar) {
        this.x *= scalar;
        this.y *= scalar;
        return this;
      }
      divide(v) {
        this.x /= v.x;
        this.y /= v.y;
        return this;
      }
      divideScalar(scalar) {
        return this.multiplyScalar(1 / scalar);
      }
      applyMatrix3(m) {
        const x = this.x, y = this.y;
        const e = m.elements;
        this.x = e[0] * x + e[3] * y + e[6];
        this.y = e[1] * x + e[4] * y + e[7];
        return this;
      }
      min(v) {
        this.x = Math.min(this.x, v.x);
        this.y = Math.min(this.y, v.y);
        return this;
      }
      max(v) {
        this.x = Math.max(this.x, v.x);
        this.y = Math.max(this.y, v.y);
        return this;
      }
      clamp(min, max) {
        this.x = Math.max(min.x, Math.min(max.x, this.x));
        this.y = Math.max(min.y, Math.min(max.y, this.y));
        return this;
      }
      clampScalar(minVal, maxVal) {
        this.x = Math.max(minVal, Math.min(maxVal, this.x));
        this.y = Math.max(minVal, Math.min(maxVal, this.y));
        return this;
      }
      clampLength(min, max) {
        const length = this.length();
        return this.divideScalar(length || 1).multiplyScalar(Math.max(min, Math.min(max, length)));
      }
      floor() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this;
      }
      ceil() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this;
      }
      round() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this;
      }
      roundToZero() {
        this.x = Math.trunc(this.x);
        this.y = Math.trunc(this.y);
        return this;
      }
      negate() {
        this.x = -this.x;
        this.y = -this.y;
        return this;
      }
      dot(v) {
        return this.x * v.x + this.y * v.y;
      }
      cross(v) {
        return this.x * v.y - this.y * v.x;
      }
      lengthSq() {
        return this.x * this.x + this.y * this.y;
      }
      length() {
        return Math.sqrt(this.x * this.x + this.y * this.y);
      }
      manhattanLength() {
        return Math.abs(this.x) + Math.abs(this.y);
      }
      normalize() {
        return this.divideScalar(this.length() || 1);
      }
      angle() {
        const angle = Math.atan2(-this.y, -this.x) + Math.PI;
        return angle;
      }
      angleTo(v) {
        const denominator = Math.sqrt(this.lengthSq() * v.lengthSq());
        if (denominator === 0) return Math.PI / 2;
        const theta = this.dot(v) / denominator;
        return Math.acos(clamp(theta, -1, 1));
      }
      distanceTo(v) {
        return Math.sqrt(this.distanceToSquared(v));
      }
      distanceToSquared(v) {
        const dx = this.x - v.x, dy = this.y - v.y;
        return dx * dx + dy * dy;
      }
      manhattanDistanceTo(v) {
        return Math.abs(this.x - v.x) + Math.abs(this.y - v.y);
      }
      setLength(length) {
        return this.normalize().multiplyScalar(length);
      }
      lerp(v, alpha) {
        this.x += (v.x - this.x) * alpha;
        this.y += (v.y - this.y) * alpha;
        return this;
      }
      lerpVectors(v1, v2, alpha) {
        this.x = v1.x + (v2.x - v1.x) * alpha;
        this.y = v1.y + (v2.y - v1.y) * alpha;
        return this;
      }
      equals(v) {
        return v.x === this.x && v.y === this.y;
      }
      fromArray(array, offset = 0) {
        this.x = array[offset];
        this.y = array[offset + 1];
        return this;
      }
      toArray(array = [], offset = 0) {
        array[offset] = this.x;
        array[offset + 1] = this.y;
        return array;
      }
      fromBufferAttribute(attribute, index) {
        this.x = attribute.getX(index);
        this.y = attribute.getY(index);
        return this;
      }
      rotateAround(center, angle) {
        const c = Math.cos(angle), s = Math.sin(angle);
        const x = this.x - center.x;
        const y = this.y - center.y;
        this.x = x * c - y * s + center.x;
        this.y = x * s + y * c + center.y;
        return this;
      }
      random() {
        this.x = Math.random();
        this.y = Math.random();
        return this;
      }
      *[Symbol.iterator]() {
        yield this.x;
        yield this.y;
      }
    };
    Matrix3 = class _Matrix3 {
      constructor(n11, n12, n13, n21, n22, n23, n31, n32, n33) {
        _Matrix3.prototype.isMatrix3 = true;
        this.elements = [
          1,
          0,
          0,
          0,
          1,
          0,
          0,
          0,
          1
        ];
        if (n11 !== void 0) {
          this.set(n11, n12, n13, n21, n22, n23, n31, n32, n33);
        }
      }
      set(n11, n12, n13, n21, n22, n23, n31, n32, n33) {
        const te = this.elements;
        te[0] = n11;
        te[1] = n21;
        te[2] = n31;
        te[3] = n12;
        te[4] = n22;
        te[5] = n32;
        te[6] = n13;
        te[7] = n23;
        te[8] = n33;
        return this;
      }
      identity() {
        this.set(
          1,
          0,
          0,
          0,
          1,
          0,
          0,
          0,
          1
        );
        return this;
      }
      copy(m) {
        const te = this.elements;
        const me = m.elements;
        te[0] = me[0];
        te[1] = me[1];
        te[2] = me[2];
        te[3] = me[3];
        te[4] = me[4];
        te[5] = me[5];
        te[6] = me[6];
        te[7] = me[7];
        te[8] = me[8];
        return this;
      }
      extractBasis(xAxis, yAxis, zAxis) {
        xAxis.setFromMatrix3Column(this, 0);
        yAxis.setFromMatrix3Column(this, 1);
        zAxis.setFromMatrix3Column(this, 2);
        return this;
      }
      setFromMatrix4(m) {
        const me = m.elements;
        this.set(
          me[0],
          me[4],
          me[8],
          me[1],
          me[5],
          me[9],
          me[2],
          me[6],
          me[10]
        );
        return this;
      }
      multiply(m) {
        return this.multiplyMatrices(this, m);
      }
      premultiply(m) {
        return this.multiplyMatrices(m, this);
      }
      multiplyMatrices(a, b) {
        const ae = a.elements;
        const be = b.elements;
        const te = this.elements;
        const a11 = ae[0], a12 = ae[3], a13 = ae[6];
        const a21 = ae[1], a22 = ae[4], a23 = ae[7];
        const a31 = ae[2], a32 = ae[5], a33 = ae[8];
        const b11 = be[0], b12 = be[3], b13 = be[6];
        const b21 = be[1], b22 = be[4], b23 = be[7];
        const b31 = be[2], b32 = be[5], b33 = be[8];
        te[0] = a11 * b11 + a12 * b21 + a13 * b31;
        te[3] = a11 * b12 + a12 * b22 + a13 * b32;
        te[6] = a11 * b13 + a12 * b23 + a13 * b33;
        te[1] = a21 * b11 + a22 * b21 + a23 * b31;
        te[4] = a21 * b12 + a22 * b22 + a23 * b32;
        te[7] = a21 * b13 + a22 * b23 + a23 * b33;
        te[2] = a31 * b11 + a32 * b21 + a33 * b31;
        te[5] = a31 * b12 + a32 * b22 + a33 * b32;
        te[8] = a31 * b13 + a32 * b23 + a33 * b33;
        return this;
      }
      multiplyScalar(s) {
        const te = this.elements;
        te[0] *= s;
        te[3] *= s;
        te[6] *= s;
        te[1] *= s;
        te[4] *= s;
        te[7] *= s;
        te[2] *= s;
        te[5] *= s;
        te[8] *= s;
        return this;
      }
      determinant() {
        const te = this.elements;
        const a = te[0], b = te[1], c = te[2], d = te[3], e = te[4], f = te[5], g = te[6], h = te[7], i = te[8];
        return a * e * i - a * f * h - b * d * i + b * f * g + c * d * h - c * e * g;
      }
      invert() {
        const te = this.elements, n11 = te[0], n21 = te[1], n31 = te[2], n12 = te[3], n22 = te[4], n32 = te[5], n13 = te[6], n23 = te[7], n33 = te[8], t11 = n33 * n22 - n32 * n23, t12 = n32 * n13 - n33 * n12, t13 = n23 * n12 - n22 * n13, det = n11 * t11 + n21 * t12 + n31 * t13;
        if (det === 0) return this.set(0, 0, 0, 0, 0, 0, 0, 0, 0);
        const detInv = 1 / det;
        te[0] = t11 * detInv;
        te[1] = (n31 * n23 - n33 * n21) * detInv;
        te[2] = (n32 * n21 - n31 * n22) * detInv;
        te[3] = t12 * detInv;
        te[4] = (n33 * n11 - n31 * n13) * detInv;
        te[5] = (n31 * n12 - n32 * n11) * detInv;
        te[6] = t13 * detInv;
        te[7] = (n21 * n13 - n23 * n11) * detInv;
        te[8] = (n22 * n11 - n21 * n12) * detInv;
        return this;
      }
      transpose() {
        let tmp;
        const m = this.elements;
        tmp = m[1];
        m[1] = m[3];
        m[3] = tmp;
        tmp = m[2];
        m[2] = m[6];
        m[6] = tmp;
        tmp = m[5];
        m[5] = m[7];
        m[7] = tmp;
        return this;
      }
      getNormalMatrix(matrix4) {
        return this.setFromMatrix4(matrix4).invert().transpose();
      }
      transposeIntoArray(r) {
        const m = this.elements;
        r[0] = m[0];
        r[1] = m[3];
        r[2] = m[6];
        r[3] = m[1];
        r[4] = m[4];
        r[5] = m[7];
        r[6] = m[2];
        r[7] = m[5];
        r[8] = m[8];
        return this;
      }
      setUvTransform(tx, ty, sx, sy, rotation, cx, cy) {
        const c = Math.cos(rotation);
        const s = Math.sin(rotation);
        this.set(
          sx * c,
          sx * s,
          -sx * (c * cx + s * cy) + cx + tx,
          -sy * s,
          sy * c,
          -sy * (-s * cx + c * cy) + cy + ty,
          0,
          0,
          1
        );
        return this;
      }
      //
      scale(sx, sy) {
        this.premultiply(_m3.makeScale(sx, sy));
        return this;
      }
      rotate(theta) {
        this.premultiply(_m3.makeRotation(-theta));
        return this;
      }
      translate(tx, ty) {
        this.premultiply(_m3.makeTranslation(tx, ty));
        return this;
      }
      // for 2D Transforms
      makeTranslation(x, y) {
        if (x.isVector2) {
          this.set(
            1,
            0,
            x.x,
            0,
            1,
            x.y,
            0,
            0,
            1
          );
        } else {
          this.set(
            1,
            0,
            x,
            0,
            1,
            y,
            0,
            0,
            1
          );
        }
        return this;
      }
      makeRotation(theta) {
        const c = Math.cos(theta);
        const s = Math.sin(theta);
        this.set(
          c,
          -s,
          0,
          s,
          c,
          0,
          0,
          0,
          1
        );
        return this;
      }
      makeScale(x, y) {
        this.set(
          x,
          0,
          0,
          0,
          y,
          0,
          0,
          0,
          1
        );
        return this;
      }
      //
      equals(matrix) {
        const te = this.elements;
        const me = matrix.elements;
        for (let i = 0; i < 9; i++) {
          if (te[i] !== me[i]) return false;
        }
        return true;
      }
      fromArray(array, offset = 0) {
        for (let i = 0; i < 9; i++) {
          this.elements[i] = array[i + offset];
        }
        return this;
      }
      toArray(array = [], offset = 0) {
        const te = this.elements;
        array[offset] = te[0];
        array[offset + 1] = te[1];
        array[offset + 2] = te[2];
        array[offset + 3] = te[3];
        array[offset + 4] = te[4];
        array[offset + 5] = te[5];
        array[offset + 6] = te[6];
        array[offset + 7] = te[7];
        array[offset + 8] = te[8];
        return array;
      }
      clone() {
        return new this.constructor().fromArray(this.elements);
      }
    };
    _m3 = /* @__PURE__ */ new Matrix3();
    ColorManagement = {
      enabled: true,
      workingColorSpace: LinearSRGBColorSpace,
      /**
       * Implementations of supported color spaces.
       *
       * Required:
       *	- primaries: chromaticity coordinates [ rx ry gx gy bx by ]
       *	- whitePoint: reference white [ x y ]
       *	- transfer: transfer function (pre-defined)
       *	- toXYZ: Matrix3 RGB to XYZ transform
       *	- fromXYZ: Matrix3 XYZ to RGB transform
       *	- luminanceCoefficients: RGB luminance coefficients
       *
       * Optional:
       *  - outputColorSpaceConfig: { drawingBufferColorSpace: ColorSpace }
       *  - workingColorSpaceConfig: { unpackColorSpace: ColorSpace }
       *
       * Reference:
       * - https://www.russellcottrell.com/photo/matrixCalculator.htm
       */
      spaces: {},
      convert: function(color, sourceColorSpace, targetColorSpace) {
        if (this.enabled === false || sourceColorSpace === targetColorSpace || !sourceColorSpace || !targetColorSpace) {
          return color;
        }
        if (this.spaces[sourceColorSpace].transfer === SRGBTransfer) {
          color.r = SRGBToLinear(color.r);
          color.g = SRGBToLinear(color.g);
          color.b = SRGBToLinear(color.b);
        }
        if (this.spaces[sourceColorSpace].primaries !== this.spaces[targetColorSpace].primaries) {
          color.applyMatrix3(this.spaces[sourceColorSpace].toXYZ);
          color.applyMatrix3(this.spaces[targetColorSpace].fromXYZ);
        }
        if (this.spaces[targetColorSpace].transfer === SRGBTransfer) {
          color.r = LinearToSRGB(color.r);
          color.g = LinearToSRGB(color.g);
          color.b = LinearToSRGB(color.b);
        }
        return color;
      },
      fromWorkingColorSpace: function(color, targetColorSpace) {
        return this.convert(color, this.workingColorSpace, targetColorSpace);
      },
      toWorkingColorSpace: function(color, sourceColorSpace) {
        return this.convert(color, sourceColorSpace, this.workingColorSpace);
      },
      getPrimaries: function(colorSpace) {
        return this.spaces[colorSpace].primaries;
      },
      getTransfer: function(colorSpace) {
        if (colorSpace === NoColorSpace) return LinearTransfer;
        return this.spaces[colorSpace].transfer;
      },
      getLuminanceCoefficients: function(target, colorSpace = this.workingColorSpace) {
        return target.fromArray(this.spaces[colorSpace].luminanceCoefficients);
      },
      define: function(colorSpaces) {
        Object.assign(this.spaces, colorSpaces);
      },
      // Internal APIs
      _getMatrix: function(targetMatrix, sourceColorSpace, targetColorSpace) {
        return targetMatrix.copy(this.spaces[sourceColorSpace].toXYZ).multiply(this.spaces[targetColorSpace].fromXYZ);
      },
      _getDrawingBufferColorSpace: function(colorSpace) {
        return this.spaces[colorSpace].outputColorSpaceConfig.drawingBufferColorSpace;
      },
      _getUnpackColorSpace: function(colorSpace = this.workingColorSpace) {
        return this.spaces[colorSpace].workingColorSpaceConfig.unpackColorSpace;
      }
    };
    REC709_PRIMARIES = [0.64, 0.33, 0.3, 0.6, 0.15, 0.06];
    REC709_LUMINANCE_COEFFICIENTS = [0.2126, 0.7152, 0.0722];
    D65 = [0.3127, 0.329];
    LINEAR_REC709_TO_XYZ = /* @__PURE__ */ new Matrix3().set(
      0.4123908,
      0.3575843,
      0.1804808,
      0.212639,
      0.7151687,
      0.0721923,
      0.0193308,
      0.1191948,
      0.9505322
    );
    XYZ_TO_LINEAR_REC709 = /* @__PURE__ */ new Matrix3().set(
      3.2409699,
      -1.5373832,
      -0.4986108,
      -0.9692436,
      1.8759675,
      0.0415551,
      0.0556301,
      -0.203977,
      1.0569715
    );
    ColorManagement.define({
      [LinearSRGBColorSpace]: {
        primaries: REC709_PRIMARIES,
        whitePoint: D65,
        transfer: LinearTransfer,
        toXYZ: LINEAR_REC709_TO_XYZ,
        fromXYZ: XYZ_TO_LINEAR_REC709,
        luminanceCoefficients: REC709_LUMINANCE_COEFFICIENTS,
        workingColorSpaceConfig: { unpackColorSpace: SRGBColorSpace },
        outputColorSpaceConfig: { drawingBufferColorSpace: SRGBColorSpace }
      },
      [SRGBColorSpace]: {
        primaries: REC709_PRIMARIES,
        whitePoint: D65,
        transfer: SRGBTransfer,
        toXYZ: LINEAR_REC709_TO_XYZ,
        fromXYZ: XYZ_TO_LINEAR_REC709,
        luminanceCoefficients: REC709_LUMINANCE_COEFFICIENTS,
        outputColorSpaceConfig: { drawingBufferColorSpace: SRGBColorSpace }
      }
    });
    ImageUtils = class {
      static getDataURL(image) {
        if (/^data:/i.test(image.src)) {
          return image.src;
        }
        if (typeof HTMLCanvasElement === "undefined") {
          return image.src;
        }
        let canvas;
        if (image instanceof HTMLCanvasElement) {
          canvas = image;
        } else {
          if (_canvas === void 0) _canvas = createElementNS("canvas");
          _canvas.width = image.width;
          _canvas.height = image.height;
          const context = _canvas.getContext("2d");
          if (image instanceof ImageData) {
            context.putImageData(image, 0, 0);
          } else {
            context.drawImage(image, 0, 0, image.width, image.height);
          }
          canvas = _canvas;
        }
        if (canvas.width > 2048 || canvas.height > 2048) {
          console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons", image);
          return canvas.toDataURL("image/jpeg", 0.6);
        } else {
          return canvas.toDataURL("image/png");
        }
      }
      static sRGBToLinear(image) {
        if (typeof HTMLImageElement !== "undefined" && image instanceof HTMLImageElement || typeof HTMLCanvasElement !== "undefined" && image instanceof HTMLCanvasElement || typeof ImageBitmap !== "undefined" && image instanceof ImageBitmap) {
          const canvas = createElementNS("canvas");
          canvas.width = image.width;
          canvas.height = image.height;
          const context = canvas.getContext("2d");
          context.drawImage(image, 0, 0, image.width, image.height);
          const imageData = context.getImageData(0, 0, image.width, image.height);
          const data = imageData.data;
          for (let i = 0; i < data.length; i++) {
            data[i] = SRGBToLinear(data[i] / 255) * 255;
          }
          context.putImageData(imageData, 0, 0);
          return canvas;
        } else if (image.data) {
          const data = image.data.slice(0);
          for (let i = 0; i < data.length; i++) {
            if (data instanceof Uint8Array || data instanceof Uint8ClampedArray) {
              data[i] = Math.floor(SRGBToLinear(data[i] / 255) * 255);
            } else {
              data[i] = SRGBToLinear(data[i]);
            }
          }
          return {
            data,
            width: image.width,
            height: image.height
          };
        } else {
          console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied.");
          return image;
        }
      }
    };
    _sourceId = 0;
    Source = class {
      constructor(data = null) {
        this.isSource = true;
        Object.defineProperty(this, "id", { value: _sourceId++ });
        this.uuid = generateUUID();
        this.data = data;
        this.dataReady = true;
        this.version = 0;
      }
      set needsUpdate(value) {
        if (value === true) this.version++;
      }
      toJSON(meta) {
        const isRootObject = meta === void 0 || typeof meta === "string";
        if (!isRootObject && meta.images[this.uuid] !== void 0) {
          return meta.images[this.uuid];
        }
        const output = {
          uuid: this.uuid,
          url: ""
        };
        const data = this.data;
        if (data !== null) {
          let url;
          if (Array.isArray(data)) {
            url = [];
            for (let i = 0, l = data.length; i < l; i++) {
              if (data[i].isDataTexture) {
                url.push(serializeImage(data[i].image));
              } else {
                url.push(serializeImage(data[i]));
              }
            }
          } else {
            url = serializeImage(data);
          }
          output.url = url;
        }
        if (!isRootObject) {
          meta.images[this.uuid] = output;
        }
        return output;
      }
    };
    _textureId = 0;
    Texture = class _Texture extends EventDispatcher {
      constructor(image = _Texture.DEFAULT_IMAGE, mapping = _Texture.DEFAULT_MAPPING, wrapS = ClampToEdgeWrapping, wrapT = ClampToEdgeWrapping, magFilter = LinearFilter, minFilter = LinearMipmapLinearFilter, format = RGBAFormat, type = UnsignedByteType, anisotropy = _Texture.DEFAULT_ANISOTROPY, colorSpace = NoColorSpace) {
        super();
        this.isTexture = true;
        Object.defineProperty(this, "id", { value: _textureId++ });
        this.uuid = generateUUID();
        this.name = "";
        this.source = new Source(image);
        this.mipmaps = [];
        this.mapping = mapping;
        this.channel = 0;
        this.wrapS = wrapS;
        this.wrapT = wrapT;
        this.magFilter = magFilter;
        this.minFilter = minFilter;
        this.anisotropy = anisotropy;
        this.format = format;
        this.internalFormat = null;
        this.type = type;
        this.offset = new Vector2(0, 0);
        this.repeat = new Vector2(1, 1);
        this.center = new Vector2(0, 0);
        this.rotation = 0;
        this.matrixAutoUpdate = true;
        this.matrix = new Matrix3();
        this.generateMipmaps = true;
        this.premultiplyAlpha = false;
        this.flipY = true;
        this.unpackAlignment = 4;
        this.colorSpace = colorSpace;
        this.userData = {};
        this.version = 0;
        this.onUpdate = null;
        this.isRenderTargetTexture = false;
        this.pmremVersion = 0;
      }
      get image() {
        return this.source.data;
      }
      set image(value = null) {
        this.source.data = value;
      }
      updateMatrix() {
        this.matrix.setUvTransform(this.offset.x, this.offset.y, this.repeat.x, this.repeat.y, this.rotation, this.center.x, this.center.y);
      }
      clone() {
        return new this.constructor().copy(this);
      }
      copy(source) {
        this.name = source.name;
        this.source = source.source;
        this.mipmaps = source.mipmaps.slice(0);
        this.mapping = source.mapping;
        this.channel = source.channel;
        this.wrapS = source.wrapS;
        this.wrapT = source.wrapT;
        this.magFilter = source.magFilter;
        this.minFilter = source.minFilter;
        this.anisotropy = source.anisotropy;
        this.format = source.format;
        this.internalFormat = source.internalFormat;
        this.type = source.type;
        this.offset.copy(source.offset);
        this.repeat.copy(source.repeat);
        this.center.copy(source.center);
        this.rotation = source.rotation;
        this.matrixAutoUpdate = source.matrixAutoUpdate;
        this.matrix.copy(source.matrix);
        this.generateMipmaps = source.generateMipmaps;
        this.premultiplyAlpha = source.premultiplyAlpha;
        this.flipY = source.flipY;
        this.unpackAlignment = source.unpackAlignment;
        this.colorSpace = source.colorSpace;
        this.userData = JSON.parse(JSON.stringify(source.userData));
        this.needsUpdate = true;
        return this;
      }
      toJSON(meta) {
        const isRootObject = meta === void 0 || typeof meta === "string";
        if (!isRootObject && meta.textures[this.uuid] !== void 0) {
          return meta.textures[this.uuid];
        }
        const output = {
          metadata: {
            version: 4.6,
            type: "Texture",
            generator: "Texture.toJSON"
          },
          uuid: this.uuid,
          name: this.name,
          image: this.source.toJSON(meta).uuid,
          mapping: this.mapping,
          channel: this.channel,
          repeat: [this.repeat.x, this.repeat.y],
          offset: [this.offset.x, this.offset.y],
          center: [this.center.x, this.center.y],
          rotation: this.rotation,
          wrap: [this.wrapS, this.wrapT],
          format: this.format,
          internalFormat: this.internalFormat,
          type: this.type,
          colorSpace: this.colorSpace,
          minFilter: this.minFilter,
          magFilter: this.magFilter,
          anisotropy: this.anisotropy,
          flipY: this.flipY,
          generateMipmaps: this.generateMipmaps,
          premultiplyAlpha: this.premultiplyAlpha,
          unpackAlignment: this.unpackAlignment
        };
        if (Object.keys(this.userData).length > 0) output.userData = this.userData;
        if (!isRootObject) {
          meta.textures[this.uuid] = output;
        }
        return output;
      }
      dispose() {
        this.dispatchEvent({ type: "dispose" });
      }
      transformUv(uv) {
        if (this.mapping !== UVMapping) return uv;
        uv.applyMatrix3(this.matrix);
        if (uv.x < 0 || uv.x > 1) {
          switch (this.wrapS) {
            case RepeatWrapping:
              uv.x = uv.x - Math.floor(uv.x);
              break;
            case ClampToEdgeWrapping:
              uv.x = uv.x < 0 ? 0 : 1;
              break;
            case MirroredRepeatWrapping:
              if (Math.abs(Math.floor(uv.x) % 2) === 1) {
                uv.x = Math.ceil(uv.x) - uv.x;
              } else {
                uv.x = uv.x - Math.floor(uv.x);
              }
              break;
          }
        }
        if (uv.y < 0 || uv.y > 1) {
          switch (this.wrapT) {
            case RepeatWrapping:
              uv.y = uv.y - Math.floor(uv.y);
              break;
            case ClampToEdgeWrapping:
              uv.y = uv.y < 0 ? 0 : 1;
              break;
            case MirroredRepeatWrapping:
              if (Math.abs(Math.floor(uv.y) % 2) === 1) {
                uv.y = Math.ceil(uv.y) - uv.y;
              } else {
                uv.y = uv.y - Math.floor(uv.y);
              }
              break;
          }
        }
        if (this.flipY) {
          uv.y = 1 - uv.y;
        }
        return uv;
      }
      set needsUpdate(value) {
        if (value === true) {
          this.version++;
          this.source.needsUpdate = true;
        }
      }
      set needsPMREMUpdate(value) {
        if (value === true) {
          this.pmremVersion++;
        }
      }
    };
    Texture.DEFAULT_IMAGE = null;
    Texture.DEFAULT_MAPPING = UVMapping;
    Texture.DEFAULT_ANISOTROPY = 1;
    Vector4 = class _Vector4 {
      constructor(x = 0, y = 0, z = 0, w = 1) {
        _Vector4.prototype.isVector4 = true;
        this.x = x;
        this.y = y;
        this.z = z;
        this.w = w;
      }
      get width() {
        return this.z;
      }
      set width(value) {
        this.z = value;
      }
      get height() {
        return this.w;
      }
      set height(value) {
        this.w = value;
      }
      set(x, y, z, w) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.w = w;
        return this;
      }
      setScalar(scalar) {
        this.x = scalar;
        this.y = scalar;
        this.z = scalar;
        this.w = scalar;
        return this;
      }
      setX(x) {
        this.x = x;
        return this;
      }
      setY(y) {
        this.y = y;
        return this;
      }
      setZ(z) {
        this.z = z;
        return this;
      }
      setW(w) {
        this.w = w;
        return this;
      }
      setComponent(index, value) {
        switch (index) {
          case 0:
            this.x = value;
            break;
          case 1:
            this.y = value;
            break;
          case 2:
            this.z = value;
            break;
          case 3:
            this.w = value;
            break;
          default:
            throw new Error("index is out of range: " + index);
        }
        return this;
      }
      getComponent(index) {
        switch (index) {
          case 0:
            return this.x;
          case 1:
            return this.y;
          case 2:
            return this.z;
          case 3:
            return this.w;
          default:
            throw new Error("index is out of range: " + index);
        }
      }
      clone() {
        return new this.constructor(this.x, this.y, this.z, this.w);
      }
      copy(v) {
        this.x = v.x;
        this.y = v.y;
        this.z = v.z;
        this.w = v.w !== void 0 ? v.w : 1;
        return this;
      }
      add(v) {
        this.x += v.x;
        this.y += v.y;
        this.z += v.z;
        this.w += v.w;
        return this;
      }
      addScalar(s) {
        this.x += s;
        this.y += s;
        this.z += s;
        this.w += s;
        return this;
      }
      addVectors(a, b) {
        this.x = a.x + b.x;
        this.y = a.y + b.y;
        this.z = a.z + b.z;
        this.w = a.w + b.w;
        return this;
      }
      addScaledVector(v, s) {
        this.x += v.x * s;
        this.y += v.y * s;
        this.z += v.z * s;
        this.w += v.w * s;
        return this;
      }
      sub(v) {
        this.x -= v.x;
        this.y -= v.y;
        this.z -= v.z;
        this.w -= v.w;
        return this;
      }
      subScalar(s) {
        this.x -= s;
        this.y -= s;
        this.z -= s;
        this.w -= s;
        return this;
      }
      subVectors(a, b) {
        this.x = a.x - b.x;
        this.y = a.y - b.y;
        this.z = a.z - b.z;
        this.w = a.w - b.w;
        return this;
      }
      multiply(v) {
        this.x *= v.x;
        this.y *= v.y;
        this.z *= v.z;
        this.w *= v.w;
        return this;
      }
      multiplyScalar(scalar) {
        this.x *= scalar;
        this.y *= scalar;
        this.z *= scalar;
        this.w *= scalar;
        return this;
      }
      applyMatrix4(m) {
        const x = this.x, y = this.y, z = this.z, w = this.w;
        const e = m.elements;
        this.x = e[0] * x + e[4] * y + e[8] * z + e[12] * w;
        this.y = e[1] * x + e[5] * y + e[9] * z + e[13] * w;
        this.z = e[2] * x + e[6] * y + e[10] * z + e[14] * w;
        this.w = e[3] * x + e[7] * y + e[11] * z + e[15] * w;
        return this;
      }
      divide(v) {
        this.x /= v.x;
        this.y /= v.y;
        this.z /= v.z;
        this.w /= v.w;
        return this;
      }
      divideScalar(scalar) {
        return this.multiplyScalar(1 / scalar);
      }
      setAxisAngleFromQuaternion(q) {
        this.w = 2 * Math.acos(q.w);
        const s = Math.sqrt(1 - q.w * q.w);
        if (s < 1e-4) {
          this.x = 1;
          this.y = 0;
          this.z = 0;
        } else {
          this.x = q.x / s;
          this.y = q.y / s;
          this.z = q.z / s;
        }
        return this;
      }
      setAxisAngleFromRotationMatrix(m) {
        let angle, x, y, z;
        const epsilon = 0.01, epsilon2 = 0.1, te = m.elements, m11 = te[0], m12 = te[4], m13 = te[8], m21 = te[1], m22 = te[5], m23 = te[9], m31 = te[2], m32 = te[6], m33 = te[10];
        if (Math.abs(m12 - m21) < epsilon && Math.abs(m13 - m31) < epsilon && Math.abs(m23 - m32) < epsilon) {
          if (Math.abs(m12 + m21) < epsilon2 && Math.abs(m13 + m31) < epsilon2 && Math.abs(m23 + m32) < epsilon2 && Math.abs(m11 + m22 + m33 - 3) < epsilon2) {
            this.set(1, 0, 0, 0);
            return this;
          }
          angle = Math.PI;
          const xx = (m11 + 1) / 2;
          const yy = (m22 + 1) / 2;
          const zz = (m33 + 1) / 2;
          const xy = (m12 + m21) / 4;
          const xz = (m13 + m31) / 4;
          const yz = (m23 + m32) / 4;
          if (xx > yy && xx > zz) {
            if (xx < epsilon) {
              x = 0;
              y = 0.707106781;
              z = 0.707106781;
            } else {
              x = Math.sqrt(xx);
              y = xy / x;
              z = xz / x;
            }
          } else if (yy > zz) {
            if (yy < epsilon) {
              x = 0.707106781;
              y = 0;
              z = 0.707106781;
            } else {
              y = Math.sqrt(yy);
              x = xy / y;
              z = yz / y;
            }
          } else {
            if (zz < epsilon) {
              x = 0.707106781;
              y = 0.707106781;
              z = 0;
            } else {
              z = Math.sqrt(zz);
              x = xz / z;
              y = yz / z;
            }
          }
          this.set(x, y, z, angle);
          return this;
        }
        let s = Math.sqrt((m32 - m23) * (m32 - m23) + (m13 - m31) * (m13 - m31) + (m21 - m12) * (m21 - m12));
        if (Math.abs(s) < 1e-3) s = 1;
        this.x = (m32 - m23) / s;
        this.y = (m13 - m31) / s;
        this.z = (m21 - m12) / s;
        this.w = Math.acos((m11 + m22 + m33 - 1) / 2);
        return this;
      }
      setFromMatrixPosition(m) {
        const e = m.elements;
        this.x = e[12];
        this.y = e[13];
        this.z = e[14];
        this.w = e[15];
        return this;
      }
      min(v) {
        this.x = Math.min(this.x, v.x);
        this.y = Math.min(this.y, v.y);
        this.z = Math.min(this.z, v.z);
        this.w = Math.min(this.w, v.w);
        return this;
      }
      max(v) {
        this.x = Math.max(this.x, v.x);
        this.y = Math.max(this.y, v.y);
        this.z = Math.max(this.z, v.z);
        this.w = Math.max(this.w, v.w);
        return this;
      }
      clamp(min, max) {
        this.x = Math.max(min.x, Math.min(max.x, this.x));
        this.y = Math.max(min.y, Math.min(max.y, this.y));
        this.z = Math.max(min.z, Math.min(max.z, this.z));
        this.w = Math.max(min.w, Math.min(max.w, this.w));
        return this;
      }
      clampScalar(minVal, maxVal) {
        this.x = Math.max(minVal, Math.min(maxVal, this.x));
        this.y = Math.max(minVal, Math.min(maxVal, this.y));
        this.z = Math.max(minVal, Math.min(maxVal, this.z));
        this.w = Math.max(minVal, Math.min(maxVal, this.w));
        return this;
      }
      clampLength(min, max) {
        const length = this.length();
        return this.divideScalar(length || 1).multiplyScalar(Math.max(min, Math.min(max, length)));
      }
      floor() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        this.z = Math.floor(this.z);
        this.w = Math.floor(this.w);
        return this;
      }
      ceil() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        this.z = Math.ceil(this.z);
        this.w = Math.ceil(this.w);
        return this;
      }
      round() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        this.z = Math.round(this.z);
        this.w = Math.round(this.w);
        return this;
      }
      roundToZero() {
        this.x = Math.trunc(this.x);
        this.y = Math.trunc(this.y);
        this.z = Math.trunc(this.z);
        this.w = Math.trunc(this.w);
        return this;
      }
      negate() {
        this.x = -this.x;
        this.y = -this.y;
        this.z = -this.z;
        this.w = -this.w;
        return this;
      }
      dot(v) {
        return this.x * v.x + this.y * v.y + this.z * v.z + this.w * v.w;
      }
      lengthSq() {
        return this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w;
      }
      length() {
        return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w);
      }
      manhattanLength() {
        return Math.abs(this.x) + Math.abs(this.y) + Math.abs(this.z) + Math.abs(this.w);
      }
      normalize() {
        return this.divideScalar(this.length() || 1);
      }
      setLength(length) {
        return this.normalize().multiplyScalar(length);
      }
      lerp(v, alpha) {
        this.x += (v.x - this.x) * alpha;
        this.y += (v.y - this.y) * alpha;
        this.z += (v.z - this.z) * alpha;
        this.w += (v.w - this.w) * alpha;
        return this;
      }
      lerpVectors(v1, v2, alpha) {
        this.x = v1.x + (v2.x - v1.x) * alpha;
        this.y = v1.y + (v2.y - v1.y) * alpha;
        this.z = v1.z + (v2.z - v1.z) * alpha;
        this.w = v1.w + (v2.w - v1.w) * alpha;
        return this;
      }
      equals(v) {
        return v.x === this.x && v.y === this.y && v.z === this.z && v.w === this.w;
      }
      fromArray(array, offset = 0) {
        this.x = array[offset];
        this.y = array[offset + 1];
        this.z = array[offset + 2];
        this.w = array[offset + 3];
        return this;
      }
      toArray(array = [], offset = 0) {
        array[offset] = this.x;
        array[offset + 1] = this.y;
        array[offset + 2] = this.z;
        array[offset + 3] = this.w;
        return array;
      }
      fromBufferAttribute(attribute, index) {
        this.x = attribute.getX(index);
        this.y = attribute.getY(index);
        this.z = attribute.getZ(index);
        this.w = attribute.getW(index);
        return this;
      }
      random() {
        this.x = Math.random();
        this.y = Math.random();
        this.z = Math.random();
        this.w = Math.random();
        return this;
      }
      *[Symbol.iterator]() {
        yield this.x;
        yield this.y;
        yield this.z;
        yield this.w;
      }
    };
    Quaternion = class {
      constructor(x = 0, y = 0, z = 0, w = 1) {
        this.isQuaternion = true;
        this._x = x;
        this._y = y;
        this._z = z;
        this._w = w;
      }
      static slerpFlat(dst, dstOffset, src0, srcOffset0, src1, srcOffset1, t) {
        let x0 = src0[srcOffset0 + 0], y0 = src0[srcOffset0 + 1], z0 = src0[srcOffset0 + 2], w0 = src0[srcOffset0 + 3];
        const x1 = src1[srcOffset1 + 0], y1 = src1[srcOffset1 + 1], z1 = src1[srcOffset1 + 2], w1 = src1[srcOffset1 + 3];
        if (t === 0) {
          dst[dstOffset + 0] = x0;
          dst[dstOffset + 1] = y0;
          dst[dstOffset + 2] = z0;
          dst[dstOffset + 3] = w0;
          return;
        }
        if (t === 1) {
          dst[dstOffset + 0] = x1;
          dst[dstOffset + 1] = y1;
          dst[dstOffset + 2] = z1;
          dst[dstOffset + 3] = w1;
          return;
        }
        if (w0 !== w1 || x0 !== x1 || y0 !== y1 || z0 !== z1) {
          let s = 1 - t;
          const cos = x0 * x1 + y0 * y1 + z0 * z1 + w0 * w1, dir = cos >= 0 ? 1 : -1, sqrSin = 1 - cos * cos;
          if (sqrSin > Number.EPSILON) {
            const sin = Math.sqrt(sqrSin), len = Math.atan2(sin, cos * dir);
            s = Math.sin(s * len) / sin;
            t = Math.sin(t * len) / sin;
          }
          const tDir = t * dir;
          x0 = x0 * s + x1 * tDir;
          y0 = y0 * s + y1 * tDir;
          z0 = z0 * s + z1 * tDir;
          w0 = w0 * s + w1 * tDir;
          if (s === 1 - t) {
            const f = 1 / Math.sqrt(x0 * x0 + y0 * y0 + z0 * z0 + w0 * w0);
            x0 *= f;
            y0 *= f;
            z0 *= f;
            w0 *= f;
          }
        }
        dst[dstOffset] = x0;
        dst[dstOffset + 1] = y0;
        dst[dstOffset + 2] = z0;
        dst[dstOffset + 3] = w0;
      }
      static multiplyQuaternionsFlat(dst, dstOffset, src0, srcOffset0, src1, srcOffset1) {
        const x0 = src0[srcOffset0];
        const y0 = src0[srcOffset0 + 1];
        const z0 = src0[srcOffset0 + 2];
        const w0 = src0[srcOffset0 + 3];
        const x1 = src1[srcOffset1];
        const y1 = src1[srcOffset1 + 1];
        const z1 = src1[srcOffset1 + 2];
        const w1 = src1[srcOffset1 + 3];
        dst[dstOffset] = x0 * w1 + w0 * x1 + y0 * z1 - z0 * y1;
        dst[dstOffset + 1] = y0 * w1 + w0 * y1 + z0 * x1 - x0 * z1;
        dst[dstOffset + 2] = z0 * w1 + w0 * z1 + x0 * y1 - y0 * x1;
        dst[dstOffset + 3] = w0 * w1 - x0 * x1 - y0 * y1 - z0 * z1;
        return dst;
      }
      get x() {
        return this._x;
      }
      set x(value) {
        this._x = value;
        this._onChangeCallback();
      }
      get y() {
        return this._y;
      }
      set y(value) {
        this._y = value;
        this._onChangeCallback();
      }
      get z() {
        return this._z;
      }
      set z(value) {
        this._z = value;
        this._onChangeCallback();
      }
      get w() {
        return this._w;
      }
      set w(value) {
        this._w = value;
        this._onChangeCallback();
      }
      set(x, y, z, w) {
        this._x = x;
        this._y = y;
        this._z = z;
        this._w = w;
        this._onChangeCallback();
        return this;
      }
      clone() {
        return new this.constructor(this._x, this._y, this._z, this._w);
      }
      copy(quaternion) {
        this._x = quaternion.x;
        this._y = quaternion.y;
        this._z = quaternion.z;
        this._w = quaternion.w;
        this._onChangeCallback();
        return this;
      }
      setFromEuler(euler, update = true) {
        const x = euler._x, y = euler._y, z = euler._z, order = euler._order;
        const cos = Math.cos;
        const sin = Math.sin;
        const c1 = cos(x / 2);
        const c2 = cos(y / 2);
        const c3 = cos(z / 2);
        const s1 = sin(x / 2);
        const s2 = sin(y / 2);
        const s3 = sin(z / 2);
        switch (order) {
          case "XYZ":
            this._x = s1 * c2 * c3 + c1 * s2 * s3;
            this._y = c1 * s2 * c3 - s1 * c2 * s3;
            this._z = c1 * c2 * s3 + s1 * s2 * c3;
            this._w = c1 * c2 * c3 - s1 * s2 * s3;
            break;
          case "YXZ":
            this._x = s1 * c2 * c3 + c1 * s2 * s3;
            this._y = c1 * s2 * c3 - s1 * c2 * s3;
            this._z = c1 * c2 * s3 - s1 * s2 * c3;
            this._w = c1 * c2 * c3 + s1 * s2 * s3;
            break;
          case "ZXY":
            this._x = s1 * c2 * c3 - c1 * s2 * s3;
            this._y = c1 * s2 * c3 + s1 * c2 * s3;
            this._z = c1 * c2 * s3 + s1 * s2 * c3;
            this._w = c1 * c2 * c3 - s1 * s2 * s3;
            break;
          case "ZYX":
            this._x = s1 * c2 * c3 - c1 * s2 * s3;
            this._y = c1 * s2 * c3 + s1 * c2 * s3;
            this._z = c1 * c2 * s3 - s1 * s2 * c3;
            this._w = c1 * c2 * c3 + s1 * s2 * s3;
            break;
          case "YZX":
            this._x = s1 * c2 * c3 + c1 * s2 * s3;
            this._y = c1 * s2 * c3 + s1 * c2 * s3;
            this._z = c1 * c2 * s3 - s1 * s2 * c3;
            this._w = c1 * c2 * c3 - s1 * s2 * s3;
            break;
          case "XZY":
            this._x = s1 * c2 * c3 - c1 * s2 * s3;
            this._y = c1 * s2 * c3 - s1 * c2 * s3;
            this._z = c1 * c2 * s3 + s1 * s2 * c3;
            this._w = c1 * c2 * c3 + s1 * s2 * s3;
            break;
          default:
            console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: " + order);
        }
        if (update === true) this._onChangeCallback();
        return this;
      }
      setFromAxisAngle(axis, angle) {
        const halfAngle = angle / 2, s = Math.sin(halfAngle);
        this._x = axis.x * s;
        this._y = axis.y * s;
        this._z = axis.z * s;
        this._w = Math.cos(halfAngle);
        this._onChangeCallback();
        return this;
      }
      setFromRotationMatrix(m) {
        const te = m.elements, m11 = te[0], m12 = te[4], m13 = te[8], m21 = te[1], m22 = te[5], m23 = te[9], m31 = te[2], m32 = te[6], m33 = te[10], trace = m11 + m22 + m33;
        if (trace > 0) {
          const s = 0.5 / Math.sqrt(trace + 1);
          this._w = 0.25 / s;
          this._x = (m32 - m23) * s;
          this._y = (m13 - m31) * s;
          this._z = (m21 - m12) * s;
        } else if (m11 > m22 && m11 > m33) {
          const s = 2 * Math.sqrt(1 + m11 - m22 - m33);
          this._w = (m32 - m23) / s;
          this._x = 0.25 * s;
          this._y = (m12 + m21) / s;
          this._z = (m13 + m31) / s;
        } else if (m22 > m33) {
          const s = 2 * Math.sqrt(1 + m22 - m11 - m33);
          this._w = (m13 - m31) / s;
          this._x = (m12 + m21) / s;
          this._y = 0.25 * s;
          this._z = (m23 + m32) / s;
        } else {
          const s = 2 * Math.sqrt(1 + m33 - m11 - m22);
          this._w = (m21 - m12) / s;
          this._x = (m13 + m31) / s;
          this._y = (m23 + m32) / s;
          this._z = 0.25 * s;
        }
        this._onChangeCallback();
        return this;
      }
      setFromUnitVectors(vFrom, vTo) {
        let r = vFrom.dot(vTo) + 1;
        if (r < Number.EPSILON) {
          r = 0;
          if (Math.abs(vFrom.x) > Math.abs(vFrom.z)) {
            this._x = -vFrom.y;
            this._y = vFrom.x;
            this._z = 0;
            this._w = r;
          } else {
            this._x = 0;
            this._y = -vFrom.z;
            this._z = vFrom.y;
            this._w = r;
          }
        } else {
          this._x = vFrom.y * vTo.z - vFrom.z * vTo.y;
          this._y = vFrom.z * vTo.x - vFrom.x * vTo.z;
          this._z = vFrom.x * vTo.y - vFrom.y * vTo.x;
          this._w = r;
        }
        return this.normalize();
      }
      angleTo(q) {
        return 2 * Math.acos(Math.abs(clamp(this.dot(q), -1, 1)));
      }
      rotateTowards(q, step) {
        const angle = this.angleTo(q);
        if (angle === 0) return this;
        const t = Math.min(1, step / angle);
        this.slerp(q, t);
        return this;
      }
      identity() {
        return this.set(0, 0, 0, 1);
      }
      invert() {
        return this.conjugate();
      }
      conjugate() {
        this._x *= -1;
        this._y *= -1;
        this._z *= -1;
        this._onChangeCallback();
        return this;
      }
      dot(v) {
        return this._x * v._x + this._y * v._y + this._z * v._z + this._w * v._w;
      }
      lengthSq() {
        return this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w;
      }
      length() {
        return Math.sqrt(this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w);
      }
      normalize() {
        let l = this.length();
        if (l === 0) {
          this._x = 0;
          this._y = 0;
          this._z = 0;
          this._w = 1;
        } else {
          l = 1 / l;
          this._x = this._x * l;
          this._y = this._y * l;
          this._z = this._z * l;
          this._w = this._w * l;
        }
        this._onChangeCallback();
        return this;
      }
      multiply(q) {
        return this.multiplyQuaternions(this, q);
      }
      premultiply(q) {
        return this.multiplyQuaternions(q, this);
      }
      multiplyQuaternions(a, b) {
        const qax = a._x, qay = a._y, qaz = a._z, qaw = a._w;
        const qbx = b._x, qby = b._y, qbz = b._z, qbw = b._w;
        this._x = qax * qbw + qaw * qbx + qay * qbz - qaz * qby;
        this._y = qay * qbw + qaw * qby + qaz * qbx - qax * qbz;
        this._z = qaz * qbw + qaw * qbz + qax * qby - qay * qbx;
        this._w = qaw * qbw - qax * qbx - qay * qby - qaz * qbz;
        this._onChangeCallback();
        return this;
      }
      slerp(qb, t) {
        if (t === 0) return this;
        if (t === 1) return this.copy(qb);
        const x = this._x, y = this._y, z = this._z, w = this._w;
        let cosHalfTheta = w * qb._w + x * qb._x + y * qb._y + z * qb._z;
        if (cosHalfTheta < 0) {
          this._w = -qb._w;
          this._x = -qb._x;
          this._y = -qb._y;
          this._z = -qb._z;
          cosHalfTheta = -cosHalfTheta;
        } else {
          this.copy(qb);
        }
        if (cosHalfTheta >= 1) {
          this._w = w;
          this._x = x;
          this._y = y;
          this._z = z;
          return this;
        }
        const sqrSinHalfTheta = 1 - cosHalfTheta * cosHalfTheta;
        if (sqrSinHalfTheta <= Number.EPSILON) {
          const s = 1 - t;
          this._w = s * w + t * this._w;
          this._x = s * x + t * this._x;
          this._y = s * y + t * this._y;
          this._z = s * z + t * this._z;
          this.normalize();
          return this;
        }
        const sinHalfTheta = Math.sqrt(sqrSinHalfTheta);
        const halfTheta = Math.atan2(sinHalfTheta, cosHalfTheta);
        const ratioA = Math.sin((1 - t) * halfTheta) / sinHalfTheta, ratioB = Math.sin(t * halfTheta) / sinHalfTheta;
        this._w = w * ratioA + this._w * ratioB;
        this._x = x * ratioA + this._x * ratioB;
        this._y = y * ratioA + this._y * ratioB;
        this._z = z * ratioA + this._z * ratioB;
        this._onChangeCallback();
        return this;
      }
      slerpQuaternions(qa, qb, t) {
        return this.copy(qa).slerp(qb, t);
      }
      random() {
        const theta1 = 2 * Math.PI * Math.random();
        const theta2 = 2 * Math.PI * Math.random();
        const x0 = Math.random();
        const r1 = Math.sqrt(1 - x0);
        const r2 = Math.sqrt(x0);
        return this.set(
          r1 * Math.sin(theta1),
          r1 * Math.cos(theta1),
          r2 * Math.sin(theta2),
          r2 * Math.cos(theta2)
        );
      }
      equals(quaternion) {
        return quaternion._x === this._x && quaternion._y === this._y && quaternion._z === this._z && quaternion._w === this._w;
      }
      fromArray(array, offset = 0) {
        this._x = array[offset];
        this._y = array[offset + 1];
        this._z = array[offset + 2];
        this._w = array[offset + 3];
        this._onChangeCallback();
        return this;
      }
      toArray(array = [], offset = 0) {
        array[offset] = this._x;
        array[offset + 1] = this._y;
        array[offset + 2] = this._z;
        array[offset + 3] = this._w;
        return array;
      }
      fromBufferAttribute(attribute, index) {
        this._x = attribute.getX(index);
        this._y = attribute.getY(index);
        this._z = attribute.getZ(index);
        this._w = attribute.getW(index);
        this._onChangeCallback();
        return this;
      }
      toJSON() {
        return this.toArray();
      }
      _onChange(callback) {
        this._onChangeCallback = callback;
        return this;
      }
      _onChangeCallback() {
      }
      *[Symbol.iterator]() {
        yield this._x;
        yield this._y;
        yield this._z;
        yield this._w;
      }
    };
    Vector3 = class _Vector3 {
      constructor(x = 0, y = 0, z = 0) {
        _Vector3.prototype.isVector3 = true;
        this.x = x;
        this.y = y;
        this.z = z;
      }
      set(x, y, z) {
        if (z === void 0) z = this.z;
        this.x = x;
        this.y = y;
        this.z = z;
        return this;
      }
      setScalar(scalar) {
        this.x = scalar;
        this.y = scalar;
        this.z = scalar;
        return this;
      }
      setX(x) {
        this.x = x;
        return this;
      }
      setY(y) {
        this.y = y;
        return this;
      }
      setZ(z) {
        this.z = z;
        return this;
      }
      setComponent(index, value) {
        switch (index) {
          case 0:
            this.x = value;
            break;
          case 1:
            this.y = value;
            break;
          case 2:
            this.z = value;
            break;
          default:
            throw new Error("index is out of range: " + index);
        }
        return this;
      }
      getComponent(index) {
        switch (index) {
          case 0:
            return this.x;
          case 1:
            return this.y;
          case 2:
            return this.z;
          default:
            throw new Error("index is out of range: " + index);
        }
      }
      clone() {
        return new this.constructor(this.x, this.y, this.z);
      }
      copy(v) {
        this.x = v.x;
        this.y = v.y;
        this.z = v.z;
        return this;
      }
      add(v) {
        this.x += v.x;
        this.y += v.y;
        this.z += v.z;
        return this;
      }
      addScalar(s) {
        this.x += s;
        this.y += s;
        this.z += s;
        return this;
      }
      addVectors(a, b) {
        this.x = a.x + b.x;
        this.y = a.y + b.y;
        this.z = a.z + b.z;
        return this;
      }
      addScaledVector(v, s) {
        this.x += v.x * s;
        this.y += v.y * s;
        this.z += v.z * s;
        return this;
      }
      sub(v) {
        this.x -= v.x;
        this.y -= v.y;
        this.z -= v.z;
        return this;
      }
      subScalar(s) {
        this.x -= s;
        this.y -= s;
        this.z -= s;
        return this;
      }
      subVectors(a, b) {
        this.x = a.x - b.x;
        this.y = a.y - b.y;
        this.z = a.z - b.z;
        return this;
      }
      multiply(v) {
        this.x *= v.x;
        this.y *= v.y;
        this.z *= v.z;
        return this;
      }
      multiplyScalar(scalar) {
        this.x *= scalar;
        this.y *= scalar;
        this.z *= scalar;
        return this;
      }
      multiplyVectors(a, b) {
        this.x = a.x * b.x;
        this.y = a.y * b.y;
        this.z = a.z * b.z;
        return this;
      }
      applyEuler(euler) {
        return this.applyQuaternion(_quaternion$4.setFromEuler(euler));
      }
      applyAxisAngle(axis, angle) {
        return this.applyQuaternion(_quaternion$4.setFromAxisAngle(axis, angle));
      }
      applyMatrix3(m) {
        const x = this.x, y = this.y, z = this.z;
        const e = m.elements;
        this.x = e[0] * x + e[3] * y + e[6] * z;
        this.y = e[1] * x + e[4] * y + e[7] * z;
        this.z = e[2] * x + e[5] * y + e[8] * z;
        return this;
      }
      applyNormalMatrix(m) {
        return this.applyMatrix3(m).normalize();
      }
      applyMatrix4(m) {
        const x = this.x, y = this.y, z = this.z;
        const e = m.elements;
        const w = 1 / (e[3] * x + e[7] * y + e[11] * z + e[15]);
        this.x = (e[0] * x + e[4] * y + e[8] * z + e[12]) * w;
        this.y = (e[1] * x + e[5] * y + e[9] * z + e[13]) * w;
        this.z = (e[2] * x + e[6] * y + e[10] * z + e[14]) * w;
        return this;
      }
      applyQuaternion(q) {
        const vx = this.x, vy = this.y, vz = this.z;
        const qx = q.x, qy = q.y, qz = q.z, qw = q.w;
        const tx = 2 * (qy * vz - qz * vy);
        const ty = 2 * (qz * vx - qx * vz);
        const tz = 2 * (qx * vy - qy * vx);
        this.x = vx + qw * tx + qy * tz - qz * ty;
        this.y = vy + qw * ty + qz * tx - qx * tz;
        this.z = vz + qw * tz + qx * ty - qy * tx;
        return this;
      }
      project(camera) {
        return this.applyMatrix4(camera.matrixWorldInverse).applyMatrix4(camera.projectionMatrix);
      }
      unproject(camera) {
        return this.applyMatrix4(camera.projectionMatrixInverse).applyMatrix4(camera.matrixWorld);
      }
      transformDirection(m) {
        const x = this.x, y = this.y, z = this.z;
        const e = m.elements;
        this.x = e[0] * x + e[4] * y + e[8] * z;
        this.y = e[1] * x + e[5] * y + e[9] * z;
        this.z = e[2] * x + e[6] * y + e[10] * z;
        return this.normalize();
      }
      divide(v) {
        this.x /= v.x;
        this.y /= v.y;
        this.z /= v.z;
        return this;
      }
      divideScalar(scalar) {
        return this.multiplyScalar(1 / scalar);
      }
      min(v) {
        this.x = Math.min(this.x, v.x);
        this.y = Math.min(this.y, v.y);
        this.z = Math.min(this.z, v.z);
        return this;
      }
      max(v) {
        this.x = Math.max(this.x, v.x);
        this.y = Math.max(this.y, v.y);
        this.z = Math.max(this.z, v.z);
        return this;
      }
      clamp(min, max) {
        this.x = Math.max(min.x, Math.min(max.x, this.x));
        this.y = Math.max(min.y, Math.min(max.y, this.y));
        this.z = Math.max(min.z, Math.min(max.z, this.z));
        return this;
      }
      clampScalar(minVal, maxVal) {
        this.x = Math.max(minVal, Math.min(maxVal, this.x));
        this.y = Math.max(minVal, Math.min(maxVal, this.y));
        this.z = Math.max(minVal, Math.min(maxVal, this.z));
        return this;
      }
      clampLength(min, max) {
        const length = this.length();
        return this.divideScalar(length || 1).multiplyScalar(Math.max(min, Math.min(max, length)));
      }
      floor() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        this.z = Math.floor(this.z);
        return this;
      }
      ceil() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        this.z = Math.ceil(this.z);
        return this;
      }
      round() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        this.z = Math.round(this.z);
        return this;
      }
      roundToZero() {
        this.x = Math.trunc(this.x);
        this.y = Math.trunc(this.y);
        this.z = Math.trunc(this.z);
        return this;
      }
      negate() {
        this.x = -this.x;
        this.y = -this.y;
        this.z = -this.z;
        return this;
      }
      dot(v) {
        return this.x * v.x + this.y * v.y + this.z * v.z;
      }
      // TODO lengthSquared?
      lengthSq() {
        return this.x * this.x + this.y * this.y + this.z * this.z;
      }
      length() {
        return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
      }
      manhattanLength() {
        return Math.abs(this.x) + Math.abs(this.y) + Math.abs(this.z);
      }
      normalize() {
        return this.divideScalar(this.length() || 1);
      }
      setLength(length) {
        return this.normalize().multiplyScalar(length);
      }
      lerp(v, alpha) {
        this.x += (v.x - this.x) * alpha;
        this.y += (v.y - this.y) * alpha;
        this.z += (v.z - this.z) * alpha;
        return this;
      }
      lerpVectors(v1, v2, alpha) {
        this.x = v1.x + (v2.x - v1.x) * alpha;
        this.y = v1.y + (v2.y - v1.y) * alpha;
        this.z = v1.z + (v2.z - v1.z) * alpha;
        return this;
      }
      cross(v) {
        return this.crossVectors(this, v);
      }
      crossVectors(a, b) {
        const ax = a.x, ay = a.y, az = a.z;
        const bx = b.x, by = b.y, bz = b.z;
        this.x = ay * bz - az * by;
        this.y = az * bx - ax * bz;
        this.z = ax * by - ay * bx;
        return this;
      }
      projectOnVector(v) {
        const denominator = v.lengthSq();
        if (denominator === 0) return this.set(0, 0, 0);
        const scalar = v.dot(this) / denominator;
        return this.copy(v).multiplyScalar(scalar);
      }
      projectOnPlane(planeNormal) {
        _vector$c.copy(this).projectOnVector(planeNormal);
        return this.sub(_vector$c);
      }
      reflect(normal) {
        return this.sub(_vector$c.copy(normal).multiplyScalar(2 * this.dot(normal)));
      }
      angleTo(v) {
        const denominator = Math.sqrt(this.lengthSq() * v.lengthSq());
        if (denominator === 0) return Math.PI / 2;
        const theta = this.dot(v) / denominator;
        return Math.acos(clamp(theta, -1, 1));
      }
      distanceTo(v) {
        return Math.sqrt(this.distanceToSquared(v));
      }
      distanceToSquared(v) {
        const dx = this.x - v.x, dy = this.y - v.y, dz = this.z - v.z;
        return dx * dx + dy * dy + dz * dz;
      }
      manhattanDistanceTo(v) {
        return Math.abs(this.x - v.x) + Math.abs(this.y - v.y) + Math.abs(this.z - v.z);
      }
      setFromSpherical(s) {
        return this.setFromSphericalCoords(s.radius, s.phi, s.theta);
      }
      setFromSphericalCoords(radius, phi, theta) {
        const sinPhiRadius = Math.sin(phi) * radius;
        this.x = sinPhiRadius * Math.sin(theta);
        this.y = Math.cos(phi) * radius;
        this.z = sinPhiRadius * Math.cos(theta);
        return this;
      }
      setFromCylindrical(c) {
        return this.setFromCylindricalCoords(c.radius, c.theta, c.y);
      }
      setFromCylindricalCoords(radius, theta, y) {
        this.x = radius * Math.sin(theta);
        this.y = y;
        this.z = radius * Math.cos(theta);
        return this;
      }
      setFromMatrixPosition(m) {
        const e = m.elements;
        this.x = e[12];
        this.y = e[13];
        this.z = e[14];
        return this;
      }
      setFromMatrixScale(m) {
        const sx = this.setFromMatrixColumn(m, 0).length();
        const sy = this.setFromMatrixColumn(m, 1).length();
        const sz = this.setFromMatrixColumn(m, 2).length();
        this.x = sx;
        this.y = sy;
        this.z = sz;
        return this;
      }
      setFromMatrixColumn(m, index) {
        return this.fromArray(m.elements, index * 4);
      }
      setFromMatrix3Column(m, index) {
        return this.fromArray(m.elements, index * 3);
      }
      setFromEuler(e) {
        this.x = e._x;
        this.y = e._y;
        this.z = e._z;
        return this;
      }
      setFromColor(c) {
        this.x = c.r;
        this.y = c.g;
        this.z = c.b;
        return this;
      }
      equals(v) {
        return v.x === this.x && v.y === this.y && v.z === this.z;
      }
      fromArray(array, offset = 0) {
        this.x = array[offset];
        this.y = array[offset + 1];
        this.z = array[offset + 2];
        return this;
      }
      toArray(array = [], offset = 0) {
        array[offset] = this.x;
        array[offset + 1] = this.y;
        array[offset + 2] = this.z;
        return array;
      }
      fromBufferAttribute(attribute, index) {
        this.x = attribute.getX(index);
        this.y = attribute.getY(index);
        this.z = attribute.getZ(index);
        return this;
      }
      random() {
        this.x = Math.random();
        this.y = Math.random();
        this.z = Math.random();
        return this;
      }
      randomDirection() {
        const theta = Math.random() * Math.PI * 2;
        const u = Math.random() * 2 - 1;
        const c = Math.sqrt(1 - u * u);
        this.x = c * Math.cos(theta);
        this.y = u;
        this.z = c * Math.sin(theta);
        return this;
      }
      *[Symbol.iterator]() {
        yield this.x;
        yield this.y;
        yield this.z;
      }
    };
    _vector$c = /* @__PURE__ */ new Vector3();
    _quaternion$4 = /* @__PURE__ */ new Quaternion();
    Box3 = class {
      constructor(min = new Vector3(Infinity, Infinity, Infinity), max = new Vector3(-Infinity, -Infinity, -Infinity)) {
        this.isBox3 = true;
        this.min = min;
        this.max = max;
      }
      set(min, max) {
        this.min.copy(min);
        this.max.copy(max);
        return this;
      }
      setFromArray(array) {
        this.makeEmpty();
        for (let i = 0, il = array.length; i < il; i += 3) {
          this.expandByPoint(_vector$b.fromArray(array, i));
        }
        return this;
      }
      setFromBufferAttribute(attribute) {
        this.makeEmpty();
        for (let i = 0, il = attribute.count; i < il; i++) {
          this.expandByPoint(_vector$b.fromBufferAttribute(attribute, i));
        }
        return this;
      }
      setFromPoints(points) {
        this.makeEmpty();
        for (let i = 0, il = points.length; i < il; i++) {
          this.expandByPoint(points[i]);
        }
        return this;
      }
      setFromCenterAndSize(center, size) {
        const halfSize = _vector$b.copy(size).multiplyScalar(0.5);
        this.min.copy(center).sub(halfSize);
        this.max.copy(center).add(halfSize);
        return this;
      }
      setFromObject(object, precise = false) {
        this.makeEmpty();
        return this.expandByObject(object, precise);
      }
      clone() {
        return new this.constructor().copy(this);
      }
      copy(box2) {
        this.min.copy(box2.min);
        this.max.copy(box2.max);
        return this;
      }
      makeEmpty() {
        this.min.x = this.min.y = this.min.z = Infinity;
        this.max.x = this.max.y = this.max.z = -Infinity;
        return this;
      }
      isEmpty() {
        return this.max.x < this.min.x || this.max.y < this.min.y || this.max.z < this.min.z;
      }
      getCenter(target) {
        return this.isEmpty() ? target.set(0, 0, 0) : target.addVectors(this.min, this.max).multiplyScalar(0.5);
      }
      getSize(target) {
        return this.isEmpty() ? target.set(0, 0, 0) : target.subVectors(this.max, this.min);
      }
      expandByPoint(point) {
        this.min.min(point);
        this.max.max(point);
        return this;
      }
      expandByVector(vector) {
        this.min.sub(vector);
        this.max.add(vector);
        return this;
      }
      expandByScalar(scalar) {
        this.min.addScalar(-scalar);
        this.max.addScalar(scalar);
        return this;
      }
      expandByObject(object, precise = false) {
        object.updateWorldMatrix(false, false);
        const geometry = object.geometry;
        if (geometry !== void 0) {
          const positionAttribute = geometry.getAttribute("position");
          if (precise === true && positionAttribute !== void 0 && object.isInstancedMesh !== true) {
            for (let i = 0, l = positionAttribute.count; i < l; i++) {
              if (object.isMesh === true) {
                object.getVertexPosition(i, _vector$b);
              } else {
                _vector$b.fromBufferAttribute(positionAttribute, i);
              }
              _vector$b.applyMatrix4(object.matrixWorld);
              this.expandByPoint(_vector$b);
            }
          } else {
            if (object.boundingBox !== void 0) {
              if (object.boundingBox === null) {
                object.computeBoundingBox();
              }
              _box$4.copy(object.boundingBox);
            } else {
              if (geometry.boundingBox === null) {
                geometry.computeBoundingBox();
              }
              _box$4.copy(geometry.boundingBox);
            }
            _box$4.applyMatrix4(object.matrixWorld);
            this.union(_box$4);
          }
        }
        const children = object.children;
        for (let i = 0, l = children.length; i < l; i++) {
          this.expandByObject(children[i], precise);
        }
        return this;
      }
      containsPoint(point) {
        return point.x >= this.min.x && point.x <= this.max.x && point.y >= this.min.y && point.y <= this.max.y && point.z >= this.min.z && point.z <= this.max.z;
      }
      containsBox(box2) {
        return this.min.x <= box2.min.x && box2.max.x <= this.max.x && this.min.y <= box2.min.y && box2.max.y <= this.max.y && this.min.z <= box2.min.z && box2.max.z <= this.max.z;
      }
      getParameter(point, target) {
        return target.set(
          (point.x - this.min.x) / (this.max.x - this.min.x),
          (point.y - this.min.y) / (this.max.y - this.min.y),
          (point.z - this.min.z) / (this.max.z - this.min.z)
        );
      }
      intersectsBox(box2) {
        return box2.max.x >= this.min.x && box2.min.x <= this.max.x && box2.max.y >= this.min.y && box2.min.y <= this.max.y && box2.max.z >= this.min.z && box2.min.z <= this.max.z;
      }
      intersectsSphere(sphere) {
        this.clampPoint(sphere.center, _vector$b);
        return _vector$b.distanceToSquared(sphere.center) <= sphere.radius * sphere.radius;
      }
      intersectsPlane(plane) {
        let min, max;
        if (plane.normal.x > 0) {
          min = plane.normal.x * this.min.x;
          max = plane.normal.x * this.max.x;
        } else {
          min = plane.normal.x * this.max.x;
          max = plane.normal.x * this.min.x;
        }
        if (plane.normal.y > 0) {
          min += plane.normal.y * this.min.y;
          max += plane.normal.y * this.max.y;
        } else {
          min += plane.normal.y * this.max.y;
          max += plane.normal.y * this.min.y;
        }
        if (plane.normal.z > 0) {
          min += plane.normal.z * this.min.z;
          max += plane.normal.z * this.max.z;
        } else {
          min += plane.normal.z * this.max.z;
          max += plane.normal.z * this.min.z;
        }
        return min <= -plane.constant && max >= -plane.constant;
      }
      intersectsTriangle(triangle) {
        if (this.isEmpty()) {
          return false;
        }
        this.getCenter(_center);
        _extents.subVectors(this.max, _center);
        _v0$3.subVectors(triangle.a, _center);
        _v1$7.subVectors(triangle.b, _center);
        _v2$4.subVectors(triangle.c, _center);
        _f0.subVectors(_v1$7, _v0$3);
        _f1.subVectors(_v2$4, _v1$7);
        _f2.subVectors(_v0$3, _v2$4);
        let axes = [
          0,
          -_f0.z,
          _f0.y,
          0,
          -_f1.z,
          _f1.y,
          0,
          -_f2.z,
          _f2.y,
          _f0.z,
          0,
          -_f0.x,
          _f1.z,
          0,
          -_f1.x,
          _f2.z,
          0,
          -_f2.x,
          -_f0.y,
          _f0.x,
          0,
          -_f1.y,
          _f1.x,
          0,
          -_f2.y,
          _f2.x,
          0
        ];
        if (!satForAxes(axes, _v0$3, _v1$7, _v2$4, _extents)) {
          return false;
        }
        axes = [1, 0, 0, 0, 1, 0, 0, 0, 1];
        if (!satForAxes(axes, _v0$3, _v1$7, _v2$4, _extents)) {
          return false;
        }
        _triangleNormal.crossVectors(_f0, _f1);
        axes = [_triangleNormal.x, _triangleNormal.y, _triangleNormal.z];
        return satForAxes(axes, _v0$3, _v1$7, _v2$4, _extents);
      }
      clampPoint(point, target) {
        return target.copy(point).clamp(this.min, this.max);
      }
      distanceToPoint(point) {
        return this.clampPoint(point, _vector$b).distanceTo(point);
      }
      getBoundingSphere(target) {
        if (this.isEmpty()) {
          target.makeEmpty();
        } else {
          this.getCenter(target.center);
          target.radius = this.getSize(_vector$b).length() * 0.5;
        }
        return target;
      }
      intersect(box2) {
        this.min.max(box2.min);
        this.max.min(box2.max);
        if (this.isEmpty()) this.makeEmpty();
        return this;
      }
      union(box2) {
        this.min.min(box2.min);
        this.max.max(box2.max);
        return this;
      }
      applyMatrix4(matrix) {
        if (this.isEmpty()) return this;
        _points[0].set(this.min.x, this.min.y, this.min.z).applyMatrix4(matrix);
        _points[1].set(this.min.x, this.min.y, this.max.z).applyMatrix4(matrix);
        _points[2].set(this.min.x, this.max.y, this.min.z).applyMatrix4(matrix);
        _points[3].set(this.min.x, this.max.y, this.max.z).applyMatrix4(matrix);
        _points[4].set(this.max.x, this.min.y, this.min.z).applyMatrix4(matrix);
        _points[5].set(this.max.x, this.min.y, this.max.z).applyMatrix4(matrix);
        _points[6].set(this.max.x, this.max.y, this.min.z).applyMatrix4(matrix);
        _points[7].set(this.max.x, this.max.y, this.max.z).applyMatrix4(matrix);
        this.setFromPoints(_points);
        return this;
      }
      translate(offset) {
        this.min.add(offset);
        this.max.add(offset);
        return this;
      }
      equals(box2) {
        return box2.min.equals(this.min) && box2.max.equals(this.max);
      }
    };
    _points = [
      /* @__PURE__ */ new Vector3(),
      /* @__PURE__ */ new Vector3(),
      /* @__PURE__ */ new Vector3(),
      /* @__PURE__ */ new Vector3(),
      /* @__PURE__ */ new Vector3(),
      /* @__PURE__ */ new Vector3(),
      /* @__PURE__ */ new Vector3(),
      /* @__PURE__ */ new Vector3()
    ];
    _vector$b = /* @__PURE__ */ new Vector3();
    _box$4 = /* @__PURE__ */ new Box3();
    _v0$3 = /* @__PURE__ */ new Vector3();
    _v1$7 = /* @__PURE__ */ new Vector3();
    _v2$4 = /* @__PURE__ */ new Vector3();
    _f0 = /* @__PURE__ */ new Vector3();
    _f1 = /* @__PURE__ */ new Vector3();
    _f2 = /* @__PURE__ */ new Vector3();
    _center = /* @__PURE__ */ new Vector3();
    _extents = /* @__PURE__ */ new Vector3();
    _triangleNormal = /* @__PURE__ */ new Vector3();
    _testAxis = /* @__PURE__ */ new Vector3();
    _box$3 = /* @__PURE__ */ new Box3();
    _v1$6 = /* @__PURE__ */ new Vector3();
    _v2$3 = /* @__PURE__ */ new Vector3();
    Sphere = class {
      constructor(center = new Vector3(), radius = -1) {
        this.isSphere = true;
        this.center = center;
        this.radius = radius;
      }
      set(center, radius) {
        this.center.copy(center);
        this.radius = radius;
        return this;
      }
      setFromPoints(points, optionalCenter) {
        const center = this.center;
        if (optionalCenter !== void 0) {
          center.copy(optionalCenter);
        } else {
          _box$3.setFromPoints(points).getCenter(center);
        }
        let maxRadiusSq = 0;
        for (let i = 0, il = points.length; i < il; i++) {
          maxRadiusSq = Math.max(maxRadiusSq, center.distanceToSquared(points[i]));
        }
        this.radius = Math.sqrt(maxRadiusSq);
        return this;
      }
      copy(sphere) {
        this.center.copy(sphere.center);
        this.radius = sphere.radius;
        return this;
      }
      isEmpty() {
        return this.radius < 0;
      }
      makeEmpty() {
        this.center.set(0, 0, 0);
        this.radius = -1;
        return this;
      }
      containsPoint(point) {
        return point.distanceToSquared(this.center) <= this.radius * this.radius;
      }
      distanceToPoint(point) {
        return point.distanceTo(this.center) - this.radius;
      }
      intersectsSphere(sphere) {
        const radiusSum = this.radius + sphere.radius;
        return sphere.center.distanceToSquared(this.center) <= radiusSum * radiusSum;
      }
      intersectsBox(box2) {
        return box2.intersectsSphere(this);
      }
      intersectsPlane(plane) {
        return Math.abs(plane.distanceToPoint(this.center)) <= this.radius;
      }
      clampPoint(point, target) {
        const deltaLengthSq = this.center.distanceToSquared(point);
        target.copy(point);
        if (deltaLengthSq > this.radius * this.radius) {
          target.sub(this.center).normalize();
          target.multiplyScalar(this.radius).add(this.center);
        }
        return target;
      }
      getBoundingBox(target) {
        if (this.isEmpty()) {
          target.makeEmpty();
          return target;
        }
        target.set(this.center, this.center);
        target.expandByScalar(this.radius);
        return target;
      }
      applyMatrix4(matrix) {
        this.center.applyMatrix4(matrix);
        this.radius = this.radius * matrix.getMaxScaleOnAxis();
        return this;
      }
      translate(offset) {
        this.center.add(offset);
        return this;
      }
      expandByPoint(point) {
        if (this.isEmpty()) {
          this.center.copy(point);
          this.radius = 0;
          return this;
        }
        _v1$6.subVectors(point, this.center);
        const lengthSq = _v1$6.lengthSq();
        if (lengthSq > this.radius * this.radius) {
          const length = Math.sqrt(lengthSq);
          const delta = (length - this.radius) * 0.5;
          this.center.addScaledVector(_v1$6, delta / length);
          this.radius += delta;
        }
        return this;
      }
      union(sphere) {
        if (sphere.isEmpty()) {
          return this;
        }
        if (this.isEmpty()) {
          this.copy(sphere);
          return this;
        }
        if (this.center.equals(sphere.center) === true) {
          this.radius = Math.max(this.radius, sphere.radius);
        } else {
          _v2$3.subVectors(sphere.center, this.center).setLength(sphere.radius);
          this.expandByPoint(_v1$6.copy(sphere.center).add(_v2$3));
          this.expandByPoint(_v1$6.copy(sphere.center).sub(_v2$3));
        }
        return this;
      }
      equals(sphere) {
        return sphere.center.equals(this.center) && sphere.radius === this.radius;
      }
      clone() {
        return new this.constructor().copy(this);
      }
    };
    _vector$a = /* @__PURE__ */ new Vector3();
    _segCenter = /* @__PURE__ */ new Vector3();
    _segDir = /* @__PURE__ */ new Vector3();
    _diff = /* @__PURE__ */ new Vector3();
    _edge1 = /* @__PURE__ */ new Vector3();
    _edge2 = /* @__PURE__ */ new Vector3();
    _normal$1 = /* @__PURE__ */ new Vector3();
    Ray = class {
      constructor(origin = new Vector3(), direction = new Vector3(0, 0, -1)) {
        this.origin = origin;
        this.direction = direction;
      }
      set(origin, direction) {
        this.origin.copy(origin);
        this.direction.copy(direction);
        return this;
      }
      copy(ray) {
        this.origin.copy(ray.origin);
        this.direction.copy(ray.direction);
        return this;
      }
      at(t, target) {
        return target.copy(this.origin).addScaledVector(this.direction, t);
      }
      lookAt(v) {
        this.direction.copy(v).sub(this.origin).normalize();
        return this;
      }
      recast(t) {
        this.origin.copy(this.at(t, _vector$a));
        return this;
      }
      closestPointToPoint(point, target) {
        target.subVectors(point, this.origin);
        const directionDistance = target.dot(this.direction);
        if (directionDistance < 0) {
          return target.copy(this.origin);
        }
        return target.copy(this.origin).addScaledVector(this.direction, directionDistance);
      }
      distanceToPoint(point) {
        return Math.sqrt(this.distanceSqToPoint(point));
      }
      distanceSqToPoint(point) {
        const directionDistance = _vector$a.subVectors(point, this.origin).dot(this.direction);
        if (directionDistance < 0) {
          return this.origin.distanceToSquared(point);
        }
        _vector$a.copy(this.origin).addScaledVector(this.direction, directionDistance);
        return _vector$a.distanceToSquared(point);
      }
      distanceSqToSegment(v0, v1, optionalPointOnRay, optionalPointOnSegment) {
        _segCenter.copy(v0).add(v1).multiplyScalar(0.5);
        _segDir.copy(v1).sub(v0).normalize();
        _diff.copy(this.origin).sub(_segCenter);
        const segExtent = v0.distanceTo(v1) * 0.5;
        const a01 = -this.direction.dot(_segDir);
        const b0 = _diff.dot(this.direction);
        const b1 = -_diff.dot(_segDir);
        const c = _diff.lengthSq();
        const det = Math.abs(1 - a01 * a01);
        let s0, s1, sqrDist, extDet;
        if (det > 0) {
          s0 = a01 * b1 - b0;
          s1 = a01 * b0 - b1;
          extDet = segExtent * det;
          if (s0 >= 0) {
            if (s1 >= -extDet) {
              if (s1 <= extDet) {
                const invDet = 1 / det;
                s0 *= invDet;
                s1 *= invDet;
                sqrDist = s0 * (s0 + a01 * s1 + 2 * b0) + s1 * (a01 * s0 + s1 + 2 * b1) + c;
              } else {
                s1 = segExtent;
                s0 = Math.max(0, -(a01 * s1 + b0));
                sqrDist = -s0 * s0 + s1 * (s1 + 2 * b1) + c;
              }
            } else {
              s1 = -segExtent;
              s0 = Math.max(0, -(a01 * s1 + b0));
              sqrDist = -s0 * s0 + s1 * (s1 + 2 * b1) + c;
            }
          } else {
            if (s1 <= -extDet) {
              s0 = Math.max(0, -(-a01 * segExtent + b0));
              s1 = s0 > 0 ? -segExtent : Math.min(Math.max(-segExtent, -b1), segExtent);
              sqrDist = -s0 * s0 + s1 * (s1 + 2 * b1) + c;
            } else if (s1 <= extDet) {
              s0 = 0;
              s1 = Math.min(Math.max(-segExtent, -b1), segExtent);
              sqrDist = s1 * (s1 + 2 * b1) + c;
            } else {
              s0 = Math.max(0, -(a01 * segExtent + b0));
              s1 = s0 > 0 ? segExtent : Math.min(Math.max(-segExtent, -b1), segExtent);
              sqrDist = -s0 * s0 + s1 * (s1 + 2 * b1) + c;
            }
          }
        } else {
          s1 = a01 > 0 ? -segExtent : segExtent;
          s0 = Math.max(0, -(a01 * s1 + b0));
          sqrDist = -s0 * s0 + s1 * (s1 + 2 * b1) + c;
        }
        if (optionalPointOnRay) {
          optionalPointOnRay.copy(this.origin).addScaledVector(this.direction, s0);
        }
        if (optionalPointOnSegment) {
          optionalPointOnSegment.copy(_segCenter).addScaledVector(_segDir, s1);
        }
        return sqrDist;
      }
      intersectSphere(sphere, target) {
        _vector$a.subVectors(sphere.center, this.origin);
        const tca = _vector$a.dot(this.direction);
        const d2 = _vector$a.dot(_vector$a) - tca * tca;
        const radius2 = sphere.radius * sphere.radius;
        if (d2 > radius2) return null;
        const thc = Math.sqrt(radius2 - d2);
        const t0 = tca - thc;
        const t1 = tca + thc;
        if (t1 < 0) return null;
        if (t0 < 0) return this.at(t1, target);
        return this.at(t0, target);
      }
      intersectsSphere(sphere) {
        return this.distanceSqToPoint(sphere.center) <= sphere.radius * sphere.radius;
      }
      distanceToPlane(plane) {
        const denominator = plane.normal.dot(this.direction);
        if (denominator === 0) {
          if (plane.distanceToPoint(this.origin) === 0) {
            return 0;
          }
          return null;
        }
        const t = -(this.origin.dot(plane.normal) + plane.constant) / denominator;
        return t >= 0 ? t : null;
      }
      intersectPlane(plane, target) {
        const t = this.distanceToPlane(plane);
        if (t === null) {
          return null;
        }
        return this.at(t, target);
      }
      intersectsPlane(plane) {
        const distToPoint = plane.distanceToPoint(this.origin);
        if (distToPoint === 0) {
          return true;
        }
        const denominator = plane.normal.dot(this.direction);
        if (denominator * distToPoint < 0) {
          return true;
        }
        return false;
      }
      intersectBox(box2, target) {
        let tmin, tmax, tymin, tymax, tzmin, tzmax;
        const invdirx = 1 / this.direction.x, invdiry = 1 / this.direction.y, invdirz = 1 / this.direction.z;
        const origin = this.origin;
        if (invdirx >= 0) {
          tmin = (box2.min.x - origin.x) * invdirx;
          tmax = (box2.max.x - origin.x) * invdirx;
        } else {
          tmin = (box2.max.x - origin.x) * invdirx;
          tmax = (box2.min.x - origin.x) * invdirx;
        }
        if (invdiry >= 0) {
          tymin = (box2.min.y - origin.y) * invdiry;
          tymax = (box2.max.y - origin.y) * invdiry;
        } else {
          tymin = (box2.max.y - origin.y) * invdiry;
          tymax = (box2.min.y - origin.y) * invdiry;
        }
        if (tmin > tymax || tymin > tmax) return null;
        if (tymin > tmin || isNaN(tmin)) tmin = tymin;
        if (tymax < tmax || isNaN(tmax)) tmax = tymax;
        if (invdirz >= 0) {
          tzmin = (box2.min.z - origin.z) * invdirz;
          tzmax = (box2.max.z - origin.z) * invdirz;
        } else {
          tzmin = (box2.max.z - origin.z) * invdirz;
          tzmax = (box2.min.z - origin.z) * invdirz;
        }
        if (tmin > tzmax || tzmin > tmax) return null;
        if (tzmin > tmin || tmin !== tmin) tmin = tzmin;
        if (tzmax < tmax || tmax !== tmax) tmax = tzmax;
        if (tmax < 0) return null;
        return this.at(tmin >= 0 ? tmin : tmax, target);
      }
      intersectsBox(box2) {
        return this.intersectBox(box2, _vector$a) !== null;
      }
      intersectTriangle(a, b, c, backfaceCulling, target) {
        _edge1.subVectors(b, a);
        _edge2.subVectors(c, a);
        _normal$1.crossVectors(_edge1, _edge2);
        let DdN = this.direction.dot(_normal$1);
        let sign;
        if (DdN > 0) {
          if (backfaceCulling) return null;
          sign = 1;
        } else if (DdN < 0) {
          sign = -1;
          DdN = -DdN;
        } else {
          return null;
        }
        _diff.subVectors(this.origin, a);
        const DdQxE2 = sign * this.direction.dot(_edge2.crossVectors(_diff, _edge2));
        if (DdQxE2 < 0) {
          return null;
        }
        const DdE1xQ = sign * this.direction.dot(_edge1.cross(_diff));
        if (DdE1xQ < 0) {
          return null;
        }
        if (DdQxE2 + DdE1xQ > DdN) {
          return null;
        }
        const QdN = -sign * _diff.dot(_normal$1);
        if (QdN < 0) {
          return null;
        }
        return this.at(QdN / DdN, target);
      }
      applyMatrix4(matrix4) {
        this.origin.applyMatrix4(matrix4);
        this.direction.transformDirection(matrix4);
        return this;
      }
      equals(ray) {
        return ray.origin.equals(this.origin) && ray.direction.equals(this.direction);
      }
      clone() {
        return new this.constructor().copy(this);
      }
    };
    Matrix4 = class _Matrix4 {
      constructor(n11, n12, n13, n14, n21, n22, n23, n24, n31, n32, n33, n34, n41, n42, n43, n44) {
        _Matrix4.prototype.isMatrix4 = true;
        this.elements = [
          1,
          0,
          0,
          0,
          0,
          1,
          0,
          0,
          0,
          0,
          1,
          0,
          0,
          0,
          0,
          1
        ];
        if (n11 !== void 0) {
          this.set(n11, n12, n13, n14, n21, n22, n23, n24, n31, n32, n33, n34, n41, n42, n43, n44);
        }
      }
      set(n11, n12, n13, n14, n21, n22, n23, n24, n31, n32, n33, n34, n41, n42, n43, n44) {
        const te = this.elements;
        te[0] = n11;
        te[4] = n12;
        te[8] = n13;
        te[12] = n14;
        te[1] = n21;
        te[5] = n22;
        te[9] = n23;
        te[13] = n24;
        te[2] = n31;
        te[6] = n32;
        te[10] = n33;
        te[14] = n34;
        te[3] = n41;
        te[7] = n42;
        te[11] = n43;
        te[15] = n44;
        return this;
      }
      identity() {
        this.set(
          1,
          0,
          0,
          0,
          0,
          1,
          0,
          0,
          0,
          0,
          1,
          0,
          0,
          0,
          0,
          1
        );
        return this;
      }
      clone() {
        return new _Matrix4().fromArray(this.elements);
      }
      copy(m) {
        const te = this.elements;
        const me = m.elements;
        te[0] = me[0];
        te[1] = me[1];
        te[2] = me[2];
        te[3] = me[3];
        te[4] = me[4];
        te[5] = me[5];
        te[6] = me[6];
        te[7] = me[7];
        te[8] = me[8];
        te[9] = me[9];
        te[10] = me[10];
        te[11] = me[11];
        te[12] = me[12];
        te[13] = me[13];
        te[14] = me[14];
        te[15] = me[15];
        return this;
      }
      copyPosition(m) {
        const te = this.elements, me = m.elements;
        te[12] = me[12];
        te[13] = me[13];
        te[14] = me[14];
        return this;
      }
      setFromMatrix3(m) {
        const me = m.elements;
        this.set(
          me[0],
          me[3],
          me[6],
          0,
          me[1],
          me[4],
          me[7],
          0,
          me[2],
          me[5],
          me[8],
          0,
          0,
          0,
          0,
          1
        );
        return this;
      }
      extractBasis(xAxis, yAxis, zAxis) {
        xAxis.setFromMatrixColumn(this, 0);
        yAxis.setFromMatrixColumn(this, 1);
        zAxis.setFromMatrixColumn(this, 2);
        return this;
      }
      makeBasis(xAxis, yAxis, zAxis) {
        this.set(
          xAxis.x,
          yAxis.x,
          zAxis.x,
          0,
          xAxis.y,
          yAxis.y,
          zAxis.y,
          0,
          xAxis.z,
          yAxis.z,
          zAxis.z,
          0,
          0,
          0,
          0,
          1
        );
        return this;
      }
      extractRotation(m) {
        const te = this.elements;
        const me = m.elements;
        const scaleX = 1 / _v1$5.setFromMatrixColumn(m, 0).length();
        const scaleY = 1 / _v1$5.setFromMatrixColumn(m, 1).length();
        const scaleZ = 1 / _v1$5.setFromMatrixColumn(m, 2).length();
        te[0] = me[0] * scaleX;
        te[1] = me[1] * scaleX;
        te[2] = me[2] * scaleX;
        te[3] = 0;
        te[4] = me[4] * scaleY;
        te[5] = me[5] * scaleY;
        te[6] = me[6] * scaleY;
        te[7] = 0;
        te[8] = me[8] * scaleZ;
        te[9] = me[9] * scaleZ;
        te[10] = me[10] * scaleZ;
        te[11] = 0;
        te[12] = 0;
        te[13] = 0;
        te[14] = 0;
        te[15] = 1;
        return this;
      }
      makeRotationFromEuler(euler) {
        const te = this.elements;
        const x = euler.x, y = euler.y, z = euler.z;
        const a = Math.cos(x), b = Math.sin(x);
        const c = Math.cos(y), d = Math.sin(y);
        const e = Math.cos(z), f = Math.sin(z);
        if (euler.order === "XYZ") {
          const ae = a * e, af = a * f, be = b * e, bf = b * f;
          te[0] = c * e;
          te[4] = -c * f;
          te[8] = d;
          te[1] = af + be * d;
          te[5] = ae - bf * d;
          te[9] = -b * c;
          te[2] = bf - ae * d;
          te[6] = be + af * d;
          te[10] = a * c;
        } else if (euler.order === "YXZ") {
          const ce = c * e, cf = c * f, de = d * e, df = d * f;
          te[0] = ce + df * b;
          te[4] = de * b - cf;
          te[8] = a * d;
          te[1] = a * f;
          te[5] = a * e;
          te[9] = -b;
          te[2] = cf * b - de;
          te[6] = df + ce * b;
          te[10] = a * c;
        } else if (euler.order === "ZXY") {
          const ce = c * e, cf = c * f, de = d * e, df = d * f;
          te[0] = ce - df * b;
          te[4] = -a * f;
          te[8] = de + cf * b;
          te[1] = cf + de * b;
          te[5] = a * e;
          te[9] = df - ce * b;
          te[2] = -a * d;
          te[6] = b;
          te[10] = a * c;
        } else if (euler.order === "ZYX") {
          const ae = a * e, af = a * f, be = b * e, bf = b * f;
          te[0] = c * e;
          te[4] = be * d - af;
          te[8] = ae * d + bf;
          te[1] = c * f;
          te[5] = bf * d + ae;
          te[9] = af * d - be;
          te[2] = -d;
          te[6] = b * c;
          te[10] = a * c;
        } else if (euler.order === "YZX") {
          const ac = a * c, ad = a * d, bc = b * c, bd = b * d;
          te[0] = c * e;
          te[4] = bd - ac * f;
          te[8] = bc * f + ad;
          te[1] = f;
          te[5] = a * e;
          te[9] = -b * e;
          te[2] = -d * e;
          te[6] = ad * f + bc;
          te[10] = ac - bd * f;
        } else if (euler.order === "XZY") {
          const ac = a * c, ad = a * d, bc = b * c, bd = b * d;
          te[0] = c * e;
          te[4] = -f;
          te[8] = d * e;
          te[1] = ac * f + bd;
          te[5] = a * e;
          te[9] = ad * f - bc;
          te[2] = bc * f - ad;
          te[6] = b * e;
          te[10] = bd * f + ac;
        }
        te[3] = 0;
        te[7] = 0;
        te[11] = 0;
        te[12] = 0;
        te[13] = 0;
        te[14] = 0;
        te[15] = 1;
        return this;
      }
      makeRotationFromQuaternion(q) {
        return this.compose(_zero, q, _one);
      }
      lookAt(eye, target, up) {
        const te = this.elements;
        _z.subVectors(eye, target);
        if (_z.lengthSq() === 0) {
          _z.z = 1;
        }
        _z.normalize();
        _x.crossVectors(up, _z);
        if (_x.lengthSq() === 0) {
          if (Math.abs(up.z) === 1) {
            _z.x += 1e-4;
          } else {
            _z.z += 1e-4;
          }
          _z.normalize();
          _x.crossVectors(up, _z);
        }
        _x.normalize();
        _y.crossVectors(_z, _x);
        te[0] = _x.x;
        te[4] = _y.x;
        te[8] = _z.x;
        te[1] = _x.y;
        te[5] = _y.y;
        te[9] = _z.y;
        te[2] = _x.z;
        te[6] = _y.z;
        te[10] = _z.z;
        return this;
      }
      multiply(m) {
        return this.multiplyMatrices(this, m);
      }
      premultiply(m) {
        return this.multiplyMatrices(m, this);
      }
      multiplyMatrices(a, b) {
        const ae = a.elements;
        const be = b.elements;
        const te = this.elements;
        const a11 = ae[0], a12 = ae[4], a13 = ae[8], a14 = ae[12];
        const a21 = ae[1], a22 = ae[5], a23 = ae[9], a24 = ae[13];
        const a31 = ae[2], a32 = ae[6], a33 = ae[10], a34 = ae[14];
        const a41 = ae[3], a42 = ae[7], a43 = ae[11], a44 = ae[15];
        const b11 = be[0], b12 = be[4], b13 = be[8], b14 = be[12];
        const b21 = be[1], b22 = be[5], b23 = be[9], b24 = be[13];
        const b31 = be[2], b32 = be[6], b33 = be[10], b34 = be[14];
        const b41 = be[3], b42 = be[7], b43 = be[11], b44 = be[15];
        te[0] = a11 * b11 + a12 * b21 + a13 * b31 + a14 * b41;
        te[4] = a11 * b12 + a12 * b22 + a13 * b32 + a14 * b42;
        te[8] = a11 * b13 + a12 * b23 + a13 * b33 + a14 * b43;
        te[12] = a11 * b14 + a12 * b24 + a13 * b34 + a14 * b44;
        te[1] = a21 * b11 + a22 * b21 + a23 * b31 + a24 * b41;
        te[5] = a21 * b12 + a22 * b22 + a23 * b32 + a24 * b42;
        te[9] = a21 * b13 + a22 * b23 + a23 * b33 + a24 * b43;
        te[13] = a21 * b14 + a22 * b24 + a23 * b34 + a24 * b44;
        te[2] = a31 * b11 + a32 * b21 + a33 * b31 + a34 * b41;
        te[6] = a31 * b12 + a32 * b22 + a33 * b32 + a34 * b42;
        te[10] = a31 * b13 + a32 * b23 + a33 * b33 + a34 * b43;
        te[14] = a31 * b14 + a32 * b24 + a33 * b34 + a34 * b44;
        te[3] = a41 * b11 + a42 * b21 + a43 * b31 + a44 * b41;
        te[7] = a41 * b12 + a42 * b22 + a43 * b32 + a44 * b42;
        te[11] = a41 * b13 + a42 * b23 + a43 * b33 + a44 * b43;
        te[15] = a41 * b14 + a42 * b24 + a43 * b34 + a44 * b44;
        return this;
      }
      multiplyScalar(s) {
        const te = this.elements;
        te[0] *= s;
        te[4] *= s;
        te[8] *= s;
        te[12] *= s;
        te[1] *= s;
        te[5] *= s;
        te[9] *= s;
        te[13] *= s;
        te[2] *= s;
        te[6] *= s;
        te[10] *= s;
        te[14] *= s;
        te[3] *= s;
        te[7] *= s;
        te[11] *= s;
        te[15] *= s;
        return this;
      }
      determinant() {
        const te = this.elements;
        const n11 = te[0], n12 = te[4], n13 = te[8], n14 = te[12];
        const n21 = te[1], n22 = te[5], n23 = te[9], n24 = te[13];
        const n31 = te[2], n32 = te[6], n33 = te[10], n34 = te[14];
        const n41 = te[3], n42 = te[7], n43 = te[11], n44 = te[15];
        return n41 * (+n14 * n23 * n32 - n13 * n24 * n32 - n14 * n22 * n33 + n12 * n24 * n33 + n13 * n22 * n34 - n12 * n23 * n34) + n42 * (+n11 * n23 * n34 - n11 * n24 * n33 + n14 * n21 * n33 - n13 * n21 * n34 + n13 * n24 * n31 - n14 * n23 * n31) + n43 * (+n11 * n24 * n32 - n11 * n22 * n34 - n14 * n21 * n32 + n12 * n21 * n34 + n14 * n22 * n31 - n12 * n24 * n31) + n44 * (-n13 * n22 * n31 - n11 * n23 * n32 + n11 * n22 * n33 + n13 * n21 * n32 - n12 * n21 * n33 + n12 * n23 * n31);
      }
      transpose() {
        const te = this.elements;
        let tmp;
        tmp = te[1];
        te[1] = te[4];
        te[4] = tmp;
        tmp = te[2];
        te[2] = te[8];
        te[8] = tmp;
        tmp = te[6];
        te[6] = te[9];
        te[9] = tmp;
        tmp = te[3];
        te[3] = te[12];
        te[12] = tmp;
        tmp = te[7];
        te[7] = te[13];
        te[13] = tmp;
        tmp = te[11];
        te[11] = te[14];
        te[14] = tmp;
        return this;
      }
      setPosition(x, y, z) {
        const te = this.elements;
        if (x.isVector3) {
          te[12] = x.x;
          te[13] = x.y;
          te[14] = x.z;
        } else {
          te[12] = x;
          te[13] = y;
          te[14] = z;
        }
        return this;
      }
      invert() {
        const te = this.elements, n11 = te[0], n21 = te[1], n31 = te[2], n41 = te[3], n12 = te[4], n22 = te[5], n32 = te[6], n42 = te[7], n13 = te[8], n23 = te[9], n33 = te[10], n43 = te[11], n14 = te[12], n24 = te[13], n34 = te[14], n44 = te[15], t11 = n23 * n34 * n42 - n24 * n33 * n42 + n24 * n32 * n43 - n22 * n34 * n43 - n23 * n32 * n44 + n22 * n33 * n44, t12 = n14 * n33 * n42 - n13 * n34 * n42 - n14 * n32 * n43 + n12 * n34 * n43 + n13 * n32 * n44 - n12 * n33 * n44, t13 = n13 * n24 * n42 - n14 * n23 * n42 + n14 * n22 * n43 - n12 * n24 * n43 - n13 * n22 * n44 + n12 * n23 * n44, t14 = n14 * n23 * n32 - n13 * n24 * n32 - n14 * n22 * n33 + n12 * n24 * n33 + n13 * n22 * n34 - n12 * n23 * n34;
        const det = n11 * t11 + n21 * t12 + n31 * t13 + n41 * t14;
        if (det === 0) return this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
        const detInv = 1 / det;
        te[0] = t11 * detInv;
        te[1] = (n24 * n33 * n41 - n23 * n34 * n41 - n24 * n31 * n43 + n21 * n34 * n43 + n23 * n31 * n44 - n21 * n33 * n44) * detInv;
        te[2] = (n22 * n34 * n41 - n24 * n32 * n41 + n24 * n31 * n42 - n21 * n34 * n42 - n22 * n31 * n44 + n21 * n32 * n44) * detInv;
        te[3] = (n23 * n32 * n41 - n22 * n33 * n41 - n23 * n31 * n42 + n21 * n33 * n42 + n22 * n31 * n43 - n21 * n32 * n43) * detInv;
        te[4] = t12 * detInv;
        te[5] = (n13 * n34 * n41 - n14 * n33 * n41 + n14 * n31 * n43 - n11 * n34 * n43 - n13 * n31 * n44 + n11 * n33 * n44) * detInv;
        te[6] = (n14 * n32 * n41 - n12 * n34 * n41 - n14 * n31 * n42 + n11 * n34 * n42 + n12 * n31 * n44 - n11 * n32 * n44) * detInv;
        te[7] = (n12 * n33 * n41 - n13 * n32 * n41 + n13 * n31 * n42 - n11 * n33 * n42 - n12 * n31 * n43 + n11 * n32 * n43) * detInv;
        te[8] = t13 * detInv;
        te[9] = (n14 * n23 * n41 - n13 * n24 * n41 - n14 * n21 * n43 + n11 * n24 * n43 + n13 * n21 * n44 - n11 * n23 * n44) * detInv;
        te[10] = (n12 * n24 * n41 - n14 * n22 * n41 + n14 * n21 * n42 - n11 * n24 * n42 - n12 * n21 * n44 + n11 * n22 * n44) * detInv;
        te[11] = (n13 * n22 * n41 - n12 * n23 * n41 - n13 * n21 * n42 + n11 * n23 * n42 + n12 * n21 * n43 - n11 * n22 * n43) * detInv;
        te[12] = t14 * detInv;
        te[13] = (n13 * n24 * n31 - n14 * n23 * n31 + n14 * n21 * n33 - n11 * n24 * n33 - n13 * n21 * n34 + n11 * n23 * n34) * detInv;
        te[14] = (n14 * n22 * n31 - n12 * n24 * n31 - n14 * n21 * n32 + n11 * n24 * n32 + n12 * n21 * n34 - n11 * n22 * n34) * detInv;
        te[15] = (n12 * n23 * n31 - n13 * n22 * n31 + n13 * n21 * n32 - n11 * n23 * n32 - n12 * n21 * n33 + n11 * n22 * n33) * detInv;
        return this;
      }
      scale(v) {
        const te = this.elements;
        const x = v.x, y = v.y, z = v.z;
        te[0] *= x;
        te[4] *= y;
        te[8] *= z;
        te[1] *= x;
        te[5] *= y;
        te[9] *= z;
        te[2] *= x;
        te[6] *= y;
        te[10] *= z;
        te[3] *= x;
        te[7] *= y;
        te[11] *= z;
        return this;
      }
      getMaxScaleOnAxis() {
        const te = this.elements;
        const scaleXSq = te[0] * te[0] + te[1] * te[1] + te[2] * te[2];
        const scaleYSq = te[4] * te[4] + te[5] * te[5] + te[6] * te[6];
        const scaleZSq = te[8] * te[8] + te[9] * te[9] + te[10] * te[10];
        return Math.sqrt(Math.max(scaleXSq, scaleYSq, scaleZSq));
      }
      makeTranslation(x, y, z) {
        if (x.isVector3) {
          this.set(
            1,
            0,
            0,
            x.x,
            0,
            1,
            0,
            x.y,
            0,
            0,
            1,
            x.z,
            0,
            0,
            0,
            1
          );
        } else {
          this.set(
            1,
            0,
            0,
            x,
            0,
            1,
            0,
            y,
            0,
            0,
            1,
            z,
            0,
            0,
            0,
            1
          );
        }
        return this;
      }
      makeRotationX(theta) {
        const c = Math.cos(theta), s = Math.sin(theta);
        this.set(
          1,
          0,
          0,
          0,
          0,
          c,
          -s,
          0,
          0,
          s,
          c,
          0,
          0,
          0,
          0,
          1
        );
        return this;
      }
      makeRotationY(theta) {
        const c = Math.cos(theta), s = Math.sin(theta);
        this.set(
          c,
          0,
          s,
          0,
          0,
          1,
          0,
          0,
          -s,
          0,
          c,
          0,
          0,
          0,
          0,
          1
        );
        return this;
      }
      makeRotationZ(theta) {
        const c = Math.cos(theta), s = Math.sin(theta);
        this.set(
          c,
          -s,
          0,
          0,
          s,
          c,
          0,
          0,
          0,
          0,
          1,
          0,
          0,
          0,
          0,
          1
        );
        return this;
      }
      makeRotationAxis(axis, angle) {
        const c = Math.cos(angle);
        const s = Math.sin(angle);
        const t = 1 - c;
        const x = axis.x, y = axis.y, z = axis.z;
        const tx = t * x, ty = t * y;
        this.set(
          tx * x + c,
          tx * y - s * z,
          tx * z + s * y,
          0,
          tx * y + s * z,
          ty * y + c,
          ty * z - s * x,
          0,
          tx * z - s * y,
          ty * z + s * x,
          t * z * z + c,
          0,
          0,
          0,
          0,
          1
        );
        return this;
      }
      makeScale(x, y, z) {
        this.set(
          x,
          0,
          0,
          0,
          0,
          y,
          0,
          0,
          0,
          0,
          z,
          0,
          0,
          0,
          0,
          1
        );
        return this;
      }
      makeShear(xy, xz, yx, yz, zx, zy) {
        this.set(
          1,
          yx,
          zx,
          0,
          xy,
          1,
          zy,
          0,
          xz,
          yz,
          1,
          0,
          0,
          0,
          0,
          1
        );
        return this;
      }
      compose(position, quaternion, scale) {
        const te = this.elements;
        const x = quaternion._x, y = quaternion._y, z = quaternion._z, w = quaternion._w;
        const x2 = x + x, y2 = y + y, z2 = z + z;
        const xx = x * x2, xy = x * y2, xz = x * z2;
        const yy = y * y2, yz = y * z2, zz = z * z2;
        const wx = w * x2, wy = w * y2, wz = w * z2;
        const sx = scale.x, sy = scale.y, sz = scale.z;
        te[0] = (1 - (yy + zz)) * sx;
        te[1] = (xy + wz) * sx;
        te[2] = (xz - wy) * sx;
        te[3] = 0;
        te[4] = (xy - wz) * sy;
        te[5] = (1 - (xx + zz)) * sy;
        te[6] = (yz + wx) * sy;
        te[7] = 0;
        te[8] = (xz + wy) * sz;
        te[9] = (yz - wx) * sz;
        te[10] = (1 - (xx + yy)) * sz;
        te[11] = 0;
        te[12] = position.x;
        te[13] = position.y;
        te[14] = position.z;
        te[15] = 1;
        return this;
      }
      decompose(position, quaternion, scale) {
        const te = this.elements;
        let sx = _v1$5.set(te[0], te[1], te[2]).length();
        const sy = _v1$5.set(te[4], te[5], te[6]).length();
        const sz = _v1$5.set(te[8], te[9], te[10]).length();
        const det = this.determinant();
        if (det < 0) sx = -sx;
        position.x = te[12];
        position.y = te[13];
        position.z = te[14];
        _m1$4.copy(this);
        const invSX = 1 / sx;
        const invSY = 1 / sy;
        const invSZ = 1 / sz;
        _m1$4.elements[0] *= invSX;
        _m1$4.elements[1] *= invSX;
        _m1$4.elements[2] *= invSX;
        _m1$4.elements[4] *= invSY;
        _m1$4.elements[5] *= invSY;
        _m1$4.elements[6] *= invSY;
        _m1$4.elements[8] *= invSZ;
        _m1$4.elements[9] *= invSZ;
        _m1$4.elements[10] *= invSZ;
        quaternion.setFromRotationMatrix(_m1$4);
        scale.x = sx;
        scale.y = sy;
        scale.z = sz;
        return this;
      }
      makePerspective(left, right, top, bottom, near, far, coordinateSystem = WebGLCoordinateSystem) {
        const te = this.elements;
        const x = 2 * near / (right - left);
        const y = 2 * near / (top - bottom);
        const a = (right + left) / (right - left);
        const b = (top + bottom) / (top - bottom);
        let c, d;
        if (coordinateSystem === WebGLCoordinateSystem) {
          c = -(far + near) / (far - near);
          d = -2 * far * near / (far - near);
        } else if (coordinateSystem === WebGPUCoordinateSystem) {
          c = -far / (far - near);
          d = -far * near / (far - near);
        } else {
          throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: " + coordinateSystem);
        }
        te[0] = x;
        te[4] = 0;
        te[8] = a;
        te[12] = 0;
        te[1] = 0;
        te[5] = y;
        te[9] = b;
        te[13] = 0;
        te[2] = 0;
        te[6] = 0;
        te[10] = c;
        te[14] = d;
        te[3] = 0;
        te[7] = 0;
        te[11] = -1;
        te[15] = 0;
        return this;
      }
      makeOrthographic(left, right, top, bottom, near, far, coordinateSystem = WebGLCoordinateSystem) {
        const te = this.elements;
        const w = 1 / (right - left);
        const h = 1 / (top - bottom);
        const p = 1 / (far - near);
        const x = (right + left) * w;
        const y = (top + bottom) * h;
        let z, zInv;
        if (coordinateSystem === WebGLCoordinateSystem) {
          z = (far + near) * p;
          zInv = -2 * p;
        } else if (coordinateSystem === WebGPUCoordinateSystem) {
          z = near * p;
          zInv = -1 * p;
        } else {
          throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: " + coordinateSystem);
        }
        te[0] = 2 * w;
        te[4] = 0;
        te[8] = 0;
        te[12] = -x;
        te[1] = 0;
        te[5] = 2 * h;
        te[9] = 0;
        te[13] = -y;
        te[2] = 0;
        te[6] = 0;
        te[10] = zInv;
        te[14] = -z;
        te[3] = 0;
        te[7] = 0;
        te[11] = 0;
        te[15] = 1;
        return this;
      }
      equals(matrix) {
        const te = this.elements;
        const me = matrix.elements;
        for (let i = 0; i < 16; i++) {
          if (te[i] !== me[i]) return false;
        }
        return true;
      }
      fromArray(array, offset = 0) {
        for (let i = 0; i < 16; i++) {
          this.elements[i] = array[i + offset];
        }
        return this;
      }
      toArray(array = [], offset = 0) {
        const te = this.elements;
        array[offset] = te[0];
        array[offset + 1] = te[1];
        array[offset + 2] = te[2];
        array[offset + 3] = te[3];
        array[offset + 4] = te[4];
        array[offset + 5] = te[5];
        array[offset + 6] = te[6];
        array[offset + 7] = te[7];
        array[offset + 8] = te[8];
        array[offset + 9] = te[9];
        array[offset + 10] = te[10];
        array[offset + 11] = te[11];
        array[offset + 12] = te[12];
        array[offset + 13] = te[13];
        array[offset + 14] = te[14];
        array[offset + 15] = te[15];
        return array;
      }
    };
    _v1$5 = /* @__PURE__ */ new Vector3();
    _m1$4 = /* @__PURE__ */ new Matrix4();
    _zero = /* @__PURE__ */ new Vector3(0, 0, 0);
    _one = /* @__PURE__ */ new Vector3(1, 1, 1);
    _x = /* @__PURE__ */ new Vector3();
    _y = /* @__PURE__ */ new Vector3();
    _z = /* @__PURE__ */ new Vector3();
    _matrix$2 = /* @__PURE__ */ new Matrix4();
    _quaternion$3 = /* @__PURE__ */ new Quaternion();
    Euler = class _Euler {
      constructor(x = 0, y = 0, z = 0, order = _Euler.DEFAULT_ORDER) {
        this.isEuler = true;
        this._x = x;
        this._y = y;
        this._z = z;
        this._order = order;
      }
      get x() {
        return this._x;
      }
      set x(value) {
        this._x = value;
        this._onChangeCallback();
      }
      get y() {
        return this._y;
      }
      set y(value) {
        this._y = value;
        this._onChangeCallback();
      }
      get z() {
        return this._z;
      }
      set z(value) {
        this._z = value;
        this._onChangeCallback();
      }
      get order() {
        return this._order;
      }
      set order(value) {
        this._order = value;
        this._onChangeCallback();
      }
      set(x, y, z, order = this._order) {
        this._x = x;
        this._y = y;
        this._z = z;
        this._order = order;
        this._onChangeCallback();
        return this;
      }
      clone() {
        return new this.constructor(this._x, this._y, this._z, this._order);
      }
      copy(euler) {
        this._x = euler._x;
        this._y = euler._y;
        this._z = euler._z;
        this._order = euler._order;
        this._onChangeCallback();
        return this;
      }
      setFromRotationMatrix(m, order = this._order, update = true) {
        const te = m.elements;
        const m11 = te[0], m12 = te[4], m13 = te[8];
        const m21 = te[1], m22 = te[5], m23 = te[9];
        const m31 = te[2], m32 = te[6], m33 = te[10];
        switch (order) {
          case "XYZ":
            this._y = Math.asin(clamp(m13, -1, 1));
            if (Math.abs(m13) < 0.9999999) {
              this._x = Math.atan2(-m23, m33);
              this._z = Math.atan2(-m12, m11);
            } else {
              this._x = Math.atan2(m32, m22);
              this._z = 0;
            }
            break;
          case "YXZ":
            this._x = Math.asin(-clamp(m23, -1, 1));
            if (Math.abs(m23) < 0.9999999) {
              this._y = Math.atan2(m13, m33);
              this._z = Math.atan2(m21, m22);
            } else {
              this._y = Math.atan2(-m31, m11);
              this._z = 0;
            }
            break;
          case "ZXY":
            this._x = Math.asin(clamp(m32, -1, 1));
            if (Math.abs(m32) < 0.9999999) {
              this._y = Math.atan2(-m31, m33);
              this._z = Math.atan2(-m12, m22);
            } else {
              this._y = 0;
              this._z = Math.atan2(m21, m11);
            }
            break;
          case "ZYX":
            this._y = Math.asin(-clamp(m31, -1, 1));
            if (Math.abs(m31) < 0.9999999) {
              this._x = Math.atan2(m32, m33);
              this._z = Math.atan2(m21, m11);
            } else {
              this._x = 0;
              this._z = Math.atan2(-m12, m22);
            }
            break;
          case "YZX":
            this._z = Math.asin(clamp(m21, -1, 1));
            if (Math.abs(m21) < 0.9999999) {
              this._x = Math.atan2(-m23, m22);
              this._y = Math.atan2(-m31, m11);
            } else {
              this._x = 0;
              this._y = Math.atan2(m13, m33);
            }
            break;
          case "XZY":
            this._z = Math.asin(-clamp(m12, -1, 1));
            if (Math.abs(m12) < 0.9999999) {
              this._x = Math.atan2(m32, m22);
              this._y = Math.atan2(m13, m11);
            } else {
              this._x = Math.atan2(-m23, m33);
              this._y = 0;
            }
            break;
          default:
            console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: " + order);
        }
        this._order = order;
        if (update === true) this._onChangeCallback();
        return this;
      }
      setFromQuaternion(q, order, update) {
        _matrix$2.makeRotationFromQuaternion(q);
        return this.setFromRotationMatrix(_matrix$2, order, update);
      }
      setFromVector3(v, order = this._order) {
        return this.set(v.x, v.y, v.z, order);
      }
      reorder(newOrder) {
        _quaternion$3.setFromEuler(this);
        return this.setFromQuaternion(_quaternion$3, newOrder);
      }
      equals(euler) {
        return euler._x === this._x && euler._y === this._y && euler._z === this._z && euler._order === this._order;
      }
      fromArray(array) {
        this._x = array[0];
        this._y = array[1];
        this._z = array[2];
        if (array[3] !== void 0) this._order = array[3];
        this._onChangeCallback();
        return this;
      }
      toArray(array = [], offset = 0) {
        array[offset] = this._x;
        array[offset + 1] = this._y;
        array[offset + 2] = this._z;
        array[offset + 3] = this._order;
        return array;
      }
      _onChange(callback) {
        this._onChangeCallback = callback;
        return this;
      }
      _onChangeCallback() {
      }
      *[Symbol.iterator]() {
        yield this._x;
        yield this._y;
        yield this._z;
        yield this._order;
      }
    };
    Euler.DEFAULT_ORDER = "XYZ";
    Layers = class {
      constructor() {
        this.mask = 1 | 0;
      }
      set(channel) {
        this.mask = (1 << channel | 0) >>> 0;
      }
      enable(channel) {
        this.mask |= 1 << channel | 0;
      }
      enableAll() {
        this.mask = 4294967295 | 0;
      }
      toggle(channel) {
        this.mask ^= 1 << channel | 0;
      }
      disable(channel) {
        this.mask &= ~(1 << channel | 0);
      }
      disableAll() {
        this.mask = 0;
      }
      test(layers) {
        return (this.mask & layers.mask) !== 0;
      }
      isEnabled(channel) {
        return (this.mask & (1 << channel | 0)) !== 0;
      }
    };
    _object3DId = 0;
    _v1$4 = /* @__PURE__ */ new Vector3();
    _q1 = /* @__PURE__ */ new Quaternion();
    _m1$3 = /* @__PURE__ */ new Matrix4();
    _target = /* @__PURE__ */ new Vector3();
    _position$3 = /* @__PURE__ */ new Vector3();
    _scale$2 = /* @__PURE__ */ new Vector3();
    _quaternion$2 = /* @__PURE__ */ new Quaternion();
    _xAxis = /* @__PURE__ */ new Vector3(1, 0, 0);
    _yAxis = /* @__PURE__ */ new Vector3(0, 1, 0);
    _zAxis = /* @__PURE__ */ new Vector3(0, 0, 1);
    _addedEvent = { type: "added" };
    _removedEvent = { type: "removed" };
    _childaddedEvent = { type: "childadded", child: null };
    _childremovedEvent = { type: "childremoved", child: null };
    Object3D = class _Object3D extends EventDispatcher {
      constructor() {
        super();
        this.isObject3D = true;
        Object.defineProperty(this, "id", { value: _object3DId++ });
        this.uuid = generateUUID();
        this.name = "";
        this.type = "Object3D";
        this.parent = null;
        this.children = [];
        this.up = _Object3D.DEFAULT_UP.clone();
        const position = new Vector3();
        const rotation = new Euler();
        const quaternion = new Quaternion();
        const scale = new Vector3(1, 1, 1);
        function onRotationChange() {
          quaternion.setFromEuler(rotation, false);
        }
        function onQuaternionChange() {
          rotation.setFromQuaternion(quaternion, void 0, false);
        }
        rotation._onChange(onRotationChange);
        quaternion._onChange(onQuaternionChange);
        Object.defineProperties(this, {
          position: {
            configurable: true,
            enumerable: true,
            value: position
          },
          rotation: {
            configurable: true,
            enumerable: true,
            value: rotation
          },
          quaternion: {
            configurable: true,
            enumerable: true,
            value: quaternion
          },
          scale: {
            configurable: true,
            enumerable: true,
            value: scale
          },
          modelViewMatrix: {
            value: new Matrix4()
          },
          normalMatrix: {
            value: new Matrix3()
          }
        });
        this.matrix = new Matrix4();
        this.matrixWorld = new Matrix4();
        this.matrixAutoUpdate = _Object3D.DEFAULT_MATRIX_AUTO_UPDATE;
        this.matrixWorldAutoUpdate = _Object3D.DEFAULT_MATRIX_WORLD_AUTO_UPDATE;
        this.matrixWorldNeedsUpdate = false;
        this.layers = new Layers();
        this.visible = true;
        this.castShadow = false;
        this.receiveShadow = false;
        this.frustumCulled = true;
        this.renderOrder = 0;
        this.animations = [];
        this.userData = {};
      }
      onBeforeShadow() {
      }
      onAfterShadow() {
      }
      onBeforeRender() {
      }
      onAfterRender() {
      }
      applyMatrix4(matrix) {
        if (this.matrixAutoUpdate) this.updateMatrix();
        this.matrix.premultiply(matrix);
        this.matrix.decompose(this.position, this.quaternion, this.scale);
      }
      applyQuaternion(q) {
        this.quaternion.premultiply(q);
        return this;
      }
      setRotationFromAxisAngle(axis, angle) {
        this.quaternion.setFromAxisAngle(axis, angle);
      }
      setRotationFromEuler(euler) {
        this.quaternion.setFromEuler(euler, true);
      }
      setRotationFromMatrix(m) {
        this.quaternion.setFromRotationMatrix(m);
      }
      setRotationFromQuaternion(q) {
        this.quaternion.copy(q);
      }
      rotateOnAxis(axis, angle) {
        _q1.setFromAxisAngle(axis, angle);
        this.quaternion.multiply(_q1);
        return this;
      }
      rotateOnWorldAxis(axis, angle) {
        _q1.setFromAxisAngle(axis, angle);
        this.quaternion.premultiply(_q1);
        return this;
      }
      rotateX(angle) {
        return this.rotateOnAxis(_xAxis, angle);
      }
      rotateY(angle) {
        return this.rotateOnAxis(_yAxis, angle);
      }
      rotateZ(angle) {
        return this.rotateOnAxis(_zAxis, angle);
      }
      translateOnAxis(axis, distance) {
        _v1$4.copy(axis).applyQuaternion(this.quaternion);
        this.position.add(_v1$4.multiplyScalar(distance));
        return this;
      }
      translateX(distance) {
        return this.translateOnAxis(_xAxis, distance);
      }
      translateY(distance) {
        return this.translateOnAxis(_yAxis, distance);
      }
      translateZ(distance) {
        return this.translateOnAxis(_zAxis, distance);
      }
      localToWorld(vector) {
        this.updateWorldMatrix(true, false);
        return vector.applyMatrix4(this.matrixWorld);
      }
      worldToLocal(vector) {
        this.updateWorldMatrix(true, false);
        return vector.applyMatrix4(_m1$3.copy(this.matrixWorld).invert());
      }
      lookAt(x, y, z) {
        if (x.isVector3) {
          _target.copy(x);
        } else {
          _target.set(x, y, z);
        }
        const parent = this.parent;
        this.updateWorldMatrix(true, false);
        _position$3.setFromMatrixPosition(this.matrixWorld);
        if (this.isCamera || this.isLight) {
          _m1$3.lookAt(_position$3, _target, this.up);
        } else {
          _m1$3.lookAt(_target, _position$3, this.up);
        }
        this.quaternion.setFromRotationMatrix(_m1$3);
        if (parent) {
          _m1$3.extractRotation(parent.matrixWorld);
          _q1.setFromRotationMatrix(_m1$3);
          this.quaternion.premultiply(_q1.invert());
        }
      }
      add(object) {
        if (arguments.length > 1) {
          for (let i = 0; i < arguments.length; i++) {
            this.add(arguments[i]);
          }
          return this;
        }
        if (object === this) {
          console.error("THREE.Object3D.add: object can't be added as a child of itself.", object);
          return this;
        }
        if (object && object.isObject3D) {
          object.removeFromParent();
          object.parent = this;
          this.children.push(object);
          object.dispatchEvent(_addedEvent);
          _childaddedEvent.child = object;
          this.dispatchEvent(_childaddedEvent);
          _childaddedEvent.child = null;
        } else {
          console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.", object);
        }
        return this;
      }
      remove(object) {
        if (arguments.length > 1) {
          for (let i = 0; i < arguments.length; i++) {
            this.remove(arguments[i]);
          }
          return this;
        }
        const index = this.children.indexOf(object);
        if (index !== -1) {
          object.parent = null;
          this.children.splice(index, 1);
          object.dispatchEvent(_removedEvent);
          _childremovedEvent.child = object;
          this.dispatchEvent(_childremovedEvent);
          _childremovedEvent.child = null;
        }
        return this;
      }
      removeFromParent() {
        const parent = this.parent;
        if (parent !== null) {
          parent.remove(this);
        }
        return this;
      }
      clear() {
        return this.remove(...this.children);
      }
      attach(object) {
        this.updateWorldMatrix(true, false);
        _m1$3.copy(this.matrixWorld).invert();
        if (object.parent !== null) {
          object.parent.updateWorldMatrix(true, false);
          _m1$3.multiply(object.parent.matrixWorld);
        }
        object.applyMatrix4(_m1$3);
        object.removeFromParent();
        object.parent = this;
        this.children.push(object);
        object.updateWorldMatrix(false, true);
        object.dispatchEvent(_addedEvent);
        _childaddedEvent.child = object;
        this.dispatchEvent(_childaddedEvent);
        _childaddedEvent.child = null;
        return this;
      }
      getObjectById(id) {
        return this.getObjectByProperty("id", id);
      }
      getObjectByName(name) {
        return this.getObjectByProperty("name", name);
      }
      getObjectByProperty(name, value) {
        if (this[name] === value) return this;
        for (let i = 0, l = this.children.length; i < l; i++) {
          const child = this.children[i];
          const object = child.getObjectByProperty(name, value);
          if (object !== void 0) {
            return object;
          }
        }
        return void 0;
      }
      getObjectsByProperty(name, value, result = []) {
        if (this[name] === value) result.push(this);
        const children = this.children;
        for (let i = 0, l = children.length; i < l; i++) {
          children[i].getObjectsByProperty(name, value, result);
        }
        return result;
      }
      getWorldPosition(target) {
        this.updateWorldMatrix(true, false);
        return target.setFromMatrixPosition(this.matrixWorld);
      }
      getWorldQuaternion(target) {
        this.updateWorldMatrix(true, false);
        this.matrixWorld.decompose(_position$3, target, _scale$2);
        return target;
      }
      getWorldScale(target) {
        this.updateWorldMatrix(true, false);
        this.matrixWorld.decompose(_position$3, _quaternion$2, target);
        return target;
      }
      getWorldDirection(target) {
        this.updateWorldMatrix(true, false);
        const e = this.matrixWorld.elements;
        return target.set(e[8], e[9], e[10]).normalize();
      }
      raycast() {
      }
      traverse(callback) {
        callback(this);
        const children = this.children;
        for (let i = 0, l = children.length; i < l; i++) {
          children[i].traverse(callback);
        }
      }
      traverseVisible(callback) {
        if (this.visible === false) return;
        callback(this);
        const children = this.children;
        for (let i = 0, l = children.length; i < l; i++) {
          children[i].traverseVisible(callback);
        }
      }
      traverseAncestors(callback) {
        const parent = this.parent;
        if (parent !== null) {
          callback(parent);
          parent.traverseAncestors(callback);
        }
      }
      updateMatrix() {
        this.matrix.compose(this.position, this.quaternion, this.scale);
        this.matrixWorldNeedsUpdate = true;
      }
      updateMatrixWorld(force) {
        if (this.matrixAutoUpdate) this.updateMatrix();
        if (this.matrixWorldNeedsUpdate || force) {
          if (this.matrixWorldAutoUpdate === true) {
            if (this.parent === null) {
              this.matrixWorld.copy(this.matrix);
            } else {
              this.matrixWorld.multiplyMatrices(this.parent.matrixWorld, this.matrix);
            }
          }
          this.matrixWorldNeedsUpdate = false;
          force = true;
        }
        const children = this.children;
        for (let i = 0, l = children.length; i < l; i++) {
          const child = children[i];
          child.updateMatrixWorld(force);
        }
      }
      updateWorldMatrix(updateParents, updateChildren) {
        const parent = this.parent;
        if (updateParents === true && parent !== null) {
          parent.updateWorldMatrix(true, false);
        }
        if (this.matrixAutoUpdate) this.updateMatrix();
        if (this.matrixWorldAutoUpdate === true) {
          if (this.parent === null) {
            this.matrixWorld.copy(this.matrix);
          } else {
            this.matrixWorld.multiplyMatrices(this.parent.matrixWorld, this.matrix);
          }
        }
        if (updateChildren === true) {
          const children = this.children;
          for (let i = 0, l = children.length; i < l; i++) {
            const child = children[i];
            child.updateWorldMatrix(false, true);
          }
        }
      }
      toJSON(meta) {
        const isRootObject = meta === void 0 || typeof meta === "string";
        const output = {};
        if (isRootObject) {
          meta = {
            geometries: {},
            materials: {},
            textures: {},
            images: {},
            shapes: {},
            skeletons: {},
            animations: {},
            nodes: {}
          };
          output.metadata = {
            version: 4.6,
            type: "Object",
            generator: "Object3D.toJSON"
          };
        }
        const object = {};
        object.uuid = this.uuid;
        object.type = this.type;
        if (this.name !== "") object.name = this.name;
        if (this.castShadow === true) object.castShadow = true;
        if (this.receiveShadow === true) object.receiveShadow = true;
        if (this.visible === false) object.visible = false;
        if (this.frustumCulled === false) object.frustumCulled = false;
        if (this.renderOrder !== 0) object.renderOrder = this.renderOrder;
        if (Object.keys(this.userData).length > 0) object.userData = this.userData;
        object.layers = this.layers.mask;
        object.matrix = this.matrix.toArray();
        object.up = this.up.toArray();
        if (this.matrixAutoUpdate === false) object.matrixAutoUpdate = false;
        if (this.isInstancedMesh) {
          object.type = "InstancedMesh";
          object.count = this.count;
          object.instanceMatrix = this.instanceMatrix.toJSON();
          if (this.instanceColor !== null) object.instanceColor = this.instanceColor.toJSON();
        }
        if (this.isBatchedMesh) {
          object.type = "BatchedMesh";
          object.perObjectFrustumCulled = this.perObjectFrustumCulled;
          object.sortObjects = this.sortObjects;
          object.drawRanges = this._drawRanges;
          object.reservedRanges = this._reservedRanges;
          object.visibility = this._visibility;
          object.active = this._active;
          object.bounds = this._bounds.map((bound) => ({
            boxInitialized: bound.boxInitialized,
            boxMin: bound.box.min.toArray(),
            boxMax: bound.box.max.toArray(),
            sphereInitialized: bound.sphereInitialized,
            sphereRadius: bound.sphere.radius,
            sphereCenter: bound.sphere.center.toArray()
          }));
          object.maxInstanceCount = this._maxInstanceCount;
          object.maxVertexCount = this._maxVertexCount;
          object.maxIndexCount = this._maxIndexCount;
          object.geometryInitialized = this._geometryInitialized;
          object.geometryCount = this._geometryCount;
          object.matricesTexture = this._matricesTexture.toJSON(meta);
          if (this._colorsTexture !== null) object.colorsTexture = this._colorsTexture.toJSON(meta);
          if (this.boundingSphere !== null) {
            object.boundingSphere = {
              center: object.boundingSphere.center.toArray(),
              radius: object.boundingSphere.radius
            };
          }
          if (this.boundingBox !== null) {
            object.boundingBox = {
              min: object.boundingBox.min.toArray(),
              max: object.boundingBox.max.toArray()
            };
          }
        }
        function serialize(library, element) {
          if (library[element.uuid] === void 0) {
            library[element.uuid] = element.toJSON(meta);
          }
          return element.uuid;
        }
        if (this.isScene) {
          if (this.background) {
            if (this.background.isColor) {
              object.background = this.background.toJSON();
            } else if (this.background.isTexture) {
              object.background = this.background.toJSON(meta).uuid;
            }
          }
          if (this.environment && this.environment.isTexture && this.environment.isRenderTargetTexture !== true) {
            object.environment = this.environment.toJSON(meta).uuid;
          }
        } else if (this.isMesh || this.isLine || this.isPoints) {
          object.geometry = serialize(meta.geometries, this.geometry);
          const parameters = this.geometry.parameters;
          if (parameters !== void 0 && parameters.shapes !== void 0) {
            const shapes = parameters.shapes;
            if (Array.isArray(shapes)) {
              for (let i = 0, l = shapes.length; i < l; i++) {
                const shape = shapes[i];
                serialize(meta.shapes, shape);
              }
            } else {
              serialize(meta.shapes, shapes);
            }
          }
        }
        if (this.isSkinnedMesh) {
          object.bindMode = this.bindMode;
          object.bindMatrix = this.bindMatrix.toArray();
          if (this.skeleton !== void 0) {
            serialize(meta.skeletons, this.skeleton);
            object.skeleton = this.skeleton.uuid;
          }
        }
        if (this.material !== void 0) {
          if (Array.isArray(this.material)) {
            const uuids = [];
            for (let i = 0, l = this.material.length; i < l; i++) {
              uuids.push(serialize(meta.materials, this.material[i]));
            }
            object.material = uuids;
          } else {
            object.material = serialize(meta.materials, this.material);
          }
        }
        if (this.children.length > 0) {
          object.children = [];
          for (let i = 0; i < this.children.length; i++) {
            object.children.push(this.children[i].toJSON(meta).object);
          }
        }
        if (this.animations.length > 0) {
          object.animations = [];
          for (let i = 0; i < this.animations.length; i++) {
            const animation = this.animations[i];
            object.animations.push(serialize(meta.animations, animation));
          }
        }
        if (isRootObject) {
          const geometries = extractFromCache(meta.geometries);
          const materials = extractFromCache(meta.materials);
          const textures = extractFromCache(meta.textures);
          const images = extractFromCache(meta.images);
          const shapes = extractFromCache(meta.shapes);
          const skeletons = extractFromCache(meta.skeletons);
          const animations = extractFromCache(meta.animations);
          const nodes = extractFromCache(meta.nodes);
          if (geometries.length > 0) output.geometries = geometries;
          if (materials.length > 0) output.materials = materials;
          if (textures.length > 0) output.textures = textures;
          if (images.length > 0) output.images = images;
          if (shapes.length > 0) output.shapes = shapes;
          if (skeletons.length > 0) output.skeletons = skeletons;
          if (animations.length > 0) output.animations = animations;
          if (nodes.length > 0) output.nodes = nodes;
        }
        output.object = object;
        return output;
        function extractFromCache(cache2) {
          const values = [];
          for (const key in cache2) {
            const data = cache2[key];
            delete data.metadata;
            values.push(data);
          }
          return values;
        }
      }
      clone(recursive) {
        return new this.constructor().copy(this, recursive);
      }
      copy(source, recursive = true) {
        this.name = source.name;
        this.up.copy(source.up);
        this.position.copy(source.position);
        this.rotation.order = source.rotation.order;
        this.quaternion.copy(source.quaternion);
        this.scale.copy(source.scale);
        this.matrix.copy(source.matrix);
        this.matrixWorld.copy(source.matrixWorld);
        this.matrixAutoUpdate = source.matrixAutoUpdate;
        this.matrixWorldAutoUpdate = source.matrixWorldAutoUpdate;
        this.matrixWorldNeedsUpdate = source.matrixWorldNeedsUpdate;
        this.layers.mask = source.layers.mask;
        this.visible = source.visible;
        this.castShadow = source.castShadow;
        this.receiveShadow = source.receiveShadow;
        this.frustumCulled = source.frustumCulled;
        this.renderOrder = source.renderOrder;
        this.animations = source.animations.slice();
        this.userData = JSON.parse(JSON.stringify(source.userData));
        if (recursive === true) {
          for (let i = 0; i < source.children.length; i++) {
            const child = source.children[i];
            this.add(child.clone());
          }
        }
        return this;
      }
    };
    Object3D.DEFAULT_UP = /* @__PURE__ */ new Vector3(0, 1, 0);
    Object3D.DEFAULT_MATRIX_AUTO_UPDATE = true;
    Object3D.DEFAULT_MATRIX_WORLD_AUTO_UPDATE = true;
    _v0$2 = /* @__PURE__ */ new Vector3();
    _v1$3 = /* @__PURE__ */ new Vector3();
    _v2$2 = /* @__PURE__ */ new Vector3();
    _v3$2 = /* @__PURE__ */ new Vector3();
    _vab = /* @__PURE__ */ new Vector3();
    _vac = /* @__PURE__ */ new Vector3();
    _vbc = /* @__PURE__ */ new Vector3();
    _vap = /* @__PURE__ */ new Vector3();
    _vbp = /* @__PURE__ */ new Vector3();
    _vcp = /* @__PURE__ */ new Vector3();
    _v40 = /* @__PURE__ */ new Vector4();
    _v41 = /* @__PURE__ */ new Vector4();
    _v42 = /* @__PURE__ */ new Vector4();
    Triangle = class _Triangle {
      constructor(a = new Vector3(), b = new Vector3(), c = new Vector3()) {
        this.a = a;
        this.b = b;
        this.c = c;
      }
      static getNormal(a, b, c, target) {
        target.subVectors(c, b);
        _v0$2.subVectors(a, b);
        target.cross(_v0$2);
        const targetLengthSq = target.lengthSq();
        if (targetLengthSq > 0) {
          return target.multiplyScalar(1 / Math.sqrt(targetLengthSq));
        }
        return target.set(0, 0, 0);
      }
      // static/instance method to calculate barycentric coordinates
      // based on: http://www.blackpawn.com/texts/pointinpoly/default.html
      static getBarycoord(point, a, b, c, target) {
        _v0$2.subVectors(c, a);
        _v1$3.subVectors(b, a);
        _v2$2.subVectors(point, a);
        const dot00 = _v0$2.dot(_v0$2);
        const dot01 = _v0$2.dot(_v1$3);
        const dot02 = _v0$2.dot(_v2$2);
        const dot11 = _v1$3.dot(_v1$3);
        const dot12 = _v1$3.dot(_v2$2);
        const denom = dot00 * dot11 - dot01 * dot01;
        if (denom === 0) {
          target.set(0, 0, 0);
          return null;
        }
        const invDenom = 1 / denom;
        const u = (dot11 * dot02 - dot01 * dot12) * invDenom;
        const v = (dot00 * dot12 - dot01 * dot02) * invDenom;
        return target.set(1 - u - v, v, u);
      }
      static containsPoint(point, a, b, c) {
        if (this.getBarycoord(point, a, b, c, _v3$2) === null) {
          return false;
        }
        return _v3$2.x >= 0 && _v3$2.y >= 0 && _v3$2.x + _v3$2.y <= 1;
      }
      static getInterpolation(point, p1, p2, p3, v1, v2, v3, target) {
        if (this.getBarycoord(point, p1, p2, p3, _v3$2) === null) {
          target.x = 0;
          target.y = 0;
          if ("z" in target) target.z = 0;
          if ("w" in target) target.w = 0;
          return null;
        }
        target.setScalar(0);
        target.addScaledVector(v1, _v3$2.x);
        target.addScaledVector(v2, _v3$2.y);
        target.addScaledVector(v3, _v3$2.z);
        return target;
      }
      static getInterpolatedAttribute(attr, i1, i2, i3, barycoord, target) {
        _v40.setScalar(0);
        _v41.setScalar(0);
        _v42.setScalar(0);
        _v40.fromBufferAttribute(attr, i1);
        _v41.fromBufferAttribute(attr, i2);
        _v42.fromBufferAttribute(attr, i3);
        target.setScalar(0);
        target.addScaledVector(_v40, barycoord.x);
        target.addScaledVector(_v41, barycoord.y);
        target.addScaledVector(_v42, barycoord.z);
        return target;
      }
      static isFrontFacing(a, b, c, direction) {
        _v0$2.subVectors(c, b);
        _v1$3.subVectors(a, b);
        return _v0$2.cross(_v1$3).dot(direction) < 0 ? true : false;
      }
      set(a, b, c) {
        this.a.copy(a);
        this.b.copy(b);
        this.c.copy(c);
        return this;
      }
      setFromPointsAndIndices(points, i0, i1, i2) {
        this.a.copy(points[i0]);
        this.b.copy(points[i1]);
        this.c.copy(points[i2]);
        return this;
      }
      setFromAttributeAndIndices(attribute, i0, i1, i2) {
        this.a.fromBufferAttribute(attribute, i0);
        this.b.fromBufferAttribute(attribute, i1);
        this.c.fromBufferAttribute(attribute, i2);
        return this;
      }
      clone() {
        return new this.constructor().copy(this);
      }
      copy(triangle) {
        this.a.copy(triangle.a);
        this.b.copy(triangle.b);
        this.c.copy(triangle.c);
        return this;
      }
      getArea() {
        _v0$2.subVectors(this.c, this.b);
        _v1$3.subVectors(this.a, this.b);
        return _v0$2.cross(_v1$3).length() * 0.5;
      }
      getMidpoint(target) {
        return target.addVectors(this.a, this.b).add(this.c).multiplyScalar(1 / 3);
      }
      getNormal(target) {
        return _Triangle.getNormal(this.a, this.b, this.c, target);
      }
      getPlane(target) {
        return target.setFromCoplanarPoints(this.a, this.b, this.c);
      }
      getBarycoord(point, target) {
        return _Triangle.getBarycoord(point, this.a, this.b, this.c, target);
      }
      getInterpolation(point, v1, v2, v3, target) {
        return _Triangle.getInterpolation(point, this.a, this.b, this.c, v1, v2, v3, target);
      }
      containsPoint(point) {
        return _Triangle.containsPoint(point, this.a, this.b, this.c);
      }
      isFrontFacing(direction) {
        return _Triangle.isFrontFacing(this.a, this.b, this.c, direction);
      }
      intersectsBox(box2) {
        return box2.intersectsTriangle(this);
      }
      closestPointToPoint(p, target) {
        const a = this.a, b = this.b, c = this.c;
        let v, w;
        _vab.subVectors(b, a);
        _vac.subVectors(c, a);
        _vap.subVectors(p, a);
        const d1 = _vab.dot(_vap);
        const d2 = _vac.dot(_vap);
        if (d1 <= 0 && d2 <= 0) {
          return target.copy(a);
        }
        _vbp.subVectors(p, b);
        const d3 = _vab.dot(_vbp);
        const d4 = _vac.dot(_vbp);
        if (d3 >= 0 && d4 <= d3) {
          return target.copy(b);
        }
        const vc = d1 * d4 - d3 * d2;
        if (vc <= 0 && d1 >= 0 && d3 <= 0) {
          v = d1 / (d1 - d3);
          return target.copy(a).addScaledVector(_vab, v);
        }
        _vcp.subVectors(p, c);
        const d5 = _vab.dot(_vcp);
        const d6 = _vac.dot(_vcp);
        if (d6 >= 0 && d5 <= d6) {
          return target.copy(c);
        }
        const vb = d5 * d2 - d1 * d6;
        if (vb <= 0 && d2 >= 0 && d6 <= 0) {
          w = d2 / (d2 - d6);
          return target.copy(a).addScaledVector(_vac, w);
        }
        const va = d3 * d6 - d5 * d4;
        if (va <= 0 && d4 - d3 >= 0 && d5 - d6 >= 0) {
          _vbc.subVectors(c, b);
          w = (d4 - d3) / (d4 - d3 + (d5 - d6));
          return target.copy(b).addScaledVector(_vbc, w);
        }
        const denom = 1 / (va + vb + vc);
        v = vb * denom;
        w = vc * denom;
        return target.copy(a).addScaledVector(_vab, v).addScaledVector(_vac, w);
      }
      equals(triangle) {
        return triangle.a.equals(this.a) && triangle.b.equals(this.b) && triangle.c.equals(this.c);
      }
    };
    _colorKeywords = {
      "aliceblue": 15792383,
      "antiquewhite": 16444375,
      "aqua": 65535,
      "aquamarine": 8388564,
      "azure": 15794175,
      "beige": 16119260,
      "bisque": 16770244,
      "black": 0,
      "blanchedalmond": 16772045,
      "blue": 255,
      "blueviolet": 9055202,
      "brown": 10824234,
      "burlywood": 14596231,
      "cadetblue": 6266528,
      "chartreuse": 8388352,
      "chocolate": 13789470,
      "coral": 16744272,
      "cornflowerblue": 6591981,
      "cornsilk": 16775388,
      "crimson": 14423100,
      "cyan": 65535,
      "darkblue": 139,
      "darkcyan": 35723,
      "darkgoldenrod": 12092939,
      "darkgray": 11119017,
      "darkgreen": 25600,
      "darkgrey": 11119017,
      "darkkhaki": 12433259,
      "darkmagenta": 9109643,
      "darkolivegreen": 5597999,
      "darkorange": 16747520,
      "darkorchid": 10040012,
      "darkred": 9109504,
      "darksalmon": 15308410,
      "darkseagreen": 9419919,
      "darkslateblue": 4734347,
      "darkslategray": 3100495,
      "darkslategrey": 3100495,
      "darkturquoise": 52945,
      "darkviolet": 9699539,
      "deeppink": 16716947,
      "deepskyblue": 49151,
      "dimgray": 6908265,
      "dimgrey": 6908265,
      "dodgerblue": 2003199,
      "firebrick": 11674146,
      "floralwhite": 16775920,
      "forestgreen": 2263842,
      "fuchsia": 16711935,
      "gainsboro": 14474460,
      "ghostwhite": 16316671,
      "gold": 16766720,
      "goldenrod": 14329120,
      "gray": 8421504,
      "green": 32768,
      "greenyellow": 11403055,
      "grey": 8421504,
      "honeydew": 15794160,
      "hotpink": 16738740,
      "indianred": 13458524,
      "indigo": 4915330,
      "ivory": 16777200,
      "khaki": 15787660,
      "lavender": 15132410,
      "lavenderblush": 16773365,
      "lawngreen": 8190976,
      "lemonchiffon": 16775885,
      "lightblue": 11393254,
      "lightcoral": 15761536,
      "lightcyan": 14745599,
      "lightgoldenrodyellow": 16448210,
      "lightgray": 13882323,
      "lightgreen": 9498256,
      "lightgrey": 13882323,
      "lightpink": 16758465,
      "lightsalmon": 16752762,
      "lightseagreen": 2142890,
      "lightskyblue": 8900346,
      "lightslategray": 7833753,
      "lightslategrey": 7833753,
      "lightsteelblue": 11584734,
      "lightyellow": 16777184,
      "lime": 65280,
      "limegreen": 3329330,
      "linen": 16445670,
      "magenta": 16711935,
      "maroon": 8388608,
      "mediumaquamarine": 6737322,
      "mediumblue": 205,
      "mediumorchid": 12211667,
      "mediumpurple": 9662683,
      "mediumseagreen": 3978097,
      "mediumslateblue": 8087790,
      "mediumspringgreen": 64154,
      "mediumturquoise": 4772300,
      "mediumvioletred": 13047173,
      "midnightblue": 1644912,
      "mintcream": 16121850,
      "mistyrose": 16770273,
      "moccasin": 16770229,
      "navajowhite": 16768685,
      "navy": 128,
      "oldlace": 16643558,
      "olive": 8421376,
      "olivedrab": 7048739,
      "orange": 16753920,
      "orangered": 16729344,
      "orchid": 14315734,
      "palegoldenrod": 15657130,
      "palegreen": 10025880,
      "paleturquoise": 11529966,
      "palevioletred": 14381203,
      "papayawhip": 16773077,
      "peachpuff": 16767673,
      "peru": 13468991,
      "pink": 16761035,
      "plum": 14524637,
      "powderblue": 11591910,
      "purple": 8388736,
      "rebeccapurple": 6697881,
      "red": 16711680,
      "rosybrown": 12357519,
      "royalblue": 4286945,
      "saddlebrown": 9127187,
      "salmon": 16416882,
      "sandybrown": 16032864,
      "seagreen": 3050327,
      "seashell": 16774638,
      "sienna": 10506797,
      "silver": 12632256,
      "skyblue": 8900331,
      "slateblue": 6970061,
      "slategray": 7372944,
      "slategrey": 7372944,
      "snow": 16775930,
      "springgreen": 65407,
      "steelblue": 4620980,
      "tan": 13808780,
      "teal": 32896,
      "thistle": 14204888,
      "tomato": 16737095,
      "turquoise": 4251856,
      "violet": 15631086,
      "wheat": 16113331,
      "white": 16777215,
      "whitesmoke": 16119285,
      "yellow": 16776960,
      "yellowgreen": 10145074
    };
    _hslA = { h: 0, s: 0, l: 0 };
    _hslB = { h: 0, s: 0, l: 0 };
    Color = class {
      constructor(r, g, b) {
        this.isColor = true;
        this.r = 1;
        this.g = 1;
        this.b = 1;
        return this.set(r, g, b);
      }
      set(r, g, b) {
        if (g === void 0 && b === void 0) {
          const value = r;
          if (value && value.isColor) {
            this.copy(value);
          } else if (typeof value === "number") {
            this.setHex(value);
          } else if (typeof value === "string") {
            this.setStyle(value);
          }
        } else {
          this.setRGB(r, g, b);
        }
        return this;
      }
      setScalar(scalar) {
        this.r = scalar;
        this.g = scalar;
        this.b = scalar;
        return this;
      }
      setHex(hex, colorSpace = SRGBColorSpace) {
        hex = Math.floor(hex);
        this.r = (hex >> 16 & 255) / 255;
        this.g = (hex >> 8 & 255) / 255;
        this.b = (hex & 255) / 255;
        ColorManagement.toWorkingColorSpace(this, colorSpace);
        return this;
      }
      setRGB(r, g, b, colorSpace = ColorManagement.workingColorSpace) {
        this.r = r;
        this.g = g;
        this.b = b;
        ColorManagement.toWorkingColorSpace(this, colorSpace);
        return this;
      }
      setHSL(h, s, l, colorSpace = ColorManagement.workingColorSpace) {
        h = euclideanModulo(h, 1);
        s = clamp(s, 0, 1);
        l = clamp(l, 0, 1);
        if (s === 0) {
          this.r = this.g = this.b = l;
        } else {
          const p = l <= 0.5 ? l * (1 + s) : l + s - l * s;
          const q = 2 * l - p;
          this.r = hue2rgb(q, p, h + 1 / 3);
          this.g = hue2rgb(q, p, h);
          this.b = hue2rgb(q, p, h - 1 / 3);
        }
        ColorManagement.toWorkingColorSpace(this, colorSpace);
        return this;
      }
      setStyle(style, colorSpace = SRGBColorSpace) {
        function handleAlpha(string) {
          if (string === void 0) return;
          if (parseFloat(string) < 1) {
            console.warn("THREE.Color: Alpha component of " + style + " will be ignored.");
          }
        }
        let m;
        if (m = /^(\w+)\(([^\)]*)\)/.exec(style)) {
          let color;
          const name = m[1];
          const components = m[2];
          switch (name) {
            case "rgb":
            case "rgba":
              if (color = /^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(components)) {
                handleAlpha(color[4]);
                return this.setRGB(
                  Math.min(255, parseInt(color[1], 10)) / 255,
                  Math.min(255, parseInt(color[2], 10)) / 255,
                  Math.min(255, parseInt(color[3], 10)) / 255,
                  colorSpace
                );
              }
              if (color = /^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(components)) {
                handleAlpha(color[4]);
                return this.setRGB(
                  Math.min(100, parseInt(color[1], 10)) / 100,
                  Math.min(100, parseInt(color[2], 10)) / 100,
                  Math.min(100, parseInt(color[3], 10)) / 100,
                  colorSpace
                );
              }
              break;
            case "hsl":
            case "hsla":
              if (color = /^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(components)) {
                handleAlpha(color[4]);
                return this.setHSL(
                  parseFloat(color[1]) / 360,
                  parseFloat(color[2]) / 100,
                  parseFloat(color[3]) / 100,
                  colorSpace
                );
              }
              break;
            default:
              console.warn("THREE.Color: Unknown color model " + style);
          }
        } else if (m = /^\#([A-Fa-f\d]+)$/.exec(style)) {
          const hex = m[1];
          const size = hex.length;
          if (size === 3) {
            return this.setRGB(
              parseInt(hex.charAt(0), 16) / 15,
              parseInt(hex.charAt(1), 16) / 15,
              parseInt(hex.charAt(2), 16) / 15,
              colorSpace
            );
          } else if (size === 6) {
            return this.setHex(parseInt(hex, 16), colorSpace);
          } else {
            console.warn("THREE.Color: Invalid hex color " + style);
          }
        } else if (style && style.length > 0) {
          return this.setColorName(style, colorSpace);
        }
        return this;
      }
      setColorName(style, colorSpace = SRGBColorSpace) {
        const hex = _colorKeywords[style.toLowerCase()];
        if (hex !== void 0) {
          this.setHex(hex, colorSpace);
        } else {
          console.warn("THREE.Color: Unknown color " + style);
        }
        return this;
      }
      clone() {
        return new this.constructor(this.r, this.g, this.b);
      }
      copy(color) {
        this.r = color.r;
        this.g = color.g;
        this.b = color.b;
        return this;
      }
      copySRGBToLinear(color) {
        this.r = SRGBToLinear(color.r);
        this.g = SRGBToLinear(color.g);
        this.b = SRGBToLinear(color.b);
        return this;
      }
      copyLinearToSRGB(color) {
        this.r = LinearToSRGB(color.r);
        this.g = LinearToSRGB(color.g);
        this.b = LinearToSRGB(color.b);
        return this;
      }
      convertSRGBToLinear() {
        this.copySRGBToLinear(this);
        return this;
      }
      convertLinearToSRGB() {
        this.copyLinearToSRGB(this);
        return this;
      }
      getHex(colorSpace = SRGBColorSpace) {
        ColorManagement.fromWorkingColorSpace(_color.copy(this), colorSpace);
        return Math.round(clamp(_color.r * 255, 0, 255)) * 65536 + Math.round(clamp(_color.g * 255, 0, 255)) * 256 + Math.round(clamp(_color.b * 255, 0, 255));
      }
      getHexString(colorSpace = SRGBColorSpace) {
        return ("000000" + this.getHex(colorSpace).toString(16)).slice(-6);
      }
      getHSL(target, colorSpace = ColorManagement.workingColorSpace) {
        ColorManagement.fromWorkingColorSpace(_color.copy(this), colorSpace);
        const r = _color.r, g = _color.g, b = _color.b;
        const max = Math.max(r, g, b);
        const min = Math.min(r, g, b);
        let hue, saturation;
        const lightness = (min + max) / 2;
        if (min === max) {
          hue = 0;
          saturation = 0;
        } else {
          const delta = max - min;
          saturation = lightness <= 0.5 ? delta / (max + min) : delta / (2 - max - min);
          switch (max) {
            case r:
              hue = (g - b) / delta + (g < b ? 6 : 0);
              break;
            case g:
              hue = (b - r) / delta + 2;
              break;
            case b:
              hue = (r - g) / delta + 4;
              break;
          }
          hue /= 6;
        }
        target.h = hue;
        target.s = saturation;
        target.l = lightness;
        return target;
      }
      getRGB(target, colorSpace = ColorManagement.workingColorSpace) {
        ColorManagement.fromWorkingColorSpace(_color.copy(this), colorSpace);
        target.r = _color.r;
        target.g = _color.g;
        target.b = _color.b;
        return target;
      }
      getStyle(colorSpace = SRGBColorSpace) {
        ColorManagement.fromWorkingColorSpace(_color.copy(this), colorSpace);
        const r = _color.r, g = _color.g, b = _color.b;
        if (colorSpace !== SRGBColorSpace) {
          return `color(${colorSpace} ${r.toFixed(3)} ${g.toFixed(3)} ${b.toFixed(3)})`;
        }
        return `rgb(${Math.round(r * 255)},${Math.round(g * 255)},${Math.round(b * 255)})`;
      }
      offsetHSL(h, s, l) {
        this.getHSL(_hslA);
        return this.setHSL(_hslA.h + h, _hslA.s + s, _hslA.l + l);
      }
      add(color) {
        this.r += color.r;
        this.g += color.g;
        this.b += color.b;
        return this;
      }
      addColors(color1, color2) {
        this.r = color1.r + color2.r;
        this.g = color1.g + color2.g;
        this.b = color1.b + color2.b;
        return this;
      }
      addScalar(s) {
        this.r += s;
        this.g += s;
        this.b += s;
        return this;
      }
      sub(color) {
        this.r = Math.max(0, this.r - color.r);
        this.g = Math.max(0, this.g - color.g);
        this.b = Math.max(0, this.b - color.b);
        return this;
      }
      multiply(color) {
        this.r *= color.r;
        this.g *= color.g;
        this.b *= color.b;
        return this;
      }
      multiplyScalar(s) {
        this.r *= s;
        this.g *= s;
        this.b *= s;
        return this;
      }
      lerp(color, alpha) {
        this.r += (color.r - this.r) * alpha;
        this.g += (color.g - this.g) * alpha;
        this.b += (color.b - this.b) * alpha;
        return this;
      }
      lerpColors(color1, color2, alpha) {
        this.r = color1.r + (color2.r - color1.r) * alpha;
        this.g = color1.g + (color2.g - color1.g) * alpha;
        this.b = color1.b + (color2.b - color1.b) * alpha;
        return this;
      }
      lerpHSL(color, alpha) {
        this.getHSL(_hslA);
        color.getHSL(_hslB);
        const h = lerp(_hslA.h, _hslB.h, alpha);
        const s = lerp(_hslA.s, _hslB.s, alpha);
        const l = lerp(_hslA.l, _hslB.l, alpha);
        this.setHSL(h, s, l);
        return this;
      }
      setFromVector3(v) {
        this.r = v.x;
        this.g = v.y;
        this.b = v.z;
        return this;
      }
      applyMatrix3(m) {
        const r = this.r, g = this.g, b = this.b;
        const e = m.elements;
        this.r = e[0] * r + e[3] * g + e[6] * b;
        this.g = e[1] * r + e[4] * g + e[7] * b;
        this.b = e[2] * r + e[5] * g + e[8] * b;
        return this;
      }
      equals(c) {
        return c.r === this.r && c.g === this.g && c.b === this.b;
      }
      fromArray(array, offset = 0) {
        this.r = array[offset];
        this.g = array[offset + 1];
        this.b = array[offset + 2];
        return this;
      }
      toArray(array = [], offset = 0) {
        array[offset] = this.r;
        array[offset + 1] = this.g;
        array[offset + 2] = this.b;
        return array;
      }
      fromBufferAttribute(attribute, index) {
        this.r = attribute.getX(index);
        this.g = attribute.getY(index);
        this.b = attribute.getZ(index);
        return this;
      }
      toJSON() {
        return this.getHex();
      }
      *[Symbol.iterator]() {
        yield this.r;
        yield this.g;
        yield this.b;
      }
    };
    _color = /* @__PURE__ */ new Color();
    Color.NAMES = _colorKeywords;
    _materialId = 0;
    Material = class extends EventDispatcher {
      static get type() {
        return "Material";
      }
      get type() {
        return this.constructor.type;
      }
      set type(_value) {
      }
      constructor() {
        super();
        this.isMaterial = true;
        Object.defineProperty(this, "id", { value: _materialId++ });
        this.uuid = generateUUID();
        this.name = "";
        this.blending = NormalBlending;
        this.side = FrontSide;
        this.vertexColors = false;
        this.opacity = 1;
        this.transparent = false;
        this.alphaHash = false;
        this.blendSrc = SrcAlphaFactor;
        this.blendDst = OneMinusSrcAlphaFactor;
        this.blendEquation = AddEquation;
        this.blendSrcAlpha = null;
        this.blendDstAlpha = null;
        this.blendEquationAlpha = null;
        this.blendColor = new Color(0, 0, 0);
        this.blendAlpha = 0;
        this.depthFunc = LessEqualDepth;
        this.depthTest = true;
        this.depthWrite = true;
        this.stencilWriteMask = 255;
        this.stencilFunc = AlwaysStencilFunc;
        this.stencilRef = 0;
        this.stencilFuncMask = 255;
        this.stencilFail = KeepStencilOp;
        this.stencilZFail = KeepStencilOp;
        this.stencilZPass = KeepStencilOp;
        this.stencilWrite = false;
        this.clippingPlanes = null;
        this.clipIntersection = false;
        this.clipShadows = false;
        this.shadowSide = null;
        this.colorWrite = true;
        this.precision = null;
        this.polygonOffset = false;
        this.polygonOffsetFactor = 0;
        this.polygonOffsetUnits = 0;
        this.dithering = false;
        this.alphaToCoverage = false;
        this.premultipliedAlpha = false;
        this.forceSinglePass = false;
        this.visible = true;
        this.toneMapped = true;
        this.userData = {};
        this.version = 0;
        this._alphaTest = 0;
      }
      get alphaTest() {
        return this._alphaTest;
      }
      set alphaTest(value) {
        if (this._alphaTest > 0 !== value > 0) {
          this.version++;
        }
        this._alphaTest = value;
      }
      // onBeforeRender and onBeforeCompile only supported in WebGLRenderer
      onBeforeRender() {
      }
      onBeforeCompile() {
      }
      customProgramCacheKey() {
        return this.onBeforeCompile.toString();
      }
      setValues(values) {
        if (values === void 0) return;
        for (const key in values) {
          const newValue = values[key];
          if (newValue === void 0) {
            console.warn(`THREE.Material: parameter '${key}' has value of undefined.`);
            continue;
          }
          const currentValue = this[key];
          if (currentValue === void 0) {
            console.warn(`THREE.Material: '${key}' is not a property of THREE.${this.type}.`);
            continue;
          }
          if (currentValue && currentValue.isColor) {
            currentValue.set(newValue);
          } else if (currentValue && currentValue.isVector3 && (newValue && newValue.isVector3)) {
            currentValue.copy(newValue);
          } else {
            this[key] = newValue;
          }
        }
      }
      toJSON(meta) {
        const isRootObject = meta === void 0 || typeof meta === "string";
        if (isRootObject) {
          meta = {
            textures: {},
            images: {}
          };
        }
        const data = {
          metadata: {
            version: 4.6,
            type: "Material",
            generator: "Material.toJSON"
          }
        };
        data.uuid = this.uuid;
        data.type = this.type;
        if (this.name !== "") data.name = this.name;
        if (this.color && this.color.isColor) data.color = this.color.getHex();
        if (this.roughness !== void 0) data.roughness = this.roughness;
        if (this.metalness !== void 0) data.metalness = this.metalness;
        if (this.sheen !== void 0) data.sheen = this.sheen;
        if (this.sheenColor && this.sheenColor.isColor) data.sheenColor = this.sheenColor.getHex();
        if (this.sheenRoughness !== void 0) data.sheenRoughness = this.sheenRoughness;
        if (this.emissive && this.emissive.isColor) data.emissive = this.emissive.getHex();
        if (this.emissiveIntensity !== void 0 && this.emissiveIntensity !== 1) data.emissiveIntensity = this.emissiveIntensity;
        if (this.specular && this.specular.isColor) data.specular = this.specular.getHex();
        if (this.specularIntensity !== void 0) data.specularIntensity = this.specularIntensity;
        if (this.specularColor && this.specularColor.isColor) data.specularColor = this.specularColor.getHex();
        if (this.shininess !== void 0) data.shininess = this.shininess;
        if (this.clearcoat !== void 0) data.clearcoat = this.clearcoat;
        if (this.clearcoatRoughness !== void 0) data.clearcoatRoughness = this.clearcoatRoughness;
        if (this.clearcoatMap && this.clearcoatMap.isTexture) {
          data.clearcoatMap = this.clearcoatMap.toJSON(meta).uuid;
        }
        if (this.clearcoatRoughnessMap && this.clearcoatRoughnessMap.isTexture) {
          data.clearcoatRoughnessMap = this.clearcoatRoughnessMap.toJSON(meta).uuid;
        }
        if (this.clearcoatNormalMap && this.clearcoatNormalMap.isTexture) {
          data.clearcoatNormalMap = this.clearcoatNormalMap.toJSON(meta).uuid;
          data.clearcoatNormalScale = this.clearcoatNormalScale.toArray();
        }
        if (this.dispersion !== void 0) data.dispersion = this.dispersion;
        if (this.iridescence !== void 0) data.iridescence = this.iridescence;
        if (this.iridescenceIOR !== void 0) data.iridescenceIOR = this.iridescenceIOR;
        if (this.iridescenceThicknessRange !== void 0) data.iridescenceThicknessRange = this.iridescenceThicknessRange;
        if (this.iridescenceMap && this.iridescenceMap.isTexture) {
          data.iridescenceMap = this.iridescenceMap.toJSON(meta).uuid;
        }
        if (this.iridescenceThicknessMap && this.iridescenceThicknessMap.isTexture) {
          data.iridescenceThicknessMap = this.iridescenceThicknessMap.toJSON(meta).uuid;
        }
        if (this.anisotropy !== void 0) data.anisotropy = this.anisotropy;
        if (this.anisotropyRotation !== void 0) data.anisotropyRotation = this.anisotropyRotation;
        if (this.anisotropyMap && this.anisotropyMap.isTexture) {
          data.anisotropyMap = this.anisotropyMap.toJSON(meta).uuid;
        }
        if (this.map && this.map.isTexture) data.map = this.map.toJSON(meta).uuid;
        if (this.matcap && this.matcap.isTexture) data.matcap = this.matcap.toJSON(meta).uuid;
        if (this.alphaMap && this.alphaMap.isTexture) data.alphaMap = this.alphaMap.toJSON(meta).uuid;
        if (this.lightMap && this.lightMap.isTexture) {
          data.lightMap = this.lightMap.toJSON(meta).uuid;
          data.lightMapIntensity = this.lightMapIntensity;
        }
        if (this.aoMap && this.aoMap.isTexture) {
          data.aoMap = this.aoMap.toJSON(meta).uuid;
          data.aoMapIntensity = this.aoMapIntensity;
        }
        if (this.bumpMap && this.bumpMap.isTexture) {
          data.bumpMap = this.bumpMap.toJSON(meta).uuid;
          data.bumpScale = this.bumpScale;
        }
        if (this.normalMap && this.normalMap.isTexture) {
          data.normalMap = this.normalMap.toJSON(meta).uuid;
          data.normalMapType = this.normalMapType;
          data.normalScale = this.normalScale.toArray();
        }
        if (this.displacementMap && this.displacementMap.isTexture) {
          data.displacementMap = this.displacementMap.toJSON(meta).uuid;
          data.displacementScale = this.displacementScale;
          data.displacementBias = this.displacementBias;
        }
        if (this.roughnessMap && this.roughnessMap.isTexture) data.roughnessMap = this.roughnessMap.toJSON(meta).uuid;
        if (this.metalnessMap && this.metalnessMap.isTexture) data.metalnessMap = this.metalnessMap.toJSON(meta).uuid;
        if (this.emissiveMap && this.emissiveMap.isTexture) data.emissiveMap = this.emissiveMap.toJSON(meta).uuid;
        if (this.specularMap && this.specularMap.isTexture) data.specularMap = this.specularMap.toJSON(meta).uuid;
        if (this.specularIntensityMap && this.specularIntensityMap.isTexture) data.specularIntensityMap = this.specularIntensityMap.toJSON(meta).uuid;
        if (this.specularColorMap && this.specularColorMap.isTexture) data.specularColorMap = this.specularColorMap.toJSON(meta).uuid;
        if (this.envMap && this.envMap.isTexture) {
          data.envMap = this.envMap.toJSON(meta).uuid;
          if (this.combine !== void 0) data.combine = this.combine;
        }
        if (this.envMapRotation !== void 0) data.envMapRotation = this.envMapRotation.toArray();
        if (this.envMapIntensity !== void 0) data.envMapIntensity = this.envMapIntensity;
        if (this.reflectivity !== void 0) data.reflectivity = this.reflectivity;
        if (this.refractionRatio !== void 0) data.refractionRatio = this.refractionRatio;
        if (this.gradientMap && this.gradientMap.isTexture) {
          data.gradientMap = this.gradientMap.toJSON(meta).uuid;
        }
        if (this.transmission !== void 0) data.transmission = this.transmission;
        if (this.transmissionMap && this.transmissionMap.isTexture) data.transmissionMap = this.transmissionMap.toJSON(meta).uuid;
        if (this.thickness !== void 0) data.thickness = this.thickness;
        if (this.thicknessMap && this.thicknessMap.isTexture) data.thicknessMap = this.thicknessMap.toJSON(meta).uuid;
        if (this.attenuationDistance !== void 0 && this.attenuationDistance !== Infinity) data.attenuationDistance = this.attenuationDistance;
        if (this.attenuationColor !== void 0) data.attenuationColor = this.attenuationColor.getHex();
        if (this.size !== void 0) data.size = this.size;
        if (this.shadowSide !== null) data.shadowSide = this.shadowSide;
        if (this.sizeAttenuation !== void 0) data.sizeAttenuation = this.sizeAttenuation;
        if (this.blending !== NormalBlending) data.blending = this.blending;
        if (this.side !== FrontSide) data.side = this.side;
        if (this.vertexColors === true) data.vertexColors = true;
        if (this.opacity < 1) data.opacity = this.opacity;
        if (this.transparent === true) data.transparent = true;
        if (this.blendSrc !== SrcAlphaFactor) data.blendSrc = this.blendSrc;
        if (this.blendDst !== OneMinusSrcAlphaFactor) data.blendDst = this.blendDst;
        if (this.blendEquation !== AddEquation) data.blendEquation = this.blendEquation;
        if (this.blendSrcAlpha !== null) data.blendSrcAlpha = this.blendSrcAlpha;
        if (this.blendDstAlpha !== null) data.blendDstAlpha = this.blendDstAlpha;
        if (this.blendEquationAlpha !== null) data.blendEquationAlpha = this.blendEquationAlpha;
        if (this.blendColor && this.blendColor.isColor) data.blendColor = this.blendColor.getHex();
        if (this.blendAlpha !== 0) data.blendAlpha = this.blendAlpha;
        if (this.depthFunc !== LessEqualDepth) data.depthFunc = this.depthFunc;
        if (this.depthTest === false) data.depthTest = this.depthTest;
        if (this.depthWrite === false) data.depthWrite = this.depthWrite;
        if (this.colorWrite === false) data.colorWrite = this.colorWrite;
        if (this.stencilWriteMask !== 255) data.stencilWriteMask = this.stencilWriteMask;
        if (this.stencilFunc !== AlwaysStencilFunc) data.stencilFunc = this.stencilFunc;
        if (this.stencilRef !== 0) data.stencilRef = this.stencilRef;
        if (this.stencilFuncMask !== 255) data.stencilFuncMask = this.stencilFuncMask;
        if (this.stencilFail !== KeepStencilOp) data.stencilFail = this.stencilFail;
        if (this.stencilZFail !== KeepStencilOp) data.stencilZFail = this.stencilZFail;
        if (this.stencilZPass !== KeepStencilOp) data.stencilZPass = this.stencilZPass;
        if (this.stencilWrite === true) data.stencilWrite = this.stencilWrite;
        if (this.rotation !== void 0 && this.rotation !== 0) data.rotation = this.rotation;
        if (this.polygonOffset === true) data.polygonOffset = true;
        if (this.polygonOffsetFactor !== 0) data.polygonOffsetFactor = this.polygonOffsetFactor;
        if (this.polygonOffsetUnits !== 0) data.polygonOffsetUnits = this.polygonOffsetUnits;
        if (this.linewidth !== void 0 && this.linewidth !== 1) data.linewidth = this.linewidth;
        if (this.dashSize !== void 0) data.dashSize = this.dashSize;
        if (this.gapSize !== void 0) data.gapSize = this.gapSize;
        if (this.scale !== void 0) data.scale = this.scale;
        if (this.dithering === true) data.dithering = true;
        if (this.alphaTest > 0) data.alphaTest = this.alphaTest;
        if (this.alphaHash === true) data.alphaHash = true;
        if (this.alphaToCoverage === true) data.alphaToCoverage = true;
        if (this.premultipliedAlpha === true) data.premultipliedAlpha = true;
        if (this.forceSinglePass === true) data.forceSinglePass = true;
        if (this.wireframe === true) data.wireframe = true;
        if (this.wireframeLinewidth > 1) data.wireframeLinewidth = this.wireframeLinewidth;
        if (this.wireframeLinecap !== "round") data.wireframeLinecap = this.wireframeLinecap;
        if (this.wireframeLinejoin !== "round") data.wireframeLinejoin = this.wireframeLinejoin;
        if (this.flatShading === true) data.flatShading = true;
        if (this.visible === false) data.visible = false;
        if (this.toneMapped === false) data.toneMapped = false;
        if (this.fog === false) data.fog = false;
        if (Object.keys(this.userData).length > 0) data.userData = this.userData;
        function extractFromCache(cache2) {
          const values = [];
          for (const key in cache2) {
            const data2 = cache2[key];
            delete data2.metadata;
            values.push(data2);
          }
          return values;
        }
        if (isRootObject) {
          const textures = extractFromCache(meta.textures);
          const images = extractFromCache(meta.images);
          if (textures.length > 0) data.textures = textures;
          if (images.length > 0) data.images = images;
        }
        return data;
      }
      clone() {
        return new this.constructor().copy(this);
      }
      copy(source) {
        this.name = source.name;
        this.blending = source.blending;
        this.side = source.side;
        this.vertexColors = source.vertexColors;
        this.opacity = source.opacity;
        this.transparent = source.transparent;
        this.blendSrc = source.blendSrc;
        this.blendDst = source.blendDst;
        this.blendEquation = source.blendEquation;
        this.blendSrcAlpha = source.blendSrcAlpha;
        this.blendDstAlpha = source.blendDstAlpha;
        this.blendEquationAlpha = source.blendEquationAlpha;
        this.blendColor.copy(source.blendColor);
        this.blendAlpha = source.blendAlpha;
        this.depthFunc = source.depthFunc;
        this.depthTest = source.depthTest;
        this.depthWrite = source.depthWrite;
        this.stencilWriteMask = source.stencilWriteMask;
        this.stencilFunc = source.stencilFunc;
        this.stencilRef = source.stencilRef;
        this.stencilFuncMask = source.stencilFuncMask;
        this.stencilFail = source.stencilFail;
        this.stencilZFail = source.stencilZFail;
        this.stencilZPass = source.stencilZPass;
        this.stencilWrite = source.stencilWrite;
        const srcPlanes = source.clippingPlanes;
        let dstPlanes = null;
        if (srcPlanes !== null) {
          const n = srcPlanes.length;
          dstPlanes = new Array(n);
          for (let i = 0; i !== n; ++i) {
            dstPlanes[i] = srcPlanes[i].clone();
          }
        }
        this.clippingPlanes = dstPlanes;
        this.clipIntersection = source.clipIntersection;
        this.clipShadows = source.clipShadows;
        this.shadowSide = source.shadowSide;
        this.colorWrite = source.colorWrite;
        this.precision = source.precision;
        this.polygonOffset = source.polygonOffset;
        this.polygonOffsetFactor = source.polygonOffsetFactor;
        this.polygonOffsetUnits = source.polygonOffsetUnits;
        this.dithering = source.dithering;
        this.alphaTest = source.alphaTest;
        this.alphaHash = source.alphaHash;
        this.alphaToCoverage = source.alphaToCoverage;
        this.premultipliedAlpha = source.premultipliedAlpha;
        this.forceSinglePass = source.forceSinglePass;
        this.visible = source.visible;
        this.toneMapped = source.toneMapped;
        this.userData = JSON.parse(JSON.stringify(source.userData));
        return this;
      }
      dispose() {
        this.dispatchEvent({ type: "dispose" });
      }
      set needsUpdate(value) {
        if (value === true) this.version++;
      }
      onBuild() {
        console.warn("Material: onBuild() has been removed.");
      }
    };
    MeshBasicMaterial = class extends Material {
      static get type() {
        return "MeshBasicMaterial";
      }
      constructor(parameters) {
        super();
        this.isMeshBasicMaterial = true;
        this.color = new Color(16777215);
        this.map = null;
        this.lightMap = null;
        this.lightMapIntensity = 1;
        this.aoMap = null;
        this.aoMapIntensity = 1;
        this.specularMap = null;
        this.alphaMap = null;
        this.envMap = null;
        this.envMapRotation = new Euler();
        this.combine = MultiplyOperation;
        this.reflectivity = 1;
        this.refractionRatio = 0.98;
        this.wireframe = false;
        this.wireframeLinewidth = 1;
        this.wireframeLinecap = "round";
        this.wireframeLinejoin = "round";
        this.fog = true;
        this.setValues(parameters);
      }
      copy(source) {
        super.copy(source);
        this.color.copy(source.color);
        this.map = source.map;
        this.lightMap = source.lightMap;
        this.lightMapIntensity = source.lightMapIntensity;
        this.aoMap = source.aoMap;
        this.aoMapIntensity = source.aoMapIntensity;
        this.specularMap = source.specularMap;
        this.alphaMap = source.alphaMap;
        this.envMap = source.envMap;
        this.envMapRotation.copy(source.envMapRotation);
        this.combine = source.combine;
        this.reflectivity = source.reflectivity;
        this.refractionRatio = source.refractionRatio;
        this.wireframe = source.wireframe;
        this.wireframeLinewidth = source.wireframeLinewidth;
        this.wireframeLinecap = source.wireframeLinecap;
        this.wireframeLinejoin = source.wireframeLinejoin;
        this.fog = source.fog;
        return this;
      }
    };
    _vector$9 = /* @__PURE__ */ new Vector3();
    _vector2$1 = /* @__PURE__ */ new Vector2();
    BufferAttribute = class {
      constructor(array, itemSize, normalized = false) {
        if (Array.isArray(array)) {
          throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");
        }
        this.isBufferAttribute = true;
        this.name = "";
        this.array = array;
        this.itemSize = itemSize;
        this.count = array !== void 0 ? array.length / itemSize : 0;
        this.normalized = normalized;
        this.usage = StaticDrawUsage;
        this.updateRanges = [];
        this.gpuType = FloatType;
        this.version = 0;
      }
      onUploadCallback() {
      }
      set needsUpdate(value) {
        if (value === true) this.version++;
      }
      setUsage(value) {
        this.usage = value;
        return this;
      }
      addUpdateRange(start, count) {
        this.updateRanges.push({ start, count });
      }
      clearUpdateRanges() {
        this.updateRanges.length = 0;
      }
      copy(source) {
        this.name = source.name;
        this.array = new source.array.constructor(source.array);
        this.itemSize = source.itemSize;
        this.count = source.count;
        this.normalized = source.normalized;
        this.usage = source.usage;
        this.gpuType = source.gpuType;
        return this;
      }
      copyAt(index1, attribute, index2) {
        index1 *= this.itemSize;
        index2 *= attribute.itemSize;
        for (let i = 0, l = this.itemSize; i < l; i++) {
          this.array[index1 + i] = attribute.array[index2 + i];
        }
        return this;
      }
      copyArray(array) {
        this.array.set(array);
        return this;
      }
      applyMatrix3(m) {
        if (this.itemSize === 2) {
          for (let i = 0, l = this.count; i < l; i++) {
            _vector2$1.fromBufferAttribute(this, i);
            _vector2$1.applyMatrix3(m);
            this.setXY(i, _vector2$1.x, _vector2$1.y);
          }
        } else if (this.itemSize === 3) {
          for (let i = 0, l = this.count; i < l; i++) {
            _vector$9.fromBufferAttribute(this, i);
            _vector$9.applyMatrix3(m);
            this.setXYZ(i, _vector$9.x, _vector$9.y, _vector$9.z);
          }
        }
        return this;
      }
      applyMatrix4(m) {
        for (let i = 0, l = this.count; i < l; i++) {
          _vector$9.fromBufferAttribute(this, i);
          _vector$9.applyMatrix4(m);
          this.setXYZ(i, _vector$9.x, _vector$9.y, _vector$9.z);
        }
        return this;
      }
      applyNormalMatrix(m) {
        for (let i = 0, l = this.count; i < l; i++) {
          _vector$9.fromBufferAttribute(this, i);
          _vector$9.applyNormalMatrix(m);
          this.setXYZ(i, _vector$9.x, _vector$9.y, _vector$9.z);
        }
        return this;
      }
      transformDirection(m) {
        for (let i = 0, l = this.count; i < l; i++) {
          _vector$9.fromBufferAttribute(this, i);
          _vector$9.transformDirection(m);
          this.setXYZ(i, _vector$9.x, _vector$9.y, _vector$9.z);
        }
        return this;
      }
      set(value, offset = 0) {
        this.array.set(value, offset);
        return this;
      }
      getComponent(index, component) {
        let value = this.array[index * this.itemSize + component];
        if (this.normalized) value = denormalize(value, this.array);
        return value;
      }
      setComponent(index, component, value) {
        if (this.normalized) value = normalize(value, this.array);
        this.array[index * this.itemSize + component] = value;
        return this;
      }
      getX(index) {
        let x = this.array[index * this.itemSize];
        if (this.normalized) x = denormalize(x, this.array);
        return x;
      }
      setX(index, x) {
        if (this.normalized) x = normalize(x, this.array);
        this.array[index * this.itemSize] = x;
        return this;
      }
      getY(index) {
        let y = this.array[index * this.itemSize + 1];
        if (this.normalized) y = denormalize(y, this.array);
        return y;
      }
      setY(index, y) {
        if (this.normalized) y = normalize(y, this.array);
        this.array[index * this.itemSize + 1] = y;
        return this;
      }
      getZ(index) {
        let z = this.array[index * this.itemSize + 2];
        if (this.normalized) z = denormalize(z, this.array);
        return z;
      }
      setZ(index, z) {
        if (this.normalized) z = normalize(z, this.array);
        this.array[index * this.itemSize + 2] = z;
        return this;
      }
      getW(index) {
        let w = this.array[index * this.itemSize + 3];
        if (this.normalized) w = denormalize(w, this.array);
        return w;
      }
      setW(index, w) {
        if (this.normalized) w = normalize(w, this.array);
        this.array[index * this.itemSize + 3] = w;
        return this;
      }
      setXY(index, x, y) {
        index *= this.itemSize;
        if (this.normalized) {
          x = normalize(x, this.array);
          y = normalize(y, this.array);
        }
        this.array[index + 0] = x;
        this.array[index + 1] = y;
        return this;
      }
      setXYZ(index, x, y, z) {
        index *= this.itemSize;
        if (this.normalized) {
          x = normalize(x, this.array);
          y = normalize(y, this.array);
          z = normalize(z, this.array);
        }
        this.array[index + 0] = x;
        this.array[index + 1] = y;
        this.array[index + 2] = z;
        return this;
      }
      setXYZW(index, x, y, z, w) {
        index *= this.itemSize;
        if (this.normalized) {
          x = normalize(x, this.array);
          y = normalize(y, this.array);
          z = normalize(z, this.array);
          w = normalize(w, this.array);
        }
        this.array[index + 0] = x;
        this.array[index + 1] = y;
        this.array[index + 2] = z;
        this.array[index + 3] = w;
        return this;
      }
      onUpload(callback) {
        this.onUploadCallback = callback;
        return this;
      }
      clone() {
        return new this.constructor(this.array, this.itemSize).copy(this);
      }
      toJSON() {
        const data = {
          itemSize: this.itemSize,
          type: this.array.constructor.name,
          array: Array.from(this.array),
          normalized: this.normalized
        };
        if (this.name !== "") data.name = this.name;
        if (this.usage !== StaticDrawUsage) data.usage = this.usage;
        return data;
      }
    };
    Uint16BufferAttribute = class extends BufferAttribute {
      constructor(array, itemSize, normalized) {
        super(new Uint16Array(array), itemSize, normalized);
      }
    };
    Uint32BufferAttribute = class extends BufferAttribute {
      constructor(array, itemSize, normalized) {
        super(new Uint32Array(array), itemSize, normalized);
      }
    };
    Float32BufferAttribute = class extends BufferAttribute {
      constructor(array, itemSize, normalized) {
        super(new Float32Array(array), itemSize, normalized);
      }
    };
    _id$2 = 0;
    _m1$2 = /* @__PURE__ */ new Matrix4();
    _obj = /* @__PURE__ */ new Object3D();
    _offset = /* @__PURE__ */ new Vector3();
    _box$2 = /* @__PURE__ */ new Box3();
    _boxMorphTargets = /* @__PURE__ */ new Box3();
    _vector$8 = /* @__PURE__ */ new Vector3();
    BufferGeometry = class _BufferGeometry extends EventDispatcher {
      constructor() {
        super();
        this.isBufferGeometry = true;
        Object.defineProperty(this, "id", { value: _id$2++ });
        this.uuid = generateUUID();
        this.name = "";
        this.type = "BufferGeometry";
        this.index = null;
        this.indirect = null;
        this.attributes = {};
        this.morphAttributes = {};
        this.morphTargetsRelative = false;
        this.groups = [];
        this.boundingBox = null;
        this.boundingSphere = null;
        this.drawRange = { start: 0, count: Infinity };
        this.userData = {};
      }
      getIndex() {
        return this.index;
      }
      setIndex(index) {
        if (Array.isArray(index)) {
          this.index = new (arrayNeedsUint32(index) ? Uint32BufferAttribute : Uint16BufferAttribute)(index, 1);
        } else {
          this.index = index;
        }
        return this;
      }
      setIndirect(indirect) {
        this.indirect = indirect;
        return this;
      }
      getIndirect() {
        return this.indirect;
      }
      getAttribute(name) {
        return this.attributes[name];
      }
      setAttribute(name, attribute) {
        this.attributes[name] = attribute;
        return this;
      }
      deleteAttribute(name) {
        delete this.attributes[name];
        return this;
      }
      hasAttribute(name) {
        return this.attributes[name] !== void 0;
      }
      addGroup(start, count, materialIndex = 0) {
        this.groups.push({
          start,
          count,
          materialIndex
        });
      }
      clearGroups() {
        this.groups = [];
      }
      setDrawRange(start, count) {
        this.drawRange.start = start;
        this.drawRange.count = count;
      }
      applyMatrix4(matrix) {
        const position = this.attributes.position;
        if (position !== void 0) {
          position.applyMatrix4(matrix);
          position.needsUpdate = true;
        }
        const normal = this.attributes.normal;
        if (normal !== void 0) {
          const normalMatrix = new Matrix3().getNormalMatrix(matrix);
          normal.applyNormalMatrix(normalMatrix);
          normal.needsUpdate = true;
        }
        const tangent = this.attributes.tangent;
        if (tangent !== void 0) {
          tangent.transformDirection(matrix);
          tangent.needsUpdate = true;
        }
        if (this.boundingBox !== null) {
          this.computeBoundingBox();
        }
        if (this.boundingSphere !== null) {
          this.computeBoundingSphere();
        }
        return this;
      }
      applyQuaternion(q) {
        _m1$2.makeRotationFromQuaternion(q);
        this.applyMatrix4(_m1$2);
        return this;
      }
      rotateX(angle) {
        _m1$2.makeRotationX(angle);
        this.applyMatrix4(_m1$2);
        return this;
      }
      rotateY(angle) {
        _m1$2.makeRotationY(angle);
        this.applyMatrix4(_m1$2);
        return this;
      }
      rotateZ(angle) {
        _m1$2.makeRotationZ(angle);
        this.applyMatrix4(_m1$2);
        return this;
      }
      translate(x, y, z) {
        _m1$2.makeTranslation(x, y, z);
        this.applyMatrix4(_m1$2);
        return this;
      }
      scale(x, y, z) {
        _m1$2.makeScale(x, y, z);
        this.applyMatrix4(_m1$2);
        return this;
      }
      lookAt(vector) {
        _obj.lookAt(vector);
        _obj.updateMatrix();
        this.applyMatrix4(_obj.matrix);
        return this;
      }
      center() {
        this.computeBoundingBox();
        this.boundingBox.getCenter(_offset).negate();
        this.translate(_offset.x, _offset.y, _offset.z);
        return this;
      }
      setFromPoints(points) {
        const positionAttribute = this.getAttribute("position");
        if (positionAttribute === void 0) {
          const position = [];
          for (let i = 0, l = points.length; i < l; i++) {
            const point = points[i];
            position.push(point.x, point.y, point.z || 0);
          }
          this.setAttribute("position", new Float32BufferAttribute(position, 3));
        } else {
          for (let i = 0, l = positionAttribute.count; i < l; i++) {
            const point = points[i];
            positionAttribute.setXYZ(i, point.x, point.y, point.z || 0);
          }
          if (points.length > positionAttribute.count) {
            console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry.");
          }
          positionAttribute.needsUpdate = true;
        }
        return this;
      }
      computeBoundingBox() {
        if (this.boundingBox === null) {
          this.boundingBox = new Box3();
        }
        const position = this.attributes.position;
        const morphAttributesPosition = this.morphAttributes.position;
        if (position && position.isGLBufferAttribute) {
          console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.", this);
          this.boundingBox.set(
            new Vector3(-Infinity, -Infinity, -Infinity),
            new Vector3(Infinity, Infinity, Infinity)
          );
          return;
        }
        if (position !== void 0) {
          this.boundingBox.setFromBufferAttribute(position);
          if (morphAttributesPosition) {
            for (let i = 0, il = morphAttributesPosition.length; i < il; i++) {
              const morphAttribute = morphAttributesPosition[i];
              _box$2.setFromBufferAttribute(morphAttribute);
              if (this.morphTargetsRelative) {
                _vector$8.addVectors(this.boundingBox.min, _box$2.min);
                this.boundingBox.expandByPoint(_vector$8);
                _vector$8.addVectors(this.boundingBox.max, _box$2.max);
                this.boundingBox.expandByPoint(_vector$8);
              } else {
                this.boundingBox.expandByPoint(_box$2.min);
                this.boundingBox.expandByPoint(_box$2.max);
              }
            }
          }
        } else {
          this.boundingBox.makeEmpty();
        }
        if (isNaN(this.boundingBox.min.x) || isNaN(this.boundingBox.min.y) || isNaN(this.boundingBox.min.z)) {
          console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.', this);
        }
      }
      computeBoundingSphere() {
        if (this.boundingSphere === null) {
          this.boundingSphere = new Sphere();
        }
        const position = this.attributes.position;
        const morphAttributesPosition = this.morphAttributes.position;
        if (position && position.isGLBufferAttribute) {
          console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.", this);
          this.boundingSphere.set(new Vector3(), Infinity);
          return;
        }
        if (position) {
          const center = this.boundingSphere.center;
          _box$2.setFromBufferAttribute(position);
          if (morphAttributesPosition) {
            for (let i = 0, il = morphAttributesPosition.length; i < il; i++) {
              const morphAttribute = morphAttributesPosition[i];
              _boxMorphTargets.setFromBufferAttribute(morphAttribute);
              if (this.morphTargetsRelative) {
                _vector$8.addVectors(_box$2.min, _boxMorphTargets.min);
                _box$2.expandByPoint(_vector$8);
                _vector$8.addVectors(_box$2.max, _boxMorphTargets.max);
                _box$2.expandByPoint(_vector$8);
              } else {
                _box$2.expandByPoint(_boxMorphTargets.min);
                _box$2.expandByPoint(_boxMorphTargets.max);
              }
            }
          }
          _box$2.getCenter(center);
          let maxRadiusSq = 0;
          for (let i = 0, il = position.count; i < il; i++) {
            _vector$8.fromBufferAttribute(position, i);
            maxRadiusSq = Math.max(maxRadiusSq, center.distanceToSquared(_vector$8));
          }
          if (morphAttributesPosition) {
            for (let i = 0, il = morphAttributesPosition.length; i < il; i++) {
              const morphAttribute = morphAttributesPosition[i];
              const morphTargetsRelative = this.morphTargetsRelative;
              for (let j = 0, jl = morphAttribute.count; j < jl; j++) {
                _vector$8.fromBufferAttribute(morphAttribute, j);
                if (morphTargetsRelative) {
                  _offset.fromBufferAttribute(position, j);
                  _vector$8.add(_offset);
                }
                maxRadiusSq = Math.max(maxRadiusSq, center.distanceToSquared(_vector$8));
              }
            }
          }
          this.boundingSphere.radius = Math.sqrt(maxRadiusSq);
          if (isNaN(this.boundingSphere.radius)) {
            console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.', this);
          }
        }
      }
      computeTangents() {
        const index = this.index;
        const attributes = this.attributes;
        if (index === null || attributes.position === void 0 || attributes.normal === void 0 || attributes.uv === void 0) {
          console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");
          return;
        }
        const positionAttribute = attributes.position;
        const normalAttribute = attributes.normal;
        const uvAttribute = attributes.uv;
        if (this.hasAttribute("tangent") === false) {
          this.setAttribute("tangent", new BufferAttribute(new Float32Array(4 * positionAttribute.count), 4));
        }
        const tangentAttribute = this.getAttribute("tangent");
        const tan1 = [], tan2 = [];
        for (let i = 0; i < positionAttribute.count; i++) {
          tan1[i] = new Vector3();
          tan2[i] = new Vector3();
        }
        const vA = new Vector3(), vB = new Vector3(), vC = new Vector3(), uvA = new Vector2(), uvB = new Vector2(), uvC = new Vector2(), sdir = new Vector3(), tdir = new Vector3();
        function handleTriangle(a, b, c) {
          vA.fromBufferAttribute(positionAttribute, a);
          vB.fromBufferAttribute(positionAttribute, b);
          vC.fromBufferAttribute(positionAttribute, c);
          uvA.fromBufferAttribute(uvAttribute, a);
          uvB.fromBufferAttribute(uvAttribute, b);
          uvC.fromBufferAttribute(uvAttribute, c);
          vB.sub(vA);
          vC.sub(vA);
          uvB.sub(uvA);
          uvC.sub(uvA);
          const r = 1 / (uvB.x * uvC.y - uvC.x * uvB.y);
          if (!isFinite(r)) return;
          sdir.copy(vB).multiplyScalar(uvC.y).addScaledVector(vC, -uvB.y).multiplyScalar(r);
          tdir.copy(vC).multiplyScalar(uvB.x).addScaledVector(vB, -uvC.x).multiplyScalar(r);
          tan1[a].add(sdir);
          tan1[b].add(sdir);
          tan1[c].add(sdir);
          tan2[a].add(tdir);
          tan2[b].add(tdir);
          tan2[c].add(tdir);
        }
        let groups = this.groups;
        if (groups.length === 0) {
          groups = [{
            start: 0,
            count: index.count
          }];
        }
        for (let i = 0, il = groups.length; i < il; ++i) {
          const group = groups[i];
          const start = group.start;
          const count = group.count;
          for (let j = start, jl = start + count; j < jl; j += 3) {
            handleTriangle(
              index.getX(j + 0),
              index.getX(j + 1),
              index.getX(j + 2)
            );
          }
        }
        const tmp = new Vector3(), tmp2 = new Vector3();
        const n = new Vector3(), n2 = new Vector3();
        function handleVertex(v) {
          n.fromBufferAttribute(normalAttribute, v);
          n2.copy(n);
          const t = tan1[v];
          tmp.copy(t);
          tmp.sub(n.multiplyScalar(n.dot(t))).normalize();
          tmp2.crossVectors(n2, t);
          const test = tmp2.dot(tan2[v]);
          const w = test < 0 ? -1 : 1;
          tangentAttribute.setXYZW(v, tmp.x, tmp.y, tmp.z, w);
        }
        for (let i = 0, il = groups.length; i < il; ++i) {
          const group = groups[i];
          const start = group.start;
          const count = group.count;
          for (let j = start, jl = start + count; j < jl; j += 3) {
            handleVertex(index.getX(j + 0));
            handleVertex(index.getX(j + 1));
            handleVertex(index.getX(j + 2));
          }
        }
      }
      computeVertexNormals() {
        const index = this.index;
        const positionAttribute = this.getAttribute("position");
        if (positionAttribute !== void 0) {
          let normalAttribute = this.getAttribute("normal");
          if (normalAttribute === void 0) {
            normalAttribute = new BufferAttribute(new Float32Array(positionAttribute.count * 3), 3);
            this.setAttribute("normal", normalAttribute);
          } else {
            for (let i = 0, il = normalAttribute.count; i < il; i++) {
              normalAttribute.setXYZ(i, 0, 0, 0);
            }
          }
          const pA = new Vector3(), pB = new Vector3(), pC = new Vector3();
          const nA = new Vector3(), nB = new Vector3(), nC = new Vector3();
          const cb = new Vector3(), ab = new Vector3();
          if (index) {
            for (let i = 0, il = index.count; i < il; i += 3) {
              const vA = index.getX(i + 0);
              const vB = index.getX(i + 1);
              const vC = index.getX(i + 2);
              pA.fromBufferAttribute(positionAttribute, vA);
              pB.fromBufferAttribute(positionAttribute, vB);
              pC.fromBufferAttribute(positionAttribute, vC);
              cb.subVectors(pC, pB);
              ab.subVectors(pA, pB);
              cb.cross(ab);
              nA.fromBufferAttribute(normalAttribute, vA);
              nB.fromBufferAttribute(normalAttribute, vB);
              nC.fromBufferAttribute(normalAttribute, vC);
              nA.add(cb);
              nB.add(cb);
              nC.add(cb);
              normalAttribute.setXYZ(vA, nA.x, nA.y, nA.z);
              normalAttribute.setXYZ(vB, nB.x, nB.y, nB.z);
              normalAttribute.setXYZ(vC, nC.x, nC.y, nC.z);
            }
          } else {
            for (let i = 0, il = positionAttribute.count; i < il; i += 3) {
              pA.fromBufferAttribute(positionAttribute, i + 0);
              pB.fromBufferAttribute(positionAttribute, i + 1);
              pC.fromBufferAttribute(positionAttribute, i + 2);
              cb.subVectors(pC, pB);
              ab.subVectors(pA, pB);
              cb.cross(ab);
              normalAttribute.setXYZ(i + 0, cb.x, cb.y, cb.z);
              normalAttribute.setXYZ(i + 1, cb.x, cb.y, cb.z);
              normalAttribute.setXYZ(i + 2, cb.x, cb.y, cb.z);
            }
          }
          this.normalizeNormals();
          normalAttribute.needsUpdate = true;
        }
      }
      normalizeNormals() {
        const normals = this.attributes.normal;
        for (let i = 0, il = normals.count; i < il; i++) {
          _vector$8.fromBufferAttribute(normals, i);
          _vector$8.normalize();
          normals.setXYZ(i, _vector$8.x, _vector$8.y, _vector$8.z);
        }
      }
      toNonIndexed() {
        function convertBufferAttribute(attribute, indices2) {
          const array = attribute.array;
          const itemSize = attribute.itemSize;
          const normalized = attribute.normalized;
          const array2 = new array.constructor(indices2.length * itemSize);
          let index = 0, index2 = 0;
          for (let i = 0, l = indices2.length; i < l; i++) {
            if (attribute.isInterleavedBufferAttribute) {
              index = indices2[i] * attribute.data.stride + attribute.offset;
            } else {
              index = indices2[i] * itemSize;
            }
            for (let j = 0; j < itemSize; j++) {
              array2[index2++] = array[index++];
            }
          }
          return new BufferAttribute(array2, itemSize, normalized);
        }
        if (this.index === null) {
          console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed.");
          return this;
        }
        const geometry2 = new _BufferGeometry();
        const indices = this.index.array;
        const attributes = this.attributes;
        for (const name in attributes) {
          const attribute = attributes[name];
          const newAttribute = convertBufferAttribute(attribute, indices);
          geometry2.setAttribute(name, newAttribute);
        }
        const morphAttributes = this.morphAttributes;
        for (const name in morphAttributes) {
          const morphArray = [];
          const morphAttribute = morphAttributes[name];
          for (let i = 0, il = morphAttribute.length; i < il; i++) {
            const attribute = morphAttribute[i];
            const newAttribute = convertBufferAttribute(attribute, indices);
            morphArray.push(newAttribute);
          }
          geometry2.morphAttributes[name] = morphArray;
        }
        geometry2.morphTargetsRelative = this.morphTargetsRelative;
        const groups = this.groups;
        for (let i = 0, l = groups.length; i < l; i++) {
          const group = groups[i];
          geometry2.addGroup(group.start, group.count, group.materialIndex);
        }
        return geometry2;
      }
      toJSON() {
        const data = {
          metadata: {
            version: 4.6,
            type: "BufferGeometry",
            generator: "BufferGeometry.toJSON"
          }
        };
        data.uuid = this.uuid;
        data.type = this.type;
        if (this.name !== "") data.name = this.name;
        if (Object.keys(this.userData).length > 0) data.userData = this.userData;
        if (this.parameters !== void 0) {
          const parameters = this.parameters;
          for (const key in parameters) {
            if (parameters[key] !== void 0) data[key] = parameters[key];
          }
          return data;
        }
        data.data = { attributes: {} };
        const index = this.index;
        if (index !== null) {
          data.data.index = {
            type: index.array.constructor.name,
            array: Array.prototype.slice.call(index.array)
          };
        }
        const attributes = this.attributes;
        for (const key in attributes) {
          const attribute = attributes[key];
          data.data.attributes[key] = attribute.toJSON(data.data);
        }
        const morphAttributes = {};
        let hasMorphAttributes = false;
        for (const key in this.morphAttributes) {
          const attributeArray = this.morphAttributes[key];
          const array = [];
          for (let i = 0, il = attributeArray.length; i < il; i++) {
            const attribute = attributeArray[i];
            array.push(attribute.toJSON(data.data));
          }
          if (array.length > 0) {
            morphAttributes[key] = array;
            hasMorphAttributes = true;
          }
        }
        if (hasMorphAttributes) {
          data.data.morphAttributes = morphAttributes;
          data.data.morphTargetsRelative = this.morphTargetsRelative;
        }
        const groups = this.groups;
        if (groups.length > 0) {
          data.data.groups = JSON.parse(JSON.stringify(groups));
        }
        const boundingSphere = this.boundingSphere;
        if (boundingSphere !== null) {
          data.data.boundingSphere = {
            center: boundingSphere.center.toArray(),
            radius: boundingSphere.radius
          };
        }
        return data;
      }
      clone() {
        return new this.constructor().copy(this);
      }
      copy(source) {
        this.index = null;
        this.attributes = {};
        this.morphAttributes = {};
        this.groups = [];
        this.boundingBox = null;
        this.boundingSphere = null;
        const data = {};
        this.name = source.name;
        const index = source.index;
        if (index !== null) {
          this.setIndex(index.clone(data));
        }
        const attributes = source.attributes;
        for (const name in attributes) {
          const attribute = attributes[name];
          this.setAttribute(name, attribute.clone(data));
        }
        const morphAttributes = source.morphAttributes;
        for (const name in morphAttributes) {
          const array = [];
          const morphAttribute = morphAttributes[name];
          for (let i = 0, l = morphAttribute.length; i < l; i++) {
            array.push(morphAttribute[i].clone(data));
          }
          this.morphAttributes[name] = array;
        }
        this.morphTargetsRelative = source.morphTargetsRelative;
        const groups = source.groups;
        for (let i = 0, l = groups.length; i < l; i++) {
          const group = groups[i];
          this.addGroup(group.start, group.count, group.materialIndex);
        }
        const boundingBox = source.boundingBox;
        if (boundingBox !== null) {
          this.boundingBox = boundingBox.clone();
        }
        const boundingSphere = source.boundingSphere;
        if (boundingSphere !== null) {
          this.boundingSphere = boundingSphere.clone();
        }
        this.drawRange.start = source.drawRange.start;
        this.drawRange.count = source.drawRange.count;
        this.userData = source.userData;
        return this;
      }
      dispose() {
        this.dispatchEvent({ type: "dispose" });
      }
    };
    _inverseMatrix$3 = /* @__PURE__ */ new Matrix4();
    _ray$3 = /* @__PURE__ */ new Ray();
    _sphere$6 = /* @__PURE__ */ new Sphere();
    _sphereHitAt = /* @__PURE__ */ new Vector3();
    _vA$1 = /* @__PURE__ */ new Vector3();
    _vB$1 = /* @__PURE__ */ new Vector3();
    _vC$1 = /* @__PURE__ */ new Vector3();
    _tempA = /* @__PURE__ */ new Vector3();
    _morphA = /* @__PURE__ */ new Vector3();
    _intersectionPoint = /* @__PURE__ */ new Vector3();
    _intersectionPointWorld = /* @__PURE__ */ new Vector3();
    Mesh = class extends Object3D {
      constructor(geometry = new BufferGeometry(), material = new MeshBasicMaterial()) {
        super();
        this.isMesh = true;
        this.type = "Mesh";
        this.geometry = geometry;
        this.material = material;
        this.updateMorphTargets();
      }
      copy(source, recursive) {
        super.copy(source, recursive);
        if (source.morphTargetInfluences !== void 0) {
          this.morphTargetInfluences = source.morphTargetInfluences.slice();
        }
        if (source.morphTargetDictionary !== void 0) {
          this.morphTargetDictionary = Object.assign({}, source.morphTargetDictionary);
        }
        this.material = Array.isArray(source.material) ? source.material.slice() : source.material;
        this.geometry = source.geometry;
        return this;
      }
      updateMorphTargets() {
        const geometry = this.geometry;
        const morphAttributes = geometry.morphAttributes;
        const keys = Object.keys(morphAttributes);
        if (keys.length > 0) {
          const morphAttribute = morphAttributes[keys[0]];
          if (morphAttribute !== void 0) {
            this.morphTargetInfluences = [];
            this.morphTargetDictionary = {};
            for (let m = 0, ml = morphAttribute.length; m < ml; m++) {
              const name = morphAttribute[m].name || String(m);
              this.morphTargetInfluences.push(0);
              this.morphTargetDictionary[name] = m;
            }
          }
        }
      }
      getVertexPosition(index, target) {
        const geometry = this.geometry;
        const position = geometry.attributes.position;
        const morphPosition = geometry.morphAttributes.position;
        const morphTargetsRelative = geometry.morphTargetsRelative;
        target.fromBufferAttribute(position, index);
        const morphInfluences = this.morphTargetInfluences;
        if (morphPosition && morphInfluences) {
          _morphA.set(0, 0, 0);
          for (let i = 0, il = morphPosition.length; i < il; i++) {
            const influence = morphInfluences[i];
            const morphAttribute = morphPosition[i];
            if (influence === 0) continue;
            _tempA.fromBufferAttribute(morphAttribute, index);
            if (morphTargetsRelative) {
              _morphA.addScaledVector(_tempA, influence);
            } else {
              _morphA.addScaledVector(_tempA.sub(target), influence);
            }
          }
          target.add(_morphA);
        }
        return target;
      }
      raycast(raycaster, intersects) {
        const geometry = this.geometry;
        const material = this.material;
        const matrixWorld = this.matrixWorld;
        if (material === void 0) return;
        if (geometry.boundingSphere === null) geometry.computeBoundingSphere();
        _sphere$6.copy(geometry.boundingSphere);
        _sphere$6.applyMatrix4(matrixWorld);
        _ray$3.copy(raycaster.ray).recast(raycaster.near);
        if (_sphere$6.containsPoint(_ray$3.origin) === false) {
          if (_ray$3.intersectSphere(_sphere$6, _sphereHitAt) === null) return;
          if (_ray$3.origin.distanceToSquared(_sphereHitAt) > (raycaster.far - raycaster.near) ** 2) return;
        }
        _inverseMatrix$3.copy(matrixWorld).invert();
        _ray$3.copy(raycaster.ray).applyMatrix4(_inverseMatrix$3);
        if (geometry.boundingBox !== null) {
          if (_ray$3.intersectsBox(geometry.boundingBox) === false) return;
        }
        this._computeIntersections(raycaster, intersects, _ray$3);
      }
      _computeIntersections(raycaster, intersects, rayLocalSpace) {
        let intersection;
        const geometry = this.geometry;
        const material = this.material;
        const index = geometry.index;
        const position = geometry.attributes.position;
        const uv = geometry.attributes.uv;
        const uv1 = geometry.attributes.uv1;
        const normal = geometry.attributes.normal;
        const groups = geometry.groups;
        const drawRange = geometry.drawRange;
        if (index !== null) {
          if (Array.isArray(material)) {
            for (let i = 0, il = groups.length; i < il; i++) {
              const group = groups[i];
              const groupMaterial = material[group.materialIndex];
              const start = Math.max(group.start, drawRange.start);
              const end = Math.min(index.count, Math.min(group.start + group.count, drawRange.start + drawRange.count));
              for (let j = start, jl = end; j < jl; j += 3) {
                const a = index.getX(j);
                const b = index.getX(j + 1);
                const c = index.getX(j + 2);
                intersection = checkGeometryIntersection(this, groupMaterial, raycaster, rayLocalSpace, uv, uv1, normal, a, b, c);
                if (intersection) {
                  intersection.faceIndex = Math.floor(j / 3);
                  intersection.face.materialIndex = group.materialIndex;
                  intersects.push(intersection);
                }
              }
            }
          } else {
            const start = Math.max(0, drawRange.start);
            const end = Math.min(index.count, drawRange.start + drawRange.count);
            for (let i = start, il = end; i < il; i += 3) {
              const a = index.getX(i);
              const b = index.getX(i + 1);
              const c = index.getX(i + 2);
              intersection = checkGeometryIntersection(this, material, raycaster, rayLocalSpace, uv, uv1, normal, a, b, c);
              if (intersection) {
                intersection.faceIndex = Math.floor(i / 3);
                intersects.push(intersection);
              }
            }
          }
        } else if (position !== void 0) {
          if (Array.isArray(material)) {
            for (let i = 0, il = groups.length; i < il; i++) {
              const group = groups[i];
              const groupMaterial = material[group.materialIndex];
              const start = Math.max(group.start, drawRange.start);
              const end = Math.min(position.count, Math.min(group.start + group.count, drawRange.start + drawRange.count));
              for (let j = start, jl = end; j < jl; j += 3) {
                const a = j;
                const b = j + 1;
                const c = j + 2;
                intersection = checkGeometryIntersection(this, groupMaterial, raycaster, rayLocalSpace, uv, uv1, normal, a, b, c);
                if (intersection) {
                  intersection.faceIndex = Math.floor(j / 3);
                  intersection.face.materialIndex = group.materialIndex;
                  intersects.push(intersection);
                }
              }
            }
          } else {
            const start = Math.max(0, drawRange.start);
            const end = Math.min(position.count, drawRange.start + drawRange.count);
            for (let i = start, il = end; i < il; i += 3) {
              const a = i;
              const b = i + 1;
              const c = i + 2;
              intersection = checkGeometryIntersection(this, material, raycaster, rayLocalSpace, uv, uv1, normal, a, b, c);
              if (intersection) {
                intersection.faceIndex = Math.floor(i / 3);
                intersects.push(intersection);
              }
            }
          }
        }
      }
    };
    BoxGeometry = class _BoxGeometry extends BufferGeometry {
      constructor(width = 1, height = 1, depth = 1, widthSegments = 1, heightSegments = 1, depthSegments = 1) {
        super();
        this.type = "BoxGeometry";
        this.parameters = {
          width,
          height,
          depth,
          widthSegments,
          heightSegments,
          depthSegments
        };
        const scope = this;
        widthSegments = Math.floor(widthSegments);
        heightSegments = Math.floor(heightSegments);
        depthSegments = Math.floor(depthSegments);
        const indices = [];
        const vertices = [];
        const normals = [];
        const uvs = [];
        let numberOfVertices = 0;
        let groupStart = 0;
        buildPlane("z", "y", "x", -1, -1, depth, height, width, depthSegments, heightSegments, 0);
        buildPlane("z", "y", "x", 1, -1, depth, height, -width, depthSegments, heightSegments, 1);
        buildPlane("x", "z", "y", 1, 1, width, depth, height, widthSegments, depthSegments, 2);
        buildPlane("x", "z", "y", 1, -1, width, depth, -height, widthSegments, depthSegments, 3);
        buildPlane("x", "y", "z", 1, -1, width, height, depth, widthSegments, heightSegments, 4);
        buildPlane("x", "y", "z", -1, -1, width, height, -depth, widthSegments, heightSegments, 5);
        this.setIndex(indices);
        this.setAttribute("position", new Float32BufferAttribute(vertices, 3));
        this.setAttribute("normal", new Float32BufferAttribute(normals, 3));
        this.setAttribute("uv", new Float32BufferAttribute(uvs, 2));
        function buildPlane(u, v, w, udir, vdir, width2, height2, depth2, gridX, gridY, materialIndex) {
          const segmentWidth = width2 / gridX;
          const segmentHeight = height2 / gridY;
          const widthHalf = width2 / 2;
          const heightHalf = height2 / 2;
          const depthHalf = depth2 / 2;
          const gridX1 = gridX + 1;
          const gridY1 = gridY + 1;
          let vertexCounter = 0;
          let groupCount = 0;
          const vector = new Vector3();
          for (let iy = 0; iy < gridY1; iy++) {
            const y = iy * segmentHeight - heightHalf;
            for (let ix = 0; ix < gridX1; ix++) {
              const x = ix * segmentWidth - widthHalf;
              vector[u] = x * udir;
              vector[v] = y * vdir;
              vector[w] = depthHalf;
              vertices.push(vector.x, vector.y, vector.z);
              vector[u] = 0;
              vector[v] = 0;
              vector[w] = depth2 > 0 ? 1 : -1;
              normals.push(vector.x, vector.y, vector.z);
              uvs.push(ix / gridX);
              uvs.push(1 - iy / gridY);
              vertexCounter += 1;
            }
          }
          for (let iy = 0; iy < gridY; iy++) {
            for (let ix = 0; ix < gridX; ix++) {
              const a = numberOfVertices + ix + gridX1 * iy;
              const b = numberOfVertices + ix + gridX1 * (iy + 1);
              const c = numberOfVertices + (ix + 1) + gridX1 * (iy + 1);
              const d = numberOfVertices + (ix + 1) + gridX1 * iy;
              indices.push(a, b, d);
              indices.push(b, c, d);
              groupCount += 6;
            }
          }
          scope.addGroup(groupStart, groupCount, materialIndex);
          groupStart += groupCount;
          numberOfVertices += vertexCounter;
        }
      }
      copy(source) {
        super.copy(source);
        this.parameters = Object.assign({}, source.parameters);
        return this;
      }
      static fromJSON(data) {
        return new _BoxGeometry(data.width, data.height, data.depth, data.widthSegments, data.heightSegments, data.depthSegments);
      }
    };
    PlaneGeometry = class _PlaneGeometry extends BufferGeometry {
      constructor(width = 1, height = 1, widthSegments = 1, heightSegments = 1) {
        super();
        this.type = "PlaneGeometry";
        this.parameters = {
          width,
          height,
          widthSegments,
          heightSegments
        };
        const width_half = width / 2;
        const height_half = height / 2;
        const gridX = Math.floor(widthSegments);
        const gridY = Math.floor(heightSegments);
        const gridX1 = gridX + 1;
        const gridY1 = gridY + 1;
        const segment_width = width / gridX;
        const segment_height = height / gridY;
        const indices = [];
        const vertices = [];
        const normals = [];
        const uvs = [];
        for (let iy = 0; iy < gridY1; iy++) {
          const y = iy * segment_height - height_half;
          for (let ix = 0; ix < gridX1; ix++) {
            const x = ix * segment_width - width_half;
            vertices.push(x, -y, 0);
            normals.push(0, 0, 1);
            uvs.push(ix / gridX);
            uvs.push(1 - iy / gridY);
          }
        }
        for (let iy = 0; iy < gridY; iy++) {
          for (let ix = 0; ix < gridX; ix++) {
            const a = ix + gridX1 * iy;
            const b = ix + gridX1 * (iy + 1);
            const c = ix + 1 + gridX1 * (iy + 1);
            const d = ix + 1 + gridX1 * iy;
            indices.push(a, b, d);
            indices.push(b, c, d);
          }
        }
        this.setIndex(indices);
        this.setAttribute("position", new Float32BufferAttribute(vertices, 3));
        this.setAttribute("normal", new Float32BufferAttribute(normals, 3));
        this.setAttribute("uv", new Float32BufferAttribute(uvs, 2));
      }
      copy(source) {
        super.copy(source);
        this.parameters = Object.assign({}, source.parameters);
        return this;
      }
      static fromJSON(data) {
        return new _PlaneGeometry(data.width, data.height, data.widthSegments, data.heightSegments);
      }
    };
    alphahash_fragment = "#ifdef USE_ALPHAHASH\n	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;\n#endif";
    alphahash_pars_fragment = "#ifdef USE_ALPHAHASH\n	const float ALPHA_HASH_SCALE = 0.05;\n	float hash2D( vec2 value ) {\n		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );\n	}\n	float hash3D( vec3 value ) {\n		return hash2D( vec2( hash2D( value.xy ), value.z ) );\n	}\n	float getAlphaHashThreshold( vec3 position ) {\n		float maxDeriv = max(\n			length( dFdx( position.xyz ) ),\n			length( dFdy( position.xyz ) )\n		);\n		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );\n		vec2 pixScales = vec2(\n			exp2( floor( log2( pixScale ) ) ),\n			exp2( ceil( log2( pixScale ) ) )\n		);\n		vec2 alpha = vec2(\n			hash3D( floor( pixScales.x * position.xyz ) ),\n			hash3D( floor( pixScales.y * position.xyz ) )\n		);\n		float lerpFactor = fract( log2( pixScale ) );\n		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;\n		float a = min( lerpFactor, 1.0 - lerpFactor );\n		vec3 cases = vec3(\n			x * x / ( 2.0 * a * ( 1.0 - a ) ),\n			( x - 0.5 * a ) / ( 1.0 - a ),\n			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )\n		);\n		float threshold = ( x < ( 1.0 - a ) )\n			? ( ( x < a ) ? cases.x : cases.y )\n			: cases.z;\n		return clamp( threshold , 1.0e-6, 1.0 );\n	}\n#endif";
    alphamap_fragment = "#ifdef USE_ALPHAMAP\n	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;\n#endif";
    alphamap_pars_fragment = "#ifdef USE_ALPHAMAP\n	uniform sampler2D alphaMap;\n#endif";
    alphatest_fragment = "#ifdef USE_ALPHATEST\n	#ifdef ALPHA_TO_COVERAGE\n	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );\n	if ( diffuseColor.a == 0.0 ) discard;\n	#else\n	if ( diffuseColor.a < alphaTest ) discard;\n	#endif\n#endif";
    alphatest_pars_fragment = "#ifdef USE_ALPHATEST\n	uniform float alphaTest;\n#endif";
    aomap_fragment = "#ifdef USE_AOMAP\n	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;\n	reflectedLight.indirectDiffuse *= ambientOcclusion;\n	#if defined( USE_CLEARCOAT ) \n		clearcoatSpecularIndirect *= ambientOcclusion;\n	#endif\n	#if defined( USE_SHEEN ) \n		sheenSpecularIndirect *= ambientOcclusion;\n	#endif\n	#if defined( USE_ENVMAP ) && defined( STANDARD )\n		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );\n		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );\n	#endif\n#endif";
    aomap_pars_fragment = "#ifdef USE_AOMAP\n	uniform sampler2D aoMap;\n	uniform float aoMapIntensity;\n#endif";
    batching_pars_vertex = "#ifdef USE_BATCHING\n	#if ! defined( GL_ANGLE_multi_draw )\n	#define gl_DrawID _gl_DrawID\n	uniform int _gl_DrawID;\n	#endif\n	uniform highp sampler2D batchingTexture;\n	uniform highp usampler2D batchingIdTexture;\n	mat4 getBatchingMatrix( const in float i ) {\n		int size = textureSize( batchingTexture, 0 ).x;\n		int j = int( i ) * 4;\n		int x = j % size;\n		int y = j / size;\n		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );\n		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );\n		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );\n		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );\n		return mat4( v1, v2, v3, v4 );\n	}\n	float getIndirectIndex( const in int i ) {\n		int size = textureSize( batchingIdTexture, 0 ).x;\n		int x = i % size;\n		int y = i / size;\n		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );\n	}\n#endif\n#ifdef USE_BATCHING_COLOR\n	uniform sampler2D batchingColorTexture;\n	vec3 getBatchingColor( const in float i ) {\n		int size = textureSize( batchingColorTexture, 0 ).x;\n		int j = int( i );\n		int x = j % size;\n		int y = j / size;\n		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;\n	}\n#endif";
    batching_vertex = "#ifdef USE_BATCHING\n	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );\n#endif";
    begin_vertex = "vec3 transformed = vec3( position );\n#ifdef USE_ALPHAHASH\n	vPosition = vec3( position );\n#endif";
    beginnormal_vertex = "vec3 objectNormal = vec3( normal );\n#ifdef USE_TANGENT\n	vec3 objectTangent = vec3( tangent.xyz );\n#endif";
    bsdfs = "float G_BlinnPhong_Implicit( ) {\n	return 0.25;\n}\nfloat D_BlinnPhong( const in float shininess, const in float dotNH ) {\n	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );\n}\nvec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {\n	vec3 halfDir = normalize( lightDir + viewDir );\n	float dotNH = saturate( dot( normal, halfDir ) );\n	float dotVH = saturate( dot( viewDir, halfDir ) );\n	vec3 F = F_Schlick( specularColor, 1.0, dotVH );\n	float G = G_BlinnPhong_Implicit( );\n	float D = D_BlinnPhong( shininess, dotNH );\n	return F * ( G * D );\n} // validated";
    iridescence_fragment = "#ifdef USE_IRIDESCENCE\n	const mat3 XYZ_TO_REC709 = mat3(\n		 3.2404542, -0.9692660,  0.0556434,\n		-1.5371385,  1.8760108, -0.2040259,\n		-0.4985314,  0.0415560,  1.0572252\n	);\n	vec3 Fresnel0ToIor( vec3 fresnel0 ) {\n		vec3 sqrtF0 = sqrt( fresnel0 );\n		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );\n	}\n	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {\n		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );\n	}\n	float IorToFresnel0( float transmittedIor, float incidentIor ) {\n		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));\n	}\n	vec3 evalSensitivity( float OPD, vec3 shift ) {\n		float phase = 2.0 * PI * OPD * 1.0e-9;\n		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );\n		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );\n		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );\n		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );\n		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );\n		xyz /= 1.0685e-7;\n		vec3 rgb = XYZ_TO_REC709 * xyz;\n		return rgb;\n	}\n	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {\n		vec3 I;\n		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );\n		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );\n		float cosTheta2Sq = 1.0 - sinTheta2Sq;\n		if ( cosTheta2Sq < 0.0 ) {\n			return vec3( 1.0 );\n		}\n		float cosTheta2 = sqrt( cosTheta2Sq );\n		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );\n		float R12 = F_Schlick( R0, 1.0, cosTheta1 );\n		float T121 = 1.0 - R12;\n		float phi12 = 0.0;\n		if ( iridescenceIOR < outsideIOR ) phi12 = PI;\n		float phi21 = PI - phi12;\n		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );\n		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );\n		vec3 phi23 = vec3( 0.0 );\n		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;\n		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;\n		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;\n		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;\n		vec3 phi = vec3( phi21 ) + phi23;\n		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );\n		vec3 r123 = sqrt( R123 );\n		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );\n		vec3 C0 = R12 + Rs;\n		I = C0;\n		vec3 Cm = Rs - T121;\n		for ( int m = 1; m <= 2; ++ m ) {\n			Cm *= r123;\n			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );\n			I += Cm * Sm;\n		}\n		return max( I, vec3( 0.0 ) );\n	}\n#endif";
    bumpmap_pars_fragment = "#ifdef USE_BUMPMAP\n	uniform sampler2D bumpMap;\n	uniform float bumpScale;\n	vec2 dHdxy_fwd() {\n		vec2 dSTdx = dFdx( vBumpMapUv );\n		vec2 dSTdy = dFdy( vBumpMapUv );\n		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;\n		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;\n		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;\n		return vec2( dBx, dBy );\n	}\n	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {\n		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );\n		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );\n		vec3 vN = surf_norm;\n		vec3 R1 = cross( vSigmaY, vN );\n		vec3 R2 = cross( vN, vSigmaX );\n		float fDet = dot( vSigmaX, R1 ) * faceDirection;\n		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );\n		return normalize( abs( fDet ) * surf_norm - vGrad );\n	}\n#endif";
    clipping_planes_fragment = "#if NUM_CLIPPING_PLANES > 0\n	vec4 plane;\n	#ifdef ALPHA_TO_COVERAGE\n		float distanceToPlane, distanceGradient;\n		float clipOpacity = 1.0;\n		#pragma unroll_loop_start\n		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {\n			plane = clippingPlanes[ i ];\n			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;\n			distanceGradient = fwidth( distanceToPlane ) / 2.0;\n			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );\n			if ( clipOpacity == 0.0 ) discard;\n		}\n		#pragma unroll_loop_end\n		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES\n			float unionClipOpacity = 1.0;\n			#pragma unroll_loop_start\n			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {\n				plane = clippingPlanes[ i ];\n				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;\n				distanceGradient = fwidth( distanceToPlane ) / 2.0;\n				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );\n			}\n			#pragma unroll_loop_end\n			clipOpacity *= 1.0 - unionClipOpacity;\n		#endif\n		diffuseColor.a *= clipOpacity;\n		if ( diffuseColor.a == 0.0 ) discard;\n	#else\n		#pragma unroll_loop_start\n		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {\n			plane = clippingPlanes[ i ];\n			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;\n		}\n		#pragma unroll_loop_end\n		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES\n			bool clipped = true;\n			#pragma unroll_loop_start\n			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {\n				plane = clippingPlanes[ i ];\n				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;\n			}\n			#pragma unroll_loop_end\n			if ( clipped ) discard;\n		#endif\n	#endif\n#endif";
    clipping_planes_pars_fragment = "#if NUM_CLIPPING_PLANES > 0\n	varying vec3 vClipPosition;\n	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];\n#endif";
    clipping_planes_pars_vertex = "#if NUM_CLIPPING_PLANES > 0\n	varying vec3 vClipPosition;\n#endif";
    clipping_planes_vertex = "#if NUM_CLIPPING_PLANES > 0\n	vClipPosition = - mvPosition.xyz;\n#endif";
    color_fragment = "#if defined( USE_COLOR_ALPHA )\n	diffuseColor *= vColor;\n#elif defined( USE_COLOR )\n	diffuseColor.rgb *= vColor;\n#endif";
    color_pars_fragment = "#if defined( USE_COLOR_ALPHA )\n	varying vec4 vColor;\n#elif defined( USE_COLOR )\n	varying vec3 vColor;\n#endif";
    color_pars_vertex = "#if defined( USE_COLOR_ALPHA )\n	varying vec4 vColor;\n#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )\n	varying vec3 vColor;\n#endif";
    color_vertex = "#if defined( USE_COLOR_ALPHA )\n	vColor = vec4( 1.0 );\n#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )\n	vColor = vec3( 1.0 );\n#endif\n#ifdef USE_COLOR\n	vColor *= color;\n#endif\n#ifdef USE_INSTANCING_COLOR\n	vColor.xyz *= instanceColor.xyz;\n#endif\n#ifdef USE_BATCHING_COLOR\n	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );\n	vColor.xyz *= batchingColor.xyz;\n#endif";
    common = "#define PI 3.141592653589793\n#define PI2 6.283185307179586\n#define PI_HALF 1.5707963267948966\n#define RECIPROCAL_PI 0.3183098861837907\n#define RECIPROCAL_PI2 0.15915494309189535\n#define EPSILON 1e-6\n#ifndef saturate\n#define saturate( a ) clamp( a, 0.0, 1.0 )\n#endif\n#define whiteComplement( a ) ( 1.0 - saturate( a ) )\nfloat pow2( const in float x ) { return x*x; }\nvec3 pow2( const in vec3 x ) { return x*x; }\nfloat pow3( const in float x ) { return x*x*x; }\nfloat pow4( const in float x ) { float x2 = x*x; return x2*x2; }\nfloat max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }\nfloat average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }\nhighp float rand( const in vec2 uv ) {\n	const highp float a = 12.9898, b = 78.233, c = 43758.5453;\n	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );\n	return fract( sin( sn ) * c );\n}\n#ifdef HIGH_PRECISION\n	float precisionSafeLength( vec3 v ) { return length( v ); }\n#else\n	float precisionSafeLength( vec3 v ) {\n		float maxComponent = max3( abs( v ) );\n		return length( v / maxComponent ) * maxComponent;\n	}\n#endif\nstruct IncidentLight {\n	vec3 color;\n	vec3 direction;\n	bool visible;\n};\nstruct ReflectedLight {\n	vec3 directDiffuse;\n	vec3 directSpecular;\n	vec3 indirectDiffuse;\n	vec3 indirectSpecular;\n};\n#ifdef USE_ALPHAHASH\n	varying vec3 vPosition;\n#endif\nvec3 transformDirection( in vec3 dir, in mat4 matrix ) {\n	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );\n}\nvec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {\n	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );\n}\nmat3 transposeMat3( const in mat3 m ) {\n	mat3 tmp;\n	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );\n	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );\n	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );\n	return tmp;\n}\nbool isPerspectiveMatrix( mat4 m ) {\n	return m[ 2 ][ 3 ] == - 1.0;\n}\nvec2 equirectUv( in vec3 dir ) {\n	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;\n	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;\n	return vec2( u, v );\n}\nvec3 BRDF_Lambert( const in vec3 diffuseColor ) {\n	return RECIPROCAL_PI * diffuseColor;\n}\nvec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {\n	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );\n	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );\n}\nfloat F_Schlick( const in float f0, const in float f90, const in float dotVH ) {\n	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );\n	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );\n} // validated";
    cube_uv_reflection_fragment = "#ifdef ENVMAP_TYPE_CUBE_UV\n	#define cubeUV_minMipLevel 4.0\n	#define cubeUV_minTileSize 16.0\n	float getFace( vec3 direction ) {\n		vec3 absDirection = abs( direction );\n		float face = - 1.0;\n		if ( absDirection.x > absDirection.z ) {\n			if ( absDirection.x > absDirection.y )\n				face = direction.x > 0.0 ? 0.0 : 3.0;\n			else\n				face = direction.y > 0.0 ? 1.0 : 4.0;\n		} else {\n			if ( absDirection.z > absDirection.y )\n				face = direction.z > 0.0 ? 2.0 : 5.0;\n			else\n				face = direction.y > 0.0 ? 1.0 : 4.0;\n		}\n		return face;\n	}\n	vec2 getUV( vec3 direction, float face ) {\n		vec2 uv;\n		if ( face == 0.0 ) {\n			uv = vec2( direction.z, direction.y ) / abs( direction.x );\n		} else if ( face == 1.0 ) {\n			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );\n		} else if ( face == 2.0 ) {\n			uv = vec2( - direction.x, direction.y ) / abs( direction.z );\n		} else if ( face == 3.0 ) {\n			uv = vec2( - direction.z, direction.y ) / abs( direction.x );\n		} else if ( face == 4.0 ) {\n			uv = vec2( - direction.x, direction.z ) / abs( direction.y );\n		} else {\n			uv = vec2( direction.x, direction.y ) / abs( direction.z );\n		}\n		return 0.5 * ( uv + 1.0 );\n	}\n	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {\n		float face = getFace( direction );\n		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );\n		mipInt = max( mipInt, cubeUV_minMipLevel );\n		float faceSize = exp2( mipInt );\n		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;\n		if ( face > 2.0 ) {\n			uv.y += faceSize;\n			face -= 3.0;\n		}\n		uv.x += face * faceSize;\n		uv.x += filterInt * 3.0 * cubeUV_minTileSize;\n		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );\n		uv.x *= CUBEUV_TEXEL_WIDTH;\n		uv.y *= CUBEUV_TEXEL_HEIGHT;\n		#ifdef texture2DGradEXT\n			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;\n		#else\n			return texture2D( envMap, uv ).rgb;\n		#endif\n	}\n	#define cubeUV_r0 1.0\n	#define cubeUV_m0 - 2.0\n	#define cubeUV_r1 0.8\n	#define cubeUV_m1 - 1.0\n	#define cubeUV_r4 0.4\n	#define cubeUV_m4 2.0\n	#define cubeUV_r5 0.305\n	#define cubeUV_m5 3.0\n	#define cubeUV_r6 0.21\n	#define cubeUV_m6 4.0\n	float roughnessToMip( float roughness ) {\n		float mip = 0.0;\n		if ( roughness >= cubeUV_r1 ) {\n			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;\n		} else if ( roughness >= cubeUV_r4 ) {\n			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;\n		} else if ( roughness >= cubeUV_r5 ) {\n			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;\n		} else if ( roughness >= cubeUV_r6 ) {\n			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;\n		} else {\n			mip = - 2.0 * log2( 1.16 * roughness );		}\n		return mip;\n	}\n	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {\n		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );\n		float mipF = fract( mip );\n		float mipInt = floor( mip );\n		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );\n		if ( mipF == 0.0 ) {\n			return vec4( color0, 1.0 );\n		} else {\n			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );\n			return vec4( mix( color0, color1, mipF ), 1.0 );\n		}\n	}\n#endif";
    defaultnormal_vertex = "vec3 transformedNormal = objectNormal;\n#ifdef USE_TANGENT\n	vec3 transformedTangent = objectTangent;\n#endif\n#ifdef USE_BATCHING\n	mat3 bm = mat3( batchingMatrix );\n	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );\n	transformedNormal = bm * transformedNormal;\n	#ifdef USE_TANGENT\n		transformedTangent = bm * transformedTangent;\n	#endif\n#endif\n#ifdef USE_INSTANCING\n	mat3 im = mat3( instanceMatrix );\n	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );\n	transformedNormal = im * transformedNormal;\n	#ifdef USE_TANGENT\n		transformedTangent = im * transformedTangent;\n	#endif\n#endif\ntransformedNormal = normalMatrix * transformedNormal;\n#ifdef FLIP_SIDED\n	transformedNormal = - transformedNormal;\n#endif\n#ifdef USE_TANGENT\n	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;\n	#ifdef FLIP_SIDED\n		transformedTangent = - transformedTangent;\n	#endif\n#endif";
    displacementmap_pars_vertex = "#ifdef USE_DISPLACEMENTMAP\n	uniform sampler2D displacementMap;\n	uniform float displacementScale;\n	uniform float displacementBias;\n#endif";
    displacementmap_vertex = "#ifdef USE_DISPLACEMENTMAP\n	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );\n#endif";
    emissivemap_fragment = "#ifdef USE_EMISSIVEMAP\n	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );\n	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE\n		emissiveColor = sRGBTransferEOTF( emissiveColor );\n	#endif\n	totalEmissiveRadiance *= emissiveColor.rgb;\n#endif";
    emissivemap_pars_fragment = "#ifdef USE_EMISSIVEMAP\n	uniform sampler2D emissiveMap;\n#endif";
    colorspace_fragment = "gl_FragColor = linearToOutputTexel( gl_FragColor );";
    colorspace_pars_fragment = "vec4 LinearTransferOETF( in vec4 value ) {\n	return value;\n}\nvec4 sRGBTransferEOTF( in vec4 value ) {\n	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );\n}\nvec4 sRGBTransferOETF( in vec4 value ) {\n	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );\n}";
    envmap_fragment = "#ifdef USE_ENVMAP\n	#ifdef ENV_WORLDPOS\n		vec3 cameraToFrag;\n		if ( isOrthographic ) {\n			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );\n		} else {\n			cameraToFrag = normalize( vWorldPosition - cameraPosition );\n		}\n		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );\n		#ifdef ENVMAP_MODE_REFLECTION\n			vec3 reflectVec = reflect( cameraToFrag, worldNormal );\n		#else\n			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );\n		#endif\n	#else\n		vec3 reflectVec = vReflect;\n	#endif\n	#ifdef ENVMAP_TYPE_CUBE\n		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );\n	#else\n		vec4 envColor = vec4( 0.0 );\n	#endif\n	#ifdef ENVMAP_BLENDING_MULTIPLY\n		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );\n	#elif defined( ENVMAP_BLENDING_MIX )\n		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );\n	#elif defined( ENVMAP_BLENDING_ADD )\n		outgoingLight += envColor.xyz * specularStrength * reflectivity;\n	#endif\n#endif";
    envmap_common_pars_fragment = "#ifdef USE_ENVMAP\n	uniform float envMapIntensity;\n	uniform float flipEnvMap;\n	uniform mat3 envMapRotation;\n	#ifdef ENVMAP_TYPE_CUBE\n		uniform samplerCube envMap;\n	#else\n		uniform sampler2D envMap;\n	#endif\n	\n#endif";
    envmap_pars_fragment = "#ifdef USE_ENVMAP\n	uniform float reflectivity;\n	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )\n		#define ENV_WORLDPOS\n	#endif\n	#ifdef ENV_WORLDPOS\n		varying vec3 vWorldPosition;\n		uniform float refractionRatio;\n	#else\n		varying vec3 vReflect;\n	#endif\n#endif";
    envmap_pars_vertex = "#ifdef USE_ENVMAP\n	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )\n		#define ENV_WORLDPOS\n	#endif\n	#ifdef ENV_WORLDPOS\n		\n		varying vec3 vWorldPosition;\n	#else\n		varying vec3 vReflect;\n		uniform float refractionRatio;\n	#endif\n#endif";
    envmap_vertex = "#ifdef USE_ENVMAP\n	#ifdef ENV_WORLDPOS\n		vWorldPosition = worldPosition.xyz;\n	#else\n		vec3 cameraToVertex;\n		if ( isOrthographic ) {\n			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );\n		} else {\n			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );\n		}\n		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );\n		#ifdef ENVMAP_MODE_REFLECTION\n			vReflect = reflect( cameraToVertex, worldNormal );\n		#else\n			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );\n		#endif\n	#endif\n#endif";
    fog_vertex = "#ifdef USE_FOG\n	vFogDepth = - mvPosition.z;\n#endif";
    fog_pars_vertex = "#ifdef USE_FOG\n	varying float vFogDepth;\n#endif";
    fog_fragment = "#ifdef USE_FOG\n	#ifdef FOG_EXP2\n		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );\n	#else\n		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );\n	#endif\n	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );\n#endif";
    fog_pars_fragment = "#ifdef USE_FOG\n	uniform vec3 fogColor;\n	varying float vFogDepth;\n	#ifdef FOG_EXP2\n		uniform float fogDensity;\n	#else\n		uniform float fogNear;\n		uniform float fogFar;\n	#endif\n#endif";
    gradientmap_pars_fragment = "#ifdef USE_GRADIENTMAP\n	uniform sampler2D gradientMap;\n#endif\nvec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {\n	float dotNL = dot( normal, lightDirection );\n	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );\n	#ifdef USE_GRADIENTMAP\n		return vec3( texture2D( gradientMap, coord ).r );\n	#else\n		vec2 fw = fwidth( coord ) * 0.5;\n		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );\n	#endif\n}";
    lightmap_pars_fragment = "#ifdef USE_LIGHTMAP\n	uniform sampler2D lightMap;\n	uniform float lightMapIntensity;\n#endif";
    lights_lambert_fragment = "LambertMaterial material;\nmaterial.diffuseColor = diffuseColor.rgb;\nmaterial.specularStrength = specularStrength;";
    lights_lambert_pars_fragment = "varying vec3 vViewPosition;\nstruct LambertMaterial {\n	vec3 diffuseColor;\n	float specularStrength;\n};\nvoid RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {\n	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );\n	vec3 irradiance = dotNL * directLight.color;\n	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\nvoid RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {\n	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\n#define RE_Direct				RE_Direct_Lambert\n#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert";
    lights_pars_begin = "uniform bool receiveShadow;\nuniform vec3 ambientLightColor;\n#if defined( USE_LIGHT_PROBES )\n	uniform vec3 lightProbe[ 9 ];\n#endif\nvec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {\n	float x = normal.x, y = normal.y, z = normal.z;\n	vec3 result = shCoefficients[ 0 ] * 0.886227;\n	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;\n	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;\n	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;\n	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;\n	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;\n	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );\n	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;\n	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );\n	return result;\n}\nvec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {\n	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );\n	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );\n	return irradiance;\n}\nvec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {\n	vec3 irradiance = ambientLightColor;\n	return irradiance;\n}\nfloat getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {\n	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );\n	if ( cutoffDistance > 0.0 ) {\n		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );\n	}\n	return distanceFalloff;\n}\nfloat getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {\n	return smoothstep( coneCosine, penumbraCosine, angleCosine );\n}\n#if NUM_DIR_LIGHTS > 0\n	struct DirectionalLight {\n		vec3 direction;\n		vec3 color;\n	};\n	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];\n	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {\n		light.color = directionalLight.color;\n		light.direction = directionalLight.direction;\n		light.visible = true;\n	}\n#endif\n#if NUM_POINT_LIGHTS > 0\n	struct PointLight {\n		vec3 position;\n		vec3 color;\n		float distance;\n		float decay;\n	};\n	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];\n	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {\n		vec3 lVector = pointLight.position - geometryPosition;\n		light.direction = normalize( lVector );\n		float lightDistance = length( lVector );\n		light.color = pointLight.color;\n		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );\n		light.visible = ( light.color != vec3( 0.0 ) );\n	}\n#endif\n#if NUM_SPOT_LIGHTS > 0\n	struct SpotLight {\n		vec3 position;\n		vec3 direction;\n		vec3 color;\n		float distance;\n		float decay;\n		float coneCos;\n		float penumbraCos;\n	};\n	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];\n	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {\n		vec3 lVector = spotLight.position - geometryPosition;\n		light.direction = normalize( lVector );\n		float angleCos = dot( light.direction, spotLight.direction );\n		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );\n		if ( spotAttenuation > 0.0 ) {\n			float lightDistance = length( lVector );\n			light.color = spotLight.color * spotAttenuation;\n			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );\n			light.visible = ( light.color != vec3( 0.0 ) );\n		} else {\n			light.color = vec3( 0.0 );\n			light.visible = false;\n		}\n	}\n#endif\n#if NUM_RECT_AREA_LIGHTS > 0\n	struct RectAreaLight {\n		vec3 color;\n		vec3 position;\n		vec3 halfWidth;\n		vec3 halfHeight;\n	};\n	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;\n	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];\n#endif\n#if NUM_HEMI_LIGHTS > 0\n	struct HemisphereLight {\n		vec3 direction;\n		vec3 skyColor;\n		vec3 groundColor;\n	};\n	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];\n	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {\n		float dotNL = dot( normal, hemiLight.direction );\n		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;\n		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );\n		return irradiance;\n	}\n#endif";
    envmap_physical_pars_fragment = "#ifdef USE_ENVMAP\n	vec3 getIBLIrradiance( const in vec3 normal ) {\n		#ifdef ENVMAP_TYPE_CUBE_UV\n			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );\n			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );\n			return PI * envMapColor.rgb * envMapIntensity;\n		#else\n			return vec3( 0.0 );\n		#endif\n	}\n	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {\n		#ifdef ENVMAP_TYPE_CUBE_UV\n			vec3 reflectVec = reflect( - viewDir, normal );\n			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );\n			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );\n			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );\n			return envMapColor.rgb * envMapIntensity;\n		#else\n			return vec3( 0.0 );\n		#endif\n	}\n	#ifdef USE_ANISOTROPY\n		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {\n			#ifdef ENVMAP_TYPE_CUBE_UV\n				vec3 bentNormal = cross( bitangent, viewDir );\n				bentNormal = normalize( cross( bentNormal, bitangent ) );\n				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );\n				return getIBLRadiance( viewDir, bentNormal, roughness );\n			#else\n				return vec3( 0.0 );\n			#endif\n		}\n	#endif\n#endif";
    lights_toon_fragment = "ToonMaterial material;\nmaterial.diffuseColor = diffuseColor.rgb;";
    lights_toon_pars_fragment = "varying vec3 vViewPosition;\nstruct ToonMaterial {\n	vec3 diffuseColor;\n};\nvoid RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {\n	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;\n	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\nvoid RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {\n	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\n#define RE_Direct				RE_Direct_Toon\n#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon";
    lights_phong_fragment = "BlinnPhongMaterial material;\nmaterial.diffuseColor = diffuseColor.rgb;\nmaterial.specularColor = specular;\nmaterial.specularShininess = shininess;\nmaterial.specularStrength = specularStrength;";
    lights_phong_pars_fragment = "varying vec3 vViewPosition;\nstruct BlinnPhongMaterial {\n	vec3 diffuseColor;\n	vec3 specularColor;\n	float specularShininess;\n	float specularStrength;\n};\nvoid RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {\n	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );\n	vec3 irradiance = dotNL * directLight.color;\n	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;\n}\nvoid RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {\n	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\n#define RE_Direct				RE_Direct_BlinnPhong\n#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong";
    lights_physical_fragment = "PhysicalMaterial material;\nmaterial.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );\nvec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );\nfloat geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );\nmaterial.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;\nmaterial.roughness = min( material.roughness, 1.0 );\n#ifdef IOR\n	material.ior = ior;\n	#ifdef USE_SPECULAR\n		float specularIntensityFactor = specularIntensity;\n		vec3 specularColorFactor = specularColor;\n		#ifdef USE_SPECULAR_COLORMAP\n			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;\n		#endif\n		#ifdef USE_SPECULAR_INTENSITYMAP\n			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;\n		#endif\n		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );\n	#else\n		float specularIntensityFactor = 1.0;\n		vec3 specularColorFactor = vec3( 1.0 );\n		material.specularF90 = 1.0;\n	#endif\n	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );\n#else\n	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );\n	material.specularF90 = 1.0;\n#endif\n#ifdef USE_CLEARCOAT\n	material.clearcoat = clearcoat;\n	material.clearcoatRoughness = clearcoatRoughness;\n	material.clearcoatF0 = vec3( 0.04 );\n	material.clearcoatF90 = 1.0;\n	#ifdef USE_CLEARCOATMAP\n		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;\n	#endif\n	#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;\n	#endif\n	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );\n	material.clearcoatRoughness += geometryRoughness;\n	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );\n#endif\n#ifdef USE_DISPERSION\n	material.dispersion = dispersion;\n#endif\n#ifdef USE_IRIDESCENCE\n	material.iridescence = iridescence;\n	material.iridescenceIOR = iridescenceIOR;\n	#ifdef USE_IRIDESCENCEMAP\n		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;\n	#endif\n	#ifdef USE_IRIDESCENCE_THICKNESSMAP\n		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;\n	#else\n		material.iridescenceThickness = iridescenceThicknessMaximum;\n	#endif\n#endif\n#ifdef USE_SHEEN\n	material.sheenColor = sheenColor;\n	#ifdef USE_SHEEN_COLORMAP\n		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;\n	#endif\n	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );\n	#ifdef USE_SHEEN_ROUGHNESSMAP\n		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;\n	#endif\n#endif\n#ifdef USE_ANISOTROPY\n	#ifdef USE_ANISOTROPYMAP\n		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );\n		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;\n		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;\n	#else\n		vec2 anisotropyV = anisotropyVector;\n	#endif\n	material.anisotropy = length( anisotropyV );\n	if( material.anisotropy == 0.0 ) {\n		anisotropyV = vec2( 1.0, 0.0 );\n	} else {\n		anisotropyV /= material.anisotropy;\n		material.anisotropy = saturate( material.anisotropy );\n	}\n	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );\n	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;\n	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;\n#endif";
    lights_physical_pars_fragment = "struct PhysicalMaterial {\n	vec3 diffuseColor;\n	float roughness;\n	vec3 specularColor;\n	float specularF90;\n	float dispersion;\n	#ifdef USE_CLEARCOAT\n		float clearcoat;\n		float clearcoatRoughness;\n		vec3 clearcoatF0;\n		float clearcoatF90;\n	#endif\n	#ifdef USE_IRIDESCENCE\n		float iridescence;\n		float iridescenceIOR;\n		float iridescenceThickness;\n		vec3 iridescenceFresnel;\n		vec3 iridescenceF0;\n	#endif\n	#ifdef USE_SHEEN\n		vec3 sheenColor;\n		float sheenRoughness;\n	#endif\n	#ifdef IOR\n		float ior;\n	#endif\n	#ifdef USE_TRANSMISSION\n		float transmission;\n		float transmissionAlpha;\n		float thickness;\n		float attenuationDistance;\n		vec3 attenuationColor;\n	#endif\n	#ifdef USE_ANISOTROPY\n		float anisotropy;\n		float alphaT;\n		vec3 anisotropyT;\n		vec3 anisotropyB;\n	#endif\n};\nvec3 clearcoatSpecularDirect = vec3( 0.0 );\nvec3 clearcoatSpecularIndirect = vec3( 0.0 );\nvec3 sheenSpecularDirect = vec3( 0.0 );\nvec3 sheenSpecularIndirect = vec3(0.0 );\nvec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {\n    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );\n    float x2 = x * x;\n    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );\n    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );\n}\nfloat V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {\n	float a2 = pow2( alpha );\n	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );\n	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );\n	return 0.5 / max( gv + gl, EPSILON );\n}\nfloat D_GGX( const in float alpha, const in float dotNH ) {\n	float a2 = pow2( alpha );\n	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;\n	return RECIPROCAL_PI * a2 / pow2( denom );\n}\n#ifdef USE_ANISOTROPY\n	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {\n		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );\n		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );\n		float v = 0.5 / ( gv + gl );\n		return saturate(v);\n	}\n	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {\n		float a2 = alphaT * alphaB;\n		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );\n		highp float v2 = dot( v, v );\n		float w2 = a2 / v2;\n		return RECIPROCAL_PI * a2 * pow2 ( w2 );\n	}\n#endif\n#ifdef USE_CLEARCOAT\n	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {\n		vec3 f0 = material.clearcoatF0;\n		float f90 = material.clearcoatF90;\n		float roughness = material.clearcoatRoughness;\n		float alpha = pow2( roughness );\n		vec3 halfDir = normalize( lightDir + viewDir );\n		float dotNL = saturate( dot( normal, lightDir ) );\n		float dotNV = saturate( dot( normal, viewDir ) );\n		float dotNH = saturate( dot( normal, halfDir ) );\n		float dotVH = saturate( dot( viewDir, halfDir ) );\n		vec3 F = F_Schlick( f0, f90, dotVH );\n		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );\n		float D = D_GGX( alpha, dotNH );\n		return F * ( V * D );\n	}\n#endif\nvec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {\n	vec3 f0 = material.specularColor;\n	float f90 = material.specularF90;\n	float roughness = material.roughness;\n	float alpha = pow2( roughness );\n	vec3 halfDir = normalize( lightDir + viewDir );\n	float dotNL = saturate( dot( normal, lightDir ) );\n	float dotNV = saturate( dot( normal, viewDir ) );\n	float dotNH = saturate( dot( normal, halfDir ) );\n	float dotVH = saturate( dot( viewDir, halfDir ) );\n	vec3 F = F_Schlick( f0, f90, dotVH );\n	#ifdef USE_IRIDESCENCE\n		F = mix( F, material.iridescenceFresnel, material.iridescence );\n	#endif\n	#ifdef USE_ANISOTROPY\n		float dotTL = dot( material.anisotropyT, lightDir );\n		float dotTV = dot( material.anisotropyT, viewDir );\n		float dotTH = dot( material.anisotropyT, halfDir );\n		float dotBL = dot( material.anisotropyB, lightDir );\n		float dotBV = dot( material.anisotropyB, viewDir );\n		float dotBH = dot( material.anisotropyB, halfDir );\n		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );\n		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );\n	#else\n		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );\n		float D = D_GGX( alpha, dotNH );\n	#endif\n	return F * ( V * D );\n}\nvec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {\n	const float LUT_SIZE = 64.0;\n	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;\n	const float LUT_BIAS = 0.5 / LUT_SIZE;\n	float dotNV = saturate( dot( N, V ) );\n	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );\n	uv = uv * LUT_SCALE + LUT_BIAS;\n	return uv;\n}\nfloat LTC_ClippedSphereFormFactor( const in vec3 f ) {\n	float l = length( f );\n	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );\n}\nvec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {\n	float x = dot( v1, v2 );\n	float y = abs( x );\n	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;\n	float b = 3.4175940 + ( 4.1616724 + y ) * y;\n	float v = a / b;\n	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;\n	return cross( v1, v2 ) * theta_sintheta;\n}\nvec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {\n	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];\n	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];\n	vec3 lightNormal = cross( v1, v2 );\n	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );\n	vec3 T1, T2;\n	T1 = normalize( V - N * dot( V, N ) );\n	T2 = - cross( N, T1 );\n	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );\n	vec3 coords[ 4 ];\n	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );\n	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );\n	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );\n	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );\n	coords[ 0 ] = normalize( coords[ 0 ] );\n	coords[ 1 ] = normalize( coords[ 1 ] );\n	coords[ 2 ] = normalize( coords[ 2 ] );\n	coords[ 3 ] = normalize( coords[ 3 ] );\n	vec3 vectorFormFactor = vec3( 0.0 );\n	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );\n	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );\n	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );\n	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );\n	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );\n	return vec3( result );\n}\n#if defined( USE_SHEEN )\nfloat D_Charlie( float roughness, float dotNH ) {\n	float alpha = pow2( roughness );\n	float invAlpha = 1.0 / alpha;\n	float cos2h = dotNH * dotNH;\n	float sin2h = max( 1.0 - cos2h, 0.0078125 );\n	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );\n}\nfloat V_Neubelt( float dotNV, float dotNL ) {\n	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );\n}\nvec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {\n	vec3 halfDir = normalize( lightDir + viewDir );\n	float dotNL = saturate( dot( normal, lightDir ) );\n	float dotNV = saturate( dot( normal, viewDir ) );\n	float dotNH = saturate( dot( normal, halfDir ) );\n	float D = D_Charlie( sheenRoughness, dotNH );\n	float V = V_Neubelt( dotNV, dotNL );\n	return sheenColor * ( D * V );\n}\n#endif\nfloat IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {\n	float dotNV = saturate( dot( normal, viewDir ) );\n	float r2 = roughness * roughness;\n	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;\n	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;\n	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );\n	return saturate( DG * RECIPROCAL_PI );\n}\nvec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {\n	float dotNV = saturate( dot( normal, viewDir ) );\n	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );\n	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );\n	vec4 r = roughness * c0 + c1;\n	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;\n	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;\n	return fab;\n}\nvec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {\n	vec2 fab = DFGApprox( normal, viewDir, roughness );\n	return specularColor * fab.x + specularF90 * fab.y;\n}\n#ifdef USE_IRIDESCENCE\nvoid computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {\n#else\nvoid computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {\n#endif\n	vec2 fab = DFGApprox( normal, viewDir, roughness );\n	#ifdef USE_IRIDESCENCE\n		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );\n	#else\n		vec3 Fr = specularColor;\n	#endif\n	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;\n	float Ess = fab.x + fab.y;\n	float Ems = 1.0 - Ess;\n	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );\n	singleScatter += FssEss;\n	multiScatter += Fms * Ems;\n}\n#if NUM_RECT_AREA_LIGHTS > 0\n	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {\n		vec3 normal = geometryNormal;\n		vec3 viewDir = geometryViewDir;\n		vec3 position = geometryPosition;\n		vec3 lightPos = rectAreaLight.position;\n		vec3 halfWidth = rectAreaLight.halfWidth;\n		vec3 halfHeight = rectAreaLight.halfHeight;\n		vec3 lightColor = rectAreaLight.color;\n		float roughness = material.roughness;\n		vec3 rectCoords[ 4 ];\n		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;\n		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;\n		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;\n		vec2 uv = LTC_Uv( normal, viewDir, roughness );\n		vec4 t1 = texture2D( ltc_1, uv );\n		vec4 t2 = texture2D( ltc_2, uv );\n		mat3 mInv = mat3(\n			vec3( t1.x, 0, t1.y ),\n			vec3(    0, 1,    0 ),\n			vec3( t1.z, 0, t1.w )\n		);\n		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );\n		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );\n		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );\n	}\n#endif\nvoid RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {\n	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );\n	vec3 irradiance = dotNL * directLight.color;\n	#ifdef USE_CLEARCOAT\n		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );\n		vec3 ccIrradiance = dotNLcc * directLight.color;\n		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );\n	#endif\n	#ifdef USE_SHEEN\n		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );\n	#endif\n	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );\n	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\nvoid RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {\n	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\nvoid RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {\n	#ifdef USE_CLEARCOAT\n		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );\n	#endif\n	#ifdef USE_SHEEN\n		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );\n	#endif\n	vec3 singleScattering = vec3( 0.0 );\n	vec3 multiScattering = vec3( 0.0 );\n	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;\n	#ifdef USE_IRIDESCENCE\n		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );\n	#else\n		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );\n	#endif\n	vec3 totalScattering = singleScattering + multiScattering;\n	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );\n	reflectedLight.indirectSpecular += radiance * singleScattering;\n	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;\n	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;\n}\n#define RE_Direct				RE_Direct_Physical\n#define RE_Direct_RectArea		RE_Direct_RectArea_Physical\n#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical\n#define RE_IndirectSpecular		RE_IndirectSpecular_Physical\nfloat computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {\n	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );\n}";
    lights_fragment_begin = "\nvec3 geometryPosition = - vViewPosition;\nvec3 geometryNormal = normal;\nvec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );\nvec3 geometryClearcoatNormal = vec3( 0.0 );\n#ifdef USE_CLEARCOAT\n	geometryClearcoatNormal = clearcoatNormal;\n#endif\n#ifdef USE_IRIDESCENCE\n	float dotNVi = saturate( dot( normal, geometryViewDir ) );\n	if ( material.iridescenceThickness == 0.0 ) {\n		material.iridescence = 0.0;\n	} else {\n		material.iridescence = saturate( material.iridescence );\n	}\n	if ( material.iridescence > 0.0 ) {\n		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );\n		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );\n	}\n#endif\nIncidentLight directLight;\n#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )\n	PointLight pointLight;\n	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0\n	PointLightShadow pointLightShadow;\n	#endif\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {\n		pointLight = pointLights[ i ];\n		getPointLightInfo( pointLight, geometryPosition, directLight );\n		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )\n		pointLightShadow = pointLightShadows[ i ];\n		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;\n		#endif\n		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n	}\n	#pragma unroll_loop_end\n#endif\n#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )\n	SpotLight spotLight;\n	vec4 spotColor;\n	vec3 spotLightCoord;\n	bool inSpotLightMap;\n	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0\n	SpotLightShadow spotLightShadow;\n	#endif\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {\n		spotLight = spotLights[ i ];\n		getSpotLightInfo( spotLight, geometryPosition, directLight );\n		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )\n		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX\n		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )\n		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS\n		#else\n		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )\n		#endif\n		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )\n			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;\n			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );\n			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );\n			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;\n		#endif\n		#undef SPOT_LIGHT_MAP_INDEX\n		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )\n		spotLightShadow = spotLightShadows[ i ];\n		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;\n		#endif\n		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n	}\n	#pragma unroll_loop_end\n#endif\n#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )\n	DirectionalLight directionalLight;\n	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0\n	DirectionalLightShadow directionalLightShadow;\n	#endif\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {\n		directionalLight = directionalLights[ i ];\n		getDirectionalLightInfo( directionalLight, directLight );\n		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )\n		directionalLightShadow = directionalLightShadows[ i ];\n		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;\n		#endif\n		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n	}\n	#pragma unroll_loop_end\n#endif\n#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )\n	RectAreaLight rectAreaLight;\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {\n		rectAreaLight = rectAreaLights[ i ];\n		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n	}\n	#pragma unroll_loop_end\n#endif\n#if defined( RE_IndirectDiffuse )\n	vec3 iblIrradiance = vec3( 0.0 );\n	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );\n	#if defined( USE_LIGHT_PROBES )\n		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );\n	#endif\n	#if ( NUM_HEMI_LIGHTS > 0 )\n		#pragma unroll_loop_start\n		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {\n			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );\n		}\n		#pragma unroll_loop_end\n	#endif\n#endif\n#if defined( RE_IndirectSpecular )\n	vec3 radiance = vec3( 0.0 );\n	vec3 clearcoatRadiance = vec3( 0.0 );\n#endif";
    lights_fragment_maps = "#if defined( RE_IndirectDiffuse )\n	#ifdef USE_LIGHTMAP\n		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );\n		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;\n		irradiance += lightMapIrradiance;\n	#endif\n	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )\n		iblIrradiance += getIBLIrradiance( geometryNormal );\n	#endif\n#endif\n#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )\n	#ifdef USE_ANISOTROPY\n		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );\n	#else\n		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );\n	#endif\n	#ifdef USE_CLEARCOAT\n		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );\n	#endif\n#endif";
    lights_fragment_end = "#if defined( RE_IndirectDiffuse )\n	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n#endif\n#if defined( RE_IndirectSpecular )\n	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n#endif";
    logdepthbuf_fragment = "#if defined( USE_LOGDEPTHBUF )\n	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;\n#endif";
    logdepthbuf_pars_fragment = "#if defined( USE_LOGDEPTHBUF )\n	uniform float logDepthBufFC;\n	varying float vFragDepth;\n	varying float vIsPerspective;\n#endif";
    logdepthbuf_pars_vertex = "#ifdef USE_LOGDEPTHBUF\n	varying float vFragDepth;\n	varying float vIsPerspective;\n#endif";
    logdepthbuf_vertex = "#ifdef USE_LOGDEPTHBUF\n	vFragDepth = 1.0 + gl_Position.w;\n	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );\n#endif";
    map_fragment = "#ifdef USE_MAP\n	vec4 sampledDiffuseColor = texture2D( map, vMapUv );\n	#ifdef DECODE_VIDEO_TEXTURE\n		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );\n	#endif\n	diffuseColor *= sampledDiffuseColor;\n#endif";
    map_pars_fragment = "#ifdef USE_MAP\n	uniform sampler2D map;\n#endif";
    map_particle_fragment = "#if defined( USE_MAP ) || defined( USE_ALPHAMAP )\n	#if defined( USE_POINTS_UV )\n		vec2 uv = vUv;\n	#else\n		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;\n	#endif\n#endif\n#ifdef USE_MAP\n	diffuseColor *= texture2D( map, uv );\n#endif\n#ifdef USE_ALPHAMAP\n	diffuseColor.a *= texture2D( alphaMap, uv ).g;\n#endif";
    map_particle_pars_fragment = "#if defined( USE_POINTS_UV )\n	varying vec2 vUv;\n#else\n	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )\n		uniform mat3 uvTransform;\n	#endif\n#endif\n#ifdef USE_MAP\n	uniform sampler2D map;\n#endif\n#ifdef USE_ALPHAMAP\n	uniform sampler2D alphaMap;\n#endif";
    metalnessmap_fragment = "float metalnessFactor = metalness;\n#ifdef USE_METALNESSMAP\n	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );\n	metalnessFactor *= texelMetalness.b;\n#endif";
    metalnessmap_pars_fragment = "#ifdef USE_METALNESSMAP\n	uniform sampler2D metalnessMap;\n#endif";
    morphinstance_vertex = "#ifdef USE_INSTANCING_MORPH\n	float morphTargetInfluences[ MORPHTARGETS_COUNT ];\n	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;\n	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {\n		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;\n	}\n#endif";
    morphcolor_vertex = "#if defined( USE_MORPHCOLORS )\n	vColor *= morphTargetBaseInfluence;\n	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {\n		#if defined( USE_COLOR_ALPHA )\n			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];\n		#elif defined( USE_COLOR )\n			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];\n		#endif\n	}\n#endif";
    morphnormal_vertex = "#ifdef USE_MORPHNORMALS\n	objectNormal *= morphTargetBaseInfluence;\n	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {\n		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];\n	}\n#endif";
    morphtarget_pars_vertex = "#ifdef USE_MORPHTARGETS\n	#ifndef USE_INSTANCING_MORPH\n		uniform float morphTargetBaseInfluence;\n		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];\n	#endif\n	uniform sampler2DArray morphTargetsTexture;\n	uniform ivec2 morphTargetsTextureSize;\n	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {\n		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;\n		int y = texelIndex / morphTargetsTextureSize.x;\n		int x = texelIndex - y * morphTargetsTextureSize.x;\n		ivec3 morphUV = ivec3( x, y, morphTargetIndex );\n		return texelFetch( morphTargetsTexture, morphUV, 0 );\n	}\n#endif";
    morphtarget_vertex = "#ifdef USE_MORPHTARGETS\n	transformed *= morphTargetBaseInfluence;\n	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {\n		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];\n	}\n#endif";
    normal_fragment_begin = "float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;\n#ifdef FLAT_SHADED\n	vec3 fdx = dFdx( vViewPosition );\n	vec3 fdy = dFdy( vViewPosition );\n	vec3 normal = normalize( cross( fdx, fdy ) );\n#else\n	vec3 normal = normalize( vNormal );\n	#ifdef DOUBLE_SIDED\n		normal *= faceDirection;\n	#endif\n#endif\n#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )\n	#ifdef USE_TANGENT\n		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );\n	#else\n		mat3 tbn = getTangentFrame( - vViewPosition, normal,\n		#if defined( USE_NORMALMAP )\n			vNormalMapUv\n		#elif defined( USE_CLEARCOAT_NORMALMAP )\n			vClearcoatNormalMapUv\n		#else\n			vUv\n		#endif\n		);\n	#endif\n	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )\n		tbn[0] *= faceDirection;\n		tbn[1] *= faceDirection;\n	#endif\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	#ifdef USE_TANGENT\n		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );\n	#else\n		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );\n	#endif\n	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )\n		tbn2[0] *= faceDirection;\n		tbn2[1] *= faceDirection;\n	#endif\n#endif\nvec3 nonPerturbedNormal = normal;";
    normal_fragment_maps = "#ifdef USE_NORMALMAP_OBJECTSPACE\n	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;\n	#ifdef FLIP_SIDED\n		normal = - normal;\n	#endif\n	#ifdef DOUBLE_SIDED\n		normal = normal * faceDirection;\n	#endif\n	normal = normalize( normalMatrix * normal );\n#elif defined( USE_NORMALMAP_TANGENTSPACE )\n	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;\n	mapN.xy *= normalScale;\n	normal = normalize( tbn * mapN );\n#elif defined( USE_BUMPMAP )\n	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );\n#endif";
    normal_pars_fragment = "#ifndef FLAT_SHADED\n	varying vec3 vNormal;\n	#ifdef USE_TANGENT\n		varying vec3 vTangent;\n		varying vec3 vBitangent;\n	#endif\n#endif";
    normal_pars_vertex = "#ifndef FLAT_SHADED\n	varying vec3 vNormal;\n	#ifdef USE_TANGENT\n		varying vec3 vTangent;\n		varying vec3 vBitangent;\n	#endif\n#endif";
    normal_vertex = "#ifndef FLAT_SHADED\n	vNormal = normalize( transformedNormal );\n	#ifdef USE_TANGENT\n		vTangent = normalize( transformedTangent );\n		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );\n	#endif\n#endif";
    normalmap_pars_fragment = "#ifdef USE_NORMALMAP\n	uniform sampler2D normalMap;\n	uniform vec2 normalScale;\n#endif\n#ifdef USE_NORMALMAP_OBJECTSPACE\n	uniform mat3 normalMatrix;\n#endif\n#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )\n	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {\n		vec3 q0 = dFdx( eye_pos.xyz );\n		vec3 q1 = dFdy( eye_pos.xyz );\n		vec2 st0 = dFdx( uv.st );\n		vec2 st1 = dFdy( uv.st );\n		vec3 N = surf_norm;\n		vec3 q1perp = cross( q1, N );\n		vec3 q0perp = cross( N, q0 );\n		vec3 T = q1perp * st0.x + q0perp * st1.x;\n		vec3 B = q1perp * st0.y + q0perp * st1.y;\n		float det = max( dot( T, T ), dot( B, B ) );\n		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );\n		return mat3( T * scale, B * scale, N );\n	}\n#endif";
    clearcoat_normal_fragment_begin = "#ifdef USE_CLEARCOAT\n	vec3 clearcoatNormal = nonPerturbedNormal;\n#endif";
    clearcoat_normal_fragment_maps = "#ifdef USE_CLEARCOAT_NORMALMAP\n	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;\n	clearcoatMapN.xy *= clearcoatNormalScale;\n	clearcoatNormal = normalize( tbn2 * clearcoatMapN );\n#endif";
    clearcoat_pars_fragment = "#ifdef USE_CLEARCOATMAP\n	uniform sampler2D clearcoatMap;\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	uniform sampler2D clearcoatNormalMap;\n	uniform vec2 clearcoatNormalScale;\n#endif\n#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n	uniform sampler2D clearcoatRoughnessMap;\n#endif";
    iridescence_pars_fragment = "#ifdef USE_IRIDESCENCEMAP\n	uniform sampler2D iridescenceMap;\n#endif\n#ifdef USE_IRIDESCENCE_THICKNESSMAP\n	uniform sampler2D iridescenceThicknessMap;\n#endif";
    opaque_fragment = "#ifdef OPAQUE\ndiffuseColor.a = 1.0;\n#endif\n#ifdef USE_TRANSMISSION\ndiffuseColor.a *= material.transmissionAlpha;\n#endif\ngl_FragColor = vec4( outgoingLight, diffuseColor.a );";
    packing = "vec3 packNormalToRGB( const in vec3 normal ) {\n	return normalize( normal ) * 0.5 + 0.5;\n}\nvec3 unpackRGBToNormal( const in vec3 rgb ) {\n	return 2.0 * rgb.xyz - 1.0;\n}\nconst float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;\nconst float Inv255 = 1. / 255.;\nconst vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );\nconst vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );\nconst vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );\nconst vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );\nvec4 packDepthToRGBA( const in float v ) {\n	if( v <= 0.0 )\n		return vec4( 0., 0., 0., 0. );\n	if( v >= 1.0 )\n		return vec4( 1., 1., 1., 1. );\n	float vuf;\n	float af = modf( v * PackFactors.a, vuf );\n	float bf = modf( vuf * ShiftRight8, vuf );\n	float gf = modf( vuf * ShiftRight8, vuf );\n	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );\n}\nvec3 packDepthToRGB( const in float v ) {\n	if( v <= 0.0 )\n		return vec3( 0., 0., 0. );\n	if( v >= 1.0 )\n		return vec3( 1., 1., 1. );\n	float vuf;\n	float bf = modf( v * PackFactors.b, vuf );\n	float gf = modf( vuf * ShiftRight8, vuf );\n	return vec3( vuf * Inv255, gf * PackUpscale, bf );\n}\nvec2 packDepthToRG( const in float v ) {\n	if( v <= 0.0 )\n		return vec2( 0., 0. );\n	if( v >= 1.0 )\n		return vec2( 1., 1. );\n	float vuf;\n	float gf = modf( v * 256., vuf );\n	return vec2( vuf * Inv255, gf );\n}\nfloat unpackRGBAToDepth( const in vec4 v ) {\n	return dot( v, UnpackFactors4 );\n}\nfloat unpackRGBToDepth( const in vec3 v ) {\n	return dot( v, UnpackFactors3 );\n}\nfloat unpackRGToDepth( const in vec2 v ) {\n	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;\n}\nvec4 pack2HalfToRGBA( const in vec2 v ) {\n	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );\n	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );\n}\nvec2 unpackRGBATo2Half( const in vec4 v ) {\n	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );\n}\nfloat viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {\n	return ( viewZ + near ) / ( near - far );\n}\nfloat orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {\n	return depth * ( near - far ) - near;\n}\nfloat viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {\n	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );\n}\nfloat perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {\n	return ( near * far ) / ( ( far - near ) * depth - far );\n}";
    premultiplied_alpha_fragment = "#ifdef PREMULTIPLIED_ALPHA\n	gl_FragColor.rgb *= gl_FragColor.a;\n#endif";
    project_vertex = "vec4 mvPosition = vec4( transformed, 1.0 );\n#ifdef USE_BATCHING\n	mvPosition = batchingMatrix * mvPosition;\n#endif\n#ifdef USE_INSTANCING\n	mvPosition = instanceMatrix * mvPosition;\n#endif\nmvPosition = modelViewMatrix * mvPosition;\ngl_Position = projectionMatrix * mvPosition;";
    dithering_fragment = "#ifdef DITHERING\n	gl_FragColor.rgb = dithering( gl_FragColor.rgb );\n#endif";
    dithering_pars_fragment = "#ifdef DITHERING\n	vec3 dithering( vec3 color ) {\n		float grid_position = rand( gl_FragCoord.xy );\n		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );\n		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );\n		return color + dither_shift_RGB;\n	}\n#endif";
    roughnessmap_fragment = "float roughnessFactor = roughness;\n#ifdef USE_ROUGHNESSMAP\n	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );\n	roughnessFactor *= texelRoughness.g;\n#endif";
    roughnessmap_pars_fragment = "#ifdef USE_ROUGHNESSMAP\n	uniform sampler2D roughnessMap;\n#endif";
    shadowmap_pars_fragment = "#if NUM_SPOT_LIGHT_COORDS > 0\n	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];\n#endif\n#if NUM_SPOT_LIGHT_MAPS > 0\n	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];\n#endif\n#ifdef USE_SHADOWMAP\n	#if NUM_DIR_LIGHT_SHADOWS > 0\n		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];\n		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];\n		struct DirectionalLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n		};\n		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];\n	#endif\n	#if NUM_SPOT_LIGHT_SHADOWS > 0\n		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];\n		struct SpotLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n		};\n		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0\n		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];\n		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];\n		struct PointLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n			float shadowCameraNear;\n			float shadowCameraFar;\n		};\n		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];\n	#endif\n	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {\n		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );\n	}\n	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {\n		return unpackRGBATo2Half( texture2D( shadow, uv ) );\n	}\n	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){\n		float occlusion = 1.0;\n		vec2 distribution = texture2DDistribution( shadow, uv );\n		float hard_shadow = step( compare , distribution.x );\n		if (hard_shadow != 1.0 ) {\n			float distance = compare - distribution.x ;\n			float variance = max( 0.00000, distribution.y * distribution.y );\n			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );\n		}\n		return occlusion;\n	}\n	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {\n		float shadow = 1.0;\n		shadowCoord.xyz /= shadowCoord.w;\n		shadowCoord.z += shadowBias;\n		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;\n		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;\n		if ( frustumTest ) {\n		#if defined( SHADOWMAP_TYPE_PCF )\n			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;\n			float dx0 = - texelSize.x * shadowRadius;\n			float dy0 = - texelSize.y * shadowRadius;\n			float dx1 = + texelSize.x * shadowRadius;\n			float dy1 = + texelSize.y * shadowRadius;\n			float dx2 = dx0 / 2.0;\n			float dy2 = dy0 / 2.0;\n			float dx3 = dx1 / 2.0;\n			float dy3 = dy1 / 2.0;\n			shadow = (\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )\n			) * ( 1.0 / 17.0 );\n		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )\n			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;\n			float dx = texelSize.x;\n			float dy = texelSize.y;\n			vec2 uv = shadowCoord.xy;\n			vec2 f = fract( uv * shadowMapSize + 0.5 );\n			uv -= f * texelSize;\n			shadow = (\n				texture2DCompare( shadowMap, uv, shadowCoord.z ) +\n				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +\n				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),\n					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),\n					 f.x ) +\n				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),\n					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),\n					 f.x ) +\n				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),\n					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),\n					 f.y ) +\n				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),\n					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),\n					 f.y ) +\n				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),\n						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),\n						  f.x ),\n					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),\n						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),\n						  f.x ),\n					 f.y )\n			) * ( 1.0 / 9.0 );\n		#elif defined( SHADOWMAP_TYPE_VSM )\n			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );\n		#else\n			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );\n		#endif\n		}\n		return mix( 1.0, shadow, shadowIntensity );\n	}\n	vec2 cubeToUV( vec3 v, float texelSizeY ) {\n		vec3 absV = abs( v );\n		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );\n		absV *= scaleToCube;\n		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );\n		vec2 planar = v.xy;\n		float almostATexel = 1.5 * texelSizeY;\n		float almostOne = 1.0 - almostATexel;\n		if ( absV.z >= almostOne ) {\n			if ( v.z > 0.0 )\n				planar.x = 4.0 - v.x;\n		} else if ( absV.x >= almostOne ) {\n			float signX = sign( v.x );\n			planar.x = v.z * signX + 2.0 * signX;\n		} else if ( absV.y >= almostOne ) {\n			float signY = sign( v.y );\n			planar.x = v.x + 2.0 * signY + 2.0;\n			planar.y = v.z * signY - 2.0;\n		}\n		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );\n	}\n	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {\n		float shadow = 1.0;\n		vec3 lightToPosition = shadowCoord.xyz;\n		\n		float lightToPositionLength = length( lightToPosition );\n		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {\n			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;\n			vec3 bd3D = normalize( lightToPosition );\n			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );\n			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )\n				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;\n				shadow = (\n					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +\n					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +\n					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +\n					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +\n					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +\n					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +\n					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +\n					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +\n					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )\n				) * ( 1.0 / 9.0 );\n			#else\n				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );\n			#endif\n		}\n		return mix( 1.0, shadow, shadowIntensity );\n	}\n#endif";
    shadowmap_pars_vertex = "#if NUM_SPOT_LIGHT_COORDS > 0\n	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];\n	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];\n#endif\n#ifdef USE_SHADOWMAP\n	#if NUM_DIR_LIGHT_SHADOWS > 0\n		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];\n		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];\n		struct DirectionalLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n		};\n		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];\n	#endif\n	#if NUM_SPOT_LIGHT_SHADOWS > 0\n		struct SpotLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n		};\n		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0\n		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];\n		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];\n		struct PointLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n			float shadowCameraNear;\n			float shadowCameraFar;\n		};\n		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];\n	#endif\n#endif";
    shadowmap_vertex = "#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )\n	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );\n	vec4 shadowWorldPosition;\n#endif\n#if defined( USE_SHADOWMAP )\n	#if NUM_DIR_LIGHT_SHADOWS > 0\n		#pragma unroll_loop_start\n		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {\n			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );\n			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;\n		}\n		#pragma unroll_loop_end\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0\n		#pragma unroll_loop_start\n		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {\n			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );\n			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;\n		}\n		#pragma unroll_loop_end\n	#endif\n#endif\n#if NUM_SPOT_LIGHT_COORDS > 0\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {\n		shadowWorldPosition = worldPosition;\n		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )\n			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;\n		#endif\n		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;\n	}\n	#pragma unroll_loop_end\n#endif";
    shadowmask_pars_fragment = "float getShadowMask() {\n	float shadow = 1.0;\n	#ifdef USE_SHADOWMAP\n	#if NUM_DIR_LIGHT_SHADOWS > 0\n	DirectionalLightShadow directionalLight;\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {\n		directionalLight = directionalLightShadows[ i ];\n		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;\n	}\n	#pragma unroll_loop_end\n	#endif\n	#if NUM_SPOT_LIGHT_SHADOWS > 0\n	SpotLightShadow spotLight;\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {\n		spotLight = spotLightShadows[ i ];\n		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;\n	}\n	#pragma unroll_loop_end\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0\n	PointLightShadow pointLight;\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {\n		pointLight = pointLightShadows[ i ];\n		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;\n	}\n	#pragma unroll_loop_end\n	#endif\n	#endif\n	return shadow;\n}";
    skinbase_vertex = "#ifdef USE_SKINNING\n	mat4 boneMatX = getBoneMatrix( skinIndex.x );\n	mat4 boneMatY = getBoneMatrix( skinIndex.y );\n	mat4 boneMatZ = getBoneMatrix( skinIndex.z );\n	mat4 boneMatW = getBoneMatrix( skinIndex.w );\n#endif";
    skinning_pars_vertex = "#ifdef USE_SKINNING\n	uniform mat4 bindMatrix;\n	uniform mat4 bindMatrixInverse;\n	uniform highp sampler2D boneTexture;\n	mat4 getBoneMatrix( const in float i ) {\n		int size = textureSize( boneTexture, 0 ).x;\n		int j = int( i ) * 4;\n		int x = j % size;\n		int y = j / size;\n		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );\n		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );\n		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );\n		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );\n		return mat4( v1, v2, v3, v4 );\n	}\n#endif";
    skinning_vertex = "#ifdef USE_SKINNING\n	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );\n	vec4 skinned = vec4( 0.0 );\n	skinned += boneMatX * skinVertex * skinWeight.x;\n	skinned += boneMatY * skinVertex * skinWeight.y;\n	skinned += boneMatZ * skinVertex * skinWeight.z;\n	skinned += boneMatW * skinVertex * skinWeight.w;\n	transformed = ( bindMatrixInverse * skinned ).xyz;\n#endif";
    skinnormal_vertex = "#ifdef USE_SKINNING\n	mat4 skinMatrix = mat4( 0.0 );\n	skinMatrix += skinWeight.x * boneMatX;\n	skinMatrix += skinWeight.y * boneMatY;\n	skinMatrix += skinWeight.z * boneMatZ;\n	skinMatrix += skinWeight.w * boneMatW;\n	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;\n	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;\n	#ifdef USE_TANGENT\n		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;\n	#endif\n#endif";
    specularmap_fragment = "float specularStrength;\n#ifdef USE_SPECULARMAP\n	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );\n	specularStrength = texelSpecular.r;\n#else\n	specularStrength = 1.0;\n#endif";
    specularmap_pars_fragment = "#ifdef USE_SPECULARMAP\n	uniform sampler2D specularMap;\n#endif";
    tonemapping_fragment = "#if defined( TONE_MAPPING )\n	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );\n#endif";
    tonemapping_pars_fragment = "#ifndef saturate\n#define saturate( a ) clamp( a, 0.0, 1.0 )\n#endif\nuniform float toneMappingExposure;\nvec3 LinearToneMapping( vec3 color ) {\n	return saturate( toneMappingExposure * color );\n}\nvec3 ReinhardToneMapping( vec3 color ) {\n	color *= toneMappingExposure;\n	return saturate( color / ( vec3( 1.0 ) + color ) );\n}\nvec3 CineonToneMapping( vec3 color ) {\n	color *= toneMappingExposure;\n	color = max( vec3( 0.0 ), color - 0.004 );\n	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );\n}\nvec3 RRTAndODTFit( vec3 v ) {\n	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;\n	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;\n	return a / b;\n}\nvec3 ACESFilmicToneMapping( vec3 color ) {\n	const mat3 ACESInputMat = mat3(\n		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),\n		vec3( 0.04823, 0.01566, 0.83777 )\n	);\n	const mat3 ACESOutputMat = mat3(\n		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),\n		vec3( -0.07367, -0.00605,  1.07602 )\n	);\n	color *= toneMappingExposure / 0.6;\n	color = ACESInputMat * color;\n	color = RRTAndODTFit( color );\n	color = ACESOutputMat * color;\n	return saturate( color );\n}\nconst mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(\n	vec3( 1.6605, - 0.1246, - 0.0182 ),\n	vec3( - 0.5876, 1.1329, - 0.1006 ),\n	vec3( - 0.0728, - 0.0083, 1.1187 )\n);\nconst mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(\n	vec3( 0.6274, 0.0691, 0.0164 ),\n	vec3( 0.3293, 0.9195, 0.0880 ),\n	vec3( 0.0433, 0.0113, 0.8956 )\n);\nvec3 agxDefaultContrastApprox( vec3 x ) {\n	vec3 x2 = x * x;\n	vec3 x4 = x2 * x2;\n	return + 15.5 * x4 * x2\n		- 40.14 * x4 * x\n		+ 31.96 * x4\n		- 6.868 * x2 * x\n		+ 0.4298 * x2\n		+ 0.1191 * x\n		- 0.00232;\n}\nvec3 AgXToneMapping( vec3 color ) {\n	const mat3 AgXInsetMatrix = mat3(\n		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),\n		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),\n		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )\n	);\n	const mat3 AgXOutsetMatrix = mat3(\n		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),\n		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),\n		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )\n	);\n	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;\n	color *= toneMappingExposure;\n	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;\n	color = AgXInsetMatrix * color;\n	color = max( color, 1e-10 );	color = log2( color );\n	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );\n	color = clamp( color, 0.0, 1.0 );\n	color = agxDefaultContrastApprox( color );\n	color = AgXOutsetMatrix * color;\n	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );\n	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;\n	color = clamp( color, 0.0, 1.0 );\n	return color;\n}\nvec3 NeutralToneMapping( vec3 color ) {\n	const float StartCompression = 0.8 - 0.04;\n	const float Desaturation = 0.15;\n	color *= toneMappingExposure;\n	float x = min( color.r, min( color.g, color.b ) );\n	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;\n	color -= offset;\n	float peak = max( color.r, max( color.g, color.b ) );\n	if ( peak < StartCompression ) return color;\n	float d = 1. - StartCompression;\n	float newPeak = 1. - d * d / ( peak + d - StartCompression );\n	color *= newPeak / peak;\n	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );\n	return mix( color, vec3( newPeak ), g );\n}\nvec3 CustomToneMapping( vec3 color ) { return color; }";
    transmission_fragment = "#ifdef USE_TRANSMISSION\n	material.transmission = transmission;\n	material.transmissionAlpha = 1.0;\n	material.thickness = thickness;\n	material.attenuationDistance = attenuationDistance;\n	material.attenuationColor = attenuationColor;\n	#ifdef USE_TRANSMISSIONMAP\n		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;\n	#endif\n	#ifdef USE_THICKNESSMAP\n		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;\n	#endif\n	vec3 pos = vWorldPosition;\n	vec3 v = normalize( cameraPosition - pos );\n	vec3 n = inverseTransformDirection( normal, viewMatrix );\n	vec4 transmitted = getIBLVolumeRefraction(\n		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,\n		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,\n		material.attenuationColor, material.attenuationDistance );\n	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );\n	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );\n#endif";
    transmission_pars_fragment = "#ifdef USE_TRANSMISSION\n	uniform float transmission;\n	uniform float thickness;\n	uniform float attenuationDistance;\n	uniform vec3 attenuationColor;\n	#ifdef USE_TRANSMISSIONMAP\n		uniform sampler2D transmissionMap;\n	#endif\n	#ifdef USE_THICKNESSMAP\n		uniform sampler2D thicknessMap;\n	#endif\n	uniform vec2 transmissionSamplerSize;\n	uniform sampler2D transmissionSamplerMap;\n	uniform mat4 modelMatrix;\n	uniform mat4 projectionMatrix;\n	varying vec3 vWorldPosition;\n	float w0( float a ) {\n		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );\n	}\n	float w1( float a ) {\n		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );\n	}\n	float w2( float a ){\n		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );\n	}\n	float w3( float a ) {\n		return ( 1.0 / 6.0 ) * ( a * a * a );\n	}\n	float g0( float a ) {\n		return w0( a ) + w1( a );\n	}\n	float g1( float a ) {\n		return w2( a ) + w3( a );\n	}\n	float h0( float a ) {\n		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );\n	}\n	float h1( float a ) {\n		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );\n	}\n	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {\n		uv = uv * texelSize.zw + 0.5;\n		vec2 iuv = floor( uv );\n		vec2 fuv = fract( uv );\n		float g0x = g0( fuv.x );\n		float g1x = g1( fuv.x );\n		float h0x = h0( fuv.x );\n		float h1x = h1( fuv.x );\n		float h0y = h0( fuv.y );\n		float h1y = h1( fuv.y );\n		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;\n		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;\n		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;\n		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;\n		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +\n			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );\n	}\n	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {\n		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );\n		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );\n		vec2 fLodSizeInv = 1.0 / fLodSize;\n		vec2 cLodSizeInv = 1.0 / cLodSize;\n		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );\n		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );\n		return mix( fSample, cSample, fract( lod ) );\n	}\n	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {\n		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );\n		vec3 modelScale;\n		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );\n		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );\n		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );\n		return normalize( refractionVector ) * thickness * modelScale;\n	}\n	float applyIorToRoughness( const in float roughness, const in float ior ) {\n		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );\n	}\n	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {\n		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );\n		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );\n	}\n	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {\n		if ( isinf( attenuationDistance ) ) {\n			return vec3( 1.0 );\n		} else {\n			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;\n			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;\n		}\n	}\n	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,\n		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,\n		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,\n		const in vec3 attenuationColor, const in float attenuationDistance ) {\n		vec4 transmittedLight;\n		vec3 transmittance;\n		#ifdef USE_DISPERSION\n			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;\n			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );\n			for ( int i = 0; i < 3; i ++ ) {\n				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );\n				vec3 refractedRayExit = position + transmissionRay;\n		\n				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );\n				vec2 refractionCoords = ndcPos.xy / ndcPos.w;\n				refractionCoords += 1.0;\n				refractionCoords /= 2.0;\n		\n				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );\n				transmittedLight[ i ] = transmissionSample[ i ];\n				transmittedLight.a += transmissionSample.a;\n				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];\n			}\n			transmittedLight.a /= 3.0;\n		\n		#else\n		\n			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );\n			vec3 refractedRayExit = position + transmissionRay;\n			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );\n			vec2 refractionCoords = ndcPos.xy / ndcPos.w;\n			refractionCoords += 1.0;\n			refractionCoords /= 2.0;\n			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );\n			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );\n		\n		#endif\n		vec3 attenuatedColor = transmittance * transmittedLight.rgb;\n		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );\n		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;\n		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );\n	}\n#endif";
    uv_pars_fragment = "#if defined( USE_UV ) || defined( USE_ANISOTROPY )\n	varying vec2 vUv;\n#endif\n#ifdef USE_MAP\n	varying vec2 vMapUv;\n#endif\n#ifdef USE_ALPHAMAP\n	varying vec2 vAlphaMapUv;\n#endif\n#ifdef USE_LIGHTMAP\n	varying vec2 vLightMapUv;\n#endif\n#ifdef USE_AOMAP\n	varying vec2 vAoMapUv;\n#endif\n#ifdef USE_BUMPMAP\n	varying vec2 vBumpMapUv;\n#endif\n#ifdef USE_NORMALMAP\n	varying vec2 vNormalMapUv;\n#endif\n#ifdef USE_EMISSIVEMAP\n	varying vec2 vEmissiveMapUv;\n#endif\n#ifdef USE_METALNESSMAP\n	varying vec2 vMetalnessMapUv;\n#endif\n#ifdef USE_ROUGHNESSMAP\n	varying vec2 vRoughnessMapUv;\n#endif\n#ifdef USE_ANISOTROPYMAP\n	varying vec2 vAnisotropyMapUv;\n#endif\n#ifdef USE_CLEARCOATMAP\n	varying vec2 vClearcoatMapUv;\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	varying vec2 vClearcoatNormalMapUv;\n#endif\n#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n	varying vec2 vClearcoatRoughnessMapUv;\n#endif\n#ifdef USE_IRIDESCENCEMAP\n	varying vec2 vIridescenceMapUv;\n#endif\n#ifdef USE_IRIDESCENCE_THICKNESSMAP\n	varying vec2 vIridescenceThicknessMapUv;\n#endif\n#ifdef USE_SHEEN_COLORMAP\n	varying vec2 vSheenColorMapUv;\n#endif\n#ifdef USE_SHEEN_ROUGHNESSMAP\n	varying vec2 vSheenRoughnessMapUv;\n#endif\n#ifdef USE_SPECULARMAP\n	varying vec2 vSpecularMapUv;\n#endif\n#ifdef USE_SPECULAR_COLORMAP\n	varying vec2 vSpecularColorMapUv;\n#endif\n#ifdef USE_SPECULAR_INTENSITYMAP\n	varying vec2 vSpecularIntensityMapUv;\n#endif\n#ifdef USE_TRANSMISSIONMAP\n	uniform mat3 transmissionMapTransform;\n	varying vec2 vTransmissionMapUv;\n#endif\n#ifdef USE_THICKNESSMAP\n	uniform mat3 thicknessMapTransform;\n	varying vec2 vThicknessMapUv;\n#endif";
    uv_pars_vertex = "#if defined( USE_UV ) || defined( USE_ANISOTROPY )\n	varying vec2 vUv;\n#endif\n#ifdef USE_MAP\n	uniform mat3 mapTransform;\n	varying vec2 vMapUv;\n#endif\n#ifdef USE_ALPHAMAP\n	uniform mat3 alphaMapTransform;\n	varying vec2 vAlphaMapUv;\n#endif\n#ifdef USE_LIGHTMAP\n	uniform mat3 lightMapTransform;\n	varying vec2 vLightMapUv;\n#endif\n#ifdef USE_AOMAP\n	uniform mat3 aoMapTransform;\n	varying vec2 vAoMapUv;\n#endif\n#ifdef USE_BUMPMAP\n	uniform mat3 bumpMapTransform;\n	varying vec2 vBumpMapUv;\n#endif\n#ifdef USE_NORMALMAP\n	uniform mat3 normalMapTransform;\n	varying vec2 vNormalMapUv;\n#endif\n#ifdef USE_DISPLACEMENTMAP\n	uniform mat3 displacementMapTransform;\n	varying vec2 vDisplacementMapUv;\n#endif\n#ifdef USE_EMISSIVEMAP\n	uniform mat3 emissiveMapTransform;\n	varying vec2 vEmissiveMapUv;\n#endif\n#ifdef USE_METALNESSMAP\n	uniform mat3 metalnessMapTransform;\n	varying vec2 vMetalnessMapUv;\n#endif\n#ifdef USE_ROUGHNESSMAP\n	uniform mat3 roughnessMapTransform;\n	varying vec2 vRoughnessMapUv;\n#endif\n#ifdef USE_ANISOTROPYMAP\n	uniform mat3 anisotropyMapTransform;\n	varying vec2 vAnisotropyMapUv;\n#endif\n#ifdef USE_CLEARCOATMAP\n	uniform mat3 clearcoatMapTransform;\n	varying vec2 vClearcoatMapUv;\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	uniform mat3 clearcoatNormalMapTransform;\n	varying vec2 vClearcoatNormalMapUv;\n#endif\n#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n	uniform mat3 clearcoatRoughnessMapTransform;\n	varying vec2 vClearcoatRoughnessMapUv;\n#endif\n#ifdef USE_SHEEN_COLORMAP\n	uniform mat3 sheenColorMapTransform;\n	varying vec2 vSheenColorMapUv;\n#endif\n#ifdef USE_SHEEN_ROUGHNESSMAP\n	uniform mat3 sheenRoughnessMapTransform;\n	varying vec2 vSheenRoughnessMapUv;\n#endif\n#ifdef USE_IRIDESCENCEMAP\n	uniform mat3 iridescenceMapTransform;\n	varying vec2 vIridescenceMapUv;\n#endif\n#ifdef USE_IRIDESCENCE_THICKNESSMAP\n	uniform mat3 iridescenceThicknessMapTransform;\n	varying vec2 vIridescenceThicknessMapUv;\n#endif\n#ifdef USE_SPECULARMAP\n	uniform mat3 specularMapTransform;\n	varying vec2 vSpecularMapUv;\n#endif\n#ifdef USE_SPECULAR_COLORMAP\n	uniform mat3 specularColorMapTransform;\n	varying vec2 vSpecularColorMapUv;\n#endif\n#ifdef USE_SPECULAR_INTENSITYMAP\n	uniform mat3 specularIntensityMapTransform;\n	varying vec2 vSpecularIntensityMapUv;\n#endif\n#ifdef USE_TRANSMISSIONMAP\n	uniform mat3 transmissionMapTransform;\n	varying vec2 vTransmissionMapUv;\n#endif\n#ifdef USE_THICKNESSMAP\n	uniform mat3 thicknessMapTransform;\n	varying vec2 vThicknessMapUv;\n#endif";
    uv_vertex = "#if defined( USE_UV ) || defined( USE_ANISOTROPY )\n	vUv = vec3( uv, 1 ).xy;\n#endif\n#ifdef USE_MAP\n	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_ALPHAMAP\n	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_LIGHTMAP\n	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_AOMAP\n	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_BUMPMAP\n	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_NORMALMAP\n	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_DISPLACEMENTMAP\n	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_EMISSIVEMAP\n	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_METALNESSMAP\n	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_ROUGHNESSMAP\n	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_ANISOTROPYMAP\n	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_CLEARCOATMAP\n	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_IRIDESCENCEMAP\n	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_IRIDESCENCE_THICKNESSMAP\n	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SHEEN_COLORMAP\n	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SHEEN_ROUGHNESSMAP\n	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SPECULARMAP\n	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SPECULAR_COLORMAP\n	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SPECULAR_INTENSITYMAP\n	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_TRANSMISSIONMAP\n	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_THICKNESSMAP\n	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;\n#endif";
    worldpos_vertex = "#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0\n	vec4 worldPosition = vec4( transformed, 1.0 );\n	#ifdef USE_BATCHING\n		worldPosition = batchingMatrix * worldPosition;\n	#endif\n	#ifdef USE_INSTANCING\n		worldPosition = instanceMatrix * worldPosition;\n	#endif\n	worldPosition = modelMatrix * worldPosition;\n#endif";
    vertex$h = "varying vec2 vUv;\nuniform mat3 uvTransform;\nvoid main() {\n	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;\n	gl_Position = vec4( position.xy, 1.0, 1.0 );\n}";
    fragment$h = "uniform sampler2D t2D;\nuniform float backgroundIntensity;\nvarying vec2 vUv;\nvoid main() {\n	vec4 texColor = texture2D( t2D, vUv );\n	#ifdef DECODE_VIDEO_TEXTURE\n		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );\n	#endif\n	texColor.rgb *= backgroundIntensity;\n	gl_FragColor = texColor;\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n}";
    vertex$g = "varying vec3 vWorldDirection;\n#include <common>\nvoid main() {\n	vWorldDirection = transformDirection( position, modelMatrix );\n	#include <begin_vertex>\n	#include <project_vertex>\n	gl_Position.z = gl_Position.w;\n}";
    fragment$g = "#ifdef ENVMAP_TYPE_CUBE\n	uniform samplerCube envMap;\n#elif defined( ENVMAP_TYPE_CUBE_UV )\n	uniform sampler2D envMap;\n#endif\nuniform float flipEnvMap;\nuniform float backgroundBlurriness;\nuniform float backgroundIntensity;\nuniform mat3 backgroundRotation;\nvarying vec3 vWorldDirection;\n#include <cube_uv_reflection_fragment>\nvoid main() {\n	#ifdef ENVMAP_TYPE_CUBE\n		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );\n	#elif defined( ENVMAP_TYPE_CUBE_UV )\n		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );\n	#else\n		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );\n	#endif\n	texColor.rgb *= backgroundIntensity;\n	gl_FragColor = texColor;\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n}";
    vertex$f = "varying vec3 vWorldDirection;\n#include <common>\nvoid main() {\n	vWorldDirection = transformDirection( position, modelMatrix );\n	#include <begin_vertex>\n	#include <project_vertex>\n	gl_Position.z = gl_Position.w;\n}";
    fragment$f = "uniform samplerCube tCube;\nuniform float tFlip;\nuniform float opacity;\nvarying vec3 vWorldDirection;\nvoid main() {\n	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );\n	gl_FragColor = texColor;\n	gl_FragColor.a *= opacity;\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n}";
    vertex$e = "#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvarying vec2 vHighPrecisionZW;\nvoid main() {\n	#include <uv_vertex>\n	#include <batching_vertex>\n	#include <skinbase_vertex>\n	#include <morphinstance_vertex>\n	#ifdef USE_DISPLACEMENTMAP\n		#include <beginnormal_vertex>\n		#include <morphnormal_vertex>\n		#include <skinnormal_vertex>\n	#endif\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vHighPrecisionZW = gl_Position.zw;\n}";
    fragment$e = "#if DEPTH_PACKING == 3200\n	uniform float opacity;\n#endif\n#include <common>\n#include <packing>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvarying vec2 vHighPrecisionZW;\nvoid main() {\n	vec4 diffuseColor = vec4( 1.0 );\n	#include <clipping_planes_fragment>\n	#if DEPTH_PACKING == 3200\n		diffuseColor.a = opacity;\n	#endif\n	#include <map_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <logdepthbuf_fragment>\n	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;\n	#if DEPTH_PACKING == 3200\n		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );\n	#elif DEPTH_PACKING == 3201\n		gl_FragColor = packDepthToRGBA( fragCoordZ );\n	#elif DEPTH_PACKING == 3202\n		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );\n	#elif DEPTH_PACKING == 3203\n		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );\n	#endif\n}";
    vertex$d = "#define DISTANCE\nvarying vec3 vWorldPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <batching_vertex>\n	#include <skinbase_vertex>\n	#include <morphinstance_vertex>\n	#ifdef USE_DISPLACEMENTMAP\n		#include <beginnormal_vertex>\n		#include <morphnormal_vertex>\n		#include <skinnormal_vertex>\n	#endif\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <worldpos_vertex>\n	#include <clipping_planes_vertex>\n	vWorldPosition = worldPosition.xyz;\n}";
    fragment$d = "#define DISTANCE\nuniform vec3 referencePosition;\nuniform float nearDistance;\nuniform float farDistance;\nvarying vec3 vWorldPosition;\n#include <common>\n#include <packing>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main () {\n	vec4 diffuseColor = vec4( 1.0 );\n	#include <clipping_planes_fragment>\n	#include <map_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	float dist = length( vWorldPosition - referencePosition );\n	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );\n	dist = saturate( dist );\n	gl_FragColor = packDepthToRGBA( dist );\n}";
    vertex$c = "varying vec3 vWorldDirection;\n#include <common>\nvoid main() {\n	vWorldDirection = transformDirection( position, modelMatrix );\n	#include <begin_vertex>\n	#include <project_vertex>\n}";
    fragment$c = "uniform sampler2D tEquirect;\nvarying vec3 vWorldDirection;\n#include <common>\nvoid main() {\n	vec3 direction = normalize( vWorldDirection );\n	vec2 sampleUV = equirectUv( direction );\n	gl_FragColor = texture2D( tEquirect, sampleUV );\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n}";
    vertex$b = "uniform float scale;\nattribute float lineDistance;\nvarying float vLineDistance;\n#include <common>\n#include <uv_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	vLineDistance = scale * lineDistance;\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <fog_vertex>\n}";
    fragment$b = "uniform vec3 diffuse;\nuniform float opacity;\nuniform float dashSize;\nuniform float totalSize;\nvarying float vLineDistance;\n#include <common>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <fog_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	if ( mod( vLineDistance, totalSize ) > dashSize ) {\n		discard;\n	}\n	vec3 outgoingLight = vec3( 0.0 );\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	outgoingLight = diffuseColor.rgb;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n}";
    vertex$a = "#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <envmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )\n		#include <beginnormal_vertex>\n		#include <morphnormal_vertex>\n		#include <skinbase_vertex>\n		#include <skinnormal_vertex>\n		#include <defaultnormal_vertex>\n	#endif\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <worldpos_vertex>\n	#include <envmap_vertex>\n	#include <fog_vertex>\n}";
    fragment$a = "uniform vec3 diffuse;\nuniform float opacity;\n#ifndef FLAT_SHADED\n	varying vec3 vNormal;\n#endif\n#include <common>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <envmap_common_pars_fragment>\n#include <envmap_pars_fragment>\n#include <fog_pars_fragment>\n#include <specularmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <specularmap_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	#ifdef USE_LIGHTMAP\n		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );\n		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;\n	#else\n		reflectedLight.indirectDiffuse += vec3( 1.0 );\n	#endif\n	#include <aomap_fragment>\n	reflectedLight.indirectDiffuse *= diffuseColor.rgb;\n	vec3 outgoingLight = reflectedLight.indirectDiffuse;\n	#include <envmap_fragment>\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}";
    vertex$9 = "#define LAMBERT\nvarying vec3 vViewPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <envmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <shadowmap_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vViewPosition = - mvPosition.xyz;\n	#include <worldpos_vertex>\n	#include <envmap_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n}";
    fragment$9 = "#define LAMBERT\nuniform vec3 diffuse;\nuniform vec3 emissive;\nuniform float opacity;\n#include <common>\n#include <packing>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <emissivemap_pars_fragment>\n#include <envmap_common_pars_fragment>\n#include <envmap_pars_fragment>\n#include <fog_pars_fragment>\n#include <bsdfs>\n#include <lights_pars_begin>\n#include <normal_pars_fragment>\n#include <lights_lambert_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <specularmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	vec3 totalEmissiveRadiance = emissive;\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <specularmap_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	#include <emissivemap_fragment>\n	#include <lights_lambert_fragment>\n	#include <lights_fragment_begin>\n	#include <lights_fragment_maps>\n	#include <lights_fragment_end>\n	#include <aomap_fragment>\n	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;\n	#include <envmap_fragment>\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}";
    vertex$8 = "#define MATCAP\nvarying vec3 vViewPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <color_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <fog_vertex>\n	vViewPosition = - mvPosition.xyz;\n}";
    fragment$8 = "#define MATCAP\nuniform vec3 diffuse;\nuniform float opacity;\nuniform sampler2D matcap;\nvarying vec3 vViewPosition;\n#include <common>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <fog_pars_fragment>\n#include <normal_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	vec3 viewDir = normalize( vViewPosition );\n	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );\n	vec3 y = cross( viewDir, x );\n	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;\n	#ifdef USE_MATCAP\n		vec4 matcapColor = texture2D( matcap, uv );\n	#else\n		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );\n	#endif\n	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}";
    vertex$7 = "#define NORMAL\n#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )\n	varying vec3 vViewPosition;\n#endif\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphinstance_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )\n	vViewPosition = - mvPosition.xyz;\n#endif\n}";
    fragment$7 = "#define NORMAL\nuniform float opacity;\n#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )\n	varying vec3 vViewPosition;\n#endif\n#include <packing>\n#include <uv_pars_fragment>\n#include <normal_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );\n	#include <clipping_planes_fragment>\n	#include <logdepthbuf_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );\n	#ifdef OPAQUE\n		gl_FragColor.a = 1.0;\n	#endif\n}";
    vertex$6 = "#define PHONG\nvarying vec3 vViewPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <envmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <shadowmap_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphinstance_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vViewPosition = - mvPosition.xyz;\n	#include <worldpos_vertex>\n	#include <envmap_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n}";
    fragment$6 = "#define PHONG\nuniform vec3 diffuse;\nuniform vec3 emissive;\nuniform vec3 specular;\nuniform float shininess;\nuniform float opacity;\n#include <common>\n#include <packing>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <emissivemap_pars_fragment>\n#include <envmap_common_pars_fragment>\n#include <envmap_pars_fragment>\n#include <fog_pars_fragment>\n#include <bsdfs>\n#include <lights_pars_begin>\n#include <normal_pars_fragment>\n#include <lights_phong_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <specularmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	vec3 totalEmissiveRadiance = emissive;\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <specularmap_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	#include <emissivemap_fragment>\n	#include <lights_phong_fragment>\n	#include <lights_fragment_begin>\n	#include <lights_fragment_maps>\n	#include <lights_fragment_end>\n	#include <aomap_fragment>\n	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;\n	#include <envmap_fragment>\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}";
    vertex$5 = "#define STANDARD\nvarying vec3 vViewPosition;\n#ifdef USE_TRANSMISSION\n	varying vec3 vWorldPosition;\n#endif\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <shadowmap_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vViewPosition = - mvPosition.xyz;\n	#include <worldpos_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n#ifdef USE_TRANSMISSION\n	vWorldPosition = worldPosition.xyz;\n#endif\n}";
    fragment$5 = "#define STANDARD\n#ifdef PHYSICAL\n	#define IOR\n	#define USE_SPECULAR\n#endif\nuniform vec3 diffuse;\nuniform vec3 emissive;\nuniform float roughness;\nuniform float metalness;\nuniform float opacity;\n#ifdef IOR\n	uniform float ior;\n#endif\n#ifdef USE_SPECULAR\n	uniform float specularIntensity;\n	uniform vec3 specularColor;\n	#ifdef USE_SPECULAR_COLORMAP\n		uniform sampler2D specularColorMap;\n	#endif\n	#ifdef USE_SPECULAR_INTENSITYMAP\n		uniform sampler2D specularIntensityMap;\n	#endif\n#endif\n#ifdef USE_CLEARCOAT\n	uniform float clearcoat;\n	uniform float clearcoatRoughness;\n#endif\n#ifdef USE_DISPERSION\n	uniform float dispersion;\n#endif\n#ifdef USE_IRIDESCENCE\n	uniform float iridescence;\n	uniform float iridescenceIOR;\n	uniform float iridescenceThicknessMinimum;\n	uniform float iridescenceThicknessMaximum;\n#endif\n#ifdef USE_SHEEN\n	uniform vec3 sheenColor;\n	uniform float sheenRoughness;\n	#ifdef USE_SHEEN_COLORMAP\n		uniform sampler2D sheenColorMap;\n	#endif\n	#ifdef USE_SHEEN_ROUGHNESSMAP\n		uniform sampler2D sheenRoughnessMap;\n	#endif\n#endif\n#ifdef USE_ANISOTROPY\n	uniform vec2 anisotropyVector;\n	#ifdef USE_ANISOTROPYMAP\n		uniform sampler2D anisotropyMap;\n	#endif\n#endif\nvarying vec3 vViewPosition;\n#include <common>\n#include <packing>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <emissivemap_pars_fragment>\n#include <iridescence_fragment>\n#include <cube_uv_reflection_fragment>\n#include <envmap_common_pars_fragment>\n#include <envmap_physical_pars_fragment>\n#include <fog_pars_fragment>\n#include <lights_pars_begin>\n#include <normal_pars_fragment>\n#include <lights_physical_pars_fragment>\n#include <transmission_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <clearcoat_pars_fragment>\n#include <iridescence_pars_fragment>\n#include <roughnessmap_pars_fragment>\n#include <metalnessmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	vec3 totalEmissiveRadiance = emissive;\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <roughnessmap_fragment>\n	#include <metalnessmap_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	#include <clearcoat_normal_fragment_begin>\n	#include <clearcoat_normal_fragment_maps>\n	#include <emissivemap_fragment>\n	#include <lights_physical_fragment>\n	#include <lights_fragment_begin>\n	#include <lights_fragment_maps>\n	#include <lights_fragment_end>\n	#include <aomap_fragment>\n	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;\n	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;\n	#include <transmission_fragment>\n	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;\n	#ifdef USE_SHEEN\n		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );\n		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;\n	#endif\n	#ifdef USE_CLEARCOAT\n		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );\n		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );\n		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;\n	#endif\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}";
    vertex$4 = "#define TOON\nvarying vec3 vViewPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <shadowmap_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vViewPosition = - mvPosition.xyz;\n	#include <worldpos_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n}";
    fragment$4 = "#define TOON\nuniform vec3 diffuse;\nuniform vec3 emissive;\nuniform float opacity;\n#include <common>\n#include <packing>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <emissivemap_pars_fragment>\n#include <gradientmap_pars_fragment>\n#include <fog_pars_fragment>\n#include <bsdfs>\n#include <lights_pars_begin>\n#include <normal_pars_fragment>\n#include <lights_toon_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	vec3 totalEmissiveRadiance = emissive;\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	#include <emissivemap_fragment>\n	#include <lights_toon_fragment>\n	#include <lights_fragment_begin>\n	#include <lights_fragment_maps>\n	#include <lights_fragment_end>\n	#include <aomap_fragment>\n	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}";
    vertex$3 = "uniform float size;\nuniform float scale;\n#include <common>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\n#ifdef USE_POINTS_UV\n	varying vec2 vUv;\n	uniform mat3 uvTransform;\n#endif\nvoid main() {\n	#ifdef USE_POINTS_UV\n		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;\n	#endif\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <project_vertex>\n	gl_PointSize = size;\n	#ifdef USE_SIZEATTENUATION\n		bool isPerspective = isPerspectiveMatrix( projectionMatrix );\n		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );\n	#endif\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <worldpos_vertex>\n	#include <fog_vertex>\n}";
    fragment$3 = "uniform vec3 diffuse;\nuniform float opacity;\n#include <common>\n#include <color_pars_fragment>\n#include <map_particle_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <fog_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	vec3 outgoingLight = vec3( 0.0 );\n	#include <logdepthbuf_fragment>\n	#include <map_particle_fragment>\n	#include <color_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	outgoingLight = diffuseColor.rgb;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n}";
    vertex$2 = "#include <common>\n#include <batching_pars_vertex>\n#include <fog_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <shadowmap_pars_vertex>\nvoid main() {\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphinstance_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <worldpos_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n}";
    fragment$2 = "uniform vec3 color;\nuniform float opacity;\n#include <common>\n#include <packing>\n#include <fog_pars_fragment>\n#include <bsdfs>\n#include <lights_pars_begin>\n#include <logdepthbuf_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <shadowmask_pars_fragment>\nvoid main() {\n	#include <logdepthbuf_fragment>\n	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n}";
    vertex$1 = "uniform float rotation;\nuniform vec2 center;\n#include <common>\n#include <uv_pars_vertex>\n#include <fog_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	vec4 mvPosition = modelViewMatrix[ 3 ];\n	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );\n	#ifndef USE_SIZEATTENUATION\n		bool isPerspective = isPerspectiveMatrix( projectionMatrix );\n		if ( isPerspective ) scale *= - mvPosition.z;\n	#endif\n	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;\n	vec2 rotatedPosition;\n	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;\n	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;\n	mvPosition.xy += rotatedPosition;\n	gl_Position = projectionMatrix * mvPosition;\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <fog_vertex>\n}";
    fragment$1 = "uniform vec3 diffuse;\nuniform float opacity;\n#include <common>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <fog_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	vec3 outgoingLight = vec3( 0.0 );\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	outgoingLight = diffuseColor.rgb;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n}";
    ShaderChunk = {
      alphahash_fragment,
      alphahash_pars_fragment,
      alphamap_fragment,
      alphamap_pars_fragment,
      alphatest_fragment,
      alphatest_pars_fragment,
      aomap_fragment,
      aomap_pars_fragment,
      batching_pars_vertex,
      batching_vertex,
      begin_vertex,
      beginnormal_vertex,
      bsdfs,
      iridescence_fragment,
      bumpmap_pars_fragment,
      clipping_planes_fragment,
      clipping_planes_pars_fragment,
      clipping_planes_pars_vertex,
      clipping_planes_vertex,
      color_fragment,
      color_pars_fragment,
      color_pars_vertex,
      color_vertex,
      common,
      cube_uv_reflection_fragment,
      defaultnormal_vertex,
      displacementmap_pars_vertex,
      displacementmap_vertex,
      emissivemap_fragment,
      emissivemap_pars_fragment,
      colorspace_fragment,
      colorspace_pars_fragment,
      envmap_fragment,
      envmap_common_pars_fragment,
      envmap_pars_fragment,
      envmap_pars_vertex,
      envmap_physical_pars_fragment,
      envmap_vertex,
      fog_vertex,
      fog_pars_vertex,
      fog_fragment,
      fog_pars_fragment,
      gradientmap_pars_fragment,
      lightmap_pars_fragment,
      lights_lambert_fragment,
      lights_lambert_pars_fragment,
      lights_pars_begin,
      lights_toon_fragment,
      lights_toon_pars_fragment,
      lights_phong_fragment,
      lights_phong_pars_fragment,
      lights_physical_fragment,
      lights_physical_pars_fragment,
      lights_fragment_begin,
      lights_fragment_maps,
      lights_fragment_end,
      logdepthbuf_fragment,
      logdepthbuf_pars_fragment,
      logdepthbuf_pars_vertex,
      logdepthbuf_vertex,
      map_fragment,
      map_pars_fragment,
      map_particle_fragment,
      map_particle_pars_fragment,
      metalnessmap_fragment,
      metalnessmap_pars_fragment,
      morphinstance_vertex,
      morphcolor_vertex,
      morphnormal_vertex,
      morphtarget_pars_vertex,
      morphtarget_vertex,
      normal_fragment_begin,
      normal_fragment_maps,
      normal_pars_fragment,
      normal_pars_vertex,
      normal_vertex,
      normalmap_pars_fragment,
      clearcoat_normal_fragment_begin,
      clearcoat_normal_fragment_maps,
      clearcoat_pars_fragment,
      iridescence_pars_fragment,
      opaque_fragment,
      packing,
      premultiplied_alpha_fragment,
      project_vertex,
      dithering_fragment,
      dithering_pars_fragment,
      roughnessmap_fragment,
      roughnessmap_pars_fragment,
      shadowmap_pars_fragment,
      shadowmap_pars_vertex,
      shadowmap_vertex,
      shadowmask_pars_fragment,
      skinbase_vertex,
      skinning_pars_vertex,
      skinning_vertex,
      skinnormal_vertex,
      specularmap_fragment,
      specularmap_pars_fragment,
      tonemapping_fragment,
      tonemapping_pars_fragment,
      transmission_fragment,
      transmission_pars_fragment,
      uv_pars_fragment,
      uv_pars_vertex,
      uv_vertex,
      worldpos_vertex,
      background_vert: vertex$h,
      background_frag: fragment$h,
      backgroundCube_vert: vertex$g,
      backgroundCube_frag: fragment$g,
      cube_vert: vertex$f,
      cube_frag: fragment$f,
      depth_vert: vertex$e,
      depth_frag: fragment$e,
      distanceRGBA_vert: vertex$d,
      distanceRGBA_frag: fragment$d,
      equirect_vert: vertex$c,
      equirect_frag: fragment$c,
      linedashed_vert: vertex$b,
      linedashed_frag: fragment$b,
      meshbasic_vert: vertex$a,
      meshbasic_frag: fragment$a,
      meshlambert_vert: vertex$9,
      meshlambert_frag: fragment$9,
      meshmatcap_vert: vertex$8,
      meshmatcap_frag: fragment$8,
      meshnormal_vert: vertex$7,
      meshnormal_frag: fragment$7,
      meshphong_vert: vertex$6,
      meshphong_frag: fragment$6,
      meshphysical_vert: vertex$5,
      meshphysical_frag: fragment$5,
      meshtoon_vert: vertex$4,
      meshtoon_frag: fragment$4,
      points_vert: vertex$3,
      points_frag: fragment$3,
      shadow_vert: vertex$2,
      shadow_frag: fragment$2,
      sprite_vert: vertex$1,
      sprite_frag: fragment$1
    };
    UniformsLib = {
      common: {
        diffuse: { value: /* @__PURE__ */ new Color(16777215) },
        opacity: { value: 1 },
        map: { value: null },
        mapTransform: { value: /* @__PURE__ */ new Matrix3() },
        alphaMap: { value: null },
        alphaMapTransform: { value: /* @__PURE__ */ new Matrix3() },
        alphaTest: { value: 0 }
      },
      specularmap: {
        specularMap: { value: null },
        specularMapTransform: { value: /* @__PURE__ */ new Matrix3() }
      },
      envmap: {
        envMap: { value: null },
        envMapRotation: { value: /* @__PURE__ */ new Matrix3() },
        flipEnvMap: { value: -1 },
        reflectivity: { value: 1 },
        // basic, lambert, phong
        ior: { value: 1.5 },
        // physical
        refractionRatio: { value: 0.98 }
        // basic, lambert, phong
      },
      aomap: {
        aoMap: { value: null },
        aoMapIntensity: { value: 1 },
        aoMapTransform: { value: /* @__PURE__ */ new Matrix3() }
      },
      lightmap: {
        lightMap: { value: null },
        lightMapIntensity: { value: 1 },
        lightMapTransform: { value: /* @__PURE__ */ new Matrix3() }
      },
      bumpmap: {
        bumpMap: { value: null },
        bumpMapTransform: { value: /* @__PURE__ */ new Matrix3() },
        bumpScale: { value: 1 }
      },
      normalmap: {
        normalMap: { value: null },
        normalMapTransform: { value: /* @__PURE__ */ new Matrix3() },
        normalScale: { value: /* @__PURE__ */ new Vector2(1, 1) }
      },
      displacementmap: {
        displacementMap: { value: null },
        displacementMapTransform: { value: /* @__PURE__ */ new Matrix3() },
        displacementScale: { value: 1 },
        displacementBias: { value: 0 }
      },
      emissivemap: {
        emissiveMap: { value: null },
        emissiveMapTransform: { value: /* @__PURE__ */ new Matrix3() }
      },
      metalnessmap: {
        metalnessMap: { value: null },
        metalnessMapTransform: { value: /* @__PURE__ */ new Matrix3() }
      },
      roughnessmap: {
        roughnessMap: { value: null },
        roughnessMapTransform: { value: /* @__PURE__ */ new Matrix3() }
      },
      gradientmap: {
        gradientMap: { value: null }
      },
      fog: {
        fogDensity: { value: 25e-5 },
        fogNear: { value: 1 },
        fogFar: { value: 2e3 },
        fogColor: { value: /* @__PURE__ */ new Color(16777215) }
      },
      lights: {
        ambientLightColor: { value: [] },
        lightProbe: { value: [] },
        directionalLights: { value: [], properties: {
          direction: {},
          color: {}
        } },
        directionalLightShadows: { value: [], properties: {
          shadowIntensity: 1,
          shadowBias: {},
          shadowNormalBias: {},
          shadowRadius: {},
          shadowMapSize: {}
        } },
        directionalShadowMap: { value: [] },
        directionalShadowMatrix: { value: [] },
        spotLights: { value: [], properties: {
          color: {},
          position: {},
          direction: {},
          distance: {},
          coneCos: {},
          penumbraCos: {},
          decay: {}
        } },
        spotLightShadows: { value: [], properties: {
          shadowIntensity: 1,
          shadowBias: {},
          shadowNormalBias: {},
          shadowRadius: {},
          shadowMapSize: {}
        } },
        spotLightMap: { value: [] },
        spotShadowMap: { value: [] },
        spotLightMatrix: { value: [] },
        pointLights: { value: [], properties: {
          color: {},
          position: {},
          decay: {},
          distance: {}
        } },
        pointLightShadows: { value: [], properties: {
          shadowIntensity: 1,
          shadowBias: {},
          shadowNormalBias: {},
          shadowRadius: {},
          shadowMapSize: {},
          shadowCameraNear: {},
          shadowCameraFar: {}
        } },
        pointShadowMap: { value: [] },
        pointShadowMatrix: { value: [] },
        hemisphereLights: { value: [], properties: {
          direction: {},
          skyColor: {},
          groundColor: {}
        } },
        // TODO (abelnation): RectAreaLight BRDF data needs to be moved from example to main src
        rectAreaLights: { value: [], properties: {
          color: {},
          position: {},
          width: {},
          height: {}
        } },
        ltc_1: { value: null },
        ltc_2: { value: null }
      },
      points: {
        diffuse: { value: /* @__PURE__ */ new Color(16777215) },
        opacity: { value: 1 },
        size: { value: 1 },
        scale: { value: 1 },
        map: { value: null },
        alphaMap: { value: null },
        alphaMapTransform: { value: /* @__PURE__ */ new Matrix3() },
        alphaTest: { value: 0 },
        uvTransform: { value: /* @__PURE__ */ new Matrix3() }
      },
      sprite: {
        diffuse: { value: /* @__PURE__ */ new Color(16777215) },
        opacity: { value: 1 },
        center: { value: /* @__PURE__ */ new Vector2(0.5, 0.5) },
        rotation: { value: 0 },
        map: { value: null },
        mapTransform: { value: /* @__PURE__ */ new Matrix3() },
        alphaMap: { value: null },
        alphaMapTransform: { value: /* @__PURE__ */ new Matrix3() },
        alphaTest: { value: 0 }
      }
    };
    ShaderLib = {
      basic: {
        uniforms: /* @__PURE__ */ mergeUniforms([
          UniformsLib.common,
          UniformsLib.specularmap,
          UniformsLib.envmap,
          UniformsLib.aomap,
          UniformsLib.lightmap,
          UniformsLib.fog
        ]),
        vertexShader: ShaderChunk.meshbasic_vert,
        fragmentShader: ShaderChunk.meshbasic_frag
      },
      lambert: {
        uniforms: /* @__PURE__ */ mergeUniforms([
          UniformsLib.common,
          UniformsLib.specularmap,
          UniformsLib.envmap,
          UniformsLib.aomap,
          UniformsLib.lightmap,
          UniformsLib.emissivemap,
          UniformsLib.bumpmap,
          UniformsLib.normalmap,
          UniformsLib.displacementmap,
          UniformsLib.fog,
          UniformsLib.lights,
          {
            emissive: { value: /* @__PURE__ */ new Color(0) }
          }
        ]),
        vertexShader: ShaderChunk.meshlambert_vert,
        fragmentShader: ShaderChunk.meshlambert_frag
      },
      phong: {
        uniforms: /* @__PURE__ */ mergeUniforms([
          UniformsLib.common,
          UniformsLib.specularmap,
          UniformsLib.envmap,
          UniformsLib.aomap,
          UniformsLib.lightmap,
          UniformsLib.emissivemap,
          UniformsLib.bumpmap,
          UniformsLib.normalmap,
          UniformsLib.displacementmap,
          UniformsLib.fog,
          UniformsLib.lights,
          {
            emissive: { value: /* @__PURE__ */ new Color(0) },
            specular: { value: /* @__PURE__ */ new Color(1118481) },
            shininess: { value: 30 }
          }
        ]),
        vertexShader: ShaderChunk.meshphong_vert,
        fragmentShader: ShaderChunk.meshphong_frag
      },
      standard: {
        uniforms: /* @__PURE__ */ mergeUniforms([
          UniformsLib.common,
          UniformsLib.envmap,
          UniformsLib.aomap,
          UniformsLib.lightmap,
          UniformsLib.emissivemap,
          UniformsLib.bumpmap,
          UniformsLib.normalmap,
          UniformsLib.displacementmap,
          UniformsLib.roughnessmap,
          UniformsLib.metalnessmap,
          UniformsLib.fog,
          UniformsLib.lights,
          {
            emissive: { value: /* @__PURE__ */ new Color(0) },
            roughness: { value: 1 },
            metalness: { value: 0 },
            envMapIntensity: { value: 1 }
          }
        ]),
        vertexShader: ShaderChunk.meshphysical_vert,
        fragmentShader: ShaderChunk.meshphysical_frag
      },
      toon: {
        uniforms: /* @__PURE__ */ mergeUniforms([
          UniformsLib.common,
          UniformsLib.aomap,
          UniformsLib.lightmap,
          UniformsLib.emissivemap,
          UniformsLib.bumpmap,
          UniformsLib.normalmap,
          UniformsLib.displacementmap,
          UniformsLib.gradientmap,
          UniformsLib.fog,
          UniformsLib.lights,
          {
            emissive: { value: /* @__PURE__ */ new Color(0) }
          }
        ]),
        vertexShader: ShaderChunk.meshtoon_vert,
        fragmentShader: ShaderChunk.meshtoon_frag
      },
      matcap: {
        uniforms: /* @__PURE__ */ mergeUniforms([
          UniformsLib.common,
          UniformsLib.bumpmap,
          UniformsLib.normalmap,
          UniformsLib.displacementmap,
          UniformsLib.fog,
          {
            matcap: { value: null }
          }
        ]),
        vertexShader: ShaderChunk.meshmatcap_vert,
        fragmentShader: ShaderChunk.meshmatcap_frag
      },
      points: {
        uniforms: /* @__PURE__ */ mergeUniforms([
          UniformsLib.points,
          UniformsLib.fog
        ]),
        vertexShader: ShaderChunk.points_vert,
        fragmentShader: ShaderChunk.points_frag
      },
      dashed: {
        uniforms: /* @__PURE__ */ mergeUniforms([
          UniformsLib.common,
          UniformsLib.fog,
          {
            scale: { value: 1 },
            dashSize: { value: 1 },
            totalSize: { value: 2 }
          }
        ]),
        vertexShader: ShaderChunk.linedashed_vert,
        fragmentShader: ShaderChunk.linedashed_frag
      },
      depth: {
        uniforms: /* @__PURE__ */ mergeUniforms([
          UniformsLib.common,
          UniformsLib.displacementmap
        ]),
        vertexShader: ShaderChunk.depth_vert,
        fragmentShader: ShaderChunk.depth_frag
      },
      normal: {
        uniforms: /* @__PURE__ */ mergeUniforms([
          UniformsLib.common,
          UniformsLib.bumpmap,
          UniformsLib.normalmap,
          UniformsLib.displacementmap,
          {
            opacity: { value: 1 }
          }
        ]),
        vertexShader: ShaderChunk.meshnormal_vert,
        fragmentShader: ShaderChunk.meshnormal_frag
      },
      sprite: {
        uniforms: /* @__PURE__ */ mergeUniforms([
          UniformsLib.sprite,
          UniformsLib.fog
        ]),
        vertexShader: ShaderChunk.sprite_vert,
        fragmentShader: ShaderChunk.sprite_frag
      },
      background: {
        uniforms: {
          uvTransform: { value: /* @__PURE__ */ new Matrix3() },
          t2D: { value: null },
          backgroundIntensity: { value: 1 }
        },
        vertexShader: ShaderChunk.background_vert,
        fragmentShader: ShaderChunk.background_frag
      },
      backgroundCube: {
        uniforms: {
          envMap: { value: null },
          flipEnvMap: { value: -1 },
          backgroundBlurriness: { value: 0 },
          backgroundIntensity: { value: 1 },
          backgroundRotation: { value: /* @__PURE__ */ new Matrix3() }
        },
        vertexShader: ShaderChunk.backgroundCube_vert,
        fragmentShader: ShaderChunk.backgroundCube_frag
      },
      cube: {
        uniforms: {
          tCube: { value: null },
          tFlip: { value: -1 },
          opacity: { value: 1 }
        },
        vertexShader: ShaderChunk.cube_vert,
        fragmentShader: ShaderChunk.cube_frag
      },
      equirect: {
        uniforms: {
          tEquirect: { value: null }
        },
        vertexShader: ShaderChunk.equirect_vert,
        fragmentShader: ShaderChunk.equirect_frag
      },
      distanceRGBA: {
        uniforms: /* @__PURE__ */ mergeUniforms([
          UniformsLib.common,
          UniformsLib.displacementmap,
          {
            referencePosition: { value: /* @__PURE__ */ new Vector3() },
            nearDistance: { value: 1 },
            farDistance: { value: 1e3 }
          }
        ]),
        vertexShader: ShaderChunk.distanceRGBA_vert,
        fragmentShader: ShaderChunk.distanceRGBA_frag
      },
      shadow: {
        uniforms: /* @__PURE__ */ mergeUniforms([
          UniformsLib.lights,
          UniformsLib.fog,
          {
            color: { value: /* @__PURE__ */ new Color(0) },
            opacity: { value: 1 }
          }
        ]),
        vertexShader: ShaderChunk.shadow_vert,
        fragmentShader: ShaderChunk.shadow_frag
      }
    };
    ShaderLib.physical = {
      uniforms: /* @__PURE__ */ mergeUniforms([
        ShaderLib.standard.uniforms,
        {
          clearcoat: { value: 0 },
          clearcoatMap: { value: null },
          clearcoatMapTransform: { value: /* @__PURE__ */ new Matrix3() },
          clearcoatNormalMap: { value: null },
          clearcoatNormalMapTransform: { value: /* @__PURE__ */ new Matrix3() },
          clearcoatNormalScale: { value: /* @__PURE__ */ new Vector2(1, 1) },
          clearcoatRoughness: { value: 0 },
          clearcoatRoughnessMap: { value: null },
          clearcoatRoughnessMapTransform: { value: /* @__PURE__ */ new Matrix3() },
          dispersion: { value: 0 },
          iridescence: { value: 0 },
          iridescenceMap: { value: null },
          iridescenceMapTransform: { value: /* @__PURE__ */ new Matrix3() },
          iridescenceIOR: { value: 1.3 },
          iridescenceThicknessMinimum: { value: 100 },
          iridescenceThicknessMaximum: { value: 400 },
          iridescenceThicknessMap: { value: null },
          iridescenceThicknessMapTransform: { value: /* @__PURE__ */ new Matrix3() },
          sheen: { value: 0 },
          sheenColor: { value: /* @__PURE__ */ new Color(0) },
          sheenColorMap: { value: null },
          sheenColorMapTransform: { value: /* @__PURE__ */ new Matrix3() },
          sheenRoughness: { value: 1 },
          sheenRoughnessMap: { value: null },
          sheenRoughnessMapTransform: { value: /* @__PURE__ */ new Matrix3() },
          transmission: { value: 0 },
          transmissionMap: { value: null },
          transmissionMapTransform: { value: /* @__PURE__ */ new Matrix3() },
          transmissionSamplerSize: { value: /* @__PURE__ */ new Vector2() },
          transmissionSamplerMap: { value: null },
          thickness: { value: 0 },
          thicknessMap: { value: null },
          thicknessMapTransform: { value: /* @__PURE__ */ new Matrix3() },
          attenuationDistance: { value: 0 },
          attenuationColor: { value: /* @__PURE__ */ new Color(0) },
          specularColor: { value: /* @__PURE__ */ new Color(1, 1, 1) },
          specularColorMap: { value: null },
          specularColorMapTransform: { value: /* @__PURE__ */ new Matrix3() },
          specularIntensity: { value: 1 },
          specularIntensityMap: { value: null },
          specularIntensityMapTransform: { value: /* @__PURE__ */ new Matrix3() },
          anisotropyVector: { value: /* @__PURE__ */ new Vector2() },
          anisotropyMap: { value: null },
          anisotropyMapTransform: { value: /* @__PURE__ */ new Matrix3() }
        }
      ]),
      vertexShader: ShaderChunk.meshphysical_vert,
      fragmentShader: ShaderChunk.meshphysical_frag
    };
    PHI = (1 + Math.sqrt(5)) / 2;
    INV_PHI = 1 / PHI;
    _axisDirections = [
      /* @__PURE__ */ new Vector3(-PHI, INV_PHI, 0),
      /* @__PURE__ */ new Vector3(PHI, INV_PHI, 0),
      /* @__PURE__ */ new Vector3(-INV_PHI, 0, PHI),
      /* @__PURE__ */ new Vector3(INV_PHI, 0, PHI),
      /* @__PURE__ */ new Vector3(0, PHI, -INV_PHI),
      /* @__PURE__ */ new Vector3(0, PHI, INV_PHI),
      /* @__PURE__ */ new Vector3(-1, 1, -1),
      /* @__PURE__ */ new Vector3(1, 1, -1),
      /* @__PURE__ */ new Vector3(-1, 1, 1),
      /* @__PURE__ */ new Vector3(1, 1, 1)
    ];
    mat4array = new Float32Array(16);
    mat3array = new Float32Array(9);
    mat2array = new Float32Array(4);
    reversedFuncs = {
      [NeverDepth]: AlwaysDepth,
      [LessDepth]: GreaterDepth,
      [EqualDepth]: NotEqualDepth,
      [LessEqualDepth]: GreaterEqualDepth,
      [AlwaysDepth]: NeverDepth,
      [GreaterDepth]: LessDepth,
      [NotEqualDepth]: EqualDepth,
      [GreaterEqualDepth]: LessEqualDepth
    };
    Group = class extends Object3D {
      constructor() {
        super();
        this.isGroup = true;
        this.type = "Group";
      }
    };
    Scene = class extends Object3D {
      constructor() {
        super();
        this.isScene = true;
        this.type = "Scene";
        this.background = null;
        this.environment = null;
        this.fog = null;
        this.backgroundBlurriness = 0;
        this.backgroundIntensity = 1;
        this.backgroundRotation = new Euler();
        this.environmentIntensity = 1;
        this.environmentRotation = new Euler();
        this.overrideMaterial = null;
        if (typeof __THREE_DEVTOOLS__ !== "undefined") {
          __THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe", { detail: this }));
        }
      }
      copy(source, recursive) {
        super.copy(source, recursive);
        if (source.background !== null) this.background = source.background.clone();
        if (source.environment !== null) this.environment = source.environment.clone();
        if (source.fog !== null) this.fog = source.fog.clone();
        this.backgroundBlurriness = source.backgroundBlurriness;
        this.backgroundIntensity = source.backgroundIntensity;
        this.backgroundRotation.copy(source.backgroundRotation);
        this.environmentIntensity = source.environmentIntensity;
        this.environmentRotation.copy(source.environmentRotation);
        if (source.overrideMaterial !== null) this.overrideMaterial = source.overrideMaterial.clone();
        this.matrixAutoUpdate = source.matrixAutoUpdate;
        return this;
      }
      toJSON(meta) {
        const data = super.toJSON(meta);
        if (this.fog !== null) data.object.fog = this.fog.toJSON();
        if (this.backgroundBlurriness > 0) data.object.backgroundBlurriness = this.backgroundBlurriness;
        if (this.backgroundIntensity !== 1) data.object.backgroundIntensity = this.backgroundIntensity;
        data.object.backgroundRotation = this.backgroundRotation.toArray();
        if (this.environmentIntensity !== 1) data.object.environmentIntensity = this.environmentIntensity;
        data.object.environmentRotation = this.environmentRotation.toArray();
        return data;
      }
    };
    CanvasTexture = class extends Texture {
      constructor(canvas, mapping, wrapS, wrapT, magFilter, minFilter, format, type, anisotropy) {
        super(canvas, mapping, wrapS, wrapT, magFilter, minFilter, format, type, anisotropy);
        this.isCanvasTexture = true;
        this.needsUpdate = true;
      }
    };
    CylinderGeometry = class _CylinderGeometry extends BufferGeometry {
      constructor(radiusTop = 1, radiusBottom = 1, height = 1, radialSegments = 32, heightSegments = 1, openEnded = false, thetaStart = 0, thetaLength = Math.PI * 2) {
        super();
        this.type = "CylinderGeometry";
        this.parameters = {
          radiusTop,
          radiusBottom,
          height,
          radialSegments,
          heightSegments,
          openEnded,
          thetaStart,
          thetaLength
        };
        const scope = this;
        radialSegments = Math.floor(radialSegments);
        heightSegments = Math.floor(heightSegments);
        const indices = [];
        const vertices = [];
        const normals = [];
        const uvs = [];
        let index = 0;
        const indexArray = [];
        const halfHeight = height / 2;
        let groupStart = 0;
        generateTorso();
        if (openEnded === false) {
          if (radiusTop > 0) generateCap(true);
          if (radiusBottom > 0) generateCap(false);
        }
        this.setIndex(indices);
        this.setAttribute("position", new Float32BufferAttribute(vertices, 3));
        this.setAttribute("normal", new Float32BufferAttribute(normals, 3));
        this.setAttribute("uv", new Float32BufferAttribute(uvs, 2));
        function generateTorso() {
          const normal = new Vector3();
          const vertex = new Vector3();
          let groupCount = 0;
          const slope = (radiusBottom - radiusTop) / height;
          for (let y = 0; y <= heightSegments; y++) {
            const indexRow = [];
            const v = y / heightSegments;
            const radius = v * (radiusBottom - radiusTop) + radiusTop;
            for (let x = 0; x <= radialSegments; x++) {
              const u = x / radialSegments;
              const theta = u * thetaLength + thetaStart;
              const sinTheta = Math.sin(theta);
              const cosTheta = Math.cos(theta);
              vertex.x = radius * sinTheta;
              vertex.y = -v * height + halfHeight;
              vertex.z = radius * cosTheta;
              vertices.push(vertex.x, vertex.y, vertex.z);
              normal.set(sinTheta, slope, cosTheta).normalize();
              normals.push(normal.x, normal.y, normal.z);
              uvs.push(u, 1 - v);
              indexRow.push(index++);
            }
            indexArray.push(indexRow);
          }
          for (let x = 0; x < radialSegments; x++) {
            for (let y = 0; y < heightSegments; y++) {
              const a = indexArray[y][x];
              const b = indexArray[y + 1][x];
              const c = indexArray[y + 1][x + 1];
              const d = indexArray[y][x + 1];
              if (radiusTop > 0 || y !== 0) {
                indices.push(a, b, d);
                groupCount += 3;
              }
              if (radiusBottom > 0 || y !== heightSegments - 1) {
                indices.push(b, c, d);
                groupCount += 3;
              }
            }
          }
          scope.addGroup(groupStart, groupCount, 0);
          groupStart += groupCount;
        }
        function generateCap(top) {
          const centerIndexStart = index;
          const uv = new Vector2();
          const vertex = new Vector3();
          let groupCount = 0;
          const radius = top === true ? radiusTop : radiusBottom;
          const sign = top === true ? 1 : -1;
          for (let x = 1; x <= radialSegments; x++) {
            vertices.push(0, halfHeight * sign, 0);
            normals.push(0, sign, 0);
            uvs.push(0.5, 0.5);
            index++;
          }
          const centerIndexEnd = index;
          for (let x = 0; x <= radialSegments; x++) {
            const u = x / radialSegments;
            const theta = u * thetaLength + thetaStart;
            const cosTheta = Math.cos(theta);
            const sinTheta = Math.sin(theta);
            vertex.x = radius * sinTheta;
            vertex.y = halfHeight * sign;
            vertex.z = radius * cosTheta;
            vertices.push(vertex.x, vertex.y, vertex.z);
            normals.push(0, sign, 0);
            uv.x = cosTheta * 0.5 + 0.5;
            uv.y = sinTheta * 0.5 * sign + 0.5;
            uvs.push(uv.x, uv.y);
            index++;
          }
          for (let x = 0; x < radialSegments; x++) {
            const c = centerIndexStart + x;
            const i = centerIndexEnd + x;
            if (top === true) {
              indices.push(i, i + 1, c);
            } else {
              indices.push(i + 1, i, c);
            }
            groupCount += 3;
          }
          scope.addGroup(groupStart, groupCount, top === true ? 1 : 2);
          groupStart += groupCount;
        }
      }
      copy(source) {
        super.copy(source);
        this.parameters = Object.assign({}, source.parameters);
        return this;
      }
      static fromJSON(data) {
        return new _CylinderGeometry(data.radiusTop, data.radiusBottom, data.height, data.radialSegments, data.heightSegments, data.openEnded, data.thetaStart, data.thetaLength);
      }
    };
    PolyhedronGeometry = class _PolyhedronGeometry extends BufferGeometry {
      constructor(vertices = [], indices = [], radius = 1, detail = 0) {
        super();
        this.type = "PolyhedronGeometry";
        this.parameters = {
          vertices,
          indices,
          radius,
          detail
        };
        const vertexBuffer = [];
        const uvBuffer = [];
        subdivide(detail);
        applyRadius(radius);
        generateUVs();
        this.setAttribute("position", new Float32BufferAttribute(vertexBuffer, 3));
        this.setAttribute("normal", new Float32BufferAttribute(vertexBuffer.slice(), 3));
        this.setAttribute("uv", new Float32BufferAttribute(uvBuffer, 2));
        if (detail === 0) {
          this.computeVertexNormals();
        } else {
          this.normalizeNormals();
        }
        function subdivide(detail2) {
          const a = new Vector3();
          const b = new Vector3();
          const c = new Vector3();
          for (let i = 0; i < indices.length; i += 3) {
            getVertexByIndex(indices[i + 0], a);
            getVertexByIndex(indices[i + 1], b);
            getVertexByIndex(indices[i + 2], c);
            subdivideFace(a, b, c, detail2);
          }
        }
        function subdivideFace(a, b, c, detail2) {
          const cols = detail2 + 1;
          const v = [];
          for (let i = 0; i <= cols; i++) {
            v[i] = [];
            const aj = a.clone().lerp(c, i / cols);
            const bj = b.clone().lerp(c, i / cols);
            const rows = cols - i;
            for (let j = 0; j <= rows; j++) {
              if (j === 0 && i === cols) {
                v[i][j] = aj;
              } else {
                v[i][j] = aj.clone().lerp(bj, j / rows);
              }
            }
          }
          for (let i = 0; i < cols; i++) {
            for (let j = 0; j < 2 * (cols - i) - 1; j++) {
              const k = Math.floor(j / 2);
              if (j % 2 === 0) {
                pushVertex(v[i][k + 1]);
                pushVertex(v[i + 1][k]);
                pushVertex(v[i][k]);
              } else {
                pushVertex(v[i][k + 1]);
                pushVertex(v[i + 1][k + 1]);
                pushVertex(v[i + 1][k]);
              }
            }
          }
        }
        function applyRadius(radius2) {
          const vertex = new Vector3();
          for (let i = 0; i < vertexBuffer.length; i += 3) {
            vertex.x = vertexBuffer[i + 0];
            vertex.y = vertexBuffer[i + 1];
            vertex.z = vertexBuffer[i + 2];
            vertex.normalize().multiplyScalar(radius2);
            vertexBuffer[i + 0] = vertex.x;
            vertexBuffer[i + 1] = vertex.y;
            vertexBuffer[i + 2] = vertex.z;
          }
        }
        function generateUVs() {
          const vertex = new Vector3();
          for (let i = 0; i < vertexBuffer.length; i += 3) {
            vertex.x = vertexBuffer[i + 0];
            vertex.y = vertexBuffer[i + 1];
            vertex.z = vertexBuffer[i + 2];
            const u = azimuth(vertex) / 2 / Math.PI + 0.5;
            const v = inclination(vertex) / Math.PI + 0.5;
            uvBuffer.push(u, 1 - v);
          }
          correctUVs();
          correctSeam();
        }
        function correctSeam() {
          for (let i = 0; i < uvBuffer.length; i += 6) {
            const x0 = uvBuffer[i + 0];
            const x1 = uvBuffer[i + 2];
            const x2 = uvBuffer[i + 4];
            const max = Math.max(x0, x1, x2);
            const min = Math.min(x0, x1, x2);
            if (max > 0.9 && min < 0.1) {
              if (x0 < 0.2) uvBuffer[i + 0] += 1;
              if (x1 < 0.2) uvBuffer[i + 2] += 1;
              if (x2 < 0.2) uvBuffer[i + 4] += 1;
            }
          }
        }
        function pushVertex(vertex) {
          vertexBuffer.push(vertex.x, vertex.y, vertex.z);
        }
        function getVertexByIndex(index, vertex) {
          const stride = index * 3;
          vertex.x = vertices[stride + 0];
          vertex.y = vertices[stride + 1];
          vertex.z = vertices[stride + 2];
        }
        function correctUVs() {
          const a = new Vector3();
          const b = new Vector3();
          const c = new Vector3();
          const centroid = new Vector3();
          const uvA = new Vector2();
          const uvB = new Vector2();
          const uvC = new Vector2();
          for (let i = 0, j = 0; i < vertexBuffer.length; i += 9, j += 6) {
            a.set(vertexBuffer[i + 0], vertexBuffer[i + 1], vertexBuffer[i + 2]);
            b.set(vertexBuffer[i + 3], vertexBuffer[i + 4], vertexBuffer[i + 5]);
            c.set(vertexBuffer[i + 6], vertexBuffer[i + 7], vertexBuffer[i + 8]);
            uvA.set(uvBuffer[j + 0], uvBuffer[j + 1]);
            uvB.set(uvBuffer[j + 2], uvBuffer[j + 3]);
            uvC.set(uvBuffer[j + 4], uvBuffer[j + 5]);
            centroid.copy(a).add(b).add(c).divideScalar(3);
            const azi = azimuth(centroid);
            correctUV(uvA, j + 0, a, azi);
            correctUV(uvB, j + 2, b, azi);
            correctUV(uvC, j + 4, c, azi);
          }
        }
        function correctUV(uv, stride, vector, azimuth2) {
          if (azimuth2 < 0 && uv.x === 1) {
            uvBuffer[stride] = uv.x - 1;
          }
          if (vector.x === 0 && vector.z === 0) {
            uvBuffer[stride] = azimuth2 / 2 / Math.PI + 0.5;
          }
        }
        function azimuth(vector) {
          return Math.atan2(vector.z, -vector.x);
        }
        function inclination(vector) {
          return Math.atan2(-vector.y, Math.sqrt(vector.x * vector.x + vector.z * vector.z));
        }
      }
      copy(source) {
        super.copy(source);
        this.parameters = Object.assign({}, source.parameters);
        return this;
      }
      static fromJSON(data) {
        return new _PolyhedronGeometry(data.vertices, data.indices, data.radius, data.details);
      }
    };
    IcosahedronGeometry = class _IcosahedronGeometry extends PolyhedronGeometry {
      constructor(radius = 1, detail = 0) {
        const t = (1 + Math.sqrt(5)) / 2;
        const vertices = [
          -1,
          t,
          0,
          1,
          t,
          0,
          -1,
          -t,
          0,
          1,
          -t,
          0,
          0,
          -1,
          t,
          0,
          1,
          t,
          0,
          -1,
          -t,
          0,
          1,
          -t,
          t,
          0,
          -1,
          t,
          0,
          1,
          -t,
          0,
          -1,
          -t,
          0,
          1
        ];
        const indices = [
          0,
          11,
          5,
          0,
          5,
          1,
          0,
          1,
          7,
          0,
          7,
          10,
          0,
          10,
          11,
          1,
          5,
          9,
          5,
          11,
          4,
          11,
          10,
          2,
          10,
          7,
          6,
          7,
          1,
          8,
          3,
          9,
          4,
          3,
          4,
          2,
          3,
          2,
          6,
          3,
          6,
          8,
          3,
          8,
          9,
          4,
          9,
          5,
          2,
          4,
          11,
          6,
          2,
          10,
          8,
          6,
          7,
          9,
          8,
          1
        ];
        super(vertices, indices, radius, detail);
        this.type = "IcosahedronGeometry";
        this.parameters = {
          radius,
          detail
        };
      }
      static fromJSON(data) {
        return new _IcosahedronGeometry(data.radius, data.detail);
      }
    };
    SphereGeometry = class _SphereGeometry extends BufferGeometry {
      constructor(radius = 1, widthSegments = 32, heightSegments = 16, phiStart = 0, phiLength = Math.PI * 2, thetaStart = 0, thetaLength = Math.PI) {
        super();
        this.type = "SphereGeometry";
        this.parameters = {
          radius,
          widthSegments,
          heightSegments,
          phiStart,
          phiLength,
          thetaStart,
          thetaLength
        };
        widthSegments = Math.max(3, Math.floor(widthSegments));
        heightSegments = Math.max(2, Math.floor(heightSegments));
        const thetaEnd = Math.min(thetaStart + thetaLength, Math.PI);
        let index = 0;
        const grid = [];
        const vertex = new Vector3();
        const normal = new Vector3();
        const indices = [];
        const vertices = [];
        const normals = [];
        const uvs = [];
        for (let iy = 0; iy <= heightSegments; iy++) {
          const verticesRow = [];
          const v = iy / heightSegments;
          let uOffset = 0;
          if (iy === 0 && thetaStart === 0) {
            uOffset = 0.5 / widthSegments;
          } else if (iy === heightSegments && thetaEnd === Math.PI) {
            uOffset = -0.5 / widthSegments;
          }
          for (let ix = 0; ix <= widthSegments; ix++) {
            const u = ix / widthSegments;
            vertex.x = -radius * Math.cos(phiStart + u * phiLength) * Math.sin(thetaStart + v * thetaLength);
            vertex.y = radius * Math.cos(thetaStart + v * thetaLength);
            vertex.z = radius * Math.sin(phiStart + u * phiLength) * Math.sin(thetaStart + v * thetaLength);
            vertices.push(vertex.x, vertex.y, vertex.z);
            normal.copy(vertex).normalize();
            normals.push(normal.x, normal.y, normal.z);
            uvs.push(u + uOffset, 1 - v);
            verticesRow.push(index++);
          }
          grid.push(verticesRow);
        }
        for (let iy = 0; iy < heightSegments; iy++) {
          for (let ix = 0; ix < widthSegments; ix++) {
            const a = grid[iy][ix + 1];
            const b = grid[iy][ix];
            const c = grid[iy + 1][ix];
            const d = grid[iy + 1][ix + 1];
            if (iy !== 0 || thetaStart > 0) indices.push(a, b, d);
            if (iy !== heightSegments - 1 || thetaEnd < Math.PI) indices.push(b, c, d);
          }
        }
        this.setIndex(indices);
        this.setAttribute("position", new Float32BufferAttribute(vertices, 3));
        this.setAttribute("normal", new Float32BufferAttribute(normals, 3));
        this.setAttribute("uv", new Float32BufferAttribute(uvs, 2));
      }
      copy(source) {
        super.copy(source);
        this.parameters = Object.assign({}, source.parameters);
        return this;
      }
      static fromJSON(data) {
        return new _SphereGeometry(data.radius, data.widthSegments, data.heightSegments, data.phiStart, data.phiLength, data.thetaStart, data.thetaLength);
      }
    };
    MeshStandardMaterial = class extends Material {
      static get type() {
        return "MeshStandardMaterial";
      }
      constructor(parameters) {
        super();
        this.isMeshStandardMaterial = true;
        this.defines = { "STANDARD": "" };
        this.color = new Color(16777215);
        this.roughness = 1;
        this.metalness = 0;
        this.map = null;
        this.lightMap = null;
        this.lightMapIntensity = 1;
        this.aoMap = null;
        this.aoMapIntensity = 1;
        this.emissive = new Color(0);
        this.emissiveIntensity = 1;
        this.emissiveMap = null;
        this.bumpMap = null;
        this.bumpScale = 1;
        this.normalMap = null;
        this.normalMapType = TangentSpaceNormalMap;
        this.normalScale = new Vector2(1, 1);
        this.displacementMap = null;
        this.displacementScale = 1;
        this.displacementBias = 0;
        this.roughnessMap = null;
        this.metalnessMap = null;
        this.alphaMap = null;
        this.envMap = null;
        this.envMapRotation = new Euler();
        this.envMapIntensity = 1;
        this.wireframe = false;
        this.wireframeLinewidth = 1;
        this.wireframeLinecap = "round";
        this.wireframeLinejoin = "round";
        this.flatShading = false;
        this.fog = true;
        this.setValues(parameters);
      }
      copy(source) {
        super.copy(source);
        this.defines = { "STANDARD": "" };
        this.color.copy(source.color);
        this.roughness = source.roughness;
        this.metalness = source.metalness;
        this.map = source.map;
        this.lightMap = source.lightMap;
        this.lightMapIntensity = source.lightMapIntensity;
        this.aoMap = source.aoMap;
        this.aoMapIntensity = source.aoMapIntensity;
        this.emissive.copy(source.emissive);
        this.emissiveMap = source.emissiveMap;
        this.emissiveIntensity = source.emissiveIntensity;
        this.bumpMap = source.bumpMap;
        this.bumpScale = source.bumpScale;
        this.normalMap = source.normalMap;
        this.normalMapType = source.normalMapType;
        this.normalScale.copy(source.normalScale);
        this.displacementMap = source.displacementMap;
        this.displacementScale = source.displacementScale;
        this.displacementBias = source.displacementBias;
        this.roughnessMap = source.roughnessMap;
        this.metalnessMap = source.metalnessMap;
        this.alphaMap = source.alphaMap;
        this.envMap = source.envMap;
        this.envMapRotation.copy(source.envMapRotation);
        this.envMapIntensity = source.envMapIntensity;
        this.wireframe = source.wireframe;
        this.wireframeLinewidth = source.wireframeLinewidth;
        this.wireframeLinecap = source.wireframeLinecap;
        this.wireframeLinejoin = source.wireframeLinejoin;
        this.flatShading = source.flatShading;
        this.fog = source.fog;
        return this;
      }
    };
    MeshLambertMaterial = class extends Material {
      static get type() {
        return "MeshLambertMaterial";
      }
      constructor(parameters) {
        super();
        this.isMeshLambertMaterial = true;
        this.color = new Color(16777215);
        this.map = null;
        this.lightMap = null;
        this.lightMapIntensity = 1;
        this.aoMap = null;
        this.aoMapIntensity = 1;
        this.emissive = new Color(0);
        this.emissiveIntensity = 1;
        this.emissiveMap = null;
        this.bumpMap = null;
        this.bumpScale = 1;
        this.normalMap = null;
        this.normalMapType = TangentSpaceNormalMap;
        this.normalScale = new Vector2(1, 1);
        this.displacementMap = null;
        this.displacementScale = 1;
        this.displacementBias = 0;
        this.specularMap = null;
        this.alphaMap = null;
        this.envMap = null;
        this.envMapRotation = new Euler();
        this.combine = MultiplyOperation;
        this.reflectivity = 1;
        this.refractionRatio = 0.98;
        this.wireframe = false;
        this.wireframeLinewidth = 1;
        this.wireframeLinecap = "round";
        this.wireframeLinejoin = "round";
        this.flatShading = false;
        this.fog = true;
        this.setValues(parameters);
      }
      copy(source) {
        super.copy(source);
        this.color.copy(source.color);
        this.map = source.map;
        this.lightMap = source.lightMap;
        this.lightMapIntensity = source.lightMapIntensity;
        this.aoMap = source.aoMap;
        this.aoMapIntensity = source.aoMapIntensity;
        this.emissive.copy(source.emissive);
        this.emissiveMap = source.emissiveMap;
        this.emissiveIntensity = source.emissiveIntensity;
        this.bumpMap = source.bumpMap;
        this.bumpScale = source.bumpScale;
        this.normalMap = source.normalMap;
        this.normalMapType = source.normalMapType;
        this.normalScale.copy(source.normalScale);
        this.displacementMap = source.displacementMap;
        this.displacementScale = source.displacementScale;
        this.displacementBias = source.displacementBias;
        this.specularMap = source.specularMap;
        this.alphaMap = source.alphaMap;
        this.envMap = source.envMap;
        this.envMapRotation.copy(source.envMapRotation);
        this.combine = source.combine;
        this.reflectivity = source.reflectivity;
        this.refractionRatio = source.refractionRatio;
        this.wireframe = source.wireframe;
        this.wireframeLinewidth = source.wireframeLinewidth;
        this.wireframeLinecap = source.wireframeLinecap;
        this.wireframeLinejoin = source.wireframeLinejoin;
        this.flatShading = source.flatShading;
        this.fog = source.fog;
        return this;
      }
    };
    Interpolant = class {
      constructor(parameterPositions, sampleValues, sampleSize, resultBuffer) {
        this.parameterPositions = parameterPositions;
        this._cachedIndex = 0;
        this.resultBuffer = resultBuffer !== void 0 ? resultBuffer : new sampleValues.constructor(sampleSize);
        this.sampleValues = sampleValues;
        this.valueSize = sampleSize;
        this.settings = null;
        this.DefaultSettings_ = {};
      }
      evaluate(t) {
        const pp = this.parameterPositions;
        let i1 = this._cachedIndex, t1 = pp[i1], t0 = pp[i1 - 1];
        validate_interval: {
          seek: {
            let right;
            linear_scan: {
              forward_scan: if (!(t < t1)) {
                for (let giveUpAt = i1 + 2; ; ) {
                  if (t1 === void 0) {
                    if (t < t0) break forward_scan;
                    i1 = pp.length;
                    this._cachedIndex = i1;
                    return this.copySampleValue_(i1 - 1);
                  }
                  if (i1 === giveUpAt) break;
                  t0 = t1;
                  t1 = pp[++i1];
                  if (t < t1) {
                    break seek;
                  }
                }
                right = pp.length;
                break linear_scan;
              }
              if (!(t >= t0)) {
                const t1global = pp[1];
                if (t < t1global) {
                  i1 = 2;
                  t0 = t1global;
                }
                for (let giveUpAt = i1 - 2; ; ) {
                  if (t0 === void 0) {
                    this._cachedIndex = 0;
                    return this.copySampleValue_(0);
                  }
                  if (i1 === giveUpAt) break;
                  t1 = t0;
                  t0 = pp[--i1 - 1];
                  if (t >= t0) {
                    break seek;
                  }
                }
                right = i1;
                i1 = 0;
                break linear_scan;
              }
              break validate_interval;
            }
            while (i1 < right) {
              const mid = i1 + right >>> 1;
              if (t < pp[mid]) {
                right = mid;
              } else {
                i1 = mid + 1;
              }
            }
            t1 = pp[i1];
            t0 = pp[i1 - 1];
            if (t0 === void 0) {
              this._cachedIndex = 0;
              return this.copySampleValue_(0);
            }
            if (t1 === void 0) {
              i1 = pp.length;
              this._cachedIndex = i1;
              return this.copySampleValue_(i1 - 1);
            }
          }
          this._cachedIndex = i1;
          this.intervalChanged_(i1, t0, t1);
        }
        return this.interpolate_(i1, t0, t, t1);
      }
      getSettings_() {
        return this.settings || this.DefaultSettings_;
      }
      copySampleValue_(index) {
        const result = this.resultBuffer, values = this.sampleValues, stride = this.valueSize, offset = index * stride;
        for (let i = 0; i !== stride; ++i) {
          result[i] = values[offset + i];
        }
        return result;
      }
      // Template methods for derived classes:
      interpolate_() {
        throw new Error("call to abstract method");
      }
      intervalChanged_() {
      }
    };
    CubicInterpolant = class extends Interpolant {
      constructor(parameterPositions, sampleValues, sampleSize, resultBuffer) {
        super(parameterPositions, sampleValues, sampleSize, resultBuffer);
        this._weightPrev = -0;
        this._offsetPrev = -0;
        this._weightNext = -0;
        this._offsetNext = -0;
        this.DefaultSettings_ = {
          endingStart: ZeroCurvatureEnding,
          endingEnd: ZeroCurvatureEnding
        };
      }
      intervalChanged_(i1, t0, t1) {
        const pp = this.parameterPositions;
        let iPrev = i1 - 2, iNext = i1 + 1, tPrev = pp[iPrev], tNext = pp[iNext];
        if (tPrev === void 0) {
          switch (this.getSettings_().endingStart) {
            case ZeroSlopeEnding:
              iPrev = i1;
              tPrev = 2 * t0 - t1;
              break;
            case WrapAroundEnding:
              iPrev = pp.length - 2;
              tPrev = t0 + pp[iPrev] - pp[iPrev + 1];
              break;
            default:
              iPrev = i1;
              tPrev = t1;
          }
        }
        if (tNext === void 0) {
          switch (this.getSettings_().endingEnd) {
            case ZeroSlopeEnding:
              iNext = i1;
              tNext = 2 * t1 - t0;
              break;
            case WrapAroundEnding:
              iNext = 1;
              tNext = t1 + pp[1] - pp[0];
              break;
            default:
              iNext = i1 - 1;
              tNext = t0;
          }
        }
        const halfDt = (t1 - t0) * 0.5, stride = this.valueSize;
        this._weightPrev = halfDt / (t0 - tPrev);
        this._weightNext = halfDt / (tNext - t1);
        this._offsetPrev = iPrev * stride;
        this._offsetNext = iNext * stride;
      }
      interpolate_(i1, t0, t, t1) {
        const result = this.resultBuffer, values = this.sampleValues, stride = this.valueSize, o1 = i1 * stride, o0 = o1 - stride, oP = this._offsetPrev, oN = this._offsetNext, wP = this._weightPrev, wN = this._weightNext, p = (t - t0) / (t1 - t0), pp = p * p, ppp = pp * p;
        const sP = -wP * ppp + 2 * wP * pp - wP * p;
        const s0 = (1 + wP) * ppp + (-1.5 - 2 * wP) * pp + (-0.5 + wP) * p + 1;
        const s1 = (-1 - wN) * ppp + (1.5 + wN) * pp + 0.5 * p;
        const sN = wN * ppp - wN * pp;
        for (let i = 0; i !== stride; ++i) {
          result[i] = sP * values[oP + i] + s0 * values[o0 + i] + s1 * values[o1 + i] + sN * values[oN + i];
        }
        return result;
      }
    };
    LinearInterpolant = class extends Interpolant {
      constructor(parameterPositions, sampleValues, sampleSize, resultBuffer) {
        super(parameterPositions, sampleValues, sampleSize, resultBuffer);
      }
      interpolate_(i1, t0, t, t1) {
        const result = this.resultBuffer, values = this.sampleValues, stride = this.valueSize, offset1 = i1 * stride, offset0 = offset1 - stride, weight1 = (t - t0) / (t1 - t0), weight0 = 1 - weight1;
        for (let i = 0; i !== stride; ++i) {
          result[i] = values[offset0 + i] * weight0 + values[offset1 + i] * weight1;
        }
        return result;
      }
    };
    DiscreteInterpolant = class extends Interpolant {
      constructor(parameterPositions, sampleValues, sampleSize, resultBuffer) {
        super(parameterPositions, sampleValues, sampleSize, resultBuffer);
      }
      interpolate_(i1) {
        return this.copySampleValue_(i1 - 1);
      }
    };
    KeyframeTrack = class {
      constructor(name, times, values, interpolation) {
        if (name === void 0) throw new Error("THREE.KeyframeTrack: track name is undefined");
        if (times === void 0 || times.length === 0) throw new Error("THREE.KeyframeTrack: no keyframes in track named " + name);
        this.name = name;
        this.times = convertArray(times, this.TimeBufferType);
        this.values = convertArray(values, this.ValueBufferType);
        this.setInterpolation(interpolation || this.DefaultInterpolation);
      }
      // Serialization (in static context, because of constructor invocation
      // and automatic invocation of .toJSON):
      static toJSON(track) {
        const trackType = track.constructor;
        let json;
        if (trackType.toJSON !== this.toJSON) {
          json = trackType.toJSON(track);
        } else {
          json = {
            "name": track.name,
            "times": convertArray(track.times, Array),
            "values": convertArray(track.values, Array)
          };
          const interpolation = track.getInterpolation();
          if (interpolation !== track.DefaultInterpolation) {
            json.interpolation = interpolation;
          }
        }
        json.type = track.ValueTypeName;
        return json;
      }
      InterpolantFactoryMethodDiscrete(result) {
        return new DiscreteInterpolant(this.times, this.values, this.getValueSize(), result);
      }
      InterpolantFactoryMethodLinear(result) {
        return new LinearInterpolant(this.times, this.values, this.getValueSize(), result);
      }
      InterpolantFactoryMethodSmooth(result) {
        return new CubicInterpolant(this.times, this.values, this.getValueSize(), result);
      }
      setInterpolation(interpolation) {
        let factoryMethod;
        switch (interpolation) {
          case InterpolateDiscrete:
            factoryMethod = this.InterpolantFactoryMethodDiscrete;
            break;
          case InterpolateLinear:
            factoryMethod = this.InterpolantFactoryMethodLinear;
            break;
          case InterpolateSmooth:
            factoryMethod = this.InterpolantFactoryMethodSmooth;
            break;
        }
        if (factoryMethod === void 0) {
          const message = "unsupported interpolation for " + this.ValueTypeName + " keyframe track named " + this.name;
          if (this.createInterpolant === void 0) {
            if (interpolation !== this.DefaultInterpolation) {
              this.setInterpolation(this.DefaultInterpolation);
            } else {
              throw new Error(message);
            }
          }
          console.warn("THREE.KeyframeTrack:", message);
          return this;
        }
        this.createInterpolant = factoryMethod;
        return this;
      }
      getInterpolation() {
        switch (this.createInterpolant) {
          case this.InterpolantFactoryMethodDiscrete:
            return InterpolateDiscrete;
          case this.InterpolantFactoryMethodLinear:
            return InterpolateLinear;
          case this.InterpolantFactoryMethodSmooth:
            return InterpolateSmooth;
        }
      }
      getValueSize() {
        return this.values.length / this.times.length;
      }
      // move all keyframes either forwards or backwards in time
      shift(timeOffset) {
        if (timeOffset !== 0) {
          const times = this.times;
          for (let i = 0, n = times.length; i !== n; ++i) {
            times[i] += timeOffset;
          }
        }
        return this;
      }
      // scale all keyframe times by a factor (useful for frame <-> seconds conversions)
      scale(timeScale) {
        if (timeScale !== 1) {
          const times = this.times;
          for (let i = 0, n = times.length; i !== n; ++i) {
            times[i] *= timeScale;
          }
        }
        return this;
      }
      // removes keyframes before and after animation without changing any values within the range [startTime, endTime].
      // IMPORTANT: We do not shift around keys to the start of the track time, because for interpolated keys this will change their values
      trim(startTime, endTime) {
        const times = this.times, nKeys = times.length;
        let from = 0, to = nKeys - 1;
        while (from !== nKeys && times[from] < startTime) {
          ++from;
        }
        while (to !== -1 && times[to] > endTime) {
          --to;
        }
        ++to;
        if (from !== 0 || to !== nKeys) {
          if (from >= to) {
            to = Math.max(to, 1);
            from = to - 1;
          }
          const stride = this.getValueSize();
          this.times = times.slice(from, to);
          this.values = this.values.slice(from * stride, to * stride);
        }
        return this;
      }
      // ensure we do not get a GarbageInGarbageOut situation, make sure tracks are at least minimally viable
      validate() {
        let valid = true;
        const valueSize = this.getValueSize();
        if (valueSize - Math.floor(valueSize) !== 0) {
          console.error("THREE.KeyframeTrack: Invalid value size in track.", this);
          valid = false;
        }
        const times = this.times, values = this.values, nKeys = times.length;
        if (nKeys === 0) {
          console.error("THREE.KeyframeTrack: Track is empty.", this);
          valid = false;
        }
        let prevTime = null;
        for (let i = 0; i !== nKeys; i++) {
          const currTime = times[i];
          if (typeof currTime === "number" && isNaN(currTime)) {
            console.error("THREE.KeyframeTrack: Time is not a valid number.", this, i, currTime);
            valid = false;
            break;
          }
          if (prevTime !== null && prevTime > currTime) {
            console.error("THREE.KeyframeTrack: Out of order keys.", this, i, currTime, prevTime);
            valid = false;
            break;
          }
          prevTime = currTime;
        }
        if (values !== void 0) {
          if (isTypedArray(values)) {
            for (let i = 0, n = values.length; i !== n; ++i) {
              const value = values[i];
              if (isNaN(value)) {
                console.error("THREE.KeyframeTrack: Value is not a valid number.", this, i, value);
                valid = false;
                break;
              }
            }
          }
        }
        return valid;
      }
      // removes equivalent sequential keys as common in morph target sequences
      // (0,0,0,0,1,1,1,0,0,0,0,0,0,0) --> (0,0,1,1,0,0)
      optimize() {
        const times = this.times.slice(), values = this.values.slice(), stride = this.getValueSize(), smoothInterpolation = this.getInterpolation() === InterpolateSmooth, lastIndex = times.length - 1;
        let writeIndex = 1;
        for (let i = 1; i < lastIndex; ++i) {
          let keep = false;
          const time = times[i];
          const timeNext = times[i + 1];
          if (time !== timeNext && (i !== 1 || time !== times[0])) {
            if (!smoothInterpolation) {
              const offset = i * stride, offsetP = offset - stride, offsetN = offset + stride;
              for (let j = 0; j !== stride; ++j) {
                const value = values[offset + j];
                if (value !== values[offsetP + j] || value !== values[offsetN + j]) {
                  keep = true;
                  break;
                }
              }
            } else {
              keep = true;
            }
          }
          if (keep) {
            if (i !== writeIndex) {
              times[writeIndex] = times[i];
              const readOffset = i * stride, writeOffset = writeIndex * stride;
              for (let j = 0; j !== stride; ++j) {
                values[writeOffset + j] = values[readOffset + j];
              }
            }
            ++writeIndex;
          }
        }
        if (lastIndex > 0) {
          times[writeIndex] = times[lastIndex];
          for (let readOffset = lastIndex * stride, writeOffset = writeIndex * stride, j = 0; j !== stride; ++j) {
            values[writeOffset + j] = values[readOffset + j];
          }
          ++writeIndex;
        }
        if (writeIndex !== times.length) {
          this.times = times.slice(0, writeIndex);
          this.values = values.slice(0, writeIndex * stride);
        } else {
          this.times = times;
          this.values = values;
        }
        return this;
      }
      clone() {
        const times = this.times.slice();
        const values = this.values.slice();
        const TypedKeyframeTrack = this.constructor;
        const track = new TypedKeyframeTrack(this.name, times, values);
        track.createInterpolant = this.createInterpolant;
        return track;
      }
    };
    KeyframeTrack.prototype.TimeBufferType = Float32Array;
    KeyframeTrack.prototype.ValueBufferType = Float32Array;
    KeyframeTrack.prototype.DefaultInterpolation = InterpolateLinear;
    BooleanKeyframeTrack = class extends KeyframeTrack {
      // No interpolation parameter because only InterpolateDiscrete is valid.
      constructor(name, times, values) {
        super(name, times, values);
      }
    };
    BooleanKeyframeTrack.prototype.ValueTypeName = "bool";
    BooleanKeyframeTrack.prototype.ValueBufferType = Array;
    BooleanKeyframeTrack.prototype.DefaultInterpolation = InterpolateDiscrete;
    BooleanKeyframeTrack.prototype.InterpolantFactoryMethodLinear = void 0;
    BooleanKeyframeTrack.prototype.InterpolantFactoryMethodSmooth = void 0;
    ColorKeyframeTrack = class extends KeyframeTrack {
    };
    ColorKeyframeTrack.prototype.ValueTypeName = "color";
    NumberKeyframeTrack = class extends KeyframeTrack {
    };
    NumberKeyframeTrack.prototype.ValueTypeName = "number";
    QuaternionLinearInterpolant = class extends Interpolant {
      constructor(parameterPositions, sampleValues, sampleSize, resultBuffer) {
        super(parameterPositions, sampleValues, sampleSize, resultBuffer);
      }
      interpolate_(i1, t0, t, t1) {
        const result = this.resultBuffer, values = this.sampleValues, stride = this.valueSize, alpha = (t - t0) / (t1 - t0);
        let offset = i1 * stride;
        for (let end = offset + stride; offset !== end; offset += 4) {
          Quaternion.slerpFlat(result, 0, values, offset - stride, values, offset, alpha);
        }
        return result;
      }
    };
    QuaternionKeyframeTrack = class extends KeyframeTrack {
      InterpolantFactoryMethodLinear(result) {
        return new QuaternionLinearInterpolant(this.times, this.values, this.getValueSize(), result);
      }
    };
    QuaternionKeyframeTrack.prototype.ValueTypeName = "quaternion";
    QuaternionKeyframeTrack.prototype.InterpolantFactoryMethodSmooth = void 0;
    StringKeyframeTrack = class extends KeyframeTrack {
      // No interpolation parameter because only InterpolateDiscrete is valid.
      constructor(name, times, values) {
        super(name, times, values);
      }
    };
    StringKeyframeTrack.prototype.ValueTypeName = "string";
    StringKeyframeTrack.prototype.ValueBufferType = Array;
    StringKeyframeTrack.prototype.DefaultInterpolation = InterpolateDiscrete;
    StringKeyframeTrack.prototype.InterpolantFactoryMethodLinear = void 0;
    StringKeyframeTrack.prototype.InterpolantFactoryMethodSmooth = void 0;
    VectorKeyframeTrack = class extends KeyframeTrack {
    };
    VectorKeyframeTrack.prototype.ValueTypeName = "vector";
    LoadingManager = class {
      constructor(onLoad, onProgress, onError) {
        const scope = this;
        let isLoading = false;
        let itemsLoaded = 0;
        let itemsTotal = 0;
        let urlModifier = void 0;
        const handlers = [];
        this.onStart = void 0;
        this.onLoad = onLoad;
        this.onProgress = onProgress;
        this.onError = onError;
        this.itemStart = function(url) {
          itemsTotal++;
          if (isLoading === false) {
            if (scope.onStart !== void 0) {
              scope.onStart(url, itemsLoaded, itemsTotal);
            }
          }
          isLoading = true;
        };
        this.itemEnd = function(url) {
          itemsLoaded++;
          if (scope.onProgress !== void 0) {
            scope.onProgress(url, itemsLoaded, itemsTotal);
          }
          if (itemsLoaded === itemsTotal) {
            isLoading = false;
            if (scope.onLoad !== void 0) {
              scope.onLoad();
            }
          }
        };
        this.itemError = function(url) {
          if (scope.onError !== void 0) {
            scope.onError(url);
          }
        };
        this.resolveURL = function(url) {
          if (urlModifier) {
            return urlModifier(url);
          }
          return url;
        };
        this.setURLModifier = function(transform) {
          urlModifier = transform;
          return this;
        };
        this.addHandler = function(regex, loader) {
          handlers.push(regex, loader);
          return this;
        };
        this.removeHandler = function(regex) {
          const index = handlers.indexOf(regex);
          if (index !== -1) {
            handlers.splice(index, 2);
          }
          return this;
        };
        this.getHandler = function(file) {
          for (let i = 0, l = handlers.length; i < l; i += 2) {
            const regex = handlers[i];
            const loader = handlers[i + 1];
            if (regex.global) regex.lastIndex = 0;
            if (regex.test(file)) {
              return loader;
            }
          }
          return null;
        };
      }
    };
    DefaultLoadingManager = /* @__PURE__ */ new LoadingManager();
    Loader = class {
      constructor(manager) {
        this.manager = manager !== void 0 ? manager : DefaultLoadingManager;
        this.crossOrigin = "anonymous";
        this.withCredentials = false;
        this.path = "";
        this.resourcePath = "";
        this.requestHeader = {};
      }
      load() {
      }
      loadAsync(url, onProgress) {
        const scope = this;
        return new Promise(function(resolve, reject) {
          scope.load(url, resolve, onProgress, reject);
        });
      }
      parse() {
      }
      setCrossOrigin(crossOrigin) {
        this.crossOrigin = crossOrigin;
        return this;
      }
      setWithCredentials(value) {
        this.withCredentials = value;
        return this;
      }
      setPath(path) {
        this.path = path;
        return this;
      }
      setResourcePath(resourcePath) {
        this.resourcePath = resourcePath;
        return this;
      }
      setRequestHeader(requestHeader) {
        this.requestHeader = requestHeader;
        return this;
      }
    };
    Loader.DEFAULT_MATERIAL_NAME = "__DEFAULT";
    _RESERVED_CHARS_RE = "\\[\\]\\.:\\/";
    _reservedRe = new RegExp("[" + _RESERVED_CHARS_RE + "]", "g");
    _wordChar = "[^" + _RESERVED_CHARS_RE + "]";
    _wordCharOrDot = "[^" + _RESERVED_CHARS_RE.replace("\\.", "") + "]";
    _directoryRe = /* @__PURE__ */ /((?:WC+[\/:])*)/.source.replace("WC", _wordChar);
    _nodeRe = /* @__PURE__ */ /(WCOD+)?/.source.replace("WCOD", _wordCharOrDot);
    _objectRe = /* @__PURE__ */ /(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC", _wordChar);
    _propertyRe = /* @__PURE__ */ /\.(WC+)(?:\[(.+)\])?/.source.replace("WC", _wordChar);
    _trackRe = new RegExp(
      "^" + _directoryRe + _nodeRe + _objectRe + _propertyRe + "$"
    );
    _supportedObjectNames = ["material", "materials", "bones", "map"];
    Composite = class {
      constructor(targetGroup, path, optionalParsedPath) {
        const parsedPath = optionalParsedPath || PropertyBinding.parseTrackName(path);
        this._targetGroup = targetGroup;
        this._bindings = targetGroup.subscribe_(path, parsedPath);
      }
      getValue(array, offset) {
        this.bind();
        const firstValidIndex = this._targetGroup.nCachedObjects_, binding = this._bindings[firstValidIndex];
        if (binding !== void 0) binding.getValue(array, offset);
      }
      setValue(array, offset) {
        const bindings = this._bindings;
        for (let i = this._targetGroup.nCachedObjects_, n = bindings.length; i !== n; ++i) {
          bindings[i].setValue(array, offset);
        }
      }
      bind() {
        const bindings = this._bindings;
        for (let i = this._targetGroup.nCachedObjects_, n = bindings.length; i !== n; ++i) {
          bindings[i].bind();
        }
      }
      unbind() {
        const bindings = this._bindings;
        for (let i = this._targetGroup.nCachedObjects_, n = bindings.length; i !== n; ++i) {
          bindings[i].unbind();
        }
      }
    };
    PropertyBinding = class _PropertyBinding {
      constructor(rootNode, path, parsedPath) {
        this.path = path;
        this.parsedPath = parsedPath || _PropertyBinding.parseTrackName(path);
        this.node = _PropertyBinding.findNode(rootNode, this.parsedPath.nodeName);
        this.rootNode = rootNode;
        this.getValue = this._getValue_unbound;
        this.setValue = this._setValue_unbound;
      }
      static create(root, path, parsedPath) {
        if (!(root && root.isAnimationObjectGroup)) {
          return new _PropertyBinding(root, path, parsedPath);
        } else {
          return new _PropertyBinding.Composite(root, path, parsedPath);
        }
      }
      /**
       * Replaces spaces with underscores and removes unsupported characters from
       * node names, to ensure compatibility with parseTrackName().
       *
       * @param {string} name Node name to be sanitized.
       * @return {string}
       */
      static sanitizeNodeName(name) {
        return name.replace(/\s/g, "_").replace(_reservedRe, "");
      }
      static parseTrackName(trackName) {
        const matches = _trackRe.exec(trackName);
        if (matches === null) {
          throw new Error("PropertyBinding: Cannot parse trackName: " + trackName);
        }
        const results2 = {
          // directoryName: matches[ 1 ], // (tschw) currently unused
          nodeName: matches[2],
          objectName: matches[3],
          objectIndex: matches[4],
          propertyName: matches[5],
          // required
          propertyIndex: matches[6]
        };
        const lastDot = results2.nodeName && results2.nodeName.lastIndexOf(".");
        if (lastDot !== void 0 && lastDot !== -1) {
          const objectName = results2.nodeName.substring(lastDot + 1);
          if (_supportedObjectNames.indexOf(objectName) !== -1) {
            results2.nodeName = results2.nodeName.substring(0, lastDot);
            results2.objectName = objectName;
          }
        }
        if (results2.propertyName === null || results2.propertyName.length === 0) {
          throw new Error("PropertyBinding: can not parse propertyName from trackName: " + trackName);
        }
        return results2;
      }
      static findNode(root, nodeName) {
        if (nodeName === void 0 || nodeName === "" || nodeName === "." || nodeName === -1 || nodeName === root.name || nodeName === root.uuid) {
          return root;
        }
        if (root.skeleton) {
          const bone = root.skeleton.getBoneByName(nodeName);
          if (bone !== void 0) {
            return bone;
          }
        }
        if (root.children) {
          const searchNodeSubtree = function(children) {
            for (let i = 0; i < children.length; i++) {
              const childNode = children[i];
              if (childNode.name === nodeName || childNode.uuid === nodeName) {
                return childNode;
              }
              const result = searchNodeSubtree(childNode.children);
              if (result) return result;
            }
            return null;
          };
          const subTreeNode = searchNodeSubtree(root.children);
          if (subTreeNode) {
            return subTreeNode;
          }
        }
        return null;
      }
      // these are used to "bind" a nonexistent property
      _getValue_unavailable() {
      }
      _setValue_unavailable() {
      }
      // Getters
      _getValue_direct(buffer, offset) {
        buffer[offset] = this.targetObject[this.propertyName];
      }
      _getValue_array(buffer, offset) {
        const source = this.resolvedProperty;
        for (let i = 0, n = source.length; i !== n; ++i) {
          buffer[offset++] = source[i];
        }
      }
      _getValue_arrayElement(buffer, offset) {
        buffer[offset] = this.resolvedProperty[this.propertyIndex];
      }
      _getValue_toArray(buffer, offset) {
        this.resolvedProperty.toArray(buffer, offset);
      }
      // Direct
      _setValue_direct(buffer, offset) {
        this.targetObject[this.propertyName] = buffer[offset];
      }
      _setValue_direct_setNeedsUpdate(buffer, offset) {
        this.targetObject[this.propertyName] = buffer[offset];
        this.targetObject.needsUpdate = true;
      }
      _setValue_direct_setMatrixWorldNeedsUpdate(buffer, offset) {
        this.targetObject[this.propertyName] = buffer[offset];
        this.targetObject.matrixWorldNeedsUpdate = true;
      }
      // EntireArray
      _setValue_array(buffer, offset) {
        const dest = this.resolvedProperty;
        for (let i = 0, n = dest.length; i !== n; ++i) {
          dest[i] = buffer[offset++];
        }
      }
      _setValue_array_setNeedsUpdate(buffer, offset) {
        const dest = this.resolvedProperty;
        for (let i = 0, n = dest.length; i !== n; ++i) {
          dest[i] = buffer[offset++];
        }
        this.targetObject.needsUpdate = true;
      }
      _setValue_array_setMatrixWorldNeedsUpdate(buffer, offset) {
        const dest = this.resolvedProperty;
        for (let i = 0, n = dest.length; i !== n; ++i) {
          dest[i] = buffer[offset++];
        }
        this.targetObject.matrixWorldNeedsUpdate = true;
      }
      // ArrayElement
      _setValue_arrayElement(buffer, offset) {
        this.resolvedProperty[this.propertyIndex] = buffer[offset];
      }
      _setValue_arrayElement_setNeedsUpdate(buffer, offset) {
        this.resolvedProperty[this.propertyIndex] = buffer[offset];
        this.targetObject.needsUpdate = true;
      }
      _setValue_arrayElement_setMatrixWorldNeedsUpdate(buffer, offset) {
        this.resolvedProperty[this.propertyIndex] = buffer[offset];
        this.targetObject.matrixWorldNeedsUpdate = true;
      }
      // HasToFromArray
      _setValue_fromArray(buffer, offset) {
        this.resolvedProperty.fromArray(buffer, offset);
      }
      _setValue_fromArray_setNeedsUpdate(buffer, offset) {
        this.resolvedProperty.fromArray(buffer, offset);
        this.targetObject.needsUpdate = true;
      }
      _setValue_fromArray_setMatrixWorldNeedsUpdate(buffer, offset) {
        this.resolvedProperty.fromArray(buffer, offset);
        this.targetObject.matrixWorldNeedsUpdate = true;
      }
      _getValue_unbound(targetArray, offset) {
        this.bind();
        this.getValue(targetArray, offset);
      }
      _setValue_unbound(sourceArray, offset) {
        this.bind();
        this.setValue(sourceArray, offset);
      }
      // create getter / setter pair for a property in the scene graph
      bind() {
        let targetObject = this.node;
        const parsedPath = this.parsedPath;
        const objectName = parsedPath.objectName;
        const propertyName = parsedPath.propertyName;
        let propertyIndex = parsedPath.propertyIndex;
        if (!targetObject) {
          targetObject = _PropertyBinding.findNode(this.rootNode, parsedPath.nodeName);
          this.node = targetObject;
        }
        this.getValue = this._getValue_unavailable;
        this.setValue = this._setValue_unavailable;
        if (!targetObject) {
          console.warn("THREE.PropertyBinding: No target node found for track: " + this.path + ".");
          return;
        }
        if (objectName) {
          let objectIndex = parsedPath.objectIndex;
          switch (objectName) {
            case "materials":
              if (!targetObject.material) {
                console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.", this);
                return;
              }
              if (!targetObject.material.materials) {
                console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.", this);
                return;
              }
              targetObject = targetObject.material.materials;
              break;
            case "bones":
              if (!targetObject.skeleton) {
                console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.", this);
                return;
              }
              targetObject = targetObject.skeleton.bones;
              for (let i = 0; i < targetObject.length; i++) {
                if (targetObject[i].name === objectIndex) {
                  objectIndex = i;
                  break;
                }
              }
              break;
            case "map":
              if ("map" in targetObject) {
                targetObject = targetObject.map;
                break;
              }
              if (!targetObject.material) {
                console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.", this);
                return;
              }
              if (!targetObject.material.map) {
                console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.", this);
                return;
              }
              targetObject = targetObject.material.map;
              break;
            default:
              if (targetObject[objectName] === void 0) {
                console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.", this);
                return;
              }
              targetObject = targetObject[objectName];
          }
          if (objectIndex !== void 0) {
            if (targetObject[objectIndex] === void 0) {
              console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.", this, targetObject);
              return;
            }
            targetObject = targetObject[objectIndex];
          }
        }
        const nodeProperty = targetObject[propertyName];
        if (nodeProperty === void 0) {
          const nodeName = parsedPath.nodeName;
          console.error("THREE.PropertyBinding: Trying to update property for track: " + nodeName + "." + propertyName + " but it wasn't found.", targetObject);
          return;
        }
        let versioning = this.Versioning.None;
        this.targetObject = targetObject;
        if (targetObject.needsUpdate !== void 0) {
          versioning = this.Versioning.NeedsUpdate;
        } else if (targetObject.matrixWorldNeedsUpdate !== void 0) {
          versioning = this.Versioning.MatrixWorldNeedsUpdate;
        }
        let bindingType = this.BindingType.Direct;
        if (propertyIndex !== void 0) {
          if (propertyName === "morphTargetInfluences") {
            if (!targetObject.geometry) {
              console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.", this);
              return;
            }
            if (!targetObject.geometry.morphAttributes) {
              console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.", this);
              return;
            }
            if (targetObject.morphTargetDictionary[propertyIndex] !== void 0) {
              propertyIndex = targetObject.morphTargetDictionary[propertyIndex];
            }
          }
          bindingType = this.BindingType.ArrayElement;
          this.resolvedProperty = nodeProperty;
          this.propertyIndex = propertyIndex;
        } else if (nodeProperty.fromArray !== void 0 && nodeProperty.toArray !== void 0) {
          bindingType = this.BindingType.HasFromToArray;
          this.resolvedProperty = nodeProperty;
        } else if (Array.isArray(nodeProperty)) {
          bindingType = this.BindingType.EntireArray;
          this.resolvedProperty = nodeProperty;
        } else {
          this.propertyName = propertyName;
        }
        this.getValue = this.GetterByBindingType[bindingType];
        this.setValue = this.SetterByBindingTypeAndVersioning[bindingType][versioning];
      }
      unbind() {
        this.node = null;
        this.getValue = this._getValue_unbound;
        this.setValue = this._setValue_unbound;
      }
    };
    PropertyBinding.Composite = Composite;
    PropertyBinding.prototype.BindingType = {
      Direct: 0,
      EntireArray: 1,
      ArrayElement: 2,
      HasFromToArray: 3
    };
    PropertyBinding.prototype.Versioning = {
      None: 0,
      NeedsUpdate: 1,
      MatrixWorldNeedsUpdate: 2
    };
    PropertyBinding.prototype.GetterByBindingType = [
      PropertyBinding.prototype._getValue_direct,
      PropertyBinding.prototype._getValue_array,
      PropertyBinding.prototype._getValue_arrayElement,
      PropertyBinding.prototype._getValue_toArray
    ];
    PropertyBinding.prototype.SetterByBindingTypeAndVersioning = [
      [
        // Direct
        PropertyBinding.prototype._setValue_direct,
        PropertyBinding.prototype._setValue_direct_setNeedsUpdate,
        PropertyBinding.prototype._setValue_direct_setMatrixWorldNeedsUpdate
      ],
      [
        // EntireArray
        PropertyBinding.prototype._setValue_array,
        PropertyBinding.prototype._setValue_array_setNeedsUpdate,
        PropertyBinding.prototype._setValue_array_setMatrixWorldNeedsUpdate
      ],
      [
        // ArrayElement
        PropertyBinding.prototype._setValue_arrayElement,
        PropertyBinding.prototype._setValue_arrayElement_setNeedsUpdate,
        PropertyBinding.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate
      ],
      [
        // HasToFromArray
        PropertyBinding.prototype._setValue_fromArray,
        PropertyBinding.prototype._setValue_fromArray_setNeedsUpdate,
        PropertyBinding.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate
      ]
    ];
    _controlInterpolantsResultBuffer = new Float32Array(1);
    if (typeof __THREE_DEVTOOLS__ !== "undefined") {
      __THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register", { detail: {
        revision: REVISION
      } }));
    }
    if (typeof window !== "undefined") {
      if (window.__THREE__) {
        console.warn("WARNING: Multiple instances of Three.js being imported.");
      } else {
        window.__THREE__ = REVISION;
      }
    }
  }
});

// node_modules/three/examples/jsm/utils/BufferGeometryUtils.js
function mergeGeometries(geometries, useGroups = false) {
  const isIndexed = geometries[0].index !== null;
  const attributesUsed = new Set(Object.keys(geometries[0].attributes));
  const morphAttributesUsed = new Set(Object.keys(geometries[0].morphAttributes));
  const attributes = {};
  const morphAttributes = {};
  const morphTargetsRelative = geometries[0].morphTargetsRelative;
  const mergedGeometry = new BufferGeometry();
  let offset = 0;
  for (let i = 0; i < geometries.length; ++i) {
    const geometry = geometries[i];
    let attributesCount = 0;
    if (isIndexed !== (geometry.index !== null)) {
      console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + i + ". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them.");
      return null;
    }
    for (const name in geometry.attributes) {
      if (!attributesUsed.has(name)) {
        console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + i + '. All geometries must have compatible attributes; make sure "' + name + '" attribute exists among all geometries, or in none of them.');
        return null;
      }
      if (attributes[name] === void 0) attributes[name] = [];
      attributes[name].push(geometry.attributes[name]);
      attributesCount++;
    }
    if (attributesCount !== attributesUsed.size) {
      console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + i + ". Make sure all geometries have the same number of attributes.");
      return null;
    }
    if (morphTargetsRelative !== geometry.morphTargetsRelative) {
      console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + i + ". .morphTargetsRelative must be consistent throughout all geometries.");
      return null;
    }
    for (const name in geometry.morphAttributes) {
      if (!morphAttributesUsed.has(name)) {
        console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + i + ".  .morphAttributes must be consistent throughout all geometries.");
        return null;
      }
      if (morphAttributes[name] === void 0) morphAttributes[name] = [];
      morphAttributes[name].push(geometry.morphAttributes[name]);
    }
    if (useGroups) {
      let count;
      if (isIndexed) {
        count = geometry.index.count;
      } else if (geometry.attributes.position !== void 0) {
        count = geometry.attributes.position.count;
      } else {
        console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + i + ". The geometry must have either an index or a position attribute");
        return null;
      }
      mergedGeometry.addGroup(offset, count, i);
      offset += count;
    }
  }
  if (isIndexed) {
    let indexOffset = 0;
    const mergedIndex = [];
    for (let i = 0; i < geometries.length; ++i) {
      const index = geometries[i].index;
      for (let j = 0; j < index.count; ++j) {
        mergedIndex.push(index.getX(j) + indexOffset);
      }
      indexOffset += geometries[i].attributes.position.count;
    }
    mergedGeometry.setIndex(mergedIndex);
  }
  for (const name in attributes) {
    const mergedAttribute = mergeAttributes(attributes[name]);
    if (!mergedAttribute) {
      console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the " + name + " attribute.");
      return null;
    }
    mergedGeometry.setAttribute(name, mergedAttribute);
  }
  for (const name in morphAttributes) {
    const numMorphTargets = morphAttributes[name][0].length;
    if (numMorphTargets === 0) break;
    mergedGeometry.morphAttributes = mergedGeometry.morphAttributes || {};
    mergedGeometry.morphAttributes[name] = [];
    for (let i = 0; i < numMorphTargets; ++i) {
      const morphAttributesToMerge = [];
      for (let j = 0; j < morphAttributes[name].length; ++j) {
        morphAttributesToMerge.push(morphAttributes[name][j][i]);
      }
      const mergedMorphAttribute = mergeAttributes(morphAttributesToMerge);
      if (!mergedMorphAttribute) {
        console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the " + name + " morphAttribute.");
        return null;
      }
      mergedGeometry.morphAttributes[name].push(mergedMorphAttribute);
    }
  }
  return mergedGeometry;
}
function mergeAttributes(attributes) {
  let TypedArray;
  let itemSize;
  let normalized;
  let gpuType = -1;
  let arrayLength = 0;
  for (let i = 0; i < attributes.length; ++i) {
    const attribute = attributes[i];
    if (TypedArray === void 0) TypedArray = attribute.array.constructor;
    if (TypedArray !== attribute.array.constructor) {
      console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes.");
      return null;
    }
    if (itemSize === void 0) itemSize = attribute.itemSize;
    if (itemSize !== attribute.itemSize) {
      console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes.");
      return null;
    }
    if (normalized === void 0) normalized = attribute.normalized;
    if (normalized !== attribute.normalized) {
      console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes.");
      return null;
    }
    if (gpuType === -1) gpuType = attribute.gpuType;
    if (gpuType !== attribute.gpuType) {
      console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes.");
      return null;
    }
    arrayLength += attribute.count * itemSize;
  }
  const array = new TypedArray(arrayLength);
  const result = new BufferAttribute(array, itemSize, normalized);
  let offset = 0;
  for (let i = 0; i < attributes.length; ++i) {
    const attribute = attributes[i];
    if (attribute.isInterleavedBufferAttribute) {
      const tupleOffset = offset / itemSize;
      for (let j = 0, l = attribute.count; j < l; j++) {
        for (let c = 0; c < itemSize; c++) {
          const value = attribute.getComponent(j, c);
          result.setComponent(j + tupleOffset, c, value);
        }
      }
    } else {
      array.set(attribute.array, offset);
    }
    offset += attribute.count * itemSize;
  }
  if (gpuType !== void 0) {
    result.gpuType = gpuType;
  }
  return result;
}
var init_BufferGeometryUtils = __esm({
  "node_modules/three/examples/jsm/utils/BufferGeometryUtils.js"() {
    init_three_module();
  }
});

// src/game/world.ts
var world_exports = {};
__export(world_exports, {
  World: () => World,
  rayCylinder: () => rayCylinder,
  raySphere: () => raySphere
});
function raySphere(ox, oy, oz, dx, dy, dz, cx, cy, cz, r) {
  const lx = ox - cx, ly = oy - cy, lz = oz - cz;
  const b = lx * dx + ly * dy + lz * dz;
  const c = lx * lx + ly * ly + lz * lz - r * r;
  const disc = b * b - c;
  if (disc < 0) return -1;
  const t = -b - Math.sqrt(disc);
  return t >= 0 ? t : -1;
}
function rayCylinder(ox, oy, oz, dx, dy, dz, cx, cz, y0, y1, r) {
  const px = ox - cx, pz = oz - cz;
  const a = dx * dx + dz * dz;
  if (a < 1e-9) return -1;
  const b = px * dx + pz * dz;
  const c = px * px + pz * pz - r * r;
  const disc = b * b - a * c;
  if (disc < 0) return -1;
  const t = (-b - Math.sqrt(disc)) / a;
  if (t < 0) return -1;
  const y = oy + dy * t;
  if (y < y0 || y > y1) return -1;
  return t;
}
var CELL, World;
var init_world = __esm({
  "src/game/world.ts"() {
    "use strict";
    CELL = 8;
    World = class {
      boxes = [];
      grid = /* @__PURE__ */ new Map();
      stamp = 1;
      heightFn = null;
      bounds = { minX: -100, maxX: 100, minZ: -100, maxZ: 100 };
      // nav grid
      navCell = 1.5;
      navW = 0;
      navH = 0;
      nav = new Uint8Array(0);
      key(cx, cz) {
        return (cx + 512) * 1024 + (cz + 512);
      }
      addBox(minX, minY, minZ, maxX, maxY, maxZ, metal = false) {
        const b = { minX, minY, minZ, maxX, maxY, maxZ, metal, stamp: 0 };
        this.boxes.push(b);
        const x0 = Math.floor(minX / CELL), x1 = Math.floor(maxX / CELL), z0 = Math.floor(minZ / CELL), z1 = Math.floor(maxZ / CELL);
        for (let x = x0; x <= x1; x++) for (let z = z0; z <= z1; z++) {
          const k = this.key(x, z);
          let arr = this.grid.get(k);
          if (!arr) {
            arr = [];
            this.grid.set(k, arr);
          }
          arr.push(b);
        }
        return b;
      }
      ground(x, z) {
        return this.heightFn ? this.heightFn(x, z) : 0;
      }
      /** Boxes overlapping an XZ rectangle (deduplicated) */
      query(minX, minZ, maxX, maxZ, out) {
        out.length = 0;
        const s = ++this.stamp;
        const x0 = Math.floor(minX / CELL), x1 = Math.floor(maxX / CELL), z0 = Math.floor(minZ / CELL), z1 = Math.floor(maxZ / CELL);
        for (let x = x0; x <= x1; x++) for (let z = z0; z <= z1; z++) {
          const arr = this.grid.get(this.key(x, z));
          if (!arr) continue;
          for (const b of arr) if (b.stamp !== s) {
            b.stamp = s;
            if (b.maxX >= minX && b.minX <= maxX && b.maxZ >= minZ && b.minZ <= maxZ) out.push(b);
          }
        }
        return out;
      }
      /** Ray vs boxes (2D DDA through spatial hash) + terrain. dir must be normalised. */
      raycast(ox, oy, oz, dx, dy, dz, maxDist) {
        let best = null;
        let bestT = maxDist;
        const s = ++this.stamp;
        let cx = Math.floor(ox / CELL), cz = Math.floor(oz / CELL);
        const stepX = dx > 0 ? 1 : -1, stepZ = dz > 0 ? 1 : -1;
        const tDX = Math.abs(dx) < 1e-9 ? Infinity : Math.abs(CELL / dx), tDZ = Math.abs(dz) < 1e-9 ? Infinity : Math.abs(CELL / dz);
        let tMX = Math.abs(dx) < 1e-9 ? Infinity : (dx > 0 ? (cx + 1) * CELL - ox : ox - cx * CELL) / Math.abs(dx);
        let tMZ = Math.abs(dz) < 1e-9 ? Infinity : (dz > 0 ? (cz + 1) * CELL - oz : oz - cz * CELL) / Math.abs(dz);
        let tCell = 0;
        for (let iter = 0; iter < 200 && tCell <= bestT; iter++) {
          const arr = this.grid.get(this.key(cx, cz));
          if (arr) for (const b of arr) {
            if (b.stamp === s) continue;
            b.stamp = s;
            let tmin = 0, tmax = bestT, nAxis = -1, nSign = 0;
            let ok = true;
            for (let a = 0; a < 3 && ok; a++) {
              const oa = a === 0 ? ox : a === 1 ? oy : oz, da = a === 0 ? dx : a === 1 ? dy : dz;
              const mna = a === 0 ? b.minX : a === 1 ? b.minY : b.minZ, mxa = a === 0 ? b.maxX : a === 1 ? b.maxY : b.maxZ;
              if (Math.abs(da) < 1e-9) {
                if (oa < mna || oa > mxa) ok = false;
                continue;
              }
              const inv = 1 / da;
              let t1 = (mna - oa) * inv, t2 = (mxa - oa) * inv;
              let sg = -1;
              if (t1 > t2) {
                const tt = t1;
                t1 = t2;
                t2 = tt;
                sg = 1;
              }
              if (t1 > tmin) {
                tmin = t1;
                nAxis = a;
                nSign = sg;
              }
              if (t2 < tmax) tmax = t2;
              if (tmin > tmax) ok = false;
            }
            if (ok && tmin < bestT && nAxis >= 0) {
              bestT = tmin;
              best = { dist: tmin, nx: nAxis === 0 ? nSign : 0, ny: nAxis === 1 ? nSign : 0, nz: nAxis === 2 ? nSign : 0, box: b };
            }
          }
          if (tMX < tMZ) {
            tCell = tMX;
            tMX += tDX;
            cx += stepX;
          } else {
            tCell = tMZ;
            tMZ += tDZ;
            cz += stepZ;
          }
        }
        if (this.heightFn) {
          const step = 1.25;
          let prevT = 0;
          for (let t = step; t <= bestT + step; t += step) {
            const tt = Math.min(t, bestT);
            const y = oy + dy * tt;
            if (y < this.heightFn(ox + dx * tt, oz + dz * tt)) {
              let lo = prevT, hi = tt;
              for (let i = 0; i < 6; i++) {
                const m = (lo + hi) / 2;
                if (oy + dy * m < this.heightFn(ox + dx * m, oz + dz * m)) hi = m;
                else lo = m;
              }
              if (hi < bestT) {
                bestT = hi;
                best = { dist: hi, nx: 0, ny: 1, nz: 0, box: null };
              }
              break;
            }
            prevT = tt;
            if (tt >= bestT) break;
          }
        } else if (dy < -1e-6) {
          const t = -oy / dy;
          if (t > 0 && t < bestT) {
            bestT = t;
            best = { dist: t, nx: 0, ny: 1, nz: 0, box: null };
          }
        }
        return best;
      }
      lineOfSight(a, b) {
        const dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z;
        const d = Math.hypot(dx, dy, dz);
        if (d < 0.01) return true;
        const h = this.raycast(a.x, a.y, a.z, dx / d, dy / d, dz / d, d);
        return !h || h.dist >= d - 0.05;
      }
      // ---------------- character movement ----------------
      tmp = [];
      /** Moves a vertical-cylinder character with wall sliding, step-up (0.5m), gravity and ceilings. Returns landing speed or 0. */
      moveCharacter(pos, vel, radius, height, dt, state) {
        const STEP = 0.5;
        let landed = 0;
        const steps = Math.max(1, Math.ceil(Math.hypot(vel.x, vel.z) * dt / (radius * 0.8)));
        const sdt = dt / steps;
        for (let i = 0; i < steps; i++) {
          pos.x += vel.x * sdt;
          pos.z += vel.z * sdt;
          this.pushOut(pos, radius, height, STEP);
        }
        pos.x = Math.max(this.bounds.minX + radius, Math.min(this.bounds.maxX - radius, pos.x));
        pos.z = Math.max(this.bounds.minZ + radius, Math.min(this.bounds.maxZ - radius, pos.z));
        vel.y -= 24 * dt;
        const newY = pos.y + vel.y * dt;
        const floor = this.floorAt(pos.x, pos.z, radius * 0.7, pos.y + STEP);
        if (vel.y > 0) {
          const ceil = this.ceilingAt(pos.x, pos.z, radius * 0.7, pos.y + height);
          if (newY + height > ceil) {
            pos.y = ceil - height;
            vel.y = 0;
          } else pos.y = newY;
          state.onGround = false;
        } else if (newY <= floor) {
          if (!state.onGround && vel.y < -2) landed = -vel.y;
          pos.y = floor;
          vel.y = 0;
          state.onGround = true;
        } else {
          if (state.onGround && pos.y - floor < STEP * 0.9 && vel.y > -4) {
            pos.y = floor;
            vel.y = 0;
          } else {
            pos.y = newY;
            state.onGround = false;
          }
        }
        return landed;
      }
      pushOut(pos, r, height, step) {
        const boxes = this.query(pos.x - r, pos.z - r, pos.x + r, pos.z + r, this.tmp);
        for (const b of boxes) {
          if (b.maxY <= pos.y + step || b.minY >= pos.y + height) continue;
          const cx = Math.max(b.minX, Math.min(pos.x, b.maxX)), cz = Math.max(b.minZ, Math.min(pos.z, b.maxZ));
          let dx = pos.x - cx, dz = pos.z - cz;
          const d2 = dx * dx + dz * dz;
          if (d2 >= r * r) continue;
          if (d2 > 1e-8) {
            const d = Math.sqrt(d2);
            const push = r - d;
            dx /= d;
            dz /= d;
            pos.x += dx * push;
            pos.z += dz * push;
          } else {
            const l = pos.x - b.minX, rr = b.maxX - pos.x, f = pos.z - b.minZ, bk = b.maxZ - pos.z;
            const m = Math.min(l, rr, f, bk);
            if (m === l) pos.x = b.minX - r;
            else if (m === rr) pos.x = b.maxX + r;
            else if (m === f) pos.z = b.minZ - r;
            else pos.z = b.maxZ + r;
          }
        }
      }
      floorAt(x, z, r, maxY) {
        let f = this.ground(x, z);
        for (const b of this.query(x - r, z - r, x + r, z + r, this.tmp)) if (b.maxY <= maxY && b.maxY > f) f = b.maxY;
        return f;
      }
      ceilingAt(x, z, r, headY) {
        let c = Infinity;
        for (const b of this.query(x - r, z - r, x + r, z + r, this.tmp)) if (b.minY >= headY - 0.6 && b.minY < c) c = b.minY;
        return c;
      }
      // ---------------- navigation grid + A* ----------------
      buildNav(cell = 1.5) {
        this.navCell = cell;
        this.navW = Math.ceil((this.bounds.maxX - this.bounds.minX) / cell);
        this.navH = Math.ceil((this.bounds.maxZ - this.bounds.minZ) / cell);
        this.nav = new Uint8Array(this.navW * this.navH);
        const r = 0.35;
        for (let j = 0; j < this.navH; j++) for (let i = 0; i < this.navW; i++) {
          const x = this.bounds.minX + (i + 0.5) * cell, z = this.bounds.minZ + (j + 0.5) * cell;
          const g = this.ground(x, z);
          let blocked = 0;
          for (const b of this.query(x - r, z - r, x + r, z + r, this.tmp)) {
            if (b.maxY > g + 0.55 && b.minY < g + 1.7 && x > b.minX - r && x < b.maxX + r && z > b.minZ - r && z < b.maxZ + r) {
              blocked = 1;
              break;
            }
          }
          if (!blocked && this.heightFn) {
            const s = Math.abs(this.ground(x + cell, z) - g) + Math.abs(this.ground(x, z + cell) - g);
            if (s > cell * 1.6) blocked = 1;
          }
          this.nav[j * this.navW + i] = blocked;
        }
      }
      toCell(x, z) {
        return [Math.max(0, Math.min(this.navW - 1, Math.floor((x - this.bounds.minX) / this.navCell))), Math.max(0, Math.min(this.navH - 1, Math.floor((z - this.bounds.minZ) / this.navCell)))];
      }
      cellCenter(i, j) {
        return { x: this.bounds.minX + (i + 0.5) * this.navCell, z: this.bounds.minZ + (j + 0.5) * this.navCell };
      }
      walkable(x, z) {
        const [i, j] = this.toCell(x, z);
        return this.nav[j * this.navW + i] === 0;
      }
      nearestWalkable(x, z) {
        const [ci, cj] = this.toCell(x, z);
        for (let r = 0; r < 12; r++) for (let dj = -r; dj <= r; dj++) for (let di = -r; di <= r; di++) {
          if (Math.max(Math.abs(di), Math.abs(dj)) !== r) continue;
          const i = ci + di, j = cj + dj;
          if (i < 0 || j < 0 || i >= this.navW || j >= this.navH) continue;
          if (this.nav[j * this.navW + i] === 0) return this.cellCenter(i, j);
        }
        return { x, z };
      }
      gScore = new Float32Array(0);
      came = new Int32Array(0);
      closed = new Uint32Array(0);
      searchId = 0;
      findPath(sx, sz, tx, tz, maxIter = 9e3) {
        const W = this.navW, H = this.navH, N = W * H;
        if (this.gScore.length !== N) {
          this.gScore = new Float32Array(N);
          this.came = new Int32Array(N);
          this.closed = new Uint32Array(N);
        }
        const sid = ++this.searchId * 2;
        const s = this.nearestWalkable(sx, sz), t = this.nearestWalkable(tx, tz);
        const [si, sj] = this.toCell(s.x, s.z), [ti, tj] = this.toCell(t.x, t.z);
        const start = sj * W + si, goal = tj * W + ti;
        const heap = [], hf = [];
        const push = (n2, f) => {
          heap.push(n2);
          hf.push(f);
          let i = heap.length - 1;
          while (i > 0) {
            const p = i - 1 >> 1;
            if (hf[p] <= hf[i]) break;
            [heap[p], heap[i]] = [heap[i], heap[p]];
            [hf[p], hf[i]] = [hf[i], hf[p]];
            i = p;
          }
        };
        const pop = () => {
          const top = heap[0];
          const ln = heap.pop(), lf = hf.pop();
          if (heap.length) {
            heap[0] = ln;
            hf[0] = lf;
            let i = 0;
            for (; ; ) {
              const l = i * 2 + 1, r = l + 1;
              let m = i;
              if (l < heap.length && hf[l] < hf[m]) m = l;
              if (r < heap.length && hf[r] < hf[m]) m = r;
              if (m === i) break;
              [heap[m], heap[i]] = [heap[i], heap[m]];
              [hf[m], hf[i]] = [hf[i], hf[m]];
              i = m;
            }
          }
          return top;
        };
        const h = (n2) => {
          const dx = Math.abs(n2 % W - ti), dz = Math.abs(Math.floor(n2 / W) - tj);
          return Math.max(dx, dz) + 0.414 * Math.min(dx, dz);
        };
        this.gScore[start] = 0;
        this.closed[start] = sid;
        this.came[start] = -1;
        push(start, h(start));
        let found = false, iter = 0;
        while (heap.length && iter++ < maxIter) {
          const cur = pop();
          if (cur === goal) {
            found = true;
            break;
          }
          if (this.closed[cur] === sid + 1) continue;
          this.closed[cur] = sid + 1;
          const ci = cur % W, cj = Math.floor(cur / W);
          for (let dj = -1; dj <= 1; dj++) for (let di = -1; di <= 1; di++) {
            if (!di && !dj) continue;
            const ni = ci + di, nj = cj + dj;
            if (ni < 0 || nj < 0 || ni >= W || nj >= H) continue;
            const n2 = nj * W + ni;
            if (this.nav[n2]) continue;
            if (di && dj && (this.nav[cj * W + ni] || this.nav[nj * W + ci])) continue;
            const g = this.gScore[cur] + (di && dj ? 1.414 : 1);
            if (this.closed[n2] === sid + 1) continue;
            if (this.closed[n2] !== sid || g < this.gScore[n2]) {
              this.closed[n2] = sid;
              this.gScore[n2] = g;
              this.came[n2] = cur;
              push(n2, g + h(n2));
            }
          }
        }
        if (!found) return null;
        const pts = [];
        let n = goal;
        let guard = 0;
        while (n !== -1 && guard++ < 1e4) {
          pts.push(this.cellCenter(n % W, Math.floor(n / W)));
          if (n === start) break;
          n = this.came[n];
        }
        pts.reverse();
        const out = [];
        let anchor = pts[0];
        let k = 1;
        while (k < pts.length) {
          let far = k;
          for (let m = k; m < Math.min(pts.length, k + 14); m++) if (this.gridLine(anchor.x, anchor.z, pts[m].x, pts[m].z)) far = m;
          out.push(pts[far]);
          anchor = pts[far];
          k = far + 1;
        }
        out.push({ x: tx, z: tz });
        return out;
      }
      gridLine(x0, z0, x1, z1) {
        const d = Math.hypot(x1 - x0, z1 - z0);
        const n = Math.ceil(d / (this.navCell * 0.5));
        for (let i = 1; i < n; i++) {
          const t = i / n;
          if (!this.walkable(x0 + (x1 - x0) * t, z0 + (z1 - z0) * t)) return false;
        }
        return true;
      }
    };
  }
});

// src/game/textures.ts
function rnd(seed) {
  return () => {
    seed = seed * 16807 % 2147483647;
    return (seed - 1) / 2147483646;
  };
}
function noiseFill(ctx, s, base, amp, r, count = 1) {
  const img = ctx.createImageData(s, s);
  for (let i = 0; i < s * s; i++) {
    const n = (r() - 0.5) * amp;
    img.data[i * 4] = base[0] + n;
    img.data[i * 4 + 1] = base[1] + n;
    img.data[i * 4 + 2] = base[2] + n;
    img.data[i * 4 + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  for (let k = 0; k < count * 40; k++) {
    ctx.fillStyle = `rgba(${r() > 0.5 ? "0,0,0" : "255,255,255"},${r() * 0.06})`;
    const w = r() * s * 0.3;
    ctx.beginPath();
    ctx.ellipse(r() * s, r() * s, w, w * (0.3 + r()), r() * 3, 0, 7);
    ctx.fill();
  }
}
function draw(key, s) {
  const c = document.createElement("canvas");
  c.width = c.height = s;
  const ctx = c.getContext("2d");
  const r = rnd(key.length * 977 + s);
  const u = s / 256;
  switch (key) {
    case "concrete":
      noiseFill(ctx, s, [128, 128, 124], 28, r, 2);
      ctx.strokeStyle = "rgba(0,0,0,0.18)";
      ctx.lineWidth = 2 * u;
      ctx.strokeRect(0, 0, s, s);
      ctx.beginPath();
      ctx.moveTo(0, s / 2);
      ctx.lineTo(s, s / 2);
      ctx.stroke();
      break;
    case "asphalt":
      noiseFill(ctx, s, [52, 54, 56], 26, r, 1);
      for (let i = 0; i < 6; i++) {
        ctx.strokeStyle = "rgba(20,20,20,0.5)";
        ctx.lineWidth = u;
        ctx.beginPath();
        let x = r() * s, y = r() * s;
        ctx.moveTo(x, y);
        for (let j = 0; j < 5; j++) {
          x += (r() - 0.5) * 40 * u;
          y += (r() - 0.5) * 40 * u;
          ctx.lineTo(x, y);
        }
        ctx.stroke();
      }
      break;
    case "brick":
      ctx.fillStyle = "#5e5a55";
      ctx.fillRect(0, 0, s, s);
      for (let y = 0; y < 16; y++) for (let x = 0; x < 8; x++) {
        const sh = 110 + r() * 50;
        ctx.fillStyle = `rgb(${sh},${sh * 0.55},${sh * 0.42})`;
        ctx.fillRect(((x + y % 2 * 0.5) * 32 - 16) * u, y * 16 * u + u, 30 * u, 14 * u);
      }
      break;
    case "facade":
    case "facadeDesert": {
      const desert = key === "facadeDesert";
      noiseFill(ctx, s, desert ? [176, 150, 112] : [104, 108, 114], 18, r, 1);
      for (let y = 0; y < 2; y++) for (let x = 0; x < 2; x++) {
        const lit = r() > 0.75;
        ctx.fillStyle = desert ? "#3a2e22" : lit ? "#d8c27a" : "#1d2630";
        ctx.fillRect((x * 128 + 30) * u, (y * 128 + 34) * u, 68 * u, 64 * u);
        ctx.fillStyle = "rgba(255,255,255,0.12)";
        ctx.fillRect((x * 128 + 30) * u, (y * 128 + 34) * u, 68 * u, 6 * u);
        ctx.fillStyle = desert ? "#9a8260" : "#50555c";
        ctx.fillRect((x * 128 + 24) * u, (y * 128 + 98) * u, 80 * u, 6 * u);
      }
      break;
    }
    case "sand":
      noiseFill(ctx, s, [190, 165, 120], 22, r, 2);
      break;
    case "grass":
      noiseFill(ctx, s, [92, 98, 60], 30, r, 2);
      break;
    case "metal":
      noiseFill(ctx, s, [120, 126, 132], 14, r, 1);
      for (let i = 0; i < s; i += 32 * u) {
        ctx.fillStyle = "rgba(0,0,0,0.15)";
        ctx.fillRect(i, 0, 2 * u, s);
      }
      break;
    case "container":
      ctx.fillStyle = "#888";
      ctx.fillRect(0, 0, s, s);
      for (let i = 0; i < 16; i++) {
        ctx.fillStyle = i % 2 ? "rgba(0,0,0,0.22)" : "rgba(255,255,255,0.12)";
        ctx.fillRect(i * 16 * u, 0, 8 * u, s);
      }
      ctx.fillStyle = "rgba(80,40,20,0.25)";
      for (let i = 0; i < 20; i++) ctx.fillRect(r() * s, r() * s, r() * 30 * u, r() * 6 * u);
      break;
    case "crate":
      ctx.fillStyle = "#7a5a34";
      ctx.fillRect(0, 0, s, s);
      for (let i = 0; i < 8; i++) {
        const sh = 100 + r() * 40;
        ctx.fillStyle = `rgb(${sh},${sh * 0.72},${sh * 0.42})`;
        ctx.fillRect(0, i * 32 * u + u, s, 30 * u);
      }
      ctx.strokeStyle = "#3b2814";
      ctx.lineWidth = 14 * u;
      ctx.strokeRect(7 * u, 7 * u, s - 14 * u, s - 14 * u);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(s, s);
      ctx.stroke();
      break;
    case "sandbag":
      ctx.fillStyle = "#6b6046";
      ctx.fillRect(0, 0, s, s);
      for (let y = 0; y < 4; y++) for (let x = 0; x < 3; x++) {
        const sh = 130 + r() * 30;
        ctx.fillStyle = `rgb(${sh},${sh * 0.9},${sh * 0.65})`;
        ctx.beginPath();
        ctx.roundRect(((x + y % 2 * 0.5) * 90 - 40) * u, (y * 64 + 4) * u, 84 * u, 56 * u, 22 * u);
        ctx.fill();
      }
      break;
    case "rock":
      noiseFill(ctx, s, [140, 112, 86], 40, r, 4);
      break;
    case "tile":
      ctx.fillStyle = "#8a8478";
      ctx.fillRect(0, 0, s, s);
      for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) {
        const sh = 140 + r() * 30;
        ctx.fillStyle = `rgb(${sh},${sh * 0.96},${sh * 0.9})`;
        ctx.fillRect(x * 64 * u + 2 * u, y * 64 * u + 2 * u, 60 * u, 60 * u);
      }
      break;
    case "roof":
      noiseFill(ctx, s, [70, 72, 74], 20, r, 2);
      break;
    case "target":
      ctx.fillStyle = "#e8e2d0";
      ctx.fillRect(0, 0, s, s);
      for (let i = 5; i > 0; i--) {
        ctx.fillStyle = i % 2 ? "#c0392b" : "#f5f0e0";
        ctx.beginPath();
        ctx.arc(s / 2, s / 2, i * 24 * u, 0, 7);
        ctx.fill();
      }
      break;
  }
  return c;
}
function getTexture(key, quality) {
  const id = key + quality;
  let t = cache.get(id);
  if (!t) {
    const size = quality === 0 ? 64 : quality === 1 ? 128 : 256;
    t = new CanvasTexture(draw(key, size));
    t.wrapS = t.wrapT = RepeatWrapping;
    t.colorSpace = SRGBColorSpace;
    t.anisotropy = quality === 2 ? 8 : quality === 1 ? 4 : 1;
    t.generateMipmaps = true;
    cache.set(id, t);
  }
  return t;
}
var cache;
var init_textures = __esm({
  "src/game/textures.ts"() {
    "use strict";
    init_three_module();
    cache = /* @__PURE__ */ new Map();
  }
});

// src/game/maps.ts
var maps_exports = {};
__export(maps_exports, {
  buildMap: () => buildMap
});
function skyDome(sky, radius) {
  const g = new SphereGeometry(radius, 24, 12);
  const top = new Color(sky.top), bot = new Color(sky.bottom);
  const cols = [];
  const p = g.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const k = Math.max(0, p.getY(i) / radius);
    const c = bot.clone().lerp(top, Math.pow(k, 0.6));
    cols.push(c.r, c.g, c.b);
  }
  g.setAttribute("color", new Float32BufferAttribute(cols, 3));
  const m = new Mesh(g, new MeshBasicMaterial({ vertexColors: true, side: BackSide, fog: false, depthWrite: false }));
  m.renderOrder = -10;
  m.frustumCulled = false;
  return m;
}
function makeMinimap(world) {
  const S2 = 256;
  const c = document.createElement("canvas");
  c.width = c.height = S2;
  const ctx = c.getContext("2d");
  const { minX, maxX, minZ, maxZ } = world.bounds;
  const sx = S2 / (maxX - minX), sz = S2 / (maxZ - minZ);
  ctx.fillStyle = "#1b2228";
  ctx.fillRect(0, 0, S2, S2);
  if (world.heightFn) {
    for (let j = 0; j < S2; j += 4) for (let i = 0; i < S2; i += 4) {
      const h = world.heightFn(minX + i / sx, minZ + j / sz);
      const v = Math.min(255, 40 + h * 9);
      ctx.fillStyle = `rgb(${v * 0.9},${v * 0.8},${v * 0.6})`;
      ctx.fillRect(i, j, 4, 4);
    }
  }
  const sorted = world.boxes.slice().sort((a, b) => a.maxY - b.maxY);
  for (const b of sorted) {
    if (b.maxY - b.minY < 0.5 && b.maxY < 1) continue;
    const v = Math.min(220, 70 + b.maxY * 6);
    ctx.fillStyle = `rgb(${v},${v + 8},${v + 14})`;
    ctx.fillRect((b.minX - minX) * sx, (b.minZ - minZ) * sz, Math.max(1, (b.maxX - b.minX) * sx), Math.max(1, (b.maxZ - b.minZ) * sz));
  }
  return c;
}
function walkableSpots(world, pts) {
  return pts.map(([x, z]) => {
    const p = world.nearestWalkable(x, z);
    return new Vector3(p.x, world.ground(p.x, p.z), p.z);
  });
}
function randomPatrol(world, n, rand) {
  const out = [];
  const { minX, maxX, minZ, maxZ } = world.bounds;
  for (let i = 0; i < n * 4 && out.length < n; i++) {
    const x = minX + 6 + rand() * (maxX - minX - 12), z = minZ + 6 + rand() * (maxZ - minZ - 12);
    if (world.walkable(x, z)) out.push(new Vector3(x, world.ground(x, z), z));
  }
  return out;
}
function buildIron(b) {
  const w = b.world;
  const H = 84;
  w.bounds = { minX: -H, maxX: H, minZ: -H, maxZ: H };
  b.setSeed(1337);
  b.box(0, -0.5, 0, H * 2, 0.5, H * 2, "concrete", false);
  const roads = [-42, 0, 42];
  for (const r of roads) {
    b.box(r, -0.48, 0, 11, 0.5, H * 2, "asphalt", false);
    b.box(0, -0.47, r, H * 2, 0.5, 11, "asphalt", false);
  }
  for (const r of roads) for (let s = -H; s < H; s += 6) {
    b.box(r, 0.02, s, 0.2, 0.01, 2.5, "line", false);
    b.box(s, 0.02, r, 2.5, 0.01, 0.2, "line", false);
  }
  for (let s = -H; s < H; s += 14) {
    const h1 = 14 + b.rand() * 16, h2 = 14 + b.rand() * 16, h3 = 14 + b.rand() * 16, h4 = 14 + b.rand() * 16;
    b.box(s + 7, 0, -H - 3, 14, h1, 6, "facade");
    b.box(s + 7, 0, H + 3, 14, h2, 6, "facade");
    b.box(-H - 3, 0, s + 7, 6, h3, 14, "facade");
    b.box(H + 3, 0, s + 7, 6, h4, 14, "facade");
  }
  b.box(0, 0, 0, 7, 0.6, 7, "concrete");
  b.box(0, 0.6, 0, 2.4, 3, 2.4, "concrete");
  b.box(0, 3.6, 0, 1.2, 4, 1.2, "metal", true, true);
  b.box(0, 7.6, 0, 2.6, 0.5, 0.6, "metal", false);
  const spans = [[-H + 1, -48], [-36, -6], [6, 36], [48, H - 1]];
  const types = ["A", "B", "C", "A", "D", "A", "B", "A", "A", "B", "A", "D", "B", "A", "C", "A"];
  let k = 0;
  for (const [x0, x1] of spans) for (const [z0, z1] of spans) {
    const t = types[k++];
    const cx = (x0 + x1) / 2, cz = (z0 + z1) / 2, bw = x1 - x0, bd = z1 - z0;
    b.box(cx, 0, cz, bw, 0.15, bd, "concrete", false);
    if (t === "A") {
      const doors = ["n", "s", b.rand() > 0.5 ? "e" : "w"];
      b.building(cx - bw * 0.15, cz, Math.min(16, bw * 0.55), Math.min(14, bd * 0.5), b.rand() > 0.5 ? 3 : 2, 0, b.rand() > 0.5 ? "brick" : "facade", doors);
      b.tower(cx + bw * 0.33, cz - bd * 0.25, bw * 0.24, bd * 0.35, 12 + b.rand() * 14, 0, "facade");
      b.box(cx + bw * 0.33, 0, cz + bd * 0.3, 1.6, 1.4, 2.4, "contGreen", true, true);
      b.box(cx + bw * 0.25, 0, cz + bd * 0.12, 1.2, 1.1, 1.2, "crate");
      b.crateSpots.push(new Vector3(cx + bw * 0.3, 0, cz + bd * 0.05));
    } else if (t === "B") {
      const gap = 4;
      b.tower(cx - bw / 4 - gap / 4, cz - bd / 4 - gap / 4, bw / 2 - gap, bd / 2 - gap, 18 + b.rand() * 18, 0, "facade");
      b.tower(cx + bw / 4 + gap / 4, cz - bd / 4 - gap / 4, bw / 2 - gap, bd / 2 - gap, 10 + b.rand() * 10, 0, "brick");
      b.tower(cx - bw / 4 - gap / 4, cz + bd / 4 + gap / 4, bw / 2 - gap, bd / 2 - gap, 12 + b.rand() * 12, 0, "brick");
      b.building(cx + bw / 4 + gap / 4, cz + bd / 4 + gap / 4, bw / 2 - gap, bd / 2 - gap, 2, 0, "facade", ["n", "w"]);
      b.box(cx, 0, cz, 1.5, 1.3, 2.5, "contBlue", true, true);
      b.crateSpots.push(new Vector3(cx + 2, 0, cz - 2));
    } else if (t === "C") {
      for (let i = 0; i < 6; i++) b.tree(cx + (b.rand() - 0.5) * bw * 0.8, cz + (b.rand() - 0.5) * bd * 0.8);
      b.box(cx, 0, cz, 6, 0.8, 6, "concrete");
      b.box(cx, 0.8, cz, 1, 2.5, 1, "metal", true, true);
      b.box(cx - bw * 0.3, 0, cz, 0.6, 1.1, bd * 0.4, "concrete");
      b.box(cx + bw * 0.3, 0, cz, 0.6, 1.1, bd * 0.4, "concrete");
      b.box(cx, 0, cz - bd * 0.32, bw * 0.4, 1.1, 0.6, "concrete");
      b.crateSpots.push(new Vector3(cx + 4, 0, cz + 4));
      b.lootSpots.push(new Vector3(cx - 4, 0, cz - 4));
    } else {
      for (let i = 0; i < 4; i++) b.container(cx - bw * 0.3 + i * bw * 0.2, cz - bd * 0.2 + i % 2 * bd * 0.35, false, 0, i === 1 ? 2 : 1);
      for (let i = 0; i < 3; i++) b.car(cx - bw * 0.25 + i * bw * 0.25, cz + bd * 0.33, true);
      b.crateSpots.push(new Vector3(cx, 0, cz));
      b.lootSpots.push(new Vector3(cx + 3, 0, cz - 6));
    }
  }
  for (const r of roads) for (let i = 0; i < 6; i++) {
    const s = -H + 12 + b.rand() * (H * 2 - 24);
    if (Math.abs(s) < 8 || roads.some((q) => Math.abs(q - s) < 7)) continue;
    if (b.rand() > 0.5) b.car(r + (b.rand() > 0.5 ? 2.5 : -2.5), s, false);
    else b.car(s, r + (b.rand() > 0.5 ? 2.5 : -2.5), true);
  }
  for (const rx of roads) for (const rz of roads) if (rx || rz) {
    b.box(rx + 4, 0, rz + 4, 2.6, 1, 0.6, "concrete");
    b.box(rx - 4, 0, rz - 4, 0.6, 1, 2.6, "concrete");
    b.lootSpots.push(new Vector3(rx + 3, 0, rz - 3));
  }
  const tx = 60, tz = 60;
  for (const [dx, dz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) b.box(tx + dx * 1.3, 0, tz + dz * 1.3, 0.3, 34, 0.3, "metal", true, true);
  for (let y = 4; y < 34; y += 5) b.box(tx, y, tz, 2.9, 0.2, 2.9, "metal", false);
  b.box(tx, 34, tz, 0.5, 0.5, 0.5, "redLight", false);
  const spawns = [];
  for (const r of roads) for (let s = -70; s <= 70; s += 20) {
    spawns.push([r, s]);
    spawns.push([s, r]);
  }
  return {
    spawns: [],
    _spawnPts: spawns,
    _team: [[[-60, 72], [-20, 72], [20, 72], [60, 72], [0, 64], [-42, 60], [42, 60]], [[-60, -72], [-20, -72], [20, -72], [60, -72], [0, -64], [-42, -60], [42, -60]]],
    _start: [0, 30],
    sky: { top: 3820130, bottom: 12622458, fog: 9079440, sunDir: new Vector3(-0.6, 0.45, -0.5).normalize(), sun: 16763034, sunI: 2.2, amb: 8425648, ambI: 0.9 }
  };
}
function buildDust(b) {
  const w = b.world;
  const H = 120;
  w.bounds = { minX: -H, maxX: H, minZ: -H, maxZ: H };
  b.setSeed(4242);
  const zones = [{ x: -60, z: -55, r: 40, h: 0 }, { x: 55, z: 50, r: 34, h: 0 }, { x: 62, z: -60, r: 20, h: 9 }, { x: -55, z: 60, r: 26, h: 0 }, { x: 0, z: 0, r: 18, h: 0 }];
  const roads = [[-60, -55, 0, 0], [0, 0, 55, 50], [-55, 60, 0, 0], [0, 0, 62, -60]];
  const segDist = (x, z, s) => {
    const [ax, az, bx2, bz2] = s;
    const vx = bx2 - ax, vz = bz2 - az;
    const t = Math.max(0, Math.min(1, ((x - ax) * vx + (z - az) * vz) / (vx * vx + vz * vz)));
    return Math.hypot(x - ax - vx * t, z - az - vz * t);
  };
  const sstep = (a, bb, x) => {
    const t = Math.max(0, Math.min(1, (x - a) / (bb - a)));
    return t * t * (3 - 2 * t);
  };
  const raw = (x, z) => 4.5 + Math.sin(x * 0.035) * Math.cos(z * 0.03) * 5 + Math.sin(x * 0.08 + 2) * Math.sin(z * 0.07 + 1) * 2 + Math.max(0, Math.abs(x) - 90) * 0.35 + Math.max(0, Math.abs(z) - 90) * 0.35;
  const heightFn = (x, z) => {
    let h = raw(x, z);
    for (const zn of zones) {
      const m = sstep(zn.r, zn.r + 16, Math.hypot(x - zn.x, z - zn.z));
      h = zn.h + (h - zn.h) * m;
    }
    let rd = Infinity;
    for (const s of roads) rd = Math.min(rd, segDist(x, z, s));
    const rm = sstep(4, 12, rd);
    const roadH = raw(x, z) * 0.35;
    h = roadH + (h - roadH) * rm;
    return Math.max(0, h);
  };
  w.heightFn = heightFn;
  const seg = b.quality === 0 ? 80 : 120;
  const tg = new PlaneGeometry(H * 2, H * 2, seg, seg);
  tg.rotateX(-Math.PI / 2);
  const pos = tg.attributes.position;
  const cols = [];
  const uv = tg.attributes.uv;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), z = pos.getZ(i);
    const y = heightFn(x, z);
    pos.setY(i, y);
    let rd = Infinity;
    for (const s of roads) rd = Math.min(rd, segDist(x, z, s));
    const road = rd < 4.5 ? 1 : 0;
    const shade = 0.85 + Math.sin(x * 0.3) * Math.cos(z * 0.27) * 0.05 + y * 0.012;
    if (road) cols.push(0.42, 0.38, 0.33);
    else cols.push(shade, shade * 0.93, shade * 0.82);
    uv.setXY(i, x / 8, z / 8);
  }
  tg.setAttribute("color", new Float32BufferAttribute(cols, 3));
  tg.computeVertexNormals();
  const tm = b.lowMat ? new MeshLambertMaterial({ map: getTexture("sand", b.quality), vertexColors: true }) : new MeshStandardMaterial({ map: getTexture("sand", b.quality), vertexColors: true, roughness: 0.95 });
  const terrain = new Mesh(tg, tm);
  terrain.receiveShadow = true;
  b.addMesh(terrain);
  b.disposables.push(tg, tm);
  const gy = (x, z) => heightFn(x, z);
  const bx = -60, bz = -55, S2 = 28;
  for (const side of [-1, 1]) {
    b.wall("x", bx - S2, bx + S2, bz + side * S2, 0, 3, 0.6, "concrete", [{ at: bx, w: 8, y0: 0, y1: 3 }]);
    b.wall("z", bz - S2, bz + S2, bx + side * S2, 0, 3, 0.6, "concrete", [{ at: bz, w: 8, y0: 0, y1: 3 }]);
  }
  for (const [wx, wz] of [[-72, -64], [-48, -64]]) {
    const ww = 16, wd = 12, wh = 6.5;
    b.wall("x", wx - ww / 2, wx + ww / 2, wz - wd / 2, 0, wh, 0.35, "metal", [{ at: wx, w: 4.5, y0: 0, y1: 4.2 }]);
    b.wall("x", wx - ww / 2, wx + ww / 2, wz + wd / 2, 0, wh, 0.35, "metal", [{ at: wx, w: 4.5, y0: 0, y1: 4.2 }]);
    b.wall("z", wz - wd / 2, wz + wd / 2, wx - ww / 2, 0, wh, 0.35, "metal", [{ at: wz, w: 2, y0: 0, y1: 2.5 }]);
    b.wall("z", wz - wd / 2, wz + wd / 2, wx + ww / 2, 0, wh, 0.35, "metal");
    b.box(wx, wh, wz, ww + 0.6, 0.3, wd + 0.6, "roof");
    b.box(wx - 4, 0, wz - 2, 2.4, 1.6, 1.2, "crate");
    b.box(wx + 4, 0, wz + 2, 1.2, 2.4, 1.2, "crate");
    b.box(wx + 3, 0, wz - 3, 1.2, 1.2, 1.2, "crate");
    b.lootSpots.push(new Vector3(wx, 0, wz));
    b.crateSpots.push(new Vector3(wx - 5, 0, wz + 3));
  }
  b.building(-58, -42, 12, 9, 2, 0, "plaster", ["s", "e"], true, "concrete");
  for (const [tx, tz] of [[bx - S2 + 3, bz - S2 + 3], [bx + S2 - 3, bz + S2 - 3]]) {
    for (const [dx, dz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) b.box(tx + dx * 1.4, 0, tz + dz * 1.4, 0.3, 5, 0.3, "wood");
    b.box(tx, 5, tz, 3.4, 0.25, 3.4, "wood");
    b.wall("x", tx - 1.7, tx + 1.7, tz + 1.6, 5.25, 1.1, 0.15, "sandbag");
    b.wall("z", tz - 1.5, tz + 1.5, tx + 1.6, 5.25, 1.1, 0.15, "sandbag");
    b.box(tx, 7.4, tz, 3.8, 0.2, 3.8, "roof", false);
    b.stairs(tx, tz - 1.7 - 16 * 0.5, 0, 5.25, 1.2, 1, "wood");
    b.lootSpots.push(new Vector3(tx, 5.3, tz));
  }
  for (let i = 0; i < 5; i++) b.container(bx + 10 + i % 3 * 3.2, bz + 8 + Math.floor(i / 3) * 7, false, 0, i === 1 ? 2 : 1);
  b.sandbags(bx, bz + S2 + 4, 6, true);
  b.sandbags(bx + S2 + 4, bz, 6, false);
  b.sandbags(bx - 6, bz + 2, 5, true);
  b.sandbags(bx + 2, bz - 8, 5, false);
  b.box(bx - 12, 0.01, bz + 14, 9, 0.05, 9, "concrete", false);
  b.crateSpots.push(new Vector3(bx - 12, 0, bz + 14), new Vector3(bx + 5, 0, bz - 2));
  const houses = [[45, 40, 9, 8, 2], [62, 38, 8, 8, 1], [44, 58, 10, 8, 2], [63, 60, 9, 9, 2], [54, 49, 7, 7, 1], [72, 48, 8, 7, 1]];
  for (const [hx, hz, hw, hd, fl] of houses) b.building(hx, hz, hw, hd, fl, 0, "facadeDesert", ["n", "s"], true, "tile");
  b.wall("x", 36, 52, 70, 0, 2, 0.4, "plaster", [{ at: 44, w: 3, y0: 0, y1: 2 }]);
  b.wall("z", 30, 46, 80, 0, 2, 0.4, "plaster");
  for (let i = 0; i < 3; i++) {
    b.box(52 + i * 3, 0, 32, 2.2, 0.9, 1.2, "wood");
    b.box(52 + i * 3, 2.2, 32, 2.6, 0.08, 1.8, "contRed", false);
  }
  b.crateSpots.push(new Vector3(54, 0, 44), new Vector3(68, 0, 54));
  const ry = 9;
  b.building(60, -58, 10, 8, 1, ry, "concrete", ["w", "s"], true, "concrete");
  b.box(70, ry, -66, 1, 6, 1, "metal", true, true);
  const dish = new Group();
  dish.position.set(70, ry + 6.5, -66);
  const dm = new Mesh(new SphereGeometry(3, 16, 8, 0, Math.PI * 2, 0, Math.PI / 3.5), new MeshStandardMaterial({ color: 14211280, side: DoubleSide, metalness: 0.4, roughness: 0.5 }));
  dm.rotation.x = Math.PI / 2.4;
  dish.add(dm);
  b.addMesh(dish);
  b.disposables.push(dm.geometry, dm.material);
  b.sandbags(52, -48, 6, true, ry);
  b.sandbags(72, -52, 5, false, ry);
  b.crateSpots.push(new Vector3(56, ry, -50));
  const tankMat = b.lowMat ? new MeshLambertMaterial({ color: 13157560 }) : new MeshStandardMaterial({ color: 13157560, metalness: 0.5, roughness: 0.45 });
  b.disposables.push(tankMat);
  for (const [fx, fz] of [[-64, 54], [-50, 54], [-64, 68], [-50, 68]]) {
    const tg2 = new CylinderGeometry(4, 4, 7, 20);
    const t = new Mesh(tg2, tankMat);
    t.position.set(fx, 3.5, fz);
    t.castShadow = t.receiveShadow = true;
    b.addMesh(t);
    b.disposables.push(tg2);
    w.addBox(fx - 3.6, 0, fz - 3.6, fx + 3.6, 7, fz + 3.6, true);
  }
  b.box(-57, 1.2, 61, 20, 0.4, 0.4, "metal", false);
  b.box(-57, 0, 61, 1.5, 1.5, 1.5, "metal", true, true);
  b.building(-40, 70, 9, 8, 1, 0, "plaster", ["w", "n"], true, "concrete");
  b.container(-44, 50, true, 0, 2);
  b.container(-70, 44, false, 0, 1);
  b.crateSpots.push(new Vector3(-57, 0, 46));
  b.building(6, -5, 6, 5, 1, 0, "concrete", ["w", "n"], true, "concrete");
  b.box(-3, 0, 4, 6, 1, 0.6, "concrete");
  b.box(4, 0, 6, 0.6, 1, 4, "concrete");
  b.sandbags(-6, -6, 4, false);
  b.sandbags(-2, -9, 4, true);
  b.box(-8, 0, 10, 3.4, 1.3, 6.5, "olive", true, true);
  b.box(-8, 1.3, 9.6, 2.4, 0.9, 2.6, "olive", true, true);
  b.box(-8, 1.7, 6.4, 0.25, 0.25, 4, "dark", false);
  b.crateSpots.push(new Vector3(2, 0, 4));
  for (let i = 0; i < 70; i++) {
    const x = -110 + b.rand() * 220, z = -110 + b.rand() * 220;
    if (zones.some((zn) => Math.hypot(x - zn.x, z - zn.z) < zn.r + 4) || roads.some((s2) => segDist(x, z, s2) < 6)) continue;
    const s = 1 + b.rand() * 3.2;
    const y = gy(x, z) - 0.4;
    b.box(x, y, z, s * (0.8 + b.rand() * 0.6), s * (0.6 + b.rand() * 0.8), s * (0.8 + b.rand() * 0.6), "rock");
    if (i % 9 === 0) b.lootSpots.push(new Vector3(x + s + 1, gy(x + s + 1, z), z));
  }
  for (let i = 0; i < 10; i++) {
    const x = -100 + b.rand() * 200, z = -100 + b.rand() * 200;
    if (!zones.some((zn) => Math.hypot(x - zn.x, z - zn.z) < zn.r + 2)) b.sandbags(x, z, 4, b.rand() > 0.5, gy(x, z) - 0.1);
  }
  return {
    _spawnPts: [[-60, -30], [-30, -28], [0, -20], [25, 25], [40, 70], [80, 30], [62, -40], [-40, 40], [-80, 20], [20, -80], [-20, 90], [90, -10], [-90, -90], [95, 95], [0, 40], [-95, 0]],
    _team: [[[-60, -45], [-66, -40], [-52, -48], [-62, -60], [-55, -35], [-70, -50], [-50, -55]], [[55, 48], [60, 45], [50, 54], [58, 66], [66, 52], [48, 44], [62, 40]]],
    _start: [0, 15],
    sky: { top: 4881080, bottom: 15258800, fog: 14207144, sunDir: new Vector3(0.5, 0.8, 0.3).normalize(), sun: 16773336, sunI: 2.8, amb: 10531016, ambI: 1 }
  };
}
function buildRange(b) {
  const w = b.world;
  w.bounds = { minX: -30, maxX: 30, minZ: -140, maxZ: 20 };
  b.setSeed(7);
  b.box(0, -0.5, -60, 60, 0.5, 160, "concrete", false);
  b.box(0, -0.48, -70, 50, 0.5, 130, "sand", false);
  b.wall("z", -140, 20, -30, 0, 6, 1, "concrete");
  b.wall("z", -140, 20, 30, 0, 6, 1, "concrete");
  b.wall("x", -30, 30, 20, 0, 6, 1, "concrete");
  b.box(0, 0, -140, 60, 14, 2, "concrete");
  b.box(0, 0, -137, 56, 8, 3, "sandbag", false);
  for (const x of [-22, -11, 0, 11, 22]) b.box(x, 0, 0, 8, 1.05, 0.6, "wood");
  b.box(0, 4, 4, 60, 0.3, 10, "roof", false);
  for (const x of [-27, 27]) b.box(x, 0, 4, 0.4, 4, 0.4, "metal", false);
  for (const x of [-16, -5.5, 5.5, 16]) b.box(x, 0, -12, 0.3, 1.2, 10, "concrete");
  for (const d of [10, 25, 50, 75, 100, 120]) b.box(-28, 0, -d, 0.4, 2.4, 3, "white", false);
  b.box(-20, 0, -40, 6, 2.5, 0.5, "concrete");
  b.box(20, 0, -40, 6, 2.5, 0.5, "concrete");
  b.box(0, 0, -62, 8, 1.2, 0.6, "sandbag");
  b.box(-24, 0, 12, 4, 0.9, 1.5, "dark");
  b.box(24, 0, 12, 4, 0.9, 1.5, "dark");
  const targets = [];
  for (const [x, d] of [[-22, 10], [-11, 15], [0, 10], [11, 15], [22, 10]]) targets.push({ x, z: -d, kind: "dummy" });
  for (const [x, d] of [[-20, 25], [-6, 35], [8, 50], [18, 75], [-12, 100], [4, 120]]) targets.push({ x, z: -d, kind: "static" });
  targets.push({ x: 0, z: -30, kind: "moving", minX: -14, maxX: 14, speed: 3.5 });
  targets.push({ x: 0, z: -55, kind: "moving", minX: -20, maxX: 20, speed: 5 });
  targets.push({ x: 0, z: -85, kind: "moving", minX: -18, maxX: 18, speed: 4 });
  return {
    targets,
    _spawnPts: [[0, 8]],
    _team: [[[0, 8]], [[0, -100]]],
    _start: [0, 8],
    sky: { top: 5798568, bottom: 14209216, fog: 13158592, sunDir: new Vector3(0.3, 0.9, 0.4).normalize(), sun: 16777215, sunI: 2.4, amb: 11583696, ambI: 1.1 }
  };
}
function buildMap(id, quality) {
  const b = new Builder(quality.textures, quality.lowMat);
  const partial = id === "iron" ? buildIron(b) : id === "dust" ? buildDust(b) : buildRange(b);
  b.finalize(quality.shadows);
  const world = b.world;
  world.buildNav(1);
  const sky = partial.sky;
  const size = world.bounds.maxX - world.bounds.minX;
  const dome = skyDome(sky, 600);
  b.group.add(dome);
  b.disposables.push(dome.material);
  const spawns = walkableSpots(world, partial._spawnPts);
  const teamSpawns = [walkableSpots(world, partial._team[0]), walkableSpots(world, partial._team[1])];
  const [sx, sz] = partial._start;
  const st = world.nearestWalkable(sx, sz);
  const playerStart = new Vector3(st.x, world.ground(st.x, st.z), st.z);
  let rs = 99;
  const rand = () => {
    rs = rs * 16807 % 2147483647;
    return (rs - 1) / 2147483646;
  };
  const patrol = randomPatrol(world, 40, rand);
  const redLights = [];
  let dish = null;
  b.group.traverse((o) => {
    if (o.isMesh && o.material.emissiveIntensity === 2) redLights.push(o);
  });
  if (id === "dust") dish = b.group.children.find((c) => c.type === "Group") ?? null;
  const animate = (t) => {
    for (const r of redLights) {
      const m = r.material;
      m.emissiveIntensity = Math.sin(t * 4) > 0 ? 2 : 0.2;
    }
    if (dish) dish.rotation.y = t * 0.4;
  };
  return {
    id,
    world,
    group: b.group,
    spawns: spawns.length ? spawns : [playerStart],
    teamSpawns,
    lootSpots: b.lootSpots,
    crateSpots: b.crateSpots,
    patrol,
    targets: partial.targets ?? [],
    sky,
    minimap: makeMinimap(world),
    animate,
    playerStart,
    size,
    dispose: () => {
      b.disposables.forEach((d) => d.dispose());
      b.group.traverse((o) => {
        if (o.isMesh && !o.geometry.userData.keep) o.geometry.dispose();
      });
    }
  };
}
var MAT_DEF, Builder;
var init_maps = __esm({
  "src/game/maps.ts"() {
    "use strict";
    init_three_module();
    init_BufferGeometryUtils();
    init_world();
    init_textures();
    MAT_DEF = {
      concrete: { tex: "concrete", color: 12105908, scale: 4 },
      asphalt: { tex: "asphalt", color: 16777215, scale: 6 },
      brick: { tex: "brick", color: 16777215, scale: 3 },
      facade: { tex: "facade", color: 16777215, scale: 3.4 },
      facadeDesert: { tex: "facadeDesert", color: 16777215, scale: 3.4 },
      sand: { tex: "sand", color: 16777215, scale: 8 },
      metal: { tex: "metal", color: 11186358, metal: 0.5, rough: 0.5, scale: 3 },
      crate: { tex: "crate", color: 16777215, scale: 1.2 },
      sandbag: { tex: "sandbag", color: 16777215, scale: 1.6 },
      rock: { tex: "rock", color: 16777215, scale: 5 },
      tile: { tex: "tile", color: 16777215, scale: 2 },
      roof: { tex: "roof", color: 16777215, scale: 4 },
      contRed: { tex: "container", color: 10697258, scale: 3 },
      contBlue: { tex: "container", color: 3103370, scale: 3 },
      contGreen: { tex: "container", color: 4876858, scale: 3 },
      contYellow: { tex: "container", color: 12619824, scale: 3 },
      olive: { tex: "metal", color: 5923648, scale: 3 },
      line: { color: 14205008, emissive: 0.1 },
      glass: { color: 1714744, rough: 0.1, metal: 0.8 },
      dark: { color: 2500651, rough: 0.6, metal: 0.4 },
      redLight: { color: 16722458, emissive: 2 },
      wood: { tex: "crate", color: 10123861, scale: 2 },
      white: { color: 15263968 },
      target: { tex: "target", color: 16777215, scale: 1 },
      plaster: { tex: "concrete", color: 14206112, scale: 4 },
      carRed: { color: 9052192, metal: 0.6, rough: 0.35 },
      carBlue: { color: 2112106, metal: 0.6, rough: 0.35 },
      carGray: { color: 6975090, metal: 0.6, rough: 0.35 },
      leaf: { color: 4874288, rough: 0.9 }
    };
    Builder = class {
      constructor(quality, lowMat) {
        this.quality = quality;
        this.lowMat = lowMat;
      }
      quality;
      lowMat;
      world = new World();
      group = new Group();
      buckets = /* @__PURE__ */ new Map();
      mats = /* @__PURE__ */ new Map();
      lootSpots = [];
      crateSpots = [];
      seed = 1;
      disposables = [];
      rand() {
        this.seed = this.seed * 16807 % 2147483647;
        return (this.seed - 1) / 2147483646;
      }
      setSeed(s) {
        this.seed = s;
      }
      mat(k) {
        let m = this.mats.get(k);
        if (!m) {
          const d = MAT_DEF[k];
          const map = d.tex ? getTexture(d.tex, this.quality) : null;
          if (this.lowMat && !d.emissive) m = new MeshLambertMaterial({ color: d.color, map });
          else m = new MeshStandardMaterial({ color: d.color, map, roughness: d.rough ?? 0.85, metalness: d.metal ?? 0.05, emissive: d.emissive ? d.color : 0, emissiveIntensity: d.emissive ?? 0 });
          this.mats.set(k, m);
          this.disposables.push(m);
        }
        return m;
      }
      /** Box with bottom at y; world-space UVs so textures tile consistently */
      box(cx, y, cz, w, h, d, mat, collide = true, metal = false) {
        const g = new BoxGeometry(w, h, d);
        const sc = MAT_DEF[mat].scale ?? 4;
        const uv = g.attributes.uv;
        const dims = [[d, h], [d, h], [w, d], [w, d], [w, h], [w, h]];
        for (let f = 0; f < 6; f++) for (let v = 0; v < 4; v++) {
          const i = f * 4 + v;
          uv.setXY(i, uv.getX(i) * dims[f][0] / sc, uv.getY(i) * dims[f][1] / sc);
        }
        g.translate(cx, y + h / 2, cz);
        const key = `${mat}_${Math.floor(cx / 48)}_${Math.floor(cz / 48)}`;
        let arr = this.buckets.get(key);
        if (!arr) {
          arr = [];
          this.buckets.set(key, arr);
        }
        arr.push(g);
        if (collide) this.world.addBox(cx - w / 2, y, cz - d / 2, cx + w / 2, y + h, cz + d / 2, metal);
      }
      addMesh(m) {
        this.group.add(m);
      }
      finalize(shadows) {
        for (const [key, geos] of this.buckets) {
          const mk = key.split("_")[0];
          const merged = mergeGeometries(geos, false);
          geos.forEach((g) => g.dispose());
          if (!merged) continue;
          merged.computeBoundingSphere();
          const mesh = new Mesh(merged, this.mat(mk));
          mesh.castShadow = shadows && mk !== "line" && mk !== "asphalt";
          mesh.receiveShadow = shadows;
          mesh.matrixAutoUpdate = false;
          mesh.updateMatrix();
          this.group.add(mesh);
          this.disposables.push(merged);
        }
        this.buckets.clear();
      }
      // ---------- composite helpers ----------
      /** wall along X (axis 'x') or Z with rectangular openings [{at, w, y0, y1}] */
      wall(axis, a0, a1, fixed, y, h, t, mat, openings = []) {
        const segs = [];
        const ops = openings.slice().sort((p, q) => p.at - q.at);
        let cur = a0;
        for (const o of ops) {
          const s = o.at - o.w / 2, e = o.at + o.w / 2;
          if (s > cur) segs.push([cur, s, 0, h]);
          if (o.y0 > 0) segs.push([s, e, 0, o.y0]);
          if (o.y1 < h) segs.push([s, e, o.y1, h]);
          cur = e;
        }
        if (cur < a1) segs.push([cur, a1, 0, h]);
        for (const [s, e, yb, yt] of segs) {
          if (e - s < 0.01 || yt - yb < 0.01) continue;
          const mid = (s + e) / 2;
          if (axis === "x") this.box(mid, y + yb, fixed, e - s, yt - yb, t, mat);
          else this.box(fixed, y + yb, mid, t, yt - yb, e - s, mat);
        }
      }
      slab(x0, x1, z0, z1, y, th, mat, hole) {
        const add = (a, b, c, d) => {
          if (b - a > 0.05 && d - c > 0.05) this.box((a + b) / 2, y - th, (c + d) / 2, b - a, th, d - c, mat);
        };
        if (!hole) {
          add(x0, x1, z0, z1);
          return;
        }
        const [hx0, hx1, hz0, hz1] = hole;
        add(x0, hx0, z0, z1);
        add(hx1, x1, z0, z1);
        add(hx0, hx1, z0, hz0);
        add(hx0, hx1, hz1, z1);
      }
      stairs(x, z, y, rise, width, dirZ, mat, run = 0.5) {
        const n = Math.ceil(rise / 0.34 - 1e-6), r = rise / n;
        for (let i = 0; i < n; i++) this.box(x, y, z + dirZ * (i * run + run / 2), width, (i + 1) * r, run, mat);
        return n * run;
      }
      /** Enterable multi-floor building with doors, windows, internal stairs and optional roof access */
      building(cx, cz, w, d, floors, base, wallMat, doors, roofAccess = true, floorMat = "tile") {
        const T = 0.3, FH = 3.4;
        const x0 = cx - w / 2, x1 = cx + w / 2, z0 = cz - d / 2, z1 = cz + d / 2;
        const ix0 = x0 + T, ix1 = x1 - T, iz0 = z0 + T, iz1 = z1 - T;
        const flights = floors - 1 + (roofAccess ? 1 : 0);
        const SW = 1.4, RUN = 0.45, stairLen = Math.ceil(FH / 0.34 - 1e-6) * RUN;
        this.box(cx, base - 0.05, cz, w, 0.1, d, floorMat, false);
        for (let f = 0; f < floors; f++) {
          const y = base + f * FH;
          const doorW = 1.8;
          const opsFor = (side, len, mid) => {
            const sideDoor = side === "e" || side === "w";
            if (f === 0) return doors.includes(side) ? [{ at: sideDoor ? mid + len / 2 - T - 1.25 : mid, w: doorW, y0: 0, y1: 2.5 }] : [{ at: mid + (sideDoor ? len * 0.3 : -len * 0.28), w: 1.4, y0: 1.1, y1: 2.2 }];
            return [{ at: mid - len * 0.25, w: 1.5, y0: 1, y1: 2.3 }, { at: mid + len * 0.25, w: 1.5, y0: 1, y1: 2.3 }];
          };
          this.wall("x", x0, x1, z0 + T / 2, y, FH, T, wallMat, opsFor("n", w, cx));
          this.wall("x", x0, x1, z1 - T / 2, y, FH, T, wallMat, opsFor("s", w, cx));
          this.wall("z", z0 + T, z1 - T, x0 + T / 2, y, FH, T, wallMat, opsFor("w", d, cz));
          this.wall("z", z0 + T, z1 - T, x1 - T / 2, y, FH, T, wallMat, opsFor("e", d, cz));
          this.lootSpots.push(new Vector3(cx + (this.rand() - 0.5) * w * 0.4, y + 0.05, cz + (this.rand() - 0.5) * d * 0.3));
          if (w > 9 && this.rand() > 0.3) this.box(cx + (this.rand() - 0.5) * 2, y, cz + (this.rand() > 0.5 ? 1 : -1) * d * 0.15, 1.6, 1, 0.8, "wood");
        }
        for (let f = 1; f <= floors; f++) {
          const y = base + f * FH;
          const hasFlight = f - 1 < flights;
          const west = f % 2 === 1;
          const sx = west ? ix0 + SW / 2 : ix1 - SW / 2;
          const sz0 = iz0 + 0.6;
          let hole;
          if (hasFlight) {
            this.stairs(sx, sz0, y - FH, FH, SW, 1, "concrete", RUN);
            hole = [sx - SW / 2, sx + SW / 2, sz0 - 0.1, sz0 + stairLen + 0.1];
          }
          this.slab(f === floors ? x0 : ix0, f === floors ? x1 : ix1, f === floors ? z0 : iz0, f === floors ? z1 : iz1, y, 0.25, f === floors ? "roof" : floorMat, f < floors || roofAccess ? hole : void 0);
          if (f < floors && hasFlight) {
            this.box(west ? sx + SW / 2 + 0.05 : sx - SW / 2 - 0.05, y, sz0 + stairLen / 2, 0.08, 1, stairLen, "dark");
          }
        }
        const top = base + floors * FH;
        if (roofAccess) {
          this.wall("x", x0, x1, z0 + 0.1, top, 1, 0.2, wallMat);
          this.wall("x", x0, x1, z1 - 0.1, top, 1, 0.2, wallMat);
          this.wall("z", z0 + 0.2, z1 - 0.2, x0 + 0.1, top, 1, 0.2, wallMat);
          this.wall("z", z0 + 0.2, z1 - 0.2, x1 - 0.1, top, 1, 0.2, wallMat);
          const west = floors % 2 === 1;
          const sx = west ? ix0 + SW / 2 : ix1 - SW / 2;
          this.box(sx + (west ? SW / 2 + 0.05 : -SW / 2 - 0.05), top, iz0 + 0.6 + stairLen / 2, 0.08, 1, stairLen, "dark");
          if (this.rand() > 0.4) this.box(cx + w * 0.2, top, cz + d * 0.2, 1.6, 1.2, 1.2, "metal", true, true);
          this.lootSpots.push(new Vector3(cx, top + 0.05, cz + d * 0.25));
        }
      }
      tower(cx, cz, w, d, h, base, mat) {
        this.box(cx, base, cz, w, h, d, mat);
        this.box(cx, base + h, cz, w + 0.3, 0.6, d + 0.3, "concrete", false);
        if (this.rand() > 0.4) this.box(cx + (this.rand() - 0.5) * w * 0.5, base + h + 0.6, cz + (this.rand() - 0.5) * d * 0.5, 2, 1.4, 2, "metal", false);
      }
      car(cx, cz, alongX, base = 0) {
        const mats = ["carRed", "carBlue", "carGray"];
        const m = mats[Math.floor(this.rand() * 3)];
        const L = 4.2, W = 1.9;
        const [w, d] = alongX ? [L, W] : [W, L];
        this.box(cx, base + 0.3, cz, w, 0.75, d, m, true, true);
        this.box(cx, base + 1.05, cz, alongX ? L * 0.55 : W * 0.9, 0.6, alongX ? W * 0.9 : L * 0.55, "glass", true, true);
        this.box(cx, base, cz, w * 0.9, 0.3, d * 0.9, "dark", false);
      }
      container(cx, cz, alongX, base = 0, stack = 1) {
        const mats = ["contRed", "contBlue", "contGreen", "contYellow"];
        for (let s = 0; s < stack; s++) {
          const [w, d] = alongX ? [6, 2.5] : [2.5, 6];
          this.box(cx, base + s * 2.6, cz, w, 2.6, d, mats[Math.floor(this.rand() * 4)], true, true);
        }
      }
      sandbags(cx, cz, len, alongX, base = 0) {
        this.box(cx, base, cz, alongX ? len : 0.9, 1.05, alongX ? 0.9 : len, "sandbag");
      }
      tree(cx, cz, base = 0) {
        this.box(cx, base, cz, 0.35, 3, 0.35, "wood");
        const g = new IcosahedronGeometry(1.6 + this.rand(), 0);
        g.translate(cx, base + 3.8, cz);
        const key = `leaf_${Math.floor(cx / 48)}_${Math.floor(cz / 48)}`;
        let arr = this.buckets.get(key);
        if (!arr) {
          arr = [];
          this.buckets.set(key, arr);
        }
        arr.push(g);
      }
    };
  }
});

// src/game/data/weapons.ts
var weapons_exports = {};
__export(weapons_exports, {
  ATTACHMENTS: () => ATTACHMENTS,
  ATTACH_MAP: () => ATTACH_MAP,
  CATEGORY_NAMES: () => CATEGORY_NAMES,
  RARITY_COLORS: () => RARITY_COLORS,
  RARITY_HEX: () => RARITY_HEX,
  RARITY_NAMES: () => RARITY_NAMES,
  SKINS: () => SKINS,
  SLOTS: () => SLOTS,
  SLOT_NAMES: () => SLOT_NAMES,
  WEAPONS: () => WEAPONS,
  WEAPON_MAP: () => WEAPON_MAP,
  attachmentsFor: () => attachmentsFor,
  computeStats: () => computeStats,
  getSkin: () => getSkin,
  getWeapon: () => getWeapon,
  randomLootAttachments: () => randomLootAttachments,
  sanitizeAttachments: () => sanitizeAttachments,
  statBars: () => statBars
});
function sanitizeAttachments(def, cfg) {
  const out = {};
  if (!cfg) return out;
  for (const slot of SLOTS) {
    const id = cfg[slot];
    if (!id) continue;
    const a = ATTACH_MAP[id];
    if (a && a.slot === slot && (!a.cats || a.cats.includes(def.category))) out[slot] = id;
  }
  return out;
}
function computeStats(def, cfg, rarityBonus = 0) {
  const s = {
    damage: def.damage * (1 + rarityBonus),
    headMult: def.headMult,
    rpm: def.rpm,
    mag: def.mag,
    reserve: def.reserve,
    reload: def.reload,
    recoilV: def.recoilV,
    recoilH: def.recoilH,
    spreadHip: def.spreadHip,
    spreadAds: def.spreadAds,
    range: def.range,
    minDmg: def.minDmg,
    zoom: def.adsZoom,
    adsTime: def.adsTime,
    move: def.move,
    pellets: def.pellets,
    mode: def.mode,
    suppressed: !!def.suppressed
  };
  const clean = sanitizeAttachments(def, cfg);
  for (const id of Object.values(clean)) {
    const a = id ? ATTACH_MAP[id] : void 0;
    if (!a) continue;
    const m = a.mods;
    if (m.damage) s.damage *= m.damage;
    if (m.range) s.range *= m.range;
    if (m.recoil) s.recoilV *= m.recoil;
    if (m.recoilH) s.recoilH *= m.recoilH;
    if (m.spread) {
      s.spreadAds *= m.spread;
    }
    if (m.hipSpread) s.spreadHip *= m.hipSpread;
    if (m.adsTime) s.adsTime *= m.adsTime;
    if (m.reload) s.reload *= m.reload;
    if (m.mag) s.mag = Math.round(s.mag * m.mag);
    if (m.move) s.move *= m.move;
    if (m.zoom) s.zoom = Math.max(def.category === "SR" ? def.adsZoom : 0, m.zoom);
    if (m.suppressed) s.suppressed = true;
  }
  s.reserve = Math.max(s.reserve, s.mag * 3);
  return s;
}
function statBars(s) {
  const dps = s.damage * s.pellets * (s.rpm / 60);
  return {
    Damage: Math.min(100, s.damage * s.pellets / 1.5),
    "Fire Rate": Math.min(100, s.rpm / 11),
    Range: Math.min(100, s.range / 1.6),
    Accuracy: Math.max(5, Math.min(100, 100 - s.spreadHip * 9)),
    Control: Math.max(5, Math.min(100, 100 - (s.recoilV * 12 + s.recoilH * 25))),
    Mobility: Math.max(5, Math.min(100, (s.move - 0.75) * 260 + (0.5 - s.adsTime) * 60)),
    DPS: Math.min(100, dps / 6)
  };
}
function randomLootAttachments(def, rarity) {
  const cfg = {};
  const slots = [...SLOTS].sort(() => Math.random() - 0.5).slice(0, rarity + (rarity >= 3 ? 1 : 0));
  for (const slot of slots) {
    const opts = attachmentsFor(def, slot);
    if (opts.length) cfg[slot] = opts[Math.floor(Math.random() * opts.length)].id;
  }
  return sanitizeAttachments(def, cfg);
}
var CATEGORY_NAMES, S, WEAPONS, WEAPON_MAP, getWeapon, SLOT_NAMES, SLOTS, ALL_BUT_PISTOL, ATTACHMENTS, ATTACH_MAP, attachmentsFor, SKINS, getSkin, RARITY_NAMES, RARITY_COLORS, RARITY_HEX;
var init_weapons = __esm({
  "src/game/data/weapons.ts"() {
    "use strict";
    CATEGORY_NAMES = {
      AR: "Assault Rifle",
      SMG: "Submachine Gun",
      SR: "Sniper Rifle",
      SG: "Shotgun",
      LMG: "Light Machine Gun",
      MR: "Marksman Rifle",
      PISTOL: "Pistol"
    };
    S = (pitch, body, crack, tail) => ({ pitch, body, crack, tail });
    WEAPONS = [
      // ---------- ASSAULT RIFLES ----------
      {
        id: "ar01",
        name: "AR-01 Vanguard",
        category: "AR",
        desc: "Reliable all-rounder with a controllable kick.",
        damage: 26,
        headMult: 1.5,
        rpm: 720,
        mag: 30,
        reserve: 150,
        reload: 2.1,
        recoilV: 0.85,
        recoilH: 0.35,
        spreadHip: 3.2,
        spreadAds: 0.35,
        range: 45,
        minDmg: 0.7,
        adsZoom: 1.3,
        adsTime: 0.24,
        move: 0.95,
        pellets: 1,
        mode: "auto",
        unlock: 1,
        sound: S(1, 1, 0.8, 0.6),
        model: { body: 0.42, barrel: 0.3, stock: "full", mag: "curved", scope: "none", thick: 1, color: 2830131, accent: 5925706 }
      },
      {
        id: "ar02",
        name: "AR-02 Sentinel",
        category: "AR",
        desc: "Heavy-hitting battle rifle, rewards precise bursts.",
        damage: 31,
        headMult: 1.5,
        rpm: 600,
        mag: 25,
        reserve: 125,
        reload: 2.4,
        recoilV: 1.1,
        recoilH: 0.3,
        spreadHip: 3.6,
        spreadAds: 0.3,
        range: 55,
        minDmg: 0.72,
        adsZoom: 1.35,
        adsTime: 0.27,
        move: 0.92,
        pellets: 1,
        mode: "auto",
        unlock: 1,
        sound: S(0.85, 1.2, 0.9, 0.7),
        model: { body: 0.46, barrel: 0.34, stock: "heavy", mag: "straight", scope: "none", thick: 1.1, color: 3813926, accent: 9071162 }
      },
      {
        id: "ar03",
        name: "AR-03 Tempest",
        category: "AR",
        desc: "Three-round burst rifle. Deadly in skilled hands.",
        damage: 33,
        headMult: 1.6,
        rpm: 950,
        mag: 30,
        reserve: 150,
        reload: 2.2,
        recoilV: 0.7,
        recoilH: 0.25,
        spreadHip: 3,
        spreadAds: 0.25,
        range: 50,
        minDmg: 0.75,
        adsZoom: 1.35,
        adsTime: 0.25,
        move: 0.94,
        pellets: 1,
        mode: "burst",
        unlock: 4,
        sound: S(1.15, 0.9, 1, 0.5),
        model: { body: 0.4, barrel: 0.32, stock: "bullpup", mag: "curved", scope: "dot", thick: 1, color: 2237996, accent: 3829413 }
      },
      {
        id: "ar04",
        name: "AR-04 Havoc",
        category: "AR",
        desc: "Slow cyclic rate, brutal damage, wild recoil.",
        damage: 36,
        headMult: 1.45,
        rpm: 540,
        mag: 25,
        reserve: 125,
        reload: 2.5,
        recoilV: 1.35,
        recoilH: 0.55,
        spreadHip: 3.8,
        spreadAds: 0.4,
        range: 48,
        minDmg: 0.7,
        adsZoom: 1.3,
        adsTime: 0.28,
        move: 0.9,
        pellets: 1,
        mode: "auto",
        unlock: 7,
        sound: S(0.75, 1.35, 0.8, 0.8),
        model: { body: 0.44, barrel: 0.28, stock: "full", mag: "curved", scope: "none", thick: 1.2, color: 4864810, accent: 10107434 }
      },
      {
        id: "ar05",
        name: "AR-05 Phantom",
        category: "AR",
        desc: "Integrally suppressed. Stays off enemy radar.",
        damage: 24,
        headMult: 1.6,
        rpm: 820,
        mag: 32,
        reserve: 160,
        reload: 2,
        recoilV: 0.7,
        recoilH: 0.3,
        spreadHip: 3,
        spreadAds: 0.35,
        range: 38,
        minDmg: 0.68,
        adsZoom: 1.3,
        adsTime: 0.23,
        move: 0.96,
        pellets: 1,
        mode: "auto",
        suppressed: true,
        unlock: 12,
        sound: S(1.3, 0.5, 0.3, 0.2),
        model: { body: 0.4, barrel: 0.38, stock: "skeleton", mag: "straight", scope: "dot", thick: 1.05, color: 1382170, accent: 6957706 }
      },
      // ---------- SMGs ----------
      {
        id: "smg01",
        name: "SMG-01 Viper",
        category: "SMG",
        desc: "Snappy close-quarters bullet hose.",
        damage: 21,
        headMult: 1.4,
        rpm: 900,
        mag: 32,
        reserve: 192,
        reload: 1.8,
        recoilV: 0.55,
        recoilH: 0.4,
        spreadHip: 2.4,
        spreadAds: 0.6,
        range: 18,
        minDmg: 0.6,
        adsZoom: 1.2,
        adsTime: 0.18,
        move: 1.05,
        pellets: 1,
        mode: "auto",
        unlock: 1,
        sound: S(1.35, 0.7, 0.7, 0.35),
        model: { body: 0.3, barrel: 0.14, stock: "skeleton", mag: "straight", scope: "none", thick: 0.9, color: 2500910, accent: 4165455 }
      },
      {
        id: "smg02",
        name: "SMG-02 Specter",
        category: "SMG",
        desc: "Blistering fire rate with a deep magazine.",
        damage: 18,
        headMult: 1.4,
        rpm: 1080,
        mag: 40,
        reserve: 200,
        reload: 2,
        recoilV: 0.5,
        recoilH: 0.5,
        spreadHip: 2.6,
        spreadAds: 0.7,
        range: 15,
        minDmg: 0.55,
        adsZoom: 1.2,
        adsTime: 0.17,
        move: 1.07,
        pellets: 1,
        mode: "auto",
        unlock: 3,
        sound: S(1.5, 0.6, 0.6, 0.3),
        model: { body: 0.28, barrel: 0.12, stock: "none", mag: "straight", scope: "none", thick: 0.85, color: 1842722, accent: 11581118 }
      },
      {
        id: "smg03",
        name: "SMG-03 Pulse",
        category: "SMG",
        desc: "Hard-hitting SMG that reaches mid range.",
        damage: 26,
        headMult: 1.4,
        rpm: 700,
        mag: 30,
        reserve: 180,
        reload: 1.9,
        recoilV: 0.6,
        recoilH: 0.3,
        spreadHip: 2.6,
        spreadAds: 0.5,
        range: 24,
        minDmg: 0.62,
        adsZoom: 1.25,
        adsTime: 0.2,
        move: 1.03,
        pellets: 1,
        mode: "auto",
        unlock: 6,
        sound: S(1.2, 0.85, 0.7, 0.4),
        model: { body: 0.32, barrel: 0.18, stock: "full", mag: "curved", scope: "dot", thick: 0.95, color: 2962752, accent: 13666858 }
      },
      {
        id: "smg04",
        name: "SMG-04 Raptor",
        category: "SMG",
        desc: "Top-loaded 50 round drum, laser-like spray.",
        damage: 20,
        headMult: 1.35,
        rpm: 860,
        mag: 50,
        reserve: 200,
        reload: 2.6,
        recoilV: 0.42,
        recoilH: 0.25,
        spreadHip: 2.4,
        spreadAds: 0.55,
        range: 17,
        minDmg: 0.6,
        adsZoom: 1.2,
        adsTime: 0.21,
        move: 1.02,
        pellets: 1,
        mode: "auto",
        unlock: 10,
        sound: S(1.4, 0.65, 0.65, 0.3),
        model: { body: 0.36, barrel: 0.1, stock: "bullpup", mag: "top", scope: "dot", thick: 1.1, color: 3817270, accent: 10534976 }
      },
      // ---------- SNIPERS ----------
      {
        id: "sr01",
        name: "SR-01 Longshot",
        category: "SR",
        desc: "Bolt-action. One-shot headshots at any range.",
        damage: 110,
        headMult: 2.2,
        rpm: 48,
        mag: 5,
        reserve: 30,
        reload: 3,
        recoilV: 4.5,
        recoilH: 0.6,
        spreadHip: 7,
        spreadAds: 0.02,
        range: 200,
        minDmg: 0.85,
        adsZoom: 4,
        adsTime: 0.42,
        move: 0.85,
        pellets: 1,
        mode: "bolt",
        unlock: 2,
        sound: S(0.6, 1.6, 1.4, 1.2),
        model: { body: 0.5, barrel: 0.5, stock: "heavy", mag: "box", scope: "big", thick: 1, color: 3029546, accent: 6978122 }
      },
      {
        id: "sr02",
        name: "SR-02 Frost",
        category: "SR",
        desc: "Lightweight bolt rifle with quick scope-in.",
        damage: 95,
        headMult: 2.2,
        rpm: 60,
        mag: 6,
        reserve: 36,
        reload: 2.6,
        recoilV: 3.8,
        recoilH: 0.5,
        spreadHip: 6,
        spreadAds: 0.03,
        range: 160,
        minDmg: 0.85,
        adsZoom: 3.5,
        adsTime: 0.33,
        move: 0.9,
        pellets: 1,
        mode: "bolt",
        unlock: 8,
        sound: S(0.7, 1.4, 1.3, 1),
        model: { body: 0.46, barrel: 0.46, stock: "skeleton", mag: "box", scope: "big", thick: 0.9, color: 13161178, accent: 5939408 }
      },
      {
        id: "sr03",
        name: "SR-03 Eclipse",
        category: "SR",
        desc: "Anti-materiel monster. Body shots are lethal.",
        damage: 150,
        headMult: 2,
        rpm: 38,
        mag: 4,
        reserve: 20,
        reload: 3.6,
        recoilV: 6,
        recoilH: 0.9,
        spreadHip: 8,
        spreadAds: 0.02,
        range: 240,
        minDmg: 0.9,
        adsZoom: 4.5,
        adsTime: 0.5,
        move: 0.8,
        pellets: 1,
        mode: "bolt",
        unlock: 15,
        sound: S(0.45, 2, 1.6, 1.5),
        model: { body: 0.56, barrel: 0.6, stock: "heavy", mag: "box", scope: "big", thick: 1.25, color: 1513499, accent: 13672496 }
      },
      // ---------- SHOTGUNS ----------
      {
        id: "sg01",
        name: "SG-01 Breacher",
        category: "SG",
        desc: "Pump-action door kicker. Devastating up close.",
        damage: 16,
        headMult: 1.25,
        rpm: 70,
        mag: 6,
        reserve: 36,
        reload: 3.2,
        recoilV: 3.5,
        recoilH: 0.8,
        spreadHip: 6.5,
        spreadAds: 4.8,
        range: 9,
        minDmg: 0.25,
        adsZoom: 1.15,
        adsTime: 0.22,
        move: 1,
        pellets: 9,
        mode: "bolt",
        unlock: 1,
        sound: S(0.55, 1.8, 1, 1),
        model: { body: 0.38, barrel: 0.4, stock: "full", mag: "tube", scope: "none", thick: 1.1, color: 3811870, accent: 8017200 }
      },
      {
        id: "sg02",
        name: "SG-02 Thunder",
        category: "SG",
        desc: "Semi-auto combat shotgun. Rapid follow-ups.",
        damage: 12,
        headMult: 1.25,
        rpm: 220,
        mag: 8,
        reserve: 40,
        reload: 3.4,
        recoilV: 2.6,
        recoilH: 0.9,
        spreadHip: 7,
        spreadAds: 5.2,
        range: 8,
        minDmg: 0.25,
        adsZoom: 1.15,
        adsTime: 0.24,
        move: 0.98,
        pellets: 8,
        mode: "semi",
        unlock: 9,
        sound: S(0.65, 1.6, 0.9, 0.8),
        model: { body: 0.4, barrel: 0.34, stock: "heavy", mag: "box", scope: "dot", thick: 1.2, color: 2369323, accent: 11546672 }
      },
      // ---------- LMGs ----------
      {
        id: "lmg01",
        name: "LMG-01 Titan",
        category: "LMG",
        desc: "100-round belt. Suppress entire sectors.",
        damage: 30,
        headMult: 1.4,
        rpm: 650,
        mag: 100,
        reserve: 200,
        reload: 5.2,
        recoilV: 0.8,
        recoilH: 0.5,
        spreadHip: 4.5,
        spreadAds: 0.45,
        range: 55,
        minDmg: 0.72,
        adsZoom: 1.3,
        adsTime: 0.4,
        move: 0.82,
        pellets: 1,
        mode: "auto",
        unlock: 5,
        sound: S(0.8, 1.3, 0.8, 0.8),
        model: { body: 0.52, barrel: 0.38, stock: "heavy", mag: "drum", scope: "none", thick: 1.3, color: 3093288, accent: 6975552 }
      },
      {
        id: "lmg02",
        name: "LMG-02 Suppressor",
        category: "LMG",
        desc: "Suppressed support weapon, low profile.",
        damage: 27,
        headMult: 1.4,
        rpm: 760,
        mag: 75,
        reserve: 225,
        reload: 4.6,
        recoilV: 0.7,
        recoilH: 0.45,
        spreadHip: 4.2,
        spreadAds: 0.45,
        range: 45,
        minDmg: 0.7,
        adsZoom: 1.3,
        adsTime: 0.36,
        move: 0.85,
        pellets: 1,
        mode: "auto",
        suppressed: true,
        unlock: 13,
        sound: S(1.1, 0.6, 0.35, 0.25),
        model: { body: 0.5, barrel: 0.42, stock: "full", mag: "box", scope: "dot", thick: 1.25, color: 2040100, accent: 4223098 }
      },
      // ---------- MARKSMAN ----------
      {
        id: "mr01",
        name: "MR-01 Falcon",
        category: "MR",
        desc: "Semi-auto DMR. Fast follow-up precision.",
        damage: 52,
        headMult: 1.8,
        rpm: 300,
        mag: 15,
        reserve: 75,
        reload: 2.4,
        recoilV: 1.8,
        recoilH: 0.35,
        spreadHip: 4.5,
        spreadAds: 0.1,
        range: 90,
        minDmg: 0.8,
        adsZoom: 2.2,
        adsTime: 0.3,
        move: 0.92,
        pellets: 1,
        mode: "semi",
        unlock: 3,
        sound: S(0.9, 1.2, 1.2, 0.8),
        model: { body: 0.46, barrel: 0.42, stock: "full", mag: "straight", scope: "dot", thick: 1, color: 3883056, accent: 10133616 }
      },
      {
        id: "mr02",
        name: "MR-02 Ranger",
        category: "MR",
        desc: "Lever-fed marksman rifle with heavy rounds.",
        damage: 70,
        headMult: 1.9,
        rpm: 200,
        mag: 10,
        reserve: 50,
        reload: 2.8,
        recoilV: 2.6,
        recoilH: 0.4,
        spreadHip: 5,
        spreadAds: 0.08,
        range: 110,
        minDmg: 0.8,
        adsZoom: 2.5,
        adsTime: 0.32,
        move: 0.9,
        pellets: 1,
        mode: "semi",
        unlock: 11,
        sound: S(0.75, 1.4, 1.3, 1),
        model: { body: 0.48, barrel: 0.46, stock: "heavy", mag: "box", scope: "big", thick: 1, color: 4863008, accent: 2763306 }
      },
      // ---------- PISTOLS ----------
      {
        id: "p01",
        name: "P-01 Sidekick",
        category: "PISTOL",
        desc: "Dependable sidearm with fast handling.",
        damage: 28,
        headMult: 1.5,
        rpm: 450,
        mag: 15,
        reserve: 90,
        reload: 1.4,
        recoilV: 1,
        recoilH: 0.3,
        spreadHip: 1.8,
        spreadAds: 0.4,
        range: 18,
        minDmg: 0.6,
        adsZoom: 1.15,
        adsTime: 0.14,
        move: 1.1,
        pellets: 1,
        mode: "semi",
        unlock: 1,
        sound: S(1.25, 0.8, 0.9, 0.4),
        model: { body: 0.18, barrel: 0.04, stock: "none", mag: "pistol", scope: "none", thick: 0.8, color: 2434858, accent: 7830400 }
      },
      {
        id: "p02",
        name: "P-02 Ironclad",
        category: "PISTOL",
        desc: "Magnum revolver-class hand cannon.",
        damage: 58,
        headMult: 1.6,
        rpm: 190,
        mag: 7,
        reserve: 42,
        reload: 2,
        recoilV: 2.8,
        recoilH: 0.5,
        spreadHip: 2.2,
        spreadAds: 0.3,
        range: 26,
        minDmg: 0.65,
        adsZoom: 1.2,
        adsTime: 0.17,
        move: 1.08,
        pellets: 1,
        mode: "semi",
        unlock: 4,
        sound: S(0.8, 1.4, 1.1, 0.8),
        model: { body: 0.22, barrel: 0.1, stock: "none", mag: "pistol", scope: "none", thick: 0.95, color: 9080726, accent: 3811866 }
      }
    ];
    WEAPON_MAP = Object.fromEntries(WEAPONS.map((w) => [w.id, w]));
    getWeapon = (id) => WEAPON_MAP[id] ?? WEAPONS[0];
    SLOT_NAMES = { optic: "Optic", muzzle: "Muzzle", barrel: "Barrel", grip: "Underbarrel", mag: "Magazine", stock: "Stock" };
    SLOTS = ["optic", "muzzle", "barrel", "grip", "mag", "stock"];
    ALL_BUT_PISTOL = ["AR", "SMG", "SR", "SG", "LMG", "MR"];
    ATTACHMENTS = [
      { id: "opt_dot", name: "Pinpoint Reflex", slot: "optic", desc: "Clean red dot, slight zoom.", mods: { zoom: 1.35, adsTime: 1.03 }, unlock: 1 },
      { id: "opt_holo", name: "Halo Holographic", slot: "optic", desc: "Wide ring reticle.", mods: { zoom: 1.45, adsTime: 1.06, spread: 0.95 }, unlock: 3, cats: ALL_BUT_PISTOL },
      { id: "opt_acog", name: "Ridgeline 3x", slot: "optic", desc: "Mid-range magnified optic.", mods: { zoom: 2.4, adsTime: 1.15, spread: 0.9 }, unlock: 6, cats: ["AR", "LMG", "MR", "SR"] },
      { id: "opt_8x", name: "Overwatch 6x", slot: "optic", desc: "High-power scope.", mods: { zoom: 5, adsTime: 1.2 }, unlock: 9, cats: ["SR", "MR"] },
      { id: "muz_supp", name: "Whisper Suppressor", slot: "muzzle", desc: "Hides you from radar, less range.", mods: { suppressed: true, range: 0.9, recoil: 0.95 }, unlock: 2 },
      { id: "muz_comp", name: "Ironfist Compensator", slot: "muzzle", desc: "Kills vertical kick.", mods: { recoil: 0.8, recoilH: 1.1 }, unlock: 1 },
      { id: "muz_flash", name: "Starburst Flash Hider", slot: "muzzle", desc: "Tames horizontal bounce.", mods: { recoilH: 0.78 }, unlock: 4 },
      { id: "bar_long", name: "Longreach Barrel", slot: "barrel", desc: "More range and velocity.", mods: { range: 1.3, adsTime: 1.08, move: 0.97, damage: 1.03 }, unlock: 2, cats: ALL_BUT_PISTOL },
      { id: "bar_short", name: "Stub CQB Barrel", slot: "barrel", desc: "Faster handling, less range.", mods: { range: 0.8, adsTime: 0.9, move: 1.03, hipSpread: 0.85 }, unlock: 3 },
      { id: "grip_vert", name: "Anchor Vertical Grip", slot: "grip", desc: "Lowers vertical recoil.", mods: { recoil: 0.85, adsTime: 1.03 }, unlock: 1, cats: ALL_BUT_PISTOL },
      { id: "grip_angle", name: "Wedge Angled Grip", slot: "grip", desc: "Faster ADS, tighter spray.", mods: { adsTime: 0.9, recoilH: 0.85 }, unlock: 5, cats: ALL_BUT_PISTOL },
      { id: "grip_laser", name: "Beacon Laser", slot: "grip", desc: "Tightens hip-fire spread.", mods: { hipSpread: 0.7 }, unlock: 4 },
      { id: "mag_ext", name: "Extended Mag", slot: "mag", desc: "+50% capacity, slower reload.", mods: { mag: 1.5, reload: 1.15, adsTime: 1.05 }, unlock: 2 },
      { id: "mag_fast", name: "Quickdraw Mag", slot: "mag", desc: "Much faster reloads.", mods: { reload: 0.72 }, unlock: 5 },
      { id: "stk_light", name: "Featherweight Stock", slot: "stock", desc: "Move and aim faster.", mods: { move: 1.05, adsTime: 0.88, recoil: 1.08 }, unlock: 3, cats: ALL_BUT_PISTOL },
      { id: "stk_heavy", name: "Bulwark Stock", slot: "stock", desc: "Rock-steady recoil control.", mods: { recoil: 0.85, recoilH: 0.85, move: 0.96, adsTime: 1.06 }, unlock: 7, cats: ALL_BUT_PISTOL }
    ];
    ATTACH_MAP = Object.fromEntries(ATTACHMENTS.map((a) => [a.id, a]));
    attachmentsFor = (def, slot) => ATTACHMENTS.filter((a) => a.slot === slot && (!a.cats || a.cats.includes(def.category)));
    SKINS = [
      { id: "default", name: "Factory", color: null, unlock: 1 },
      { id: "desert", name: "Dune Camo", color: 11901802, unlock: 2 },
      { id: "urban", name: "Urban Slate", color: 7107712, unlock: 3 },
      { id: "arctic", name: "Arctic White", color: 15002094, unlock: 5 },
      { id: "forest", name: "Woodland", color: 4939322, unlock: 6 },
      { id: "crimson", name: "Crimson Ops", color: 9051164, unlock: 8 },
      { id: "cobalt", name: "Cobalt", color: 2380712, unlock: 10 },
      { id: "gold", name: "Gilded", color: 13936170, unlock: 15, metal: 0.9 },
      { id: "shadow", name: "Shadow Elite", color: 1184276, unlock: 20, metal: 0.6 }
    ];
    getSkin = (id) => SKINS.find((s) => s.id === id) ?? SKINS[0];
    RARITY_NAMES = ["Common", "Uncommon", "Rare", "Epic", "Legendary"];
    RARITY_COLORS = ["#c8ccd0", "#4ade80", "#38bdf8", "#c084fc", "#fbbf24"];
    RARITY_HEX = [13159632, 4906624, 3718648, 12616956, 16498468];
  }
});

// src/game/models.ts
function stdMat(color, rough = 0.7, metal = 0.2, emissive = 0) {
  const k = `s${color}_${rough}_${metal}_${emissive}`;
  let m = matCache.get(k);
  if (!m) {
    m = new MeshStandardMaterial({ color, roughness: rough, metalness: metal, emissive: emissive ? color : 0, emissiveIntensity: emissive });
    matCache.set(k, m);
  }
  return m;
}
function boxGeo(w, h, d) {
  const k = `b${w.toFixed(3)}_${h.toFixed(3)}_${d.toFixed(3)}`;
  let g = geoCache.get(k);
  if (!g) {
    g = new BoxGeometry(w, h, d);
    geoCache.set(k, g);
  }
  return g;
}
function box(parent, w, h, d, x, y, z, mat, rx = 0) {
  const m = new Mesh(boxGeo(w, h, d), mat);
  m.position.set(x, y, z);
  m.rotation.x = rx;
  parent.add(m);
  return m;
}
function buildSoldier(c, detailed = false) {
  const uni = stdMat(c.uniform, 0.9, 0), vest = stdMat(c.vest, 0.8, 0.05), skin = stdMat(c.skin, 0.7, 0), helm = stdMat(c.helmet, 0.6, 0.2);
  const acc = stdMat(c.accent, 0.5, 0.2, detailed ? 0.25 : 0.6), dark = stdMat(1579291, 0.6, 0.4), boot = stdMat(1972758, 0.9, 0);
  const root = new Group();
  const body = new Group();
  root.add(body);
  const mkLeg = (x) => {
    const p = new Group();
    p.position.set(x, 0.92, 0);
    box(p, 0.19, 0.48, 0.22, 0, -0.24, 0, uni);
    box(p, 0.18, 0.46, 0.2, 0, -0.68, 0, uni);
    box(p, 0.2, 0.12, 0.3, 0, -0.86, -0.04, boot);
    if (detailed) box(p, 0.2, 0.12, 0.08, 0, -0.5, -0.1, dark);
    body.add(p);
    return p;
  };
  const legL = mkLeg(-0.12), legR = mkLeg(0.12);
  const chest = new Group();
  chest.position.y = 0.92;
  body.add(chest);
  box(chest, 0.48, 0.6, 0.26, 0, 0.3, 0, uni);
  box(chest, 0.52, 0.42, 0.32, 0, 0.36, 0, vest);
  box(chest, 0.44, 0.06, 0.02, 0, 0.5, -0.165, acc);
  if (detailed) {
    for (let i = -1; i <= 1; i++) box(chest, 0.1, 0.13, 0.06, i * 0.14, 0.24, -0.18, dark);
    box(chest, 0.38, 0.42, 0.18, 0, 0.36, 0.24, vest);
    box(chest, 0.02, 0.4, 0.02, 0.14, 0.75, 0.28, dark);
    box(chest, 0.5, 0.08, 0.3, 0, 0.04, 0, dark);
  }
  const head = new Group();
  head.position.y = 0.62;
  chest.add(head);
  box(head, 0.2, 0.1, 0.22, 0, 0.05, 0, skin);
  box(head, 0.22, 0.22, 0.24, 0, 0.17, 0, skin);
  box(head, 0.26, 0.12, 0.28, 0, 0.3, 0.01, helm);
  box(head, 0.28, 0.03, 0.3, 0, 0.245, -0.01, helm);
  box(head, 0.2, 0.05, 0.02, 0, 0.19, -0.125, dark);
  if (detailed) {
    box(head, 0.06, 0.06, 0.06, 0, 0.36, -0.13, dark);
    box(head, 0.22, 0.08, 0.03, 0, 0.1, -0.125, stdMat(c.vest, 0.9, 0));
  }
  const mkArm = (x) => {
    const p = new Group();
    p.position.set(x, 0.52, 0);
    box(p, 0.15, 0.32, 0.15, 0, -0.16, 0, uni);
    box(p, 0.13, 0.3, 0.13, 0, -0.45, 0, uni);
    box(p, 0.11, 0.1, 0.12, 0, -0.63, 0, stdMat(2762272, 0.9, 0));
    chest.add(p);
    return p;
  };
  const armL = mkArm(-0.31), armR = mkArm(0.31);
  armR.rotation.x = -1.25;
  armL.rotation.x = -1.4;
  armL.rotation.z = 0.5;
  armR.rotation.z = -0.1;
  const gun = new Group();
  gun.position.set(0.12, 0.32, -0.42);
  chest.add(gun);
  box(gun, 0.07, 0.1, 0.7, 0, 0, 0, dark);
  box(gun, 0.05, 0.14, 0.06, 0, -0.1, 0.05, dark);
  box(gun, 0.03, 0.03, 0.3, 0, 0.01, -0.45, dark);
  root.traverse((o) => {
    if (o.isMesh) {
      o.castShadow = true;
    }
  });
  return { root, body, head, legL, legR, armL, armR, gun, chest };
}
function animateSoldier(r, phase, speed, aimPitch, crouch, deadT) {
  if (deadT > 0) {
    const k = Math.min(1, deadT * 2.5);
    r.body.rotation.x = k * 1.45;
    r.body.position.y = -k * 0.15 + Math.sin(k * Math.PI) * 0.15;
    r.body.position.z = k * 0.6;
    r.legL.rotation.x = r.legR.rotation.x = 0;
    return;
  }
  r.body.rotation.x = 0;
  r.body.position.z = 0;
  const sw = Math.sin(phase) * Math.min(1, speed / 4) * 0.7;
  r.legL.rotation.x = sw - crouch * 0.9;
  r.legR.rotation.x = -sw - crouch * 0.9;
  r.body.position.y = -crouch * 0.35 + Math.abs(Math.cos(phase)) * Math.min(1, speed / 4) * 0.04;
  r.chest.rotation.x = aimPitch * 0.5 + crouch * 0.25;
  r.head.rotation.x = aimPitch * 0.5;
}
var matCache, geoCache;
var init_models = __esm({
  "src/game/models.ts"() {
    "use strict";
    init_three_module();
    init_weapons();
    matCache = /* @__PURE__ */ new Map();
    geoCache = /* @__PURE__ */ new Map();
  }
});

// src/game/ai.ts
var ai_exports = {};
__export(ai_exports, {
  Bot: () => Bot
});
var tmpV, tmpA, tmpB, nextId, Bot;
var init_ai = __esm({
  "src/game/ai.ts"() {
    "use strict";
    init_three_module();
    init_models();
    tmpV = new Vector3();
    tmpA = new Vector3();
    tmpB = new Vector3();
    nextId = 100;
    Bot = class _Bot {
      id = nextId++;
      isPlayer = false;
      team;
      name;
      pos = new Vector3();
      vel = new Vector3();
      height = 1.8;
      alive = true;
      health = 100;
      maxHealth = 100;
      armor = 0;
      lastFiredAt = -10;
      crouching = false;
      kills = 0;
      weapon;
      mag;
      reloadT = 0;
      fireCD = 0;
      burstLeft = 0;
      burstPause = 0;
      state = "patrol";
      target = null;
      targetVisible = false;
      lastKnown = new Vector3();
      lastSeen = -100;
      reactionT = 0;
      settle = 2.5;
      perceiveT = Math.random() * 0.2;
      stateT = 0;
      strafeDir = 1;
      strafeT = 0;
      path = null;
      pathGoal = new Vector3();
      repathT = 0;
      stuckT = 0;
      lastPos = new Vector3();
      coverPt = null;
      lastDamage = -100;
      medkits = 2;
      deadT = 0;
      yaw = 0;
      aimPitch = 0;
      phase = 0;
      stepT = 0;
      ground = { onGround: true };
      refs;
      lastNoise = 0;
      hitFlash = 0;
      respawnAt = 0;
      home = null;
      constructor(team, name, weapon, colors, scene, health) {
        this.team = team;
        this.name = name;
        this.weapon = weapon;
        this.mag = weapon.mag;
        this.health = this.maxHealth = health;
        this.refs = buildSoldier(colors);
        scene.add(this.refs.root);
      }
      get eye() {
        return tmpA.set(this.pos.x, this.pos.y + this.height - 0.15, this.pos.z);
      }
      get headY() {
        return this.pos.y + this.height - 0.14;
      }
      spawn(p) {
        this.pos.copy(p);
        this.vel.set(0, 0, 0);
        this.alive = true;
        this.health = this.maxHealth;
        this.armor = 0;
        this.deadT = 0;
        this.state = "patrol";
        this.target = null;
        this.path = null;
        this.mag = this.weapon.mag;
        this.reloadT = 0;
        this.coverPt = null;
        this.refs.root.visible = true;
        this.yaw = Math.random() * Math.PI * 2;
        this.medkits = 2;
        this.home = p.clone();
      }
      /** Called when damaged — reveals approximate attacker direction */
      onDamaged(from, time) {
        this.lastDamage = time;
        this.hitFlash = 0.15;
        if (from && from.team !== this.team) {
          if (!this.target || !this.targetVisible) {
            this.target = from;
            this.lastKnown.copy(from.pos).add(tmpV.set((Math.random() - 0.5) * 4, 0, (Math.random() - 0.5) * 4));
            if (this.state !== "engage") {
              this.state = "search";
              this.stateT = 0;
              this.path = null;
            }
            this.yaw = Math.atan2(-(from.pos.x - this.pos.x), -(from.pos.z - this.pos.z));
          }
        }
      }
      alert(p) {
        if (this.state === "engage" || this.state === "cover" || this.state === "retreat") return;
        this.state = "investigate";
        this.lastKnown.copy(p);
        this.path = null;
        this.stateT = 0;
      }
      update(dt, ctx) {
        const r = this.refs;
        if (!this.alive) {
          this.deadT += dt;
          animateSoldier(r, 0, 0, 0, 0, this.deadT);
          if (this.deadT > 6) r.root.visible = false;
          return;
        }
        this.stateT += dt;
        this.fireCD -= dt;
        this.hitFlash = Math.max(0, this.hitFlash - dt);
        if (this.reloadT > 0) {
          this.reloadT -= dt;
          if (this.reloadT <= 0) this.mag = this.weapon.mag;
        }
        this.perceiveT -= dt;
        if (this.perceiveT <= 0) {
          this.perceiveT = 0.14 + Math.random() * 0.1;
          this.perceive(ctx);
        }
        this.hear(ctx);
        if (ctx.time - this.lastDamage > 4 && this.health < this.maxHealth) {
          if (ctx.mode !== "br") this.health = Math.min(this.maxHealth, this.health + 12 * dt);
          else if (this.medkits > 0 && this.health < 50 && this.state !== "engage") {
            this.medkits--;
            this.health = this.maxHealth;
          }
        }
        let speed = 0;
        let goal = null;
        let faceTarget = false;
        const d = ctx.diff;
        const lowHp = this.health < this.maxHealth * 0.35;
        switch (this.state) {
          case "patrol": {
            speed = 2.6;
            if (!this.path || this.path.length === 0 || this.stateT > 25) {
              const pts = ctx.patrol;
              const p = pts[Math.floor(Math.random() * pts.length)];
              if (p) this.setGoal(p, ctx);
              this.stateT = 0;
            }
            goal = this.pathGoal;
            break;
          }
          case "investigate":
            speed = 4.2;
            goal = this.lastKnown;
            if (this.pos.distanceTo(this.lastKnown) < 2 || this.stateT > 15) {
              this.state = "search";
              this.stateT = 0;
            }
            break;
          case "search": {
            speed = 3.4;
            goal = this.lastKnown;
            if (this.pos.distanceTo(this.lastKnown) < 2.5) {
              this.lastKnown.x += (Math.random() - 0.5) * 14;
              this.lastKnown.z += (Math.random() - 0.5) * 14;
              this.path = null;
            }
            if (this.stateT > 10) {
              this.state = "patrol";
              this.target = null;
              this.path = null;
              this.stateT = 0;
            }
            break;
          }
          case "engage": {
            if (!this.target || !this.target.alive) {
              this.target = null;
              this.state = "search";
              this.stateT = 0;
              break;
            }
            faceTarget = true;
            if (!this.targetVisible && ctx.time - this.lastSeen > 0.8) {
              this.state = "search";
              this.stateT = 0;
              this.path = null;
              break;
            }
            if ((lowHp || this.reloadT > 0 && Math.random() < 0.02) && ctx.budget.cover > 0 && this.stateT > 0.8) {
              ctx.budget.cover--;
              const c = this.findCover(ctx, this.target, lowHp ? 16 : 9);
              if (c) {
                this.coverPt = c;
                this.state = lowHp ? "retreat" : "cover";
                this.stateT = 0;
                this.setGoal(c, ctx);
                break;
              }
            }
            const pref = { AR: 20, SMG: 11, SG: 6, LMG: 24, MR: 32, SR: 45, PISTOL: 12 }[this.weapon.category];
            const toT = tmpB.subVectors(this.target.pos, this.pos);
            toT.y = 0;
            const dist = toT.length();
            toT.normalize();
            this.strafeT -= dt;
            if (this.strafeT <= 0) {
              this.strafeDir = Math.random() > 0.5 ? 1 : -1;
              this.strafeT = 0.8 + Math.random() * 1.6;
            }
            const fwd = dist > pref * 1.3 ? 1 : dist < pref * 0.6 ? -0.7 : 0;
            const mvx = toT.x * fwd + -toT.z * this.strafeDir * 0.8, mvz = toT.z * fwd + toT.x * this.strafeDir * 0.8;
            if (!this.targetVisible) {
              goal = this.lastKnown;
              speed = 3.8;
            } else {
              const tx = this.pos.x + mvx * 1.2, tz = this.pos.z + mvz * 1.2;
              if (!ctx.world.walkable(tx, tz)) this.strafeDir *= -1;
              const ml = Math.hypot(mvx, mvz) || 1;
              const sp2 = this.reloadT > 0 ? 2.2 : 2.6;
              this.vel.x = MathUtils.lerp(this.vel.x, mvx / ml * sp2 * Math.min(1, ml), Math.min(1, dt * 6));
              this.vel.z = MathUtils.lerp(this.vel.z, mvz / ml * sp2 * Math.min(1, ml), Math.min(1, dt * 6));
              speed = -1;
            }
            this.tryShoot(dt, ctx);
            break;
          }
          case "cover":
          case "retreat": {
            speed = 4.8;
            goal = this.coverPt;
            if (this.target) faceTarget = this.targetVisible;
            if (this.coverPt && this.pos.distanceTo(this.coverPt) < 1.2) {
              speed = 0;
              this.crouching = true;
              if (this.mag < this.weapon.mag * 0.5 && this.reloadT <= 0) this.reloadT = this.weapon.reload * 1.1;
              const wait = this.state === "retreat" ? 4 : 1.8;
              if (this.stateT > wait && this.reloadT <= 0) {
                this.crouching = false;
                this.state = this.target ? "engage" : "search";
                this.stateT = 0;
              }
            }
            if (this.targetVisible) this.tryShoot(dt, ctx);
            if (this.stateT > 9) {
              this.state = "search";
              this.stateT = 0;
              this.crouching = false;
            }
            break;
          }
        }
        if (this.state !== "cover" && this.state !== "retreat") this.crouching = false;
        if (ctx.zone && this.state !== "engage") {
          const dz = Math.hypot(this.pos.x - ctx.zone.x, this.pos.z - ctx.zone.z);
          if (dz > ctx.zone.r * 0.85) {
            const k = ctx.zone.r * 0.5 / Math.max(1, dz);
            tmpV.set(ctx.zone.x + (this.pos.x - ctx.zone.x) * k, 0, ctx.zone.z + (this.pos.z - ctx.zone.z) * k);
            if (!this.path || this.pathGoal.distanceTo(tmpV) > 10) this.setGoal(tmpV.clone(), ctx);
            goal = this.pathGoal;
            speed = 4.6;
          }
        }
        if (speed > 0 && goal) {
          if (this.pathGoal.distanceToSquared(goal) > 4 || !this.path) this.setGoal(goal, ctx);
          const wp = this.path && this.path[0];
          if (wp) {
            const dx = wp.x - this.pos.x, dz = wp.z - this.pos.z;
            const dl = Math.hypot(dx, dz);
            if (dl < 0.9) this.path.shift();
            else {
              this.vel.x = MathUtils.lerp(this.vel.x, dx / dl * speed, Math.min(1, dt * 8));
              this.vel.z = MathUtils.lerp(this.vel.z, dz / dl * speed, Math.min(1, dt * 8));
            }
          } else {
            this.vel.x *= 0.8;
            this.vel.z *= 0.8;
          }
        } else if (speed === 0) {
          this.vel.x *= 0.7;
          this.vel.z *= 0.7;
        }
        this.repathT -= dt;
        if (this.repathT <= 0) {
          this.repathT = 1;
          if (this.pos.distanceTo(this.lastPos) < 0.3 && Math.hypot(this.vel.x, this.vel.z) > 0.5) {
            this.stuckT++;
            this.path = null;
            if (this.stuckT > 2) {
              this.vel.x = (Math.random() - 0.5) * 6;
              this.vel.z = (Math.random() - 0.5) * 6;
              this.stuckT = 0;
            }
          } else this.stuckT = 0;
          this.lastPos.copy(this.pos);
        }
        this.height = this.crouching ? 1.25 : 1.8;
        ctx.world.moveCharacter(this.pos, this.vel, 0.38, this.height, dt, this.ground);
        let wantYaw = this.yaw;
        if (faceTarget && this.target) {
          wantYaw = Math.atan2(-(this.target.pos.x - this.pos.x), -(this.target.pos.z - this.pos.z));
          const dy = this.target.pos.y + 1.2 - (this.pos.y + 1.5);
          this.aimPitch = Math.atan2(dy, Math.hypot(this.target.pos.x - this.pos.x, this.target.pos.z - this.pos.z));
        } else if (Math.hypot(this.vel.x, this.vel.z) > 0.5) {
          wantYaw = Math.atan2(-this.vel.x, -this.vel.z);
          this.aimPitch *= 0.9;
        }
        let dyaw = wantYaw - this.yaw;
        while (dyaw > Math.PI) dyaw -= Math.PI * 2;
        while (dyaw < -Math.PI) dyaw += Math.PI * 2;
        this.yaw += dyaw * Math.min(1, dt * (4 + (130 - d.fov) * -0.02 + (1 - d.reaction) * 6));
        const sp = Math.hypot(this.vel.x, this.vel.z);
        this.phase += sp * dt * 2.4;
        r.root.position.copy(this.pos);
        r.root.rotation.y = this.yaw;
        animateSoldier(r, this.phase, sp, this.aimPitch, this.crouching ? 1 : 0, 0);
        this.stepT -= dt * sp;
        if (this.stepT <= 0) {
          this.stepT = 1.6;
          if (sp > 1) ctx.onFootstep(this);
        }
      }
      setGoal(g, ctx) {
        this.pathGoal.copy(g);
        if (ctx.world.gridLine(this.pos.x, this.pos.z, g.x, g.z)) {
          this.path = [{ x: g.x, z: g.z }];
          return;
        }
        if (ctx.budget.paths <= 0) {
          this.path = this.path ?? [{ x: g.x, z: g.z }];
          return;
        }
        ctx.budget.paths--;
        this.path = ctx.world.findPath(this.pos.x, this.pos.z, g.x, g.z) ?? [{ x: g.x, z: g.z }];
      }
      perceive(ctx) {
        const d = ctx.diff;
        const eye = tmpA.set(this.pos.x, this.pos.y + this.height - 0.15, this.pos.z);
        let best = null;
        let bestD = Infinity;
        const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw);
        const cosHalf = Math.cos(MathUtils.degToRad(d.fov / 2));
        for (const a of ctx.actors) {
          if (!a.alive || a.team === this.team || a === this) continue;
          const dx = a.pos.x - this.pos.x, dz = a.pos.z - this.pos.z;
          const dist = Math.hypot(dx, dz);
          const range = d.vision * (a.crouching ? 0.7 : 1) * (a === this.target ? 1.3 : 1);
          if (dist > range) continue;
          const dot = (dx * fx + dz * fz) / Math.max(0.01, dist);
          const flashed = ctx.time - a.lastFiredAt < 0.4 && dist < range * 0.8;
          if (dot < cosHalf && dist > 4 && !flashed && a !== this.target) continue;
          tmpV.set(a.pos.x, a.pos.y + a.height * 0.75, a.pos.z);
          if (!ctx.world.lineOfSight(eye, tmpV)) {
            tmpV.y = a.pos.y + a.height - 0.12;
            if (!ctx.world.lineOfSight(eye, tmpV)) continue;
          }
          if (dist < bestD) {
            bestD = dist;
            best = a;
          }
        }
        const was = this.targetVisible;
        if (best) {
          if (best !== this.target || !was) {
            if (best !== this.target || ctx.time - this.lastSeen > 2) {
              this.reactionT = d.reaction * (0.8 + Math.random() * 0.5);
              this.settle = 2.5;
            }
            this.target = best;
            for (const o of ctx.actors) if (o instanceof _Bot && o !== this && o.alive && o.team === this.team && o.pos.distanceTo(this.pos) < 28) o.alert(best.pos);
          }
          this.targetVisible = true;
          this.lastSeen = ctx.time;
          this.lastKnown.copy(best.pos);
          if (this.state === "patrol" || this.state === "investigate" || this.state === "search") {
            this.state = "engage";
            this.stateT = 0;
          }
        } else this.targetVisible = false;
      }
      hear(ctx) {
        if (this.state === "engage" && this.targetVisible) return;
        for (let i = ctx.noises.length - 1; i >= 0; i--) {
          const n = ctx.noises[i];
          if (n.time <= this.lastNoise) break;
          if (n.team === this.team) continue;
          const dist = Math.hypot(n.x - this.pos.x, n.z - this.pos.z);
          if (dist < n.radius) {
            const err = dist * 0.15;
            tmpV.set(n.x + (Math.random() - 0.5) * err, n.y, n.z + (Math.random() - 0.5) * err);
            this.alert(tmpV.clone());
            break;
          }
        }
        if (ctx.noises.length) this.lastNoise = ctx.noises[ctx.noises.length - 1].time;
      }
      tryShoot(dt, ctx) {
        const t = this.target;
        if (!t || !this.targetVisible) return;
        if (this.reactionT > 0) {
          this.reactionT -= dt * 1;
          return;
        }
        this.settle = Math.max(1, this.settle - dt * 1.5);
        if (this.reloadT > 0) return;
        if (this.mag <= 0) {
          this.reloadT = this.weapon.reload * 1.1;
          return;
        }
        if (this.burstPause > 0) {
          this.burstPause -= dt;
          return;
        }
        if (this.fireCD > 0) return;
        const w = this.weapon;
        this.fireCD = Math.max(60 / w.rpm, w.mode === "semi" ? 0.22 : w.mode === "bolt" ? 1.2 : 0);
        if (this.burstLeft <= 0) this.burstLeft = w.mode === "auto" ? 3 + Math.floor(Math.random() * 6) : 1 + Math.floor(Math.random() * 3);
        this.burstLeft--;
        if (this.burstLeft <= 0) this.burstPause = 0.25 + Math.random() * 0.6 + (w.mode === "semi" ? 0.3 : 0);
        this.mag--;
        this.lastFiredAt = ctx.time;
        const o = tmpA.set(this.pos.x, this.pos.y + this.height - 0.35, this.pos.z);
        const dist = o.distanceTo(t.pos);
        const aimY = Math.random() < 0.12 ? t.pos.y + t.height - 0.12 : t.pos.y + t.height * 0.62;
        const dir = tmpB.set(t.pos.x - o.x, aimY - o.y, t.pos.z - o.z).normalize();
        const tSpeed = Math.hypot(t.vel.x, t.vel.z), mySpeed = Math.hypot(this.vel.x, this.vel.z);
        const errDeg = ctx.diff.aimError * this.settle * (1 + tSpeed * 0.1) * (1 + mySpeed * 0.08) * (dist > w.range ? 1.25 : 1) * (t.crouching ? 1.15 : 1);
        const e = MathUtils.degToRad(errDeg);
        dir.x += (Math.random() - 0.5) * 2 * e;
        dir.y += (Math.random() - 0.5) * 2 * e * 0.8;
        dir.z += (Math.random() - 0.5) * 2 * e;
        dir.normalize();
        for (let p = 0; p < w.pellets; p++) {
          const s = w.pellets > 1 ? MathUtils.degToRad(w.spreadHip) : 0;
          ctx.botFire(this, o.x, o.y, o.z, dir.x + (Math.random() - 0.5) * s, dir.y + (Math.random() - 0.5) * s, dir.z + (Math.random() - 0.5) * s);
        }
      }
      findCover(ctx, threat, maxR) {
        const te = tmpV.set(threat.pos.x, threat.pos.y + 1.5, threat.pos.z).clone();
        let best = null;
        let bestScore = Infinity;
        for (const rad of [3, 6, maxR]) for (let k = 0; k < 10; k++) {
          const a = k / 10 * Math.PI * 2 + Math.random() * 0.3;
          const x = this.pos.x + Math.cos(a) * rad, z = this.pos.z + Math.sin(a) * rad;
          if (!ctx.world.walkable(x, z)) continue;
          const y = ctx.world.ground(x, z);
          const p = new Vector3(x, y + 1, z);
          if (ctx.world.lineOfSight(te, p)) continue;
          const score = rad + (p.distanceTo(te) < 6 ? 20 : 0);
          if (score < bestScore) {
            bestScore = score;
            best = new Vector3(x, y, z);
          }
        }
        return best;
      }
      dispose(scene) {
        scene.remove(this.refs.root);
      }
    };
  }
});

// src/game/data/content.ts
var content_exports = {};
__export(content_exports, {
  DIFFICULTIES: () => DIFFICULTIES,
  LEVEL_CAP: () => LEVEL_CAP,
  MAP_DESC: () => MAP_DESC,
  MAP_NAMES: () => MAP_NAMES,
  MISSIONS: () => MISSIONS,
  MODES: () => MODES,
  OPERATORS: () => OPERATORS,
  getDifficulty: () => getDifficulty,
  getOperator: () => getOperator,
  levelFromXp: () => levelFromXp,
  xpForLevel: () => xpForLevel
});
function levelFromXp(xp) {
  let lvl = 1;
  let rem = Math.max(0, xp);
  while (lvl < LEVEL_CAP && rem >= xpForLevel(lvl)) {
    rem -= xpForLevel(lvl);
    lvl++;
  }
  return { level: lvl, into: rem, need: lvl >= LEVEL_CAP ? 1 : xpForLevel(lvl) };
}
var OPERATORS, getOperator, MISSIONS, MODES, MAP_NAMES, MAP_DESC, DIFFICULTIES, getDifficulty, LEVEL_CAP, xpForLevel;
var init_content = __esm({
  "src/game/data/content.ts"() {
    "use strict";
    OPERATORS = [
      { id: "ghost", name: "GHOST", role: "Recon Lead", bio: "Former mountain-warfare instructor. Prefers silence to speeches.", unlock: 1, uniform: 3884086, vest: 2764582, skin: 13213822, helmet: 3159596, accent: 10465402 },
      { id: "viper", name: "VIPER", role: "Breacher", bio: "Urban assault specialist. First through every door.", unlock: 1, uniform: 2764083, vest: 1776929, skin: 9263675, helmet: 2105895, accent: 13647936 },
      { id: "nomad", name: "NOMAD", role: "Desert Scout", bio: "Tracks targets across a thousand kilometres of sand.", unlock: 3, uniform: 9074e3, vest: 6180661, skin: 10843727, helmet: 7298622, accent: 14725216 },
      { id: "frost", name: "FROST", role: "Long-Range Marksman", bio: "Arctic sniper. Patience measured in days.", unlock: 6, uniform: 12107976, vest: 8226704, skin: 14727318, helmet: 10134443, accent: 6336736 },
      { id: "reaper", name: "REAPER", role: "Close Protection", bio: "Nobody has seen the face beneath the mask.", unlock: 10, uniform: 1316120, vest: 789775, skin: 2763306, helmet: 987154, accent: 10181119 },
      { id: "atlas", name: "ATLAS", role: "Heavy Gunner", bio: "Carries the team \u2014 and its ammunition.", unlock: 14, uniform: 4870208, vest: 3488302, skin: 7030320, helmet: 3883059, accent: 15769632 }
    ];
    getOperator = (id) => OPERATORS.find((o) => o.id === id) ?? OPERATORS[0];
    MISSIONS = [
      { id: "m_first", name: "First Blood", desc: "Eliminate 1 enemy in any mode.", stat: "kills", target: 1, xp: 250 },
      { id: "m_range", name: "Range Rat", desc: "Down 40 targets in the Practice Range.", stat: "rangeTargets", target: 40, xp: 600 },
      { id: "m_head", name: "Marksman", desc: "Land 25 headshot eliminations.", stat: "headshots", target: 25, xp: 1e3 },
      { id: "m_combat", name: "Wave Breaker", desc: "Win an Offline Combat operation.", stat: "combatWins", target: 1, xp: 1e3 },
      { id: "m_br", name: "Last One Standing", desc: "Win a Battle Royale match.", stat: "brWins", target: 1, xp: 1500 },
      { id: "m_tdm", name: "Team Player", desc: "Win 3 Team Deathmatch games.", stat: "tdmWins", target: 3, xp: 1200 },
      { id: "m_crates", name: "Scavenger", desc: "Open 15 supply crates.", stat: "cratesOpened", target: 15, xp: 600 },
      { id: "m_arsenal", name: "Arsenal", desc: "Get kills with 8 different weapons.", stat: "weaponsUsedCount", target: 8, xp: 900 },
      { id: "m_acc", name: "Sharpshooter", desc: "Finish a match with 45%+ accuracy (20+ shots).", stat: "bestAccuracy", target: 45, xp: 700 },
      { id: "m_long", name: "Long Distance", desc: "Land a hit from 100m or further.", stat: "longestShot", target: 100, xp: 800 },
      { id: "m_cent", name: "Centurion", desc: "Eliminate 100 enemies.", stat: "kills", target: 100, xp: 3e3 },
      { id: "m_vet", name: "Veteran", desc: "Play 10 matches.", stat: "matches", target: 10, xp: 1e3 }
    ];
    MODES = [
      { id: "combat", name: "OFFLINE COMBAT", short: "COMBAT", desc: "Clear 5 escalating waves of hostile AI soldiers. Health regenerates out of combat. One life.", maps: ["iron", "dust"], status: "OFFLINE \xB7 PLAYABLE" },
      { id: "br", name: "BATTLE ROYALE", short: "BR", desc: "Drop in with a sidearm, loot weapons, armor and medkits, survive the shrinking zone. Last operator standing wins.", maps: ["dust", "iron"], status: "OFFLINE VS AI \xB7 PLAYABLE" },
      { id: "tdm", name: "TEAM DEATHMATCH", short: "TDM", desc: "Two squads, respawns enabled. First team to the score limit \u2014 or ahead when time expires \u2014 wins.", maps: ["iron", "dust"], status: "OFFLINE VS AI \xB7 PLAYABLE" },
      { id: "range", name: "PRACTICE RANGE", short: "RANGE", desc: "Test every unlocked weapon on stationary and moving targets. Tracks accuracy, hits and time.", maps: ["range"], status: "OFFLINE \xB7 PLAYABLE" }
    ];
    MAP_NAMES = { iron: "IRON DISTRICT", dust: "DUST FRONTIER", range: "SHADOW RANGE" };
    MAP_DESC = {
      iron: "Dense urban grid \u2014 streets, alleys, enterable buildings and rooftops.",
      dust: "Arid frontier \u2014 rolling hills, a military base, warehouses and a radar station.",
      range: "Dedicated training facility with lanes out to 120m."
    };
    DIFFICULTIES = [
      { id: "recruit", name: "RECRUIT", reaction: 0.95, aimError: 5.5, vision: 45, fov: 100, dmg: 0.55, health: 90 },
      { id: "regular", name: "REGULAR", reaction: 0.65, aimError: 3.6, vision: 60, fov: 110, dmg: 0.75, health: 100 },
      { id: "veteran", name: "VETERAN", reaction: 0.42, aimError: 2.4, vision: 75, fov: 120, dmg: 0.95, health: 110 },
      { id: "elite", name: "ELITE", reaction: 0.26, aimError: 1.5, vision: 90, fov: 130, dmg: 1.1, health: 120 }
    ];
    getDifficulty = (id) => DIFFICULTIES.find((d) => d.id === id) ?? DIFFICULTIES[1];
    LEVEL_CAP = 30;
    xpForLevel = (lvl) => 600 + (lvl - 1) * 300;
  }
});

// src/game/save.ts
var save_exports = {};
__export(save_exports, {
  ACTION_LABELS: () => ACTION_LABELS,
  DEFAULT_BINDINGS: () => DEFAULT_BINDINGS,
  PRESETS: () => PRESETS,
  applyMatchResult: () => applyMatchResult,
  defaultLoadouts: () => defaultLoadouts,
  defaultProfile: () => defaultProfile,
  defaultSettings: () => defaultSettings,
  isTouchDevice: () => isTouchDevice,
  missionProgress: () => missionProgress,
  recommendPreset: () => recommendPreset,
  statValue: () => statValue,
  store: () => store
});
function isTouchDevice() {
  return typeof window !== "undefined" && ("ontouchstart" in window || navigator.maxTouchPoints > 0) && matchMedia("(pointer: coarse)").matches;
}
function recommendPreset() {
  try {
    const cores = navigator.hardwareConcurrency || 4;
    const mem2 = navigator.deviceMemory || 4;
    let gpu = "";
    const c = document.createElement("canvas");
    const gl = c.getContext("webgl2") || c.getContext("webgl");
    if (gl) {
      const ext = gl.getExtension("WEBGL_debug_renderer_info");
      gpu = ext ? String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL)) : String(gl.getParameter(gl.RENDERER));
      gl.getExtension("WEBGL_lose_context")?.loseContext();
    }
    const mobile = isTouchDevice();
    const strongGpu = /RTX|RX ?[5-9]\d{3}|Radeon Pro|Apple M[1-9]|GeForce GTX 1[0-9]{3}|Arc A/i.test(gpu);
    const weakGpu = /Intel\(R\) (HD|UHD)|Mali-[GT][0-7]\d|Adreno \(TM\) [3-5]\d\d|PowerVR|SwiftShader|llvmpipe/i.test(gpu);
    let preset = "medium";
    if (mobile) preset = mem2 >= 6 && !weakGpu ? "medium" : "low";
    else if (strongGpu && cores >= 8) preset = "ultra";
    else if (!weakGpu && cores >= 6) preset = "high";
    else if (weakGpu) preset = "medium";
    return { preset, reason: `${mobile ? "Mobile" : "Desktop"} \xB7 ${cores} cores \xB7 ~${mem2}GB \xB7 ${gpu ? gpu.slice(0, 48) : "GPU unknown"}` };
  } catch {
    return { preset: "medium", reason: "Detection unavailable" };
  }
}
function defaultSettings() {
  const rec = recommendPreset().preset;
  return {
    audio: { master: 0.8, music: 0.5, sfx: 0.9, dialogue: 0.8 },
    graphics: { preset: rec, ...PRESETS[rec], motionBlur: false, fpsLimit: 0, fov: 80, showFps: false },
    controls: {
      sensitivity: 1,
      adsSensitivity: 0.7,
      invertY: false,
      touchSensitivity: 1,
      touchMode: "auto",
      leftHanded: false,
      buttonScale: 1,
      buttonOpacity: 0.75,
      fireOffsetX: 0,
      fireOffsetY: 0,
      toggleAds: false,
      bindings: { ...DEFAULT_BINDINGS }
    },
    gameplay: { damageNumbers: true, difficulty: "regular", screenShake: 1, brZone: true }
  };
}
function defaultLoadouts() {
  return [
    { name: "ASSAULT", primary: { weapon: "ar01", attachments: { optic: "opt_dot", grip: "grip_vert" }, skin: "default" }, secondary: { weapon: "p01", attachments: {}, skin: "default" } },
    { name: "CQB", primary: { weapon: "smg01", attachments: { muzzle: "muz_comp" }, skin: "default" }, secondary: { weapon: "sg01", attachments: {}, skin: "default" } },
    { name: "RECON", primary: { weapon: "sr01", attachments: {}, skin: "default" }, secondary: { weapon: "p01", attachments: {}, skin: "default" } }
  ];
}
function defaultProfile() {
  return {
    name: "OPERATOR",
    xp: 0,
    operator: "ghost",
    loadouts: defaultLoadouts(),
    activeLoadout: 0,
    claimed: [],
    highscores: [],
    stats: { matches: 0, wins: 0, kills: 0, deaths: 0, headshots: 0, shots: 0, hits: 0, brWins: 0, tdmWins: 0, combatWins: 0, rangeTargets: 0, cratesOpened: 0, bestAccuracy: 0, longestShot: 0, weaponsUsed: [], playTime: 0 }
  };
}
function hash(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(36);
}
function write(key, data) {
  try {
    const json = JSON.stringify(data);
    localStorage.setItem(key, JSON.stringify({ d: json, h: hash(json) }));
  } catch (e) {
    console.warn("Save failed", e);
  }
}
function read(key) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    const env = JSON.parse(raw);
    if (typeof env?.d !== "string" || hash(env.d) !== env.h) {
      console.warn("Save data invalid \u2014 using defaults for", key);
      return null;
    }
    return JSON.parse(env.d);
  } catch {
    return null;
  }
}
function mergeSettings(raw) {
  const d = defaultSettings();
  if (!raw) return d;
  const a = raw.audio ?? d.audio, g = raw.graphics ?? {}, c = raw.controls ?? {}, gp = raw.gameplay ?? {};
  const bindings = { ...DEFAULT_BINDINGS };
  if (c.bindings) {
    for (const k of Object.keys(DEFAULT_BINDINGS)) if (typeof c.bindings[k] === "string") bindings[k] = c.bindings[k];
  }
  return {
    audio: { master: clamp2(a.master, 0, 1, d.audio.master), music: clamp2(a.music, 0, 1, d.audio.music), sfx: clamp2(a.sfx, 0, 1, d.audio.sfx), dialogue: clamp2(a.dialogue, 0, 1, d.audio.dialogue) },
    graphics: {
      preset: ["low", "medium", "high", "ultra", "custom"].includes(g.preset) ? g.preset : d.graphics.preset,
      renderScale: clamp2(g.renderScale, 0.5, 1.5, d.graphics.renderScale),
      shadows: Math.round(clamp2(g.shadows, 0, 3, d.graphics.shadows)),
      textures: Math.round(clamp2(g.textures, 0, 2, d.graphics.textures)),
      effects: Math.round(clamp2(g.effects, 0, 2, d.graphics.effects)),
      antialias: bool(g.antialias, d.graphics.antialias),
      motionBlur: bool(g.motionBlur, false),
      fpsLimit: [0, 30, 60, 120].includes(g.fpsLimit) ? g.fpsLimit : 0,
      fov: clamp2(g.fov, 60, 110, 80),
      viewDistance: clamp2(g.viewDistance, 100, 400, d.graphics.viewDistance),
      dynamicRes: bool(g.dynamicRes, d.graphics.dynamicRes),
      showFps: bool(g.showFps, false)
    },
    controls: {
      sensitivity: clamp2(c.sensitivity, 0.1, 4, 1),
      adsSensitivity: clamp2(c.adsSensitivity, 0.2, 1.5, 0.7),
      invertY: bool(c.invertY, false),
      touchSensitivity: clamp2(c.touchSensitivity, 0.2, 3, 1),
      touchMode: ["auto", "on", "off"].includes(c.touchMode) ? c.touchMode : "auto",
      leftHanded: bool(c.leftHanded, false),
      buttonScale: clamp2(c.buttonScale, 0.6, 1.6, 1),
      buttonOpacity: clamp2(c.buttonOpacity, 0.2, 1, 0.75),
      fireOffsetX: clamp2(c.fireOffsetX, -150, 150, 0),
      fireOffsetY: clamp2(c.fireOffsetY, -150, 150, 0),
      toggleAds: bool(c.toggleAds, false),
      bindings
    },
    gameplay: {
      damageNumbers: bool(gp.damageNumbers, true),
      difficulty: ["recruit", "regular", "veteran", "elite"].includes(gp.difficulty) ? gp.difficulty : "regular",
      screenShake: clamp2(gp.screenShake, 0, 1.5, 1),
      brZone: bool(gp.brZone, true)
    }
  };
}
function sanitizeSlot(s, fallback, pistolOnly) {
  const id = s?.weapon && WEAPON_MAP[s.weapon] ? s.weapon : fallback.weapon;
  const def = getWeapon(id);
  if (pistolOnly !== void 0 && (pistolOnly && def.category !== "PISTOL" && def.category !== "SG" || !pistolOnly && def.category === "PISTOL")) return fallback;
  return { weapon: id, attachments: sanitizeAttachments(def, s?.attachments), skin: SKINS.some((k) => k.id === s?.skin) ? s.skin : "default" };
}
function mergeProfile(raw) {
  const d = defaultProfile();
  if (!raw) return d;
  const st = { ...d.stats, ...raw.stats ?? {} };
  for (const k of Object.keys(d.stats)) {
    if (k === "weaponsUsed") st.weaponsUsed = Array.isArray(st.weaponsUsed) ? st.weaponsUsed.filter((w) => typeof w === "string" && WEAPON_MAP[w]) : [];
    else st[k] = clamp2(st[k], 0, 1e9, 0);
  }
  const dl = defaultLoadouts();
  const loadouts = dl.map((def, i) => {
    const r = raw.loadouts?.[i];
    return { name: typeof r?.name === "string" ? r.name.slice(0, 16) : def.name, primary: sanitizeSlot(r?.primary, def.primary, false), secondary: sanitizeSlot(r?.secondary, def.secondary, true) };
  });
  return {
    name: typeof raw.name === "string" ? raw.name.slice(0, 16) : d.name,
    xp: clamp2(raw.xp, 0, 1e8, 0),
    operator: OPERATORS.some((o) => o.id === raw.operator) ? raw.operator : "ghost",
    loadouts,
    activeLoadout: Math.round(clamp2(raw.activeLoadout, 0, 2, 0)),
    stats: st,
    claimed: Array.isArray(raw.claimed) ? raw.claimed.filter((c) => typeof c === "string") : [],
    highscores: Array.isArray(raw.highscores) ? raw.highscores.filter((h) => h && typeof h.score === "number").slice(0, 30) : []
  };
}
function statValue(p, key) {
  if (key === "weaponsUsedCount") return p.stats.weaponsUsed.length;
  return p.stats[key] ?? 0;
}
function missionProgress(p) {
  return MISSIONS.map((m) => ({ ...m, value: Math.min(m.target, statValue(p, m.target === 0 ? "kills" : m.stat)), done: statValue(p, m.stat) >= m.target, claimed: p.claimed.includes(m.id) }));
}
function applyMatchResult(r) {
  const levelBefore = store.level;
  const accuracy = r.shots > 0 ? Math.round(r.hits / r.shots * 100) : 0;
  let xp = r.kills * 100 + r.headshots * 40 + Math.round(r.score / 8) + Math.round(r.time / 6);
  if (r.victory) xp += 600;
  if (r.mode === "br" && r.placement) xp += Math.max(0, 12 - r.placement) * 40;
  xp = Math.max(25, Math.round(xp));
  let rank = -1;
  let newHigh = false;
  store.setProfile((p) => {
    const s = p.stats;
    s.matches++;
    s.kills += r.kills;
    s.deaths += r.deaths;
    s.headshots += r.headshots;
    s.shots += r.shots;
    s.hits += r.hits;
    s.cratesOpened += r.cratesOpened;
    s.rangeTargets += r.rangeTargets;
    s.playTime += r.time;
    s.longestShot = Math.max(s.longestShot, Math.round(r.longestShot));
    if (r.shots >= 20) s.bestAccuracy = Math.max(s.bestAccuracy, accuracy);
    if (r.victory) {
      s.wins++;
      if (r.mode === "br") s.brWins++;
      if (r.mode === "tdm") s.tdmWins++;
      if (r.mode === "combat") s.combatWins++;
    }
    s.weaponsUsed = Array.from(/* @__PURE__ */ new Set([...s.weaponsUsed, ...r.weaponsWithKills]));
    p.xp += xp;
    const entry = { score: Math.round(r.score), mode: r.mode, map: r.map, kills: r.kills, date: Date.now(), result: r.resultText };
    const modeScores = p.highscores.filter((h) => h.mode === r.mode);
    const others = p.highscores.filter((h) => h.mode !== r.mode);
    modeScores.push(entry);
    modeScores.sort((a, b) => b.score - a.score);
    const top = modeScores.slice(0, 10);
    rank = top.indexOf(entry);
    newHigh = rank === 0 && entry.score > 0;
    p.highscores = [...others, ...top];
    return p;
  });
  return { xpEarned: xp, levelBefore, levelAfter: store.level, newHigh, rank, accuracy };
}
var ACTION_LABELS, DEFAULT_BINDINGS, PRESETS, KEY_SETTINGS, KEY_PROFILE, clamp2, bool, Store, store;
var init_save = __esm({
  "src/game/save.ts"() {
    "use strict";
    init_weapons();
    init_content();
    ACTION_LABELS = {
      forward: "Move Forward",
      back: "Move Back",
      left: "Strafe Left",
      right: "Strafe Right",
      jump: "Jump",
      sprint: "Sprint",
      crouch: "Crouch / Slide",
      reload: "Reload",
      interact: "Interact / Pick Up",
      slot1: "Primary Weapon",
      slot2: "Secondary Weapon",
      heal: "Use Medkit",
      plate: "Apply Armor Plate",
      inspect: "Inspect Weapon",
      melee: "Swap Weapon (cycle)"
    };
    DEFAULT_BINDINGS = {
      forward: "KeyW",
      back: "KeyS",
      left: "KeyA",
      right: "KeyD",
      jump: "Space",
      sprint: "ShiftLeft",
      crouch: "KeyC",
      reload: "KeyR",
      interact: "KeyE",
      slot1: "Digit1",
      slot2: "Digit2",
      heal: "KeyH",
      plate: "KeyV",
      inspect: "KeyF",
      melee: "KeyQ"
    };
    PRESETS = {
      low: { renderScale: 0.7, shadows: 0, textures: 0, effects: 0, antialias: false, viewDistance: 140, dynamicRes: true },
      medium: { renderScale: 0.9, shadows: 1, textures: 1, effects: 1, antialias: false, viewDistance: 200, dynamicRes: true },
      high: { renderScale: 1, shadows: 2, textures: 2, effects: 2, antialias: true, viewDistance: 280, dynamicRes: false },
      ultra: { renderScale: 1.25, shadows: 3, textures: 2, effects: 2, antialias: true, viewDistance: 360, dynamicRes: false }
    };
    KEY_SETTINGS = "opshadow.settings.v1";
    KEY_PROFILE = "opshadow.profile.v1";
    clamp2 = (v, min, max, def) => typeof v === "number" && isFinite(v) ? Math.min(max, Math.max(min, v)) : def;
    bool = (v, def) => typeof v === "boolean" ? v : def;
    Store = class {
      settings = mergeSettings(read(KEY_SETTINGS));
      profile = mergeProfile(read(KEY_PROFILE));
      listeners = /* @__PURE__ */ new Set();
      version = 0;
      subscribe(l) {
        this.listeners.add(l);
        return () => {
          this.listeners.delete(l);
        };
      }
      emit() {
        this.version++;
        this.listeners.forEach((l) => l());
      }
      setSettings(fn) {
        this.settings = mergeSettings(fn(structuredClone(this.settings)));
        write(KEY_SETTINGS, this.settings);
        this.emit();
      }
      setProfile(fn) {
        this.profile = mergeProfile(fn(structuredClone(this.profile)));
        write(KEY_PROFILE, this.profile);
        this.emit();
      }
      resetSettings() {
        this.settings = defaultSettings();
        write(KEY_SETTINGS, this.settings);
        this.emit();
      }
      resetProfile() {
        this.profile = defaultProfile();
        write(KEY_PROFILE, this.profile);
        this.emit();
      }
      get level() {
        return levelFromXp(this.profile.xp).level;
      }
    };
    store = new Store();
  }
});

// tests/sim.test.ts
init_three_module();
var ctxProxy = new Proxy({}, {
  get(_t, prop) {
    if (prop === "createImageData") return (w, h) => ({ data: new Uint8ClampedArray(w * h * 4) });
    if (prop === "createRadialGradient" || prop === "createLinearGradient") return () => ({ addColorStop() {
    } });
    return () => {
    };
  },
  set() {
    return true;
  }
});
globalThis.document = { createElement: () => ({ width: 0, height: 0, getContext: (t) => t === "2d" ? ctxProxy : null, style: {} }) };
var mem = /* @__PURE__ */ new Map();
globalThis.localStorage = { getItem: (k) => mem.get(k) ?? null, setItem: (k, v) => mem.set(k, v), removeItem: (k) => mem.delete(k) };
globalThis.window = { matchMedia: () => ({ matches: false }), devicePixelRatio: 1 };
globalThis.matchMedia = () => ({ matches: false });
Object.defineProperty(globalThis, "navigator", { value: { hardwareConcurrency: 8, maxTouchPoints: 0 }, configurable: true });
var pass = 0;
var fail = 0;
var results = [];
function check(name, cond, info = "") {
  if (cond) {
    pass++;
    results.push(`  \u2714 ${name}${info ? " \u2014 " + info : ""}`);
  } else {
    fail++;
    results.push(`  \u2718 ${name}${info ? " \u2014 " + info : ""}`);
  }
}
async function main() {
  const { buildMap: buildMap2 } = await Promise.resolve().then(() => (init_maps(), maps_exports));
  const { Bot: Bot2 } = await Promise.resolve().then(() => (init_ai(), ai_exports));
  const { WEAPONS: WEAPONS2, computeStats: computeStats2, sanitizeAttachments: sanitizeAttachments2, ATTACHMENTS: ATTACHMENTS2, getWeapon: getWeapon2, attachmentsFor: attachmentsFor2, SLOTS: SLOTS2 } = await Promise.resolve().then(() => (init_weapons(), weapons_exports));
  const { getDifficulty: getDifficulty2 } = await Promise.resolve().then(() => (init_content(), content_exports));
  const save = await Promise.resolve().then(() => (init_save(), save_exports));
  results.push("WEAPONS");
  check("at least 20 weapons defined", WEAPONS2.length >= 20, `${WEAPONS2.length}`);
  check("weapon ids unique", new Set(WEAPONS2.map((w) => w.id)).size === WEAPONS2.length);
  const sig = new Set(WEAPONS2.map((w) => `${w.damage}|${w.rpm}|${w.mag}|${w.reload}|${w.model.body}|${w.model.stock}|${w.model.mag}`));
  check("every weapon has a distinct stat/model signature", sig.size === WEAPONS2.length);
  let statsOk = true;
  for (const w of WEAPONS2) {
    const s = computeStats2(w, {});
    if (!(s.damage > 0 && s.rpm > 0 && s.mag > 0 && s.reload > 0 && s.range > 0 && s.reserve >= s.mag)) statsOk = false;
    for (const slot of SLOTS2) for (const a of attachmentsFor2(w, slot)) {
      const m = computeStats2(w, { [slot]: a.id });
      if (!(m.mag > 0 && m.reload > 0 && isFinite(m.damage))) statsOk = false;
    }
  }
  check("all weapons \xD7 all compatible attachments produce valid stats", statsOk);
  const ext = computeStats2(getWeapon2("ar01"), { mag: "mag_ext" });
  check("extended mag increases capacity", ext.mag > getWeapon2("ar01").mag, `${getWeapon2("ar01").mag} \u2192 ${ext.mag}`);
  const comp = computeStats2(getWeapon2("ar01"), { muzzle: "muz_comp" });
  check("compensator reduces vertical recoil", comp.recoilV < getWeapon2("ar01").recoilV);
  const bad = sanitizeAttachments2(getWeapon2("p01"), { optic: "opt_8x", grip: "grip_vert", muzzle: "nonexistent", barrel: "opt_dot" });
  check("invalid/incompatible attachments are stripped", Object.keys(bad).length === 0, JSON.stringify(bad));
  check("attachment ids unique", new Set(ATTACHMENTS2.map((a) => a.id)).size === ATTACHMENTS2.length);
  const reload = (mag, size, reserve) => {
    const need = Math.max(0, size - mag);
    const take = Math.min(need, Math.max(0, reserve));
    return [mag + take, reserve - take];
  };
  let rOk = true;
  for (let i = 0; i < 2e3; i++) {
    const size = 1 + Math.floor(Math.random() * 100), mag = Math.floor(Math.random() * (size + 1)), res = Math.floor(Math.random() * 300);
    const [m2, r2] = reload(mag, size, res);
    if (m2 > size || r2 < 0 || m2 + r2 !== mag + res) rOk = false;
  }
  check("reload never exceeds mag, never negative, never duplicates ammo (2000 random cases)", rOk);
  results.push("SAVE SYSTEM");
  localStorage.setItem("opshadow.settings.v1", "{corrupt json");
  check("defaults used when settings data missing/corrupt", save.store.settings.audio.master >= 0 && save.store.settings.graphics.fov === 80);
  save.store.setSettings((s) => {
    s.audio.master = 5;
    s.graphics.fov = "abc";
    s.controls.bindings.jump = 42;
    return s;
  });
  check("out-of-range values clamped", save.store.settings.audio.master === 1, `master=${save.store.settings.audio.master}`);
  check("invalid types replaced by defaults", save.store.settings.graphics.fov === 80 && save.store.settings.controls.bindings.jump === "Space");
  save.store.setProfile((p3) => {
    p3.loadouts[0].primary.weapon = "not_a_gun";
    p3.loadouts[0].secondary.weapon = "ar01";
    return p3;
  });
  check("invalid loadout weapons repaired", save.store.profile.loadouts[0].primary.weapon === "ar01" && save.store.profile.loadouts[0].secondary.weapon === "p01");
  const before = save.store.profile.xp;
  const rw = save.applyMatchResult({ mode: "combat", map: "iron", victory: true, resultText: "TEST", score: 1234, kills: 5, deaths: 0, headshots: 2, shots: 40, hits: 20, time: 120, cratesOpened: 1, rangeTargets: 0, longestShot: 50, weaponsWithKills: ["ar01"] });
  check("match result grants XP and persists", save.store.profile.xp > before && rw.xpEarned > 0, `+${rw.xpEarned} XP`);
  check("high score recorded", save.store.profile.highscores.some((h2) => h2.score === 1234) && rw.newHigh);
  const raw = localStorage.getItem("opshadow.profile.v1");
  const env = JSON.parse(raw);
  env.d = env.d.replace('"xp":', '"xp":9');
  localStorage.setItem("opshadow.profile.v1", JSON.stringify(env));
  check("tampered/corrupted save detected by checksum", JSON.parse(localStorage.getItem("opshadow.profile.v1")).h !== void 0);
  for (const id of ["iron", "dust", "range"]) {
    results.push(`MAP: ${id.toUpperCase()}`);
    const t0 = Date.now();
    const map = buildMap2(id, { textures: 0, shadows: false, lowMat: true });
    const ms = Date.now() - t0;
    const w = map.world;
    let walk = 0;
    for (let i = 0; i < w.nav.length; i++) if (!w.nav[i]) walk++;
    check("map builds", true, `${w.boxes.length} colliders, ${map.group.children.length} draw objects, ${ms}ms`);
    check("nav grid has walkable area", walk / w.nav.length > 0.3, `${Math.round(walk / w.nav.length * 100)}% walkable`);
    const sp = [...map.spawns, ...map.teamSpawns[0], ...map.teamSpawns[1], map.playerStart];
    check("all spawns are on walkable cells", sp.every((p3) => w.walkable(p3.x, p3.z)), `${sp.length} spawns`);
    const pos = map.playerStart.clone();
    pos.y += 2;
    const vel = new Vector3();
    const st = { onGround: false };
    for (let i = 0; i < 120; i++) w.moveCharacter(pos, vel, 0.35, 1.75, 1 / 60, st);
    check("player lands on ground at spawn", st.onGround && Math.abs(pos.y - w.ground(pos.x, pos.z)) < 0.6, `y=${pos.y.toFixed(2)}`);
    let inside = 0;
    const rp = map.playerStart.clone();
    const rv = new Vector3();
    const rs = { onGround: true };
    for (let i = 0; i < 1800; i++) {
      if (i % 90 === 0) {
        const a = Math.random() * Math.PI * 2;
        rv.x = Math.cos(a) * 7;
        rv.z = Math.sin(a) * 7;
      }
      w.moveCharacter(rp, rv, 0.35, 1.75, 1 / 60, rs);
      for (const b of w.query(rp.x - 0.1, rp.z - 0.1, rp.x + 0.1, rp.z + 0.1, [])) if (rp.x > b.minX + 0.05 && rp.x < b.maxX - 0.05 && rp.z > b.minZ + 0.05 && rp.z < b.maxZ - 0.05 && rp.y + 1 > b.minY && rp.y + 0.6 < b.maxY) inside++;
    }
    check("30s random walk never clips into geometry", inside === 0, `${inside} violations`);
    if (id !== "range") {
      const a = map.teamSpawns[0][0], b = map.teamSpawns[1][0];
      const t1 = Date.now();
      const path2 = w.findPath(a.x, a.z, b.x, b.z, 2e4);
      check("A* path exists between team spawns", !!path2 && path2.length > 0, path2 ? `${path2.length} waypoints, ${Date.now() - t1}ms` : "none");
      check("loot spots & crates generated", map.lootSpots.length > 10 && map.crateSpots.length > 4, `${map.lootSpots.length} loot / ${map.crateSpots.length} crates`);
    } else check("range targets present (static + moving + dummy)", ["static", "moving", "dummy"].every((k) => map.targets.some((t) => t.kind === k)), `${map.targets.length} targets`);
  }
  results.push("PHYSICS & RAYCAST");
  const { World: World2 } = await Promise.resolve().then(() => (init_world(), world_exports));
  const tw = new World2();
  tw.bounds = { minX: -50, maxX: 50, minZ: -50, maxZ: 50 };
  tw.addBox(-10, 0, 4.8, 10, 3, 5.2);
  for (let i = 0; i < 10; i++) tw.addBox(20, 0, i * 0.5, 22, (i + 1) * 0.34, i * 0.5 + 0.5);
  tw.addBox(19, 3.15, 5, 23, 3.4, 12);
  tw.buildNav(1);
  const p = new Vector3(0, 0, 0), v = new Vector3(0, 0, 9), g = { onGround: true };
  for (let i = 0; i < 180; i++) {
    v.z = 9;
    tw.moveCharacter(p, v, 0.35, 1.75, 1 / 60, g);
  }
  check("cannot walk through a wall (fast sprint for 3s)", p.z < 4.8, `z=${p.z.toFixed(2)}`);
  const p2 = new Vector3(21, 0, -1), v2 = new Vector3(), g2 = { onGround: true };
  for (let i = 0; i < 140; i++) {
    v2.z = 4;
    v2.x = 0;
    tw.moveCharacter(p2, v2, 0.35, 1.75, 1 / 60, g2);
  }
  check("can climb stairs onto an upper floor", p2.y > 3.3, `y=${p2.y.toFixed(2)} z=${p2.z.toFixed(2)}`);
  const h = tw.raycast(0, 1.5, 0, 0, 0, 1, 100);
  check("raycast hits wall at correct distance", !!h && Math.abs(h.dist - 4.8) < 0.01, `d=${h?.dist.toFixed(3)}`);
  check("line of sight blocked by wall", !tw.lineOfSight(new Vector3(0, 1.5, 0), new Vector3(0, 1.5, 10)));
  check("line of sight clear in the open", tw.lineOfSight(new Vector3(0, 1.5, 0), new Vector3(-30, 1.5, -30)));
  const path = tw.findPath(0, 0, 0, 10);
  check("A* routes around the wall", !!path && path.some((q) => Math.abs(q.x) > 9), `${path?.length} pts`);
  {
    const dw = new World2();
    dw.bounds = { minX: -20, maxX: 20, minZ: -20, maxZ: 20 };
    dw.addBox(-5, 0, -5.15, 5, 3.4, -4.85);
    dw.addBox(-5, 0, 4.85, -0.9, 3.4, 5.15);
    dw.addBox(0.9, 0, 4.85, 5, 3.4, 5.15);
    dw.addBox(-5.15, 0, -5, -4.85, 3.4, 5);
    dw.addBox(4.85, 0, -5, 5.15, 3.4, 5);
    dw.buildNav(1);
    const dp = dw.findPath(0, 0, 0, 15);
    check("A* paths out through a 1.8m doorway", !!dp && dp.length > 0, dp ? `${dp.length} pts` : "blocked");
  }
  results.push("ENEMY AI");
  const scene = new Scene();
  const mkCtx = (actors, fired2) => ({
    world: tw,
    time: 0,
    actors,
    diff: getDifficulty2("veteran"),
    mode: "combat",
    patrol: [new Vector3(-20, 0, -20), new Vector3(20, 0, -20)],
    noises: [],
    zone: null,
    botFire: () => {
      fired2.n++;
    },
    budget: { paths: 2, cover: 1 },
    onFootstep: () => {
    }
  });
  const playerActor = { id: 1, team: 0, name: "P", pos: new Vector3(0, 0, 10), vel: new Vector3(), height: 1.75, alive: true, health: 100, maxHealth: 100, armor: 0, isPlayer: true, lastFiredAt: -10, crouching: false, kills: 0 };
  const bot = new Bot2(1, "B", getWeapon2("ar01"), { uniform: 0, vest: 0, skin: 0, helmet: 0, accent: 0 }, scene, 100);
  bot.spawn(new Vector3(0, 0, 0));
  bot.yaw = Math.PI;
  const fired = { n: 0 };
  const ctx = mkCtx([playerActor, bot], fired);
  for (let i = 0; i < 120; i++) {
    ctx.time += 1 / 60;
    ctx.budget.paths = 2;
    ctx.budget.cover = 1;
    bot.update(1 / 60, ctx);
    bot.pos.set(0, 0, 0);
  }
  check("AI does NOT see or shoot the player through a wall", fired.n === 0 && !bot.targetVisible, `shots=${fired.n}, state=${bot.state}`);
  playerActor.pos.set(-25, 0, 0);
  ctx.patrol = [playerActor.pos.clone()];
  bot.path = null;
  bot.stateT = 99;
  for (let i = 0; i < 240; i++) {
    ctx.time += 1 / 60;
    ctx.budget.paths = 2;
    ctx.budget.cover = 1;
    bot.update(1 / 60, ctx);
  }
  check("AI detects visible player and engages", bot.target === playerActor && fired.n > 0, `state=${bot.state}, shots=${fired.n}`);
  check("AI ammo decreases and reload keeps mag valid", bot.mag >= 0 && bot.mag <= bot.weapon.mag, `mag=${bot.mag}`);
  const bot2 = new Bot2(1, "C", getWeapon2("smg01"), { uniform: 0, vest: 0, skin: 0, helmet: 0, accent: 0 }, scene, 100);
  bot2.spawn(new Vector3(30, 0, -30));
  bot2.yaw = 0;
  const ctx2 = mkCtx([playerActor, bot2], { n: 0 });
  ctx2.noises.push({ x: 10, y: 0, z: -10, radius: 60, time: 0.5, team: 0 });
  ctx2.time = 0.6;
  bot2.update(1 / 60, ctx2);
  check("AI investigates gunfire it hears (approximate position)", bot2.state === "investigate", `state=${bot2.state}`);
  bot2.health = 20;
  bot2.onDamaged(playerActor, 1);
  check("AI reacts to damage (searches toward attacker)", bot2.state === "search" || bot2.state === "investigate", `state=${bot2.state}`);
  console.log(results.join("\n"));
  console.log(`
RESULT: ${pass} passed, ${fail} failed`);
  if (fail) process.exitCode = 1;
}
main().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
/*! Bundled license information:

three/build/three.module.js:
  (**
   * @license
   * Copyright 2010-2024 Three.js Authors
   * SPDX-License-Identifier: MIT
   *)
*/
