import assert from 'node:assert/strict';

const values = new Map();
globalThis.localStorage = {
  getItem: key => values.has(key) ? values.get(key) : null,
  setItem: (key, value) => values.set(key, String(value)),
  removeItem: key => values.delete(key),
  clear: () => values.clear()
};
globalThis.CustomEvent = class CustomEvent { constructor(type) { this.type = type; } };
globalThis.window = { dispatchEvent() {}, addEventListener() {} };

const Data = await import('../www/js/data.js');
const Engine = await import('../www/js/engine.js');
const Photo = await import('../www/js/photo-analysis.js');

function image(r, g, b, w = 12, h = 12, pattern = 'solid') {
  const data = new Uint8ClampedArray(w * h * 4);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const i = (y * w + x) * 4;
    let rr = r, gg = g, bb = b;
    if (pattern === 'gradient') { rr = Math.round(x / Math.max(1, w - 1) * 255); gg = Math.round(y / Math.max(1, h - 1) * 255); bb = (x + y) % 2 ? 35 : 230; }
    data[i] = rr; data[i + 1] = gg; data[i + 2] = bb; data[i + 3] = 255;
  }
  return { data, width: w, height: h };
}

// Photo analysis: deterministic, pixel-based and bounded; no fake fallback values.
const red = Photo.analyzePixelData(image(235, 35, 25));
const green = Photo.analyzePixelData(image(25, 225, 55));
const blue = Photo.analyzePixelData(image(20, 60, 230));
const black = Photo.analyzePixelData(image(0, 0, 0));
const detailed = Photo.analyzePixelData(image(0, 0, 0, 24, 24, 'gradient'));
assert.equal(red.element, 'Chama');
assert.equal(green.element, 'Flora');
assert.equal(blue.element, 'Maré');
assert.equal(black.element, 'Sombra');
assert(detailed.detail > 0, 'edge detail should respond to pixel changes');
assert.notDeepEqual(red, black, 'different images should generate different deterministic analysis results');
assert.deepEqual(red, Photo.analyzePixelData(image(235, 35, 25)), 'same pixels must always return same attributes');
for (const result of [red, green, blue, black, detailed]) {
  assert(result.atk >= 10 && result.atk <= 180);
  assert(result.def >= 10 && result.def <= 180);
  assert(result.hp >= 50 && result.hp <= 240);
  assert(result.score >= 0 && result.score <= 100);
}
assert.throws(() => Photo.analyzePixelData({ data: new Uint8Array(2), width: 2, height: 2 }), /inválidos/);

// Starter content: 24 valid cards, a mix of creatures/actions, at most three copies each.
const deck = Data.DB.decks[0];
assert.equal(deck.cards.length, 24);
const copyCounts = new Map();
for (const id of deck.cards) copyCounts.set(id, (copyCounts.get(id) || 0) + 1);
assert([...copyCounts.values()].every(count => count <= 3));
assert(deck.cards.every(id => Data.DB.cards.some(card => card.id === id)));
assert(deck.cards.some(id => Data.DB.cards.find(card => card.id === id).kind === 'creature'));
assert(deck.cards.some(id => Data.DB.cards.find(card => card.id === id).kind !== 'creature'));
const creature = Data.DB.cards.find(card => card.kind === 'creature');

// Illegal/incomplete decks must not launch.
const invalidDeck = { id: 'regression-invalid', name: 'Inválido', cards: [creature.id] };
Data.DB.decks.push(invalidDeck);
assert.throws(() => Engine.startGame({ mode: 'classic', deckId: invalidDeck.id }), /24 cartas/);
Data.DB.decks.pop();

// Shield absorbs damage; reflection damages the attacking duelist.
Engine.startGame({ mode: 'training', deckId: deck.id });
let p1 = Engine.side(), p2 = Engine.opponent();
p1.active = { ...creature, id: 'reg-shield-attacker', atk: 80, def: 0, currentHp: 100 };
p2.active = { ...creature, id: 'reg-shield-target', def: 0, currentHp: 150 };
p2.shield = 30; p2.reflect = 10;
const p1Life = p1.life;
Engine.attack();
assert.equal(p2.active.currentHp, 100, '30 shield should be removed before 50 damage reaches creature');
assert.equal(p1.life, p1Life - 10, 'reflection should damage attacker life');

// Spike trap hurts the attacker and is consumed by the attack.
Engine.startGame({ mode: 'training', deckId: deck.id });
p1 = Engine.side(); p2 = Engine.opponent();
p1.active = { ...creature, id: 'reg-trap-attacker', atk: 60, def: 0, currentHp: 100 };
p2.active = { ...creature, id: 'reg-trap-target', def: 0, currentHp: 150 };
p2.trap = { type: 'spike', name: 'Espinhos Ocultos' };
Engine.attack();
assert.equal(p1.active.currentHp, 70);
assert.equal(p2.trap, null);
assert.equal(p2.active.currentHp, 90);

// Double strike consumes the skill and produces a second, reduced attack.
Engine.startGame({ mode: 'training', deckId: deck.id });
p1 = Engine.side(); p2 = Engine.opponent();
p1.active = { ...creature, id: 'reg-double', ability: 'double', atk: 80, def: 0, currentHp: 100 };
p2.active = { ...creature, id: 'reg-double-target', def: 0, currentHp: 150 };
p1.energy = 10;
assert.equal(Engine.canUseAbility(), true);
Engine.activateAbility();
Engine.attack();
assert.equal(p2.active.currentHp, 22, '80 + 48 damage should be dealt by double strike');

// Burn and poison apply at turn start and tick down.
Engine.startGame({ mode: 'training', deckId: deck.id });
p1 = Engine.side(); p2 = Engine.opponent();
p2.life = 80; p2.active = { ...creature, id: 'reg-status-target', atk: 0, def: 100, currentHp: 100 };
p2.hand = []; p2.energy = 0;
p2.status = [{ type: 'burn', turns: 1, value: 15 }, { type: 'poison', turns: 2, value: 10 }];
Engine.endTurn();
let state = Engine.snapshot();
assert.equal(state.sides.p2.life, 55, 'burn and poison should apply at the start of the CPU side turn');
assert.deepEqual(state.sides.p2.status.map(s => s.turns), [1], 'expired statuses should be removed');

// Revive is passive and activates once when its creature is defeated.
Engine.startGame({ mode: 'training', deckId: deck.id });
p1 = Engine.side(); p2 = Engine.opponent();
p1.active = { ...creature, id: 'reg-revive', ability: 'revive', hp: 100, currentHp: 1, def: 0 };
p2.active = { ...creature, id: 'reg-heavy-attacker', atk: 150, def: 0, currentHp: 120, ability: 'none' };
p2.hand = []; p2.energy = 0;
Engine.endTurn();
state = Engine.snapshot();
assert(state.sides.p1.active && state.sides.p1.active.currentHp === 35, 'revive should restore 35% of creature HP once');

// Two-player local pass hides control until confirmation and gives no profile rewards.
const oldWins = Data.DB.wins, oldCoins = Data.DB.coins;
Engine.startGame({ mode: 'same', deckId: deck.id, secondDeckId: deck.id });
Engine.endTurn();
assert.equal(Engine.snapshot().pendingPass, true);
Engine.passToNext();
assert.equal(Engine.snapshot().pendingPass, false);
Engine.endTurn();
Engine.passToNext();
assert.equal(Engine.snapshot().active, 'p1');
p1 = Engine.side();
p1.active = { ...creature, id: 'reg-local-winner', atk: 500, currentHp: 300, def: 50 };
Engine.attack();
assert.equal(Engine.snapshot().winner, 'p1');
assert.equal(Data.DB.wins, oldWins);
assert.equal(Data.DB.coins, oldCoins);

// All advertised solo game modes create a valid starting hand and 24-card player deck.
for (const mode of ['classic', 'zoeira', 'boss', 'survival', 'draft', 'quick', 'training', 'tournament']) {
  Engine.startGame({ mode, deckId: deck.id });
  const state = Engine.snapshot();
  assert.equal(state.mode, mode);
  assert.equal(state.sides.p1.hand.length, 5);
  assert.equal(state.sides.p1.deck.length + state.sides.p1.hand.length, 24);
}

console.log('FOTO DUEL regression tests: OK (photo metrics, decks, combat, statuses, traps, double strike, revive, local mode and all solo modes)');
