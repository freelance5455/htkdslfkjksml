"""Zoom velké mapy (minimapka, posun, Celá mapa), zoom story mapy, další level po výhře:  python3 -I tests/ui_zoom.py"""
import glob, json
from playwright.sync_api import sync_playwright
exe = (glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome') or [None])[0]
SH = '/home/claude/BubbleDefence/tests/shots/'
errs, results = [], []
def check(n, c, x=''): results.append(bool(c)); print(('OK   ' if c else 'FAIL ') + n + (' ' + str(x) if x != '' else ''))
BIG = {'w': 32, 'h': 28, 'spawns': [{'side': 'L', 'pos': 24, 'len': 4}], 'exit': {'side': 'R', 'pos': 24, 'len': 4},
       'rocks': [], 'walls': [], 'towers': [], 'lives': 99, 'gold': 500, 'waves': 10}
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=exe, args=['--no-sandbox'])
    pg = b.new_page(viewport={'width': 1280, 'height': 800})
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type in ('error', 'warning') and 'willReadFrequently' not in m.text else None)
    pg.goto('file:///home/claude/BubbleDefence/index.html'); pg.wait_for_selector('.content:not(.hidden) .intro')
    pg.click('text=Nová lokální hra'); pg.wait_for_selector('.content:not(.hidden) .menu'); pg.wait_for_timeout(300)
    pg.click('.mi:has-text("Editor")'); pg.click('.lcard.add'); pg.wait_for_selector('.edv .ed-cv'); pg.wait_for_timeout(300)
    pg.evaluate("(L=>{const l=BD.store.profile.editor.levels[0]; Object.assign(l, L); BD.debugEditor.buildMasks(); BD.debugEditor.changed(true);})(%s)" % json.dumps(BIG))
    pg.click('.smap-head .btn.primary'); pg.wait_for_selector('.gv canvas'); pg.wait_for_timeout(600)
    R = lambda js: pg.evaluate("(()=>{const r=BD.debug.renderer; return %s})()" % js)
    check('velká mapa: přiblížení je zapnuté', R('r.big && r.zoomed'), R('[r.fitCell, r.cell]'))
    check('vidím jen část mapy (pohled je menší než mapa)', R('r.VW < r.W || r.VH < r.H'), R('[r.VW, r.VH, r.W, r.H]'))
    check('minimapka a tlačítko Celá mapa jsou vidět', pg.locator('canvas.mini').count() == 1 and pg.locator('[data-act=zoom-out]').count() == 1)
    pg.screenshot(path=SH + 'zoom_big.png')
    # posun tažením
    v0 = R('[r.vx, r.vy]'); cv = pg.locator('.gv canvas:not(.mini)').bounding_box()
    pg.mouse.move(cv['x'] + 300, cv['y'] + 300); pg.mouse.down(); pg.mouse.move(cv['x'] + 200, cv['y'] + 250, steps=5); pg.mouse.up()
    v1 = R('[r.vx, r.vy]')
    check('tažením se mapa posune', v1[0] > v0[0] and v1[1] > v0[1], (v0, v1))
    check('tažení nepostaví věž', pg.evaluate('BD.debug.game.towers.length') == 0)
    # kolečko
    pg.mouse.move(cv['x'] + 300, cv['y'] + 300); pg.mouse.wheel(0, 120); pg.wait_for_timeout(50)
    check('kolečko posouvá mapu', R('r.vy') > v1[1], R('r.vy'))
    # minimapka
    mb = pg.locator('canvas.mini').bounding_box(); pg.mouse.click(mb['x'] + 5, mb['y'] + 5); pg.wait_for_timeout(100)
    check('klik do minimapky přesune pohled do rohu', R('r.vx') < 5 and R('r.vy') < 5, R('[r.vx, r.vy]'))
    # stavba v přiblíženém pohledu trefí správnou buňku
    pg.click('.tw >> nth=0'); cv = pg.locator('.gv canvas:not(.mini)').bounding_box(); c = R('r.cell')
    pg.mouse.click(cv['x'] + (1 + 4 * 2 + 1) * c, cv['y'] + (1 + 3 * 2 + 1) * c); pg.wait_for_timeout(100)
    tw = pg.evaluate('BD.debug.game.towers.map(t=>[t.x,t.y])')
    check('věž se postaví přesně tam, kam kliknu (i při posunu)', tw == [[8, 6]], tw)
    # návrat na celou mapu
    pg.click('[data-act=zoom-out]'); pg.wait_for_timeout(200)
    check('Celá mapa: bez minimapky, celé pole vidět', pg.locator('canvas.mini').count() == 0 and R('r.VW === r.W && r.VH === r.H'), R('[r.VW, r.W]'))
    check('v celé mapě je tlačítko Přiblížit', pg.locator('[data-act=zoom-in]').count() == 1)
    pg.screenshot(path=SH + 'zoom_full.png')
    pg.click('[data-act=zoom-in]'); pg.wait_for_timeout(200)
    check('Přiblížit zase zapne zoom', R('r.zoomed && r.VW < r.W'))
    # malá mapa zoom nemá
    b.close()

    # ---- story mapa: zoom a minimapka ----
    b = p.chromium.launch(executable_path=exe, args=['--no-sandbox'])
    pg = b.new_page(viewport={'width': 1280, 'height': 800})
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('file:///home/claude/BubbleDefence/index.html'); pg.wait_for_selector('.content:not(.hidden) .intro')
    pg.click('text=Nová lokální hra'); pg.wait_for_selector('.content:not(.hidden) .menu'); pg.wait_for_timeout(300)
    pg.click('.mi:has-text("Story mód")'); pg.click('.ms:has-text("Nová hra")'); pg.wait_for_selector('.content:not(.hidden) .smap', timeout=8000); pg.wait_for_timeout(300)
    vb0 = pg.get_attribute('.smap-svg', 'viewBox')
    check('story mapa: na začátku celá mapa bez minimapky', vb0.startswith('0 0 1000') and pg.locator('.smap .mini').count() == 0, vb0)
    check('story mapa: malý strom nemá tlačítka zoomu', pg.locator('.smap .zoomui').count() == 0)
    box0 = pg.locator('.smap-body').bounding_box(); pg.mouse.move(box0['x'] + 400, box0['y'] + 300); pg.mouse.wheel(0, -300); pg.wait_for_timeout(100)
    check('story mapa: malý strom kolečkem nejde přiblížit', pg.get_attribute('.smap-svg', 'viewBox').startswith('0 0 1000'), pg.get_attribute('.smap-svg', 'viewBox'))
    pg.evaluate("BD.store.profile.story.completed.push('t1','l2','a1','b1','c1','a2','b2','c2')"); pg.wait_for_timeout(200)
    check('story mapa: velký strom (odkryté větve) zoom nabídne', pg.locator('.smap .zoomui').count() == 1 and pg.locator('[data-act=zin]').count() == 1)
    pg.click('[data-act=zin]'); pg.click('[data-act=zin]'); pg.wait_for_timeout(100)
    vb1 = [float(x) for x in pg.get_attribute('.smap-svg', 'viewBox').split()]
    check('story mapa: po přiblížení je výřez menší a minimapka je vidět', vb1[2] < 600 and pg.locator('.smap .mini').count() == 1, vb1)
    box = pg.locator('.smap-body').bounding_box()
    pg.mouse.move(box['x'] + 400, box['y'] + 300); pg.mouse.down(); pg.mouse.move(box['x'] + 300, box['y'] + 300, steps=6); pg.mouse.up()
    vb2 = [float(x) for x in pg.get_attribute('.smap-svg', 'viewBox').split()]
    check('story mapa: tažením se posune', vb2[0] != vb1[0] or vb2[1] != vb1[1], (vb1[:2], vb2[:2]))
    pg.mouse.move(box['x'] + 400, box['y'] + 300); pg.mouse.wheel(0, -200); pg.wait_for_timeout(100)
    vb3 = [float(x) for x in pg.get_attribute('.smap-svg', 'viewBox').split()]
    check('story mapa: kolečko přibližuje', vb3[2] < vb2[2], (vb2[2], vb3[2]))
    pg.screenshot(path=SH + 'zoom_story.png')
    pg.click('[data-act=zfull]'); pg.wait_for_timeout(100)
    check('story mapa: Celá mapa vrátí pohled', pg.get_attribute('.smap-svg', 'viewBox').startswith('0 0 1000') and pg.locator('.smap .mini').count() == 0)

    pg.evaluate("BD.store.profile.story.completed.splice(0)"); pg.wait_for_timeout(200)
    check('story mapa: po návratu na malý strom zoom zmizí', pg.locator('.smap .zoomui').count() == 0)

    # ---- po výhře: další level podle cesty ----
    pg.click('[data-act=zfull]') if pg.locator('[data-act=zfull]').count() else None
    pg.click('.node.open .dot'); pg.wait_for_selector('.content:not(.hidden) .gv', timeout=8000); pg.wait_for_timeout(300)
    pg.evaluate("(()=>{const g=BD.debug.game; g.lives=99; g.wave=g.maxWaves-1; g.streams=[]; g.waveLeft={}; g.enemies=[]; g.startWave(); for(let i=0;i<20000&&!g.won&&!g.gameOver;i++) g.step(1/30);})()")
    pg.wait_for_timeout(500)
    check('tutoriál: po výhře je tlačítko Další level', pg.locator('[data-act=next-level]').count() == 1, pg.locator('.over .btn').all_inner_texts())
    pg.click('[data-act=next-level]'); pg.wait_for_selector('.content:not(.hidden) .gv', timeout=8000); pg.wait_for_timeout(400)
    check('Další level otevře level Základy (l2) rovnou ve hře', pg.evaluate('BD.debug.session.nodeId') == 'l2', pg.evaluate('BD.debug.session.nodeId'))
    pg.evaluate("(()=>{const g=BD.debug.game; g.lives=99; g.wave=g.maxWaves-1; g.streams=[]; g.waveLeft={}; g.enemies=[]; g.startWave(); for(let i=0;i<20000&&!g.won&&!g.gameOver;i++) g.step(1/30);})()")
    pg.wait_for_timeout(500)
    pg.click('[data-act=next-level]'); pg.wait_for_selector('.content:not(.hidden) .gv', timeout=8000); pg.wait_for_timeout(400)
    check('na rozcestí se vybere některá z větví', pg.evaluate('BD.debug.session.nodeId') in ('a1', 'b1', 'c1'), pg.evaluate('BD.debug.session.nodeId'))
    b.close()
print('\nvýsledek: %d/%d' % (sum(results), len(results)), '| chyby:', errs or 'žádné')
