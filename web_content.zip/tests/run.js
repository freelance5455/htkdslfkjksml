// Tests sans dépendance : node tests/run.js
const fs = require('fs'), path = require('path'), vm = require('vm');
const root = path.join(__dirname, '..');
let fail = 0;
const ok = (c, m) => { console.log((c ? 'OK    ' : 'ÉCHEC ') + m); if (!c) fail++; };
const read = f => fs.readFileSync(path.join(root, f), 'utf8');

// 1. Traductions : mêmes clés dans les 3 langues, aucune valeur vide
const win = { LOCALES: {} };
for (const l of ['ar', 'fr', 'en']) vm.runInNewContext(read(`locales/${l}.js`), { window: win });
const ref = Object.keys(win.LOCALES.en).sort();
for (const l of ['ar', 'fr']) {
  const k = Object.keys(win.LOCALES[l]).sort();
  ok(JSON.stringify(k) === JSON.stringify(ref), `locales/${l}.js : mêmes clés que en`);
}
ok(Object.values(win.LOCALES).every(o => Object.values(o).every(v => String(v).trim())), 'traductions non vides');

// 2. Syntaxe JS + fichiers référencés par index.html
for (const f of ['app', 'extra', 'indicators']) { try { new vm.Script(read(`assets/js/${f}.js`)); ok(true, f + '.js : syntaxe valide'); } catch (e) { ok(false, f + '.js : ' + e.message); } }
const Ind = require('../assets/js/indicators.js');
const up = Array.from({ length: 60 }, (_, i) => i + 1);
ok(Ind.sma([...Array(20).keys()].map(x => x + 1), 20) === 10.5, 'SMA(1..20) = 10.5');
ok(Ind.rsi(up) === 100, 'RSI série haussière = 100');
ok(Ind.rsi(up.slice().reverse()) < 1, 'RSI série baissière proche de 0');
ok(Ind.summary(up.map(x => ({ h: x + 1, l: x - 1, c: x }))).trend === 'up', 'tendance haussière détectée');
ok(Ind.rsi([1, 2, 3]) === null, 'RSI sans assez de données = null');
const html = read('index.html');
const refs = [...html.matchAll(/(?:src|href)="([^"#]+)"/g)].map(m => m[1]).filter(x => !/^https?:/.test(x));
refs.forEach(r => ok(fs.existsSync(path.join(root, r)), 'fichier référencé présent : ' + r));
ok(/<html[^>]*dir="rtl"/.test(html), 'RTL par défaut (arabe)');
ok(html.includes('By Bilel Fridhi'), 'signature présente');

// 3. Aucun secret dans le dépôt
const bad = /(-----BEGIN [A-Z ]*PRIVATE KEY|AKIA[0-9A-Z]{16}|service_role|sk_live_)/i;
const skip = ['node_modules', '.git', 'www', 'android'];
const walk = d => fs.readdirSync(d, { withFileTypes: true }).flatMap(e => skip.includes(e.name) ? [] : e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]);
const hits = walk(root).filter(f => /\.(js|json|html|css|md|yml)$/.test(f) && !f.endsWith('run.js') && bad.test(fs.readFileSync(f, 'utf8')));
ok(!hits.length, 'aucun secret détecté' + (hits.length ? ' : ' + hits.join(', ') : ''));

console.log(fail ? `\n${fail} test(s) en échec` : '\nTous les tests passent');
process.exit(fail ? 1 : 0);
