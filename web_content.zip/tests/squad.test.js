import test from 'node:test';
import assert from 'node:assert/strict';
import { buildSquad, renderSquadHtml, formLabel, moraleLabel } from '../src/squad.js';

const state = {
  userClubId: 'a',
  management: { relations: { playerMorale: { p1: 72 } } },
  divisions: [{ clubs: [{ id: 'a', name: 'Orion Dames', damistes: [
    { id: 'p1', name: 'K. Zorin', level: 70, form: 80, age: 24, potential: 78, specialty: 'défense' },
    { id: 'p2', name: 'M. Ielo', level: 82, form: 55, age: 21, potential: 90 }
  ] }] }]
};

test('l’effectif est trié par niveau et lit le moral réel (50 par défaut)', () => {
  const squad = buildSquad(state);
  assert.equal(squad.clubName, 'Orion Dames');
  assert.deepEqual(squad.rows.map(r => r.id), ['p2', 'p1']);
  assert.equal(squad.rows[1].moraleLabel, 'Excellent');
  assert.equal(squad.rows[0].moraleLabel, 'Correct');
  assert.equal(squad.rows[0].formLabel, 'Basse');
});

test('les libellés et le rendu restent sûrs sans club', () => {
  assert.equal(formLabel(75), 'Haute');
  assert.equal(moraleLabel(39), 'Bas');
  assert.match(renderSquadHtml(buildSquad({ divisions: [] })), /Aucun club/);
  assert.match(renderSquadHtml(buildSquad(state)), /M\. Ielo/);
});
