import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const T = require('../src/selftest.js');
const t0 = Date.now();
const res = await T.runAll();
let bad = 0, total = 0;
for (const r of res) {
  console.log(`${r.ok ? 'PASS' : 'FAIL'}  ${r.id.padEnd(13)} ${r.checks.filter(c => c.ok).length}/${r.checks.length}  ${r.ms}ms`);
  for (const c of r.checks) { total++; if (!c.ok) { bad++; console.log('   ✗', c.name, c.detail || ''); } }
}
console.log(`\n${total - bad}/${total} checks passed in ${Date.now() - t0}ms`);
process.exit(bad ? 1 : 0);
