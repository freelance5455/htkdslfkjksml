import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState } from '../src/store.js';
import { createManagerProfile, generateJobMarket, applyForJob, processJobApplications, acceptJobAppointment } from '../src/career.js';

function unemployed(score = 50) {
  const state = createInitialState();
  const profile = createManagerProfile({ firstName: 'Mina', lastName: 'Traore', galaxy: state.world.galaxies[0].name, mode: 'unemployed', sex: 'Femme', reputation: score >= 75 ? 'Mondiale' : score >= 50 ? 'Continentale' : score >= 25 ? 'Locale' : 'Inconnu' }, state);
  profile.reputationScore = score;
  state.career.manager.reputationScore = score;
  return state;
}

test('le marché de l’emploi propose des postes selon la réputation et évite les doublons', () => {
  const state = unemployed(50);
  const first = generateJobMarket(state);
  const second = generateJobMarket(state);
  assert.ok(first.length > 0 && first.length <= 5);
  assert.equal(second.length, 0);
  assert.ok(first.every(offer => offer.minimumReputation <= 50));
});

test('candidature, réponse du club et acceptation du poste rattachent le manager au club', () => {
  const state = unemployed(100);
  const [offer] = generateJobMarket(state);
  const application = applyForJob(state, offer.id);
  assert.equal(application.status, 'pending');
  const processed = processJobApplications(state);
  assert.equal(processed[0].status, 'offered');
  const accepted = acceptJobAppointment(state, application.id);
  assert.equal(accepted.status, 'accepted');
  assert.equal(state.userClubId, offer.clubId);
  assert.equal(state.career.manager.clubId, offer.clubId);
  assert.equal(state.career.mode, 'club');
});

test('un manager déjà en poste ne peut pas postuler à un emploi concurrent', () => {
  const state = createInitialState();
  createManagerProfile({ firstName: 'M', lastName: 'N', galaxy: state.world.galaxies[0].name, mode: 'club', sex: 'Homme', clubId: state.divisions[0].clubs[0].id }, state);
  assert.deepEqual(generateJobMarket(state), []);
});
