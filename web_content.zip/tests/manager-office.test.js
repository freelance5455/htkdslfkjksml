import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState } from '../src/store.js';
import { createManagerProfile } from '../src/career.js';
import { ensureClubOffice, advanceManagerOneDay, updateDelegation, updateFacility, submitBoardRequest, updateBoardDomain, validateClubOffice } from '../src/manager-office.js';

function stateWithManager(){
  const state=createInitialState();
  createManagerProfile({firstName:'Awa',lastName:'Diallo',galaxy:state.world.galaxies[0].name,mode:'club',sex:'Femme',reputation:'Inconnu',clubId:state.divisions[0].clubs[0].id},state);
  return state;
}

test('initialise finances, installations, staff, délégations et objectifs du conseil',()=>{
  const state=stateWithManager(),office=ensureClubOffice(state).office;
  assert.equal(office.staff.length,5);
  assert.equal(Object.keys(office.delegation).length,3);
  assert.equal(office.board.domains.Matchs,50);
  assert.equal(office.facilities.arenaCapacity,5000);
  assert.equal(validateClubOffice(state),true);
});

test('avance le calendrier d’un seul jour et comptabilise les recettes et charges paramétrées',()=>{
  const state=stateWithManager(),office=ensureClubOffice(state).office;
  office.finance.dailyIncome=1000;office.finance.dailyCosts=250;
  const before=office.finance.cash;
  const result=advanceManagerOneDay(state);
  assert.equal(result.day,2);
  assert.equal(office.finance.cash,before+750);
  assert.equal(office.finance.ledger[0].net,750);
  assert.equal(state.calendar.currentDay,2);
});

test('enregistre délégations et amélioration des installations sans dépasser les niveaux',()=>{
  const state=stateWithManager();
  assert.equal(updateDelegation(state,'match-preparation',true),true);
  assert.equal(updateFacility(state,'training',20),10);
  assert.equal(ensureClubOffice(state).office.facilities.training,10);
});

test('enregistre les demandes au conseil et recalcule sa confiance par domaine',()=>{
  const state=stateWithManager();
  const req=submitBoardRequest(state,'arena-expansion','Augmenter la capacité');
  assert.equal(req.status,'submitted');
  const confidence=updateBoardDomain(state,'Finances',20,'Gestion saine');
  assert.equal(confidence,53);
  assert.equal(state.management.relations.boardConfidence,53);
});

test('un manager sans emploi ne reçoit pas une administration de club fictive',()=>{
  const state=createInitialState();
  createManagerProfile({firstName:'Awa',lastName:'Diallo',galaxy:state.world.galaxies[0].name,mode:'unemployed',sex:'Femme',reputation:'Inconnu'},state);
  assert.equal(ensureClubOffice(state),null);
});

test('les décisions du conseil sont historisées et ne peuvent pas être répétées', async () => {
  const { resolveBoardRequest } = await import('../src/manager-office.js');
  const state = stateWithManager();
  const request = submitBoardRequest(state, 'wage-budget', 'Renforcer le recrutement');
  const resolved = resolveBoardRequest(state, request.id, 'approved', 'Accord de principe');
  assert.equal(resolved.status, 'approved');
  assert.equal(resolved.decisionDetails, 'Accord de principe');
  assert.throws(() => resolveBoardRequest(state, request.id, 'rejected'));
});

test('le profil du staff est modifiable avec contrôle des champs', async () => {
  const { updateStaffMember } = await import('../src/manager-office.js');
  const state = stateWithManager();
  const updated = updateStaffMember(state, 'assistant', { name: 'Nadia K.', profile: 'Spécialiste tactique', rating: 78 });
  assert.equal(updated.name, 'Nadia K.');
  assert.equal(updated.rating, 78);
  assert.throws(() => updateStaffMember(state, 'assistant', { rating: 101 }));
});

test('le conseil traite automatiquement les demandes à la journée suivante', async () => {
  const { processBoardRequests } = await import('../src/manager-office.js');
  const state = stateWithManager();
  const request = submitBoardRequest(state, 'training-facility', 'Améliorer le centre');
  const result = processBoardRequests(state);
  assert.equal(result.length, 1);
  assert.equal(result[0].id, request.id);
  assert.equal(result[0].status, 'approved');
  assert.equal(processBoardRequests(state).length, 0);
});

test('une démission approuvée par le conseil libère le manager et conserve son historique', async () => {
  const { processBoardRequests } = await import('../src/manager-office.js');
  const state = stateWithManager();
  const formerClub = state.userClubId;
  submitBoardRequest(state, 'resignation', 'Fin de mission');
  const results = processBoardRequests(state);
  assert.equal(results[0].status, 'approved');
  assert.equal(state.userClubId, null);
  assert.equal(state.career.mode, 'unemployed');
  assert.equal(state.career.manager.clubId, null);
  assert.equal(state.career.history[0].clubId, formerClub);
});
