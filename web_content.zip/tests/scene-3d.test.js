import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const scene = await readFile(new URL('../src/scene-3d.js', import.meta.url), 'utf8');
const match = await readFile(new URL('../src/match-ui.js', import.meta.url), 'utf8');
const app = await readFile(new URL('../src/app.js', import.meta.url), 'utf8');
const html = await readFile(new URL('../index.html', import.meta.url), 'utf8');

test('le moteur 3D utilise réellement WebGL et des shaders', () => {
  assert.match(scene, /getContext\('webgl'/);
  assert.match(scene, /createShader\(type\)/);
  assert.match(scene, /gl\.drawArrays\(gl\.TRIANGLES/);
  assert.match(scene, /mat4\.perspective/);
});
test('la scène construit un plateau 3D et des pièces en volume', () => {
  assert.match(scene, /function addCylinder/);
  assert.match(scene, /function addBoxTop/);
  assert.match(scene, /Math\.abs\(piece\)===2/);
  assert.match(scene, /function buildScene/);
});
test('la vue 3D conserve les interactions et le moteur de règles existants', () => {
  assert.match(match, /legalMoves\(board,1/);
  assert.match(match, /applyMove\(board,move/);
  assert.match(match, /scene3d\.draw\(board,selected,targetsNow,true\)/);
  assert.match(match, /cell\.addEventListener\('click'/);
});
test('la vue 3D est activable depuis l’interface et dispose d’un repli WebGL indisponible', () => {
  assert.match(app, /matchController\.toggle3D/);
  assert.match(match, /ne prend pas en charge WebGL/);
  assert.match(html, /id="toggle3dView"/);
  assert.match(html, /cgd-3d-canvas/);
});
