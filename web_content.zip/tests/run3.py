import sys, time, subprocess, json, os
from playwright.sync_api import sync_playwright
sys.path.insert(0,'/tmp/t'); import mock
R=[]
def ok(n,c,e=''):
    R.append((n,bool(c),e)); print(('PASS ' if c else 'FAIL ')+n, e, flush=True)
def tab(page,t): page.click(f'#tabs button[data-t={t}]')
with sync_playwright() as p:
    b = p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
    ctx = b.new_context(viewport={'width':420,'height':900}, accept_downloads=True)
    page = ctx.new_page(); errs=[]
    page.on('pageerror', lambda e: errs.append(str(e)))
    calls = mock.install(page)
    page.goto('http://localhost:8099/index.html')
    page.wait_for_function("document.querySelector('#surah').options.length>0", timeout=15000)
    page.select_option('#surah','112'); page.wait_for_function("window.__qvm.S.ayat.length==4")
    page.select_option('#to','2'); page.wait_for_function("window.__qvm.S.ayat.length==2")
    # backgrounds: local video + image + gold, shuffle on
    tab(page,'bg'); page.set_input_files('#bgFiles',['/tmp/t/vid10.webm','/tmp/t/img.png'])
    page.wait_for_function("window.__qvm.S.lib.length==6", timeout=10000)
    ok('3 bgs selected', page.evaluate("window.__qvm.S.selected.size")==3)
    # style: gold allah, glow, both translations
    tab(page,'style'); page.click('#tr button[data-v=both]')
    tab(page,'exp'); page.select_option('#preset','0'); page.select_option('#quality','2')
    ok('format picked', page.evaluate("window.__qvm.pickMime()"), str(page.evaluate("window.__qvm.pickMime()")))
    t0=time.time()
    page.click('#exp')
    page.wait_for_function("document.querySelector('#prog').value>0.3", timeout=20000)
    ok('progress is real (value moves 0..1)', True, str(page.evaluate("document.querySelector('#prog').value")))
    page.wait_for_function("document.querySelector('#result').style.display==='flex'", timeout=60000)
    el=time.time()-t0
    ok('export finished in ~real time (6s audio)', 5<el<30, f'{el:.1f}s')
    with page.expect_download() as d: page.click('#dl')
    out='/tmp/t/out_export.'+d.value.suggested_filename.split('.')[-1]; d.value.save_as(out)
    print('FILE', out, os.path.getsize(out), d.value.suggested_filename)
    ok('exp message ok', 'تم' in page.inner_text('#expMsg'), page.inner_text('#expMsg'))
    ok('export button re-enabled, cancel hidden', (not page.is_disabled('#exp')) and (not page.is_visible('#cancel')))
    pr=subprocess.run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',out],capture_output=True,text=True)
    info=json.loads(pr.stdout or '{}'); st=info.get('streams',[])
    v=[s for s in st if s['codec_type']=='video']; a=[s for s in st if s['codec_type']=='audio']
    ok('output has video stream', len(v)==1, str([(s['codec_name'],s['width'],s['height']) for s in v]))
    ok('output has audio stream', len(a)==1, str([(s['codec_name']) for s in a]))
    ok('resolution 540x960', v and (v[0]['width'],v[0]['height'])==(540,960))
    dur=subprocess.run(['ffmpeg','-v','info','-i',out,'-f','null','-'],capture_output=True,text=True).stderr
    import re
    m=re.findall(r'time=(\d+):(\d+):([\d.]+)',dur); secs=int(m[-1][0])*3600+int(m[-1][1])*60+float(m[-1][2]) if m else 0
    ok('decoded duration ≈ 6s (5.3-7.5)', 5.3<secs<7.5, f'{secs:.2f}s')
    # audio has signal (sine) and not silent
    vol=subprocess.run(['ffmpeg','-i',out,'-af','volumedetect','-vn','-f','null','-'],capture_output=True,text=True).stderr
    mm=re.search(r'mean_volume: (-?[\d.]+) dB',vol); ok('audio not silent', mm and float(mm.group(1))>-40, mm.group(0) if mm else vol[-200:])
    for i,t in enumerate([0.4,1.5,2.8,4.2,5.5]):
        subprocess.run(['ffmpeg','-y','-v','error','-ss',str(t),'-i',out,'-frames:v','1',f'/tmp/t/f{i}.png'])
    print('frames written')
    # frame content differs over time (highlight progression/bg)
    from hashlib import md5
    hs=[md5(open(f'/tmp/t/f{i}.png','rb').read()).hexdigest() for i in range(5)]
    ok('frames differ over time', len(set(hs))>=4, str(len(set(hs))))
    # cancel test
    page.click('#exp'); page.wait_for_function("document.querySelector('#prog').value>0.1", timeout=15000)
    page.click('#cancel'); page.wait_for_function("document.querySelector('#exp').disabled===false", timeout=15000)
    ok('cancel works and says cancelled', 'إلغاء' in page.inner_text('#expMsg'), page.inner_text('#expMsg'))
    ok('no result link after cancel', not page.is_visible('#result'))
    # state recovers: play works after export
    tab(page,'text'); page.click('#play'); time.sleep(0.8)
    ok('preview still plays after export', 'إيقاف' in page.inner_text('#play'))
    page.click('#play')
    print('ERRS', errs)
    print('LOG TAIL', page.input_value('#log')[-400:])
    print('SUMMARY', sum(1 for r in R if r[1]), '/', len(R))
    b.close()
