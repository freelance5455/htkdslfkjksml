import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState } from '../src/store.js';
import { getCareerSelectionCatalog, validateCareerSelection } from '../src/career-selection.js';

test('5.0-D référence exactement 24 galaxies et 60 emplacements de clubs', () => {
  const catalog = getCareerSelectionCatalog(createInitialState());
  assert.equal(catalog.galaxies.length, 24);
  assert.equal(catalog.clubs.length, 60);
  assert.equal(catalog.counts.availableClubs, 36);
  assert.equal(catalog.counts.lockedClubs, 24);
});

test('les 24 emplacements futurs restent verrouillés jusqu’à activation réelle', () => {
  const state = createInitialState();
  const catalog = getCareerSelectionCatalog(state);
  const ligueC = catalog.clubs.filter(club => club.divisionId === 'ligue-c');
  const ligueD = catalog.clubs.filter(club => club.divisionId === 'ligue-d');
  assert.equal(ligueC.length, 12);
  assert.equal(ligueD.length, 12);
  assert.ok(ligueC.every(club => club.locked && club.unlockSeason === 3));
  assert.ok(ligueD.every(club => club.locked && club.unlockSeason === 5));
  assert.throws(() => validateCareerSelection(state, { galaxyId: 'galaxy-01', clubId: ligueC[0].id, mode: 'club' }), /verrouillé/);
});

test('sélection d’une galaxie et d’un club actif acceptée ; mode sans emploi sans club', () => {
  const state = createInitialState();
  const catalog = getCareerSelectionCatalog(state);
  const selected = validateCareerSelection(state, { galaxyId: 'galaxy-01', clubId: catalog.clubs[0].id, mode: 'club' });
  assert.equal(selected.galaxy.name, state.world.galaxies[0].name);
  assert.equal(selected.club.id, state.divisions[0].clubs[0].id);
  const unemployed = validateCareerSelection(state, { galaxyId: 'galaxy-24', clubId: '', mode: 'unemployed' });
  assert.equal(unemployed.club, null);
});

test('les clubs des divisions C/D deviennent sélectionnables seulement quand la division est active et possède ses clubs', () => {
  const state = createInitialState();
  const division = state.divisions.find(item => item.id === 'ligue-c');
  division.status = 'active';
  division.clubs = Array.from({ length: 12 }, (_, index) => ({ id: `future-c-${index + 1}`, name: `Club futur ${index + 1}`, damistes: [{ id: 'a' }, { id: 'b' }] }));
  const catalog = getCareerSelectionCatalog(state);
  assert.equal(catalog.clubs.filter(club => club.divisionId === 'ligue-c' && club.available).length, 12);
});
