import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState } from '../src/store.js';
import { createManagerProfile } from '../src/career.js';
import { takeManagerOffice, getManagerDashboard } from '../src/manager-dashboard.js';

function createClubCareer() {
  const state = createInitialState();
  createManagerProfile({ firstName: 'Amina', lastName: 'Diallo', galaxy: state.world.galaxies[0].name, mode: 'club', clubId: state.divisions[0].clubs[0].id, sex: 'Femme' }, state);
  return state;
}

test('5.0-E officialise la prise de fonction et active le bureau du manager', () => {
  const state = createClubCareer();
  const result = takeManagerOffice(state);
  assert.equal(result.appointed, true);
  assert.equal(result.club.manager, 'Amina Diallo');
  assert.equal(state.career.officeActivated, true);
  assert.equal(state.career.appointedAt.clubId, state.userClubId);
  assert.equal(state.career.history.filter(item => item.type === 'appointment').length, 1);
});

test('la prise de fonction est idempotente et ne duplique pas l’historique', () => {
  const state = createClubCareer();
  takeManagerOffice(state);
  takeManagerOffice(state);
  assert.equal(state.career.history.filter(item => item.type === 'appointment').length, 1);
});

test('un manager sans emploi ne reçoit pas de club par erreur', () => {
  const state = createInitialState();
  createManagerProfile({ firstName: 'Amina', lastName: 'Diallo', galaxy: state.world.galaxies[0].name, mode: 'unemployed', clubId: '', sex: 'Femme' }, state);
  const result = takeManagerOffice(state);
  assert.equal(result.appointed, false);
  assert.equal(state.userClubId, null);
});

test('le tableau de bord expose finances, effectif, calendrier et alertes du club', () => {
  const state = createClubCareer();
  takeManagerOffice(state);
  const club = state.divisions[0].clubs[0];
  state.calendar.fixtures.push({ id: 'test-next', home: club.id, away: 'opponent', status: 'scheduled', round: 2 });
  state.management.inbox.push({ id: 'msg-1', status: 'unread' });
  const dashboard = getManagerDashboard(state);
  assert.equal(dashboard.club.id, club.id);
  assert.equal(dashboard.playerCount, 2);
  assert.equal(dashboard.upcoming[0].id, 'test-next');
  assert.equal(dashboard.unread, 1);
  assert.ok(Number.isFinite(dashboard.finance.cash));
});

test('le tableau de bord reste disponible pour une carrière sans emploi', () => {
  const state = createInitialState();
  createManagerProfile({ firstName: 'Amina', lastName: 'Diallo', galaxy: state.world.galaxies[0].name, mode: 'unemployed', clubId: '', sex: 'Femme' }, state);
  const dashboard = getManagerDashboard(state);
  assert.equal(dashboard.club, null);
  assert.equal(dashboard.gate, 'Sans emploi');
});
