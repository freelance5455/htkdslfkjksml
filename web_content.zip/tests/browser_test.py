from playwright.sync_api import sync_playwright
import os
URL = "http://127.0.0.1:4173"
with sync_playwright() as p:
    kwargs = {"headless": True, "args": ["--autoplay-policy=no-user-gesture-required"]}
    if os.getenv("CHROMIUM_PATH"):
        kwargs["executable_path"] = os.environ["CHROMIUM_PATH"]
    b = p.chromium.launch(**kwargs)
    page = b.new_page()
    page.add_init_script(r"""
window.__calls=[]; window.__playCount=0;
window.__PIPER_TEST_API__={predict:async o=>{window.__calls.push(o);let b=Uint8Array.from(atob('UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA='),c=>c.charCodeAt(0));return new Blob([b],{type:'audio/wav'})}};
HTMLMediaElement.prototype.play=function(){this._paused=false;window.__playCount++;return Promise.resolve()};
HTMLMediaElement.prototype.pause=function(){this._paused=true};
Object.defineProperty(HTMLMediaElement.prototype,'paused',{get(){return this._paused!==false}});
""")
    page.goto(URL)
    page.fill("#text", "Erster Testsatz. " + ("Langer Testinhalt. " * 80))
    page.select_option("#voice", "piper:de_DE-thorsten-medium")
    page.click("#start")
    page.wait_for_function("window.__calls.length >= 1")
    page.click("#pause")
    assert "Pausiert" in page.locator("#status").inner_text() or "pausiert" in page.locator("#status").inner_text().lower()
    page.click("#pause")
    page.evaluate("document.querySelector('#audio').onended()")
    page.wait_for_function("window.__calls.length >= 2")
    assert page.evaluate("__calls.every(x=>x.voiceId==='de_DE-thorsten-medium')")
    assert page.evaluate("__playCount >= 2")
    page.click("#stop")
    assert page.locator("#start").is_enabled()
    print("PASS multi-chunk piper flow")
    b.close()
