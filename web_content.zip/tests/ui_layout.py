"""Rozložení hry: nastavení v popupu, upgrady v levém sloupci, pás (čísla, rámeček, plynulé přivolání):  python3 -I tests/ui_layout.py"""
import glob, json
from playwright.sync_api import sync_playwright
exe = (glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome') or [None])[0]
SH = '/home/claude/BubbleDefence/tests/shots/'
errs, results = [], []
def check(n, c, x=''): results.append(bool(c)); print(('OK   ' if c else 'FAIL ') + n + (' ' + str(x) if x != '' else ''))
LEVEL = {'w': 12, 'h': 10, 'spawns': [{'side': 'L', 'pos': 8, 'len': 4}], 'exit': {'orb': [[19, 9], [20, 9], [19, 10], [20, 10]]},
         'rocks': [[10, 4, 1], [11, 4, 1], [10, 5, 1], [11, 5, 1]], 'walls': [[14, y] for y in range(0, 10)] + [[14, y] for y in range(12, 20)],
         'towers': [{'type': 'normal', 'x': 4, 'y': 4}], 'lives': 999, 'gold': 321, 'waves': 10, 'hp': 2, 'allowed': ['normal', 'ghost']}
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=exe, args=['--no-sandbox'])
LEVEL['waves'] = 12; LEVEL['gap'] = 20
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=exe, args=['--no-sandbox'])
    pg = b.new_page(viewport={'width': 1280, 'height': 800})
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type in ('error', 'warning') and 'willReadFrequently' not in m.text else None)
    pg.goto('file:///home/claude/BubbleDefence/index.html'); pg.wait_for_selector('.content:not(.hidden) .intro')
    pg.click('text=Nová lokální hra'); pg.wait_for_selector('.content:not(.hidden) .menu'); pg.wait_for_timeout(300)
    pg.click('.mi:has-text("Editor")'); pg.click('.lcard.add'); pg.wait_for_selector('.edv .ed-cv'); pg.wait_for_timeout(300)
    pg.evaluate("(L=>{const l=BD.store.profile.editor.levels[0]; Object.assign(l, L); BD.debugEditor.buildMasks(); BD.debugEditor.changed(true);})(%s)" % json.dumps(LEVEL))
    pg.click('.smap-head .btn.primary'); pg.wait_for_selector('.gv canvas'); pg.wait_for_timeout(500)
    G = lambda js: pg.evaluate("(()=>{const g=BD.debug.game; return %s})()" % js)
    check('levý sloupec už neobsahuje Zobrazení', pg.locator('.col.l:has-text("Zobrazení")').count() == 0 and pg.locator('.col.r').count() == 0)
    check('karta základny ukazuje tři skutečná čísla', pg.locator('.tw .ts span').count() == 3 and '–' not in pg.locator('.tw .ts').inner_text(), pg.locator('.tw .ts').inner_text().replace('\n', ' '))
    cb = pg.locator('.gv canvas').bounding_box(); bb0 = pg.locator('.belt').bounding_box()
    pl = pg.locator('.play').bounding_box(); lc = pg.locator('.col.l').bounding_box()
    check('pás je pravý sloupec: dosahuje k pravému okraji, bez mezery', abs((bb0['x'] + bb0['width']) - (pl['x'] + pl['width'])) < 3 and abs(bb0['height'] - pl['height']) < 3, (bb0, pl))
    check('pás je stejně široký jako levý sloupec', abs(bb0['width'] - lc['width']) < 6, (bb0['width'], lc['width']))
    check('pole je mezi levým sloupcem a pásem', cb['x'] >= pl['x'] and cb['x'] + cb['width'] <= bb0['x'] + 1, (cb, bb0))
    check('rámeček pásu je vidět', pg.locator('.belt-slot').bounding_box()['height'] > 40)
    # popup nastavení z Menu
    pg.click('.bar .btn:has-text("Menu")'); pg.click('.pbox .btn:has-text("Nastavení")'); pg.wait_for_timeout(300)
    check('popup nastavení se zobrazí', pg.locator('.pbox.wide .settings').count() == 1)
    pg.screenshot(path=SH + 'popup_settings.png')
    r0 = pg.evaluate("BD.store.profile.settings.showRange")
    pg.click('.pbox.wide label.tog:has-text("Zobrazit dosah věží")'); pg.wait_for_timeout(100)
    check('přepínač v popupu mění globální nastavení', pg.evaluate("BD.store.profile.settings.showRange") == (not r0))
    pg.click('[data-act=close-settings]'); pg.click('.pbox .btn:has-text("Pokračovat")'); pg.wait_for_timeout(200)
    check('popup se zavře a hra pokračuje', pg.locator('.pbox').count() == 0)
    # věž a upgrady vlevo
    pg.evaluate("(()=>{const g=BD.debug.game; g.gold=5000; g.place('base',8,2); BD.debug.tap({cell:[8,2],pos:[8,2]});})()"); pg.wait_for_timeout(300)
    check('vybraná věž a její upgrady jsou v levém sloupci', pg.locator('.col.l .selbox .card').count() == 1 and pg.locator('.col.l .btn.choice').count() >= 1)
    pg.click('.col.l .btn.choice >> nth=0'); pg.wait_for_timeout(200)
    check('upgrade z levého sloupce funguje', G('g.towers.filter(t=>t.type!=="base").length') >= 1)
    pg.screenshot(path=SH + 'left_upgrades.png')
    # pás: jen číslo
    txt = pg.locator('.belt .blk .bw').first.inner_text().strip()
    check('blok ukazuje jen číslo vlny', txt.isdigit(), txt)
    check('nahoře je rámeček', pg.locator('.belt-slot').count() == 1)
    pg.click('.bar .btn.primary:has-text("Start")'); pg.wait_for_timeout(300)
    pg.evaluate("(()=>{const g=BD.debug.game; for(let i=0;i<30*10;i++) g.step(1/30);})()"); pg.wait_for_timeout(300)
    # přivolání 4 vln: žádný blok neskáče víc než ~12 % za 150 ms
    pg.locator('.belt .blk:not(.bl-leave-active)').nth(3).evaluate('e=>e.click()')
    pg.evaluate("window.__dn=0; window.__pv={}; (function f(){document.querySelectorAll('.belt .blk').forEach(e=>{const k=e.querySelector('.bw').textContent, y=e.getBoundingClientRect().top; if(window.__pv[k]!==undefined && y-window.__pv[k]>3) window.__dn++; window.__pv[k]=y}); requestAnimationFrame(f)})()")
    prev = None; maxjump = 0; import time; tp = time.time()
    for i in range(14):
        cur = pg.evaluate("Object.fromEntries([...document.querySelectorAll('.belt .blk')].map(e=>[e.querySelector('.bw').textContent, e.getBoundingClientRect().top]))")
        tn = time.time()
        if prev:
            for k, y in cur.items():
                if k in prev: maxjump = max(maxjump, abs(y - prev[k]) / max(tn - tp, .01))
        prev = cur; tp = tn; pg.wait_for_timeout(150)
        if i == 4: pg.screenshot(path=SH + 'belt_call.png')
    check('při přivolání žádný blok nejede dolů', pg.evaluate('window.__dn') == 0, pg.evaluate('window.__dn'))
    h = pg.locator('.belt-track').bounding_box()['height']
    check('přivolání vln je plynulé (rychlost bloku < 100 % pásu za s)', maxjump < 1.0 * h, '%.0f px/s, pás %.0f px' % (maxjump, h))
    b.close()
print('\nvýsledek: %d/%d' % (sum(results), len(results)), '| chyby:', errs or 'žádné')
