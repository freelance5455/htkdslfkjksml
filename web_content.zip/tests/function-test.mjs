// Offline integration tests; no real provider calls and no API costs.
import assert from 'node:assert/strict';
process.env.NETLIFY='true';process.env.OPENROUTER_API_KEY='test-placeholder-not-a-real-key';process.env.STUDIO_ACCESS_CODE='test-access-code';
let calls=0;
global.fetch=async()=>{calls++;return Response.json({choices:[{finish_reason:'stop',message:{content:JSON.stringify({reply:'Let’s change only the background.',project:{...project,scenes:[{...project.scenes[0],background:'#ff633e'}]},sceneIndex:0})}}]})};
const {default:handler}=await import('../netlify/functions/ai.mjs');
const project={version:1,name:'Test',style:'saas',width:1280,height:720,fps:30,scenes:[{id:'scene1',name:'Intro',duration:5,background:'#171714',camera:{yaw:0,zoom:1,orbit:0},transition:'fade',layers:[{id:'text1',type:'text',name:'Title',text:'Hello',x:640,y:360,w:800,h:100,color:'#f3ebdd',fontSize:50,scale:1,rotation:0,opacity:1,depth:0,start:0,end:5,easing:'cubic',keyframes:[{time:0,x:640,y:400,scale:1,rotation:0,opacity:0},{time:1,x:640,y:360,scale:1,rotation:0,opacity:1}]}]}]};
const make=(path,body,cookie)=>new Request('https://studio.example'+path,{method:body?'POST':'GET',headers:{...(body?{'Content-Type':'application/json','X-Th-Studio':'1'}:{}),...(cookie?{cookie}:{})},body:body?JSON.stringify(body):undefined});
let res=await handler(make('/api/ai/status'));assert((await res.json()).locked);console.log('PASS locked status');
res=await handler(make('/api/ai/chat',{message:'Hi',project}));assert.equal(res.status,401);assert.equal(calls,0);console.log('PASS unauthorized chat cannot use provider');
res=await handler(make('/api/ai/unlock',{code:'wrong'}));assert.equal(res.status,401);console.log('PASS invalid access code');
res=await handler(make('/api/ai/unlock',{code:'test-access-code'}));assert.equal(res.status,200);const cookie=res.headers.get('set-cookie').split(';')[0];assert(res.headers.get('set-cookie').includes('HttpOnly'));assert(res.headers.get('set-cookie').includes('Secure'));console.log('PASS signed, secure, HttpOnly authentication');
res=await handler(make('/api/ai/status',null,cookie));assert((await res.json()).connected);console.log('PASS configured OpenRouter status');
res=await handler(make('/.netlify/functions/ai/status',null,cookie));assert((await res.json()).connected);console.log('PASS Netlify rewritten route');
res=await handler(make('/api/ai/chat',{message:'Change background',project,sceneIndex:0,selectedLayer:0,history:[],assets:[]},cookie));let out=await res.json();assert.equal(res.status,200);assert.equal(out.project.scenes[0].background,'#ff633e');assert.equal(project.scenes[0].background,'#171714');assert.equal(calls,1);console.log('PASS provider → validated proposal; original recipe preserved');
res=await handler(make('/api/ai/connect',{key:'not-used'},cookie));assert.equal(res.status,400);console.log('PASS ephemeral browser-key sessions disabled for serverless');
let saved=process.env.STUDIO_ACCESS_CODE;delete process.env.STUDIO_ACCESS_CODE;res=await handler(make('/api/ai/status'));assert((await res.json()).setupRequired);process.env.STUDIO_ACCESS_CODE=saved;console.log('PASS missing host setup reported clearly');
