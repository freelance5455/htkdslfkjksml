import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const source = fs.readFileSync(new URL('../supabase-local.js', import.meta.url), 'utf8');

function makeClient() {
  const calls = [];
  const sandbox = {
    window: {},
    localStorage: {
      getItem() { return null; },
      setItem() {},
      removeItem() {},
    },
    fetch: async (url, options) => {
      calls.push({ url, options });
      return {
        ok: true,
        async json() { return []; },
      };
    },
  };
  vm.runInNewContext(source, sandbox);
  return { client: sandbox.window.createLocalSupabaseClient('https://example.supabase.co', 'test-key'), calls };
}

test('GET queries are sent without a request body', async () => {
  const { client, calls } = makeClient();

  await client.from('company_members')
    .select('id')
    .eq('company_id', 'company-1')
    .eq('user_id', 'user-1')
    .maybeSingle();

  assert.equal(calls.length, 1);
  assert.equal(calls[0].options.method, 'GET');
  assert.equal('body' in calls[0].options, false);
});

test('password sign-in remains a POST request with a JSON body', async () => {
  const { client, calls } = makeClient();

  await client.auth.signInWithPassword({ email: 'owner@example.com', password: 'secret' });

  assert.equal(calls.length, 1);
  assert.equal(calls[0].options.method, 'POST');
  assert.equal(typeof calls[0].options.body, 'string');
  assert.deepEqual(JSON.parse(calls[0].options.body), {
    email: 'owner@example.com',
    password: 'secret',
  });
});
