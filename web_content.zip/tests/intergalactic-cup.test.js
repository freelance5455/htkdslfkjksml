import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState } from '../src/store.js';
import { INTERGALACTIC_CUP_ID, INTERGALACTIC_NATIONS, createIntergalacticCupSeason, getIntergalacticCupStatus, recordIntergalacticCupResult, validateIntergalacticCup } from '../src/intergalactic-cup.js';
import { scheduleCompetitionCalendar } from '../src/competition-calendar.js';
import { simulateIntergalacticCupRound, recordPlayedGame } from '../src/season-engine.js';

function setup(){const state=createInitialState();state.season=3;state.calendar.officialCalendars={FGD:{regularSeasonEnd:{absoluteDay:160,phase:'end-of-regular-season'}},AGD:{coupeIntergalactiqueGalaxies:{absoluteDay:162,phase:'after-regular-season'},intergalactiqueClubs:{absoluteDay:190,phase:'after-regular-season'}}};scheduleCompetitionCalendar(state);return state;}

test('la Coupe Intergalactique est triennale et contient les 24 sélections officielles',()=>{
 const state=createInitialState();const cup=state.competitions.find(c=>c.id===INTERGALACTIC_CUP_ID);createIntergalacticCupSeason(state);assert.equal(cup.status,'pending');assert.equal(INTERGALACTIC_NATIONS.length,24);
});

test('une édition génère 6 groupes, 36 matchs et des créneaux AGD étalés',()=>{
 const state=setup();const fixtures=createIntergalacticCupSeason(state);const cup=state.competitions.find(c=>c.id===INTERGALACTIC_CUP_ID);
 assert.equal(fixtures.length,36);assert.equal(cup.groups.length,6);assert.ok(cup.groups.every(g=>g.nations.length===4));
 assert.equal(new Set(fixtures.map(f=>f.id)).size,36);assert.deepEqual([...new Set(fixtures.map(f=>f.scheduledDay))].sort((a,b)=>a-b),[162,164,166]);
 assert.equal(validateIntergalacticCup(state),true);
});

test('les deux premiers de chaque groupe et les quatre meilleurs troisièmes donnent 16 qualifiés et 51 matchs',()=>{
 const state=setup();createIntergalacticCupSeason(state);const cup=state.competitions.find(c=>c.id===INTERGALACTIC_CUP_ID);
 for(let roundNo=1;roundNo<=3;roundNo++){
  const round=cup.rounds.find(r=>r.number===roundNo);state.calendar.currentDay=state.calendar.fixtures.find(f=>f.id===round.fixtureIds[0]).scheduledDay;
  for(const id of round.fixtureIds){const f=state.calendar.fixtures.find(x=>x.id===id);const result=recordIntergalacticCupResult(state,id,2,1);assert.equal(result.accepted,true);}
 }
 assert.equal(cup.qualifiedNationIds.length,16);assert.equal(cup.bestThirdPlaceNationIds.length,4);assert.equal(cup.rounds[3].fixtureIds.length,8);assert.equal(cup.rounds[3].label,'Huitièmes de finale');assert.equal(new Set(cup.qualifiedNationIds).size,16);
 for(let roundNo=4;roundNo<=7;roundNo++){
  const round=cup.rounds.find(r=>r.number===roundNo);state.calendar.currentDay=state.calendar.fixtures.find(f=>f.id===round.fixtureIds[0]).scheduledDay;
  for(const id of round.fixtureIds){const f=state.calendar.fixtures.find(x=>x.id===id);const winnerId=f.home;const result=recordIntergalacticCupResult(state,id,2,1,{winnerId});assert.equal(result.accepted,true);}
 }
 assert.equal(cup.status,'completed');assert.ok(cup.championId);assert.equal(cup.fixtures.length,51);assert.equal(getIntergalacticCupStatus(state).totalMatches,51);assert.equal(validateIntergalacticCup(state),true);
});

test('un résultat déjà homologué ne peut pas être compté deux fois',()=>{
 const state=setup();createIntergalacticCupSeason(state);const f=state.calendar.fixtures.find(x=>x.competitionId===INTERGALACTIC_CUP_ID);state.calendar.currentDay=f.scheduledDay;
 assert.equal(recordIntergalacticCupResult(state,f.id,1,0).accepted,true);assert.equal(recordIntergalacticCupResult(state,f.id,1,0).accepted,false);
});

test('la simulation IA laisse le match de la sélection du joueur à jouer manuellement',()=>{
 const state=setup();createIntergalacticCupSeason(state);const cup=state.competitions.find(c=>c.id===INTERGALACTIC_CUP_ID);const first=cup.rounds[0],userFixture=state.calendar.fixtures.find(f=>f.id===first.fixtureIds[0]);state.userNationId=userFixture.home;state.calendar.currentDay=userFixture.scheduledDay;
 const result=simulateIntergalacticCupRound(state);assert.equal(result.userFixture.id,userFixture.id);assert.equal(result.simulated.length,11);assert.equal(first.completed,false);
 const manual=recordPlayedGame(state,userFixture.id,1,{arena:'terrestrial'});assert.equal(manual.accepted,true);assert.equal(userFixture.status,'played');assert.equal(state.calendar.processedFixtureIds.filter(id=>id===userFixture.id).length,1);
});
