"""Strom věží ve Studiu (Basic Tower / Upgrades / Combinations, rodič-dítě, přetahování, mazání, upozornění):  python3 -I tests/ui_tree.py"""
import glob
from playwright.sync_api import sync_playwright
exe = (glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome') or [None])[0]
results, errs = [], []
def check(n, c, x=''): results.append(bool(c)); print(('OK   ' if c else 'FAIL ') + n + (' ' + str(x) if x != '' else ''))
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=exe, args=['--no-sandbox'])
    pg = b.new_context(viewport={'width': 1440, 'height': 900}).new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('file:///home/claude/BubbleDefence/index.html'); pg.wait_for_selector('.content:not(.hidden) .intro')
    pg.click('text=Nová lokální hra'); pg.wait_for_selector('.content:not(.hidden) .menu'); pg.wait_for_timeout(300)
    pg.keyboard.type('terminal', delay=40); pg.keyboard.press('Backquote'); pg.wait_for_timeout(300); pg.keyboard.type('studio'); pg.keyboard.press('Enter'); pg.wait_for_timeout(250); pg.keyboard.press('Backquote'); pg.wait_for_timeout(300)
    pg.click('.mi:has-text("Studio")'); pg.wait_for_selector('.stv'); pg.click('[data-tab=towers]'); pg.wait_for_timeout(300)
    par = lambda i: pg.evaluate("BD.data.towers['%s'] && BD.data.towers['%s'].parent" % (i, i))
    pad = lambda i: pg.evaluate("parseFloat(getComputedStyle(document.querySelector('[data-row=%s]')).paddingLeft)" % i)
    check('tři sekce: Basic Tower, Upgrades, Combinations', pg.locator('.stu-cat').count() == 3 and 'Basic Tower' in pg.inner_text('[data-cat=start]') and 'Upgrades' in pg.inner_text('[data-cat=kinds]') and 'Combinations' in pg.inner_text('[data-cat=combo]'))
    check('Základna je v Basic Tower; v Upgrades je celý strom (4 druhy + 12 vylepšení)', pg.locator('[data-cat=start] [data-id=base]').count() == 1 and pg.locator('[data-cat=kinds] .stu-trow').count() == 16)
    check('vylepšení jsou odsazená pod svým druhem', pad('normal_a') > pad('normal') and par('normal_a') == 'normal' and par('normal') == 'base')
    pg.click('[data-tfold=normal]'); pg.wait_for_timeout(200)
    check('věž jde sbalit (děti se skryjí) a rozbalit', pg.locator('[data-row=normal_a]').count() == 0 and pg.locator('[data-cat=kinds] .stu-trow').count() == 13)
    pg.click('[data-tfold=normal]'); pg.wait_for_timeout(200)
    check('po rozbalení jsou zase vidět', pg.locator('[data-row=normal_a]').count() == 1)
    # přetažení: pod jinou věž
    pg.drag_and_drop('[data-row=normal_a] .stu-item', '[data-row=burst] .stu-item'); pg.wait_for_timeout(400)
    check('přetažení věže na jinou ji udělá jejím vylepšením', par('normal_a') == 'burst', par('normal_a'))
    check('cyklus se nepovolí (rodič pod vlastní dítě)', pg.evaluate("BD.studio.moveTower('burst', 'normal_a')") is False and par('burst') == 'base')
    check('základnu nejde přesunout', pg.evaluate("BD.studio.moveTower('base', 'normal')") is False)
    # nové vylepšení pod vybranou
    pg.click('[data-id=burst_b]'); pg.wait_for_timeout(200); pg.fill('[data-role=stu-newid]', 'Test věž'); pg.click('[data-act=stu-create]'); pg.wait_for_timeout(400)
    nid = pg.evaluate('BD.studio.lastId')
    check('nová věž vznikne jako vylepšení vybrané věže', par(nid) == 'burst_b' and pg.evaluate('BD.studio.ui.sel') == nid and pg.locator('[data-row=%s]' % nid).count() == 1, par(nid))
    # upozornění na slabší vylepšení
    pg.evaluate("BD.studio.set('towers', 'normal', 'base.dmg', 100); BD.studio.set('towers', 'normal_b', 'base.dmg', 5)"); pg.wait_for_timeout(300)
    pg.click('[data-id=normal_b]'); pg.click('[data-panel=props]'); pg.wait_for_timeout(300)
    check('slabší vylepšení je označené ⚠ a v kartě je varování, uložit jde', pg.locator('[data-row=normal_b] [data-role=weak]').count() == 1 and pg.locator('[data-role=weak-box]').count() == 1 and pg.evaluate("BD.data.towers.normal_b.base.dmg") == 5)
    check('pole „Vylepšení z věže“ je ve vlastnostech', pg.locator('[data-f=parent]').count() == 1 and pg.evaluate("document.querySelector('[data-f=parent]').value") == 'normal')
    pg.select_option('[data-f=parent]', 'ghost'); pg.wait_for_timeout(300)
    check('změna rodiče ve formuláři přesune věž ve stromě', par('normal_b') == 'ghost' and pg.locator('[data-row=normal_b]').count() == 1)
    # mazání vestavěné věže
    pg.click('[data-id=ghost_c]'); pg.wait_for_timeout(200)
    pg.evaluate("BD.studio.moveTower('normal_c', 'ghost_c')"); pg.wait_for_timeout(200)
    pg.click('[data-id=ghost_c]'); pg.click('[data-act=stu-remove]'); pg.wait_for_selector('.dlg'); pg.click('.dlg button:has-text("Smazat")'); pg.wait_for_timeout(400)
    check('smazaná vestavěná věž zmizí ze seznamu i z dat hry', pg.locator('[data-row=ghost_c]').count() == 0 and pg.evaluate("!BD.data.towers.ghost_c"))
    check('její vylepšení se přesunula o patro výš', par('normal_c') == 'ghost')
    check('export obsahuje smazání', '"deleted": true' in pg.evaluate('BD.studio.exportText()'))
    check('základnu smazat nejde', pg.evaluate("BD.studio.remove('towers', 'base')") is False)
    pg.click('[data-act=stu-restore]'); pg.wait_for_timeout(300)
    check('smazanou věž jde obnovit', pg.locator('[data-row=ghost_c]').count() == 1 and pg.evaluate("!!BD.data.towers.ghost_c"))
    # chybný strom se opraví
    pg.evaluate("BD.studio.items().towers.normal_a = { patch: { parent: 'neexistuje' } }; BD.studio.apply()"); pg.wait_for_timeout(200)
    check('věž s neexistujícím rodičem skončí pod základnou', par('normal_a') == 'base' or par('normal_a') == 'burst', par('normal_a'))
    pg.screenshot(path='/home/claude/BubbleDefence/tests/shots/studio_tree3.png')
    check('bez chyb', not errs, errs)
    b.close()
print('\nvýsledek: %d/%d' % (sum(results), len(results)), '| chyby:', errs or 'žádné')
