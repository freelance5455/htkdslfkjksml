import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState, loadState } from '../src/store.js';
import { generateSeasonCalendar } from '../src/calendar.js';
import { createFederalCupSeason, getFederalCupStatus, recordFederalCupResult, validateFederalCup } from '../src/federal-cup.js';

test('la Coupe Fédéral inscrit les 36 clubs des divisions actives dans le calendrier central', () => {
  const state = createInitialState();
  generateSeasonCalendar(state);
  const fixtures = createFederalCupSeason(state);
  assert.equal(fixtures.length, 18);
  assert.equal(state.competitions.find(c => c.id === 'coupe-federal').rounds[0].participants.length, 36);
  assert.ok(fixtures.every(f => state.calendar.fixtures.includes(f)));
  assert.ok(fixtures.every(f => f.competitionId === 'coupe-federal'));
  assert.equal(validateFederalCup(state), true);
});

test('la coupe est à élimination directe, sans match retour, et la finale est neutre', () => {
  const state = createInitialState();
  generateSeasonCalendar(state); createFederalCupSeason(state);
  const cup = state.competitions.find(c => c.id === 'coupe-federal');
  assert.equal(cup.format.legs, 1);
  assert.equal(cup.format.penalties, true);
  assert.equal(cup.format.finalVenue, 'neutral');
  let guard = 0;
  while (cup.status === 'in-progress' && guard++ < 12) {
    const round = cup.rounds.at(-1);
    for (const id of [...round.fixtureIds]) {
      const f = state.calendar.fixtures.find(x => x.id === id);
      if (f.status === 'scheduled') recordFederalCupResult(state, id, 1, 0, { winnerId: f.home });
    }
  }
  assert.equal(cup.status, 'completed');
  assert.ok(cup.championId);
  assert.equal(cup.fixtures.length, 35);
  assert.equal(cup.rounds.at(-1).fixtureIds.length, 1);
  assert.equal(state.calendar.fixtures.find(f => f.id === cup.rounds.at(-1).fixtureIds[0]).venueType, 'neutral');
  assert.equal(validateFederalCup(state), true);
});

test('une égalité doit être départagée et les statistiques de coupe ne gonflent pas le championnat', () => {
  const state = createInitialState();
  generateSeasonCalendar(state); createFederalCupSeason(state);
  const cup = state.competitions.find(c => c.id === 'coupe-federal');
  const f = state.calendar.fixtures.find(x => x.id === cup.rounds[0].fixtureIds[0]);
  const home = state.divisions.flatMap(d => d.clubs).find(c => c.id === f.home);
  const playedBefore = home.played;
  assert.throws(() => recordFederalCupResult(state, f.id, 0, 0), /départagé/);
  recordFederalCupResult(state, f.id, 1, 0, { winnerId: f.home, penalties: [5, 4] });
  assert.equal(home.played, playedBefore);
  assert.equal(home.competitionStats['coupe-federal'].played, 1);
});

test('une ancienne sauvegarde à sept compétitions reçoit la Coupe Fédéral sans perdre ses compétitions', () => {
  const state = createInitialState();
  state.competitions.pop();
  const storage = { getItem: () => JSON.stringify(state) };
  const restored = loadState(storage);
  assert.equal(restored.competitions.length, 8);
  assert.equal(restored.competitions[7].id, 'coupe-federal');
});
