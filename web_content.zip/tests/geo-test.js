const vm=require('vm'),fs=require('fs'),L='lib/';const c={console,Math,Object,Array,JSON,Float32Array,Float64Array,Date,setTimeout,clearTimeout};c.window=c;c.self=c;vm.createContext(c);
['x_d3-3.5.17/package/d3.min.js','x_topojson-1.6.19/package/topojson.min.js','x_datamaps-0.5.9/package/dist/datamaps.world.min.js'].forEach(f=>vm.runInContext(fs.readFileSync(L+f,'utf8'),c));
vm.runInContext(fs.readFileSync('geo.js','utf8')+`
var topo=Datamap.prototype.worldTopo,geoms=topo.objects.world.geometries,fs_=topojson.feature(topo,topo.objects.world).features,nb=topojson.neighbors(geoms),R=[],M={};
fs_.forEach(function(f,i){var id=geoms[i].id;if(!/^[A-Z]{3}$/.test(id)||id=='ATA')return;var r={id:id,f:f,nbi:nb[i],c:d3.geo.centroid(f)};M[id]=r;R.push(r)});
R.forEach(function(r){r.nb=r.nbi.map(function(j){return geoms[j].id}).filter(function(x){return M[x]})});geoInit();
function own(ids){var o={};R.forEach(function(r){o[r.id]=r.id});ids.forEach(function(i){o[i]=0});return o}
function lst(ids){var t=targets(0,own(ids));return Object.keys(t).map(function(k){return k+':'+t[k][0]}).join(' ')}
var out={n:R.length,
 eur:lst(['PRT','ESP','FRA','IRL','GBR','ISL','NOR']),
 aut:lst(['AUT']),egy:lst(['EGY']),idn:lst(['IDN']),sen:lst(['SEN','MRT','MAR']),rus:lst(['RUS'])};out`,c);
const o=vm.runInContext('out',c);console.log('ülke sayısı',o.n);for(const k of['eur','aut','egy','idn','sen','rus'])console.log('\n'+k+':',o[k]);
