/**
 * JARVIS Automated Security Tests
 * Verifies 4-tier permission model, pending approval workflows, rate limiting, and immutable audit logs.
 */

import { strict as assert } from 'node:assert';
import { db, initializeDatabase } from '../server/db/database.ts';
import { securityLayer } from '../server/security/securityLayer.ts';
import { toolRegistry } from '../server/tools/toolRegistry.ts';

export async function runSecurityTests(): Promise<{ passed: number; failed: number }> {
  console.log('\n--- Running Security Tests ---');
  let passed = 0;
  let failed = 0;

  async function test(name: string, fn: () => Promise<void> | void) {
    try {
      await fn();
      console.log(`  [PASS] ${name}`);
      passed++;
    } catch (err: any) {
      console.error(`  [FAIL] ${name}:`, err.message);
      failed++;
    }
  }

  // Ensure DB is initialized for audit logging
  await initializeDatabase();

  // 1. Permission level evaluations from tools
  test('evaluates safe and sensitive permission boundaries correctly', () => {
    const diagTool = toolRegistry.getTool('system_diagnostics');
    assert.equal(diagTool?.definition.permissionLevel, 'READ');
    assert.equal(securityLayer.requiresApproval('READ'), false);

    const memoryTool = toolRegistry.getTool('memory_persist');
    assert.equal(memoryTool?.definition.permissionLevel, 'SAFE_WRITE');
    assert.equal(securityLayer.requiresApproval('SAFE_WRITE'), false);

    const codeTool = toolRegistry.getTool('code_sandbox');
    assert.equal(codeTool?.definition.permissionLevel, 'SENSITIVE');
    assert.equal(securityLayer.requiresApproval('SENSITIVE'), true);

    const autoTool = toolRegistry.getTool('automation_action');
    assert.equal(autoTool?.definition.permissionLevel, 'EXTERNAL_ACTION');
    assert.equal(securityLayer.requiresApproval('EXTERNAL_ACTION'), true);
  });

  // 2. Safe execution clearance (READ)
  await test('grants automatic execution for READ tools without blocking', async () => {
    const clearance = await securityLayer.evaluatePermission(
      'EXECUTE_TOOL_system_diagnostics',
      'system_diagnostics',
      'READ',
      {
        taskId: 'task_test_read_1',
        stepId: 'step_1',
        details: { deepScan: false },
      }
    );
    assert.equal(clearance.allowed, true);
    assert.equal(clearance.pendingRequestId, undefined);
  });

  // 3. Challenge issuance for EXTERNAL_ACTION tools
  await test('issues authorization challenge for EXTERNAL_ACTION tools', async () => {
    const clearance = await securityLayer.evaluatePermission(
      'EXECUTE_TOOL_notifier',
      'notifier',
      'EXTERNAL_ACTION',
      {
        taskId: 'task_test_gated_1',
        stepId: 'step_2',
        details: { channel: 'console', message: 'Mission briefing' },
      }
    );

    assert.equal(clearance.allowed, false);
    assert.ok(clearance.pendingRequestId, 'Pending request ID must be issued');
    assert.ok(clearance.reason?.includes('EXTERNAL_ACTION'));

    // Verify challenge can be found in pending list
    const pending = securityLayer.getPendingRequests();
    const found = pending.find((c) => c.id === clearance.pendingRequestId);
    assert.ok(found, 'Pending request must be stored');
    assert.equal(found.toolName, 'notifier');
  });

  // 4. Challenge approval workflow
  await test('resolves pending challenge with approval and removes from pending', async () => {
    const clearance = await securityLayer.evaluatePermission(
      'EXECUTE_TOOL_notifier',
      'notifier',
      'EXTERNAL_ACTION',
      {
        taskId: 'task_test_approval_1',
        stepId: 'step_3',
        details: { message: 'Approved dispatch' },
      }
    );

    assert.ok(clearance.pendingRequestId);
    const reqId = clearance.pendingRequestId;

    // Approve the request
    const resolved = securityLayer.resolveRequest(reqId, true);
    assert.ok(resolved);
    assert.equal(resolved.id, reqId);

    // Verify it is no longer in pending requests
    const pending = securityLayer.getPendingRequests();
    const found = pending.find((c) => c.id === reqId);
    assert.equal(found, undefined, 'Approved request must be removed from pending list');
  });

  // 5. Challenge rejection workflow
  await test('resolves pending challenge with rejection and removes from pending', async () => {
    const clearance = await securityLayer.evaluatePermission(
      'EXECUTE_TOOL_notifier',
      'notifier',
      'EXTERNAL_ACTION',
      {
        taskId: 'task_test_reject_1',
        stepId: 'step_4',
        details: { message: 'Vetoed dispatch' },
      }
    );

    assert.ok(clearance.pendingRequestId);
    const reqId = clearance.pendingRequestId;

    // Reject the request
    const resolved = securityLayer.resolveRequest(reqId, false);
    assert.ok(resolved);
    assert.equal(resolved.id, reqId);

    const pending = securityLayer.getPendingRequests();
    const found = pending.find((c) => c.id === reqId);
    assert.equal(found, undefined);
  });

  // 6. Rate limiting enforcement
  test('rate limiter tracks and limits excessive requests', () => {
    const clientKey = 'test_ip_127_0_0_1';
    // Should allow up to 3 requests
    assert.equal(securityLayer.checkRateLimit(clientKey, 3, 5000), true);
    assert.equal(securityLayer.checkRateLimit(clientKey, 3, 5000), true);
    assert.equal(securityLayer.checkRateLimit(clientKey, 3, 5000), true);
    // 4th request exceeds limit
    assert.equal(securityLayer.checkRateLimit(clientKey, 3, 5000), false);
  });

  // 7. Input sanitizer cleans control characters
  test('sanitizes input against control characters', () => {
    const raw = 'valid-query\x00\x08malicious';
    const clean = securityLayer.sanitizeInput(raw);
    assert.equal(clean, 'valid-querymalicious');
  });

  // 8. Audit log recording in database
  await test('logs audit events to database', async () => {
    const initialLogs = await db.getAuditLogs(50);
    assert.ok(Array.isArray(initialLogs));
    assert.ok(initialLogs.length > 0, 'Audit logs should contain records of previous checks');
  });

  return { passed, failed };
}
