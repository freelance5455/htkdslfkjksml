import * as THREE from 'three'
import { describe, expect, it } from 'vitest'
import { DICTIONARY_KEYS } from '../src/engine/i18n'
import { defaultSave, parseSave } from '../src/engine/save'
import { CONFIG } from '../src/game/config'
import { altitudeAboveGround, createContact, detectGroundContact, timeToTerrain } from '../src/game/collision'
import { FlightModel } from '../src/game/flight'
import { applyRingMiss, applyRingPass, cardinal, createRun, formatClock, isBetter, multiplierFor } from '../src/game/rules'
import { groundHeight, terrainHeight, WATER_LEVEL } from '../src/game/terrain'

const spawn = () => new THREE.Vector3(450, groundHeight(450, 0) + CONFIG.world.startHeight, 0)

describe('terrain', () => {
  it('is deterministic and finite', () => {
    for (const [x, z] of [[0, 0], [1200, -800], [-5000, 9000], [40000, 40000]]) {
      expect(terrainHeight(x, z)).toBe(terrainHeight(x, z))
      expect(Number.isFinite(terrainHeight(x, z))).toBe(true)
    }
  })
  it('has real mountains west of the start and a low valley near it', () => {
    let peak = 0
    for (let x = -9000; x < -1000; x += 200) for (let z = -3000; z <= 3000; z += 200) peak = Math.max(peak, terrainHeight(x, z))
    expect(peak).toBeGreaterThan(900)
    expect(terrainHeight(450, 0)).toBeLessThan(400)
  })
  it('never lets the ground fall below the water surface', () => {
    for (let i = 0; i < 400; i += 1) expect(groundHeight(i * 37 - 3000, i * 19)).toBeGreaterThanOrEqual(WATER_LEVEL)
  })
  it('starts the player with generous clearance', () => {
    expect(altitudeAboveGround(spawn())).toBeGreaterThan(150)
  })
})

describe('flight model', () => {
  const fly = (seconds: number, input: { roll: number; pitch: number; throttle: number }) => {
    const f = new FlightModel()
    f.reset(spawn(), Math.PI / 2, 90, input.throttle)
    for (let t = 0; t < seconds; t += 1 / 60) f.step(1 / 60, input)
    return f
  }
  it('pulling the stick back raises the nose, pushing forward lowers it', () => {
    expect(fly(1.2, { roll: 0, pitch: 1, throttle: 0.6 }).pitchAngle).toBeGreaterThan(0.2)
    expect(fly(1.2, { roll: 0, pitch: -1, throttle: 0.6 }).pitchAngle).toBeLessThan(-0.2)
  })
  it('banks in opposite directions for opposite roll input', () => {
    const left = fly(1, { roll: -1, pitch: 0, throttle: 0.6 }).bank
    const right = fly(1, { roll: 1, pitch: 0, throttle: 0.6 }).bank
    expect(Math.sign(left)).toBe(-Math.sign(right))
    expect(Math.abs(left)).toBeGreaterThan(0.4)
  })
  it('throttle sets the cruising speed within the configured range', () => {
    const slow = fly(12, { roll: 0, pitch: 0, throttle: 0 }).speed
    const fast = fly(12, { roll: 0, pitch: 0, throttle: 1 }).speed
    expect(fast).toBeGreaterThan(slow + 30)
    expect(slow).toBeGreaterThanOrEqual(CONFIG.flight.minSpeed - 4)
    expect(fast).toBeLessThanOrEqual(CONFIG.flight.maxSpeed + 4)
  })
  it('keeps the orientation quaternion normalised', () => {
    const f = fly(8, { roll: 1, pitch: 0.7, throttle: 0.8 })
    expect(f.quaternion.length()).toBeCloseTo(1, 4)
  })
})

describe('terrain collision', () => {
  const dive = (pitch: number, seconds: number) => {
    const f = new FlightModel()
    f.reset(spawn(), Math.PI / 2, 100, 0.6)
    const contact = createContact()
    const prevPos = new THREE.Vector3()
    const prevQuat = new THREE.Quaternion()
    for (let t = 0; t < seconds; t += 1 / 60) {
      prevPos.copy(f.position)
      prevQuat.copy(f.quaternion)
      f.step(1 / 60, { roll: 0, pitch, throttle: 0.6 })
      if (detectGroundContact(prevPos, prevQuat, f.position, f.quaternion, f.speed, contact)) return { t, contact }
    }
    return null
  }
  it('crashes when diving into the terrain', () => {
    const hit = dive(-1, 20)
    expect(hit).not.toBeNull()
    expect(hit!.contact.point.y).toBeGreaterThanOrEqual(WATER_LEVEL - 1)
  })
  it('does not crash in steady level flight', () => {
    expect(dive(0, 6)).toBeNull()
  })
  it('warns before an impact and stays quiet in open air', () => {
    const pos = spawn()
    const down = new THREE.Vector3(0, -0.8, -0.6).normalize()
    expect(timeToTerrain(pos, down, 100, 6, 24)).toBeLessThan(6)
    expect(timeToTerrain(pos, new THREE.Vector3(0, 1, 0), 100, 6, 24)).toBe(Infinity)
  })
})

describe('run rules', () => {
  it('builds a multiplier from consecutive rings and resets it on a miss', () => {
    expect(multiplierFor(0)).toBe(1)
    expect(multiplierFor(3)).toBe(2)
    expect(multiplierFor(30)).toBe(4)
    const run = createRun()
    for (let i = 0; i < 4; i += 1) applyRingPass(run, 0.5)
    expect(run.multiplier).toBe(2)
    const before = run.score
    applyRingMiss(run)
    expect(run.multiplier).toBe(1)
    expect(run.score).toBe(before)
    expect(run.missed).toBe(1)
  })
  it('awards more for a centred pass', () => {
    const a = createRun()
    const b = createRun()
    expect(applyRingPass(a, 0.95).points).toBeGreaterThan(applyRingPass(b, 0.3).points)
  })
  it('formats time and compass points in Spanish', () => {
    expect(formatClock(75)).toBe('1:15')
    expect(cardinal(270)).toBe('O')
    expect(cardinal(0)).toBe('N')
    expect(isBetter({ score: 10, distance: 1 }, { score: 5, distance: 99 })).toBe(true)
  })
})

describe('save data', () => {
  it('survives corrupt or hostile storage', () => {
    expect(parseSave('not json')).toEqual(defaultSave())
    expect(parseSave(null)).toEqual(defaultSave())
    const bad = parseSave(JSON.stringify({ version: 1, sensitivity: 'big', musicVolume: 99, quality: 'ultra', best: { score: -5 } }))
    expect(bad.sensitivity).toBe(defaultSave().sensitivity)
    expect(bad.musicVolume).toBeLessThanOrEqual(1)
    expect(['low', 'medium', 'high']).toContain(bad.quality)
    expect(bad.best.score).toBeGreaterThanOrEqual(0)
  })
})

describe('text', () => {
  it('ships a complete Spanish dictionary', () => {
    expect(DICTIONARY_KEYS.length).toBeGreaterThan(40)
  })
})
