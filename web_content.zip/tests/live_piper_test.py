from playwright.sync_api import sync_playwright
import json, time, pathlib, os, tempfile

URL = os.getenv('LIVE_URL')
if not URL:
    raise SystemExit('LIVE_URL fehlt. Der Live-Test muss gegen die bereitgestellte Netlify-URL laufen.')

REPORT = pathlib.Path(__file__).with_name('live-report.json')
report = {
    'test': 'real Piper de_DE-thorsten-medium online and offline',
    'url': URL,
    'online': {'passed': False},
    'offline': {'passed': False},
    'offline_reload': {'passed': False},
    'passed': False,
    'console_errors': [],
}

def wait_for_audio(page, previous_src='', timeout=600000):
    page.wait_for_function(
        "prev => { const a=document.querySelector('#audio'); return a && a.src.startsWith('blob:') && a.src !== prev && a.readyState >= 1 && Number.isFinite(a.duration) && a.duration > 0; }",
        arg=previous_src,
        timeout=timeout,
    )
    return {
        'src': page.locator('#audio').get_attribute('src'),
        'ready_state': page.eval_on_selector('#audio', 'a => a.readyState'),
        'duration': page.eval_on_selector('#audio', 'a => a.duration'),
        'status': page.locator('#status').inner_text(),
    }

with sync_playwright() as p:
    kwargs = {
        'headless': True,
        'args': ['--autoplay-policy=no-user-gesture-required'],
        'user_data_dir': tempfile.mkdtemp(prefix='piper-profile-'),
    }
    if os.getenv('CHROMIUM_PATH'):
        kwargs['executable_path'] = os.environ['CHROMIUM_PATH']
    context = p.chromium.launch_persistent_context(**kwargs)
    page = context.pages[0]
    page.on('console', lambda m: report['console_errors'].append(m.text) if m.type == 'error' else None)

    try:
        page.goto(URL, wait_until='networkidle', timeout=120000)
        page.fill('#text', 'Dies ist der echte Online-Test der deutschen Piper Stimme Thorsten.')
        started = time.time()
        page.click('#start')
        online = wait_for_audio(page)
        online['synthesis_seconds'] = round(time.time() - started, 2)
        online['passed'] = True
        report['online'] = online

        page.click('#stop')
        context.set_offline(True)
        page.fill('#text', 'Dies ist der Offline-Test mit dem bereits gespeicherten Piper Modell.')
        started = time.time()
        page.click('#start')
        offline = wait_for_audio(page, previous_src=online['src'], timeout=240000)
        offline['synthesis_seconds'] = round(time.time() - started, 2)
        offline['passed'] = True
        report['offline'] = offline
        page.wait_for_function("navigator.serviceWorker && navigator.serviceWorker.controller !== null", timeout=30000)
        page.reload(wait_until='domcontentloaded', timeout=60000)
        page.wait_for_selector('#start', timeout=30000)
        report['offline_reload'] = {
            'passed': True,
            'status': page.locator('#status').inner_text(),
            'service_worker_controlled': page.evaluate("Boolean(navigator.serviceWorker.controller)"),
        }
        report['passed'] = True
    except Exception as exc:
        report['error'] = str(exc)
        try:
            report['status'] = page.locator('#status').inner_text()
        except Exception:
            pass
    finally:
        REPORT.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
        print(json.dumps(report, indent=2, ensure_ascii=False))
        context.close()

if not report['passed']:
    raise SystemExit(1)
