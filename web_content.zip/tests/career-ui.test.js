import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

test('navigation principale contient les neuf rubriques demandées', async () => {
  const html = await readFile(new URL('../index.html', import.meta.url), 'utf8');
  for (const screen of ['accueil','club','competitions','mercato','arene','calendrier','gestion','messagerie','reglages']) assert.match(html, new RegExp(`data-screen-link="${screen}"`));
});

test('interface utilise une navigation à écran unique et conserve les sections historiques', async () => {
  const html = await readFile(new URL('../index.html', import.meta.url), 'utf8');
  assert.match(html, /\.section\[hidden\]\{display:none!important\}/);
  for (const label of ['Les cinq divisions','Les huit compétitions du CGD','Dame d’Or','Messagerie, presse','Moteur de match']) assert.ok(html.includes(label));
});

test('adaptation paysage mobile et navigation tactile sont déclarées', async () => {
  const html = await readFile(new URL('../index.html', import.meta.url), 'utf8');
  assert.match(html, /orientation:landscape/);
  assert.match(html, /orientation:portrait/);
  assert.match(html, /career-rail/);
});

test('un bouton CONTINUER global est présent dans l’en-tête', async () => {
  const html = await readFile(new URL('../index.html', import.meta.url), 'utf8');
  assert.match(html, /id="continueCareer"/);
});
