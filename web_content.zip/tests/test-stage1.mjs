// Stone Pro v14.1 checks: terms gate, roles + trades, password on every delete, timestamps + event log,
// backup/restore, PIN lock + throttling, pure-JS hashing fallback, offline.
// Usage: CHROMIUM_PATH=/path/to/chrome node test-stage1.mjs <path to ysp-pwa folder>
import { chromium } from 'playwright';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(process.argv[2]);
const types = { '.html': 'text/html', '.js': 'text/javascript', '.json': 'application/json', '.png': 'image/png' };
const server = http.createServer((req, res) => {
  const p = path.join(root, decodeURIComponent(req.url.split('?')[0]).replace(/^\/$/, '/index.html'));
  if (!p.startsWith(root) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'content-type': types[path.extname(p)] || 'application/octet-stream' });
  fs.createReadStream(p).pipe(res);
});
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const url = `http://127.0.0.1:${server.address().port}/`;

let fails = 0;
const ok = (n, c, extra = '') => { console.log((c ? 'PASS ' : 'FAIL ') + n + (c ? '' : ' -> ' + extra)); if (!c) fails++; };
const PIN = '482913';

const b = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
const newCtx = (extra = {}) => b.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, acceptDownloads: true, ...extra });
const errs = [];
const open = async (ctx) => { const p = await ctx.newPage(); p.on('pageerror', (e) => errs.push(e.message)); p.on('dialog', (d) => d.accept()); return p; };

const store = (p, k) => p.evaluate((key) => JSON.parse(localStorage.getItem(key) || 'null'), k);
const val = (p, id) => p.evaluate((i) => document.getElementById(i).value, id);
const isOpen = (p, sel) => p.evaluate((s) => !!document.querySelector(s) && document.querySelector(s).classList.contains('open'), sel);
const visible = (p, sel) => p.evaluate((s) => { const e = document.querySelector(s); return !!e && (e.offsetParent !== null || getComputedStyle(e).position === 'fixed'); }, sel);

async function acceptTerms(p) {
  await p.evaluate(() => { const b = document.querySelector('#ysp-terms .ysp-gate-body'); b.scrollTop = b.scrollHeight; b.dispatchEvent(new Event('scroll')); });
  await p.check('#ysp-terms-check');
  await p.click('#ysp-terms-go');
}
async function chooseRole(p, role, trade, name) {
  await p.click(`.ysp-role-card[data-r="${role}"]`);
  if (trade) await p.selectOption('#ysp-trade', { label: trade });
  if (name !== undefined) await p.fill('#ysp-name', name);
  await p.click('#ysp-role-save');
}
async function unlock(p, pin = PIN) { await p.fill('#ysp-lock-pin', pin); await p.click('#ysp-lock-go'); await p.waitForTimeout(500); }
async function createPinInDialog(p, pin) {
  await p.fill('#ysp-pin-new', pin); await p.fill('#ysp-pin-new2', pin); await p.click('#ysp-pin-save'); await p.waitForTimeout(700);
}
async function confirmDelete(p, pin) { await p.fill('#ysp-delete-password', pin); await p.evaluate(() => confirmDeleteModal()); await p.waitForTimeout(500); }

const ctx = await newCtx();
const p = await open(ctx);
await p.goto(url);
await p.waitForTimeout(1800);

/* ===== A. terms gate, then role gate ===== */
ok('terms shown before anything else', await isOpen(p, '#ysp-terms'));
ok('no profile and no acceptance yet', (await store(p, 'ysp_legal')) === null && (await store(p, 'ysp_profile')) === null);
await p.screenshot({ path: '/home/claude/sp_terms.png' });
ok('accept box disabled before reading to the end', await p.evaluate(() => document.getElementById('ysp-terms-check').disabled));
await p.click('#ysp-terms-no');
ok('"I do not accept" keeps the gate closed', (await isOpen(p, '#ysp-terms')) && (await p.textContent('#ysp-terms-hint')).includes('نمی‌توانی'));
await p.evaluate(() => { const b = document.querySelector('#ysp-terms .ysp-gate-body'); b.scrollTop = b.scrollHeight; b.dispatchEvent(new Event('scroll')); });
ok('accept box enabled after scrolling to the end', await p.evaluate(() => !document.getElementById('ysp-terms-check').disabled));
ok('continue button needs the checkbox', await p.evaluate(() => document.getElementById('ysp-terms-go').disabled));
await p.check('#ysp-terms-check'); await p.click('#ysp-terms-go'); await p.waitForTimeout(200);
const legal = await store(p, 'ysp_legal');
ok('acceptance saved with version and exact time', legal && legal.version && legal.at && legal.at.includes('T'));
ok('acceptance logged as an event', (await store(p, 'ysp_events')).some((e) => e.kind === 'terms_accepted' && e.at.includes('T')));
ok('role chooser shown next', await isOpen(p, '#ysp-role'));
await p.screenshot({ path: '/home/claude/sp_role.png' });
await p.click('.ysp-role-card[data-r="contractor"]');
await p.click('#ysp-role-save');
ok('contractor must pick a trade', (await p.textContent('#ysp-role-err')).includes('صنف'));
await p.selectOption('#ysp-trade', { label: 'سایر (خودم می‌نویسم)' });
await p.click('#ysp-role-save');
ok('"other" trade needs a name', (await p.textContent('#ysp-role-err')).includes('نام صنف'));
await p.selectOption('#ysp-trade', { label: 'سنگ‌کار' });
await p.fill('#ysp-name', 'یاشار <b>x</b>');
await p.click('#ysp-role-save'); await p.waitForTimeout(300);
const prof = (await store(p, 'ysp_profile'))[0];
ok('profile saved (contractor, trade)', prof.userType === 'contractor' && prof.trade === 'سنگ‌کار');
ok('gates are closed afterwards', !(await isOpen(p, '#ysp-role')) && !(await isOpen(p, '#ysp-terms')));
ok('home subtitle shows role and trade', (await p.textContent('#home-sub')).includes('پیمانکار') && (await p.textContent('#home-sub')).includes('سنگ‌کار'));
ok('profile change logged', (await store(p, 'ysp_events')).some((e) => e.entity === 'profile' && e.kind === 'create'));
await p.reload(); await p.waitForTimeout(1500);
ok('no gates on the next start', !(await isOpen(p, '#ysp-terms')) && !(await isOpen(p, '#ysp-role')));
await p.evaluate(() => { const l = JSON.parse(localStorage.getItem('ysp_legal')); l.version = 'old'; localStorage.setItem('ysp_legal', JSON.stringify(l)); });
await p.reload(); await p.waitForTimeout(1500);
ok('changed terms version asks for acceptance again', await isOpen(p, '#ysp-terms'));
await acceptTerms(p); await p.waitForTimeout(300);
ok('profile is kept, role chooser not repeated', !(await isOpen(p, '#ysp-role')) && (await store(p, 'ysp_profile')).length === 1);
await p.waitForTimeout(1500);

/* ===== B. timestamps + event log (contractor) ===== */
await p.evaluate(() => newProject());
await p.fill('#p-name', 'ویلا تست <img src=x onerror="window.__xss=1">');
await p.fill('#p-income', '5000000');
await p.evaluate(() => saveProject());
let projects = await store(p, 'ysp_projects');
ok('project saved with createdAt/updatedAt/incomeAt', projects.length === 1 && ['createdAt', 'updatedAt', 'incomeAt'].every((k) => projects[0][k]?.includes('T')));
let events = await store(p, 'ysp_events');
ok('create event logged with time', events.some((e) => e.kind === 'create' && e.entity === 'project' && e.at.includes('T')));
await p.evaluate((id) => openProject(id), projects[0].id);
ok('income date + last edit show a clock time', (await val(p, 'p-income-date')).includes(':') && (await val(p, 'p-updated')).includes(':'));
await p.fill('#p-expense', '750000');
await p.evaluate(() => saveProject());
events = await store(p, 'ysp_events');
const upd = events.filter((e) => e.kind === 'update' && e.entity === 'project').pop();
ok('update event lists only the changed field', upd && upd.fields.includes('expense') && !upd.fields.includes('income'), JSON.stringify(upd));
await p.evaluate(() => openEntityForm('worker', null));
await p.fill('#ef-name', 'علی');
await p.evaluate(() => saveEntity());
const w = (await store(p, 'ysp_workers')).find((x) => x.name === 'علی');
await p.evaluate((id) => openEntityForm('worker', id), w.id);
await p.evaluate(() => recordWorkerWork('work'));
let led = await store(p, 'ysp_worker_ledger');
ok('ledger entry has exact time and shows it', led.length === 1 && led[0].at.includes('T') && (await p.evaluate(() => document.getElementById('worker-ledger-box').textContent)).includes(':'));
await p.evaluate((id) => openProject(id), projects[0].id);
await p.evaluate(() => newProject());
ok('new project does not inherit old dates', await p.evaluate(() => ['p-income-date', 'p-expense-date'].every((i) => !document.getElementById(i).dataset.iso && !document.getElementById(i).value)));
await p.evaluate(() => go('projects'));
ok('project name is escaped (no script ran)', !(await p.evaluate(() => window.__xss)));
await p.evaluate(() => go('accounting'));
const acc = await p.evaluate(() => document.getElementById('acc-list').textContent);
ok('accounting shows Persian date/time, not raw ISO', !/\d{4}-\d{2}-\d{2}/.test(acc) && acc.includes(':'), acc.slice(0, 120));
await p.evaluate(() => go('home'));

/* ===== C. every deletion needs the password ===== */
await p.evaluate((id) => openProject(id), projects[0].id);
await p.evaluate(() => deleteProject());
ok('no PIN yet: delete opens "create a password" instead of deleting', (await isOpen(p, '#ysp-sec-modal')) && (await store(p, 'ysp_projects')).length === 1);
await p.fill('#ysp-pin-new', '1234'); await p.fill('#ysp-pin-new2', '1234'); await p.click('#ysp-pin-save');
ok('weak PIN 1234 rejected', (await p.textContent('#ysp-sec-err')).includes('ردیف'));
await p.fill('#ysp-pin-new', '111111'); await p.fill('#ysp-pin-new2', '111111'); await p.click('#ysp-pin-save');
ok('repeated-digit PIN rejected', (await p.textContent('#ysp-sec-err')).includes('یکی'));
await p.fill('#ysp-pin-new', PIN); await p.fill('#ysp-pin-new2', '000000'); await p.click('#ysp-pin-save');
ok('mismatching repeat rejected', (await p.textContent('#ysp-sec-err')).includes('تکرار'));
await createPinInDialog(p, PIN);
const sec = await store(p, 'ysp_sec');
ok('PIN stored as salted hash only', sec && sec.hash && sec.salt && !JSON.stringify(sec).includes(PIN) && sec.iter >= 100000);
ok('after creating the PIN the same delete asks for it', await isOpen(p, '#ysp-delete-modal'));
await confirmDelete(p, '1234');
ok('old default 1234 does not delete', (await store(p, 'ysp_projects')).length === 1);
await confirmDelete(p, PIN);
ok('project deleted only with the real PIN', (await store(p, 'ysp_projects')).length === 0);
ok('delete event logged', (await store(p, 'ysp_events')).some((e) => e.kind === 'delete' && e.entity === 'project'));

await p.evaluate(() => setArr('ysp_photos', [{ id: 'ph1', data: '', caption: 'عکس تست', date: YSP.isoDate(), at: YSP.nowISO() }]));
await p.evaluate(() => delPhoto('ph1'));
ok('photo delete asks for PIN and keeps the photo', (await isOpen(p, '#ysp-delete-modal')) && (await store(p, 'ysp_photos')).length === 1);
await confirmDelete(p, PIN);
ok('photo deleted after PIN', (await store(p, 'ysp_photos')).length === 0);
led = await store(p, 'ysp_worker_ledger');
await p.evaluate((id) => deleteWorkerEntry(id), led[0].id);
ok('ledger delete asks for PIN and keeps the entry', (await isOpen(p, '#ysp-delete-modal')) && (await store(p, 'ysp_worker_ledger')).length === 1);
await confirmDelete(p, '000111');
ok('wrong PIN does not delete the ledger entry', (await store(p, 'ysp_worker_ledger')).length === 1);
await confirmDelete(p, PIN);
ok('ledger entry deleted after PIN', (await store(p, 'ysp_worker_ledger')).length === 0);
await p.evaluate(() => { openEntityForm('estimate', null); window._estimateRows = [{ item: 'سنگ', qty: 2, unit: 'متر مربع', price: 100 }]; renderEstimateRows(); });
await p.evaluate(() => removeEstimateRow(0));
ok('estimate row delete asks for PIN and keeps the row', (await isOpen(p, '#ysp-delete-modal')) && (await p.evaluate(() => window._estimateRows.length)) === 1);
await confirmDelete(p, PIN);
ok('estimate row removed after PIN', (await p.evaluate(() => window._estimateRows.length)) === 0);
await p.evaluate((id) => openEntityForm('worker', id), w.id);
await p.evaluate(() => deleteEntity());
ok('worker delete asks for PIN and keeps the worker', (await isOpen(p, '#ysp-delete-modal')) && (await store(p, 'ysp_workers')).some((x) => x.id === w.id));
await confirmDelete(p, PIN);
ok('worker deleted after PIN', !(await store(p, 'ysp_workers')).some((x) => x.id === w.id));
await p.evaluate(() => go('home'));

/* ===== D. roles: owner, worker, back to contractor ===== */
await p.evaluate(() => { newProject(); });
await p.fill('#p-name', 'برج آزمایشی'); await p.fill('#p-client', 'پیمانکار الف'); await p.fill('#p-price', '10000000'); await p.fill('#p-expense', '4000000');
await p.evaluate(() => saveProject());
await p.evaluate(() => { go('home'); openSettings(); });
ok('settings has role card + terms card', (await p.textContent('#ysp-settings-tools')).includes('نقش و صنف') && (await p.textContent('#ysp-settings-tools')).includes('مقررات و حریم خصوصی'));
await p.screenshot({ path: '/home/claude/sp_settings.png' });
await p.click('text=تغییر نقش یا صنف');
await chooseRole(p, 'owner', '', 'سرمایه‌گذار'); await p.waitForTimeout(300);
ok('owner: body role set', (await p.evaluate(() => document.body.dataset.role)) === 'owner');
ok('owner: workers/estimate tiles hidden, projects tile shown', !(await visible(p, '.tile[data-for="contractor"]')) && (await visible(p, '.tile[data-for="contractor owner"]')));
await p.screenshot({ path: '/home/claude/sp_owner_home.png' });
await p.evaluate(() => openProject(JSON.parse(localStorage.getItem('ysp_projects'))[0].id));
ok('owner: form speaks about contractor/payments', (await p.textContent('#project .lbl[data-label-owner]')).includes('پیمانکار') && !(await visible(p, '#p-income')) && !(await visible(p, '#p-worker-paid')) && (await visible(p, '#p-price')));
await p.evaluate(() => go('accounting'));
const oacc = await p.evaluate(() => document.getElementById('acc-stats').textContent + document.getElementById('acc-list').textContent);
ok('owner: payments screen shows contract, paid, remaining', oacc.includes('مانده') && oacc.includes('پیمانکار الف'));
await p.evaluate(() => go('reports'));
ok('owner: report has paid/remaining', (await p.evaluate(() => document.getElementById('rep-stats').textContent)).includes('کل پرداختی'));
await p.evaluate(() => { go('home'); openSettings(); });
await p.click('text=تغییر نقش یا صنف');
await chooseRole(p, 'worker', '', 'رضا'); await p.waitForTimeout(300);
ok('worker: self record created', (await store(p, 'ysp_workers')).some((x) => x.id === 'wself' && x.name === 'رضا'));
ok('worker: only own tiles', (await visible(p, '.tile[data-for="worker"]')) && !(await visible(p, '.tile[data-for="contractor owner"]')) && !(await visible(p, '.tile[data-for="contractor"]')));
await p.screenshot({ path: '/home/claude/sp_worker_home.png' });
await p.evaluate(() => YSPRole.openMyLog());
ok('worker: logbook opens, no delete button, receipt button gone', !(await visible(p, '#ef-del')) && (await p.evaluate(() => !document.querySelector("[onclick=\"recordWorkerMoney('receipt')\"]"))));
ok('worker: money button says "received"', (await p.textContent('#worker-ledger-box')).includes('ثبت دریافتی'));
await p.evaluate(() => recordWorkerWork('work'));
await p.evaluate(() => go('reports'));
ok('worker: report shows days worked', (await p.evaluate(() => document.getElementById('rep-stats').textContent)).includes('روز کارکرد'));
await p.evaluate(() => { go('home'); openSettings(); });
await p.click('text=تغییر نقش یا صنف');
await chooseRole(p, 'contractor', 'سنگ‌کار'); await p.waitForTimeout(300);
ok('back to contractor: everything visible again, data intact', (await visible(p, '.tile[data-for="contractor"]')) && (await store(p, 'ysp_projects')).length === 1);
ok('estimate unit suggestions follow the trade', (await p.evaluate(() => document.getElementById('ysp-units').innerHTML)).includes('پله'));
ok('role changes are in the event log', (await store(p, 'ysp_events')).filter((e) => e.entity === 'profile').length >= 3);

/* ===== E. backup, tamper, restore (restore needs the PIN too) ===== */
await p.evaluate(() => { go('home'); openSettings(); });
const [dl] = await Promise.all([p.waitForEvent('download'), p.click('text=دانلود فایل پشتیبان')]);
const backupPath = await dl.path();
const text = fs.readFileSync(backupPath, 'utf8');
const bk = JSON.parse(text);
ok('backup has format, sha256 checksum, profile', bk.app === 'stone-pro' && bk.format === 1 && bk.algo === 'sha256' && bk.checksum.length === 64 && bk.data.ysp_profile.length === 1);
ok('backup never contains PIN or terms state', !('ysp_sec' in bk.data) && !('ysp_legal' in bk.data));
ok('valid backup passes validation', !!(await p.evaluate((t) => YSPData._validate(t), text)).backup);
const bad = JSON.parse(text); bad.data.ysp_projects[0].price = '999';
ok('tampered backup rejected', !!(await p.evaluate((t) => YSPData._validate(t), JSON.stringify(bad))).error);
ok('garbage file rejected', !!(await p.evaluate(() => YSPData._validate('not json'))).error);
await p.evaluate(() => { ['ysp_projects', 'ysp_workers', 'ysp_worker_ledger', 'ysp_estimates', 'ysp_photos', 'ysp_events'].forEach((k) => localStorage.removeItem(k)); });
await p.reload(); await p.waitForTimeout(1500);
await unlock(p);
await p.evaluate(() => openSettings());
const [chooser] = await Promise.all([p.waitForEvent('filechooser'), p.click('text=بازیابی از فایل پشتیبان')]);
await chooser.setFiles(backupPath);
await p.waitForTimeout(800);
ok('restore asks for the PIN first', (await isOpen(p, '#ysp-delete-modal')) && (await store(p, 'ysp_projects')) === null);
await confirmDelete(p, '000111');
ok('wrong PIN: nothing restored', (await store(p, 'ysp_projects')) === null);
await p.fill('#ysp-delete-password', PIN); await p.evaluate(() => confirmDeleteModal());
await p.waitForTimeout(1800);
projects = await store(p, 'ysp_projects');
ok('restore brings projects, workers and events back', projects && projects.length === 1 && (await store(p, 'ysp_workers')).length >= 1 && (await store(p, 'ysp_events')).some((e) => e.kind === 'restore'));

/* ===== F. lock screen, auto-lock, throttling ===== */
await p.reload(); await p.waitForTimeout(700);
ok('lock screen on start', await isOpen(p, '#ysp-lock'));
await p.screenshot({ path: '/home/claude/sp_lock.png' });
await unlock(p, '000111');
ok('wrong PIN keeps it locked', (await isOpen(p, '#ysp-lock')) && (await p.textContent('#ysp-lock-msg')).includes('اشتباه'));
await unlock(p);
ok('correct PIN unlocks', !(await isOpen(p, '#ysp-lock')));
events = await store(p, 'ysp_events');
ok('auth events logged with time', events.some((e) => e.kind === 'auth_fail') && events.some((e) => e.kind === 'auth_ok'));
await p.evaluate(() => { YSPSec.markHidden(Date.now() - 200000); document.dispatchEvent(new Event('visibilitychange')); });
ok('auto-lock after >2 min away', await isOpen(p, '#ysp-lock'));
await unlock(p);
await p.evaluate(() => { YSPSec.markHidden(Date.now() - 10000); document.dispatchEvent(new Event('visibilitychange')); });
ok('no lock after a short absence', !(await isOpen(p, '#ysp-lock')));
await p.evaluate(() => YSPSec.lock());
for (let i = 0; i < 5; i++) { await p.fill('#ysp-lock-pin', '000111'); await p.click('#ysp-lock-go'); await p.waitForTimeout(450); }
ok('5 wrong PINs force a wait', (await p.textContent('#ysp-lock-msg')).includes('ثانیه'));
await unlock(p);
ok('correct PIN refused during the wait', await isOpen(p, '#ysp-lock'));
await p.evaluate(() => { const s = JSON.parse(localStorage.getItem('ysp_sec')); s.lockUntil = 0; localStorage.setItem('ysp_sec', JSON.stringify(s)); });
await unlock(p);
ok('unlocks once the wait is over', !(await isOpen(p, '#ysp-lock')));

/* ===== G. terms viewer and event viewer ===== */
await p.evaluate(() => { go('home'); openSettings(); });
await p.click('text=مشاهده مقررات'); await p.waitForTimeout(200);
ok('terms viewer shows text and acceptance time', (await isOpen(p, '#ysp-terms-view')) && (await p.textContent('#ysp-terms-view')).includes('پذیرفته‌شده در'));
await p.click('#ysp-terms-close');
await p.evaluate(() => { openSettings(); closeUtilityModal('ysp-settings-modal'); YSPData.openEvents(); });
await p.waitForTimeout(300);
ok('event viewer lists many events', (await p.evaluate(() => document.querySelectorAll('#ysp-events-list .utility-result').length)) > 10);
await p.screenshot({ path: '/home/claude/sp_events.png' });
await p.evaluate(() => closeUtilityModal('ysp-events-modal'));

/* ===== H. pure-JS hashing equals WebCrypto, and works without WebCrypto ===== */
const sameHash = await p.evaluate(async () => {
  const enc = new TextEncoder(); let good = true;
  for (let i = 0; i < 6; i++) {
    const pw = enc.encode('pw' + i * 7919), salt = crypto.getRandomValues(new Uint8Array(16)), it = 500 + i * 777;
    const key = await crypto.subtle.importKey('raw', pw, 'PBKDF2', false, ['deriveBits']);
    const ref = new Uint8Array(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: it }, key, 256));
    if (YSPHash.hex(YSPHash.pbkdf2(pw, salt, it)) !== YSPHash.hex(ref)) good = false;
    const msg = crypto.getRandomValues(new Uint8Array(i * 977));
    if (YSPHash.hex(YSPHash.sha256(msg)) !== YSPHash.hex(new Uint8Array(await crypto.subtle.digest('SHA-256', msg)))) good = false;
  }
  return good;
});
ok('JS PBKDF2/SHA-256 match WebCrypto', sameHash);

const ctx2 = await newCtx();
await ctx2.addInitScript(() => { try { Object.defineProperty(window.crypto, 'subtle', { get: () => undefined }); } catch (e) {} });
const q = await open(ctx2);
await q.goto(url); await q.waitForTimeout(1500);
ok('(no WebCrypto) crypto.subtle really missing', await q.evaluate(() => !crypto.subtle));
await acceptTerms(q); await chooseRole(q, 'contractor', 'کاشی‌کار و سرامیک‌کار'); await q.waitForTimeout(300);
await q.evaluate(() => { newProject(); });
await q.fill('#p-name', 'پروژه بدون crypto'); await q.evaluate(() => saveProject());
await q.evaluate(() => deleteProject());
await createPinInDialog(q, PIN);
const qsec = await store(q, 'ysp_sec');
ok('(no WebCrypto) PIN can be created with the JS fallback', qsec && qsec.iter === 100000);
ok('(no WebCrypto) delete still needs and accepts the PIN', await isOpen(q, '#ysp-delete-modal'));
await confirmDelete(q, '000111');
ok('(no WebCrypto) wrong PIN refused', (await store(q, 'ysp_projects')).length === 1);
await confirmDelete(q, PIN);
ok('(no WebCrypto) right PIN deletes', (await store(q, 'ysp_projects')).length === 0);
await q.reload(); await q.waitForTimeout(700);
await unlock(q);
ok('(no WebCrypto) lock screen unlocks with the JS hash', !(await isOpen(q, '#ysp-lock')));
await q.evaluate(() => { newProject(); });
await q.fill('#p-name', 'برای پشتیبان'); await q.evaluate(() => saveProject());
await q.evaluate(() => { go('home'); openSettings(); });
const [dl2] = await Promise.all([q.waitForEvent('download'), q.click('text=دانلود فایل پشتیبان')]);
const text2 = fs.readFileSync(await dl2.path(), 'utf8');
ok('backup made WITHOUT WebCrypto verifies WITH WebCrypto', !!(await p.evaluate((t) => YSPData._validate(t), text2)).backup);
ok('backup made WITH WebCrypto verifies WITHOUT WebCrypto', !!(await q.evaluate((t) => YSPData._validate(t), text)).backup);

/* ===== I. service worker + offline ===== */
await p.evaluate(async () => { await navigator.serviceWorker.ready; });
await p.reload(); await p.waitForTimeout(1200);
await unlock(p).catch(() => {});
const cacheNames = await p.evaluate(() => caches.keys());
ok('service worker cache v14-4 present', cacheNames.includes('stonepro-v14-4'), JSON.stringify(cacheNames));
await ctx.setOffline(true);
await p.reload(); await p.waitForTimeout(1500);
ok('app opens offline', await p.evaluate(() => typeof YSP === 'object' && typeof YSPRole === 'object' && !!document.getElementById('home')));
await ctx.setOffline(false);

console.log('page errors:', errs);
console.log('FAILS', fails + errs.length);
await b.close(); server.close();
