import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState } from '../src/store.js';
import { createManagerProfile } from '../src/career.js';
import { ensureClubOffice, updateBoardDomain } from '../src/manager-office.js';
import { proposeStaffContract, respondStaffContract, signStaffContract, processStaffPayroll, evaluateManagerSecurity, calculateStaffPerformanceModifiers, processDailyStaffDevelopment, getStaffMatchPreparationBonus, validateStaffContracts } from '../src/manager-consequences.js';

function setup(){const state=createInitialState();createManagerProfile({firstName:'Awa',lastName:'Diallo',galaxy:state.world.galaxies[0].name,mode:'club',sex:'Femme',reputation:'Locale',clubId:state.divisions[0].clubs[0].id},state);return state;}

test('propose, accept and sign staff contract only after both parties agree',()=>{const s=setup(),office=ensureClubOffice(s).office;const cashBefore=office.finance.cash;const n=proposeStaffContract(s,'assistant',{wagePerDay:120,bonus:500,duration:2});assert.equal(n.status,'proposed');assert.throws(()=>signStaffContract(s,'assistant'));respondStaffContract(s,'assistant','accept');const c=signStaffContract(s,'assistant');assert.equal(c.status,'active');assert.equal(c.wagePerDay,120);assert.equal(office.finance.cash,cashBefore-500);assert.equal(validateStaffContracts(s),true);});

test('staff may counter-propose and manager must explicitly accept it',()=>{const s=setup();proposeStaffContract(s,'coach',{wagePerDay:100,duration:1});respondStaffContract(s,'coach','counter',{wagePerDay:150,duration:2,bonus:20});assert.throws(()=>signStaffContract(s,'coach'));const c=signStaffContract(s,'coach',true);assert.equal(c.wagePerDay,150);assert.equal(c.duration,2);});

test('invalid staff salary, duration and bonus are rejected',()=>{const s=setup();assert.throws(()=>proposeStaffContract(s,'assistant',{wagePerDay:-1,duration:1}));assert.throws(()=>proposeStaffContract(s,'assistant',{wagePerDay:10,duration:6}));assert.throws(()=>proposeStaffContract(s,'assistant',{wagePerDay:10,duration:1,bonus:-1}));});

test('daily staff payroll is deducted from club cash and recorded',()=>{const s=setup(),o=ensureClubOffice(s).office;proposeStaffContract(s,'assistant',{wagePerDay:100,duration:1});respondStaffContract(s,'assistant','accept');signStaffContract(s,'assistant');const before=o.finance.cash;const r=processStaffPayroll(s);assert.equal(r.paid,100);assert.equal(o.finance.cash,before-100);assert.equal(o.finance.ledger[0].reason,'Masse salariale quotidienne du staff');});

test('insufficient cash partially pays staff and lowers finance confidence',()=>{const s=setup(),o=ensureClubOffice(s).office;o.finance.cash=20;s.divisions[0].clubs.find(c=>c.id===s.userClubId).budget=20;proposeStaffContract(s,'assistant',{wagePerDay:100,duration:1});respondStaffContract(s,'assistant','accept');signStaffContract(s,'assistant');o.finance.cash=10;s.divisions[0].clubs.find(c=>c.id===s.userClubId).budget=10;const before=o.board.domains.Finances;const r=processStaffPayroll(s);assert.equal(r.shortfall,90);assert.equal(o.board.domains.Finances,before-2);});

test('board dismissal requires seven consecutive days below 15 confidence',()=>{const s=setup();const o=ensureClubOffice(s).office;for(const key of Object.keys(o.board.domains))o.board.domains[key]=0;o.board.confidence=0;for(let i=0;i<6;i++){const r=evaluateManagerSecurity(s);assert.equal(r.dismissed,false);}const last=evaluateManagerSecurity(s);assert.equal(last.dismissed,true);assert.equal(s.userClubId,null);assert.equal(s.career.mode,'unemployed');assert.equal(s.career.history[0].type,'dismissal');});

test('confidence recovery resets dismissal counter',()=>{const s=setup(),o=ensureClubOffice(s).office;o.board.confidence=10;for(let i=0;i<3;i++)evaluateManagerSecurity(s);o.board.domains.Matchs=100;o.board.domains.Transferts=100;o.board.domains.Harmonie=100;o.board.domains.Supporters=100;o.board.domains.Finances=100;o.board.domains.Jeunes=100;o.board.confidence=100;const r=evaluateManagerSecurity(s);assert.equal(r.dismissed,false);assert.equal(o.board.lowConfidenceDays,0);});

test('staff skill and delegation produce transparent modifiers',()=>{const s=setup(),o=ensureClubOffice(s).office;o.staff.find(x=>x.id==='coach').rating=90;o.staff.find(x=>x.id==='assistant').rating=80;o.delegation['match-preparation']=true;const m=calculateStaffPerformanceModifiers(s);assert.equal(m.training,8);assert.equal(m.matchPreparation,6);assert.equal(m.recovery,0);});


test('daily coaching and physio effects improve damistes gradually and only once per day',()=>{
 const s=setup(),o=ensureClubOffice(s).office,club=s.divisions.flatMap(d=>d.clubs).find(c=>c.id===s.userClubId);
 o.staff.find(x=>x.id==='coach').rating=100;o.staff.find(x=>x.id==='physio').rating=100;o.facilities.training=10;
 const before=club.damistes.map(p=>({level:p.level,form:p.form}));
 const first=processDailyStaffDevelopment(s);assert.equal(first.processed,true);assert.ok(first.developmentPerDay>0);assert.ok(first.recoveryPerDay>0);
 assert.ok(club.damistes.every((p,i)=>p.form>before[i].form));
 assert.equal(processDailyStaffDevelopment(s).reason,'already-processed');
 s.calendar.currentDay+=1;s.day+=1;const second=processDailyStaffDevelopment(s);assert.equal(second.processed,true);
 assert.ok(club.damistes.every(p=>Number.isFinite(p.staffDevelopmentProgress)));
 const initialLevel=club.damistes[0].level;
 for(let i=0;i<10;i++){s.calendar.currentDay+=1;s.day+=1;processDailyStaffDevelopment(s);}
 assert.ok(club.damistes[0].level>=initialLevel);
});

test('delegated assistant preparation creates a bounded sporting bonus',()=>{
 const s=setup(),o=ensureClubOffice(s).office;o.staff.find(x=>x.id==='assistant').rating=100;
 assert.equal(getStaffMatchPreparationBonus(s),0);o.delegation['match-preparation']=true;
 assert.equal(getStaffMatchPreparationBonus(s),2.5);o.staff.find(x=>x.id==='assistant').rating=1;
 assert.ok(getStaffMatchPreparationBonus(s)>=-2.5);
});
