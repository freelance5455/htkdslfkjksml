import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState } from '../src/store.js';
import { generateSeasonCalendar } from '../src/calendar.js';
import { createFederalCupSeason, recordFederalCupResult } from '../src/federal-cup.js';
import { simulateFederalCupRound, recordPlayedGame } from '../src/season-engine.js';

test('le tour de Coupe Fédéral simule automatiquement les matchs IA et réserve celui du club dirigé', () => {
  const state = createInitialState();
  generateSeasonCalendar(state); createFederalCupSeason(state);
  state.calendar.currentDay = state.calendar.fixtures.find(f => f.competitionId === 'coupe-federal').scheduledDay;
  const before = state.divisions.flatMap(d => d.clubs).map(c => c.played).reduce((a,b)=>a+b,0);
  const result = simulateFederalCupRound(state);
  assert.equal(result.simulated.length, 17);
  assert.ok(result.userFixture);
  assert.equal(result.complete, false);
  assert.equal(state.calendar.fixtures.filter(f => f.competitionId === 'coupe-federal' && f.status === 'played').length, 17);
  const after = state.divisions.flatMap(d => d.clubs).map(c => c.played).reduce((a,b)=>a+b,0);
  assert.equal(after, before);
});

test('le match manuel du club dirigé qualifie un seul club et ouvre le tour suivant quand il est complet', () => {
  const state = createInitialState();
  generateSeasonCalendar(state); createFederalCupSeason(state);
  const cup = state.competitions.find(c => c.id === 'coupe-federal');
  const firstRound = cup.rounds[0];
  for (const id of firstRound.fixtureIds) {
    const f = state.calendar.fixtures.find(x => x.id === id);
    if (f.home === state.userClubId || f.away === state.userClubId) continue;
    // Résultats des rencontres IA du tour.
    recordFederalCupResult(state, id, 1, 0, { winnerId: f.home });
  }
  const userFixture = state.calendar.fixtures.find(f => f.competitionId === 'coupe-federal' && f.status === 'scheduled' && (f.home === state.userClubId || f.away === state.userClubId));
  assert.ok(userFixture);
  state.calendar.currentDay = userFixture.scheduledDay;
  const result = recordPlayedGame(state, userFixture.id, 1, { arena: 'terrestrial' });
  assert.equal(result.accepted, true);
  assert.equal(userFixture.status, 'played');
  assert.equal(cup.rounds.length, 2);
});

test('une rencontre automatique de Coupe Fédéral utilise le moteur de dames et son résultat reste distinct du championnat', async () => {
  const { simulateFixture } = await import('../src/season-engine.js');
  const state = createInitialState();
  generateSeasonCalendar(state); createFederalCupSeason(state);
  const cup = state.competitions.find(c => c.id === 'coupe-federal');
  const fixture = state.calendar.fixtures.find(f => f.id === cup.rounds[0].fixtureIds[0]);
  const home = state.divisions.flatMap(d => d.clubs).find(c => c.id === fixture.home);
  const leaguePlayed = home.played;
  assert.equal(simulateFixture(state, fixture.id), true);
  assert.equal(fixture.status, 'played');
  assert.equal(fixture.matchDetails.engine, 'cgd-draughts-ai-v1');
  assert.equal(home.played, leaguePlayed);
  assert.equal(home.competitionStats['coupe-federal'].played, 1);
});
