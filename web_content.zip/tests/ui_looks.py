"""Vzhled věže podle úrovně/větve (looks), design Základnae, export jen jedné položky:  python3 -I tests/ui_looks.py"""
import glob, json
from playwright.sync_api import sync_playwright
exe = (glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome') or [None])[0]
SH = '/home/claude/BubbleDefence/tests/shots/'
errs, results = [], []
def check(n, c, x=''): results.append(bool(c)); print(('OK   ' if c else 'FAIL ') + n + (' ' + str(x) if x != '' else ''))
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=exe, args=['--no-sandbox'])
    ctx = b.new_context(viewport={'width': 1440, 'height': 860}); ctx.grant_permissions(['clipboard-read', 'clipboard-write'])
    pg = ctx.new_page()
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type in ('error', 'warning') and 'willReadFrequently' not in m.text else None)
    pg.goto('file:///home/claude/BubbleDefence/index.html'); pg.wait_for_selector('.content:not(.hidden) .intro')
    # --- design základní věže je v datech hry i bez Studia ---
    check('Základna má vlastní vzhled (bez zapnutého Studia)', pg.evaluate('BD.studio.enabled') is False and pg.evaluate("!!BD.data.towers.base.sprite && BD.data.towers.base.sprite.nodes.length") == 2)
    img = lambda ang: pg.evaluate("""(a => { const c = document.createElement('canvas'); c.width = c.height = 120; const x = c.getContext('2d'); const t = { type: 'base', branch: null, boost: 1, x: 0.2, y: 0.2, size: 2, level: 1, tier: 0, angle: a, cool: 0 }; t.s = BD.systems.towers.stats(t); t.hp = t.s.hp; BD.render.draw.tower(x, t, 26); const d = x.getImageData(0, 0, 120, 120).data; let n = 0; for (let i = 3; i < d.length; i += 4) if (d[i] > 0) n++; return [n, Array.from(d).join(',').length, d.slice(0).reduce((s, v, i) => s + (i & 3 ? (i & 3) < 3 ? v : 0 : v), 0)]; })(ANG)""".replace('ANG', str(ang)))
    a0, a1 = img(0), img(2.0)
    check('věž se kreslí a otáčí se jen hlava (obrázek se liší, počet pixelů tělesa je stejný řádově)', a0[0] > 500 and a0[2] != a1[2], (a0, a1))
    # --- Studio ---
    pg.click('text=Nová lokální hra'); pg.wait_for_selector('.content:not(.hidden) .menu'); pg.wait_for_timeout(300)
    pg.keyboard.type('terminal', delay=40); pg.keyboard.press('Backquote'); pg.wait_for_timeout(300); pg.keyboard.type('studio'); pg.keyboard.press('Enter'); pg.wait_for_timeout(250); pg.keyboard.press('Backquote'); pg.wait_for_timeout(300)
    pg.click('.mi:has-text("Studio")'); pg.wait_for_selector('.stv'); pg.wait_for_timeout(300)
    pg.click('[data-tab=towers]'); pg.wait_for_timeout(200); pg.click('.stu-item[data-id=base]'); pg.wait_for_timeout(300)
    check('Studio: Základna ukazuje svůj vzhled a pruh stupňů', pg.locator('[data-role=slots]').count() == 1 and pg.locator('[data-slot=base]').count() == 1 and pg.evaluate('BD.debugStudio.sp.nodes.length') == 2)
    pg.select_option('[data-role=new-lv]', '3'); pg.click('[data-act=look-add]'); pg.wait_for_timeout(300)
    check('přidán vzhled pro úroveň 3 (kopie výchozího) a je vybraný', pg.locator('[data-slot="0"]').count() == 1 and pg.evaluate('BD.debugStudio.slot') == '0' and pg.evaluate("BD.studio.value('towers','base','looks').length") == 1)
    pg.evaluate("(() => { const d = BD.debugStudio; const head = d.sp.nodes.find(n => n.name === 'Hlava'); head.children[0].children[0].fill.stops[0][1] = '#ff0000'; d.commit(); })()"); pg.wait_for_timeout(200)
    tw = lambda lv, br=None: pg.evaluate("(() => { const t = { type: 'base', level: %d, branch: %s }; const s = BD.systems.towers.look(t); return s && s.nodes.find(n => n.name === 'Hlava').children[0].children[0].fill.stops[0][1]; })()" % (lv, json.dumps(br)))
    c1, c2, c3, c4 = tw(1), tw(2), tw(3), tw(4)
    check('úroveň 1–2 mají výchozí vzhled, 3 a 4 červený (od úrovně 3)', c1 == c2 and c1 != '#ff0000' and c3 == '#ff0000' and c4 == '#ff0000', (c1, c2, c3, c4))
    # vzhled jen pro větev
    pg.evaluate("(() => { const lk = JSON.parse(JSON.stringify(BD.studio.value('towers','base','looks'))); const sp = JSON.parse(JSON.stringify(BD.data.towers.base.sprite)); sp.nodes.find(n => n.name === 'Hlava').children[0].children[0].fill.stops[0][1] = '#00ff00'; lk.push({ level: 2, branch: 'b', sprite: sp }); BD.studio.set('towers','base','looks', lk); })()"); pg.wait_for_timeout(200)

    check('vzhled větve B od úrovně 2 má přednost, jiné větve ne', tw(2, 'b') == '#00ff00' and tw(3, 'b') == '#00ff00' and tw(3, 'a') == '#ff0000' and tw(2, 'a') == c1 and tw(4, 'c') == '#ff0000')
    check('věž ve hře se kreslí podle úrovně (obrázek úrovně 3 ≠ úrovně 1)', pg.evaluate("""(() => { const px = lv => { const c = document.createElement('canvas'); c.width = c.height = 100; const x = c.getContext('2d'); const t = { type: 'base', branch: null, boost: 1, x: 0, y: 0, size: 2, level: lv, tier: 0, angle: 0, cool: 0 }; t.s = BD.systems.towers.stats(t); t.hp = t.s.hp; BD.render.draw.tower(x, t, 50); return x.getImageData(0, 0, 100, 100).data.join(','); }; return px(1) !== px(3); })()"""))
    pg.screenshot(path=SH + 'studio_slots.png')
    # --- export jen jedné položky ---
    pg.click('[data-act=stu-io]'); pg.click('[data-act=stu-copy]'); pg.wait_for_timeout(300)
    o = json.loads(pg.evaluate('navigator.clipboard.readText()'))
    check('export jen vybrané položky (výchozí): jediná věž, žádní nepřátelé', list(o['items']['towers'].keys()) == ['base'] and o['items']['enemies'] == {} and list(o['result']['towers'].keys()) == ['base'], list(o['items']['towers'].keys()))
    check('export obsahuje vzhledy stupňů', len(o['result']['towers']['base']['looks']) == 2)
    pg.evaluate('BD.debugStudio.ioOne = false'); pg.click('[data-act=stu-copy]'); pg.wait_for_timeout(300)
    allj = json.loads(pg.evaluate('navigator.clipboard.readText()')); check('bez zaškrtnutí exportuje vše', 'base' in allj['items']['towers'])
    # smazání vzhledu stupně
    pg.evaluate('BD.debugStudio.ioOne = true')
    pg.evaluate("(() => { const it = BD.store.profile.studio.items; Object.keys(it.towers).forEach(k => delete it.towers[k]); BD.studio.apply(); BD.debugStudio.loadSp(); })()"); pg.wait_for_timeout(200)
    check('po vymazání úprav zůstává jen výchozí design věže bez dalších stupňů', pg.evaluate("!BD.data.towers.base.looks") and pg.evaluate("BD.systems.towers.look({type:'base',level:4,branch:'b'}) === BD.data.towers.base.sprite"))
    pg.fill('[data-role=stu-text]', json.dumps(o)); pg.click('[data-act=stu-import]'); pg.wait_for_timeout(300)
    check('import jedné položky vrátí stupně vzhledu a nesmaže ostatní', pg.evaluate("BD.data.towers.base.looks.length") == 2 and pg.evaluate("!!BD.systems.enemies.TYPES.tank"))
    pg.click('[data-slot="0"]'); pg.wait_for_timeout(200); pg.click('[data-act=look-del]'); pg.wait_for_selector('.dlg'); pg.click('.dlg button:has-text("Smazat")'); pg.wait_for_timeout(300)
    check('po smazání vzhledu jedné úrovně zbývá druhý', pg.evaluate("BD.data.towers.base.looks.length") == 1)
    # podvržený import: špatné úrovně a barvy
    evil = {'game': 'BubbleDefence', 'type': 'studio', 'items': {'enemies': {}, 'towers': {'base': {'patch': {'looks': [{'level': 99, 'sprite': o['items']['towers']['base']['patch']['looks'][0]['sprite']}, {'level': 3, 'branch': '<x>', 'sprite': {'nodes': [{'type': 'circle', 'fill': {'stops': [[0, 'url(javascript:1)'], [1, '#fff']]}}]}}, 'bad']}}}}}
    pg.fill('[data-role=stu-text]', json.dumps(evil)); pg.click('[data-act=stu-import]'); pg.wait_for_timeout(250)
    lk = pg.evaluate("JSON.stringify((BD.data.towers.base.looks || []).map(r => [r.level, r.branch]))")
    check('podvržený import: úroveň mimo 2–4 se zahodí, větev se vyčistí, nebezpečná barva zmizí', lk == '[[3,""]]' and 'javascript' not in pg.evaluate('JSON.stringify(BD.data.towers.base.looks)'), lk)
    b.close()
print('\nvýsledek: %d/%d' % (sum(results), len(results)), '| chyby:', errs or 'žádné')
