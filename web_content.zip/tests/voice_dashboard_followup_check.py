from pathlib import Path
root=Path(__file__).resolve().parents[1]
header=(root/'app/platform_header.php').read_text()
nav=(root/'assets/navigation.css').read_text()
voice=(root/'app/voice.php').read_text()
tts=(root/'api/voice/tts.php').read_text()
js=(root/'assets/voice-studio.js').read_text()
assert 'voice_wallet_balance((int)$user[\'id\'])' in header
assert 'topbar-balance-chip' in header and 'topbar-brand-logo' not in header
assert 'topbar-logout-form' not in header and 'sidebar-logout-form' in header
assert 'topbar-balance-chip' in nav and 'sidebar-logout-form' in nav
assert 'HTTP 401' in voice and 'HTTP 403' in voice and 'HTTP 429' in voice
assert 'safeProviderError' in tts
assert 'r.status<500 && r.status!==409' in js
print('PASS: topbar logo/sign-out removed; live wallet balance shown; sign-out retained in sidebar; Fish Audio failures are diagnosed safely; retry key survives server errors.')
