import { Chess } from 'chess.js';
import { tournamentService } from '../src/services/tournamentService';
import { leaderboardService } from '../src/services/leaderboardService';
import { dailyChallengeService } from '../src/services/dailyChallengeService';
import { achievementService } from '../src/services/achievementService';
import { antiCheatService } from '../src/services/antiCheatService';
import { notificationService } from '../src/services/notificationService';
import { TournamentItem } from '../src/types/chess';

console.log('====================================================');
console.log('--- RUNNING STAGE 5: COMPETITIVE CHESS ECOSYSTEM TESTS ---');
console.log('====================================================');

let passedTests = 0;
let totalTests = 0;

function assert(condition: boolean, testName: string) {
  totalTests++;
  if (condition) {
    passedTests++;
    console.log(`[PASS] ${testName}`);
  } else {
    console.error(`[FAIL] ${testName}`);
    throw new Error(`Assertion failed: ${testName}`);
  }
}

// 1. TOURNAMENT REGISTRATION, CAPACITY & DUPLICATION CHECKS
function testTournamentRegistration() {
  console.log('\n--- 1. Testing Tournament Registration & Capacity ---');

  const tourn = tournamentService.createTournament({
    title: 'Test Capacity Masters',
    description: 'Unit testing capacity and duplication rules',
    format: 'swiss',
    organizerId: 'u-org-1',
    organizerName: 'Organizer 1',
    timeControlType: 'blitz',
    initialSeconds: 300,
    incrementSeconds: 0,
    maxParticipants: 3,
    totalRounds: 2,
    isRated: true,
    isPrivate: false,
  });

  // Organizer is automatically first participant
  assert(tourn.participants.length === 1, 'Organizer registered automatically');

  // Register player 2
  const reg2 = tournamentService.registerPlayer(tourn.id, {
    id: 'u-test-2',
    name: 'Player 2',
    rating: 1400,
  });
  assert(reg2.success, 'Player 2 registration succeeds within capacity');

  // Register player 3 (capacity limit reached)
  const reg3 = tournamentService.registerPlayer(tourn.id, {
    id: 'u-test-3',
    name: 'Player 3',
    rating: 1550,
  });
  assert(reg3.success, 'Player 3 registration succeeds at capacity limit');

  // Attempt duplicate registration
  const dupReg = tournamentService.registerPlayer(tourn.id, {
    id: 'u-test-2',
    name: 'Player 2 Again',
    rating: 1400,
  });
  assert(!dupReg.success, 'Duplicate player registration correctly rejected');

  // Attempt over-capacity registration
  const overCapReg = tournamentService.registerPlayer(tourn.id, {
    id: 'u-test-4',
    name: 'Player 4',
    rating: 1600,
  });
  assert(!overCapReg.success, 'Registration past maxParticipants correctly rejected');

  // Withdrawal
  const withdrawRes = tournamentService.withdrawPlayer(tourn.id, 'u-test-3');
  assert(withdrawRes.success, 'Player withdrawal succeeds before start');
  assert(tourn.participants.length === 2, 'Roster shrinks by 1 after withdrawal');
}

// 2. SWISS PAIRING ENGINE & ODD BYE LOGIC
function testSwissPairingAndByes() {
  console.log('\n--- 2. Testing FIDE Swiss Pairings & Bye Logic ---');

  // Create a 5-player Swiss tournament (odd number requiring a bye)
  const tourn: TournamentItem = {
    id: 'TEST-SWISS-ODD',
    title: 'Odd Swiss Test',
    description: 'Testing odd player bye and color balance',
    format: 'swiss',
    organizerId: 'org-test',
    organizerName: 'Test Arbiter',
    timeControlType: 'rapid',
    initialSeconds: 600,
    incrementSeconds: 0,
    maxParticipants: 16,
    minRating: 0,
    maxRating: 3000,
    isRated: true,
    isPrivate: false,
    rulesDescription: 'Standard FIDE',
    totalRounds: 3,
    currentRound: 1,
    registrationStartAt: new Date().toISOString(),
    registrationEndAt: new Date().toISOString(),
    scheduledStartAt: new Date().toISOString(),
    status: 'live',
    participants: [
      {
        id: 'p1', tournamentId: 'TEST-SWISS-ODD', playerId: 'u1', playerName: 'Player A',
        playerRating: 2100, seed: 1, checkedIn: true, score: 0, tieBreakBuchholz: 0,
        tieBreakSonnebornBerger: 0, wins: 0, draws: 0, losses: 0, streak: 0, isEliminated: false, withdrawn: false, registeredAt: ''
      },
      {
        id: 'p2', tournamentId: 'TEST-SWISS-ODD', playerId: 'u2', playerName: 'Player B',
        playerRating: 1900, seed: 2, checkedIn: true, score: 0, tieBreakBuchholz: 0,
        tieBreakSonnebornBerger: 0, wins: 0, draws: 0, losses: 0, streak: 0, isEliminated: false, withdrawn: false, registeredAt: ''
      },
      {
        id: 'p3', tournamentId: 'TEST-SWISS-ODD', playerId: 'u3', playerName: 'Player C',
        playerRating: 1750, seed: 3, checkedIn: true, score: 0, tieBreakBuchholz: 0,
        tieBreakSonnebornBerger: 0, wins: 0, draws: 0, losses: 0, streak: 0, isEliminated: false, withdrawn: false, registeredAt: ''
      },
      {
        id: 'p4', tournamentId: 'TEST-SWISS-ODD', playerId: 'u4', playerName: 'Player D',
        playerRating: 1600, seed: 4, checkedIn: true, score: 0, tieBreakBuchholz: 0,
        tieBreakSonnebornBerger: 0, wins: 0, draws: 0, losses: 0, streak: 0, isEliminated: false, withdrawn: false, registeredAt: ''
      },
      {
        id: 'p5', tournamentId: 'TEST-SWISS-ODD', playerId: 'u5', playerName: 'Player E',
        playerRating: 1400, seed: 5, checkedIn: true, score: 0, tieBreakBuchholz: 0,
        tieBreakSonnebornBerger: 0, wins: 0, draws: 0, losses: 0, streak: 0, isEliminated: false, withdrawn: false, registeredAt: ''
      },
    ],
    rounds: [],
  };

  const round1Pairings = tournamentService.generateSwissPairings(tourn, 1);
  assert(round1Pairings.length === 3, '5 players yield 2 head-to-head matches + 1 bye');

  const byePairing = round1Pairings.find((p) => p.isBye);
  assert(byePairing !== undefined, 'Bye pairing successfully generated for odd count');
  assert(byePairing?.whiteId === 'u5', 'Lowest-rated eligible player (Player E) awarded bye');
  assert(byePairing?.whiteScore === 1.0, 'Bye awards 1.0 full point');
}

// 3. SINGLE ELIMINATION BRACKET ADVANCEMENT
function testEliminationBrackets() {
  console.log('\n--- 3. Testing Single-Elimination Bracket Advancement ---');

  const tourn: TournamentItem = {
    id: 'TEST-KO-CUP',
    title: '4-Player Knockout',
    description: 'Testing winner advancement',
    format: 'single_elimination',
    organizerId: 'org-ko',
    organizerName: 'KO Arbiter',
    timeControlType: 'bullet',
    initialSeconds: 120,
    incrementSeconds: 1,
    maxParticipants: 4,
    minRating: 0,
    maxRating: 3000,
    isRated: true,
    isPrivate: false,
    rulesDescription: 'Knockout',
    totalRounds: 2,
    currentRound: 1,
    registrationStartAt: new Date().toISOString(),
    registrationEndAt: new Date().toISOString(),
    scheduledStartAt: new Date().toISOString(),
    status: 'live',
    participants: [
      { id: 'kp1', tournamentId: 'TEST-KO-CUP', playerId: 'ku1', playerName: 'Seed 1', playerRating: 2000, seed: 1, checkedIn: true, score: 0, tieBreakBuchholz: 0, tieBreakSonnebornBerger: 0, wins: 0, draws: 0, losses: 0, streak: 0, isEliminated: false, withdrawn: false, registeredAt: '' },
      { id: 'kp2', tournamentId: 'TEST-KO-CUP', playerId: 'ku2', playerName: 'Seed 2', playerRating: 1800, seed: 2, checkedIn: true, score: 0, tieBreakBuchholz: 0, tieBreakSonnebornBerger: 0, wins: 0, draws: 0, losses: 0, streak: 0, isEliminated: false, withdrawn: false, registeredAt: '' },
      { id: 'kp3', tournamentId: 'TEST-KO-CUP', playerId: 'ku3', playerName: 'Seed 3', playerRating: 1600, seed: 3, checkedIn: true, score: 0, tieBreakBuchholz: 0, tieBreakSonnebornBerger: 0, wins: 0, draws: 0, losses: 0, streak: 0, isEliminated: false, withdrawn: false, registeredAt: '' },
      { id: 'kp4', tournamentId: 'TEST-KO-CUP', playerId: 'ku4', playerName: 'Seed 4', playerRating: 1400, seed: 4, checkedIn: true, score: 0, tieBreakBuchholz: 0, tieBreakSonnebornBerger: 0, wins: 0, draws: 0, losses: 0, streak: 0, isEliminated: false, withdrawn: false, registeredAt: '' },
    ],
    rounds: [],
  };

  const r1Pairings = tournamentService.generateEliminationPairings(tourn, 1);
  assert(r1Pairings.length === 2, 'Semifinals generates 2 pairings');
  assert(r1Pairings[0].whiteId === 'ku1' && r1Pairings[0].blackId === 'ku4', 'Seed 1 vs Seed 4 seeded pairing');
  assert(r1Pairings[1].whiteId === 'ku2' && r1Pairings[1].blackId === 'ku3', 'Seed 2 vs Seed 3 seeded pairing');
}

// 4. ELO & RATING INTEGRITY
function testRatingCalculation() {
  console.log('\n--- 4. Testing Rating Calculation Integrity ---');

  // Equal players (1500 vs 1500): Win
  const winDelta = leaderboardService.calculateEloDelta(1500, 1500, 1, 32);
  assert(winDelta.delta === 16, 'Equal rating win awards +16 with K=32');
  assert(winDelta.newRating === 1516, 'New rating is 1516');

  // Equal players: Draw
  const drawDelta = leaderboardService.calculateEloDelta(1500, 1500, 0.5, 32);
  assert(drawDelta.delta === 0, 'Equal rating draw awards 0 delta');

  // Equal players: Loss
  const lossDelta = leaderboardService.calculateEloDelta(1500, 1500, 0, 32);
  assert(lossDelta.delta === -16, 'Equal rating loss deducts 16 points');

  // Underdog victory (1400 defeats 1800)
  const upsetDelta = leaderboardService.calculateEloDelta(1400, 1800, 1, 32);
  assert(upsetDelta.delta >= 28, 'Upset victory against +400 higher opponent awards substantial rating (+28 or more)');
}

// 5. DAILY CHALLENGE VERIFICATION & BOUNDARIES
function testDailyChallenges() {
  console.log('\n--- 5. Testing Daily Challenges & Verified Positions ---');

  const today = dailyChallengeService.getTodayChallenge();
  assert(today !== undefined, 'Today challenge is populated');
  assert(today.fen.length > 10, 'Challenge contains valid FEN string');
  assert(today.solutionMoves.length >= 1, 'Challenge contains verified solution UCI moves');

  // Test position validity with chess.js
  const chess = new Chess(today.fen);
  assert(!chess.isGameOver(), 'Starting puzzle position is an active legal board');

  // Idempotent reward claim
  const firstClaim = dailyChallengeService.recordCompletion(today.id, true, 45);
  assert(firstClaim.isFirstCompletion && firstClaim.xpAwarded > 0, 'First completion awards XP');

  const secondClaim = dailyChallengeService.recordCompletion(today.id, true, 30);
  assert(!secondClaim.isFirstCompletion && secondClaim.xpAwarded === 0, 'Subsequent attempts prevent duplicate XP farming');
}

// 6. ACHIEVEMENTS & PROGRESSION IDEMPOTENCY
function testAchievementsAndProgression() {
  console.log('\n--- 6. Testing Achievements & Progression Idempotency ---');

  const unlockRes1 = achievementService.unlockAchievement('first_checkmate');
  // If already unlocked previously, it should return false; otherwise true.
  assert(typeof unlockRes1.unlocked === 'boolean', 'Unlock method returns boolean status');

  const unlockRes2 = achievementService.unlockAchievement('first_checkmate');
  assert(!unlockRes2.unlocked, 'Unlocking an already-unlocked achievement is strictly idempotent');

  const initialProg = achievementService.getProgression();
  const xpRes = achievementService.addXp(100);
  assert(xpRes.newLevel >= initialProg.level, 'Adding XP increases progression correctly');
}

// 7. ANTI-CHEAT ENGINE DETECTION SANITY CHECKS
function testAntiCheatInspection() {
  console.log('\n--- 7. Testing Anti-Cheat ACPL & Move Variance Detection ---');

  // Sample with robotic fixed timing (std dev < 0.25) and near 0 ACPL
  const roboticTimes = [1.2, 1.21, 1.19, 1.2, 1.22, 1.2, 1.21, 1.2, 1.19, 1.2, 1.21];
  const perfectEvals = [0, 0, 0, -1, 0, 0, 0, 0, -1, 0, 0];

  const flag = antiCheatService.inspectMatchMoves(
    'TEST-MATCH-999',
    'u-bot-test',
    'BotTester',
    roboticTimes,
    perfectEvals
  );

  assert(flag !== null, 'Anomalously uniform move execution and near-zero ACPL flagged for review');
  assert(flag?.riskLevel === 'critical' || flag?.riskLevel === 'high', 'Flagged as high or critical risk');
  assert(flag?.flagReasons.length! >= 1, 'Flag contains transparent evidentiary reasons');

  // Sample with normal human variance (no flag)
  const humanTimes = [5.4, 2.1, 14.8, 1.2, 22.0, 4.3, 8.9, 1.5, 30.2, 3.4, 7.8];
  const humanEvals = [-10, -25, -5, -45, 0, -15, -60, -10, -30, -5, -20];

  const noFlag = antiCheatService.inspectMatchMoves(
    'TEST-MATCH-888',
    'u-human-test',
    'HumanPlayer',
    humanTimes,
    humanEvals
  );

  assert(noFlag === null, 'Normal human move timing variance and natural ACPL is not falsely flagged');
}

// 8. NOTIFICATIONS DISPATCH & READ STATE
function testNotifications() {
  console.log('\n--- 8. Testing Notifications Dispatch & Unread Management ---');

  const initialUnread = notificationService.getUnreadCount();
  const notif = notificationService.sendNotification(
    'tournament_pairing',
    'Round 3 Live',
    'Your match is starting on Board 1'
  );

  assert(notificationService.getUnreadCount() === initialUnread + 1, 'Unread count increments on dispatch');

  notificationService.markAsRead(notif.id);
  assert(notificationService.getUnreadCount() === initialUnread, 'Unread count decrements on mark-as-read');
}

// Run all test suites
try {
  testTournamentRegistration();
  testSwissPairingAndByes();
  testEliminationBrackets();
  testRatingCalculation();
  testDailyChallenges();
  testAchievementsAndProgression();
  testAntiCheatInspection();
  testNotifications();

  console.log('\n====================================================');
  console.log(`ALL TESTS PASSED: ${passedTests} / ${totalTests} assertions verified.`);
  console.log('====================================================\n');
} catch (error) {
  console.error('\nTEST SUITE FAILED:', error);
  process.exit(1);
}
