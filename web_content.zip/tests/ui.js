const puppeteer=require('/home/claude/.npm-global/lib/node_modules/@mermaid-js/mermaid-cli/node_modules/puppeteer');
let ok=0,bad=0;const T=(n,c)=>{c?ok++:bad++;console.log(c?'PASS':'FAIL',n)};
(async()=>{const b=await puppeteer.launch({headless:'new',executablePath:'/home/claude/.cache/puppeteer/chrome/linux-131.0.6778.204/chrome-linux64/chrome',args:['--no-sandbox']});
const p=await b.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('dialog',d=>d.accept());
await p.goto('file://'+process.cwd()+'/www/index.html');const w=ms=>new Promise(r=>setTimeout(r,ms));
const tab=t=>p.evaluate(t=>document.querySelector('[data-tab='+t+']').click(),t);
const set=(o)=>p.evaluate(o=>{for(const k in o)document.getElementById(k).value=o[k]},o);
const act=(a,extra)=>p.evaluate((a,x)=>{const e=[...document.querySelectorAll('[data-a="'+a+'"]')].find(b=>!x||b.closest('tr')&&b.closest('tr').innerText.includes(x));e.click()},a,extra);
const txt=()=>p.evaluate(()=>document.getElementById('app').innerText.replace(/\s+/g,' '));
const stat=l=>p.evaluate(l=>{const s=[...document.querySelectorAll('.stat')].find(x=>x.innerText.startsWith(l));return s?s.innerText.replace(/\s+/g,' '):''},l);
// stock in
await tab('stock');await set({fItem:'Chair',fBrand:'A',fQty:100});await act('saveAdd');
T('stock added shows 100',(await txt()).includes('Chair')&&(await txt()).includes('100'));
// sale
await tab('sale');await set({fItem:'Chair',fBrand:'A',fQty:10,fRate:100});await act('saveSale');
T('sale appears in Sales list',(await txt()).includes('₹1,000'));
await tab('dashboard');T('dashboard Today Sale ₹1,000',(await stat('Today Sale')).includes('₹1,000'));
T('stock 90 on dashboard',(await txt()).includes('Chair A 90')||(await txt()).includes('Chair A 90'));
// same item other rate
await tab('sale');await set({fItem:'Chair',fBrand:'A',fQty:5,fRate:200});await act('saveSale');
await tab('dashboard');T('today = 2000',(await stat('Today Sale')).includes('₹2,000'));
// edit
await tab('sale');await act('edit','₹200');await set({fRate:300});await act('saveSale');
await tab('dashboard');T('edit -> 2500',(await stat('Today Sale')).includes('₹2,500'));
// delete
await tab('sale');await act('del','₹300');await tab('dashboard');T('delete -> 1000',(await stat('Today Sale')).includes('₹1,000'));
// labour
await tab('labour');await set({lnew:'Ram'});await act('addL');await act('openL');
await set({lItem:'Chair',lBrand:'A',lTaken:20,lSold:12,lRate:100});await act('addLine');
await set({fOn:300,fCash:200,fWq:1,fWr:50});await act('saveL');
await tab('dashboard');
T('today sale incl labour 1000+1200=2200',(await stat('Today Sale')).includes('₹2,200'));
await tab('school');await set({fFees:100,fExp:50});await act('saveSch');await tab('prime');await set({fType:'credit',fAmt:500});await act('savePb');await tab('dashboard');T('school/prime on dashboard',(await txt()).includes('School ₹150'));
T('stock 90-20+7 (auto return 20-12-1 wastage)=77',(await txt()).includes('Chair A 77'));
T('returned stock 7 (auto)',(await stat('Returned Stock')).includes('7'));
// persistence
await p.reload();await w(300);T('after reload today sale kept',(await stat('Today Sale')).includes('₹2,200'));
const n=await p.evaluate(()=>JSON.parse(localStorage.getItem('AS_ENTERPRISES_V2')).sales.length);T('no duplicates after reload (1 sale)',n===1);
// invalid
await tab('sale');await set({fItem:'',fQty:'abc',fRate:-5});await act('saveSale');T('invalid blocked',(await p.evaluate(()=>JSON.parse(localStorage.getItem('AS_ENTERPRISES_V2')).sales.length))===1);
T('no JS errors',errs.length===0);if(errs.length)console.log(errs);
console.log(ok+' passed '+bad+' failed');await b.close();process.exit(bad?1:0)})();
