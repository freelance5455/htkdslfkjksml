/**
 * JARVIS Automated Database Tests
 * Verifies initialization, full CRUD on all domain entities, schema compliance, and persistence across reconnects.
 */

import { strict as assert } from 'node:assert';
import fs from 'node:fs';
import path from 'node:path';
import { SqliteDatabase } from '../server/db/sqliteDatabase.ts';
import type { TaskItem } from '../server/types.ts';

const TEST_DB_PATH = './data/test-jarvis-suite.sqlite';

export async function runDatabaseTests(): Promise<{ passed: number; failed: number }> {
  console.log('\n--- Running Database Tests ---');
  let passed = 0;
  let failed = 0;

  async function test(name: string, fn: () => Promise<void>) {
    try {
      await fn();
      console.log(`  [PASS] ${name}`);
      passed++;
    } catch (err: any) {
      console.error(`  [FAIL] ${name}:`, err.message);
      failed++;
    }
  }

  // Clean prior test artifacts
  try {
    if (fs.existsSync(TEST_DB_PATH)) fs.unlinkSync(TEST_DB_PATH);
    if (fs.existsSync(`${TEST_DB_PATH}-wal`)) fs.unlinkSync(`${TEST_DB_PATH}-wal`);
    if (fs.existsSync(`${TEST_DB_PATH}-shm`)) fs.unlinkSync(`${TEST_DB_PATH}-shm`);
  } catch {}

  let testDb = new SqliteDatabase(TEST_DB_PATH);

  // 1. Initialization
  await test('database initialization and schema bootstrapping', async () => {
    await testDb.initialize();
    const health = await testDb.getHealth();
    assert.equal(health.provider, 'sqlite');
    assert.equal(health.status, 'CONNECTED');
    assert.ok(health.recordCounts);
  });

  // 2. Task CRUD
  await test('task item save, retrieval, update, and lifecycle', async () => {
    const taskId = `test_task_${Date.now()}`;
    const task: TaskItem = {
      id: taskId,
      userId: 'usr_jarvis_prime',
      title: 'Automated Suite Task',
      rawPrompt: 'Run full verification',
      status: 'EXECUTING',
      currentStage: 'EXECUTE',
      logs: ['Log entry 1', 'Log entry 2'],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await testDb.saveTask(task);

    const fetched = await testDb.getTask(taskId);
    assert.ok(fetched, 'Task should be fetched');
    assert.equal(fetched.id, taskId);
    assert.equal(fetched.title, 'Automated Suite Task');
    assert.equal(fetched.currentStage, 'EXECUTE');

    // Update status
    await testDb.updateTask(taskId, { status: 'COMPLETED', resultSummary: 'Task finished successfully' });
    const updated = await testDb.getTask(taskId);
    assert.ok(updated);
    assert.equal(updated.status, 'COMPLETED');
    assert.equal(updated.resultSummary, 'Task finished successfully');
  });

  // 3. Memory CRUD
  await test('memory entry save, search retrieval, and deletion', async () => {
    const mem = await testDb.saveMemory({
      id: `mem_test_${Date.now()}`,
      userId: 'usr_jarvis_prime',
      type: 'knowledge',
      key: 'test_key_math',
      content: 'Calculus derivative of sin(x) is cos(x)',
      importance: 8,
      tags: ['math', 'calculus'],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    assert.ok(mem.id);
    const results = await testDb.getMemories({ text: 'Calculus' });
    assert.ok(results.length >= 1);
    assert.equal(results[0].key, 'test_key_math');

    const deleted = await testDb.deleteMemory(mem.id);
    assert.equal(deleted, true);

    const postDelete = await testDb.getMemories({ text: 'Calculus' });
    assert.equal(postDelete.length, 0);
  });

  // 4. Audit Log Recording
  await test('audit log persistence and query', async () => {
    await testDb.recordAuditLog({
      id: `audit_${Date.now()}`,
      timestamp: new Date().toISOString(),
      action: 'SYSTEM_FILE_READ',
      actor: 'test-runner',
      permissionLevel: 'READ',
      details: { path: '/tmp/test.log' },
      status: 'ALLOWED',
    });

    const logs = await testDb.getAuditLogs(10);
    assert.ok(logs.length >= 1);
    assert.equal(logs[0].action, 'SYSTEM_FILE_READ');
    assert.equal(logs[0].status, 'ALLOWED');
  });

  // 5. Chat & Conversation CRUD
  await test('conversation and chat message persistence', async () => {
    const convId = 'conv_test_suite';
    if (testDb.saveConversation) {
      await testDb.saveConversation({
        id: convId,
        userId: 'usr_jarvis_prime',
        title: 'Automated Test Chat',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    }

    await testDb.saveMessage(convId, {
      id: `msg_1_${Date.now()}`,
      role: 'user',
      content: 'Hello JARVIS test',
      timestamp: new Date().toISOString(),
    });

    await testDb.saveMessage(convId, {
      id: `msg_2_${Date.now()}`,
      role: 'assistant',
      content: 'Online and operating within normal parameters.',
      timestamp: new Date().toISOString(),
    });

    const messages = await testDb.getMessages(convId);
    assert.equal(messages.length, 2);
    assert.equal(messages[0].content, 'Hello JARVIS test');
    assert.equal(messages[1].role, 'assistant');
  });

  // 6. Persistence across connection re-open
  await test('persistence verification across instance restart', async () => {
    await testDb.close();

    // Reconnect to the same file
    const reconnectedDb = new SqliteDatabase(TEST_DB_PATH);
    await reconnectedDb.initialize();

    const tasks = await reconnectedDb.getTasks();
    assert.ok(tasks.length >= 1, 'Tasks should persist across database reconnect');

    const health = await reconnectedDb.getHealth();
    assert.equal(health.status, 'CONNECTED');

    await reconnectedDb.close();
  });

  // Cleanup test file
  try {
    if (fs.existsSync(TEST_DB_PATH)) fs.unlinkSync(TEST_DB_PATH);
    if (fs.existsSync(`${TEST_DB_PATH}-wal`)) fs.unlinkSync(`${TEST_DB_PATH}-wal`);
    if (fs.existsSync(`${TEST_DB_PATH}-shm`)) fs.unlinkSync(`${TEST_DB_PATH}-shm`);
  } catch {}

  return { passed, failed };
}
