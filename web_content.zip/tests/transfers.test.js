import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState } from '../src/store.js';
import { proposePlayerExchange, completePlayerExchange, validateTransfers } from '../src/transfers.js';
import { getPlayerContractDemand, proposePlayerContract, signPlayerContract } from '../src/player-contracts.js';

test('un échange accepté conserve deux damistes par club et déplace l’indemnité', () => {
  const s = createInitialState();
  const own = s.divisions[0].clubs[0];
  const other = s.divisions[0].clubs[1];
  const incoming = other.damistes[0], outgoing = own.damistes[0];
  const beforeOwn = own.budget, beforeOther = other.budget;
  const offer = proposePlayerExchange(s, { incomingPlayerId: incoming.id, outgoingPlayerId: outgoing.id, fee: 12000 });
  assert.equal(offer.status, 'accepted-by-selling-club');
  const done = completePlayerExchange(s, offer.id);
  assert.equal(done.fee, 12000);
  assert.equal(own.damistes.length, 2);
  assert.equal(other.damistes.length, 2);
  assert.ok(own.damistes.some(p => p.id === incoming.id));
  assert.ok(other.damistes.some(p => p.id === outgoing.id));
  assert.equal(own.budget, beforeOwn - 12000);
  assert.equal(other.budget, beforeOther + 12000);
  assert.equal(validateTransfers(s), true);
  assert.equal(completePlayerExchange(s, offer.id).id, done.id);
});

test('une indemnité hors budget ou une clause de non-transfert bloque la proposition', () => {
  const s = createInitialState();
  const own = s.divisions[0].clubs[0], other = s.divisions[0].clubs[1];
  assert.throws(() => proposePlayerExchange(s, { incomingPlayerId: other.damistes[0].id, outgoingPlayerId: own.damistes[0].id, fee: own.budget + 1 }), /budget/);
  own.damistes[0].contract = { status: 'active', clauses: { noTransfer: true } };
  assert.throws(() => proposePlayerExchange(s, { incomingPlayerId: other.damistes[0].id, outgoingPlayerId: own.damistes[0].id, fee: 0 }), /interdit son transfert/);
});

test('le vendeur refuse une compensation insuffisante pour un joueur de niveau supérieur', () => {
  const s = createInitialState();
  const own = s.divisions[0].clubs[0], other = s.divisions[0].clubs[1];
  own.damistes[0].level = 30; other.damistes[0].level = 90;
  const offer = proposePlayerExchange(s, { incomingPlayerId: other.damistes[0].id, outgoingPlayerId: own.damistes[0].id, fee: 0 });
  assert.equal(offer.status, 'rejected-by-selling-club');
  assert.throws(() => completePlayerExchange(s, offer.id), /n’a pas accepté/);
});

test('les clauses négociées sont archivées dans le contrat signé', () => {
  const s = createInitialState();
  const player = s.divisions[0].clubs[0].damistes[0];
  const demand = getPlayerContractDemand(s, player.id);
  const clauses = { releaseClause: 80000, appearanceBonus: 250, loyaltyBonus: 500, annualRaisePercent: 3, noTransfer: false };
  const n = proposePlayerContract(s, player.id, { ...demand, clauses });
  const contract = signPlayerContract(s, n.id);
  assert.deepEqual(contract.clauses, clauses);
  assert.equal(contract.expiresSeason, s.season + demand.duration);
});
