/**
 * JARVIS Task #11 Validation Suite
 * Universal Knowledge, Voice, Files, Web Research, Advanced Workspace & System Integrity:
 * 1. Universal Resource Engine (₹0 genuine free platforms, accurate pricing tags, strict copyright boundary)
 * 2. Strict Anti-Piracy & Anti-Circumvention (Refusal of torrents/cracks, offering lawful alternatives)
 * 3. Evidence-Grounded Research Synthesizer (Truth > Impressive Answers, multi-source synthesis, conflict detection)
 * 4. Document Generator Engine (Valid PDF-1.4 generation, Markdown formatting, download endpoints)
 * 5. Secure File Attachment & Sandboxing (Sandboxed storage, path traversal protection, content extraction)
 * 6. Multi-Layer Context Envelope Integration (Attached files formatted in prompt context)
 * 7. Tool Registry Tool Verification (All Task 11 tools registered with REAL execution mode)
 */

import { strict as assert } from 'node:assert';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { db, initializeDatabase } from '../server/db/database.ts';
import { universalResourceEngine } from '../server/discovery/universalResourceEngine.ts';
import { webResearchEngine } from '../server/research/webResearchEngine.ts';
import { fileManager } from '../server/files/fileManager.ts';
import { documentGenerator } from '../server/documents/documentGenerator.ts';
import { contextEngine } from '../server/context/contextEngine.ts';
import { toolRegistry } from '../server/tools/toolRegistry.ts';

export async function runTask11Tests(): Promise<{ passed: number; failed: number }> {
  console.log('\n--- Running Task #11 Universal Knowledge, Files, Research & System Tests ---');
  let passed = 0;
  let failed = 0;

  async function test(name: string, fn: () => Promise<void>) {
    try {
      await fn();
      console.log(`  [PASS] ${name}`);
      passed++;
    } catch (err: any) {
      console.error(`  [FAIL] ${name}:`, err.message);
      failed++;
    }
  }

  await initializeDatabase();

  // 1. Universal Resource Engine: Verified ₹0 Knowledge & Tools
  await test('1. Universal Resource Engine: Returns verified ₹0 resources with legitimate pricing models', async () => {
    const result = await universalResourceEngine.investigate('arxiv.org');
    assert.ok(result.name, 'Should resolve verified resource profile');
    assert.strictEqual(result.pricingModel, 'PERMANENTLY_FREE', 'arXiv must be classified as PERMANENTLY_FREE');
    assert.strictEqual(result.isGenuinelyFree, true, 'Must be marked as genuinely free');
    assert.strictEqual(result.paymentCardRequired, false, 'No payment card required');
    assert.ok(result.officialSource.startsWith('https://'), 'Official source must be a secure https URL');
  });

  // 2. Strict Anti-Piracy Guard
  await test('2. Universal Resource Engine: Refuses piracy / torrent queries with legal alternatives', async () => {
    const piracyQuery = 'download pirate cracked account generator mod apk unlimited money';
    const result = await universalResourceEngine.investigate(piracyQuery);
    assert.strictEqual(result.isGenuinelyFree, false, 'Piracy bypass attempts must not be marked as free');
    assert.strictEqual(result.currentAvailability, 'BLOCKED_OR_REGION_RESTRICTED', 'Must be blocked');
    assert.ok(result.alternatives.length > 0, 'Must provide verified lawful alternatives');
    assert.ok(
      result.usageLimits.includes('Access denied') || result.directAnswer.includes('cannot assist'),
      'Must explain legal and ethical boundary'
    );
  });

  // 3. Evidence-Grounded Research Synthesizer
  await test('3. Research Synthesizer: Synthesizes web research with confidence and source citations', async () => {
    const report = await webResearchEngine.conductResearch({
      query: 'Quantum computing developments in 2026',
      maxSources: 4,
    });
    assert.ok(report.query, 'Report must have a query');
    assert.ok(report.conciseSummary, 'Report must have a concise summary');
    assert.ok(Array.isArray(report.citations), 'Report must contain citations array');
    assert.ok(report.citations.length > 0, 'Report must cite at least one source');
    assert.ok(report.synthesisConfidence >= 0.5, 'Report should have measurable confidence');
  });

  // 4. Document Generator Engine - PDF & Markdown
  await test('4. Document Generator: Produces valid PDF-1.4 spec bytes and Markdown documents', async () => {
    const pdfDoc = await documentGenerator.generateDocument({
      title: 'JARVIS Task 11 Verification Report',
      format: 'pdf',
      content: 'This is a verified system status report compiled for Aaradhy Parmar (Founder).',
    });
    assert.ok(pdfDoc.id, 'Document must have an ID');
    assert.strictEqual(pdfDoc.format, 'pdf');
    assert.ok(pdfDoc.downloadUrl.includes('/api/documents/'), 'Download URL must be populated');

    // Verify raw file exists and starts with %PDF-1.4
    const res = await documentGenerator.getDocumentBuffer(pdfDoc.id);
    assert.ok(res, 'Document buffer must be retrieved');
    const header = res.buffer.subarray(0, 8).toString('utf-8');
    assert.ok(header.startsWith('%PDF-1.4'), 'PDF file must begin with valid %PDF-1.4 header');

    // Test Markdown generation
    const mdDoc = await documentGenerator.generateDocument({
      title: 'System Architecture Notes',
      format: 'md',
      content: '# Architecture Overview\n- Layer 1: Context Engine\n- Layer 2: Tool Registry',
    });
    assert.strictEqual(mdDoc.format, 'md');
    assert.ok(mdDoc.sizeBytes > 0, 'Markdown document must have non-zero size');
  });

  // 5. Secure File Attachment & Sandboxing
  await test('5. File Manager: Uploads, stores in sandboxed storage, and parses files', async () => {
    const textContent = 'JARVIS OS Core Systems: Multi-Agent Orchestration & Sandboxed Execution.';
    const buffer = Buffer.from(textContent, 'utf-8');

    const file = await fileManager.uploadFile({
      originalName: 'system_manifest.txt',
      mimeType: 'text/plain',
      buffer,
    });

    assert.ok(file.id, 'File must be assigned an ID');
    assert.strictEqual(file.originalName, 'system_manifest.txt');
    assert.strictEqual(file.fileCategory, 'text');
    assert.strictEqual(file.extractionStatus, 'EXTRACTED');

    // Retrieve file buffer
    const retrieved = await fileManager.getFileBuffer(file.id);
    assert.ok(retrieved, 'Must be able to retrieve stored buffer');
    assert.strictEqual(retrieved.buffer.toString('utf-8'), textContent);

    // Clean up
    await fileManager.deleteFile(file.id);
    const afterDelete = await fileManager.getFileBuffer(file.id);
    assert.strictEqual(afterDelete, null, 'File must be removed after deletion');
  });

  // 6. Context Engine Enrichment with Attached Files
  await test('6. Context Engine: Injects attached files into prompt context envelope', async () => {
    const convId = `conv_test_ctx_${Date.now()}`;
    const file = await fileManager.uploadFile({
      originalName: 'research_memo.md',
      mimeType: 'text/markdown',
      buffer: Buffer.from('Key finding: Autonomous agent consensus is 99.8% safe.', 'utf-8'),
      conversationId: convId,
    });

    const envelope = await contextEngine.buildContext({
      userPrompt: 'Summarize attached memo',
      conversationId: convId,
      userId: 'usr_jarvis_prime',
    });

    assert.ok(envelope.attachedFiles, 'Context envelope must contain attachedFiles array');
    assert.ok(envelope.attachedFiles.length > 0, 'Should find the attached file for conversation');
    assert.strictEqual(envelope.attachedFiles[0].originalName, 'research_memo.md');

    assert.ok(
      envelope.formattedPrompt.includes('ATTACHED WORKSPACE FILES & DOCUMENTS'),
      'Formatted prompt must include attached files section'
    );
    assert.ok(envelope.formattedPrompt.includes('research_memo.md'), 'Formatted prompt must cite file name');

    // Clean up
    await fileManager.deleteFile(file.id);
  });

  // 7. Tool Registry Tool Verification
  await test('7. Tool Registry: Contains document_generator, research_synthesizer & universal_resource tools', async () => {
    const tools = toolRegistry.getAllDefinitions();
    const docGen = tools.find((t) => t.name === 'document_generator');
    const researchTool = tools.find((t) => t.name === 'web_research_synthesizer');
    const resourceTool = tools.find((t) => t.name === 'resource_investigation' || t.name === 'universal_resource_investigator');
    const fileInspector = tools.find((t) => t.name === 'file_content_inspector');

    assert.ok(docGen, 'document_generator tool must be registered');
    assert.strictEqual(docGen?.permissionLevel, 'SAFE_WRITE');
    assert.strictEqual(docGen?.executionStatus, 'REAL');

    assert.ok(researchTool, 'web_research_synthesizer tool must be registered');
    assert.strictEqual(researchTool?.executionStatus, 'REAL');

    assert.ok(resourceTool, 'resource_investigation tool must be registered');
    assert.strictEqual(resourceTool?.executionStatus, 'REAL');

    assert.ok(fileInspector, 'file_content_inspector tool must be registered');
    assert.strictEqual(fileInspector?.executionStatus, 'REAL');
  });

  // 8. Android Companion Architecture & Voice Protocol Specification
  await test('8. Android Companion Architecture: Manifest, ForegroundService & Gradle compliance', async () => {
    const manifestPath = path.resolve('android-companion/app/src/main/AndroidManifest.xml');
    assert.ok(fs.existsSync(manifestPath), 'AndroidManifest.xml must exist');
    const manifestXml = fs.readFileSync(manifestPath, 'utf-8');

    assert.ok(manifestXml.includes('RECORD_AUDIO'), 'Must declare RECORD_AUDIO permission');
    assert.ok(manifestXml.includes('FOREGROUND_SERVICE'), 'Must declare FOREGROUND_SERVICE permission');
    assert.ok(
      manifestXml.includes('FOREGROUND_SERVICE_MICROPHONE'),
      'Must declare FOREGROUND_SERVICE_MICROPHONE for Android 14+'
    );
    assert.ok(
      manifestXml.includes('foregroundServiceType="microphone"'),
      'Service must declare foregroundServiceType="microphone"'
    );
    assert.ok(manifestXml.includes('android.intent.action.ASSIST'), 'Must declare ASSIST intent');
    assert.ok(manifestXml.includes('android.intent.action.VOICE_COMMAND'), 'Must declare VOICE_COMMAND intent');

    // Kotlin Sources
    const serviceKt = path.resolve(
      'android-companion/app/src/main/java/ai/jarvis/companion/JarvisAssistantService.kt'
    );
    const mainKt = path.resolve('android-companion/app/src/main/java/ai/jarvis/companion/MainActivity.kt');
    assert.ok(fs.existsSync(serviceKt), 'JarvisAssistantService.kt must exist');
    assert.ok(fs.existsSync(mainKt), 'MainActivity.kt must exist');

    // Gradle Spec
    const appGradle = path.resolve('android-companion/app/build.gradle');
    assert.ok(fs.existsSync(appGradle), 'app/build.gradle must exist');
    const gradleContent = fs.readFileSync(appGradle, 'utf-8');
    assert.ok(gradleContent.includes('compileSdk 34'), 'Must target modern compileSdk 34');
    assert.ok(gradleContent.includes('ai.jarvis.companion'), 'Must define correct namespace');
  });

  // 9. Real Tool Execution: document_generator and file_content_inspector
  await test('9. Tool Registry Real Execution: document_generator creates downloadable document', async () => {
    const execResult = await toolRegistry.executeTool('document_generator', {
      title: 'Real Tool Execution Proof',
      format: 'txt',
      content: 'JARVIS autonomous tool execution verified successfully.',
    });

    assert.strictEqual(execResult.success, true, 'Tool execution must succeed');
    assert.ok(execResult.data?.id, 'Result must contain generated document ID');
    assert.ok(execResult.data?.downloadUrl, 'Result must contain download URL');

    // Clean up document from DB if generated
    if (db.deleteDocument) {
      await db.deleteDocument(execResult.data.id);
    }
  });

  // 10. Sandboxed Path Traversal Security Protection
  await test('10. Security: File and document storage enforces sandboxed boundaries', async () => {
    const invalidId = '../../etc/passwd';
    const badFile = await fileManager.getFileBuffer(invalidId);
    assert.strictEqual(badFile, null, 'Path traversal ID in fileManager must return null');

    const badDoc = await documentGenerator.getDocumentBuffer(invalidId);
    assert.strictEqual(badDoc, null, 'Path traversal ID in documentGenerator must return null');
  });

  // 11. OpenAPI 3.0.3 Specification Contract
  await test('11. OpenAPI Specification: Defines complete REST endpoints, schemas, and parameters', async () => {
    const { JARVIS_OPENAPI_SPEC } = await import('../server/api/openapiRouter.ts');
    assert.strictEqual(JARVIS_OPENAPI_SPEC.openapi, '3.0.3', 'Must be valid OpenAPI 3.0.3');
    assert.ok(JARVIS_OPENAPI_SPEC.paths['/api/status'], 'Must define /api/status');
    assert.ok(JARVIS_OPENAPI_SPEC.paths['/api/chat'], 'Must define /api/chat');
    assert.ok(JARVIS_OPENAPI_SPEC.paths['/api/files/upload'], 'Must define /api/files/upload');
    assert.ok(JARVIS_OPENAPI_SPEC.paths['/api/documents/generate'], 'Must define /api/documents/generate');
    assert.ok(JARVIS_OPENAPI_SPEC.paths['/api/openapi.json'], 'Must define /api/openapi.json');
  });

  // 12. PDF Document Generation & Extraction Integrity
  await test('12. PDF Generation: Produces standard compliant PDF 1.4 buffer with xref table and EOF marker', async () => {
    const pdfDoc = await documentGenerator.generateDocument({
      title: 'JARVIS Technical Specification',
      format: 'pdf',
      content: 'JARVIS 4.6 Autonomous AI OS. Sovereign intelligence for Aaradhy Parmar.',
    });
    assert.ok(pdfDoc.id, 'Must return generated document entity');
    assert.strictEqual(pdfDoc.format, 'pdf');

    const result = await documentGenerator.getDocumentBuffer(pdfDoc.id);
    assert.ok(result && result.buffer, 'Buffer must be retrievable from storage');
    const pdfBuffer = result.buffer;
    const pdfHeader = pdfBuffer.slice(0, 5).toString('ascii');
    assert.strictEqual(pdfHeader, '%PDF-', 'PDF must begin with %PDF- header');
    const pdfTail = pdfBuffer.slice(pdfBuffer.length - 10).toString('ascii');
    assert.ok(pdfTail.includes('%%EOF'), 'PDF must end with %%EOF marker');

    // Clean up
    if (db.deleteDocument) {
      await db.deleteDocument(pdfDoc.id);
    }
  });

  // 13. Master 407-Outcome Audit Engine Contract
  await test('13. Master 407-Outcome Audit Engine: Validates complete 407 outcomes inventory & categories', async () => {
    const { outcomeAuditEngine } = await import('../server/verification/outcomeAudit.ts');
    const summary = outcomeAuditEngine.getSummary();
    assert.strictEqual(summary.totalOutcomes, 407, 'Must audit exactly 407 outcomes');
    assert.ok(summary.verifiedComplete > 300, 'Must have >300 verified complete outcomes');
    assert.strictEqual(summary.missing, 0, 'Must have zero missing outcomes');
    assert.strictEqual(summary.broken, 0, 'Must have zero broken outcomes');
    assert.ok(summary.configurationRequired > 0, 'Must truthfully report configuration required outcomes');
    assert.ok(summary.devicePlatformDependent > 0, 'Must truthfully report device/platform dependent outcomes');

    const categories = outcomeAuditEngine.getCategories();
    assert.ok(categories.length >= 15, 'Must encompass all OS functional categories');
  });

  // 14. Real Media Generation & Video Orchestrator Architecture
  await test('14. Media Engine: Synthesizes real SVG / Imagen visuals and reports truthful video credentials', async () => {
    const { mediaEngine } = await import('../server/media/mediaEngine.ts');
    const imgResult = await mediaEngine.generateImage({
      prompt: 'JARVIS sovereign neural core architecture diagram',
      style: 'diagram',
    });
    assert.ok(imgResult.id, 'Must generate image ID');
    assert.ok(imgResult.svgContent && imgResult.svgContent.includes('<svg'), 'Diagram style must produce valid SVG');

    const videoResult = await mediaEngine.orchestrateVideo({
      prompt: 'Cinematic flyover of holographic intelligence cluster',
      providerPreference: 'luma',
    });
    assert.strictEqual(videoResult.provider, 'luma');
    assert.strictEqual(videoResult.status, 'CONFIG_REQUIRED', 'Must truthfully report CONFIG_REQUIRED when LUMA_API_KEY is not set');
    assert.strictEqual(videoResult.requiredSecret, 'LUMA_API_KEY');
  });

  // 15. Autonomous Coding Agent & AST Validator
  await test('15. Autonomous Coding Agent: Synthesizes multi-file code and validates AST / security rules', async () => {
    const { codingEngine } = await import('../server/code/codingAgent.ts');
    const project = await codingEngine.generateCodeProject({
      objective: 'Calculate prime numbers with memoization',
      language: 'typescript',
      includeTests: true,
    });
    assert.ok(project.files.length >= 2, 'Must generate at least entry file and tests');
    assert.strictEqual(project.validation.syntaxOk, true, 'Synthesized code must pass security syntax validation');

    const diff = codingEngine.generateUnifiedDiff('test.ts', 'const a = 1;', 'const a = 2;');
    assert.ok(diff.unifiedDiff.includes('--- a/test.ts'), 'Must produce unified diff');
  });

  // 16. Autonomous Website Generator
  await test('16. Website Generator: Generates responsive site package with Tailwind and clean HTML/CSS/JS', async () => {
    const { websiteGenerator } = await import('../server/code/websiteGenerator.ts');
    const site = websiteGenerator.generateWebsite({
      title: 'Aaradhy Sovereign Labs',
      theme: 'saas',
      description: 'Autonomous high-performance computing OS',
    });
    assert.ok(site.htmlContent.includes('<!DOCTYPE html>'), 'Must produce valid HTML document');
    assert.ok(site.htmlContent.includes('Plus+Jakarta+Sans'), 'Must use Plus Jakarta Sans typography');
    assert.ok(site.files.length >= 3, 'Must bundle index.html, style.css, app.js, and multi-file project files');
  });

  // 17. Multi-Cloud Deployment Engine Scaffolding
  await test('17. Deployment Engine: Scaffolds Vercel, Netlify, Cloud Run, and GitHub Pages configs', async () => {
    const { deploymentEngine } = await import('../server/deploy/deploymentEngine.ts');
    const vercelConfig = deploymentEngine.scaffoldDeployConfig('vercel');
    assert.strictEqual(vercelConfig.configFile, 'vercel.json');
    assert.ok(vercelConfig.configContent.includes('builds'));

    const cloudRunConfig = deploymentEngine.scaffoldDeployConfig('cloud_run');
    assert.strictEqual(cloudRunConfig.configFile, 'Dockerfile');
    assert.ok(cloudRunConfig.configContent.includes('EXPOSE 3000'));
  });

  // 18. Automation & DAG Workflow Engine
  await test('18. Automation & Workflow Engine: Executes multi-step DAG workflow with step telemetry', async () => {
    const { workflowEngine } = await import('../server/automation/workflowEngine.ts');
    const run = await workflowEngine.executeWorkflow('wf_morning_briefing');
    assert.ok(run.runId, 'Must produce unique run ID');
    assert.strictEqual(run.status, 'COMPLETED', 'Pre-configured workflow must complete');
    assert.ok(Object.keys(run.stepResults).length >= 2, 'Must record multiple step execution results');
  });

  // 19. Android Companion Architecture & Truthful Platform Bounds
  await test('19. Android Companion Bridge: Truthfully reports DEVICE/PLATFORM DEPENDENT when unbridged', async () => {
    const { androidCompanion } = await import('../server/android/androidCompanion.ts');
    const contracts = androidCompanion.getArchitecturalContracts();
    assert.strictEqual(contracts.length, 4, 'Must define 4 core Android companion services');
    
    const screenStatus = androidCompanion.getScreenAwarenessStatus();
    assert.strictEqual(screenStatus.hasActiveBridge, false, 'In web container, active bridge must be false');
    assert.ok(screenStatus.statusMessage.includes('DEVICE/PLATFORM DEPENDENT'), 'Must truthfully disclose platform bounds');

    const cmdResult = androidCompanion.executeDeviceCommand({
      action: 'TAP',
      params: { x: 100, y: 200 },
      requiresPhysicalBridge: true,
    });
    assert.strictEqual(cmdResult.success, false, 'Physical tap must fail in web container without hardware bridge');
    assert.strictEqual(cmdResult.status, 'DEVICE_UNAVAILABLE');
  });

  // 20. Master Real World Scenario: "Ek pizza business website banado"
  await test('20. Master Scenario: "Ek pizza business website banado" triggers WEBSITE_GENERATION and real website synthesis', async () => {
    const { IntentClassifier } = await import('../server/planner/intentClassifier.ts');
    const { PlannerEngine } = await import('../server/planner/plannerEngine.ts');
    const intent = IntentClassifier.analyze('Ek pizza business website banado');

    assert.strictEqual(intent.intentType, 'WEBSITE_GENERATION');
    assert.strictEqual(intent.requiresToolExecution, true);
    assert.strictEqual(intent.recommendedAgent, 'CODING');

    const planner = new PlannerEngine();
    const plan = await planner.composePlan({
      userGoal: 'Ek pizza business website banado',
      intent,
      contextOptions: { targetLanguage: 'hinglish' },
    });

    assert.ok(plan.steps.length >= 1, 'Must have at least 1 plan step');
    assert.strictEqual(plan.steps[0].toolName, 'website_generator', 'Must schedule website_generator tool');
    assert.strictEqual(plan.steps[0].toolInput?.theme, 'ecommerce', 'Pizza business should select ecommerce/food theme');

    // Execute tool directly to verify real generation
    const toolResult = await toolRegistry.executeTool('website_generator', plan.steps[0].toolInput || {});
    assert.strictEqual(toolResult.success, true);
    assert.ok(toolResult.data?.htmlContent.includes('<!DOCTYPE html>'), 'Generated site must contain complete HTML5 doctype');
    assert.ok(toolResult.data?.files.length >= 3, 'Must produce index.html, style.css, and app.js');
  });

  // 21. Master Real World Scenario: "Is text ka PDF bana do"
  await test('21. Master Scenario: "Is text ka PDF bana do" triggers DOCUMENT_GENERATION and generates real downloadable PDF', async () => {
    const { IntentClassifier } = await import('../server/planner/intentClassifier.ts');
    const { PlannerEngine } = await import('../server/planner/plannerEngine.ts');
    const intent = IntentClassifier.analyze('Is text ka PDF bana do: JARVIS sovereign operating system');

    assert.strictEqual(intent.intentType, 'DOCUMENT_GENERATION');
    assert.strictEqual(intent.requiresToolExecution, true);

    const planner = new PlannerEngine();
    const plan = await planner.composePlan({
      userGoal: 'Is text ka PDF bana do: JARVIS sovereign operating system',
      intent,
      contextOptions: { targetLanguage: 'hinglish' },
    });

    assert.strictEqual(plan.steps[0].toolName, 'document_generator');
    assert.strictEqual(plan.steps[0].toolInput?.format, 'pdf');

    const toolResult = await toolRegistry.executeTool('document_generator', plan.steps[0].toolInput || {});
    assert.strictEqual(toolResult.success, true);
    assert.ok(toolResult.data?.downloadUrl, 'Must produce valid download URL');
    assert.ok(toolResult.data?.sizeBytes > 0, 'PDF size must be non-zero');

    // Clean up
    if (db.deleteDocument) {
      await db.deleteDocument(toolResult.data.id);
    }
  });

  // 22. Master Real World Scenario: "Ek portfolio website bana do"
  await test('22. Master Scenario: "Ek portfolio website bana do" triggers WEBSITE_GENERATION with portfolio theme', async () => {
    const { IntentClassifier } = await import('../server/planner/intentClassifier.ts');
    const { PlannerEngine } = await import('../server/planner/plannerEngine.ts');
    const intent = IntentClassifier.analyze('Ek portfolio website bana do');

    assert.strictEqual(intent.intentType, 'WEBSITE_GENERATION');
    assert.strictEqual(intent.requiresToolExecution, true);

    const planner = new PlannerEngine();
    const plan = await planner.composePlan({
      userGoal: 'Ek portfolio website bana do',
      intent,
    });

    assert.strictEqual(plan.steps[0].toolName, 'website_generator');
    assert.strictEqual(plan.steps[0].toolInput?.theme, 'portfolio');
  });

  // 23. Master Real World Scenario: "School website kaise banate hain?" -> EDUCATIONAL, NO GENERATOR TOOLS
  await test('23. Master Scenario: "School website kaise banate hain?" triggers EDUCATIONAL_EXPLANATION with ZERO generator tools', async () => {
    const { IntentClassifier } = await import('../server/planner/intentClassifier.ts');
    const { PlannerEngine } = await import('../server/planner/plannerEngine.ts');
    const intent = IntentClassifier.analyze('School website kaise banate hain?');

    assert.strictEqual(intent.intentType, 'EDUCATIONAL_EXPLANATION', 'How-to query must be classified as EDUCATIONAL_EXPLANATION');
    assert.strictEqual(intent.requiresToolExecution, false, 'Must NOT require tool execution');

    const planner = new PlannerEngine();
    const plan = await planner.composePlan({
      userGoal: 'School website kaise banate hain?',
      intent,
    });

    assert.ok(plan.steps.length >= 1);
    assert.strictEqual(plan.steps[0].toolName, undefined, 'Must NOT invoke generator tool for educational query');
  });

  // 24. Master Real World Scenario: "Ek app bana do"
  await test('24. Master Scenario: "Ek app bana do" triggers APP_GENERATION and executes real app_scaffolder', async () => {
    const { IntentClassifier } = await import('../server/planner/intentClassifier.ts');
    const { PlannerEngine } = await import('../server/planner/plannerEngine.ts');
    const intent = IntentClassifier.analyze('Ek app bana do');

    assert.strictEqual(intent.intentType, 'APP_GENERATION');
    assert.strictEqual(intent.requiresToolExecution, true);

    const planner = new PlannerEngine();
    const plan = await planner.composePlan({
      userGoal: 'Ek app bana do',
      intent,
    });

    assert.strictEqual(plan.steps[0].toolName, 'app_scaffolder');
    const toolResult = await toolRegistry.executeTool('app_scaffolder', plan.steps[0].toolInput || {});
    assert.strictEqual(toolResult.success, true);
    assert.ok(toolResult.data?.files.length >= 2, 'Scaffolded app must include project files');
  });

  // 25. Master Real World Scenario: "Image bana do"
  await test('25. Master Scenario: "Image bana do" triggers IMAGE_GENERATION', async () => {
    const { IntentClassifier } = await import('../server/planner/intentClassifier.ts');
    const { PlannerEngine } = await import('../server/planner/plannerEngine.ts');
    const intent = IntentClassifier.analyze('Neural network architecture ka image bana do');

    assert.strictEqual(intent.intentType, 'IMAGE_GENERATION');
    assert.strictEqual(intent.requiresToolExecution, true);

    const planner = new PlannerEngine();
    const plan = await planner.composePlan({
      userGoal: 'Neural network architecture ka image bana do',
      intent,
    });

    assert.strictEqual(plan.steps[0].toolName, 'image_generator');
  });

  // 26. Master Real World Scenario: "Video bana do" -> Truthful CONFIG_REQUIRED without mock video
  await test('26. Master Scenario: "Video bana do" triggers VIDEO_GENERATION and truthfully reports CONFIG_REQUIRED', async () => {
    const { IntentClassifier } = await import('../server/planner/intentClassifier.ts');
    const { PlannerEngine } = await import('../server/planner/plannerEngine.ts');
    const intent = IntentClassifier.analyze('Ek cinematic space video bana do');

    assert.strictEqual(intent.intentType, 'VIDEO_GENERATION');
    assert.strictEqual(intent.requiresToolExecution, true);

    const planner = new PlannerEngine();
    const plan = await planner.composePlan({
      userGoal: 'Ek cinematic space video bana do',
      intent,
    });

    assert.strictEqual(plan.steps[0].toolName, 'video_generator_orchestrator');
    const toolResult = await toolRegistry.executeTool('video_generator_orchestrator', plan.steps[0].toolInput || {});
    assert.strictEqual(toolResult.success, true);
    assert.strictEqual(toolResult.data?.status, 'CONFIG_REQUIRED', 'Must truthfully report CONFIG_REQUIRED when video API key is missing');
    assert.strictEqual(toolResult.data?.requiredSecret, 'LUMA_API_KEY');
  });

  return { passed, failed };
}
