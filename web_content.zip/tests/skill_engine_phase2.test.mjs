/**
 * WHITE ROOM OS — Phase 2 Skill Engine Granular Unit & Integration Test Suite
 * Explicitly tests all 18 required Phase 2 test cases:
 * 1. Skill creation
 * 2. Subskill creation
 * 3. Prerequisite locking
 * 4. Prerequisite unlocking
 * 5. Mastery gate evaluation
 * 6. Failed test
 * 7. Error creation
 * 8. Remediation creation
 * 9. Corrective task creation & completion
 * 10. Retest blocking before corrective task completion
 * 11. Failed retest escalation
 * 12. Successful retest resolution
 * 13. Mastery transition
 * 14. Maintenance transition & retention session
 * 15. 5-Dimensional progress calculation
 * 16. Persistence & v1->v2+ DB schema migration
 * 17. Backup/restore compatibility
 * 18. Full Integration Flow: Goal -> Capability -> Skill -> Subskill -> Prerequisite -> Training -> Test -> Fail -> Error -> Remediation -> Corrective Task -> Retest -> Pass -> Mastery -> Maintenance
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { createWhiteRoomSystem } from '../src/core/bootstrap.js';

test('P2-01: Skill creation with full domain model fields', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true });
  const skill = await sys.engines.skillEngine.createSkill({
    id: 'skill-test-create',
    name: 'Cryptography & Applied Number Theory',
    description: 'Modular arithmetic, RSA, Diffie-Hellman, AES, SHA',
    capabilityId: 'cap-05-cyber',
    domain: 'Cybersecurity',
    goalId: 'goal-cyber-sec',
    currentLevel: 2,
    targetLevel: 8,
    priority: 1,
    prerequisites: [],
  });
  assert.equal(skill.id, 'skill-test-create');
  assert.equal(skill.status, 'AVAILABLE');
  assert.equal(skill.domain, 'Cybersecurity');
  assert.ok(skill.createdAt && skill.updatedAt);
});

test('P2-02: Subskill creation linked to parent Skill', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true });
  const sub = await sys.engines.skillEngine.createSubskill({
    id: 'sub-test-create',
    skillId: 'skill-cyber-linux',
    name: 'Systemd Services & Journalctl Auditing',
    level: 3,
    prerequisites: [],
  });
  assert.equal(sub.id, 'sub-test-create');
  assert.equal(sub.masteryState, 'AVAILABLE');
  const parent = await sys.db.get('skills', 'skill-cyber-linux');
  assert.ok(parent.subskills.includes('sub-test-create'));
});

test('P2-03: Prerequisite locking prevents training and testing on LOCKED Skill/Subskill', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true });
  const { skillEngine } = sys.engines;

  const dpSkill = await sys.db.get('skills', 'skill-dp-graphs');
  assert.equal(dpSkill.status, 'LOCKED');

  await assert.rejects(
    () => skillEngine.recordTrainingSession({ skillId: 'skill-dp-graphs', durationMinutes: 30, evidenceTitle: 'Blocked' }),
    /is LOCKED/
  );

  const subTrees = await sys.db.get('subskills', 'sub-py-trees');
  assert.equal(subTrees.masteryState, 'LOCKED');

  await assert.rejects(
    () => skillEngine.recordTestAttempt({ skillId: 'skill-python-algo', subskillId: 'sub-py-trees', score: 90, accuracy: 90 }),
    /is LOCKED/
  );
});

test('P2-04: Prerequisite unlocking automatically transitions dependent Subskill/Skill to AVAILABLE', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true });
  const { skillEngine } = sys.engines;

  await skillEngine.recordTestAttempt({
    skillId: 'skill-python-algo',
    subskillId: 'sub-py-arrays',
    score: 92,
    accuracy: 90,
    evidence: 'Mastered arrays',
  });

  const subArrays = await sys.db.get('subskills', 'sub-py-arrays');
  const subTrees = await sys.db.get('subskills', 'sub-py-trees');
  assert.equal(subArrays.masteryState, 'MASTERED');
  assert.equal(subTrees.masteryState, 'AVAILABLE', 'Dependent subskill must unlock to AVAILABLE');
});

test('P2-05: Mastery gate evaluation checks all configurable conditions', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true });
  const gateBefore = await sys.engines.skillEngine.evaluateMasteryGate('skill', 'skill-python-algo');
  assert.equal(gateBefore.passed, false);
  assert.equal(gateBefore.checks.subskillsMastered, false);
  assert.equal(gateBefore.checks.minTestScore, false);
  assert.ok(gateBefore.blockingReasons.length > 0);
});

test('P2-06 & P2-07: Failed test attempt & automatic linked Error creation', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true });
  const res = await sys.engines.skillEngine.recordTestAttempt({
    skillId: 'skill-python-algo',
    subskillId: 'sub-py-arrays',
    score: 58,
    accuracy: 60,
    errorCategory: 'calculation',
    errorDescription: 'Hash collision handling error',
    errorCause: 'Forgot probing loop termination condition',
  });
  assert.equal(res.passed, false);
  assert.ok(res.createdError);
  assert.equal(res.createdError.skillId, 'skill-python-algo');
  assert.equal(res.createdError.subskillId, 'sub-py-arrays');
  assert.equal(res.createdError.linkedTestAttemptId, res.attempt.id);
  assert.equal(res.createdError.category, 'calculation');
  assert.equal(res.createdError.status, 'open');
});

test('P2-08 & P2-09: Remediation plan creation & Corrective task generation/completion', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true });
  const { skillEngine } = sys.engines;

  const failRes = await skillEngine.recordTestAttempt({
    skillId: 'skill-python-algo',
    subskillId: 'sub-py-arrays',
    score: 60,
    accuracy: 65,
  });

  const remRes = await skillEngine.createRemediationPlan({
    errorId: failRes.createdError.id,
    title: 'Fix Array Boundary Logic',
  });
  assert.equal(remRes.remediation.status, 'active');
  assert.equal(remRes.remediation.retestAllowed, false);
  assert.equal(remRes.correctiveTasks.length, 1);

  const compRes = await skillEngine.completeCorrectiveTask(remRes.correctiveTasks[0].id);
  assert.equal(compRes.task.status, 'completed');
  assert.equal(compRes.remediation.retestAllowed, true);
  assert.equal(compRes.remediation.status, 'ready_for_retest');
});

test('P2-10, P2-11 & P2-12: Retest enforcement, Failed Retest escalation, and Successful Retest resolution', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true });
  const { skillEngine } = sys.engines;

  const failRes = await skillEngine.recordTestAttempt({
    skillId: 'skill-python-algo',
    subskillId: 'sub-py-arrays',
    score: 64,
    accuracy: 68,
  });
  const errId = failRes.createdError.id;

  const remRes = await skillEngine.createRemediationPlan({ errorId: errId });

  await assert.rejects(
    () =>
      skillEngine.recordRetestAttempt({
        skillId: 'skill-python-algo',
        subskillId: 'sub-py-arrays',
        linkedErrorId: errId,
        score: 90,
        accuracy: 90,
      }),
    /before completing all Corrective Tasks/
  );

  await skillEngine.completeCorrectiveTask(remRes.correctiveTasks[0].id);

  const failedRetest = await skillEngine.recordRetestAttempt({
    skillId: 'skill-python-algo',
    subskillId: 'sub-py-arrays',
    linkedErrorId: errId,
    score: 70,
    accuracy: 72,
  });
  assert.equal(failedRetest.passed, false);
  assert.equal(failedRetest.updatedError.status, 'escalated');
  assert.equal(failedRetest.updatedError.failureCount, 2);
  assert.ok(failedRetest.spawnedEscalationTask);

  await skillEngine.completeCorrectiveTask(failedRetest.spawnedEscalationTask.id);

  const passedRetest = await skillEngine.recordRetestAttempt({
    skillId: 'skill-python-algo',
    subskillId: 'sub-py-arrays',
    linkedErrorId: errId,
    score: 93,
    accuracy: 91,
  });
  assert.equal(passedRetest.passed, true);
  assert.equal(passedRetest.updatedError.status, 'resolved');
});

test('P2-13 & P2-14: Mastery transition & Maintenance transition with retention tracking', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true });
  const { skillEngine } = sys.engines;

  await skillEngine.recordTestAttempt({
    skillId: 'skill-python-algo',
    subskillId: 'sub-py-arrays',
    score: 91,
    accuracy: 90,
  });
  await skillEngine.recordTrainingSession({
    skillId: 'skill-python-algo',
    subskillId: 'sub-py-trees',
    durationMinutes: 50,
    evidenceTitle: 'Tree traversal implementation',
  });
  await skillEngine.recordTestAttempt({
    skillId: 'skill-python-algo',
    subskillId: 'sub-py-trees',
    score: 90,
    accuracy: 89,
  });

  const masteredSkill = await sys.db.get('skills', 'skill-python-algo');
  assert.equal(masteredSkill.status, 'MASTERED');

  const maintSkill = await skillEngine.transitionToMaintenance('skill', 'skill-python-algo', '2026-10-14');
  assert.equal(maintSkill.status, 'MAINTENANCE');
  assert.equal(maintSkill.maintenanceCriteria.nextReviewDate, '2026-10-28');

  const maintSession = await skillEngine.recordMaintenanceSession({
    skillId: 'skill-python-algo',
    reviewDate: '2026-10-14',
    score: 95,
    retentionEvidence: 'Zero-error timed retention drill',
  });
  assert.equal(maintSession.passed, true);
  assert.equal(maintSession.nextReviewDate, '2026-11-04');
});

test('P2-15, P2-16 & P2-17: 5-Dimensional Progress, DB v2+ Persistence, and Backup/Restore Compatibility', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true });
  const { skillEngine, backupEngine } = sys.engines;

  const prog = await skillEngine.calculateSkillProgress('skill-python-algo');
  assert.equal(typeof prog.activityProgress, 'number');
  assert.equal(typeof prog.learningProgress, 'number');
  assert.equal(typeof prog.competence, 'number');
  assert.equal(typeof prog.mastery, 'number');
  assert.equal(typeof prog.retention, 'number');

  const meta = await sys.db.get('meta', 'schema_info');
  assert.ok(meta.schemaVersion >= 2);

  const backup = await backupEngine.exportBackup();
  assert.ok(backup.schemaVersion >= 2);
  await sys.db.clearAll();
  const restored = await backupEngine.restoreBackup(backup);
  assert.equal(restored.restoredCount, backup.totalRecords);
});

test('P2-18: Full End-to-End Integration Flow (Goal -> Capability -> Skill -> Subskill -> Prerequisite -> Training -> Test -> Fail -> Error -> Remediation -> Corrective Task -> Retest -> Pass -> Mastery -> Maintenance)', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true });
  const { skillEngine } = sys.engines;

  const goalBefore = await sys.db.get('goals', 'goal-math-core');
  assert.ok(goalBefore);

  let subLogic = await sys.db.get('subskills', 'sub-math-logic');
  let subInduction = await sys.db.get('subskills', 'sub-math-induction');
  assert.equal(subLogic.masteryState, 'AVAILABLE');
  assert.equal(subInduction.masteryState, 'LOCKED');

  await skillEngine.recordTrainingSession({
    skillId: 'skill-math-discrete',
    subskillId: 'sub-math-logic',
    durationMinutes: 60,
    evidenceTitle: 'Constructed 10 truth tables & quantifier negations',
  });

  const failAttempt = await skillEngine.recordTestAttempt({
    skillId: 'skill-math-discrete',
    subskillId: 'sub-math-logic',
    score: 68,
    accuracy: 70,
    errorCategory: 'conceptual',
    errorDescription: 'Confused contrapositive with converse in implication proof',
  });
  assert.equal(failAttempt.passed, false);
  assert.ok(failAttempt.createdError);

  const rem = await skillEngine.createRemediationPlan({
    errorId: failAttempt.createdError.id,
    title: 'Implication vs Contrapositive Drill',
  });
  await skillEngine.completeCorrectiveTask(rem.correctiveTasks[0].id, {
    durationMinutes: 35,
    evidenceTitle: 'Verified 8 contrapositive equivalences',
  });

  const retestPass = await skillEngine.recordRetestAttempt({
    skillId: 'skill-math-discrete',
    subskillId: 'sub-math-logic',
    linkedErrorId: failAttempt.createdError.id,
    score: 92,
    accuracy: 90,
  });
  assert.equal(retestPass.passed, true);
  assert.equal(retestPass.updatedError.status, 'resolved');

  subLogic = await sys.db.get('subskills', 'sub-math-logic');
  subInduction = await sys.db.get('subskills', 'sub-math-induction');
  assert.equal(subLogic.masteryState, 'MASTERED');
  assert.equal(subInduction.masteryState, 'AVAILABLE', 'Prerequisite unlocking verified');

  await skillEngine.recordTrainingSession({
    skillId: 'skill-math-discrete',
    subskillId: 'sub-math-induction',
    durationMinutes: 60,
    evidenceTitle: 'Wrote 5 strong induction proofs',
  });
  await skillEngine.recordTestAttempt({
    skillId: 'skill-math-discrete',
    subskillId: 'sub-math-induction',
    score: 95,
    accuracy: 94,
  });

  const masteredMath = await sys.db.get('skills', 'skill-math-discrete');
  assert.equal(masteredMath.status, 'MASTERED');

  await skillEngine.recordMaintenanceSession({
    skillId: 'skill-math-discrete',
    reviewDate: '2026-10-14',
    score: 94,
    retentionEvidence: 'Proved 2 induction theorems from memory',
  });

  const maintainedMath = await sys.db.get('skills', 'skill-math-discrete');
  assert.equal(maintainedMath.status, 'MAINTENANCE');
  assert.equal(maintainedMath.progress.mastery, 100);
  assert.equal(maintainedMath.progress.retention, 94);
});
