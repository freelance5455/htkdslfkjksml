import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const html = await readFile(new URL('../index.html', import.meta.url), 'utf8');

test('interface : retire la largeur minimale fixe qui imposait un défilement global', () => {
  assert.doesNotMatch(html, /body\s*\{[^}]*min-width\s*:\s*720px/s);
  assert.match(html, /overflow-x\s*:\s*hidden/);
});
test('interface : dispose de règles dédiées aux orientations portrait et paysage', () => {
  assert.match(html, /max-width\s*:\s*900px\)\s*and\s*\(orientation\s*:\s*landscape\)/);
  assert.match(html, /max-width\s*:\s*760px\)\s*and\s*\(orientation\s*:\s*portrait\)/);
  assert.match(html, /\.match-layout\s*\{\s*grid-template-columns\s*:\s*minmax\(0,1\.2fr\)\s*minmax\(230px,\.8fr\)/);
});
test('interface : conserve les huit compétitions et les sections de gestion', () => {
  for (const id of ['divisionCards','competitionCards','dameOrPanel','managementPanel','playerContractsPanel','transferMarketPanel','commercialPanel','identityEditorPanel','officialCalendarAdmin','championsLeaguePanel','intergalacticClubsPanel','intergalacticCupPanel','lunarCupPanel','calendarRows','matchBoard']) {
    assert.ok(html.includes(`id="${id}"`), `élément conservé : ${id}`);
  }
  assert.match(html, /Les huit compétitions du CGD/);
});
test('interface : le conseil paysage propose aussi une continuation en portrait', () => {
  assert.match(html, /initLandscapeGuidance\(\)/);
  assert.match(html, /from "\.\/src\/orientation\.js"/);
});
