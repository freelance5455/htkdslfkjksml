"""Duchové ve hře letí skrz skály a věže, zeď je zastaví:  python3 -I tests/ui_ghost.py"""
import glob, json
from playwright.sync_api import sync_playwright
exe = (glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome') or [None])[0]
errs, results = [], []
def check(n, c, x=''): results.append(bool(c)); print(('OK   ' if c else 'FAIL ') + n + (' ' + str(x) if x != '' else ''))
LEVEL = {'w': 12, 'h': 10, 'spawns': [{'side': 'L', 'pos': 8, 'len': 4}], 'exit': {'side': 'R', 'pos': 8, 'len': 4},
         'rocks': [[10, y] for y in range(0, 16)], 'walls': [[14, y] for y in range(0, 14)], 'towers': [], 'lives': 99, 'gold': 321, 'waves': 12}
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=exe, args=['--no-sandbox'])
    pg = b.new_page(viewport={'width': 1280, 'height': 800})
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type in ('error', 'warning') and 'willReadFrequently' not in m.text else None)
    pg.goto('file:///home/claude/BubbleDefence/index.html'); pg.wait_for_selector('.content:not(.hidden) .intro')
    pg.click('text=Nová lokální hra'); pg.wait_for_selector('.content:not(.hidden) .menu'); pg.wait_for_timeout(300)
    pg.click('.mi:has-text("Editor")'); pg.click('.lcard.add'); pg.wait_for_selector('.edv .ed-cv'); pg.wait_for_timeout(300)
    pg.evaluate("(L=>{const l=BD.store.profile.editor.levels[0]; Object.assign(l, L); BD.debugEditor.buildMasks(); BD.debugEditor.changed(true);})(%s)" % json.dumps(LEVEL))
    pg.click('.smap-head .btn.primary'); pg.wait_for_selector('.gv canvas'); pg.wait_for_timeout(500)
    G = lambda js: pg.evaluate("(()=>{const g=BD.debug.game; return %s})()" % js)
    G("(()=>{ BD.systems.enemies.spawn(g,'ghost',1); BD.systems.enemies.spawn(g,'bub',1); g.waveLeft[1]=2; g.wave=1; g.enemies.forEach(e=>e.hp=1e9); g.running=false; })()")
    seen = pg.evaluate("new Promise(r=>{const g=BD.debug.game; let hit=0, n=0; const iv=setInterval(()=>{ g.enemies.forEach(e=>{ if(e.type==='ghost' && g.rock[g.idx(Math.floor(e.x),Math.floor(e.y))]) hit++; }); if(++n>160){clearInterval(iv); r(hit);} }, 50);})")
    pos = G("g.enemies.map(e=>[e.type, +e.x.toFixed(1), +e.y.toFixed(1)])")
    check('duch letěl skrz skály', seen > 0, seen); check('bublina skálou neprošla', G("g.enemies.filter(e=>e.type==='bub').every(e=>!g.rock[g.idx(Math.floor(e.x),Math.floor(e.y))])"))
    pg.screenshot(path='/home/claude/BubbleDefence/tests/shots/ghost.png')
    pg.wait_for_timeout(2500)
    check('duch prošel skalami: nikdy nebyl ve zdi', G("g.enemies.every(e=>!g.wall[g.idx(Math.floor(e.x),Math.floor(e.y))])"))
    b.close()
print('\nvýsledek: %d/%d' % (sum(results), len(results)), '| chyby:', errs or 'žádné')
