'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

function loadCloud(fetchImpl) {
  const session = { access_token: 'test-user-jwt', refresh_token: 'refresh', expires_at: 9999999999 };
  const localStorage = { getItem: key => key === 'mrk-supabase-session-v1' ? JSON.stringify(session) : null, setItem() {}, removeItem() {} };
  const window = { MRK_SUPABASE: { url: 'https://test-project.supabase.co', publishableKey: 'sb_publishable_test' } };
  vm.runInNewContext(fs.readFileSync(require.resolve('../supabase-client.js'), 'utf8'), { window, localStorage, fetch: fetchImpl, Date, JSON, Math, encodeURIComponent, Blob, Promise, Error });
  return window.MRKCloud;
}

const COMPANY = '11111111-2222-4333-8444-555555555555';

test('cloud backup upload is private, authenticated, and unique (no overwrite)', async () => {
  let call;
  const cloud = loadCloud(async (url, options) => { call = { url, options }; return new Response('{"Key":"stored"}', { status: 200 }); });
  const blob = new Blob(['backup'], { type: 'application/json' });
  const result = await cloud.uploadBackup(COMPANY, '1405_backup.json', blob);
  assert.equal(result.path, COMPANY + '/1405_backup.json');
  assert.equal(call.url, 'https://test-project.supabase.co/storage/v1/object/mrk-backups/' + COMPANY + '/1405_backup.json');
  assert.equal(call.options.method, 'POST');
  assert.equal(call.options.headers.Authorization, 'Bearer test-user-jwt');
  assert.equal(call.options.headers['x-upsert'], 'false');
  assert.equal(call.options.body, blob);
});

test('cloud backup listing and download use the selected company and reject cross-company paths', async () => {
  const calls = [];
  const cloud = loadCloud(async (url, options) => {
    calls.push({ url, options });
    if (url.includes('/rest/v1/backup_jobs')) return new Response('[{"status":"COMPLETED"}]', { status: 200 });
    return new Response('backup-content', { status: 200 });
  });
  const rows = await cloud.listBackupJobs(COMPANY, 12);
  assert.equal(rows[0].status, 'COMPLETED');
  assert.match(calls[0].url, new RegExp('/rest/v1/backup_jobs\\?company_id=eq\\.' + COMPANY));
  const blob = await cloud.downloadBackup(COMPANY, COMPANY + '/backup.json');
  assert.equal(await blob.text(), 'backup-content');
  await assert.rejects(cloud.downloadBackup(COMPANY, 'aaaaaaaa-bbbb-4ccc-8ddd-eeeeeeeeeeee/backup.json'), /متعلق به شرکت فعال نیست/);
  assert.equal(calls.length, 2);
});
