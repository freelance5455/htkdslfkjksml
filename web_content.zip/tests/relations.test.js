import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState, loadState } from '../src/store.js';
import { addCareerMessage, getCareerInbox, replyToCareerMessage, recordPressResponse, receiveCommercialOffer, counterCommercialOffer, acceptCommercialOffer, signCommercialOffer, rejectCommercialOffer, generatePostMatchMessages, validateManagementState } from '../src/relations.js';
import { generateSeasonCalendar, recordResult } from '../src/calendar.js';

function offer(id='offer-1', sourceName='Nébula Cola') {
  return { id, kind:'sponsor', sourceName, description:'Proposition entrante de partenariat', terms:{cash:100,duration:2,visibility:'maillot',exclusivity:false}, limits:{maximumCash:140,minimumDuration:1} };
}

test('une réponse à la presse modifie durablement la réputation et archive la déclaration',()=>{
  const s=createInitialState();
  addCareerMessage(s,{id:'press-1',type:'press',from:'Presse',subject:'Après-match',body:'Que répondez-vous ?',choices:[{id:'calm',label:'Réponse mesurée',effects:{mediaReputation:4,boardConfidence:2}}]});
  assert.equal(recordPressResponse(s,'press-1','calm').choiceId,'calm');
  assert.equal(s.management.relations.mediaReputation,54);
  assert.equal(s.management.relations.boardConfidence,52);
  assert.equal(s.management.press.history.length,1);
  assert.equal(recordPressResponse(s,'press-1','calm'),false);
});

test('les messages des joueurs, supporters et de la direction appliquent leurs effets relationnels',()=>{
  const s=createInitialState();
  addCareerMessage(s,{id:'player-1',type:'player',playerId:'p1',from:'Damiste',subject:'Temps de jeu',body:'Je souhaite jouer davantage.',choices:[{id:'reassure',label:'Rassurer',effects:{playerMorale:8}}]});
  addCareerMessage(s,{id:'fans-1',type:'supporters',from:'Supporters',subject:'Résultats',body:'Nous attendons mieux.',choices:[{id:'promise',label:'Promettre',effects:{supporterSatisfaction:5}}]});
  addCareerMessage(s,{id:'board-1',type:'board',from:'Direction',subject:'Objectifs',body:'Nous attendons une réaction.',choices:[{id:'plan',label:'Présenter un plan',effects:{boardConfidence:6}}]});
  replyToCareerMessage(s,'player-1','reassure');replyToCareerMessage(s,'fans-1','promise');replyToCareerMessage(s,'board-1','plan');
  assert.equal(s.management.relations.playerMorale.p1,58);
  assert.equal(s.management.relations.supporterSatisfaction,55);
  assert.equal(s.management.relations.boardConfidence,56);
  assert.equal(getCareerInbox(s,{status:'answered'}).length,3);
});

test('un résultat du club génère une messagerie contextuelle et idempotente',()=>{
  const s=createInitialState();generateSeasonCalendar(s);
  const f=s.calendar.fixtures.find(x=>x.home===s.userClubId);
  assert.equal(recordResult(s,f.id,0,2),true);
  const messages=generatePostMatchMessages(s,f);
  assert.ok(messages.some(x=>x.type==='press'));
  assert.ok(messages.some(x=>x.type==='supporters'));
  assert.ok(messages.some(x=>x.type==='board'));
  assert.ok(messages.some(x=>x.type==='player'));
  assert.deepEqual(generatePostMatchMessages(s,f),[]);
  assert.equal(s.management.processedEvents.length,1);
});

test('les offres commerciales sont uniquement entrantes, cataloguées et sans signature automatique',()=>{
  const s=createInitialState();
  const incoming=receiveCommercialOffer(s,offer());
  assert.equal(incoming.origin,'inbound');assert.equal(incoming.status,'received');
  assert.equal(s.divisions[0].clubs[0].budget,1000000);
  assert.equal(receiveCommercialOffer(s,offer()).id,'offer-1');
  assert.throws(()=>receiveCommercialOffer(s,{...offer('fake','Sponsor inventé')}));
  assert.equal(s.management.commercialContracts.length,0);
});

test('une contre-proposition acceptable attend la signature du manager et crédite le club seulement après signature',()=>{
  const s=createInitialState();receiveCommercialOffer(s,offer());
  const result=counterCommercialOffer(s,'offer-1',{cash:130,duration:1,visibility:'maillot premium',exclusivity:false});
  assert.equal(result.accepted,true);assert.equal(result.offer.status,'partner-accepted');
  assert.equal(s.divisions[0].clubs[0].budget,1000000);
  const contract=signCommercialOffer(s,'offer-1');
  assert.equal(contract.terms.cash,130);
  assert.equal(s.divisions[0].clubs[0].budget,1000130);
  assert.equal(s.management.commercialOffers[0].status,'signed');
  assert.equal(s.management.commercialContracts.length,1);
  assert.equal(signCommercialOffer(s,'offer-1').id,contract.id);
  assert.equal(s.management.commercialContracts.length,1);
});

test('une contre-proposition hors des limites du partenaire est refusée et peut être renégociée',()=>{
  const s=createInitialState();receiveCommercialOffer(s,offer());
  assert.equal(counterCommercialOffer(s,'offer-1',{cash:150,duration:1}).accepted,false);
  assert.equal(s.management.commercialOffers[0].status,'counter-rejected');
  assert.equal(counterCommercialOffer(s,'offer-1',{cash:120,duration:2}).accepted,true);
});

test('une offre refusée ne peut pas être signée',()=>{
  const s=createInitialState();receiveCommercialOffer(s,offer());
  assert.equal(rejectCommercialOffer(s,'offer-1'),true);
  assert.throws(()=>signCommercialOffer(s,'offer-1'));
  assert.equal(s.divisions[0].clubs[0].budget,1000000);
});

test('la migration d’une ancienne sauvegarde ajoute la gestion relationnelle sans toucher au catalogue',()=>{
  const s=createInitialState();delete s.management;const storage={getItem:()=>JSON.stringify(s)};
  const migrated=loadState(storage);assert.ok(migrated.management);assert.equal(migrated.management.relations.boardConfidence,50);
  assert.equal(migrated.world.sponsors.length,12);assert.equal(migrated.world.partners.length,16);
});

test('le validateur refuse les identifiants de messages dupliqués',()=>{
  const s=createInitialState();const message={id:'same',type:'press',from:'Presse',subject:'A',body:'B',choices:[{id:'x',label:'Y',effects:{}}]};
  addCareerMessage(s,message);addCareerMessage(s,{...message,id:'same-2'});s.management.inbox[0].id='same';
  assert.throws(()=>validateManagementState(s));
});

test('la réponse qui protège le groupe restaure le moral des deux damistes du club',()=>{
  const s=createInitialState();const club=s.divisions[0].clubs[0];
  addCareerMessage(s,{id:'press-team',type:'press',clubId:club.id,from:'Presse',subject:'Groupe',body:'Réaction ?',choices:[{id:'protect',label:'Protéger le groupe',effects:{playerMorale:4}}]});
  replyToCareerMessage(s,'press-team','protect');
  assert.equal(s.management.relations.playerMorale[club.damistes[0].id],54);
  assert.equal(s.management.relations.playerMorale[club.damistes[1].id],54);
});

test('le club peut accepter directement une offre entrante et la signature reste unique',()=>{
  const s=createInitialState();receiveCommercialOffer(s,offer('offer-direct'));
  const contract=acceptCommercialOffer(s,'offer-direct');
  assert.equal(contract.status,'active');assert.equal(contract.terms.cash,100);
  assert.equal(s.divisions[0].clubs[0].budget,1000100);
  assert.equal(acceptCommercialOffer(s,'offer-direct').id,contract.id);
  assert.equal(s.management.commercialContracts.length,1);
});

test('les structures commerciales approchent automatiquement le club aux jalons prévus, sans doublon', async()=>{
  const { generateInboundCommercialOffers } = await import('../src/relations.js');
  const s=createInitialState();generateSeasonCalendar(s);
  const userFixtures=s.calendar.fixtures.filter(f=>!f.competitionId&&(f.home===s.userClubId||f.away===s.userClubId)).slice(0,9);
  for(let i=0;i<3;i++)userFixtures[i].status='played';
  const first=generateInboundCommercialOffers(s);
  assert.equal(first.length,1);assert.equal(first[0].origin,'inbound');
  assert.equal(generateInboundCommercialOffers(s).length,0);
  assert.equal(s.divisions[0].clubs[0].budget,1000000);
  for(let i=3;i<6;i++)userFixtures[i].status='played';
  assert.equal(generateInboundCommercialOffers(s).length,1);
  for(let i=6;i<9;i++)userFixtures[i].status='played';
  assert.equal(generateInboundCommercialOffers(s).length,1);
  assert.equal(s.management.commercialOffers.length,3);
  assert.equal(new Set(s.management.commercialOffers.map(x=>x.sourceName)).size,3);
});

test('les matchs du club déclenchent les propositions commerciales entrantes au troisième match', async()=>{
  const s=createInitialState();generateSeasonCalendar(s);
  const userFixtures=s.calendar.fixtures.filter(f=>!f.competitionId&&(f.home===s.userClubId||f.away===s.userClubId)).slice(0,3);
  for(const f of userFixtures){
    f.status='played';f.score=[2,1];
    generatePostMatchMessages(s,f);
  }
  assert.equal(s.management.commercialOffers.length,1);
  assert.equal(s.management.commercialOffers[0].origin,'inbound');
  assert.equal(s.management.commercialContracts.length,0);
});
