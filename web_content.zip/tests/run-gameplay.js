'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(x => x[1]);
const ctx = { console, Date, Math, JSON, Set, Map, Array, Object, String, Number, RegExp, Promise };
ctx.self = ctx;
vm.createContext(ctx);
for (let i = 0; i <= 5; i++) vm.runInContext(scripts[i], ctx, { filename: `inline-${i}.js` });
const { schema: S, engine: E, encounters: X } = ctx.PA;
const now = new Date('2026-11-17T12:00:00');
let st = S.fresh(now);
assert.equal(S.rankFor(1), null); assert.equal(S.rankFor(2), null);
assert.equal(S.rankFor(3), 'E'); assert.equal(S.rankFor(5), 'E');
assert.equal(S.rankFor(6), 'D'); assert.equal(S.rankFor(8), 'D');
assert.equal(S.rankFor(9), 'C'); assert.equal(S.rankFor(11), 'C');
assert.equal(S.rankFor(12), 'B'); assert.equal(S.rankFor(14), 'B');
assert.equal(S.rankFor(15), 'A'); assert.equal(S.rankFor(17), 'A');
assert.equal(S.rankFor(18), 'S');
st.coreTasks = [{id:'core_a',title:'الدراسة',active:true},{id:'core_b',title:'الرياضة',active:true}];
st.lastDate = '2026-11-16'; st.streak = 6; st.completedWeeks = 0; st.weeklyMilestone = 0;
st.coreDays['2026-11-16'] = {doneIds:['core_a','core_b']};
let r = E.rollover(st, new Date('2026-11-17T09:00:00'));
assert.equal(r.status, 'rolled'); assert.equal(st.streak, 7); assert.equal(st.completedWeeks, 1);
assert.equal(st.weeklyCelebration.pending, true);
// Penalty for one missed task: exactly 20 XP and a reset streak.
st = S.fresh(now); st.coreTasks=[{id:'core_a',title:'الدراسة',active:true},{id:'core_b',title:'الرياضة',active:true}];
st.lastDate='2026-11-16'; st.streak=4; st.coreDays['2026-11-16']={doneIds:['core_a']};
E.awardXp(st, new Date('2026-11-16T10:00:00'), 50, {kind:'test',label:'seed'}, 'seed');
r=E.rollover(st,new Date('2026-11-17T09:00:00'));
assert.equal(st.streak,0); assert.equal(st.progress.lifetimeXp,30); assert.equal(st.progress.wallet,30);
assert.equal(st.ledger.filter(e=>e.type==='xp_penalty').reduce((n,e)=>n+e.amount,0),20);
assert.equal(E.audit(st).length,0);
// Recurring side-task rewards: difficulty values, once-per-day dedupe, and next-day eligibility.
st=S.fresh(now);
for (const [difficulty,xp] of [['easy',5],['medium',7],['hard',10]]) {
  const key='side:daily-'+difficulty+':2026-11-17';
  const first=E.awardXp(st,now,xp,{kind:'side_daily_task',ref:'daily-'+difficulty,label:'مهمة جانبية'},key);
  assert.equal(first.ok,true);
  const duplicate=E.awardXp(st,now,xp,{kind:'side_daily_task',ref:'daily-'+difficulty,label:'مهمة جانبية'},key);
  assert.equal(duplicate.reason,'duplicate');
  const nextDay=E.awardXp(st,new Date('2026-11-18T10:00:00'),xp,{kind:'side_daily_task',ref:'daily-'+difficulty,label:'مهمة جانبية'},'side:daily-'+difficulty+':2026-11-18');
  assert.equal(nextDay.ok,true);
}
assert.equal(st.ledger.filter(e=>e.type==='xp_gain'&&e.source&&e.source.kind==='side_daily_task').length,6);
assert.equal(E.audit(st).length,0);
// Do not allow a negative XP balance.
st = S.fresh(now); st.coreTasks=[{id:'core_a',title:'الدراسة',active:true}]; st.lastDate='2026-11-16';
E.rollover(st,new Date('2026-11-17T09:00:00')); assert.equal(st.progress.lifetimeXp,0); assert.equal(st.progress.wallet,0);
// Gate E requires rank E, one full week and two completed goals.
st = S.fresh(now); st.progress.level=3; st.completedWeeks=1; st.goals=[{completed:true},{completed:true}];
let cat=X.catalog(st); assert.equal(cat.dungeons.length,6); assert.equal(cat.bosses.length,6); assert.equal(cat.dungeons[0].unlocked,true);
assert.equal(cat.dungeons[1].unlocked,false);
assert.equal(X.start(st,'dungeon','gate-e',now).ok,true);
for(let i=0;i<st.encounters.active.steps.length;i++) X.toggleStep(st,i,true);
assert.equal(X.complete(st,now).ok,true);
assert.equal(X.catalog(st).bosses[0].unlocked,true);
assert.equal(X.start(st,'boss','boss-e',now).ok,true);
st.encounters.active.assessment={score:85,passed:true,feedback:'تقييم تجريبي واضح'};
assert.equal(X.complete(st,new Date('2026-11-19T12:00:00')).reason,'duration_incomplete');
assert.equal(X.complete(st,new Date('2026-11-20T12:00:00')).ok,true);
assert.equal(st.encounters.completedBosses.length,1);
console.log('RISEUP gameplay tests passed: rank thresholds, weekly streak, -20 XP penalty, no-negative balance, six gates/bosses and multi-day boss duration.');
