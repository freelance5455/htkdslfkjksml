const test = require('node:test');
const assert = require('node:assert/strict');
const { positiveWarehouses, buildRows } = require('../mrk-inventory-view.js');

test('warehouse detail includes only warehouses with positive quantity', () => {
  const warehouses = [{id:'a',name:'انبار الف'},{id:'b',name:'انبار ب'},{id:'c',name:'انبار ج'}];
  const result = positiveWarehouses(warehouses, w => ({a:{q:4,v:40},b:{q:0,v:0},c:{q:-2,v:-20}}[w.id]));
  assert.deepEqual(result.map(x => x.warehouse.id), ['a']);
  assert.equal(result[0].quantity, 4);
});

test('inventory report lists each product once and omits products without positive stock', () => {
  const goods = [{id:'g1',name:'کالای اول'},{id:'g2',name:'کالای دوم'}];
  const warehouses = [{id:'a',name:'الف'},{id:'b',name:'ب'}];
  const rows = buildRows(goods, warehouses, (g,w) => {
    if (g.id === 'g1' && w.id === 'a') return {q:3,v:90};
    if (g.id === 'g1' && w.id === 'b') return {q:0,v:0};
    return {q:-1,v:-10};
  });
  assert.equal(rows.length, 1);
  assert.equal(rows[0].good.id, 'g1');
  assert.equal(rows[0].warehouses.length, 1);
  assert.equal(rows[0].quantity, 3);
  assert.equal(rows[0].average, 30);
});

test('missing and malformed balances are treated as zero and hidden', () => {
  const result = positiveWarehouses([{id:'x'}], () => null);
  assert.deepEqual(result, []);
});
