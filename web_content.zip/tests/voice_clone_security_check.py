from pathlib import Path
root=Path(__file__).resolve().parents[1]
voice=(root/'app/voice.php').read_text()
clone=(root/'api/voice/clone.php').read_text()
tts=(root/'api/voice/tts.php').read_text()
listing=(root/'api/voice/voices.php').read_text()
agent_create=(root/'api/agent/create.php').read_text()
agent_update=(root/'api/agent/update.php').read_text()
agent_session=(root/'api/agent/session.php').read_text()
assert "https://api.fish.audio/model" in voice
assert "'visibility'=>'private'" in voice
assert "'voices'=>$file" in voice and "'train_mode'=>'fast'" in voice
assert 'consent_status' in voice and 'voice-consent-v1' in voice
assert 'fish_audio_user_can_use_voice' in tts and 'fish_audio_user_can_use_voice' in agent_create
assert 'fish_audio_user_can_use_voice' in agent_update and 'fish_audio_user_can_use_voice' in agent_session
assert "if(($voice['visibility']??'')!=='private') return true" in listing
assert 'voice_clone_requests' in clone and 'Idempotency-Key' in clone
assert 'credits_per_voice_clone' in clone
assert clone.index('voice_charge_credits(') < clone.index('fish_audio_create_private_voice(')
assert 'voice_refund_credits' in clone and "status='uncertain'" in clone
print('PASS: private clone creation, consent, per-user voice access, clone idempotency and optional credit pricing.')
