#!/usr/bin/env python3
"""Guard against public first-user admin escalation."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
auth = (root / 'app/auth.php').read_text(encoding='utf-8')
register = (root / 'register.php').read_text(encoding='utf-8')
provision = (root / 'tools-create-admin.php').read_text(encoding='utf-8')
assert "'member','active',now_sql(),now_sql()" in auth
assert "$role=$hasAdmin===0?'admin':'member'" not in auth
assert "if (PHP_SAPI !== 'cli')" in provision
assert "COUNT(*) FROM users WHERE role='admin'" in provision
assert "strlen($password) < 12" in provision
assert 'standard member access' in register
print('PASS: public registration cannot grant admin; first admin is provisioned by CLI with one-admin guard and strong password requirement.')
