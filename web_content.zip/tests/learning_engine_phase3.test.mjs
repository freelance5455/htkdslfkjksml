/**
 * WHITE ROOM OS — Phase 3 Learning Engine Comprehensive Unit & Integration Test Suite
 * Tests all 26 required Phase 3 capabilities + complete End-to-End Learning Pipeline:
 * Goal -> Capability -> Skill -> Subskill -> Learning Objective -> Resource -> Learning Session
 * -> Recall -> Practice -> Evidence -> Test -> Failure -> Error -> Remediation -> Corrective Task
 * -> Retest -> Mastery -> Retention Review
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { createWhiteRoomSystem } from '../src/core/bootstrap.js';

test('P3-01: Learning Objective creation with actionable Target DO Outcome', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true });
  const { learningEngine } = sys.engines;

  const obj = await learningEngine.createLearningObjective({
    id: 'obj-cyber-suid',
    title: 'Identify & Exploit Linux SUID Misconfigurations',
    description: 'Find SUID binaries and analyze privilege escalation vectors',
    goalId: 'goal-cyber-sec',
    capabilityId: 'cap-05-cyber',
    skillId: 'skill-cyber-linux',
    subskillId: 'sub-cyber-cli',
    targetOutcome: 'Audit a Linux filesystem using find -perm -4000 and remediate insecure SUID bits in under 10 minutes',
    difficulty: 6,
    estimatedEffortMin: 60,
    masteryRelevance: 'core',
    prerequisites: [],
  });

  assert.equal(obj.id, 'obj-cyber-suid');
  assert.equal(obj.status, 'NOT_STARTED');
  assert.ok(obj.targetOutcome.includes('find -perm -4000'));
});

test('P3-02: Resource creation and linking to Learning Objective & Skill', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true });
  const { learningEngine } = sys.engines;

  const res = await learningEngine.createResource({
    id: 'res-linux-priv-pdf',
    title: 'Linux Privilege Escalation Handbook',
    type: 'PDF',
    reference: 'local://security/linux-privesc.pdf',
    author: 'Security Lab Team',
    estimatedTimeMin: 45,
    difficulty: 6,
    domain: 'cap-05-cyber',
    skillId: 'skill-cyber-linux',
    subskillId: 'sub-cyber-cli',
    learningObjectives: [],
  });

  const linked = await learningEngine.linkResourceToObjective(res.id, 'obj-py-two-pointers');
  assert.ok(linked.learningObjectives.includes('obj-py-two-pointers'));
});

test('P3-03 & P3-04: Learning Session persistence & Session state transition (Exposure != Mastery)', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true });
  const { learningEngine } = sys.engines;

  const before = await sys.db.get('learning_objectives', 'obj-math-propositional');
  assert.equal(before.status, 'NOT_STARTED');

  const sessRes = await learningEngine.recordLearningSession({
    objectiveId: 'obj-math-propositional',
    resourceId: 'res-math-hammack',
    sessionType: 'LEARN',
    plannedDurationMin: 45,
    actualDurationMin: 45,
    confidence: 85,
    notes: 'Read Chapter 2 on truth tables and De Morgan laws',
  });

  assert.equal(sessRes.session.sessionType, 'LEARN');
  assert.equal(sessRes.objective.status, 'EXPOSED', 'Passive LEARN session must only transition NOT_STARTED -> EXPOSED, never MASTERED');

  const updatedRes = await sys.db.get('resources', 'res-math-hammack');
  assert.equal(updatedRes.status, 'processed');
});

test('P3-05 & P3-06: Active Recall attempt, scoring, and Metacognitive Confidence vs Performance mismatch detection', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true });
  const { learningEngine } = sys.engines;

  const mismatchRes = await learningEngine.recordRecallAttempt({
    objectiveId: 'obj-math-propositional',
    question: 'What is the negation of ∀x (P(x) → Q(x))?',
    expectedAnswer: '∃x (P(x) ∧ ¬Q(x))',
    userAnswer: '∀x (¬P(x) → ¬Q(x))',
    confidence: 90,
    correctness: 50,
  });

  assert.equal(mismatchRes.passed, false);
  assert.equal(mismatchRes.calibration.metacognitiveMismatch, true);
  assert.equal(mismatchRes.calibration.mismatchType, 'OVERCONFIDENT_ILLUSION_OF_COMPETENCE');
  assert.equal(mismatchRes.calibration.calibrationDelta, 40);
  assert.equal(mismatchRes.objective.status, 'WEAK', 'Failed recall must transition objective to WEAK');

  const passRecall = await learningEngine.recordRecallAttempt({
    objectiveId: 'obj-math-propositional',
    question: 'Explain De Morgan law for negating a conjunction ¬(P ∧ Q)',
    expectedAnswer: 'negating conjunction yields disjunction of negations not P or not Q',
    userAnswer: 'negating conjunction yields disjunction of negations not P or not Q',
    confidence: 85,
  });
  assert.equal(passRecall.passed, true);
  assert.ok(passRecall.recallAttempt.correctness >= 85);
});

test('P3-07, P3-08 & P3-09: Flashcard creation, review persistence, Spaced Repetition scheduling & pluggable strategy replacement', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true });
  const { learningEngine, srScheduler } = sys.engines;

  const fc = await learningEngine.createFlashcard({
    id: 'fc-test-sr',
    front: 'What is the time complexity of building a binary heap in-place?',
    back: 'O(N) using bottom-up siftDown',
    explanation: 'Sum of heights of all nodes in a complete binary tree is bounded by O(N)',
    source: 'CLRS Ch 6',
    objectiveId: 'obj-py-two-pointers',
    skillId: 'skill-python-algo',
    subskillId: 'sub-py-arrays',
    difficulty: 5,
    nextReviewDate: '2026-10-14',
  });
  assert.equal(fc.retentionState, 'NEW');

  const rev1 = await learningEngine.reviewFlashcard({
    flashcardId: 'fc-test-sr',
    recallScore: 95,
    confidence: 90,
    reviewDate: '2026-10-14',
  });
  assert.equal(rev1.flashcard.reviewHistory.length, 1);
  assert.equal(rev1.flashcard.retentionState, 'REVIEW');
  assert.equal(rev1.flashcard.interval, 2);
  assert.equal(rev1.flashcard.nextReviewDate, '2026-10-16');

  const rev2 = await learningEngine.reviewFlashcard({
    flashcardId: 'fc-test-sr',
    recallScore: 40,
    confidence: 80,
    reviewDate: '2026-10-16',
  });
  assert.equal(rev2.flashcard.retentionState, 'LAPSED');
  assert.equal(rev2.flashcard.interval, 1);

  let customStrategyCalled = false;
  srScheduler.setStrategy(() => {
    customStrategyCalled = true;
    return {
      passed: true,
      interval: 10,
      repetitionCount: 5,
      easeFactor: 2.5,
      nextReviewDate: '2026-10-26',
      retentionState: 'RETAINED',
      metacognitiveMismatch: false,
      calibrationDelta: 0,
    };
  });

  const revCustom = await learningEngine.reviewFlashcard({
    flashcardId: 'fc-test-sr',
    recallScore: 95,
    confidence: 95,
    reviewDate: '2026-10-16',
  });
  assert.equal(customStrategyCalled, true);
  assert.equal(revCustom.flashcard.interval, 10);
  assert.equal(revCustom.flashcard.retentionState, 'RETAINED');
});

test('P3-10: Feynman Mode explanation produces Remediation on gaps and Evidence on mastery clarity', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true });
  const { learningEngine } = sys.engines;

  const feynGap = await learningEngine.recordFeynmanExplanation({
    objectiveId: 'obj-py-two-pointers',
    explanation: 'We move two pointers inward, but I am unsure why we never miss a pair.',
    confidence: 60,
    clarityScore: 55,
    identifiedGaps: ['Monotonicity proof of pointer elimination'],
  });
  assert.equal(feynGap.passed, false);
  assert.equal(feynGap.feynmanEntry.evaluatorResult, 'needs_remediation');
  assert.ok(feynGap.createdError, 'Feynman gaps must create an ErrorRecord');
  assert.ok(feynGap.createdRemediation, 'Feynman gaps must create a RemediationPlan');

  const corrTaskId = feynGap.createdRemediation.correctiveTaskIds[0];
  await sys.engines.skillEngine.completeCorrectiveTask(corrTaskId);
  await sys.engines.skillEngine.recordRetestAttempt({
    skillId: 'skill-python-algo',
    subskillId: 'sub-py-arrays',
    linkedErrorId: feynGap.createdError.id,
    score: 90,
    accuracy: 90,
  });

  const feynPass = await learningEngine.recordFeynmanExplanation({
    objectiveId: 'obj-py-two-pointers',
    explanation:
      'Because the array is sorted, if sum < target, the current left element paired with any smaller right element is also < target, proving we can safely increment left.',
    confidence: 90,
    clarityScore: 92,
    identifiedGaps: [],
  });
  assert.equal(feynPass.passed, true);
  assert.ok(feynPass.createdEvidence);
  assert.equal(feynPass.createdEvidence.type, 'written_explanation');
});

test('P3-11 & P3-12: Practice Task creation, completion, and Evidence verification (rejecting resource consumption as evidence)', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true });
  const { learningEngine } = sys.engines;

  await assert.rejects(
    () =>
      learningEngine.recordLearningEvidence({
        objectiveId: 'obj-py-two-pointers',
        skillId: 'skill-python-algo',
        type: 'watched_video',
        title: 'Watched a 2-hour video',
      }),
    /does not count as mastery evidence/
  );

  const pTask = await learningEngine.createPracticeTask({
    objectiveId: 'obj-py-two-pointers',
    title: 'Solve Container With Most Water & 3Sum in O(N^2) / O(N)',
    timeEstimateMin: 50,
    evidenceRequirement: 'solved_problem',
  });
  assert.equal(pTask.isPracticeTask, true);

  const comp = await learningEngine.completePracticeTask(pTask.id, {
    durationMinutes: 45,
    outputSubmitted: 'Submitted working Python solutions passing 100% of test cases',
    qualityScore: 95,
  });
  assert.equal(comp.task.status, 'completed');
  assert.equal(comp.evidence.type, 'solved_problem');
});

test('P3-13, P3-14, P3-15, P3-16 & P3-17: Learning Test integration, Failed Test -> Error -> Remediation -> Retest -> Objective Mastery', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true });
  const { learningEngine, skillEngine } = sys.engines;

  await learningEngine.recordRecallAttempt({
    objectiveId: 'obj-py-two-pointers',
    question: 'State the two-pointer invariant',
    expectedAnswer: 'Monotonic search space reduction in O(N)',
    userAnswer: 'Monotonic search space reduction in O(N)',
    confidence: 85,
    correctness: 92,
  });

  const lTest = await learningEngine.createLearningTest({
    id: 'ltest-tp-mastery',
    objectiveId: 'obj-py-two-pointers',
    testType: 'mastery',
    title: 'Two Pointers Mastery Assessment',
    passingScore: 85,
    minAccuracy: 80,
  });
  assert.equal(lTest.testType, 'mastery');

  const failTest = await learningEngine.recordLearningTestAttempt({
    testId: lTest.id,
    objectiveId: 'obj-py-two-pointers',
    testType: 'mastery',
    score: 55,
    accuracy: 60,
    confidence: 95,
  });
  assert.equal(failTest.passed, false);
  assert.equal(failTest.calibration.metacognitiveMismatch, true);
  assert.ok(failTest.createdError, 'Failed learning test must create an Error via Phase 2 engine');
  assert.equal(failTest.objective.status, 'WEAK');

  const rem = await skillEngine.createRemediationPlan({
    errorId: failTest.createdError.id,
    title: 'Two-Pointer Duplicate Skipping Remediation',
  });
  await learningEngine._recomputeObjectiveProgressState('obj-py-two-pointers');
  const objInRem = await sys.db.get('learning_objectives', 'obj-py-two-pointers');
  assert.equal(objInRem.status, 'REMEDIATION');

  await skillEngine.completeCorrectiveTask(rem.correctiveTasks[0].id);

  const passRetest = await learningEngine.recordLearningTestAttempt({
    testId: lTest.id,
    objectiveId: 'obj-py-two-pointers',
    testType: 'mastery',
    linkedErrorId: failTest.createdError.id,
    isRetest: true,
    score: 94,
    accuracy: 92,
    confidence: 90,
  });
  assert.equal(passRetest.passed, true);
  assert.equal(passRetest.updatedError.status, 'resolved');
  assert.equal(passRetest.objective.status, 'MASTERED');
  assert.equal(passRetest.objective.historicalMasteryAchieved, true);
});

test('P3-18 & P3-19: Retention Review pass & Retention Failure (reopening remediation WITHOUT destroying historical mastery)', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true });
  const { learningEngine } = sys.engines;

  await learningEngine.recordRecallAttempt({
    objectiveId: 'obj-py-two-pointers',
    question: 'Q1',
    expectedAnswer: 'A1',
    userAnswer: 'A1',
    correctness: 95,
    confidence: 90,
  });
  await learningEngine.recordLearningTestAttempt({
    objectiveId: 'obj-py-two-pointers',
    testType: 'mastery',
    score: 92,
    accuracy: 90,
    confidence: 90,
  });

  const retPass = await learningEngine.recordRetentionReview({
    objectiveId: 'obj-py-two-pointers',
    reviewDate: '2026-10-20',
    score: 92,
    confidence: 90,
    evidence: 'Solved 2 unseen sliding window problems in 12 minutes',
  });
  assert.equal(retPass.passed, true);
  assert.equal(retPass.objective.status, 'MAINTENANCE');
  assert.ok(retPass.retentionEvidence);
  assert.equal(retPass.retentionEvidence.type, 'retention');

  const retFail = await learningEngine.recordRetentionReview({
    objectiveId: 'obj-py-two-pointers',
    reviewDate: '2026-11-15',
    score: 52,
    confidence: 80,
  });
  assert.equal(retFail.passed, false);
  assert.equal(retFail.objective.status, 'REMEDIATION', 'Retention failure must reopen REMEDIATION path');
  assert.equal(
    retFail.objective.historicalMasteryAchieved,
    true,
    'Retention failure must NEVER destroy historical mastery record'
  );
  assert.ok(retFail.objective.masteredAt, 'Original masteredAt timestamp must be preserved');
  assert.ok(retFail.retentionError, 'Must create a retention Error');
  assert.ok(retFail.remediationBundle, 'Must generate a retention recovery Remediation Plan');
});

test('P3-20, P3-21, P3-22 & P3-23: Learning Path progression, Prerequisite blocking/unlocking, and Learning Recommendations', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true });
  const { learningEngine } = sys.engines;

  const bfsObjBefore = await sys.db.get('learning_objectives', 'obj-py-bfs-dfs');
  assert.equal(bfsObjBefore.status, 'LOCKED');

  await assert.rejects(
    () =>
      learningEngine.recordLearningSession({
        objectiveId: 'obj-py-bfs-dfs',
        sessionType: 'LEARN',
        plannedDurationMin: 30,
      }),
    /is LOCKED/
  );

  const recsBefore = await learningEngine.getLearningRecommendations('2026-10-14');
  assert.ok(recsBefore.length > 0);
  assert.equal(
    recsBefore.some((r) => r.objectiveId === 'obj-py-bfs-dfs'),
    false,
    'Recommendation engine must never recommend a LOCKED objective'
  );

  await learningEngine.recordRecallAttempt({
    objectiveId: 'obj-py-two-pointers',
    question: 'Q',
    expectedAnswer: 'A',
    userAnswer: 'A',
    correctness: 95,
    confidence: 90,
  });
  await learningEngine.recordLearningTestAttempt({
    objectiveId: 'obj-py-two-pointers',
    testType: 'mastery',
    score: 95,
    accuracy: 92,
    confidence: 90,
  });

  const bfsObjAfter = await sys.db.get('learning_objectives', 'obj-py-bfs-dfs');
  assert.equal(bfsObjAfter.status, 'NOT_STARTED', 'Dependent objective must unlock once prerequisite objective & subskill are mastered');

  const pathStatus = await learningEngine.getLearningPathStatus('lpath-cs-algo-mastery');
  assert.equal(pathStatus.masteredCount, 1);
  assert.equal(pathStatus.totalObjectives, 2);
  assert.equal(pathStatus.progressPct, 50);
  assert.equal(pathStatus.currentActiveObjective.id, 'obj-py-bfs-dfs');
});

test('P3-24, P3-25 & P3-26: Reusable Notes, Backup/Restore v3+ Compatibility, and Full End-to-End Integration Pipeline', async () => {
  const sys = await createWhiteRoomSystem({ forceMemory: true });
  const { learningEngine, skillEngine, backupEngine } = sys.engines;

  const sess = await learningEngine.recordLearningSession({
    objectiveId: 'obj-math-propositional',
    resourceId: 'res-math-hammack',
    sessionType: 'LEARN',
    plannedDurationMin: 40,
    actualDurationMin: 40,
    confidence: 80,
    notes: 'Extracted truth tables for implication and contrapositive',
  });
  assert.equal(sess.objective.status, 'EXPOSED');

  const note = await learningEngine.addNote({
    targetType: 'objective',
    targetId: 'obj-math-propositional',
    skillId: 'skill-math-discrete',
    content: 'Remember: P -> Q is logically equivalent to ~Q -> ~P, NOT Q -> P.',
  });
  assert.ok(note.id);

  const rec = await learningEngine.recordRecallAttempt({
    objectiveId: 'obj-math-propositional',
    question: 'State the negation of P -> Q',
    expectedAnswer: 'P and not Q',
    userAnswer: 'P and not Q',
    confidence: 88,
    correctness: 95,
  });
  assert.equal(rec.passed, true);
  assert.equal(rec.objective.status, 'RECALLING');

  const pTask = await learningEngine.createPracticeTask({
    objectiveId: 'obj-math-propositional',
    title: 'Negate 10 nested ∀/∃ quantifier statements from Book of Proof',
    timeEstimateMin: 45,
    evidenceRequirement: 'solved_problem',
  });
  const pComp = await learningEngine.completePracticeTask(pTask.id, {
    durationMinutes: 45,
    outputSubmitted: 'All 10 quantifier negations verified against solution key',
  });
  assert.equal(pComp.objective.status, 'READY_FOR_TEST');

  const failTest = await learningEngine.recordLearningTestAttempt({
    objectiveId: 'obj-math-propositional',
    testType: 'mastery',
    score: 62,
    accuracy: 65,
    confidence: 85,
    errorDescription: 'Swapped existential and universal quantifiers only on outer scope',
  });
  assert.equal(failTest.passed, false);
  assert.ok(failTest.createdError);

  const rem = await skillEngine.createRemediationPlan({
    errorId: failTest.createdError.id,
    title: 'Nested Quantifier Negation Drill',
  });
  await skillEngine.completeCorrectiveTask(rem.correctiveTasks[0].id);

  const passRetest = await learningEngine.recordLearningTestAttempt({
    objectiveId: 'obj-math-propositional',
    testType: 'mastery',
    linkedErrorId: failTest.createdError.id,
    isRetest: true,
    score: 95,
    accuracy: 94,
    confidence: 92,
  });
  assert.equal(passRetest.passed, true);
  assert.equal(passRetest.updatedError.status, 'resolved');
  assert.equal(passRetest.objective.status, 'MASTERED');

  const retRev = await learningEngine.recordRetentionReview({
    objectiveId: 'obj-math-propositional',
    reviewDate: '2026-10-28',
    score: 96,
    confidence: 95,
    evidence: 'Completed timed logic proof retention check',
  });
  assert.equal(retRev.passed, true);
  assert.equal(retRev.objective.status, 'MAINTENANCE');

  const backup = await backupEngine.exportBackup();
  assert.ok(backup.schemaVersion >= 3);
  await sys.db.clearAll();
  const restored = await backupEngine.restoreBackup(backup);
  assert.equal(restored.restoredCount, backup.totalRecords);

  const restoredObj = await sys.db.get('learning_objectives', 'obj-math-propositional');
  assert.equal(restoredObj.status, 'MAINTENANCE');
  assert.equal(restoredObj.historicalMasteryAchieved, true);
});
