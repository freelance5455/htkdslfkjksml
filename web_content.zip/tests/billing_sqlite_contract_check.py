#!/usr/bin/env python3
"""SQLite contract test for the billing_operations reservation/refund schema.
This tests SQLite SQL/transaction semantics, not PHP PDO execution or provider calls.
"""
import sqlite3, tempfile, pathlib, unittest

class BillingSqliteContract(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.NamedTemporaryFile(suffix=".sqlite",delete=False)
        self.db=sqlite3.connect(self.tmp.name, isolation_level=None)
        self.db.execute("PRAGMA foreign_keys=ON")
        self.db.executescript("""
        CREATE TABLE user_wallets(user_id INTEGER PRIMARY KEY,balance INTEGER NOT NULL,updated_at TEXT NOT NULL);
        CREATE TABLE credit_transactions(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL,amount INTEGER NOT NULL,balance_after INTEGER NOT NULL,reason TEXT NOT NULL,reference_id TEXT NOT NULL,created_at TEXT NOT NULL);
        CREATE TABLE credit_operations(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL,workspace TEXT NOT NULL,job_id TEXT NOT NULL UNIQUE,credits INTEGER NOT NULL CHECK(credits>0),state TEXT NOT NULL CHECK(state IN ('reserved','settled','refunded')),created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
        INSERT INTO user_wallets VALUES(7,100,'now');
        """)
    def tearDown(self):
        self.db.close(); pathlib.Path(self.tmp.name).unlink(missing_ok=True)
    def reserve(self, job, credits):
        self.db.execute("BEGIN IMMEDIATE")
        try:
            self.db.execute("INSERT INTO credit_operations(user_id,workspace,job_id,credits,state,created_at,updated_at) VALUES(7,'image',?,?,'reserved','now','now')",(job,credits))
            cur=self.db.execute("UPDATE user_wallets SET balance=balance-? WHERE user_id=7 AND balance>=?",(credits,credits))
            if cur.rowcount!=1: raise ValueError("insufficient")
            bal=self.db.execute("SELECT balance FROM user_wallets WHERE user_id=7").fetchone()[0]
            self.db.execute("INSERT INTO credit_transactions(user_id,amount,balance_after,reason,reference_id,created_at) VALUES(7,?,?,?,?,'now')",(-credits,bal,'generation reservation',job))
            self.db.execute("COMMIT")
        except Exception:
            self.db.execute("ROLLBACK"); raise
    def refund(self, job):
        self.db.execute("BEGIN IMMEDIATE")
        try:
            op=self.db.execute("SELECT user_id,credits,state FROM credit_operations WHERE job_id=?",(job,)).fetchone()
            if not op: raise ValueError("missing")
            uid,amount,state=op
            if state!='reserved':
                self.db.execute("COMMIT"); return False
            self.db.execute("UPDATE user_wallets SET balance=balance+? WHERE user_id=?",(amount,uid))
            bal=self.db.execute("SELECT balance FROM user_wallets WHERE user_id=?",(uid,)).fetchone()[0]
            self.db.execute("INSERT INTO credit_transactions(user_id,amount,balance_after,reason,reference_id,created_at) VALUES(?,?,?,?,?,'now')",(uid,amount,bal,'generation refund',job))
            self.db.execute("UPDATE credit_operations SET state='refunded' WHERE job_id=? AND state='reserved'",(job,))
            self.db.execute("COMMIT"); return True
        except Exception:
            self.db.execute("ROLLBACK"); raise
    def test_reservation_and_refund_are_atomic_and_idempotent(self):
        self.reserve("a"*32,30)
        self.assertEqual(self.db.execute("SELECT balance FROM user_wallets").fetchone()[0],70)
        with self.assertRaises(sqlite3.IntegrityError): self.reserve("a"*32,30)
        self.assertTrue(self.refund("a"*32))
        self.assertFalse(self.refund("a"*32))
        self.assertEqual(self.db.execute("SELECT balance FROM user_wallets").fetchone()[0],100)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM credit_transactions").fetchone()[0],2)
    def test_insufficient_balance_rolls_back_reservation(self):
        with self.assertRaises(ValueError): self.reserve("b"*32,101)
        self.assertEqual(self.db.execute("SELECT balance FROM user_wallets").fetchone()[0],100)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM credit_operations").fetchone()[0],0)
    def test_settled_operation_cannot_be_refunded(self):
        self.reserve("c"*32,20)
        self.db.execute("UPDATE credit_operations SET state='settled' WHERE job_id=?",("c"*32,))
        self.assertFalse(self.refund("c"*32))
        self.assertEqual(self.db.execute("SELECT balance FROM user_wallets").fetchone()[0],80)

if __name__=="__main__":
    unittest.main(verbosity=2)
