import fs from 'node:fs';
const required=['package.json','index.html','src/app.tsx','src/components/Editor.tsx','src/core/effects.ts','src/services/projectStore.ts','src/services/security.ts','src/engine/exporter.ts','public/nivex-logo.png'];
for(const f of required){if(!fs.existsSync(new URL(`../${f}`,import.meta.url)))throw new Error(`Missing: ${f}`)}
const effects=fs.readFileSync(new URL('../src/core/effects.ts',import.meta.url),'utf8');
if(!effects.includes("glow")||!effects.includes("impact-flash"))throw new Error('Effect registry incomplete');
console.log('NIVEX smoke test: OK');
