import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState } from '../src/store.js';
import { getDashboardUniverse } from '../src/manager-dashboard.js';

test('dashboard universe agrège les clubs, damistes et calendrier sans modifier l’état', () => {
  const state = createInitialState();
  state.calendar.fixtures.push({ id:'played-1', status:'played', home:'super-league-01', away:'super-league-02' });
  state.calendar.fixtures.push({ id:'next-1', status:'scheduled', home:'super-league-01', away:'super-league-03', absoluteDay:4 });
  const before = JSON.stringify(state);
  const result = getDashboardUniverse(state);
  assert.equal(result.stats.clubs, 36);
  assert.equal(result.stats.damistes, 72);
  assert.equal(result.stats.played, 1);
  assert.equal(result.stats.scheduled, 1);
  assert.equal(result.ranking.length, 8);
  assert.equal(result.topDamistes.length, 5);
  assert.equal(result.calendar[0].id, 'next-1');
  assert.equal(JSON.stringify(state), before);
});

test('dashboard universe tolère un historique vide et des divisions inactives', () => {
  const state = createInitialState();
  state.divisions.forEach(d => { if (d.id === 'super-league') d.clubs = []; });
  state.management.inbox = [];
  const result = getDashboardUniverse(state);
  assert.equal(result.stats.clubs, 24);
  assert.deepEqual(result.news, []);
});
