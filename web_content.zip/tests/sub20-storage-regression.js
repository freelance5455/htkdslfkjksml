const fs=require('fs'),path=require('path'),vm=require('vm');
const html=fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8');
const script=html.match(/<script>([\s\S]*)<\/script>/)?.[1]; if(!script)throw Error('script missing');
const store={cc_sub20_league_v126:'legacy duplicate',cc_sub20_league_v132:'legacy duplicate'};
const localStorage={getItem:k=>store[k]??null,setItem(k,v){store[k]=String(v)},removeItem:k=>delete store[k]};
class El{constructor(){this.innerHTML='';this.textContent='';this.value='';this.dataset={};this.style={};this.classList={add(){},remove(){},contains(){return false}}}querySelectorAll(){return []}querySelector(){return new El()}click(){}}
const document={querySelector(){return new El()},querySelectorAll(){return []},createElement(){return new El()},body:new El()};
const context={document,localStorage,console,Math,Date,JSON,Blob:function(){},URL:{createObjectURL(){return ''},revokeObjectURL(){}},confirm(){return true},alert(){},setTimeout(){return 1},clearTimeout(){},FormData:function(){},FileReader:function(){},navigator:{},performance:{now(){return 0}}};context.window=context;vm.createContext(context);
vm.runInContext(script+'\nglobalThis.__t={setState(v){state=v},sub20Save,saveAll};',context);
const t=context.__t;t.setState({id:'career-test',season:2026,p:{name:'Teste'},history:[],fixtures:[],table:[]});
if(!t.sub20Save({season:2026,round:1,rounds:[],teams:[]}))throw Error('Sub-20 save failed');
if(!store['cc_sub20_league_career_career-test'])throw Error('career-specific Sub-20 key missing');
if(store.cc_sub20_league_v126!=='legacy duplicate'||store.cc_sub20_league_v132!=='legacy duplicate')throw Error('legacy caches unexpectedly changed during normal save');
if(!t.saveAll())throw Error('career save failed');
if(!store.cc_v1_saves||!store.cc_v1_active)throw Error('main career or active key not saved');
console.log('PASS: Sub-20 uses one per-career storage key and main career persistence succeeds without duplicate legacy writes.');
