import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const html = readFileSync(join(root, 'index.html'), 'utf8');
const app = readFileSync(join(root, 'src/app.js'), 'utf8');
test('le tableau de bord est un portail en six tuiles sans défilement', () => {
  assert.ok(html.includes('id="portalGrid"') && html.includes('portal-mode'));
  for (const h of ['Messages', 'Prochain match', 'Classement', 'Calendrier et résultats', 'Effectif et finances', 'Conseil et tâches']) assert.ok(app.includes(`'${h}'`), h);
  assert.ok(app.includes('fitPortal'));
});
test('Accueil expose Tableau de bord et Détails du club', () => {
  assert.match(app, /accueil:\[\['dashboard','Tableau de bord'\],\['actualites','Actualités'\],\['classement','Classement'\],\['divisions','Divisions'\],\['details'/);
  assert.match(html, /data-sub="details" id="careerProfileSection"/);
});
