import assert from "node:assert/strict";
import { chromium } from "playwright";

/** Wrap JPEG page images into a PDF with no text layer at all (like a scanner). */
function imagePdf(jpegs, w, h) {
  const objs = [];
  const add = (body) => { objs.push(body); return objs.length; };
  const catalog = add(null);
  const pages = add(null);
  const kids = [];
  for (const jpg of jpegs) {
    const img = add(Buffer.concat([
      Buffer.from(`<< /Type /XObject /Subtype /Image /Width ${w} /Height ${h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpg.length} >>\nstream\n`),
      jpg, Buffer.from("\nendstream"),
    ]));
    const content = `q 595 0 0 842 0 0 cm /Im Do Q`;
    const c = add(`<< /Length ${content.length} >>\nstream\n${content}\nendstream`);
    kids.push(add(`<< /Type /Page /Parent ${pages} 0 R /MediaBox [0 0 595 842] /Resources << /XObject << /Im ${img} 0 R >> >> /Contents ${c} 0 R >>`));
  }
  objs[catalog - 1] = `<< /Type /Catalog /Pages ${pages} 0 R >>`;
  objs[pages - 1] = `<< /Type /Pages /Kids [${kids.map((k) => `${k} 0 R`).join(" ")}] /Count ${kids.length} >>`;
  const parts = [Buffer.from("%PDF-1.4\n")];
  let len = parts[0].length;
  const offsets = [];
  objs.forEach((body, i) => {
    offsets.push(len);
    const b = Buffer.concat([Buffer.from(`${i + 1} 0 obj\n`), Buffer.isBuffer(body) ? body : Buffer.from(body), Buffer.from("\nendobj\n")]);
    parts.push(b); len += b.length;
  });
  let x = `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n` + offsets.map((o) => `${String(o).padStart(10, "0")} 00000 n \n`).join("");
  x += `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${len}\n%%EOF`;
  parts.push(Buffer.from(x));
  return Buffer.concat(parts);
}

const browser = await chromium.launch({ headless: true });
try {
  const W = 1240, H = 1754;
  const shot = await browser.newPage({ viewport: { width: W, height: H } });
  const pagesHtml = [
    ["فصل اول", "کتاب‌ها پنجره‌هایی به جهان دیگرند. هر کس کتاب بخواند زندگی‌های بسیاری را تجربه می‌کند. این متن به صورت تصویر در پرونده ذخیره شده است و هیچ لایهٔ متنی ندارد."],
    ["فصل دوم", "خواندن در گوشی همراه با نوشته‌های ریز دشوار است. برنامه باید نوشته‌ها را از تصویر تشخیص دهد و آن‌ها را با قلم درشت در صفحه‌های تازه نمایش دهد."],
  ];
  const jpegs = [];
  for (const [title, body] of pagesHtml) {
    await shot.setContent(`<html dir="rtl"><body style="margin:110px 120px;background:#f4efe3;font-family:'DejaVu Sans';color:#222">
      <h1 style="font-size:40px">${title}</h1>
      ${Array.from({ length: 10 }, (_, k) => `<p style="font-size:22px;line-height:1.8">${k + 1}. ${body}</p>`).join("")}</body></html>`);
    jpegs.push(await shot.screenshot({ type: "jpeg", quality: 80 }));
  }
  await shot.close();
  const pdf = imagePdf(jpegs, W, H);
  if (process.env.SAVE_PDF) { (await import("node:fs")).writeFileSync(process.env.SAVE_PDF, pdf); process.exit(0); }

  const page = await browser.newPage({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto(process.env.TEST_URL || "http://127.0.0.1:5173/");
  await page.locator('input[type="file"]').setInputFiles({ name: "scanned-book.pdf", mimeType: "application/pdf", buffer: pdf });
  await page.getByRole("button", { name: "باز کردن scanned-book" }).click({ timeout: 20000 });
  await page.getByText("در حال", { exact: false }).first().waitFor({ timeout: 20000 });
  const t0 = Date.now();
  await page.locator(".reflow-text").first().waitFor({ timeout: 180000 });
  console.log(`first page OCR in ${((Date.now() - t0) / 1000).toFixed(1)}s`);
  const hint = page.getByRole("button", { name: "فهمیدم" });
  if (await hint.isVisible()) await hint.click();
  const text = await page.locator(".reflow-text").first().textContent();
  console.log("OCR text:", text.slice(0, 160));
  assert.match(text, /کتاب‌ها پنجره‌هایی به جهان دیگرند/);
  assert.match(text, /بسیاری را/, "Persian word spacing should be preserved");
  assert.doesNotMatch(text, /[A-Za-z\u200e\u200f]/, "no Latin hallucinations or bidi marks");
  assert.match(text, /تصویر|جهان|زندگی/);
  assert.equal(await page.locator(".reflow-text").first().getAttribute("dir"), "rtl");
  // collect every reflowed page of the scanned source page 1
  await page.waitForFunction(() => !document.querySelector(".ocr-beam"), null, { timeout: 180000 });
  const total = await page.locator("footer input[type=range]").getAttribute("max");
  const seen = new Set();
  for (let i = 0; i <= Number(total); i++) {
    await page.locator("footer input[type=range]").evaluate((el, v) => {
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(el, String(v));
      el.dispatchEvent(new Event("input", { bubbles: true }));
    }, i);
    await page.waitForTimeout(250);
    seen.add(await page.locator('[role="group"] .reflow-text').first().textContent());
  }
  const all = [...seen].join(" ");
  const complete = (all.match(/زندگی‌های بسیاری را تجربه می‌کند\. این متن به صورت تصویر/g) || []).length;
  console.log(`reflowed pages: ${Number(total) + 1}, complete sentences recognised on page 1: ${complete}/10`);
  assert(complete >= 9, "OCR should keep every line of the scanned page, sentences unbroken");
  assert(all.includes("فصل اول"), "heading recognised");
  await page.locator("footer input[type=range]").evaluate((el) => {
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(el, "0");
    el.dispatchEvent(new Event("input", { bubbles: true }));
  });
  assert(await page.getByText("تشخیص از تصویر (OCR)", { exact: false }).first().isVisible());
  const fontSize = await page.locator(".reflow-text").first().evaluate((el) => getComputedStyle(el).fontSize);
  assert.equal(fontSize, "24px");
  // wait for page 2 and swipe through to it
  await page.waitForFunction(() => !document.body.innerText.includes("در صف پردازش") && !document.querySelector(".ocr-beam"), null, { timeout: 180000 });
  const footer = await page.locator("footer").innerText();
  console.log("footer:", footer.replace(/\n/g, " | "));
  const box = await page.locator("main").boundingBox();
  const before = Number(await page.locator("footer input[type=range]").inputValue());
  await page.mouse.move(box.x + box.width * 0.2, box.y + box.height * 0.4);
  await page.mouse.down();
  await page.mouse.move(box.x + box.width * 0.85, box.y + box.height * 0.4, { steps: 8 });
  await page.mouse.up();
  await page.waitForTimeout(500);
  assert.equal(Number(await page.locator("footer input[type=range]").inputValue()), before + 1);

  // reopening uses the cached OCR result (instant, no rescanning)
  await page.getByRole("button", { name: "بازگشت به کتابخانه" }).click();
  await page.waitForTimeout(700);
  await page.reload({ waitUntil: "load" });
  await page.getByText("ادامهٔ مطالعه", { exact: false }).first().waitFor({ timeout: 20000 });
  await page.locator("button.group").first().click();
  const t1 = Date.now();
  await page.locator(".reflow-text").first().waitFor({ timeout: 15000 });
  console.log(`reopen from OCR cache in ${((Date.now() - t1) / 1000).toFixed(1)}s`);
  assert(Date.now() - t1 < 8000, "cached OCR should reopen quickly");
  assert.equal(errors.length, 0, errors.join(" | "));
  console.log("PASS scanned PDF -> OCR -> reflowed large text, swipe, cache");
} finally {
  await browser.close();
}
