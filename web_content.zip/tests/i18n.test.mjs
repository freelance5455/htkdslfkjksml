import fs from 'node:fs'; import vm from 'node:vm';
const ctx={globalThis:null};ctx.globalThis=ctx;vm.createContext(ctx);
for (const f of ['src/i18n.js','src/legal-texts.js','src/lang-extra.js']) vm.runInContext(fs.readFileSync(f,'utf8'),ctx);
const I=ctx.AN_I18N, LG=ctx.AN_LEGAL;let bad=0;
const fa=new Set(Object.keys(I.fa)),en=new Set(Object.keys(I.en));
for(const k of fa)if(!en.has(k)){console.log('missing en:',k);bad++}
for(const k of en)if(!fa.has(k)){console.log('missing fa:',k);bad++}
const keys=new Set(),prefixes=new Set();
for(const f of fs.readdirSync('src').filter(f=>f.startsWith('view-')||f==='main.js'||f==='ui-core.js')){
  const s=fs.readFileSync('src/'+f,'utf8');
  for(const m of s.matchAll(/\bt\(\s*"([A-Za-z0-9_]+)"\s*([,)+])/g)){ (m[2]==='+'?prefixes:keys).add(m[1]); }
}
for(const k of keys)if(!fa.has(k)){console.log('undefined key:',k);bad++}
for(const p of prefixes)if(![...fa].some(k=>k.startsWith(p))){console.log('no keys for prefix:',p);bad++}
for(const k of fa){ if(/\{(\w+)\}/.test(I.fa[k])!==/\{(\w+)\}/.test(I.en[k])){console.log('placeholder mismatch:',k);bad++} }
for (const l of ['ar','fr','de']) {
  const ks=new Set(Object.keys(I[l]||{}));
  for (const k of en) if (!ks.has(k)) { console.log('missing',l,k); bad++; }
  for (const k of ks) if (!en.has(k)) { console.log('extra',l,k); bad++; }
  for (const k of en) { const a=(I.en[k].match(/\{\w+\}/g)||[]).sort().join(), b=((I[l]||{})[k]||'').match(/\{\w+\}/g); if (a!==(b||[]).sort().join()) { console.log('placeholders',l,k); bad++; } }
}
for (const l of ['fa','en','ar','fr','de']) for (const kind of ['terms','privacy']) { const d=LG[l]&&LG[l][kind]; if(!d||d.sections.length!==LG.en[kind].sections.length){console.log('legal',l,kind);bad++;} }
console.log(`i18n (fa,en,ar,fr,de): ${fa.size} keys each, ${keys.size} static refs, ${prefixes.size} prefixes → ${bad?bad+' PROBLEMS':'OK'}`);process.exit(bad?1:0);
