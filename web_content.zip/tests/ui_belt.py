"""Pás vln, auto-vlny, přivolání více vln, návrat do editoru, výchozí nastavení:  python3 -I tests/ui_belt.py"""
import glob, json
from playwright.sync_api import sync_playwright
exe = (glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome') or [None])[0]
SH = '/home/claude/BubbleDefence/tests/shots/'
errs, results = [], []
def check(n, c, x=''): results.append(bool(c)); print(('OK   ' if c else 'FAIL ') + n + (' ' + str(x) if x != '' else ''))
LEVEL = {'w': 12, 'h': 10, 'spawns': [{'side': 'L', 'pos': 8, 'len': 4}], 'exit': {'orb': [[19, 9], [20, 9], [19, 10], [20, 10]]},
         'rocks': [[10, 4, 1], [11, 4, 1], [10, 5, 1], [11, 5, 1]], 'walls': [[14, y] for y in range(0, 10)] + [[14, y] for y in range(12, 20)],
         'towers': [{'type': 'normal', 'x': 4, 'y': 4}], 'lives': 999, 'gold': 321, 'waves': 10, 'hp': 2, 'allowed': ['normal', 'ghost']}
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=exe, args=['--no-sandbox'])
LEVEL['waves'] = 12
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=exe, args=['--no-sandbox'])
    pg = b.new_page(viewport={'width': 1280, 'height': 800})
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type in ('error', 'warning') and 'willReadFrequently' not in m.text else None)
    pg.goto('file:///home/claude/BubbleDefence/index.html'); pg.wait_for_selector('.content:not(.hidden) .intro')
    pg.click('text=Nová lokální hra'); pg.wait_for_selector('.content:not(.hidden) .menu'); pg.wait_for_timeout(300)
    pg.click('.mi:has-text("Editor")'); pg.click('.lcard.add'); pg.wait_for_selector('.edv .ed-cv'); pg.wait_for_timeout(300)
    pg.evaluate("(L=>{const l=BD.store.profile.editor.levels[0]; Object.assign(l, L); BD.debugEditor.buildMasks(); BD.debugEditor.changed(true);})(%s)" % json.dumps(LEVEL))
    # pravidla: nekonečno schová počet vln
    pg.click('.ed-tabs >> text=Pravidla') if pg.locator('.ed-tabs >> text=Pravidla').count() else None
    pg.wait_for_timeout(200)
    if pg.locator('input[data-rule=waves]').count():
        pg.click('label.tog:has-text("Nekonečno")'); check('∞ schová počet vln', pg.locator('input[data-rule=waves]').count() == 0)
        pg.click('label.tog:has-text("Nekonečno")'); check('vypnuté ∞ vrátí počet vln', pg.locator('input[data-rule=waves]').count() == 1)
    pg.click('.smap-head .btn.primary'); pg.wait_for_selector('.gv canvas'); pg.wait_for_timeout(500)
    G = lambda js: pg.evaluate("(()=>{const g=BD.debug.game; return %s})()" % js)
    check('výchozí: trasa a délka cesty vypnuté', G('0') == 0 and pg.evaluate("[BD.store.profile.settings.showPath, BD.store.profile.settings.showPathLen]") == [False, False])
    check('pás má 5+ bloků', pg.locator('.belt .blk').count() >= 5, pg.locator('.belt .blk').count())
    check('první blok je vlna 1', pg.locator('.belt .blk').first.inner_text().find('1') >= 0)
    pg.screenshot(path=SH + 'belt_idle.png')
    pg.click('.bar .btn.primary:has-text("Start")'); pg.wait_for_timeout(300)
    check('po Startu hra běží', G('g.running') is True)
    pg.evaluate("(()=>{const g=BD.debug.game; for(let i=0;i<30*70;i++) g.step(1/30);})()")
    check('vlny jedou samy za sebou', G('g.wave') >= 3, G('g.wave'))
    pg.wait_for_timeout(300)
    # přivolání více vln
    w0 = G('g.wave'); pg.locator('.belt .blk:not(.bl-leave-active)').nth(3).evaluate('e=>e.click()'); pg.wait_for_timeout(200)
    pg.evaluate("(()=>{const g=BD.debug.game; for(let i=0;i<30*8;i++) g.step(1/30);})()")
    check('klik na 4. blok pustí 4 vlny', G('g.wave') - w0 == 4, G('g.wave') - w0)
    pg.wait_for_timeout(300); pg.screenshot(path=SH + 'belt_run.png')
    # boss blok
    pg.evaluate("(()=>{const g=BD.debug.game; g.wave=8; g.nextIn=50;})()"); pg.wait_for_timeout(400)
    check('blok vlny 10 je BOSS', pg.locator('.belt .blk.boss').count() >= 1 and 'BOSS' in pg.locator('.belt .blk.boss').first.inner_text())
    pg.screenshot(path=SH + 'belt_boss.png')
    # zpět do editoru z lišty
    pg.click('.bar .btn:has(.lbl)') if False else pg.click('button[title="Zpět do editoru"]'); pg.wait_for_selector('.smap-head', timeout=5000)
    check('z lišty zpět do editoru', pg.locator('.smap-head').count() >= 1)
    # mobil
    m = b.new_page(viewport={'width': 390, 'height': 780})
    m.goto('file:///home/claude/BubbleDefence/index.html'); m.wait_for_selector('.content:not(.hidden) .intro')
    m.click('text=Nová lokální hra'); m.wait_for_selector('.content:not(.hidden) .menu'); m.wait_for_timeout(300)
    m.click('.mi:has-text("Editor")'); m.click('.lcard.add'); m.wait_for_selector('.edv .ed-cv')
    m.evaluate("(L=>{const l=BD.store.profile.editor.levels[0]; Object.assign(l, L); BD.debugEditor.buildMasks(); BD.debugEditor.changed(true);})(%s)" % json.dumps(LEVEL))
    m.click('.smap-head .btn.primary'); m.wait_for_selector('.gv canvas'); m.wait_for_timeout(600)
    bb = m.locator('.belt').bounding_box(); check('mobil: pás je vodorovný a vidět', bb and bb['width'] > bb['height'] * 2, bb)
    m.screenshot(path=SH + 'belt_mobile.png')
    b.close()
print('\nvýsledek: %d/%d' % (sum(results), len(results)), '| chyby:', errs or 'žádné')
