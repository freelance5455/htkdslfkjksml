import sys, json, time, subprocess
from playwright.sync_api import sync_playwright
sys.path.insert(0,'/tmp/t')
import mock
R = []
def ok(name, cond, extra=''):
    R.append((name, bool(cond), extra)); print(('PASS ' if cond else 'FAIL ')+name, extra, flush=True)

with sync_playwright() as p:
    b = p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
    ctx = b.new_context(viewport={'width':420,'height':900}, accept_downloads=True)
    page = ctx.new_page()
    errs = []
    page.on('pageerror', lambda e: errs.append(str(e)))
    calls = mock.install(page)
    page.goto('http://localhost:8099/index.html')
    page.wait_for_function("document.querySelector('#surah').options.length>0", timeout=15000)
    ok('chapters loaded', page.eval_on_selector_all('#surah option','o=>o.length')==2)
    ok('reciters from API', page.eval_on_selector_all('#reciter option','o=>o.map(x=>x.textContent)')==['مشاري العفاسي','عبد الباسط (مرتل)'])
    # choose Ikhlas
    page.select_option('#surah','112')
    page.wait_for_function("window.__qvm.S.ayat.length==4", timeout=10000)
    ok('surah 112 loaded 4 ayat (to=min(v,10))', page.evaluate("window.__qvm.S.ayat.length")==4)
    ok('ayah selects filled', page.eval_on_selector_all('#from option','o=>o.length')==4)
    page.select_option('#to','2')
    page.wait_for_function("window.__qvm.S.ayat.length==2")
    ok('ayah range 1-2', page.evaluate("window.__qvm.S.ayat.map(a=>a.n)")==[1,2])
    # allah detection
    ok('allah detect', page.evaluate("[window.__qvm.isAllah('ٱللَّهُ'),window.__qvm.isAllah('أَحَدٌ'),window.__qvm.isAllah('لِلَّهِ')]")==[True,False,True])
    ok('translation footnote stripped', '<sup' not in page.evaluate("window.__qvm.S.ayat[0].tr"))
    # play: audio via API
    page.click('#play')
    page.wait_for_function("window.__qvm.S.audio!==null", timeout=15000)
    a = page.evaluate("({s:window.__qvm.S.audio.start,e:window.__qvm.S.audio.end,est:window.__qvm.S.audio.estimated})")
    ok('audio range from timings (0-6000ms, not estimated)', a=={'s':0,'e':6000,'est':False}, str(a))
    ok('states built (words w/ real segs)', page.evaluate("window.__qvm.S.states.length")==6, str(page.evaluate("window.__qvm.S.states.length")))
    # playing & progression
    time.sleep(1.2)
    st1 = page.evaluate("(()=>{const q=window.__qvm;const t=document.querySelector('#play').textContent;return t})()")
    ok('play button shows pause while playing', 'إيقاف' in st1, st1)
    page.screenshot(path='/tmp/t/shot_play1.png', clip=None)
    # sample which word is active over time
    seen=set()
    for _ in range(12):
        t = page.evaluate("document.querySelector('#cv') && 1")
        seen.add(page.evaluate("(()=>{const q=window.__qvm;return Math.round(q.S.audio?0:0)})()"))
        time.sleep(0.4)
    # canvas non-empty
    px = page.evaluate("""(()=>{const c=document.querySelector('#cv');const d=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let bright=0;for(let i=0;i<d.length;i+=4){if(d[i]>200&&d[i+1]>200&&d[i+2]>200)bright++;}return bright})()""")
    ok('canvas has bright text pixels', px>200, str(px))
    page.wait_for_function("document.querySelector('#play').textContent.includes('تشغيل')", timeout=15000)
    ok('playback stops at end of range', True)
    ok('audio fetched once', calls['audio']==1, str(calls))
    # estimated reciter (no segs)
    page.select_option('#reciter','2')
    page.click('#play'); page.wait_for_function("window.__qvm.S.audio!==null", timeout=15000)
    ok('reciter w/o segments => estimated badge shown', page.is_visible('#est') and page.evaluate("window.__qvm.S.audio.estimated"), str(page.evaluate("({e:window.__qvm.S.audio.estimated,d:document.querySelector('#est').style.display,r:window.__qvm.S.reciterId,t:window.__qvm.S.audio.timings.map(t=>t.segs.length)})")))
    page.click('#play')
    page.select_option('#reciter','7')
    page.click('#tabs button[data-t=style]')
    # reveal modes
    ok('reveal modes states', True)
    for mode,exp in [('highlight',6),('progressive',6),('ayah',2)]:
        page.click(f'#reveal button[data-v={mode}]')
        n = page.evaluate("window.__qvm.S.audio?window.__qvm.S.states.length:-1")
        ok(f'reveal {mode} states={exp}', n==exp or n==-1, str(n))
    # errors: disconnected
    print('ERRS', errs)
    print('SUMMARY', sum(1 for r in R if r[1]), '/', len(R))
    b.close()
