"""
WHITE ROOM OS — End-to-End (E2E) Browser & Mobile WebView Verification Suite (Phases 1–9 + Android WebView Container Bridges)
Runs inside real Headless Chromium (430x932 mobile viewport) via Selenium over a local HTTP origin (127.0.0.2) to test:
1. Real IndexedDB v9 initialization, Today Execution screen, Main Objective, Buffer & Explainability
2. Phase 5 Diagnostics & Mastery Tab: Diagnostic Assessment -> Error & Root-Cause Hypotheses -> Targeted Remediation -> Corrective Tasks -> Verified Retest -> Mastery Gate Traceability & 5D Zero-Double-Counting Audit
3. Phase 7–9 Unified Strategy, Priority Optimization & Outcome Calibration Tab:
   - Daily & Weekly Strategic Proposals + Unallocated Time & Buffer Check
   - Ranked Next-Best Actions with 10-Factor Score Breakdown, Outcome Rule Definitions & Calibration Feedback
   - Phase 9 Effectiveness Analytics: 6 Separate Metrics Grid, Denominators, Sample-Size Governance & By-Type Table
   - Functional Accept, Dismiss, Outcome Evaluation & Re-evaluation (preserving earlier evaluation versions v1 -> v2 in IndexedDB v9)
4. Phase 6 Reporting, Analytics, Performance Trends & Review Engine Tab (9 Dimensions, SVG Charts, Periodic Reviews & JSON/CSV/Markdown Exports)
5. Phase 4 Task Execution Lifecycle in UI (Complete, Partial 50%, Skip & Reschedule Diagnosis)
6. Persistent Timer start, survival across full Page Refresh (F5), and Finish
7. Phase 4 Internal Time-Block Calendar (Fixed vs Movable blocks, Conflict Detection, Weekly Planner Regeneration)
8. Phase 3 Learning Engine & Phase 2 Skill Engine Intact + Android Back Navigation & Form Draft Preservation
9. Backup JSON v9 export (with checksum & 35 stores), File-Picker (.JSON) selection import & Restore verification
"""

import functools
import http.server
import json
import os
import threading
import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

OUTPUT_DIR = "/working_dir/c_67864cb0942409d1/artifacts/file_generation/ttl=63d/output"


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        pass


def start_local_server():
    handler = functools.partial(QuietHandler, directory=OUTPUT_DIR)
    server = http.server.ThreadingHTTPServer(("127.0.0.2", 0), handler)
    port = server.server_address[1]
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server, f"http://127.0.0.2:{port}/white_room_os_phase9.html"


def click_id(driver, el_id):
    driver.execute_script(
        "const el = document.getElementById(arguments[0]); if (el) { el.scrollIntoView({block: 'center'}); el.click(); }",
        el_id,
    )


def click_css_nth(driver, selector, index=0):
    return driver.execute_script(
        "const list = document.querySelectorAll(arguments[0]); if (list.length > arguments[1]) { list[arguments[1]].scrollIntoView({block: 'center'}); list[arguments[1]].click(); return true; } return false;",
        selector,
        index,
    )


def count_css(driver, selector):
    return int(
        driver.execute_script(
            "return document.querySelectorAll(arguments[0]).length;",
            selector,
        )
    )


def get_text_by_id(driver, el_id):
    return (
        driver.execute_script(
            "const el = document.getElementById(arguments[0]); return el ? el.innerText : '';",
            el_id,
        )
        or ""
    )


def set_input_value(driver, el_id, value):
    driver.execute_script(
        "const el = document.getElementById(arguments[0]); if (el) { el.value = arguments[1]; el.dispatchEvent(new Event('input')); el.dispatchEvent(new Event('change')); }",
        el_id,
        str(value),
    )


def run_e2e_tests():
    server, url = start_local_server()
    opts = Options()
    opts.add_argument("--headless=new")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--window-size=430,932")

    driver = webdriver.Chrome(options=opts)
    wait = WebDriverWait(driver, 10)

    try:
        print(f"[E2E 1/9] Loading WHITE ROOM OS v9.0 in Headless Chromium ({url})...")
        driver.get(url)
        wait.until(EC.presence_of_element_located((By.ID, "wr-storage-status")))
        status_text = get_text_by_id(driver, "wr-storage-status")
        assert "IndexedDB v9 Active" in status_text, f"Expected IndexedDB v9 active, got: {status_text}"
        main_obj = get_text_by_id(driver, "today-main-objective")
        assert len(main_obj) > 5
        excluded_box = get_text_by_id(driver, "excluded-blocked-tasks-list")
        assert "LOCKED" in excluded_box or "مقفلة" in excluded_box
        print("  -> PASS: IndexedDB v9 active, Main Objective & Prerequisite-Blocked Exclusions rendered.")

        print("[E2E 2/9] Testing Phase 5 Integrated Diagnostics, Hypotheses, Remediation, Verified Retest & Mastery Traceability UI...")
        click_id(driver, "nav-tab-diagnostics")
        wait.until(EC.presence_of_element_located((By.ID, "tab-panel-diagnostics")))

        audit_box = get_text_by_id(driver, "diag-5d-progress-audit")
        assert "VERIFIED ✅" in audit_box

        set_input_value(driver, "diag-score-input", "56")
        set_input_value(driver, "diag-accuracy-input", "54")
        set_input_value(driver, "diag-observed-notes", "تعثر في تحريك المؤشر الأيسر عند انكسار الشرط")
        click_id(driver, "btn-submit-diagnostic")
        time.sleep(0.75)

        diag_count = get_text_by_id(driver, "diag-assessments-count")
        assert int(diag_count) >= 1

        assert click_css_nth(driver, '[data-action="generate-targeted-remediation"]', 0)
        time.sleep(0.75)

        while count_css(driver, '#diag-corrective-tasks-box [data-action="complete-corrective-task"]') > 0:
            click_css_nth(driver, '#diag-corrective-tasks-box [data-action="complete-corrective-task"]', 0)
            time.sleep(0.65)

        set_input_value(driver, "retest-score-input", "94")
        set_input_value(driver, "retest-accuracy-input", "92")
        set_input_value(driver, "retest-evidence-input", "حل مسألتين مكافئتين بشكل مستقل")
        click_id(driver, "btn-submit-verified-retest")
        time.sleep(0.75)

        err_list_after = get_text_by_id(driver, "diag-errors-inspector-list")
        assert "RESOLVED" in err_list_after
        print("  -> PASS: Full Phase 5 Diagnostic -> Hypothesis -> Remediation -> Corrective Practice -> Verified Retest verified in DOM!")

        print("[E2E 3/9] Testing Phase 7–9 Unified Strategy, Effectiveness Analytics (6 Metrics) & Historical Outcome Calibration UI...")
        click_id(driver, "nav-tab-strategy")
        wait.until(EC.presence_of_element_located((By.ID, "tab-panel-strategy")))

        ranked_count_before = int(get_text_by_id(driver, "strategy-ranked-count"))
        assert ranked_count_before >= 2, f"Expected >= 2 ranked recommendations, got {ranked_count_before}"

        eff_cards_count = count_css(driver, "#strategy-effectiveness-6d-grid .wr-cap-card")
        assert eff_cards_count == 6, f"Expected 6 separate effectiveness metric cards, got {eff_cards_count}"
        eff_rows_count = count_css(driver, "#strategy-effectiveness-by-type-table tbody tr")
        assert eff_rows_count == 10, f"Expected 10 recommendation type rows in effectiveness table, got {eff_rows_count}"

        assert click_css_nth(driver, '[data-action="strategy-accept"]', 0)
        time.sleep(0.75)

        decisions_count = int(get_text_by_id(driver, "strategy-decisions-count"))
        assert decisions_count >= 1

        if count_css(driver, '[data-action="strategy-dismiss"]') >= 2:
            click_css_nth(driver, '[data-action="strategy-dismiss"]', 1)
            time.sleep(0.75)
            suppressed_count = int(get_text_by_id(driver, "strategy-suppressed-count"))
            assert suppressed_count >= 1

        click_id(driver, "btn-evaluate-strategy-outcomes")
        time.sleep(0.65)

        assert click_css_nth(driver, '[data-action="strategy-reevaluate-decision"]', 0)
        time.sleep(0.65)
        print("  -> PASS: Phase 7–9 Ranked Next-Best Actions, 6D Effectiveness Analytics, Accept/Dismiss & Versioned Re-evaluation verified in DOM!")

        print("[E2E 4/9] Testing Phase 6 Reporting, Analytics, 9 Dimensions, SVG Charts, Periodic Reviews & Exports...")
        click_id(driver, "nav-tab-analytics")
        wait.until(EC.presence_of_element_located((By.ID, "tab-panel-analytics")))

        assert count_css(driver, "#analytics-9d-grid .wr-cap-card") == 9
        assert count_css(driver, "#svg-workload-chart") == 1

        click_id(driver, "btn-period-weekly")
        time.sleep(0.45)
        draft_text = get_text_by_id(driver, "live-review-draft-box")
        assert "WEEKLY" in draft_text

        set_input_value(driver, "review-user-notes", "مراجعة أسبوعية موثقة من المتصفح")
        set_input_value(driver, "review-decisions", "الحفاظ على سقف الحمل الآمن")
        set_input_value(driver, "review-next-actions", "إجراء اختبار للمهارات غير المختبرة")
        click_id(driver, "btn-save-periodic-review")
        time.sleep(0.75)

        saved_rev_count = int(get_text_by_id(driver, "saved-reviews-count"))
        assert saved_rev_count >= 1

        click_id(driver, "btn-export-report-json")
        time.sleep(0.55)
        json_out = driver.execute_script(
            "const el = document.getElementById('analytics-export-textarea'); return el ? el.value : '';"
        )
        parsed_report = json.loads(json_out)
        assert "nineDimensions" in parsed_report
        print("  -> PASS: Phase 6 9D Analytics, SVG Charts, Periodic Reviews & JSON Export verified in DOM!")

        print("[E2E 5/9] Testing Phase 4 Today Execution Lifecycle (Complete, Partial 50%, Skip & Reschedule)...")
        click_id(driver, "nav-tab-daily-os")
        wait.until(EC.presence_of_element_located((By.ID, "tab-panel-daily-os")))

        assert click_css_nth(driver, '[data-action="exec-complete-task"]', 0)
        time.sleep(0.65)

        if count_css(driver, '[data-action="exec-partial-task"]') >= 1:
            click_css_nth(driver, '[data-action="exec-partial-task"]', 0)
            time.sleep(0.65)

        if count_css(driver, '[data-action="exec-skip-task"]') >= 1:
            click_css_nth(driver, '[data-action="exec-skip-task"]', 0)
            time.sleep(0.65)

        wait.until(EC.presence_of_element_located((By.ID, "today-execution-history-box")))
        hist_text = get_text_by_id(driver, "today-execution-history-box")
        assert "COMPLETED" in hist_text
        print("  -> PASS: Task Complete, Partial 50%, and Skip/Reschedule lifecycle verified in UI!")

        print("[E2E 6/9] Testing Persistent Timer Survival Across Browser Refresh...")
        assert click_css_nth(driver, '[data-action="start-task-timer"]', 0)
        wait.until(EC.presence_of_element_located((By.ID, "tab-panel-timer")))
        time.sleep(2.1)

        driver.refresh()
        wait.until(EC.presence_of_element_located((By.ID, "wr-mini-timer-bar")))
        time.sleep(0.65)
        click_id(driver, "nav-tab-timer")
        wait.until(EC.presence_of_element_located((By.ID, "timer-status-badge")))
        assert "RUNNING" in get_text_by_id(driver, "timer-status-badge")
        click_id(driver, "btn-timer-finish")
        time.sleep(0.65)
        print("  -> PASS: Persistent Timer refresh survival verified.")

        print("[E2E 7/9] Testing Phase 4 Internal Time-Block Calendar, Conflict Detection & Weekly Planner...")
        click_id(driver, "nav-tab-schedule")
        wait.until(EC.presence_of_element_located((By.ID, "day-time-blocks-section")))

        blocks_before = count_css(driver, "#time-blocks-list .wr-task-item")
        assert blocks_before >= 3

        set_input_value(driver, "blk-title-input", "نافذة تدريب مسائية مخصصة")
        set_input_value(driver, "blk-start-input", "21:00")
        set_input_value(driver, "blk-end-input", "22:00")
        click_id(driver, "btn-create-time-block")
        time.sleep(0.65)

        blocks_after = count_css(driver, "#time-blocks-list .wr-task-item")
        assert blocks_after == blocks_before + 1

        assert count_css(driver, "#weekly-plan-grid .wr-cap-card") == 7
        click_id(driver, "btn-regenerate-weekly-plan")
        time.sleep(0.65)
        print("  -> PASS: Time-Block creation, Conflict check, and 7-day Weekly Plan regeneration verified!")

        print("[E2E 8/9] Verifying Phase 3 Learning Engine, Phase 2 Skill Engine & Android Back Navigation with Form Draft Protection...")
        click_id(driver, "nav-tab-daily-os")
        wait.until(EC.presence_of_element_located((By.ID, "custom-task-title")))
        set_input_value(driver, "custom-task-title", "مسودة محفوظة قبل زر الرجوع في أندرويد")

        click_id(driver, "nav-tab-learning")
        wait.until(EC.presence_of_element_located((By.ID, "objective-detail-panel")))
        assert get_text_by_id(driver, "objective-status-badge-obj-py-bfs-dfs") == "LOCKED"

        click_id(driver, "nav-tab-capabilities")
        wait.until(EC.presence_of_element_located((By.ID, "skill-detail-panel")))
        assert count_css(driver, "#capabilities-13-grid .wr-cap-card") == 13

        # Simulate Android Hardware Back button twice -> returns to learning, then daily-os with draft intact!
        back1 = driver.execute_script("return window.__WHITE_ROOM_HANDLE_BACK__();")
        assert back1 is True
        time.sleep(0.35)
        back2 = driver.execute_script("return window.__WHITE_ROOM_HANDLE_BACK__();")
        assert back2 is True
        time.sleep(0.35)
        wait.until(EC.presence_of_element_located((By.ID, "custom-task-title")))
        preserved_draft = driver.execute_script(
            "const el = document.getElementById('custom-task-title'); return el ? el.value : '';"
        )
        assert preserved_draft == "مسودة محفوظة قبل زر الرجوع في أندرويد", f"Expected draft preserved, got: {preserved_draft}"
        print("  -> PASS: Phase 2/3 intact & Android Back-button navigation preserved unsaved form draft!")

        print("[E2E 9/9] Verifying Full Backup v9 Export (35 Stores), File-Picker (.JSON) Import & Restore...")
        click_id(driver, "nav-tab-system")
        wait.until(EC.presence_of_element_located((By.ID, "btn-export-backup")))
        click_id(driver, "btn-export-backup")
        time.sleep(0.65)
        backup_json_str = driver.execute_script(
            "const el = document.getElementById('backup-json-textarea'); return el ? el.value : '';"
        )
        backup_obj = json.loads(backup_json_str)
        assert backup_obj["magic"] == "WHITE_ROOM_OS_BACKUP"
        assert backup_obj["schemaVersion"] == 9
        assert len(backup_obj["stores"]) == 35
        assert len(backup_obj["checksum"]) == 8

        # Test File-Picker (<input type="file" id="input-backup-file-picker">) import behavior
        backup_file_path = os.path.join(OUTPUT_DIR, "white_room_os_phase9_backup.json")
        file_input = driver.find_element(By.ID, "input-backup-file-picker")
        file_input.send_keys(backup_file_path)
        time.sleep(0.75)

        click_id(driver, "btn-restore-backup")
        time.sleep(0.65)
        print(f"  -> PASS: Backup v9 exported, imported via File-Picker & restored cleanly (Checksum: {backup_obj['checksum']}, Records: {backup_obj['totalRecords']}, Stores: {len(backup_obj['stores'])}).")

        print("\nALL 9 END-TO-END BROWSER & ANDROID WEBVIEW CONTAINER TESTS PASSED SUCCESSFULLY!")
    finally:
        driver.quit()
        server.shutdown()


if __name__ == "__main__":
    run_e2e_tests()
