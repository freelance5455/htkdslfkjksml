import test from 'node:test';
import assert from 'node:assert/strict';
import { simulateBoardMatch } from '../src/board-simulation.js';
import { createInitialState } from '../src/store.js';
import { generateSeasonCalendar } from '../src/calendar.js';
import { simulateFixture, simulateNextMatchday } from '../src/season-engine.js';

test('une simulation automatique joue une partie du moteur de dames et conserve les détails',()=>{
 const match=simulateBoardMatch({fixtureId:'test-board-1',season:1,arena:'terrestrial',homeStrength:55,awayStrength:48});
 assert.equal(match.engine,'cgd-draughts-ai-v1');assert.ok(match.plies>0);assert.ok(match.plies<=600);
 assert.ok([null,1,-1].includes(match.winnerSide));assert.equal(match.score.length,2);assert.ok(match.elapsedMs>=0);
 assert.ok(match.turns[1]>0);assert.ok(match.turns[-1]>0);
});
test('la simulation IA est déterministe pour une même rencontre',()=>{
 const args={fixtureId:'stable-fixture',season:3,arena:'crystalline',homeStrength:64,awayStrength:72};
 assert.deepEqual(simulateBoardMatch(args),simulateBoardMatch(args));
});
test('les effets d’arène sont transmis à la simulation automatique',()=>{
 const match=simulateBoardMatch({fixtureId:'arena-neon',arena:'neon'});
 assert.equal(match.arenaName,'Néon');assert.equal(match.arena,'neon');
});
test('une rencontre du calendrier reçoit un résultat issu du moteur de dames',()=>{
 const state=createInitialState();generateSeasonCalendar(state);const fixture=state.calendar.fixtures[0];
 assert.equal(simulateFixture(state,fixture.id),true);assert.equal(fixture.status,'played');
 assert.equal(fixture.matchDetails.engine,'cgd-draughts-ai-v1');assert.equal(fixture.matchDetails.mode,'automatic');
 assert.equal(state.calendar.processedFixtureIds.filter(id=>id===fixture.id).length,1);
});
test('une journée simule les matchs des clubs IA avec le moteur commun',()=>{
 const state=createInitialState();generateSeasonCalendar(state);const result=simulateNextMatchday(state);
 assert.ok(result.simulated.length>0);
 for(const id of result.simulated){const f=state.calendar.fixtures.find(x=>x.id===id);assert.equal(f.matchDetails.engine,'cgd-draughts-ai-v1');}
});
