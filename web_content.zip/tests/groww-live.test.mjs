import test from 'node:test';
import assert from 'node:assert/strict';
import { handler } from '../netlify/functions/groww-live.mjs';

const req = (query = {}, method = 'GET') => ({ httpMethod: method, queryStringParameters: query });
const body = r => r.body ? JSON.parse(r.body) : null;
const oldToken = process.env.GROWW_ACCESS_TOKEN;
const oldFetch = globalThis.fetch;

test.after(() => {
  if (oldToken === undefined) delete process.env.GROWW_ACCESS_TOKEN;
  else process.env.GROWW_ACCESS_TOKEN = oldToken;
  globalThis.fetch = oldFetch;
});

test('OPTIONS preflight does not call upstream', async () => {
  globalThis.fetch = () => { throw new Error('must not call upstream'); };
  const r = await handler(req({}, 'OPTIONS'));
  assert.equal(r.statusCode, 204);
});

test('rejects non-GET requests', async () => {
  process.env.GROWW_ACCESS_TOKEN = 'test-token';
  const r = await handler(req({}, 'POST'));
  assert.equal(r.statusCode, 405);
  assert.equal(body(r).error, 'GET_ONLY');
});

test('fails closed when token is missing', async () => {
  delete process.env.GROWW_ACCESS_TOKEN;
  const r = await handler(req({ exchange_symbols: 'NSE_RELIANCE' }));
  assert.equal(r.statusCode, 503);
  assert.equal(body(r).error, 'GROWW_ACCESS_TOKEN_NOT_CONFIGURED');
});

test('rejects non-allowlisted action before fetch', async () => {
  process.env.GROWW_ACCESS_TOKEN = 'test-token';
  globalThis.fetch = () => { throw new Error('must not call upstream'); };
  const r = await handler(req({ action: 'orders', exchange_symbols: 'NSE_RELIANCE' }));
  assert.equal(r.statusCode, 400);
  assert.equal(body(r).error, 'ACTION_NOT_ALLOWED');
});

test('rejects malformed symbols', async () => {
  process.env.GROWW_ACCESS_TOKEN = 'test-token';
  const r = await handler(req({ action: 'ltp', exchange_symbols: 'NSE_RELIANCE%26admin' }));
  assert.equal(r.statusCode, 400);
  assert.equal(body(r).error, 'INVALID_EXCHANGE_SYMBOLS');
});

test('rejects invalid segment', async () => {
  process.env.GROWW_ACCESS_TOKEN = 'test-token';
  const r = await handler(req({ segment: 'CRYPTO', exchange_symbols: 'NSE_RELIANCE' }));
  assert.equal(r.statusCode, 400);
  assert.equal(body(r).error, 'INVALID_SEGMENT');
});

test('forwards valid LTP request with server-side bearer token', async () => {
  process.env.GROWW_ACCESS_TOKEN = 'test-token';
  let seen;
  globalThis.fetch = async (url, options) => {
    seen = { url: String(url), options };
    return { ok: true, status: 200, text: async () => '{"NSE_RELIANCE":1234.5}' };
  };
  const r = await handler(req({ action: 'ltp', segment: 'CASH', exchange_symbols: 'NSE_RELIANCE' }));
  assert.equal(r.statusCode, 200);
  assert.equal(body(r).ok, true);
  assert.equal(body(r).data.NSE_RELIANCE, 1234.5);
  assert.match(seen.url, /\/ltp\?/);
  assert.equal(seen.options.headers.Authorization, 'Bearer test-token');
  assert.equal(seen.options.method, 'GET');
});

test('maps expired upstream token to a clear 401', async () => {
  process.env.GROWW_ACCESS_TOKEN = 'expired-token';
  globalThis.fetch = async () => ({ ok: false, status: 401, text: async () => '{"message":"expired"}' });
  const r = await handler(req({ exchange_symbols: 'NSE_RELIANCE' }));
  assert.equal(r.statusCode, 401);
  assert.equal(body(r).error, 'GROWW_TOKEN_INVALID_OR_EXPIRED');
});

test('does not return bearer token in successful response', async () => {
  process.env.GROWW_ACCESS_TOKEN = 'super-secret-test-token';
  globalThis.fetch = async () => ({ ok: true, status: 200, text: async () => '{"price":1}' });
  const r = await handler(req({ exchange_symbols: 'NSE_RELIANCE' }));
  assert.equal(r.statusCode, 200);
  assert.equal(r.body.includes('super-secret-test-token'), false);
});

test('rejects more than 50 LTP symbols', async () => {
  process.env.GROWW_ACCESS_TOKEN = 'test-token';
  globalThis.fetch = () => { throw new Error('must not call upstream'); };
  const symbols = Array.from({ length: 51 }, (_, i) => `NSE_TEST${i}`).join(',');
  const r = await handler(req({ action: 'ltp', exchange_symbols: symbols }));
  assert.equal(r.statusCode, 400);
  assert.equal(body(r).error, 'MAX_50_SYMBOLS');
});

test('forwards valid quote request with exchange and trading symbol', async () => {
  process.env.GROWW_ACCESS_TOKEN = 'test-token';
  let seenUrl = '';
  globalThis.fetch = async url => {
    seenUrl = String(url);
    return { ok: true, status: 200, text: async () => '{"ltp":123.4}' };
  };
  const r = await handler(req({ action: 'quote', segment: 'CASH', exchange: 'NSE', trading_symbol: 'RELIANCE' }));
  assert.equal(r.statusCode, 200);
  assert.match(seenUrl, /\/quote\?/);
  assert.match(seenUrl, /exchange=NSE/);
  assert.match(seenUrl, /trading_symbol=RELIANCE/);
});

test('sanitizes network failures without exposing token', async () => {
  process.env.GROWW_ACCESS_TOKEN = 'super-secret-test-token';
  globalThis.fetch = async () => { throw new TypeError('network unreachable'); };
  const r = await handler(req({ exchange_symbols: 'NSE_RELIANCE' }));
  assert.equal(r.statusCode, 502);
  assert.equal(body(r).error, 'GROWW_CONNECTION_FAILED');
  assert.equal(r.body.includes('super-secret-test-token'), false);
  assert.equal(r.body.includes('network unreachable'), false);
});
