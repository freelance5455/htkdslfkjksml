
const fs=require('fs'),path=require('path'),vm=require('vm');
const html=fs.readFileSync(path.join(__dirname, '..', 'index.html'),'utf8');
const match=html.match(/<script>([\s\S]*)<\/script>/);
if(!match) throw Error('script missing');
const store={};
class El {constructor(){this.innerHTML='';this.textContent='';this.value='';this.dataset={};this.style={};this.classList={add(){},remove(){},contains(){return false}}}querySelectorAll(){return []}querySelector(){return new El()}click(){}}
const document={querySelector(){return new El()},querySelectorAll(){return []},createElement(){return new El()},body:new El()};
const context={document,localStorage:{getItem(k){return store[k]??null},setItem(k,v){store[k]=v},removeItem(k){delete store[k]}},console,Math,Date,JSON,Blob:function(){},URL:{createObjectURL(){return ''},revokeObjectURL(){}},confirm(){return true},alert(){},setTimeout(){return 1},clearTimeout(){},FormData:function(){},FileReader:function(){},navigator:{},performance:{now(){return 0}}};
context.window=context;context.__store=store;vm.createContext(context);
vm.runInContext(match[1]+'\nglobalThis.__t={setState(v){state=v},brazilWorldLoad,brazilWorldTable,brazilWorldSave,brazilWorldClubs,brazilWorldFresh};',context);
const t=context.__t;
const A=Array.from({length:20},(_,i)=>'A'+i),B=Array.from({length:20},(_,i)=>'B'+i),C=Array.from({length:20},(_,i)=>'C'+i);
t.setState({season:2027,divisions:{A,B,C}});
let a=t.brazilWorldLoad('A');
if(a.clubs.length!==20||!A.every(c=>a.clubs.includes(c)))throw Error('current dynamic A participants not loaded');
if(a.rounds.length!==38||a.rounds.some(r=>r.length!==10))throw Error('calendar not regenerated correctly');
a.rounds[0][0].played=true;a.rounds[0][0].homeGoals=1;a.rounds[0][0].awayGoals=0;t.brazilWorldSave('A',a);
let again=t.brazilWorldLoad('A');
if(!again.rounds[0][0].played)throw Error('same-season result not persisted');
const nextA=A.slice(1).concat(B[0]);
t.setState({season:2028,divisions:{A:nextA,B:B.slice(1).concat(A[0]),C:C}});
let promoted=t.brazilWorldLoad('A');
if(!promoted.clubs.includes(B[0])||promoted.clubs.includes(A[0]))throw Error('promotion/relegation roster not reflected');
if(promoted.rounds.flat().some(f=>f.played))throw Error('new season did not reset old fixtures');
if(t.brazilWorldTable(promoted).length!==20)throw Error('classification does not reflect 20 dynamic participants');
// Legacy saves without an explicit clubs array retain results when their fixture roster matches.
const legacy={season:2028,division:'C',round:1,rounds:t.brazilWorldFresh('C',2028,C).rounds};
legacy.rounds[0][0].played=true;legacy.rounds[0][0].homeGoals=2;legacy.rounds[0][0].awayGoals=1;
context.__store['cc_brazil_world_leagues_v123']=JSON.stringify({A:promoted,B:t.brazilWorldFresh('B',2028,B),C:legacy});
t.setState({season:2028,divisions:{A:nextA,B:B.slice(1).concat(A[0]),C:C}});
const migrated=t.brazilWorldLoad('C');
if(!migrated.clubs||!migrated.rounds[0][0].played)throw Error('legacy save migration failed to preserve matching results');
console.log('PASS: dynamic promotion/relegation participants, 38-round calendar, persisted results, clean new-season reset, and legacy migration.');
