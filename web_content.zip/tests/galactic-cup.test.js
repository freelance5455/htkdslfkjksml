import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState } from '../src/store.js';
import { generateSeasonCalendar } from '../src/calendar.js';
import { createGalacticCupSeason, getGalacticCupStatus, recordGalacticCupResult, validateGalacticCup } from '../src/galactic-cup.js';
import { recordPlayedGame, simulateGalacticCupRound, simulateFixture, getCurrentMatchday } from '../src/season-engine.js';

function setup() { const state=createInitialState(); generateSeasonCalendar(state); createGalacticCupSeason(state); return state; }

test('la Coupe Galactique V116 conserve huit clubs dont le club dirigé et quatre quarts de finale',()=>{
  const s=setup(),cup=s.competitions.find(c=>c.id==='coupe-galactique');
  assert.equal(cup.rounds[0].participants.length,8);
  assert.ok(cup.rounds[0].participants.includes(s.userClubId));
  assert.equal(cup.rounds[0].fixtureIds.length,4);
  assert.ok(cup.rounds[0].fixtureIds.every(id=>s.calendar.fixtures.some(f=>f.id===id&&f.competitionId==='coupe-galactique')));
  assert.equal(validateGalacticCup(s),true);
});

test('la Coupe Galactique progresse quarts, demi-finales et finale jusqu’au champion',()=>{
  const s=setup(),cup=s.competitions.find(c=>c.id==='coupe-galactique');
  for(let round=1;round<=3;round++){
    const current=cup.rounds.at(-1);
    s.day=[6,12,18][round-1];
    for(const id of [...current.fixtureIds]){
      const f=s.calendar.fixtures.find(x=>x.id===id);
      if(f.status==='scheduled')recordGalacticCupResult(s,id,1,0,{winnerId:f.home});
    }
  }
  assert.equal(cup.status,'completed');
  assert.ok(cup.championId);
  assert.deepEqual(cup.rounds.map(r=>r.fixtureIds.length),[4,2,1]);
  assert.equal(cup.fixtures.length,7);
  assert.equal(validateGalacticCup(s),true);
});

test('une égalité est départagée de manière stable et sans double comptabilisation',()=>{
  const s=setup(),cup=s.competitions.find(c=>c.id==='coupe-galactique');
  const f=s.calendar.fixtures.find(x=>x.id===cup.rounds[0].fixtureIds[0]);
  const first=recordGalacticCupResult(s,f.id,0,0);
  assert.equal(first.accepted,true);
  assert.ok([f.home,f.away].includes(f.winnerId));
  assert.equal(recordGalacticCupResult(s,f.id,0,0).accepted,false);
});

test('la partie manuelle du club dirigé met à jour la Coupe Galactique et son tableau',()=>{
  const s=setup(),cup=s.competitions.find(c=>c.id==='coupe-galactique');
  s.day=6;s.calendar.currentDay=38;
  for(const id of cup.rounds[0].fixtureIds){const f=s.calendar.fixtures.find(x=>x.id===id);if(f.home!==s.userClubId&&f.away!==s.userClubId)recordGalacticCupResult(s,id,1,0,{winnerId:f.home});}
  const f=s.calendar.fixtures.find(x=>x.status==='scheduled'&&x.competitionId==='coupe-galactique'&&(x.home===s.userClubId||x.away===s.userClubId));
  assert.ok(f);
  const result=recordPlayedGame(s,f.id,1,{arena:'terrestrial'});
  assert.equal(result.accepted,true);
  assert.equal(f.status,'played');
  assert.equal(cup.rounds.length,2);
  const club=s.divisions.flatMap(d=>d.clubs).find(c=>c.id===s.userClubId);
  assert.equal(club.competitionStats['coupe-galactique'].played,1);
});

test('la simulation automatique de coupe réserve le match du club dirigé et utilise le moteur de dames',()=>{
  const s=setup();
  s.day=6;s.calendar.currentDay=38;
  const result=simulateGalacticCupRound(s);
  assert.equal(result.simulated.length,3);
  assert.ok(result.userFixture);
  assert.ok(result.simulated.every(id=>s.calendar.fixtures.find(f=>f.id===id).matchDetails.engine==='cgd-draughts-ai-v1'));
});

test('les tours de coupe ne bloquent pas la prochaine journée du championnat',()=>{
  const s=setup();
  const day=getCurrentMatchday(s);
  assert.equal(day.round,1);
  assert.ok(day.fixtures.every(f=>!f.competitionId));
  assert.equal(cupFixtureDay(s),6);
  const cup=s.competitions.find(c=>c.id==='coupe-galactique');
  s.day=6;s.calendar.currentDay=38;
  for(const id of cup.rounds[0].fixtureIds)simulateFixture(s,id);
  assert.equal(getCurrentMatchday(s).round,1);
});

function cupFixtureDay(state){const cup=state.competitions.find(c=>c.id==='coupe-galactique');return state.calendar.fixtures.find(f=>f.id===cup.rounds[0].fixtureIds[0]).scheduledMatchday;}

test('le statut de la Coupe Galactique expose le tour actif',()=>{
  const s=setup();
  assert.deepEqual(getGalacticCupStatus(s),{name:'Coupe Galactique',status:'in-progress',participantCount:8,round:1,roundLabel:'Quarts de finale',pendingFixtures:4,requiredMatchday:6,championId:null});
});

test('les tours de Coupe Galactique respectent les journées 6, 12 et 18 de la V116',()=>{
  const s=setup(),cup=s.competitions.find(c=>c.id==='coupe-galactique');
  assert.equal(s.calendar.fixtures.find(f=>f.id===cup.rounds[0].fixtureIds[0]).scheduledMatchday,6);
  assert.equal(simulateGalacticCupRound(s).available,false);
  s.day=6;s.calendar.currentDay=38;s.calendar.currentDay=38;assert.equal(simulateGalacticCupRound(s).available,true);
});
