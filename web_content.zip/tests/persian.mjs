import assert from "node:assert/strict";
import { chromium } from "playwright";

const browser = await chromium.launch({ headless: true });
try {
  const generator = await browser.newPage();
  const sentences = [
    "این یک کتاب فارسی است که متن آن باید از پروندهٔ پی دی اف استخراج شود.",
    "نوشته‌های ریز صفحه نباید فقط بزرگ‌نمایی شوند بلکه باید دوباره چیده شوند.",
    "هر جمله در جای درست خود باقی می‌ماند و خواننده اندازهٔ قلم را تغییر می‌دهد.",
  ];
  await generator.setContent(`
    <html lang="fa" dir="rtl"><head><meta charset="utf-8" />
    <style>@page{size:A4;margin:20mm}body{font:8px/1.6 'DejaVu Sans'}p{margin:0 0 8px}</style>
    </head><body>${Array.from({ length: 70 }, (_, i) => `<p>${sentences[i % 3]}</p>`).join("")}</body></html>
  `);
  const pdf = await generator.pdf({ format: "A4" });
  await generator.close();

  const page = await browser.newPage({
    viewport: { width: 390, height: 844 },
    isMobile: true,
    hasTouch: true,
  });
  const errors = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await page.goto(process.env.TEST_URL || "http://127.0.0.1:5173/");
  await page.locator('input[type="file"]').setInputFiles({
    name: "persian.pdf",
    mimeType: "application/pdf",
    buffer: pdf,
  });
  await page.getByRole("button", { name: "باز کردن persian" }).waitFor({ timeout: 20000 });
  await page.getByRole("button", { name: "باز کردن persian" }).click();
  await page.locator(".reflow-text").first().waitFor({ timeout: 30000 });
  await page.getByRole("button", { name: "فهمیدم" }).click();
  const text = await page.locator(".reflow-text").first().textContent();
  assert(text?.includes("این یک کتاب فارسی است"), "Persian text should be readable");
  assert(!/[\uFB50-\uFDFF\uFE70-\uFEFF]/.test(text), "Presentation forms should be normalized");
  assert.equal(await page.locator(".reflow-text").first().getAttribute("dir"), "rtl");
  const rect = await page.locator("main").boundingBox();
  assert(rect);
  await page.mouse.move(rect.x + rect.width * 0.2, rect.y + rect.height * 0.4);
  await page.mouse.down();
  await page.mouse.move(rect.x + rect.width * 0.85, rect.y + rect.height * 0.4, { steps: 8 });
  await page.mouse.up();
  await page.waitForTimeout(450);
  assert.equal(await page.locator("footer input[type=range]").inputValue(), "1");
  assert.equal(errors.length, 0, errors.join(" | "));
  console.log("PASS Persian PDF extraction, glyph normalization and RTL swipe");
} finally {
  await browser.close();
}