import os, tempfile, unittest, json, io, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__),"..","backend"))
import app as api

class ApiTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        api.DB_PATH=os.path.join(self.tmp.name,"test.sqlite3")
        api.init_db()
    def tearDown(self): self.tmp.cleanup()
    def call(self, method, path, data=None, token=None, org=None):
        raw=json.dumps(data or {}).encode()
        env={"REQUEST_METHOD":method,"PATH_INFO":path,"CONTENT_LENGTH":str(len(raw)),
             "wsgi.input":io.BytesIO(raw),"HTTP_AUTHORIZATION":("Bearer "+token) if token else ""}
        if org: env["HTTP_X_ORGANIZATION_ID"]=org
        out={}
        def start(status,headers): out["status"]=status
        body=b"".join(api.app(env,start))
        return out["status"],json.loads(body)
    def test_register_login_and_idempotent_sync(self):
        status,r=self.call("POST","/auth/register",{"email":"owner@example.com","password":"a-very-long-password","organization_name":"شركة الاختبار"})
        self.assertTrue(status.startswith("201"))
        status,l=self.call("POST","/auth/login",{"email_or_phone":"owner@example.com","password":"a-very-long-password"})
        self.assertTrue(status.startswith("200"))
        token=l["access_token"]; org=l["organizations"][0]["id"]
        status,b=self.call("GET","/branches",token=token,org=org)
        branch=b["branches"][0]["id"]
        op={"operations":[{"type":"sale.create","idempotency_key":"same-key-001","payload":{"branch_id":branch,"total":125.5,"invoice_no":"T-001"}}]}
        _,first=self.call("POST","/sync/push",op,token,org)
        _,second=self.call("POST","/sync/push",op,token,org)
        self.assertTrue(first["results"][0]["ok"])
        self.assertEqual(first["results"][0]["sale_id"],second["results"][0]["sale_id"])
        _,sales=self.call("GET","/sales",token=token,org=org)
        self.assertEqual(len(sales["sales"]),1)
    def test_auth_required(self):
        status,_=self.call("GET","/me")
        self.assertTrue(status.startswith("401"))

    def test_product_sync_and_list(self):
        _,r=self.call("POST","/auth/register",{"email":"products@example.com","password":"another-long-password","organization_name":"شركة المنتجات"})
        _,l=self.call("POST","/auth/login",{"email_or_phone":"products@example.com","password":"another-long-password"})
        token=l["access_token"]; org=l["organizations"][0]["id"]
        _,b=self.call("GET","/branches",token=token,org=org); branch=b["branches"][0]["id"]
        op={"operations":[{"type":"product.create","idempotency_key":"product-key-01","payload":{"branch_id":branch,"sku":"SKU-01","name":"منتج اختبار","price":9.75,"stock":4}}]}
        _,synced=self.call("POST","/sync/push",op,token,org)
        self.assertTrue(synced["results"][0]["ok"])
        _,products=self.call("GET","/products",token=token,org=org)
        self.assertEqual(len(products["products"]),1)
        self.assertEqual(products["products"][0]["price_minor"],975)

if __name__=="__main__": unittest.main()
