"""Smazané / osiřelé položky se nesmí objevit v exportu:  python3 -I tests/ui_orphans.py"""
import glob
from playwright.sync_api import sync_playwright
exe = (glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome') or [None])[0]
results=[]
def check(n,c,x=''): results.append(bool(c)); print(('OK   ' if c else 'FAIL ')+n+(' '+str(x) if x!='' else ''))
with sync_playwright() as p:
    b=p.chromium.launch(executable_path=exe,args=['--no-sandbox']); pg=b.new_context(viewport={'width':1440,'height':860}).new_page()
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('file:///home/claude/BubbleDefence/index.html'); pg.wait_for_selector('.content:not(.hidden) .intro')
    pg.click('text=Nová lokální hra'); pg.wait_for_selector('.content:not(.hidden) .menu'); pg.wait_for_timeout(300)
    pg.keyboard.type('terminal',delay=40); pg.keyboard.press('Backquote'); pg.wait_for_timeout(300); pg.keyboard.type('studio'); pg.keyboard.press('Enter'); pg.wait_for_timeout(250); pg.keyboard.press('Backquote'); pg.wait_for_timeout(300)
    pg.click('.mi:has-text("Studio")'); pg.wait_for_selector('.stv'); pg.wait_for_timeout(300)
    pg.evaluate("BD.studio.create('enemies','xxx'); BD.studio.create('towers','hrom')")
    pg.evaluate("BD.studio.items().enemies.dukh={patch:{}}; BD.studio.items().towers.ghost0={patch:{'dmg':5}}; BD.studio.apply()")
    ex=lambda: pg.evaluate("BD.studio.exportText()")
    check('vytvořené položky jsou v exportu', '"xxx"' in ex() and '"hrom"' in ex())
    pg.click('[data-tab=enemies]'); pg.wait_for_timeout(200); pg.click('.stu-item[data-id=xxx]'); pg.wait_for_timeout(200)
    pg.click('[data-act=stu-remove]'); pg.wait_for_timeout(200); pg.click('.modal .btn.primary, .dlg .btn.primary, button:has-text("Smazat") >> nth=-1'); pg.wait_for_timeout(300)
    check('smazaný nepřítel není v seznamu ani v exportu ani v profilu', pg.locator('.stu-item[data-id=xxx]').count()==0 and '"xxx"' not in ex() and pg.evaluate("!('xxx' in BD.store.profile.studio.items.enemies)"))
    pg.evaluate("BD.studio.remove('towers','hrom')")
    check('smazaná věž pryč z exportu', '"hrom"' not in ex())
    pg.evaluate("BD.store.profile.studio.items.enemies.zombie_x={custom:true,def:{name:'x'}}; BD.store.profile.studio.items.towers.nic={patch:{dmg:1}}; BD.studio.exportText")
    t=ex(); check('osiřelé záznamy se v exportu neobjeví', 'zombie_x' not in t and '"nic"' not in t and '"dukh"' not in t)
    pg.evaluate("BD.studio.apply()"); check('apply uklidí osiřelé záznamy z profilu', pg.evaluate("Object.keys(BD.store.profile.studio.items.towers).join()")=='' and pg.evaluate("!('dukh' in BD.store.profile.studio.items.enemies)"), pg.evaluate("JSON.stringify(BD.store.profile.studio.items)"))
    check('bez chyb', not errs, errs)
    b.close()
print('%d/%d'%(sum(results),len(results)))
