import { test, expect, type Page } from "@playwright/test";
import { unzipSync, strFromU8 } from "fflate";
import { readFile } from "node:fs/promises";

const prompt = (page: Page) =>
  page.getByRole("textbox", { name: "Message TopeCode" });
const nav = (page: Page, name: string) =>
  page
    .getByRole("navigation", { name: "Workspace views", exact: true })
    .getByRole("button", { name, exact: true });
async function connect(page: Page, key = "sk-test-placeholder-not-real") {
  await page
    .getByRole("button", { name: "Connect your model", exact: true })
    .click();
  await page.getByLabel("API key", { exact: true }).fill(key);
  await page
    .getByRole("button", { name: "Save provider", exact: true })
    .click();
  await page.getByRole("button", { name: "Back to workspace" }).click();
}
function proposal(summary: string, actions: unknown[]) {
  return {
    choices: [
      {
        message: {
          content: "",
          tool_calls: [
            {
              function: {
                name: "propose_workspace_changes",
                arguments: JSON.stringify({ summary, actions }),
              },
            },
          ],
        },
      },
    ],
  };
}
function message(content = "The requested work is complete.") {
  return { choices: [{ message: { content } }] };
}
async function mockProposal(page: Page, actions: unknown[]) {
  let calls = 0;
  await page.route("https://api.openai.com/v1/chat/completions", (route) =>
    route.fulfill({
      contentType: "application/json",
      body: JSON.stringify(
        ++calls === 1
          ? proposal("Review this proposed change.", actions)
          : message(),
      ),
    }),
  );
}
async function openSource(page: Page, name: string) {
  await page
    .getByRole("button", { name: "Quick switch", exact: true })
    .first()
    .click();
  await page
    .getByRole("textbox", { name: "Search files and commands" })
    .fill(name);
  await page
    .getByRole("dialog")
    .getByRole("button", {
      name: new RegExp(name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")),
    })
    .first()
    .click();
}

test("light-first mobile workspace has working starters and persistent drafts", async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/");
  await expect(page.locator("html")).not.toHaveClass(/dark/);
  await expect(
    page.getByRole("heading", { name: /built with TopeCode/ }),
  ).toBeVisible();
  await page.getByRole("button", { name: /^Website/ }).click();
  await expect(prompt(page)).toHaveValue(/responsive landing page/);
  await page.waitForTimeout(650);
  await page.reload();
  await expect(prompt(page)).toHaveValue(/responsive landing page/);
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
});

test("no-key chat never simulates an AI response", async ({ page }) => {
  await page.goto("/");
  await prompt(page).fill("Build a dashboard");
  await page.getByRole("button", { name: "Send message" }).click();
  await expect(
    page.getByText("No AI response was simulated.", { exact: false }),
  ).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Edit connection" }),
  ).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Approve change" }),
  ).toHaveCount(0);
});

test("real React preview is interactive without any API key", async ({
  page,
}) => {
  await page.goto("/");
  const frame = page.frameLocator('iframe[title="Workspace browser preview"]');
  await expect(
    frame.getByRole("heading", { name: /Little notes/ }),
  ).toBeVisible();
  const before = await frame.locator(".petal-note").count();
  await frame.getByRole("button", { name: "A fresh little note" }).click();
  await expect(frame.locator(".petal-note")).toHaveCount(before + 1);
  await frame.getByRole("button", { name: "Favorites", exact: true }).click();
  await expect(frame.locator(".petal-note")).toHaveCount(1);
  expect(
    await page
      .locator('iframe[title="Workspace browser preview"]')
      .getAttribute("sandbox"),
  ).toBe("allow-scripts");
});

test("saving real source code refreshes the actual browser preview", async ({
  page,
}) => {
  await page.goto("/");
  await openSource(page, "src/App.tsx");
  const editor = page.getByRole("textbox", {
    name: "Edit App.tsx",
    exact: true,
  });
  const original = await editor.inputValue();
  await editor.fill(original.replace("Little notes.", "It actually runs."));
  await page.getByRole("button", { name: "Save", exact: true }).click();
  await expect(
    page
      .frameLocator('iframe[title="Workspace browser preview"]')
      .getByRole("heading", { name: /It actually runs/ }),
  ).toBeVisible();
});

test("agent proposals wait for approval and changes can be undone", async ({
  page,
}) => {
  await mockProposal(page, [
    {
      kind: "create_file",
      label: "Create file",
      path: "generated.txt",
      content: "real file contents",
    },
  ]);
  await page.goto("/");
  await connect(page);
  await prompt(page).fill("Create generated.txt");
  await page.getByRole("button", { name: "Send message" }).click();
  await expect(
    page.getByRole("button", { name: "Approve change" }),
  ).toBeVisible();
  await expect(page.getByText("PROPOSED DIFF", { exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Approve change" }).click();
  await expect(
    page.getByText("1 change applied.", { exact: false }),
  ).toBeVisible();
  await nav(page, "Changes").click();
  await page.getByRole("button", { name: "Undo last" }).click();
  await expect(page.getByText("Undone", { exact: true })).toBeVisible();
});

test("agent reads a real file and receives actual results in a second round", async ({
  page,
}) => {
  let calls = 0;
  let followup: any;
  await page.route("https://api.openai.com/v1/chat/completions", (route) => {
    calls++;
    if (calls > 1) followup = route.request().postDataJSON();
    return route.fulfill({
      contentType: "application/json",
      body: JSON.stringify(
        calls === 1
          ? proposal("I'll inspect the source.", [
              { kind: "read", label: "Read App", path: "src/App.tsx" },
            ])
          : message(
              "The actual App source imports NoteList and manages the selected view.",
            ),
      ),
    });
  });
  await page.goto("/");
  await connect(page);
  await prompt(page).fill("Inspect the App source");
  await page.getByRole("button", { name: "Send message" }).click();
  await expect(
    page.getByText("The actual App source imports NoteList", { exact: false }),
  ).toBeVisible();
  expect(calls).toBe(2);
  expect(JSON.stringify(followup.messages)).toContain(
    "Actual TopeCode execution report",
  );
  expect(JSON.stringify(followup.messages)).toContain("setView");
});

test("read-only Plan mode never applies returned file proposals", async ({
  page,
}) => {
  let request: any;
  await page.route("https://api.openai.com/v1/chat/completions", (route) => {
    request = route.request().postDataJSON();
    return route.fulfill({
      contentType: "application/json",
      body: JSON.stringify(
        message("Here is a plan. No files will be changed in Plan mode."),
      ),
    });
  });
  await page.goto("/");
  await connect(page);
  await page.getByRole("button", { name: "Choose agent mode" }).click();
  await page
    .getByRole("dialog")
    .getByRole("button", { name: /^Plan Work/ })
    .click();
  await prompt(page).fill("Plan a website");
  await page.getByRole("button", { name: "Send message" }).click();
  await expect(
    page.getByText("No files will be changed", { exact: false }),
  ).toBeVisible();
  expect(request.tools).toBeUndefined();
  await expect(
    page.getByRole("button", { name: "Approve change" }),
  ).toHaveCount(0);
});

test("changing permission after a proposal blocks its execution", async ({
  page,
}) => {
  await mockProposal(page, [
    {
      kind: "create_file",
      label: "Create file",
      path: "blocked.txt",
      content: "no",
    },
  ]);
  await page.goto("/");
  await connect(page);
  await prompt(page).fill("Create blocked.txt");
  await page.getByRole("button", { name: "Send message" }).click();
  await page.getByRole("button", { name: "Approve change" }).waitFor();
  await page
    .getByRole("button", { name: "Agent permissions", exact: true })
    .click();
  await page.getByRole("switch", { name: "Create files", exact: true }).click();
  await page.getByRole("button", { name: "Back to workspace" }).click();
  await page.getByRole("button", { name: "Approve change" }).click();
  await expect(
    page.getByText("Permission off: create file", { exact: true }),
  ).toBeVisible();
  await nav(page, "Changes").click();
  await expect(page.getByText("A clean slate.", { exact: true })).toBeVisible();
});

test("model IDs, keys and base URLs are editable and remembered per provider", async ({
  page,
}) => {
  await page.goto("/");
  await page
    .getByRole("button", { name: "Connect your model", exact: true })
    .click();
  await page.getByRole("button", { name: "Edit API key", exact: true }).click();
  await page.getByLabel("API key", { exact: true }).fill("sk-replacement");
  await page
    .getByRole("button", { name: "Edit model ID", exact: true })
    .click();
  await page
    .getByLabel("Model ID", { exact: true })
    .fill("exact-model-with-dashes-6");
  await page
    .getByLabel("Base URL", { exact: true })
    .fill("https://gateway.example/v1");
  await page
    .getByRole("button", { name: "Save provider", exact: true })
    .click();
  await page.waitForTimeout(650);
  await page.reload();
  await page
    .getByRole("button", { name: "Manage your models", exact: true })
    .click();
  await expect(page.getByLabel("API key", { exact: true })).toHaveValue(
    "sk-replacement",
  );
  await expect(page.getByLabel("Model ID", { exact: true })).toHaveValue(
    "exact-model-with-dashes-6",
  );
  await expect(page.getByLabel("Base URL", { exact: true })).toHaveValue(
    "https://gateway.example/v1",
  );
  await page.getByRole("button", { name: /^DeepSeek$/ }).click();
  await page.getByRole("button", { name: /^OpenAI$/ }).click();
  await expect(page.getByLabel("Model ID", { exact: true })).toHaveValue(
    "exact-model-with-dashes-6",
  );
});

test("saved keys are encrypted at rest and decrypt after reload", async ({
  page,
}) => {
  await page.goto("/");
  await connect(page, "sk-encrypted-example");
  await page.waitForTimeout(700);
  const stored = await page.evaluate(
    () =>
      new Promise<any>((resolve) => {
        const r = indexedDB.open("tope-workspace");
        r.onsuccess = () => {
          const q = r.result.transaction("app").objectStore("app").get("state");
          q.onsuccess = () => resolve(q.result.providers.openai);
        };
      }),
  );
  expect(stored.apiKey).toBe("");
  expect(stored.encryptedKey.data.length).toBeGreaterThan(0);
  expect(JSON.stringify(stored)).not.toContain("sk-encrypted-example");
  await page.reload();
  await page
    .getByRole("button", { name: "Manage your models", exact: true })
    .click();
  await expect(page.getByLabel("API key", { exact: true })).toHaveValue(
    "sk-encrypted-example",
  );
});

test("turning off remembered keys clears them on reload", async ({ page }) => {
  await page.goto("/");
  await page
    .getByRole("button", { name: "Connect your model", exact: true })
    .click();
  await page
    .getByRole("switch", { name: "Remember API keys", exact: true })
    .click();
  await page.getByLabel("API key", { exact: true }).fill("sk-memory-only");
  await page
    .getByRole("button", { name: "Save provider", exact: true })
    .click();
  await page.waitForTimeout(700);
  await page.reload();
  await page
    .getByRole("button", { name: "Connect your model", exact: true })
    .click();
  await expect(page.getByLabel("API key", { exact: true })).toHaveValue("");
});

test("connection and generation tests are different real requests", async ({
  page,
}) => {
  const requests: any[] = [];
  await page.route("https://api.openai.com/v1/models", (route) =>
    route.fulfill({
      contentType: "application/json",
      body: JSON.stringify({ data: [{ id: "exact-coder-6" }] }),
    }),
  );
  await page.route("https://api.openai.com/v1/chat/completions", (route) => {
    requests.push(route.request().postDataJSON());
    return route.fulfill({
      contentType: "application/json",
      body: JSON.stringify(message("OK")),
    });
  });
  await page.goto("/");
  await page
    .getByRole("button", { name: "Connect your model", exact: true })
    .click();
  await page.getByLabel("API key", { exact: true }).fill("sk-test");
  await page.getByLabel("Model ID", { exact: true }).fill("exact-coder-6");
  await page
    .getByRole("button", { name: "Test connection", exact: true })
    .click();
  await expect(
    page.getByText("Endpoint connected.", { exact: false }),
  ).toBeVisible();
  expect(requests).toHaveLength(0);
  await page
    .getByRole("button", { name: "Test model generation", exact: true })
    .click();
  await expect(
    page.getByText("generated a response successfully", { exact: false }),
  ).toBeVisible();
  expect(requests[0].model).toBe("exact-coder-6");
  expect(requests[0].tools).toBeUndefined();
});

test("custom providers support native API protocol and arbitrary exact model IDs", async ({
  page,
}) => {
  await page.goto("/");
  await page
    .getByRole("button", { name: "Connect your model", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Custom provider", exact: true })
    .click();
  const dialog = page.getByRole("dialog", { name: "Add your own provider" });
  await dialog.getByLabel("Name", { exact: true }).fill("My gateway");
  await dialog
    .getByLabel("Base URL", { exact: true })
    .fill("https://gateway.example/v1");
  await dialog.getByLabel("Model ID", { exact: true }).fill("my-exact-coder");
  await dialog
    .getByRole("combobox", { name: "API protocol", exact: true })
    .selectOption("anthropic");
  await dialog
    .getByRole("button", { name: "Save provider", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "My gateway", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("combobox", { name: "API protocol", exact: true }),
  ).toHaveValue("anthropic");
});

test("429 errors support key replacement and retry without fake fallback", async ({
  page,
}) => {
  const seen: string[] = [];
  await page.route("https://api.openai.com/v1/chat/completions", (route) => {
    const auth = route.request().headers().authorization;
    seen.push(auth);
    return auth === "Bearer sk-old-key"
      ? route.fulfill({
          status: 429,
          contentType: "application/json",
          body: JSON.stringify({ error: { message: "Quota exceeded" } }),
        })
      : route.fulfill({
          contentType: "application/json",
          body: JSON.stringify(message("The replacement key works.")),
        });
  });
  await page.goto("/");
  await connect(page, "sk-old-key");
  await prompt(page).fill("Explain the project");
  await page.getByRole("button", { name: "Send message" }).click();
  await expect(
    page.getByText("Quota exceeded", { exact: false }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Edit connection", exact: true })
    .click();
  await page.getByLabel("API key", { exact: true }).fill("sk-new-key");
  await page
    .getByRole("button", { name: "Save provider", exact: true })
    .click();
  await page.getByRole("button", { name: "Back to workspace" }).click();
  await page.getByRole("button", { name: "Retry", exact: true }).click();
  await expect(
    page.getByText("The replacement key works.", { exact: true }),
  ).toBeVisible();
  expect(seen).toEqual(["Bearer sk-old-key", "Bearer sk-new-key"]);
});

test("stopping an active request ignores late provider responses", async ({
  page,
}) => {
  let started = false;
  await page.route(
    "https://api.openai.com/v1/chat/completions",
    async (route) => {
      started = true;
      await new Promise((resolve) => setTimeout(resolve, 1000));
      await route
        .fulfill({
          contentType: "application/json",
          body: JSON.stringify(message("Must never appear")),
        })
        .catch(() => {});
    },
  );
  await page.goto("/");
  await connect(page);
  await prompt(page).fill("Build something");
  await page.getByRole("button", { name: "Send message" }).click();
  await expect.poll(() => started).toBe(true);
  await page.getByRole("button", { name: "Stop response" }).click();
  await expect(page.getByText("Stopped by you", { exact: true })).toBeVisible();
  await page.waitForTimeout(1200);
  await expect(
    page.getByText("Must never appear", { exact: true }),
  ).toHaveCount(0);
});

test("editor drafts survive tab changes and saving empty text is supported", async ({
  page,
}) => {
  await page.goto("/");
  await openSource(page, "README.md");
  const editor = page.getByRole("textbox", {
    name: "Edit README.md",
    exact: true,
  });
  await editor.fill("unsaved draft");
  await nav(page, "Agent").click();
  await nav(page, "Editor").click();
  await expect(editor).toHaveValue("unsaved draft");
  await editor.fill("");
  await page.getByRole("button", { name: "Save", exact: true }).click();
  await expect(
    page.getByText("Saved locally / UTF-8", { exact: false }),
  ).toBeVisible();
});

test("preview reports unsupported package imports instead of a simulated success", async ({
  page,
}) => {
  await page.goto("/");
  await openSource(page, "src/App.tsx");
  await page
    .getByRole("textbox", { name: "Edit App.tsx", exact: true })
    .fill(
      'import madeup from "not-installed"; export default function App(){ return <div>{madeup}</div> }',
    );
  await page.getByRole("button", { name: "Save", exact: true }).click();
  await expect(page.getByRole("alert")).toContainText(
    'Package "not-installed" is not bundled',
  );
  await expect(
    page.getByRole("button", { name: "Ask TopeCode to fix it" }),
  ).toBeVisible();
});

test("mobile model sheets trap focus and close correctly", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/");
  await page.getByRole("button", { name: "Select model", exact: true }).click();
  const dialog = page.getByRole("dialog", { name: "Choose your model" });
  await expect(dialog).toBeVisible();
  await page.keyboard.press("Shift+Tab");
  expect(
    await page.evaluate(
      () => !!document.activeElement?.closest('[role="dialog"]'),
    ),
  ).toBe(true);
  await page.keyboard.press("Escape");
  await expect(dialog).toHaveCount(0);
  await expect(prompt(page)).toBeVisible();
});

test("network permission prevents actual provider requests", async ({
  page,
}) => {
  let requests = 0;
  await page.route(
    "https://api.openai.com/v1/chat/completions",
    async (route) => {
      requests++;
      await route.abort();
    },
  );
  await page.goto("/");
  await connect(page);
  await page
    .getByRole("button", { name: "Agent permissions", exact: true })
    .click();
  await page
    .getByRole("switch", { name: "Network requests", exact: true })
    .click();
  await page.getByRole("button", { name: "Back to workspace" }).click();
  await prompt(page).fill("Explain the App");
  await page.getByRole("button", { name: "Send message" }).click();
  await expect(
    page.getByText("Network permission is off.", { exact: false }),
  ).toBeVisible();
  expect(requests).toBe(0);
});

test("ZIP export contains the actual edited workspace files", async ({
  page,
}) => {
  await page.goto("/");
  await page
    .getByRole("button", { name: /^pocket-notes Local workspace$/ })
    .click();
  const pending = page.waitForEvent("download");
  await page
    .getByRole("dialog")
    .getByRole("button", { name: /Export workspace/ })
    .click();
  const file = await pending;
  const data = unzipSync(new Uint8Array(await readFile((await file.path())!)));
  expect(strFromU8(data["src/App.tsx"])).toContain("Room to bloom");
  expect(file.suggestedFilename()).toBe("pocket-notes.zip");
});

test("console never invents native npm execution", async ({ page }) => {
  await page.goto("/");
  await nav(page, "Console").click();
  await page.getByRole("button", { name: "Enable built-in commands" }).click();
  await page
    .getByRole("textbox", { name: "Console command" })
    .fill("npm run build");
  await page.getByRole("button", { name: "Run command" }).click();
  await expect(
    page.getByText("It was not executed.", { exact: false }),
  ).toBeVisible();
});

test("dark mode remains available and persists", async ({ page }) => {
  await page.goto("/");
  await page
    .getByRole("button", { name: "Toggle color theme", exact: true })
    .first()
    .click();
  await expect(page.locator("html")).toHaveClass(/dark/);
  await page.waitForTimeout(650);
  await page.reload();
  await expect(page.locator("html")).toHaveClass(/dark/);
});

test("preview viewport controls change the actual iframe layout width", async ({
  page,
}) => {
  await page.goto("/");
  await expect(
    page
      .frameLocator('iframe[title="Workspace browser preview"]')
      .getByRole("heading", { name: /Little notes/ }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "desktop preview", exact: true })
    .click();
  await expect
    .poll(async () => {
      const handle = await page
        .locator('iframe[title="Workspace browser preview"]')
        .elementHandle();
      const frame = await handle?.contentFrame();
      return frame?.evaluate(() => innerWidth);
    })
    .toBe(1024);
  await page
    .getByRole("button", { name: "mobile preview", exact: true })
    .click();
  await expect
    .poll(async () => {
      const handle = await page
        .locator('iframe[title="Workspace browser preview"]')
        .elementHandle();
      const frame = await handle?.contentFrame();
      return frame?.evaluate(() => innerWidth);
    })
    .toBe(375);
});

test("mobile Run opens a real isolated browser preview", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/");
  await page.getByRole("button", { name: "Run", exact: true }).click();
  await expect(
    page
      .frameLocator('iframe[title="Workspace browser preview"]')
      .getByRole("heading", { name: /Little notes/ }),
  ).toBeVisible();
});
