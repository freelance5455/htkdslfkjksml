// Regression test focused on persisted league results and the 3-1-0 points rule.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const match = html.match(/<script>([\s\S]*)<\/script>/);
if (!match) throw new Error('Application script not found');
const source = match[1] + '\n;globalThis.__test={emptyTable,rebuildStandingsFromFixtures,sortStandings};';
class Element { constructor(){this.innerHTML='';this.textContent='';this.value='';this.dataset={};this.style={};this.classList={add(){},remove(){},contains(){return false}};} querySelectorAll(){return [];} querySelector(){return new Element();} click(){} }
const document={querySelector(){return new Element();},querySelectorAll(){return [];},createElement(){return new Element();},body:new Element()};
const context={document,localStorage:{getItem(){return null;},setItem(){},removeItem(){}},console,Math,Date,JSON,Blob:function(){},URL:{createObjectURL(){return '';},revokeObjectURL(){}},confirm(){return true;},alert(){},setTimeout(){return 1;},clearTimeout(){},FormData:function(){},FileReader:function(){},navigator:{},performance:{now(){return 0;}}};
context.window=context;vm.createContext(context);vm.runInContext(source,context);
const {emptyTable,rebuildStandingsFromFixtures,sortStandings}=context.__test;
const clubs=['Internacional','Sport Recife','Palmeiras'];
const fixtures=[
 {home:'Internacional',away:'Sport Recife',played:true,score:[2,0]},
 {home:'Palmeiras',away:'Internacional',played:true,score:[0,1]},
 {home:'Internacional',away:'Palmeiras',played:true,score:[3,1]},
 {home:'Sport',away:'Palmeiras',played:true,score:[1,1]},
 {home:'Sport Recife',away:'Internacional',played:true,score:[0,0]},
 {home:'Palmeiras',away:'Sport Recife',played:true,score:[2,0]},
];
let table=rebuildStandingsFromFixtures(clubs,fixtures);sortStandings(table,fixtures);
const get=name=>table.find(x=>x.club===name);
if(get('Internacional').pts!==10 || get('Internacional').w!==3 || get('Internacional').d!==1 || get('Internacional').p!==4) throw new Error('Inter should have 7 points from 2 wins and 1 draw');
if(get('Sport Recife').pts!==2 || get('Sport Recife').w!==0 || get('Sport Recife').d!==2 || get('Sport Recife').p!==4) throw new Error('Sport alias should resolve and have 2 points from 2 draws');
if(get('Palmeiras').pts!==4 || get('Palmeiras').w!==1 || get('Palmeiras').d!==1 || get('Palmeiras').p!==4) throw new Error('Palmeiras should have 4 points from 1 win and 1 draw');
let test=emptyTable(['Casa','Fora']);
for(const score of [[1,0],[2,1],[0,0]]){const fx=[{home:'Casa',away:'Fora',played:true,score}];test=rebuildStandingsFromFixtures(['Casa','Fora'],fx);}
// Regression: a caller may pass fixtures grouped by round (2D) or flattened (1D).
// Head-to-head must be identical; before the fix, the 2D caller silently skipped it.
const tiedRows=()=>[{club:'Alpha',pts:20,w:6,gd:4,gf:18,red:0,yellow:0},{club:'Zeta',pts:20,w:6,gd:4,gf:18,red:0,yellow:0}];
const headToHead=[[{home:'Zeta',away:'Alpha',played:true,score:[1,0]},{home:'Alpha',away:'Zeta',played:true,score:[0,2]}]];
const flatRank=tiedRows();sortStandings(flatRank,headToHead.flat());
const groupedRank=tiedRows();sortStandings(groupedRank,headToHead);
if(flatRank[0].club!=='Zeta') throw new Error('fixture design must make Zeta win head-to-head');
if(groupedRank.map(x=>x.club).join('|')!==flatRank.map(x=>x.club).join('|')) throw new Error('grouped and flat fixtures must produce identical standings order');
console.log('PASS: standings calculate 3-1-0 points, resolve aliases, and use identical head-to-head ranking for grouped or flat fixtures.');
