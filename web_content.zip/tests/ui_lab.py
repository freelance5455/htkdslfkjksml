"""Zkušebna ve hře (Zkusit ve hře ze Studia): libovolná věž ze stromu rovnou, vypouštění nepřátel, nic se neukládá:  python3 -I tests/ui_lab.py"""
import glob, json
from playwright.sync_api import sync_playwright
exe = (glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome') or [None])[0]
errs, results = [], []
def check(n, c, x=''): results.append(bool(c)); print(('OK   ' if c else 'FAIL ') + n + (' ' + str(x) if x != '' else ''))
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=exe, args=['--no-sandbox'])
    ctx = b.new_context(viewport={'width': 1440, 'height': 860}); pg = ctx.new_page()
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type in ('error', 'warning') and 'willReadFrequently' not in m.text else None)
    pg.goto('file:///home/claude/BubbleDefence/index.html'); pg.wait_for_selector('.content:not(.hidden) .intro')
    pg.evaluate("BD.dev.unlocked = true; BD.dev.studio = true; BD.studio.enable(true)")
    pg.click('text=Nová lokální hra'); pg.wait_for_selector('.content:not(.hidden) .menu'); pg.wait_for_timeout(300)
    pg.click('.mi:has-text("Studio")'); pg.wait_for_selector('.stv'); pg.wait_for_timeout(400)
    before = pg.evaluate('JSON.stringify([BD.store.profile.bestiary, BD.store.profile.free, BD.store.profile.story])')
    pg.click('[data-tab=towers]'); pg.wait_for_timeout(300); pg.click('[data-id=burst_b]'); pg.wait_for_timeout(300)
    check('v záložce Šablony není Zkusit ve hře', (pg.click('[data-tab=templates]'), pg.wait_for_timeout(200), pg.locator('[data-act=stu-test]').count())[2] == 0)
    pg.click('[data-tab=towers]'); pg.wait_for_timeout(300); pg.click('[data-id=burst_b]'); pg.wait_for_timeout(200)
    pg.click('[data-act=stu-test]'); pg.wait_for_selector('.gv'); pg.wait_for_timeout(700)
    check('je vidět panel Zkušebna', pg.locator('[data-role=lab]').count() == 1)
    check('vybraná věž je z testu (burst_b) a je v nabídce celý strom', pg.evaluate("document.querySelector('[data-role=lab-tower]').value") == 'burst_b' and pg.locator('[data-role=lab-tower] option').count() > 12, pg.locator('[data-role=lab-tower] option').count())
    # postavit věž rovnou: klik do pole
    box = pg.locator('.stage canvas').bounding_box()
    for fy in (0.2, 0.35, 0.5, 0.65, 0.8):
        for fx in (0.15, 0.3, 0.45, 0.6, 0.75, 0.9):
            if pg.evaluate("BD.dev.game ? BD.dev.game.towers.length : -1") != 0: break
            pg.mouse.move(box['x'] + box['width'] * fx, box['y'] + box['height'] * fy); pg.wait_for_timeout(60)
            pg.mouse.click(box['x'] + box['width'] * fx, box['y'] + box['height'] * fy); pg.wait_for_timeout(120)
    t = pg.evaluate("(BD.dev.game && BD.dev.game.towers || []).map(t => t.type)")
    check('postavila se věž z hloubky stromu bez cesty přes vylepšení', t == ['burst_b'], t)
    # vypouštění
    pg.select_option('[data-role=lab-enemy]', 'ghost') if pg.locator('[data-role=lab-enemy] option[value=ghost]').count() else None
    pg.click('[data-act=lab-spawn10]'); pg.wait_for_timeout(1200)
    e = pg.evaluate("(BD.dev.game && BD.dev.game.enemies || []).length")
    check('Vypustit 10 pouští nepřátele postupně', 1 <= e <= 10, e)
    check('zlato i životy jsou nekonečné', '∞' in pg.inner_text('.stat.coin') and '∞' in pg.inner_text('.stat.heart'))
    pg.click('[data-act=lab-clear]'); pg.wait_for_timeout(300)
    check('Vyčistit pole odstraní věže i nepřátele', pg.evaluate("(BD.dev.game.towers.length + BD.dev.game.enemies.length)") == 0)
    pg.click('.gv .bar .btn:has-text("Studio")'); pg.wait_for_selector('.stv'); pg.wait_for_timeout(300)
    after = pg.evaluate('JSON.stringify([BD.store.profile.bestiary, BD.store.profile.free, BD.store.profile.story])')
    check('zkouška nic nezapsala do postupu ani do bestiáře', before == after)
    check('bez chyb', not errs, errs)
    b.close()
print('\nvýsledek: %d/%d' % (sum(results), len(results)), '| chyby:', errs or 'žádné')
