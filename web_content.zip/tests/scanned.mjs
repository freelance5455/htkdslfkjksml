import assert from "node:assert/strict";
import { chromium } from "playwright";

function blankPdf() {
  const objects = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R /Resources << >> >>",
    "<< /Length 0 >>\nstream\n\nendstream",
  ];
  let text = "%PDF-1.4\n";
  const offsets = [0];
  for (const [i, content] of objects.entries()) {
    offsets.push(text.length);
    text += `${i + 1} 0 obj\n${content}\nendobj\n`;
  }
  const xref = text.length;
  text += `xref\n0 ${offsets.length}\n0000000000 65535 f \n`;
  for (const offset of offsets.slice(1)) {
    text += `${String(offset).padStart(10, "0")} 00000 n \n`;
  }
  text += `trailer\n<< /Size ${offsets.length} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return Buffer.from(text, "ascii");
}

const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 390, height: 844 } });
  const errors = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await page.goto(process.env.TEST_URL || "http://127.0.0.1:5173/");
  await page.locator('input[type="file"]').setInputFiles({
    name: "scan.pdf",
    mimeType: "application/pdf",
    buffer: blankPdf(),
  });
  await page.getByRole("button", { name: "باز کردن scan" }).waitFor({ timeout: 20000 });
  await page.getByRole("button", { name: "باز کردن scan" }).click();
  await page.getByText("متنی برای بازچینی پیدا نشد").waitFor({ timeout: 20000 });
  assert.equal(await page.locator("main canvas").count(), 0);
  assert((await page.locator("main").innerText()).includes("OCR"));
  assert.equal(errors.length, 0, errors.join(" | "));
  console.log("PASS image-only PDF shows an honest OCR-needed message, not zoom");
} finally {
  await browser.close();
}