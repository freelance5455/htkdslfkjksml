const fs=require('fs');const s=fs.readFileSync(__dirname+'/../index.html','utf8');
function ok(v,m){if(!v)throw new Error(m)}
ok(s.includes('function simulateMatchEngine('),'central event engine missing');
ok(/function simulateLeagueGame\([\s\S]*?simulateMatchEngine\(f\.home,f\.away\)/.test(s),'career round is not routed to central engine');
ok(/function sub20AdvanceToCareerRound\([\s\S]*?simulateMatchEngine\(g\.home,g\.away\)/.test(s),'Sub-20 auto advance is not routed to central engine');
ok(/function sub20SimRound\([\s\S]*?simulateMatchEngine\(g\.home,g\.away\)/.test(s),'Sub-20 round is not routed to central engine');
ok(/function brazilWorldSim\([\s\S]*?simulateMatchEngine\(g\.home,g\.away\)/.test(s),'Brazil divisions are not routed to central engine');
ok(/function euroSimRound\([\s\S]*?simulateMatchEngine\(g\.home,g\.away\)/.test(s),'European leagues are not routed to central engine');
ok(/function playMatch\([\s\S]*?simulateMatchEngine\(home,away/.test(s),'player match is not routed to central engine');
ok(s.includes('teamStats:matchSim?.stats||null'),'post-match report is not using engine stats');
ok(s.includes("simulationEngine:matchSim?'event-driven-v1.56':'legacy'"),'engine source marker missing');
console.log('PASS: career calendar, Sub-20, Brazilian parallel leagues, European leagues and user matches route to the same event engine; post-match team stats are attached to that match result.');
