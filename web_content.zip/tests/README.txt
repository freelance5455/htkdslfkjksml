اختبارات المتصفح (Playwright + Chromium) — بتشغّل الموقع فعلياً وبترد على الـAPI ببيانات تجريبية (mock).
التجهيز (على كمبيوتر): pip install playwright && playwright install chromium، وفي /tmp/t حط index.html والملفات وملفات الاختبار.
ولّد ملفات الاختبار: ffmpeg → aud12.mp3 (12 ث) و local5.mp3 و vid10.webm و img.png (الأوامر في TEST_REPORT.md).
شغّل سيرفر: python3 -m http.server 8099 --directory /tmp/t ثم python3 run1.py (وهكذا run2..run4).
