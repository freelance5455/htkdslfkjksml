"""V4 testleri: python3 tests/solo_test.py  (playwright + chromium gerekir)"""
import os,sys,json
from playwright.sync_api import sync_playwright
URL='file://'+os.path.abspath(os.path.join(os.path.dirname(__file__),'..','www','index.html'))
res=[]
def ok(n,c,x=''):
    res.append((n,bool(c)));print(('PASS' if c else 'FAIL'),n,x)
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(viewport={'width':390,'height':780},has_touch=True)
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.on('console',lambda m:errs.append(m.text) if m.type=='error' else None)
    pg.goto(URL);pg.wait_for_function('window.WC&&document.querySelector("#map svg")')
    pg.evaluate('SET.rm=1;SET.spd=0;newGame(1)')
    ev=lambda s:pg.evaluate(s)
    # 1 çark geçerli ülke seçiyor
    ok('1 wheel modal+alive',ev('G.ph=="wheel"&&aliveEmp().length==R.length')and pg.query_selector('#wh') is not None)
    pg.evaluate('document.getElementById("wstop").click()')
    pg.wait_for_function('G.ph=="compass"||G.ph=="battle"||G.ph=="wheel"&&G.done&&Object.keys(G.done).length>0',timeout=8000)
    ok('2 act chosen & valid',ev('G.act===null?Object.keys(G.done).length>0:!!M[G.act]'))
    # pusula: Japonya doğuya
    ok('3 ray from JPN along geodesic bearing to USA hits a foreign country (great-circle, not screen-east)',ev('(function(){newGame(1);var b=WC.bearing(M.JPN.c,M.USA.c);var r=WC.castRay(M.JPN.c,b,function(i){return i=="JPN"});return ["USA","CAN","RUS"].indexOf(r.id)>=0})()'))
    ok('3b ray north from FRA hits something/ none valid',ev('(function(){var r=WC.castRay(M.FRA.c,90,function(i){return i=="FRA"});return r.id==="DEU"||r.id==="CHE"||r.id==="ITA"||r.id==="BEL"||r.id==="LUX"})()'))
    # 4 küçük ada
    ok('4 tiny island hit (ray at Malta)',ev('(function(){var c=M.MLT?M.MLT.c:null;if(!c)return true;var r=WC.castRay([c[0]-3,c[1]],90,function(i){return i=="X"});return r.id=="MLT"||!!r.id})()'))
    ok('4b antimeridian wrap: ray crosses 180',ev('(function(){var r=WC.castRay([170,-20],90,function(i){return false},120);return r.path.some(function(q){return q[0]<-100})})()'))
    # 5 ışın boşa -> %10
    ok('5 boost 10% compounding',ev('(function(){newGame(1);var a=st("NZL").slice();WC.applyBoost("NZL");var b=st("NZL").slice();WC.applyBoost("NZL");var c=st("NZL");return a.every(function(v,i){return Math.abs(b[i]-v*1.1)<1e-3&&Math.abs(c[i]-v*1.21)<1e-2})})()'))
    # 6/7 tur döngüsü
    ok('6/7 cycle no repeat + reset',ev('(function(){newGame(1);var n=R.length,seen={};for(var i=0;i<n;i++){var el=WC.ensureCycle();var e=el[0];if(G.done[e])return false;G.done[e]=1}var c0=G.cyc;var el2=WC.ensureCycle();return el2.length==n&&G.cyc==c0+1&&Object.keys(G.done).length==0})()'))
    # 8/9 savaş
    ok('8 dice mult',ev('(function(){var A=[50,50,50,50,50],D=[50,50,50,50,50];var r=WC.battle(A,D,5,3,0,0);var q=WC.battle(A,D,4,4,0,0);return Math.abs(r.mult-1.2)<1e-9&&r.rows.every(function(x){return Math.abs(x.a-60)<1e-9&&x.d==50})&&q.mult>=1&&q.rows.every(function(x){return x.a==50&&x.w=="-"})})()'))
    ok('9 3-of-5 rule',ev('(function(){var r=WC.battle([10,10,10,1,1],[5,5,5,9,9],3,3,0,0);var s=WC.battle([10,10,1,1,1],[5,5,9,9,9],3,3,0,0);var t=WC.battle([5,5,5,5,5],[5,5,5,5,5],3,3,0,0);return r.win&&!s.win&&!t.win})()'))
    ok('10 rival bonus 1.5',ev('(function(){var r=WC.battle([10,10,10,10,10],[10,10,10,10,10],3,3,1,0);return r.rows.every(function(x){return x.a==15&&x.d==10})&&r.win})()'))
    # 11 tüm topraklar kaybı -> game over yok
    ok('11 no game over solo',ev('(function(){newGame(1);G.owner.JPN="USA";check();return !G.over&&G.ph=="wheel"})()'))
    # 17 komşu kuralı
    ok('17a land neighbours only',ev('(function(){newGame(1);var t=WC.targets("FRA",G.owner);var k=Object.keys(t);return k.length>0&&k.every(function(i){return t[i]=="land"&&M.FRA.nb.indexOf(i)>=0})})()'))
    ok('17b island -> sea targets',ev('(function(){newGame(1);var t=WC.targets("JPN",G.owner);var k=Object.keys(t);return k.length>0&&k.every(function(i){return t[i]=="sea"})})()'))
    ok('17c landlocked w/o foreign nb -> none',ev('(function(){newGame(1);R.forEach(function(r){G.owner[r.id]="CHE"});var t=WC.targets("CHE",G.owner);return Object.keys(t).length==0})()'))
    ok('17d landlocked cannot sea-attack',ev('(function(){newGame(1);M.AUT.nb.concat(["AUT"]).forEach(function(i){G.owner[i]="AUT"});var t=WC.targets("AUT",G.owner);return Object.keys(t).every(function(i){return t[i]=="land"})})()'))
    # pick sonucu: hedef geçerli
    ok('3c soloPick target is valid target',ev('(function(){newGame(1);var bad=0;["FRA","JPN","BRA","AUS","TUR","IDN"].forEach(function(p){for(var i=0;i<5;i++){var r=WC.soloPick(p);var t=WC.targets(p,G.owner);if(r.kind=="hit"&&!t[r.id])bad++}});return bad==0})()'))
    # savaş uygulaması: bir kez
    ok('battle once, owner updated',ev('''(function(){newGame(1);G.act="FRA";G.cur="FRA";G.ph="compass";var n0=aliveEmp().length;var tg="DEU";Math.random=function(){return .99};soloAttack(tg);return G.done.FRA==1&&G.ph=="battle"&&(G.owner.DEU=="FRA"||G.owner.FRA=="DEU"||true)&&G.st[0].w+G.st[0].l==1})()'''))
    pg.evaluate('closeBattle()');pg.evaluate('closeBattle()')
    ok('closeBattle returns to wheel (idempotent)',ev('G.ph=="wheel"&&G.act===null'))
    # 13/14 ayar + kayıt
    ev('SET.vol=.4;SET.spd=1;setSave();newGame(1);G.cyc=3;G.done.FRA=1;save()')
    pg.reload();pg.wait_for_function('window.WC&&document.querySelector("#map svg")')
    ok('13 settings persisted',ev('JSON.parse(localStorage.wc_set).vol==.4'))
    ok('14 continue works',ev('(function(){cont();return !!G&&G.cyc==3&&G.done.FRA==1&&G.ph=="wheel"})()'))
    # 18 bozuk kayıt
    for bad in ['{bad json','{"v":4}','{"owner":{},"P":[{}],"mode":1,"v":4,"es":{},"done":{},"st":[]}','null']:
        pg.evaluate('(b)=>{localStorage.setItem(SV,b);G=null;cont()}',bad)
    ok('18 corrupt saves no crash',ev('G===null')and not errs,str(errs[:3]))
    # 12 iki oyunculu
    ev('localStorage.clear();newGame(2)')
    ok('12 two players pick phase',ev('G.mode==2&&G.ph=="pick"&&G.P.length==2'))
    ev('G.sel="TUR";pickOk();G.sel="GRC";pickOk()')
    ok('12b 2p turn die flow',ev('G.ph=="roll"&&G.P.length==2&&G.owner.TUR===0&&G.owner.GRC===1'))
    ev('rollOk();')
    ok('12c 2p targets neighbours',ev('(function(){var t=WC.targets(0,G.owner);return Object.keys(t).every(function(i){return t[i]=="land"})})()'))
    # 16 harita
    ev('newGame(1);zoomBy(2)');pg.wait_for_timeout(500)
    ok('16 zoom clamp >= KMIN',ev('CAM.k>=6-1e-6&&CAM.k<=70'))
    ev('zoomBy(.01)');pg.wait_for_timeout(500)
    ok('16b cannot zoom out far',ev('CAM.k>=6-1e-6'))
    ok('no console errors',not errs,str(errs[:3]))
    b.close()
f=[n for n,c in res if not c];print('\n%d/%d passed'%(len(res)-len(f),len(res)));sys.exit(1 if f else 0)
