#!/usr/bin/env python3
"""Exercise the SQLite resource migration without needing PHP pdo_sqlite."""
from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[1]
SQL = ROOT / "migrations" / "002_resources_centre_sqlite.sql"
source = SQL.read_text(encoding="utf-8")
assert "DROP TABLE" not in source.upper(), "Migration must not drop existing data"
assert "DELETE FROM" not in source.upper(), "Migration must not delete existing data"

con = sqlite3.connect(":memory:")
con.execute("PRAGMA foreign_keys=ON")
con.executescript(source)
con.executescript(source)  # idempotency
required = {
    "tool_categories", "tutorial_categories", "tools", "tutorials", "tutorial_steps",
    "tutorial_relations", "tutorial_media", "notifications", "dashboard_recent_access"
}
actual = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
assert required <= actual, f"Missing tables: {sorted(required - actual)}"
expected_indexes = {
    "idx_tools_category_status", "idx_tools_featured", "idx_tutorials_category_status",
    "idx_tutorials_featured", "idx_tutorial_steps_order", "idx_tutorial_relations_lookup",
    "idx_tutorial_media_order", "idx_notifications_user_created", "idx_dashboard_access_user"
}
actual_indexes = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='index'")}
assert expected_indexes <= actual_indexes, f"Missing indexes: {sorted(expected_indexes - actual_indexes)}"

now = "2026-11-11 12:00:00"
con.execute("INSERT INTO tool_categories(name,slug,created_at,updated_at) VALUES(?,?,?,?)", ("Voice tools", "voice", now, now))
cat_id = con.execute("SELECT id FROM tool_categories WHERE slug='voice'").fetchone()[0]
con.execute("INSERT INTO tools(category_id,name,slug,official_url,created_at,updated_at) VALUES(?,?,?,?,?,?)", (cat_id,"OBS Studio","obs-studio","https://obsproject.com/",now,now))
tool_id = con.execute("SELECT id FROM tools WHERE slug='obs-studio'").fetchone()[0]
con.execute("INSERT INTO tutorial_categories(name,slug,created_at,updated_at) VALUES(?,?,?,?)", ("Streaming", "streaming", now, now))
tcat_id = con.execute("SELECT id FROM tutorial_categories WHERE slug='streaming'").fetchone()[0]
con.execute("INSERT INTO tutorials(category_id,title,slug,last_updated_at,created_at,updated_at) VALUES(?,?,?,?,?,?)", (tcat_id,"OBS setup","obs-setup",now,now,now))
tut_id = con.execute("SELECT id FROM tutorials WHERE slug='obs-setup'").fetchone()[0]
con.execute("INSERT INTO tutorial_steps(tutorial_id,step_order,title,body,created_at,updated_at) VALUES(?,?,?,?,?,?)",(tut_id,1,"Install","Get it from the official site.",now,now))
con.execute("INSERT INTO tutorial_relations(tutorial_id,related_type,related_id,created_at) VALUES(?,?,?,?)",(tut_id,"tool",tool_id,now))
con.execute("INSERT INTO tutorial_media(tutorial_id,media_kind,external_url,created_at) VALUES(?,?,?,?)",(tut_id,"video","https://www.youtube.com/watch?v=abcdef12345",now))
con.execute("INSERT INTO notifications(user_id,event_key,title,created_at) VALUES(?,?,?,?)",(7,"signin:1","Sign-in",now))
# Duplicate event key is deliberately rejected to avoid duplicate genuine notifications.
try:
    con.execute("INSERT INTO notifications(user_id,event_key,title,created_at) VALUES(?,?,?,?)",(7,"signin:1","Duplicate",now))
    raise AssertionError("Notification idempotency constraint was not enforced")
except sqlite3.IntegrityError:
    pass
con.execute("INSERT INTO dashboard_recent_access(user_id,workspace,title,target_url,accessed_at) VALUES(?,?,?,?,?)",(7,"image","Image Studio","image-studio.php",now))
# Foreign-key cascades remove child tutorial media/steps/relations, while tool category delete keeps tool.
con.execute("DELETE FROM tutorials WHERE id=?",(tut_id,))
assert con.execute("SELECT COUNT(*) FROM tutorial_steps WHERE tutorial_id=?",(tut_id,)).fetchone()[0] == 0
assert con.execute("SELECT COUNT(*) FROM tutorial_media WHERE tutorial_id=?",(tut_id,)).fetchone()[0] == 0
assert con.execute("SELECT COUNT(*) FROM tutorial_relations WHERE tutorial_id=?",(tut_id,)).fetchone()[0] == 0
con.execute("DELETE FROM tool_categories WHERE id=?",(cat_id,))
assert con.execute("SELECT category_id FROM tools WHERE id=?",(tool_id,)).fetchone()[0] is None
con.close()
print("PASS: SQLite migration is repeatable; all 9 tables and indexes are created; prepared sample writes, unique notifications and FK delete behavior work.")
