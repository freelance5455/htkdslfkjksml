import { startCompany } from './helpers.mjs';
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const S='/tmp/claude-0/-home-claude/ac093352-288c-53a7-aeac-97bb6afa3d7b/scratchpad/';
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium', args:['--no-sandbox'] });
const ctx = await b.newContext({ viewport:{width:1200,height:900}, locale:'fa-IR', acceptDownloads:true });
const p = await ctx.newPage();
const errs=[]; p.on('pageerror',e=>errs.push('PAGEERR '+e.message)); p.on('console',m=>{if(['error','warning'].includes(m.type()))errs.push(m.type()+' '+m.text())});
let pass=0,fail=0; const ok=(c,n)=>{c?pass++:(fail++,console.log('FAIL',n))};
const tab=async n=>{await p.click(`nav.tabs button:has-text("${n}")`);await p.waitForTimeout(300)};
await p.goto('file://'+process.cwd()+'/dist/index.html');
await startCompany(p);
// CSP check: network blocked
const net = await p.evaluate(()=>fetch('https://example.com').then(()=>'open').catch(()=>'blocked'));
ok(net==='blocked','CSP blocks fetch');
// reports
await tab('گزارش‌ها');

// CSV download under CSP
const [dl]=await Promise.all([p.waitForEvent('download'),p.click('#view button:has-text("CSV")')]);
const csvPath=await dl.path(); const fs=await import('node:fs'); const csv=fs.readFileSync(csvPath,'utf8');
ok(csv.charCodeAt(0)===0xFEFF,'csv BOM'); ok(/1000/.test(csv),'csv has rows'); console.log('CSV file',dl.suggestedFilename(),csv.split('\n').length,'lines');
// print builds #printRoot
await p.evaluate(()=>{window.print=()=>{window.__pr=document.getElementById('printRoot').innerText.length}});
await p.click('#view button:has-text("چاپ")'); await p.waitForTimeout(400);
ok((await p.evaluate(()=>window.__pr))>50,'print root filled');
// each report renders
for (const r of ['دفتر کل','سود و زیان','ترازنامه','سن مطالبات','سن بدهی‌ها','تراز آزمایشی']){
  await p.click(`#view [role=tab]:has-text("${r}")`); await p.waitForTimeout(250);
  const locked=await p.$('#view .locked'); const txt=await p.innerText('#view');
  console.log('report',r,locked?'LOCKED':'open',txt.length); ok(locked||txt.length>150,'report '+r); }
// invoice flow
await tab('فروش'); await p.click('#view button:has-text("فاکتور فروش جدید")'); await p.waitForTimeout(400);
await p.screenshot({path:S+'inv0.png'});
ok(!(await p.isVisible('.modal .field:has(label:text("نرخ تبدیل"))')),'rate hidden for base currency');
const D='dialog[open] ';
const inp=i=>p.locator(D+'input, '+D+'select, '+D+'textarea').nth(i);
await inp(4).fill('طراحی سایت'); await inp(5).fill('۲'); await inp(6).fill('۵٬۰۰۰٬۰۰۰'); await inp(6).blur(); await p.waitForTimeout(200);
await p.screenshot({path:S+'inv1.png'});
const tot=await p.innerText('dialog[open]'); console.log('TOTALS',tot.match(/جمع[\s\S]{0,200}$/m)?.[0]?.replace(/\n/g,' | ').slice(0,300));
await p.click('dialog[open] button:has-text("ذخیره و ثبت نهایی")'); await p.waitForTimeout(700);
const body=await p.innerText('#view'); console.log('AFTER POST',body.slice(body.indexOf('INV-00004')-10,body.indexOf('INV-00004')+120));
ok(body.includes('INV-00004'),'invoice posted and listed');
console.log('modal open?',await p.isVisible('dialog[open]'));
// integrity + trial balance still balanced
const integ=await p.evaluate(()=>{const s=AN_UI.store;return JSON.stringify(s.verifyIntegrity(AN_UI.ctx))});
console.log('INTEGRITY',integ.slice(0,200));
const tb=await p.evaluate(()=>{const s=AN_UI.store;const r=s.trialBalance(AN_UI.ctx,s.today());return [r.balanced,String(r.totalDebit),String(r.totalCredit)]});
ok(tb[0]===true,'TB balanced after UI invoice'); console.log('TB',tb);

// ---- settings flows
const sub=async n=>{await p.click(`#view [role=tab]:has-text("${n}")`);await p.waitForTimeout(350)};
await tab('تنظیمات');
await sub('اشتراک');
await p.click('#view button:has-text("پرداخت موفق — Pro")'); await p.waitForTimeout(500);
let st=await p.evaluate(()=>AN_UI.store.planOf(AN_UI.co()).id||AN_UI.store.effectivePlan(AN_UI.co()));
ok(String(st).includes('pro'),'webhook upgrades to pro: '+st);
await p.click('#view button:has-text("رویداد جعلی")'); await p.waitForTimeout(400);
ok(/رد|نامعتبر|امضا/.test(await p.innerText('body')),'forged webhook rejected visibly');
st=await p.evaluate(()=>AN_UI.store.effectivePlan(AN_UI.co()));ok(String(st)==='pro','still pro after forged');
await p.click('#view button:has-text("ارسال دوباره")'); await p.waitForTimeout(300);
// backup plain
await sub('بکاپ');
const [d1]=await Promise.all([p.waitForEvent('download'),p.click('#view button:has-text("دانلود بکاپ (JSON)")')]);
const plain=fs.readFileSync(await d1.path(),'utf8'); ok(plain.includes('"sha256"')||plain.includes('fingerprint')||plain.length>1000,'plain backup'); console.log('backup',d1.suggestedFilename(),plain.length);
// encrypted backup
const pw=p.locator('#view input[type=password]'); await pw.nth(0).fill('Secret-Pass-123'); await pw.nth(1).fill('Secret-Pass-123');
const [d2]=await Promise.all([p.waitForEvent('download'),p.click('#view button:has-text("دانلود بکاپ رمزگذاری‌شده")')]);
const enc=fs.readFileSync(await d2.path(),'utf8'); ok(!enc.includes('Aria')&&!enc.includes('آریا'),'encrypted backup hides data'); console.log('enc',d2.suggestedFilename(),enc.length);
// restore both
await p.waitForTimeout(1000); const fi=p.locator('#view input[type=file]');
await fi.setInputFiles(await d1.path()); await p.waitForTimeout(300);
console.log('RESTORE UI',await p.$$eval('#view button',e=>e.map(x=>x.textContent.trim()).join(';')));
await p.click('#view button:has-text("بازیابی")'); await p.waitForTimeout(1200);
console.log('RMSG',(await p.innerText('#view')).match(/sim-out[^\n]*/)||await p.$$eval('.sim-out',e=>e.map(x=>x.textContent)));console.log('companies',await p.evaluate(()=>Object.keys(AN_UI.store.state().companies||{}).length));
await fi.setInputFiles(await d2.path()); await p.waitForTimeout(300);
await p.locator('#view input[type=password]').last().fill('wrong-pass').catch(()=>{});
await p.click('#view button:has-text("بازیابی")'); await p.waitForTimeout(1500);
console.log('after wrong pass:',(await p.innerText('#view')).match(/رمز[^\n]*/g)?.slice(-2));
await p.screenshot({path:S+'bk.png'});
// selftest
await sub('آزمون پذیرش'); await p.click('#view button:has-text("اجرای همهٔ آزمون‌ها")');
await p.waitForFunction(()=>/۱۰۸|108/.test(document.querySelector('#view').innerText),null,{timeout:60000}).catch(()=>{});
console.log('SELFTEST',(await p.innerText('#view')).replace(/\n+/g,' | ').slice(-500));
await p.screenshot({path:S+'st.png'});

// encrypted restore with correct pass
await sub('بکاپ'); await fi.setInputFiles(await d2.path()); await p.waitForTimeout(300);
await p.locator('#view input[type=password]').last().fill('Secret-Pass-123');
await p.click('#view button:has-text("بازیابی")'); await p.waitForTimeout(1800);
const nc=await p.evaluate(()=>Object.keys(AN_UI.store.state().companies||{}).length); ok(nc===3,'encrypted restore creates company: '+nc);
// viewer role: cannot post
await p.evaluate(()=>{const s=AN_UI.store,c=AN_UI.ctx;});
await sub('اعضا و نقش‌ها');
await p.locator('#view input.inp').first().fill('ناظر'); 
await p.locator('#view select').last().selectOption({label:'مشاهده‌گر'}).catch(e=>console.log('sel',e.message));
await p.click('#view button:has-text("افزودن عضو")'); await p.waitForTimeout(400);
console.log('MEMBERS',(await p.innerText('#view')).replace(/\n+/g,' | ').slice(0,300));
// language toggle
await p.selectOption('.lang-sel','en'); await p.waitForTimeout(500);
ok(await p.evaluate(()=>document.documentElement.dir==='ltr'&&document.documentElement.lang==='en'),'English is LTR');
await tab('Home').catch(()=>{});
await p.screenshot({path:S+'en0.png'});
await p.click('nav.tabs button >> nth=7'); await p.waitForTimeout(300); await p.screenshot({path:S+'en1.png'});
// mobile
await p.setViewportSize({width:390,height:800}); await p.click('nav.tabs button >> nth=1'); await p.waitForTimeout(300);
ok(await p.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth+1),'no horizontal scroll on mobile (sales): '+await p.evaluate(()=>document.documentElement.scrollWidth));
await p.screenshot({path:S+'m1.png'});
for(const i of [0,4,5,7,8]){await p.click(`nav.tabs button >> nth=${i}`);await p.waitForTimeout(250);
 const w=await p.evaluate(()=>document.documentElement.scrollWidth);ok(w<=391,'mobile tab '+i+' width '+w);}
console.log('ERRS',errs);
await b.close(); console.log({pass,fail});
