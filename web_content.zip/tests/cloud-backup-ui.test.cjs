'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const html = fs.readFileSync(require.resolve('../index.html'), 'utf8');
const client = fs.readFileSync(require.resolve('../supabase-client.js'), 'utf8');

test('organization backup page exposes authenticated cloud backup and restore actions', () => {
  assert.match(html, /data-a="bakCloud"/);
  assert.match(html, /data-a="bakCloudList"/);
  assert.match(html, /async function openCloudBackups\(/);
  assert.match(html, /data-cloud-backup-restore/);
  assert.match(html, /data-cloud-backup-download/);
});

test('cloud backups verify SHA-256 and are scoped to the active company', () => {
  assert.match(html, /cloudSha256\(blob\)/);
  assert.match(html, /pack\.companyId!==UI\.companyId/);
  assert.match(html, /await MRKCloud\.pushState\(UI\.companyId,S,current\?\.updated_at\|\|null\)/);
  assert.match(client, /async function uploadBackup\(companyId,fileName,blob\)/);
  assert.match(client, /async function listBackupJobs\(companyId,limit=30\)/);
  assert.match(client, /async function downloadBackup\(companyId,path\)/);
  assert.match(client, /String\(path\)\.includes\('\.\.'\)/);
});

test('backup metadata uses an allowed MANUAL kind and never includes user passwords', () => {
  assert.match(html, /backup_kind:'MANUAL'/);
  assert.match(html, /state\.users=\[\]/);
  assert.match(html, /delete state\.passwordHash/);
});
