import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createInitialState } from '../src/store.js';

test('le registre galactique UI est accessible depuis Gestion',()=>{
  const html=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8');
  const app=fs.readFileSync(new URL('../src/app.js',import.meta.url),'utf8');
  assert.match(html,/data-screen="gestion" data-sub="registre"/);
  assert.match(app,/\['registre','Registre galactique'\]/);
  assert.match(app,/function renderGalacticRegistry\(/);
});

test('les fiches de registre couvrent les 60 clubs et leurs 120 damistes',()=>{
  const state=createInitialState();
  assert.equal(state.world.clubCatalog.length,60);
  assert.equal(state.world.clubCatalog.reduce((n,c)=>n+c.damistes.length,0),120);
  assert.equal(state.world.clubCatalog.filter(c=>c.catalogStatus==='locked').length,24);
});

test('le registre managers distingue les 60 managers de clubs et les 24 sélectionneurs',()=>{
  const state=createInitialState();
  assert.equal(state.world.clubManagers.length,60);
  assert.equal(new Set(state.world.clubManagers.map(m=>m.id)).size,60);
  assert.equal(state.world.selectionManagers.length,24);
  assert.equal(new Set(state.world.selectionManagers.map(m=>m.id)).size,24);
});
