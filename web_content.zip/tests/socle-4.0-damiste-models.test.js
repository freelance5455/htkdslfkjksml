import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const scene=readFileSync(new URL('../src/scene-3d.js',import.meta.url),'utf8');
const match=readFileSync(new URL('../src/match-ui.js',import.meta.url),'utf8');
test('Socle 4.0 : jambes, genoux et chaussures sont construits séparément',()=>{
  assert.ok(scene.includes('const hipY=.20+lift,kneeY=.125+lift,footY=.055+lift'));
  assert.ok(scene.includes('addSphere(out,knee[0],knee[1],knee[2],.047'));
  assert.ok(scene.includes('addBox(out,foot[0]-.065'));
});
test('Socle 4.0 : épaules, coudes et mains forment des bras articulés',()=>{
  for(const token of ['leftElbow','rightElbow','addLimb(out,leftShoulder,leftElbow','addLimb(out,leftElbow,left','addLimb(out,rightElbow,right'])assert.ok(scene.includes(token));
});
test('Socle 4.0 : la marche anime les membres sans modifier le déplacement légal',()=>{
  assert.ok(scene.includes('gait:Math.sin(t*Math.PI*2)'));
  assert.ok(scene.includes('sway:Math.cos(t*Math.PI*2)'));
  assert.ok(scene.includes('phase:Math.sin(t*Math.PI*2)'));
  assert.ok(scene.includes('const gait=pose?.gait||0'));
});
test('Socle 4.0 : les deux camps reçoivent une présentation avant le match',()=>{
  assert.ok(match.includes("playPose?.(board,1,'presentation'"));
  assert.ok(match.includes("playPose?.(board,-1,'presentation'"));
  assert.ok(scene.includes("action==='presentation'"));
});
test('Socle 4.0 : expressions et réactions du public sont reliées aux poses',()=>{
  for(const token of ['const headTilt=','const eyeScale=','const mouthColor=','arenaReaction===\'celebrate\'','arenaReaction===\'defeat\''])assert.ok(scene.includes(token));
});
