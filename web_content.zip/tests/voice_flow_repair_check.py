from pathlib import Path
root=Path(__file__).resolve().parents[1]
voice=(root/'app/voice.php').read_text()
create=(root/'api/agent/create.php').read_text()
session=(root/'api/agent/session.php').read_text()
agent=(root/'app/agent.php').read_text()
config=(root/'api/voice/config.php').read_text()
pref=(root/'api/voice/preference.php').read_text()
js=(root/'assets/voice-studio.js').read_text()
chat=(root/'assets/agent-chat.js').read_text()
boot=(root/'app/bootstrap.php').read_text()
checks={
 'Fish Audio documented svc voice models accepted': "['svc', 'tts']" in voice,
 'Fish Audio pagination respects provider has_more': "array_key_exists('has_more', $decoded)" in voice,
 'Agent expressive false preserved explicitly': "'expressive'=>filter_var" in create and "array_filter" not in create,
 'Saved agent voice passed as session override': "'voice_id']=$savedVoice" in session and "sessionPayload['overrides']" in session,
 'Account-level selected voice returned': "preferredVoice" in config,
 'Account-level voice preference endpoint uses existing workspace preferences': 'preference_set' in pref and 'voice_selected_reference_id' in pref,
 'Voice Studio syncs selection server-side': 'api/voice/preference.php' in js,
 'Agent SDK pinned to 0.3.0': '@fishaudio/agent-client@0.3.0' in chat,
 'Agent session start is serialized': 'startingPromise' in chat,
 'Agent provider session ID is validated': 'incomplete session response' in session,
 'Provider LLM usage reconciliation implemented': 'agent_reconcile_provider_usage' in agent and 'billable_cost_usd' in agent,
 'Voice TTS requires a caller idempotency key': "A valid Idempotency-Key header is required" in (root/'api/voice/tts.php').read_text(),
 'Voice charge idempotency uses a unique per-user request key': 'voice_request_keys' in voice and 'PRIMARY KEY(user_id,request_key)' in boot,
 'Voice refund idempotency uses a unique per-user refund key': 'voice_refunds' in voice and 'PRIMARY KEY(user_id,request_key)' in boot,
 'Voice Studio persists request key across network retries': "'Idempotency-Key':requestKey" in js and 'anonymoux_voice_pending_request' in js,
 'Provider usage IDs and wallet references are idempotent': 'provider_usage_id' in agent and "'agent-'.substr(hash('sha256',$usageId),0,40)" in agent,
 'Agent billing conversion is opt-in': 'ANONYMOUX_AGENT_CREDITS_PER_USD' in boot and "'agent_credits_per_usd' => 0" in (root/'config.local.example.php').read_text(),
 'Manual usage reconciliation endpoint exists': (root/'api/agent/reconcile-session.php').is_file(),
}
for label,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+label)
if not all(checks.values()): raise SystemExit(1)
