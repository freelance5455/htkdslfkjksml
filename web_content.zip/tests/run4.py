import sys, time, subprocess, json, os, re
from playwright.sync_api import sync_playwright
sys.path.insert(0,'/tmp/t'); import mock
R=[]
def ok(n,c,e=''):
    R.append((n,bool(c),e)); print(('PASS ' if c else 'FAIL ')+n, e, flush=True)
def tab(page,t): page.click(f'#tabs button[data-t={t}]')
with sync_playwright() as p:
    b = p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
    # 1) chapters fail -> banner + retry
    ctx = b.new_context(viewport={'width':420,'height':900}); page = ctx.new_page()
    mock.install(page, fail_chapters=True); page.goto('http://localhost:8099/index.html')
    page.wait_for_function("document.querySelector('#err').style.display==='block'", timeout=20000)
    msg=page.inner_text('#errmsg'); ok('offline chapters -> clear Arabic error', 'الإنترنت' in msg, msg)
    ok('retry button visible', page.is_visible('#retry')); ctx.close()
    # 2) audio blob fails
    ctx = b.new_context(viewport={'width':420,'height':900}); page = ctx.new_page(); mock.install(page)
    page.route('https://mock.audio/**', lambda r: r.abort())
    page.goto('http://localhost:8099/index.html'); page.wait_for_function("document.querySelector('#surah').options.length>0", timeout=15000)
    page.select_option('#surah','112'); page.wait_for_function("window.__qvm.S.ayat.length==4")
    page.click('#play'); page.wait_for_function("document.querySelector('#err').style.display==='block'", timeout=20000)
    ok('audio download failure -> message (no fake success)', page.evaluate("window.__qvm.S.audio")==None and len(page.inner_text('#errmsg'))>10, page.inner_text('#errmsg'))
    ok('play button back to idle', 'تشغيل' in page.inner_text('#play')); ctx.close()
    # 3) video background in preview + switching in export
    ctx = b.new_context(viewport={'width':420,'height':900}, accept_downloads=True); page = ctx.new_page(); mock.install(page)
    page.goto('http://localhost:8099/index.html'); page.wait_for_function("document.querySelector('#surah').options.length>0", timeout=15000)
    page.select_option('#surah','112'); page.wait_for_function("window.__qvm.S.ayat.length==4")
    tab(page,'bg'); page.set_input_files('#bgFiles',['/tmp/t/vid10.webm','/tmp/t/img.png']); page.wait_for_function("window.__qvm.S.lib.length==6", timeout=10000)
    page.uncheck('#lib label:nth-child(1) input'); page.uncheck('#lib label:nth-child(2) input'); page.uncheck('#lib label:nth-child(3) input'); page.uncheck('#lib label:nth-child(4) input')
    ok('only 2 local bgs selected', page.evaluate("[...window.__qvm.S.selected].length")==2, str(page.evaluate("[...window.__qvm.S.selected]")))
    page.uncheck('#shuffle')
    page.click('#play'); page.wait_for_function("window.__qvm.S.audio!==null", timeout=15000); time.sleep(2)
    colors=page.evaluate("""(()=>{const c=document.querySelector('#cv');const d=c.getContext('2d').getImageData(0,0,c.width,40).data;const s=new Set();for(let i=0;i<d.length;i+=16){s.add((d[i]>>4)+','+(d[i+1]>>4)+','+(d[i+2]>>4))}return s.size})()""")
    ok('preview draws moving video background (many colors)', colors>6, str(colors))
    page.click('#play'); tab(page,'exp'); page.select_option('#quality','2')
    page.click('#exp')
    # hidden-tab cancel check later; now full export 12s
    page.wait_for_function("document.querySelector('#result').style.display==='flex'", timeout=60000)
    with page.expect_download() as d: page.click('#dl')
    out='/tmp/t/out_full.'+d.value.suggested_filename.split('.')[-1]; d.value.save_as(out)
    dur=subprocess.run(['ffmpeg','-v','info','-i',out,'-f','null','-'],capture_output=True,text=True).stderr
    m=re.findall(r'time=(\d+):(\d+):([\d.]+)',dur); secs=int(m[-1][0])*3600+int(m[-1][1])*60+float(m[-1][2])
    ok('12s audio (4 ayat) => ~12s video', 11<secs<13.5, f'{secs:.2f}')
    for i,t in enumerate([2,6,9.2,10.6,11.5]): subprocess.run(['ffmpeg','-y','-v','error','-ss',str(t),'-i',out,'-frames:v','1',f'/tmp/t/g{i}.png'])
    # check bg frame stats: before 10s video (testsrc2 colorful), after 10.6s image (blue 0x225588 mostly)
    def avg(path, y0=0, h=80):
        r=subprocess.run(['ffmpeg','-v','error','-i',path,'-vf',f'crop=iw:{h}:0:{y0},scale=1:1','-f','rawvideo','-pix_fmt','rgb24','-'],capture_output=True).stdout
        return tuple(r[:3])
    v_before = avg('/tmp/t/g1.png'); i_after = avg('/tmp/t/g4.png')
    print('avg top strip video-time', v_before, 'image-time', i_after)
    ok('after segment switch background is the image color (~34,85,136 darkened)', abs(i_after[2]-i_after[0])>40, str(i_after))
    ok('video segment differs from image segment', sum(abs(a-b) for a,b in zip(v_before,i_after))>25, f'{v_before} vs {i_after}')
    # 4) hidden tab cancels export
    tab(page,'exp'); page.click('#exp'); page.wait_for_function("document.querySelector('#prog').value>0.1", timeout=15000)
    page.evaluate("Object.defineProperty(document,'hidden',{get:()=>true,configurable:true}); document.dispatchEvent(new Event('visibilitychange'))")
    page.wait_for_function("document.querySelector('#exp').disabled===false", timeout=15000)
    ok('leaving page cancels export with clear reason', 'غادرت' in page.inner_text('#expMsg'), page.inner_text('#expMsg'))
    page.evaluate("Object.defineProperty(document,'hidden',{get:()=>false,configurable:true})")
    print('SUMMARY', sum(1 for r in R if r[1]), '/', len(R))
    b.close()
