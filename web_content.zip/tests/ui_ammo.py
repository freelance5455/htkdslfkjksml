"""Střelivo: data, záložka Studia, pole u věže, hra (výstřel / let / dopad), export:  python3 -I tests/ui_ammo.py"""
import glob, json
from playwright.sync_api import sync_playwright
exe = (glob.glob('/opt/pw-browsers/chromium-*/chrome-linux/chrome') or [None])[0]
errs, results = [], []
def check(n, c, x=''): results.append(bool(c)); print(('OK   ' if c else 'FAIL ') + n + (' ' + str(x) if x != '' else ''))
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=exe, args=['--no-sandbox'])
    ctx = b.new_context(viewport={'width': 1440, 'height': 900}); pg = ctx.new_page()
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type in ('error', 'warning') and 'willReadFrequently' not in m.text else None)
    pg.goto('file:///home/claude/BubbleDefence/index.html'); pg.wait_for_selector('.content:not(.hidden) .intro')
    pg.evaluate("BD.dev.unlocked = true; BD.dev.studio = true; BD.studio.enable(true); BD.dev.save && BD.dev.save()")
    check('výchozí střela existuje', pg.evaluate("!!BD.data.ammo.default && BD.studio.ids('ammo').join() === 'default'"))
    pg.click('text=Nová lokální hra'); pg.wait_for_selector('.content:not(.hidden) .menu'); pg.wait_for_timeout(300)
    pg.click('.mi:has-text("Studio")'); pg.wait_for_selector('.stv'); pg.wait_for_timeout(400)
    check('záložka Střelivo je', pg.locator('[data-tab=ammo]').count() == 1)
    pg.click('[data-tab=ammo]'); pg.wait_for_timeout(400)
    check('v seznamu je Výchozí střela', pg.locator('.stu-item').count() == 1)
    check('výchozí střela nejde smazat', pg.locator('[data-act=stu-remove]').count() == 0)
    check('náhled s časovou osou je vidět', pg.locator('[data-role=am-cv]').count() == 1 and pg.locator('[data-role=am-seg]').count() == 1)
    check('přepínač fází', pg.locator('[data-ph]').count() == 3)
    # nová střelivo, tvar ve fázi Let
    pg.fill('[data-role=stu-newid]', 'Plamen'); pg.click('[data-act=stu-create]'); pg.wait_for_timeout(500)
    check('vzniklo střelivo plamen', pg.evaluate("!!BD.studio.KINDS.ammo.plamen"))
    pg.click('[data-ph=shot]'); pg.click('[data-act=look-from]'); pg.wait_for_timeout(300)
    check('tvar letu se uložil do shot.sprite', pg.evaluate("BD.studio.KINDS.ammo.plamen.shot.sprite.nodes.length === 1"))
    pg.click('[data-ph=muzzle]'); pg.wait_for_timeout(200)
    check('jiná fáze je zatím bez tvaru', pg.locator('[data-act=look-from]').count() == 1 and pg.evaluate("!BD.studio.KINDS.ammo.plamen.muzzle.sprite"))
    pg.click('[data-act=look-from]'); pg.click('[data-ph=impact]'); pg.click('[data-act=look-from]'); pg.wait_for_timeout(300)
    pg.evaluate("BD.studio.set('ammo','plamen','dmgMul',2); BD.studio.set('ammo','plamen','shot.trail',0.5); BD.studio.set('ammo','plamen','shot.spin',2)")
    pg.click('[data-act=am-play]'); pg.wait_for_timeout(700)
    px = pg.evaluate("""(() => { const c = document.querySelector('[data-role=am-cv]'); const x = c.getContext('2d'); const d = x.getImageData(0, 0, c.width, c.height).data; let n = 0; for (let i = 0; i < d.length; i += 4) if (d[i] > 150 && d[i + 1] > 150) n++; return n; })()""")
    check('náhled něco kreslí', px > 30, px)
    # pole u věže
    pg.click('[data-tab=towers]'); pg.wait_for_timeout(300); pg.click('[data-id=normal_a]'); pg.wait_for_timeout(300); pg.click('[data-panel=props]'); pg.wait_for_timeout(200)
    check('věž má pole Střelivo', pg.locator('[data-f=ammo]').count() == 1)
    pg.select_option('[data-f=ammo]', 'plamen'); pg.wait_for_timeout(200)
    check('věž si pamatuje střelivo', pg.evaluate("BD.data.towers.normal_a.ammo") == 'plamen')
    # kreslení ve hře: střela s tvarem, stopa, výstřel a dopad se vykreslí bez chyby a něco nakreslí
    n = pg.evaluate("""(() => {
      const c = document.createElement('canvas'); c.width = c.height = 200; const x = c.getContext('2d'), D = BD.render.draw;
      D.shot(x, { x: 4, y: 4, am: 'plamen', ang: 0.5, age: 1, trail: [{ x: 3.5, y: 3.8, a: 0.5, l: 0 }, { x: 3.8, y: 3.9, a: 0.5, l: 0 }], big: 0, splash: 0, color: '#fff' }, 26);
      D.fx(x, { kind: 'ammo', ph: 'muzzle', am: 'plamen', x: 2, y: 2, aim: 0, t: 0.05, life: 0.2 }, 26);
      D.fx(x, { kind: 'ammo', ph: 'impact', am: 'plamen', x: 6, y: 6, aim: 0, t: 0.05, life: 0.4 }, 26);
      const d = x.getImageData(0, 0, 200, 200).data; let k = 0; for (let i = 3; i < d.length; i += 4) if (d[i] > 20) k++; return k; })()""")
    check('hra střelu, výstřel i dopad nakreslí', n > 200, n)
    # export / import
    txt = pg.evaluate("BD.studio.exportText()")
    o = json.loads(txt)
    check('export obsahuje střelivo', 'plamen' in o['items']['ammo'] and o['items']['ammo']['plamen']['custom'])
    pg.evaluate("BD.studio.remove('ammo','plamen')"); pg.wait_for_timeout(200)
    check('po smazání se věž vrací k výchozí střele', pg.evaluate("BD.render.ammo.get(BD.data.towers.normal_a.ammo) === BD.data.ammo.default"))
    res = pg.evaluate("t => BD.studio.importText(t)", txt)
    check('import vrátí střelivo', res['ok'] and pg.evaluate("!!BD.studio.KINDS.ammo.plamen && !!BD.studio.KINDS.ammo.plamen.impact.sprite"), res)
    check('žádné chyby v konzoli', not errs, errs[:3])
    b.close()
print('\nvýsledek: %d/%d | chyby: %s' % (sum(results), len(results), 'žádné' if not errs else errs[:3]))
