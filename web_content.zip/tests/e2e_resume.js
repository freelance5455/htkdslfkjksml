// node tests/e2e_resume.js — kayıttan devam: eski/bekleyen fetih ve bonus durumları yeni kurala göre çözülür, bir kez uygulanır
const { chromium } = require('playwright'); const path = require('path');
const URL = 'file://' + path.resolve(__dirname, '..') + '/index.html'; let fails = 0, n = 0;
const ok = (c, m) => { n++; console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fails++; };
(async () => {
  const b = await chromium.launch();
  async function mk(setupFn) { // oyun kur, durumu hazırla, kaydet
    const ctx = await b.newContext({ viewport: { width: 900, height: 700 } }); const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(String(e)));
    await p.goto(URL); await p.waitForTimeout(800);
    await p.evaluate(setupFn); return { ctx, p, errs };
  }
  const base = `SET.rm = true; newGame(1); closeMod(); G.pl = G.cur = G.act = 'TUR'; G.sel = null; G.T = { turn: 1, roll: 6, moves: 6, scouted: false }; G.es = {}; G.ed = {}; G.bonusUsed = {};`;
  // 1) eski kayıt: bekleyen fetih (pend, done=false), oyuncu 5/5 üstün → devam ederken otomatik bonus, seçim ekranı yok
  let t = await mk(new Function(base + `G.es['TUR'] = [80,75,90,85,70]; G.pend = { loser: 'GRC', tg: 'GRC', foeSnap: [60,65,80,70,50], destroyed: true, done: false, id: 7, bonus: { ok: true, used: false, id: 7 } }; G.ph = 'v5pick'; save();`));
  let r = await t.p.evaluate(() => { cont(); return { ph: G.ph, modal: document.getElementById('mod').style.display == 'flex', me: st('TUR').slice(), pend: G.pend && G.pend.done, used: JSON.stringify(G.bonusUsed) }; });
  ok(r.ph === 'act' && !r.modal && JSON.stringify(r.me) === JSON.stringify([88, 82.5, 99, 93.5, 77]) && r.pend, 'eski kayıt (bekleyen fetih, 5/5 üstün): seçimsiz otomatik bonus ' + JSON.stringify(r));
  const r2 = await t.p.evaluate(() => { cont(); return { me: st('TUR').slice() }; }); // kayda işlendi → ikinci devamda tekrar uygulanmaz
  ok(JSON.stringify(r2.me) === JSON.stringify([88, 82.5, 99, 93.5, 77]), 'tekrar "Devam Et": bonus ikinci kez uygulanmadı ' + JSON.stringify(r2.me));
  ok(t.errs.length === 0, 'sayfa hatası yok'); await t.ctx.close();
  // 2) bekleyen fetih, üstünlük yok → zorunlu seçim ekranı
  t = await mk(new Function(base + `G.es['TUR'] = [80,75,90,65,70]; G.pend = { loser: 'GRC', tg: 'GRC', foeSnap: [60,65,80,70,50], destroyed: true, done: false, id: 8 }; G.ph = 'v5pick'; save();`));
  r = await t.p.evaluate(() => { cont(); return { ph: G.ph, modal: document.getElementById('mod').style.display == 'flex', okDis: document.getElementById('cdok') && document.getElementById('cdok').disabled, me: st('TUR').slice() }; });
  ok(r.ph === 'v5pick' && r.modal && r.okDis === true && JSON.stringify(r.me) === JSON.stringify([80, 75, 90, 65, 70]), 'bekleyen fetih, üstünlük yok: zorunlu seçim ekranı, değer değişmedi ' + JSON.stringify(r));
  ok(t.errs.length === 0, 'sayfa hatası yok'); await t.ctx.close();
  // 3) eski kayıt: v8bonus (beşli bonus seçimi) bekliyor → otomatik çözülür, seçim sorulmaz
  t = await mk(new Function(base + `G.es['TUR'] = [80,75,90,85,70]; G.bpend = { ok: true, used: false, id: 9 }; G.ph = 'v8bonus'; save();`));
  r = await t.p.evaluate(() => { cont(); return { ph: G.ph, modal: document.getElementById('mod').style.display == 'flex', bn: !!document.getElementById('bnok'), me: st('TUR').slice(), bpend: !!G.bpend }; });
  ok(r.ph === 'act' && !r.modal && !r.bn && !r.bpend && JSON.stringify(r.me) === JSON.stringify([88, 82.5, 99, 93.5, 77]), 'eski kayıt (v8bonus bekliyor): beşli seçim sorulmadan otomatik ' + JSON.stringify(r));
  ok(t.errs.length === 0, 'sayfa hatası yok'); await t.ctx.close();
  console.log(fails ? `\n${fails}/${n} BAŞARISIZ` : `\nHEPSİ GEÇTİ (${n})`); await b.close(); process.exit(fails ? 1 : 0);
})();
