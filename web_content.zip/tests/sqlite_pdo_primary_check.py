from pathlib import Path
root=Path(__file__).resolve().parents[1]
bootstrap=(root/'app/bootstrap.php').read_text()
example=(root/'config.local.example.php').read_text()
readme=(root/'README.md').read_text()
assert "if (!extension_loaded('pdo_sqlite'))" in bootstrap
assert "$dsn = 'sqlite:' . $storage . '/workspace.sqlite';" in bootstrap
assert 'new PDO($dsn, null, null' in bootstrap
assert 'PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION' in bootstrap
assert 'PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC' in bootstrap
assert 'PDO::ATTR_EMULATE_PREPARES => false' in bootstrap
assert 'uses SQLite exclusively' in bootstrap
assert 'Database selection is fixed to PDO SQLite' in example
assert 'PDO SQLite only' in readme or 'PDO SQLite' in readme
print('PASS: PDO SQLite is the sole database driver; private storage/workspace.sqlite, exceptions, associative fetches and native prepared statements are configured.')
