import test from 'node:test';
import assert from 'node:assert/strict';
import { createTurnClock, startTurnClock, pauseTurnClock, remainingTurnMs, completeTurnClock, expireTurnClock, passTurnClock } from '../src/time-control.js';

test('horloge par défaut : vingt secondes par tour',()=>{const c=createTurnClock();assert.equal(c.secondsPerTurn,20);assert.equal(c.remainingMs,20000);});
test('décompte, pause et reprise conservent le temps restant',()=>{const c=createTurnClock(20);startTurnClock(c,1000);assert.equal(remainingTurnMs(c,3500),17500);pauseTurnClock(c,3500);assert.equal(c.remainingMs,17500);startTurnClock(c,5000);assert.equal(remainingTurnMs(c,6000),19000);});
test('un tour joué dans le temps est accepté et réinitialise au prochain tour',()=>{const c=createTurnClock(20);startTurnClock(c,0);assert.equal(completeTurnClock(c,19999).accepted,true);startTurnClock(c,20000);assert.equal(remainingTurnMs(c,20000),20000);});
test('dépassement du temps : le tour est refusé et l’horloge est expirée',()=>{const c=createTurnClock(20);startTurnClock(c,0);const r=completeTurnClock(c,20001);assert.equal(r.accepted,false);assert.equal(r.expired,true);assert.equal(remainingTurnMs(c,20002),0);});
test('une horloge expirée ne peut pas être relancée',()=>{const c=createTurnClock();expireTurnClock(c);startTurnClock(c,100);assert.equal(c.running,false);assert.equal(c.expired,true);});
test('refuse une durée nulle ou négative',()=>{assert.throws(()=>createTurnClock(0));assert.throws(()=>createTurnClock(-1));});
test('après perte de main, l’horloge est réinitialisée sans démarrer le temps du camp adverse',()=>{const c=createTurnClock(20);startTurnClock(c,0);expireTurnClock(c);passTurnClock(c);assert.equal(c.expired,false);assert.equal(c.running,false);assert.equal(remainingTurnMs(c,22000),20000);startTurnClock(c,22000);assert.equal(c.running,true);assert.equal(remainingTurnMs(c,22000),20000);});
