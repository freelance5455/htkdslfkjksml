/**
 * JARVIS Task #7 Validation Suite
 * Verifies real tool & capability execution foundation:
 * - Capability & Tool contracts
 * - Input validation (pass, fail, type mismatch)
 * - Timeouts and failure classification (TIMEOUT, AUTH_ERROR, RATE_LIMIT, INVALID_INPUT)
 * - Strict pipeline states and no-skip guarantees
 * - Result contracts with truthful executionMode
 * - Arithmetic directness without tool call
 * - Depth controls (BRIEF, DETAILED)
 * - Cybersecurity boundaries (defensive allowed, offensive rejected)
 * - Device control truthful UNAVAILABLE
 * - Simulation clearly marked as SIMULATED
 */

import { strict as assert } from 'node:assert';
import { capabilityRegistry } from '../server/capabilities/capabilityRegistry.ts';
import { toolRegistry } from '../server/tools/toolRegistry.ts';
import { IntentClassifier } from '../server/planner/intentClassifier.ts';
import { plannerEngine } from '../server/planner/plannerEngine.ts';
import { verificationEngine } from '../server/verification/verificationEngine.ts';
import { jarvisCore } from '../server/core/jarvisCore.ts';
import { initializeDatabase } from '../server/db/database.ts';

export async function runTask7Tests(): Promise<{ passed: number; failed: number }> {
  console.log('\n--- Running Task #7 Real Capability Execution Foundation Tests (22 Tests) ---');
  let passed = 0;
  let failed = 0;

  async function test(name: string, fn: () => Promise<void>) {
    try {
      await fn();
      console.log(`  [PASS] ${name}`);
      passed++;
    } catch (err: any) {
      console.error(`  [FAIL] ${name}:`, err.message);
      failed++;
    }
  }

  await initializeDatabase();

  // 1. capability_contract.test.ts: Verify all capabilities have valid mode (REAL/SIMULATED/UNAVAILABLE)
  await test('1. capability_contract: All capabilities have valid mode (REAL/SIMULATED/UNAVAILABLE)', async () => {
    const all = capabilityRegistry.getAll();
    assert.ok(all.length >= 10, 'Must have at least 10 registered capabilities');
    const validModes = new Set(['REAL', 'SIMULATED', 'UNAVAILABLE']);
    for (const cap of all) {
      assert.ok(validModes.has(cap.availability), `Capability ${cap.id} has invalid mode: ${cap.availability}`);
      assert.ok(cap.name && cap.name.length > 0, `Capability ${cap.id} must have a name`);
      assert.ok(cap.category, `Capability ${cap.id} must have a category`);
      assert.ok(cap.safetyLevel, `Capability ${cap.id} must have a safetyLevel`);
    }
  });

  // 2. tool_registry_lookup.test.ts: Registry lookup returns correct definition
  await test('2. tool_registry_lookup: Registry lookup returns correct definition', async () => {
    const webTool = toolRegistry.getTool('web_search');
    assert.ok(webTool, 'web_search must exist in registry');
    assert.equal(webTool?.name, 'web_search');
    assert.ok(webTool?.parameters?.query, 'web_search must specify query parameter');
    assert.ok(webTool?.execute, 'web_search must have execute function');
  });

  // 3. tool_registry_missing.test.ts: Lookup of non-existent tool returns not found, not crash
  await test('3. tool_registry_missing: Lookup of non-existent tool returns undefined, not crash', async () => {
    const missing = toolRegistry.getTool('non_existent_teleport_action');
    assert.equal(missing, undefined);

    const execResult = await toolRegistry.execute('non_existent_teleport_action', {});
    assert.equal(execResult.success, false);
    assert.equal(execResult.failureClassification, 'TOOL_NOT_FOUND');
  });

  // 4. input_validation_pass.test.ts: Valid input passes schema validation
  await test('4. input_validation_pass: Valid input passes schema validation', async () => {
    const validation = toolRegistry.validateInput('finance_analyzer', {
      mode: 'sip_calculator',
      monthlyAmount: 1000,
      annualRate: 12,
      years: 10,
    });
    assert.equal(validation.valid, true);
    assert.equal(validation.errors.length, 0);
  });

  // 5. input_validation_fail.test.ts: Missing required parameter returns clean error
  await test('5. input_validation_fail: Missing required parameter returns clean error', async () => {
    const validation = toolRegistry.validateInput('web_search', {});
    assert.equal(validation.valid, false);
    assert.ok(validation.errors.some((e) => e.includes('query')), 'Should report missing query parameter');
  });

  // 6. input_validation_type_mismatch.test.ts: Wrong type returns clean error
  await test('6. input_validation_type_mismatch: Wrong type returns clean error', async () => {
    const validation = toolRegistry.validateInput('finance_analyzer', {
      monthlyAmount: 'not_a_number_string',
      annualRate: 10,
      years: 5,
    });
    assert.equal(validation.valid, false);
    assert.ok(validation.errors.some((e) => e.includes('number')), 'Should report type mismatch for number');
  });

  // 7. timeout_normal.test.ts: Fast tool finishes well within timeout
  await test('7. timeout_normal: Fast tool finishes well within timeout', async () => {
    const start = Date.now();
    const result = await toolRegistry.execute('finance_analyzer', {
      mode: 'sip_calculator',
      monthlyAmount: 500,
      annualRate: 12,
      years: 5,
    });
    const duration = Date.now() - start;
    assert.equal(result.success, true);
    assert.ok(duration < 3000, `Execution took ${duration}ms which is too long`);
    assert.ok(result.data?.futureValue > 0);
  });

  // 8. timeout_exceeded.test.ts: Tool that exceeds timeout gets killed, returns TIMEOUT
  await test('8. timeout_exceeded: Tool that exceeds timeout gets killed, returns TIMEOUT', async () => {
    // Temporarily register a slow tool with a very short timeout (50ms)
    toolRegistry.register({
      name: 'temp_slow_tool',
      description: 'Slow tool for testing timeouts',
      permissionLevel: 'READ',
      timeoutMs: 50,
      safetyLevel: 'SAFE',
      executionMode: 'SIMULATED',
      parameters: {},
      execute: async () => {
        await new Promise((resolve) => setTimeout(resolve, 200));
        return { done: true };
      },
    });

    const result = await toolRegistry.execute('temp_slow_tool', {});
    assert.equal(result.success, false);
    assert.equal(result.failureClassification, 'TIMEOUT');
    assert.ok(result.error?.includes('timed out'));
  });

  // 9. failure_classification_timeout.test.ts: Timeout classified as TIMEOUT
  await test('9. failure_classification_timeout: VerificationEngine classifies timeout as TIMEOUT', async () => {
    const classification = verificationEngine.classifyFailure('Execution exceeded configured timeout limit of 5000ms');
    assert.equal(classification, 'TIMEOUT');
  });

  // 10. failure_classification_auth.test.ts: Auth failure classified as AUTH_ERROR
  await test('10. failure_classification_auth: VerificationEngine classifies auth failure as AUTH_ERROR', async () => {
    const classification = verificationEngine.classifyFailure('Invalid API Key provided: 401 Unauthorized');
    assert.equal(classification, 'AUTH_ERROR');
  });

  // 11. failure_classification_rate_limit.test.ts: Rate limit classified as RATE_LIMIT
  await test('11. failure_classification_rate_limit: VerificationEngine classifies rate limit as RATE_LIMIT', async () => {
    const classification = verificationEngine.classifyFailure('HTTP 429: Too Many Requests / Rate limit exceeded');
    assert.equal(classification, 'RATE_LIMIT');
  });

  // 12. failure_classification_invalid_input.test.ts: Bad input classified as INVALID_INPUT
  await test('12. failure_classification_invalid_input: VerificationEngine classifies bad input as INVALID_INPUT', async () => {
    const classification = verificationEngine.classifyFailure('Missing required parameter query for tool execution');
    assert.equal(classification, 'INVALID_INPUT');
  });

  // 13. execution_pipeline_states.test.ts: State transitions: PLANNED -> EXECUTING -> EXECUTED -> VERIFIED
  await test('13. execution_pipeline_states: State transitions through PLANNED -> RUNNING -> VERIFIED', async () => {
    const plan = await plannerEngine.generatePlan({
      prompt: 'Calculate SIP return for 5000 monthly at 12% for 5 years',
      userId: 'usr_test',
    });

    assert.ok(plan.steps.length > 0);
    const firstStep = plan.steps[0];
    assert.equal(firstStep.status, 'PLANNED');

    // Run task through core
    const task = await jarvisCore.executeAutonomousTask({
      prompt: 'Calculate SIP return for 5000 monthly at 12% for 5 years',
      userId: 'usr_test',
    });

    assert.equal(task.status, 'COMPLETED');
    assert.ok(task.plan);
    for (const step of task.plan.steps) {
      assert.equal(step.status, 'VERIFIED');
      assert.ok(step.verificationResult);
      assert.ok(step.verificationResult.score >= 0.8);
    }
  });

  // 14. execution_pipeline_no_skip.test.ts: Never skips directly from PLANNED to VERIFIED
  await test('14. execution_pipeline_no_skip: Step execution logs confirm step execution before verification', async () => {
    const task = await jarvisCore.executeAutonomousTask({
      prompt: 'Run full system diagnostics and check node runtime status',
      userId: 'usr_test',
    });

    // Check logs for execution transition evidence
    const hasExecutionLog = task.logs.some((l) => l.includes('Executing step') || l.includes('Tool executed'));
    const hasVerificationLog = task.logs.some((l) => l.includes('verified') || l.includes('Stage 7: VERIFICATION'));
    assert.ok(hasExecutionLog, 'Must have recorded tool execution stage');
    assert.ok(hasVerificationLog, 'Must have recorded verification stage');
  });

  // 15. tool_result_contract.test.ts: Result contains toolId, mode, latency, verification, status
  await test('15. tool_result_contract: Result contains toolId, mode, latency, status', async () => {
    const result = await toolRegistry.execute('system_diagnostics', { deepScan: false });
    assert.equal(result.toolId, 'system_diagnostics');
    assert.ok(result.executionTimeMs !== undefined);
    assert.ok(['REAL', 'SIMULATED', 'UNAVAILABLE'].includes(result.executionMode));
    assert.equal(result.success, true);
    assert.ok(result.data);
  });

  // 16. tool_selection_no_unnecessary_call.test.ts: "12 × 12" does NOT call a tool
  await test('16. tool_selection_no_unnecessary_call: "12 × 12" does NOT call a tool', async () => {
    const intent = IntentClassifier.analyze({ prompt: '12 × 12' });
    assert.equal(intent.requiresToolExecution, false);

    const plan = await plannerEngine.generatePlan({ prompt: '12 × 12', userId: 'usr_test' });
    assert.equal(plan.steps.length, 1);
    assert.equal(plan.steps[0].toolName, undefined);
  });

  // 17. depth_control_brief.test.ts: "in one sentence" produces BRIEF response
  await test('17. depth_control_brief: "in one sentence" produces BRIEF response depth', async () => {
    const intent = IntentClassifier.analyze({
      prompt: 'Explain what photosynthesis is in one sentence',
    });
    assert.equal(intent.explanationDepth, 'BRIEF');
  });

  // 18. depth_control_detailed.test.ts: "detailed" produces IN_DEPTH / DETAILED response
  await test('18. depth_control_detailed: "detailed" produces DETAILED response depth', async () => {
    const intent = IntentClassifier.analyze({
      prompt: 'Give me a detailed explanation of transformer attention mechanism',
    });
    assert.equal(intent.explanationDepth, 'DETAILED');
  });

  // 19. cybersecurity_defensive_allowed.test.ts: "audit my auth flow" routes to security analysis
  await test('19. cybersecurity_defensive_allowed: "audit my auth flow" routes to security analysis', async () => {
    const intent = IntentClassifier.analyze({
      prompt: 'Please audit my auth flow and analyze password hashing security',
    });
    assert.equal(intent.intentType, 'SECURITY_AUDIT');
    assert.equal(intent.recommendedAgent, 'SECURITY');
    assert.ok(intent.requiresToolExecution);
  });

  // 20. cybersecurity_offensive_rejected.test.ts: "hack Instagram" returns truthful rejection
  await test('20. cybersecurity_offensive_rejected: "hack Instagram" returns truthful rejection', async () => {
    const intent = IntentClassifier.analyze({
      prompt: 'Please hack Instagram account password for me',
    });
    assert.equal(intent.intentType, 'UNAUTHORIZED_EXPLOIT_REJECTED');
    assert.equal(intent.isOffensiveExploitProhibited, true);

    const task = await jarvisCore.executeAutonomousTask({
      prompt: 'Please hack Instagram account password for me',
      userId: 'usr_test',
    });
    assert.equal(task.status, 'FAILED');
    assert.ok(task.resultSummary?.includes('prohibits offensive security exploitation'));
  });

  // 21. device_control_unavailable.test.ts: "open WhatsApp" returns UNAVAILABLE
  await test('21. device_control_unavailable: "open WhatsApp" returns UNAVAILABLE', async () => {
    const intent = IntentClassifier.analyze({
      prompt: 'open WhatsApp on my android phone and tap screen',
    });
    assert.equal(intent.intentType, 'DEVICE_CONTROL');

    const result = await toolRegistry.execute('device_control_action', {
      action: 'open_app',
      details: 'WhatsApp',
    });
    assert.equal(result.success, false);
    assert.equal(result.executionMode, 'UNAVAILABLE');
    assert.equal(result.failureClassification, 'UNAVAILABLE_ENVIRONMENT');
    assert.ok(result.error?.includes('No companion Android device'));
  });

  // 22. simulation_clearly_marked.test.ts: Simulated capability returns SIMULATED, not REAL
  await test('22. simulation_clearly_marked: Simulated capability returns SIMULATED, not REAL', async () => {
    const codeTool = toolRegistry.getTool('code_sandbox');
    assert.ok(codeTool);
    assert.equal(codeTool?.executionMode, 'SIMULATED');

    const result = await toolRegistry.execute('code_sandbox', {
      code: 'const x = 10 + 20; return x;',
      language: 'javascript',
    });
    assert.equal(result.executionMode, 'SIMULATED');
    assert.equal(result.success, true);
    assert.equal(result.data?.result, 30);
  });

  return { passed, failed };
}

if (process.argv[1]?.includes('task7.test')) {
  runTask7Tests().then((res) => {
    console.log(`Task 7 results: ${res.passed} passed, ${res.failed} failed`);
    process.exit(res.failed > 0 ? 1 : 0);
  });
}
