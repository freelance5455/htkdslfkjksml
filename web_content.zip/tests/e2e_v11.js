// node tests/e2e_v11.js — V11: bayrak yok, yakın kamera, sürükleme/zoom, rAF sınırı, hata yok
const { chromium } = require('playwright'); const path = require('path');
const URL = 'file://' + path.resolve(__dirname, '..') + '/index.html'; let fails = 0, n = 0;
const ok = (c, m) => { n++; console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fails++; };
(async () => {
  const b = await chromium.launch();
  for (const vp of [{ width: 420, height: 800 }, { width: 1280, height: 720 }]) {
    const p = await b.newPage({ viewport: vp }); const errs = []; p.on('pageerror', e => errs.push(String(e)));
    await p.goto(URL); await p.waitForTimeout(800);
    await p.evaluate(() => { SET.rm = true; newGame(1); }); await p.waitForTimeout(400);
    const r = await p.evaluate(() => ({
      imgs: document.querySelectorAll('#map svg image').length, clips: document.querySelectorAll('#map svg clipPath').length,
      fg: document.querySelectorAll('#map g.fg, #map g.ctr, #map path.lift').length, k: CAM.k, kmin: KMIN, W, H: H_, paths: document.querySelectorAll('#map path.c').length }));
    const tag = vp.width + 'px';
    ok(r.imgs === 0 && r.clips === 0 && r.fg === 0, `${tag}: haritada bayrak/clipPath/ctr/lift yok (img=${r.imgs}, clip=${r.clips})`);
    ok(r.paths > 150, `${tag}: ${r.paths} ülke yolu çiziliyor`);
    ok(r.k >= r.kmin && r.k <= 70, `${tag}: başlangıç kamera ölçeği yakın (k=${r.k.toFixed(1)} ≥ KMIN=${r.kmin})`);
    // zoom-out alt sınırı
    const kz = await p.evaluate(async () => { for (let i = 0; i < 6; i++) { zoomBy(.5); await new Promise(r => setTimeout(r, 30)); } await new Promise(r => setTimeout(r, 200)); return CAM.k; });
    ok(kz >= r.kmin - 1e-6, `${tag}: art arda uzaklaştırmada ölçek KMIN altına inmiyor (k=${kz.toFixed(2)})`);
    // mouse sürükleme + rAF: transform attr güncelleniyor, ülke seçimi tetiklenmiyor
    await p.evaluate(() => { G.sel = null; render(); });
    const box = await p.evaluate(() => { const e = document.getElementById('map').getBoundingClientRect(); return { x: e.x, y: e.y, w: e.width, h: e.height }; });
    const before = await p.evaluate(() => ({ x: CAM.x, y: CAM.y, sel: G.sel }));
    await p.mouse.move(box.x + box.w / 2, box.y + box.h / 2); await p.mouse.down();
    const t0 = Date.now(); for (let i = 1; i <= 60; i++) { await p.mouse.move(box.x + box.w / 2 - i * 3, box.y + box.h / 2 + i, { steps: 1 }); }
    await p.mouse.up(); await p.waitForTimeout(200);
    const after = await p.evaluate(() => ({ x: CAM.x, y: CAM.y, sel: G.sel, tr: document.querySelector('#map svg > g').getAttribute('transform') }));
    ok(Math.abs(after.x - before.x) > 20 || Math.abs(after.y - before.y) > 5, `${tag}: sürükleme haritayı kaydırdı (dx=${(after.x - before.x).toFixed(0)})`);
    ok(after.tr.includes(String(after.x)) || after.tr.includes(after.x.toFixed(0)), `${tag}: DOM transform CAM ile senkron`);
    ok(after.sel === before.sel, `${tag}: sürükleme ülke seçimi tetiklemedi`);
    // sürükleme sırasında kare süresi ölçümü (sentetik, headless — yalnızca kıyas)
    const perf = await p.evaluate(async () => {
      const ts = []; let last = performance.now(); let run = true; (function f(t) { ts.push(t - last); last = t; if (run) requestAnimationFrame(f); })(last);
      const t0 = performance.now(); let i = 0;
      await new Promise(res => { (function step() { const a = (i++ % 120) / 120 * 2 * Math.PI; goTo([CAM.x + Math.sin(a) * 40, CAM.y + Math.cos(a) * 20], CAM.k, 0); if (performance.now() - t0 < 2500) requestAnimationFrame(step); else res(); })(); });
      run = false; ts.sort((a, b) => a - b); return { n: ts.length, med: ts[Math.floor(ts.length / 2)], p95: ts[Math.floor(ts.length * .95)], max: ts[ts.length - 1] };
    });
    console.log(tag, 'kare süresi ms', JSON.stringify(perf));
    ok(perf.n > 20, `${tag}: pan sırasında ${perf.n} kare üretildi`);
    // ülke seçimi hâlâ çalışıyor
    await p.evaluate(() => pickC('TUR')); await p.waitForTimeout(300);
    ok(await p.evaluate(() => G.sel === 'TUR' && document.getElementById('panel').style.display == 'block'), `${tag}: ülke seçimi + bilgi paneli çalışıyor`);
    ok(errs.length === 0, `${tag}: sayfa hatası yok ${errs.slice(0, 3).join('|')}`);
    await p.close();
  }
  console.log(fails ? `\n${fails}/${n} BAŞARISIZ` : `\nHEPSİ GEÇTİ (${n})`); await b.close(); process.exit(fails ? 1 : 0);
})();
