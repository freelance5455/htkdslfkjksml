#!/usr/bin/env bash
# Spins up a throw-away PostgreSQL 16 cluster, applies the migration and proves the DB-level guarantees.
set -u
BIN=/usr/lib/postgresql/16/bin; D=$(mktemp -d); PORT=54329; PASS=0; FAIL=0
HERE=$(cd "$(dirname "$0")/.." && pwd)
chown postgres "$D" 2>/dev/null; chmod 700 "$D"
run() { runuser -u postgres -- "$@"; }
run $BIN/initdb -D "$D/data" -A trust >/dev/null || { echo "initdb failed"; exit 2; }
run $BIN/pg_ctl -D "$D/data" -o "-p $PORT -k $D" -l "$D/log" -w start >/dev/null || { cat "$D/log"; exit 2; }
trap 'run $BIN/pg_ctl -D "$D/data" -m immediate stop >/dev/null 2>&1; rm -rf "$D"' EXIT
Q() { run $BIN/psql -h "$D" -p $PORT -U postgres -d acc -v ON_ERROR_STOP=1 -qtAX "$@"; }
run $BIN/createdb -h "$D" -p $PORT acc
Q -f "$HERE/database/migrations/001_core.sql" >/dev/null || { echo "MIGRATION FAILED"; exit 1; }
# grant app role login-less usage via SET ROLE inside sessions
expect_ok()   { if out=$(Q -c "$2" 2>&1); then PASS=$((PASS+1)); else FAIL=$((FAIL+1)); echo "FAIL (expected ok): $1 -> $out"; fi; }
expect_err()  { if out=$(Q -c "$2" 2>&1); then FAIL=$((FAIL+1)); echo "FAIL (expected error $3): $1"; else if echo "$out" | grep -q "$3"; then PASS=$((PASS+1)); else FAIL=$((FAIL+1)); echo "FAIL (wrong error): $1 -> $out"; fi; fi; }
expect_eq()   { got=$(Q -c "$2" 2>&1 | tr -d '\n'); if [ "$got" = "$3" ]; then PASS=$((PASS+1)); else FAIL=$((FAIL+1)); echo "FAIL: $1 expected '$3' got '$got'"; fi; }

A=11111111-1111-1111-1111-111111111111; B=22222222-2222-2222-2222-222222222222; U=33333333-3333-3333-3333-333333333333
Q <<SQL >/dev/null
INSERT INTO users(id,email,name,password_hash) VALUES ('$U','a@x.io','A','h');
INSERT INTO companies(id,name,base_currency) VALUES ('$A','Alpha','IRR'),('$B','Beta','IRR');
INSERT INTO memberships VALUES ('$A','$U','owner'),('$B','$U','owner');
INSERT INTO accounts(company_id,id,code,type,name_fa,name_en) VALUES
 ('$A','A1000','1000','asset','بانک','Bank'),('$A','A4000','4000','revenue','درآمد','Revenue'),
 ('$B','A1000','1000','asset','بانک','Bank'),('$B','A4000','4000','revenue','درآمد','Revenue');
INSERT INTO fiscal_periods VALUES ('$A','1405-07','2026-09-23','2026-10-22','open'),('$A','1405-06','2026-08-23','2026-09-22','closed'),
 ('$B','1405-07','2026-09-23','2026-10-22','open');
SQL

post() { # company, id, date, debit, credit  (a balanced two-line entry)
 echo "BEGIN; INSERT INTO journal_entries(company_id,id,seq,entry_date,prev_hash,hash,idempotency_key) VALUES ('$1','$2',(SELECT COALESCE(max(seq),0)+1 FROM journal_entries WHERE company_id='$1'),'$3','0','h$2',${6:-NULL});
 INSERT INTO journal_lines(company_id,entry_id,line_no,account_id,currency,debit,base_debit) VALUES ('$1','$2',1,'A1000','IRR',$4,$4);
 INSERT INTO journal_lines(company_id,entry_id,line_no,account_id,currency,credit,base_credit) VALUES ('$1','$2',2,'A4000','IRR',$5,$5); COMMIT;"; }

expect_ok  "balanced entry commits"            "$(post $A E1 2026-10-01 1000 1000)"
expect_err "unbalanced entry rejected"          "$(post $A E2 2026-10-02 1000 999)" "UNBALANCED"
expect_err "entry without lines rejected"       "BEGIN; INSERT INTO journal_entries(company_id,id,seq,entry_date,prev_hash,hash) VALUES ('$A','E3',9,'2026-10-02','0','h'); COMMIT;" "UNBALANCED"
expect_err "closed period rejected"             "$(post $A E4 2026-09-01 5 5)" "PERIOD_CLOSED"
expect_err "no period rejected"                 "$(post $A E5 2030-01-01 5 5)" "NO_PERIOD"
expect_err "UPDATE of posted entry forbidden"   "UPDATE journal_entries SET memo='x' WHERE id='E1'" "IMMUTABLE"
expect_err "DELETE of posted entry forbidden"   "DELETE FROM journal_entries WHERE id='E1'" "IMMUTABLE"
expect_err "UPDATE of line forbidden"           "UPDATE journal_lines SET debit=1 WHERE entry_id='E1'" "IMMUTABLE"
expect_err "DELETE of line forbidden"           "DELETE FROM journal_lines WHERE entry_id='E1'" "IMMUTABLE"
expect_ok  "idempotency first use"              "$(post $A E6 2026-10-03 7 7 "'k1'")"
expect_err "duplicate idempotency key rejected" "$(post $A E7 2026-10-03 7 7 "'k1'")" "journal_idem"
expect_ok  "same key in other company is fine"  "$(post $B E1 2026-10-03 7 7 "'k1'")"
expect_ok  "reversal entry (new entry)"         "BEGIN; INSERT INTO journal_entries(company_id,id,seq,entry_date,reverses,prev_hash,hash) VALUES ('$A','R1',20,'2026-10-04','E1','0','hr');
 INSERT INTO journal_lines(company_id,entry_id,line_no,account_id,currency,credit,base_credit) VALUES ('$A','R1',1,'A1000','IRR',1000,1000);
 INSERT INTO journal_lines(company_id,entry_id,line_no,account_id,currency,debit,base_debit) VALUES ('$A','R1',2,'A4000','IRR',1000,1000); COMMIT;"
expect_err "second reversal of same entry rejected" "BEGIN; INSERT INTO journal_entries(company_id,id,seq,entry_date,reverses,prev_hash,hash) VALUES ('$A','R2',21,'2026-10-04','E1','0','hr2');
 INSERT INTO journal_lines(company_id,entry_id,line_no,account_id,currency,credit,base_credit) VALUES ('$A','R2',1,'A1000','IRR',1000,1000);
 INSERT INTO journal_lines(company_id,entry_id,line_no,account_id,currency,debit,base_debit) VALUES ('$A','R2',2,'A4000','IRR',1000,1000); COMMIT;" "journal_one_reversal"
expect_err "negative amount rejected"           "INSERT INTO journal_lines(company_id,entry_id,line_no,account_id,currency,debit,base_debit) VALUES ('$A','E1',9,'A1000','IRR',-5,-5)" "check"
expect_err "overlapping fiscal periods rejected" "INSERT INTO fiscal_periods VALUES ('$A','dup','2026-10-01','2026-10-31','open')" "conflicting key"
expect_err "audit log is append-only"           "INSERT INTO audit_log(company_id,action) VALUES ('$A','x'); DELETE FROM audit_log" "IMMUTABLE"
expect_err "last owner cannot be removed"       "DELETE FROM memberships WHERE company_id='$A' AND user_id='$U'" "LAST_OWNER"
expect_err "last owner cannot be demoted"       "UPDATE memberships SET role='viewer' WHERE company_id='$A' AND user_id='$U'" "LAST_OWNER"
expect_err "invoice total must equal net+tax"   "INSERT INTO contacts VALUES ('$A','C1','customer','X',null,null,null); INSERT INTO invoices(company_id,id,kind,contact_id,currency,issue_date,due_date,net,tax,total) VALUES ('$A','I1','sale','C1','IRR','2026-10-01','2026-10-30',100,10,999)" "check"
# --- tenant isolation with RLS (as the unprivileged app role)
rls() { echo "SET ROLE acconova_app; BEGIN; SELECT set_config('app.company_id','$1',true); SELECT set_config('app.user_id','$U',true); $2; COMMIT;"; }
cnt() { run $BIN/psql -h "$D" -p $PORT -U postgres -d acc -qtAX -c "$1" 2>&1 | tail -1; }
a=$(cnt "$(rls $A "SELECT count(*) FROM journal_entries")"); b=$(cnt "$(rls $B "SELECT count(*) FROM journal_entries")"); n=$(cnt "$(rls '' "SELECT count(*) FROM journal_entries")")
[ "$a" = "3" ] && PASS=$((PASS+1)) || { FAIL=$((FAIL+1)); echo "FAIL RLS A count: $a"; }
[ "$b" = "1" ] && PASS=$((PASS+1)) || { FAIL=$((FAIL+1)); echo "FAIL RLS B count: $b"; }
[ "$n" = "0" ] && PASS=$((PASS+1)) || { FAIL=$((FAIL+1)); echo "FAIL RLS no-tenant count: $n"; }
out=$(cnt "$(rls $B "INSERT INTO contacts VALUES ('$A','CX','customer','Evil',null,null,null)")")
echo "$out" | grep -q "row-level security" && PASS=$((PASS+1)) || { FAIL=$((FAIL+1)); echo "FAIL cross-tenant insert not blocked: $out"; }
out=$(cnt "$(rls $B "UPDATE accounts SET name_en='hacked' WHERE company_id='$A'; SELECT count(*) FROM accounts WHERE name_en='hacked'")")
[ "$out" = "0" ] && PASS=$((PASS+1)) || { FAIL=$((FAIL+1)); echo "FAIL cross-tenant update touched rows: $out"; }
echo "db tests: $PASS passed, $FAIL failed"; [ $FAIL -eq 0 ]
