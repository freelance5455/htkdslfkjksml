"""World Conquest e2e testleri (Playwright / Chromium). Çalıştırma: python3 tests/e2e_test.py"""
import os, sys, json
from playwright.sync_api import sync_playwright
URL='file://'+os.path.abspath(os.path.join(os.path.dirname(__file__),'..','www','index.html'))
res=[];errs=[]
def ok(name,cond,info=''):
    res.append((name,bool(cond),info));print(('PASS ' if cond else 'FAIL ')+name+(' | '+str(info) if info!='' else ''))
def fresh(b,w=414,h=760,touch=True):
    pg=b.new_page(viewport={'width':w,'height':h},has_touch=touch,is_mobile=touch)
    pg.on('pageerror',lambda e:errs.append('PE '+str(e)))
    pg.on('console',lambda m:errs.append(m.text) if m.type=='error' else None)
    pg.goto(URL);pg.wait_for_timeout(500);return pg
def start(pg,mode,start_id):
    pg.evaluate("newGame(%d)"%mode)
    for i in range(mode):
        pg.evaluate("G.sel='%s';render();pickOk()"%(start_id if i==0 else 'FRA'))
    pg.wait_for_timeout(900)
def noanim(pg): pg.evaluate("SET.spd=0;SET.rm=1;setSave()")
with sync_playwright() as p:
    b=p.chromium.launch()
    # 1 Açılış & dünya haritası
    pg=fresh(b)
    ok('1 harita açıldı, ülke sayısı',pg.evaluate("R.length")>=170,pg.evaluate("R.length"))
    ok('1 tüm yollar çizildi',pg.evaluate("document.querySelectorAll('path.c').length")==pg.evaluate("R.length"))
    ok('1 uzak kamera yok: açılış yakınlığı >= KMIN',pg.evaluate("CAM.k")>=pg.evaluate("KMIN")-.01,pg.evaluate("CAM.k"))
    pg.evaluate("zoomBy(.1)");pg.wait_for_timeout(500)
    ok('1 uzaklaştırma KMIN altına inemiyor',pg.evaluate("CAM.k")>=pg.evaluate("KMIN")-.01,pg.evaluate("CAM.k"))
    x0=pg.evaluate("CAM.x");pg.evaluate("panBy(1)");pg.wait_for_timeout(600)
    ok('1 sağ/sol kaydırma düğmesi kamerayı yatay kaydırıyor',pg.evaluate("CAM.x")!=x0,[x0,pg.evaluate("CAM.x")])
    # 2 Küçük/büyük ülke seçimi (gerçek tıklama)
    pg.evaluate("newGame(1)");pg.wait_for_timeout(300)
    for cid in ['RUS','LUX','QAT']:
        pg.evaluate("G.sel=null;render();home(0)");pg.wait_for_timeout(200)
        # önce dünya görünümünde tıklanabilir (ya path ya marker) bir nokta bul
        pg.evaluate("pickC('%s')"%cid);pg.wait_for_timeout(1300)
        ok('2 seçim '+cid,pg.evaluate("G.sel")==cid)
    # küçük ülkeye gerçek fare/dokunma ile tıklama (yakınlaşmış görünümde işaretçi)
    pg.evaluate("G.sel='LUX';render();focusSel(0)");pg.wait_for_timeout(300)
    pos=pg.evaluate("(function(){var r=M['LUX'],k=CAM.k,m=document.getElementById('map').getBoundingClientRect();return [m.left+CAM.x+r.px[0]*k,m.top+CAM.y+r.px[1]*k]})()")
    pg.evaluate("G.sel=null");pg.mouse.click(pos[0],pos[1]);pg.wait_for_timeout(300)
    ok('2 küçük ülke (LUX) gerçek tıklamayla seçilebiliyor',pg.evaluate("G.sel")=='LUX',pos)
    # 3-4 Kamera yakınlaşması, seçili ülke ve komşuları görünür
    def vis(pg,ids):
        return pg.evaluate("""(function(ids){var A=area(),out={};ids.forEach(function(id){var b=M[id].bb,k=CAM.k;var x0=CAM.x+b[0]*k,x1=CAM.x+b[2]*k,y0=CAM.y+b[1]*k,y1=CAM.y+b[3]*k;out[id]=x1>0&&x0<A.w&&y1>0&&y0<A.h});return out})(%s)"""%json.dumps(ids))
    for cid in ['TUR','LUX','CHE','JPN','USA','FJI']:
        pg.evaluate("G.sel=null;render();home(0)");pg.wait_for_timeout(150)
        k0=pg.evaluate("CAM.k");pg.evaluate("pickC('%s')"%cid);pg.wait_for_timeout(1400)
        k1=pg.evaluate("CAM.k");v=vis(pg,[cid])
        ok('3 yakınlaştı '+cid,k1>k0 and v[cid],'k %.2f→%.2f'%(k0,k1))
    pg.evaluate("G.sel=null;render();home(0)");pg.evaluate("newGame(1)");start(pg,1,'GRC')
    pg.evaluate("pickC('BGR')");pg.wait_for_timeout(1400)
    v=vis(pg,['BGR','GRC','TUR','MKD','ALB'])
    ok('4 seçili ülke + oyuncunun komşusu + saldırılabilir komşular görünür',all(v.values()),v)
    # panel haritanın çoğunu kaplamıyor
    ph=pg.evaluate("document.getElementById('panel').offsetHeight/document.getElementById('map').offsetHeight")
    ok('4 kompakt panel mobilde haritanın <%25 kısmı',ph<.25,'%.2f'%ph)
    # 5 dünya görünümüne dönüş
    pg.evaluate("worldView()");pg.wait_for_timeout(1000)
    ok('5 yakın görünüme dönüldü (uzak kamera yok)',pg.evaluate("CAM.k")>=pg.evaluate("KMIN")-.01 and pg.evaluate("G.sel")is None,pg.evaluate("CAM.k"))
    # 6 geçersiz saldırı (komşu olmayan)
    noanim(pg)
    ow0=pg.evaluate("JSON.stringify(G.owner)")
    pg.evaluate("G.sel='BRA';render();doAttack()");pg.wait_for_timeout(300)
    ok('6 komşu olmayan ülkeye saldırı engellendi',pg.evaluate("JSON.stringify(G.owner)")==ow0 and not pg.evaluate("BSH"))
    ok('6 hedef listesinde BRA yok',pg.evaluate("!targets(0,G.owner)['BRA']"))
    ok('6 hedef listesinde BGR (kara) var',pg.evaluate("targets(0,G.owner)['BGR']")=='land')
    # 7-8 Tek oyunculuda zar/sıra/hak sınırı yok
    ok('7 tek oyuncu: tur zarı aşaması yok',pg.evaluate("G.ph")=='act' and not pg.evaluate("document.querySelector('#mod').style.display=='flex'"))
    pg.evaluate("G.roll=1;G.left=0;G.P[0].s=[9999,9999,9999,9999,9999]")  # eski mekanikler olsaydı saldırıyı engellerdi
    # 9-12 Art arda 30 saldırı: her saldırıda zar sadece savaş zarı
    st=pg.evaluate("""(function(){var log=[],n=0,guard=0;
      while(n<30&&guard++<400){TG=targets(G.cur,G.owner);var ids=Object.keys(TG);if(!ids.length)break;
        var id=ids[Math.floor(Math.random()*ids.length)];G.sel=id;var before=G.owner[id],cnt=owned(0).length,st0=JSON.stringify(G.st[0]);
        doAttack();var w=G.owner[id]===0;
        log.push({id:id,won:w,own:owned(0).length-cnt,ph:G.ph,left:G.left,cur:G.cur,busy:G.busy});
        closeBattle();n++;if(G.over)break}
      return{n:n,log:log.slice(0,3),won:G.st[0].w,lost:G.st[0].l,c:G.st[0].c,ph:G.ph,up:G.up,own:owned(0).length}})()""")
    ok('8 30 art arda saldırı hiçbir hak/tur limitine takılmadı',st['n']>=30,st)
    ok('8 faz hep "act" (otomatik tur geçişi yok)',st['ph'] in('act','over'),st['ph'])
    ok('11 fetih sayacı = kazanılan savaş',st['c']==st['won'],st)
    ok('8 30 saldırının hepsi kazanıldı (güçlü ordu)',st['won']==30 and st['lost']==0,st)
    ok('12 fetihlerle toprak arttı (kazanma-kaybetme dengesi)',st['own']==1+st['won']-st['lost'],st)
    ok('13 geliştirme puanı her 5 fetihte',st['up']==st['c']//5,[st['up'],st['c']])
    # 9-10 Savaş zarları ve hesap
    ok('9 savaş hesabı: zar çarpanı ve 5 karşılaştırma',pg.evaluate("(function(){var r=WC.battle([10,10,10,10,10],[5,5,5,5,5],6,2,false,false);return r.rows.length==5&&r.win&&Math.abs(r.mult-1.4)<1e-9&&r.aw==5})()"))
    ok('10 eşit zarlarda galip savunan (3 şartı yoksa)',pg.evaluate("(function(){var r=WC.battle([5,5,5,5,5],[5,5,5,5,5],3,3,false,false);return !r.win&&r.aw==0})()"))
    ok('10 savaş galibi 3+ karşılaştırma ile belirlenir',pg.evaluate("WC.battle([9,9,9,1,1],[5,5,5,5,5],3,3,false,false).win")==True and pg.evaluate("WC.battle([9,9,1,1,1],[5,5,5,5,5],3,3,false,false).win")==False)
    # Fetih -> sahiplik tutarlılığı
    pg.evaluate("newGame(1)");start(pg,1,'GRC');noanim(pg)
    seq=pg.evaluate("""(function(){for(var i=0;i<60;i++){G.sel='BGR';G.owner.BGR=G.owner.BGR;var o=G.owner.BGR;if(o===0)break;TG=targets(0,G.owner);doAttack();closeBattle()}
       return{bgr:G.owner.BGR,names:owned(0).map(function(r){return r.id}).join(',')}})()""")
    ok('11 BGR ele geçirildi ve sahiplik 0',seq['bgr']==0,seq)
    t2=pg.evaluate("(function(){TG=targets(0,G.owner);return Object.keys(TG)})()")
    ok('12 fetih sonrası yeni komşular (ROU/SRB...) saldırılabilir',any(x in t2 for x in ['ROU','SRB','MKD']),t2[:8])
    # UI: fethedilen ülke seçili ve panelde 'Senin'
    pg.evaluate("G.sel='BGR';render()")
    ok('11 panelde fethedilen ülke "Senin" rozetli',pg.evaluate("document.getElementById('panel').textContent.toLowerCase().indexOf('senin')>=0||document.getElementById('panel').textContent.toLowerCase().indexOf('senİn')>=0"))
    # 13 veri tutarlılığı
    d=pg.evaluate("""(function(){var bad=[];R.forEach(function(r){var s=BASE[r.id];if(s.length!=5||s.some(function(v){return!isFinite(v)||v<0}))bad.push(r.id)});return bad})()""")
    ok('13 tüm ülke istatistikleri sonlu ve geçerli',len(d)==0,d)
    ok('13 savaş sonrası ekonomi transferi korunuyor',pg.evaluate("Object.keys(G.ed).length>=0&&isFinite(G.P[0].s[2])"))
    # keşif serbest (tek oyuncu)
    pg.evaluate("newGame(1)");start(pg,1,'GRC');noanim(pg)
    n=pg.evaluate("(function(){G.sel='BGR';TG=targets(0,G.owner);var c=0;for(var i=0;i<6;i++){var before=JSON.stringify(G.kn[0]);scout();c++}return {left:G.left,ph:G.ph,kn:G.kn[0].BGR}})()")
    ok('keşif tek oyuncuda hak tüketmiyor, faz değişmiyor',n['ph']=='act' and sum(n['kn'])==5,n)
    # geliştirme
    up=pg.evaluate("(function(){G.up=1;var a=G.P[0].s[1];upgrade(1);return [a,G.P[0].s[1],G.up]})()")
    ok('geliştirme puanı +%10 ve tüketiliyor',abs(up[1]-up[0]*1.1)<1e-9 and up[2]==0,up)
    # Kayıt / yükleme
    pg.evaluate("save()");
    pg.reload();pg.wait_for_timeout(600)
    ok('15 kayıt mevcut',pg.evaluate("hasSave()"))
    pg.evaluate("cont()");pg.wait_for_timeout(600)
    ok('15 yükleme: tek oyuncu act fazı',pg.evaluate("G.ph")=='act' and pg.evaluate("solo()"))
    # eski kayıt (roll aşaması) dönüşümü
    pg.evaluate("(function(){var g=JSON.parse(localStorage.getItem(SV));g.ph='roll';g.roll=1;localStorage.setItem(SV,JSON.stringify(g))})()");pg.reload();pg.wait_for_timeout(500)
    pg.evaluate("cont()");pg.wait_for_timeout(500)
    ok('15 eski kayıt (roll) tek oyuncuda act fazına dönüştü',pg.evaluate("G.ph")=='act' and not pg.evaluate("document.querySelector('#mod').style.display=='flex'"))
    pg.close()
    # 2 oyunculu mod korunuyor
    pg=fresh(b);start(pg,2,'GRC');noanim(pg)
    ok('15 2P: tur zarı aşaması var',pg.evaluate("G.ph")=='roll' and pg.evaluate("document.querySelector('#mod').style.display=='flex'"))
    pg.evaluate("rollOk()");ph=pg.evaluate("[G.ph,G.left,G.roll]")
    ok('15 2P: zar sonrası hak/geliştirme akışı',ph[0] in('act','upg') and ph[1]==ph[2],ph)
    r=pg.evaluate("""(function(){if(G.ph=='upg')upgrade(0);var left0=G.left,cur0=G.cur;var ids=Object.keys(targets(G.cur,G.owner));G.sel=ids[0];var tgt=ids[0];doAttack();var res={left0:left0,left:G.left,cur:G.cur,cur0:cur0,ph:G.ph,win:G.owner[tgt]===cur0};closeBattle();return res})()""")
    ok('15 2P: savaş hakkı azalıyor / kayıpta tur bitiyor',(r['win'] and (r['left']==r['left0']-1 or r['cur']!=r['cur0'])) or ((not r['win']) and r['cur']!=r['cur0']),r)
    pg.close()
    # Kayıp senaryosu (savunan kazanır, en yakın ülke kaybedilir, son ülke giderse oyun biter)
    pg=fresh(b);start(pg,1,'GRC');noanim(pg)
    pg.evaluate("G.P[0].s=[9999,9999,9999,9999,9999];G.sel='BGR';doAttack();closeBattle();G.P[0].s=[.001,.001,.001,.001,.001]")
    r=pg.evaluate("(function(){G.sel='ROU';TG=targets(0,G.owner);var o0=owned(0).map(function(x){return x.id});doAttack();var lost=G.owner.ROU!==0;var o1=owned(0).map(function(x){return x.id});closeBattle();return{lost:lost,before:o0,after:o1,ph:G.ph,l:G.st[0].l}})()")
    ok('10 kayıpta savunan kazanır ve 1 ülke kaybedilir',r['lost'] and len(r['after'])==len(r['before'])-1 and r['l']==1,r)
    ok('10 kayıptan sonra da tek oyuncuda saldırı serbest (faz act)',r['ph']=='act',r['ph'])
    pg.close()
    # 14 Mobil / masaüstü taşma
    for (w,h,tag) in [(360,640,'360x640'),(414,760,'414x760'),(768,1024,'768x1024'),(1280,720,'1280x720')]:
        pg=fresh(b,w,h,touch=(w<700));start(pg,1,'GRC');noanim(pg)
        pg.evaluate("pickC('BGR')");pg.wait_for_timeout(1300)
        ov=pg.evaluate("(function(){var o={};['panel','hud'].forEach(function(i){var r=document.getElementById(i).getBoundingClientRect();o[i]=r.left>=-1&&r.right<=innerWidth+1&&r.bottom<=innerHeight+1});o.sw=document.documentElement.scrollWidth<=innerWidth;return o})()")
        ok('14 panel taşmıyor '+tag,all(ov.values()),ov)
        pg.evaluate("doAttack()");pg.wait_for_timeout(300)
        ov=pg.evaluate("(function(){var r=document.getElementById('bs').getBoundingClientRect();return {l:r.left>=-1,r:r.right<=innerWidth+1,b:r.bottom<=innerHeight+1,t:r.top>=0,sh:document.getElementById('bs').scrollWidth<=document.getElementById('bs').clientWidth+1,fit:document.getElementById('bs').scrollHeight<=document.getElementById('bs').clientHeight+2}})()")
        ok('14 savaş sayfası taşmıyor '+tag,all(ov.values()),ov)
        if w in(414,1280): pg.screenshot(path='/tmp/shots/e2e_battle_%s.png'%tag)
        pg.close()
    ok('hiç JS hatası yok',len(errs)==0,errs[:5])
    b.close()
bad=[r for r in res if not r[1]]
print('\n%d/%d geçti'%(len(res)-len(bad),len(res)));sys.exit(1 if bad else 0)
