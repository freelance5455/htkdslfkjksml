import { createRequire } from 'module';
const J = createRequire(import.meta.url)('../src/jalali.js');
let ok = 0, bad = 0; const chk = (n, c, x = '') => { c ? ok++ : (bad++, console.log('FAIL', n, x)); };
// Compare against ICU for every day 1200..1600 (≈146k days)
const f = new Intl.DateTimeFormat('en-US-u-ca-persian-nu-latn', { year: 'numeric', month: 'numeric', day: 'numeric', timeZone: 'UTC' });
let mism = 0, first = [];
const start = Date.UTC(1821, 2, 1), end = Date.UTC(2121, 2, 21); // 1200..1499 AP (ICU diverges from the 33-year rule from 1503 AP on)
for (let t = start; t < end; t += 864e5) {
  const d = new Date(t), g = { y: d.getUTCFullYear(), m: d.getUTCMonth() + 1, d: d.getUTCDate() };
  const p = {}; f.formatToParts(d).forEach(x => p[x.type] = x.value);
  const icu = { y: +p.year, m: +p.month, d: +p.day }, mine = J.toJalali(g.y, g.m, g.d);
  if (icu.y !== mine.y || icu.m !== mine.m || icu.d !== mine.d) { mism++; if (first.length < 5) first.push([g, icu, mine]); }
  const back = J.toGregorian(mine.y, mine.m, mine.d);
  if (back.y !== g.y || back.m !== g.m || back.d !== g.d) { bad++; console.log('roundtrip fail', g, mine, back); break; }
}
console.log('ICU mismatches 1200-1499 AP:', mism, JSON.stringify(first));
chk('icu parity', mism === 0);
chk('2026-10-15 = 1405/7/23', JSON.stringify(J.toJalali(2026, 10, 15)) === '{"y":1405,"m":7,"d":23}');
chk('Nowruz 1405 = 2026-03-21', JSON.stringify(J.toGregorian(1405, 1, 1)) === '{"y":2026,"m":3,"d":21}');
chk('1403 leap', J.isLeapJalali(1403)); chk('1404 not leap', !J.isLeapJalali(1404)); chk('1405 not leap', !J.isLeapJalali(1405));
chk('esfand 1403 = 30', J.jalaliMonthLength(1403, 12) === 30); chk('esfand 1405 = 29', J.jalaliMonthLength(1405, 12) === 29);
chk('parse jalali persian digits', J.parseDateInput('۱۴۰۵/۰۷/۲۳', 'jalali') === '2026-10-15');
chk('parse dashes', J.parseDateInput('1405-7-23', 'jalali') === '2026-10-15');
chk('reject 1405/12/30', J.parseDateInput('1405/12/30', 'jalali') === null);
chk('accept 1403/12/30', J.parseDateInput('1403/12/30', 'jalali') === '2025-03-20');
chk('reject 31 mehr', J.parseDateInput('1405/07/31', 'jalali') === null);
chk('gregorian parse', J.parseDateInput('2026/10/15', 'gregorian') === '2026-10-15');
chk('reject feb 30', J.parseDateInput('2026/02/30', 'gregorian') === null);
chk('addDays', J.addDaysIso('2026-12-31', 1) === '2027-01-01'); chk('diff', J.diffDaysIso('2026-01-01', '2026-03-01') === 59);
console.log({ ok, bad }); process.exit(bad ? 1 : 0);
