import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
import { startCompany } from './helpers.mjs';
import fs from 'node:fs';
const S = process.env.SHOTS || '/tmp/';
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium', args: ['--no-sandbox'] });
const p = await (await b.newContext({ viewport: { width: 1200, height: 900 }, locale: 'en-US' })).newPage();
const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
let pass = 0, fail = 0; const ok = (c, n) => { c ? pass++ : (fail++, console.log('FAIL', n)); };
await p.goto('file://' + process.cwd() + '/dist/index.html');
const keys = new Set(Object.keys(JSON.parse(fs.readFileSync('tools/translations/source-en.json', 'utf8')).ui));
await p.selectOption('.lang-sel', 'de'); ok(await p.evaluate(() => document.documentElement.lang) === 'de', 'terms gate switches to German');
ok((await p.innerText('body')).includes('Nutzungsbedingungen'), 'German terms title on gate');
await startCompany(p, { company: 'Test Co' });
const expect = { fa: ['rtl', 'fa'], ar: ['rtl', 'ar'], en: ['ltr', 'en'], fr: ['ltr', 'fr'], de: ['ltr', 'de'] };
for (const l of ['en', 'fa', 'ar', 'fr', 'de']) {
  await p.selectOption('.lang-sel', l); await p.waitForTimeout(250);
  const [dir, lang] = await p.evaluate(() => [document.documentElement.dir, document.documentElement.lang]);
  ok(dir === expect[l][0] && lang === expect[l][1], `${l} dir/lang ${dir}/${lang}`);
  const tabs = await p.$$('nav.tabs button:not(.back)'); let leaks = [];
  for (let i = 0; i < tabs.length; i++) {
    await (await p.$$('nav.tabs button:not(.back)'))[i].click(); await p.waitForTimeout(150);
    const txt = await p.innerText('body'); const words = txt.split(/[\s|]+/);
    for (const w of words) if (keys.has(w) && /_/.test(w)) leaks.push(w);
    const w = await p.evaluate(() => document.documentElement.scrollWidth); if (w > 1201) ok(false, `${l} tab ${i} overflows ${w}`);
    if (i === 0 || i === 8) await p.screenshot({ path: `${S}lang-${l}-${i}.png` });
  }
  ok(leaks.length === 0, `${l} raw key leaks: ${leaks.slice(0, 5)}`);
}
// mobile overflow per language on the busiest tabs
await p.setViewportSize({ width: 390, height: 800 });
for (const l of ['ar', 'fr', 'de']) { await p.selectOption('.lang-sel', l); for (const i of [0, 1, 5, 8, 9]) { await (await p.$$('nav.tabs button:not(.back)'))[i].click(); await p.waitForTimeout(120); const w = await p.evaluate(() => document.documentElement.scrollWidth); ok(w <= 391, `${l} mobile tab ${i} width ${w}`); } }
// terms reader in Arabic
await p.setViewportSize({ width: 1200, height: 900 }); await p.selectOption('.lang-sel', 'ar'); await p.click('.foot button >> nth=0'); await p.waitForTimeout(300);
ok((await p.innerText('dialog[open]')).includes('شروط') || (await p.innerText('dialog[open]')).length > 500, 'Arabic terms render'); ok((await p.innerText('dialog[open]')).includes('[owner]'), 'unfilled legal placeholders are visible');
await p.screenshot({ path: S + 'lang-ar-terms.png' });
console.log('ERRS', errs, { pass, fail }); await b.close(); process.exit(fail ? 1 : 0);
