<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/bootstrap.php';

try {
    if (!extension_loaded('pdo_sqlite')) {
        throw new RuntimeException('pdo_sqlite is required; this project is configured for SQLite PDO only.');
    }
    require_once __DIR__ . '/../app/auth.php';
    require_once __DIR__ . '/../app/payments.php';
    auth_schema();
    payments_schema();
    $pdo = db();
    $promptCount = (int)$pdo->query('SELECT COUNT(*) FROM prompt_library WHERE is_custom = 0')->fetchColumn();
    if ($promptCount < 10) throw new RuntimeException('Built-in prompt seed did not complete.');
    $requiredTables = ['prompt_library', 'workspace_preferences', 'reference_uploads', 'realtime_sessions', 'admin_api_keys', 'admin_audit_logs', 'platform_settings', 'fish_audio_keys', 'voice_usage', 'user_wallets', 'credit_transactions', 'voice_generations', 'voice_request_keys', 'voice_refunds', 'tool_categories', 'tutorial_categories', 'tools', 'tutorials', 'tutorial_steps', 'tutorial_relations', 'tutorial_media', 'notifications', 'dashboard_recent_access', 'admin_bootstrap_lock', 'credit_packages', 'payment_orders'];
    foreach ($requiredTables as $table) {
        $query = $pdo->query("SELECT COUNT(*) FROM {$table}");
        if (!$query) throw new RuntimeException('Missing table: ' . $table);
    }
    preference_set('smoke_test', ['ok' => true]);
    if (preference_get('smoke_test')['ok'] !== true) throw new RuntimeException('Preference persistence check failed.');
    $pdo->prepare('DELETE FROM workspace_preferences WHERE owner_key = ? AND preference_key = ?')->execute([owner_key(), 'smoke_test']);
    echo "PASS: database schema (including wallet, credit ledger, voice history and resource centre), built-in prompts, and workspace preference persistence.\n";
    echo "NOTE: no external Decart request was made. Configure config.local.php and run the live acceptance test in README.md.\n";
} catch (Throwable $e) {
    fwrite(STDERR, "FAIL: {$e->getMessage()}\n");
    exit(1);
}
