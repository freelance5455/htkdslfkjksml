import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState } from '../src/store.js';
import { ensureVisualIdentities, validateVisualIdentities, updateVisualIdentity, KIT_MOTIFS, EMBLEM_MOTIFS, FLAG_MOTIFS } from '../src/visual-identity.js';

test('catalogues visuels proposent au moins vingt motifs par catégorie',()=>{
  assert.ok(KIT_MOTIFS.length>=20);assert.ok(EMBLEM_MOTIFS.length>=20);assert.ok(FLAG_MOTIFS.length>=20);
});
test('chaque club et chaque galaxie reçoit une identité distincte',()=>{
  const state=createInitialState();ensureVisualIdentities(state);
  const result=validateVisualIdentities(state);
  assert.equal(result.clubs,36);assert.equal(result.galaxies,24);assert.equal(result.total,60);
  assert.ok(result.motifs.kit>=20&&result.motifs.emblem>=20&&result.motifs.flag>=20);
});
test('les modifications du maillot, de l’emblème et du drapeau sont conservées',()=>{
  const state=createInitialState();ensureVisualIdentities(state);
  const club=state.divisions[0].clubs[0];
  updateVisualIdentity(state,'club',club.id,{kit:{motif:'chevrons',primary:'#123456'},emblem:{motif:'couronne',symbol:'♛'},flag:{motif:'etoile-centrale',accent:'#abcdef'}});
  assert.equal(club.visualIdentity.kit.motif,'chevrons');assert.equal(club.visualIdentity.kit.primary,'#123456');
  assert.equal(club.visualIdentity.emblem.motif,'couronne');assert.equal(club.visualIdentity.emblem.symbol,'♛');
  assert.equal(club.visualIdentity.flag.motif,'etoile-centrale');assert.equal(club.visualIdentity.flag.accent,'#abcdef');
  assert.equal(validateVisualIdentities(state).total,60);
});
test('refuse un motif non répertorié',()=>{
  const state=createInitialState();ensureVisualIdentities(state);const club=state.divisions[0].clubs[0];
  assert.throws(()=>updateVisualIdentity(state,'club',club.id,{kit:{motif:'inconnu'}}),/Motif kit non reconnu/);
});
test('refuse un code couleur invalide',()=>{
  const state=createInitialState();ensureVisualIdentities(state);const club=state.divisions[0].clubs[0];
  assert.throws(()=>updateVisualIdentity(state,'club',club.id,{flag:{primary:'rouge'}}),/Code couleur invalide/);
});
test('les nouveaux clubs ajoutés aux divisions reçoivent une identité distincte',()=>{
  const state=createInitialState();ensureVisualIdentities(state);
  const newClub={id:'ligue-c-01',name:'Nouvelle équipe',visualIdentity:null};state.divisions.find(d=>d.id==='ligue-c').clubs.push(newClub);
  ensureVisualIdentities(state);
  const result=validateVisualIdentities(state);
  assert.equal(result.total,61);assert.ok(newClub.visualIdentity.kit&&newClub.visualIdentity.emblem&&newClub.visualIdentity.flag);
});
