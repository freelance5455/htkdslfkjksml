import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const S='/tmp/claude-0/-home-claude/ac093352-288c-53a7-aeac-97bb6afa3d7b/scratchpad/';
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium', args:['--no-sandbox'] });
const p = await b.newPage({ viewport:{width:1200,height:900}, locale:'fa-IR' });
const errs=[]; p.on('pageerror',e=>errs.push('PAGEERR '+e.message)); p.on('console',m=>{if(['error','warning'].includes(m.type()))errs.push(m.type()+' '+m.text())});
await p.goto('file:///home/claude/acconova/dist/index.html');
await p.click('button:has-text("داده نمونه")');
await p.waitForTimeout(1500);
const tabs = await p.$$eval('.tabs button, nav button, [role=tab]',els=>els.map(e=>e.textContent.trim()));
console.log((await p.evaluate(()=>document.body.innerHTML)).slice(0,1800));
console.log('TABS',tabs);
for (let i=0;i<tabs.length;i++){
  const els = await p.$$('[role=tab], nav button, .tabs button');
  await els[i].click(); await p.waitForTimeout(500);
  await p.screenshot({path:S+`t${i}.png`});
  console.log(i,tabs[i],(await p.evaluate(()=>document.body.innerText.length)));
}
console.log('ERRS',errs);
await b.close();
