# BAKI ŞAŞKISI 2.5.3 — Exit, anonymous profiles and avatar sync

- Replaced the hard-coded default name “Elvin” with a randomly generated anonymous nickname, saved per installation.
- Existing saved profile name is preserved unless it is empty or exactly the old default “Elvin”.
- Profile name edits are saved and reflected immediately in the local game UI.
- Online players exchange profile packets after connecting; the opponent's anonymous name and avatar are displayed.
- Avatar updates are persisted locally and shared with the connected opponent.
- Android exit button continues to call the native `finishAndRemoveTask()` flow, returning to the launcher; Android Back from the game returns to the menu, and Back from the main menu backgrounds the task.
- Existing native Android photo picker/camera bridge remains in place.

Important: the Android exit and avatar picker are already implemented in the native Kotlin wrapper; this update tightens the HTML-to-native integration and profile synchronization. Rebuild the APK in APK Forge and test on two physical phones. Online avatar transfer depends on the peer data channel and the public PeerJS service.
