# BAKI ŞAŞKISI 2.5.3 — Exit, anonymous profiles and avatar sync

- Replaced the hard-coded default name “Elvin” with a randomly generated anonymous nickname, saved per installation.
- Existing saved profile name is preserved unless it is empty or exactly the old default “Elvin”.
- Profile name edits are saved and reflected immediately in the local game UI.
- Online players exchange profile packets after connecting; the opponent's anonymous name and avatar are displayed.
- Avatar updates are persisted locally and shared with the connected opponent.
- Android exit button continues to call the native `finishAndRemoveTask()` flow, returning to the launcher; Android Back from the game returns to the menu, and Back from the main menu backgrounds the task.
- Existing native Android photo picker/camera bridge remains in place.

Important: the Android exit and avatar picker are already implemented in the native Kotlin wrapper; this update tightens the HTML-to-native integration and profile synchronization. Rebuild the APK in APK Forge and test on two physical phones. Online avatar transfer depends on the peer data channel and the public PeerJS service.


## 2.5.3 source maintenance patch
- Corrected Android version metadata to 2.5.3 (versionCode 18).
- Profile save/reset actions propagate the current name/avatar to the connected opponent.
- Tightened incoming profile packet validation and single-opponent connection handling.
- Added PeerJS signaling reconnect handling.
- Hardened camera URI handoff and fixed a bitmap lifecycle edge case.
- JavaScript syntax and manifest XML checks pass. Android build and physical-device tests remain unverified; see QA_REPORT.md.
