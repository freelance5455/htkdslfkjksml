# BAKI ŞAŞKISI 2.5.3 — Exit / Gallery follow-up patch

## Changes made from the two reported Android screenshots
- Replaced the gallery and camera `<label>` controls with explicit `type="button"` controls. The previous labels were also associated with hidden HTML file inputs, which could compete with the native Android bridge click path.
- Made the gallery and camera click handlers explicitly prevent the browser default action, invoke the Android JavaScript bridge, and use the hidden HTML file inputs only as a browser fallback when the native bridge is absent.
- Reworked the exit confirmation handler so PeerJS/audio cleanup exceptions cannot prevent the native `AndroidBridge.exitApp()` command from being called.
- Hardened native task shutdown with `finishAndRemoveTask()` and layered `finishAffinity()` / `finish()` fallbacks.
- Changed the primary image selection intent to `ACTION_OPEN_DOCUMENT`, with persistable read permission where the document provider grants it, and a chooser fallback to the platform Photo Picker / `ACTION_GET_CONTENT`.
- Kept the existing dialogs, labels, colors, layout, game assets and game logic visually unchanged.

## Checks completed in this environment
- [x] Inline JavaScript syntax check with Node.js (`node --check`).
- [x] AndroidManifest.xml parses as valid XML.
- [x] Source inspection confirms explicit native bridge calls for exit, gallery and camera remain wired.

## Not verified
- [ ] Kotlin/Android compilation and APK build (Android SDK and Gradle are not installed in this environment; project has no Gradle wrapper).
- [ ] Actual launcher return on the user's Honor phone.
- [ ] Actual gallery launch / photo selection on the user's Honor phone.
- [ ] Camera capture on the user's Honor phone.

This is a source patch. It must not be described as a verified APK or as device-tested until installed and tested on the phone.
