package com.bakisasaskisi.game

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.ClipData
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import java.io.ByteArrayOutputStream
import android.net.Uri
import android.content.ContentValues
import android.graphics.Matrix
import android.os.Build
import android.provider.MediaStore
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.widget.FrameLayout
import android.widget.ProgressBar

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var anthemPlayer: MediaPlayer? = null
    private var anthemWasPrepared = false
    private var anthemFinished = false
    private var anthemFailed = false
    private var activityInForeground = false
    private var anthemStartAttempted = false
    private var anthemUserPaused = false
    private var anthemVolume = 1.0f
    private var cameraUri: Uri? = null
    private var pageReady = false
    private val pendingJs = ArrayList<String>()
    private val anthemProgressHandler = Handler(Looper.getMainLooper())
    private val anthemProgressRunnable = object : Runnable {
        override fun run() {
            val player = anthemPlayer ?: return
            if (!activityInForeground || !anthemWasPrepared || anthemFinished) return
            try {
                val duration = player.duration.coerceAtLeast(1)
                val position = player.currentPosition.coerceIn(0, duration)
                evaluateAnthemJavascript("window.onNativeAnthemProgress && window.onNativeAnthemProgress($position,$duration)")
                anthemProgressHandler.postDelayed(this, 500L)
            } catch (e: Exception) {
                Log.w(TAG, "Could not read anthem playback position", e)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 14, 23)
        setVolumeControlStream(android.media.AudioManager.STREAM_MUSIC)
        window.navigationBarColor = Color.rgb(8, 14, 23)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(8, 14, 23)) }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(231, 189, 105))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(25, 39, 54))
        }
        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(8, 14, 23))
            settings.javaScriptEnabled = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                settings.safeBrowsingEnabled = true
            }
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.setSupportZoom(false)
            settings.builtInZoomControls = false
            settings.displayZoomControls = false
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    pageReady = true
                    if (pendingJs.isNotEmpty()) { pendingJs.forEach { evaluateAnthemJavascript(it) }; pendingJs.clear() }
                    evaluateAnthemJavascript("window.onNativePageLoaded && window.onNativePageLoaded()")
                    if (anthemFinished) {
                        if (anthemFailed) evaluateAnthemJavascript("window.onNativeAnthemError && window.onNativeAnthemError()")
                    } else if (activityInForeground && anthemPlayer == null) {
                        // Start only after the WebView is ready and Activity is resumed.
                        // This avoids racing MediaPlayer startup against Android lifecycle.
                        startNationalAnthem()
                    }
                }
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val url = request?.url?.toString() ?: return false
                    return !(url.startsWith("https://") || url.startsWith("http://") || url.startsWith("file:///android_asset/"))
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    progress.progress = newProgress
                    progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
                    if (::webView.isInitialized) {
                        webView.evaluateJavascript("window.setPageLoadProgress && window.setPageLoadProgress($newProgress)", null)
                    }
                }

                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                    this@MainActivity.fileChooserCallback = filePathCallback
                    return try {
                        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "image/*"
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        startActivityForResult(intent, FILE_CHOOSER_REQUEST)
                        true
                    } catch (_: Exception) {
                        this@MainActivity.fileChooserCallback = null
                        false
                    }
                }
            }
        }
        webView.addJavascriptInterface(object {
            @JavascriptInterface
            fun stopAnthem() {
                runOnUiThread {
                    anthemFinished = true
                    anthemStartAttempted = true
                    releaseAnthem()
                }
            }

            @JavascriptInterface
            fun retryAnthem() {
                runOnUiThread {
                    if (anthemPlayer != null) return@runOnUiThread
                    anthemProgressHandler.removeCallbacks(anthemProgressRunnable)
                    releaseAnthem()
                    anthemFinished = false
                    anthemFailed = false
                    anthemWasPrepared = false
                    anthemStartAttempted = false
                    if (activityInForeground) startNationalAnthem()
                }
            }

            @JavascriptInterface
            fun setAnthemVolume(volume: Float) {
                runOnUiThread {
                    anthemVolume = volume.coerceIn(0f, 1f)
                    try { anthemPlayer?.setVolume(anthemVolume, anthemVolume) } catch (_: Exception) { }
                }
            }

            @JavascriptInterface
            fun setAnthemPlaying(on: Boolean) {
                runOnUiThread {
                    anthemUserPaused = !on
                    val player = anthemPlayer ?: return@runOnUiThread
                    try {
                        if (on) { if (activityInForeground && anthemWasPrepared && !player.isPlaying) player.start() }
                        else if (player.isPlaying) player.pause()
                    } catch (e: Exception) { Log.w(TAG, "setAnthemPlaying", e) }
                }
            }

            @JavascriptInterface
            fun takeAvatarPhoto() {
                runOnUiThread { launchCamera() }
            }

            @JavascriptInterface
            fun chooseAvatar() {
                runOnUiThread { launchAvatarPicker() }
            }

            @JavascriptInterface
            fun exitApp() {
                runOnUiThread { shutDownAndFinish() }
            }
        }, "AndroidBridge")
        root.addView(webView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        root.addView(progress, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, 3, Gravity.TOP))
        setContentView(root)
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html")
        else webView.restoreState(savedInstanceState)

        // Playback is started from onResume after the Activity is foregrounded.
        // WebView onPageFinished also retries the first start if loading finishes later.
    }


    private fun startNationalAnthem() {
        if (!activityInForeground || anthemPlayer != null || anthemFinished || anthemStartAttempted) return
        anthemStartAttempted = true
        anthemFailed = false
        try {
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
            // MediaPlayer.create() prepares the packaged raw resource safely,
            // including APK compression; no file-descriptor assumptions or network.
            val player = MediaPlayer.create(this, R.raw.anthem, attributes, android.media.AudioManager.AUDIO_SESSION_ID_GENERATE)
            if (player == null) {
                failAnthem()
                return
            }
            anthemPlayer = player
            player.setVolume(anthemVolume, anthemVolume)
            // The anthem is background music (splash + menu): it loops quietly and is paused by the page in-game.
            player.isLooping = true
            player.setOnErrorListener { failed, what, extra ->
                Log.e(TAG, "Anthem playback error: what=$what extra=$extra")
                if (anthemPlayer === failed) failAnthem()
                true
            }
            val actualDurationMs = player.duration
            if (actualDurationMs <= 0) {
                failAnthem()
                return
            }
            anthemWasPrepared = true
            startPreparedAnthem(player)
        } catch (_: Exception) {
            failAnthem()
        }
    }

    private fun startPreparedAnthem(player: MediaPlayer) {
        if (anthemPlayer !== player || anthemFinished || anthemUserPaused) return
        try {
            if (!player.isPlaying) {
                player.start()
            }
        } catch (_: Exception) {
            failAnthem()
        }
    }

    private fun failAnthem() {
        Log.e(TAG, "Anthem could not be played")
        anthemStartAttempted = true
        anthemFinished = true
        anthemFailed = true
        releaseAnthem()
        evaluateAnthemJavascript("window.onNativeAnthemError && window.onNativeAnthemError()")
    }

    private fun evaluateAnthemJavascript(script: String) {
        runOnUiThread {
            if (::webView.isInitialized) webView.evaluateJavascript(script, null)
        }
    }

    private fun releaseAnthem() {
        anthemProgressHandler.removeCallbacks(anthemProgressRunnable)
        try { anthemPlayer?.setOnPreparedListener(null); anthemPlayer?.setOnCompletionListener(null); anthemPlayer?.setOnErrorListener(null); anthemPlayer?.release() } catch (_: Exception) { }
        anthemPlayer = null
        anthemWasPrepared = false
    }

    override fun onPause() {
        activityInForeground = false
        if (::webView.isInitialized) webView.onPause()
        anthemProgressHandler.removeCallbacks(anthemProgressRunnable)
        try { if (anthemPlayer?.isPlaying == true) anthemPlayer?.pause() } catch (_: Exception) { }
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        activityInForeground = true
        if (::webView.isInitialized) { webView.onResume(); webView.resumeTimers() }
        try {
            val player = anthemPlayer
            if (player != null && anthemWasPrepared && !anthemFinished) {
                if (!player.isPlaying) startPreparedAnthem(player)
            } else if (player == null && !anthemFinished && !anthemStartAttempted) {
                startNationalAnthem()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Could not resume anthem", e)
            failAnthem()
        }
    }

    /** Stops anthem + page work, then closes every Activity of the task so the user lands on the Android home screen. */
    private fun shutDownAndFinish() {
        if (isFinishing) return
        anthemFinished = true
        anthemStartAttempted = true
        releaseAnthem()
        try {
            if (::webView.isInitialized) {
                webView.stopLoading()
                webView.onPause()
                // Do not pause process-wide WebView timers: the process may be reused on next launch.
            }
        } catch (e: Exception) { Log.w(TAG, "WebView shutdown", e) }
        // finishAndRemoveTask is supported from API 21. Keep layered fallbacks for
        // vendor Android builds where removing the task can throw unexpectedly.
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) finishAndRemoveTask()
            else finishAffinity()
        } catch (e: Exception) {
            Log.w(TAG, "finishAndRemoveTask failed; using finishAffinity", e)
            try { finishAffinity() } catch (_: Exception) { }
            try { finish() } catch (_: Exception) { }
        }
    }

    private fun launchAvatarPicker() {
        // ACTION_OPEN_DOCUMENT is supported on the target Android versions and
        // returns a content:// URI without requesting broad storage permissions.
        val primary = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/jpeg", "image/png", "image/webp", "image/*"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try {
            startActivityForResult(primary, AVATAR_PICKER_REQUEST)
        } catch (e: Exception) {
            Log.w(TAG, "ACTION_OPEN_DOCUMENT unavailable; trying Photo Picker / GET_CONTENT", e)
            try {
                val fallback = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    Intent(MediaStore.ACTION_PICK_IMAGES).apply { type = "image/*" }
                } else {
                    Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "image/*"
                    }
                }
                startActivityForResult(Intent.createChooser(fallback, "Avatar şəkli seç"), AVATAR_PICKER_REQUEST)
            } catch (fallbackError: Exception) {
                Log.e(TAG, "No image picker activity available", fallbackError)
                runWhenPageReady("window.onNativeAvatarError && window.onNativeAvatarError()")
            }
        }
    }

    private fun runWhenPageReady(script: String) {
        if (pageReady) evaluateAnthemJavascript(script) else pendingJs.add(script)
    }

    /** Decodes/crops the picked image off the UI thread (large photos used to freeze the UI) and hands it to the page. */
    private fun processAvatarAsync(produce: () -> String?, afterwards: () -> Unit = {}) {
        Thread {
            val dataUrl = try { produce() } catch (t: Throwable) { Log.w(TAG, "Avatar processing failed", t); null }
            runOnUiThread {
                afterwards()
                if (dataUrl != null) {
                    runWhenPageReady("window.onNativeAvatarSelected && window.onNativeAvatarSelected(${JSONObject.quote(dataUrl)})")
                } else {
                    runWhenPageReady("window.onNativeAvatarError && window.onNativeAvatarError()")
                }
            }
        }.start()
    }

    private fun launchCamera() {
        try {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            if (intent.resolveActivity(packageManager) == null) {
                runWhenPageReady("window.onNativeAvatarError && window.onNativeAvatarError()")
                return
            }
            cameraUri = null
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Use a temporary MediaStore URI for a full-resolution capture; delete it after import.
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "baki_avatar_${System.currentTimeMillis()}.jpg")
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                cameraUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                cameraUri?.let { output ->
                    intent.putExtra(MediaStore.EXTRA_OUTPUT, output)
                    intent.clipData = ClipData.newRawUri("BAKI avatar output", output)
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                }
            }
            startActivityForResult(intent, AVATAR_CAMERA_REQUEST)
        } catch (e: Exception) {
            Log.w(TAG, "Camera launch failed", e)
            discardCameraUri()
            runWhenPageReady("window.onNativeAvatarError && window.onNativeAvatarError()")
        }
    }

    private fun discardCameraUri() {
        val u = cameraUri ?: return
        cameraUri = null
        try { contentResolver.delete(u, null, null) } catch (_: Exception) { }
    }

    private fun uriFromResult(data: Intent?): Uri? {
        data?.data?.let { return it }
        val clip = data?.clipData
        if (clip != null && clip.itemCount > 0) return clip.getItemAt(0).uri
        return null
    }

    private fun makeAvatarDataUri(uri: Uri): String? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1200) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        val decoded = contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, options)
        } ?: return null

        try {
            val rotation = readExifRotation(uri)
            val source = if (rotation != 0f) {
                val m = Matrix().apply { postRotate(rotation) }
                val rotated = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, m, true)
                if (rotated !== decoded) decoded.recycle()
                rotated
            } else decoded
            return squareAvatar(source)
        } catch (e: Exception) {
            Log.w(TAG, "Avatar processing failed", e)
            decoded.recycle()
            return null
        }
    }

    private fun readExifRotation(uri: Uri): Float {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return 0f
        return try {
            contentResolver.openInputStream(uri)?.use {
                when (android.media.ExifInterface(it).getAttributeInt(
                    android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL)) {
                    android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (_: Exception) { 0f }
    }

    private fun squareAvatar(decoded: Bitmap): String? {
        try {
            val cropSize = minOf(decoded.width, decoded.height)
            if (cropSize <= 0) return null
            val left = (decoded.width - cropSize) / 2
            val top = (decoded.height - cropSize) / 2
            val square = Bitmap.createBitmap(decoded, left, top, cropSize, cropSize)
            val scaled = Bitmap.createScaledBitmap(square, 320, 320, true)
            // createScaledBitmap may return its input when it is already 320x320.
            if (square !== decoded && square !== scaled) square.recycle()
            val output = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 78, output)
            if (scaled !== decoded) scaled.recycle()
            return "data:image/jpeg;base64," + Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
        } finally {
            decoded.recycle()
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == AVATAR_PICKER_REQUEST) {
            if (resultCode == RESULT_OK) {
                val uri = uriFromResult(data)
                if (uri != null) {
                    // Persist access when the provider supports it. If not, the selected
                    // image is immediately decoded and copied into the app's localStorage.
                    try {
                        val granted = data?.flags?.and(Intent.FLAG_GRANT_READ_URI_PERMISSION) ?: 0
                        if (granted != 0) contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } catch (e: Exception) { Log.d(TAG, "Provider did not grant persistable URI access", e) }
                    processAvatarAsync({ makeAvatarDataUri(uri) })
                } else runWhenPageReady("window.onNativeAvatarError && window.onNativeAvatarError()")
            }
            return
        }
        if (requestCode == AVATAR_CAMERA_REQUEST) {
            if (resultCode == RESULT_OK) {
                val uri = cameraUri
                val thumb = data?.extras?.get("data") as? Bitmap
                if (uri != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    try {
                        contentResolver.update(uri, ContentValues().apply {
                            put(MediaStore.Images.Media.IS_PENDING, 0)
                        }, null, null)
                    } catch (e: Exception) { Log.w(TAG, "Could not finalize camera output", e) }
                }
                processAvatarAsync({
                    if (uri != null) makeAvatarDataUri(uri) else thumb?.let { squareAvatar(it) } // legacy camera thumbnail fallback
                }, { discardCameraUri() })
            } else discardCameraUri()
            return
        }
        if (requestCode == FILE_CHOOSER_REQUEST) {
            val uri = if (resultCode == RESULT_OK) uriFromResult(data) else null
            fileChooserCallback?.onReceiveValue(uri?.let { arrayOf(it) })
            fileChooserCallback = null
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (!::webView.isInitialized) { super.onBackPressed(); return }
        webView.evaluateJavascript(
            "(function(){var q=function(i){return document.getElementById(i)};" +
            "var d=q('exitDialog');if(d&&d.classList.contains('show')){q('cancelExit').click();return true;}" +
            "var g=q('gameBoard');if(g&&!g.classList.contains('hidden')){q('exitGame').click();return true;}" +
            "var ids=['settingsScreen','onlinePanel','rulesPanel'];for(var i=0;i<ids.length;i++){var e=q(ids[i]);if(e&&!e.classList.contains('hidden')){e.classList.add('hidden');return true;}}" +
            "return false;})()"
        ) { handled -> if (handled != "true") moveTaskToBack(true) }
    }

    override fun onDestroy() {
        fileChooserCallback?.onReceiveValue(null)
        fileChooserCallback = null
        releaseAnthem()
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.removeJavascriptInterface("AndroidBridge")
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.destroy()
        }
        super.onDestroy()
    }

    companion object {
        private const val TAG = "BakiSaskisi"
        private const val FILE_CHOOSER_REQUEST = 7412
        private const val AVATAR_PICKER_REQUEST = 7413
        private const val AVATAR_CAMERA_REQUEST = 7414
    }
}
