# BAKI ŞAŞKISI 2.5.2 — Custom online room codes

- Players can choose their own 4–20 character room code (A–Z, 0–9, `_`, `-`).
- The host creates the PeerJS peer using that exact room code.
- The second player enters the same code and joins it.
- Added validation and clearer messages for occupied room IDs and missing rooms.
- Preserved the existing board, game rules, visuals, and Android wrapper.

Important: this change uses the existing public PeerJS signaling infrastructure. It does not add a self-hosted signaling server. Both players need internet access, and the room host must remain connected while waiting/playing.
