# BAKI ŞAŞKİSİ — Android 2.3.0

Android WebView əsaslı 8×8 dama oyunu. Mövcud Kotlin Android qabığı, HTML/CSS/JavaScript oyun məntiqi, oyun rejimləri və resurslar saxlanılıb.

## 2.3.0 dəyişiklikləri
- PeerJS artıq tətbiq açılan kimi CDN-dən yüklənmir. Yalnız istifadəçi Online oyun bölməsində otaq yaratdıqda və ya qoşulduqda yüklənir. Bu, offline başlanğıcın şəbəkə gecikməsindən asılılığını aradan qaldırır.
- Himn oynatma xətası zamanı “Himni yenidən başlat” düyməsi artıq Android MediaPlayer-i həqiqətən yenidən başladır.
- Native retry axınında köhnə MediaPlayer callback-ləri təmizlənir və təkrar başlatma üçün vəziyyət sıfırlanır.
- Mövcud avatar seçimi, profil yaddaşı, oyun rejimləri və qaydalar saxlanılıb.
- Versiya: 2.3.0, versionCode 14.

## Layihənin açılması
Android Studio-da `BakiSaskisiAndroid` qovluğunu açın, Gradle Sync edin və Android cihazında işə salın. Min SDK 23, compile SDK 35, Java/Kotlin 17 tələb olunur.

## Online rejim
Online otaq yaratmaq və qoşulmaq üçün internet və PeerJS CDN/signaling infrastrukturu əlçatan olmalıdır. Offline rejimlər və daxili fon/gimn resursları internet tələb etmir.

## Test məhdudiyyətləri
Bu mühitdə Node.js sintaksis yoxlaması, XML parse və ZIP bütövlüyü yoxlanıla bilər. Android SDK, Gradle executable/wrapper və fiziki Android cihazı mövcud olmadığından APK build/install, real hoparlör səsi, Android Photo Picker və iki cihazlı online sessiya burada təsdiqlənə bilməz. Bu səbəbdən APK-nın real cihazda tam işlədiyi iddia edilmir.


## 2.5.2 — Öz otaq kodu
İndi otaq sahibi 4-20 simvolluq öz kodunu seçir. “Otaq yarat” düyməsi həmin kodla otaq açır; digər oyunçu eyni kodu daxil edib “Otağa qoşul” düyməsinə basır. Kod yalnız A-Z, 0-9, tire və alt xətt qəbul edir. Hər iki oyunçu internetdə olmalı, otaq sahibi oyundan çıxmamalıdır.
