# QA REPORT — BAKI ŞAŞKISI 2.5.3 patched source

## Checks completed in this environment
- [x] Extracted and inspected the supplied ZIP project; retained the existing Android app, HTML game, graphics, audio and resources.
- [x] JavaScript syntax check: `node --check` passes for the embedded game script.
- [x] AndroidManifest.xml parses as valid XML.
- [x] Static source checks: app label/applicationId retained; native exit bridge, image picker and camera handlers remain present; HTML no longer contains a hard-coded `Elvin` fallback.
- [x] Profile save now normalizes and bounds the nickname and shares it with an online opponent.
- [x] Resetting the avatar now shares the default-avatar state with an online opponent.
- [x] Incoming profile packets validate name type/length and constrain avatar data URLs to bounded JPEG/PNG/WebP base64 payloads.
- [x] A room accepts only one active data connection; duplicate peer connections are rejected.
- [x] PeerJS signaling disconnect now attempts reconnection and reports the condition.
- [x] Android camera intent now checks camera availability, grants URI read/write access to the camera app, uses a temporary MediaStore item on Android 10+, and finalizes/deletes the temporary item.
- [x] Fixed an avatar bitmap recycling edge case for 320x320 intermediate crops.
- [x] Android version metadata updated to versionName 2.5.3 / versionCode 18.

## Not verified — environment limitations
- [ ] Gradle build / APK generation: not run. This ZIP contains no Gradle wrapper, and this environment has no installed Gradle executable or Android SDK.
- [ ] Kotlin/Android compilation: not verified.
- [ ] Installation, launcher exit, gallery picker, camera capture, profile persistence and WebView lifecycle on a physical Android phone: not verified.
- [ ] PeerJS room creation and two-device gameplay: not verified. The project still uses the public PeerJS signaling service; no private signaling server is deployed or configured.
- [ ] End-to-end online game rules / adversarial packet testing: not verified.
- [ ] Full-resolution camera capture on older Android versions: legacy camera apps may return only the standard thumbnail because this project does not bundle a FileProvider-based output path.

## Important
The source has been patched and static checks pass, but it is not honest to label an APK built or online play verified. A machine with Android SDK + Gradle and two network-connected Android devices is required for those checks.
