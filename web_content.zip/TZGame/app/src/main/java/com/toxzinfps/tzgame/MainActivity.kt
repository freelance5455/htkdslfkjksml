package com.toxzinfps.tzgame

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.sp
import rikka.shizuku.Shizuku
import java.util.Locale
import java.util.concurrent.TimeUnit
import org.json.JSONArray
import org.json.JSONObject

private val Ink = Color(0xFF080B13)
private val Panel = Color(0xFF121827)
private val Accent = Color(0xFF66F2C2)
private val Secondary = Color(0xFF8AA2FF)

class MainActivity : ComponentActivity() {
    private var shizukuRevision by mutableIntStateOf(0)
    private var pendingGameMode: Pair<String, String>? = null
    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        shizukuRevision++
        if (requestCode == 42) {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                val pending = pendingGameMode
                pendingGameMode = null
                if (pending != null) applyGameMode(pending.first, pending.second)
            } else {
                pendingGameMode = null
            }
        }
    }
    private val binderReceived = Shizuku.OnBinderReceivedListener { shizukuRevision++ }
    private val binderDead = Shizuku.OnBinderDeadListener { shizukuRevision++ }
    private var waitingForShizukuStart = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        Shizuku.addBinderReceivedListener(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent { TzGameApp(this, shizukuRevision) }
    }

    override fun onResume() {
        super.onResume()
        if (waitingForShizukuStart) {
            Handler(Looper.getMainLooper()).postDelayed({
                if (waitingForShizukuStart && runCatching { Shizuku.pingBinder() }.getOrDefault(false)) {
                    waitingForShizukuStart = false
                    requestShizukuPermission()
                }
            }, 700)
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        Shizuku.removeBinderReceivedListener(binderReceived)
        Shizuku.removeBinderDeadListener(binderDead)
        super.onDestroy()
    }

    fun connectShizuku() {
        if (!runCatching { Shizuku.pingBinder() }.getOrDefault(false)) {
            val manager = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if (manager != null) {
                waitingForShizukuStart = true
                startActivity(manager)
            } else {
                Toast.makeText(this, "Instale e inicie o Shizuku; depois volte aqui.", Toast.LENGTH_LONG).show()
            }
            return
        }
        requestShizukuPermission()
    }

    private fun requestShizukuPermission() {
        try {
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Shizuku já está autorizado.", Toast.LENGTH_SHORT).show()
            } else {
                Shizuku.requestPermission(42)
                Toast.makeText(this, "Aprove a permissão do TZGame na tela do Shizuku.", Toast.LENGTH_LONG).show()
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Abra o Shizuku, inicie o serviço e tente novamente.", Toast.LENGTH_LONG).show()
        }
    }

    fun applyGameMode(packageName: String, mode: String) {
        if (loadLaunchableApps(this).none { it.packageName == packageName }) {
            Toast.makeText(this, "Selecione um aplicativo instalado na lista.", Toast.LENGTH_SHORT).show()
            return
        }
        if (mode !in setOf("performance", "standard")) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            Toast.makeText(this, "O modo de jogo do Android exige Android 12 ou superior.", Toast.LENGTH_LONG).show()
            return
        }
        if (!runCatching { Shizuku.pingBinder() }.getOrDefault(false)) {
            pendingGameMode = packageName to mode
            connectShizuku()
            return
        }
        if (runCatching { Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED }.getOrDefault(true)) {
            pendingGameMode = packageName to mode
            requestShizukuPermission()
            return
        }
        Thread {
            try {
                val process = Shizuku.newProcess(arrayOf("cmd", "game", "mode", mode, packageName), null, null)
                val finished = process.waitFor(8, TimeUnit.SECONDS)
                val output = if (finished) process.inputStream.bufferedReader().use { it.readText() }.trim() else ""
                if (!finished) process.destroy()
                runOnUiThread {
                    val message = if (!finished) "Comando expirou; esse aparelho pode não suportar o modo." else if (process.exitValue() == 0) {
                        if (mode == "performance") "Modo desempenho solicitado para este jogo. O efeito depende do fabricante." else "Modo padrão restaurado."
                    } else "O fabricante/Android não disponibilizou esse modo para o jogo. ${output.take(140)}"
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                }
            } catch (_: Exception) {
                runOnUiThread { Toast.makeText(this, "Não foi possível aplicar o modo. Verifique a autorização Shizuku e a compatibilidade do aparelho.", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    fun launchGamePackage(packageName: String) {
        val game = loadLaunchableApps(this).firstOrNull { it.packageName == packageName }
        if (game == null) {
            Toast.makeText(this, "Selecione um aplicativo instalado.", Toast.LENGTH_SHORT).show()
            return
        }
        launchGame(this, game)
    }

    fun openWifiSettings() {
        val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) else Intent(Settings.ACTION_WIFI_SETTINGS)
        runCatching { startActivity(intent) }.onFailure { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
    }

    fun openDisplaySettings() {
        runCatching { startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
            .onFailure { Toast.makeText(this, "Não foi possível abrir as configurações de tela.", Toast.LENGTH_SHORT).show() }
    }
}

private data class GameItem(val name: String, val packageName: String)

@Composable
private fun TzGameApp(activity: MainActivity, revision: Int) {
    var page by remember { mutableStateOf("Início") }
    var games by remember { mutableStateOf(loadLaunchableApps(activity)) }
    var selectedGame by remember { mutableStateOf<GameItem?>(null) }
    var refresh by remember { mutableIntStateOf(0) }
    val shizukuOnline = remember(revision) { runCatching { Shizuku.pingBinder() }.getOrDefault(false) }
    val shizukuAllowed = remember(revision, shizukuOnline) {
        shizukuOnline && runCatching { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED }.getOrDefault(false)
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Accent, secondary = Secondary,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Início", "Jogos", "Celular", "HTML").forEach { item ->
                    NavigationBarItem(selected = page == item, onClick = { page = item; selectedGame = null },
                        icon = { Text(when (item) { "Início" -> "⌂"; "Jogos" -> "▶"; "Celular" -> "▦"; else -> "</>" }, fontSize = 20.sp) },
                        label = { Text(item) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Accent, indicatorColor = Color(0xFF23372F), selectedTextColor = Accent, unselectedTextColor = Color.LightGray))
                }
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 18.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("TZGAME", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text("Desempenho sem mito.", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("●", color = if (shizukuAllowed) Accent else Color.Gray, fontSize = 20.sp)
                }
                when {
                    selectedGame != null -> GameActionsPage(activity, selectedGame!!, onBack = { selectedGame = null }, onLaunch = { launchGame(activity, selectedGame!!) })
                    page == "Início" -> HomePage(activity, shizukuOnline, shizukuAllowed, refresh) { activity.connectShizuku() }
                    page == "Jogos" -> GamesPage(games, onRefresh = { games = loadLaunchableApps(activity) }, onSelect = { selectedGame = it })
                    page == "Celular" -> DevicePage(activity, refresh)
                    else -> HtmlPage(activity, Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun HomePage(activity: MainActivity, shizukuOnline: Boolean, shizukuAllowed: Boolean, refresh: Int, onConnect: () -> Unit) {
    val stats = remember(refresh) { readDeviceStats(activity) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
        item {
            Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("SESSÃO DE JOGO", color = Color.LightGray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    Text(stats.soc, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("${stats.cores} núcleos · ${stats.ramLivre} RAM livre · ${stats.temp}°C bateria", color = Color.LightGray, fontSize = 13.sp)
                    Spacer(Modifier.height(15.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        StatChip("REDE", stats.rede)
                        StatChip("TELA", stats.refreshRate)
                    }
                }
            }
        }
        item {
            Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("CONTROLE SHIZUKU", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(when { shizukuAllowed -> "Conectado e autorizado"; shizukuOnline -> "Shizuku ativo — falta autorizar"; else -> "Shizuku não está ativo" }, color = if (shizukuAllowed) Accent else Color.LightGray, fontSize = 14.sp)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = onConnect, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Ink)) {
                        Text(if (shizukuAllowed) "Shizuku autorizado" else "Ativar / autorizar Shizuku", fontWeight = FontWeight.Bold)
                    }
                    Text("Se não estiver ativo, o TZGame abre o Shizuku. Inicie o serviço e volte para receber o pedido de autorização. No Android 11+, use Depuração sem fio.", color = Color.Gray, fontSize = 12.sp)
                }
            }
        }
        item {
            Surface(color = Color(0xFF192538), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(17.dp)) {
                    Text("Otimização segura", color = Secondary, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Text("Acompanhe temperatura, memória, rede e tela; abra seus jogos pelo launcher. O app não força clock nem desativa proteções térmicas.", color = Color.White, fontSize = 13.sp)
                }
            }
        }
        item { Text("Leitura do aparelho", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp) }
        item { InfoCard("CPU / SoC", "${stats.soc}\n${stats.cores} núcleos · ${stats.abi}") }
        item { InfoCard("GPU / gráficos", "${stats.gpuHint}\nOpenGL ES ${stats.glEs}") }
        item { InfoCard("Wi‑Fi / rede", stats.rede + "\n" + stats.redeDetail) }
        item { Text("Os dados de GPU, clocks e recursos variam por fabricante; esta versão mostra apenas informações fornecidas pelo Android.", color = Color.Gray, fontSize = 11.sp) }
    }
}

@Composable
private fun GamesPage(games: List<GameItem>, onRefresh: () -> Unit, onSelect: (GameItem) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Seus aplicativos", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            TextButton(onClick = onRefresh) { Text("Atualizar", color = Accent) }
        }
        Text("Toque em um app para escolher o jogo e abrir as opções de sessão.", color = Color.Gray, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
            items(games, key = { it.packageName }) { game ->
                Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(15.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(game.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text(game.packageName, color = Color.Gray, fontSize = 11.sp)
                        }
                        TextButton(onClick = { onSelect(game) }) { Text("Selecionar", color = Accent, fontWeight = FontWeight.Bold) }
                    }
                }
            }
            if (games.isEmpty()) item { Text("Nenhum app com ícone de inicialização encontrado.", color = Color.LightGray) }
        }
    }
}

@Composable
private fun GameActionsPage(activity: MainActivity, game: GameItem, onBack: () -> Unit, onLaunch: () -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(11.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { TextButton(onClick = onBack) { Text("‹ Voltar para jogos", color = Accent) } }
        item {
            Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(17.dp)) {
                    Text("JOGO SELECIONADO", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Text(game.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(game.packageName, color = Color.Gray, fontSize = 11.sp)
                }
            }
        }
        item { ActionButton("Otimizar jogo", "Solicitar modo desempenho do Android via Shizuku", onClick = { activity.applyGameMode(game.packageName, "performance") }) }
        item { ActionButton("Acelerar GPU", "Usa o perfil de desempenho do sistema, se o aparelho oferecer. Não faz overclock.", onClick = { activity.applyGameMode(game.packageName, "performance") }) }
        item { ActionButton("Otimizar Wi‑Fi", "Abrir controles de rede do Android para escolher/reconectar a rede", onClick = { activity.openWifiSettings() }) }
        item { ActionButton("Toque suave / reduzir delay", "Abrir configurações de tela para escolher a maior taxa de atualização disponível. Não altera o atraso do digitizador.", onClick = { activity.openDisplaySettings() }) }
        item { OutlinedButton(onClick = { activity.applyGameMode(game.packageName, "standard") }, modifier = Modifier.fillMaxWidth()) { Text("Restaurar modo padrão", color = Color.White) } }
        item { Button(onClick = onLaunch, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Ink)) { Text("Iniciar ${game.name}", fontWeight = FontWeight.Bold) } }
        item { Text("Se o Shizuku não estiver ativo, o TZGame abre o app Shizuku. Inicie o serviço e volte: a autorização aparecerá para você aprovar. As opções de modo de jogo variam por versão do Android e fabricante.", color = Color.Gray, fontSize = 12.sp) }
    }
}

@Composable
private fun ActionButton(title: String, subtitle: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        contentPadding = PaddingValues(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Panel, contentColor = Color.White)
    ) {
        Column(Modifier.fillMaxWidth()) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(Modifier.height(3.dp))
            Text(subtitle, color = Color.LightGray, fontSize = 12.sp)
        }
    }
}

@Composable
private fun DevicePage(context: Context, refresh: Int) {
    val s = remember(refresh) { readDeviceStats(context) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { Text("Diagnóstico do celular", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        item { InfoCard("Processador", "${s.soc}\n${s.cores} núcleos · ABI ${s.abi}") }
        item { InfoCard("Gráficos", "${s.gpuHint}\nOpenGL ES ${s.glEs}") }
        item { InfoCard("Memória", "${s.ramLivre} livres de ${s.ramTotal}") }
        item { InfoCard("Bateria e temperatura", "${s.bateria}% · ${s.temp}°C") }
        item { InfoCard("Conexão", "${s.rede}\n${s.redeDetail}") }
        item { InfoCard("Tela", s.refreshRate) }
        item { Text("Este painel identifica o hardware reportado pelo sistema; não instala atualizações de CPU/GPU nem altera o firmware do Wi‑Fi.", color = Color.Gray, fontSize = 12.sp) }
    }
}

@Composable
private fun StatChip(label: String, value: String) {
    Surface(color = Color(0xFF202B3D), shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 9.dp)) {
            Text(label, color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun InfoCard(title: String, value: String) {
    Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title.uppercase(Locale.getDefault()), color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(Modifier.height(5.dp))
            Text(value, color = Color.White, fontSize = 14.sp)
        }
    }
}

private data class DeviceStats(
    val soc: String, val cores: Int, val abi: String, val gpuHint: String, val glEs: String,
    val ramLivre: String, val ramTotal: String, val bateria: Int, val temp: String,
    val rede: String, val redeDetail: String, val refreshRate: String
)

@Suppress("DEPRECATION")
private fun readDeviceStats(context: Context): DeviceStats {
    val soc = if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL.isNotBlank()) Build.SOC_MODEL else Build.HARDWARE
    val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val memory = ActivityManager.MemoryInfo()
    activityManager.getMemoryInfo(memory)
    val batteryIntent = context.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val battery = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
    val tempRaw = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
    val temp = if (tempRaw > 0) String.format(Locale.US, "%.1f", tempRaw / 10f) else "—"
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val network = cm.activeNetwork
    val caps = network?.let { cm.getNetworkCapabilities(it) }
    val isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
    val isCell = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
    val netName = when { isWifi -> "Wi‑Fi"; isCell -> "Dados móveis"; caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet"; else -> "Sem conexão" }
    val down = caps?.linkDownstreamBandwidthKbps ?: 0
    val up = caps?.linkUpstreamBandwidthKbps ?: 0
    val netDetail = if (down > 0) "Estimativa do Android: ↓ ${down} kb/s · ↑ ${up} kb/s" else "Velocidade/latência real dependem do roteador e da internet"
    val refreshRate = runCatching { String.format(Locale.US, "%.0f Hz", (context as? ComponentActivity)?.windowManager?.defaultDisplay?.refreshRate ?: 0f) }.getOrDefault("Não informado")
    val glEs = runCatching { activityManager.deviceConfigurationInfo.glEsVersion ?: "não informado" }.getOrDefault("não informado")
    return DeviceStats(
        soc = soc.ifBlank { "Não informado pelo fabricante" }, cores = Runtime.getRuntime().availableProcessors(),
        abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "não informado", gpuHint = "Modelo exato não exposto em API pública universal",
        glEs = glEs, ramLivre = formatBytes(memory.availMem), ramTotal = formatBytes(memory.totalMem), bateria = battery,
        temp = temp, rede = netName, redeDetail = netDetail, refreshRate = refreshRate
    )
}

private fun formatBytes(bytes: Long): String {
    val gb = bytes / (1024.0 * 1024.0 * 1024.0)
    return if (gb >= 1.0) String.format(Locale.getDefault(), "%.1f GB", gb) else "${bytes / (1024 * 1024)} MB"
}

@Suppress("DEPRECATION")
private fun loadLaunchableApps(context: Context): List<GameItem> {
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return context.packageManager.queryIntentActivities(intent, 0)
        .mapNotNull { info ->
            val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
            if (pkg == context.packageName) return@mapNotNull null
            GameItem(info.loadLabel(context.packageManager)?.toString() ?: pkg, pkg)
        }
        .distinctBy { it.packageName }
        .sortedBy { it.name.lowercase(Locale.getDefault()) }
}

private fun launchGame(context: Context, game: GameItem) {
    val intent = context.packageManager.getLaunchIntentForPackage(game.packageName) ?: return
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    context.startActivity(intent)
}

@Composable
private fun HtmlPage(activity: MainActivity, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier.fillMaxWidth().padding(bottom = 8.dp),
        factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = false
                addJavascriptInterface(TzGameBridge(activity), "TzGame")
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean = !url.startsWith("file:///android_asset/")
                }
                loadUrl("file:///android_asset/index.html")
            }
        }
    )
}

class TzGameBridge(private val activity: MainActivity) {
    @JavascriptInterface
    fun getGames(): String {
        val result = JSONArray()
        loadLaunchableApps(activity).forEach { game ->
            result.put(JSONObject().put("name", game.name).put("packageName", game.packageName))
        }
        return result.toString()
    }

    @JavascriptInterface
    fun optimizeGame(packageName: String) = activity.runOnUiThread { activity.applyGameMode(packageName, "performance") }

    @JavascriptInterface
    fun accelerateGpu(packageName: String) = activity.runOnUiThread { activity.applyGameMode(packageName, "performance") }

    @JavascriptInterface
    fun restoreDefault(packageName: String) = activity.runOnUiThread { activity.applyGameMode(packageName, "standard") }

    @JavascriptInterface
    fun optimizeWifi() = activity.runOnUiThread { activity.openWifiSettings() }

    @JavascriptInterface
    fun smoothTouch() = activity.runOnUiThread { activity.openDisplaySettings() }

    @JavascriptInterface
    fun authorizeShizuku() = activity.runOnUiThread { activity.connectShizuku() }

    @JavascriptInterface
    fun launchGame(packageName: String) = activity.runOnUiThread { activity.launchGamePackage(packageName) }
}
