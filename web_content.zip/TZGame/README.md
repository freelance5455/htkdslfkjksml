# TZGame — MVP Android

Aplicativo Android nativo em Kotlin + Jetpack Compose, com identidade TZGame (toxzinfps), launcher de apps, diagnóstico do aparelho e fluxo de autorização Shizuku.

## O que já está no projeto
- Painel com SoC reportado pelo Android, núcleos, RAM, bateria/temperatura, rede e taxa de atualização.
- Informação de capacidade OpenGL ES e identificação explícita quando o Android não expõe o modelo de GPU.
- Lista de aplicativos iniciáveis para abrir jogos rapidamente.
- Integração de API Shizuku: detecção do serviço, abertura do app Shizuku, pedido de permissão e estado autorizado.
- Seleção de um app/jogo para abrir uma tela de ações.
- Perfil de desempenho do Android (`cmd game mode performance <pacote>`) e restauração para modo padrão por Shizuku, em Android 12+ quando o fabricante aceitar o comando.
- Atalhos para o painel de conectividade e configurações de tela do sistema.
- Interface escura tecnológica adaptável, com os mesmos controles ativos também na página `assets/index.html` dentro da aba HTML.

## Limites importantes
Este MVP não altera clock/voltagem de CPU ou GPU, não atualiza firmware e não promete reduzir ping nem atraso do toque. “Acelerar GPU” solicita o perfil de desempenho do modo de jogo do Android; o sistema/fabricante decide o efeito e pode ignorar a solicitação. “Otimizar Wi‑Fi” abre o painel de conectividade; “Toque suave” abre configurações de tela para o usuário escolher a taxa de atualização disponível. O Shizuku concede identidade ADB/shell (ou root via Sui), não remove as políticas do fabricante; a disponibilidade do modo de desempenho depende da versão do Android e do aparelho. Os valores de rede são estimativas reportadas pelo Android, não um teste de velocidade.

Ao tocar em um app na aba Jogos, aparecem as ações. Se Shizuku não estiver ativo, o TZGame tenta abrir o aplicativo Shizuku; a pessoa precisa iniciar o serviço e aprovar a solicitação quando voltar. A aprovação nunca é automática.

## Abrir e compilar
1. Abra a pasta `TZGame` no Android Studio recente.
2. Aguarde a sincronização do Gradle e compile para um aparelho Android 8.0+.
3. Instale e inicie Shizuku no telefone; no Android 11+, use Depuração sem fio para iniciar sem PC.
4. No TZGame, toque em **Ativar / autorizar Shizuku** e aceite a solicitação no Shizuku.

A autorização é solicitada pelo próprio app e pode ser revogada a qualquer momento nas configurações do Shizuku.

## Próximos módulos possíveis
HUD flutuante com consentimento de sobreposição, painel de ping/estabilidade (sem alegar aceleração), perfis seguros de sessão e integração com o modo de jogo oficial quando o fabricante disponibilizar API. O modo de desempenho desta versão depende do comando disponível no Android do aparelho; qualquer ação privilegiada adicional precisa ser validada por modelo, sem comandos de overclock ou desativação de proteção térmica.
