# KINGLDZ MUSIC

Reproductor musical local creado con HTML5, CSS3 y JavaScript modular.

## Abrir en SPCK
Abre `index.html` desde la carpeta del proyecto. Mantén las carpetas `css`, `js` y `assets` junto a él.

## Música
Pulsa **Añadir música** y selecciona uno o varios archivos de audio mediante el selector de Android. Una página web normal no puede escanear silenciosamente todo el almacenamiento del teléfono.

La aplicación guarda metadatos y los archivos seleccionados en IndexedDB para intentar conservar la biblioteca local. Algunos navegadores pueden imponer límites de almacenamiento o restricciones adicionales.

## Importante sobre ejecución
Las funciones con módulos ES (`type="module"`) y IndexedDB funcionan mejor cuando SPCK sirve el proyecto mediante su vista previa/servidor local, en vez de abrirlo como `file://`.

## APK
Para empaquetarlo como APK, usa un empaquetador WebView compatible con tu proyecto. Si lo conviertes a una APK, el acceso a música en segundo plano, notificaciones del sistema, controles de pantalla bloqueada y acceso amplio al almacenamiento requieren integración nativa y permisos de Android; esta versión web usa las APIs del navegador.

## Tema y About
El tema oscuro por defecto usa negro y rosa claro como identidad visual. En Configuración hay un apartado About del creador con enlaces de ejemplo para Instagram, Telegram, GitHub y WhatsApp. Sustituye las URLs de ejemplo por las tuyas antes de distribuir la aplicación.


## Iconos personalizables
Los iconos están en `assets/icons/`. Puedes reemplazar `home.svg`, `search.svg`, `library.svg`, `favorites.svg`, `profile.svg`, `creator.svg`, `instagram.svg`, `telegram.svg`, `github.svg`, `whatsapp.svg` y `other.svg` por tus propios SVG. Mantén los mismos nombres para no cambiar el código. El menú inferior usa iconos tipo Android (casa, lupa, biblioteca, corazón y usuario).
