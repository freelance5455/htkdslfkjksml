const titles={home:"Inicio",search:"Buscar",library:"Biblioteca",favorites:"Favoritos",profile:"Perfil"};
export function initNavigation(onPage){
 document.querySelectorAll(".nav-item").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.page,onPage)));
}
export function showPage(page,onPage){
 document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));
 document.getElementById(page+"Page").classList.add("active");
 document.querySelectorAll(".nav-item").forEach(x=>x.classList.toggle("active",x.dataset.page===page));
 document.getElementById("pageTitle").textContent=titles[page]||"KINGLDZ";
 onPage?.(page);
}
export const pageTitles=titles;
