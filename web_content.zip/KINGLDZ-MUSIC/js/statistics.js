const KEY="kingldz_stats";
const defaults={plays:0,seconds:0,bySong:{},byArtist:{},byAlbum:{},byPlaylist:{}};
export function getStats(){try{return {...defaults,...JSON.parse(localStorage.getItem(KEY)||"{}")}}catch{return {...defaults}}}
export function saveStats(s){localStorage.setItem(KEY,JSON.stringify(s))}
export function recordPlay(song){const s=getStats();s.plays++;s.bySong[song.id]=(s.bySong[song.id]||0)+1;s.byArtist[song.artist]=(s.byArtist[song.artist]||0)+1;s.byAlbum[song.album]=(s.byAlbum[song.album]||0)+1;saveStats(s);return s}
export function addSeconds(sec){const s=getStats();s.seconds+=Math.max(0,sec);saveStats(s);return s}
export function top(map){return Object.entries(map||{}).sort((a,b)=>b[1]-a[1])[0]||null}
