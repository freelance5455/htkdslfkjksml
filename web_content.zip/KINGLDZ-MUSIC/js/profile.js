const KEY="kingldz_profile";
const defaults={name:"KINGLDZ",username:"@kingldz",bio:"Amante de la música 🎧",avatar:"",links:[]};
export function getProfile(){try{return {...defaults,...JSON.parse(localStorage.getItem(KEY)||"{}")}}catch{return {...defaults}}}
export function saveProfile(p){localStorage.setItem(KEY,JSON.stringify(p))}
