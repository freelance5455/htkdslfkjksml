import {getAll,put,remove,clearStore,get} from "./database.js";
import {getPlaylists,savePlaylists,createPlaylist,deletePlaylist,addToPlaylist,removeFromPlaylist} from "./playlists.js";
import {getProfile,saveProfile} from "./profile.js";
import {getStats,top,addSeconds} from "./statistics.js";
import {loadSettings,applySettings} from "./settings.js";
import {Player} from "./player.js";
import {initNavigation,showPage} from "./navigation.js";

const $=s=>document.querySelector(s);
let songs=[], profile=getProfile(), settings=loadSettings(), currentPage="home";
const player=new Player({onChange:s=>{renderAll();},onRender:()=>{renderPlayerUI()}});
applySettings(settings);

function esc(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function fmt(t){if(!isFinite(t))return"0:00";const m=Math.floor(t/60),s=Math.floor(t%60);return `${m}:${String(s).padStart(2,"0")}`}
function toast(m){const x=$("#toast");x.textContent=m;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),2200)}
function cover(s,cls="cover"){return s?.cover?`<img class="${cls}" src="${esc(s.cover)}" alt="">`:`<div class="${cls}">${esc((s?.title||"♫").slice(0,1).toUpperCase())}</div>`}
function songRow(s){const fav=JSON.parse(localStorage.getItem("kingldz_favs")||"[]").includes(s.id);return `<div class="song-row" data-id="${s.id}">${cover(s)}<div class="song-info"><b>${esc(s.title)}</b><span>${esc(s.artist)}${s.album&&s.album!=="Desconocido"?" · "+esc(s.album):""}</span></div><div class="row-actions"><button class="tiny-btn fav ${fav?"favorite-on":""}" data-action="fav">${fav?"♥":"♡"}</button><button class="tiny-btn" data-action="queue">＋</button><button class="tiny-btn" data-action="play">▶</button></div></div>`}
function getFavIds(){return JSON.parse(localStorage.getItem("kingldz_favs")||"[]")}
function setFav(id,on){let a=getFavIds();a=on?[...new Set([...a,id])]:a.filter(x=>x!==id);localStorage.setItem("kingldz_favs",JSON.stringify(a))}
function byIds(ids){return ids.map(id=>songs.find(s=>s.id===id)).filter(Boolean)}

async function loadSongs(){songs=await getAll("songs");renderAll()}
async function importFiles(files){
 for(const file of [...files]){
  if(!file.type.startsWith("audio/") && !/\.(mp3|wav|ogg|m4a|aac|flac)$/i.test(file.name))continue;
  const id=crypto.randomUUID(), meta={id,name:file.name,type:file.type,size:file.size,addedAt:Date.now()};
  await put("songs",{id,title:file.name.replace(/\.[^.]+$/,""),artist:"Artista desconocido",album:"Desconocido",duration:0,cover:""});
  await put("files",{id,blob:file,meta});
 }
 toast(`${files.length} archivo(s) añadido(s)`);
 await loadSongs();
}
async function songObject(id){const s=songs.find(x=>x.id===id);if(!s)return null;const f=await get("files",id);return {...s,url:f?URL.createObjectURL(f.blob):null}}
async function playId(id,collection=songs){const list=[];for(const s of collection){const x=await songObject(s.id);if(x)list.push(x)}const i=list.findIndex(x=>x.id===id);if(i<0)return;player.setQueue(list,i);$("#playerOverlay").classList.remove("hidden");renderPlayerUI()}
async function toggleFavorite(id){setFav(id,!getFavIds().includes(id));renderAll();if(player.current?.id===id)renderPlayerUI()}
async function actionFromRow(e){const row=e.target.closest(".song-row");if(!row)return;const id=row.dataset.id,act=e.target.dataset.action;if(act==="fav")return toggleFavorite(id);const s=await songObject(id);if(!s)return;if(act==="queue"){player.add(s);toast("Añadida a la cola");renderPlayerUI()}else if(act==="play")await playId(id)}
function renderHome(){
 const stats=getStats(), fav=byIds(getFavIds()), recent=Object.entries(stats.bySong||{}).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([id])=>songs.find(s=>s.id===id)).filter(Boolean), pls=getPlaylists();
 $("#homePage").innerHTML=`<div class="hero"><div class="eyebrow">BIENVENIDO</div><h1>Hola, ${esc(profile.name)} 👋</h1><p class="muted">Tu biblioteca musical está lista.</p><button id="addMusicHome" class="primary-btn">🎵 Añadir música</button></div>
 <div class="section-head"><h3>Resumen</h3></div><div class="stats-grid"><div class="stat"><b>${songs.length}</b><span>Canciones</span></div><div class="stat"><b>${stats.plays}</b><span>Reproducciones</span></div><div class="stat"><b>${Math.round(stats.seconds/60)}</b><span>Minutos</span></div><div class="stat"><b>${fav.length}</b><span>Favoritos</span></div></div>
 <div class="section-head"><h3>Reproducido recientemente</h3></div>${recent.length?`<div class="song-list">${recent.map(songRow).join("")}</div>`:`<div class="empty">Todavía no has reproducido canciones.</div>`}
 <div class="section-head"><h3>Tus playlists</h3><button id="newPlaylistHome" class="ghost-btn">＋ Crear</button></div>${playlistCards(pls)}`;
}
function playlistCards(pls){return pls.length?`<div class="playlists-grid">${pls.map(p=>`<article class="playlist-card"><div class="playlist-art">♫</div><h4>${esc(p.name)}</h4><small>${p.songIds.length} canciones</small><button class="secondary-btn playlist-play" data-pid="${p.id}" style="width:100%;margin-top:10px">▶ Reproducir</button></article>`).join("")}</div>`:`<div class="empty">Crea tu primera playlist.</div>`}
function renderSearch(){
 $("#searchPage").innerHTML=`<div class="search-box"><input id="searchInput" placeholder="Buscar canciones, artistas, álbumes o playlists"><button id="searchAdd" class="icon-btn">＋</button></div><div id="searchResults"></div>`;
 $("#searchInput").oninput=()=>{const q=$("#searchInput").value.toLowerCase().trim(),pls=getPlaylists();const ss=songs.filter(s=>[s.title,s.artist,s.album].join(" ").toLowerCase().includes(q)),pp=pls.filter(p=>p.name.toLowerCase().includes(q));$("#searchResults").innerHTML=q?`<div class="section-head"><h3>Canciones</h3></div>${ss.length?`<div class="song-list">${ss.map(songRow).join("")}</div>`:`<div class="empty">No se encontraron canciones.</div>`}<div class="section-head"><h3>Playlists</h3></div>${pp.length?playlistCards(pp):`<div class="empty">No se encontraron playlists.</div>`}`:`<div class="empty" style="margin-top:20px">Escribe para buscar en tu biblioteca.</div>`}
}
function renderLibrary(){
 const pls=getPlaylists();
 $("#libraryPage").innerHTML=`<div class="section-head"><h3>Tu música</h3><button id="libraryAdd" class="primary-btn" style="width:auto">🎵 Añadir</button></div>${songs.length?`<div class="song-list">${songs.map(songRow).join("")}</div>`:`<div class="empty">No hay canciones. Añade archivos de audio desde tu teléfono.</div>`}<div class="section-head"><h3>Playlists</h3><button id="newPlaylist" class="ghost-btn">＋ Crear</button></div>${playlistCards(pls)}`;
}
function renderFavorites(){const fav=byIds(getFavIds());$("#favoritesPage").innerHTML=`<div class="section-head"><h3>❤️ Favoritos</h3></div>${fav.length?`<div class="song-list">${fav.map(songRow).join("")}</div>`:`<div class="empty">Marca canciones con ♡ para verlas aquí.</div>`}`}
function renderProfile(){
 const st=getStats(), t=top(st.bySong), mins=Math.round(st.seconds/60);
 $("#profilePage").innerHTML=`<div class="profile-card">${profile.avatar?`<img class="avatar" src="${esc(profile.avatar)}" alt="">`:`<div class="avatar">${esc(profile.name.slice(0,1).toUpperCase())}</div>`}<h2>${esc(profile.name)}</h2><div class="muted">${esc(profile.username)}</div><p>${esc(profile.bio)}</p><button id="editProfile" class="secondary-btn">Editar perfil</button><div class="stats-grid" style="margin-top:16px"><div class="stat"><b>${st.plays}</b><span>Reproducciones</span></div><div class="stat"><b>${mins}</b><span>Minutos</span></div><div class="stat"><b>${getPlaylists().length}</b><span>Playlists</span></div><div class="stat"><b>${getFavIds().length}</b><span>Favoritos</span></div></div><div class="section-head"><h3>Redes y enlaces</h3><button id="addLink" class="ghost-btn">＋ Añadir</button></div><div class="profile-links">${profile.links.map((l,i)=>`<div class="link-card"><span>🔗 ${esc(l.name)}</span><span><button class="tiny-btn open-link" data-url="${esc(l.url)}">↗</button><button class="tiny-btn del-link" data-i="${i}">×</button></span></div>`).join("")||`<div class="empty">Añade tus redes o enlaces.</div>`}</div><div class="section-head"><h3>Dashboard</h3></div><div class="bar-chart">${[0,1,2,3,4,5,6].map((_,i)=>`<i style="height:${20+Math.min(75,(Object.values(st.bySong).reduce((a,b)=>a+b,0)*(i+1)%90))}%"></i>`).join("")}</div><p class="muted">Canción más reproducida: ${esc(t?.[0]||"Ninguna")}</p></div>`;
}
function renderSettings(){
 $("#settingsPage").innerHTML=`<div class="settings-list">
 <div class="setting"><span>Tema</span><select id="themeSel"><option value="dark">Negro + rosa (por defecto)</option><option value="light">Claro</option><option value="auto">Automático</option></select></div>
 <div class="setting"><span>Reproducción automática</span><input id="autoplaySet" class="switch" type="checkbox" ${settings.autoplay?"checked":""}></div>
 <div class="setting"><span>Aleatorio</span><input id="shuffleSet" class="switch" type="checkbox" ${settings.shuffle?"checked":""}></div>
 <div class="setting"><span>Animaciones</span><input id="animSet" class="switch" type="checkbox" ${settings.animations?"checked":""}></div>
 <div class="setting"><span>Notificaciones visuales</span><input id="notifSet" class="switch" type="checkbox" ${settings.notifications?"checked":""}></div>
 <button id="exportData" class="secondary-btn">Exportar datos</button><button id="importData" class="secondary-btn">Importar datos</button>
 <button id="clearHistory" class="secondary-btn">Borrar historial</button><button id="clearLibrary" class="secondary-btn">Borrar biblioteca</button>
 <button id="resetApp" class="primary-btn">Restablecer aplicación</button><button id="logout" class="ghost-btn">Cerrar sesión</button>
 </div>
 <div class="about-card">
   <div class="about-title-row">
     <div class="about-icon-slot"><img src="assets/icons/creator.svg" alt="Icono del creador"></div>
     <div><span class="creator-badge">✦ ABOUT KINGLDZ MUSIC</span><h3>Sobre el creador</h3></div>
   </div>
   <p class="about-note">KINGLDZ MUSIC es un proyecto creado para disfrutar y organizar música local desde una interfaz móvil. Personaliza esta sección con tu información.</p>
   <div class="social-grid">
     <a class="social-link" href="https://instagram.com/" target="_blank" rel="noopener"><span class="social-icon-slot"><img src="assets/icons/instagram.svg" alt=""></span><b>Instagram</b><span>Visitar ↗</span></a>
     <a class="social-link" href="https://t.me/" target="_blank" rel="noopener"><span class="social-icon-slot"><img src="assets/icons/telegram.svg" alt=""></span><b>Telegram</b><span>Visitar ↗</span></a>
     <a class="social-link" href="https://github.com/" target="_blank" rel="noopener"><span class="social-icon-slot"><img src="assets/icons/github.svg" alt=""></span><b>GitHub</b><span>Visitar ↗</span></a>
     <a class="social-link" href="https://wa.me/" target="_blank" rel="noopener"><span class="social-icon-slot"><img src="assets/icons/whatsapp.svg" alt=""></span><b>WhatsApp</b><span>Visitar ↗</span></a>
     <a class="social-link" href="#" onclick="return false;"><span class="social-icon-slot"><img src="assets/icons/other.svg" alt=""></span><b>Otra red</b><span>Editar ↗</span></a>
   </div>
   <p class="about-note">Los archivos de iconos son espacios reservados: coloca tus propios PNG/SVG en <code>assets/icons/</code> usando esos mismos nombres.</p>
 </div>`;
 $("#themeSel").value=settings.theme;
}
function renderPlayerUI(){
 const s=player.current;if(!s){$("#miniPlayer").classList.add("hidden");return}
 $("#miniPlayer").classList.remove("hidden");$("#miniPlayer").innerHTML=`${cover(s)}<div class="mini-info"><b>${esc(s.title)}</b><span>${esc(s.artist)}</span></div><button class="mini-play" id="miniPlay">${player.audio.paused?"▶":"Ⅱ"}</button>`;
 $("#fullCover").outerHTML=cover(s,"full-cover");$("#fullTitle").textContent=s.title;$("#fullArtist").textContent=s.artist;$("#fullFavorite").textContent=getFavIds().includes(s.id)?"♥":"♡";$("#fullFavorite").classList.toggle("favorite-on",getFavIds().includes(s.id));
 const d=player.audio.duration||0,t=player.audio.currentTime||0;$("#progress").value=d?t/d*100:0;$("#currentTime").textContent=fmt(t);$("#duration").textContent=fmt(d);$("#playBtn").textContent=player.audio.paused?"▶":"Ⅱ";$("#shuffleBtn").classList.toggle("favorite-on",player.shuffle);$("#repeatBtn").textContent=player.repeat==="one"?"↻1":player.repeat==="all"?"↻":"↻";$("#volume").value=player.audio.volume;$("#volumeLabel").textContent=Math.round(player.audio.volume*100)+"%";
 $("#queueList").innerHTML=player.queue.map((x,i)=>`<div class="queue-item"><div class="song-info"><b>${esc(x.title)}</b><span>${esc(x.artist)}</span></div><button class="tiny-btn" data-qremove="${x.id}">×</button></div>`).join("")||`<div class="muted">Cola vacía</div>`;
}
function renderAll(){renderHome();renderSearch();renderLibrary();renderFavorites();renderProfile();renderSettings();renderPlayerUI();wireDynamic()}
function wireDynamic(){
 document.querySelectorAll(".song-row").forEach(x=>x.onclick=actionFromRow);
 $("#addMusicHome")?.addEventListener("click",()=>$("#audioPicker").click());$("#libraryAdd")?.addEventListener("click",()=>$("#audioPicker").click());$("#searchAdd")?.addEventListener("click",()=>$("#audioPicker").click());
 document.querySelectorAll(".playlist-play").forEach(b=>b.onclick=async()=>{const p=getPlaylists().find(x=>x.id===b.dataset.pid);const ss=byIds(p?.songIds||[]);if(ss.length)await playId(ss[0].id,ss)});
 $("#newPlaylist,#newPlaylistHome")?.addEventListener("click",newPlaylist);
 $("#editProfile")?.addEventListener("click",editProfile);$("#addLink")?.addEventListener("click",addLink);
 document.querySelectorAll(".open-link").forEach(b=>b.onclick=()=>window.open(b.dataset.url,"_blank"));document.querySelectorAll(".del-link").forEach(b=>b.onclick=()=>{profile.links.splice(+b.dataset.i,1);saveProfile(profile);renderProfile()});
}
function newPlaylist(){const n=prompt("Nombre de la playlist:");if(n?.trim()){createPlaylist(n.trim());renderAll();toast("Playlist creada")}}
function editProfile(){const name=prompt("Nombre",profile.name);if(name===null)return;const username=prompt("Usuario",profile.username);if(username===null)return;const bio=prompt("Bio",profile.bio);profile={...profile,name,username,bio};saveProfile(profile);renderAll()}
function addLink(){const name=prompt("Nombre del enlace (Instagram, TikTok, etc.)");if(!name)return;const url=prompt("URL completa (https://...)");if(!url)return;profile.links.push({name,url});saveProfile(profile);renderProfile()}
function initEvents(){
 $("#audioPicker").addEventListener("change",e=>importFiles(e.target.files));
 $("#loginForm").onsubmit=e=>{e.preventDefault();const u=$("#loginUser").value.trim()||"KINGLDZ";localStorage.setItem("kingldz_session",JSON.stringify({user:u}));profile.name=u;saveProfile(profile);showMain()};
 $("#createAccountBtn").onclick=()=>{$("#loginUser").focus();toast("Introduce un usuario y contraseña para crear tu sesión local")};
 $("#guestBtn").onclick=()=>{localStorage.setItem("kingldz_session",JSON.stringify({user:"Invitado"}));showMain()};
 $("#topSettingsBtn").onclick=()=>showPage("settings",renderAll);$("#miniPlayer").onclick=e=>{if(e.target.id==="miniPlay"){player.toggle();renderPlayerUI()}else $("#playerOverlay").classList.remove("hidden")};
 $("#closePlayer").onclick=()=>$("#playerOverlay").classList.add("hidden");$("#playBtn").onclick=()=>player.toggle();$("#prevBtn").onclick=()=>player.prev();$("#nextBtn").onclick=()=>player.next();$("#progress").oninput=e=>player.seek(+e.target.value);$("#volume").oninput=e=>player.setVolume(e.target.value);$("#shuffleBtn").onclick=()=>{player.shuffle=!player.shuffle;renderPlayerUI()};$("#repeatBtn").onclick=()=>{player.repeat=player.repeat==="none"?"all":player.repeat==="all"?"one":"none";renderPlayerUI()};$("#fullFavorite").onclick=()=>player.current&&toggleFavorite(player.current.id);$("#addQueueBtn").onclick=()=>{if(player.current)player.add(player.current);toast("Añadida a la cola")};$("#addPlaylistBtn").onclick=()=>{if(!player.current)return;const ps=getPlaylists();if(!ps.length)return newPlaylist();const names=ps.map((p,i)=>`${i+1}. ${p.name}`).join("\n");const n=prompt(`Elige playlist por número:\n${names}`);const p=ps[Number(n)-1];if(p){addToPlaylist(p.id,player.current.id);toast("Añadida a playlist")}};
 document.addEventListener("click",e=>{const id=e.target.dataset.qremove;if(id){player.remove(id);renderPlayerUI()}});
 $("#themeSel")?.addEventListener("change",()=>{});document.body.addEventListener("change",e=>{if(!e.target.id)return;const id=e.target.id;if(id==="themeSel")settings.theme=e.target.value;if(id==="autoplaySet")settings.autoplay=e.target.checked;if(id==="shuffleSet")settings.shuffle=e.target.checked;if(id==="animSet")settings.animations=e.target.checked;if(id==="notifSet")settings.notifications=e.target.checked;player.shuffle=settings.shuffle;applySettings(settings);});
 $("#exportData").onclick=()=>{const data={profile,getPlaylists,settings,getFavIds,stats:getStats()};const blob=new Blob([JSON.stringify({profile,playlists:getPlaylists(),settings,favorites:getFavIds(),stats:getStats()},null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="kingldz-music-backup.json";a.click()};
 $("#clearHistory").onclick=()=>{if(confirm("¿Borrar estadísticas e historial?")){localStorage.removeItem("kingldz_stats");renderAll();toast("Historial borrado")}};
 $("#clearLibrary").onclick=async()=>{if(confirm("¿Eliminar todas las canciones importadas?")){await clearStore("songs");await clearStore("files");songs=[];renderAll();toast("Biblioteca borrada")}};
 $("#resetApp").onclick=async()=>{if(confirm("¿Restablecer toda la aplicación?")){localStorage.clear();await clearStore("songs");await clearStore("files");location.reload()}};
 $("#logout").onclick=()=>{localStorage.removeItem("kingldz_session");location.reload()};
}
function showMain(){$("#loginView").classList.add("hidden");$("#mainView").classList.remove("hidden");initNavigation(p=>{currentPage=p;renderAll()});renderAll()}
(async()=>{initEvents();await loadSongs();if(localStorage.getItem("kingldz_session"))showMain()})()
