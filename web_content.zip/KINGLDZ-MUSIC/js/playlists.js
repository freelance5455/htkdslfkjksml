const KEY="kingldz_playlists";
export function getPlaylists(){try{return JSON.parse(localStorage.getItem(KEY)||"[]")}catch{return []}}
export function savePlaylists(p){localStorage.setItem(KEY,JSON.stringify(p))}
export function createPlaylist(name){const p=getPlaylists();const x={id:crypto.randomUUID(),name:name||"Nueva playlist",songIds:[],createdAt:Date.now()};p.push(x);savePlaylists(p);return x}
export function deletePlaylist(id){savePlaylists(getPlaylists().filter(x=>x.id!==id))}
export function addToPlaylist(pid,sid){const p=getPlaylists(),x=p.find(x=>x.id===pid);if(x&&!x.songIds.includes(sid)){x.songIds.push(sid);savePlaylists(p)}}
export function removeFromPlaylist(pid,sid){const p=getPlaylists(),x=p.find(x=>x.id===pid);if(x){x.songIds=x.songIds.filter(id=>id!==sid);savePlaylists(p)}}
