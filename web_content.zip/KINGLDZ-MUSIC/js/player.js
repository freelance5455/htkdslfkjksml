import {recordPlay,addSeconds} from "./statistics.js";
export class Player{
 constructor({onChange,onRender}){this.audio=new Audio();this.queue=[];this.index=-1;this.shuffle=false;this.repeat="none";this.current=null;this.lastStat=0;this.onChange=onChange;this.onRender=onRender;
  this.audio.addEventListener("timeupdate",()=>{this.onRender?.("time");if(this.audio.currentTime-this.lastStat>=10){addSeconds(10);this.lastStat=this.audio.currentTime}});
  this.audio.addEventListener("loadedmetadata",()=>this.onRender?.("meta"));
  this.audio.addEventListener("play",()=>this.onRender?.("play"));
  this.audio.addEventListener("pause",()=>this.onRender?.("pause"));
  this.audio.addEventListener("ended",()=>this.next(true));
 }
 async play(song){if(!song)return;if(this.current?.id!==song.id){this.audio.pause();if(this.current?.url)URL.revokeObjectURL(this.current.url);this.current=song;this.audio.src=song.url;this.audio.load();this.lastStat=0;recordPlay(song);this.onChange?.(song)}
  try{await this.audio.play()}catch(e){this.onRender?.("error",e)}
 }
 pause(){this.audio.pause()} toggle(){this.audio.paused?this.play(this.current):this.pause()}
 seek(percent){if(this.audio.duration)this.audio.currentTime=(percent/100)*this.audio.duration}
 setVolume(v){this.audio.volume=Number(v)}
 setQueue(songs,index=0){this.queue=[...songs];this.index=index;this.play(this.queue[this.index])}
 add(song){if(song&&!this.queue.some(x=>x.id===song.id))this.queue.push(song);this.onRender?.("queue")}
 remove(id){this.queue=this.queue.filter(x=>x.id!==id);this.onRender?.("queue")}
 async next(ended=false){if(!this.queue.length)return;
  if(ended&&this.repeat==="one"){this.audio.currentTime=0;return this.play(this.current)}
  if(this.shuffle&&this.queue.length>1){let n=Math.floor(Math.random()*this.queue.length);if(n===this.index)n=(n+1)%this.queue.length;this.index=n}
  else this.index=(this.index+1)%this.queue.length;
  if(this.index===0&&ended&&this.repeat==="none"){this.pause();return}
  return this.play(this.queue[this.index])
 }
 prev(){if(this.audio.currentTime>4){this.audio.currentTime=0;return}if(!this.queue.length)return;this.index=(this.index-1+this.queue.length)%this.queue.length;this.play(this.queue[this.index])}
}
