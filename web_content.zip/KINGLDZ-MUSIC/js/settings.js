const KEY="kingldz_settings";
export const defaults={theme:"dark",autoplay:false,shuffle:false,repeat:"none",animations:true,notifications:true};
export function loadSettings(){try{return {...defaults,...JSON.parse(localStorage.getItem(KEY)||"{}")}}catch{return {...defaults}}}
export function saveSettings(s){localStorage.setItem(KEY,JSON.stringify(s));document.documentElement.dataset.theme=s.theme==="auto"?(matchMedia("(prefers-color-scheme:dark)").matches?"dark":"light"):s.theme;document.body.classList.toggle("no-animations",!s.animations)}
export function applySettings(s){saveSettings(s)}
