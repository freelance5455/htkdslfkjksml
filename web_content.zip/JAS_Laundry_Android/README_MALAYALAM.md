# JAS Laundry Room — Android app project

ഈ ഫോൾഡറിൽ നിങ്ങളുടെ HTML ഫയൽ ഉൾപ്പെടുത്തിയ Android Studio WebView പ്രോജക്റ്റാണ്. ഇത് APK ആയി build ചെയ്യാൻ Android Studio ഉള്ള കമ്പ്യൂട്ടർ ആവശ്യമാണ്. ഈ പരിസരത്തിൽ Android SDK/Gradle build environment ലഭ്യമല്ലാത്തതിനാൽ ഇവിടെ നേരിട്ട് ഇൻസ്റ്റാൾ ചെയ്യാവുന്ന APK നിർമ്മിച്ച് പരിശോധിച്ചിട്ടില്ല.

## APK നിർമ്മിക്കുന്ന വിധം
1. കമ്പ്യൂട്ടറിൽ Android Studio ഇൻസ്റ്റാൾ ചെയ്യുക.
2. ഈ ZIP extract ചെയ്യുക.
3. Android Studio → **Open** → extract ചെയ്ത `JAS_Laundry_Android` ഫോൾഡർ തിരഞ്ഞെടുക്കുക.
4. Gradle sync പൂർത്തിയാകുന്നത് വരെ കാത്തിരിക്കുക; ആവശ്യപ്പെട്ടാൽ Android SDK Platform 35 ഇൻസ്റ്റാൾ ചെയ്യുക.
5. **Build → Build Bundle(s) / APK(s) → Build APK(s)** തിരഞ്ഞെടുക്കുക.
6. വിജയിച്ചാൽ APK സാധാരണയായി `app/build/outputs/apk/debug/app-debug.apk` എന്നിടത്ത് ഉണ്ടാകും.

## Firebase ശ്രദ്ധിക്കുക
- ഈ പ്രോജക്റ്റ് HTML-നെ Android WebView-ൽ തുറക്കുന്നു; Internet permission, JavaScript, DOM storage എന്നിവ സജ്ജമാക്കിയിട്ടുണ്ട്.
- Firebase യഥാർത്ഥ പ്രോജക്റ്റുമായി ബന്ധിപ്പിച്ച് പരിശോധിച്ചിട്ടില്ല. APK build വിജയിക്കുന്നത് Firebase login/sync വിജയിച്ചതായി അർത്ഥമല്ല.
- `https://appassets.androidplatform.net` origin ഉപയോഗിക്കുന്നതിനാൽ Firebase Authentication-ൽ `auth/unauthorized-domain` വന്നാൽ Firebase Console → Authentication → Settings → Authorized domains-ൽ ഈ domain ചേർക്കേണ്ടി വരാം. നിങ്ങളുടെ Firebase Console-ൽ അനുമതി ഉണ്ടെങ്കിൽ മാത്രം ഇത് ചെയ്യുക.
- Email/Password sign-in Firebase Console-ൽ enable ചെയ്തിരിക്കണം; Owner email-നുള്ള account നിലവിലുണ്ടായിരിക്കണം.

## പാക്കേജ് വിവരങ്ങൾ
- App label: JAS Laundry Room
- Application ID: `com.jaslaundry.room`
- Minimum Android: Android 6.0 (API 23)
