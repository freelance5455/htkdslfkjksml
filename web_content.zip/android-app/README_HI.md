# VideoGenie Android wrapper source

Ye Android Studio project VideoGenie ke Python/Flask backend ko WebView app se kholta hai. **Ye compiled APK nahi hai.** Android SDK/Gradle environment is session mein available nahi tha, isliye APK build/sign/install test nahi kiya gaya.

## Build APK
1. Android Studio mein `android-app` folder open karo.
2. Gradle sync complete hone do (JDK 17 recommended).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK `app/build/outputs/apk/debug/app-debug.apk` mein milega.

## Phone par kaise use karein
1. Backend ko Windows PC par `project/start-for-phone-app.bat` se start karo.
2. PC aur Android phone same Wi-Fi par hone chahiye.
3. Terminal mein jo local IP print ho (example `http://192.168.1.10:5000`), woh Android app ke Server box mein enter karo.
4. Backend chalna zaroori hai; APK akela video render nahi karta.

Android phone par backend chalana ho to Termux mein Python + FFmpeg + dependencies install karke `python app.py` run karo, phir app mein `http://127.0.0.1:5000` set karo. Heavy 1080p/30-minute render ke liye PC/cloud server better hai.

## Security
Backend mein abhi user authentication nahi hai. Isliye ise public internet par expose mat karo. Private trusted Wi-Fi par use karo. Public deployment se pehle login/authentication, HTTPS, rate limiting, job isolation, API-key protection aur storage limits add karna zaroori hai.
