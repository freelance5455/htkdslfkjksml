# WeldMaster Android — исходный проект оболочки

Это Android Studio-проект WebView-оболочки, которая запускает локальные файлы WeldMaster из `app/src/main/assets/www/`. Интернет для основных справочников не нужен. Внешние ссылки на источники требуют соединения.

## Сборка APK
1. Установить Android Studio и Android SDK Platform 35.
2. Открыть в Android Studio папку `android-app`.
3. Дождаться синхронизации Gradle (нужен интернет для загрузки Android Gradle Plugin).
4. Выбрать Build → Build Bundle(s) / APK(s) → Build APK(s).
5. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

Требуется JDK 17 и Gradle 8.9 (Android Studio установит/подберёт Gradle по проекту). Для публикации нужна отдельная release-сборка, подпись ключом и тестирование на реальных устройствах.

## Состав
- `app/src/main/java/.../MainActivity.java` — Android WebView Activity.
- `app/src/main/assets/www/` — полный локальный интерфейс, справочники и офлайн-файлы.
- `app/build.gradle` — параметры приложения, minSdk 23, targetSdk 35.

Это стартовая Android-оболочка. APK в этом архиве не собран и не протестирован на физическом устройстве.
