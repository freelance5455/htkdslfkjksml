MH MIRAZ AI — আপডেট করা Android সোর্স প্রজেক্ট
=============================================

এই ZIP-টি Android Studio source project, APK নয়। আগের ব্র্যান্ডিং, ছবি ও মূল ডিজাইন রাখা হয়েছে।

সোর্সে থাকা ফিচার (এখনো APK build/ফোনে পরীক্ষা করা হয়নি):
- Gemini API ও OpenAI Chat Completions-এর টেক্সট চ্যাট এবং live connection test।
- API Key Android Keystore-ভিত্তিক AES-GCM encryption দিয়ে ডিভাইসে সংরক্ষণ।
- Provider/model নির্বাচন, key দেখানো/লুকানো, Save, Connect/Test, Disconnect।
- বাস্তব API-নির্ভর টেক্সট চ্যাট, লোকাল chat history, emoji, থিম, wallpaper, image library, ছবি attach, floating assistant bubble।
- ছবি API-তে পাঠানোর কোড আছে; ছবির বিশ্লেষণ নির্বাচিত মডেল ও API access-এর ওপর নির্ভরশীল।
- কোনো API Key source code-এ hardcode করা নেই।

এখনো বাস্তবায়িত নয় (বোতাম/সেটিংস রাখা হয়েছে, কিন্তু সংযুক্ত বলে দেখায় না):
- Gmail, Drive, Calendar, YouTube ও অন্য অ্যাকাউন্ট সংযোগ—OAuth/API setup ও বাস্তব integration লাগবে।
- Voice input/output—বর্তমানে টেক্সট চ্যাট।
- Cloud sync/account login—চ্যাটের ইতিহাস এই ডিভাইসেই থাকে।

নিরাপত্তা: Production app-এর জন্য নিজের secure backend ভালো। Keystore at-rest security বাড়ায়, কিন্তু compromised ফোনে বা key ব্যবহারের সময় ফাঁসের ঝুঁকি পুরো দূর করে না। API provider-এর চার্জ/কোটা প্রযোজ্য।

Build status: এই পরিবেশে APK build বা ফোনে install করে পরীক্ষা করা হয়নি। Android SDK/build tools ও Gradle wrapper নেই। কম্পিউটারে Android Studio ও SDK 35 দিয়ে `android-app` ফোল্ডার খুলে Gradle Sync, তারপর Build > Build APK(s)। Package: com.mhmiraz.ai; minSdk 26; target/compile SDK 35।
