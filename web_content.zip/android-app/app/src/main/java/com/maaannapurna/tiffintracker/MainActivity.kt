package com.maaannapurna.tiffintracker

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.webkit.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import java.io.InputStream

/**
 * MainActivity (Kotlin Edition) - Bulletproof WebView for Maa Annapurna Tiffin Management System
 */
class MainActivityKt : AppCompatActivity() {

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    companion object {
        private const val TAG = "MaaAnnapurnaApp"
        private const val CAMERA_PERMISSION_REQUEST_CODE = 101
        private const val FILE_CHOOSER_REQUEST_CODE = 102
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        requestCameraPermissionIfNeeded()
        configureWebSettings()

        val assetLoader = WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler("/web/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/res/", WebViewAssetLoader.ResourcesPathHandler(this))
            .build()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val url = request?.url ?: return null

                val response = assetLoader.shouldInterceptRequest(url)
                if (response != null) return response

                if (url.toString().contains("appassets.androidplatform.net")) {
                    val path = url.path ?: ""
                    var cleanPath = path
                    if (cleanPath.startsWith("/web/")) cleanPath = cleanPath.substring(5)
                    else if (cleanPath.startsWith("/assets/")) cleanPath = cleanPath.substring(8)
                    else if (cleanPath.startsWith("/")) cleanPath = cleanPath.substring(1)
                    if (cleanPath.isEmpty()) cleanPath = "index.html"

                    val fallback = loadAssetDirectly(cleanPath)
                    if (fallback != null) return fallback
                }

                return super.shouldInterceptRequest(view, request)
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    Log.w(TAG, "Main frame error: ${error?.description}. Falling back to file:///android_asset/web/index.html")
                    view?.post { view.loadUrl("file:///android_asset/web/index.html") }
                }
            }

            override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?) {
                super.onReceivedHttpError(view, request, errorResponse)
                if (request?.isForMainFrame == true && (errorResponse?.statusCode ?: 200) >= 400) {
                    Log.w(TAG, "HTTP error: ${errorResponse?.statusCode}. Falling back to file:///android_asset/web/index.html")
                    view?.post { view.loadUrl("file:///android_asset/web/index.html") }
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                runOnUiThread {
                    request?.resources?.forEach { res ->
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE == res) {
                            request.grant(request.resources)
                            return@runOnUiThread
                        }
                    }
                    request?.grant(request.resources)
                }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivityKt.filePathCallback = filePathCallback
                val intent = fileChooserParams?.createIntent()
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST_CODE)
                } catch (e: ActivityNotFoundException) {
                    this@MainActivityKt.filePathCallback = null
                    Toast.makeText(this@MainActivityKt, "Cannot open file chooser", Toast.LENGTH_SHORT).show()
                    return false
                }
                return true
            }
        }

        webView.loadUrl("https://appassets.androidplatform.net/web/index.html")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebSettings() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.builtInZoomControls = false
        settings.displayZoomControls = false
        settings.mediaPlaybackRequiresUserGesture = false
        settings.cacheMode = WebSettings.LOAD_DEFAULT

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
    }

    private fun loadAssetDirectly(relativePath: String): WebResourceResponse? {
        try {
            var stream: InputStream? = null
            try {
                stream = assets.open("web/$relativePath")
            } catch (e1: Exception) {
                try {
                    stream = assets.open(relativePath)
                } catch (ignored: Exception) {}
            }

            if (stream != null) {
                val mimeType = getMimeType(relativePath)
                val headers = HashMap<String, String>()
                headers["Access-Control-Allow-Origin"] = "*"
                headers["Cache-Control"] = "no-cache"
                return WebResourceResponse(mimeType, "UTF-8", 200, "OK", headers, stream)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error loading asset: $relativePath", e)
        }
        return null
    }

    private fun getMimeType(path: String): String {
        val lower = path.lowercase()
        return when {
            lower.endsWith(".html") || lower.endsWith(".htm") -> "text/html"
            lower.endsWith(".css") -> "text/css"
            lower.endsWith(".js") -> "application/javascript"
            lower.endsWith(".json") -> "application/json"
            lower.endsWith(".png") -> "image/png"
            lower.endsWith(".jpg") || lower.endsWith(".jpeg") -> "image/jpeg"
            lower.endsWith(".svg") -> "image/svg+xml"
            lower.endsWith(".ico") -> "image/x-icon"
            else -> "application/octet-stream"
        }
    }

    private fun requestCameraPermissionIfNeeded() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_REQUEST_CODE)
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
