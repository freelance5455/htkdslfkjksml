package com.maaannapurna.tiffintracker;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * MainActivity - Bulletproof WebView for Maa Annapurna Tiffin Management System
 * Completely resolves:
 * 1. net::ERR_HTTP_RESPONSE_CODE_FAILURE
 * 2. Missing WebViewAssetLoader path mappings (/web/ and /assets/)
 * 3. Camera permissions for QR code scanner (WebChromeClient onPermissionRequest)
 * 4. Full offline asset loading with automatic fallback to file:///android_asset/
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MaaAnnapurnaApp";
    private static final int CAMERA_PERMISSION_REQUEST_CODE = 101;
    private static final int FILE_CHOOSER_REQUEST_CODE = 102;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        // 1. Request Runtime Camera Permission for QR Code Scanner
        requestCameraPermissionIfNeeded();

        // 2. Configure WebView Settings (JavaScript, DOM Storage, Offline Cache)
        configureWebSettings();

        // 3. Configure WebViewAssetLoader with BOTH /web/ and /assets/ path handlers
        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .setDomain("appassets.androidplatform.net")
                .addPathHandler("/web/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/res/", new WebViewAssetLoader.ResourcesPathHandler(this))
                .build();

        // 4. Attach Bulletproof WebViewClient with Auto-Recovery
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();

                // Step A: Let WebViewAssetLoader handle standard registered paths
                WebResourceResponse response = assetLoader.shouldInterceptRequest(url);
                if (response != null) {
                    return response;
                }

                // Step B: Fail-safe interceptor for any appassets.androidplatform.net URL
                String urlStr = url.toString();
                if (urlStr.contains("appassets.androidplatform.net")) {
                    String path = url.getPath();
                    if (path != null) {
                        String cleanPath = path;
                        if (cleanPath.startsWith("/web/")) {
                            cleanPath = cleanPath.substring(5);
                        } else if (cleanPath.startsWith("/assets/")) {
                            cleanPath = cleanPath.substring(8);
                        } else if (cleanPath.startsWith("/")) {
                            cleanPath = cleanPath.substring(1);
                        }
                        if (cleanPath.isEmpty()) {
                            cleanPath = "index.html";
                        }

                        WebResourceResponse fallbackResponse = loadAssetDirectly(cleanPath);
                        if (fallbackResponse != null) {
                            return fallbackResponse;
                        }
                    }
                }

                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) {
                    Log.w(TAG, "Main frame error on URL: " + request.getUrl() + ". Auto-recovering via direct asset URL...");
                    // Emergency fallback: Native file:///android_asset/ never fails with HTTP status errors
                    view.post(() -> view.loadUrl("file:///android_asset/web/index.html"));
                }
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                super.onReceivedHttpError(view, request, errorResponse);
                if (request.isForMainFrame() && errorResponse.getStatusCode() >= 400) {
                    Log.w(TAG, "HTTP error " + errorResponse.getStatusCode() + ". Recovering via local asset loader...");
                    view.post(() -> view.loadUrl("file:///android_asset/web/index.html"));
                }
            }
        });

        // 5. Attach WebChromeClient with Camera Permission Handler for QR Scanner
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                // Automatically grant camera resource for html5-qrcode scanner
                runOnUiThread(() -> {
                    for (String resource : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) {
                            request.grant(request.getResources());
                            return;
                        }
                    }
                    request.grant(request.getResources());
                });
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                              FileChooserParams fileChooserParams) {
                MainActivity.this.filePathCallback = filePathCallback;
                Intent intent = fileChooserParams.createIntent();
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST_CODE);
                } catch (ActivityNotFoundException e) {
                    MainActivity.this.filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Cannot open file chooser", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        // 6. Load the Application (Opens directly to home page)
        webView.loadUrl("https://appassets.androidplatform.net/web/index.html");
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebSettings() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
    }

    private WebResourceResponse loadAssetDirectly(String relativePath) {
        try {
            AssetManager assets = getAssets();
            InputStream stream = null;
            
            // Try in web/ subdirectory first
            try {
                stream = assets.open("web/" + relativePath);
            } catch (Exception e1) {
                // Try in root of assets
                try {
                    stream = assets.open(relativePath);
                } catch (Exception ignored) {}
            }

            if (stream != null) {
                String mimeType = getMimeType(relativePath);
                Map<String, String> headers = new HashMap<>();
                headers.put("Access-Control-Allow-Origin", "*");
                headers.put("Cache-Control", "no-cache");
                return new WebResourceResponse(mimeType, "UTF-8", 200, "OK", headers, stream);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error loading asset directly: " + relativePath, e);
        }
        return null;
    }

    private String getMimeType(String path) {
        String lower = path.toLowerCase();
        if (lower.endsWith(".html") || lower.endsWith(".htm")) return "text/html";
        if (lower.endsWith(".css")) return "text/css";
        if (lower.endsWith(".js")) return "application/javascript";
        if (lower.endsWith(".json")) return "application/json";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        if (lower.endsWith(".ico")) return "image/x-icon";
        return "application/octet-stream";
    }

    private void requestCameraPermissionIfNeeded() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.i(TAG, "Camera permission granted for QR scanner");
            } else {
                Toast.makeText(this, "Camera permission is needed to scan Tiffin QR codes", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (filePathCallback != null) {
                Uri[] results = null;
                if (resultCode == RESULT_OK && data != null) {
                    if (data.getData() != null) {
                        results = new Uri[]{data.getData()};
                    } else if (data.getClipData() != null) {
                        int count = data.getClipData().getItemCount();
                        results = new Uri[count];
                        for (int i = 0; i < count; i++) {
                            results[i] = data.getClipData().getItemAt(i).getUri();
                        }
                    }
                }
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
