package com.weldmaster.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.File;
import java.io.IOException;

public class PdfViewerActivity extends Activity {
    private PdfRenderer renderer;
    private PdfRenderer.Page page;
    private ImageView image;
    private TextView counter;
    private int pageIndex = 0;
    private int bg = Color.rgb(8, 9, 18);
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(Color.BLACK);
        String path = getIntent().getStringExtra("pdf_path");
        String title = getIntent().getStringExtra("pdf_title");
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg);
        TextView heading = new TextView(this); heading.setText("‹    " + (title == null ? "Справочник" : title));
        heading.setTextColor(Color.WHITE); heading.setTextSize(17); heading.setPadding(18,18,18,18);
        heading.setOnClickListener(v -> finish()); root.addView(heading);
        image = new ImageView(this); image.setBackgroundColor(Color.rgb(28,29,42)); image.setAdjustViewBounds(true); image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(-1,0,1); imageParams.setMargins(8,4,8,4); root.addView(image,imageParams);
        LinearLayout controls = new LinearLayout(this); controls.setGravity(Gravity.CENTER); controls.setPadding(10,10,10,18);
        Button prev = new Button(this); prev.setText("← Назад"); prev.setOnClickListener(v -> showPage(pageIndex-1));
        counter = new TextView(this); counter.setTextColor(Color.WHITE); counter.setTextSize(14); counter.setGravity(Gravity.CENTER); counter.setPadding(18,0,18,0);
        Button next = new Button(this); next.setText("Далее →"); next.setOnClickListener(v -> showPage(pageIndex+1));
        controls.addView(prev); controls.addView(counter); controls.addView(next); root.addView(controls);
        setContentView(root);
        try { ParcelFileDescriptor fd = ParcelFileDescriptor.open(new File(path), ParcelFileDescriptor.MODE_READ_ONLY); renderer = new PdfRenderer(fd); showPage(0); }
        catch (Exception e) { counter.setText("Не удалось открыть PDF"); }
    }
    private void showPage(int index) {
        if (renderer == null || index < 0 || index >= renderer.getPageCount()) return;
        if (page != null) page.close(); pageIndex = index; page = renderer.openPage(index);
        int width = Math.min(page.getWidth() * 2, 1800);
        int height = (int)((float)width * page.getHeight() / page.getWidth());
        Bitmap bitmap = Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);
        bitmap.eraseColor(Color.WHITE); page.render(bitmap,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
        image.setImageBitmap(bitmap); counter.setText((pageIndex+1)+" / "+renderer.getPageCount());
    }
    @Override protected void onDestroy() { if(page!=null)page.close(); if(renderer!=null)renderer.close(); super.onDestroy(); }
}
