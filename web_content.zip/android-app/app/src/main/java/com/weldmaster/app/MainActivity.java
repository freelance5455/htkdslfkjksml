package com.weldmaster.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.view.Window;
import android.view.WindowManager;
import android.graphics.Color;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(5, 5, 10));
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new PdfBridge(), "WeldMasterBridge");
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/www/index.html");
    }
    private class PdfBridge {
        @JavascriptInterface public void openPdf(String filename) {
            if (!"posobie-svarshika.pdf".equals(filename) &&
                !"12_mehanizirovannaya_dugovaya_svarka.pdf".equals(filename)) return;
            try {
                File out = new File(getCacheDir(), filename);
                try (InputStream in = getAssets().open("www/" + filename);
                     FileOutputStream fos = new FileOutputStream(out)) {
                    byte[] buffer = new byte[8192]; int count;
                    while ((count = in.read(buffer)) > 0) fos.write(buffer, 0, count);
                }
                Intent intent = new Intent(MainActivity.this, PdfViewerActivity.class);
                intent.putExtra("pdf_path", out.getAbsolutePath());
                intent.putExtra("pdf_title", filename.startsWith("posobie") ? "Пособие сварщика" : "Механизированная дуговая сварка");
                startActivity(intent);
            } catch (Exception ex) { ex.printStackTrace(); }
        }
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
