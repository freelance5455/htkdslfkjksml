package com.vaishnavworld.app;
import android.app.Activity;import android.content.*;import android.net.Uri;import android.os.Build;import android.provider.Settings;import android.webkit.JavascriptInterface;
public class OverlayBridge {private final Activity a; public OverlayBridge(Activity a){this.a=a;}
 @JavascriptInterface public void start(){a.runOnUiThread(()->{if(Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(a)){Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+a.getPackageName()));a.startActivity(i);return;}if(Build.VERSION.SDK_INT>=26)a.startForegroundService(new Intent(a,FloatingCounterService.class));else a.startService(new Intent(a,FloatingCounterService.class));});}
 @JavascriptInterface public void stop(){a.runOnUiThread(()->a.stopService(new Intent(a,FloatingCounterService.class)));}
 @JavascriptInterface public boolean available(){return Build.VERSION.SDK_INT<23||Settings.canDrawOverlays(a);}
 @JavascriptInterface public void update(String label){FloatingCounterService.updateLabel(label);}
}
