package com.vaishnavworld.app;
import android.app.*;import android.content.*;import android.graphics.Color;import android.graphics.PixelFormat;import android.graphics.Typeface;import android.os.Build;import android.os.IBinder;import android.view.*;import android.widget.TextView;

public class FloatingCounterService extends Service {
  static FloatingCounterService instance; private WindowManager wm; private TextView bubble; private WindowManager.LayoutParams params; private int beads=0;
  @Override public void onCreate(){super.onCreate();instance=this;showNotification();wm=(WindowManager)getSystemService(WINDOW_SERVICE);bubble=new TextView(this);bubble.setText("📿 Japa +1");bubble.setTextColor(Color.WHITE);bubble.setTextSize(14);bubble.setTypeface(null,Typeface.BOLD);bubble.setGravity(Gravity.CENTER);bubble.setPadding(22,16,22,16);bubble.setBackgroundColor(Color.rgb(74,45,115));
    int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
    params=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);params.gravity=Gravity.TOP|Gravity.END;params.x=18;params.y=180;
    bubble.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int ox,oy;boolean moved;public boolean onTouch(View v,android.view.MotionEvent e){switch(e.getAction()){case MotionEvent.ACTION_DOWN:sx=e.getRawX();sy=e.getRawY();ox=params.x;oy=params.y;moved=false;return true;case MotionEvent.ACTION_MOVE:float dx=sx-e.getRawX(),dy=e.getRawY()-sy;if(Math.abs(dx)>8||Math.abs(dy)>8)moved=true;params.x=Math.max(0,ox+(int)dx);params.y=Math.max(0,oy+(int)dy);wm.updateViewLayout(bubble,params);return true;case MotionEvent.ACTION_UP:if(!moved&&MainActivity.instance!=null){MainActivity.instance.runOnUiThread(()->MainActivity.instance.countFloatingBead());}return true;}return true;}});
    wm.addView(bubble,params);
  }
  private void showNotification(){String channel="japa_floating";if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(channel,"Floating Japa Counter",NotificationManager.IMPORTANCE_LOW);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}Notification n;if(Build.VERSION.SDK_INT>=26)n=new Notification.Builder(this,channel).setContentTitle("Vaishnav World · Japa Counter").setContentText("Floating Japa counter is active").setSmallIcon(android.R.drawable.ic_menu_compass).setOngoing(true).build();else n=new Notification.Builder(this).setContentTitle("Vaishnav World · Japa Counter").setContentText("Floating Japa counter is active").setSmallIcon(android.R.drawable.ic_menu_compass).setOngoing(true).build();startForeground(4108,n);}
  public static void updateLabel(String label){if(instance!=null&&instance.bubble!=null)instance.bubble.post(()->instance.bubble.setText(label));}
  @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
  @Override public void onDestroy(){if(bubble!=null)try{wm.removeView(bubble);}catch(Exception ignored){}instance=null;super.onDestroy();}
  @Override public IBinder onBind(Intent i){return null;}
}
