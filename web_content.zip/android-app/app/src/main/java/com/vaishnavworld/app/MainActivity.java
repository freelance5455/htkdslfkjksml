package com.vaishnavworld.app;
import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.annotation.Nullable;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends Activity {
    public static MainActivity instance;
    WebView w;
    @Override public void onCreate(@Nullable Bundle b) {
        super.onCreate(b); instance=this;
        try { if (FirebaseApp.getApps(this).isEmpty()) FirebaseApp.initializeApp(this); } catch(Exception e) { e.printStackTrace(); }
        w=new WebView(this);
        w.setWebViewClient(new WebViewClient());
        WebSettings s=w.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        w.addJavascriptInterface(new FcmBridge(this),"AndroidFCM");
        w.addJavascriptInterface(new OverlayBridge(this),"AndroidOverlay");
        w.loadUrl("file:///android_asset/web/index.html");
        setContentView(w);
        if(android.os.Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},1001);
        try { FirebaseMessaging.getInstance().getToken().addOnSuccessListener(this::saveToken); } catch(Exception e) { e.printStackTrace(); }
    }
    public void countFloatingBead(){ if(w!=null) w.evaluateJavascript("window.handleFloatingJapaTap && window.handleFloatingJapaTap()",null); }
    @Override protected void onDestroy(){ if(FloatingCounterService.instance!=null){} instance=null; super.onDestroy(); }
    private void saveToken(String t) {
        try {
            getSharedPreferences("push",0).edit().putString("token",t).apply();
            java.util.HashMap<String,Object> x=new java.util.HashMap<>();
            x.put("token",t); x.put("updatedAt",System.currentTimeMillis());
            FirebaseDatabase.getInstance().getReference("fcmTokens").child(android.net.Uri.encode(t)).setValue(x);
        } catch(Exception e) { e.printStackTrace(); }
    }
}
