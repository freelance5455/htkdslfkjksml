package com.vaishnavworld.app;
import android.content.Context;import android.webkit.JavascriptInterface;
public class FcmBridge{private final Context c;public FcmBridge(Context c){this.c=c;}@JavascriptInterface public String getToken(){return c.getSharedPreferences("push",0).getString("token","");}}