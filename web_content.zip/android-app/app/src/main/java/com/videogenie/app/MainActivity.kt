package com.videogenie.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("videogenie", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        val saved = prefs.getString("server", "") ?: ""
        if (saved.isBlank()) showServerDialog() else connect(saved)
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(246, 245, 251))
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(14, 10, 14, 10)
            setBackgroundColor(Color.rgb(35, 34, 70))
        }
        val title = TextView(this).apply {
            text = "VideoGenie"
            textSize = 19f
            setTextColor(Color.WHITE)
        }
        val change = Button(this).apply {
            text = "Server"
            setOnClickListener { showServerDialog() }
        }
        bar.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(change)
        status = TextView(this).apply {
            text = "Connect to your VideoGenie backend"
            setPadding(14, 8, 14, 8)
            setTextColor(Color.DKGRAY)
            textSize = 12f
        }
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.allowFileAccess = false
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                status.text = "Connected: ${prefs.getString("server", "")}" 
            }
            override fun onReceivedError(view: WebView?, request: android.webkit.WebResourceRequest?, error: android.webkit.WebResourceError?) {
                if (request?.isForMainFrame == true) status.text = "Cannot connect. Check backend and Wi-Fi, then tap Server."
            }
        }
        web.webChromeClient = WebChromeClient()
        web.setDownloadListener(DownloadListener { url, _, contentDisposition, mimeType, _ ->
            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                setDataAndType(android.net.Uri.parse(url), mimeType ?: "application/octet-stream")
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try { startActivity(intent) } catch (_: Exception) {
                Toast.makeText(this, "No app available to open this download", Toast.LENGTH_LONG).show()
            }
        })
        CookieManager.getInstance().setAcceptCookie(true)
        root.addView(bar)
        root.addView(status)
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun showServerDialog() {
        val input = EditText(this).apply {
            hint = "http://192.168.1.10:5000"
            setSingleLine(true)
            setText(prefs.getString("server", ""))
            setPadding(24, 18, 24, 18)
        }
        AlertDialog.Builder(this)
            .setTitle("Connect VideoGenie backend")
            .setMessage("Start the backend on your computer or phone first. Enter its address (same Wi-Fi for a computer backend).")
            .setView(input)
            .setPositiveButton("Connect") { _, _ ->
                var url = input.text.toString().trim().trimEnd('/')
                if (url.isNotBlank() && !url.startsWith("http://") && !url.startsWith("https://")) url = "http://$url"
                if (!url.matches(Regex("^https?://[^\\s]+$"))) {
                    Toast.makeText(this, "Enter a valid server URL", Toast.LENGTH_LONG).show()
                } else {
                    prefs.edit().putString("server", url).apply()
                    connect(url)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun connect(url: String) {
        status.text = "Connecting to $url …"
        web.loadUrl(url)
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }
}
