package com.mhmiraz.ai;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
public class StopBubbleReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context context, Intent intent) { context.stopService(new Intent(context, BubbleService.class)); }
}
