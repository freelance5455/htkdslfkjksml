package com.mhmiraz.ai;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.webkit.PermissionRequest;
import android.speech.tts.TextToSpeech;
import android.speech.RecognizerIntent;
import android.Manifest;
import android.content.pm.PackageManager;
import java.util.Locale;
import java.util.ArrayList;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private PermissionRequest pendingMediaPermissionRequest;
    private TextToSpeech tts;
    private static final int FILE_CHOOSER_REQUEST = 7101;
    private static final int VOICE_REQUEST = 7102;
    private static final int AUDIO_PERMISSION_REQUEST = 7103;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(7,16,31));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(7,16,31));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                // Use Android's document picker explicitly; it is more reliable on Android 13-15
                // than the generic WebView intent, and supports Photos, Downloads and cloud providers.
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                String[] accepts = params.getAcceptTypes();
                String mime = "*/*";
                if (accepts != null && accepts.length > 0) {
                    java.util.ArrayList<String> valid = new java.util.ArrayList<>();
                    for (String a : accepts) {
                        if (a == null) continue;
                        a = a.trim();
                        if (a.contains("/")) valid.add(a);
                        else if (a.startsWith(".")) {
                            String ext = a.toLowerCase(java.util.Locale.ROOT);
                            if (ext.matches("\\.(jpg|jpeg|png|webp|gif|bmp)")) valid.add("image/*");
                            else if (ext.equals(".pdf")) valid.add("application/pdf");
                            else if (ext.matches("\\.(txt|md|csv|json|html|xml|log)")) valid.add("text/*");
                        }
                    }
                    if (valid.size() == 1) mime = valid.get(0);
                }
                intent.setType(mime);
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (Exception firstError) {
                    try { startActivityForResult(params.createIntent(), FILE_CHOOSER_REQUEST); }
                    catch (Exception e) { filePathCallback = null; callback.onReceiveValue(null); Toast.makeText(MainActivity.this, "ফাইল বাছাই করা যায়নি। Files/Photos অনুমতি ও অ্যাপ আপডেট পরীক্ষা করুন।", Toast.LENGTH_LONG).show(); return false; }
                }
                return true;
            }
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean wantsAudio = false;
                    for (String resource : request.getResources()) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) wantsAudio = true;
                    }
                    if (wantsAudio && Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        pendingMediaPermissionRequest = request;
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, AUDIO_PERMISSION_REQUEST);
                    } else request.grant(request.getResources());
                });
            }
        });
        tts = new TextToSpeech(this, status -> { if (status == TextToSpeech.SUCCESS) { int result = tts.setLanguage(new Locale("bn", "BD")); if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(new Locale("bn", "IN")); } });
        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }
    private class Bridge {
        private static final String PREFS = "mh_miraz_secure_store";
        private static final String ALIAS = "mh_miraz_ai_key_v1";
        @JavascriptInterface public boolean setSecureValue(String name, String value) {
            try {
                SecretKey key = getOrCreateKey();
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.ENCRYPT_MODE, key);
                byte[] iv = cipher.getIV();
                byte[] encrypted = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
                String packed = Base64.encodeToString(iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(encrypted, Base64.NO_WRAP);
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(name, packed).apply();
                return true;
            } catch (Exception e) { return false; }
        }
        @JavascriptInterface public String getSecureValue(String name) {
            try {
                String packed = getSharedPreferences(PREFS, MODE_PRIVATE).getString(name, "");
                if (packed.isEmpty()) return "";
                String[] parts = packed.split(":", 2);
                byte[] iv = Base64.decode(parts[0], Base64.NO_WRAP);
                byte[] encrypted = Base64.decode(parts[1], Base64.NO_WRAP);
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(128, iv));
                return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
            } catch (Exception e) { return ""; }
        }
        @JavascriptInterface public boolean deleteSecureValue(String name) {
            return getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(name).commit();
        }
        private SecretKey getOrCreateKey() throws Exception {
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
            if (ks.containsAlias(ALIAS)) return (SecretKey) ks.getKey(ALIAS, null);
            KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            generator.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build());
            return generator.generateKey();
        }
        @JavascriptInterface public void startVoiceInput() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, AUDIO_PERMISSION_REQUEST);
                    Toast.makeText(MainActivity.this, "মাইক্রোফোন অনুমতি দিন, তারপর আবার 🎙 চাপুন", Toast.LENGTH_LONG).show();
                    return;
                }
                try {
                    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD");
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD");
                    intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "বাংলায় কথা বলুন");
                    startActivityForResult(intent, VOICE_REQUEST);
                } catch (Exception e) {
                    webView.evaluateJavascript("setVoiceStatus('এই ফোনে speech recognition পরিষেবা পাওয়া যায়নি')", null);
                    Toast.makeText(MainActivity.this, "Google Speech Services ইনস্টল/চালু আছে কি না দেখুন", Toast.LENGTH_LONG).show();
                }
            });
        }
        @JavascriptInterface public void stopVoiceInput() { runOnUiThread(() -> { if (tts != null) tts.stop(); }); }
        @JavascriptInterface public void speakBengali(String text, float rate) {
            runOnUiThread(() -> {
                if (tts == null) return;
                tts.setSpeechRate(Math.max(0.65f, Math.min(1.25f, rate)));
                if (Build.VERSION.SDK_INT >= 21) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mh-miraz-voice");
                else tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
            });
        }
        @JavascriptInterface public void enableBubble() {
            runOnUiThread(() -> {
                if (!Settings.canDrawOverlays(MainActivity.this)) {
                    Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                    Toast.makeText(MainActivity.this, "MH MIRAZ AI-কে অন্য অ্যাপের ওপর দেখানোর অনুমতি দিন, তারপর অ্যাপে ফিরে আবার চালু করুন।", Toast.LENGTH_LONG).show();
                    return;
                }
                Intent service = new Intent(MainActivity.this, BubbleService.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service); else startService(service);
                Toast.makeText(MainActivity.this, "Floating Bubble চালু হয়েছে", Toast.LENGTH_SHORT).show();
            });
        }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback != null) {
                Uri[] results = null;
                if (resultCode == RESULT_OK && data != null) {
                    if (data.getClipData() != null) {
                        int count = data.getClipData().getItemCount(); results = new Uri[count];
                        for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                    } else if (data.getData() != null) results = new Uri[]{data.getData()};
                }
                filePathCallback.onReceiveValue(results); filePathCallback = null;
            }
        } else if (requestCode == VOICE_REQUEST) {
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (matches != null && !matches.isEmpty()) {
                    String value = org.json.JSONObject.quote(matches.get(0));
                    webView.evaluateJavascript("onNativeVoiceResult(" + value + ")", null);
                } else webView.evaluateJavascript("setVoiceStatus('কথা বোঝা যায়নি; আবার বলো')", null);
            } else webView.evaluateJavascript("setVoiceStatus('ভয়েস ইনপুট বন্ধ হয়েছে')", null);
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == AUDIO_PERMISSION_REQUEST) {
            if (pendingMediaPermissionRequest != null) {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) pendingMediaPermissionRequest.grant(pendingMediaPermissionRequest.getResources());
                else pendingMediaPermissionRequest.deny();
                pendingMediaPermissionRequest = null;
            }
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                Toast.makeText(this, "মাইক্রোফোন অনুমতি দেওয়া হয়েছে।", Toast.LENGTH_LONG).show();
        }
    }
    @Override protected void onDestroy() { if (pendingMediaPermissionRequest != null) { pendingMediaPermissionRequest.deny(); pendingMediaPermissionRequest = null; } if (tts != null) { tts.stop(); tts.shutdown(); } super.onDestroy(); }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
