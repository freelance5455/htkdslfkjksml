package com.mhmiraz.ai;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

public class BubbleService extends Service {
    private WindowManager wm;
    private View bubble;
    private WindowManager.LayoutParams params;
    private static final String CHANNEL = "mh_miraz_bubble";
    @Override public void onCreate() {
        super.onCreate(); createChannel();
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, StopBubbleReceiver.class); PendingIntent stopPi = PendingIntent.getBroadcast(this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        Notification notification = nb.setContentTitle("MH MIRAZ AI চলছে").setContentText("ভাসমান বাবল চালু আছে · বন্ধ করতে notification থেকে stop করুন").setSmallIcon(android.R.drawable.ic_dialog_info).setContentIntent(pi).addAction(android.R.drawable.ic_menu_close_clear_cancel, "বাবল বন্ধ", stopPi).build();
        startForeground(41, notification);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        TextView b = new TextView(this); b.setText("MH\n✦"); b.setTextColor(0xFFFFFFFF); b.setTextSize(13); b.setTypeface(Typeface.DEFAULT_BOLD); b.setGravity(Gravity.CENTER); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF126AA2));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable(); bg.setShape(android.graphics.drawable.GradientDrawable.OVAL); bg.setColor(0xFF126AA2); bg.setStroke(3, 0xFF80D7FF); b.setBackground(bg); bubble = b;
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(dp(62), dp(62), type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START; params.x = dp(12); params.y = dp(220);
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startX, startY; boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch(e.getAction()) {
                    case MotionEvent.ACTION_DOWN: downX=e.getRawX(); downY=e.getRawY(); startX=params.x; startY=params.y; moved=false; return true;
                    case MotionEvent.ACTION_MOVE: int dx=(int)(e.getRawX()-downX), dy=(int)(e.getRawY()-downY); if(Math.abs(dx)>5||Math.abs(dy)>5)moved=true; params.x=startX+dx; params.y=startY+dy; try{wm.updateViewLayout(bubble,params);}catch(Exception ignored){} return true;
                    case MotionEvent.ACTION_UP: if(!moved){Intent launch=new Intent(BubbleService.this,MainActivity.class); launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP); startActivity(launch);} return true;
                } return true;
            }
        });
        wm.addView(bubble, params);
    }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density);}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"MH MIRAZ AI Bubble",NotificationManager.IMPORTANCE_LOW);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    @Override public int onStartCommand(Intent intent,int flags,int startId){return START_STICKY;}
    @Override public void onDestroy(){if(wm!=null&&bubble!=null){try{wm.removeView(bubble);}catch(Exception ignored){}}super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
