
package com.saher.schedule;

import android.app.*;
import android.content.*;
import android.os.*;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String title=intent.getStringExtra("title");
        String body=intent.getStringExtra("body");

        String channel="saher_schedule";
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26)
            b=new Notification.Builder(context, channel);
        else
            b=new Notification.Builder(context);

        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(
            context, 7001, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        String t = title == null ? "⏰ جدول ساهر" : title;
        String msg = body == null ? "لديك موعد قريب." : body;

        b.setSmallIcon(android.R.drawable.ic_popup_reminder)
         .setContentTitle(t)
         .setContentText(msg)
         .setStyle(new Notification.BigTextStyle().bigText(msg))
         .setContentIntent(openPi)
         .setAutoCancel(true)
         .setCategory(Notification.CATEGORY_REMINDER)
         .setPriority(Notification.PRIORITY_HIGH)
         .setDefaults(Notification.DEFAULT_ALL);

        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify((int)(System.currentTimeMillis() & 0x7fffffff), b.build());
    }
}
