
package com.saher.schedule;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.os.*;
import android.provider.Settings;
import android.net.Uri;
import android.webkit.*;
import android.view.*;
import java.util.*;

public class MainActivity extends Activity {
    public static final String CHANNEL_ID = "saher_schedule";
    private WebView web;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        createChannel();

        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new AndroidBridge(this), "AndroidNotifications");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);

        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);

        if (Build.VERSION.SDK_INT >= 31) {
            try {
                AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
                if (!am.canScheduleExactAlarms()) {
                    Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                    i.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                }
            } catch(Exception ignored) {}
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                CHANNEL_ID, "مواعيد جدول ساهر", NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("تذكير بالمواعيد قبلها بخمس دقائق");
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(c);
        }
    }

    public static class AndroidBridge {
        private final Context c;
        AndroidBridge(Context c){this.c=c;}

        @JavascriptInterface
        public void scheduleReminder(long triggerAt, int id, String title, String body) {
            Intent i = new Intent(c, ReminderReceiver.class);
            i.putExtra("title", title);
            i.putExtra("body", body);
            PendingIntent pi = PendingIntent.getBroadcast(
                c, id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) return;
            if (Build.VERSION.SDK_INT >= 23)
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            else
                am.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        }

        @JavascriptInterface
        public void cancelReminder(int id) {
            Intent i = new Intent(c, ReminderReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(
                c, id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
            am.cancel(pi);
        }
    }
}
