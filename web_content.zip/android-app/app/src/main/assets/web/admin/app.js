
const firebaseConfig = {
  apiKey: "AIzaSyD9f8E3eZuaUVXNOiycBsxqiw4bgW_McZg",
  authDomain: "hare-krishna-94342.firebaseapp.com",
  databaseURL: "https://hare-krishna-94342-default-rtdb.firebaseio.com",
  projectId: "hare-krishna-94342",
  storageBucket: "hare-krishna-94342.firebasestorage.app",
  messagingSenderId: "648445902152",
  appId: "1:648445902152:web:f1ef523abb197031f4c77d",
  measurementId: "G-2VWQXRJ3B4"
};

let db=null;
const $=id=>document.getElementById(id), main=$("main");
function initFirebase(){
  if(db) return true;
  try{
    if(!window.firebase) throw new Error("Firebase SDK did not load.");
    const app=window.firebase.apps.length?window.firebase.app():window.firebase.initializeApp(firebaseConfig);
    db=window.firebase.database(app);
    return true;
  }catch(e){ console.error(e); toast("Firebase connection could not start."); return false; }
}
const ref=(path)=>db.ref(String(path));
const get=(r)=>r.once("value");
const set=(r,v)=>r.set(v);
const push=(r)=>r.push();
const update=(r,v)=>r.update(v);
const remove=(r)=>r.remove();
const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));
const today=()=>new Date().toISOString().slice(0,10);
function toast(t){const x=$("toast");x.textContent=t;x.style.display="block";clearTimeout(window.__toast);window.__toast=setTimeout(()=>x.style.display="none",2600)}
async function pushSave(path,data){const r=push(ref(db,path));await set(r,{...data,createdAt:Date.now()});return r.key}
async function notify(title,text,target="all",extra={}){
  const id=await pushSave("notifications",{title,text,target,...extra});
  try{await pushSave("pushQueue",{title,text,type:target,notificationId:id,status:"queued",route:target,createdAt:Date.now()})}catch(e){console.warn("pushQueue",e)}
  return id;
}
function page(title,subtitle="",body=""){main.innerHTML=`<div class="title"><div><h2>${title}</h2>${subtitle?`<p>${subtitle}</p>`:""}</div></div>${body}`}
function countOnce(path,id){if(!db){$(id).textContent="—";return}get(ref(db,path)).then(s=>$(id).textContent=s.exists()?Object.keys(s.val()||{}).length:0).catch(()=>$(id).textContent="—")}
function fileToDataURL(file,maxW=1200,quality=.78){
 return new Promise((resolve,reject)=>{
  if(!file)return resolve("");
  const fr=new FileReader();fr.onerror=reject;
  fr.onload=()=>{const im=new Image();im.onload=()=>{
   const scale=Math.min(1,maxW/im.width), c=document.createElement("canvas");
   c.width=Math.max(1,Math.round(im.width*scale));c.height=Math.max(1,Math.round(im.height*scale));
   c.getContext("2d").drawImage(im,0,0,c.width,c.height);
   resolve(c.toDataURL("image/jpeg",quality));
  };im.onerror=reject;im.src=fr.result};fr.readAsDataURL(file);
 });
}
async function uploadImage(input, maxBytes=950000){
 const f=input?.files?.[0]; if(!f)return "";
 if(!f.type.startsWith("image/"))throw Error("Please select an image.");
 let q=.78,url="";
 for(let i=0;i<5;i++){url=await fileToDataURL(f,1200,q);if(url.length<=maxBytes)break;q-=.1}
 if(url.length>maxBytes)throw Error("Image is still too large. Choose a smaller image.");
 return url;
}
function imageField(id,label="Image"){return `<label>${label}<input id="${id}" type="file" accept="image/*"></label>`}
function safeVal(v){return esc(v||"")}
async function listItems(path,container,opts={}){
 const s=await get(ref(db,path));const v=s.val()||{};
 const entries=Object.entries(v).sort((a,b)=>(b[1]?.createdAt||0)-(a[1]?.createdAt||0));
 const search=opts.searchId?($(opts.searchId)?.value||"").toLowerCase():"";
 const filtered=entries.filter(([id,x])=>!search||JSON.stringify(x).toLowerCase().includes(search));
 $(container).innerHTML=filtered.map(([id,x])=>{
   const title=x.title||x.name||x.question||x.text?.slice(0,70)||id;
   return `<div class="card item"><div><b>${esc(title)}</b><div class="small muted">${esc(id)}</div></div>
   <div class="actions"><button class="secondary" data-edit-path="${esc(path)}" data-edit-id="${esc(id)}">Edit</button>
   <button class="danger" data-del-path="${esc(path)}" data-del-id="${esc(id)}">Delete</button></div></div>`
 }).join("")||`<div class="card empty">No items found.</div>`;
 document.querySelectorAll("[data-del-path]").forEach(b=>b.onclick=async()=>{if(!confirm("Delete this item?"))return;await remove(ref(db,`${b.dataset.delPath}/${b.dataset.delId}`));toast("Deleted");await listItems(path,container,opts)});
}
function wireDeleteOnly(path,container){document.querySelectorAll("[data-del-path]").forEach(b=>b.onclick=async()=>{if(!confirm("Delete this item?"))return;await remove(ref(db,`${b.dataset.delPath}/${b.dataset.delId}`));toast("Deleted");await listItems(path,container)})}

function dashboard(){
 page("Dashboard","Complete control of the shared Devotee app.",`
 <div class="grid">
 <div class="card stat">Devotees<strong id="cUsers">—</strong></div>
 <div class="card stat">Daily Darshan<strong id="cDarshan">—</strong></div>
 <div class="card stat">Shlokas<strong id="cShloka">—</strong></div>
 <div class="card stat">Gita<strong id="cGita">—</strong></div>
 <div class="card stat">Quiz Results<strong id="cQuiz">—</strong></div>
 <div class="card stat">Courses<strong id="cCourses">—</strong></div>
 <div class="card stat">Challenges<strong id="cChallenges">—</strong></div>
 <div class="card stat">Notifications<strong id="cNoti">—</strong></div>
 </div>
 <div class="card section"><h3>Monthly Leaderboard</h3><p class="muted">All XP points earned this month, combined across quiz, japa, shlok, courses and challenges.</p><div id="adminMonthlyLb"></div></div><div class="card section"><h3>Admin publishing</h3><p class="muted">Anything you publish here is written to the same Firebase Realtime Database used by the Devotee app. Push delivery uses the pushQueue path when the Cloud Function/native FCM setup is connected.</p>
 <div class="actions"><button class="primary" data-go="darshan">Upload Daily Darshan</button><button class="secondary" data-go="quiz">Create Quiz</button><button class="secondary" data-go="notifications">Send Notification</button></div></div>`);
 [["users","cUsers"],["dailyDarshan","cDarshan"],["shlokaReading","cShloka"],["gita","cGita"],["quiz/results","cQuiz"],["courses","cCourses"],["challenges","cChallenges"],["notifications","cNoti"]].forEach(x=>countOnce(...x));
 const month=today().slice(0,7);get(ref(db,`monthlyLeaderboard/${month}`)).then(s=>{const rows=Object.values(s.val()||{}).sort((a,b)=>Number(b.points||0)-Number(a.points||0));$("adminMonthlyLb").innerHTML=rows.map((x,i)=>`<div class="card item"><b>#${i+1} · ${esc(x.name||"Devotee")}</b><small>${esc(x.relation||"")} · ${Number(x.points||0)} points</small></div>`).join("")||'<p class="muted">No points yet.</p>'}).catch(()=>{});
 document.querySelectorAll("[data-go]").forEach(b=>b.onclick=()=>pages[b.dataset.go]());
}


async function members(){page("Family Members","View main devotees and the members added under each account.",`<div class="card"><input class="search" id="memSearch" placeholder="Search name, relation or mobile"></div><div id="memList" class="section"></div>`);const users=(await get(ref(db,"users"))).val()||{};const rows=[];Object.entries(users).forEach(([uid,u])=>Object.values(u.members||{}).forEach(m=>rows.push({uid,owner:u.name||uid,member:m})));const render=()=>{const q=($('memSearch').value||'').toLowerCase();$('memList').innerHTML=rows.filter(r=>(r.owner+' '+r.member.name+' '+r.member.relation+' '+(r.member.mobile||'')).toLowerCase().includes(q)).map(r=>`<div class="card item"><b>${esc(r.member.name||'Member')}</b><small>${esc(r.member.relation||'')} · Owner: ${esc(r.owner)}</small><small>UID: ${esc(r.uid)}</small><small>Mobile: ${esc(r.member.mobile||'—')}</small></div>`).join('')||'<div class="card empty">No members found.</div>'};render();$('memSearch').oninput=render}

async function devotees(){
 page("Devotees","View registered profiles, search, inspect details and send an individual notification.",`<div class="card"><input class="search" id="devSearch" placeholder="Search name or mobile"></div><div id="devList" class="section"></div>`);
 const s=await get(ref(db,"users"));const v=s.val()||{};const render=()=>{
  const q=($("devSearch")?.value||"").toLowerCase();
  const rows=Object.entries(v).filter(([uid,u])=>!q||String(u.name||"").toLowerCase().includes(q)||String(u.mobile||"").includes(q)).map(([uid,u])=>`
  <tr><td><b>${esc(u.name||"—")}</b><div class="small">${esc(u.dob||"")} · ${esc(u.gender||"")}</div></td>
  <td>${esc(u.mobile||"—")}</td><td>${esc(uid)}</td><td><button class="secondary" data-user="${esc(uid)}">View</button></td></tr>`).join("");
  $("devList").innerHTML=`<div class="table-wrap"><table class="table"><tr><th>Devotee</th><th>Mobile</th><th>UID</th><th></th></tr>${rows||'<tr><td colspan="4" class="empty">No devotees found</td></tr>'}</table></div>`;
  document.querySelectorAll("[data-user]").forEach(b=>b.onclick=()=>{const u=v[b.dataset.user]||{};alert(`Name: ${u.name||"—"}\nMobile: ${u.mobile||"—"}\nDOB: ${u.dob||"—"}\nGender: ${u.gender||"—"}\nUID: ${b.dataset.user}`)})
 };
 render();$("devSearch").oninput=render;
}

async function darshan(){
 page("Daily Darshan","Publish or replace the daily Darshan. Image upload is available only here.",`
 <div class="card"><div class="form">
 <div class="row"><label>Date<input id="dDate" type="date" value="${today()}"></label><input id="dTitle" placeholder="Darshan title"></div>
 <textarea id="dText" placeholder="Caption / description"></textarea>
 <label>Daily Darshan Image (optional)<input id="dImage" type="file" accept="image/*"></label>
 <button class="primary" id="dSave">Publish / Replace Daily Darshan</button></div></div><div id="dList" class="section"></div>`);
 $("dSave").onclick=async()=>{try{
  const date=$("dDate").value||today(), old=(await get(ref(db,`dailyDarshan/${date}`))).val()||{};
  const image=await uploadImage($("dImage"),950000);
  const x={...old,date,title:$("dTitle").value.trim(),text:$("dText").value.trim(),updatedAt:Date.now(),likeCount:Number(old.likeCount||0),likes:old.likes||{}};
  if(image)x.imageUrl=image;
  await set(ref(db,`dailyDarshan/${date}`),x);
  try{await notify("Daily Darshan",`${x.title||"Today's Darshan"} is now available.`,"darshan",{date});}catch(e){console.warn("Darshan notification skipped",e);}
  toast("Daily Darshan published");loadSimpleList("dailyDarshan","dList")
 }catch(e){toast(e?.message||"Could not publish Daily Darshan.")}};
 loadSimpleList("dailyDarshan","dList");
}

async function loadSimpleList(path,id){
 const s=await get(ref(db,path)),v=s.val()||{};const rows=Object.entries(v).sort((a,b)=>b[0].localeCompare(a[0])).map(([k,x])=>`
 <div class="card item"><div><b>${esc(x.title||x.name||k)}</b><div class="small muted">${esc(k)} · ${x.imageUrl?"Image ✓":"No image"}</div></div>
 <button class="danger" data-remove="${esc(path+"/"+k)}">Delete</button></div>`).join("");
 $(id).innerHTML=rows||`<div class="card empty">No content yet.</div>`;
 document.querySelectorAll("[data-remove]").forEach(b=>b.onclick=async()=>{if(confirm("Delete this item?")){await remove(ref(db,b.dataset.remove));toast("Deleted");loadSimpleList(path,id)}})
}

async function shloka(){
 page("Shloka Reading Challenge","Admin publishes the daily shlok, meaning and optional image.",`
 <div class="card"><div class="form">
 <div class="row"><label>Date<input id="sDate" type="date" value="${today()}"></label><input id="sTitle" placeholder="Shloka title / chapter"></div>
 <textarea id="sSanskrit" placeholder="Sanskrit shloka"></textarea><textarea id="sHindi" placeholder="Hindi meaning"></textarea><textarea id="sBengali" placeholder="Bengali meaning"></textarea><textarea id="sEnglish" placeholder="English meaning"></textarea>
<button class="primary" id="sSave">Publish Daily Shloka</button></div></div><div id="sList" class="section"></div>`);
 $("sSave").onclick=async()=>{try{const d=$("sDate").value||today(),old=(await get(ref(db,`shlokaReading/${d}`))).val()||{}; const x={...old,date:d,title:$("sTitle").value.trim(),sanskrit:$("sSanskrit").value.trim(),hindi:$("sHindi").value.trim(),bengali:$("sBengali").value.trim(),english:$("sEnglish").value.trim(),publishedAt:Date.now()};await set(ref(db,`shlokaReading/${d}`),x);await notify("New Shloka",`Today's shloka is ready.`,"shloka",{date:d});toast("Shloka published");loadSimpleList("shlokaReading","sList")}catch(e){toast(e.message)}};
 loadSimpleList("shlokaReading","sList");
}

async function gita(){
 page("Bhagavad Gita","Publish Gita chapter/verse learning content with Hindi and Bengali meanings.",`
 <div class="card"><div class="form">
 <div class="row"><input id="gChapter" type="number" min="1" placeholder="Chapter"><input id="gVerse" placeholder="Verse"></div>
 <input id="gTitle" placeholder="Verse title"><textarea id="gSanskrit" placeholder="Sanskrit verse"></textarea>
 <textarea id="gHindi" placeholder="Hindi meaning / explanation"></textarea><textarea id="gBengali" placeholder="Bengali meaning / explanation"></textarea>
<button class="primary" id="gSave">Publish Gita Verse</button></div></div><div id="gList" class="section"></div>`);
 $("gSave").onclick=async()=>{try{const id=`${$("gChapter").value||0}_${$("gVerse").value.trim()||Date.now()}`;const x={chapter:Number($("gChapter").value||0),verse:$("gVerse").value.trim(),title:$("gTitle").value.trim(),sanskrit:$("gSanskrit").value.trim(),hindi:$("gHindi").value.trim(),bengali:$("gBengali").value.trim(),publishedAt:Date.now()};await set(ref(db,`gita/${id}`),x);await notify("Bhagavad Gita",`New Gita verse published.`,"gita",{gitaId:id});toast("Gita verse published");loadSimpleList("gita","gList")}catch(e){toast(e.message)}};
 loadSimpleList("gita","gList");
}

const quizFields=["question","optionA","optionB","optionC","optionD","correct"];
function qCard(i,x={}){
 return `<div class="card qcard"><div class="question-top"><b>Question ${i}</b></div><input data-q="${i}" data-f="question" placeholder="Question" value="${safeVal(x.question)}">
 <div class="row"><input data-q="${i}" data-f="optionA" placeholder="Option A" value="${safeVal(x.optionA)}"><input data-q="${i}" data-f="optionB" placeholder="Option B" value="${safeVal(x.optionB)}"></div>
 <div class="row"><input data-q="${i}" data-f="optionC" placeholder="Option C" value="${safeVal(x.optionC)}"><input data-q="${i}" data-f="optionD" placeholder="Option D" value="${safeVal(x.optionD)}"></div>
 <select data-q="${i}" data-f="correct"><option value="">Correct option</option>${["A","B","C","D"].map(o=>`<option ${x.correct===o?"selected":""}>${o}</option>`).join("")}</select></div>`
}
async function quiz(){
 page("Quiz Manager","Create exactly 10 daily questions in Hindi or Bengali. Results store selected and correct answers.",`
 <div class="card"><div class="row"><label>Language<select id="qLang"><option value="hindi">Hindi</option><option value="bengali">Bengali</option></select></label><label>Date<input id="qDate" type="date" value="${today()}"></label>
 <button class="secondary" id="qLoad">Load existing</button></div></div><div id="qEditor"></div>
 <div class="card"><div class="actions"><button class="secondary" id="qDraft">Save Draft</button><button class="primary" id="qPublish">Publish 10 Questions</button></div></div>
 <div id="qHistory" class="section"></div>`);
 const render=arr=>{$("qEditor").innerHTML=Array.from({length:10},(_,i)=>qCard(i+1,arr?.[i]||{})).join("")};
 render([]);
 $("qLoad").onclick=async()=>{const d=$("qDate").value,l=$("qLang").value,s=await get(ref(db,`quiz/daily/${l}/${d}`)),v=s.val()||{};render(Array.from({length:10},(_,i)=>v[`Q${i+1}`]||{}));toast(s.exists()?"Loaded":"No quiz found")};
 const read=()=>{const a=[];for(let i=1;i<=10;i++){const x={};document.querySelectorAll(`[data-q="${i}"]`).forEach(e=>{x[e.dataset.f]=e.value.trim()});a.push(x)}return a};
 const save=async(publish)=>{try{const l=$("qLang").value,d=$("qDate").value,a=read();if(a.some(x=>!x.question||!x.optionA||!x.optionB||!x.optionC||!x.optionD||!x.correct))return toast("Complete all 10 questions.");const out={};for(let i=0;i<10;i++)out[`Q${i+1}`]={...a[i],questionNo:i+1};if(publish){await set(ref(db,`quiz/daily/${l}/${d}`),out);try{await notify("Daily Quiz",`${l==="hindi"?"Hindi":"Bengali"} quiz published for ${d}.`,"quiz",{date:d,language:l});}catch(e){console.warn("Quiz notification skipped",e);}toast("Quiz published")}else{await set(ref(db,`quiz/drafts/${l}/${d}`),out);toast("Draft saved")}}catch(e){toast(e?.message||"Could not save quiz.")}};
 $("qDraft").onclick=()=>save(false);$("qPublish").onclick=()=>save(true);
 loadSimpleList(`quiz/daily/${$("qLang").value}/${$("qDate").value}`,"qHistory").catch(()=>{});
}

async function quizresults(){
 page("Quiz Results & Leaderboard","Review daily results and combined leaderboard sorted by highest score.",`
 <div class="card"><div class="row"><label>Date<input id="rDate" type="date" value="${today()}"></label><button class="primary" id="rLoad">Load Results</button></div></div>
 <div id="rList" class="section"></div>`);
 $("rLoad").onclick=async()=>{const d=$("rDate").value,s=await get(ref(db,`quiz/results/${d}`)),v=s.val()||{},arr=Object.entries(v).map(([uid,x])=>({uid,...x})).sort((a,b)=>(Number(b.score)||0)-(Number(a.score)||0)||(a.submittedAt||0)-(b.submittedAt||0));
 $("rList").innerHTML=arr.map((x,i)=>`<div class="card"><div class="question-top"><b>#${i+1} ${esc(x.name||"Devotee")}</b><span class="pill">${Number(x.score||0)} / ${Number(x.total||10)}</span></div>
 <div class="small">Correct: ${Number(x.correct||0)} · Wrong: ${Number(x.wrong||0)} · Language: ${esc(x.language||"")}</div>
 <details><summary>See answer-by-answer result</summary>${(x.details||x.questions||[]).map((q,j)=>`<div class="result-row"><b>Q${j+1}</b> Selected: ${esc(q.selectedOption||q.selectedAnswer||"—")} · Correct: ${esc(q.correctOption||q.correctAnswer||"—")} · ${String(q.selectedOption||q.selectedAnswer||"").toUpperCase()===String(q.correctOption||q.correctAnswer||"").toUpperCase()?"✓ Correct":"✗ Wrong"}</div>`).join("")}</details></div>`).join("")||'<div class="card empty">No results for this date.</div>'};
 $("rLoad").click();
}

async function courses(){
 page("Courses","Create day-wise learning courses with YouTube lessons and optional cover image.",`
 <div class="card"><div class="form"><input id="coTitle" placeholder="Course title"><textarea id="coDesc" placeholder="Course description"></textarea><div id="coDays"></div>
 <div class="actions"><button class="secondary" id="coAdd">+ Add Day</button><button class="primary" id="coSave">Publish Course</button></div></div></div><div id="coList" class="section"></div>`);
 let n=0;const addDay=(x={})=>{n++;const e=document.createElement("div");e.className="card day-row";e.innerHTML=`<b>Day ${n}</b><div class="row"><input class="dayTitle" placeholder="Day title" value="${safeVal(x.title)}"><input class="dayUrl" placeholder="YouTube URL" value="${safeVal(x.url)}"></div><textarea class="dayText" placeholder="Lesson text">${safeVal(x.text)}</textarea>`;$("coDays").appendChild(e)};addDay();$("coAdd").onclick=()=>addDay();
 $("coSave").onclick=async()=>{try{const id=push(ref(db,"courses")).key,days={};document.querySelectorAll(".day-row").forEach((e,i)=>days["day"+(i+1)]={title:e.querySelector(".dayTitle").value.trim(),url:e.querySelector(".dayUrl").value.trim(),text:e.querySelector(".dayText").value.trim()});const x={title:$("coTitle").value.trim(),description:$("coDesc").value.trim(),days,active:true,createdAt:Date.now()};if(!x.title)return toast("Add course title.");await set(ref(db,`courses/${id}`),x);await notify("New Course",`${x.title} is now available.`,"course",{courseId:id});toast("Course published");loadSimpleList("courses","coList")}catch(e){toast(e.message)}};loadSimpleList("courses","coList");
}

async function challenge(){
 page("Challenges","Create the active 30-day/weekly style challenge with tasks, points and optional banner.",`
 <div class="card"><div class="form"><input id="chTitle" placeholder="Challenge title"><input id="chPeriod" placeholder="Period e.g. 30 Days"><textarea id="chDesc" placeholder="Description"></textarea><div id="chTasks"></div>
 <div class="actions"><button class="secondary" id="chAdd">+ Add Task</button><button class="primary" id="chSave">Publish Active Challenge</button></div></div></div><div id="chList" class="section"></div>`);
 let n=0;const add=(x={})=>{n++;const e=document.createElement("div");e.className="row task-row";e.innerHTML=`<input class="tn" placeholder="Task ${n}" value="${safeVal(x.name)}"><input class="tp" type="number" min="0" placeholder="Points" value="${Number(x.points||0)}">`;$("chTasks").appendChild(e)};add();$("chAdd").onclick=()=>add();
 $("chSave").onclick=async()=>{try{const id=push(ref(db,"challenges")).key,tasks={};document.querySelectorAll(".task-row").forEach((e,i)=>{const name=e.querySelector(".tn").value.trim();if(name)tasks["task"+(i+1)]={name,points:Number(e.querySelector(".tp").value||0)}});const x={title:$("chTitle").value.trim(),period:$("chPeriod").value.trim(),description:$("chDesc").value.trim(),active:true,tasks,createdAt:Date.now()};if(!x.title)return toast("Add title.");const all=(await get(ref(db,"challenges"))).val()||{};const up={};Object.keys(all).forEach(k=>up[`challenges/${k}/active`]=false);up[`challenges/${id}`]=x;await update(ref(db),up);await notify("Challenge",`${x.title} is now active.`,"challenge",{challengeId:id});toast("Challenge published");loadSimpleList("challenges","chList")}catch(e){toast(e.message)}};loadSimpleList("challenges","chList");
}

async function content(){
 page("Katha / Articles","Publish devotional stories/articles in multiple languages with an optional image.",`
 <div class="card"><div class="form"><div class="row"><input id="ctType" placeholder="Type: Katha / Article"><input id="ctTitle" placeholder="Title"></div><select id="ctLang"><option>Hindi</option><option>Bengali</option><option>English</option><option>Other</option></select><textarea id="ctText" placeholder="Full content"></textarea><button class="primary" id="ctSave">Publish</button></div></div><div id="ctList" class="section"></div>`);
 $("ctSave").onclick=async()=>{try{const id=push(ref(db,"bhaktiContent")).key,x={type:$("ctType").value.trim(),title:$("ctTitle").value.trim(),language:$("ctLang").value,text:$("ctText").value.trim(),createdAt:Date.now()};await set(ref(db,`bhaktiContent/${id}`),x);await notify("New Katha / Article",x.title||"New devotional content","content",{contentId:id});toast("Published");loadSimpleList("bhaktiContent","ctList")}catch(e){toast(e.message)}};loadSimpleList("bhaktiContent","ctList");
}

async function calendar(){
 page("Festival Calendar","Add festival dates, details and optional poster image.",`
 <div class="card"><div class="form"><div class="row"><input id="calTitle" placeholder="Festival title"><label>Date<input id="calDate" type="date"></label></div><textarea id="calDetails" placeholder="Festival details / paran / notes"></textarea><button class="primary" id="calSave">Publish Calendar Event</button></div></div><div id="calList" class="section"></div>`);
 $("calSave").onclick=async()=>{try{const id=push(ref(db,"calendar")).key,x={title:$("calTitle").value.trim(),date:$("calDate").value,details:$("calDetails").value.trim(),createdAt:Date.now()};await set(ref(db,`calendar/${id}`),x);await notify("Festival Calendar",`${x.title} added to the calendar.`,"calendar",{calendarId:id});toast("Calendar event published");loadSimpleList("calendar","calList")}catch(e){toast(e.message)}};loadSimpleList("calendar","calList");
}

async function youtube(){
 page("YouTube","Add devotional videos for the Devotee app.",`
 <div class="card"><div class="form"><input id="ytTitle" placeholder="Video title"><input id="ytUrl" placeholder="Exact YouTube URL"><textarea id="ytDesc" placeholder="Description"></textarea><button class="primary" id="ytSave">Publish Video</button></div></div><div id="ytList" class="section"></div>`);
 $("ytSave").onclick=async()=>{try{const id=push(ref(db,"youtube")).key,x={title:$("ytTitle").value.trim(),url:$("ytUrl").value.trim(),description:$("ytDesc").value.trim(),createdAt:Date.now()};await set(ref(db,`youtube/${id}`),x);await notify("New YouTube Video",x.title||"New video","youtube",{youtubeId:id});toast("Video published");loadSimpleList("youtube","ytList")}catch(e){toast(e.message)}};loadSimpleList("youtube","ytList");
}

async function books(){
 page("Book Store","Add books/resources with cover image and external link.",`
 <div class="card"><div class="form"><div class="row"><input id="bTitle" placeholder="Book title"><input id="bAuthor" placeholder="Author"></div><div class="row"><input id="bLang" placeholder="Language"><input id="bPrice" placeholder="Price"></div><input id="bUrl" placeholder="Book / Buy / PDF link"><textarea id="bDesc" placeholder="Description"></textarea><button class="primary" id="bSave">Publish Book</button></div></div><div id="bList" class="section"></div>`);
 $("bSave").onclick=async()=>{try{const id=push(ref(db,"books")).key,x={title:$("bTitle").value.trim(),author:$("bAuthor").value.trim(),language:$("bLang").value.trim(),price:$("bPrice").value.trim(),url:$("bUrl").value.trim(),description:$("bDesc").value.trim(),createdAt:Date.now()};await set(ref(db,`books/${id}`),x);await notify("New Book",`${x.title||"A new book"} added to Book Store.`,"books",{bookId:id});toast("Book published");loadSimpleList("books","bList")}catch(e){toast(e.message)}};loadSimpleList("books","bList");
}

async function prabhupada(){
 page("Prabhupada Today","Publish the daily inspiration by date.",`
 <div class="card"><div class="form"><div class="row"><label>Date<input id="pdDate" type="date" value="${today()}"></label><input id="pdSource" placeholder="Source"></div><textarea id="pdText" placeholder="Daily text / quote"></textarea><button class="primary" id="pdSave">Publish</button></div></div><div id="pdList" class="section"></div>`);
 $("pdSave").onclick=async()=>{try{const d=$("pdDate").value||today(),x={text:$("pdText").value.trim(),source:$("pdSource").value.trim(),publishedAt:Date.now()};await set(ref(db,`prabhupadaToday/${d}`),x);await notify("Prabhupada Today",`Daily inspiration published for ${d}.`,"prabhupada",{date:d});toast("Published");loadSimpleList("prabhupadaToday","pdList")}catch(e){toast(e.message)}};loadSimpleList("prabhupadaToday","pdList");
}

async function sadhana(){
 page("Sadhana Logs","View devotee-submitted sadhana/japa records. This page is read-only.",`<div class="card"><input class="search" id="sadSearch" placeholder="Search logs by name, UID or date"></div><div id="sadList" class="section"></div>`);
 const s=await get(ref(db,"sadhana"));const v=s.val()||{};const render=()=>{const q=($("sadSearch").value||"").toLowerCase();const rows=Object.entries(v).filter(([k,x])=>!q||(`${k} ${JSON.stringify(x)}`).toLowerCase().includes(q)).slice(-200).reverse().map(([k,x])=>`<div class="card item"><div><b>${esc(x.name||x.uid||k)}</b><div class="small">${esc(x.date||k)} · Mala: ${esc(x.mala||x.malaCount||"—")} · Wake: ${esc(x.wakeTime||"—")}</div><div class="muted">${esc(x.note||"")}</div></div></div>`).join("");$("sadList").innerHTML=rows||'<div class="card empty">No sadhana logs found.</div>'};render();$("sadSearch").oninput=render;
}

async function bhakti(){
 page("Bhakti Content","Manage home-page devotional cards/content.",`
 <div class="card"><div class="form"><input id="bcTitle" placeholder="Title"><input id="bcType" placeholder="Type / section"><textarea id="bcText" placeholder="Text"></textarea><input id="bcRoute" placeholder="Route / target screen (optional)"><button class="primary" id="bcSave">Publish Home Content</button></div></div><div id="bcList" class="section"></div>`);
 $("bcSave").onclick=async()=>{
  const btn=$("bcSave");
  try{
   btn.disabled=true;
   const title=$("bcTitle").value.trim(), type=$("bcType").value.trim(), text=$("bcText").value.trim(), route=$("bcRoute").value.trim();
   if(!title && !text)return toast("Enter a title or text.");
   const id=push(ref(db,"bhaktiContent")).key;
   const x={title,type,text,route,createdAt:Date.now()};
   await set(ref(db,`bhaktiContent/${String(id)}`),x);
   // Notification is optional; content must still publish if notification/FCM is unavailable.
   try{await notify("New Bhakti Content",title||"New content","content",{contentId:String(id)});}catch(e){console.warn("Bhakti notification skipped",e);}
   toast("Published successfully");
   $("bcTitle").value="";$("bcType").value="";$("bcText").value="";$("bcRoute").value="";
   await loadSimpleList("bhaktiContent","bcList");
  }catch(e){console.error(e);toast(e?.message||"Could not publish content.");}
  finally{btn.disabled=false;}
 };
 loadSimpleList("bhaktiContent","bcList");
}

async function notifications(){
 page("Notifications","Send an in-app notification and queue the same message for FCM push.",`
 <div class="card"><div class="form"><input id="nTitle" placeholder="Notification title"><textarea id="nText" placeholder="Notification message"></textarea><div class="row"><input id="nTarget" placeholder="Target e.g. all / quiz / darshan"><input id="nRoute" placeholder="Route (optional)"></div><button class="primary" id="nSend">Send Push + In-App Notification</button></div></div><div id="nList" class="section"></div>`);
 $("nSend").onclick=async()=>{const title=$("nTitle").value.trim(),text=$("nText").value.trim();if(!title||!text)return toast("Enter title and message.");await notify(title,text,$("nTarget").value.trim()||"all",{route:$("nRoute").value.trim()});toast("Notification queued");loadSimpleList("notifications","nList")};loadSimpleList("notifications","nList");
}

async function settings(){
 page("App Settings","Small controls stored in Firebase Realtime Database.",`
 <div class="card"><div class="form"><input id="setName" placeholder="App display name" value="Vaishnav World"><input id="setNotice" placeholder="Home announcement"><textarea id="setAbout" placeholder="About app"></textarea><label>Enable maintenance mode<select id="setMaintenance"><option value="false">No</option><option value="true">Yes</option></select></label><button class="primary" id="setSave">Save App Settings</button></div></div>
 <div class="card section"><b>Firebase / push status</b><p class="muted">Admin publishes to Realtime Database. The pushQueue path is ready for the Cloud Function/native FCM sender. Question images are used only inside the Daily Quiz editor. Other Admin sections use text/links only.</p></div>`);
 const s=await get(ref(db,"appSettings"));const x=s.val()||{};$("setName").value=x.appName||"Vaishnav World";$("setNotice").value=x.homeNotice||"";$("setAbout").value=x.about||"";$("setMaintenance").value=String(!!x.maintenance);
 $("setSave").onclick=async()=>{await set(ref(db,"appSettings"),{appName:$("setName").value.trim(),homeNotice:$("setNotice").value.trim(),about:$("setAbout").value.trim(),maintenance:$("setMaintenance").value==="true",updatedAt:Date.now()});await notify("App Updated","New app settings are available.","all",{route:"home"});toast("Settings saved")};
}

const pages={dashboard,devotees,members,darshan,shloka,gita,quiz,quizresults,courses,challenge,content,calendar,youtube,books,prabhupada,sadhana,bhakti,notifications,settings};
function init(){document.querySelectorAll(".nav").forEach(b=>b.onclick=()=>{document.querySelectorAll(".nav").forEach(x=>x.classList.remove("active"));b.classList.add("active");pages[b.dataset.page]()})}
function openAdmin(){sessionStorage.setItem("adminLoggedIn","1");$("login").classList.add("hidden");$("app").classList.remove("hidden");initFirebase();init();dashboard()}
function closeAdmin(){sessionStorage.removeItem("adminLoggedIn");$("app").classList.add("hidden");$("login").classList.remove("hidden");$("password").value="";$("loginMsg").textContent=""}
$("loginBtn").onclick=()=>{if($("password").value==="2011")openAdmin();else $("loginMsg").textContent="Wrong password"};
$("password").addEventListener("keydown",e=>{if(e.key==="Enter")$("loginBtn").click()});
$("logout").onclick=closeAdmin;
if(sessionStorage.getItem("adminLoggedIn")==="1")openAdmin();
