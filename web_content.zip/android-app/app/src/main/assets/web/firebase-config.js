/**
 * Firebase Configuration & Infrastructure
 * Maa Annapurna Tiffin Management System
 * Connected to Live Production Firebase Project: tiffine-ce58f
 */

// Production Pre-configured Firebase Keys (Configured for tiffine-ce58f)
const PRECONFIGURED_FIREBASE_CONFIG = {
  apiKey: "AIzaSyAG5cMmo3JlvAqF1P4XRe3dmlOwxSVnVeE",
  authDomain: "tiffine-ce58f.firebaseapp.com",
  projectId: "tiffine-ce58f",
  storageBucket: "tiffine-ce58f.firebasestorage.app",
  messagingSenderId: "224753390975",
  appId: "1:224753390975:web:1580874a6f3400a624f64a"
};

const DEV_CONFIG_KEY = 'MAT_DEV_FIREBASE_CONFIG';
const DEV_SYNC_ENABLED_KEY = 'MAT_DEV_SYNC_ENABLED';
const DEV_ADMIN_PASS_KEY = 'MAT_DEV_ADMIN_PASS';
const DEFAULT_DEV_ADMIN_PASS = 'admin@annapurna2026';

// Purge any stale demo or invalid keys from localStorage to ensure the real live project is used
(function ensureLiveConfigActive() {
  try {
    const stored = localStorage.getItem(DEV_CONFIG_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      if (parsed.projectId !== 'tiffine-ce58f') {
        localStorage.removeItem(DEV_CONFIG_KEY);
      }
    }
    localStorage.removeItem('MAT_FIREBASE_CONFIG');
  } catch (e) {}
})();

// ============================================================================
// SYSTEM LOGS LOGGER
// ============================================================================
class LoggerService {
  constructor() {
    this.logs = [];
    this.maxLogs = 200;
    this.loadLogs();
  }

  loadLogs() {
    try {
      const stored = sessionStorage.getItem('MAT_DEV_LOGS');
      if (stored) this.logs = JSON.parse(stored);
    } catch (e) {
      this.logs = [];
    }
  }

  persist() {
    try {
      sessionStorage.setItem('MAT_DEV_LOGS', JSON.stringify(this.logs.slice(-this.maxLogs)));
    } catch (e) {}
  }

  log(level, message, data = null) {
    const entry = {
      timestamp: new Date().toLocaleTimeString(),
      level: level.toUpperCase(),
      message,
      data: data ? (typeof data === 'object' ? JSON.stringify(data) : String(data)) : null
    };
    this.logs.push(entry);
    if (this.logs.length > this.maxLogs) this.logs.shift();
    this.persist();

    if (window.renderDeveloperLogs) {
      window.renderDeveloperLogs();
    }
  }

  info(msg, data) { this.log('INFO', msg, data); }
  warn(msg, data) { this.log('WARN', msg, data); }
  error(msg, data) { this.log('ERROR', msg, data); }
  success(msg, data) { this.log('SUCCESS', msg, data); }

  getLogs() {
    return [...this.logs];
  }

  clear() {
    this.logs = [];
    try { sessionStorage.removeItem('MAT_DEV_LOGS'); } catch (e) {}
    if (window.renderDeveloperLogs) {
      window.renderDeveloperLogs();
    }
  }
}

window.AppLogger = new LoggerService();

// ============================================================================
// FIREBASE MANAGER CLASS
// ============================================================================
class FirebaseManager {
  constructor() {
    this.app = null;
    this.auth = null;
    this.db = null;
    this.isInitialized = false;
    this.isSandbox = false; // Live Google Firebase
  }

  isLiveGoogleApiKey(apiKey) {
    if (!apiKey || typeof apiKey !== 'string') return false;
    if (apiKey.startsWith('sk-ant') || apiKey.startsWith('sk-')) return false;
    if (apiKey.includes('Placeholder')) return false;
    return apiKey.startsWith('AIzaSy') && apiKey.length >= 35;
  }

  getConfig() {
    try {
      const custom = localStorage.getItem(DEV_CONFIG_KEY);
      if (custom) {
        const parsed = JSON.parse(custom);
        if (parsed.apiKey && parsed.projectId) {
          return parsed;
        }
      }
    } catch (e) {
      AppLogger.warn('Error reading custom dev config, falling back to preconfigured', e);
    }
    return PRECONFIGURED_FIREBASE_CONFIG;
  }

  saveDeveloperConfig(config) {
    if (!config || !config.apiKey || !config.projectId) {
      throw new Error('API Key and Project ID are required.');
    }
    localStorage.setItem(DEV_CONFIG_KEY, JSON.stringify(config));
    AppLogger.success('Developer updated Firebase project configuration', config.projectId);
    return true;
  }

  resetDeveloperConfig() {
    localStorage.removeItem(DEV_CONFIG_KEY);
    localStorage.removeItem('MAT_FIREBASE_CONFIG');
    AppLogger.info('Developer reset Firebase configuration to factory default');
  }

  isCloudSyncEnabled() {
    const val = localStorage.getItem(DEV_SYNC_ENABLED_KEY);
    return val !== 'false';
  }

  setCloudSyncEnabled(enabled) {
    localStorage.setItem(DEV_SYNC_ENABLED_KEY, enabled ? 'true' : 'false');
    AppLogger.info(`Cloud Sync set to: ${enabled ? 'ENABLED' : 'DISABLED'}`);
    if (window.FirebaseSync) {
      window.FirebaseSync.updateIndicator(enabled ? 'synced' : 'offline');
    }
  }

  verifyDeveloperPassword(inputPass) {
    const stored = localStorage.getItem(DEV_ADMIN_PASS_KEY) || DEFAULT_DEV_ADMIN_PASS;
    return String(inputPass).trim() === stored;
  }

  setDeveloperPassword(newPass) {
    if (!newPass || newPass.length < 6) {
      throw new Error('Admin password must be at least 6 characters.');
    }
    localStorage.setItem(DEV_ADMIN_PASS_KEY, String(newPass).trim());
    AppLogger.info('Developer Admin Password updated');
    return true;
  }

  init() {
    if (this.isInitialized) return this;

    const config = this.getConfig();
    const hasLiveKey = this.isLiveGoogleApiKey(config.apiKey);

    if (typeof firebase === 'undefined') {
      AppLogger.info('Firebase CDN offline, running in local persistence mode');
      this.isSandbox = true;
      this.isInitialized = true;
      return this;
    }

    try {
      if (!firebase.apps.length) {
        this.app = firebase.initializeApp(config);
      } else {
        this.app = firebase.app();
      }

      this.auth = firebase.auth();
      this.db = firebase.firestore();

      // Configure multi-device offline persistence
      try {
        this.db.enablePersistence({ synchronizeTabs: true }).catch(() => {});
      } catch (e) {}

      this.isInitialized = true;
      this.isSandbox = !hasLiveKey;

      AppLogger.success('Live Firebase project connected:', config.projectId);
    } catch (err) {
      AppLogger.warn('Firebase init notice, falling back to local storage:', err.message);
      this.isSandbox = true;
      this.isInitialized = true;
    }

    return this;
  }
}

// Global Singleton Instance
window.FirebaseAppManager = new FirebaseManager();
