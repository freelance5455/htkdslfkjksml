const defaultProducts = [
  {id:1,name:'Camiseta Premium',price:19.99,stock:30},
  {id:2,name:'Sudadera Urban',price:39.99,stock:18},
  {id:3,name:'Pantalón Cargo',price:34.99,stock:15},
  {id:4,name:'Zapatillas Sport',price:59.99,stock:12},
  {id:5,name:'Gorra Classic',price:14.99,stock:25},
  {id:6,name:'Mochila Pro',price:44.99,stock:10}
];
const defaultNames = ['Lucas','Mateo','Sofía','Emma','Hugo','Daniel','Martina','Leo','Pablo','Noah','Valeria','Julia','Sara','David','Mario'];
const load = () => { try { return JSON.parse(localStorage.getItem('shopsim-state')) } catch { return null } };
let state = load() || {products:defaultProducts,orders:[],customers:[],activity:[],nextId:7};
const save = () => localStorage.setItem('shopsim-state',JSON.stringify(state));
const money = n => Number(n).toLocaleString('es-ES',{style:'currency',currency:'EUR'});
const escapeHTML = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function addActivity(title,detail){state.activity.unshift({title,detail,time:new Date().toLocaleString('es-ES',{hour:'2-digit',minute:'2-digit'})});state.activity=state.activity.slice(0,12);}
function render(){
 const sales=state.orders.reduce((sum,o)=>sum+o.total,0);
 document.getElementById('stat-sales').textContent=money(sales);
 document.getElementById('stat-orders').textContent=state.orders.length;
 document.getElementById('stat-customers').textContent=state.customers.length;
 document.getElementById('stat-profit').textContent=money(sales*.35);
 document.getElementById('activity-list').innerHTML=state.activity.length?state.activity.map(a=>`<div class="activity-item"><div class="activity-icon">↗</div><div><strong>${escapeHTML(a.title)}</strong><small>${escapeHTML(a.detail)} · ${a.time}</small></div></div>`).join(''):'<div class="empty-state">Todavía no hay actividad. ¡Simula tu primera venta!</div>';
 document.getElementById('inventory-preview').innerHTML=state.products.slice(0,5).map(p=>`<div class="inventory-row"><span>${escapeHTML(p.name)}</span><span>${p.stock} uds.</span></div>`).join('')||'<div class="empty-state">No hay productos</div>';
 document.getElementById('products-table').innerHTML=state.products.length?`<table class="table"><thead><tr><th>Producto</th><th>Precio</th><th>Stock</th><th>Estado</th></tr></thead><tbody>${state.products.map(p=>`<tr><td>${escapeHTML(p.name)}</td><td>${money(p.price)}</td><td>${p.stock}</td><td><span class="pill ${p.stock<=5?'low':''}">${p.stock<=5?'Stock bajo':'Disponible'}</span></td></tr>`).join('')}</tbody></table>`:'<div class="empty-state">No hay productos todavía.</div>';
 document.getElementById('orders-table').innerHTML=state.orders.length?`<table class="table"><thead><tr><th>Pedido</th><th>Cliente</th><th>Artículo</th><th>Total</th><th>Hora</th></tr></thead><tbody>${state.orders.map(o=>`<tr><td>#${o.id}</td><td>${escapeHTML(o.customer)}</td><td>${escapeHTML(o.product)}</td><td>${money(o.total)}</td><td>${o.time}</td></tr>`).join('')}</tbody></table>`:'<div class="empty-state">Aún no hay pedidos. Genera uno para empezar.</div>';
 document.getElementById('customers-table').innerHTML=state.customers.length?`<table class="table"><thead><tr><th>Cliente</th><th>Pedidos</th><th>Total gastado</th></tr></thead><tbody>${state.customers.map(c=>`<tr><td>${escapeHTML(c.name)}</td><td>${c.orders}</td><td>${money(c.spent)}</td></tr>`).join('')}</tbody></table>`:'<div class="empty-state">Todavía no tienes clientes.</div>';
 save();
}
function createOrder(){
 const available=state.products.filter(p=>p.stock>0);
 if(!available.length){alert('No queda stock disponible. Añade productos o repón inventario.');return;}
 const product=available[Math.floor(Math.random()*available.length)]; product.stock--;
 let customer=state.customers[Math.floor(Math.random()*state.customers.length)];
 if(!customer){customer={name:defaultNames[Math.floor(Math.random()*defaultNames.length)],orders:0,spent:0};state.customers.push(customer);}
 customer.orders++;customer.spent+=product.price;
 const order={id:state.orders.length+1,customer:customer.name,product:product.name,total:product.price,time:new Date().toLocaleTimeString('es-ES',{hour:'2-digit',minute:'2-digit'})};
 state.orders.unshift(order);addActivity('Nuevo pedido',`${customer.name} compró ${product.name} · ${money(product.price)}`);render();
}
function setView(view){document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));document.getElementById(`view-${view}`)?.classList.add('active');document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===view));const titles={dashboard:'Dashboard',products:'Productos',orders:'Pedidos',customers:'Clientes'};document.getElementById('page-title').textContent=titles[view]||'Dashboard';}
document.querySelectorAll('.nav-item').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.view)));
document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.go)));
document.getElementById('simulate-sale').addEventListener('click',createOrder);
document.getElementById('simulate-order').addEventListener('click',createOrder);
const dialog=document.getElementById('product-dialog');
document.getElementById('open-add-product').addEventListener('click',()=>dialog.showModal());
document.getElementById('close-dialog').addEventListener('click',()=>dialog.close());
document.getElementById('product-form').addEventListener('submit',e=>{e.preventDefault();const name=document.getElementById('product-name').value.trim();const price=Number(document.getElementById('product-price').value);const stock=Number(document.getElementById('product-stock').value);if(!name||price<=0||stock<0)return;state.products.push({id:state.nextId++,name,price,stock});addActivity('Producto añadido',`${name} · ${money(price)}`);e.target.reset();dialog.close();render();});
render();
