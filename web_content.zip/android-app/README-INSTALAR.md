# ShopSim Android

Proyecto Android wrapper para ShopSim (HTML/CSS/JS) usando WebView local.

## Compilar APK
1. Instala Android Studio en un PC.
2. Abre la carpeta `android-app` desde Android Studio.
3. Espera a que Gradle termine la sincronización.
4. Selecciona Build > Build APK(s).
5. Usa el enlace "locate" que muestra Android Studio para encontrar el APK.
6. Copia el APK al Vivo Y21 e instálalo. Si Android lo solicita, permite instalar apps desde esa fuente.

## Características
- ShopSim embebido localmente en assets; no requiere internet para abrir.
- JavaScript y almacenamiento DOM habilitados.
- No requiere permisos de red.

Nota: este paquete es el proyecto fuente, no una APK compilada.
