CRICKET COUNTER — REFERENCE STYLE BUILD

How to use:
1. Extract this ZIP.
2. Open index.html in your browser or app preview.
3. Open Settings, paste your CricketLiveAPI token, and Save token.
4. Tap Test live API now, then use Live, Upcoming, Rankings, and News.

Important:
- This is a mobile-friendly browser prototype, not an Android APK.
- Live scores, schedule, scorecard, and rankings require working CricketLiveAPI endpoints and a valid token.
- The news feed can be blocked by the browser Preview due to cross-origin restrictions; the app provides an external news link as a fallback.
- A production/public app should use a secure backend to protect the API token.
- Ad space is a placeholder, not a live ad network integration.
