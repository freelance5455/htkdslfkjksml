# MR,KHORASANI — نسخه 1.5.0

این نسخه ادامه‌ی `MR-KHORASANI-WEB-v1.4.6-FINAL.zip` است و روی همان معماری وب/PWA اجرا می‌شود.

## تغییرات

- ورود گروهی اشخاص از قالب رسمی Excel با تشخیص هدرهای فارسی.
- ورود گروهی کالاها از قالب رسمی Excel با موجودی و بهای دو انبار.
- تشخیص رکورد تکراری با کد/نام و به‌روزرسانی رکورد موجود.
- تعریف دستی شخص جدید.
- تعریف دستی کالا جدید.
- خروجی بخش‌ها با اولویت انتخاب مسیر ذخیره‌سازی.
- پشتیبانی از `showSaveFilePicker` در محیط‌های وب سازگار.
- پشتیبانی از پل بومی `Android.saveFileWithPicker` / `Android.saveWithPicker`.
- پل نمونه اندروید بر پایه `ACTION_CREATE_DOCUMENT` در `android-ExportFilePickerBridge.kt`.
- در صورت نبودن انتخاب‌گر، دانلود استاندارد مرورگر همچنان به‌عنوان fallback فعال است.

## فایل‌های مهم

- `index.html` — برنامه اصلی.
- `templates/قالب-ورود-اشخاص.xlsx` — قالب ورود اشخاص.
- `templates/قالب-ورود-کالاها.xlsx` — قالب ورود کالاها.
- `STORAGE-EXPORT-README.txt` — شرح کامل قابلیت ذخیره‌سازی و ورود Excel.
- `android-ExportFilePickerBridge.kt` — پل نمونه برای APK/WebView.
