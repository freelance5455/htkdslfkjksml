plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "se.lyftsang.besiktning"
    compileSdk = 35

    defaultConfig {
        applicationId = "se.lyftsang.besiktning"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
