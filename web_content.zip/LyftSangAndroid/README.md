# Lyft & Säng – Android

Detta är ett färdigt Android Studio-projekt som paketerar den befintliga `index.html`-appen i en WebView.

## Funktioner
- Offline
- JavaScript + localStorage aktiverat
- Registerdata sparas lokalt på telefonen
- Backup/återställning via filväljare
- Svenskt appnamn: Lyft & Säng
- Enkel teknisk appikon

## Bygga APK
Öppna projektmappen i Android Studio och välj Build → Generate App Bundles or APKs → Generate APKs.

Projektet är förberett för Android SDK 35 och Java 17.
