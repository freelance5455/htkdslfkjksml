MEU REINO - projeto Android

Este projeto empacota o checklist HTML Meu Reino como um aplicativo Android usando WebView.
O checklist, suas 529 tarefas, busca, categorias e armazenamento local foram preservados.

Para gerar o APK:
1. Instale Android Studio em um computador.
2. Abra a pasta MeuReinoAndroid no Android Studio (Open).
3. Aguarde o Gradle sincronizar e instalar componentes solicitados.
4. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de debug estará em app/build/outputs/apk/debug/app-debug.apk.

Nota: este ambiente não possui Android SDK/Gradle instalado, portanto não foi possível compilar o APK aqui.
