package ir.medreminder.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "medicine_alarm_v2";

    @Override public void onReceive(Context context, Intent intent) {
        String name = intent.getStringExtra("n");
        String dose = intent.getStringExtra("d");
        String time = intent.getStringExtra("t");
        if (name == null || time == null) return;

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        long[] vibration = {0, 600, 300, 600, 300, 900};

        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "آلارم دارو", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("یادآوری زمان مصرف دارو");
            channel.setSound(sound, new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            channel.enableVibration(true);
            channel.setVibrationPattern(vibration);
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(channel);
        }

        Intent open = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("alarm_name", name)
                .putExtra("alarm_time", time);
        PendingIntent fullScreen = PendingIntent.getActivity(
                context, stableId(name + "|" + time), open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context);
        builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("⏰ وقت مصرف دارو")
                .setContentText(name + (dose == null || dose.isEmpty() ? "" : " — " + dose) + " · " + time)
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_MAX)
                .setFullScreenIntent(fullScreen, true)
                .setContentIntent(fullScreen)
                .setAutoCancel(true)
                .setOngoing(false)
                .setVisibility(Notification.VISIBILITY_PUBLIC);

        if (Build.VERSION.SDK_INT < 26) {
            builder.setSound(sound);
            builder.setVibrate(vibration);
        }

        Notification notification = builder.build();
        notification.flags |= Notification.FLAG_INSISTENT;
        nm.notify(stableId(name + "|" + time), notification);

        Alarms.schedule(context.getApplicationContext());
    }

    private static int stableId(String value) {
        int h = 0x811c9dc5;
        for (int i = 0; i < value.length(); i++) h = (h ^ value.charAt(i)) * 16777619;
        return h & 0x7fffffff;
    }
}
