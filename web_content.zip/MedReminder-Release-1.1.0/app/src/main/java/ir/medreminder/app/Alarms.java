package ir.medreminder.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public final class Alarms {
    private static final String PREFS = "m";
    private static final String JSON = "j";
    private static final String KEYS = "keys";

    private Alarms() {}

    private static int requestCode(String key) {
        int h = 0x811c9dc5;
        for (int i = 0; i < key.length(); i++) h = (h ^ key.charAt(i)) * 16777619;
        return h & 0x7fffffff;
    }

    private static PendingIntent pi(Context c, String key, String n, String d, String t) {
        Intent i = new Intent(c, AlarmReceiver.class)
                .putExtra("n", n).putExtra("d", d).putExtra("t", t);
        return PendingIntent.getBroadcast(c, requestCode(key), i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static void save(Context c, String json) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(JSON, json).apply();
        schedule(c.getApplicationContext());
    }

    public static void schedule(Context c) {
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String json = sp.getString(JSON, null);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        Set<String> oldKeys = sp.getStringSet(KEYS, new HashSet<String>());
        for (String key : oldKeys) am.cancel(pi(c, key, "", "", ""));

        Set<String> keys = new HashSet<>();
        if (json == null || json.trim().isEmpty()) {
            sp.edit().putStringSet(KEYS, keys).apply();
            return;
        }

        try {
            JSONObject root = new JSONObject(json);
            String today = root.optString("k", "");
            JSONArray meds = root.optJSONArray("m");
            if (meds == null) return;

            PendingIntent show = PendingIntent.getActivity(c, 0,
                    new Intent(c, MainActivity.class),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            for (int i = 0; i < meds.length(); i++) {
                JSONObject m = meds.getJSONObject(i);
                JSONArray times = m.optJSONArray("t");
                if (times == null) continue;
                for (int k = 0; k < times.length(); k++) {
                    String time = times.getString(k);
                    String key = m.getString("id") + "|" + time;
                    long at = next(m, time, today);
                    if (at < 0) continue;
                    PendingIntent pending = pi(c, key, m.optString("n", "دارو"), m.optString("d", ""), time);
                    keys.add(key);
                    am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), pending);
                }
            }
        } catch (Exception ignored) {
            // Keep the app usable even if a corrupt preference exists.
        }
        sp.edit().putStringSet(KEYS, keys).apply();
    }

    private static long next(JSONObject medicine, String time, String today) throws Exception {
        String[] parts = time.split(":");
        int hour = Integer.parseInt(parts[0]);
        int minute = Integer.parseInt(parts[1]);
        String start = medicine.optString("s", "");
        String end = medicine.optString("e", "");
        JSONArray weekdays = medicine.optJSONArray("w");
        JSONArray excludedToday = medicine.optJSONArray("x");

        for (int day = 0; day < 9; day++) {
            Calendar q = Calendar.getInstance();
            q.add(Calendar.DAY_OF_YEAR, day);
            q.set(Calendar.HOUR_OF_DAY, hour);
            q.set(Calendar.MINUTE, minute);
            q.set(Calendar.SECOND, 0);
            q.set(Calendar.MILLISECOND, 0);
            if (q.getTimeInMillis() <= System.currentTimeMillis()) continue;

            int dow = q.get(Calendar.DAY_OF_WEEK) - 1;
            boolean ok = false;
            if (weekdays != null) {
                for (int i = 0; i < weekdays.length(); i++) if (weekdays.getInt(i) == dow) ok = true;
            }
            if (!ok) continue;

            String date = String.format(Locale.US, "%04d-%02d-%02d",
                    q.get(Calendar.YEAR), q.get(Calendar.MONTH) + 1, q.get(Calendar.DAY_OF_MONTH));
            if (!start.isEmpty() && date.compareTo(start) < 0) continue;
            if (!end.isEmpty() && date.compareTo(end) > 0) continue;

            if (excludedToday != null && date.equals(today)) {
                for (int i = 0; i < excludedToday.length(); i++) {
                    if (time.equals(excludedToday.getString(i))) { ok = false; break; }
                }
            }
            if (!ok) continue;
            return q.getTimeInMillis();
        }
        return -1;
    }
}
