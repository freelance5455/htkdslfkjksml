package ir.medreminder.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String action = intent != null ? intent.getAction() : null;
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)
                || Intent.ACTION_TIME_SET.equals(action)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(action)) {
            Alarms.schedule(context.getApplicationContext());
        }
    }
}
