مشروع ARSANYOS لتحويل صفحة HTML إلى تطبيق Android.

محتويات المشروع:
- صفحة التطبيق داخل app/src/main/assets/index.html
- اسم التطبيق ARSANYOS
- package: com.arsanyos.app
- WebView محلي مع دعم JavaScript وفتح روابط Telegram خارج التطبيق.

طريقة البناء:
1) افتح المجلد ARSANYOS_Android_Project في Android Studio حديث.
2) استخدم JDK 17 و Android SDK Platform 35.
3) انتظر Gradle Sync.
4) من Build اختر Build APK(s).
5) ستجد APK داخل app/build/outputs/apk/debug/.

ملاحظة: هذا مشروع مصدر جاهز، وليس ملف APK مبنيًا. يحتاج Android SDK/Gradle لبناء APK.
