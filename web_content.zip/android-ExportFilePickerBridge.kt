// پل اختیاری اندروید برای انتخاب مسیر ذخیره خروجی‌های MR,KHORASANI
// قرارداد JavaScript: Android.saveFileWithPicker(fileName, mime, base64)
// در Activity/WebView، نمونه کلاس را به نام Android به WebView معرفی کنید.

package com.mrkhorasani.financialcloud

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.util.Base64
import android.webkit.JavascriptInterface
import java.io.OutputStream

class MrkExportFilePickerBridge(private val activity: Activity) {
    private var pendingFileName: String = "export.bin"
    private var pendingMime: String = "application/octet-stream"
    private var pendingBytes: ByteArray = ByteArray(0)

    @JavascriptInterface
    fun saveFileWithPicker(fileName: String, mime: String, base64: String): Boolean {
        pendingFileName = fileName.ifBlank { "export.bin" }
        pendingMime = mime.ifBlank { "application/octet-stream" }
        pendingBytes = try { Base64.decode(base64, Base64.DEFAULT) } catch (_: Exception) { return false }

        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = pendingMime
            putExtra(Intent.EXTRA_TITLE, pendingFileName)
        }
        activity.startActivityForResult(intent, REQUEST_CREATE_DOCUMENT)
        return true
    }

    fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?): Boolean {
        if (requestCode != REQUEST_CREATE_DOCUMENT) return false
        if (resultCode != Activity.RESULT_OK) return true
        val uri: Uri = data?.data ?: return true
        activity.contentResolver.openOutputStream(uri)?.use { out: OutputStream ->
            out.write(pendingBytes)
            out.flush()
        }
        return true
    }

    companion object {
        const val REQUEST_CREATE_DOCUMENT = 40991
    }
}

/*
Integration sketch in the Android Activity:

private lateinit var exportBridge: MrkExportFilePickerBridge

exportBridge = MrkExportFilePickerBridge(this)
webView.settings.javaScriptEnabled = true
webView.addJavascriptInterface(exportBridge, "Android")

override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
    super.onActivityResult(requestCode, resultCode, data)
    exportBridge.onActivityResult(requestCode, resultCode, data)
}
*/
