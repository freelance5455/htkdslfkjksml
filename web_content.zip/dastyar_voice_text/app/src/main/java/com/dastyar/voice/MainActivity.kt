package com.dastyar.voice
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import androidx.core.app.ActivityCompat
import java.util.Locale

class MainActivity:Activity(),TextToSpeech.OnInitListener {
 private lateinit var web:WebView
 private var sr:SpeechRecognizer?=null
 private var tts:TextToSpeech?=null
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
  tts=TextToSpeech(this,this);web=WebView(this);web.settings.javaScriptEnabled=true;web.settings.domStorageEnabled=true
  web.webViewClient=WebViewClient();web.addJavascriptInterface(Bridge(),"AndroidVoice");setContentView(web);web.loadUrl("file:///android_asset/index.html")
  if(ActivityCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.RECORD_AUDIO),12)
 }
 inner class Bridge{
  @JavascriptInterface fun toggleListening(){runOnUiThread{startSpeech()}}
  @JavascriptInterface fun speak(s:String){runOnUiThread{tts?.speak(s.take(1200),TextToSpeech.QUEUE_FLUSH,null,"reply")}}
  @JavascriptInterface fun submitText(s:String){runOnUiThread{
   val reply="پیامت ثبت شد: "+s.take(180)+". برای پاسخ هوشمند باید اتصال امن هوش مصنوعی راه‌اندازی شود."
   web.evaluateJavascript("window.onAssistantReply(${org.json.JSONObject.quote(reply)})",null)
  }}
 }
 private fun startSpeech(){
  if(ActivityCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.RECORD_AUDIO),12);return}
  if(!SpeechRecognizer.isRecognitionAvailable(this)){web.evaluateJavascript("window.onAssistantReply('سرویس تشخیص گفتار روی گوشی فعال نیست.')",null);return}
  sr?.destroy();sr=SpeechRecognizer.createSpeechRecognizer(this)
  sr?.setRecognitionListener(object:RecognitionListener{
   override fun onReadyForSpeech(p:Bundle?){web.evaluateJavascript("window.setListening(true)",null)}
   override fun onBeginningOfSpeech(){};override fun onRmsChanged(v:Float){};override fun onBufferReceived(b:ByteArray?){};override fun onEndOfSpeech(){web.evaluateJavascript("window.setListening(false)",null)}
   override fun onError(e:Int){web.evaluateJavascript("window.setListening(false);window.onAssistantReply('گفتار تشخیص داده نشد؛ دوباره تلاش کن.')",null)}
   override fun onResults(b:Bundle?){val t=b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?:return
    web.evaluateJavascript("window.onSpeechResult(${org.json.JSONObject.quote(t)})",null);web.evaluateJavascript("window.setListening(false)",null)}
   override fun onPartialResults(b:Bundle?){};override fun onEvent(t:Int,b:Bundle?){}
  })
  val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_LANGUAGE,"fa-IR")}
  sr?.startListening(i)
 }
 override fun onInit(status:Int){if(status==TextToSpeech.SUCCESS)tts?.setLanguage(Locale("fa","IR"))}
 override fun onDestroy(){sr?.destroy();tts?.stop();tts?.shutdown();web.destroy();super.onDestroy()}
}