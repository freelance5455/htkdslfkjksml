STEAL AN EGG — ANDROID LANDSCAPE PROJECT

This is a minimal Android Studio project wrapping the included game page in a WebView.
Landscape is forced by BOTH AndroidManifest.xml (android:screenOrientation="landscape") and MainActivity.java (setRequestedOrientation(SCREEN_ORIENTATION_LANDSCAPE)). The old "turn your tablet sideways" interstitial is absent from the included index.html.

To build an APK:
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish (Android SDK Platform 35 and a compatible JDK are needed).
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).

The generated APK is not included because this environment does not have the Android SDK/Gradle build toolchain configured. This ZIP is the Android project source, not a prebuilt APK.
