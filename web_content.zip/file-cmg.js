"use strict";

const CACHE = "my-progress-shell-v1";
const SHELL = [
  "./index.html",
  "./manifest.webmanifest",
  "./icon.svg"
];

const shellURLs = new Set(
  SHELL.map(path => new URL(path, self.registration.scope).href)
);

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE).then(cache => cache.addAll(SHELL))
  );
});

self.addEventListener("activate", event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(
      keys
        .filter(key => key.startsWith("my-progress-shell-") && key !== CACHE)
        .map(key => caches.delete(key))
    );
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", event => {
  const request = event.request;
  if (request.method !== "GET") return;

const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

if (request.mode === "navigate") {
    event.respondWith((async () => {
      try {
        const response = await fetch(request);
        if (response.ok) return response;
      } catch {
        // Use the installed app shell when offline.
      }
      return (
        await caches.match(
          new URL("./index.html", self.registration.scope).href
        )
      ) || new Response("Open My Progress online once to enable offline use.", {
        status: 503,
        headers: { "Content-Type": "text/plain; charset=utf-8" }
      });
    })());
    return;
  }

if (shellURLs.has(url.href)) {
    event.respondWith(
      caches.match(request).then(cached => cached || fetch(request))
    );
  }
});
