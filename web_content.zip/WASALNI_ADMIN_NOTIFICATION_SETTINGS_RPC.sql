-- WASALNI V15.2 / ADMIN V13.4
-- Secure admin-only RPCs for editing public.notification_settings.
-- Run once in Supabase SQL Editor after notification_settings table exists.

begin;

create or replace function public.admin_get_notification_setting(
  p_event_type text default 'new_trip'
)
returns jsonb
language plpgsql
security definer
set search_path = public, auth, pg_temp
as $fn$
declare
  v_uid uuid := auth.uid();
  v_event_type text := nullif(trim(coalesce(p_event_type, '')), '');
  v_row public.notification_settings%rowtype;
begin
  if v_uid is null or v_uid <> '51ede91d-ee3f-4a19-8ed4-e1001ceb4e98'::uuid then
    raise exception 'not_authorized' using errcode = '42501';
  end if;

  if v_event_type is null then
    v_event_type := 'new_trip';
  end if;

  select *
    into v_row
  from public.notification_settings
  where event_type = v_event_type;

  if not found then
    return jsonb_build_object(
      'success', false,
      'message', 'إعداد الإشعار غير موجود',
      'event_type', v_event_type
    );
  end if;

  return jsonb_build_object(
    'success', true,
    'event_type', v_row.event_type,
    'title', v_row.title,
    'body', v_row.body,
    'enabled', v_row.enabled,
    'updated_at', v_row.updated_at
  );
end;
$fn$;

create or replace function public.admin_update_notification_setting(
  p_event_type text,
  p_title text,
  p_body text default '',
  p_enabled boolean default true
)
returns jsonb
language plpgsql
security definer
set search_path = public, auth, pg_temp
as $fn$
declare
  v_uid uuid := auth.uid();
  v_event_type text := nullif(trim(coalesce(p_event_type, '')), '');
  v_title text := trim(coalesce(p_title, ''));
  v_body text := trim(coalesce(p_body, ''));
  v_row public.notification_settings%rowtype;
begin
  if v_uid is null or v_uid <> '51ede91d-ee3f-4a19-8ed4-e1001ceb4e98'::uuid then
    raise exception 'not_authorized' using errcode = '42501';
  end if;

  if v_event_type is null then
    raise exception 'event_type_required' using errcode = '22023';
  end if;

  -- Current admin UI is intentionally limited to the new-trip notification.
  if v_event_type <> 'new_trip' then
    raise exception 'unsupported_event_type' using errcode = '22023';
  end if;

  if v_title = '' then
    raise exception 'title_required' using errcode = '22023';
  end if;

  if char_length(v_title) > 120 then
    raise exception 'title_too_long' using errcode = '22023';
  end if;

  if char_length(v_body) > 240 then
    raise exception 'body_too_long' using errcode = '22023';
  end if;

  insert into public.notification_settings (
    event_type,
    title,
    body,
    enabled,
    updated_at
  )
  values (
    v_event_type,
    v_title,
    v_body,
    coalesce(p_enabled, true),
    now()
  )
  on conflict (event_type)
  do update set
    title = excluded.title,
    body = excluded.body,
    enabled = excluded.enabled,
    updated_at = now()
  returning * into v_row;

  return jsonb_build_object(
    'success', true,
    'event_type', v_row.event_type,
    'title', v_row.title,
    'body', v_row.body,
    'enabled', v_row.enabled,
    'updated_at', v_row.updated_at
  );
end;
$fn$;

revoke all on function public.admin_get_notification_setting(text) from public, anon;
revoke all on function public.admin_update_notification_setting(text, text, text, boolean) from public, anon;

grant execute on function public.admin_get_notification_setting(text) to authenticated;
grant execute on function public.admin_update_notification_setting(text, text, text, boolean) to authenticated;

commit;

-- Optional read-only verification after setup:
-- select event_type, title, body, enabled, updated_at
-- from public.notification_settings
-- where event_type = 'new_trip';
