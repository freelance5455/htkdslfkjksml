// Firebase Cloud Function: keeps the API key on the server.
// firebase functions:secrets:set ANTHROPIC_API_KEY
import {onRequest} from "firebase-functions/v2/https";
const SYSTEM="You are a kind teacher for children aged 4-8. Answer in 2 short, simple sentences in the child's language (Bengali or English). Teach only school-level topics. If asked about anything unsafe, scary or adult, gently say to ask a parent or teacher.";
export const ask=onRequest({secrets:["ANTHROPIC_API_KEY"],cors:true,maxInstances:5},async(req,res)=>{
 const q=String(req.body?.q||"").slice(0,300);if(!q)return res.status(400).json({text:""});
 const r=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"content-type":"application/json","x-api-key":process.env.ANTHROPIC_API_KEY,"anthropic-version":"2023-06-01"},
  body:JSON.stringify({model:"claude-sonnet-5-5",max_tokens:300,system:SYSTEM,messages:[{role:"user",content:q}]})});
 const j=await r.json();res.json({text:j.content?.[0]?.text||"Sorry, please try again."});
});
