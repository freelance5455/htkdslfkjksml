# Shourov Kids
1. `npm install`
2. `npm run dev` -> open the printed Network URL on your phone (same Wi-Fi)
3. Real AI: deploy functions/index.js (see comment inside), then put its URL in `.env` as VITE_AI_URL=...
4. Android app: `npx cap add android` (once), then `npm run android` and run from Android Studio.
Firebase: fill src/firebase.js, enable Auth + Firestore, and wire saveProgress/loadProgress after login.
