// Fill in from Firebase console > Project settings > Your apps > Web app
import {initializeApp} from "firebase/app";
import {getAuth} from "firebase/auth";
import {getFirestore,doc,setDoc,getDoc} from "firebase/firestore";
const app=initializeApp({apiKey:"",authDomain:"",projectId:"",storageBucket:"",appId:""});
export const auth=getAuth(app),db=getFirestore(app);
// Not wired into the UI yet: call after login to sync progress.
export const saveProgress=(uid,p)=>setDoc(doc(db,"users",uid),{progress:p},{merge:true});
export const loadProgress=async uid=>(await getDoc(doc(db,"users",uid))).data()?.progress;
