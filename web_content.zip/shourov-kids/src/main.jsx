import React,{useState,useEffect} from "react";
import ReactDOM from "react-dom/client";
import "./style.css";
const h=React.createElement;

const BN=[["অ","অজগর","🐍"],["আ","আম","🥭"],["ই","ইঁদুর","🐭"],["ঈ","ঈগল","🦅"],["উ","উট","🐪"],["ক","কলা","🍌"],["খ","খরগোশ","🐰"],["গ","গরু","🐄"],["ঘ","ঘড়ি","⏰"],["চ","চাঁদ","🌙"],["ফ","ফুল","🌸"],["ম","মাছ","🐟"]];
const EN=[["A","Apple","🍎"],["B","Ball","⚽"],["C","Cat","🐱"],["D","Dog","🐶"],["E","Elephant","🐘"],["F","Fish","🐟"],["G","Grapes","🍇"],["H","Hat","🎩"],["I","Ice cream","🍦"],["J","Juice","🧃"],["K","Kite","🪁"],["L","Lion","🦁"],["M","Moon","🌙"],["N","Nest","🪺"],["O","Orange","🍊"],["P","Pizza","🍕"],["Q","Queen","👸"],["R","Rainbow","🌈"],["S","Sun","☀️"],["T","Tiger","🐯"],["U","Umbrella","☂️"],["V","Violin","🎻"],["W","Watch","⌚"],["X","X-ray","🩻"],["Y","Yo-yo","🪀"],["Z","Zebra","🦓"]];
const BNS="অ|অজগর|🐍,আ|আম|🥭,ই|ইঁদুর|🐭,ঈ|ঈগল|🦅,উ|উট|🐪,ঊ|ঊষা|🌅,ঋ|ঋষি|🧘,এ|একতারা|🎸,ঐ|ঐরাবত|🐘,ও|ওল|🍠,ঔ|ঔষধ|💊,ক|কলা|🍌,খ|খরগোশ|🐰,গ|গরু|🐄,ঘ|ঘড়ি|⏰,ঙ|রঙ|🎨,চ|চাঁদ|🌙,ছ|ছাতা|☂️,জ|জাহাজ|🚢,ঝ|ঝুড়ি|🧺,ঞ|মিঞা|👨,ট|টিয়া|🦜,ঠ|ঠেলাগাড়ি|🛒,ড|ডিম|🥚,ঢ|ঢোল|🥁,ণ|ঘণ্টা|🔔,ত|তরমুজ|🍉,থ|থালা|🍽️,দ|দাঁত|🦷,ধ|ধান|🌾,ন|নৌকা|⛵,প|পাখি|🐦,ফ|ফুল|🌸,ব|বই|📖,ভ|ভাত|🍚,ম|মাছ|🐟,য|যব|🌾,র|রাজা|🤴,ল|লিচু|🍒,শ|শাপলা|🪷,ষ|ষাঁড়|🐂,স|সূর্য|☀️,হ|হাতি|🐘,ড়|ঘোড়া|🐴,ঢ়|আষাঢ়|🌧️,য়|ময়ূর|🦚,ৎ|হঠাৎ|⚡,ং|বাংলা|🇧🇩,ঃ|দুঃখ|😢,ঁ|চাঁদ|🌙";BN.splice(0,BN.length,...BNS.split(",").map(s=>s.split("|")));
const ST=[{t:"The Thirsty Crow",l:"en-US",e:"🐦",x:"A thirsty crow found a jug with a little water inside. The water was too low to reach. The clever crow dropped small stones into the jug, one by one. The water rose up, and the crow drank happily. Moral: clever ideas solve problems."},{t:"খরগোশ ও কচ্ছপ",l:"bn-BD",e:"🐢",x:"এক খরগোশ আর এক কচ্ছপের দৌড় হলো। খরগোশ ভাবল, আমি তো দ্রুত দৌড়াই, একটু ঘুমিয়ে নিই। কচ্ছপ ধীরে ধীরে চলতেই থাকল। শেষে কচ্ছপই জিতল। শিক্ষা: ধৈর্য আর চেষ্টা থাকলে জয় হয়।"}];
const RH=[
 {t:"Twinkle, Twinkle, Little Star",l:"en-US",e:"⭐",x:"Twinkle, twinkle, little star,\nHow I wonder what you are!\nUp above the world so high,\nLike a diamond in the sky."},
 {t:"Humpty Dumpty",l:"en-US",e:"🥚",x:"Humpty Dumpty sat on a wall,\nHumpty Dumpty had a great fall.\nAll the king's horses and all the king's men\nCouldn't put Humpty together again."},
 {t:"আয় আয় চাঁদ মামা",l:"bn-BD",e:"🌙",x:"আয় আয় চাঁদ মামা\nটিপ দিয়ে যা,\nচাঁদের কপালে চাঁদ\nটিপ দিয়ে যা।"},
 {t:"হাট্টিমা টিম টিম",l:"bn-BD",e:"🥚",x:"হাট্টিমা টিম টিম,\nতারা মাঠে পাড়ে ডিম,\nতাদের খাড়া দুটো শিং,\nতারা হাট্টিমা টিম টিম।"}];
const AI=[
 [/sky|আকাশ/i,"আকাশ নীল কারণ সূর্যের আলোর নীল রং বাতাসে সবচেয়ে বেশি ছড়িয়ে যায়। 🌤️","The sky looks blue because the blue part of sunlight scatters the most in the air. 🌤️"],
 [/rainbow|রংধনু|রামধনু/i,"বৃষ্টির ফোঁটায় সূর্যের আলো ভেঙে সাত রং হয়, তাই রংধনু দেখা যায়! 🌈","A rainbow appears when sunlight passes through raindrops and splits into seven colours! 🌈"],
 [/moon|চাঁদ/i,"চাঁদ নিজে আলো দেয় না। সূর্যের আলো লেগে সে ঝলমল করে। 🌙","The moon has no light of its own. It shines by reflecting sunlight. 🌙"],
 [/noun|বিশেষ্য/i,"কোনো মানুষ, প্রাণী বা জিনিসের নামকে বিশেষ্য বলে। যেমন: রহিম, বিড়াল, বই। 📘","A noun is the name of a person, animal or thing. Example: Rahim, cat, book. 📘"],
 [/apple|আপেল/i,"Apple মানে আপেল। A for Apple! 🍎","Apple is a yummy fruit. A is for Apple! 🍎"],
 [/hello|hi\b|হ্যালো|হাই|কেমন/i,"হ্যালো বন্ধু! আমি তোমার শিক্ষক। আমাকে কিছু জিজ্ঞেস করো! 😊","Hello friend! I am your teacher. Ask me anything! 😊"]];
function aiReply(q,bn){
 if(/kill|sex|gun|drug|weapon|খুন|যৌন|অস্ত্র|মদ/i.test(q))return bn?"এটা শিশুদের জন্য নয়। বাবা-মা বা শিক্ষককে জিজ্ঞেস করো। 🤗":"That is not for kids. Please ask a parent or teacher. 🤗";
 const m=q.replace(/[০-৯]/g,d=>"০১২৩৪৫৬৭৮৯".indexOf(d)).match(/(\d+)\s*([+\-x*×])\s*(\d+)/);
 if(m){const a=+m[1],b=+m[3],o=m[2];const r=o=="+"?a+b:o=="-"?a-b:a*b;return (bn?"উত্তর হলো ":"The answer is ")+r+" 🎉"}
 for(const[r,b,e] of AI)if(r.test(q))return bn?b:e;
 return bn?"দারুণ প্রশ্ন! এটা আমার আরও শেখা দরকার। চাঁদ, আকাশ বা যোগ করা জিজ্ঞেস করে দেখো। 🤔":"Great question! I'm still learning that one. Try asking about the sky, the moon or a sum like 2+3. 🤔";
}
let SOUND=true,LANG="bn";const tr=(b,e)=>LANG=="bn"?b:e;
function say(t,l){try{if(!SOUND||!window.speechSynthesis)return;speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang=l;u.rate=.8;speechSynthesis.speak(u)}catch(e){}}
const DEF={done:{},best:0,stars:0,quizzes:0,sound:true,limit:30,ai:true,pin:"1234",lang:"bn",theme:"light",hard:false};
function load(){try{return Object.assign({},DEF,JSON.parse(localStorage.getItem("sk")||"{}"))}catch(e){return{...DEF}}}
function save(p){try{localStorage.setItem("sk",JSON.stringify(p))}catch(e){}}
const shuf=a=>[...a].sort(()=>Math.random()-.5);

function Home({go,p,upd}){
 const cs=[["বাংলা বর্ণমালা","🅰️","#7c4dff",()=>go("learn","bn")],["English ABC","🔤","#2fa8ff",()=>go("learn","en")],["ছড়া Rhymes","🎵","#ff5c9a",()=>go("rhymes")],["Quiz কুইজ","🏆","#ff8a3d",()=>go("quiz")],["AI শিক্ষক","🤖","#22b8a0",()=>go("ai")],["Progress","📈","#8b5cf6",()=>go("profile")]];
 return h("div",null,
  h("div",{className:"top"},h("div",null,h("h2",null,tr("হ্যালো, Shourov! 👋","Hello, Shourov! 👋")),h("div",{style:{color:"var(--mute)"}},tr("চলো আজ শিখি","Let's learn today"))),h("div",{style:{display:"flex",gap:6}},h("button",{className:"pill tb",onClick:()=>upd({lang:p.lang=="bn"?"en":"bn"})},p.lang=="bn"?"EN":"বাং"),h("button",{className:"pill tb",onClick:()=>upd({theme:p.theme=="dark"?"light":"dark"})},p.theme=="dark"?"☀️":"🌙"),h("div",{className:"pill"},"⭐ "+p.stars))),
  h("div",{className:"grid"},cs.map((c,i)=>h("button",{key:i,className:"card",style:{background:c[2],animationDelay:i*60+"ms"},onClick:c[3]},h("div",{className:"e"},c[1]),h("span",null,c[0])))));
}
function Detail({list,i,setI,lang,p,mark}){
 const[l,w,e]=list[i];
 useEffect(()=>{say(l+". "+w,lang)},[i]);
 return h("div",{className:"box big",key:i},
  h("div",{className:"l"},lang=="en-US"?l+l.toLowerCase():l),h("div",{className:"pic"},e),h("div",{className:"w"},w),
  h("button",{className:"btn o",onClick:()=>say(l+". "+w,lang)},"🔊 শোনো / Listen"),h(Trace,{ch:lang=="en-US"?l+l.toLowerCase():l,key:l}),
  h("button",{className:"btn g",onClick:()=>mark(lang+l)},p.done[lang+l]?"✅ শেখা হয়েছে":"✔ I learned it"),
  h("div",{className:"row",style:{marginTop:10}},
   h("button",{className:"btn gray",onClick:()=>setI((i+list.length-1)%list.length)},"◀"),
   h("button",{className:"btn gray",onClick:()=>setI((i+1)%list.length)},"▶")));
}
function Trace({ch}){
 const ref=React.useRef(null),dn=React.useRef(false);
 const draw=()=>{const c=ref.current;if(!c)return;const x=c.getContext("2d");x.clearRect(0,0,300,200);x.font="bold "+(ch.length>1?120:170)+"px system-ui,sans-serif";x.textAlign="center";x.textBaseline="middle";x.fillStyle="rgba(124,77,255,.2)";x.fillText(ch,150,105)};
 useEffect(draw,[ch]);
 const pt=e=>{const r=ref.current.getBoundingClientRect();return[(e.clientX-r.left)*300/r.width,(e.clientY-r.top)*200/r.height]};
 const mv=e=>{if(!dn.current)return;const x=ref.current.getContext("2d"),[a,b]=pt(e);x.lineTo(a,b);x.strokeStyle="#ff5c9a";x.lineWidth=12;x.lineCap="round";x.lineJoin="round";x.stroke();x.beginPath();x.moveTo(a,b)};
 return h("div",{className:"box",style:{padding:8,marginTop:10}},h("div",{style:{fontWeight:700,marginBottom:6}},tr("✏️ আঙুল দিয়ে লেখো","✏️ Trace with your finger")),h("canvas",{ref,width:300,height:200,style:{width:"100%",touchAction:"none",borderRadius:16,background:"var(--bg)"},onPointerDown:e=>{dn.current=true;ref.current.setPointerCapture(e.pointerId);const x=ref.current.getContext("2d"),[a,b]=pt(e);x.beginPath();x.moveTo(a,b)},onPointerMove:mv,onPointerUp:()=>{dn.current=false}}),h("button",{className:"btn gray",onClick:draw},"🧽 "+tr("মুছে ফেলো","Clear")));
}
function Rhymes({p,mark}){
 const L=[...RH,...ST],[r,setR]=useState(null),[s,setS]=useState("idle"),ok=!!window.speechSynthesis;
 const stop=()=>{try{speechSynthesis.cancel()}catch(e){}setS("idle")};
 const play=()=>{if(!ok)return;stop();const u=new SpeechSynthesisUtterance(L[r].x.replace(/\n/g," "));u.lang=L[r].l;u.rate=.8;u.onend=()=>setS("idle");u.onerror=()=>setS("idle");speechSynthesis.speak(u);setS("play");mark("x"+r)};
 const pause=()=>{if(s=="play"){speechSynthesis.pause();setS("pause")}else if(s=="pause"){speechSynthesis.resume();setS("play")}};
 if(r===null)return h("div",null,h("h2",{style:{marginBottom:10}},tr("🎵 ছড়া ও গল্প","🎵 Rhymes & Stories")),L.map((x,k)=>h("button",{key:k,className:"opt",onClick:()=>setR(k)},x.e+" "+x.t+(k>=RH.length?" 📖":""))));
 const x=L[r];
 return h("div",{className:"box big"},h("div",{className:"pic"},x.e),h("h3",null,x.t),h("p",{style:{whiteSpace:"pre-line",fontSize:20,lineHeight:1.5,textAlign:"left"}},x.x),!ok&&h("p",{style:{color:"#ef4444"}},tr("এই ফোনে অডিও চলে না।","Audio isn't supported on this device.")),h("div",{className:"row"},h("button",{className:"btn g",disabled:!ok,onClick:play},s=="idle"?"▶":"🔁"),h("button",{className:"btn o",disabled:!ok||s=="idle",onClick:pause},s=="pause"?"▶":"⏸"),h("button",{className:"btn gray",onClick:stop},"⏹")),h("button",{className:"btn gray",onClick:()=>{stop();setR(null)}},tr("⬅ ফিরে যাও","⬅ Back")));
}
function Learn({p,mark,tab,setTab}){
 const[i,setI]=useState(null),[r,setR]=useState(null);
 const list=tab=="bn"?BN:EN,lang=tab=="bn"?"bn-BD":"en-US";
 return h("div",null,
  h("h2",{style:{marginBottom:10}},tr("📚 শেখো","📚 Learn")),
  h("div",{className:"seg"},[["bn","অ আ"],["en","A B C"]].map(([k,t])=>h("button",{key:k,className:tab==k?"on":"",onClick:()=>{setTab(k);setI(null);setR(null)}},t))),
  tab=="rh"?(r===null?RH.map((x,k)=>h("button",{key:k,className:"opt",onClick:()=>setR(k)},x.e+" "+x.t)):
    h("div",{className:"box big"},h("div",{className:"pic"},RH[r].e),h("h3",null,RH[r].t),
     h("p",{style:{whiteSpace:"pre-line",fontSize:22,lineHeight:1.5}},RH[r].x),
     h("button",{className:"btn o",onClick:()=>say(RH[r].x.replace(/\n/g," "),RH[r].l)},"▶ Play / শোনো"),
     h("button",{className:"btn gray",onClick:()=>{try{speechSynthesis.cancel()}catch(e){};setR(null)}},"⬅ Back"))):
  i===null?h("div",{className:"tiles"},list.map((x,k)=>h("button",{key:k,className:"tile"+(p.done[lang+x[0]]?" d":""),onClick:()=>setI(k)},x[0],p.done[lang+x[0]]&&h("i",null,"✅")))):
  h("div",null,h(Detail,{list,i,setI,lang,p,mark}),h("button",{className:"btn gray",onClick:()=>setI(null)},"⬅ All letters")));
}
function Quiz({p,upd}){
 const[qs,setQs]=useState(null),[n,setN]=useState(0),[sub,setSub]=useState("mix"),[d,setD]=useState(1),[sc,setSc]=useState(0),[pick,setPick]=useState(null);
 const start=()=>{const all=[...(sub!="en"?BN.map(x=>[...x,"bn-BD"]):[]),...(sub!="bn"?EN.map(x=>[...x,"en-US"]):[])];
  setQs(shuf(all).slice(0,5).map(c=>{const pool=all.filter(x=>x[3]==c[3]&&x[0]!=c[0]);return{c,o:shuf([c,...shuf(pool).slice(0,d+1)])}}));setN(0);setSc(0);setPick(null)};
 if(!qs)return h("div",{className:"box big"},h("div",{className:"pic"},"🏆"),h("h2",null,"Quiz Time!"),h("p",null,"Best: "+"⭐".repeat(p.best)+" ("+p.best+"/5)"),h("div",{className:"seg"},[["bn",tr("বাংলা","Bengali")],["en","English"],["mix",tr("মিশ্র","Mixed")]].map(([k,t])=>h("button",{key:k,className:sub==k?"on":"",onClick:()=>setSub(k)},t))),h("div",{className:"seg"},[tr("সহজ","Easy"),tr("মাঝারি","Medium"),tr("কঠিন","Hard")].map((t,k)=>h("button",{key:k,className:d==k?"on":"",onClick:()=>setD(k)},t))),h("button",{className:"btn",onClick:start},tr("▶ শুরু করো","▶ Start Quiz")));
 if(n>=qs.length){const st=sc;return h("div",{className:"box big"},h("div",{className:"pic"},st>=4?"🥇":st>=2?"🥈":"🌱"),h("h2",null,"Score: "+sc+"/5"),h("div",{style:{fontSize:36}},"⭐".repeat(sc)||"—"),h("p",null,st>=4?"অসাধারণ! Super job!":"ভালো চেষ্টা! Try again!"),h("button",{className:"btn",onClick:start},"🔁 Play again"))}
 const q=qs[n],c=q.c;
 const ans=o=>{if(pick)return;setPick(o[0]);const ok=o[0]==c[0];if(ok)setSc(sc+1);say(ok?(c[3]=="bn-BD"?"শাবাশ":"Great job"):(c[3]=="bn-BD"?"আবার চেষ্টা করো":"Try again"),c[3]);
  setTimeout(()=>{const last=n==4;if(last)upd({stars:p.stars+sc+(ok?1:0),best:Math.max(p.best,sc+(ok?1:0)),quizzes:p.quizzes+1,hard:p.hard||(d==2&&sc+(ok?1:0)>=4)});setN(n+1);setPick(null)},1100)};
 return h("div",{key:n},h("div",{className:"bar"},h("div",{style:{width:(n/5*100)+"%"}})),
  h("div",{className:"box big"},h("div",{style:{color:"var(--mute)"}},"Question "+(n+1)+"/5"),h("div",{className:"pic"},c[2]),h("h3",null,c[3]=="bn-BD"?"এর প্রথম অক্ষর কোনটি?":"Which letter starts this word?"),h("button",{className:"btn o",onClick:()=>say(c[1],c[3])},"🔊")),
  q.o.map(o=>h("button",{key:o[0],className:"opt"+(pick?(o[0]==c[0]?" ok":o[0]==pick?" no":""):""),onClick:()=>ans(o)},o[0])));
}
function Teacher({p}){
 const[bn,setBn]=useState(true),[t,setT]=useState(""),[ms,setMs]=useState([{a:1,x:"হ্যালো! Hello! Ask me anything 😊"}]);
 if(!p.ai)return h("div",{className:"box big"},h("div",{className:"pic"},"🔒"),h("h3",null,"AI Teacher is off"),h("p",null,"Ask a parent to turn it on."));
 const send=async(q)=>{q=(q||t).trim();if(!q)return;setMs(m=>[...m,{x:q}]);setT("");let r;const U=import.meta.env.VITE_AI_URL;try{r=U?(await(await fetch(U,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({q,lang:bn?"bn":"en"})})).json()).text:aiReply(q,bn)}catch(e){r=bn?"ইন্টারনেটে সমস্যা। আবার চেষ্টা করো।":"Network problem. Please try again."}setMs(m=>[...m,{a:1,x:r}]);say(r.replace(/[^\p{L}\p{N}\s.,!?]/gu,""),bn?"bn-BD":"en-US")};
 const mic=()=>{const R=window.SpeechRecognition||window.webkitSpeechRecognition;if(!R)return setMs(m=>[...m,{a:1,x:bn?"এই ফোনে মাইক চলে না। লিখে প্রশ্ন করো।":"Voice input isn't supported here. Please type."}]);const r=new R();r.lang=bn?"bn-BD":"en-US";r.onresult=e=>send(e.results[0][0].transcript);r.onerror=()=>setMs(m=>[...m,{a:1,x:bn?"শুনতে পাইনি, আবার চেষ্টা করো।":"I couldn't hear you. Try again."}]);r.start()};
 return h("div",null,h("div",{style:{fontSize:64,textAlign:"center",animation:"bob 2s infinite"}},"🦉"),h("h2",{style:{marginBottom:10,textAlign:"center"}},tr("🤖 AI শিক্ষক","🤖 AI Teacher")),
  h("div",{className:"seg"},h("button",{className:bn?"on":"",onClick:()=>setBn(true)},"বাংলা"),h("button",{className:!bn?"on":"",onClick:()=>setBn(false)},"English")),
  h("div",null,["আকাশ নীল কেন?","Why is the sky blue?","2+3","What is a noun?"].map(s=>h("button",{key:s,className:"chip",onClick:()=>send(s)},s))),
  h("div",{className:"chat"},ms.map((m,i)=>h("div",{key:i,className:"m "+(m.a?"a":"u")},m.x))),
  h("div",{className:"row"},h("input",{value:t,placeholder:bn?"প্রশ্ন লেখো...":"Type a question...",onChange:e=>setT(e.target.value),onKeyDown:e=>e.key=="Enter"&&send()}),h("button",{className:"btn o",onClick:mic},"🎤"),h("button",{className:"btn",onClick:()=>send()},"➤")));
}
function Sw({label,on,set}){return h("div",{className:"sw"},h("span",null,label),h("button",{className:on?"on":"",onClick:()=>set(!on)}))}
function Parent({p,upd,back}){
 const[pin,setPin]=useState(""),[ok,setOk]=useState(false);
 if(!ok)return h("div",{className:"box big"},h("div",{className:"pic"},"👨‍👩‍👦"),h("h3",null,"Parent Area"),h("p",null,"Enter PIN (demo: 1234)"),
  h("div",{className:"row"},h("input",{type:"password",inputMode:"numeric",maxLength:4,value:pin,onChange:e=>setPin(e.target.value)}),h("button",{className:"btn",onClick:()=>pin==p.pin?setOk(true):setPin("")},"OK")),
  h("button",{className:"btn gray",onClick:back},"⬅ Back"));
 const tot=BN.length+EN.length,dn=Object.keys(p.done).filter(k=>"be".includes(k[0])).length;
 return h("div",null,h("h2",{style:{marginBottom:10}},"👨‍👩‍👦 Parent Section"),
  h("div",{className:"box"},h("b",null,"Learning progress"),h("div",{className:"bar"},h("div",{style:{width:dn/tot*100+"%"}})),h("div",null,dn+" of "+tot+" letters learned · "+p.quizzes+" quizzes · best "+p.best+"/5")),
  h("div",{className:"box"},h("b",null,"Parental controls"),
   h(Sw,{label:"🔊 Sound & audio",on:p.sound,set:v=>upd({sound:v})}),
   h(Sw,{label:"🤖 AI Teacher",on:p.ai,set:v=>upd({ai:v})}),
   h("div",{className:"sw"},h("span",null,"⏱ Daily limit: "+p.limit+" min"),h("span",null,[15,30,60].map(m=>h("button",{key:m,className:"chip",style:{margin:2,background:p.limit==m?"var(--p)":"",color:p.limit==m?"#fff":""},onClick:()=>upd({limit:m})},m))))),
  h("button",{className:"btn",onClick:()=>{if(confirm("Reset all progress?"))upd({done:{},best:0,stars:0,quizzes:0})}},"🗑 Reset progress"),
  h("button",{className:"btn gray",onClick:back},"⬅ Back"));
}
function Profile({p,upd}){
 const[par,setPar]=useState(false);
 if(par)return h(Parent,{p,upd,back:()=>setPar(false)});
 const dn=Object.keys(p.done).length,bnD=Object.keys(p.done).filter(k=>k[0]=="b").length,enD=Object.keys(p.done).filter(k=>k[0]=="e").length;
 const ach=[["🌱","First letter",dn>=1],["📘","10 letters",dn>=10],["🎓","All Bengali",bnD>=BN.length],["🔤","All A–Z",enD>=EN.length],["🏆","Perfect quiz",p.best==5],["⭐","10 stars",p.stars>=10],["🔥","Hard quiz",p.hard],["🎵","Rhyme fan",Object.keys(p.done).some(k=>k[0]=="x")]];
 return h("div",null,h("div",{className:"box big"},h("div",{className:"pic"},"🧒"),h("h2",null,"Shourov"),h("div",{style:{fontSize:26}},"⭐ "+p.stars+" stars")),
  h("div",{className:"box"},h("b",null,"বাংলা "+bnD+"/"+BN.length),h("div",{className:"bar"},h("div",{style:{width:bnD/BN.length*100+"%"}})),h("b",null,"English "+enD+"/"+EN.length),h("div",{className:"bar"},h("div",{style:{width:enD/EN.length*100+"%"}})),h("div",null,dn+" lessons · Quizzes played: "+p.quizzes+" · Best: "+p.best+"/5")),
  h("div",{className:"box"},h("b",null,"🏅 Achievements"+(ach.some(a=>a[2])?"":" — "+tr("প্রথম ব্যাজ জিততে একটি পাঠ শেখো!","learn a lesson to earn your first badge!"))),h("div",{className:"grid",style:{marginTop:10}},ach.map(a=>h("div",{key:a[1],style:{textAlign:"center",opacity:a[2]?1:.35,fontWeight:700}},h("div",{style:{fontSize:38}},a[0]),a[1])))),
  h("button",{className:"btn o",onClick:()=>setPar(true)},"🔐 Parent Section"));
}
function App(){
 const[p,setP]=useState(load),[tab,setTab]=useState(()=>load().tab||"home"),[sub,setSub]=useState(()=>load().sub||"bn"),[rd,setRd]=useState(false),[used,setUsed]=useState(0),[unl,setUnl]=useState(false);
 SOUND=p.sound;LANG=p.lang;useEffect(()=>{document.documentElement.dataset.theme=p.theme},[p.theme]);useEffect(()=>{const t=setTimeout(()=>setRd(true),600);return()=>clearTimeout(t)},[]);
 const upd=o=>setP(q=>{const n={...q,...o};save(n);return n});
 useEffect(()=>{const t=setInterval(()=>setUsed(u=>u+1),60000);return()=>clearInterval(t)},[]);
 useEffect(()=>{upd({tab,sub})},[tab,sub]);const go=(t,s)=>{if(s)setSub(s);setTab(t)};
 const mark=k=>upd({done:{...p.done,[k]:1},stars:p.done[k]?p.stars:p.stars+1});
 const locked=used>=p.limit&&!unl;
 const body=tab=="home"?h(Home,{go,p,upd}):tab=="learn"?h(Learn,{p,mark,tab:sub,setTab:setSub}):tab=="quiz"?h(Quiz,{p,upd}):tab=="rhymes"?h(Rhymes,{p,mark}):tab=="ai"?h(Teacher,{p}):h(Profile,{p,upd});
 return h(React.Fragment,null,
  locked&&h("div",{className:"lock"},h("div",{style:{fontSize:80}},"😴"),h("h2",null,"বিশ্রামের সময়! Time to rest"),h("p",null,"Daily limit reached. Parents can unlock."),h("button",{className:"btn",onClick:()=>{if(prompt("Parent PIN")==p.pin)setUnl(true)}},"🔐 Parent unlock")),
  h("main",{key:tab},rd?body:h("div",{className:"sp"})),
  h("nav",{className:"nav"},[["home","🏠","হোম","Home"],["learn","📚","শেখো","Learn"],["quiz","🎯","কুইজ","Quiz"],["rhymes","🎵","ছড়া","Rhymes"],["profile","🧒","প্রোফাইল","Profile"]].map(([k,e,b,en])=>h("button",{key:k,className:tab==k?"on":"",onClick:()=>go(k)},h("b",null,e),tr(b,en)))));
}
ReactDOM.createRoot(document.getElementById("root")).render(h(App));
