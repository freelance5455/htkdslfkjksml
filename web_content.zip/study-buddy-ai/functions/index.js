const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const logger = require("firebase-functions/logger");
const admin = require("firebase-admin");
const OpenAI = require("openai");

admin.initializeApp();
const db = admin.firestore();
const openAiKey = defineSecret("OPENAI_API_KEY");

function requireVerifiedUser(request) {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Please sign in first.");
  }
  if (request.auth.token.email_verified !== true) {
    throw new HttpsError("failed-precondition", "Verify your email before using this feature.");
  }
  return request.auth.uid;
}

exports.issueStudentId = onCall({ region: "asia-south1", enforceAppCheck: false }, async (request) => {
  const uid = requireVerifiedUser(request);
  const email = String(request.auth.token.email || "").toLowerCase();
  const displayName = String(request.auth.token.name || "Student").slice(0, 80);
  const userRef = db.collection("users").doc(uid);
  const counterRef = db.collection("system").doc("studentIdCounter");

  try {
    const studentId = await db.runTransaction(async (tx) => {
      const existing = await tx.get(userRef);
      if (existing.exists && existing.get("studentId")) {
        return existing.get("studentId");
      }

      const counterSnap = await tx.get(counterRef);
      const next = (counterSnap.exists ? Number(counterSnap.get("lastNumber") || 0) : 0) + 1;
      tx.set(counterRef, { lastNumber: next }, { merge: true });
      const id = `SBA-${new Date().getUTCFullYear()}-${String(next).padStart(8, "0")}`;
      tx.set(userRef, {
        uid,
        email,
        displayName,
        studentId: id,
        emailVerified: true,
        createdAt: existing.exists && existing.get("createdAt")
          ? existing.get("createdAt") : admin.firestore.FieldValue.serverTimestamp(),
        updatedAt: admin.firestore.FieldValue.serverTimestamp()
      }, { merge: true });
      return id;
    });
    return { studentId };
  } catch (err) {
    logger.error("Could not issue Student ID", { uid, message: err.message });
    throw new HttpsError("internal", "Could not create your Student ID. Please try again.");
  }
});

exports.askTutor = onCall({
  region: "asia-south1",
  secrets: [openAiKey],
  timeoutSeconds: 60,
  memory: "256MiB",
  enforceAppCheck: false
}, async (request) => {
  const uid = requireVerifiedUser(request);
  const message = typeof request.data?.message === "string" ? request.data.message.trim() : "";
  if (!message) throw new HttpsError("invalid-argument", "Enter a question first.");
  if (message.length > 4000) throw new HttpsError("invalid-argument", "Your question must be 4,000 characters or fewer.");

  const profile = await db.collection("users").doc(uid).get();
  if (!profile.exists || !profile.get("studentId")) {
    throw new HttpsError("failed-precondition", "Your student profile is not ready. Refresh your dashboard.");
  }

  // Simple server-side per-user rate limit: 10 requests in a rolling minute window.
  const limitRef = db.collection("rateLimits").doc(uid);
  const now = Date.now();
  try {
    await db.runTransaction(async (tx) => {
      const snap = await tx.get(limitRef);
      const old = snap.exists ? snap.data() : {};
      const windowStart = Number(old.windowStart || 0);
      const count = windowStart > now - 60_000 ? Number(old.count || 0) : 0;
      if (count >= 10) throw new HttpsError("resource-exhausted", "You've sent 10 questions in a minute. Please wait and try again.");
      tx.set(limitRef, { windowStart: count === 0 ? now : windowStart, count: count + 1 });
    });
  } catch (err) {
    if (err instanceof HttpsError) throw err;
    logger.error("Rate limit transaction failed", { uid, message: err.message });
    throw new HttpsError("internal", "Please try again in a moment.");
  }

  try {
    const client = new OpenAI({ apiKey: openAiKey.value(), timeout: 45000, maxRetries: 1 });
    const response = await client.responses.create({
      model: "gpt-5.4-mini",
      instructions: [
        "You are Study Buddy AI, a kind, accurate, age-appropriate study tutor.",
        "Explain concepts clearly and adapt to the student's level.",
        "For maths and science, show steps and check units where relevant.",
        "Encourage learning rather than simply doing graded work dishonestly; help the student understand.",
        "If a question is ambiguous, ask one concise clarifying question.",
        "Do not request passwords, home addresses, or other sensitive personal information.",
        "Keep answers organized and reasonably concise. Use plain text and Markdown."
      ].join(" "),
      input: message,
      max_output_tokens: 900,
      store: false
    });
    const answer = String(response.output_text || "").trim();
    if (!answer) throw new Error("Empty model response");
    return { answer };
  } catch (err) {
    logger.error("AI request failed", { uid, message: err.message, status: err.status });
    throw new HttpsError("unavailable", "The AI tutor is temporarily unavailable. Please try again shortly.");
  }
});
