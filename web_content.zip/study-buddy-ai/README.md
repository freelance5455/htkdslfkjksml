# Study Buddy AI — Firebase + AI tutor

A responsive mobile-first web app intended to be edited on Android (for example, in Spck Editor) and deployed with Firebase Hosting. It includes Firebase email/password authentication, email verification, a server-issued unique Student ID, and an AI tutor backed by the OpenAI Responses API.

## Important setup notes

- You must create your own Firebase project and OpenAI API key. This project cannot be live until those values are configured and deployed.
- Never place the OpenAI API key in `index.html`, an Android client, or a public repository. It is stored as a Firebase Functions secret.
- The generated `SBA-YYYY-########` ID is an app account ID, not proof that a person attends a real school or college. This app does not validate external school records.
- Firebase Blaze billing is normally required for deployed Cloud Functions. OpenAI API usage may cost money separately. Set billing alerts and usage limits before sharing the app.
- The app uses email verification, not school-issued identity verification. Don't collect student documents unless you add a carefully designed, privacy-compliant process.

## 1. Create Firebase project

1. Open https://console.firebase.google.com/ and create a project.
2. Add a **Web app** in Project settings and copy its Firebase configuration.
3. In `index.html`, replace all six `PASTE_...` values in `firebaseConfig` with your real values.
4. In Firebase Console → Authentication → Sign-in method, enable **Email/Password**.
5. In Authentication → Settings → Authorized domains, make sure your deployed Hosting domain is listed.
6. Create a Cloud Firestore database in production mode.
7. In the project root, install Firebase CLI on a computer with Node.js:
   ```bash
   npm install -g firebase-tools
   firebase login
   firebase use --add
   ```
   Select your project when prompted.

## 2. Configure the OpenAI key

Create an API key in your OpenAI API account. API usage is billed separately from ChatGPT subscriptions.

From the project root, run:
```bash
firebase functions:secrets:set OPENAI_API_KEY
```
Paste the key when prompted. Do not add the key to any frontend file or commit it to Git.

The function uses the `gpt-5.4-mini` model with the OpenAI Responses API. If your API project does not have access to that model, change the `model` value in `functions/index.js` to a model available to your API account.

## 3. Deploy

From the project root:
```bash
npm install -g firebase-tools
cd functions
npm install
cd ..
firebase deploy --only firestore:rules,functions,hosting
```
If prompted, enable the required APIs and billing. The CLI will print the Hosting URL when deployment completes.

## 4. Test on Android

1. Open the deployed Hosting URL in Chrome on your Android phone.
2. Create an account with an email address you can access.
3. Open the Firebase verification email and tap the link.
4. Return to the app and sign in again if needed. Your Student ID should appear after the server verifies your email.
5. Ask a question in the AI tutor.

You can edit `index.html` with Spck Editor, but Firebase Cloud Functions are server-side Node.js code and must be deployed with Firebase CLI. Spck alone cannot deploy the backend.

## 5. How the safeguards work

- Firebase Authentication handles password storage and email verification.
- The backend checks the signed-in Firebase user's `email_verified` claim.
- Student IDs are assigned in a Firestore transaction, preventing duplicate sequence numbers and repeated IDs for the same account.
- Firestore rules prevent client-side profile or counter writes.
- The OpenAI key is a Firebase secret and never sent to the browser.
- The AI callable checks for a verified user and issued Student ID, limits each user to 10 requests per minute, and limits prompts to 4,000 characters.

## 6. Before public launch

This is a starter implementation, not a completed production security review. Before sharing publicly, consider enabling Firebase App Check, adding abuse monitoring and stricter cost limits, testing recovery and account deletion flows, reviewing privacy disclosures, and setting appropriate retention policies. The current simple rate limiter is useful as a baseline but should be upgraded for high-traffic deployments.

## Files

- `index.html` — responsive frontend, authentication UI, dashboard, chatbot
- `functions/index.js` — server-side Student ID generation and AI API proxy
- `firestore.rules` — denies client writes to protected data
- `firebase.json` — Hosting, Functions and Firestore deployment config
