Offline Billing - Android converter package
Entry point: index.html
This package is prepared for ZIP-to-APK converters that accept local HTML/CSS/JS assets.
Keep all files in this ZIP together when uploading.
