# 保险计算器 Android 项目

应用名称：保险计算器  
版本：1.0  
功能：离线运行、底池输入、1–15 Outs 赔率选择、赔率自定义、自动计算买满金额、赔率本地保存。

## 构建 APK
本项目包含 GitHub Actions 自动构建配置：
1. 将整个项目上传到自己的 GitHub 仓库（项目根目录直接包含 `settings.gradle`、`build.gradle`、`app/`）。
2. 打开仓库的 Actions，选择 **Build Insurance Calculator APK**，点击 **Run workflow**。
3. 构建成功后，在该次运行的 Artifacts 中下载 `insurance-calculator-apk`。
4. 解压后安装 `app-debug.apk`。

应用通过 Android WebView 加载内置的本地 HTML 文件，不需要网络权限，也不依赖外部网页地址。
