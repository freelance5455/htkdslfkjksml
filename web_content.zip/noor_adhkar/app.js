(() => {
"use strict";
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const main = $("#appMain"), view = $("#contentView"), toastEl = $("#toast");
const storeKey = "noor-adhkar-v1";
const defaults = {theme:"light",favorites:[],progress:{},counts:{},tasbeeh:0,totalTasbeeh:0,phrase:"سبحان الله وبحمده",fontSize:19};
let state = loadState(), currentView = "home", currentMode = "morning", favFilter = "all", toastTimer;
function loadState(){try{return {...defaults,...JSON.parse(localStorage.getItem(storeKey)||"{}")}}catch(e){return {...defaults}}}
function save(){try{localStorage.setItem(storeKey,JSON.stringify(state))}catch(e){notify("تعذر الحفظ على هذا المتصفح")}}
function notify(msg){toastEl.textContent=msg;toastEl.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastEl.classList.remove("show"),2200)}
function allItems(){return [...ADHKAR.morning,...ADHKAR.evening,...ADHKAR.categories]}
function itemById(id){return allItems().find(x=>x.id===id)}
function isFav(id){return state.favorites.includes(id)}
function progressKey(mode,id){return mode+":"+id}
function getCount(mode,id){return Number(state.progress[progressKey(mode,id)]||0)}
function completed(mode,item){return getCount(mode,item.id)>=item.count}
function totals(mode){let items=ADHKAR[mode]||[];return {done:items.filter(x=>completed(mode,x)).length,total:items.length,percent:items.length?Math.round(items.filter(x=>completed(mode,x)).length/items.length*100):0}}
function updateHomeProgress(){let a=totals("morning"),b=totals("evening"),total=a.total+b.total,done=a.done+b.done;$("#dailyPercent").textContent=(total?Math.round(done/total*100):0)+"%";$("#dailyText").textContent=done===total?"ما شاء الله، أتممت وردك اليوم":done?"أحسنت، واصل وردك بهدوء":"ابدأ يومك بذكر الله";$("#dailyBar").style.width=(total?done/total*100:0)+"%";$("#morningProgress").textContent=`الصباح ${a.done}/${a.total}`;$("#eveningProgress").textContent=`المساء ${b.done}/${b.total}`}
function setTheme(){document.body.classList.toggle("night",state.theme==="night");$("#themeToggle").textContent=state.theme==="night"?"☀":"◐"}
function showView(name){currentView=name;main.classList.toggle("hidden",name!=="home");view.classList.toggle("hidden",name==="home");$$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view===name||(name==="adhkar"&&b.dataset.view==="adhkar")));if(name==="home"){window.scrollTo({top:0,behavior:"smooth"});return}renderView();window.scrollTo({top:0,behavior:"smooth"})}
function head(title,sub=""){return `<div class="view-head"><button class="back-btn" data-view="home" aria-label="رجوع">›</button><div><h1>${title}</h1><p>${sub}</p></div></div>`}
function renderView(){
 if(currentView==="adhkar")renderAdhkar(); else if(currentView==="favorites")renderFavorites();else if(currentView==="tasbeeh")renderTasbeeh();else if(currentView==="settings")renderSettings();else if(currentView==="categories")renderCategories();
}
function card(item,mode){
 let n=getCount(mode,item.id),done=n>=item.count;
 return `<article class="dhikr-card" id="card-${item.id}"><div class="dhikr-meta"><span class="dhikr-number">${item.count}×</span><span class="dhikr-category">${item.title}</span></div><p class="dhikr-text" style="font-size:${state.fontSize||19}px">${item.text}</p><p class="dhikr-source">المصدر: ${item.source}</p><div class="dhikr-actions"><button class="small-btn ${isFav(item.id)?"fav-on":""}" data-fav="${item.id}" aria-label="المفضلة">${isFav(item.id)?"♥":"♡"} حفظ</button><button class="small-btn" data-copy="${item.id}">▣ نسخ</button><span class="count-badge">${Math.min(n,item.count)}/${item.count}</span><button class="repeat-btn ${done?"done":""}" data-count="${mode}|${item.id}">${done?"✓ اكتمل":"تسبيح +1"}</button></div></article>`;
}
function renderAdhkar(){
 const items=ADHKAR[currentMode],t=totals(currentMode);
 view.innerHTML=head("الأذكار",currentMode==="morning"?"أذكار الصباح من القرآن والسنة":"أذكار المساء من القرآن والسنة")+`<div class="mode-tabs"><button data-mode="morning" class="${currentMode==="morning"?"selected":""}">☀ أذكار الصباح</button><button data-mode="evening" class="${currentMode==="evening"?"selected":""}">☾ أذكار المساء</button></div><div class="list-progress"><p><strong>تقدم الورد</strong><span>${t.done} من ${t.total} · ${t.percent}%</span></p><div class="progress-track"><span style="width:${t.percent}%"></span></div></div>${items.map(x=>card(x,currentMode)).join("")}<p class="dhikr-source">تنبيه: هذه نسخة أولية مختارة وليست حصرًا لكل الأذكار الواردة.</p>`;
}
function renderFavorites(){
 const items=allItems().filter(x=>isFav(x.id));
 view.innerHTML=head("المفضلة","أذكارك التي حفظتها")+`<div class="mode-tabs"><button data-favfilter="all" class="${favFilter==="all"?"selected":""}">الكل</button><button data-favfilter="morning" class="${favFilter==="morning"?"selected":""}">الصباح</button><button data-favfilter="evening" class="${favFilter==="evening"?"selected":""}">المساء</button><button data-favfilter="categories" class="${favFilter==="categories"?"selected":""}">أدعية</button></div>${items.filter(x=>favFilter==="all"||x.id.startsWith(favFilter==="morning"?"m":favFilter==="evening"?"e":"c")).map(x=>card(x,x.id.startsWith("e")?"evening":"morning")).join("")||`<div class="empty-state"><strong>لا توجد أذكار محفوظة بعد</strong>اضغط على ♡ بجانب أي ذكر لإضافته هنا.</div>`}`;
}
function renderTasbeeh(){
 view.innerHTML=head("المسبحة","لحظات هادئة مع ذكر الله")+`<div class="tasbeeh-wrap"><h2>مسبحتك الإلكترونية</h2><p>اضغط على الزر بعد كل تسبيحة</p><div class="beads"><div class="bead-inner"><strong id="tasbeehCount">${state.tasbeeh}</strong><small>مرة</small></div></div><button class="tasbeeh-main" id="tasbeehAdd">${state.phrase}　＋</button><div class="tasbeeh-controls"><button id="tasbeehReset">↻ إعادة التعيين</button><button id="phraseChange">✧ تغيير الذكر</button></div></div><div class="stats-grid"><div class="stat"><strong id="statSession">${state.tasbeeh}</strong><small>العدد الحالي</small></div><div class="stat"><strong id="statTotal">${state.totalTasbeeh}</strong><small>إجمالي التسبيحات</small></div><div class="stat"><strong>${state.tasbeeh%33}</strong><small>من دورة 33</small></div></div>`;
}
function renderSettings(){
 view.innerHTML=head("الإعدادات","خصص التطبيق بما يناسبك")+`<div class="setting-row"><span class="setting-icon">◐</span><div class="setting-copy"><strong>المظهر الليلي</strong><small>راحة للعين في الإضاءة المنخفضة</small></div><label class="switch"><input type="checkbox" id="nightSwitch" ${state.theme==="night"?"checked":""}><span></span></label></div><div class="setting-row"><span class="setting-icon">Aa</span><div class="setting-copy"><strong>حجم خط الأذكار</strong><small>اختر حجمًا مريحًا للقراءة</small></div><select id="fontSelect"><option value="17" ${state.fontSize===17?"selected":""}>صغير</option><option value="19" ${(!state.fontSize||state.fontSize===19)?"selected":""}>متوسط</option><option value="22" ${state.fontSize===22?"selected":""}>كبير</option><option value="25" ${state.fontSize===25?"selected":""}>كبير جدًا</option></select></div><div class="setting-row"><span class="setting-icon">▣</span><div class="setting-copy"><strong>البيانات المحفوظة</strong><small>تقدمك ومفضلاتك محفوظة على هذا الجهاز</small></div><button class="small-btn" id="exportData">تصدير</button></div><div class="setting-row"><span class="setting-icon">ⓘ</span><div class="setting-copy"><strong>حول نور</strong><small>نسخة محلية أولية · الإصدار 1.0</small></div></div><div class="quote-card"><p>﴿ وَاذْكُرُوا اللَّهَ كَثِيرًا ﴾</p><small>سورة الجمعة · الآية 10</small></div><button class="small-btn" id="resetAll" style="width:100%;margin-top:12px;color:#a34242">إعادة ضبط بيانات التطبيق</button>`;
}
function renderCategories(){
 view.innerHTML=head("أدعية متنوعة","أدعية قرآنية مصنفة حسب الموضوع")+`<div class="category-grid">${[{name:"الاستغفار",icon:"☁",desc:"الرجوع إلى الله"},{name:"التيسير",icon:"✧",desc:"لشرح الصدر وتيسير الأمر"},{name:"جوامع الدعاء",icon:"♡",desc:"خير الدنيا والآخرة"},{name:"العلم",icon:"✦",desc:"طلب العلم النافع"}].map(c=>`<button class="category-tile" data-category="${c.name}"><span>${c.icon}</span><strong>${c.name}</strong><small>${c.desc}</small></button>`).join("")}</div><div id="categoryItems" style="margin-top:15px"></div>`;
}
function toggleFav(id){state.favorites=isFav(id)?state.favorites.filter(x=>x!==id):[...state.favorites,id];save();notify(isFav(id)?"أضيف إلى المفضلة":"أزيل من المفضلة");renderView()}
function addCount(mode,id){let item=itemById(id);if(!item)return;let k=progressKey(mode,id);state.progress[k]=Math.min(item.count,(state.progress[k]||0)+1);save();updateHomeProgress();renderView();if(state.progress[k]>=item.count)notify("أحسنت، أتممت هذا الذكر")}
async function copyItem(id){let item=itemById(id);if(!item)return;try{await navigator.clipboard.writeText(item.text);notify("تم نسخ الذكر")}catch(e){let ta=document.createElement("textarea");ta.value=item.text;document.body.appendChild(ta);ta.select();try{document.execCommand("copy");notify("تم نسخ الذكر")}catch(err){notify("تعذر النسخ في هذا المتصفح")}ta.remove()}}
function bindEvents(){
 document.addEventListener("click",e=>{
  const viewBtn=e.target.closest("[data-view]");if(viewBtn){showView(viewBtn.dataset.view);return}
  const open=e.target.closest("[data-open]");if(open){currentMode=open.dataset.open;showView("adhkar");return}
  const mode=e.target.closest("[data-mode]");if(mode){currentMode=mode.dataset.mode;renderView();return}
  const fav=e.target.closest("[data-fav]");if(fav){toggleFav(fav.dataset.fav);return}
  const copy=e.target.closest("[data-copy]");if(copy){copyItem(copy.dataset.copy);return}
  const cnt=e.target.closest("[data-count]");if(cnt){let [m,id]=cnt.dataset.count.split("|");addCount(m,id);return}
  const ff=e.target.closest("[data-favfilter]");if(ff){favFilter=ff.dataset.favfilter;renderFavorites();return}
  const cat=e.target.closest("[data-category]");if(cat){let items=ADHKAR.categories.filter(x=>x.category===cat.dataset.category);$("#categoryItems").innerHTML=items.map(x=>card(x,"morning")).join("");return}
 });
 $("#themeToggle").addEventListener("click",()=>{state.theme=state.theme==="night"?"light":"night";save();setTheme()});
 $("#settingsQuick").addEventListener("click",()=>showView("settings"));
 view.addEventListener("click",e=>{
  if(e.target.closest("#tasbeehAdd")){state.tasbeeh++;state.totalTasbeeh++;save();renderTasbeeh();return}
  if(e.target.closest("#tasbeehReset")){state.tasbeeh=0;save();renderTasbeeh();notify("تم تصفير العدد الحالي");return}
  if(e.target.closest("#phraseChange")){const phrases=["سبحان الله وبحمده","سبحان الله","الحمد لله","الله أكبر","أستغفر الله","لا إله إلا الله"];state.phrase=phrases[(phrases.indexOf(state.phrase)+1)%phrases.length];save();renderTasbeeh();return}
  if(e.target.closest("#nightSwitch")){state.theme=e.target.checked?"night":"light";save();setTheme();return}
  if(e.target.closest("#exportData")){let blob=new Blob([JSON.stringify(state,null,2)],{type:"application/json"});let a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="noor-backup.json";a.click();URL.revokeObjectURL(a.href);notify("تم تجهيز نسخة احتياطية");return}
  if(e.target.closest("#resetAll")){if(confirm("هل تريد حذف جميع المفضلات والتقدم والعدادات؟")){state={...defaults,progress:{},counts:{},favorites:[]};save();setTheme();renderSettings();updateHomeProgress();notify("تمت إعادة ضبط البيانات")}}
 });
 view.addEventListener("change",e=>{if(e.target.id==="fontSelect"){state.fontSize=Number(e.target.value);save();renderView()}});
}
function init(){setTheme();updateHomeProgress();bindEvents();if("serviceWorker" in navigator && location.protocol!=="file:"){navigator.serviceWorker.register("./sw.js").catch(()=>{});}}
init();
})();