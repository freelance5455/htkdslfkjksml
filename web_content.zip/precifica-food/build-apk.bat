@echo off
set ROOT=%~dp0
call "%ROOT%sync-web-assets.bat"
cd /d "%ROOT%android"
call gradlew.bat assembleDebug
if errorlevel 1 exit /b %errorlevel%
echo APK output: %ROOT%android\app\build\outputs\apk\debug\app-debug.apk
