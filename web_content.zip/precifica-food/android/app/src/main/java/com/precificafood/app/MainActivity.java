package com.precificafood.app;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(246, 247, 251));
        window.setNavigationBarColor(Color.rgb(246, 247, 251));
        window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(246, 247, 251));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setDefaultTextEncodingName("UTF-8");
        settings.setTextZoom(100);
        webView.addJavascriptInterface(new NativeStorage(this), "NativeStorage");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // This application is fully offline. Only bundled assets may be opened.
                return !url.startsWith("file:///android_asset/");
            }
        });
        root.addView(webView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("(function(){if(window.handleNativeBack){return String(window.handleNativeBack())}return 'false'})()", value -> {
                if (!"\"true\"".equals(value)) {
                    MainActivity.super.onBackPressed();
                }
            });
        } else {
            super.onBackPressed();
        }
    }

    public static final class NativeStorage {
        private final Context context;
        private final Activity activity;
        NativeStorage(Context context) {
            this.context = context.getApplicationContext();
            this.activity = context instanceof Activity ? (Activity) context : null;
        }
        private File fileFor(String key) {
            String safe = key == null ? "precifica_data" : key.replaceAll("[^A-Za-z0-9._-]", "_");
            return new File(context.getFilesDir(), safe + ".json");
        }
        @JavascriptInterface
        public synchronized String getItem(String key) {
            File file = fileFor(key);
            if (!file.isFile()) return null;
            try (FileInputStream in = new FileInputStream(file); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int count;
                while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                return out.toString("UTF-8");
            } catch (IOException e) {
                throw new RuntimeException("Unable to read private app data", e);
            }
        }
        @JavascriptInterface
        public synchronized void setItem(String key, String value) {
            File target = fileFor(key);
            File temp = new File(context.getFilesDir(), target.getName() + ".tmp");
            byte[] bytes = (value == null ? "" : value).getBytes(StandardCharsets.UTF_8);
            try (FileOutputStream out = new FileOutputStream(temp, false)) {
                out.write(bytes);
                out.flush();
                out.getFD().sync();
            } catch (IOException e) {
                temp.delete();
                throw new RuntimeException("Unable to save private app data", e);
            }
            if (!temp.renameTo(target)) {
                if (target.exists()) target.delete();
                if (!temp.renameTo(target)) {
                    temp.delete();
                    throw new RuntimeException("Unable to finalize private app data write");
                }
            }
        }
        @JavascriptInterface
        public synchronized void removeItem(String key) {
            File file = fileFor(key);
            if (file.exists() && !file.delete()) throw new RuntimeException("Unable to remove private app data");
        }
        @JavascriptInterface
        public synchronized void clear() {
            File[] files = context.getFilesDir().listFiles((dir, name) -> name.startsWith("precifica_") && (name.endsWith(".json") || name.endsWith(".json.tmp")));
            if (files == null) return;
            for (File file : files) file.delete();
        }
        @JavascriptInterface
        public void setTheme(String theme) {
            if (activity == null) return;
            activity.runOnUiThread(() -> {
                boolean dark = "dark".equals(theme);
                int surface = dark ? Color.rgb(17, 21, 33) : Color.rgb(246, 247, 251);
                activity.getWindow().setStatusBarColor(surface);
                activity.getWindow().setNavigationBarColor(surface);
                int flags = dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                activity.getWindow().getDecorView().setSystemUiVisibility(flags);
            });
        }
    }
}
