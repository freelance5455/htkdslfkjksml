@echo off
set ROOT=%~dp0
copy /Y "%ROOT%web\index.html" "%ROOT%android\app\src\main\assets\index.html" >nul
copy /Y "%ROOT%web\styles.css" "%ROOT%android\app\src\main\assets\styles.css" >nul
copy /Y "%ROOT%web\app.js" "%ROOT%android\app\src\main\assets\app.js" >nul
echo Web assets copied into Android assets.
