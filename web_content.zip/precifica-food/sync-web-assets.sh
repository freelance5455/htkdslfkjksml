#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cp "$ROOT/web/index.html" "$ROOT/android/app/src/main/assets/index.html"
cp "$ROOT/web/styles.css" "$ROOT/android/app/src/main/assets/styles.css"
cp "$ROOT/web/app.js" "$ROOT/android/app/src/main/assets/app.js"
echo "Web assets copied into Android assets."
