#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
"$ROOT/sync-web-assets.sh"
cd "$ROOT/android"
./gradlew assembleDebug
echo "APK output: $ROOT/android/app/build/outputs/apk/debug/app-debug.apk"
