# Precifica+ — projeto Android

Aplicativo offline de precificação de produtos alimentícios, com interface responsiva e armazenamento local. O projeto Android está organizado para abrir no Android Studio e gerar APK.

## O que está implementado

- Cinco áreas principais: Visão geral, Criar planilha, Planilhas salvas, Como precificar e Configurações.
- Assistente inicial: idioma/moeda com sugestão pela região do aparelho, tema, interface simplificada ou elaborada, tutorial demonstrativo e configuração opcional dos padrões.
- Ficha detalhada: ingredientes, quantidades e unidades compradas/usadas, embalagem por unidade, outros custos do lote, mão de obra, custos fixos alocados, margem, impostos e taxas.
- Ficha automatizada: pede os dados variáveis do produto e usa os padrões de custo configurados.
- Cálculo proporcional dos ingredientes com conversão entre g/kg/mg, ml/L e unidades. Unidades incompatíveis impedem o cálculo.
- Preço sugerido com margem sobre o preço de venda: `preço = custo unitário / (1 - margem - impostos - taxas)`. A soma de percentuais precisa ser menor que 100%.
- Dashboard com faturamento bruto de vendas registradas, lucro estimado após os custos e taxas salvos com a venda, custo de ingredientes vendidos, planilhas recentes e valores que clientes devem ao negócio.
- Pesquisa de planilhas por nome, data ou valor, filtros por período e ordenação por preço/custo.
- Registro de vendas e contas a receber; marcar uma conta como recebida atualiza os valores em aberto.
- Tema claro/escuro, idiomas Português (Brasil), English e Español, e moedas BRL, USD, EUR, GBP, MXN, ARS, CLP, CAD, AUD e JPY.
- Animações leves, layout adaptável para celular/tablet/desktop, navegação inferior no celular e gesto de puxar para baixo para atualizar a visualização.
- O aplicativo não depende de serviços web para operar.

## Regras das configurações automatizadas

Para desbloquear a ficha automatizada, cada despesa fixa deve conter um valor ou estar marcada como **Nulo / não pago**. Também é necessário definir horas produtivas mensais, mão de obra (valor mensal ou **Não incluir mão de obra**), margem, impostos e taxas (valor ou Nulo). O campo de horas produtivas é necessário para distribuir as despesas fixas por hora. É possível salvar as configurações incompletas, mas a automação permanece bloqueada até que todos os itens obrigatórios estejam definidos.

A ficha detalhada não usa esses padrões: seus custos de mão de obra, despesas fixas, margem, impostos e taxas são informados diretamente na ficha.

## Armazenamento e privacidade

No Android, o estado do usuário é salvo em um arquivo JSON no diretório interno privado do app, usando escrita temporária e substituição do arquivo por uma ponte local entre Java e JavaScript. No navegador de desenvolvimento, é usado `localStorage`. Não são necessários login, conexão ou permissões de rede.

Os dados permanecem entre aberturas normais do aplicativo. Como ocorre com qualquer armazenamento local, **desinstalar o app ou apagar os dados do aplicativo nas configurações do Android pode removê-los**. O APK desativa o backup automático do Android.

## Compilar APK no Android Studio

1. Instale o Android Studio com JDK 17 e o Android SDK Platform 35.
2. Descompacte este projeto e abra a pasta `android/` no Android Studio.
3. Aceite a sincronização do Gradle. Na primeira sincronização, será necessário acesso à internet para obter a distribuição Gradle e os componentes do Android Gradle Plugin/SDK que ainda não estiverem instalados. O APK compilado funciona offline.
4. Para APK de teste, use **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. O APK de depuração normalmente ficará em `android/app/build/outputs/apk/debug/app-debug.apk`.

O projeto usa `applicationId` `com.precificafood.app`, `minSdk 23`, `compileSdk 35` e `targetSdk 34`. A assinatura de produção pode ser configurada pelo assistente **Generate Signed Bundle / APK** do Android Studio.

### Compilar pela linha de comando

Na raiz do projeto, em um computador com Android SDK configurado e JDK 17:

```sh
./build-apk.sh
```

No Windows, execute `build-apk.bat` na raiz do projeto.

Os scripts usam Gradle 8.9 e baixam a distribuição oficial na primeira execução quando ela não estiver em cache. Também é possível usar o Android Studio para a compilação.

## Fonte da interface

A fonte web editável está em `web/`. As cópias usadas pelo WebView Android ficam em `android/app/src/main/assets/`. Depois de editar a interface, sincronize as cópias com:

```sh
./sync-web-assets.sh
```

## Observações de cálculo

- Despesas fixas mensais são rateadas pelas horas produtivas mensais e aplicadas ao tempo de preparo do lote.
- Mão de obra automatizada = remuneração mensal desejada ÷ horas produtivas mensais × tempo do lote.
- Embalagem é tratada como custo por unidade; “outros custos variáveis” são tratados como custo total do lote.
- O registro de uma venda preserva um retrato do custo unitário e das taxas da ficha na data da venda, para que alterações futuras na planilha não reescrevam os resultados históricos.
- A estimativa não substitui orientação contábil/fiscal. O usuário deve inserir taxas e impostos corretos para seu regime e contexto.
