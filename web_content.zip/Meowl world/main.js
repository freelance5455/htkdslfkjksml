// MEOWL WORLD
// VERSION 0.1

const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

const menu = document.getElementById("menu");
const game = document.getElementById("game");

const playBtn = document.getElementById("playBtn");
const menuBtn = document.getElementById("menuBtn");

const scoreElement = document.getElementById("score");

// НАСТРОЙКИ

let running = false;

let width = 0;
let height = 0;

const WORLD_SIZE = 2400;

let score = 0;

// ИГРОК

const player = {
    x: 1200,
    y: 1200,

    size: 65,

    speed: 240
};

// КОТОСОВА

const catImage = new Image();

catImage.src = "assets/kotosova.png";

// УПРАВЛЕНИЕ

const keys = {
    up: false,
    down: false,
    left: false,
    right: false
};

// КАМЕРА

const camera = {
    x: 0,
    y: 0
};

// МИР

const trees = [];
const chocolates = [];
const flowers = [];

// СЛУЧАЙНОЕ ЧИСЛО

function random(min, max) {
    return Math.random() * (max - min) + min;
}

// СОЗДАНИЕ МИРА

function generateWorld() {

    trees.length = 0;
    chocolates.length = 0;
    flowers.length = 0;

    // ДЕРЕВЬЯ

    for (let i = 0; i < 100; i++) {

        const x = random(100, WORLD_SIZE - 100);
        const y = random(100, WORLD_SIZE - 100);

        if (
            Math.abs(x - player.x) < 130 &&
            Math.abs(y - player.y) < 130
        ) continue;

        trees.push({
            x: x,
            y: y,
            size: random(30, 55)
        });

    }

    // ЦВЕТЫ

    for (let i = 0; i < 200; i++) {

        flowers.push({

            x: random(0, WORLD_SIZE),
            y: random(0, WORLD_SIZE),

            size: random(3, 7),

            color: Math.random() > 0.5
                ? "#fff7a8"
                : "#ffffff"

        });

    }

    // ШОКОЛАДКИ

    for (let i = 0; i < 35; i++) {

        chocolates.push({

            x: random(80, WORLD_SIZE - 80),
            y: random(80, WORLD_SIZE - 80),

            collected: false

        });

    }

}

// ИЗМЕНЕНИЕ РАЗМЕРА

function resize() {

    width = window.innerWidth;
    height = window.innerHeight;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    canvas.width = width * dpr;
    canvas.height = height * dpr;

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

}

window.addEventListener("resize", resize);

resize();

// НАЧАЛО ИГРЫ

playBtn.onclick = function() {

    menu.style.display = "none";
    game.style.display = "block";

    if (!running) {

        running = true;

        generateWorld();

        lastTime = performance.now();

        requestAnimationFrame(loop);

    }

};

// ВОЗВРАТ В МЕНЮ

menuBtn.onclick = function() {

    running = false;

    Object.keys(keys).forEach(key => keys[key] = false);

    game.style.display = "none";
    menu.style.display = "flex";

};

// КЛАВИАТУРА

const keyMap = {
    "w": "up",
    "ц": "up",
    "ArrowUp": "up",

    "s": "down",
    "ы": "down",
    "ArrowDown": "down",

    "a": "left",
    "ф": "left",
    "ArrowLeft": "left",

    "d": "right",
    "в": "right",
    "ArrowRight": "right"
};

window.addEventListener("keydown", e => {

    const direction = keyMap[e.key];

    if (direction) {
        keys[direction] = true;
        e.preventDefault();
    }

});

window.addEventListener("keyup", e => {

    const direction = keyMap[e.key];

    if (direction) {
        keys[direction] = false;
        e.preventDefault();
    }

});

// МОБИЛЬНОЕ УПРАВЛЕНИЕ

document.querySelectorAll("[data-dir]").forEach(button => {

    const direction = button.dataset.dir;

    button.addEventListener("pointerdown", e => {

        e.preventDefault();

        button.setPointerCapture(e.pointerId);

        keys[direction] = true;

    });

    button.addEventListener("pointerup", e => {

        keys[direction] = false;

    });

    button.addEventListener("pointercancel", e => {

        keys[direction] = false;

    });

    button.addEventListener("lostpointercapture", e => {

        keys[direction] = false;

    });

});

// ОБНОВЛЕНИЕ ИГРЫ

function update(dt) {

    let dx = 0;
    let dy = 0;

    if (keys.up) dy--;
    if (keys.down) dy++;
    if (keys.left) dx--;
    if (keys.right) dx++;

    // НОРМАЛИЗАЦИЯ ДИАГОНАЛИ

    const length = Math.hypot(dx, dy);

    if (length > 0) {

        dx /= length;
        dy /= length;

    }

    player.x += dx * player.speed * dt;
    player.y += dy * player.speed * dt;

    // ГРАНИЦЫ МИРА

    player.x = Math.max(
        player.size,
        Math.min(WORLD_SIZE - player.size, player.x)
    );

    player.y = Math.max(
        player.size,
        Math.min(WORLD_SIZE - player.size, player.y)
    );

    // КАМЕРА

    camera.x = player.x - width / 2;
    camera.y = player.y - height / 2;

    // СБОР ШОКОЛАДОК

    for (const chocolate of chocolates) {

        if (chocolate.collected) continue;

        const distance = Math.hypot(
            player.x - chocolate.x,
            player.y - chocolate.y
        );

        if (distance < 45) {

            chocolate.collected = true;

            score++;

            scoreElement.textContent = "🍫 " + score;

        }

    }

}

// ОТРИСОВКА ЗЕМЛИ

function drawGround() {

    ctx.fillStyle = "#79ba59";

    ctx.fillRect(
        0,
        0,
        WORLD_SIZE,
        WORLD_SIZE
    );

    // СЕТКА ТРАВЫ

    ctx.strokeStyle = "rgba(255,255,255,0.035)";
    ctx.lineWidth = 1;

    for (let x = 0; x < WORLD_SIZE; x += 80) {

        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, WORLD_SIZE);
        ctx.stroke();

    }

    for (let y = 0; y < WORLD_SIZE; y += 80) {

        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(WORLD_SIZE, y);
        ctx.stroke();

    }

}

// ДЕРЕВО

function drawTree(tree) {

    const {x, y, size} = tree;

    // ТЕНЬ

    ctx.fillStyle = "rgba(0,0,0,0.15)";

    ctx.beginPath();

    ctx.ellipse(
        x + 8,
        y + 12,
        size,
        size / 2,
        0,
        0,
        Math.PI * 2
    );

    ctx.fill();

    // СТВОЛ

    ctx.fillStyle = "#79512e";

    ctx.fillRect(
        x - 7,
        y - 5,
        14,
        25
    );

    // ЛИСТВА

    ctx.fillStyle = "#286e36";

    ctx.beginPath();
    ctx.arc(x, y - 20, size, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "#399447";

    ctx.beginPath();
    ctx.arc(
        x - size * 0.25,
        y - 27,
        size * 0.65,
        0,
        Math.PI * 2
    );

    ctx.fill();

}

// ШОКОЛАД

function drawChocolate(item) {

    if (item.collected) return;

    const x = item.x;
    const y = item.y;

    ctx.save();

    ctx.translate(x, y);
    ctx.rotate(-0.2);

    // ТЕНЬ

    ctx.fillStyle = "rgba(0,0,0,0.2)";
    ctx.fillRect(-16, -8, 36, 28);

    // ОСНОВА

    ctx.fillStyle = "#65351d";
    ctx.fillRect(-18, -13, 36, 26);

    // ДОЛЬКИ

    ctx.fillStyle = "#a86b43";

    for (let row = 0; row < 2; row++) {

        for (let col = 0; col < 3; col++) {

            ctx.fillRect(
                -16 + col * 12,
                -11 + row * 12,
                10,
                10
            );

        }

    }

    ctx.restore();

}

// ИГРОК

function drawPlayer() {

    const x = player.x;
    const y = player.y;

    ctx.save();

    // ТЕНЬ

    ctx.fillStyle = "rgba(0,0,0,0.22)";

    ctx.beginPath();

    ctx.ellipse(
        x,
        y + 27,
        28,
        12,
        0,
        0,
        Math.PI * 2
    );

    ctx.fill();

    // КОТОСОВА

    if (catImage.complete && catImage.naturalWidth > 0) {

        ctx.drawImage(
            catImage,
            x - player.size / 2,
            y - player.size / 2,
            player.size,
            player.size
        );

    } else {

        // ЕСЛИ ФОТОГРАФИЯ НЕ ЗАГРУЗИЛАСЬ

        ctx.font = "55px Arial";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";

        ctx.fillText("🐱", x, y);

    }

    ctx.restore();

}

// ОТРИСОВКА МИРА

function render() {

    ctx.clearRect(0, 0, width, height);

    ctx.save();

    ctx.translate(
        -camera.x,
        -camera.y
    );

    drawGround();

    // ЦВЕТЫ

    for (const flower of flowers) {

        ctx.fillStyle = flower.color;

        ctx.beginPath();

        ctx.arc(
            flower.x,
            flower.y,
            flower.size,
            0,
            Math.PI * 2
        );

        ctx.fill();

    }

    // ШОКОЛАД

    for (const chocolate of chocolates) {

        drawChocolate(chocolate);

    }

    // ДЕРЕВЬЯ

    for (const tree of trees) {

        drawTree(tree);

    }

    // ИГРОК

    drawPlayer();

    ctx.restore();

}

// ИГРОВОЙ ЦИКЛ

let lastTime = 0;

function loop(time) {

    if (!running) return;

    const dt = Math.min(
        (time - lastTime) / 1000,
        0.05
    );

    lastTime = time;

    update(dt);

    render();

    requestAnimationFrame(loop);

}

