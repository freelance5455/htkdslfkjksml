package com.yorrichin.jarvisnova;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.hardware.camera2.CameraManager;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView web;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private static final int MIC_REQ = 41, CAMERA_REQ = 42, LOCATION_REQ = 43, PHOTO_REQ = 44;
    private String pendingAction = "";
    private boolean torchOn = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(5, 12, 24));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(5, 12, 24));
        web = new WebView(this);
        web.setBackgroundColor(android.graphics.Color.rgb(5, 12, 24));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        tts = new TextToSpeech(this, status -> { if (status == TextToSpeech.SUCCESS) tts.setLanguage(Locale.getDefault()); });
    }

    private void js(String code) { runOnUiThread(() -> { if (web != null) web.evaluateJavascript(code, null); }); }
    private void sayToUi(String text) { js("window.jarvisResult && window.jarvisResult(" + org.json.JSONObject.quote(text) + ")"); }
    private boolean granted(String permission) { return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED; }

    private void listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { sayToUi("Speech recognition is not available on this device. You can type a command instead."); return; }
        if (!granted(Manifest.permission.RECORD_AUDIO)) { pendingAction = "listen"; requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQ); return; }
        runOnUiThread(() -> {
            try {
                if (recognizer != null) { recognizer.destroy(); recognizer = null; }
                recognizer = SpeechRecognizer.createSpeechRecognizer(this);
                recognizer.setRecognitionListener(new RecognitionListener() {
                    public void onReadyForSpeech(Bundle p) { js("window.jarvisListening && window.jarvisListening(true)"); }
                    public void onBeginningOfSpeech() {}
                    public void onRmsChanged(float r) {}
                    public void onBufferReceived(byte[] b) {}
                    public void onEndOfSpeech() { js("window.jarvisListening && window.jarvisListening(false)"); }
                    public void onError(int e) { js("window.jarvisListening && window.jarvisListening(false)"); sayToUi("I couldn't hear that clearly. Try again or type your command."); }
                    public void onResults(Bundle b) { js("window.jarvisListening && window.jarvisListening(false)"); ArrayList<String> a = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if (a != null && !a.isEmpty()) js("window.jarvisVoiceCommand && window.jarvisVoiceCommand(" + org.json.JSONObject.quote(a.get(0)) + ")"); }
                    public void onPartialResults(Bundle b) {}
                    public void onEvent(int t, Bundle p) {}
                });
                Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
                i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS");
                recognizer.startListening(i);
            } catch (Exception ex) { sayToUi("Voice input couldn't start. Please type your command."); }
        });
    }

    private void openCamera() {
        if (!granted(Manifest.permission.CAMERA)) { pendingAction = "camera"; requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_REQ); return; }
        try { Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE); startActivityForResult(i, PHOTO_REQ); }
        catch (Exception e) { sayToUi("No camera app was found."); }
    }

    private void locate() {
        if (!granted(Manifest.permission.ACCESS_FINE_LOCATION) && !granted(Manifest.permission.ACCESS_COARSE_LOCATION)) {
            pendingAction = "location"; requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQ); return;
        }
        try {
            LocationManager lm = (LocationManager)getSystemService(LOCATION_SERVICE);
            Location best = null;
            for (String provider : lm.getProviders(true)) { try { Location l = lm.getLastKnownLocation(provider); if (l != null && (best == null || l.getTime() > best.getTime())) best = l; } catch (SecurityException ignored) {} }
            if (best != null) sayToUi("Your approximate location is latitude " + best.getLatitude() + ", longitude " + best.getLongitude() + ". You can open Maps to see it.");
            else { startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)); sayToUi("Location permission is granted, but no recent location is available yet. Check that Location is switched on, then try again."); }
        } catch (Exception e) { sayToUi("I couldn't read your location. Check Android location settings."); }
    }

    private void doPending() { String p = pendingAction; pendingAction = ""; if (p.equals("listen")) listen(); else if (p.equals("camera")) openCamera(); else if (p.equals("location")) locate(); }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        boolean ok = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
        if (!ok) { pendingAction = ""; sayToUi("Permission was not granted. You can still use text commands, or enable access later in Android Settings."); return; }
        doPending();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PHOTO_REQ) {
            if (resultCode == RESULT_OK && data != null && data.getExtras() != null) {
                Object obj = data.getExtras().get("data");
                if (obj instanceof Bitmap) {
                    Bitmap bmp = (Bitmap)obj;
                    java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream(); bmp.compress(Bitmap.CompressFormat.JPEG, 78, out);
                    String base64 = android.util.Base64.encodeToString(out.toByteArray(), android.util.Base64.NO_WRAP);
                    js("window.jarvisPhoto && window.jarvisPhoto('data:image/jpeg;base64," + base64 + "')");
                    sayToUi("Photo captured. This is a preview; image understanding requires an AI vision service to be connected.");
                }
            } else sayToUi("Camera closed without taking a photo.");
        }
    }

    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if (recognizer != null) recognizer.destroy(); if (tts != null) { tts.stop(); tts.shutdown(); } if (web != null) web.destroy(); super.onDestroy(); }

    private class Bridge {
        @JavascriptInterface public void listen() { MainActivity.this.runOnUiThread(() -> MainActivity.this.listen()); }
        @JavascriptInterface public void speak(String text) { MainActivity.this.runOnUiThread(() -> { if (tts != null) { tts.setSpeechRate(0.94f); tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-" + System.currentTimeMillis()); } }); }
        @JavascriptInterface public void openCamera() { MainActivity.this.runOnUiThread(() -> MainActivity.this.openCamera()); }
        @JavascriptInterface public void getLocation() { MainActivity.this.runOnUiThread(() -> MainActivity.this.locate()); }
        @JavascriptInterface public void openSettings(String type) {
            MainActivity.this.runOnUiThread(() -> { try {
                Intent i;
                switch (type) {
                    case "wifi": i = new Intent(Settings.ACTION_WIFI_SETTINGS); break;
                    case "bluetooth": i = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS); break;
                    case "location": i = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS); break;
                    case "display": i = new Intent(Settings.ACTION_DISPLAY_SETTINGS); break;
                    case "sound": i = new Intent(Settings.ACTION_SOUND_SETTINGS); break;
                    case "apps": i = new Intent(Settings.ACTION_APPLICATION_SETTINGS); break;
                    case "security": i = new Intent(Settings.ACTION_SECURITY_SETTINGS); break;
                    default: i = new Intent(Settings.ACTION_SETTINGS);
                } startActivity(i);
            } catch (Exception e) { sayToUi("That settings page is unavailable on this Android version."); } });
        }
        @JavascriptInterface public void openApp(String app) {
            MainActivity.this.runOnUiThread(() -> {
                String p;
                switch (app.toLowerCase(Locale.ROOT)) {
                    case "youtube": p="com.google.android.youtube"; break;
                    case "chrome": p="com.android.chrome"; break;
                    case "maps": p="com.google.android.apps.maps"; break;
                    case "settings": startActivity(new Intent(Settings.ACTION_SETTINGS)); return;
                    case "camera": MainActivity.this.openCamera(); return;
                    case "phone": p="com.google.android.dialer"; break;
                    case "messages": p="com.google.android.apps.messaging"; break;
                    case "photos": p="com.google.android.apps.photos"; break;
                    case "play store": p="com.android.vending"; break;
                    case "clock": p="com.google.android.deskclock"; break;
                    default: sayToUi("I don't know that app yet. Try YouTube, Chrome, Maps, Camera, Settings, Phone, Messages, Photos, Play Store or Clock."); return;
                }
                try { Intent i = getPackageManager().getLaunchIntentForPackage(p); if (i != null) startActivity(i); else sayToUi(app + " isn't installed or doesn't expose a launch icon."); }
                catch (Exception e) { sayToUi("Couldn't open " + app + "."); }
            });
        }
        @JavascriptInterface public void searchWeb(String query) { MainActivity.this.runOnUiThread(() -> { try { Intent i = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/search?q=" + android.net.Uri.encode(query))); startActivity(i); } catch (Exception e) { sayToUi("Couldn't open web search."); } }); }
        @JavascriptInterface public void setVolume(int percent) { MainActivity.this.runOnUiThread(() -> { AudioManager am=(AudioManager)getSystemService(AUDIO_SERVICE); int max=am.getStreamMaxVolume(AudioManager.STREAM_MUSIC); am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.max(0,Math.min(max,Math.round(max*percent/100f))), 0); sayToUi("Media volume set to " + Math.max(0,Math.min(100,percent)) + " percent."); }); }
        @JavascriptInterface public void toggleTorch() { MainActivity.this.runOnUiThread(() -> { try { CameraManager cm=(CameraManager)getSystemService(Context.CAMERA_SERVICE); String[] ids=cm.getCameraIdList(); if(ids.length==0){sayToUi("No camera torch is available.");return;} torchOn=!torchOn; cm.setTorchMode(ids[0],torchOn); sayToUi(torchOn?"Flashlight turned on.":"Flashlight turned off."); } catch(Exception e){sayToUi("Flashlight control is not available on this device.");} }); }
        @JavascriptInterface public void vibrate() { MainActivity.this.runOnUiThread(() -> { android.os.Vibrator v=(android.os.Vibrator)getSystemService(VIBRATOR_SERVICE); if(v!=null) { if(android.os.Build.VERSION.SDK_INT>=26) v.vibrate(android.os.VibrationEffect.createOneShot(100, android.os.VibrationEffect.DEFAULT_AMPLITUDE)); else v.vibrate(100); } }); }
    }
}
