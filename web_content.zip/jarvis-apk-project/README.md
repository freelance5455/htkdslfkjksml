# JARVIS NOVA — Android project

A fresh Android app project with a custom neon-core interface and a native Android bridge. This is a source project, **not a precompiled APK**.

## Features in this starter build
- New responsive JARVIS interface; tap the central core to start Android speech recognition.
- Type commands or use voice input; replies can be spoken with Android's installed Text-to-Speech voice.
- Permission-gated camera launch and an in-app photo preview (Android camera apps may return only a thumbnail).
- Location request and last-known location lookup, with Android location settings fallback.
- Launch supported apps: YouTube, Chrome, Maps, Camera, Settings, Phone, Messages, Photos, Play Store and Clock (installed apps vary).
- Open Wi-Fi, Bluetooth, display, sound, location, app and security settings.
- Flashlight toggle, media-volume adjustment, one-shot vibration, web search, local notes, activity log and focus timer.
- Optional Gemini text-chat connection. The API key is stored in local WebView storage, so it is convenient but **not a secure place for a production secret**. Do not share your key. The camera preview is not sent to Gemini in this build.

## Build the APK for free on an Android tablet
1. Install **AndroidIDE** from its official source or use another Android Gradle IDE that supports Android projects. Availability and UI can vary by Android version.
2. Extract this ZIP into a folder named `JARVIS-NOVA`.
3. Open/import the folder as an existing Gradle project.
4. Let Gradle sync. The project uses Android Gradle Plugin `8.7.3`, `compileSdk 35`, and `minSdk 26`; the build environment must have compatible Android SDK platform/build tools installed.
5. Choose the `app` module and run **Build APK** / `assembleDebug`.
6. Install the generated debug APK, usually at `app/build/outputs/apk/debug/app-debug.apk`. Approve Android's install-from-this-source prompt if Android asks.

If Gradle sync fails because the IDE cannot download dependencies or doesn't support this Android Gradle Plugin version, this ZIP has not been compiled in this environment. Use an IDE/build environment compatible with AGP 8.7.3; don't rename an HTML file to `.apk`.

## Important Android limits
- The app cannot silently control all settings or every app. Android blocks many privileged actions; those open system settings or require user confirmation.
- Microphone, camera and location are requested only when you use those features. You can revoke them in Android Settings at any time.
- Speech recognition may send audio to the speech service configured on the device. TTS uses the device's installed voice; this build does not bundle a unique cloned JARVIS voice.
- AI replies require an internet connection and a valid Gemini API key. The key is sent to Google's Gemini API from the device. Review Google's terms and privacy information before using it.
