# El Heladero — Proyecto Android

Proyecto Android para empaquetar el juego 3D en una APK.

## Requisitos
- Android Studio reciente
- Android SDK 35
- JDK 17

## Compilar
1. Abre esta carpeta en Android Studio.
2. Espera a que Gradle sincronice.
3. Ve a Build > Build APK(s).
4. La APK aparecerá en:
   app/build/outputs/apk/debug/app-debug.apk

## Nota
El juego usa Three.js desde jsDelivr, por eso la aplicación solicita permiso de Internet.
