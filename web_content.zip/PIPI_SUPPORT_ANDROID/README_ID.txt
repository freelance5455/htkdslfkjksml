PIPI SUPPORT — ANDROID BLE GATT SERVER
=====================================

Isi proyek:
- app Android PIPI SUPPORT (Kotlin)
- BLE GATT Server + BLE advertising
- Accessibility Service untuk swipe global
- volume musik Android
- kecerahan sistem (memerlukan izin khusus)

PENTING:
1. Ini adalah SOURCE PROJECT Android, bukan APK siap pasang.
2. Build APK menggunakan Android Studio pada komputer.
3. PIPI CONTROL HTML harus dibuka di browser yang mendukung Web Bluetooth
   melalui HTTPS/localhost.
4. UUID dan format JSON harus sama dengan PIPI CONTROL HTML:
   Service: 12345678-1234-5678-1234-56789abcdef0
   Characteristic: 12345678-1234-5678-1234-56789abcdef1
   {"command":"next"}
   {"command":"previous"}
   {"command":"pause"}
   {"command":"resume"}
   {"command":"volume","value":50}
   {"command":"brightness","value":70}

CARA BUILD:
1. Install Android Studio versi stabil terbaru.
2. Pilih Open, lalu pilih folder PIPI_SUPPORT_ANDROID hasil ekstrak ZIP.
3. Tunggu Gradle Sync selesai. Gunakan JDK 17 jika diminta.
4. Sambungkan HP Android untuk pengujian atau pilih Build > Build APK(s).
5. APK debug biasanya berada di app/build/outputs/apk/debug/app-debug.apk.

CARA MENYIAPKAN HP SUPPORT:
1. Install APK di HP yang akan dikontrol.
2. Buka PIPI SUPPORT.
3. Aktifkan Bluetooth dan izinkan BLUETOOTH_ADVERTISE serta BLUETOOTH_CONNECT.
4. Tekan tombol Accessibility dan aktifkan "PIPI Remote Control".
5. Untuk brightness, tekan izin pengaturan kecerahan dan izinkan PIPI SUPPORT.
6. Kembali ke PIPI SUPPORT, tekan MULAI PIPI BLUETOOTH.
7. Buka PIPI CONTROL HTML pada HP remote, tekan Cari & Hubungkan Support.
8. Pilih PIPI SUPPORT jika muncul.

BATASAN DAN KESELAMATAN:
- Swipe adalah gestur layar global; hasilnya bergantung pada aplikasi, orientasi,
  ukuran layar, dialog/pop-up, dan konten yang sedang terbuka.
- Pause/resume mengirim tombol media Android. Tidak semua aplikasi menanggapinya.
- Volume mengatur STREAM_MUSIC, bukan alarm/ringtone.
- Brightness memerlukan izin WRITE_SETTINGS dan dapat dibatasi kebijakan perangkat.
- Aplikasi tidak dapat melewati layar kunci, izin keamanan, proteksi aplikasi,
  atau batasan Android. Tidak menjamin 100% kompatibilitas semua aplikasi.
- Accessibility memberi kemampuan luas untuk melakukan gestur. Aktifkan hanya
  pada perangkat milik sendiri dan pahami izin yang diberikan.
- Implementasi awal ini menjaga server hidup selama proses aplikasi aktif.
  Jangan force-stop PIPI SUPPORT; beberapa vendor Android dapat membatasi proses
  latar belakang. Untuk pemakaian jangka panjang perlu foreground service dan
  pengujian khusus perangkat.
