package id.pipi.support

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.media.AudioManager
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class PipiAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: PipiAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { }
    override fun onInterrupt() { }

    fun executeCommand(command: String) {
        when (command) {
            "next" -> swipe(up = true)
            "previous" -> swipe(up = false)
            "pause" -> mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE)
            "resume" -> mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY)
        }
    }

    private fun swipe(up: Boolean) {
        val dm = resources.displayMetrics
        val x = dm.widthPixels * 0.50f
        val startY = if (up) dm.heightPixels * 0.78f else dm.heightPixels * 0.28f
        val endY = if (up) dm.heightPixels * 0.25f else dm.heightPixels * 0.78f
        val path = Path().apply {
            moveTo(x, startY)
            lineTo(x, endY)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 80, 420))
            .build()
        dispatchGesture(gesture, null, null)
    }

    private fun mediaKey(keyCode: Int) {
        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        val down = KeyEvent(KeyEvent.ACTION_DOWN, keyCode)
        val up = KeyEvent(KeyEvent.ACTION_UP, keyCode)
        audio.dispatchMediaKeyEvent(down)
        audio.dispatchMediaKeyEvent(up)
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
