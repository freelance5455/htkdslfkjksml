package id.pipi.support

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothGattServer
import android.bluetooth.BluetoothGattServerCallback
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothDevice
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import org.json.JSONObject
import java.util.UUID

class MainActivity : Activity() {
    private val serviceUuid = UUID.fromString("12345678-1234-5678-1234-56789abcdef0")
    private val charUuid = UUID.fromString("12345678-1234-5678-1234-56789abcdef1")
    private var gattServer: BluetoothGattServer? = null
    private var advertiserCallback: AdvertiseCallback? = null
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestBluetoothPermissions()
    }

    private fun buildUi() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(36, 48, 36, 36)
            setBackgroundColor(0xFFFFF5FA.toInt())
        }
        val title = TextView(this).apply {
            text = "🐻 PIPI SUPPORT"
            textSize = 27f
            setTextColor(0xFF62485D.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Status: belum aktif"
            textSize = 15f
            setPadding(0, 24, 0, 24)
            gravity = Gravity.CENTER
            setTextColor(0xFF62485D.toInt())
        }
        fun button(label: String, action: () -> Unit) =
            Button(this).apply {
                text = label
                isAllCaps = false
                textSize = 15f
                setOnClickListener { action() }
            }
        layout.addView(title)
        layout.addView(status)
        layout.addView(button("1. Aktifkan izin Bluetooth") { requestBluetoothPermissions() })
        layout.addView(button("2. Aktifkan Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        layout.addView(button("3. Izinkan pengaturan kecerahan") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                    Uri.parse("package:$packageName")))
            }
        })
        layout.addView(button("4. MULAI PIPI BLUETOOTH") { startBleServer() })
        layout.addView(button("Hentikan Bluetooth") { stopBleServer() })
        val note = TextView(this).apply {
            text = "Biarkan PIPI SUPPORT terbuka. Hubungkan dari PIPI CONTROL melalui Bluetooth. Aktifkan layanan Accessibility dan izin kecerahan bila ingin memakai fitur tersebut."
            textSize = 12f
            setTextColor(0xFF92778B.toInt())
            setPadding(0, 22, 0, 0)
        }
        layout.addView(note)
        setContentView(layout)
    }

    private fun requestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val needed = arrayOf(
                Manifest.permission.BLUETOOTH_ADVERTISE,
                Manifest.permission.BLUETOOTH_CONNECT
            ).filter { ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
            if (needed.isNotEmpty()) ActivityCompat.requestPermissions(this, needed.toTypedArray(), 44)
        }
    }

    private fun hasBluetoothPermissions(): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED &&
             ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)
    }

    private fun startBleServer() {
        if (!hasBluetoothPermissions()) {
            requestBluetoothPermissions()
            toast("Berikan izin Bluetooth lalu tekan MULAI lagi")
            return
        }
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter: BluetoothAdapter = manager.adapter ?: run {
            toast("Bluetooth tidak tersedia")
            return
        }
        if (!adapter.isEnabled) {
            toast("Nyalakan Bluetooth HP terlebih dahulu")
            return
        }
        val bleAdvertiser = adapter.bluetoothLeAdvertiser
        if (bleAdvertiser == null) {
            toast("HP ini tidak mendukung BLE advertising")
            return
        }

        stopBleServer()
        val service = BluetoothGattService(serviceUuid, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        val characteristic = BluetoothGattCharacteristic(
            charUuid,
            BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE,
            BluetoothGattCharacteristic.PERMISSION_WRITE
        )
        service.addCharacteristic(characteristic)

        gattServer = manager.openGattServer(this, object : BluetoothGattServerCallback() {
            override fun onServiceAdded(statusCode: Int, addedService: BluetoothGattService) {
                if (statusCode == android.bluetooth.BluetoothGatt.GATT_SUCCESS &&
                    addedService.uuid == serviceUuid) {
                    runOnUiThread { beginAdvertising(adapter) }
                } else {
                    runOnUiThread {
                        status.text = "Gagal menambahkan BLE service"
                        toast("GATT service gagal ditambahkan")
                    }
                }
            }

            override fun onConnectionStateChange(device: BluetoothDevice, statusCode: Int, newState: Int) {
                runOnUiThread {
                    status.text = if (newState == android.bluetooth.BluetoothProfile.STATE_CONNECTED)
                        "Status: CONTROL terhubung ♡" else "Status: menunggu koneksi"
                }
            }

            override fun onCharacteristicWriteRequest(
                device: BluetoothDevice,
                requestId: Int,
                characteristic: BluetoothGattCharacteristic,
                preparedWrite: Boolean,
                responseNeeded: Boolean,
                offset: Int,
                value: ByteArray
            ) {
                val accepted = characteristic.uuid == charUuid && offset == 0
                if (accepted) {
                    val payload = value.toString(Charsets.UTF_8)
                    runOnUiThread { handleCommand(payload) }
                }
                if (responseNeeded) {
                    gattServer?.sendResponse(device, requestId,
                        if (accepted) android.bluetooth.BluetoothGatt.GATT_SUCCESS else android.bluetooth.BluetoothGatt.GATT_FAILURE,
                        0, null)
                }
            }
        })

        val added = gattServer?.addService(service) ?: false
        if (!added) {
            status.text = "Gagal membuat GATT service"
            toast("GATT service gagal dibuat")
        } else {
            status.text = "Menyiapkan layanan Bluetooth…"
        }
    }

    private fun beginAdvertising(adapter: BluetoothAdapter) {
        val bleAdvertiser = adapter.bluetoothLeAdvertiser ?: return
        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
            .setConnectable(true)
            .setTimeout(0)
            .build()
        // UUID service diiklankan di advertising packet; nama perangkat tidak
        // dimasukkan agar payload legacy BLE tetap muat dalam batas 31 byte.
        val data = AdvertiseData.Builder()
            .setIncludeDeviceName(false)
            .addServiceUuid(android.os.ParcelUuid(serviceUuid))
            .build()
        advertiserCallback = object : AdvertiseCallback() {
            override fun onStartSuccess(settingsInEffect: AdvertiseSettings) {
                runOnUiThread {
                    status.text = "PIPI SUPPORT AKTIF · SIAP DIHUBUNGKAN"
                    toast("PIPI Support sedang mengiklankan BLE ♡")
                }
            }
            override fun onStartFailure(errorCode: Int) {
                runOnUiThread {
                    status.text = "Gagal mengiklankan BLE: $errorCode"
                    toast("BLE advertise gagal: $errorCode")
                }
            }
        }
        try {
            bleAdvertiser.startAdvertising(settings, data, advertiserCallback)
        } catch (e: SecurityException) {
            status.text = "Izin Bluetooth belum diberikan"
            toast("Izin Bluetooth ditolak")
        }
    }

    private fun handleCommand(json: String) {
        try {
            val obj = JSONObject(json)
            val command = obj.optString("command")
            val value = obj.optInt("value", -1)
            val service = PipiAccessibilityService.instance
            when (command) {
                "next", "previous", "pause", "resume" -> {
                    if (service == null) toast("Aktifkan PIPI Remote Control di Accessibility")
                    else service.executeCommand(command)
                }
                "volume" -> {
                    if (value in 0..100) {
                        val audio = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
                        val max = audio.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
                        audio.setStreamVolume(android.media.AudioManager.STREAM_MUSIC,
                            (max * value / 100f).toInt(), 0)
                    }
                }
                "brightness" -> {
                    if (value in 0..100) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.System.canWrite(this)) {
                            toast("Izinkan pengaturan kecerahan terlebih dahulu")
                        } else {
                            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS,
                                (value * 255 / 100).coerceIn(1, 255))
                        }
                    }
                }
                else -> toast("Perintah tidak dikenal: $command")
            }
        } catch (e: Exception) {
            toast("Payload tidak valid")
        }
    }

    private fun stopBleServer() {
        try {
            val adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
            advertiserCallback?.let { adapter.bluetoothLeAdvertiser?.stopAdvertising(it) }
            advertiserCallback = null
            gattServer?.close()
            gattServer = null
            status.text = "Status: Bluetooth dihentikan"
        } catch (_: Exception) { }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        stopBleServer()
        super.onDestroy()
    }
}
