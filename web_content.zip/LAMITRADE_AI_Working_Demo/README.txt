LAMITRADE AI — Updated Working Browser Demo

HOW TO RUN ON ANDROID
1. Download and extract the ZIP.
2. Open index.html using Chrome or a compatible HTML viewer.
3. The first screen is now ONLY the login screen. The app header, footer and bottom navigation are hidden until you log in, create a demo profile, or continue as guest.
4. After entering the app, use the bottom navigation to switch between Home, Analyze, Risk, Trade, History and Settings.

FUNCTIONS
- Login / guest entry (demo only; no real authentication)
- Home screen with explicitly labelled sample market prices
- Chart screenshot upload and local preview
- Illustrative bullish/bearish scenario explanations
- Risk calculator and position-size estimate
- Paper trades with manually simulated target/stop outcomes
- Analysis history and settings

NOT YET IMPLEMENTED
- Actual AI interpretation of uploaded screenshots
- Live Forex market feed
- Broker integrations or real-money trading
- Secure real user accounts / cloud sync
- Native Android APK packaging

IMPORTANT
This is a standalone HTML prototype, not yet a native APK. Sample prices and analysis are illustrative only, not trading advice or live signals.
