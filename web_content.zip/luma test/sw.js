/* LUMA v12.3 service worker */
const VERSION = '12.3';
const CACHE = 'luma-v' + VERSION;
const JSZIP = 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.40.1/jszip.min.js';
const ASSETS = [
  './',
  './index.html',
  './assets/css/style.css?v=' + VERSION,
  './assets/js/app.js?v=' + VERSION,
  './manifest.webmanifest?v=' + VERSION,
  './assets/icons/icon-192.png',
  './assets/icons/icon-512.png',
  './assets/icons/icon-192-maskable.png',
  './assets/icons/icon-512-maskable.png',
  './assets/icons/apple-touch-icon.png',
  './assets/icons/favicon.png',
  './assets/js/vrm.js?v=' + VERSION,
  './assets/images/luma-mark.png'
];

self.addEventListener('install', (e) => {
  self.skipWaiting();
  e.waitUntil((async () => {
    const c = await caches.open(CACHE);
    // satu per satu: satu aset gagal tidak membatalkan yang lain
    const res = await Promise.allSettled(ASSETS.map((u) => c.add(u)));
    res.forEach((r, i) => { if (r.status === 'rejected') console.warn('[sw] gagal cache', ASSETS[i]); });
    try { await c.add(new Request(JSZIP, { mode: 'no-cors' })); } catch (err) {}
  })());
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // pustaka JSZip dari CDN: cache-first agar pengelola berkas jalan offline
  if (req.url === JSZIP) {
    e.respondWith(caches.match(req).then((hit) => hit || fetch(req).then((res) => {
      const copy = res.clone();
      caches.open(CACHE).then((c) => c.put(req, copy));
      return res;
    })));
    return;
  }

  if (url.origin !== self.location.origin) return;

  // berkas musik bawaan: biarkan browser yang menangani (pemutar audio memakai permintaan Range / 206 yang tak bisa di-cache)
  if (url.pathname.includes('/media/')) return;

  if (req.mode === 'navigate') {
    e.respondWith(
      fetch(req).then((res) => {
        if (res && res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put('./index.html', copy)); }
        return res;
      }).catch(() => caches.match('./index.html'))
    );
    return;
  }

  // network-first untuk app.js / style.css / index.html agar pembaruan cepat terpakai
  if (/app\.js|style\.css|index\.html/.test(url.pathname)) {
    e.respondWith(
      fetch(req).then((res) => {
        if (res && res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); }
        return res;
      }).catch(() => caches.match(req))
    );
    return;
  }

  e.respondWith(
    caches.match(req).then((cached) => {
      const fetched = fetch(req).then((res) => {
        if (res && res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); }
        return res;
      }).catch(() => cached);
      return cached || fetched;
    })
  );
});
