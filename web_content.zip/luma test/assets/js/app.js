// migrasi IndexedDB dari versi lama ('arumi-media' / 'zuvex-media' -> 'luma-media'); migrasi localStorage ada di <head> index.html agar jalan sebelum vrm.js
const AVDEF=new URL('assets/images/luma-mark.png',document.baseURI).href; // foto profil bawaan; hero beranda tidak ikut berubah
(async()=>{try{if(!indexedDB.databases)return;const dbs=(await indexedDB.databases()).map(d=>d.name);for(const OLD of ['ar'+'umi-media','zuvex-media']){if(!dbs.includes(OLD))continue;const o=await new Promise((r,j)=>{const q=indexedDB.open(OLD);q.onsuccess=()=>r(q.result);q.onerror=j});if(!o.objectStoreNames.contains('m')){o.close();continue}const all=await new Promise(r=>{const q=o.transaction('m').objectStore('m').getAll();q.onsuccess=()=>r(q.result)});const n=await new Promise((r,j)=>{const q=indexedDB.open('luma-media',1);q.onupgradeneeded=()=>q.result.createObjectStore('m',{keyPath:'id'});q.onsuccess=()=>r(q.result);q.onerror=j});const tx=n.transaction('m','readwrite');all.forEach(v=>tx.objectStore('m').put(v));await new Promise(r=>tx.oncomplete=r);o.close();n.close();indexedDB.deleteDatabase(OLD)}}catch(e){}})();
const $=s=>document.querySelector(s);
$('#av').src=AVDEF;
// bintang & kilau
const star='<svg viewBox="0 0 24 24"><path d="M12 1l2.6 8.4L23 12l-8.4 2.6L12 23l-2.6-8.4L1 12l8.4-2.6z"/></svg>';
$('#sp').innerHTML=Array.from({length:14},()=>`<i style="left:${Math.random()*100}%;top:${Math.random()*100}%;--s:${8+Math.random()*18}px;--d:-${Math.random()*4}s"></i>`).join('');
// efek miring mengikuti sentuhan / kursor
let hero=$('#hero');const stage=$('#stage');
function tilt(x,y){const r=stage.getBoundingClientRect();const dx=(x-r.left)/r.width-.5,dy=(y-r.top)/r.height-.5;hero.style.transform=`translate(${dx*-10}px,${dy*-8}px) scale(1.03)`}
stage.addEventListener('pointermove',e=>tilt(e.clientX,e.clientY));
['pointerleave','pointerup'].forEach(t=>stage.addEventListener(t,()=>hero.style.transform=''));
// toast
const lsSet=(k,v)=>{try{localStorage.setItem(k,v);return true}catch(e){toast('Penyimpanan penuh, perubahan tidak tersimpan. Hapus foto atau catatan lama.');return false}};
let tt;function toast(m,ms){const t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(tt);tt=setTimeout(()=>t.classList.remove('on'),ms||1800)}
// lembar bawah
const views={
chat:()=>`<div class="chat"><div class="chat-hd"><span class="avatar cav big" id="cav0"><img alt=""></span><div class="who"><b>${esc(nice(PF.name))}</b><small id="cst"></small></div><select id="cprov" class="csel" aria-label="Pilih mesin AI"><option value="auto">Otomatis</option><option value="gemini">Gemini</option><option value="groq">Groq</option><option value="openai">OpenAI</option></select><button class="cic" id="ckey" aria-label="Atur API key AI"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3M14 9l2 2"/></svg></button><button class="cic" id="cvo" type="button" aria-pressed="false"></button><button class="cic" id="cclr" aria-label="Hapus percakapan"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 10v6M14 10v6"/></svg></button></div><div id="cl" class="cl" aria-live="polite"></div><div class="qk">${['Apa yang bisa kamu lakukan?','Beri aku semangat','Beri aku ide seru'].map(q=>`<button class="fl">${q}</button>`).join('')}</div><div class="cbar"><textarea class="cti" id="ci" rows="1" placeholder="Tulis pesan…" maxlength="500" aria-label="Pesan"></textarea><button class="csend" id="cs" aria-label="Kirim"></button></div></div>`,
cari:()=>`<h2>Cari</h2><p style="color:var(--mute);font-size:14px;margin:0 0 10px">Pencarian web di dalam LUMA (Google Programmable Search).</p><div class="cin" style="margin:0 0 12px"><input class="inp" id="q" placeholder="Ketik kata kunci…" maxlength="200" aria-label="Kata kunci" style="flex:1"><button class="fl on" id="qgo">Cari</button></div><div id="res"></div><p id="qmeta" style="color:var(--mute);font-size:12px;margin:8px 0 0"></p><details style="margin-top:12px"><summary style="cursor:pointer;color:var(--mute);font-size:13px">Server pencarian</summary><div class="cin" style="margin:8px 0 0"><input class="inp" id="qsrv" placeholder="http://192.168.1.10:8787" aria-label="Alamat server pencarian" style="flex:1"><button class="fl" id="qsv">Simpan</button></div><p style="color:var(--mute);font-size:12px;margin:6px 0 0">Kosongkan lalu Simpan untuk kembali ke alamat otomatis.</p></details>`,
set:()=>`<h2>Pengaturan</h2><div class="row">Pemutar musik<button class="fl" id="op">Buka</button></div>${TGR('fxb',fxOn(),'Animasi mengikuti beat lagu')}`,
file:()=>`<div id="fm"></div><input type="file" id="ff" multiple hidden>`,
profil:()=>`<h2>Profil karakter</h2><div class="pfh"><div class="avatar"><img id="pfimg" alt="Foto karakter" src="${$('#av').src}"></div><div class="fbar" style="flex-direction:column;align-items:flex-start;margin:0"><button class="fl" id="pfph">Ganti foto</button><button class="fl" id="pfrs">Pakai foto asli</button></div></div><div class="lb">Warna aksen</div><div class="sw"><button data-h="auto" class="${mode==='auto'?'on':''}" style="--sw:conic-gradient(#f66,#fd5,#6d8,#5cf,#96f,#f6c,#f66)" aria-label="Warna otomatis dari karakter"></button>${[262,330,170,28,204].map(h=>`<button data-h="${h}" class="${mode==h?'on':''}" style="--sw:${h===204?'#A8D9F9':`hsl(${h} 55% 62%)`}" aria-label="Warna ${h===204?'biru langit #A8D9F9':h}"></button>`).join('')}</div><div class="row">Mode gelap<button class="tg ${document.documentElement.dataset.theme!=='light'?'on':''}" id="tg" aria-label="Mode gelap"></button></div><button class="fl" id="pfreset" style="margin-top:10px">Setel ulang profil</button><input type="file" id="pfi" accept="image/*" hidden>`,
'a-view':()=>{const d=x=>new Date(x).toLocaleDateString('id-ID',{day:'numeric',month:'long',year:'numeric'});return `<h2>Profil akun</h2><div class="lvbox"><div class="eav"><img src="${avSrc()}" alt=""></div><div><b>${esc(ACC.name)}</b><span>${esc(ACC.email)}</span></div></div><div class="kv"><span>Teman</span><b>${ACC.friends.length}</b></div><div class="kv"><span>Bingkai</span><b>${BORDERS[ACC.border].n}</b></div><div class="kv"><span>Bergabung</span><b>${d(ACC.joined)}</b></div>`},
'a-edit':()=>`<h2>Edit akun</h2><div class="pfh"><div class="eav"><img id="eimg" src="${avSrc()}" alt="Foto akun"></div><div class="fbar" style="flex-direction:column;align-items:flex-start;margin:0"><button class="fl" id="eph">Ganti foto</button><button class="fl" id="erm">Hapus foto</button></div></div><label class="lb">Nama<input class="inp" id="en" style="width:100%" maxlength="24" value="${esc(ACC.name)}"></label><label class="lb">Email<input class="inp" id="ee" type="email" style="width:100%" maxlength="60" value="${esc(ACC.email)}"></label><input type="file" id="efi" accept="image/*" hidden><p style="margin-top:12px">Data akun hanya tersimpan di perangkat ini dan terpisah dari profil karakter.</p>`,
komentar:()=>`<h2>Personalisasi Komentar</h2><p>Warna dan badge untuk pesanmu di chat.</p><div class="lb">Warna bubble</div><div class="sw">${['',262,330,170,28,205].map(h=>`<button data-ch="${h}" class="${(ACC.cmt.hue==null?'':ACC.cmt.hue)==h?'on':''}" style="--sw:${h===''?'var(--ac)':`hsl(${h} 55% 55%)`}" aria-label="Warna ${h||'aksen'}"></button>`).join('')}</div><div class="lb">Badge</div><div class="fbar">${['','⭐','🔬','🌙','🍀','🔥'].map(b=>`<button class="fl ${ACC.cmt.badge===b?'on':''}" data-cb="${b}">${b||'Tanpa'}</button>`).join('')}</div><div class="lb">Pratinjau</div><div class="cl"><div class="msg me" id="cpv"></div></div>`,
border:()=>`<h2>Border Avatar</h2><p>Pilih bingkai untuk foto akunmu.</p><div class="bgrid">${BORDERS.map((B,i)=>`<button class="bd ${ACC.border===i?'on':''}" data-b="${i}" style="--rg:${B.rg}"><span class="mr"><img src="${avSrc()}" alt=""></span><small>${B.n}</small></button>`).join('')}</div>`,
teman:()=>`<h2>Teman</h2><p>Daftar teman tersimpan di perangkat ini. Permintaan pertemanan: tidak ada.</p><div class="cin"><input class="inp" id="fn" maxlength="24" placeholder="Nama teman"><button class="fl" id="fa">Tambah</button></div><div id="fl2"></div>`
};
const SEG=(k,cur,arr)=>`<div class="seg" data-k="${k}">${arr.map(([v,l])=>`<button type="button" data-v="${v}" class="${cur===v?'on':''}">${l}</button>`).join('')}</div>`;
const BACK='<button class="fl" id="lzBack" style="width:100%;margin-top:14px;padding:12px">← Kembali ke chat</button>';
views['c-pers']=()=>{const p=jget(LPK,PERS_D);return `<h2>Personalisasi</h2><p style="color:var(--mute);font-size:14px;margin:0 0 10px">Atur cara ${esc(nice(PF.name))} berbicara denganmu. Tersimpan di perangkat ini.</p><label class="lb">Nama panggilanmu<input class="inp" id="lzNick" maxlength="24" style="width:100%" placeholder="Opsional" value="${esc(String(p.nick||''))}"></label><div class="lb" style="margin-top:12px">Gaya bicara</div>${SEG('tone',p.tone,[['ceria','Ceria'],['santai','Santai'],['lembut','Lembut'],['formal','Formal']])}<div class="lb">Panjang jawaban</div>${SEG('len',p.len,[['singkat','Singkat'],['sedang','Sedang'],['panjang','Panjang']])}<label class="lb">Instruksi tambahan<textarea class="inp" id="lzExtra" rows="3" maxlength="300" style="width:100%" placeholder="Contoh: sering beri semangat, jangan terlalu banyak emoji">${esc(String(p.extra||''))}</textarea></label>${BACK}`};
views['c-mem']=()=>{const m=memGet();return `<h2>Memori</h2><p style="color:var(--mute);font-size:14px;margin:0 0 10px">Catatan tentangmu yang akan selalu dibaca AI saat membalas. Kamu mengisinya sendiri; AI tidak menyimpan otomatis. Tersimpan di perangkat ini.</p><div class="row">Pakai memori<button class="tg ${m.on?'on':''}" id="lzMemOn" aria-label="Pakai memori"></button></div><div class="cin" style="margin:10px 0 0"><input class="inp" id="lzMemIn" maxlength="120" placeholder="Contoh: Aku suka kopi tanpa gula" aria-label="Catatan memori" style="flex:1"><button class="fl on" id="lzMemAdd">Tambah</button></div><div id="lzMemList"></div><p id="lzMemCnt" style="color:var(--mute);font-size:12px;margin:8px 0 0"></p><button class="fl" id="lzMemClr" style="margin-top:8px">Hapus semua</button>${BACK}`};
views['c-suara']=()=>{const v=jget(LSK,VOICE_D);return `<h2>Suara</h2><p style="color:var(--mute);font-size:14px;margin:0 0 10px">LUMA membacakan balasannya dengan suara bawaan perangkat, dan mulut model ikut bergerak.</p><p id="lzVoWarn" hidden style="color:#e66;font-size:13px;margin:0 0 10px">Browser ini tidak mendukung suara (Web Speech).</p><div class="row">Suara balasan<button class="tg ${v.on?'on':''}" id="lzVoOn" aria-label="Suara balasan"></button></div><label class="lb" style="margin-top:12px">Mesin suara<select class="inp" id="lzEng" style="width:100%"><option value="dev" ${v.eng!=='gemini'?'selected':''}>Suara perangkat</option><option value="gemini" ${v.eng==='gemini'?'selected':''}>Gemini TTS (gratis)</option><option value="fish" ${v.eng==='fish'?'selected':''}>Fish Audio</option></select></label><div id="lzGem" ${v.eng==='gemini'?'':'hidden'} style="margin-top:10px"><p style="color:var(--mute);font-size:13px;margin:0 0 8px">Gemini TTS gratis lewat API key dari Google AI Studio (aistudio.google.com/apikey). Boleh dikosongkan bila API key Gemini untuk chat sudah diisi di ikon kunci.</p><label class="lb">API key Gemini TTS<input class="inp" id="lzGKey" type="password" autocomplete="off" spellcheck="false" placeholder="AIza…" value="${esc(v.gkey||'')}" style="width:100%"></label><label class="lb" style="margin-top:10px">Suara Gemini<select class="inp" id="lzGVo" style="width:100%">${GTTS_VOICES.map(x=>`<option value="${x}" ${(v.gvoice||'Kore')===x?'selected':''}>${x}</option>`).join('')}</select></label><label class="lb" style="margin-top:10px">Model TTS<input class="inp" id="lzGMo" value="${esc(gModel(v))}" spellcheck="false" style="width:100%"></label><p style="color:var(--mute);font-size:12px;margin:8px 0 0">Kunci hanya disimpan di perangkat ini. Bila Gemini gagal (kuota habis dll.), LUMA otomatis memakai suara perangkat.</p></div><div id="lzFish" ${v.eng==='fish'?'':'hidden'} style="margin-top:10px"><p style="color:var(--mute);font-size:13px;margin:0 0 8px">Buat API key di fish.audio (menu API). Paket gratisnya punya kuota terbatas.</p><label class="lb">API key Fish Audio<input class="inp" id="lzFKey" type="password" autocomplete="off" spellcheck="false" placeholder="API key Fish Audio" value="${esc(v.fkey||'')}" style="width:100%"></label><label class="lb" style="margin-top:10px">ID suara (opsional)<input class="inp" id="lzFRef" value="${esc(v.fref||'')}" spellcheck="false" placeholder="reference_id dari halaman suara di fish.audio" style="width:100%"></label><label class="lb" style="margin-top:10px">Model<input class="inp" id="lzFMo" value="${esc(fModel(v))}" spellcheck="false" style="width:100%"></label><p style="color:var(--mute);font-size:12px;margin:8px 0 0">Kunci hanya disimpan di perangkat ini. Bila gagal, LUMA memakai suara perangkat.</p></div><label class="lb" style="margin-top:12px">Pilihan suara perangkat<select class="inp" id="lzVoSel" style="width:100%"></select></label><label class="lb" style="margin-top:12px">Kecepatan <b id="lzVoRateV">${(+v.rate||1).toFixed(1)}×</b><input type="range" class="lzr" id="lzVoRate" min="0.6" max="1.6" step="0.1" value="${+v.rate||1}"></label><label class="lb">Nada <b id="lzVoPitchV">${(+v.pitch||1).toFixed(1)}</b><input type="range" class="lzr" id="lzVoPitch" min="0.5" max="1.8" step="0.1" value="${+v.pitch||1}"></label><div class="cpr" style="margin-top:12px"><button class="fl on" id="lzTest" style="flex:1">Tes suara</button><button class="fl" id="lzStop" style="flex:1">Hentikan</button></div><p id="lzVoMsg" style="color:#e66;font-size:13px;margin:10px 0 0;word-break:break-word"></p>${BACK}`};
function initPers(){const p=jget(LPK,PERS_D),sv=()=>jset(LPK,p);
  $('#lzNick').oninput=e=>{p.nick=e.target.value.trim().slice(0,24);sv()};
  $('#lzExtra').oninput=e=>{p.extra=e.target.value.replace(/\s+/g,' ').trim().slice(0,300);sv()};
  document.querySelectorAll('#sc .seg').forEach(g=>{g.onclick=e=>{const b=e.target.closest('button[data-v]');if(!b)return;p[g.dataset.k]=b.dataset.v;g.querySelectorAll('button').forEach(x=>x.classList.toggle('on',x===b));sv()}});
  $('#lzBack').onclick=()=>open('chat')}
function initMem(){const m=memGet(),list=$('#lzMemList');
  const draw=()=>{list.innerHTML=m.items.length?m.items.map((x,i)=>`<div class="mi"><span>${esc(x)}</span><button type="button" data-i="${i}" aria-label="Hapus catatan">×</button></div>`).join(''):'<p style="color:var(--mute);font-size:13px;margin:8px 0 0">Belum ada catatan.</p>';$('#lzMemCnt').textContent=m.items.length+' / 50 catatan'};
  draw();
  const add=()=>{const i=$('#lzMemIn'),v=i.value.replace(/\s+/g,' ').trim().slice(0,120);if(!v)return;if(m.items.length>=50){toast('Memori penuh (maks. 50)');return}if(m.items.includes(v)){toast('Catatan sudah ada');return}m.items.push(v);memSet(m);i.value='';draw()};
  $('#lzMemAdd').onclick=add;$('#lzMemIn').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();add()}};
  list.onclick=e=>{const b=e.target.closest('button[data-i]');if(!b)return;m.items.splice(+b.dataset.i,1);memSet(m);draw()};
  const tg=$('#lzMemOn');tg.onclick=()=>{m.on=!m.on;tg.classList.toggle('on',m.on);memSet(m)};
  $('#lzMemClr').onclick=()=>{if(!m.items.length)return;if(!confirm('Hapus semua catatan memori?'))return;m.items.length=0;memSet(m);draw()};
  $('#lzBack').onclick=()=>open('chat')}
function initSuara(){const v=jget(LSK,VOICE_D),sv=()=>jset(LSK,v),sel=$('#lzVoSel');
  if(!VOICEOK)$('#lzVoWarn').hidden=false;
  const fill=()=>{const vs=VOICEOK?speechSynthesis.getVoices().slice():[];vs.sort((a,b)=>(/^id/i.test(b.lang)-/^id/i.test(a.lang))||a.name.localeCompare(b.name));sel.innerHTML='<option value="">Otomatis (Indonesia)</option>'+vs.map(x=>`<option value="${esc(x.voiceURI)}">${esc(x.name)} (${esc(x.lang)})</option>`).join('');sel.value=v.voice&&vs.some(x=>x.voiceURI===v.voice)?v.voice:''};
  fill();if(VOICEOK)speechSynthesis.onvoiceschanged=fill;
  sel.onchange=()=>{v.voice=sel.value;sv()};
  const tg=$('#lzVoOn');tg.onclick=()=>{v.on=!v.on;tg.classList.toggle('on',v.on);sv();try{window.__paintVo&&window.__paintVo()}catch(e){}if(v.on){if(!lzSay('Suara balasan aktif',true))toast('Suara tidak tersedia di browser ini')}else lzStop()};
  const eng=$('#lzEng'),gem=$('#lzGem');
  eng.onchange=()=>{v.eng=eng.value;gem.hidden=v.eng!=='gemini';$('#lzFish').hidden=v.eng!=='fish';sv()};
  $('#lzFKey').oninput=e=>{v.fkey=e.target.value.trim();sv()};
  $('#lzFRef').onchange=e=>{v.fref=e.target.value.trim();sv()};
  $('#lzFMo').onchange=e=>{v.fmodel=e.target.value.trim()||VOICE_D.fmodel;e.target.value=v.fmodel;sv()};
  $('#lzGKey').oninput=e=>{v.gkey=e.target.value.trim();sv()};
  $('#lzGVo').onchange=e=>{v.gvoice=e.target.value;sv()};
  $('#lzGMo').onchange=e=>{v.gmodel=e.target.value.trim()||VOICE_D.gmodel;e.target.value=v.gmodel;sv()};
  $('#lzVoRate').oninput=e=>{v.rate=+e.target.value;$('#lzVoRateV').textContent=v.rate.toFixed(1)+'×';sv()};
  $('#lzVoPitch').oninput=e=>{v.pitch=+e.target.value;$('#lzVoPitchV').textContent=v.pitch.toFixed(1);sv()};
  $('#lzTest').onclick=()=>{$('#lzVoMsg').textContent='';if(!lzSay('Halo, aku '+nice(PF.name)+'. Begini suaraku sekarang.',true))toast('Suara tidak tersedia di browser ini')};
  $('#lzStop').onclick=lzStop;
  $('#lzBack').onclick=()=>open('chat')}

const TGR=(id,on,l)=>`<div class="row">${l}<button class="tg ${on?'on':''}" id="${id}" aria-label="${l}"></button></div>`;
views['c-link']=()=>{const l=jget(LLK,LINK_D);return `<h2>Hubungan AI ke Model</h2><p style="color:var(--mute);font-size:14px;margin:0 0 10px">Atur bagaimana model 3D bereaksi saat AI berpikir dan membalas. Model terlihat di atas panel ini.</p>${TGR('lzLkOn',l.on,'Model bereaksi pada AI')}<div class="lb">Ekspresi wajah</div>${SEG('expr',l.expr,[['ai','AI memilih'],['teks','Dari teks'],['mati','Mati']])}<p style="color:var(--mute);font-size:12px;margin:-6px 0 8px">AI memilih: AI menandai emosi tiap balasan. Dari teks: ditebak dari kata dan emoji.</p>${TGR('lzLkNod',l.nod,'Mengangguk saat membalas')}${TGR('lzLkLip',l.lip,'Mulut ikut bicara')}${TGR('lzLkThink',l.think,'Tampak berpikir saat menunggu')}<label class="lb" style="margin-top:10px">Kekuatan ekspresi <b id="lzLkKv">${Math.round((+l.k||.7)*100)}%</b><input type="range" class="lzr" id="lzLkK" min="0.3" max="1" step="0.1" value="${+l.k||.7}"></label><div class="lb">Coba di model</div><div class="seg" id="lzLkTest"><button type="button" data-e="happy">Senang</button><button type="button" data-e="sad">Sedih</button><button type="button" data-e="angry">Marah</button><button type="button" data-e="surprised">Kaget</button><button type="button" data-e="relaxed">Tenang</button><button type="button" data-e="nod">Angguk</button><button type="button" data-e="talk">Bicara</button></div>${BACK}`};
function initLink(){const l=jget(LLK,LINK_D),sv=()=>jset(LLK,l);
  [['lzLkOn','on'],['lzLkNod','nod'],['lzLkLip','lip'],['lzLkThink','think']].forEach(([id,k])=>{const t=$('#'+id);t.onclick=()=>{l[k]=!l[k];t.classList.toggle('on',l[k]);sv();if(k==='lip'&&!l[k])lzTalk(false);if(k==='on'&&!l.on){try{mdl()&&mdl().emote&&mdl().emote('',0,0)}catch(e){}}}});
  const g=document.querySelector('#sc .seg[data-k="expr"]');g.onclick=e=>{const b=e.target.closest('button[data-v]');if(!b)return;l.expr=b.dataset.v;g.querySelectorAll('button').forEach(x=>x.classList.toggle('on',x===b));sv()};
  $('#lzLkK').oninput=e=>{l.k=+e.target.value;$('#lzLkKv').textContent=Math.round(l.k*100)+'%';sv()};
  $('#lzLkTest').onclick=e=>{const b=e.target.closest('button[data-e]');if(!b)return;const M=mdl();if(!M)return;const k=b.dataset.e;
    if(k==='nod'){M.nodOnce&&M.nodOnce()}else if(k==='talk'){M.speak&&M.speak('Halo, ini tes mulut bergerak selama beberapa detik.')}else{M.emote&&M.emote(k,+l.k||.7,4)}};
  $('#lzBack').onclick=()=>open('chat')}
const nbs=[...document.querySelectorAll('.nb')];let lastFocus=null;
function open(k,keep){if(k==='home')return goHome();if(k==='akun'){if(acctOpen&&$('#sheet').classList.contains('on')){close();return}return toggleAcct()}
if(k==='fokus'){if(acctOpen&&!keep)toggleAcct();close();enterFocus();return}
if(typeof views[k]!=='function'){console.warn('view missing',k);toast('Fitur belum siap');return}
if(acctOpen&&!keep){try{const pg=$('#acct');pg.classList.remove('on');acctOpen=false;pg.setAttribute('aria-hidden','true');pg.inert=true}catch(e){}}
const sc=$('#sc');sc.innerHTML=views[k]();const sh=$('#sheet');if(!sh.classList.contains('on'))lastFocus=document.activeElement;sh.inert=false;sh.classList.add('on');$('#scrim').classList.add('on');
const hl=(keep&&acctOpen)?'akun':(k.slice(0,2)==='c-'?'chat':k);nbs.forEach(b=>b.classList.toggle('on',b.dataset.open===hl));
if(k==='chat'){$('#bd').style.display='none';initChat()}
if(k==='file')initFM();
if(k==='profil')initPF();
if(k==='a-edit')initEdit();
if(k==='komentar')initCmt();
if(k==='border')initBorder();
if(k==='teman')initFriends();
if(k==='karakter')initChar();
if(k==='skor')initSkor();
if(k==='catatan')initNotes();
if(k==='belajar')initLearn();
if(k==='game')initGame();
if(k==='tugas')initTodo();
if(k==='cuaca')initWeather();
if(k==='konversi')initConv();
if(k==='cari')initCari();
if(k==='backend')initBackend();
if(k==='c-pers')initPers();
if(k==='c-mem')initMem();
if(k==='c-suara')initSuara();
if(k==='c-link')initLink();
if(k==='set'){$('#op').onclick=()=>{close();openPlayer()};const fb=$('#fxb');fb.onclick=()=>{const on=!fxOn();try{localStorage.setItem('luma-fx',on?'1':'0')}catch(e){}fb.classList.toggle('on',on);if(on)fxSync()}}
setTimeout(()=>{const f=sc.querySelector('input:not([type=hidden]),textarea,button');(f&&k!=='file'&&k!=='chat'&&k!=='backend'&&k.slice(0,2)!=='c-'?f:sh).focus({preventScroll:true})},60);
navigator.vibrate&&navigator.vibrate(10)}
function close(){const sh=$('#sheet'),was=sh.classList.contains('on');sh.classList.remove('on');sh.inert=true;$('#scrim').classList.remove('on');if(was&&lastFocus&&lastFocus.focus&&document.contains(lastFocus)){try{lastFocus.focus({preventScroll:true})}catch(e){}}lastFocus=null;nbs.forEach(b=>b.classList.remove('on'));$('[data-open="'+(acctOpen?'akun':'home')+'"]').classList.add('on')}
document.querySelectorAll('[data-open]').forEach(b=>b.onclick=()=>open(b.dataset.open));
$('#scrim').onclick=close;addEventListener('keydown',e=>e.key==='Escape'&&close());
/* focus trap di dalam sheet */
$('#sheet').addEventListener('keydown',e=>{if(e.key!=='Tab')return;const f=[...$('#sheet').querySelectorAll('a[href],button:not([disabled]),input:not([disabled]):not([hidden]),textarea,select,[tabindex]:not([tabindex="-1"])')].filter(x=>x.offsetParent!==null);if(!f.length)return;const a=f[0],z=f[f.length-1];if(e.shiftKey&&(document.activeElement===a||document.activeElement===$('#sheet'))){e.preventDefault();z.focus()}else if(!e.shiftKey&&document.activeElement===z){e.preventDefault();a.focus()}});
let y0=null;$('#sheet').addEventListener('touchstart',e=>y0=e.touches[0].clientY,{passive:true});
$('#sheet').addEventListener('touchend',e=>{if(y0!==null&&e.changedTouches[0].clientY-y0>70)close();y0=null});
// tab
let started=false,activeTab='musik';const syncMini=()=>{$('#mini').hidden=!(started&&activeTab!=='musik')};
const tabs=[...document.querySelectorAll('.tabs button')];
// bagian Musik/Video hanya tampil saat ada yang diputar; setelah berhenti, disembunyikan lagi setelah jeda singkat
(()=>{const info=$('#info');let off=0;const R=document.documentElement,set=v=>{if(info.classList.contains('nomedia')===v)return;info.classList.toggle('nomedia',v);R.classList.toggle('idle-media',v);requestAnimationFrame(()=>requestAnimationFrame(()=>window.__lumaFrame&&window.__lumaFrame()))};const on=()=>{clearTimeout(off);off=0;set(false)};
setInterval(()=>{const vpEl=$('#vp'),act=(typeof playing!=='undefined'&&playing)||(vpEl&&!vpEl.paused&&!vpEl.ended);
if(act)on();else if(!off&&!info.classList.contains('nomedia'))off=setTimeout(()=>{off=0;set(true)},12000)},400)})();
new MutationObserver(()=>document.documentElement.classList.toggle('mini-on',!$('#mini').hidden)).observe($('#mini'),{attributes:true,attributeFilter:['hidden']});
tabs.forEach((b,i)=>b.onclick=()=>{activeTab=b.dataset.t;tabs.forEach(x=>{x.classList.toggle('on',x===b);x.setAttribute('aria-selected',x===b)});$('.ind').style.transform=`translateX(${i*100}%)`;document.querySelectorAll('.panel').forEach(p=>p.classList.toggle('on',p.dataset.p===b.dataset.t));if(activeTab!=='video')$('#vp').pause();syncMini()});
// warna otomatis dari karakter
let mode=262,autoH=262;
function setHue(h){document.documentElement.style.setProperty('--h',h);if(+h===204)document.documentElement.setAttribute('data-acc','sky');else document.documentElement.removeAttribute('data-acc')}
function calcHue(){const im=$('#hero'),w=120,h=Math.round(w*im.naturalHeight/im.naturalWidth),c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d',{willReadFrequently:true});try{x.drawImage(im,0,0,w,h);const d=x.getImageData(0,0,w,h).data;let sx=0,sy=0;for(let i=0;i<d.length;i+=4){if(d[i+3]<200)continue;const r=d[i]/255,g=d[i+1]/255,b=d[i+2]/255,mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(mx+mn)/2;if(mx===mn)continue;const s=(mx-mn)/(1-Math.abs(2*l-1));if(s<.18||l<.2||l>.93)continue;let H=mx===r?((g-b)/(mx-mn))%6:mx===g?(b-r)/(mx-mn)+2:(r-g)/(mx-mn)+4;H*=Math.PI/3;sx+=Math.cos(H)*s;sy+=Math.sin(H)*s}if(sx||sy)autoH=Math.round((Math.atan2(sy,sx)*180/Math.PI+360)%360)}catch(e){}if(mode==='auto')setHue(autoH)}
$('#hero').complete&&calcHue();
// ucapan karakter
let bt;
function say(s){const b=$('#bub');b.textContent=s;b.classList.add('on');clearTimeout(bt);bt=setTimeout(()=>b.classList.remove('on'),2800)}
// pesan
const chatLog=[['a','Halo! Aku LUMA ✌️',Date.now()],['a','Ada yang bisa aku bantu hari ini?',Date.now()]];
const esc=s=>s.replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
let SM,smTried=false,ctl=null,busy=false,aiOff=false;const aiTurns=[];
async function getSM(){if(smTried)return SM;smTried=true;try{SM=window.claude?await window.claude.use('sample'):null}catch(e){SM=null}return SM}
/* pengetahuan tentang LUMA (dari catatan proyek) yang disisipkan ke prompt AI */
const LUMAKB=`Pengetahuan tentang LUMA (aplikasi tempat kamu berjalan):
- LUMA = Link, Universal, Multifunction, Assistant. Tagline: "A Light for Your Digital World". Platform awal: Android. LUMA adalah ekosistem digital multifungsi (AI, hiburan, kreativitas, produktivitas) dalam satu aplikasi, bukan sekadar chatbot.
- Arti nama: cahaya yang membantu pengguna menjalani dunia digital, sekaligus permainan kata dari "lumba-lumba" yang jadi inspirasi maskot (simbol kecerdasan, keramahan, interaksi, rasa ingin tahu).
- Logo: siluet lumba-lumba berbentuk huruf C, warna biru tua, ungu, toska, dengan detail putih (termasuk mata). Huruf C berarti Connection (menghubungkan fitur dan kebutuhan digital) dan Creative (mendukung kreativitas) sebagai makna utama, serta Continuity (pengalaman berkesinambungan) dan Companion (teman aktivitas sehari-hari) sebagai nilai pendukung.
- Visi: satu aplikasi sebagai pusat aktivitas digital, tanpa pindah-pindah aplikasi.
- Prinsip: multifungsi, modular, terintegrasi, kreatif (membantu membuat sesuatu, bukan hanya menjawab), personal, berkelanjutan, praktis, bertahap, transparan.
- Sudah ada di aplikasi: chat AI, pencarian web (tab Cari), penampil model 3D VRM/PMX, pemutar musik dan video, pengelola berkas, catatan, to-do, penghitung skor, cuaca, konversi, mode fokus, serta di menu chat: personalisasi (nama panggilan, gaya bicara, panjang jawaban), catatan memori manual, dan suara balasan (teks-ke-suara bawaan browser, mulut model ikut bergerak), serta pengaturan Hubungan AI ke Model (ekspresi wajah model dipilih AI atau dari teks, mengangguk, tampak berpikir saat menunggu, mulut ikut bicara).
- Masih rencana, belum jadi: memori otomatis (yang sudah ada baru catatan memori manual), memahami gambar, pencarian web langsung di chat, basis pengetahuan, interaksi karakter 3D dengan AI yang lebih dalam.
Aturan: jawab pertanyaan tentang LUMA berdasarkan info ini, dengan ringkas. Jangan mengklaim fitur yang belum jadi sudah tersedia, dan jangan mengarang detail lain (harga, tanggal rilis, tim). Jika tidak tahu, katakan tidak tahu.`;
/* ===== personalisasi, memori, suara (tersimpan di perangkat) ===== */
const LPK='luma-pers',LMK='luma-mem',LSK='luma-voice';
const PERS_D={nick:'',tone:'ceria',len:'singkat',extra:''},VOICE_D={on:false,voice:'',rate:1,pitch:1,eng:'dev',gkey:'',gvoice:'Kore',gmodel:'gemini-3.8-flash-lite-tts',fkey:'',fref:'',fmodel:'s2.1-pro-free'};
const jget=(k,d)=>{try{const o=JSON.parse(localStorage.getItem(k)||'{}');return Object.assign({},d,o&&typeof o==='object'?o:{})}catch(e){return Object.assign({},d)}};
const jset=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}};
const memGet=()=>{try{const o=JSON.parse(localStorage.getItem(LMK)||'{}')||{};return {on:o.on!==false,items:(Array.isArray(o.items)?o.items:[]).filter(x=>typeof x==='string').slice(0,50)}}catch(e){return {on:true,items:[]}}};
const memSet=o=>{try{localStorage.setItem(LMK,JSON.stringify(o));return true}catch(e){return false}};
const persExtra=()=>{const p=jget(LPK,PERS_D),m=memGet(),L=[];
  if(p.nick)L.push('Panggil pengguna "'+String(p.nick).slice(0,24)+'".');
  const T={santai:'Gaya bicara: santai dan akrab, seperti teman dekat.',lembut:'Gaya bicara: lembut, tenang, dan menenangkan.',formal:'Gaya bicara: sopan dan formal.'};
  if(T[p.tone])L.push(T[p.tone]);
  const N={sedang:'Panjang jawaban: sedang (3 sampai 6 kalimat) bila perlu; ini menggantikan batas 1 sampai 4 kalimat di atas.',panjang:'Panjang jawaban: boleh rinci dan panjang bila topiknya butuh; ini menggantikan batas 1 sampai 4 kalimat di atas.'};
  if(N[p.len])L.push(N[p.len]);
  if(p.extra)L.push('Preferensi tambahan dari pengguna (ikuti selama tidak melanggar aturan di atas): '+String(p.extra).slice(0,300));
  if(m.on&&m.items.length)L.push('Catatan memori tentang pengguna (ditulis pengguna sendiri; pakai hanya bila relevan dan jangan diumbar):\n'+m.items.map(x=>'- '+x).join('\n'));
  return L.length?'Personalisasi:\n'+L.join('\n')+'\n\n':''};
const VOICEOK=typeof speechSynthesis!=='undefined'&&typeof SpeechSynthesisUtterance!=='undefined';
let vtok=0;
const speechClean=t=>String(t||'').replace(/https?:\/\/\S+/g,' ').replace(/[*_`#>~]/g,'').replace(/[\u{1F000}-\u{1FFFF}\u{2600}-\u{27BF}\u{FE0F}\u{200D}]/gu,'').replace(/\s+/g,' ').trim();
const lzTalk=on=>{try{if(on&&!linkOn('lip'))return;window.__lumaModel&&window.__lumaModel.talk&&window.__lumaModel.talk(on)}catch(e){}};
let gEl=null,gCtl=null;
const SILENT_WAV='data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAIA+AAACABAAZGF0YQAAAAA=';
const gAudio=()=>gEl||(gEl=new Audio());
const lzUnlock=()=>{try{const a=gAudio();a.src=SILENT_WAV;const r=a.play();r&&r.catch&&r.catch(()=>{})}catch(e){}};
['click','touchend'].forEach(t=>document.addEventListener(t,lzUnlock,{once:true,capture:true}));
function lzStop(){vtok++;try{VOICEOK&&speechSynthesis.cancel()}catch(e){}try{gCtl&&gCtl.abort()}catch(e){}gCtl=null;try{if(gEl){gEl.onplay=gEl.onended=gEl.onerror=null;gEl.pause()}}catch(e){}lzTalk(false)}
/* Gemini TTS: balasan PCM 16-bit mono dibungkus jadi WAV lalu diputar */
const GTTS_VOICES=['Kore','Puck','Zephyr','Aoede','Leda','Callirrhoe','Autonoe','Charon','Fenrir','Orus','Achird','Sulafat'];
const gKey=v=>(v.gkey||'').trim()||(((lkGet().keys||{}).gemini||[])[0]||'').trim();
const gModel=v=>{const m=(v.gmodel||'').trim();return !m||/^gemini-2\.5-.*tts/.test(m)?VOICE_D.gmodel:m};
function pcmWav(u8,rate){const n=u8.length,b=new ArrayBuffer(44+n),d=new DataView(b),w=(o,t)=>{for(let k=0;k<t.length;k++)d.setUint8(o+k,t.charCodeAt(k))};
  w(0,'RIFF');d.setUint32(4,36+n,true);w(8,'WAVE');w(12,'fmt ');d.setUint32(16,16,true);d.setUint16(20,1,true);d.setUint16(22,1,true);d.setUint32(24,rate,true);d.setUint32(28,rate*2,true);d.setUint16(32,2,true);d.setUint16(34,16,true);w(36,'data');d.setUint32(40,n,true);new Uint8Array(b,44).set(u8);return new Blob([b],{type:'audio/wav'})}
async function gemTTS(text,v,signal){
  const key=gKey(v);if(!key)throw new Error('API key Gemini belum diisi');
  const model=gModel(v);
  const r=await fetch('https://generativelanguage.googleapis.com/v1beta/models/'+encodeURIComponent(model)+':generateContent',{method:'POST',signal,headers:{'Content-Type':'application/json','x-goog-api-key':key},
    body:JSON.stringify({contents:[{parts:[{text}]}],generationConfig:{responseModalities:['AUDIO'],speechConfig:{voiceConfig:{prebuiltVoiceConfig:{voiceName:v.gvoice||'Kore'}}}}})});
  const d=await r.json().catch(()=>({}));
  if(!r.ok)throw new Error('HTTP '+r.status+': '+String((d.error&&d.error.message)||'ditolak').slice(0,140));
  const part=(((d.candidates||[])[0]||{}).content||{}).parts;const inl=part&&part.map(x=>x.inlineData).find(Boolean);
  if(!inl||!inl.data)throw new Error('Gemini tidak mengirim audio');
  const bin=atob(inl.data),u8=new Uint8Array(bin.length);for(let k=0;k<bin.length;k++)u8[k]=bin.charCodeAt(k);
  if(u8.length>12&&String.fromCharCode(u8[0],u8[1],u8[2],u8[3])==='RIFF')return new Blob([u8],{type:'audio/wav'});
  const m=/rate=(\d+)/.exec(inl.mimeType||'');return pcmWav(u8,m?+m[1]:24000)}
/* Fish Audio: POST /v1/tts, balasan berupa berkas mp3 */
const fModel=v=>{const m=(v.fmodel||'').trim();return !m||m==='s1'?VOICE_D.fmodel:m};
async function fishTTS(text,v,signal){
  const key=(v.fkey||'').trim();if(!key)throw new Error('API key Fish Audio belum diisi');
  const ref=(v.fref||'').trim(),model=fModel(v);
  const body={text,format:'mp3',mp3_bitrate:128,latency:'normal'};if(ref)body.reference_id=ref;
  let r;
  try{r=await fetch('https://api.fish.audio/v1/tts',{method:'POST',signal,headers:{'Content-Type':'application/json','Authorization':'Bearer '+key,'model':model},body:JSON.stringify(body)})}
  catch(e){
    if(!e||e.name!=='TypeError')throw e;
    /* diblokir browser (CORS) → lewat backend LUMA */
    const base=searchBase();let r2;
    if(mixedBlocked(base))throw new Error('diblokir browser (CORS) dan backend HTTP tidak bisa dipakai dari halaman HTTPS');
    try{r2=await fetch(base+'/api/tts',{method:'POST',signal,headers:authH({'Content-Type':'application/json'}),body:JSON.stringify({key,text,reference_id:ref,model})})}
    catch(e2){if(e2&&e2.name==='AbortError')throw e2;throw new Error('Fish Audio diblokir browser (CORS) dan backend LUMA ('+base+') tidak menjawab. Jalankan python3 server.py di folder backend.')}
    if(!r2.ok){let m='';try{const d=await r2.json();m=d.message||d.error||''}catch(x){}throw new Error('Backend '+r2.status+': '+String(m||'ditolak').slice(0,140))}
    const b2=await r2.blob();if(!b2.size)throw new Error('Fish Audio tidak mengirim audio');return b2}
  if(!r.ok){let m='';try{const d=await r.json();m=d.message||d.detail||''}catch(e){}throw new Error('HTTP '+r.status+': '+String(m||'ditolak').slice(0,140))}
  const b=await r.blob();if(!b.size)throw new Error('Fish Audio tidak mengirim audio');return b}
function lzSayDev(s,v){
  try{speechSynthesis.cancel()}catch(e){}
  const tok=++vtok,u=new SpeechSynthesisUtterance(s),vs=speechSynthesis.getVoices();
  const pick=vs.find(x=>x.voiceURI===v.voice)||vs.find(x=>/^id/i.test(x.lang));
  if(pick){u.voice=pick;u.lang=pick.lang}else u.lang='id-ID';
  u.rate=Math.min(1.6,Math.max(.6,+v.rate||1));u.pitch=Math.min(1.8,Math.max(.5,+v.pitch||1));
  u.onstart=()=>{if(tok===vtok)lzTalk(true)};u.onend=u.onerror=()=>{if(tok===vtok)lzTalk(false)};
  try{speechSynthesis.speak(u);return true}catch(e){return false}}
function lzSay(text,force){const v=jget(LSK,VOICE_D);if(!v.on&&!force)return false;
  const s=speechClean(text).slice(0,600);if(!s)return false;
  const cloud=v.eng==='gemini'&&gKey(v)?gemTTS:v.eng==='fish'&&(v.fkey||'').trim()?fishTTS:null;
  if(cloud){
    lzStop();const tok=vtok,ac=new AbortController();gCtl=ac;
    cloud(s,v,ac.signal).then(blob=>{if(tok!==vtok)return;const a=gAudio(),u=URL.createObjectURL(blob);a.onplay=a.onended=a.onerror=null;a.src=u;a.playbackRate=Math.min(1.6,Math.max(.6,+v.rate||1));
      a.onplay=()=>{if(tok===vtok)lzTalk(true)};a.onended=a.onerror=()=>{if(tok===vtok)lzTalk(false);try{URL.revokeObjectURL(u)}catch(e){}};
      return a.play()}).catch(e=>{if(e&&e.name==='AbortError')return;if(tok!==vtok)return;
      let m=(e&&e.message)||'coba lagi';if(e&&e.name==='TypeError')m='tidak bisa terhubung ke server suara (jaringan atau diblokir browser/CORS)';else if(e&&e.name==='NotAllowedError')m='browser memblokir pemutaran otomatis, ketuk layar lalu coba lagi';else if(e&&e.name==='NotSupportedError')m='format audio tidak didukung browser';
      window.__lzErr=m;toast('Suara AI gagal: '+m,6000);const el=document.querySelector('#lzVoMsg');if(el)el.textContent='Gagal: '+m;if(VOICEOK)lzSayDev(s,v)});
    return true}
  if(!VOICEOK)return false;
  return lzSayDev(s,v)}
/* ===== hubungan AI ke model 3D ===== */
const LLK='luma-link',LINK_D={on:true,expr:'ai',nod:true,lip:true,think:true,k:.7};
const linkG=()=>jget(LLK,LINK_D);
const linkOn=k=>{const l=linkG();return !!(l.on&&l[k])};
const EMO_TAG=/^\s*\[(netral|senang|sedih|marah|kaget|tenang)\]\s*/i;
const EMO_MAP={senang:'happy',sedih:'sad',marah:'angry',kaget:'surprised',tenang:'relaxed'};
const stripEmo=t=>String(t==null?'':t).replace(EMO_TAG,'').replace(/^\s*\[[a-z]{0,8}$/i,'');
const emoGuess=t=>{const s=String(t||'').toLowerCase();
  if(/😠|😡|🤬|marah|kesal|sebal/.test(s))return 'angry';
  if(/😢|😭|😞|😔|🥺|sedih|maaf|sayang sekali|turut berduka|kasihan/.test(s))return 'sad';
  if(/😮|😲|😱|🤯|astaga|wah[!,.]|kaget|serius\?|\?!/.test(s))return 'surprised';
  if(/😌|🙂|tenang|santai|tarik napas|pelan-pelan/.test(s))return 'relaxed';
  if(/😊|😄|😁|😆|😍|🥰|✌|✨|🎉|senang|hore|yay|haha|hehe|semangat|keren|bagus/.test(s))return 'happy';
  return ''};
const mdl=()=>window.__lumaModel||null;
const linkInstr=()=>{const l=linkG();return l.on&&l.expr==='ai'?'Hubungan ke model 3D: awali setiap balasan dengan satu tag emosi dalam kurung siku untuk mengatur ekspresi wajah modelmu, pilih salah satu: [netral], [senang], [sedih], [marah], [kaget], [tenang]. Contoh: "[senang] Hai, senang ketemu kamu!". Tag itu hanya untuk sistem; jangan menjelaskannya dan jangan menaruhnya di tengah kalimat.\n\n':''};
function linkReact(raw){const l=linkG(),M=mdl();if(!l.on||!M)return;
  const clean=stripEmo(raw),dur=Math.min(10,Math.max(3,2.5+clean.length*.04));
  if(l.expr!=='mati'&&M.emote){let e='';const m=String(raw).match(EMO_TAG);
    if(l.expr==='ai'&&m)e=EMO_MAP[m[1].toLowerCase()]||'';else e=emoGuess(clean);
    M.emote(e,l.k,dur)}
  if(l.nod&&M.nodOnce)M.nodOnce()}
const persona=()=>`Kamu berperan sebagai ${nice(PF.name)}, asisten ramah dari "${PF.series}". Sifatmu ceria, penasaran, dan hangat. Aturan: balas dalam bahasa yang dipakai pengguna (utamanya Indonesia), singkat seperti chat (1 sampai 4 kalimat), tanpa format markdown. Tetap dalam karakter, tetapi jika ditanya langsung, akui bahwa kamu karakter AI. Jangan mengaku punya akses ke internet atau data nyata. Jika pengguna tampak sedih atau butuh bantuan serius, tanggapi dengan peduli dan sarankan bicara dengan orang terdekat atau tenaga profesional.\n\n${persExtra()}${linkInstr()}${LUMAKB}`;
const CPKEY='luma-chat-prov';
const chatProv=()=>{try{const v=localStorage.getItem(CPKEY);return ['gemini','groq','openai'].includes(v)?v:'auto'}catch(e){return 'auto'}};
let lastProv='',chatUI=null;
const IC_SEND='<svg viewBox="0 0 24 24" fill="currentColor"><path d="M3.4 20.4l17.5-7.5a1 1 0 0 0 0-1.8L3.4 3.6a1 1 0 0 0-1.4 1.2L4 11l9 1-9 1-2 6.2a1 1 0 0 0 1.4 1.2z"/></svg>';
const IC_VON='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5L6 9H3v6h3l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13"/></svg>';
const IC_VOFF='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5L6 9H3v6h3l5 4z"/><path d="M22 9l-6 6M16 9l6 6"/></svg>';
const IC_STOP='<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="6" width="12" height="12" rx="2.5"/></svg>';
const chatTime=t=>t?new Date(t).toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'}):'';
const chatRich=t=>esc(t).replace(/\*\*(.+?)\*\*/g,'<b>$1</b>');
const BTKEY='luma-backend-token';
const getToken=()=>{try{return (localStorage.getItem(BTKEY)||'').trim()}catch(e){return ''}};
const setToken=v=>{try{if(v)localStorage.setItem(BTKEY,v);else localStorage.removeItem(BTKEY);return true}catch(e){return false}};
const authH=x=>{const t=getToken();return Object.assign({},x||{},t?{Authorization:'Bearer '+t}:{})};
try{localStorage.removeItem('luma-ai-keys');localStorage.removeItem('luma-model-auto')}catch(e){} /* migrasi keamanan: API key penyedia AI tidak lagi disimpan di browser */
const PNAME={gemini:'Gemini',groq:'Groq',openai:'OpenAI'};
const PROVS=['gemini','groq','openai'];

const NOKEY_MSG='API key belum diisi. Ketuk ikon kunci di kanan atas chat, lalu isi API key.';
const cleanTurns=t=>{const a=t.slice();while(a.length&&a[0].role!=='user')a.shift();return a};
async function askBackend(signal){
  const base=searchBase();
  if(mixedBlocked(base)){const e=new Error('Halaman ini HTTPS tapi server AI HTTP, jadi diblokir browser. Buka LUMA lewat http:// di jaringan lokal atau pakai server HTTPS.');e.code='mixed';throw e}
  let r;
  try{r=await fetch(base+'/api/chat',{method:'POST',headers:authH({'Content-Type':'application/json'}),signal,body:JSON.stringify({provider:chatProv(),system:persona(),messages:aiTurns.slice(-12)})})}
  catch(e){if(e&&e.name==='AbortError')throw e;const x=new Error('Tidak bisa terhubung ke server di '+base+'. Pastikan backend sedang jalan, lalu coba lagi.');x.code='network';throw x}
  const d=await r.json().catch(()=>({error:'bad_json'}));
  if(!r.ok||d.error||!d.text){const x=new Error(d.error==='unauthorized'?'Token akses salah atau belum diisi. Ketuk ikon kunci di kanan atas chat untuk mengisinya.':d.error==='not_configured'?'Chat AI belum diatur. Ketuk ikon kunci di kanan atas chat lalu isi API key, atau isi key di backend/config.env.':(d.message||'Server AI mengembalikan error ('+r.status+').'));x.code=d.error||'http_'+r.status;throw x}
  return d;
}
const chatErrMsg=e=>(e&&e.message)||'Chat AI sedang tidak bisa menjawab. Coba lagi sebentar.';
async function runChat(text){
  const ui=()=>chatUI&&$('#cl')===chatUI.cl?chatUI:null;
  const refresh=()=>{const u=ui();if(u){u.draw();u.sync()}};
  try{lzStop()}catch(e){}aiTurns.push({role:'user',content:text});
  const slot=['a','',0];chatLog.push(slot);busy=true;ctl=new AbortController();refresh();
  try{if(linkOn('think')&&mdl()&&mdl().emote)mdl().emote('relaxed',.5,90)}catch(e){}
  let emoted=false;
  const fin=t=>{const c=stripEmo(t);slot[1]=c;slot[2]=Date.now();aiTurns.push({role:'assistant',content:t});emoted=true;try{if(linkOn('lip')&&window.__lumaModel&&window.__lumaModel.speak)window.__lumaModel.speak(c)}catch(e){}try{linkReact(t)}catch(e){}try{lzSay(c)}catch(e){}};
  const drop=()=>{const k=chatLog.indexOf(slot);if(k>-1)chatLog.splice(k,1);if(aiTurns.length&&aiTurns[aiTurns.length-1].role==='user')aiTurns.pop()};
  let err=null;const errs=[];
  try{let got=false;
    if(!got){
      try{const d=await askAny(ctl.signal);lastProv=d.provider||'AI';fin(d.text);got=true}
      catch(e){
        if(e&&e.name==='AbortError'){drop();return}
        if(e&&e.code==='rate_limited'){drop();toast('Terlalu sering, coba lagi sebentar lagi');return}
        err=e}}
    if(!got){const sm=await getSM();
      if(sm&&!aiOff){try{const r=await sm([{role:'user',content:persona()},...aiTurns.slice(-12)],{cache:false,signal:ctl.signal,modelTier:'quick',onText:({text})=>{slot[1]=stripEmo(text);const u=ui();if(u){u.draw()}}});lastProv='';fin(r.text);got=true}
      catch(e){const c=e&&e.code;if(c==='cancelled'||(e&&e.name==='AbortError')){if(e&&e.text)fin(e.text);else drop();return}
        if(['not_granted','sampling_disabled','not_declared','capability_disabled','capability_removed'].includes(c))aiOff=true;
        else if(c==='rate_limited'){drop();toast('Terlalu sering, coba lagi sebentar lagi');return}
        else if(c==='session_expired'){drop();toast('Masuk lagi ke akunmu untuk melanjutkan');return}}}}
    if(!got){drop();const msg=chatErrMsg(err);chatLog.push(['e',msg,Date.now(),text])}
  }finally{busy=false;ctl=null;refresh();if(!emoted){try{mdl()&&mdl().emote&&mdl().emote('',0,0)}catch(e){}}}
}

/* ===== API key lokal (pemakaian pribadi): disimpan di perangkat, dipanggil langsung dari browser ===== */
const LK='luma-ai-keys';
const DEFM={gemini:'gemini-flash-latest',groq:'llama-3.3-70b-versatile',openai:'gpt-6-luna'};
const PRESM={gemini:['gemini-3.8-flash','gemini-3.7-flash','gemini-3.5-flash-lite','gemini-3.1-flash-lite','gemini-3-flash-preview','gemini-flash-latest','gemini-flash-lite-latest','gemini-2.5-flash','gemini-2.5-flash-lite','gemini-3.1-pro-preview','gemini-pro-latest','gemini-2.5-pro'],groq:['llama-3.3-70b-versatile','llama-3.1-8b-instant','meta-llama/llama-4-scout-17b-16e-instruct','openai/gpt-oss-120b','openai/gpt-oss-20b'],openai:['gpt-6-luna','gpt-5','gpt-5-mini','gpt-4.1','gpt-4.1-mini','gpt-4o-mini']};
/* model yang masuk paket gratis (ada batas per menit/hari); Pro Gemini umumnya berbayar */
const FREEM=new Set(['gemini-3.8-flash','gemini-3.7-flash','gemini-3.5-flash-lite','gemini-3.1-flash-lite','gemini-3-flash-preview','gemini-flash-latest','gemini-flash-lite-latest','gemini-2.5-flash','gemini-2.5-flash-lite','llama-3.3-70b-versatile','llama-3.1-8b-instant','meta-llama/llama-4-scout-17b-16e-instruct','openai/gpt-oss-120b','openai/gpt-oss-20b']);
const PROM=new Set(['gemini-3.1-pro-preview','gemini-pro-latest','gemini-2.5-pro']);
const mlabel=x=>x+(FREEM.has(x)?' · gratis':PROM.has(x)?' · umumnya berbayar':'')+(x==='gemini-3.8-flash'?' · terbaru':'');
const lkGet=()=>{try{const o=JSON.parse(localStorage.getItem(LK)||'{}')||{};return {keys:o.keys||{},models:o.models||{},gs:o.gs||{}}}catch(e){return {keys:{},models:{},gs:{}}}};
const lkSet=o=>{try{localStorage.setItem(LK,JSON.stringify(o));return true}catch(e){return false}};
const parseKeys=s=>[...new Set(String(s||'').split(/[\s,;]+/).map(x=>x.trim()).filter(Boolean))];
const localProvs=()=>{const k=lkGet().keys;return PROVS.filter(p=>Array.isArray(k[p])&&k[p].length)};
class LErr extends Error{constructor(m,s){super(m);this.status=s}}
async function jpost(url,headers,body,signal){
  let r;try{r=await fetch(url,{method:'POST',headers:Object.assign({'Content-Type':'application/json'},headers),body:JSON.stringify(body),signal})}
  catch(e){if(e&&e.name==='AbortError')throw e;throw new LErr('tidak bisa dihubungi',0)}
  const d=await r.json().catch(()=>({}));
  if(!r.ok){const er=d&&d.error;throw new LErr(String((er&&er.message)||(typeof er==='string'?er:'')||'ditolak').slice(0,120),r.status)}
  return d}
const directCall={
 async gemini(key,model,system,msgs,signal){
  const url='https://generativelanguage.googleapis.com/v1beta/models/'+encodeURIComponent(model)+':generateContent',hd={'x-goog-api-key':key};
  /* Gemini 3.x berpikir dulu: tingkat 'low' + batas token lebih longgar agar jawaban tidak kosong */
  const mk=th=>({systemInstruction:{parts:[{text:system}]},contents:msgs.map(m=>({role:m.role==='user'?'user':'model',parts:[{text:m.content}]})),generationConfig:Object.assign({maxOutputTokens:2048,temperature:.9},th?{thinkingConfig:{thinkingLevel:'low'}}:{})});
  const th=/^gemini-(3|[a-z-]*latest)/.test(model);
  let d;try{d=await jpost(url,hd,mk(th),signal)}catch(e){if(th&&e&&e.status===400&&/think/i.test(e.message))d=await jpost(url,hd,mk(false),signal);else throw e}
  const c=(d.candidates||[])[0],t=((c&&c.content&&c.content.parts)||[]).filter(p=>!p.thought).map(p=>p.text||'').join('').trim();
  if(!t)throw new LErr(c&&c.finishReason==='MAX_TOKENS'?'jawaban terpotong (batas token)':'jawaban kosong atau diblokir',0);
  return c.finishReason==='MAX_TOKENS'?t+'…':t},
 async groq(key,model,system,msgs,signal){
  const d=await jpost('https://api.groq.com/openai/v1/chat/completions',{Authorization:'Bearer '+key},Object.assign({model,messages:[{role:'system',content:system},...msgs],temperature:.9},/gpt-oss/.test(model)?{max_completion_tokens:1500,reasoning_effort:'low'}:{max_tokens:400}),signal);
  const c=(d.choices||[])[0],t=((c&&c.message&&c.message.content)||'').trim();
  if(!t)throw new LErr('jawaban kosong',0);return t},
 async openai(key,model,system,msgs,signal){
  const b={model,messages:[{role:'system',content:system},...msgs],max_completion_tokens:2000};
  if(/^(gpt-[56]|o\d)/.test(model))b.reasoning_effort='low';
  const d=await jpost('https://api.openai.com/v1/chat/completions',{Authorization:'Bearer '+key},b,signal);
  const c=(d.choices||[])[0],t=((c&&c.message&&c.message.content)||'').trim();
  if(!t)throw new LErr(c&&c.finish_reason==='length'?'kehabisan token sebelum selesai':'jawaban kosong',0);
  return c.finish_reason==='length'?t+'…':t}
};
/* mencoba semua key lokal; null bila belum ada key untuk penyedia terpilih */
async function askLocal(signal){
  const sel=chatProv(),order=sel==='auto'?PROVS:[sel],L=lkGet();
  const turns=cleanTurns(aiTurns.slice(-12)).map(m=>({role:m.role,content:String(m.content).slice(0,1000)}));
  let last=null,any=false;
  for(const p of order){const ks=L.keys[p]||[];if(!ks.length)continue;any=true;
    for(const k of ks){
      try{const t=await directCall[p](k,L.models[p]||DEFM[p],persona(),turns,signal);return {text:t,provider:PNAME[p]}}
      catch(e){if(e&&e.name==='AbortError')throw e;last=e;last.prov=PNAME[p];const s=e&&e.status,m=(e&&e.message)||'';
        if(s===401||s===403||s===429||(s===400&&/key/i.test(m)))continue; /* key berikutnya */
        break}}} /* penyedia berikutnya */
  if(!any)return null;
  const x=new Error('Semua API key gagal'+(last?' ('+last.prov+': '+last.message+')':'')+'. Cek di ikon kunci, lalu coba lagi.');x.code='local';throw x}
async function askAny(signal){
  let le=null;
  if(localProvs().length){try{const d=await askLocal(signal);if(d)return d}catch(e){if(e&&e.name==='AbortError')throw e;le=e}}
  try{return await askBackend(signal)}
  catch(e){if(e&&e.name==='AbortError')throw e;throw (le&&['network','not_configured','unauthorized','mixed'].includes(e.code))?le:e}}
async function searchDirect(q,signal,g=lkGet().gs){
  const r=await fetch('https://www.googleapis.com/customsearch/v1?'+new URLSearchParams({key:g.key,cx:g.cx,q,num:8,hl:'id'}),{signal});
  const d=await r.json().catch(()=>({}));
  if(!r.ok)return {error:'http_'+r.status,direct:1,message:'Google Search: '+(((d.error||{}).message)||('error '+r.status))};
  const it=(d.items||[]).map(i=>({title:i.title||'',link:i.link||'',displayLink:i.displayLink||'',snippet:String(i.snippet||'').replace(/\s+/g,' ')}));
  return {items:it,count:it.length,searchTime:d.searchInformation&&d.searchInformation.formattedSearchTime}}
function initKeys(){
  const m=(t,bad)=>{const e=$('#kkmsg');if(e){e.textContent=t;e.style.color=bad?'#e5484d':'var(--mute)'}};
  const tas=PROVS.map(p=>$('#k-'+p));
  PROVS.forEach(p=>{const sl=$('#ks-'+p),ip=$('#km-'+p);sl.onchange=()=>{const c=sl.value==='__custom';ip.style.display=c?'':'none';if(c)ip.focus()}});
  $('#k-show').onclick=e=>{const on=!tas[0].classList.contains('show');tas.forEach(x=>x.classList.toggle('show',on));$('#k-gskey').type=on?'text':'password';e.target.textContent=on?'Sembunyikan':'Lihat key'};
  const collect=()=>{const o={keys:{},models:{},gs:{}};
    for(const p of PROVS){const ks=parseKeys($('#k-'+p).value);
      if(ks.some(k=>k.length<10||/[^\x21-\x7e]/.test(k)))return {err:'Key '+PNAME[p]+' tidak valid (terlalu pendek atau ada karakter aneh).'};
      if(ks.length)o.keys[p]=ks;
      const sv=$('#ks-'+p).value,md=(sv==='__custom'?($('#km-'+p).value||''):sv).trim();if(sv==='__custom'&&!md)return {err:'Isi nama model '+PNAME[p]+' atau pilih dari daftar.'};if(md){if(!/^[\w.:\-\/]+$/.test(md))return {err:'Nama model '+PNAME[p]+' tidak valid.'};o.models[p]=md}}
    const gk=($('#k-gskey').value||'').trim(),gc=($('#k-gscx').value||'').trim();
    if(gk||gc){if(!gk||!gc)return {err:'Google Search butuh API key dan CX sekaligus.'};if(/\s/.test(gk+gc))return {err:'Key atau CX Google tidak boleh mengandung spasi.'};o.gs={key:gk,cx:gc}}
    return {o}};
  $('#ksave').onclick=()=>{const r=collect();if(r.err)return m(r.err,true);if(!lkSet(r.o))return m('Gagal menyimpan (penyimpanan browser penuh atau diblokir).',true);toast('API key disimpan');open('backend')};
  $('#kdel').onclick=()=>{if(!confirm('Hapus semua API key dari perangkat ini?'))return;try{localStorage.removeItem(LK)}catch(e){}toast('Semua API key dihapus');open('backend')};
  $('#ktest').onclick=async()=>{const r=collect();if(r.err)return m(r.err,true);const b=$('#ktest');b.disabled=true;const out=[];
    try{
      for(const p of PROVS){const ks=r.o.keys[p]||[];
        for(let i=0;i<ks.length;i++){m('Menguji '+PNAME[p]+' #'+(i+1)+'…');const c=new AbortController(),tm=setTimeout(()=>c.abort(),20000);
          try{await directCall[p](ks[i],r.o.models[p]||DEFM[p],'Balas satu kata saja.',[{role:'user',content:'Hai'}],c.signal);out.push('✅ '+PNAME[p]+' #'+(i+1)+' berfungsi')}
          catch(e){out.push('❌ '+PNAME[p]+' #'+(i+1)+': '+(e&&e.name==='AbortError'?'waktu habis':e.message))}
          finally{clearTimeout(tm)}}}
      if(r.o.gs.key){m('Menguji Google Search…');const c=new AbortController(),tm=setTimeout(()=>c.abort(),15000);
        try{const d=await searchDirect('test',c.signal,r.o.gs);out.push(d.error?'❌ '+d.message:'✅ Google Search berfungsi')}
        catch(e){out.push('❌ Google Search: '+(e&&e.name==='AbortError'?'waktu habis':'tidak bisa dihubungi'))}
        finally{clearTimeout(tm)}}
    }finally{b.disabled=false}
    m(out.length?out.join('\n'):'Belum ada key untuk diuji.',out.some(x=>x[0]==='❌'))};
}

/* ===== Pengaturan backend: alamat + token akses. API key penyedia AI hanya ada di server. ===== */
views.backend=()=>{const t=getToken(),L=lkGet();
 const kb=p=>{const n=(L.keys[p]||[]).length,cm=L.models[p]||'',cu=!!cm&&cm!==DEFM[p]&&!PRESM[p].includes(cm);return `<div class="lb" style="display:flex;justify-content:space-between;align-items:center"><span>${PNAME[p]}</span><span class="kst ${n?'ok':''}">${n?n+' key tersimpan':'Belum diisi'}</span></div><textarea class="inp kta" id="k-${p}" rows="2" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="Tempel key, satu per baris" aria-label="API key ${PNAME[p]}">${esc((L.keys[p]||[]).join('\n'))}</textarea><select class="inp" id="ks-${p}" style="width:100%;margin-top:6px" aria-label="Model ${PNAME[p]}"><option value="">Model: bawaan (${mlabel(DEFM[p])})</option>${PRESM[p].filter(x=>x!==DEFM[p]).map(x=>`<option value="${x}"${cm===x?' selected':''}>${mlabel(x)}</option>`).join('')}<option value="__custom"${cu?' selected':''}>Lainnya (ketik sendiri)…</option></select><input class="inp" id="km-${p}" style="width:100%;margin-top:6px;${cu?'':'display:none'}" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="Nama model, mis. ${DEFM[p]}" value="${cu?esc(cm):''}" aria-label="Nama model ${PNAME[p]}">`};
 return `<div class="fhd"><button class="ib" id="kback" aria-label="Kembali ke chat">←</button><h2>API key</h2></div><p>Key disimpan di perangkat ini dan dipakai langsung dari browser, jadi chat dan pencarian jalan tanpa backend. Isi satu atau beberapa key per penyedia (satu per baris): kalau satu key kena batas atau ditolak, LUMA otomatis mencoba key berikutnya.</p>${PROVS.map(kb).join('')}<p style="font-size:12px">Model bertanda gratis tersedia di paket gratis (ada batas per menit dan per hari). Batas Gemini dihitung per proyek Google dan Groq per organisasi, jadi beberapa key dari proyek atau akun yang sama tidak menambah kuota.</p><div class="lb" style="display:flex;justify-content:space-between;align-items:center"><span>Google Search (pencarian)</span><span class="kst ${L.gs.key&&L.gs.cx?'ok':''}">${L.gs.key&&L.gs.cx?'Tersimpan':'Belum diisi'}</span></div><input class="inp" id="k-gskey" type="password" style="width:100%" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="API key Google" value="${esc(L.gs.key||'')}" aria-label="API key Google Search"><input class="inp" id="k-gscx" style="width:100%;margin-top:6px" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="CX (ID mesin pencarian)" value="${esc(L.gs.cx||'')}" aria-label="CX Google Search"><div class="fbar" style="margin-top:14px"><button class="fl on" id="ksave">Simpan key</button><button class="fl" id="ktest">Tes key</button><button class="fl" id="k-show" type="button">Lihat key</button><button class="fl" id="kdel">Hapus semua</button></div><p id="kkmsg" role="status" style="margin:4px 0 0;white-space:pre-line"></p><p style="font-size:12px">Key tersimpan di browser tanpa enkripsi. Pakai hanya di perangkat pribadi dan jangan dibagikan.</p><div class="lb" style="margin-top:22px">Backend (opsional)</div><p>Kalau lebih suka key tetap di komputer (bukan di HP), pakai backend. Kalau key sudah diisi di atas, backend hanya jadi cadangan.</p><div class="lb">Alamat backend</div><input class="inp" id="b-url" style="width:100%" inputmode="url" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" aria-label="Alamat backend" value="${esc(searchBase())}"><div class="lb" style="display:flex;justify-content:space-between;align-items:center"><span>Token akses</span><span class="kst ${t?'ok':''}">${t?'Tersimpan (…'+esc(t.slice(-4))+')':'Belum diisi'}</span></div><div class="kin"><input class="inp" id="b-tok" type="password" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="${t?'Kosongkan jika tidak diubah':'Tempel token dari terminal backend'}" aria-label="Token akses"><button class="fl" type="button" id="b-show">Lihat</button>${t?'<button class="fl" type="button" id="b-del">Hapus</button>':''}</div><p>Token dicetak di terminal saat backend dijalankan, dan tersimpan di backend/.access_token.</p><div class="fbar" style="margin-top:14px"><button class="fl on" id="bsave">Simpan</button><button class="fl" id="btest">Tes koneksi</button></div><p id="kmsg" role="status" style="margin:4px 0 0;white-space:pre-line"></p>`};
function initBackend(){
  initKeys();
  const msg=(t,bad)=>{const m=$('#kmsg');if(m){m.textContent=t;m.style.color=bad?'#e5484d':'var(--mute)'}};
  $('#kback').onclick=()=>open('chat');
  $('#b-show').onclick=e=>{const i=$('#b-tok'),h=i.type==='password';i.type=h?'text':'password';e.target.textContent=h?'Sembunyi':'Lihat'};
  const d=$('#b-del');if(d)d.onclick=()=>{setToken('');toast('Token dihapus');open('backend')};
  const read=()=>{const u=($('#b-url').value||'').trim().replace(/\/+$/,''),t=($('#b-tok').value||'').trim();
    if(u&&!/^https?:\/\/[^\s]+$/i.test(u))return {err:'Alamat harus diawali http:// atau https://'};
    if(t&&(/\s/.test(t)||t.length<16))return {err:'Token tidak valid (minimal 16 karakter, tanpa spasi).'};
    return {u,t}};
  $('#bsave').onclick=()=>{const r=read();if(r.err)return msg(r.err,true);
    try{if(r.u)localStorage.setItem(SKEY,r.u);else localStorage.removeItem(SKEY)}catch(e){return msg('Gagal menyimpan (penyimpanan browser penuh atau diblokir).',true)}
    if(r.t&&!setToken(r.t))return msg('Gagal menyimpan token.',true);
    toast('Pengaturan backend disimpan');open('backend')};
  $('#btest').onclick=async()=>{const r=read();if(r.err)return msg(r.err,true);
    const base=r.u||searchBase(),tok=r.t||getToken(),b=$('#btest');
    if(mixedBlocked(base))return msg('❌ Halaman ini HTTPS tapi backend HTTP, jadi diblokir browser. Pakai backend HTTPS.',true);
    b.disabled=true;msg('Menguji…');const c=new AbortController(),tm=setTimeout(()=>c.abort(),8000);
    try{
      let h;try{h=await fetch(base+'/health',{signal:c.signal})}catch(e){return msg('❌ Backend tidak terjangkau di '+base+'. Pastikan server jalan dan alamatnya benar (bukan localhost jika kamu di HP).',true)}
      if(!h.ok)return msg('❌ Alamat itu menjawab error '+h.status+', bukan backend LUMA.',true);
      const st=await fetch(base+'/api/status',{signal:c.signal,headers:tok?{Authorization:'Bearer '+tok}:{}});
      const j=await st.json().catch(()=>({}));
      if(st.status===401)return msg('✅ Backend terjangkau\n❌ Token akses kosong atau salah.',true);
      if(st.status===403)return msg('✅ Backend terjangkau\n❌ Origin aplikasi ini belum diizinkan. Tambahkan ke ALLOW_ORIGINS di config.env.',true);
      if(!st.ok)return msg('✅ Backend terjangkau\n❌ Error '+st.status+'.',true);
      const on=PROVS.filter(p=>j.chat&&j.chat[p]).map(p=>PNAME[p]);
      msg('✅ Backend terjangkau, token benar\n'+(on.length?'✅ Chat AI: '+on.join(', '):'⚠️ Belum ada API key AI di backend/config.env')+'\n'+(j.search?'✅ Pencarian web aktif':'ℹ️ Pencarian web belum diatur'),!on.length)
    }catch(e){msg(e&&e.name==='AbortError'?'❌ Waktu habis saat menghubungi backend.':'❌ Gagal menguji koneksi.',true)}
    finally{clearTimeout(tm);b.disabled=false}};
}
function initChat(){const cl=$('#cl'),inp=$('#ci'),btn=$('#cs');
const heroSrc=()=>$('#av').src;
const draw=()=>{cl.innerHTML=chatLog.map((m,i)=>{const me=m[0]==='u',er=m[0]==='e';
 const body=er?`${esc(m[1])}<br><button class="fl" data-retry="${i}" style="margin-top:8px">Coba lagi</button>`:m[1]?(me?(ACC.cmt.badge?esc(ACC.cmt.badge)+' ':'')+esc(m[1]):chatRich(m[1])):'<span class="dots"><i></i><i></i><i></i></span>';
 return `<div class="crow ${me?'me':''}">${me?'':'<span class="avatar cav"><img alt=""></span>'}<div class="cb"><div class="msg ${me?'me':''} ${er?'err':''}">${body}</div>${m[2]?`<div class="ts">${chatTime(m[2])}</div>`:''}</div></div>`}).join('');
 const hs=heroSrc();cl.querySelectorAll('.cav img').forEach(x=>x.src=hs);cl.scrollTop=cl.scrollHeight};
let ready=localProvs().length>0,bmsg='API key belum diisi';
const sync=()=>{btn.innerHTML=busy?IC_STOP:IC_SEND;btn.setAttribute('aria-label',busy?'Hentikan':'Kirim');
 const bad=chatLog.length&&chatLog[chatLog.length-1][0]==='e',s=$('#cst');
 if(s)s.innerHTML=`<i class="${bad||(!ready&&!busy)?'bad':busy?'busy':''}"></i>${bad?'Tidak terhubung':busy?'Sedang mengetik…':!ready?esc(bmsg):lastProv?'Online · '+esc(lastProv):'Online'}`;
 const q=$('.qk');if(q)q.hidden=chatLog.some(m=>m[0]==='u')};
const av0=$('#cav0 img');if(av0)av0.src=heroSrc();
const autosize=()=>{inp.style.height='auto';inp.style.height=Math.min(inp.scrollHeight,110)+'px'};
chatUI={cl,draw,sync};draw();sync();
(async()=>{if(!ready){const base=searchBase();if(!mixedBlocked(base)){try{const c=new AbortController(),tm=setTimeout(()=>c.abort(),2500);const r=await fetch(base+'/api/status',{signal:c.signal,headers:authH()});clearTimeout(tm);const d=await r.json().catch(()=>({}));if(r.status===401)bmsg=getToken()?'Token akses salah':'Token akses belum diisi';else if(r.ok){ready=!!(d.chat&&(d.chat.gemini||d.chat.groq||d.chat.openai));if(!ready)bmsg='Backend belum punya API key AI'}else bmsg='Backend error ('+r.status+')'}catch(e){bmsg='Backend tidak terjangkau'}}else bmsg='Diblokir: HTTPS ke server HTTP'
 if(!ready){const sm=await getSM();if(sm&&!aiOff)ready=true}}
 if($('#cl')===cl)sync()})();
$('#ckey').onclick=()=>open('backend');
const vob=$('#cvo'),paintVo=()=>{const on=!!jget(LSK,VOICE_D).on;vob.innerHTML=on?IC_VON:IC_VOFF;vob.classList.toggle('on',on);vob.setAttribute('aria-pressed',on?'true':'false');const t=on?'Matikan suara balasan':'Hidupkan suara balasan';vob.setAttribute('aria-label',t);vob.title=t};
window.__paintVo=()=>{if($('#cvo')===vob)paintVo()};paintVo();
vob.onclick=()=>{const v=jget(LSK,VOICE_D);v.on=!v.on;jset(LSK,v);paintVo();if(v.on){toast('Suara balasan hidup');if(!lzSay('Suara balasan aktif',true))toast('Suara tidak tersedia di browser ini')}else{lzStop();toast('Suara balasan mati')}};
const CH_KEY='luma-chath',chEl=$('.chat'),chHd=$('.chat-hd'),avB=$('#cav0');
const chGet=()=>{try{return localStorage.getItem(CH_KEY)==='full'?'full':'half'}catch(e){return'half'}};
const chApply=m=>{chEl.classList.toggle('full',m==='full');pop.querySelectorAll('button[data-m]').forEach(x=>x.classList.toggle('on',x.dataset.m===m))};
/* pilihan tinggi panel: dibuka lewat avatar */
const pop=document.createElement('div');pop.className='cpop';pop.hidden=true;
pop.innerHTML='<b>Tinggi panel</b><div class="cpr"><button data-m="half">Setengah</button><button data-m="full">Penuh</button></div>';
chHd.appendChild(pop);
const keyEl=$('#ckey');keyEl.insertAdjacentHTML('beforeend','<span>Atur API key</span>');pop.appendChild(keyEl);keyEl.addEventListener('click',()=>{pop.hidden=true});
const closePop=()=>{pop.hidden=true};
[["c-pers","Personalisasi","<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><circle cx=\"12\" cy=\"8\" r=\"4\"/><path d=\"M4 21a8 8 0 0 1 16 0\"/></svg>"],["c-mem","Memori","<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M4 5a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v14l-4-3H6a2 2 0 0 1-2-2z\"/><path d=\"M8 8h8M8 12h5\"/></svg>"],["c-suara","Suara","<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M11 5L6 9H3v6h3l5 4z\"/><path d=\"M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13\"/></svg>"],["c-link","Hubungan AI ke Model","<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1\"/><path d=\"M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1\"/></svg>"]].forEach(([k,l,svg])=>{const b=document.createElement('button');b.type='button';b.className='cic';b.innerHTML=svg+'<span>'+l+'</span>';b.onclick=()=>{closePop();open(k)};pop.insertBefore(b,keyEl)});
avB.setAttribute('role','button');avB.tabIndex=0;avB.setAttribute('aria-label','Atur tinggi panel chat');avB.setAttribute('aria-haspopup','true');
avB.onclick=e=>{e.stopPropagation();pop.hidden=!pop.hidden};
avB.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();avB.click()}};
pop.onclick=e=>{const b=e.target.closest('button[data-m]');if(b){try{localStorage.setItem(CH_KEY,b.dataset.m)}catch(x){}chApply(b.dataset.m);closePop();cl.scrollTop=cl.scrollHeight}};
chApply(chGet());
const gb=$('#sheet .grab');if(gb)gb.onclick=()=>{if(!document.contains(chEl))return;const m=chEl.classList.contains('full')?'half':'full';try{localStorage.setItem(CH_KEY,m)}catch(x){}chApply(m);cl.scrollTop=cl.scrollHeight};
chEl.addEventListener('click',e=>{if(!e.target.closest('.cpop')&&!e.target.closest('#cav0'))closePop()});
const sel=$('#cprov');sel.value=chatProv();sel.onchange=()=>{try{localStorage.setItem(CPKEY,sel.value)}catch(e){}};
/* perintah lokal: memutar musik & Mode fokus lewat chat (tanpa memanggil AI) */
const APPV='8.4';
const cmdNorm=s=>s.toLowerCase().replace(/[^a-z0-9\u00c0-\u024f\s]/g,' ').replace(/\s+/g,' ').trim();
const CMD_FILL=/\b(dong|ya|yaa|yuk|tolong|bisa|coba|kamu|luma|nya|saja|aja|sekarang|please|sih|deh|kak|donk|lah)\b/g;
function localCmd(raw){
 const s=cmdNorm(raw);if(!s||s.length>90)return null;
 if(/^(apa|apakah|bagaimana|gimana|kenapa|mengapa|siapa|kapan|dimana|di mana|berapa)\b/.test(s))return null;
 const w=s.replace(CMD_FILL,' ').replace(/\b(mau|pengen|pingin|ingin|minta|boleh|dengan|untuk|buat|sambil|dan|lalu|terus|sama|di|ke|yang|dari|jadi|nih|tuh|dulu|aku|saya|gue|gw|please|plis|pls)\b/g,' ').replace(/\s+/g,' ').trim();
 const musik=/\b(musik|musiknya|music|lagu|lagunya|lagunya|playlist|mp3|bgm|soundtrack|tembang|nada|radio|audio)\b/.test(w);
 const fokus=/\b(mode )?(fokus|pokus|focus|fokos|konsentrasi|pomodoro)(nya)?\b/.test(w);
 /* kata kerja bersama */
 const V_ON='mulai|mulailah|aktifkan|aktifin|aktif|nyalakan|nyalain|nyalakn|nyala|hidupkan|hidupin|masuk|masuki|buka|bukain|bukakan|jalankan|jalanin|start|on|pasang|pasangin|ayo|gas|setel|setelkan|setelin|atur|pakai|pakek|pake|jalan|launch|enable|aktivasi';
 const V_OFF='keluar|matikan|matiin|mati|akhiri|akhirin|tutup|tutupin|tutupkan|selesai|selesaikan|sudahi|hentikan|hentiin|berhenti|stop|batal|batalkan|off|nonaktifkan|cancel|exit|close|disable|udahan|udah';
 const V_PLAY='pasang|pasangin|putar|putarkan|putarin|putarkn|puter|puterin|mainkan|mainin|main|setel|setelkan|setelin|play|lanjutkan|lanjut|resume|nyalakan|nyalain|nyala|hidupkan|hidupin|aktifkan|aktifin|bunyikan|bunyiin|dengarkan|dengerin|denger|dengar|dengerkan|start|on|gas|ayo|mulai|mulailah|lantunkan|iringi|jalankan|buka|bukain';
 const has=(re)=>new RegExp('\\b('+re+')\\b').test(w);
 const isPlayV=has(V_PLAY);
 /* Mode fokus */
 if(fokus){
  const on=document.body.classList.contains('focus-on');
  if(has('jeda|pause|tahan')&&!has(V_OFF)){
   if(!on)return 'Mode fokus belum aktif.';
   if(fxRun){$('#fxgo').click();return 'Timer fokus kujeda. Bilang \"lanjut fokus\" kalau mau lanjut.'}
   return 'Timer fokusnya memang sedang berhenti.';
  }
  if(has('lanjut|lanjutkan|resume')&&on&&!fxRun&&fxLeft>0){$('#fxgo').click();return 'Lanjut fokus, sisa '+String(Math.floor(fxLeft/60)).padStart(2,'0')+':'+String(fxLeft%60).padStart(2,'0')+'. Semangat! 💪'}
  if(has(V_OFF)){
   if(!on)return 'Mode fokus memang belum aktif.';
   exitFocus();return 'Oke, mode fokus kututup. Kerja bagus!';
  }
  if(has(V_ON+'|lanjut|lanjutkan|saatnya|waktunya|timer|hitung mundur')||w.split(' ').length<=5||/\d+ ?(menit|mnt|min|jam)/.test(w)||/setengah jam/.test(w)){
   let mins=0;const mm=w.match(/(\d{1,3}) ?(menit|mnt|min|m)\b/),mj=w.match(/(\d{1,2}) ?jam\b/);
   if(mm)mins=+mm[1];else if(mj)mins=+mj[1]*60;else if(/setengah jam/.test(w))mins=30;else if(/sejam|satu jam/.test(w))mins=60;
   mins=mins?Math.min(180,Math.max(1,mins)):0;
   if(!on){close();enterFocus()}
   if(mins){fxTotal=mins*60;fxLeft=fxTotal;clearInterval(fxTimer);fxTimer=null;fxRun=false;[...$('#fxpre').children].forEach(x=>x.classList.toggle('on',+x.dataset.m===mins));paintFocus()}
   const go=has('mulai|mulailah|jalankan|jalanin|start|ayo|gas|jalan|timer|hitung mundur')||mins>0;
   if(go&&!fxRun)$('#fxgo').click();
   let extra='';
   if(musik&&tracks.length&&!playing){try{play();paintFocus();extra=' Musik ikut kuputar 🎵'}catch(e){}}
   return (go?'Mode fokus '+Math.round(fxTotal/60)+' menit dimulai. Semangat! 💪':'Mode fokus kubuka. Pilih durasi lalu tekan Mulai, atau bilang \"mulai fokus 25 menit\".')+extra;
  }
  return null;
 }
 if(has('cek versi|versi luma|versi aplikasi|versi app|versi web|luma versi|version')&&!musik&&!fokus)return 'Luma versi '+APPV+' 🌟 Kalau angkanya bukan '+APPV+', halaman masih memuat berkas lama. Tutup aplikasi sepenuhnya lalu buka lagi.';
 if(has('model')&&!musik&&!fokus&&window.__lumaModel){
  if(has('sembunyikan|sembunyiin|umpetin|umpetkan|hilangkan|hilangin|tutup|matikan|matiin|nonaktifkan|hide|off'))return window.__lumaModel.hidden?'Modelnya memang sudah disembunyikan.':(window.__lumaModel.set(true),'Oke, model kusembunyikan. Bilang \"tampilkan model\" kalau mau muncul lagi.');
  if(has('tampilkan|tampilin|munculkan|munculin|perlihatkan|show|nyalakan|nyalain|aktifkan|on'))return !window.__lumaModel.hidden?'Modelnya sudah tampil.':(window.__lumaModel.set(false),'Siap, modelnya kutampilkan lagi ✨');
 }
 /* Musik: tambah lagu dari ponsel */
 if(musik&&has('tambah|tambahkan|tambahin|masukkan|masukin|upload|unggah|impor|import|add|unggahkan')&&!has('playlist favorit|favorit')){
  try{$('#pf').click()}catch(e){}
  return 'Kubuka pemilih berkas. Pilih satu atau beberapa lagu dari ponselmu, nanti langsung kuputar 🎵';
 }
 /* Musik: acak & ulangi */
 if(!/\bmulai ulang\b/.test(w)&&(musik||isPlayV||w.split(' ').length<=3)){
  const NEG='tidak|nggak|ngga|gak|ga|enggak|engga|jangan|tanpa|matikan|matiin|mati|off|nonaktifkan|batal|batalkan|hentikan|stop|cukup|berhenti|normal|urut|berurutan|biasa';
  const out=[];let shufOn=false;
  s.split(/\b(?:tapi|tetapi|dan|serta|lalu|terus|sambil|kemudian)\b/).map(x=>x.trim()).filter(Boolean).forEach(c=>{
   const fneg=kw=>new RegExp('\\b('+NEG+')\\b(\\s+\\w+){0,2}\\s+('+kw+')\\b').test(c)||new RegExp('\\b('+kw+')\\b\\s+(\\w+\\s+)?(off|dimatikan|dinonaktifkan|dibatalkan|mati|nonaktif)\\b').test(c);
   const KS='acak|diacak|acakin|acakkan|shuffle|random|randomin',KR='ulang|ulangi|ulangin|diulang|berulang|repeat|loop|looping|mengulang';
   if(new RegExp('\\b('+KS+')\\b').test(c)){
    const neg=fneg(KS);shuf=!neg;shufOn=shuf;syncSh();
    out.push(shuf?'Putar acak aktif 🔀':'Putar acak dimatikan, lagu diputar berurutan.');
   }
   if(new RegExp('\\b('+KR+')\\b').test(c)){
    if(fneg(KR))rpt=0;
    else if(/\b(daftar|semua|seluruh|playlist|all|list)\b/.test(c))rpt=1;
    else if(/\b(satu|1|ini|itu|single|one|sendiri)\b/.test(c)||/\blagu\b/.test(c))rpt=2;
    else rpt=1;
    paintRp();
    out.push(['Ulangi dimatikan.','Ulangi daftar lagu aktif 🔁','Ulangi satu lagu aktif 🔂'][rpt]);
   }
  });
  if(out.length){
   if(isPlayV&&!/\b(matikan|matiin|stop|hentikan|berhenti|jeda|pause|batal)\b/.test(w)&&!playing&&tracks.length){if(shufOn)next(1,false);else play();out.push('Memutar \"'+T().title+'\" 🎵')}
   return out.join(' ');
  }
 }
 /* Musik */
 const isNext=has('berikutnya|selanjutnya|sesudahnya|next|nextin|skip|skipin|lewati|lewatin|lewat|lompati|lompat|loncat|loncati|ganti|gantiin|lagu lain|lagu baru|musik lain|lagu lagi|maju|pindah');
 const isPrev=has('sebelumnya|sebelum|previous|prev|back|mundur|lagu tadi|lagu lalu|lagu kemarin|balik|kembali|ulang lagu tadi');
 const isStop=has('jeda|pause|berhenti|stop|matikan|matiin|mati|hentikan|hentiin|diam|diamkan|off|senyap|tahan|udahan|cukup');
 const isPlay=has(V_PLAY);
 const lone=/^(play|pause|stop|next|skip|skipin|putar|putarkan|puter|mainkan|jeda|berhenti|lanjut|lanjutkan|prev|previous|resume|gas|ganti|lewati|lewatin|lompat|loncat|sebelumnya|selanjutnya|berikutnya|balik|back)$/.test(w);
 if(!(musik||lone)){
  if(!isPlay||!tracks.length)return null;
  const q0=w.replace(new RegExp('\\b('+V_PLAY+'|judul|berjudul|dong|aja|saja)\\b','g'),' ').replace(/\s+/g,' ').trim();
  const j=q0.length>1?tracks.findIndex(k=>{const n=cmdNorm(k.title);return n.includes(q0)||q0.includes(n)}):-1;
  if(j<0)return null;
  load(j,true);return 'Memutar "'+T().title+'" 🎵';
 }
 if(!tracks.length)return 'Belum ada lagu. Tambahkan dulu lewat pemutar musik (ikon musik di kanan atas), nanti kuputarkan.';
 if(isNext||isPrev){if(isPrev&&!isNext&&shuf){load((cur-1+tracks.length)%tracks.length,true)}else next(isNext?1:-1,false);return (isNext?'Lagu berikutnya: ':'Kembali ke: ')+T().title+' 🎵'}
 if(isStop&&!isPlay){if(!playing)return 'Musiknya memang sedang tidak diputar.';pause();return 'Oke, musiknya kujeda.'}
 if(isPlay||lone||w.split(" ").length<=2){
  const q=w.replace(new RegExp('\\b('+V_PLAY+'|musik|musiknya|music|lagu|lagunya|playlist|mp3|bgm|soundtrack|tembang|nada|radio|audio|judul|berjudul|dong|aja|saja)\\b','g'),' ').replace(/\s+/g,' ').trim();
  if(q.length>1){
   const i=tracks.findIndex(k=>{const n=cmdNorm(k.title);return n.includes(q)||q.includes(n)});
   if(i<0)return 'Aku tidak menemukan lagu \"'+q+'\". Yang ada: '+tracks.slice(0,3).map(k=>k.title).join(', ')+(tracks.length>3?', …':'')+'.';
   load(i,true);return 'Memutar \"'+T().title+'\" 🎵';
  }
  if(playing)return 'Musiknya sudah diputar: '+T().title+' 🎵';
  play();return 'Siap, kuputar \"'+T().title+'\" 🎵';
 }
 return null;
}
function send(){if(busy){ctl&&ctl.abort();return}const text=inp.value.trim();if(!text)return;
 for(let i=chatLog.length-1;i>=0;i--)if(chatLog[i][0]==='e')chatLog.splice(i,1);
 inp.value='';autosize();chatLog.push(['u',text,Date.now()]);let lc=null;try{lc=localCmd(text)}catch(e){lc=null}if(lc){chatLog.push(['a',lc,Date.now()]);try{window.__lumaModel&&window.__lumaModel.speak&&window.__lumaModel.speak(lc)}catch(e){};aiTurns.push({role:'user',content:text},{role:'assistant',content:lc});draw();sync();return}runChat(text)}
cl.onclick=e=>{const b=e.target.closest('[data-retry]');if(!b||busy)return;const i=+b.dataset.retry,m=chatLog[i];if(!m)return;chatLog.splice(i,1);runChat(m[3])};
$('#cclr').onclick=()=>{lzStop();if(busy&&ctl)ctl.abort();chatLog.length=0;chatLog.push(['a','Halo! Aku '+nice(PF.name)+' ✌️',Date.now()],['a','Ada yang bisa aku bantu hari ini?',Date.now()]);aiTurns.length=0;lastProv='';draw();sync();toast('Percakapan dihapus')};
document.querySelectorAll('.qk button').forEach(b=>b.onclick=()=>{if(busy)return;inp.value=b.textContent;send()});
btn.onclick=send;inp.oninput=autosize;
inp.onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey&&!matchMedia('(pointer:coarse)').matches){e.preventDefault();send()}}}
// simpan pengaturan
function save(){try{localStorage.setItem('luma-prefs',JSON.stringify({v:2,mode,theme:document.documentElement.dataset.theme||'dark'}))}catch(e){}}
try{const P=JSON.parse(localStorage.getItem('luma-prefs')||'{}');if(P.theme)document.documentElement.dataset.theme=P.theme;if(P.v===2&&typeof P.mode==='number'){mode=P.mode;setHue(mode)}}catch(e){}
// pemutar musik
const mf=m=>440*Math.pow(2,(m-69)/12),fmt=s=>{if(!isFinite(s)||s<=0)return'--:--';s=Math.round(s);return Math.floor(s/60)+':'+String(s%60).padStart(2,'0')},hashH=s=>{let x=0;for(const c of s)x=(x*31+c.charCodeAt(0))%360;return x};
const tracks=[];
// lagu bawaan (musik awal): ada di folder media/music/, selalu muncul paling atas di daftar & tidak bisa dihapus
const BUILTIN=[['morning_on_the_green_hill','Morning on the Green Hill',165],['sabar_menanti_pagi','Sabar Menanti Pagi',160],['secangkir_kopi_dingin','Secangkir Kopi Dingin',181],['rehat_sejenak','Rehat Sejenak',181]];
BUILTIN.forEach(([f,title,dur])=>tracks.push({id:'b_'+f,title,artist:'LUMA',type:'file',src:'media/music/'+f+'.mp3',dur,h:hashH(title),builtin:true}));
const EMPTY={id:'none',title:'Belum ada lagu',artist:'Tambah lagu dari ponsel',type:'none',dur:0,h:262};
const MUSKEY='luma-music';
// penyimpanan permanen lagu & video (IndexedDB) agar tidak hilang saat reload
const MDB=(()=>{let db;const open=()=>db||(db=new Promise((res,rej)=>{try{const r=indexedDB.open('luma-media',1);r.onupgradeneeded=()=>r.result.createObjectStore('m',{keyPath:'id'});r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)}catch(e){rej(e)}}));
const tx=(mode,fn)=>open().then(d=>new Promise((res,rej)=>{const t=d.transaction('m',mode),q=fn(t.objectStore('m'));t.oncomplete=()=>res(q&&q.result);t.onerror=t.onabort=()=>rej(t.error)}));
return{put:r=>tx('readwrite',s=>s.put(r)),del:id=>tx('readwrite',s=>s.delete(id)),all:()=>tx('readonly',s=>s.getAll())}})();
let askedPersist=false;
const keepMedia=r=>{if(!askedPersist){askedPersist=true;try{navigator.storage&&navigator.storage.persist&&navigator.storage.persist()}catch(e){}}return MDB.put(Object.assign({ts:Date.now()},r)).catch(()=>toast('Diputar, tapi tidak bisa disimpan permanen (penyimpanan penuh atau tidak didukung)'))};
const dropMedia=id=>{if(id)MDB.del(id).catch(()=>{})};
const getMus=()=>{try{return JSON.parse(localStorage.getItem(MUSKEY)||'{}')||{}}catch(e){return {}}};
const saveMus=o=>{lsSet(MUSKEY,JSON.stringify(o))};
const saveMusLast=()=>{const m=getMus();m.last=T()?T().id:0;m.vol=vol;saveMus(m)};
const toggleFav=id=>{const m=getMus();m.fav=m.fav||[];const i=m.fav.indexOf(id);if(i>=0)m.fav.splice(i,1);else m.fav.push(id);saveMus(m);toast(i>=0?'Dihapus dari favorit':'Ditambah ke favorit')};

let cur=0,playing=false,shuf=false,rpt=0,vol=.7,drag=false,ctx,master,dly,tid,nextT=0,step=0,genT=0,an,fxS,fxId='',fxMS;
const au=new Audio();au.preload='metadata';au.volume=vol;
const IC={play:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>',pause:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M6 5h4v14H6zM14 5h4v14h-4z"/></svg>',rpt:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 2l4 4-4 4M3 11V9a3 3 0 0 1 3-3h15M7 22l-4-4 4-4M21 13v2a3 3 0 0 1-3 3H3"/></svg>'};
const T=()=>tracks[cur]||EMPTY;
function ensureCtx(){if(ctx)return;ctx=new(window.AudioContext||window.webkitAudioContext)();master=ctx.createGain();master.gain.value=0;const lp=ctx.createBiquadFilter();lp.type='lowpass';lp.frequency.value=2200;dly=ctx.createDelay();dly.delayTime.value=.375;const fb=ctx.createGain();fb.gain.value=.35;dly.connect(fb);fb.connect(dly);dly.connect(lp);master.connect(lp);lp.connect(ctx.destination);an=ctx.createAnalyser();an.fftSize=512;an.smoothingTimeConstant=.5;lp.connect(an)}
function tone(f,t,d,ty,v,echo){const o=ctx.createOscillator(),g=ctx.createGain();o.type=ty;o.frequency.value=f;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(v,t+Math.min(1,d*.25));g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(master);if(echo)g.connect(dly);o.start(t);o.stop(t+d+.05)}
function sched(){const P=T().pre;while(nextT<ctx.currentTime+.6){if(step%8===0)P.c[Math.floor(step/8)%P.c.length].forEach(m=>tone(mf(m),nextT,P.s*8+.6,P.pad,.05,false));if(Math.random()<P.p)tone(mf(P.sc[Math.floor(Math.random()*P.sc.length)]),nextT,1.8,'sine',.07,true);step++;nextT+=P.s}}
const pos=()=>T().type==='file'?au.currentTime:genT,dur=()=>{const k=T();return k.type==='file'?(isFinite(au.duration)?au.duration:k.dur):k.dur};
function ui(){const d=dur(),c=pos(),pc=d>0?Math.min(100,c/d*100):0;if(!drag){$('#seek').value=pc*10;$('#seek').style.setProperty('--p',pc+'%')}$('#tc').textContent=fmt(c);$('#td').textContent=fmt(d);$('#itc').textContent=fmt(c);$('#itd').textContent=fmt(d);$('#ibf').style.width=pc+'%';$('#fmtc').textContent=fmt(c);$('#fmtd').textContent=fmt(d);$('#fmbf').style.width=pc+'%';$('#mb').style.width=pc+'%'}
function renderList(){const favs=getMus().fav||[];$('#plist').innerHTML=!tracks.length?'<p style="color:var(--mute);font-size:14px;margin:6px 0 10px">Belum ada lagu. Tambahkan dari ponsel.</p>':tracks.map((k,i)=>`<div class="tr ${i===cur?'cur':''}" data-i="${i}"><span class="n">${i===cur&&playing?'<span class="eq"><i></i><i></i><i></i></span>':i+1}</span><div class="tt"><b>${esc(k.title)}</b><small>${esc(k.artist)}</small></div><button type="button" class="fav ${favs.includes(k.id)?'on':''}" data-fav="${i}" aria-label="Favorit">★</button><span class="d">${fmt(k.dur)}</span>${k.type==='file'&&!k.builtin?'<button class="x" aria-label="Hapus lagu">✕</button>':''}</div>`).join('')}
function meta(){const k=T();document.documentElement.style.setProperty('--th',k.h);$('#pt').textContent=k.title;$('#par').textContent=k.artist;$('#mt').textContent=$('#imt').textContent=$('#fmt').textContent=k.title;$('#ma').textContent=$('#ima').textContent=$('#fma').textContent=k.artist;try{navigator.mediaSession.metadata=new MediaMetadata({title:k.title,artist:k.artist})}catch(e){}renderList();ui()}
function paint(){$('#pp').innerHTML=$('#mp').innerHTML=$('#ipp').innerHTML=$('#fmpp').innerHTML=playing?IC.pause:IC.play;$('#mus').classList.toggle('on',playing);$('.cover').classList.toggle('go',playing);renderList();try{fxSync()}catch(e){}}
function stopEng(){au.pause();clearInterval(tid);if(master){master.gain.cancelScheduledValues(ctx.currentTime);master.gain.setTargetAtTime(0,ctx.currentTime,.08)}}
function play(){const k=T();if(k.type==='none'){playing=false;paint();return}playing=true;started=true;syncMini();$('#vp').pause();if(k.type==='file'){try{ensureCtx();ctx.resume&&ctx.resume()}catch(e){}au.play().catch(()=>{toast('File ini tidak bisa diputar');pause()})}else{ensureCtx();ctx.resume();master.gain.cancelScheduledValues(ctx.currentTime);master.gain.setTargetAtTime(.6*vol,ctx.currentTime,.3);nextT=ctx.currentTime+.1;clearInterval(tid);tid=setInterval(()=>{sched();genT+=.2;if(genT>=k.dur)onEnd();ui()},200)}paint()}
function pause(){playing=false;stopEng();paint()}
function load(i,go){stopEng();cur=i;genT=0;step=0;if(T().type==='file')au.src=T().src;meta();saveMusLast();if(go)play();else{playing=false;paint()}}
function next(dir,auto){const n=tracks.length;if(!n)return;let i;if(shuf&&n>1){do{i=Math.floor(Math.random()*n)}while(i===cur)}else{i=cur+dir;if(auto&&rpt===0&&i>=n){load(0,false);return}i=(i+n)%n}load(i,true)}
function onEnd(){if(rpt===2){genT=0;if(T().type==='file'){au.currentTime=0;au.play()}return}next(1,true)}
function seekTo(s){if(T().type==='file')au.currentTime=s;else genT=s;ui()}
const toggle=()=>{if(!tracks.length){toast('Belum ada lagu. Tambahkan dulu dari ponsel.');return}playing?pause():play()};
au.ontimeupdate=ui;au.onended=onEnd;au.onloadedmetadata=()=>{T().dur=au.duration;renderList();ui()};
const pl=$('#pl');
function openPlayer(){pl.inert=false;pl.classList.add('on');pl.setAttribute('aria-hidden','false')}
function closePlayer(){pl.classList.remove('on');pl.setAttribute('aria-hidden','true');pl.inert=true}
$('#mus').onclick=openPlayer;$('#pc').onclick=closePlayer;$('#mini').onclick=e=>e.target.closest('#mp')?toggle():openPlayer();
$('#pp').onclick=toggle;$('#nx').onclick=()=>next(1,false);$('#pv').onclick=()=>pos()>3?seekTo(0):next(-1,false);
function syncSh(){document.querySelectorAll('#sh,.sh2').forEach(b=>b.classList.toggle('on',!!shuf))}
$('#sh').onclick=e=>{shuf=!shuf;syncSh();toast(shuf?'Acak aktif':'Acak mati')};
$('#ish').onclick=$('#fmsh').onclick=()=>$('#sh').click();$('#irp').onclick=$('#fmrp').onclick=()=>$('#rp').click();
function paintRp(){document.querySelectorAll('#rp,.rp2').forEach(b=>{b.innerHTML=IC.rpt+(rpt===2?'<em>1</em>':'');b.classList.toggle('on',rpt>0)});syncSh()}
$('#rp').onclick=()=>{rpt=(rpt+1)%3;paintRp();toast(['Ulangi mati','Ulangi daftar','Ulangi satu lagu'][rpt])};
const sk=$('#seek');sk.oninput=e=>{drag=true;const q=e.target.value/10;e.target.style.setProperty('--p',q+'%');$('#tc').textContent=fmt(dur()*q/100)};sk.onchange=e=>{seekTo(dur()*e.target.value/1000);drag=false};
$('#vol').oninput=e=>{vol=e.target.value/100;au.volume=vol;if(master&&playing)master.gain.setTargetAtTime(.6*vol,ctx.currentTime,.05);e.target.style.setProperty('--p',e.target.value+'%')};
$('#plist').onclick=e=>{const r=e.target.closest('.tr');if(!r)return;const i=+r.dataset.i;if(e.target.closest('.fav')){toggleFav(tracks[i].id);renderList();return}if(e.target.closest('.x')){const k=tracks[i],was=playing;URL.revokeObjectURL(k.src);dropMedia(k.id);{const mm=getMus();mm.fav=(mm.fav||[]).filter(x=>x!==k.id);saveMus(mm)}tracks.splice(i,1);if(i<cur){cur--;renderList()}else if(i===cur){load(Math.min(cur,tracks.length-1),was)}else renderList();return}i===cur?toggle():load(i,true)};
$('#addb').onclick=$('#pa').onclick=()=>$('#pf').click();
const AUDX=/\.(mp3|m4a|aac|ogg|oga|opus|wav|flac|amr|wma|3gp|mka|weba|mp4|webm)$/i;
async function readId3(f){try{const buf=await f.slice(0,262144).arrayBuffer(),u=new Uint8Array(buf),d=new DataView(buf);if(u[0]!==0x49||u[1]!==0x44||u[2]!==0x33)return{};const ver=u[3],sz=((u[6]&127)<<21)|((u[7]&127)<<14)|((u[8]&127)<<7)|(u[9]&127),end=Math.min(10+sz,u.length),o={};let p=10;
 const dec=(a,enc)=>{try{return new TextDecoder(enc===1?'utf-16le':enc===2?'utf-16be':enc===3?'utf-8':'iso-8859-1').decode(a).replace(/\0/g,'').trim()}catch(e){return''}};
 while(p+10<=end){const id=String.fromCharCode(u[p],u[p+1],u[p+2],u[p+3]);if(!/^[A-Z0-9]{4}$/.test(id))break;const fs=ver===4?((u[p+4]&127)<<21)|((u[p+5]&127)<<14)|((u[p+6]&127)<<7)|(u[p+7]&127):d.getUint32(p+4);if(fs<=0||p+10+fs>end)break;if(id==='TIT2'||id==='TPE1')o[id]=dec(u.subarray(p+11,p+10+fs),u[p+10]);p+=10+fs}
 return{title:o.TIT2,artist:o.TPE1}}catch(e){return{}}}
function addAudioFiles(list){
 const fl=[...list].filter(f=>f.type.startsWith('audio/')||AUDX.test(f.name));
 const bad=list.length-fl.length;
 if(!fl.length){toast('Itu bukan file lagu (mp3, m4a, ogg, wav, flac)');return}
 const fresh=[];let dup=0;
 fl.forEach(f=>{const sig=f.name+'|'+f.size;if(tracks.some(k=>k.sig===sig)||fresh.some(x=>x.sig===sig)){dup++;return}fresh.push({f,sig})});
 if(!fresh.length){toast('Lagu itu sudah ada di daftar');return}
 const first=tracks.length;
 fresh.forEach(({f,sig},j)=>{
  const src=URL.createObjectURL(f),k={id:'f'+Date.now()+'_'+j,sig,title:f.name.replace(/\.[^.]+$/,''),artist:'File sendiri',type:'file',src,dur:0,h:hashH(f.name)};
  tracks.push(k);const ts=Date.now()+j;keepMedia({id:k.id,sig,ts,kind:'audio',title:k.title,artist:k.artist,h:k.h,blob:f});
  const a=new Audio();a.preload='metadata';
  a.onloadedmetadata=()=>{k.dur=a.duration;renderList()};
  a.onerror=()=>{const i=tracks.indexOf(k);if(i<0)return;toast('"'+k.title+'" tidak bisa diputar di browser ini');URL.revokeObjectURL(k.src);dropMedia(k.id);const was=playing&&i===cur;tracks.splice(i,1);if(!tracks.length){load(0,false)}else if(i<cur){cur--;renderList()}else if(i===cur){load(Math.min(cur,tracks.length-1),was)}else renderList()};
  a.src=src;
  readId3(f).then(m=>{if(!m||(!m.title&&!m.artist))return;if(m.title)k.title=m.title;if(m.artist)k.artist=m.artist;keepMedia({id:k.id,sig,ts,kind:'audio',title:k.title,artist:k.artist,h:k.h,blob:f});if(tracks[cur]===k)meta();else renderList()})
 });
 load(first,true);
 toast(fresh.length+' lagu ditambahkan'+(dup?', '+dup+' sudah ada':'')+(bad?', '+bad+' bukan lagu':''));
}
$('#pf').onchange=e=>{const fl=[...e.target.files];e.target.value='';if(fl.length)addAudioFiles(fl)};
addEventListener('keydown',e=>e.key==='Escape'&&closePlayer());
try{const ms=navigator.mediaSession;ms.setActionHandler('play',play);ms.setActionHandler('pause',pause);ms.setActionHandler('previoustrack',()=>next(-1,false));ms.setActionHandler('nexttrack',()=>next(1,false))}catch(e){}
['#pimg','#mimg'].forEach(s=>$(s).src=AVDEF);
$('#vol').style.setProperty('--p','70%');paintRp();load(0,false);
/* ===== animasi di SEKITAR karakter yang mengikuti beat lagu (karakternya sendiri tidak digerakkan) ===== */
const fxOn=()=>{try{return localStorage.getItem('luma-fx')!=='0'}catch(e){return true}};
const FX={cv:null,g:null,w:0,h:0,raf:0,data:null,avg:0,last:0,rings:[],pts:[],rot:0,hue:270,fr:0,bass:0,kick:0};
/* ambil sinyal audio hanya untuk dianalisis; pemutaran lagu tidak dialihkan */
function fxTap(){try{ensureCtx();if(ctx.state!=='running')ctx.resume();
  if(au.captureStream){const st=au.captureStream(),tr=st.getAudioTracks();if(tr.length){const id=tr.map(t=>t.id).join();if(id!==fxId){try{fxS&&fxS.disconnect()}catch(e){}fxS=ctx.createMediaStreamSource(st);fxS.connect(an);fxId=id}}}
  else if(!fxMS){fxMS=ctx.createMediaElementSource(au);fxMS.connect(an);fxMS.connect(ctx.destination)}}catch(e){}}
au.addEventListener('playing',fxTap);
document.addEventListener('click',()=>{try{if(ctx&&ctx.state==='suspended'&&playing)ctx.resume()}catch(e){}},true);
function fxResize(){const c=FX.cv;if(!c)return;const r=c.parentNode.getBoundingClientRect(),d=Math.min(1.5,devicePixelRatio||1);FX.w=r.width;FX.h=r.height;c.width=Math.round(r.width*d);c.height=Math.round(r.height*d);FX.g.setTransform(d,0,0,d,0,0)}
function fxSync(){if(!FX.cv){FX.cv=$('#beatfx');if(!FX.cv)return;FX.g=FX.cv.getContext('2d');addEventListener('resize',()=>{if(FX.raf)fxResize()})}
  if(playing&&fxOn()&&!FX.raf){fxResize();FX.raf=requestAnimationFrame(fxFrame)}}
function fxFrame(t){
  const F=FX,g=F.g;F.raf=requestAnimationFrame(fxFrame);
  const act=playing&&fxOn();let bass=0,mid=0;
  if(act&&an){if(!F.data)F.data=new Uint8Array(an.frequencyBinCount);an.getByteFrequencyData(F.data);const d=F.data;for(let i=0;i<4;i++)bass+=d[i];bass/=1020;for(let i=4;i<24;i++)mid+=d[i];mid/=20*255}
  F.bass+=(bass-F.bass)*(bass>F.bass?.65:.14);F.kick*=.9;F.rot+=.003+mid*.02;
  if(F.fr++%45===0){F.hue=parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--th'))||270}
  /* deteksi beat: bass melonjak di atas rata-rata berjalan */
  if(act&&bass>.26&&bass>F.avg*1.28+.03&&t-F.last>230){
    F.last=t;F.kick=1;F.rings.push({p:0});
    const n=5+Math.round(bass*9);for(let i=0;i<n&&F.pts.length<90;i++){const a=Math.random()*6.283;F.pts.push({a,r:0,v:1.1+Math.random()*2.4+bass*2,s:1.6+Math.random()*3.2,l:1,u:Math.random()*.6})}}
  F.avg+=(bass-F.avg)*.06;
  const w=F.w,h=F.h,cx=w/2,cy=h*.5,R=Math.min(w*.33,h*.2),H=F.hue;
  /* bila model tampil, batang spektrum & riak digambar di lantai 3D (vrm.js) lewat window.__lumaBeat; di sini hanya percikan bintang */
  const FLR=window.__lumaFloor,stg=$('#stage'),onF=!!(FLR&&stg&&stg.classList.contains('has-vrm')&&!stg.classList.contains('model-off'));
  const FB=window.__lumaBeat||(window.__lumaBeat={on:false,bass:0,kick:0,rot:0,hue:270,rings:[],bars:[]});
  FB.on=true;FB.bass=F.bass;FB.kick=F.kick;FB.rot=F.rot;FB.hue=H;FB.rings=F.rings.map(q=>q.p);
  if(act&&F.data){const N=56,d=F.data;FB.bars.length=N;for(let i=0;i<N;i++){const j=i<N/2?i:N-1-i;FB.bars[i]=d[1+Math.floor(j/(N/2)*64)]/255}}else FB.bars.length=0;
  g.clearRect(0,0,w,h);
  /* cahaya lembut yang berdenyut di belakang karakter */
  if(!onF){const gr=R*(1.55+F.bass*.55+F.kick*.2),gg=g.createRadialGradient(cx,cy,R*.3,cx,cy,gr);
  gg.addColorStop(0,'hsla('+H+',90%,68%,'+(.10+F.bass*.4+F.kick*.18).toFixed(3)+')');gg.addColorStop(1,'hsla('+H+',90%,68%,0)');
  g.fillStyle=gg;g.beginPath();g.arc(cx,cy,gr,0,6.283);g.fill();}
  /* cincin yang memancar tiap beat */
  for(let i=F.rings.length-1;i>=0;i--){const q=F.rings[i];q.p+=.022;if(q.p>=1){F.rings.splice(i,1);continue}
    if(onF)continue;const a=Math.pow(1-q.p,1.6)*.6;g.strokeStyle='hsla('+(H+30)+',95%,75%,'+a.toFixed(3)+')';g.lineWidth=1.5+(1-q.p)*4;g.beginPath();g.arc(cx,cy,R*(.95+q.p*1.15),0,6.283);g.stroke()}
  /* batang spektrum melingkar */
  if(act&&F.data&&!onF){const N=56,d=F.data;g.lineCap='round';g.lineWidth=3.2;
    for(let i=0;i<N;i++){const j=i<N/2?i:N-1-i,v=d[1+Math.floor(j/(N/2)*64)]/255,len=3+v*v*R*.5+F.kick*4,an2=i/N*6.283+F.rot,c=Math.cos(an2),s2=Math.sin(an2),r0=R*1.04;
      g.strokeStyle='hsla('+(H+i*2.5)+',92%,'+(66+v*14)+'%,'+(.28+v*.6).toFixed(3)+')';g.beginPath();g.moveTo(cx+c*r0,cy+s2*r0);g.lineTo(cx+c*(r0+len),cy+s2*(r0+len));g.stroke()}}
  /* percikan bintang yang melayang keluar */
  for(let i=F.pts.length-1;i>=0;i--){const q=F.pts[i];q.r+=q.v;q.v*=.965;q.l-=.014+q.u*.01;if(q.l<=0){F.pts.splice(i,1);continue}
    let x,y;if(onF){const k=.7+.25*(1-q.l);x=FLR.x+Math.cos(q.a)*FLR.rx*k;y=FLR.y+Math.sin(q.a)*FLR.ry*k-q.r*.9}else{x=cx+Math.cos(q.a)*(R*1.1+q.r);y=cy+Math.sin(q.a)*(R*1.1+q.r)-q.r*.25}g.globalAlpha=q.l;g.fillStyle='hsl('+(H+q.u*80)+',95%,80%)';
    const z=q.s*(.6+q.l*.6);g.beginPath();g.moveTo(x,y-z*1.6);g.lineTo(x+z*.45,y-z*.45);g.lineTo(x+z*1.6,y);g.lineTo(x+z*.45,y+z*.45);g.lineTo(x,y+z*1.6);g.lineTo(x-z*.45,y+z*.45);g.lineTo(x-z*1.6,y);g.lineTo(x-z*.45,y-z*.45);g.closePath();g.fill()}
  g.globalAlpha=1;
  /* kilau di dasar layar */
  if(F.bass>.02){const b=g.createLinearGradient(0,h,0,h*.55);b.addColorStop(0,'hsla('+H+',90%,65%,'+(F.bass*.28).toFixed(3)+')');b.addColorStop(1,'hsla('+H+',90%,65%,0)');g.fillStyle=b;g.fillRect(0,h*.55,w,h*.45)}
  /* berhenti sendiri setelah lagu dijeda dan semua efek memudar */
  if(!act&&!F.rings.length&&!F.pts.length&&F.bass<.015){cancelAnimationFrame(F.raf);F.raf=0;g.clearRect(0,0,w,h);F.bass=0;FB.on=false;FB.bars.length=0;FB.rings=[]}
}
// kontrol musik di tab + pemutar video
$('#imimg').src=$('#fmimg').src=AVDEF;
$('#ipp').onclick=toggle;$('#ipv').onclick=$('#pv').onclick;$('#inx').onclick=()=>next(1,false);$('#iop').onclick=openPlayer;
$('#fmpp').onclick=toggle;$('#fmpv').onclick=$('#pv').onclick;$('#fmnx').onclick=()=>next(1,false);
$('#fmbar').onclick=e=>{const r=e.currentTarget.getBoundingClientRect();seekTo(dur()*(e.clientX-r.left)/r.width)};
$('#ibar').onclick=e=>{const r=e.currentTarget.getBoundingClientRect();seekTo(dur()*(e.clientX-r.left)/r.width)};
const vp=$('#vp'),vids=[];let vcur=-1;
function renderVids(){$('#vl').innerHTML=vids.map((v,i)=>`<div class="tr ${i===vcur?'cur':''}" data-i="${i}"><span class="n">🎬</span><div class="tt"><b>${esc(v.title)}</b><small>${esc(v.size)}</small></div><button class="x" aria-label="Hapus video">✕</button></div>`).join('');$('#vempty').hidden=vids.length>0;vp.hidden=!vids.length;$('#vadd2').hidden=!vids.length}
function playVid(i){vcur=i;vp.src=vids[i].src;vp.play().catch(()=>{});renderVids()}
$('#vadd').onclick=$('#vadd2').onclick=()=>$('#vf').click();
$('#vf').onchange=e=>{const fl=[...e.target.files];if(!fl.length)return;const first=vids.length;fl.forEach((f,j)=>{const v={id:'v'+Date.now()+j,title:f.name.replace(/\.[^.]+$/,''),src:URL.createObjectURL(f),size:(f.size/1048576).toFixed(1)+' MB'};vids.push(v);keepMedia({id:v.id,kind:'video',title:v.title,size:v.size,blob:f})});playVid(first);toast(fl.length+' video ditambahkan');e.target.value=''};
$('#vl').onclick=e=>{const r=e.target.closest('.tr');if(!r)return;const i=+r.dataset.i;if(e.target.closest('.x')){URL.revokeObjectURL(vids[i].src);dropMedia(vids[i].id);vids.splice(i,1);if(i===vcur){vp.pause();vp.removeAttribute('src');vp.load();vcur=-1;if(vids.length)playVid(Math.min(i,vids.length-1));else renderVids()}else{if(i<vcur)vcur--;renderVids()}return}playVid(i)};
vp.onplay=()=>{if(playing)pause()};
vp.onended=()=>{if(vcur<vids.length-1)playVid(vcur+1)};
renderVids();
(async()=>{try{const all=((await MDB.all())||[]).sort((a,b)=>a.ts-b.ts);if(!all.length)return;
all.forEach(r=>{if(!r.blob||tracks.some(k=>k.id===r.id)||vids.some(v=>v.id===r.id))return;const src=URL.createObjectURL(r.blob);
if(r.kind==='audio'){const k={id:r.id,sig:r.sig||'',title:r.title,artist:r.artist||'File sendiri',type:'file',src,dur:0,h:r.h||0};tracks.push(k);const a=new Audio();a.preload='metadata';a.onloadedmetadata=()=>{k.dur=a.duration;renderList()};a.src=src}
else vids.push({id:r.id,title:r.title,src,size:r.size||''})});
renderList();renderVids()}catch(e){}})();
// pengelola berkas ala ZArchiver
const FM={files:[],arc:null,prefix:'',sel:new Set(),prev:null,busy:false};
const EXT=n=>(n.split('.').pop()||'').toLowerCase(),OKX=new Set('gif png jpg jpeg webp mp4 webm txt json md docx pptx epub csv ttf html svg pdf xlsx zip'.split(' '));
const isTar=n=>/\.(tar|tar\.gz|tgz)$/i.test(n),isZip=n=>['zip','jar','apk','docx','xlsx','pptx','epub'].includes(EXT(n));
const fsz=b=>b<1024?b+' B':b<1048576?(b/1024).toFixed(1)+' KB':(b/1048576).toFixed(1)+' MB';
const MIME={png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',gif:'image/gif',webp:'image/webp',svg:'image/svg+xml',bmp:'image/bmp',mp3:'audio/mpeg',wav:'audio/wav',ogg:'audio/ogg',m4a:'audio/mp4',aac:'audio/aac',flac:'audio/flac',mp4:'video/mp4',webm:'video/webm',mov:'video/quicktime','3gp':'video/3gpp'};
const fIcon=(n,d)=>d?'📁':isZip(n)||isTar(n)?'🗜️':(MIME[EXT(n)]||'').startsWith('image')?'🖼️':(MIME[EXT(n)]||'').startsWith('audio')?'🎵':(MIME[EXT(n)]||'').startsWith('video')?'🎬':/^(txt|md|json|csv|html|js|css|xml|log|ini|yml|yaml)$/.test(EXT(n))?'📄':'📦';
const fempty=(t,s,act)=>`<div class="fr tk emp arc" ${act?`data-a="${act}"`:''}><div class="tl"><span class="tgl">Kosong</span><span class="mi"><i style="width:0%"></i></span><em>0%</em></div><div class="tc"><span class="fi dm"><b>${act?'➕':'📂'}</b></span><div class="tt"><b>${t}</b><small>${s}</small></div></div></div>`;
const fcat=(n,d)=>{if(d)return['dir','Folder'];if(isZip(n)||isTar(n))return['arc','Arsip'];const m=MIME[EXT(n)]||'';if(m.startsWith('image'))return['med','Gambar'];if(m.startsWith('audio'))return['med','Audio'];if(m.startsWith('video'))return['med','Video'];return['doc','Dokumen']};
const fcard=o=>{const[c,l]=fcat(o.name,o.dir),p=o.dir?0:Math.max(3,Math.round(o.size/o.mx*100));return `<div class="fr tk ${c}" data-a="${o.act}" ${o.attr}><div class="tl"><span class="tgl">${l}</span>${o.dir?'':`<span class="mi"><i style="width:${p}%"></i></span><em>${p}%</em>`}</div><div class="tc">${o.chk}<span class="fi dm"><b>${fIcon(o.name,o.dir)}</b></span><div class="tt"><b>${esc(o.name)}</b><small>${o.sub}</small></div>${o.rm||''}</div></div>`};
async function readTar(b,gz){let buf;if(gz)buf=await new Response(b.stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer();else buf=await b.arrayBuffer();
const u=new Uint8Array(buf),dec=new TextDecoder(),cut=s=>s.replace(/\0.*$/s,''),ents=[];let o=0;
while(o+512<=u.length){const h=u.subarray(o,o+512);if(!h[0])break;const name=cut(dec.decode(h.subarray(0,100))),pre=cut(dec.decode(h.subarray(345,500))),size=parseInt(cut(dec.decode(h.subarray(124,136))).trim()||'0',8),ty=String.fromCharCode(h[156]),path=(pre?pre+'/':'')+name;o+=512;
if(ty==='0'||ty==='\0'||ty==='5'){const s0=o,dir=ty==='5';ents.push({path:path.replace(/\/$/,''),dir,size:dir?0:size,get:async()=>new Blob([u.subarray(s0,s0+size)])})}o+=Math.ceil(size/512)*512}
return ents}
async function openArc(f){if(!isTar(f.name)&&typeof JSZip==='undefined')return toast('Pustaka ZIP belum termuat');FM.busy=true;fmRender();
try{let ents;if(isTar(f.name))ents=await readTar(f.blob,/(gz)$/i.test(f.name));else{const z=await JSZip.loadAsync(f.blob);ents=Object.values(z.files).map(o=>({path:o.name.replace(/\/$/,''),dir:o.dir,size:(o._data&&o._data.uncompressedSize)||0,get:()=>o.async('blob')}))}
FM.arc={f,ents};FM.prefix='';FM.sel.clear()}catch(e){toast('Arsip ini tidak bisa dibuka')}FM.busy=false;fmRender()}
function kids(){const pre=FM.prefix?FM.prefix+'/':'',m=new Map();for(const e of FM.arc.ents){if(!e.path.startsWith(pre)||e.path===FM.prefix)continue;const rest=e.path.slice(pre.length),i=rest.indexOf('/'),n=i<0?rest:rest.slice(0,i);if(!n)continue;if(i<0&&!e.dir)m.set(n,{name:n,path:pre+n,dir:false,size:e.size});else m.set(n,{name:n,path:pre+n,dir:true,size:0})}return[...m.values()].sort((a,b)=>b.dir-a.dir||a.name.localeCompare(b.name))}
async function saveBlob(name,blob){try{const dl=window.claude&&await window.claude.use('downloads');if(!dl){const u=URL.createObjectURL(blob),an=document.createElement('a');an.href=u;an.download=name;document.body.appendChild(an);an.click();an.remove();setTimeout(()=>URL.revokeObjectURL(u),4000);return toast('Mengunduh…')}await dl.save({filename:name,data:blob});toast('Disimpan')}catch(err){const c=err&&err.code;if(c==='declined')return;toast(c==='too_large'?'File terlalu besar untuk disimpan':'Gagal menyimpan')}}
async function zipSave(items,filename){if(typeof JSZip==='undefined')return toast('Pustaka ZIP belum termuat');toast('Menyiapkan…');const z=new JSZip();for(const it of items)z.file(it.name,it.blob||await it.get());await saveBlob(filename,await z.generateAsync({type:'blob'}))}
const base=n=>n.replace(/\.[^.]+$/,'');
const saveSmart=(name,blob)=>OKX.has(EXT(name))?saveBlob(name,blob):zipSave([{name,blob}],base(name)+'.zip');
async function showPrev(name,blob){const x=EXT(name),mt=MIME[x]||'',kind=mt.startsWith('image')?'img':mt.startsWith('audio')?'audio':mt.startsWith('video')?'video':/^(txt|md|json|csv|html|js|css|xml|log|ini|yml|yaml)$/.test(x)?'text':'none',b=mt?new Blob([blob],{type:mt}):blob,p={name,blob:b,kind};
if(kind==='img')p.url=await new Promise(r=>{const fr=new FileReader();fr.onload=()=>r(fr.result);fr.readAsDataURL(b)});else if(kind==='audio'||kind==='video')p.url=URL.createObjectURL(b);else if(kind==='text')p.text=(await b.slice(0,20000).text())+(b.size>20000?'\n…':'');
FM.prev=p;fmRender()}
function fmRender(){const box=$('#fm');if(!box)return;
if(FM.busy){box.innerHTML='<h2>Berkas</h2><p>Membuka arsip…</p>';return}
if(FM.prev){const p=FM.prev;const body=p.kind==='img'?`<img class="pv" src="${p.url}" alt="">`:p.kind==='text'?`<pre class="pv">${esc(p.text)}</pre>`:p.kind==='audio'?`<audio class="pv" controls src="${p.url}" style="width:100%"></audio>`:p.kind==='video'?`<video class="pv" controls playsinline src="${p.url}" style="width:100%"></video>`:'<p>Pratinjau tidak tersedia untuk format ini, tapi file tetap bisa disimpan.</p>';
box.innerHTML=`<div class="fhd"><button class="ib" data-a="pback" aria-label="Kembali">←</button><h2>${esc(p.name)}</h2></div><p>${fsz(p.blob.size)}</p>${body}<div class="fbar"><button class="fl" data-a="psave">Unduh</button>${FM.arc?'<button class="fl" data-a="d-psave">Simpan ke Drive</button>':''}${p.kind==='audio'?'<button class="fl" data-a="padd">Tambah ke pemutar musik</button>':p.kind==='video'?'<button class="fl" data-a="padd">Tambah ke daftar video</button>':''}</div>`;return}
if(FM.arc){const a=FM.arc,list=kids(),crumb=[a.f.name].concat(FM.prefix?FM.prefix.split('/'):[]).join(' / ');
box.innerHTML=`<div class="fhd"><button class="ib" data-a="up" aria-label="Naik">←</button><h2>${esc(crumb)}</h2></div><div class="fbar"><button class="fl" data-a="all">Pilih semua</button><button class="fl" data-a="ext">${FM.sel.size?'Ekstrak ('+FM.sel.size+')':'Ekstrak semua'}</button></div>`+(list.length?(()=>{const mx=Math.max(1,...list.map(k=>k.size));return list.map(k=>fcard({name:k.name,dir:k.dir,size:k.size,mx,act:k.dir?'dir':'file',attr:`data-p="${esc(k.path)}"`,chk:`<input type="checkbox" data-a="sel" data-p="${esc(k.path)}" ${FM.sel.has(k.path)?'checked':''} aria-label="Pilih ${esc(k.name)}">`,sub:k.dir?'Folder':fsz(k.size)})).join('')})():fempty('Folder kosong','Tidak ada isi di folder ini',''));return}
dRender()}
async function fmClick(e){const el=e.target.closest('[data-a]');if(!el){if(e.target.closest&&e.target.closest('input'))return;if(!FM.prev&&!FM.arc&&(DR.menu||DR.newOpen)){DR.menu=null;DR.newOpen=false;dRender()}return}if(el.dataset.a.startsWith('d-'))return dClick(el);const a=i=+el.dataset.i,p=el.dataset.p;
if(a==='add')$('#ff').click();
else if(a==='chk'){FM.files[i].sel=el.checked;const keep=$('#zn').value;fmRender();$('#zn').value=keep}
else if(a==='rm'){FM.files.splice(i,1);fmRender()}
else if(a==='open'){const f=FM.files[i];isZip(f.name)||isTar(f.name)?openArc(f):showPrev(f.name,f.blob)}
else if(a==='zip'){const nm=($('#zn').value.trim()||'arsip').replace(/[\\/:*?"<>|]/g,'_');zipSave(FM.files.filter(f=>f.sel),nm+'.zip')}
else if(a==='dir'){FM.prefix=p;FM.sel.clear();fmRender()}
else if(a==='file'){const ent=FM.arc.ents.find(x=>x.path===p);showPrev(p.split('/').pop(),await ent.get())}
else if(a==='sel'){el.checked?FM.sel.add(p):FM.sel.delete(p);fmRender()}
else if(a==='all'){const l=kids();if(FM.sel.size===l.length)FM.sel.clear();else l.forEach(k=>FM.sel.add(k.path));fmRender()}
else if(a==='up'){FM.sel.clear();if(FM.prefix){const j=FM.prefix.lastIndexOf('/');FM.prefix=j<0?'':FM.prefix.slice(0,j)}else FM.arc=null;fmRender()}
else if(a==='ext'){const pre=FM.prefix?FM.prefix+'/':'',roots=[...FM.sel],ch=FM.arc.ents.filter(x=>!x.dir&&x.path.startsWith(pre)&&(!roots.length||roots.some(r=>x.path===r||x.path.startsWith(r+'/'))));
if(!ch.length)return toast('Tidak ada berkas untuk diekstrak');
if(ch.length===1)saveSmart(ch[0].path.split('/').pop(),await ch[0].get());else zipSave(ch.map(x=>({name:x.path.slice(pre.length),get:x.get})),base(FM.arc.f.name)+'-ekstrak.zip')}
else if(a==='pback'){if(FM.prev.kind==='audio'||FM.prev.kind==='video')URL.revokeObjectURL(FM.prev.url);FM.prev=null;fmRender()}
else if(a==='psave')saveSmart(FM.prev.name,FM.prev.blob);
else if(a==='padd'){const q=FM.prev,u=URL.createObjectURL(q.blob);if(q.kind==='audio'){{const k={id:'f'+Date.now(),title:base(q.name),artist:'Dari arsip',type:'file',src:u,dur:0,h:hashH(q.name)};tracks.push(k);keepMedia({id:k.id,kind:'audio',title:k.title,artist:k.artist,h:k.h,blob:q.blob})}renderList();toast('Ditambahkan ke pemutar musik')}else{{const v={id:'v'+Date.now(),title:base(q.name),src:u,size:fsz(q.blob.size)};vids.push(v);keepMedia({id:v.id,kind:'video',title:v.title,size:v.size,blob:q.blob})}renderVids();toast('Ditambahkan ke daftar video')}}}
/* ===== Drive: penyimpanan file permanen (IndexedDB 'luma-drive') ===== */
const DDB=(()=>{let db;const open=()=>db||(db=new Promise((res,rej)=>{try{const r=indexedDB.open('luma-drive',1);r.onupgradeneeded=()=>r.result.createObjectStore('f',{keyPath:'id'});r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)}catch(e){rej(e)}}));
const tx=(mode,fn)=>open().then(d=>new Promise((res,rej)=>{const t=d.transaction('f',mode),q=fn(t.objectStore('f'));t.oncomplete=()=>res(q&&q.result);t.onerror=t.onabort=()=>rej(t.error)}));
return{put:r=>tx('readwrite',s=>s.put(r)),del:id=>tx('readwrite',s=>s.delete(id)),all:()=>tx('readonly',s=>s.getAll())}})();
const DR={items:[],loaded:false,tab:'drive',cur:'root',q:'',cat:'all',sort:'date',sel:new Set(),selMode:false,menu:null,dlg:null,moving:null,newOpen:false,thumbs:new Map(),
grid:(()=>{try{return localStorage.getItem('luma-drive-grid')!=='0'}catch(e){return true}})()};
const DFOLD='<svg viewBox="0 0 24 24" fill="currentColor"><path d="M10 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-8z"/></svg>';
const DIC={search:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>',
grid:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/></svg>',
list:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 6h16M4 12h16M4 18h16"/></svg>'};
const DMI={"up": "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M12 16V4M7 9l5-5 5 5M4 20h16\"/></svg>", "newf": "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"/><path d=\"M12 10v5M9.5 12.5h5\"/></svg>", "open": "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"/></svg>", "down": "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M12 4v12M7 11l5 5 5-5M4 20h16\"/></svg>", "star": "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z\"/></svg>", "edit": "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M4 20h4L19 9l-4-4L4 16zM14 6l4 4\"/></svg>", "move": "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"/><path d=\"M9 13h6M13 10l3 3-3 3\"/></svg>", "trash": "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3\"/></svg>", "restore": "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M4 12a8 8 0 1 0 2.5-5.8M4 4v5h5M12 8v4l3 2\"/></svg>"};
const did=()=>'d'+Date.now().toString(36)+Math.random().toString(36).slice(2,6);
const dById=id=>DR.items.find(x=>x.id===id);
const dDate=ts=>new Date(ts).toLocaleDateString('id-ID',{day:'numeric',month:'short',year:'numeric'});
const dType=it=>{if(it.folder)return'dir';const x=EXT(it.name),m=it.mime||MIME[x]||'';if(m.startsWith('image'))return'img';if(m.startsWith('video'))return'vid';if(m.startsWith('audio'))return'aud';if((isZip(it.name)&&!/^(docx|xlsx|pptx|epub)$/.test(x))||isTar(it.name))return'arc';return'doc'};
const dKids=id=>DR.items.filter(x=>x.parent===id);
function dUniq(name,parent){const has=n=>DR.items.some(x=>!x.trash&&x.parent===parent&&x.name===n);if(!has(name))return name;const i=name.lastIndexOf('.'),b=i>0?name.slice(0,i):name,e=i>0?name.slice(i):'';let k=2;while(has(b+' ('+k+')'+e))k++;return b+' ('+k+')'+e}
function dPath(f){const a=[];let c=f;while(c){a.unshift(c.name);c=c.parent!=='root'?dById(c.parent):null}return a.join(' / ')}
function dThumb(it){if(dType(it)!=='img'||!it.blob)return'';let u=DR.thumbs.get(it.id);if(!u){u=URL.createObjectURL(it.blob);DR.thumbs.set(it.id,u)}return u}
const dSave=it=>DDB.put(it).catch(()=>toast('Gagal menyimpan (penyimpanan penuh atau tidak didukung)'));
async function dLoad(){try{DR.items=(await DDB.all())||[]}catch(e){DR.items=[]}
  const lim=Date.now()-30*864e5,old=DR.items.filter(x=>x.trash&&x.trash<lim);old.forEach(x=>DDB.del(x.id).catch(()=>{}));if(old.length)DR.items=DR.items.filter(x=>!(x.trash&&x.trash<lim));
  DR.loaded=true}
let dAsked=false;
function dPersist(){if(dAsked)return;dAsked=true;try{navigator.storage&&navigator.storage.persist&&navigator.storage.persist()}catch(e){}}
async function dUpload(files){const parent=DR.tab==='drive'?DR.cur:'root';let n=0;dPersist();
  for(const f of files){const it={id:did(),name:dUniq(f.name,parent),folder:false,parent,size:f.size,mime:f.type||'',ts:Date.now(),star:false,trash:0,blob:f};
    try{await DDB.put(it);DR.items.push(it);n++}catch(e){toast('Gagal menyimpan '+f.name+' (penyimpanan penuh?)');break}}
  if(n)toast(n+' file disimpan di Drive');DR.tab='drive';DR.cur=parent;DR.q='';DR.cat='all';fmRender()}
async function dAddBlob(name,blob,parent){dPersist();const it={id:did(),name:dUniq(name,parent),folder:false,parent,size:blob.size,mime:blob.type||'',ts:Date.now(),star:false,trash:0,blob};try{await DDB.put(it);DR.items.push(it);return it}catch(e){toast('Gagal menyimpan (penyimpanan penuh?)');return null}}
function dDesc(id,out=[]){dKids(id).forEach(x=>{out.push(x);if(x.folder)dDesc(x.id,out)});return out}
function dTrash(ids){const ts=Date.now();ids.forEach(id=>{const it=dById(id);if(!it||it.trash)return;[it,...(it.folder?dDesc(id):[])].forEach(x=>{if(!x.trash){x.trash=ts;dSave(x)}})});DR.sel.clear();DR.selMode=false;DR.menu=null;toast('Dipindahkan ke sampah')}
function dRestore(id){const it=dById(id);if(!it)return;const t=it.trash;[it,...(it.folder?dDesc(id).filter(x=>x.trash===t):[])].forEach(x=>{x.trash=0;dSave(x)});const p=it.parent!=='root'?dById(it.parent):null;if(p&&p.trash){it.parent='root';dSave(it)}it.name=dUniq(it.name,it.parent)===it.name?it.name:it.name;DR.menu=null;toast('Dipulihkan')}
function dPurge(ids){ids.forEach(id=>{const it=dById(id);if(!it)return;[it,...(it.folder?dDesc(id):[])].forEach(x=>{DDB.del(x.id).catch(()=>{});const u=DR.thumbs.get(x.id);if(u){URL.revokeObjectURL(u);DR.thumbs.delete(x.id)}DR.items=DR.items.filter(y=>y.id!==x.id)})});DR.menu=null;toast('Dihapus permanen')}
function dGather(ids,pre,out){for(const id of ids){const it=dById(id);if(!it)continue;if(it.folder)dGather(dKids(id).filter(x=>!x.trash).map(x=>x.id),pre+it.name+'/',out);else out.push({name:pre+it.name,blob:it.blob})}return out}
function dVisible(){let l=DR.items.filter(x=>DR.tab==='trash'?(x.trash&&!(x.parent!=='root'&&dById(x.parent)&&dById(x.parent).trash===x.trash)):!x.trash);
  if(DR.tab==='star')l=l.filter(x=>x.star);
  else if(DR.tab==='drive'&&!DR.q&&DR.cat==='all')l=l.filter(x=>x.parent===DR.cur);
  if(DR.q){const q=DR.q.toLowerCase();l=l.filter(x=>x.name.toLowerCase().includes(q))}
  if(DR.cat!=='all')l=l.filter(x=>dType(x)===DR.cat);
  const s=DR.sort;l.sort((a,b)=>(b.folder?1:0)-(a.folder?1:0)||(s==='name'?a.name.localeCompare(b.name):s==='size'?(b.size||0)-(a.size||0):b.ts-a.ts));return l}
function dMenu(it){const tr=DR.tab==='trash',b=(a,l,ic)=>`<button data-a="${a}" data-id="${it.id}"><i>${ic}</i><span>${l}</span></button>`;
  return `<div class="dmenu">${tr?b('d-restore','Pulihkan',DMI.restore)+b('d-purge','Hapus permanen',DMI.trash):b('d-open',it.folder?'Buka':'Buka / pratinjau',DMI.open)+(it.folder?'':b('d-dl','Unduh',DMI.down))+b('d-star',it.star?'Hapus bintang':'Beri bintang',DMI.star)+b('d-ren','Ganti nama',DMI.edit)+b('d-mv','Pindahkan',DMI.move)+b('d-del','Hapus',DMI.trash)}</div>`}
function dItem(it,mode){const t=dType(it),sel=DR.sel.has(it.id),th=dThumb(it),chk=DR.selMode?`<span class="dck ${sel?'on':''}"></span>`:'',
  kb=DR.selMode?'':`<button class="dkb" data-a="d-menu" data-id="${it.id}" aria-label="Opsi">⋮</button>`,menu=DR.menu===it.id?dMenu(it):'',
  ic=it.folder?DFOLD:`<b>${fIcon(it.name,false)}</b>`,star=it.star?' ⭐':'',
  meta=it.folder?(dKids(it.id).filter(x=>!x.trash).length+' item'):fsz(it.size||0)+' · '+dDate(it.ts);
  if(mode==='fold')return `<div class="dfold ${sel?'sel':''}" data-a="d-open" data-id="${it.id}">${chk}<span class="dsm dt-dir">${ic}</span><div class="dtt"><b>${esc(it.name)}${star}</b></div>${kb}${menu}</div>`;
  if(mode==='card')return `<div class="dcard ${sel?'sel':''}" data-a="d-open" data-id="${it.id}"><div class="dth dt-${t}">${th?`<img src="${th}" alt="">`:`<span class="dbig">${ic}</span>`}${chk}</div><div class="dft"><span class="dsm dt-${t}">${ic}</span><div class="dtt"><b>${esc(it.name)}${star}</b><small>${meta}</small></div>${kb}</div>${menu}</div>`;
  return `<div class="drow ${sel?'sel':''}" data-a="d-open" data-id="${it.id}">${chk}<span class="dsm lg dt-${t}">${th?`<img src="${th}" alt="">`:ic}</span><div class="dtt"><b>${esc(it.name)}${star}</b><small>${meta}</small></div>${kb}${menu}</div>`}
function dDlg(){const d=DR.dlg;return `<div class="dlg"><b>${d.type==='folder'?'Folder baru':'Ganti nama'}</b><input id="dnm" value="${esc(d.value)}" maxlength="80" autocomplete="off"><div class="fbar"><button class="fl on" data-a="d-dlgok">Simpan</button><button class="fl" data-a="d-dlgno">Batal</button></div></div>`}
function dMoveBox(){const bad=new Set(),mark=id=>{bad.add(id);dKids(id).forEach(x=>mark(x.id))};DR.moving.forEach(mark);const fs=DR.items.filter(x=>x.folder&&!x.trash&&!bad.has(x.id)).sort((a,b)=>dPath(a).localeCompare(dPath(b)));
  return `<div class="dlg"><b>Pindahkan ke…</b><div class="dmv"><button data-a="d-mvto" data-id="root"><span class="dsm dt-dir">${DFOLD}</span>Drive Saya</button>${fs.map(f=>`<button data-a="d-mvto" data-id="${f.id}"><span class="dsm dt-dir">${DFOLD}</span>${esc(dPath(f))}</button>`).join('')}</div><div class="fbar"><button class="fl" data-a="d-dlgno">Batal</button></div></div>`}
function dBody(){const el=$('#dbody');if(!el)return;const l=dVisible(),drv=DR.tab==='drive'&&!DR.q&&DR.cat==='all';let h='';
  if(DR.dlg)h+=dDlg();if(DR.moving)h+=dMoveBox();
  if(DR.selMode){const n=DR.sel.size;h+=`<div class="dsel"><b>${n} dipilih</b><button class="fl" data-a="d-selzip" ${n?'':'disabled'}>ZIP</button><button class="fl" data-a="d-selmv" ${n?'':'disabled'}>Pindahkan</button><button class="fl" data-a="d-seldel" ${n?'':'disabled'}>Hapus</button></div>`}
  if(drv){const cr=[];let id=DR.cur;while(id&&id!=='root'){const f=dById(id);if(!f)break;cr.unshift(f);id=f.parent}
    h+=`<div class="dcr"><button data-a="d-go" data-id="root">Drive Saya</button>${cr.map(f=>`<span>›</span><button data-a="d-go" data-id="${f.id}">${esc(f.name)}</button>`).join('')}</div>`}
  if(DR.tab==='trash')h+=`<div class="dnote"><span>Item di sampah dihapus otomatis setelah 30 hari.</span>${l.length?'<button class="fl" data-a="d-empty">Kosongkan</button>':''}</div>`;
  h+=`<div class="dsort"><button data-a="d-sort">${({date:'Terbaru',name:'Nama',size:'Ukuran'})[DR.sort]} ↓</button>${DR.tab!=='trash'?`<button data-a="d-sel" class="${DR.selMode?'on':''}">${DR.selMode?'Selesai':'Pilih'}</button>`:''}</div>`;
  const fo=l.filter(x=>x.folder),fi=l.filter(x=>!x.folder);
  if(!l.length){const msg=DR.q?['🔍','Tidak ditemukan','Coba kata kunci lain']:DR.tab==='star'?['⭐','Belum ada berbintang','Beri bintang pada file penting']:DR.tab==='trash'?['🗑️','Sampah kosong','Item yang dihapus muncul di sini']:DR.cat!=='all'?['📂','Tidak ada file','Belum ada file jenis ini']:['☁️','Drive masih kosong','Ketuk “Baru” untuk mengunggah file atau membuat folder'];
    h+=`<div class="dempty"><div>${msg[0]}</div><b>${msg[1]}</b><small>${msg[2]}</small></div>`}
  else{if(fo.length)h+=`<div class="dlbl">Folder</div><div class="dfolds">${fo.map(x=>dItem(x,'fold')).join('')}</div>`;
    if(fi.length)h+=`<div class="dlbl">File</div><div class="${DR.grid?'dgrid':'dlist'}">${fi.map(x=>dItem(x,DR.grid?'card':'row')).join('')}</div>`}
  el.innerHTML=h;if(DR.dlg){const i=$('#dnm');if(i){i.focus();i.select()}}}
function dStorage(){const el=$('#dsto');if(!el)return;const used=DR.items.reduce((s,x)=>s+(x.size||0),0),set=(u,q)=>{const p=q?Math.max(1,Math.min(100,u/q*100)):0;el.innerHTML=`<div class="dsb"><i style="width:${p}%"></i></div><small>${fsz(u)} terpakai${q?' dari '+fsz(q)+' kuota browser':''}</small>`};set(used,0);
  try{navigator.storage&&navigator.storage.estimate&&navigator.storage.estimate().then(e=>{if(e&&e.quota)set(used,e.quota)})}catch(e){}}
function dRender(){const box=$('#fm');if(!box)return;
  if(!DR.loaded){box.innerHTML='<h2>Drive</h2><p>Memuat…</p>';return}
  const tabs=[['drive','Drive Saya'],['star','Berbintang'],['trash','Sampah']],cats=[['img','Gambar'],['vid','Video'],['aud','Audio'],['doc','Dokumen'],['arc','Arsip']];
  box.innerHTML=`<h2 class="dh">Drive</h2><div class="dsearch">${DIC.search}<input id="dq" type="search" placeholder="Cari di Drive" value="${esc(DR.q)}" autocomplete="off" aria-label="Cari file"><button data-a="d-view" aria-label="Ganti tampilan">${DR.grid?DIC.list:DIC.grid}</button></div>`
   +`<div class="dtabs">${tabs.map(t=>`<button class="${DR.tab===t[0]?'on':''}" data-a="d-tab" data-v="${t[0]}">${t[1]}</button>`).join('')}</div>`
   +(DR.tab!=='trash'?`<div class="dchips">${cats.map(c=>`<button class="${DR.cat===c[0]?'on':''}" data-a="d-cat" data-v="${c[0]}">${c[1]}</button>`).join('')}</div>`:'')
   +(DR.tab==='drive'?'<div id="dsto" class="dsto"></div>':'')+'<div id="dbody"></div>'
   +`<div class="dfabw"><div class="dfabi"><button class="dfab" data-a="d-new"><span>＋</span> Baru</button>${DR.newOpen?`<div class="dmenu dnewm"><button data-a="d-upload"><i>${DMI.up}</i><span>Unggah file</span></button><button data-a="d-newfolder"><i>${DMI.newf}</i><span>Folder baru</span></button></div>`:''}</div></div>`;
  dBody();dStorage()}
async function dClick(el){const a=el.dataset.a,id=el.dataset.id,it=id?dById(id):null;
  if(a==='d-menu'){DR.menu=DR.menu===id?null:id;dBody();return}
  if(a==='d-open'&&DR.selMode&&it){DR.sel.has(id)?DR.sel.delete(id):DR.sel.add(id);dBody();return}
  const wasNew=DR.newOpen;DR.newOpen=false;const hadMenu=DR.menu;DR.menu=null;
  if(a==='d-tab'){DR.tab=el.dataset.v;DR.sel.clear();DR.selMode=false;DR.dlg=null;DR.moving=null;DR.q=''}
  else if(a==='d-cat')DR.cat=DR.cat===el.dataset.v?'all':el.dataset.v;
  else if(a==='d-view'){DR.grid=!DR.grid;try{localStorage.setItem('luma-drive-grid',DR.grid?'1':'0')}catch(e){}}
  else if(a==='d-sort')DR.sort=DR.sort==='date'?'name':DR.sort==='name'?'size':'date';
  else if(a==='d-go'){DR.cur=id;DR.q='';DR.cat='all';DR.sel.clear()}
  else if(a==='d-sel'){DR.selMode=!DR.selMode;DR.sel.clear()}
  else if(a==='d-new')DR.newOpen=!wasNew;
  else if(a==='d-upload'){$('#ff').click()}
  else if(a==='d-newfolder'){DR.dlg={type:'folder',value:'Folder tanpa judul'}}
  else if(a==='d-dlgno'){DR.dlg=null;DR.moving=null}
  else if(a==='d-dlgok'){const v=(($('#dnm')||{}).value||'').trim().replace(/[\\/]/g,'_');if(!v){toast('Nama tidak boleh kosong');DR.dlg=DR.dlg;return}
    if(DR.dlg.type==='folder'){const parent=DR.tab==='drive'?DR.cur:'root',f={id:did(),name:dUniq(v,parent),folder:true,parent,size:0,mime:'',ts:Date.now(),star:false,trash:0};DR.items.push(f);dSave(f);DR.tab='drive';DR.cur=parent;toast('Folder dibuat')}
    else{const t=dById(DR.dlg.id);if(t){t.name=v===t.name?v:dUniq(v,t.parent);dSave(t);toast('Nama diganti')}}DR.dlg=null}
  else if(a==='d-ren'&&it)DR.dlg={type:'rename',id,value:it.name};
  else if(a==='d-star'&&it){it.star=!it.star;dSave(it)}
  else if(a==='d-del'&&it)dTrash([id]);
  else if(a==='d-restore'&&it)dRestore(id);
  else if(a==='d-purge'&&it)dPurge([id]);
  else if(a==='d-empty'){dPurge(dVisible().map(x=>x.id))}
  else if(a==='d-dl'&&it){saveBlob(it.name,it.blob)}
  else if(a==='d-mv'&&it)DR.moving=[id];
  else if(a==='d-selmv'&&DR.sel.size)DR.moving=[...DR.sel];
  else if(a==='d-seldel'&&DR.sel.size)dTrash([...DR.sel]);
  else if(a==='d-mvto'){DR.moving.forEach(m=>{const x=dById(m);if(x){x.parent=id;x.name=dUniq(x.name,id)===x.name?x.name:x.name;dSave(x)}});DR.moving=null;DR.sel.clear();DR.selMode=false;toast('Dipindahkan')}
  else if(a==='d-selzip'&&DR.sel.size){if(typeof JSZip==='undefined')return toast('Pustaka ZIP belum termuat');toast('Menyiapkan…');const fl=dGather([...DR.sel],'',[]);if(!fl.length){toast('Tidak ada file untuk dikompres');return}
    const z=new JSZip();fl.forEach(o=>z.file(o.name,o.blob));const blob=await z.generateAsync({type:'blob'});const parent=DR.tab==='drive'?DR.cur:'root';const r=await dAddBlob('arsip.zip',blob,parent);if(r)toast('ZIP disimpan: '+r.name);DR.sel.clear();DR.selMode=false}
  else if(a==='d-psave'&&FM.prev){const parent=DR.tab==='drive'?DR.cur:'root';const r=await dAddBlob(FM.prev.name,FM.prev.blob,parent);if(r)toast('Disimpan ke Drive');return}
  else if(a==='d-open'&&it){
    if(it.folder){if(DR.tab==='trash'){toast('Pulihkan dulu untuk membuka folder');DR.newOpen=false}else{DR.tab='drive';DR.cur=id;DR.q='';DR.cat='all'}}
    else if(DR.tab==='trash')toast('Pulihkan dulu untuk membuka file');
    else if(isZip(it.name)&&!/^(docx|xlsx|pptx|epub)$/.test(EXT(it.name))||isTar(it.name)){openArc({name:it.name,blob:it.blob});return}
    else{await showPrev(it.name,it.blob);return}}
  dRender()}

function initFM(){const b=$('#fm');b.onclick=fmClick;DR.menu=null;DR.dlg=null;DR.moving=null;DR.newOpen=false;
b.oninput=e=>{if(e.target.id==='dq'){DR.q=e.target.value;dBody()}};
b.onkeydown=e=>{if(e.key==='Enter'&&e.target.id==='dnm'){e.preventDefault();dClick({dataset:{a:'d-dlgok'}})}};
$('#ff').onchange=e=>{const fl=[...e.target.files];e.target.value='';if(fl.length)dUpload(fl)};
fmRender();if(!DR.loaded)dLoad().then(()=>{if($('#fm')===b)fmRender()})}
// profil karakter (pengaturan)
var MAINID='main',RNAME={};const ORIG=AVDEF,ORIGALT=$('#hero').alt,PKEY=()=>'luma-profile',FKEY=()=>'luma-photo',CHX={},
DEF=(id)=>{const x=CHX[id];return {name:'LUMA',series:x?x.series:'LUMA',stars:4,cut:false,stats:x?x.stats.map(t=>({...t})):[{l:'Kecerdasan',v:92},{l:'Rasa ingin tahu',v:98},{l:'Keceriaan',v:88}]}};
const PF=DEF();try{const s=JSON.parse(localStorage.getItem('luma-profile')||'{}');Object.assign(PF,s);if(PF.name==='ZUVEX')PF.name='LUMA'}catch(e){}
const savePF=()=>{lsSet(PKEY(),JSON.stringify(PF))};
const nice=s=>s.charAt(0).toUpperCase()+s.slice(1).toLowerCase();
function applyPF(){$('.name').textContent=PF.name;document.title='LUMA – Kartu Profil';$('.series').textContent=PF.series;
tracks.forEach(k=>{if(k.type==='gen')k.artist=nice(PF.name)});chatLog[0][1]='Halo! Aku '+nice(PF.name)+' ✌️';meta()}
function setPhoto(src){['#av','#pimg','#mimg','#imimg','#fmimg','#pfimg'].forEach(s=>{const e=$(s);if(e)e.src=src});document.documentElement.classList.toggle('cu',src!==ORIG)}
$('#hero').addEventListener('load',()=>calcHue());
function cutWhite(cv){const x=cv.getContext('2d'),w=cv.width,h=cv.height,im=x.getImageData(0,0,w,h),d=im.data,seen=new Uint8Array(w*h),st=[];
const push=i=>{if(!seen[i]){const o=i*4;if(d[o+3]>0&&Math.min(d[o],d[o+1],d[o+2])>=236){seen[i]=1;st.push(i)}}};
for(let i=0;i<w;i++){push(i);push((h-1)*w+i)}for(let j=0;j<h;j++){push(j*w);push(j*w+w-1)}
while(st.length){const i=st.pop(),cx=i%w,cy=(i/w)|0;if(cx>0)push(i-1);if(cx<w-1)push(i+1);if(cy>0)push(i-w);if(cy<h-1)push(i+w)}
for(let i=0;i<w*h;i++)if(seen[i])d[i*4+3]=0;
for(let i=0;i<w*h;i++){if(seen[i])continue;const cx=i%w,cy=(i/w)|0;if((cx>0&&seen[i-1])||(cx<w-1&&seen[i+1])||(cy>0&&seen[i-w])||(cy<h-1&&seen[i+w]))d[i*4+3]=Math.min(d[i*4+3],140)}
x.putImageData(im,0,0)}
function loadPhoto(file,cut){return new Promise((res,rej)=>{const fr=new FileReader();fr.onerror=rej;fr.onload=()=>{const img=new Image();img.onerror=rej;img.onload=()=>{const s=Math.min(1,900/img.width,1300/img.height),cv=document.createElement('canvas');cv.width=Math.round(img.width*s);cv.height=Math.round(img.height*s);cv.getContext('2d',{willReadFrequently:true}).drawImage(img,0,0,cv.width,cv.height);if(cut)cutWhite(cv);res(cv.toDataURL('image/webp',.8))};img.src=fr.result};fr.readAsDataURL(file)})}
function initPF(){const sc=$('#sc');renderChars();
$('#pfph').onclick=()=>$('#pfi').click();
$('#pfi').onchange=async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;try{const src=await loadPhoto(f,PF.cut);setPhoto(src);try{localStorage.setItem(FKEY(),src);toast('Foto diganti')}catch(er){toast('Foto dipakai, tapi terlalu besar untuk disimpan')}}catch(er){toast('Foto tidak bisa dibuka')}};
$('#pfrs').onclick=()=>{setPhoto(defPhoto());try{localStorage.removeItem(FKEY())}catch(e){}toast('Foto asli dipakai lagi')};
sc.querySelectorAll('[data-h]').forEach(b=>b.onclick=()=>{mode=b.dataset.h==='auto'?'auto':+b.dataset.h;setHue(mode==='auto'?autoH:mode);sc.querySelectorAll('[data-h]').forEach(x=>x.classList.toggle('on',x===b));toast(mode==='auto'?'Warna otomatis dari karakter':'Warna diganti');save()});
$('#tg').onclick=e=>{const d=document.documentElement.dataset.theme==='light';document.documentElement.dataset.theme=d?'dark':'light';e.currentTarget.classList.toggle('on',d);save()};
$('#pfreset').onclick=()=>{Object.assign(PF,DEF(MAINID));setPhoto(defPhoto());try{localStorage.removeItem(PKEY());localStorage.removeItem(FKEY())}catch(e){}delete CHS[MAINID];saveCH();renderChars();applyPF();open('profil');toast('Profil disetel ulang')}}
try{const ph=localStorage.getItem('luma-photo');if(ph)setPhoto(ph)}catch(e){}
applyPF();
const hd=$('.head');hd.style.cursor='pointer';hd.onclick=e=>{if(e.target.closest('.ed'))return;open('profil')};
// tombol pensil: sembunyikan / tampilkan kartu info (diingat di perangkat)
(()=>{const K='luma-info-hidden',R=document.documentElement,ed=$('.ed'),sh=$('#infoShow');
const re=()=>requestAnimationFrame(()=>requestAnimationFrame(()=>window.__lumaFrame&&window.__lumaFrame()));
const setH=(v,q)=>{R.classList.toggle('info-off',v);$('#info').inert=v;ed.setAttribute('aria-pressed',String(v));ed.setAttribute('aria-label',v?'Tampilkan kartu':'Sembunyikan kartu');try{localStorage.setItem(K,v?'1':'0')}catch(e){}};
ed.onclick=e=>{e.stopPropagation();setH(true)};sh.onclick=()=>setH(false);
let h=false;try{h=localStorage.getItem(K)==='1'}catch(e){}setH(h,true)})();
// akun (halaman profil kanan bawah) — terpisah dari profil karakter
const BORDERS=[{n:'Polos',lv:1,rg:'linear-gradient(#f2f0fb,#cfcbe6)'},{n:'Aurora',lv:1,rg:'conic-gradient(#7c5cff,#2de2e6,#ff6bd6,#7c5cff)',sp:1},{n:'Emas',lv:2,rg:'linear-gradient(135deg,#fff3b0,#f0b429,#b8860b)',rs:'0 0 16px #f0b42988'},{n:'Bintang',lv:3,rg:'conic-gradient(#fff,#b9a8ff,#fff,#b9a8ff,#fff)',rs:'0 0 18px #b9a8ff',sp:1},{n:'Neon',lv:5,rg:'conic-gradient(#00f5ff,#2b6cff,#00f5ff)',rs:'0 0 20px #00f5ffaa',sp:1},{n:'Sakura',lv:8,rg:'linear-gradient(135deg,#ffd1e8,#ff7eb6,#ffc2dd)',rs:'0 0 18px #ff7eb688'}];
const ACCDEF=()=>({name:'Pengguna',email:'Belum diisi',border:0,cmt:{hue:null,badge:''},friends:[],photo:null,joined:Date.now()});
const ACC=ACCDEF();try{Object.assign(ACC,JSON.parse(localStorage.getItem('luma-acct')||'{}'))}catch(e){}
const saveAcc=()=>{try{localStorage.setItem('luma-acct',JSON.stringify(ACC))}catch(e){toast('Data akun terlalu besar untuk disimpan')}};
let acctOpen=false;
const avSrc=()=>ACC.photo||'data:image/svg+xml;utf8,'+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#7c5cff"/><stop offset="1" stop-color="#2de2e6"/></linearGradient></defs><rect width="100" height="100" fill="url(#g)"/><text x="50" y="68" font-size="52" text-anchor="middle" fill="#fff" font-family="sans-serif" font-weight="700">${esc((ACC.name.trim()[0]||'?').toUpperCase())}</text></svg>`);
function renderAcct(){const B=BORDERS[ACC.border]||BORDERS[0],ring=$('#ring');$('#aimg').src=avSrc();ring.style.setProperty('--rg',B.rg);ring.style.setProperty('--rs',B.rs||'none');ring.classList.toggle('sp',!!B.sp);$('#anm').textContent=ACC.name;$('#aem').textContent=ACC.email;$('#cf').textContent=ACC.friends.length+' teman';$('#cj').textContent='Bergabung '+new Date(ACC.joined).toLocaleDateString('id-ID',{month:'short',year:'numeric'});document.documentElement.style.setProperty('--me',ACC.cmt.hue==null?'':`hsl(${ACC.cmt.hue} 55% 55%)`)}
function toggleAcct(){acctOpen=!acctOpen;const pg=$('#acct');pg.inert=!acctOpen;pg.classList.toggle('on',acctOpen);pg.setAttribute('aria-hidden',!acctOpen);if(acctOpen){renderAcct();close();closePlayer();$('[data-open="akun"]').classList.add('on')}else{$('[data-open="akun"]').classList.remove('on');$('[data-open="home"]').classList.add('on')}}
function goHome(){closePlayer();if(acctOpen)toggleAcct();close();scrollTo({top:0,behavior:'smooth'})}
function squarePhoto(file,sz){return new Promise((res,rej)=>{const fr=new FileReader();fr.onerror=rej;fr.onload=()=>{const im=new Image();im.onerror=rej;im.onload=()=>{const s=Math.min(im.width,im.height),cv=document.createElement('canvas');cv.width=cv.height=sz;cv.getContext('2d').drawImage(im,(im.width-s)/2,(im.height-s)/2,s,s,0,0,sz,sz);res(cv.toDataURL('image/webp',.85))};im.src=fr.result};fr.readAsDataURL(file)})}
function initEdit(){$('#eph').onclick=()=>$('#efi').click();
$('#efi').onchange=async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;try{ACC.photo=await squarePhoto(f,256);$('#eimg').src=ACC.photo;saveAcc();renderAcct();toast('Foto akun diganti')}catch(er){toast('Foto tidak bisa dibuka')}};
$('#erm').onclick=()=>{ACC.photo=null;$('#eimg').src=avSrc();saveAcc();renderAcct()};
$('#en').oninput=e=>{ACC.name=e.target.value.trim()||'Pengguna';saveAcc();renderAcct()};
$('#ee').oninput=e=>{ACC.email=e.target.value.trim()||'Belum diisi';saveAcc();renderAcct()}}
function initCmt(){const sc=$('#sc'),prev=()=>{$('#cpv').textContent=(ACC.cmt.badge?ACC.cmt.badge+' ':'')+'Halo, ini contoh balasanku!'};prev();
sc.querySelectorAll('[data-ch]').forEach(b=>b.onclick=()=>{ACC.cmt.hue=b.dataset.ch===''?null:+b.dataset.ch;sc.querySelectorAll('[data-ch]').forEach(x=>x.classList.toggle('on',x===b));saveAcc();renderAcct()});
sc.querySelectorAll('[data-cb]').forEach(b=>b.onclick=()=>{ACC.cmt.badge=b.dataset.cb;sc.querySelectorAll('[data-cb]').forEach(x=>x.classList.toggle('on',x===b));saveAcc();prev()})}
function initBorder(){const sc=$('#sc');sc.querySelectorAll('[data-b]').forEach(b=>b.onclick=()=>{ACC.border=+b.dataset.b;sc.querySelectorAll('[data-b]').forEach(x=>x.classList.toggle('on',x===b));saveAcc();renderAcct()})}
function initFriends(){const L=$('#fl2'),draw=()=>{L.innerHTML=ACC.friends.length?ACC.friends.map((n,i)=>`<div class="fr"><span class="fi">🙂</span><div class="tt"><b>${esc(n)}</b><small>Teman</small></div><button class="x" data-i="${i}" aria-label="Hapus teman">✕</button></div>`).join(''):'<p>Belum ada teman.</p>';L.querySelectorAll('.x').forEach(b=>b.onclick=()=>{ACC.friends.splice(+b.dataset.i,1);saveAcc();renderAcct();draw()})},add=()=>{const v=$('#fn').value.trim();if(!v)return;ACC.friends.unshift(v);saveAcc();renderAcct();$('#fn').value='';draw()};$('#fa').onclick=add;$('#fn').onkeydown=e=>e.key==='Enter'&&add();draw()}
document.querySelectorAll('.agrid button').forEach(b=>b.onclick=()=>open(b.dataset.m,true));
$('#alv').onclick=()=>open('a-view');$('#aed').onclick=$('#aimg').onclick=()=>open('a-edit');
addEventListener('keydown',e=>e.key==='Escape'&&acctOpen&&toggleAcct());
renderAcct();
$('#acct').insertAdjacentHTML('afterbegin','<div class="sparkles">'+$('#sp').innerHTML+'</div>');

// satu profil saja; karakter lain sudah dihapus
const CHS={};const saveCH=()=>{};
const pretty=t=>t.length>1&&t===t.toUpperCase()?nice(t):t;
function defPhoto(){return ORIG}
function loadMain(){MAINID='main';Object.assign(PF,DEF(MAINID));
try{Object.assign(PF,JSON.parse(localStorage.getItem(PKEY())||'{}'))}catch(e){}

let ph=null;try{ph=localStorage.getItem(FKEY())}catch(e){}
const h=$('#hero');h.alt=ORIGALT;h.style.animation='none';void h.offsetWidth;h.style.animation='';
setPhoto(ph||defPhoto());applyPF()}
function renderChars(){}
loadMain();

// hitung skor
const SKD=()=>({players:['Pemain 1','Pemain 2','Pemain 3','Pemain 4','Pemain 5'],games:[],cats:[],pend:[0,0,0,0,0],cat:'song',open:-1,edit:-1});
const SK=SKD();
const SKCATS={song:'Song Game',biliar:'Biliar'};
const skOkSong=v=>v===0||(v>=5&&v<=100&&v%5===0)||[-25,-50,-100,-200].includes(v);
const skOkBiliar=v=>v===0||(Number.isInteger(v)&&v>=-50&&v<=100);
const skOk=v=>skOkSong(v)||skOkBiliar(v);
try{const q=JSON.parse(localStorage.getItem('luma-skor')||'null');if(q&&Array.isArray(q.players)&&q.players.length>=5&&q.players.length<=6){SK.players=q.players.map(x=>String(x).slice(0,14));const f=v=>{const n=+v;return skOk(n)?n:0};SK.games=(q.games||[]).map(g=>SK.players.map((_,i)=>f(g[i])));SK.cats=(q.cats||[]).map(c=>c==='biliar'||c==='other'?'biliar':'song');while(SK.cats.length<SK.games.length)SK.cats.push('song');SK.pend=SK.players.map((_,i)=>f((q.pend||[])[i]));if(q.cat==='biliar'||q.cat==='other')SK.cat='biliar'}}catch(e){}
const saveSK=()=>{lsSet('luma-skor',JSON.stringify({players:SK.players,games:SK.games,cats:SK.cats,pend:SK.pend,cat:SK.cat}))};
const skTot=i=>SK.games.reduce((a,g)=>a+g[i],0);
const skF=n=>(n>0?'+':n<0?'−':'')+Math.abs(n);
const skCls=n=>n>0?'pos':n<0?'neg':'';
views.skor=()=>`<h2>Hitung Skor</h2><div id="sk"></div>`;
function skPicker(o,g){
  if(SK.cat==='biliar'){
    const add=[1,2,3,4,5,6,7,8,9,10,15,20,25,50];
    const sub=[1,2,5,10,15,25];
    return `<div class="sk-pk" id="skpk"><div class="lb" style="margin-top:0">Poin biliar untuk <b>${esc(SK.players[o])}</b> · game ke-${g}</div><div class="lb">Tambah (bola / poin)</div><div class="sk-g5">${add.map(v=>`<button class="sk-c ${SK.pend[o]===v?'on':''}" data-v="${v}">+${v}</button>`).join('')}</div><div class="lb">Foul / kurangi</div><div class="sk-g4">${sub.map(v=>`<button class="sk-c m ${SK.pend[o]===-v?'on':''}" data-v="${-v}">−${v}</button>`).join('')}</div><div class="fbar" style="margin:10px 0 0"><button class="fl" data-v="0">Kosongkan</button>${SK.players.length>5?`<button class="fl" data-rm="${o}">Hapus pemain</button>`:''}</div></div>`;
  }
  return `<div class="sk-pk" id="skpk"><div class="lb" style="margin-top:0">Poin song untuk <b>${esc(SK.players[o])}</b> · game ke-${g}</div><div class="sk-g5">${Array.from({length:20},(_,k)=>(k+1)*5).map(v=>`<button class="sk-c ${SK.pend[o]===v?'on':''}" data-v="${v}">+${v}</button>`).join('')}</div><div class="lb">Kurangi</div><div class="sk-g4">${[25,50,100,200].map(v=>`<button class="sk-c m ${SK.pend[o]===-v?'on':''}" data-v="${-v}">−${v}</button>`).join('')}</div><div class="fbar" style="margin:10px 0 0"><button class="fl" data-v="0">Kosongkan</button>${SK.players.length>5?`<button class="fl" data-rm="${o}">Hapus pemain</button>`:''}</div></div>`;
}
function renderSkor(){const n=SK.players.length,g=SK.games.length+1,tot=SK.players.map((_,i)=>skTot(i)),mx=Math.max(...tot),lose=i=>mx>0&&tot[i]===mx;
const catBar=`<div class="tabs" style="margin-bottom:12px"><div class="ind" style="transform:translateX(${SK.cat==='biliar'?'100%':'0'})"></div><button class="${SK.cat==='song'?'on':''}" data-cat="song">Song Game</button><button class="${SK.cat==='biliar'?'on':''}" data-cat="biliar">Biliar</button></div>`;
const cards=SK.players.map((nm,i)=>{const d=SK.pend[i];
return `<div class="sk-p ${SK.open===i?'on':''}" data-r="${i}"><div class="sk-top"><span class="sk-i">${i+1}</span>${SK.edit===i?`<input class="sk-nm" data-nm="${i}" value="${esc(nm)}" maxlength="14" aria-label="Nama pemain ${i+1}">`:`<span class="sk-nm">${esc(nm)}</span><button class="x" data-e="${i}" aria-label="Ubah nama ${esc(nm)}">✎</button>`}</div><b class="sk-t">${tot[i]}</b><div class="sk-bot">${d?`<span class="sk-dd ${skCls(d)}">${skF(d)}</span>`:''}${lose(i)?'<span class="sk-dd lose">Kalah</span>':''}</div></div>`}).join('');
const o=SK.open,pk=o>=0?skPicker(o,g):'';
const ls=SK.players.filter((_,i)=>lose(i));
const hist=SK.games.length?`<div class="lb">Riwayat</div><div class="sk-hs"><table class="sk-tb"><thead><tr><th>#</th><th>Kategori</th>${SK.players.map(p=>`<th>${esc(p)}</th>`).join('')}</tr></thead><tbody>${SK.games.map((r,k)=>`<tr><th>${k+1}</th><td>${esc(SKCATS[SK.cats[k]||'song'])}</td>${r.map(v=>`<td class="${skCls(v)}">${v?skF(v):'–'}</td>`).join('')}</tr>`).join('')}</tbody><tfoot><tr><th colspan="2">Total</th>${tot.map((t,i)=>`<td class="${lose(i)?'neg':''}">${t}</td>`).join('')}</tr></tfoot></table></div>`:'';
$('#sk').innerHTML=`${catBar}<div class="sk-gh"><b>${SKCATS[SK.cat]} ke-${g}</b><span>${ls.length?'Kalah sementara: '+esc(ls.join(', ')):n+' pemain'}</span></div><div class="sk-grid">${cards}</div>${pk}<div class="fbar"><button class="fl on" data-a="save">Simpan ${SKCATS[SK.cat].toLowerCase()} ${g}</button><button class="fl" data-a="clr">Kosongkan game ini</button></div><div class="fbar"><button class="fl" data-a="add" ${n>=6?'disabled':''}>+ Pemain</button><button class="fl" data-a="undo" ${SK.games.length?'':'disabled'}>Batalkan game terakhir</button><button class="fl" data-a="reset" id="skrs">Mulai ulang</button></div>${hist}`;
if(o>=0){const e=$('#skpk');e&&e.scrollIntoView({block:'nearest',behavior:'smooth'})}}
let skT=0;
function initSkor(){const box=$('#sk');
box.oninput=e=>{const t=e.target;if(t.dataset.nm!==undefined){SK.players[+t.dataset.nm]=t.value.slice(0,14)||'Pemain '+(+t.dataset.nm+1);saveSK()}};
box.addEventListener('focusout',e=>{const t=e.target;if(t.dataset&&t.dataset.nm!==undefined){SK.edit=-1;const sp=document.createElement('span');sp.className='sk-nm';sp.textContent=t.value.trim().slice(0,14)||SK.players[+t.dataset.nm];t.replaceWith(sp)}});box.onkeydown=e=>{if(e.key==='Enter'&&e.target.dataset.nm!==undefined)e.target.blur()};
box.onclick=e=>{if(e.target.tagName==='INPUT')return;const t=e.target.closest('[data-v],[data-a],[data-rm],[data-r],[data-e],[data-cat]');if(!t)return;const d=t.dataset;if(d.e!==undefined){SK.edit=+d.e;renderSkor();const q=box.querySelector('[data-nm]');if(q){q.focus();q.select()}return}SK.edit=-1;
if(d.cat!==undefined){SK.cat=d.cat;SK.open=-1;SK.pend=SK.players.map(()=>0);saveSK()}
else if(d.v!==undefined){const v=+d.v;const ok=SK.cat==='biliar'?skOkBiliar(v):skOkSong(v);if(!ok&&v!==0){toast('Poin tidak valid untuk mode ini');return}SK.pend[SK.open]=v;SK.open=-1;saveSK()}
else if(d.rm!==undefined){const i=+d.rm;if(SK.players.length>5){SK.players.splice(i,1);SK.games.forEach(r=>r.splice(i,1));SK.pend.splice(i,1);SK.open=-1;saveSK()}}
else if(d.a==='save'){if(!SK.pend.some(v=>v)){toast('Isi poin minimal satu pemain');return}SK.games.push(SK.pend.slice());SK.cats.push(SK.cat);SK.pend=SK.players.map(()=>0);SK.open=-1;saveSK();toast((SKCATS[SK.cat]||'Game')+' '+SK.games.length+' disimpan')}
else if(d.a==='clr'){SK.pend=SK.players.map(()=>0);SK.open=-1;saveSK()}
else if(d.a==='add'){if(SK.players.length<6){SK.players.push('Pemain '+(SK.players.length+1));SK.games.forEach(r=>r.push(0));SK.pend.push(0);saveSK()}}
else if(d.a==='undo'){if(SK.games.length){SK.games.pop();SK.cats.pop();saveSK();toast('Game terakhir dibatalkan')}}
else if(d.a==='reset'){if(!skT){t.textContent='Yakin? Ketuk lagi';skT=setTimeout(()=>{skT=0;const b=$('#skrs');if(b)b.textContent='Mulai ulang'},3000);return}clearTimeout(skT);skT=0;Object.assign(SK,SKD());saveSK();toast('Skor dimulai ulang')}
else if(d.r!==undefined){SK.open=SK.open===+d.r?-1:+d.r}
renderSkor()};
renderSkor()}


/* ===== Alat harian: catatan, tugas, cuaca, konversi, fokus, musik favorit ===== */
views.catatan=()=>`<h2>Catatan</h2><p style="color:var(--mute);font-size:14px;margin:0 0 10px">Memo cepat, tersimpan di perangkat ini.</p><div id="notes"></div><div class="fbar"><button class="fl on" id="nadd">+ Catatan baru</button></div>`;
const NKEY='luma-notes';
const getNotes=()=>{try{const a=JSON.parse(localStorage.getItem(NKEY)||'[]');return Array.isArray(a)?a:[]}catch(e){return []}};
const saveNotes=a=>{lsSet(NKEY,JSON.stringify(a))};
function renderNotes(){
  const a=getNotes();
  const box=$('#notes');
  if(!a.length){box.innerHTML='<div class="vempty"><div class="vic">📝</div><p>Belum ada catatan. Tulis ide atau pengingat singkat.</p></div>';return}
  box.innerHTML=a.map((n,i)=>`<div class="note" data-i="${i}"><textarea maxlength="2000" aria-label="Catatan">${esc(n.t||'')}</textarea><div class="meta"><span>${esc(n.d||'')}</span><button class="x" data-del="${i}" aria-label="Hapus">✕</button></div></div>`).join('');
}
function initNotes(){
  renderNotes();
  $('#nadd').onclick=()=>{const a=getNotes();a.unshift({t:'',d:new Date().toLocaleString('id-ID',{dateStyle:'medium',timeStyle:'short'})});saveNotes(a);renderNotes();const ta=$('#notes textarea');if(ta)ta.focus()};
  $('#notes').oninput=e=>{const ta=e.target.closest('textarea');if(!ta)return;const i=+ta.closest('.note').dataset.i;const a=getNotes();if(a[i]){a[i].t=ta.value.slice(0,2000);saveNotes(a)}};
  $('#notes').onclick=e=>{const b=e.target.closest('[data-del]');if(!b)return;const a=getNotes();a.splice(+b.dataset.del,1);saveNotes(a);renderNotes();toast('Catatan dihapus')};
}

views.tugas=()=>`<h2>Tugas</h2><p style="color:var(--mute);font-size:14px;margin:0 0 10px">Checklist harian di perangkat ini.</p><div class="cin" style="margin:0 0 12px"><input class="inp" id="ti" placeholder="Tambah tugas…" maxlength="120" aria-label="Tugas baru"><button class="fl on" id="tadd">Tambah</button></div><div id="todos"></div><div class="fbar"><button class="fl" id="tclr">Hapus yang selesai</button></div>`;
const TKEY='luma-todo';
const getTodos=()=>{try{const a=JSON.parse(localStorage.getItem(TKEY)||'[]');return Array.isArray(a)?a:[]}catch(e){return []}};
const saveTodos=a=>{lsSet(TKEY,JSON.stringify(a))};
function renderTodos(){
  const a=getTodos();
  const box=$('#todos');
  if(!a.length){box.innerHTML='<div class="vempty"><div class="vic">✅</div><p>Tidak ada tugas. Tambah yang perlu dikerjakan hari ini.</p></div>';return}
  box.innerHTML=a.map((t,i)=>`<div class="todo-item ${t.done?'done':''}" data-i="${i}"><input type="checkbox" ${t.done?'checked':''} aria-label="Selesai"><span>${esc(t.t)}</span><button class="x" data-del="${i}" aria-label="Hapus">✕</button></div>`).join('');
}
function initTodo(){
  renderTodos();
  const add=()=>{const v=($('#ti').value||'').trim();if(!v)return;$('#ti').value='';const a=getTodos();a.unshift({t:v.slice(0,120),done:false});saveTodos(a);renderTodos()};
  $('#tadd').onclick=add;
  $('#ti').onkeydown=e=>{if(e.key==='Enter')add()};
  $('#tclr').onclick=()=>{saveTodos(getTodos().filter(t=>!t.done));renderTodos();toast('Tugas selesai dihapus')};
  $('#todos').onclick=e=>{
    const item=e.target.closest('.todo-item');if(!item)return;const i=+item.dataset.i;const a=getTodos();
    if(e.target.closest('[data-del]')){a.splice(i,1);saveTodos(a);renderTodos();return}
    if(e.target.type==='checkbox'){a[i].done=!!e.target.checked;saveTodos(a);renderTodos()}
  };
}

const WXCODE={0:'Cerah',1:'Cerah berawan',2:'Berawan sebagian',3:'Mendung',45:'Berkabut',48:'Kabut beku',51:'Gerimis ringan',53:'Gerimis',55:'Gerimis lebat',56:'Gerimis beku',57:'Gerimis beku lebat',61:'Hujan ringan',63:'Hujan',65:'Hujan lebat',66:'Hujan beku',67:'Hujan beku lebat',71:'Salju ringan',73:'Salju',75:'Salju lebat',77:'Butiran salju',80:'Hujan lokal',81:'Hujan sedang',82:'Hujan deras',85:'Salju lokal',86:'Salju lokal lebat',95:'Badai petir',96:'Badai + hujan es',99:'Badai kuat + hujan es'};
views.cuaca=()=>`<h2>Cuaca</h2><div id="wx"><div class="vempty"><div class="vic">⛅</div><p>Memuat cuaca…</p></div></div><div class="fbar"><button class="fl on" id="wxgo">Perbarui lokasi</button></div>`;
function renderWx(d,place){
  const c=d.current||{};
  const code=c.weather_code;
  $('#wx').innerHTML=`<div class="wx"><div class="temp">${Math.round(c.temperature_2m)}°</div><div class="desc">${esc(WXCODE[code]||'Kondisi tidak diketahui')} · ${esc(place||'Lokasi saat ini')}</div><div class="grid"><div><span>Kelembapan</span><b>${c.relative_humidity_2m ?? '–'}%</b></div><div><span>Angin</span><b>${c.wind_speed_10m ?? '–'} km/j</b></div><div><span>Terasa</span><b>${c.apparent_temperature!=null?Math.round(c.apparent_temperature)+'°':'–'}</b></div><div><span>Min / Maks hari ini</span><b>${d.daily&&d.daily.temperature_2m_min?Math.round(d.daily.temperature_2m_min[0])+'° / '+Math.round(d.daily.temperature_2m_max[0])+'°':'–'}</b></div></div></div>`;
}
async function fetchWx(lat,lon,place){
  const url=`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min&timezone=auto`;
  const r=await fetch(url);if(!r.ok)throw new Error('gagal');const d=await r.json();renderWx(d,place);
}
function initWeather(){
  const run=()=>{
    $('#wx').innerHTML='<div class="vempty"><div class="vic">⛅</div><p>Memuat cuaca…</p></div>';
    if(!navigator.geolocation){$('#wx').innerHTML='<div class="vempty"><p>Geolokasi tidak tersedia di browser ini.</p></div>';return}
    navigator.geolocation.getCurrentPosition(async pos=>{
      try{
        const {latitude:lat,longitude:lon}=pos.coords;
        const place='Lokasi saat ini';
        await fetchWx(lat,lon,place);
      }catch(e){$('#wx').innerHTML='<div class="vempty"><p>Gagal memuat cuaca. Cek koneksi internet.</p></div>'}
    },()=>{$('#wx').innerHTML='<div class="vempty"><p>Izin lokasi ditolak. Aktifkan lokasi untuk melihat cuaca.</p></div>'},{enableHighAccuracy:false,timeout:12000});
  };
  $('#wxgo').onclick=run;run();
}

views.konversi=()=>`<h2>Konversi satuan</h2>
<div class="lb">Kategori</div>
<div class="tabs cv4" id="cvtabs" style="margin-bottom:12px"><div class="ind" id="cvind"></div>
<button class="on" data-k="suhu">Suhu</button><button data-k="panjang">Panjang</button><button data-k="waktu">Waktu</button><button data-k="berat">Berat</button></div>
<div class="cv-row"><div><label>Dari</label><input class="inp" id="cvin" type="number" step="any" value="1"><select id="cvfrom"></select></div>
<div class="cv-eq">=</div>
<div><label>Ke</label><input class="inp" id="cvout" type="number" step="any" readonly><select id="cvto"></select></div></div>
<p id="cvhint" style="color:var(--mute);font-size:13px;margin:0"></p>`;
const CV={
  suhu:{u:{C:'°C',F:'°F',K:'K'},toBase:(v,u)=>u==='C'?v:u==='F'?(v-32)*5/9:v-273.15,fromBase:(v,u)=>u==='C'?v:u==='F'?v*9/5+32:v+273.15,hint:'Air membeku 0°C / 32°F'},
  panjang:{u:{m:'meter',km:'km',cm:'cm',mi:'mil',ft:'kaki'},toBase:(v,u)=>({m:1,km:1000,cm:0.01,mi:1609.344,ft:0.3048})[u]*v,fromBase:(v,u)=>v/({m:1,km:1000,cm:0.01,mi:1609.344,ft:0.3048})[u],hint:'1 mil ≈ 1,609 m'},
  waktu:{u:{s:'detik',min:'menit',h:'jam',d:'hari'},toBase:(v,u)=>({s:1,min:60,h:3600,d:86400})[u]*v,fromBase:(v,u)=>v/({s:1,min:60,h:3600,d:86400})[u],hint:'1 hari = 24 jam'},
  berat:{u:{g:'gram',kg:'kg',lb:'pon',oz:'ons'},toBase:(v,u)=>({g:1,kg:1000,lb:453.59237,oz:28.3495})[u]*v,fromBase:(v,u)=>v/({g:1,kg:1000,lb:453.59237,oz:28.3495})[u],hint:'1 kg ≈ 2,205 pon'}
};
let cvK='suhu';
function fillCv(){
  const c=CV[cvK],keys=Object.keys(c.u);
  const opts=keys.map(k=>`<option value="${k}">${c.u[k]}</option>`).join('');
  $('#cvfrom').innerHTML=opts;$('#cvto').innerHTML=opts;
  $('#cvto').value=keys[1]||keys[0];
  $('#cvhint').textContent=c.hint||'';
  runCv();
}
function runCv(){
  const c=CV[cvK];let v=parseFloat($('#cvin').value);if(!isFinite(v)){$('#cvout').value='';return}
  const b=c.toBase(v,$('#cvfrom').value);$('#cvout').value=String(Math.round(c.fromBase(b,$('#cvto').value)*1000)/1000);
}
function initConv(){
  fillCv();
  const tabs=$('#cvtabs');
  const ind=$('#cvind');
  const btns=[...tabs.querySelectorAll('button')];
  const setInd=()=>{const i=btns.findIndex(b=>b.classList.contains('on'));ind.style.width=`calc((100% - 8px)/${btns.length})`;ind.style.transform=`translateX(${i*100}%)`};
  setInd();
  tabs.onclick=e=>{const b=e.target.closest('button[data-k]');if(!b)return;btns.forEach(x=>x.classList.toggle('on',x===b));cvK=b.dataset.k;fillCv();setInd()};
  $('#cvin').oninput=runCv;$('#cvfrom').onchange=runCv;$('#cvto').onchange=runCv;
}

/* Mode fokus */
let fxLeft=25*60,fxTotal=25*60,fxTimer=null,fxRun=false,fxEnd=0;
function paintFocus(){
  const m=Math.floor(fxLeft/60),s=fxLeft%60;
  const el=$('#fxtime');if(el)el.textContent=String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');
  const go=$('#fxgo');if(go)go.textContent=fxRun?'Jeda':(fxLeft<fxTotal&&fxLeft>0?'Lanjut':'Mulai');
  const mu=$('#fxmus');if(mu){const o=$('#fxmp');mu.classList.toggle('on',!!(o&&!o.hidden))}
}
function fxClock(){fxLeft=Math.max(0,Math.ceil((fxEnd-Date.now())/1000))}
function tickFocus(){
  fxClock();paintFocus();
  if(fxLeft<=0){clearInterval(fxTimer);fxTimer=null;fxRun=false;paintFocus();toast('Waktu fokus selesai');navigator.vibrate&&navigator.vibrate([200,100,200]);try{const a=new (window.AudioContext||window.webkitAudioContext)();a.resume&&a.resume();const o=a.createOscillator();const g=a.createGain();o.connect(g);g.connect(a.destination);o.frequency.value=880;g.gain.value=0.05;o.start();g.gain.exponentialRampToValueAtTime(0.001,a.currentTime+0.8);o.stop(a.currentTime+0.8);setTimeout(()=>a.close&&a.close(),1200)}catch(e){}}
}
document.addEventListener('visibilitychange',()=>{if(fxRun&&!document.hidden)tickFocus()});
function enterFocus(){
  const f=$('#focus');if(!f)return;fxOpenAt=Date.now();f.hidden=false;document.body.classList.add('focus-on');
  paintFocus();
  $('#fxclose').onclick=exitFocus;
  $('#fxgo').onclick=()=>{
    if(fxRun){fxClock();clearInterval(fxTimer);fxTimer=null;fxRun=false;paintFocus();return}
    if(fxLeft<=0)fxLeft=fxTotal;
    fxEnd=Date.now()+fxLeft*1000;fxRun=true;paintFocus();fxTimer=setInterval(tickFocus,500);
  };
  $('#fxmus').onclick=()=>{const p=$('#fxmp');p.hidden=!p.hidden;paintFocus()};
  $('#fxpre').onclick=e=>{const b=e.target.closest('button[data-m]');if(!b)return;[...$('#fxpre').children].forEach(x=>x.classList.toggle('on',x===b));const mins=+b.dataset.m;fxTotal=mins*60;fxLeft=fxTotal;clearInterval(fxTimer);fxTimer=null;fxRun=false;paintFocus()};
}
/* keluar fokus: ketuk di mana saja (kecuali tombol Mulai/Musik/durasi), atau tekan Esc */
let fxOpenAt=0;
(function(){const f=$('#focus');if(!f)return;
f.addEventListener('click',e=>{if(!document.body.classList.contains('focus-on'))return;if(Date.now()-fxOpenAt<500)return;if((e.composedPath?e.composedPath():[e.target]).some(n=>n&&n.matches&&n.matches('button,.focus-music,input')))return;exitFocus()});
addEventListener('keydown',e=>{if(e.key==='Escape'&&document.body.classList.contains('focus-on'))exitFocus()})})();
function exitFocus(){
  clearInterval(fxTimer);fxTimer=null;fxRun=false;fxLeft=fxTotal;
  const f=$('#focus');if(f)f.hidden=true;document.body.classList.remove('focus-on');
}

/* restore last music + favorit filter hint on boot */
(function restoreMusic(){
  try{
    const m=getMus();
    if(typeof vol==='number'&&m.vol!=null){vol=+m.vol;if(au)au.volume=vol}
    if(m.last){const i=tracks.findIndex(t=>t.id===m.last);if(i>=0&&typeof load==='function'){/* defer until load exists */ setTimeout(()=>{try{load(i,false)}catch(e){}},0)}}
  }catch(e){}
})();


/* Google Programmable Search via backend */
const SKEY='luma-search-api';
function searchBase(){
  let v='';try{v=(localStorage.getItem(SKEY)||'').trim()}catch(e){}
  if(v)return v.replace(/\/+$/,'');
  const h=location.hostname;
  // halaman dibuka dari PC/LAN (mis. 192.168.x.x): backend diasumsikan di mesin yang sama
  if(location.protocol==='http:'&&h&&h!=='localhost'&&h!=='127.0.0.1')return 'http://'+h+':8787';
  return 'http://127.0.0.1:8787';
}
const safeUrl=u=>/^https?:\/\//i.test(u||'')?u:'#';
function mixedBlocked(base){return location.protocol==='https:'&&/^http:\/\//i.test(base)&&!/^http:\/\/(localhost|127\.0\.0\.1)/i.test(base)}
function renderSearchResults(data){
  const box=$('#res'), meta=$('#qmeta');
  if(!box)return;
  if(data.error){
    const msg=data.message||data.error;
    box.innerHTML=`<div class="vempty"><div class="vic">🔌</div><p>${esc(msg)}</p><p style="font-size:12px;color:var(--mute)">${data.direct?'Cek API key dan CX Google di ikon kunci pada chat.':'Cek alamat server di bawah dan pastikan backend jalan: <code>cd backend && python3 server.py</code>'}</p></div>`;
    if(meta)meta.textContent='';
    return;
  }
  const items=data.items||[];
  if(!items.length){
    box.innerHTML='<div class="vempty"><div class="vic">🔎</div><p>Tidak ada hasil untuk pencarian ini.</p></div>';
    if(meta)meta.textContent='';
    return;
  }
  box.innerHTML=items.map(it=>`<a class="sres" href="${esc(safeUrl(it.link))}" target="_blank" rel="noopener noreferrer"><b>${esc(it.title)}</b><small>${esc(it.displayLink||'')}</small><span>${esc(it.snippet||'')}</span></a>`).join('');
  if(meta)meta.textContent=(data.count||items.length)+' hasil'+(data.searchTime?' · '+data.searchTime+'s':'')+(data.cached?' · dari cache':'');
}
let searching=false;
async function doSearch(){
  const q=($('#q')&&$('#q').value||'').trim();
  if(!q){toast('Ketik kata kunci dulu');return}
  if(searching)return;
  const box=$('#res'),base=searchBase(),G=lkGet().gs,direct=!!(G.key&&G.cx);
  if(!direct&&mixedBlocked(base)){renderSearchResults({error:'mixed',message:'Halaman ini HTTPS tapi server pencarian HTTP, jadi diblokir browser. Pakai server HTTPS atau buka LUMA lewat http:// di jaringan lokal.'});return}
  searching=true;
  if(box)box.innerHTML='<div class="vempty"><div class="vic">⏳</div><p>Mencari…</p></div>';
  const ac=new AbortController(),to=setTimeout(()=>ac.abort(),15000);
  try{
    if(direct){renderSearchResults(await searchDirect(q,ac.signal));return}
    const r=await fetch(base+'/api/search?q='+encodeURIComponent(q),{signal:ac.signal,headers:authH()});
    const data=await r.json().catch(()=>({error:'bad_json',message:'Respons tidak valid'}));
    if(!r.ok&&!data.error)data.error='http_'+r.status;
    renderSearchResults(data);
  }catch(e){
    renderSearchResults({error:'network',direct:direct,message:e&&e.name==='AbortError'?(direct?'Google Search tidak menjawab (waktu habis).':'Server pencarian tidak menjawab (waktu habis).'):(direct?'Tidak bisa menghubungi Google Search.':'Tidak terhubung ke server pencarian di '+base+'.')});
  }finally{clearTimeout(to);searching=false}
}
function initCari(){
  const go=$('#qgo'), q=$('#q');
  if(go)go.onclick=()=>doSearch();
  if(q){q.onkeydown=e=>{if(e.key==='Enter')doSearch()};q.focus()}
  const box=$('#res');
  if(box)box.innerHTML='<div class="vempty"><div class="vic">🔎</div><p>Ketik kata kunci lalu ketuk Cari. Hasil muncul di dalam LUMA.</p></div>';
  const sv=$('#qsv'),si=$('#qsrv');
  if(si)si.value=searchBase();
  if(sv)sv.onclick=()=>{const v=(si.value||'').trim().replace(/\/+$/,'');if(v&&!/^https?:\/\/[^\s]+$/i.test(v)){toast('Alamat harus diawali http:// atau https://');return}try{if(v)localStorage.setItem(SKEY,v);else localStorage.removeItem(SKEY)}catch(e){}toast(v?'Alamat server disimpan':'Alamat server direset');si.value=searchBase()};
}



// ===== Belajar & Game (tombol di bawah tombol musik) =====
const LGK='luma-lg';
const LGD={bestQuiz:{},bestMem:0,bestGuess:0,bestTap:0,cards:[{f:'Fotosintesis',b:'Proses tumbuhan membuat makanan dari cahaya matahari',k:0},{f:'Ibu kota Jepang',b:'Tokyo',k:0},{f:'7 × 8',b:'56',k:0}]};
const lg=()=>{const o=jget(LGK,LGD);if(!Array.isArray(o.cards))o.cards=LGD.cards.slice();if(!o.bestQuiz||typeof o.bestQuiz!=='object')o.bestQuiz={};return o};
const lgSave=o=>jset(LGK,o);
const lgR=n=>Math.floor(Math.random()*n);
const lgShuf=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=lgR(i+1);[a[i],a[j]]=[a[j],a[i]]}return a};
let lgTimer=0;const lgClear=()=>{clearTimeout(lgTimer);clearInterval(lgTimer)};
const LG_VOC=[['apple','apel'],['book','buku'],['water','air'],['house','rumah'],['friend','teman'],['school','sekolah'],['cat','kucing'],['dog','anjing'],['sun','matahari'],['moon','bulan'],['tree','pohon'],['food','makanan'],['car','mobil'],['happy','senang'],['big','besar'],['small','kecil'],['read','membaca'],['write','menulis'],['eat','makan'],['sleep','tidur']];
const LG_UM=[['Ibu kota Indonesia?','Jakarta',['Bandung','Surabaya','Medan']],['Planet terdekat dari Matahari?','Merkurius',['Venus','Mars','Bumi']],['Hewan terbesar di dunia?','Paus biru',['Gajah','Jerapah','Hiu paus']],['Gas yang kita hirup untuk bernapas?','Oksigen',['Nitrogen','Hidrogen','Karbon dioksida']],['Jumlah provinsi di Pulau Jawa (termasuk DKI & DIY)?','6',['4','5','7']],['Proklamasi kemerdekaan Indonesia tahun?','1945',['1942','1949','1950']],['Samudra terluas di dunia?','Pasifik',['Atlantik','Hindia','Arktik']],['Lambang kimia air?','H2O',['CO2','O2','NaCl']],['Benua terkecil?','Australia',['Eropa','Antartika','Amerika Selatan']],['Gunung tertinggi di dunia?','Everest',['K2','Kilimanjaro','Semeru']],['Alat untuk mengukur suhu?','Termometer',['Barometer','Higrometer','Amperemeter']],['Hasil dari 12 × 12?','144',['124','136','148']]];
const LG_EMO=['🐱','🐶','🦊','🐼','🐸','🦋','🌸','⭐'];
views.belajar=()=>`<h2>Belajar</h2><div id="lr"></div>`;
views.game=()=>`<h2>Game</h2><div id="gm"></div>`;
const lgBack=(a)=>`<button type="button" class="x" data-a="${a||'menu'}" style="padding:4px 0">‹ Kembali</button>`;

/* ---------- Belajar ---------- */
const LQ={};
function lrMakeQ(cat){
  if(cat==='mat'){const t=lgR(3);let a,b,r,s;
    if(t===0){a=2+lgR(98);b=2+lgR(98);r=a+b;s=a+' + '+b}
    else if(t===1){a=20+lgR(80);b=2+lgR(a-2);r=a-b;s=a+' − '+b}
    else{a=2+lgR(11);b=2+lgR(11);r=a*b;s=a+' × '+b}
    const set=new Set([r]);while(set.size<4){const d=(1+lgR(10))*(lgR(2)?1:-1);const v=r+d;if(v>=0)set.add(v)}
    return{q:'Berapa '+s+' ?',a:String(r),o:lgShuf([...set].map(String))}}
  if(cat==='kosa'){const p=LG_VOC[lgR(LG_VOC.length)];const o=new Set([p[1]]);while(o.size<4)o.add(LG_VOC[lgR(LG_VOC.length)][1]);
    return{q:'Apa arti “'+p[0]+'”?',a:p[1],o:lgShuf([...o])}}
  const p=LG_UM[lgR(LG_UM.length)];return{q:p[0],a:p[1],o:lgShuf([p[1],...p[2]])}}
const LR_CATS={mat:'Matematika',kosa:'Kosakata Inggris',umum:'Pengetahuan Umum'};
function lrRender(){const box=$('#lr');if(!box)return;const d=lg();
  if(LQ.v==='quiz'){
    if(LQ.i>=10){const best=d.bestQuiz[LQ.cat]||0;const nb=LQ.score>best;if(nb){d.bestQuiz[LQ.cat]=LQ.score;lgSave(d)}
      box.innerHTML=lgBack()+`<div class="lg-res"><div>${LR_CATS[LQ.cat]}</div><div class="big">${LQ.score}/10</div><p>${LQ.score>=8?'Keren sekali! 🎉':LQ.score>=5?'Bagus, terus berlatih 👍':'Ayo coba lagi, pasti bisa 💪'}</p>${nb?'<p><b>Rekor baru!</b></p>':''}<div class="lg-row"><button type="button" class="fl on" data-a="quiz" data-c="${LQ.cat}">Main lagi</button></div></div>`;return}
    const q=LQ.q;box.innerHTML=lgBack()+`<div class="lg-top"><span>${LR_CATS[LQ.cat]}</span><span>Soal ${LQ.i+1}/10 · Skor ${LQ.score}</span></div><div class="lg-q">${esc(q.q)}</div><div class="lg-opts">${q.o.map(o=>`<button type="button" data-a="ans" data-v="${esc(o)}">${esc(o)}</button>`).join('')}</div>`;return}
  if(LQ.v==='cards'){const cs=d.cards;
    if(!cs.length){box.innerHTML=lgBack()+`<div class="vempty"><div class="vic">🗂️</div><p>Belum ada kartu. Tambahkan di bawah.</p></div>`+lrAddForm();return}
    LQ.ci=Math.min(LQ.ci||0,cs.length-1);const c=cs[LQ.ci];const known=cs.filter(x=>x.k).length;
    box.innerHTML=lgBack()+`<div class="lg-top"><span>Kartu ${LQ.ci+1}/${cs.length}</span><span>Hafal ${known}</span></div><div class="lg-card" data-a="flip">${LQ.flip?esc(c.b)+'<small>Jawaban</small>':esc(c.f)+'<small>Ketuk untuk membalik</small>'}</div><div class="lg-row"><button type="button" class="fl" data-a="cprev">‹</button><button type="button" class="fl" data-a="cno">Belum hafal</button><button type="button" class="fl on" data-a="cyes">Hafal ✓</button><button type="button" class="fl" data-a="cnext">›</button></div><div class="lg-row"><button type="button" class="fl" data-a="cshuf">Acak</button><button type="button" class="fl" data-a="cdel">Hapus kartu</button></div>`+lrAddForm();return}
  const b=d.bestQuiz;
  box.innerHTML=`<p style="color:var(--mute);font-size:14px;margin:0">Pilih cara belajar.</p><div class="lg-menu">`+
  Object.keys(LR_CATS).map(k=>`<button type="button" data-a="quiz" data-c="${k}"><div class="em">${k==='mat'?'➗':k==='kosa'?'🔤':'🌏'}</div><div><b>Kuis ${LR_CATS[k]}</b><span>10 soal pilihan ganda${b[k]?' · rekor '+b[k]+'/10':''}</span></div></button>`).join('')+
  `<button type="button" data-a="cards"><div class="em">🗂️</div><div><b>Kartu Hafalan</b><span>${d.cards.length} kartu · buat sendiri</span></div></button></div>`}
const lrAddForm=()=>`<div class="lb">Tambah kartu</div><input class="inp" id="cf" placeholder="Depan (pertanyaan)" maxlength="120" style="width:100%;margin-bottom:6px"><input class="inp" id="cb" placeholder="Belakang (jawaban)" maxlength="200" style="width:100%"><div class="lg-row"><button type="button" class="fl on" data-a="cadd">Simpan kartu</button></div>`;
function initLearn(){lgClear();LQ.v='menu';lrRender();const box=$('#lr');
  box.onclick=e=>{const t=e.target.closest('[data-a]');if(!t)return;const a=t.dataset.a,d=lg();
    if(a==='menu'){LQ.v='menu';return lrRender()}
    if(a==='quiz'){LQ.v='quiz';LQ.cat=t.dataset.c;LQ.i=0;LQ.score=0;LQ.lock=false;LQ.q=lrMakeQ(LQ.cat);return lrRender()}
    if(a==='ans'){if(LQ.lock)return;LQ.lock=true;const ok=t.dataset.v===LQ.q.a;if(ok)LQ.score++;
      box.querySelectorAll('.lg-opts button').forEach(b=>{if(b.dataset.v===LQ.q.a)b.classList.add('ok');else if(b===t)b.classList.add('bad')});
      lgTimer=setTimeout(()=>{if(!$('#lr'))return;LQ.i++;LQ.lock=false;if(LQ.i<10)LQ.q=lrMakeQ(LQ.cat);lrRender()},ok?600:1100);return}
    if(a==='cards'){LQ.v='cards';LQ.ci=0;LQ.flip=false;return lrRender()}
    if(a==='flip'){LQ.flip=!LQ.flip;return lrRender()}
    if(a==='cnext'||a==='cprev'){const n=d.cards.length;LQ.ci=(LQ.ci+(a==='cnext'?1:n-1))%n;LQ.flip=false;return lrRender()}
    if(a==='cyes'||a==='cno'){const c=d.cards[LQ.ci];if(c){c.k=a==='cyes'?1:0;lgSave(d);LQ.ci=(LQ.ci+1)%d.cards.length;LQ.flip=false}return lrRender()}
    if(a==='cshuf'){d.cards=lgShuf(d.cards);lgSave(d);LQ.ci=0;LQ.flip=false;return lrRender()}
    if(a==='cdel'){d.cards.splice(LQ.ci,1);lgSave(d);LQ.flip=false;toast('Kartu dihapus');return lrRender()}
    if(a==='cadd'){const f=$('#cf').value.trim(),b=$('#cb').value.trim();if(!f||!b)return toast('Isi sisi depan dan belakang');if(d.cards.length>=200)return toast('Maksimal 200 kartu');d.cards.push({f:f.slice(0,120),b:b.slice(0,200),k:0});lgSave(d);LQ.ci=d.cards.length-1;LQ.flip=false;toast('Kartu disimpan');lrRender()}}}

/* ---------- Game ---------- */
const GM={};
function gmRender(){const box=$('#gm');if(!box)return;const d=lg();
  if(GM.v==='mem'){
    box.innerHTML=lgBack()+`<div class="lg-top"><span>Cocokkan pasangan</span><span>Langkah ${GM.moves}${d.bestMem?' · rekor '+d.bestMem:''}</span></div><div class="lg-mem">${GM.cards.map((c,i)=>`<button type="button" data-a="flipm" data-i="${i}" class="${GM.done[i]?'done':GM.up.includes(i)?'up':''}">${GM.done[i]||GM.up.includes(i)?c:'❔'}</button>`).join('')}</div>`+(GM.done.every(Boolean)?`<div class="lg-res"><div class="big">🎉</div><p>Selesai dalam ${GM.moves} langkah${GM.nb?' — rekor baru!':''}</p><button type="button" class="fl on" data-a="mem">Main lagi</button></div>`:'');return}
  if(GM.v==='guess'){
    box.innerHTML=lgBack()+`<div class="lg-top"><span>Tebak angka 1–100</span><span>Tebakan ${GM.n}${d.bestGuess?' · rekor '+d.bestGuess:''}</span></div><div class="lg-hint" id="gh">${GM.msg||'Aku sudah memilih satu angka…'}</div>${GM.won?`<div class="lg-row"><button type="button" class="fl on" data-a="guess">Main lagi</button></div>`:`<div class="lg-row"><input class="inp" id="gi" type="number" inputmode="numeric" min="1" max="100" placeholder="Angka" style="flex:2"><button type="button" class="fl on" data-a="gtry">Tebak</button></div>`}`;
    const i=$('#gi');if(i){i.onkeydown=e=>{if(e.key==='Enter')$('#gm [data-a=gtry]').click()}}return}
  if(GM.v==='tap'){
    box.innerHTML=lgBack()+`<div class="lg-top"><span>Ketuk secepat mungkin!</span><span>Rekor ${d.bestTap||0}</span></div><div class="lg-hint" id="gt">${GM.state==='run'?'Sisa '+GM.left+' detik':GM.state==='end'?'Waktu habis! '+GM.cnt+' ketukan'+(GM.nb?' — rekor baru! 🎉':''):'Ketuk tombol untuk mulai (10 detik)'}</div><button type="button" class="lg-tap" data-a="tap">${GM.state==='run'?GM.cnt:GM.state==='end'?'Main lagi':'MULAI'}</button>`;return}
  box.innerHTML=`<p style="color:var(--mute);font-size:14px;margin:0">Istirahat sebentar, main yuk.</p><div class="lg-menu"><button type="button" data-a="mem"><div class="em">🃏</div><div><b>Kartu Memori</b><span>Cocokkan 8 pasang${d.bestMem?' · rekor '+d.bestMem+' langkah':''}</span></div></button><button type="button" data-a="guess"><div class="em">🎯</div><div><b>Tebak Angka</b><span>Cari angka rahasia 1–100${d.bestGuess?' · rekor '+d.bestGuess+' tebakan':''}</span></div></button><button type="button" data-a="tapg"><div class="em">⚡</div><div><b>Tap Cepat</b><span>Berapa ketukan dalam 10 detik?${d.bestTap?' · rekor '+d.bestTap:''}</span></div></button></div>`}
function initGame(){lgClear();GM.v='menu';gmRender();const box=$('#gm');
  box.onclick=e=>{const t=e.target.closest('[data-a]');if(!t)return;const a=t.dataset.a,d=lg();
    if(a==='menu'){lgClear();GM.v='menu';return gmRender()}
    if(a==='mem'){lgClear();GM.v='mem';GM.cards=lgShuf([...LG_EMO,...LG_EMO]);GM.done=GM.cards.map(()=>false);GM.up=[];GM.moves=0;GM.nb=false;return gmRender()}
    if(a==='flipm'){const i=+t.dataset.i;if(GM.up.length>=2||GM.up.includes(i)||GM.done[i])return;GM.up.push(i);
      if(GM.up.length===2){GM.moves++;const[x,y]=GM.up;
        if(GM.cards[x]===GM.cards[y]){GM.done[x]=GM.done[y]=true;GM.up=[];if(GM.done.every(Boolean)){if(!d.bestMem||GM.moves<d.bestMem){d.bestMem=GM.moves;GM.nb=true;lgSave(d)}}}
        else{gmRender();lgTimer=setTimeout(()=>{if(!$('#gm'))return;GM.up=[];gmRender()},800);return}}
      return gmRender()}
    if(a==='guess'){GM.v='guess';GM.secret=1+lgR(100);GM.n=0;GM.won=false;GM.msg='';return gmRender()}
    if(a==='gtry'){const v=parseInt($('#gi').value,10);if(!(v>=1&&v<=100))return toast('Masukkan angka 1–100');GM.n++;
      if(v===GM.secret){GM.won=true;GM.msg='🎉 Benar! Angkanya '+v+' ('+GM.n+' tebakan)';if(!d.bestGuess||GM.n<d.bestGuess){d.bestGuess=GM.n;lgSave(d);GM.msg+=' — rekor baru!'}}
      else GM.msg=v<GM.secret?'⬆️ Terlalu kecil':'⬇️ Terlalu besar';return gmRender()}
    if(a==='tapg'){lgClear();GM.v='tap';GM.state='idle';GM.cnt=0;GM.left=10;GM.nb=false;return gmRender()}
    if(a==='tap'){
      if(GM.state==='run'){GM.cnt++;t.textContent=GM.cnt;return}
      GM.state='run';GM.cnt=1;GM.left=10;GM.nb=false;gmRender();
      lgTimer=setInterval(()=>{if(!$('#gm')||GM.v!=='tap'){lgClear();return}GM.left--;
        if(GM.left<=0){lgClear();GM.state='end';const dd=lg();if(GM.cnt>(dd.bestTap||0)){dd.bestTap=GM.cnt;GM.nb=true;lgSave(dd)}gmRender()}
        else{const h=$('#gt');if(h)h.textContent='Sisa '+GM.left+' detik'}},1000)}}}
