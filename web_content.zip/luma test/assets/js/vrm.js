// Penampil model 3D di beranda LUMA: VRM/GLB dan PMX/PMD (MMD). Logo LUMA jadi cadangan.
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { MMDLoader } from 'three/addons/loaders/MMDLoader.js';
import { VRMLoaderPlugin, VRMUtils } from '@pixiv/three-vrm';

const stage = document.getElementById('stage');
const say = m => { try { window.toast && window.toast(m); } catch (e) {} };

// ---- penyimpanan model di perangkat (IndexedDB) ----
const DB = 'luma-vrm', ST = 'm', KEY = 'last';
const idb = () => new Promise((res, rej) => {
  const r = indexedDB.open(DB, 1);
  r.onupgradeneeded = () => r.result.createObjectStore(ST);
  r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
});
const idbGetFrom = async (name) => { try { if (!indexedDB.databases || !(await indexedDB.databases()).some(d => d.name === name)) return null; } catch (e) { return null; } return new Promise(res => { try { const r = indexedDB.open(name, 1); r.onupgradeneeded = () => r.result.createObjectStore(ST); r.onsuccess = () => { try { const d = r.result; const q = d.transaction(ST).objectStore(ST).get(KEY); q.onsuccess = () => res(q.result || null); q.onerror = () => res(null); } catch (e) { res(null); } }; r.onerror = () => res(null); } catch (e) { res(null); } }); };
const idbGet = async () => {
  try {
    const d = await idb();
    const cur = await new Promise(res => { const q = d.transaction(ST).objectStore(ST).get(KEY); q.onsuccess = () => res(q.result || null); q.onerror = () => res(null); });
    if (cur) return cur;
  } catch (e) { return null; }
  // migrasi: model tersimpan di basis data lama (zuvex-vrm / arumi-vrm) dipindah ke luma-vrm
  for (const old of ['zuvex-vrm', 'ar' + 'umi-vrm']) {
    const v = await idbGetFrom(old);
    if (v) { try { await idbSet(v); indexedDB.deleteDatabase(old); } catch (e) {} return v; }
  }
  return null;
};
const idbSet = async (v) => { try { const d = await idb(); d.transaction(ST, 'readwrite').objectStore(ST).put(v, KEY); } catch (e) {} };

// ---- kanvas, tombol, scene ----
const canvas = document.createElement('canvas');
canvas.id = 'vrm';
canvas.style.filter = 'brightness(.92) contrast(1.05) saturate(1)';
stage.insertBefore(canvas, stage.querySelector('.hero'));
const lab = document.createElement('label');
lab.className = 'vrmbtn';
lab.innerHTML = '<span>Muat model</span><input type="file" accept=".vrm,.glb,.pmx,.pmd,.zip,.png,.jpg,.jpeg,.bmp,.tga,.spa,.sph,.webp" multiple hidden>';
const bar = document.createElement('div');
bar.className = 'vrmbar';
bar.appendChild(lab);
const hideBtn = document.createElement('button');
hideBtn.type = 'button';
hideBtn.className = 'vrmbtn vrmhide';
bar.appendChild(hideBtn);
const centerBtn = document.createElement('button');
centerBtn.type = 'button';
centerBtn.className = 'vrmbtn vrmhide vrmcenter';
centerBtn.title = 'Kamera ke tengah'; centerBtn.setAttribute('aria-label', 'Kamera ke tengah');
centerBtn.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3.2"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4"/></svg>';
bar.appendChild(centerBtn);
stage.appendChild(bar);
// sembunyikan / tampilkan model (diingat di perangkat)
const OFFKEY = 'luma-model-hidden';
const SV = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">';
const EYE_ON = SV + '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>';
const EYE_OFF = SV + '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z" opacity=".45"/><path d="M3 3l18 18"/></svg>';
let modelOff = false;
try { modelOff = localStorage.getItem(OFFKEY) === '1'; } catch (e) {}
function setModelOff(off, quiet) {
  modelOff = !!off;
  stage.classList.toggle('model-off', modelOff);
  hideBtn.innerHTML = modelOff ? EYE_OFF : EYE_ON;
  hideBtn.setAttribute('aria-label', modelOff ? 'Tampilkan model' : 'Sembunyikan model');
  hideBtn.title = modelOff ? 'Tampilkan model' : 'Sembunyikan model';
  hideBtn.setAttribute('aria-pressed', String(modelOff));
  try { localStorage.setItem(OFFKEY, modelOff ? '1' : '0'); } catch (e) {}
  if (!modelOff && cur) { try { frame(); } catch (e) {} }
  if (!quiet) say(modelOff ? 'Model disembunyikan' : 'Model ditampilkan');
}
hideBtn.addEventListener('click', () => setModelOff(!modelOff));
window.__lumaModel = { set: o => setModelOff(o), toggle: () => setModelOff(!modelOff), get hidden() { return modelOff; }, speak: x => { try { speak(x); } catch (e) {} }, react: () => { try { react(); } catch (e) {} }, talk: on => { try { A.speakT = on ? 120 : 0; } catch (e) {} },
  emote: (n, k, dur) => { try { const m = ({ happy: 1, sad: 1, angry: 1, surprised: 1, relaxed: 1 })[n] ? n : ''; A.emo = m; A.emoK = Math.min(1, Math.max(0, k == null ? 0.7 : k)); A.emoT = m ? (dur || 5) : 0; } catch (e) {} },
  nodOnce: () => { try { A.nodRT = 0; } catch (e) {} } };
const inp = lab.querySelector('input'), lbl = lab.querySelector('span');

const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(28, 1, 0.1, 50);
const sun = new THREE.DirectionalLight(0xfff1e0, Math.PI * 0.42); sun.position.set(2, 1.2, 1.5);
const rim = new THREE.DirectionalLight(0x6f8cff, Math.PI * 0.3); rim.position.set(-2, 1.5, -1.5);
scene.add(sun, rim, new THREE.AmbientLight(0xdfe6ff, Math.PI * 0.13));

// cur = { kind:'vrm'|'pmx', obj, vrm?, mesh? }
let camBase = null, camP = 0, camPT = 0;   // sudut orbit kamera atas/bawah (rad): hasil yang dihaluskan & targetnya
const PITCH_MIN = -0.5, PITCH_MAX = 0.9;
let camZ = 1, camZT = 1;                    // jarak kamera (pengali): 1 = bidikan awal = zoom-in maksimal; >1 = kamera mundur
const ZOOM_MIN = 1, ZOOM_MAX = 1.35;         // mundur maksimal ±35% ("sedikit")   // batas: sedikit dari bawah ... dari atas
let cur = null, pivot = new THREE.Group(), yaw = 0, targetYaw = 0, look = { x: 0, y: 0 }, t = 0, nextBlink = 2, blink = 0;
scene.add(pivot);

function size() {
  const w = stage.clientWidth, h = stage.clientHeight;
  renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix();
  if (cur) frame();
}
new ResizeObserver(size).observe(stage); size();

function disposeObj(o) {
  o.traverse(n => {
    if (n.geometry) n.geometry.dispose();
    const ms = n.material ? (Array.isArray(n.material) ? n.material : [n.material]) : [];
    ms.forEach(m => { Object.values(m).forEach(v => { if (v && v.isTexture) v.dispose(); }); m.dispose(); });
  });
}
function clear() {
  if (!cur) return;
  pivot.remove(cur.obj);
  if (cur.kind === 'vrm') VRMUtils.deepDispose(cur.obj); else disposeObj(cur.obj);
  cur = null; camBase = null; camP = camPT = 0; camZ = camZT = 1; floorG.visible = false;
}

function recenter() {   // kamera & putaran kembali ke posisi awal (putaran lewat jalur terdekat)
  camPT = 0; camZT = 1; targetYaw = Math.round(targetYaw / (Math.PI * 2)) * Math.PI * 2;
}
centerBtn.addEventListener('click', () => { recenter(); say('Kamera ke tengah'); });

function applyCam() {
  // orbit atas/bawah seperti putaran kiri/kanan: kamera berputar mengelilingi satu titik yang terkunci
  // (tengah bidikan); zoom hanya memundurkan kamera dari bidikan awal (tidak bisa lebih dekat dari bidikan awal)
  if (!camBase) return;
  const { ty, dist, h } = camBase;
  const oy = -h * 0.05 * camZ, oz = dist * camZ, cp = Math.cos(camP), sp = Math.sin(camP);
  camera.position.set(0, ty + oy * cp + oz * sp, oz * cp - oy * sp);
  camera.lookAt(0, ty, 0);
}

// ---- pijakan & lantai: panggung bundar di bawah kaki model (terlihat bila bidikan cukup lebar) ----
const FLOOR = { r: 0.4, thick: 0.018, shadow: 0.3 };   // jari-jari pijakan, tebal, & bayangan kaki (× tinggi model)
const floorG = new THREE.Group(); floorG.visible = false; scene.add(floorG);
const glowTex = (stops, rings) => {
  const c = document.createElement('canvas'); c.width = c.height = 256;
  const g = c.getContext('2d'), m = 128;
  if (stops) { const gr = g.createRadialGradient(m, m, 0, m, m, m); stops.forEach(([o, a]) => gr.addColorStop(o, 'rgba(255,255,255,' + a + ')')); g.fillStyle = gr; g.fillRect(0, 0, 256, 256); }
  if (rings) {
    g.strokeStyle = '#fff'; g.lineCap = 'round';
    g.globalAlpha = 0.9; g.lineWidth = 3; g.beginPath(); g.arc(m, m, m * 0.9, 0, 6.2832); g.stroke();
    g.globalAlpha = 0.55; g.lineWidth = 2; g.setLineDash([2, 9]); g.beginPath(); g.arc(m, m, m * 0.74, 0, 6.2832); g.stroke();
    g.setLineDash([]); g.globalAlpha = 0.4; g.lineWidth = 2;
    for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2 + Math.PI / 4; g.beginPath(); g.arc(m, m, m * 0.58, a - 0.28, a + 0.28); g.stroke(); }
  }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
};
const unitDisc = new THREE.CircleGeometry(1, 64);
const flMat = (tex, extra) => new THREE.MeshBasicMaterial(Object.assign({ map: tex, transparent: true, depthWrite: false, toneMapped: false,
  polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 }, extra || {}));
const fl = {
  glow: new THREE.Mesh(unitDisc, flMat(glowTex([[0, 0.7], [0.5, 0.28], [1, 0]]), { opacity: 0.55 })),
  top: new THREE.Mesh(new THREE.CylinderGeometry(1, 1, 1, 72), new THREE.MeshStandardMaterial({ roughness: 0.55, metalness: 0.15 })),
  rim: new THREE.Mesh(new THREE.TorusGeometry(1, 0.012, 8, 96), new THREE.MeshBasicMaterial({ toneMapped: false })),
  ring: new THREE.Mesh(unitDisc, flMat(glowTex(null, true), { opacity: 0.75 })),
  shade: new THREE.Mesh(unitDisc, flMat(glowTex([[0, 0.55], [0.55, 0.28], [1, 0]]), { color: 0x000000, opacity: 0.8 })),
};
[fl.glow, fl.ring, fl.shade].forEach(m => { m.rotation.x = -Math.PI / 2; });
fl.rim.rotation.x = Math.PI / 2;
fl.glow.renderOrder = -2; fl.ring.renderOrder = 1; fl.shade.renderOrder = 2;
Object.values(fl).forEach(m => floorG.add(m));

function floorColors() {   // warna pijakan mengikuti tema & warna aksen halaman
  try {
    const probe = document.createElement('span'); probe.style.cssText = 'color:var(--ac);position:absolute;visibility:hidden';
    document.body.appendChild(probe);
    const ac = new THREE.Color(getComputedStyle(probe).color); probe.remove();
    const light = document.documentElement.getAttribute('data-theme') === 'light';
    fl.glow.material.color.copy(ac); fl.ring.material.color.copy(ac); fl.rim.material.color.copy(ac);
    fl.top.material.color.copy(ac).lerp(new THREE.Color(light ? 0xffffff : 0x0b0d1f), light ? 0.8 : 0.78);
    fl.shade.material.opacity = light ? 0.55 : 0.8;
  } catch (e) {}
}
floorColors();
new MutationObserver(floorColors).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme', 'style', 'class'] });

// ---- efek beat di lantai: batang spektrum & riak di pijakan (data dari app.js lewat window.__lumaBeat) ----
const BN = 56;
// batang 3D berdiri di tepi pijakan, memanjang ke atas (InstancedMesh; ikut tertutup model dari belakang)
const beatBox = new THREE.BoxGeometry(1, 1, 1); beatBox.translate(0, 0.5, 0);
{ const ps = beatBox.attributes.position, nr = beatBox.attributes.normal, cl = new Float32Array(ps.count * 3);
  for (let i = 0; i < ps.count; i++) {
    const ny = nr.getY(i), nx = Math.abs(nr.getX(i));
    let k = ny > 0.5 ? 1 : ny < -0.5 ? 0.3 : (nx > 0.5 ? 0.82 : 0.6);   // sisi atas terang, sisi samping bergradasi → kesan 3D
    if (Math.abs(ny) < 0.5) k *= 0.5 + 0.5 * ps.getY(i);
    cl[i * 3] = cl[i * 3 + 1] = cl[i * 3 + 2] = k;
  }
  beatBox.setAttribute('color', new THREE.BufferAttribute(cl, 3)); }
const beatBars = new THREE.InstancedMesh(beatBox, new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false, transparent: true, opacity: 0.92 }), BN);
beatBars.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
{ const c0 = new THREE.Color(1, 1, 1); for (let i = 0; i < BN; i++) beatBars.setColorAt(i, c0); }
beatBars.frustumCulled = false; beatBars.renderOrder = 3; beatBars.visible = false; floorG.add(beatBars);
const beatBase = { transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4 };
const _bd = new THREE.Object3D();
const beatRipples = [];
for (let i = 0; i < 5; i++) {
  const m = new THREE.Mesh(new THREE.RingGeometry(0.965, 1, 80), new THREE.MeshBasicMaterial(beatBase));
  m.rotation.x = -Math.PI / 2; m.renderOrder = 3; m.visible = false; floorG.add(m); beatRipples.push(m);
}
const _bv = new THREE.Vector3(), _bc = new THREE.Color();
function updateBeatFloor() {
  if (!cur || !camBase || !floorG.visible || cur.footY === undefined) { window.__lumaFloor = null; return; }
  const h = camBase.h, r = FLOOR.r * h, y = cur.footY;
  const W = stage.clientWidth || 1, Hh = stage.clientHeight || 1;
  const P = (x, z) => { _bv.set(x, y, z).project(camera); return [(_bv.x + 1) / 2 * W, (1 - _bv.y) / 2 * Hh]; };
  const c = P(0, 0), ex = P(r, 0), ez = P(0, r);
  window.__lumaFloor = { x: c[0], y: c[1], rx: Math.abs(ex[0] - c[0]), ry: Math.abs(ez[1] - c[1]) };   // dipakai app.js untuk percikan bintang
  const FB = window.__lumaBeat, on = !!(FB && FB.on);
  const hasBars = on && FB.bars && FB.bars.length === BN;
  beatBars.visible = hasBars;
  if (hasBars) {
    const hue = FB.hue || 270, rb = r * 0.97, y0 = y + h * 0.004;
    for (let i = 0; i < BN; i++) {
      const v = FB.bars[i], a = i / BN * Math.PI * 2 + FB.rot;
      const hg = h * (0.012 + v * v * 0.2 + FB.kick * 0.03);
      _bd.position.set(Math.cos(a) * rb, y0, Math.sin(a) * rb);
      _bd.rotation.set(0, -a, 0);
      _bd.scale.set(r * 0.02, hg, r * 0.04);
      _bd.updateMatrix(); beatBars.setMatrixAt(i, _bd.matrix);
      _bc.setHSL(((hue + i * 2.5) % 360) / 360, 0.92, 0.6 + v * 0.15).multiplyScalar(0.6 + v * 0.5);
      beatBars.setColorAt(i, _bc);
    }
    beatBars.instanceMatrix.needsUpdate = true; beatBars.instanceColor.needsUpdate = true;
  }
  const rp = on && FB.rings ? FB.rings.slice(-beatRipples.length) : [];
  beatRipples.forEach((m, i) => {
    const p = rp[i];
    if (p === undefined) { m.visible = false; return; }
    m.visible = true; m.position.y = y + h * 0.0035; m.scale.setScalar(r * (0.25 + p * 0.75));
    m.material.color.setHSL((((FB.hue || 270) + 30) % 360) / 360, 0.95, 0.75);
    m.material.opacity = Math.pow(1 - p, 1.6) * 0.7;
  });
  // pijakan ikut berdenyut
  const bs = on ? FB.bass : 0, kk = on ? FB.kick : 0;
  fl.glow.material.opacity = 0.55 + bs * 0.45;
  fl.ring.material.opacity = Math.min(1, 0.75 + kk * 0.25 + bs * 0.2);
}

function placeFloor(footY, h) {
  const r = FLOOR.r * h, th = FLOOR.thick * h, y = footY;
  floorG.position.set(0, 0, 0);
  fl.top.scale.set(r, th, r); fl.top.position.y = y - th / 2;
  fl.rim.scale.setScalar(r); fl.rim.position.y = y;
  fl.ring.scale.setScalar(r * 0.97); fl.ring.position.y = y + h * 0.0008;
  fl.shade.scale.setScalar(FLOOR.shadow * h); fl.shade.position.y = y + h * 0.0016;
  fl.glow.scale.setScalar(r * 2.0); fl.glow.position.y = y - th - h * 0.001;
  floorG.visible = true;
}

let lastCover = null;
function frame() {
  // bidikan bust-up seperti semula; panggung kini setinggi layar, jadi posisi model
  // dihitung agar kepala tetap di ~20% area yang terlihat (di atas kartu)
  // ukur dari posisi netral (tanpa geser/putar sebelumnya) supaya hasilnya stabil di setiap pemanggilan
  cur.obj.position.x = 0; pivot.position.set(0, 0, 0); pivot.rotation.set(0, 0, 0); pivot.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(cur.obj), h = box.max.y - box.min.y;
  let cx = (box.max.x + box.min.x) / 2;
  if (cur.kind === 'vrm') {   // pusat = badan karakter (pinggul & kepala), bukan kotak pembatas yang ikut melebar karena sayap/ekor
    try {
      const hu = cur.vrm.humanoid, p = new THREE.Vector3(); let sum = 0, n = 0;
      ['hips', 'head'].forEach(k => { const b = hu.getNormalizedBoneNode(k); if (b) { b.getWorldPosition(p); sum += p.x; n++; } });
      if (n) cx = sum / n;
    } catch (e) {}
  }
  const tn = Math.tan(THREE.MathUtils.degToRad(camera.fov / 2));
  const vis = h * 0.66;
  const fit = (vis * camera.aspect < h * 0.5) ? (h * 0.5) / (vis * camera.aspect) : 1;
  const dist = (vis / 2) / tn * fit * 1.05, Vh = 2 * dist * tn;
  const H = stage.clientHeight || 1, info = document.getElementById('info');
  // kartu disembunyikan → pakai tinggi tutupan terakhir agar model tidak bergeser
  let cover;
  if (document.documentElement.classList.contains('info-off')) cover = lastCover != null ? lastCover : H * 0.3;
  else { cover = info ? Math.min(Math.max(0, H - (info.getBoundingClientRect().top + window.scrollY)), H * 0.6) : 0; lastCover = cover; }
  const ty = box.max.y - Vh / 2 + 0.2 * ((H - cover) / H) * Vh;
  camera.near = h * 0.02; camera.far = h * 40; camera.updateProjectionMatrix();
  cur.obj.position.x = -cx; pivot.position.set(0, 0, 0); pivot.rotation.set(0, 0, 0);   // putaran tetap berporos di tengah badan
  if (cur.hair) cur.hair.reset = true;   // posisi dunia bergeser → mulai ulang simulasi rambut
  if (cur.footY === undefined) { cur.footY = box.min.y; placeFloor(cur.footY, h); }
  camBase = { ty, dist, h, vh: Vh, y0: ty - h * 0.05 };
  applyCam();
}
window.__lumaFrame = () => { if (cur) frame(); };

// ---- animasi ekor & sayap (otomatis, dikenali dari nama tulang/node) ----
const RIG_TAIL = /tail|尻尾|しっぽ|シッポ|テール|ﾃｰﾙ/i;
const RIG_WING = /wing|羽|翼|はね|ウイング|ウィング/i;
const RIG_SKIP = /pony|twin|hair|髪|ツイン|ポニー|ヘア|羽織|haori|ear|耳/i;
const REDUCE = (() => { try { return matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; } })();
let rig = [], rigNeedsSway = false, flapT = -1, nextFlap = 3 + Math.random() * 3;
const _q1 = new THREE.Quaternion(), _q2 = new THREE.Quaternion(), _pq = new THREE.Quaternion();
const _ax = new THREE.Vector3(), _wp = new THREE.Vector3(), _Y = new THREE.Vector3(0, 1, 0), _Z = new THREE.Vector3(0, 0, 1);

function buildRig(springSet) {
  rig = []; rigNeedsSway = false;
  if (!cur) return;
  const root = cur.obj, found = [];
  root.traverse(o => {
    if (o === root || o.isMesh || o.isSkinnedMesh || o.isLight || o.isCamera) return;
    const n = o.name || '';
    if (!n || RIG_SKIP.test(n)) return;
    const kind = RIG_WING.test(n) ? 'wing' : RIG_TAIL.test(n) ? 'tail' : '';
    if (kind) found.push({ o, kind });
  });
  if (!found.length) return;
  const box = new THREE.Box3().setFromObject(root), cx = (box.max.x + box.min.x) / 2, H = (box.max.y - box.min.y) || 1;
  const maxDepth = { tail: 0, wing: 0 };
  found.forEach(r => {
    let d = 0, p = r.o.parent;
    while (p) { const nm = p.name || ''; if (nm && !RIG_SKIP.test(nm) && (r.kind === 'wing' ? RIG_WING : RIG_TAIL).test(nm)) d++; p = p.parent; }
    r.depth = d; maxDepth[r.kind] = Math.max(maxDepth[r.kind], d);
    r.o.getWorldPosition(_wp);
    const dx = _wp.x - cx;
    r.side = Math.abs(dx) < H * 0.02 ? 0 : (dx > 0 ? 1 : -1);
    r.rest = r.o.quaternion.clone();
    r.spring = !!(springSet && springSet.has(r.o));
    if (r.spring) rigNeedsSway = true;
  });
  found.forEach(r => { r.n = maxDepth[r.kind] + 1; r.ph = Math.random() * 6.28; });
  rig = found;
}

function applyRig(dt) {
  if (!rig.length) return;
  const k = REDUCE ? 0.4 : 1;
  nextFlap -= dt;
  if (flapT < 0 && nextFlap <= 0) { flapT = 0; nextFlap = 7 + Math.random() * 8; }
  let flap = 0;
  if (flapT >= 0) { flapT += dt; if (flapT > 1.1) flapT = -1; else flap = Math.sin(Math.PI * flapT / 1.1) * Math.sin(flapT * 14); }
  for (let i = 0; i < rig.length; i++) {
    const r = rig[i];
    if (r.spring || !r.o.parent) continue;
    let ay = 0, az = 0;
    if (r.kind === 'tail') {
      const s = Math.min(0.18, 0.42 / r.n) * k, lag = r.depth * 0.45;
      ay = s * (Math.sin(t * 1.3 - lag + r.ph) * 0.75 + Math.sin(t * 0.55 - lag * 0.6) * 0.45);
      az = s * 0.45 * Math.sin(t * 0.9 - lag * 0.8 + 1.1);
    } else {
      const s = Math.min(0.2, 0.5 / r.n) * k, f = Math.min(0.3, 0.9 / r.n) * k, lag = r.depth * 0.35, sd = r.side || 0;
      az = sd * (s * 0.35 * Math.sin(t * 1.8 - lag + r.ph * 0.3) + f * flap);
      ay = sd * (s * 0.25 * Math.sin(t * 1.8 - lag + 0.8) + f * 0.35 * flap);
    }
    r.o.parent.getWorldQuaternion(_pq).invert();
    _ax.copy(_Y).applyQuaternion(_pq); _q1.setFromAxisAngle(_ax, ay);
    _ax.copy(_Z).applyQuaternion(_pq); _q2.setFromAxisAngle(_ax, az);
    r.o.quaternion.copy(_q1).multiply(_q2).multiply(r.rest);
  }
}

// ---- animasi alami: tatapan, kedip, napas, goyang, ekspresi, bicara ----
// ---- pose lengan / siku / pergelangan (diatur dari Profil karakter → "Pose tangan") ----
// Nilai dalam derajat per sumbu. Kiri memakai nilai apa adanya (z positif = lengan turun);
// kanan dicerminkan otomatis, jadi "Kedua sisi" selalu simetris.
const D2R = Math.PI / 180;
const POSE_DEF = {
  pmx: { arm: { z: 25, y: 0, x: 0 }, elbow: { z: 7, y: -5, x: 0 }, wrist: { z: 0, y: 0, x: 0 } },   // hasil uji di Profil karakter
  vrm: { arm: { z: 75, y: 0, x: 0 }, elbow: { z: 0, y: -8, x: 0 }, wrist: { z: 3, y: 0, x: 0 } }
};
let POSE = null, poseKind = null;
const poseDefault = kind => { const d = JSON.parse(JSON.stringify(POSE_DEF[kind])); return { L: d, R: JSON.parse(JSON.stringify(d)) }; };
function loadPose(kind) {
  poseKind = kind; const P = poseDefault(kind);
  try {
    const sv = JSON.parse(localStorage.getItem('luma-pose-' + kind) || 'null');
    if (sv) for (const sd of ['L', 'R']) for (const j of ['arm', 'elbow', 'wrist']) for (const a of ['x', 'y', 'z'])
      if (sv[sd] && sv[sd][j] && typeof sv[sd][j][a] === 'number') P[sd][j][a] = sv[sd][j][a];
  } catch (e) {}
  return P;
}
const savePose = () => { try { localStorage.setItem('luma-pose-' + poseKind, JSON.stringify(POSE)); } catch (e) {} };
// derajat → rotasi tulang (rad); kanan = cermin kiri
const jr = (v, side) => side === 'L' ? [v.x * D2R, v.y * D2R, -v.z * D2R] : [v.x * D2R, -v.y * D2R, v.z * D2R];
window.__lumaModel.pose = {
  get kind() { return poseKind && cur ? poseKind : null; },
  get: () => POSE && cur ? JSON.parse(JSON.stringify(POSE)) : null,
  set(side, joint, axis, deg) {
    if (!POSE || !cur) return;
    (side === 'B' ? ['L', 'R'] : [side]).forEach(sd => { POSE[sd][joint][axis] = +deg; });
    savePose();
  },
  reset() { if (!poseKind) return; POSE = poseDefault(poseKind); savePose(); }
};
const damp = (a, b, r, dt) => a + (b - a) * (1 - Math.exp(-r * dt));
const clampN = (v, a, b) => Math.max(a, Math.min(b, v));
const dz = (v, z) => Math.sign(v) * Math.max(0, Math.abs(v) - z);
const rnd = (a, b) => a + Math.random() * (b - a);
// pegas teredam kritis: mulai pelan, mempercepat, lalu berhenti lembut tanpa memantul (gerak leher yang alami)
const spring = (o, k, v, target, w, dt) => {
  const x = o[k] - target, e = Math.exp(-w * dt), tmp = (o[v] + w * x) * dt;
  o[v] = (o[v] - w * tmp) * e; o[k] = target + (x + tmp) * e;
};
const wrapPi = a => a - Math.PI * 2 * Math.floor((a + Math.PI) / (Math.PI * 2));
const ease = x => { x = clampN(x, 0, 1); return x * x * (3 - 2 * x); };
const _gv = new THREE.Vector3(), _eu = new THREE.Euler();
const gaze = new THREE.Object3D(); scene.add(gaze);   // titik yang ditatap mata (VRM lookAt)
const A = {
  lastMove: -99, att: 0,            // perhatian ke kursor (0 = menatap penonton)
  wx: 0, wy: 0, wxT: 0, wyT: 0, wT: 2,   // pandangan menerawang saat diam
  sx: 0, sy: 0, sT: 1,              // gerak mata mikro (saccade)
  ex: 0, ey: 0, hx: 0, hy: 0, hxV: 0, hyV: 0,       // arah mata & kepala (rad); ey>0 = ke atas, hx>0 = menunduk
  blinkP: -1, nextBlink: 2.5, dbl: false, second: false, bl: 0,
  tap: -1, happyT: 0, nod: 0, speakT: 0, spk: 0, mouth: 0, mouth2: 0, happy: 0,
  br: 0, br2: 0, sw: 0,
  nodRT: -1, emo: '', emoT: 0, emoK: 0.7, e: { happy: 0, sad: 0, angry: 0, surprised: 0, relaxed: 0 },   // reaksi dari AI
  hp: new THREE.Vector3()
};

function startBlink(second) {
  A.blinkP = 0; A.nextBlink = rnd(2.2, 6);
  A.dbl = second ? false : Math.random() < 0.15;   // sesekali kedip dua kali
}
function resetAnim() {
  Object.assign(A, { lastMove: -99, att: 0, wx: 0, wy: 0, wxT: 0, wyT: 0, wT: 2, sx: 0, sy: 0, sT: 1, ex: 0, ey: 0, hx: 0, hy: 0, hxV: 0, hyV: 0,
    blinkP: -1, nextBlink: rnd(1.5, 3), dbl: false, second: false, bl: 0, tap: -1, happyT: 0, nod: 0, speakT: 0, spk: 0, mouth: 0, mouth2: 0, happy: 0,
    nodRT: -1, emo: '', emoT: 0, e: { happy: 0, sad: 0, angry: 0, surprised: 0, relaxed: 0 } });
}
// ketuk model → tersenyum + mengangguk kecil
function react() { if (cur) A.tap = 0; }
// dipanggil saat AI membalas: mulut bergerak selama kira-kira lama kalimat
function speak(text) {
  const n = String(text || '').replace(/\s+/g, ' ').length;
  A.speakT = clampN(n * 0.06, 1.2, 9);
}

// tatapan: mata cepat, kepala menyusul pelan (mata duluan, baru kepala ikut)
function updateGaze(dt) {
  const hp = A.hp, D = Math.max(0.5, camera.position.z - hp.z);
  const fresh = (t - A.lastMove) < 4 && A.speakT <= 0 ? 1 : 0;   // kursor baru bergerak → ikuti; selain itu tatap penonton
  A.att = damp(A.att, fresh, fresh ? 5 : 1.2, dt);
  // arah dari kepala ke titik kursor pada layar
  camera.updateMatrixWorld();
  _gv.set(clampN(look.x, -1.6, 1.6), -clampN(look.y, -1.6, 1.6), 0.5).unproject(camera).sub(camera.position).normalize();
  const zp = camera.position.z * 0.55, s = _gv.z ? (zp - camera.position.z) / _gv.z : 0;
  const px = camera.position.x + _gv.x * s - hp.x, py = camera.position.y + _gv.y * s - hp.y, pz = zp - hp.z;
  const yawP = clampN(Math.atan2(px, pz), -1.1, 1.1), pitP = clampN(Math.atan2(py, Math.hypot(px, pz)), -0.7, 0.7);
  // menerawang saat tak ada kursor: gerak kecil, sesekali melirik ke samping lalu kembali
  A.wT -= dt;
  if (A.wT <= 0) {
    const glance = Math.random() < 0.22;
    A.wxT = glance ? rnd(-0.38, 0.38) : rnd(-0.1, 0.1); A.wyT = glance ? rnd(-0.12, 0.2) : rnd(-0.05, 0.06);
    A.wT = glance ? rnd(0.9, 1.8) : rnd(2.2, 5);
    if (glance && A.blinkP < 0 && Math.random() < 0.6) startBlink(false);
  }
  A.wx = damp(A.wx, A.wxT, 6, dt); A.wy = damp(A.wy, A.wyT, 6, dt);
  A.sT -= dt;
  if (A.sT <= 0) { A.sx = rnd(-0.035, 0.035); A.sy = rnd(-0.022, 0.022); A.sT = rnd(0.35, 1.8); }
  // saat kamera naik/turun, tatapan ikut mengarah ke kamera (dibanding posisi awal)
  const vp = clampN(camP, -0.5, 0.5) * 0.9;
  const tx = A.att * yawP + (1 - A.att) * A.wx, ty = A.att * pitP + (1 - A.att) * (A.wy + vp);
  A.ex = damp(A.ex, tx + A.sx, 20, dt); A.ey = damp(A.ey, ty + A.sy, 20, dt);
  // kepala menoleh kiri/kanan ke arah tatapan relatif terhadap badan; batas lembut ±~60° (tanh), lewat itu kepala tak dipaksa
  const rel = wrapPi(tx - yaw), LIM = 1.05;
  const hyT = LIM * Math.tanh(dz(rel, 0.04) * 0.9 / LIM);
  const hxT = clampN(-dz(ty, 0.04) * 0.7, -0.34, 0.3);
  spring(A, 'hy', 'hyV', hyT, 5.5, dt); spring(A, 'hx', 'hxV', hxT, 6.5, dt);
  gaze.position.set(hp.x + Math.tan(A.ex) * D, hp.y + Math.tan(A.ey) * D, camera.position.z);
}

// kedip, napas, goyang, ketukan, bicara (dipakai VRM & PMX)
function stepCommon(dt) {
  const k = REDUCE ? 0.4 : 1;
  updateGaze(dt);
  A.nextBlink -= dt;
  if (A.blinkP < 0 && A.nextBlink <= 0) { startBlink(A.second); A.second = false; }
  let bl = 0;
  if (A.blinkP >= 0) {
    A.blinkP += dt / 0.2;   // menutup cepat, membuka lebih pelan
    if (A.blinkP >= 1) { A.blinkP = -1; if (A.dbl) { A.dbl = false; A.second = true; A.nextBlink = 0.1; } }
    else bl = ease(A.blinkP < 0.4 ? A.blinkP / 0.4 : 1 - (A.blinkP - 0.4) / 0.6);
  }
  A.bl = bl;
  A.br = Math.sin(t * 1.5) * k; A.br2 = Math.sin(t * 1.5 - 0.6) * k;
  A.sw = (Math.sin(t * 0.42) * 0.6 + Math.sin(t * 0.19 + 1.3) * 0.4) * k;
  if (A.tap >= 0) {
    A.tap += dt;
    if (A.tap > 2.4) A.tap = -1;
  }
  const tp = A.tap;
  A.happyT = tp >= 0 ? ease(tp / 0.25) * (1 - ease((tp - 1.6) / 0.8)) : 0;
  A.nod = tp >= 0 && tp < 0.7 ? Math.sin(Math.PI * tp / 0.7) : 0;
  if (A.speakT > 0) A.speakT -= dt;
  A.spk = Math.min(1, Math.max(0, A.speakT));
  const env = Math.max(0, Math.sin(t * 9) * Math.sin(t * 2.3 + 0.5));   // suku kata dengan jeda
  A.mouth = damp(A.mouth, A.spk > 0 ? 0.15 + 0.5 * env : 0, 18, dt) * (A.spk > 0 ? 1 : 0.9);
  A.mouth2 = damp(A.mouth2, A.spk > 0 ? 0.35 * Math.max(0, Math.sin(t * 5.3 + 2)) : 0, 12, dt);
  A.happy = damp(A.happy, 0.45 * A.happyT, 10, dt);
  // reaksi dari AI: emosi (dipilih AI / dari teks) dan angguk
  if (A.emoT > 0) A.emoT -= dt;
  for (const n in A.e) A.e[n] = damp(A.e[n], (A.emoT > 0 && A.emo === n) ? A.emoK : 0, A.emoT > 0 ? 5 : 3, dt);
  if (A.nodRT >= 0) { A.nodRT += dt; if (A.nodRT > 0.7) A.nodRT = -1; }
  if (A.nodRT >= 0) A.nod = Math.max(A.nod, Math.sin(Math.PI * A.nodRT / 0.7));
}

// ---- VRM ----
function initVRMAnim(m) {
  const hu = m.humanoid, N = n => { try { return hu.getNormalizedBoneNode(n); } catch (e) { return null; } };
  const B = { hips: N('hips'), spine: N('spine'), chest: N('chest'), upperChest: N('upperChest'), neck: N('neck'), head: N('head'),
    lSh: N('leftShoulder'), rSh: N('rightShoulder'), lUA: N('leftUpperArm'), rUA: N('rightUpperArm'),
    lLA: N('leftLowerArm'), rLA: N('rightLowerArm'), lH: N('leftHand'), rH: N('rightHand') };
  // jari agak menekuk (rileks), bukan lurus kaku
  const F = [];
  [['Index', [0.18, 0.22, 0.12]], ['Middle', [0.26, 0.3, 0.15]], ['Ring', [0.32, 0.34, 0.16]], ['Little', [0.38, 0.38, 0.18]]].forEach(([nm, v]) =>
    ['Proximal', 'Intermediate', 'Distal'].forEach((j, i) => {
      const l = N('left' + nm + j), r = N('right' + nm + j);
      if (l) F.push({ b: l, s: -1, v: v[i] }); if (r) F.push({ b: r, s: 1, v: v[i] });
    }));
  const box = new THREE.Box3().setFromObject(m.scene), h = (box.max.y - box.min.y) || 1.6;
  cur.bones = B; cur.fingers = F; cur.eyeUp = h * 0.04;
  cur.hp0 = new THREE.Vector3(0, box.max.y - h * 0.1, 0);
  POSE = loadPose('vrm');
  { const l = jr(POSE.L.arm, 'L'), r = jr(POSE.R.arm, 'R'); if (B.lUA) B.lUA.rotation.set(l[0], l[1], l[2]); if (B.rUA) B.rUA.rotation.set(r[0], r[1], r[2]); }
  if (m.lookAt) { m.lookAt.target = gaze; m.lookAt.autoUpdate = true; }   // mata mengikuti titik tatapan
  resetAnim();
}

function animateVRM(dt) {
  const m = cur.vrm, B = cur.bones, k = REDUCE ? 0.4 : 1;
  try {
    if (B.head) { B.head.getWorldPosition(A.hp); A.hp.y += cur.eyeUp; } else A.hp.copy(cur.hp0);
    stepCommon(dt);
    const { br, br2, sw } = A, set = (b, x, y, z) => { if (b) b.rotation.set(x, y, z); };
    const swayY = rigNeedsSway ? Math.sin(t * 1.1) * 0.05 : Math.sin(t * 0.31) * 0.02 * k;
    // badan: napas + geser berat badan pelan
    set(B.hips, 0, swayY, sw * 0.012);
    const bsh = B.upperChest ? 0.1 : 0.2;   // menoleh: 20% ikut badan atas, 33% leher, 47% kepala
    set(B.spine, -0.006 * br, -swayY * 0.5, -sw * 0.008);
    set(B.chest, -0.012 * br2, -swayY * 0.3 + A.hy * bsh, -sw * 0.006);
    set(B.upperChest, -0.01 * br2, A.hy * 0.1, 0);
    // leher & kepala: mengikuti tatapan, miring halus, angguk saat diketuk / bicara
    const nodX = A.nod * 0.12 + A.spk * Math.sin(t * 4.1) * 0.012;
    const roll = (-A.hy * 0.12 + (Math.sin(t * 0.37) * 0.022 + Math.sin(t * 0.91 + 2) * 0.01) * k - sw * 0.01);
    const micro = Math.sin(t * 0.6) * 0.01 * k;
    set(B.neck, A.hx * 0.4 + nodX * 0.4, A.hy * 0.33, roll * 0.4);
    set(B.head, A.hx * 0.6 + nodX * 0.6 + micro, A.hy * 0.47, roll * 0.6);
    // bahu naik-turun saat napas, lengan menjuntai santai
    set(B.lSh, 0, 0, 0.014 * br2); set(B.rSh, 0, 0, -0.014 * br2);
    const bz = br2 * 0.012, sz = sw * 0.012;
    let r = jr(POSE.L.arm, 'L'); set(B.lUA, r[0], r[1], r[2] - bz + sz);
    r = jr(POSE.R.arm, 'R'); set(B.rUA, r[0], r[1], r[2] + bz + sz);
    r = jr(POSE.L.elbow, 'L'); set(B.lLA, r[0], r[1] - br2 * 0.01, r[2]);
    r = jr(POSE.R.elbow, 'R'); set(B.rLA, r[0], r[1] + br2 * 0.01, r[2]);
    r = jr(POSE.L.wrist, 'L'); set(B.lH, r[0], r[1], r[2]);
    r = jr(POSE.R.wrist, 'R'); set(B.rH, r[0], r[1], r[2]);
    for (const f of cur.fingers) f.b.rotation.set(0, 0, f.s * (f.v + br2 * 0.01));
    const ex = m.expressionManager;
    if (ex) {
      const hp = Math.min(1, A.happy + A.e.happy);
      ex.setValue('blink', A.bl * (1 - hp));
      ex.setValue('happy', hp);
      ex.setValue('sad', A.e.sad); ex.setValue('angry', A.e.angry);
      ex.setValue('surprised', A.e.surprised); ex.setValue('relaxed', A.e.relaxed);
      ex.setValue('aa', A.mouth); ex.setValue('oh', A.mouth2);
    }
  } catch (e) { if (!window.__lumaAnimWarn) { window.__lumaAnimWarn = 1; console.warn('[anim]', e); } }
  m.update(dt);
  applyRig(dt);
}

// ---- fisika rambut PMX: pegas ringan (tanpa Ammo.js) pada tulang "hair_*" ----
// Tiap tulang rambut punya "ujung" yang tertinggal saat kepala bergerak (inersia),
// ditarik kembali ke arah diam (kekakuan), plus embusan angin halus agar tidak kaku saat diam.
const HAIR = { stiff: 1, drag: 0.2, wind: 0.2, smooth: 0.45, margin: 1.0, collide: true };
// stiff: makin besar makin kaku · drag: redaman (makin besar makin tenang) · wind: 0 = tanpa angin
// smooth: 0..1 penghalus rotasi tulang (makin kecil makin halus) · margin: pengali jarak aman dari tubuh/sayap · collide: false = matikan tabrakan
const HAIR_RE = /^hair_/i;
const _hv = new THREE.Vector3(), _hv2 = new THREE.Vector3(), _rd = new THREE.Vector3(), _nx = new THREE.Vector3(), _nd = new THREE.Vector3(), _pp = new THREE.Vector3();
const _hq = new THREE.Quaternion(), _hq2 = new THREE.Quaternion(), _dq = new THREE.Quaternion();

// ---- collider tubuh & sayap: rambut tidak boleh menembus baju/sayap ----
const _ca = new THREE.Vector3(), _cb = new THREE.Vector3(), _cq = new THREE.Vector3(), _cd = new THREE.Vector3(), _cm = new THREE.Vector3();
function buildHairColliders(mesh, h) {
  const bones = (mesh.skeleton && mesh.skeleton.bones) || [];
  const byName = n => bones.find(x => x.name === n) || null;
  const cols = [];
  const cap = (a, b, r) => { if (a && b && a !== b) cols.push({ a, b, r: h * r, A: new THREE.Vector3(), B: new THREE.Vector3() }); };
  const sph = (a, r) => { if (a) cols.push({ a, b: a, r: h * r, A: new THREE.Vector3(), B: new THREE.Vector3() }); };
  const up = byName('上半身'), up2 = byName('上半身2'), neck = byName('首'), lowr = byName('下半身');
  cap(up, up2 || neck, 0.075);
  if (up2) cap(up2, neck, 0.07);
  if (lowr) cap(up, lowr, 0.07);
  for (const s of ['左', '右']) {
    const arm = byName(s + '腕'), elb = byName(s + 'ひじ'), wr = byName(s + '手首');
    cap(arm, elb, 0.032); cap(elb, wr, 0.026);
  }
  // sayap: semua tulang bernama wing/羽/翼 (bukan 羽織 / rambut), dihubungkan ke anak sayapnya
  const isWing = b => RIG_WING.test(b.name || '') && !RIG_SKIP.test(b.name || '');
  bones.forEach(b => {
    if (!isWing(b)) return;
    const kids = b.children.filter(c => c.isBone && isWing(c));
    if (kids.length) kids.forEach(k => cap(b, k, 0.05)); else sph(b, 0.045);
  });
  return cols;
}

// dorong titik p keluar dari semua collider; base = pangkal tulang rambut (collider yang sudah menelan pangkal diabaikan)
function hairCollide(H, p, base) {
  let hit = false;
  for (const c of H.cols) {
    if (c.skip && c.skip.has(base)) continue;
    const r = c.r * HAIR.margin;
    _cb.subVectors(c.B, c.A); const l2 = _cb.lengthSq();
    const tt = l2 > 1e-12 ? Math.max(0, Math.min(1, _cd.subVectors(p, c.A).dot(_cb) / l2)) : 0;
    _cq.copy(c.A).addScaledVector(_cb, tt);
    _cd.subVectors(p, _cq);
    const d = _cd.length();
    if (d < r) {
      if (d < 1e-6) _cd.set(0, 0, 1); else _cd.divideScalar(d);
      p.copy(_cq).addScaledVector(_cd, r); hit = true;
    }
  }
  return hit;
}

function initHair(mesh, h) {
  const bones = (mesh.skeleton && mesh.skeleton.bones) || [];
  const hb = bones.filter(b => HAIR_RE.test(b.name || '') && b.parent && b.parent.isBone);
  if (!hb.length) return null;
  mesh.updateMatrixWorld(true);
  const set = new Set(hb), byBone = new Map();
  const depth = b => { let d = 0, p = b.parent; while (p && set.has(p)) { d++; p = p.parent; } return d; };
  const joints = hb.map(b => {
    const kids = b.children.filter(c => set.has(c));
    return { b, p: b.parent, d: depth(b), restQ: b.quaternion.clone(), kid: kids.length === 1 ? kids[0] : null,
      cur: new THREE.Vector3(), prev: new THREE.Vector3(), ph: Math.random() * 6.28 };
  }).sort((a, b) => a.d - b.d);       // induk dihitung lebih dulu dari anak
  joints.forEach(j => byBone.set(j.b, j));
  joints.forEach(j => {
    j.b.getWorldPosition(_hv);
    j.p.getWorldQuaternion(_hq).multiply(j.restQ);
    if (j.kid) {
      j.kid.getWorldPosition(_hv2);
      j.len = _hv2.distanceTo(_hv) || h * 0.04;
      j.rl = j.kid.position.clone().normalize();                              // arah diam di frame tulang
    } else {
      const pj = byBone.get(j.p);
      j.len = pj ? pj.len : h * 0.04;
      j.rl = new THREE.Vector3(0, -1, 0).applyQuaternion(_hq.clone().invert()); // ujung tulang: menggantung ke bawah
    }
    const n = j.b.name;
    if (/ribon/i.test(n)) { j.k = 6; j.max = 0.28; }
    else if (/front/i.test(n)) { j.k = 5; j.max = 0.34; }
    else { j.k = [5, 4, 3.2, 2.6][Math.min(j.d, 3)]; j.max = 0.3; }
  });
  const cols = HAIR.collide ? buildHairColliders(mesh, h) : [];
  cols.forEach(c => {                    // collider yang sudah menelan pangkal tulang rambut saat diam → abaikan untuk tulang itu
    c.a.getWorldPosition(c.A); c.b.getWorldPosition(c.B);
    c.skip = new Set();
    joints.forEach(j => {
      j.b.getWorldPosition(_hv);
      _cb.subVectors(c.B, c.A); const l2 = _cb.lengthSq();
      const tt = l2 > 1e-12 ? Math.max(0, Math.min(1, _hv2.subVectors(_hv, c.A).dot(_cb) / l2)) : 0;
      _cq.copy(c.A).addScaledVector(_cb, tt);
      if (_hv.distanceTo(_cq) < c.r * 0.95) c.skip.add(j.b);
    });
  });
  return { joints, cols, reset: true };
}

function stepHair(H, dt) {
  dt = Math.min(dt, 1 / 30);
  const k = REDUCE ? 0.4 : 1, ret = Math.pow(1 - HAIR.drag, dt * 60);
  cur.obj.updateMatrixWorld(true);      // pose kepala terbaru dari animasi
  for (const c of H.cols) { c.a.getWorldPosition(c.A); c.b.getWorldPosition(c.B); }
  for (const j of H.joints) {
    const b = j.b, p = j.p;
    _hv.setFromMatrixPosition(b.matrixWorld);                 // pangkal tulang (dunia)
    p.getWorldQuaternion(_hq);                                // rotasi dunia induk
    _hq2.copy(_hq).multiply(j.restQ);
    _rd.copy(j.rl).applyQuaternion(_hq2);                     // arah diam (dunia)
    if (H.reset) { j.cur.copy(_hv).addScaledVector(_rd, j.len); j.prev.copy(j.cur); }
    _nx.copy(j.cur).sub(j.prev).multiplyScalar(ret).add(j.cur);                // inersia
    _nx.addScaledVector(_rd, j.k * HAIR.stiff * j.len * dt);                   // tarik ke arah diam
    const wx = Math.sin(t * 0.9 + j.ph) * 0.6 + Math.sin(t * 0.37 + j.ph * 2) * 0.4;
    const wz = Math.sin(t * 0.7 + j.ph + 1) * 0.5;
    _nx.x += wx * HAIR.wind * k * j.len * dt; _nx.z += wz * HAIR.wind * 0.6 * k * j.len * dt;   // angin halus
    _nd.copy(_nx).sub(_hv);
    if (_nd.lengthSq() < 1e-10) _nd.copy(_rd);
    _nd.normalize();
    const c = _nd.dot(_rd), ca = Math.cos(j.max);             // batasi sudut simpangan
    if (c < ca) {
      _pp.copy(_nd).addScaledVector(_rd, -c);
      if (_pp.lengthSq() < 1e-10) _pp.set(1, 0, 0).addScaledVector(_rd, -_rd.x);
      _pp.normalize();
      _nd.copy(_rd).multiplyScalar(ca).addScaledVector(_pp, Math.sin(j.max)).normalize();
    }
    _nx.copy(_hv).addScaledVector(_nd, j.len);
    if (H.cols.length) {                                      // tabrakan: ujung & titik tengah tidak boleh masuk tubuh/sayap
      let hit = hairCollide(H, _nx, b);
      _cm.copy(_hv).lerp(_nx, 0.5);
      if (hairCollide(H, _cm, b)) { _nx.copy(_cm).sub(_hv).multiplyScalar(2).add(_hv); hit = true; }
      if (hit) { _nd.copy(_nx).sub(_hv).normalize(); _nx.copy(_hv).addScaledVector(_nd, j.len); }   // panjang tulang tetap
    }
    j.prev.copy(j.cur); j.cur.copy(_nx);
    _dq.setFromUnitVectors(_rd, _nd);                         // putar tulang ke arah baru
    _hq2.copy(_hq).invert().multiply(_dq).multiply(_hq).multiply(j.restQ);
    if (H.reset) b.quaternion.copy(_hq2); else b.quaternion.slerp(_hq2, HAIR.smooth);   // penghalus: kurangi getaran kecil
    b.updateMatrixWorld(true);
  }
  H.reset = false;
}

// ---- PMX / PMD (tulang berbahasa Jepang) ----
function initPMXAnim(mesh) {
  const bones = (mesh.skeleton && mesh.skeleton.bones) || [];
  const get = n => { const b = bones.find(x => x.name === n); return b ? { b, q: b.quaternion.clone() } : null; };
  cur.pb = { head: get('頭'), neck: get('首'), eyeL: get('左目'), eyeR: get('右目'), up: get('上半身'), up2: get('上半身2'),
    lSh: get('左肩'), rSh: get('右肩'), lArm: get('左腕'), rArm: get('右腕'),
    lElb: get('左ひじ'), rElb: get('右ひじ'), lWr: get('左手首'), rWr: get('右手首') };
  POSE = loadPose('pmx');
  const box = new THREE.Box3().setFromObject(mesh), h = (box.max.y - box.min.y) || 1;
  cur.eyeUp = h * 0.04; cur.hp0 = new THREE.Vector3(0, box.max.y - h * 0.12, 0);
  cur.hair = initHair(mesh, h);   // fisika rambut (bone hair_*)
  resetAnim();
}

function animatePMX(dt) {
  const P = cur.pb || {}, k = REDUCE ? 0.4 : 1;
  const rot = (o, x, y, z) => { if (o) { _eu.set(x, y, z, 'YXZ'); o.b.quaternion.setFromEuler(_eu).multiply(o.q); } };
  try {
    if (P.head) { P.head.b.getWorldPosition(A.hp); A.hp.y += cur.eyeUp; } else A.hp.copy(cur.hp0);
    stepCommon(dt);
    cur.obj.scale.y = 1 + Math.sin(t * 1.2) * 0.002 * k;
    const nodX = A.nod * 0.12 + A.spk * Math.sin(t * 4.1) * 0.012;
    const roll = -A.hy * 0.12 + Math.sin(t * 0.37) * 0.022 * k - A.sw * 0.01;
    rot(P.up, -0.012 * A.br2, A.hy * (P.up2 ? 0.1 : 0.2), A.sw * 0.006);
    // bahu naik-turun saat napas; lengan diturunkan dari pose bawaan lalu bergoyang halus
    rot(P.lSh, 0, 0, 0.014 * A.br2); rot(P.rSh, 0, 0, -0.014 * A.br2);
    const bz = A.br2 * 0.012, sz = A.sw * 0.012;
    let r = jr(POSE.L.arm, 'L'); rot(P.lArm, r[0], r[1], r[2] - bz + sz);
    r = jr(POSE.R.arm, 'R'); rot(P.rArm, r[0], r[1], r[2] + bz + sz);
    r = jr(POSE.L.elbow, 'L'); rot(P.lElb, r[0], r[1], r[2]);
    r = jr(POSE.R.elbow, 'R'); rot(P.rElb, r[0], r[1], r[2]);
    r = jr(POSE.L.wrist, 'L'); rot(P.lWr, r[0], r[1], r[2]);
    r = jr(POSE.R.wrist, 'R'); rot(P.rWr, r[0], r[1], r[2]);
    rot(P.up2, -0.008 * A.br2, A.hy * 0.1, 0);
    rot(P.neck, A.hx * 0.4 + nodX * 0.4, A.hy * 0.33, roll * 0.4);
    rot(P.head, A.hx * 0.6 + nodX * 0.6, A.hy * 0.47, roll * 0.6);
    // mata relatif terhadap kepala (kepala dunia = yaw pivot + gerak kepala)
    // mata dihitung dari arah hadap kepala yang SEBENARNYA (bukan perkiraan yaw + hy), jadi tidak melenceng
    // ke satu sisi walau badan diputar, ada tulang yang tak ada, atau pose awal model sedikit miring
    let eyY, eyX;
    if (P.head) {
      P.head.b.updateWorldMatrix(true, false);
      P.head.b.getWorldQuaternion(_hq); _hv.set(0, 0, 1).applyQuaternion(_hq);
      const hdYaw = Math.atan2(_hv.x, _hv.z), hdUp = Math.asin(clampN(_hv.y, -1, 1));
      eyY = clampN(wrapPi(A.ex - hdYaw), -0.32, 0.32);
      eyX = clampN(-(A.ey - hdUp), -0.2, 0.2);
    } else {
      eyY = clampN(A.ex - (yaw + A.hy), -0.3, 0.3); eyX = clampN(-(A.ey + A.hx), -0.2, 0.2);
    }
    rot(P.eyeL, eyX, eyY, 0); rot(P.eyeR, eyX, eyY, 0);
    const d = cur.mesh.morphTargetDictionary, inf = cur.mesh.morphTargetInfluences;
    if (d && inf) {
      const put = (names, v) => { for (const n of names) if (d[n] !== undefined) { inf[d[n]] = v; return; } };
      const hp = Math.min(1, A.happy + A.e.happy);
      put(['まばたき', 'blink', 'Blink'], A.bl * (1 - hp));
      put(['笑い', 'にこり'], hp * 1.2);
      put(['困る', '悲しい', 'しょんぼり'], A.e.sad);
      put(['怒り', 'ぷんぷん'], A.e.angry);
      put(['びっくり', '驚き', 'おどろき'], A.e.surprised);
      put(['なごみ'], A.e.relaxed);
      put(['あ'], A.mouth);
    }
    applyRig(dt);
    if (cur.hair) stepHair(cur.hair, dt);
  } catch (e) { if (!window.__lumaAnimWarn) { window.__lumaAnimWarn = 1; console.warn('[anim]', e); } }
}

function shown() { stage.classList.add('has-vrm'); lbl.textContent = 'Ganti model'; }

// ---- pemuat ----
async function loadVRM(blob) {
  const loader = new GLTFLoader();
  loader.register(p => new VRMLoaderPlugin(p));
  const gltf = await loader.parseAsync(await blob.arrayBuffer(), '');
  const m = gltf.userData.vrm;
  if (!m) throw new Error('Bukan file VRM (GLB biasa)');
  VRMUtils.removeUnnecessaryVertices(gltf.scene);
  VRMUtils.removeUnnecessaryJoints(gltf.scene);
  VRMUtils.rotateVRM0(m);
  clear(); cur = { kind: 'vrm', obj: m.scene, vrm: m }; pivot.add(m.scene);
  try { initVRMAnim(m); } catch (e) { console.warn('[anim]', e); }
  frame(); shown();
  try { const sp = new Set(); const j = m.springBoneManager && m.springBoneManager.joints; if (j) j.forEach(x => x.bone && sp.add(x.bone)); buildRig(sp); } catch (e) { buildRig(); }
}

let pmxUrls = [];
async function loadPMX(main, files, mainName) {
  // MMDLoader membaca ekstensi dari URL, sedangkan blob: tidak punya ekstensi.
  // Jadi dipakai alamat palsu yang dipetakan ke file lewat nama (tanpa folder, tanpa huruf besar/kecil).
  const safe = x => { try { return decodeURIComponent(x); } catch (e) { return x; } };
  const key = x => safe(String(x)).split(/[\\\\/]/).pop().split('?')[0].toLowerCase();
  const ext = /\.pmd$/i.test(mainName) ? 'pmd' : 'pmx';
  const mgr = new THREE.LoadingManager();
  const made = [];
  mgr.setURLModifier(u => {
    if (u.startsWith('blob:') || u.startsWith('data:')) return u;
    const k = key(u), b = k === 'luma-main.' + ext ? main : files.get(k);
    if (!b) return u;
    const bu = URL.createObjectURL(b); made.push(bu); return bu;
  });
  const mesh = await new Promise((res, rej) => new MMDLoader(mgr).load('https://luma.local/luma-main.' + ext, res, undefined, rej));
  clear(); pmxUrls.forEach(URL.revokeObjectURL); pmxUrls = made;
  cur = { kind: 'pmx', obj: mesh, mesh }; pivot.add(mesh);
  try { initPMXAnim(mesh); } catch (e) { console.warn('[anim]', e); }
  frame(); shown(); buildRig();
}

// kumpulkan file (termasuk isi ZIP) lalu pilih model utamanya
async function expand(list) {
  const map = new Map();
  const add = (name, blob) => map.set(name.split(/[\\/]/).pop().toLowerCase(), blob);
  for (const f of list) {
    if (/\.zip$/i.test(f.name)) {
      if (!window.JSZip) { say('Pustaka ZIP belum termuat'); continue; }
      const z = await window.JSZip.loadAsync(f);
      for (const e of Object.values(z.files)) if (!e.dir) add(e.name, await e.async('blob'));
    } else add(f.name, f);
  }
  return map;
}

async function loadFiles(list, save) {
  const files = await expand([...list]);
  const names = [...files.keys()];
  const pmx = names.find(n => /\.(pmx|pmd)$/.test(n)), vrm = names.find(n => /\.(vrm|glb)$/.test(n));
  try {
    if (pmx) await loadPMX(files.get(pmx), files, pmx);
    else if (vrm) await loadVRM(files.get(vrm));
    else { say('Pilih file .vrm, .pmx, atau ZIP berisi model'); return false; }
  } catch (e) { console.warn('[model]', e); say('Model gagal dimuat: ' + String((e && e.message) || e).slice(0, 90)); return false; }
  if (save) idbSet([...files].map(([n, b]) => ({ n, b })));
  return true;
}

inp.addEventListener('change', () => { if (inp.files.length) loadFiles(inp.files, true); inp.value = ''; });
stage.addEventListener('dragover', e => e.preventDefault());
stage.addEventListener('drop', e => { e.preventDefault(); if (e.dataTransfer.files.length) loadFiles(e.dataTransfer.files, true); });

// geser horizontal memutar model; geser vertikal menaik-turunkan kamera; ketuk dua kali mengembalikan pandangan
let dragX = null, dragY = null, tapDown = null, lastTap = 0, pinch = null;
const ptrs = new Map();   // jari/pointer yang sedang menyentuh model (untuk cubit zoom)
const pdist = () => { const [a, b] = [...ptrs.values()]; return Math.hypot(a.x - b.x, a.y - b.y) || 1; };
canvas.addEventListener('pointerdown', e => {
  ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
  if (ptrs.size === 2) { pinch = { d: pdist(), z: camZT }; dragX = dragY = null; tapDown = null; return; }
  dragX = e.clientX; dragY = e.clientY; tapDown = { x: e.clientX, y: e.clientY, t: performance.now() };
});
// roda mouse / cubit di trackpad di atas model: zoom (roda ke bawah = mundur)
canvas.addEventListener('wheel', e => {
  e.preventDefault();
  camZT = clampN(camZT * Math.exp(e.deltaY * (e.deltaMode === 1 ? 0.03 : 0.0012)), ZOOM_MIN, ZOOM_MAX);
}, { passive: false });
addEventListener('pointerup', e => {
  ptrs.delete(e.pointerId); if (ptrs.size < 2) pinch = null;
  if (pinch === null && ptrs.size === 1) { tapDown = null; dragX = dragY = null; return; }   // sisa satu jari setelah cubit: jangan melompat
  if (tapDown && performance.now() - tapDown.t < 350 && Math.hypot(e.clientX - tapDown.x, e.clientY - tapDown.y) < 10) {
    react();
    const n = performance.now();
    if (n - lastTap < 320) { recenter(); lastTap = 0; }   // ketuk dua kali: pandangan kembali
    else lastTap = n;
  }
  tapDown = null; dragX = null; dragY = null;
});
addEventListener('pointercancel', e => { ptrs.delete(e.pointerId); pinch = null; tapDown = null; dragX = null; dragY = null; });
addEventListener('pointermove', e => {
  if (ptrs.has(e.pointerId)) {
    ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pinch && ptrs.size === 2) {   // cubit: jari menjauh = mendekat (sampai bidikan awal), mendekat = kamera mundur
      camZT = clampN(pinch.z * pinch.d / pdist(), ZOOM_MIN, ZOOM_MAX);
      return;
    }
  }
  const r = stage.getBoundingClientRect();
  look.x = ((e.clientX - r.left) / r.width - 0.5) * 2; look.y = ((e.clientY - r.top) / r.height - 0.5) * 2;
  A.lastMove = t;
  if (dragX !== null) {
    targetYaw += (e.clientX - dragX) * 0.01;
    if (dragY !== null) camPT = clampN(camPT + (e.clientY - dragY) * 0.01, PITCH_MIN, PITCH_MAX);   // jari turun → kamera naik (orbit), skala sama dengan kiri/kanan
    dragX = e.clientX; dragY = e.clientY;
  }
});
// kursor keluar jendela / tab tak aktif → kembali menatap penonton
document.documentElement.addEventListener('pointerleave', () => { A.lastMove = -99; });
addEventListener('blur', () => { A.lastMove = -99; });

let visible = true;
new IntersectionObserver(en => { visible = en[0].isIntersecting; }, { threshold: 0 }).observe(stage);
const clock = new THREE.Clock();
renderer.setAnimationLoop(() => {
  const dt = Math.min(clock.getDelta(), 0.1);
  if (!cur || !visible || modelOff || document.hidden) return;
  t += dt;
  yaw += (targetYaw - yaw) * Math.min(1, dt * 6); pivot.rotation.y = yaw;
  camP = damp(camP, camPT, 9, dt); camZ = damp(camZ, camZT, 9, dt); applyCam();
  fl.ring.rotation.z -= dt * 0.12;
  if (cur.kind === 'vrm') animateVRM(dt); else animatePMX(dt);
  renderer.render(scene, camera);
  updateBeatFloor();
});

setModelOff(modelOff, true);
// muat otomatis: model tersimpan, lalu models/model.vrm
(async () => {
  const saved = await idbGet();
  if (Array.isArray(saved) && saved.length) {
    const list = saved.map(s => new File([s.b], s.n)); if (await loadFiles(list, false)) return;
  } else if (saved instanceof Blob) { try { await loadVRM(saved); return; } catch (e) {} }
  try { const r = await fetch('models/model.vrm', { cache: 'no-cache' }); if (r.ok) await loadVRM(await r.blob()); } catch (e) {}
})();
