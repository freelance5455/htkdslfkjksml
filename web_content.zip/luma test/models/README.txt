Beranda memuat model 3D dari tombol "Muat model" (VRM, GLB, PMX, PMD, atau ZIP berisi model beserta teksturnya).
Untuk PMX: pilih file .pmx bersama semua file teksturnya sekaligus, atau satu ZIP.
Model yang dipilih tersimpan di perangkat. Opsional: taruh model.vrm di folder ini agar dimuat otomatis.
