LUMA – Kartu Profil v11.1
=========================

Aplikasi web (PWA) berisi kartu profil, pemutar musik, video, penampil model 3D (VRM/GLB/PMX),
chat AI, pencarian web, dan alat harian (catatan, tugas, cuaca, konversi, mode fokus, hitung skor).

Ada DUA cara memakai chat AI & pencarian. Pilih salah satu (atau pakai keduanya):

A) API key langsung di aplikasi (paling mudah, pemakaian pribadi)
-----------------------------------------------------------------
   - Chat → ikon kunci → isi API key Gemini / Groq / OpenAI (boleh beberapa, satu per baris)
     dan Google Search (API key + CX).
   - Key disimpan di browser perangkat ini (localStorage, TANPA enkripsi) dan dipanggil langsung
     dari browser, jadi backend tidak wajib dijalankan.
   - Jika satu key kena batas (429) atau ditolak (401/403), key berikutnya dicoba otomatis.
   - Pakai hanya di perangkat pribadi. Jangan di perangkat bersama atau komputer umum.
   - Kalau LUMA di-host publik, ingat: siapa pun yang membuka perangkat/browsermu bisa membaca key itu.

B) Lewat backend (key tetap di komputer, tidak di browser)
----------------------------------------------------------
   Jalankan DUA proses:

   1) Backend
      cd backend
      cp config.example.env config.env
      # edit config.env → isi key AI (GEMINI_API_KEY / GROQ_API_KEY / OPENAI_API_KEY)
      # dan (opsional) GOOGLE_API_KEY + GOOGLE_CX untuk pencarian
      python3 server.py
      # http://127.0.0.1:8787  (hanya dari komputer ini)

   2) Frontend LUMA (dari folder induk)
      python3 -m http.server 8080
      # http://localhost:8080

   Di LUMA: Chat → ikon kunci → bagian "Backend": isi Alamat backend + Token akses → Simpan → Tes koneksi.
   Jika key sudah diisi di aplikasi (cara A), backend hanya menjadi cadangan.

   Dari PONSEL (Wi-Fi yang sama):
      - Backend:   HOST=0.0.0.0 python3 server.py     (atau HOST=0.0.0.0 di config.env)
      - Frontend:  python3 -m http.server 8080 --bind 0.0.0.0
      - Buka http://IP-KOMPUTER:8080 di ponsel. Alamat backend harus IP komputer (bukan localhost),
        mis. http://192.168.1.5:8787. Alamat server pencarian otomatis http://IP-KOMPUTER:8787;
        bisa diubah di Cari → "Server pencarian".
      - Jika LUMA di-host lewat HTTPS, backend juga harus HTTPS (browser memblokir HTTP dari halaman HTTPS).
      - HTTP biasa tidak terenkripsi; di luar Wi-Fi rumah gunakan HTTPS.

   Keamanan backend:
      - Mendengarkan 127.0.0.1 secara default.
      - Semua /api/* butuh TOKEN AKSES (header Authorization: Bearer <token>). Token dibuat otomatis
        saat backend pertama dijalankan (disimpan di backend/.access_token dan dicetak di terminal),
        atau isi ACCESS_TOKEN sendiri di config.env (min. 16 karakter).
      - Token salah dibatasi 10 percobaan/menit/IP, origin asing ditolak, body chat maks 32 KB.
      - CORS hanya untuk localhost, jaringan lokal, dan origin di ALLOW_ORIGINS.
      - Cache pencarian 10 menit, batas 20 pencarian/menit/IP, batas harian 90 (atur di config.env).
      - Token disimpan di browser (localStorage). Itu bukan API key penyedia AI, tapi tetap jangan
        dipakai di perangkat bersama. Ganti token dengan mengubah ACCESS_TOKEN / hapus .access_token
        lalu restart backend.
      - .gitignore mengecualikan config.env, .env, dan .access_token. Jangan commit file itu.

   Kunci AI di backend:
      - Ambil key: Gemini https://aistudio.google.com/apikey , Groq https://console.groq.com/keys ,
        OpenAI https://platform.openai.com/api-keys (berbayar per token)
      - Nama model diganti lewat GEMINI_MODEL / GROQ_MODEL / OPENAI_MODEL di config.env.
      - Di chat ada pilihan "Mesin AI": Otomatis (Gemini, lalu Groq, lalu OpenAI), Gemini, Groq, atau OpenAI.

   Detail setup backend: backend/README.md

Privasi
-------
   Isi chat dikirim ke Google/Groq/OpenAI (langsung dari browser atau lewat backend-mu); baca kebijakan data
   tiap layanan (tier gratis Gemini dapat dipakai Google untuk meningkatkan produk).
   Tanpa key/backend: UI tetap ada, chat menampilkan pesan error dengan tombol "Coba lagi".

Perintah di chat (jalan lokal tanpa memanggil AI)
-------------------------------------------------
Musik (butuh lagu yang sudah ditambahkan di pemutar):
   "putar musik", "putar lagu <judul>", "jeda musik" / "pause", "lagu berikutnya", "lagu sebelumnya"
Mode fokus:
   "mode fokus" (buka), "mulai fokus 25 menit" (buka + atur durasi + mulai), "keluar mode fokus"
Kalimat tanya (diawali apa/bagaimana/kenapa, dst.) tetap dijawab AI.

Migrasi dari versi lama
-----------------------
Data lokal dengan nama kunci lama (arumi-* / zuvex-*) dipindahkan otomatis ke luma-* saat v11.1 dibuka
pertama kali (localStorage dan IndexedDB: media & model 3D). Key AI lama yang pernah tersimpan di browser
lewat versi v3.6 (zuvex-ai-keys) dihapus otomatis.

Struktur folder
---------------
index.html            halaman utama (HTML)
manifest.webmanifest  data PWA (nama, ikon, warna)
sw.js                 service worker (harus di root agar mencakup seluruh situs)
assets/css/           style.css
assets/js/            app.js (aplikasi), vrm.js (penampil model 3D)
assets/icons/         favicon, ikon PWA, ikon iOS
assets/images/        gambar & logo
models/               model 3D (.vrm/.glb/.pmx); model.vrm di sini dimuat otomatis
media/music/          4 lagu bawaan (morning_on_the_green_hill, sabar_menanti_pagi,
                      secangkir_kopi_dingin, rehat_sejenak — .mp3, TARUH SENDIRI di folder ini);
                      daftar di konstanta BUILTIN pada assets/js/app.js
media/video/          arsip video (belum dimuat otomatis)
backend/              server Python untuk chat AI, pencarian, dan proxy suara (Fish Audio)

Catatan versi
-------------
Versi aplikasi (judul, meta, manifest, service worker, cache) dan backend memakai nomor yang sama: 11.1.
Naikkan VERSION di sw.js dan "?v=" di index.html bersamaan setiap kali ada rilis.
