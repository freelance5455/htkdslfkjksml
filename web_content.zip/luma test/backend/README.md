Backend pencarian LUMA (Programmable Search)
==============================================

1) Buat Search Engine
   https://programmablesearchengine.google.com/
   - Create → cari di seluruh web (Search the entire web)
   - Salin "Search engine ID" (cx)

2) API key Google Cloud
   https://console.cloud.google.com/
   - Aktifkan "Custom Search API"
   - Buat API key
   - (Opsional) batasi key ke Custom Search API saja

3) Konfigurasi
   cp config.example.env config.env      # atau: cp .env.example .env
   # edit → isi key AI dan (opsional) GOOGLE_API_KEY + GOOGLE_CX
   # ACCESS_TOKEN boleh dikosongkan: dibuat otomatis di backend/.access_token

4) Jalankan backend
   python3 server.py
   # default http://127.0.0.1:8787 (hanya komputer ini)
   # untuk ponsel di Wi-Fi yang sama: HOST=0.0.0.0 python3 server.py

5) Jalankan LUMA (folder induk)
   cd ..
   python3 -m http.server 8080
   # buka http://localhost:8080

Kuota gratis Google biasanya ~100 query/hari.

Catatan: Google dikabarkan menutup Custom Search JSON API untuk pelanggan baru; cek ketersediaannya di console sebelum membuat key.
Batas bawaan: 20 pencarian/menit/IP dan 90/hari (DAILY_LIMIT), hasil di-cache 10 menit.

Token akses (v3.6)
------------------
Semua /api/* butuh header  Authorization: Bearer <token>.  Contoh uji:
   curl -H "Authorization: Bearer $(cat .access_token)" http://127.0.0.1:8787/api/status
/health publik hanya mengembalikan status minimum.

Suara Fish Audio (proxy)
------------------------
Jika browser memblokir panggilan langsung ke Fish Audio (CORS), LUMA otomatis memakai
POST /api/tts di backend ini. API key Fish Audio dikirim dari aplikasi per permintaan dan
tidak disimpan di server. Pastikan backend jalan dan token akses sudah diisi di LUMA → Chat → ikon kunci.
