#!/usr/bin/env python3
"""LUMA backend v11.1 — proxy pencarian Google + chat AI (Gemini, Groq & OpenAI).

Perubahan v11.1: nomor versi diselaraskan dengan aplikasi (tanpa perubahan perilaku).

Perubahan v3.6 (keamanan):
  - Semua endpoint /api/* wajib token akses (header Authorization: Bearer <token>).
    Token dari ACCESS_TOKEN di config.env/.env; jika kosong dibuat otomatis di backend/.access_token
  - Percobaan token salah dibatasi per IP; perbandingan token constant-time
  - Origin diperiksa untuk GET dan POST (termasuk capacitor://localhost untuk aplikasi Android)
  - /health publik hanya memberi status minimum; detail konfigurasi ada di GET /api/status (butuh token)

Perubahan v3.1: tambah penyedia OpenAI (GPT-6 Luna, id gpt-6-luna) lewat OPENAI_API_KEY.

Perubahan v2.9: batas jawaban Gemini 1024 token (model berpikir memakai token ini), tangani MAX_TOKENS.

Perubahan v2.4:
  - Default hanya mendengarkan 127.0.0.1 (HOST=0.0.0.0 untuk akses dari ponsel di Wi-Fi yang sama)
  - CORS dibatasi: localhost, jaringan lokal, dan origin di ALLOW_ORIGINS
  - Cache hasil + batas per menit per IP + batas harian (melindungi kuota gratis ~100/hari)
  - Pesan error dari Google diringkas

Endpoint:
  GET  /api/search?q=kata+kunci      (token)
  POST /api/chat   {provider: auto|gemini|groq|openai, system, messages:[{role,content}]}   (token)
  GET  /api/status                   (token)
  GET  /health                       (publik, minimal)

API key penyedia AI hanya hidup di server (config.env / .env / environment variable), tidak pernah dikirim ke klien.
"""
from __future__ import annotations

import hmac
import json
import os
import re
import secrets
import time
import threading
import urllib.error
import urllib.parse
import urllib.request
from collections import OrderedDict, defaultdict, deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def load_env():
    # urutan prioritas: environment variable > config.env > .env
    for name in ("config.env", ".env"):
        cfg = ROOT / name
        if not cfg.exists():
            continue
        for line in cfg.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            k, v = k.strip(), v.strip().strip('"').strip("'")
            if k and k not in os.environ:
                os.environ[k] = v


load_env()

PORT = int(os.environ.get("PORT", "8787"))
HOST = os.environ.get("HOST", "127.0.0.1").strip() or "127.0.0.1"
API_KEY = os.environ.get("GOOGLE_API_KEY", "").strip()
CX = os.environ.get("GOOGLE_CX", "").strip()
ALLOW_ORIGINS = {o.strip().rstrip("/") for o in os.environ.get("ALLOW_ORIGINS", "").split(",") if o.strip()}
DAILY_LIMIT = int(os.environ.get("DAILY_LIMIT", "90"))
PER_MIN_LIMIT = int(os.environ.get("PER_MIN_LIMIT", "20"))
CACHE_TTL = int(os.environ.get("CACHE_TTL", "600"))
CACHE_MAX = 200

GEMINI_KEY = os.environ.get("GEMINI_API_KEY", "").strip()
GROQ_KEY = os.environ.get("GROQ_API_KEY", "").strip()
OPENAI_KEY = os.environ.get("OPENAI_API_KEY", "").strip()
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-flash-latest").strip()
GROQ_MODEL = os.environ.get("GROQ_MODEL", "llama-3.3-70b-versatile").strip()
OPENAI_MODEL = os.environ.get("OPENAI_MODEL", "gpt-6-luna").strip()
GEMINI_BASE = os.environ.get("GEMINI_BASE", "https://generativelanguage.googleapis.com/v1beta").rstrip("/")
GROQ_BASE = os.environ.get("GROQ_BASE", "https://api.groq.com/openai/v1").rstrip("/")
OPENAI_BASE = os.environ.get("OPENAI_BASE", "https://api.openai.com/v1").rstrip("/")
FISH_BASE = os.environ.get("FISH_BASE", "https://api.fish.audio").rstrip("/")
CHAT_ORDER = [p.strip().lower() for p in os.environ.get("CHAT_ORDER", "gemini,groq,openai").split(",") if p.strip()]
CHAT_PER_MIN = int(os.environ.get("CHAT_PER_MIN", "15"))

TOKEN_FILE = ROOT / ".access_token"


def load_token():
    """Token akses klien. Urutan: ACCESS_TOKEN env/config > backend/.access_token > dibuat baru."""
    t = os.environ.get("ACCESS_TOKEN", "").strip()
    if t:
        if len(t) < 16:
            raise SystemExit("ACCESS_TOKEN terlalu pendek (minimal 16 karakter).")
        return t, "env"
    try:
        t = TOKEN_FILE.read_text(encoding="utf-8").strip()
        if len(t) >= 16:
            return t, "file"
    except OSError:
        pass
    t = secrets.token_urlsafe(24)
    try:
        fd = os.open(str(TOKEN_FILE), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(t + "\n")
    except OSError:
        pass
    return t, "new"


ACCESS_TOKEN, TOKEN_SRC = load_token()
_lock = threading.Lock()
_cache: "OrderedDict[str, tuple[float, dict]]" = OrderedDict()
_hits: "defaultdict[str, deque]" = defaultdict(deque)
_day = {"d": time.strftime("%Y-%m-%d"), "n": 0}

LOCAL_RE = re.compile(
    r"^(https?|capacitor|ionic)://(localhost|127\.0\.0\.1|\[::1\]|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|172\.(1[6-9]|2\d|3[01])\.\d+\.\d+)(:\d+)?$"
)


def origin_ok(origin: str) -> bool:
    origin = (origin or "").rstrip("/")
    return bool(origin) and (bool(LOCAL_RE.match(origin)) or origin in ALLOW_ORIGINS)


def cache_get(key):
    with _lock:
        v = _cache.get(key)
        if not v:
            return None
        if time.time() - v[0] > CACHE_TTL:
            _cache.pop(key, None)
            return None
        _cache.move_to_end(key)
        return v[1]


def cache_put(key, val):
    with _lock:
        _cache[key] = (time.time(), val)
        _cache.move_to_end(key)
        while len(_cache) > CACHE_MAX:
            _cache.popitem(last=False)


def rate_ok(ip: str, bucket: str = "s", limit: int = 0) -> bool:
    now = time.time()
    limit = limit or PER_MIN_LIMIT
    with _lock:
        dq = _hits[(bucket, ip)]
        while dq and now - dq[0] > 60:
            dq.popleft()
        if len(dq) >= limit:
            return False
        dq.append(now)
        return True


def daily_take() -> bool:
    with _lock:
        today = time.strftime("%Y-%m-%d")
        if _day["d"] != today:
            _day["d"], _day["n"] = today, 0
        if _day["n"] >= DAILY_LIMIT:
            return False
        _day["n"] += 1
        return True


# ---------------------------------------------------------------- chat AI
class ChatErr(Exception):
    def __init__(self, status, msg):
        super().__init__(msg)
        self.status, self.msg = status, msg


def _post_json(url, headers, body, timeout=25):
    data = json.dumps(body).encode("utf-8")
    h = {"Content-Type": "application/json", "User-Agent": "LUMA-Chat/11.1"}
    h.update(headers)
    req = urllib.request.Request(url, data=data, headers=h, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        msg = ""
        try:
            err = json.loads(e.read().decode("utf-8")).get("error")
            msg = err.get("message", "") if isinstance(err, dict) else str(err or "")
        except Exception:
            pass
        raise ChatErr(e.code, (msg or "ditolak")[:120])
    except Exception:
        raise ChatErr(0, "tidak bisa dihubungi")


def call_gemini(system, msgs):
    contents = [{"role": "user" if m["role"] == "user" else "model", "parts": [{"text": m["content"]}]} for m in msgs]
    body = {
        "systemInstruction": {"parts": [{"text": system}]},
        "contents": contents,
        "generationConfig": {"maxOutputTokens": 1024, "temperature": 0.9},
    }
    d = _post_json("%s/models/%s:generateContent" % (GEMINI_BASE, urllib.parse.quote(GEMINI_MODEL, safe="-._")),
                   {"x-goog-api-key": GEMINI_KEY}, body)
    cands = d.get("candidates") or []
    parts = ((cands[0].get("content") or {}).get("parts") or []) if cands else []
    text = "".join(p.get("text", "") for p in parts).strip()
    finish = cands[0].get("finishReason") if cands else None
    if not text:
        raise ChatErr(0, "jawaban terpotong (batas token)" if finish == "MAX_TOKENS" else "jawaban kosong atau diblokir")
    return text + "…" if finish == "MAX_TOKENS" else text


def call_groq(system, msgs):
    body = {
        "model": GROQ_MODEL,
        "messages": [{"role": "system", "content": system}] + msgs,
        "max_tokens": 400,
        "temperature": 0.9,
    }
    d = _post_json(GROQ_BASE + "/chat/completions", {"Authorization": "Bearer " + GROQ_KEY}, body)
    ch = d.get("choices") or []
    text = ((ch[0].get("message") or {}).get("content") or "").strip() if ch else ""
    if not text:
        raise ChatErr(0, "jawaban kosong")
    return text


def call_openai(system, msgs):
    # GPT-6 (model penalar): max_completion_tokens menggantikan max_tokens, tanpa temperature.
    body = {
        "model": OPENAI_MODEL,
        "messages": [{"role": "system", "content": system}] + msgs,
        "max_completion_tokens": 2000,
    }
    if re.match(r"^(gpt-[56]|o\d)", OPENAI_MODEL):
        body["reasoning_effort"] = "low"
    d = _post_json(OPENAI_BASE + "/chat/completions", {"Authorization": "Bearer " + OPENAI_KEY}, body, timeout=40)
    ch = d.get("choices") or []
    text = ((ch[0].get("message") or {}).get("content") or "").strip() if ch else ""
    finish = ch[0].get("finish_reason") if ch else None
    if not text:
        raise ChatErr(0, "kehabisan token sebelum selesai" if finish == "length" else "jawaban kosong")
    return text + "…" if finish == "length" else text


PROVIDERS = {
    "gemini": (lambda: bool(GEMINI_KEY), call_gemini),
    "groq": (lambda: bool(GROQ_KEY), call_groq),
    "openai": (lambda: bool(OPENAI_KEY), call_openai),
}


def clean_msgs(raw):
    out = []
    for m in (raw if isinstance(raw, list) else [])[-12:]:
        if not isinstance(m, dict):
            continue
        role = "user" if m.get("role") == "user" else "assistant" if m.get("role") == "assistant" else None
        content = str(m.get("content") or "").strip()[:1000]
        if role and content:
            out.append({"role": role, "content": content})
    while out and out[0]["role"] != "user":
        out.pop(0)
    return out if out and out[-1]["role"] == "user" else []


def fish_tts(key, text, ref, model):
    """Teruskan permintaan TTS ke Fish Audio (key dikirim klien, tidak disimpan di server)."""
    body = {"text": text[:600], "format": "mp3", "mp3_bitrate": 128, "latency": "normal"}
    if ref:
        body["reference_id"] = ref
    req = urllib.request.Request(
        FISH_BASE + "/v1/tts", data=json.dumps(body).encode("utf-8"), method="POST",
        headers={"Content-Type": "application/json", "Authorization": "Bearer " + key,
                 "model": model or "s2.1-pro-free", "User-Agent": "LUMA-Chat/11.1"})
    try:
        with urllib.request.urlopen(req, timeout=40) as resp:
            return resp.read()
    except urllib.error.HTTPError as e:
        msg = ""
        try:
            d = json.loads(e.read().decode("utf-8"))
            msg = str(d.get("message") or d.get("detail") or "")
        except Exception:
            pass
        raise ChatErr(e.code, (msg or "ditolak")[:120])
    except Exception:
        raise ChatErr(0, "Fish Audio tidak bisa dihubungi dari server")


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print("[%s] %s" % (self.log_date_time_string(), fmt % args))

    def _cors(self):
        origin = self.headers.get("Origin", "")
        if origin_ok(origin):
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")

    def _json(self, code: int, obj: dict):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self._cors()
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _guard(self):
        """Periksa Origin lalu token. Mengirim error dan mengembalikan False bila ditolak."""
        origin = self.headers.get("Origin", "")
        if origin and not origin_ok(origin):
            self._json(403, {"error": "forbidden", "message": "Origin tidak diizinkan"})
            return False
        h = self.headers.get("Authorization", "")
        tok = h[7:].strip() if h[:7].lower() == "bearer " else ""
        if tok and hmac.compare_digest(tok.encode("utf-8"), ACCESS_TOKEN.encode("utf-8")):
            return True
        if not rate_ok(self.client_address[0], "auth", 10):
            self._json(429, {"error": "rate_limited", "message": "Terlalu banyak percobaan token, tunggu sebentar."})
        else:
            self._json(401, {"error": "unauthorized", "message": "Token akses salah atau belum diisi."})
        return False

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path in ("/", "/health"):
            return self._json(200, {"ok": True, "service": "luma", "version": "11.1", "auth": True})

        if parsed.path not in ("/api/search", "/api/status"):
            return self._json(404, {"error": "not_found"})
        if not self._guard():
            return
        if parsed.path == "/api/status":
            return self._json(200, {"ok": True, "version": "11.1",
                                    "search": bool(API_KEY and CX),
                                    "chat": {"gemini": bool(GEMINI_KEY), "groq": bool(GROQ_KEY), "openai": bool(OPENAI_KEY)}})

        qs = urllib.parse.parse_qs(parsed.query)
        q = (qs.get("q") or [""])[0].strip()[:200]
        if not q:
            return self._json(400, {"error": "empty_query", "message": "Parameter q wajib diisi"})

        if not API_KEY or not CX:
            return self._json(503, {
                "error": "not_configured",
                "message": "Isi GOOGLE_API_KEY dan GOOGLE_CX di backend/config.env"
            })

        ip = self.client_address[0]
        if not rate_ok(ip):
            return self._json(429, {"error": "rate_limited", "message": "Terlalu sering mencari, coba lagi sebentar."})

        key = q.lower()
        hit = cache_get(key)
        if hit:
            return self._json(200, dict(hit, cached=True))

        if not daily_take():
            return self._json(429, {"error": "daily_limit",
                                    "message": "Batas pencarian harian tercapai (melindungi kuota Google)."})

        params = urllib.parse.urlencode({"key": API_KEY, "cx": CX, "q": q, "num": 8, "hl": "id"})
        url = "https://www.googleapis.com/customsearch/v1?" + params
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "LUMA-Search/11.1"})
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            msg = ""
            try:
                msg = (json.loads(e.read().decode("utf-8")).get("error") or {}).get("message", "")
            except Exception:
                pass
            return self._json(502, {"error": "google_http", "status": e.code, "message": (msg or "Google menolak permintaan")[:200]})
        except Exception:
            return self._json(502, {"error": "upstream", "message": "Tidak bisa menghubungi Google"})

        items = [{
            "title": it.get("title") or "",
            "link": it.get("link") or "",
            "snippet": it.get("snippet") or "",
            "displayLink": it.get("displayLink") or "",
        } for it in (data.get("items") or [])]

        out = {
            "query": q,
            "count": len(items),
            "items": items,
            "searchTime": (data.get("searchInformation") or {}).get("formattedSearchTime"),
        }
        cache_put(key, out)
        return self._json(200, out)


    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path not in ("/api/chat", "/api/tts"):
            return self._json(404, {"error": "not_found"})
        if not self._guard():
            return
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = 0
        if n <= 0 or n > 32768:
            return self._json(413 if n > 32768 else 400, {"error": "bad_size", "message": "Ukuran permintaan tidak valid"})
        try:
            body = json.loads(self.rfile.read(n).decode("utf-8"))
        except Exception:
            return self._json(400, {"error": "bad_json", "message": "JSON tidak valid"})

        if parsed.path == "/api/tts":
            key = str(body.get("key") or "").strip()[:300]
            text = str(body.get("text") or "").strip()[:600]
            if not key or not text:
                return self._json(400, {"error": "empty", "message": "Key atau teks kosong"})
            if not rate_ok(self.client_address[0], "tts", 20):
                return self._json(429, {"error": "rate_limited", "message": "Terlalu sering, coba lagi sebentar."})
            try:
                audio = fish_tts(key, text, str(body.get("reference_id") or "").strip()[:100], str(body.get("model") or "").strip()[:40])
            except ChatErr as e:
                print("[tts] fish gagal (%s) %s" % (e.status, e.msg))
                return self._json(502, {"error": "upstream", "message": "Fish Audio %s: %s" % (e.status or "-", e.msg)})
            self.send_response(200)
            self.send_header("Content-Type", "audio/mpeg")
            self._cors()
            self.send_header("Content-Length", str(len(audio)))
            self.end_headers()
            self.wfile.write(audio)
            return

        avail = [p for p in CHAT_ORDER if p in PROVIDERS and PROVIDERS[p][0]()]
        if not avail:
            return self._json(503, {"error": "not_configured",
                                    "message": "Isi GEMINI_API_KEY, GROQ_API_KEY, dan/atau OPENAI_API_KEY di backend/config.env"})
        if not rate_ok(self.client_address[0], "chat", CHAT_PER_MIN):
            return self._json(429, {"error": "rate_limited", "message": "Terlalu sering, coba lagi sebentar."})

        msgs = clean_msgs(body.get("messages"))
        if not msgs:
            return self._json(400, {"error": "empty", "message": "Pesan kosong"})
        system = str(body.get("system") or "Kamu asisten yang ramah. Jawab singkat dalam bahasa Indonesia.")[:6000]

        want = str(body.get("provider") or "auto").lower()
        order = ([want] if want in avail else []) + [p for p in avail if p != want]
        errs = []
        for p in order:
            try:
                text = PROVIDERS[p][1](system, msgs)[:1500]
                return self._json(200, {"text": text, "provider": p.capitalize()})
            except ChatErr as e:
                errs.append("%s: %s" % (p, e.msg))
                print("[chat] %s gagal (%s) %s" % (p, e.status, e.msg))
        return self._json(502, {"error": "upstream", "message": "Semua penyedia AI gagal (" + "; ".join(errs)[:200] + ")"})


def main():
    httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    print("LUMA backend v11.1 di http://%s:%s" % (HOST, PORT))
    print("  Health:  GET /health")
    print("  Search:  GET /api/search?q=...   (Google dikonfigurasi: %s)" % bool(API_KEY and CX))
    print("  Suara:   POST /api/tts           (proxy Fish Audio, key dari aplikasi)")
    print("  Chat:    POST /api/chat          (Gemini: %s, Groq: %s, OpenAI: %s)" % (bool(GEMINI_KEY), bool(GROQ_KEY), bool(OPENAI_KEY)))
    print("  Auth:    token akses wajib (sumber: %s)" % TOKEN_SRC)
    if TOKEN_SRC == "new":
        print("  Token BARU dibuat. Salin ke LUMA → Chat → ikon kunci:")
    if TOKEN_SRC in ("file", "new"):
        print("  TOKEN:   " + ACCESS_TOKEN)
    if HOST not in ("127.0.0.1", "localhost", "::1"):
        print("  PERHATIAN: HOST=%s — dapat diakses dari jaringan. Lalu lintas HTTP biasa tidak terenkripsi;" % HOST)
        print("             untuk akses di luar Wi-Fi rumah pakai HTTPS (reverse proxy / tunnel).")
    if not (API_KEY and CX) and not (GEMINI_KEY or GROQ_KEY or OPENAI_KEY):
        print("  WARNING: config.env belum diisi — salin config.example.env → config.env")
    httpd.serve_forever()


if __name__ == "__main__":
    main()
