Folder musik.
Empat lagu bawaan (musik awal) ada di sini dan otomatis masuk daftar pemutar:
morning_on_the_green_hill.mp3, sabar_menanti_pagi.mp3, secangkir_kopi_dingin.mp3, rehat_sejenak.mp3
Daftar & judulnya diatur di konstanta BUILTIN di assets/js/app.js.
Lagu tambahan dari ponsel lewat tombol "Tambah lagu dari ponsel" di pemutar disimpan di perangkat (IndexedDB).
