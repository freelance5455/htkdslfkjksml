Folder video.
Taruh file video (mp4, webm) di sini sebagai arsip.
Saat ini video dipilih lewat tombol "Pilih video" di tab Video dan disimpan di perangkat (IndexedDB), belum dimuat otomatis dari folder ini.
