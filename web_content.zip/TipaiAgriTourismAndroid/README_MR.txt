TIPAI AGRI TOURISM – Android WebView प्रोजेक्ट

महत्त्वाची नोंद:
या ZIP मध्ये तुमची HTML फाईल Android अॅपमध्ये चालवण्यासाठी WebView प्रोजेक्टमध्ये ठेवली आहे.
ही ZIP स्वतः APK फाईल नाही. या वातावरणात Android SDK/Gradle build साधने उपलब्ध नसल्यामुळे
इथे तयार आणि चाचणी केलेली APK फाईल बनवता आली नाही.

APK तयार करण्यासाठी:
1. ZIP संगणकावर डाउनलोड करून extract करा.
2. Android Studio मध्ये 'TipaiAgriTourismAndroid' फोल्डर Open करा.
3. Gradle sync पूर्ण होऊ द्या (Android SDK Platform 35 व Android Gradle Plugin डाउनलोड लागू शकते).
4. Build > Build Bundle(s) / APK(s) > Build APK(s) निवडा.
5. APK साधारणपणे app/build/outputs/apk/debug/app-debug.apk येथे तयार होईल.
6. APK फोनमध्ये पाठवून install करा. फोनवर unknown apps install करण्याची परवानगी मागितल्यास
   फक्त स्वतः तयार केलेल्या/विश्वसनीय APK साठीच परवानगी द्या.

टीप:
मूळ HTML फाईल जशी मिळाली तशीच assets/index.html मध्ये ठेवली आहे. प्रत्यक्ष APK बनवल्यानंतर
मोबाईलवर calculator, export आणि WhatsApp संबंधित सर्व सुविधा तपासून घ्या.
