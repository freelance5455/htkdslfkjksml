JAFFNARIDE APK PROJECT

This is an Android Studio project wrapping the supplied JaffnaRide HTML app.
It includes Android location permissions and WebView geolocation support.

Build:
1. Open this folder in Android Studio on a computer.
2. Let Gradle sync.
3. Build > Build APK(s).

The HTML is app/src/main/assets/index.html.
The launcher icon is app/src/main/res/drawable/jr_icon.png.

Important: Supabase and map services remain online/HTTPS. The APK itself does not need a separate website host for the HTML.
