const videoInput = document.getElementById("videoInput");
const uploadSection = document.getElementById("uploadSection");
const editorSection = document.getElementById("editorSection");
const resetBtn = document.getElementById("resetBtn");

const origInfoEl = document.getElementById("origInfo");
const outInfoEl = document.getElementById("outInfo");
const sourceVideo = document.getElementById("sourceVideo");
const previewCanvas = document.getElementById("previewCanvas");
const pCtx = previewCanvas.getContext("2d");

const modeTag = document.getElementById("modeTag");
const playPauseBtn = document.getElementById("playPauseBtn");
const seekBar = document.getElementById("seekBar");
const timeLabel = document.getElementById("timeLabel");
const compareBtn = document.getElementById("compareBtn");

const resRow = document.getElementById("resRow");
const presetRow = document.getElementById("presetRow");
const sharpRange = document.getElementById("sharpRange");
const contrastRange = document.getElementById("contrastRange");
const satRange = document.getElementById("satRange");
const brightRange = document.getElementById("brightRange");

const valSharp = document.getElementById("valSharp");
const valContrast = document.getElementById("valContrast");
const valSat = document.getElementById("valSat");
const valBright = document.getElementById("valBright");
const sharpenMatrix = document.getElementById("sharpenMatrix");

const exportBtn = document.getElementById("exportBtn");
const manualDownloadLink = document.getElementById("manualDownloadLink");
const renderOverlay = document.getElementById("renderOverlay");
const renderTitle = document.getElementById("renderTitle");
const progressFill = document.getElementById("progressFill");
const renderPct = document.getElementById("renderPct");
const cancelRenderBtn = document.getElementById("cancelRenderBtn");
const statusMsg = document.getElementById("statusMsg");

const PRESETS = {
  auto: { sharp: 55, contrast: 18, sat: 24, bright: 4 },
  anime: { sharp: 82, contrast: 24, sat: 38, bright: 4 },
  hdr: { sharp: 70, contrast: 38, sat: 42, bright: 6 },
  bright: { sharp: 45, contrast: 12, sat: 16, bright: 16 }
};

let videoUrl = null;
let selectedRes = "1080";
let showOriginal = false;
let animFrameId = null;
let isRendering = false;
let activeRecorder = null;
let renderCancelled = false;
let audioCtx = null;
let audioSourceNode = null;
let audioDestNode = null;
let lastExportUrl = null;

function formatTime(sec) {
  if (!isFinite(sec) || sec < 0) return "0:00";
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s < 10 ? "0" : ""}${s}`;
}

function updateSharpenKernel() {
  const s = parseInt(sharpRange.value, 10) / 100; // 0 to 1
  const edge = -(s * 0.85);
  const center = 1 - 4 * edge;
  const k = `0 ${edge.toFixed(3)} 0 ${edge.toFixed(3)} ${center.toFixed(3)} ${edge.toFixed(3)} 0 ${edge.toFixed(3)} 0`;
  sharpenMatrix.setAttribute("kernelMatrix", k);
}

function getFilterString() {
  const contrast = 100 + parseInt(contrastRange.value, 10);
  const sat = 100 + parseInt(satRange.value, 10);
  const bright = 100 + parseInt(brightRange.value, 10);
  const sharp = parseInt(sharpRange.value, 10);
  const base = `brightness(${bright}%) contrast(${contrast}%) saturate(${sat}%)`;
  return sharp > 3 ? `url(#sharpenFilter) ${base}` : base;
}

function updateSliderLabels() {
  valSharp.textContent = `${sharpRange.value}%`;
  valContrast.textContent = `${contrastRange.value}%`;
  valSat.textContent = `${satRange.value}%`;
  valBright.textContent = `${brightRange.value}%`;
  updateSharpenKernel();
}

function getOutputDimensions() {
  const vw = sourceVideo.videoWidth || 720;
  const vh = sourceVideo.videoHeight || 1280;
  if (selectedRes === "orig") return { width: vw, height: vh };

  const targetLong = selectedRes === "2k" ? 2560 : 1920;
  const curLong = Math.max(vw, vh);
  const ratio = targetLong / curLong;

  // Ensure even dimensions for video encoders
  const w = Math.max(2, Math.round((vw * ratio) / 2) * 2);
  const h = Math.max(2, Math.round((vh * ratio) / 2) * 2);
  return { width: w, height: h };
}

function updateResolutionLabels() {
  if (!sourceVideo.videoWidth) return;
  const out = getOutputDimensions();
  origInfoEl.textContent = `${sourceVideo.videoWidth} × ${sourceVideo.videoHeight}`;
  outInfoEl.textContent = `${out.width} × ${out.height}`;
}

function drawPreviewFrame() {
  if (!sourceVideo.videoWidth || isRendering) return;
  pCtx.imageSmoothingEnabled = true;
  pCtx.imageSmoothingQuality = "high";
  pCtx.filter = showOriginal ? "none" : getFilterString();
  pCtx.drawImage(sourceVideo, 0, 0, previewCanvas.width, previewCanvas.height);
  pCtx.filter = "none";

  if (sourceVideo.duration) {
    seekBar.value = (sourceVideo.currentTime / sourceVideo.duration) * 100;
    timeLabel.textContent = formatTime(sourceVideo.currentTime);
  }
}

function previewLoop() {
  drawPreviewFrame();
  if (!sourceVideo.paused && !sourceVideo.ended && !isRendering) {
    animFrameId = requestAnimationFrame(previewLoop);
  }
}

// File Upload
videoInput.addEventListener("change", (e) => {
  const file = e.target.files && e.target.files[0];
  if (!file) return;

  if (videoUrl) URL.revokeObjectURL(videoUrl);
  videoUrl = URL.createObjectURL(file);
  sourceVideo.src = videoUrl;
  sourceVideo.load();
  manualDownloadLink.classList.add("hidden");
  statusMsg.textContent = "Loading video...";
});

sourceVideo.addEventListener("loadedmetadata", () => {
  const vw = sourceVideo.videoWidth;
  const vh = sourceVideo.videoHeight;

  // Preview canvas capped at 720px for smooth 60fps mobile preview
  const maxPrev = 720;
  let pw = vw;
  let ph = vh;
  if (Math.max(pw, ph) > maxPrev) {
    const r = maxPrev / Math.max(pw, ph);
    pw = Math.round(pw * r);
    ph = Math.round(ph * r);
  }
  previewCanvas.width = pw;
  previewCanvas.height = ph;

  uploadSection.classList.add("hidden");
  editorSection.classList.remove("hidden");
  resetBtn.classList.remove("hidden");
  updateResolutionLabels();

  sourceVideo.currentTime = 0.05;
  statusMsg.textContent = "Video ready! Preset chuno aur Play dabao.";
});

sourceVideo.addEventListener("seeked", () => {
  if (!isRendering) drawPreviewFrame();
});

sourceVideo.addEventListener("ended", () => {
  if (!isRendering) {
    playPauseBtn.textContent = "▶ Play";
  }
});

// Play / Pause
playPauseBtn.addEventListener("click", () => {
  if (isRendering) return;
  if (sourceVideo.paused || sourceVideo.ended) {
    if (sourceVideo.ended) sourceVideo.currentTime = 0;
    sourceVideo.muted = false;
    sourceVideo.play().then(() => {
      playPauseBtn.textContent = "⏸ Pause";
      previewLoop();
    }).catch(() => {
      sourceVideo.muted = true;
      sourceVideo.play();
      playPauseBtn.textContent = "⏸ Pause";
      previewLoop();
    });
  } else {
    sourceVideo.pause();
    playPauseBtn.textContent = "▶ Play";
  }
});

seekBar.addEventListener("input", () => {
  if (!sourceVideo.duration || isRendering) return;
  sourceVideo.currentTime = (seekBar.value / 100) * sourceVideo.duration;
  drawPreviewFrame();
});

// Before / After Toggle
compareBtn.addEventListener("click", () => {
  showOriginal = !showOriginal;
  compareBtn.classList.toggle("active", showOriginal);
  compareBtn.textContent = showOriginal ? "✨ Enhanced" : "👁️ Original";
  modeTag.textContent = showOriginal ? "ORIGINAL" : "ENHANCED";
  modeTag.classList.toggle("orig-mode", showOriginal);
  drawPreviewFrame();
});

// Resolution Selector
resRow.addEventListener("click", (e) => {
  const btn = e.target.closest(".seg-btn");
  if (!btn) return;
  resRow.querySelectorAll(".seg-btn").forEach((b) => b.classList.remove("active"));
  btn.classList.add("active");
  selectedRes = btn.dataset.res;
  updateResolutionLabels();
});

// Presets
presetRow.addEventListener("click", (e) => {
  const btn = e.target.closest(".preset-btn");
  if (!btn) return;
  presetRow.querySelectorAll(".preset-btn").forEach((b) => b.classList.remove("active"));
  btn.classList.add("active");
  const p = PRESETS[btn.dataset.preset];
  if (p) {
    sharpRange.value = p.sharp;
    contrastRange.value = p.contrast;
    satRange.value = p.sat;
    brightRange.value = p.bright;
    updateSliderLabels();
    drawPreviewFrame();
  }
});

// Sliders
[sharpRange, contrastRange, satRange, brightRange].forEach((sl) => {
  sl.addEventListener("input", () => {
    updateSliderLabels();
    drawPreviewFrame();
  });
});

// Pick best supported MediaRecorder MIME type
function getBestMimeType() {
  const types = [
    "video/mp4;codecs=avc1.42E01E,mp4a.40.2",
    "video/mp4",
    "video/webm;codecs=vp9,opus",
    "video/webm;codecs=vp8,opus",
    "video/webm"
  ];
  for (const t of types) {
    if (window.MediaRecorder && MediaRecorder.isTypeSupported(t)) {
      return t;
    }
  }
  return "";
}

// Export Enhanced Video with Audio
exportBtn.addEventListener("click", async () => {
  if (!sourceVideo.videoWidth || isRendering) return;
  if (!window.MediaRecorder) {
    statusMsg.textContent = "Aapka browser video export support nahi karta. Chrome update karo.";
    return;
  }

  isRendering = true;
  renderCancelled = false;
  exportBtn.disabled = true;
  manualDownloadLink.classList.add("hidden");
  sourceVideo.pause();
  playPauseBtn.textContent = "▶ Play";

  const dims = getOutputDimensions();
  const outCanvas = document.createElement("canvas");
  outCanvas.width = dims.width;
  outCanvas.height = dims.height;
  const oCtx = outCanvas.getContext("2d");

  renderTitle.textContent = `Rendering ${dims.width}×${dims.height}...`;
  progressFill.style.width = "0%";
  renderPct.textContent = "0%";
  renderOverlay.classList.remove("hidden");
  statusMsg.textContent = "Enhancing video... Screen band mat karna.";

  try {
    const stream = outCanvas.captureStream(30);

    // Attach original audio track via Web Audio API
    try {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (AudioContextClass) {
        if (!audioCtx) {
          audioCtx = new AudioContextClass();
          audioSourceNode = audioCtx.createMediaElementSource(sourceVideo);
          audioDestNode = audioCtx.createMediaStreamDestination();
          audioSourceNode.connect(audioDestNode);
        }
        if (audioCtx.state === "suspended") await audioCtx.resume();
        audioDestNode.stream.getAudioTracks().forEach((track) => stream.addTrack(track));
      }
    } catch (audioErr) {
      // Proceed with video-only if audio capture is restricted
    }

    const mimeType = getBestMimeType();
    const isMp4 = mimeType.includes("mp4");
    const bitrate = selectedRes === "2k" ? 12000000 : selectedRes === "1080" ? 8000000 : 6000000;
    const options = mimeType ? { mimeType, videoBitsPerSecond: bitrate } : { videoBitsPerSecond: bitrate };

    const chunks = [];
    const recorder = new MediaRecorder(stream, options);
    activeRecorder = recorder;

    recorder.ondataavailable = (ev) => {
      if (ev.data && ev.data.size > 0) chunks.push(ev.data);
    };

    recorder.onstop = () => {
      isRendering = false;
      activeRecorder = null;
      exportBtn.disabled = false;
      renderOverlay.classList.add("hidden");

      if (renderCancelled) {
        statusMsg.textContent = "Export cancelled.";
        drawPreviewFrame();
        return;
      }

      const blob = new Blob(chunks, { type: mimeType || "video/webm" });
      if (lastExportUrl) URL.revokeObjectURL(lastExportUrl);
      lastExportUrl = URL.createObjectURL(blob);

      const ext = isMp4 ? "mp4" : "webm";
      const fileName = `SAHIL_${selectedRes.toUpperCase()}_${Date.now()}.${ext}`;

      manualDownloadLink.href = lastExportUrl;
      manualDownloadLink.download = fileName;
      manualDownloadLink.classList.remove("hidden");

      const a = document.createElement("a");
      a.href = lastExportUrl;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      statusMsg.textContent = `✅ Enhanced Video Saved (${dims.width}×${dims.height} .${ext.toUpperCase()})!`;
      drawPreviewFrame();
    };

    // Seek to start and play
    sourceVideo.muted = false;
    sourceVideo.currentTime = 0;

    await new Promise((resolve) => {
      const onSeeked = () => {
        sourceVideo.removeEventListener("seeked", onSeeked);
        resolve();
      };
      sourceVideo.addEventListener("seeked", onSeeked);
    });

    recorder.start(200);
    await sourceVideo.play();

    const filterStr = getFilterString();

    function renderStep() {
      if (renderCancelled) {
        sourceVideo.pause();
        if (recorder.state !== "inactive") recorder.stop();
        return;
      }

      oCtx.imageSmoothingEnabled = true;
      oCtx.imageSmoothingQuality = "high";
      oCtx.filter = filterStr;
      oCtx.drawImage(sourceVideo, 0, 0, dims.width, dims.height);
      oCtx.filter = "none";

      // Mirror to preview canvas
      pCtx.drawImage(outCanvas, 0, 0, previewCanvas.width, previewCanvas.height);

      if (sourceVideo.duration) {
        const pct = Math.min(100, Math.round((sourceVideo.currentTime / sourceVideo.duration) * 100));
        progressFill.style.width = `${pct}%`;
        renderPct.textContent = `${pct}%`;
      }

      if (sourceVideo.ended || sourceVideo.paused) {
        progressFill.style.width = "100%";
        renderPct.textContent = "100%";
        if (recorder.state !== "inactive") recorder.stop();
        return;
      }

      requestAnimationFrame(renderStep);
    }

    requestAnimationFrame(renderStep);
  } catch (err) {
    isRendering = false;
    exportBtn.disabled = false;
    renderOverlay.classList.add("hidden");
    statusMsg.textContent = "Error: 1080p HD ya Original quality try karo.";
  }
});

cancelRenderBtn.addEventListener("click", () => {
  renderCancelled = true;
  sourceVideo.pause();
  if (activeRecorder && activeRecorder.state !== "inactive") {
    activeRecorder.stop();
  }
});

// Reset
resetBtn.addEventListener("click", () => {
  if (isRendering) return;
  sourceVideo.pause();
  cancelAnimationFrame(animFrameId);
  videoInput.value = "";
  editorSection.classList.add("hidden");
  resetBtn.classList.add("hidden");
  uploadSection.classList.remove("hidden");
  manualDownloadLink.classList.add("hidden");
  statusMsg.textContent = "";
});

updateSliderLabels();
