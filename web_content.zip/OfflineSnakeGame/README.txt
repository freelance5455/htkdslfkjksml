Snake Rush - Offline Game

This is a self-contained offline HTML5 game. Open index.html in a browser to play.
For ZIP-to-APK builders, upload this ZIP with index.html in the ZIP root and choose index.html as the start page if asked.
No external libraries, images, fonts, APIs, or network access are required.
Controls: tap arrows, swipe on the board, or use keyboard arrow keys. Eat the pink food, avoid walls and your own body. Score and best score are shown.

Note: APK builders differ. A ZIP is source project, not an APK, and a third-party builder may still require its own settings.
