CS Tarabalam Chandra + Hora Chakra — Online-only build

This build intentionally requires internet access.
- Moon Nakshatra/Pada and entry/exit times are calculated using Astronomy Engine loaded online from jsDelivr.
- Sunrise/sunset are obtained online from sunrise-sunset.org.
- No moonTransitDB.json is used.
- The service worker does not cache application/data files.
- If internet is unavailable, the daily calculation displays an error and asks the user to retry.

Chandra uses sidereal longitude with a Lahiri ayanamsa approximation. Exact boundary times can vary slightly from a Panchanga provider due to ephemeris/ayanamsa conventions.
