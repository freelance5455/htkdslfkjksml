/**
 * ui.js - UI rendering utilities for Tarabalam PWA
 * Fixed: Added imports, ES module exports, content display
 */

import { loadUserProfile, loadMoonOverride } from './storage.js';

function showLoader(message = 'లోడ్ అవుతోంది...') {
  const loaderContainer = document.getElementById('loaderContainer');
  const content = document.getElementById('content');
  
  if (loaderContainer) {
    loaderContainer.style.display = 'block';
    const loaderText = loaderContainer.querySelector('.loader-text');
    if (loaderText) loaderText.textContent = message;
  }
  if (content) content.style.display = 'none';
}

function hideLoader() {
  const loaderContainer = document.getElementById('loaderContainer');
  if (loaderContainer) loaderContainer.style.display = 'none';
}

function showError(message, isFatal = false) {
  hideLoader();
  const content = document.getElementById('content');
  if (content) content.style.display = 'none';
  
  let errorDiv = document.querySelector('.error-message');
  if (!errorDiv) {
    errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    const container = document.querySelector('.container');
    if (container) container.insertBefore(errorDiv, container.firstChild);
  }
  
  errorDiv.innerHTML = `
    <p>⚠️ ${message}</p>
    ${isFatal ? '<button class="btn-primary" onclick="location.reload()">మళ్లీ ప్రయత్నించండి</button>' : ''}
  `;
  errorDiv.style.display = 'block';
}

function clearError() {
  const errorDiv = document.querySelector('.error-message');
  if (errorDiv) errorDiv.style.display = 'none';
}

function renderStars(rating) {
  const fullStar = '★', emptyStar = '☆';
  let stars = '';
  for (let i = 1; i <= 5; i++) stars += i <= rating ? fullStar : emptyStar;
  return stars;
}

function getStatusClass(status) {
  const classes = { 'excellent': 'status-excellent', 'good': 'status-good', 'caution': 'status-caution', 'bad': 'status-bad' };
  return classes[status] || 'status-normal';
}

function getStatusText(status) {
  const texts = { 'excellent': 'చాలా శుభం', 'good': 'శుభం', 'caution': 'జాగ్రత్త', 'bad': 'అశుభం' };
  return texts[status] || 'సాధారణం';
}

export async function renderTodayScreen(data) {
  if (!data) { showError('డేటా అందుబాటులో లేదు'); return; }
  clearError();
  
  const profile = loadUserProfile();
  const janmaId = profile?.janmaNakshatra;
  
  try {
    const response = await fetch('../database/nakshatraData.json');
    const nakshatras = await response.json();
    const janmaName = nakshatras[janmaId]?.telugu || '-';
    const janmaEl = document.getElementById('janmaValue');
    if (janmaEl) janmaEl.textContent = janmaName;
  } catch(e) { console.error(e); }
  
  const dateEl = document.getElementById('dateValue');
  if (dateEl) dateEl.textContent = data.todayDate || new Date().toLocaleDateString('te-IN');
  
  const moonEl = document.getElementById('moonValue');
  if (moonEl) moonEl.textContent = data.todayMoonNakshatra?.name || '-';
  
  const entryTime = data.todayMoonNakshatra?.entryTime;
  if (entryTime) {
    const formatted = new Date(entryTime).toLocaleString('te-IN', { day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit' });
    const entryEl = document.getElementById('entryTimeValue');
    if (entryEl) entryEl.textContent = formatted;
  }
  
  const source = data.todayMoonNakshatra?.source;
  const sourceText = source === 'manual_override' ? 'మాన్యువల్ ఓవర్రైడ్' : (source === 'initial_seed' ? 'ప్రారంభ సెటప్' : 'స్థిర డేటాబేస్');
  const sourceEl = document.getElementById('sourceValue');
  if (sourceEl) sourceEl.textContent = sourceText;
  
  const tara = data.tarabalam;
  const taraNameEl = document.getElementById('taraName');
  if (taraNameEl) taraNameEl.textContent = `━━━ ${tara.taraName} తార ━━━`;
  
  const planetEl = document.getElementById('planetValue');
  if (planetEl) planetEl.textContent = tara.planet;
  
  const statusEl = document.getElementById('statusValue');
  if (statusEl) {
    statusEl.textContent = getStatusText(tara.status);
    statusEl.className = `status-badge ${getStatusClass(tara.status)}`;
  }
  
  const summaryEl = document.getElementById('summaryValue');
  if (summaryEl) summaryEl.textContent = data.guidance?.summary || 'సాధారణ దినం';
  
  const favorableList = document.getElementById('favorableList');
  if (favorableList) {
    favorableList.innerHTML = '';
    (data.guidance?.favorable || []).forEach(item => { const li = document.createElement('li'); li.textContent = item; favorableList.appendChild(li); });
  }
  
  const avoidList = document.getElementById('avoidList');
  if (avoidList) {
    avoidList.innerHTML = '';
    (data.guidance?.avoid || []).forEach(item => { const li = document.createElement('li'); li.textContent = item; avoidList.appendChild(li); });
  }
  
  const remediesList = document.getElementById('remediesList');
  if (remediesList) {
    remediesList.innerHTML = '';
    (data.guidance?.remedies || []).forEach(item => { const li = document.createElement('li'); li.textContent = item; remediesList.appendChild(li); });
  }
  
  const mantraEl = document.getElementById('mantraValue');
  if (mantraEl) mantraEl.textContent = data.guidance?.mantra || 'ॐ నమః శివాయ';
  
  const rating = data.guidance?.rating || 3;
  const starsEl = document.getElementById('ratingStars');
  if (starsEl) starsEl.innerHTML = renderStars(rating);
  
  const ratingValueEl = document.getElementById('ratingValue');
  if (ratingValueEl) ratingValueEl.textContent = `${rating}/5 అనుకూలత`;
  
  // FIX: Show content after rendering
  const content = document.getElementById('content');
  if (content) content.style.display = 'block';
}

export async function renderSetupScreen() {
  try {
    const response = await fetch('../database/nakshatraData.json');
    const data = await response.json();
    const janmaSelect = document.getElementById('janmaNakshatra');
    const moonSelect = document.getElementById('moonNakshatra');
    
    for (let id in data) {
      const option1 = document.createElement('option');
      option1.value = id;
      option1.textContent = `${data[id].sequence}. ${data[id].telugu}`;
      if (janmaSelect) janmaSelect.appendChild(option1);
      
      const option2 = document.createElement('option');
      option2.value = id;
      option2.textContent = `${data[id].sequence}. ${data[id].telugu}`;
      if (moonSelect) moonSelect.appendChild(option2);
    }
  } catch (error) {
    console.error('Error loading nakshatras:', error);
    showError('నక్షత్రాల డేటాను లోడ్ చేయడంలో లోపం');
  }
}

export async function renderUpdateMoonScreen() {
  try {
    const response = await fetch('../database/nakshatraData.json');
    const data = await response.json();
    const select = document.getElementById('moonNakshatra');
    if (select) {
      for (let id in data) {
        const option = document.createElement('option');
        option.value = id;
        option.textContent = `${data[id].sequence}. ${data[id].telugu}`;
        select.appendChild(option);
      }
    }
    
    const existingOverride = loadMoonOverride();
    if (existingOverride && existingOverride.nakshatraId && select) {
      select.value = existingOverride.nakshatraId;
      if (existingOverride.entryTime) {
        const [date, time] = existingOverride.entryTime.split('T');
        const dateEl = document.getElementById('entryDate');
        const timeEl = document.getElementById('entryTime');
        if (dateEl) dateEl.value = date;
        if (timeEl) timeEl.value = time?.substring(0, 5) || '';
      }
    }
  } catch (error) {
    console.error('Error:', error);
    showError('డేటా లోడ్ చేయడంలో లోపం');
  }
}

export { showLoader, hideLoader, showError, clearError, renderStars, getStatusClass, getStatusText };