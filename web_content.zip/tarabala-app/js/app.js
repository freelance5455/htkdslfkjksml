/**
 * app.js - Master application controller
 * Fixed: Service worker path, proper initialization
 */

import { loadUserProfile, saveUserProfile, saveMoonOverride, deleteMoonOverride, resetAppData, loadSettings, saveSettings, isAppConfigured, getJanmaNakshatraId } from './storage.js';
import { showLoader, hideLoader, showError, clearError, renderTodayScreen } from './ui.js';
import { generateTodayReport, clearReportCache } from '../engines/dailyEngine.js';

let currentReport = null;

function checkSetup() { return isAppConfigured(); }

async function loadTodayScreen() {
  showLoader('తారాబలం లెక్కిస్తోంది...');
  clearError();
  try {
    const profile = loadUserProfile();
    if (!profile || !profile.configured) { window.location.href = 'pages/setup.html'; return; }
    currentReport = await generateTodayReport();
    renderTodayScreen(currentReport);
    hideLoader();
  } catch (error) {
    hideLoader();
    showError(error.message || 'డేటా లోడ్ చేయడంలో లోపం', true);
  }
}

async function handleSetupSubmit(event) {
  event.preventDefault();
  const janma = parseInt(document.getElementById('janmaNakshatra')?.value, 10);
  if (!janma) { showError('దయచేసి జన్మ నక్షత్రాన్ని ఎంచుకోండి'); return; }
  saveUserProfile({ configured: true, janmaNakshatra: janma });
  localStorage.removeItem('tarabalam_initial_moon');
  localStorage.removeItem('tarabalam_moon_override');
  clearReportCache();
  showLoader('సేవ్ చేస్తోంది...');
  setTimeout(() => window.location.href = 'today.html', 300);
}

async function handleMoonOverride(event) {
  event.preventDefault();
  showError('ఈ ఆన్‌లైన్ వెర్షన్‌లో చంద్ర వివరాలు స్వయంచాలకంగా లెక్కించబడతాయి. మాన్యువల్ చంద్ర ప్రవేశం అవసరం లేదు.');
}

function resetMoonOverride() {
  if (confirm('డేటాబేస్ మోడ్కు తిరిగి వెళ్లాలనుకుంటున్నారా?')) {
    deleteMoonOverride();
    clearReportCache();
    showLoader('డేటాబేస్ మోడ్కు మారుస్తోంది...');
    setTimeout(() => window.location.href = 'today.html', 500);
  }
}

function toggleDarkMode() {
  const isDark = document.body.classList.contains('dark-mode');
  if (!isDark) document.body.classList.add('dark-mode');
  else document.body.classList.remove('dark-mode');
  saveSettings({ darkMode: !isDark });
  const toggle = document.getElementById('darkModeToggle');
  const label = document.getElementById('darkModeLabel');
  if (toggle) toggle.checked = !isDark;
  if (label) label.textContent = !isDark ? 'చీకటి మోడ్' : 'తేలికపాటి మోడ్';
}

function handleResetApp() {
  if (confirm('యాప్ డేటాను పూర్తిగా తొలగించాలా?')) {
    resetAppData();
    localStorage.removeItem('tarabalam_initial_moon');
    clearReportCache();
    window.location.href = 'pages/setup.html';
  }
}

function initDarkMode() {
  const settings = loadSettings();
  if (settings.darkMode) document.body.classList.add('dark-mode');
  const toggle = document.getElementById('darkModeToggle');
  const label = document.getElementById('darkModeLabel');
  if (toggle) toggle.checked = settings.darkMode;
  if (label) label.textContent = settings.darkMode ? 'చీకటి మోడ్' : 'తేలికపాటి మోడ్';
}

async function initializeApp() {
  initDarkMode();
  const path = window.location.pathname;
  const page = path.split('/').pop() || 'index.html';
  
  // FIX: Relative path for service worker
  if ('serviceWorker' in navigator) {
    try {
      const registration = await navigator.serviceWorker.register('./service-worker.js');
      console.log('Service Worker registered:', registration);
    } catch (error) {
      console.error('Service Worker registration failed:', error);
    }
  }
  
  if (page === 'index.html' || page === '') {
    const configured = checkSetup();
    configured ? window.location.href = 'pages/today.html' : window.location.href = 'pages/setup.html';
  } else if (page === 'today.html') await loadTodayScreen();
}

window.app = { handleSetupSubmit, handleMoonOverride, resetMoonOverride, toggleDarkMode, handleResetApp, loadTodayScreen, checkSetup };

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initializeApp);
else initializeApp();

export { initializeApp, loadTodayScreen, handleSetupSubmit, handleMoonOverride, resetMoonOverride, toggleDarkMode, handleResetApp };