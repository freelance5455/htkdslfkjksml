/**
 * storage.js - LocalStorage manager for Tarabalam PWA
 * PURE JAVASCRIPT - NO HTML
 */

const STORAGE_KEYS = {
  PROFILE: 'tarabalam_user_profile',
  MOON_OVERRIDE: 'tarabalam_moon_override',
  SETTINGS: 'tarabalam_settings',
  INITIAL_MOON: 'tarabalam_initial_moon'
};

export function saveUserProfile(profile) {
  try {
    if (!profile || typeof profile !== 'object') throw new Error('Invalid profile');
    const profileToSave = {
      configured: profile.configured === true,
      janmaNakshatra: profile.janmaNakshatra || null,
      savedAt: new Date().toISOString()
    };
    localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profileToSave));
    return true;
  } catch (error) {
    console.error('Error saving profile:', error);
    return false;
  }
}

export function loadUserProfile() {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.PROFILE);
    if (!data) return null;
    const profile = JSON.parse(data);
    return {
      configured: profile.configured === true,
      janmaNakshatra: profile.janmaNakshatra,
      savedAt: profile.savedAt
    };
  } catch (error) {
    console.error('Error loading profile:', error);
    return null;
  }
}

export function isAppConfigured() {
  const profile = loadUserProfile();
  return !!(profile && profile.configured === true && profile.janmaNakshatra);
}

export function getJanmaNakshatraId() {
  const profile = loadUserProfile();
  return profile?.janmaNakshatra || null;
}

export function saveMoonOverride(data) {
  try {
    if (!data || typeof data !== 'object') throw new Error('Invalid override');
    const overrideToSave = {
      override: data.override === true,
      nakshatraId: data.nakshatraId || null,
      entryTime: data.entryTime || null,
      savedAt: new Date().toISOString()
    };
    localStorage.setItem(STORAGE_KEYS.MOON_OVERRIDE, JSON.stringify(overrideToSave));
    return true;
  } catch (error) {
    console.error('Error saving override:', error);
    return false;
  }
}

export function loadMoonOverride() {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.MOON_OVERRIDE);
    if (!data) return null;
    const override = JSON.parse(data);
    if (override.override !== true) return null;
    return {
      override: true,
      nakshatraId: override.nakshatraId,
      entryTime: override.entryTime,
      savedAt: override.savedAt
    };
  } catch (error) {
    console.error('Error loading override:', error);
    return null;
  }
}

export function deleteMoonOverride() {
  try {
    localStorage.removeItem(STORAGE_KEYS.MOON_OVERRIDE);
    return true;
  } catch (error) {
    console.error('Error deleting override:', error);
    return false;
  }
}

export function saveSettings(settings) {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify({ darkMode: settings.darkMode === true }));
    return true;
  } catch (error) {
    console.error('Error saving settings:', error);
    return false;
  }
}

export function loadSettings() {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!data) return { darkMode: false };
    return JSON.parse(data);
  } catch (error) {
    console.error('Error loading settings:', error);
    return { darkMode: false };
  }
}

export function resetAppData() {
  try {
    localStorage.removeItem(STORAGE_KEYS.PROFILE);
    localStorage.removeItem(STORAGE_KEYS.MOON_OVERRIDE);
    localStorage.removeItem(STORAGE_KEYS.SETTINGS);
    localStorage.removeItem(STORAGE_KEYS.INITIAL_MOON);
    return true;
  } catch (error) {
    console.error('Error resetting app:', error);
    return false;
  }
}