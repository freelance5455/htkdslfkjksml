// Online-only PWA service worker: never serves stale application data from a cache.
const VERSION = 'tarabalam-online-v2';
self.addEventListener('install', event => event.waitUntil(self.skipWaiting()));
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));
self.addEventListener('fetch', event => {
  // Always go to the network. This app intentionally requires internet access.
  event.respondWith(fetch(event.request, { cache: 'no-store' }));
});
