/* Online Astronomy Engine
 * Requires internet: loads Astronomy Engine from CDN and sunrise/sunset from sunrise-sunset.org.
 * Chandra Nakshatra uses sidereal longitude with a Lahiri ayanamsa approximation.
 */
let astronomyPromise = null;

function loadAstronomy() {
  if (window.Astronomy) return Promise.resolve(window.Astronomy);
  if (!astronomyPromise) {
    astronomyPromise = new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = 'https://cdn.jsdelivr.net/npm/astronomy-engine/astronomy.browser.min.js';
      s.async = true;
      s.onload = () => window.Astronomy ? resolve(window.Astronomy) : reject(new Error('Astronomy Engine loaded but was not found'));
      s.onerror = () => reject(new Error('Cannot load online Astronomy Engine. Check internet connection.'));
      document.head.appendChild(s);
    });
  }
  return astronomyPromise;
}

function normalize(x) { return ((x % 360) + 360) % 360; }

// Lahiri ayanamsa approximation, degrees. Sufficient for nakshatra/pada display;
// exact Panchanga services may differ by seconds around a boundary.
function lahiriAyanamsa(date) {
  const y = date.getUTCFullYear() + (date.getUTCMonth() + 0.5) / 12;
  const t = y - 2000;
  return 23.856111 + (50.290966 / 3600) * t;
}

function siderealMoonLongitude(Astronomy, date) {
  const tropical = Astronomy.EclipticLongitude(Astronomy.Body.Moon, date);
  return normalize(tropical - lahiriAyanamsa(date));
}

function nakshatraFromLongitude(longitude) {
  const span = 360 / 27;
  const padaSpan = span / 4;
  const id = Math.floor(normalize(longitude) / span) + 1;
  const within = normalize(longitude) - (id - 1) * span;
  const pada = Math.floor(within / padaSpan) + 1;
  return { nakshatraId: id, pada, longitude: normalize(longitude) };
}

function sameNakshatra(Astronomy, a, b) {
  return nakshatraFromLongitude(siderealMoonLongitude(Astronomy, a)).nakshatraId ===
         nakshatraFromLongitude(siderealMoonLongitude(Astronomy, b)).nakshatraId;
}

function binaryBoundary(Astronomy, before, after) {
  let lo = before.getTime(), hi = after.getTime();
  for (let i = 0; i < 45; i++) {
    const mid = new Date((lo + hi) / 2);
    if (sameNakshatra(Astronomy, new Date(lo), mid)) lo = mid.getTime();
    else hi = mid.getTime();
  }
  return new Date(hi);
}

function findEntry(Astronomy, now) {
  const current = nakshatraFromLongitude(siderealMoonLongitude(Astronomy, now));
  let after = new Date(now);
  let before = new Date(now);
  for (let i = 0; i < 288; i++) { // 48 hours at 10-minute steps
    before = new Date(before.getTime() - 10 * 60 * 1000);
    if (!sameNakshatra(Astronomy, before, now)) break;
  }
  const entry = binaryBoundary(Astronomy, before, now);

  // Find next boundary.
  let cursor = new Date(now);
  for (let i = 0; i < 288; i++) {
    after = new Date(after.getTime() + 10 * 60 * 1000);
    if (!sameNakshatra(Astronomy, now, after)) break;
  }
  const exit = binaryBoundary(Astronomy, now, after);
  const nextNak = nakshatraFromLongitude(siderealMoonLongitude(Astronomy, new Date(exit.getTime() + 1000)));
  return { ...current, entryTime: entry, exitTime: exit, nextNakshatraId: nextNak.nakshatraId, source: 'online-astronomy-engine' };
}

async function fetchSunTimes(lat, lon, date) {
  const yyyy = date.getUTCFullYear();
  const mm = String(date.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(date.getUTCDate()).padStart(2, '0');
  const url = `https://api.sunrise-sunset.org/json?lat=${encodeURIComponent(lat)}&lng=${encodeURIComponent(lon)}&date=${yyyy}-${mm}-${dd}&formatted=0`;
  const r = await fetch(url, { cache: 'no-store' });
  if (!r.ok) throw new Error('Sunrise/sunset service unavailable');
  const j = await r.json();
  if (j.status !== 'OK') throw new Error('Sunrise/sunset service returned an error');
  return { sunrise: new Date(j.results.sunrise), sunset: new Date(j.results.sunset), solarNoon: new Date(j.results.solar_noon) };
}

export async function getOnlineChandra(date = new Date()) {
  const Astronomy = await loadAstronomy();
  const result = findEntry(Astronomy, date);
  return result;
}

export async function getOnlineSunTimes(lat, lon, date = new Date()) {
  return fetchSunTimes(lat, lon, date);
}

export async function getOnlineDailyAstronomy(lat, lon, date = new Date()) {
  const nextDate = new Date(date.getTime() + 24*60*60*1000);
  const [moon, sun, nextSun] = await Promise.all([getOnlineChandra(date), getOnlineSunTimes(lat, lon, date), getOnlineSunTimes(lat, lon, nextDate)]);
  return { moon, sun, nextSun, generatedAt: new Date().toISOString(), online: true };
}

export function getDefaultLocation() {
  return { lat: 14.4673, lon: 78.8242, name: 'Kadapa, Andhra Pradesh, India', timezone: 'Asia/Kolkata' };
}

export function getBrowserLocation() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) return reject(new Error('Geolocation is not supported'));
    navigator.geolocation.getCurrentPosition(
      p => resolve({ lat: p.coords.latitude, lon: p.coords.longitude, name: 'Current location', timezone: Intl.DateTimeFormat().resolvedOptions().timeZone }),
      e => reject(new Error(e.message || 'Location permission denied')),
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 3600000 }
    );
  });
}

export function generateHoraChakra(sunrise, sunset, nextSunrise, date = new Date()) {
  const day = date.getDay(); // 0 Sun ... 6 Sat
  const dayLord = [0, 3, 6, 2, 5, 1, 4][day]; // Sun, Moon, Mars, Mercury, Jupiter, Venus, Saturn
  const planets = [
    { id: 0, name: 'సూర్యుడు', en: 'Sun', symbol: '☀️' },
    { id: 1, name: 'శుక్రుడు', en: 'Venus', symbol: '♀️' },
    { id: 2, name: 'బుధుడు', en: 'Mercury', symbol: '☿' },
    { id: 3, name: 'చంద్రుడు', en: 'Moon', symbol: '☾' },
    { id: 4, name: 'శని', en: 'Saturn', symbol: '♄' },
    { id: 5, name: 'గురుడు', en: 'Jupiter', symbol: '♃' },
    { id: 6, name: 'కుజుడు', en: 'Mars', symbol: '♂' }
  ];
  const order = [0,1,2,3,4,5,6];
  const startIndex = order.indexOf(dayLord);
  const sequence = [];
  for (let i = 0; i < 24; i++) sequence.push(order[(startIndex + i) % 7]);
  const rise = sunrise.getTime(), set = sunset.getTime();
  const nextRise = nextSunrise instanceof Date ? nextSunrise : new Date(rise + 24*60*60*1000);
  const dayHoraMs = (set - rise) / 12;
  const nightHoraMs = (nextRise.getTime() - set) / 12;
  const result = [];
  for (let i = 0; i < 24; i++) {
    const start = i < 12 ? new Date(rise + i * dayHoraMs) : new Date(set + (i-12) * nightHoraMs);
    const end = i < 11 ? new Date(rise + (i+1) * dayHoraMs) : i === 11 ? new Date(set) : i < 23 ? new Date(set + (i-11) * nightHoraMs) : nextRise;
    const p = planets[sequence[i]];
    result.push({ index: i+1, planetId: p.id, ...p, start, end });
  }
  return result;
}
