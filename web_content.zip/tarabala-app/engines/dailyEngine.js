/**
 * dailyEngine.js
 * Master orchestrator - combines moon, tarabalam, and remedies
 */

import { getCurrentMoonNakshatra } from './moonCycleEngine.js';
import { calculateTarabalam } from './tarabalamEngine.js';
import { getDailyGuidance } from './remedyEngine.js';
import { loadUserProfile } from '../js/storage.js';

/**
 * Generate complete today's report
 * @returns {Promise<Object>} Complete daily report
 */
export async function generateTodayReport() {
  try {
    // Step 1: Load user profile
    const profile = loadUserProfile();
    if (!profile || !profile.configured || !profile.janmaNakshatra) {
      throw new Error('User profile missing. Please complete setup.');
    }
    
    // Step 2: Get today's Moon Nakshatra
    const moonData = await getCurrentMoonNakshatra();
    
    // Step 3: Calculate Tarabalam
    const tarabalamData = await calculateTarabalam({
      janmaNakshatraId: profile.janmaNakshatra,
      moonNakshatraId: moonData.nakshatraId
    });
    
    // Step 4: Get daily guidance based on tara
    const guidanceData = await getDailyGuidance(tarabalamData.taraId);
    
    // Step 5: Return merged object
    const todayDate = new Date().toLocaleDateString('te-IN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      weekday: 'long'
    });
    
    return {
      todayDate: todayDate,
      todayMoonNakshatra: {
        id: moonData.nakshatraId,
        name: moonData.nakshatra,
        entryTime: moonData.entryTime,
        source: moonData.source
      },
      tarabalam: {
        taraId: tarabalamData.taraId,
        taraName: tarabalamData.taraName,
        planet: tarabalamData.planet,
        status: tarabalamData.status,
        nature: tarabalamData.nature,
        distance: tarabalamData.distance
      },
      guidance: {
        summary: guidanceData.summary,
        favorable: guidanceData.favorable,
        avoid: guidanceData.avoid,
        remedies: guidanceData.remedies,
        mantra: guidanceData.mantra,
        rating: guidanceData.rating,
        planet: guidanceData.planet
      },
      timestamp: new Date().toISOString()
    };
    
  } catch (error) {
    console.error('Error generating today\'s report:', error);
    throw new Error(error.message || 'Unable to generate daily report');
  }
}

/**
 * Check if app is properly configured
 * @returns {Promise<boolean>}
 */
export async function isAppConfigured() {
  try {
    const profile = loadUserProfile();
    return !!(profile && profile.configured === true && profile.janmaNakshatra);
  } catch {
    return false;
  }
}

/**
 * Get cached or fresh report (for performance)
 * Cached for current day only
 */
let cachedReport = null;
let cachedDate = null;

export async function getTodayReportWithCache() {
  const today = new Date().toDateString();
  
  if (cachedReport && cachedDate === today) {
    return cachedReport;
  }
  
  cachedReport = await generateTodayReport();
  cachedDate = today;
  return cachedReport;
}

/**
 * Clear cache (useful after manual override)
 */
export function clearReportCache() {
  cachedReport = null;
  cachedDate = null;
}