/**
 * tarabalamEngine.js
 * Calculates Tarabalam based on Janma Nakshatra and daily Moon Nakshatra
 * Formula: distance = (moon - janma + 1), if <=0 add 27, then (distance % 9), 0 becomes 9
 */

let taraMatrixCache = null;

/**
 * Load Tara Matrix database
 * @returns {Promise<Object>} Tara matrix JSON
 */
async function loadTaraMatrix() {
  if (taraMatrixCache) return taraMatrixCache;
  
  try {
    const response = await fetch('../database/taraMatrix.json');
    if (!response.ok) throw new Error('Failed to load tara matrix');
    taraMatrixCache = await response.json();
    return taraMatrixCache;
  } catch (error) {
    console.error('Error loading tara matrix:', error);
    throw new Error('Tara matrix unavailable');
  }
}

/**
 * Calculate distance between moon and janma nakshatras
 * @param {number} moonId - Moon Nakshatra ID (1-27)
 * @param {number} janmaId - Janma Nakshatra ID (1-27)
 * @returns {number} Distance (1-27)
 */
function calculateDistance(moonId, janmaId) {
  let distance = moonId - janmaId + 1;
  if (distance <= 0) distance += 27;
  return distance;
}

/**
 * Convert distance to Tara Index (1-9)
 * @param {number} distance - Distance (1-27)
 * @returns {number} Tara ID (1-9)
 */
function getTaraIndex(distance) {
  let taraIndex = distance % 9;
  if (taraIndex === 0) taraIndex = 9;
  return taraIndex;
}

/**
 * Main function: Calculate Tarabalam
 * @param {Object} input - { janmaNakshatraId, moonNakshatraId }
 * @returns {Promise<Object>} Tarabalam result
 */
export async function calculateTarabalam(input) {
  const { janmaNakshatraId, moonNakshatraId } = input;
  
  if (!janmaNakshatraId || !moonNakshatraId) {
    throw new Error('Missing janma or moon nakshatra ID');
  }
  
  const distance = calculateDistance(moonNakshatraId, janmaNakshatraId);
  const taraId = getTaraIndex(distance);
  
  const taraMatrix = await loadTaraMatrix();
  const taraData = taraMatrix[taraId];
  
  if (!taraData) {
    throw new Error(`Invalid tara ID: ${taraId}`);
  }
  
  return {
    taraId: taraData.id,
    taraName: taraData.telugu,
    planet: taraData.planet,
    nature: taraData.nature,
    status: taraData.status,
    distance: distance,
    englishName: taraData.english
  };
}

/**
 * Get Tarabalam status text for UI
 * @param {string} status - 'good', 'bad', 'excellent', 'caution'
 * @returns {string} Telugu status message
 */
export function getTaraStatusMessage(status) {
  const messages = {
    'excellent': 'చాలా శుభం',
    'good': 'శుభం',
    'caution': 'జాగ్రత్త అవసరం',
    'bad': 'అశుభం'
  };
  return messages[status] || 'సాధారణం';
}

/**
 * Get color class for status
 * @param {string} status 
 * @returns {string} CSS class
 */
export function getTaraColorClass(status) {
  const classes = {
    'excellent': 'status-excellent',
    'good': 'status-good',
    'caution': 'status-caution',
    'bad': 'status-bad'
  };
  return classes[status] || 'status-normal';
}