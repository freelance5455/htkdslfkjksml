/**
 * remedyEngine.js
 * Merges tara remedies and effects to provide daily guidance
 */

let remediesCache = null;
let effectsCache = null;

/**
 * Load remedies database
 * @returns {Promise<Object>}
 */
async function loadRemediesDB() {
  if (remediesCache) return remediesCache;
  
  try {
    const response = await fetch('../database/taraRemedies.json');
    if (!response.ok) throw new Error('Failed to load remedies');
    remediesCache = await response.json();
    return remediesCache;
  } catch (error) {
    console.error('Error loading remedies:', error);
    return getFallbackRemedies();
  }
}

/**
 * Load effects database
 * @returns {Promise<Object>}
 */
async function loadEffectsDB() {
  if (effectsCache) return effectsCache;
  
  try {
    const response = await fetch('../database/taraEffects.json');
    if (!response.ok) throw new Error('Failed to load effects');
    effectsCache = await response.json();
    return effectsCache;
  } catch (error) {
    console.error('Error loading effects:', error);
    return getFallbackEffects();
  }
}

/**
 * Fallback remedies if DB unavailable
 */
function getFallbackRemedies() {
  return {
    "1": { tara: "జన్మ", planet: "సూర్యుడు", goodFor: ["ధ్యానం"], avoid: ["కొత్త పనులు"], remedies: ["దానం"], mantra: "ॐ సూర్యాయ నమః" }
  };
}

/**
 * Fallback effects if DB unavailable
 */
function getFallbackEffects() {
  return {
    "1": { tara: "జన్మ", summary: "జాగ్రత్తగా ఉండండి", favorable: ["ధ్యానం"], avoid: ["ప్రయాణం"], rating: 2 }
  };
}

/**
 * Main function: Get daily guidance for a specific tara
 * @param {number} taraId - Tara ID (1-9)
 * @returns {Promise<Object>} Merged guidance
 */
export async function getDailyGuidance(taraId) {
  try {
    const remedies = await loadRemediesDB();
    const effects = await loadEffectsDB();
    
    const remedyData = remedies[taraId] || remedies["1"];
    const effectData = effects[taraId] || effects["1"];
    
    return {
      summary: effectData.summary || "సాధారణ దినం",
      favorable: effectData.favorable || remedyData.goodFor || ["దానం"],
      avoid: effectData.avoid || remedyData.avoid || ["అవసరం లేని పనులు"],
      remedies: remedyData.remedies || ["దానం", "జపం"],
      mantra: remedyData.mantra || "ॐ నమః శివాయ",
      planet: remedyData.planet || "సూర్యుడు",
      rating: effectData.rating || 3,
      taraName: remedyData.tara || `తార-${taraId}`
    };
  } catch (error) {
    console.error('Error getting daily guidance:', error);
    return {
      summary: "దయచేసి అనువర్తనాన్ని రీలోడ్ చేయండి",
      favorable: ["పూజ", "ధ్యానం"],
      avoid: ["వివాదం"],
      remedies: ["గుడి దర్శనం"],
      mantra: "ॐ శాంతిః",
      planet: "సూర్యుడు",
      rating: 3,
      taraName: "సాధారణ"
    };
  }
}

/**
 * Get rating stars HTML
 * @param {number} rating - 1-5
 * @returns {string} HTML star rating
 */
export function getRatingStars(rating) {
  const fullStar = '★';
  const emptyStar = '☆';
  let stars = '';
  for (let i = 1; i <= 5; i++) {
    stars += i <= rating ? fullStar : emptyStar;
  }
  return stars;
}