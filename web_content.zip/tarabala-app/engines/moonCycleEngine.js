/* Online-only Moon/Nakshatra engine. */
import { getOnlineChandra } from './onlineAstronomyEngine.js';

const namesCache = {};
async function getData(){ if(!namesCache.data){ const r=await fetch('../database/nakshatraData.json',{cache:'no-store'}); if(!r.ok) throw new Error('Nakshatra data unavailable'); namesCache.data=await r.json(); } return namesCache.data; }

export async function getCurrentMoonNakshatra(){
  const [m,d]=await Promise.all([getOnlineChandra(new Date()),getData()]);
  const n=d[m.nakshatraId]||{};
  return {...m, nakshatra:n.telugu||n.name||`నక్షత్రం-${m.nakshatraId}`, pada:m.pada};
}

export async function getMoonNakshatraForDate(date){
  const [m,d]=await Promise.all([getOnlineChandra(date),getData()]);
  const n=d[m.nakshatraId]||{};
  return {...m, nakshatra:n.telugu||n.name||`నక్షత్రం-${m.nakshatraId}`, pada:m.pada};
}
