const { contextBridge } = require('electron');
const { app } = require('electron');

// Expose only non-privileged app metadata for the first desktop shell.
// File-system operations and trash actions are intentionally NOT exposed yet.
contextBridge.exposeInMainWorld('safiDesktop', Object.freeze({
  getVersion: () => process.versions.electron,
  getPlatform: () => process.platform,
  isDesktop: true
}));
