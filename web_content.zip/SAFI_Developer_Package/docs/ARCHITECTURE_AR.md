# البنية التقنية المقترحة

## الطبقات
- **UI:** واجهة RTL، إدارة الصفحات والحالة، عرض النتائج والمراجعة.
- **Core Engine:** hashing، image fingerprinting، grouping، ranking، file metadata.
- **Application Services:** scan jobs، pause/resume، review session، export/report.
- **Adapters:** File System Access API للويب، وواجهات Electron محدودة لسطح المكتب.
- **Persistence:** IndexedDB للويب؛ SQLite لسطح المكتب عند الحاجة.
- **Integrations:** وحدات مستقلة اختيارية، مع تعطيل الشبكة افتراضيًا.

## قواعد أمنية
- `contextIsolation: true` و`nodeIntegration: false` و`sandbox: true`.
- لا تمرير `fs` أو `ipcRenderer` مباشرة إلى الواجهة.
- التحقق من كل طلب IPC في Main Process.
- استخدام قائمة سماح للأوامر، وليس تنفيذ مسارات أو أوامر يرسلها renderer بلا تحقق.
- عند تنفيذ النقل لسلة المحذوفات: استخدام `shell.trashItem` فقط، وعدم استخدام `unlink` أو `rm`.
- تأكيد واضح قبل أي عملية تغيير.
- تسجيل العملية ونتيجتها، وإظهار فشل أي ملف منفرد دون إخفائه.

## اقتراح محرك فحص
1. جرد metadata أولًا.
2. تجميع المرشحين حسب الحجم والنوع.
3. SHA-256 تدريجيًا وبحجم chunks مضبوط.
4. صور: تصغير آمن ثم dHash؛ فصل التشابه عن التطابق.
5. إلغاء/إيقاف/استكمال المهام مع checkpoints.
6. منع تجميع الملفات ذات الحجم المختلف في مجموعات التطابق التام.

## التحديثات
اعتماد قنوات `stable` و`beta`، والتحقق من توقيع الحزمة، وإظهار سجل التغيير، وإتاحة تأجيل التحديث. لا تُفعّل التحديثات قبل إعداد خادم نشر وتوقيع التطبيق.
