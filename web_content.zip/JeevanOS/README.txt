JeevanOS prototype
==================

Features:
- Study plan tasks with completion and priority
- Reminder list with date/time and best-effort notifications while app/browser remains open
- Notes create/edit/delete
- Expense tracker in NPR
- Home dashboard, daily summary
- Local browser storage
- JSON export/import backup
- Basic offline PWA caching when served from HTTPS or localhost

IMPORTANT LIMITATIONS:
- This ZIP is a web app prototype, not a compiled Android APK.
- Browser notifications are not guaranteed when the app/browser is closed or Android suspends it.
- Data is stored in this browser on this device. Use Export Backup regularly.
- To install as a PWA, host the files on an HTTPS static host, then open the URL in Chrome and choose Install app / Add to Home screen. Opening index.html directly from a file manager does not enable service worker offline installation.
- To make a native APK, wrap the web app with a compatible WebView/HTML-to-APK service or Android tool. Review the service's privacy policy and build terms before uploading personal data. Do not pay unless you choose to.

Files:
index.html - full app
manifest.json - PWA metadata
sw.js - offline cache
