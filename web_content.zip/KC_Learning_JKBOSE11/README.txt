KC LEARNING — JKBOSE CLASS 11 ANDROID STARTER
Brand: KC PRIVATE LIMITED
Theme: Blue and white

WHAT IS INCLUDED
- Android Studio project (Java WebView wrapper)
- Offline HTML/CSS/JavaScript student app
- Student demo sign-in and local profile
- Delete demo account / log out
- Class 11 subject catalogue with Free and Paid labels
- Sample chapter notes
- Five sample MCQs with instant score
- Admin console preview (not a real secured admin system)

IMPORTANT LIMITATIONS
This ZIP is an Android Studio SOURCE PROJECT, not a ready-to-install APK.
Open it in Android Studio, allow Gradle sync, then Build > Build APK(s).
The project is an offline starter/demo. Student accounts are stored only on the device.
The paid course buttons are placeholders; no money is collected.
There is no live class, recorded video hosting, cloud sync, real user database,
production admin login, password reset, or Razorpay/UPI integration in this ZIP.
Those features require a secure backend and service credentials. Do not put admin
passwords, payment secrets, or private API keys in the Android app or JavaScript.

BUILD STEPS
1. Install Android Studio on a computer.
2. Open this folder as a project.
3. Wait for Gradle sync to finish.
4. Select Build > Build APK(s).
5. Find the APK under app/build/outputs/apk/debug/.

For production release, replace the demo sign-in with a secure backend, use HTTPS,
store passwords as salted hashes on the server, add role-based admin authorization,
and integrate a verified payment provider with server-side order creation and
signature verification. Have the JKBOSE syllabus and notes reviewed before release.
