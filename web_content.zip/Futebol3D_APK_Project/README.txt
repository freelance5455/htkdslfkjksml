FUTEBOL 3D 1v1 - PROJETO APK

Este projeto coloca o jogo HTML enviado no usuário dentro de um aplicativo Android usando WebView.

Compatibilidade: Android 6.0 ou superior; testado como projeto para Android moderno.

IMPORTANTE:
O jogo usa Three.js e Tailwind por links externos. Por isso o aplicativo precisa de internet para carregar essas bibliotecas.

COMO GERAR O APK NO ANDROID STUDIO:
1. Abra esta pasta no Android Studio.
2. Espere o Gradle sincronizar e o Android Studio baixar as ferramentas necessárias.
3. Vá em Build > Build APK(s).
4. O APK será criado em app/build/outputs/apk/debug/.

O arquivo original do jogo está em:
app/src/main/assets/index.html
