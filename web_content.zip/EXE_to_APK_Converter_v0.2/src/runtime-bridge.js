/**
 * Contract for a future native Android runtime bridge.
 * This web build deliberately exposes no fake Run/Convert operation.
 * A real implementation must be supplied by a signed Android host app that
 * bundles or installs compatible Wine, Box64/Box86 and a root filesystem.
 */
export class RuntimeUnavailableError extends Error {
  constructor(message = 'Windows runtime native belum tersedia di build web ini.') {
    super(message);
    this.name = 'RuntimeUnavailableError';
  }
}

export function getRuntimeStatus() {
  return Object.freeze({
    available: false,
    wine: false,
    box64: false,
    rootfs: false,
    reason: 'Browser tidak menyediakan ABI native atau Windows compatibility runtime.'
  });
}

export async function launchWindowsExecutable() {
  throw new RuntimeUnavailableError('Tidak dapat menjalankan EXE: instalasi Wine/Box64 dan bridge Android native belum tersedia.');
}

export async function buildStandaloneApk() {
  throw new RuntimeUnavailableError('Tidak dapat membangun APK runtime: toolchain Android dan komponen runtime native tidak disertakan.');
}
