const DB_NAME = 'exe-to-apk-converter';
const DB_VERSION = 1;
const STORE_APPS = 'apps';
const STORE_SETTINGS = 'settings';

let dbPromise;

export function openDatabase() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) {
      reject(new Error('Browser ini tidak mendukung IndexedDB. Gunakan Chrome atau browser modern.'));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_APPS)) {
        const store = db.createObjectStore(STORE_APPS, { keyPath: 'id' });
        store.createIndex('importedAt', 'importedAt', { unique: false });
        store.createIndex('name', 'name', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_SETTINGS)) db.createObjectStore(STORE_SETTINGS, { keyPath: 'key' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Database tidak dapat dibuka.'));
    request.onblocked = () => reject(new Error('Database sedang diblokir tab lain. Tutup tab aplikasi lain lalu coba lagi.'));
  });
  return dbPromise;
}

function requestResult(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Operasi database gagal.'));
  });
}

export async function getAllApps() {
  const db = await openDatabase();
  return requestResult(db.transaction(STORE_APPS, 'readonly').objectStore(STORE_APPS).getAll());
}
export async function getApp(id) {
  const db = await openDatabase();
  return requestResult(db.transaction(STORE_APPS, 'readonly').objectStore(STORE_APPS).get(id));
}
export async function saveApp(app) {
  const db = await openDatabase();
  return requestResult(db.transaction(STORE_APPS, 'readwrite').objectStore(STORE_APPS).put(app));
}
export async function removeApp(id) {
  const db = await openDatabase();
  return requestResult(db.transaction(STORE_APPS, 'readwrite').objectStore(STORE_APPS).delete(id));
}
export async function getSetting(key, fallback = null) {
  const db = await openDatabase();
  const item = await requestResult(db.transaction(STORE_SETTINGS, 'readonly').objectStore(STORE_SETTINGS).get(key));
  return item ? item.value : fallback;
}
export async function saveSetting(key, value) {
  const db = await openDatabase();
  return requestResult(db.transaction(STORE_SETTINGS, 'readwrite').objectStore(STORE_SETTINGS).put({ key, value }));
}
export async function estimateStorage() {
  if (!navigator.storage?.estimate) return null;
  try { return await navigator.storage.estimate(); } catch { return null; }
}
