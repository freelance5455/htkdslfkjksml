import { analyzePE, formatBytes } from './pe-analyzer.js';
import { getAllApps, getApp, saveApp, removeApp, getSetting, saveSetting, estimateStorage } from './db.js';
import { getRuntimeStatus } from './runtime-bridge.js';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const DEFAULT_PROFILE = { ram: '2048', cpu: '2', resolution: '1280x720', graphics: 'balanced', controls: 'touch' };
const DEFAULT_SETTINGS = { ...DEFAULT_PROFILE };
let apps = [];
let activePage = 'home';
let busy = false;

function escapeHTML(value = '') {
  return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
}
function makeId() {
  return globalThis.crypto?.randomUUID?.() || `app-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}
function formatDate(value) {
  try { return new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)); }
  catch { return 'Tanggal tidak diketahui'; }
}
function toast(message, type = 'info') {
  const el = document.createElement('div');
  el.className = `toast ${type === 'error' ? 'error' : ''}`;
  el.textContent = message;
  $('#toast-region').append(el);
  setTimeout(() => el.remove(), 3600);
}
function setBusy(value) {
  busy = value;
  $('#import-button').disabled = value;
  $('#library-import').disabled = value;
  $('#import-button').innerHTML = value ? '<span class="spinner">◌</span> Memproses...' : '<span>＋</span> Import EXE';
}
function createProgressToast(filename) {
  const el = document.createElement('div');
  el.className = 'toast import-progress-toast';
  const title = document.createElement('div');
  title.className = 'progress-label';
  const name = document.createElement('span');
  name.textContent = `Memproses ${filename}`;
  const percent = document.createElement('b');
  percent.textContent = '5%';
  title.append(name, percent);
  const track = document.createElement('div');
  track.className = 'progress-line';
  const fill = document.createElement('span');
  fill.style.width = '5%';
  track.append(fill);
  el.append(title, track);
  $('#toast-region').append(el);
  const update = (value, label) => {
    const bounded = Math.max(0, Math.min(100, value));
    percent.textContent = `${bounded}%`;
    name.textContent = label || `Memproses ${filename}`;
    fill.style.width = `${bounded}%`;
  };
  update.element = el;
  return update;
}
function appIcon(name) {
  const ext = name.split('.').pop()?.toUpperCase() || 'EXE';
  return `<div class="file-icon">${escapeHTML(ext.slice(0, 4))}</div>`;
}
function appRow(app) {
  const arch = app.analysis?.architecture || 'Belum dianalisis';
  const status = app.analysis?.validPE ? 'Analisis PE selesai' : 'Analisis gagal';
  return `<article class="app-row">
    ${appIcon(app.name)}
    <div class="app-info"><h3 title="${escapeHTML(app.name)}">${escapeHTML(app.name)}</h3><div class="app-meta"><span>${formatBytes(app.size)}</span><span>${escapeHTML(arch)}</span><span>${formatDate(app.importedAt)}</span></div></div>
    <span class="app-status ${app.analysis?.validPE ? '' : 'unknown'}">${status}</span>
    <div class="row-actions"><button class="mini-btn" data-action="details" data-id="${escapeHTML(app.id)}">Detail</button><button class="mini-btn" data-action="profile" data-id="${escapeHTML(app.id)}">Profil</button><button class="mini-btn" data-action="more" data-id="${escapeHTML(app.id)}" aria-label="Aksi lainnya">•••</button></div>
  </article>`;
}
function render() {
  const recent = [...apps].sort((a, b) => b.importedAt - a.importedAt).slice(0, 4);
  $('#stat-total').textContent = apps.length;
  $('#stat-analyzed').textContent = apps.filter(a => a.analysis?.validPE).length;
  $('#stat-profiles').textContent = apps.filter(a => a.profileSaved).length;
  $('#side-count').textContent = apps.length;
  $('#recent-list').innerHTML = recent.length ? recent.map(appRow).join('') : `<div class="empty-state"><div class="empty-art">⌁</div><b>Belum ada file EXE</b><p>Impor file Windows pertama untuk memulai analisis.</p><button class="btn btn-secondary" id="empty-import">Pilih file EXE</button></div>`;
  renderLibrary();
  updateStorage();
}
function renderLibrary() {
  const q = ($('#search-input')?.value || '').trim().toLowerCase();
  const sort = $('#sort-select')?.value || 'newest';
  const list = apps.filter(a => a.name.toLowerCase().includes(q));
  list.sort((a, b) => sort === 'oldest' ? a.importedAt - b.importedAt : sort === 'name' ? a.name.localeCompare(b.name) : sort === 'size' ? b.size - a.size : b.importedAt - a.importedAt);
  $('#library-summary').textContent = `${list.length} dari ${apps.length} program tersimpan`;
  $('#library-list').innerHTML = list.length ? list.map(appRow).join('') : `<div class="empty-state"><div class="empty-art">▤</div><b>${apps.length ? 'Tidak ada hasil' : 'Library masih kosong'}</b><p>${apps.length ? 'Coba kata pencarian yang lain.' : 'File yang kamu impor akan muncul di sini.'}</p>${apps.length ? '' : '<button class="btn btn-secondary" id="library-empty-import">Pilih file EXE</button>'}</div>`;
}
async function updateStorage() {
  const usage = await estimateStorage();
  if (!usage || !usage.quota) {
    $('#storage-percent').textContent = '—';
    $('#storage-detail').textContent = `${apps.length} item tersimpan`;
    return;
  }
  const percent = Math.min(100, (usage.usage / usage.quota) * 100);
  $('#storage-percent').textContent = `${percent.toFixed(1)}%`;
  $('#storage-bar').style.width = `${percent}%`;
  $('#storage-detail').textContent = `${formatBytes(usage.usage)} digunakan dari estimasi ${formatBytes(usage.quota)}`;
}
function navigate(page) {
  if (!['home', 'library', 'runtime', 'settings'].includes(page)) return;
  activePage = page;
  $$('.page').forEach(el => el.classList.toggle('active', el.id === `page-${page}`));
  $$('[data-nav]').forEach(el => el.classList.toggle('active', el.dataset.nav === page));
  $('#page-title').textContent = ({ home: 'Dashboard', library: 'Library', runtime: 'Windows Runtime', settings: 'Pengaturan' })[page];
  if (page === 'library') renderLibrary();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function importFiles(fileList) {
  const files = [...fileList];
  if (!files.length || busy) return;
  setBusy(true);
  let imported = 0;
  try {
    for (const file of files) {
      if (!file.name.toLowerCase().endsWith('.exe')) {
        toast(`${file.name}: hanya file .exe yang diterima.`, 'error');
        continue;
      }
      const progress = createProgressToast(file.name);
      progress(18, `Membaca header ${file.name}`);
      let analysis = null;
      let analysisError = null;
      try { analysis = await analyzePE(file); }
      catch (error) { analysisError = error.message || 'Analisis gagal'; }
      progress(70, `Analisis selesai · menyimpan ${file.name}`);
      const record = {
        id: makeId(), name: file.name, size: file.size, type: file.type || 'application/octet-stream',
        lastModified: file.lastModified || null, importedAt: Date.now(), blob: file,
        analysis, analysisError, profile: { ...DEFAULT_PROFILE }, profileSaved: false
      };
      try {
        await saveApp(record);
        apps.push(record);
        imported++;
        progress(100, analysis ? `${file.name}: berhasil disimpan` : `${file.name}: disimpan, PE tidak valid`);
        if (!analysis) progress.element.classList.add('error');
        setTimeout(() => progress.element.parentElement && progress.element.remove(), 4000);
      } catch (error) {
        progress.element.remove();
        toast(`Gagal menyimpan ${file.name}: ${error.name === 'QuotaExceededError' ? 'penyimpanan browser penuh.' : error.message}`, 'error');
      }
    }
    render();
    if (imported) toast(`${imported} file berhasil disimpan di perangkat ini.`);
    if (activePage === 'library') renderLibrary();
  } finally {
    setBusy(false);
    $('#file-input').value = '';
  }
}
function openModal(title, kicker, content) {
  $('#modal-title').textContent = title;
  $('#modal-kicker').textContent = kicker;
  $('#modal-body').innerHTML = content;
  $('#modal-backdrop').hidden = false;
  $('#modal-close').focus();
}
function closeModal() { $('#modal-backdrop').hidden = true; }
function detailMarkup(app) {
  const a = app.analysis;
  const item = (label, value) => `<div class="detail-item"><small>${escapeHTML(label)}</small><b>${escapeHTML(value ?? '—')}</b></div>`;
  const notes = a?.notes?.length ? a.notes.map(n => `<li>${escapeHTML(n)}</li>`).join('') : '';
  return `<div class="detail-grid">
    ${item('Nama file', app.name)}${item('Ukuran', formatBytes(app.size))}
    ${item('Arsitektur', a?.architecture || 'Tidak diketahui')}${item('Format', a?.peFormat || 'Bukan PE valid')}
    ${item('Subsystem', a?.subsystem || '—')}${item('Jumlah section', a?.sectionCount ?? '—')}
    ${item('Tanggal impor', formatDate(app.importedAt))}${item('CLR / .NET', a ? (a.dotNet ? 'Terdeteksi' : 'Tidak terdeteksi') : '—')}
    ${item('Karakteristik', a?.characteristics || '—')}${item('Status executable', a ? (a.executable ? 'PE executable' : a.isDll ? 'DLL image' : 'Tidak ditandai executable') : '—')}
  </div>
  <h3 class="detail-section">Hasil kompatibilitas</h3>
  <div class="compat-box">${escapeHTML(app.analysisError || a?.compatibility || 'Belum ada hasil analisis.')}${notes ? `<ul>${notes}</ul>` : ''}</div>
  ${a?.sections?.length ? `<h3 class="detail-section">PE Sections (${a.sections.length} terbaca)</h3><div class="app-meta">${a.sections.map(s => `<span>${escapeHTML(s.name)} · ${formatBytes(s.rawSize)}</span>`).join(' &nbsp; ')}</div>` : ''}
  <div class="modal-actions"><button class="btn btn-secondary" data-action="download" data-id="${escapeHTML(app.id)}">↓ Simpan salinan EXE</button><button class="btn btn-primary" data-action="profile" data-id="${escapeHTML(app.id)}">Atur profil</button></div>`;
}
async function showDetails(id) {
  const app = await getApp(id);
  if (!app) return toast('File tidak ditemukan di database.', 'error');
  openModal(app.name, 'HASIL ANALISIS PE', detailMarkup(app));
}
async function showProfile(id) {
  const app = await getApp(id);
  if (!app) return toast('File tidak ditemukan.', 'error');
  const p = { ...DEFAULT_PROFILE, ...(app.profile || {}) };
  openModal('Profil kompatibilitas', `KONFIGURASI · ${app.name}`, `
    <p class="lead" style="margin:0 0 17px">Profil disimpan sebagai preferensi runtime. Nilai ini belum mengubah atau menjalankan file EXE.</p>
    <form id="profile-form" class="profile-form">
      <label>Alokasi RAM<select name="ram"><option value="1024" ${p.ram==='1024'?'selected':''}>1 GB</option><option value="2048" ${p.ram==='2048'?'selected':''}>2 GB</option><option value="3072" ${p.ram==='3072'?'selected':''}>3 GB</option><option value="4096" ${p.ram==='4096'?'selected':''}>4 GB</option><option value="6144" ${p.ram==='6144'?'selected':''}>6 GB</option><option value="8192" ${p.ram==='8192'?'selected':''}>8 GB</option></select></label>
      <label>Jumlah core CPU<select name="cpu">${['1','2','4','6','8'].map(v=>`<option ${p.cpu===v?'selected':''}>${v}</option>`).join('')}</select></label>
      <label>Resolusi<select name="resolution">${['800x600','1280x720','1366x768','1600x900','1920x1080'].map(v=>`<option ${p.resolution===v?'selected':''}>${v}</option>`).join('')}</select></label>
      <label>Preset grafis<select name="graphics"><option value="compatibility" ${p.graphics==='compatibility'?'selected':''}>Compatibility</option><option value="balanced" ${p.graphics==='balanced'?'selected':''}>Balanced</option><option value="performance" ${p.graphics==='performance'?'selected':''}>Performance</option></select></label>
      <label>Mode kontrol<select name="controls"><option value="touch" ${p.controls==='touch'?'selected':''}>Touchscreen</option><option value="gamepad" ${p.controls==='gamepad'?'selected':''}>Gamepad</option><option value="keyboard" ${p.controls==='keyboard'?'selected':''}>Keyboard / Mouse</option></select></label>
    </form>
    <div class="modal-actions"><button class="btn btn-primary" data-action="save-profile" data-id="${escapeHTML(app.id)}">Simpan profil</button><button class="btn btn-secondary" data-action="export-profile" data-id="${escapeHTML(app.id)}">Ekspor JSON</button></div>`);
}
function downloadBlob(blob, filename, type) {
  const url = URL.createObjectURL(new Blob([blob], { type }));
  const link = document.createElement('a');
  link.href = url; link.download = filename; link.style.display = 'none';
  document.body.append(link); link.click(); link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}
async function downloadExe(id) {
  const app = await getApp(id);
  if (!app?.blob) return toast('Data EXE tidak ditemukan.', 'error');
  downloadBlob(app.blob, app.name, app.type || 'application/octet-stream');
  toast(`Salinan ${app.name} disiapkan untuk diunduh.`);
}
function profilePayload(app) {
  return { schema: 'exe-to-apk-profile', schemaVersion: 1, app: { name: app.name, size: app.size, architecture: app.analysis?.architecture || null }, exportedAt: new Date().toISOString(), runtime: 'not-included', profile: { ...DEFAULT_PROFILE, ...(app.profile || {}) } };
}
async function exportProfile(id) {
  const app = await getApp(id);
  if (!app) return;
  downloadBlob(JSON.stringify(profilePayload(app), null, 2), `${app.name}.profile.json`, 'application/json');
  toast('Profil JSON berhasil diekspor.');
}
async function saveProfileFromModal(id) {
  const app = await getApp(id);
  const form = $('#profile-form');
  if (!app || !form) return;
  const data = Object.fromEntries(new FormData(form).entries());
  app.profile = { ...DEFAULT_PROFILE, ...data };
  app.profileSaved = true;
  await saveApp(app);
  apps = apps.map(item => item.id === id ? app : item);
  render(); closeModal(); toast('Profil kompatibilitas berhasil disimpan.');
}
async function moreActions(id) {
  const app = await getApp(id);
  if (!app) return;
  openModal('Kelola file', 'FILE ACTIONS', `<div class="detail-item"><small>File</small><b>${escapeHTML(app.name)}</b></div><div class="modal-actions"><button class="btn btn-secondary" data-action="download" data-id="${escapeHTML(id)}">↓ Unduh EXE</button><button class="btn btn-secondary" data-action="export-profile" data-id="${escapeHTML(id)}">Ekspor profil JSON</button><button class="btn btn-secondary" data-action="details" data-id="${escapeHTML(id)}">Lihat analisis</button><button class="btn btn-secondary" data-action="delete" data-id="${escapeHTML(id)}" style="border-color:#74404b;color:#ff9ca3">Hapus file</button></div>`);
}
async function deleteApp(id) {
  const app = await getApp(id);
  if (!app) return;
  const confirmed = window.confirm(`Hapus ${app.name} dan data EXE yang tersimpan di aplikasi?`);
  if (!confirmed) return;
  await removeApp(id);
  apps = apps.filter(item => item.id !== id);
  closeModal(); render(); toast(`${app.name} dihapus dari penyimpanan aplikasi.`);
}
async function loadSettings() {
  const settings = await getSetting('defaults', DEFAULT_SETTINGS);
  $('#default-ram').value = settings.ram || DEFAULT_SETTINGS.ram;
  $('#default-cpu').value = settings.cpu || DEFAULT_SETTINGS.cpu;
  $('#default-resolution').value = settings.resolution || DEFAULT_SETTINGS.resolution;
  $('#default-graphics').value = settings.graphics || DEFAULT_SETTINGS.graphics;
}
async function saveSettings() {
  const settings = { ram: $('#default-ram').value, cpu: $('#default-cpu').value, resolution: $('#default-resolution').value, graphics: $('#default-graphics').value };
  await saveSetting('defaults', settings);
  Object.assign(DEFAULT_PROFILE, settings);
  $('#settings-saved').textContent = `Tersimpan pada ${new Date().toLocaleTimeString('id-ID')}.`;
  toast('Pengaturan default disimpan.');
}
async function exportBackup() {
  const data = {
    schema: 'exe-to-apk-backup', schemaVersion: 1, exportedAt: new Date().toISOString(),
    note: 'Backup hanya berisi metadata dan profil, bukan binary EXE.',
    settings: await getSetting('defaults', DEFAULT_SETTINGS),
    apps: apps.map(app => ({ id: app.id, name: app.name, size: app.size, type: app.type, lastModified: app.lastModified, importedAt: app.importedAt, analysis: app.analysis, analysisError: app.analysisError, profile: app.profile, profileSaved: app.profileSaved }))
  };
  downloadBlob(JSON.stringify(data, null, 2), 'exe-to-apk-backup.json', 'application/json');
  toast('Backup metadata berhasil dibuat. File EXE tidak termasuk.');
}
async function importBackup(file) {
  try {
    const data = JSON.parse(await file.text());
    if (data.schema !== 'exe-to-apk-backup' || data.schemaVersion !== 1 || !Array.isArray(data.apps)) throw new Error('Format backup tidak didukung.');
    if (data.settings) await saveSetting('defaults', data.settings);
    let count = 0;
    for (const raw of data.apps) {
      if (!raw || typeof raw.name !== 'string' || !Number.isFinite(raw.size)) continue;
      const restored = { ...raw, id: makeId(), blob: null, restoredWithoutBinary: true };
      await saveApp(restored); apps.push(restored); count++;
    }
    await loadSettings(); render(); toast(`${count} metadata dipulihkan. File EXE harus diimpor ulang untuk menyimpan binary.`);
  } catch (error) { toast(`Backup gagal diimpor: ${error.message}`, 'error'); }
  $('#backup-input').value = '';
}

async function handleAction(event) {
  const button = event.target.closest('[data-action]');
  if (!button) return;
  const { action, id } = button.dataset;
  try {
    if (action === 'details') await showDetails(id);
    else if (action === 'profile') await showProfile(id);
    else if (action === 'more') await moreActions(id);
    else if (action === 'download') await downloadExe(id);
    else if (action === 'export-profile') await exportProfile(id);
    else if (action === 'save-profile') await saveProfileFromModal(id);
    else if (action === 'delete') await deleteApp(id);
  } catch (error) { toast(error.message || 'Operasi gagal.', 'error'); }
}

function setupDropZone() {
  const targets = [$('#page-home'), $('#page-library')];
  for (const target of targets) {
    target.addEventListener('dragover', event => { if (event.dataTransfer?.types.includes('Files')) { event.preventDefault(); target.classList.add('drag-over'); } });
    target.addEventListener('dragleave', event => { if (!target.contains(event.relatedTarget)) target.classList.remove('drag-over'); });
    target.addEventListener('drop', event => {
      if (event.dataTransfer?.files?.length) { event.preventDefault(); target.classList.remove('drag-over'); importFiles(event.dataTransfer.files); }
    });
  }
}

function bindEvents() {
  document.addEventListener('click', event => {
    const nav = event.target.closest('[data-nav]');
    if (nav) { event.preventDefault(); navigate(nav.dataset.nav); return; }
    if (event.target.closest('#import-button, #empty-import, #library-import, #library-empty-import')) $('#file-input').click();
  });
  $('#file-input').addEventListener('change', event => importFiles(event.target.files));
  $('#recent-list').addEventListener('click', handleAction);
  $('#library-list').addEventListener('click', handleAction);
  $('#modal-body').addEventListener('click', handleAction);
  $('#search-input').addEventListener('input', renderLibrary);
  $('#sort-select').addEventListener('change', renderLibrary);
  $('#modal-close').addEventListener('click', closeModal);
  $('#modal-backdrop').addEventListener('click', event => { if (event.target === $('#modal-backdrop')) closeModal(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape') closeModal(); });
  $('#save-settings').addEventListener('click', saveSettings);
  $('#export-backup').addEventListener('click', exportBackup);
  $('#backup-input').addEventListener('change', event => { const file = event.target.files?.[0]; if (file) importBackup(file); });
}

async function init() {
  try {
    apps = await getAllApps();
    await loadSettings();
    const runtime = getRuntimeStatus();
    if (runtime.available) console.info('Native runtime available');
    render();
    bindEvents();
    setupDropZone();
    if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) {
      navigator.serviceWorker.register('./service-worker.js').catch(error => console.warn('Service worker tidak aktif:', error));
    }
  } catch (error) {
    toast(error.message || 'Aplikasi gagal diinisialisasi.', 'error');
    console.error(error);
  }
}

init();
