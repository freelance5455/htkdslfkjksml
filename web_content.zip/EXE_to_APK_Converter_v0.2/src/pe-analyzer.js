const MACHINE_TYPES = new Map([
  [0x014c, 'x86 (Intel 32-bit)'],
  [0x8664, 'x64 (AMD64 / Intel 64-bit)'],
  [0x01c0, 'ARM (32-bit)'],
  [0x01c4, 'ARMv7 / Thumb-2'],
  [0xaa64, 'ARM64 (AArch64)'],
  [0x0200, 'IA-64 (Itanium)'],
  [0x01f0, 'PowerPC'],
  [0x5032, 'RISC-V 32-bit'],
  [0x5064, 'RISC-V 64-bit'],
  [0x5128, 'RISC-V 128-bit']
]);

function ensureRange(offset, length, total, what) {
  if (!Number.isSafeInteger(offset) || !Number.isSafeInteger(length) || offset < 0 || length < 0 || offset + length > total) {
    throw new Error(`Header EXE tidak lengkap atau rusak (${what}).`);
  }
}
function readAscii(view, offset, length) {
  let result = '';
  for (let i = 0; i < length; i++) {
    const code = view.getUint8(offset + i);
    if (code === 0) break;
    result += String.fromCharCode(code);
  }
  return result;
}

export async function analyzePE(file) {
  if (!(file instanceof Blob)) throw new Error('Input file tidak valid.');
  if (file.size < 64) throw new Error('File terlalu kecil untuk menjadi executable Windows yang valid.');
  const buffer = await file.slice(0, Math.min(file.size, 2 * 1024 * 1024)).arrayBuffer();
  const view = new DataView(buffer);
  ensureRange(0, 64, buffer.byteLength, 'DOS header');
  if (view.getUint16(0, true) !== 0x5a4d) throw new Error('Signature MZ tidak ditemukan. File ini bukan executable Windows PE yang dikenali.');

  const peOffset = view.getUint32(0x3c, true);
  ensureRange(peOffset, 24, buffer.byteLength, 'PE signature / COFF header');
  if (view.getUint32(peOffset, true) !== 0x00004550) throw new Error('Signature PE tidak ditemukan. File mungkin DOS executable lama, installer khusus, atau file rusak.');

  const machine = view.getUint16(peOffset + 4, true);
  const sectionCount = view.getUint16(peOffset + 6, true);
  const timestamp = view.getUint32(peOffset + 8, true);
  const optionalSize = view.getUint16(peOffset + 20, true);
  const characteristics = view.getUint16(peOffset + 22, true);
  const optionalOffset = peOffset + 24;
  ensureRange(optionalOffset, optionalSize, buffer.byteLength, 'optional header');
  const magic = optionalSize >= 2 ? view.getUint16(optionalOffset, true) : 0;
  const peFormat = magic === 0x10b ? 'PE32' : magic === 0x20b ? 'PE32+' : `Tidak dikenal (0x${magic.toString(16)})`;
  const is64 = magic === 0x20b;

  let subsystem = 'Tidak diketahui';
  let clr = false;
  if (optionalSize >= 70) {
    const subsystemCode = view.getUint16(optionalOffset + 68, true);
    subsystem = ({ 1: 'Native', 2: 'Windows GUI', 3: 'Windows Console', 5: 'OS/2 Console', 7: 'POSIX Console', 9: 'Windows CE GUI', 10: 'EFI Application', 11: 'EFI Boot Service Driver', 12: 'EFI Runtime Driver', 13: 'EFI ROM', 14: 'Xbox' })[subsystemCode] || `Lainnya (${subsystemCode})`;
  }
  const directoryCountOffset = is64 ? 108 : 92;
  const directoryOffset = is64 ? 112 : 96;
  if (optionalSize >= directoryCountOffset + 4) {
    const directoryCount = view.getUint32(optionalOffset + directoryCountOffset, true);
    const clrEntryOffset = directoryOffset + 14 * 8;
    if (directoryCount > 14 && optionalSize >= clrEntryOffset + 8) {
      const clrRva = view.getUint32(optionalOffset + clrEntryOffset, true);
      const clrSize = view.getUint32(optionalOffset + clrEntryOffset + 4, true);
      clr = clrRva !== 0 && clrSize !== 0;
    }
  }

  const sections = [];
  const sectionTableOffset = optionalOffset + optionalSize;
  const maxSectionsReadable = Math.min(sectionCount, 96);
  if (maxSectionsReadable > 0 && sectionTableOffset < buffer.byteLength) {
    const readable = Math.min(maxSectionsReadable, Math.floor((buffer.byteLength - sectionTableOffset) / 40));
    for (let i = 0; i < readable; i++) {
      const base = sectionTableOffset + i * 40;
      sections.push({ name: readAscii(view, base, 8) || `section_${i}`, virtualSize: view.getUint32(base + 8, true), rawSize: view.getUint32(base + 16, true) });
    }
  }

  const arch = MACHINE_TYPES.get(machine) || `Tidak dikenal (0x${machine.toString(16).padStart(4, '0')})`;
  const executable = Boolean(characteristics & 0x0002);
  const dll = Boolean(characteristics & 0x2000);
  const notes = [];
  if (machine === 0x8664) notes.push('Aplikasi x64 umumnya membutuhkan translasi x86-64 seperti Box64 pada perangkat ARM64.');
  else if (machine === 0x014c) notes.push('Aplikasi x86 32-bit memerlukan dukungan translasi 32-bit yang sesuai, misalnya Box86 atau konfigurasi Box64 yang mendukungnya.');
  else if (machine === 0xaa64 || machine === 0x01c4 || machine === 0x01c0) notes.push('Arsitektur ARM terdeteksi; kompatibilitas tetap bergantung pada Wine, ABI Android, dan library yang tersedia.');
  else notes.push('Arsitektur ini tidak umum pada lingkungan Windows Android; verifikasi dukungan runtime sebelum mencoba menjalankan.');
  if (clr) notes.push('CLR/.NET data directory terdeteksi. Program mungkin memerlukan .NET runtime atau Mono yang cocok.');
  if (dll) notes.push('File ditandai sebagai DLL, bukan aplikasi mandiri yang dapat dijalankan langsung.');
  if (!executable) notes.push('PE characteristics tidak menandai file sebagai executable image.');
  if (sectionCount > sections.length) notes.push('Sebagian tabel section berada di luar potongan header yang dibaca; jumlah section penuh tetap tercatat.');

  return {
    validPE: true, machine, architecture: arch, peFormat, is64Bit: is64,
    sectionCount, sections, timestamp: timestamp ? new Date(timestamp * 1000).toISOString() : null,
    subsystem, isDll: dll, executable, dotNet: clr,
    characteristics: `0x${characteristics.toString(16).padStart(4, '0')}`,
    compatibility: machine === 0x8664 || machine === 0x014c || machine === 0xaa64 || machine === 0x01c4 || machine === 0x01c0 ? 'Perlu runtime sesuai arsitektur' : 'Belum diketahui',
    notes
  };
}

export function formatBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes < 0) return '—';
  if (bytes === 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  return `${(bytes / (1024 ** index)).toFixed(index === 0 ? 0 : 2)} ${units[index]}`;
}
