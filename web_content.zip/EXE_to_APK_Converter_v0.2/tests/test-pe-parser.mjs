import { analyzePE } from '../src/pe-analyzer.js';
const bytes = new Uint8Array(512);
const v = new DataView(bytes.buffer);
v.setUint16(0, 0x5a4d, true);
v.setUint32(0x3c, 0x80, true);
v.setUint32(0x80, 0x00004550, true);
v.setUint16(0x84, 0x8664, true);
v.setUint16(0x86, 1, true);
v.setUint32(0x88, 1700000000, true);
v.setUint16(0x94, 0xf0, true);
v.setUint16(0x96, 0x0022, true);
v.setUint16(0x98, 0x20b, true);
v.setUint32(0x98 + 108, 16, true);
v.setUint16(0x98 + 68, 2, true);
v.setUint32(0x98 + 112 + 14*8, 0x1234, true);
v.setUint32(0x98 + 112 + 14*8 + 4, 0x40, true);
const section = 0x80 + 24 + 0xf0;
for (const [i,c] of [...'.text'].entries()) v.setUint8(section+i,c.charCodeAt(0));
v.setUint32(section+16, 256, true);
const file = new Blob([bytes], { type: 'application/octet-stream' });
file.name = 'sample.exe';
const result = await analyzePE(file);
if (!result.validPE || result.architecture !== 'x64 (AMD64 / Intel 64-bit)' || result.peFormat !== 'PE32+' || !result.dotNet || result.subsystem !== 'Windows GUI' || result.sections[0].name !== '.text') {
  console.error(result); process.exit(1);
}
console.log('PE parser test passed:', result.architecture, result.peFormat, 'CLR:', result.dotNet, 'section:', result.sections[0].name);
