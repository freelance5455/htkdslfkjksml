# Rancangan integrasi runtime native — v0.2

Dokumen ini adalah rencana teknis untuk versi Android native berikutnya. Ini bukan runtime siap pakai dan tidak menyertakan binary Wine/Box64.

## Mengapa aplikasi web tidak dapat menjalankan EXE

File PE/Windows membutuhkan implementasi Windows API dan eksekusi instruksi CPU yang tepat. Browser sandbox tidak dapat memuat executable native arbitrary atau menyediakan ABI Linux/Android yang dibutuhkan Wine/Box64. JavaScript dapat membaca header file sebagai data, tetapi tidak mengeksekusi PE.

## Arsitektur target

```text
Android UI (Kotlin)
   ├── SAF / ContentResolver (pemilihan EXE)
   ├── Room / SQLite (library & profile)
   ├── Runtime Manager
   │     ├── Wine Android build (Windows API compatibility)
   │     ├── Box64 / Box86 (CPU translation where required)
   │     ├── Root filesystem + runtime libraries
   │     └── Per-app prefix / registry / environment
   ├── Native Bridge (JNI / foreground service)
   └── Renderer & input bridge (Vulkan/OpenGL path, touch/gamepad)
```

## Komponen wajib sebelum fitur Run dapat diaktifkan

1. Tetapkan ABI dan Android API minimum yang benar-benar diuji (misalnya arm64-v8a; jangan menganggap semua SoC/GPU kompatibel).
2. Bangun/ambil distribusi Wine yang lisensinya sesuai dan kompatibel dengan Android/NDK serta target API.
3. Integrasikan Box64 dan, bila dibutuhkan oleh target aplikasi, dukungan x86 32-bit yang kompatibel. Periksa lisensi dan atribusi setiap komponen.
4. Siapkan root filesystem dan library pendukung yang konsisten dengan versi Wine; sediakan downloader/resume atau paket terpisah dengan checksum dan verifikasi tanda tangan.
5. Implementasikan proses native melalui JNI/child process yang sah untuk lingkungan aplikasi, lifecycle, signal, stdout/stderr, exit code, dan pengelolaan proses.
6. Integrasikan renderer grafis berdasarkan kemampuan driver/GPU; jangan menjanjikan DirectX/Vulkan translation tanpa backend yang telah diuji.
7. Hubungkan input touchscreen/gamepad, audio, clipboard, filesystem mapping, permission, dan isolasi data.
8. Uji installer, aplikasi Win32, .NET, game 2D/3D, suspend/resume, overheating, konsumsi RAM, dan perangkat low-end.

## Kontrak bridge yang disiapkan

`src/runtime-bridge.js` sengaja melaporkan runtime tidak tersedia dan melempar `RuntimeUnavailableError` ketika operasi eksekusi/build APK dipanggil. Android host dapat mengganti implementasi ini dengan bridge native yang memeriksa capability secara eksplisit. Tombol Run/Build tidak boleh ditampilkan aktif sebelum preflight runtime dan perangkat berhasil.

Contoh status yang sebaiknya dikembalikan implementasi native:

```json
{
  "available": true,
  "abi": "arm64-v8a",
  "wineVersion": "version-under-test",
  "box64Version": "version-under-test",
  "rootfsId": "verified-rootfs-id",
  "gpuBackend": "backend-under-test"
}
```

Nilai contoh di atas hanya skema data, bukan klaim bahwa komponen tersebut sudah terpasang.

## Tentang APK pembungkus

APK wrapper yang memuat file EXE tetap membutuhkan runtime untuk mengeksekusinya. APK wrapper bukan hasil konversi EXE ke kode Android native. Jika runtime besar, pendekatan yang masuk akal adalah APK launcher kecil + runtime/rootfs yang dipasang terpisah, dengan pemeriksaan integritas dan lisensi yang benar.
