# Changelog

## v0.2.0
- Pindah ke paket Web Edition: HTML/CSS/JavaScript modular.
- Dashboard responsif, library, halaman runtime, dan pengaturan.
- Analisis metadata PE langsung dari bytes file EXE.
- Penyimpanan binary EXE dan profil lokal melalui IndexedDB.
- Detail file, pencarian, sorting, delete, dan download ulang.
- Ekspor/impor backup metadata serta ekspor profil JSON.
- PWA manifest dan service worker untuk shell offline.
- Runtime Windows dan konversi APK tidak diklaim tersedia tanpa engine native.
