# EXE to APK Converter — Web Edition v0.2.0

Paket aplikasi web offline-first berbasis HTML, CSS, dan JavaScript vanilla. Dapat dibuka di browser desktop maupun Android. Antarmuka dan fitur lokal tidak membutuhkan server backend.

## Fitur yang benar-benar berfungsi

- Import satu atau beberapa file `.exe` melalui pemilih file atau drag-and-drop.
- Membaca header DOS/PE dari file lokal: signature, machine/arsitektur, PE32/PE32+, subsystem, jumlah section, flags, dan indikasi CLR/.NET.
- Menyimpan binary EXE dan metadata di IndexedDB browser (di perangkat pengguna).
- Library dengan pencarian, pengurutan, detail analisis, unduh kembali, dan penghapusan file tersimpan.
- Profil konfigurasi per file: RAM, CPU, resolusi, preset grafis, serta mode kontrol.
- Ekspor profil JSON dan backup metadata; impor metadata dari backup.
- Pengaturan default lokal dan estimasi kuota storage bila browser mendukungnya.
- PWA/service worker untuk cache shell aplikasi ketika disajikan melalui HTTPS atau localhost.

## Batasan yang dinyatakan secara jujur

Versi web ini **tidak menjalankan EXE Windows** dan **tidak mengubah EXE menjadi APK native**. Browser Android tidak menyediakan akses langsung ke ABI/native execution yang diperlukan untuk Wine dan Box64. Sistem file dan konfigurasi dalam versi ini adalah persiapan/profil manajemen, bukan emulator.

Untuk menjalankan aplikasi Windows dibutuhkan host Android native (Kotlin/Java + NDK/JNI), binary Wine yang dibangun untuk Android/ABI target, Box64/Box86 yang sesuai, root filesystem beserta library, pengaturan GPU/driver, serta integrasi input dan audio. Komponen itu tidak disertakan dalam ZIP ini. Rancangan dan urutan pengembangan ada di `RUNTIME_INTEGRATION.md`.

## Menjalankan

### Cara cepat di Android

Buka `standalone.html` dari file manager lalu pilih browser modern. File ini sudah menyatukan HTML, CSS, dan JavaScript sehingga tidak membutuhkan server atau file modul terpisah. IndexedDB pada alamat `file://` bergantung pada browser; bila penyimpanan tidak tersedia atau tidak bertahan setelah browser ditutup, gunakan metode HTTPS/localhost di bawah.

### Mode modular / PWA

Sajikan `index.html` bersama folder `src/` dan file pendukung melalui server lokal atau hosting HTTPS. Mode ini mendukung service worker dan dapat ditambahkan ke layar utama sebagai PWA. Jangan buka `index.html` modular langsung dengan `file://` karena browser umumnya membatasi ES Modules dari alamat file.

### Server lokal (desktop)

Dengan Python:

```bash
python -m http.server 8000
```

Kemudian buka `http://localhost:8000` di browser.

### Android

1. Ekstrak ZIP ke folder perangkat atau hosting statis HTTPS.
2. Buka alamat `index.html` melalui server lokal/HTTPS di Chrome.
3. Pilih **Add to Home screen / Tambahkan ke layar utama** untuk pengalaman PWA jika browser menawarkan opsi tersebut.
4. Berikan izin pemilih dokumen saat memilih file EXE. File diproses di perangkat; tidak dikirim ke server.

Catatan: mode PWA/service worker memerlukan HTTPS atau localhost. Membuka `index.html` langsung tidak mengaktifkan service worker.

## Penyimpanan dan privasi

File EXE disimpan sebagai Blob di IndexedDB pada origin browser. Menghapus data situs/browser dapat menghapus file tersebut. Backup JSON hanya mengandung metadata dan profil—bukan binary EXE. Gunakan tombol unduh EXE untuk menyimpan salinan file secara terpisah.

## Pengujian

Parser PE memiliki tes mandiri yang membangun contoh header PE32+ x64 dan memeriksa deteksi arsitektur, subsystem, CLR, dan section. Jalankan dengan Node.js:

```bash
node --experimental-default-type=module tests/test-pe-parser.mjs
```

## Struktur

```text
EXE_to_APK_Converter_v0.2/
├── index.html
├── standalone.html (semua HTML/CSS/JS dalam satu file)
├── styles.css
├── manifest.webmanifest
├── service-worker.js
├── README.md
├── RUNTIME_INTEGRATION.md
├── assets/icon.svg
├── assets/icon-192.png
├── assets/icon-512.png
├── tests/test-pe-parser.mjs
└── src/
    ├── app.js
    ├── db.js
    ├── pe-analyzer.js
    └── runtime-bridge.js
```

## Target teknis

- HTML5, CSS3, JavaScript ES Modules
- IndexedDB untuk binary dan metadata
- Web App Manifest + Service Worker
- Tanpa framework dan tanpa dependency CDN wajib
- UI mobile responsive, dark mode

Tidak ada dependency CDN atau library eksternal wajib; font sistem digunakan agar paket lebih ringan dan tetap offline.
