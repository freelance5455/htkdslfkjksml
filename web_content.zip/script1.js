
(function(){
  const KEY='tailleurpro_v1';
  const TAILLEURPRO_WHATSAPP='';

  const SUPABASE_URL='https://zapbfinagzjwjpqkfqom.supabase.co';
  const SUPABASE_PUBLISHABLE_KEY='sb_publishable_x1Od9lqAvGPy3SQIXjBz6A_p2pnUZHP';
  const supa=(window.supabase&&SUPABASE_URL&&SUPABASE_PUBLISHABLE_KEY)
    ? window.supabase.createClient(SUPABASE_URL,SUPABASE_PUBLISHABLE_KEY)
    : null;

  async function handleTailleurProAuthUrl(url){
    if(!supa || !url) return false;
    try{
      const u=new URL(url);
      const hash=new URLSearchParams(String(u.hash||'').replace(/^#/,'')).entries();
      const h=Object.fromEntries(hash);
      const q=u.searchParams;
      if(q.get('error')){
        setTimeout(()=>toast('La confirmation e-mail a échoué : '+(q.get('error_description')||q.get('error'))),300);
        return false;
      }
      if(q.get('code')){
        const {error}=await supa.auth.exchangeCodeForSession(q.get('code'));
        if(error) throw error;
      }else if(h.access_token && h.refresh_token){
        const {error}=await supa.auth.setSession({access_token:h.access_token,refresh_token:h.refresh_token});
        if(error) throw error;
      }else return false;
      if(recoveryFlow){
        window.forgotOrigin='login';
        setTimeout(()=>toast('Lien de réinitialisation validé. Choisissez votre nouveau mot de passe.'),300);
        setTimeout(()=>go('verify'),700);
      }else{
        setTimeout(()=>toast('Adresse e-mail confirmée avec succès ! Vous pouvez maintenant vous connecter.'),300);
        setTimeout(()=>go('login'),700);
      }
      return true;
    }catch(e){
      setTimeout(()=>toast('Confirmation e-mail reçue, mais la session n’a pas pu être finalisée.'),300);
      return false;
    }
  }

  async function initTailleurProDeepLink(){
    try{
      const AppPlugin=window.Capacitor?.Plugins?.App;
      if(!AppPlugin) return;
      AppPlugin.addListener('appUrlOpen',e=>handleTailleurProAuthUrl(e?.url||''));
      const launch=await AppPlugin.getLaunchUrl();
      if(launch?.url) await handleTailleurProAuthUrl(launch.url);
    }catch(e){}
  }
  let cloudReady=false, recoveryFlow=false;
  if(supa){supa.auth.onAuthStateChange((event)=>{if(event==='PASSWORD_RECOVERY'){recoveryFlow=true;window.forgotOrigin='login';setTimeout(()=>go('verify'),50);}});}
  initTailleurProDeepLink();
  function cloudEnabled(){return !!supa}
  function cloudEmail(){return String(db.account?.email||'').trim().toLowerCase()}
  async function cloudSignUp(){
    if(!supa)return {ok:false,message:'Mode local'};
    const email=cloudEmail(), password=String(db.account?.password||'');
    if(!isValidLoginEmail(email))return {ok:false,message:'Entrez une adresse e-mail valide pour créer le compte.'};
    const {data,error}=await supa.auth.signUp({email,password,options:{emailRedirectTo:'tailleurpro://auth/callback',data:{full_name:db.account?.name||'',phone:db.account?.phone||''}}});
    if(error)return {ok:false,message:error.message};
    if(!data.session)return {ok:false,message:'Compte créé. Un e-mail de confirmation vient de vous être envoyé. Vérifiez votre boîte de réception, puis confirmez votre adresse e-mail pour continuer.'};
    await cloudEnsureAtelier();
    return {ok:true};
  }
  async function cloudLogin(email,password){
    if(!supa)return {ok:false,message:'Mode local'};
    const emailValue=String(email||'').trim().toLowerCase();
    if(!isValidLoginEmail(emailValue)) return {ok:false,message:'Adresse e-mail ou mot de passe incorrect.'};
    const {data,error}=await supa.auth.signInWithPassword({email:emailValue,password});
    if(error)return {ok:false,message:error.message};
    cloudReady=!!data.session;
    if(!cloudReady)return {ok:false,message:'Session de connexion non disponible.'};

    // Restaurer uniquement la sauvegarde locale associée à cet e-mail.
    // Ne jamais vider les données avant d'avoir réussi à lire le serveur.
    let localBackup=null;
    try{
      const backupKey='tailleurpro_backup_'+btoa(unescape(encodeURIComponent(emailValue)));
      const raw=localStorage.getItem(backupKey);
      if(raw){const parsed=JSON.parse(raw);if(parsed&&typeof parsed==='object')localBackup=parsed;}
    }catch(e){}
    db=localBackup?{...structuredClone(defaultDB),...localBackup}:structuredClone(defaultDB);
    db.account={...(db.account||{}),email:emailValue};
    db.clients=Array.isArray(db.clients)?db.clients:[];
    db.orders=Array.isArray(db.orders)?db.orders:[];
    db.settings=db.settings||structuredClone(defaultDB.settings);
    db.subscription=db.subscription||structuredClone(defaultDB.subscription);
    saveLocalOnly();

    const pulled=await cloudPull();
    if(!pulled.ok){
      saveLocalOnly();
      renderHome();renderClients();renderOrders();
      return {ok:true,warning:'Connexion réussie, mais synchronisation non confirmée : '+(pulled.message||'réessayez avec Actualiser. Vos données locales sont conservées.')};
    }
    // Après fusion serveur/local, tenter d'envoyer les éventuelles données locales absentes du serveur.
    if(db.clients.length||db.orders.length){
      const synced=await cloudSync();
      if(!synced.ok){saveLocalOnly();return {ok:true,warning:'Connexion réussie, mais envoi au serveur impossible : '+synced.message+'. Les données restent sur cet appareil.'};}
    }
    return {ok:true,warning:pulled.warning||''};
  }
  async function cloudEnsureAtelier(){
    if(!supa)return null;
    const {data:{user},error:userError}=await supa.auth.getUser();
    if(userError||!user)return null;
    let {data:atelier,error}=await supa.from('ateliers').select('*').eq('owner_id',user.id).maybeSingle();
    if(error){
      return {__error:error.message||'Impossible de lire l’atelier du compte.'};
    }
    if(!atelier){
      const ins=await supa.from('ateliers').insert({owner_id:user.id,name:db.atelier?.name||db.account?.name||'Mon atelier',phone:db.atelier?.phone||'',address:db.atelier?.location||''}).select().single();
      if(ins.error)return {__error:ins.error.message||'Impossible de créer l’atelier du compte.'};
      atelier=ins.data;
    }
    db.cloudAtelierId=atelier.id;
    cloudReady=true;
    return atelier;
  }
  async function cloudPull(){
    if(!supa)return {ok:false,message:'Connexion serveur indisponible.'};
    const atelier=await cloudEnsureAtelier();
    if(!atelier || atelier.__error)return {ok:false,message:atelier?.__error||'Votre atelier n’a pas pu être chargé.'};
    const {data:{user},error:userError}=await supa.auth.getUser();
    if(userError||!user)return {ok:false,message:'Session Supabase introuvable.'};
    const results=await Promise.allSettled([
      supa.from('profiles').select('full_name,phone').eq('id',user.id).maybeSingle(),
      supa.from('clients').select('*').eq('owner_id',user.id).eq('atelier_id',atelier.id).order('created_at'),
      supa.from('orders').select('*').eq('owner_id',user.id).eq('atelier_id',atelier.id).order('created_at'),
      supa.from('payments').select('*').eq('owner_id',user.id).eq('atelier_id',atelier.id).order('payment_date'),
      supa.from('subscriptions').select('*').eq('atelier_id',atelier.id).maybeSingle()
    ]);
    const [ur,cr,or,pr,sr]=results.map(x=>x.status==='fulfilled'?x.value:{data:null,error:x.reason||{message:'Erreur de chargement'}});
    const failures=[];
    for(const [label,r] of [['profil',ur],['clients',cr],['commandes',or],['paiements',pr],['abonnement',sr]]) if(r?.error) failures.push(label+': '+(r.error.message||'erreur inconnue'));
    if(ur.data)db.account={...(db.account||{}),name:ur.data.full_name||db.account?.name||'',email:user.email||db.account?.email||'',phone:ur.data.phone||db.account?.phone||''};
    db.atelier={...(db.atelier||{}),name:atelier.name||db.atelier?.name||'',phone:atelier.phone||db.atelier?.phone||'',location:atelier.address||db.atelier?.location||'',logo:atelier.logo_url||db.atelier?.logo||''};

    const clientsLoaded=!cr.error && Array.isArray(cr.data);
    const paymentsLoaded=!pr.error && Array.isArray(pr.data);
    const ordersLoaded=!or.error && Array.isArray(or.data);
    if(!clientsLoaded || !ordersLoaded){
      saveLocalOnly();
      return {ok:false,message:'Lecture Supabase impossible — '+failures.filter(x=>x.startsWith('clients:')||x.startsWith('commandes:')).join(' ; ')};
    }

    // Fusionner par identifiant : une réponse vide ou partielle ne doit jamais effacer des données locales.
    const localClients=Array.isArray(db.clients)?db.clients:[];
    const remoteClients=(cr.data||[]).map(c=>({id:c.id,name:c.full_name||'',phone:c.phone||'',sex:'',photo:c.photo_url||'',note:c.notes||'',orders:0,measures:c.measurements||{}}));
    const clientMap=new Map(localClients.map(c=>[String(c.id),c]));
    remoteClients.forEach(c=>clientMap.set(String(c.id),{...(clientMap.get(String(c.id))||{}),...c,photo:c.photo||(clientMap.get(String(c.id))||{}).photo||''}));
    const clients=[...clientMap.values()];

    const paymentsBy={};
    if(paymentsLoaded)(pr.data||[]).forEach(x=>(paymentsBy[x.order_id]??=[]).push({id:x.id||makeUuid(),amount:Number(x.amount),date:x.payment_date?.slice(0,10)||'',method:x.payment_method||'Paiement',note:x.notes||''}));
    const localOrders=Array.isArray(db.orders)?db.orders:[];
    const orderMap=new Map(localOrders.map(o=>[String(o.id),o]));
    (or.data||[]).forEach(o=>{
      const old=orderMap.get(String(o.id))||{};
      const remotePays=paymentsLoaded?(paymentsBy[o.id]||[]):(old.payments||[]);
      const pays=remotePays.length?remotePays:(old.payments||[]);
      const paid=pays.reduce((a,p)=>a+Number(p.amount||0),0);
      const status=o.status==='pending'?'En attente':o.status==='in_progress'?'En cours':o.status==='ready'?'Prêt':o.status==='delivered'?'Livré':'Annulée';
      orderMap.set(String(o.id),{...old,id:o.id,clientId:o.client_id,type:o.garment_type||'',model:o.model||'',fabric:o.fabric||'',total:Number(o.total_amount||0),advance:paid,delivery:o.delivery_date||'',status,notes:o.notes||'',measurements:clients.find(c=>c.id===o.client_id)?.measures||old.measurements||{},payments:pays,createdAt:o.created_at?.slice(0,10)||old.createdAt||'',createdMonthKey:o.created_at?.slice(0,7)||old.createdMonthKey||''});
    });
    const orders=[...orderMap.values()];
    clients.forEach(c=>c.orders=orders.filter(o=>o.clientId===c.id).length);
    db.clients=clients;db.orders=orders;
    if(paymentsLoaded){
      // Keep local payment records that have not reached the server yet.
      for(const o of db.orders){
        const remote=paymentsBy[o.id]||[];
        const local=Array.isArray(o.payments)?o.payments:[];
        const pm=new Map(local.map(x=>[String(x.id),x]));
        remote.forEach(x=>pm.set(String(x.id),x));
        o.payments=[...pm.values()];
        o.advance=o.payments.reduce((sum,x)=>sum+Number(x.amount||0),0);
      }
    }
    if(sr.data)db.subscription={...db.subscription,plan:sr.data.plan,status:sr.data.status,startedAt:sr.data.started_at,expiresAt:sr.data.expires_at,monthlyOrders:sr.data.monthly_orders||0,monthKey:sr.data.month_key||''};
    saveLocalOnly();renderHome();renderClients();renderOrders();renderSubscription();renderPlanCard();
    return {ok:true,warning:failures.length?'Certaines données secondaires ne sont pas confirmées : '+failures.join(' ; '):''};
  }
  function saveLocalOnly(){try{localStorage.setItem(KEY,JSON.stringify(db));return true}catch(e){return false}}
  let cloudSyncTimer=null, cloudSyncing=false, cloudSyncPending=false, cloudSyncWaiters=[], lastSyncError='';
  function scheduleCloudSync(){
    if(!supa||!cloudReady)return;
    if(cloudSyncing){cloudSyncPending=true;return;}
    clearTimeout(cloudSyncTimer);
    cloudSyncTimer=setTimeout(()=>{cloudSync().catch(()=>{})},700);
  }
  async function waitForCloudSync(){
    if(!cloudSyncing)return;
    await new Promise(resolve=>cloudSyncWaiters.push(resolve));
  }
  function finishCloudSyncWaiters(){
    const list=cloudSyncWaiters.splice(0); list.forEach(resolve=>resolve());
  }
  async function cloudSync(){
    if(!supa||!cloudReady)return {ok:false,message:'Synchronisation indisponible : session cloud absente.'};
    if(cloudSyncing){cloudSyncPending=true;await waitForCloudSync();return lastSyncError?{ok:false,message:lastSyncError}:{ok:true};}
    cloudSyncing=true;lastSyncError='';
    try{
      const atelier=await cloudEnsureAtelier();
      if(!atelier||atelier.__error)throw new Error(atelier?.__error||'Atelier introuvable.');
      const {data:{user},error:userError}=await supa.auth.getUser();
      if(userError||!user)throw new Error('Session Supabase introuvable.');
      const now=new Date().toISOString();

      // Stabiliser les UUID avant l'envoi et conserver les liens commande -> client.
      const clientIdMap=new Map();
      for(const c of db.clients){
        const old=String(c.id||'');
        if(!isUuid(c.id))c.id=makeUuid();
        if(old && old!==c.id)clientIdMap.set(old,c.id);
      }
      for(const o of db.orders){
        if(clientIdMap.has(String(o.clientId)))o.clientId=clientIdMap.get(String(o.clientId));
        if(!isUuid(o.id))o.id=makeUuid();
        for(const pay of (o.payments||[]))if(!isUuid(pay.id))pay.id=makeUuid();
      }

      // Chaque écriture porte owner_id, requis par les policies RLS actuelles.
      for(const c of db.clients){
        const payload={id:c.id,atelier_id:atelier.id,owner_id:user.id,full_name:c.name||'',phone:c.phone||'',address:'',photo_url:c.photo||null,notes:c.note||'',measurements:c.measures||{},updated_at:now};
        const res=await supa.from('clients').upsert(payload,{onConflict:'id'});
        if(res.error)throw new Error('Clients — '+res.error.message);
      }
      for(const o of db.orders){
        const client=db.clients.find(c=>String(c.id)===String(o.clientId));
        if(!client)throw new Error('Commande '+String(o.id)+' : client associé introuvable.');
        const statusMap={'En attente':'pending','En cours':'in_progress','Prêt':'ready','Livré':'delivered','Annulée':'cancelled'};
        const payload={id:o.id,atelier_id:atelier.id,owner_id:user.id,client_id:client.id,order_number:String(o.orderNumber||''),garment_type:o.type||'',model:o.model||'',fabric:o.fabric||'',total_amount:Number(o.total||0),delivery_date:o.delivery||null,status:statusMap[o.status]||'pending',notes:o.notes||'',updated_at:now};
        const res=await supa.from('orders').upsert(payload,{onConflict:'id'});
        if(res.error)throw new Error('Commandes — '+res.error.message);
        for(const pay of (o.payments||[])){
          const paymentPayload={id:pay.id,atelier_id:atelier.id,owner_id:user.id,order_id:o.id,amount:Number(pay.amount||0),payment_method:pay.method||'Paiement',payment_date:toPaymentIso(pay.date,now),notes:pay.note||''};
          const pr=await supa.from('payments').upsert(paymentPayload,{onConflict:'id'});
          if(pr.error)throw new Error('Paiements — '+pr.error.message);
        }
      }
      saveLocalOnly();
      return {ok:true};
    }catch(e){
      lastSyncError=e?.message||'Erreur inconnue de synchronisation';
      saveLocalOnly();
      return {ok:false,message:lastSyncError};
    }finally{
      cloudSyncing=false;finishCloudSyncWaiters();
      if(cloudSyncPending){cloudSyncPending=false;scheduleCloudSync();}
    }
  }
  function toPaymentIso(value,fallback){
    if(!value)return fallback;
    const s=String(value).trim();
    // Preserve ISO dates; local French display dates are not reliably parseable by Date.
    if(/^\d{4}-\d{2}-\d{2}/.test(s)){const d=new Date(s);return Number.isNaN(d.getTime())?fallback:d.toISOString();}
    const fr=s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if(fr){const d=new Date(Number(fr[3]),Number(fr[2])-1,Number(fr[1]),12,0,0);return Number.isNaN(d.getTime())?fallback:d.toISOString();}
    const d=new Date(s);return Number.isNaN(d.getTime())?fallback:d.toISOString();
  }
  window.contactTailleurPro=function(){const number=String(TAILLEURPRO_WHATSAPP||'').replace(/\D/g,'');if(!number){toast('Le numéro WhatsApp officiel de TailleurPro sera ajouté prochainement.');return;}const msg=encodeURIComponent('Bonjour TailleurPro, j’ai besoin d’aide concernant l’application.');window.location.href='https://wa.me/'+number+'?text='+msg;};
  const defaultDB={account:null,atelier:null,clients:[],orders:[],subscription:{plan:'free',status:'active',monthKey:'',monthlyOrders:0,startedAt:null,expiresAt:null},settings:{payments:{'Espèces':true,'Wave':true,'Orange Money':true,'Autre':true},notifications:{'Rappel de livraison':true,'Commande en retard':true,'Paiement restant':true},customMeasures:[],models:['Grand boubou classique','Ensemble moderne'],fabrics:['Bazin riche','Wax']}};
  function readDB(){
    try{return JSON.parse(localStorage.getItem(KEY)||'null')||structuredClone(defaultDB)}catch(e){return structuredClone(defaultDB)}
  }
  let db=readDB();
  db.clients=Array.isArray(db.clients)?db.clients:[]; db.orders=Array.isArray(db.orders)?db.orders:[];
  db.subscription=Object.assign(structuredClone(defaultDB.subscription),db.subscription||{});
  if(!db.subscription.status)db.subscription.status='active';
  db.settings=Object.assign(structuredClone(defaultDB.settings),db.settings||{});
  db.orders.forEach(o=>{if(!Array.isArray(o.payments)){o.payments=Number(o.advance||0)>0?[{amount:Number(o.advance),date:o.createdAt||new Date().toLocaleDateString('fr-FR'),method:'Espèces',note:'Avance initiale'}]:[]} o.advance=o.payments.reduce((s,p)=>s+Number(p.amount||0),0)});
  function save(){try{localStorage.setItem(KEY,JSON.stringify(db));scheduleCloudSync();return true}catch(e){toast('Impossible de sauvegarder les données dans ce navigateur.');return false}}
  function money(n){return new Intl.NumberFormat('fr-FR').format(Number(n)||0)+' F';}
  function monthKey(){const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0');}
  function ensureSubscription(){if(!db.subscription||typeof db.subscription!=='object')db.subscription=structuredClone(defaultDB.subscription);if(!db.subscription.status)db.subscription.status='active';if(db.subscription.plan!=='pro')db.subscription.plan='free';if(db.subscription.plan==='pro'&&db.subscription.expiresAt&&new Date(db.subscription.expiresAt).getTime()<=Date.now()){db.subscription.plan='free';db.subscription.status='expired';db.subscription.startedAt=null;db.subscription.expiresAt=null;save();toast('Votre abonnement Pro a expiré.');}const k=monthKey();if(db.subscription.monthKey!==k){db.subscription.monthKey=k;db.subscription.monthlyOrders=0;save();}return db.subscription;}
  function formatDateISO(v){if(!v)return '—';const d=new Date(v);return Number.isNaN(d.getTime())?'—':d.toLocaleDateString('fr-FR',{day:'2-digit',month:'2-digit',year:'numeric'});}
  function activateProPrototype(days){days=Number(days||30);if(!Number.isFinite(days)||days<1)days=30;const start=new Date(),end=new Date(start);end.setDate(end.getDate()+days);db.subscription.plan='pro';db.subscription.status='active';db.subscription.startedAt=start.toISOString();db.subscription.expiresAt=end.toISOString();save();renderSubscription();renderPlanCard();toast('Pro activé pour '+days+' jours.');}
  window.activateProPrototype=activateProPrototype;
  function isPro(){return ensureSubscription().plan==='pro';}
  function canAddClient(){return isPro()||db.clients.length<5;}
  function canAddOrder(){const sub=ensureSubscription();return isPro()||Number(sub.monthlyOrders||0)<10;}
  function freeUsageText(){const sub=ensureSubscription();return isPro()?'PRO · Illimité':db.clients.length+'/5 clients · '+Number(sub.monthlyOrders||0)+'/10 commandes ce mois-ci';}
  window.showUpgrade=function(){toast('L’activation Pro en ligne arrivera avec le système de paiement sécurisé.');};
  function renderPlanCard(){const el=document.getElementById('planCard');if(!el)return;const pro=isPro(),sub=ensureSubscription();el.innerHTML=pro?'<div class="status-line"><div><b>⭐ TailleurPro Pro</b><div class="small">Clients et commandes illimités.</div></div><span class="owner-badge">PRO</span></div>':'<div class="status-line"><div><b>🆓 TailleurPro Free</b><div class="small">'+db.clients.length+'/5 clients · '+Number(sub.monthlyOrders||0)+'/10 commandes ce mois-ci</div></div><button class="btn secondary" onclick="showUpgrade()">⭐ Passer à Pro</button></div>';if(!pro)el.innerHTML+='<div class="progress" style="margin-top:10px"><i style="width:'+Math.min(100,Math.round(db.clients.length/5*100))+'%"></i></div>';}
  function normalizePhone(v){const raw=String(v||'').trim();if(!raw)return '';if(!/[0-9]/.test(raw))return '';let d=raw.replace(/\D/g,'');if(!d)return '';if(d.startsWith('221'))d=d.slice(3);if(d.startsWith('0')&&d.length===10)d=d.slice(1);return d;}
  function isValidLoginEmail(v){const e=String(v||'').trim().toLowerCase();return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);}
  function inputs(section){return [...document.querySelectorAll('#'+section+' input, #'+section+' select, #'+section+' textarea')];}
  function toast(msg){let t=document.getElementById('toast');if(!t){t=document.createElement('div');t.id='toast';t.style='position:fixed;left:50%;bottom:85px;transform:translateX(-50%);background:#17201a;color:white;padding:12px 16px;border-radius:12px;z-index:99;box-shadow:0 8px 30px #0004;max-width:90%;text-align:center';document.body.appendChild(t)}t.textContent=msg;t.hidden=false;clearTimeout(t._x);t._x=setTimeout(()=>t.hidden=true,2600)}
  function esc(v){return String(v??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]))}
  function val(id){return document.getElementById(id)?.value||''}
  function todayISO(){return new Date().toISOString().slice(0,10)}
  function oldGo(id){
    screens.forEach(s=>s.classList.toggle('active',s.id===id));
    const auth=['welcome','signup','login','forgot','verify','setup'].includes(id); bottom.classList.toggle('hide',auth);
    document.querySelectorAll('.nav button').forEach(b=>{let active=b.dataset.go===id;if(['client','newclient','newmeasure'].includes(id))active=b.dataset.go==='clients';if(id==='neworder')active=b.dataset.go==='orders';if(['payments'].includes(id))active=b.dataset.go==='home';b.classList.toggle('active',active)});scrollTo(0,0)
  }
  const screens=[...document.querySelectorAll('.screen')]; const bottom=document.getElementById('bottom');
  window.go=function(id){oldGo(id);if(id==='clients')renderClients();if(id==='orders')renderOrders();if(id==='home')renderHome();if(id==='client')renderCurrentClient();if(id==='orderdetail')renderOrderDetail();if(id==='neworder')renderNewOrderForm();if(id==='newmeasure')renderMeasureForm();if(id==='profile')renderProfile();if(id==='measurementSettings')renderMeasurementSettings();if(id==='catalog')renderCatalog();if(id==='paymentSettings')renderPaymentSettings();if(id==='notifications')renderNotifications();if(id==='subscription')renderSubscription();if(id==='about')renderAbout();renderOwner();};
  function localToday(){const d=new Date();return new Date(d.getFullYear(),d.getMonth(),d.getDate());}
  function deliveryDateValue(v){if(!v)return null;const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(String(v));if(m)return new Date(Number(m[1]),Number(m[2])-1,Number(m[3]));const x=new Date(v);return Number.isNaN(x.getTime())?null:new Date(x.getFullYear(),x.getMonth(),x.getDate());}
  function renderDeliveryAlerts(){
    const box=document.getElementById('deliveryAlerts');
    if(!box)return;
    const enabled=db.settings.notifications['Rappel de livraison']!==false;
    const lateEnabled=db.settings.notifications['Commande en retard']!==false;
    const today=localToday();
    const tomorrow=new Date(today); tomorrow.setDate(tomorrow.getDate()+1);
    const rows=db.orders.map(o=>{const d=deliveryDateValue(o.delivery);return d&&o.status!=='Livré'?{o,d}:null}).filter(Boolean).sort((a,b)=>a.d-b.d);
    if(!enabled){box.innerHTML='<b>🔔 Rappels de livraison désactivés</b><div class="small">Activez « Rappel de livraison » dans Paramètres → Notifications.</div>';return;}
    const due=rows.filter(x=>x.d<=tomorrow);
    const overdue=due.filter(x=>x.d<today && lateEnabled);
    const todayRows=due.filter(x=>x.d.getTime()===today.getTime());
    const tomorrowRows=due.filter(x=>x.d.getTime()===tomorrow.getTime());
    if(!due.length){box.innerHTML='<b>🔔 Livraisons</b><div class="small">Aucune livraison prévue aujourd’hui ou demain.</div>';return;}
    const item=(x,label,icon)=>{const c=db.clients.find(c=>c.id===x.o.clientId);return `<div class="row delivery-alert-row" role="button" tabindex="0" onclick="window.openOrder('${esc(x.o.id)}')" onkeydown="if(event.key==='Enter'||event.key===' ')window.openOrder('${esc(x.o.id)}')" style="margin-top:8px"><div><b>${icon} ${label}</b><div class="small">${esc(c?.name||'Client')} · ${esc(x.o.type||'Commande')}</div></div><span class="tag">${esc(x.o.delivery)}</span></div>`;};
    let html='<b>🔔 Alertes de livraison</b>';
    overdue.slice(0,5).forEach(x=>html+=item(x,'En retard','⚠️'));
    todayRows.slice(0,5).forEach(x=>html+=item(x,"À livrer aujourd’hui",'📦'));
    tomorrowRows.slice(0,5).forEach(x=>html+=item(x,'À livrer demain','🗓️'));
    box.innerHTML=html;
  }
  function imageFileToDataUrl(file,maxSize=640){return new Promise((resolve,reject)=>{if(!file)return resolve('');if(!file.type||!file.type.startsWith('image/'))return reject(new Error('Fichier image invalide'));const reader=new FileReader();reader.onload=()=>{const img=new Image();img.onload=()=>{const scale=Math.min(1,maxSize/Math.max(img.width,img.height));const w=Math.max(1,Math.round(img.width*scale)),h=Math.max(1,Math.round(img.height*scale));const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;const ctx=canvas.getContext('2d');ctx.drawImage(img,0,0,w,h);resolve(canvas.toDataURL('image/jpeg',0.78));};img.onerror=()=>reject(new Error('Image illisible'));img.src=reader.result;};reader.onerror=()=>reject(reader.error||new Error('Lecture impossible'));reader.readAsDataURL(file);});}
  window.deleteCurrentClient=function(){const id=window.currentClient;const c=db.clients.find(x=>x.id===id);if(!c)return toast('Client introuvable.');const count=db.orders.filter(o=>o.clientId===id).length;const msg=count?`Supprimer ${c.name} et ses ${count} commande(s) ? Cette action est irréversible.`:`Supprimer ${c.name} ? Cette action est irréversible.`;if(!confirm(msg))return;db.orders=db.orders.filter(o=>o.clientId!==id);db.clients=db.clients.filter(x=>x.id!==id);window.currentClient=null;window.currentOrder=null;if(!save())return;renderClients();renderOrders();renderHome();go('clients');toast('Client supprimé.');};
  window.deleteCurrentOrder=function(){const id=window.currentOrder;const o=db.orders.find(x=>x.id===id);if(!o)return toast('Commande introuvable.');const c=db.clients.find(x=>x.id===o.clientId);if(!confirm(`Supprimer la commande de ${c?.name||'ce client'} ? Cette action est irréversible.`))return;db.orders=db.orders.filter(x=>x.id!==id);if(c)c.orders=Math.max(0,db.orders.filter(x=>x.clientId===c.id).length);window.currentOrder=null;if(!save())return;renderOrders();renderClients();renderHome();go('orders');toast('Commande supprimée.');};
  function renderHome(){const h=document.getElementById('home');if(!h)return;const active=db.orders.filter(o=>o.status!=='Livré').length;const today=localToday();const tomorrow=new Date(today);tomorrow.setDate(tomorrow.getDate()+1);const toDeliver=db.orders.filter(o=>o.status!=='Livré'&&(()=>{const d=deliveryDateValue(o.delivery);return d&&d<=tomorrow;})()).length;const due=db.orders.reduce((a,o)=>a+Math.max(0,Number(o.total||0)-Number(o.advance||0)),0);const m=h.querySelectorAll('.metric');if(m[0])m[0].textContent=active;if(m[1])m[1].textContent=toDeliver;if(m[2])m[2].textContent=money(due);if(m[3])m[3].textContent=db.clients.length;const g=h.querySelector('#homeGreeting');if(g)g.textContent='Bonjour'+(db.atelier?.name?', '+db.atelier.name:'')+' 👋';const lg=h.querySelector('#homeAtelierLogo');if(lg){const img=lg.querySelector('img');if(db.atelier?.logo){img.src=db.atelier.logo;lg.style.display='block';}else{img.removeAttribute('src');lg.style.display='none';}}const watch=h.querySelector('#homeWatch');if(watch){const overdue=db.orders.filter(o=>o.status!=='Livré'&&deliveryDateValue(o.delivery)&&deliveryDateValue(o.delivery)<today).length;const pending=db.orders.filter(o=>Math.max(0,Number(o.total||0)-Number(o.advance||0))>0).length;watch.innerHTML=overdue?'🔴 <b>'+overdue+'</b> commande(s) en retard.':toDeliver?'🟠 <b>'+toDeliver+'</b> commande(s) à livrer bientôt.':pending?'💰 <b>'+pending+'</b> commande(s) ont encore un solde.':'🟢 Rien d’urgent. Votre atelier est à jour.';}const recent=h.querySelector('#recentOrders');if(recent){const arr=[...db.orders].slice(-3).reverse();recent.innerHTML=arr.length?arr.map(o=>{const c=db.clients.find(x=>x.id===o.clientId);const rem=Math.max(0,Number(o.total||0)-Number(o.advance||0));return '<div class="row" onclick="window.openOrder(\''+esc(o.id)+'\')"><div><b>'+esc(c?.name||'Client')+'</b><div class="small">'+esc(o.type||'Commande')+' · '+esc(o.status||'En attente')+'</div></div><span class="money">'+money(rem)+'</span><span>›</span></div>'}).join(''):'<b>Aucune commande pour le moment.</b><div class="small">Vos nouvelles commandes apparaîtront ici.</div>';}renderDeliveryAlerts();renderPlanCard();}
  function renderClients(){const s=document.getElementById('clients'),list=s?.querySelector('.list');if(!list)return;const q=String(document.getElementById('clientSearch')?.value||'').trim().toLowerCase();const data=db.clients.filter(c=>{if(!q)return true;return [c.name,c.phone].some(v=>String(v||'').toLowerCase().includes(q));});list.innerHTML=data.length?data.map(c=>`<div class="row" role="button" tabindex="0" onclick="window.openClient('${esc(c.id)}')" onkeydown="if(event.key==='Enter'||event.key===' ')window.openClient('${esc(c.id)}')"><div><b>${esc(c.name)}</b><div class="small">${esc(c.phone||'Sans téléphone')} · ${c.orders||0} commande(s)</div></div><span>›</span></div>`).join(''):q?`<div class="card"><b>Aucun client trouvé.</b><div class="small">Essayez un autre nom ou numéro de téléphone.</div></div>`:`<div class="card"><b>Aucun client pour le moment.</b><div class="small">Ajoutez votre premier client.</div></div>`;}
  window.openClient=function(id){window.currentClient=id;go('client')};
  window.openOrder=function(id){window.currentOrder=id;go('orderdetail')};
  function renderCurrentClient(){const c=db.clients.find(x=>x.id===window.currentClient)||db.clients[0];if(!c)return;window.currentClient=c.id;const s=document.getElementById('client');if(!s)return;s.querySelector('h1').textContent=c.name;s.querySelector('.hero .small').textContent=(c.phone||'')+' · Mesures : '+(c.measureDate||'à renseigner');const pp=s.querySelector('#clientPhotoPreview');if(pp)pp.innerHTML=c.photo?`<img src="${c.photo}" alt="Photo de ${esc(c.name)}" style="width:88px;height:88px;object-fit:cover;border-radius:18px;border:1px solid rgba(0,0,0,.12)">`:'';const mg=s.querySelector('.measure-grid');const vals=c.measures||{};if(mg)mg.innerHTML=Object.entries(vals).filter(([k,v])=>v).slice(0,12).map(([k,v])=>`<div class="measure"><span>${esc(k)}</span><b>${esc(v)} cm</b></div>`).join('')||'<div class="small">Aucune mesure enregistrée.</div>';const lists=s.querySelectorAll('.list');const hist=lists[lists.length-1];if(hist)hist.innerHTML=db.orders.filter(o=>o.clientId===c.id).map(o=>`<div class="row" role="button" tabindex="0" onclick="window.openOrder('${esc(o.id)}')" onkeydown="if(event.key==='Enter'||event.key===' ')window.openOrder('${esc(o.id)}')"><div><b>${esc(o.type||'Commande')}${o.model?' — '+esc(o.model):''}</b><div class="small">${esc(o.fabric||'Tissu non renseigné')} · livraison ${esc(o.delivery||'—')}</div></div><span class="money">${money(o.total)}</span><span>›</span></div>`).join('')||'<div class="small">Aucune commande.</div>';}
  function renderOrders(filter){const s=document.getElementById('orders'),list=s?.querySelector('.list');if(!list)return;const f=filter||window.orderFilter||'Toutes';window.orderFilter=f;const q=String(document.getElementById('orderSearch')?.value||'').trim().toLowerCase();const data=db.orders.filter(o=>{const statusOk=f==='Toutes'||(f==='En cours'&&o.status!=='Livré')||(f==='Livré'&&o.status==='Livré');if(!statusOk)return false;const c=db.clients.find(x=>x.id===o.clientId);if(!q)return true;return [c?.name,o.type,o.model,o.fabric,o.color,o.status,o.delivery].some(v=>String(v||'').toLowerCase().includes(q));});list.innerHTML=data.length?data.map(o=>{const c=db.clients.find(x=>x.id===o.clientId);return `<div class="row" role="button" tabindex="0" onclick="window.openOrder('${esc(o.id)}')" onkeydown="if(event.key==='Enter'||event.key===' ')window.openOrder('${esc(o.id)}')"><div><b>${esc(c?.name||'Client')}</b><div class="small">${esc(o.type||'Commande')} · ${esc(o.fabric||'Tissu —')} · livraison ${esc(o.delivery||'—')}</div></div><span class="tag">${esc(o.status||'En attente')}</span><span>›</span></div>`}).join(''):q?`<div class="card"><b>Aucune commande trouvée.</b><div class="small">Essayez un autre client, modèle, tissu ou statut.</div></div>`:`<div class="card"><b>Aucune commande ${f==='Toutes'?'pour le moment':'dans cette catégorie'}.</b></div>`;}
  function renderNewOrderForm(){const s=document.getElementById('neworder');if(!s)return;const sel=s.querySelector('select');if(!sel)return;const current=window.currentClient;sel.innerHTML=db.clients.length?db.clients.map(c=>`<option value="${esc(c.id)}">${esc(c.name)}</option>`).join(''):'<option value="">Aucun client</option>';if(current&&db.clients.some(c=>c.id===current))sel.value=current;}
  function renderMeasureForm(){const s=document.getElementById('newmeasure');if(!s)return;const c=db.clients.find(x=>x.id===window.currentClient)||db.clients[0];if(!c)return;const names=['Poitrine','Taille','Hanche','Épaule','Cou','Manche','Tour de bras','Poignet','Longueur boubou','Longueur pantalon','Cuisse','Bas pantalon'];s.querySelectorAll('.measure input').forEach((x,i)=>x.value=c.measures?.[names[i]]||'');}
  window.editOrder=function(){const o=db.orders.find(x=>x.id===window.currentOrder);if(!o){toast('Commande introuvable.');return}const c=db.clients.find(x=>x.id===o.clientId),set=(id,v)=>{const e=document.getElementById(id);if(e)e.value=v??''};set('editType',o.type||'Ensemble');set('editModel',o.model||'');set('editFabric',o.fabric||'');set('editColor',o.color||'');set('editProvider',o.fabricProvider||'Le client');set('editFabricQty',o.fabricQty||'');set('editTotal',o.total||0);set('editAdvance',o.advance||0);set('editDelivery',o.delivery||'');set('editStatus',o.status||'En attente');set('editNotes',o.notes||'');const names=['Poitrine','Taille','Hanche','Épaule','Cou','Manche','Tour de bras','Poignet','Longueur boubou','Longueur pantalon','Cuisse','Bas pantalon'],m=o.measurements||c?.measures||{};names.forEach((n,i)=>set('editMeasure'+i,m[n]||''));const label=document.getElementById('editOrderClient');if(label)label.textContent=c?.name||'Client';go('editorder')};
  window.saveOrderEdit=function(){try{const o=db.orders.find(x=>x.id===window.currentOrder);if(!o){toast('Commande introuvable.');return}const total=Number(val('editTotal')||0);if(!Number.isFinite(total)||total<=0)return toast('Indiquez un prix total valide.');const paid=(o.payments||[]).reduce((sum,p)=>sum+Number(p.amount||0),0);if(paid>total)return toast('Le nouveau prix ne peut pas être inférieur aux paiements déjà enregistrés.');o.type=val('editType');o.model=val('editModel');o.fabric=val('editFabric');o.color=val('editColor');o.fabricProvider=val('editProvider');o.fabricQty=val('editFabricQty');o.total=total;o.delivery=val('editDelivery');o.status=val('editStatus');o.notes=val('editNotes');o.advance=paid;const names=['Poitrine','Taille','Hanche','Épaule','Cou','Manche','Tour de bras','Poignet','Longueur boubou','Longueur pantalon','Cuisse','Bas pantalon'];o.measurements={};names.forEach((n,i)=>{const v=val('editMeasure'+i).trim();if(v)o.measurements[n]=v});if(!save())return;renderOrderDetail();renderOrders();renderHome();renderCurrentClient();go('orderdetail');toast('Commande et mesures modifiées avec succès.')}catch(e){toast('Impossible d’enregistrer la modification.')}};

  function renderOrderDetail(){const o=db.orders.find(x=>x.id===window.currentOrder);if(!o)return;const c=db.clients.find(x=>x.id===o.clientId),s=document.getElementById('orderdetail');if(!s)return;const remaining=Math.max(0,Number(o.total||0)-Number(o.advance||0));s.querySelector('#orderDetailTitle').textContent=(o.type||'Commande')+(o.model?' — '+o.model:'');s.querySelector('#orderDetailSubtitle').textContent=(c?.name||'Client')+' · créée le '+(o.createdAt||'—');s.querySelector('#orderDetailStatus').innerHTML='<div class="small">Statut</div><span class="tag">'+esc(o.status||'En attente')+'</span>';s.querySelector('#orderDetailGrid').innerHTML=[['Client',c?.name||'Client'],['Téléphone',c?.phone||'—'],['Type de vêtement',o.type||'—'],['Modèle',o.model||'—'],['Tissu',o.fabric||'—'],['Tissu fourni par',o.fabricProvider||'—'],['Quantité de tissu',o.fabricQty||'—'],['Couleur / motif',o.color||'—'],['Date de commande',o.createdAt||'—'],['Date prévue',o.delivery||'—']].map(([k,v])=>'<div class="detail-item"><div class="small">'+esc(k)+'</div><b>'+esc(v)+'</b></div>').join('');s.querySelector('#orderPaymentGrid').innerHTML='<div class="card"><div class="small">Prix total</div><b>'+money(o.total)+'</b></div><div class="card"><div class="small">Total payé</div><b>'+money(o.advance)+'</b></div><div class="card"><div class="small">Reste à payer</div><b>'+money(remaining)+'</b></div>';const ph=s.querySelector('#orderPaymentHistory'),payments=Array.isArray(o.payments)?o.payments:[];ph.innerHTML=payments.length?payments.map((p,i)=>'<div class="row"><div><b>'+esc(p.method||'Paiement')+' · '+money(p.amount)+'</b><div class="small">'+esc(p.date||'—')+(p.note?' · '+esc(p.note):'')+'</div></div><span class="tag">'+(i===0?'Avance initiale':'Paiement')+'</span></div>').join(''):'<div class="card"><div class="small">Aucun paiement enregistré.</div></div>';s.querySelector('#orderDetailNotes').innerHTML=esc(o.notes||'Aucune note.');const vals=o.measurements||c?.measures||{};s.querySelector('#orderDetailMeasures').innerHTML=Object.entries(vals).filter(([k,v])=>v).map(([k,v])=>'<div class="measure"><span>'+esc(k)+'</span><b>'+esc(v)+' cm</b></div>').join('')||'<div class="small">Aucune mesure enregistrée pour cette commande.</div>';}
  window.addPayment=function(){const o=db.orders.find(x=>x.id===window.currentOrder);if(!o){toast('Commande introuvable.');return}const remaining=Math.max(0,Number(o.total||0)-Number(o.advance||0));if(remaining<=0){toast('Cette commande est déjà entièrement payée.');return}document.getElementById('paymentOrderSubtitle').textContent=(db.clients.find(c=>c.id===o.clientId)?.name||'Client')+' · reste à payer : '+money(remaining);document.getElementById('paymentRemainingCard').innerHTML='<div class="small">Reste à payer</div><div class="metric">'+money(remaining)+'</div>';document.getElementById('newPaymentAmount').value='';document.getElementById('newPaymentDate').value=todayISO();document.getElementById('newPaymentMethod').value='Espèces';document.getElementById('newPaymentNote').value='';go('addpayment')};
  window.saveNewPayment=function(){const o=db.orders.find(x=>x.id===window.currentOrder);if(!o){toast('Commande introuvable.');return}const amount=Number(val('newPaymentAmount')||0),remaining=Math.max(0,Number(o.total||0)-Number(o.advance||0));if(!Number.isFinite(amount)||amount<=0){toast('Entrez un montant valide.');return}if(amount>remaining){toast('Le paiement ne peut pas dépasser le reste à payer.');return}if(!Array.isArray(o.payments))o.payments=o.advance>0?[{amount:Number(o.advance),date:o.createdAt||new Date().toLocaleDateString('fr-FR'),method:'Espèces',note:'Avance initiale'}]:[];o.payments.push({id:makeUuid(),amount,date:val('newPaymentDate')||todayISO(),method:val('newPaymentMethod')||'Espèces',note:val('newPaymentNote').trim()});o.advance=o.payments.reduce((s,p)=>s+Number(p.amount||0),0);save();renderOrderDetail();renderOrders();renderHome();go('orderdetail');toast('Paiement enregistré avec succès.')};
  function bindSignup(){const s=document.getElementById('signup');if(!s||s.dataset.bound)return;s.dataset.bound=1;s.querySelector('button.btn.full').onclick=async()=>{const v=inputs('signup').map(x=>x.value);const email=String(v[2]||'').trim().toLowerCase();const password=String(v[3]||'');const confirmPassword=String(v[4]||'');if(!v[0]||!v[1]||!isValidLoginEmail(email)||password.length<6||password!==confirmPassword)return toast('Vérifiez le nom, l’e-mail et les mots de passe.');
    // Le téléphone appartient à l’atelier et sera renseigné après connexion.
    db.clients=[];db.orders=[];db.atelier=null;db.cloudAtelierId=null;db.subscription=structuredClone(defaultDB.subscription);
    db.account={name:(v[0]+' '+v[1]).trim(),phone:'',email,password};
    saveLocalOnly();
    const r=await cloudSignUp();if(!r.ok&&r.message!=='Mode local')return toast(r.message);go('setup');}};
  function bindLogin(){const s=document.getElementById('login');if(!s||s.dataset.bound)return;s.dataset.bound=1;s.querySelector('button.btn.full').onclick=async()=>{const v=inputs('login').map(x=>x.value);if(!v[0]||!v[1])return toast('Entrez vos identifiants.');if(supa){const r=await cloudLogin(v[0],v[1]);if(r.ok){sessionStorage.setItem('tailleurpro_session','1');go('home');toast(r.warning||'Connexion en ligne réussie.');return;}return toast('Connexion : '+r.message);}toast('Connexion Internet requise pour accéder à votre compte.')}}  function bindForgotBack(){const b=document.getElementById('forgotBack');if(!b||b.dataset.bound)return;if(b.dataset.bound)return;b.dataset.bound=1;b.onclick=()=>go(window.forgotOrigin||'login');}
function bindForgot(){const s=document.getElementById('forgot');if(!s||s.dataset.bound)return;s.dataset.bound=1;s.querySelector('button.btn.full').onclick=async()=>{const email=(s.querySelector('input')?.value||'').trim().toLowerCase();if(!isValidLoginEmail(email))return toast('Entrez une adresse e-mail valide.');if(!supa)return toast('Une connexion Internet est nécessaire pour réinitialiser le mot de passe.');const {error}=await supa.auth.resetPasswordForEmail(email,{redirectTo:'tailleurpro://auth/callback'});if(error)return toast('Impossible d’envoyer l’e-mail : '+error.message);s.querySelector('input').value='';toast('Un e-mail de réinitialisation vient d’être envoyé. Vérifiez votre boîte de réception.');};}
  function bindVerify(){const s=document.getElementById('verify');if(!s||s.dataset.bound)return;s.dataset.bound=1;s.querySelector('button.btn.full').onclick=async()=>{const inp=s.querySelectorAll('input'),newPass=inp[0]?.value||'',confirmPass=inp[1]?.value||'';if(!supa)return toast('Connexion Internet requise.');if(newPass.length<6)return toast('Le nouveau mot de passe doit contenir au moins 6 caractères.');if(newPass!==confirmPass)return toast('Les deux mots de passe doivent être identiques.');const {error}=await supa.auth.updateUser({password:newPass});if(error)return toast('Impossible de réinitialiser le mot de passe : '+error.message);inp.forEach(x=>x.value='');sessionStorage.removeItem('tailleurpro_session');go('login');toast('Mot de passe réinitialisé. Vous pouvez vous connecter.');};}
  function bindSetup(){const s=document.getElementById('setup');if(!s||s.dataset.bound)return;s.dataset.bound=1;s.querySelector('button.btn.full').onclick=async()=>{const v=inputs('setup').map(x=>x.value);if(!v[0])return toast('Indiquez le nom de l’atelier.');db.atelier={name:v[0],phone:v[1],location:v[2],specialization:v[3],types:v[4]};save();sessionStorage.setItem('tailleurpro_session','1');if(supa&&cloudReady){await cloudEnsureAtelier();await cloudSync();}go('home');toast(cloudReady?'Atelier connecté à Supabase.':'Atelier configuré.')}}
  function makeUuid(){try{return crypto.randomUUID()}catch(e){return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,c=>{const r=Math.random()*16|0,v=c==='x'?r:(r&3|8);return v.toString(16)})}}
  function isUuid(v){return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(v||''))}

  function bindNewClient(){const s=document.getElementById('newclient');if(!s||s.dataset.bound)return;s.dataset.bound=1;s.querySelector('button.btn.full').onclick=async()=>{if(!canAddClient())return toast('Limite Free atteinte : 5 clients. Passez à Pro pour continuer.');const els=inputs('newclient'),v=els.map(x=>x.value);if(!v[0])return toast('Le nom du client est obligatoire.');const file=s.querySelector('input[type="file"]')?.files?.[0];let photo='';if(file){try{photo=await imageFileToDataUrl(file)}catch(e){return toast('Impossible d’enregistrer cette photo.')}}const c={id:makeUuid(),name:v[0].trim(),phone:v[1].trim(),sex:v[2],photo,note:v[4]||'',orders:0,measures:{}};db.clients.push(c);window.currentClient=c.id;if(!save()){db.clients.pop();return}go('newmeasure');toast('Client enregistré.');}}
  function bindNewMeasure(){const s=document.getElementById('newmeasure');if(!s||s.dataset.bound)return;s.dataset.bound=1;s.querySelector('button.btn.full').onclick=()=>{const c=db.clients.find(x=>x.id===window.currentClient)||db.clients.at(-1);if(!c)return;const names=['Poitrine','Taille','Hanche','Épaule','Cou','Manche','Tour de bras','Poignet','Longueur boubou','Longueur pantalon','Cuisse','Bas pantalon'];c.measures={};s.querySelectorAll('.measure input').forEach((x,i)=>{const v=x.value.trim();if(v)c.measures[names[i]]=v});c.measureDate=new Date().toLocaleDateString('fr-FR');save();go('client');toast('Mesures enregistrées.')}}
  function bindNewOrder(){const s=document.getElementById('neworder');if(!s||s.dataset.bound)return;s.dataset.bound=1;s.querySelector('button.btn.full').onclick=()=>{if(!canAddOrder())return toast('Limite Free atteinte : 10 commandes ce mois-ci. Passez à Pro pour continuer.');const a=inputs('neworder'),cId=a[0]?.value,c=db.clients.find(x=>x.id===cId);if(!c)return toast('Sélectionnez un client.');const type=a[1]?.value||'',model=a[2]?.value||'',fabric=a[4]?.value||'',color=a[5]?.value||'',provider=a[6]?.value||'',qty=a[7]?.value||'',total=Number(a[9]?.value||0),advance=Number(a[10]?.value||0);if(!type)return toast('Choisissez le type de vêtement.');if(total<=0)return toast('Indiquez un prix total valide.');if(advance<0||advance>total)return toast('L’avance ne peut pas dépasser le prix total.');const o={id:makeUuid(),clientId:c.id,type,model,fabric,color,fabricProvider:provider,fabricQty:qty,total,advance,delivery:a[11]?.value||'',status:a[12]?.value||'En attente',notes:a[13]?.value||'',measurements:{...(c.measures||{})},payments:advance>0?[{id:makeUuid(),amount:advance,date:new Date().toLocaleDateString('fr-FR'),method:'Espèces',note:'Avance initiale'}]:[],createdAt:new Date().toLocaleDateString('fr-FR'),createdMonthKey:monthKey()};db.orders.push(o);c.orders=(c.orders||0)+1;if(!isPro())db.subscription.monthlyOrders=Number(db.subscription.monthlyOrders||0)+1;save();window.currentOrder=o.id;go('orderdetail');toast('Commande créée.')}}
  function renderProfile(){const s=document.getElementById('profile');if(!s)return;const a=s.querySelectorAll('input');if(a[0])a[0].value=db.account?.name||'';if(a[1])a[1].value=db.atelier?.name||'';if(a[2])a[2].value=db.atelier?.phone||'';if(a[3])a[3].value=db.atelier?.location||'';const pv=document.getElementById('atelierLogoPreview');if(pv)pv.innerHTML=db.atelier?.logo?'<img src="'+db.atelier.logo+'" alt="Logo atelier" style="width:96px;height:96px;object-fit:contain;border-radius:16px;border:1px solid #ddd;background:#fff;padding:6px">':'Aucun logo enregistré.'}
  function bindProfile(){const s=document.getElementById('profile');if(!s||s.dataset.bound)return;s.dataset.bound=1;const fileInput=document.getElementById('atelierLogoInput');fileInput?.addEventListener('change',async()=>{const f=fileInput.files?.[0];if(!f)return;try{db.atelier=db.atelier||{};db.atelier.logo=await imageFileToDataUrl(f,320);renderProfile();toast('Logo chargé. Appuyez sur Enregistrer.');}catch(e){toast('Impossible de lire ce logo.');}});s.querySelector('button.btn.full').onclick=()=>{const a=s.querySelectorAll('input');db.account=db.account||{};db.account.name=a[0]?.value.trim()||db.account.name||'';db.atelier=db.atelier||{};db.atelier.name=a[1]?.value.trim()||'';db.atelier.phone=a[2]?.value.trim()||'';db.atelier.location=a[3]?.value.trim()||'';save();renderHome();go('settings');toast('Profil enregistré.')}}
  function renderMeasurementSettings(){const s=document.getElementById('measurementSettings');if(!s)return;const list=s.querySelector('.list');const base=['Poitrine','Taille','Longueur boubou'];list.innerHTML=[...base,...(db.settings.customMeasures||[])].map(n=>`<div class="row"><span>${esc(n)}</span><button class="btn secondary measure-toggle">Activée</button></div>`).join('');s.querySelector('button.btn.full').onclick=()=>{const n=prompt('Nom de la nouvelle mesure :');if(n&&n.trim()){db.settings.customMeasures.push(n.trim());save();renderMeasurementSettings();toast('Mesure ajoutée.')}}}
  function renderCatalog(){const s=document.getElementById('catalog');if(!s)return;const lists=s.querySelectorAll('.list');if(lists[0])lists[0].innerHTML=db.settings.models.map(x=>`<div class="row"><span>${esc(x)}</span><span class="tag">Modèle</span></div>`).join('');if(lists[1])lists[1].innerHTML=db.settings.fabrics.map(x=>`<div class="row"><span>${esc(x)}</span><span class="tag">Tissu</span></div>`).join('');const btns=s.querySelectorAll('.section-title .btn');btns.forEach((b,i)=>b.onclick=()=>{const n=prompt(i===0?'Nom du modèle :':'Nom du tissu :');if(n&&n.trim()){(i===0?db.settings.models:db.settings.fabrics).push(n.trim());save();renderCatalog();toast('Élément ajouté.')}})}
  function renderPaymentSettings(){const s=document.getElementById('paymentSettings');if(!s)return;s.querySelectorAll('.row').forEach(r=>{const name=r.querySelector('span')?.textContent.trim();const b=r.querySelector('button');if(!name||!b)return;b.textContent=db.settings.payments[name]?'Activé':'Désactivé';b.onclick=()=>{db.settings.payments[name]=!db.settings.payments[name];save();renderPaymentSettings()}})}
  function renderNotifications(){const s=document.getElementById('notifications');if(!s)return;s.querySelectorAll('.row').forEach(r=>{const name=r.querySelector('span')?.textContent.trim(),b=r.querySelector('button');if(!name||!b)return;b.textContent=db.settings.notifications[name]?'Activé':'Désactivé';b.onclick=()=>{db.settings.notifications[name]=!db.settings.notifications[name];save();renderNotifications();renderDeliveryAlerts();toast(name+' : '+(db.settings.notifications[name]?'activé':'désactivé'))}})}
  function bindSearch(){const c=document.getElementById('clientSearch');if(c&&!c.dataset.bound){c.dataset.bound=1;c.addEventListener('input',()=>renderClients())}const o=document.getElementById('orderSearch');if(o&&!o.dataset.bound){o.dataset.bound=1;o.addEventListener('input',()=>renderOrders())}}
  function bindOrderFilters(){const s=document.getElementById('orders');if(!s||s.dataset.filters)return;s.dataset.filters=1;s.querySelectorAll('button').forEach(b=>{const t=b.textContent.trim();if(['Toutes','En cours'].includes(t))b.onclick=()=>renderOrders(t)})}
  function bindSecurity(){const s=document.getElementById('security');if(!s||s.dataset.bound)return;s.dataset.bound=1;const reset=s.querySelector('button.btn.full');const sessions=s.querySelector('button.btn.secondary.full');if(reset)reset.onclick=()=>{window.forgotOrigin='security';const f=document.getElementById('forgot');const inp=f?.querySelector('input');if(inp&&db.account?.email)inp.value=db.account.email;go('forgot');};if(sessions)sessions.onclick=()=>toast('Prototype : session active sur cet appareil. La gestion multi-appareils viendra avec le serveur.')}
  function renderSubscription(){const s=document.getElementById('subscription');if(!s)return;const el=s.querySelector('#subscriptionDetail');if(!el)return;const sub=ensureSubscription();if(isPro()){el.innerHTML='<div class="status-line"><div><b>⭐ Vous êtes en Pro</b><div class="small">Clients et commandes illimités.</div><div class="small" style="margin-top:5px">Valable jusqu’au '+formatDateISO(sub.expiresAt)+'.</div></div><span class="owner-badge">PRO</span></div>';}else{el.innerHTML='<div><b>🆓 Vous êtes en Free</b><div class="small" style="margin-top:5px">'+db.clients.length+'/5 clients · '+Number(sub.monthlyOrders||0)+'/10 commandes ce mois-ci</div><div class="small" style="margin-top:5px">Fonctionnalités essentielles disponibles gratuitement.</div></div>';}}
  function renderAbout(){const s=document.getElementById('about');if(!s)return;}
  function bindLogout(){
    const s=document.getElementById('settings');if(!s)return;
    const b=[...s.querySelectorAll('button')].find(x=>x.textContent.includes('Se déconnecter'));
    if(!b||b.dataset.safeLogout)return;b.dataset.safeLogout='1';
    b.onclick=async()=>{
      b.disabled=true;
      try{
        clearTimeout(cloudSyncTimer);
        const emailKey=String(db.account?.email||'').trim().toLowerCase();
        if(emailKey){try{localStorage.setItem('tailleurpro_backup_'+btoa(unescape(encodeURIComponent(emailKey))),JSON.stringify(db));}catch(e){}}
        let syncResult={ok:true};
        if(supa&&cloudReady){
          if(cloudSyncing)await waitForCloudSync();
          syncResult=await cloudSync();
        }
        // Même si le serveur est indisponible, la sauvegarde liée à l'e-mail reste conservée.
        sessionStorage.removeItem('tailleurpro_session');
        if(supa){try{await supa.auth.signOut();}catch(e){}}
        db=structuredClone(defaultDB);saveLocalOnly();cloudReady=false;go('welcome');
        toast(syncResult.ok?'Déconnecté.':'Déconnecté. Synchronisation non confirmée : les données locales restent sauvegardées pour ce compte.');
      }finally{b.disabled=false;}
    };
  }
  function renderOwner(){const c=document.getElementById('ownerClients'),o=document.getElementById('ownerOrders'),r=document.getElementById('ownerRevenue'),d=document.getElementById('ownerDue');if(c)c.textContent=db.clients.length;if(o)o.textContent=db.orders.length;const revenue=db.orders.reduce((sum,x)=>sum+Number(x.total||0),0),due=db.orders.reduce((sum,x)=>sum+Math.max(0,Number(x.total||0)-Number(x.advance||0)),0);if(r)r.textContent=money(revenue);if(d)d.textContent=money(due)}
  window.openOwnerSpace=function(){const code=prompt('Accès propriétaire — entrez votre code :');if(code==='TP-OWNER-2026'){renderOwner();go('owner');}else if(code!==null){toast('Code propriétaire incorrect.')}};
  window.ownerExportSummary=function(){renderOwner();const revenue=db.orders.reduce((sum,x)=>sum+Number(x.total||0),0),due=db.orders.reduce((sum,x)=>sum+Math.max(0,Number(x.total||0)-Number(x.advance||0)),0);const msg=`TAILLEURPRO — RÉSUMÉ\n\nClients : ${db.clients.length}\nCommandes : ${db.orders.length}\nMontant total des commandes : ${money(revenue)}\nReste à encaisser : ${money(due)}\nMode : hors ligne / prototype`;navigator.clipboard?.writeText(msg).then(()=>toast('Résumé copié.')).catch(()=>alert(msg))};
  function bindNav(){document.querySelectorAll('.nav button').forEach(b=>b.onclick=()=>go(b.dataset.go))}
  function boot(){ensureSubscription();if(supa){supa.auth.getSession().then(({data})=>{if(data.session){cloudReady=true;cloudPull();}}).catch(()=>{});}enhancePasswords();bindNav();bindSignup();bindLogin();bindForgotBack();bindForgot();bindVerify();bindSetup();bindNewClient();bindNewMeasure();bindNewOrder();bindProfile();bindSearch();bindOrderFilters();bindSecurity();bindLogout();renderHome();renderClients();renderOrders();renderNewOrderForm();renderMeasureForm();renderProfile();renderMeasurementSettings();renderCatalog();renderPaymentSettings();renderNotifications();renderSubscription();renderPlanCard();}
  function enhancePasswords(){document.querySelectorAll('input[type="password"]').forEach(input=>{if(input.parentElement?.classList.contains('password-wrap'))return;const wrap=document.createElement('div');wrap.className='password-wrap';input.parentNode.insertBefore(wrap,input);wrap.appendChild(input);const b=document.createElement('button');b.type='button';b.className='password-toggle';b.setAttribute('aria-label','Afficher le mot de passe');b.textContent='👁️';b.onclick=()=>{const show=input.type==='password';input.type=show?'text':'password';b.textContent=show?'🙈':'👁️';b.setAttribute('aria-label',show?'Masquer le mot de passe':'Afficher le mot de passe')};wrap.appendChild(b)})}
  boot();
})();

function initPullToRefresh(){
  const indicator=document.getElementById('pullRefreshIndicator');
  const label=document.getElementById('pullRefreshText');
  if(!indicator||!label||window.__tpPullReady)return;
  window.__tpPullReady=true;
  let startY=0,pulling=false,busy=false,armed=false;
  const threshold=72;
  const scrollTop=()=>Math.max(0,Number(document.scrollingElement?.scrollTop||window.pageYOffset||0));
  const reset=()=>{
    indicator.classList.remove('refreshing','show');
    label.classList.remove('show');
    indicator.style.transform='';
    indicator.style.opacity='';
  };
  document.addEventListener('touchstart',e=>{
    if(busy||e.touches.length!==1)return;
    const active=document.querySelector('.screen.active');
    if(!active||active.id!=='home'||scrollTop()>2)return;
    startY=e.touches[0].clientY;
    pulling=true;
    armed=false;
  },{passive:true});
  document.addEventListener('touchmove',e=>{
    if(!pulling||busy||e.touches.length!==1)return;
    const dy=e.touches[0].clientY-startY;
    if(dy<=0){pulling=false;reset();return;}
    const progress=Math.min(dy/threshold,1);
    armed=dy>=threshold;
    indicator.classList.add('show');
    indicator.style.transform='translateY('+Math.max(-70,-70+70*progress)+'px)';
    indicator.style.opacity=String(.35+.65*progress);
  },{passive:true});
  document.addEventListener('touchend',async()=>{
    if(!pulling||busy)return;
    pulling=false;
    if(!armed){reset();return;}
    busy=true;
    indicator.classList.add('show','refreshing');
    label.classList.add('show');
    indicator.style.transform='translateY(0)';
    indicator.style.opacity='1';
    try{
      if(!supa||!cloudReady)throw new Error('Synchronisation indisponible.');
      const sync=await cloudSync();
      if(!sync.ok)throw new Error(sync.message||'Synchronisation impossible.');
      const pulled=await cloudPull();
      if(!pulled.ok)throw new Error(pulled.message||'Actualisation impossible.');
      toast('Données actualisées.');
    }catch(e){toast(e?.message||'Actualisation impossible.');}
    finally{
      busy=false;
      setTimeout(reset,250);
    }
  },{passive:true});
  document.addEventListener('touchcancel',()=>{pulling=false;reset();},{passive:true});
}

