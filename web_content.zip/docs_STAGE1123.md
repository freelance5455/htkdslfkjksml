# CPLS V2 — Stage 1123

## Futures live samples → stable candles

- Continued from Stage 1122.
- Keeps LBank Contract REST as the production Futures market/order-book source.
- Converts the live price samples already collected by the native feed into OHLC candles for the selected timeframe.
- Persists recent Futures price samples in local browser storage so navigating away from the Futures page does not immediately erase the chart history.
- Merges native Android samples with locally persisted samples instead of replacing one with the other.
- De-duplicates near-identical samples and caps browser-side history at 12,000 samples to keep mobile storage reasonable.
- 1m/5m/15m candles become progressively more useful as the app remains connected; longer timeframes still depend on the amount of retained sample history.
- No undocumented Futures WebSocket subscription message is invented or sent.

## Important

This package is a source ZIP, not an APK. The live network behavior must be validated on the Android phone because this build environment cannot certify LBank WebSocket/REST reachability from the user's network.
