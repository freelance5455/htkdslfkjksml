## Guia simples para configurar o banco pelo celular
Abra `GUIA_CONFIGURAR_BANCO.html` no navegador para ver o passo a passo visual.

# Assistente Virtual — MVP Android

## O que já funciona nesta primeira versão
- Interface Android com visão geral, financeiro, clientes, assistente e relatórios.
- Cadastro local de entradas, saídas e clientes.
- Cálculo de entradas, saídas e saldo com base nos lançamentos registrados.
- Ações preparadas pelo assistente precisam de confirmação antes de serem executadas.
- Modo demonstração salva os dados no aparelho via AsyncStorage.

## Limitações importantes
- Sem Supabase configurado, o login é apenas uma demonstração local, não é autenticação segura nem multiempresa real.
- Com Supabase configurado, o cadastro/login e os dados na nuvem usam o backend incluído; execute `supabase_schema.sql` no SQL Editor do Supabase.
- A interpretação do assistente ainda é demonstrativa, baseada em regras simples. Não é uma integração real com ChatGPT.
- Assinaturas, pagamentos, envio de mensagens, sincronização de agenda, relatórios fiscais e conexão bancária não estão implementados.
- Antes de publicar, revise as políticas de segurança, testes, termos de uso, privacidade e recuperação de senha.

## Como testar sem pagar
1. Instale Node.js em um computador e instale o aplicativo Expo Go no Android.
2. Extraia este ZIP e abra a pasta no terminal.
3. Rode `npm install` e depois `npx expo start`.
4. Escaneie o QR code pelo Expo Go. O computador e o celular devem estar na mesma rede.

## Como habilitar contas reais e sincronização
1. Crie um projeto no Supabase.
2. Abra o SQL Editor e execute todo o arquivo `supabase_schema.sql`.
3. Copie a Project URL e a chave publicável/anon do projeto.
4. Crie um arquivo `.env` a partir de `.env.example` e preencha `EXPO_PUBLIC_SUPABASE_URL` e `EXPO_PUBLIC_SUPABASE_ANON_KEY`.
5. Reinicie o Expo. Não coloque uma chave `service_role` no aplicativo.

## Próximas etapas recomendadas
1. Testar login, criação de empresa, lançamentos e clientes.
2. Adicionar edição, categorias, filtros por período e exportação.
3. Implementar uma Edge Function segura para chamar um modelo de IA sem expor a chave de API no celular.
4. Implementar membros/equipe, permissões administrativas, auditoria e exclusão/exportação de dados.
5. Adicionar planos e assinaturas somente depois de validar com usuários reais.

## Segurança
O esquema SQL usa Row Level Security (RLS) para limitar acesso aos dados das empresas. Antes de produção, faça revisão técnica das políticas e testes com duas contas diferentes para confirmar que uma empresa nunca consegue acessar dados de outra.

## Gerar APK pela nuvem usando apenas o Android
O arquivo `eas.json` já inclui o perfil `preview` para gerar um APK instalável.
Em um terminal na pasta do projeto, execute:

```bash
npm install
npm install --global eas-cli
 eas login
 eas build:configure
 eas build --platform android --profile preview
```

Se `eas build:configure` alterar arquivos, mantenha o perfil `preview` com `android.buildType` igual a `apk`. Siga as instruções do terminal e aguarde o build na nuvem. Ao terminar, abra o link do artefato no navegador do celular e baixe o `.apk`.
