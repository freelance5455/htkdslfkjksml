import React, { useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator, Alert, KeyboardAvoidingView, Platform, SafeAreaView,
  ScrollView, StatusBar, StyleSheet, Text, TextInput, TouchableOpacity, View
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL || '';
const SUPABASE_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || '';
const hasSupabase = SUPABASE_URL.startsWith('https://') && SUPABASE_KEY.length > 20;
const supabase = hasSupabase ? createClient(SUPABASE_URL, SUPABASE_KEY) : null;
const money = n => Number(n || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const today = () => new Date().toISOString().slice(0,10);

export default function App() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [business, setBusiness] = useState(null);
  const [page, setPage] = useState('Início');
  const [loading, setLoading] = useState(true);
  const [offlineMode, setOfflineMode] = useState(!hasSupabase);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [businessType, setBusinessType] = useState('Comércio');
  const [entries, setEntries] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [entryTitle, setEntryTitle] = useState('');
  const [entryAmount, setEntryAmount] = useState('');
  const [entryKind, setEntryKind] = useState('entrada');
  const [customerName, setCustomerName] = useState('');
  const [customerContact, setCustomerContact] = useState('');
  const [ask, setAsk] = useState('');
  const [proposal, setProposal] = useState(null);
  const [assistantLog, setAssistantLog] = useState('Olá! Posso resumir suas finanças e preparar ações para você confirmar.');

  useEffect(() => {
    (async () => {
      try {
        if (supabase) {
          const { data } = await supabase.auth.getSession();
          if (data?.session) { setSession(data.session); await loadCloud(data.session); }
        } else {
          const raw = await AsyncStorage.getItem('gestaoia_demo');
          if (raw) {
            const d = JSON.parse(raw);
            setProfile(d.profile || null); setBusiness(d.business || null);
            setEntries(d.entries || []); setCustomers(d.customers || []);
            if (d.profile) setOfflineMode(true);
          }
        }
      } catch (e) { console.log(e); }
      setLoading(false);
    })();
  }, []);

  useEffect(() => {
    if (!supabase && profile) {
      AsyncStorage.setItem('gestaoia_demo', JSON.stringify({ profile, business, entries, customers })).catch(()=>{});
    }
  }, [profile, business, entries, customers]);

  async function loadCloud(s = session) {
    if (!supabase || !s?.user) return;
    const { data: memberships } = await supabase.from('business_members').select('business_id, businesses(id,name,business_type)').eq('user_id', s.user.id);
    const b = memberships?.[0]?.businesses || null;
    setProfile({ email: s.user.email, id: s.user.id });
    setBusiness(b);
    if (b?.id) {
      const [{data:e},{data:c}] = await Promise.all([
        supabase.from('finance_entries').select('*').eq('business_id', b.id).order('created_at',{ascending:false}),
        supabase.from('customers').select('*').eq('business_id', b.id).order('created_at',{ascending:false})
      ]);
      setEntries(e || []); setCustomers(c || []);
    }
  }

  async function signIn() {
    if (!email.trim() || password.length < 6) return Alert.alert('Confira os dados', 'Informe um e-mail e uma senha com pelo menos 6 caracteres.');
    if (!supabase) {
      const p = { email: email.trim().toLowerCase(), id: 'demo-local' };
      setProfile(p); setBusiness({ id:'demo-business', name: businessName.trim() || 'Minha empresa', business_type: businessType });
      setOfflineMode(true);
      return;
    }
    setLoading(true);
    const { data, error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    if (error) Alert.alert('Não foi possível entrar', error.message);
    else { setSession(data.session); await loadCloud(data.session); }
    setLoading(false);
  }

  async function signUp() {
    if (!email.trim() || password.length < 6 || !businessName.trim()) return Alert.alert('Complete o cadastro', 'Informe e-mail, senha de pelo menos 6 caracteres e nome da empresa.');
    if (!supabase) {
      setProfile({ email: email.trim().toLowerCase(), id: 'demo-local' });
      setBusiness({ id:'demo-business', name:businessName.trim(), business_type:businessType });
      setOfflineMode(true);
      Alert.alert('Modo demonstração', 'Seus dados ficam somente neste aparelho. Configure o Supabase para habilitar contas reais.');
      return;
    }
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({ email: email.trim(), password });
    if (error) { Alert.alert('Erro no cadastro', error.message); setLoading(false); return; }
    if (data.user) {
      const { data: b, error: be } = await supabase.from('businesses').insert({ name:businessName.trim(), business_type:businessType, owner_id:data.user.id }).select().single();
      if (!be && b) await supabase.from('business_members').insert({ business_id:b.id, user_id:data.user.id, role:'owner' });
      if (data.session) { setSession(data.session); await loadCloud(data.session); }
      else Alert.alert('Confirme seu e-mail', 'Confirme o endereço de e-mail e depois entre no aplicativo.');
    }
    setLoading(false);
  }

  async function createBusiness() {
    if (!businessName.trim()) return Alert.alert('Informe o nome', 'Digite o nome da sua empresa.');
    if (!supabase || !session?.user) {
      setBusiness({ id:'demo-business', name:businessName.trim(), business_type:businessType });
      return;
    }
    setLoading(true);
    const { data: b, error } = await supabase.from('businesses').insert({
      name: businessName.trim(), business_type: businessType, owner_id: session.user.id
    }).select().single();
    if (error) { Alert.alert('Não foi possível criar a empresa', error.message); setLoading(false); return; }
    const { error: me } = await supabase.from('business_members').insert({
      business_id: b.id, user_id: session.user.id, role: 'owner'
    });
    if (me) { Alert.alert('Erro ao configurar acesso', me.message); setLoading(false); return; }
    setBusiness(b);
    setEntries([]); setCustomers([]);
    setLoading(false);
  }

  async function logout() {
    if (supabase && session) await supabase.auth.signOut();
    setSession(null); setProfile(null); setBusiness(null); setEntries([]); setCustomers([]);
    setPage('Início');
    if (!supabase) await AsyncStorage.removeItem('gestaoia_demo');
  }

  async function saveEntry(entry) {
    if (supabase && business?.id !== 'demo-business') {
      const { data, error } = await supabase.from('finance_entries').insert({ ...entry, business_id:business.id, created_by:session.user.id }).select().single();
      if (error) return Alert.alert('Erro ao salvar', error.message);
      setEntries(old => [data, ...old]);
    } else setEntries(old => [{...entry, id:String(Date.now()), created_at:new Date().toISOString()}, ...old]);
    setEntryTitle(''); setEntryAmount('');
  }

  async function saveCustomer(c) {
    if (supabase && business?.id !== 'demo-business') {
      const { data, error } = await supabase.from('customers').insert({ ...c, business_id:business.id, created_by:session.user.id }).select().single();
      if (error) return Alert.alert('Erro ao salvar', error.message);
      setCustomers(old => [data, ...old]);
    } else setCustomers(old => [{...c, id:String(Date.now()), created_at:new Date().toISOString()}, ...old]);
    setCustomerName(''); setCustomerContact('');
  }

  async function deleteEntry(item) {
    Alert.alert('Excluir lançamento?', `Deseja excluir "${item.title}"?`, [
      {text:'Cancelar',style:'cancel'},
      {text:'Excluir',style:'destructive',onPress:async()=>{
        if (supabase && business?.id !== 'demo-business') {
          const {error}=await supabase.from('finance_entries').delete().eq('id',item.id).eq('business_id',business.id);
          if(error) return Alert.alert('Erro',error.message);
        }
        setEntries(old=>old.filter(x=>x.id!==item.id));
      }}
    ]);
  }

  const income = useMemo(()=>entries.filter(e=>e.kind==='entrada').reduce((s,e)=>s+Number(e.amount||0),0),[entries]);
  const expenses = useMemo(()=>entries.filter(e=>e.kind==='saída').reduce((s,e)=>s+Number(e.amount||0),0),[entries]);
  const balance = income-expenses;

  function prepareAction() {
    const q=ask.trim();
    if(!q) return;
    const lower=q.toLowerCase();
    if ((lower.includes('registr') || lower.includes('adicionar') || lower.includes('lançar')) && (lower.includes('despesa') || lower.includes('entrada') || lower.includes('receita'))) {
      const isOut=lower.includes('despesa');
      const match=q.match(/(?:r\$?\s*)?(\d+(?:[.,]\d{1,2})?)/i);
      const amount=match ? Number(match[1].replace('.','').replace(',','.')) : 0;
      const title=q.replace(/registr(ar|e)|adicion(ar|e)|lançar/ig,'').trim();
      if(amount>0) setProposal({type:'finance',entry:{title:title || (isOut?'Despesa via assistente':'Entrada via assistente'),amount,kind:isOut?'saída':'entrada',date:today(),category:'Assistente IA'},summary:`Registrar ${isOut?'uma saída':'uma entrada'} de ${money(amount)}?`});
      else setAssistantLog('Entendi que você quer registrar um lançamento, mas não encontrei o valor. Exemplo: “registrar despesa de 35,90 de material”.');
    } else if (lower.includes('cliente') && (lower.includes('adicion') || lower.includes('cadastrar') || lower.includes('criar'))) {
      setAssistantLog('Para cadastrar um cliente, abra Clientes e use o formulário. Posso preparar isso automaticamente em uma próxima versão.');
    } else if (lower.includes('lucro') || lower.includes('saldo') || lower.includes('finance') || lower.includes('gasto') || lower.includes('despesa')) {
      setAssistantLog(`Resumo dos lançamentos cadastrados: entradas ${money(income)}, saídas ${money(expenses)} e saldo calculado ${money(balance)}. Este resumo considera somente os dados que você registrou no app.`);
    } else {
      setAssistantLog('Posso resumir as finanças registradas ou preparar um lançamento. Para testar uma ação, escreva “registrar despesa de 35,90 de material” e revise antes de confirmar. A interpretação por linguagem natural ainda é demonstrativa.');
    }
    setAsk('');
  }

  async function confirmProposal() {
    if(!proposal) return;
    if(proposal.type==='finance') await saveEntry(proposal.entry);
    setAssistantLog('Ação concluída. Confira o lançamento na área Financeiro.');
    setProposal(null);
    setPage('Financeiro');
  }

  if (loading) return <SafeAreaView style={styles.center}><ActivityIndicator size="large" color="#1769ff"/><Text style={styles.muted}>Carregando Assistente Virtual…</Text></SafeAreaView>;

  if (!profile) return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content"/>
      <KeyboardAvoidingView behavior={Platform.OS==='ios'?'padding':undefined} style={{flex:1}}>
        <ScrollView contentContainerStyle={styles.loginWrap}>
          <View style={styles.brandIcon}><Text style={{fontSize:28}}>✦</Text></View>
          <Text style={styles.brand}>Assistente Virtual</Text>
          <Text style={styles.subtitle}>Sua empresa organizada. Suas decisões mais claras.</Text>
          {!hasSupabase && <View style={styles.notice}><Text style={styles.noticeText}>Modo demonstração local: login e dados ficam neste aparelho. Configure o Supabase para habilitar contas reais e sincronização.</Text></View>}
          <Text style={styles.label}>E-mail</Text>
          <TextInput value={email} onChangeText={setEmail} placeholder="voce@empresa.com" autoCapitalize="none" keyboardType="email-address" style={styles.input}/>
          <Text style={styles.label}>Senha</Text>
          <TextInput value={password} onChangeText={setPassword} placeholder="Mínimo de 6 caracteres" secureTextEntry style={styles.input}/>
          <Text style={styles.label}>Nome da empresa (para cadastro)</Text>
          <TextInput value={businessName} onChangeText={setBusinessName} placeholder="Ex.: Minha Empresa" style={styles.input}/>
          <Text style={styles.label}>Ramo de atividade</Text>
          <TextInput value={businessType} onChangeText={setBusinessType} placeholder="Comércio, serviços, alimentação…" style={styles.input}/>
          <TouchableOpacity style={styles.primary} onPress={signIn}><Text style={styles.primaryText}>Entrar</Text></TouchableOpacity>
          <TouchableOpacity style={styles.secondary} onPress={signUp}><Text style={styles.secondaryText}>Criar conta e empresa</Text></TouchableOpacity>
          <Text style={styles.tiny}>No modo demonstração, não use senhas reais. Para produção, configure autenticação e banco de dados.</Text>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );

  if (profile && !business) return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content"/>
      <ScrollView contentContainerStyle={styles.loginWrap}>
        <View style={styles.brandIcon}><Text style={{fontSize:28}}>✦</Text></View>
        <Text style={styles.brand}>Configure sua empresa</Text>
        <Text style={styles.subtitle}>Sua conta está pronta. Agora cadastre o negócio que você vai administrar.</Text>
        <Text style={styles.label}>Nome da empresa</Text>
        <TextInput value={businessName} onChangeText={setBusinessName} placeholder="Ex.: Minha Empresa" style={styles.input}/>
        <Text style={styles.label}>Ramo de atividade</Text>
        <TextInput value={businessType} onChangeText={setBusinessType} placeholder="Comércio, serviços, alimentação…" style={styles.input}/>
        <TouchableOpacity style={styles.primary} onPress={createBusiness}><Text style={styles.primaryText}>Criar empresa</Text></TouchableOpacity>
        <TouchableOpacity style={styles.secondary} onPress={logout}><Text style={styles.secondaryText}>Sair da conta</Text></TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content"/>
      <View style={styles.topbar}>
        <View style={styles.logoSmall}><Text style={{color:'#fff',fontSize:18,fontWeight:'900'}}>✦</Text></View>
        <View style={{flex:1}}><Text style={styles.topTitle}>Assistente Virtual</Text><Text style={styles.topSub}>{business?.name || 'Minha empresa'} · {business?.business_type || 'Negócio'}</Text></View>
        <TouchableOpacity onPress={()=>Alert.alert('Conta',profile.email||'Usuário')}><Text style={styles.avatar}>●</Text></TouchableOpacity>
      </View>
      {offlineMode && <View style={styles.demoBar}><Text style={styles.demoText}>DEMONSTRAÇÃO LOCAL · dados não sincronizados</Text></View>}
      <ScrollView style={{flex:1}} contentContainerStyle={styles.content}>
        {page==='Início' && <>
          <Text style={styles.h1}>Visão geral</Text><Text style={styles.subtitleLeft}>Veja como está seu negócio.</Text>
          <View style={styles.statsRow}>
            <Stat title="Entradas" value={money(income)} color="#16794b"/>
            <Stat title="Saídas" value={money(expenses)} color="#c24141"/>
          </View>
          <View style={styles.heroCard}><Text style={styles.heroLabel}>Saldo dos lançamentos</Text><Text style={styles.heroValue}>{money(balance)}</Text><Text style={styles.heroFoot}>Entradas menos saídas registradas</Text></View>
          <View style={styles.sectionHead}><Text style={styles.h2}>Acesso rápido</Text></View>
          <View style={styles.quickGrid}>
            <Quick title="Adicionar finanças" icon="＋" onPress={()=>setPage('Financeiro')}/>
            <Quick title="Cadastrar cliente" icon="♙" onPress={()=>setPage('Clientes')}/>
            <Quick title="Falar com a IA" icon="✦" onPress={()=>setPage('Assistente')}/>
            <Quick title="Relatórios" icon="▥" onPress={()=>setPage('Relatórios')}/>
          </View>
          <Text style={styles.h2}>Últimos lançamentos</Text>
          {entries.slice(0,4).map(e=><EntryRow key={e.id} item={e}/>)}
          {!entries.length && <Empty text="Nenhum lançamento ainda. Adicione sua primeira entrada ou saída."/>}
        </>}
        {page==='Financeiro' && <>
          <Text style={styles.h1}>Financeiro</Text><Text style={styles.subtitleLeft}>Registre entradas e saídas da empresa.</Text>
          <View style={styles.statsRow}><Stat title="Entradas" value={money(income)} color="#16794b"/><Stat title="Saídas" value={money(expenses)} color="#c24141"/></View>
          <View style={styles.card}>
            <Text style={styles.h2}>Novo lançamento</Text>
            <View style={styles.segmentRow}><TouchableOpacity style={[styles.segment,entryKind==='entrada'&&styles.segmentOn]} onPress={()=>setEntryKind('entrada')}><Text style={[styles.segmentText,entryKind==='entrada'&&styles.segmentTextOn]}>Entrada</Text></TouchableOpacity><TouchableOpacity style={[styles.segment,entryKind==='saída'&&styles.segmentOn]} onPress={()=>setEntryKind('saída')}><Text style={[styles.segmentText,entryKind==='saída'&&styles.segmentTextOn]}>Saída</Text></TouchableOpacity></View>
            <TextInput value={entryTitle} onChangeText={setEntryTitle} placeholder="Descrição (ex.: venda, aluguel)" style={styles.input}/>
            <TextInput value={entryAmount} onChangeText={setEntryAmount} placeholder="Valor em R$ (ex.: 150,00)" keyboardType="decimal-pad" style={styles.input}/>
            <TouchableOpacity style={styles.primary} onPress={()=>{const a=Number(entryAmount.replace(',','.'));if(!entryTitle.trim()||!a||a<=0)return Alert.alert('Confira os dados','Informe uma descrição e um valor maior que zero.');saveEntry({title:entryTitle.trim(),amount:a,kind:entryKind,date:today(),category:'Geral'});}}><Text style={styles.primaryText}>Salvar lançamento</Text></TouchableOpacity>
          </View>
          <Text style={styles.h2}>Histórico</Text>
          {entries.map(e=><TouchableOpacity key={e.id} onLongPress={()=>deleteEntry(e)}><EntryRow item={e} hint="Segure para excluir"/></TouchableOpacity>)}
          {!entries.length&&<Empty text="Seus lançamentos aparecerão aqui."/>}
        </>}
        {page==='Clientes' && <>
          <Text style={styles.h1}>Clientes</Text><Text style={styles.subtitleLeft}>Organize seus contatos comerciais.</Text>
          <View style={styles.card}><Text style={styles.h2}>Novo cliente</Text><TextInput value={customerName} onChangeText={setCustomerName} placeholder="Nome do cliente ou empresa" style={styles.input}/><TextInput value={customerContact} onChangeText={setCustomerContact} placeholder="Telefone ou e-mail (opcional)" style={styles.input}/><TouchableOpacity style={styles.primary} onPress={()=>{if(!customerName.trim())return Alert.alert('Falta o nome','Informe o nome do cliente.');saveCustomer({name:customerName.trim(),contact:customerContact.trim()});}}><Text style={styles.primaryText}>Cadastrar cliente</Text></TouchableOpacity></View>
          {customers.map(c=><View key={c.id} style={styles.listCard}><View style={styles.avatarSmall}><Text style={{color:'#1769ff',fontWeight:'800'}}>{c.name?.slice(0,1)?.toUpperCase()}</Text></View><View style={{flex:1}}><Text style={styles.rowTitle}>{c.name}</Text><Text style={styles.muted}>{c.contact||'Sem contato informado'}</Text></View></View>)}
          {!customers.length&&<Empty text="Cadastre seu primeiro cliente."/>}
        </>}
        {page==='Assistente' && <>
          <Text style={styles.h1}>Assistente de IA</Text><Text style={styles.subtitleLeft}>Analise seus registros e prepare ações.</Text>
          <View style={styles.aiCard}><View style={styles.aiMark}><Text style={{color:'#fff',fontSize:20}}>✦</Text></View><Text style={styles.h2}>Seu assistente empresarial</Text><Text style={styles.bodyText}>{assistantLog}</Text></View>
          {proposal&&<View style={styles.proposal}><Text style={styles.h2}>Confirme a ação</Text><Text style={styles.bodyText}>{proposal.summary}</Text><Text style={styles.muted}>A ação só será executada quando você confirmar.</Text><View style={styles.segmentRow}><TouchableOpacity style={styles.secondaryFlex} onPress={()=>setProposal(null)}><Text style={styles.secondaryText}>Cancelar</Text></TouchableOpacity><TouchableOpacity style={styles.primaryFlex} onPress={confirmProposal}><Text style={styles.primaryText}>Confirmar</Text></TouchableOpacity></View></View>}
          <View style={styles.card}><Text style={styles.label}>O que você quer fazer?</Text><TextInput value={ask} onChangeText={setAsk} placeholder="Ex.: registrar despesa de 35,90 de material" multiline style={[styles.input,{height:100,textAlignVertical:'top'}]}/><TouchableOpacity style={styles.primary} onPress={prepareAction}><Text style={styles.primaryText}>Analisar pedido</Text></TouchableOpacity></View>
          <Text style={styles.tiny}>Nesta versão, a interpretação é demonstrativa e limitada a alguns comandos. Uma IA generativa real exige integração segura com um serviço de IA.</Text>
        </>}
        {page==='Relatórios' && <>
          <Text style={styles.h1}>Relatórios</Text><Text style={styles.subtitleLeft}>Resumo com base nos lançamentos cadastrados.</Text>
          <View style={styles.heroCard}><Text style={styles.heroLabel}>Saldo atual registrado</Text><Text style={styles.heroValue}>{money(balance)}</Text></View>
          <View style={styles.card}><ReportLine label="Total de entradas" value={money(income)} color="#16794b"/><ReportLine label="Total de saídas" value={money(expenses)} color="#c24141"/><ReportLine label="Quantidade de lançamentos" value={String(entries.length)}/><ReportLine label="Clientes cadastrados" value={String(customers.length)}/></View>
          <Text style={styles.tiny}>Este relatório ainda não separa períodos, impostos, contas futuras ou conciliação bancária.</Text>
        </>}
      </ScrollView>
      <View style={styles.nav}>
        {['Início','Financeiro','Clientes','Assistente','Relatórios'].map((p,i)=><TouchableOpacity key={p} onPress={()=>setPage(p)} style={styles.navItem}><Text style={[styles.navIcon,page===p&&styles.navSelected]}>{['⌂','R$','♙','✦','▥'][i]}</Text><Text style={[styles.navLabel,page===p&&styles.navSelected]}>{p}</Text></TouchableOpacity>)}
      </View>
      <TouchableOpacity style={styles.logout} onPress={logout}><Text style={styles.logoutText}>Sair da conta</Text></TouchableOpacity>
    </SafeAreaView>
  );
}

function Stat({title,value,color}) { return <View style={styles.stat}><Text style={styles.statLabel}>{title}</Text><Text style={[styles.statValue,{color:color||'#172b4d'}]}>{value}</Text></View>; }
function Quick({title,icon,onPress}) { return <TouchableOpacity style={styles.quick} onPress={onPress}><Text style={styles.quickIcon}>{icon}</Text><Text style={styles.quickTitle}>{title}</Text></TouchableOpacity>; }
function EntryRow({item,hint}) { const positive=item.kind==='entrada'; return <View style={styles.entry}><View style={[styles.entryDot,{backgroundColor:positive?'#dcfce7':'#fee2e2'}]}><Text style={{color:positive?'#16794b':'#c24141',fontWeight:'900'}}>{positive?'+':'−'}</Text></View><View style={{flex:1}}><Text style={styles.rowTitle}>{item.title}</Text><Text style={styles.muted}>{item.date||item.created_at?.slice(0,10)||'Sem data'}{hint?' · '+hint:''}</Text></View><Text style={[styles.entryAmount,{color:positive?'#16794b':'#c24141'}]}>{positive?'+':'−'}{money(item.amount)}</Text></View>; }
function Empty({text}) { return <View style={styles.empty}><Text style={styles.muted}>{text}</Text></View>; }
function ReportLine({label,value,color}) { return <View style={styles.reportLine}><Text style={styles.bodyText}>{label}</Text><Text style={[styles.rowTitle,{color:color||'#172b4d'}]}>{value}</Text></View>; }

const styles=StyleSheet.create({
 safe:{flex:1,backgroundColor:'#f5f7fb'}, center:{flex:1,alignItems:'center',justifyContent:'center',gap:12,backgroundColor:'#f5f7fb'},
 topbar:{paddingHorizontal:18,paddingVertical:13,backgroundColor:'#fff',flexDirection:'row',alignItems:'center',borderBottomWidth:1,borderBottomColor:'#e7ecf4',gap:10},
 logoSmall:{width:38,height:38,borderRadius:13,backgroundColor:'#1769ff',alignItems:'center',justifyContent:'center'},
 topTitle:{fontSize:17,fontWeight:'800',color:'#152746'},topSub:{fontSize:11,color:'#718096',marginTop:2},avatar:{color:'#1769ff',fontSize:24},
 demoBar:{backgroundColor:'#fff3cd',paddingVertical:6,alignItems:'center'},demoText:{fontSize:10,fontWeight:'800',color:'#8a5b00',letterSpacing:.3},
 content:{padding:16,paddingBottom:18},h1:{fontSize:25,fontWeight:'900',color:'#152746',marginTop:4},subtitle:{fontSize:14,color:'#6b7890',textAlign:'center',lineHeight:21,marginBottom:24},subtitleLeft:{fontSize:13,color:'#6b7890',marginTop:5,marginBottom:18},
 statsRow:{flexDirection:'row',gap:10,marginBottom:12},stat:{flex:1,backgroundColor:'#fff',borderRadius:16,padding:15,borderWidth:1,borderColor:'#e7ecf4'},statLabel:{fontSize:12,color:'#718096',marginBottom:8},statValue:{fontSize:18,fontWeight:'900'},
 heroCard:{backgroundColor:'#1769ff',borderRadius:18,padding:19,marginBottom:20},heroLabel:{color:'#dce8ff',fontSize:13},heroValue:{color:'#fff',fontSize:29,fontWeight:'900',marginTop:6},heroFoot:{color:'#dce8ff',fontSize:11,marginTop:7},
 sectionHead:{marginBottom:12},h2:{fontSize:16,fontWeight:'800',color:'#152746',marginBottom:12},quickGrid:{flexDirection:'row',flexWrap:'wrap',gap:10,marginBottom:22},quick:{width:'48%',flexGrow:1,backgroundColor:'#fff',borderRadius:15,borderWidth:1,borderColor:'#e7ecf4',padding:15,minHeight:98},quickIcon:{fontSize:24,color:'#1769ff',marginBottom:10},quickTitle:{fontSize:12,fontWeight:'700',color:'#243653'},
 card:{backgroundColor:'#fff',padding:16,borderRadius:17,borderWidth:1,borderColor:'#e7ecf4',marginBottom:20},input:{backgroundColor:'#f9fbfe',borderWidth:1,borderColor:'#dfe6f0',borderRadius:11,paddingHorizontal:13,paddingVertical:12,fontSize:14,color:'#172b4d',marginBottom:12},label:{fontSize:12,fontWeight:'700',color:'#52627a',marginBottom:7},primary:{backgroundColor:'#1769ff',paddingVertical:14,borderRadius:11,alignItems:'center',marginTop:3},primaryText:{color:'#fff',fontWeight:'800',fontSize:14},secondary:{borderWidth:1,borderColor:'#1769ff',paddingVertical:13,borderRadius:11,alignItems:'center',marginTop:10},secondaryText:{color:'#1769ff',fontWeight:'800',fontSize:14},
 segmentRow:{flexDirection:'row',gap:10,marginBottom:12},segment:{flex:1,borderWidth:1,borderColor:'#dfe6f0',borderRadius:10,paddingVertical:11,alignItems:'center'},segmentOn:{backgroundColor:'#eaf1ff',borderColor:'#1769ff'},segmentText:{color:'#52627a',fontWeight:'700'},segmentTextOn:{color:'#1769ff'},
 entry:{flexDirection:'row',alignItems:'center',gap:11,paddingVertical:13,borderBottomWidth:1,borderBottomColor:'#edf0f5'},entryDot:{width:34,height:34,borderRadius:12,alignItems:'center',justifyContent:'center'},rowTitle:{fontSize:13,fontWeight:'800',color:'#22334e'},muted:{fontSize:11,color:'#7b879a',marginTop:4},entryAmount:{fontSize:12,fontWeight:'800'},empty:{padding:20,backgroundColor:'#fff',borderRadius:14,alignItems:'center',marginBottom:18},
 listCard:{flexDirection:'row',alignItems:'center',gap:11,backgroundColor:'#fff',padding:14,borderRadius:14,borderWidth:1,borderColor:'#e7ecf4',marginBottom:9},avatarSmall:{width:38,height:38,borderRadius:13,backgroundColor:'#eaf1ff',alignItems:'center',justifyContent:'center'},
 aiCard:{backgroundColor:'#eaf1ff',padding:17,borderRadius:17,marginBottom:14,borderWidth:1,borderColor:'#d5e3ff'},aiMark:{width:38,height:38,borderRadius:13,backgroundColor:'#1769ff',alignItems:'center',justifyContent:'center',marginBottom:13},bodyText:{fontSize:13,color:'#52627a',lineHeight:20},proposal:{backgroundColor:'#fff8e8',borderColor:'#f5d28b',borderWidth:1,borderRadius:15,padding:15,marginBottom:14},secondaryFlex:{flex:1,borderWidth:1,borderColor:'#1769ff',paddingVertical:13,borderRadius:10,alignItems:'center'},primaryFlex:{flex:1,backgroundColor:'#1769ff',paddingVertical:13,borderRadius:10,alignItems:'center'},tiny:{fontSize:10,color:'#7b879a',lineHeight:15,marginTop:12},
 reportLine:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',paddingVertical:13,borderBottomWidth:1,borderBottomColor:'#edf0f5'},
 nav:{flexDirection:'row',backgroundColor:'#fff',borderTopWidth:1,borderTopColor:'#e7ecf4',paddingTop:8,paddingBottom:5,justifyContent:'space-around'},navItem:{alignItems:'center',flex:1,gap:3},navIcon:{fontSize:18,color:'#8995a8',fontWeight:'800'},navSelected:{color:'#1769ff'},navLabel:{fontSize:9,color:'#8995a8'},logout:{backgroundColor:'#fff',alignItems:'center',paddingVertical:8,borderTopWidth:1,borderTopColor:'#f0f2f6'},logoutText:{fontSize:11,color:'#b44343',fontWeight:'700'},
 loginWrap:{paddingHorizontal:24,paddingTop:42,paddingBottom:36},brandIcon:{alignSelf:'center',width:62,height:62,borderRadius:20,backgroundColor:'#1769ff',alignItems:'center',justifyContent:'center',marginBottom:14},brand:{fontSize:29,fontWeight:'900',color:'#152746',textAlign:'center'},notice:{backgroundColor:'#fff3cd',padding:12,borderRadius:10,marginBottom:16},noticeText:{fontSize:11,color:'#795900',lineHeight:16}
});