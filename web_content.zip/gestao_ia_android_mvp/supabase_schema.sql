-- Execute no SQL Editor do seu projeto Supabase.
-- Este esquema separa os dados por empresa e protege cada linha com RLS.

create extension if not exists pgcrypto;

create table if not exists public.businesses (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  business_type text not null default 'Outro',
  owner_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.business_members (
  business_id uuid not null references public.businesses(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','admin','member')),
  created_at timestamptz not null default now(),
  primary key (business_id,user_id)
);

create table if not exists public.finance_entries (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  created_by uuid not null references auth.users(id),
  title text not null,
  amount numeric(12,2) not null check (amount > 0),
  kind text not null check (kind in ('entrada','saída')),
  category text not null default 'Geral',
  date date not null default current_date,
  created_at timestamptz not null default now()
);

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  created_by uuid not null references auth.users(id),
  name text not null,
  contact text,
  created_at timestamptz not null default now()
);

create index if not exists finance_entries_business_date_idx on public.finance_entries(business_id,date desc);
create index if not exists customers_business_name_idx on public.customers(business_id,name);

alter table public.businesses enable row level security;
alter table public.business_members enable row level security;
alter table public.finance_entries enable row level security;
alter table public.customers enable row level security;

create policy "members can read their businesses" on public.businesses
for select to authenticated using (
  exists(select 1 from public.business_members m where m.business_id=id and m.user_id=auth.uid())
  or owner_id=auth.uid()
);
create policy "authenticated users can create their own business" on public.businesses
for insert to authenticated with check (owner_id=auth.uid());
create policy "owners can update their businesses" on public.businesses
for update to authenticated using (owner_id=auth.uid()) with check (owner_id=auth.uid());

create policy "users can read their own memberships" on public.business_members
for select to authenticated using (user_id=auth.uid());
create policy "users can add themselves as owner to their business" on public.business_members
for insert to authenticated with check (
  user_id=auth.uid() and role='owner'
  and exists(select 1 from public.businesses b where b.id=business_id and b.owner_id=auth.uid())
);

create policy "members can read finance entries" on public.finance_entries
for select to authenticated using (exists(select 1 from public.business_members m where m.business_id=finance_entries.business_id and m.user_id=auth.uid()));
create policy "members can add finance entries" on public.finance_entries
for insert to authenticated with check (created_by=auth.uid() and exists(select 1 from public.business_members m where m.business_id=finance_entries.business_id and m.user_id=auth.uid()));
create policy "members can delete finance entries" on public.finance_entries
for delete to authenticated using (exists(select 1 from public.business_members m where m.business_id=finance_entries.business_id and m.user_id=auth.uid()));

create policy "members can read customers" on public.customers
for select to authenticated using (exists(select 1 from public.business_members m where m.business_id=customers.business_id and m.user_id=auth.uid()));
create policy "members can add customers" on public.customers
for insert to authenticated with check (created_by=auth.uid() and exists(select 1 from public.business_members m where m.business_id=customers.business_id and m.user_id=auth.uid()));
