# SkillStep Student Earning App — starter

Mobile-friendly HTML/CSS/JavaScript prototype.

Features: search, categories, sample skill activities, demo points, saved activities, progress profile. Progress is saved only on this device.

Important: points are not cash and cannot be withdrawn. No real paid jobs, account system, payment or server is connected. Never pay upfront fees or share OTPs, passwords or bank PINs. Check platform age rules and review opportunities with a trusted adult.

This ZIP is source code, NOT a compiled APK. Building a safe APK usually requires Android Studio on a computer or a trusted Android app builder. Test the APK before installing.
