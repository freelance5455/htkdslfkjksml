let loadedBOMData = [];
let scannedReelsList = [];

window.onload = function() {
    let today = new Date().toISOString().split('T')[0];
    document.getElementById('ginDate').value = today;
};

document.getElementById('bomFileInput').addEventListener('change', function(e) {
    let file = e.target.files[0];
    if (!file) return;

    let reader = new FileReader();
    reader.onload = function(evt) {
        let data = new Uint8Array(evt.target.result);
        let workbook = XLSX.read(data, {type: 'array'});
        let firstSheetName = workbook.SheetNames[0];
        let worksheet = workbook.Sheets[firstSheetName];

        loadedBOMData = XLSX.utils.sheet_to_json(worksheet, {defval: ""});
        
        let statusElement = document.getElementById('bomStatus');
        statusElement.innerText = `✅ BOM Loaded Successfully (${loadedBOMData.length} Items Found)`;
        statusElement.style.color = "#059669";
    };
    reader.readAsArrayBuffer(file);
});

function parseReelText() {
    let rawInput = document.getElementById('scannedMaterialCode').value.trim();
    if (!rawInput) return;

    let lotMatch = rawInput.match(/(?:LOT|BATCH|LOT NO|L\/N)[:\s-]*([A-Z0-9]+)/i);
    let dateCodeMatch = rawInput.match(/(?:D\/C|DATE|DC|DATE CODE)[:\s-]*([0-9]{4}|[A-Z0-9]+)/i);
    let pkgMatch = rawInput.match(/(?:PKG|PACKAGE|BODY|SIZE)[:\s-]*([A-Z0-9]+)/i);
    let qtyMatch = rawInput.match(/(?:QTY|Q'TY|Q)[:\s-]*([0-9]+)/i);

    let extractedBatchInfo = "";
    if (lotMatch) {
        extractedBatchInfo = "LOT: " + lotMatch[1];
    } else if (dateCodeMatch) {
        extractedBatchInfo = "D/C: " + dateCodeMatch[1];
    } else if (pkgMatch) {
        extractedBatchInfo = "PKG: " + pkgMatch[1];
    } else {
        extractedBatchInfo = "N/A (Using Desc Spec)";
    }

    let isLotLocked = document.getElementById('lockLotToggle').checked;
    if (!isLotLocked && extractedBatchInfo !== "N/A (Using Desc Spec)") {
        document.getElementById('lotNumber').value = extractedBatchInfo;
    }

    if (qtyMatch && !document.getElementById('reelQty').value) {
        document.getElementById('reelQty').value = qtyMatch[1];
    }

    matchBOMData();
}

function matchBOMData() {
    let inputCode = document.getElementById('scannedMaterialCode').value.trim().toLowerCase();
    let matchCard = document.getElementById('matchResultCard');

    if (!inputCode || loadedBOMData.length === 0) {
        matchCard.style.display = "none";
        return;
    }

    let matchedItem = loadedBOMData.find(row => {
        let rowValues = Object.values(row).map(val => String(val).toLowerCase());
        return rowValues.some(val => val.includes(inputCode));
    });

    if (matchedItem) {
        let keys = Object.keys(matchedItem);
        let partCode = matchedItem[keys[1]] || matchedItem[keys[0]] || "N/A";
        let description = matchedItem[keys[2]] || matchedItem[keys[3]] || "N/A";
        let pkgSize = matchedItem[keys[4]] || matchedItem[keys[5]] || "";

        document.getElementById('resPartCode').innerText = partCode;
        document.getElementById('resDesc').innerText = description + (pkgSize ? ` [PKG: ${pkgSize}]` : '');
        document.getElementById('matchStatus').innerText = "MATCHED";
        document.getElementById('matchStatus').style.backgroundColor = "#10b981";

        matchCard.style.display = "block";
    } else {
        document.getElementById('resPartCode').innerText = "Not Found in BOM";
        document.getElementById('resDesc').innerText = "Manual Verification Required";
        document.getElementById('matchStatus').innerText = "NOT IN BOM";
        document.getElementById('matchStatus').style.backgroundColor = "#ef4444";

        matchCard.style.display = "block";
    }
}

function updateQtyBalance() {
    let totalInvQty = parseFloat(document.getElementById('totalInvoiceQty').value) || 0;
    let scannedTotal = scannedReelsList.reduce((sum, item) => sum + (parseFloat(item.qty) || 0), 0);
    let remaining = totalInvQty - scannedTotal;

    document.getElementById('scannedSumQty').innerText = scannedTotal;
    document.getElementById('remainingQty').innerText = remaining >= 0 ? remaining : `${remaining} (Over-Qty)`;
}

function addReelToReport() {
    let code = document.getElementById('scannedMaterialCode').value.trim();
    let qty = document.getElementById('reelQty').value.trim();
    let lotInfo = document.getElementById('lotNumber').value.trim();
    let ginDate = document.getElementById('ginDate').value;
    let status = document.getElementById('inspectionResult').value;
    let remarks = document.getElementById('defectRemarks').value;
    let desc = document.getElementById('resDesc').innerText;

    if (!code || !qty) {
        alert("Please enter Part Code and Quantity!");
        return;
    }

    if (!lotInfo) {
        lotInfo = desc !== "Manual Verification Required" ? desc : "No Lot/DC Spec";
    }

    let reelEntry = {
        id: Date.now(),
        ginDate: ginDate,
        materialCode: code,
        description: desc,
        lotOrBatchInfo: lotInfo,
        qty: parseFloat(qty),
        status: status,
        remarks: remarks
    };

    scannedReelsList.push(reelEntry);
    updateTableUI();
    updateQtyBalance();

    document.getElementById('scannedMaterialCode').value = "";
    document.getElementById('reelQty').value = "";
    document.getElementById('defectRemarks').value = "";
    document.getElementById('matchResultCard').style.display = "none";

    let lockToggle = document.getElementById('lockLotToggle').checked;
    if (!lockToggle) {
        document.getElementById('lotNumber').value = "";
    }
}

function deleteReelEntry(id) {
    scannedReelsList = scannedReelsList.filter(item => item.id !== id);
    updateTableUI();
    updateQtyBalance();
}

function updateTableUI() {
    let tbody = document.querySelector('#scannedTable tbody');
    tbody.innerHTML = "";

    scannedReelsList.forEach(item => {
        let row = `<tr>
            <td>${item.materialCode}</td>
            <td>${item.description}</td>
            <td>${item.lotOrBatchInfo}</td>
            <td><strong>${item.qty}</strong></td>
            <td><strong style="color:${item.status === 'OK' ? '#059669' : '#dc2626'}">${item.status}</strong></td>
            <td><button class="btn-delete" onclick="deleteReelEntry(${item.id})">Delete</button></td>
        </tr>`;
        tbody.innerHTML += row;
    });

    document.getElementById('totalScannedCount').innerText = scannedReelsList.length;
}

function exportIQCReport() {
    if (scannedReelsList.length === 0) {
        alert("Please add entries before downloading the report!");
        return;
    }

    let totalInv = document.getElementById('totalInvoiceQty').value || "N/A";
    let totalScanned = scannedReelsList.reduce((sum, item) => sum + item.qty, 0);

    let excelRows = [
        ["IQC REEL INSPECTION REPORT"],
        ["GIN Date:", document.getElementById('ginDate').value],
        ["Total Received Qty:", totalInv, "Total Scanned Qty:", totalScanned],
        ["Total Scanned Reels:", scannedReelsList.length],
        [""],
        ["Material Code", "Description & Package Spec", "Lot No / Date Code / PKG Spec", "Quantity", "Inspection Status", "Remarks"]
    ];

    scannedReelsList.forEach(item => {
        excelRows.push([
            item.materialCode,
            item.description,
            item.lotOrBatchInfo,
            item.qty,
            item.status,
            item.remarks
        ]);
    });

    let ws = XLSX.utils.aoa_to_sheet(excelRows);
    let wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "IQC_Scanned_Reels");

    let fileName = `IQC_Reel_Report_${document.getElementById('ginDate').value}.xlsx`;
    XLSX.writeFile(wb, fileName);
}
