// Mega Vendas - catálogo inicial editável
// Configure o número abaixo com código do país + DDD + número, somente dígitos.
const WHATSAPP_NUMBER = "5500000000000"; // TROQUE pelo seu número
const products = [
{id:1,name:"Camiseta básica",category:"Masculino",price:39.90,desc:"Conforto para o dia a dia",emoji:"👕"},
{id:2,name:"Vestido casual",category:"Feminino",price:79.90,desc:"Visual leve e versátil",emoji:"👗"},
{id:3,name:"Calça jeans",category:"Feminino",price:99.90,desc:"Modelo clássico",emoji:"👖"},
{id:4,name:"Moletom urbano",category:"Masculino",price:119.90,desc:"Ideal para dias frescos",emoji:"🧥"},
{id:5,name:"Bolsa casual",category:"Acessórios",price:69.90,desc:"Um toque no seu look",emoji:"👜"},
{id:6,name:"Boné street",category:"Acessórios",price:34.90,desc:"Estilo casual",emoji:"🧢"}
];
let cart = [];
const money=n=>n.toLocaleString("pt-BR",{style:"currency",currency:"BRL"});
function render(){
 const q=(document.getElementById("search").value||"").toLowerCase(), cat=document.getElementById("category").value;
 document.getElementById("products").innerHTML=products.filter(p=>(cat==="Todas"||p.category===cat)&&p.name.toLowerCase().includes(q)).map(p=>`
 <article class="product"><div class="pic">${p.emoji}</div><div class="info"><h3>${p.name}</h3><div class="desc">${p.desc}</div><div class="price">${money(p.price)}</div><button onclick="add(${p.id})">Adicionar ao carrinho</button></div></article>`).join("");
 drawCart(); drawOrders();
}
function add(id){const p=products.find(x=>x.id===id);const item=cart.find(x=>x.id===id);item?item.qty++:cart.push({...p,qty:1});drawCart();}
function removeItem(id){cart=cart.filter(x=>x.id!==id);drawCart();}
function drawCart(){
 document.getElementById("count").textContent=cart.reduce((a,x)=>a+x.qty,0);
 document.getElementById("cart").innerHTML=cart.length?cart.map(x=>`<div class="cartline row"><span>${x.name} × ${x.qty}</span><span>${money(x.price*x.qty)} <button class="secondary" onclick="removeItem(${x.id})">×</button></span></div>`).join(""):"<p class='small'>Seu carrinho está vazio.</p>";
 document.getElementById("total").textContent=money(cart.reduce((a,x)=>a+x.price*x.qty,0));
}
function checkout(mode){
 if(!cart.length){alert("Adicione produtos ao carrinho primeiro.");return;}
 const name=document.getElementById("customer").value.trim(), phone=document.getElementById("phone").value.trim(), address=document.getElementById("address").value.trim();
 if(!name||!phone||!address){alert("Preencha nome, telefone e endereço/retirada.");return;}
 const order={number:Date.now(),date:new Date().toLocaleString("pt-BR"),name,phone,address,notes:document.getElementById("notes").value,items:cart.map(x=>({name:x.name,qty:x.qty,price:x.price})),total:cart.reduce((a,x)=>a+x.price*x.qty,0)};
 const orders=JSON.parse(localStorage.getItem("mega_vendas_orders")||"[]");orders.unshift(order);localStorage.setItem("mega_vendas_orders",JSON.stringify(orders));
 const message=`Pedido Mega Vendas #${String(order.number).slice(-6)}%0ACliente: ${encodeURIComponent(name)}%0ATelefone: ${encodeURIComponent(phone)}%0AEntrega/retirada: ${encodeURIComponent(address)}%0AItens: ${encodeURIComponent(order.items.map(x=>`${x.name} x${x.qty}`).join(", "))}%0ATotal: ${encodeURIComponent(money(order.total))}%0AObservações: ${encodeURIComponent(order.notes||"-")}`;
 const status=document.getElementById("status");status.style.display="block";
 if(mode==="whatsapp"){
   if(WHATSAPP_NUMBER==="5500000000000"){status.textContent="Pedido salvo neste aparelho. Configure WHATSAPP_NUMBER em app.js com seu número para abrir o WhatsApp."; }
   else {window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${message}`,"_blank");status.textContent="Pedido registrado. O WhatsApp foi aberto para enviar a mensagem.";}
 } else status.textContent=`Pedido #${String(order.number).slice(-6)} salvo neste aparelho!`;
 cart=[];drawCart();drawOrders();
}
function drawOrders(){
 const orders=JSON.parse(localStorage.getItem("mega_vendas_orders")||"[]");
 document.getElementById("orders").innerHTML=orders.length?orders.map(o=>`<div class="cartline"><b>Pedido #${String(o.number).slice(-6)} • ${money(o.total)}</b><br>${o.date} — ${o.name}<br>${o.items.map(i=>`${i.name} ×${i.qty}`).join(", ")}</div>`).join(""):"Nenhum pedido ainda.";
}
function clearOrders(){if(confirm("Apagar os pedidos salvos neste aparelho?")){localStorage.removeItem("mega_vendas_orders");drawOrders();}}
render();