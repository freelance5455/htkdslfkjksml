#!/usr/bin/env bash
# Build APK debug (Linux / macOS). Butuh: Node 18+, JDK 17, Android SDK (ANDROID_HOME)
set -e
npm install
node scripts/copy-three.js
[ -d android ] || npx cap add android
npx cap sync android
cd android && chmod +x gradlew && ./gradlew assembleDebug
echo ""
echo "SELESAI. APK ada di: android/app/build/outputs/apk/debug/app-debug.apk"
