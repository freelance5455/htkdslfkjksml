// Menyalin three.js ke www/ supaya game bisa jalan offline di dalam APK
const fs = require('fs');
fs.copyFileSync('node_modules/three/build/three.min.js', 'www/three.min.js');
console.log('three.min.js disalin ke www/');
