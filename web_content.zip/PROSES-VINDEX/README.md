# PROSES VINDEX
Petualangan Konsultan Herbal - game 3D Android (HTML5 + three.js, dibungkus dengan Capacitor).

Misi: ketok pintu tiap rumah, jual obat herbal FITASA (asam urat & rematik) dan FITDARA (darah tinggi & kolesterol) seharga Rp300.000 per botol. Jual 30 botol dan rekrut 8 anggota tim untuk naik jabatan menjadi Manager. Lima lokasi bergantian: Perumahan, Pegunungan, Perkampungan, Pantai, Kota.

## Isi paket
- `www/index.html`  : seluruh game
- `package.json`, `capacitor.config.json` : pengaturan proyek (ID aplikasi `com.prosesvindex.game`)
- `scripts/copy-three.js` : menyalin three.js agar game jalan offline
- `build-apk.sh` (Linux/Mac) dan `build-apk.bat` (Windows) : build otomatis
- `assets/icon-only.png` : ikon aplikasi (1024x1024)

## Yang perlu dipasang (sekali saja)
1. Node.js 18 atau lebih baru
2. JDK 17
3. Android Studio (untuk Android SDK), lalu atur variabel `ANDROID_HOME` ke folder SDK
4. Koneksi internet saat build pertama (mengunduh paket dan Gradle)

## Cara membuat APK (otomatis)
1. Ekstrak file ZIP ini.
2. Buka terminal di dalam folder `PROSES-VINDEX`.
3. Linux/Mac: `./build-apk.sh`   |   Windows: klik dua kali `build-apk.bat`
4. APK jadi di `android/app/build/outputs/apk/debug/app-debug.apk`
5. Kirim file itu ke HP, lalu pasang (izinkan "Install dari sumber tidak dikenal").

## Cara lewat Android Studio
```
npm install
npm run setup
npx cap add android
npm run sync
npm run open
```
Di Android Studio pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Mengganti ikon (opsional)
```
npx @capacitor/assets generate --android
```
Ikon diambil dari `assets/icon-only.png`.

## Mengunci layar potret (opsional)
Setelah `npx cap add android`, buka `android/app/src/main/AndroidManifest.xml`, lalu pada tag `<activity>` tambahkan:
`android:screenOrientation="portrait"`

## Rilis ke Play Store
APK debug hanya untuk uji coba. Untuk rilis, buat keystore lalu pilih **Build > Generate Signed Bundle / APK** di Android Studio.

## Catatan
- Jika `three.min.js` tidak ditemukan di `www/`, game otomatis memuat three.js dari internet. Untuk mode offline penuh, jalankan `npm run setup`.
- Setiap mengubah `www/index.html`, jalankan `npm run sync` sebelum build ulang.
