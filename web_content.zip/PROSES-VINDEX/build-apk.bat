@echo off
REM Build APK debug (Windows). Butuh: Node 18+, JDK 17, Android SDK (ANDROID_HOME)
call npm install || exit /b 1
call node scripts\copy-three.js || exit /b 1
if not exist android call npx cap add android
call npx cap sync android || exit /b 1
cd android
call gradlew.bat assembleDebug || exit /b 1
echo.
echo SELESAI. APK ada di: android\app\build\outputs\apk\debug\app-debug.apk
pause
