POS MÓVIL ANDROID - PROYECTO APK
================================

Este ZIP contiene un proyecto Android Studio que empaqueta el POS HTML como una app Android.

INCLUYE:
- Persistencia de productos, ventas e información del ticket mediante almacenamiento local.
- Copia de seguridad JSON desde la propia app.
- Restauración de copia JSON.
- Selección de impresora térmica Bluetooth previamente vinculada al teléfono.
- Impresión directa ESC/POS básica por Bluetooth clásico (SPP).
- Papel configurable 58/80 mm desde el POS.
- Funciona sin Internet una vez instalados los recursos de la app; el HTML original todavía usa algunos recursos CDN, por lo que para una versión 100% offline conviene empaquetarlos localmente.

PARA GENERAR EL APK:
1. Abre la carpeta POS_Movil_Android en Android Studio.
2. Espera a que sincronice Gradle y acepte/instale el Android SDK solicitado (compileSdk 35).
3. Conecta tu Android con depuración USB o usa Build > Build APK(s).
4. El APK de prueba quedará normalmente en app/build/outputs/apk/debug/app-debug.apk.

IMPRESORA:
- Primero vincula la impresora térmica desde Ajustes > Bluetooth del teléfono.
- Dentro del POS entra a Ticket y pulsa “Impresora Bluetooth”.
- Selecciona la impresora vinculada.
- Al cobrar una venta se enviará el ticket a la impresora.

COPIAS:
- Ticket > “Copia de seguridad” crea un archivo JSON que puedes guardar en el teléfono, Drive, WhatsApp, etc.
- Ticket > “Restaurar copia” permite recuperar productos, ventas y configuración.
- Guarda una copia antes de actualizar/reinstalar la app.

NOTA:
La impresión Bluetooth está preparada para impresoras térmicas ESC/POS que acepten Bluetooth Classic/SPP. Algunas impresoras BLE, Wi-Fi o modelos con protocolos propietarios necesitarán una adaptación específica.
