<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POS Móvil</title>
    <style>
        body { font-family: sans-serif; padding: 20px; }
        button { padding: 10px 15px; margin: 5px; font-size: 16px; }
    </style>
</head>
<body>
    <h2>Punto de Venta</h2>
    <p>Impresora actual: <span id="printerName">Ninguna</span></p>
    
    <button onclick="seleccionarImpresora()">Vincular Impresora</button>
    <button onclick="registrarVenta()">Vender 1Kg de Cebolla</button>
    <button onclick="verInventario()">Ver Inventario</button>

    <div id="log"></div>

    <script>
        // 1. INICIALIZAR BASE DE DATOS (INDEXEDDB)
        let db;
        const request = indexedDB.open("POS_DB", 1);

        request.onupgradeneeded = (event) => {
            db = event.target.result;
            if (!db.objectStoreNames.contains("productos")) {
                const store = db.createObjectStore("productos", { keyPath: "id" });
                // Insertar stock inicial ficticio (Ej: compraste 10kg hace un año)
                store.add({ id: 1, nombre: "Cebolla", cantidad_kg: 10, precio: 20.00 });
            }
        };
        request.onsuccess = (event) => { db = event.target.result; };

        // 2. CONEXIÓN CON BLUETOOTH (JAVA BRIDGE)
        function seleccionarImpresora() {
            if(window.Android) window.Android.choosePrinter();
        }

        // Callback invocado desde Java cuando se selecciona la impresora
        window.onPrinterSelected = function(nombre) {
            document.getElementById('printerName').innerText = nombre;
        };

        // 3. LÓGICA DE VENTA E IMPRESIÓN
        function registrarVenta() {
            const transaction = db.transaction(["productos"], "readwrite");
            const store = transaction.objectStore("productos");
            const req = store.get(1); // ID 1 = Cebolla

            req.onsuccess = () => {
                let producto = req.result;
                if (producto.cantidad_kg >= 1) {
                    // Descontar del inventario histórico
                    producto.cantidad_kg -= 1;
                    store.put(producto);

                    // Formatear JSON exacto que espera MainActivity.java
                    const ticketJSON = {
                        config: { paperWidth: 58, businessName: "Abarrotes", footerMsg: "¡Vuelva pronto!" },
                        sale: {
                            date: new Date().toLocaleString(),
                            customer: "Público General",
                            items: [{ name: producto.nombre, qty: 1, price: producto.precio }],
                            total: producto.precio,
                            paymentMethod: "Efectivo",
                            change: 0
                        }
                    };

                    // Enviar al método printTicket() de Java
                    if(window.Android) window.Android.printTicket(JSON.stringify(ticketJSON));
                    
                } else {
                    alert("Sin stock de cebolla");
                }
            };
        }

        function verInventario() {
            const transaction = db.transaction(["productos"], "readonly");
            const req = transaction.objectStore("productos").get(1);
            req.onsuccess = () => {
                document.getElementById('log').innerText = `Stock actual de Cebolla: ${req.result.cantidad_kg} kg`;
            };
        }

        // Cargar nombre de impresora al iniciar
        window.onload = () => {
            if(window.Android) {
                let name = window.Android.getPrinterName();
                if(name) document.getElementById('printerName').innerText = name;
            }
        };
    </script>
</body>
</html>
