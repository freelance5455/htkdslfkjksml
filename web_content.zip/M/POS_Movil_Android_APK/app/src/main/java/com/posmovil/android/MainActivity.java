package com.posmovil.android;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.Nullable;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQ_BT = 1001;
    private static final int REQ_ENABLE_BT = 1002;

    private WebView webView;
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothDevice selectedDevice;
    private static final UUID SPP_UUID =
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);

        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBridge(), "Android");

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        // Load the bundled POS HTML.
        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean hasBluetoothPermissions() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private void requestBluetoothPermissions() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            requestPermissions(new String[]{
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
            }, REQ_BT);
        }
    }

    private void ensureBluetooth() {
        if (bluetoothAdapter == null) {
            toast("Este teléfono no tiene Bluetooth.");
            return;
        }
        if (!hasBluetoothPermissions()) {
            requestBluetoothPermissions();
            return;
        }
        if (!bluetoothAdapter.isEnabled()) {
            try {
                startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQ_ENABLE_BT);
            } catch (Exception e) {
                toast("Activa Bluetooth desde Ajustes.");
            }
        }
    }

    private void showPairedPrinters() {
        if (bluetoothAdapter == null) {
            toast("Bluetooth no disponible.");
            return;
        }
        if (!hasBluetoothPermissions()) {
            requestBluetoothPermissions();
            return;
        }
        if (!bluetoothAdapter.isEnabled()) {
            ensureBluetooth();
            return;
        }

        Set<BluetoothDevice> paired = bluetoothAdapter.getBondedDevices();
        List<BluetoothDevice> printers = new ArrayList<>(paired);

        if (printers.isEmpty()) {
            toast("No hay dispositivos Bluetooth vinculados. Vincula primero la impresora en Ajustes de Android.");
            return;
        }

        // Return a simple JSON array to JavaScript.
        StringBuilder json = new StringBuilder("[");
        for (int i = 0; i < printers.size(); i++) {
            BluetoothDevice d = printers.get(i);
            if (i > 0) json.append(",");
            json.append("{\"name\":")
                .append(JSONObjectEscape(d.getName()))
                .append(",\"address\":")
                .append(JSONObjectEscape(d.getAddress()))
                .append("}");
        }
        json.append("]");

        final String result = json.toString();
        webView.post(() -> webView.evaluateJavascript(
                "window.onBluetoothPrinters && window.onBluetoothPrinters(" +
                        JSONObjectEscape(result) + ")", null));
    }

    private String JSONObjectEscape(String s) {
        if (s == null) return "\"\"";
        return "\"" + s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r") + "\"";
    }

    private void connectAndPrint(String address, String data) {
        if (!hasBluetoothPermissions()) {
            requestBluetoothPermissions();
            return;
        }
        if (bluetoothAdapter == null) {
            toast("Bluetooth no disponible.");
            return;
        }

        new Thread(() -> {
            BluetoothSocket socket = null;
            try {
                BluetoothDevice device = bluetoothAdapter.getRemoteDevice(address);
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                bluetoothAdapter.cancelDiscovery();
                socket.connect();

                OutputStream out = socket.getOutputStream();
                byte[] bytes = data.getBytes(StandardCharsets.UTF_8);
                out.write(bytes);
                out.flush();

                // Feed paper and attempt a cut for printers supporting ESC/POS cut.
                out.write(new byte[]{0x0A,0x0A,0x0A});
                out.write(new byte[]{0x1D,0x56,0x00});
                out.flush();

                toast("Ticket enviado a la impresora.");
            } catch (Exception e) {
                toast("No se pudo imprimir. Verifica que la impresora esté vinculada y sea Bluetooth ESC/POS.");
            } finally {
                if (socket != null) {
                    try { socket.close(); } catch (IOException ignored) {}
                }
            }
        }).start();
    }

    private void toast(String message) {
        runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show());
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void choosePrinter() {
            runOnUiThread(() -> {
                if (!hasBluetoothPermissions()) {
                    requestBluetoothPermissions();
                } else {
                    ensureBluetooth();
                    if (bluetoothAdapter != null && bluetoothAdapter.isEnabled()) {
                        showPairedPrinters();
                    }
                }
            });
        }

        @JavascriptInterface
        public void printTicket(String address, String data) {
            if (address == null || address.trim().isEmpty()) {
                toast("Primero selecciona una impresora.");
                return;
            }
            connectAndPrint(address, data == null ? "" : data);
        }

        @JavascriptInterface
        public void savePrinter(String address, String name) {
            getPreferences(MODE_PRIVATE).edit()
                    .putString("printer_address", address)
                    .putString("printer_name", name)
                    .apply();
        }

        @JavascriptInterface
        public String getSavedPrinterAddress() {
            return getPreferences(MODE_PRIVATE).getString("printer_address", "");
        }

        @JavascriptInterface
        public String getSavedPrinterName() {
            return getPreferences(MODE_PRIVATE).getString("printer_name", "");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT) {
            boolean ok = true;
            for (int r : grantResults) if (r != PackageManager.PERMISSION_GRANTED) ok = false;
            if (!ok) toast("Se necesitan permisos de Bluetooth para usar la impresora.");
        }
    }
}
