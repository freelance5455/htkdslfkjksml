/* Vortex — интерфейс */
(function () {
  'use strict';
  var A = window.VortexApi, Core = window.VortexCore;
  var root = document.getElementById('root');

  /* ================= помощники ================= */
  function h(tag, props) {
    var el = document.createElement(tag);
    if (props) for (var k in props) {
      var v = props[k];
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'html') el.innerHTML = v;
      else if (k.slice(0, 2) === 'on') el.addEventListener(k.slice(2), v);
      else if (k === 'value') el.value = v;
      else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (var i = 2; i < arguments.length; i++) add(el, arguments[i]);
    return el;
  }
  function add(el, kid) {
    if (kid == null || kid === false) return;
    if (Array.isArray(kid)) { kid.forEach(function (x) { add(el, x); }); return; }
    el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  var P = {
    back: '<path d="M15 5l-7 7 7 7"/>', send: '<path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/>',
    clip: '<path d="M21.4 11.1l-9.2 9.2a5.5 5.5 0 0 1-7.8-7.8l9.2-9.2a3.7 3.7 0 0 1 5.2 5.2l-9.2 9.2a1.8 1.8 0 0 1-2.6-2.6l8.5-8.5"/>',
    phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>', edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
    x: '<path d="M18 6L6 18M6 6l12 12"/>', eye: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
    eyeoff: '<path d="M17.9 17.9A10.9 10.9 0 0 1 12 20c-7 0-11-8-11-8a18.5 18.5 0 0 1 5.1-5.9M9.9 4.2A9.1 9.1 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.2 3.2M1 1l22 22"/>',
    login: '<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="M10 17l5-5-5-5M15 12H3"/>',
    userplus: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/>',
    arrow: '<path d="M5 12h14M12 5l7 7-7 7"/>', reply: '<path d="M9 17l-5-5 5-5"/><path d="M4 12h11a5 5 0 0 1 5 5v2"/>',
    copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
    trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/>', camera: '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>',
    users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
    mega: '<path d="M3 11v2a1 1 0 0 0 1 1h2l5 4V6L6 10H4a1 1 0 0 0-1 1z"/><path d="M16 8a5 5 0 0 1 0 8M19 5a9 9 0 0 1 0 14"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/>', bookmark: '<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>',
    check: '<path d="M20 6L9 17l-5-5"/>', dots: '<path d="M12 5v.01M12 12v.01M12 19v.01" stroke-width="3"/>', retry: '<path d="M23 4v6h-6"/><path d="M20.5 15a9 9 0 1 1-2.1-9.4L23 10"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>'
  };
  function icon(n, size) {
    size = size || 22;
    return h('span', { class: 'ic', html: '<svg viewBox="0 0 24 24" width="' + size + '" height="' + size + '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + P[n] + '</svg>' });
  }
  function badge(size) {
    size = size || 15;
    return h('span', { class: 'vx-badge', title: 'Подтверждён', html: '<svg viewBox="0 0 24 24" width="' + size + '" height="' + size + '"><circle cx="12" cy="12" r="11" fill="#3b82f6"/><path d="M7 12.5l3.2 3.2L17 9" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>' });
  }
  function tick(status) {
    var d = status === 'read' || status === 'delivered';
    var svg = d ? '<svg viewBox="0 0 18 11" width="18" height="11" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M1 5.8l3.4 3.4L11 1.6"/><path d="M6.4 8.4l.8.8L14.3 1.6"/></svg>'
      : status === 'sent' ? '<svg viewBox="0 0 18 11" width="18" height="11" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3 5.8l3.4 3.4L13 1.6"/></svg>'
      : status === 'failed' ? '<svg viewBox="0 0 18 11" width="14" height="11"><text x="5" y="10" font-size="11" font-weight="700" fill="currentColor">!</text></svg>'
      : '<svg viewBox="0 0 18 11" width="12" height="11" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><circle cx="9" cy="5.5" r="4.2"/><path d="M9 3.2v2.5l1.6 1"/></svg>';
    return h('span', { class: 'tick ' + status, html: svg });
  }
  function plural(n, a, b, c) { var m = n % 100, k = n % 10; return n + ' ' + (m > 10 && m < 20 ? c : k === 1 ? a : k >= 2 && k <= 4 ? b : c); }
  function two(n) { return (n < 10 ? '0' : '') + n; }
  function hhmm(ts) { var d = new Date(ts); return two(d.getHours()) + ':' + two(d.getMinutes()); }
  function dayKey(ts) { var d = new Date(ts); return d.getFullYear() + '-' + d.getMonth() + '-' + d.getDate(); }
  var MONTHS = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
  function dayLabel(ts) {
    var d = new Date(ts), n = new Date();
    if (dayKey(ts) === dayKey(+n)) return 'Сегодня';
    if (dayKey(ts) === dayKey(n - 864e5)) return 'Вчера';
    return d.getDate() + ' ' + MONTHS[d.getMonth()] + (d.getFullYear() !== n.getFullYear() ? ' ' + d.getFullYear() : '');
  }
  function listTime(ts) {
    var n = new Date(), d = new Date(ts);
    if (dayKey(ts) === dayKey(+n)) return hhmm(ts);
    if (n - d < 6 * 864e5) return ['вс', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб'][d.getDay()];
    return two(d.getDate()) + '.' + two(d.getMonth() + 1) + '.' + String(d.getFullYear()).slice(2);
  }
  function seen(ts) {
    if (!ts) return 'был(а) недавно';
    var d = new Date(ts);
    if (dayKey(ts) === dayKey(Date.now())) return 'был(а) в ' + hhmm(ts);
    if (dayKey(ts) === dayKey(Date.now() - 864e5)) return 'был(а) вчера в ' + hhmm(ts);
    return 'был(а) ' + d.getDate() + ' ' + MONTHS[d.getMonth()];
  }
  var GRADS = [['#6366f1', '#8b5cf6'], ['#ec4899', '#f43f5e'], ['#f59e0b', '#ef4444'], ['#10b981', '#06b6d4'], ['#3b82f6', '#6366f1'], ['#a855f7', '#ec4899'], ['#14b8a6', '#22c55e']];
  function hashOf(s) { var x = 0; s = String(s); for (var i = 0; i < s.length; i++) x = (x * 31 + s.charCodeAt(i)) | 0; return Math.abs(x); }
  function grad(id) { var g = GRADS[hashOf(id) % GRADS.length]; return 'linear-gradient(135deg,' + g[0] + ',' + g[1] + ')'; }
  function initials(s) { s = String(s || '?').trim(); var w = s.split(/\s+/); return ((w[0] || '?')[0] + (w.length > 1 ? w[1][0] : '')).toUpperCase(); }
  function avatar(e, size, iconName) {
    var el = h('div', { class: 'av', style: { width: size + 'px', height: size + 'px', fontSize: Math.round(size * 0.38) + 'px', background: grad(e.id || e.title || '') } });
    if (iconName) { el.append(icon(iconName, Math.round(size * 0.5))); return el; }
    if (e.avatar) el.append(h('img', { src: A.media(e.avatar), alt: '', loading: 'lazy' }));
    else el.append(initials(e.displayName || e.title));
    return el;
  }
  function nameNode(u) { return h('span', { class: 'nm' }, h('span', { class: 't' }, u.displayName || u.title || '?'), u.verified ? badge() : null); }
  function toast(msg, ms) {
    var old = document.querySelector('.toast'); if (old) old.remove();
    var t = h('div', { class: 'toast' }, msg); document.body.append(t);
    setTimeout(function () { t.remove(); }, ms || 3200);
  }
  function badgePop(title, sub) {
    var old = document.querySelector('.badge-pop'); if (old) old.remove();
    var el = h('div', { class: 'badge-pop' }, h('div', { class: 'card' },
      h('span', { html: '<svg class="big" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#3b82f6"/><path d="M7 12.5l3.2 3.2L17 9" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>' }),
      h('b', null, title), sub ? h('small', null, sub) : null));
    document.body.append(el);
    setTimeout(function () { el.classList.add('out'); }, 3300);
    setTimeout(function () { el.remove(); }, 3700);
  }
  var actx;
  function beep() {
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      var o = actx.createOscillator(), g = actx.createGain(); o.frequency.value = 880; g.gain.value = 0.04;
      o.connect(g); g.connect(actx.destination); o.start(); o.stop(actx.currentTime + 0.1);
    } catch (e) {}
  }
  function openSheet(build) {
    var ov, content;
    function close() { if (ov) ov.remove(); }
    content = build(close);
    ov = h('div', { class: 'overlay', onclick: function (e) { if (e.target === ov) close(); } }, h('div', { class: 'sheet' }, content));
    document.body.append(ov);
    return { close: close, el: ov };
  }
  function pickImage(cb) {
    var i = h('input', { type: 'file', accept: 'image/*' });
    i.onchange = function () { if (i.files && i.files[0]) cb(i.files[0]); };
    i.click();
  }
  function resizeImage(file, maxDim, q, square) {
    return new Promise(function (ok, no) {
      var url = URL.createObjectURL(file), img = new Image();
      img.onload = function () {
        var sw = img.naturalWidth, sh = img.naturalHeight, sx = 0, sy = 0, dw, dh;
        if (square) { var s = Math.min(sw, sh); sx = (sw - s) / 2; sy = (sh - s) / 2; sw = sh = s; dw = dh = Math.min(maxDim, s); }
        else { var k = Math.min(1, maxDim / Math.max(sw, sh)); dw = Math.round(sw * k); dh = Math.round(sh * k); }
        var cv = document.createElement('canvas'); cv.width = dw; cv.height = dh;
        var cx = cv.getContext('2d'); cx.fillStyle = '#fff'; cx.fillRect(0, 0, dw, dh); cx.drawImage(img, sx, sy, sw, sh, 0, 0, dw, dh);
        cv.toBlob(function (b) { URL.revokeObjectURL(url); b ? ok(b) : no(new Error('Не удалось обработать фото')); }, 'image/jpeg', q);
      };
      img.onerror = function () { URL.revokeObjectURL(url); no(new Error('Не удалось открыть изображение')); };
      img.src = url;
    });
  }
  function linkify(text) {
    var out = [], re = /(https?:\/\/[^\s<]+)/g, last = 0, m;
    while ((m = re.exec(text))) {
      if (m.index > last) out.push(text.slice(last, m.index));
      var u = m[1].replace(/[.,;:!?)]+$/, '');
      out.push(h('a', { href: u, target: '_blank', rel: 'noopener noreferrer', onclick: function (e) { e.stopPropagation(); } }, u));
      last = m.index + u.length; re.lastIndex = last;
    }
    if (last < text.length) out.push(text.slice(last));
    return out;
  }
  function viewImage(src) {
    var v = h('div', { class: 'viewer', onclick: function () { v.remove(); } }, h('img', { src: src, alt: '' }),
      h('button', { class: 'ibtn', 'aria-label': 'Закрыть' }, icon('x')));
    document.body.append(v);
  }

  /* ================= состояние ================= */
  var S = { me: null, users: {}, chats: {}, msgs: {}, more: {}, typing: {}, active: null, q: '', remote: [], drafts: {}, reply: null, edit: null, attach: null, conn: 'online', pushed: false };
  var ui = {};
  var tmpN = 0;

  function mergeUsers(list) { (list || []).forEach(function (u) { S.users[u.id] = Object.assign(S.users[u.id] || {}, u); }); }
  function user(id) { return S.users[id] || { id: id, displayName: 'Неизвестный', username: '?' }; }
  function peerOf(c) { if (c.type !== 'private') return null; var id = c.members.filter(function (x) { return x !== S.me.id; })[0]; return user(id || S.me.id); }
  function lastMsg(c) { var a = S.msgs[c.id]; return a && a.length ? a[a.length - 1] : null; }
  function sortTs(c) { var m = lastMsg(c); return m ? m.ts : (c.lastTs || c.createdAt || 0); }
  function chatNameNode(c) {
    if (c.type === 'private') return nameNode(peerOf(c));
    if (c.type === 'saved') return h('span', { class: 'nm' }, h('span', { class: 't' }, 'Избранное'));
    return h('span', { class: 'nm' }, h('span', { class: 't' }, c.title));
  }
  function chatAvatar(c, size) {
    if (c.type === 'private') return avatar(peerOf(c), size);
    if (c.type === 'saved') return avatar({ id: 'saved' }, size, 'bookmark');
    return avatar(c, size, c.avatar ? null : null);
  }
  function unread(c) {
    var a = S.msgs[c.id] || [], n = 0;
    for (var i = 0; i < a.length; i++) { var m = a[i]; if (!m.service && m.from !== S.me.id && (m.read || []).indexOf(S.me.id) < 0) n++; }
    return n;
  }
  function statusOf(m, c) {
    if (m.failed) return 'failed';
    if (m.pending) return 'pending';
    if (c.type === 'saved' || c.type === 'channel') return null;
    var others = (m.read || []).filter(function (x) { return x !== S.me.id; });
    if (others.length) return 'read';
    if ((m.delivered || []).filter(function (x) { return x !== S.me.id; }).length) return 'delivered';
    return 'sent';
  }
  function isAdmin(c) { return c.admins && c.admins.indexOf(S.me.id) >= 0; }
  function canPost(c) { return c.type !== 'channel' || isAdmin(c); }
  function setSnapshot(s) {
    S.me = s.me; S.users = {}; mergeUsers(s.users); S.users[s.me.id] = s.me;
    S.chats = {}; s.chats.forEach(function (c) { S.chats[c.id] = c; });
    S.msgs = s.messages || {}; S.more = s.more || {};
  }
  function updateTitle() {
    var n = 0; Object.keys(S.chats).forEach(function (k) { n += unread(S.chats[k]); });
    document.title = (n ? '(' + n + ') ' : '') + 'Vortex';
  }

  /* ================= события ================= */
  function addMsg(m) {
    var arr = S.msgs[m.chatId] || (S.msgs[m.chatId] = []), i;
    for (i = 0; i < arr.length; i++) if (arr[i].id === m.id) { arr[i] = m; return; }
    if (m.cid) for (i = 0; i < arr.length; i++) if (arr[i].cid === m.cid && arr[i].tmp) { arr.splice(i, 1); break; }
    var at = arr.length;
    for (i = 0; i < arr.length; i++) if (arr[i].tmp) { at = i; break; }
    arr.splice(at, 0, m);
  }
  function setTyping(chatId, uid) {
    var t = S.typing[chatId] || (S.typing[chatId] = {});
    clearTimeout(t[uid]);
    t[uid] = setTimeout(function () { delete t[uid]; renderHead(); renderList(); }, 4500);
  }
  function typingNames(c) {
    var t = S.typing[c.id] || {}, ids = Object.keys(t);
    if (!ids.length) return '';
    if (c.type === 'private') return 'печатает…';
    return ids.map(function (i) { return user(i).displayName; }).join(', ') + ' печатает…';
  }
  function onEvent(ev) {
    if (!S.me) return;
    switch (ev.t) {
      case 'message': {
        mergeUsers(ev.users);
        if (ev.chat) S.chats[ev.chat.id] = ev.chat;
        var m = ev.msg, c = S.chats[m.chatId];
        if (!c) { resync(); return; }
        addMsg(m);
        if (S.typing[c.id] && S.typing[c.id][m.from]) { clearTimeout(S.typing[c.id][m.from]); delete S.typing[c.id][m.from]; }
        var mine = m.from === S.me.id;
        var visible = S.active === c.id && document.visibilityState === 'visible';
        if (!mine && !m.service && !visible) beep();
        renderList(); if (S.active === c.id) { renderMessages({ stick: mine }); renderHead(); }
        if (visible) markReadSoon();
        updateTitle();
        break;
      }
      case 'message_edit': {
        var arr = S.msgs[ev.msg.chatId] || [];
        for (var i = 0; i < arr.length; i++) if (arr[i].id === ev.msg.id) { arr[i] = ev.msg; break; }
        renderList(); renderMessages(); break;
      }
      case 'message_delete': {
        var a2 = S.msgs[ev.chatId] || [];
        S.msgs[ev.chatId] = a2.filter(function (x) { return x.id !== ev.id; });
        renderList(); renderMessages(); updateTitle(); break;
      }
      case 'read': case 'delivered': {
        (S.msgs[ev.chatId] || []).forEach(function (m) {
          if (typeof m.id === 'number' && m.id <= ev.upTo && m.from !== ev.userId) {
            var k = ev.t === 'read' ? 'read' : 'delivered';
            if ((m[k] = m[k] || []).indexOf(ev.userId) < 0) m[k].push(ev.userId);
            if (k === 'read' && (m.delivered = m.delivered || []).indexOf(ev.userId) < 0) m.delivered.push(ev.userId);
          }
        });
        renderList(); renderMessages(); updateTitle(); break;
      }
      case 'typing': if (S.chats[ev.chatId]) { setTyping(ev.chatId, ev.userId); renderHead(); renderList(); } break;
      case 'user': {
        S.users[ev.user.id] = Object.assign(S.users[ev.user.id] || {}, ev.user);
        if (ev.user.id === S.me.id) S.me = Object.assign(S.me, ev.user);
        renderList(); renderHead(); renderMessages(); renderTop(); break;
      }
      case 'presence': {
        var u = S.users[ev.userId]; if (u) { u.online = ev.online; u.lastSeen = ev.lastSeen; }
        renderHead(); break;
      }
      case 'chat': mergeUsers(ev.users); S.chats[ev.chat.id] = ev.chat; renderList(); renderHead(); break;
      case 'chat_removed': delete S.chats[ev.chatId]; delete S.msgs[ev.chatId]; if (S.active === ev.chatId) location.hash = ''; renderList(); break;
      case 'badge':
        if (ev.on) { badgePop('Вам выдали галочку!', 'от @' + ev.by.username); } else toast('С вас сняли галочку');
        break;
    }
  }
  function onConn(st) {
    S.conn = st;
    if (st === 'storage_full') toast('Память браузера заполнена — сообщения могут не сохраняться', 5000);
    renderTop();
  }
  function resync() {
    if (!S.me) return Promise.resolve();
    return A.call('snapshot').then(function (s) {
      var pend = {};
      Object.keys(S.msgs).forEach(function (k) { pend[k] = (S.msgs[k] || []).filter(function (m) { return m.tmp; }); });
      setSnapshot(s);
      Object.keys(pend).forEach(function (k) { if (S.msgs[k] && pend[k].length) S.msgs[k] = S.msgs[k].concat(pend[k]); });
      renderList(); renderTop(); if (S.active) { if (S.chats[S.active]) { renderHead(); renderMessages(); markReadSoon(); } else location.hash = ''; }
      updateTitle();
    }).catch(function () {});
  }
  var readTimer = null;
  function markReadSoon() {
    clearTimeout(readTimer);
    readTimer = setTimeout(function () {
      var c = S.chats[S.active];
      if (!c || document.visibilityState !== 'visible') return;
      var changed = false;
      (S.msgs[c.id] || []).forEach(function (m) {
        if (!m.service && m.from !== S.me.id && (m.read = m.read || []).indexOf(S.me.id) < 0 && typeof m.id === 'number') { m.read.push(S.me.id); changed = true; }
      });
      if (changed) { A.call('markRead', { chatId: c.id }).catch(function () {}); renderList(); updateTitle(); }
    }, 150);
  }
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible') markReadSoon(); });

  /* ================= вход / регистрация ================= */
  function showAuth(errMsg, tab) {
    S.me = null; document.body.dataset.view = '';
    document.title = 'Vortex Messenger';
    var st = { tab: tab || 'login', err: errMsg || '', busy: false, pw: false, v: { username: '', displayName: '', password: '', bio: '' } };
    function draw() {
      var reg = st.tab === 'reg';
      function inp(key, label, hint, type, extra) {
        var props = { class: 'inp', value: st.v[key], autocomplete: extra && extra.ac || 'off', autocapitalize: 'none', autocorrect: 'off', spellcheck: 'false',
          oninput: function (e) { st.v[key] = e.target.value; }, onkeydown: function (e) { if (e.key === 'Enter') submit(); } };
        props.type = type || 'text';
        var input = h('input', props);
        var box = key === 'password'
          ? h('div', { class: 'pw' }, input, h('button', { type: 'button', 'aria-label': 'Показать пароль', onclick: function () { st.pw = !st.pw; input.type = st.pw ? 'text' : 'password'; btn.replaceChildren(icon(st.pw ? 'eyeoff' : 'eye')); } }))
          : input;
        var btn = key === 'password' ? box.lastChild : null; if (btn) btn.append(icon(st.pw ? 'eyeoff' : 'eye'));
        if (key === 'password') input.type = st.pw ? 'text' : 'password';
        return h('div', { class: 'field' }, h('label', null, label, hint ? h('small', null, ' ' + hint) : null), box);
      }
      var submitBtn = h('button', { class: 'btn', type: 'button', onclick: submit, disabled: st.busy },
        st.busy ? h('span', { class: 'spin' }) : null, reg ? 'Создать аккаунт' : 'Войти', st.busy ? null : icon('arrow', 20));
      root.replaceChildren(h('div', { class: 'auth' }, h('div', { class: 'auth-card' },
        h('img', { class: 'auth-logo', src: 'logo.png', alt: 'Vortex' }),
        h('h1', null, 'Vortex'), h('div', { class: 'sub' }, 'Современный мессенджер'),
        h('div', { class: 'tabs' },
          h('button', { class: st.tab === 'login' ? 'on' : '', onclick: function () { st.tab = 'login'; st.err = ''; draw(); } }, icon('login', 20), 'Вход'),
          h('button', { class: reg ? 'on' : '', onclick: function () { st.tab = 'reg'; st.err = ''; draw(); } }, icon('userplus', 20), 'Регистрация')),
        A.mode === 'local' ? h('div', { class: 'note' }, 'Сервер не найден — включён локальный режим: аккаунты и чаты хранятся только в этом браузере. ',
          h('button', { onclick: function () { location.reload(); } }, 'Проверить сервер снова')) : null,
        st.err ? h('div', { class: 'err', role: 'alert' }, st.err) : null,
        inp('username', 'Username', reg ? '(латиница, нельзя изменить)' : '', 'text', { ac: 'username' }),
        reg ? inp('displayName', 'Отображаемое имя', '', 'text', { ac: 'nickname' }) : null,
        inp('password', 'Пароль', reg ? '(минимум 6 символов)' : '', 'password', { ac: reg ? 'new-password' : 'current-password' }),
        reg ? inp('bio', 'О себе', '(необязательно)', 'text') : null,
        submitBtn)));
    }
    function submit() {
      if (st.busy) return;
      var v = st.v, reg = st.tab === 'reg';
      v.username = v.username.trim();
      if (!v.username) { st.err = 'Введи username'; return draw(); }
      if (reg && !Core.USERNAME_RE.test(v.username)) { st.err = 'Username: только латиница, цифры и _, от 3 до 32 символов, первый символ — буква'; return draw(); }
      if (!v.password) { st.err = 'Введи пароль'; return draw(); }
      if (reg && v.password.length < 6) { st.err = 'Пароль должен быть не короче 6 символов'; return draw(); }
      st.busy = true; st.err = ''; draw();
      (reg ? A.register(v) : A.login(v)).then(function () { return A.call('snapshot'); }).then(function (snap) { enter(snap); })
        .catch(function (e) { st.busy = false; st.err = e.message || 'Что-то пошло не так'; draw(); });
    }
    draw();
  }

  /* ================= каркас приложения ================= */
  function enter(snap) {
    setSnapshot(snap);
    S.active = null; S.q = ''; S.remote = []; S.typing = {};
    A.connect();
    buildShell();
    route();
    updateTitle();
  }
  function buildShell() {
    ui.top = h('div', { class: 'top' });
    ui.search = h('input', { class: 'inp', placeholder: 'Поиск чатов и людей', autocomplete: 'off', autocapitalize: 'none', oninput: onSearch });
    ui.list = h('div', { class: 'list' });
    ui.main = h('div', { class: 'main' });
    var side = h('div', { class: 'side' }, ui.top,
      h('div', { class: 'search' }, icon('search', 18), ui.search), ui.list,
      h('button', { class: 'fab', 'aria-label': 'Новый чат', onclick: newChatSheet }, icon('edit', 24)));
    root.replaceChildren(h('div', { class: 'app' }, side, ui.main));
    renderTop(); renderList();
  }
  function renderTop() {
    if (!ui.top || !S.me) return;
    var sub = S.conn === 'connecting' ? ['Подключение…', 'warn'] : A.mode === 'local' ? ['Локальный режим', 'warn'] : ['@' + S.me.username, ''];
    ui.top.replaceChildren(
      h('button', { class: 'ibtn', 'aria-label': 'Профиль', onclick: profileSheet }, avatar(S.me, 40)),
      h('div', { class: 'ttl' }, h('b', null, nameNode(S.me)), h('small', { class: sub[1] }, sub[0])),
      h('button', { class: 'ibtn', 'aria-label': 'Новый чат', onclick: newChatSheet }, icon('users', 22)));
  }
  var searchTimer = null, searchSeq = 0;
  function onSearch() {
    S.q = ui.search.value.trim();
    renderList();
    clearTimeout(searchTimer);
    if (!S.q) { S.remote = []; renderList(); return; }
    var my = ++searchSeq;
    searchTimer = setTimeout(function () {
      A.call('searchUsers', { q: S.q }).then(function (r) {
        if (my !== searchSeq) return;
        mergeUsers(r.users); S.remote = r.users; renderList();
      }).catch(function () {});
    }, 250);
  }
  function previewOf(c) {
    var typ = typingNames(c);
    if (typ) return h('span', { class: 'pv typ' }, typ);
    var m = lastMsg(c);
    if (!m) return h('span', { class: 'pv' }, c.type === 'saved' ? 'Заметки для себя' : 'Нет сообщений');
    var body = m.service ? m.text : (m.image ? '📷 ' + (m.text || 'Фото') : m.text);
    var pre = '';
    if (!m.service && m.from === S.me.id && c.type !== 'saved') pre = 'Вы: ';
    else if (!m.service && c.type === 'group' && m.from !== S.me.id) pre = user(m.from).displayName + ': ';
    return h('span', { class: 'pv' }, pre + body);
  }
  function chatItem(c) {
    var m = lastMsg(c), n = unread(c), st = m && m.from === S.me.id && !m.service ? statusOf(m, c) : null;
    return h('button', { class: 'item' + (S.active === c.id ? ' on' : ''), onclick: function () { openChat(c.id); } },
      chatAvatar(c, 52),
      h('div', { class: 'body' },
        h('div', { class: 'l1' }, chatNameNode(c), h('span', { class: 'tm' }, st ? tick(st) : null, m ? listTime(m.ts) : '')),
        h('div', { class: 'l2' }, previewOf(c), n ? h('span', { class: 'cnt' }, n > 99 ? '99+' : n) : null)));
  }
  function renderList() {
    if (!ui.list || !S.me) return;
    var q = S.q.replace(/^@/, '').toLowerCase();
    var chats = Object.keys(S.chats).map(function (k) { return S.chats[k]; }).filter(function (c) {
      if (!q) return true;
      var t = c.type === 'private' ? peerOf(c).displayName + ' ' + peerOf(c).username : c.type === 'saved' ? 'избранное saved' : c.title;
      return t.toLowerCase().indexOf(q) >= 0;
    }).sort(function (a, b) { return sortTs(b) - sortTs(a); });
    var frag = document.createDocumentFragment();
    chats.forEach(function (c) { frag.append(chatItem(c)); });
    if (q) {
      var people = S.remote.filter(function (u) { return u.id !== S.me.id; });
      if (people.length) {
        frag.append(h('div', { class: 'sec-t' }, 'Люди'));
        people.forEach(function (u) {
          frag.append(h('button', { class: 'item', onclick: function () { startPrivate(u.id); } }, avatar(u, 48),
            h('div', { class: 'body' }, h('div', { class: 'l1' }, nameNode(u)), h('div', { class: 'l2' }, h('span', { class: 'pv' }, '@' + u.username)))));
        });
      } else if (!chats.length) frag.append(h('div', { class: 'lempty' }, 'Ничего не найдено'));
    } else if (!chats.length) frag.append(h('div', { class: 'lempty' }, 'Пока нет чатов. Найди людей через поиск или нажми ✏️'));
    ui.list.replaceChildren(frag);
  }

  /* ================= маршрутизация ================= */
  function openChat(id) {
    if (S.active) location.replace('#/chat/' + encodeURIComponent(id));
    else { S.pushed = true; location.hash = '#/chat/' + encodeURIComponent(id); }
  }
  function goBack() {
    if (S.pushed) { S.pushed = false; history.back(); } else location.hash = '';
  }
  function startPrivate(userId) {
    A.call('openPrivate', { userId: userId }).then(function (r) {
      mergeUsers(r.users); S.chats[r.chat.id] = r.chat;
      if (!S.msgs[r.chat.id]) S.msgs[r.chat.id] = [];
      ui.search.value = ''; S.q = ''; S.remote = [];
      renderList(); openChat(r.chat.id);
    }).catch(function (e) { toast(e.message); });
  }
  function route() {
    if (!S.me) return;
    var m = location.hash.match(/^#\/chat\/(.+)$/), id = m && decodeURIComponent(m[1]);
    saveDraft();
    if (id && S.chats[id]) {
      if (S.active !== id) { S.active = id; S.reply = null; S.edit = null; clearAttach(); buildChat(); }
      document.body.dataset.view = 'chat';
      markReadSoon();
    } else {
      S.active = null; S.pushed = false; document.body.dataset.view = 'list';
      if (ui.main) ui.main.replaceChildren(h('div', { class: 'empty empty-main' }, h('img', { src: 'logo.png', alt: '' }), h('div', null, 'Выбери чат, чтобы начать общение')));
    }
    renderList();
  }
  window.addEventListener('hashchange', route);
  function saveDraft() {
    if (S.active && ui.input) S.drafts[S.active] = ui.input.value;
  }

  /* ================= экран чата ================= */
  function buildChat() {
    var c = S.chats[S.active];
    ui.head = h('div', { class: 'chead' });
    ui.msgs = h('div', { class: 'msgs' });
    ui.msgs.addEventListener('scroll', function () { ui.stick = ui.msgs.scrollHeight - ui.msgs.scrollTop - ui.msgs.clientHeight < 140; });
    ui.stick = true;
    ui.bar = h('div');
    ui.input = null;
    ui.wrap = h('div', { class: 'composer-wrap' });
    ui.main.replaceChildren(ui.head, ui.msgs, ui.wrap);
    renderHead(); renderMessages({ stick: true }); renderComposer(c);
  }
  function headStatus(c) {
    var typ = typingNames(c);
    if (typ) return [typ, 'on'];
    if (c.type === 'saved') return ['только для тебя', ''];
    if (c.type === 'private') {
      var p = peerOf(c);
      if (p.bot) return ['бот', ''];
      if (A.mode === 'local') return ['@' + p.username, ''];
      return p.online ? ['в сети', 'on'] : [seen(p.lastSeen), ''];
    }
    return [c.type === 'channel' ? plural(c.members.length, 'подписчик', 'подписчика', 'подписчиков') : plural(c.members.length, 'участник', 'участника', 'участников'), ''];
  }
  function renderHead() {
    var c = S.chats[S.active]; if (!c || !ui.head) return;
    var st = headStatus(c), p = peerOf(c);
    ui.head.replaceChildren(
      h('button', { class: 'ibtn back', 'aria-label': 'Назад', onclick: goBack }, icon('back')),
      h('button', { class: 'who', onclick: function () { chatInfo(c); } }, chatAvatar(c, 42),
        h('div', { class: 'tx' }, chatNameNode(c), h('small', { class: st[1] }, st[0]))),
      p && !p.bot && p.id !== S.me.id ? h('button', { class: 'ibtn', 'aria-label': 'Позвонить', onclick: function () { startCall(p); } }, icon('phone')) : null,
      h('button', { class: 'ibtn', 'aria-label': 'Информация', onclick: function () { chatInfo(c); } }, icon('dots')));
  }
  function chatInfo(c) {
    if (c.type === 'private') return userSheet(peerOf(c).id);
    if (c.type === 'saved') return;
    groupSheet(c);
  }
  function quoteOf(m, c) {
    var r = (S.msgs[c.id] || []).filter(function (x) { return x.id === m.replyTo; })[0];
    if (!r) return h('div', { class: 'quote' }, h('span', null, 'Сообщение удалено'));
    return h('div', { class: 'quote' }, h('b', null, user(r.from).displayName), h('span', null, r.image && !r.text ? '📷 Фото' : r.text));
  }
  function bubble(m, c, prev) {
    if (m.service) return h('div', { class: 'svc' }, m.text);
    var mine = m.from === S.me.id, u = user(m.from);
    var st = mine ? statusOf(m, c) : null;
    var showName = !mine && c.type !== 'private' && c.type !== 'saved' && (!prev || prev.from !== m.from);
    var img = null;
    if (m.image) {
      var src = A.media(m.image);
      img = h('img', { class: 'pic', src: src, alt: 'Фото', loading: 'lazy', onclick: function (e) { e.stopPropagation(); viewImage(src); } });
      img.onload = function () { if (ui.stick && ui.msgs) ui.msgs.scrollTop = ui.msgs.scrollHeight; };
    }
    var b = h('div', { class: 'bub' + (m.pending ? ' pend' : '') + (m.failed ? ' failed' : ''), onclick: function () { msgActions(m, c); } },
      showName ? h('span', { class: 'from', style: { color: GRADS[hashOf(u.id) % GRADS.length][0] } }, nameNode(u)) : null,
      m.replyTo ? quoteOf(m, c) : null, img,
      m.text ? h('span', { class: 'txt' }, linkify(m.text)) : null,
      h('span', { class: 'meta' }, m.edited ? 'изм.' : '', hhmm(m.ts), st ? tick(st) : null));
    return h('div', { class: 'row ' + (mine ? 'mine' : 'other') + (prev && prev.from === m.from ? '' : ' gap') }, b);
  }
  function renderMessages(opts) {
    var box = ui.msgs, c = S.chats[S.active];
    if (!box || !c) return;
    opts = opts || {};
    var near = box.scrollHeight - box.scrollTop - box.clientHeight < 140;
    var prevH = box.scrollHeight, prevTop = box.scrollTop;
    var arr = S.msgs[c.id] || [], frag = document.createDocumentFragment();
    if (S.more[c.id]) frag.append(h('button', { class: 'more', onclick: loadMore }, 'Загрузить ещё'));
    var lastDay = '', prev = null;
    arr.forEach(function (m) {
      var d = dayKey(m.ts);
      if (d !== lastDay) { frag.append(h('div', { class: 'day' }, dayLabel(m.ts))); lastDay = d; prev = null; }
      frag.append(bubble(m, c, prev)); prev = m.service ? null : m;
    });
    if (!arr.length) frag.append(h('div', { class: 'svc' }, c.type === 'saved' ? 'Здесь можно хранить заметки' : 'Сообщений пока нет. Напиши первым 👋'));
    box.replaceChildren(frag);
    if (opts.prepend) box.scrollTop = box.scrollHeight - prevH + prevTop;
    else if (opts.stick || near) box.scrollTop = box.scrollHeight;
    else box.scrollTop = prevTop;
  }
  function loadMore() {
    var c = S.chats[S.active], arr = S.msgs[c.id] || [];
    var first = arr.filter(function (m) { return typeof m.id === 'number'; })[0];
    if (!first) return;
    A.call('history', { chatId: c.id, before: first.id }).then(function (r) {
      S.msgs[c.id] = r.messages.concat(arr); S.more[c.id] = r.more;
      renderMessages({ prepend: true });
    }).catch(function (e) { toast(e.message); });
  }

  /* ---------- композер ---------- */
  var typingSent = 0;
  function renderComposer(c) {
    ui.wrap.replaceChildren();
    ui.input = null;
    if (!canPost(c)) { ui.wrap.append(h('div', { class: 'ro' }, 'В канале писать могут только администраторы')); return; }
    ui.bar = h('div');
    var ta = h('textarea', { rows: 1, placeholder: 'Сообщение', 'aria-label': 'Сообщение', autocomplete: 'off',
      oninput: function () { grow(); S.drafts[c.id] = ta.value; updateSend(); sendTyping(); },
      onkeydown: function (e) {
        if (e.key === 'Enter' && !e.shiftKey && window.matchMedia('(pointer:fine)').matches) { e.preventDefault(); send(); }
        if (e.key === 'Escape' && (S.reply || S.edit)) { S.reply = null; S.edit = null; ta.value = ''; renderBar(); updateSend(); }
      } });
    var sendBtn = h('button', { class: 'send', 'aria-label': 'Отправить', onclick: send, disabled: true }, icon('send', 20));
    ui.input = ta; ui.sendBtn = sendBtn;
    ta.value = S.drafts[c.id] || '';
    ui.wrap.append(ui.bar, h('div', { class: 'composer' },
      h('button', { class: 'ibtn', 'aria-label': 'Прикрепить фото', onclick: attachPick }, icon('clip')), ta, sendBtn));
    renderBar(); grow(); updateSend();
    if (window.matchMedia('(pointer:fine)').matches) setTimeout(function () { ta.focus(); }, 30);
  }
  function grow() { var t = ui.input; if (!t) return; t.style.height = 'auto'; t.style.height = Math.min(t.scrollHeight, 140) + 'px'; }
  function updateSend() { if (ui.sendBtn) ui.sendBtn.disabled = !(ui.input.value.trim() || S.attach); }
  function sendTyping() {
    var t = Date.now();
    if (t - typingSent < 2500 || !S.active || (ui.input.value || '').charAt(0) === '/') return;
    typingSent = t; A.call('typing', { chatId: S.active }).catch(function () {});
  }
  function renderBar() {
    if (!ui.bar) return;
    ui.bar.replaceChildren();
    function row(content, cancel) {
      ui.bar.append(h('div', { class: 'bar' }, content, h('button', { class: 'ibtn', 'aria-label': 'Отмена', onclick: cancel }, icon('x', 18))));
    }
    if (S.edit) row(h('div', { class: 'tx' }, h('b', null, 'Редактирование'), h('span', null, S.edit.text)), function () { S.edit = null; ui.input.value = ''; renderBar(); updateSend(); grow(); });
    else if (S.reply) row(h('div', { class: 'tx' }, h('b', null, 'Ответ ' + user(S.reply.from).displayName), h('span', null, S.reply.image && !S.reply.text ? '📷 Фото' : S.reply.text)), function () { S.reply = null; renderBar(); });
    if (S.attach) row([h('img', { src: S.attach.url, alt: '' }), h('div', { class: 'tx' }, h('b', null, 'Фото'), h('span', null, 'Можно добавить подпись'))], function () { clearAttach(); renderBar(); updateSend(); });
  }
  function clearAttach() { if (S.attach) { try { URL.revokeObjectURL(S.attach.url); } catch (e) {} } S.attach = null; }
  function attachPick() {
    pickImage(function (file) {
      var cfg = A.maxImage();
      resizeImage(file, cfg.dim, cfg.q, false).then(function (blob) {
        clearAttach(); S.attach = { blob: blob, url: URL.createObjectURL(blob) }; renderBar(); updateSend(); ui.input.focus();
      }).catch(function (e) { toast(e.message); });
    });
  }
  var CMD_RE = Core.COMMAND_RE;
  function handleCommand(r) {
    if (r.me) { S.me = Object.assign(S.me, r.me); S.users[S.me.id] = S.me; }
    if (r.badge) {
      var u = r.badge.user; S.users[u.id] = Object.assign(S.users[u.id] || {}, u);
      if (r.badge.on) badgePop('Поздравляем, вы выдали галочку', '@' + u.username);
      else toast('Галочка снята у @' + u.username);
      renderList(); renderMessages(); renderHead();
    } else if (r.toast) toast(r.toast, 4200);
    renderTop();
  }
  function send() {
    var c = S.chats[S.active]; if (!c || !ui.input) return;
    var text = ui.input.value.trim();
    if (!text && !S.attach) return;
    var clear = function () { ui.input.value = ''; S.drafts[c.id] = ''; grow(); updateSend(); };
    if (S.edit) {
      var em = S.edit; if (!text) return;
      S.edit = null; clear(); renderBar();
      A.call('editMessage', { chatId: c.id, id: em.id, text: text }).then(function (r) {
        var arr = S.msgs[c.id] || []; for (var i = 0; i < arr.length; i++) if (arr[i].id === r.msg.id) arr[i] = r.msg;
        renderMessages(); renderList();
      }).catch(function (e) { toast(e.message); });
      return;
    }
    if (!S.attach && CMD_RE.test(text)) {
      clear();
      A.call('command', { text: text }).then(function (r) { if (r.handled) handleCommand(r); else sendNow(c, text); }).catch(function (e) { toast(e.message); });
      return;
    }
    sendNow(c, text); clear();
  }
  function sendNow(c, text) {
    var temp = { id: 't' + (++tmpN), cid: 'c' + Date.now() + '_' + tmpN, tmp: true, pending: true, chatId: c.id, from: S.me.id, text: text, image: S.attach ? S.attach.url : null,
      replyTo: S.reply ? S.reply.id : null, ts: Date.now(), delivered: [], read: [], edited: false, _blob: S.attach ? S.attach.blob : null };
    S.attach = null; S.reply = null; renderBar(); updateSend();
    (S.msgs[c.id] = S.msgs[c.id] || []).push(temp);
    renderMessages({ stick: true }); renderList();
    doSend(temp);
  }
  function doSend(temp) {
    var c = S.chats[temp.chatId];
    temp.pending = true; temp.failed = false;
    Promise.resolve(temp._blob ? A.upload(temp._blob) : null).then(function (url) {
      return A.call('sendMessage', { chatId: temp.chatId, text: temp.text, image: url || undefined, replyTo: typeof temp.replyTo === 'number' ? temp.replyTo : undefined, cid: temp.cid });
    }).then(function (r) {
      if (temp.image && /^blob:/.test(temp.image)) { try { URL.revokeObjectURL(temp.image); } catch (e) {} }
      addMsg(r.msg);
    }).catch(function (e) {
      temp.pending = false; temp.failed = true; toast(e.message || 'Не удалось отправить');
    }).then(function () { if (c) { renderMessages(); renderList(); } });
  }

  /* ---------- действия с сообщением ---------- */
  function msgActions(m, c) {
    openSheet(function (close) {
      function act(ic, label, fn, danger) { return h('button', { class: 'act' + (danger ? ' danger' : ''), onclick: function () { close(); fn(); } }, icon(ic, 22), label); }
      var mine = m.from === S.me.id, list = [];
      if (m.failed) {
        list.push(act('retry', 'Повторить отправку', function () { doSend(m); renderMessages(); }));
        list.push(act('trash', 'Удалить', function () { S.msgs[c.id] = S.msgs[c.id].filter(function (x) { return x !== m; }); renderMessages(); renderList(); }, true));
        return list;
      }
      if (m.pending) return [h('div', { class: 'ro' }, 'Отправляется…')];
      if (canPost(c)) list.push(act('reply', 'Ответить', function () { S.reply = m; S.edit = null; renderBar(); updateSend(); if (ui.input) ui.input.focus(); }));
      if (m.text) list.push(act('copy', 'Копировать', function () {
        var done = function () { toast('Скопировано', 1500); };
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(m.text).then(done, function () { toast('Не удалось скопировать'); });
        else { var t = h('textarea', null); t.value = m.text; document.body.append(t); t.select(); try { document.execCommand('copy'); done(); } catch (e) {} t.remove(); }
      }));
      if (mine && m.text) list.push(act('edit', 'Изменить', function () { S.edit = m; S.reply = null; ui.input.value = m.text; renderBar(); grow(); updateSend(); ui.input.focus(); }));
      if (mine || ((c.type === 'group' || c.type === 'channel') && isAdmin(c))) list.push(act('trash', 'Удалить', function () {
        A.call('deleteMessage', { chatId: c.id, id: m.id }).then(function () {
          S.msgs[c.id] = S.msgs[c.id].filter(function (x) { return x.id !== m.id; }); renderMessages(); renderList();
        }).catch(function (e) { toast(e.message); });
      }, true));
      return list;
    });
  }

  /* ================= листы ================= */
  function sheetTitle(text, close) { return h('h3', null, text, h('button', { class: 'ibtn x', 'aria-label': 'Закрыть', onclick: close }, icon('x'))); }

  function picker(opts) { // поиск людей
    var res = h('div'), seq = 0, timer = null;
    var input = h('input', { class: 'inp', placeholder: opts.placeholder || 'Поиск по @username или имени', autocapitalize: 'none', autocomplete: 'off',
      oninput: function () {
        clearTimeout(timer); var q = input.value.trim(), my = ++seq;
        if (!q) { res.replaceChildren(); return; }
        timer = setTimeout(function () {
          A.call('searchUsers', { q: q }).then(function (r) {
            if (my !== seq) return;
            mergeUsers(r.users);
            var list = r.users.filter(function (u) { return !(opts.exclude && opts.exclude(u)); });
            res.replaceChildren.apply(res, list.length ? list.map(function (u) {
              return h('button', { class: 'item', style: { padding: '8px 4px' }, onclick: function () { opts.onPick(u); input.value = ''; res.replaceChildren(); } },
                avatar(u, 44), h('div', { class: 'body' }, h('div', { class: 'l1' }, nameNode(u)), h('div', { class: 'l2' }, h('span', { class: 'pv' }, '@' + u.username))));
            }) : [h('div', { class: 'lempty' }, 'Никого не нашли')]);
          }).catch(function () {});
        }, 250);
      } });
    return { el: h('div', null, h('div', { class: 'field' }, input), res), input: input };
  }

  function newChatSheet() {
    openSheet(function (close) {
      var p = picker({ onPick: function (u) { close(); startPrivate(u.id); }, exclude: function (u) { return u.id === S.me.id; } });
      setTimeout(function () { p.input.focus(); }, 50);
      return [sheetTitle('Новый чат', close),
        h('button', { class: 'act', onclick: function () { close(); groupCreateSheet('group'); } }, icon('users'), 'Новая группа'),
        h('button', { class: 'act', onclick: function () { close(); groupCreateSheet('channel'); } }, icon('mega'), 'Новый канал'),
        h('div', { class: 'sec-t', style: { padding: '12px 0 6px' } }, 'Написать человеку'), p.el];
    });
  }
  function groupCreateSheet(type) {
    var members = [];
    openSheet(function (close) {
      var title = h('input', { class: 'inp', placeholder: type === 'channel' ? 'Название канала' : 'Название группы', maxlength: 60 });
      var chips = h('div', { class: 'chips' });
      function drawChips() {
        chips.replaceChildren.apply(chips, members.map(function (u) {
          return h('span', { class: 'chip' }, u.displayName, h('button', { 'aria-label': 'Убрать', onclick: function () { members = members.filter(function (x) { return x.id !== u.id; }); drawChips(); } }, icon('x', 12)));
        }));
      }
      var p = picker({ placeholder: 'Добавить участников', onPick: function (u) { members.push(u); drawChips(); },
        exclude: function (u) { return u.id === S.me.id || members.some(function (x) { return x.id === u.id; }); } });
      var btn = h('button', { class: 'btn', style: { marginTop: '12px' }, onclick: function () {
        var t = title.value.trim(); if (!t) { toast('Введи название'); return; }
        btn.disabled = true;
        A.call('createGroup', { type: type, title: t, memberIds: members.map(function (u) { return u.id; }) }).then(function (r) {
          mergeUsers(r.users); S.chats[r.chat.id] = r.chat; if (!S.msgs[r.chat.id]) S.msgs[r.chat.id] = [];
          close(); renderList(); openChat(r.chat.id);
        }).catch(function (e) { btn.disabled = false; toast(e.message); });
      } }, 'Создать');
      return [sheetTitle(type === 'channel' ? 'Новый канал' : 'Новая группа', close), h('div', { class: 'field' }, title), chips, p.el, btn];
    });
  }
  function groupSheet(c) {
    openSheet(function (close) {
      var memberRows = c.members.map(function (id) {
        var u = user(id);
        return h('button', { class: 'item', style: { padding: '8px 4px' }, onclick: function () { close(); userSheet(id); } }, avatar(u, 42),
          h('div', { class: 'body' }, h('div', { class: 'l1' }, nameNode(u), c.admins.indexOf(id) >= 0 ? h('span', { class: 'tm' }, c.owner === id ? 'владелец' : 'админ') : null),
            h('div', { class: 'l2' }, h('span', { class: 'pv' }, '@' + u.username))));
      });
      var rows = [h('div', { class: 'prof' }, avatar(c, 84), h('div', { class: 'nm' }, c.title),
        h('div', { class: 'un' }, c.type === 'channel' ? plural(c.members.length, 'подписчик', 'подписчика', 'подписчиков') : plural(c.members.length, 'участник', 'участника', 'участников')))];
      if (isAdmin(c)) rows.push(h('button', { class: 'act', onclick: function () { close(); addMembersSheet(c); } }, icon('userplus'), 'Добавить участников'));
      rows.push(h('div', { class: 'sec-t', style: { padding: '8px 0 4px' } }, 'Участники'), memberRows);
      rows.push(h('button', { class: 'act danger', onclick: function () {
        if (!confirm('Покинуть «' + c.title + '»?')) return;
        A.call('leaveChat', { chatId: c.id }).then(function () { close(); }).catch(function (e) { toast(e.message); });
      } }, icon('logout'), 'Покинуть'));
      return [sheetTitle('Информация', close), rows];
    });
  }
  function addMembersSheet(c) {
    var picked = [];
    openSheet(function (close) {
      var chips = h('div', { class: 'chips' });
      function drawChips() {
        chips.replaceChildren.apply(chips, picked.map(function (u) {
          return h('span', { class: 'chip' }, u.displayName, h('button', { onclick: function () { picked = picked.filter(function (x) { return x.id !== u.id; }); drawChips(); } }, icon('x', 12)));
        }));
      }
      var p = picker({ onPick: function (u) { picked.push(u); drawChips(); },
        exclude: function (u) { return c.members.indexOf(u.id) >= 0 || picked.some(function (x) { return x.id === u.id; }); } });
      return [sheetTitle('Добавить участников', close), chips, p.el,
        h('button', { class: 'btn', onclick: function () {
          if (!picked.length) return;
          A.call('addMembers', { chatId: c.id, memberIds: picked.map(function (u) { return u.id; }) }).then(function (r) { mergeUsers(r.users); S.chats[r.chat.id] = r.chat; close(); renderHead(); toast('Добавлено'); }).catch(function (e) { toast(e.message); });
        } }, 'Добавить')];
    });
  }
  function toggleVerified(id, close) {
    var u = user(id);
    A.call('setVerified', { id: id, on: !u.verified }).then(function (r) {
      S.users[id] = Object.assign(S.users[id] || {}, r.user);
      if (id === S.me.id) S.me = Object.assign(S.me, r.user);
      if (close) close();
      if (r.on) badgePop('Поздравляем, вы выдали галочку', '@' + r.user.username); else toast('Галочка снята у @' + r.user.username);
      renderList(); renderHead(); renderMessages(); renderTop();
    }).catch(function (e) { toast(e.message); });
  }
  function userSheet(id) {
    openSheet(function (close) {
      var u = user(id), me = id === S.me.id, body = [];
      var st = u.bot ? 'бот' : A.mode === 'local' ? '' : (u.online ? 'в сети' : seen(u.lastSeen));
      body.push(h('div', { class: 'prof' }, avatar(u, 96), h('div', { class: 'nm' }, nameNode(u)),
        h('div', { class: 'un' }, '@' + u.username + (st ? ' · ' + st : '')), u.bio ? h('div', { class: 'bio' }, u.bio) : null));
      if (!me) {
        body.push(h('button', { class: 'btn', onclick: function () { close(); startPrivate(id); } }, icon('send', 20), 'Написать'));
      }
      if (S.me.creator) {
        body.push(h('button', { class: 'btn sec', style: { marginTop: '10px' }, onclick: function () { toggleVerified(id, close); } },
          u.verified ? icon('x', 20) : badge(20), u.verified ? 'Снять галочку' : 'Выдать галочку'));
      }
      return [sheetTitle(me ? 'Профиль' : 'Контакт', close), body];
    });
  }
  function profileSheet() {
    openSheet(function (close) {
      var name = h('input', { class: 'inp', value: S.me.displayName, maxlength: 40 });
      var bio = h('input', { class: 'inp', value: S.me.bio || '', maxlength: 200, placeholder: 'О себе' });
      var av = h('div', { style: { position: 'relative', width: '96px', margin: '0 auto 12px', cursor: 'pointer' }, onclick: changeAvatar }, avatar(S.me, 96),
        h('span', { class: 'ic', style: { position: 'absolute', right: '-2px', bottom: '-2px', width: '32px', height: '32px', borderRadius: '50%', background: 'var(--grad)', color: '#fff', border: '3px solid var(--panel)' } }, icon('camera', 16)));
      function changeAvatar() {
        pickImage(function (file) {
          resizeImage(file, 320, 0.85, true).then(function (blob) { return A.upload(blob); })
            .then(function (url) { return A.call('updateProfile', { avatar: url }); })
            .then(function (r) { S.me = Object.assign(S.me, r.me); S.users[S.me.id] = S.me; av.firstChild.replaceWith(avatar(S.me, 96)); renderTop(); renderList(); toast('Фото профиля обновлено', 1800); })
            .catch(function (e) { toast(e.message); });
        });
      }
      var keyInp = h('input', { class: 'inp', placeholder: 'Ключ создателя', autocapitalize: 'none', autocomplete: 'off', type: 'password' });
      var creatorBox;
      if (S.me.creator) {
        creatorBox = h('div', { class: 'note' }, h('b', null, 'Режим создателя включён. '), 'Выдавать галочки можно из профиля любого человека или командой ',
          h('code', null, '/verify @ник'), ' в чате (', h('code', null, '/unverify @ник'), ' — снять).',
          h('div', { style: { marginTop: '10px', display: 'flex', gap: '8px', flexWrap: 'wrap' } },
            h('button', { class: 'btn sec small', onclick: function () { close(); toggleVerified(S.me.id); } }, S.me.verified ? 'Снять галочку с себя' : 'Выдать галочку себе'),
            h('button', { class: 'btn sec small', onclick: function () { A.call('command', { text: '/creator off' }).then(function (r) { handleCommand(r); close(); }); } }, 'Выключить')));
      } else {
        creatorBox = h('div', { class: 'field' }, h('label', null, 'Режим создателя ', h('small', null, '(для выдачи галочек)')),
          h('div', { style: { display: 'flex', gap: '8px' } }, keyInp, h('button', { class: 'btn small', style: { flexShrink: 0 }, onclick: function () {
            if (!keyInp.value.trim()) return;
            A.call('command', { text: '/creator ' + keyInp.value.trim() }).then(function (r) { handleCommand(r); if (S.me.creator) close(); }).catch(function (e) { toast(e.message); });
          } }, 'Включить')));
      }
      return [sheetTitle('Профиль', close),
        h('div', { class: 'prof' }, av, h('div', { class: 'un' }, '@' + S.me.username + ' · нельзя изменить')),
        h('div', { class: 'field' }, h('label', null, 'Отображаемое имя'), name), h('div', { class: 'field' }, h('label', null, 'О себе'), bio),
        h('button', { class: 'btn', onclick: function () {
          A.call('updateProfile', { displayName: name.value, bio: bio.value }).then(function (r) { S.me = Object.assign(S.me, r.me); S.users[S.me.id] = S.me; renderTop(); renderList(); close(); toast('Сохранено', 1500); }).catch(function (e) { toast(e.message); });
        } }, 'Сохранить'),
        h('div', { style: { height: '14px' } }), creatorBox,
        A.mode === 'local' ? h('div', { class: 'note' }, 'Локальный режим: данные хранятся только в этом браузере. Чтобы общаться между устройствами, запусти сервер (node server.js).') : null,
        h('button', { class: 'btn danger', onclick: function () { if (!confirm('Выйти из аккаунта?')) return; close(); A.logout().then(function () { location.hash = ''; showAuth(); }); } }, icon('logout', 20), 'Выйти')];
    });
  }

  /* ================= звонок (заглушка) ================= */
  function startCall(p) {
    var ring = new Audio('sounds/call_sound.mp3'); ring.loop = true;
    var st = h('div', { class: 'st' }, 'Вызов…'), timer, done = false;
    var el = h('div', { class: 'call' }, h('div', { class: 'pulse' }, avatar(p, 120)), h('div', { class: 'nm' }, nameNode(p)), st,
      h('button', { class: 'end', 'aria-label': 'Завершить', onclick: end }, icon('phone', 30)));
    document.body.append(el);
    ring.play().catch(function () {});
    timer = setTimeout(function () {
      ring.pause(); st.textContent = 'Абонент недоступен';
      var na = new Audio('sounds/abonent_nedostupen.mp3'); na.play().catch(function () {}); el._na = na;
      timer = setTimeout(end, 6000);
    }, 6000);
    function end() { if (done) return; done = true; clearTimeout(timer); ring.pause(); if (el._na) el._na.pause(); el.remove(); }
  }

  /* ================= запуск ================= */
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    var ov = document.querySelector('.overlay, .viewer'); if (ov) ov.remove();
  });
  function boot() {
    root.replaceChildren(h('div', { class: 'auth' }, h('div', { class: 'auth-card', style: { textAlign: 'center' } }, h('img', { class: 'auth-logo', src: 'logo.png', alt: '' }), h('div', { class: 'sub' }, 'Подключение…'))));
    A.handler = onEvent; A.stateHandler = onConn; A.resyncHandler = resync;
    A.authLostHandler = function () { if (S.me) { A.logout(); showAuth('Сессия истекла — войди снова'); } };
    A.init().then(function () { return A.restore(); }).then(function (snap) { if (snap) enter(snap); else showAuth(); })
      .catch(function (e) { showAuth(e.message); });
  }
  boot();
})();
