/* Vortex API: два транспорта с одинаковым интерфейсом.
   server — настоящий сервер (REST + SSE); local — всё в браузере (если сервера нет). */
(function () {
  'use strict';
  var Core = window.VortexCore;
  var SERVER = String(window.VORTEX_SERVER_URL || '').replace(/\/+$/, '');
  var MODE_PREF = window.VORTEX_MODE || 'auto'; // auto | server | local
  var CREATOR_KEY_LOCAL = window.VORTEX_CREATOR_KEY || 'vortex-creator';

  var Api = { mode: null, token: null, handler: function () {}, stateHandler: function () {}, resyncHandler: function () {}, authLostHandler: function () {} };
  var NET_MSG = 'Нет связи с сервером. Проверь интернет и попробуй ещё раз.';

  function mkErr(msg, code, status) { var e = new Error(msg); e.code = code; e.status = status; return e; }
  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); return true; } catch (e) { return false; } }
  function lsDel(k) { try { localStorage.removeItem(k); } catch (e) {} }
  function tokenKey() { return 'vortex_token_' + Api.mode; }

  Api.media = function (u) {
    if (!u) return '';
    if (/^(data:|blob:|https?:)/.test(u)) return u;
    return SERVER + u;
  };

  /* ---------- определение режима ---------- */
  function ping() {
    var ctrl = new AbortController();
    var t = setTimeout(function () { ctrl.abort(); }, 4500);
    return fetch(SERVER + '/api/ping', { signal: ctrl.signal, cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (j) { return !!(j && j.app === 'vortex'); })
      .catch(function () { return false; })
      .then(function (v) { clearTimeout(t); return v; });
  }
  Api.init = function () {
    if (MODE_PREF === 'local') { Api.mode = 'local'; return Promise.resolve('local'); }
    if (MODE_PREF === 'server') { Api.mode = 'server'; return Promise.resolve('server'); }
    return ping().then(function (ok) { Api.mode = ok ? 'server' : 'local'; return Api.mode; });
  };

  /* ---------- серверный транспорт ---------- */
  function http(path, o) {
    o = o || {};
    var headers = {};
    if (Api.token) headers.Authorization = 'Bearer ' + Api.token;
    if (o.type) headers['Content-Type'] = o.type;
    return fetch(SERVER + path, { method: o.method || 'GET', headers: headers, body: o.body })
      .catch(function () { throw mkErr(NET_MSG, 'network'); })
      .then(function (res) {
        return res.json().catch(function () { return null; }).then(function (j) {
          if (!res.ok) {
            if (res.status === 401 && Api.token) Api.authLostHandler();
            var er = j && j.error || {};
            throw mkErr(er.message || ('Ошибка сервера (' + res.status + ')'), er.code || 'http', res.status);
          }
          return j;
        });
      });
  }
  function postJson(path, body) { return http(path, { method: 'POST', type: 'application/json', body: JSON.stringify(body || {}) }); }

  var es = null, esOpened = false;
  function connectSSE() {
    closeSSE();
    es = new EventSource(SERVER + '/api/events?token=' + encodeURIComponent(Api.token));
    es.onmessage = function (e) { try { Api.handler(JSON.parse(e.data)); } catch (x) { console.error(x); } };
    es.onopen = function () {
      Api.stateHandler('online');
      if (esOpened) Api.resyncHandler();
      esOpened = true;
    };
    es.onerror = function () {
      Api.stateHandler('connecting');
      if (es && es.readyState === 2) { // закрыт навсегда (например 401)
        // проверим токен: при 401 http() сам вызовет authLostHandler
        http('/api/call/getUser', { method: 'POST', type: 'application/json', body: '{"username":"vortex"}' }).catch(function () {});
      }
    };
  }
  function closeSSE() { if (es) { es.close(); es = null; } esOpened = false; }

  /* ---------- локальный транспорт ---------- */
  var LKEY = 'vortex_local_db_v2';
  var L = null; // { state, core, bc }

  function sha256(str) {
    var K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
    var H = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
    var bytes = new TextEncoder().encode(str), l = bytes.length;
    var total = ((l + 9 + 63) >> 6) << 6, buf = new Uint8Array(total);
    buf.set(bytes); buf[l] = 0x80;
    var dv = new DataView(buf.buffer);
    dv.setUint32(total - 8, Math.floor(l * 8 / 4294967296)); dv.setUint32(total - 4, (l * 8) >>> 0);
    var w = new Uint32Array(64);
    function rr(x, n) { return (x >>> n) | (x << (32 - n)); }
    for (var off = 0; off < total; off += 64) {
      for (var i = 0; i < 16; i++) w[i] = dv.getUint32(off + i * 4);
      for (i = 16; i < 64; i++) {
        var s0 = rr(w[i - 15], 7) ^ rr(w[i - 15], 18) ^ (w[i - 15] >>> 3), s1 = rr(w[i - 2], 17) ^ rr(w[i - 2], 19) ^ (w[i - 2] >>> 10);
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
      }
      var a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
      for (i = 0; i < 64; i++) {
        var S1 = rr(e, 6) ^ rr(e, 11) ^ rr(e, 25), ch = (e & f) ^ (~e & g), t1 = (h + S1 + ch + K[i] + w[i]) | 0;
        var S0 = rr(a, 2) ^ rr(a, 13) ^ rr(a, 22), mj = (a & b) ^ (a & c) ^ (b & c), t2 = (S0 + mj) | 0;
        h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
      }
      H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
      H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
    }
    return Array.prototype.map.call(H, function (x) { return ('00000000' + (x >>> 0).toString(16)).slice(-8); }).join('');
  }
  function hex(buf) { return Array.prototype.map.call(new Uint8Array(buf), function (x) { return ('0' + x.toString(16)).slice(-2); }).join(''); }
  function rand(n) { var a = new Uint8Array(n); (window.crypto || window.msCrypto).getRandomValues(a); return hex(a); }
  function hashPw(pw) {
    var salt = rand(12);
    if (window.crypto && crypto.subtle) {
      return crypto.subtle.importKey('raw', new TextEncoder().encode(pw), 'PBKDF2', false, ['deriveBits'])
        .then(function (k) { return crypto.subtle.deriveBits({ name: 'PBKDF2', salt: new TextEncoder().encode(salt), iterations: 100000, hash: 'SHA-256' }, k, 256); })
        .then(function (b) { return 'pbkdf2$' + salt + '$' + hex(b); });
    }
    var x = pw; for (var i = 0; i < 2000; i++) x = sha256(salt + x);
    return Promise.resolve('sha$' + salt + '$' + x);
  }
  function verifyPw(pw, stored) {
    var p = String(stored).split('$');
    if (p[0] === 'pbkdf2' && window.crypto && crypto.subtle) {
      return crypto.subtle.importKey('raw', new TextEncoder().encode(pw), 'PBKDF2', false, ['deriveBits'])
        .then(function (k) { return crypto.subtle.deriveBits({ name: 'PBKDF2', salt: new TextEncoder().encode(p[1]), iterations: 100000, hash: 'SHA-256' }, k, 256); })
        .then(function (b) { return hex(b) === p[2]; });
    }
    if (p[0] === 'sha') { var x = pw; for (var i = 0; i < 2000; i++) x = sha256(p[1] + x); return Promise.resolve(x === p[2]); }
    return Promise.resolve(false);
  }

  function reloadLocal() {
    var raw = lsGet(LKEY), fresh = null;
    if (raw) { try { fresh = JSON.parse(raw); } catch (e) {} }
    if (!fresh) fresh = Core.emptyState();
    Object.keys(L.state).forEach(function (k) { delete L.state[k]; });
    Object.assign(L.state, fresh);
  }
  function saveLocal() {
    if (!lsSet(LKEY, JSON.stringify(L.state))) Api.stateHandler('storage_full');
  }
  function initLocal() {
    if (L) return;
    L = { state: Core.emptyState(), bc: null };
    reloadLocal();
    var deliver = function (targets, ev) {
      var uid = Api.localUid;
      if (!uid) return;
      if (targets == null || targets.indexOf(uid) >= 0) Api.handler(ev);
    };
    try {
      L.bc = new BroadcastChannel('vortex_local');
      L.bc.onmessage = function (e) { reloadLocal(); deliver(e.data.targets, e.data.ev); };
    } catch (e) {}
    L.core = Core.create({
      state: L.state, save: saveLocal, creatorKey: CREATOR_KEY_LOCAL, allowDataImages: true,
      isOnline: function () { return true; },
      rand: rand, hash: hashPw, verify: verifyPw,
      schedule: function (fn, ms) { setTimeout(function () { reloadLocal(); fn(); }, ms); },
      emit: function (targets, ev) {
        if (L.bc) { try { L.bc.postMessage({ targets: targets, ev: ev }); } catch (e) {} }
        deliver(targets, ev);
      }
    });
    saveLocal();
  }

  /* ---------- общий интерфейс ---------- */
  function wrapLocal(fn) {
    return new Promise(function (ok, no) {
      try { reloadLocal(); Promise.resolve(fn()).then(ok, function (e) { no(mkErr(e.message, e.code, e.status)); }); }
      catch (e) { no(mkErr(e.message, e.code, e.status)); }
    });
  }
  function setToken(t, me) {
    Api.token = t; Api.localUid = me && me.id;
    lsSet(tokenKey(), t);
  }

  Api.register = function (p) {
    if (Api.mode === 'local') { initLocal(); return wrapLocal(function () { return L.core.register(p); }).then(function (r) { setToken(r.token, r.me); return r; }); }
    return postJson('/api/register', p).then(function (r) { setToken(r.token, r.me); return r; });
  };
  Api.login = function (p) {
    if (Api.mode === 'local') { initLocal(); return wrapLocal(function () { return L.core.login(p); }).then(function (r) { setToken(r.token, r.me); return r; }); }
    return postJson('/api/login', p).then(function (r) { setToken(r.token, r.me); return r; });
  };
  Api.call = function (method, args) {
    if (Api.mode === 'local') {
      return wrapLocal(function () {
        var uid = L.core.auth(Api.token);
        if (!uid) throw mkErr('Нужно войти заново', 'unauthorized', 401);
        return L.core.methods[method](uid, args || {});
      });
    }
    return postJson('/api/call/' + method, args);
  };
  Api.restore = function () {
    var t = lsGet(tokenKey());
    if (!t) return Promise.resolve(null);
    Api.token = t;
    if (Api.mode === 'local') {
      initLocal();
      return wrapLocal(function () { var uid = L.core.auth(t); if (!uid) throw mkErr('x'); Api.localUid = uid; return L.core.methods.snapshot(uid); })
        .catch(function () { Api.token = null; lsDel(tokenKey()); return null; });
    }
    return Api.call('snapshot').catch(function (e) {
      if (e.code === 'network') throw e;
      Api.token = null; lsDel(tokenKey()); return null;
    });
  };
  Api.connect = function () {
    if (Api.mode === 'server') connectSSE(); else Api.stateHandler('online');
  };
  Api.logout = function () {
    var t = Api.token;
    closeSSE();
    var p = Api.mode === 'local' ? wrapLocal(function () { L.core.logout(t); return {}; }) : postJson('/api/logout').catch(function () {});
    Api.token = null; Api.localUid = null; lsDel(tokenKey());
    return p.catch(function () {});
  };
  Api.upload = function (blob) {
    if (Api.mode === 'local') {
      return new Promise(function (ok, no) {
        var fr = new FileReader();
        fr.onload = function () { ok(fr.result); };
        fr.onerror = function () { no(mkErr('Не удалось прочитать файл')); };
        fr.readAsDataURL(blob);
      });
    }
    return http('/api/upload', { method: 'POST', type: blob.type || 'image/jpeg', body: blob }).then(function (r) { return r.url; });
  };
  Api.maxImage = function () { return Api.mode === 'local' ? { dim: 720, q: 0.7 } : { dim: 1280, q: 0.82 }; };

  window.VortexApi = Api;
})();
