/* Vortex core — общая логика (аккаунты, чаты, сообщения, галочки).
   Работает и в Node (server.js), и в браузере (локальный режим). */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.VortexCore = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var USERNAME_RE = /^[A-Za-z][A-Za-z0-9_]{2,31}$/;
  var BOT_ID = 'u_bot';
  var COMMAND_RE = /^\/(creator|verify|unverify|verified|creatorhelp)(\s|$)/i;

  function VError(code, message, status) {
    var e = new Error(message); e.code = code; e.status = status || 400; return e;
  }
  function clip(s, n) { s = String(s == null ? '' : s); return s.length > n ? s.slice(0, n) : s; }
  function emptyState() {
    return { v: 2, seq: 1, users: {}, names: {}, sessions: {}, chats: {}, messages: {} };
  }
  function pid(a, b) { return 'p_' + [a, b].sort().join('_'); }

  function create(o) {
    var S = o.state;
    var now = o.now || function () { return Date.now(); };
    var schedule = o.schedule || function (fn, ms) { setTimeout(fn, ms); };
    var keyFails = {};

    function touch() { try { o.save && o.save(); } catch (e) {} }
    function emit(targets, ev) { try { o.emit(targets, ev); } catch (e) {} }
    function isOnline(id) { return !!(o.isOnline && o.isOnline(id)); }
    function allowDataImg() { return !!o.allowDataImages; }

    function pub(u) {
      return {
        id: u.id, username: u.username, displayName: u.displayName, bio: u.bio || '',
        avatar: u.avatar || null, verified: !!u.verified, bot: !!u.bot,
        online: u.bot ? true : isOnline(u.id), lastSeen: u.lastSeen || 0
      };
    }
    function selfView(u) { var p = pub(u); p.creator = !!u.creator; p.createdAt = u.createdAt; return p; }
    function chatView(c) {
      return { id: c.id, type: c.type, title: c.title || '', avatar: c.avatar || null, members: c.members.slice(),
        owner: c.owner || null, admins: (c.admins || []).slice(), createdAt: c.createdAt, lastTs: c.lastTs || c.createdAt };
    }
    function usersOf(chat) {
      return chat.members.map(function (id) { return S.users[id]; }).filter(Boolean).map(pub);
    }
    function mustUser(id) { var u = S.users[id]; if (!u) throw VError('no_user', 'Пользователь не найден', 404); return u; }
    function mustChat(uid, chatId) {
      var c = S.chats[chatId];
      if (!c || c.members.indexOf(uid) < 0) throw VError('no_chat', 'Чат не найден', 404);
      return c;
    }
    function isAdmin(c, uid) { return (c.admins || []).indexOf(uid) >= 0; }
    function validImage(v) {
      if (v == null || v === '') return null;
      if (typeof v !== 'string') throw VError('bad_image', 'Некорректное изображение');
      if (/^\/uploads\/[\w.-]+$/.test(v)) return v;
      if (allowDataImg() && /^data:image\/(jpeg|png|webp|gif);base64,[A-Za-z0-9+\/=]+$/.test(v) && v.length < 3500000) return v;
      throw VError('bad_image', 'Некорректное изображение');
    }

    /* ---------- внутренности ---------- */
    function ensureBot() {
      if (S.users[BOT_ID]) return;
      S.users[BOT_ID] = { id: BOT_ID, username: 'vortex', displayName: 'Vortex', bio: 'Официальный бот Vortex',
        avatar: null, verified: true, bot: true, createdAt: now(), lastSeen: now() };
      S.names['vortex'] = BOT_ID;
    }
    function ensureSaved(uid) {
      var id = 's_' + uid;
      if (!S.chats[id]) S.chats[id] = { id: id, type: 'saved', title: 'Избранное', members: [uid], owner: uid, admins: [uid], createdAt: now(), lastTs: now() };
      return S.chats[id];
    }
    function ensurePrivate(a, b) {
      var id = pid(a, b), created = false;
      if (!S.chats[id]) { S.chats[id] = { id: id, type: 'private', title: '', members: [a, b], owner: null, admins: [], createdAt: now(), lastTs: now() }; created = true; }
      return { chat: S.chats[id], created: created };
    }
    function push(chat, from, data) {
      var m = { id: S.seq++, chatId: chat.id, from: from, text: '', image: null, replyTo: null, ts: now(),
        edited: false, service: false, delivered: [], read: [] };
      for (var k in data) m[k] = data[k];
      m.delivered = chat.members.filter(function (x) { return x !== from && (x === BOT_ID || isOnline(x)); });
      var arr = S.messages[chat.id] || (S.messages[chat.id] = []);
      arr.push(m);
      if (arr.length > 5000) arr.splice(0, arr.length - 5000);
      chat.lastTs = m.ts;
      return m;
    }
    function newSession(uid) {
      var t = o.rand(24);
      S.sessions[t] = { uid: uid, ts: now() };
      return t;
    }
    function botSay(chat, text) {
      var m = push(chat, BOT_ID, { text: text });
      emit(chat.members, { t: 'message', msg: m });
      touch();
    }
    function welcome(u) {
      ensureBot();
      var r = ensurePrivate(u.id, BOT_ID);
      push(r.chat, BOT_ID, { text: 'Добро пожаловать в Vortex, ' + u.displayName + '! 👋\n\nНайди друзей через поиск по @username или создай группу — кнопка ✏️ внизу справа. В «Избранном» сообщения видишь только ты.\n\nГалочки у сообщений: ✓ отправлено, ✓✓ доставлено, синие ✓✓ прочитано.' });
    }

    /* ---------- аккаунты ---------- */
    async function register(p) {
      p = p || {};
      var username = String(p.username || '').trim();
      if (!USERNAME_RE.test(username)) throw VError('bad_username', 'Username: только латиница, цифры и _, от 3 до 32 символов, первый символ — буква');
      var pw = String(p.password || '');
      if (pw.length < 6) throw VError('bad_password', 'Пароль должен быть не короче 6 символов');
      if (pw.length > 128) throw VError('bad_password', 'Пароль слишком длинный');
      var displayName = clip(String(p.displayName || '').trim() || username, 40);
      var bio = clip(String(p.bio || '').trim(), 200);
      var hash = await o.hash(pw);
      var lower = username.toLowerCase();
      if (S.names[lower]) throw VError('taken', 'Этот username уже занят', 409);
      ensureBot();
      var first = !Object.keys(S.users).some(function (id) { return !S.users[id].bot; });
      var id = 'u' + (S.seq++);
      var u = { id: id, username: username, displayName: displayName, bio: bio, avatar: null, verified: false,
        creator: first, passHash: hash, createdAt: now(), lastSeen: now() };
      S.users[id] = u; S.names[lower] = id;
      ensureSaved(id);
      welcome(u);
      var token = newSession(id);
      touch();
      return { token: token, me: selfView(u) };
    }
    async function login(p) {
      p = p || {};
      var id = S.names[String(p.username || '').trim().toLowerCase()];
      var u = id && S.users[id];
      var ok = !!(u && u.passHash && await o.verify(String(p.password || ''), u.passHash));
      if (!ok) throw VError('bad_credentials', 'Неверный username или пароль', 401);
      var token = newSession(u.id);
      touch();
      return { token: token, me: selfView(u) };
    }
    function logout(token) { if (S.sessions[token]) { delete S.sessions[token]; touch(); } }
    function auth(token) { var s = token && S.sessions[token]; return s && S.users[s.uid] ? s.uid : null; }

    /* ---------- методы (uid — авторизованный пользователь) ---------- */
    var M = {};

    M.snapshot = function (uid) {
      var chats = Object.keys(S.chats).map(function (k) { return S.chats[k]; })
        .filter(function (c) { return c.members.indexOf(uid) >= 0; });
      var ids = {}; ids[uid] = 1;
      chats.forEach(function (c) { c.members.forEach(function (m) { ids[m] = 1; }); });
      var messages = {}, more = {};
      chats.forEach(function (c) {
        var a = S.messages[c.id] || [];
        messages[c.id] = a.slice(-60); more[c.id] = a.length > 60;
      });
      return {
        me: selfView(S.users[uid]),
        users: Object.keys(ids).map(function (i) { return S.users[i]; }).filter(Boolean).map(pub),
        chats: chats.map(chatView), messages: messages, more: more
      };
    };

    M.history = function (uid, a) {
      var c = mustChat(uid, a.chatId);
      var arr = (S.messages[c.id] || []).filter(function (m) { return m.id < a.before; });
      return { messages: arr.slice(-50), more: arr.length > 50 };
    };

    M.getUser = function (uid, a) {
      var id = a.id || S.names[String(a.username || '').replace(/^@/, '').toLowerCase()];
      return { user: pub(mustUser(id)) };
    };

    M.searchUsers = function (uid, a) {
      var q = String(a.q || '').trim().replace(/^@/, '').toLowerCase();
      if (!q) return { users: [] };
      var res = Object.keys(S.users).map(function (k) { return S.users[k]; }).filter(function (u) {
        return u.id !== uid && (u.username.toLowerCase().indexOf(q) >= 0 || u.displayName.toLowerCase().indexOf(q) >= 0);
      }).sort(function (x, y) {
        var xs = x.username.toLowerCase().indexOf(q) === 0 ? 0 : 1, ys = y.username.toLowerCase().indexOf(q) === 0 ? 0 : 1;
        return xs - ys;
      }).slice(0, 20).map(pub);
      return { users: res };
    };

    M.openPrivate = function (uid, a) {
      var tid = a.userId || S.names[String(a.username || '').replace(/^@/, '').toLowerCase()];
      var t = mustUser(tid);
      if (t.id === uid) return { chat: chatView(ensureSaved(uid)), users: [pub(S.users[uid])] };
      var r = ensurePrivate(uid, t.id);
      if (r.created) touch();
      return { chat: chatView(r.chat), users: usersOf(r.chat) };
    };

    M.createGroup = function (uid, a) {
      var type = a.type === 'channel' ? 'channel' : 'group';
      var title = clip(String(a.title || '').trim(), 60);
      if (!title) throw VError('bad_title', 'Введи название');
      var members = [uid];
      (a.memberIds || []).forEach(function (id) { if (S.users[id] && !S.users[id].bot && members.indexOf(id) < 0) members.push(id); });
      var id = 'g_' + o.rand(6);
      var c = S.chats[id] = { id: id, type: type, title: title, avatar: null, members: members, owner: uid, admins: [uid], createdAt: now(), lastTs: now() };
      var me = S.users[uid];
      var m = push(c, uid, { service: true, text: me.displayName + (type === 'channel' ? ' создал(а) канал «' : ' создал(а) группу «') + title + '»' });
      emit(c.members, { t: 'chat', chat: chatView(c), users: usersOf(c) });
      emit(c.members, { t: 'message', msg: m });
      touch();
      return { chat: chatView(c), users: usersOf(c) };
    };

    M.addMembers = function (uid, a) {
      var c = mustChat(uid, a.chatId);
      if (c.type !== 'group' && c.type !== 'channel') throw VError('bad_chat', 'Сюда нельзя добавлять участников');
      if (!isAdmin(c, uid)) throw VError('forbidden', 'Добавлять участников может только администратор', 403);
      var added = [];
      (a.memberIds || []).forEach(function (id) {
        if (S.users[id] && !S.users[id].bot && c.members.indexOf(id) < 0) { c.members.push(id); added.push(S.users[id]); }
      });
      if (added.length) {
        var me = S.users[uid];
        var m = push(c, uid, { service: true, text: me.displayName + ' добавил(а): ' + added.map(function (u) { return u.displayName; }).join(', ') });
        emit(c.members, { t: 'chat', chat: chatView(c), users: usersOf(c) });
        emit(c.members, { t: 'message', msg: m });
        touch();
      }
      return { chat: chatView(c), users: usersOf(c) };
    };

    M.leaveChat = function (uid, a) {
      var c = mustChat(uid, a.chatId);
      if (c.type !== 'group' && c.type !== 'channel') throw VError('bad_chat', 'Из этого чата нельзя выйти');
      c.members = c.members.filter(function (x) { return x !== uid; });
      c.admins = (c.admins || []).filter(function (x) { return x !== uid; });
      emit([uid], { t: 'chat_removed', chatId: c.id });
      if (!c.members.length) { delete S.chats[c.id]; delete S.messages[c.id]; }
      else {
        if (c.owner === uid) { c.owner = c.members[0]; if (c.admins.indexOf(c.owner) < 0) c.admins.push(c.owner); }
        var m = push(c, uid, { service: true, text: S.users[uid].displayName + ' покинул(а) чат' });
        emit(c.members, { t: 'chat', chat: chatView(c), users: usersOf(c) });
        emit(c.members, { t: 'message', msg: m });
      }
      touch();
      return { ok: true };
    };

    M.sendMessage = function (uid, a) {
      var c = mustChat(uid, a.chatId);
      if (c.type === 'channel' && !isAdmin(c, uid)) throw VError('forbidden', 'В канале писать может только администратор', 403);
      var text = clip(String(a.text || '').trim(), 4000);
      var image = validImage(a.image);
      if (!text && !image) throw VError('empty', 'Пустое сообщение');
      var replyTo = null;
      if (a.replyTo != null) {
        var rm = (S.messages[c.id] || []).filter(function (x) { return x.id === a.replyTo; })[0];
        if (rm) replyTo = rm.id;
      }
      var first = !(S.messages[c.id] || []).length;
      var m = push(c, uid, { text: text, image: image, replyTo: replyTo });
      var out = JSON.parse(JSON.stringify(m)); out.cid = a.cid || null;
      var ev = { t: 'message', msg: out };
      if (first) { ev.chat = chatView(c); ev.users = usersOf(c); }
      emit(c.members, ev);
      if (c.type === 'saved') { m.read = [uid]; }
      if (c.type === 'private' && c.members.indexOf(BOT_ID) >= 0) {
        schedule(function () {
          botSay(c, 'Я автоматический бот и отвечать не умею 🙂 Найди друзей через 🔍 поиск по @username — и общайтесь!');
        }, 700);
      }
      touch();
      return { msg: out };
    };

    M.editMessage = function (uid, a) {
      var c = mustChat(uid, a.chatId);
      var m = (S.messages[c.id] || []).filter(function (x) { return x.id === a.id; })[0];
      if (!m || m.service) throw VError('no_msg', 'Сообщение не найдено', 404);
      if (m.from !== uid) throw VError('forbidden', 'Можно изменять только свои сообщения', 403);
      var text = clip(String(a.text || '').trim(), 4000);
      if (!text && !m.image) throw VError('empty', 'Пустое сообщение');
      m.text = text; m.edited = true;
      emit(c.members, { t: 'message_edit', msg: m });
      touch();
      return { msg: m };
    };

    M.deleteMessage = function (uid, a) {
      var c = mustChat(uid, a.chatId);
      var arr = S.messages[c.id] || [];
      var i = -1; for (var k = 0; k < arr.length; k++) if (arr[k].id === a.id) { i = k; break; }
      if (i < 0) throw VError('no_msg', 'Сообщение не найдено', 404);
      var m = arr[i];
      if (m.from !== uid && !((c.type === 'group' || c.type === 'channel') && isAdmin(c, uid))) throw VError('forbidden', 'Нельзя удалить чужое сообщение', 403);
      arr.splice(i, 1);
      emit(c.members, { t: 'message_delete', chatId: c.id, id: m.id });
      touch();
      return { ok: true };
    };

    M.markRead = function (uid, a) {
      var c = mustChat(uid, a.chatId);
      var upTo = 0;
      (S.messages[c.id] || []).forEach(function (m) {
        if (m.from !== uid && m.read.indexOf(uid) < 0) {
          m.read.push(uid);
          if (m.delivered.indexOf(uid) < 0) m.delivered.push(uid);
          if (m.id > upTo) upTo = m.id;
        }
      });
      if (upTo) { emit(c.members, { t: 'read', chatId: c.id, userId: uid, upTo: upTo }); touch(); }
      return { ok: true };
    };

    M.typing = function (uid, a) {
      var c = mustChat(uid, a.chatId);
      emit(c.members.filter(function (x) { return x !== uid; }), { t: 'typing', chatId: c.id, userId: uid });
      return { ok: true };
    };

    M.updateProfile = function (uid, a) {
      var u = S.users[uid];
      if (a.displayName != null) {
        var dn = clip(String(a.displayName).trim(), 40);
        if (!dn) throw VError('bad_name', 'Имя не может быть пустым');
        u.displayName = dn;
      }
      if (a.bio != null) u.bio = clip(String(a.bio).trim(), 200);
      if (a.avatar !== undefined) u.avatar = validImage(a.avatar);
      emit(null, { t: 'user', user: pub(u) });
      touch();
      return { me: selfView(u) };
    };

    M.setVerified = function (uid, a) {
      var me = S.users[uid];
      if (!me.creator) throw VError('forbidden', 'Выдавать галочки может только создатель', 403);
      var t = mustUser(a.id);
      var on = a.on !== false;
      t.verified = on;
      emit(null, { t: 'user', user: pub(t) });
      if (t.id !== uid) emit([t.id], { t: 'badge', on: on, by: pub(me) });
      touch();
      return { user: pub(t), on: on };
    };

    M.command = function (uid, a) {
      var text = String(a.text || '').trim();
      if (!COMMAND_RE.test(text)) return { handled: false };
      var me = S.users[uid];
      var p = text.split(/\s+/), c = p[0].toLowerCase();
      if (c === '/creator') {
        var f = keyFails[uid] || { n: 0, until: 0 };
        if (f.until > now()) return { handled: true, toast: 'Слишком много попыток. Подожди несколько минут.' };
        if (p[1] && p[1].toLowerCase() === 'off') { me.creator = false; touch(); return { handled: true, toast: 'Режим создателя выключен', me: selfView(me) }; }
        if (p[1] && o.creatorKey && p[1] === o.creatorKey) {
          me.creator = true; keyFails[uid] = { n: 0, until: 0 }; touch();
          return { handled: true, toast: 'Режим создателя включён. /creatorhelp — список команд', me: selfView(me) };
        }
        f.n++; if (f.n >= 5) { f.until = now() + 10 * 60000; f.n = 0; }
        keyFails[uid] = f;
        return { handled: true, toast: 'Неверный ключ' };
      }
      if (!me.creator) return { handled: true, toast: 'Команда доступна только создателю: /creator <ключ>' };
      if (c === '/creatorhelp') return { handled: true, toast: '/verify @ник · /unverify @ник · /verified · /creator off' };
      if (c === '/verified') {
        var list = Object.keys(S.users).map(function (k) { return S.users[k]; }).filter(function (u) { return u.verified && !u.bot; }).map(function (u) { return '@' + u.username; });
        return { handled: true, toast: list.length ? 'С галочкой: ' + list.join(', ') : 'Галочек пока нет' };
      }
      var tid = p[1] ? S.names[p[1].replace(/^@/, '').toLowerCase()] : uid;
      if (!tid) return { handled: true, toast: 'Пользователь ' + p[1] + ' не найден' };
      var r = M.setVerified(uid, { id: tid, on: c === '/verify' });
      return { handled: true, badge: { on: r.on, user: r.user }, me: selfView(me) };
    };

    /* ---------- доставка при подключении ---------- */
    function markDelivered(uid) {
      Object.keys(S.chats).forEach(function (k) {
        var c = S.chats[k];
        if (c.members.indexOf(uid) < 0) return;
        var upTo = 0;
        (S.messages[k] || []).forEach(function (m) {
          if (m.from !== uid && m.delivered.indexOf(uid) < 0) { m.delivered.push(uid); if (m.id > upTo) upTo = m.id; }
        });
        if (upTo) emit(c.members, { t: 'delivered', chatId: k, userId: uid, upTo: upTo });
      });
      touch();
    }
    function setPresence(uid, online) {
      var u = S.users[uid]; if (!u) return;
      if (!online) u.lastSeen = now();
      emit(null, { t: 'presence', userId: uid, online: online, lastSeen: u.lastSeen });
      touch();
    }

    ensureBot();
    return { register: register, login: login, logout: logout, auth: auth, methods: M,
      markDelivered: markDelivered, setPresence: setPresence, ensureBot: ensureBot };
  }

  return { create: create, emptyState: emptyState, VError: VError, COMMAND_RE: COMMAND_RE, USERNAME_RE: USERNAME_RE, BOT_ID: BOT_ID };
});
