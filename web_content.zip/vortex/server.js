#!/usr/bin/env node
/* Vortex server — без внешних зависимостей. Node 18+.
   Запуск: node server.js   (PORT=3000, VORTEX_DATA=./data, VORTEX_CREATOR_KEY=...) */
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const Core = require('./public/js/core.js');

const PORT = +process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';
const DATA = path.resolve(process.env.VORTEX_DATA || path.join(__dirname, 'data'));
const PUBLIC = path.join(__dirname, 'public');
const UPLOADS = path.join(DATA, 'uploads');
const DB_FILE = path.join(DATA, 'db.json');
fs.mkdirSync(UPLOADS, { recursive: true });

/* ---------- хранилище ---------- */
let state = Core.emptyState();
try { state = Object.assign(Core.emptyState(), JSON.parse(fs.readFileSync(DB_FILE, 'utf8'))); } catch (e) {}
let saveTimer = null;
function saveNow() {
  clearTimeout(saveTimer); saveTimer = null;
  const tmp = DB_FILE + '.tmp';
  try { fs.writeFileSync(tmp, JSON.stringify(state)); fs.renameSync(tmp, DB_FILE); } catch (e) { console.error('save error', e.message); }
}
function save() { if (!saveTimer) saveTimer = setTimeout(saveNow, 400); }
process.on('SIGINT', () => { saveNow(); process.exit(0); });
process.on('SIGTERM', () => { saveNow(); process.exit(0); });

/* ключ создателя: из окружения или сгенерированный и сохранённый */
let creatorKey = process.env.VORTEX_CREATOR_KEY;
if (!creatorKey) {
  const kf = path.join(DATA, 'creator.key');
  try { creatorKey = fs.readFileSync(kf, 'utf8').trim(); } catch (e) {}
  if (!creatorKey) { creatorKey = crypto.randomBytes(9).toString('hex'); fs.writeFileSync(kf, creatorKey); }
}

/* ---------- realtime (SSE) ---------- */
const clients = new Map(); // uid -> Set(res)
function emit(targets, ev) {
  const line = 'data: ' + JSON.stringify(ev) + '\n\n';
  const send = (set) => { if (set) for (const res of set) { try { res.write(line); } catch (e) {} } };
  if (targets == null) for (const set of clients.values()) send(set);
  else for (const id of targets) send(clients.get(id));
}

const scrypt = (pw, salt) => new Promise((ok, no) => crypto.scrypt(pw, salt, 32, (e, k) => e ? no(e) : ok(k)));
const core = Core.create({
  state, emit, save,
  isOnline: (id) => clients.has(id) && clients.get(id).size > 0,
  creatorKey,
  allowDataImages: false,
  rand: (n) => crypto.randomBytes(n).toString('hex'),
  hash: async (pw) => { const salt = crypto.randomBytes(16).toString('hex'); return 'scrypt$' + salt + '$' + (await scrypt(pw, salt)).toString('hex'); },
  verify: async (pw, stored) => {
    const p = String(stored).split('$'); if (p[0] !== 'scrypt') return false;
    const a = Buffer.from(p[2], 'hex'), b = await scrypt(pw, p[1]);
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  }
});

/* ---------- утилиты HTTP ---------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif', '.mp3': 'audio/mpeg', '.ico': 'image/x-icon' };

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
}
function json(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}
function fail(res, e) {
  const status = e && e.status || 500;
  if (status >= 500) console.error(e);
  json(res, status, { error: { code: e.code || 'server', message: status >= 500 ? 'Внутренняя ошибка сервера' : e.message } });
}
function readBody(req, limit) {
  return new Promise((ok, no) => {
    const chunks = []; let n = 0;
    req.on('data', (c) => { n += c.length; if (n > limit) { no(Object.assign(new Error('Слишком большой запрос'), { status: 413, code: 'too_big' })); req.destroy(); } else chunks.push(c); });
    req.on('end', () => ok(Buffer.concat(chunks)));
    req.on('error', no);
  });
}
async function readJson(req) {
  const b = await readBody(req, 1024 * 1024);
  if (!b.length) return {};
  try { return JSON.parse(b.toString('utf8')); } catch (e) { throw Object.assign(new Error('Некорректный JSON'), { status: 400, code: 'bad_json' }); }
}
function tokenOf(req, url) {
  const h = req.headers.authorization || '';
  return h.startsWith('Bearer ') ? h.slice(7) : url.searchParams.get('token');
}

/* простая защита от перебора пароля */
const hits = new Map();
function limited(req, key, max, windowMs) {
  const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').toString().split(',')[0].trim();
  const k = key + ':' + ip, t = Date.now();
  const arr = (hits.get(k) || []).filter((x) => t - x < windowMs);
  arr.push(t); hits.set(k, arr);
  return arr.length > max;
}
setInterval(() => { const t = Date.now(); for (const [k, v] of hits) if (!v.some((x) => t - x < 600000)) hits.delete(k); }, 300000).unref();

/* ---------- API ---------- */
async function api(req, res, url) {
  const route = url.pathname.slice(5);
  if (route === 'ping') return json(res, 200, { ok: true, app: 'vortex', v: 2 });

  if (req.method === 'POST' && (route === 'register' || route === 'login')) {
    if (limited(req, route, route === 'login' ? 15 : 10, 5 * 60000)) throw Object.assign(new Error('Слишком много попыток, подожди пару минут'), { status: 429, code: 'rate' });
    const body = await readJson(req);
    return json(res, 200, await core[route](body));
  }

  const token = tokenOf(req, url);
  const uid = core.auth(token);
  if (!uid) throw Object.assign(new Error('Нужно войти заново'), { status: 401, code: 'unauthorized' });

  if (route === 'logout' && req.method === 'POST') { core.logout(token); return json(res, 200, { ok: true }); }

  if (route === 'events') {
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
    res.write('retry: 2000\n\n');
    let set = clients.get(uid); const wasOffline = !set || !set.size;
    if (!set) clients.set(uid, set = new Set());
    set.add(res);
    const ka = setInterval(() => { try { res.write(': ka\n\n'); } catch (e) {} }, 20000);
    req.on('close', () => {
      clearInterval(ka); set.delete(res);
      if (!set.size) { clients.delete(uid); core.setPresence(uid, false); }
    });
    if (wasOffline) { core.markDelivered(uid); core.setPresence(uid, true); }
    return;
  }

  if (route === 'upload' && req.method === 'POST') {
    if (limited(req, 'upload', 60, 60000)) throw Object.assign(new Error('Слишком часто'), { status: 429, code: 'rate' });
    const type = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
    const ext = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp', 'image/gif': '.gif' }[type];
    if (!ext) throw Object.assign(new Error('Поддерживаются только JPEG, PNG, WebP, GIF'), { status: 415, code: 'bad_type' });
    const buf = await readBody(req, 8 * 1024 * 1024);
    if (!buf.length) throw Object.assign(new Error('Пустой файл'), { status: 400, code: 'empty' });
    const name = crypto.randomBytes(12).toString('hex') + ext;
    fs.writeFileSync(path.join(UPLOADS, name), buf);
    return json(res, 200, { url: '/uploads/' + name });
  }

  if (route.startsWith('call/') && req.method === 'POST') {
    const method = route.slice(5);
    if (!Object.prototype.hasOwnProperty.call(core.methods, method)) throw Object.assign(new Error('Неизвестный метод'), { status: 404, code: 'no_method' });
    const args = await readJson(req);
    return json(res, 200, await core.methods[method](uid, args || {}));
  }
  throw Object.assign(new Error('Не найдено'), { status: 404, code: 'not_found' });
}

/* ---------- статика ---------- */
function serveFile(req, res, file, extraHeaders) {
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404); return res.end('Not found'); }
    const ext = path.extname(file).toLowerCase();
    const headers = Object.assign({ 'Content-Type': MIME[ext] || 'application/octet-stream', 'Content-Length': st.size, 'X-Content-Type-Options': 'nosniff' }, extraHeaders);
    res.writeHead(200, headers);
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  });
}
function safeJoin(base, rel) {
  const p = path.normalize(path.join(base, decodeURIComponent(rel)));
  return p.startsWith(base + path.sep) || p === base ? p : null;
}

const server = http.createServer(async (req, res) => {
  cors(res);
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  let url;
  try { url = new URL(req.url, 'http://x'); } catch (e) { res.writeHead(400); return res.end(); }
  try {
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    if (url.pathname.startsWith('/uploads/')) {
      const f = safeJoin(UPLOADS, url.pathname.slice(9));
      return f ? serveFile(req, res, f, { 'Cache-Control': 'public, max-age=31536000, immutable' }) : (res.writeHead(400), res.end());
    }
    let rel = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
    let f = safeJoin(PUBLIC, rel);
    if (!f) { res.writeHead(400); return res.end(); }
    if (!fs.existsSync(f) || fs.statSync(f).isDirectory()) f = path.extname(rel) ? f : path.join(PUBLIC, 'index.html');
    return serveFile(req, res, f, { 'Cache-Control': 'no-cache' });
  } catch (e) {
    if (!res.headersSent) fail(res, e); else try { res.end(); } catch (x) {}
  }
});

server.listen(PORT, HOST, () => {
  console.log('Vortex запущен: http://localhost:' + PORT);
  console.log('Данные: ' + DATA);
  console.log('Ключ создателя (команда /creator <ключ> в любом чате): ' + creatorKey);
  console.log('Первый зарегистрированный пользователь автоматически становится создателем.');
});
