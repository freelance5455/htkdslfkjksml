# v124 — FLOAT STATUS and AGENT SERVICING

Added two final dashboard metrics to the web app and Android app:

- **FLOAT STATUS** = current month-to-date total float given minus the previous month's comparable month-to-date total float given.
- **AGENT SERVICING** = current month-to-date count of active items visited at least five times minus the previous month's comparable month-to-date count of active items visited at least five times.

The previous-month comparison uses the same day-of-month cutoff as the current month, capped at the previous month's final calendar day (for example, on the 4th, compare days 1–4 in each month). Both figures are green when positive, red when negative, and neutral when zero. Existing dashboard metrics and visit-time behavior are retained. No database migration or Supabase SQL change is required.
