const {spawnSync}=require('child_process'),win=process.platform==='win32';
const r=spawnSync(win?'gradlew.bat':'./gradlew',['assembleDebug'],{cwd:'android',stdio:'inherit',shell:true});
if(r.status===0)console.log('\nDONE. APK: android/app/build/outputs/apk/debug/app-debug.apk');process.exit(r.status||0);
