const fs=require('fs'),f='android/app/src/main/AndroidManifest.xml';
let x=fs.readFileSync(f,'utf8');
if(!x.includes('screenOrientation')){x=x.replace('<activity','<activity android:screenOrientation="sensorLandscape"');fs.writeFileSync(f,x);console.log('Landscape lock added to AndroidManifest.xml')}else console.log('Already patched');
