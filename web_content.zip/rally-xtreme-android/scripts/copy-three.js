const fs=require('fs'),p='node_modules/three/build/three.min.js';
if(!fs.existsSync(p)){console.error('three.min.js not found. Run: npm install');process.exit(1)}
fs.copyFileSync(p,'www/three.min.js');console.log('three.min.js copied into www/');
