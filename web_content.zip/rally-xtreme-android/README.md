# Rally Xtreme - تحويل اللعبة لتطبيق أندرويد (APK)

## المتطلبات (مرة وحدة)
1. Node.js 18 أو أحدث
2. JDK 17
3. Android Studio (بيجيب معه Android SDK). بعد التثبيت افتحه مرة وخلّيه يحمّل الـSDK.

## الخطوات
```
npm install
npm run android:init     # مرة وحدة بس: بيعمل مشروع أندرويد وبيثبّت الوضع الأفقي
npm run apk              # بيبني الـAPK
```
الـAPK بيطلع هون: `android/app/build/outputs/apk/debug/app-debug.apk`
انقله للجوال وثبّته (فعّل "التثبيت من مصادر غير معروفة").

## بعد ما تعدّل على اللعبة
عدّل الملف `www/index.html` وبعدها شغّل بس:
```
npm run apk
```
(بيجيب مكتبة three.js أوتوماتيك من npm وبيحطها جوا التطبيق، فاللعبة بتشتغل بدون إنترنت.)

## للنشر كموقع (بدل APK)
شغّل `npm install` و `npm run copy-three`، وارفع مجلد `www` على Netlify Drop أو GitHub Pages.
افتح الرابط من Chrome مباشرة (مش من داخل تطبيق) وحساس الإمالة غالبًا بيشتغل.

## الخط (اختياري)
اللعبة بتستخدم خط Racing Sans One. نزّله من Google Fonts وحط الملف `RacingSansOne-Regular.ttf` جوا `www/`. لو ما حطيته بتشتغل بخط النظام.

## ملاحظات
- هاد APK للتجربة (debug). للنشر على Google Play بتحتاج توقيع (release) من Android Studio.
- لتغيير الأيقونة: استخدم `npx @capacitor/assets generate --android` مع صورة `assets/icon.png`.
