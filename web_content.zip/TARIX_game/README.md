# TARIX — Rise of Empires (Demo 0.1)

Bu birinchi ishlaydigan prototip: mobil va kompyuter brauzerlarida ochiladi.

## Ishga tushirish
1. ZIP faylni oching.
2. `index.html` faylini Chrome, Firefox yoki boshqa zamonaviy brauzerda oching.
3. Internet bo‘lmasa ham asosiy o‘yin ishlaydi. Sarlavha shriftlari uchun internet kerak bo‘lishi mumkin.

## Boshqaruv
- Xaritaga teging/bosing: qo‘shin harakatlanadi.
- Askar yollash va kamonchi yollash: resurs sarflaydi.
- Minora va ferma qurish: mudofaa va resurslar.
- Dushmanga hujum: 8 yoki undan ko‘p jangchi bilan qal’ani egallash.

## Keyingi ishlab chiqish bosqichlari
- 3D sahna va kamera (Three.js / Babylon.js)
- Tarixiy kampaniyalar va imperiyalar
- Saqlash/yuklash, audio, animatsiyalar
- Android APK uchun Capacitor qobig‘i
- Kompyuter uchun PWA yoki Electron/Tauri qobig‘i

Eslatma: “7D” ekran standarti emas. Loyihada bu atama o‘rniga chuqur 3D, kamera effektlari, zarba va muhit effektlari kabi cinematic ko‘rinish maqsad qilinadi.
