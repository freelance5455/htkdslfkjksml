(() => {
"use strict";
const $ = (id) => document.getElementById(id);
const canvas = $("world");
const ctx = canvas.getContext("2d");
const state = {
  running:false, paused:false, day:1, gold:350, wood:220, food:180,
  soldiers:12, archers:0, towers:[], farms:[], enemyHP:100, enemyAlive:true,
  territory:1, selected:null, target:{x:690,y:290}, units:[], particles:[],
  lastTick:0, tick:0, attackMode:false, won:false
};
const W=960,H=600;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const rand=(a,b)=>a+Math.random()*(b-a);
const colors={grass:"#61794f",dark:"#506a47",light:"#77865a",gold:"#d6ad62"};
function resizeCanvas(){
  const rect=canvas.getBoundingClientRect();
  const dpr=Math.min(window.devicePixelRatio||1,2);
  canvas.width=Math.max(1,Math.round(rect.width*dpr));
  canvas.height=Math.max(1,Math.round(rect.height*dpr));
  ctx.setTransform(canvas.width/W,0,0,canvas.height/H,0,0);
  draw();
}
function terrain(x,y){
  const n=Math.sin(x*.018)*Math.cos(y*.021)+Math.sin((x+y)*.009)*.7;
  return n>.65?"#74845a":n<-.65?"#526e4d":"#637b50";
}
function rounded(x,y,w,h,r,color){
  ctx.fillStyle=color;ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fill();
}
function drawTree(x,y,s=1){
  ctx.fillStyle="#263f32";ctx.beginPath();ctx.ellipse(x+4*s,y+14*s,13*s,5*s,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle="#34563b";ctx.beginPath();ctx.arc(x,y,12*s,0,Math.PI*2);ctx.fill();
  ctx.fillStyle="#52764a";ctx.beginPath();ctx.arc(x-4*s,y-5*s,8*s,0,Math.PI*2);ctx.fill();
  ctx.fillStyle="#6e7850";ctx.fillRect(x-2*s,y+5*s,4*s,11*s);
}
function drawBuilding(x,y,type){
  if(type==="castle"){
    ctx.fillStyle="#282f31";ctx.fillRect(x-35,y-25,70,42);
    ctx.fillStyle="#9b947c";ctx.fillRect(x-30,y-30,60,43);
    ctx.fillStyle="#6f746d";ctx.fillRect(x-39,y-42,16,55);ctx.fillRect(x+23,y-42,16,55);
    ctx.fillStyle="#b5a98d";ctx.fillRect(x-42,y-49,22,9);ctx.fillRect(x+20,y-49,22,9);
    ctx.fillStyle="#4c514e";ctx.fillRect(x-7,y-3,14,16);
    ctx.fillStyle="#c59b52";ctx.fillRect(x+2,y-60,2,17);ctx.fillStyle="#b94e3d";ctx.beginPath();ctx.moveTo(x+4,y-59);ctx.lineTo(x+23,y-53);ctx.lineTo(x+4,y-47);ctx.fill();
  }else if(type==="enemy"){
    ctx.fillStyle="#493b32";ctx.fillRect(x-37,y-24,74,40);
    ctx.fillStyle="#8c6651";ctx.fillRect(x-31,y-31,62,40);
    ctx.fillStyle="#594338";ctx.fillRect(x-39,y-43,17,55);ctx.fillRect(x+22,y-43,17,55);
    ctx.fillStyle="#d4b078";ctx.fillRect(x-43,y-49,25,9);ctx.fillRect(x+18,y-49,25,9);
    ctx.fillStyle="#2c2725";ctx.fillRect(x-8,y-4,16,13);
    ctx.fillStyle="#a94436";ctx.fillRect(x+4,y-60,3,18);ctx.fillStyle="#a94436";ctx.beginPath();ctx.moveTo(x+7,y-59);ctx.lineTo(x+26,y-54);ctx.lineTo(x+7,y-48);ctx.fill();
  }else if(type==="tower"){
    ctx.fillStyle="#a99d7d";ctx.fillRect(x-10,y-26,20,32);ctx.fillStyle="#6f7168";ctx.fillRect(x-14,y-33,28,9);ctx.fillStyle="#3c4440";ctx.fillRect(x-4,y-15,8,10);
  }else{
    ctx.fillStyle="#8a7048";ctx.fillRect(x-18,y-8,36,14);ctx.fillStyle="#c7ae70";ctx.beginPath();ctx.moveTo(x-23,y-8);ctx.lineTo(x,y-25);ctx.lineTo(x+23,y-8);ctx.fill();ctx.fillStyle="#6b8b50";ctx.fillRect(x-13,y-4,26,8);
  }
}
function drawUnit(u){
  ctx.save();ctx.translate(u.x,u.y);
  ctx.fillStyle="#27342b";ctx.beginPath();ctx.ellipse(2,7,9,4,0,0,7);ctx.fill();
  ctx.fillStyle=u.team==="enemy"?"#a64c3b":u.type==="archer"?"#a6a05f":"#d2c39b";
  ctx.beginPath();ctx.arc(0,-2,5,0,7);ctx.fill();
  ctx.fillStyle=u.team==="enemy"?"#542e2a":"#46544a";ctx.fillRect(-4,2,8,8);
  ctx.strokeStyle=u.team==="enemy"?"#c98d62":"#d8d0b4";ctx.lineWidth=2;
  ctx.beginPath();ctx.moveTo(5,1);ctx.lineTo(10,-7);ctx.stroke();
  ctx.restore();
}
function draw(){
  if(!ctx)return;
  ctx.clearRect(0,0,W,H);
  for(let y=0;y<H;y+=30)for(let x=0;x<W;x+=30){ctx.fillStyle=terrain(x,y);ctx.fillRect(x,y,30,30)}
  // River and road
  ctx.strokeStyle="#9ab0a0";ctx.globalAlpha=.35;ctx.lineWidth=24;ctx.beginPath();ctx.moveTo(0,455);ctx.bezierCurveTo(240,390,350,520,550,445);ctx.bezierCurveTo(690,390,820,445,960,380);ctx.stroke();ctx.globalAlpha=1;
  ctx.strokeStyle="#b7a17a";ctx.lineWidth=18;ctx.beginPath();ctx.moveTo(110,310);ctx.bezierCurveTo(330,280,460,330,650,290);ctx.stroke();
  ctx.strokeStyle="#d6c49b";ctx.lineWidth=2;ctx.setLineDash([12,10]);ctx.stroke();ctx.setLineDash([]);
  [[80,90,1.2],[180,175,.9],[370,85,1.1],[810,100,1.1],[860,470,1.2],[90,500,1],[440,510,.8],[580,90,.8]].forEach(t=>drawTree(...t));
  // Resource stones
  for(let i=0;i<9;i++){let x=80+i*93,y=390+Math.sin(i*2)*35;ctx.fillStyle="#999b8c";ctx.beginPath();ctx.ellipse(x,y,8,5,-.2,0,7);ctx.fill()}
  drawBuilding(205,285,"castle");
  drawBuilding(740,285,"enemy");
  state.towers.forEach(p=>drawBuilding(p.x,p.y,"tower"));
  state.farms.forEach(p=>drawBuilding(p.x,p.y,"farm"));
  // Territory boundary
  ctx.strokeStyle="#e2c477";ctx.globalAlpha=.55;ctx.lineWidth=2;ctx.setLineDash([8,8]);ctx.beginPath();ctx.ellipse(205,300,155,130,0,0,7);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;
  // Army banner
  ctx.fillStyle="#e2c477";ctx.fillRect(205,190,3,35);ctx.fillStyle="#a74437";ctx.beginPath();ctx.moveTo(208,191);ctx.lineTo(231,198);ctx.lineTo(208,206);ctx.fill();
  state.units.forEach(drawUnit);
  // Enemy health
  if(state.enemyAlive){rounded(690,205,100,9,4,"#2b2725");rounded(690,205,100*state.enemyHP/100,9,4,"#b64e3d");}
  // Particles
  state.particles.forEach(p=>{ctx.globalAlpha=p.life;ctx.fillStyle=p.color;ctx.beginPath();ctx.arc(p.x,p.y,p.size,0,7);ctx.fill();ctx.globalAlpha=1});
  // labels
  ctx.font="bold 12px Manrope";ctx.textAlign="center";ctx.fillStyle="#f0e6d1";ctx.shadowColor="#111";ctx.shadowBlur=5;
  ctx.fillText("SIZNING QAL’A",205,145);if(state.enemyAlive)ctx.fillText("DUSHMAN QAL’ASI",740,145);else ctx.fillText("EGALLANGAN HUDUD",740,145);
  ctx.shadowBlur=0;
}
function initUnits(){
  state.units=[];
  for(let i=0;i<state.soldiers;i++)state.units.push({x:rand(160,245),y:rand(320,365),tx:rand(160,245),ty:rand(320,365),team:"ally",type:"soldier",speed:rand(25,42)});
  for(let i=0;i<state.archers;i++)state.units.push({x:rand(160,245),y:rand(320,365),tx:rand(160,245),ty:rand(320,365),team:"ally",type:"archer",speed:rand(22,35)});
}
function updateHUD(){
  $("gold").textContent=Math.floor(state.gold);$("wood").textContent=Math.floor(state.wood);$("food").textContent=Math.floor(state.food);
  $("army-count").textContent=state.soldiers+state.archers;$("territory-count").textContent=state.territory;
  $("day-count").textContent=state.day+"-KUN";
  $("mission-progress").style.width=state.won?"100%":Math.max(8,100-state.enemyHP)+"%";
  if(state.won){$("mission-text").textContent="G‘alaba! Dushman qal’asi sizning imperiyangizga qo‘shildi.";$("status-text").textContent="G‘ALABA — YANGI HUDUD";}
}
let toastTimer;
function toast(message){
  const el=$("toast");el.textContent=message;el.classList.add("show");
  clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),2300);
}
function spend(g,w,f){
  if(state.gold<g||state.wood<w||state.food<f){toast("Resurs yetarli emas!");return false}
  state.gold-=g;state.wood-=w;state.food-=f;return true;
}
function recruit(type){
  if(type==="recruit"){
    if(!spend(60,0,20))return;
    state.soldiers++;state.units.push({x:205,y:345,tx:205,ty:345,team:"ally",type:"soldier",speed:34});
    toast("Yangi jangchi qo‘shinga qo‘shildi!");
  }else{
    if(!spend(80,15,0))return;
    state.archers++;state.units.push({x:215,y:350,tx:215,ty:350,team:"ally",type:"archer",speed:29});
    toast("Kamonchi tayyor!");
  }
  updateHUD();
}
function build(type){
  if(type==="tower"){
    if(!spend(40,100,0))return;
    state.towers.push({x:rand(115,290),y:rand(225,380)});toast("Qo‘riqlash minorasi qurildi!");
  }else{
    if(!spend(30,70,0))return;
    state.farms.push({x:rand(100,300),y:rand(380,430)});toast("Dehqonchilik yeri qurildi!");
  }
  updateHUD();draw();
}
function attack(){
  if(state.won){toast("Bu hudud allaqachon egallangan!");return}
  const count=state.soldiers+state.archers;
  if(count<8){toast("Hujum uchun kamida 8 jangchi kerak!");return}
  if(state.food<15){toast("Qo‘shin uchun oziq-ovqat yetarli emas!");return}
  state.food-=15;
  state.attackMode=true;
  state.units.forEach((u,i)=>{u.tx=rand(630,790);u.ty=rand(300,370)});
  $("status-text").textContent="JANG DAVOM ETMOQDA";
  toast("Hujum boshlandi! Qo‘shin dushman qal’asiga yo‘l oldi.");
  updateHUD();
}
function gameTick(dt){
  if(!state.running||state.paused)return;
  state.tick+=dt;
  state.gold+=dt*.8;state.food+=dt*.35;state.wood+=dt*.45;
  if(state.tick>35){state.tick=0;state.day++;toast("Yangi kun boshlandi. Resurslar yig‘ildi.");}
  if(state.attackMode&&state.enemyAlive){
    let near=state.units.filter(u=>Math.hypot(u.x-740,u.y-285)<100).length;
    if(near>0&&Math.random()<dt*.55){
      const damage=Math.min(near*.45,8);state.enemyHP-=damage;
      for(let i=0;i<3;i++)state.particles.push({x:rand(700,780),y:rand(250,310),life:1,size:rand(2,5),color:"#e2a15d"});
      if(state.enemyHP<=0){
        state.enemyHP=0;state.enemyAlive=false;state.won=true;state.territory++;
        state.gold+=180;state.food+=100;state.attackMode=false;
        $("status-text").textContent="G‘ALABA — HUDUD EGALLANDI";
        toast("G‘ALABA! Dushman qal’asi egallandi!");
      }
    }
  }
  state.units.forEach(u=>{
    const dx=u.tx-u.x,dy=u.ty-u.y,d=Math.hypot(dx,dy);
    if(d>2){const step=Math.min(d,u.speed*dt);u.x+=dx/d*step;u.y+=dy/d*step}
    else if(state.attackMode&&state.enemyAlive){u.tx=rand(680,790);u.ty=rand(300,370)}
  });
  state.particles.forEach(p=>p.life-=dt*1.5);state.particles=state.particles.filter(p=>p.life>0);
  updateHUD();
}
let last=0;
function loop(now){
  const dt=Math.min((now-last)/1000||0,.05);last=now;
  gameTick(dt);draw();requestAnimationFrame(loop);
}
function startGame(){
  $("menu-screen").classList.add("hidden");$("game-screen").classList.remove("hidden");
  state.running=true;state.paused=false;initUnits();resizeCanvas();toast("Xush kelibsiz, imperator!");updateHUD();
}
function showModal(title,text){
  $("modal-title").textContent=title;$("modal-text").textContent=text;$("modal").classList.remove("hidden");
}
function closeModal(){ $("modal").classList.add("hidden");state.paused=false; }
$("start-btn").addEventListener("click",startGame);
$("pause-btn").addEventListener("click",()=>{state.paused=true;showModal("PAUZA","Imperiyangiz kutmoqda. Davom etish tugmasini bosing.")});
$("close-modal").addEventListener("click",closeModal);
$("resume-btn").addEventListener("click",closeModal);
$("help-btn").addEventListener("click",()=>showModal("O‘YIN QOIDALARI","Xaritaga teging — qo‘shin yuradi. O‘ng paneldan askar yollang va inshoot quring. Resurslar vaqt o‘tishi bilan ko‘payadi. Kamida 8 jangchi bilan Dushmanga hujum buyrug‘ini bering. Dushman qal’asini egallasangiz g‘alaba qozonasiz."));
document.querySelectorAll("[data-action]").forEach(btn=>btn.addEventListener("click",()=>{
  const a=btn.dataset.action;
  if(a==="recruit"||a==="archer")recruit(a);
  else if(a==="tower"||a==="farm")build(a);
  else if(a==="attack")attack();
}));
canvas.addEventListener("pointerdown",e=>{
  const rect=canvas.getBoundingClientRect();const x=(e.clientX-rect.left)/rect.width*W;const y=(e.clientY-rect.top)/rect.height*H;
  if(state.attackMode){toast("Qo‘shin hujumga o‘tgan. Jang yakunini kuting.");return}
  state.units.forEach((u,i)=>{u.tx=clamp(x+rand(-35,35),30,900);u.ty=clamp(y+rand(-25,25),30,560)});
  toast("Qo‘shin yangi joyga harakatlanmoqda.");
});
window.addEventListener("resize",resizeCanvas);
document.addEventListener("visibilitychange",()=>{if(document.hidden&&state.running){state.paused=true;showModal("PAUZA","O‘yin boshqa oynaga o‘tgani uchun vaqtincha to‘xtatildi.")}});
resizeCanvas();requestAnimationFrame(loop);
})();