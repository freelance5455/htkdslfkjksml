BHAKKAR RIDE — APP FILES
========================

This is a mobile-friendly web app / installable PWA starter for Bhakkar Ride.

WHAT IT DOES
- Customer enters name, mobile number, pickup and destination.
- Tapping “WhatsApp par booking bhejein” opens WhatsApp with the booking details pre-filled.
- Booking messages are sent to the WhatsApp number configured in index.html.
- No database, automatic rider matching, live tracking, payment processing, or booking dashboard is included yet.

WHATSAPP NUMBER
The app is configured to send booking messages to:
923407489366

HOW TO PUBLISH FREE WITH NETLIFY DROP
1. Extract this ZIP file.
2. Open https://app.netlify.com/drop in a browser.
3. Sign in / create a Netlify account if asked.
4. Upload or drag the extracted folder (the folder containing index.html, manifest.webmanifest, sw.js, and icon.svg).
5. Netlify will provide a public HTTPS link. Test the link on your phone.
6. Share that public link with people. On Android, open the link in Chrome and use “Install app” or “Add to Home screen” if offered.

IMPORTANT
- This ZIP is not an APK and is not already hosted publicly.
- The public link is created only after you upload the files to a hosting service.
- Before sharing widely, test the form and confirm that messages reach the correct WhatsApp account.
- The booking is only a request; manually confirm the rider and fare.
- Do not collect or share more personal data than necessary.
