/* ترید یار — Worker یکپارچه (ساخته‌شده خودکار با cloudflare-worker-src/build.js؛ دستی ویرایش نکنید)
 * همگام‌سازی + ریلی + مسیر /trade/v1 (اتصال و معامله فیوچرز روی صرافی‌ها) */
const __defs = {};
const __cache = {};
function __req(n) { if (n === "../server/exchanges.js") n = "./exchanges.js"; if (__cache[n]) return __cache[n].exports; const m = (__cache[n] = { exports: {} }); __defs[n](m, m.exports, __req); return m.exports; }
__defs["node:crypto"] = function (module, exports, require) {
'use strict';
/* جایگزین سبک و همگام (sync) برای node:crypto داخل Cloudflare Worker — بدون نیاز به nodejs_compat
 * فقط همان چیزهایی که کانکتورها لازم دارند: createHmac / createHash (sha256, sha512, md5) / randomBytes */
const K256 = [1116352408,1899447441,-1245643825,-373957723,961987163,1508970993,-1841331548,-1424204075,-670586216,310598401,607225278,1426881987,1925078388,-2132889090,-1680079193,-1046744716,-459576895,-272742522,264347078,604807628,770255983,1249150122,1555081692,1996064986,-1740746414,-1473132947,-1341970488,-1084653625,-958395405,-710438585,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,-2117940946,-1838011259,-1564481375,-1474664885,-1035236496,-949202525,-778901479,-694614492,-200395387,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,-2067236844,-1933114872,-1866530822,-1538233109,-1090935817,-965641998], H256 = [1779033703,-1150833019,1013904242,-1521486534,1359893119,-1694144372,528734635,1541459225], H512 = ["6a09e667f3bcc908","bb67ae8584caa73b","3c6ef372fe94f82b","a54ff53a5f1d36f1","510e527fade682d1","9b05688c2b3e6c1f","1f83d9abfb41bd6b","5be0cd19137e2179"], K512B = ["428a2f98d728ae22","7137449123ef65cd","b5c0fbcfec4d3b2f","e9b5dba58189dbbc","3956c25bf348b538","59f111f1b605d019","923f82a4af194f9b","ab1c5ed5da6d8118","d807aa98a3030242","12835b0145706fbe","243185be4ee4b28c","550c7dc3d5ffb4e2","72be5d74f27b896f","80deb1fe3b1696b1","9bdc06a725c71235","c19bf174cf692694","e49b69c19ef14ad2","efbe4786384f25e3","0fc19dc68b8cd5b5","240ca1cc77ac9c65","2de92c6f592b0275","4a7484aa6ea6e483","5cb0a9dcbd41fbd4","76f988da831153b5","983e5152ee66dfab","a831c66d2db43210","b00327c898fb213f","bf597fc7beef0ee4","c6e00bf33da88fc2","d5a79147930aa725","06ca6351e003826f","142929670a0e6e70","27b70a8546d22ffc","2e1b21385c26c926","4d2c6dfc5ac42aed","53380d139d95b3df","650a73548baf63de","766a0abb3c77b2a8","81c2c92e47edaee6","92722c851482353b","a2bfe8a14cf10364","a81a664bbc423001","c24b8b70d0f89791","c76c51a30654be30","d192e819d6ef5218","d69906245565a910","f40e35855771202a","106aa07032bbd1b8","19a4c116b8d2d0c8","1e376c085141ab53","2748774cdf8eeb99","34b0bcb5e19b48a8","391c0cb3c5c95a63","4ed8aa4ae3418acb","5b9cca4f7763e373","682e6ff3d6b2b8a3","748f82ee5defb2fc","78a5636f43172f60","84c87814a1f0ab72","8cc702081a6439ec","90befffa23631e28","a4506cebde82bde9","bef9a3f7b2c67915","c67178f2e372532b","ca273eceea26619c","d186b8c721c0c207","eada7dd6cde0eb1e","f57d4f7fee6ed178","06f067aa72176fba","0a637dc5a2c898a6","113f9804bef90dae","1b710b35131c471b","28db77f523047d84","32caab7b40c72493","3c9ebe0a15c9bebc","431d67c49c100d4c","4cc5d4becb3e42b6","597f299cfc657e2a","5fcb6fab3ad6faec","6c44198c4a475817"].map((x) => BigInt('0x' + x)), MK = [-680876936,-389564586,606105819,-1044525330,-176418897,1200080426,-1473231341,-45705983,1770035416,-1958414417,-42063,-1990404162,1804603682,-40341101,-1502002290,1236535329,-165796510,-1069501632,643717713,-373897302,-701558691,38016083,-660478335,-405537848,568446438,-1019803690,-187363961,1163531501,-1444681467,-51403784,1735328473,-1926607734,-378558,-2022574463,1839030562,-35309556,-1530992060,1272893353,-155497632,-1094730640,681279174,-358537222,-722521979,76029189,-640364487,-421815835,530742520,-995338651,-198630844,1126891415,-1416354905,-57434055,1700485571,-1894986606,-1051523,-2054922799,1873313359,-30611744,-1560198380,1309151649,-145523070,-1120210379,718787259,-343485551], MS = [7,12,17,22,7,12,17,22,7,12,17,22,7,12,17,22,5,9,14,20,5,9,14,20,5,9,14,20,5,9,14,20,4,11,16,23,4,11,16,23,4,11,16,23,4,11,16,23,6,10,15,21,6,10,15,21,6,10,15,21,6,10,15,21];
const enc = new TextEncoder();
const toBytes = (m) => (typeof m === 'string' ? enc.encode(m) : m instanceof Uint8Array ? m : new Uint8Array(m));
const rotr = (x, n) => (x >>> n) | (x << (32 - n));

function sha256(msg) {
  const m = toBytes(msg), l = m.length, padLen = (((l + 9 + 63) >> 6) << 6);
  const b = new Uint8Array(padLen); b.set(m); b[l] = 0x80;
  const dv = new DataView(b.buffer); dv.setUint32(padLen - 4, (l * 8) >>> 0); dv.setUint32(padLen - 8, Math.floor((l * 8) / 4294967296));
  const H = Uint32Array.from(H256), w = new Uint32Array(64);
  for (let o = 0; o < padLen; o += 64) {
    for (let i = 0; i < 16; i++) w[i] = dv.getUint32(o + i * 4);
    for (let i = 16; i < 64; i++) { const a = w[i - 15], c = w[i - 2]; const s0 = rotr(a, 7) ^ rotr(a, 18) ^ (a >>> 3), s1 = rotr(c, 17) ^ rotr(c, 19) ^ (c >>> 10); w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0; }
    let [a, b2, c, d, e, f, g, h] = H;
    for (let i = 0; i < 64; i++) {
      const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25), ch = (e & f) ^ (~e & g), t1 = (h + S1 + ch + K256[i] + w[i]) | 0;
      const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22), mj = (a & b2) ^ (a & c) ^ (b2 & c), t2 = (S0 + mj) | 0;
      h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b2; b2 = a; a = (t1 + t2) | 0;
    }
    H[0] += a; H[1] += b2; H[2] += c; H[3] += d; H[4] += e; H[5] += f; H[6] += g; H[7] += h;
  }
  const out = new Uint8Array(32), ov = new DataView(out.buffer); H.forEach((x, i) => ov.setUint32(i * 4, x)); return out;
}

const M64 = (1n << 64n) - 1n;
const r64 = (x, n) => ((x >> BigInt(n)) | (x << BigInt(64 - n))) & M64;
function sha512(msg) {
  const m = toBytes(msg), l = m.length, padLen = (((l + 17 + 127) >> 7) << 7);
  const b = new Uint8Array(padLen); b.set(m); b[l] = 0x80;
  const dv = new DataView(b.buffer); dv.setUint32(padLen - 4, (l * 8) >>> 0); dv.setUint32(padLen - 8, Math.floor((l * 8) / 4294967296));
  const H = H512.map((x) => BigInt('0x' + x)), K = K512B, w = new Array(80);
  for (let o = 0; o < padLen; o += 128) {
    for (let i = 0; i < 16; i++) w[i] = (BigInt(dv.getUint32(o + i * 8)) << 32n) | BigInt(dv.getUint32(o + i * 8 + 4));
    for (let i = 16; i < 80; i++) { const a = w[i - 15], c = w[i - 2]; const s0 = r64(a, 1) ^ r64(a, 8) ^ (a >> 7n), s1 = r64(c, 19) ^ r64(c, 61) ^ (c >> 6n); w[i] = (w[i - 16] + s0 + w[i - 7] + s1) & M64; }
    let [a, b2, c, d, e, f, g, h] = H;
    for (let i = 0; i < 80; i++) {
      const S1 = r64(e, 14) ^ r64(e, 18) ^ r64(e, 41), ch = (e & f) ^ (~e & M64 & g), t1 = (h + S1 + ch + K[i] + w[i]) & M64;
      const S0 = r64(a, 28) ^ r64(a, 34) ^ r64(a, 39), mj = (a & b2) ^ (a & c) ^ (b2 & c), t2 = (S0 + mj) & M64;
      h = g; g = f; f = e; e = (d + t1) & M64; d = c; c = b2; b2 = a; a = (t1 + t2) & M64;
    }
    [a, b2, c, d, e, f, g, h].forEach((x, i) => { H[i] = (H[i] + x) & M64; });
  }
  const out = new Uint8Array(64), ov = new DataView(out.buffer);
  H.forEach((x, i) => { ov.setUint32(i * 8, Number(x >> 32n)); ov.setUint32(i * 8 + 4, Number(x & 0xffffffffn)); }); return out;
}

function md5(msg) {
  const m = toBytes(msg), l = m.length, padLen = (((l + 9 + 63) >> 6) << 6);
  const b = new Uint8Array(padLen); b.set(m); b[l] = 0x80;
  const dv = new DataView(b.buffer); dv.setUint32(padLen - 8, (l * 8) >>> 0, true); dv.setUint32(padLen - 4, Math.floor((l * 8) / 4294967296), true);
  let a0 = 0x67452301, b0 = 0xefcdab89 | 0, c0 = 0x98badcfe | 0, d0 = 0x10325476;
  for (let o = 0; o < padLen; o += 64) {
    let A = a0, B = b0, C = c0, D = d0;
    for (let i = 0; i < 64; i++) {
      let F, g;
      if (i < 16) { F = (B & C) | (~B & D); g = i; } else if (i < 32) { F = (D & B) | (~D & C); g = (5 * i + 1) % 16; } else if (i < 48) { F = B ^ C ^ D; g = (3 * i + 5) % 16; } else { F = C ^ (B | ~D); g = (7 * i) % 16; }
      F = (F + A + MK[i] + dv.getUint32(o + g * 4, true)) | 0; A = D; D = C; C = B; B = (B + ((F << MS[i]) | (F >>> (32 - MS[i])))) | 0;
    }
    a0 = (a0 + A) | 0; b0 = (b0 + B) | 0; c0 = (c0 + C) | 0; d0 = (d0 + D) | 0;
  }
  const out = new Uint8Array(16), ov = new DataView(out.buffer); [a0, b0, c0, d0].forEach((x, i) => ov.setUint32(i * 4, x >>> 0, true)); return out;
}

const ALGO = { sha256: [sha256, 64], sha512: [sha512, 128], md5: [md5, 64] };
const hex = (u) => Array.from(u, (x) => x.toString(16).padStart(2, '0')).join('');
const b64 = (u) => { let s = ''; for (let i = 0; i < u.length; i++) s += String.fromCharCode(u[i]); return btoa(s); };
const fmt = (u, e) => (e === 'hex' ? hex(u) : e === 'base64' ? b64(u) : u);
const concat = (a, b) => { const r = new Uint8Array(a.length + b.length); r.set(a); r.set(b, a.length); return r; };

function createHash(algo) {
  const e = ALGO[algo]; if (!e) throw new Error('algo ' + algo);
  let buf = new Uint8Array(0);
  const o = { update(d) { buf = concat(buf, toBytes(d)); return o; }, digest(encn) { return fmt(e[0](buf), encn); } };
  return o;
}
function createHmac(algo, key) {
  const e = ALGO[algo]; if (!e) throw new Error('algo ' + algo);
  const [fn, bs] = e; let k = toBytes(key); if (k.length > bs) k = fn(k);
  const kp = new Uint8Array(bs); kp.set(k);
  const ip = kp.map((x) => x ^ 0x36), op = kp.map((x) => x ^ 0x5c);
  let buf = new Uint8Array(0);
  const o = { update(d) { buf = concat(buf, toBytes(d)); return o; }, digest(encn) { return fmt(fn(concat(op, fn(concat(ip, buf)))), encn); } };
  return o;
}
function randomBytes(n) {
  const u = new Uint8Array(n); crypto.getRandomValues(u);
  return { toString: (e) => (e === 'hex' ? hex(u) : String.fromCharCode(...u)) };
}
module.exports = { createHash, createHmac, randomBytes };

};
__defs["./exchanges.js"] = function (module, exports, require) {
'use strict';
/**
 * ترید یار — اتصال واقعی به صرافی‌ها (بازار، تحلیل و معامله)
 * ------------------------------------------------------------------
 * هر کانکتور این توابع را دارد (همه با امضای واقعی API رسمی هر صرافی):
 *   markets()                      → فهرست همهٔ جفت‌ارزهای قابل معامله + قوانین دقت/حداقل
 *   tickers()                      → قیمت و حجم ۲۴ساعتهٔ همهٔ جفت‌ارزها
 *   klines(symbol, interval, n)    → کندل‌ها [ts,o,h,l,c,v] صعودی
 *   balance(creds)                 → موجودی‌ها
 *   placeOrder(creds, order)       → ثبت سفارش واقعی (یا تست، اگر صرافی پشتیبانی کند)
 *   protect(creds, plan)           → حد ضرر/سود بومی صرافی (اگر پشتیبانی شود)
 *   positions(creds) / closePosition(creds, ...)   → فقط بازارهای فیوچرز
 *
 * کلیدهای API هیچ‌جا ذخیره یا لاگ نمی‌شوند؛ فقط برای امضای همان درخواست استفاده می‌شوند.
 */

const crypto = require('node:crypto');

/* ------------------------------ ابزارها ------------------------------ */

class ExchangeError extends Error {
  constructor(message, { code, status, raw } = {}) {
    super(message);
    this.name = 'ExchangeError';
    this.exCode = code;
    this.exStatus = status;
    this.raw = raw;
  }
}

const hmac = (algo, secret, msg, enc = 'hex') => crypto.createHmac(algo, secret).update(msg).digest(enc);
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const sha512 = (s) => crypto.createHash('sha512').update(s).digest('hex');
const md5 = (s) => crypto.createHash('md5').update(s).digest('hex');
const num = (x) => { const n = Number(x); return Number.isFinite(n) ? n : 0; };
const rnd = (len = 32) => crypto.randomBytes(len).toString('hex').slice(0, len);

const cleanObj = (o) => {
  const r = {};
  for (const k of Object.keys(o || {})) if (o[k] !== undefined && o[k] !== null && o[k] !== '') r[k] = o[k];
  return r;
};
const qs = (o) => Object.entries(cleanObj(o)).map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&');
const qsRaw = (o) => Object.entries(cleanObj(o)).map(([k, v]) => `${k}=${v}`).join('&');
const sortedKeys = (o) => Object.keys(cleanObj(o)).sort();

/* تعداد رقم اعشار یک step مثل 0.001 → 3 (با پشتیبانی از 1e-7) */
function decimalsOf(step) {
  const n = Number(step);
  if (!(n > 0)) return 8;
  const s = String(n);
  if (s.includes('e-')) {
    const [m, e] = s.split('e-');
    return parseInt(e, 10) + ((m.split('.')[1] || '').length);
  }
  const i = s.indexOf('.');
  return i < 0 ? 0 : s.length - i - 1;
}
const stepFromDecimals = (d) => (Number.isInteger(+d) && +d >= 0 ? Number((10 ** -d).toFixed(Math.min(+d, 20))) : 0);

/* گرد کردن رو به پایین به مضرب step و برگرداندن رشتهٔ بدون نماد علمی */
function floorToStep(value, step) {
  const v = Number(value);
  if (!(v > 0)) return '0';
  if (!(step > 0)) return String(v);
  const d = decimalsOf(step);
  const units = Math.floor(v / step + 1e-9);
  return (units * step).toFixed(Math.min(d, 20));
}

const STABLES = new Set(['USDT', 'USDC', 'USD', 'BUSD', 'FDUSD', 'TUSD', 'DAI', 'EUR', 'TRY', 'USDD']);
const normInterval = (iv) => (['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w'].includes(iv) ? iv : '1h');
const IV_SEC = { '1m': 60, '5m': 300, '15m': 900, '30m': 1800, '1h': 3600, '4h': 14400, '1d': 86400, '1w': 604800 };

/* خروجی استاندارد بازار */
function mkMarket(o) {
  const m = {
    symbol: o.symbol, base: String(o.base || '').toUpperCase(), quote: String(o.quote || '').toUpperCase(),
    tickSize: num(o.tickSize), stepSize: num(o.stepSize), minQty: num(o.minQty), minNotional: num(o.minNotional),
    trading: o.trading !== false, type: o.type || 'spot',
  };
  if (o.maxLeverage) m.maxLeverage = num(o.maxLeverage);
  return m;
}

/* اعتبارسنجی و گردکردن سفارش بر اساس قوانین بازار؛ خروجی: مقادیر آمادهٔ ارسال (رشته) */
function prepareOrder(market, o) {
  const side = String(o.side || '').toLowerCase();
  const type = String(o.type || 'market').toLowerCase();
  if (side !== 'buy' && side !== 'sell') throw new ExchangeError('side نامعتبر است', { code: 'bad_side' });
  if (type !== 'market' && type !== 'limit') throw new ExchangeError('type نامعتبر است', { code: 'bad_type' });
  if (!market) throw new ExchangeError('جفت‌ارز در این صرافی پیدا نشد', { code: 'unknown_symbol' });
  if (market.trading === false) throw new ExchangeError('معامله روی این جفت‌ارز فعلاً غیرفعال است', { code: 'not_trading' });
  const out = { side, type, market };
  const quoteDec = STABLES.has(market.quote) ? 2 : 8;
  if (type === 'limit') {
    const price = Number(o.price);
    if (!(price > 0)) throw new ExchangeError('قیمت نامعتبر است', { code: 'bad_price' });
    out.price = market.tickSize > 0 ? floorToStep(price, market.tickSize) : String(price);
    const qty = Number(o.qty);
    if (!(qty > 0)) throw new ExchangeError('حجم نامعتبر است', { code: 'bad_qty' });
    out.qty = market.stepSize > 0 ? floorToStep(qty, market.stepSize) : String(qty);
    if (!(Number(out.qty) > 0)) throw new ExchangeError('حجم بعد از گرد کردن صفر شد (کمتر از حداقل گام)', { code: 'below_step' });
    if (market.minQty && Number(out.qty) < market.minQty) throw new ExchangeError('حجم کمتر از حداقل مجاز صرافی است (' + market.minQty + ')', { code: 'below_min_qty' });
    if (market.minNotional && Number(out.qty) * Number(out.price) < market.minNotional) throw new ExchangeError('ارزش سفارش کمتر از حداقل صرافی است (' + market.minNotional + ' ' + market.quote + ')', { code: 'below_min_notional' });
    return out;
  }
  // سفارش مارکت
  if (market.type === 'futures' || side === 'sell') {
    const qty = Number(o.qty);
    if (!(qty > 0)) throw new ExchangeError('حجم نامعتبر است', { code: 'bad_qty' });
    out.qty = market.stepSize > 0 ? floorToStep(qty, market.stepSize) : String(qty);
    if (!(Number(out.qty) > 0)) throw new ExchangeError('حجم بعد از گرد کردن صفر شد', { code: 'below_step' });
    if (market.minQty && Number(out.qty) < market.minQty) throw new ExchangeError('حجم کمتر از حداقل مجاز صرافی است (' + market.minQty + ')', { code: 'below_min_qty' });
    return out;
  }
  // خرید مارکت اسپات: مبلغ به واحد quote
  const qq = Number(o.quoteQty);
  if (!(qq > 0)) throw new ExchangeError('مبلغ خرید نامعتبر است', { code: 'bad_quote_qty' });
  out.quoteQty = (Math.floor(qq * 10 ** quoteDec + 1e-9) / 10 ** quoteDec).toFixed(quoteDec);
  if (market.minNotional && Number(out.quoteQty) < market.minNotional) throw new ExchangeError('مبلغ خرید کمتر از حداقل صرافی است (' + market.minNotional + ' ' + market.quote + ')', { code: 'below_min_notional' });
  return out;
}

/* ------------------------- کانکتور پایه (ساختار مشترک) ------------------------- */

/**
 * ctx = { http(method,url,{headers,body}) → {status,json,text}, now(), nonce() }
 * کانکتورها فقط درخواست می‌سازند/امضا می‌کنند؛ شبکه را ctx انجام می‌دهد.
 */

const need = (creds, ...fields) => {
  for (const f of fields) if (!creds || !creds[f]) throw new ExchangeError('فیلد ' + f + ' برای این صرافی لازم است', { code: 'missing_' + f });
};
const bad = (msg, code, raw) => new ExchangeError(msg, { code, raw });

/* ============================ Binance / MEXC (خانوادهٔ مشابه) ============================ */

function binanceLike({ id, name, base, headerName, ivMap, mexc }) {
  const signed = async (ctx, creds, method, path, params = {}) => {
    need(creds, 'apiKey', 'apiSecret');
    const p = cleanObj({ ...params, recvWindow: 10000, timestamp: ctx.now() });
    const query = qs(p);
    const signature = hmac('sha256', creds.apiSecret, query);
    const r = await ctx.http(method, `${base}${path}?${query}&signature=${signature}`, { headers: { [headerName]: creds.apiKey } });
    return unwrap(r);
  };
  const unwrap = (r) => {
    const j = r.json;
    if (r.status >= 400 || (j && typeof j === 'object' && !Array.isArray(j) && j.code && Number(j.code) < 0) || (mexc && j && j.code && Number(j.code) !== 200 && j.msg)) {
      throw new ExchangeError((j && (j.msg || j.message)) || 'خطای صرافی ' + r.status, { code: j && j.code, status: r.status, raw: j });
    }
    return j;
  };
  const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));

  return {
    id, name, type: 'spot', needsPassphrase: false, hosts: [new URL(base).hostname],
    async markets(ctx) {
      const j = await pub(ctx, '/api/v3/exchangeInfo');
      return (j.symbols || []).map((s) => {
        const f = {};
        (s.filters || []).forEach((x) => { f[x.filterType] = x; });
        const active = mexc ? (String(s.status) === '1' || String(s.status).toUpperCase() === 'ENABLED') && s.isSpotTradingAllowed !== false : s.status === 'TRADING' && s.isSpotTradingAllowed !== false;
        let tick = f.PRICE_FILTER ? num(f.PRICE_FILTER.tickSize) : 0;
        let step = f.LOT_SIZE ? num(f.LOT_SIZE.stepSize) : 0;
        let minQty = f.LOT_SIZE ? num(f.LOT_SIZE.minQty) : 0;
        let minNot = f.NOTIONAL ? num(f.NOTIONAL.minNotional) : f.MIN_NOTIONAL ? num(f.MIN_NOTIONAL.minNotional) : 0;
        if (mexc) {
          tick = tick || stepFromDecimals(s.quoteAssetPrecision != null ? s.quoteAssetPrecision : s.quotePrecision);
          step = step || num(s.baseSizePrecision) || stepFromDecimals(s.baseAssetPrecision);
          minNot = minNot || num(s.quoteAmountPrecision);
        }
        return mkMarket({ symbol: s.symbol, base: s.baseAsset, quote: s.quoteAsset, trading: active, tickSize: tick, stepSize: step, minQty, minNotional: minNot });
      });
    },
    async tickers(ctx) {
      const j = await pub(ctx, '/api/v3/ticker/24hr');
      return (Array.isArray(j) ? j : []).map((t) => {
        const last = num(t.lastPrice), open = num(t.openPrice);
        return { symbol: t.symbol, last, changePct: open > 0 ? ((last - open) / open) * 100 : num(t.priceChangePercent), quoteVol: num(t.quoteVolume), high: num(t.highPrice), low: num(t.lowPrice) };
      });
    },
    async klines(ctx, symbol, interval, limit) {
      const iv = ivMap[normInterval(interval)];
      const j = await pub(ctx, '/api/v3/klines', { symbol, interval: iv, limit: Math.min(limit || 300, 1000) });
      return (Array.isArray(j) ? j : []).map((k) => [num(k[0]), num(k[1]), num(k[2]), num(k[3]), num(k[4]), num(k[5])]);
    },
    async balance(ctx, creds) {
      const j = await signed(ctx, creds, 'GET', '/api/v3/account');
      return { balances: (j.balances || []).map((b) => ({ asset: b.asset, free: num(b.free), locked: num(b.locked) })).filter((b) => b.free > 0 || b.locked > 0), canTrade: j.canTrade !== false, canWithdraw: j.canWithdraw === true };
    },
    async placeOrder(ctx, creds, o) {
      const m = o.market;
      const params = { symbol: m.symbol, side: o.side.toUpperCase(), type: o.type.toUpperCase() };
      if (o.type === 'limit') { params.quantity = o.qty; params.price = o.price; params.timeInForce = 'GTC'; }
      else if (o.quoteQty) params.quoteOrderQty = o.quoteQty;
      else params.quantity = o.qty;
      if (o.clientId) params.newClientOrderId = o.clientId;
      const j = await signed(ctx, creds, 'POST', o.test ? '/api/v3/order/test' : '/api/v3/order', params);
      return { orderId: String((j && (j.orderId || j.orderListId)) || ''), status: j && j.status, filledQty: num(j && j.executedQty), quoteSpent: num(j && j.cummulativeQuoteQty), raw: j };
    },
    async openOrders(ctx, creds, symbol) {
      const j = await signed(ctx, creds, 'GET', '/api/v3/openOrders', { symbol });
      return (Array.isArray(j) ? j : []).map((x) => ({ orderId: String(x.orderId), symbol: x.symbol, side: String(x.side).toLowerCase(), type: String(x.type).toLowerCase(), price: num(x.price), qty: num(x.origQty), filled: num(x.executedQty), status: x.status, time: x.time }));
    },
    async cancelOrder(ctx, creds, symbol, orderId) {
      const j = await signed(ctx, creds, 'DELETE', '/api/v3/order', { symbol, orderId });
      return { orderId: String(orderId), raw: j };
    },
    /* OCO فروش بومی (فقط Binance): حد سود + حد ضرر، هر کدام فعال شد دیگری لغو می‌شود */
    async protect(ctx, creds, p) {
      if (mexc) return { native: false, reason: 'unsupported' };
      const m = p.market;
      const params = {
        symbol: m.symbol, side: 'SELL', quantity: p.qty,
        aboveType: 'LIMIT_MAKER', abovePrice: floorToStep(p.tp, m.tickSize),
        belowType: 'STOP_LOSS_LIMIT', belowStopPrice: floorToStep(p.sl, m.tickSize),
        belowPrice: floorToStep(p.sl * 0.995, m.tickSize), belowTimeInForce: 'GTC',
      };
      const j = await signed(ctx, creds, 'POST', '/api/v3/orderList/oco', params);
      return { native: true, orderId: String((j && j.orderListId) || ''), raw: j };
    },
  };
}

const BINANCE_IV = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1h', '4h': '4h', '1d': '1d', '1w': '1w' };
const MEXC_IV = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '60m', '4h': '4h', '1d': '1d', '1w': '1W' };

/* ================================== Bybit v5 ================================== */

function bybit() {
  const base = 'https://api.bybit.com';
  const IV = { '1m': '1', '5m': '5', '15m': '15', '30m': '30', '1h': '60', '4h': '240', '1d': 'D', '1w': 'W' };
  const unwrap = (r) => {
    const j = r.json;
    if (r.status >= 400 || !j || Number(j.retCode) !== 0) throw new ExchangeError((j && j.retMsg) || 'خطای Bybit ' + r.status, { code: j && j.retCode, status: r.status, raw: j });
    return j.result;
  };
  const call = async (ctx, creds, method, path, params, body) => {
    need(creds, 'apiKey', 'apiSecret');
    const ts = String(ctx.now()), recv = '10000';
    const query = method === 'GET' ? qs(params || {}) : '';
    const bodyStr = body ? JSON.stringify(body) : '';
    const sign = hmac('sha256', creds.apiSecret, ts + creds.apiKey + recv + (method === 'GET' ? query : bodyStr));
    const headers = { 'X-BAPI-API-KEY': creds.apiKey, 'X-BAPI-TIMESTAMP': ts, 'X-BAPI-RECV-WINDOW': recv, 'X-BAPI-SIGN': sign, 'Content-Type': 'application/json' };
    return unwrap(await ctx.http(method, `${base}${path}${query ? '?' + query : ''}`, { headers, body: bodyStr || undefined }));
  };
  const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}?${qs(params)}`, {}));
  return {
    id: 'bybit', name: 'Bybit', type: 'spot', needsPassphrase: false, hosts: ['api.bybit.com'],
    async markets(ctx) {
      const r = await pub(ctx, '/v5/market/instruments-info', { category: 'spot', limit: 1000 });
      return (r.list || []).map((s) => mkMarket({
        symbol: s.symbol, base: s.baseCoin, quote: s.quoteCoin, trading: s.status === 'Trading',
        tickSize: num(s.priceFilter && s.priceFilter.tickSize), stepSize: num(s.lotSizeFilter && s.lotSizeFilter.basePrecision),
        minQty: num(s.lotSizeFilter && s.lotSizeFilter.minOrderQty), minNotional: num(s.lotSizeFilter && s.lotSizeFilter.minOrderAmt),
      }));
    },
    async tickers(ctx) {
      const r = await pub(ctx, '/v5/market/tickers', { category: 'spot' });
      return (r.list || []).map((t) => ({ symbol: t.symbol, last: num(t.lastPrice), changePct: num(t.price24hPcnt) * 100, quoteVol: num(t.turnover24h), high: num(t.highPrice24h), low: num(t.lowPrice24h) }));
    },
    async klines(ctx, symbol, interval, limit) {
      const r = await pub(ctx, '/v5/market/kline', { category: 'spot', symbol, interval: IV[normInterval(interval)], limit: Math.min(limit || 300, 1000) });
      return (r.list || []).map((k) => [num(k[0]), num(k[1]), num(k[2]), num(k[3]), num(k[4]), num(k[5])]).reverse();
    },
    async balance(ctx, creds) {
      const r = await call(ctx, creds, 'GET', '/v5/account/wallet-balance', { accountType: 'UNIFIED' });
      const coins = (r.list && r.list[0] && r.list[0].coin) || [];
      return { balances: coins.map((c) => { const wb = num(c.walletBalance), lk = num(c.locked); return { asset: c.coin, free: Math.max(0, wb - lk), locked: lk }; }).filter((b) => b.free > 0 || b.locked > 0), canTrade: true };
    },
    async placeOrder(ctx, creds, o) {
      if (o.test) throw new ExchangeError('Bybit حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
      const body = { category: 'spot', symbol: o.market.symbol, side: o.side === 'buy' ? 'Buy' : 'Sell', orderType: o.type === 'limit' ? 'Limit' : 'Market' };
      if (o.type === 'limit') { body.qty = o.qty; body.price = o.price; body.timeInForce = 'GTC'; }
      else if (o.quoteQty) { body.qty = o.quoteQty; body.marketUnit = 'quoteCoin'; }
      else { body.qty = o.qty; body.marketUnit = 'baseCoin'; }
      if (o.clientId) body.orderLinkId = o.clientId;
      const r = await call(ctx, creds, 'POST', '/v5/order/create', null, body);
      return { orderId: String(r.orderId || ''), raw: r };
    },
  };
}

/* =================================== OKX v5 =================================== */

function okx() {
  const base = 'https://www.okx.com';
  const IV = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1H', '4h': '4H', '1d': '1D', '1w': '1W' };
  const unwrap = (r) => {
    const j = r.json;
    if (r.status >= 400 || !j || String(j.code) !== '0') {
      const d = j && j.data && j.data[0];
      throw new ExchangeError((d && d.sMsg) || (j && j.msg) || 'خطای OKX ' + r.status, { code: (d && d.sCode) || (j && j.code), status: r.status, raw: j });
    }
    const d = j.data && j.data[0];
    if (d && d.sCode !== undefined && String(d.sCode) !== '0') throw new ExchangeError(d.sMsg || 'سفارش رد شد', { code: d.sCode, raw: j });
    return j.data;
  };
  const call = async (ctx, creds, method, path, params, body) => {
    need(creds, 'apiKey', 'apiSecret', 'passphrase');
    const ts = new Date(ctx.now()).toISOString();
    const reqPath = path + (params && Object.keys(cleanObj(params)).length ? '?' + qs(params) : '');
    const bodyStr = body ? JSON.stringify(body) : '';
    const sign = hmac('sha256', creds.apiSecret, ts + method + reqPath + bodyStr, 'base64');
    const headers = { 'OK-ACCESS-KEY': creds.apiKey, 'OK-ACCESS-SIGN': sign, 'OK-ACCESS-TIMESTAMP': ts, 'OK-ACCESS-PASSPHRASE': creds.passphrase, 'Content-Type': 'application/json' };
    return unwrap(await ctx.http(method, base + reqPath, { headers, body: bodyStr || undefined }));
  };
  const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}?${qs(params)}`, {}));
  return {
    id: 'okx', name: 'OKX', type: 'spot', needsPassphrase: true, hosts: ['www.okx.com'],
    async markets(ctx) {
      const d = await pub(ctx, '/api/v5/public/instruments', { instType: 'SPOT' });
      return d.map((s) => mkMarket({ symbol: s.instId, base: s.baseCcy, quote: s.quoteCcy, trading: s.state === 'live', tickSize: num(s.tickSz), stepSize: num(s.lotSz), minQty: num(s.minSz) }));
    },
    async tickers(ctx) {
      const d = await pub(ctx, '/api/v5/market/tickers', { instType: 'SPOT' });
      return d.map((t) => { const last = num(t.last), open = num(t.open24h); return { symbol: t.instId, last, changePct: open > 0 ? ((last - open) / open) * 100 : 0, quoteVol: num(t.volCcy24h), high: num(t.high24h), low: num(t.low24h) }; });
    },
    async klines(ctx, symbol, interval, limit) {
      const d = await pub(ctx, '/api/v5/market/candles', { instId: symbol, bar: IV[normInterval(interval)], limit: Math.min(limit || 300, 300) });
      return d.map((k) => [num(k[0]), num(k[1]), num(k[2]), num(k[3]), num(k[4]), num(k[5])]).reverse();
    },
    async balance(ctx, creds) {
      const d = await call(ctx, creds, 'GET', '/api/v5/account/balance', {});
      const det = (d[0] && d[0].details) || [];
      return { balances: det.map((x) => ({ asset: x.ccy, free: num(x.availBal), locked: num(x.frozenBal) })).filter((b) => b.free > 0 || b.locked > 0), canTrade: true };
    },
    async placeOrder(ctx, creds, o) {
      if (o.test) throw new ExchangeError('OKX حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
      const body = { instId: o.market.symbol, tdMode: 'cash', side: o.side, ordType: o.type };
      if (o.type === 'limit') { body.sz = o.qty; body.px = o.price; }
      else if (o.quoteQty) { body.sz = o.quoteQty; body.tgtCcy = 'quote_ccy'; }
      else { body.sz = o.qty; body.tgtCcy = 'base_ccy'; }
      if (o.clientId) body.clOrdId = o.clientId;
      const d = await call(ctx, creds, 'POST', '/api/v5/trade/order', null, body);
      return { orderId: String((d[0] && d[0].ordId) || ''), raw: d };
    },
    /* OCO بومی OKX (اسپات): فروش با حد سود/ضرر مارکت */
    async protect(ctx, creds, p) {
      const body = { instId: p.market.symbol, tdMode: 'cash', side: 'sell', ordType: 'oco', sz: p.qty, tpTriggerPx: floorToStep(p.tp, p.market.tickSize), tpOrdPx: '-1', slTriggerPx: floorToStep(p.sl, p.market.tickSize), slOrdPx: '-1' };
      const d = await call(ctx, creds, 'POST', '/api/v5/trade/order-algo', null, body);
      return { native: true, orderId: String((d[0] && d[0].algoId) || ''), raw: d };
    },
  };
}

/* ================================== KuCoin ================================== */

function kucoin() {
  const base = 'https://api.kucoin.com';
  const IV = { '1m': '1min', '5m': '5min', '15m': '15min', '30m': '30min', '1h': '1hour', '4h': '4hour', '1d': '1day', '1w': '1week' };
  const unwrap = (r) => {
    const j = r.json;
    if (r.status >= 400 || !j || String(j.code) !== '200000') throw new ExchangeError((j && j.msg) || 'خطای KuCoin ' + r.status, { code: j && j.code, status: r.status, raw: j });
    return j.data;
  };
  const call = async (ctx, creds, method, path, params, body) => {
    need(creds, 'apiKey', 'apiSecret', 'passphrase');
    const ts = String(ctx.now());
    const ep = path + (params && Object.keys(cleanObj(params)).length ? '?' + qs(params) : '');
    const bodyStr = body ? JSON.stringify(body) : '';
    const headers = {
      'KC-API-KEY': creds.apiKey, 'KC-API-TIMESTAMP': ts, 'KC-API-KEY-VERSION': '2', 'Content-Type': 'application/json',
      'KC-API-SIGN': hmac('sha256', creds.apiSecret, ts + method + ep + bodyStr, 'base64'),
      'KC-API-PASSPHRASE': hmac('sha256', creds.apiSecret, creds.passphrase, 'base64'),
    };
    return unwrap(await ctx.http(method, base + ep, { headers, body: bodyStr || undefined }));
  };
  const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));
  return {
    id: 'kucoin', name: 'KuCoin', type: 'spot', needsPassphrase: true, hosts: ['api.kucoin.com'],
    async markets(ctx) {
      const d = await pub(ctx, '/api/v2/symbols');
      return d.map((s) => mkMarket({ symbol: s.symbol, base: s.baseCurrency, quote: s.quoteCurrency, trading: s.enableTrading !== false, tickSize: num(s.priceIncrement), stepSize: num(s.baseIncrement), minQty: num(s.baseMinSize), minNotional: num(s.minFunds || s.quoteMinSize) }));
    },
    async tickers(ctx) {
      const d = await pub(ctx, '/api/v1/market/allTickers');
      return ((d && d.ticker) || []).map((t) => ({ symbol: t.symbol, last: num(t.last), changePct: num(t.changeRate) * 100, quoteVol: num(t.volValue), high: num(t.high), low: num(t.low) }));
    },
    async klines(ctx, symbol, interval, limit) {
      const iv = normInterval(interval);
      const end = Math.floor(ctx.now() / 1000), start = end - IV_SEC[iv] * Math.min(limit || 300, 1500);
      const d = await pub(ctx, '/api/v1/market/candles', { symbol, type: IV[iv], startAt: start, endAt: end });
      return (d || []).map((k) => [num(k[0]) * 1000, num(k[1]), num(k[3]), num(k[4]), num(k[2]), num(k[5])]).reverse();
    },
    async balance(ctx, creds) {
      const d = await call(ctx, creds, 'GET', '/api/v1/accounts', { type: 'trade' });
      return { balances: d.map((x) => ({ asset: x.currency, free: num(x.available), locked: num(x.holds) })).filter((b) => b.free > 0 || b.locked > 0), canTrade: true };
    },
    async placeOrder(ctx, creds, o) {
      const body = { clientOid: o.clientId || rnd(24), side: o.side, symbol: o.market.symbol, type: o.type };
      if (o.type === 'limit') { body.size = o.qty; body.price = o.price; }
      else if (o.quoteQty) body.funds = o.quoteQty;
      else body.size = o.qty;
      const d = await call(ctx, creds, 'POST', o.test ? '/api/v1/orders/test' : '/api/v1/orders', null, body);
      return { orderId: String((d && d.orderId) || ''), raw: d };
    },
  };
}

/* ================================ Gate.io v4 ================================ */

function gate() {
  const host = 'https://api.gateio.ws', prefix = '/api/v4';
  const IV = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1h', '4h': '4h', '1d': '1d', '1w': '7d' };
  const unwrap = (r) => {
    const j = r.json;
    if (r.status >= 400 || (j && !Array.isArray(j) && j.label)) throw new ExchangeError((j && (j.message || j.label)) || 'خطای Gate ' + r.status, { code: j && j.label, status: r.status, raw: j });
    return j;
  };
  const call = async (ctx, creds, method, path, params, body) => {
    need(creds, 'apiKey', 'apiSecret');
    const ts = String(Math.floor(ctx.now() / 1000));
    const query = params ? qs(params) : '';
    const bodyStr = body ? JSON.stringify(body) : '';
    const payload = [method, prefix + path, query, sha512(bodyStr), ts].join('\n');
    const headers = { KEY: creds.apiKey, Timestamp: ts, SIGN: hmac('sha512', creds.apiSecret, payload), 'Content-Type': 'application/json', Accept: 'application/json' };
    return unwrap(await ctx.http(method, `${host}${prefix}${path}${query ? '?' + query : ''}`, { headers, body: bodyStr || undefined }));
  };
  const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${host}${prefix}${path}${params ? '?' + qs(params) : ''}`, {}));
  return {
    id: 'gate', name: 'Gate.io', type: 'spot', needsPassphrase: false, hosts: ['api.gateio.ws'],
    async markets(ctx) {
      const d = await pub(ctx, '/spot/currency_pairs');
      return d.map((s) => mkMarket({ symbol: s.id, base: s.base, quote: s.quote, trading: s.trade_status === 'tradable', tickSize: stepFromDecimals(s.precision), stepSize: stepFromDecimals(s.amount_precision), minQty: num(s.min_base_amount), minNotional: num(s.min_quote_amount) }));
    },
    async tickers(ctx) {
      const d = await pub(ctx, '/spot/tickers');
      return d.map((t) => ({ symbol: t.currency_pair, last: num(t.last), changePct: num(t.change_percentage), quoteVol: num(t.quote_volume), high: num(t.high_24h), low: num(t.low_24h) }));
    },
    async klines(ctx, symbol, interval, limit) {
      const d = await pub(ctx, '/spot/candlesticks', { currency_pair: symbol, interval: IV[normInterval(interval)], limit: Math.min(limit || 300, 1000) });
      return d.map((k) => [num(k[0]) * 1000, num(k[5]), num(k[3]), num(k[4]), num(k[2]), num(k[6])]);
    },
    async balance(ctx, creds) {
      const d = await call(ctx, creds, 'GET', '/spot/accounts', {});
      return { balances: d.map((x) => ({ asset: x.currency, free: num(x.available), locked: num(x.locked) })).filter((b) => b.free > 0 || b.locked > 0), canTrade: true };
    },
    async placeOrder(ctx, creds, o) {
      if (o.test) throw new ExchangeError('Gate حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
      const body = { currency_pair: o.market.symbol, side: o.side, type: o.type, account: 'spot', text: 't-' + (o.clientId || rnd(16)) };
      if (o.type === 'limit') { body.amount = o.qty; body.price = o.price; body.time_in_force = 'gtc'; }
      else { body.amount = o.quoteQty || o.qty; body.time_in_force = 'ioc'; }
      const d = await call(ctx, creds, 'POST', '/spot/orders', null, body);
      return { orderId: String((d && d.id) || ''), status: d && d.status, raw: d };
    },
  };
}

/* ================================ Bitget v2 ================================ */

function bitget() {
  const base = 'https://api.bitget.com';
  const IV = { '1m': '1min', '5m': '5min', '15m': '15min', '30m': '30min', '1h': '1h', '4h': '4h', '1d': '1day', '1w': '1week' };
  const unwrap = (r) => {
    const j = r.json;
    if (r.status >= 400 || !j || String(j.code) !== '00000') throw new ExchangeError((j && j.msg) || 'خطای Bitget ' + r.status, { code: j && j.code, status: r.status, raw: j });
    return j.data;
  };
  const call = async (ctx, creds, method, path, params, body) => {
    need(creds, 'apiKey', 'apiSecret', 'passphrase');
    const ts = String(ctx.now());
    const query = params ? qs(params) : '';
    const bodyStr = body ? JSON.stringify(body) : '';
    const headers = {
      'ACCESS-KEY': creds.apiKey, 'ACCESS-TIMESTAMP': ts, 'ACCESS-PASSPHRASE': creds.passphrase, 'Content-Type': 'application/json', locale: 'en-US',
      'ACCESS-SIGN': hmac('sha256', creds.apiSecret, ts + method + path + (query ? '?' + query : '') + bodyStr, 'base64'),
    };
    return unwrap(await ctx.http(method, `${base}${path}${query ? '?' + query : ''}`, { headers, body: bodyStr || undefined }));
  };
  const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));
  return {
    id: 'bitget', name: 'Bitget', type: 'spot', needsPassphrase: true, hosts: ['api.bitget.com'],
    async markets(ctx) {
      const d = await pub(ctx, '/api/v2/spot/public/symbols');
      return d.map((s) => mkMarket({ symbol: s.symbol, base: s.baseCoin, quote: s.quoteCoin, trading: s.status === 'online', tickSize: stepFromDecimals(s.pricePrecision), stepSize: stepFromDecimals(s.quantityPrecision), minQty: num(s.minTradeAmount), minNotional: num(s.minTradeUSDT) }));
    },
    async tickers(ctx) {
      const d = await pub(ctx, '/api/v2/spot/market/tickers');
      return d.map((t) => { const last = num(t.lastPr), open = num(t.open); return { symbol: t.symbol, last, changePct: open > 0 ? ((last - open) / open) * 100 : num(t.change24h) * 100, quoteVol: num(t.quoteVolume), high: num(t.high24h), low: num(t.low24h) }; });
    },
    async klines(ctx, symbol, interval, limit) {
      const d = await pub(ctx, '/api/v2/spot/market/candles', { symbol, granularity: IV[normInterval(interval)], limit: Math.min(limit || 300, 1000) });
      return d.map((k) => [num(k[0]), num(k[1]), num(k[2]), num(k[3]), num(k[4]), num(k[5])]).sort((a, b) => a[0] - b[0]);
    },
    async balance(ctx, creds) {
      const d = await call(ctx, creds, 'GET', '/api/v2/spot/account/assets', {});
      return { balances: d.map((x) => ({ asset: x.coin, free: num(x.available), locked: num(x.frozen) + num(x.locked) })).filter((b) => b.free > 0 || b.locked > 0), canTrade: true };
    },
    async placeOrder(ctx, creds, o) {
      if (o.test) throw new ExchangeError('Bitget حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
      const body = { symbol: o.market.symbol, side: o.side, orderType: o.type, force: 'gtc', clientOid: o.clientId || rnd(24) };
      if (o.type === 'limit') { body.price = o.price; body.size = o.qty; }
      else body.size = o.quoteQty || o.qty; // خرید مارکت: مبلغ quote | فروش مارکت: مقدار base
      const d = await call(ctx, creds, 'POST', '/api/v2/spot/trade/place-order', null, body);
      return { orderId: String((d && d.orderId) || ''), raw: d };
    },
  };
}

/* ================================== LBank v2 ================================== */

function lbank() {
  const base = 'https://api.lbkex.com';
  const IV = { '1m': 'minute1', '5m': 'minute5', '15m': 'minute15', '30m': 'minute30', '1h': 'hour1', '4h': 'hour4', '1d': 'day1', '1w': 'week1' };
  const unwrap = (r) => {
    const j = r.json;
    if (r.status >= 400 || !j || (String(j.result) !== 'true' && j.result !== true)) throw new ExchangeError('خطای LBank (کد ' + ((j && j.error_code) || r.status) + ')' + (j && j.msg ? ': ' + j.msg : ''), { code: j && j.error_code, status: r.status, raw: j });
    return j.data;
  };
  /* امضا: پارامترها مرتب → MD5 با حروف بزرگ → HmacSHA256 */
  const call = async (ctx, creds, path, params) => {
    need(creds, 'apiKey', 'apiSecret');
    const sys = { api_key: creds.apiKey, signature_method: 'HmacSHA256', timestamp: String(ctx.now()), echostr: rnd(35) };
    const all = cleanObj({ ...(params || {}), ...sys });
    const prepared = sortedKeys(all).map((k) => `${k}=${all[k]}`).join('&');
    const sign = hmac('sha256', creds.apiSecret, md5(prepared).toUpperCase());
    const body = qs({ ...all, sign });
    const headers = { 'Content-Type': 'application/x-www-form-urlencoded', contentType: 'application/x-www-form-urlencoded', timestamp: sys.timestamp, signature_method: sys.signature_method, echostr: sys.echostr };
    return unwrap(await ctx.http('POST', base + path, { headers, body }));
  };
  const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));
  return {
    id: 'lbank', name: 'LBank', type: 'spot', needsPassphrase: false, hosts: ['api.lbkex.com'],
    async markets(ctx) {
      const d = await pub(ctx, '/v2/accuracy.do');
      return (d || []).map((s) => {
        const [b, q] = String(s.symbol).split('_');
        return mkMarket({ symbol: s.symbol, base: b, quote: q, tickSize: stepFromDecimals(num(s.priceAccuracy)), stepSize: stepFromDecimals(num(s.quantityAccuracy)), minQty: num(s.minTranQua) });
      });
    },
    async tickers(ctx) {
      const d = await pub(ctx, '/v2/ticker/24hr.do', { symbol: 'all' });
      return (d || []).map((t) => ({ symbol: t.symbol, last: num(t.ticker && t.ticker.latest), changePct: num(t.ticker && t.ticker.change), quoteVol: num(t.ticker && t.ticker.turnover), high: num(t.ticker && t.ticker.high), low: num(t.ticker && t.ticker.low) }));
    },
    async klines(ctx, symbol, interval, limit) {
      const iv = normInterval(interval), size = Math.min(limit || 300, 2000);
      const d = await pub(ctx, '/v2/kline.do', { symbol, size, type: IV[iv], time: Math.floor(ctx.now() / 1000) - IV_SEC[iv] * size });
      return (d || []).map((k) => [num(k[0]) * 1000, num(k[1]), num(k[2]), num(k[3]), num(k[4]), num(k[5])]);
    },
    async balance(ctx, creds) {
      const d = await call(ctx, creds, '/v2/user_info.do', {});
      const free = (d && d.free) || {};
      const frozen = (d && d.freeze) || {};
      let balances;
      if (d && Array.isArray(d.balances)) balances = d.balances.map((b) => ({ asset: String(b.asset).toUpperCase(), free: num(b.free), locked: num(b.locked) }));
      else balances = Object.keys(free).map((k) => ({ asset: k.toUpperCase(), free: num(free[k]), locked: num(frozen[k]) }));
      return { balances: balances.filter((b) => b.free > 0 || b.locked > 0), canTrade: true };
    },
    async placeOrder(ctx, creds, o) {
      const sym = o.market.symbol;
      let params;
      if (o.type === 'limit') params = { symbol: sym, type: o.side, price: o.price, amount: o.qty };
      else if (o.side === 'buy') params = { symbol: sym, type: 'buy_market', price: o.quoteQty }; // خرید مارکت: price = مبلغ quote
      else params = { symbol: sym, type: 'sell_market', amount: o.qty };
      if (o.clientId) params.custom_id = o.clientId;
      const d = await call(ctx, creds, o.test ? '/v2/supplement/create_order_test.do' : '/v2/create_order.do', params);
      return { orderId: String((d && (d.order_id || d.orderId)) || ''), raw: d };
    },
  };
}

/* ================================== XT.com v4 ================================== */

function xt() {
  const base = 'https://sapi.xt.com';
  const unwrap = (r) => {
    const j = r.json;
    if (r.status >= 400 || !j || (j.rc !== undefined && Number(j.rc) !== 0)) throw new ExchangeError((j && (j.mc || j.msg)) || 'خطای XT ' + r.status, { code: j && (j.rc !== undefined ? j.rc : j.mc), status: r.status, raw: j });
    return j.result;
  };
  const call = async (ctx, creds, method, path, params, body) => {
    need(creds, 'apiKey', 'apiSecret');
    const ts = String(ctx.now()), recv = '10000';
    const hdr = { 'xt-validate-algorithms': 'HmacSHA256', 'xt-validate-appkey': creds.apiKey, 'xt-validate-recvwindow': recv, 'xt-validate-timestamp': ts };
    const X = sortedKeys(hdr).map((k) => `${k}=${hdr[k]}`).join('&');
    const query = params ? sortedKeys(params).map((k) => `${k}=${params[k]}`).join('&') : '';
    const bodyStr = body ? JSON.stringify(body) : '';
    let Y = '#' + method + '#' + path;
    if (query) Y += '#' + query;
    if (bodyStr) Y += '#' + bodyStr;
    const headers = { ...hdr, 'xt-validate-signature': hmac('sha256', creds.apiSecret, X + Y), 'Content-Type': 'application/json' };
    return unwrap(await ctx.http(method, `${base}${path}${query ? '?' + query : ''}`, { headers, body: bodyStr || undefined }));
  };
  const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));
  return {
    id: 'xt', name: 'XT.com', type: 'spot', needsPassphrase: false, hosts: ['sapi.xt.com'],
    async markets(ctx) {
      const r = await pub(ctx, '/v4/public/symbol');
      return ((r && r.symbols) || []).map((s) => {
        let minNot = 0;
        (s.filters || []).forEach((f) => { if (f.filter === 'QUOTE_QTY' || f.filter === 'MIN_NOTIONAL') minNot = num(f.min); });
        return mkMarket({ symbol: s.symbol, base: s.baseCurrency, quote: s.quoteCurrency, trading: s.state === 'ONLINE' && s.tradingEnabled !== false, tickSize: stepFromDecimals(s.pricePrecision), stepSize: stepFromDecimals(s.quantityPrecision), minNotional: minNot });
      });
    },
    async tickers(ctx) {
      const r = await pub(ctx, '/v4/public/ticker/24h');
      return (Array.isArray(r) ? r : []).map((t) => ({ symbol: t.s, last: num(t.c), changePct: num(t.cr) * 100, quoteVol: num(t.q), high: num(t.h), low: num(t.l) }));
    },
    async klines(ctx, symbol, interval, limit) {
      const r = await pub(ctx, '/v4/public/kline', { symbol, interval: normInterval(interval), limit: Math.min(limit || 300, 1000) });
      return (Array.isArray(r) ? r : []).map((k) => [num(k.t), num(k.o), num(k.h), num(k.l), num(k.c), num(k.v)]).sort((a, b) => a[0] - b[0]);
    },
    async balance(ctx, creds) {
      const r = await call(ctx, creds, 'GET', '/v4/balances', null);
      return { balances: ((r && r.assets) || []).map((x) => ({ asset: String(x.currency).toUpperCase(), free: num(x.availableAmount), locked: num(x.frozenAmount) })).filter((b) => b.free > 0 || b.locked > 0), canTrade: true };
    },
    async placeOrder(ctx, creds, o) {
      if (o.test) throw new ExchangeError('XT حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
      const body = { symbol: o.market.symbol, side: o.side.toUpperCase(), type: o.type.toUpperCase(), bizType: 'SPOT' };
      if (o.type === 'limit') { body.timeInForce = 'GTC'; body.price = o.price; body.quantity = o.qty; }
      else if (o.quoteQty) body.quoteQty = o.quoteQty;
      else body.quantity = o.qty;
      if (o.clientId) body.clientOrderId = o.clientId;
      const r = await call(ctx, creds, 'POST', '/v4/order', null, body);
      return { orderId: String((r && r.orderId) || ''), raw: r };
    },
  };
}

/* ======================== Bitunix (فیوچرز USDT-M) ======================== */

function bitunix() {
  const base = 'https://fapi.bitunix.com';
  const IV = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1h', '4h': '4h', '1d': '1d', '1w': '1w' };
  const unwrap = (r) => {
    const j = r.json;
    if (r.status >= 400 || !j || Number(j.code) !== 0) throw new ExchangeError((j && j.msg) || 'خطای Bitunix ' + r.status, { code: j && j.code, status: r.status, raw: j });
    return j.data;
  };
  /* امضا: digest = SHA256(nonce+timestamp+apiKey+query+body) ؛ sign = SHA256(digest+secret) */
  const call = async (ctx, creds, method, path, params, body) => {
    need(creds, 'apiKey', 'apiSecret');
    const nonce = rnd(32), ts = String(ctx.now());
    const p = cleanObj(params || {});
    const qSign = sortedKeys(p).map((k) => k + p[k]).join('');
    const bodyStr = body ? JSON.stringify(body) : '';
    const digest = sha256(nonce + ts + creds.apiKey + qSign + bodyStr);
    const headers = { 'api-key': creds.apiKey, nonce, timestamp: ts, sign: sha256(digest + creds.apiSecret), language: 'en-US', 'Content-Type': 'application/json' };
    const query = qs(p);
    return unwrap(await ctx.http(method, `${base}${path}${query ? '?' + query : ''}`, { headers, body: bodyStr || undefined }));
  };
  const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));
  return {
    id: 'bitunix', name: 'Bitunix (Futures)', type: 'futures', needsPassphrase: false, hosts: ['fapi.bitunix.com'],
    async markets(ctx) {
      const d = await pub(ctx, '/api/v1/futures/market/trading_pairs');
      return (d || []).map((s) => mkMarket({
        symbol: s.symbol, base: s.base, quote: s.quote, type: 'futures', trading: String(s.symbolStatus || 'OPEN').toUpperCase() === 'OPEN',
        stepSize: stepFromDecimals(num(s.basePrecision)), tickSize: stepFromDecimals(num(s.quotePrecision)), minQty: num(s.minTradeVolume), maxLeverage: s.maxLeverage,
      }));
    },
    async tickers(ctx) {
      const d = await pub(ctx, '/api/v1/futures/market/tickers');
      return (d || []).map((t) => { const last = num(t.lastPrice || t.last), open = num(t.open); return { symbol: t.symbol, last, changePct: open > 0 ? ((last - open) / open) * 100 : 0, quoteVol: num(t.quoteVol), high: num(t.high), low: num(t.low) }; });
    },
    async klines(ctx, symbol, interval, limit) {
      const d = await pub(ctx, '/api/v1/futures/market/kline', { symbol, interval: IV[normInterval(interval)], limit: Math.min(limit || 300, 200) });
      return (d || []).map((k) => [num(k.time), num(k.open), num(k.high), num(k.low), num(k.close), num(k.baseVol)]).sort((a, b) => a[0] - b[0]);
    },
    async balance(ctx, creds) {
      const d = await call(ctx, creds, 'GET', '/api/v1/futures/account', { marginCoin: 'USDT' });
      const a = Array.isArray(d) ? d[0] : d;
      return { balances: a ? [{ asset: a.marginCoin || 'USDT', free: num(a.available), locked: num(a.frozen) + num(a.margin) }] : [], canTrade: true, equityExtra: a ? { crossUnrealizedPNL: num(a.crossUnrealizedPNL), isolationUnrealizedPNL: num(a.isolationUnrealizedPNL) } : null };
    },
    async setLeverage(ctx, creds, symbol, leverage, marginMode) {
      if (marginMode) await call(ctx, creds, 'POST', '/api/v1/futures/account/change_margin_mode', null, { symbol, marginCoin: 'USDT', marginMode: marginMode === 'cross' ? 'CROSS' : 'ISOLATION' });
      return call(ctx, creds, 'POST', '/api/v1/futures/account/change_leverage', null, { symbol, marginCoin: 'USDT', leverage: Number(leverage) });
    },
    async placeOrder(ctx, creds, o) {
      if (o.test) throw new ExchangeError('Bitunix حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
      if (o.leverage) {
        try { await this.setLeverage(ctx, creds, o.market.symbol, o.leverage, o.marginMode); } catch (e) { if (!o.ignoreLeverageError) throw new ExchangeError('تنظیم اهرم ناموفق: ' + e.message, { code: e.exCode, raw: e.raw }); }
      }
      const body = { symbol: o.market.symbol, qty: o.qty, side: o.side === 'buy' ? 'BUY' : 'SELL', tradeSide: o.reduceOnly ? 'CLOSE' : 'OPEN', orderType: o.type === 'limit' ? 'LIMIT' : 'MARKET', clientId: o.clientId || rnd(24) };
      if (o.type === 'limit') { body.price = o.price; body.effect = 'GTC'; }
      if (o.sl > 0) { body.slPrice = floorToStep(o.sl, o.market.tickSize); body.slStopType = 'MARK_PRICE'; body.slOrderType = 'MARKET'; }
      if (o.tp > 0) { body.tpPrice = floorToStep(o.tp, o.market.tickSize); body.tpStopType = 'MARK_PRICE'; body.tpOrderType = 'MARKET'; }
      const d = await call(ctx, creds, 'POST', '/api/v1/futures/trade/place_order', null, body);
      return { orderId: String((d && d.orderId) || ''), nativeProtection: !!(o.sl > 0 || o.tp > 0), raw: d };
    },
    async positions(ctx, creds, symbol) {
      const d = await call(ctx, creds, 'GET', '/api/v1/futures/position/get_pending_positions', symbol ? { symbol } : {});
      return (d || []).map((p) => ({ positionId: String(p.positionId), symbol: p.symbol, side: String(p.side).toLowerCase() === 'buy' ? 'long' : 'short', qty: num(p.qty), entry: num(p.avgOpenPrice), leverage: num(p.leverage), margin: num(p.margin), pnl: num(p.unrealizedPNL), liqPrice: num(p.liqPrice) }));
    },
    async closePosition(ctx, creds, positionId) {
      const d = await call(ctx, creds, 'POST', '/api/v1/futures/trade/flash_close_position', null, { positionId: String(positionId) });
      return { raw: d };
    },
    async openOrders(ctx, creds, symbol) {
      const d = await call(ctx, creds, 'GET', '/api/v1/futures/trade/get_pending_orders', symbol ? { symbol } : {});
      const list = (d && (d.orderList || d)) || [];
      return (Array.isArray(list) ? list : []).map((x) => ({ orderId: String(x.orderId), symbol: x.symbol, side: String(x.side).toLowerCase(), type: String(x.orderType || '').toLowerCase(), price: num(x.price), qty: num(x.qty), filled: num(x.tradeQty), status: x.status }));
    },
    async cancelOrder(ctx, creds, symbol, orderId) {
      const d = await call(ctx, creds, 'POST', '/api/v1/futures/trade/cancel_orders', null, { symbol, orderList: [{ orderId: String(orderId) }] });
      return { orderId: String(orderId), raw: d };
    },
  };
}

/* -------------------------------- رجیستری -------------------------------- */

/* فیوچرز (USDT-M دائمی) برای همهٔ صرافی‌های پشتیبانی‌شده؛ نسخه‌های اسپات با پسوند _spot نگه داشته می‌شوند ولی در فهرست کاربر نیستند */
const H = { ExchangeError, hmac, sha256, sha512, md5, num, rnd, cleanObj, qs, qsRaw, sortedKeys, decimalsOf, stepFromDecimals, floorToStep, mkMarket, normInterval, IV_SEC, STABLES, need, bad };
const FA = require('./futures-a.js')(H);
const FB = require('./futures-b.js')(H);
const FC = require('./futures-c.js')(H);

const SPOT = {
  binance_spot: binanceLike({ id: 'binance_spot', name: 'Binance (Spot)', base: 'https://api.binance.com', headerName: 'X-MBX-APIKEY', ivMap: BINANCE_IV }),
  mexc_spot: binanceLike({ id: 'mexc_spot', name: 'MEXC (Spot)', base: 'https://api.mexc.com', headerName: 'X-MEXC-APIKEY', ivMap: MEXC_IV, mexc: true }),
  bybit_spot: bybit(), okx_spot: okx(), kucoin_spot: kucoin(), gate_spot: gate(), bitget_spot: bitget(), lbank_spot: lbank(), xt_spot: xt(),
};
Object.entries(SPOT).forEach(([id, c]) => { c.id = id; c.hidden = true; });
Object.entries({ binance: FA.binance, mexc: FA.mexc, bybit: FA.bybit, okx: FB.okx, kucoin: FB.kucoin, gate: FB.gate, bitget: FB.bitget, lbank: FC.lbank, xt: FC.xt }).forEach(([id, c]) => { c.id = id; });

const CONNECTORS = {
  binance: FA.binance, mexc: FA.mexc, bybit: FA.bybit,
  okx: FB.okx, kucoin: FB.kucoin, gate: FB.gate, bitget: FB.bitget,
  bitunix: bitunix(),
  lbank: FC.lbank, xt: FC.xt,
  ...Object.fromEntries(Object.entries(SPOT).filter(([id]) => id.endsWith('_spot'))),
};

const ALL_HOSTS = [...new Set(Object.values(CONNECTORS).flatMap((c) => c.hosts))];

const listExchanges = () => Object.values(CONNECTORS).filter((c) => !c.hidden).map((c) => ({
  id: c.id, name: c.name, type: c.type, soon: !!c.soon, needsPassphrase: !!c.needsPassphrase,
  features: { protect: typeof c.protect === 'function', positions: typeof c.positions === 'function', orders: typeof c.openOrders === 'function', test: ['binance'].includes(c.id) },
}));

module.exports = { CONNECTORS, ALL_HOSTS, listExchanges, ExchangeError, prepareOrder, floorToStep, decimalsOf, stepFromDecimals, hmac, md5, sha256, sha512 };

};
__defs["./futures-a.js"] = function (module, exports, require) {
'use strict';
/**
 * ترید یار — کانکتورهای فیوچرز (USDT-M دائمی): Binance، MEXC، Bybit
 * هر سه با همان رابط کانکتورهای exchanges.js؛ حجم‌ها همیشه به «واحد ارز پایه» هستند.
 * ساخته‌شده با build(H) تا به exchanges.js وابسته (و دایره‌ای) نباشد.
 */
module.exports = function build(H) {
  const { ExchangeError, hmac, num, cleanObj, qs, floorToStep, mkMarket, normInterval, IV_SEC, need } = H;
  const lc = (s) => String(s || '').toLowerCase();
  const tickStr = (v, mk) => floorToStep(v, mk && mk.tickSize > 0 ? mk.tickSize : 0);

  /* ================================ Binance USDT-M ================================ */
  function binance() {
    const base = 'https://fapi.binance.com';
    const unwrap = (r) => {
      const j = r.json;
      if (r.status >= 400 || (j && typeof j === 'object' && !Array.isArray(j) && j.code !== undefined && Number(j.code) < 0)) {
        throw new ExchangeError((j && j.msg) || 'خطای Binance Futures ' + r.status, { code: j && j.code, status: r.status, raw: j });
      }
      return j;
    };
    const signed = async (ctx, creds, method, path, params = {}) => {
      need(creds, 'apiKey', 'apiSecret');
      const query = qs(cleanObj({ ...params, recvWindow: 10000, timestamp: ctx.now() }));
      const signature = hmac('sha256', creds.apiSecret, query);
      return unwrap(await ctx.http(method, `${base}${path}?${query}&signature=${signature}`, { headers: { 'X-MBX-APIKEY': creds.apiKey } }));
    };
    const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));
    const IVM = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1h', '4h': '4h', '1d': '1d', '1w': '1w' };
    const isHedge = async (ctx, creds) => !!((await signed(ctx, creds, 'GET', '/fapi/v1/positionSide/dual')) || {}).dualSidePosition;
    const posSideFor = (side, reduce) => ((side === 'buy') !== !!reduce ? 'LONG' : 'SHORT'); // خرید باز = LONG ؛ فروش کاهشی = LONG

    const self = {
      id: 'binance', name: 'Binance Futures', type: 'futures', needsPassphrase: false, hosts: ['fapi.binance.com'],
      async markets(ctx) {
        const r = await pub(ctx, '/fapi/v1/exchangeInfo');
        return ((r && r.symbols) || []).filter((s) => s.contractType === 'PERPETUAL' && s.quoteAsset === 'USDT').map((s) => {
          const f = {}; (s.filters || []).forEach((x) => { f[x.filterType] = x; });
          return mkMarket({
            symbol: s.symbol, base: s.baseAsset, quote: s.quoteAsset, type: 'futures', trading: s.status === 'TRADING',
            tickSize: num(f.PRICE_FILTER && f.PRICE_FILTER.tickSize), stepSize: num(f.LOT_SIZE && f.LOT_SIZE.stepSize),
            minQty: num(f.LOT_SIZE && f.LOT_SIZE.minQty), minNotional: num(f.MIN_NOTIONAL && (f.MIN_NOTIONAL.notional || f.MIN_NOTIONAL.minNotional)),
          });
        });
      },
      async tickers(ctx) {
        const r = await pub(ctx, '/fapi/v1/ticker/24hr');
        return (Array.isArray(r) ? r : []).filter((t) => /USDT$/.test(t.symbol)).map((t) => ({ symbol: t.symbol, last: num(t.lastPrice), changePct: num(t.priceChangePercent), quoteVol: num(t.quoteVolume), high: num(t.highPrice), low: num(t.lowPrice) }));
      },
      async klines(ctx, symbol, interval, limit) {
        const r = await pub(ctx, '/fapi/v1/klines', { symbol, interval: IVM[normInterval(interval)], limit: Math.min(limit || 300, 1500) });
        return (Array.isArray(r) ? r : []).map((k) => [num(k[0]), num(k[1]), num(k[2]), num(k[3]), num(k[4]), num(k[5])]);
      },
      async balance(ctx, creds) {
        const a = await signed(ctx, creds, 'GET', '/fapi/v2/account');
        const balances = ((a && a.assets) || []).map((x) => { const w = num(x.walletBalance), f = num(x.availableBalance); return { asset: x.asset, free: f, locked: Math.max(0, w - f), w }; })
          .filter((x) => x.w > 0 || x.free > 0).map(({ asset, free, locked }) => ({ asset, free, locked }));
        return { balances, canTrade: a.canTrade !== false, canWithdraw: !!a.canWithdraw };
      },
      async setLeverage(ctx, creds, symbol, leverage, marginMode) {
        if (marginMode) {
          try { await signed(ctx, creds, 'POST', '/fapi/v1/marginType', { symbol, marginType: marginMode === 'cross' ? 'CROSSED' : 'ISOLATED' }); }
          catch (e) { if (Number(e.exCode) !== -4046) throw e; }
        }
        return signed(ctx, creds, 'POST', '/fapi/v1/leverage', { symbol, leverage: Number(leverage) });
      },
      async placeOrder(ctx, creds, o) {
        const sym = o.market.symbol;
        if (o.leverage && !o.test) {
          try { await self.setLeverage(ctx, creds, sym, o.leverage, o.marginMode); }
          catch (e) { if (!o.ignoreLeverageError) throw e; }
        }
        const hedge = await isHedge(ctx, creds);
        const side = o.side === 'buy' ? 'BUY' : 'SELL';
        const p = { symbol: sym, side, type: o.type === 'limit' ? 'LIMIT' : 'MARKET', quantity: o.qty, newClientOrderId: o.clientId };
        if (o.type === 'limit') { p.price = o.price; p.timeInForce = 'GTC'; }
        if (hedge) p.positionSide = posSideFor(o.side, o.reduceOnly); else if (o.reduceOnly) p.reduceOnly = 'true';
        const r = await signed(ctx, creds, 'POST', o.test ? '/fapi/v1/order/test' : '/fapi/v1/order', p);
        let native = false;
        if (!o.test && o.type !== 'limit' && !o.reduceOnly && (o.sl > 0 || o.tp > 0)) {
          const opp = o.side === 'buy' ? 'SELL' : 'BUY';
          const algo = (type, price) => signed(ctx, creds, 'POST', '/fapi/v1/algoOrder', cleanObj({
            symbol: sym, side: opp, algoType: 'CONDITIONAL', type, triggerPrice: tickStr(price, o.market), closePosition: 'true', workingType: 'MARK_PRICE', positionSide: hedge ? posSideFor(o.side, false) : undefined,
          }));
          try {
            if (o.sl > 0) await algo('STOP_MARKET', o.sl);
            if (o.tp > 0) await algo('TAKE_PROFIT_MARKET', o.tp);
            native = true;
          } catch (e) {
            // بدون حد ضرر نباید پوزیشن باز بماند → بستن اضطراری
            try { await self.placeOrder(ctx, creds, { market: o.market, side: opp.toLowerCase(), type: 'market', qty: o.qty, reduceOnly: true }); } catch { /* ignore */ }
            throw new ExchangeError('ثبت حد ضرر/سود ناموفق بود و پوزیشن بسته شد: ' + e.message, { code: e.exCode, raw: e.raw });
          }
        }
        return { orderId: String((r && r.orderId) || ''), nativeProtection: native, raw: r };
      },
      async positions(ctx, creds, symbol) {
        const r = await signed(ctx, creds, 'GET', '/fapi/v2/positionRisk', symbol ? { symbol } : {});
        return (Array.isArray(r) ? r : []).filter((x) => num(x.positionAmt) !== 0).map((x) => {
          const amt = num(x.positionAmt), lev = num(x.leverage) || 1;
          const side = x.positionSide === 'LONG' ? 'long' : x.positionSide === 'SHORT' ? 'short' : amt > 0 ? 'long' : 'short';
          const margin = lc(x.marginType) === 'isolated' ? num(x.isolatedMargin) : Math.abs(num(x.notional)) / lev;
          return { positionId: `${x.symbol}|${side}`, symbol: x.symbol, side, qty: Math.abs(amt), entry: num(x.entryPrice), leverage: lev, margin, pnl: num(x.unRealizedProfit), liqPrice: num(x.liquidationPrice) };
        });
      },
      async closePosition(ctx, creds, positionId) {
        const [symbol, side] = String(positionId).split('|');
        const p = (await self.positions(ctx, creds, symbol)).find((x) => x.symbol === symbol && (!side || x.side === side));
        if (!p) throw new ExchangeError('موقعیت پیدا نشد', { code: 'position_not_found' });
        return self.placeOrder(ctx, creds, { market: { symbol, tickSize: 0 }, side: p.side === 'long' ? 'sell' : 'buy', type: 'market', qty: String(p.qty), reduceOnly: true });
      },
      async openOrders(ctx, creds, symbol) {
        const r = await signed(ctx, creds, 'GET', '/fapi/v1/openOrders', symbol ? { symbol } : {});
        const out = (Array.isArray(r) ? r : []).map((x) => ({ orderId: String(x.orderId), symbol: x.symbol, side: lc(x.side), type: lc(x.type), price: num(x.price), qty: num(x.origQty), filled: num(x.executedQty), status: x.status }));
        try {
          const a = await signed(ctx, creds, 'GET', '/fapi/v1/openAlgoOrders', symbol ? { symbol } : {});
          (Array.isArray(a) ? a : []).forEach((x) => out.push({ orderId: 'algo:' + x.algoId, symbol: x.symbol, side: lc(x.side), type: lc(x.orderType || x.type), price: num(x.triggerPrice), qty: num(x.quantity), filled: 0, status: x.algoStatus || 'NEW' }));
        } catch { /* ignore */ }
        return out;
      },
      async cancelOrder(ctx, creds, symbol, orderId) {
        const id = String(orderId);
        if (id.startsWith('algo:')) return { orderId: id, raw: await signed(ctx, creds, 'DELETE', '/fapi/v1/algoOrder', { algoId: id.slice(5) }) };
        return { orderId: id, raw: await signed(ctx, creds, 'DELETE', '/fapi/v1/order', { symbol, orderId: id }) };
      },
    };
    return self;
  }

  /* ================================ MEXC Futures ================================ */
  function mexc() {
    const base = 'https://contract.mexc.com';
    const IVM = { '1m': 'Min1', '5m': 'Min5', '15m': 'Min15', '30m': 'Min30', '1h': 'Min60', '4h': 'Hour4', '1d': 'Day1', '1w': 'Week1' };
    const unwrap = (r) => {
      const j = r.json;
      if (r.status >= 400 || !j || j.success === false || (j.code !== undefined && Number(j.code) !== 0 && Number(j.code) !== 200)) {
        throw new ExchangeError((j && (j.message || j.msg)) || 'خطای MEXC Futures ' + r.status, { code: j && j.code, status: r.status, raw: j });
      }
      return j.data;
    };
    const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));
    const call = async (ctx, creds, method, path, params, body) => {
      need(creds, 'apiKey', 'apiSecret');
      const ts = String(ctx.now());
      let paramStr = '', bodyStr, url = base + path;
      if (method === 'GET') {
        paramStr = Object.keys(cleanObj(params || {})).sort().map((k) => `${k}=${encodeURIComponent(params[k])}`).join('&');
        if (paramStr) url += '?' + paramStr;
      } else { bodyStr = JSON.stringify(body === undefined ? {} : body); paramStr = bodyStr; }
      const headers = { ApiKey: creds.apiKey, 'Request-Time': ts, Signature: hmac('sha256', creds.apiSecret, creds.apiKey + ts + paramStr), 'Content-Type': 'application/json' };
      return unwrap(await ctx.http(method, url, { headers, body: bodyStr }));
    };
    const spec = new Map();
    const specOf = async (ctx, symbol) => {
      if (spec.has(symbol)) return spec.get(symbol);
      const d = await pub(ctx, '/api/v1/contract/detail', { symbol });
      const s = Array.isArray(d) ? d.find((x) => x.symbol === symbol) : d;
      if (!s) throw new ExchangeError('قرارداد پیدا نشد', { code: 'unknown_symbol' });
      const v = { cs: num(s.contractSize) || 1, vu: num(s.volUnit) || 1 };
      spec.set(symbol, v);
      return v;
    };
    const getMode = async (ctx, creds) => { try { return Number(await call(ctx, creds, 'GET', '/api/v1/private/position/position_mode')) === 1 ? 1 : 2; } catch { return 2; } };
    const SIDE_FA = { 1: 'buy', 2: 'buy', 3: 'sell', 4: 'sell' };

    const self = {
      id: 'mexc', name: 'MEXC Futures', type: 'futures', needsPassphrase: false, hosts: ['contract.mexc.com'],
      async markets(ctx) {
        const d = await pub(ctx, '/api/v1/contract/detail');
        return (Array.isArray(d) ? d : [d]).filter((s) => s && s.quoteCoin === 'USDT' && s.settleCoin === 'USDT').map((s) => {
          const cs = num(s.contractSize) || 1, vu = num(s.volUnit) || 1;
          spec.set(s.symbol, { cs, vu });
          return mkMarket({ symbol: s.symbol, base: s.baseCoin, quote: s.quoteCoin, type: 'futures', trading: Number(s.state) === 0 && s.apiAllowed !== false, tickSize: num(s.priceUnit), stepSize: vu * cs, minQty: num(s.minVol) * cs, maxLeverage: s.maxLeverage });
        });
      },
      async tickers(ctx) {
        const d = await pub(ctx, '/api/v1/contract/ticker');
        return (Array.isArray(d) ? d : [d]).filter((t) => t && /_USDT$/.test(t.symbol)).map((t) => ({ symbol: t.symbol, last: num(t.lastPrice), changePct: Number((num(t.riseFallRate) * 100).toFixed(6)), quoteVol: num(t.amount24), high: num(t.high24Price), low: num(t.lower24Price) }));
      },
      async klines(ctx, symbol, interval, limit) {
        const iv = normInterval(interval), n = Math.min(limit || 300, 2000), end = Math.floor(ctx.now() / 1000);
        const [d, sp] = await Promise.all([pub(ctx, `/api/v1/contract/kline/${symbol}`, { interval: IVM[iv], start: end - n * IV_SEC[iv], end }), specOf(ctx, symbol)]);
        const t = (d && d.time) || [];
        return t.map((ts, i) => [ts * 1000, num(d.open[i]), num(d.high[i]), num(d.low[i]), num(d.close[i]), num(d.vol[i]) * sp.cs]).sort((a, b) => a[0] - b[0]);
      },
      async balance(ctx, creds) {
        const d = await call(ctx, creds, 'GET', '/api/v1/private/account/assets');
        const balances = (Array.isArray(d) ? d : []).map((a) => ({ asset: a.currency, free: num(a.availableBalance), locked: num(a.frozenBalance) + num(a.positionMargin) })).filter((b) => b.free > 0 || b.locked > 0);
        return { balances, canTrade: true };
      },
      async setLeverage(ctx, creds, symbol, leverage, marginMode) {
        const openType = marginMode === 'cross' ? 2 : 1;
        for (const positionType of [1, 2]) await call(ctx, creds, 'POST', '/api/v1/private/position/change_leverage', null, { symbol, leverage: Number(leverage), openType, positionType });
        return true;
      },
      async placeOrder(ctx, creds, o) {
        if (o.test) throw new ExchangeError('MEXC حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
        const sym = o.market.symbol, sp = await specOf(ctx, sym), mode = await getMode(ctx, creds);
        if (o.leverage) {
          try { await self.setLeverage(ctx, creds, sym, o.leverage, o.marginMode); } catch (e) { if (!o.ignoreLeverageError) throw e; }
        }
        const buy = o.side === 'buy', reduce = !!o.reduceOnly;
        const body = {
          symbol: sym, vol: floorToStep(Number(o.qty) / sp.cs, sp.vu), side: reduce ? (buy ? 2 : 4) : (buy ? 1 : 3), type: o.type === 'limit' ? 1 : 5,
          openType: o.marginMode === 'cross' ? 2 : 1, positionMode: mode,
        };
        if (o.type === 'limit') body.price = tickStr(o.price, o.market);
        if (o.leverage && !reduce) body.leverage = Number(o.leverage);
        if (reduce && mode === 2) body.reduceOnly = true;
        if (o.clientId) body.externalOid = o.clientId;
        if (!reduce) {
          if (o.sl > 0) body.stopLossPrice = tickStr(o.sl, o.market);
          if (o.tp > 0) body.takeProfitPrice = tickStr(o.tp, o.market);
        }
        const d = await call(ctx, creds, 'POST', '/api/v1/private/order/submit', null, body);
        return { orderId: String((d && typeof d === 'object' ? d.orderId : d) || ''), nativeProtection: !reduce && !!(o.sl > 0 || o.tp > 0), raw: d };
      },
      async positions(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/api/v1/private/position/open_positions', symbol ? { symbol } : {});
        const out = [];
        for (const x of (Array.isArray(d) ? d : [])) {
          if (!(num(x.holdVol) > 0)) continue;
          const sp = await specOf(ctx, x.symbol), qty = num(x.holdVol) * sp.cs, long = Number(x.positionType) === 1, entry = num(x.holdAvgPrice);
          let fair = 0;
          try { const t = await pub(ctx, '/api/v1/contract/ticker', { symbol: x.symbol }); const tt = Array.isArray(t) ? t[0] : t; fair = num(tt && (tt.fairPrice || tt.lastPrice)); } catch { /* ignore */ }
          out.push({ positionId: String(x.positionId), symbol: x.symbol, side: long ? 'long' : 'short', qty, entry, leverage: num(x.leverage), margin: num(x.im), pnl: fair > 0 ? (long ? fair - entry : entry - fair) * qty : num(x.realised), liqPrice: num(x.liquidatePrice) });
        }
        return out;
      },
      async closePosition(ctx, creds, positionId) {
        const d = await call(ctx, creds, 'GET', '/api/v1/private/position/open_positions', {});
        const x = (Array.isArray(d) ? d : []).find((p) => String(p.positionId) === String(positionId) && num(p.holdVol) > 0);
        if (!x) throw new ExchangeError('موقعیت پیدا نشد', { code: 'position_not_found' });
        const mode = await getMode(ctx, creds);
        const body = { symbol: x.symbol, vol: String(x.holdVol), side: Number(x.positionType) === 1 ? 4 : 2, type: 5, openType: Number(x.openType) || 1, positionId: Number(x.positionId), positionMode: mode };
        if (mode === 2) body.reduceOnly = true;
        const r = await call(ctx, creds, 'POST', '/api/v1/private/order/submit', null, body);
        return { raw: r };
      },
      async openOrders(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/api/v1/private/order/list/open_orders' + (symbol ? '/' + symbol : ''), { page_num: 1, page_size: 100 });
        const list = Array.isArray(d) ? d : (d && d.resultList) || [];
        const out = [];
        for (const x of list) {
          const sp = await specOf(ctx, x.symbol);
          out.push({ orderId: String(x.orderId), symbol: x.symbol, side: SIDE_FA[x.side] || 'buy', type: Number(x.orderType) === 1 ? 'limit' : 'market', price: num(x.price), qty: num(x.vol) * sp.cs, filled: num(x.dealVol) * sp.cs, status: x.state });
        }
        return out;
      },
      async cancelOrder(ctx, creds, symbol, orderId) {
        const d = await call(ctx, creds, 'POST', '/api/v1/private/order/cancel', null, [Number(orderId)]);
        return { orderId: String(orderId), raw: d };
      },
    };
    return self;
  }

  /* ================================ Bybit Linear ================================ */
  function bybit() {
    const base = 'https://api.bybit.com';
    const IVM = { '1m': '1', '5m': '5', '15m': '15', '30m': '30', '1h': '60', '4h': '240', '1d': 'D', '1w': 'W' };
    const unwrap = (r) => {
      const j = r.json;
      if (r.status >= 400 || !j || Number(j.retCode) !== 0) throw new ExchangeError((j && j.retMsg) || 'خطای Bybit ' + r.status, { code: j && j.retCode, status: r.status, raw: j });
      return j.result;
    };
    const call = async (ctx, creds, method, path, params, body) => {
      need(creds, 'apiKey', 'apiSecret');
      const ts = String(ctx.now()), recv = '10000';
      const query = method === 'GET' ? qs(params || {}) : '';
      const bodyStr = body ? JSON.stringify(body) : '';
      const sign = hmac('sha256', creds.apiSecret, ts + creds.apiKey + recv + (method === 'GET' ? query : bodyStr));
      const headers = { 'X-BAPI-API-KEY': creds.apiKey, 'X-BAPI-TIMESTAMP': ts, 'X-BAPI-RECV-WINDOW': recv, 'X-BAPI-SIGN': sign, 'Content-Type': 'application/json' };
      return unwrap(await ctx.http(method, `${base}${path}${query ? '?' + query : ''}`, { headers, body: bodyStr || undefined }));
    };
    const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}?${qs(params)}`, {}));
    const ignoring = async (fn, ...codes) => { try { return await fn(); } catch (e) { if (codes.includes(Number(e.exCode))) return null; throw e; } };

    const self = {
      id: 'bybit', name: 'Bybit Futures', type: 'futures', needsPassphrase: false, hosts: ['api.bybit.com'],
      async markets(ctx) {
        const out = []; let cursor;
        for (let i = 0; i < 10; i++) {
          const r = await pub(ctx, '/v5/market/instruments-info', { category: 'linear', limit: 1000, cursor });
          (r.list || []).filter((s) => s.contractType === 'LinearPerpetual' && s.quoteCoin === 'USDT').forEach((s) => out.push(mkMarket({
            symbol: s.symbol, base: s.baseCoin, quote: s.quoteCoin, type: 'futures', trading: s.status === 'Trading',
            tickSize: num(s.priceFilter && s.priceFilter.tickSize), stepSize: num(s.lotSizeFilter && s.lotSizeFilter.qtyStep), minQty: num(s.lotSizeFilter && s.lotSizeFilter.minOrderQty),
            minNotional: num(s.lotSizeFilter && s.lotSizeFilter.minNotionalValue), maxLeverage: s.leverageFilter && s.leverageFilter.maxLeverage,
          })));
          cursor = r.nextPageCursor;
          if (!cursor) break;
        }
        return out;
      },
      async tickers(ctx) {
        const r = await pub(ctx, '/v5/market/tickers', { category: 'linear' });
        return (r.list || []).filter((t) => /USDT$/.test(t.symbol)).map((t) => ({ symbol: t.symbol, last: num(t.lastPrice), changePct: num(t.price24hPcnt) * 100, quoteVol: num(t.turnover24h), high: num(t.highPrice24h), low: num(t.lowPrice24h) }));
      },
      async klines(ctx, symbol, interval, limit) {
        const r = await pub(ctx, '/v5/market/kline', { category: 'linear', symbol, interval: IVM[normInterval(interval)], limit: Math.min(limit || 300, 1000) });
        return (r.list || []).map((k) => [num(k[0]), num(k[1]), num(k[2]), num(k[3]), num(k[4]), num(k[5])]).reverse();
      },
      async balance(ctx, creds) {
        const r = await call(ctx, creds, 'GET', '/v5/account/wallet-balance', { accountType: 'UNIFIED' });
        const acc = (r.list && r.list[0]) || {};
        const usdt = (acc.coin || []).find((c) => c.coin === 'USDT');
        const wallet = usdt ? num(usdt.walletBalance) : 0, free = num(acc.totalAvailableBalance);
        let canTrade = true, canWithdraw = false;
        try {
          const k = await call(ctx, creds, 'GET', '/v5/user/query-api');
          const perms = (k && k.permissions) || {};
          canTrade = !Number(k && k.readOnly) && !!(perms.ContractTrade && perms.ContractTrade.length);
          canWithdraw = !!(perms.Wallet && perms.Wallet.indexOf('Withdraw') >= 0);
        } catch { /* ignore */ }
        return { balances: usdt || free > 0 ? [{ asset: 'USDT', free, locked: Math.max(0, wallet - free) }] : [], canTrade, canWithdraw };
      },
      async setLeverage(ctx, creds, symbol, leverage, marginMode) {
        const lv = String(Number(leverage));
        if (marginMode) await ignoring(() => call(ctx, creds, 'POST', '/v5/position/switch-isolated', null, { category: 'linear', symbol, tradeMode: marginMode === 'cross' ? 0 : 1, buyLeverage: lv, sellLeverage: lv }), 110026, 100028);
        return ignoring(() => call(ctx, creds, 'POST', '/v5/position/set-leverage', null, { category: 'linear', symbol, buyLeverage: lv, sellLeverage: lv }), 110043);
      },
      async placeOrder(ctx, creds, o) {
        if (o.test) throw new ExchangeError('Bybit حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
        const sym = o.market.symbol;
        if (o.leverage) { try { await self.setLeverage(ctx, creds, sym, o.leverage, o.marginMode); } catch (e) { if (!o.ignoreLeverageError) throw e; } }
        const pl = await call(ctx, creds, 'GET', '/v5/position/list', { category: 'linear', symbol: sym });
        const hedge = (pl.list || []).some((x) => Number(x.positionIdx) === 1 || Number(x.positionIdx) === 2);
        const buy = o.side === 'buy';
        const body = { category: 'linear', symbol: sym, side: buy ? 'Buy' : 'Sell', orderType: o.type === 'limit' ? 'Limit' : 'Market', qty: o.qty, positionIdx: hedge ? ((buy !== !!o.reduceOnly) ? 1 : 2) : 0 };
        if (o.type === 'limit') { body.price = o.price; body.timeInForce = 'GTC'; }
        if (o.clientId) body.orderLinkId = o.clientId;
        let native = false;
        if (o.reduceOnly) body.reduceOnly = true;
        else {
          if (o.sl > 0) { body.stopLoss = tickStr(o.sl, o.market); body.slTriggerBy = 'MarkPrice'; body.slOrderType = 'Market'; native = true; }
          if (o.tp > 0) { body.takeProfit = tickStr(o.tp, o.market); body.tpTriggerBy = 'MarkPrice'; body.tpOrderType = 'Market'; native = true; }
          if (native) body.tpslMode = 'Full';
        }
        const r = await call(ctx, creds, 'POST', '/v5/order/create', null, body);
        return { orderId: String(r.orderId || ''), nativeProtection: native, raw: r };
      },
      async positions(ctx, creds, symbol) {
        const r = await call(ctx, creds, 'GET', '/v5/position/list', symbol ? { category: 'linear', symbol } : { category: 'linear', settleCoin: 'USDT', limit: 200 });
        return (r.list || []).filter((x) => num(x.size) > 0).map((x) => {
          const side = x.side === 'Sell' ? 'short' : 'long';
          return { positionId: `${x.symbol}|${side}`, symbol: x.symbol, side, qty: num(x.size), entry: num(x.avgPrice), leverage: num(x.leverage), margin: num(x.positionIM), pnl: num(x.unrealisedPnl), liqPrice: num(x.liqPrice) };
        });
      },
      async closePosition(ctx, creds, positionId) {
        const [symbol, side] = String(positionId).split('|');
        const r = await call(ctx, creds, 'GET', '/v5/position/list', { category: 'linear', symbol });
        const p = (r.list || []).find((x) => x.symbol === symbol && num(x.size) > 0 && (!side || (x.side === 'Sell' ? 'short' : 'long') === side));
        if (!p) throw new ExchangeError('موقعیت پیدا نشد', { code: 'position_not_found' });
        const d = await call(ctx, creds, 'POST', '/v5/order/create', null, { category: 'linear', symbol, side: p.side === 'Sell' ? 'Buy' : 'Sell', orderType: 'Market', qty: String(p.size), reduceOnly: true, positionIdx: Number(p.positionIdx) || 0 });
        return { raw: d };
      },
      async openOrders(ctx, creds, symbol) {
        const r = await call(ctx, creds, 'GET', '/v5/order/realtime', symbol ? { category: 'linear', symbol } : { category: 'linear', settleCoin: 'USDT' });
        return (r.list || []).map((x) => ({ orderId: x.orderId, symbol: x.symbol, side: lc(x.side), type: lc(x.orderType), price: num(x.price), qty: num(x.qty), filled: num(x.cumExecQty), status: x.orderStatus }));
      },
      async cancelOrder(ctx, creds, symbol, orderId) {
        const d = await call(ctx, creds, 'POST', '/v5/order/cancel', null, { category: 'linear', symbol, orderId: String(orderId) });
        return { orderId: String(orderId), raw: d };
      },
    };
    return self;
  }

  return { binance: binance(), mexc: mexc(), bybit: bybit() };
};

};
__defs["./futures-b.js"] = function (module, exports, require) {
'use strict';
/**
 * ترید یار — کانکتورهای فیوچرز (USDT-M دائمی): OKX، Bitget، Gate، KuCoin
 * حجم‌ها همیشه به «واحد ارز پایه» هستند؛ تبدیل به قرارداد/لات داخل کانکتور انجام می‌شود.
 * حد ضرر/سود: همراه سفارش (OKX/Bitget) یا بلافاصله بعد از ورود (Gate/KuCoin)؛
 * اگر ثبت حد ضرر شکست بخورد پوزیشن بلافاصله بسته می‌شود تا هیچ‌وقت بدون حد ضرر نماند.
 */
module.exports = function build(H) {
  const { ExchangeError, hmac, sha512, num, rnd, cleanObj, qs, floorToStep, mkMarket, normInterval, IV_SEC, need } = H;
  const lc = (s) => String(s || '').toLowerCase();
  const tickStr = (v, mk) => floorToStep(v, mk && mk.tickSize > 0 ? mk.tickSize : 0);
  const cid = (s, max, re = /[^A-Za-z0-9]/g) => String(s || rnd(20)).replace(re, '').slice(0, max) || rnd(16);
  const hasQuery = (p) => p && Object.keys(cleanObj(p)).length;

  /* ===================================== OKX ===================================== */
  function okx() {
    const base = 'https://www.okx.com';
    const IVM = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1H', '4h': '4H', '1d': '1D', '1w': '1W' };
    const unwrap = (r) => {
      const j = r.json;
      if (r.status >= 400 || !j || String(j.code) !== '0') {
        const d = j && j.data && j.data[0];
        throw new ExchangeError((d && d.sMsg) || (j && j.msg) || 'خطای OKX ' + r.status, { code: (d && d.sCode) || (j && j.code), status: r.status, raw: j });
      }
      const d = j.data && j.data[0];
      if (d && d.sCode !== undefined && String(d.sCode) !== '0') throw new ExchangeError(d.sMsg || 'سفارش رد شد', { code: d.sCode, raw: j });
      return j.data;
    };
    const call = async (ctx, creds, method, path, params, body) => {
      need(creds, 'apiKey', 'apiSecret', 'passphrase');
      const ts = new Date(ctx.now()).toISOString();
      const reqPath = path + (hasQuery(params) ? '?' + qs(params) : '');
      const bodyStr = body ? JSON.stringify(body) : '';
      const headers = { 'OK-ACCESS-KEY': creds.apiKey, 'OK-ACCESS-SIGN': hmac('sha256', creds.apiSecret, ts + method + reqPath + bodyStr, 'base64'), 'OK-ACCESS-TIMESTAMP': ts, 'OK-ACCESS-PASSPHRASE': creds.passphrase, 'Content-Type': 'application/json' };
      return unwrap(await ctx.http(method, base + reqPath, { headers, body: bodyStr || undefined }));
    };
    const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}?${qs(params)}`, {}));
    const specs = new Map();
    const loadSpecs = async (ctx) => {
      const d = await pub(ctx, '/api/v5/public/instruments', { instType: 'SWAP' });
      (d || []).forEach((s) => specs.set(s.instId, { ctVal: num(s.ctVal) || 1, lotSz: num(s.lotSz) || 1, minSz: num(s.minSz) || 1, s }));
      return d || [];
    };
    const specOf = async (ctx, instId) => { if (!specs.has(instId)) await loadSpecs(ctx); const v = specs.get(instId); if (!v) throw new ExchangeError('قرارداد پیدا نشد', { code: 'unknown_symbol' }); return v; };
    const posMode = async (ctx, creds) => { try { const d = await call(ctx, creds, 'GET', '/api/v5/account/config'); return d && d[0] && d[0].posMode === 'long_short_mode' ? 'long_short' : 'net'; } catch { return 'net'; } };
    const mgn = (m) => (m === 'cross' ? 'cross' : 'isolated');

    const self = {
      id: 'okx', name: 'OKX Futures', type: 'futures', needsPassphrase: true, hosts: ['www.okx.com'],
      async markets(ctx) {
        const d = await loadSpecs(ctx);
        return d.filter((s) => s.settleCcy === 'USDT' && s.ctType === 'linear').map((s) => {
          const ct = num(s.ctVal) || 1;
          const m = mkMarket({ symbol: s.instId, base: String(s.instId).split('-')[0], quote: 'USDT', type: 'futures', trading: s.state === 'live', tickSize: num(s.tickSz), stepSize: num(s.lotSz) * ct, minQty: num(s.minSz) * ct, maxLeverage: s.lever });
          m.ctVal = ct; m.lotSz = num(s.lotSz) || 1;
          return m;
        });
      },
      async tickers(ctx) {
        const d = await pub(ctx, '/api/v5/market/tickers', { instType: 'SWAP' });
        return (d || []).filter((t) => /-USDT-SWAP$/.test(t.instId)).map((t) => {
          const last = num(t.last), open = num(t.open24h);
          return { symbol: t.instId, last, changePct: open > 0 ? ((last - open) / open) * 100 : 0, quoteVol: num(t.volCcy24h) * last, high: num(t.high24h), low: num(t.low24h) };
        });
      },
      async klines(ctx, symbol, interval, limit) {
        const [d, sp] = await Promise.all([pub(ctx, '/api/v5/market/candles', { instId: symbol, bar: IVM[normInterval(interval)], limit: Math.min(limit || 300, 300) }), specOf(ctx, symbol)]);
        return (d || []).map((k) => [num(k[0]), num(k[1]), num(k[2]), num(k[3]), num(k[4]), num(k[5]) * sp.ctVal]).reverse();
      },
      async balance(ctx, creds) {
        const d = await call(ctx, creds, 'GET', '/api/v5/account/balance', { ccy: 'USDT' });
        const det = (d && d[0] && d[0].details) || [];
        const b = det.find((x) => x.ccy === 'USDT');
        return { balances: b ? [{ asset: 'USDT', free: num(b.availBal), locked: Math.max(0, num(b.eq) - num(b.availBal)) }] : [], canTrade: true };
      },
      async setLeverage(ctx, creds, symbol, leverage, marginMode) {
        const mm = await posMode(ctx, creds);
        const body = { instId: symbol, lever: String(Number(leverage)), mgnMode: mgn(marginMode) };
        if (mm === 'long_short' && mgn(marginMode) === 'isolated') {
          await call(ctx, creds, 'POST', '/api/v5/account/set-leverage', null, { ...body, posSide: 'long' });
          return call(ctx, creds, 'POST', '/api/v5/account/set-leverage', null, { ...body, posSide: 'short' });
        }
        return call(ctx, creds, 'POST', '/api/v5/account/set-leverage', null, body);
      },
      async placeOrder(ctx, creds, o) {
        if (o.test) throw new ExchangeError('OKX حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
        const sym = o.market.symbol, sp = await specOf(ctx, sym);
        if (o.leverage) { try { await self.setLeverage(ctx, creds, sym, o.leverage, o.marginMode); } catch (e) { if (!o.ignoreLeverageError) throw e; } }
        const mm = await posMode(ctx, creds), buy = o.side === 'buy', reduce = !!o.reduceOnly;
        const sz = floorToStep(Number(o.qty) / sp.ctVal, sp.lotSz);
        const body = { instId: sym, tdMode: mgn(o.marginMode), side: buy ? 'buy' : 'sell', ordType: o.type === 'limit' ? 'limit' : 'market', sz, clOrdId: cid(o.clientId, 32) };
        if (o.type === 'limit') body.px = o.price;
        if (mm === 'long_short') body.posSide = (buy !== reduce) ? 'long' : 'short'; else if (reduce) body.reduceOnly = true;
        let native = false;
        if (!reduce && (o.sl > 0 || o.tp > 0)) {
          const a = { };
          if (o.sl > 0) { a.slTriggerPx = tickStr(o.sl, o.market); a.slOrdPx = '-1'; a.slTriggerPxType = 'mark'; }
          if (o.tp > 0) { a.tpTriggerPx = tickStr(o.tp, o.market); a.tpOrdPx = '-1'; a.tpTriggerPxType = 'mark'; }
          body.attachAlgoOrds = [a]; native = true;
        }
        const d = await call(ctx, creds, 'POST', '/api/v5/trade/order', null, body);
        return { orderId: String((d && d[0] && d[0].ordId) || ''), nativeProtection: native, raw: d };
      },
      async positions(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/api/v5/account/positions', cleanObj({ instType: 'SWAP', instId: symbol }));
        const out = [];
        for (const x of d || []) {
          const pos = num(x.pos); if (!pos) continue;
          const sp = await specOf(ctx, x.instId);
          const side = x.posSide === 'long' ? 'long' : x.posSide === 'short' ? 'short' : pos > 0 ? 'long' : 'short';
          out.push({ positionId: `${x.instId}|${x.mgnMode}|${x.posSide}`, symbol: x.instId, side, qty: Math.abs(pos) * sp.ctVal, entry: num(x.avgPx), leverage: num(x.lever), margin: num(x.imr || x.margin), pnl: num(x.upl), liqPrice: num(x.liqPx) });
        }
        return out;
      },
      async closePosition(ctx, creds, positionId) {
        const [instId, mgnMode, posSide] = String(positionId).split('|');
        const body = { instId, mgnMode: mgnMode || 'isolated' };
        if (posSide && posSide !== 'net') body.posSide = posSide;
        return { raw: await call(ctx, creds, 'POST', '/api/v5/trade/close-position', null, body) };
      },
      async openOrders(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/api/v5/trade/orders-pending', cleanObj({ instType: 'SWAP', instId: symbol }));
        const out = [];
        for (const x of d || []) { const sp = await specOf(ctx, x.instId); out.push({ orderId: x.ordId, symbol: x.instId, side: x.side, type: x.ordType, price: num(x.px), qty: num(x.sz) * sp.ctVal, filled: num(x.accFillSz) * sp.ctVal, status: x.state }); }
        return out;
      },
      async cancelOrder(ctx, creds, symbol, orderId) {
        return { orderId: String(orderId), raw: await call(ctx, creds, 'POST', '/api/v5/trade/cancel-order', null, { instId: symbol, ordId: String(orderId) }) };
      },
    };
    return self;
  }

  /* ==================================== Bitget ==================================== */
  function bitget() {
    const base = 'https://api.bitget.com', PT = 'USDT-FUTURES';
    const IVM = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1H', '4h': '4H', '1d': '1D', '1w': '1W' };
    const unwrap = (r) => {
      const j = r.json;
      if (r.status >= 400 || !j || String(j.code) !== '00000') throw new ExchangeError((j && j.msg) || 'خطای Bitget ' + r.status, { code: j && j.code, status: r.status, raw: j });
      return j.data;
    };
    const call = async (ctx, creds, method, path, params, body) => {
      need(creds, 'apiKey', 'apiSecret', 'passphrase');
      const ts = String(ctx.now()), query = hasQuery(params) ? qs(params) : '';
      const bodyStr = body ? JSON.stringify(body) : '';
      const headers = { 'ACCESS-KEY': creds.apiKey, 'ACCESS-TIMESTAMP': ts, 'ACCESS-PASSPHRASE': creds.passphrase, 'Content-Type': 'application/json', locale: 'en-US', 'ACCESS-SIGN': hmac('sha256', creds.apiSecret, ts + method + path + (query ? '?' + query : '') + bodyStr, 'base64') };
      return unwrap(await ctx.http(method, `${base}${path}${query ? '?' + query : ''}`, { headers, body: bodyStr || undefined }));
    };
    const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}?${qs(params)}`, {}));
    const hedgeOf = async (ctx, creds, symbol) => {
      try { const d = await call(ctx, creds, 'GET', '/api/v2/mix/account/account', { symbol, productType: PT, marginCoin: 'USDT' }); return !!d && d.posMode === 'hedge_mode'; } catch { return false; }
    };
    const mm = (m) => (m === 'cross' ? 'crossed' : 'isolated');

    const self = {
      id: 'bitget', name: 'Bitget Futures', type: 'futures', needsPassphrase: true, hosts: ['api.bitget.com'],
      async markets(ctx) {
        const d = await pub(ctx, '/api/v2/mix/market/contracts', { productType: PT });
        return (d || []).filter((s) => s.quoteCoin === 'USDT').map((s) => mkMarket({
          symbol: s.symbol, base: s.baseCoin, quote: s.quoteCoin, type: 'futures', trading: s.symbolStatus === 'normal',
          tickSize: num(s.priceEndStep || 1) * 10 ** -num(s.pricePlace), stepSize: num(s.sizeMultiplier) || 10 ** -num(s.volumePlace), minQty: num(s.minTradeNum), minNotional: num(s.minTradeUSDT), maxLeverage: s.maxLever,
        }));
      },
      async tickers(ctx) {
        const d = await pub(ctx, '/api/v2/mix/market/tickers', { productType: PT });
        return (d || []).map((t) => ({ symbol: t.symbol, last: num(t.lastPr), changePct: num(t.change24h) * 100, quoteVol: num(t.quoteVolume), high: num(t.high24h), low: num(t.low24h) }));
      },
      async klines(ctx, symbol, interval, limit) {
        const d = await pub(ctx, '/api/v2/mix/market/candles', { symbol, productType: PT, granularity: IVM[normInterval(interval)], limit: Math.min(limit || 300, 1000) });
        return (d || []).map((k) => [num(k[0]), num(k[1]), num(k[2]), num(k[3]), num(k[4]), num(k[5])]).sort((a, b) => a[0] - b[0]);
      },
      async balance(ctx, creds) {
        const d = await call(ctx, creds, 'GET', '/api/v2/mix/account/accounts', { productType: PT });
        const a = (d || []).find((x) => x.marginCoin === 'USDT');
        return { balances: a ? [{ asset: 'USDT', free: num(a.available), locked: Math.max(0, num(a.accountEquity) - num(a.available)) }] : [], canTrade: true };
      },
      async setLeverage(ctx, creds, symbol, leverage, marginMode) {
        if (marginMode) { try { await call(ctx, creds, 'POST', '/api/v2/mix/account/set-margin-mode', null, { symbol, productType: PT, marginCoin: 'USDT', marginMode: mm(marginMode) }); } catch { /* با پوزیشن باز ممکن نیست */ } }
        return call(ctx, creds, 'POST', '/api/v2/mix/account/set-leverage', null, { symbol, productType: PT, marginCoin: 'USDT', leverage: String(Number(leverage)) });
      },
      async placeOrder(ctx, creds, o) {
        if (o.test) throw new ExchangeError('Bitget حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
        const sym = o.market.symbol;
        if (o.leverage) { try { await self.setLeverage(ctx, creds, sym, o.leverage, o.marginMode); } catch (e) { if (!o.ignoreLeverageError) throw e; } }
        const hedge = await hedgeOf(ctx, creds, sym), buy = o.side === 'buy', reduce = !!o.reduceOnly;
        const body = { symbol: sym, productType: PT, marginMode: mm(o.marginMode), marginCoin: 'USDT', size: o.qty, side: buy ? 'buy' : 'sell', orderType: o.type === 'limit' ? 'limit' : 'market', clientOid: cid(o.clientId, 40, /[^\w-]/g) };
        if (o.type === 'limit') { body.price = o.price; body.force = 'gtc'; }
        if (hedge) body.tradeSide = reduce ? 'close' : 'open'; else if (reduce) body.reduceOnly = 'YES';
        let native = false;
        if (!reduce) {
          if (o.sl > 0) { body.presetStopLossPrice = tickStr(o.sl, o.market); native = true; }
          if (o.tp > 0) { body.presetStopSurplusPrice = tickStr(o.tp, o.market); native = true; }
        }
        const d = await call(ctx, creds, 'POST', '/api/v2/mix/order/place-order', null, body);
        return { orderId: String((d && d.orderId) || ''), nativeProtection: native, raw: d };
      },
      async positions(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/api/v2/mix/position/all-position', { productType: PT, marginCoin: 'USDT' });
        return (d || []).filter((x) => num(x.total) > 0 && (!symbol || x.symbol === symbol)).map((x) => ({ positionId: `${x.symbol}|${x.holdSide}`, symbol: x.symbol, side: x.holdSide === 'short' ? 'short' : 'long', qty: num(x.total), entry: num(x.openPriceAvg), leverage: num(x.leverage), margin: num(x.marginSize), pnl: num(x.unrealizedPL), liqPrice: num(x.liquidationPrice) }));
      },
      async closePosition(ctx, creds, positionId) {
        const [symbol, holdSide] = String(positionId).split('|');
        return { raw: await call(ctx, creds, 'POST', '/api/v2/mix/order/close-positions', null, cleanObj({ symbol, productType: PT, holdSide })) };
      },
      async openOrders(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/api/v2/mix/order/orders-pending', cleanObj({ productType: PT, symbol }));
        const list = (d && d.entrustedList) || [];
        return list.map((x) => ({ orderId: x.orderId, symbol: x.symbol, side: lc(x.side), type: lc(x.orderType), price: num(x.price), qty: num(x.size), filled: num(x.baseVolume), status: x.status }));
      },
      async cancelOrder(ctx, creds, symbol, orderId) {
        return { orderId: String(orderId), raw: await call(ctx, creds, 'POST', '/api/v2/mix/order/cancel-order', null, { symbol, productType: PT, orderId: String(orderId) }) };
      },
    };
    return self;
  }

  /* ===================================== Gate ===================================== */
  function gate() {
    const host = 'https://api.gateio.ws', prefix = '/api/v4', S = '/futures/usdt';
    const IVM = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1h', '4h': '4h', '1d': '1d', '1w': '7d' };
    const unwrap = (r) => {
      const j = r.json;
      if (r.status >= 400 || (j && !Array.isArray(j) && j.label)) throw new ExchangeError((j && (j.message || j.label)) || 'خطای Gate ' + r.status, { code: j && j.label, status: r.status, raw: j });
      return j;
    };
    const call = async (ctx, creds, method, path, params, body) => {
      need(creds, 'apiKey', 'apiSecret');
      const ts = String(Math.floor(ctx.now() / 1000)), query = hasQuery(params) ? qs(params) : '';
      const bodyStr = body ? JSON.stringify(body) : '';
      const payload = [method, prefix + path, query, H.sha512(bodyStr), ts].join('\n');
      const headers = { KEY: creds.apiKey, Timestamp: ts, SIGN: hmac('sha512', creds.apiSecret, payload), 'Content-Type': 'application/json', Accept: 'application/json' };
      return unwrap(await ctx.http(method, `${host}${prefix}${path}${query ? '?' + query : ''}`, { headers, body: bodyStr || undefined }));
    };
    const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${host}${prefix}${path}${params ? '?' + qs(params) : ''}`, {}));
    const mult = new Map();
    const multOf = async (ctx, c) => { if (!mult.has(c)) { const d = await pub(ctx, `${S}/contracts/${c}`); mult.set(c, num(d.quanto_multiplier) || 1); } return mult.get(c); };

    const self = {
      id: 'gate', name: 'Gate Futures', type: 'futures', needsPassphrase: false, hosts: ['api.gateio.ws'],
      async markets(ctx) {
        const d = await pub(ctx, `${S}/contracts`);
        return (d || []).filter((s) => /_USDT$/.test(s.name) && s.type !== 'inverse').map((s) => {
          const m = num(s.quanto_multiplier) || 1; mult.set(s.name, m);
          const mk = mkMarket({ symbol: s.name, base: s.name.split('_')[0], quote: 'USDT', type: 'futures', trading: !s.in_delisting && s.status !== 'delisting', tickSize: num(s.order_price_round), stepSize: m, minQty: num(s.order_size_min || 1) * m, maxLeverage: s.leverage_max });
          mk.mult = m; return mk;
        });
      },
      async tickers(ctx) {
        const d = await pub(ctx, `${S}/tickers`);
        return (d || []).filter((t) => /_USDT$/.test(t.contract)).map((t) => ({ symbol: t.contract, last: num(t.last), changePct: num(t.change_percentage), quoteVol: num(t.volume_24h_quote), high: num(t.high_24h), low: num(t.low_24h) }));
      },
      async klines(ctx, symbol, interval, limit) {
        const [d, m] = await Promise.all([pub(ctx, `${S}/candlesticks`, { contract: symbol, interval: IVM[normInterval(interval)], limit: Math.min(limit || 300, 1000) }), multOf(ctx, symbol)]);
        return (d || []).map((k) => [num(k.t) * 1000, num(k.o), num(k.h), num(k.l), num(k.c), num(k.v) * m]).sort((a, b) => a[0] - b[0]);
      },
      async balance(ctx, creds) {
        const a = await call(ctx, creds, 'GET', `${S}/accounts`);
        return { balances: [{ asset: 'USDT', free: num(a.available), locked: num(a.position_margin) + num(a.order_margin) }], canTrade: true };
      },
      async setLeverage(ctx, creds, symbol, leverage, marginMode) {
        const p = marginMode === 'cross' ? { leverage: 0, cross_leverage_limit: Number(leverage) } : { leverage: Number(leverage) };
        return call(ctx, creds, 'POST', `${S}/positions/${symbol}/leverage`, p);
      },
      async placeOrder(ctx, creds, o) {
        if (o.test) throw new ExchangeError('Gate حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
        const sym = o.market.symbol, m = await multOf(ctx, sym), buy = o.side === 'buy', reduce = !!o.reduceOnly;
        if (o.leverage) { try { await self.setLeverage(ctx, creds, sym, o.leverage, o.marginMode); } catch (e) { if (!o.ignoreLeverageError) throw e; } }
        const n = Math.floor(Number(o.qty) / m + 1e-9);
        if (!(n >= 1)) throw new ExchangeError('حجم کمتر از یک قرارداد است', { code: 'below_min_qty' });
        const body = { contract: sym, size: buy ? n : -n, text: 't-' + cid(o.clientId, 26) };
        if (o.type === 'limit') { body.price = o.price; body.tif = 'gtc'; } else { body.price = '0'; body.tif = 'ioc'; }
        if (reduce) body.reduce_only = true;
        const d = await call(ctx, creds, 'POST', `${S}/orders`, null, body);
        let native = false;
        if (!reduce && o.type !== 'limit' && (o.sl > 0 || o.tp > 0)) {
          const plan = (price, rule) => call(ctx, creds, 'POST', `${S}/price_orders`, null, {
            initial: { contract: sym, size: 0, price: '0', tif: 'ioc', reduce_only: true, close: true },
            trigger: { strategy_type: 0, price_type: 1, price: tickStr(price, o.market), rule, expiration: 2592000 },
            order_type: buy ? 'plan-close-long-position' : 'plan-close-short-position',
          });
          try {
            if (o.sl > 0) await plan(o.sl, buy ? 2 : 1);
            if (o.tp > 0) await plan(o.tp, buy ? 1 : 2);
            native = true;
          } catch (e) {
            try { await call(ctx, creds, 'POST', `${S}/orders`, null, { contract: sym, size: buy ? -n : n, price: '0', tif: 'ioc', reduce_only: true }); } catch { /* ignore */ }
            throw new ExchangeError('ثبت حد ضرر/سود ناموفق بود و پوزیشن بسته شد: ' + e.message, { code: e.exCode, raw: e.raw });
          }
        }
        return { orderId: String((d && d.id) || ''), nativeProtection: native, raw: d };
      },
      async positions(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', `${S}/positions`);
        const out = [];
        for (const x of Array.isArray(d) ? d : []) {
          if (!num(x.size) || (symbol && x.contract !== symbol)) continue;
          const m = await multOf(ctx, x.contract), side = num(x.size) > 0 ? 'long' : 'short';
          out.push({ positionId: `${x.contract}|${side}`, symbol: x.contract, side, qty: Math.abs(num(x.size)) * m, entry: num(x.entry_price), leverage: num(x.leverage) || num(x.cross_leverage_limit), margin: num(x.margin), pnl: num(x.unrealised_pnl), liqPrice: num(x.liq_price) });
        }
        return out;
      },
      async closePosition(ctx, creds, positionId) {
        const [symbol, side] = String(positionId).split('|');
        const d = await call(ctx, creds, 'GET', `${S}/positions/${symbol}`);
        const x = Array.isArray(d) ? d.find((p) => num(p.size)) : d;
        if (!x || !num(x.size) || (side && (num(x.size) > 0 ? 'long' : 'short') !== side)) throw new ExchangeError('موقعیت پیدا نشد', { code: 'position_not_found' });
        return { raw: await call(ctx, creds, 'POST', `${S}/orders`, null, { contract: symbol, size: -num(x.size), price: '0', tif: 'ioc', reduce_only: true }) };
      },
      async openOrders(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', `${S}/orders`, cleanObj({ status: 'open', contract: symbol }));
        const out = [];
        for (const x of Array.isArray(d) ? d : []) { const m = await multOf(ctx, x.contract); out.push({ orderId: String(x.id), symbol: x.contract, side: num(x.size) > 0 ? 'buy' : 'sell', type: num(x.price) ? 'limit' : 'market', price: num(x.price), qty: Math.abs(num(x.size)) * m, filled: Math.abs(num(x.size) - num(x.left)) * m, status: x.status }); }
        return out;
      },
      async cancelOrder(ctx, creds, symbol, orderId) {
        return { orderId: String(orderId), raw: await call(ctx, creds, 'DELETE', `${S}/orders/${orderId}`) };
      },
    };
    return self;
  }

  /* ==================================== KuCoin ==================================== */
  function kucoin() {
    const base = 'https://api-futures.kucoin.com';
    const GR = { '1m': 1, '5m': 5, '15m': 15, '30m': 30, '1h': 60, '4h': 240, '1d': 1440, '1w': 10080 };
    const unwrap = (r) => {
      const j = r.json;
      if (r.status >= 400 || !j || String(j.code) !== '200000') throw new ExchangeError((j && j.msg) || 'خطای KuCoin ' + r.status, { code: j && j.code, status: r.status, raw: j });
      return j.data;
    };
    const call = async (ctx, creds, method, path, params, body) => {
      need(creds, 'apiKey', 'apiSecret', 'passphrase');
      const ts = String(ctx.now()), ep = path + (hasQuery(params) ? '?' + qs(params) : ''), bodyStr = body ? JSON.stringify(body) : '';
      const headers = { 'KC-API-KEY': creds.apiKey, 'KC-API-TIMESTAMP': ts, 'KC-API-KEY-VERSION': '2', 'Content-Type': 'application/json', 'KC-API-SIGN': hmac('sha256', creds.apiSecret, ts + method + ep + bodyStr, 'base64'), 'KC-API-PASSPHRASE': hmac('sha256', creds.apiSecret, creds.passphrase, 'base64') };
      return unwrap(await ctx.http(method, base + ep, { headers, body: bodyStr || undefined }));
    };
    const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));
    const specs = new Map();
    const loadContracts = async (ctx) => { const d = await pub(ctx, '/api/v1/contracts/active'); (d || []).forEach((s) => specs.set(s.symbol, { mult: num(s.multiplier) || 1, lot: num(s.lotSize) || 1 })); return d || []; };
    const specOf = async (ctx, sym) => { if (!specs.has(sym)) await loadContracts(ctx); const v = specs.get(sym); if (!v) throw new ExchangeError('قرارداد پیدا نشد', { code: 'unknown_symbol' }); return v; };
    const baseName = (b) => (b === 'XBT' ? 'BTC' : b);
    const mgn = (m) => (m === 'cross' ? 'CROSS' : 'ISOLATED');

    const self = {
      id: 'kucoin', name: 'KuCoin Futures', type: 'futures', needsPassphrase: true, hosts: ['api-futures.kucoin.com'],
      async markets(ctx) {
        const d = await loadContracts(ctx);
        return d.filter((s) => s.quoteCurrency === 'USDT' && s.settleCurrency === 'USDT' && !s.isInverse && s.type === 'FFWCSX').map((s) => {
          const m = num(s.multiplier) || 1;
          const mk = mkMarket({ symbol: s.symbol, base: baseName(s.baseCurrency), quote: 'USDT', type: 'futures', trading: s.status === 'Open', tickSize: num(s.tickSize), stepSize: num(s.lotSize) * m, minQty: num(s.lotSize) * m, maxLeverage: s.maxLeverage });
          mk.mult = m; return mk;
        });
      },
      async tickers(ctx) {
        const d = await loadContracts(ctx);
        return d.filter((s) => s.quoteCurrency === 'USDT' && !s.isInverse && s.type === 'FFWCSX').map((s) => ({ symbol: s.symbol, last: num(s.lastTradePrice), changePct: num(s.priceChgPct) * 100, quoteVol: num(s.turnoverOf24h), high: num(s.highPrice), low: num(s.lowPrice) }));
      },
      async klines(ctx, symbol, interval, limit) {
        const iv = normInterval(interval), n = Math.min(limit || 300, 500), to = ctx.now();
        const [d, sp] = await Promise.all([pub(ctx, '/api/v1/kline/query', { symbol, granularity: GR[iv], from: to - n * IV_SEC[iv] * 1000, to }), specOf(ctx, symbol)]);
        return (d || []).map((k) => [num(k[0]), num(k[1]), num(k[2]), num(k[3]), num(k[4]), num(k[5]) * sp.mult]).sort((a, b) => a[0] - b[0]);
      },
      async balance(ctx, creds) {
        const a = await call(ctx, creds, 'GET', '/api/v1/account-overview', { currency: 'USDT' });
        return { balances: [{ asset: 'USDT', free: num(a.availableBalance), locked: num(a.positionMargin) + num(a.orderMargin) }], canTrade: true };
      },
      async setLeverage() { return true; }, // در KuCoin اهرم همراه سفارش ارسال می‌شود
      async placeOrder(ctx, creds, o) {
        if (o.test) throw new ExchangeError('KuCoin حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
        const sym = o.market.symbol, sp = await specOf(ctx, sym), buy = o.side === 'buy', reduce = !!o.reduceOnly;
        const lots = floorToStep(Number(o.qty) / sp.mult, sp.lot);
        if (!(Number(lots) >= 1)) throw new ExchangeError('حجم کمتر از یک قرارداد است', { code: 'below_min_qty' });
        const body = { clientOid: cid(o.clientId, 40, /[^\w-]/g), side: buy ? 'buy' : 'sell', symbol: sym, type: o.type === 'limit' ? 'limit' : 'market', size: Number(lots), marginMode: mgn(o.marginMode) };
        if (o.type === 'limit') { body.price = o.price; body.timeInForce = 'GTC'; }
        if (reduce) body.reduceOnly = true; else body.leverage = String(Math.max(1, Number(o.leverage) || 1));
        const d = await call(ctx, creds, 'POST', '/api/v1/orders', null, body);
        let native = false;
        if (!reduce && o.type !== 'limit' && (o.sl > 0 || o.tp > 0)) {
          const stop = (price, dir) => call(ctx, creds, 'POST', '/api/v1/orders', null, { clientOid: rnd(24), side: buy ? 'sell' : 'buy', symbol: sym, type: 'market', stop: dir, stopPriceType: 'MP', stopPrice: tickStr(price, o.market), closeOrder: true, marginMode: mgn(o.marginMode) });
          try {
            if (o.sl > 0) await stop(o.sl, buy ? 'down' : 'up');
            if (o.tp > 0) await stop(o.tp, buy ? 'up' : 'down');
            native = true;
          } catch (e) {
            try { await call(ctx, creds, 'POST', '/api/v1/orders', null, { clientOid: rnd(24), side: buy ? 'sell' : 'buy', symbol: sym, type: 'market', closeOrder: true, marginMode: mgn(o.marginMode) }); } catch { /* ignore */ }
            throw new ExchangeError('ثبت حد ضرر/سود ناموفق بود و پوزیشن بسته شد: ' + e.message, { code: e.exCode, raw: e.raw });
          }
        }
        return { orderId: String((d && d.orderId) || ''), nativeProtection: native, raw: d };
      },
      async positions(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/api/v1/positions');
        const out = [];
        for (const x of Array.isArray(d) ? d : []) {
          if (!num(x.currentQty) || (symbol && x.symbol !== symbol)) continue;
          const sp = await specOf(ctx, x.symbol), side = num(x.currentQty) > 0 ? 'long' : 'short';
          out.push({ positionId: `${x.symbol}|${side}`, symbol: x.symbol, side, qty: Math.abs(num(x.currentQty)) * sp.mult, entry: num(x.avgEntryPrice), leverage: num(x.realLeverage), margin: num(x.posMargin || x.posInit), pnl: num(x.unrealisedPnl), liqPrice: num(x.liquidationPrice) });
        }
        return out;
      },
      async closePosition(ctx, creds, positionId) {
        const [symbol, side] = String(positionId).split('|');
        const p = (await self.positions(ctx, creds, symbol)).find((x) => x.symbol === symbol && (!side || x.side === side));
        if (!p) throw new ExchangeError('موقعیت پیدا نشد', { code: 'position_not_found' });
        return { raw: await call(ctx, creds, 'POST', '/api/v1/orders', null, { clientOid: rnd(24), side: p.side === 'long' ? 'sell' : 'buy', symbol, type: 'market', closeOrder: true }) };
      },
      async openOrders(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/api/v1/orders', cleanObj({ status: 'active', symbol }));
        const out = [];
        for (const x of (d && d.items) || []) { const sp = await specOf(ctx, x.symbol); out.push({ orderId: String(x.id), symbol: x.symbol, side: x.side, type: x.type, price: num(x.price), qty: num(x.size) * sp.mult, filled: num(x.dealSize) * sp.mult, status: x.status }); }
        return out;
      },
      async cancelOrder(ctx, creds, symbol, orderId) {
        return { orderId: String(orderId), raw: await call(ctx, creds, 'DELETE', `/api/v1/orders/${orderId}`) };
      },
    };
    return self;
  }

  return { okx: okx(), bitget: bitget(), gate: gate(), kucoin: kucoin() };
};

};
__defs["./futures-c.js"] = function (module, exports, require) {
'use strict';
/**
 * ترید یار — کانکتورهای فیوچرز USDT-M (دائمی): Bitget, LBank, XT
 * قرارداد مثل bitunix() در exchanges.js است؛ همهٔ مقدارها (qty) در اپ بر حسب «کوین پایه» است
 * و تبدیل به واحد صرافی (قرارداد/لات) درون کانکتور انجام می‌شود.
 * استفاده: const { bitget, lbank, xt } = require('./futures-c')(H)
 */
module.exports = function build(H) {
  const { ExchangeError, hmac, md5, num, rnd, cleanObj, qs, sortedKeys, decimalsOf, stepFromDecimals, floorToStep, mkMarket, normInterval, IV_SEC, need } = H;
  const r12 = (x) => Number(Number(x).toPrecision(12));
  const arr = (x) => (Array.isArray(x) ? x : []);
  const isUsdt = (s) => String(s || '').toUpperCase() === 'USDT';
  const failLev = (e) => new ExchangeError('تنظیم اهرم ناموفق: ' + e.message, { code: e.exCode, raw: e.raw });
  const tsCache = () => { const m = new Map(); return { get: (k, now, ttl) => { const v = m.get(k); return v && now - v.t < ttl ? v.d : undefined; }, set: (k, d, now) => m.set(k, { t: now, d }) }; };

  /* ================================ Bitget (mix v2) ================================ */
  function bitget() {
    const base = 'https://api.bitget.com', PT = 'USDT-FUTURES';
    const IV = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1H', '4h': '4H', '1d': '1D', '1w': '1W' };
    const unwrap = (r) => {
      const j = r.json;
      if (r.status >= 400 || !j || String(j.code) !== '00000') throw new ExchangeError((j && j.msg) || 'خطای Bitget ' + r.status, { code: j && j.code, status: r.status, raw: j });
      return j.data;
    };
    /* امضا: base64(HMAC-SHA256(ts + METHOD + path + ?query + body)) */
    const call = async (ctx, creds, method, path, params, body) => {
      need(creds, 'apiKey', 'apiSecret', 'passphrase');
      const ts = String(ctx.now());
      const query = params ? qs(params) : '';
      const bodyStr = body ? JSON.stringify(body) : '';
      const headers = {
        'ACCESS-KEY': creds.apiKey, 'ACCESS-TIMESTAMP': ts, 'ACCESS-PASSPHRASE': creds.passphrase, 'Content-Type': 'application/json', locale: 'en-US',
        'ACCESS-SIGN': hmac('sha256', creds.apiSecret, ts + method + path + (query ? '?' + query : '') + bodyStr, 'base64'),
      };
      return unwrap(await ctx.http(method, `${base}${path}${query ? '?' + query : ''}`, { headers, body: bodyStr || undefined }));
    };
    const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));
    const modes = tsCache();
    /* حالت پوزیشن حساب: hedge_mode | one_way_mode (پیش‌فرض hedge) */
    const posMode = async (ctx, creds, symbol) => {
      const k = creds.apiKey, c = modes.get(k, ctx.now(), 600000);
      if (c) return c;
      let m = 'hedge_mode';
      try {
        const d = await call(ctx, creds, 'GET', '/api/v2/mix/account/account', { symbol, productType: PT, marginCoin: 'USDT' });
        if (d && d.posMode) m = d.posMode;
      } catch { /* پیش‌فرض */ }
      modes.set(k, m, ctx.now());
      return m;
    };
    const self = {
      id: 'bitget_futures', name: 'Bitget Futures', type: 'futures', needsPassphrase: true, hosts: ['api.bitget.com'],
      async markets(ctx) {
        const d = await pub(ctx, '/api/v2/mix/market/contracts', { productType: PT });
        return arr(d).filter((s) => String(s.quoteCoin).toUpperCase() === 'USDT' && String(s.symbolType || 'perpetual').toLowerCase() === 'perpetual').map((s) => mkMarket({
          symbol: s.symbol, base: s.baseCoin, quote: s.quoteCoin, type: 'futures', trading: String(s.symbolStatus || 'normal').toLowerCase() === 'normal',
          tickSize: r12(num(s.priceEndStep || 1) * stepFromDecimals(num(s.pricePlace))), stepSize: num(s.sizeMultiplier) || stepFromDecimals(num(s.volumePlace)),
          minQty: num(s.minTradeNum), minNotional: num(s.minTradeUSDT), maxLeverage: s.maxLever,
        }));
      },
      async tickers(ctx) {
        const d = await pub(ctx, '/api/v2/mix/market/tickers', { productType: PT });
        return arr(d).map((t) => ({ symbol: t.symbol, last: num(t.lastPr), changePct: num(t.change24h) * 100, quoteVol: num(t.usdtVolume || t.quoteVolume), high: num(t.high24h), low: num(t.low24h) }));
      },
      async klines(ctx, symbol, interval, limit) {
        const d = await pub(ctx, '/api/v2/mix/market/candles', { symbol, productType: PT, granularity: IV[normInterval(interval)], limit: Math.min(limit || 300, 1000) });
        return arr(d).map((k) => [num(k[0]), num(k[1]), num(k[2]), num(k[3]), num(k[4]), num(k[5])]).sort((a, b) => a[0] - b[0]);
      },
      async balance(ctx, creds) {
        const d = await call(ctx, creds, 'GET', '/api/v2/mix/account/accounts', { productType: PT });
        const a = arr(d).find((x) => isUsdt(x.marginCoin)) || arr(d)[0];
        return { balances: a ? [{ asset: 'USDT', free: num(a.available), locked: num(a.locked) }] : [], canTrade: true, equityExtra: a ? { unrealizedPL: num(a.unrealizedPL), accountEquity: num(a.accountEquity) } : null };
      },
      async setLeverage(ctx, creds, symbol, leverage, marginMode) {
        if (marginMode) await call(ctx, creds, 'POST', '/api/v2/mix/account/set-margin-mode', null, { symbol, productType: PT, marginCoin: 'USDT', marginMode: marginMode === 'cross' ? 'crossed' : 'isolated' });
        return call(ctx, creds, 'POST', '/api/v2/mix/account/set-leverage', null, { symbol, productType: PT, marginCoin: 'USDT', leverage: String(Number(leverage)) });
      },
      async placeOrder(ctx, creds, o) {
        if (o.test) throw new ExchangeError('Bitget حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
        const symbol = o.market.symbol;
        if (o.leverage) {
          try { await self.setLeverage(ctx, creds, symbol, o.leverage, o.marginMode); } catch (e) { if (!o.ignoreLeverageError) throw failLev(e); }
        }
        const hedge = (await posMode(ctx, creds, symbol)) !== 'one_way_mode';
        const body = { symbol, productType: PT, marginMode: o.marginMode === 'cross' ? 'crossed' : 'isolated', marginCoin: 'USDT', size: String(o.qty), orderType: o.type === 'limit' ? 'limit' : 'market', clientOid: o.clientId || rnd(24) };
        if (hedge) {
          // هج‌مود: در بستن، side جهت «پوزیشن» است (بستن لانگ = buy/close)
          body.side = o.reduceOnly ? (o.side === 'buy' ? 'sell' : 'buy') : o.side;
          body.tradeSide = o.reduceOnly ? 'close' : 'open';
        } else {
          body.side = o.side;
          if (o.reduceOnly) body.reduceOnly = 'YES';
        }
        if (o.type === 'limit') { body.price = o.price; body.force = 'gtc'; }
        let prot = false;
        if (!o.reduceOnly) {
          if (o.sl > 0) { body.presetStopLossPrice = floorToStep(o.sl, o.market.tickSize); prot = true; }
          if (o.tp > 0) { body.presetStopSurplusPrice = floorToStep(o.tp, o.market.tickSize); prot = true; }
        }
        const d = await call(ctx, creds, 'POST', '/api/v2/mix/order/place-order', null, body);
        return { orderId: String((d && d.orderId) || ''), nativeProtection: prot, raw: d };
      },
      async positions(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/api/v2/mix/position/all-position', { productType: PT, marginCoin: 'USDT' });
        return arr(d).filter((p) => !symbol || p.symbol === symbol).filter((p) => num(p.total) > 0).map((p) => {
          const side = String(p.holdSide).toLowerCase() === 'short' ? 'short' : 'long';
          return { positionId: `${p.symbol}|${side}`, symbol: p.symbol, side, qty: num(p.total), entry: num(p.openPriceAvg), leverage: num(p.leverage), margin: num(p.marginSize), pnl: num(p.unrealizedPL), liqPrice: num(p.liquidationPrice), _available: num(p.available) };
        }).map(({ _available, ...x }) => x);
      },
      async closePosition(ctx, creds, positionId) {
        const [symbol, side] = String(positionId).split('|');
        const d = await call(ctx, creds, 'GET', '/api/v2/mix/position/all-position', { productType: PT, marginCoin: 'USDT' });
        const p = arr(d).find((x) => x.symbol === symbol && String(x.holdSide).toLowerCase() === side && num(x.total) > 0);
        if (!p) throw new ExchangeError('پوزیشن پیدا نشد', { code: 'no_position' });
        const hedge = (await posMode(ctx, creds, symbol)) !== 'one_way_mode';
        const body = { symbol, productType: PT, marginMode: String(p.marginMode || 'crossed').toLowerCase().startsWith('iso') ? 'isolated' : 'crossed', marginCoin: 'USDT', size: String(p.available && num(p.available) > 0 ? p.available : p.total), orderType: 'market', clientOid: rnd(24) };
        if (hedge) { body.side = side === 'long' ? 'buy' : 'sell'; body.tradeSide = 'close'; } else { body.side = side === 'long' ? 'sell' : 'buy'; body.reduceOnly = 'YES'; }
        const r = await call(ctx, creds, 'POST', '/api/v2/mix/order/place-order', null, body);
        return { raw: r };
      },
      async openOrders(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/api/v2/mix/order/orders-pending', { productType: PT, symbol });
        const list = (d && d.entrustedList) || [];
        return arr(list).map((x) => ({ orderId: String(x.orderId), symbol: x.symbol, side: String(x.side).toLowerCase(), type: String(x.orderType || '').toLowerCase(), price: num(x.price), qty: num(x.size), filled: num(x.baseVolume), status: x.status }));
      },
      async cancelOrder(ctx, creds, symbol, orderId) {
        const d = await call(ctx, creds, 'POST', '/api/v2/mix/order/cancel-order', null, { symbol, productType: PT, orderId: String(orderId) });
        return { orderId: String(orderId), raw: d };
      },
    };
    return self;
  }

  /* ================================ XT.com (fapi) ================================ */
  function xt() {
    const base = 'https://fapi.xt.com';
    const unwrap = (r) => {
      const j = r.json;
      const code = j && (j.returnCode !== undefined ? j.returnCode : j.rc);
      if (r.status >= 400 || !j || (code !== undefined && Number(code) !== 0)) throw new ExchangeError((j && (j.msgInfo || j.mc || j.msg)) || 'خطای XT ' + r.status, { code: j && (code !== undefined ? code : j.mc), status: r.status, raw: j });
      return j.result;
    };
    /* امضا: X = هدرهای validate (مرتب) ، Y = #METHOD#path#query#body ؛ sign = HMAC-SHA256(X+Y) */
    const call = async (ctx, creds, method, path, params, body) => {
      need(creds, 'apiKey', 'apiSecret');
      const ts = String(ctx.now()), recv = '10000';
      const hdr = { 'xt-validate-algorithms': 'HmacSHA256', 'xt-validate-appkey': creds.apiKey, 'xt-validate-recvwindow': recv, 'xt-validate-timestamp': ts };
      const X = sortedKeys(hdr).map((k) => `${k}=${hdr[k]}`).join('&');
      const query = params ? sortedKeys(params).map((k) => `${k}=${params[k]}`).join('&') : '';
      const bodyStr = body ? JSON.stringify(body) : '';
      let Y = '#' + method + '#' + path;
      if (query) Y += '#' + query;
      if (bodyStr) Y += '#' + bodyStr;
      const headers = { ...hdr, 'xt-validate-signature': hmac('sha256', creds.apiSecret, X + Y), 'Content-Type': 'application/json' };
      return unwrap(await ctx.http(method, `${base}${path}${query ? '?' + query : ''}`, { headers, body: bodyStr || undefined }));
    };
    const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));
    const lc = (s) => String(s || '').toLowerCase();
    const cache = tsCache();
    const rawContracts = async (ctx) => {
      const c = cache.get('c', ctx.now(), 600000);
      if (c) return c;
      const r = await pub(ctx, '/future/market/v1/public/symbol/list');
      const list = Array.isArray(r) ? r : arr(r && (r.symbols || r.items));
      const d = list.filter((s) => lc(s.contractType || 'perpetual') === 'perpetual' && lc(s.quoteCoin) === 'usdt' && lc(s.underlyingType || 'u_based') !== 'coin_based');
      cache.set('c', d, ctx.now());
      return d;
    };
    const meta = async (ctx, symbol) => {
      const s = (await rawContracts(ctx)).find((x) => lc(x.symbol) === lc(symbol));
      if (!s) throw new ExchangeError('جفت‌ارز در XT فیوچرز پیدا نشد', { code: 'unknown_symbol' });
      return { cs: num(s.contractSize) || 1, stepC: stepFromDecimals(num(s.quantityPrecision) || 0) || 1 };
    };
    const IVX = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1h', '4h': '4h', '1d': '1d', '1w': '1w' };
    const self = {
      id: 'xt_futures', name: 'XT Futures', type: 'futures', needsPassphrase: false, hosts: ['fapi.xt.com'],
      async markets(ctx) {
        const list = await rawContracts(ctx);
        return list.map((s) => {
          const cs = num(s.contractSize) || 1, stepC = stepFromDecimals(num(s.quantityPrecision) || 0) || 1;
          return mkMarket({
            symbol: s.symbol, base: s.baseCoin, quote: s.quoteCoin, type: 'futures', trading: s.tradeSwitch !== false && s.openSwitch !== false,
            tickSize: num(s.minStepPrice) || stepFromDecimals(num(s.pricePrecision)), stepSize: r12(cs * stepC), minQty: r12(num(s.minQty || 1) * cs), minNotional: num(s.minNotional),
            maxLeverage: s.maxLeverage || s.leverageMax,
          });
        });
      },
      async tickers(ctx) {
        const r = await pub(ctx, '/future/market/v1/public/q/tickers');
        return arr(r).map((t) => { const last = num(t.c), open = num(t.o); return { symbol: t.s, last, changePct: open > 0 ? ((last - open) / open) * 100 : num(t.r) * 100, quoteVol: num(t.v), high: num(t.h), low: num(t.l) }; });
      },
      async klines(ctx, symbol, interval, limit) {
        const { cs } = await meta(ctx, symbol);
        const r = await pub(ctx, '/future/market/v1/public/q/kline', { symbol, interval: IVX[normInterval(interval)], limit: Math.min(limit || 300, 500) });
        return arr(r).map((k) => [num(k.t), num(k.o), num(k.h), num(k.l), num(k.c), r12(num(k.a) * cs)]).sort((a, b) => a[0] - b[0]);
      },
      async balance(ctx, creds) {
        const r = await call(ctx, creds, 'GET', '/future/user/v1/balance/detail', { coin: 'usdt' });
        const a = Array.isArray(r) ? r.find((x) => lc(x.coin) === 'usdt') || r[0] : r;
        if (!a) return { balances: [], canTrade: true };
        const free = num(a.availableBalance), wallet = num(a.walletBalance);
        const locked = a.openOrderMarginFrozen !== undefined || a.isolatedMargin !== undefined || a.crossedMargin !== undefined ? num(a.openOrderMarginFrozen) + num(a.isolatedMargin) + num(a.crossedMargin) : Math.max(0, wallet - free);
        return { balances: [{ asset: 'USDT', free, locked }], canTrade: true };
      },
      async setLeverage(ctx, creds, symbol, leverage, marginMode) {
        if (marginMode) await call(ctx, creds, 'POST', '/future/user/v1/position/change-type', null, { symbol, positionType: marginMode === 'cross' ? 'CROSSED' : 'ISOLATED' });
        const res = [];
        for (const positionSide of ['LONG', 'SHORT']) res.push(await call(ctx, creds, 'POST', '/future/user/v1/position/adjust-leverage', null, { symbol, positionSide, leverage: Number(leverage) }));
        return res;
      },
      async placeOrder(ctx, creds, o) {
        if (o.test) throw new ExchangeError('XT حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
        const symbol = o.market.symbol;
        const { cs, stepC } = await meta(ctx, symbol);
        if (o.leverage) {
          try { await self.setLeverage(ctx, creds, symbol, o.leverage, o.marginMode); } catch (e) { if (!o.ignoreLeverageError) throw failLev(e); }
        }
        const contracts = floorToStep(Number(o.qty) / cs, stepC);
        if (!(Number(contracts) > 0)) throw new ExchangeError('حجم کمتر از یک قرارداد است', { code: 'below_step' });
        // جهت پوزیشن: باز کردن buy=LONG ؛ بستن sell=LONG
        const positionSide = (o.side === 'buy') !== !!o.reduceOnly ? 'LONG' : 'SHORT';
        const body = { symbol, orderSide: o.side.toUpperCase(), orderType: o.type === 'limit' ? 'LIMIT' : 'MARKET', origQty: contracts, positionSide, clientOrderId: o.clientId || rnd(24) };
        if (o.type === 'limit') { body.price = o.price; body.timeInForce = 'GTC'; }
        let prot = false;
        if (!o.reduceOnly) {
          if (o.sl > 0) { body.triggerStopPrice = floorToStep(o.sl, o.market.tickSize); prot = true; }
          if (o.tp > 0) { body.triggerProfitPrice = floorToStep(o.tp, o.market.tickSize); prot = true; }
        }
        const r = await call(ctx, creds, 'POST', '/future/trade/v1/order/create', null, body);
        return { orderId: String((r && typeof r === 'object' ? r.orderId : r) || ''), nativeProtection: prot, raw: r };
      },
      async positions(ctx, creds, symbol) {
        const r = await call(ctx, creds, 'GET', '/future/user/v1/position/list', symbol ? { symbol } : {});
        const list = Array.isArray(r) ? r : arr(r && r.items);
        const out = [];
        for (const p of list.filter((x) => num(x.positionSize) > 0)) {
          let cs = 1;
          try { cs = (await meta(ctx, p.symbol)).cs; } catch { /* ناشناخته */ }
          const side = lc(p.positionSide) === 'short' ? 'short' : 'long';
          out.push({ positionId: `${p.symbol}|${side}`, symbol: p.symbol, side, qty: r12(num(p.positionSize) * cs), entry: num(p.entryPrice), leverage: num(p.leverage), margin: num(p.isolatedMargin || p.margin), pnl: num(p.unrealizedProfit), liqPrice: num(p.liquidationPrice) });
        }
        return out;
      },
      async closePosition(ctx, creds, positionId) {
        const [symbol, side] = String(positionId).split('|');
        const r = await call(ctx, creds, 'GET', '/future/user/v1/position/list', { symbol });
        const list = Array.isArray(r) ? r : arr(r && r.items);
        const p = list.find((x) => x.symbol === symbol && lc(x.positionSide) === side && num(x.positionSize) > 0);
        if (!p) throw new ExchangeError('پوزیشن پیدا نشد', { code: 'no_position' });
        const size = num(p.availableCloseSize) > 0 ? p.availableCloseSize : p.positionSize;
        const body = { symbol, orderSide: side === 'long' ? 'SELL' : 'BUY', orderType: 'MARKET', origQty: String(size), positionSide: side.toUpperCase(), clientOrderId: rnd(24) };
        return { raw: await call(ctx, creds, 'POST', '/future/trade/v1/order/create', null, body) };
      },
      async openOrders(ctx, creds, symbol) {
        const r = await call(ctx, creds, 'GET', '/future/trade/v1/order/list', cleanObj({ symbol, state: 'NEW' }));
        const list = Array.isArray(r) ? r : arr(r && (r.items || r.list));
        const out = [];
        for (const x of list) {
          let cs = 1;
          try { cs = (await meta(ctx, x.symbol)).cs; } catch { /* ناشناخته */ }
          out.push({ orderId: String(x.orderId), symbol: x.symbol, side: lc(x.orderSide), type: lc(x.orderType), price: num(x.price), qty: r12(num(x.origQty) * cs), filled: r12(num(x.executedQty) * cs), status: x.state });
        }
        return out;
      },
      async cancelOrder(ctx, creds, symbol, orderId) {
        const d = await call(ctx, creds, 'POST', '/future/trade/v1/order/cancel', null, { orderId: String(orderId) });
        return { orderId: String(orderId), raw: d };
      },
    };
    return self;
  }

  /* ================================ LBank (lbkperp) ================================ */
  function lbank() {
    const base = 'https://lbkperp.lbank.com', PG = 'SwapU';
    const IV = { '1m': 'minute1', '5m': 'minute5', '15m': 'minute15', '30m': 'minute30', '1h': 'hour1', '4h': 'hour4', '1d': 'day1', '1w': 'week1' };
    // مقادیر enum سفارش (طبق مستندات؛ در صورت تغییر اینجا اصلاح شود)
    const ENUM = { open: '0', close: '1', limit: '0', market: '4', orig: '0' };
    const unwrap = (r) => {
      const j = r.json;
      if (r.status >= 400 || !j || (j.result !== undefined && String(j.result) !== 'true') || (j.error_code !== undefined && Number(j.error_code) !== 0)) throw new ExchangeError('خطای LBank (کد ' + ((j && j.error_code) || r.status) + ')' + (j && j.msg ? ': ' + j.msg : ''), { code: j && j.error_code, status: r.status, raw: j });
      return j.data;
    };
    /* امضا: همهٔ پارامترها + api_key/signature_method/timestamp/echostr ، مرتب → MD5 بزرگ → HmacSHA256(hex) ؛ GET: query ، POST: بدنهٔ JSON */
    const call = async (ctx, creds, method, path, params) => {
      need(creds, 'apiKey', 'apiSecret');
      const sys = { signature_method: 'HmacSHA256', timestamp: String(ctx.now()), echostr: rnd(35) };
      const all = cleanObj({ ...(params || {}), api_key: creds.apiKey, ...sys });
      const prepared = sortedKeys(all).map((k) => `${k}=${all[k]}`).join('&');
      const sign = hmac('sha256', creds.apiSecret, md5(prepared).toUpperCase());
      const headers = { 'Content-Type': 'application/json', timestamp: sys.timestamp, signature_method: sys.signature_method, echostr: sys.echostr };
      const full = { ...all, sign };
      if (method === 'GET') return unwrap(await ctx.http('GET', `${base}${path}?${qs(full)}`, { headers }));
      return unwrap(await ctx.http(method, base + path, { headers, body: JSON.stringify(full) }));
    };
    const pub = async (ctx, path, params) => unwrap(await ctx.http('GET', `${base}${path}${params ? '?' + qs(params) : ''}`, {}));
    const cache = tsCache();
    const rawInstruments = async (ctx) => {
      const c = cache.get('i', ctx.now(), 600000);
      if (c) return c;
      const d = arr(await pub(ctx, '/cfd/openApi/v1/pub/instrument', { productGroup: PG })).filter((s) => !s.clearCurrency || isUsdt(s.clearCurrency));
      cache.set('i', d, ctx.now());
      return d;
    };
    const mult = (s) => num(s.volumeMultiple) || 1;
    const meta = async (ctx, symbol) => {
      const s = (await rawInstruments(ctx)).find((x) => x.symbol === symbol);
      if (!s) throw new ExchangeError('جفت‌ارز در LBank فیوچرز پیدا نشد', { code: 'unknown_symbol' });
      return { vm: mult(s), vt: num(s.volumeTick) || 1 };
    };
    const longSide = (v) => ['BUY', 'LONG', '2'].includes(String(v).toUpperCase());
    const self = {
      id: 'lbank_futures', name: 'LBank Futures', type: 'futures', needsPassphrase: false, hosts: ['lbkperp.lbank.com'],
      async markets(ctx) {
        return (await rawInstruments(ctx)).map((s) => {
          const vm = mult(s);
          return mkMarket({
            symbol: s.symbol, base: s.baseCurrency, quote: s.clearCurrency || s.priceCurrency || 'USDT', type: 'futures',
            trading: s.isTrading === undefined ? !/suspend|delist|halt|stop/i.test(String(s.status || s.state || '')) : !!s.isTrading,
            tickSize: num(s.priceTick), stepSize: r12((num(s.volumeTick) || 1) * vm), minQty: r12(num(s.minOrderVolume) * vm), maxLeverage: s.maxLeverage || s.leverageMax,
          });
        });
      },
      async tickers(ctx) {
        const d = await pub(ctx, '/cfd/openApi/v1/pub/marketData', { productGroup: PG });
        return arr(d).map((t) => { const last = num(t.lastPrice), open = num(t.openPrice); return { symbol: t.symbol, last, changePct: open > 0 ? ((last - open) / open) * 100 : 0, quoteVol: num(t.turnover), high: num(t.highestPrice), low: num(t.lowestPrice) }; });
      },
      async klines(ctx, symbol, interval, limit) {
        const iv = normInterval(interval), size = Math.min(limit || 300, 2000);
        const { vm } = await meta(ctx, symbol);
        const d = await pub(ctx, '/cfd/openApi/v1/pub/kline', { symbol, size, type: IV[iv], startTime: Math.floor(ctx.now() / 1000) - IV_SEC[iv] * size });
        const t = (k) => { const x = num(k.time !== undefined ? k.time : k.t !== undefined ? k.t : k[0]); return x < 1e12 ? x * 1000 : x; };
        return arr(d).map((k) => Array.isArray(k)
          ? [t(k), num(k[1]), num(k[2]), num(k[3]), num(k[4]), r12(num(k[5]) * vm)]
          : [t(k), num(k.open), num(k.high), num(k.low), num(k.close), r12(num(k.volume) * vm)]).sort((a, b) => a[0] - b[0]);
      },
      async balance(ctx, creds) {
        const d = await call(ctx, creds, 'GET', '/cfd/openApi/v1/prv/account', { asset: 'USDT', productGroup: PG });
        const a = Array.isArray(d) ? d.find((x) => isUsdt(x.asset)) || d[0] : d;
        if (!a) return { balances: [], canTrade: true };
        const total = num(a.balance), free = num(a.available !== undefined ? a.available : a.availableBalance);
        return { balances: [{ asset: 'USDT', free, locked: Math.max(0, total - free) }], canTrade: true };
      },
      async setLeverage(ctx, creds, symbol, leverage, marginMode) {
        return call(ctx, creds, 'POST', '/cfd/openApi/v1/prv/setLeverage', { symbol, productGroup: PG, leverage: Number(leverage), positionType: marginMode === 'cross' ? '1' : marginMode ? '2' : undefined });
      },
      async placeOrder(ctx, creds, o) {
        if (o.test) throw new ExchangeError('LBank حالت تست ندارد؛ با مبلغ کم امتحان کنید', { code: 'test_unsupported' });
        const symbol = o.market.symbol;
        const { vm, vt } = await meta(ctx, symbol);
        if (o.leverage) {
          try { await self.setLeverage(ctx, creds, symbol, o.leverage, o.marginMode); } catch (e) { if (!o.ignoreLeverageError) throw failLev(e); }
        }
        const lots = floorToStep(Number(o.qty) / vm, vt);
        if (!(Number(lots) > 0)) throw new ExchangeError('حجم کمتر از حداقل قرارداد است', { code: 'below_step' });
        const body = { symbol, volume: lots, side: o.side === 'buy' ? 'BUY' : 'SELL', offsetFlag: o.reduceOnly ? ENUM.close : ENUM.open, orderPriceType: o.type === 'limit' ? ENUM.limit : ENUM.market, origType: ENUM.orig, clientOrderId: o.clientId || rnd(24) };
        if (o.type === 'limit') body.price = o.price;
        const d = await call(ctx, creds, 'POST', '/cfd/openApi/v1/prv/placeOrder', body);
        return { orderId: String((d && (d.orderSysID || d.orderId || d.orderSysId)) || ''), nativeProtection: false, raw: d };
      },
      async positions(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/cfd/openApi/v1/prv/position', cleanObj({ productGroup: PG, symbol }));
        const list = Array.isArray(d) ? d : arr(d && (d.positionList || d.list));
        const out = [];
        for (const p of list.filter((x) => num(x.volume || x.position) > 0)) {
          let vm = 1;
          try { vm = (await meta(ctx, p.symbol)).vm; } catch { /* ناشناخته */ }
          const side = longSide(p.side || p.direction || p.posiDirection || p.positionSide) ? 'long' : 'short';
          out.push({ positionId: `${p.symbol}|${side}`, symbol: p.symbol, side, qty: r12(num(p.volume || p.position) * vm), entry: num(p.openPrice || p.avgPrice), leverage: num(p.leverage), margin: num(p.positionMargin || p.margin), pnl: num(p.unrealizedProfit || p.unrealisedPnl || p.floatProfit), liqPrice: num(p.liquidationPrice || p.liqPrice) });
        }
        return out;
      },
      async closePosition(ctx, creds, positionId) {
        const [symbol, side] = String(positionId).split('|');
        const ps = await self.positions(ctx, creds, symbol);
        const p = ps.find((x) => x.symbol === symbol && x.side === side);
        if (!p) throw new ExchangeError('پوزیشن پیدا نشد', { code: 'no_position' });
        const { vm } = await meta(ctx, symbol);
        const body = { symbol, volume: String(r12(p.qty / vm)), side: side === 'long' ? 'SELL' : 'BUY', offsetFlag: ENUM.close, orderPriceType: ENUM.market, origType: ENUM.orig, clientOrderId: rnd(24) };
        return { raw: await call(ctx, creds, 'POST', '/cfd/openApi/v1/prv/placeOrder', body) };
      },
      async openOrders(ctx, creds, symbol) {
        const d = await call(ctx, creds, 'GET', '/cfd/openApi/v1/prv/orderList', cleanObj({ productGroup: PG, symbol }));
        const list = Array.isArray(d) ? d : arr(d && (d.orderList || d.list));
        const out = [];
        for (const x of list) {
          let vm = 1;
          try { vm = (await meta(ctx, x.symbol)).vm; } catch { /* ناشناخته */ }
          out.push({ orderId: String(x.orderSysID || x.orderId), symbol: x.symbol, side: String(x.side || '').toLowerCase(), type: Number(x.orderPriceType) === Number(ENUM.market) ? 'market' : 'limit', price: num(x.price), qty: r12(num(x.volume) * vm), filled: r12(num(x.tradeVolume || x.volumeTraded) * vm), status: x.orderStatus || x.status });
        }
        return out;
      },
      async cancelOrder(ctx, creds, symbol, orderId) {
        const d = await call(ctx, creds, 'POST', '/cfd/openApi/v1/prv/cancelOrder', { symbol, orderSysID: String(orderId) });
        return { orderId: String(orderId), raw: d };
      },
    };
    return self;
  }

  return { bitget: bitget(), lbank: lbank(), xt: xt() };
};

};
__defs["./trade.js"] = function (module, exports, require) {
'use strict';
/* ترید یار — مسیر /trade/v1 داخل Cloudflare Worker (بدون سرور اختصاصی)
 * همان API سرور اختصاصی (بازار، تحلیل، اتصال و معامله فیوچرز) ولی بدون ربات ۲۴ساعته سمت سرور.
 * کلیدهای API هیچ‌جا ذخیره یا لاگ نمی‌شوند؛ فقط برای امضای همان درخواست استفاده می‌شوند. */
const { CONNECTORS, ALL_HOSTS, listExchanges, ExchangeError, prepareOrder } = require('../server/exchanges.js');

const CORS = {
  'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-tradyar-token', 'Access-Control-Max-Age': '86400',
};
const reply = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { ...CORS, 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });
const httpErr = (status, code) => Object.assign(new Error(code), { status, code });
const hostOk = (h) => { h = h.toLowerCase(); return ALL_HOSTS.some((x) => h === x || h.endsWith('.' + x)); };

const tradeCtx = {
  now: () => Date.now(),
  async http(method, urlStr, { headers = {}, body } = {}) {
    let u; try { u = new URL(urlStr); } catch { throw httpErr(400, 'bad_url'); }
    if (u.protocol !== 'https:' || !hostOk(u.hostname)) throw httpErr(403, 'host_not_allowed');
    const resp = await fetch(u.toString(), { method, redirect: 'manual', signal: AbortSignal.timeout(20000), headers: { 'user-agent': 'TradYar/1.1', accept: 'application/json', ...headers }, body });
    const text = await resp.text();
    let json = null; try { json = JSON.parse(text); } catch { /* ممکن است JSON نباشد */ }
    return { status: resp.status, json, text: text.slice(0, 2000) };
  },
};

const marketsCache = new Map(), tickersCache = new Map(), klinesCache = new Map();
function getConnector(id) { const c = CONNECTORS[String(id || '').toLowerCase()]; if (!c) throw httpErr(400, 'unknown_exchange'); return c; }
async function getMarkets(c, force) {
  const e = marketsCache.get(c.id);
  if (e && !force && Date.now() - e.at < 600000) return e;
  const list = await c.markets(tradeCtx);
  const fresh = { at: Date.now(), list, map: new Map(list.map((m) => [m.symbol, m])) };
  marketsCache.set(c.id, fresh); return fresh;
}
async function getTickers(c) {
  const e = tickersCache.get(c.id);
  if (e && Date.now() - e.at < 4000) return e.list;
  const list = await c.tickers(tradeCtx); tickersCache.set(c.id, { at: Date.now(), list }); return list;
}
function sanitizeCreds(cr) {
  if (!cr || typeof cr !== 'object') throw httpErr(400, 'missing_creds');
  const out = {};
  for (const k of ['apiKey', 'apiSecret', 'passphrase']) if (cr[k] !== undefined) { const v = String(cr[k]).trim(); if (v.length > 512 || /[\r\n]/.test(v)) throw httpErr(400, 'bad_creds'); out[k] = v; }
  return out;
}

async function placeOrderFlow(c, creds, o) {
  const mk = (await getMarkets(c)).map.get(String(o.symbol));
  const prepared = prepareOrder(mk, o);
  const order = {
    ...prepared, symbol: mk.symbol, test: o.test === true, clientId: o.clientId ? String(o.clientId).slice(0, 36).replace(/[^\w-]/g, '') : undefined,
    sl: Number(o.sl) || 0, tp: Number(o.tp) || 0, leverage: Number(o.leverage) || 0, marginMode: o.marginMode === 'cross' ? 'cross' : o.marginMode ? 'isolated' : undefined, reduceOnly: o.reduceOnly === true,
  };
  if (c.type === 'futures' && order.leverage && mk.maxLeverage && order.leverage > mk.maxLeverage) throw new ExchangeError('اهرم بیشتر از سقف مجاز این جفت‌ارز است (' + mk.maxLeverage + ')', { code: 'leverage_too_high' });
  const r = await c.placeOrder(tradeCtx, creds, order);
  const out = { ok: true, exchange: c.id, test: order.test, symbol: mk.symbol, side: order.side, type: order.type, sent: { qty: order.qty, quoteQty: order.quoteQty, price: order.price }, orderId: r.orderId, status: r.status, filledQty: r.filledQty, quoteSpent: r.quoteSpent };
  if (c.type === 'futures') out.protection = { native: !!r.nativeProtection, mode: 'attached' };
  return out;
}

const SIGNED = new Set(['balance', 'verify', 'order', 'orders', 'cancel', 'positions', 'close', 'leverage']);
const PUBLIC = new Set(['markets', 'tickers', 'klines']);

async function handleTrade(request) {
  if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
  try {
    const url = new URL(request.url);
    const op = url.pathname.replace(/^\/trade(\/v1)?\/?/, '').replace(/\/+$/, '');
    if (op === 'health') return reply({ ok: true, trade: true, version: '1.1.0-worker', exchanges: Object.keys(CONNECTORS).length, tokenRequired: false });
    if (op === 'exchanges') return reply({ ok: true, exchanges: listExchanges() });
    if (op === 'egress') return reply({ ok: true, ip: null });
    if (op === 'bot/info') return reply({ ok: true, enabled: false, ai: false, caps: null });
    if (request.method !== 'POST') throw httpErr(405, 'method_not_allowed');
    if (!SIGNED.has(op) && !PUBLIC.has(op)) throw httpErr(404, 'unknown_op');
    let body; try { body = JSON.parse((await request.text()) || '{}'); } catch { throw httpErr(400, 'bad_json'); }
    const c = getConnector(body.exchange);
    if (op === 'markets') { const m = await getMarkets(c, body.refresh === true); return reply({ ok: true, exchange: c.id, type: c.type, at: m.at, markets: m.list }); }
    if (op === 'tickers') return reply({ ok: true, exchange: c.id, at: Date.now(), tickers: await getTickers(c) });
    if (op === 'klines') {
      const symbol = String(body.symbol || ''); if (!symbol || symbol.length > 40) throw httpErr(400, 'bad_symbol');
      const limit = Math.max(20, Math.min(parseInt(body.limit, 10) || 300, 1000));
      const key = [c.id, symbol, body.interval, limit].join('|'), hit = klinesCache.get(key);
      let data;
      if (hit && Date.now() - hit.at < 3000) data = hit.data;
      else { data = await c.klines(tradeCtx, symbol, body.interval, limit); klinesCache.set(key, { at: Date.now(), data }); if (klinesCache.size > 200) klinesCache.delete(klinesCache.keys().next().value); }
      return reply({ ok: true, exchange: c.id, symbol, klines: data });
    }
    const creds = sanitizeCreds(body.creds);
    if (op === 'balance' || op === 'verify') {
      const t0 = Date.now(), b = await c.balance(tradeCtx, creds), out = { ok: true, exchange: c.id, latencyMs: Date.now() - t0, ...b };
      if (op === 'verify') {
        out.warnings = [];
        if (b.canWithdraw === true) out.warnings.push('این کلید دسترسی «برداشت» دارد — برای امنیت، کلید را فقط با دسترسی Trade بسازید.');
        if (b.canTrade === false) out.warnings.push('این کلید اجازهٔ معامله ندارد.');
      }
      return reply(out);
    }
    if (op === 'order') return reply(await placeOrderFlow(c, creds, body.order || {}));
    if (op === 'orders') return reply({ ok: true, orders: typeof c.openOrders === 'function' ? await c.openOrders(tradeCtx, creds, body.symbol) : [] });
    if (op === 'cancel') { const r = await c.cancelOrder(tradeCtx, creds, String(body.symbol), String(body.orderId)); return reply({ ok: true, orderId: r.orderId }); }
    if (op === 'positions') return reply({ ok: true, positions: typeof c.positions === 'function' ? await c.positions(tradeCtx, creds, body.symbol) : [] });
    if (op === 'close') { await c.closePosition(tradeCtx, creds, String(body.positionId)); return reply({ ok: true }); }
    if (op === 'leverage') { await c.setLeverage(tradeCtx, creds, String(body.symbol), Number(body.leverage), body.marginMode); return reply({ ok: true }); }
    throw httpErr(404, 'unknown_op');
  } catch (e) {
    if (e instanceof ExchangeError) return reply({ ok: false, error: 'exchange_error', message: String(e.message || 'خطای صرافی').slice(0, 300), code: e.exCode !== undefined ? String(e.exCode) : undefined, status: e.exStatus }, 422);
    if (e && e.status && e.code) return reply({ ok: false, error: e.code }, e.status);
    return reply({ ok: false, error: 'internal_error', message: String(e && e.message || e).slice(0, 200) }, 500);
  }
}
module.exports = { handleTrade };

};
/**
 * ترید یار — Worker یکپارچه: همگام‌سازی + ریلی APIهای عمومی
 *
 * کار این Worker:
 *  1) GET/POST روی ریشه ("/")  → ذخیره/بازیابی داده‌های همگام‌سازی (مثل نسخهٔ قبلی)
 *  2) GET/POST روی "/relay?u=<URL>" → عبور دادن درخواست به APIهای عمومی قیمت و AI
 *     (فقط دامنه‌های داخل لیست مجاز؛ پروکسی باز نیست)
 *
 * دیپلوی:
 *  - کد را جایگزین Worker فعلی کنید و Deploy بزنید.
 *  - (اختیاری ولی مهم) KV بسازید و با نام TRADYAR_KV به Worker bind کنید.
 *    اگر KV نبود، مثل قبل از textdb.dev استفاده می‌شود.
 *  - برای اینکه بدون فیلترشکن کار کند: به‌جای *.workers.dev
 *    یک دامنهٔ شخصی (Custom Domain) به Worker وصل کنید.
 */

const TEXTDB_URL = 'https://textdb.dev/api/data/4b1d3f97-6c1a-4e8b-9f2a-1a2b3c4d5e6f';
const KV_KEY = 'tradyar_sync_data';
const MAX_BODY = 1024 * 1024; // 1MB

// فقط این دامنه‌ها (و زیردامنه‌هایشان) قابل ریلی هستند
const ALLOWED_HOSTS = [
  'api.binance.com', 'data-api.binance.vision', 'fapi.binance.com',
  'api.bybit.com', 'www.okx.com', 'api.gateio.ws', 'api.kucoin.com',
  'api.mexc.com', 'api.bitget.com', 'api.kraken.com', 'api-pub.bitfinex.com',
  'www.bitstamp.net', 'api.coinex.com', 'api.bitmart.com', 'api.coinbase.com',
  'api.crypto.com', 'www.bitmex.com', 'api.hitbtc.com', 'api.huobi.pro',
  'api.lbkex.com', 'api.coingecko.com', 'coincheck.com',
  'api.openai.com',
  'contract.mexc.com', 'api-futures.kucoin.com', 'fapi.bitunix.com', 'lbkperp.lbank.com', 'fapi.xt.com', 'sapi.xt.com',
  'text.pollinations.ai',
  // سرویس‌های هوش مصنوعی (بخش API Keys پنل ادمین)
  'api.anthropic.com', 'generativelanguage.googleapis.com', 'api.groq.com',
  'openrouter.ai', 'api.deepseek.com', 'api.x.ai', 'api.mistral.ai',
  'api.perplexity.ai', 'api.together.xyz', 'api.gapgpt.app',
];

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': '*',
  'Access-Control-Max-Age': '86400',
  'Access-Control-Expose-Headers': 'X-Tradyar-Relay',
};

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: { ...CORS, 'Content-Type': 'application/json' },
  });

function hostAllowed(host) {
  host = host.toLowerCase();
  return ALLOWED_HOSTS.some((h) => host === h || host.endsWith('.' + h));
}

async function handleRelay(request, url) {
  const raw = url.searchParams.get('u');
  if (!raw) return json({ ok: false, error: 'missing_u' }, 400);

  let target;
  try { target = new URL(raw); } catch { return json({ ok: false, error: 'bad_url' }, 400); }
  if (target.protocol !== 'https:') return json({ ok: false, error: 'https_only' }, 400);
  if (!hostAllowed(target.hostname)) return json({ ok: false, error: 'host_not_allowed' }, 403);

  const init = { method: request.method, headers: {} };
  const ct = request.headers.get('Content-Type');
  if (ct) init.headers['Content-Type'] = ct;
  const auth = request.headers.get('Authorization');
  if (auth) init.headers['Authorization'] = auth;
  for (const h of ['x-api-key', 'anthropic-version', 'x-goog-api-key']) {
    const v = request.headers.get(h);
    if (v) init.headers[h] = v;
  }
  // هدرهای امضای صرافی‌ها (Binance / Bybit / OKX / Bitget / ...) برای معامله از داخل برنامه
  for (const [k, v] of request.headers) {
    if (/^(x-mbx-|x-bapi-|ok-access-|access-|x-bit-|x-mexc-|kc-api-|key$|sign$|timestamp$|apikey$|x-bx-|x-xt-|validate-|bt-)/i.test(k)) init.headers[k] = v;
  }
  if (request.method === 'POST') {
    const body = await request.text();
    if (body.length > MAX_BODY) return json({ ok: false, error: 'too_large' }, 413);
    init.body = body;
  }

  const upstream = await fetch(target.toString(), init);
  const headers = new Headers(CORS);
  headers.set('Content-Type', upstream.headers.get('Content-Type') || 'application/json');
  headers.set('Cache-Control', 'no-store');
  headers.set('X-Tradyar-Relay', '1'); // کلاینت با این هدر مطمئن می‌شود پاسخ واقعاً از ریلی است
  return new Response(upstream.body, { status: upstream.status, headers });
}

async function handleSync(request, env) {
  if (request.method === 'GET') {
    let text = null;
    if (env && env.TRADYAR_KV) {
      text = await env.TRADYAR_KV.get(KV_KEY);
    } else {
      const r = await fetch(TEXTDB_URL);
      text = await r.text();
    }
    let doc = null;
    try { doc = JSON.parse(text); } catch (e) {}
    if (doc && doc.v) return json({ ok: true, doc });
    return json({ ok: false, reason: 'no_data' });
  }

  if (request.method === 'POST') {
    const body = await request.text();
    if (body.length > MAX_BODY) return json({ ok: false, error: 'too_large' }, 413);
    if (env && env.TRADYAR_KV) {
      await env.TRADYAR_KV.put(KV_KEY, body);
      return json({ ok: true });
    }
    const r = await fetch(TEXTDB_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain' },
      body,
    });
    return r.ok ? json({ ok: true }) : json({ ok: false, error: 'textdb_error' }, 502);
  }

  return json({ ok: false, error: 'method_not_allowed' }, 405);
}

const __relay = {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
    const url = new URL(request.url);
    try {
      if (url.pathname === '/relay') return await handleRelay(request, url);
      return await handleSync(request, env);
    } catch (e) {
      return json({ ok: false, error: String(e) }, 500);
    }
  },
};

export default {
  async fetch(request, env, ctx) {
    const p = new URL(request.url).pathname;
    if (p === '/trade' || p.startsWith('/trade/')) return __req('./trade.js').handleTrade(request);
    return __relay.fetch(request, env, ctx);
  },
};
