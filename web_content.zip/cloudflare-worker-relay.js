/**
 * ترید یار — Worker یکپارچه: همگام‌سازی + ریلی APIهای عمومی
 *
 * کار این Worker:
 *  1) GET/POST روی ریشه ("/")  → ذخیره/بازیابی داده‌های همگام‌سازی (مثل نسخهٔ قبلی)
 *  2) GET/POST روی "/relay?u=<URL>" → عبور دادن درخواست به APIهای عمومی قیمت و AI
 *     (فقط دامنه‌های داخل لیست مجاز؛ پروکسی باز نیست)
 *
 * دیپلوی:
 *  - کد را جایگزین Worker فعلی کنید و Deploy بزنید.
 *  - (اختیاری ولی مهم) KV بسازید و با نام TRADYAR_KV به Worker bind کنید.
 *    اگر KV نبود، مثل قبل از textdb.dev استفاده می‌شود.
 *  - برای اینکه بدون فیلترشکن کار کند: به‌جای *.workers.dev
 *    یک دامنهٔ شخصی (Custom Domain) به Worker وصل کنید.
 */

const TEXTDB_URL = 'https://textdb.dev/api/data/4b1d3f97-6c1a-4e8b-9f2a-1a2b3c4d5e6f';
const KV_KEY = 'tradyar_sync_data';
const MAX_BODY = 1024 * 1024; // 1MB

// فقط این دامنه‌ها (و زیردامنه‌هایشان) قابل ریلی هستند
const ALLOWED_HOSTS = [
  'api.binance.com', 'data-api.binance.vision', 'fapi.binance.com',
  'api.bybit.com', 'www.okx.com', 'api.gateio.ws', 'api.kucoin.com',
  'api.mexc.com', 'api.bitget.com', 'api.kraken.com', 'api-pub.bitfinex.com',
  'www.bitstamp.net', 'api.coinex.com', 'api.bitmart.com', 'api.coinbase.com',
  'api.crypto.com', 'www.bitmex.com', 'api.hitbtc.com', 'api.huobi.pro',
  'api.lbkex.com', 'api.coingecko.com', 'coincheck.com',
  'api.openai.com',
  'text.pollinations.ai',
];

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Access-Control-Max-Age': '86400',
  'Access-Control-Expose-Headers': 'X-Tradyar-Relay',
};

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: { ...CORS, 'Content-Type': 'application/json' },
  });

function hostAllowed(host) {
  host = host.toLowerCase();
  return ALLOWED_HOSTS.some((h) => host === h || host.endsWith('.' + h));
}

async function handleRelay(request, url) {
  const raw = url.searchParams.get('u');
  if (!raw) return json({ ok: false, error: 'missing_u' }, 400);

  let target;
  try { target = new URL(raw); } catch { return json({ ok: false, error: 'bad_url' }, 400); }
  if (target.protocol !== 'https:') return json({ ok: false, error: 'https_only' }, 400);
  if (!hostAllowed(target.hostname)) return json({ ok: false, error: 'host_not_allowed' }, 403);

  const init = { method: request.method, headers: {} };
  const ct = request.headers.get('Content-Type');
  if (ct) init.headers['Content-Type'] = ct;
  const auth = request.headers.get('Authorization');
  if (auth) init.headers['Authorization'] = auth;
  if (request.method === 'POST') {
    const body = await request.text();
    if (body.length > MAX_BODY) return json({ ok: false, error: 'too_large' }, 413);
    init.body = body;
  }

  const upstream = await fetch(target.toString(), init);
  const headers = new Headers(CORS);
  headers.set('Content-Type', upstream.headers.get('Content-Type') || 'application/json');
  headers.set('Cache-Control', 'no-store');
  headers.set('X-Tradyar-Relay', '1'); // کلاینت با این هدر مطمئن می‌شود پاسخ واقعاً از ریلی است
  return new Response(upstream.body, { status: upstream.status, headers });
}

async function handleSync(request, env) {
  if (request.method === 'GET') {
    let text = null;
    if (env && env.TRADYAR_KV) {
      text = await env.TRADYAR_KV.get(KV_KEY);
    } else {
      const r = await fetch(TEXTDB_URL);
      text = await r.text();
    }
    let doc = null;
    try { doc = JSON.parse(text); } catch (e) {}
    if (doc && doc.v) return json({ ok: true, doc });
    return json({ ok: false, reason: 'no_data' });
  }

  if (request.method === 'POST') {
    const body = await request.text();
    if (body.length > MAX_BODY) return json({ ok: false, error: 'too_large' }, 413);
    if (env && env.TRADYAR_KV) {
      await env.TRADYAR_KV.put(KV_KEY, body);
      return json({ ok: true });
    }
    const r = await fetch(TEXTDB_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain' },
      body,
    });
    return r.ok ? json({ ok: true }) : json({ ok: false, error: 'textdb_error' }, 502);
  }

  return json({ ok: false, error: 'method_not_allowed' }, 405);
}

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
    const url = new URL(request.url);
    try {
      if (url.pathname === '/relay') return await handleRelay(request, url);
      return await handleSync(request, env);
    } catch (e) {
      return json({ ok: false, error: String(e) }, 500);
    }
  },
};
