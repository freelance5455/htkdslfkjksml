# ABU GAME Android долбоору

Бул ZIP — даяр APK эмес, Android Studio аркылуу APK чогултуу үчүн долбоор.

1. Android Studio'до ушул папканы ач.
2. Android SDK 35 жана Gradle sync орнот.
3. Build > Build APK(s) бас.
4. APK app/build/outputs/apk/debug/ ичинде пайда болот.

Оюн офлайн иштейт: HTML Android WebView'ге кошулган.
