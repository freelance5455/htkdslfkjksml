Ahmadi Finance Manager Android Project
Open this folder in Android Studio, wait for Gradle Sync, then Build > Build APK(s).
APK: app/build/outputs/apk/debug/app-debug.apk
