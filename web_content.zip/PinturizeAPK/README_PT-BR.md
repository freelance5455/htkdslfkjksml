# Pinturize — projeto Android

Primeira estrutura real do aplicativo Pinturize, baseada no modelo enviado.

## Incluído
- Tela inicial com identidade Pinturize
- Solicitação de orçamento
- Seleção de fotos do aparelho
- Serviços
- Meus pedidos (estrutura inicial)
- Botão direto para WhatsApp: (21) 97561-3428
- Logo da Pinturize
- Interface Android em modo retrato

## Como gerar o APK
Abra esta pasta como projeto no Android Studio e use **Build > Generate App Bundles or APKs > Generate APKs**.

Para publicação em loja, ainda será necessário configurar assinatura do aplicativo, política de privacidade e dados da conta da loja.
