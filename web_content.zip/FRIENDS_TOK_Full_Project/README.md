# FRIENDS TOK — full-stack starter

A private, short-video social app starter with a neon purple/black interface.

## Included
- Email/password registration and login (bcrypt password hashing)
- Invite-code gate for registration
- Email verification flow (prints a verification link in the server console by default; optional SMTP)
- JWT authentication
- User profiles and profile editing
- Vertical video feed and video upload
- Likes, comments, following
- Direct messages
- Notifications
- User blocking and content reporting
- SQLite database and local upload storage

## Important limitations
This is a deployable **starter**, not a production-certified social network. It has not been security-audited or load-tested. It does not include automated content moderation, push notifications, video transcoding/CDN delivery, password reset, age assurance, or robust abuse prevention. Before inviting real users, add moderation, rate limiting, backups, HTTPS, secure hosting, and a privacy policy. Do not use it to collect sensitive personal information. For public launch, have a trusted adult review hosting, privacy, and safety settings.

## Run locally
Requires Node.js 20+.

1. Extract the ZIP.
2. Copy `.env.example` to `.env`.
3. Set a long random `JWT_SECRET` and your private `INVITE_CODE`.
4. Run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

The first registered account must still have the invite code. To verify an account during local testing, open the verification link printed in the terminal.

## Email setup (optional)
Set `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, and `SMTP_FROM` in `.env`. Verification links will then be emailed. Keep `.env` secret and never upload it to GitHub.

## Deploy
Deploy the project to a Node.js host that supports persistent disk storage. Set the environment variables from `.env.example`, including a strong `JWT_SECRET`, `INVITE_CODE`, and SMTP settings. The host must preserve `data.sqlite` and `uploads/` across restarts. Use HTTPS and a persistent volume. A serverless/static-only host will not work without replacing SQLite and local uploads with managed database/object storage.

## API overview
- `POST /api/register`
- `POST /api/login`
- `GET /api/verify?token=...`
- `GET /api/me`
- `PATCH /api/profile`
- `GET /api/feed`
- `POST /api/videos` (multipart field `video`)
- `POST /api/videos/:id/like`
- `GET/POST /api/videos/:id/comments`
- `POST /api/users/:id/follow`
- `GET /api/messages/:userId`
- `POST /api/messages/:userId`
- `GET /api/notifications`
- `POST /api/users/:id/block`
- `POST /api/reports`

Use only with people you know and trust. Never publish private contact details in videos or profiles.
