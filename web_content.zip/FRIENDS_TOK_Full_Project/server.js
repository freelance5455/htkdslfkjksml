require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const multer = require("multer");
const nodemailer = require("nodemailer");
const crypto = require("crypto");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const SECRET = process.env.JWT_SECRET;
if (!SECRET || SECRET.length < 24) {
  console.error("Set JWT_SECRET in .env to a random string at least 24 characters long.");
  process.exit(1);
}
const uploadDir = path.join(__dirname, "uploads");
fs.mkdirSync(uploadDir, { recursive: true });
app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));
app.use(cors({ origin: process.env.APP_URL || true }));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/uploads", express.static(uploadDir, { maxAge: "1h" }));

const db = new Database(path.join(__dirname, "data.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE NOT NULL, username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, bio TEXT DEFAULT '', avatar TEXT DEFAULT '', verified INTEGER DEFAULT 0,
 verify_token TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS videos(
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, filename TEXT NOT NULL,
 caption TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS likes(user_id INTEGER, video_id INTEGER, created_at TEXT DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(user_id,video_id));
CREATE TABLE IF NOT EXISTS comments(
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, video_id INTEGER NOT NULL,
 body TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS follows(follower_id INTEGER, followed_id INTEGER, created_at TEXT DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(follower_id,followed_id));
CREATE TABLE IF NOT EXISTS messages(
 id INTEGER PRIMARY KEY AUTOINCREMENT, sender_id INTEGER NOT NULL, receiver_id INTEGER NOT NULL,
 body TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS notifications(
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, actor_id INTEGER NOT NULL,
 kind TEXT NOT NULL, item_id INTEGER, seen INTEGER DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS blocks(blocker_id INTEGER, blocked_id INTEGER, PRIMARY KEY(blocker_id,blocked_id));
CREATE TABLE IF NOT EXISTS reports(
 id INTEGER PRIMARY KEY AUTOINCREMENT, reporter_id INTEGER NOT NULL, target_type TEXT NOT NULL,
 target_id INTEGER NOT NULL, reason TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);`);

const transporter = process.env.SMTP_HOST ? nodemailer.createTransport({
  host: process.env.SMTP_HOST, port: Number(process.env.SMTP_PORT || 587),
  secure: Number(process.env.SMTP_PORT) === 465,
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
}) : null;
async function sendVerification(email, token) {
  const link = `${process.env.APP_URL || `http://localhost:${PORT}`}/api/verify?token=${token}`;
  if (transporter) await transporter.sendMail({ from: process.env.SMTP_FROM, to: email, subject: "Verify your FRIENDS TOK email", text: `Verify your account: ${link}` });
  else console.log(`\n[FRIENDS TOK verification for ${email}]\n${link}\n`);
}
const sign = user => jwt.sign({ id: user.id }, SECRET, { expiresIn: "7d" });
function auth(req,res,next) {
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i,"");
  try { if (!token) throw new Error(); req.user = jwt.verify(token, SECRET); next(); }
  catch { res.status(401).json({ error: "Please log in again." }); }
}
function blockedEither(a,b) {
  return !!db.prepare("SELECT 1 FROM blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?)").get(a,b,b,a);
}
function notify(userId, actorId, kind, itemId=null) {
  if (userId !== actorId && !blockedEither(userId,actorId))
    db.prepare("INSERT INTO notifications(user_id,actor_id,kind,item_id) VALUES(?,?,?,?)").run(userId,actorId,kind,itemId);
}
const safeUser = id => db.prepare("SELECT id,username,bio,avatar,created_at FROM users WHERE id=?").get(id);
app.get("/api/health", (req,res)=>res.json({ok:true,app:"FRIENDS TOK"}));

app.post("/api/register", async (req,res)=>{
  try {
    const {email,username,password,inviteCode}=req.body||{};
    if (!email || !username || !password || !inviteCode) return res.status(400).json({error:"Fill in every field."});
    if (inviteCode !== (process.env.INVITE_CODE || "FRIENDS-2026")) return res.status(403).json({error:"That invite code is not valid."});
    if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) return res.status(400).json({error:"Username must be 3–20 letters, numbers, or underscores."});
    if (String(password).length < 10) return res.status(400).json({error:"Use a password with at least 10 characters."});
    const token=crypto.randomBytes(32).toString("hex"), hash=await bcrypt.hash(password,12);
    const result=db.prepare("INSERT INTO users(email,username,password_hash,verify_token) VALUES(?,?,?,?)").run(String(email).toLowerCase(),username,hash,token);
    await sendVerification(String(email).toLowerCase(),token);
    res.status(201).json({message:"Account created. Verify your email using the link sent (or shown in the server console).",user:safeUser(result.lastInsertRowid)});
  } catch(e) { res.status(400).json({error:e.code==="SQLITE_CONSTRAINT_UNIQUE"?"Email or username is already registered.":"Could not create account."}); }
});
app.get("/api/verify",(req,res)=>{
  const result=db.prepare("UPDATE users SET verified=1,verify_token=NULL WHERE verify_token=?").run(req.query.token||"");
  res.send(result.changes ? "<h2>Email verified!</h2><p>You can return to FRIENDS TOK and log in.</p>" : "<h2>Link invalid or already used.</h2>");
});
app.post("/api/login",async(req,res)=>{
  const {email,password}=req.body||{}, user=db.prepare("SELECT * FROM users WHERE email=?").get(String(email||"").toLowerCase());
  if(!user || !(await bcrypt.compare(password||"",user.password_hash))) return res.status(401).json({error:"Email or password is incorrect."});
  if(!user.verified) return res.status(403).json({error:"Please verify your email first."});
  res.json({token:sign(user),user:safeUser(user.id)});
});
app.get("/api/me",auth,(req,res)=>res.json({user:safeUser(req.user.id)}));
app.patch("/api/profile",auth,(req,res)=>{
  const {username,bio,avatar}=req.body||{};
  if(username && !/^[a-zA-Z0-9_]{3,20}$/.test(username)) return res.status(400).json({error:"Invalid username."});
  try {
    db.prepare("UPDATE users SET username=COALESCE(?,username),bio=COALESCE(?,bio),avatar=COALESCE(?,avatar) WHERE id=?")
      .run(username||null,typeof bio==="string"?bio.slice(0,160):null,typeof avatar==="string"?avatar.slice(0,500):null,req.user.id);
    res.json({user:safeUser(req.user.id)});
  } catch { res.status(400).json({error:"Username may already be taken."}); }
});
app.get("/api/feed",auth,(req,res)=>{
  const rows=db.prepare(`SELECT v.*,u.username,u.avatar,
    (SELECT COUNT(*) FROM likes l WHERE l.video_id=v.id) likes,
    (SELECT COUNT(*) FROM comments c WHERE c.video_id=v.id) comments,
    EXISTS(SELECT 1 FROM likes l WHERE l.video_id=v.id AND l.user_id=?) liked
    FROM videos v JOIN users u ON u.id=v.user_id
    WHERE v.user_id NOT IN (SELECT blocked_id FROM blocks WHERE blocker_id=?)
    AND v.user_id NOT IN (SELECT blocker_id FROM blocks WHERE blocked_id=?)
    ORDER BY v.created_at DESC LIMIT 100`).all(req.user.id,req.user.id,req.user.id);
  res.json({videos:rows.map(v=>({...v,url:`/uploads/${encodeURIComponent(v.filename)}`}))});
});
const maxBytes=Math.max(1,Number(process.env.MAX_UPLOAD_MB||100))*1024*1024;
const storage=multer.diskStorage({destination:uploadDir,filename:(req,file,cb)=>cb(null,crypto.randomBytes(16).toString("hex")+path.extname(file.originalname).toLowerCase())});
const upload=multer({storage,limits:{fileSize:maxBytes},fileFilter:(req,file,cb)=>cb(null,file.mimetype.startsWith("video/"))});
app.post("/api/videos",auth,(req,res)=>{
  upload.single("video")(req,res,err=>{
    if(err) return res.status(400).json({error:"Upload failed. Check the file type and size."});
    if(!req.file) return res.status(400).json({error:"Choose a video file."});
    const caption=String(req.body.caption||"").slice(0,500);
    const result=db.prepare("INSERT INTO videos(user_id,filename,caption) VALUES(?,?,?)").run(req.user.id,req.file.filename,caption);
    res.status(201).json({id:result.lastInsertRowid,url:`/uploads/${req.file.filename}`});
  });
});
app.post("/api/videos/:id/like",auth,(req,res)=>{
  const video=db.prepare("SELECT * FROM videos WHERE id=?").get(req.params.id); if(!video)return res.status(404).json({error:"Video not found."});
  const exists=db.prepare("SELECT 1 FROM likes WHERE user_id=? AND video_id=?").get(req.user.id,video.id);
  if(exists) db.prepare("DELETE FROM likes WHERE user_id=? AND video_id=?").run(req.user.id,video.id);
  else {db.prepare("INSERT INTO likes(user_id,video_id) VALUES(?,?)").run(req.user.id,video.id);notify(video.user_id,req.user.id,"liked",video.id);}
  res.json({liked:!exists});
});
app.get("/api/videos/:id/comments",auth,(req,res)=>res.json({comments:db.prepare("SELECT c.id,c.body,c.created_at,u.id userId,u.username FROM comments c JOIN users u ON u.id=c.user_id WHERE c.video_id=? ORDER BY c.created_at").all(req.params.id)}));
app.post("/api/videos/:id/comments",auth,(req,res)=>{
  const body=String(req.body.body||"").trim(); const v=db.prepare("SELECT * FROM videos WHERE id=?").get(req.params.id);
  if(!v)return res.status(404).json({error:"Video not found."}); if(!body||body.length>500)return res.status(400).json({error:"Comment must be 1–500 characters."});
  const r=db.prepare("INSERT INTO comments(user_id,video_id,body) VALUES(?,?,?)").run(req.user.id,v.id,body);notify(v.user_id,req.user.id,"commented",v.id);res.status(201).json({id:r.lastInsertRowid});
});
app.post("/api/users/:id/follow",auth,(req,res)=>{
  const target=Number(req.params.id);if(target===req.user.id||!safeUser(target))return res.status(400).json({error:"Cannot follow this account."});
  if(blockedEither(req.user.id,target))return res.status(403).json({error:"This action is unavailable."});
  const exists=db.prepare("SELECT 1 FROM follows WHERE follower_id=? AND followed_id=?").get(req.user.id,target);
  if(exists)db.prepare("DELETE FROM follows WHERE follower_id=? AND followed_id=?").run(req.user.id,target);
  else{db.prepare("INSERT INTO follows(follower_id,followed_id) VALUES(?,?)").run(req.user.id,target);notify(target,req.user.id,"followed");}
  res.json({following:!exists});
});
app.get("/api/messages/:userId",auth,(req,res)=>{
  const target=Number(req.params.userId);if(blockedEither(req.user.id,target))return res.status(403).json({error:"Conversation unavailable."});
  res.json({messages:db.prepare("SELECT id,sender_id,receiver_id,body,created_at FROM messages WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?) ORDER BY created_at LIMIT 200").all(req.user.id,target,target,req.user.id)});
});
app.post("/api/messages/:userId",auth,(req,res)=>{
  const target=Number(req.params.userId),body=String(req.body.body||"").trim();
  if(!safeUser(target)||target===req.user.id||blockedEither(req.user.id,target))return res.status(400).json({error:"Cannot message this user."});
  if(!body||body.length>2000)return res.status(400).json({error:"Message must be 1–2000 characters."});
  const r=db.prepare("INSERT INTO messages(sender_id,receiver_id,body) VALUES(?,?,?)").run(req.user.id,target,body);notify(target,req.user.id,"message",r.lastInsertRowid);res.status(201).json({id:r.lastInsertRowid});
});
app.get("/api/notifications",auth,(req,res)=>res.json({notifications:db.prepare("SELECT n.*,u.username FROM notifications n JOIN users u ON u.id=n.actor_id WHERE n.user_id=? ORDER BY n.created_at DESC LIMIT 100").all(req.user.id)}));
app.post("/api/users/:id/block",auth,(req,res)=>{
  const target=Number(req.params.id);if(target===req.user.id||!safeUser(target))return res.status(400).json({error:"Invalid user."});
  db.prepare("INSERT OR IGNORE INTO blocks(blocker_id,blocked_id) VALUES(?,?)").run(req.user.id,target);
  db.prepare("DELETE FROM follows WHERE (follower_id=? AND followed_id=?) OR (follower_id=? AND followed_id=?)").run(req.user.id,target,target,req.user.id);
  res.json({blocked:true});
});
app.post("/api/reports",auth,(req,res)=>{
  const {targetType,targetId,reason}=req.body||{};
  if(!["video","user","comment"].includes(targetType)||!Number.isInteger(Number(targetId))||!String(reason||"").trim())return res.status(400).json({error:"Choose what to report and provide a reason."});
  db.prepare("INSERT INTO reports(reporter_id,target_type,target_id,reason) VALUES(?,?,?,?)").run(req.user.id,targetType,Number(targetId),String(reason).slice(0,500));
  res.status(201).json({reported:true});
});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`FRIENDS TOK running at http://localhost:${PORT}`));
