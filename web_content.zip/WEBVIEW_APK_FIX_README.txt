VAISHNAV WORLD - WEBVIEW APK FIX PACKAGE

This package is arranged for a WebView wrapper that loads:
https://appassets.androidplatform.net/web/index.html

IMPORTANT:
- Put the CONTENTS of the 'web' folder into the wrapper's Android assets/web/ folder.
- The wrapper must intercept /web/ through WebViewAssetLoader (or equivalent).
- The main web/index.html is the Devotee app.
- The Admin app is at web/admin/index.html.
- This ZIP is NOT an APK.

The previous error ERR_HTTP_RESPONSE_CODE_FAILURE is a WebView asset-path/loading problem, not a Firebase database error.

Android's WebViewAssetLoader documentation normally uses a registered path such as /assets/ and a matching URL. If your wrapper is hard-coded to /web/index.html, it must register /web/ as an asset path.
