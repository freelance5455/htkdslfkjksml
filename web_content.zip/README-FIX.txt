HALLWAY DRAMA CHAT FIX

The original app saved chats in browser localStorage. That only works on one device/browser, so friends on other phones could not see each other's messages.

This version is prepared for Firebase Realtime Database so private chats can sync across devices.

1. Create a Firebase project at firebase.google.com.
2. Add a Web App to the project.
3. Enable Realtime Database.
4. Copy the Web App configuration into firebase-config.js.
5. Add the Firebase SDK scripts to app.html (instructions are in app.js comments).
6. Deploy the folder/ZIP contents to your web host.

Until Firebase is configured, the app keeps the original localStorage behavior as a fallback.
