NØVA Android project — fix for gallery import

What changed:
- MainActivity now implements WebChromeClient.onShowFileChooser and returns selected image/video URIs to the HTML file input.
- Content URI access is enabled for the Android file picker.

This is Android project source, NOT a compiled APK. It must be built by an Android/Gradle build environment. A generic ZIP-to-APK wrapper that does not implement Android WebView file chooser callbacks will still not support gallery imports.

Main page: app/src/main/assets/index.html
Application label: NØVA
Package: com.nova.tracker
