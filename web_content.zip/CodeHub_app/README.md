# CodeHub App Prototype
Prototype nền đen để chia sẻ code/script/file.

Có: đăng bài, tìm kiếm, like, lưu riêng tư, follow UI, hồ sơ, copy code, responsive mobile, localStorage.

Để thành app thật: nối Firebase/Supabase/Node.js cho đăng nhập, follow, database, upload/download file và quyền riêng tư.
