# TrainerPro : de l'HTML à l'APK
Test immédiat : ouvre www/index.html dans Chrome (ou installe-le comme PWA).
APK (aucun Android Studio requis) :
1. Crée un dépôt GitHub (privé) et envoie-y tout le contenu de ce dossier.
2. Onglet Actions > "Build APK" > Run workflow.
3. Télécharge l'artefact TrainerPro-apk (app-debug.apk), installe-le sur ton téléphone (autoriser les sources inconnues).
En local : npm install && npx cap add android && npx cap sync && cd android && ./gradlew assembleDebug
