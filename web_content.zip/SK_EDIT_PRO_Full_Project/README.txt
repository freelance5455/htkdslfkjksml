SK EDIT PRO — Full Android Studio starter project

INCLUDED
- Dark black/red editing interface
- Local video import and playback
- Trim range controls (preview only)
- Text overlays and filters
- Playback speed and canvas ratio options
- Audio preview and simple generated beat preview
- Device speech synthesis voiceover preview
- Transition previews
- Experimental browser-based WebM export where supported
- Save project settings as JSON
- Android WebView wrapper and file chooser

IMPORTANT LIMITATIONS
This is a starter project, not a finished CapCut-level product or a prebuilt APK.
MP4 export, reliable rendered transitions, audio/video mixing, multi-clip rendering,
AI/cloud voice generation, and production-grade effects need native/media-engine work.
The browser-based export is experimental and may fail depending on Android WebView/device.

BUILD APK
1. Use a computer with Android Studio installed.
2. Extract this ZIP and open the SK_EDIT_PRO_Full folder in Android Studio.
3. Allow Gradle sync; install Android SDK Platform 35 if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Test the APK on your Android device.
