YUZU SWITCH 2 PROJECT — HTML + PROJETO ANDROID DE EXEMPLO

Arquivos:
- site-yuzu-switch2.html: versão HTML independente para abrir no navegador.
- app/src/main/assets/index.html: página que será exibida dentro do APK de exemplo.
- app/: código-fonte Android com WebView.
- build.gradle / settings.gradle: configuração Gradle.

COMO USAR NO CELULAR:
1. Extraia o ZIP.
2. Para apenas ver o site, abra site-yuzu-switch2.html no navegador.
3. Para tentar gerar APK no próprio Android, use um ambiente de desenvolvimento compatível com Gradle/Android (por exemplo, AndroidIDE, se compatível com seu aparelho). Abra a pasta extraída como projeto Gradle e compile um APK de depuração.
4. A compilação pode exigir download de componentes, internet, memória e espaço. Este ZIP contém o código-fonte, NÃO um APK já compilado.
5. Se o ambiente do celular não conseguir compilar, será necessário usar um computador ou serviço de compilação confiável.

NOTAS:
- O projeto é uma página WebView, não um emulador.
- Yuzu Switch 2 Project é um nome de projeto independente; não é oficial nem afiliado à Nintendo ou à antiga equipe do Yuzu.
- O Yuzu original era um emulador de Nintendo Switch. Este exemplo não executa jogos nem inclui chaves, firmware ou arquivos de jogos.
