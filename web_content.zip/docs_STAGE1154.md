# CPLS V2 — Stage 1154
## Feed Manager + Rate Limiter
- Futures polling cadence is centralized at 1800 ms per subscribed symbol.
- A per-symbol next-poll gate prevents duplicate scheduling from competing requests.
- Existing channel-specific exponential backoff remains in force.
- Cache TTL is centralized so quote reuse cannot silently become long-lived.
