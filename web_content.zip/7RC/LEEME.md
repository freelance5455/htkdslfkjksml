# 7RC — versión inicial

## Incluye
- Catálogo de productos, precio, costo y existencia.
- Registro de pedidos con cliente, WhatsApp, fechas, cantidad, anticipo y estado.
- Registro de un segundo pago y saldo por cobrar.
- Resumen de pedidos, importe registrado y saldo.
- Exportación/importación de respaldo JSON.
- Diseño adaptable a celular y archivos base para PWA/Capacitor.

## Limitaciones importantes
Los datos se guardan en el almacenamiento local de cada dispositivo. No sincroniza con otros teléfonos ni tiene cuentas de usuario. Antes de usarla para operación real, hay que probarla y ampliar pagos, inventario, cancelaciones y reportes.

## Generar APK en Windows
1. Instala Node.js LTS (20 o superior): https://nodejs.org/en/download
2. Instala Android Studio: https://developer.android.com/studio
3. Extrae la carpeta `7RC` en una ruta sencilla, por ejemplo `C:\7RC`.
4. Abre PowerShell dentro de esa carpeta (en el Explorador, clic en la barra de dirección, escribe `powershell` y Enter).
5. Ejecuta, una línea a la vez:
   ```powershell
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
6. Espera a que Android Studio termine la sincronización de Gradle.
7. Menú **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
8. El APK queda en: `android\app\build\outputs\apk\debug\app-debug.apk`
9. Pásalo a tu Xiaomi 15T Pro, ábrelo e instala (Android puede pedir permitir la instalación desde esa fuente).

## Alternativa sin Android Studio: GitHub Actions
1. Sube esta carpeta a un repositorio nuevo de GitHub (rama `main`).
2. Ve a **Actions > Build APK > Run workflow**.
3. Al terminar, descarga el artefacto **7RC-apk** (contiene `app-debug.apk`).

## Actualizar la app
Tras editar `web/index.html`:
```powershell
npx cap sync android
npx cap open android
```
y vuelve a generar el APK.
