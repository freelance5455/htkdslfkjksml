# Notas v12

- Corrigido bug de escopo: a camada V9 de personalidades e diálogos estava fora do bloco que continha o estado do jogo, gerando referências fora de escopo e impedindo as conversas avançadas de funcionar.
- Removidos listeners antigos duplicados para o chat; o envio por botão e Enter usa um único manipulador.
- Histórico visual por personagem e sugestões rápidas de perguntas.
- Provedor remoto recebe mensagem atual e turnos anteriores com papéis `user`/`assistant`.
- Respostas locais contextualizadas com a mensagem real, personalidade, objetivo, vínculo e memórias.
- Manifesto em paisagem, tentativa de lock de orientação ao iniciar e ajuda de orientação no jogo.
- Terreno com subdivisão, ondulação suave contínua e cor variável determinística.
- Adicionadas espécies místicas e silhuetas extras.
- Rotinas autônomas de patrulha, pausa, busca e fuga; animação de membros.

- TerrainHeightAt compartilhado entre malha do terreno, edifícios, árvores, rochas, NPCs, criaturas, vida selvagem e jogador para evitar que a topografia deixe objetos flutuando.
- Suavizado o padrão de cor do terreno e ampliada a amplitude das ondulações sem criar picos abruptos.
- Corrigido o histórico enviado à IA remota para não repetir a mensagem atual duas vezes. O estado da interface distingue resposta remota de fallback local.
- A derrota/retorno à aldeia também reposiciona o jogador na altura do terreno.
