# CGD V117 — Socle 5.11 : calendrier lunaire galactique

## Décisions appliquées
- Conservation intégrale du catalogue historique des 24 galaxies et de leurs noms.
- Création d'un calendrier galactique de 360 jours : 12 mois de 30 jours.
- Création de sept noms de jours lunaires : Aster, Veyra, Qoril, Theryn, Myr, Solven et Nyxar.
- Conversion bidirectionnelle entre le jour absolu de saison et la date lunaire.
- Année lunaire suivante après le jour 360.
- Intégration des dates lunaires dans l'avancement quotidien du manager et les affichages d'agenda.
- Les résultats des rencontres enregistrent désormais leur date de jeu galactique plutôt qu'un horodatage terrestre.
- Les règles sportives historiques de placement des rencontres sont préservées ; les noms terrestres qui restent dans les structures internes de compatibilité doivent être masqués de l'interface et remplacés progressivement par les identifiants lunaires.

## Mois
Auron, Kelys, Voryn, Zéthar, Névar, Orvys, Thalor, Myzra, Elyon, Drakys, Solvyr, Astréon.

## Vérification
- 277 tests automatisés réussis.
- 0 échec.
- Le catalogue des 24 galaxies et les fonctionnalités antérieures sont conservés.

## Étape suivante
Remplacer les noms provisoires des clubs, construire le registre complet des managers fictifs avec origine parmi les 24 galaxies, puis raccorder les identifiants du calendrier lunaire à toutes les compétitions et aux écrans restants. Les noms des 24 galaxies ne doivent pas être modifiés.
