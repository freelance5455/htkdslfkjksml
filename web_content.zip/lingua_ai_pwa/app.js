const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const today = () => new Date().toISOString().slice(0,10);
const defaultState = {xp:0, learned:[], completed:[], streak:0,lastStudy:null,theme:'light',dailyGoal:20,quizDone:0};
let state = loadState();
function loadState(){try{return {...defaultState,...JSON.parse(localStorage.getItem('linguaState')||'{}')}}catch{return {...defaultState}}}
function save(){localStorage.setItem('linguaState',JSON.stringify(state));renderStats()}
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2100)}
function markStudy(points=5){const d=today();if(state.lastStudy!==d){const y=new Date(Date.now()-86400000).toISOString().slice(0,10);state.streak=state.lastStudy===y?state.streak+1:1;state.lastStudy=d}state.xp+=points;save()}
function renderStats(){
 $('#xp').textContent=state.xp;$('#streak').textContent=state.streak;$('#learned').textContent=state.learned.length;
 const pct=Math.min(100,Math.round(state.completed.length/6*100));$('#progressText').textContent=pct+'٪';$('#progressBar').style.width=pct+'%';
}
function shell(title,sub,body){$('#app').innerHTML=`<h1 class="page-title">${title}</h1><p class="page-sub">${sub}</p>${body}`;window.scrollTo(0,0)}
const lessons=[
 {id:'l1',title:'سلام و معرفی خود',grammar:'فعل to be: am / is / are',ex:[['I am Sina.','من سینا هستم.'],['You are a student.','تو دانش‌آموز هستی.'],['She is happy.','او خوشحال است.']],words:['hello','name','student','friend','happy']},
 {id:'l2',title:'ضمیرهای شخصی',grammar:'I, You, He, She, It, We, They',ex:[['He is my friend.','او دوست من است.'],['We are ready.','ما آماده‌ایم.']],words:['teacher','family','book','city','good']},
 {id:'l3',title:'جمله‌های روزمره',grammar:'ساختار ساده جمله: فاعل + فعل + مفعول',ex:[['I like music.','من موسیقی دوست دارم.'],['They play football.','آن‌ها فوتبال بازی می‌کنند.']],words:['music','water','food','work','learn']},
 {id:'l4',title:'حال ساده',grammar:'برای عادت‌ها و واقعیت‌ها؛ برای he/she/it معمولاً s اضافه می‌شود.',ex:[['I study English.','من انگلیسی می‌خوانم.'],['She works every day.','او هر روز کار می‌کند.']],words:['study','work','every','always','usually']},
 {id:'l5',title:'سؤال ساختن',grammar:'با do و does سؤال بساز: Do you like tea?',ex:[['Do you speak English?','آیا انگلیسی صحبت می‌کنی؟'],['Does he live here?','آیا او اینجا زندگی می‌کند؟']],words:['speak','live','where','when','why']},
 {id:'l6',title:'گذشته ساده',grammar:'برای فعل‌های باقاعده معمولاً ed اضافه می‌شود؛ افعال بی‌قاعده شکل ویژه دارند.',ex:[['I watched a film.','من یک فیلم تماشا کردم.'],['She went home.','او به خانه رفت.']],words:['yesterday','watched','went','visited','last']}
];
const vocab=[
 ['hello','سلام','Hello, how are you?','سلام، حالت چطوره؟','hə-LOH'],
 ['goodbye','خداحافظ','Goodbye, see you soon.','خداحافظ، به‌زودی می‌بینمت.','good-BYE'],
 ['name','نام','My name is Sara.','اسم من سارا است.','NAYM'],
 ['friend','دوست','He is my friend.','او دوست من است.','frend'],
 ['book','کتاب','This is my book.','این کتاب من است.','book'],
 ['water','آب','I drink water.','من آب می‌نوشم.','WAW-ter'],
 ['learn','یاد گرفتن','I learn English.','من انگلیسی یاد می‌گیرم.','lern'],
 ['happy','خوشحال','I am happy today.','امروز خوشحالم.','HAP-ee'],
 ['teacher','معلم','My teacher is kind.','معلم من مهربان است.','TEE-cher'],
 ['family','خانواده','I love my family.','من خانواده‌ام را دوست دارم.','FAM-uh-lee'],
 ['city','شهر','This city is beautiful.','این شهر زیباست.','SIT-ee'],
 ['music','موسیقی','I like music.','من موسیقی دوست دارم.','MYOO-zik'],
 ['food','غذا','The food is good.','غذا خوب است.','food'],
 ['work','کار کردن','I work every day.','من هر روز کار می‌کنم.','werk'],
 ['study','مطالعه کردن','I study at home.','من در خانه درس می‌خوانم.','STUD-ee']
];
function speak(text){if(!('speechSynthesis'in window)){toast('پخش صوت در این مرورگر پشتیبانی نمی‌شود');return}speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang='en-US';u.rate=.85;speechSynthesis.speak(u)}
function showHome(){location.hash='home';$('#app').innerHTML=document.querySelector('#home-template')?.innerHTML||homeMarkup;renderStats();setActive('home')}
const homeMarkup=$('#app').innerHTML;
function setActive(tab){$$('.nav-item').forEach(x=>x.classList.toggle('active',x.dataset.tab===tab))}
function showLesson(){
 location.hash='learn';setActive('learn');
 const idx=state.completed.length%lessons.length,L=lessons[idx];
 const examples=L.ex.map(e=>`<div class="lesson-step"><b class="en">${e[0]}</b><p>${e[1]}</p><button class="soft-btn" onclick="speak('${e[0]}')">▶ شنیدن تلفظ</button></div>`).join('');
 shell(`درس ${idx+1}: ${L.title}`,'آموزش کوتاه · سطح A1',`<div class="panel"><span class="level-pill">Grammar</span><h3>${L.grammar}</h3><p>به مثال‌ها توجه کن و جمله‌ها را با صدای بلند بخوان.</p>${examples}</div><div class="panel"><h3>تمرین کوچک</h3><p class="en">Choose the correct sentence:</p><div class="answer-list" id="lessonAnswers"><button class="answer-option" data-correct="false">I is a student.</button><button class="answer-option" data-correct="true">I am a student.</button><button class="answer-option" data-correct="false">I are a student.</button></div><div id="lessonFeedback"></div></div><button class="primary-action" id="finishLesson">اتمام درس و دریافت XP</button>`);
 $$('#lessonAnswers button').forEach(b=>b.onclick=()=>{ $$('#lessonAnswers button').forEach(x=>x.classList.remove('selected'));b.classList.add('selected');$('#lessonFeedback').innerHTML=b.dataset.correct?'<div class="feedback good">آفرین! پاسخ درست است.</div>':'<div class="feedback bad">یک بار دیگر فکر کن؛ فاعل I با am می‌آید.</div>';});
 $('#finishLesson').onclick=()=>{if(!state.completed.includes(L.id))state.completed.push(L.id);markStudy(15);toast('درس تکمیل شد؛ ۱۵ XP گرفتی');showLesson()};
}
let cardIndex=0;
function showVocab(){
 location.hash='vocab';setActive('vocab');cardIndex=0;
 const due=vocab.filter(v=>!state.learned.includes(v[0]));
 const list=due.length?due:vocab;
 function draw(){const w=list[cardIndex%list.length];shell('گنجینه واژگان','لغات کاربردی را یکی‌یکی یاد بگیر و مرور کن.',`<div class="word-card"><div class="en">${w[0]}</div><p>${w[1]}</p><div class="en" style="font-size:13px">${w[2]}</div><p>${w[3]}</p><button class="soft-btn" onclick="speak('${w[0]}')">▶ شنیدن تلفظ</button></div><div class="row"><button class="soft-btn" id="prevWord">قبلی</button><button class="primary-action" id="knowWord">بلدم ✓</button><button class="soft-btn" id="nextWord">بعدی ←</button></div><div class="panel"><div class="list-row"><span>پیشرفت این مجموعه</span><b>${state.learned.length} / ${vocab.length}</b></div><div class="list-row"><span>روش پیشنهادی</span><b>با صدای بلند تکرار کن</b></div></div>`);$('#prevWord').onclick=()=>{cardIndex=(cardIndex-1+list.length)%list.length;draw()};$('#nextWord').onclick=()=>{cardIndex++;draw()};$('#knowWord').onclick=()=>{if(!state.learned.includes(w[0])){state.learned.push(w[0]);markStudy(3)}else toast('این لغت قبلاً ثبت شده');cardIndex++;draw()}}
 draw();
}
const questions=[
 {q:'معنی “Hello” چیست؟',opts:['خداحافظ','سلام','ممنون'],a:1,why:'Hello یعنی سلام.'},
 {q:'کدام گزینه درست است؟',opts:['She are happy.','She am happy.','She is happy.'],a:2,why:'برای She از is استفاده می‌کنیم.'},
 {q:'“Book” یعنی چه؟',opts:['کتاب','آب','شهر'],a:0,why:'Book یعنی کتاب.'},
 {q:'جای خالی را کامل کن: I ___ a student.',opts:['is','am','are'],a:1,why:'I am درست است.'},
 {q:'معنی “friend” چیست؟',opts:['معلم','دوست','خانواده'],a:1,why:'Friend یعنی دوست.'}
];
function showQuiz(){location.hash='quiz';setActive('learn');let i=0,score=0,answered=false;function draw(){if(i>=questions.length){markStudy(score*2+5);state.quizDone++;save();shell('نتیجه آزمون','آفرین که تمرین کردی!',`<div class="panel" style="text-align:center"><div style="font-size:42px;color:var(--primary)">${score}/${questions.length}</div><h3>${score>=4?'عالی بود!':'ادامه بده؛ با تمرین بهتر می‌شی.'}</h3><p>این نتیجه در امتیاز و پیشرفتت ثبت شد.</p><button class="primary-action" id="again">تکرار آزمون</button></div>`);$('#again').onclick=showQuiz;return}answered=false;const q=questions[i];shell(`آزمون ${i+1} از ${questions.length}`,'هر بار فقط یک پاسخ درست است.',`<div class="panel"><div class="progress-track"><i style="width:${i/questions.length*100}%"></i></div><h3>${q.q}</h3><div class="answer-list">${q.opts.map((o,n)=>`<button class="answer-option" data-n="${n}">${o}</button>`).join('')}</div><div id="quizFeedback"></div><button class="primary-action" id="nextQ" disabled>سؤال بعدی</button></div>`);$$('.answer-option').forEach(b=>b.onclick=()=>{if(answered)return;answered=true;const ok=+b.dataset.n===q.a;if(ok)score++;$$('.answer-option').forEach(x=>{x.disabled=true;if(+x.dataset.n===q.a)x.classList.add('selected')});$('#quizFeedback').innerHTML=`<div class="feedback ${ok?'good':'bad'}">${ok?'درست است!':'پاسخ درست: '+q.opts[q.a]} ${q.why}</div>`;$('#nextQ').disabled=false});$('#nextQ').onclick=()=>{if(answered){i++;draw()}}}draw()}
function showReading(){location.hash='reading';setActive('learn');shell('Reading · خواندن','یک متن کوتاه در سطح مبتدی بخوان.',`<div class="panel"><span class="level-pill">A1 · Short story</span><h3 class="en">My New Friend</h3><p class="en" style="color:var(--text)">Hello! My name is Alex. I am a student. I live in a small city. I have a new friend. Her name is Mia. We like music and books.</p><hr style="border:0;border-top:1px solid var(--line)"><p>سلام! اسم من الکس است. من دانش‌آموز هستم. در یک شهر کوچک زندگی می‌کنم. یک دوست جدید دارم. اسم او میا است. ما موسیقی و کتاب را دوست داریم.</p><button class="soft-btn" onclick="speak('Hello! My name is Alex. I am a student. I live in a small city. I have a new friend. Her name is Mia. We like music and books.')">▶ گوش دادن به متن</button></div><div class="panel"><h3>سؤال درک مطلب</h3><p>What do Alex and Mia like?</p><div class="answer-list"><button class="answer-option" data-ok="false">Sports and food</button><button class="answer-option" data-ok="true">Music and books</button></div><div id="readFeedback"></div></div>`);$$('.answer-option').forEach(b=>b.onclick=()=>{$('#readFeedback').innerHTML=`<div class="feedback ${b.dataset.ok==='true'?'good':'bad'}">${b.dataset.ok==='true'?'آفرین، درست است!':'دوباره متن را بخوان.'}</div>`;if(b.dataset.ok==='true')markStudy(5)})}
function showListening(){location.hash='listening';setActive('learn');shell('Listening · شنیداری','به جمله گوش بده و معنی آن را انتخاب کن.',`<div class="panel" style="text-align:center"><div style="font-size:38px;color:var(--primary)">♫</div><h3>تمرین شنیداری اول</h3><p>بدون نگاه کردن به متن، جمله را گوش بده.</p><button class="primary-action" id="playListen">▶ پخش جمله انگلیسی</button></div><div class="panel"><h3>چه چیزی شنیدی؟</h3><div class="answer-list"><button class="answer-option" data-ok="false">من تشنه هستم.</button><button class="answer-option" data-ok="true">اسم من سارا است.</button><button class="answer-option" data-ok="false">من کتاب می‌خوانم.</button></div><div id="listenFeedback"></div></div>`);$('#playListen').onclick=()=>speak('My name is Sara.');$$('.answer-option').forEach(b=>b.onclick=()=>{$('#listenFeedback').innerHTML=`<div class="feedback ${b.dataset.ok==='true'?'good':'bad'}">${b.dataset.ok==='true'?'درست شنیدی!':'یک بار دیگر گوش بده.'}</div>`;if(b.dataset.ok==='true')markStudy(5)})}
function showWriting(){location.hash='writing';setActive('learn');shell('Writing · نوشتن','یک جمله ساده انگلیسی بنویس.',`<div class="panel"><h3>تمرین امروز</h3><p>به انگلیسی بنویس: «من یک دانش‌آموز هستم.»</p><textarea class="field" id="writingInput" placeholder="Write your sentence..."></textarea><button class="primary-action" id="checkWriting" style="margin-top:10px">بررسی پاسخ</button><div id="writingFeedback"></div></div>`);$('#checkWriting').onclick=()=>{const v=$('#writingInput').value.trim().toLowerCase().replace(/[.!?]/g,'').replace(/\s+/g,' ');const ok=['i am a student','i’m a student','i am student'].includes(v);$('#writingFeedback').innerHTML=ok?'<div class="feedback good">عالی! جمله‌ات درست است: I am a student.</div>':'<div class="feedback bad">پاسخ پیشنهادی: I am a student. در این جمله از I am استفاده می‌کنیم.</div>';if(ok)markStudy(8)}}
function showSpeaking(){location.hash='speaking';setActive('learn');shell('Speaking · مکالمه','فعلاً تمرین گفتاری با تلفظ و جمله‌سازی در دسترس است.',`<div class="panel"><span class="level-pill">تمرین مکالمه A1</span><h3>Introduce yourself</h3><p>به این سؤال با صدای بلند جواب بده:</p><h3 class="en">What is your name?</h3><button class="primary-action" id="speakPrompt">▶ شنیدن سؤال</button></div><div class="panel"><h3>پاسخت را بنویس</h3><input class="field" id="speakAnswer" placeholder="My name is ..."><button class="primary-action" id="checkSpeak" style="margin-top:10px">بررسی جمله</button><div id="speakFeedback"></div></div><div class="panel"><h3>درباره مکالمه هوشمند</h3><p>گفت‌وگوی آزاد با هوش مصنوعی به اتصال امن به سرویس AI و کلید API نیاز دارد. این نسخه هنوز به چنین سرویسی متصل نیست؛ برای جلوگیری از نمایش قابلیت غیرواقعی، فعلاً تمرین‌های محلی ارائه شده‌اند.</p></div>`);$('#speakPrompt').onclick=()=>speak('What is your name?');$('#checkSpeak').onclick=()=>{const v=$('#speakAnswer').value.trim();const ok=/^(my name is .+|i am .+)$/i.test(v);$('#speakFeedback').innerHTML=`<div class="feedback ${ok?'good':'bad'}">${ok?'ساختار جمله مناسب است.':'از الگوی My name is ... استفاده کن.'}</div>`;if(ok){speak(v);markStudy(5)}}}
function showProgress(){location.hash='progress';setActive('progress');const pct=Math.min(100,Math.round(state.completed.length/6*100));shell('گزارش پیشرفت','رشدت را با استمرار بساز.',`<div class="stats-grid"><article class="stat-card"><span class="stat-icon purple">✦</span><b>${state.xp}</b><small>XP</small></article><article class="stat-card"><span class="stat-icon green">▤</span><b>${state.learned.length}</b><small>لغت</small></article><article class="stat-card"><span class="stat-icon orange">♨</span><b>${state.streak}</b><small>روز متوالی</small></article></div><div class="panel"><h3>پیشرفت دوره A1</h3><div class="progress-track"><i style="width:${pct}%"></i></div><b>${pct}٪</b><p>با تکمیل درس‌ها، نوار پیشرفتت افزایش پیدا می‌کند.</p></div><div class="panel"><h3>آمار یادگیری</h3><div class="list-row"><span>درس‌های تکمیل‌شده</span><b>${state.completed.length} از ۶</b></div><div class="list-row"><span>آزمون‌های انجام‌شده</span><b>${state.quizDone}</b></div><div class="list-row"><span>هدف روزانه</span><b>${state.dailyGoal} دقیقه</b></div></div><div class="panel"><h3>تنظیمات داده‌ها</h3><p>اطلاعات در حافظه همین مرورگر ذخیره می‌شود.</p><button class="soft-btn" id="resetData">بازنشانی پیشرفت</button></div>`);$('#resetData').onclick=()=>{if(confirm('همه پیشرفت ذخیره‌شده پاک شود؟')){localStorage.removeItem('linguaState');state=loadState();showProgress();toast('پیشرفت بازنشانی شد')}}}
function route(go){({home:showHome,lesson:showLesson,learn:showLesson,vocab:showVocab,quiz:showQuiz,reading:showReading,listening:showListening,writing:showWriting,speaking:showSpeaking,progress:showProgress}[go]||showHome)()}
document.addEventListener('click',e=>{const b=e.target.closest('[data-go],[data-tab]');if(!b)return;route(b.dataset.go||b.dataset.tab)});
$('#themeBtn').onclick=()=>{document.body.classList.toggle('dark');state.theme=document.body.classList.contains('dark')?'dark':'light';save()};
if(state.theme==='dark')document.body.classList.add('dark');
renderStats();
if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
if(location.hash && location.hash!=='#home')route(location.hash.slice(1));
