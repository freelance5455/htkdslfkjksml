package com.benhur.knockoutdolls;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Build;
import android.os.Bundle;
import android.content.Context;
import android.hardware.input.InputManager;
import java.util.HashMap;
import java.util.Map;
import android.content.pm.ActivityInfo;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.net.Uri;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/assets/index.html";
    private WebView game;
    private static final class PadState {
        final int slot;
        final float[] axes = new float[4];
        final float[] buttons = new float[17];
        PadState(int slot) { this.slot = slot; }
    }
    private final Map<Integer, PadState> controllers = new HashMap<>();
    private InputManager inputManager;
    private final InputManager.InputDeviceListener deviceListener = new InputManager.InputDeviceListener() {
        @Override public void onInputDeviceAdded(int deviceId) {}
        @Override public void onInputDeviceChanged(int deviceId) {}
        @Override public void onInputDeviceRemoved(int deviceId) {
            PadState gone = controllers.remove(deviceId);
            if (gone != null && game != null) game.evaluateJavascript(
                    "window.KD_ANDROID_GAMEPAD_UPDATE&&window.KD_ANDROID_GAMEPAD_UPDATE("+
                    gone.slot+",[],[],false)", null);
        }
    };
    private PadState padFor(int deviceId) {
        PadState existing = controllers.get(deviceId);
        if (existing != null) return existing;
        // Keep two independent gamepads for local 1v1, as in the browser game.
        int slot = 0;
        while (slot < 2) {
            boolean taken = false;
            for (PadState p : controllers.values()) if (p.slot == slot) taken = true;
            if (!taken) break;
            slot++;
        }
        if (slot >= 2) return null;
        PadState fresh = new PadState(slot);
        controllers.put(deviceId, fresh);
        return fresh;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        immersive();
        inputManager = (InputManager)getSystemService(Context.INPUT_SERVICE);
        if (inputManager != null) inputManager.registerInputDeviceListener(deviceListener, null);
        game = new WebView(this);
        game.setBackgroundColor(Color.rgb(17,29,41));
        game.setOverScrollMode(View.OVER_SCROLL_NEVER);
        game.setFocusable(true);
        game.setFocusableInTouchMode(true);
        WebSettings settings = game.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setTextZoom(100);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        game.setWebChromeClient(new WebChromeClient());
        // Intercept only our own virtual HTTPS host. The game still uses HTTPS/WSS for online play.
        game.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!"https".equals(uri.getScheme()) || !HOST.equals(uri.getHost())) return null;
                String path = uri.getEncodedPath();
                if (path == null || !path.startsWith("/assets/")) return null;
                String rel = Uri.decode(path.substring("/assets/".length()));
                if (rel.contains("..") || rel.startsWith("/") || rel.contains("\\")) {
                    return new WebResourceResponse("text/plain", "UTF-8", 403, "Forbidden", null,
                            new java.io.ByteArrayInputStream(new byte[0]));
                }
                try {
                    InputStream body = getAssets().open(rel, AssetManager.ACCESS_STREAMING);
                    String mime = mime(rel);
                    return new WebResourceResponse(mime, "UTF-8", 200, "OK", null, body);
                } catch(IOException missing) {
                    return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", null,
                            new java.io.ByteArrayInputStream(new byte[0]));
                }
            }
        });
        setContentView(game);
        game.loadUrl(START_URL);
    }

    private static String mime(String f) {
        String name = f.toLowerCase(Locale.ROOT);
        if (name.endsWith(".html")) return "text/html";
        if (name.endsWith(".js") || name.endsWith(".mjs")) return "text/javascript";
        if (name.endsWith(".css")) return "text/css";
        if (name.endsWith(".svg")) return "image/svg+xml";
        if (name.endsWith(".json")) return "application/json";
        if (name.endsWith(".png")) return "image/png";
        if (name.endsWith(".woff2")) return "font/woff2";
        return "application/octet-stream";
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if(hasFocus) immersive();
    }
    @SuppressWarnings("deprecation") private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }
    private static boolean isPad(KeyEvent event) {
        int source = event.getSource();
        return (source & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                (source & InputDevice.SOURCE_DPAD) == InputDevice.SOURCE_DPAD;
    }
    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (isPad(event)) {
            int index = button(event.getKeyCode());
            if (index >= 0) {
                PadState pad = padFor(event.getDeviceId());
                if (pad == null) return super.dispatchKeyEvent(event);
                pad.buttons[index] = event.getAction() == KeyEvent.ACTION_UP ? 0f : 1f;
                updatePad(pad);
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }
    private static int button(int key) {
        switch(key) {
            case KeyEvent.KEYCODE_BUTTON_A: return 0;
            case KeyEvent.KEYCODE_BUTTON_B: return 1;
            case KeyEvent.KEYCODE_BUTTON_X: return 2;
            case KeyEvent.KEYCODE_BUTTON_Y: return 3;
            case KeyEvent.KEYCODE_BUTTON_L1: return 4;
            case KeyEvent.KEYCODE_BUTTON_R1: return 5;
            case KeyEvent.KEYCODE_BUTTON_L2: return 6;
            case KeyEvent.KEYCODE_BUTTON_R2: return 7;
            case KeyEvent.KEYCODE_BUTTON_SELECT: return 8;
            case KeyEvent.KEYCODE_BUTTON_START: return 9;
            case KeyEvent.KEYCODE_BUTTON_THUMBL: return 10;
            case KeyEvent.KEYCODE_BUTTON_THUMBR: return 11;
            case KeyEvent.KEYCODE_DPAD_UP: return 12;
            case KeyEvent.KEYCODE_DPAD_DOWN: return 13;
            case KeyEvent.KEYCODE_DPAD_LEFT: return 14;
            case KeyEvent.KEYCODE_DPAD_RIGHT: return 15;
            default: return -1;
        }
    }
    @Override public boolean dispatchGenericMotionEvent(MotionEvent event) {
        if ((event.getSource() & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK &&
            event.getAction() == MotionEvent.ACTION_MOVE) {
            PadState pad = padFor(event.getDeviceId());
            if (pad == null) return super.dispatchGenericMotionEvent(event);
            pad.axes[0] = event.getAxisValue(MotionEvent.AXIS_X);
            pad.axes[1] = event.getAxisValue(MotionEvent.AXIS_Y);
            pad.axes[2] = event.getAxisValue(MotionEvent.AXIS_Z);
            pad.axes[3] = event.getAxisValue(MotionEvent.AXIS_RZ);
            pad.buttons[6] = Math.max(0f,Math.max(event.getAxisValue(MotionEvent.AXIS_LTRIGGER),event.getAxisValue(MotionEvent.AXIS_BRAKE)));
            pad.buttons[7] = Math.max(0f,Math.max(event.getAxisValue(MotionEvent.AXIS_RTRIGGER),event.getAxisValue(MotionEvent.AXIS_GAS)));
            updatePad(pad);
            return true;
        }
        return super.dispatchGenericMotionEvent(event);
    }
    private void updatePad(PadState pad) {
        if (game == null) return;
        StringBuilder js = new StringBuilder("window.KD_ANDROID_GAMEPAD_UPDATE&&window.KD_ANDROID_GAMEPAD_UPDATE(");
        js.append(pad.slot).append(",[");
        for(int i=0;i<pad.axes.length;i++){if(i>0)js.append(',');js.append(pad.axes[i]);}
        js.append("],[");
        for(int i=0;i<pad.buttons.length;i++){if(i>0)js.append(',');js.append(pad.buttons[i]);}
        js.append("],true);");
        game.evaluateJavascript(js.toString(),null);
    }
    @SuppressWarnings("deprecation") @Override public void onBackPressed() {
        if(game == null){super.onBackPressed();return;}
        game.evaluateJavascript("(function(){let e=document.querySelector('#characterEditor');if(e&&!e.hidden){let b=e.querySelector('[data-close]');b&&b.click();return true;}let p=document.querySelector('#pausePanel');if(p&&!p.hidden){let b=document.querySelector('#resume');b&&b.click();return true;}let h=document.querySelector('#help');if(h&&h.open){h.close();return true;}let m=document.querySelector('#menu');if(m&&m.hidden){let b=document.querySelector('#pause');b&&b.click();return true;}return false;})()", response -> {
            if ("true".equals(response)) return;
            new AlertDialog.Builder(this).setTitle("Sair do Knockout Dolls?")
                    .setNegativeButton("Continuar jogando", (d,w)->{}).setPositiveButton("Sair", (d,w)->finish()).show();
        });
    }
    @Override protected void onPause() { if(game != null)game.onPause();super.onPause(); }
    @Override protected void onResume() { super.onResume(); if(game != null)game.onResume();immersive(); }
    @Override protected void onDestroy() {
        if (inputManager != null) inputManager.unregisterInputDeviceListener(deviceListener);
        if (game != null) { game.destroy(); game = null; }
        super.onDestroy();
    }
}
