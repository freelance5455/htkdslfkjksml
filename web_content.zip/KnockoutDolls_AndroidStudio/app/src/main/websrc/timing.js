export const STEP=1/60;
// Preserve real time down to 5 FPS, while bounding work after a background tab or a long stall.
export function scheduleFrame(remainder,elapsed){
 const available=Math.min(Math.max(0,remainder)+Math.min(Math.max(0,elapsed),.2),.2+STEP);
 const steps=Math.min(12,Math.floor((available+1e-9)/STEP));
 const rest=Math.max(0,available-steps*STEP);
 return {steps,remainder:rest,alpha:Math.min(1,rest/STEP)};
}
