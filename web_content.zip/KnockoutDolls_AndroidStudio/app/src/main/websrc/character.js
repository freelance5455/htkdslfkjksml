const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
export const BODY_FIELDS=[
 ['height','Altura',160,200,1,'cm'],['weight','Peso',50,115,1,'kg'],['shoulders','Largura dos ombros',86,116,1,'%'],['waist','Largura da cintura',88,114,1,'%'],['arms','Comprimento dos braços',88,112,1,'%'],['legs','Comprimento das pernas',90,110,1,'%'],['muscle','Musculatura',0,100,1,'%']
];
export const LOOKS={
 hair:['Sem cabelo','Curto','Topete','Moicano','Preso','Raspado','Cacheado','Lateral'],
 face:['Neutro','Determinado','Suave','Bravo','Focado'],
 outfit:['Esportivo','Camiseta','Regata','Quimono','Moletom','Jaqueta','Compressão'],
 accessory:['Nenhum','Faixa na cabeça','Óculos esportivos','Cotoveleiras','Joelheiras','Curativo nasal','Brincos','Protetor bucal','Munhequeiras','Emblema','Protetor de cabeça'],
 beard:['Sem barba','Curta','Cavanhaque','Bigode','Cheia'],
 bottom:['Shorts','Calça','Legging','Cargo','Jogger']
};
export const DEFAULT_CHARACTER=Object.freeze({name:'LUTADOR',height:180,weight:80,shoulders:100,waist:100,arms:100,legs:100,muscle:50,hair:0,face:0,outfit:0,accessory:0,beard:0,bottom:0,skin:'#c9a777',hairColor:'#332820',cloth:'#cce989',trim:'#273d46',gloves:'#819e42'});
export const PRESETS={balanced:{label:'Equilibrado',body:{}},reach:{label:'Alcance',body:{height:192,weight:83,arms:111,legs:106,shoulders:94,muscle:40}},power:{label:'Potência',body:{height:176,weight:96,arms:92,legs:96,shoulders:112,waist:108,muscle:84}},quick:{label:'Ágil',body:{height:166,weight:61,arms:97,legs:102,shoulders:92,waist:92,muscle:40}}};
export function weightLimits(height){return [Math.max(50,Math.ceil(18.5*(height/100)**2)),Math.min(115,Math.floor(32*(height/100)**2))];}
export function sanitizeCharacter(raw={}){
 raw=raw&&typeof raw==='object'?raw:{};const c={...DEFAULT_CHARACTER};c.name=String(raw.name??c.name).replace(/[<>\x00-\x1f]/g,'').trim().slice(0,18)||'LUTADOR';
 for(const [key,,min,max] of BODY_FIELDS){const v=Number(raw[key]);c[key]=Number.isFinite(v)?clamp(v,min,max):c[key];}
 const [lo,hi]=weightLimits(c.height);c.weight=clamp(c.weight,lo,hi);
 for(const [key,choices] of Object.entries(LOOKS)){const v=Number(raw[key]);c[key]=Number.isInteger(v)?clamp(v,0,choices.length-1):c[key];}
 for(const key of ['skin','hairColor','cloth','trim','gloves'])if(/^#[\da-f]{6}$/i.test(raw[key]||''))c[key]=raw[key];
 return c;
}
export function bodyMetrics(raw={}){
 const c=sanitizeCharacter(raw),legRatio=c.legs/100,armRatio=c.arms/100,mass=c.weight/80,muscle=(c.muscle-50)/50;
 const h=c.height/180*2.325/(.97*legRatio+1.355),leg=h*legRatio,arm=h*armRatio;
 const bulk=clamp((mass/h**3)**.24,.85,1.23),width=h*c.shoulders/100*bulk,hip=h*c.waist/100*bulk,depth=h*bulk*(1-.08*muscle),limb=h*bulk*(1+.08*muscle);
 const punch=clamp(mass**.34*(1+.12*muscle)/arm**.8,.72,1.35),kick=clamp(mass**.30*(1+.10*muscle)/leg**.7,.74,1.33);
 const cadence=clamp(mass**.38*arm**.45*(1+.04*Math.max(0,muscle)),.83,1.24),kickTime=clamp(mass**.18*leg**.32,.84,1.24);
 const mobility=clamp(mass**-.32*(1-.12*(c.waist/100-1))*(1-.025*Math.abs(muscle)),.83,1.15);
 const recovery=clamp(mass**-.28*(1-.12*muscle),.82,1.16),cost=clamp(mass**.30*(1+.14*Math.max(0,muscle)),.85,1.22);
 const grip=clamp(mass**.28*(1+.12*muscle)*(c.shoulders/100)**.2,.78,1.30);
 const stability=clamp(mass**.15*(c.waist/100)**.45/legRatio**.2,.85,1.20);
 const technique=armRatio<.95?'compact':armRatio>1.05?'reach':mass>1.14?'heavy':mass<.87?'quick':'balanced';
 return {config:c,h,leg,arm,width,hip,depth,limb,mass,punch,kick,cadence,kickTime,mobility,recovery,cost,grip,stability,technique,
  label:{compact:'COMPACTO · GANCHO CURTO',reach:'LONGILÍNEO · DIRETOS LONGOS',heavy:'PESADO · DIRETO CARREGADO',quick:'LEVE · JAB RÁPIDO',balanced:'EQUILIBRADO · JAB E DIRETO'}[technique],
  reach:(.39*width+.12*limb+.96*arm)/1.47,kickReach:(.20*hip+.95*leg)/1.15,
  standHeight:.97*leg+.16*h,bodyHeight:c.height/180*2.325};
}
export function morphSkeleton(baseSpecs,baseJoints,raw){
 const b=bodyMetrics(raw),specs={},scales={};
 const upper=y=>.97*b.leg+(y-.97)*b.h;
 for(const [name,base] of Object.entries(baseSpecs)){
  const sp={...base,p:[...base.p]},arm=/^(arm|hand)/.test(name),leg=/^(thigh|shin)/.test(name);
  const scale=name==='head'?[b.h,b.h,b.h]:arm?[b.limb,b.arm,b.limb]:leg?[b.limb,b.leg,b.h]:name==='pelvis'?[b.hip,b.h,b.depth]:[b.width,b.h,b.depth];
  if(arm){const sign=Math.sign(base.p[0]);sp.p=[sign*(.39*b.width+.12*b.limb),upper(1.72)+(base.p[1]-1.72)*b.arm,base.p[2]*b.depth];}
  else if(leg)sp.p=[base.p[0]*b.hip,base.p[1]*b.leg,base.p[2]*b.h];
  else sp.p=[base.p[0]*scale[0],upper(base.p[1]),base.p[2]*scale[2]];
  if(base.size)sp.size=base.size.map((v,i)=>v*scale[i]);if(base.radius)sp.radius=base.radius*b.h;sp.mass=base.mass*b.mass;sp.scale=scale;scales[name]=scale;specs[name]=sp;
 }
 const joints=baseJoints.map(([parent,child,p,angle,twist])=>{
  const arm=/^(arm|hand)/.test(child),leg=/^(thigh|shin)/.test(child);
  let pivot;
  if(arm){const sign=Math.sign(p[0]),shoulder=/^arm/.test(child);pivot=[sign*(shoulder?(.355*b.width+.095*b.limb):(.39*b.width+.12*b.limb)),upper(1.72)+(p[1]-1.72)*b.arm,p[2]*b.depth];}
  else pivot=leg?[p[0]*b.hip,p[1]*b.leg,p[2]*b.h]:[p[0]*b.width,upper(p[1]),p[2]*b.depth];
  return [parent,child,pivot,angle,twist];
 });return {body:b,specs,joints,scales};
}
