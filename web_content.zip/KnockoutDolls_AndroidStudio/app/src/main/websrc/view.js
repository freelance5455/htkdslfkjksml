import * as T from './vendor/three.module.js';
import {buildHumanPart} from './human-model.js?v=13';
import {mergeGeometries} from './vendor/BufferGeometryUtils.js';
const C={mint:0xcce989,coral:0xef8a70,dark:0x192b38,cream:0xd8e3c9};
const mat=(color,extra={})=>new T.MeshLambertMaterial({color,...extra});
// Rounded equipment keeps the same outer dimensions as its collision shape.
function paddedBox(width,height,depth,radius){
 const box=new T.BoxGeometry(width,height,depth,6,6,6);
 const pos=box.attributes.position,normal=box.attributes.normal;
 const core=new T.Vector3(width/2-radius,height/2-radius,depth/2-radius);
 const vertex=new T.Vector3(),nearest=new T.Vector3(),outward=new T.Vector3();
 for(let i=0;i<pos.count;i++){
  vertex.fromBufferAttribute(pos,i);
  nearest.set(clamp(vertex.x,-core.x,core.x),clamp(vertex.y,-core.y,core.y),clamp(vertex.z,-core.z,core.z));
  outward.subVectors(vertex,nearest).normalize();vertex.copy(nearest).addScaledVector(outward,radius);
  pos.setXYZ(i,vertex.x,vertex.y,vertex.z);normal.setXYZ(i,outward.x,outward.y,outward.z);
 }
 return box;
}
function paintFightMat(c){
 c.fillStyle='#344854';c.fillRect(0,0,1024,1024);
 for(let y=0;y<1024;y+=128)for(let x=0;x<1024;x+=128){
  c.fillStyle=(x+y)%256?'#435862':'#465c65';c.fillRect(x+1,y+1,126,126);
 }
 c.strokeStyle='#c7d8ce';c.lineWidth=5;c.strokeRect(43,43,938,938);
 c.lineWidth=2;c.strokeRect(55,55,914,914);
 for(let i=0;i<64;i++){
  const angle=i*Math.PI/32,major=i%4===0;
  c.strokeStyle=major?'#acc5bb':'#748f92';c.lineWidth=major?5:2;
  c.beginPath();c.moveTo(512+Math.cos(angle)*255,512+Math.sin(angle)*255);
  c.lineTo(512+Math.cos(angle)*(major?278:266),512+Math.sin(angle)*(major?278:266));c.stroke();
 }
 c.strokeStyle='#92aaa7';c.lineWidth=3;c.beginPath();c.arc(512,512,240,0,Math.PI*2);c.stroke();
 c.textAlign='center';c.fillStyle='#b0c2b7';c.font='italic 900 70px Arial';c.fillText('KNOCKOUT',512,502);
 c.font='bold 32px monospace';c.fillText('D O L L S',512,557);
 c.font='bold 17px monospace';c.fillStyle='#c3d2cb';c.fillText('FIGHT NIGHT   /   ARENA 05',512,928);
 for(const right of [false,true]){
  c.fillStyle=right?'#ff916d':'#cff678';
  for(let i=0;i<5;i++){const x=right?940:62,y=338+i*65;c.fillRect(x,y,22,45);}
 }
}
export class GameView{
 constructor(canvas,low=false){this.renderer=new T.WebGLRenderer({canvas,antialias:!low,powerPreference:'high-performance'});this.resolutionScale=low?1:Math.min(devicePixelRatio,1.5);this.renderer.setPixelRatio(this.resolutionScale);this.renderer.shadowMap.enabled=!low;this.renderer.shadowMap.type=T.PCFSoftShadowMap;this.renderer.outputColorSpace=T.SRGBColorSpace;this.renderer.toneMapping=T.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.2;this.scene=new T.Scene();this.scene.background=new T.Color(0x111825);this.scene.fog=new T.Fog(0x111825,13,44);this.camera=new T.PerspectiveCamera(38,1,.1,90);this.camera.position.set(6.7,7,9.4);this.target=new T.Vector3();this.shake=0;this.models=[];this.editor=null;this.particles=[];this.effects=new T.Group();this.scene.add(this.effects);this.low=low;this.tempQuaternion=new T.Quaternion();this.center=new T.Vector3();this.camPos=new T.Vector3();this.particleDummy=new T.Object3D();this.particleMesh=new T.InstancedMesh(new T.BoxGeometry(.055,.055,.055),new T.MeshBasicMaterial({color:0xffffff}),40);this.particleMesh.count=0;this.particleMesh.frustumCulled=false;this.particleMesh.instanceMatrix.setUsage(T.DynamicDrawUsage);this.effects.add(this.particleMesh);
  this.scene.add(new T.HemisphereLight(0xf1f8e8,0x29404f,1.75));const sun=new T.DirectionalLight(0xffdfbf,3.35);sun.position.set(-4,10,6);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);sun.shadow.camera.left=-8;sun.shadow.camera.right=8;sun.shadow.camera.top=7;sun.shadow.camera.bottom=-7;sun.shadow.normalBias=.025;sun.shadow.bias=-.00015;this.scene.add(sun);this.sun=sun;const fill=new T.DirectionalLight(0x8bdfff,1.9);fill.position.set(6,4,-5);this.scene.add(fill);
  const rim=new T.DirectionalLight(0xff957a,1.25);rim.position.set(-5,4,-6);this.scene.add(rim);
  this.makeArena();this.batchArena();this.makeAtmosphere();this.makeElasticNets();
  this.hazardMesh=this.mesh(new T.PlaneGeometry(1,1),new T.MeshBasicMaterial({color:0xffbc54,transparent:true,opacity:.3,depthWrite:false,side:T.DoubleSide}),[0,.028,0]);this.hazardMesh.rotation.x=-Math.PI/2;this.hazardMesh.visible=false;
  this.hazardEdge=this.mesh(new T.PlaneGeometry(1,1),new T.MeshBasicMaterial({color:0xffe2aa,transparent:true,opacity:.75,depthWrite:false,wireframe:true}),[0,.035,0]);this.hazardEdge.rotation.x=-Math.PI/2;this.hazardEdge.visible=false;
  this.resize();
 }
 mesh(geo,material,pos,parent=this.scene){const m=new T.Mesh(geo,material);if(pos)m.position.set(...pos);parent.add(m);return m;}
 box(w,h,d,color,x,y,z,parent=this.scene){return this.mesh(new T.BoxGeometry(w,h,d),mat(color),[x,y,z],parent);}
 textTexture(text,w=1024,h=256,color='#d3f376',background=null){const cv=document.createElement('canvas');cv.width=w;cv.height=h;const c=cv.getContext('2d');if(background){c.fillStyle=background;c.fillRect(0,0,w,h);}c.fillStyle=color;c.textAlign='center';c.textBaseline='middle';c.font=`italic 900 ${h*.65}px Arial`;c.fillText(text,w/2,h*.54,w*.94);const t=new T.CanvasTexture(cv);t.colorSpace=T.SRGBColorSpace;return t;}
 makeArena(){const base=this.box(10.5,.55,8.5,C.dark,0,-.30,0);base.receiveShadow=true;const edgeMat=mat(0x344955);for(const x of [-5.1,5.1])this.mesh(new T.BoxGeometry(.19,.16,8.35),edgeMat,[x,.08,0]);for(const z of [-4.1,4.1])this.mesh(new T.BoxGeometry(10.3,.16,.19),edgeMat,[0,.08,z]);
  const cv=document.createElement('canvas');cv.width=1024;cv.height=1024;const c=cv.getContext('2d');paintFightMat(c);const tex=new T.CanvasTexture(cv);tex.colorSpace=T.SRGBColorSpace;const floor=this.mesh(new T.PlaneGeometry(10.2,8.2),new T.MeshStandardMaterial({color:0xffffff,map:tex,roughness:.88,metalness:.02,bumpMap:this.fabricTexture(),bumpScale:.007}),[0,.008,0]);floor.rotation.x=-Math.PI/2;floor.receiveShadow=true;this.floorMaterial=floor.material;
  for(const x of [-4.95,4.95])for(const z of [-3.95,3.95]){this.box(.40,.7,.40,x<0?C.mint:C.coral,x,.35,z);const top=this.mesh(new T.SphereGeometry(.20,12,8),mat(x<0?C.mint:C.coral),[x,.70,z]);top.scale.y=.35;}
  const ground=this.box(100,.25,100,0x172532,0,-1.3,0);ground.receiveShadow=true;
  for(const x of [-4,4]){this.box(1.8,.04,.06,x<0?C.mint:C.coral,x,-.48,4.28);this.box(.03,.25,8,0x3c5261,x<0?-5.27:5.27,-.30,0);}
  // Low-cost instanced toy audience and benches.
  const people=48,heads=new T.InstancedMesh(new T.SphereGeometry(.14,8,6),mat(0xaac2c1),people),torsos=new T.InstancedMesh(new T.BoxGeometry(.29,.36,.22),mat(0x586f81),people);const ob=new T.Object3D();let n=0;const colors=[0x7f9396,0xc7bb92,0x648599,0xad877d,0x9da882];for(let row=0;row<3;row++){this.box(13,.25,.5,0x293d4d,0,-.2+row*.45,-6-row*.8);for(let j=0;j<16;j++){const x=(j-7.5)*.75,z=-6-row*.8,y=.12+row*.45;ob.position.set(x,y+.39,z);ob.updateMatrix();heads.setMatrixAt(n,ob.matrix);heads.setColorAt(n,new T.Color(colors[(j+row)%5]));ob.position.y=y+.08;ob.updateMatrix();torsos.setMatrixAt(n,ob.matrix);torsos.setColorAt(n,new T.Color(colors[(j*3+row)%5]).multiplyScalar(.65));n++;}}this.scene.add(heads,torsos);this.crowd={heads,torsos,points:[],dummy:new T.Object3D(),at:-1};
  const arms=new T.InstancedMesh(new T.BoxGeometry(.09,.30,.10),mat(0x91a9ac),people*2);arms.instanceMatrix.setUsage(T.DynamicDrawUsage);heads.instanceMatrix.setUsage(T.DynamicDrawUsage);torsos.instanceMatrix.setUsage(T.DynamicDrawUsage);this.scene.add(arms);this.crowd.arms=arms;
  for(let row=0;row<3;row++)for(let j=0;j<16;j++)this.crowd.points.push({x:(j-7.5)*.75,y:.12+row*.45,z:-6-row*.8,phase:j*2.3+row*4});
  // Illuminated apron and lighting gantry. Shared strips are batched with the arena.
  const strips=[0xbce97a,0xff8864].map(color=>new T.MeshBasicMaterial({color}));
  for(let i=0;i<16;i++){
   const x=(i-7.5)*.62;
   this.mesh(new T.BoxGeometry(.49,.045,.035),strips[i<8?0:1],[x,-.12,4.27]);
   this.mesh(new T.BoxGeometry(.49,.045,.035),strips[i<8?0:1],[x,2.93,-8.45]);
  }
  this.box(14,.12,.2,0x314352,0,4.4,-5.7);
  for(let i=0;i<9;i++){
   const x=(i-4)*1.5;this.box(.65,.18,.42,0x293d4d,x,4.24,-5.7);
   this.mesh(new T.BoxGeometry(.5,.055,.39),strips[i%2],[x,4.12,-5.7]);
  }
  const banner=this.mesh(new T.PlaneGeometry(7,1.25),new T.MeshBasicMaterial({map:this.textTexture('KNOCKOUT   /   FIGHT NIGHT',1024,180,'#e4edce','#172434')}),[0,2.35,-8.4]);banner.rotation.x=.02;for(const x of [-7,7]){this.box(.13,6,.13,0x2d4454,x,1.8,-5);this.box(2.1,.12,.32,0x768e9a,x,4.8,-5);this.box(1.9,.04,.26,0xd0f4e5,x,4.72,-5);}
 }
 makeElasticNets(){
  // Four animated wire meshes, deliberately separate from batched original arena.
  this.elasticNets=[];
  for(let side=0;side<4;side++){
   const horizontal=side>=2,half=horizontal?4.88:3.88,cols=22,rows=5;
   const vertexCount=cols*rows*4,geometry=new T.BufferGeometry(),points=new Float32Array(vertexCount*3);
   geometry.setAttribute('position',new T.BufferAttribute(points,3));
   const material=new T.LineBasicMaterial({color:0x9fbbb2,transparent:true,opacity:.58,depthWrite:false});
   const mesh=new T.LineSegments(geometry,material);mesh.frustumCulled=false;mesh.renderOrder=3;this.scene.add(mesh);
   this.elasticNets.push({mesh,points,side,cols,rows,half});
  }
  this.updateElasticNets(null);
 }
 updateElasticNets(sim){
  if(!this.elasticNets)return;
  for(const net of this.elasticNets){
   const {points,cols,rows,side,half,mesh}=net,hit=sim?.netStretch?.[side]||0,focus=sim?.netPoint?.[side]||0,pulse=sim?.netHit?.[side]||0;
   const zEdge=side>=2,sign=(side===0||side===2)?-1:1,plane=zEdge?3.95:4.95;
   const at=(u,v)=>{const y=.28+v*.45,spread=Math.exp(-(((u-focus)/1.6)**2))*Math.sin(Math.PI*v/(rows+.25));const push=hit*.55*spread;
    return zEdge?[u,y,sign*(plane+push)]:[sign*(plane+push),y,u];};
   let k=0;const add=(p)=>{points[k++]=p[0];points[k++]=p[1];points[k++]=p[2];};
   for(let r=0;r<rows;r++)for(let c=0;c<cols;c++){
    const u=-half+c*2*half/cols,v=-half+(c+1)*2*half/cols;
    add(at(u,r));add(at(v,r+1));add(at(u,r+1));add(at(v,r));
   }
   mesh.geometry.attributes.position.needsUpdate=true;
   mesh.material.color.setHex(pulse>.1?0xd7ff87:0x9fbbb2);
   mesh.material.opacity=.47+Math.min(.36,pulse*.27+hit*.15);
  }
 }
 bind(sim){
  this.scoreAt=-1;this.updateElasticNets(sim);if(this.crowd)this.crowd.at=-1;this.cheer=0;this.particles.length=0;
  if(this.rings)for(const ring of this.rings){ring.life=0;ring.visible=false;}
  for(const model of this.models){
   const geos=new Set(),mats=new Set(model.materials||[]);
   for(const g of [...Object.values(model.parts),model.marker,model.shadow,model.nameSprite]){g.traverse(o=>{if(o.geometry)geos.add(o.geometry);if(o.material)mats.add(o.material);});this.scene.remove(g);}
   if(model.nameTexture)model.nameTexture.dispose();for(const g of geos)g.dispose();for(const m of mats)m.dispose();
  }
  this.models=[];
  for(const f of sim.fighters){
   const c=f.config,parts={},color=new T.Color(c.cloth),bodyMat=new T.MeshStandardMaterial({color,roughness:.62,metalness:.05}),dark=mat(c.trim),cream=mat(0xe5e8d7),skin=new T.MeshStandardMaterial({color:c.skin,roughness:.72,metalness:.03}),face=mat(0x4b4439),hair=mat(c.hairColor);
   const gloveMat=Object.fromEntries(['L','R'].map(side=>[side,new T.MeshStandardMaterial({color:c.gloves,roughness:.34,metalness:.16})]));
   const bootMat=Object.fromEntries(['L','R'].map(side=>[side,new T.MeshStandardMaterial({color:c.trim,roughness:.55,metalness:.08})]));
   const judo=c.outfit===3||(c.outfit===0&&sim.style==='judo');
   for(const [name,p] of Object.entries(f.parts)){
    const g=new T.Group();this.scene.add(g);parts[name]=g;
    buildHumanPart(g,name,{body:bodyMat,dark,cream,skin,face,hair,glove:gloveMat[name.at(-1)],boot:bootMat[name.at(-1)],judo,config:c});
    g.scale.set(...p.spec.scale);
   }
   const marker=this.mesh(new T.RingGeometry(.50,.56,32),new T.MeshBasicMaterial({color,transparent:true,opacity:.6,side:T.DoubleSide}),[0,.023,0]);marker.rotation.x=-Math.PI/2;
   const shadow=this.mesh(new T.PlaneGeometry(2,1.55),new T.MeshBasicMaterial({map:this.contactTexture(),color:0x071017,transparent:true,opacity:.38,depthWrite:false}),[0,.018,0]);shadow.rotation.x=-Math.PI/2;
   const nameCanvas=document.createElement('canvas');nameCanvas.width=512;nameCanvas.height=96;
   const labelCtx=nameCanvas.getContext('2d');labelCtx.fillStyle='rgba(15,29,40,.80)';labelCtx.fillRect(10,10,492,76);
   labelCtx.fillStyle=f.id===0?'#d3f376':'#fc8c73';labelCtx.fillRect(10,10,8,76);
   labelCtx.font='900 44px Arial';labelCtx.textAlign='center';labelCtx.textBaseline='middle';labelCtx.fillStyle='#f4f3df';
   labelCtx.fillText(String(c.name||('JOGADOR '+(f.id+1))).toUpperCase(),260,50,454);
   const nameTexture=new T.CanvasTexture(nameCanvas);nameTexture.colorSpace=T.SRGBColorSpace;
   const nameSprite=new T.Sprite(new T.SpriteMaterial({map:nameTexture,transparent:true,depthWrite:false,depthTest:false}));
   nameSprite.scale.set(1.9,.36,1);this.scene.add(nameSprite);
   this.models.push({parts,marker,nameSprite,nameTexture,bodyMat,gloveMat,bootMat,shadow,skinMat:skin,materials:[bodyMat,dark,cream,skin,face,hair,...Object.values(gloveMat),...Object.values(bootMat)]});
  }
 }
 fabricTexture(){
  if(this.fabric)return this.fabric;
  const cv=document.createElement('canvas');cv.width=cv.height=64;const c=cv.getContext('2d');c.fillStyle='#808080';c.fillRect(0,0,64,64);
  for(let y=0;y<64;y+=2)for(let x=0;x<64;x+=2){c.fillStyle=(x+y)%4?'#777777':'#999999';c.fillRect(x,y,1,2);}
  const t=new T.CanvasTexture(cv);t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(9,9);this.fabric=t;return t;
 }
 contactTexture(){
  if(this.contact)return this.contact;
  const cv=document.createElement('canvas');cv.width=cv.height=64;const c=cv.getContext('2d');
  const gradient=c.createRadialGradient(32,32,2,32,32,32);gradient.addColorStop(0,'rgba(255,255,255,.7)');gradient.addColorStop(.45,'rgba(255,255,255,.35)');gradient.addColorStop(1,'rgba(255,255,255,0)');c.fillStyle=gradient;c.fillRect(0,0,64,64);this.contact=new T.CanvasTexture(cv);return this.contact;
 }
 makeAtmosphere(){
  this.cheer=0;this.rings=[];
  for(let i=0;i<6;i++){const ring=this.mesh(new T.RingGeometry(.15,.18,24),new T.MeshBasicMaterial({color:0xffe3ae,transparent:true,opacity:0,depthWrite:false,side:T.DoubleSide}),null,this.effects);ring.visible=false;ring.life=0;this.rings.push(ring);}
  this.beams=new T.Group();this.scene.add(this.beams);
  for(const x of [-4.7,4.7]){const beam=this.mesh(new T.ConeGeometry(1.5,5.5,12,1,true),new T.MeshBasicMaterial({color:x<0?0xbce97a:0xff8864,transparent:true,opacity:.035,depthWrite:false,side:T.DoubleSide,blending:T.AdditiveBlending}),[x,1.8,-5.5],this.beams);beam.rotation.z=x<0?-.16:.16;}
  this.beams.visible=!this.low;
  const cv=document.createElement('canvas');cv.width=1024;cv.height=96;this.scoreCanvas=cv;this.scoreContext=cv.getContext('2d');this.scoreTexture=new T.CanvasTexture(cv);this.scoreTexture.colorSpace=T.SRGBColorSpace;this.scoreAt=-1;
  this.mesh(new T.PlaneGeometry(6,.56),new T.MeshBasicMaterial({map:this.scoreTexture}),[0,3.5,-8.4]);
 }
 animateAtmosphere(sim,dt,menu){
  this.cheer=Math.max(0,this.cheer-dt*1.2);
  const crowd=this.crowd;
  if(crowd&&sim.time-crowd.at>(this.low?.16:.08)){
   crowd.at=sim.time;const o=crowd.dummy;
   for(let i=0;i<crowd.points.length;i++){
    const p=crowd.points[i],wave=Math.sin(sim.time*7+p.phase),bounce=this.cheer*Math.max(0,wave)*.12;
    o.rotation.set(0,0,0);o.scale.set(1,1,1);o.position.set(p.x,p.y+.39+bounce,p.z);o.updateMatrix();crowd.heads.setMatrixAt(i,o.matrix);
    o.position.y=p.y+.08+bounce;o.updateMatrix();crowd.torsos.setMatrixAt(i,o.matrix);
    for(const side of [-1,1]){o.position.set(p.x+side*.23,p.y+.09+bounce+this.cheer*.20,p.z);o.rotation.z=side*(.15+this.cheer*(2.1+wave*.25));o.updateMatrix();crowd.arms.setMatrixAt(i*2+(side===1?1:0),o.matrix);}
   }
   crowd.heads.instanceMatrix.needsUpdate=crowd.torsos.instanceMatrix.needsUpdate=crowd.arms.instanceMatrix.needsUpdate=true;
  }
  if(this.scoreAt!==Math.floor(sim.time)){
   this.scoreAt=Math.floor(sim.time);const c=this.scoreContext;c.fillStyle='#152333';c.fillRect(0,0,1024,96);c.textAlign='center';c.textBaseline='middle';c.font='bold 34px monospace';
   c.fillStyle='#d3f376';c.fillText('P1  '+Math.ceil(sim.fighters[0].hp),180,48);c.fillStyle='#ffad92';c.fillText(Math.ceil(sim.fighters[1].hp)+'  P2',844,48);c.fillStyle='#e1e7d5';c.font='bold 21px monospace';c.fillText(menu?'FIGHT NIGHT':'ENERGIA  /  AO VIVO',512,48);this.scoreTexture.needsUpdate=true;
  }
  for(const ring of this.rings){if(ring.life<=0){ring.visible=false;continue;}ring.life-=dt;ring.visible=ring.life>0;ring.quaternion.copy(this.camera.quaternion);ring.scale.setScalar(1+(1-ring.life/.23)*2.4);ring.material.opacity=Math.max(0,ring.life/.23)*.65;}
 }
 batchArena(){
  // Batch only static meshes with identical surface properties. Keep lights, crowd instances and effects separate.
  const batches=new Map();this.scene.updateMatrixWorld(true);
  for(const obj of [...this.scene.children]){if(!obj.isMesh||obj.isInstancedMesh||obj.material.map)continue;const m=obj.material,key=[m.type,m.color.getHex(),obj.receiveShadow,m.side].join('/');if(!batches.has(key))batches.set(key,[]);batches.get(key).push(obj);}
  for(const list of batches.values()){if(list.length<2)continue;const baked=list.map(o=>o.geometry.clone().applyMatrix4(o.matrixWorld));const merged=mergeGeometries(baked,false);for(const g of baked)g.dispose();if(!merged)continue;const mesh=new T.Mesh(merged,list[0].material);mesh.receiveShadow=list[0].receiveShadow;this.scene.add(mesh);for(const o of list){this.scene.remove(o);o.geometry.dispose();if(o.material!==mesh.material)o.material.dispose();}}
  for(const obj of this.scene.children)if(obj.isMesh){obj.updateMatrix();obj.matrixAutoUpdate=false;}
 }
 quality(low){this.low=low;if(this.beams)this.beams.visible=!low;if(this.floorMaterial){this.floorMaterial.bumpMap=low?null:this.fabricTexture();this.floorMaterial.needsUpdate=true;}this.renderer.shadowMap.enabled=!low;this.resolutionScale=low?1:Math.min(devicePixelRatio,1.5);this.renderer.setPixelRatio(this.resolutionScale);this.resize();}
 adapt(fps){if(!this.low||fps>=44||this.resolutionScale<=.70)return false;this.resolutionScale=Math.max(.70,this.resolutionScale-.15);this.renderer.setPixelRatio(this.resolutionScale);this.resize();return true;}
 resize(){const w=innerWidth,h=innerHeight;this.renderer.setSize(w,h,false);this.camera.aspect=w/h;this.camera.updateProjectionMatrix();}
 event(e){if(!e.position||!['hit','block','break','throw','parry','dash','dodge','escape','recover','turbo','hazard','guardbreak','step'].includes(e.type))return;if(e.type==='step'){if(!this.low&&this.particles.length<38)for(let i=0;i<2;i++)this.particles.push({position:new T.Vector3(e.position.x,.06,e.position.z),color:new T.Color(0x9dafad),life:.19,v:new T.Vector3((Math.random()-.5)*.8,.2,(Math.random()-.5)*.8)});return;}
  this.cheer=Math.max(this.cheer,e.finisher||e.type==='throw'||e.type==='parry'||e.type==='break'?1:e.type==='hit'?.32:0);
  if(['hit','block','parry'].includes(e.type)&&this.rings){const ring=this.rings.find(r=>r.life<=0)||this.rings[0];ring.position.set(e.position.x,e.position.y,e.position.z);ring.life=.23;ring.visible=true;ring.material.color.setHex(e.type==='parry'?0x86ffff:e.type==='block'?0xe7eee5:e.kick?0xffb36f:0xe4f896);}
  this.shake=Math.max(this.shake,e.type==='break'?.13:e.type==='throw'?.10:e.type==='block'?.025:.06*(e.power||1));const color=new T.Color(['parry','dodge','escape'].includes(e.type)?0x7df4ed:['turbo','hazard','guardbreak','step'].includes(e.type)?0xffbd54:e.type==='break'?0xffb784:e.type==='block'?0xe8f4e1:0xe4f896);const count=this.low?(e.type==='break'?6:3):(e.type==='break'?10:6);for(let i=0;i<count;i++)this.particles.push({position:new T.Vector3(e.position.x,e.position.y,e.position.z),color,life:.35+Math.random()*.3,v:new T.Vector3((Math.random()-.5)*4+(e.direction?.x||0)*(e.power||1)*2,Math.random()*3,(Math.random()-.5)*4+(e.direction?.z||0)*(e.power||1)*2)});while(this.particles.length>40)this.particles.shift();}
 render(sim,dt,menu=false,alpha=1){for(const f of sim.fighters){const model=this.models[f.id];if(!model)continue;for(const [name,p] of Object.entries(f.parts)){const g=model.parts[name];const b=p.body;g.position.lerpVectors(b.previousPosition,b.position,alpha);g.quaternion.set(b.previousQuaternion.x,b.previousQuaternion.y,b.previousQuaternion.z,b.previousQuaternion.w).slerp(this.tempQuaternion.set(b.quaternion.x,b.quaternion.y,b.quaternion.z,b.quaternion.w),alpha);g.visible=p.body.position.y> -5&&(!this.editor||this.editor.index===f.id);}model.marker.position.set(f.root.position.x,.025,f.root.position.z);model.marker.visible=(!this.editor||this.editor.index===f.id)&&f.alive&&Math.abs(f.root.position.x)<5.0&&Math.abs(f.root.position.z)<4;model.bodyMat.emissive.setHex(f.recoil>0?0x42201a:0x000000);
  if(model.skinMat)model.skinMat.emissive.setHex(f.recoil>0?0x24110b:0);
  for(const side of ['L','R']){
   const punch=f.attacks[side];
   const active=punch&&punch.t<punch.strikeEnd+.04;
   model.gloveMat[side].emissive.setHex(active?(punch.t<punch.wind?0x302219:0x614a28):0x000000);
   const kick=f.legAttack;model.bootMat[side].emissive.setHex(kick?.side===side&&kick.t<kick.strikeEnd+.04?0x49321a:0x000000);
  }
  model.nameSprite.position.set(f.parts.head.body.position.x,f.parts.head.body.position.y+.58,f.parts.head.body.position.z);model.nameSprite.visible=!this.editor||this.editor.index===f.id;
  model.shadow.position.set(f.root.position.x,.018,f.root.position.z);model.shadow.visible=model.marker.visible;model.shadow.material.opacity=clamp(.42-(f.root.position.y-1.1)*.16,.08,.42);
  model.marker.material.opacity=f.dodgeTime>0?.9:f.stun>0?.22:.55;model.marker.material.color.setHex(f.parryTime>0?0x86ffff:f.hype>=100?0xffc857:f.id===0?C.mint:C.coral);model.marker.scale.setScalar(f.hype>=100?1.1+Math.sin(sim.time*7)*.06:1);}
  const h=sim.hazard;this.hazardMesh.visible=this.hazardEdge.visible=!!h?.visible&&!menu;
  if(h?.visible){const x=h.axis==='x'?h.center:0,z=h.axis==='z'?h.center:0,w=h.axis==='x'?h.half*2:10.2,d=h.axis==='z'?h.half*2:8.2;
   this.hazardMesh.position.set(x,h.active?.05:.028,z);this.hazardEdge.position.set(x,.055,z);this.hazardMesh.scale.set(w,d,1);this.hazardEdge.scale.set(w,d,1);this.hazardMesh.material.color.setHex(h.active?0xff664f:0xffc857);this.hazardMesh.material.opacity=h.active?.75:.22+Math.sin(sim.time*14)*.09;
  }
  this.updateElasticNets(sim);
  const a=sim.fighters[0].root.position,b=sim.fighters[1].root.position;const dist=Math.hypot(a.x-b.x,a.z-b.z);const center=this.center.set(clamp((a.x+b.x)/2,-4.4,4.4),1,clamp((a.z+b.z)/2,-3.5,3.5));this.target.lerp(center,Math.min(1,dt*7));const zoom=menu?1.20:clamp(.72+(dist-1.8)*.09,.72,1.65)*Math.max(1,1.45/this.camera.aspect);const camPos=this.camPos.set(this.target.x+6.7*zoom,this.target.y+4.65*zoom,this.target.z+9.4*zoom);if(menu){camPos.set(7.3,6.5,10.5);this.target.set(-.55,.1,0);}this.camera.position.lerp(camPos,Math.min(1,dt*8));if(this.camera.position.length()<1)this.camera.position.copy(camPos);this.shake*=Math.exp(-dt*15);this.camera.position.x+=(Math.random()-.5)*this.shake;this.camera.position.y+=(Math.random()-.5)*this.shake;this.camera.lookAt(this.target);
  if(this.editor){
   const f=sim.fighters[this.editor.index],p=f.root.position,h=f.body.bodyHeight,angle=f.yaw+this.editor.angle;
   this.camera.setViewOffset(innerWidth,innerHeight,-innerWidth*.20,0,innerWidth,innerHeight);
   this.camera.position.set(p.x+Math.sin(angle)*h*2,p.y+h*.40,p.z+Math.cos(angle)*h*2);
   this.camera.lookAt(p.x,h*.54,p.z);
  }else if(this.camera.view?.enabled)this.camera.clearViewOffset();
  for(let i=this.particles.length-1;i>=0;i--){const p=this.particles[i];p.life-=dt;p.v.y-=dt*8;p.position.addScaledVector(p.v,dt);if(p.life<=0)this.particles.splice(i,1);}
  this.particleMesh.count=this.particles.length;for(let i=0;i<this.particles.length;i++){const p=this.particles[i],o=this.particleDummy;o.position.copy(p.position);o.rotation.set(p.life*6,p.life*8,0);o.scale.setScalar(Math.min(1,p.life*4));o.updateMatrix();this.particleMesh.setMatrixAt(i,o.matrix);this.particleMesh.setColorAt(i,p.color);}if(this.particles.length){this.particleMesh.instanceMatrix.needsUpdate=true;this.particleMesh.instanceColor.needsUpdate=true;}
  this.animateAtmosphere(sim,dt,menu);
  this.renderer.render(this.scene,this.camera);
 }
}
function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
