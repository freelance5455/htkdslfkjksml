import * as T from './vendor/three.module.js';
import {mergeGeometries} from './vendor/BufferGeometryUtils.js';

// Continuous, chamfered cross-sections. Every face owns its normal, so a broad
// planar surface cannot inherit diagonal corner normals from a deformed cube.
export function facetedGeometry(rings){
 const positions=[],normals=[],uvs=[];
 const sections=rings.map(({y,w,d,x=0,z=0,c=.23})=>{
  const a=w/2,b=d/2,u=w*c/2,v=d*c/2;
  return [[-a+u,-b],[a-u,-b],[a,-b+v],[a,b-v],[a-u,b],[-a+u,b],[-a,b-v],[-a,-b+v]].map(([px,pz])=>new T.Vector3(px+x,y,pz+z));
 });
 function face(vertices){
  const n=new T.Vector3().subVectors(vertices[1],vertices[0]).cross(new T.Vector3().subVectors(vertices[2],vertices[0])).normalize();
  for(let i=1;i<vertices.length-1;i++)for(const [j,uv] of [[0,[0,0]],[i,[1,0]],[i+1,[1,1]]]){positions.push(...vertices[j].toArray());normals.push(...n.toArray());uvs.push(...uv);}
 }
 for(let row=0;row<sections.length-1;row++)for(let i=0;i<8;i++){const next=(i+1)%8;face([sections[row][i],sections[row+1][i],sections[row+1][next],sections[row][next]]);}
 face(sections[0]);face([...sections.at(-1)].reverse());
 const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(positions,3));geometry.setAttribute('normal',new T.Float32BufferAttribute(normals,3));geometry.setAttribute('uv',new T.Float32BufferAttribute(uvs,2));return geometry;
}

// Anatomy remains decorative and follows the proven physics skeleton.
export function buildHumanPart(group,name,{body,dark,cream,skin,face,hair,glove,boot,judo,config={}}){
 const batches=new Map();let pieces=0;
 function add(material,rings,position=[0,0,0],rotation=[0,0,0]){
  const geometry=facetedGeometry(rings),transform=new T.Matrix4().compose(new T.Vector3(...position),new T.Quaternion().setFromEuler(new T.Euler(...rotation)),new T.Vector3(1,1,1));geometry.applyMatrix4(transform);
  if(!batches.has(material))batches.set(material,[]);batches.get(material).push(geometry);pieces++;
 }
 function piece(material,[w,h,d],position=[0,0,0],rotation=[0,0,0],c=.24){
  const bevel=Math.min(h*.13,.016);
  add(material,[{y:-h/2,w:w*.88,d:d*.88,c},{y:-h/2+bevel,w,d,c},{y:h/2-bevel,w,d,c},{y:h/2,w:w*.88,d:d*.88,c}],position,rotation);
 }
 const side=name.endsWith('L')?-1:1;
 const trousers=config.bottom===1||config.bottom===3?body:dark;
 const legMaterial=judo?cream:(/^(thigh|shin)/.test(name)&&config.bottom>0?trousers:skin);
 if(name==='head'){
  // One faceted cranium, cheekbone transition and tapered jaw. No stacked face cubes.
  add(skin,[{y:-.215,w:.19,d:.22,z:.025},{y:-.145,w:.285,d:.29,z:.018},{y:-.045,w:.35,d:.34},{y:.12,w:.345,d:.335},{y:.205,w:.28,d:.28}]);
  for(const sign of [-1,1]){
   piece(skin,[.035,.092,.06],[sign*.177,-.018,-.008]);
   const eyeY=config.face===2?.045:config.face===4?.031:.037;
   const eyeW=config.face===2?.052:config.face===4?.067:.060;
   piece(face,[eyeW,config.face===2?.019:.015,.011],[sign*.083,eyeY,.174],undefined,.10);
  }
  add(skin,[{y:-.065,w:.065,d:.025,z:.182},{y:-.035,w:.065,d:.067,z:.19},{y:.065,w:.025,d:.014,z:.17}]);
  const mouthY=config.face===2?-.142:-.139;
  if(config.face===3)for(const sign of [-1,1])piece(face,[.038,.007,.009],[sign*.017,-.132,.171],[0,0,sign*.14],.12);
  else piece(face,[config.face===2?.056:.067,.007,.009],[0,mouthY,.171],undefined,.12);
 }else if(name==='torso'){
  const shell=judo?cream:body;
  add(shell,[{y:-.105,w:.48,d:.335},{y:-.045,w:.61,d:.43},{y:.15,w:.78,d:.43},{y:.235,w:.70,d:.345},{y:.27,w:.40,d:.28}]);
  // The abdomen has its own silhouette; no intersecting stripes or six-pack cubes.
  add(judo?cream:(config.outfit===2?skin:shell),[{y:-.285,w:.43,d:.30},{y:-.22,w:.45,d:.32},{y:-.125,w:.46,d:.315}]);
  add(skin,[{y:.265,w:.185,d:.19},{y:.34,w:.17,d:.18},{y:.39,w:.18,d:.19}]);
  if(judo){
   for(const sign of [-1,1])piece(cream,[.065,.31,.035],[sign*.07,.06,.225],[0,0,sign*.32]);
   piece(body,[.47,.065,.34],[0,-.235,0]);piece(body,[.085,.075,.045],[0,-.235,.19]);piece(body,[.055,.16,.03],[.035,-.32,.18],[0,0,.12]);
  }else if(config.outfit===0){
   for(const sign of [-1,1])piece(dark,[.22,.018,.012],[sign*.18,.19,.219],[0,0,sign*-.10]);
   piece(cream,[.052,.067,.010],[-.18,.08,.223]);piece(dark,[.024,.12,.010],[0,.03,.224]);
  }else if(config.outfit===4){
   for(const sign of [-1,1])piece(dark,[.035,.25,.014],[sign*.075,.09,.225],[0,0,sign*.04]);
   add(body,[{y:.18,w:.42,d:.12,z:-.19},{y:.32,w:.30,d:.18,z:-.17},{y:.39,w:.22,d:.18,z:-.15}]);
   piece(dark,[.20,.055,.016],[0,.205,.220]);
  }else if(config.outfit===5){
   for(const sign of [-1,1])piece(dark,[.25,.025,.012],[sign*.12,.18,.222],[0,0,sign*.22]);
   piece(dark,[.025,.31,.012],[0,.02,.225]);
   for(const sign of [-1,1])piece(cream,[.14,.045,.012],[sign*.18,-.01,.224]);
  }else if(config.outfit===6){
   for(const sign of [-1,1])piece(dark,[.22,.022,.012],[sign*.21,.20,.219],[0,0,sign*-.08]);
   piece(dark,[.44,.035,.012],[0,-.22,.190]);
  }
 }else if(name==='pelvis'){
  add(judo?cream:body,[{y:-.18,w:.31,d:.28,z:.015},{y:-.08,w:.56,d:.39},{y:.085,w:.59,d:.38},{y:.17,w:.44,d:.31}]);
  piece(dark,[.46,.045,.325],[0,.145,0]);
  for(const sign of [-1,1])piece(judo?cream:body,[.13,.17,.29],[sign*.24,-.025,0],[0,0,sign*.08]);
 }else if(name.startsWith('arm')){
  // Shoulder cap flows into biceps; the smaller elbow fits inside the forearm opening.
  const longSleeve=!judo&&config.outfit===6,upperClothed=judo||[0,1,4,5,6].includes(config.outfit);
  add(longSleeve?body:skin,[{y:-.205,w:.165,d:.18},{y:-.12,w:.205,d:.215},{y:.045,w:.26,d:.265},{y:.10,w:.27,d:.275}]);
  add(judo?cream:(upperClothed?body:skin),[{y:.10,w:.27,d:.275},{y:.16,w:.28,d:.28},{y:.235,w:.19,d:.205}]);
  if(config.outfit===4&&!judo)piece(dark,[.275,.035,.282],[0,.085,0]);
  if(config.outfit===5&&!judo)piece(dark,[.275,.026,.282],[0,.10,0]);
  piece(dark,[.14,.07,.145],[0,-.226,0]);
 }else if(name.startsWith('hand')){
  add(skin,[{y:-.15,w:.15,d:.16},{y:-.035,w:.175,d:.18},{y:.12,w:.225,d:.235},{y:.205,w:.20,d:.205},{y:.24,w:.15,d:.155}]);
  piece(cream,[.18,.053,.19],[0,-.145,0]);
  // The glove back faces the camera; the thumb always points inward toward the torso.
  add(glove,[{y:-.34,w:.245,d:.22,z:.008},{y:-.245,w:.285,d:.265,z:.002},{y:-.17,w:.21,d:.21}]);
  for(let i=0;i<4;i++){
   const x=(i-1.5)*.063;
   piece(glove,[.057,.080,.20],[x,-.35,.016]);
   piece(glove,[.055,.052,.065],[x,-.315,.118],[.12,0,0]);
  }
  piece(glove,[.07,.125,.12],[-side*.145,-.25,.045],[0,0,-side*.3]);
  piece(glove,[.068,.065,.085],[-side*.13,-.32,.085],[0,0,-side*.45]);
  piece(dark,[.12,.026,.010],[0,-.235,.138]);
  if(config.accessory===8)piece(body,[.19,.075,.195],[0,-.14,0]);
 }else if(name.startsWith('thigh')){
  // A single continuous quad profile replaces three overlapping boxes and their bands.
  if(config.bottom===0&&!judo){
   add(skin,[{y:-.238,w:.185,d:.19,z:.005},{y:-.16,w:.215,d:.23},{y:.055,w:.275,d:.295,z:-.008}]);
   add(dark,[{y:.055,w:.278,d:.298,z:-.008},{y:.17,w:.300,d:.294},{y:.242,w:.248,d:.243}]);
  }else add(legMaterial,[{y:-.238,w:.185,d:.19,z:.005},{y:-.16,w:.215,d:.23},{y:.035,w:.275,d:.295,z:-.008},{y:.17,w:.295,d:.29},{y:.242,w:.245,d:.24}]);
  if(config.bottom===3)piece(dark,[.13,.15,.035],[side*.13,.02,.13]);
  if(config.bottom===4)piece(body,[.19,.03,.21],[0,-.18,0]);
  piece(dark,[.15,.045,.155],[0,-.257,0]);
 }else if(name.startsWith('shin')){
  // Kneecap is shaped into the same shell. Calf tapers to a slender ankle.
  add(legMaterial,[{y:-.17,w:.135,d:.15},{y:-.06,w:.165,d:.185,z:-.006},{y:.055,w:.235,d:.255,z:-.018},{y:.135,w:.215,d:.23},{y:.205,w:.205,d:.245,z:.012},{y:.245,w:.165,d:.185}]);
  piece(cream,[.16,.045,.175],[0,-.145,0]);
  // Wedge boot has one hull, with a raised heel and a lower toe rather than stacked cubes.
  add(boot,[{y:-.255,w:.28,d:.46,z:.115},{y:-.20,w:.285,d:.465,z:.115},{y:-.12,w:.245,d:.32,z:.055},{y:-.075,w:.16,d:.18,z:.008}]);
  add(cream,[{y:-.276,w:.268,d:.45,z:.115},{y:-.255,w:.28,d:.46,z:.115}]);
  for(const z of [.12,.175])piece(body,[.15,.008,.023],[0,-.068-(z-.098)*.3846,z],[.367,0,0]);
 }
 // Cosmetics add no colliders or bonuses. They are baked with their parent limb.
 if(name==='head'){
  // Every expression uses the hair colour for brows and the dark face material for eyes.
  const brows={0:[.076,.016,.075,.025],1:[.078,.019,.072,.18],2:[.064,.014,.080,-.045],3:[.082,.021,.068,.31],4:[.076,.018,.061,.08]}[config.face]||[.076,.016,.075,.025];
  for(const sign of [-1,1])piece(hair,[brows[0],brows[1],.010],[sign*.082,brows[2],.180],[0,0,sign*brows[3]]);
  if(config.hair>0){
   const low=config.hair===5?.158:.125;
   add(hair,[{y:low,w:.35,d:.34},{y:.20,w:.34,d:.33},{y:config.hair===5?.218:.235,w:.27,d:.265}]);
   if(config.hair===2)piece(hair,[.25,.085,.19],[0,.25,.07],[.14,0,0]);
   if(config.hair===3)piece(hair,[.105,.12,.30],[0,.27,-.005]);
   if(config.hair===4){piece(hair,[.13,.13,.15],[0,.15,-.205]);piece(hair,[.09,.22,.08],[0,-.005,-.24],[.18,0,0]);}
   if(config.hair===6)for(const [x,y,z] of [[-.12,.235,.04],[0,.25,.07],[.12,.235,.04],[-.09,.215,-.12],[.09,.215,-.12]])piece(hair,[.12,.10,.12],[x,y,z]);
   if(config.hair===7){piece(hair,[.24,.10,.18],[-.045,.245,.045],[.10,0,-.16]);piece(hair,[.07,.16,.22],[.15,.17,-.01]);}
  }
  if(config.beard>0){
   if(config.beard===3)piece(hair,[.16,.035,.026],[0,-.095,.174]);
   else piece(hair,[config.beard===1||config.beard===4?.23:.10,config.beard===4?.105:.07,.035],[0,-.17,.15]);
   if(config.beard===1||config.beard===4)for(const sign of [-1,1])piece(hair,[config.beard===4?.07:.055,.13,.075],[sign*.135,-.1,.125],[0,0,sign*.14]);
   if(config.beard===4)piece(hair,[.17,.06,.04],[0,-.105,.165]);
  }
  if(config.accessory===1)add(body,[{y:.092,w:.361,d:.350},{y:.135,w:.358,d:.348}]);
  if(config.accessory===2){for(const sign of [-1,1]){piece(dark,[.13,.07,.025],[sign*.088,.041,.182]);piece(cream,[.075,.018,.009],[sign*.085,.057,.20]);}piece(dark,[.055,.018,.027],[0,.048,.18]);}
  if(config.accessory===5)piece(cream,[.075,.024,.014],[0,-.025,.205]);
  if(config.accessory===6)for(const sign of [-1,1])piece(body,[.025,.045,.025],[sign*.184,-.052,0]);
  if(config.accessory===7)piece(cream,[.083,.022,.014],[0,-.139,.181]);
  if(config.accessory===10){
   add(body,[{y:.09,w:.375,d:.355},{y:.20,w:.36,d:.34},{y:.245,w:.29,d:.275}]);
   for(const sign of [-1,1])piece(body,[.065,.25,.09],[sign*.18,-.01,-.015]);
   piece(dark,[.29,.028,.018],[0,-.132,.181]);
  }
 }
 if(name.startsWith('arm')&&config.accessory===3)piece(dark,[.19,.13,.075],[0,-.16,-.09]);
 if(name.startsWith('shin')&&config.accessory===4)piece(dark,[.21,.145,.07],[0,.18,.12]);
 if(name==='torso'&&config.outfit===2){for(const sign of [-1,1])piece(dark,[.052,.19,.012],[sign*.26,.14,.222],[0,0,sign*.13]);piece(dark,[.22,.022,.012],[0,.215,.220]);}
 if(name==='torso'&&config.accessory===9){piece(cream,[.105,.105,.014],[-.19,.07,.225]);piece(dark,[.045,.045,.012],[-.19,.07,.235],[0,0,.785]);}
 for(const [material,geometries] of batches){
  const merged=mergeGeometries(geometries,false);for(const geometry of geometries)geometry.dispose();
  const mesh=new T.Mesh(merged,material);mesh.castShadow=true;mesh.receiveShadow=false;group.add(mesh);
 }
 group.userData.blocks=pieces;group.userData.model='human';group.userData.surface='faceted';
 if(name==='head')group.userData.expression=LOOKUP_FACE[config.face]||'neutral';
 if(name.startsWith('hand'))group.userData.thumbDirection=-side;
 return group;
}
const LOOKUP_FACE=['neutral','determined','soft','angry','focused'];
