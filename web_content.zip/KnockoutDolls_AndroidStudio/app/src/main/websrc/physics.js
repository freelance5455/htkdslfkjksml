import {morphSkeleton} from './character.js?v=13';
import {hazardState,inHazard} from './arena.js?v=5';
import * as C from './vendor/cannon-es.js';
export const DT=1/60;
export const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const V=(x=0,y=0,z=0)=>new C.Vec3(x,y,z);
export const GRAB_DELAY=.22;
const ZERO=()=>({x:0,z:0,block:false,armL:false,armR:false,special:false,kick:false,dash:false});
export const STYLES={boxing:{name:'Boxe',speed:4.65,power:1.10,grab:250,special:'UPPERCUT'},judo:{name:'Judô',speed:4.15,power:.65,grab:650,special:'PROJETAR'},mixed:{name:'Livre',speed:4.45,power:1,grab:450,special:'CIRCULAR'}};
const SPECS={
 pelvis:{p:[0,1.16,0],size:[.32,.19,.21],mass:5},
 torso:{p:[0,1.57,0],size:[.37,.28,.23],mass:7},
 head:{p:[0,2.08,0],radius:.245,mass:2.3},
 armL:{p:[-.51,1.48,0],size:[.13,.24,.13],mass:1.5},
 armR:{p:[.51,1.48,0],size:[.13,.24,.13],mass:1.5},
 handL:{p:[-.51,1.00,0],size:[.12,.24,.12],mass:1.2,glove:true},
 handR:{p:[.51,1.00,0],size:[.12,.24,.12],mass:1.2,glove:true},
 thighL:{p:[-.20,.72,0],size:[.145,.25,.145],mass:2.8},
 thighR:{p:[.20,.72,0],size:[.145,.25,.145],mass:2.8},
 shinL:{p:[-.20,.23,.025],size:[.13,.23,.13],mass:1.8,foot:true},
 shinR:{p:[.20,.23,.025],size:[.13,.23,.13],mass:1.8,foot:true}
};
const JOINTS=[['pelvis','torso',[0,1.34,0],.4,.3],['torso','head',[0,1.88,0],.55,.5],['torso','armL',[-.45,1.72,0],1.9,1.25],['torso','armR',[.45,1.72,0],1.9,1.25],['armL','handL',[-.51,1.24,0],1.8,.5],['armR','handR',[.51,1.24,0],1.8,.5],['pelvis','thighL',[-.20,.97,0],1.5,.65],['pelvis','thighR',[.20,.97,0],1.5,.65],['thighL','shinL',[-.20,.47,0],1.3,.25],['thighR','shinR',[.20,.47,0],1.3,.25]];
export class Fighter{
 constructor(sim,id,x,z,yaw){const rig=morphSkeleton(SPECS,JOINTS,sim.characters?.[id]||(id===1?{cloth:'#ef8a70',gloves:'#c34d40',skin:'#ad8766'}:{}));this.body=rig.body;this.config=rig.body.config;this.scales=rig.scales;this.sim=sim;this.id=id;this.parts={};this.joints=[];this.hp=100;this.stamina=100;this.balance=100;this.stun=0;this.yaw=yaw;this.phase=0;this.wasSpecial=false;this.wasKick=false;this.kickCd=0;this.arms={L:{down:false,held:0,holding:false,cooldown:0,buffer:0},R:{down:false,held:0,holding:false,cooldown:0,buffer:0}};this.attacks={L:null,R:null};this.legAttack=null;this.recoil=0;this.armFlinch={L:0,R:0};this.guardOpen=0;this.fallGrace=0;this.comboSide=null;this.comboAt=-10;this.cooldown=0;this.specialCd=0;this.hitCount=0;this.alternate=0;this.grips={L:null,R:null};this.downs=0;this.lastHit=-10;this.aiTimer=.6;this.aiPulse=0;this.aiSide='R';this.input=ZERO();this.jabYield=0;this.plant=null;this.wasDash=false;this.wasBlock=false;this.dashCd=0;this.dashTime=0;this.dodgeTime=0;this.dashDir=V();this.parryTime=0;this.parryCd=0;this.counterTime=0;this.grabImmunity=0;this.hype=0;this.chain=0;this.chainAt=-10;this.chainSide=null;this.hazardHit=-1;this.reactAt=0;this.sawAttack=false;this.stats={hits:0,parries:0,dodges:0,escapes:0,throws:0,bestCombo:0,turbos:0};
  const q=new C.Quaternion();q.setFromEuler(0,yaw,0);
  for(const [name,sp] of Object.entries(rig.specs)){const p=q.vmult(V(...sp.p));p.x+=x;p.z+=z;const b=new C.Body({mass:sp.mass,position:p,quaternion:q.clone(),linearDamping:.22,angularDamping:.5,collisionFilterGroup:id===0?2:4,collisionFilterMask:id===0?13:11,material:sim.dollMaterial});if(sp.radius)b.addShape(new C.Sphere(sp.radius));else b.addShape(new C.Box(V(...sp.size)));if(sp.glove)b.addShape(new C.Sphere(.185*Math.max(sp.scale[0],sp.scale[1])),V(0,-.23*sp.scale[1],0));if(sp.foot)b.addShape(new C.Box(V(.15*sp.scale[0],.08*sp.scale[1],.24*sp.scale[2])),V(0,-.17*sp.scale[1],.11*sp.scale[2]));b.fighter=this;b.partName=name;sim.world.addBody(b);this.parts[name]={name,body:b,spec:sp,attached:true,integrity:34};}
  for(const [parent,child,pivot,angle,twist] of rig.joints){const a=this.parts[parent].body,b=this.parts[child].body,p=q.vmult(V(...pivot));p.x+=x;p.z+=z;const con=new C.ConeTwistConstraint(a,b,{pivotA:a.pointToLocalFrame(p),pivotB:b.pointToLocalFrame(p),axisA:V(0,1,0),axisB:V(0,1,0),angle,twistAngle:twist,maxForce:2500*this.body.mass,collideConnected:false});for(const eq of con.equations)eq.setSpookParams(3e6,4,DT);sim.world.addConstraint(con);this.joints.push({parent,child,constraint:con,broken:false});}
 }
 get root(){return this.parts.pelvis.body;}
 get alive(){return this.hp>0&&this.root.position.y> -3;}
 get legs(){return Number(this.parts.thighL.attached)+Number(this.parts.thighR.attached);}
 limbPoint(name){const s=this.scales[name];return name.startsWith('shin')?V(0,-.17*s[1],.30*s[2]):V(0,-.23*s[1],0);}
 handPoint(name){return this.parts[name].body.pointToWorldFrame(this.limbPoint(name));}
 get grip(){return this.grips.L||this.grips.R;}
 get gripTime(){return Math.max(this.grips.L?.elapsed||0,this.grips.R?.elapsed||0);}
 get attack(){return this.legAttack||this.attacks.L||this.attacks.R;}
 activeAttacks(){return [this.attacks.L,this.attacks.R,this.legAttack].filter(Boolean);}
 release(side){for(const hand of side?[side]:['L','R']){const grip=this.grips[hand];if(grip)this.sim.world.removeConstraint(grip.constraint);this.grips[hand]=null;}}
 cancelArm(side){this.release(side);Object.assign(this.arms[side],{down:false,held:0,holding:false,buffer:0});}
 resetControls(){for(const side of ['L','R'])this.cancelArm(side);this.wasSpecial=false;this.wasKick=false;this.wasDash=false;this.wasBlock=false;this.parryTime=0;}
 detach(name){const joint=this.joints.find(j=>j.child===name&&!j.broken);if(!joint||['head','torso'].includes(name))return false;if(name.startsWith('thigh')||name.startsWith('shin'))this.legAttack=null;if(name.startsWith('arm')||name.startsWith('hand')){const side=name.at(-1);this.cancelArm(side);this.attacks[side]=null;}joint.broken=true;this.sim.world.removeConstraint(joint.constraint);const remove=n=>{const p=this.parts[n];p.attached=false;p.body.collisionFilterGroup=8;p.body.collisionFilterMask=15;for(const j of this.joints)if(j.parent===n&&!j.broken)remove(j.child);};remove(name);this.balance=Math.max(0,this.balance-(/^(arm|hand)/.test(name)?6:25));this.sim.events.push({type:'break',fighter:this.id,part:name,position:this.parts[name].body.position.clone()});return true;}
 knock(duration=1.5){if(this.stun<.1)this.downs++;this.stun=Math.max(this.stun,duration);this.balance=30;this.release();this.attacks.L=this.attacks.R=this.legAttack=null;}
 gainHype(amount){const old=this.hype;this.hype=clamp(this.hype+amount,0,100);if(old<100&&this.hype>=100)this.sim.events.push({type:'ready',fighter:this.id,position:this.root.position.clone()});}
 empower(attack){if(this.hype<100)return;this.hype=0;this.stats.turbos++;if(attack){attack.turbo=true;attack.heavy=true;attack.power=1.3;attack.kind='TURBO '+attack.kind;}this.stamina=Math.min(100,this.stamina+15);this.sim.events.push({type:'turbo',fighter:this.id,position:this.parts.torso.body.position.clone()});}
 evade(input,enemy){
  if(!this.alive||this.dashCd>0||this.stamina<26*this.body.cost||this.legs===0)return false;
  this.stamina-=26*this.body.cost;this.dashCd=.85/this.body.mobility;this.release();this.attacks.L=this.attacks.R=this.legAttack=null;
  const caught=['L','R'].filter(side=>enemy.grips[side]?.enemy===this);
  if(caught.length){for(const side of caught)enemy.release(side);this.grabImmunity=.7;this.stats.escapes++;this.sim.events.push({type:'escape',fighter:this.id,position:this.root.position.clone()});}
  if(this.stun>.2){this.stun=Math.max(.12,this.stun-.75);this.balance=Math.max(this.balance,55);this.sim.events.push({type:'recover',fighter:this.id,position:this.root.position.clone()});return true;}
  const len=Math.hypot(input.x||0,input.z||0);this.dashDir.set(len>.15?input.x/len:-Math.sin(this.yaw),0,len>.15?input.z/len:-Math.cos(this.yaw));this.dashTime=.22;this.dodgeTime=.13;
  this.sim.events.push({type:'dash',fighter:this.id,position:this.root.position.clone()});return true;
 }
 torque(name,rx,rz,k=32,d=4,weight=1,yawOffset=0){const part=this.parts[name];if(!part.attached)return;const size=this.scales[name],motor=this.body.mass*Math.max(size[0],size[1],size[2])**2;k*=motor;d*=motor;const b=part.body,yaw=new C.Quaternion();yaw.setFromEuler(0,this.yaw+yawOffset,0);const pose=new C.Quaternion();pose.setFromEuler(rx,0,rz,'XYZ');const target=yaw.mult(pose);const err=target.mult(b.quaternion.conjugate());if(err.w<0){err.x*=-1;err.y*=-1;err.z*=-1;}const inv=b.quaternion.conjugate(),el=inv.vmult(V(err.x,err.y,err.z)),wl=inv.vmult(b.angularVelocity),tl=V();for(const axis of ['x','y','z'])tl[axis]=(2*k*el[axis]-d*wl[axis])*weight/(1+(d*DT+k*DT*DT)*b.invInertia[axis]);const t=b.quaternion.vmult(tl);const len=t.length();if(len>k*1.8)t.scale(k*1.8/len,t);b.torque.vadd(t,b.torque);}
 driveGround(input,enemy,active,maxSpeed){
  const root=this.root;
  let mass=0;
  for(const part of Object.values(this.parts))if(part.attached)mass+=part.body.mass;
  const lift=mass*20.2+((this.legs===1?.95/1.13:1)*this.body.standHeight-root.position.y)*580*this.body.mass-root.velocity.y*110*this.body.mass;
  root.force.y+=clamp(lift,0,1150*this.body.mass)*active;

  const dash=this.dashTime>0;
  const planting=!dash&&Math.hypot(input.x,input.z)<.01&&!this.grip&&enemy.grip?.enemy!==this
   &&this.stun<=0&&this.recoil<=0&&this.sim.time-this.lastHit>.22;
  if(planting&&!this.plant&&Math.hypot(root.velocity.x,root.velocity.z)<.55)this.plant={x:root.position.x,z:root.position.z};
  if(!planting)this.plant=null;
  let vx=dash?this.dashDir.x*8*this.body.mobility:input.x*maxSpeed;
  let vz=dash?this.dashDir.z*8*this.body.mobility:input.z*maxSpeed;
  if(this.plant){
   // Plant against the mat, never relative to the other fighter. Yield to a shove.
   const dx=this.plant.x-root.position.x,dz=this.plant.z-root.position.z;
   if(Math.hypot(dx,dz)>.28){this.plant.x=root.position.x;this.plant.z=root.position.z;}
   else {vx=dx*4;vz=dz*4;}
  }
  const gain=(planting?460:210)*this.body.mass;
  const response=active*(this.jabYield>0?.20:this.recoil>0?.35:1);
  const limit=(planting?1500:dash?840:660)*this.body.mass;
  const fx=clamp((vx-root.velocity.x)*gain,-limit,limit)*response;
  const fz=clamp((vz-root.velocity.z)*gain,-limit,limit)*response;
  // Carry the whole attached mass. Driving only the pelvis folds the chest backward.
  for(const part of Object.values(this.parts))if(part.attached){
   const share=part.body.mass/mass;
   part.body.force.x+=fx*share;part.body.force.z+=fz*share;
  }
 }
 startPunch(side,upper=false){
  const arm=this.arms[side];if(!this.alive||this.stun>.2||this.legAttack||arm.cooldown>0||this.attacks[side]||!this.parts['hand'+side].attached||this.grips[side])return false;
  if(this.chain>=3)this.chain=0;
  const combo=this.chain>0&&this.chainSide!==side&&this.sim.time-this.chainAt<1.25,finisher=combo&&this.chain>=2;
  const cost=(upper?22:combo?12:9)*this.body.cost;if(this.stamina<cost)return false;
  this.stamina-=cost;const counter=this.counterTime>0;this.counterTime=0;this.comboSide=side;this.comboAt=this.sim.time;
  const a={limb:'hand'+side,side,finisher,counter,t:0,duration:upper?.44:side==='L'?.34:.38,wind:upper?.125:side==='L'?.095:.115,strikeEnd:upper?.29:side==='L'?.225:.255,heavy:upper||Boolean(combo)||counter,power:upper?.9:combo?.8:side==='R'?.65:.5,upper,kick:false,hit:false,hitAt:null,peakSpeed:0,prev:this.handPoint('hand'+side),kind:finisher?'FINALIZAÇÃO':counter?'CONTRA-ATAQUE':upper?'UPPERCUT':side==='L'?'JAB':'DIRETO'};
  a.tempo=this.body.cadence;a.profile=this.body.technique;a.hook=!upper&&side==='R'&&this.body.technique==='compact';a.duration*=a.tempo;a.wind*=a.tempo;a.strikeEnd*=a.tempo;if(!finisher&&!counter&&!upper)a.kind=a.hook?'GANCHO CURTO':this.body.technique==='reach'?'DIRETO LONGO':this.body.technique==='heavy'?'DIRETO PESADO':a.kind;
  this.attacks[side]=a;arm.cooldown=a.duration+.015;this.sim.events.push({type:'swing',fighter:this.id,side,kind:a.kind});return true;
 }
 special(){
  if(!this.alive||this.stun>.2||this.specialCd>0||this.cooldown>0)return false;
  if(this.grip&&this.sim.style!=='boxing'){
   if(this.stamina<25*this.body.cost)return false;const turbo=this.hype>=100;const enemy=this.grip.enemy,two=!!(this.grips.L&&this.grips.R);this.release();const f=V(Math.sin(this.yaw),0,Math.cos(this.yaw)),strong=this.sim.style==='judo',force=(strong?39:29)*(two?1.15:1)*(turbo?1.35:1)*this.body.grip;if(turbo)this.empower();this.stats.throws++;this.gainHype(turbo?0:22);
   enemy.root.applyImpulse(V(f.x*force,20,f.z*force),V(.22,.35,0));enemy.parts.torso.body.angularVelocity.set(f.z*5,1,-f.x*5);enemy.hp=Math.max(0,enemy.hp-(strong?19:12)*(turbo?1.5:1)*this.body.grip);enemy.knock(strong?1.55:1.2);this.stamina-=25*this.body.cost;this.specialCd=1.5;this.cooldown=.35;enemy.gainHype(10);this.sim.events.push({type:'throw',fighter:this.id,turbo,position:enemy.root.position.clone()});return true;
  }
  if(this.sim.style==='judo'){this.specialCd=.35;this.sim.events.push({type:'hint',fighter:this.id,text:'SEGURE LT OU RT PARA AGARRAR'});return false;}
  if(this.sim.style==='boxing'){for(const side of ['R','L'])if(this.startPunch(side,true)){this.empower(this.attacks[side]);this.specialCd=.9;return true;}return false;}
  if(!this.startKick(true))return false;this.empower(this.legAttack);this.specialCd=1.1;return true;
 }
 startKick(roundhouse=false){
  if(!this.alive||this.stun>.2||this.dashTime>0||this.kickCd>0||this.legAttack||this.attacks.L||this.attacks.R||this.grip)return false;
  if(!['thighL','thighR','shinL','shinR'].every(name=>this.parts[name].attached))return false;
  const cost=(roundhouse?27:19)*this.body.cost;if(this.stamina<cost)return false;
  if(this.chain>=3)this.chain=0;
  const finisher=this.chain>=2&&this.chainSide!=='K'&&this.sim.time-this.chainAt<1.25;
  const counter=this.counterTime>0;this.counterTime=0;this.stamina-=cost;
  const side=roundhouse?'R':'L',limb='shin'+side;
  this.legAttack={limb,side,chainKey:'K',roundhouse,finisher,counter,t:0,duration:roundhouse?.66:.56,wind:roundhouse?.20:.16,strikeEnd:roundhouse?.43:.34,heavy:roundhouse||finisher||counter,power:roundhouse?1:.8,upper:false,kick:true,hit:false,hitAt:null,peakSpeed:0,prev:this.handPoint(limb),kind:finisher?'COMBO + CHUTE':roundhouse?'CIRCULAR':'CHUTE FRONTAL'};
  const a=this.legAttack;a.tempo=this.body.kickTime;a.legBias=(this.config.legs-100)/100;a.duration*=a.tempo;a.wind*=a.tempo;a.strikeEnd*=a.tempo;if(!roundhouse&&!finisher)a.kind=a.legBias>.04?'CHUTE DE DISTÂNCIA':a.legBias<-.04?'CHUTE COMPACTO':a.kind;
  this.kickCd=(roundhouse?.94:.74)*a.tempo;
  this.sim.events.push({type:'swing',fighter:this.id,side,kind:this.legAttack.kind,kick:true});return true;
 }

 armInput(side,down,tap,noTap,dt){
  const a=this.arms[side];a.cooldown=Math.max(0,a.cooldown-dt);
  a.buffer=Math.max(0,a.buffer-dt);
  if(this.stun>.2||!this.parts['hand'+side].attached){a.down=down;a.held=GRAB_DELAY;a.holding=false;a.buffer=0;this.release(side);return;}
  if(down){
   if(!a.down)a.buffer=0;
   a.held=a.down?a.held+dt:dt;a.holding=a.held>=GRAB_DELAY;
  }else{
   const requested=!noTap&&(tap||(a.down&&!a.holding&&a.held<GRAB_DELAY));
   if(noTap)a.buffer=0;
   else if(requested&&a.cooldown<=.12)a.buffer=.135;
   a.held=0;a.holding=false;this.release(side);
   if(a.buffer>0&&this.startPunch(side))a.buffer=0;
  }
  a.down=down;
 }
 updateGrips(enemy,dt){
  for(const side of ['L','R']){let grip=this.grips[side];const hand='hand'+side,wants=this.arms[side].holding&&this.parts[hand].attached;
   if(grip){grip.elapsed+=dt;if(!wants||this.stamina<4||this.stun>.1||!enemy.alive||this.root.position.distanceTo(enemy.root.position)>2.0*this.body.reach){this.release(side);continue;}enemy.balance=Math.max(0,enemy.balance-dt*(this.sim.style==='judo'?9:4));if(enemy.input.block&&enemy.stamina>10&&grip.elapsed>1.3){this.release(side);enemy.stamina-=8;}continue;}
   if(!wants||enemy.grabImmunity>0||this.stamina<12||this.attacks[side]||this.stun>.1||this.root.position.distanceTo(enemy.root.position)>1.6*this.body.reach)continue;
   const point=this.handPoint(hand),body=enemy.parts.torso.body;if(point.distanceTo(body.position)>.98*this.body.reach)continue;const pivot=body.pointToLocalFrame(point),size=enemy.parts.torso.spec.size;pivot.x=clamp(pivot.x,-size[0],size[0]);pivot.y=clamp(pivot.y,-size[1],size[1]);pivot.z=clamp(pivot.z,-size[2],size[2]);
   if(point.distanceTo(body.pointToWorldFrame(pivot))>.55)continue;
   const constraint=new C.PointToPointConstraint(this.parts[hand].body,this.limbPoint(hand),body,pivot,styleGrab(this.sim.style)*.72*this.body.grip);constraint.collideConnected=false;this.sim.world.addConstraint(constraint);this.grips[side]={constraint,enemy,hand,elapsed:0};this.stamina-=4;this.sim.events.push({type:'grab',fighter:this.id,side,position:point});
  }
 }
 update(input,enemy,dt){
  input={...ZERO(),...input};input.x=Number.isFinite(input.x)?clamp(input.x,-1,1):0;input.z=Number.isFinite(input.z)?clamp(input.z,-1,1):0;this.input=input;this.cooldown=Math.max(0,this.cooldown-dt);this.specialCd=Math.max(0,this.specialCd-dt);this.stun=Math.max(0,this.stun-dt);this.recoil=Math.max(0,this.recoil-dt);if(!this.alive){this.release();return;}
  for(const key of ['dashCd','dashTime','dodgeTime','parryTime','parryCd','counterTime','grabImmunity','guardOpen','fallGrace','jabYield','kickCd'])this[key]=Math.max(0,this[key]-dt);
  for(const side of ['L','R'])this.armFlinch[side]=Math.max(0,this.armFlinch[side]-dt);
  if(this.sim.time-this.chainAt>1.25)this.chain=0;
  if(input.dash&&!this.wasDash)this.evade(input,enemy);this.wasDash=!!input.dash;
  const r=this.root,desired=Math.atan2(enemy.root.position.x-r.position.x,enemy.root.position.z-r.position.z);this.yaw+=Math.atan2(Math.sin(desired-this.yaw),Math.cos(desired-this.yaw))*Math.min(1,dt*22);
  for(const side of ['L','R'])this.armInput(side,!!input['arm'+side],!!input['tap'+side],!!input['noTap'+side],dt);
  if(input.special&&!this.wasSpecial)this.special();this.wasSpecial=input.special;
  if(input.kick&&!this.wasKick)this.startKick();this.wasKick=!!input.kick;
  const freeArms=['L','R'].filter(side=>this.parts['hand'+side].attached&&!this.grips[side]&&!this.attacks[side]).length;
  const guard=input.block&&!this.legAttack&&this.guardOpen<=0&&freeArms>0&&this.stamina>5&&this.stun<.2&&this.dashTime<=0;this.blocking=guard;
  if(guard&&!this.wasBlock&&this.parryCd<=0){this.parryTime=.14;this.parryCd=.65;}this.wasBlock=!!input.block;
  if(!guard)this.parryTime=0;
  const grips=Number(!!this.grips.L)+Number(!!this.grips.R);this.stamina=clamp(this.stamina+dt*(grips?-7*grips:guard?7:this.attack?5:22*this.body.recovery),0,100);this.balance=clamp(this.balance+dt*(guard?23:16),0,100);this.updateGrips(enemy,dt);
  for(const attack of this.activeAttacks()){
   attack.t+=dt;if(attack.t>attack.duration){if(attack.kick)this.legAttack=null;else this.attacks[attack.side]=null;continue;}
   const source=this.parts[attack.limb].body;source.getVelocityAtWorldPoint(this.handPoint(attack.limb),attack.velocity||(attack.velocity=V()));
   if(attack.kick&&attack.t<=attack.wind){
    const strength=Math.sin(Math.PI*attack.t/attack.wind),draw=V(-Math.sin(this.yaw)*70*strength,230*strength,-Math.cos(this.yaw)*70*strength);
    source.force.vadd(draw,source.force);this.root.force.vsub(draw,this.root.force);
   }
   if(!attack.kick&&attack.t<=attack.wind){
    const sign=attack.side==='L'?-1:1;
    const strength=Math.sin(Math.PI*attack.t/attack.wind);
    const lateral=sign*125*strength,back=-100*strength;
    const draw=V(Math.cos(this.yaw)*lateral+Math.sin(this.yaw)*back,190*strength,-Math.sin(this.yaw)*lateral+Math.cos(this.yaw)*back);
    source.force.vadd(draw,source.force);this.parts.torso.body.force.vsub(draw,this.parts.torso.body.force);
   }
   if(attack.t>attack.wind&&!attack.hit&&attack.t<attack.strikeEnd){const fraction=(attack.t-attack.wind)/(attack.strikeEnd-attack.wind);const force=(attack.kick?440:attack.upper?355:attack.heavy?400:360)*Math.sin(Math.PI*fraction)*this.body.mass;const glove=this.handPoint(attack.limb),target=enemy.parts.torso.body;
    const leadX=target.position.x+target.velocity.x*.055-glove.x;
    const leadZ=target.position.z+target.velocity.z*.055-glove.z;
    const aim=Math.atan2(leadX,leadZ),error=Math.atan2(Math.sin(aim-this.yaw),Math.cos(aim-this.yaw));
    const heading=this.yaw+clamp(error,-.52,.52);
    const vertical=attack.upper?.58:clamp((target.position.y-glove.y)*.8,-.32,.32);
    const push=V(Math.sin(heading)*force,vertical*force,Math.cos(heading)*force);source.force.vadd(push,source.force);this.parts.torso.body.force.vsub(push,this.parts.torso.body.force);}
  }
  const grounded=Math.abs(r.position.x)<5.1&&Math.abs(r.position.z)<4.1&&r.position.y<this.body.standHeight+.62*this.body.h,active=this.stun>.3?0:this.legs===0?.15:1-this.stun/.3;
  const move=Math.hypot(input.x,input.z);
  const forward=input.x*Math.sin(this.yaw)+input.z*Math.cos(this.yaw);
  const lateral=input.x*Math.cos(this.yaw)-input.z*Math.sin(this.yaw);
  // A sideways shuffle and a backward step are shorter than a forward stride.
  const stride=1-.10*Math.abs(lateral)-.16*Math.max(0,-forward);
  const maxSpeed=styleSpeed(this.sim.style)*this.body.mobility*stride*(guard?.65:this.grip?.55:1)*(this.legs===1?.55:1)*(this.legAttack?.48:this.attack?.95:1);
  this.phase+=dt*Math.min(12,Math.hypot(r.velocity.x,r.velocity.z)*3.15);
  if(active>.01&&grounded)this.driveGround(input,enemy,active,maxSpeed);
  else this.plant=null;
  if(active>.01){let twist=0;for(const a of [this.attacks.L,this.attacks.R])if(a){const p=punchPose(a);twist+=p.twist;}
   if(this.legAttack)twist+=kickPose(this.legAttack).twist;
   const brace=this.recoil>0?.45:1;this.torque('pelvis',0,0,340,18,active,twist*.35);this.torque('torso',this.dashTime>0?.12:guard?-.05:0,0,640,24,active*brace,twist);this.torque('head',0,0,120,6,active*(this.recoil>0?.32:1));
   for(const side of ['L','R']){const sign=side==='L'?-1:1,walk=Math.sin(this.phase+(side==='L'?0:Math.PI))*Math.min(move,1)*.62;
    let wrist=-sign*.12;
    let arm=guard?-1.05:-.90,hand=guard?-2.65:-2.45,rz=-sign*.20,thigh=-walk*forward,shin=Math.max(0,walk)*.8;
    if(this.arms[side].holding||this.grips[side]){arm=-1.23;hand=-1.55;rz=-sign*.30;}
    const attack=this.attacks[side];if(attack){const pose=punchPose(attack);arm=pose.arm;hand=pose.hand;rz=pose.rz;wrist=pose.wrist;}
    const kicking=this.legAttack?.side===side;let legRoll=sign*.025+walk*lateral;
    if(kicking){const pose=kickPose(this.legAttack);thigh=pose.thigh;shin=pose.shin;legRoll=pose.roll;}
    const armSupport=active*(this.armFlinch[side]>0?.36:1);
    this.torque('arm'+side,arm,rz,attack?235:75,4.5,armSupport);this.torque('hand'+side,hand,wrist,attack?165:65,3.5,armSupport);this.torque('thigh'+side,thigh,legRoll,kicking?245:95,7,active);this.torque('shin'+side,shin,kicking?legRoll*.6:walk*lateral*.5,kicking?175:53,4,active);
   }
  }
 }

}
export function punchPose(a){
 const tempo=a.tempo||1;a={...a,t:a.t/tempo,wind:a.wind/tempo,strikeEnd:a.strikeEnd/tempo};
 const side=a.side==='L'?-1:1;
 const smooth=x=>{x=clamp(x,0,1);return x*x*(3-2*x);};
 const prep=smooth(a.t/a.wind);
 const fire=smooth((a.t-a.wind)/.078);
 const back=smooth((a.t-a.strikeEnd)/.105);
 const load=prep*(1-fire);
 const extension=fire*(1-back);
 // Wind up outside the opponent's silhouette, then bring the elbow in behind the fist.
 // Early contact stops the strike force; the arm still completes one visible follow-through.
 return {
  arm:-.90+load*.30-extension*(a.upper?1.30:.76),
  hand:-2.45-load*.80+extension*(a.upper?.16:a.hook?.48:a.profile==='reach'?1.02:.91),
  rz:side*(-.20+load*1.18-extension*.20+(a.hook?extension*.85:0)),
  wrist:side*(-.12+load*.65-extension*.10),
  twist:side*(load*.32-extension*(a.hook?.66:a.side==='R'?.44:.25))
 };

}
export function kickPose(a){
 const tempo=a.tempo||1;a={...a,t:a.t/tempo,wind:a.wind/tempo,strikeEnd:a.strikeEnd/tempo};
 const smooth=x=>{x=clamp(x,0,1);return x*x*(3-2*x);};
 const lift=smooth(a.t/a.wind),fire=smooth((a.t-a.wind)/.11),back=smooth((a.t-a.strikeEnd)/.18);
 const chamber=lift*(1-fire)*(1-back),extension=fire*(1-back),sign=a.side==='L'?-1:1;
 return {thigh:-1.65*chamber-(1.52+(a.legBias||0)*.8)*extension,shin:.65*chamber-(1.48+(a.legBias||0)*.7)*extension,
  roll:a.roundhouse?sign*(.8*chamber+.30*extension):sign*.04,
  twist:a.roundhouse?sign*(.32*chamber-.45*extension):-.08*extension};
}
function styleGrab(style){return STYLES[style].grab;}
function styleSpeed(style){return STYLES[style].speed;}
function segmentDistance(p,a,b){const ab=b.vsub(a),den=ab.lengthSquared();const t=den>0?clamp(p.vsub(a).dot(ab)/den,0,1):0;return p.distanceTo(a.vadd(ab.scale(t)));}
// Sweep the glove against the target's oriented collision shapes, including its glove.
// Center-only hit spheres miss the ends of forearms and turn real contacts into shoves.
function sweepsPart(part,start,end,radius=.185){
 const b=part.body,from=b.pointToLocalFrame(start),to=b.pointToLocalFrame(end);
 for(let i=0;i<b.shapes.length;i++){const shape=b.shapes[i],q=b.shapeOrientations[i].conjugate(),a=q.vmult(from.vsub(b.shapeOffsets[i])),z=q.vmult(to.vsub(b.shapeOffsets[i]));
  if(shape instanceof C.Sphere){if(segmentDistance(V(),a,z)<=shape.radius+radius)return true;continue;}
  if(!(shape instanceof C.Box))continue;let near=0,far=1;const d=z.vsub(a);
  for(const axis of ['x','y','z']){const half=shape.halfExtents[axis]+radius;if(Math.abs(d[axis])<1e-8){if(Math.abs(a[axis])>half){far=-1;break;}}else{let t0=(-half-a[axis])/d[axis],t1=(half-a[axis])/d[axis];if(t0>t1)[t0,t1]=[t1,t0];near=Math.max(near,t0);far=Math.min(far,t1);if(near>far)break;}}
  if(near<=far)return true;
 }return false;
}

export class ArenaPhysics{
 constructor({style='boxing',breakable=true,difficulty='normal',hazards=false,personality='pressure',characters=[]}={}){this.characters=characters;this.hazards=hazards;this.personality=personality;this.matchTime=0;this.hazard=hazardState(0,hazards);this.style=style;this.breakable=breakable;this.difficulty=difficulty;this.events=[];this.netStretch=[0,0,0,0];this.netHit=[0,0,0,0];this.netPoint=[0,0,0,0];this.netCooldown=[0,0,0,0];this.time=0;this.world=new C.World({gravity:V(0,-20.2,0),allowSleep:false});this.world.broadphase=new C.SAPBroadphase(this.world);this.world.solver.iterations=10;this.world.solver.tolerance=.0001;this.dollMaterial=new C.Material('doll');this.floorMaterial=new C.Material('floor');this.world.addContactMaterial(new C.ContactMaterial(this.dollMaterial,this.floorMaterial,{friction:.55,restitution:.04,contactEquationStiffness:1e7,contactEquationRelaxation:4}));this.world.addContactMaterial(new C.ContactMaterial(this.dollMaterial,this.dollMaterial,{friction:.2,restitution:.05,contactEquationStiffness:1e6,contactEquationRelaxation:5}));this.floor=new C.Body({mass:0,shape:new C.Box(V(5.2,.3,4.2)),position:V(0,-.3,0),material:this.floorMaterial,collisionFilterGroup:1});this.world.addBody(this.floor);
  // Original apron remains intact. Four taller invisible end-stops stop fighters falling
  // beyond the elastic mesh; spring forces absorb the blow *before* hitting the stops.
  this.netMaterial=new C.Material('elastic-net');
  this.world.addContactMaterial(new C.ContactMaterial(this.dollMaterial,this.netMaterial,{friction:.15,restitution:.42,contactEquationStiffness:1.3e6,contactEquationRelaxation:4}));
  for(const [x,z,sx,sz] of [[-5.02,0,.11,4.08],[5.02,0,.11,4.08],[0,-4.02,5.08,.11],[0,4.02,5.08,.11]]){const b=new C.Body({mass:0,shape:new C.Box(V(sx,1.6,sz)),position:V(x,1.55,z),material:this.netMaterial,collisionFilterGroup:1});this.world.addBody(b);}
  this.fighters=[new Fighter(this,0,-1.35,0,Math.PI/2),new Fighter(this,1,1.35,0,-Math.PI/2)];this.aiClock=0;this.aiIndex=0;
 }
 ai(id=1){
  const f=this.fighters[id],e=this.fighters[1-id],p=f.root.position,q=e.root.position,dx=q.x-p.x,dz=q.z-p.z,d=Math.hypot(dx,dz)||1,hard=this.difficulty==='normal',input=ZERO(),range=(this.style==='judo'?.88:1.02)*f.body.reach;
  const circle=Math.sin(this.time*.95+id*2)>.1?1:-1;
  if(d>range){input.x=dx/d*.9;input.z=dz/d*.9;}else if(d<.72){input.x=-dx/d*.4;input.z=-dz/d*.4;}else if(hard&&!f.grip){input.x=-dz/d*.38*circle;input.z=dx/d*.38*circle;}
  if(f.stamina<24&&!f.grip){input.x=-dx/d*.7;input.z=-dz/d*.7;input.block=true;}
  if(Math.abs(p.x)>4.35)input.x=-Math.sign(p.x);if(Math.abs(p.z)>3.35)input.z=-Math.sign(p.z);
  if(e.attack&&!f.sawAttack){f.reactAt=this.time+(hard?.14:.32);f.sawAttack=true;}if(!e.attack)f.sawAttack=false;
  const react=e.attack&&this.time>=f.reactAt&&d<1.6;
  if(react&&hard){if(this.personality==='counter'&&Math.sin(this.time*2)>.2&&f.dashCd<=0){input.dash=true;input.x=-dz/d*circle;input.z=dx/d*circle;}else input.block=true;}
  f.aiTimer-=DT;if(f.aiTimer<=0&&d<1.7*f.body.reach&&f.stun<.1&&f.stamina>14){f.aiTimer=f.chain>0?.28:hard?.4+(Math.sin(this.time*2.1)+1)*.16:.85+(Math.sin(this.time)+1)*.35;f.aiSide=f.aiSide==='L'?'R':'L';f.aiPulse=.06;}
  if(f.aiPulse>0){input['arm'+f.aiSide]=true;f.aiPulse-=DT;}
  const wrestle=this.style==='judo'||(this.personality==='grappler'&&Math.sin(this.time*.6)>.2);
  if(wrestle&&d<1.4){input.armL=true;if(this.style==='judo')input.armR=true;if(f.gripTime>.38&&this.style!=='boxing')input.special=true;}
  else if(hard&&d<1.35&&(f.hype>=100||f.counterTime>.2||Math.sin(this.time*1.3)>.94))input.special=true;
  if(e.grip?.enemy===f&&f.dashCd<=0&&f.stamina>30&&e.grip.elapsed>.28&&Math.sin(this.time*1.7+id*1.2)>.3)input.dash=true;
  if(hard&&d>1.35&&d<2.15*f.body.kickReach&&f.kickCd<=0&&!f.grip&&f.stamina>35&&Math.sin(this.time*1.8+id)>.5){input.kick=true;input.armL=input.armR=false;}
  if(f.stun>.25){input.armL=input.armR=input.special=input.kick=false;if(hard&&f.stamina>35)input.dash=true;}
  if(inHazard(this.hazard,p,.35)){const axis=this.hazard.axis;input.x=input.z=0;input[axis]=p[axis]>=this.hazard.center?1:-1;input.armL=input.armR=input.special=input.kick=input.block=false;if(this.hazard.seconds<.5&&hard)input.dash=true;}
  return input;
 }

 hit(attacker,target,part,a,point,closing){
  if(a.hit||!target.alive)return;a.hit=true;a.hitAt=a.t;
  const delta=attacker.root.position.vsub(target.root.position);delta.y=0;delta.normalize();const frontal=target.blocking&&target.stamina>8&&delta.dot(V(Math.sin(target.yaw),0,Math.cos(target.yaw)))>.25;
  if(target.dodgeTime>0){target.stats.dodges++;target.gainHype(12);this.events.push({type:'dodge',fighter:target.id,position:point.clone()});return;}
  if(frontal&&target.parryTime>0){target.parryTime=0;target.counterTime=.85;target.stats.parries++;target.gainHype(25);target.stamina=Math.min(100,target.stamina+10);attacker.chain=0;attacker.stun=Math.max(attacker.stun,.28);attacker.recoil=.2;attacker.attacks.L=attacker.attacks.R=attacker.legAttack=null;this.events.push({type:'parry',fighter:target.id,position:point.clone()});return;}
  const punish=!!(target.legAttack&&!target.legAttack.hit&&target.legAttack.t>target.legAttack.strikeEnd+.06);
  const speedFactor=clamp(closing/3.5,.72,1.35),boost=(a.turbo?1.6:a.finisher?1.3:a.counter?1.25:1)*(punish?1.2:1);
  const chainKey=a.chainKey||a.side;
  if(!frontal){attacker.chain=(attacker.chain>0&&this.time-attacker.chainAt<1.25&&attacker.chainSide!==chainKey)?Math.min(3,attacker.chain+1):1;attacker.chainAt=this.time;attacker.chainSide=chainKey;attacker.stats.bestCombo=Math.max(attacker.stats.bestCombo,attacker.chain);attacker.stats.hits++;attacker.gainHype(a.turbo?0:16);target.gainHype(9);target.chain=0;}else{attacker.chain=0;target.gainHype(5);}

  const arm=/^(arm|hand)/.test(part.name);
  const head=part.name==='head';
  const strikeDamage=(a.kick?(a.roundhouse?22:16):a.upper?18:a.heavy?14:a.side==='R'?12:10)*STYLES[this.style].power*speedFactor*boost*.7*(a.kick?attacker.body.kick:attacker.body.punch);
  let damage=strikeDamage*(head?1.2:arm?.45:1);
  if(frontal){
   damage*=.22;target.stamina=Math.max(0,target.stamina-(a.heavy?25:13));
   if(target.stamina<5){
    target.guardOpen=.5;target.blocking=false;target.parryTime=0;
    this.events.push({type:'guardbreak',fighter:attacker.id,position:point.clone()});
   }
  }
  target.hp=Math.max(0,target.hp-damage);
  const balanceLoss=frontal?3:arm?4:(a.finisher||a.turbo?43:a.heavy?25:15)*(head?1.16:1);
  target.balance=Math.max(0,target.balance-balanceLoss*speedFactor/target.body.stability);
  target.lastHit=this.time;attacker.hitCount++;
  if(arm)target.armFlinch[part.name.at(-1)]=frontal?.06:.12;
  else target.recoil=frontal?.05:head?.16:.11;

  const forward=V(Math.sin(attacker.yaw),0,Math.cos(attacker.yaw));
  const baseImpulse=a.kick?19:a.upper?22:a.heavy?19:15;
  const force=baseImpulse*speedFactor*boost*(frontal?.4:1)*(a.kick?attacker.body.kick:attacker.body.punch);
  const impulse=V(forward.x*force,a.upper?force*.48:a.kick?2:1,forward.z*force);
  part.body.applyImpulse(impulse,point.vsub(part.body.position));
  // A clean lead jab makes room on contact. Guard, dodges and grips keep their own rules.
  if(!frontal&&!a.upper&&(a.kick&&!a.roundhouse||!a.kick&&a.side==='L')&&!attacker.grip&&!target.grip){
   const speed=target.root.velocity.dot(forward);
   const give=clamp((a.kick?(arm?1.45:2.3):arm?1.05:1.75)*speedFactor*(a.kick?attacker.body.kick:attacker.body.punch)/target.body.mass**.35-speed,0,a.kick?2.4:1.85);
   if(give>0){
    for(const bodyPart of Object.values(target.parts))if(bodyPart.attached){
     bodyPart.body.applyImpulse(forward.scale(give*bodyPart.body.mass));
    }
    target.jabYield=a.kick?.20:.13;
   }
  }
  if(target.hp<=0)target.knock(99);
  else if(!arm&&!frontal&&target.balance<12&&target.stun<=0&&target.fallGrace<=0){
   const duration=a.heavy?.62:.42;
   target.knock(duration);target.fallGrace=duration+.70;
  }
  if(this.breakable&&!frontal&&!['head','torso','pelvis'].includes(part.name)){
   part.integrity-=strikeDamage*(a.heavy?1.65:.40);
   if(part.integrity<=0&&a.heavy&&speedFactor>.85)target.detach(part.name);
  }
  this.events.push({type:frontal?'block':'hit',fighter:attacker.id,target:target.id,side:a.side,part:part.name,kind:a.kind,power:clamp(speedFactor*(a.heavy?1.15:.85),.35,1.5),direction:forward,closingSpeed:closing,damage,combo:attacker.chain,finisher:!!a.finisher,turbo:!!a.turbo,counter:!!a.counter,punish,kick:!!a.kick,position:point.clone()});
 }
 applyNetForce(){
  const bounds=[4.83,4.83,3.83,3.83],axes=['x','x','z','z'],signs=[-1,1,-1,1];
  for(let i=0;i<4;i++){this.netStretch[i]*=.86;this.netHit[i]*=.91;this.netCooldown[i]=Math.max(0,this.netCooldown[i]-DT);}
  for(const f of this.fighters)for(const p of Object.values(f.parts)){const b=p.body;if(b.mass<=0||b.position.y<.16||b.position.y>3.35)continue;
   for(let i=0;i<4;i++){const ax=axes[i],side=signs[i],out=side*b.position[ax],depth=out-(bounds[i]-.35);if(depth<=0)continue;
    const outward=Math.max(0,side*b.velocity[ax]),force=Math.max(0,depth*92+outward*17);b.force[ax]-=side*force*b.mass;
    const strength=clamp(depth*.95+outward*.095,0,1);if(strength>this.netStretch[i]){this.netStretch[i]=strength;this.netPoint[i]=ax==='x'?b.position.z:b.position.x;}
    if(strength>.25&&outward>1&&this.netCooldown[i]===0){this.events.push({type:'net',fighter:f.id,side:i,power:strength,position:b.position.clone()});this.netHit[i]=1;this.netCooldown[i]=.42;}
   }
  }
 }
 step(inputs=[ZERO(),ZERO()],combat=true){this.time+=DT;if(combat)this.matchTime+=DT;this.hazard=hazardState(this.matchTime,this.hazards&&combat);for(let i=0;i<2;i++)this.fighters[i].update(inputs[i]||ZERO(),this.fighters[1-i],DT);this.applyNetForce();this.world.step(DT);
  for(const f of this.fighters){const target=this.fighters[1-f.id];for(const a of f.activeAttacks()){
   const point=f.handPoint(a.limb),travel=point.vsub(a.prev).scale(1/DT),forward=V(Math.sin(f.yaw),0,Math.cos(f.yaw));
   const closing=Math.max(0,travel.vsub(target.parts.torso.body.velocity).dot(forward),a.velocity?a.velocity.vsub(target.parts.torso.body.velocity).dot(forward):0);if(a.t>a.wind)a.peakSpeed=Math.max(a.peakSpeed,closing);
   if(!a.hit&&a.t>a.wind+.033&&a.t<a.strikeEnd+.06){let closest=null,dist=Infinity;for(const part of Object.values(target.parts)){if(!part.attached)continue;const d=segmentDistance(part.body.position,a.prev,point);if(d<dist&&sweepsPart(part,a.prev,point,(a.kick?.25:.27)*Math.max(...f.scales[a.limb]))){closest=part;dist=d;}}if(closest&&a.peakSpeed>.20)this.hit(f,target,closest,a,point,Math.max(closing,a.peakSpeed*.65));}
   a.prev=point;
  }if(f.root.position.y< -3){f.hp=0;f.release();}}
  if(this.hazard.active)for(const f of this.fighters){if(f.alive&&f.hazardHit!==this.hazard.cycle&&inHazard(this.hazard,f.root.position)){f.hazardHit=this.hazard.cycle;f.hp=Math.max(0,f.hp-7);f.knock(.65);const push=V(0,9,0);push[this.hazard.axis]=(f.root.position[this.hazard.axis]>=this.hazard.center?1:-1)*10;f.root.applyImpulse(push);this.events.push({type:'hazard',fighter:f.id,position:f.root.position.clone()});}}
  // Apply safety caps after BOTH fighters have delivered their impacts.
  for(const f of this.fighters){   for(const p of Object.values(f.parts)){const b=p.body;const speed=b.velocity.length();if(speed>13)b.velocity.scale(13/speed,b.velocity);const spin=b.angularVelocity.length();if(spin>20)b.angularVelocity.scale(20/spin,b.angularVelocity);}}
 }
 drainEvents(){const e=this.events;this.events=[];return e;}
 dispose(){for(const f of this.fighters)f.release();}
}
