import {BODY_FIELDS,LOOKS,DEFAULT_CHARACTER,PRESETS,sanitizeCharacter,bodyMetrics,weightLimits} from './character.js?v=13';
export function loadRoster(storage=localStorage){
 try{const saved=JSON.parse(storage.getItem('knockout-dolls-characters')||'null');if(Array.isArray(saved)&&saved.length===2)return saved.map((v,i)=>sanitizeCharacter({...v,name:v?.name||(i===0?'CAMPEÃO':'RIVAL')}));}catch{}
 return [sanitizeCharacter({name:'CAMPEÃO'}),sanitizeCharacter({name:'RIVAL',cloth:'#ef8a70',gloves:'#c34d40',skin:'#ad8766'})];
}
export function saveRoster(roster,storage=localStorage){try{storage.setItem('knockout-dolls-characters',JSON.stringify(roster.map(sanitizeCharacter)));return true;}catch{return false;}}
const pct=n=>Math.round(n*100)+'%';
export class CharacterEditor{
 constructor(root,callbacks){
  this.root=root;this.callbacks=callbacks;this.index=0;this.angle=.28;this.pending=null;this.padButtons=[];this.padAt=0;
  root.innerHTML=`<aside class="atelier-panel"><header><span class="eyebrow">KNOCKOUT DOLLS / ATELIÊ</span><button data-close aria-label="Fechar editor">×</button><h2>SEU CORPO.<br><em>SEU ESTILO.</em></h2><p>A aparência muda. A luta também.</p></header>
   <div class="editor-fighters"><button data-fighter="0">JOGADOR 1</button><button data-fighter="1">P2 / RIVAL IA</button></div><label class="kd-name-field">NOME DO LUTADOR<input id="fighterName" type="text" maxlength="18" placeholder="NOME" autocomplete="off" spellcheck="false"></label>
   <div class="editor-tabs" role="tablist"><button data-tab="body" role="tab">CORPO</button><button data-tab="look" role="tab">APARÊNCIA</button><button data-tab="combat" role="tab">COMBATE</button></div>
   <section data-page="body"><p class="editor-intro">Comece por um perfil e ajuste. Todos têm vantagens e desvantagens.</p><div class="body-presets">${Object.entries(PRESETS).map(([key,p])=>`<button data-preset="${key}">${p.label}</button>`).join('')}</div>
   <div class="body-sliders">${BODY_FIELDS.map(([key,label,min,max,step,unit])=>`<label><span>${label}<output id="value-${key}" for="body-${key}"></output></span><input id="body-${key}" data-body="${key}" type="range" min="${min}" max="${max}" step="${step}" aria-label="${label}"><small>${key==='height'?'A altura total inclui a proporção das pernas.':key==='weight'?'Limites de peso acompanham a altura.':key==='arms'?'Mais alcance exige abrir mão de impacto.':key==='legs'?'Muda o alcance e a trajetória do chute.':key==='muscle'?'Mais impacto e gasto de fôlego.':key==='shoulders'?'Muda a silhueta, o alcance e a força do agarrão.':'Base mais larga ganha equilíbrio e perde mobilidade.'}</small></label>`).join('')}</div><p id="bodyAdjustment" role="status"></p><button data-reset class="editor-subtle">RESTAURAR CORPO EQUILIBRADO</button></section>
   <section data-page="look" hidden><p class="editor-intro">Estilo livre. Cabelo, roupas e acessórios não dão bônus.</p><div class="look-selects">${Object.entries(LOOKS).map(([key,choices])=>`<label>${({hair:'Cabelo',face:'Rosto',outfit:'Parte superior',accessory:'Acessório',beard:'Barba',bottom:'Parte inferior'})[key]}<select data-look="${key}">${choices.map((label,i)=>`<option value="${i}">${label}</option>`).join('')}</select></label>`).join('')}</div><div class="editor-colors">${Object.entries({skin:'Tom de pele',hairColor:'Cabelo / barba',cloth:'Roupa',trim:'Acabamentos',gloves:'Luvas'}).map(([key,label])=>`<label><input type="color" data-color="${key}" aria-label="${label}"><span>${label}</span></label>`).join('')}</div></section>
   <section data-page="combat" hidden><p class="editor-intro">Comparação com o corpo equilibrado. 100% é a referência. O alcance final depende da postura e da distância.</p><div id="editorStats"></div><div class="editor-rules"><h3>O QUE MUDA NA LUTA</h3><p>Braços longos alcançam mais e batem com menos impacto. Braços curtos usam um gancho fechado no braço direito.</p><p>Mais peso aumenta impacto e firmeza no agarrão, mas reduz mobilidade e recuperação. Mais músculo aumenta potência e consumo de fôlego.</p><p>Pernas longas estendem mais o chute e levam mais tempo para recolher. Corpos compactos usam uma trajetória mais fechada.</p><p>A massa, as colisões e as juntas acompanham as medidas. São regras de equilíbrio do jogo, não uma avaliação real da capacidade física de uma pessoa.</p></div></section>
   <footer><p id="editorApplyNote"></p><button data-apply class="start">SALVAR LUTADORES <span>↗</span></button><button data-close class="editor-subtle">CANCELAR ALTERAÇÕES</button></footer></aside>
   <div class="atelier-preview"><div class="preview-title"><span>PRÉVIA 3D</span><strong id="editorBuildName"></strong><p id="editorDimensions"></p></div><div class="preview-tools"><div><button data-test="punch">TESTAR SOCO</button><button data-test="kick">TESTAR CHUTE</button></div><label>GIRAR PERSONAGEM<input type="range" id="editorTurn" min="-180" max="180" value="16" aria-label="Girar prévia do personagem"></label><p>F / X continuam sendo chute na luta.<br>Controle no editor · direcional navega · A seleciona · B cancela</p></div></div>`;
  this.$$=q=>[...root.querySelectorAll(q)];this.$=q=>root.querySelector(q);
  this.$$('[data-fighter]').forEach(b=>b.onclick=()=>{this.index=Number(b.dataset.fighter);this.refresh();this.preview(true);});
  this.$$('[data-tab]').forEach(b=>b.onclick=()=>this.tab(b.dataset.tab));
  this.$('#fighterName').oninput=e=>{this.drafts[this.index].name=String(e.target.value).slice(0,18);this.$('#editorBuildName').textContent=this.drafts[this.index].name.toUpperCase();};
  this.$$('[data-body]').forEach(input=>input.oninput=()=>{const c=this.drafts[this.index],before=c.weight;c[input.dataset.body]=Number(input.value);this.drafts[this.index]=sanitizeCharacter(c);this.refresh();this.$('#bodyAdjustment').textContent=before!==this.drafts[this.index].weight&&input.dataset.body==='height'?'Peso ajustado para acompanhar a nova altura.':'';this.preview();});
  this.$$('[data-look],[data-color]').forEach(input=>input.oninput=()=>{const c=this.drafts[this.index];c[input.dataset.look||input.dataset.color]=input.dataset.look?Number(input.value):input.value;this.refresh();this.preview();});
  this.$$('[data-preset]').forEach(b=>b.onclick=()=>{this.setBody(PRESETS[b.dataset.preset].body);});
  this.$('[data-reset]').onclick=()=>this.setBody({});
  this.$$('[data-close]').forEach(b=>b.onclick=()=>this.cancel());
  this.$('[data-apply]').onclick=()=>{const result=this.drafts.map(sanitizeCharacter);this.hide();callbacks.apply(result);};
  this.$('#editorTurn').oninput=e=>{this.angle=Number(e.target.value)*Math.PI/180;callbacks.turn(this.angle);};
  this.$$('[data-test]').forEach(b=>b.onclick=()=>{this.preview(true);callbacks.test(b.dataset.test);});
 }
 setBody(body){const c=this.drafts[this.index];for(const [key] of BODY_FIELDS)c[key]=body[key]??DEFAULT_CHARACTER[key];this.drafts[this.index]=sanitizeCharacter(c);this.refresh();this.preview(true);}
 tab(name){this.$$('[data-page]').forEach(p=>p.hidden=p.dataset.page!==name);this.$$('[data-tab]').forEach(b=>{b.classList.toggle('selected',b.dataset.tab===name);b.setAttribute('aria-selected',String(b.dataset.tab===name));});}
 open(roster,restart=false){this.drafts=roster.map(sanitizeCharacter);this.index=0;this.root.hidden=false;this.padButtons=[];this.tab('body');this.$('[data-apply]').firstChild.textContent=restart?'SALVAR E REINICIAR DUELO ':'SALVAR LUTADORES ';this.$('#editorApplyNote').textContent=restart?'Para aplicar novas medidas com justiça, salvar inicia um duelo novo. Cancelar mantém a luta pausada.':'Os dois lutadores ficam salvos neste navegador, inclusive o rival da IA.';this.refresh();this.preview(true);this.$('[data-fighter="0"]').focus();}
 hide(){clearTimeout(this.pending);this.pending=null;this.root.hidden=true;}
 cancel(){this.hide();this.callbacks.cancel();}
 preview(now=false){clearTimeout(this.pending);if(now){this.callbacks.preview(this.drafts.map(sanitizeCharacter),this.index,this.angle);this.pending=null;}else this.pending=setTimeout(()=>this.preview(true),80);}
 refresh(){
  this.$('#fighterName').value=this.drafts[this.index].name;
  const c=this.drafts[this.index],m=bodyMetrics(c),[lo,hi]=weightLimits(c.height),weight=this.$('[data-body="weight"]');weight.min=lo;weight.max=hi;
  for(const [key,,min,max,step,unit] of BODY_FIELDS){this.$(`[data-body="${key}"]`).value=c[key];this.$('#value-'+key).textContent=Math.round(c[key])+' '+unit;}
  this.$$('[data-look]').forEach(el=>el.value=c[el.dataset.look]);this.$$('[data-color]').forEach(el=>el.value=c[el.dataset.color]);this.$$('[data-fighter]').forEach(b=>b.classList.toggle('selected',Number(b.dataset.fighter)===this.index));
  this.$('#editorBuildName').textContent=c.name.toUpperCase()+' · '+m.label;this.$('#editorDimensions').textContent=`${c.height} cm · ${c.weight} kg · alcance relativo ${pct(m.reach)}`;
  const rows=[['Alcance dos braços',m.reach],['Impacto do soco',m.punch],['Impacto do chute',m.kick],['Cadência dos socos',1/m.cadence],['Mobilidade',m.mobility],['Recuperação de fôlego',m.recovery],['Força do agarrão',m.grip],['Equilíbrio',m.stability],['Gasto de fôlego',m.cost]];
  this.$('#editorStats').innerHTML=rows.map(([label,value])=>`<div class="editor-stat"><span>${label}<b>${pct(value)}</b></span><div><i style="width:${Math.min(100,value/1.4*100)}%"></i><em></em></div></div>`).join('');
 }
 pollGamepad(now){
  const pad=Array.from(navigator.getGamepads?.()||[]).find(Boolean);if(!pad)return;const held=pad.buttons.map(b=>!!b.pressed),edge=i=>held[i]&&!this.padButtons[i];
  const focusables=this.$$('button,input,select').filter(el=>el.getClientRects().length&&!el.disabled),focused=document.activeElement;let index=focusables.indexOf(focused);
  if(edge(1)){this.padButtons=held;this.cancel();return;}
  if(now-this.padAt>140){
   if(held[12]||held[13]){index=(Math.max(0,index)+(held[13]?1:-1)+focusables.length)%focusables.length;focusables[index]?.focus();this.padAt=now;}
   else if(held[14]||held[15]){const dir=held[15]?1:-1;if(focused?.type==='range'){dir>0?focused.stepUp():focused.stepDown();focused.dispatchEvent(new Event('input'));}else if(focused?.tagName==='SELECT'){focused.selectedIndex=Math.max(0,Math.min(focused.options.length-1,focused.selectedIndex+dir));focused.dispatchEvent(new Event('input'));}this.padAt=now;}
  }
  if(edge(0)&&(focused?.tagName==='BUTTON'||focused?.type==='color'))focused.click();this.padButtons=held;
 }
}
