// Native Android gamepad compatibility bridge. No effect on ordinary web controls.
(()=>{
 const original=typeof navigator.getGamepads==='function'?navigator.getGamepads.bind(navigator):null;
 const pads=new Map();
 window.KD_ANDROID_GAMEPAD_UPDATE=(id,axes,values,connected)=>{
  if(!Number.isInteger(id)||id<0||id>15)return;
  if(!connected){pads.delete(id);return;}
  const buttons=Array.from({length:17},(_,i)=>({pressed:Number(values?.[i]||0)>.4,value:Math.max(0,Math.min(1,Number(values?.[i]||0)))}));
  pads.set(id,{id:'Android Bluetooth/USB Gamepad',index:id,connected:true,mapping:'standard',axes:Array.from({length:4},(_,i)=>Math.max(-1,Math.min(1,Number(axes?.[i]||0)))),buttons,timestamp:performance.now()});
 };
 try{
  Object.defineProperty(navigator,'getGamepads',{configurable:true,value:()=>{
   const web=original?Array.from(original()||[]).filter(Boolean):[];
   // Prefer the browser's native Gamepad API if the WebView already supports it.
   return web.length?web:Array.from(pads.values());
  }});
 }catch{ /* The game's touchscreen controls remain available. */ }
})();
