// Deterministic, telegraphed hazards; no extra rigid bodies or timers outside the fixed clock.
export function hazardState(time,enabled=true){
 if(!enabled||time<4)return {visible:false,active:false,cycle:-1,seconds:Math.max(0,4-time)};
 const elapsed=time-4,cycle=Math.floor(elapsed/7.5),phase=elapsed-cycle*7.5;
 return {visible:phase<2.55,active:phase>=2&&phase<2.55,cycle,axis:cycle%2?'z':'x',center:[0,-2.1,2.1][Math.floor(cycle/2)%3],half:.95,seconds:Math.max(0,2-phase)};
}
export function inHazard(h,p,margin=0){return h.visible&&Math.abs(p[h.axis]-h.center)<h.half+margin&&Math.abs(p.x)<5.2&&Math.abs(p.z)<4.2;}
