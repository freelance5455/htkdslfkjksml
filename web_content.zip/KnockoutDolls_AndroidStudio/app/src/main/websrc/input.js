// Standard Gamepad mapping: analog triggers, with hysteresis against noisy values.
export function readPadArms(pad,previous={}){
 const down=(index,was)=>{const b=pad.buttons[index];return !!b&&(b.pressed||b.value>(was?.12:.20));};
 return {armL:down(6,previous.armL),armR:down(7,previous.armR)};
}
export function releaseArm(queue,side,elapsed,cancelled,threshold=.22){
 if(cancelled||elapsed>=threshold){queue['noTap'+side]=true;queue['tap'+side]=false;}
 else if(!queue['noTap'+side])queue['tap'+side]=true;
}

// Track mouse buttons separately. Pointer events alone miss the second press of a chord.
export function desktopArms(surface, win, enabled, queue, grabDelay, clock=()=>performance.now()){
 const held=new Map();
 const sideFor=button=>button===0?'L':button===2?'R':null;
 function finish(side,cancelled=false){
  if(!held.has(side))return;
  const elapsed=(clock()-held.get(side))/1000;
  held.delete(side);
  if(enabled())releaseArm(queue(),side,elapsed,cancelled,grabDelay);
 }
 surface.addEventListener('mousedown',event=>{
  const side=sideFor(event.button);
  if(!side||!enabled())return;
  event.preventDefault();
  if(!held.has(side))held.set(side,clock());
 });
 win.addEventListener('mouseup',event=>finish(sideFor(event.button)));
 win.addEventListener('mousemove',event=>{
  if(!(event.buttons&1))finish('L',true);
  if(!(event.buttons&2))finish('R',true);
 });
 surface.addEventListener('contextmenu',event=>{if(enabled())event.preventDefault();});
 return {down:side=>held.has(side),reset:()=>held.clear()};
}

// Remap from the edge of the neutral zone so a small resting offset cannot walk the fighter.
export function movementStick(x=0,z=0){
 const length=Math.hypot(x,z);
 if(!Number.isFinite(length)||length<=.22)return {x:0,z:0};
 const gain=Math.min(1,(length-.22)/.78)/length;
 return {x:x*gain,z:z*gain};
}

export function readPadCombat(pad,previous={}){
 const pressed=i=>!!pad.buttons[i]?.pressed;
 return {...readPadArms(pad,previous),kick:pressed(2),special:pressed(3),dash:pressed(0),block:pressed(1)};
}
