// Lightweight online transport for the original Fight Night 05.
// The host owns Cannon physics, the guest sends inputs and renders snapshots.
const cap=(n,min,max)=>Math.min(max,Math.max(min,Number(n)||0));
export class OnlineClient {
  constructor(onMessage,onStatus){this.ws=null;this.onMessage=onMessage;this.onStatus=onStatus;this.active=false;}
  connect(address,command){
    this.close(); const url=new URL(address);if(!['ws:','wss:'].includes(url.protocol))throw Error('Use ws:// ou wss://');
    if(location.protocol==='https:'&&url.protocol==='ws:'&&url.hostname!=='localhost'&&url.hostname!=='127.0.0.1')throw Error('Em HTTPS, use wss://');
    const ws=new WebSocket(url);this.ws=ws;this.active=true;
    ws.onopen=()=>{this.onStatus('SERVIDOR CONECTADO');this.send(command);};
    ws.onmessage=e=>{try{const data=JSON.parse(e.data);if(data&&typeof data==='object')this.onMessage(data);}catch{}};
    ws.onerror=()=>this.onStatus('NÃO FOI POSSÍVEL CONECTAR AO SERVIDOR');
    ws.onclose=()=>{if(this.ws===ws){this.ws=null;if(this.active)this.onMessage({type:'closed'});}};
  }
  send(data){if(this.ws?.readyState===WebSocket.OPEN)this.ws.send(JSON.stringify(data));}
  close(){this.active=false;if(this.ws){const ws=this.ws;this.ws=null;ws.onclose=null;ws.close();}}
}
const vec=v=>[v.x,v.y,v.z].map(n=>Math.round(n*10000)/10000);
const quat=q=>[q.x,q.y,q.z,q.w].map(n=>Math.round(n*10000)/10000);
export function snapshot(sim,match){return {
  match, time:sim.time,matchTime:sim.matchTime,hazard:sim.hazard,
  netStretch:sim.netStretch,netPoint:sim.netPoint,netHit:sim.netHit,
  fighters:sim.fighters.map(f=>({hp:f.hp,stamina:f.stamina,balance:f.balance,stun:f.stun,
    yaw:f.yaw,blocking:f.blocking,hype:f.hype,chain:f.chain,dashCd:f.dashCd,dashTime:f.dashTime,
    kickCd:f.kickCd,guardOpen:f.guardOpen,counterTime:f.counterTime,dodgeTime:f.dodgeTime,
    recoil:f.recoil,stats:f.stats,parts:Object.fromEntries(Object.entries(f.parts).map(([name,p])=>[name,{p:vec(p.body.position),q:quat(p.body.quaternion),a:p.attached}]))}))
  };
}
export function applySnapshot(sim,s){
 if(!s||!Array.isArray(s.fighters)||s.fighters.length!==2)return;
 sim.time=cap(s.time,0,1e6);sim.matchTime=cap(s.matchTime,0,1e6);if(s.hazard)sim.hazard=s.hazard;
 for(const key of ['netStretch','netPoint','netHit'])if(Array.isArray(s[key])&&s[key].length===4)sim[key]=s[key].map(x=>cap(x,-10,10));
 for(let i=0;i<2;i++){
  const source=s.fighters[i],f=sim.fighters[i];if(!source||!source.parts)continue;
  for(const key of ['hp','stamina','balance','stun','yaw','hype','chain','dashCd','dashTime','kickCd','guardOpen','counterTime','dodgeTime','recoil'])if(Number.isFinite(source[key]))f[key]=source[key];
  f.blocking=!!source.blocking;
  if(source.stats&&typeof source.stats==='object')f.stats=source.stats;
  for(const [name,part] of Object.entries(f.parts)){
    const p=source.parts[name];if(!p||!Array.isArray(p.p)||p.p.length!==3||!Array.isArray(p.q)||p.q.length!==4)continue;
    const b=part.body;
    b.previousPosition.copy(b.position);
    b.previousQuaternion.copy(b.quaternion);
    b.position.set(...p.p.map(v=>cap(v,-50,50)));
    b.quaternion.set(...p.q.map(v=>cap(v,-1,1)));
    part.attached=!!p.a;
  }
 }
}
