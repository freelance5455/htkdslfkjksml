// Servidor HTTP + WebSocket das salas 1v1. O host da sala calcula a física.
import {createServer} from 'node:http';
import {readFile,stat} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {dirname,extname,resolve,sep} from 'node:path';
import {randomBytes} from 'node:crypto';
import {WebSocketServer,WebSocket} from 'ws';
const root=dirname(fileURLToPath(import.meta.url)),port=Number(process.env.PORT)||8787;
const types={'.html':'text/html;charset=utf-8','.js':'text/javascript;charset=utf-8','.css':'text/css;charset=utf-8','.json':'application/json;charset=utf-8','.svg':'image/svg+xml','.png':'image/png'};
const server=createServer(async(req,res)=>{
 try{
  const path=new URL(req.url,'http://local').pathname;
  const file=resolve(root,'.'+decodeURIComponent(path==='/'?'/index.html':path));
  if(file!==root&&!file.startsWith(root+sep)){res.writeHead(403).end();return;}
  const info=await stat(file);if(!info.isFile())throw Error('not file');
  res.writeHead(200,{'Content-Type':types[extname(file)]||'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
  res.end(await readFile(file));
 }catch{res.writeHead(404).end('Arquivo não encontrado');}
});
const wss=new WebSocketServer({server,maxPayload:150000});
const rooms=new Map();const cleanName=v=>String(v??'LUTADOR').slice(0,18).replace(/[<>]/g,'');
const cleanFighter=raw=>({...(raw&&typeof raw==='object'?raw:{}),name:cleanName(raw?.name)});
const send=(ws,obj)=>{if(ws?.readyState===WebSocket.OPEN)try{ws.send(JSON.stringify(obj));}catch{}};
function leave(ws){const code=ws.room;if(!code)return;ws.room=null;const r=rooms.get(code);if(!r)return;rooms.delete(code);
 const other=r.host===ws?r.guest:r.host;send(other,{type:'left'});if(other)other.room=null;
}
function cleanInput(x){x=x&&typeof x==='object'?x:{};return {x:Math.max(-1,Math.min(1,Number(x.x)||0)),z:Math.max(-1,Math.min(1,Number(x.z)||0)),armL:!!x.armL,armR:!!x.armR,special:!!x.special,kick:!!x.kick,block:!!x.block,dash:!!x.dash};}
function rate(ws,kind){const now=Date.now();if(now-(ws.lastAt||0)>1000){ws.lastAt=now;ws.counts={};}ws.counts[kind]=(ws.counts[kind]||0)+1;return ws.counts[kind]<=(kind==='state'?25:kind==='input'?70:10);}
wss.on('connection',ws=>{
 ws.on('message',raw=>{
  let msg;try{msg=JSON.parse(raw.toString());}catch{return;}if(!msg||typeof msg!=='object'||typeof msg.type!=='string'||!rate(ws,msg.type))return;
  if(msg.type==='create'){
   leave(ws);let code;do{code=randomBytes(3).toString('hex').toUpperCase()}while(rooms.has(code));
   rooms.set(code,{host:ws,guest:null,fighters:[cleanFighter(msg.fighter),null],style:['boxing','judo','mixed'].includes(msg.style)?msg.style:'boxing',breakable:!!msg.breakable,hazards:!!msg.hazards});ws.room=code;send(ws,{type:'created',code});
  }else if(msg.type==='join'){
   if(ws.room)return;const code=String(msg.code||'').toUpperCase(),r=rooms.get(code);if(!r||r.guest){send(ws,{type:'error',message:'Sala inexistente ou cheia'});return;}
   r.guest=ws;ws.room=code;r.fighters[1]=cleanFighter(msg.fighter);
   const data={type:'ready',code,fighters:r.fighters,style:r.style,breakable:r.breakable,hazards:r.hazards};send(r.host,{...data,role:'host'});send(ws,{...data,role:'guest'});
  }else if(msg.type==='input'){
   const r=rooms.get(ws.room);if(r?.guest===ws)send(r.host,{type:'input',cmd:cleanInput(msg.cmd)});
  }else if(msg.type==='state'){
   const r=rooms.get(ws.room);if(r?.host===ws&&r.guest&&msg.data&&JSON.stringify(msg.data).length<130000)send(r.guest,{type:'state',data:msg.data});
  }else if(msg.type==='rematch'){
   const r=rooms.get(ws.room);if(r?.host===ws)send(r.guest,{type:'restart'});else if(r?.guest===ws)send(r.host,{type:'rematchRequest'});
  }else if(msg.type==='leave')leave(ws);
 });ws.on('close',()=>leave(ws));ws.on('error',()=>leave(ws));
});
server.listen(port,'0.0.0.0',()=>console.log(`Knockout Dolls original 05+ em http://localhost:${port}`));
