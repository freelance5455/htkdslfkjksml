# Knockout Dolls: Fight Night 05+ para Android

**Este pacote é um PROJETO ANDROID, não é um arquivo .apk pronto.** Foi criado a partir dos arquivos originais recuperados do jogo. O ambiente de criação não possuía Android SDK e não permitiu gerar/testar o instalador.

## O que permanece exatamente na base do jogo

- `human-model.js`: o mesmo modelo humano, cabelo, rostos, roupa, acessórios e partes desmontáveis.
- `physics.js`: mesma simulação 3D de corpos rígidos, agarrões, combates e redes elásticas adicionadas ao Fight Night 05+.
- `view.js`, `style.css`, `editor.js`: mesma arena 3D, público, iluminação, editor, menus e UI.
- IA, 1v1 local, boxe, judô, livre, configurações salvas, nomes personalizados.
- Modo online experimental permanece no jogo, mas necessita de servidor WebSocket **WSS** externo.

A embalagem Android usa uma WebView com WebGL, não reescreve o jogo no Unity. É um app Android de verdade, instalado pelo APK, sem precisar deixar o PC ligado para jogar IA/2P local. A compatibilidade, FPS e controle Bluetooth devem ser verificados no aparelho.

## Gerar o APK no Windows com Android Studio

1. Baixe o **Android Studio** no site oficial https://developer.android.com/studio e instale-o.
2. Extraia este ZIP.
3. No Android Studio, escolha **Open** e selecione a pasta `KnockoutDolls_AndroidStudio`.
4. Aguarde **Gradle Sync**. Se for solicitado, instale Android SDK Platform **35** e Build Tools.
5. Com internet no PC, no menu do Android Studio escolha **Build > Build Bundle(s) / APK(s) > Build APK(s)** (ou a opção equivalente na sua versão).
6. O APK fica em `app/build/outputs/apk/debug/app-debug.apk`.
7. Passe o APK ao celular e instale-o. Essa compilação `debug` já vem assinada para testes. Não é uma versão de Play Store.

O projeto não traz o executável `gradlew` porque a ferramenta oficial de Gradle não estava disponível no ambiente de criação. Se o Android Studio não sincronizar sem wrapper, use o Gradle instalado nele (versão 8.9), ou use o método GitHub Actions abaixo.

## Alternativa: gerar o APK pela nuvem (GitHub Actions)

Suba os arquivos para um repositório de sua propriedade no GitHub, mantendo a pasta `.github`. Abra a aba **Actions**, selecione **Gerar APK Android** e execute o workflow. Quando terminar, baixe o artefato `Knockout-Dolls-Android-APK` e extraia o `app-debug.apk`. O resultado ainda precisa ser testado no aparelho.

## Como funciona a compilação

No processo de build, `prepareGameAssets` copia o HTML/CSS/JS original e baixa versões **fixas** das três bibliotecas 3D que faltavam nos RARs originais:
- Three.js r180 (three.module.js)
- Cannon-es 0.20.0
- BufferGeometryUtils.js do Three.js r180

O Gradle salva essas bibliotecas em `app/.downloaded-engine` e as inclui no APK para que o 3D do jogo funcione **offline depois da instalação**, sem depender de uma CDN no celular. É necessário ter internet no PC **na primeira compilação**. Se faltar internet o build dá erro em vez de entregar uma versão sem motor gráfico.

Se você recuperar os três arquivos originais de `vendor/` do jogo publicado, poderá colocá-los no cache `app/.downloaded-engine` com esses nomes, substituindo as versões CDN e recompilar. Isso aumenta a fidelidade exata.

## Multiplayer online

O 1v1 online original atualizado continua **experimental**. O APK não executa servidor de salas internamente. Para jogar com pessoas em outras redes, hospede `online-server/server.mjs` com Node.js + pacote `ws` em um servidor de sua confiança, atrás de um endereço `wss://` com HTTPS/TLS. Digite esse endereço no menu ONLINE do jogo. Servidores `ws://localhost` são apenas para testes no PC e **não funcionam como servidor remoto no celular**.

## Privacidade e segurança

Não desative o Controle de Aplicativos Inteligente ou as proteções do Android para construir o projeto. O app precisa de internet somente para o multiplayer online; mantém os dados de personagens em armazenamento local do WebView. O projeto evita o uso inseguro de URLs `file://` para scripts e permite só HTTPS/WSS para rede. O código completo está incluído para inspeção.

## Não validado

A compilação do APK e o teste no celular não puderam ser realizados neste ambiente. Podem aparecer ajustes adicionais na configuração do Android Studio, nos gestos multitouch ou no controle Bluetooth. O jogo da web foi preservado, mas não posso garantir paridade total sem esse teste.
