@echo off
title Retail Stock and Customer Ledger App
cd /d "%~dp0"
echo =======================================================
echo Starting Retail Stock and Customer Ledger App...
echo =======================================================
python server.py
pause
