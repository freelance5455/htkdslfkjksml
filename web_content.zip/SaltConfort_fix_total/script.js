document.addEventListener("DOMContentLoaded", () => {

    let tableData = [];
    let originalData = [];
    let fileLoaded = false;
    let currentMode = "";
    let sumeazaActive = false;


    // =========================
    // ELEMENTE
    // =========================

    const fileInput = document.getElementById("fileInput");
    const tableBody = document.querySelector("#dataTable tbody");
    const dataTable = document.getElementById("dataTable");

    const btnProducere = document.getElementById("btnProducere");
    const btnDepozit = document.getElementById("btnDepozit");
    const btnReset = document.getElementById("btnReset");
    const btnSumeaza = document.getElementById("btnSumeaza");
    const btnPrint = document.getElementById("btnPrint");
    const btnCopy = document.getElementById("btnCopy");
    const btnToggleImport = document.getElementById("btnToggleImport");
    const importPanel = document.getElementById("importPanel");
    const pasteInput = document.getElementById("pasteInput");
    const btnClearPaste = document.getElementById("btnClearPaste");

    let copyResetTimer = null;

    const toastContainer = document.getElementById("toastContainer");
    const totalsDiv = document.getElementById("totalsDiv");
    const depozitTotalDiv = document.getElementById("depozitTotal");

    // =========================
    // TOAST
    // =========================

    function showToast(msg, type = "success") {

        if (!toastContainer) return;

        const t = document.createElement("div");

        t.className =
            "toast toast-" + type;

        let icon = "fa-info-circle";

        if (type === "success")
            icon = "fa-check-circle";

        if (type === "danger")
            icon = "fa-times-circle";

        t.innerHTML =
            `<i class="fa ${icon}"></i> ${msg}`;

        toastContainer.appendChild(t);

        requestAnimationFrame(() => {

            t.classList.add("show");

        });

        setTimeout(() => {

            t.classList.remove("show");

            setTimeout(() => {

                t.remove();

            }, 400);

        }, 3000);
    }


    // =========================
    // CORECTARE NOMENCLATOR
    // =========================

    function cleanNomenclator(value) {

        return String(value || "")
            .trim()

            .replace(/cocos/gi, "cocos")

            .replace(
                /toppermemory/gi,
                "Topper Memory"
            )

            .replace(
                /topperlatex/gi,
                "Topper Latex"
            )

            .replace(
                /toppercocos/gi,
                "Topper Cocos"
            );
    }


    // =========================
    // POCKET - CONFORT
    // =========================

    function isConfortPocket(nomenclator) {

        const value = String(nomenclator || "").toLowerCase();

        return /(^|[^a-z0-9])(ultra|hypnos|setra|armony|artflex|relaxa)(?=$|[^a-z0-9])/.test(value);
    }


    // =========================
    // CATEGORII
    // =========================

    function getCategory(nomenclator) {

        if (isConfortPocket(nomenclator)) {
            return "Pocket";
        }


        const l =
            String(nomenclator || "")
                .toLowerCase()
                .trim();


        if (
            l.includes("topper memory") ||
            l.includes("topper latex") ||
            l.includes("topper cocos") ||
            /\*\s*7(\D|$)/.test(l)
        ) {

            return "Spuma/Topper 7";
        }


        if (
            /p\.?\s*s\.?\s*\+?\s*(memory|mem)\b/i.test(l) ||
            /p\.?\s*s\.?\s*\+?\s*latex\b/i.test(l)
        ) {

            return "Pocket";
        }


        if (
            l.includes("cocos") &&
            !l.includes("topper") &&
            !/\*\s*(5|7|10|15|20)(\D|$)/.test(l)
        ) {

            return "Arcuri N86 Cocos";
        }


        if (
            [
                "ideal",
                "troia",
                "orient",
                "ocean",
                "pocket"
            ].some(k => l.includes(k))
        ) {

            return "Pocket";
        }


        if (
            ["super", "forte", "memory"].some(k => l.includes(k)) &&
            !l.includes("topper memory")
        ) {

            return "Arcuri N73";
        }


        if (
            ["clasic", "lux", "plus"].some(k => l.includes(k))
        ) {

            return "Arcuri N86";
        }


        if (/\*\s*5(\D|$)/.test(l)) {

            return "Spuma 5";
        }


        if (/\*\s*10(\D|$)/.test(l)) {

            return "Spuma 10";
        }


        if (/\*\s*15(\D|$)/.test(l)) {

            return "Spuma 15";
        }


        if (/\*\s*20(\D|$)/.test(l)) {

            return "Spuma 20";
        }


        return "Alara&Perla";
    }


    // =========================
    // DIMENSIUNE
    // =========================

    function getSize(nomenclator) {

        const match =
            String(nomenclator || "")
                .match(/(\d+(\.\d+)?)/);

        return match
            ? parseFloat(match[0])
            : 0;
    }


    // =========================
    // DATE DIN COPY / PASTE
    // =========================

    function normalizeHeader(value) {

        return String(value || "")
            .trim()
            .toLowerCase()
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/[^a-z0-9]/g, "");
    }


    function splitDelimitedLine(line, delimiter) {

        const cells = [];
        let cell = "";
        let inQuotes = false;

        for (let i = 0; i < line.length; i++) {

            const char = line[i];

            if (char === '"') {

                if (inQuotes && line[i + 1] === '"') {
                    cell += '"';
                    i++;
                } else {
                    inQuotes = !inQuotes;
                }

            } else if (char === delimiter && !inQuotes) {

                cells.push(cell.trim());
                cell = "";

            } else {

                cell += char;
            }
        }

        cells.push(cell.trim());
        return cells;
    }


    function detectDelimiter(line) {

        if (line.includes("\t")) return "\t";
        if (line.includes(";")) return ";";
        if (line.includes(",")) return ",";
        return "\t";
    }


    function parsePastedRows(rawText) {
        const textValue = String(rawText || "").replace(/^\uFEFF/, "").trim();
        if (!textValue) return [];
        const lines = textValue.split(/\r?\n/).filter(line => line.trim() !== "");
        if (!lines.length) return [];
        const delimiter = detectDelimiter(lines[0]);
        const rows = lines.map(line => splitDelimitedLine(line, delimiter));
        const headers = rows[0].map(normalizeHeader);
        const findColumn = aliases => headers.findIndex(header => aliases.includes(header));
        let colData = findColumn(["data", "date"]);
        let colRepartizare = findColumn(["repartizare", "destinatie"]);
        let colClient = findColumn(["client", "beneficiar"]);
        let colNomenclator = findColumn(["nomenclator", "produs", "denumire", "articol"]);
        let colCant = findColumn(["cant", "cantitate", "cantitatea", "qty", "quantity", "bucati"]);
        const hasHeader = colNomenclator >= 0 && colCant >= 0;
        let dataRows;
        if (hasHeader) {
            dataRows = rows.slice(1);
        } else {
            if (rows.some(r => r.length >= 5)) {
                colData = 0; colRepartizare = 1; colClient = 2; colNomenclator = 3; colCant = 4;
            } else if (rows[0].length === 3) {
                colClient = 0; colNomenclator = 1; colCant = 2;
            } else if (rows[0].length === 2) {
                colNomenclator = 0; colCant = 1;
            } else return [];
            dataRows = rows;
        }
        let lastData = "", lastRepartizare = "", lastClient = "";
        const parsed = [];
        dataRows.forEach(row => {
            const dateValue = colData >= 0 ? (row[colData] || "").trim() : "";
            const repartoValue = colRepartizare >= 0 ? (row[colRepartizare] || "").trim() : "";
            const clientValue = colClient >= 0 ? (row[colClient] || "").trim() : "";
            if (dateValue) lastData = dateValue;
            if (repartoValue) lastRepartizare = repartoValue;
            if (clientValue) lastClient = clientValue;
            const nomenclator = cleanNomenclator(colNomenclator >= 0 ? (row[colNomenclator] || "") : "");
            if (!nomenclator) return;
            const qtyText = String(colCant >= 0 ? (row[colCant] || "0") : "0").replace(",", ".");
            parsed.push({
                Data: dateValue || lastData,
                Repartizare: repartoValue || lastRepartizare,
                Client: clientValue || lastClient,
                Nomenclator: nomenclator,
                Cant: Number(qtyText) || 0
            });
        });
        return parsed;
    }


    function setImportedData(rows, sourceLabel) {

        const cleaned = (rows || []).map(row => ({
            Data: row.Data || "",
            Repartizare: row.Repartizare || "",
            Client: row.Client || "",
            Nomenclator: cleanNomenclator(row.Nomenclator || ""),
            Cant: Number(row.Cant ?? row.Cantitate ?? 0) || 0
        })).filter(row => row.Nomenclator);

        if (!cleaned.length) {
            showToast("Nu am găsit rânduri valide. Verifică antetele și datele.", "danger");
            showToast("Nu am găsit rânduri valide. Verifică antetele și datele.", "danger");
            return false;
        }

        tableData = cleaned;
        originalData = JSON.parse(JSON.stringify(cleaned));
        fileLoaded = true;
        currentMode = "";
        sumeazaActive = false;

        btnSumeaza.textContent = "Sumează!";
        btnSumeaza.classList.remove("btn-success");
        btnSumeaza.classList.add("btn-danger");
        btnSumeaza.disabled = true;

        if (btnCopy) btnCopy.disabled = true;

        showToast(`${sourceLabel} preluate! Apasă Producere sau Depozit.`, "success");
        return true;
    }

    function setInputPanelsVisible(visible) {
        const pastePanel = document.getElementById("pastePanel");
        if (pastePanel) pastePanel.hidden = !visible;
        if (btnToggleImport) btnToggleImport.hidden = !visible;
        if (importPanel) { importPanel.hidden = true; }
        if (btnToggleImport) btnToggleImport.setAttribute("aria-expanded", "false");
    }


    // =========================
    // AFIȘARE TABEL
    // =========================

    function renderTable(data) {

        if (!data || data.length === 0) {

            tableBody.innerHTML =
                `<tr>
                    <td colspan="3">
                        Nu există date încă.
                    </td>
                </tr>`;

            dataTable.style.display = "none";

            totalsDiv.innerHTML = "";
            depozitTotalDiv.innerHTML = "";

            if (btnCopy) btnCopy.disabled = true;

            return;
        }


        dataTable.style.display = "table";
        if (btnCopy) btnCopy.disabled = false;


        if (currentMode === "producere") {

            dataTable.classList.add("producere");

            btnSumeaza.disabled = false;

        } else {

            dataTable.classList.remove("producere");

            btnSumeaza.disabled = true;
        }


        const thead =
            dataTable.querySelector("thead tr");


        if (currentMode === "producere") {

            thead.innerHTML = `
                <th>Nomenclator</th>
                <th>Cantitate</th>
            `;

        } else {

            thead.innerHTML = `
                <th>Data</th>
                <th>Repartizare</th>
                <th>Client</th>
                <th>Nomenclator</th>
                <th>Cantitate</th>
            `;
        }


        tableBody.innerHTML = "";


        const categories = [

            "Pocket",
            "Arcuri N73",
            "Arcuri N86",
            "Arcuri N86 Cocos",
            "Spuma 5",
            "Spuma/Topper 7",
            "Spuma 10",
            "Spuma 15",
            "Spuma 20",
            "Alara&Perla"

        ];


        categories.forEach(category => {

            let filtered = data.filter(
                d => getCategory(d.Nomenclator) === category
            );

            if (filtered.length === 0) return;

            const sortBySize = (a, b) =>
                getSize(a.Nomenclator) - getSize(b.Nomenclator);

            const colspan = currentMode === "producere" ? 2 : 5;

            tableBody.innerHTML += `
                <tr class="categoria-row">
                    <td colspan="${colspan}">${category}</td>
                </tr>
            `;

            if (category === "Pocket") {

                const regularPocket = filtered
                    .filter(item => !isConfortPocket(item.Nomenclator))
                    .sort(sortBySize);

                const confortPocket = filtered
                    .filter(item => isConfortPocket(item.Nomenclator))
                    .sort(sortBySize);

                const appendPocketRows = items => {
                    items.forEach(item => {
                        if (currentMode === "producere") {
                            tableBody.innerHTML += `
                                <tr>
                                    <td>${item.Nomenclator}</td>
                                    <td>${item.Cant}</td>
                                </tr>
                            `;
                        } else {
                            tableBody.innerHTML += `
                                <tr>
                                    <td>${item.Data || ""}</td>
                                    <td>${item.Repartizare || ""}</td>
                                    <td class="client-cell">${item.Client || ""}</td>
                                    <td>${item.Nomenclator || ""}</td>
                                    <td class="cant-depozit">${item.Cant || 0}</td>
                                </tr>
                            `;
                        }
                    });
                };

                appendPocketRows(regularPocket);

                if (confortPocket.length) {
                    tableBody.innerHTML += `
                        <tr class="subcategoria-row">
                            <td colspan="${colspan}">Confort</td>
                        </tr>
                    `;
                    appendPocketRows(confortPocket);
                }

                return;
            }

            if (category === "Spuma/Topper 7") {

                filtered.sort((a, b) => {
                    const aIs7 = /\*\s*7(\D|$)/.test(String(a.Nomenclator).toLowerCase());
                    const bIs7 = /\*\s*7(\D|$)/.test(String(b.Nomenclator).toLowerCase());
                    const aIsTopper = /topper/i.test(a.Nomenclator);
                    const bIsTopper = /topper/i.test(b.Nomenclator);

                    if (aIs7 && !bIs7) return -1;
                    if (!aIs7 && bIs7) return 1;
                    if (aIsTopper && !bIsTopper) return 1;
                    if (!aIsTopper && bIsTopper) return -1;
                    return sortBySize(a, b);
                });

            } else {
                filtered.sort(sortBySize);
            }

            filtered.forEach(item => {
                if (currentMode === "producere") {
                    tableBody.innerHTML += `
                        <tr>
                            <td>${item.Nomenclator}</td>
                            <td>${item.Cant}</td>
                        </tr>
                    `;
                } else {
                    tableBody.innerHTML += `
                        <tr>
                            <td>${item.Data || ""}</td>
                            <td>${item.Repartizare || ""}</td>
                            <td class="client-cell">${item.Client || ""}</td>
                            <td>${item.Nomenclator || ""}</td>
                            <td class="cant-depozit">${item.Cant || 0}</td>
                        </tr>
                    `;
                }
            });
        });


        if (currentMode === "producere") {

            const total =
                data.reduce(
                    (sum, r) =>
                        sum + (Number(r.Cant) || 0),
                    0
                );

            totalsDiv.innerHTML =
                `Total: ${total}`;

            depozitTotalDiv.innerHTML = "";

        } else {

            totalsDiv.innerHTML = "";

            const totalDepozit =
                data.reduce(
                    (sum, r) =>
                        sum + (Number(r.Cant) || 0),
                    0
                );

            depozitTotalDiv.innerHTML =
                `Total Cantitate: ${totalDepozit}`;
        }
    }


    // ============================================================
    // IMPORT PANEL - DESCHIDERE / ÎNCHIDERE
    // ============================================================

    if (btnToggleImport && importPanel) {
        btnToggleImport.addEventListener("click", () => {
            const isOpen = btnToggleImport.getAttribute("aria-expanded") === "true";
            btnToggleImport.setAttribute("aria-expanded", String(!isOpen));
            importPanel.hidden = isOpen;
        });
    }


    // ============================================================
    // COPY / PASTE DIN EXCEL ÎN APLICAȚIE
    // ============================================================

    if (btnClearPaste && pasteInput) {
        btnClearPaste.addEventListener("click", () => {
            pasteInput.value = "";
            pasteInput.focus();
        });
    }


    // ============================================================
    // EXCEL / CSV
    // ============================================================

    if (fileInput) {

        fileInput.addEventListener("change", e => {

            const file =
                e.target.files[0];

            if (!file) return;


            const reader =
                new FileReader();


            reader.onload = ev => {

                try {

                    const wb =
                        XLSX.read(
                            new Uint8Array(
                                ev.target.result
                            ),
                            { type: "array" }
                        );


                    const ws =
                        wb.Sheets[
                            wb.SheetNames[0]
                        ];


                    const jsonData =
                        XLSX.utils.sheet_to_json(
                            ws,
                            { defval: "" }
                        );


                    if (jsonData.length === 0) {

                        showToast(
                            "Fișier gol!",
                            "danger"
                        );

                        return;
                    }


                    const mappedRows = jsonData.map(r => ({
                        Data: r["Data"] || r["Date"] || "",
                        Repartizare: r["Repartizare"] || "",
                        Client: r["Client"] || "",
                        Nomenclator: r["Nomenclator"] || r["Produs"] || "",
                        Cant: r["Cant"] || r["Cantitate"] || r["Cantitatea"] || r["Qty"] || 0
                    }));

                    setImportedData(mappedRows, "Datele din fișier");

                } catch (error) {

                    console.error(error);

                    showToast(
                        "Nu am putut citi fișierul!",
                        "danger"
                    );
                }
            };


            reader.readAsArrayBuffer(file);
        });
    }


    function importPasteIfNeeded() {
        const pastedText = pasteInput ? pasteInput.value.trim() : "";
        if (pastedText) {
            const parsed = parsePastedRows(pastedText);
            if (!parsed.length) {
                showToast("Nu am putut identifica tabelul lipit. Verifică datele și încearcă din nou.", "danger");
                return false;
            }
            return setImportedData(parsed, "Datele lipite");
        }
        if (fileLoaded && tableData.length) return true;
        showToast("Lipește mai întâi datele sau importă un fișier Excel / CSV.", "danger");
        return false;
    }

    // ============================================================
    // PRODUCERE
    // ============================================================

    if (btnProducere) {

        btnProducere.addEventListener(
            "click",
            () => {

                if (!importPasteIfNeeded()) return;
                currentMode =
                    "producere";


                renderTable(tableData);
                setInputPanelsVisible(false);

                showToast(
                    "Producere afișată!",
                    "success"
                );
            }
        );
    }


    // ============================================================
    // DEPOZIT
    // ============================================================

    if (btnDepozit) {

        btnDepozit.addEventListener(
            "click",
            () => {

                if (!importPasteIfNeeded()) return;
                currentMode =
                    "depozit";


                renderTable(tableData);
                setInputPanelsVisible(false);

                showToast(
                    "Depozit afișat!",
                    "info"
                );
            }
        );
    }


    // ============================================================
    // SUMEAZĂ
    // ============================================================

    if (btnSumeaza) {

        btnSumeaza.addEventListener(
            "click",
            () => {

                if (currentMode !== "producere") {

                    showToast(
                        "Sumarea este disponibilă doar pentru Producere!",
                        "info"
                    );

                    return;
                }


                if (!sumeazaActive) {

                    const grouped = {};


                    tableData.forEach(r => {

                        const key =
                            r.Nomenclator;


                        if (grouped[key]) {

                            grouped[key] +=
                                Number(r.Cant) || 0;

                        } else {

                            grouped[key] =
                                Number(r.Cant) || 0;
                        }
                    });


                    tableData =
                        Object.entries(grouped)
                            .map(
                                ([Nomenclator, Cant]) => ({
                                    Nomenclator,
                                    Cant
                                })
                            );


                    sumeazaActive = true;


                    btnSumeaza.textContent =
                        "Original";


                    btnSumeaza.classList.remove(
                        "btn-danger"
                    );


                    btnSumeaza.classList.add(
                        "btn-success"
                    );


                    showToast(
                        "Valorile au fost sumate!",
                        "success"
                    );

                } else {

                    tableData =
                        JSON.parse(
                            JSON.stringify(originalData)
                        );


                    sumeazaActive = false;


                    btnSumeaza.textContent =
                        "Sumează!";


                    btnSumeaza.classList.remove(
                        "btn-success"
                    );


                    btnSumeaza.classList.add(
                        "btn-danger"
                    );


                    showToast(
                        "S-a revenit la valorile originale!",
                        "info"
                    );
                }


                renderTable(tableData);
            }
        );
    }


    // ============================================================
    // RESET
    // ============================================================

    if (btnReset) {

        btnReset.addEventListener(
            "click",
            () => {

                tableData = [];

                originalData = [];

                fileLoaded = false;

                currentMode = "";

                sumeazaActive = false;


                renderTable([]);


                if (fileInput) {
                    fileInput.value = "";
                }

                if (pasteInput) {
                    pasteInput.value = "";
                }
                setInputPanelsVisible(true);
                if (copyResetTimer) { clearTimeout(copyResetTimer); copyResetTimer = null; }
                if (toastContainer) toastContainer.innerHTML = "";

                if (btnCopy) {
                    btnCopy.disabled = true;
                    btnCopy.classList.remove("copied");
                    btnCopy.innerHTML = '<i class="fa-regular fa-copy"></i><span>Copy</span>';
                }

                btnSumeaza.disabled = true;

                btnSumeaza.textContent =
                    "Sumează!";


                btnSumeaza.classList.remove(
                    "btn-success"
                );


                btnSumeaza.classList.add(
                    "btn-danger"
                );


                showToast(
                    "Tot a fost șters.",
                    "danger"
                );
            }
        );
    }


    // ============================================================
    // COPY TABEL PENTRU EXCEL
    // ============================================================

    function getTableClipboardContent() {

        const rows = Array.from(dataTable.querySelectorAll("tr"));
        const plainRows = rows.map(row => {
            const cells = Array.from(row.querySelectorAll("th, td"));
            if (!cells.length) return "";

            if (row.classList.contains("categoria-row") || row.classList.contains("subcategoria-row")) {
                return cells[0].innerText.trim();
            }

            return cells.map(cell => cell.innerText.trim().replace(/\s+/g, " ")).join("\t");
        }).filter(Boolean);

        const plainText = plainRows.join("\n");
        const htmlTable = dataTable.cloneNode(true);
        htmlTable.removeAttribute("style");
        htmlTable.style.display = "table";
        htmlTable.style.borderCollapse = "collapse";
        htmlTable.querySelectorAll("th, td").forEach(cell => {
            cell.style.border = "1px solid #64748b";
            cell.style.padding = "4px 7px";
        });

        return {
            plainText,
            htmlText: `<html><body>${htmlTable.outerHTML}</body></html>`
        };
    }


    async function copyVisibleTable() {

        if (!dataTable || dataTable.style.display === "none" || !dataTable.querySelector("tbody tr")) {
            showToast("Mai întâi afișează tabelul Producere sau Depozit.", "info");
            return;
        }

        const content = getTableClipboardContent();
        let copied = false;

        try {
            if (navigator.clipboard && window.ClipboardItem && navigator.clipboard.write) {
                const item = new ClipboardItem({
                    "text/html": new Blob([content.htmlText], { type: "text/html" }),
                    "text/plain": new Blob([content.plainText], { type: "text/plain" })
                });
                await navigator.clipboard.write([item]);
                copied = true;
            } else if (navigator.clipboard && navigator.clipboard.writeText) {
                await navigator.clipboard.writeText(content.plainText);
                copied = true;
            }
        } catch (error) {
            console.warn("Clipboard API indisponibilă, încerc metoda alternativă.", error);
        }

        if (!copied) {
            const temp = document.createElement("textarea");
            temp.value = content.plainText;
            temp.setAttribute("readonly", "");
            temp.style.position = "fixed";
            temp.style.opacity = "0";
            temp.style.left = "-9999px";
            document.body.appendChild(temp);
            temp.select();
            try {
                copied = document.execCommand("copy");
            } catch (error) {
                copied = false;
            }
            temp.remove();
        }

        if (!copied) {
            showToast("Browserul nu a permis copierea. Încearcă din nou sau selectează tabelul manual.", "danger");
            return;
        }

        if (btnCopy) {
            btnCopy.classList.add("copied");
            btnCopy.innerHTML = '<i class="fa-solid fa-check"></i><span>Copiat</span>';
            btnCopy.disabled = true;

            if (copyResetTimer) clearTimeout(copyResetTimer);
            copyResetTimer = setTimeout(() => {
                btnCopy.classList.remove("copied");
                btnCopy.innerHTML = '<i class="fa-regular fa-copy"></i><span>Copy</span>';
                btnCopy.disabled = !(currentMode && dataTable.style.display !== "none");
            }, 2000);
        }

        showToast("Tabelul a fost copiat cu succes! Acum îl poți lipi în Excel.", "success");
    }

    if (btnCopy) {
        btnCopy.addEventListener("click", copyVisibleTable);
    }


    // ============================================================
    // PRINT
    // ============================================================

    if (btnPrint) {

        btnPrint.addEventListener(
            "click",
            () => {

                if (
                    !fileLoaded ||
                    tableData.length === 0
                ) {

                    showToast(
                        "Întâi importă un fișier sau lipește date din Excel!",
                        "danger"
                    );

                    return;
                }


                if (!currentMode) {

                    showToast(
                        "Alege Producere sau Depozit înainte de Print!",
                        "info"
                    );

                    return;
                }


                const printContent =
                    document.createElement("div");


                printContent.innerHTML = `

                    <h2 style="text-align:center;">
                        ${
                            currentMode === "producere"
                                ? "Producere"
                                : "Depozit"
                        }
                    </h2>

                    ${dataTable.outerHTML}

                    <div style="
                        margin-top:10px;
                        font-weight:700;
                        font-size:1rem;
                        text-align:${currentMode === "producere" ? "center" : "right"};
                    ">
                        ${
                            currentMode === "producere"
                                ? totalsDiv.innerHTML
                                : depozitTotalDiv.innerHTML
                        }
                    </div>
                `;


                const newWin =
                    window.open(
                        "",
                        "",
                        "width=900,height=700"
                    );


                if (!newWin) {

                    showToast(
                        "Fereastra de imprimare a fost blocată.",
                        "danger"
                    );

                    return;
                }


                newWin.document.write(`
                    <html>

                    <head>

                        <title>Print</title>

                        <link
                            href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
                            rel="stylesheet"
                        >

                        <style>

                            table {
                                width:auto;
                                border-collapse:collapse;
                            }

                            th,
                            td {
                                border:1px solid #333;
                                padding:4px;
                                text-align:left;
                                white-space:nowrap;
                            }

                            td.cant-depozit {
                                text-align:center;
                            }

                            .categoria-row {
                                background:#e2e8f0;
                                font-weight:700;
                            }

                        </style>

                    </head>

                    <body>

                        ${printContent.innerHTML}

                    </body>

                    </html>
                `);


                newWin.document.close();

                newWin.focus();


                setTimeout(() => {

                    newWin.print();

                    newWin.close();

                }, 300);
            }
        );
    }


    console.log(
        "SaltConfort script.js încărcat corect."
    );

});