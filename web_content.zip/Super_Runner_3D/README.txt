SUPER RUNNER 3D — Offline WebGL HTML Game

Files:
- index.html : complete game

How to play:
- Open index.html in Chrome or another Android browser with WebGL enabled.
- Swipe left/right to change lanes.
- Swipe up to jump; swipe down to slide.
- Collect gold coins and avoid obstacles.

This game uses built-in WebGL and does not need external libraries or internet.
For APK conversion, use the extracted index.html in an Android WebView wrapper.

Update: added an articulated 3D human-like runner model, animated limbs, and a more distant follow camera. This is a procedural game character, not a scanned photoreal human asset.

Update: coin pickups now spawn in trails of ten coins in one lane.

Update: obstacles now have clear 3D action markers: green up arrow = jump, yellow down arrow = slide under, red X = cannot pass; avoid the wall.
\nUpdate: clearer, less frequent obstacle patterns; menu character shop with eight named characters; collect coins to unlock characters; Game Over has only Again and Menu options.\n