Pipode - UL Orange
Version: 1.2026.1

Project structure:
- index.html: loading screen (minimum 5 seconds), then opens html/menu.html
- html/: menu, game, and about pages
- css/: shared and page-specific styles
- js/: navigation, loading, pipe logic, puzzle generation, and game logic

The project is a web app written with HTML/CSS/JavaScript. Import the project folder
or ZIP into an Android WebView/HTML-to-APK builder. Set the Android app orientation
to Landscape in the builder if that option is available.

No external libraries or internet connection are required.
