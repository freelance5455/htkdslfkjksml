(() => {
    "use strict";

    const MINIMUM_LOADING_TIME = 5000;
    const startedAt = Date.now();

    window.addEventListener("load", () => {
        const elapsed = Date.now() - startedAt;
        const remaining = Math.max(0, MINIMUM_LOADING_TIME - elapsed);

        window.setTimeout(() => {
            window.location.replace("html/menu.html");
        }, remaining);
    }, { once: true });
})();
