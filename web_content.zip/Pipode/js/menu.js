(() => {
    "use strict";

    const startButton = document.getElementById("startButton");
    const aboutButton = document.getElementById("aboutButton");

    startButton?.addEventListener("click", () => {
        window.PipodeNavigation.goTo("game");
    });

    aboutButton?.addEventListener("click", () => {
        window.PipodeNavigation.goTo("about");
    });
})();
