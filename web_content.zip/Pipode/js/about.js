(() => {
    "use strict";

    document.getElementById("aboutBackButton")?.addEventListener("click", () => {
        window.PipodeNavigation.goTo("menu");
    });
})();
