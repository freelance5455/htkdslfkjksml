(() => {
    "use strict";

    window.PipodeNavigation = {
        goTo(page) {
            const allowedPages = {
                menu: "menu.html",
                game: "game.html",
                about: "about.html"
            };

            if (!Object.prototype.hasOwnProperty.call(allowedPages, page)) {
                console.error("صفحه درخواستی معتبر نیست:", page);
                return;
            }

            window.location.href = allowedPages[page];
        }
    };
})();
