(() => {
    "use strict";

    const canvas = document.getElementById("gameCanvas");
    const ctx = canvas.getContext("2d");
    const overlay = document.getElementById("winOverlay");
    const acknowledgeButton = document.getElementById("acknowledgeButton");
    const backButton = document.getElementById("backButton");
    const winBackButton = document.getElementById("winBackButton");

    const DIR = window.PipodePipes.DIRECTIONS;
    const DELTAS = {
        [DIR.N]: [0, -1],
        [DIR.E]: [1, 0],
        [DIR.S]: [0, 1],
        [DIR.W]: [-1, 0]
    };
    const OPPOSITE = {
        [DIR.N]: DIR.S,
        [DIR.E]: DIR.W,
        [DIR.S]: DIR.N,
        [DIR.W]: DIR.E
    };

    let puzzle = null;
    let cellSize = 0;
    let boardLeft = 0;
    let boardTop = 0;
    let completed = false;

    function resizeCanvas() {
        const rect = canvas.getBoundingClientRect();
        const dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
        canvas.width = Math.round(rect.width * dpr);
        canvas.height = Math.round(rect.height * dpr);
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        createNewPuzzle();
    }

    function createNewPuzzle() {
        const width = canvas.clientWidth;
        const height = canvas.clientHeight;
        if (!width || !height) return;

        const size = window.PipodeGenerator.chooseGridSize(width, height);
        puzzle = window.PipodeGenerator.makePuzzle(size.cols, size.rows);
        cellSize = Math.min(width / size.cols, height / size.rows);
        boardLeft = (width - cellSize * size.cols) / 2;
        boardTop = (height - cellSize * size.rows) / 2;
        completed = false;
        overlay.classList.add("hidden");
        draw();
    }

    function drawPipe(cx, cy, size, mask) {
        const radius = size * 0.29;
        const width = Math.max(7, size * 0.17);

        ctx.save();
        ctx.lineCap = "round";
        ctx.lineJoin = "round";
        ctx.strokeStyle = "#ff8500";
        ctx.lineWidth = width;
        ctx.shadowColor = "rgba(255, 133, 0, .35)";
        ctx.shadowBlur = size * .10;

        const center = { x: cx, y: cy };
        const endpoints = [];
        if (mask & DIR.N) endpoints.push({ x: cx, y: cy - radius });
        if (mask & DIR.E) endpoints.push({ x: cx + radius, y: cy });
        if (mask & DIR.S) endpoints.push({ x: cx, y: cy + radius });
        if (mask & DIR.W) endpoints.push({ x: cx - radius, y: cy });

        if (endpoints.length === 2) {
            ctx.beginPath();
            ctx.moveTo(endpoints[0].x, endpoints[0].y);
            ctx.lineTo(center.x, center.y);
            ctx.lineTo(endpoints[1].x, endpoints[1].y);
            ctx.stroke();
        }

        ctx.fillStyle = "#ff9d2e";
        ctx.beginPath();
        ctx.arc(cx, cy, width * .52, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
    }

    function drawMarker(cx, cy, size, color, label) {
        ctx.save();
        ctx.fillStyle = color;
        ctx.shadowColor = color;
        ctx.shadowBlur = size * .18;
        ctx.beginPath();
        ctx.arc(cx, cy, size * .22, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
        ctx.fillStyle = "#000";
        ctx.font = `bold ${Math.max(10, size * .22)}px Tahoma, Arial`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(label, cx, cy + 1);
        ctx.restore();
    }

    function draw() {
        if (!puzzle) return;

        const width = canvas.clientWidth;
        const height = canvas.clientHeight;
        ctx.clearRect(0, 0, width, height);

        const boardWidth = cellSize * puzzle.cols;
        const boardHeight = cellSize * puzzle.rows;

        ctx.save();
        ctx.strokeStyle = "rgba(255, 133, 0, .13)";
        ctx.lineWidth = 1;
        for (let x = 0; x <= puzzle.cols; x++) {
            const px = boardLeft + x * cellSize;
            ctx.beginPath();
            ctx.moveTo(px, boardTop);
            ctx.lineTo(px, boardTop + boardHeight);
            ctx.stroke();
        }
        for (let y = 0; y <= puzzle.rows; y++) {
            const py = boardTop + y * cellSize;
            ctx.beginPath();
            ctx.moveTo(boardLeft, py);
            ctx.lineTo(boardLeft + boardWidth, py);
            ctx.stroke();
        }
        ctx.restore();

        for (let y = 0; y < puzzle.rows; y++) {
            for (let x = 0; x < puzzle.cols; x++) {
                const cell = puzzle.cells[y][x];
                const cx = boardLeft + (x + .5) * cellSize;
                const cy = boardTop + (y + .5) * cellSize;

                if (cell.isStart) {
                    drawMarker(cx, cy, cellSize, "#ff3030", "S");
                } else if (cell.isEnd) {
                    drawMarker(cx, cy, cellSize, "#35d66b", "E");
                } else {
                    drawPipe(cx, cy, cellSize, cell.mask);
                }
            }
        }
    }

    function getCellFromPointer(event) {
        const rect = canvas.getBoundingClientRect();
        const x = event.clientX - rect.left;
        const y = event.clientY - rect.top;
        const col = Math.floor((x - boardLeft) / cellSize);
        const row = Math.floor((y - boardTop) / cellSize);

        if (row < 0 || row >= puzzle.rows || col < 0 || col >= puzzle.cols) {
            return null;
        }
        return puzzle.cells[row][col];
    }

    function isConnectedToEnd() {
        const queue = [{ x: puzzle.start.x, y: puzzle.start.y }];
        const visited = new Set([`${puzzle.start.x},${puzzle.start.y}`]);

        while (queue.length) {
            const current = queue.shift();

            if (current.x === puzzle.end.x && current.y === puzzle.end.y) {
                return true;
            }

            for (const direction of Object.values(DIR)) {
                const [dx, dy] = DELTAS[direction];
                const nx = current.x + dx;
                const ny = current.y + dy;

                if (nx < 0 || nx >= puzzle.cols || ny < 0 || ny >= puzzle.rows) continue;

                const neighbor = puzzle.cells[ny][nx];
                if (neighbor.isStart) continue;

                const currentCell = puzzle.cells[current.y][current.x];
                const currentHasPort = currentCell.isStart
                    ? (current.x === puzzle.start.x && current.y === puzzle.start.y &&
                       getDirection(current, neighbor) === DIR.E)
                    : window.PipodePipes.hasDirection(currentCell.mask, direction);

                const neighborHasPort = neighbor.isEnd
                    ? true
                    : window.PipodePipes.hasDirection(neighbor.mask, OPPOSITE[direction]);

                if (!currentHasPort || !neighborHasPort) continue;

                const key = `${nx},${ny}`;
                if (!visited.has(key)) {
                    visited.add(key);
                    queue.push({ x: nx, y: ny });
                }
            }
        }
        return false;
    }

    function checkWin() {
        // The generated path's first cell can be at any row, so the start
        // connects only to its immediate right-hand neighbor.
        const firstNext = puzzle.path[1];
        const startNeighbor = puzzle.cells[firstNext.y][firstNext.x];
        const startDirection = firstNext.x > puzzle.start.x ? DIR.E :
            firstNext.x < puzzle.start.x ? DIR.W :
            firstNext.y > puzzle.start.y ? DIR.S : DIR.N;

        if (!window.PipodePipes.hasDirection(startNeighbor.mask, OPPOSITE[startDirection])) {
            return false;
        }

        // BFS from the first pipe; the end marker is reached only through a matching port.
        const queue = [firstNext];
        const visited = new Set([`${firstNext.x},${firstNext.y}`]);

        while (queue.length) {
            const current = queue.shift();
            if (current.x === puzzle.end.x && current.y === puzzle.end.y) return true;

            const cell = puzzle.cells[current.y][current.x];
            for (const direction of Object.values(DIR)) {
                if (!window.PipodePipes.hasDirection(cell.mask, direction)) continue;
                const [dx, dy] = DELTAS[direction];
                const nx = current.x + dx;
                const ny = current.y + dy;
                if (nx < 0 || nx >= puzzle.cols || ny < 0 || ny >= puzzle.rows) continue;

                const neighbor = puzzle.cells[ny][nx];
                if (neighbor.isStart) continue;
                if (neighbor.isEnd) {
                    if (direction === DIR.E || direction === DIR.W ||
                        direction === DIR.N || direction === DIR.S) return true;
                }
                if (!window.PipodePipes.hasDirection(neighbor.mask, OPPOSITE[direction])) continue;

                const key = `${nx},${ny}`;
                if (!visited.has(key)) {
                    visited.add(key);
                    queue.push({ x: nx, y: ny });
                }
            }
        }
        return false;
    }

    function onCanvasTap(event) {
        if (completed || !puzzle) return;
        const cell = getCellFromPointer(event);
        if (!cell || cell.isStart || cell.isEnd) return;

        window.PipodePipes.rotatePipe(cell);
        draw();

        if (checkWin()) {
            completed = true;
            overlay.classList.remove("hidden");
        }
    }

    function goToMenu() {
        window.PipodeNavigation.goTo("menu");
    }

    canvas.addEventListener("pointerup", onCanvasTap);
    backButton.addEventListener("click", goToMenu);
    winBackButton.addEventListener("click", goToMenu);
    acknowledgeButton.addEventListener("click", () => {
        // Endless mode: dismiss the win message and immediately create a new puzzle.
        createNewPuzzle();
    });

    window.addEventListener("resize", resizeCanvas);
    window.addEventListener("orientationchange", () => window.setTimeout(resizeCanvas, 150));

    resizeCanvas();
})();
