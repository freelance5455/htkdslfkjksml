(() => {
    "use strict";

    const DIR = window.PipodePipes.DIRECTIONS;
    const OPPOSITE = {
        [DIR.N]: DIR.S,
        [DIR.E]: DIR.W,
        [DIR.S]: DIR.N,
        [DIR.W]: DIR.E
    };

    const STEP = {
        [DIR.N]: [0, -1],
        [DIR.E]: [1, 0],
        [DIR.S]: [0, 1],
        [DIR.W]: [-1, 0]
    };

    function randomInt(max) {
        return Math.floor(Math.random() * max);
    }

    function shuffled(values) {
        const result = values.slice();
        for (let i = result.length - 1; i > 0; i--) {
            const j = randomInt(i + 1);
            [result[i], result[j]] = [result[j], result[i]];
        }
        return result;
    }

    function getDirection(a, b) {
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        if (dx === 1) return DIR.E;
        if (dx === -1) return DIR.W;
        if (dy === 1) return DIR.S;
        if (dy === -1) return DIR.N;
        return 0;
    }

    function chooseGridSize(width, height) {
        // Grid grows/shrinks with available landscape canvas space.
        const cell = Math.max(42, Math.min(76, Math.floor(Math.min(width / 10.5, height / 6.2))));
        const cols = Math.max(5, Math.min(14, Math.floor(width / cell)));
        const rows = Math.max(5, Math.min(9, Math.floor(height / cell)));
        return { cols, rows };
    }

    function makeGuaranteedPath(cols, rows) {
        // The path always advances to the right. Each column may contain
        // a vertical segment, so it cannot loop back or revisit a cell.
        const startY = randomInt(rows);
        const path = [{ x: 0, y: startY }];

        let currentY = startY;
        for (let x = 0; x < cols - 1; x++) {
            let nextY = currentY;

            if (rows > 1 && Math.random() < 0.72) {
                const choices = [];
                if (currentY > 0) choices.push(currentY - 1);
                if (currentY < rows - 1) choices.push(currentY + 1);
                if (choices.length) nextY = choices[randomInt(choices.length)];
            }

            if (nextY !== currentY) {
                const direction = nextY > currentY ? 1 : -1;
                while (currentY !== nextY) {
                    currentY += direction;
                    path.push({ x, y: currentY });
                }
            }

            path.push({ x: x + 1, y: currentY });
        }

        return path;
    }

    function makePuzzle(cols, rows) {
        const path = makeGuaranteedPath(cols, rows);
        const routeKeys = new Set(path.map(p => `${p.x},${p.y}`));
        const cells = Array.from({ length: rows }, (_, y) =>
            Array.from({ length: cols }, (_, x) => ({
                x, y,
                type: Math.random() < 0.5 ? "straight" : "elbow",
                mask: Math.random() < 0.5 ? (DIR.E | DIR.W) : (DIR.N | DIR.S),
                rotation: 0,
                isStart: false,
                isEnd: false,
                route: false
            }))
        );

        const start = path[0];
        const end = path[path.length - 1];
        cells[start.y][start.x].isStart = true;
        cells[end.y][end.x].isEnd = true;

        for (let i = 1; i < path.length - 1; i++) {
            const previous = path[i - 1];
            const current = path[i];
            const next = path[i + 1];
            const entry = OPPOSITE[getDirection(previous, current)];
            const exit = getDirection(current, next);
            const solutionMask = entry | exit;
            const cell = cells[current.y][current.x];

            cell.route = true;
            cell.type = (solutionMask === (DIR.E | DIR.W) || solutionMask === (DIR.N | DIR.S))
                ? "straight" : "elbow";

            // Start each route pipe in a random orientation, not its solution orientation.
            const rotations = randomInt(4);
            cell.mask = solutionMask;
            cell.rotation = 0;
            for (let r = 0; r < rotations; r++) {
                window.PipodePipes.rotatePipe(cell);
            }
            cell.solutionMask = solutionMask;
        }

        // Randomize the two endpoint markers' positions are fixed at the path ends.
        // A valid solution is guaranteed because every route pipe has a known target mask.
        return { cols, rows, cells, start, end, path, routeKeys };
    }

    window.PipodeGenerator = {
        chooseGridSize,
        makePuzzle
    };
})();
