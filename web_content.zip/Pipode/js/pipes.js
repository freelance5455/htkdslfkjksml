(() => {
    "use strict";

    const DIRECTIONS = {
        N: 1,
        E: 2,
        S: 4,
        W: 8
    };

    function rotateMask(mask) {
        // Clockwise: N -> E -> S -> W -> N
        return ((mask << 1) & 15) | ((mask & DIRECTIONS.W) ? DIRECTIONS.N : 0);
    }

    function rotatePipe(pipe) {
        pipe.mask = rotateMask(pipe.mask);
        pipe.rotation = (pipe.rotation + 1) % 4;
    }

    function hasDirection(mask, direction) {
        return (mask & direction) !== 0;
    }

    window.PipodePipes = {
        DIRECTIONS,
        rotatePipe,
        hasDirection
    };
})();
