MY LIFE LOG — Faisal Abbas
=========================
This is a working, mobile-friendly personal tracking app prototype.

Included:
- Daily walk/run duration and kilometres
- Five daily prayers, congregation, past-years Qaza count, Namaz-e-Shab
- Quran Surah and ayah range, translation/tafseer, minutes
- Bedtime, wake time and calculated sleep duration
- Office start/end, food diary, water glasses, charity in PKR
- Mood, personal notes, gratitude, reflection and tomorrow's intention
- Daily history, monthly report, stats, CSV export, JSON backup/restore
- Local-only storage in the browser

QUICK TEST:
Open www/index.html in a modern browser. On Android, you can open it from
a local file manager, but browser restrictions may vary. For reliable install
as an Android app, package the www folder with Capacitor or Android Studio.

IMPORTANT:
This generated package is not a signed Android APK. An APK needs an Android
build environment and package signing. Do not treat local browser storage as
a backup; export JSON regularly.
