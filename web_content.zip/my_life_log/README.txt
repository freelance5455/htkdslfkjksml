MY LIFE LOG — FAISAL ABBAS

This ZIP contains a mobile-friendly browser-based personal life log.

How to use:
1. Extract the ZIP.
2. Open www/index.html in Chrome or another modern browser.
3. Data is stored locally in that browser on that device. Use Backup & Restore to download JSON backups regularly.

Features included:
- Daily prayer statuses: With Jamaat, Individually, Missed, Not recorded.
- Qaza starting balances for Fajr, Zuhr, Asr, Maghrib, Isha and Witr; daily completions and remaining balances.
- Multiple sleep, office/duty, walk/run and Quran tilawat entries per day; editable/removable rows; overnight durations.
- Walk/run type and distance totals; Quran surah, ayah range and Urdu-translation checkbox.
- Good habits and hygiene checklist plus custom habits; daily short dua checklist with Arabic, transliteration and English meaning.
- Meals, mood, water, sadqa, special events and personal notes.
- Daily/monthly reports, statistics, record editing/deletion, JSON backup/restore and CSV export.

Important:
- This is a web app ZIP, not an Android APK.
- Records stay in local browser storage unless exported. Clearing browser data may remove them.
- The duas are short prompts; verify exact wording with a trusted religious source.
