# AeroScenery Web Studio (prototype)

A responsive dark aviation dashboard concept based on the uploaded AeroScenery Community Mod l repository. This is a browser-only UI prototype, not a port of the Windows app's scenery engine.

## Run locally

Open `index.html` in a modern browser, or serve this folder with any static web server. An internet connection is needed for the Leaflet map tiles and CDN assets.

## Included
- Responsive dark dashboard
- OpenStreetMap preview with click-to-set coordinates
- Project name, coordinates, detail level, output profile and worker settings
- Session-only build-plan queue
- Queue and tile-library views

## Important limitations
The original repository is a C# Windows Forms application targeting .NET Framework 4.8. Its imagery download, tile processing, built-in TTC conversion, and optional GeoConvert functions are not executed by this static website. A real full web app needs a backend service to manage jobs, access configured imagery providers, process files, store outputs, and expose job progress. GeoConvert SDK requirements and simulator file licensing should be reviewed before hosting such a service.

## Suggested next architecture
- Frontend: this responsive HTML/CSS/JS interface, later migrated to React/TypeScript if desired.
- Backend: ASP.NET Core API and worker service on a Windows host for reuse of compatible C# processing code; isolate long-running jobs from HTTP requests.
- Storage: temporary job workspace plus object/file storage for generated tiles.
- Queue: persistent job state, cancellation, progress updates, validation, and cleanup.
- Security: per-user job isolation, upload/download limits, provider rate limits, and no arbitrary server-side file paths.

This is an unofficial community concept and is not affiliated with IPACS.
