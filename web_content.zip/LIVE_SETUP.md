# Live setup checklist

## AdMob
You need your own:
- AdMob account
- AdMob App ID
- Production Rewarded Ad Unit ID

The starter intentionally uses Google's rewarded test ad unit:
ca-app-pub-3940256099942544/5224354917

Do not use the test ID as your production ad unit.

## Rewards
For a real earning app, do not trust a JavaScript/localStorage balance. The server should:
- authenticate the user
- record rewards
- enforce daily/rate limits
- verify rewarded-ad completion (including AdMob server-side verification where appropriate)
- maintain an immutable transaction ledger
- prevent replay/fraud

## Orange Money
A phone number is not an API credential. Real payouts require an approved merchant/business relationship and the API/collection/disbursement capability offered by the provider. Keep credentials on the backend.

## AdMob publisher payments
Ad revenue paid to the app owner is separate from user withdrawals. AdMob determines supported publisher payment methods based on the payment profile/address; do not assume publisher revenue can be paid directly to an Orange Money number.
