# ANONYMOUX STUDIO 2.5.5 — source audit and implementation report

## Source and architecture inspected

The starting archive was extracted without replacing its original upload. The source contains a PHP 8 application with PDO persistence, shared authentication/session bootstrap, SQLite/MySQL SQL migrations, server-side provider adapters, browser workspaces and existing static regression tests.

### Route and dependency inventory

| Area / entry point | Main dependencies | Findings / action |
|---|---|---|
| Tools & Tutorials: `tools-tutorials.php` | `app/tools-tutorials.php`, `app/resources.php`, `tutorial.php`, `resource-media.php`, `admin_resources_view.php`, `migrations/002_*` | Existing database-backed catalogue, filters, pagination, tutorial detail and admin resource workflows retained. Existing resource regression tests pass. |
| Buy Credits: `credits.php` | `app/payments.php`, `app/voice.php`, `api/payments.php`, `api/flutterwave-webhook.php`, Admin → Payments, `migrations/003_*` | Existing hosted Flutterwave checkout and server verification retained. Added package options, safe schema upgrades, four default package definitions (only missing names inserted), bonus-aware order credit snapshot and per-credit display. |
| Agent Studio: `agent-studio.php`, `agent-chat.php` | `app/agent.php`, `api/agent/*`, `assets/agent-studio.js`, `assets/agent-chat.js`, Fish Audio key vault in `app/voice.php`, `migrations/004_*` | Fish adapter now logs bounded sanitized diagnostics and maps HTTP failures. Session creation sends documented `agent_id` and supported overrides; session response is passed through to the Fish SDK. Provider session end is requested before usage reconciliation. |
| Explore: `community.php` | `app/platform_header.php`, shared community/landing assets | Preserved; this is not renamed to Exploit and is not removed. Its former Shorts Studio CTA now points to Video Studio. |
| Shorts Studio: `shorts-studio.php` | `app/platform_header.php`, `onboarding.php`, `onboarding-tour.php`, community link | Removed from sidebar and onboarding workspace cards/allowed-next route. Old URL returns HTTP 404 with a Video Studio route. Shared media/video code and reusable assets are retained. |

### Important Fish Audio diagnosis

The original Agent session request included extra fields (`end_user_id` and `tool_events`) in addition to `agent_id` and nested overrides. The Fish Audio SDK's official authenticated-agent quickstart creates a server-side session by POSTing `{ agent_id }` and passes the returned JSON object as `sessionToken` to `AgentSession.start`. Agent configuration documentation explicitly supports per-session `overrides.voice_id`, `overrides.system_prompt` and `overrides.first_message`. The updated endpoint therefore sends only `agent_id` plus these documented overrides; it no longer sends the unsupported extra request fields.

The adapter preserves HTTP status, provider error code/message (bounded) and transport diagnostics in server logs without logging API credentials or request bodies. User-facing errors are mapped by actual status classes. Mutating requests are not automatically replayed after transient failures. The pinned `@fishaudio/agent-client@0.3.0` was checked against the current npm package listing on 2026-11-15; it is still the package current tag/latest version.

Official references checked 2026-11-15:
- https://docs.fish.audio/llms.txt
- https://github.com/fishaudio/fish-agent-sdk
- https://github.com/fishaudio/docs/blob/main/agents/build/configuration.mdx
- https://github.com/fishaudio/docs/blob/main/agents/build/voice-language.mdx
- https://www.npmjs.com/package/@fishaudio/agent-client

### Payment and package behavior

- Package amount is stored in minor currency units; ₦2,500 is stored as 250,000 kobo.
- Proposed package quantities and prices reflect ₦10 per credit.
- Bonus credits default to zero and are snapshotted into the pending payment order at checkout creation.
- Existing package records are not rewritten; missing named defaults are added. Existing user wallets, transactions, orders, media and provider credentials are not dropped or reset.
- Existing Flutterwave verification still checks provider success, reference, exact currency and exact expected amount before entering the wallet transaction. Payment-order reference and provider transaction ID uniqueness plus transaction locking protect duplicate crediting.

### Scope deliberately not changed

- No unrelated Explore page deletion.
- No removal of shared video processing, reusable community assets or shared media components.
- No invented Fish Audio/Decart provider costs or new model rates.
- No live provider success fabricated in place of a real request.
- Existing credentials/configuration and generated media are not overwritten.
