'use strict';
/* ==========================================================
   متجر العطور - المنطق البرمجي
   - حفظ كل خطوة للمستخدم (localStorage)
   - ربط مع بوت تلجرام (توكن + آيدي): إرسال الطلبات + إضافة المنتجات
   ========================================================== */

/* ---------------- الإعدادات (يمكنك تعبئتها هنا أو من شاشة "حسابي") ---------------- */
const CONFIG = {
  TELEGRAM_TOKEN: '',      // توكن البوت من @BotFather  مثال: 123456:ABC-DEF...
  TELEGRAM_CHAT_ID: '',    // آيدي حسابك (المدير) من @userinfobot
  CURRENCY: '$',
  SHIPPING: 0,             // مصاريف الشحن
  POLL_SECONDS: 20,        // مدة الانتظار لاستقبال أوامر البوت
  STORAGE_KEY: 'royal_perfume_state_v1'
};

/* ---------------- أدوات مساعدة ---------------- */
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = n => CONFIG.CURRENCY + Number(n).toFixed(2);
const hash = s => { let h = 5381; for (const c of s) h = ((h << 5) + h + c.charCodeAt(0)) >>> 0; return h.toString(36); };

const ICONS = {
  cart: '<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6"/>',
  bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/>',
  menu: '<path d="M3 6h18M3 12h18M3 18h18"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  filter: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
  heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8z"/>',
  home: '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 22V12h6v10"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/>',
  tag: '<path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L2 12V2h10l8.6 8.6a2 2 0 0 1 0 2.8z"/><circle cx="7" cy="7" r="1.5"/>',
  user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  back: '<path d="M5 12h14M12 5l7 7-7 7"/>',
  trash: '<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  xc: '<circle cx="12" cy="12" r="10"/><path d="m15 9-6 6M9 9l6 6"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  mail: '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>',
  eye: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>',
  eyeoff: '<path d="M17.9 17.9A10.9 10.9 0 0 1 12 20C5 20 1 12 1 12a18 18 0 0 1 5.1-5.9M9.9 4.2A9.1 9.1 0 0 1 12 4c7 0 11 8 11 8a18 18 0 0 1-2.2 3.2M1 1l22 22"/>',
  gift: '<path d="M20 12v10H4V12M2 7h20v5H2zM12 22V7M12 7H7.5a2.5 2.5 0 1 1 0-5C11 2 12 7 12 7zM12 7h4.5a2.5 2.5 0 1 0 0-5C13 2 12 7 12 7z"/>',
  chev: '<path d="m15 18-6-6 6-6"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  doc: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h8"/>',
  truck: '<path d="M1 3h15v13H1zM16 8h4l3 3v5h-7"/><circle cx="5.5" cy="18.5" r="2"/><circle cx="18.5" cy="18.5" r="2"/>',
  wallet: '<rect x="2" y="6" width="20" height="14" rx="2"/><path d="M2 10h20M16 15h2"/>',
  send: '<path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/>',
  globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20M12 2a15 15 0 0 0 0 20"/>',
  caret: '<path d="m6 9 6 6 6-6"/>'
};
const ic = (n, cls = '') => `<svg class="ic ${cls}" viewBox="0 0 24 24">${ICONS[n]}</svg>`;
const STAR = '<svg class="ic fill" viewBox="0 0 24 24"><path d="m12 2 3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z"/></svg>';

const LOGO = `<div class="logo"><svg viewBox="0 0 64 64" fill="none" stroke="#e8c765" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12l6 5 6-9 6 9 6-5-3 9H23z" fill="#d4af37" stroke="none"/><path d="M22 28c-8 6-10 18-6 30M42 28c8 6 10 18 6 30M24 30c-4 8-4 18 0 28M40 30c4 8 4 18 0 28M32 28v30"/></svg><b>متجر العطور</b><i>عطور .. تليق بك</i></div>`;

/* صورة زجاجة عطر (SVG) تُستخدم عندما لا توجد صورة للمنتج */
function bottle(c) {
  const [a, b] = c || ['#d4af37', '#5a3d0a'];
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 120 160'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='${a}'/><stop offset='1' stop-color='${b}'/></linearGradient><linearGradient id='k' x1='0' x2='1'><stop offset='0' stop-color='#f7e08f'/><stop offset='1' stop-color='#9a7420'/></linearGradient></defs><rect x='44' y='6' width='32' height='20' rx='3' fill='url(#k)'/><rect x='54' y='26' width='12' height='10' fill='#c9a24a'/><rect x='18' y='36' width='84' height='116' rx='14' fill='url(#g)' stroke='#f7e08f' stroke-opacity='.6' stroke-width='1.5'/><rect x='36' y='72' width='48' height='38' rx='4' fill='rgba(255,255,255,.88)'/><path d='M60 80l5 7 7-3-2 9H50l-2-9 7 3z' fill='#b8891f'/><rect x='26' y='44' width='8' height='100' rx='4' fill='rgba(255,255,255,.18)'/></svg>`;
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
}

/* ---------------- البيانات الافتراضية ---------------- */
const CATS = { women: 'عطور نسائية', men: 'عطور رجالية', unisex: 'عطور للجنسين', gifts: 'هدايا فاخرة', offers: 'عروض خاصة' };
const CAT_ICON = { women: ['#f4a6b8', '#c9577a'], men: ['#1d3f8f', '#0a1a45'], unisex: null, gifts: null, offers: null };
const PALETTE = [['#f4a6b8', '#c9577a'], ['#1d3f8f', '#0a1a45'], ['#d4af37', '#5a3d0a'], ['#c0304a', '#5a0a1e'], ['#3a3a44', '#0c0c10'], ['#2f8f6b', '#0b3a2a']];

const SEED = [
  { id: 1, name: 'عطر ميس ديور', price: 129.99, old: 159.99, cat: 'women', size: '100 مل', rating: 4.8, reviews: '12.5k', badge: '🔥 الأكثر مبيعاً', c: ['#f4a6b8', '#c9577a'] },
  { id: 2, name: 'عطر بلو دي شانيل', price: 149.99, old: 179.99, cat: 'men', size: '100 مل', rating: 4.9, reviews: '18.7k', badge: '👑 الأفضل مبيعاً', c: ['#1d3f8f', '#0a1a45'] },
  { id: 3, name: 'عطر رويال عود', price: 199, old: 0, cat: 'unisex', size: '100 مل', rating: 4.7, reviews: '3.2k', badge: '', c: ['#d4af37', '#5a3d0a'] },
  { id: 4, name: 'عطر ورد دمشقي', price: 89.5, old: 110, cat: 'women', size: '75 مل', rating: 4.6, reviews: '2.1k', badge: '', c: ['#c0304a', '#5a0a1e'] },
  { id: 5, name: 'عطر ليل الصحراء', price: 119, old: 0, cat: 'men', size: '100 مل', rating: 4.5, reviews: '1.4k', badge: '', c: ['#3a3a44', '#0c0c10'] },
  { id: 6, name: 'صندوق هدية ملكي', price: 249, old: 299, cat: 'gifts', size: 'طقم', rating: 5.0, reviews: '860', badge: '🎁 هدية', c: ['#d4af37', '#1a1206'] }
];

const DEFAULT_STATE = {
  user: null, users: [], remember: true,
  favs: [], cart: [], coupon: null,
  coupons: { ROYAL10: 10 },
  products: SEED, nextPid: 7, orders: [], nextOid: 1001,
  screen: 'home', cat: 'all', q: '', scroll: 0,
  tg: { token: CONFIG.TELEGRAM_TOKEN, chat: CONFIG.TELEGRAM_CHAT_ID, offset: 0 }
};

/* ---------------- الحالة + الحفظ التلقائي ---------------- */
let S = load();
const UI = { mode: 'login', showPw: false, err: '', slide: 0, restore: true };

function load() {
  try {
    const raw = JSON.parse(localStorage.getItem(CONFIG.STORAGE_KEY) || 'null');
    const st = Object.assign(structuredClone(DEFAULT_STATE), raw || {});
    if (raw && raw.remember === false) st.user = null;
    if (!st.tg.token && CONFIG.TELEGRAM_TOKEN) st.tg.token = CONFIG.TELEGRAM_TOKEN;
    if (!st.tg.chat && CONFIG.TELEGRAM_CHAT_ID) st.tg.chat = CONFIG.TELEGRAM_CHAT_ID;
    return st;
  } catch (e) { return structuredClone(DEFAULT_STATE); }
}
function save() { try { localStorage.setItem(CONFIG.STORAGE_KEY, JSON.stringify(S)); } catch (e) { } }
function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 2400);
}

/* ---------------- منطق المتجر ---------------- */
const prod = id => S.products.find(p => p.id === id);
const isFav = id => S.favs.includes(id);
const cartCount = () => S.cart.reduce((a, i) => a + i.qty, 0);
function cartLines() { return S.cart.map(i => ({ ...i, p: prod(i.id) })).filter(i => i.p); }
function totals() {
  const lines = cartLines();
  const sub = lines.reduce((a, l) => a + l.p.price * l.qty, 0);
  const pct = S.coupon ? (S.coupons[S.coupon] || 0) : 0;
  const disc = +(sub * pct / 100).toFixed(2);
  const ship = lines.length ? CONFIG.SHIPPING : 0;
  return { lines, sub, pct, disc, ship, total: sub - disc + ship };
}
function filtered() {
  const q = S.q.trim().toLowerCase();
  return S.products.filter(p => {
    if (S.cat === 'offers' && !(p.old > p.price)) return false;
    if (S.cat !== 'all' && S.cat !== 'offers' && p.cat !== S.cat) return false;
    return !q || p.name.toLowerCase().includes(q);
  });
}

/* ---------------- العرض ---------------- */
function go(screen, extra = {}) {
  Object.assign(S, extra, { screen, scroll: 0 });
  UI.restore = false; save(); render();
}

function render() {
  const root = $('#screen');
  if (!S.user) { root.innerHTML = loginView(); return; }
  const cartScr = S.screen === 'cart';
  root.innerHTML = `
    <header class="hdr">
      <div class="side r">${cartScr
        ? `<button class="round" data-act="nav" data-v="home">${ic('back')}</button>`
        : `<button class="round" data-act="nav" data-v="account">${ic('menu')}</button>`}</div>
      ${LOGO}
      <div class="side l">
        <button class="plain" data-act="bell">${ic('bell')}</button>
        ${cartScr
          ? `<button class="round" data-act="clearcart">${ic('trash')}</button>`
          : `<button class="plain" data-act="nav" data-v="cart">${ic('cart')}${cartCount() ? `<span class="badge-n">${cartCount()}</span>` : ''}</button>`}
      </div>
    </header>
    <main id="view">${viewFor()}</main>
    ${navView()}`;
  const v = $('#view');
  if (UI.restore) { v.scrollTop = S.scroll || 0; UI.restore = false; }
  v.addEventListener('scroll', () => { S.scroll = v.scrollTop; clearTimeout(render.t); render.t = setTimeout(save, 250); });
  const q = $('#q');
  if (q) q.addEventListener('keydown', e => { if (e.key === 'Enter') { go('categories', { q: q.value, cat: 'all' }); } });
}

function viewFor() {
  switch (S.screen) {
    case 'categories': return listView(true);
    case 'offers': return listView(false);
    case 'favorites': return favView();
    case 'cart': return cartView();
    case 'account': return accountView();
    default: return homeView();
  }
}

function navView() {
  const items = [['categories', 'grid', 'الأقسام'], ['offers', 'tag', 'العروض'], ['home', 'home', 'الرئيسية'], ['favorites', 'heart', 'المفضلة'], ['account', 'user', 'حسابي']];
  return `<nav class="nav">${items.map(([k, i, l]) => `<button class="nv ${S.screen === k ? 'on' : ''}" data-act="nav" data-v="${k}">${ic(i)}<span>${l}</span></button>`).join('')}</nav>`;
}

function searchBar() {
  return `<div class="search"><span class="flt" data-act="nav" data-v="categories">${ic('filter')}</span><input id="q" placeholder="ابحث عن عطرك المفضل..." value="${esc(S.q)}">${ic('search')}</div>`;
}

function productCard(p) {
  const img = p.img ? `<img class="b" src="${esc(p.img)}" onerror="this.src='${bottle(p.c)}'">` : `<img class="b" src="${bottle(p.c)}">`;
  const [a, b] = p.c || ['#d4af37', '#5a3d0a'];
  const tag = p.badge || (p.old > p.price ? `خصم ${Math.round((1 - p.price / p.old) * 100)}%` : '');
  return `<div class="pcard">
    <div class="pimg" style="background:radial-gradient(90% 90% at 50% 40%,${a}55,${b}33 55%,#0a0806)">
      ${img}
      <button class="fav ${isFav(p.id) ? 'on' : ''}" data-act="fav" data-id="${p.id}">${ic('heart')}</button>
      ${tag ? `<span class="tag">${esc(tag)}</span>` : ''}
    </div>
    <div class="pinfo">
      <div class="pname">${esc(p.name)}</div>
      <div class="rate">${STAR}<span>${p.rating} (${esc(p.reviews)})</span></div>
      <div class="prow">
        <button class="cartbtn" data-act="add" data-id="${p.id}">${ic('cart')}</button>
        <div class="price">${money(p.price)}${p.old > p.price ? `<s>${money(p.old)}</s>` : ''}</div>
      </div>
    </div></div>`;
}

const SLIDES = [
  ['اكتشف عالم', 'العطور الفاخرة', 'بمزيج من الفخامة والجاذبية', ['#d4af37', '#2a1c06']],
  ['تشكيلة جديدة من', 'عطور العود', 'أصالة تدوم طويلاً', ['#3a3a44', '#0c0c10']],
  ['خصومات تصل إلى', 'عروض خاصة', 'لفترة محدودة فقط', ['#c0304a', '#5a0a1e']]
];

function homeView() {
  const cats = [['women', 'عطور نسائية', 'img'], ['men', 'عطور رجالية', 'img'], ['unisex', 'عطور للجنسين', 'ic:globe'], ['gifts', 'هدايا فاخرة', 'ic:gift'], ['offers', 'عروض خاصة', 'ic:tag']];
  const catHtml = cats.map(([k, l, t]) => {
    const inner = t === 'img' ? `<img src="${bottle(CAT_ICON[k])}">` : ic(t.split(':')[1]);
    return `<button class="cat" data-act="cat" data-v="${k}">${inner}<span>${l}</span></button>`;
  }).join('');
  const feat = S.products.slice(0, 4);
  return `${searchBar()}
  <div class="banner">${SLIDES.map((s, i) => `<div class="slide ${i === UI.slide ? 'on' : ''}"><div class="bg"></div><div class="rose"></div><img class="bimg" src="${bottle(s[3])}"><div class="txt"><h3>${s[0]}</h3><h2>${s[1]}</h2><p>${s[2]}</p><button class="btn-gold" data-act="cat" data-v="all">${ic('chev')} تسوق الآن</button></div></div>`).join('')}</div>
  <div class="dots">${SLIDES.map((_, i) => `<span class="${i === UI.slide ? 'on' : ''}"></span>`).join('')}</div>
  <div class="sec">الأقسام الرئيسية</div><div class="cats">${catHtml}</div>
  <div class="sec">منتجات مميزة</div><div class="grid">${feat.map(productCard).join('')}</div>
  <div class="gift">${ic('gift')}<div><b>هدية فاخرة مع كل طلب</b><span>لأنك تستحق الأفضل</span></div></div>`;
}

function listView(withCats) {
  if (!withCats) S.cat = 'offers';
  const chips = [['all', 'الكل'], ...Object.entries(CATS)].map(([k, l]) => `<button class="btn-gold" style="height:36px;font-size:13px;padding:0 14px;flex:none;${S.cat === k ? '' : 'background:none;color:var(--gold1);border:1px solid var(--line);box-shadow:none'}" data-act="cat" data-v="${k}">${l}</button>`).join('');
  const list = filtered();
  return `${searchBar()}
  <div style="display:flex;gap:8px;overflow-x:auto;margin-bottom:12px;scrollbar-width:none">${chips}</div>
  <div class="sec">${S.cat === 'all' ? 'كل العطور' : CATS[S.cat]} (${list.length})</div>
  ${list.length ? `<div class="grid">${list.map(productCard).join('')}</div>` : `<div class="empty">${ic('search')}<b>لا توجد نتائج</b>جرّب كلمة بحث أخرى أو قسماً مختلفاً</div>`}`;
}

function favView() {
  const list = S.favs.map(prod).filter(Boolean);
  return `<div class="sec">المفضلة (${list.length})</div>` + (list.length
    ? `<div class="grid">${list.map(productCard).join('')}</div>`
    : `<div class="empty">${ic('heart')}<b>قائمة المفضلة فارغة</b>اضغط على القلب في أي عطر لحفظه هنا<br><button class="btn-gold" data-act="cat" data-v="all">تصفح العطور</button></div>`);
}

function cartView() {
  const t = totals();
  const hero = `<div class="cart-hero">${ic('cart')}<h2>سلة المشتريات</h2><p>مراجعة منتجاتك قبل إتمام الطلب</p></div>`;
  if (!t.lines.length) return hero + `<div class="empty">${ic('cart')}<b>سلتك فارغة</b>أضف عطورك المفضلة لتبدأ<br><button class="btn-gold" data-act="cat" data-v="all">تسوق الآن</button></div>`;
  const items = t.lines.map(l => {
    const [a, b] = l.p.c || ['#d4af37', '#5a3d0a'];
    const img = l.p.img ? `<img src="${esc(l.p.img)}" onerror="this.src='${bottle(l.p.c)}'">` : `<img src="${bottle(l.p.c)}">`;
    return `<div class="item"><div class="im" style="background:radial-gradient(circle,${a}66,${b}44 70%,#0a0806)">${img}</div>
      <div class="in"><b>${esc(l.p.name)}</b><small>${esc(l.p.size || '')}</small>
      <div class="ir"><div class="qty"><button data-act="qty" data-id="${l.id}" data-d="-1">${ic('minus')}</button><span>${l.qty}</span><button data-act="qty" data-id="${l.id}" data-d="1">${ic('plus')}</button></div>
      <div class="price" style="flex-direction:row;gap:8px;align-items:baseline">${money(l.p.price)}${l.p.old > l.p.price ? `<s>${money(l.p.old)}</s>` : ''}</div></div></div>
      <button class="x" data-act="rm" data-id="${l.id}">${ic('xc')}</button></div>`;
  }).join('');
  return `${hero}${items}
  <div class="box coupon">${ic('tag', 'tg')}<div class="cf"><b>هل لديك كوبون خصم؟</b>
    <div class="cin"><input id="cp" placeholder="أدخل الكود" value="${esc(S.coupon || '')}"><button data-act="coupon">تطبيق</button></div></div></div>
  <div class="box sum"><h4>${ic('doc')} ملخص الطلب</h4>
    <div class="sr"><span>المجموع الفرعي</span><em>${money(t.sub)}</em></div>
    <div class="sr g"><span>${ic('tag')} خصم الكوبون${t.pct ? ` (${t.pct}%)` : ''}</span><em>${t.disc ? '-' : ''}${money(t.disc)}</em></div>
    <div class="sr g"><span>${ic('truck')} مصاريف الشحن</span><em>${money(t.ship)}</em></div>
    <div class="sr t"><span>${ic('wallet')} الإجمالي الكلي</span><em>${money(t.total)}</em></div></div>
  <button class="btn-big" data-act="checkout">${ic('lock')} إتمام الشراء الآن</button>`;
}

function accountView() {
  const u = S.user;
  const myOrders = S.orders.filter(o => o.user === u.id).slice(-5).reverse();
  return `<div class="prof"><div class="av">${esc((u.name || 'م')[0])}</div><div><b>${esc(u.name)}</b><small>${esc(u.id)}</small></div></div>
  <div class="stats"><div><b>${S.favs.length}</b><span>المفضلة</span></div><div><b>${cartCount()}</b><span>في السلة</span></div><div><b>${S.orders.filter(o => o.user === u.id).length}</b><span>طلباتي</span></div></div>
  <div class="sec">طلباتي الأخيرة</div>
  <div class="box">${myOrders.length ? myOrders.map(o => `<div class="ord"><span>#${o.id}<br><span class="status ${o.sent ? 'ok' : ''}">${o.sent ? 'تم إرساله' : 'محفوظ محلياً'}</span></span><em>${money(o.total)}</em></div>`).join('') : '<div class="note" style="margin:0">لا توجد طلبات بعد</div>'}</div>
  <div class="sec">ربط تلجرام</div>
  <div class="box">
    <label class="fld"><span>توكن البوت (Bot Token)</span><input id="tgt" value="${esc(S.tg.token)}" placeholder="123456:ABC-DEF..."></label>
    <label class="fld"><span>آيدي تلجرام (Chat ID)</span><input id="tgc" value="${esc(S.tg.chat)}" placeholder="123456789"></label>
    <button class="btn-gold" style="width:100%" data-act="savetg">${ic('send')} حفظ وتفعيل الربط</button>
    <button class="btn-line" data-act="testtg">إرسال رسالة اختبار</button>
    <div class="note">أوامر البوت (من حسابك فقط):<br>
      <code>/add الاسم | السعر | السعر قبل الخصم | القسم | الحجم</code><br>
      أرسل صورة مع الأمر نفسه كتعليق لإضافة صورة المنتج. القسم: <code>women</code> <code>men</code> <code>unisex</code> <code>gifts</code><br>
      <code>/discount رقم | السعر الجديد | السعر القديم</code> &nbsp; <code>/del رقم</code> &nbsp; <code>/list</code><br>
      <code>/coupon كود | نسبة</code> &nbsp; <code>/orders</code> &nbsp; <code>/help</code></div>
  </div>
  <button class="btn-line" data-act="logout">تسجيل الخروج</button>
  <button class="btn-line danger" data-act="reset">مسح كل البيانات المحفوظة</button>`;
}

const GOOGLE = '<svg viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.6 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.6 5.9c4.4-4.1 7-10.1 7-17.6z"/><path fill="#FBBC05" d="M10.5 28.7A14.5 14.5 0 0 1 9.5 24c0-1.6.3-3.2.8-4.7l-7.9-6.1A24 24 0 0 0 0 24c0 3.9.9 7.5 2.6 10.8l7.9-6.1z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.6-5.9c-2.1 1.4-4.9 2.3-8.3 2.3-6.3 0-11.6-4.1-13.5-9.8l-7.9 6.1C6.5 42.6 14.6 48 24 48z"/></svg>';

function loginView() {
  const reg = UI.mode === 'register';
  return `<div class="login"><div class="top">
    <div class="lang">${ic('globe')} العربية ${ic('caret')}</div>
    <img class="big" src="${bottle(['#d4af37', '#2a1c06'])}"><div class="rose"></div>
    <div class="brand">${LOGO}</div>
    <div class="welcome"><h2>${reg ? 'أهلاً بك' : 'مرحباً بك مجدداً'}</h2><p>${reg ? 'أنشئ حسابك للمتابعة' : 'تسجيل الدخول للمتابعة'}</p></div></div>
  <form id="lf" autocomplete="off">
    ${reg ? `<div class="inp">${ic('user')}<input id="ln" placeholder="الاسم الكامل"></div>` : ''}
    <div class="inp">${ic('mail')}<input id="lu" placeholder="البريد الإلكتروني أو رقم الجوال"></div>
    <div class="inp">${ic('lock')}<input id="lp" type="${UI.showPw ? 'text' : 'password'}" placeholder="كلمة المرور"><button type="button" class="eye" data-act="togglepw">${ic(UI.showPw ? 'eye' : 'eyeoff')}</button></div>
    <div class="err">${esc(UI.err)}</div>
    <div class="row2"><button type="button" class="chk" data-act="remember"><i class="${S.remember ? '' : 'off'}">${ic('check')}</i>تذكرني</button><button type="button" class="lnk" data-act="forgot">نسيت كلمة المرور؟</button></div>
    <button class="btn-big" type="submit">${reg ? 'إنشاء الحساب' : 'تسجيل الدخول'} ${ic('send')}</button>
    <div class="divider">أو المتابعة عبر</div>
    <button type="button" class="btn-google" data-act="google">${GOOGLE} تسجيل الدخول بواسطة جوجل</button>
    <div class="switch">${reg ? 'لديك حساب بالفعل؟' : 'ليس لديك حساب؟'}<button type="button" data-act="mode">${reg ? 'تسجيل الدخول' : 'إنشاء حساب جديد'}</button></div>
  </form></div>`;
}

/* ---------------- تسجيل الدخول ---------------- */
function submitLogin() {
  const id = $('#lu').value.trim(), pw = $('#lp').value, nm = $('#ln') ? $('#ln').value.trim() : '';
  if (!id || !pw) return setErr('أدخل البريد أو الجوال وكلمة المرور');
  if (UI.mode === 'register') {
    if (!nm) return setErr('أدخل اسمك الكامل');
    if (pw.length < 4) return setErr('كلمة المرور يجب ألا تقل عن 4 أحرف');
    if (S.users.some(u => u.id === id)) return setErr('هذا الحساب مسجّل مسبقاً، سجّل الدخول');
    const u = { id, name: nm, pw: hash(pw) };
    S.users.push(u); S.user = { id: u.id, name: u.name };
  } else {
    const u = S.users.find(x => x.id === id && x.pw === hash(pw));
    if (!u) return setErr('بيانات الدخول غير صحيحة');
    S.user = { id: u.id, name: u.name };
  }
  UI.err = ''; S.screen = 'home'; save(); render();
}
function setErr(m) { UI.err = m; const e = $('.err'); if (e) e.textContent = m; }

/* ---------------- تلجرام ---------------- */
let pollRun = false;
async function tg(method, params = {}) {
  const token = S.tg.token; if (!token) throw new Error('لم يتم إدخال توكن البوت');
  const r = await fetch(`https://api.telegram.org/bot${token}/${method}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(params) });
  const j = await r.json(); if (!j.ok) throw new Error(j.description || 'خطأ تلجرام'); return j.result;
}
const say = (text) => tg('sendMessage', { chat_id: S.tg.chat, text, parse_mode: 'HTML' }).catch(() => { });
const h = s => String(s ?? '').replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));

function orderMessage(o) {
  const lines = o.items.map((i, n) => `${n + 1}. ${h(i.name)} (${h(i.size || '')}) × ${i.qty} — ${money(i.price * i.qty)}`).join('\n');
  return `🛍 <b>طلب جديد #${o.id}</b>\n\n👤 <b>الاسم:</b> ${h(o.name)}\n📞 <b>الجوال:</b> ${h(o.phone)}\n📍 <b>العنوان:</b> ${h(o.address)}\n${o.note ? '📝 <b>ملاحظات:</b> ' + h(o.note) + '\n' : ''}🔑 <b>الحساب:</b> ${h(o.user)}\n\n━━━━━━━━━━\n${lines}\n━━━━━━━━━━\n` +
    `المجموع الفرعي: ${money(o.sub)}\n` + (o.coupon ? `🏷 كوبون ${h(o.coupon)} (${o.pct}%): -${money(o.disc)}\n` : '') + `🚚 الشحن: ${money(o.ship)}\n💰 <b>الإجمالي: ${money(o.total)}</b>\n🕒 ${new Date(o.time).toLocaleString('ar')}`;
}

async function confirmOrder() {
  const name = $('#on').value.trim(), phone = $('#op').value.trim(), address = $('#oa').value.trim(), note = $('#oo').value.trim();
  if (!name || !phone || !address) return toast('أكمل الاسم والجوال والعنوان');
  const t = totals(); if (!t.lines.length) return;
  const o = {
    id: S.nextOid++, user: S.user.id, name, phone, address, note, time: Date.now(),
    items: t.lines.map(l => ({ id: l.id, name: l.p.name, size: l.p.size, price: l.p.price, qty: l.qty })),
    sub: t.sub, coupon: S.coupon, pct: t.pct, disc: t.disc, ship: t.ship, total: t.total, sent: false
  };
  const btn = $('#cfo'); btn.disabled = true; btn.textContent = 'جاري الإرسال...';
  try { await tg('sendMessage', { chat_id: S.tg.chat, text: orderMessage(o), parse_mode: 'HTML' }); o.sent = true; }
  catch (e) { toast('تم حفظ الطلب لكن لم يُرسل لتلجرام: ' + e.message); }
  S.orders.push(o); S.cart = []; S.coupon = null; S.user.phone = phone; S.user.address = address;
  closeModal(); S.screen = 'account'; save(); render();
  if (o.sent) toast('✅ تم إرسال طلبك #' + o.id + ' بنجاح');
}

function startPolling() {
  if (pollRun || !S.tg.token || !S.tg.chat) return;
  pollRun = true;
  (async function loop() {
    while (S.tg.token && S.tg.chat) {
      try {
        const ups = await tg('getUpdates', { offset: S.tg.offset, timeout: CONFIG.POLL_SECONDS, allowed_updates: ['message'] });
        for (const u of ups) { S.tg.offset = u.update_id + 1; await handleUpdate(u).catch(() => { }); }
        if (ups.length) save();
      } catch (e) { await new Promise(r => setTimeout(r, 6000)); }
    }
    pollRun = false;
  })();
}

const CAT_MAP = { women: 'women', 'نسائي': 'women', 'نسائية': 'women', men: 'men', 'رجالي': 'men', 'رجالية': 'men', unisex: 'unisex', 'للجنسين': 'unisex', gifts: 'gifts', 'هدايا': 'gifts', 'هدية': 'gifts' };
const HELP = `أوامر المتجر:\n/add الاسم | السعر | السعر قبل الخصم (0 = بدون خصم) | القسم | الحجم\n(أرسل صورة مع الأمر كتعليق لإضافة صورة المنتج)\n/discount رقم | السعر الجديد | السعر القديم\n/del رقم\n/list\n/coupon كود | نسبة\n/orders`;

async function handleUpdate(u) {
  const m = u.message; if (!m || String(m.chat.id) !== String(S.tg.chat)) return;
  const text = (m.text || m.caption || '').trim(); if (!text.startsWith('/')) return;
  const cmd = text.split(/\s+/)[0].split('@')[0].toLowerCase();
  const args = text.slice(text.split(/\s+/)[0].length).trim();
  const parts = args.split('|').map(x => x.trim());
  const refresh = () => { save(); if (S.user) { const v = $('#view'), top = v ? v.scrollTop : 0; render(); const nv = $('#view'); if (nv) nv.scrollTop = top; } };

  if (cmd === '/start' || cmd === '/help') return say(HELP);

  if (cmd === '/add') {
    const [name, price, old, cat, size] = parts;
    if (!name || !(parseFloat(price) > 0)) return say('❌ الصيغة:\n/add الاسم | السعر | السعر قبل الخصم | القسم | الحجم');
    const p = { id: S.nextPid++, name, price: parseFloat(price), old: parseFloat(old) > parseFloat(price) ? parseFloat(old) : 0, cat: CAT_MAP[(cat || '').toLowerCase()] || 'unisex', size: size || '100 مل', rating: 4.8, reviews: '0', badge: '🆕 جديد', c: PALETTE[Math.floor(Math.random() * PALETTE.length)] };
    if (m.photo && m.photo.length) {
      try { const f = await tg('getFile', { file_id: m.photo[m.photo.length - 1].file_id }); p.img = `https://api.telegram.org/file/bot${S.tg.token}/${f.file_path}`; } catch (e) { }
    }
    S.products.unshift(p); refresh();
    return say(`✅ تمت إضافة المنتج #${p.id}\n${p.name}\nالسعر: ${money(p.price)}${p.old ? ' (قبل الخصم ' + money(p.old) + ')' : ' (بدون خصم)'}\nالقسم: ${CATS[p.cat]}${p.img ? '\n🖼 مع صورة' : ''}`);
  }
  if (cmd === '/discount') {
    const p = prod(parseInt(parts[0])); if (!p) return say('❌ رقم المنتج غير موجود. استخدم /list');
    const np = parseFloat(parts[1]), op = parseFloat(parts[2]);
    if (!(np > 0)) return say('❌ الصيغة: /discount رقم | السعر الجديد | السعر القديم');
    p.price = np; p.old = op > np ? op : 0; refresh();
    return say(`✅ تم التحديث: ${p.name}\n${money(p.price)}${p.old ? ' بدلاً من ' + money(p.old) : ' (بدون خصم)'}`);
  }
  if (cmd === '/del') {
    const id = parseInt(parts[0]), p = prod(id); if (!p) return say('❌ رقم المنتج غير موجود');
    S.products = S.products.filter(x => x.id !== id); S.cart = S.cart.filter(x => x.id !== id); S.favs = S.favs.filter(x => x !== id); refresh();
    return say('🗑 تم حذف: ' + p.name);
  }
  if (cmd === '/list') return say(S.products.map(p => `#${p.id} ${p.name} — ${money(p.price)}${p.old ? ' (خصم)' : ''}`).join('\n') || 'لا توجد منتجات');
  if (cmd === '/coupon') {
    const code = (parts[0] || '').toUpperCase(), pct = parseFloat(parts[1]);
    if (!code || !(pct > 0 && pct <= 100)) return say('❌ الصيغة: /coupon كود | نسبة');
    S.coupons[code] = pct; save(); return say(`✅ تم إنشاء الكوبون ${code} بخصم ${pct}%`);
  }
  if (cmd === '/orders') return say(S.orders.slice(-10).map(o => `#${o.id} ${o.name} — ${money(o.total)}`).join('\n') || 'لا توجد طلبات');
}

/* ---------------- الأحداث ---------------- */
function openCheckout() {
  const t = totals(); if (!t.lines.length) return toast('السلة فارغة');
  $('#modal').innerHTML = `<div class="sheet"><h3>تأكيد الطلب <button data-act="closemodal">${ic('x')}</button></h3>
    <label class="fld"><span>الاسم</span><input class="rtl" id="on" value="${esc(S.user.name)}"></label>
    <label class="fld"><span>رقم الجوال</span><input id="op" value="${esc(S.user.phone || (/^[+\d\s-]+$/.test(S.user.id) ? S.user.id : ''))}"></label>
    <label class="fld"><span>عنوان التوصيل</span><textarea class="rtl" id="oa">${esc(S.user.address || '')}</textarea></label>
    <label class="fld"><span>ملاحظات (اختياري)</span><input class="rtl" id="oo"></label>
    <div class="tot"><span>الإجمالي</span><em>${money(t.total)}</em></div>
    <button class="btn-big" id="cfo" data-act="confirmorder">${ic('check')} تأكيد وإرسال الطلب</button></div>`;
  $('#modal').classList.add('show');
}
function closeModal() { $('#modal').classList.remove('show'); $('#modal').innerHTML = ''; }

document.addEventListener('click', e => {
  const el = e.target.closest('[data-act]'); if (!el) return;
  const a = el.dataset.act, id = +el.dataset.id;
  switch (a) {
    case 'nav': if (el.dataset.v === 'categories') S.cat = 'all'; if (el.dataset.v === 'offers') S.cat = 'offers'; go(el.dataset.v, el.dataset.v === 'categories' ? { q: '' } : {}); break;
    case 'cat': go(el.dataset.v === 'offers' ? 'offers' : 'categories', { cat: el.dataset.v, q: S.screen === 'categories' || S.screen === 'offers' ? S.q : '' }); break;
    case 'fav': S.favs = isFav(id) ? S.favs.filter(x => x !== id) : [...S.favs, id]; save(); keepScroll(); toast(isFav(id) ? 'أضيف إلى المفضلة' : 'أزيل من المفضلة'); break;
    case 'add': { const it = S.cart.find(x => x.id === id); it ? it.qty++ : S.cart.push({ id, qty: 1 }); save(); keepScroll(); toast('أضيف إلى السلة'); break; }
    case 'qty': { const it = S.cart.find(x => x.id === id); if (it) { it.qty += +el.dataset.d; if (it.qty < 1) S.cart = S.cart.filter(x => x.id !== id); } save(); keepScroll(); break; }
    case 'rm': S.cart = S.cart.filter(x => x.id !== id); save(); keepScroll(); break;
    case 'clearcart': if (S.cart.length && confirm('تفريغ السلة بالكامل؟')) { S.cart = []; S.coupon = null; save(); render(); } break;
    case 'coupon': { const c = ($('#cp').value || '').trim().toUpperCase(); if (!c) { S.coupon = null; save(); return keepScroll(); } if (S.coupons[c]) { S.coupon = c; save(); keepScroll(); toast('تم تطبيق الكوبون ' + c); } else toast('كود الخصم غير صحيح'); break; }
    case 'checkout': openCheckout(); break;
    case 'confirmorder': confirmOrder(); break;
    case 'closemodal': closeModal(); break;
    case 'bell': toast('لا توجد إشعارات جديدة'); break;
    case 'togglepw': { const v = { u: $('#lu').value, p: $('#lp').value, n: $('#ln') ? $('#ln').value : '' }; UI.showPw = !UI.showPw; render(); $('#lu').value = v.u; $('#lp').value = v.p; if ($('#ln')) $('#ln').value = v.n; break; }
    case 'remember': S.remember = !S.remember; save(); { const v = $('#lu').value, p = $('#lp').value; render(); $('#lu').value = v; $('#lp').value = p; } break;
    case 'mode': UI.mode = UI.mode === 'login' ? 'register' : 'login'; UI.err = ''; render(); break;
    case 'forgot': toast('تواصل مع المتجر لاستعادة كلمة المرور'); break;
    case 'google': { const n = prompt('تجريبي: أدخل اسمك للمتابعة بحساب جوجل'); if (n) { const id = n.trim().toLowerCase().replace(/\s+/g, '') + '@gmail.com'; S.user = { id, name: n.trim() }; S.screen = 'home'; save(); render(); } break; }
    case 'logout': S.user = null; S.screen = 'home'; save(); render(); break;
    case 'savetg': S.tg.token = $('#tgt').value.trim(); S.tg.chat = $('#tgc').value.trim(); S.tg.offset = 0; save(); toast('تم حفظ إعدادات تلجرام'); startPolling(); break;
    case 'testtg': { S.tg.token = $('#tgt').value.trim(); S.tg.chat = $('#tgc').value.trim(); save(); tg('sendMessage', { chat_id: S.tg.chat, text: '✅ تم ربط متجر العطور بنجاح!\n\n' + HELP }).then(() => { toast('تم إرسال رسالة الاختبار'); startPolling(); }).catch(err => toast('فشل: ' + err.message)); break; }
    case 'reset': if (confirm('سيتم حذف الحسابات والسلة والمفضلة والطلبات. متابعة؟')) { localStorage.removeItem(CONFIG.STORAGE_KEY); S = load(); render(); } break;
  }
});

/* إبقاء مكان التمرير عند إعادة الرسم */
function keepScroll() { const v = $('#view'), t = v ? v.scrollTop : 0; render(); const nv = $('#view'); if (nv) nv.scrollTop = t; }

document.addEventListener('submit', e => { e.preventDefault(); if (e.target.id === 'lf') submitLogin(); });

/* مؤقت البنر */
setInterval(() => {
  if (!S.user || S.screen !== 'home') return;
  const sl = document.querySelectorAll('.slide'), ds = document.querySelectorAll('.dots span'); if (!sl.length) return;
  UI.slide = (UI.slide + 1) % sl.length;
  sl.forEach((s, i) => s.classList.toggle('on', i === UI.slide)); ds.forEach((d, i) => d.classList.toggle('on', i === UI.slide));
}, 4000);

/* ملاءمة المقاس 393×873 مع الشاشة */
function fit() { const s = Math.min(innerWidth / 393, innerHeight / 873); $('#app').style.transform = `translate(-50%,-50%) scale(${s})`; }
addEventListener('resize', fit); fit();

/* بدء التشغيل */
render();
startPolling();
