# Carreira Craque — instalar como app no Android

Esta versão foi preparada como **PWA instalável**: abre em tela própria, pode ter ícone na tela inicial e guarda os arquivos principais para uso offline depois do primeiro carregamento. Ela não é um APK compilado.

## Como instalar
1. Publique a pasta `CarreiraCraque_v1.7` em um site com HTTPS (por exemplo, seu serviço de hospedagem). O recurso de instalação não funciona abrindo o `index.html` diretamente como arquivo.
2. No Android, abra o endereço publicado pelo Google Chrome.
3. Espere o jogo carregar e toque no menu `⋮` do Chrome.
4. Escolha **Instalar app** ou **Adicionar à tela inicial** e confirme.
5. Abra pelo ícone criado para jogar em uma janela própria.

## Importante
- Não apague os arquivos `manifest.webmanifest`, `service-worker.js` nem a pasta `icons`.
- A primeira abertura precisa de internet para baixar os arquivos; o modo offline depende de o cache ter sido preenchido corretamente.
- Escudos que usam endereços externos ainda podem precisar de internet.
- O progresso continua usando o sistema de salvamento que já existia no jogo; faça backup antes de trocar versões.

Para gerar um APK Android de verdade, é necessário empacotar esta aplicação com Android Studio/Capacitor e compilar com o Android SDK.
