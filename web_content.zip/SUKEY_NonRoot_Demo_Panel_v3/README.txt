SUKEY PRO v3 — LOGIN + FREE FIRE LAUNCHER FIX
Files: index.html, style.css, script.js

Demo login:
Username: sukey
Password: 1234

Launcher fix:
- The button now tries Android's standard MAIN/LAUNCHER intent for package com.dts.freefireth.
- Spck's built-in Preview/WebView may block launching another app. If it does, open index.html in Chrome or launch Free Fire manually from the app drawer.
- This package name is for the standard Free Fire edition; Free Fire MAX can use a different package.
- The game must already be installed.

Important:
This is a local demo login, not secure authentication. The aim/radar controls are visual-only and do not modify Free Fire.
