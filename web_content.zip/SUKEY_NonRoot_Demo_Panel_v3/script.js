const toast=document.getElementById('toast');let toastTimer;
function notify(message){toast.textContent=message;toast.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove('show'),2300);}
const loginForm=document.getElementById('loginForm');
loginForm.addEventListener('submit',e=>{
 e.preventDefault();
 const user=document.getElementById('username').value.trim();
 const pass=document.getElementById('password').value;
 // Demo-only credentials. This is not secure authentication.
 if(user.toLowerCase()==='sukey'&&pass==='1234'){
  document.getElementById('loginScreen').classList.add('hidden');
  document.getElementById('panelScreen').classList.remove('hidden');
  document.getElementById('welcomeUser').textContent=user;
  notify('Login successful. Welcome to SUKEY PRO.');
 }else{notify('Wrong demo login. Try sukey / 1234.');}
});
document.getElementById('logoutBtn').addEventListener('click',()=>{
 document.getElementById('panelScreen').classList.add('hidden');
 document.getElementById('loginScreen').classList.remove('hidden');
 document.getElementById('password').value='';
 notify('Logged out.');
});
document.getElementById('freeFireBtn').addEventListener('click',()=>{
 // Android launcher intent. WebView previews may block external-app intents.
 const intentUrl = 'intent:#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;package=com.dts.freefireth;end';
 const startedAt = Date.now();
 window.location.href = intentUrl;
 setTimeout(()=>{
   if(Date.now() - startedAt >= 900) {
     notify('If nothing opened, this preview blocks app launching. Open Free Fire from your app drawer, or test this page in Chrome.');
   }
 }, 1100);
});
const modeText=document.getElementById('modeText'),masterBtn=document.getElementById('masterBtn');let running=false;
masterBtn.addEventListener('click',()=>{running=!running;modeText.textContent=running?'ACTIVE DEMO':'IDLE';masterBtn.textContent=running?'STOP DEMO':'START DEMO';notify(running?'Practice demo started — no game is modified.':'Practice demo stopped.');});
document.querySelectorAll('input[data-feature]').forEach(input=>input.addEventListener('change',()=>{
 const feature=input.dataset.feature;
 if(feature==='Location Radar'){document.getElementById('radar').classList.toggle('active',input.checked);document.getElementById('radarMessage').textContent=input.checked?'Fictional dots shown — not real player locations.':'Enable Location Radar to show simulated dots.';}
 if(feature==='Crosshair')document.getElementById('crosshair').style.display=input.checked?'block':'none';
 notify(feature+(input.checked?' demo enabled.':' demo disabled.'));
}));
const sensitivity=document.getElementById('sensitivity');sensitivity.addEventListener('input',()=>document.getElementById('sensValue').textContent=sensitivity.value);
