Аль-Фатиха Викторина APK

Исправленная структура для AndroidIDE.

Сборка:
Gradle command:
:app:assembleDebug

Если AndroidIDE предлагает свою версию Gradle — используйте её.
