PROTOCOL: CHAOS — проект Android

Это исходный проект Android Studio, НЕ готовый APK.
Он открывает игру из app/src/main/assets/index.html внутри Android WebView.
Игра работает офлайн.

Как собрать APK:
1. Открой эту папку в Android Studio на компьютере.
2. Дождись синхронизации Gradle. Если попросит, установи Android SDK Platform 35.
3. Выбери Build → Build Bundle(s) / APK(s) → Build APK(s).
4. Готовый тестовый APK появится в app/build/outputs/apk/debug/app-debug.apk.

Для Google Play нужен подписанный AAB:
Build → Generate Signed Bundle / APK → Android App Bundle.
Создай собственный ключ подписи и никому его не передавай.
