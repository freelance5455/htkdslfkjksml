Madar Halaqat - Full v1
Two separate apps connected to Supabase.
MadarTeacher = teacher app
MadarManager = manager app
Upload each folder separately to Netlify Drop.
