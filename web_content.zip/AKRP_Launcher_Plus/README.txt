AKRP — All Kerala Roleplay | Launcher + 3D single-player prototype

WHAT'S IN THIS UPDATE
- AKRP branding and server profile label: "Akrp all kerala roleplay"
- Server password label shown as 786 (demo label only; not an actual hosted server)
- First-time profile: choose username, create password, re-enter password to confirm
- Profile is saved locally in the same browser/device
- On later visits, login using saved username and password
- Small 3D town with houses, local shop, tea shop, trees, roads and a player avatar
- WASD / arrow keys to move; drag mouse or touch to look around
- Town directory buttons can guide the player toward locations
- Local chat preview
- Responsive dark gaming UI

HOW TO RUN
1. Extract the ZIP.
2. Open index.html in Chrome, Edge or Firefox while connected to the internet.
3. The Three.js 3D engine is loaded from a CDN, so an internet connection is required for the 3D scene.
4. Create a username and password, confirm it, then enter the world.

IMPORTANT
- This is a single-player prototype. It does NOT yet create a real online server or let friends join.
- "786" is displayed as the intended server password label, but there is no live server to authenticate against.
- The local profile is stored in browser localStorage. The password is stored as demo data and is NOT securely hashed. Do not use a real or reused password.
- The next stage can improve the world and gameplay; multiplayer server/authentication should be implemented later with a real backend.


UPDATE: LAUNCHER PLUS
- Preserves the AKRP launcher/profile screen.
- Adds a login-screen soundtrack using the audio file supplied by the user.
- Music tries to start on the first click/tap; browser autoplay rules may require pressing the play button.
- Music pauses when entering the game. It can be toggled from the in-game extra features menu.
- Extra feature controls: show/hide world guide and toggle a simple sunny/rainy lighting mood.
- The 3D game and chat are still single-player/local prototype features.
- The profile/password remain local browser demo data, not secure online accounts.
