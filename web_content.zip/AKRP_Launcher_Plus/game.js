(() => {
const $ = id => document.getElementById(id);
const auth = $("auth-screen"), game = $("game-screen"), form = $("register-form");
const error = $("auth-error");
const ACCOUNT_KEY = "akrpLocalAccountV1";
const music = $("login-music");
const musicToggle = $("music-toggle");
let musicStarted = false;
function startMusic(){
  if(!music) return;
  music.volume = 0.42;
  const promise = music.play();
  if(promise && promise.then){promise.then(()=>{musicStarted=true;if(musicToggle)musicToggle.textContent="Ⅱ";}).catch(()=>{if(musicToggle)musicToggle.textContent="▶";});}
}
function toggleMusic(){
  if(!music)return;
  if(music.paused){startMusic();}else{music.pause();if(musicToggle)musicToggle.textContent="▶";}
}
if(musicToggle)musicToggle.addEventListener("click",toggleMusic);
// Start the uploaded soundtrack on the first user interaction on the login screen.
auth.addEventListener("pointerdown",()=>{if(!musicStarted && music && music.paused)startMusic();},{once:true});
let account = loadAccount();

function loadAccount(){try{return JSON.parse(localStorage.getItem(ACCOUNT_KEY)||"null")}catch{return null}}
function showError(msg){error.textContent=msg;error.hidden=false}
function enterWorld(name){
  auth.hidden=true;game.hidden=false;
  $("hud-username").textContent=name;$("character-name").textContent=name;
  $("avatar").textContent=name.charAt(0).toUpperCase();$("big-avatar").textContent=name.charAt(0).toUpperCase();
  $("username").value=name;
  if(window.AKRPWorld) window.AKRPWorld.start();
  if(music && !music.paused){music.pause();if(musicToggle)musicToggle.textContent="▶";}
}
function resetFormForAccount(){
  if(account){
    $("auth-title").textContent="Welcome back, "+account.username;
    $("username").value=account.username;
    $("username").readOnly=true;
    $("password").setAttribute("autocomplete","current-password");
    $("password").placeholder="Enter your saved password";
    $("confirm-password").parentElement; // keep registration form layout
    $("confirm-password").hidden=true;
    $("confirm-password").required=false;
    $("register-form").querySelector('label[for="confirm-password"]').hidden=true;
    form.querySelector("button[type=submit]").innerHTML='Log In & Enter World <span>→</span>';
    $("return-login").hidden=false;
  }
}
form.addEventListener("submit",e=>{
  e.preventDefault();error.hidden=true;
  const username=$("username").value.trim();
  const password=$("password").value;
  const confirm=$("confirm-password").value;
  if(!/^[\p{L}\p{N}_ -]{2,20}$/u.test(username)){showError("Username must be 2–20 characters. Letters, numbers, spaces, _ and - are allowed.");return}
  if(password.length<4){showError("Password must be at least 4 characters.");return}
  if(account){
    if(username!==account.username||password!==account.password){showError("Username or password is incorrect.");return}
    enterWorld(account.username);return;
  }
  if(password!==confirm){showError("Passwords do not match. Please re-enter your password.");return}
  account={username,password,createdAt:new Date().toISOString()};
  localStorage.setItem(ACCOUNT_KEY,JSON.stringify(account));
  enterWorld(username);
});
$("show-register").addEventListener("click",()=>{
  if(!confirm("Create a new local profile? This will replace the profile saved in this browser."))return;
  localStorage.removeItem(ACCOUNT_KEY);account=null;
  $("auth-title").textContent="Welcome to AKRP";$("username").readOnly=false;
  $("password").value="";$("confirm-password").value="";$("confirm-password").hidden=false;$("confirm-password").required=true;
  form.querySelector('label[for="confirm-password"]').hidden=false;
  form.querySelector("button[type=submit]").innerHTML='Create Profile & Enter World <span>→</span>';
  $("return-login").hidden=true;error.hidden=true;
});
$("logout").addEventListener("click",()=>{game.hidden=true;auth.hidden=false;error.hidden=true;});
const gameMusicBtn=$("toggle-music-game");
if(gameMusicBtn)gameMusicBtn.addEventListener("click",()=>{if(music){if(music.paused){startMusic();}else{music.pause();if(musicToggle)musicToggle.textContent="▶";}toast(music.paused?"Login music paused":"Login music playing");}});
const mapBtn=$("toggle-map");
if(mapBtn)mapBtn.addEventListener("click",()=>{const label=document.querySelector(".world-label");if(label){label.hidden=!label.hidden;toast(label.hidden?"World guide hidden":"World guide shown")}});
const weatherBtn=$("toggle-weather");
let rainy=false;
if(weatherBtn)weatherBtn.addEventListener("click",()=>{rainy=!rainy;if(window.AKRPWorld&&window.AKRPWorld.setWeather)window.AKRPWorld.setWeather(rainy);toast(rainy?"Rainy mood enabled":"Sunny weather restored")});
if(account)resetFormForAccount();

const chatForm=$("chat-form");
chatForm.addEventListener("submit",e=>{
  e.preventDefault();const input=$("chat-input"),msg=input.value.trim();if(!msg)return;
  addChat(account?.username||"Player",msg);input.value="";
});
function addChat(name,msg){
  const line=document.createElement("div");line.className="chat-line";
  const b=document.createElement("b");b.textContent=name;
  const span=document.createElement("span");span.textContent=msg;
  line.append(b,span);$("chat-messages").append(line);$("chat-messages").scrollTop=$("chat-messages").scrollHeight;
}
let toastTimer;
function toast(msg){const t=$("toast");t.textContent=msg;t.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.hidden=true,2300)}
document.querySelectorAll("[data-place]").forEach(btn=>btn.addEventListener("click",()=>{
  const place=btn.dataset.place;
  const names={house:"Small House",shop:"Local Shop",tea:"Chaya Kada",tree:"Green Park"};
  $("location-name").textContent=names[place];
  if(window.AKRPWorld)window.AKRPWorld.goTo(place);
  toast("Marked destination: "+names[place]);
}));

// Three.js world. CDN connection is needed for the 3D scene.
function initWorld(){
  const canvas=$("world"),wrap=$("world-wrap");
  if(!window.THREE){canvas.style.display="none";wrap.style.background="linear-gradient(#9fc9b5,#648f73)";toast("3D engine needs internet. Open this page online and reload.");return}
  const THREE=window.THREE;
  const scene=new THREE.Scene();scene.background=new THREE.Color(0x9dc8b6);scene.fog=new THREE.Fog(0x9dc8b6,45,135);
  const camera=new THREE.PerspectiveCamera(62,1,0.1,250);
  const renderer=new THREE.WebGLRenderer({canvas,antialias:true});
  renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
  renderer.outputColorSpace=THREE.SRGBColorSpace;
  scene.add(new THREE.HemisphereLight(0xe5fff2,0x52634c,2.0));
  const sun=new THREE.DirectionalLight(0xfff0d0,2.5);sun.position.set(-25,38,20);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);scene.add(sun);
  const mat=(color,roughness=0.9)=>new THREE.MeshStandardMaterial({color,roughness});
  const grass=mat(0x67966c),road=mat(0x434d4d),roadLine=mat(0xe8dfb4),concrete=mat(0xaaa99b),wall1=mat(0xe2c8a0),wall2=mat(0xd8e0cc),wall3=mat(0xe7b99d),roof=mat(0x8b5140),roof2=mat(0x596c69),dark=mat(0x293d40),glass= new THREE.MeshStandardMaterial({color:0x79b9bc,roughness:.3,metalness:.1}),leaf=mat(0x286d45),leaf2=mat(0x438b51),trunk=mat(0x6b4931),white=mat(0xf3eee0),sign=mat(0x153e38),playerMat=mat(0x2a4458),skin=mat(0xc88e66);
  function box(w,h,d,m,x,y,z,shadows=true){const mesh=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);mesh.position.set(x,y,z);mesh.castShadow=shadows;mesh.receiveShadow=true;scene.add(mesh);return mesh}
  function cylinder(rt,rb,h,m,x,y,z,seg=8){const mesh=new THREE.Mesh(new THREE.CylinderGeometry(rt,rb,h,seg),m);mesh.position.set(x,y,z);mesh.castShadow=true;scene.add(mesh);return mesh}
  function sphere(r,m,x,y,z,seg=10){const mesh=new THREE.Mesh(new THREE.SphereGeometry(r,seg,8),m);mesh.position.set(x,y,z);mesh.castShadow=true;scene.add(mesh);return mesh}
  box(180,.4,180,grass,0,-.3,0,false);
  // Road and lane markings
  box(12,.08,150,road,0,-.02,0,false);box(150,.08,10,road,0,-.01,0,false);
  for(let z=-68;z<70;z+=9)box(.16,.03,4,roadLine,0,.04,z,false);
  for(let x=-68;x<70;x+=9)box(4,.03,.16,roadLine,x,.04,0,false);
  // Sidewalks
  box(16,.15,150,concrete,14,.01,0,false);box(16,.15,150,concrete,-14,.01,0,false);
  box(150,.15,14,concrete,0,.01,12,false);box(150,.15,14,concrete,0,.01,-12,false);
  function makeHouse(x,z,wall,roofMat,label,scale=1){
    const w=6*scale,h=3.3*scale,d=5*scale;
    box(w,h,d,wall,x,h/2,z);
    // pitched roof approximated by a coloured raised roof slab and triangular gables
    const roofMesh=box(w+0.7*scale,.35*scale,d+0.7*scale,roofMat,x,h+.15*scale,z);
    roofMesh.rotation.z=.03;
    box(1.1*scale,2*scale,.12*scale,dark,x,.95*scale,z+d/2+.07);
    box(.8*scale,.8*scale,.1*scale,glass,x-1.65*scale,1.8*scale,z+d/2+.08);
    box(.8*scale,.8*scale,.1*scale,glass,x+1.65*scale,1.8*scale,z+d/2+.08);
    box(w+1,.13,d+.8,concrete,x,.1,z);
    if(label){
      box(3.8*scale,.6*scale,.15*scale,sign,x,h-.1,z+d/2+.18);
      // label boards are abstract; text is shown in the directory
    }
    return {x,z};
  }
  const places={
    house:makeHouse(-25,-20,wall1,roof,"HOUSE",1.15),
    shop:makeHouse(23,-19,wall2,roof2,"SHOP",1.15),
    tea:makeHouse(25,19,wall3,roof,"TEA",.95),
    tree:{x:-26,z:23}
  };
  // Market stalls and colourful awnings
  for(let i=0;i<3;i++){
    const x=18+i*4;
    box(3,.18,2.4,i%2?wall3:wall1,x,.9,2);
    for(const dx of [-1.3,1.3])for(const dz of [-.9,.9])cylinder(.07,.07,1.8,trunk,x+dx,.9,2+dz,6);
    box(3.2,.18,2.6,i%2?roof:sign,x,2,2);
  }
  // Trees around the roads and yards
  function tree(x,z,s=1){
    cylinder(.18*s,.28*s,2.2*s,trunk,x,1.1*s,z,7);
    sphere(1.15*s,leaf,x,2.6*s,z,9);
    sphere(.8*s,leaf2,x-.45*s,2.9*s,z+.15*s,8);
    sphere(.8*s,leaf,x+.48*s,3.15*s,z-.15*s,8);
  }
  const treePositions=[[-40,-35],[-38,-8],[-38,22],[-40,43],[-18,-43],[0,-43],[18,-43],[40,-38],[40,-5],[41,25],[37,44],[-20,42],[4,34],[12,33],[-31,5],[31,7],[-9,24]];
  treePositions.forEach((p,i)=>tree(p[0],p[1],i%3===0?1.15:.85));
  // Distant hills and low buildings
  const hillMat=mat(0x477c62);
  for(let i=0;i<13;i++){const a=i/13*Math.PI*2;const x=Math.cos(a)*65,z=Math.sin(a)*65;const hill=new THREE.Mesh(new THREE.ConeGeometry(12+(i%3)*4,18+(i%4)*4,7),hillMat);hill.position.set(x,4,z);hill.rotation.z=.08;scene.add(hill)}
  // Simple player avatar, positioned in town centre
  const player=new THREE.Group();scene.add(player);
  const body=new THREE.Mesh(new THREE.CylinderGeometry(.35,.42,1.05,8),playerMat);body.position.y=.9;body.castShadow=true;player.add(body);
  const head=new THREE.Mesh(new THREE.SphereGeometry(.27,12,10),skin);head.position.y=1.62;head.castShadow=true;player.add(head);
  const hair=new THREE.Mesh(new THREE.SphereGeometry(.275,12,7,0,Math.PI*2,0,Math.PI/2),dark);hair.position.y=1.72;player.add(hair);
  const legMat=mat(0x263139);
  const leg1=new THREE.Mesh(new THREE.BoxGeometry(.16,.48,.19),legMat);leg1.position.set(-.16,.25,0);player.add(leg1);
  const leg2=leg1.clone();leg2.position.x=.16;player.add(leg2);
  player.position.set(0,0,5);
  let yaw=0,pitch=-.18,keys={},drag=false,lastX=0,lastY=0,started=false,moveTarget=null;
  const forward=new THREE.Vector3(),right=new THREE.Vector3();
  function resize(){const w=wrap.clientWidth,h=wrap.clientHeight;if(!w||!h)return;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix()}
  window.addEventListener("resize",resize);resize();
  window.addEventListener("keydown",e=>{if(["w","a","s","d","ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(e.key)){keys[e.key.toLowerCase()]=true;if(game.hidden===false)e.preventDefault()}});
  window.addEventListener("keyup",e=>{keys[e.key.toLowerCase()]=false});
  canvas.addEventListener("pointerdown",e=>{drag=true;lastX=e.clientX;lastY=e.clientY;canvas.setPointerCapture?.(e.pointerId)});
  canvas.addEventListener("pointerup",()=>drag=false);canvas.addEventListener("pointercancel",()=>drag=false);
  canvas.addEventListener("pointermove",e=>{if(!drag)return;const dx=e.clientX-lastX,dy=e.clientY-lastY;lastX=e.clientX;lastY=e.clientY;yaw-=dx*.005;pitch=Math.max(-.8,Math.min(.25,pitch+dy*.003))});
  document.querySelectorAll("[data-move]").forEach(btn=>{
    const keyMap={forward:"w",back:"s",left:"a",right:"d"};const k=keyMap[btn.dataset.move];
    btn.addEventListener("pointerdown",e=>{e.preventDefault();keys[k]=true});
    ["pointerup","pointerleave","pointercancel"].forEach(ev=>btn.addEventListener(ev,()=>keys[k]=false));
  });
  function goTo(place){const p=places[place];if(!p)return;moveTarget=new THREE.Vector3(p.x,0,p.z+7);toast("Heading towards "+({house:"Small House",shop:"Local Shop",tea:"Chaya Kada",tree:"Green Park"}[place]));}
  function start(){started=true;resize()}
  function setWeather(isRainy){
    scene.background = new THREE.Color(isRainy?0x657b83:0x9dc8b6);
    scene.fog.color = new THREE.Color(isRainy?0x657b83:0x9dc8b6);
    sun.intensity = isRainy?0.75:2.5;
  }
  function animate(){
    requestAnimationFrame(animate);
    if(!game.hidden&&started){
      const speed=.16;let dx=0,dz=0;
      if(keys.w||keys.arrowup)dz-=1;if(keys.s||keys.arrowdown)dz+=1;if(keys.a||keys.arrowleft)dx-=1;if(keys.d||keys.arrowright)dx+=1;
      if(dx||dz){moveTarget=null;const len=Math.hypot(dx,dz);dx/=len;dz/=len;const rx=Math.cos(yaw),rz=Math.sin(yaw),fx=-Math.sin(yaw),fz=-Math.cos(yaw);player.position.x+=(dx*rx+dz*fx)*speed;player.position.z+=(dx*rz+dz*fz)*speed;player.rotation.y=Math.atan2(dx*rx+dz*fx,dx*rz+dz*fz);leg1.rotation.x=Math.sin(Date.now()*.014)*.6;leg2.rotation.x=-leg1.rotation.x}
      else {leg1.rotation.x=0;leg2.rotation.x=0}
      if(moveTarget){const vx=moveTarget.x-player.position.x,vz=moveTarget.z-player.position.z,dist=Math.hypot(vx,vz);if(dist>.6){player.position.x+=vx/dist*.11;player.position.z+=vz/dist*.11;player.rotation.y=Math.atan2(vx,vz)}else moveTarget=null}
      player.position.x=Math.max(-55,Math.min(55,player.position.x));player.position.z=Math.max(-65,Math.min(65,player.position.z));
      const target=new THREE.Vector3(player.position.x,1.2,player.position.z);
      const distance=9;const camX=player.position.x+Math.sin(yaw)*distance,camZ=player.position.z+Math.cos(yaw)*distance;
      camera.position.set(camX,player.position.y+4.8+pitch*5,camZ);camera.lookAt(target);
    }
    renderer.render(scene,camera);
  }
  animate();
  return {start,goTo,setWeather};
}
try{window.AKRPWorld=initWorld()}catch(e){console.error(e);toast("Could not start 3D scene. Try a recent browser with WebGL enabled.")}
})();