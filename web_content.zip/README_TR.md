# İKİLİ ARENA PRO — Android Studio kaynak projesi

## Bu sürümde
- Premium koyu/neon arayüz ve 20 oyun menüsü
- Aynı telefonda iki kişilik oyun modları
- XOX, Dörtle Kazan, Hafıza, Pong, Matematik, Sayı Tahmini, Kelime, Penaltı vb.
- PeerJS tabanlı oda kurma ve 6 haneli kodla katılma prototipi
- Android WebView kabuğu ve internet izni

## APK derleme
1. ZIP'i çıkar.
2. Android Studio > Open ile `IkiliArena_Pro` klasörünü aç.
3. Gradle senkronizasyonunun bitmesini bekle.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK: `app/build/outputs/apk/debug/app-debug.apk`

## Çevrim içi hakkında dürüst not
Oda kurma/oda koduyla bağlanma PeerJS'in herkese açık sinyal sunucusu üzerinden P2P prototipidir; her ağda bağlantı garantisi yoktur. Bu sürümde lobi bağlantısı ve hazır/bağlantı testi mesajları çalışır. Oyun hamlelerinin iki cihaz arasında tam senkronizasyonu, oda güvenliği, özel sunucu ve kalıcı eşleştirme henüz tamamlanmış değildir. Yayına çıkmadan önce kendi signaling/backend sunucusu, oda doğrulaması, bağlantı yeniden deneme ve her oyunun ağ durum senkronizasyonu eklenmelidir.

## Boyut
500 MB zorunlu bir hedef değildir. Bu proje hafif tutulmuştur; yüksek kaliteli ses/görsel paketleri eklenirse boyut artar.


## Sürüm 3.0 — 70 oyun
Toplam 70 oyun menüsü: ilk 20 oyun ve 50 yeni mini oyun. Yeni oyunlar bilgi, kelime, matematik, refleks, zamanlama, hedef, labirent seçimi, gizli hedef ve strateji tahtası mekanikleri içerir. Bazı oyunlar ortak mini-oyun mekaniklerini farklı kurallar ve hedeflerle kullanır; her biri bağımsız büyük ölçekli oyun motoru değildir.
