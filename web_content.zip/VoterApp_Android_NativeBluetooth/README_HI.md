# Voter App — Android Native Bluetooth Edition

इस प्रोजेक्ट में बिना लॉगिन वाला मौजूदा HTML ऐप Android WebView के अंदर चलता है और Android Native Bluetooth Classic (SPP) से ESC/POS थर्मल प्रिंटर पर 48mm raster पर्ची भेजता है।

## जरूरी बातें
- यह Android Studio प्रोजेक्ट है; ZIP अपने आप APK नहीं है।
- Native प्रिंटिंग के लिए सामान्य Classic Bluetooth SPP थर्मल प्रिंटर अपेक्षित है।
- प्रिंटर को पहले फोन की Android Bluetooth Settings में Pair करें।
- BLE-only प्रिंटर, या अलग proprietary protocol वाले प्रिंटर इस SPP bridge से नहीं चलेंगे।
- Hindi पर्ची HTML Canvas में raster image बनाकर भेजी जाती है, इसलिए प्रिंटर में Hindi code-page की जरूरत नहीं होती।

## APK बनाना
1. Android Studio में इस पूरी फ़ोल्डर को Open करें।
2. Gradle sync पूरा होने दें (Android Gradle Plugin 8.7.3 और SDK 35 आवश्यक)।
3. फोन USB debugging से जोड़ें या Build > Build APK(s) चुनें।
4. APK इंस्टॉल करें, Bluetooth permission दें।
5. फोन Settings में प्रिंटर Pair करें।
6. ऐप में नीले Bluetooth कार्ड पर टैप करके paired printer चुनें और प्रिंट करें।

## सीमाएँ
प्रिंटर मॉडल उपलब्ध नहीं था, इसलिए वास्तविक डिवाइस पर कनेक्शन/प्रिंट की पुष्टि नहीं की जा सकी। अधिकांश ESC/POS SPP प्रिंटर में यह तरीका काम करता है; यदि आपका मॉडल BLE-only है तो उसके लिए अलग native BLE implementation चाहिए।
