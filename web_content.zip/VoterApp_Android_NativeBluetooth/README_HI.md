# मतदाता सूची ऐप — Native Bluetooth APK प्रोजेक्ट

## इस बार दिख रहे संदेश का कारण
स्क्रीनशॉट में ऐप `https://appassets.androidplatform.net` पर चल रहा है और उसमें `AndroidPrinter` नाम का Android Native bridge मौजूद नहीं है। इसका मतलब है कि फोन में अभी भी पुराना HTML-wrapper/website-wrapper वाला APK चल रहा है। सिर्फ HTML फाइल डालने से Android Native Bluetooth API APK में नहीं जुड़ती।

## सही तरीका — इसी प्रोजेक्ट से APK बनाएं
1. ZIP को Extract करें।
2. Android Studio खोलें → **Open** → Extract किया हुआ `VoterApp_Android_NativeBluetooth` फ़ोल्डर चुनें।
3. Gradle Sync पूरा होने दें। Android SDK Platform 35 इंस्टॉल होना चाहिए।
4. Android फोन में Bluetooth चालू करें और थर्मल प्रिंटर को फोन की Bluetooth Settings में Pair करें।
5. Android Studio में **Build → Build Bundle(s) / APK(s) → Build APK(s)** चुनें।
6. Android Studio द्वारा बनाई गई APK फोन में इंस्टॉल करें। पुराना wrapper APK हटाकर नई APK इंस्टॉल करें।
7. ऐप खोलें → नीले Bluetooth कार्ड पर टैप करें → paired printer चुनें → प्रिंट करें।

## इस प्रोजेक्ट में
- बिना लॉगिन वाला मौजूदा ऐप HTML asset के रूप में शामिल है।
- `MainActivity.java` WebView में `AndroidPrinter` bridge जोड़ता है।
- Bluetooth Classic SPP paired device picker और ESC/POS print data transfer शामिल है।
- Hindi पर्ची को raster image बनाकर 48mm thermal printer को भेजने का प्रयास किया जाता है।

## जरूरी सीमा
यह Native implementation Classic Bluetooth SPP वाले ESC/POS प्रिंटर के लिए है। BLE-only या proprietary protocol वाले प्रिंटर पर यह सीधे काम नहीं करेगा। आपके प्रिंटर मॉडल के बिना वास्तविक डिवाइस पर परीक्षण/गारंटी संभव नहीं है।

**ध्यान दें:** ZIP Android Studio source project है, पहले से compiled APK नहीं। इस environment में Android SDK/Gradle build उपलब्ध नहीं है, इसलिए यहां से installable APK compile नहीं की गई है।
