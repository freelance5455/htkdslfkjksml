package com.redigram.voterapp;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_BT_CONNECT = 301;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private WebView webView;
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket socket;
    private OutputStream outputStream;
    private final ExecutorService printerExecutor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new PrinterBridge(), "AndroidPrinter");
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void askPermissionThenChoose() {
        if (bluetoothAdapter == null) {
            callJs("onNativePrinterError", "इस मोबाइल में Bluetooth उपलब्ध नहीं है।");
            return;
        }
        if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT_CONNECT);
            return;
        }
        choosePairedPrinter();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT_CONNECT) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) choosePairedPrinter();
            else callJs("onNativePrinterError", "Bluetooth अनुमति नहीं मिली। Android Settings में अनुमति दें।");
        }
    }

    private void choosePairedPrinter() {
        try {
            if (!bluetoothAdapter.isEnabled()) {
                callJs("onNativePrinterError", "पहले मोबाइल की Bluetooth Settings में Bluetooth चालू करें।");
                return;
            }
            Set<BluetoothDevice> paired = bluetoothAdapter.getBondedDevices();
            if (paired == null || paired.isEmpty()) {
                callJs("onNativePrinterError", "कोई Paired डिवाइस नहीं मिला। मोबाइल की Bluetooth Settings में थर्मल प्रिंटर Pair करें, फिर दोबारा कोशिश करें।");
                return;
            }
            final ArrayList<BluetoothDevice> devices = new ArrayList<>(paired);
            ArrayList<String> labels = new ArrayList<>();
            for (BluetoothDevice d : devices) labels.add((d.getName() == null ? "Bluetooth Device" : d.getName()) + "\n" + d.getAddress());
            runOnUiThread(() -> new AlertDialog.Builder(MainActivity.this)
                .setTitle("अपना थर्मल प्रिंटर चुनें")
                .setAdapter(new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, labels),
                    (dialog, which) -> connectDevice(devices.get(which)))
                .setNegativeButton("रद्द", null)
                .show());
        } catch (SecurityException e) {
            callJs("onNativePrinterError", "Bluetooth अनुमति नहीं मिली: " + e.getMessage());
        }
    }

    private void connectDevice(BluetoothDevice device) {
        printerExecutor.execute(() -> {
            try {
                closePrinter();
                BluetoothSocket newSocket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                newSocket.connect();
                socket = newSocket;
                outputStream = socket.getOutputStream();
                String name = device.getName() == null ? "Thermal Printer" : device.getName();
                callJs("onNativePrinterConnected", name);
            } catch (Exception e) {
                closePrinter();
                callJs("onNativePrinterError", "कनेक्शन विफल: " + e.getMessage() +
                    "। सुनिश्चित करें कि प्रिंटर Classic Bluetooth SPP सपोर्ट करता है और Pair है।");
            }
        });
    }

    private void closePrinter() {
        try { if (outputStream != null) outputStream.close(); } catch (Exception ignored) {}
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        outputStream = null;
        socket = null;
    }

    private void callJs(String function, String message) {
        runOnUiThread(() -> {
            String safe = org.json.JSONObject.quote(message == null ? "" : message);
            webView.evaluateJavascript("window." + function + "(" + safe + ")", null);
        });
    }

    public class PrinterBridge {
        @JavascriptInterface public void connectPrinter() {
            runOnUiThread(() -> askPermissionThenChoose());
        }
        @JavascriptInterface public boolean isConnected() {
            return socket != null && socket.isConnected() && outputStream != null;
        }
        @JavascriptInterface public void printBase64(String data) {
            printerExecutor.execute(() -> {
                try {
                    if (socket == null || !socket.isConnected() || outputStream == null)
                        throw new Exception("प्रिंटर कनेक्ट नहीं है।");
                    byte[] bytes = android.util.Base64.decode(data, android.util.Base64.DEFAULT);
                    // Send in paced chunks to avoid overflowing small thermal-printer buffers.
                    for (int offset = 0; offset < bytes.length; offset += 512) {
                        int count = Math.min(512, bytes.length - offset);
                        outputStream.write(bytes, offset, count);
                        outputStream.flush();
                        Thread.sleep(12);
                    }
                    callJs("onNativePrintComplete", "true");
                } catch (Exception e) {
                    callJs("onNativePrintComplete", "false");
                    callJs("onNativePrinterError", "प्रिंट नहीं हो पाया: " + e.getMessage());
                }
            });
        }
    }

    @Override public void onDestroy() {
        closePrinter();
        printerExecutor.shutdownNow();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
