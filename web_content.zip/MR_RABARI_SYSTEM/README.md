# MR.RABARI — SYSTEM

A mobile-first Solo Leveling-inspired 60-day Winter Arc tracker.

## Run
Open `index.html` in a modern browser. For PWA installation/offline caching, serve this folder over HTTPS (or localhost); then use your browser's **Add to Home screen** option.

## Features
- Daily quests and editable custom quests
- XP, levels, and hunter ranks
- Stats and category progress
- 60-day calendar and milestones
- Editable daily routine
- Local persistence
- JSON backup and restore
- No app-locking or device-blocking features

## Important
This is a web/PWA app project, not an APK. A real APK requires an Android packaging/build environment and compilation. This project does not lock your phone or other apps. Data is stored locally in your browser; export backups regularly.
