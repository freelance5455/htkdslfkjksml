import React from 'react';
import { BankBranch, Language } from '../types';
import { MOCK_BANKS, MOCK_SERVICES } from '../data/mockData';
import { BankLogo } from './BankLogo';
import { OccupancyBadge } from './OccupancyBadge';
import { getTranslation } from '../i18n/translations';
import { StorageService } from '../services/storage';
import {
  X,
  Phone,
  Clock,
  MapPin,
  Calendar,
  CheckCircle2,
  Star,
  ChevronRight,
  ShieldCheck,
  CreditCard,
  MessageSquare,
} from 'lucide-react';

interface BranchDetailModalProps {
  branch: BankBranch | null;
  language: Language;
  onClose: () => void;
  onBookQueue: (branch: BankBranch) => void;
}

export const BranchDetailModal: React.FC<BranchDetailModalProps> = ({
  branch,
  language,
  onClose,
  onBookQueue,
}) => {
  if (!branch) return null;

  const t = getTranslation(language);
  const bank = MOCK_BANKS.find((b) => b.id === branch.bankId);
  const reviews = StorageService.getReviews(branch.id);

  // Available services objects
  const availableServices = MOCK_SERVICES.filter((s) =>
    branch.services.includes(s.id)
  );

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="w-full sm:max-w-xl max-h-[90vh] bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="relative p-5 sm:p-6 border-b border-slate-100 dark:border-slate-800 flex items-start justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <BankLogo bank={bank} size="lg" />
            <div>
              <span className="text-xs font-semibold text-blue-600 dark:text-blue-400">
                {bank?.name}
              </span>
              <h3 className="font-bold text-lg text-slate-900 dark:text-white leading-tight">
                {branch.name}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                {branch.city}, {branch.district} tumani
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 hover:text-slate-900 dark:hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6">
          {/* Occupancy Card */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                {t.occupancyOverview}
              </p>
              <div className="mt-1">
                <OccupancyBadge
                  level={branch.occupancyLevel}
                  count={branch.currentQueueCount}
                  language={language}
                />
              </div>
            </div>
            <div className="text-right">
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                {t.estimatedWait}
              </p>
              <p className="text-lg font-bold text-slate-900 dark:text-white tabular-nums mt-0.5">
                ~{branch.averageWaitMinutes} {t.minutesShort}
              </p>
            </div>
          </div>

          {/* Contact and Work Hours */}
          <div className="space-y-3 text-xs text-slate-600 dark:text-slate-300">
            <div className="flex items-start gap-3">
              <MapPin className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-slate-900 dark:text-white">Manzil:</p>
                <p className="text-slate-600 dark:text-slate-400 mt-0.5">{branch.address}</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Clock className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-slate-900 dark:text-white">{t.workHours}:</p>
                <p className="text-slate-600 dark:text-slate-400 mt-0.5">
                  {branch.workHours} ({branch.workDays})
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Phone className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-slate-900 dark:text-white">Aloqa telefoni:</p>
                <a
                  href={`tel:${branch.phone}`}
                  className="text-blue-600 dark:text-blue-400 font-medium hover:underline mt-0.5 inline-block"
                >
                  {branch.phone}
                </a>
              </div>
            </div>
          </div>

          {/* Services Available */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">
              Mavjud bank xizmatlari ({availableServices.length})
            </h4>
            <div className="space-y-2">
              {availableServices.map((srv) => (
                <div
                  key={srv.id}
                  className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-blue-100/70 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                      <CreditCard className="w-3.5 h-3.5" />
                    </div>
                    <span className="font-medium text-slate-900 dark:text-white">
                      {srv.name[language] || srv.name.uz}
                    </span>
                  </div>
                  <span className="text-slate-500 tabular-nums">
                    ~{srv.averageDurationMinutes} {t.minutesShort}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Customer Reviews Section */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Mijozlar fikrlari ({branch.reviewsCount})
              </h4>
              <div className="flex items-center gap-1 text-xs font-bold text-amber-500">
                <Star className="w-3.5 h-3.5 fill-amber-400" />
                <span>{branch.rating.toFixed(1)} / 5.0</span>
              </div>
            </div>

            <div className="space-y-2.5">
              {reviews.slice(0, 3).map((rev) => (
                <div
                  key={rev.id}
                  className="p-3 rounded-xl bg-slate-50/70 dark:bg-slate-800/30 border border-slate-100 dark:border-slate-800/80 text-xs space-y-1"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-900 dark:text-white">
                      {rev.userName}
                    </span>
                    <span className="text-slate-400 text-[11px]">{rev.date}</span>
                  </div>
                  <div className="flex items-center gap-1 text-amber-500">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3 h-3 ${
                          i < rev.rating ? 'fill-amber-400' : 'text-slate-300'
                        }`}
                      />
                    ))}
                  </div>
                  <p className="text-slate-600 dark:text-slate-300 mt-1 italic">
                    "{rev.comment}"
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Booking Button */}
        <div className="p-4 sm:p-5 border-t border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center gap-3">
          <button
            type="button"
            onClick={() => {
              onClose();
              onBookQueue(branch);
            }}
            className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-sm flex items-center justify-center gap-2 transition-colors"
          >
            <span>{t.bookQueue}</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
