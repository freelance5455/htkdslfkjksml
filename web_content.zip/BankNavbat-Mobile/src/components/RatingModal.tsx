import React, { useState } from 'react';
import { QueueTicket, Language, BranchReview } from '../types';
import { getTranslation } from '../i18n/translations';
import { StorageService } from '../services/storage';
import { Star, X, Check, Sparkles, Zap, HeartHandshake } from 'lucide-react';
import confetti from 'canvas-confetti';

interface RatingModalProps {
  ticket: QueueTicket | null;
  language: Language;
  onClose: () => void;
  onSubmitted?: () => void;
}

export const RatingModal: React.FC<RatingModalProps> = ({
  ticket,
  language,
  onClose,
  onSubmitted,
}) => {
  if (!ticket) return null;

  const t = getTranslation(language);
  const [rating, setRating] = useState<number>(5);
  const [speedRating, setSpeedRating] = useState<number>(3); // 3=fast, 2=medium, 1=slow
  const [comment, setComment] = useState<string>('');
  const [isSuccess, setIsSuccess] = useState<boolean>(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const newReview: BranchReview = {
      id: `rev_${Date.now()}`,
      branchId: ticket.branchId,
      userName: ticket.clientName || 'Mijoz',
      rating: rating,
      speedRating: speedRating,
      comment: comment.trim() || 'Xizmat a’lo darajada ko‘rsatildi, rahmat!',
      date: 'Hozirgina',
      serviceName: ticket.serviceName,
    };

    StorageService.addReview(newReview);
    StorageService.updateTicket(ticket.id, {
      ratingGiven: rating,
      speedRating: speedRating,
      reviewGiven: comment,
    });

    setIsSuccess(true);
    confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });

    setTimeout(() => {
      if (onSubmitted) onSubmitted();
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="w-full sm:max-w-md bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-5 sm:p-6 overflow-hidden animate-in slide-in-from-bottom duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              {t.rateTitle}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {ticket.bankName} · {ticket.branchName}
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 hover:text-slate-900 dark:hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {isSuccess ? (
          <div className="py-8 text-center space-y-3">
            <div className="w-14 h-14 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto">
              <Check className="w-7 h-7 stroke-[3]" />
            </div>
            <h4 className="font-bold text-lg text-slate-900 dark:text-white">
              {t.ratingSubmitted}
            </h4>
            <p className="text-xs text-slate-500 max-w-xs mx-auto">
              Sizning bahoyingiz bank filiali sifat ko‘rsatkichlariga qo‘shildi.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-5 pt-4">
            {/* 1-5 Star Selection */}
            <div className="text-center space-y-2">
              <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                {t.overallRating}
              </p>
              <div className="flex items-center justify-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    className="p-1.5 transition-transform hover:scale-125 focus:outline-hidden"
                  >
                    <Star
                      className={`w-8 h-8 ${
                        star <= rating
                          ? 'fill-amber-400 text-amber-500'
                          : 'text-slate-300 dark:text-slate-700'
                      }`}
                    />
                  </button>
                ))}
              </div>
              <p className="text-xs font-bold text-amber-600 dark:text-amber-400">
                {rating === 5 && '⭐️⭐️⭐️⭐️⭐️ A’lo darajada!'}
                {rating === 4 && '⭐️⭐️⭐️⭐️ Yaxshi'}
                {rating === 3 && '⭐️⭐️⭐️ Qoniqarli'}
                {rating <= 2 && '⭐️⭐️ Yaxshilash kerak'}
              </p>
            </div>

            {/* Service Speed Rating */}
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                {t.speedRating}
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setSpeedRating(3)}
                  className={`p-2.5 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1.5 transition-all ${
                    speedRating === 3
                      ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <Zap className="w-3.5 h-3.5" />
                  <span>{t.speedFast}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSpeedRating(2)}
                  className={`p-2.5 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1.5 transition-all ${
                    speedRating === 2
                      ? 'border-blue-600 bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <span>{t.speedMedium}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSpeedRating(1)}
                  className={`p-2.5 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1.5 transition-all ${
                    speedRating === 1
                      ? 'border-amber-600 bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <span>{t.speedSlow}</span>
                </button>
              </div>
            </div>

            {/* Comment */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {t.commentLabel}
              </label>
              <textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                rows={3}
                placeholder={t.commentPlaceholder}
                className="w-full p-3 text-xs sm:text-sm rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-sm flex items-center justify-center gap-2 transition-colors"
            >
              <Sparkles className="w-4 h-4" />
              <span>{t.submitRating}</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
