import React from 'react';
import { Smartphone, Monitor, Globe, Moon, Sun, Bell } from 'lucide-react';
import { Language } from '../types';

interface MobileDeviceFrameProps {
  children: React.ReactNode;
  isDeviceMode: boolean;
  onToggleDeviceMode: () => void;
  language: Language;
  onChangeLanguage: (lang: Language) => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
  unreadNotificationsCount?: number;
  onOpenNotifications?: () => void;
  onOpenApkModal?: () => void;
}

export const MobileDeviceFrame: React.FC<MobileDeviceFrameProps> = ({
  children,
  isDeviceMode,
  onToggleDeviceMode,
  language,
  onChangeLanguage,
  isDarkMode,
  onToggleTheme,
  unreadNotificationsCount = 0,
  onOpenNotifications,
  onOpenApkModal,
}) => {
  // Current Tashkent time display (HH:MM)
  const currentTime = new Date().toLocaleTimeString('uz-UZ', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 flex flex-col transition-colors">
      {/* Top Demo Utility Control Bar */}
      <header className="sticky top-0 z-50 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 px-4 py-2.5 flex items-center justify-between text-xs">
        {/* Brand Lockup */}
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-blue-700 to-blue-500 text-white font-black flex items-center justify-center text-xs shadow-xs">
            BN
          </div>
          <div>
            <span className="font-extrabold tracking-tight text-slate-900 dark:text-white text-sm">
              BankNavbat<span className="text-blue-600 dark:text-blue-400">.uz</span>
            </span>
          </div>
        </div>

        {/* Global Toolbar Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* APK & Android Install Trigger */}
          {onOpenApkModal && (
            <button
              type="button"
              onClick={onOpenApkModal}
              className="px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-[11px] sm:text-xs flex items-center gap-1 sm:gap-1.5 shadow-sm active:scale-95 transition-all cursor-pointer"
              title="Android APK yuklab olish va o‘rnatish"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span className="hidden xs:inline">.APK / O‘rnatish</span>
              <span className="xs:hidden">.APK</span>
            </button>
          )}

          {/* Device Viewport Switcher (Desktop only) */}
          <button
            type="button"
            onClick={onToggleDeviceMode}
            className={`hidden sm:flex p-2 rounded-xl items-center gap-1.5 transition-colors cursor-pointer ${
              isDeviceMode
                ? 'bg-blue-100 dark:bg-blue-950/80 text-blue-700 dark:text-blue-300 font-semibold'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
            title="Qurilma / Keng ekran ko'rinishini almashtirish"
          >
            {isDeviceMode ? (
              <Smartphone className="w-4 h-4" />
            ) : (
              <Monitor className="w-4 h-4" />
            )}
            <span>
              {isDeviceMode ? 'Smartfon' : 'Keng ekran'}
            </span>
          </button>

          {/* Language Selector */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-0.5 rounded-xl">
            {(['uz', 'ru', 'en'] as Language[]).map((lang) => (
              <button
                key={lang}
                type="button"
                onClick={() => onChangeLanguage(lang)}
                className={`px-1.5 sm:px-2 py-1 text-[11px] sm:text-xs font-semibold rounded-lg uppercase transition-all cursor-pointer ${
                  language === lang
                    ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {lang}
              </button>
            ))}
          </div>

          {/* Theme Toggle */}
          <button
            type="button"
            onClick={onToggleTheme}
            className="p-1.5 sm:p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
            title="Mavzuni almashtirish"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Notifications Bell */}
          {onOpenNotifications && (
            <button
              type="button"
              onClick={onOpenNotifications}
              className="relative p-1.5 sm:p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
              title="Bildirishnomalar"
            >
              <Bell className="w-4 h-4" />
              {unreadNotificationsCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-rose-500 ring-2 ring-white dark:ring-slate-900 animate-pulse" />
              )}
            </button>
          )}
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 flex flex-col sm:items-center sm:justify-center p-0 sm:p-4 md:p-6 overflow-x-hidden">
        {/* Real Mobile Viewport (Screens < 640px): 100% Full Screen Edge-to-Edge Native Experience */}
        <div className="w-full flex-1 flex flex-col sm:hidden bg-white dark:bg-slate-900">
          {children}
        </div>

        {/* Desktop / Tablet Viewport (Screens >= 640px) */}
        <div className="hidden sm:flex flex-1 items-center justify-center w-full">
          {isDeviceMode ? (
            <div className="relative w-full max-w-[420px] h-[870px] max-h-[92vh] bg-slate-900 rounded-[48px] p-3 shadow-2xl ring-1 ring-slate-800 flex flex-col my-auto transition-all">
              {/* Phone Bezel Buttons Simulation (Power/Volume) */}
              <div className="absolute -left-1 top-24 w-1 h-10 bg-slate-700 rounded-l-md" />
              <div className="absolute -left-1 top-38 w-1 h-12 bg-slate-700 rounded-l-md" />
              <div className="absolute -right-1 top-28 w-1 h-14 bg-slate-700 rounded-r-md" />

              {/* Inner Phone Screen */}
              <div className="relative flex-1 bg-white dark:bg-slate-900 rounded-[38px] overflow-hidden flex flex-col border border-slate-800/20">
                {/* Phone Status Bar (Island + Time + Battery) */}
                <div className="sticky top-0 z-40 px-6 pt-3 pb-2 flex items-center justify-between text-xs font-semibold text-slate-900 dark:text-white bg-white/90 dark:bg-slate-900/90 backdrop-blur-md select-none shrink-0">
                  <span className="font-mono text-[13px] tracking-tight">{currentTime}</span>

                  {/* Dynamic Island Pill */}
                  <div className="w-24 h-5 rounded-full bg-black flex items-center justify-center gap-2 px-2 shadow-xs">
                    <span className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-700" />
                    <span className="w-2 h-2 rounded-full bg-blue-900/40" />
                  </div>

                  {/* Status Icons: 5G & Battery */}
                  <div className="flex items-center gap-1.5 text-[11px] font-mono">
                    <span>5G</span>
                    <div className="w-5 h-2.5 rounded-xs border border-current p-0.5 flex items-center">
                      <div className="w-full h-full bg-current rounded-2xs" />
                    </div>
                  </div>
                </div>

                {/* Scrollable Screen Content */}
                <div className="flex-1 overflow-y-auto no-scrollbar flex flex-col">
                  {children}
                </div>
              </div>
            </div>
          ) : (
            <div className="w-full max-w-4xl bg-white dark:bg-slate-900 rounded-3xl shadow-xl border border-slate-200/80 dark:border-slate-800 overflow-hidden flex flex-col min-h-[750px]">
              {children}
            </div>
          )}
        </div>
      </main>
    </div>
  );
};
