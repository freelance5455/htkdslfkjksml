import React, { useState, useEffect } from 'react';
import { Bank, BankBranch, BankService, QueueTicket, Language } from '../types';
import { MOCK_BANKS, MOCK_BRANCHES, MOCK_SERVICES } from '../data/mockData';
import { BankLogo } from './BankLogo';
import { OccupancyBadge } from './OccupancyBadge';
import { getTranslation } from '../i18n/translations';
import { StorageService } from '../services/storage';
import {
  generateTicketCode,
  assignServiceWindow,
  calculateEstimatedWait,
  formatUzbekPhone,
  validateUzbekPhone,
} from '../utils/queueLogic';
import {
  X,
  ChevronRight,
  ChevronLeft,
  Check,
  Calendar,
  Clock,
  MapPin,
  CreditCard,
  User,
  Phone,
  Sparkles,
  FileText,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { motion, AnimatePresence } from 'motion/react';

interface BookingWizardModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  preselectedBranch?: BankBranch | null;
  preselectedBank?: Bank | null;
  onTicketCreated: (ticket: QueueTicket) => void;
}

export const BookingWizardModal: React.FC<BookingWizardModalProps> = ({
  isOpen,
  onClose,
  language,
  preselectedBranch,
  preselectedBank,
  onTicketCreated,
}) => {
  if (!isOpen) return null;

  const t = getTranslation(language);
  const profile = StorageService.getProfile();

  // Wizard state
  const [step, setStep] = useState<number>(1);
  const [selectedBank, setSelectedBank] = useState<Bank | null>(
    preselectedBank ||
      (preselectedBranch
        ? MOCK_BANKS.find((b) => b.id === preselectedBranch.bankId) || null
        : null)
  );
  const [selectedBranch, setSelectedBranch] = useState<BankBranch | null>(
    preselectedBranch || null
  );
  const [selectedService, setSelectedService] = useState<BankService | null>(null);
  const [selectedDate, setSelectedDate] = useState<'today' | 'tomorrow'>('today');
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>('11:30');
  const [clientName, setClientName] = useState<string>(profile.name || 'Jamshidbek Alimov');
  const [clientPhone, setClientPhone] = useState<string>(profile.phone || '+998 (90) 123-45-67');
  const [phoneError, setPhoneError] = useState<string>('');
  const [nameError, setNameError] = useState<string>('');
  const [createdTicket, setCreatedTicket] = useState<QueueTicket | null>(null);

  // If a branch was preselected when opened, jump straight to step 3 (Service)
  useEffect(() => {
    if (preselectedBranch) {
      setSelectedBranch(preselectedBranch);
      const b = MOCK_BANKS.find((x) => x.id === preselectedBranch.bankId);
      if (b) setSelectedBank(b);
      setStep(3);
    } else if (preselectedBank) {
      setSelectedBank(preselectedBank);
      setStep(2);
    }
  }, [preselectedBranch, preselectedBank]);

  // Filter branches by bank
  const availableBranches = selectedBank
    ? MOCK_BRANCHES.filter((br) => br.bankId === selectedBank.id)
    : MOCK_BRANCHES;

  // Filter services by branch
  const availableServices = selectedBranch
    ? MOCK_SERVICES.filter((srv) => selectedBranch.services.includes(srv.id))
    : MOCK_SERVICES;

  const timeSlots = [
    { time: '09:15', available: true },
    { time: '09:45', available: true },
    { time: '10:30', available: false },
    { time: '11:00', available: true },
    { time: '11:30', available: true },
    { time: '12:15', available: true },
    { time: '14:00', available: true },
    { time: '14:45', available: false },
    { time: '15:30', available: true },
    { time: '16:15', available: true },
    { time: '17:00', available: true },
  ];

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatUzbekPhone(e.target.value);
    setClientPhone(formatted);
    if (phoneError && validateUzbekPhone(formatted)) {
      setPhoneError('');
    }
  };

  const handleConfirm = () => {
    let hasError = false;
    if (!clientName.trim()) {
      setNameError('Iltimos, ismingizni kiriting');
      hasError = true;
    } else {
      setNameError('');
    }

    if (!validateUzbekPhone(clientPhone)) {
      setPhoneError('Iltimos, to‘g‘ri telefon raqami kiriting (masalan: +998 90 123 45 67)');
      hasError = true;
    } else {
      setPhoneError('');
    }

    if (hasError) {
      return;
    }

    if (!selectedBank || !selectedBranch || !selectedService) {
      return;
    }

    const currentTickets = StorageService.getTickets();
    const serviceCode = selectedService.serviceCode || 'A';
    const ticketCode = generateTicketCode(serviceCode, currentTickets.length + 42);
    const windowName = assignServiceWindow(selectedService.category);
    const peopleAhead = Math.max(1, selectedBranch.currentQueueCount - 2);
    const waitMins = calculateEstimatedWait(
      peopleAhead,
      selectedService.averageDurationMinutes,
      3
    );

    const dateLabel =
      selectedDate === 'today'
        ? `Bugun, 9-noyabr`
        : `Ertaga, 10-noyabr`;

    const newTicket: QueueTicket = {
      id: `tkt_${Date.now()}`,
      ticketNumber: ticketCode,
      bankId: selectedBank.id,
      bankName: selectedBank.name,
      branchId: selectedBranch.id,
      branchName: selectedBranch.name,
      branchAddress: selectedBranch.address,
      serviceId: selectedService.id,
      serviceName: selectedService.name[language] || selectedService.name.uz,
      serviceCode: serviceCode,
      date: dateLabel,
      timeSlot: selectedTimeSlot,
      windowNumber: windowName,
      status: 'active',
      createdAt: new Date().toISOString(),
      estimatedWaitMinutes: waitMins,
      peopleAhead: peopleAhead,
      clientName: clientName.trim(),
      clientPhone: clientPhone.trim(),
      qrCodeValue: `BANKNAVBAT-${selectedBank.code}-${ticketCode}-${Date.now()}`,
    };

    StorageService.saveTicket(newTicket);
    setCreatedTicket(newTicket);
    setStep(6); // Success screen

    // Trigger celebration confetti
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
    });
  };

  const handleFinish = () => {
    if (createdTicket) {
      onTicketCreated(createdTicket);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="w-full sm:max-w-xl max-h-[92vh] bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Step Progress Top Bar */}
        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {step > 1 && step < 6 && (
              <button
                type="button"
                onClick={() => setStep(step - 1)}
                className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-200 transition-colors mr-1"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
            )}
            <div>
              <p className="text-[11px] font-semibold text-blue-600 dark:text-blue-400 uppercase tracking-wider">
                {step < 6 ? `Qadam ${step} / 5` : 'Tayyor!'}
              </p>
              <h3 className="font-bold text-base text-slate-900 dark:text-white leading-tight">
                {step === 1 && t.stepBank}
                {step === 2 && t.stepBranch}
                {step === 3 && t.stepService}
                {step === 4 && t.stepTime}
                {step === 5 && t.stepConfirm}
                {step === 6 && t.bookingSuccess}
              </h3>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 hover:text-slate-900 dark:hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Wizard Step Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-4 flex-1">
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.18, ease: 'easeOut' }}
            >
              {/* STEP 1: SELECT BANK */}
              {step === 1 && (
            <div className="space-y-3">
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {t.selectBankPrompt}
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {MOCK_BANKS.map((bank) => {
                  const isSelected = selectedBank?.id === bank.id;
                  return (
                    <button
                      key={bank.id}
                      type="button"
                      onClick={() => {
                        setSelectedBank(bank);
                        setSelectedBranch(null);
                        setStep(2);
                      }}
                      className={`p-3.5 rounded-2xl border text-left flex flex-col justify-between transition-all ${
                        isSelected
                          ? 'border-blue-600 bg-blue-50/50 dark:bg-blue-950/40 ring-2 ring-blue-500/20'
                          : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-900'
                      }`}
                    >
                      <BankLogo bank={bank} size="md" />
                      <div className="mt-3">
                        <span className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white leading-tight block">
                          {bank.name}
                        </span>
                        <span className="text-[10px] text-slate-400 uppercase mt-0.5 block">
                          {bank.code}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 2: SELECT BRANCH */}
          {step === 2 && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                <BankLogo bank={selectedBank || undefined} size="sm" />
                <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                  {selectedBank?.name}
                </span>
              </div>

              <p className="text-xs text-slate-500 dark:text-slate-400">
                {t.selectBranchPrompt}
              </p>

              <div className="space-y-2.5">
                {availableBranches.map((br) => {
                  const isSelected = selectedBranch?.id === br.id;
                  return (
                    <button
                      key={br.id}
                      type="button"
                      onClick={() => {
                        setSelectedBranch(br);
                        setStep(3);
                      }}
                      className={`w-full p-4 rounded-2xl border text-left flex items-start justify-between gap-3 transition-all ${
                        isSelected
                          ? 'border-blue-600 bg-blue-50/50 dark:bg-blue-950/40'
                          : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-900'
                      }`}
                    >
                      <div>
                        <h4 className="font-bold text-sm text-slate-900 dark:text-white leading-tight">
                          {br.name}
                        </h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 flex items-center gap-1">
                          <MapPin className="w-3 h-3 shrink-0" />
                          <span className="line-clamp-1">{br.address}</span>
                        </p>
                        <div className="mt-2.5 flex items-center gap-2">
                          <OccupancyBadge
                            level={br.occupancyLevel}
                            count={br.currentQueueCount}
                            language={language}
                          />
                          <span className="text-xs text-slate-500 font-medium">
                            ~{br.averageWaitMinutes} {t.minutesShort}
                          </span>
                        </div>
                      </div>

                      <ChevronRight className="w-4 h-4 text-slate-400 shrink-0 mt-1" />
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 3: SELECT SERVICE */}
          {step === 3 && (
            <div className="space-y-3">
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {t.selectServicePrompt}
              </p>

              <div className="space-y-2.5">
                {availableServices.map((srv) => {
                  const isSelected = selectedService?.id === srv.id;
                  return (
                    <button
                      key={srv.id}
                      type="button"
                      onClick={() => {
                        setSelectedService(srv);
                        setStep(4);
                      }}
                      className={`w-full p-4 rounded-2xl border text-left flex items-start justify-between gap-3 transition-all ${
                        isSelected
                          ? 'border-blue-600 bg-blue-50/50 dark:bg-blue-950/40 ring-2 ring-blue-500/20'
                          : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-900'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className="w-9 h-9 rounded-xl bg-blue-100/70 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0 mt-0.5">
                          <CreditCard className="w-4 h-4" />
                        </div>
                        <div>
                          <h4 className="font-bold text-sm text-slate-900 dark:text-white leading-tight">
                            {srv.name[language] || srv.name.uz}
                          </h4>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                            {srv.description[language] || srv.description.uz}
                          </p>
                          <div className="flex items-center gap-2 mt-2 text-[11px] text-slate-400">
                            <Clock className="w-3 h-3" />
                            <span>
                              Davomiyligi: ~{srv.averageDurationMinutes} {t.minutesShort}
                            </span>
                          </div>
                        </div>
                      </div>

                      <ChevronRight className="w-4 h-4 text-slate-400 shrink-0 mt-1" />
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 4: SELECT DATE & TIME */}
          {step === 4 && (
            <div className="space-y-4">
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {t.selectDatePrompt}
              </p>

              {/* Day selection tabs */}
              <div className="flex items-center gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
                <button
                  type="button"
                  onClick={() => setSelectedDate('today')}
                  className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
                    selectedDate === 'today'
                      ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {t.today} (9-noyabr)
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedDate('tomorrow')}
                  className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
                    selectedDate === 'tomorrow'
                      ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {t.tomorrow} (10-noyabr)
                </button>
              </div>

              {/* Time Slots Grid */}
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                {timeSlots.map((slot) => {
                  const isSelected = selectedTimeSlot === slot.time;
                  return (
                    <button
                      key={slot.time}
                      type="button"
                      disabled={!slot.available}
                      onClick={() => setSelectedTimeSlot(slot.time)}
                      className={`p-2.5 rounded-xl text-center border transition-all ${
                        !slot.available
                          ? 'opacity-40 border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 cursor-not-allowed'
                          : isSelected
                          ? 'border-blue-600 bg-blue-600 text-white font-bold shadow-xs'
                          : 'border-slate-200 dark:border-slate-800 hover:border-blue-400 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 font-medium'
                      }`}
                    >
                      <span className="text-xs tabular-nums block">{slot.time}</span>
                      <span
                        className={`text-[9px] block mt-0.5 ${
                          isSelected ? 'text-white/80' : 'text-slate-400'
                        }`}
                      >
                        {slot.available ? t.timeSlotAvailable : t.timeSlotBusy}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Required Documents Callout */}
              {selectedService && (
                <div className="p-3.5 rounded-2xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200/50 dark:border-amber-900/40 text-xs space-y-1.5">
                  <div className="flex items-center gap-1.5 font-semibold text-amber-900 dark:text-amber-200">
                    <FileText className="w-3.5 h-3.5 text-amber-600" />
                    <span>Zarur hujjatlar:</span>
                  </div>
                  <ul className="list-disc list-inside text-amber-800 dark:text-amber-300/90 text-[11px] space-y-0.5">
                    {(selectedService.requiredDocuments[language] ||
                      selectedService.requiredDocuments.uz
                    ).map((doc, idx) => (
                      <li key={idx}>{doc}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {/* STEP 5: CONFIRMATION & CONTACTS */}
          {step === 5 && (
            <div className="space-y-4">
              {/* Summary Card */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-3">
                <div className="flex items-center gap-3 border-b border-slate-200/70 dark:border-slate-700/60 pb-3">
                  <BankLogo bank={selectedBank || undefined} size="md" />
                  <div>
                    <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                      {selectedBranch?.name}
                    </h4>
                    <p className="text-xs text-slate-500">{selectedBranch?.address}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-slate-400">Xizmat:</span>
                    <p className="font-semibold text-slate-900 dark:text-white line-clamp-1">
                      {selectedService?.name[language] || selectedService?.name.uz}
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-400">Tashrif vaqti:</span>
                    <p className="font-semibold text-blue-600 dark:text-blue-400">
                      {selectedDate === 'today' ? 'Bugun' : 'Ertaga'}, {selectedTimeSlot}
                    </p>
                  </div>
                </div>
              </div>

              {/* Client form inputs */}
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {t.clientName}
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={clientName}
                      onChange={(e) => {
                        setClientName(e.target.value);
                        if (nameError && e.target.value.trim()) {
                          setNameError('');
                        }
                      }}
                      placeholder="Masalan: Jamshidbek Alimov"
                      className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  {nameError && (
                    <p className="text-xs text-rose-500 mt-1">{nameError}</p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {t.clientPhone}
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="tel"
                      value={clientPhone}
                      onChange={handlePhoneChange}
                      placeholder="+998 (90) 123-45-67"
                      className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  {phoneError && (
                    <p className="text-xs text-rose-500 mt-1">{phoneError}</p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* STEP 6: SUCCESS TICKET CREATED */}
          {step === 6 && createdTicket && (
            <div className="py-4 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto shadow-md">
                <Check className="w-8 h-8 stroke-[3]" />
              </div>

              <div>
                <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
                  Muvaffaqiyatli!
                </span>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white mt-1">
                  Elektron talon tayyor
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto">
                  {t.bookingSuccessDesc}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 max-w-sm mx-auto text-left space-y-2">
                <div className="flex items-baseline justify-between">
                  <span className="text-xs text-slate-400 uppercase font-mono">
                    Talon raqami:
                  </span>
                  <span className="text-2xl font-extrabold text-blue-600 dark:text-blue-400 font-mono">
                    {createdTicket.ticketNumber}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Filial:</span>
                  <span className="font-semibold text-slate-900 dark:text-white">
                    {createdTicket.branchName}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Darcha:</span>
                  <span className="font-semibold text-slate-900 dark:text-white">
                    {createdTicket.windowNumber}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Vaqt:</span>
                  <span className="font-semibold text-slate-900 dark:text-white">
                    {createdTicket.date}, {createdTicket.timeSlot}
                  </span>
                </div>
              </div>
            </div>
          )}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Bottom Actions Bar */}
        <div className="p-4 sm:p-5 border-t border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center gap-3">
          {step === 4 && (
            <button
              type="button"
              onClick={() => setStep(5)}
              className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-sm flex items-center justify-center gap-2 transition-colors"
            >
              <span>{t.next}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          )}

          {step === 5 && (
            <button
              type="button"
              onClick={handleConfirm}
              className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-sm flex items-center justify-center gap-2 transition-colors"
            >
              <Sparkles className="w-4 h-4" />
              <span>{t.confirmAndGetTicket}</span>
            </button>
          )}

          {step === 6 && (
            <button
              type="button"
              onClick={handleFinish}
              className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-sm flex items-center justify-center gap-2 transition-colors"
            >
              <span>{t.viewMyTicket}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
