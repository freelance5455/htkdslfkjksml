import React, { useState } from 'react';
import { BankBranch, Language } from '../types';
import { MOCK_BANKS } from '../data/mockData';
import { BankLogo } from './BankLogo';
import { OccupancyBadge } from './OccupancyBadge';
import { getTranslation } from '../i18n/translations';
import { calculateDistanceKm, formatDistance } from '../utils/queueLogic';
import {
  Navigation,
  ZoomIn,
  ZoomOut,
  Layers,
  MapPin,
  Clock,
  ChevronRight,
  Crosshair,
  Filter,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface InteractiveMapProps {
  branches: BankBranch[];
  language: Language;
  onSelectBranch: (branch: BankBranch) => void;
  onBookQueue: (branch: BankBranch) => void;
}

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  branches,
  language,
  onSelectBranch,
  onBookQueue,
}) => {
  const t = getTranslation(language);

  // User simulated position (Tashkent Amir Temur Square)
  const userPos = { lat: 41.3111, lng: 69.2797 };

  // Map viewport states
  const [zoom, setZoom] = useState<number>(1);
  const [selectedBankFilter, setSelectedBankFilter] = useState<string>('all');
  const [activeBranch, setActiveBranch] = useState<BankBranch | null>(branches[0] || null);
  const [userLocated, setUserLocated] = useState<boolean>(true);

  // Tashkent bounding box for coordinate projection
  // Lat: ~41.25 to 41.38, Lng: ~69.18 to 69.34
  const minLat = 41.25;
  const maxLat = 41.38;
  const minLng = 69.18;
  const maxLng = 69.34;

  const projectCoords = (lat: number, lng: number) => {
    // If coordinate is outside Tashkent (e.g. Samarkand), map it into boundary
    const clampedLat = Math.min(Math.max(lat, minLat), maxLat);
    const clampedLng = Math.min(Math.max(lng, minLng), maxLng);

    const x = ((clampedLng - minLng) / (maxLng - minLng)) * 100;
    const y = ((maxLat - clampedLat) / (maxLat - minLat)) * 100;
    return { x: Math.min(Math.max(x, 8), 92), y: Math.min(Math.max(y, 10), 88) };
  };

  const filteredBranches =
    selectedBankFilter === 'all'
      ? branches
      : branches.filter((b) => b.bankId === selectedBankFilter);

  const activeBank = activeBranch
    ? MOCK_BANKS.find((b) => b.id === activeBranch.bankId)
    : null;

  const distanceKm = activeBranch
    ? calculateDistanceKm(userPos.lat, userPos.lng, activeBranch.lat, activeBranch.lng)
    : 0;

  return (
    <div className="relative w-full h-[520px] sm:h-[600px] rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-900 select-none shadow-inner">
      {/* Map Vector Grid Canvas Background */}
      <svg
        className="absolute inset-0 w-full h-full pointer-events-none opacity-40"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <pattern id="mapGrid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path
              d="M 40 0 L 0 0 0 40"
              fill="none"
              stroke="#334155"
              strokeWidth="0.8"
            />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#mapGrid)" />

        {/* Stylized River (Bo'zsuv / Anhor kanali representation) */}
        <path
          d="M 10 20 Q 35 150, 45 280 T 85 450 T 120 600"
          fill="none"
          stroke="#0284c7"
          strokeWidth="6"
          strokeLinecap="round"
          className="opacity-70"
        />
        {/* Ring Road stylized arcs */}
        <circle
          cx="50%"
          cy="48%"
          r="190"
          fill="none"
          stroke="#475569"
          strokeWidth="1.5"
          strokeDasharray="6 4"
        />
        <circle
          cx="50%"
          cy="48%"
          r="290"
          fill="none"
          stroke="#334155"
          strokeWidth="1"
          strokeDasharray="8 6"
        />
      </svg>

      {/* Top Filter Chips Bar */}
      <div className="absolute top-4 left-4 right-4 z-20 flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
        <button
          type="button"
          onClick={() => setSelectedBankFilter('all')}
          className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap shadow-md backdrop-blur-md transition-all ${
            selectedBankFilter === 'all'
              ? 'bg-blue-600 text-white ring-2 ring-blue-400/40'
              : 'bg-slate-800/90 text-slate-300 hover:bg-slate-700/90 border border-slate-700'
          }`}
        >
          {t.allBanks} ({branches.length})
        </button>
        {MOCK_BANKS.slice(0, 6).map((bank) => (
          <button
            key={bank.id}
            type="button"
            onClick={() => setSelectedBankFilter(bank.id)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap shadow-md backdrop-blur-md transition-all flex items-center gap-1.5 ${
              selectedBankFilter === bank.id
                ? 'bg-white text-slate-900 font-bold'
                : 'bg-slate-800/90 text-slate-300 hover:bg-slate-700 border border-slate-700'
            }`}
          >
            <span
              className="w-2 h-2 rounded-full"
              style={{ backgroundColor: bank.logoColor }}
            />
            <span>{bank.name}</span>
          </button>
        ))}
      </div>

      {/* Map Controls (Zoom, My Location) */}
      <div className="absolute right-4 top-20 z-20 flex flex-col gap-2">
        <button
          type="button"
          onClick={() => setUserLocated(true)}
          title={t.locateMe}
          className="w-10 h-10 rounded-xl bg-slate-800/90 backdrop-blur-md border border-slate-700 text-white flex items-center justify-center hover:bg-slate-700 shadow-md transition-colors"
        >
          <Crosshair className="w-5 h-5 text-blue-400" />
        </button>
        <button
          type="button"
          onClick={() => setZoom((z) => Math.min(z + 0.2, 1.8))}
          className="w-10 h-10 rounded-xl bg-slate-800/90 backdrop-blur-md border border-slate-700 text-white flex items-center justify-center hover:bg-slate-700 shadow-md transition-colors"
        >
          <ZoomIn className="w-4 h-4" />
        </button>
        <button
          type="button"
          onClick={() => setZoom((z) => Math.max(z - 0.2, 0.8))}
          className="w-10 h-10 rounded-xl bg-slate-800/90 backdrop-blur-md border border-slate-700 text-white flex items-center justify-center hover:bg-slate-700 shadow-md transition-colors"
        >
          <ZoomOut className="w-4 h-4" />
        </button>
      </div>

      {/* District labels on map for realism */}
      <div className="absolute inset-0 pointer-events-none text-[11px] font-bold tracking-widest text-slate-600 uppercase select-none">
        <span className="absolute top-[28%] left-[24%]">Chilonzor</span>
        <span className="absolute top-[18%] left-[58%]">Yunusobod</span>
        <span className="absolute top-[48%] left-[62%]">Mirzo Ulug‘bek</span>
        <span className="absolute top-[68%] left-[48%]">Mirobod</span>
        <span className="absolute top-[38%] left-[38%] text-blue-500/60">Markaz (Amir Temur)</span>
      </div>

      {/* User Location Radar Pin with Concentric Waves */}
      {userLocated && (
        <div
          className="absolute z-10 -translate-x-1/2 -translate-y-1/2 cursor-pointer"
          style={{
            left: `${projectCoords(userPos.lat, userPos.lng).x}%`,
            top: `${projectCoords(userPos.lat, userPos.lng).y}%`,
          }}
          title={t.myLocation}
        >
          <div className="relative flex items-center justify-center">
            {/* Concentric radar wave 1 */}
            <motion.span
              animate={{ scale: [1, 2.6], opacity: [0.6, 0] }}
              transition={{ duration: 2.2, repeat: Infinity, ease: 'easeOut' }}
              className="absolute w-8 h-8 rounded-full bg-blue-500/40 pointer-events-none"
            />
            {/* Concentric radar wave 2 */}
            <motion.span
              animate={{ scale: [1, 1.8], opacity: [0.8, 0] }}
              transition={{ duration: 2.2, repeat: Infinity, ease: 'easeOut', delay: 0.7 }}
              className="absolute w-8 h-8 rounded-full bg-cyan-400/40 pointer-events-none"
            />
            <span className="relative w-4 h-4 rounded-full bg-blue-500 border-2 border-white shadow-lg shadow-blue-500/50" />
          </div>
        </div>
      )}

      {/* Branch Markers */}
      {filteredBranches.map((branch) => {
        const { x, y } = projectCoords(branch.lat, branch.lng);
        const isSelected = activeBranch?.id === branch.id;
        const bank = MOCK_BANKS.find((b) => b.id === branch.bankId);

        const haloColor =
          branch.occupancyLevel === 'low'
            ? 'ring-emerald-400/80 shadow-emerald-500/30'
            : branch.occupancyLevel === 'medium'
            ? 'ring-amber-400/80 shadow-amber-500/30'
            : 'ring-rose-400/80 shadow-rose-500/30';

        return (
          <motion.button
            key={branch.id}
            type="button"
            onClick={() => setActiveBranch(branch)}
            whileHover={{ scale: 1.25 }}
            whileTap={{ scale: 0.92 }}
            animate={{ scale: isSelected ? 1.25 : 1 }}
            className={`absolute z-10 -translate-x-1/2 -translate-y-1/2 cursor-pointer ${
              isSelected ? 'z-30' : ''
            }`}
            style={{ left: `${x}%`, top: `${y}%` }}
          >
            <div
              className={`relative flex items-center justify-center w-8 h-8 rounded-full text-white font-bold text-[10px] ring-2 shadow-lg ${haloColor}`}
              style={{ backgroundColor: bank?.logoColor || '#102B5C' }}
            >
              <span>{bank?.code || 'BK'}</span>
              {/* Occupancy tiny badge with breathing dot */}
              <span
                className={`absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full border border-slate-900 ${
                  branch.occupancyLevel === 'low'
                    ? 'bg-emerald-400'
                    : branch.occupancyLevel === 'medium'
                    ? 'bg-amber-400'
                    : 'bg-rose-400'
                }`}
              />
            </div>
          </motion.button>
        );
      })}

      {/* Bottom Floating Branch Preview Card with AnimatePresence */}
      <AnimatePresence>
        {activeBranch && (
          <motion.div
            key={activeBranch.id}
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 50, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 350, damping: 28 }}
            className="absolute bottom-4 left-4 right-4 z-20"
          >
            <div className="p-4 rounded-2xl bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border border-slate-200/80 dark:border-slate-800 shadow-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-start gap-3">
                <BankLogo bank={activeBank || undefined} size="md" />
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-sm text-slate-900 dark:text-white leading-tight">
                      {activeBranch.name}
                    </span>
                    <OccupancyBadge
                      level={activeBranch.occupancyLevel}
                      count={activeBranch.currentQueueCount}
                      language={language}
                    />
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 shrink-0" />
                    <span className="line-clamp-1">{activeBranch.address}</span>
                    <span>·</span>
                    <span className="font-semibold text-blue-600 dark:text-blue-400 tabular-nums">
                      {formatDistance(distanceKm)}
                    </span>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <motion.button
                  type="button"
                  whileTap={{ scale: 0.95 }}
                  onClick={() => onBookQueue(activeBranch)}
                  className="flex-1 sm:flex-none py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-xs flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer"
                >
                  <span>{t.bookQueue}</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </motion.button>
                <motion.button
                  type="button"
                  whileTap={{ scale: 0.95 }}
                  onClick={() => onSelectBranch(activeBranch)}
                  className="py-2.5 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 text-xs font-medium transition-colors whitespace-nowrap cursor-pointer"
                >
                  {t.viewDetails}
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
