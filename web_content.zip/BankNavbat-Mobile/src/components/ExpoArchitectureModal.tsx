import React, { useState } from 'react';
import { X, Copy, Check, Terminal, FolderTree, Smartphone, FileCode2, BookOpen } from 'lucide-react';

interface ExpoArchitectureModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExpoArchitectureModal: React.FC<ExpoArchitectureModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'run' | 'structure' | 'code' | 'apk'>('run');
  const [copiedSection, setCopiedSection] = useState<string>('');

  const copyToClipboard = (text: string, id: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopiedSection(id);
      setTimeout(() => setCopiedSection(''), 2000);
    }
  };

  const runCommands = `# 1. Loyihani yaratish (Create Expo app with TypeScript)
npx create-expo-app@latest BankNavbat --template blank-typescript

# 2. BankNavbat katalogiga kirish
cd BankNavbat

# 3. Zarur kutubxonalarni o'rnatish (Dependencies)
npx expo install expo-router expo-constants expo-status-bar expo-linking
npx expo install react-native-safe-area-context react-native-screens
npx expo install @react-native-async-storage/async-storage
npx expo install lucide-react-native react-native-svg
npx expo install react-native-maps react-native-reanimated

# 4. Expo dev-serverni ishga tushirish
npx expo start

# Android qurilma yoki emulyatorda ochish:
# Klaviaturada "a" tugmasini bosing yoki Expo Go ilovasida QR-kodni skanerlang!`;

  const apkBuildCommands = `# 1. EAS CLI global o'rnatish
npm install -g eas-cli

# 2. Expo hisobingizga kirish
eas login

# 3. EAS loyihasini sozlash (eas.json yaratiladi)
eas build:configure

# 4. Android uchun bevosita o'rnatiluvchi APK (.apk) yig'ish:
eas build -p android --profile preview

# 5. Tayyor APK faylni yuklab olib Android smartfonga o'rnating!`;

  const projectTree = `BankNavbat/
├── app/                      # Expo Router Fayllar ierarxiyasi
│   ├── (tabs)/               # Bottom Navigation Tabs
│   │   ├── _layout.tsx       # Tab bar sozlamalari va ikonkalar
│   │   ├── index.tsx         # Bosh sahifa (Home)
│   │   ├── branches.tsx      # Filiallar ro'yxati (Branches)
│   │   ├── map.tsx           # Interaktiv xarita (Map)
│   │   ├── my-queues.tsx     # Mening navbatlarim (My Queues)
│   │   └── profile.tsx       # Profil va sozlamalar
│   ├── _layout.tsx           # Ilovaning asosiy root layout'i
│   ├── booking-modal.tsx     # 5 bosqichli navbat olish ekrani
│   ├── ticket/[id].tsx       # Elektron talon (QR-kod va darcha)
│   ├── branch/[id].tsx       # Filial haqida batafsil ma'lumot
│   └── rate/[id].tsx         # Xizmatni baholash ekrani
├── components/               # Qayta ishlatiluvchi UI komponentlar
│   ├── BankLogo.tsx          # Banklar brend logolari
│   ├── BranchCard.tsx        # Filial kartochkasi
│   ├── DigitalTicketCard.tsx # Elektron talon komponenti
│   ├── OccupancyBadge.tsx    # Bandlik indikatori
│   └── QRCodeView.tsx        # SVG QR-kod generatori
├── services/                 # Servislar va API qatlami
│   ├── storage.ts            # AsyncStorage bilan ishlash
│   └── api.ts                # Backend / Supabase API klient
├── utils/                    # Yordamchi hisoblash algoritmlari
│   ├── queueLogic.ts         # Navbat raqami va kutish vaqti
│   └── queueLogic.test.ts    # Unit testlar
├── types/                    # TypeScript tiplari
│   └── index.ts              # Bank, Branch, Ticket modellari
├── app.json                  # Expo konfiguratsiyasi
├── eas.json                  # Android APK build sozlamalari
└── package.json              # Loyiha paketlari`;

  const sampleNativeCode = `// app/(tabs)/_layout.tsx (Expo Router Navigation)
import { Tabs } from 'expo-router';
import { Home, Building2, Map, Ticket, User } from 'lucide-react-native';

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: '#2878F0',
        tabBarInactiveTintColor: '#94A3B8',
        tabBarStyle: {
          backgroundColor: '#FFFFFF',
          borderTopColor: '#F1F5F9',
          height: 64,
          paddingBottom: 8,
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Bosh sahifa',
          tabBarIcon: ({ color, size }) => <Home color={color} size={size} />,
        }}
      />
      <Tabs.Screen
        name="branches"
        options={{
          title: 'Filiallar',
          tabBarIcon: ({ color, size }) => <Building2 color={color} size={size} />,
        }}
      />
      <Tabs.Screen
        name="map"
        options={{
          title: 'Xarita',
          tabBarIcon: ({ color, size }) => <Map color={color} size={size} />,
        }}
      />
      <Tabs.Screen
        name="my-queues"
        options={{
          title: 'Navbatlarim',
          tabBarIcon: ({ color, size }) => <Ticket color={color} size={size} />,
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: 'Profil',
          tabBarIcon: ({ color, size }) => <User color={color} size={size} />,
        }}
      />
    </Tabs>
  );
}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="w-full max-w-3xl max-h-[92vh] bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white leading-tight">
                React Native + Expo & Android APK
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Loyiha arxitekturasi, buyruqlar va Android APK yig'ish qo‘llanmasi
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 hover:text-slate-900 dark:hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 px-5 pt-3 border-b border-slate-100 dark:border-slate-800 overflow-x-auto no-scrollbar">
          <button
            type="button"
            onClick={() => setActiveTab('run')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-t-xl transition-all border-b-2 flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'run'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-950/30'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Expo ishga tushirish</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('apk')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-t-xl transition-all border-b-2 flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'apk'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-950/30'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Android APK Build</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('structure')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-t-xl transition-all border-b-2 flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'structure'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-950/30'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <FolderTree className="w-3.5 h-3.5" />
            <span>Loyiha tuzilmasi</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('code')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-t-xl transition-all border-b-2 flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'code'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-950/30'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <FileCode2 className="w-3.5 h-3.5" />
            <span>Expo Router kodi</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-5 overflow-y-auto flex-1 font-sans">
          {activeTab === 'run' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-xs text-slate-600 dark:text-slate-300">
                  Ushbu buyruqlar yordamida ilovani bevosita Expo Go orqali o'z Android yoki iOS qurilmangizda sinashingiz mumkin:
                </p>
                <button
                  type="button"
                  onClick={() => copyToClipboard(runCommands, 'run')}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-medium flex items-center gap-1 text-slate-700 dark:text-slate-300 transition-colors shrink-0"
                >
                  {copiedSection === 'run' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedSection === 'run' ? 'Nusxalandi' : 'Nusxa olish'}</span>
                </button>
              </div>

              <pre className="p-4 rounded-2xl bg-slate-950 text-slate-200 text-xs font-mono overflow-x-auto leading-relaxed border border-slate-800">
                {runCommands}
              </pre>
            </div>
          )}

          {activeTab === 'apk' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-xs text-slate-600 dark:text-slate-300">
                  EAS Build (Expo Application Services) orqali to'g'ridan-to'g'ri o'rnatiladigan <strong>.apk</strong> fayl yaratish:
                </p>
                <button
                  type="button"
                  onClick={() => copyToClipboard(apkBuildCommands, 'apk')}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-medium flex items-center gap-1 text-slate-700 dark:text-slate-300 transition-colors shrink-0"
                >
                  {copiedSection === 'apk' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedSection === 'apk' ? 'Nusxalandi' : 'Nusxa olish'}</span>
                </button>
              </div>

              <pre className="p-4 rounded-2xl bg-slate-950 text-slate-200 text-xs font-mono overflow-x-auto leading-relaxed border border-slate-800">
                {apkBuildCommands}
              </pre>

              <div className="p-3.5 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/40 text-xs text-blue-900 dark:text-blue-200">
                <strong>eas.json konfiguratsiyasi:</strong> build profili sifatida <code>"buildType": "apk"</code> ko‘rsatiladi. Bu Play Store orqali emas, smartfonga bevosita o‘rnatiluvchi APK beradi.
              </div>
            </div>
          )}

          {activeTab === 'structure' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-xs text-slate-600 dark:text-slate-300">
                  BankNavbat.uz to'liq React Native + Expo Router loyiha fayllar tuzilmasi:
                </p>
                <button
                  type="button"
                  onClick={() => copyToClipboard(projectTree, 'structure')}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-medium flex items-center gap-1 text-slate-700 dark:text-slate-300 transition-colors shrink-0"
                >
                  {copiedSection === 'structure' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedSection === 'structure' ? 'Nusxalandi' : 'Nusxa olish'}</span>
                </button>
              </div>

              <pre className="p-4 rounded-2xl bg-slate-950 text-emerald-400 text-xs font-mono overflow-x-auto leading-relaxed border border-slate-800">
                {projectTree}
              </pre>
            </div>
          )}

          {activeTab === 'code' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-xs text-slate-600 dark:text-slate-300">
                  Expo Router bottom navigation va tablar sozlamasi:
                </p>
                <button
                  type="button"
                  onClick={() => copyToClipboard(sampleNativeCode, 'code')}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-medium flex items-center gap-1 text-slate-700 dark:text-slate-300 transition-colors shrink-0"
                >
                  {copiedSection === 'code' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedSection === 'code' ? 'Nusxalandi' : 'Nusxa olish'}</span>
                </button>
              </div>

              <pre className="p-4 rounded-2xl bg-slate-950 text-blue-300 text-xs font-mono overflow-x-auto leading-relaxed border border-slate-800">
                {sampleNativeCode}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
