import React from 'react';
import { NotificationItem, Language } from '../types';
import { getTranslation } from '../i18n/translations';
import { StorageService } from '../services/storage';
import { Bell, CheckCheck, X, Ticket, AlertCircle, Sparkles, Clock } from 'lucide-react';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onSelectTicket?: (ticketId: string) => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
  language,
  onSelectTicket,
}) => {
  if (!isOpen) return null;

  const t = getTranslation(language);
  const notifications = StorageService.getNotifications();

  const handleMarkAllRead = () => {
    StorageService.markNotificationsRead();
  };

  const handleCreateTestNotification = () => {
    StorageService.addNotification({
      id: `notif_test_${Date.now()}`,
      title: {
        uz: 'Navbat tezlashmoqda! (Darcha №2)',
        ru: 'Очередь ускоряется! (Окно №2)',
        en: 'Queue moving faster! (Window №2)',
      },
      body: {
        uz: 'Agrobank Chilonzor filialida xizmat tezlashdi. Sizning navbatingizga 5 daqiqa qoldi.',
        ru: 'В филиале Агробанка обслуживание ускорилось. До вашего вызова осталось 5 минут.',
        en: 'Service speed increased at Agrobank Chilonzor. Only 5 minutes until your turn.',
      },
      time: 'Hozirgina',
      type: 'ticket',
      isRead: false,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="w-full sm:max-w-md max-h-[85vh] bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white leading-tight">
                {t.notificationsTitle}
              </h3>
              <p className="text-[11px] text-slate-400">
                {notifications.filter((n) => !n.isRead).length} ta o‘qilmagan
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={handleMarkAllRead}
              title={t.markAllRead}
              className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <CheckCheck className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 hover:text-slate-900 dark:hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* List of Notifications */}
        <div className="p-4 overflow-y-auto space-y-2.5 flex-1">
          {notifications.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs">
              <Bell className="w-8 h-8 mx-auto mb-2 opacity-40" />
              <p>{t.noNotifications}</p>
            </div>
          ) : (
            notifications.map((notif) => {
              const title = notif.title[language] || notif.title.uz;
              const body = notif.body[language] || notif.body.uz;

              return (
                <div
                  key={notif.id}
                  onClick={() => {
                    if (notif.ticketId && onSelectTicket) {
                      onSelectTicket(notif.ticketId);
                      onClose();
                    }
                  }}
                  className={`p-3.5 rounded-2xl border text-xs transition-all ${
                    !notif.isRead
                      ? 'border-blue-200 dark:border-blue-900/60 bg-blue-50/40 dark:bg-blue-950/20'
                      : 'border-slate-100 dark:border-slate-800/80 bg-white dark:bg-slate-900'
                  } ${notif.ticketId ? 'cursor-pointer hover:border-blue-400' : ''}`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2.5">
                      <div
                        className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
                          notif.type === 'ticket'
                            ? 'bg-blue-100 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400'
                            : 'bg-amber-100 dark:bg-amber-950/80 text-amber-600 dark:text-amber-400'
                        }`}
                      >
                        {notif.type === 'ticket' ? (
                          <Ticket className="w-3.5 h-3.5" />
                        ) : (
                          <AlertCircle className="w-3.5 h-3.5" />
                        )}
                      </div>
                      <div>
                        <h4 className="font-semibold text-slate-900 dark:text-white leading-tight">
                          {title}
                        </h4>
                        <p className="text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                          {body}
                        </p>
                      </div>
                    </div>

                    {!notif.isRead && (
                      <span className="w-2 h-2 rounded-full bg-blue-600 shrink-0 mt-1" />
                    )}
                  </div>

                  <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-100 dark:border-slate-800/60 text-[10px] text-slate-400">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {notif.time}
                    </span>
                    {notif.ticketId && (
                      <span className="text-blue-600 dark:text-blue-400 font-medium">
                        Talonni ochish →
                      </span>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer with Test button */}
        <div className="p-3.5 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900">
          <button
            type="button"
            onClick={handleCreateTestNotification}
            className="w-full py-2 px-3 rounded-xl border border-dashed border-blue-300 dark:border-blue-800 hover:bg-blue-50 dark:hover:bg-blue-950/40 text-blue-600 dark:text-blue-400 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{t.testNotificationBtn}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
