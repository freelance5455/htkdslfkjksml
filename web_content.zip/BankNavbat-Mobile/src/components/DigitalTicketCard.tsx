import React, { useState } from 'react';
import { QueueTicket, Language } from '../types';
import { getTranslation } from '../i18n/translations';
import { BankLogo } from './BankLogo';
import { QRCodeDisplay } from './QRCodeDisplay';
import { MOCK_BANKS } from '../data/mockData';
import { StorageService } from '../services/storage';
import {
  Clock,
  MapPin,
  Users,
  CheckCircle2,
  XCircle,
  Share2,
  Calendar,
  ChevronRight,
  AlertTriangle,
  Sparkles,
  Volume2,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { motion, AnimatePresence } from 'motion/react';

interface DigitalTicketCardProps {
  ticket: QueueTicket;
  language: Language;
  onCancelRequest?: (ticketId: string) => void;
  onRateRequest?: (ticket: QueueTicket) => void;
  onSelectBranch?: (branchId: string) => void;
  isDetailed?: boolean;
}

export const DigitalTicketCard: React.FC<DigitalTicketCardProps> = ({
  ticket,
  language,
  onCancelRequest,
  onRateRequest,
  onSelectBranch,
  isDetailed = true,
}) => {
  const t = getTranslation(language);
  const [currentTicket, setCurrentTicket] = useState<QueueTicket>(ticket);
  const [showConfirmCancel, setShowConfirmCancel] = useState(false);
  const [copiedNotice, setCopiedNotice] = useState(false);

  const bank = MOCK_BANKS.find((b) => b.id === currentTicket.bankId);

  const handleSimulateQueueMove = () => {
    if (currentTicket.peopleAhead > 0) {
      const nextPeople = currentTicket.peopleAhead - 1;
      const nextWait = Math.max(2, Math.round(nextPeople * 3.5));
      const updated = StorageService.updateTicket(currentTicket.id, {
        peopleAhead: nextPeople,
        estimatedWaitMinutes: nextWait,
        status: nextPeople === 0 ? 'waiting' : 'active',
      });
      if (updated) {
        setCurrentTicket(updated);
        if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
          navigator.vibrate(40);
        }
        // Fire little confetti if your turn arrived
        if (nextPeople === 0) {
          confetti({ particleCount: 40, spread: 60, origin: { y: 0.6 } });
          if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
            navigator.vibrate([80, 50, 80]);
          }
        }
      }
    }
  };

  const handleSimulateCall = () => {
    const updated = StorageService.updateTicket(currentTicket.id, {
      peopleAhead: 0,
      estimatedWaitMinutes: 0,
      status: 'in_service',
    });
    if (updated) {
      setCurrentTicket(updated);
      confetti({ particleCount: 70, spread: 80, origin: { y: 0.5 } });
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        navigator.vibrate([100, 50, 150]);
      }
    }
  };

  const handleSimulateComplete = () => {
    const updated = StorageService.updateTicket(currentTicket.id, {
      status: 'completed',
    });
    if (updated) {
      setCurrentTicket(updated);
      if (onRateRequest) {
        onRateRequest(updated);
      }
    }
  };

  const handleShare = async () => {
    const shareText = `BankNavbat.uz e-Talon:\nBank: ${currentTicket.bankName}\nFilial: ${currentTicket.branchName}\nTalon: ${currentTicket.ticketNumber}\nVaqt: ${currentTicket.date} ${currentTicket.timeSlot}\nDarcha: ${currentTicket.windowNumber}\n\nNavbatingizni oldindan oling: ${window.location.origin}`;
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: `BankNavbat: ${currentTicket.ticketNumber} - ${currentTicket.bankName}`,
          text: shareText,
          url: window.location.href,
        });
        return;
      } catch {
        // Fallback to clipboard if user dismissed or permission denied
      }
    }
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      try {
        await navigator.clipboard.writeText(shareText);
        setCopiedNotice(true);
        setTimeout(() => setCopiedNotice(false), 2500);
      } catch {
        // Clipboard write failed
      }
    }
  };

  const getStatusBadge = () => {
    switch (currentTicket.status) {
      case 'active':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 text-xs font-semibold rounded-md bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200/50">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
            {t.ticketStatusActive}
          </span>
        );
      case 'waiting':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 text-xs font-semibold rounded-md bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-200/50">
            <Clock className="w-3 h-3 text-amber-500" />
            {t.ticketStatusWaiting}
          </span>
        );
      case 'in_service':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 text-xs font-semibold rounded-md bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200/50">
            <Volume2 className="w-3 h-3 text-emerald-500" />
            {t.ticketStatusInService}
          </span>
        );
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 text-xs font-semibold rounded-md bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
            <CheckCircle2 className="w-3 h-3 text-slate-500" />
            {t.ticketStatusCompleted}
          </span>
        );
      case 'cancelled':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 text-xs font-semibold rounded-md bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300">
            <XCircle className="w-3 h-3 text-rose-500" />
            {t.ticketStatusCancelled}
          </span>
        );
    }
  };

  const isActionable = currentTicket.status === 'active' || currentTicket.status === 'waiting';

  return (
    <div className="relative overflow-hidden rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-md transition-all">
      {/* Top Bank Header Bar with Holographic Glint */}
      <div
        className="relative overflow-hidden p-4 sm:p-5 text-white flex items-center justify-between"
        style={{
          background: `linear-gradient(135deg, ${bank?.logoColor || '#102B5C'} 0%, #0E2550 100%)`,
        }}
      >
        {/* Holographic sweep beam */}
        <motion.div
          animate={{ x: [-150, 400] }}
          transition={{ duration: 4, repeat: Infinity, repeatDelay: 3 }}
          className="absolute inset-0 w-16 h-full bg-white/15 skew-x-12 blur-xs pointer-events-none"
        />

        <div className="flex items-center gap-3 relative z-10">
          <BankLogo bank={bank} size="md" className="ring-2 ring-white/30" />
          <div>
            <h4 className="font-bold text-base tracking-tight leading-tight">{currentTicket.bankName}</h4>
            <p className="text-xs text-white/80 line-clamp-1">{currentTicket.branchName}</p>
          </div>
        </div>
        <div className="shrink-0 relative z-10">{getStatusBadge()}</div>
      </div>

      {/* Main Ticket Centerpiece */}
      <div className="p-5 sm:p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-dashed border-slate-200 dark:border-slate-800 pb-5">
          <div>
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              {t.ticketTitle}
            </p>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="text-4xl font-extrabold tracking-tight font-mono text-slate-900 dark:text-white tabular-nums">
                {currentTicket.ticketNumber}
              </span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                {currentTicket.windowNumber}
              </span>
            </div>
            <p className="text-sm font-medium text-slate-700 dark:text-slate-300 mt-2">
              {currentTicket.serviceName}
            </p>
          </div>

          {/* QR Code Container with High-tech Laser Scan Beam */}
          <div className="relative flex items-center justify-center p-2.5 rounded-2xl bg-white shadow-xs border border-slate-200/90 overflow-hidden shrink-0">
            <QRCodeDisplay value={currentTicket.qrCodeValue} size={110} />
            {/* Animated Laser Beam */}
            <div className="absolute left-2 right-2 h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_8px_#22d3ee] animate-scanline pointer-events-none" />
          </div>
        </div>

        {/* Live Wait & Ahead Metrics (if active) with animated pop */}
        {isActionable && (
          <div className="grid grid-cols-2 gap-3 p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-blue-100/70 dark:bg-blue-950/80 flex items-center justify-center text-blue-600 dark:text-blue-400 shrink-0">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400">{t.peopleAhead}</p>
                <div className="flex items-baseline gap-1">
                  <AnimatePresence mode="popLayout">
                    <motion.span
                      key={currentTicket.peopleAhead}
                      initial={{ scale: 1.4, color: '#2563eb' }}
                      animate={{ scale: 1, color: 'inherit' }}
                      transition={{ type: 'spring', stiffness: 400, damping: 20 }}
                      className="text-base font-bold text-slate-900 dark:text-white tabular-nums inline-block"
                    >
                      {currentTicket.peopleAhead}
                    </motion.span>
                  </AnimatePresence>
                  <span className="text-base font-bold text-slate-900 dark:text-white">
                    {t.people}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-emerald-100/70 dark:bg-emerald-950/80 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shrink-0">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400">{t.estimatedWait}</p>
                <div className="flex items-baseline gap-1">
                  <AnimatePresence mode="popLayout">
                    <motion.span
                      key={currentTicket.estimatedWaitMinutes}
                      initial={{ scale: 1.3, color: '#059669' }}
                      animate={{ scale: 1, color: 'inherit' }}
                      transition={{ type: 'spring', stiffness: 400, damping: 20 }}
                      className="text-base font-bold text-slate-900 dark:text-white tabular-nums inline-block"
                    >
                      ~{currentTicket.estimatedWaitMinutes}
                    </motion.span>
                  </AnimatePresence>
                  <span className="text-base font-bold text-slate-900 dark:text-white">
                    {t.minutesShort}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Time, Date and Location Info */}
        <div className="space-y-2 text-xs text-slate-600 dark:text-slate-400">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-slate-400 shrink-0" />
            <span className="font-medium text-slate-900 dark:text-slate-200">
              {currentTicket.date} · {currentTicket.timeSlot}
            </span>
          </div>
          <div className="flex items-start gap-2">
            <MapPin className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
            <span className="line-clamp-2">{currentTicket.branchAddress}</span>
          </div>
        </div>

        {/* Action Controls & Simulator Controls */}
        {isDetailed && (
          <div className="space-y-3 pt-2">
            {/* Live Interactive Simulator controls for Demo / Jury */}
            {isActionable && (
              <div className="p-3.5 rounded-xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200/50 dark:border-blue-900/40 space-y-2.5">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-blue-800 dark:text-blue-300">
                  <Sparkles className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                  <span>Demo simulyatsiyasi (Real vaqt)</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <motion.button
                    type="button"
                    whileTap={{ scale: 0.95 }}
                    onClick={handleSimulateQueueMove}
                    disabled={currentTicket.peopleAhead === 0}
                    className="w-full px-2.5 py-1.5 text-xs font-medium rounded-lg bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 shadow-xs hover:bg-slate-50 disabled:opacity-50 transition-colors cursor-pointer"
                  >
                    {t.simulateQueueMove}
                  </motion.button>
                  <motion.button
                    type="button"
                    whileTap={{ scale: 0.95 }}
                    onClick={handleSimulateCall}
                    className="w-full px-2.5 py-1.5 text-xs font-medium rounded-lg bg-blue-600 text-white shadow-xs hover:bg-blue-700 transition-colors cursor-pointer"
                  >
                    {t.simulateWindowCall}
                  </motion.button>
                </div>
              </div>
            )}

            {currentTicket.status === 'in_service' && (
              <button
                type="button"
                onClick={handleSimulateComplete}
                className="w-full py-2.5 text-xs font-semibold rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm flex items-center justify-center gap-1.5 transition-colors"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Xizmatni yakunlash va baholash</span>
              </button>
            )}

            {currentTicket.status === 'completed' && !currentTicket.ratingGiven && onRateRequest && (
              <button
                type="button"
                onClick={() => onRateRequest(currentTicket)}
                className="w-full py-2.5 text-xs font-semibold rounded-xl bg-amber-500 hover:bg-amber-600 text-white shadow-sm flex items-center justify-center gap-1.5 transition-colors"
              >
                <Sparkles className="w-4 h-4" />
                <span>{t.rateService}</span>
              </button>
            )}

            {currentTicket.status === 'completed' && currentTicket.ratingGiven && (
              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 text-emerald-800 dark:text-emerald-300 text-xs flex items-center justify-between">
                <span>{t.ratingSubmitted}</span>
                <span className="font-bold">★ {currentTicket.ratingGiven}/5</span>
              </div>
            )}

            {/* General Actions: Share & Cancel */}
            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={handleShare}
                className="flex-1 py-2 text-xs font-medium rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center gap-1.5 transition-colors"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>{copiedNotice ? 'Nusxa olindi!' : t.shareTicket}</span>
              </button>

              {isActionable && (
                <button
                  type="button"
                  onClick={() => setShowConfirmCancel(true)}
                  className="py-2 px-3 text-xs font-medium rounded-xl text-rose-600 hover:bg-rose-50 dark:text-rose-400 dark:hover:bg-rose-950/40 transition-colors"
                >
                  {t.cancelBooking}
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Confirmation Modal for Cancel */}
      {showConfirmCancel && (
        <div className="absolute inset-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xs flex flex-col justify-center items-center p-6 text-center z-20">
          <div className="w-12 h-12 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center mb-3">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <h4 className="font-bold text-base text-slate-900 dark:text-white">
            {t.cancelConfirmTitle}
          </h4>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs">
            {t.cancelConfirmDesc}
          </p>
          <div className="flex items-center gap-2 w-full mt-4 max-w-xs">
            <button
              type="button"
              onClick={() => setShowConfirmCancel(false)}
              className="flex-1 py-2 text-xs font-medium rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
            >
              {t.noKeep}
            </button>
            <button
              type="button"
              onClick={() => {
                StorageService.cancelTicket(currentTicket.id);
                setCurrentTicket({ ...currentTicket, status: 'cancelled' });
                setShowConfirmCancel(false);
                if (onCancelRequest) onCancelRequest(currentTicket.id);
              }}
              className="flex-1 py-2 text-xs font-semibold rounded-xl bg-rose-600 text-white hover:bg-rose-700"
            >
              {t.yesCancel}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
