import React from 'react';
import { OccupancyLevel, Language } from '../types';
import { Users, AlertCircle, CheckCircle2, Clock } from 'lucide-react';
import { getTranslation } from '../i18n/translations';

interface OccupancyBadgeProps {
  level: OccupancyLevel;
  count?: number;
  language?: Language;
  showIcon?: boolean;
  className?: string;
}

export const OccupancyBadge: React.FC<OccupancyBadgeProps> = ({
  level,
  count,
  language = 'uz',
  showIcon = true,
  className = '',
}) => {
  const t = getTranslation(language);

  const config = {
    low: {
      label: t.lowOccupancy,
      colorClass: 'text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200/60 dark:border-emerald-800/40',
      icon: CheckCircle2,
      dotColor: 'bg-emerald-500',
    },
    medium: {
      label: t.mediumOccupancy,
      colorClass: 'text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40 border-amber-200/60 dark:border-amber-800/40',
      icon: Clock,
      dotColor: 'bg-amber-500',
    },
    high: {
      label: t.highOccupancy,
      colorClass: 'text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/40 border-rose-200/60 dark:border-rose-800/40',
      icon: AlertCircle,
      dotColor: 'bg-rose-500',
    },
  }[level];

  const IconComponent = config.icon;

  return (
    <div
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-lg border ${config.colorClass} ${className}`}
    >
      <span className="relative flex h-2 w-2">
        <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${config.dotColor} opacity-75`} />
        <span className={`relative inline-flex rounded-full h-2 w-2 ${config.dotColor}`} />
      </span>
      {showIcon && <IconComponent className="w-3.5 h-3.5 shrink-0" />}
      <span>{config.label}</span>
      {typeof count === 'number' && (
        <span className="opacity-80 tabular-nums">
          ({count} {t.people})
        </span>
      )}
    </div>
  );
};
