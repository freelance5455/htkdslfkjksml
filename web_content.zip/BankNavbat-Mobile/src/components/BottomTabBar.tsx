import React from 'react';
import { Language } from '../types';
import { getTranslation } from '../i18n/translations';
import { Home, Building2, Map, Ticket, User } from 'lucide-react';
import { motion } from 'motion/react';

export type NavTab = 'home' | 'branches' | 'map' | 'queues' | 'profile';

interface BottomTabBarProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  language: Language;
  activeTicketsCount?: number;
}

export const BottomTabBar: React.FC<BottomTabBarProps> = ({
  activeTab,
  onTabChange,
  language,
  activeTicketsCount = 0,
}) => {
  const t = getTranslation(language);

  const tabs: { id: NavTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'home', label: t.tabHome, icon: Home },
    { id: 'branches', label: t.tabBranches, icon: Building2 },
    { id: 'map', label: t.tabMap, icon: Map },
    { id: 'queues', label: t.tabQueues, icon: Ticket },
    { id: 'profile', label: t.tabProfile, icon: User },
  ];

  return (
    <nav
      aria-label="Bottom Navigation"
      className="sticky bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200/80 dark:border-slate-800 shadow-lg px-2 py-1.5 transition-colors"
    >
      <div className="grid grid-cols-5 items-center max-w-lg mx-auto relative">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          const Icon = tab.icon;

          return (
            <motion.button
              key={tab.id}
              type="button"
              onClick={() => onTabChange(tab.id)}
              whileTap={{ scale: 0.90 }}
              className={`relative flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-colors duration-150 min-h-[48px] select-none ${
                isActive
                  ? 'text-blue-600 dark:text-blue-400 font-semibold'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              {/* Active Tab Spring Indicator Pill */}
              {isActive && (
                <motion.div
                  layoutId="activeTabPill"
                  className="absolute -top-1.5 w-7 h-1 rounded-full bg-blue-600 dark:bg-blue-400 shadow-sm shadow-blue-500/40"
                  transition={{ type: 'spring', stiffness: 500, damping: 35 }}
                />
              )}

              {/* Active Tab Ambient Glow Background */}
              {isActive && (
                <motion.div
                  layoutId="activeTabBackground"
                  className="absolute inset-0 bg-blue-50/70 dark:bg-blue-950/40 rounded-xl -z-10"
                  transition={{ type: 'spring', stiffness: 450, damping: 32 }}
                />
              )}

              <div className="relative">
                <motion.div
                  animate={{ scale: isActive ? 1.12 : 1 }}
                  transition={{ type: 'spring', stiffness: 400, damping: 25 }}
                >
                  <Icon className="w-5 h-5" />
                </motion.div>

                {/* Active badge for tickets tab */}
                {tab.id === 'queues' && activeTicketsCount > 0 && (
                  <motion.span
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute -top-1.5 -right-2 px-1.5 py-0.2 text-[10px] font-bold rounded-full bg-blue-600 text-white tabular-nums shadow-xs flex items-center justify-center"
                  >
                    {activeTicketsCount}
                  </motion.span>
                )}
              </div>

              <span className="text-[11px] tracking-tight mt-1 truncate max-w-[68px]">
                {tab.label}
              </span>
            </motion.button>
          );
        })}
      </div>
    </nav>
  );
};
