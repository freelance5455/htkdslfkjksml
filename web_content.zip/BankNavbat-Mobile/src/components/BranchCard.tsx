import React from 'react';
import { BankBranch, Language } from '../types';
import { MOCK_BANKS } from '../data/mockData';
import { BankLogo } from './BankLogo';
import { OccupancyBadge } from './OccupancyBadge';
import { getTranslation } from '../i18n/translations';
import { StorageService } from '../services/storage';
import { Star, MapPin, Clock, ChevronRight } from 'lucide-react';
import { motion } from 'motion/react';

interface BranchCardProps {
  branch: BankBranch;
  language: Language;
  distanceKm?: number;
  onBookQueue: (branch: BankBranch) => void;
  onViewDetails: (branch: BankBranch) => void;
  isFavorite?: boolean;
  onToggleFavorite?: (branchId: string) => void;
}

export const BranchCard: React.FC<BranchCardProps> = ({
  branch,
  language,
  distanceKm,
  onBookQueue,
  onViewDetails,
  isFavorite = false,
  onToggleFavorite,
}) => {
  const t = getTranslation(language);
  const bank = MOCK_BANKS.find((b) => b.id === branch.bankId);

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onToggleFavorite) {
      onToggleFavorite(branch.id);
    } else {
      StorageService.toggleFavoriteBranch(branch.id);
    }
  };

  return (
    <motion.div
      onClick={() => onViewDetails(branch)}
      whileHover={{ y: -3, transition: { duration: 0.2 } }}
      whileTap={{ scale: 0.98 }}
      className="group relative bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200/80 dark:border-slate-800 shadow-xs hover:shadow-lg hover:border-blue-400/50 dark:hover:border-blue-500/30 transition-all cursor-pointer select-none"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <BankLogo bank={bank} size="md" />
          <div>
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-xs font-semibold text-blue-600 dark:text-blue-400">
                {bank?.name || 'Bank'}
              </span>
              <span className="text-slate-300 dark:text-slate-600">·</span>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                {branch.city}
              </span>
            </div>
            <h4 className="font-bold text-slate-900 dark:text-white text-sm sm:text-base leading-tight mt-0.5 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
              {branch.name}
            </h4>
          </div>
        </div>

        {/* Favorite Star Button with Micro-pop */}
        <motion.button
          type="button"
          onClick={handleFavoriteClick}
          whileTap={{ scale: 1.3, rotate: 15 }}
          aria-label={isFavorite ? 'Remove favorite' : 'Add favorite'}
          className={`p-2 rounded-xl transition-colors shrink-0 ${
            isFavorite
              ? 'text-amber-500 bg-amber-50 dark:bg-amber-950/40'
              : 'text-slate-400 hover:text-amber-500 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Star className={`w-4 h-4 ${isFavorite ? 'fill-amber-400 text-amber-500' : ''}`} />
        </motion.button>
      </div>

      {/* Address */}
      <div className="flex items-start gap-1.5 mt-3 text-xs text-slate-600 dark:text-slate-400">
        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
        <span className="line-clamp-1">{branch.address}</span>
      </div>

      {/* Badges & Metrics Row */}
      <div className="flex items-center justify-between gap-2 mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs">
        <OccupancyBadge
          level={branch.occupancyLevel}
          count={branch.currentQueueCount}
          language={language}
        />

        <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-slate-400" />
            <span className="tabular-nums font-medium text-slate-700 dark:text-slate-300">
              ~{branch.averageWaitMinutes} {t.minutesShort}
            </span>
          </div>

          {typeof distanceKm === 'number' && (
            <>
              <span>·</span>
              <span className="tabular-nums font-medium text-blue-600 dark:text-blue-400">
                {distanceKm < 1 ? `${Math.round(distanceKm * 1000)}m` : `${distanceKm.toFixed(1)}km`}
              </span>
            </>
          )}

          <span>·</span>
          <div className="flex items-center gap-0.5 text-amber-500 font-medium">
            <Star className="w-3 h-3 fill-amber-400" />
            <span>{branch.rating.toFixed(1)}</span>
          </div>
        </div>
      </div>

      {/* Action Row */}
      <div className="flex items-center gap-2 mt-3.5">
        <motion.button
          type="button"
          whileTap={{ scale: 0.96 }}
          onClick={(e) => {
            e.stopPropagation();
            onBookQueue(branch);
          }}
          className="flex-1 py-2 px-3 text-xs font-semibold rounded-xl bg-blue-600 hover:bg-blue-700 text-white shadow-xs transition-colors flex items-center justify-center gap-1 cursor-pointer"
        >
          <span>{t.bookQueue}</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </motion.button>

        <motion.button
          type="button"
          whileTap={{ scale: 0.96 }}
          onClick={(e) => {
            e.stopPropagation();
            onViewDetails(branch);
          }}
          className="py-2 px-3 text-xs font-medium rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
        >
          {t.viewDetails}
        </motion.button>
      </div>
    </motion.div>
  );
};

