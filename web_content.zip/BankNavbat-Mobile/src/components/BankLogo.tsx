import React from 'react';
import { Bank } from '../types';

interface BankLogoProps {
  bank?: Bank;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const BankLogo: React.FC<BankLogoProps> = ({ bank, size = 'md', className = '' }) => {
  const sizeClasses = {
    sm: 'w-7 h-7 text-xs rounded-lg',
    md: 'w-10 h-10 text-sm rounded-xl',
    lg: 'w-14 h-14 text-base rounded-2xl',
  };

  const getBankInitials = (b?: Bank) => {
    if (!b) return 'BN';
    if (b.code) return b.code.slice(0, 3);
    return b.name.slice(0, 2).toUpperCase();
  };

  const bgColor = bank?.logoColor || '#102B5C';
  const textColor = bank?.textColor || '#FFFFFF';

  return (
    <div
      className={`relative inline-flex items-center justify-center font-bold tracking-tight shadow-xs select-none shrink-0 ${sizeClasses[size]} ${className}`}
      style={{ backgroundColor: bgColor, color: textColor }}
    >
      <span className="font-mono font-semibold tracking-wider">{getBankInitials(bank)}</span>
      {/* Subtle glossy sheen */}
      <div className="absolute inset-0 rounded-inherit bg-gradient-to-tr from-white/0 via-white/10 to-white/20 pointer-events-none" />
    </div>
  );
};
