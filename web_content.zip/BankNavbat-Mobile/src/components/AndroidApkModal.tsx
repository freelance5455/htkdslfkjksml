import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import {
  X,
  Smartphone,
  Download,
  Terminal,
  Check,
  Copy,
  ExternalLink,
  ShieldCheck,
  Sparkles,
  ArrowDownToLine,
  HelpCircle,
} from 'lucide-react';

interface AndroidApkModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidApkModal: React.FC<AndroidApkModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'pwa' | 'eas' | 'zip'>('pwa');
  const [copiedCmd, setCopiedCmd] = useState<string>('');

  const copyToClipboard = (text: string, id: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopiedCmd(id);
      setTimeout(() => setCopiedCmd(''), 2000);
    }
  };

  const easBuildCmd = `npm install -g eas-cli
eas login
eas build -p android --profile preview`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="w-full max-w-2xl max-h-[92vh] bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shadow-xs">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white leading-tight">
                Android APK & Ilovani o‘rnatish markazi
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                BankNavbat.uz mobil ilovasini Android smartfoniga o‘rnatish usullari
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 hover:text-slate-900 dark:hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab selection */}
        <div className="flex items-center gap-1 px-5 pt-3 border-b border-slate-100 dark:border-slate-800 overflow-x-auto no-scrollbar">
          <button
            type="button"
            onClick={() => setActiveTab('pwa')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-t-xl transition-all border-b-2 flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'pwa'
                ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400 bg-emerald-50/50 dark:bg-emerald-950/30'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>1-usul: Tezkor Android APK (WebAPK)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('zip')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-t-xl transition-all border-b-2 flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'zip'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-950/30'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <ArrowDownToLine className="w-3.5 h-3.5" />
            <span>2-usul: Expo ZIP arxivini yuklash</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('eas')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-t-xl transition-all border-b-2 flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'eas'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-950/30'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>3-usul: EAS Cloud Build (.apk)</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4">
          {activeTab === 'pwa' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-emerald-50/80 dark:bg-emerald-950/30 border border-emerald-200/60 dark:border-emerald-800/40 space-y-3">
                <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-300 font-bold text-xs sm:text-sm">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Google Chrome & Android WebAPK Texnologiyasi</span>
                </div>
                <p className="text-xs text-emerald-900/80 dark:text-emerald-200/80 leading-relaxed">
                  Android tizimida Google Chrome yoki Samsung Internet orqali ilovani ochganingizda, telefoningiz uni <strong>haqiqiy mahalliy Android ilovasi (.apk)</strong> sifatida yaratadi va Bosh ekranga o‘rnatadi.
                </p>

                {isInstalled ? (
                  <div className="p-3 rounded-xl bg-emerald-600 text-white text-xs font-semibold flex items-center justify-center gap-2">
                    <Check className="w-4 h-4" />
                    <span>Ilova allaqachon smartfoningizga o‘rnatilgan!</span>
                  </div>
                ) : isInstallable ? (
                  <button
                    type="button"
                    onClick={install}
                    className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 transition-all active:scale-98"
                  >
                    <Download className="w-4 h-4" />
                    <span>Ilovani hozir o‘rnatish (1-klik)</span>
                  </button>
                ) : (
                  <div className="p-3 rounded-xl bg-white/70 dark:bg-slate-900/70 border border-emerald-200 dark:border-emerald-800 text-xs text-slate-700 dark:text-slate-300 space-y-1.5">
                    <span className="font-semibold block">Qo‘lda o‘rnatish bo‘yicha qo‘llanma:</span>
                    <ol className="list-decimal list-inside space-y-1 text-slate-600 dark:text-slate-400">
                      <li>Android smartfoningizda ushbu havolani <strong>Google Chrome</strong>da oching.</li>
                      <li>Brauzerning o‘ng yuqori qismidagi <strong>uch nuqta (⋮)</strong> menyusini bosing.</li>
                      <li><strong>"Ilovani o‘rnatish"</strong> yoki <strong>"Bosh ekranga qo‘shish"</strong> bandini tanlang.</li>
                      <li>Ilova o‘z logotipi bilan telefoningizda alohida ilova bo‘lib o‘rnatiladi!</li>
                    </ol>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'zip' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-blue-50/80 dark:bg-blue-950/30 border border-blue-200/60 dark:border-blue-800/40 space-y-3">
                <div className="flex items-center gap-2 text-blue-900 dark:text-blue-300 font-bold text-xs sm:text-sm">
                  <ArrowDownToLine className="w-4 h-4 text-blue-600" />
                  <span>Tayyor Expo & React Native loyiha fayllari (.ZIP)</span>
                </div>
                <p className="text-xs text-blue-900/80 dark:text-blue-200/80 leading-relaxed">
                  Loyiha barcha komponentlari, xizmatlari, tillari, <code>app.json</code> va <code>eas.json</code> sozlamalari bilan birga arxivlandi. Siz uni yuklab olib, o‘z kompyuteringizda yoki Android Studio / Expo muhitida bevosita yurgizishingiz mumkin.
                </p>

                <a
                  href="/BankNavbat-Expo-Android.zip"
                  download="BankNavbat-Expo-Android.zip"
                  className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-600/20 flex items-center justify-center gap-2 transition-all active:scale-98 cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>BankNavbat-Expo-Android.zip yuklab olish (224 KB)</span>
                </a>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 text-xs text-slate-600 dark:text-slate-400 space-y-1">
                <span className="font-semibold text-slate-900 dark:text-white">Arxiv ichida:</span>
                <p>• <code>package.json</code> va barcha kutubxonalar ro‘yxati</p>
                <p>• <code>app.json</code> (uz.banknavbat.app identifikatori bilan)</p>
                <p>• <code>eas.json</code> (APK profili bilan)</p>
                <p>• <code>src/</code> papkasidagi to‘liq komponentlar va hisoblash logikasi</p>
              </div>
            </div>
          )}

          {activeTab === 'eas' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-xs text-slate-600 dark:text-slate-300">
                  Expo Application Services (EAS) orqali to‘g‘ridan-to‘g‘ri <strong>.apk</strong> fayl havolasini olish:
                </p>
                <button
                  type="button"
                  onClick={() => copyToClipboard(easBuildCmd, 'eas')}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-medium flex items-center gap-1 text-slate-700 dark:text-slate-300 transition-colors shrink-0"
                >
                  {copiedCmd === 'eas' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCmd === 'eas' ? 'Nusxalandi' : 'Nusxa olish'}</span>
                </button>
              </div>

              <pre className="p-4 rounded-2xl bg-slate-950 text-emerald-400 text-xs font-mono overflow-x-auto leading-relaxed border border-slate-800">
                {easBuildCmd}
              </pre>

              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 text-xs space-y-1 text-slate-600 dark:text-slate-300">
                <p className="font-semibold text-slate-900 dark:text-white">Build jarayoni qanday kechadi?</p>
                <p>1. EAS buyrug‘i Expo bulutli serverlariga loyihani yuklaydi.</p>
                <p>2. Google Gradle serverlarida <code>.apk</code> yig‘iladi.</p>
                <p>3. Terminalda to‘g‘ridan-to‘g‘ri yuklab olish havolasi (<code>https://expo.dev/artifacts/eas/...apk</code>) chiqadi.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
