export type Language = 'uz' | 'ru' | 'en';

export type OccupancyLevel = 'low' | 'medium' | 'high';

export type TicketStatus = 'active' | 'waiting' | 'in_service' | 'completed' | 'cancelled';

export interface Bank {
  id: string;
  name: string;
  shortName: string;
  code: string;
  logoColor: string;
  textColor: string;
  website: string;
  hotline: string;
  description: {
    uz: string;
    ru: string;
    en: string;
  };
}

export interface BankBranch {
  id: string;
  bankId: string;
  name: string;
  code: string;
  address: string;
  city: string;
  district: string;
  lat: number;
  lng: number;
  phone: string;
  workHours: string;
  workDays: string;
  occupancyLevel: OccupancyLevel;
  currentQueueCount: number;
  averageWaitMinutes: number;
  services: string[];
  rating: number;
  reviewsCount: number;
  isFavorite?: boolean;
}

export interface BankService {
  id: string;
  category: 'cards' | 'credits' | 'currency' | 'deposits' | 'transfers' | 'business';
  serviceCode: string;
  name: {
    uz: string;
    ru: string;
    en: string;
  };
  description: {
    uz: string;
    ru: string;
    en: string;
  };
  averageDurationMinutes: number;
  icon: string;
  requiredDocuments: {
    uz: string[];
    ru: string[];
    en: string[];
  };
}

export interface QueueTicket {
  id: string;
  ticketNumber: string;
  bankId: string;
  bankName: string;
  branchId: string;
  branchName: string;
  branchAddress: string;
  serviceId: string;
  serviceName: string;
  serviceCode: string;
  date: string;
  timeSlot: string;
  windowNumber: string;
  status: TicketStatus;
  createdAt: string;
  estimatedWaitMinutes: number;
  peopleAhead: number;
  clientName: string;
  clientPhone: string;
  qrCodeValue: string;
  ratingGiven?: number;
  reviewGiven?: string;
  speedRating?: number;
}

export interface NotificationItem {
  id: string;
  title: {
    uz: string;
    ru: string;
    en: string;
  };
  body: {
    uz: string;
    ru: string;
    en: string;
  };
  time: string;
  type: 'ticket' | 'alert' | 'service';
  isRead: boolean;
  ticketId?: string;
}

export interface BranchReview {
  id: string;
  branchId: string;
  userName: string;
  rating: number;
  speedRating: number;
  comment: string;
  date: string;
  serviceName: string;
}

export interface UserProfile {
  name: string;
  phone: string;
  language: Language;
  notificationsEnabled: boolean;
  soundEnabled: boolean;
  favoriteBranchIds: string[];
  hasCompletedOnboarding: boolean;
}
