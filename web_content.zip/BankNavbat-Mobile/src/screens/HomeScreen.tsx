import React from 'react';
import { BankBranch, QueueTicket, Language, BankService } from '../types';
import { MOCK_BANKS, MOCK_BRANCHES, MOCK_SERVICES } from '../data/mockData';
import { BankLogo } from '../components/BankLogo';
import { OccupancyBadge } from '../components/OccupancyBadge';
import { BranchCard } from '../components/BranchCard';
import { getTranslation } from '../i18n/translations';
import { StorageService } from '../services/storage';
import {
  Search,
  Calendar,
  Sparkles,
  Ticket,
  ChevronRight,
  CreditCard,
  ArrowLeftRight,
  BadgePercent,
  PiggyBank,
  Send,
  Briefcase,
  Users,
  Clock,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { motion } from 'motion/react';

interface HomeScreenProps {
  language: Language;
  onOpenBooking: (preselected?: { branch?: BankBranch; service?: BankService }) => void;
  onSelectBranch: (branch: BankBranch) => void;
  onViewTicket: (ticket: QueueTicket) => void;
  onNavigateToBranches: (searchQuery?: string) => void;
  onNavigateToMap: () => void;
  onOpenApkModal?: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  language,
  onOpenBooking,
  onSelectBranch,
  onViewTicket,
  onNavigateToBranches,
  onNavigateToMap,
  onOpenApkModal,
}) => {
  const t = getTranslation(language);
  const profile = StorageService.getProfile();
  const allTickets = StorageService.getTickets();
  const activeTicket = allTickets.find(
    (t) => t.status === 'active' || t.status === 'waiting' || t.status === 'in_service'
  );

  // Time-based greeting
  const hour = new Date().getHours();
  const greeting =
    hour < 11
      ? t.greetingMorning
      : hour < 18
      ? t.greetingDay
      : t.greetingEvening;

  // Occupancy metrics
  const lowCount = MOCK_BRANCHES.filter((b) => b.occupancyLevel === 'low').length;
  const medCount = MOCK_BRANCHES.filter((b) => b.occupancyLevel === 'medium').length;
  const highCount = MOCK_BRANCHES.filter((b) => b.occupancyLevel === 'high').length;

  const nearestBranches = MOCK_BRANCHES.slice(0, 3);

  const getServiceIcon = (category: string) => {
    switch (category) {
      case 'cards':
        return CreditCard;
      case 'currency':
        return ArrowLeftRight;
      case 'credits':
        return BadgePercent;
      case 'deposits':
        return PiggyBank;
      case 'transfers':
        return Send;
      default:
        return Briefcase;
    }
  };

  return (
    <div className="p-4 sm:p-6 space-y-6">
      {/* User Greeting & Date Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
            <Calendar className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
            <span>9-noyabr, Dushanba</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-0.5">
            {greeting}, {profile.name.split(' ')[0]}!
          </h2>
        </div>

        <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 to-teal-400 text-white font-bold flex items-center justify-center text-sm shadow-sm">
          {profile.name
            .split(' ')
            .map((n) => n[0])
            .join('')
            .slice(0, 2)}
        </div>
      </div>

      {/* Quick Search Bar */}
      <div
        onClick={() => onNavigateToBranches()}
        className="relative flex items-center p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs cursor-pointer hover:border-blue-400 dark:hover:border-blue-500 transition-all"
      >
        <Search className="w-4 h-4 text-slate-400 ml-1.5 mr-2.5 shrink-0" />
        <span className="text-xs text-slate-400 select-none">
          {t.searchPlaceholder}
        </span>
      </div>

      {/* Active Ticket Banner (if exists) with Live Radar Beacon */}
      {activeTicket && (
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          whileHover={{ scale: 1.01 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => onViewTicket(activeTicket)}
          className="relative overflow-hidden p-4 rounded-2xl bg-gradient-to-r from-blue-950 via-[#102B5C] to-slate-900 text-white shadow-lg cursor-pointer transition-shadow group border border-teal-500/20"
        >
          {/* Subtle moving shine sweep */}
          <motion.div
            animate={{ x: [-150, 450] }}
            transition={{ duration: 5, repeat: Infinity, repeatDelay: 2 }}
            className="absolute inset-0 w-12 h-full bg-white/10 skew-x-12 blur-xs pointer-events-none"
          />

          <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-teal-400" />
              </span>
              <span className="text-xs font-semibold uppercase tracking-wider text-teal-300">
                {t.activeTicketBanner}
              </span>
            </div>
            <span className="text-xs text-white/80 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
              <span>{t.viewMyTicket}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </span>
          </div>

          <div className="flex items-baseline justify-between mt-3 relative z-10">
            <div>
              <span className="text-3xl font-extrabold font-mono tracking-tight text-white tabular-nums drop-shadow-xs">
                {activeTicket.ticketNumber}
              </span>
              <p className="text-xs text-blue-200 font-medium mt-0.5">
                {activeTicket.branchName}
              </p>
            </div>
            <div className="text-right">
              <span className="text-xs text-white/70 block">{t.peopleAhead}:</span>
              <span className="text-base font-bold text-teal-300 tabular-nums">
                {activeTicket.peopleAhead} {t.people}
              </span>
            </div>
          </div>
        </motion.div>
      )}

      {/* Primary Hero CTA Card */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="relative overflow-hidden rounded-3xl p-5 bg-gradient-to-br from-[#102B5C] via-[#1A3F80] to-[#2878F0] text-white shadow-xl"
      >
        <div className="relative z-10 max-w-sm space-y-3">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/15 backdrop-blur-md text-[11px] font-semibold text-teal-300 border border-white/10">
            <Sparkles className="w-3 h-3 text-teal-300" />
            <span>Tezkor navbat olish</span>
          </span>

          <h3 className="text-xl sm:text-2xl font-bold tracking-tight text-white leading-tight">
            {t.quickBookCTA}
          </h3>

          <p className="text-xs text-white/80 leading-relaxed">
            {t.quickBookDesc}
          </p>

          <motion.button
            type="button"
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onOpenBooking()}
            className="mt-2 py-3 px-5 rounded-xl bg-teal-400 hover:bg-teal-300 text-slate-900 font-bold text-xs shadow-md shadow-teal-500/20 flex items-center gap-2 cursor-pointer transition-colors"
          >
            <span>Navbat band qilish</span>
            <ChevronRight className="w-4 h-4" />
          </motion.button>
        </div>

        {/* Ambient background graphical rings with gentle breathing */}
        <motion.div
          animate={{ scale: [1, 1.15, 1], opacity: [0.1, 0.2, 0.1] }}
          transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute -right-8 -bottom-10 w-48 h-48 rounded-full bg-white/15 blur-xl pointer-events-none"
        />
        <div className="absolute right-4 top-4 opacity-15 pointer-events-none">
          <Ticket className="w-32 h-32 stroke-1" />
        </div>
      </motion.div>

      {/* Android APK & Install Quick Card */}
      {onOpenApkModal && (
        <motion.div
          whileHover={{ y: -2 }}
          whileTap={{ scale: 0.98 }}
          onClick={onOpenApkModal}
          className="p-4 rounded-2xl bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-blue-500/10 border border-emerald-500/30 dark:border-emerald-500/20 shadow-xs cursor-pointer hover:border-emerald-500 transition-all flex items-center justify-between select-none"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center shrink-0 shadow-xs">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white leading-tight">
                  Android .APK & Smartfonga o‘rnatish
                </span>
                <span className="px-1.5 py-0.2 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold">
                  APK
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                WebAPK 1-klikda o‘rnatish yoki Expo .ZIP arxivini yuklab olish
              </p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
        </motion.div>
      )}

      {/* Top Uzbekistan Banks Carousel */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
            Yetakchi banklar
          </h4>
          <button
            type="button"
            onClick={() => onNavigateToBranches()}
            className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span>Barchasi ({MOCK_BANKS.length})</span>
            <ChevronRight className="w-3 h-3" />
          </button>
        </div>

        <div className="flex items-center gap-3 overflow-x-auto no-scrollbar py-1 -mx-4 px-4 sm:mx-0 sm:px-0">
          {MOCK_BANKS.map((bank) => (
            <motion.button
              key={bank.id}
              type="button"
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.94 }}
              onClick={() => onNavigateToBranches(bank.name)}
              className="flex flex-col items-center gap-1.5 shrink-0 w-17 text-center cursor-pointer group"
            >
              <div
                className="w-13 h-13 rounded-2xl flex items-center justify-center text-white font-bold text-sm shadow-sm ring-1 ring-black/5 group-hover:shadow-md transition-all"
                style={{ backgroundColor: bank.logoColor }}
              >
                {bank.code}
              </div>
              <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 truncate w-full group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                {bank.name}
              </span>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Occupancy Overview Metrics */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
            {t.occupancyOverview}
          </h4>
          <button
            type="button"
            onClick={onNavigateToMap}
            className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
          >
            <span>Xaritada ko‘rish</span>
            <ChevronRight className="w-3 h-3" />
          </button>
        </div>

        <div className="grid grid-cols-3 gap-2">
          <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200/50 dark:border-emerald-900/40 text-center">
            <span className="text-lg font-bold text-emerald-700 dark:text-emerald-300 tabular-nums block">
              {lowCount}
            </span>
            <span className="text-[11px] font-medium text-emerald-800 dark:text-emerald-400">
              {t.lowOccupancy}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200/50 dark:border-amber-900/40 text-center">
            <span className="text-lg font-bold text-amber-700 dark:text-amber-300 tabular-nums block">
              {medCount}
            </span>
            <span className="text-[11px] font-medium text-amber-800 dark:text-amber-400">
              {t.mediumOccupancy}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200/50 dark:border-rose-900/40 text-center">
            <span className="text-lg font-bold text-rose-700 dark:text-rose-300 tabular-nums block">
              {highCount}
            </span>
            <span className="text-[11px] font-medium text-rose-800 dark:text-rose-400">
              {t.highOccupancy}
            </span>
          </div>
        </div>
      </div>

      {/* Popular Services Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
            {t.popularServices}
          </h4>
          <span className="text-xs text-slate-400">{MOCK_SERVICES.length} xizmat</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          {MOCK_SERVICES.slice(0, 6).map((srv) => {
            const IconComponent = getServiceIcon(srv.category);

            return (
              <button
                key={srv.id}
                type="button"
                onClick={() => onOpenBooking({ service: srv })}
                className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-blue-400 dark:hover:border-blue-500 shadow-xs text-left flex flex-col justify-between transition-all group"
              >
                <div className="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                  <IconComponent className="w-4 h-4" />
                </div>
                <div className="mt-3">
                  <h5 className="font-semibold text-xs text-slate-900 dark:text-white leading-tight line-clamp-2">
                    {srv.name[language] || srv.name.uz}
                  </h5>
                  <span className="text-[10px] text-slate-400 mt-1 block">
                    ~{srv.averageDurationMinutes} {t.minutesShort}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Nearest Bank Branches Section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
            {t.nearestBranches}
          </h4>
          <button
            type="button"
            onClick={() => onNavigateToBranches()}
            className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
          >
            <span>{t.seeAll}</span>
            <ChevronRight className="w-3 h-3" />
          </button>
        </div>

        <div className="space-y-3">
          {nearestBranches.map((branch, idx) => (
            <BranchCard
              key={branch.id}
              branch={branch}
              language={language}
              distanceKm={0.8 + idx * 0.9}
              onBookQueue={(b) => onOpenBooking({ branch: b })}
              onViewDetails={onSelectBranch}
              isFavorite={profile.favoriteBranchIds.includes(branch.id)}
            />
          ))}
        </div>
      </div>

      {/* Smart Advice Card */}
      <div className="p-4 rounded-2xl bg-blue-50/60 dark:bg-blue-950/30 border border-blue-200/50 dark:border-blue-900/40 flex items-start gap-3 text-xs">
        <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
          <Zap className="w-4 h-4" />
        </div>
        <div>
          <h5 className="font-bold text-blue-900 dark:text-blue-200">
            Aqlli tavsiya:
          </h5>
          <p className="text-blue-800/80 dark:text-blue-300/80 mt-0.5 leading-relaxed">
            Bank filiallarida eng kam navbat odatda soat <strong>10:00 dan 12:00 gacha</strong> bo‘ladi. Valyuta va karta xizmatlariga ertalab navbat olishni tavsiya qilamiz.
          </p>
        </div>
      </div>
    </div>
  );
};
