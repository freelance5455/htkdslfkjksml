import React, { useState } from 'react';
import { QueueTicket, Language } from '../types';
import { DigitalTicketCard } from '../components/DigitalTicketCard';
import { getTranslation } from '../i18n/translations';
import { StorageService } from '../services/storage';
import { Ticket, Clock, CheckCircle2, XCircle, Plus, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface MyQueuesScreenProps {
  language: Language;
  onOpenBooking: () => void;
  onRateTicket: (ticket: QueueTicket) => void;
  onSelectBranch?: (branchId: string) => void;
}

export const MyQueuesScreen: React.FC<MyQueuesScreenProps> = ({
  language,
  onOpenBooking,
  onRateTicket,
  onSelectBranch,
}) => {
  const t = getTranslation(language);
  const [activeTab, setActiveTab] = useState<'active' | 'upcoming' | 'history'>('active');
  const [, setRefreshKey] = useState(0);

  const tickets = StorageService.getTickets();

  const activeTickets = tickets.filter(
    (t) => t.status === 'active' || t.status === 'waiting' || t.status === 'in_service'
  );

  const upcomingTickets = tickets.filter(
    (t) => t.date.includes('Ertaga') && t.status !== 'cancelled' && t.status !== 'completed'
  );

  const historyTickets = tickets.filter(
    (t) => t.status === 'completed' || t.status === 'cancelled'
  );

  const handleTicketCancel = () => {
    setRefreshKey((k) => k + 1);
  };

  return (
    <div className="p-4 sm:p-6 space-y-5">
      {/* Header and Fast Book Button */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            {t.myQueuesTitle}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Barcha elektron talonlaringiz bir joyda
          </p>
        </div>

        <motion.button
          type="button"
          whileTap={{ scale: 0.94 }}
          onClick={onOpenBooking}
          className="py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Yangi navbat</span>
        </motion.button>
      </div>

      {/* Segmented Filter Tabs with layout spring */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl relative">
        <button
          type="button"
          onClick={() => setActiveTab('active')}
          className={`relative flex-1 py-2 text-xs font-semibold rounded-xl transition-colors flex items-center justify-center gap-1.5 z-10 ${
            activeTab === 'active'
              ? 'text-blue-600 dark:text-blue-400'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          {activeTab === 'active' && (
            <motion.div
              layoutId="queuesTabPill"
              className="absolute inset-0 bg-white dark:bg-slate-900 rounded-xl shadow-xs -z-10"
              transition={{ type: 'spring', stiffness: 450, damping: 32 }}
            />
          )}
          <span>{t.tabActive}</span>
          {activeTickets.length > 0 && (
            <span className="w-4 h-4 rounded-full bg-blue-600 text-white text-[10px] font-mono flex items-center justify-center">
              {activeTickets.length}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('upcoming')}
          className={`relative flex-1 py-2 text-xs font-semibold rounded-xl transition-colors flex items-center justify-center gap-1.5 z-10 ${
            activeTab === 'upcoming'
              ? 'text-blue-600 dark:text-blue-400'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          {activeTab === 'upcoming' && (
            <motion.div
              layoutId="queuesTabPill"
              className="absolute inset-0 bg-white dark:bg-slate-900 rounded-xl shadow-xs -z-10"
              transition={{ type: 'spring', stiffness: 450, damping: 32 }}
            />
          )}
          <span>{t.tabUpcoming}</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('history')}
          className={`relative flex-1 py-2 text-xs font-semibold rounded-xl transition-colors flex items-center justify-center gap-1.5 z-10 ${
            activeTab === 'history'
              ? 'text-blue-600 dark:text-blue-400'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          {activeTab === 'history' && (
            <motion.div
              layoutId="queuesTabPill"
              className="absolute inset-0 bg-white dark:bg-slate-900 rounded-xl shadow-xs -z-10"
              transition={{ type: 'spring', stiffness: 450, damping: 32 }}
            />
          )}
          <span>{t.tabHistory}</span>
          <span className="text-[10px] opacity-60">({historyTickets.length})</span>
        </button>
      </div>

      {/* Ticket List Containers with AnimatePresence */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
        >
          {activeTab === 'active' && (
            <div className="space-y-4">
              {activeTickets.length === 0 ? (
                <div className="py-16 text-center space-y-3 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6">
                  <div className="w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto">
                    <Ticket className="w-6 h-6" />
                  </div>
                  <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                    {t.noActiveQueues}
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs mx-auto">
                    {t.noActiveQueuesDesc}
                  </p>
                  <motion.button
                    type="button"
                    whileTap={{ scale: 0.95 }}
                    onClick={onOpenBooking}
                    className="mt-2 px-4 py-2 text-xs font-semibold rounded-xl bg-blue-600 text-white hover:bg-blue-700 transition-colors cursor-pointer"
                  >
                    {t.bookQueue}
                  </motion.button>
                </div>
              ) : (
                activeTickets.map((ticket) => (
                  <motion.div
                    key={ticket.id}
                    layout
                    initial={{ opacity: 0, scale: 0.96 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.96 }}
                    transition={{ type: 'spring', stiffness: 350, damping: 25 }}
                  >
                    <DigitalTicketCard
                      ticket={ticket}
                      language={language}
                      onCancelRequest={handleTicketCancel}
                      onRateRequest={onRateTicket}
                      onSelectBranch={onSelectBranch}
                      isDetailed={true}
                    />
                  </motion.div>
                ))
              )}
            </div>
          )}

          {activeTab === 'upcoming' && (
            <div className="space-y-4">
              {upcomingTickets.length === 0 ? (
                <div className="py-16 text-center space-y-3 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6">
                  <Clock className="w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto" />
                  <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                    {t.noUpcomingQueues}
                  </h4>
                  <p className="text-xs text-slate-500 max-w-xs mx-auto">
                    Ertangi kunga navbat rejalashtirib, vaqtingizni tejang.
                  </p>
                  <motion.button
                    type="button"
                    whileTap={{ scale: 0.95 }}
                    onClick={onOpenBooking}
                    className="mt-2 px-4 py-2 text-xs font-semibold rounded-xl bg-blue-600 text-white hover:bg-blue-700 transition-colors cursor-pointer"
                  >
                    {t.bookQueue}
                  </motion.button>
                </div>
              ) : (
                upcomingTickets.map((ticket) => (
                  <motion.div
                    key={ticket.id}
                    layout
                    initial={{ opacity: 0, scale: 0.96 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.96 }}
                    transition={{ type: 'spring', stiffness: 350, damping: 25 }}
                  >
                    <DigitalTicketCard
                      key={ticket.id}
                      ticket={ticket}
                      language={language}
                      onCancelRequest={handleTicketCancel}
                      onRateRequest={onRateTicket}
                    />
                  </motion.div>
                ))
              )}
            </div>
          )}

          {activeTab === 'history' && (
            <div className="space-y-4">
              {historyTickets.length === 0 ? (
                <div className="py-16 text-center space-y-3 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6">
                  <CheckCircle2 className="w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto" />
                  <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                    {t.noHistoryQueues}
                  </h4>
                </div>
              ) : (
                historyTickets.map((ticket) => (
                  <motion.div
                    key={ticket.id}
                    layout
                    initial={{ opacity: 0, scale: 0.96 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.96 }}
                    transition={{ type: 'spring', stiffness: 350, damping: 25 }}
                  >
                    <DigitalTicketCard
                      key={ticket.id}
                      ticket={ticket}
                      language={language}
                      onRateRequest={onRateTicket}
                      isDetailed={true}
                    />
                  </motion.div>
                ))
              )}
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};
