import React, { useState } from 'react';
import { Language } from '../types';
import { getTranslation } from '../i18n/translations';
import { StorageService } from '../services/storage';
import { Clock, Ticket, MapPin, ChevronRight, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface OnboardingScreenProps {
  language: Language;
  onFinish: () => void;
}

export const OnboardingScreen: React.FC<OnboardingScreenProps> = ({
  language,
  onFinish,
}) => {
  const t = getTranslation(language);
  const [currentSlide, setCurrentSlide] = useState<number>(0);
  const [direction, setDirection] = useState<number>(1);

  const slides = [
    {
      title: t.onboarding1Title,
      desc: t.onboarding1Desc,
      icon: Clock,
      color: 'from-blue-600 to-indigo-600',
      badge: 'Tejamkorlik',
      illustrationTag: 'Vaqtingizni tejash',
    },
    {
      title: t.onboarding2Title,
      desc: t.onboarding2Desc,
      icon: Ticket,
      color: 'from-blue-600 to-teal-500',
      badge: 'Oldindan bron',
      illustrationTag: 'Raqamli e-Talon',
    },
    {
      title: t.onboarding3Title,
      desc: t.onboarding3Desc,
      icon: MapPin,
      color: 'from-teal-600 to-emerald-500',
      badge: 'Interaktiv xarita',
      illustrationTag: 'Bo‘sh filiallar',
    },
  ];

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      setDirection(1);
      setCurrentSlide(currentSlide + 1);
    } else {
      completeOnboarding();
    }
  };

  const handleSelectSlide = (idx: number) => {
    setDirection(idx > currentSlide ? 1 : -1);
    setCurrentSlide(idx);
  };

  const completeOnboarding = () => {
    StorageService.saveProfile({ hasCompletedOnboarding: true });
    onFinish();
  };

  const slide = slides[currentSlide];
  const IconComponent = slide.icon;

  const slideVariants = {
    enter: (dir: number) => ({
      x: dir > 0 ? 50 : -50,
      opacity: 0,
      scale: 0.95,
    }),
    center: {
      x: 0,
      opacity: 1,
      scale: 1,
      transition: {
        x: { type: 'spring' as const, stiffness: 350, damping: 30 },
        opacity: { duration: 0.3 },
      },
    },
    exit: (dir: number) => ({
      x: dir > 0 ? -50 : 50,
      opacity: 0,
      scale: 0.95,
      transition: {
        x: { type: 'spring' as const, stiffness: 350, damping: 30 },
        opacity: { duration: 0.2 },
      },
    }),
  };

  return (
    <div className="min-h-[680px] h-full flex flex-col justify-between p-6 sm:p-8 bg-white dark:bg-slate-900 select-none overflow-hidden">
      {/* Top Header */}
      <div className="flex items-center justify-between z-10">
        <motion.span
          key={`badge-${currentSlide}`}
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-xs font-semibold px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
        >
          {slide.badge}
        </motion.span>
        <button
          type="button"
          onClick={completeOnboarding}
          className="text-xs font-medium text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white transition-colors cursor-pointer"
        >
          {t.skip}
        </button>
      </div>

      {/* Slide Illustration Center with AnimatePresence */}
      <div className="my-auto py-6 relative overflow-hidden">
        <AnimatePresence mode="wait" custom={direction}>
          <motion.div
            key={currentSlide}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            className="text-center space-y-6 flex flex-col items-center"
          >
            {/* Floating 3D-styled Icon Card */}
            <motion.div
              animate={{ y: [-4, 6, -4] }}
              transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
              className={`w-36 h-36 rounded-3xl bg-gradient-to-tr ${slide.color} p-1 shadow-2xl shadow-blue-500/25 flex items-center justify-center`}
            >
              <div className="w-full h-full rounded-[22px] bg-white/10 backdrop-blur-md flex flex-col items-center justify-center text-white">
                <IconComponent className="w-16 h-16 stroke-[1.5] drop-shadow-md" />
                <span className="text-[10px] font-bold uppercase tracking-wider mt-1.5 opacity-90">
                  {slide.illustrationTag}
                </span>
              </div>
            </motion.div>

            <div className="space-y-3 max-w-xs mx-auto">
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white leading-tight">
                {slide.title}
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                {slide.desc}
              </p>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Bottom Controls (Animated Dots & CTA Button) */}
      <div className="space-y-5 z-10">
        {/* Dynamic Animated Dots */}
        <div className="flex items-center justify-center gap-2">
          {slides.map((_, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleSelectSlide(idx)}
              className="relative p-1 cursor-pointer focus:outline-hidden"
              aria-label={`Slide ${idx + 1}`}
            >
              {idx === currentSlide ? (
                <motion.div
                  layoutId="onboardingDot"
                  className="w-7 h-2 rounded-full bg-blue-600 dark:bg-blue-400 shadow-xs"
                  transition={{ type: 'spring', stiffness: 500, damping: 35 }}
                />
              ) : (
                <div className="w-2 h-2 rounded-full bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 transition-colors" />
              )}
            </button>
          ))}
        </div>

        {/* Next / Start Button with Tactile Feedback */}
        <motion.button
          type="button"
          onClick={handleNext}
          whileHover={{ scale: 1.01 }}
          whileTap={{ scale: 0.97 }}
          className="w-full py-3.5 px-6 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2 cursor-pointer transition-shadow"
        >
          <span>
            {currentSlide === slides.length - 1 ? t.getStarted : t.next}
          </span>
          {currentSlide === slides.length - 1 ? (
            <Check className="w-4 h-4 stroke-[2.5]" />
          ) : (
            <ChevronRight className="w-4 h-4" />
          )}
        </motion.button>
      </div>
    </div>
  );
};

