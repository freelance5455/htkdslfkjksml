import React, { useState } from 'react';
import { Language, UserProfile } from '../types';
import { getTranslation } from '../i18n/translations';
import { StorageService } from '../services/storage';
import {
  User,
  Phone,
  Globe,
  Moon,
  Sun,
  Bell,
  Volume2,
  Bookmark,
  HelpCircle,
  Headphones,
  RotateCcw,
  Sparkles,
  Smartphone,
  ChevronRight,
  ShieldCheck,
  ExternalLink,
  Share2,
} from 'lucide-react';
import { motion } from 'motion/react';

interface ProfileScreenProps {
  language: Language;
  onChangeLanguage: (lang: Language) => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
  onReplayOnboarding: () => void;
  onOpenExpoGuide: () => void;
  onOpenNotifications: () => void;
  onNavigateToBranches: () => void;
  onOpenApkModal?: () => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  language,
  onChangeLanguage,
  isDarkMode,
  onToggleTheme,
  onReplayOnboarding,
  onOpenExpoGuide,
  onOpenNotifications,
  onNavigateToBranches,
  onOpenApkModal,
}) => {
  const t = getTranslation(language);
  const [profile, setProfile] = useState<UserProfile>(StorageService.getProfile());
  const [editName, setEditName] = useState(false);
  const [nameInput, setNameInput] = useState(profile.name);
  const [shareCopied, setShareCopied] = useState(false);

  const handleShareApp = async () => {
    const shareData = {
      title: 'BankNavbat.uz — Smart Banking Queue',
      text: 'O‘zbekiston banklarida navbatda vaqt yo‘qotmang! Elektron talonni oldindan band qiling.',
      url: window.location.origin,
    };
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share(shareData);
        return;
      } catch {
        // Fallback
      }
    }
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      try {
        await navigator.clipboard.writeText(`${shareData.title}\n${shareData.text}\n${shareData.url}`);
        setShareCopied(true);
        setTimeout(() => setShareCopied(false), 2500);
      } catch {
        // Ignore clipboard failure
      }
    }
  };

  const handleSaveName = () => {
    if (nameInput.trim()) {
      const updated = StorageService.saveProfile({ name: nameInput.trim() });
      setProfile(updated);
      setEditName(false);
    }
  };

  const handleToggleNotifications = () => {
    const updated = StorageService.saveProfile({
      notificationsEnabled: !profile.notificationsEnabled,
    });
    setProfile(updated);
  };

  const handleResetData = () => {
    if (confirm('Barcha test ma‘lumotlari dastlabki holatga qaytarilsinmi?')) {
      StorageService.resetAll();
      window.location.reload();
    }
  };

  return (
    <div className="p-4 sm:p-6 space-y-6">
      {/* User Header Profile Card */}
      <div className="p-5 rounded-3xl bg-gradient-to-br from-[#102B5C] to-[#1E4E9E] text-white shadow-xl space-y-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-teal-400 to-blue-500 text-white font-extrabold text-xl flex items-center justify-center shadow-md">
            {profile.name
              .split(' ')
              .map((n) => n[0])
              .join('')
              .slice(0, 2)}
          </div>

          <div className="flex-1">
            {editName ? (
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  className="px-2.5 py-1 text-xs rounded-lg bg-white/20 text-white placeholder-white/60 border border-white/30 focus:outline-hidden"
                />
                <button
                  type="button"
                  onClick={handleSaveName}
                  className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-teal-400 text-slate-900"
                >
                  Saqlash
                </button>
              </div>
            ) : (
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-lg text-white leading-tight">
                    {profile.name}
                  </h3>
                  <p className="text-xs text-blue-200 mt-0.5">{profile.phone}</p>
                </div>
                <button
                  type="button"
                  onClick={() => setEditName(true)}
                  className="text-xs text-teal-300 hover:underline"
                >
                  Tahrirlash
                </button>
              </div>
            )}
            <span className="inline-block mt-2 px-2.5 py-0.5 rounded-full bg-white/10 text-[10px] font-medium text-teal-200">
              O‘zbekiston fuqarosi · {t.userRole}
            </span>
          </div>
        </div>

        {/* User stats summary */}
        <div className="grid grid-cols-2 gap-2 pt-3 border-t border-white/10 text-xs text-center">
          <div className="p-2 rounded-xl bg-white/5">
            <span className="text-white/70 block">Sevimli filiallar</span>
            <span className="text-base font-bold text-white tabular-nums">
              {profile.favoriteBranchIds.length} ta
            </span>
          </div>
          <div className="p-2 rounded-xl bg-white/5">
            <span className="text-white/70 block">Jami navbatlar</span>
            <span className="text-base font-bold text-teal-300 tabular-nums">
              {StorageService.getTickets().length} ta
            </span>
          </div>
        </div>
      </div>

      {/* Android APK & Install Banner */}
      {onOpenApkModal && (
        <div
          onClick={onOpenApkModal}
          className="p-4 rounded-2xl bg-gradient-to-r from-emerald-500/15 via-teal-500/10 to-emerald-500/15 border border-emerald-500/30 dark:border-emerald-500/20 shadow-xs cursor-pointer hover:border-emerald-500 transition-all flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center shrink-0 shadow-xs">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white leading-tight">
                  Android APK & Ilovani o‘rnatish markazi
                </h4>
                <span className="px-1.5 py-0.2 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold">
                  APK
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                WebAPK o‘rnatish, Expo ZIP yuklash va EAS Build buyrug‘i
              </p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
        </div>
      )}

      {/* Expo & React Native Architecture Button Banner */}
      <div
        onClick={onOpenExpoGuide}
        className="p-4 rounded-2xl bg-gradient-to-r from-blue-500/10 via-teal-500/10 to-indigo-500/10 border border-blue-500/30 dark:border-blue-500/20 shadow-xs cursor-pointer hover:border-blue-500 transition-all flex items-center justify-between"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white leading-tight">
              {t.expoArchitecture}
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Android APK yig‘ish, Expo Router va loyiha kodlari
            </p>
          </div>
        </div>
        <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
      </div>

      {/* Language Section */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
          <Globe className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          <span>{t.languageSection}</span>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {[
            { id: 'uz', name: 'O‘zbekcha', sub: 'Lotin' },
            { id: 'ru', name: 'Русский', sub: 'Язык' },
            { id: 'en', name: 'English', sub: 'Global' },
          ].map((l) => (
            <button
              key={l.id}
              type="button"
              onClick={() => onChangeLanguage(l.id as Language)}
              className={`p-3 rounded-xl border text-center transition-all ${
                language === l.id
                  ? 'border-blue-600 bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 font-bold shadow-xs'
                  : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
              }`}
            >
              <span className="text-xs block">{l.name}</span>
              <span className="text-[10px] text-slate-400 block mt-0.5">{l.sub}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Theme & Settings Section */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
        <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
          {t.themeSection} & Sozlamalar
        </h4>

        {/* Dark/Light mode row */}
        <div className="flex items-center justify-between py-1 text-xs">
          <div className="flex items-center gap-2.5">
            {isDarkMode ? (
              <Moon className="w-4 h-4 text-blue-400" />
            ) : (
              <Sun className="w-4 h-4 text-amber-500" />
            )}
            <span className="font-medium text-slate-900 dark:text-white">
              {isDarkMode ? t.themeDark : t.themeLight}
            </span>
          </div>
          <button
            type="button"
            onClick={onToggleTheme}
            className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-semibold hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
          >
            {isDarkMode ? 'Yorug‘ mavzuga o‘tish' : 'Tungi mavzuga o‘tish'}
          </button>
        </div>

        {/* Push Notification Toggle */}
        <div className="flex items-center justify-between py-1 text-xs border-t border-slate-100 dark:border-slate-800 pt-3">
          <div className="flex items-center gap-2.5">
            <Bell className="w-4 h-4 text-slate-400" />
            <span className="font-medium text-slate-900 dark:text-white">
              {t.pushNotifications}
            </span>
          </div>
          <button
            type="button"
            onClick={handleToggleNotifications}
            className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
              profile.notificationsEnabled ? 'bg-blue-600' : 'bg-slate-300 dark:bg-slate-700'
            }`}
          >
            <span
              className={`block w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                profile.notificationsEnabled ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Actions and Support List */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
        <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
          {t.helpSupport}
        </h4>

        <div className="space-y-2 text-xs">
          <a
            href="tel:1188"
            className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100 transition-colors"
          >
            <div className="flex items-center gap-2.5">
              <Headphones className="w-4 h-4 text-blue-600" />
              <span className="font-semibold text-slate-900 dark:text-white">
                {t.hotline} (1188 / +998 71 200 00 00)
              </span>
            </div>
            <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
          </a>

          <button
            type="button"
            onClick={onReplayOnboarding}
            className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100 text-left transition-colors"
          >
            <div className="flex items-center gap-2.5">
              <HelpCircle className="w-4 h-4 text-teal-600" />
              <span className="font-medium text-slate-900 dark:text-white">
                {t.replayOnboarding}
              </span>
            </div>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          </button>

          <motion.button
            type="button"
            whileTap={{ scale: 0.98 }}
            onClick={handleShareApp}
            className="w-full flex items-center justify-between p-3 rounded-xl bg-blue-50/70 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 hover:bg-blue-100/70 text-left transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-2.5">
              <Share2 className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span className="font-semibold">
                {shareCopied ? 'Havola nusxalandi!' : 'Do‘stlarga ulashish (Ilova havolasi)'}
              </span>
            </div>
            <ExternalLink className="w-3.5 h-3.5 text-blue-500" />
          </motion.button>

          <button
            type="button"
            onClick={handleResetData}
            className="w-full flex items-center justify-between p-3 rounded-xl bg-rose-50/60 dark:bg-rose-950/20 text-rose-700 dark:text-rose-400 hover:bg-rose-100/60 text-left transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-2.5">
              <RotateCcw className="w-4 h-4 text-rose-600" />
              <span className="font-medium">{t.resetDemoData}</span>
            </div>
          </button>
        </div>
      </div>

      {/* App Version Info */}
      <div className="text-center text-[11px] text-slate-400 pb-4 space-y-1">
        <p className="font-semibold text-slate-600 dark:text-slate-300">
          BankNavbat.uz Mobile Fintech MVP
        </p>
        <p>{t.version}</p>
        <p className="text-[10px] text-slate-400">
          Demo Day uchun tayyorlangan startap prototipi
        </p>
      </div>
    </div>
  );
};
