import React from 'react';
import { Language } from '../types';
import { getTranslation } from '../i18n/translations';
import { ShieldCheck, ChevronRight } from 'lucide-react';
import { motion } from 'motion/react';

interface SplashScreenProps {
  language: Language;
  onFinish: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ language, onFinish }) => {
  const t = getTranslation(language);

  return (
    <div className="relative min-h-[680px] h-full flex flex-col items-center justify-between p-8 bg-gradient-to-b from-[#071329] via-[#0E2550] to-[#071329] text-white overflow-hidden select-none">
      {/* Dynamic Animated background ambient orbs */}
      <motion.div
        animate={{
          scale: [1, 1.25, 1],
          opacity: [0.2, 0.35, 0.2],
        }}
        transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
        className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-88 h-88 rounded-full bg-blue-500/25 blur-3xl pointer-events-none"
      />
      <motion.div
        animate={{
          scale: [1, 1.3, 1],
          opacity: [0.15, 0.3, 0.15],
        }}
        transition={{ duration: 7, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
        className="absolute bottom-1/4 right-0 w-72 h-72 rounded-full bg-teal-500/20 blur-3xl pointer-events-none"
      />

      {/* Top Tagline */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
        className="text-center pt-8 z-10"
      >
        <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white/10 backdrop-blur-md text-[11px] font-medium text-blue-200 border border-white/15 shadow-sm">
          <ShieldCheck className="w-3.5 h-3.5 text-teal-400" />
          <span>O‘zbekiston Banklar Assotsiatsiyasi Standarti</span>
        </span>
      </motion.div>

      {/* Centerpiece Logo with Expanding Pulse Rings & Slogan */}
      <div className="text-center z-10 space-y-6 max-w-sm flex flex-col items-center">
        {/* Animated Badge Container with Concentric Radar Wave Rings */}
        <div className="relative flex items-center justify-center">
          {/* Outer Ripple Wave 1 */}
          <motion.div
            animate={{ scale: [1, 1.6], opacity: [0.6, 0] }}
            transition={{ duration: 2.5, repeat: Infinity, ease: 'easeOut' }}
            className="absolute w-28 h-28 rounded-full border border-teal-400/40 pointer-events-none"
          />
          {/* Outer Ripple Wave 2 */}
          <motion.div
            animate={{ scale: [1, 1.9], opacity: [0.4, 0] }}
            transition={{ duration: 2.5, repeat: Infinity, ease: 'easeOut', delay: 0.8 }}
            className="absolute w-28 h-28 rounded-full border border-blue-400/30 pointer-events-none"
          />

          {/* Logo Box with Spring Entrance and Subtle Float */}
          <motion.div
            initial={{ scale: 0, rotate: -15 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: 'spring', stiffness: 260, damping: 20 }}
            className="relative z-10"
          >
            <motion.div
              animate={{ y: [-4, 4, -4] }}
              transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
              className="relative w-26 h-26 rounded-3xl bg-gradient-to-tr from-blue-500 via-blue-600 to-teal-400 p-0.5 shadow-2xl shadow-blue-500/50 flex items-center justify-center"
            >
              <div className="w-full h-full rounded-[22px] bg-[#0E2550] flex flex-col items-center justify-center relative overflow-hidden">
                {/* Subtle shine glint across logo */}
                <motion.div
                  animate={{ x: [-80, 120] }}
                  transition={{ duration: 3.5, repeat: Infinity, repeatDelay: 2 }}
                  className="absolute inset-0 w-8 h-full bg-white/20 skew-x-12 blur-xs pointer-events-none"
                />
                <span className="text-3xl font-extrabold tracking-tight text-white font-mono drop-shadow-md">
                  BN
                </span>
                <span className="text-[10px] font-black tracking-widest text-teal-300 uppercase">
                  NAVBAT
                </span>
              </div>
            </motion.div>
          </motion.div>
        </div>

        {/* Text Presentation with Staggered Reveal */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="space-y-2"
        >
          <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white drop-shadow-sm">
            BankNavbat<span className="text-teal-400">.uz</span>
          </h1>
          <p className="text-sm font-semibold text-blue-200 mt-1 leading-relaxed">
            {t.appSlogan}
          </p>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.5 }}
          className="text-xs text-slate-300/80 leading-relaxed max-w-xs mx-auto"
        >
          {t.tagline}
        </motion.p>
      </div>

      {/* Bottom Launch Button with Pulsing Glow */}
      <motion.div
        initial={{ opacity: 0, y: 25 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.6 }}
        className="w-full max-w-xs pb-6 z-10 space-y-3"
      >
        <motion.button
          type="button"
          onClick={onFinish}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.96 }}
          className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-blue-600 via-blue-500 to-teal-500 text-white font-bold text-sm shadow-xl shadow-teal-500/25 flex items-center justify-center gap-2 cursor-pointer transition-shadow"
        >
          <span>Ilovani boshlash</span>
          <ChevronRight className="w-4 h-4" />
        </motion.button>

        <p className="text-[10px] text-center text-slate-400/90 font-medium">
          12+ yetakchi O‘zbekiston banklari bilan integratsiya
        </p>
      </motion.div>
    </div>
  );
};

