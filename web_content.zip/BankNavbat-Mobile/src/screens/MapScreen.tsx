import React from 'react';
import { BankBranch, Language } from '../types';
import { MOCK_BRANCHES } from '../data/mockData';
import { InteractiveMap } from '../components/InteractiveMap';
import { getTranslation } from '../i18n/translations';
import { MapPin, Navigation, Info } from 'lucide-react';

interface MapScreenProps {
  language: Language;
  onSelectBranch: (branch: BankBranch) => void;
  onBookQueue: (branch: BankBranch) => void;
}

export const MapScreen: React.FC<MapScreenProps> = ({
  language,
  onSelectBranch,
  onBookQueue,
}) => {
  const t = getTranslation(language);

  return (
    <div className="p-4 sm:p-6 space-y-4">
      {/* Map Header */}
      <div>
        <h2 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
          {t.mapTitle}
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          {t.mapSubtitle}
        </p>
      </div>

      {/* Interactive Map Component */}
      <InteractiveMap
        branches={MOCK_BRANCHES}
        language={language}
        onSelectBranch={onSelectBranch}
        onBookQueue={onBookQueue}
      />

      {/* Map Legend & Info Notice */}
      <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-400">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-emerald-200 dark:ring-emerald-900" />
            <span>{t.lowOccupancy}</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-400">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 ring-2 ring-amber-200 dark:ring-amber-900" />
            <span>{t.mediumOccupancy}</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-400">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 ring-2 ring-rose-200 dark:ring-rose-900" />
            <span>{t.highOccupancy}</span>
          </div>
        </div>

        <div className="text-[11px] text-slate-400">
          GPS: Toshkent markazi (Amir Temur xiyoboni)
        </div>
      </div>
    </div>
  );
};
