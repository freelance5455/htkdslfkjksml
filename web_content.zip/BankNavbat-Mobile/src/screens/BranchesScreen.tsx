import React, { useState, useMemo } from 'react';
import { BankBranch, Language } from '../types';
import { MOCK_BANKS, MOCK_BRANCHES } from '../data/mockData';
import { BranchCard } from '../components/BranchCard';
import { getTranslation } from '../i18n/translations';
import { filterBranches } from '../utils/queueLogic';
import { StorageService } from '../services/storage';
import {
  Search,
  Filter,
  X,
  Building2,
  Star,
  RotateCcw,
  SlidersHorizontal,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface BranchesScreenProps {
  language: Language;
  initialQuery?: string;
  onOpenBooking: (branch: BankBranch) => void;
  onSelectBranch: (branch: BankBranch) => void;
}

export const BranchesScreen: React.FC<BranchesScreenProps> = ({
  language,
  initialQuery = '',
  onOpenBooking,
  onSelectBranch,
}) => {
  const t = getTranslation(language);
  const profile = StorageService.getProfile();

  const [query, setQuery] = useState<string>(initialQuery);
  const [selectedCity, setSelectedCity] = useState<string>('all');
  const [selectedBankId, setSelectedBankId] = useState<string>('all');
  const [selectedOccupancy, setSelectedOccupancy] = useState<string>('all');
  const [showFavoritesOnly, setShowFavoritesOnly] = useState<boolean>(false);

  const cities = ['Toshkent', 'Samarqand', 'Buxoro', 'Farg‘ona'];

  const filtered = useMemo(() => {
    let result = filterBranches(
      MOCK_BRANCHES,
      query,
      selectedCity,
      selectedBankId,
      selectedOccupancy
    );

    if (showFavoritesOnly) {
      result = result.filter((b) => profile.favoriteBranchIds.includes(b.id));
    }

    return result;
  }, [query, selectedCity, selectedBankId, selectedOccupancy, showFavoritesOnly, profile.favoriteBranchIds]);

  const handleResetFilters = () => {
    setQuery('');
    setSelectedCity('all');
    setSelectedBankId('all');
    setSelectedOccupancy('all');
    setShowFavoritesOnly(false);
  };

  const hasActiveFilters =
    query.trim() !== '' ||
    selectedCity !== 'all' ||
    selectedBankId !== 'all' ||
    selectedOccupancy !== 'all' ||
    showFavoritesOnly;

  return (
    <div className="p-4 sm:p-6 space-y-5">
      {/* Search Input Bar */}
      <div className="relative flex items-center">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t.searchPlaceholder}
          className="w-full pl-10 pr-10 py-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 text-slate-900 dark:text-white text-xs sm:text-sm placeholder:text-slate-400 shadow-xs focus:outline-hidden focus:ring-2 focus:ring-blue-500"
        />
        {query && (
          <button
            type="button"
            onClick={() => setQuery('')}
            className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* City Filter Chips */}
      <div className="space-y-1.5">
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
          <button
            type="button"
            onClick={() => setSelectedCity('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              selectedCity === 'all'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800'
            }`}
          >
            {t.allCities}
          </button>
          {cities.map((city) => (
            <button
              key={city}
              type="button"
              onClick={() => setSelectedCity(city)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCity === city
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800'
              }`}
            >
              {city}
            </button>
          ))}
        </div>
      </div>

      {/* Bank & Occupancy Secondary Filter Dropdowns */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
        {/* Bank Dropdown */}
        <select
          value={selectedBankId}
          onChange={(e) => setSelectedBankId(e.target.value)}
          className="px-3 py-1.5 text-xs font-medium rounded-xl bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800 focus:outline-hidden"
        >
          <option value="all">{t.allBanks}</option>
          {MOCK_BANKS.map((bank) => (
            <option key={bank.id} value={bank.id}>
              {bank.name}
            </option>
          ))}
        </select>

        {/* Occupancy Dropdown */}
        <select
          value={selectedOccupancy}
          onChange={(e) => setSelectedOccupancy(e.target.value)}
          className="px-3 py-1.5 text-xs font-medium rounded-xl bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800 focus:outline-hidden"
        >
          <option value="all">{t.allOccupancy}</option>
          <option value="low">{t.lowOccupancy}</option>
          <option value="medium">{t.mediumOccupancy}</option>
          <option value="high">{t.highOccupancy}</option>
        </select>

        {/* Favorites Filter Toggle */}
        <button
          type="button"
          onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
          className={`px-3 py-1.5 text-xs font-medium rounded-xl border flex items-center gap-1 whitespace-nowrap transition-all ${
            showFavoritesOnly
              ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-300 dark:border-amber-800 text-amber-700 dark:text-amber-300'
              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
          }`}
        >
          <Star className={`w-3.5 h-3.5 ${showFavoritesOnly ? 'fill-amber-400' : ''}`} />
          <span>{t.favoritesOnly}</span>
        </button>

        {hasActiveFilters && (
          <button
            type="button"
            onClick={handleResetFilters}
            className="p-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-800 dark:hover:text-white transition-colors"
            title={t.resetFilters}
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Result Count Status */}
      <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
        <span>Topildi: <strong>{filtered.length}</strong> ta filial</span>
        {selectedCity !== 'all' && <span>Shahar: {selectedCity}</span>}
      </div>

      {/* Branches List */}
      {filtered.length === 0 ? (
        <div className="py-16 text-center space-y-3 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6">
          <Building2 className="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto" />
          <h4 className="font-bold text-sm text-slate-900 dark:text-white">
            {t.noBranchesFound}
          </h4>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs mx-auto">
            {t.noBranchesFoundDesc}
          </p>
          <button
            type="button"
            onClick={handleResetFilters}
            className="mt-2 px-4 py-2 text-xs font-semibold rounded-xl bg-blue-600 text-white hover:bg-blue-700 transition-colors"
          >
            {t.resetFilters}
          </button>
        </div>
      ) : (
        <motion.div layout className="space-y-3">
          <AnimatePresence>
            {filtered.map((branch, idx) => (
              <motion.div
                key={branch.id}
                layout
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.96 }}
                transition={{ duration: 0.2, delay: Math.min(idx * 0.04, 0.25) }}
              >
                <BranchCard
                  branch={branch}
                  language={language}
                  distanceKm={1.1 + idx * 0.7}
                  onBookQueue={onOpenBooking}
                  onViewDetails={onSelectBranch}
                  isFavorite={profile.favoriteBranchIds.includes(branch.id)}
                />
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      )}
    </div>
  );
};
