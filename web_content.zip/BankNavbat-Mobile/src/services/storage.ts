import { QueueTicket, NotificationItem, UserProfile, BranchReview, Language } from '../types';
import { INITIAL_TICKETS, INITIAL_NOTIFICATIONS, MOCK_REVIEWS } from '../data/mockData';

const STORAGE_KEYS = {
  TICKETS: 'banknavbat_tickets_v1',
  NOTIFICATIONS: 'banknavbat_notifications_v1',
  PROFILE: 'banknavbat_profile_v1',
  REVIEWS: 'banknavbat_reviews_v1',
  THEME: 'banknavbat_theme_v1',
};

const DEFAULT_PROFILE: UserProfile = {
  name: 'Jamshidbek Alimov',
  phone: '+998 (90) 123-45-67',
  language: 'uz',
  notificationsEnabled: true,
  soundEnabled: true,
  favoriteBranchIds: ['br_agro_chilonzor', 'br_kapital_mirobod'],
  hasCompletedOnboarding: false,
};

// Safe JSON get/set
function getStored<T>(key: string, defaultValue: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return defaultValue;
    return JSON.parse(raw);
  } catch {
    return defaultValue;
  }
}

function setStored<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    window.dispatchEvent(new Event('banknavbat_storage_update'));
  } catch (e) {
    console.error('Storage error:', e);
  }
}

export const StorageService = {
  getTickets(): QueueTicket[] {
    return getStored<QueueTicket[]>(STORAGE_KEYS.TICKETS, INITIAL_TICKETS);
  },

  saveTicket(ticket: QueueTicket): void {
    const tickets = this.getTickets();
    const updated = [ticket, ...tickets];
    setStored(STORAGE_KEYS.TICKETS, updated);

    // Also automatically create a notification
    this.addNotification({
      id: `notif_${Date.now()}`,
      title: {
        uz: `Yangi navbat: ${ticket.ticketNumber}`,
        ru: `Новая запись: ${ticket.ticketNumber}`,
        en: `New booking: ${ticket.ticketNumber}`,
      },
      body: {
        uz: `${ticket.branchName} filialiga ${ticket.timeSlot} uchun elektron talon olindi.`,
        ru: `Оформлен электронный талон в филиал ${ticket.branchName} на ${ticket.timeSlot}.`,
        en: `Electronic ticket booked for ${ticket.branchName} at ${ticket.timeSlot}.`,
      },
      time: 'Hozirgina',
      type: 'ticket',
      isRead: false,
      ticketId: ticket.id,
    });
  },

  updateTicket(id: string, updates: Partial<QueueTicket>): QueueTicket | null {
    const tickets = this.getTickets();
    const idx = tickets.findIndex((t) => t.id === id);
    if (idx === -1) return null;

    tickets[idx] = { ...tickets[idx], ...updates };
    setStored(STORAGE_KEYS.TICKETS, [...tickets]);
    return tickets[idx];
  },

  cancelTicket(id: string): void {
    const ticket = this.getTickets().find((t) => t.id === id);
    this.updateTicket(id, { status: 'cancelled' });
    if (ticket) {
      this.addNotification({
        id: `notif_cancel_${Date.now()}`,
        title: {
          uz: `${ticket.ticketNumber} navbati bekor qilindi`,
          ru: `Запись ${ticket.ticketNumber} отменена`,
          en: `Ticket ${ticket.ticketNumber} was cancelled`,
        },
        body: {
          uz: `${ticket.branchName} filialidagi navbatingiz muvaffaqiyatli bekor qilindi.`,
          ru: `Ваша очередь в ${ticket.branchName} была успешно отменена.`,
          en: `Your booking at ${ticket.branchName} was cancelled successfully.`,
        },
        time: 'Hozirgina',
        type: 'alert',
        isRead: false,
      });
    }
  },

  getNotifications(): NotificationItem[] {
    return getStored<NotificationItem[]>(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
  },

  addNotification(notif: NotificationItem): void {
    const notifs = this.getNotifications();
    setStored(STORAGE_KEYS.NOTIFICATIONS, [notif, ...notifs]);
  },

  markNotificationsRead(): void {
    const notifs = this.getNotifications().map((n) => ({ ...n, isRead: true }));
    setStored(STORAGE_KEYS.NOTIFICATIONS, notifs);
  },

  getProfile(): UserProfile {
    return getStored<UserProfile>(STORAGE_KEYS.PROFILE, DEFAULT_PROFILE);
  },

  saveProfile(profile: Partial<UserProfile>): UserProfile {
    const current = this.getProfile();
    const updated = { ...current, ...profile };
    setStored(STORAGE_KEYS.PROFILE, updated);
    return updated;
  },

  toggleFavoriteBranch(branchId: string): boolean {
    const profile = this.getProfile();
    const favorites = new Set(profile.favoriteBranchIds || []);
    let isFav = false;
    if (favorites.has(branchId)) {
      favorites.delete(branchId);
      isFav = false;
    } else {
      favorites.add(branchId);
      isFav = true;
    }
    this.saveProfile({ favoriteBranchIds: Array.from(favorites) });
    return isFav;
  },

  getReviews(branchId?: string): BranchReview[] {
    const all = getStored<BranchReview[]>(STORAGE_KEYS.REVIEWS, MOCK_REVIEWS);
    if (!branchId) return all;
    return all.filter((r) => r.branchId === branchId);
  },

  addReview(review: BranchReview): void {
    const all = this.getReviews();
    setStored(STORAGE_KEYS.REVIEWS, [review, ...all]);
  },

  resetAll(): void {
    setStored(STORAGE_KEYS.TICKETS, INITIAL_TICKETS);
    setStored(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
    setStored(STORAGE_KEYS.PROFILE, DEFAULT_PROFILE);
    setStored(STORAGE_KEYS.REVIEWS, MOCK_REVIEWS);
  },
};
