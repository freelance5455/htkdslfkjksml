import { BankBranch, OccupancyLevel } from '../types';

/**
 * Calculates haversine distance between two points in kilometers.
 */
export function calculateDistanceKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c;
  return Math.round(d * 10) / 10;
}

/**
 * Generates formatted distance label (e.g., "1.2 km" or "450 m").
 */
export function formatDistance(km: number): string {
  if (km < 1) {
    return `${Math.round(km * 1000)} m`;
  }
  return `${km.toFixed(1)} km`;
}

/**
 * Determines occupancy level based on active queue length.
 */
export function getOccupancyLevel(queueCount: number): OccupancyLevel {
  if (queueCount <= 4) return 'low';
  if (queueCount <= 12) return 'medium';
  return 'high';
}

/**
 * Calculates estimated wait time in minutes based on people ahead and active counters.
 */
export function calculateEstimatedWait(
  peopleAhead: number,
  avgServiceMinutes = 7,
  activeWindows = 3
): number {
  if (peopleAhead <= 0) return 2;
  const rawWait = Math.ceil((peopleAhead * avgServiceMinutes) / activeWindows);
  return Math.max(3, rawWait);
}

/**
 * Generates an authentic ticket code like "A042", "K108", "V015".
 */
export function generateTicketCode(serviceCode = 'A', existingCount = 41): string {
  const nextNum = (existingCount % 999) + 1;
  const padded = nextNum.toString().padStart(3, '0');
  return `${serviceCode.toUpperCase()}${padded}`;
}

/**
 * Assigns an available bank service counter/window (Darcha).
 */
export function assignServiceWindow(serviceCategory: string): string {
  switch (serviceCategory) {
    case 'currency':
      return 'Darcha №1 (Kassa)';
    case 'cards':
      return 'Darcha №2 (Plastik kartalar)';
    case 'credits':
      return 'Darcha №4 (Kredit bo\'limi)';
    case 'deposits':
      return 'Darcha №5 (Omonatlar)';
    case 'transfers':
      return 'Darcha №3 (Pul o\'tkazmalari)';
    default:
      return 'Darcha №2 (Mijozlar zali)';
  }
}

/**
 * Validates Uzbek phone numbers: e.g. +998 90 123 45 67 or 901234567.
 */
export function validateUzbekPhone(phone: string): boolean {
  const digitsOnly = phone.replace(/\D/g, '');
  if (digitsOnly.length === 9) {
    // e.g. 901234567
    return true;
  }
  if (digitsOnly.length === 12 && digitsOnly.startsWith('998')) {
    return true;
  }
  return false;
}

/**
 * Formats phone input nicely as +998 (XX) XXX-XX-XX
 */
export function formatUzbekPhone(value: string): string {
  const digits = value.replace(/\D/g, '');
  let normalized = digits;
  if (digits.startsWith('998')) {
    normalized = digits.slice(3);
  }
  normalized = normalized.slice(0, 9);

  if (normalized.length === 0) return '+998 ';
  if (normalized.length <= 2) return `+998 (${normalized}`;
  if (normalized.length <= 5)
    return `+998 (${normalized.slice(0, 2)}) ${normalized.slice(2)}`;
  if (normalized.length <= 7)
    return `+998 (${normalized.slice(0, 2)}) ${normalized.slice(2, 5)}-${normalized.slice(5)}`;
  return `+998 (${normalized.slice(0, 2)}) ${normalized.slice(2, 5)}-${normalized.slice(5, 7)}-${normalized.slice(7, 9)}`;
}

/**
 * Filters branches by query, city, bankId, and occupancy.
 */
export function filterBranches(
  branches: BankBranch[],
  query: string,
  selectedCity: string,
  selectedBankId: string,
  selectedOccupancy: string
): BankBranch[] {
  const q = query.trim().toLowerCase();

  return branches.filter((branch) => {
    // City filter
    if (selectedCity && selectedCity !== 'all' && branch.city.toLowerCase() !== selectedCity.toLowerCase()) {
      return false;
    }

    // Bank filter
    if (selectedBankId && selectedBankId !== 'all' && branch.bankId !== selectedBankId) {
      return false;
    }

    // Occupancy filter
    if (selectedOccupancy && selectedOccupancy !== 'all' && branch.occupancyLevel !== selectedOccupancy) {
      return false;
    }

    // Search query
    if (q) {
      const matchName = branch.name.toLowerCase().includes(q);
      const matchAddress = branch.address.toLowerCase().includes(q);
      const matchDistrict = branch.district.toLowerCase().includes(q);
      const matchCity = branch.city.toLowerCase().includes(q);
      if (!matchName && !matchAddress && !matchDistrict && !matchCity) {
        return false;
      }
    }

    return true;
  });
}
