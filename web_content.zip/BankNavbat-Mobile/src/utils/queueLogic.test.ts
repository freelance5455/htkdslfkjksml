import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateDistanceKm,
  formatDistance,
  getOccupancyLevel,
  calculateEstimatedWait,
  generateTicketCode,
  validateUzbekPhone,
  filterBranches,
} from './queueLogic';
import { BankBranch } from '../types';

test('calculateDistanceKm calculates approximate distance between Tashkent locations', () => {
  // Tashkent Amir Temur Square (41.3111, 69.2797) to Chilonzor (41.2721, 69.2045) ~7-8km
  const dist = calculateDistanceKm(41.3111, 69.2797, 41.2721, 69.2045);
  assert.ok(dist > 6 && dist < 10, `Expected distance ~7.5km, got ${dist}`);
});

test('formatDistance formats meters and kilometers properly', () => {
  assert.equal(formatDistance(0.35), '350 m');
  assert.equal(formatDistance(2.4), '2.4 km');
});

test('getOccupancyLevel maps queue sizes to levels correctly', () => {
  assert.equal(getOccupancyLevel(2), 'low');
  assert.equal(getOccupancyLevel(4), 'low');
  assert.equal(getOccupancyLevel(5), 'medium');
  assert.equal(getOccupancyLevel(12), 'medium');
  assert.equal(getOccupancyLevel(13), 'high');
  assert.equal(getOccupancyLevel(25), 'high');
});

test('calculateEstimatedWait calculates realistic wait times in minutes', () => {
  assert.equal(calculateEstimatedWait(0), 2);
  // 6 people ahead, 7 min avg, 3 windows => ceil(42/3) = 14 mins
  assert.equal(calculateEstimatedWait(6, 7, 3), 14);
});

test('generateTicketCode produces prefixed ticket numbers', () => {
  assert.equal(generateTicketCode('A', 23), 'A024');
  assert.equal(generateTicketCode('K', 107), 'K108');
  assert.equal(generateTicketCode('V', 0), 'V001');
});

test('validateUzbekPhone recognizes valid and invalid Uzbek phone numbers', () => {
  assert.equal(validateUzbekPhone('+998 90 123 45 67'), true);
  assert.equal(validateUzbekPhone('901234567'), true);
  assert.equal(validateUzbekPhone('998901234567'), true);
  assert.equal(validateUzbekPhone('12345'), false);
  assert.equal(validateUzbekPhone(''), false);
});

test('filterBranches handles city, bank, and query filtering', () => {
  const sampleBranches: BankBranch[] = [
    {
      id: 'b1',
      bankId: 'agrobank',
      name: 'Agrobank Chilonzor',
      code: 'AGR-01',
      address: 'Chilonzor 9-mavze',
      city: 'Toshkent',
      district: 'Chilonzor',
      lat: 41.28,
      lng: 69.21,
      phone: '+998 71 202 00 00',
      workHours: '09:00 - 18:00',
      workDays: 'Dush - Juma',
      occupancyLevel: 'low',
      currentQueueCount: 3,
      averageWaitMinutes: 5,
      services: ['cards', 'credits'],
      rating: 4.8,
      reviewsCount: 32,
    },
    {
      id: 'b2',
      bankId: 'kapitalbank',
      name: 'Kapitalbank Samarqand',
      code: 'KAP-02',
      address: 'Mirzo Ulug\'bek ko\'chasi 14',
      city: 'Samarqand',
      district: 'Markaz',
      lat: 39.65,
      lng: 66.97,
      phone: '+998 78 148 40 08',
      workHours: '09:00 - 18:00',
      workDays: 'Dush - Shan',
      occupancyLevel: 'high',
      currentQueueCount: 16,
      averageWaitMinutes: 25,
      services: ['cards', 'currency'],
      rating: 4.6,
      reviewsCount: 45,
    },
  ];

  // Filter by city
  const toshkentOnly = filterBranches(sampleBranches, '', 'Toshkent', 'all', 'all');
  assert.equal(toshkentOnly.length, 1);
  assert.equal(toshkentOnly[0].id, 'b1');

  // Filter by bank
  const kapitalOnly = filterBranches(sampleBranches, '', 'all', 'kapitalbank', 'all');
  assert.equal(kapitalOnly.length, 1);
  assert.equal(kapitalOnly[0].id, 'b2');

  // Search by query
  const queryResult = filterBranches(sampleBranches, 'Chilonzor', 'all', 'all', 'all');
  assert.equal(queryResult.length, 1);
  assert.equal(queryResult[0].id, 'b1');
});
