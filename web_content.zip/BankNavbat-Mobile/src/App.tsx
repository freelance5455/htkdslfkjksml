import React, { useState, useEffect } from 'react';
import { Language, BankBranch, BankService, QueueTicket } from './types';
import { StorageService } from './services/storage';
import { MobileDeviceFrame } from './components/MobileDeviceFrame';
import { BottomTabBar, NavTab } from './components/BottomTabBar';
import { SplashScreen } from './screens/SplashScreen';
import { OnboardingScreen } from './screens/OnboardingScreen';
import { HomeScreen } from './screens/HomeScreen';
import { BranchesScreen } from './screens/BranchesScreen';
import { MapScreen } from './screens/MapScreen';
import { MyQueuesScreen } from './screens/MyQueuesScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { BookingWizardModal } from './components/BookingWizardModal';
import { BranchDetailModal } from './components/BranchDetailModal';
import { RatingModal } from './components/RatingModal';
import { NotificationsModal } from './components/NotificationsModal';
import { ExpoArchitectureModal } from './components/ExpoArchitectureModal';
import { AndroidApkModal } from './components/AndroidApkModal';
import { DigitalTicketCard } from './components/DigitalTicketCard';
import { MOCK_BRANCHES } from './data/mockData';
import { X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [profile, setProfile] = useState(StorageService.getProfile());
  const [language, setLanguage] = useState<Language>(profile.language || 'uz');
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return document.documentElement.classList.contains('dark');
  });

  // Screen flow: splash -> onboarding (if not completed) -> main
  const [screenFlow, setScreenFlow] = useState<'splash' | 'onboarding' | 'main'>(() => {
    // If autostart query param is set, skip straight to main
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('autostart') === '1') {
      return 'main';
    }
    return profile.hasCompletedOnboarding ? 'splash' : 'splash';
  });

  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [isDeviceMode, setIsDeviceMode] = useState<boolean>(true);

  // Modals
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [bookingPreselected, setBookingPreselected] = useState<{
    branch?: BankBranch;
    service?: BankService;
  }>({});
  const [selectedBranchDetail, setSelectedBranchDetail] = useState<BankBranch | null>(null);
  const [viewTicketModal, setViewTicketModal] = useState<QueueTicket | null>(null);
  const [ratingModalTicket, setRatingModalTicket] = useState<QueueTicket | null>(null);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isExpoGuideOpen, setIsExpoGuideOpen] = useState(false);
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);
  const [branchesSearchQuery, setBranchesSearchQuery] = useState<string>('');

  // Storage listener for reactive updates
  const [tickets, setTickets] = useState<QueueTicket[]>(StorageService.getTickets());
  const [notifications, setNotifications] = useState(StorageService.getNotifications());

  // Process deep links and query parameters on mount
  useEffect(() => {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const langParam = urlParams.get('lang');
      if (langParam === 'uz' || langParam === 'ru' || langParam === 'en') {
        setLanguage(langParam as Language);
        StorageService.saveProfile({ language: langParam as Language });
      }

      const tabParam = urlParams.get('tab');
      if (tabParam && ['home', 'branches', 'map', 'queues', 'profile'].includes(tabParam)) {
        setActiveTab(tabParam as NavTab);
        setScreenFlow('main');
      }

      const branchParam = urlParams.get('branch');
      if (branchParam) {
        const targetBranch = MOCK_BRANCHES.find(
          (b) =>
            b.id === branchParam ||
            b.name.toLowerCase().includes(branchParam.toLowerCase())
        );
        if (targetBranch) {
          setSelectedBranchDetail(targetBranch);
          setScreenFlow('main');
        }
      }

      if (urlParams.get('book') === '1') {
        setIsBookingOpen(true);
        setScreenFlow('main');
      }

      if (
        urlParams.get('source') === 'pwa' ||
        urlParams.get('skip') === '1' ||
        urlParams.get('autostart') === '1'
      ) {
        setScreenFlow('main');
      }
    } catch {
      // Ignore URL parsing errors
    }
  }, []);

  useEffect(() => {
    const handleStorageUpdate = () => {
      setTickets(StorageService.getTickets());
      setNotifications(StorageService.getNotifications());
      setProfile(StorageService.getProfile());
    };

    window.addEventListener('banknavbat_storage_update', handleStorageUpdate);
    return () => {
      window.removeEventListener('banknavbat_storage_update', handleStorageUpdate);
    };
  }, []);

  // Sync theme with <html> element class
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const handleToggleTheme = () => {
    setIsDarkMode((prev) => !prev);
  };

  const handleChangeLanguage = (newLang: Language) => {
    setLanguage(newLang);
    StorageService.saveProfile({ language: newLang });
  };

  const handleOpenBooking = (preselected?: { branch?: BankBranch; service?: BankService }) => {
    setBookingPreselected(preselected || {});
    setIsBookingOpen(true);
  };

  const handleTicketCreated = (newTicket: QueueTicket) => {
    setTickets(StorageService.getTickets());
    setViewTicketModal(newTicket);
  };

  const activeTicketsCount = tickets.filter(
    (t) => t.status === 'active' || t.status === 'waiting' || t.status === 'in_service'
  ).length;

  const unreadNotificationsCount = notifications.filter((n) => !n.isRead).length;

  return (
    <MobileDeviceFrame
      isDeviceMode={isDeviceMode}
      onToggleDeviceMode={() => setIsDeviceMode(!isDeviceMode)}
      language={language}
      onChangeLanguage={handleChangeLanguage}
      isDarkMode={isDarkMode}
      onToggleTheme={handleToggleTheme}
      unreadNotificationsCount={unreadNotificationsCount}
      onOpenNotifications={() => setIsNotificationsOpen(true)}
      onOpenApkModal={() => setIsApkModalOpen(true)}
    >
      <AnimatePresence mode="wait">
        {/* 1. Splash Screen */}
        {screenFlow === 'splash' && (
          <motion.div
            key="splash"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            transition={{ duration: 0.3 }}
            className="flex-1 flex flex-col h-full"
          >
            <SplashScreen
              language={language}
              onFinish={() => {
                if (profile.hasCompletedOnboarding) {
                  setScreenFlow('main');
                } else {
                  setScreenFlow('onboarding');
                }
              }}
            />
          </motion.div>
        )}

        {/* 2. Onboarding Screen */}
        {screenFlow === 'onboarding' && (
          <motion.div
            key="onboarding"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
            className="flex-1 flex flex-col h-full"
          >
            <OnboardingScreen
              language={language}
              onFinish={() => setScreenFlow('main')}
            />
          </motion.div>
        )}

        {/* 3. Main Dashboard Navigation Screens */}
        {screenFlow === 'main' && (
          <motion.div
            key="main"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="flex-1 flex flex-col justify-between min-h-full"
          >
            <div className="flex-1">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  transition={{ duration: 0.18, ease: 'easeOut' }}
                >
                  {activeTab === 'home' && (
                    <HomeScreen
                      language={language}
                      onOpenBooking={handleOpenBooking}
                      onSelectBranch={(b) => setSelectedBranchDetail(b)}
                      onViewTicket={(t) => setViewTicketModal(t)}
                      onNavigateToBranches={(q) => {
                        if (q) setBranchesSearchQuery(q);
                        setActiveTab('branches');
                      }}
                      onNavigateToMap={() => setActiveTab('map')}
                      onOpenApkModal={() => setIsApkModalOpen(true)}
                    />
                  )}

                  {activeTab === 'branches' && (
                    <BranchesScreen
                      language={language}
                      initialQuery={branchesSearchQuery}
                      onOpenBooking={(b) => handleOpenBooking({ branch: b })}
                      onSelectBranch={(b) => setSelectedBranchDetail(b)}
                    />
                  )}

                  {activeTab === 'map' && (
                    <MapScreen
                      language={language}
                      onSelectBranch={(b) => setSelectedBranchDetail(b)}
                      onBookQueue={(b) => handleOpenBooking({ branch: b })}
                    />
                  )}

                  {activeTab === 'queues' && (
                    <MyQueuesScreen
                      language={language}
                      onOpenBooking={() => handleOpenBooking()}
                      onRateTicket={(ticket) => setRatingModalTicket(ticket)}
                      onSelectBranch={(branchId) => {
                        setActiveTab('branches');
                      }}
                    />
                  )}

                  {activeTab === 'profile' && (
                    <ProfileScreen
                      language={language}
                      onChangeLanguage={handleChangeLanguage}
                      isDarkMode={isDarkMode}
                      onToggleTheme={handleToggleTheme}
                      onReplayOnboarding={() => setScreenFlow('onboarding')}
                      onOpenExpoGuide={() => setIsExpoGuideOpen(true)}
                      onOpenNotifications={() => setIsNotificationsOpen(true)}
                      onNavigateToBranches={() => setActiveTab('branches')}
                      onOpenApkModal={() => setIsApkModalOpen(true)}
                    />
                  )}
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Sticky Bottom Tab Bar */}
            <BottomTabBar
              activeTab={activeTab}
              onTabChange={setActiveTab}
              language={language}
              activeTicketsCount={activeTicketsCount}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Global Modals */}

      {/* Booking Wizard Modal */}
      <BookingWizardModal
        isOpen={isBookingOpen}
        onClose={() => {
          setIsBookingOpen(false);
          setBookingPreselected({});
        }}
        language={language}
        preselectedBranch={bookingPreselected.branch}
        onTicketCreated={handleTicketCreated}
      />

      {/* Branch Detail Modal */}
      <BranchDetailModal
        branch={selectedBranchDetail}
        language={language}
        onClose={() => setSelectedBranchDetail(null)}
        onBookQueue={(b) => {
          setSelectedBranchDetail(null);
          handleOpenBooking({ branch: b });
        }}
      />

      {/* Rating Modal */}
      <RatingModal
        ticket={ratingModalTicket}
        language={language}
        onClose={() => setRatingModalTicket(null)}
        onSubmitted={() => setTickets(StorageService.getTickets())}
      />

      {/* Notifications Modal */}
      <NotificationsModal
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        language={language}
        onSelectTicket={(ticketId) => {
          const tkt = tickets.find((t) => t.id === ticketId);
          if (tkt) {
            setViewTicketModal(tkt);
          }
        }}
      />

      {/* Expo & React Native Architecture Guide Modal */}
      <ExpoArchitectureModal
        isOpen={isExpoGuideOpen}
        onClose={() => setIsExpoGuideOpen(false)}
      />

      {/* Android APK & Installation Modal */}
      <AndroidApkModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />

      {/* Ticket Viewer Modal (when opening ticket from active banner or notification) */}
      {viewTicketModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
          <div
            className="w-full max-w-md max-h-[92vh] overflow-y-auto no-scrollbar relative animate-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative">
              <button
                type="button"
                onClick={() => setViewTicketModal(null)}
                className="absolute top-3 right-3 z-30 w-8 h-8 rounded-full bg-white/20 hover:bg-white/40 text-white flex items-center justify-center transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
              <DigitalTicketCard
                ticket={viewTicketModal}
                language={language}
                onCancelRequest={() => {
                  setViewTicketModal(null);
                  setTickets(StorageService.getTickets());
                }}
                onRateRequest={(ticket) => {
                  setViewTicketModal(null);
                  setRatingModalTicket(ticket);
                }}
              />
            </div>
          </div>
        </div>
      )}
    </MobileDeviceFrame>
  );
}
