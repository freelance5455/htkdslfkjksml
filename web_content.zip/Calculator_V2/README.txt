Calculator V2 Vault Prototype

Open index.html in a modern browser. The calculator and PIN flow remain. Vault file actions now use IndexedDB: import files, list/filter, view (browser-supported files), restore/download files, and delete files.

IMPORTANT: This is a browser prototype. PIN is stored in localStorage and vault files are NOT encrypted. Do not store sensitive files in it. Browser storage may be cleared, and this is not yet a native Android APK. Test with non-sensitive files only.
