import { initializeApp } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-app.js";
import {
  getAuth,
  onAuthStateChanged,
  setPersistence,
  browserLocalPersistence,
  updateProfile
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-auth.js";
import {
  getDatabase,
  ref,
  push,
  set,
  onValue,
  remove,
  update
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyDHjqIRyA7VoWoH1Wdr7XUbRmAxhnUufjk",
  authDomain: "clips-61b6a.firebaseapp.com",
  databaseURL: "https://clips-61b6a-default-rtdb.firebaseio.com",
  projectId: "clips-61b6a",
  storageBucket: "clips-61b6a.appspot.com",
  messagingSenderId: "408398676797",
  appId: "1:408398676797:web:ecc603268691d236ca3b54",
  measurementId: "G-GBWWMMFP4D"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);

const createprj = document.getElementById('createprj');
const createp = document.getElementById('createp');
const create = document.getElementById('create');
const hisB = document.getElementById('hisB');
const his = document.getElementById('his');
const cnt = document.getElementById('cnt');
const uploadedTab = document.getElementById('uploadedTab');
const downloadsTab = document.getElementById('downloadsTab');
const imageInput = document.getElementById('cpimage');
const videoInput = document.getElementById('cpvideo');
const previewOverlay = document.getElementById('project-preview');
if (previewOverlay) {
  previewOverlay.querySelector('.preview-close').onclick = () => previewOverlay.style.display = 'none';
  previewOverlay.onclick = (e) => { if (e.target === previewOverlay) previewOverlay.style.display = 'none'; };
}

const DB_NAME = 'BetterClipsHistory';
const DB_VERSION = 1;
const STORE = 'media';
const PROJECTS_PATH = 'projects';
const MAX_IMAGE_BYTES = 2 * 1024 * 1024;
const MAX_VIDEO_BYTES = 8 * 1024 * 1024;

let historyMode = 'uploaded';
let selectedUpload = null;
let selectedImage = null;
let selectedVideo = null;
let currentUser = null;
let projects = {};
let unsubscribeProjects = null;
let objectUrls = [];

function showMessage(message) {
  let toast = document.getElementById('bc-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'bc-toast';
    toast.setAttribute('role', 'status');
    toast.setAttribute('aria-live', 'polite');
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(showMessage.timer);
  showMessage.timer = setTimeout(() => toast.classList.remove('show'), 3200);
}

function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE)) {
        db.createObjectStore(STORE, { keyPath: 'id', autoIncrement: true });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function addHistoryItem(item) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).add(item);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

async function getHistory(type) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const request = tx.objectStore(STORE).getAll();
    request.onsuccess = () => {
      const items = request.result.filter(item => item.type === type);
      items.sort((a, b) => b.createdAt - a.createdAt);
      resolve(items);
    };
    request.onerror = () => reject(request.error);
  });
}

async function deleteHistoryItem(id) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).delete(id);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

function formatDate(timestamp) {
  return new Date(timestamp).toLocaleString([], {
    month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit'
  });
}

function makeDownload(blob, name) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name || 'better-clips-download';
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function downloadHistoryItem(item) {
  makeDownload(item.blob, item.name);
  await addHistoryItem({
    type: 'download', name: item.name, mime: item.mime,
    blob: item.blob, createdAt: Date.now()
  });
  if (historyMode === 'download') renderHistory();
}

async function renderHistory() {
  cnt.innerHTML = '';
  objectUrls.forEach(url => URL.revokeObjectURL(url));
  objectUrls = [];
  const items = await getHistory(historyMode);

  if (!items.length) {
    cnt.innerHTML = '<div class="empty-history">Nothing here yet</div>';
    return;
  }

  items.forEach(item => {
    const row = document.createElement('div');
    row.className = 'history-item';
    const left = document.createElement('div');
    left.className = 'history-info';
    const preview = document.createElement('div');
    preview.className = 'history-preview';
    const url = URL.createObjectURL(item.blob);
    objectUrls.push(url);

    if (item.mime && item.mime.startsWith('video/')) {
      const video = document.createElement('video');
      video.src = url; video.muted = true; video.playsInline = true; video.preload = 'metadata';
      preview.appendChild(video);
    } else {
      const img = document.createElement('img');
      img.src = url; preview.appendChild(img);
    }

    const text = document.createElement('div');
    text.innerHTML = `<p>${escapeHtml(item.name)}</p><small>${formatDate(item.createdAt)}</small>`;
    left.append(preview, text);

    const actions = document.createElement('div');
    actions.className = 'history-actions';
    const dl = document.createElement('button');
    dl.innerHTML = '<span class="material-symbols-outlined">download</span>';
    dl.title = 'Download'; dl.onclick = () => downloadHistoryItem(item);
    const del = document.createElement('button');
    del.innerHTML = '<span class="material-symbols-outlined">delete</span>';
    del.title = 'Delete';
    del.onclick = async () => { await deleteHistoryItem(item.id); renderHistory(); };
    actions.append(dl, del);
    row.append(left, actions);
    cnt.appendChild(row);
  });
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
  }[char]));
}

async function handleUpload(file) {
  if (!file) return;
  selectedUpload = file;
  if (file.type.startsWith('image/')) selectedImage = file;
  if (file.type.startsWith('video/')) selectedVideo = file;
  await addHistoryItem({
    type: 'uploaded', name: file.name,
    mime: file.type || 'application/octet-stream', blob: file, createdAt: Date.now()
  });

  if (file.type.startsWith('image/')) imageInput.closest('.upload-choice')?.classList.add('selected-upload');
  else if (file.type.startsWith('video/')) videoInput.closest('.upload-choice')?.classList.add('selected-upload');
  if (his.style.display === 'block' && historyMode === 'uploaded') renderHistory();
}

function setupReactionButtons(project, projectId) {
  const like = project.querySelector('.like-btn');
  const dislike = project.querySelector('.dislike-btn');
  if (!like || !dislike || projectId === '__demo__') return;

  const refresh = () => {
    const data = projects[projectId] || {};
    const likedBy = data.likedBy || {};
    const dislikedBy = data.dislikedBy || {};
    like.classList.toggle('active', !!currentUser && !!likedBy[currentUser.uid]);
    dislike.classList.toggle('active', !!currentUser && !!dislikedBy[currentUser.uid]);
    like.title = `Like${data.likes ? ` (${data.likes})` : ''}`;
    dislike.title = `Dislike${data.dislikes ? ` (${data.dislikes})` : ''}`;
  };

  refresh();

  like.onclick = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!currentUser) return;
    like.disabled = true;
    try {
      const projectData = projects[projectId] || {};
      const likes = { ...(projectData.likedBy || {}) };
      const dislikes = { ...(projectData.dislikedBy || {}) };
      if (likes[currentUser.uid]) delete likes[currentUser.uid];
      else { likes[currentUser.uid] = true; delete dislikes[currentUser.uid]; }
      await update(ref(db, `${PROJECTS_PATH}/${projectId}`), {
        likedBy: likes,
        dislikedBy: dislikes,
        likes: Object.keys(likes).length,
        dislikes: Object.keys(dislikes).length
      });
    } catch (error) {
      console.error(error);
      showMessage('Could not update the like. Check your Firebase Database rules.');
    } finally {
      like.disabled = false;
    }
  };

  dislike.onclick = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!currentUser) return;
    dislike.disabled = true;
    try {
      const projectData = projects[projectId] || {};
      const likes = { ...(projectData.likedBy || {}) };
      const dislikes = { ...(projectData.dislikedBy || {}) };
      if (dislikes[currentUser.uid]) delete dislikes[currentUser.uid];
      else { dislikes[currentUser.uid] = true; delete likes[currentUser.uid]; }
      await update(ref(db, `${PROJECTS_PATH}/${projectId}`), {
        likedBy: likes,
        dislikedBy: dislikes,
        likes: Object.keys(likes).length,
        dislikes: Object.keys(dislikes).length
      });
    } catch (error) {
      console.error(error);
      showMessage('Could not update the dislike. Check your Firebase Database rules.');
    } finally {
      dislike.disabled = false;
    }
  };
}

function renderProjects() {
  const container = document.querySelector('.container');
  const original = document.getElementById('prj');
  container.querySelectorAll('.remote-project').forEach(el => el.remove());

  Object.entries(projects)
    .sort(([, a], [, b]) => (b.createdAt || 0) - (a.createdAt || 0))
    .forEach(([id, data]) => {
      const project = document.createElement('div');
      project.className = 'prj remote-project';
      project.dataset.projectId = id;
      project.dataset.type = data.type || '';
      project.dataset.owner = data.ownerUsername || data.ownerName || data.ownerEmail || '';
      project.innerHTML = `
        <div class="tb">
          <div class="project-heading">
            <p class="title"></p>
            <div class="project-owner-wrap">
              <span class="project-owner"></span>
              <small class="project-type"></small>
            </div>
          </div>
        </div>
        <img alt="Project preview">
        <div class="bb">
          <button type="button" class="like-btn" aria-label="Like"><span class="material-symbols-outlined">thumb_up</span></button>
          <button type="button" class="dislike-btn" aria-label="Dislike"><span class="material-symbols-outlined">thumb_down</span></button>
          <button type="button" class="project-download" aria-label="Download"><span class="material-symbols-outlined">download</span></button>
          <button type="button" class="project-delete" aria-label="Delete project" title="Delete project"><span class="material-symbols-outlined">delete</span></button>
        </div>
      `;
      project.querySelector('.title').textContent = data.name || 'Untitled project';
      project.querySelector('.project-owner').textContent = data.ownerUsername || data.ownerName || data.ownerEmail || 'Unknown user';
      project.querySelector('.project-type').textContent = data.type || 'none';
      const previewImage = data.image || data.imageUrl || 'image.jpeg';
      project.querySelector('img').src = previewImage;
      project.querySelector('img').alt = `${data.name || 'Project'} preview`;

      const openPreview = () => {
        const overlay = document.getElementById('project-preview');
        if (!overlay) return;
        overlay.querySelector('.preview-title').textContent = data.name || 'Untitled project';
        overlay.querySelector('.preview-owner').textContent = data.ownerUsername || data.ownerName || data.ownerEmail || 'Unknown user';
        overlay.querySelector('.preview-type').textContent = data.type || 'none';
        const previewImg = overlay.querySelector('.preview-image');
        const previewVideo = overlay.querySelector('.preview-video');
        if (data.video) {
          previewImg.hidden = true;
          previewVideo.hidden = false;
          previewVideo.src = data.video;
          previewVideo.load();
        } else {
          previewVideo.pause();
          previewVideo.removeAttribute('src');
          previewVideo.load();
          previewVideo.hidden = true;
          previewImg.hidden = false;
          previewImg.src = previewImage;
        }
        overlay.querySelector('.preview-download').onclick = () => project.querySelector('.project-download').click();
        overlay.style.display = 'flex';
      };

      project.querySelector('img').onclick = openPreview;
      project.querySelector('.title').onclick = openPreview;
      project.querySelector('.project-download').onclick = async (e) => {
        e.stopPropagation();
        try {
          const source = data.video || previewImage;
          const response = await fetch(source);
          const blob = await response.blob();
          const ext = data.video ? ((data.videoMime || blob.type || 'video/mp4').split('/')[1] || 'mp4').split(';')[0] : 'jpg';
          await downloadHistoryItem({
            name: `${data.name || 'project'}.${ext}`,
            mime: blob.type || (data.video ? data.videoMime : 'image/jpeg'),
            blob
          });
        } catch (error) {
          console.error(error);
          showMessage('Could not download this project.');
        }
      };

      const deleteButton = project.querySelector('.project-delete');
      const isOwner = !!currentUser && data.ownerUid === currentUser.uid;
      deleteButton.style.display = isOwner ? '' : 'none';
      deleteButton.onclick = async (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!currentUser || data.ownerUid !== currentUser.uid) return;
        if (!confirm(`Delete "${data.name || 'Untitled project'}" for everyone?`)) return;
        deleteButton.disabled = true;
        try {
          await remove(ref(db, `${PROJECTS_PATH}/${id}`));
        } catch (error) {
          console.error(error);
          deleteButton.disabled = false;
          showMessage(error.message || 'Could not delete the project.');
        }
      };

      setupReactionButtons(project, id);
      container.appendChild(project);
    });

  if (original) setupReactionButtons(original, '__demo__');
  searchfor(document.getElementById('search').value);
}

async function ensureUsernameProfile(user) {
  const savedUsername = localStorage.getItem('betterClipsUsername') || '';
  const username = (user.displayName || savedUsername || '').trim();
  if (!username) return '';

  if (user.displayName !== username) {
    try {
      await updateProfile(user, { displayName: username });
    } catch (error) {
      console.warn('Could not set Firebase username:', error);
    }
  }
  localStorage.setItem('betterClipsUsername', username);
  return username;
}

async function migrateOwnProjectUsernames(username) {
  if (!currentUser || !username) return;
  const changes = {};
  Object.entries(projects).forEach(([id, data]) => {
    if (data && data.ownerUid === currentUser.uid && data.ownerUsername !== username) {
      changes[`${PROJECTS_PATH}/${id}/ownerUsername`] = username;
      changes[`${PROJECTS_PATH}/${id}/ownerName`] = username;
    }
  });
  if (Object.keys(changes).length) {
    try {
      await update(ref(db), changes);
    } catch (error) {
      console.warn('Could not migrate project username:', error);
    }
  }
}

function startProjectSync() {
  if (unsubscribeProjects) unsubscribeProjects();
  unsubscribeProjects = onValue(ref(db, PROJECTS_PATH), (snapshot) => {
    projects = snapshot.val() || {};
    renderProjects();
    const username = currentUser?.displayName || localStorage.getItem('betterClipsUsername') || '';
    if (username) migrateOwnProjectUsernames(username);
  }, (error) => {
    console.error(error);
    showMessage('Could not load shared projects. Check your Firebase Database rules.');
  });
}

function fileToCompressedDataUrl(file) {
  return new Promise((resolve, reject) => {
    if (!file || !file.type.startsWith('image/')) {
      resolve('image.jpeg');
      return;
    }
    if (file.size > MAX_IMAGE_BYTES) {
      reject(new Error('Image is too large. Choose an image under 2 MB.'));
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const maxSide = 1280;
        const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(img.width * scale));
        canvas.height = Math.max(1, Math.round(img.height * scale));
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', 0.78));
      };
      img.onerror = () => reject(new Error('Could not read that image.'));
      img.src = reader.result;
    };
    reader.onerror = () => reject(reader.error || new Error('Could not read that image.'));
    reader.readAsDataURL(file);
  });
}

createprj.onclick = (e) => {
  e.preventDefault(); e.stopPropagation(); createp.style.display = 'block';
};

create.onclick = async (e) => {
  e.preventDefault();
  if (!currentUser) { showMessage('Please log in first.'); return; }

  const name = document.getElementById('prjname').value.trim();
  const type = document.getElementById('prjtype').value;
  if (!name) { showMessage('Enter a project name.'); return; }

  create.disabled = true;
  try {
    const imageFile = selectedImage;
    const videoFile = selectedVideo;
    const image = imageFile ? await fileToCompressedDataUrl(imageFile) : 'image.jpeg';
    const video = videoFile ? await fileToDataUrl(videoFile, MAX_VIDEO_BYTES) : '';
    const projectRef = push(ref(db, PROJECTS_PATH));
    await set(projectRef, {
      name,
      type,
      image,
      video,
      videoMime: videoFile?.type || '',
      ownerUid: currentUser.uid,
      ownerUsername: currentUser.displayName || localStorage.getItem('betterClipsUsername') || 'User',
      ownerName: currentUser.displayName || localStorage.getItem('betterClipsUsername') || 'User',
      ownerEmail: currentUser.email || '',
      createdAt: Date.now(),
      likes: 0,
      dislikes: 0,
      likedBy: {},
      dislikedBy: {}
    });

    createp.style.display = 'none';
    document.getElementById('prjname').value = '';
    imageInput.value = '';
    videoInput.value = '';
    selectedUpload = null;
    selectedImage = null;
    selectedVideo = null;
    document.querySelectorAll('.selected-upload').forEach(button => button.classList.remove('selected-upload'));
    if (imageLabel) imageLabel.textContent = 'select image';
    if (videoLabel) videoLabel.textContent = 'select video';
  } catch (error) {
    console.error(error);
    showMessage(error.message || 'Could not create the shared project.');
  } finally {
    create.disabled = false;
  }
};

const imageChoice = document.getElementById('imageChoice');
const videoChoice = document.getElementById('videoChoice');
const imageLabel = document.getElementById('imageLabel');
const videoLabel = document.getElementById('videoLabel');

// The APK/WebView can treat <label for=file> differently from a normal browser.
// Handle the visible buttons as real user-gesture targets and explicitly open
// the native picker. preventDefault() stops the label's default action from
// interfering, while input.click() is still inside the user's click event.
imageChoice?.addEventListener('click', (e) => {
  e.preventDefault();
  e.stopPropagation();
  imageInput?.click();
});

videoChoice?.addEventListener('click', (e) => {
  e.preventDefault();
  e.stopPropagation();
  videoInput?.click();
});

imageInput?.addEventListener('change', async () => {
  const file = imageInput.files?.[0];
  if (!file) return;
  selectedImage = file;
  imageLabel.textContent = file.name;
  imageChoice?.classList.add('selected-upload');
  await handleUpload(file);
});

videoInput?.addEventListener('change', async () => {
  const file = videoInput.files?.[0];
  if (!file) return;
  selectedVideo = file;
  videoLabel.textContent = file.name;
  videoChoice?.classList.add('selected-upload');
  await handleUpload(file);
});

function fileToDataUrl(file, maxBytes) {
  return new Promise((resolve, reject) => {
    if (!file) return resolve('');
    if (file.size > maxBytes) {
      reject(new Error(`Video is too large. Choose a video under ${Math.round(maxBytes / 1024 / 1024)} MB.`));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error || new Error('Could not read that video.'));
    reader.readAsDataURL(file);
  });
}

hisB.onclick = (e) => {
  e.preventDefault(); e.stopPropagation();
  his.style.display = 'block'; historyMode = 'uploaded'; updateHistoryTabs(); renderHistory();
};

document.addEventListener('click', (e) => {
  if (his.style.display === 'block' && !his.contains(e.target) && e.target !== hisB && !hisB.contains(e.target)) his.style.display = 'none';
  if (createp.style.display === 'block' && !createp.contains(e.target) && e.target !== createprj && !createprj.contains(e.target)) createp.style.display = 'none';
});

uploadedTab.onclick = (e) => { e.preventDefault(); historyMode = 'uploaded'; updateHistoryTabs(); renderHistory(); };
downloadsTab.onclick = (e) => { e.preventDefault(); historyMode = 'download'; updateHistoryTabs(); renderHistory(); };

function updateHistoryTabs() {
  uploadedTab.classList.toggle('active', historyMode === 'uploaded');
  downloadsTab.classList.toggle('active', historyMode === 'download');
}

const search = document.getElementById('search');
search.addEventListener('input', () => searchfor(search.value));
search.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); searchfor(search.value); } });

function searchfor(s) {
  const raw = String(s || '').trim().toLowerCase();
  const usernameMatch = raw.match(/\(([^)]*)\)/);
  const username = (usernameMatch?.[1] || '').trim().replace(/^@/, '');
  const term = raw.replace(/\([^)]*\)/g, ' ').replace(/\s+/g, ' ').trim();
  const words = term ? term.split(' ') : [];

  document.querySelectorAll('.container .prj').forEach(prj => {
    if (prj.id === 'prj') {
      prj.style.display = raw ? 'none' : '';
      return;
    }

    const title = prj.querySelector('.title')?.textContent?.toLowerCase() || '';
    const type = (prj.dataset.type || '').toLowerCase();
    const owner = (prj.dataset.owner || '').toLowerCase().replace(/^@/, '');

    const textMatches = !words.length || words.every(word =>
      title.includes(word) || type.includes(word)
    );
    const userMatches = !username || owner === username || owner.includes(username);

    prj.style.display = textMatches && userMatches ? '' : 'none';
  });
}


(async function initAuth() {
  try {
    await setPersistence(auth, browserLocalPersistence);
  } catch (error) {
    console.warn('Could not enable local auth persistence:', error);
  }

  onAuthStateChanged(auth, async user => {
    if (!user) {
      window.location.replace('index.html');
      return;
    }
    currentUser = user;
    await ensureUsernameProfile(user);
    startProjectSync();
  });
})();
