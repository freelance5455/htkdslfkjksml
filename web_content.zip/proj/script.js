import { initializeApp } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-app.js";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  setPersistence,
  browserLocalPersistence,
  onAuthStateChanged,
  updateProfile
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyDHjqIRyA7VoWoH1Wdr7XUbRmAxhnUufjk",
  authDomain: "clips-61b6a.firebaseapp.com",
  databaseURL: "https://clips-61b6a-default-rtdb.firebaseio.com",
  projectId: "clips-61b6a",
  storageBucket: "clips-61b6a.appspot.com",
  messagingSenderId: "408398676797",
  appId: "1:408398676797:web:ecc603268691d236ca3b54",
  measurementId: "G-GBWWMMFP4D"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const submit = document.getElementById('submit');
const password = document.getElementById('password');
const email = document.getElementById('email');
const visibility = document.getElementById('visibility');
const vis = document.getElementById('vis');

function showError(message) {
  const alertMessage = document.getElementById('alert-message');
  const overlay = document.getElementById('custom-alert-overlay');
  if (alertMessage && overlay) {
    alertMessage.innerText = message;
    overlay.style.display = 'block';
  } else {
    alert(message);
  }
}

async function goToAppIfSignedIn() {
  try {
    await setPersistence(auth, browserLocalPersistence);
  } catch (error) {
    console.warn('Could not enable local auth persistence:', error);
  }

  onAuthStateChanged(auth, (user) => {
    if (user) window.location.replace('main.html');
  });
}

document.addEventListener('DOMContentLoaded', async () => {
  await goToAppIfSignedIn();

  if (visibility) {
    visibility.onclick = (e) => {
      e.preventDefault();
      const isPassword = password.type === 'password';
      password.type = isPassword ? 'text' : 'password';
      vis.textContent = isPassword ? 'visibility_off' : 'visibility';
    };
  }

  submit.onclick = async (e) => {
    e.preventDefault();
    submit.disabled = true;

    const emailValue = email.value.trim();
    const passwordValue = password.value;
    const usernameValue = document.getElementById('user')?.value.trim() || '';

    if (!emailValue || !passwordValue) {
      showError('Enter your email and password.');
      submit.disabled = false;
      return;
    }

    try {
      await setPersistence(auth, browserLocalPersistence);

      // Try to log in first. This makes returning users go straight back into
      // their existing account instead of creating another one.
      const credential = await signInWithEmailAndPassword(auth, emailValue, passwordValue);
      if (usernameValue && credential.user.displayName !== usernameValue) {
        await updateProfile(credential.user, { displayName: usernameValue });
        localStorage.setItem('betterClipsUsername', usernameValue);
      }
      window.location.replace('main.html');
    } catch (loginError) {
      if (loginError.code === 'auth/user-not-found' || loginError.code === 'auth/invalid-credential') {
        try {
          const credential = await createUserWithEmailAndPassword(auth, emailValue, passwordValue);
          if (usernameValue) {
            await updateProfile(credential.user, { displayName: usernameValue });
            localStorage.setItem('betterClipsUsername', usernameValue);
          }
          window.location.replace('main.html');
        } catch (createError) {
          showError(getAuthError(createError));
          submit.disabled = false;
        }
      } else {
        showError(getAuthError(loginError));
        submit.disabled = false;
      }
    }
  };
});

function getAuthError(error) {
  switch (error.code) {
    case 'auth/wrong-password':
    case 'auth/invalid-credential':
      return 'That email/password combination is not correct.';
    case 'auth/invalid-email':
      return 'Enter a valid email address.';
    case 'auth/weak-password':
      return 'Password must be at least 6 characters.';
    case 'auth/email-already-in-use':
      return 'An account already exists with that email. Check your password.';
    case 'auth/too-many-requests':
      return 'Too many attempts. Try again later.';
    default:
      return error.message || 'Could not sign you in.';
  }
}
