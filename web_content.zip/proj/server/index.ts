import express, { type Request, type Response } from 'express';
import crypto from 'node:crypto';
import multer from 'multer';
import { db, migrate } from './lib/db.js';

const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-user-id, x-admin-token');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  if (req.method === 'OPTIONS') { res.sendStatus(204); return; }
  next();
});
app.use(express.json({ limit: '1mb' }));

migrate(`
  CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, first_name TEXT NOT NULL, last_name TEXT NOT NULL, phone TEXT NOT NULL, username TEXT NOT NULL UNIQUE, gender TEXT NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'student', subject TEXT DEFAULT '', bio TEXT DEFAULT '', avatar_url TEXT DEFAULT '', show_online TEXT NOT NULL DEFAULT 'everyone', show_profile TEXT NOT NULL DEFAULT 'everyone', theme TEXT NOT NULL DEFAULT 'emerald', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS admin_tokens (token TEXT PRIMARY KEY, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS studies (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, subject TEXT NOT NULL, minutes INTEGER NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS warnings (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, body TEXT NOT NULL, read_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY AUTOINCREMENT, sender_id INTEGER NOT NULL, recipient_id INTEGER NOT NULL, body TEXT, attachment_url TEXT, attachment_type TEXT, deleted_by_sender INTEGER NOT NULL DEFAULT 0, deleted_by_recipient INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS user_activity (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, action TEXT NOT NULL, detail TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS user_presence (user_id INTEGER PRIMARY KEY, status TEXT NOT NULL DEFAULT 'offline', last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS announcements (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT NOT NULL, media_url TEXT, media_type TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS assignments (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT NOT NULL, subject TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
`);
for (const statement of [
  "ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'student'", "ALTER TABLE users ADD COLUMN subject TEXT DEFAULT ''", "ALTER TABLE users ADD COLUMN bio TEXT DEFAULT ''", "ALTER TABLE users ADD COLUMN avatar_url TEXT DEFAULT ''", "ALTER TABLE users ADD COLUMN show_online TEXT NOT NULL DEFAULT 'everyone'", "ALTER TABLE users ADD COLUMN show_profile TEXT NOT NULL DEFAULT 'everyone'", "ALTER TABLE users ADD COLUMN theme TEXT NOT NULL DEFAULT 'emerald'", "ALTER TABLE warnings ADD COLUMN read_at TEXT", "ALTER TABLE messages ADD COLUMN deleted_by_sender INTEGER NOT NULL DEFAULT 0", "ALTER TABLE messages ADD COLUMN deleted_by_recipient INTEGER NOT NULL DEFAULT 0"
]) { try { db.exec(statement); } catch { /* migrated earlier */ } }

const OWNER_PASSWORD = 'Madrsa_12_Frordin';
const STAFF_CODES = new Set(['Moaalman_1219', 'Mahdi_4351', 'Mohmdi1014', 'Btl_Roial_6579', 'Flooding12', 'Google000', 'Tara1090', 'Prshn_6666', 'Ali_121319', 'Rostamkhani_121819', 'Dift_98', 'Targt_2040']);
const hashPassword = (value: string) => crypto.createHash('sha256').update(value).digest('hex');
const makeToken = () => crypto.randomBytes(32).toString('hex');
function safeUser(row: Record<string, unknown>) { return { id: row.id, firstName: row.first_name, lastName: row.last_name, username: row.username, gender: row.gender, phone: row.phone, role: row.role, subject: row.subject || '', bio: row.bio || '', avatarUrl: row.avatar_url || '', showOnline: row.show_online || 'everyone', showProfile: row.show_profile || 'everyone', theme: row.theme || 'emerald' }; }
function userId(req: Request) { const id = Number(req.header('x-user-id')); return Number.isInteger(id) && id > 0 ? id : null; }
function requireUser(req: Request, res: Response) { const id = userId(req); if (!id) { res.status(401).json({ error: 'ابتدا وارد حساب شوید.' }); return null; } return id; }
function requireAdmin(req: Request, res: Response) { const token = req.header('x-admin-token'); if (!token || !db.prepare('SELECT 1 FROM admin_tokens WHERE token = ?').get(token)) { res.status(401).json({ error: 'دسترسی مدیریت مجاز نیست.' }); return false; } return true; }
function activity(id: number, action: string, detail = '') { db.prepare('INSERT INTO user_activity (user_id, action, detail) VALUES (?,?,?)').run(id, action, detail); }
function presence(id: number, status: 'online' | 'offline') { db.prepare("INSERT INTO user_presence (user_id,status,last_seen,updated_at) VALUES (?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET status=excluded.status,last_seen=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP").run(id, status); }
function issueAdminToken() { const token = makeToken(); db.prepare('INSERT INTO admin_tokens (token) VALUES (?)').run(token); return token; }

app.post('/api/auth/register', (req, res) => { try {
  const { firstName, lastName, phone, username, gender, password, role, subject } = req.body as Record<string, string>;
  const staff = role === 'teacher' || role === 'manager';
  if (!firstName?.trim() || !lastName?.trim() || !phone?.trim() || !username?.trim() || !gender || !password || password.length < 8 || (staff && (!subject?.trim() || !STAFF_CODES.has(password)))) { res.status(400).json({ error: staff ? 'کد ورود معلم معتبر نیست یا اطلاعات کامل نیست.' : 'اطلاعات ثبت‌نام کامل نیست.' }); return; }
  const result = db.prepare('INSERT INTO users (first_name,last_name,phone,username,gender,password_hash,role,subject) VALUES (?,?,?,?,?,?,?,?)').run(firstName.trim(), lastName.trim(), phone.trim(), username.trim().toLowerCase(), gender, hashPassword(password), staff ? role : 'student', staff ? subject.trim() : '');
  const id = Number(result.lastInsertRowid); const row = db.prepare('SELECT * FROM users WHERE id=?').get(id) as Record<string, unknown>;
  presence(id, 'online'); activity(id, 'ساخت حساب کاربری', staff ? 'حساب معلم' : 'حساب دانش‌آموز');
  res.status(201).json({ user: safeUser(row), adminToken: staff ? issueAdminToken() : null });
} catch (error) { console.error('register failed', error); res.status(409).json({ error: 'این نام کاربری قبلاً انتخاب شده است.' }); } });
app.post('/api/auth/login', (req, res) => { try {
  const { phone, password } = req.body as Record<string, string>;
  const row = db.prepare('SELECT * FROM users WHERE phone=? AND password_hash=? ORDER BY id DESC LIMIT 1').get(phone?.trim(), hashPassword(password || '')) as Record<string, unknown> | undefined;
  if (!row) { res.status(401).json({ error: 'شماره تلفن یا رمز عبور نادرست است.' }); return; }
  const id = Number(row.id); presence(id, 'online'); activity(id, 'ورود به برنامه');
  const staff = row.role === 'teacher' || row.role === 'manager'; res.json({ user: safeUser(row), adminToken: staff ? issueAdminToken() : null });
} catch (error) { console.error('login failed', error); res.status(500).json({ error: 'ورود انجام نشد.' }); } });
app.get('/api/profile/me', (req, res) => { const id = requireUser(req, res); if (!id) return; const row = db.prepare('SELECT * FROM users WHERE id=?').get(id) as Record<string, unknown>; res.json({ user: safeUser(row) }); });
app.put('/api/profile/me', (req, res) => { const id = requireUser(req, res); if (!id) return; const { firstName, lastName, bio, avatarUrl, showOnline, showProfile, theme } = req.body as Record<string, string>; db.prepare('UPDATE users SET first_name=?,last_name=?,bio=?,avatar_url=?,show_online=?,show_profile=?,theme=? WHERE id=?').run((firstName || '').slice(0, 50), (lastName || '').slice(0, 50), (bio || '').slice(0, 280), (avatarUrl || '').slice(0, 1000), showOnline === 'nobody' ? 'nobody' : 'everyone', showProfile === 'nobody' ? 'nobody' : 'everyone', (theme || 'emerald').slice(0, 30), id); const row = db.prepare('SELECT * FROM users WHERE id=?').get(id) as Record<string, unknown>; activity(id, 'ویرایش پروفایل'); res.json({ user: safeUser(row) }); });
app.post('/api/presence', (req, res) => { const id = requireUser(req, res); if (!id) return; presence(id, req.body?.status === 'offline' ? 'offline' : 'online'); res.json({ ok: true }); });
app.get('/api/users', (req, res) => { const id = requireUser(req, res); if (!id) return; const rows = db.prepare("SELECT u.id,u.username,u.first_name,u.last_name,u.role,u.subject,u.bio,u.avatar_url,u.show_online,u.show_profile,COALESCE(p.status,'offline') status FROM users u LEFT JOIN user_presence p ON p.user_id=u.id WHERE u.id != ? ORDER BY CASE u.role WHEN 'teacher' THEN 0 WHEN 'manager' THEN 1 ELSE 2 END, u.id DESC LIMIT 50000").all(id) as Array<Record<string, unknown>>; res.json({ users: rows.map(r => ({ id: r.id, username: r.username, firstName: r.first_name, lastName: r.last_name, role: r.role, subject: r.subject, bio: r.show_profile === 'nobody' ? '' : r.bio, avatarUrl: r.show_profile === 'nobody' ? '' : r.avatar_url, status: r.show_online === 'nobody' ? 'hidden' : r.status })) }); });
app.get('/api/studies', (req, res) => { const id = requireUser(req, res); if (!id) return; res.json({ studies: db.prepare('SELECT * FROM studies WHERE user_id=? ORDER BY created_at DESC').all(id) }); });
app.post('/api/studies', (req, res) => { const id = requireUser(req, res); const { subject, minutes } = req.body as { subject?: string; minutes?: number }; if (!id || !subject || !Number.isInteger(minutes) || minutes < 1 || minutes > 600) { res.status(400).json({ error: 'زمان یا درس نامعتبر است.' }); return; } const result = db.prepare('INSERT INTO studies (user_id,subject,minutes) VALUES (?,?,?)').run(id, subject, minutes); activity(id, 'ثبت زمان مطالعه', subject + ' — ' + minutes + ' دقیقه'); res.status(201).json({ study: db.prepare('SELECT * FROM studies WHERE id=?').get(result.lastInsertRowid) }); });
app.get('/api/warnings', (req, res) => { const id = requireUser(req, res); if (!id) return; res.json({ warnings: db.prepare('SELECT * FROM warnings WHERE user_id=? ORDER BY created_at DESC').all(id) }); });
app.post('/api/warnings/read', (req, res) => { const id = requireUser(req, res); if (!id) return; db.prepare('UPDATE warnings SET read_at=CURRENT_TIMESTAMP WHERE user_id=? AND read_at IS NULL').run(id); res.json({ ok: true }); });
app.get('/api/messages/:otherId', (req, res) => { const id = requireUser(req, res); const other = Number(req.params.otherId); if (!id || !other) { res.status(400).json({ error: 'گفت‌وگو نامعتبر است.' }); return; } res.json({ messages: db.prepare('SELECT * FROM messages WHERE ((sender_id=? AND recipient_id=? AND deleted_by_sender=0) OR (sender_id=? AND recipient_id=? AND deleted_by_recipient=0)) ORDER BY id').all(id, other, other, id) }); });
app.post('/api/messages', (req, res) => { const id = requireUser(req, res); const { recipientId, body, attachmentUrl, attachmentType } = req.body as { recipientId?: number; body?: string; attachmentUrl?: string; attachmentType?: string }; if (!id || !recipientId || (!body?.trim() && !attachmentUrl)) { res.status(400).json({ error: 'پیام خالی است.' }); return; } const result = db.prepare('INSERT INTO messages (sender_id,recipient_id,body,attachment_url,attachment_type) VALUES (?,?,?,?,?)').run(id, recipientId, (body || '').trim().slice(0, 3000), attachmentUrl || null, attachmentType || null); res.status(201).json({ message: db.prepare('SELECT * FROM messages WHERE id=?').get(result.lastInsertRowid) }); });
app.post('/api/upload', upload.single('file'), async (req, res) => { const id = requireUser(req, res); if (!id) return; try { if (!req.file) { res.status(400).json({ error: 'فایلی انتخاب نشده است.' }); return; } const fd = new FormData(); fd.append('file', new Blob([req.file.buffer], { type: req.file.mimetype }), req.file.originalname); const response = await fetch(String(process.env.PLATFORM_SERVICES_URL) + '/storage/upload', { method: 'POST', headers: { Authorization: 'Bearer ' + String(process.env.PLATFORM_SERVICE_TOKEN) }, body: fd }); if (!response.ok) throw new Error('storage status ' + response.status); const stored = await response.json() as { url: string }; activity(id, 'بارگذاری فایل'); res.json(stored); } catch (error) { console.error('upload failed', error); res.status(503).json({ error: 'ارسال فایل موقتاً ممکن نیست؛ سقف هر فایل ۵ مگابایت است.' }); } });
app.get('/api/announcements', (_req, res) => res.json({ announcements: db.prepare('SELECT * FROM announcements ORDER BY id DESC LIMIT 50').all(), assignments: db.prepare('SELECT * FROM assignments ORDER BY id DESC LIMIT 50').all() }));
app.post('/api/admin/login', (req, res) => { if (req.body?.password !== OWNER_PASSWORD) { res.status(401).json({ error: 'رمز مدیریت نادرست است.' }); return; } res.json({ token: issueAdminToken() }); });
app.get('/api/admin/users', (req, res) => { if (!requireAdmin(req, res)) return; res.json({ users: db.prepare("SELECT u.id,u.first_name,u.last_name,u.phone,u.username,u.gender,u.role,u.subject,u.bio,u.avatar_url,u.show_online,u.show_profile,u.created_at,COALESCE(p.status,'offline') status,p.last_seen FROM users u LEFT JOIN user_presence p ON p.user_id=u.id ORDER BY u.id DESC").all() }); });
app.get('/api/admin/activity/:userId', (req, res) => { if (!requireAdmin(req, res)) return; res.json({ activities: db.prepare('SELECT action,detail,created_at FROM user_activity WHERE user_id=? ORDER BY id DESC LIMIT 100').all(Number(req.params.userId)) }); });
app.post('/api/admin/warnings', (req, res) => { if (!requireAdmin(req, res)) return; const { userId: target, body } = req.body as { userId?: number; body?: string }; if (!target || !body?.trim()) { res.status(400).json({ error: 'اطلاعات اخطار کامل نیست.' }); return; } db.prepare('INSERT INTO warnings (user_id,body) VALUES (?,?)').run(target, body.trim()); res.status(201).json({ ok: true }); });
app.post('/api/admin/announcement', (req, res) => { if (!requireAdmin(req, res)) return; const { title, body, mediaUrl, mediaType } = req.body as Record<string, string>; if (!title?.trim() || !body?.trim()) { res.status(400).json({ error: 'عنوان و متن لازم است.' }); return; } db.prepare('INSERT INTO announcements (title,body,media_url,media_type) VALUES (?,?,?,?)').run(title.trim(), body.trim(), mediaUrl || null, mediaType || null); res.status(201).json({ ok: true }); });
app.listen(Number(process.env.PORT || 3001), () => console.log('Focus server ready'));
