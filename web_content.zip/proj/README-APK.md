# ساخت APK اندروید

پیش‌نیاز: Node 22+، Android Studio، JDK 17+

1. سرور را جایی اجرا کن که گوشی به آن دسترسی دارد:
   `npm install` سپس `npm run server` (پورت پیش‌فرض ۳۰۰۱، دیتابیس در server/data)
2. `cp .env.example .env` و آدرس سرور را در VITE_API_URL بنویس
   (اگر http بدون SSL است، در capacitor.config.ts خط server.cleartext را فعال کن)
3. `npm run cap:add` (فقط بار اول)
4. `npm run cap:sync`
5. `npm run cap:open` ← در Android Studio: Build > Build Bundle(s)/APK(s) > Build APK(s)

فایل APK در android/app/build/outputs/apk/debug/ ساخته می‌شود.
برای نصب مستقیم روی گوشی: USB debugging را روشن کن و در Android Studio دکمه Run را بزن.
