# Better Clips v2

## What changed
- Projects created by one user are saved to Firebase Realtime Database and appear for other signed-in users.
- The exact image selected during project creation is saved with that project and shown to everyone. Image selection is tracked separately from video selection.
- Firebase Auth uses `browserLocalPersistence`, so returning users stay signed in on the same browser.
- The login page now tries to sign in first; if the email does not exist, it creates the account.
- The main page requires an authenticated Firebase user.

## Firebase setup required

The code already contains the Firebase project configuration from the original app. To make shared projects work, enable:

1. **Authentication → Sign-in method → Email/Password**.
2. **Realtime Database**.
3. Realtime Database rules that allow authenticated users to read/write projects. A simple starting point is:

```json
{
  "rules": {
    "projects": {
      ".read": "auth != null",
      "$projectId": {
        ".write": "auth != null && ( !data.exists() ? newData.child('ownerUid').val() === auth.uid : ( !newData.exists() ? data.child('ownerUid').val() === auth.uid : (data.child('ownerUid').val() === auth.uid || (newData.child('name').val() === data.child('name').val() && newData.child('type').val() === data.child('type').val() && newData.child('image').val() === data.child('image').val() && newData.child('ownerUid').val() === data.child('ownerUid').val() && newData.child('ownerEmail').val() === data.child('ownerEmail').val() && newData.child('createdAt').val() === data.child('createdAt').val()))) )"
      }
    }
  }
}
```

For a production app, use owner-only write rules so only the project owner can update/delete their project. The UI also only shows the delete button to the owner.

## Important

The current implementation stores compressed project preview images directly in Realtime Database. This is convenient for this small project, but Firebase Storage is a better choice if you expect lots of large images or videos.

Open `index.html` through a web server (for example, VS Code Live Server), rather than using `file://`, so Firebase modules and authentication work reliably.


## New project browsing features
- Clicking a shared project's image or title opens a preview modal before download.
- The preview uses the exact image selected during project creation.
- Each shared project shows the creator's username on the right, with the project type underneath in smaller text.
- Search supports `(username)` to filter results to that creator. It can be combined with normal search text, for example `anime (alex)`.
- Deleting a project removes it from the shared `projects` node, so every connected user receives the deletion through the realtime listener. Firebase rules must be updated using the rules above for owner-only deletion to work.
