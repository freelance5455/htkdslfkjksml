import test from 'node:test';
import assert from 'node:assert/strict';
import { hashPassword, verifyPassword, generateSessionToken, RateLimiter } from './crypto-node';

test('Password hashing and verification with PBKDF2', () => {
  const secret = 'SuperSecret123!';
  const { salt, hash, iterations } = hashPassword(secret);

  assert.ok(salt.length >= 32, 'Salt should be at least 32 chars');
  assert.ok(hash.length >= 64, 'Hash should be at least 64 chars');
  assert.equal(iterations, 100_000, 'Iterations should match 100,000');

  const isValid = verifyPassword(secret, salt, hash, iterations);
  assert.equal(isValid, true, 'Correct password should verify');

  const isInvalid = verifyPassword('WrongPassword', salt, hash, iterations);
  assert.equal(isInvalid, false, 'Wrong password should fail');
});

test('Rate limiter locks out after max attempts', () => {
  const limiter = new RateLimiter(3, 1000, 5000);
  const ip = '192.168.1.1';

  // 1st failure
  let res = limiter.recordFailure(ip);
  assert.equal(res.locked, false);
  assert.equal(res.attemptsLeft, 2);

  // 2nd failure
  res = limiter.recordFailure(ip);
  assert.equal(res.locked, false);
  assert.equal(res.attemptsLeft, 1);

  // 3rd failure - should lock
  res = limiter.recordFailure(ip);
  assert.equal(res.locked, true);
  assert.equal(res.attemptsLeft, 0);

  const status = limiter.isLocked(ip);
  assert.equal(status.locked, true);
  assert.ok(status.remainingSeconds! > 0);

  // Reset
  limiter.reset(ip);
  assert.equal(limiter.isLocked(ip).locked, false);
});

test('Session token generates unique cryptographic strings', () => {
  const token1 = generateSessionToken();
  const token2 = generateSessionToken();
  assert.equal(token1.length, 64);
  assert.notEqual(token1, token2);
});
