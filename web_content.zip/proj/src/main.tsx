import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import Admin from './Admin';
import './index.css';

// در نسخهٔ موبایل، درخواست‌های /api باید به آدرس سرور اصلی بروند.
const API_URL = (import.meta.env.VITE_API_URL as string | undefined)?.replace(/\/$/, '');
if (API_URL) {
  const nativeFetch = window.fetch.bind(window);
  window.fetch = (input: RequestInfo | URL, init?: RequestInit) =>
    typeof input === 'string' && input.startsWith('/api') ? nativeFetch(API_URL + input, init) : nativeFetch(input, init);
}

const root = document.getElementById('root');
if (!root) throw new Error('بخش اصلی برنامه پیدا نشد.');

ReactDOM.createRoot(root).render(
  <React.StrictMode>
    {window.location.pathname === '/admin' ? <Admin /> : <App />}
  </React.StrictMode>,
);
