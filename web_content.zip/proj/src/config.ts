/**
 * Sunucu adresi yapılandırması.
 * - Web (aynı origin): boş bırakılır, göreli istek atılır.
 * - Mobil (Capacitor APK/IPA): derleme sırasında VITE_API_URL verilmelidir
 *   (örn. https://bra.ornek.com). Sonunda "/" olmamalı.
 */
const STORED_KEY = 'bra_server_url';

function normalize(url: string): string {
  return url.trim().replace(/\/+$/, '');
}

export function getServerUrl(): string {
  try {
    const stored = localStorage.getItem(STORED_KEY);
    if (stored) return normalize(stored);
  } catch {
    /* ignore */
  }
  const fromEnv = (import.meta.env.VITE_API_URL as string | undefined) || '';
  return normalize(fromEnv);
}

export function setServerUrl(url: string) {
  localStorage.setItem(STORED_KEY, normalize(url));
}

export function apiUrl(path: string): string {
  return `${getServerUrl()}${path}`;
}

export function wsUrl(token: string): string {
  const base = getServerUrl();
  const q = `/ws?token=${encodeURIComponent(token)}`;
  if (base) {
    return base.replace(/^http/i, 'ws') + q; // http->ws, https->wss
  }
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  return `${protocol}//${window.location.host}${q}`;
}

/** Uygulama Capacitor (native) içinde mi çalışıyor? */
export function isNativeApp(): boolean {
  return !!(window as any).Capacitor?.isNativePlatform?.();
}
