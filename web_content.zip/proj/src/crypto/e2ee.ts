/**
 * Aegis E2EE (End-to-End Encryption) Engine
 * Standard Web Crypto API (ECDH P-256 + HKDF + AES-GCM-256)
 * Real client-side encryption: Plaintexts and raw media never leave the user's browser.
 */

// Helper: Uint8Array to Base64
export function bufferToBase64(buffer: ArrayBuffer | Uint8Array): string {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

// Helper: Base64 to Uint8Array
export function base64ToBuffer(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

export interface KeyPairJwk {
  publicKey: JsonWebKey;
  privateKey: JsonWebKey;
}

export interface EncryptedMessagePayload {
  ciphertext: string; // Base64
  iv: string; // Base64 (12 bytes for AES-GCM)
}

/**
 * Generates an ECDH P-256 key pair on the device
 */
export async function generateDeviceKeyPair(): Promise<KeyPairJwk> {
  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const keyPair = await cryptoObj.subtle.generateKey(
    {
      name: 'ECDH',
      namedCurve: 'P-256',
    },
    true,
    ['deriveKey', 'deriveBits']
  );

  const publicKey = await cryptoObj.subtle.exportKey('jwk', keyPair.publicKey);
  const privateKey = await cryptoObj.subtle.exportKey('jwk', keyPair.privateKey);

  return { publicKey, privateKey };
}

/**
 * Derives a 256-bit AES-GCM shared key from local private key and peer public key using ECDH
 */
export async function deriveSharedSecretKey(
  localPrivateKeyJwk: JsonWebKey,
  peerPublicKeyJwk: JsonWebKey
): Promise<CryptoKey> {
  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;

  const privateKey = await cryptoObj.subtle.importKey(
    'jwk',
    localPrivateKeyJwk,
    { name: 'ECDH', namedCurve: 'P-256' },
    false,
    ['deriveKey', 'deriveBits']
  );

  const publicKey = await cryptoObj.subtle.importKey(
    'jwk',
    peerPublicKeyJwk,
    { name: 'ECDH', namedCurve: 'P-256' },
    false,
    []
  );

  // Derive AES-GCM 256-bit key directly using ECDH
  return await cryptoObj.subtle.deriveKey(
    {
      name: 'ECDH',
      public: publicKey,
    },
    privateKey,
    {
      name: 'AES-GCM',
      length: 256,
    },
    false,
    ['encrypt', 'decrypt']
  );
}

/**
 * Encrypts arbitrary structured object using AES-GCM 256
 */
export async function encryptObject<T>(data: T, sharedKey: CryptoKey): Promise<EncryptedMessagePayload> {
  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const jsonStr = JSON.stringify(data);
  const encoded = new TextEncoder().encode(jsonStr);

  const iv = cryptoObj.getRandomValues(new Uint8Array(12));

  const ciphertextBuffer = await cryptoObj.subtle.encrypt(
    {
      name: 'AES-GCM',
      iv,
    },
    sharedKey,
    encoded
  );

  return {
    ciphertext: bufferToBase64(ciphertextBuffer),
    iv: bufferToBase64(iv),
  };
}

/**
 * Decrypts AES-GCM 256 ciphertext and parses JSON
 */
export async function decryptObject<T>(
  payload: EncryptedMessagePayload,
  sharedKey: CryptoKey
): Promise<T> {
  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const ciphertext = base64ToBuffer(payload.ciphertext);
  const iv = base64ToBuffer(payload.iv);

  const decryptedBuffer = await cryptoObj.subtle.decrypt(
    {
      name: 'AES-GCM',
      iv: iv as unknown as BufferSource,
    },
    sharedKey,
    ciphertext as unknown as BufferSource
  );

  const decodedStr = new TextDecoder().decode(decryptedBuffer);
  return JSON.parse(decodedStr) as T;
}

/**
 * Encrypts raw binary media (voice note, photo, video)
 */
export async function encryptBinary(
  data: ArrayBuffer,
  sharedKey: CryptoKey
): Promise<{ encryptedBuffer: ArrayBuffer; iv: string }> {
  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const iv = cryptoObj.getRandomValues(new Uint8Array(12));

  const encryptedBuffer = await cryptoObj.subtle.encrypt(
    {
      name: 'AES-GCM',
      iv,
    },
    sharedKey,
    data
  );

  return {
    encryptedBuffer,
    iv: bufferToBase64(iv),
  };
}

/**
 * Decrypts raw binary media and creates a Blob
 */
export async function decryptBinary(
  encryptedData: ArrayBuffer,
  ivBase64: string,
  sharedKey: CryptoKey,
  mimeType: string
): Promise<Blob> {
  const cryptoObj = typeof window !== 'undefined' ? window.crypto : globalThis.crypto;
  const iv = base64ToBuffer(ivBase64);

  const decryptedBuffer = await cryptoObj.subtle.decrypt(
    {
      name: 'AES-GCM',
      iv: iv as unknown as BufferSource,
    },
    sharedKey,
    encryptedData as unknown as BufferSource
  );

  return new Blob([decryptedBuffer], { type: mimeType });
}
