import React from 'react';
import { X, Download } from 'lucide-react';

interface MediaLightboxProps {
  media: {
    url: string;
    type: 'image' | 'video';
    name?: string;
  };
  onClose: () => void;
}

export function MediaLightbox({ media, onClose }: MediaLightboxProps) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      {/* Top action bar */}
      <div
        className="absolute top-4 right-4 z-10 flex items-center gap-3"
        onClick={(e) => e.stopPropagation()}
      >
        <a
          href={media.url}
          download={media.name || 'aegis-medya'}
          className="p-2.5 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-200 hover:text-white transition-colors"
          title="İndir"
        >
          <Download className="w-5 h-5" />
        </a>
        <button
          type="button"
          onClick={onClose}
          className="p-2.5 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-200 hover:text-white transition-colors"
          title="Kapat"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Main Preview Container */}
      <div
        className="max-w-[90vw] max-h-[85vh] flex items-center justify-center p-2"
        onClick={(e) => e.stopPropagation()}
      >
        {media.type === 'image' ? (
          <img
            src={media.url}
            alt="Şifreli fotoğraf"
            className="max-w-full max-h-[85vh] object-contain rounded-2xl shadow-2xl"
          />
        ) : (
          <video
            src={media.url}
            controls
            autoPlay
            className="max-w-full max-h-[85vh] object-contain rounded-2xl shadow-2xl"
          />
        )}
      </div>
    </div>
  );
}
