import React, { useRef, useState } from 'react';
import {
  Phone,
  Video,
  ShieldCheck,
  Search,
  Sliders,
  LogOut,
  Shield,
  X,
  Camera,
} from 'lucide-react';
import { UserProfile } from '../types';
import { ProfileModal } from './ProfileModal';

interface ChatHeaderProps {
  currentUser: UserProfile;
  peerUser: UserProfile;
  isPeerTyping: boolean;
  onStartVoiceCall: () => void;
  onStartVideoCall: () => void;
  onOpenSecurityModal: () => void;
  onOpenAdminPanel: () => void;
  onLogout: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  isSearchOpen: boolean;
  onToggleSearch: () => void;
  onUpdateAvatar?: (base64: string) => Promise<void>;
}

export function ChatHeader({
  currentUser,
  peerUser,
  isPeerTyping,
  onStartVoiceCall,
  onStartVideoCall,
  onOpenSecurityModal,
  onOpenAdminPanel,
  onLogout,
  searchQuery,
  onSearchChange,
  isSearchOpen,
  onToggleSearch,
  onUpdateAvatar,
}: ChatHeaderProps) {
  const avatarInputRef = useRef<HTMLInputElement>(null);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);

  const handleAvatarFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !onUpdateAvatar) return;
    const reader = new FileReader();
    reader.onload = async () => {
      if (typeof reader.result === 'string') {
        await onUpdateAvatar(reader.result);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  return (
    <header className="w-full bg-[#111620] border-b border-slate-800/80 px-4 py-3 shrink-0 z-30 transition-all">
      <input
        ref={avatarInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleAvatarFile}
      />
      <div className="flex items-center justify-between gap-3">
        {/* Peer Info */}
        <div className="flex items-center gap-2.5 min-w-0 flex-1 mr-1">
          <div className="relative shrink-0">
            <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-slate-200 shadow-inner overflow-hidden">
              {peerUser.avatar ? (
                <img
                  src={peerUser.avatar}
                  alt={peerUser.username}
                  className="w-full h-full object-cover"
                />
              ) : (
                <span className="text-sm sm:text-base font-bold text-teal-400">
                  {peerUser.username.charAt(0).toUpperCase()}
                </span>
              )}
            </div>
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <h2 className="text-xs sm:text-sm font-bold text-slate-100 truncate">
                {peerUser.displayName || peerUser.username}
              </h2>
              <button
                type="button"
                onClick={onOpenSecurityModal}
                className="inline-flex items-center gap-0.5 px-1 py-0.5 rounded bg-teal-500/15 border border-teal-500/30 text-[10px] font-medium text-teal-300 hover:bg-teal-500/25 transition-colors shrink-0"
                title="E2EE Güvenlik Numarasını Doğrula"
              >
                <ShieldCheck className="w-3 h-3 text-teal-400" />
                <span className="hidden md:inline">E2EE</span>
              </button>
            </div>

            {/* Typing indicator only if typing */}
            {isPeerTyping && (
              <div className="text-[10px] sm:text-xs truncate flex items-center gap-1 mt-0.5">
                <span className="text-teal-400 font-medium animate-pulse flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-teal-400 animate-ping" />
                  yazıyor...
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1 shrink-0">
          {/* Voice Call */}
          <button
            type="button"
            onClick={onStartVoiceCall}
            aria-label="Sesli Arama Başlat"
            className="p-1.5 sm:p-2.5 rounded-xl bg-slate-800/80 hover:bg-teal-500/20 text-slate-300 hover:text-teal-300 transition-all border border-slate-700/60 active:scale-95"
            title="Sesli Arama (WebRTC P2P)"
          >
            <Phone className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          </button>

          {/* Video Call */}
          <button
            type="button"
            onClick={onStartVideoCall}
            aria-label="Görüntülü Arama Başlat"
            className="p-1.5 sm:p-2.5 rounded-xl bg-slate-800/80 hover:bg-teal-500/20 text-slate-300 hover:text-teal-300 transition-all border border-slate-700/60 active:scale-95"
            title="Görüntülü Arama (WebRTC P2P)"
          >
            <Video className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          </button>

          {/* Search Toggle */}
          <button
            type="button"
            onClick={onToggleSearch}
            aria-label="Mesajlarda Ara"
            className={`p-1.5 sm:p-2.5 rounded-xl transition-all border border-slate-700/60 active:scale-95 ${
              isSearchOpen
                ? 'bg-teal-500 text-slate-950 font-bold'
                : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-slate-100'
            }`}
            title="Mesaj Ara"
          >
            <Search className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          </button>

          {/* Security Protocol Modal */}
          <button
            type="button"
            onClick={onOpenSecurityModal}
            aria-label="Güvenlik ve Cihaz Ayarları"
            className="p-1.5 sm:p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-teal-300 transition-all border border-slate-700/60 active:scale-95"
            title="Güvenlik Numarası ve Protokol"
          >
            <Shield className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          </button>

          {/* Admin Panel (ONLY for Golu) */}
          {currentUser.role === 'SUPER_ADMIN' && (
            <button
              type="button"
              onClick={onOpenAdminPanel}
              aria-label="Yönetici Kontrol Paneli"
              className="p-1.5 sm:p-2.5 rounded-xl bg-gradient-to-r from-amber-500/20 to-teal-500/20 hover:from-amber-500/30 hover:to-teal-500/30 text-amber-300 border border-amber-500/40 transition-all active:scale-95"
              title="Yönetici Kontrol Paneli (Golu Özel)"
            >
              <Sliders className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </button>
          )}

          {/* Profile Photo (Changeable) */}
          <button
            type="button"
            onClick={() => setIsProfileModalOpen(true)}
            aria-label="Profil Fotoğrafını Yönet ve Değiştir"
            className="p-1.5 sm:p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-teal-300 transition-all border border-slate-700/60 active:scale-95 cursor-pointer"
            title="Profil Fotoğrafını Değiştir"
          >
            {currentUser.avatar ? (
              <div className="w-4 h-4 sm:w-5 sm:h-5 rounded-full overflow-hidden border border-teal-400">
                <img src={currentUser.avatar} alt="Profil" className="w-full h-full object-cover" />
              </div>
            ) : (
              <div className="w-4 h-4 sm:w-5 sm:h-5 rounded-full bg-teal-500/20 text-teal-300 flex items-center justify-center font-bold text-[10px]">
                {currentUser.username.charAt(0).toUpperCase()}
              </div>
            )}
          </button>

          {/* Logout */}
          <button
            type="button"
            onClick={onLogout}
            aria-label="Güvenli Çıkış Yap"
            className="p-1.5 sm:p-2.5 rounded-xl bg-slate-800/80 hover:bg-red-500/20 text-slate-400 hover:text-red-300 transition-all border border-slate-700/60 active:scale-95"
            title="Çıkış Yap"
          >
            <LogOut className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          </button>
        </div>
      </div>

      {/* Expandable Search Input */}
      {isSearchOpen && (
        <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center gap-2 animate-in slide-in-from-top-2 duration-150">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Şifresi çözülmüş mesajlarda ara..."
              autoFocus
              className="w-full pl-9 pr-8 py-2 bg-[#0c1017] border border-slate-700 rounded-xl text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => onSearchChange('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          <button
            type="button"
            onClick={onToggleSearch}
            className="text-xs text-slate-400 hover:text-slate-200 px-2 py-1.5"
          >
            Kapat
          </button>
        </div>
      )}

      {/* Profile Modal for Changing Profile Picture */}
      {onUpdateAvatar && (
        <ProfileModal
          isOpen={isProfileModalOpen}
          onClose={() => setIsProfileModalOpen(false)}
          currentUser={currentUser}
          onUpdateAvatar={onUpdateAvatar}
        />
      )}
    </header>
  );
}
