import React, { useRef, useEffect, useState } from 'react';
import {
  Check,
  Lock,
  CornerUpLeft,
  Smile,
  Trash2,
  Copy,
  Play,
  Pause,
  Download,
  FileText,
  AlertCircle,
  MoreVertical,
} from 'lucide-react';
import { DecryptedMessage, Username, UserProfile } from '../types';

import chatBg from '../assets/images/user_chat_bg.jpg';

interface MessageListProps {
  messages: DecryptedMessage[];
  currentUser: UserProfile;
  onReply: (msg: DecryptedMessage) => void;
  onToggleReaction: (msgId: string, emoji: string) => void;
  onDeleteMessage: (msgId: string, forEveryone: boolean) => void;
  onOpenMediaLightbox: (url: string, type: 'image' | 'video', name?: string) => void;
  searchQuery?: string;
}

const COMMON_EMOJIS = ['❤️', '👍', '😂', '😮', '😢', '🔥', '🙏'];

export function MessageList({
  messages,
  currentUser,
  onReply,
  onToggleReaction,
  onDeleteMessage,
  onOpenMediaLightbox,
  searchQuery = '',
}: MessageListProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [activeMenuMsgId, setActiveMenuMsgId] = useState<string | null>(null);
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const audioElementsRef = useRef<Map<string, HTMLAudioElement>>(new Map());

  // Scroll to bottom on initial load and new messages
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages.length]);

  // Audio Playback Handler
  const handleToggleAudio = (msgId: string, audioUrl: string) => {
    let audio = audioElementsRef.current.get(msgId);
    if (!audio) {
      audio = new Audio(audioUrl);
      audio.onended = () => setPlayingAudioId(null);
      audioElementsRef.current.set(msgId, audio);
    }

    if (playingAudioId === msgId) {
      audio.pause();
      setPlayingAudioId(null);
    } else {
      // Pause any currently playing audio
      if (playingAudioId) {
        const prev = audioElementsRef.current.get(playingAudioId);
        prev?.pause();
      }
      audio.play().catch(() => {});
      setPlayingAudioId(msgId);
    }
  };

  const copyToClipboard = (text?: string) => {
    if (text) {
      navigator.clipboard.writeText(text);
      setActiveMenuMsgId(null);
    }
  };

  const filteredMessages = messages.filter((m) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      m.text?.toLowerCase().includes(q) ||
      m.mediaName?.toLowerCase().includes(q) ||
      m.sender.toLowerCase().includes(q)
    );
  });

  return (
    <div
      ref={scrollRef}
      className="flex-1 overflow-y-auto p-4 space-y-3 bg-cover bg-center bg-fixed relative"
      style={{ backgroundImage: `url(${chatBg})` }}
      onClick={() => setActiveMenuMsgId(null)}
    >
      <div className="absolute inset-0 bg-[#070a10]/55 pointer-events-none" />

      <div className="relative z-10 space-y-3">
      {filteredMessages.length === 0 && (
        <div className="text-center py-12 text-slate-400 text-xs">
          {searchQuery ? '' : ''}
        </div>
      )}

      {/* Messages */}
      {filteredMessages.map((msg) => {
        const isMe = msg.sender === currentUser.username;
        const isMenuOpen = activeMenuMsgId === msg.id;

        return (
          <div
            key={msg.id}
            id={`message-${msg.id}`}
            className={`group relative flex flex-col ${isMe ? 'items-end' : 'items-start'} transition-all`}
          >
            {/* Sender Name for incoming */}
            {!isMe && (
              <span className="text-[11px] font-semibold text-teal-400/90 ml-3 mb-1">
                {msg.sender}
              </span>
            )}

            {/* Bubble Container */}
            <div
              className={`relative max-w-[85%] sm:max-w-[70%] rounded-2xl p-3 shadow-md transition-all ${
                msg.deletedForEveryone
                  ? 'bg-slate-900/60 border border-slate-800 text-slate-500 italic text-xs'
                  : isMe
                  ? 'bg-teal-600 text-white rounded-br-xs border border-teal-500/30 shadow-teal-950/20'
                  : 'bg-[#18212e] text-slate-100 rounded-bl-xs border border-slate-700/60'
              }`}
            >
              {/* Deleted For Everyone */}
              {msg.deletedForEveryone ? (
                <div className="flex items-center gap-2 text-slate-500 text-xs py-1 px-1">
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Bu mesaj silindi</span>
                </div>
              ) : (
                <>
                  {/* Quoted Reply Preview */}
                  {msg.replyTo && (
                    <div
                      className={`mb-2 p-2 rounded-lg text-xs border-l-2 cursor-pointer ${
                        isMe
                          ? 'bg-teal-700/60 border-white/60 text-teal-100'
                          : 'bg-[#131b26] border-teal-500 text-slate-300'
                      }`}
                      onClick={() => {
                        const target = document.getElementById(`message-${msg.replyTo?.id}`);
                        target?.scrollIntoView({ behavior: 'smooth', block: 'center' });
                      }}
                    >
                      <div className="font-semibold text-[11px] text-teal-300">
                        {msg.replyTo.sender}
                      </div>
                      <div className="truncate text-[11px] opacity-90">{msg.replyTo.textSnippet}</div>
                    </div>
                  )}

                  {/* Media Content */}

                  {/* Photo */}
                  {msg.type === 'image' && msg.mediaUrl && (
                    <div className="mb-2 rounded-xl overflow-hidden cursor-pointer max-h-80 bg-black/40">
                      <img
                        src={msg.mediaUrl}
                        alt="Şifreli fotoğraf"
                        onClick={() => onOpenMediaLightbox(msg.mediaUrl!, 'image', msg.mediaName)}
                        className="w-full h-auto object-cover hover:scale-101 transition-transform max-h-72"
                      />
                    </div>
                  )}

                  {/* Video */}
                  {msg.type === 'video' && msg.mediaUrl && (
                    <div className="mb-2 rounded-xl overflow-hidden max-h-80 bg-black/40">
                      <video
                        src={msg.mediaUrl}
                        controls
                        className="w-full h-auto max-h-72 object-contain"
                      />
                    </div>
                  )}

                  {/* Voice Note Audio */}
                  {msg.type === 'audio' && msg.mediaUrl && (
                    <div
                      className={`flex items-center gap-3 p-2 rounded-xl mb-1 ${
                        isMe ? 'bg-teal-700/50' : 'bg-[#111722]'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => handleToggleAudio(msg.id, msg.mediaUrl!)}
                        className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 shadow-sm transition-all ${
                          isMe
                            ? 'bg-white text-teal-700 hover:bg-slate-100'
                            : 'bg-teal-500 text-slate-950 hover:bg-teal-400'
                        }`}
                      >
                        {playingAudioId === msg.id ? (
                          <Pause className="w-4 h-4" />
                        ) : (
                          <Play className="w-4 h-4 ml-0.5" />
                        )}
                      </button>

                      <div className="flex-1 min-w-32">
                        {/* Audio Waveform Simulation */}
                        <div className="flex items-center gap-0.5 h-6">
                          {[40, 70, 30, 90, 50, 80, 20, 60, 95, 40, 75, 30, 85, 50, 65, 35].map(
                            (h, idx) => (
                              <div
                                key={idx}
                                className={`w-1 rounded-full transition-all duration-200 ${
                                  playingAudioId === msg.id
                                    ? 'bg-teal-300 animate-pulse'
                                    : isMe
                                    ? 'bg-teal-200/50'
                                    : 'bg-slate-500'
                                }`}
                                style={{ height: `${h}%` }}
                              />
                            )
                          )}
                        </div>
                        <div className="text-[10px] mt-0.5 opacity-80 flex justify-between">
                          <span>Sesli Mesaj</span>
                          <span>{msg.audioDuration ? `${msg.audioDuration}s` : 'E2EE Ses'}</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Generic File */}
                  {msg.type === 'file' && (
                    <div
                      className={`flex items-center gap-3 p-2.5 rounded-xl mb-1 ${
                        isMe ? 'bg-teal-700/50' : 'bg-[#111722]'
                      }`}
                    >
                      <div className="w-9 h-9 rounded-lg bg-teal-500/20 flex items-center justify-center text-teal-300 shrink-0">
                        <FileText className="w-5 h-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-medium truncate">{msg.mediaName || 'Belge'}</div>
                        <div className="text-[10px] opacity-75">
                          {msg.mediaSize ? `${(msg.mediaSize / 1024).toFixed(1)} KB` : 'Şifreli dosya'}
                        </div>
                      </div>
                      {msg.mediaUrl && (
                        <a
                          href={msg.mediaUrl}
                          download={msg.mediaName || 'belge.bin'}
                          className="p-1.5 rounded-lg hover:bg-black/20 text-slate-200"
                        >
                          <Download className="w-4 h-4" />
                        </a>
                      )}
                    </div>
                  )}

                  {/* Decrypted Text */}
                  {msg.text && (
                    <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">{msg.text}</p>
                  )}

                  {/* Decryption Error Fallback */}
                  {msg.decryptionError && (
                    <div className="flex items-center gap-2 text-xs text-amber-300 py-1">
                      <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                      <span>Bu mesaj cihaz anahtarı uyuşmazlığı nedeniyle çözülemedi.</span>
                    </div>
                  )}

                  {/* Metadata: Time & Status Ticks */}
                  <div
                    className={`flex items-center justify-end gap-1.5 mt-1 text-[10px] ${
                      isMe ? 'text-teal-100/80' : 'text-slate-400'
                    }`}
                  >
                    <span>
                      {new Date(msg.timestamp).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>

                    {/* Always single tick (Tek Tık) */}
                    {isMe && (
                      <span className="flex items-center text-teal-100/90 ml-0.5">
                        <Check className="w-3.5 h-3.5" />
                      </span>
                    )}
                  </div>
                </>
              )}

              {/* Reactions Badges */}
              {msg.reactions && Object.keys(msg.reactions).length > 0 && (
                <div className="flex flex-wrap gap-1 mt-1.5 -mb-1">
                  {Object.entries(msg.reactions).map(([emoji, users]) => {
                    const hasMyReact = users.includes(currentUser.username);
                    return (
                      <button
                        key={emoji}
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleReaction(msg.id, emoji);
                        }}
                        className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[11px] border shadow-xs transition-all ${
                          hasMyReact
                            ? 'bg-teal-500/30 border-teal-400 text-teal-200'
                            : 'bg-[#101620] border-slate-700 text-slate-300 hover:border-slate-500'
                        }`}
                      >
                        <span>{emoji}</span>
                        <span className="text-[10px] font-semibold">{users.length}</span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Quick Action Trigger Button */}
            {!msg.deletedForEveryone && (
              <div
                className={`absolute top-0 ${
                  isMe ? '-left-8' : '-right-8'
                } opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1`}
              >
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveMenuMsgId(isMenuOpen ? null : msg.id);
                  }}
                  className="p-1 rounded-full bg-slate-800 border border-slate-700 text-slate-300 hover:text-white shadow-md"
                >
                  <MoreVertical className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Action Popup Menu */}
            {isMenuOpen && !msg.deletedForEveryone && (
              <div
                className={`absolute z-40 top-8 ${
                  isMe ? 'right-0' : 'left-0'
                } bg-[#141b25] border border-slate-700 rounded-2xl shadow-2xl p-2 min-w-44 text-xs space-y-1 animate-in fade-in zoom-in-95 duration-150`}
                onClick={(e) => e.stopPropagation()}
              >
                {/* Emoji Bar */}
                <div className="flex items-center justify-around gap-1 pb-2 border-b border-slate-800">
                  {COMMON_EMOJIS.map((emoji) => (
                    <button
                      key={emoji}
                      type="button"
                      onClick={() => {
                        onToggleReaction(msg.id, emoji);
                        setActiveMenuMsgId(null);
                      }}
                      className="text-base hover:scale-125 transition-transform p-1 rounded-md hover:bg-slate-800"
                    >
                      {emoji}
                    </button>
                  ))}
                </div>

                {/* Reply */}
                <button
                  type="button"
                  onClick={() => {
                    onReply(msg);
                    setActiveMenuMsgId(null);
                  }}
                  className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-slate-200 hover:bg-slate-800 text-left"
                >
                  <CornerUpLeft className="w-3.5 h-3.5 text-teal-400" />
                  <span>Yanıtla</span>
                </button>

                {/* Copy text */}
                {msg.text && (
                  <button
                    type="button"
                    onClick={() => copyToClipboard(msg.text)}
                    className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-slate-200 hover:bg-slate-800 text-left"
                  >
                    <Copy className="w-3.5 h-3.5 text-slate-400" />
                    <span>Metni Kopyala</span>
                  </button>
                )}

                {/* Delete for Me */}
                <button
                  type="button"
                  onClick={() => {
                    onDeleteMessage(msg.id, false);
                    setActiveMenuMsgId(null);
                  }}
                  className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-slate-300 hover:bg-slate-800 text-left"
                >
                  <Trash2 className="w-3.5 h-3.5 text-slate-400" />
                  <span>Benden Sil</span>
                </button>

                {/* Delete for Everyone (Sender or Super Admin Golu) */}
                {(isMe || currentUser.role === 'SUPER_ADMIN') && (
                  <button
                    type="button"
                    onClick={() => {
                      onDeleteMessage(msg.id, true);
                      setActiveMenuMsgId(null);
                    }}
                    className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-red-300 hover:bg-red-500/20 text-left"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-red-400" />
                    <span>Herkesten Sil</span>
                  </button>
                )}
              </div>
            )}
          </div>
        );
      })}
      </div>
    </div>
  );
}
