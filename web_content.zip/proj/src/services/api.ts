import { AppSettings } from '../types';
import { apiUrl } from '../config';

const TOKEN_KEY = 'aegis_session_token';

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredToken(token: string) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearStoredToken() {
  localStorage.removeItem(TOKEN_KEY);
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  let response: Response;
  try {
    response = await fetch(apiUrl(endpoint), {
      ...options,
      headers,
    });
  } catch {
    throw new Error('Sunucuya ulaşılamıyor. İnternet bağlantınızı kontrol edin.');
  }

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const err: any = new Error(data.error || `İstek başarısız (${response.status})`);
    if (data.remainingSeconds) err.remainingSeconds = data.remainingSeconds;
    if (response.status === 401 && token) err.unauthorized = true;
    throw err;
  }

  return data as T;
}

export const api = {
  // Auth
  getSetupStatus: () => request<{ isSetupCompleted: boolean }>('/api/auth/setup-status'),
  login: (username: string, password: string) =>
    request<{ token: string; user: any; settings: AppSettings }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    }),
  logout: () => request<{ success: boolean }>('/api/auth/logout', { method: 'POST' }),
  getMe: () => request<{ user: any; peer: any; session: any; settings: AppSettings }>('/api/auth/me'),
  updateProfile: (data: { avatar?: string; displayName?: string }) =>
    request<{ success: boolean; user: any }>('/api/auth/profile', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  // Crypto Keys
  publishPublicKey: (publicKeyJwk: JsonWebKey) =>
    request<{ success: boolean }>('/api/crypto/keys', {
      method: 'POST',
      body: JSON.stringify({ publicKeyJwk }),
    }),
  getPeerPublicKey: (username: string) =>
    request<{ publicKeyJwk: JsonWebKey }>(`/api/crypto/keys/${username}`),

  // Messages
  getMessages: () => request<{ messages: any[] }>('/api/messages'),
  sendMessage: (payload: {
    ciphertext: string;
    iv: string;
    type?: string;
    replyToId?: string;
    mediaId?: string;
    mediaMimeType?: string;
    mediaName?: string;
    mediaSize?: number;
  }) =>
    request<{ message: any }>('/api/messages', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  markAsRead: () => request<{ success: boolean; count: number }>('/api/messages/read', { method: 'POST' }),
  deleteMessage: (id: string, forEveryone: boolean) =>
    request<{ success: boolean }>(`/api/messages/${id}`, {
      method: 'DELETE',
      body: JSON.stringify({ forEveryone }),
    }),
  toggleReaction: (id: string, emoji: string) =>
    request<{ success: boolean; reactions: Record<string, string[]> }>(`/api/messages/${id}/reaction`, {
      method: 'POST',
      body: JSON.stringify({ emoji }),
    }),

  // Media
  uploadEncryptedMedia: (payload: {
    encryptedBase64: string;
    iv: string;
    mimeType: string;
    filename: string;
    size: number;
  }) =>
    request<{ mediaId: string }>('/api/media/upload', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  downloadEncryptedMedia: (mediaId: string) =>
    request<{
      id: string;
      encryptedBase64: string;
      iv: string;
      mimeType: string;
      filename: string;
      size: number;
    }>(`/api/media/${mediaId}`),

  // Admin
  getAdminOverview: () => request<any>('/api/admin/overview'),
  adminResetPassword: (targetUsername: string, newPassword: string) =>
    request<{ success: boolean; message: string }>('/api/admin/users/reset-password', {
      method: 'POST',
      body: JSON.stringify({ targetUsername, newPassword }),
    }),
  adminRevokeSession: (id: string) =>
    request<{ success: boolean }>('/api/admin/sessions/revoke', {
      method: 'POST',
      body: JSON.stringify({ id }),
    }),
  getAdminAuditLogs: () => request<{ logs: any[] }>('/api/admin/audit-logs'),
  updateSettings: (settings: Partial<AppSettings>) =>
    request<{ success: boolean; settings: AppSettings }>('/api/admin/settings', {
      method: 'POST',
      body: JSON.stringify(settings),
    }),
  wipeMessages: () => request<{ success: boolean; wipedCount: number }>('/api/admin/wipe-messages', { method: 'POST' }),
};
