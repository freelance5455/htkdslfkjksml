// `npx cap add android` sonrası çalışır: kamera/mikrofon izinlerini ekler.
import fs from 'node:fs';

const file = 'android/app/src/main/AndroidManifest.xml';
let xml = fs.readFileSync(file, 'utf8');

const perms = [
  'android.permission.INTERNET',
  'android.permission.ACCESS_NETWORK_STATE',
  'android.permission.CAMERA',
  'android.permission.RECORD_AUDIO',
  'android.permission.MODIFY_AUDIO_SETTINGS',
];
const features = [
  '<uses-feature android:name="android.hardware.camera" android:required="false" />',
  '<uses-feature android:name="android.hardware.microphone" android:required="false" />',
];

let add = '';
for (const p of perms) {
  if (!xml.includes(`android:name="${p}"`)) add += `    <uses-permission android:name="${p}" />\n`;
}
for (const f of features) {
  const name = f.match(/android:name="([^"]+)"/)[1];
  if (!xml.includes(`android:name="${name}"`)) add += `    ${f}\n`;
}
if (add) xml = xml.replace('</manifest>', `${add}</manifest>`);
fs.writeFileSync(file, xml);
console.log('Android izinleri eklendi.');
