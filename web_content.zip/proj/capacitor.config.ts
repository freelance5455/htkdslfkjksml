import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'ir.madreseh12farvardin.app',
  appName: 'مدرسه ۱۲ فروردین',
  webDir: 'dist',
  android: { allowMixedContent: true },
  // اگر آدرس سرورت http (بدون SSL) است، خط زیر را فعال کن:
  // server: { cleartext: true },
};

export default config;
