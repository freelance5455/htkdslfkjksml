package id.masjid.jadwalwaktusholat;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/** Membuka Jadwal Waktu Sholat setelah Android selesai boot. */
public class BootReceiver extends BroadcastReceiver {
    private static final String TAG = "JWSBootReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        try {
            Intent launch = new Intent(context, MainActivity.class);
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            context.startActivity(launch);
        } catch (Exception e) {
            Log.e(TAG, "Tidak dapat membuka aplikasi otomatis saat boot", e);
        }
    }
}
