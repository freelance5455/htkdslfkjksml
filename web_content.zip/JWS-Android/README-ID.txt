JADWAL WAKTU SHOLAT — PROYEK ANDROID OFFLINE
===========================================

Target perangkat:
- Android TV / Google TV (tampilan landscape; remote arah dan OK)
- HP Android dan tablet (orientasi mengikuti perangkat)
- Mode otomatis: aplikasi dicoba dibuka setelah TV/Android selesai menyala

FITUR OFFLINE
-------------
- React, ReactDOM, Babel, dan Tailwind disiapkan sebagai aset lokal di www/vendor.
- Tidak menggunakan CDN atau Google Fonts saat aplikasi dijalankan.
- Jadwal sholat dihitung langsung di perangkat memakai kalkulasi lokal yang sudah ada di kode sumber.
- Pengaturan, gambar, logo, dan audio yang diunggah tetap disimpan melalui penyimpanan lokal aplikasi/WebView.
- Tidak perlu internet untuk membuka tampilan utama dan menghitung jadwal.

Batasan mode offline:
- Background YouTube membutuhkan internet. Gunakan gambar background yang diunggah dari perangkat.
- Penyesuaian metode/perhitungan dan koordinat lokasi tetap perlu diperiksa dengan jadwal resmi setempat.
- Aplikasi tidak mengunduh pembaruan jadwal dari server; hasil dihitung lokal. Pastikan koordinat dan zona waktu benar.
- Font memakai font sistem agar dapat berjalan tanpa internet; bentuk font tertentu bisa berbeda dari versi web.

CARA MEMBUAT APK (Windows)
--------------------------
Persiapan satu kali pada komputer pembuat APK:
1. Instal Node.js LTS dan Android Studio (termasuk Android SDK).
2. Ekstrak ZIP, buka Command Prompt/PowerShell pada folder JWS-Android.
3. Jalankan:
     npm install
     npm run prepare:web
     npx cap add android
     npm run build
     npx cap open android
   `npm install` memerlukan internet di komputer pembuat APK untuk mengambil paket. Setelah aset vendor terbentuk, aplikasi hasil APK berjalan offline.

PENGATURAN ANDROID NATIVE
-------------------------
A. MainActivity dan layar selalu menyala
1. Buka android/app/src/main/java/id/masjid/jadwalwaktusholat/.
2. Ganti MainActivity.java dengan file android-config/MainActivity.java.
   File ini menjaga layar tetap menyala ketika aplikasi tampil (berguna untuk TV masjid).

B. Jalankan otomatis setelah perangkat boot
1. Salin android-config/BootReceiver.java ke folder Java yang sama dengan MainActivity.java.
2. Buka android/app/src/main/AndroidManifest.xml.
3. Tambahkan permission berikut sebagai anak langsung <manifest>:
     <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
4. Di dalam <application>, tambahkan receiver:
     <receiver android:name=".BootReceiver" android:enabled="true" android:exported="true">
       <intent-filter>
         <action android:name="android.intent.action.BOOT_COMPLETED" />
       </intent-filter>
     </receiver>
5. Di dalam activity MainActivity yang sudah memiliki MAIN/LAUNCHER, tambahkan intent-filter LEANBACK_LAUNCHER dari android-config/AndroidManifest-snippet.xml.
   Jangan menghapus intent-filter MAIN/LAUNCHER bawaan.

C. Kompatibilitas HP, tablet, dan TV
- Jangan mengunci screenOrientation ke landscape secara global: HP/tablet tetap dapat portrait, sedangkan TV umumnya landscape.
- Pastikan activity utama memiliki android:exported="true" (pada template Capacitor baru biasanya sudah).
- Untuk ikon Android TV yang benar, siapkan banner TV 320x180 px dan deklarasikan android:banner pada activity jika diperlukan.

MEMBUAT APK
-----------
1. Setelah konfigurasi native di atas, jalankan kembali `npm run build`.
2. Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
3. APK debug umumnya berada di android/app/build/outputs/apk/debug/app-debug.apk.
4. Untuk distribusi umum, buat signed APK/AAB melalui Build > Generate Signed Bundle / APK.

CATATAN PENTING AUTO-START
--------------------------
BootReceiver meminta Android membuka aplikasi setelah BOOT_COMPLETED. Beberapa merek TV/Android membatasi peluncuran aplikasi otomatis dari background. Jika perangkat memblokirnya, aktifkan izin Auto-start/Run at startup pada pengaturan TV (jika tersedia) atau atur aplikasi sebagai launcher/home melalui pengaturan perangkat. Perilaku ini wajib diuji pada model TV yang akan digunakan.

PENGUJIAN WAJIB
---------------
- Cabut koneksi internet, restart perangkat, dan pastikan aplikasi tetap terbuka serta jadwal tampil.
- Uji auto-start setelah listrik mati/TV dinyalakan kembali.
- Uji tombol arah, OK/Enter, dan Back pada remote TV.
- Uji portrait/landscape di HP dan tablet.
- Uji audio adzan, unggah MP3/gambar/logo, serta penyimpanan pengaturan setelah aplikasi ditutup.
- Cocokkan jadwal lokal dengan jadwal resmi masjid untuk tanggal dan lokasi yang sama sebelum dipakai operasional.

STATUS PAKET
------------
Ini adalah proyek sumber untuk membangun APK, bukan APK siap instal. Folder android/ dibuat oleh Capacitor di komputer Anda saat `npx cap add android` dijalankan. Aset vendor lokal dibuat oleh `npm run prepare:web`.
