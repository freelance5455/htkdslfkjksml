module.exports = {
  content: ['./www/index.html'],
  theme: {
    extend: {
      fontFamily: {
        alice: ['Georgia', 'serif'],
        cairo: ['Arial', 'sans-serif'],
        roboto: ['Roboto', 'Arial', 'sans-serif'],
        lato: ['Arial', 'sans-serif'],
        amiri: ['Georgia', 'serif']
      }
    }
  },
  plugins: []
};
