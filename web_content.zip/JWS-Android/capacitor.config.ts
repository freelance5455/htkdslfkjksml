import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'id.masjid.jadwalwaktusholat',
  appName: 'Jadwal Waktu Sholat',
  webDir: 'www',
  android: {
    backgroundColor: '#0a0f1e'
  }
};

export default config;
