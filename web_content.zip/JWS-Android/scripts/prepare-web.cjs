const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const root = path.resolve(__dirname, '..');
const vendor = path.join(root, 'www', 'vendor');
fs.mkdirSync(vendor, { recursive: true });
const copies = [
  ['react/umd/react.production.min.js', 'react.production.min.js'],
  ['react-dom/umd/react-dom.production.min.js', 'react-dom.production.min.js'],
  ['@babel/standalone/babel.min.js', 'babel.min.js']
];
for (const [src, dest] of copies) {
  const from = path.join(root, 'node_modules', src);
  if (!fs.existsSync(from)) throw new Error(`Dependensi tidak ditemukan: ${src}. Jalankan npm install terlebih dahulu.`);
  fs.copyFileSync(from, path.join(vendor, dest));
}
execFileSync(process.execPath, [
  path.join(root, 'node_modules', 'tailwindcss', 'lib', 'cli.js'),
  '-c', path.join(root, 'tailwind.config.cjs'),
  '-i', path.join(root, 'src', 'tailwind.css'),
  '-o', path.join(vendor, 'tailwind.css'),
  '--minify'
], { stdio: 'inherit', cwd: root });
console.log('Aset web lokal siap: React, ReactDOM, Babel, dan Tailwind CSS.');
