# Zeyd's Ultimate App

This is a functional, installable Progressive Web App (PWA), not a screenshot or static mockup.

## Run it
Serve this folder from an HTTPS static host (or localhost for testing), then open the site in Chrome on Android. Use Chrome menu -> Add to Home screen / Install app.

## Working features
- Three playable mini-games: Tic-Tac-Toe vs phone, 10-second Tap Challenge, Memory Match
- Gaming directory with official Nintendo and PlayStation links
- Favourite football team saved locally and player notebook
- Private local social feed with posts, likes and delete
- AI prompt builder, with links to ChatGPT and Gemini
- Music and video search shortcuts
- Local notes and focus timer
- Offline app shell via service worker after first successful load

## Honest limitations
- Social posts, notes, team and player data are stored only in the browser on this device. They are not a public/online social network.
- The AI section builds prompts and opens an AI service; it does not include a private AI model or API server.
- Music/video playback and availability are handled by the linked services.
- Nintendo Switch and PS5 games cannot be run inside this Android web app. The app links to official game hubs.
- A public multi-user social network, real-time online multiplayer, synced accounts, live scores API, and native Android APK require external backend/services and/or a separate Android build.
