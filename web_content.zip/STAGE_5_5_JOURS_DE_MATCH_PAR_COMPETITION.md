# CGD — Étape 5.5 : un jour de match par compétition

## Règle validée
Chaque compétition de la saison a son propre jour de match, et aucune compétition n'en chevauche une autre. Les matchs ont lieu du mardi au dimanche ; le lundi est réservé à d'autres activités (aucun match).

| Jour | Compétition | Autorité |
|---|---|---|
| Mardi | Champions League | FGD |
| Mercredi | Coupe Galactique (semaines des journées 6, 12 et 18) | FGD |
| Jeudi | Coupe des Clubs (jeudis lunaires officiels) | FGD |
| Samedi | Championnats (22 journées) | FGD |
| Dimanche | Coupe Fédéral | AGD |

Les compétitions AGD (Intergalactique des Clubs, Coupe Intergalactique, Coupe Lunaire) gardent leurs fenêtres officielles propres, en dehors de la saison régulière.

## Changements
- `src/competition-calendar.js` : table `COMPETITION_MATCH_DAYS`, Coupe Galactique au mercredi, créneaux du mardi (Champions League) et du dimanche (Coupe Fédéral), contrôle « jamais deux événements le même jour » au lieu de l'ancien intervalle d'une journée complète.
- `src/config.js` : la Coupe Fédéral est organisée par l'AGD.
- Un tour déjà programmé sur un autre jour est replacé au jour de sa compétition, sauf s'il a déjà été joué.

## À traiter plus tard
Mardi, mercredi et jeudi se suivent : le repos des clubs entre deux matchs n'est plus imposé par le calendrier central et devra être géré club par club.

## Vérification
`npm test` : tests existants adaptés aux nouveaux jours, plus `tests/match-days.test.js`.
