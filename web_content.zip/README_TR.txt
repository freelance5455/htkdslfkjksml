PUBG MOBILE GLOBAL 4.6 — A51 Skin Menu Demo
================================================

Bu ZIP, Samsung Galaxy A51 için hazırlanmış bağımsız bir skin menüsü DEMOSUDUR.
Gerçek PUBG Mobile Global istemcisine bağlanmaz ve kilitli skinleri hesabında açmaz.
Görseller/skin isimleri örnek arayüz içeriğidir; oyun dosyası veya resmi PUBG aracı değildir.

Dosyalar:
- index.html: Android tarayıcısında açılabilen skin menüsü demosu
- config/skin_catalog.json: Demo katalog örnekleri
- config/device_profile.json: A51 için genel performans notları
- KURULUM.txt: Kurulum talimatları

Kurulum:
1. ZIP'i Android'de Dosyalar uygulamasıyla çıkar.
2. index.html dosyasına dokun ve Chrome gibi bir tarayıcıda aç.
3. Menüde X-Suit, silah skinleri, desenler ve kaplamalar arasında gezin.
4. Bu demo seçimleri yalnızca arayüzde görünür; PUBG hesabını veya oyunu değiştirmez.

Güvenlik:
- Oyun hesabı şifreni hiçbir demo dosyasına girme.
- Bilinmeyen APK yükleme veya PUBG dosyalarını değiştirme.
