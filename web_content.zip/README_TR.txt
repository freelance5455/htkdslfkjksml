Türkçe Roblox — Kayıp Şehir: Kabusun Başlangıcı

Bu güncelleme, mevcut Hayalet Avcıları sürümüne ayrı bir “Kayıp Şehir — Kabusun Başlangıcı” modu ekler. Arkadaşlar ekranı ve diğer oyun kartları korunmuştur. DORS / 150 Kapı modu yeni ana ekrana eklenmemiştir.

Bölüm 1 oynanabilir: terk edilmiş şehir sokakları, hastane alanı, metro ve yeraltı tesisi; fener; üç güç hücresi; elektrik panoları; saklanma noktaları; oyuncuyu arayıp kovalayan büyük gölge yaratık ve çıkış görevi. Bölüm 2 menüde kilitli olarak gösterilir ve henüz oynanamaz.

Açma: ZIP'i tamamen çıkarın ve assets/web/index.html dosyasını Chrome'da açın. Three.js CDN dosyası için internet gerekir. Android'de yatay ekran ve dokunmatik hareket / zıplama / etkileşim kontrolleri kullanılır.

Bu bir web oyun paketi, APK değildir. JavaScript sözdizimi ve ZIP bütünlüğü kontrol edilmiştir; gerçek telefonda kapsamlı oynanış testi yapılmamıştır. Arkadaşlarla çevrimiçi oynama mevcut sunucu yapılandırmasına bağlıdır.
