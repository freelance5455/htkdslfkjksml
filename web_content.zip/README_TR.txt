JARVIS HTML APK Builder paketi

1) ZIP dosyasını HTML APK Builder - ZIP APK uygulamasına aktar.
2) Uygulama ana HTML dosyası sorarsa index.html dosyasını seç.
3) Uygulama izinleri bölümünden mikrofon iznini etkinleştir (uygulama destekliyorsa).
4) APK oluştur ve kendi telefonunda/tabletinde test et.

Bu paket tek dosyalı HTML arayüzüdür. Yerel olarak çalışanlar:
- Profesyonel, mobil uyumlu JARVIS paneli
- Sohbet arşivi (localStorage)
- Görev listesi
- Yerel saat/tarih ve temel komutlar
- Tarayıcı/Android destekliyorsa sesli giriş ve sesli cevap
- Seçilen dosyaları listeleme
- Yazdırma menüsü üzerinden PDF kaydetme

Henüz bağlı olmayanlar:
- Genel amaçlı yapay zekâ modeli
- Gerçek çevrimdışı LLM
- Android dosya sisteminin tamamına erişim
- MyT Müzik uygulamasını açıp şarkı seçme/kontrol
- Bluetooth cihazını programatik bağlama
- Ekran kapalıyken sürekli JARVIS uyandırma

Bunlar yalnızca HTML ile garanti edilemez; APK Builder'ın Android köprü/izin desteği ve/veya ayrı bir güvenli AI sunucusu gerekir.
