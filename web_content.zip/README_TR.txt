FIXSIS 2.1 — ANDROID PROJESI

Bu klasör, FixSis uygulamasının Android WebView kaynak projesidir.

APK OLUSTURMA
1. Android Studio'da bu klasörü açın.
2. Gradle senkronizasyonunu bekleyin.
3. Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.
4. APK, app/build/outputs/apk/debug/app-debug.apk konumunda oluşur.

NOTLAR
- Proje Android Studio/Gradle ile derlenmek üzere hazırlanmıştır; bu çalışma ortamında Android SDK/Gradle bulunmadığı için APK derlemesi ve gerçek cihaz testi yapılamadı.
- Firebase, Tailwind ve yazı tipleri internet bağlantısı gerektirir.
- Firestore kuralları firestore.rules dosyasındadır; Firebase Console'da yayımlanmalıdır.
- Lisans ve kurucu rolü istemci tarafındaki HTML/JavaScript'te tutulduğu için üretim güvenliği sağlamaz. Gerçek yetkilendirme Firebase Authentication ve Cloud Functions gibi sunucu tarafı kontrollerle tamamlanmalıdır.
- Firebase anonim UID tabanlı depolama nedeniyle farklı cihazlar aynı sipariş listesini otomatik paylaşmaz.
- Android WebView dosya seçicisi JSON yedeğini içe aktarmak için eklenmiştir.


Sipariş yönetimi: Sipariş kartındaki Düzenle seçeneğiyle ürünleri, ölçüleri, adetleri, fiyatı, durumu, ödeme bilgisini, telefon/adres ve notu değiştirebilirsiniz. Sil seçeneği siparişi kalıcı olarak silmez; Siparişler > Silinenler bölümüne taşır. Buradan Geri Yükle ile tekrar aktif siparişlere alabilirsiniz.


SÜRÜM 2.4 - ARAMA EKRANI
- Ayarlar > Arama Bilgileri bölümünden FixSis varsayılan telefon uygulaması yapılabilir.
- Android'in varsayılan arama uygulaması rolü istenir; kullanıcı onayı olmadan değişmez.
- Gelen/giden aramada kayıtlı numara eşleşirse ad, adres, siparişler ve veresiye toplamı yerel arama ekranında gösterilir.
- Müşteri/sipariş dizini, uygulamadaki yerel kayıtlardan Android SharedPreferences alanına aktarılır.
- Varsayılan uygulamayı geri almak için Android Ayarlar > Uygulamalar > Varsayılan uygulamalar > Telefon bölümünden başka uygulama seçilebilir.
- Arama ekranı ve varsayılan arama rolü cihaz/Android sürümüne göre test edilmelidir.

ACIL AÇILIŞ YOLU DÜZELTMESİ
Bazı APK oluşturucular WebView içinde https://appassets.androidplatform.net/web/index.html yolunu kullanır.
Bu nedenle aynı uygulama dosyası app/src/main/assets/web/index.html konumuna da eklenmiştir.
Android Studio projesindeki mevcut MainActivity ise android_asset/index.html yolunu kullanmaya devam eder.
