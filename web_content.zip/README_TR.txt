# Akşam Nereye Gidelim? – Ankara v30

Bu paket, önceki 595 kayıtlı rehberin Çankaya ilçesi odaklı tarama ile güncellenmiş sürümüdür.

- Yeni kayıtlar: Çankaya mahalleleri ve semtleri (Kızılay, Tunalı/Kavaklıdere, Ayrancı, Dikmen, Öveçler, Çukurambar, Çayyolu, Ümitköy, Yaşamkent, Ahlatlıbel ve Yıldız).
- Kaynaklar farklı dizinler ve işletme/kurum sayfalarıdır; puan ve yorum sayıları yalnızca bulunduğu kayıtlarda gösterilir.
- Dizin kayıtları işletmenin bugün açık olduğunu garanti etmez; gitmeden önce işletme bilgilerini kontrol edin.
- Bazı yeni kayıtların puanı/adresi kaynakta net olmadığından boş bırakılmıştır.

HTML dosyasını tarayıcıda açın.
