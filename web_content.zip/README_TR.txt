REHBER PRO – APK DÖNÜŞÜM PAKETİ

İÇERİK
- www/index.html : Yüklediğiniz güncel HTML dosyası (uygulama kodu korunmuştur)
- app-icon.png   : Android uygulama simgesi
- www/icon-192.png ve www/icon-512.png : Web/PWA simge boyutları

TELEFONDAN APK OLUŞTURMA
1. ZIP dosyasını telefonunuza indirin ve çıkartın.
2. Kullandığınız HTML-to-APK / WebView APK oluşturucuda index.html dosyasını
   başlangıç sayfası (Start URL / Local HTML) olarak seçin.
3. Uygulama adı: Rehber Pro
4. Paket adı: com.rehberpro.app
5. Sürüm: 1.0.0 (versionCode: 1)
6. Uygulama simgesi olarak app-icon.png dosyasını seçin.
7. Aşağıdaki WebView seçeneklerini etkinleştirin:
   - JavaScript: AÇIK
   - DOM Storage / Local Storage: AÇIK
   - Dosya yükleme / File chooser: AÇIK (JSON yedekten geri yükleme ve CSV aktarımı için)
   - Harici bağlantılar: telefon (tel:) ve WhatsApp (https://wa.me/) bağlantılarını
     cihazdaki ilgili uygulamada açacak şekilde etkinleştirin.
   - İnternet erişimi: AÇIK (Google Fonts ve WhatsApp bağlantısı için)
8. APK'yı oluşturun, imzalayın ve Android'e kurun.

ÖNEMLİ
- Bu ZIP, APK oluşturucuya verilecek hazırlanmış kaynak paketidir; derlenmiş/imzalanmış APK değildir.
- HTML içindeki IndexedDB ve localStorage verileri WebView uygulamasının kendi depolamasında tutulur.
  Tarayıcıdaki mevcut rehber kayıtları otomatik olarak APK'ya taşınmaz.
- APK'yı ilk açtığınızda PIN oluşturmanız gerekebilir. Eski verileri taşımak için HTML uygulamasından
  JSON yedeği alın ve APK içinden "Yedekten Geri Yükle" seçeneğini kullanın.
- Uygulama verilerini temizlemek veya uygulamayı kaldırmak kayıtları silebilir; düzenli JSON yedeği alın.
- Uygulama çevrimdışı açılabilir; ancak Google Fonts internet bağlantısı olmadığında yüklenmeyebilir.
