import os, json, re
from pathlib import Path
from flask import Flask, request, jsonify, send_from_directory
from dotenv import load_dotenv
import requests

BASE=Path(__file__).resolve().parent
load_dotenv(BASE/'.env')
app=Flask(__name__,static_folder=None)

@app.get('/')
def home(): return send_from_directory(BASE,'index.html')
@app.get('/assets/<path:name>')
def assets(name): return send_from_directory(BASE/'assets',name)
@app.get('/api/health')
def health(): return jsonify({'app':'NOVA ULTIMATE AI','status':'online'})

@app.post('/api/settings')
def settings():
    d=request.get_json(silent=True) or {}
    values={'NOVA_BRAIN_KEY':d.get('brain_key',''),'NOVA_BRAIN_PROVIDER':d.get('brain_provider','openai'),
            'NOVA_IMAGE_KEY':d.get('image_key',''),'NOVA_VIDEO_KEY':d.get('video_key',''),'NOVA_AUDIO_KEY':d.get('audio_key','')}
    env=BASE/'.env'; current={}
    if env.exists():
        for line in env.read_text(encoding='utf-8').splitlines():
            if '=' in line and not line.lstrip().startswith('#'):
                k,v=line.split('=',1); current[k]=v
    current.update({k:str(v).replace('\\n','') for k,v in values.items()})
    env.write_text('\\n'.join(f'{k}={v}' for k,v in current.items())+'\\n',encoding='utf-8')
    os.environ.update(current)
    return jsonify({'message':'Clés enregistrées côté serveur. Elles ne sont pas renvoyées au navigateur.'})

def ask(message):
    key=os.getenv('NOVA_BRAIN_KEY','')
    if not key: raise ValueError('Ajoute la clé du cerveau dans Réglages.')
    if os.getenv('NOVA_BRAIN_PROVIDER','openai')=='gemini':
        url=f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={key}"
        r=requests.post(url,json={'contents':[{'parts':[{'text':message}]}]},timeout=90)
        if not r.ok: raise RuntimeError(f'Gemini HTTP {r.status_code}: {r.text[:250]}')
        return r.json()['candidates'][0]['content']['parts'][0]['text']
    r=requests.post('https://api.openai.com/v1/chat/completions',headers={'Authorization':f'Bearer {key}'},
        json={'model':'gpt-4o-mini','messages':[{'role':'user','content':message}]},timeout=90)
    if not r.ok: raise RuntimeError(f'OpenAI HTTP {r.status_code}: {r.text[:250]}')
    return r.json()['choices'][0]['message']['content']

@app.post('/api/chat')
def chat():
    d=request.get_json(silent=True) or {}
    try: return jsonify({'reply':ask((d.get('message') or '').strip())})
    except Exception as e: return jsonify({'error':str(e)}),502

@app.post('/api/chapter')
def chapter():
    d=request.get_json(silent=True) or {}
    prompt=(d.get('prompt') or '').strip()
    if not prompt: return jsonify({'error':'Prompt vide.'}),400
    n=18 if '18' in d.get('length','') else 8 if '8' in d.get('length','') else 12
    instruction=f"""Tu es scénariste et directeur artistique de manga/manhwa. Crée un chapitre ORIGINAL en français basé sur cette idée: {prompt}
Format: {d.get('format','Manga')}. Style visuel: {d.get('style','anime détaillé')}. Prévois exactement {n} scènes.
Retourne UNIQUEMENT un objet JSON valide de la forme:
{{"title":"...","summary":"...","scenes":[{{"heading":"...","description":"description visuelle précise de la scène et de l'action","dialogue":"dialogues courts et expressifs","image_prompt":"prompt d'illustration autonome décrivant les personnages, décor, cadrage et ambiance"}}]}}
Assure la cohérence des personnages, une progression dramatique, un début accrocheur et une fin qui donne envie de lire la suite. Pas de personnages ou univers protégés copiés."""
    try:
        raw=ask(instruction)
        match=re.search(r'\\{.*\\}',raw,re.S)
        if not match: raise ValueError('Le modèle n’a pas retourné de JSON exploitable. Réessaie.')
        data=json.loads(match.group(0))
        if not isinstance(data.get('scenes'),list): raise ValueError('Structure de chapitre incorrecte.')
        return jsonify({'chapter':data})
    except Exception as e: return jsonify({'error':str(e)}),502

@app.post('/api/video/prepare')
def video_prepare():
    d=request.get_json(silent=True) or {}
    # Creates a production brief. Actual MP4 rendering requires a configured video provider or FFmpeg pipeline.
    chapter=d.get('chapter') or {}
    brief={'title':d.get('title') or chapter.get('title','NOVA Episode'),'ratio':d.get('ratio','16:9'),
           'narration':d.get('narration',''),'chapter':chapter,
           'note':'Projet vidéo préparé. Pour produire un MP4, configure un fournisseur vidéo ou un moteur FFmpeg côté serveur.'}
    out=BASE/'exports'; out.mkdir(exist_ok=True)
    path=out/'video-production-brief.json'; path.write_text(json.dumps(brief,ensure_ascii=False,indent=2),encoding='utf-8')
    return jsonify({'message':'Dossier de production préparé. Le rendu MP4 nécessite encore le moteur vidéo choisi.','download_url':'/exports/video-production-brief.json'})
@app.get('/exports/<path:name>')
def export_file(name): return send_from_directory(BASE/'exports',name,as_attachment=True)

@app.post('/api/test')
def test():
    try: return jsonify({'message':'Connexion testée : '+ask('Réponds uniquement NOVA OK')[:80]})
    except Exception as e: return jsonify({'error':str(e)}),502

if __name__=='__main__': app.run(host='0.0.0.0',port=int(os.getenv('PORT','8000')))
