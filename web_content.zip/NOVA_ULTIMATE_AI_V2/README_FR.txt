NOVA ULTIMATE AI — CREATOR STUDIO V2

Ce projet améliore l'interface NOVA avec un fond spatial, une page d'accueil immersive et un créateur de chapitres manga/manhwa/webtoon/anime à partir d'un prompt.

FONCTIONS INCLUSES
- Accueil mobile avec fond d'écran spatial.
- Cerveau conversationnel via OpenAI compatible ou Gemini.
- Génération d'un chapitre structuré en scènes, descriptions, dialogues et prompts d'illustration.
- Export du chapitre au format JSON.
- Préparation d'un dossier de production vidéo.
- Quatre champs de clés : cerveau, images, vidéo, audio/musique.

LIMITES HONNÊTES
- La génération du chapitre fonctionne via la clé du cerveau configurée.
- Les images des cases ne sont pas automatiquement générées dans cette version : il faut connecter un fournisseur d'images et développer l'adaptateur correspondant.
- Le bouton vidéo prépare un brief de production, pas un fichier MP4 final. Un fournisseur vidéo ou une chaîne de rendu FFmpeg doit être configuré.
- La publication directe YouTube n'est pas activée. Elle exige une application Google Cloud, OAuth 2.0 et l'autorisation explicite du compte. En attendant, exporter le MP4 puis l'importer dans YouTube Studio.
- Un convertisseur ZIP-vers-APK statique peut afficher l'interface mais ne lance pas le serveur Python.

INSTALLATION SERVEUR
1. Installer Python 3.
2. pip install -r requirements.txt
3. Copier .env.example vers .env.
4. Lancer python server.py
5. Ouvrir http://localhost:8000

DÉPLOIEMENT RENDER
Build command: pip install -r requirements.txt
Start command: gunicorn server:app
Déployer le dossier du projet. Configurer HTTPS et ne jamais committer .env.

SÉCURITÉ
Ne publie jamais tes clés dans le ZIP, HTML, GitHub public ou une capture d'écran. Saisis-les uniquement dans ton serveur privé. Si une clé a été exposée, révoque-la et recrée-la.
