LastTime Web MVP

افتح index.html في المتصفح أو ارفع المجلد/ZIP إلى خدمة HTML-to-APK.
البيانات محفوظة محلياً في الجهاز عبر localStorage.
