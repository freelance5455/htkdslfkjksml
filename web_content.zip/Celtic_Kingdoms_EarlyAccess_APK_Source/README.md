# Celtic Kingdoms — Early Access APK Source

Eigenständige, originale Mobile-Strategie-Spielbasis für den HTML-to-APK-Builder.

## Enthaltene Kernsysteme
- Hochformat-Mobile-UI
- Dorf und Gebäudeausbau
- harte Lagerkapazitäten
- Ressourcenproduktion
- Bauwarteschlange mit Live-Fortschritt und Restzeit
- Rekrutierungswarteschlange mit Live-Fortschritt und Restzeit
- Forschung mit Live-Fortschritt und Restzeit
- Einheiten-Detailfenster
- 15x15 Weltkarte mit Gelände und POIs
- anklickbare Kartenfelder, dauerhaft geöffnete Dialoge
- Angriff und Kampfbericht
- Spieler- und Dorfname änderbar
- lokaler Spielstand

## APK
Im HTML-to-APK-Builder als „Gezippte Website“ importieren und `index.html` als Startseite verwenden.

Hinweis: Das ist die aktuelle Early-Access-Spielbasis. Ein echter persistenter Multiplayer-Server, Accounts und serverseitige Kämpfe benötigen zusätzlich ein Backend und werden nicht durch das Verpacken einer HTML-Datei erzeugt.


## v0.3 Mehrdorf-/Reich-UI
- Jedes Dorf besitzt eigene Ressourcen, Gebäude, Truppen und Warteschlangen.
- Oben kann zwischen Dörfern gewechselt werden.
- Reich-Ansicht zeigt alle Dörfer und aggregierte Ressourcen/Truppen.
- Neue Dörfer können für UI-/Testzwecke aufgenommen werden; die Struktur ist für spätere Eroberungen vorbereitet.


## v0.4 – Stammesfunktion aktiviert
- Stamm gründen mit Name und Kürzel
- Mitgliederliste und Ränge
- Einladungen (lokaler Early-Access-Datensatz)
- Stammeschat (lokal)
- Diplomatie: Neutral / NAP / Bündnis / Krieg
- Stammeslager mit Einzahlungen
- Kriegsrat und Kriegspunkte
- Stammespunkte und Grundstatistik

Hinweis: Echte Spieler-übergreifende Online-Synchronisierung benötigt später ein Backend. Die UI und Datenstruktur sind dafür vorbereitet.


Version 0.8: Stammesansicht tatsächlich aktiviert; kein „Online-Backend aktiviert“-Platzhalter mehr im Stamm-Menü. Lokale Stammesverwaltung, Mitglieder, Diplomatie, Stammeslager, Kriegsrat und Chat sind testbar.
