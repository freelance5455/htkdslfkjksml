# Celtic Kingdoms — Early Access Visual Build

Diese ZIP ist die aktuelle Web-App-Quelle für den HTML-to-APK-Builder.

## Enthalten
- hochwertigeres Celtic-Fantasy UI mit dunklem Wald-/Bronze-Stil
- hochauflösende Gebäude- und Einheiten-Artworks
- detaillierte Einheitenkarten und Rekrutierungsansichten
- atmosphärische Weltkarten- und Szenen-Assets
- 25×25 Weltkarte
- Bau-, Rekrutierungs-, Forschungs- und Marschzeiten mit Live-Fortschrittsbalken
- harte Lagerkapazitäten
- lokale Speicherung

## APK-Erstellung
Im HTML-to-APK-Builder **„Gezippte Website“** auswählen und diese ZIP verwenden.

## Hinweis
Die Asset-Größe wurde bewusst durch echte visuelle Spielinhalte erhöht. Sie ist kein künstlicher Platzhalter. Online-Accounts, Serverwelt und serverseitige Kämpfe benötigen später ein Backend und können nicht allein durch einen HTML-to-APK-Wrapper entstehen.
