# Celtic Kingdoms — Early Access APK Source

Diese ZIP ist für einen HTML-to-APK-Builder gedacht. Öffne/importiere die ZIP als "gezippte Website".
Die Startdatei ist `index.html`.

Die Version enthält ein spielbares Early-Access-Grundgerüst: Dorf, Wirtschaft mit harten Lagerlimits, Gebäudeausbau, Einheiten/Rekrutierung, Forschung, Weltkarte, Marsch/Kampf, Berichte, Namen, Stamm-/Diplomatie-Grundsystem, Quests und lokale Speicherung.

Hinweis: Online-Account, echte serverseitige Persistenz und Multiplayer benötigen später ein Backend. Das Frontend ist dafür strukturiert, läuft aber in dieser APK zunächst lokal.
