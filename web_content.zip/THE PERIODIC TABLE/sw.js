/* Offline cache. Online: always fetch the newest files (falls back to cache after 3s or when offline). */
const C="periodic-table-v7",FILES=["./","./index.html","./manifest.webmanifest","./icon-192.png","./icon-512.png","./icon-180.png","./icon-32.png"];
self.addEventListener("install",e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting()))});
self.addEventListener("activate",e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener("fetch",e=>{
 const r=e.request;
 if(r.method!=="GET"||new URL(r.url).origin!==location.origin)return;
 e.respondWith(caches.open(C).then(c=>{
  const net=fetch(r).then(res=>{if(res&&res.ok)c.put(r,res.clone());return res});
  const cached=()=>c.match(r,{ignoreSearch:true}).then(m=>m||c.match("./index.html"));
  return Promise.race([net,new Promise((_,rej)=>setTimeout(rej,3000))]).catch(()=>cached().then(m=>m||net));
 }));
});
