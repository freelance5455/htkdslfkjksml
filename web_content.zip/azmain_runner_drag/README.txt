AZMAIN RUNNER — DRAG CONTROL
============================
নতুন কন্ট্রোল সিস্টেম:
- কোনো Left/Right button নেই।
- গেমের screen-এর উপর আঙুল রাখো।
- আঙুল ডানে drag করলে গাড়ি ডানে যাবে।
- আঙুল বামে drag করলে গাড়ি বামে যাবে।
- গাড়ি রাস্তার সীমার বাইরে যেতে পারবে না।

Preview: ZIP extract করে index.html Chrome-এ খুলো।
