/* ==========================================================================
   fonctionenligne.js — Machine complète Version En Ligne, Création/Reprise
   Multi-Téléphones & Pont Firebase Temps Réel — Trading Commerce
   ========================================================================== */
(function (global) {
  "use strict";

  const CFG = {
    projectId: "trading-commerce",
    apiKey: "AIzaSyAPEnpD8hfQNBZT1wpjSEh9E_OXsjsNiAU",
    collection: "comptes_trading_commerce",

    pageConnexion: "connexion-en-ligne.html",
    pageVersionEnLigne: "version-en-ligne.html",
    pageAccueilEnLigne: "espace-accueil-en-ligne.html",
    pageProfilEnLigne: "profil-en-ligne.html",
    pageHorsLigne: "index.html",

    cleConnecteLocal: "tc_connecte_en_ligne",
    cleConnecteApp: "tc_est_connecte",
    cleSessionActive: "tc_session_profil_en_ligne",
    cleSessionPermanente: "tc_session_permanente_en_ligne",
    cleSessionSecours: "tc_session_secours_reseau",
    cleDernierEmail: "tc_dernier_email_en_ligne",
    cleUserEmail: "tc_user_email",
    cleComptesGoogleConnus: "tc_comptes_google_appareil_v1",
    cleQueueOffline: "tc_queue_hors_ligne_firebase_v1",
    cleModeCreation: "tc_mode_creation_compte_v1",

    idEcranBlocage: "tc-ecran-blocage",
    idTexteBlocage: "tc-texte-blocage",
    idBoutonConnexion: "tc-btn-retour-connexion",
    idBoutonHorsLigne: "tc-btn-passer-hors-ligne",
    idBoutonVerifier: "tc-btn-verifier-connexion",
    idModalGoogle: "tc-google-picker-modal",
    idBlocCreationRapide: "tc-bloc-creation-compte-en-ligne",

    intervalleVerificationMs: 3500
  };

  /* ------------------------------------------------------------------------
     0. RÉSOLUTION DE CHEMIN & DÉTECTION DE FICHIER
     ------------------------------------------------------------------------ */
  function resoudreCheminFichier(nomFichierCible) {
    try {
      const loc = global.location;
      if (!loc) return nomFichierCible;
      return String(nomFichierCible || "").replace(/^\/+/, "");
    } catch (_) {
      return nomFichierCible;
    }
  }

  function obtenirNomFichierActuel() {
    const cheminActuel = ((global.location && global.location.pathname) || "").toLowerCase();
    return (cheminActuel.split("/").pop() || "index.html").toLowerCase();
  }

  function naviguerVers(nomFichier, remplacer) {
    const cible = resoudreCheminFichier(nomFichier);
    const actuel = obtenirNomFichierActuel();
    const cibleBas = cible.split("?")[0].toLowerCase();
    if (actuel === cibleBas && !cible.includes("?")) return;
    if (remplacer && global.location && typeof global.location.replace === "function") {
      global.location.replace(cible);
    } else if (global.location) {
      global.location.href = cible;
    }
  }

  const fichierActuel = obtenirNomFichierActuel();
  const estPageConnexion = fichierActuel.includes("connexion-en-ligne") || fichierActuel.includes("connexion");
  const estPageProfilEnLigne = fichierActuel.includes("profil-en-ligne");
  const estPageVersionEnLigne =
    fichierActuel.includes("version-en-ligne") ||
    fichierActuel.includes("espace-accueil-en-ligne") ||
    fichierActuel.includes("fonctionenligne") ||
    estPageProfilEnLigne;

  let verificationEnCours = false;
  let dernierEtatEnLigne = null;

  /* ------------------------------------------------------------------------
     1. UTILITAIRES FIRESTORE, IDENTIFIANT DOCUMENT & SESSION UNIQUE
     ------------------------------------------------------------------------ */
  function normaliserEmail(email) {
    return String(email || "").trim().toLowerCase();
  }

  function idDocFirestore(email) {
    return encodeURIComponent(normaliserEmail(email));
  }

  function urlDocFirestore(email) {
    return (
      "https://firestore.googleapis.com/v1/projects/" +
      CFG.projectId +
      "/databases/(default)/documents/" +
      CFG.collection +
      "/" +
      idDocFirestore(email) +
      "?key=" +
      CFG.apiKey
    );
  }

  function urlTestFirestore() {
    return (
      "https://firestore.googleapis.com/v1/projects/" +
      CFG.projectId +
      "/databases/(default)/documents/" +
      CFG.collection +
      "?pageSize=1&key=" +
      CFG.apiKey
    );
  }

  function lireSessionPermanente() {
    try {
      const brute = global.localStorage.getItem(CFG.cleSessionPermanente);
      if (brute) {
        const parsed = JSON.parse(brute);
        if (parsed && parsed.email && parsed.deconnecte !== true) {
          return parsed;
        }
      }
    } catch (_) {}

    const emailSecours =
      global.localStorage.getItem(CFG.cleUserEmail) ||
      global.localStorage.getItem(CFG.cleDernierEmail) ||
      "";
    const flagLigne = global.localStorage.getItem(CFG.cleConnecteLocal) === "true";

    if (flagLigne && emailSecours) {
      return {
        email: normaliserEmail(emailSecours),
        connecteUneFois: true,
        deconnecte: false
      };
    }
    return null;
  }

  function estDejaConnecteUneFois() {
    const params = new URLSearchParams(global.location.search || "");
    if (params.get("deconnecte") === "1") {
      return false;
    }
    return Boolean(lireSessionPermanente());
  }

  function obtenirEmailActif() {
    try {
      const sAct = JSON.parse(global.sessionStorage.getItem(CFG.cleSessionActive) || "null");
      if (sAct && sAct.email) return normaliserEmail(sAct.email);
    } catch (_) {}

    try {
      const sSec = JSON.parse(global.sessionStorage.getItem(CFG.cleSessionSecours) || "null");
      if (sSec && sSec.email) return normaliserEmail(sSec.email);
    } catch (_) {}

    const perm = lireSessionPermanente();
    if (perm && perm.email) return normaliserEmail(perm.email);

    const direct =
      global.localStorage.getItem(CFG.cleUserEmail) ||
      global.localStorage.getItem(CFG.cleDernierEmail) ||
      global.localStorage.getItem("tc_email_compte") ||
      "";
    return normaliserEmail(direct);
  }

  function sauvegarderSessionAvantCoupure() {
    try {
      const act = global.sessionStorage.getItem(CFG.cleSessionActive);
      if (act) {
        global.sessionStorage.setItem(CFG.cleSessionSecours, act);
      }
    } catch (_) {}
  }

  function restaurerSessionApresReconnexion() {
    try {
      if (!global.sessionStorage.getItem(CFG.cleSessionActive)) {
        const sec = global.sessionStorage.getItem(CFG.cleSessionSecours);
        if (sec) {
          global.sessionStorage.setItem(CFG.cleSessionActive, sec);
        }
      }
    } catch (_) {}
  }

  /* ------------------------------------------------------------------------
     2. GESTION DES ADRESSES E-MAIL, GOOGLE & REPRISE SUR N'IMPORTE QUEL TÉLÉPHONE
     ------------------------------------------------------------------------ */
  function enregistrerAdresseGoogleConnue(email) {
    const clean = normaliserEmail(email);
    if (!clean || !clean.includes("@")) return;
    try {
      const liste = JSON.parse(global.localStorage.getItem(CFG.cleComptesGoogleConnus) || "[]");
      const arr = Array.isArray(liste) ? liste : [];
      const filtre = arr.filter(function (x) {
        return normaliserEmail(x) !== clean;
      });
      filtre.unshift(clean);
      global.localStorage.setItem(CFG.cleComptesGoogleConnus, JSON.stringify(filtre.slice(0, 25)));
    } catch (_) {}
    global.localStorage.setItem(CFG.cleDernierEmail, clean);
    global.localStorage.setItem(CFG.cleUserEmail, clean);
    global.localStorage.setItem("tc_email_compte", clean);
  }

  function listerAdressesGoogleDisponibles() {
    const resultats = [];
    const ajouter = function (val) {
      const clean = normaliserEmail(val);
      if (clean && clean.includes("@") && !resultats.includes(clean)) {
        resultats.push(clean);
      }
    };

    try {
      if (global.TC_NativeGoogleBridge && typeof global.TC_NativeGoogleBridge.getAccounts === "function") {
        const natifs = global.TC_NativeGoogleBridge.getAccounts();
        if (Array.isArray(natifs)) natifs.forEach(ajouter);
      } else if (global.AndroidInterface && typeof global.AndroidInterface.getGoogleAccounts === "function") {
        const brut = global.AndroidInterface.getGoogleAccounts();
        const parsed = typeof brut === "string" ? JSON.parse(brut) : brut;
        if (Array.isArray(parsed)) parsed.forEach(ajouter);
      }
    } catch (_) {}

    try {
      const connus = JSON.parse(global.localStorage.getItem(CFG.cleComptesGoogleConnus) || "[]");
      if (Array.isArray(connus)) connus.forEach(ajouter);
    } catch (_) {}

    ajouter(global.localStorage.getItem(CFG.cleDernierEmail));
    ajouter(global.localStorage.getItem(CFG.cleUserEmail));
    ajouter(global.localStorage.getItem("tc_email_compte"));

    return resultats;
  }

  function initialiserFirebaseSdkSiPresent() {
    try {
      if (global.firebase && typeof global.firebase.initializeApp === "function") {
        if (!global.firebase.apps || !global.firebase.apps.length) {
          global.firebase.initializeApp({
            apiKey: CFG.apiKey,
            authDomain: CFG.projectId + ".firebaseapp.com",
            projectId: CFG.projectId,
            storageBucket: CFG.projectId + ".appspot.com"
          });
        }
        return true;
      }
    } catch (_) {}
    return false;
  }

  function ouvrirSelecteurGoogle(emailPreRempli, modeCreation) {
    if (global.TC_NativeGoogleBridge && typeof global.TC_NativeGoogleBridge.pickAccount === "function") {
      global.TC_NativeGoogleBridge.pickAccount(function (emailChoisi) {
        if (emailChoisi) {
          if (modeCreation) {
            creerOuReprendreCompteFirebase(emailChoisi, { fournisseurConnexion: "google_natif" });
          } else {
            validerConnexionUnique(emailChoisi, { fournisseurConnexion: "google_natif" });
          }
        }
      });
      return;
    }

    let modal = document.getElementById(CFG.idModalGoogle);
    if (!modal) {
      modal = document.createElement("div");
      modal.id = CFG.idModalGoogle;
      modal.style.cssText = [
        "position:fixed",
        "inset:0",
        "z-index:100000",
        "background:rgba(15,23,42,0.75)",
        "display:flex",
        "align-items:center",
        "justify-content:center",
        "padding:18px",
        "font-family:Arial,sans-serif"
      ].join(";");
      document.body.appendChild(modal);
    }

    const adresses = listerAdressesGoogleDisponibles();
    const boutonsAdresses = adresses.length
      ? adresses
          .map(function (adr) {
            return (
              '<button type="button" data-tc-google-choice="' +
              adr.replace(/"/g, "&quot;") +
              '" style="width:100%;text-align:left;padding:11px 12px;margin-bottom:8px;border-radius:10px;border:1.5px solid #bae6fd;background:#f0f9ff;color:#0f172a;font-weight:700;font-size:0.88rem;cursor:pointer;display:flex;justify-content:space-between;align-items:center;">' +
              "<span>" +
              adr +
              "</span><span>Google →</span></button>"
            );
          })
          .join("")
      : '<div style="font-size:0.82rem;color:#475569;margin-bottom:10px;">Saisis ton adresse Gmail / e-mail Google pour l\'enregistrer sur Firebase et la retrouver sur n\'importe quel téléphone :</div>';

    modal.innerHTML =
      '<div style="width:100%;max-width:420px;background:#ffffff;color:#0f172a;border-radius:16px;padding:18px;border:2px solid #0284c7;box-shadow:0 20px 45px rgba(0,0,0,0.35);">' +
      '<div style="font-size:1.05rem;font-weight:800;color:#0369a1;margin-bottom:6px;">Compte Google & Firebase</div>' +
      '<div style="font-size:0.82rem;color:#475569;margin-bottom:12px;">Enregistre ou reprends automatiquement ton compte et ta configuration sur n\'importe quel téléphone avec la même adresse e-mail.</div>' +
      "<div>" +
      boutonsAdresses +
      "</div>" +
      '<div style="display:flex;gap:8px;margin-top:8px;">' +
      '<input type="email" id="tc-google-input-email" placeholder="exemple@gmail.com" value="' +
      normaliserEmail(emailPreRempli || "").replace(/"/g, "&quot;") +
      '" style="flex:1;padding:10px 11px;border-radius:10px;border:1.5px solid #cbd5e1;font-size:0.86rem;">' +
      '<button type="button" id="tc-google-btn-valider" style="padding:10px 14px;border-radius:10px;border:none;background:#0284c7;color:#ffffff;font-weight:800;cursor:pointer;">Valider</button>' +
      "</div>" +
      '<button type="button" id="tc-google-btn-annuler" style="width:100%;margin-top:10px;padding:10px;border-radius:10px;border:1px solid #cbd5e1;background:#f8fafc;color:#334155;font-weight:700;cursor:pointer;">Annuler</button>' +
      "</div>";

    modal.style.display = "flex";

    modal.querySelectorAll("[data-tc-google-choice]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const choisi = btn.getAttribute("data-tc-google-choice");
        modal.style.display = "none";
        lancerConnexionGoogle(choisi, Boolean(modeCreation));
      });
    });

    const btnValider = document.getElementById("tc-google-btn-valider");
    const inputEmail = document.getElementById("tc-google-input-email");
    if (btnValider && inputEmail) {
      btnValider.addEventListener("click", function () {
        const val = normaliserEmail(inputEmail.value);
        if (!val || !val.includes("@")) {
          inputEmail.focus();
          return;
        }
        modal.style.display = "none";
        lancerConnexionGoogle(val, Boolean(modeCreation));
      });
    }

    const btnAnnuler = document.getElementById("tc-google-btn-annuler");
    if (btnAnnuler) {
      btnAnnuler.addEventListener("click", function () {
        modal.style.display = "none";
      });
    }
  }

  async function lancerConnexionGoogle(emailSelectionne, estCreation) {
    if (!navigator.onLine) return false;

    const sdkPret = initialiserFirebaseSdkSiPresent();
    if (sdkPret && global.firebase.auth && global.firebase.auth.GoogleAuthProvider) {
      try {
        const provider = new global.firebase.auth.GoogleAuthProvider();
        provider.setCustomParameters({ prompt: "select_account" });
        if (emailSelectionne) {
          provider.setCustomParameters({ login_hint: normaliserEmail(emailSelectionne) });
        }
        const res = await global.firebase.auth().signInWithPopup(provider);
        const user = res && res.user;
        const emailGoogle = normaliserEmail((user && user.email) || emailSelectionne);
        if (emailGoogle) {
          const infosGoogle = {
            nom: (user && user.displayName) || "",
            photo: (user && user.photoURL) || "",
            fournisseurConnexion: "google",
            googleLie: true
          };
          return estCreation
            ? await creerOuReprendreCompteFirebase(emailGoogle, infosGoogle)
            : await validerConnexionUnique(emailGoogle, infosGoogle);
        }
      } catch (_) {}
    }

    const emailClean = normaliserEmail(emailSelectionne);
    if (emailClean && emailClean.includes("@")) {
      const infosGoogle = { fournisseurConnexion: "google", googleLie: true };
      return estCreation
        ? await creerOuReprendreCompteFirebase(emailClean, infosGoogle)
        : await validerConnexionUnique(emailClean, infosGoogle);
    }

    ouvrirSelecteurGoogle("", estCreation);
    return false;
  }

  /* ------------------------------------------------------------------------
     3. PROFIL EN LIGNE, CONFIGURATION, CRÉATION & REPRISE MULTI-TÉLÉPHONES
     ------------------------------------------------------------------------ */
  function capturerConfigurationLocale() {
    const configAuto = {};
    try {
      for (let i = 0; i < global.localStorage.length; i++) {
        const cle = global.localStorage.key(i);
        if (!cle) continue;
        if (
          cle.startsWith("tc_") &&
          !cle.startsWith("tc_donnees_completes_") &&
          !cle.startsWith("tc_profil_fichier_") &&
          cle !== CFG.cleQueueOffline
        ) {
          configAuto[cle] = global.localStorage.getItem(cle);
        }
      }
    } catch (_) {}
    return configAuto;
  }

  function appliquerConfigurationRestauree(configObj) {
    if (!configObj || typeof configObj !== "object") return;
    Object.keys(configObj).forEach(function (cle) {
      if (
        cle.startsWith("tc_") &&
        !cle.startsWith("tc_donnees_completes_") &&
        !cle.startsWith("tc_profil_fichier_") &&
        cle !== CFG.cleQueueOffline
      ) {
        try {
          if (configObj[cle] !== null && configObj[cle] !== undefined) {
            global.localStorage.setItem(cle, String(configObj[cle]));
          }
        } catch (_) {}
      }
    });
  }

  function construireEtatComplet(email, extraAction) {
    const emailClean = normaliserEmail(email || obtenirEmailActif());
    const cleEtat = "tc_donnees_completes_" + encodeURIComponent(emailClean);

    let etat = {
      profil: {
        email: emailClean,
        nom: global.localStorage.getItem("tc_nom") || "",
        prenom: global.localStorage.getItem("tc_prenom") || "",
        telephone: global.localStorage.getItem("tc_telephone") || "",
        boutique: global.localStorage.getItem("tc_boutique") || "Trading Commerce",
        ville: global.localStorage.getItem("tc_ville") || "",
        devise: global.localStorage.getItem("tc_devise") || "XOF",
        fournisseurConnexion: global.localStorage.getItem("tc_fournisseur_connexion") || "compte_normal",
        publicationImagesActif: global.localStorage.getItem("tc_pro_publication_active") === "true"
      },
      configuration: capturerConfigurationLocale(),
      profilsClients: [],
      entrees: [],
      historique: [],
      journalActions: []
    };

    try {
      const localBrut = JSON.parse(global.localStorage.getItem(cleEtat) || "null");
      if (localBrut && typeof localBrut === "object") {
        etat.profil = Object.assign({}, etat.profil, localBrut.profil || {}, { email: emailClean });
        etat.configuration = Object.assign({}, etat.configuration, localBrut.configuration || {});
        if (Array.isArray(localBrut.entrees)) etat.entrees = localBrut.entrees;
        if (Array.isArray(localBrut.historique)) etat.historique = localBrut.historique;
        if (Array.isArray(localBrut.journalActions)) etat.journalActions = localBrut.journalActions;
        if (Array.isArray(localBrut.profilsClients)) etat.profilsClients = localBrut.profilsClients;
      }
    } catch (_) {}

    try {
      const clients = JSON.parse(
        global.localStorage.getItem("tc_profils_clients") ||
          global.localStorage.getItem("tc_clients") ||
          "[]"
      );
      if (Array.isArray(clients) && clients.length) {
        etat.profilsClients = clients;
      }
    } catch (_) {}

    if (extraAction) {
      etat.journalActions.unshift(extraAction);
      etat.journalActions = etat.journalActions.slice(0, 150);
    }

    etat.updatedAt = new Date().toISOString();
    global.localStorage.setItem(cleEtat, JSON.stringify(etat));
    return etat;
  }

  async function pousserEtatSurFirestore(email, etat) {
    const emailClean = normaliserEmail(email);
    if (!emailClean || !navigator.onLine) return false;

    const p = etat.profil || {};
    try {
      const res = await fetch(urlDocFirestore(emailClean), {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fields: {
            email: { stringValue: emailClean },
            nom: { stringValue: String(p.nom || "") },
            prenom: { stringValue: String(p.prenom || "") },
            telephone: { stringValue: String(p.telephone || "") },
            boutique: { stringValue: String(p.boutique || "Trading Commerce") },
            ville: { stringValue: String(p.ville || "") },
            devise: { stringValue: String(p.devise || "XOF") },
            fournisseurConnexion: { stringValue: String(p.fournisseurConnexion || "compte_normal") },
            publicationImagesActif: { booleanValue: Boolean(p.publicationImagesActif) },
            updatedAt: { stringValue: etat.updatedAt || new Date().toISOString() },
            donneesJson: { stringValue: JSON.stringify(etat) }
          }
        })
      });
      return res.ok;
    } catch (_) {
      return false;
    }
  }

  async function chargerEtFusionnerDepuisFirebase(email, infosNouvelles, prioriteCloud) {
    const emailClean = normaliserEmail(email);
    if (!emailClean || !emailClean.includes("@")) return null;

    enregistrerAdresseGoogleConnue(emailClean);

    let etat = construireEtatComplet(emailClean);
    let cloudTrouve = false;

    if (navigator.onLine) {
      try {
        const res = await fetch(urlDocFirestore(emailClean), { method: "GET", cache: "no-store" });
        if (res.ok) {
          cloudTrouve = true;
          const doc = await res.json();
          const f = doc.fields || {};

          const profilCloud = {
            email: emailClean,
            nom: (f.nom && f.nom.stringValue) || "",
            prenom: (f.prenom && f.prenom.stringValue) || "",
            telephone: (f.telephone && f.telephone.stringValue) || "",
            boutique: (f.boutique && f.boutique.stringValue) || "Trading Commerce",
            ville: (f.ville && f.ville.stringValue) || "",
            devise: (f.devise && f.devise.stringValue) || "XOF",
            fournisseurConnexion: (f.fournisseurConnexion && f.fournisseurConnexion.stringValue) || "compte_normal",
            publicationImagesActif: Boolean(f.publicationImagesActif && f.publicationImagesActif.booleanValue)
          };

          if (prioriteCloud) {
            etat.profil = Object.assign({}, etat.profil, profilCloud, infosNouvelles || {}, { email: emailClean });
          } else {
            etat.profil = Object.assign({}, profilCloud, etat.profil, infosNouvelles || {}, { email: emailClean });
          }

          if (f.donneesJson && f.donneesJson.stringValue) {
            const cloudObj = JSON.parse(f.donneesJson.stringValue);
            if (cloudObj && typeof cloudObj === "object") {
              if (prioriteCloud) {
                etat.profil = Object.assign({}, etat.profil, cloudObj.profil || {}, infosNouvelles || {}, { email: emailClean });
                etat.configuration = Object.assign({}, cloudObj.configuration || {}, etat.configuration || {});
              } else {
                etat.profil = Object.assign({}, cloudObj.profil || {}, etat.profil, infosNouvelles || {}, { email: emailClean });
                etat.configuration = Object.assign({}, etat.configuration || {}, cloudObj.configuration || {});
              }

              if (Array.isArray(cloudObj.entrees) && cloudObj.entrees.length) {
                etat.entrees = cloudObj.entrees;
              }
              if (Array.isArray(cloudObj.historique) && cloudObj.historique.length) {
                etat.historique = cloudObj.historique;
              }
              if (Array.isArray(cloudObj.profilsClients) && cloudObj.profilsClients.length) {
                etat.profilsClients = cloudObj.profilsClients;
              }
              if (Array.isArray(cloudObj.journalActions) && cloudObj.journalActions.length) {
                const ids = new Set(etat.journalActions.map(function (a) { return a.id; }));
                cloudObj.journalActions.forEach(function (a) {
                  if (a && a.id && !ids.has(a.id)) {
                    ids.add(a.id);
                    etat.journalActions.push(a);
                  }
                });
              }
            }
          }
        }
      } catch (_) {}
    }

    if (!cloudTrouve) {
      etat.profil = Object.assign({}, etat.profil, infosNouvelles || {}, { email: emailClean });
    }

    appliquerConfigurationRestauree(etat.configuration);
    await absorberDonneesHorsLigneVersFirebase(emailClean, etat);

    const cleEtat = "tc_donnees_completes_" + encodeURIComponent(emailClean);
    global.localStorage.setItem(cleEtat, JSON.stringify(etat));
    global.localStorage.setItem("tc_profil_fichier_" + encodeURIComponent(emailClean), JSON.stringify(etat.profil));
    global.localStorage.setItem("tc_nom", etat.profil.nom || "");
    global.localStorage.setItem("tc_prenom", etat.profil.prenom || "");
    global.localStorage.setItem("tc_telephone", etat.profil.telephone || "");
    global.localStorage.setItem("tc_boutique", etat.profil.boutique || "Trading Commerce");
    global.localStorage.setItem("tc_ville", etat.profil.ville || "");
    global.localStorage.setItem("tc_devise", etat.profil.devise || "XOF");
    global.localStorage.setItem("tc_fournisseur_connexion", etat.profil.fournisseurConnexion || "compte_normal");

    if (navigator.onLine) {
      await pousserEtatSurFirestore(emailClean, etat);
    }

    global.dispatchEvent(
      new CustomEvent("tc:compte-charge", { detail: { email: emailClean, etat: etat, cloudTrouve: cloudTrouve } })
    );

    return etat;
  }

  async function creerOuReprendreCompteFirebase(email, infosCompte, cibleRedirection) {
    const emailClean = normaliserEmail(email);
    if (!emailClean || !emailClean.includes("@")) return false;

    const infosPropres = Object.assign(
      {
        fournisseurConnexion: "compte_normal",
        creeOuReprisLe: new Date().toISOString()
      },
      infosCompte || {},
      { email: emailClean }
    );

    const etat = await chargerEtFusionnerDepuisFirebase(emailClean, infosPropres, true);
    if (!etat) return false;

    etat.journalActions.unshift({
      id: "cpt_" + Date.now() + "_" + Math.random().toString(36).slice(2, 6),
      type: "CREATION_OU_REPRISE_COMPTE",
      fournisseur: infosPropres.fournisseurConnexion,
      dateIso: new Date().toISOString()
    });
    etat.updatedAt = new Date().toISOString();

    const cleEtat = "tc_donnees_completes_" + encodeURIComponent(emailClean);
    global.localStorage.setItem(cleEtat, JSON.stringify(etat));
    await pousserEtatSurFirestore(emailClean, etat);

    return await validerConnexionUnique(
      emailClean,
      etat.profil,
      cibleRedirection || CFG.pageVersionEnLigne
    );
  }

  async function synchroniserProfilDepuisFirestore(email, infosSaisies) {
    const etat = await chargerEtFusionnerDepuisFirebase(email, infosSaisies, true);
    return etat ? etat.profil : null;
  }

  async function enregistrerProfilVersFirebase(champsProfil) {
    const emailClean = normaliserEmail((champsProfil && champsProfil.email) || obtenirEmailActif());
    if (!emailClean || !emailClean.includes("@")) return false;

    const act = {
      id: "prof_" + Date.now() + "_" + Math.random().toString(36).slice(2, 6),
      type: "MISE_A_JOUR_PROFIL",
      dateIso: new Date().toISOString()
    };

    const etatActuel = await chargerEtFusionnerDepuisFirebase(emailClean, champsProfil, false);
    if (!etatActuel) return false;

    etatActuel.configuration = capturerConfigurationLocale();
    etatActuel.journalActions.unshift(act);
    etatActuel.journalActions = etatActuel.journalActions.slice(0, 150);
    etatActuel.updatedAt = new Date().toISOString();

    const cleEtat = "tc_donnees_completes_" + encodeURIComponent(emailClean);
    global.localStorage.setItem(cleEtat, JSON.stringify(etatActuel));

    if (!navigator.onLine) return false;
    return await pousserEtatSurFirestore(emailClean, etatActuel);
  }

  async function absorberDonneesHorsLigneVersFirebase(emailForce, etatExistant) {
    const emailClean = normaliserEmail(emailForce || obtenirEmailActif());
    if (!emailClean || !navigator.onLine) return false;

    let fileOff = [];
    try {
      const raw = JSON.parse(global.localStorage.getItem(CFG.cleQueueOffline) || "[]");
      if (Array.isArray(raw)) fileOff = raw;
    } catch (_) {}

    const etat = etatExistant || construireEtatComplet(emailClean);
    const idsExistants = new Set((etat.journalActions || []).map(function (a) { return a.id; }));

    fileOff.forEach(function (act) {
      if (act && act.id && !idsExistants.has(act.id)) {
        idsExistants.add(act.id);
        etat.journalActions.unshift(Object.assign({}, act, { synchroniseDepuisHorsLigne: true }));
      }
    });

    etat.journalActions = etat.journalActions.slice(0, 150);
    etat.updatedAt = new Date().toISOString();

    const ok = await pousserEtatSurFirestore(emailClean, etat);
    if (ok) {
      global.localStorage.setItem(CFG.cleQueueOffline, "[]");
      global.dispatchEvent(new CustomEvent("tc:firebase-sync-ok", { detail: { email: emailClean, etat: etat } }));
    }
    return ok;
  }

  async function pousserActionEnLigneDirecte(typeAction, payload) {
    const okReseau = await testerAccesInternetReel();
    if (!okReseau) {
      if (estPageVersionEnLigne) {
        appliquerEtatInterface(false, "Connexion coupée : aucune action en ligne ne peut être effectuée sans internet.");
      }
      return { ok: false, raison: "HORS_LIGNE" };
    }

    const emailClean = obtenirEmailActif();
    if (!emailClean) {
      if (estPageVersionEnLigne) {
        naviguerVers(CFG.pageConnexion, true);
      }
      return { ok: false, raison: "NON_CONNECTE" };
    }

    const actionObj = {
      id: "act_on_" + Date.now() + "_" + Math.random().toString(36).slice(2, 7),
      type: String(typeAction || "ACTION_EN_LIGNE"),
      payload: payload || {},
      origine: fichierActuel,
      dateIso: new Date().toISOString()
    };

    const etat = construireEtatComplet(emailClean, actionObj);
    etat.configuration = capturerConfigurationLocale();
    const envoye = await pousserEtatSurFirestore(emailClean, etat);
    return { ok: envoye, action: actionObj, etat: etat };
  }

  async function validerConnexionUnique(email, infosSaisies, cibleRedirection) {
    const emailClean = normaliserEmail(email);
    if (!emailClean || !emailClean.includes("@")) return false;

    const etat = await chargerEtFusionnerDepuisFirebase(emailClean, infosSaisies, true);
    const profil = etat ? etat.profil : null;

    const payloadSession = {
      email: emailClean,
      nom: profil ? profil.nom : "",
      prenom: profil ? profil.prenom : "",
      boutique: profil ? profil.boutique : "Trading Commerce",
      fournisseurConnexion: (infosSaisies && infosSaisies.fournisseurConnexion) || "compte_normal",
      connecteUneFois: true,
      deconnecte: false,
      connecteLe: new Date().toISOString()
    };

    global.localStorage.setItem(CFG.cleSessionPermanente, JSON.stringify(payloadSession));
    global.localStorage.setItem(CFG.cleConnecteLocal, "true");
    global.localStorage.setItem(CFG.cleConnecteApp, "true");
    global.localStorage.setItem(CFG.cleUserEmail, emailClean);
    global.localStorage.setItem(CFG.cleDernierEmail, emailClean);

    try {
      global.sessionStorage.setItem(CFG.cleSessionActive, JSON.stringify(payloadSession));
      global.sessionStorage.setItem(CFG.cleSessionSecours, JSON.stringify(payloadSession));
    } catch (_) {}

    const destination = cibleRedirection || CFG.pageVersionEnLigne;
    naviguerVers(destination, true);
    return true;
  }

  function seDeconnecterDepuisProfil() {
    global.localStorage.setItem(CFG.cleConnecteLocal, "false");
    global.localStorage.removeItem(CFG.cleUserEmail);
    global.localStorage.removeItem(CFG.cleSessionPermanente);
    try {
      global.sessionStorage.removeItem(CFG.cleSessionActive);
      global.sessionStorage.removeItem(CFG.cleSessionSecours);
    } catch (_) {}
    naviguerVers(CFG.pageConnexion + "?deconnecte=1", true);
  }

  /* ------------------------------------------------------------------------
     4. BARRE / FORMULAIRE INTELLIGENT DE CRÉATION & REPRISE SUR version-en-ligne.html
     ------------------------------------------------------------------------ */
  function injecterAssistantCompteSurVersionEnLigne() {
    if (!fichierActuel.includes("version-en-ligne") || !document.body) return;
    if (document.getElementById(CFG.idBlocCreationRapide)) return;

    const params = new URLSearchParams(global.location.search || "");
    const modeCreationDemande =
      params.get("creer_compte") === "1" || global.localStorage.getItem(CFG.cleModeCreation) === "1";

    const emailCourant = obtenirEmailActif();
    const bloc = document.createElement("div");
    bloc.id = CFG.idBlocCreationRapide;
    bloc.style.cssText = [
      "margin:12px auto",
      "max-width:720px",
      "background:#f8fafc",
      "border:1.5px solid #0284c7",
      "border-radius:14px",
      "padding:14px 16px",
      "font-family:Arial,sans-serif",
      "color:#0f172a",
      "box-shadow:0 6px 18px rgba(2,132,199,0.08)"
    ].join(";");

    bloc.innerHTML =
      '<div style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:8px;margin-bottom:10px;">' +
      '<strong style="color:#0369a1;font-size:0.95rem;">' +
      (modeCreationDemande
        ? "Créer un nouveau compte en ligne (Firebase & Google)"
        : "Compte & Configuration Cloud (Firebase / Google)") +
      "</strong>" +
      '<span id="tc-statut-compte-badge" style="font-size:0.78rem;padding:3px 9px;border-radius:999px;background:#e0f2fe;color:#0369a1;font-weight:700;">' +
      (emailCourant ? "Actif : " + emailCourant : "Aucun compte actif") +
      "</span>" +
      "</div>" +
      '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:8px;">' +
      '<input type="email" id="tc-on-email" placeholder="Adresse e-mail / Google *" value="' +
      String(emailCourant || "").replace(/"/g, "&quot;") +
      '" style="padding:9px 10px;border-radius:9px;border:1px solid #cbd5e1;font-size:0.85rem;">' +
      '<input type="text" id="tc-on-nom" placeholder="Nom complet / Boutique" value="' +
      String(global.localStorage.getItem("tc_nom") || "").replace(/"/g, "&quot;") +
      '" style="padding:9px 10px;border-radius:9px;border:1px solid #cbd5e1;font-size:0.85rem;">' +
      '<input type="text" id="tc-on-devise" placeholder="Devise (ex: XOF)" value="' +
      String(global.localStorage.getItem("tc_devise") || "XOF").replace(/"/g, "&quot;") +
      '" style="padding:9px 10px;border-radius:9px;border:1px solid #cbd5e1;font-size:0.85rem;">' +
      "</div>" +
      '<div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:10px;">' +
      '<button type="button" id="tc-on-btn-creer" style="padding:9px 14px;border:none;border-radius:9px;background:#16a34a;color:#ffffff;font-weight:700;font-size:0.84rem;cursor:pointer;">Enregistrer / Créer sur Firebase</button>' +
      '<button type="button" id="tc-on-btn-google" style="padding:9px 14px;border:none;border-radius:9px;background:#0284c7;color:#ffffff;font-weight:700;font-size:0.84rem;cursor:pointer;">Continuer avec Google</button>' +
      '<button type="button" id="tc-on-btn-reprendre" style="padding:9px 14px;border:1px solid #0284c7;border-radius:9px;background:#ffffff;color:#0369a1;font-weight:700;font-size:0.84rem;cursor:pointer;">Reprendre ce compte sur ce téléphone</button>' +
      "</div>";

    document.body.insertBefore(bloc, document.body.firstChild);
    global.localStorage.removeItem(CFG.cleModeCreation);

    const inpEmail = document.getElementById("tc-on-email");
    const inpNom = document.getElementById("tc-on-nom");
    const inpDevise = document.getElementById("tc-on-devise");

    const btnCreer = document.getElementById("tc-on-btn-creer");
    if (btnCreer) {
      btnCreer.addEventListener("click", async function () {
        const em = normaliserEmail(inpEmail && inpEmail.value);
        if (!em || !em.includes("@")) {
          if (inpEmail) inpEmail.focus();
          return;
        }
        btnCreer.disabled = true;
        btnCreer.textContent = "Enregistrement Firebase...";
        await creerOuReprendreCompteFirebase(em, {
          nom: inpNom ? inpNom.value.trim() : "",
          devise: inpDevise ? inpDevise.value.trim() || "XOF" : "XOF",
          fournisseurConnexion: "compte_normal"
        });
        btnCreer.disabled = false;
        btnCreer.textContent = "Enregistrer / Créer sur Firebase";
      });
    }

    const btnGoogle = document.getElementById("tc-on-btn-google");
    if (btnGoogle) {
      btnGoogle.addEventListener("click", function () {
        ouvrirSelecteurGoogle(inpEmail ? inpEmail.value : "", true);
      });
    }

    const btnReprendre = document.getElementById("tc-on-btn-reprendre");
    if (btnReprendre) {
      btnReprendre.addEventListener("click", async function () {
        const em = normaliserEmail(inpEmail && inpEmail.value);
        if (!em || !em.includes("@")) {
          if (inpEmail) inpEmail.focus();
          return;
        }
        btnReprendre.disabled = true;
        btnReprendre.textContent = "Chargement du compte...";
        await chargerEtFusionnerDepuisFirebase(em, {}, true);
        await validerConnexionUnique(em, {}, CFG.pageVersionEnLigne);
        btnReprendre.disabled = false;
        btnReprendre.textContent = "Reprendre ce compte sur ce téléphone";
      });
    }
  }

  /* ------------------------------------------------------------------------
     5. ÉCRAN DE BLOCAGE RÉSEAU (PAGES EN LIGNE)
     ------------------------------------------------------------------------ */
  function supprimerDoublonsEcran() {
    const tous = document.querySelectorAll("#" + CFG.idEcranBlocage);
    for (let i = 1; i < tous.length; i++) {
      tous[i].remove();
    }
  }

  function preparerElementsBlocage() {
    supprimerDoublonsEcran();
    let ecran = document.getElementById(CFG.idEcranBlocage);
    if (ecran) return ecran;

    const boutonConnexionHtml = estPageVersionEnLigne
      ? '<button type="button" id="' +
        CFG.idBoutonConnexion +
        '" style="display:block;width:100%;padding:13px;margin-bottom:10px;border:none;border-radius:10px;background:#16a34a;color:#ffffff;font-size:1rem;font-weight:bold;cursor:pointer;">Aller à la page de connexion</button>'
      : "";

    ecran = document.createElement("div");
    ecran.id = CFG.idEcranBlocage;
    ecran.style.cssText = [
      "position:fixed",
      "inset:0",
      "background:#0f172a",
      "color:#ffffff",
      "display:none",
      "align-items:center",
      "justify-content:center",
      "padding:24px",
      "z-index:99999",
      "text-align:center",
      "font-family:Arial,sans-serif"
    ].join(";");

    ecran.innerHTML =
      '<div style="max-width:460px;width:100%;background:#1e293b;border:2px solid #ef4444;border-radius:16px;padding:26px 22px;box-shadow:0 20px 45px rgba(0,0,0,0.45);">' +
      '<h2 style="margin:0 0 12px 0;font-size:1.55rem;color:#fca5a5;">Vous devez vous connecter</h2>' +
      '<p id="' +
      CFG.idTexteBlocage +
      '" style="margin:0 0 20px 0;font-size:1rem;line-height:1.5;color:#e2e8f0;">La connexion internet est absente ou a été coupée. Vous ne pouvez pas utiliser la version en ligne.</p>' +
      boutonConnexionHtml +
      '<button type="button" id="' +
      CFG.idBoutonHorsLigne +
      '" style="display:block;width:100%;padding:13px;margin-bottom:10px;border:none;border-radius:10px;background:#f59e0b;color:#0f172a;font-size:1rem;font-weight:bold;cursor:pointer;">Passer à l\'application hors ligne</button>' +
      '<button type="button" id="' +
      CFG.idBoutonVerifier +
      '" style="display:block;width:100%;padding:12px;border:1px solid #64748b;border-radius:10px;background:#334155;color:#ffffff;font-size:0.96rem;font-weight:bold;cursor:pointer;">Vérifier la connexion</button>' +
      "</div>";

    document.body.appendChild(ecran);

    const btnConn = document.getElementById(CFG.idBoutonConnexion);
    if (btnConn) {
      btnConn.addEventListener("click", function () {
        naviguerVers(CFG.pageConnexion, false);
      });
    }

    const btnHorsLigne = document.getElementById(CFG.idBoutonHorsLigne);
    if (btnHorsLigne) {
      btnHorsLigne.addEventListener("click", function () {
        naviguerVers(CFG.pageHorsLigne, false);
      });
    }

    const btnVerif = document.getElementById(CFG.idBoutonVerifier);
    if (btnVerif) {
      btnVerif.addEventListener("click", function () {
        verifierConnexionReelle(true);
      });
    }

    return ecran;
  }

  function masquerOuAfficherContenuPage(masquer) {
    const ecran = document.getElementById(CFG.idEcranBlocage);
    const modal = document.getElementById(CFG.idModalGoogle);
    Array.from(document.body.children).forEach(function (enfant) {
      if (
        enfant === ecran ||
        enfant === modal ||
        enfant.id === "tc-bande-statuts-js" ||
        enfant.id === "tc-ecran-creer-statut-js" ||
        enfant.id === "tc-visionneuse-js" ||
        enfant.tagName === "SCRIPT"
      ) {
        return;
      }
      if (!enfant.dataset.tcDisplayPrecedent) {
        enfant.dataset.tcDisplayPrecedent = enfant.style.display || "";
      }
      enfant.style.display = masquer ? "none" : enfant.dataset.tcDisplayPrecedent;
    });
  }

  function appliquerEtatInterface(estConnecteReseau, messagePersonnalise) {
    if (!estPageVersionEnLigne && estConnecteReseau) {
      return;
    }

    const ecran = preparerElementsBlocage();
    const texteEl = document.getElementById(CFG.idTexteBlocage);

    if (!estConnecteReseau) {
      sauvegarderSessionAvantCoupure();
      if (texteEl) {
        texteEl.textContent =
          messagePersonnalise ||
          "La connexion internet est absente ou a été coupée. Vous ne pouvez pas utiliser la version en ligne.";
      }
      masquerOuAfficherContenuPage(true);
      ecran.style.setProperty("display", "flex", "important");
    } else {
      restaurerSessionApresReconnexion();
      ecran.style.setProperty("display", "none", "important");
      masquerOuAfficherContenuPage(false);
    }

    if (dernierEtatEnLigne !== estConnecteReseau) {
      dernierEtatEnLigne = estConnecteReseau;
      global.dispatchEvent(
        new CustomEvent("tc:etat-reseau-change", { detail: { enLigne: estConnecteReseau } })
      );
    }
  }

  async function testerAccesInternetReel() {
    if (!navigator.onLine) return false;
    const ctrl = new AbortController();
    const timer = setTimeout(function () {
      ctrl.abort();
    }, 4500);
    try {
      const res = await fetch(urlTestFirestore(), {
        method: "GET",
        cache: "no-store",
        signal: ctrl.signal
      });
      clearTimeout(timer);
      return res.ok || res.status === 400 || res.status === 403;
    } catch (_) {
      clearTimeout(timer);
      return false;
    }
  }

  async function verifierConnexionReelle(depuisBouton) {
    if (verificationEnCours) return;
    verificationEnCours = true;

    const btnVerifier = document.getElementById(CFG.idBoutonVerifier);
    const texteEl = document.getElementById(CFG.idTexteBlocage);

    if (depuisBouton && btnVerifier) {
      btnVerifier.disabled = true;
      btnVerifier.textContent = "Vérification...";
    }

    const ok = await testerAccesInternetReel();

    if (!ok) {
      if (estPageVersionEnLigne) {
        appliquerEtatInterface(
          false,
          "Connexion instable ou sans accès internet réel. Rien ne fonctionne en ligne sans connexion."
        );
        if (depuisBouton && texteEl) {
          texteEl.textContent =
            "Toujours pas d'accès internet détecté. Réessayez dès que le réseau est actif.";
        }
      }
    } else {
      if (estPageVersionEnLigne) {
        appliquerEtatInterface(true);
        injecterAssistantCompteSurVersionEnLigne();
      }

      const session = lireSessionPermanente();
      const dejaConnecte = estDejaConnecteUneFois();

      if (dejaConnecte && session && session.email) {
        await chargerEtFusionnerDepuisFirebase(session.email, session, false);
        if (estPageConnexion) {
          naviguerVers(CFG.pageVersionEnLigne, true);
          verificationEnCours = false;
          return;
        }
      } else if (estPageProfilEnLigne) {
        naviguerVers(CFG.pageConnexion, true);
        verificationEnCours = false;
        return;
      }
    }

    if (depuisBouton && btnVerifier) {
      btnVerifier.disabled = false;
      btnVerifier.textContent = "Vérifier la connexion";
    }

    verificationEnCours = false;
  }

  /* ------------------------------------------------------------------------
     6. ÉVÉNEMENTS GLOBAUX & REDIRECTION DIRECTE "CRÉER UN COMPTE"
     ------------------------------------------------------------------------ */
  document.addEventListener(
    "click",
    function (event) {
      const cible =
        event.target &&
        event.target.closest(
          "button, a, [data-role-connexion], [data-google-signin], [data-creer-compte]"
        );
      if (!cible) return;

      const id = (cible.id || "").toLowerCase();
      const href = (cible.getAttribute("href") || "").toLowerCase();
      const texte = (cible.textContent || "").trim().toLowerCase();

      const estCreationCompte =
        cible.hasAttribute("data-creer-compte") ||
        id.includes("creer") ||
        id.includes("nouveau-compte") ||
        id.includes("inscription") ||
        href.includes("creer-compte") ||
        texte.includes("créer un nouveau compte") ||
        texte.includes("créer un compte") ||
        texte.includes("nouveau compte");

      if (estCreationCompte) {
        event.preventDefault();
        event.stopImmediatePropagation();
        global.localStorage.setItem(CFG.cleModeCreation, "1");
        const champEmail = document.querySelector("input[type='email'], input[name='email']");
        if (champEmail && champEmail.value) {
          enregistrerAdresseGoogleConnue(champEmail.value);
        }
        naviguerVers(CFG.pageVersionEnLigne + "?creer_compte=1", false);
        return;
      }

      const estGoogle =
        cible.hasAttribute("data-google-signin") ||
        id.includes("google") ||
        texte.includes("continuer avec google") ||
        texte.includes("avec google");

      if (estGoogle) {
        event.preventDefault();
        event.stopImmediatePropagation();
        if (!navigator.onLine) {
          if (estPageVersionEnLigne) {
            appliquerEtatInterface(false, "Connexion internet requise pour continuer avec Google.");
          }
          return;
        }
        const champEmail = document.querySelector("input[type='email'], input[name='email']");
        ouvrirSelecteurGoogle(champEmail ? champEmail.value : "", fichierActuel.includes("version-en-ligne"));
        return;
      }

      if (
        cible.hasAttribute("data-deconnexion-profil") ||
        id.includes("deconnect") ||
        texte === "se déconnecter" ||
        texte === "déconnexion"
      ) {
        event.preventDefault();
        event.stopImmediatePropagation();
        seDeconnecterDepuisProfil();
        return;
      }

      if (estPageConnexion && estDejaConnecteUneFois()) {
        const estBoutonConn =
          id.includes("connect") ||
          cible.hasAttribute("data-role-connexion") ||
          texte === "se connecter" ||
          texte === "connexion";
        if (estBoutonConn) {
          event.preventDefault();
          event.stopImmediatePropagation();
          naviguerVers(CFG.pageVersionEnLigne, true);
        }
      }
    },
    true
  );

  document.addEventListener(
    "submit",
    function (event) {
      const form = event.target;
      if (!form) return;
      const idForm = (form.id || "").toLowerCase();
      const actionAttr = (form.getAttribute("action") || "").toLowerCase();

      if (idForm.includes("creer") || idForm.includes("inscription") || actionAttr.includes("creer")) {
        event.preventDefault();
        event.stopImmediatePropagation();
        const inputEmail = form.querySelector("input[type='email'], input[name='email']");
        const inputNom = form.querySelector("input[name='nom'], #nom, #tc-nom");
        if (inputEmail && inputEmail.value && inputEmail.value.includes("@")) {
          creerOuReprendreCompteFirebase(
            inputEmail.value,
            { nom: inputNom ? inputNom.value.trim() : "", fournisseurConnexion: "compte_normal" },
            CFG.pageVersionEnLigne
          );
        }
        return;
      }

      if (idForm.includes("connexion") || idForm.includes("login")) {
        event.preventDefault();
        event.stopImmediatePropagation();

        const inputEmail = form.querySelector("input[type='email'], input[name='email']");
        if (inputEmail && inputEmail.value && inputEmail.value.includes("@")) {
          creerOuReprendreCompteFirebase(
            inputEmail.value,
            { fournisseurConnexion: "compte_normal" },
            CFG.pageVersionEnLigne
          );
          return;
        }

        if (estDejaConnecteUneFois()) {
          naviguerVers(CFG.pageVersionEnLigne, true);
        }
      }
    },
    true
  );

  global.addEventListener("tc:client-update", function (ev) {
    if (estPageVersionEnLigne) {
      pousserActionEnLigneDirecte("MISE_A_JOUR_CLIENT", ev.detail || {});
    }
  });

  global.addEventListener("offline", function () {
    if (estPageVersionEnLigne) {
      appliquerEtatInterface(
        false,
        "La connexion internet a été coupée. Vous ne pouvez pas utiliser la version en ligne."
      );
    }
  });

  global.addEventListener("online", function () {
    verifierConnexionReelle(false);
  });

  function demarrerMachineEnLigne() {
    if (estPageVersionEnLigne) {
      preparerElementsBlocage();
      injecterAssistantCompteSurVersionEnLigne();
    }
    verifierConnexionReelle(false);
    setInterval(function () {
      verifierConnexionReelle(false);
    }, CFG.intervalleVerificationMs);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", demarrerMachineEnLigne);
  } else {
    demarrerMachineEnLigne();
  }

  global.TC_FonctionEnLigne = {
    config: CFG,
    naviguerVers: naviguerVers,
    resoudreCheminFichier: resoudreCheminFichier,
    creerOuReprendreCompteFirebase: creerOuReprendreCompteFirebase,
    validerConnexionUnique: validerConnexionUnique,
    seDeconnecterDepuisProfil: seDeconnecterDepuisProfil,
    ouvrirSelecteurGoogle: ouvrirSelecteurGoogle,
    lancerConnexionGoogle: lancerConnexionGoogle,
    listerAdressesGoogleDisponibles: listerAdressesGoogleDisponibles,
    chargerEtFusionnerDepuisFirebase: chargerEtFusionnerDepuisFirebase,
    synchroniserProfilDepuisFirestore: synchroniserProfilDepuisFirestore,
    enregistrerProfilVersFirebase: enregistrerProfilVersFirebase,
    absorberDonneesHorsLigneVersFirebase: absorberDonneesHorsLigneVersFirebase,
    pousserActionEnLigneDirecte: pousserActionEnLigneDirecte,
    estDejaConnecteUneFois: estDejaConnecteUneFois,
    obtenirEmailActif: obtenirEmailActif,
    verifierConnexionReelle: verifierConnexionReelle
  };

  global.TC_ProfilEnLigne = {
    chargerEtFusionnerDepuisFirebase: chargerEtFusionnerDepuisFirebase,
    enregistrerProfilVersFirebase: enregistrerProfilVersFirebase,
    creerOuReprendreCompteFirebase: creerOuReprendreCompteFirebase,
    ouvrirProfilEnLigne: function (email, infosSupp, redirigerVersProfil) {
      return validerConnexionUnique(
        email || obtenirEmailActif(),
        infosSupp,
        redirigerVersProfil ? CFG.pageProfilEnLigne : CFG.pageVersionEnLigne
      );
    },
    obtenirEmailCourant: obtenirEmailActif
  };
})(window);

/* ------------------------------------------------------------------------
   CONNEXION E-MAIL + MOT DE PASSE & REDIRECTION DÉMARRAGE EN LIGNE
   ------------------------------------------------------------------------ */
async function connexionAvecEmailEtMotDePasse(email, motDePasse, infosSupp) {
  const emailClean = String(email || "").trim().toLowerCase();
  const mdpClean = String(motDePasse || "");

  if (!emailClean || !emailClean.includes("@")) {
    return { ok: false, message: "Veuillez saisir une adresse e-mail valide." };
  }
  if (!mdpClean) {
    return { ok: false, message: "Veuillez saisir votre mot de passe." };
  }
  if (!navigator.onLine) {
    return { ok: false, message: "Connexion internet requise pour se connecter." };
  }

  try {
    const res = await fetch(urlDocFirestore(emailClean), { method: "GET", cache: "no-store" });
    if (!res.ok) {
      return { ok: false, message: "Aucun compte trouvé pour cette adresse e-mail." };
    }

    const doc = await res.json();
    const f = doc.fields || {};
    const mdpCloud = f.motDePasse && f.motDePasse.stringValue ? f.motDePasse.stringValue : "";

    if (mdpCloud && mdpCloud !== mdpClean) {
      return { ok: false, message: "Mot de passe incorrect." };
    }

    const infosFusion = Object.assign(
      {
        nom: (f.nom && f.nom.stringValue) || "",
        prenom: (f.prenom && f.prenom.stringValue) || "",
        ville: (f.ville && f.ville.stringValue) || "",
        telephone: (f.numero && f.numero.stringValue) || (f.telephone && f.telephone.stringValue) || "",
        fournisseurConnexion: "email_mot_de_passe"
      },
      infosSupp || {},
      { email: emailClean }
    );

    await validerConnexionUnique(emailClean, infosFusion, CFG.pageDemarrageEnLigne || "demarrage-en-ligne.html");
    return { ok: true, message: "Connexion réussie." };
  } catch (_) {
    return { ok: false, message: "Impossible de vérifier le compte pour le moment." };
  }
}

if (window.TC_FonctionEnLigne) {
  window.TC_FonctionEnLigne.connexionAvecEmailEtMotDePasse = connexionAvecEmailEtMotDePasse;
}

/* =========================================================
   FONCTIONS EN LIGNE : LOCALISATION, DEVISES, PRIX & RANGS
   ========================================================= */
const DEVISES_PAYS = {
  BF: { label: "Franc CFA (XOF)", symbole: "FCFA", position: "after" },
  ML: { label: "Franc CFA (XOF)", symbole: "FCFA", position: "after" },
  CI: { label: "Franc CFA (XOF)", symbole: "FCFA", position: "after" },
  SN: { label: "Franc CFA (XOF)", symbole: "FCFA", position: "after" },
  NE: { label: "Franc CFA (XOF)", symbole: "FCFA", position: "after" },
  TG: { label: "Franc CFA (XOF)", symbole: "FCFA", position: "after" },
  BJ: { label: "Franc CFA (XOF)", symbole: "FCFA", position: "after" },
  GW: { label: "Franc CFA (XOF)", symbole: "FCFA", position: "after" },
  CM: { label: "Franc CFA (XAC)", symbole: "FCFA", position: "after" },
  FR: { label: "Euro (€)", symbole: "€", position: "after" },
  US: { label: "Dollar US ($)", symbole: "$", position: "before" },
  NG: { label: "Naira (₦)", symbole: "₦", position: "before" },
  GH: { label: "Cedi (GH₵)", symbole: "GH₵", position: "before" }
};

const LISTE_DEVISES_DISPONIBLES = [
  { code: "BF", label: "Franc CFA (FCFA)", symbole: "FCFA", position: "after" },
  { code: "FR", label: "Euro (€)", symbole: "€", position: "after" },
  { code: "US", label: "Dollar ($)", symbole: "$", position: "before" },
  { code: "NG", label: "Naira (₦)", symbole: "₦", position: "before" },
  { code: "GH", label: "Cedi (GH₵)", symbole: "GH₵", position: "before" }
];

async function detecterLocalisationEtDeviseEnLigne() {
  const sauvegardee = JSON.parse(localStorage.getItem("tc_devise_active") || "null");
  if (sauvegardee && sauvegardee.symbole) {
    return sauvegardee;
  }

  if ("geolocation" in navigator) {
    await new Promise((resolve) => {
      navigator.geolocation.getCurrentPosition(
        () => resolve(true),
        () => resolve(false),
        { timeout: 5000 }
      );
    });
  }

  try {
    const res = await fetch("https://ipapi.co/json/");
    if (res.ok) {
      const data = await res.json();
      const codePays = (data.country_code || "BF").toUpperCase();
      const info = DEVISES_PAYS[codePays] || DEVISES_PAYS.BF;
      const devise = { code: codePays, ...info };
      localStorage.setItem("tc_devise_active", JSON.stringify(devise));
      return devise;
    }
  } catch (e) {}

  const defaut = { code: "BF", ...DEVISES_PAYS.BF };
  localStorage.setItem("tc_devise_active", JSON.stringify(defaut));
  return defaut;
}

function formaterPrixAvecDevise(montant, deviseOverride = null) {
  const propre = String(montant ?? "").replace(/[^\d.,]/g, "").replace(",", ".");
  const valeur = parseFloat(propre);
  const devise =
    deviseOverride ||
    JSON.parse(localStorage.getItem("tc_devise_active") || "null") ||
    { symbole: "FCFA", position: "after" };

  if (isNaN(valeur)) {
    return montant ? `${montant} ${devise.symbole}` : `0 ${devise.symbole}`;
  }

  const nombreFormate = valeur.toLocaleString("fr-FR");
  return devise.position === "before"
    ? `${devise.symbole} ${nombreFormate}`
    : `${nombreFormate} ${devise.symbole}`;
}

function actualiserAffichagePrixEtDevises() {
  document.querySelectorAll("[data-prix-brut]").forEach((el) => {
    const brut = el.getAttribute("data-prix-brut");
    const devisePost = el.getAttribute("data-devise-post");
    el.textContent = formaterPrixAvecDevise(
      brut,
      devisePost ? { symbole: devisePost, position: "after" } : null
    );
  });
}

const MONNAIES_PAYS_PRIORITAIRES = {
  BF: { code: "XOF", symbole: "FCFA", position: "after" },
  ML: { code: "XOF", symbole: "FCFA", position: "after" },
  CI: { code: "XOF", symbole: "FCFA", position: "after" },
  SN: { code: "XOF", symbole: "FCFA", position: "after" },
  NE: { code: "XOF", symbole: "FCFA", position: "after" },
  TG: { code: "XOF", symbole: "FCFA", position: "after" },
  BJ: { code: "XOF", symbole: "FCFA", position: "after" },
  GW: { code: "XOF", symbole: "FCFA", position: "after" },
  CM: { code: "XAF", symbole: "FCFA", position: "after" },
  GA: { code: "XAF", symbole: "FCFA", position: "after" },
  CG: { code: "XAF", symbole: "FCFA", position: "after" },
  TD: { code: "XAF", symbole: "FCFA", position: "after" },
  CF: { code: "XAF", symbole: "FCFA", position: "after" },
  GQ: { code: "XAF", symbole: "FCFA", position: "after" },
  FR: { code: "EUR", symbole: "€", position: "after" },
  US: { code: "USD", symbole: "$", position: "before" },
  GB: { code: "GBP", symbole: "£", position: "before" },
  NG: { code: "NGN", symbole: "₦", position: "before" },
  GH: { code: "GHS", symbole: "GH₵", position: "before" },
  MA: { code: "MAD", symbole: "MAD", position: "after" },
  DZ: { code: "DZD", symbole: "DA", position: "after" },
  TN: { code: "TND", symbole: "DT", position: "after" }
};

function obtenirSymboleMonnaie(codeISO) {
  const c = String(codeISO || "").toUpperCase();
  if (c === "XOF" || c === "XAF") return "FCFA";
  if (c === "EUR") return "€";
  if (c === "USD") return "$";
  if (c === "GBP") return "£";
  if (c === "NGN") return "₦";
  if (c === "GHS") return "GH₵";
  try {
    const parts = new Intl.NumberFormat("fr-FR", {
      style: "currency",
      currency: c,
      currencyDisplay: "narrowSymbol"
    }).formatToParts(1);
    const cur = parts.find((p) => p.type === "currency");
    return cur ? cur.value : c;
  } catch (e) {
    return c || "FCFA";
  }
}

function obtenirToutesLesMonnaiesDuMonde() {
  let codes = [];
  if (typeof Intl !== "undefined" && typeof Intl.supportedValuesOf === "function") {
    try {
      codes = Intl.supportedValuesOf("currency");
    } catch (e) {
      codes = [];
    }
  }
  if (!codes.length) {
    codes = ["XOF", "XAF", "EUR", "USD", "GBP", "NGN", "GHS", "MAD", "CAD", "CHF", "JPY", "CNY"];
  }

  const displayNames =
    typeof Intl !== "undefined" && typeof Intl.DisplayNames === "function"
      ? new Intl.DisplayNames(["fr"], { type: "currency" })
      : null;

  const liste = codes.map((code) => {
    const iso = String(code).toUpperCase();
    const nom = displayNames ? displayNames.of(iso) || iso : iso;
    const symbole = obtenirSymboleMonnaie(iso);
    const position = ["USD", "GBP", "NGN", "GHS", "CAD", "AUD"].includes(iso) ? "before" : "after";
    return {
      code: iso,
      symbole,
      position,
      label: symbole === nom ? `${nom} (${iso})` : `${nom} (${symbole})`
    };
  });

  const priorite = ["XOF", "XAF", "EUR", "USD", "GBP", "NGN", "GHS"];
  liste.sort((a, b) => {
    const ia = priorite.indexOf(a.code);
    const ib = priorite.indexOf(b.code);
    if (ia !== -1 && ib !== -1) return ia - ib;
    if (ia !== -1) return -1;
    if (ib !== -1) return 1;
    return a.label.localeCompare(b.label, "fr");
  });

  return liste;
}

async function detecterLocalisationEtMonnaieEnLigne(forcerDetection = false) {
  const toutes = obtenirToutesLesMonnaiesDuMonde();
  if (!forcerDetection) {
    const sauvegardee = JSON.parse(localStorage.getItem("tc_monnaie_active") || "null");
    if (sauvegardee && sauvegardee.code) {
      return sauvegardee;
    }
  }

  if ("geolocation" in navigator) {
    await new Promise((resolve) => {
      navigator.geolocation.getCurrentPosition(
        () => resolve(true),
        () => resolve(false),
        { timeout: 5000 }
      );
    });
  }

  try {
    const res = await fetch("https://ipapi.co/json/");
    if (res.ok) {
      const data = await res.json();
      const codePays = String(data.country_code || "BF").toUpperCase();
      const mapPays = MONNAIES_PAYS_PRIORITAIRES[codePays];
      const codeDevise = mapPays ? mapPays.code : String(data.currency || "XOF").toUpperCase();
      const trouvee =
        toutes.find((m) => m.code === codeDevise) ||
        toutes.find((m) => m.code === "XOF") ||
        toutes[0];

      const active = {
        code: trouvee.code,
        symbole: mapPays ? mapPays.symbole : trouvee.symbole,
        position: mapPays ? mapPays.position : trouvee.position,
        label: trouvee.label,
        pays: codePays
      };
      localStorage.setItem("tc_monnaie_active", JSON.stringify(active));
      return active;
    }
  } catch (e) {}

  const xof = toutes.find((m) => m.code === "XOF") || toutes[0];
  const defaut = {
    code: xof.code,
    symbole: "FCFA",
    position: "after",
    label: xof.label,
    pays: "BF"
  };
  localStorage.setItem("tc_monnaie_active", JSON.stringify(defaut));
  return defaut;
}

function formaterPrixMonnaie(montant, monnaieOverride = null) {
  const propre = String(montant ?? "").replace(/[^\d.,]/g, "").replace(",", ".");
  const valeur = parseFloat(propre);
  const monnaie =
    monnaieOverride ||
    JSON.parse(localStorage.getItem("tc_monnaie_active") || "null") || {
      code: "XOF",
      symbole: "FCFA",
      position: "after"
    };

  const symbole = monnaie.symbole || obtenirSymboleMonnaie(monnaie.code);
  if (isNaN(valeur)) {
    return montant ? `${montant} ${symbole}` : `0 ${symbole}`;
  }
  const nombre = valeur.toLocaleString("fr-FR");
  return monnaie.position === "before" ? `${symbole} ${nombre}` : `${nombre} ${symbole}`;
}

function formaterRangOrdinal(numero) {
  const n = Math.max(1, parseInt(numero, 10) || 1);
  if (n === 1) return "1er";
  return `${n.toLocaleString("fr-FR")}e`;
}

function appliquerRangSansPousser(el, count, libelle) {
  if (!el) return;
  el.textContent = `${formaterRangOrdinal(count)} ${libelle}`;
  el.style.whiteSpace = "nowrap";
  el.style.flexShrink = "0";
}

function actualiserPrixSurLaPage(monnaieActive = null) {
  const courante =
    monnaieActive ||
    JSON.parse(localStorage.getItem("tc_monnaie_active") || "null") || {
      code: "XOF",
      symbole: "FCFA",
      position: "after"
    };

  document.querySelectorAll("[data-prix-brut]").forEach((el) => {
    const brut = el.getAttribute("data-prix-brut");
    el.textContent = formaterPrixMonnaie(brut, courante);
  });

  document.querySelectorAll("p, span, div, strong, b, h2, h3, h4").forEach((el) => {
    if (el.children.length > 0) return;
    const txt = (el.textContent || "").trim();
    if (/^\d[\d\s.,]*$/.test(txt)) {
      const val = parseFloat(txt.replace(/\s+/g, "").replace(",", "."));
      if (!isNaN(val) && val > 0 && !el.closest("input, select, textarea, button")) {
        el.setAttribute("data-prix-brut", String(val));
        el.textContent = formaterPrixMonnaie(val, courante);
      }
    }
  });
}

function remplirSelecteurMonnaies(selectEl, monnaies, codeSelectionne) {
  if (!selectEl) return;
  selectEl.innerHTML = monnaies
    .map((m) => `<option value="${m.code}">${m.label}</option>`)
    .join("");
  if (codeSelectionne && Array.from(selectEl.options).some((o) => o.value === codeSelectionne)) {
    selectEl.value = codeSelectionne;
  } else if (Array.from(selectEl.options).some((o) => o.value === "XOF")) {
    selectEl.value = "XOF";
  }
}

function brancherPublicationEtSelecteurs() {
  const monnaies = obtenirToutesLesMonnaiesDuMonde();
  const selectHaut = document.getElementById("select-devise-disponible");
  const statutHaut = document.getElementById("statut-localisation-devise");

  const activeInit = JSON.parse(localStorage.getItem("tc_monnaie_active") || "null") || {
    code: "XOF",
    symbole: "FCFA",
    position: "after"
  };

  remplirSelecteurMonnaies(selectHaut, monnaies, activeInit.code);
  if (statutHaut) statutHaut.textContent = `(${activeInit.symbole || "FCFA"})`;

  const inputs = Array.from(document.querySelectorAll("input"));
  const champPrix = inputs.find((inp) => {
    const ph = (inp.placeholder || "").toLowerCase();
    const idn = `${inp.id || ""} ${inp.name || ""}`.toLowerCase();
    return ph.includes("prix") || ph.includes("fcfa") || idn.includes("prix") || idn.includes("price");
  });

  let selectPublication = document.getElementById("select-monnaie-publication");
  if (champPrix && !selectPublication) {
    selectPublication = document.createElement("select");
    selectPublication.id = "select-monnaie-publication";
    selectPublication.style.padding = "6px 8px";
    selectPublication.style.borderRadius = "6px";
    selectPublication.style.marginLeft = "6px";
    remplirSelecteurMonnaies(selectPublication, monnaies, activeInit.code);
    champPrix.insertAdjacentElement("afterend", selectPublication);
  }

  function appliquerChoixCode(codeChoisis) {
    const trouvee = monnaies.find((m) => m.code === codeChoisis) || monnaies[0];
    const next = {
      code: trouvee.code,
      symbole: trouvee.symbole,
      position: trouvee.position,
      label: trouvee.label
    };
    localStorage.setItem("tc_monnaie_active", JSON.stringify(next));
    if (selectHaut && selectHaut.value !== next.code) selectHaut.value = next.code;
    if (selectPublication && selectPublication.value !== next.code) selectPublication.value = next.code;
    if (statutHaut) statutHaut.textContent = `(${next.symbole})`;
    if (champPrix) {
      champPrix.placeholder = `Prix (ex: ${formaterPrixMonnaie(15000, next)})`;
    }
    actualiserPrixSurLaPage(next);
  }

  if (selectHaut) {
    selectHaut.addEventListener("change", (e) => appliquerChoixCode(e.target.value));
  }
  if (selectPublication) {
    selectPublication.addEventListener("change", (e) => appliquerChoixCode(e.target.value));
  }

  const boutonPublier = Array.from(document.querySelectorAll("button")).find((btn) =>
    (btn.textContent || "").trim().toLowerCase().includes("publier")
  );
  if (boutonPublier) {
    boutonPublier.addEventListener("click", () => {
      const codePub = selectPublication ? selectPublication.value : activeInit.code;
      appliquerChoixCode(codePub);
      setTimeout(() => actualiserPrixSurLaPage(), 150);
    });
  }

  detecterLocalisationEtMonnaieEnLigne(false).then((detectee) => {
    if (detectee && detectee.code) {
      appliquerChoixCode(detectee.code);
    } else {
      actualiserPrixSurLaPage(activeInit);
    }
  });
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", brancherPublicationEtSelecteurs);
} else {
  brancherPublicationEtSelecteurs();
}

/* =========================================================
   MESSAGERIE EN LIGNE GRATUITE (FIRESTORE)
   ========================================================= */
function tcInitialiserDbAuto() {
  if (!window.tcDb && typeof firebase !== "undefined" && typeof firebase.firestore === "function") {
    try {
      window.tcDb = firebase.firestore();
    } catch (e) {}
  }
  return window.tcDb || null;
}

function obtenirIdentifiantUtilisateurCourant() {
  try {
    const s = JSON.parse(sessionStorage.getItem("tc_session_profil_en_ligne") || "null");
    if (s && s.email) return String(s.email).trim().toLowerCase();
  } catch (_) {}
  return String(
    localStorage.getItem("tc_mon_id") ||
      localStorage.getItem("tc_user_email") ||
      localStorage.getItem("tc_dernier_email_en_ligne") ||
      localStorage.getItem("tc_numero_utilisateur") ||
      "moi"
  )
    .trim()
    .toLowerCase();
}

function obtenirCleDiscussionCible(cible) {
  const moi = obtenirIdentifiantUtilisateurCourant();
  const autre = String(
    (cible && (cible.cibleId || cible.numero || cible.nomCible)) || "general"
  )
    .trim()
    .toLowerCase();

  const paire = [moi || "moi", autre || "general"].sort();
  return `disc_${paire[0]}__${paire[1]}`.replace(/[^a-zA-Z0-9_-]/g, "_");
}

function jouerBipNotificationSonore() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(880, ctx.currentTime);
    gain.gain.setValueAtTime(0.14, ctx.currentTime);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.18);
  } catch (_) {}
}

function enregistrerMessageDansBoiteRecue(msgData) {
  const cleBoite = "tc_messages_recus_liste_v1";
  let liste = [];
  try {
    liste = JSON.parse(localStorage.getItem(cleBoite) || "[]");
    if (!Array.isArray(liste)) liste = [];
  } catch (_) {
    liste = [];
  }

  const expediteurId = String(msgData.expediteur || msgData.cibleId || "contact").trim();
  const nomExpediteur = String(msgData.nomExpediteur || expediteurId || "Contact").trim();
  const item = {
    id: msgData.id || "msg_" + Date.now() + "_" + Math.random().toString(36).slice(2, 6),
    expediteur: expediteurId,
    nomExpediteur: nomExpediteur,
    objet: msgData.objet || "",
    texte: String(msgData.texte || ""),
    date: msgData.date || new Date().toISOString(),
    lu: false
  };

  liste.unshift(item);
  liste = liste.slice(0, 80);
  try {
    localStorage.setItem(cleBoite, JSON.stringify(liste));
  } catch (_) {}

  actualiserListeMessagesRecusUI();
  return item;
}

function afficherBandeauMessageRecu(msgData) {
  jouerBipNotificationSonore();
  const saved = enregistrerMessageDansBoiteRecue(msgData);

  let bandeau = document.getElementById("notif-message-recu-tc");
  if (!bandeau) {
    bandeau = document.createElement("div");
    bandeau.id = "notif-message-recu-tc";
    bandeau.style.cssText =
      "position:fixed;top:14px;right:14px;max-width:92vw;background:#0f172a;color:#ffffff;border:2px solid #facc15;padding:11px 14px;border-radius:12px;z-index:100000;cursor:pointer;box-shadow:0 8px 24px rgba(0,0,0,0.3);font-family:Arial,sans-serif;font-size:13px;";
    document.body.appendChild(bandeau);
  }

  bandeau.innerHTML =
    '<div style="font-weight:800;color:#fde047;margin-bottom:2px;">Message reçu</div>' +
    "<div><strong>" +
    saved.nomExpediteur +
    "</strong> : " +
    saved.texte +
    '</div><div style="font-size:11px;color:#cbd5e1;margin-top:4px;">Appuyer pour répondre directement</div>';
  bandeau.style.display = "block";

  bandeau.onclick = function () {
    bandeau.style.display = "none";
    ouvrirDiscussionAvecPersonne({
      cibleId: saved.expediteur,
      nomCible: saved.nomExpediteur,
      numero: saved.expediteur,
      objet: saved.objet
    });
  };
}

function rendreHistoriqueRoomDansChat(roomId) {
  const zoneMessages = document.getElementById("messages-chat-ia");
  if (!zoneMessages) return;
  zoneMessages.innerHTML = "";

  const moi = obtenirIdentifiantUtilisateurCourant();
  let messages = [];
  try {
    messages = JSON.parse(localStorage.getItem("tc_room_msgs_" + roomId) || "[]");
    if (!Array.isArray(messages)) messages = [];
  } catch (_) {
    messages = [];
  }

  messages.forEach(function (m) {
    const estMoi = m.auteur === "moi" || String(m.expediteur || "").toLowerCase() === moi;
    const bulle = document.createElement("div");
    bulle.style.cssText = estMoi
      ? "align-self:flex-end;background:#dbeafe;color:#0f172a;padding:7px 10px;border-radius:10px;max-width:85%;word-break:break-word;"
      : "align-self:flex-start;background:#f1f5f9;color:#0f172a;padding:7px 10px;border-radius:10px;max-width:85%;word-break:break-word;";
    bulle.textContent = m.texte || "";
    zoneMessages.appendChild(bulle);
  });

  zoneMessages.scrollTop = zoneMessages.scrollHeight;
}

function sauvegarderMessageRoomLocal(roomId, payload) {
  const cle = "tc_room_msgs_" + roomId;
  let liste = [];
  try {
    liste = JSON.parse(localStorage.getItem(cle) || "[]");
    if (!Array.isArray(liste)) liste = [];
  } catch (_) {
    liste = [];
  }
  const existe = liste.some(function (x) {
    return x.id && payload.id && x.id === payload.id;
  });
  if (!existe) {
    liste.push(payload);
    liste = liste.slice(-120);
    try {
      localStorage.setItem(cle, JSON.stringify(liste));
    } catch (_) {}
  }
}

let tcStopEcouteDiscussion = null;

function tcEcouterDiscussionEnLigne(cible, callbackNouveauMessage) {
  if (typeof tcStopEcouteDiscussion === "function") {
    tcStopEcouteDiscussion();
    tcStopEcouteDiscussion = null;
  }

  const db = tcInitialiserDbAuto();
  const roomId = obtenirCleDiscussionCible(cible);
  const moi = obtenirIdentifiantUtilisateurCourant();

  rendreHistoriqueRoomDansChat(roomId);

  if (db && typeof db.collection === "function") {
    tcStopEcouteDiscussion = db
      .collection("discussions_en_ligne")
      .doc(roomId)
      .collection("messages")
      .orderBy("date", "asc")
      .onSnapshot(
        (snapshot) => {
          snapshot.docChanges().forEach((change) => {
            if (change.type === "added") {
              const data = change.doc.data() || {};
              sauvegarderMessageRoomLocal(roomId, data);
              rendreHistoriqueRoomDansChat(roomId);

              const vientDAutrui =
                data.expediteur && String(data.expediteur).toLowerCase() !== moi;
              if (vientDAutrui) {
                afficherBandeauMessageRecu(data);
              }
              if (typeof callbackNouveauMessage === "function") {
                callbackNouveauMessage(data);
              }
            }
          });
        },
        () => {}
      );
  }
}

function tcEnvoyerMessageFirebase(item) {
  const db = tcInitialiserDbAuto();
  const cibleActuelle = window.tcCibleActive || { cibleId: "general", nomCible: "Contact" };
  const roomId = obtenirCleDiscussionCible(cibleActuelle);
  const moi = obtenirIdentifiantUtilisateurCourant();

  const payload = {
    id: (item && item.id) || "msg_" + Date.now() + "_" + Math.random().toString(36).slice(2, 6),
    roomId,
    expediteur: moi,
    nomExpediteur: localStorage.getItem("tc_nom") || moi,
    destinataire: cibleActuelle.cibleId || cibleActuelle.nomCible || "general",
    objet: cibleActuelle.objet || "",
    auteur: "moi",
    texte: item && item.texte ? String(item.texte) : "",
    date: item && item.date ? item.date : new Date().toISOString()
  };

  if (!payload.texte) return;

  sauvegarderMessageRoomLocal(roomId, payload);
  rendreHistoriqueRoomDansChat(roomId);

  if (db && typeof db.collection === "function") {
    return db
      .collection("discussions_en_ligne")
      .doc(roomId)
      .collection("messages")
      .add(payload)
      .catch(() => {});
  }

  if (typeof window.tcRtdbPushMessage === "function") {
    try {
      window.tcRtdbPushMessage(roomId, payload);
    } catch (_) {}
  }
}

function assurerBoiteDiscussionDirecte() {
  let boite = document.getElementById("chat-ia-trading-commerce");
  if (boite) return boite;

  boite = document.createElement("div");
  boite.id = "chat-ia-trading-commerce";
  boite.style.cssText =
    "position:fixed;bottom:70px;right:12px;width:320px;max-width:94vw;background:#ffffff;color:#0f172a;border:1.5px solid #0f172a;border-radius:12px;padding:10px;z-index:99990;box-shadow:0 8px 24px rgba(0,0,0,0.25);font-family:Arial,sans-serif;display:none;";

  boite.innerHTML =
    '<div style="display:flex;justify-content:space-between;align-items:center;font-weight:bold;margin-bottom:8px;padding-bottom:6px;border-bottom:1px solid #e2e8f0;">' +
    '<span id="titre-discussion-directe">Discussion</span>' +
    '<div style="display:flex;gap:6px;align-items:center;">' +
    '<button type="button" id="ouvrir-boite-recue-btn" style="border:1px solid #cbd5e1;background:#f8fafc;color:#0f172a;border-radius:6px;padding:2px 7px;font-size:11px;font-weight:bold;cursor:pointer;">Reçus</button>' +
    '<button type="button" id="fermer-chat-ia" style="border:none;background:transparent;font-size:16px;cursor:pointer;">✕</button>' +
    "</div></div>" +
    '<div id="messages-chat-ia" style="max-height:220px;overflow-y:auto;display:flex;flex-direction:column;gap:6px;margin-bottom:8px;font-size:13px;"></div>' +
    '<div style="display:flex;gap:6px;">' +
    '<input type="text" id="input-chat-ia" placeholder="Écrire un message..." style="flex:1;padding:7px 9px;border:1px solid #cbd5e1;border-radius:8px;font-size:13px;" />' +
    '<button type="button" id="envoyer-chat-ia" style="padding:7px 11px;border:none;border-radius:8px;background:#0f172a;color:#ffffff;font-weight:bold;cursor:pointer;">Envoyer</button>' +
    "</div>";

  document.body.appendChild(boite);

  document.getElementById("fermer-chat-ia").addEventListener("click", function () {
    boite.style.display = "none";
  });

  document.getElementById("ouvrir-boite-recue-btn").addEventListener("click", function () {
    ouvrirListeMessagesRecus();
  });

  const inputEl = document.getElementById("input-chat-ia");
  const btnEnvoyer = document.getElementById("envoyer-chat-ia");

  function envoyerMessageActif() {
    const msg = inputEl ? String(inputEl.value || "").trim() : "";
    if (!msg) return;
    inputEl.value = "";
    tcEnvoyerMessageFirebase({
      auteur: "moi",
      texte: msg,
      date: new Date().toISOString()
    });
  }

  btnEnvoyer.addEventListener("click", envoyerMessageActif);
  inputEl.addEventListener("keydown", function (e) {
    if (e.key === "Enter") {
      e.preventDefault();
      envoyerMessageActif();
    }
  });

  return boite;
}

function ouvrirDiscussionAvecPersonne(cible, messagePreRempli) {
  window.tcCibleActive = cible || { cibleId: "general", nomCible: "Contact", numero: "" };
  const listeModal = document.getElementById("tc-boite-messages-recus");
  if (listeModal) listeModal.style.display = "none";

  const boite = assurerBoiteDiscussionDirecte();
  const titre = document.getElementById("titre-discussion-directe");
  if (titre) {
    titre.textContent = "Discussion : " + (window.tcCibleActive.nomCible || "Contact");
  }
  boite.style.display = "block";

  const roomId = obtenirCleDiscussionCible(window.tcCibleActive);
  rendreHistoriqueRoomDansChat(roomId);
  tcEcouterDiscussionEnLigne(window.tcCibleActive);

  const inputEl = document.getElementById("input-chat-ia");
  if (inputEl) {
    if (messagePreRempli) inputEl.value = messagePreRempli;
    inputEl.focus();
  }
}

function actualiserListeMessagesRecusUI() {
  const conteneur = document.getElementById("tc-liste-messages-recus-contenu");
  let liste = [];
  try {
    liste = JSON.parse(localStorage.getItem("tc_messages_recus_liste_v1") || "[]");
    if (!Array.isArray(liste)) liste = [];
  } catch (_) {
    liste = [];
  }

  const nonLus = liste.filter(function (m) {
    return !m.lu;
  }).length;
  let badge = document.getElementById("tc-badge-messages-recus");
  if (!badge) {
    badge = document.createElement("button");
    badge.id = "tc-badge-messages-recus";
    badge.type = "button";
    badge.style.cssText =
      "position:fixed;bottom:68px;left:12px;z-index:99985;background:#0f172a;color:#fde047;border:1.5px solid #facc15;border-radius:999px;padding:7px 12px;font-size:12px;font-weight:bold;cursor:pointer;box-shadow:0 6px 16px rgba(0,0,0,0.22);";
    badge.addEventListener("click", function () {
      ouvrirListeMessagesRecus();
    });
    if (document.body) document.body.appendChild(badge);
  }
  badge.textContent = "Messages reçus (" + nonLus + ")";

  if (!conteneur) return;
  conteneur.innerHTML = "";

  if (!liste.length) {
    conteneur.innerHTML =
      '<div style="padding:18px;text-align:center;color:#64748b;font-size:13px;">Aucun message reçu pour le moment.</div>';
    return;
  }

  liste.forEach(function (msg) {
    const ligne = document.createElement("div");
    ligne.style.cssText =
      "padding:10px 12px;border-bottom:1px solid #e2e8f0;cursor:pointer;background:" +
      (msg.lu ? "#ffffff" : "#fef9c3") +
      ";";
    ligne.innerHTML =
      '<div style="display:flex;justify-content:space-between;font-weight:bold;font-size:13px;color:#0f172a;">' +
      "<span>" +
      (msg.nomExpediteur || msg.expediteur || "Contact") +
      "</span>" +
      '<span style="font-size:11px;color:#0369a1;">Répondre →</span>' +
      "</div>" +
      '<div style="font-size:12.5px;color:#334155;margin-top:4px;word-break:break-word;">' +
      (msg.texte || "") +
      "</div>";

    ligne.addEventListener("click", function () {
      msg.lu = true;
      try {
        localStorage.setItem("tc_messages_recus_liste_v1", JSON.stringify(liste));
      } catch (_) {}
      ouvrirDiscussionAvecPersonne({
        cibleId: msg.expediteur,
        nomCible: msg.nomExpediteur || msg.expediteur,
        numero: msg.expediteur,
        objet: msg.objet || ""
      });
    });

    conteneur.appendChild(ligne);
  });
}

function ouvrirListeMessagesRecus() {
  let fenetre = document.getElementById("tc-boite-messages-recus");
  if (!fenetre) {
    fenetre = document.createElement("div");
    fenetre.id = "tc-boite-messages-recus";
    fenetre.style.cssText =
      "position:fixed;bottom:70px;left:12px;width:330px;max-width:94vw;max-height:68vh;background:#ffffff;color:#0f172a;border:1.5px solid #0f172a;border-radius:12px;z-index:99995;box-shadow:0 10px 26px rgba(0,0,0,0.28);font-family:Arial,sans-serif;display:none;flex-direction:column;overflow:hidden;";

    fenetre.innerHTML =
      '<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 12px;background:#0f172a;color:#ffffff;font-weight:bold;font-size:13px;">' +
      "<span>Messages reçus (clique pour parler)</span>" +
      '<button type="button" id="tc-fermer-recus" style="border:none;background:transparent;color:#ffffff;font-size:16px;cursor:pointer;">✕</button>' +
      "</div>" +
      '<div id="tc-liste-messages-recus-contenu" style="overflow-y:auto;flex:1;"></div>';

    document.body.appendChild(fenetre);
    document.getElementById("tc-fermer-recus").addEventListener("click", function () {
      fenetre.style.display = "none";
    });
  }

  actualiserListeMessagesRecusUI();
  fenetre.style.display = "flex";
}

function extraireObjetEtVendeur(el) {
  const carte = el ? el.closest("article, .carte, .card, .post, .produit, .item, li, div") : null;
  const texte = carte ? carte.textContent || "" : "";
  const tel = texte.match(/\b\d{6,15}\b/);
  const titreEl = carte ? carte.querySelector("h2, h3, h4, strong, b") : null;
  const nom = titreEl ? (titreEl.textContent || "").trim() : "Vendeur";
  const prixEl = carte ? carte.querySelector("[data-prix-brut]") : null;
  const prix = prixEl ? prixEl.textContent.trim() : "";

  return {
    cibleId: tel ? tel[0] : nom.toLowerCase().replace(/\s+/g, "_"),
    nomCible: nom,
    numero: tel ? tel[0] : "",
    objet: prix ? `${nom} (${prix})` : nom
  };
}

document.addEventListener("click", function (e) {
  const cibleClic = e.target.closest("button, img, .btn-acheter, .acheter, [data-acheter]");
  if (!cibleClic) return;
  if (cibleClic.closest("#chat-ia-trading-commerce, #tc-boite-messages-recus, #notif-message-recu-tc")) {
    return;
  }

  const estBoutonAction =
    cibleClic.tagName === "BUTTON" &&
    /parler|discuter|acheter|contacter|messages/i.test((cibleClic.textContent || "").trim());
  const estImageObjet =
    cibleClic.tagName === "IMG" && !!cibleClic.closest("article, .carte, .card, .post, .produit, .item");

  if (!estBoutonAction && !estImageObjet && !cibleClic.matches(".btn-acheter, .acheter, [data-acheter]")) {
    return;
  }

  if (/messages/i.test((cibleClic.textContent || "").trim())) {
    e.preventDefault();
    ouvrirListeMessagesRecus();
    return;
  }

  e.preventDefault();
  const infos = extraireObjetEtVendeur(cibleClic);
  ouvrirDiscussionAvecPersonne(infos, `Bonjour, je suis intéressé par : ${infos.objet}`);
});

tcInitialiserDbAuto();
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", actualiserListeMessagesRecusUI);
} else {
  actualiserListeMessagesRecusUI();
}

/* ==========================================================================
   TRADUCTION COMPLÈTE (BOUTONS + PUBLICATIONS + CHIFFRES)
   ========================================================================== */
(function (global) {
  "use strict";

  const CLE_CACHE_TRAD = "tc_cache_trad_universelle_v2";
  const CLE_LANGUE_ACT = "tc_langue_monde_v1";

  const CHIFFRES_ARABES = {
    "0": "٠",
    "1": "١",
    "2": "٢",
    "3": "٣",
    "4": "٤",
    "5": "٥",
    "6": "٦",
    "7": "٧",
    "8": "٨",
    "9": "٩"
  };

  const DICO_INSTANT = {
    fr: {
      "accueil": "Accueil",
      "catégories": "Catégories",
      "ia": "IA",
      "ai": "IA",
      "voir plus": "Voir plus",
      "publier": "Publier",
      "demandes": "Demandes",
      "profil": "Profil",
      "mon profil": "Mon Profil",
      "monnaie": "Monnaie",
      "actualiser": "Actualiser",
      "rechercher produit, ville...": "Rechercher produit, ville...",
      "abonné": "Abonné",
      "s'abonner": "S'abonner",
      "parler": "Parler",
      "vue(s)": "vue(s)",
      "j'aime": "j'aime",
      "abonné(s)": "abonné(s)",
      "prix sur demande": "Prix sur demande",
      "en ligne": "En ligne",
      "envoyer": "Envoyer",
      "retour": "Retour"
    },
    en: {
      "accueil": "Home",
      "catégories": "Categories",
      "ia": "AI",
      "voir plus": "See more",
      "publier": "Post",
      "demandes": "Requests",
      "profil": "Profile",
      "mon profil": "My Profile",
      "monnaie": "Currency",
      "actualiser": "Refresh",
      "rechercher produit, ville...": "Search product, city...",
      "abonné": "Subscribed",
      "s'abonner": "Subscribe",
      "parler": "Chat",
      "vue(s)": "view(s)",
      "j'aime": "like(s)",
      "abonné(s)": "follower(s)",
      "prix sur demande": "Price on request",
      "en ligne": "Online",
      "envoyer": "Send",
      "retour": "Back"
    },
    ar: {
      "accueil": "الرئيسية",
      "catégories": "الفئات",
      "ia": "الذكاء",
      "ai": "الذكاء",
      "voir plus": "المزيد",
      "publier": "نشر",
      "demandes": "الطلبات",
      "profil": "الملف",
      "mon profil": "ملفي الشخصي",
      "monnaie": "العملة",
      "actualiser": "تحديث",
      "rechercher produit, ville...": "ابحث عن منتج أو مدينة...",
      "abonné": "مشترك",
      "s'abonner": "اشتراك",
      "parler": "تحدث",
      "vue(s)": "مشاهدة",
      "j'aime": "إعجاب",
      "abonné(s)": "مشترك(ون)",
      "prix sur demande": "السعر عند الطلب",
      "en ligne": "متصل",
      "envoyer": "إرسال",
      "retour": "رجوع"
    },
    zh: {
      "accueil": "首页",
      "catégories": "分类",
      "ia": "AI",
      "voir plus": "更多",
      "publier": "发布",
      "demandes": "请求",
      "profil": "我的",
      "mon profil": "我的资料",
      "monnaie": "货币",
      "actualiser": "刷新",
      "rechercher produit, ville...": "搜索商品、城市...",
      "abonné": "已关注",
      "s'abonner": "关注",
      "parler": "聊天",
      "vue(s)": "次浏览",
      "j'aime": "个赞",
      "abonné(s)": "位粉丝",
      "prix sur demande": "价格面议",
      "en ligne": "在线",
      "envoyer": "发送",
      "retour": "返回"
    },
    es: {
      "accueil": "Inicio",
      "catégories": "Categorías",
      "ia": "IA",
      "voir plus": "Ver más",
      "publier": "Publicar",
      "demandes": "Solicitudes",
      "profil": "Perfil",
      "mon profil": "Mi Perfil",
      "monnaie": "Moneda",
      "actualiser": "Actualizar",
      "rechercher produit, ville...": "Buscar producto, ciudad...",
      "abonné": "Suscrito",
      "s'abonner": "Suscribirse",
      "parler": "Hablar",
      "vue(s)": "vista(s)",
      "j'aime": "me gusta",
      "abonné(s)": "seguidor(es)",
      "prix sur demande": "Precio a consultar",
      "en ligne": "En línea",
      "envoyer": "Enviar",
      "retour": "Volver"
    },
    pt: {
      "accueil": "Início",
      "catégories": "Categorias",
      "ia": "IA",
      "voir plus": "Ver mais",
      "publier": "Publicar",
      "demandes": "Pedidos",
      "profil": "Perfil",
      "mon profil": "Meu Perfil",
      "monnaie": "Moeda",
      "actualiser": "Atualizar",
      "rechercher produit, ville...": "Buscar produto, ciudad...",
      "abonné": "Inscrito",
      "s'abonner": "Inscrever-se",
      "parler": "Falar",
      "vue(s)": "visualização(ões)",
      "j'aime": "curtida(s)",
      "abonné(s)": "seguidor(es)",
      "prix sur demande": "Preço sob consulta",
      "en ligne": "Online",
      "envoyer": "Enviar",
      "retour": "Voltar"
    }
  };

  let cacheTraductions = (function () {
    try {
      return JSON.parse(localStorage.getItem(CLE_CACHE_TRAD) || "{}") || {};
    } catch (_) {
      return {};
    }
  })();

  let langueCourante = (function () {
    try {
      return (localStorage.getItem(CLE_LANGUE_ACT) || document.documentElement.lang || "fr").trim();
    } catch (_) {
      return "fr";
    }
  })();

  let enCours = false;
  let timerRequete = null;

  function sauvegarderCache() {
    try {
      const cles = Object.keys(cacheTraductions);
      if (cles.length > 3500) {
        const reduit = {};
        cles.slice(-2000).forEach(function (k) {
          reduit[k] = cacheTraductions[k];
        });
        cacheTraductions = reduit;
      }
      localStorage.setItem(CLE_CACHE_TRAD, JSON.stringify(cacheTraductions));
    } catch (_) {}
  }

  function normaliserCodeLangue(code) {
    const raw = String(code || "fr").trim().toLowerCase();
    const matchCode = raw.match(/\b(fr|en|ar|es|pt|zh|hi|sw|ha|de|it|ru|ja|ko|tr|wo|fa|ur|bn|id|ms|vi|th)\b/);
    if (matchCode) return matchCode[1];
    if (raw.includes("arab")) return "ar";
    if (raw.includes("chin")) return "zh";
    if (raw.includes("engl") || raw.includes("angl")) return "en";
    if (raw.includes("span") || raw.includes("españ")) return "es";
    if (raw.includes("port")) return "pt";
    if (raw.includes("fren") || raw.includes("fran")) return "fr";
    return raw.split(/[-_\s(]/)[0] || "fr";
  }

  function convertirChiffresSiArabe(texte, codeNorm) {
    if (codeNorm !== "ar") return texte;
    return String(texte || "").replace(/[0-9]/g, function (d) {
      return CHIFFRES_ARABES[d] || d;
    });
  }

  function traduireLocalement(texteBrut, codeNorm) {
    const str = String(texteBrut || "");
    const trim = str.trim();
    if (!trim) return str;

    if (/^[0-9\s.,]+$/.test(trim)) {
      return convertirChiffresSiArabe(str, codeNorm);
    }

    const cleCache = codeNorm + "::" + trim.toLowerCase();
    if (cacheTraductions[cleCache]) {
      return convertirChiffresSiArabe(cacheTraductions[cleCache], codeNorm);
    }

    if (codeNorm === "fr") {
      return str;
    }

    const dico = DICO_INSTANT[codeNorm];
    let resultat = str;

    if (dico) {
      const cles = Object.keys(dico).sort(function (a, b) {
        return b.length - a.length;
      });
      for (let i = 0; i < cles.length; i++) {
        const k = cles[i];
        const v = dico[k];
        const rx = new RegExp(
          "(^|[^\\p{L}])" + k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "([^\\p{L}]|$)",
          "giu"
        );
        resultat = resultat.replace(rx, function (_, p1, p2) {
          return (p1 || "") + v + (p2 || "");
        });
      }
    }

    return convertirChiffresSiArabe(resultat, codeNorm);
  }

  async function traduireTexteEnLigne(texte, codeNorm) {
    const clean = String(texte || "").trim();
    if (!clean || codeNorm === "fr" || /^[0-9\s.,€$£¥₦]+$/.test(clean)) {
      return convertirChiffresSiArabe(texte, codeNorm);
    }

    const cleCache = codeNorm + "::" + clean.toLowerCase();
    if (cacheTraductions[cleCache]) {
      return convertirChiffresSiArabe(cacheTraductions[cleCache], codeNorm);
    }

    if (!navigator.onLine) {
      return convertirChiffresSiArabe(texte, codeNorm);
    }

    try {
      const url =
        "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=" +
        encodeURIComponent(codeNorm) +
        "&dt=t&q=" +
        encodeURIComponent(clean);
      const res = await fetch(url, { method: "GET" });
      if (!res.ok) return convertirChiffresSiArabe(texte, codeNorm);
      const data = await res.json();
      if (Array.isArray(data) && Array.isArray(data[0])) {
        const traduit = data[0]
          .map(function (seg) {
            return Array.isArray(seg) && seg[0] ? seg[0] : "";
          })
          .join("");
        if (traduit && traduit.trim()) {
          cacheTraductions[cleCache] = traduit.trim();
          sauvegarderCache();
          return convertirChiffresSiArabe(traduit.trim(), codeNorm);
        }
      }
    } catch (_) {}

    return convertirChiffresSiArabe(texte, codeNorm);
  }

  function estIgnore(el) {
    if (!el) return true;
    const tag = el.tagName ? el.tagName.toUpperCase() : "";
    return (
      tag === "SCRIPT" ||
      tag === "STYLE" ||
      tag === "NOSCRIPT" ||
      tag === "TEXTAREA" ||
      tag === "CODE" ||
      tag === "PRE" ||
      el.id === "tc-select-langue-monde" ||
      el.id === "tc-select-langue-settings" ||
      el.id === "select-devise-disponible"
    );
  }

  function collecterCiblesEcran() {
    const ciblesTexte = [];
    const ciblesAttr = [];
    if (!document.body) return { ciblesTexte: ciblesTexte, ciblesAttr: ciblesAttr };

    document
      .querySelectorAll("input[placeholder], textarea[placeholder], [title]")
      .forEach(function (el) {
        if (estIgnore(el)) return;
        if (el.hasAttribute("placeholder")) {
          const orig = el.dataset.tcOrigPh || el.getAttribute("placeholder");
          el.dataset.tcOrigPh = orig;
          ciblesAttr.push({ el: el, attr: "placeholder", orig: orig });
        }
        if (el.hasAttribute("title")) {
          const orig = el.dataset.tcOrigTitle || el.getAttribute("title");
          el.dataset.tcOrigTitle = orig;
          ciblesAttr.push({ el: el, attr: "title", orig: orig });
        }
      });

    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode: function (node) {
          if (!node || !node.nodeValue || !node.nodeValue.trim()) {
            return NodeFilter.FILTER_REJECT;
          }
          const parent = node.parentElement;
          if (!parent || estIgnore(parent)) return NodeFilter.FILTER_REJECT;
          if (parent.closest && parent.closest("select")) return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        }
      }
    );

    let courant;
    while ((courant = walker.nextNode())) {
      if (
        !courant.__tcOrigText ||
        (courant.__tcDernierRendu && courant.nodeValue !== courant.__tcDernierRendu)
      ) {
        courant.__tcOrigText = courant.nodeValue;
      }
      ciblesTexte.push({ node: courant, orig: courant.__tcOrigText });
    }

    return { ciblesTexte: ciblesTexte, ciblesAttr: ciblesAttr };
  }

  function appliquerTraductionUniverselle(langueChoisie) {
    if (enCours || !document.body) return;
    enCours = true;

    try {
      const brute = String(langueChoisie || langueCourante || "fr").trim();
      langueCourante = brute;
      const codeNorm = normaliserCodeLangue(brute);

      try {
        localStorage.setItem(CLE_LANGUE_ACT, brute);
      } catch (_) {}

      document.documentElement.lang = codeNorm;
      document.documentElement.dir = codeNorm === "ar" || codeNorm === "fa" || codeNorm === "ur" ? "rtl" : "ltr";

      const badge = document.getElementById("badge-langue-active");
      if (badge) {
        badge.textContent = codeNorm.toUpperCase();
      }

      const { ciblesTexte, ciblesAttr } = collecterCiblesEcran();
      const lotsEnLigne = [];

      ciblesTexte.forEach(function (item) {
        const renduRapide = traduireLocalement(item.orig, codeNorm);
        if (item.node.nodeValue !== renduRapide) {
          item.node.__tcDernierRendu = renduRapide;
          item.node.nodeValue = renduRapide;
        }
        const trim = String(item.orig || "").trim();
        if (trim && codeNorm !== "fr" && !cacheTraductions[codeNorm + "::" + trim.toLowerCase()]) {
          lotsEnLigne.push({ type: "text", ref: item.node, orig: item.orig });
        }
      });

      ciblesAttr.forEach(function (item) {
        const renduRapide = traduireLocalement(item.orig, codeNorm);
        if (item.el.getAttribute(item.attr) !== renduRapide) {
          item.el.setAttribute(item.attr, renduRapide);
        }
        const trim = String(item.orig || "").trim();
        if (trim && codeNorm !== "fr" && !cacheTraductions[codeNorm + "::" + trim.toLowerCase()]) {
          lotsEnLigne.push({ type: "attr", el: item.el, attr: item.attr, orig: item.orig });
        }
      });

      if (lotsEnLigne.length && navigator.onLine) {
        clearTimeout(timerRequete);
        timerRequete = setTimeout(async function () {
          const uniques = Array.from(
            new Set(
              lotsEnLigne.map(function (x) {
                return String(x.orig || "").trim();
              })
            )
          ).slice(0, 120);

          await Promise.all(
            uniques.map(function (txt) {
              return traduireTexteEnLigne(txt, codeNorm);
            })
          );

          lotsEnLigne.forEach(function (entry) {
            const tr = traduireLocalement(entry.orig, codeNorm);
            if (entry.type === "text" && entry.ref && entry.ref.nodeValue !== tr) {
              entry.ref.__tcDernierRendu = tr;
              entry.ref.nodeValue = tr;
            } else if (entry.type === "attr" && entry.el && entry.el.getAttribute(entry.attr) !== tr) {
              entry.el.setAttribute(entry.attr, tr);
            }
          });
        }, 20);
      }
    } finally {
      enCours = false;
    }
  }

  function connecterEvenements() {
    ["tc-select-langue-monde", "tc-select-langue-settings"].forEach(function (id) {
      const sel = document.getElementById(id);
      if (sel && !sel.dataset.tcUnivLie) {
        sel.dataset.tcUnivLie = "1";
        sel.addEventListener("change", function () {
          appliquerTraductionUniverselle(sel.value);
        });
      }
    });

    if (document.body && !document.body.dataset.tcUnivObs) {
      document.body.dataset.tcUnivObs = "1";
      let t = null;
      const obs = new MutationObserver(function () {
        if (enCours) return;
        const codeNorm = normaliserCodeLangue(langueCourante);
        if (codeNorm === "fr") return;
        clearTimeout(t);
        t = setTimeout(function () {
          appliquerTraductionUniverselle(langueCourante);
        }, 40);
      });
      obs.observe(document.body, { childList: true, subtree: true, characterData: true });
    }
  }

  global.TC_TraductionUniverselle = {
    traduire: appliquerTraductionUniverselle,
    obtenirLangue: function () {
      return langueCourante;
    }
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () {
      connecterEvenements();
      appliquerTraductionUniverselle(langueCourante);
    });
  } else {
    connecterEvenements();
    appliquerTraductionUniverselle(langueCourante);
  }
})(window);

/* ==========================================================================
   STATUTS EN LIGNE FIREBASE + STUDIO CAPCUT + CHANSONS EN LIGNE + CLIC SUIVANT
   ========================================================================== */
(function (global) {
  if (global.TC_StatutsStudioJS) return;

  const CFG = {
    projectId: "trading-commerce",
    apiKey: "AIzaSyAPEnpD8hfQNBZT1wpjSEh9E_OXsjsNiAU",
    collectionStatuts: "statuts_trading_commerce",
    cleStatutsLocal: "tc_statuts_utilisateurs_v1",
    cleProduitsLocal: "tc_produits_en_ligne_v1",
    cleProfilLocal: "tc_profil_tiktok_v1"
  };

  let listeChansons = [];
  let pageChansons = 0;
  let chargementChansonsEnCours = false;
  let termeRechercheChanson = "";
  const chansonsSelectionnees = new Map();

  let mediasChoisis = [];
  let audioLocalUrl = "";
  let audioLocalNom = "";
  let posTexte = { x: 50, y: 20 };
  let filtreState = { sun: 100, contrast: 100, sat: 100, hue: 0, crop: "none" };
  let outilActif = null;
  let sessionLecture = null;
  let audioPlayer = null;
  let timerDureeVideo = null;

  function lireJson(cle, defaut) {
    try {
      const v = JSON.parse(localStorage.getItem(cle) || "null");
      return v !== null ? v : defaut;
    } catch (_) {
      return defaut;
    }
  }

  function ecrireJson(cle, val) {
    try {
      localStorage.setItem(cle, JSON.stringify(val));
    } catch (_) {}
  }

  function obtenirProfilActuel() {
    const p = lireJson(CFG.cleProfilLocal, {});
    const email = (localStorage.getItem("tc_user_email") || "").trim().toLowerCase();
    const nom = p.nom || localStorage.getItem("tc_nom") || (email ? email.split("@")[0] : "Utilisateur");
    const key = (email || nom || "utilisateur").toLowerCase().replace(/[^a-z0-9_@.-]/g, "_");
    return {
      key,
      nom,
      avatar: p.photo || localStorage.getItem("tc_photo_profil") || ""
    };
  }

  function construireFiltreCss(f) {
    return `brightness(${f.sun}%) contrast(${f.contrast}%) saturate(${f.sat}%) hue-rotate(${f.hue}deg)`;
  }

  function construireCropStyle(crop) {
    if (crop === "16:9") return "aspect-ratio:16/9;object-fit:cover;";
    if (crop === "4:3") return "aspect-ratio:4/3;object-fit:cover;";
    if (crop === "1:1") return "aspect-ratio:1/1;object-fit:cover;";
    return "max-height:240px;width:100%;object-fit:contain;";
  }

  function stopperAudio() {
    if (timerDureeVideo) {
      clearTimeout(timerDureeVideo);
      timerDureeVideo = null;
    }
    if (audioPlayer) {
      try {
        audioPlayer.pause();
        audioPlayer.currentTime = 0;
      } catch (_) {}
      audioPlayer = null;
    }
  }

  function jouerPisteAudio(url, boucle) {
    stopperAudio();
    if (!url) return;
    try {
      audioPlayer = new Audio(url);
      audioPlayer.loop = Boolean(boucle);
      audioPlayer.volume = 0.8;
      audioPlayer.play().catch(function () {});
    } catch (_) {}
  }

  async function publierStatutFirebase(statutObj) {
    if (!navigator.onLine) return;
    const mediaSecurise = String(statutObj.media || "").length < 700000 ? String(statutObj.media || "") : "";
    const url =
      "https://firestore.googleapis.com/v1/projects/" +
      CFG.projectId +
      "/databases/(default)/documents/" +
      CFG.collectionStatuts +
      "/" +
      encodeURIComponent(statutObj.id) +
      "?key=" +
      CFG.apiKey;

    try {
      await fetch(url, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fields: {
            id: { stringValue: statutObj.id },
            auteurKey: { stringValue: statutObj.auteurKey },
            auteurNom: { stringValue: statutObj.auteurNom },
            avatar: { stringValue: String(statutObj.avatar || "").slice(0, 120000) },
            texte: { stringValue: statutObj.texte || "" },
            textePosX: { integerValue: String(Math.round(statutObj.textePos ? statutObj.textePos.x : 50)) },
            textePosY: { integerValue: String(Math.round(statutObj.textePos ? statutObj.textePos.y : 20)) },
            media: { stringValue: mediaSecurise },
            mediaType: { stringValue: statutObj.mediaType || "image" },
            filtreCss: { stringValue: statutObj.filtreCss || "none" },
            cropMode: { stringValue: statutObj.cropMode || "none" },
            chansonsJson: { stringValue: JSON.stringify(statutObj.chansons || []) },
            produitJson: { stringValue: JSON.stringify(statutObj.produit || null) },
            dateTs: { integerValue: String(statutObj.dateTs || Date.now()) }
          }
        })
      });
    } catch (_) {}
  }

  async function chargerStatutsFirebase() {
    if (!navigator.onLine) return;
    const url =
      "https://firestore.googleapis.com/v1/projects/" +
      CFG.projectId +
      "/databases/(default)/documents/" +
      CFG.collectionStatuts +
      "?pageSize=80&key=" +
      CFG.apiKey;
    try {
      const res = await fetch(url, { method: "GET", cache: "no-store" });
      if (!res.ok) return;
      const data = await res.json();
      const docs = Array.isArray(data.documents) ? data.documents : [];
      const distants = docs.map(function (doc) {
        const f = doc.fields || {};
        let chansons = [];
        let produit = null;
        try { chansons = JSON.parse((f.chansonsJson && f.chansonsJson.stringValue) || "[]"); } catch (_) {}
        try { produit = JSON.parse((f.produitJson && f.produitJson.stringValue) || "null"); } catch (_) {}
        return {
          id: (f.id && f.id.stringValue) || (doc.name ? doc.name.split("/").pop() : "st_" + Math.random()),
          auteurKey: (f.auteurKey && f.auteurKey.stringValue) || "utilisateur",
          auteurNom: (f.auteurNom && f.auteurNom.stringValue) || "Utilisateur",
          avatar: (f.avatar && f.avatar.stringValue) || "",
          texte: (f.texte && f.texte.stringValue) || "",
          textePos: {
            x: Number((f.textePosX && f.textePosX.integerValue) || 50),
            y: Number((f.textePosY && f.textePosY.integerValue) || 20)
          },
          media: (f.media && f.media.stringValue) || "",
          mediaType: (f.mediaType && f.mediaType.stringValue) || "image",
          filtreCss: (f.filtreCss && f.filtreCss.stringValue) || "none",
          cropMode: (f.cropMode && f.cropMode.stringValue) || "none",
          chansons: Array.isArray(chansons) ? chansons : [],
          produit: produit,
          dateTs: Number((f.dateTs && f.dateTs.integerValue) || Date.now())
        };
      });

      if (distants.length) {
        const locaux = lireJson(CFG.cleStatutsLocal, []);
        const map = new Map();
        distants.forEach(function (d) { map.set(d.id, d); });
        locaux.forEach(function (l) {
          if (l && l.id && !map.has(l.id)) map.set(l.id, l);
        });
        const fusion = Array.from(map.values()).sort(function (a, b) {
          return Number(b.dateTs || 0) - Number(a.dateTs || 0);
        });
        ecrireJson(CFG.cleStatutsLocal, fusion);
        rendreBandeStatuts();
      }
    } catch (_) {}
  }

  async function rechercherChansonsEnLigne(reset) {
    if (chargementChansonsEnCours) return;
    chargementChansonsEnCours = true;
    if (reset) {
      pageChansons = 0;
      listeChansons = [];
    }
    const offset = pageChansons * 12;
    pageChansons++;

    const requete = encodeURIComponent((termeRechercheChanson || "afrobeat pop hits").trim());
    const url = `https://itunes.apple.com/search?term=${requete}&media=music&limit=12&offset=${offset}`;

    const listeDom = document.getElementById("tc-st-liste-chansons");
    if (listeDom && reset) {
      listeDom.innerHTML = '<div style="padding:10px;font-size:12px;color:#cbd5e1;">Chargement des chansons...</div>';
    }

    try {
      if (navigator.onLine) {
        const res = await fetch(url, { cache: "no-store" });
        if (res.ok) {
          const data = await res.json();
          const items = Array.isArray(data.results) ? data.results : [];
          const formates = items
            .filter(function (it) { return it.trackName || it.collectionName; })
            .map(function (it, idx) {
              const id = String(it.trackId || (termeRechercheChanson + "_" + offset + "_" + idx));
              return {
                id,
                titre: it.trackName || it.collectionName,
                artiste: it.artistName || "Artiste",
                logo: it.artworkUrl100 || it.artworkUrl60 || "",
                previewUrl: it.previewUrl || ""
              };
            });
          const existants = new Set(listeChansons.map(function (c) { return c.id; }));
          formates.forEach(function (f) {
            if (!existants.has(f.id)) listeChansons.push(f);
          });
        }
      }
    } catch (_) {}

    if (!listeChansons.length) {
      listeChansons = [
        { id: "fb_1", titre: "Golden Sun Mix", artiste: "DJ Faso", logo: "", previewUrl: "" },
        { id: "fb_2", titre: "Ouaga Night Beat", artiste: "Studio K", logo: "", previewUrl: "" },
        { id: "fb_3", titre: "Market Energy", artiste: "TC Sound", logo: "", previewUrl: "" }
      ];
    }

    rendreListeChansons();
    chargementChansonsEnCours = false;
  }

  function rendreListeChansons() {
    const cont = document.getElementById("tc-st-liste-chansons");
    const compteurEl = document.getElementById("tc-st-chansons-count");
    if (!cont) return;

    if (compteurEl) {
      compteurEl.textContent = `${chansonsSelectionnees.size} sélectionnée(s) (illimité)`;
    }

    cont.innerHTML = "";
    listeChansons.forEach(function (ch) {
      const estSel = chansonsSelectionnees.has(ch.id);
      const ligne = document.createElement("div");
      ligne.style.cssText =
        "display:flex;align-items:center;justify-content:space-between;gap:8px;padding:7px 8px;border-radius:10px;margin-bottom:6px;background:" +
        (estSel ? "#1e3a2f" : "#1e293b") +
        ";border:1px solid " +
        (estSel ? "#22c55e" : "#334155") +
        ";";

      const gauche = document.createElement("div");
      gauche.style.cssText = "display:flex;align-items:center;gap:8px;min-width:0;flex:1;cursor:pointer;";

      const logo = document.createElement("img");
      logo.src = ch.logo || "";
      logo.alt = ch.artiste;
      logo.style.cssText = "width:38px;height:38px;border-radius:8px;object-fit:cover;background:#0f172a;flex-shrink:0;";
      logo.onerror = function () { this.style.display = "none"; };

      const txt = document.createElement("div");
      txt.style.cssText = "min-width:0;flex:1;";
      txt.innerHTML =
        `<div style="font-size:12px;font-weight:bold;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${ch.titre}</div>` +
        `<div style="font-size:11px;color:#94a3b8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${ch.artiste}</div>`;

      gauche.appendChild(logo);
      gauche.appendChild(txt);

      const droite = document.createElement("div");
      droite.style.cssText = "display:flex;align-items:center;gap:5px;flex-shrink:0;";

      if (ch.previewUrl) {
        const btnPlay = document.createElement("button");
        btnPlay.type = "button";
        btnPlay.textContent = "▶";
        btnPlay.style.cssText = "border:none;background:#334155;color:#fde047;border-radius:6px;padding:5px 8px;cursor:pointer;font-size:11px;";
        btnPlay.addEventListener("click", function (ev) {
          ev.stopPropagation();
          jouerPisteAudio(ch.previewUrl, false);
        });
        droite.appendChild(btnPlay);
      }

      const btnSel = document.createElement("button");
      btnSel.type = "button";
      btnSel.textContent = estSel ? "✓ Ajoutée" : "+ Choisir";
      btnSel.style.cssText =
        "border:none;border-radius:6px;padding:5px 8px;cursor:pointer;font-size:11px;font-weight:bold;background:" +
        (estSel ? "#22c55e" : "#eab308") +
        ";color:#0f172a;";
      btnSel.addEventListener("click", function () {
        if (chansonsSelectionnees.has(ch.id)) chansonsSelectionnees.delete(ch.id);
        else chansonsSelectionnees.set(ch.id, ch);
        rendreListeChansons();
      });

      droite.appendChild(btnSel);
      ligne.appendChild(gauche);
      ligne.appendChild(droite);
      cont.appendChild(ligne);
    });
  }

  function creerEcranCreationStatut() {
    if (!document.body || document.getElementById("tc-ecran-creer-statut-js")) return;

    const ecran = document.createElement("div");
    ecran.id = "tc-ecran-creer-statut-js";
    ecran.style.cssText =
      "display:none;position:fixed;inset:0;z-index:100001;background:#090d16;color:#fff;flex-direction:column;overflow-y:auto;padding:12px 12px 36px 12px;font-family:Arial,sans-serif;";

    ecran.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;padding-bottom:10px;border-bottom:1px solid #1e293b;">
        <button type="button" id="tc-st-fermer-ecran" style="background:#1e293b;color:#fff;border:1px solid #334155;border-radius:8px;padding:7px 12px;font-weight:bold;cursor:pointer;">← Fermer</button>
        <strong style="font-size:14px;color:#fde047;">Studio Statut</strong>
        <button type="button" id="tc-st-publier-btn" style="background:#16a34a;color:#fff;border:none;border-radius:8px;padding:8px 14px;font-weight:bold;cursor:pointer;">Publier</button>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px;">
        <label style="background:#1e293b;border:1px dashed #64748b;border-radius:10px;padding:9px;text-align:center;font-size:12px;font-weight:bold;cursor:pointer;">
          🖼️ +10 Images ou Vidéo
          <input type="file" id="tc-st-input-medias" accept="image/*,video/*" multiple style="display:none;" />
        </label>
        <label style="background:#1e293b;border:1px dashed #64748b;border-radius:10px;padding:9px;text-align:center;font-size:12px;font-weight:bold;cursor:pointer;">
          🎧 Son du téléphone
          <input type="file" id="tc-st-input-audio-local" accept="audio/*" style="display:none;" />
        </label>
      </div>

      <div id="tc-st-resume-fichiers" style="font-size:11px;color:#94a3b8;margin-top:6px;"></div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px;">
        <input type="text" id="tc-st-texte-superpose" placeholder="Écrire un texte sur l'image/vidéo..." style="padding:8px 10px;border-radius:8px;border:1px solid #334155;background:#0f172a;color:#fff;font-size:12px;" />
        <select id="tc-st-select-produit" style="padding:8px 10px;border-radius:8px;border:1px solid #334155;background:#0f172a;color:#fff;font-size:12px;">
          <option value="">Produit lié (optionnel)</option>
        </select>
      </div>

      <div id="tc-st-stage" style="position:relative;margin-top:10px;border-radius:12px;overflow:hidden;background:#020617;border:1px solid #334155;min-height:190px;display:flex;align-items:center;justify-content:center;">
        <div id="tc-st-apercu-media" style="width:100%;display:flex;align-items:center;justify-content:center;"></div>
        <div id="tc-st-texte-flottant" style="position:absolute;left:50%;top:20%;transform:translate(-50%,-50%);background:rgba(15,23,42,0.72);color:#fde047;padding:4px 10px;border-radius:8px;font-size:13px;font-weight:bold;cursor:grab;user-select:none;max-width:85%;text-align:center;"></div>
      </div>

      <div style="display:flex;align-items:center;justify-content:space-around;gap:8px;margin-top:10px;background:#1e293b;padding:8px;border-radius:10px;">
        <button type="button" id="tc-ico-soleil" title="Soleil / Couleurs" style="background:#0f172a;color:#fde047;border:1px solid #475569;border-radius:8px;padding:7px 12px;font-size:14px;cursor:pointer;">☀️</button>
        <button type="button" id="tc-ico-teinte" title="Teinte / Couleur" style="background:#0f172a;color:#38bdf8;border:1px solid #475569;border-radius:8px;padding:7px 12px;font-size:14px;cursor:pointer;">🎨</button>
        <button type="button" id="tc-ico-couper" title="Couper / Recadrer" style="background:#0f172a;color:#4ade80;border:1px solid #475569;border-radius:8px;padding:7px 12px;font-size:14px;cursor:pointer;">✂️</button>
      </div>

      <div id="tc-st-panneau-outil" style="display:none;margin-top:8px;background:#1e293b;border:1px solid #475569;border-radius:10px;padding:10px;"></div>

      <div style="margin-top:12px;background:#0f172a;border:1px solid #334155;border-radius:12px;padding:10px;">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px;">
          <strong style="font-size:12px;color:#fde047;">🎵 Chansons en ligne</strong>
          <span id="tc-st-chansons-count" style="font-size:11px;color:#86efac;">0 sélectionnée(s)</span>
        </div>
        <input type="search" id="tc-st-recherche-chanson" placeholder="Rechercher un artiste ou une chanson..." style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid #475569;background:#1e293b;color:#fff;font-size:12px;margin-bottom:8px;" />
        <div id="tc-st-liste-chansons" style="max-height:175px;overflow-y:auto;"></div>
      </div>
    `;

    document.body.appendChild(ecran);

    const selProd = document.getElementById("tc-st-select-produit");
    const prods = lireJson(CFG.cleProduitsLocal, []);
    prods.forEach(function (p) {
      if (!p || !p.nom) return;
      const opt = document.createElement("option");
      opt.value = p.id;
      opt.textContent = p.nom;
      selProd.appendChild(opt);
    });

    document.getElementById("tc-st-fermer-ecran").addEventListener("click", function () {
      stopperAudio();
      ecran.style.display = "none";
    });

    document.getElementById("tc-st-input-medias").addEventListener("change", async function (ev) {
      const files = Array.from(ev.target.files || []);
      if (!files.length) return;
      mediasChoisis = [];
      for (let i = 0; i < files.length; i++) {
        const f = files[i];
        const type = f.type && f.type.startsWith("video/") ? "video" : "image";
        const dataUrl = await new Promise(function (resolve) {
          const r = new FileReader();
          r.onload = function (e) { resolve(e.target.result); };
          r.readAsDataURL(f);
        });
        mediasChoisis.push({ dataUrl, type, nom: f.name });
      }
      document.getElementById("tc-st-resume-fichiers").textContent =
        `${mediasChoisis.length} média(s) sélectionné(s) (${mediasChoisis[0].type}).`;
      rafraichirApercuStudio();
    });

    document.getElementById("tc-st-input-audio-local").addEventListener("change", function (ev) {
      const f = ev.target.files && ev.target.files[0];
      if (!f) return;
      audioLocalUrl = URL.createObjectURL(f);
      audioLocalNom = f.name;
      document.getElementById("tc-st-resume-fichiers").textContent = `Audio téléphone : ${audioLocalNom}`;
      jouerPisteAudio(audioLocalUrl, true);
    });

    const inpTxt = document.getElementById("tc-st-texte-superpose");
    const txtFlot = document.getElementById("tc-st-texte-flottant");
    inpTxt.addEventListener("input", function () {
      txtFlot.textContent = inpTxt.value;
    });

    const stage = document.getElementById("tc-st-stage");
    let draggingTxt = false;
    txtFlot.addEventListener("pointerdown", function (ev) {
      ev.stopPropagation();
      draggingTxt = true;
    });
    stage.addEventListener("pointermove", function (ev) {
      if (!draggingTxt) return;
      const rect = stage.getBoundingClientRect();
      const x = Math.max(10, Math.min(90, ((ev.clientX - rect.left) / rect.width) * 100));
      const y = Math.max(10, Math.min(90, ((ev.clientY - rect.top) / rect.height) * 100));
      posTexte = { x, y };
      txtFlot.style.left = x + "%";
      txtFlot.style.top = y + "%";
    });
    window.addEventListener("pointerup", function () {
      draggingTxt = false;
    });

    const panneauOutil = document.getElementById("tc-st-panneau-outil");

    document.getElementById("tc-ico-soleil").addEventListener("click", function () {
      if (outilActif === "soleil") {
        outilActif = null;
        panneauOutil.style.display = "none";
        return;
      }
      outilActif = "soleil";
      panneauOutil.style.display = "block";
      panneauOutil.innerHTML =
        `<div style="font-size:11px;color:#fde047;margin-bottom:6px;">☀️ Soleil (Luminosité & Contraste)</div>` +
        `<input type="range" id="tc-range-sun" min="50" max="160" value="${filtreState.sun}" style="width:100%;" />` +
        `<input type="range" id="tc-range-con" min="60" max="160" value="${filtreState.contrast}" style="width:100%;margin-top:6px;" />`;

      document.getElementById("tc-range-sun").addEventListener("input", function (e) {
        filtreState.sun = Number(e.target.value);
        rafraichirApercuStudio();
      });
      document.getElementById("tc-range-con").addEventListener("input", function (e) {
        filtreState.contrast = Number(e.target.value);
        rafraichirApercuStudio();
      });
    });

    document.getElementById("tc-ico-teinte").addEventListener("click", function () {
      if (outilActif === "teinte") {
        outilActif = null;
        panneauOutil.style.display = "none";
        return;
      }
      outilActif = "teinte";
      panneauOutil.style.display = "block";
      panneauOutil.innerHTML =
        `<div style="font-size:11px;color:#38bdf8;margin-bottom:6px;">🎨 Couleur (Teinte & Saturation)</div>` +
        `<input type="range" id="tc-range-hue" min="0" max="360" value="${filtreState.hue}" style="width:100%;" />` +
        `<input type="range" id="tc-range-sat" min="0" max="220" value="${filtreState.sat}" style="width:100%;margin-top:6px;" />`;

      document.getElementById("tc-range-hue").addEventListener("input", function (e) {
        filtreState.hue = Number(e.target.value);
        rafraichirApercuStudio();
      });
      document.getElementById("tc-range-sat").addEventListener("input", function (e) {
        filtreState.sat = Number(e.target.value);
        rafraichirApercuStudio();
      });
    });

    document.getElementById("tc-ico-couper").addEventListener("click", function () {
      if (outilActif === "couper") {
        outilActif = null;
        panneauOutil.style.display = "none";
        return;
      }
      outilActif = "couper";
      panneauOutil.style.display = "block";
      panneauOutil.innerHTML =
        `<div style="font-size:11px;color:#4ade80;margin-bottom:6px;">✂️ Couper / Cadrage</div>` +
        `<div style="display:flex;gap:6px;flex-wrap:wrap;">` +
        `<button type="button" data-crop="none" class="tc-btn-crop" style="padding:5px 9px;border-radius:6px;border:none;cursor:pointer;">Original</button>` +
        `<button type="button" data-crop="1:1" class="tc-btn-crop" style="padding:5px 9px;border-radius:6px;border:none;cursor:pointer;">1:1</button>` +
        `<button type="button" data-crop="4:3" class="tc-btn-crop" style="padding:5px 9px;border-radius:6px;border:none;cursor:pointer;">4:3</button>` +
        `<button type="button" data-crop="16:9" class="tc-btn-crop" style="padding:5px 9px;border-radius:6px;border:none;cursor:pointer;">16:9</button>` +
        `</div>`;

      panneauOutil.querySelectorAll(".tc-btn-crop").forEach(function (b) {
        b.addEventListener("click", function () {
          filtreState.crop = b.getAttribute("data-crop") || "none";
          rafraichirApercuStudio();
        });
      });
    });

    const inpCh = document.getElementById("tc-st-recherche-chanson");
    let debCh = null;
    inpCh.addEventListener("input", function () {
      clearTimeout(debCh);
      debCh = setTimeout(function () {
        termeRechercheChanson = inpCh.value.trim();
        rechercherChansonsEnLigne(true);
      }, 300);
    });

    const listeChDom = document.getElementById("tc-st-liste-chansons");
    listeChDom.addEventListener("scroll", function () {
      if (listeChDom.scrollTop + listeChDom.clientHeight >= listeChDom.scrollHeight - 25) {
        rechercherChansonsEnLigne(false);
      }
    });

    document.getElementById("tc-st-publier-btn").addEventListener("click", async function () {
      const profil = obtenirProfilActuel();
      const texte = inpTxt.value.trim() || "Nouveau statut";
      const prodId = selProd.value;
      const prodObj = prods.find(function (x) { return x && x.id === prodId; }) || null;
      const chansonsArr = Array.from(chansonsSelectionnees.values());
      if (audioLocalUrl) {
        chansonsArr.unshift({
          id: "local_" + Date.now(),
          titre: audioLocalNom || "Son téléphone",
          artiste: "Téléphone",
          logo: "",
          previewUrl: audioLocalUrl
        });
      }

      const filtreCss = construireFiltreCss(filtreState);
      const listeActuelle = lireJson(CFG.cleStatutsLocal, []);
      const itemsACreer = mediasChoisis.length ? mediasChoisis : [{ dataUrl: profil.avatar || "", type: "image", nom: "" }];

      for (let i = 0; i < itemsACreer.length; i++) {
        const m = itemsACreer[i];
        const stObj = {
          id: "st_" + Date.now() + "_" + i + "_" + Math.random().toString(36).slice(2, 5),
          auteurKey: profil.key,
          auteurNom: profil.nom,
          avatar: profil.avatar,
          texte,
          textePos: { x: posTexte.x, y: posTexte.y },
          media: m.dataUrl,
          mediaType: m.type,
          filtreCss,
          cropMode: filtreState.crop,
          chansons: chansonsArr,
          produit: prodObj,
          dateTs: Date.now() + i
        };
        listeActuelle.unshift(stObj);
        await publierStatutFirebase(stObj);
      }

      ecrireJson(CFG.cleStatutsLocal, listeActuelle);
      stopperAudio();
      mediasChoisis = [];
      audioLocalUrl = "";
      chansonsSelectionnees.clear();
      inpTxt.value = "";
      document.getElementById("tc-st-resume-fichiers").textContent = "";
      ecran.style.display = "none";
      rendreBandeStatuts();
    });
  }

  function rafraichirApercuStudio() {
    const cont = document.getElementById("tc-st-apercu-media");
    if (!cont) return;
    cont.innerHTML = "";
    const premier = mediasChoisis[0];
    const css = construireFiltreCss(filtreState);
    const cropCss = construireCropStyle(filtreState.crop);

    if (premier && premier.type === "video") {
      const vid = document.createElement("video");
      vid.src = premier.dataUrl;
      vid.controls = true;
      vid.muted = true;
      vid.style.cssText = cropCss + `filter:${css};`;
      cont.appendChild(vid);
    } else if (premier && premier.dataUrl) {
      const img = document.createElement("img");
      img.src = premier.dataUrl;
      img.style.cssText = cropCss + `filter:${css};`;
      cont.appendChild(img);
    } else {
      cont.innerHTML = `<div style="padding:36px;color:#94a3b8;font-size:12px;">Sélectionne des images ou une vidéo</div>`;
    }
  }

  function ouvrirEcranCreationStatut() {
    creerEcranCreationStatut();
    mediasChoisis = [];
    audioLocalUrl = "";
    chansonsSelectionnees.clear();
    posTexte = { x: 50, y: 20 };
    filtreState = { sun: 100, contrast: 100, sat: 100, hue: 0, crop: "none" };
    outilActif = null;
    const pan = document.getElementById("tc-st-panneau-outil");
    if (pan) pan.style.display = "none";
    const txtFlot = document.getElementById("tc-st-texte-flottant");
    if (txtFlot) {
      txtFlot.textContent = "";
      txtFlot.style.left = "50%";
      txtFlot.style.top = "20%";
    }
    rafraichirApercuStudio();
    const ecran = document.getElementById("tc-ecran-creer-statut-js");
    if (ecran) ecran.style.display = "flex";
    rechercherChansonsEnLigne(true);
  }

  function creerVisionneuse() {
    if (!document.body || document.getElementById("tc-visionneuse-js")) return;
    const v = document.createElement("div");
    v.id = "tc-visionneuse-js";
    v.style.cssText =
      "display:none;position:fixed;inset:0;z-index:100002;background:#020617;color:#fff;flex-direction:column;justify-content:space-between;padding:12px;font-family:Arial,sans-serif;";
    v.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;">
        <div>
          <strong id="tc-vis-auteur" style="font-size:14px;"></strong>
          <span id="tc-vis-compteur" style="font-size:11px;color:#fde047;margin-left:8px;"></span>
        </div>
        <button type="button" id="tc-vis-fermer" style="background:#1e293b;color:#fff;border:1px solid #475569;border-radius:8px;padding:6px 12px;cursor:pointer;font-weight:bold;">✕</button>
      </div>
      <div id="tc-vis-zone-clic" style="flex:1;position:relative;display:flex;align-items:center;justify-content:center;overflow:hidden;cursor:pointer;margin:8px 0;">
        <div id="tc-vis-media-box" style="width:100%;max-width:460px;display:flex;align-items:center;justify-content:center;"></div>
        <div id="tc-vis-texte-box" style="position:absolute;transform:translate(-50%,-50%);background:rgba(15,23,42,0.75);color:#fde047;padding:5px 12px;border-radius:8px;font-weight:bold;font-size:14px;pointer-events:none;text-align:center;"></div>
      </div>
      <div id="tc-vis-pied" style="text-align:center;font-size:12px;color:#cbd5e1;padding-bottom:6px;">
        Clique dans la zone vide pour passer au suivant
      </div>
    `;
    document.body.appendChild(v);

    document.getElementById("tc-vis-fermer").addEventListener("click", function () {
      stopperAudio();
      sessionLecture = null;
      v.style.display = "none";
    });

    document.getElementById("tc-vis-zone-clic").addEventListener("click", function (ev) {
      if (!sessionLecture) return;
      const rect = ev.currentTarget.getBoundingClientRect();
      const relX = (ev.clientX - rect.left) / rect.width;
      if (relX < 0.25 && sessionLecture.index > 0) {
        sessionLecture.index--;
        afficherEtapeLecture();
      } else {
        sessionLecture.index++;
        if (sessionLecture.index >= sessionLecture.etapes.length) {
          stopperAudio();
          sessionLecture = null;
          v.style.display = "none";
        } else {
          afficherEtapeLecture();
        }
      }
    });
  }

  function afficherEtapeLecture() {
    if (!sessionLecture) return;
    const etape = sessionLecture.etapes[sessionLecture.index];
    if (!etape) return;

    document.getElementById("tc-vis-auteur").textContent = sessionLecture.auteurNom;
    document.getElementById("tc-vis-compteur").textContent =
      etape.estPhotoProfil
        ? "Photo de profil"
        : `${sessionLecture.index + 1} / ${sessionLecture.etapes.filter(function (x) { return !x.estPhotoProfil; }).length}`;

    const mediaBox = document.getElementById("tc-vis-media-box");
    mediaBox.innerHTML = "";
    stopperAudio();

    const cropCss = construireCropStyle(etape.cropMode || "none");
    const filtreCss = etape.filtreCss || "none";

    if (etape.media && etape.mediaType === "video") {
      const vid = document.createElement("video");
      vid.src = etape.media;
      vid.autoplay = true;
      vid.controls = true;
      vid.playsInline = true;
      vid.style.cssText = cropCss + `filter:${filtreCss};`;
      mediaBox.appendChild(vid);
      timerDureeVideo = setTimeout(function () {
        try { vid.pause(); } catch (_) {}
      }, 30000);
    } else if (etape.media) {
      const img = document.createElement("img");
      img.src = etape.media;
      img.style.cssText = cropCss + `filter:${filtreCss};`;
      mediaBox.appendChild(img);
    } else {
      mediaBox.innerHTML = `<div style="padding:30px;font-size:16px;font-weight:bold;">${etape.texte || sessionLecture.auteurNom}</div>`;
    }

    const txtBox = document.getElementById("tc-vis-texte-box");
    if (etape.texte && !etape.estPhotoProfil) {
      txtBox.style.display = "block";
      txtBox.textContent = etape.texte;
      txtBox.style.left = ((etape.textePos && etape.textePos.x) || 50) + "%";
      txtBox.style.top = ((etape.textePos && etape.textePos.y) || 20) + "%";
    } else {
      txtBox.style.display = "none";
    }

    const chPrem = Array.isArray(etape.chansons) && etape.chansons[0] ? etape.chansons[0] : null;
    if (chPrem && chPrem.previewUrl) {
      jouerPisteAudio(chPrem.previewUrl, true);
    }

    const infos = [];
    if (etape.produit && etape.produit.nom) infos.push("🛍️ " + etape.produit.nom);
    if (chPrem) infos.push("🎵 " + chPrem.titre + " — " + chPrem.artiste);
    document.getElementById("tc-vis-pied").textContent =
      (infos.length ? infos.join(" • ") + " — " : "") + "Clique dans la zone vide pour passer au suivant";
  }

  function lancerStatutsPuisPhotoProfil(auteurNom, statutsAuteur, photoProfil) {
    creerVisionneuse();
    const etapes = (statutsAuteur || []).map(function (st) {
      return Object.assign({}, st, { estPhotoProfil: false });
    });
    if (photoProfil) {
      etapes.push({
        auteurNom,
        texte: "Photo de profil",
        media: photoProfil,
        mediaType: "image",
        filtreCss: "none",
        cropMode: "none",
        chansons: [],
        estPhotoProfil: true
      });
    }
    if (!etapes.length) return;
    sessionLecture = { auteurNom, etapes, index: 0 };
    const v = document.getElementById("tc-visionneuse-js");
    if (v) v.style.display = "flex";
    afficherEtapeLecture();
  }

  function rendreBandeStatuts() {
    if (!document.body) return;
    let barre = document.getElementById("tc-bande-statuts-js");
    if (!barre) {
      barre = document.createElement("div");
      barre.id = "tc-bande-statuts-js";
      barre.style.cssText =
        "display:flex;align-items:center;gap:10px;overflow-x:auto;padding:8px 10px;margin:8px;background:#0f172a;border:1px solid #eab308;border-radius:12px;position:relative;z-index:50;font-family:Arial,sans-serif;";
      const cible = document.querySelector(".espace-flux");
      if (cible && cible.parentNode) {
        cible.parentNode.insertBefore(barre, cible);
      } else {
        document.body.insertBefore(barre, document.body.firstChild);
      }
    }

    barre.innerHTML = "";

    const btnPlus = document.createElement("div");
    btnPlus.style.cssText = "display:flex;flex-direction:column;align-items:center;gap:4px;min-width:68px;cursor:pointer;flex-shrink:0;";
    btnPlus.innerHTML =
      `<div style="width:54px;height:54px;border-radius:50%;background:#1e293b;border:2px dashed #fde047;color:#fde047;display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:bold;">+</div>` +
      `<span style="font-size:11px;color:#fff;font-weight:bold;">Statut</span>`;
    btnPlus.addEventListener("click", ouvrirEcranCreationStatut);
    barre.appendChild(btnPlus);

    const tous = lireJson(CFG.cleStatutsLocal, []);
    const groupes = new Map();
    tous.forEach(function (st) {
      const k = String(st.auteurKey || st.auteurNom || "u").toLowerCase();
      if (!groupes.has(k)) {
        groupes.set(k, { auteurNom: st.auteurNom || "Utilisateur", avatar: st.avatar || "", items: [] });
      }
      groupes.get(k).items.push(st);
    });

    groupes.forEach(function (grp) {
      const first = grp.items[0] || {};
      const item = document.createElement("div");
      item.style.cssText = "display:flex;flex-direction:column;align-items:center;gap:4px;min-width:72px;max-width:78px;cursor:pointer;flex-shrink:0;";

      const cercle = document.createElement("div");
      cercle.style.cssText =
        "width:56px;height:56px;border-radius:50%;padding:2px;background:linear-gradient(135deg,#fde047,#16a34a);display:flex;align-items:center;justify-content:center;overflow:hidden;";

      const ap = first.media || grp.avatar || "";
      if (ap && first.mediaType === "video") {
        cercle.innerHTML = `<video src="${ap}" muted style="width:100%;height:100%;border-radius:50%;object-fit:cover;filter:${first.filtreCss || "none"};"></video>`;
      } else if (ap) {
        cercle.innerHTML = `<img src="${ap}" alt="" style="width:100%;height:100%;border-radius:50%;object-fit:cover;filter:${first.filtreCss || "none"};" />`;
      } else {
        cercle.innerHTML = `<div style="width:100%;height:100%;border-radius:50%;background:#1e293b;color:#fde047;display:flex;align-items:center;justify-content:center;font-weight:bold;">${(grp.auteurNom || "U").charAt(0).toUpperCase()}</div>`;
      }

      const nom = document.createElement("span");
      nom.style.cssText = "font-size:11px;color:#f8fafc;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100%;text-align:center;";
      nom.textContent = grp.auteurNom;

      item.appendChild(cercle);
      item.appendChild(nom);
      item.addEventListener("click", function () {
        lancerStatutsPuisPhotoProfil(grp.auteurNom, grp.items, grp.avatar);
      });
      barre.appendChild(item);
    });
  }

  function initialiserStatutsStudio() {
    rendreBandeStatuts();
    chargerStatutsFirebase();
  }

  global.TC_StatutsStudioJS = {
    ouvrirCreation: ouvrirEcranCreationStatut,
    ouvrirLecture: lancerStatutsPuisPhotoProfil,
    rafraichir: rendreBandeStatuts
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initialiserStatutsStudio);
  } else {
    initialiserStatutsStudio();
  }
})(window);


/* ==========================================================================
   BLOC À COLLER DANS : fonction en ligne.js
   ========================================================================== */

(function () {
  const STORAGE_HISTORIQUE = "historique_sons_v1";
  const STORAGE_LOCAUX = "sons_locaux_v1";

  // Catalogue de sons réels (profil propre)
  const CATALOGUE_SONS_REELS = [
    {
      id: "trk-1",
      titre: "Mood",
      artiste: "Ninho",
      categorie: "son_en_ligne",
      duree: "03:12",
      url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
    },
    {
      id: "trk-2",
      titre: "DIE",
      artiste: "Gazo",
      categorie: "son_en_ligne",
      duree: "02:58",
      url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3"
    },
    {
      id: "trk-3",
      titre: "VVS",
      artiste: "Ninho",
      categorie: "son_en_ligne",
      duree: "03:24",
      url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3"
    },
    {
      id: "trk-4",
      titre: "CELINE 3X",
      artiste: "Gazo",
      categorie: "son_en_ligne",
      duree: "03:05",
      url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3"
    },
    {
      id: "trk-5",
      titre: "Jefe",
      artiste: "Ninho",
      categorie: "son_en_ligne",
      duree: "03:31",
      url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3"
    },
    {
      id: "trk-6",
      titre: "Kassav",
      artiste: "Gazo",
      categorie: "son_en_ligne",
      duree: "02:49",
      url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3"
    }
  ];

  const EtatEnLigne = {
    sonsAffiches: [],
    indexPage: 0,
    taillePage: 3,
    chargementEnCours: false,
    filtreActif: "tous", // changé UNIQUEMENT au clic sur les boutons du haut
    historique: chargerJSON(STORAGE_HISTORIQUE, []),
    sonsLocaux: chargerJSON(STORAGE_LOCAUX, [])
  };

  function chargerJSON(cle, valeurDefaut) {
    try {
      const brut = localStorage.getItem(cle);
      return brut ? JSON.parse(brut) : valeurDefaut;
    } catch (e) {
      return valeurDefaut;
    }
  }

  function sauvegarderJSON(cle, donnees) {
    try {
      localStorage.setItem(cle, JSON.stringify(donnees));
    } catch (e) {
      console.error("Erreur sauvegarde locale :", e);
    }
  }

  // Injecte le style du cercle qui tourne (spinner) sans toucher au HTML
  function injecterStyleSpinner() {
    if (document.getElementById("style-spinner-en-ligne")) return;
    const style = document.createElement("style");
    style.id = "style-spinner-en-ligne";
    style.textContent = `
      #spinner-chargement-sons {
        display: none;
        width: 28px;
        height: 28px;
        margin: 14px auto;
        border: 3px solid rgba(150, 150, 150, 0.25);
        border-top-color: #2563eb;
        border-radius: 50%;
        animation: rotationCercleSon 0.8s linear infinite;
      }
      #spinner-chargement-sons.actif {
        display: block;
      }
      @keyframes rotationCercleSon {
        to { transform: rotate(360deg); }
      }
    `;
    document.head.appendChild(style);
  }

  function obtenirOuCreerConteneurListe() {
    return (
      document.getElementById("liste-sons-en-ligne") ||
      document.querySelector("[data-liste-sons]") ||
      document.body
    );
  }

  function obtenirOuCreerSpinner(conteneur) {
    let spinner = document.getElementById("spinner-chargement-sons");
    if (!spinner) {
      spinner = document.createElement("div");
      spinner.id = "spinner-chargement-sons";
      conteneur.appendChild(spinner);
    }
    return spinner;
  }

  // Charge un lot de sons réels avec cercle qui tourne
  function chargerSonsAutomatiquement(reset = false) {
    if (!navigator.onLine) return;
    if (EtatEnLigne.chargementEnCours) return;

    if (reset) {
      EtatEnLigne.indexPage = 0;
      EtatEnLigne.sonsAffiches = [];
    }

    const debut = EtatEnLigne.indexPage * EtatEnLigne.taillePage;
    if (debut >= CATALOGUE_SONS_REELS.length) return;

    EtatEnLigne.chargementEnCours = true;
    const conteneur = obtenirOuCreerConteneurListe();
    const spinner = obtenirOuCreerSpinner(conteneur);
    spinner.classList.add("actif");

    setTimeout(() => {
      const lot = CATALOGUE_SONS_REELS.slice(debut, debut + EtatEnLigne.taillePage);
      EtatEnLigne.sonsAffiches = EtatEnLigne.sonsAffiches.concat(lot);
      EtatEnLigne.indexPage += 1;

      spinner.classList.remove("actif");
      EtatEnLigne.chargementEnCours = false;

      afficherSonsDansListe(EtatEnLigne.sonsAffiches);
    }, 650);
  }

  // Affiche les sons sans les re-trier automatiquement tout seul
  function afficherSonsDansListe(liste) {
    const conteneur = obtenirOuCreerConteneurListe();
    const spinner = obtenirOuCreerSpinner(conteneur);

    // Supprime les anciens éléments rendus par ce module
    conteneur.querySelectorAll(".item-son-reel").forEach((el) => el.remove());

    liste.forEach((son) => {
      const ligne = document.createElement("div");
      ligne.className = "item-son-reel";
      ligne.dataset.id = son.id;
      ligne.dataset.categorie = son.categorie || "son_en_ligne";
      ligne.style.cssText =
        "display:flex;justify-content:space-between;align-items:center;padding:10px;border-bottom:1px solid #eee;cursor:pointer;";

      ligne.innerHTML = `
        <div>
          <strong>${son.titre}</strong> — <span>${son.artiste}</span>
          <small style="opacity:0.7;"> (${son.duree || ""})</small>
        </div>
        <button type="button" class="btn-choisir-son">Choisir</button>
      `;

      ligne.addEventListener("click", () => {
        selectionnerSonEtAjouterHistorique(son);
      });

      conteneur.insertBefore(ligne, spinner);
    });
  }

  // Sélection d'un son -> ajout immédiat dans l'historique
  function selectionnerSonEtAjouterHistorique(son) {
    if (!son) return;

    const entreeHistorique = {
      id: son.id || "son-" + Date.now(),
      titre: son.titre || "Son sélectionné",
      artiste: son.artiste || "Artiste",
      categorie: son.categorie || "son_en_ligne",
      url: son.url || "",
      dateAjout: new Date().toISOString()
    };

    // Évite les doublons consécutifs tout en gardant l'historique complet
    EtatEnLigne.historique = [
      entreeHistorique,
      ...EtatEnLigne.historique.filter((item) => item.id !== entreeHistorique.id)
    ];

    sauvegarderJSON(STORAGE_HISTORIQUE, EtatEnLigne.historique);
    afficherHistorique();
  }

  // Rendu de l'historique quand on ouvre l'historique
  function afficherHistorique(cibleId = "zone-historique-sons") {
    const zone =
      document.getElementById(cibleId) ||
      document.querySelector("[data-historique-sons]");
    if (!zone) return;

    zone.innerHTML = "";

    if (!EtatEnLigne.historique.length) {
      zone.innerHTML = "<p>Aucun son dans l'historique.</p>";
      return;
    }

    EtatEnLigne.historique.forEach((item) => {
      const div = document.createElement("div");
      div.className = "item-historique-son";
      div.style.cssText = "padding:8px;border-bottom:1px solid #ddd;";
      div.innerHTML = `<strong>${item.titre}</strong> — <span>${item.artiste}</span>`;
      zone.appendChild(div);
    });
  }

  // Gestion des sons locaux (pour qu'ils soient bien visibles et sélectionnables)
  function enregistrerEtAfficherSonsLocaux(fichiersOuSons) {
    const liste = Array.isArray(fichiersOuSons)
      ? fichiersOuSons
      : Array.from(fichiersOuSons || []);

    const formates = liste.map((f, idx) => ({
      id: f.id || "local-" + Date.now() + "-" + idx,
      titre: f.titre || (f.name ? f.name.replace(/\.[^/.]+$/, "") : "Son local"),
      artiste: f.artiste || "Fichier local",
      categorie: "son_local",
      url: f.url || (f instanceof File ? URL.createObjectURL(f) : "")
    }));

    EtatEnLigne.sonsLocaux = [...formates, ...EtatEnLigne.sonsLocaux];
    sauvegarderJSON(STORAGE_LOCAUX, EtatEnLigne.sonsLocaux);
    afficherSonsDansListe(EtatEnLigne.sonsLocaux);
  }

  // Classement déclenché UNIQUEMENT quand on clique sur un bouton en haut
  function classerParBoutonHaut(categorieCible) {
    EtatEnLigne.filtreActif = categorieCible;

    if (categorieCible === "son_local") {
      afficherSonsDansListe(EtatEnLigne.sonsLocaux);
      return;
    }

    if (categorieCible === "historique") {
      afficherHistorique();
      return;
    }

    const source = EtatEnLigne.sonsAffiches.length
      ? EtatEnLigne.sonsAffiches
      : CATALOGUE_SONS_REELS;

    if (!categorieCible || categorieCible === "tous") {
      afficherSonsDansListe(source);
      return;
    }

    const filtres = source.filter((s) => s.categorie === categorieCible);
    afficherSonsDansListe(filtres);
  }

  // Branche les boutons du haut s'ils portent data-filtre-haut="son_local|image|video|son_en_ligne|historique"
  function attacherBoutonsDuHaut() {
    document.querySelectorAll("[data-filtre-haut]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const cat = btn.getAttribute("data-filtre-haut");
        classerParBoutonHaut(cat);
      });
    });
  }

  // Défilement vers le bas -> cercle qui tourne + chargement
  function attacherDefilementBas() {
    window.addEventListener(
      "scroll",
      () => {
        if (!navigator.onLine) return;
        const positionBas = window.innerHeight + window.scrollY;
        const seuil = document.documentElement.scrollHeight - 120;
        if (positionBas >= seuil) {
          chargerSonsAutomatiquement(false);
        }
      },
      { passive: true }
    );
  }

  // Initialisation automatique dès qu'il y a du réseau (sans clic)
  function initialiser() {
    injecterStyleSpinner();
    attacherBoutonsDuHaut();
    attacherDefilementBas();
    afficherHistorique();

    if (navigator.onLine) {
      chargerSonsAutomatiquement(true);
    }

    window.addEventListener("online", () => {
      chargerSonsAutomatiquement(true);
    });
  }

  // Exposition pratique pour appeler depuis ton code existant si besoin
  window.FonctionEnLigne = {
    init: initialiser,
    chargerSons: chargerSonsAutomatiquement,
    classerAuClic: classerParBoutonHaut,
    selectionnerSon: selectionnerSonEtAjouterHistorique,
    afficherHistorique: afficherHistorique,
    setSonsLocaux: enregistrerEtAfficherSonsLocaux
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initialiser);
  } else {
    initialiser();
  }
})();
