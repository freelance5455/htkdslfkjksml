// firebase-service.js
// Service centralisé Firebase pour Trading Commerce (Profil, Publications, Stats & IA)

const TradingFirebaseService = {
  // Remplace ces clés par celles de ta console Firebase quand tu branches Firebase
  config: {
    apiKey: "TA_API_KEY",
    authDomain: "TON_PROJET.firebaseapp.com",
    projectId: "TON_PROJET",
    storageBucket: "TON_PROJET.appspot.com",
    messagingSenderId: "TON_SENDER_ID",
    appId: "TON_APP_ID"
  },

  db: null,
  isReady: false,

  // 1. Initialisation de Firebase (si les scripts SDK Firebase sont chargés dans la page)
  init() {
    try {
      if (typeof firebase !== "undefined" && !firebase.apps.length) {
        firebase.initializeApp(this.config);
      }
      if (typeof firebase !== "undefined" && firebase.firestore) {
        this.db = firebase.firestore();
        this.isReady = true;
      }
    } catch (err) {
      console.warn("Mode local actif (Firebase non connecté) :", err);
      this.isReady = false;
    }
    return this.isReady;
  },

  // 2. Récupérer les stats du profil (Abonnés, J'aime, Vues, Images)
  async getUserStats(userId = "default_user") {
    if (this.isReady && this.db) {
      const doc = await this.db.collection("users").doc(userId).get();
      if (doc.exists) {
        const data = doc.data();
        return {
          abonnes: data.abonnes || 0,
          jaime: data.jaime || 0,
          vues: data.vues || 0,
          images: data.images || 0
        };
      }
    }

    // Repli local si hors ligne ou pas encore lié à Firestore
    const local = JSON.parse(localStorage.getItem("tc_stats_" + userId) || "null");
    return local || { abonnes: 0, jaim: 0, jaime: 0, vues: 0, images: 0 };
  },

  // 3. Mettre à jour un compteur (ex: +1 vue, +1 j'aime, +1 abonné)
  async incrementStat(userId = "default_user", field = "vues", amount = 1) {
    const allowed = ["abonnes", "jaime", "vues", "images"];
    if (!allowed.includes(field)) return;

    if (this.isReady && this.db) {
      const inc = firebase.firestore.FieldValue.increment(amount);
      await this.db.collection("users").doc(userId).set(
        { [field]: inc, updatedAt: Date.now() },
        { merge: true }
      );
    }

    const current = await this.getUserStats(userId);
    current[field] = Math.max(0, (current[field] || 0) + amount);
    localStorage.setItem("tc_stats_" + userId, JSON.stringify(current));
    return current;
  },

  // 4. Publier une image / un produit visible par tous
  async publishPost({ userId = "default_user", authorName = "Utilisateur", imageUrl = "", title = "", price = "" }) {
    const post = {
      id: "post_" + Date.now(),
      userId,
      authorName,
      imageUrl,
      title,
      price,
      likes: 0,
      views: 0,
      createdAt: new Date().toISOString()
    };

    if (this.isReady && this.db) {
      await this.db.collection("publications").doc(post.id).set(post);
    }

    const posts = await this.getPublicPosts();
    posts.unshift(post);
    localStorage.setItem("tc_posts", JSON.stringify(posts));
    await this.incrementStat(userId, "images", 1);
    return post;
  },

  // 5. Récupérer toutes les publications publiques (pour le fil et la grille 3x3)
  async getPublicPosts(limit = 30) {
    if (this.isReady && this.db) {
      const snap = await this.db
        .collection("publications")
        .orderBy("createdAt", "desc")
        .limit(limit)
        .get();
      if (!snap.empty) {
        return snap.docs.map(d => ({ id: d.id, ...d.data() }));
      }
    }

    return JSON.parse(localStorage.getItem("tc_posts") || "[]");
  },

  // 6. Préparer un résumé clair des données pour le module IA intelligent
  async getContextForAI(userId = "default_user") {
    const stats = await this.getUserStats(userId);
    const posts = await this.getPublicPosts(15);

    return {
      firebaseConnected: this.isReady,
      stats,
      totalPostsLoaded: posts.length,
      recentPosts: posts.slice(0, 5).map(p => ({
        title: p.title || "Sans titre",
        price: p.price || "Non précisé",
        likes: p.likes || 0,
        views: p.views || 0
      }))
    };
  }
};

window.TradingFirebaseService = TradingFirebaseService;