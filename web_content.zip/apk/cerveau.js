/* ====================================================================================
   TRADING COMMERCE - CERVEAU.JS (MOTEUR LOGIQUE GLOBAL, SÉCURITÉ & TRADUCTION)
   100% gratuit, sans abonnement, compatible hors ligne
   ==================================================================================== */

(function (window) {
    'use strict';

    // 1. DICTIONNAIRE GLOBAL DE TRADUCTION ET DES LIBELLÉS DE L'APPLICATION
    const TRADUCTIONS_APP = {
        fr: {
            appTitle: "Trading Commerce",
            menuTitle: "Menu Principal",
            langLbl: "🌐 Langue / Language :",
            mHome: "Accueil",
            mClients: "Profils Clients",
            mCalc: "Calculatrices & Devises",
            mProfil: "Mon Profil",
            mSettings: "Paramètres & Style",
            mSync: "Synchronisation QR",
            mClose: "Fermer le menu",
            online: "● En ligne",
            formTitle: "Enregistrer un mouvement",
            namePh: "Nom du client *",
            waPh: "Numéro WhatsApp (optionnel)",
            optCredit: "📥 Il a pris crédit (+)",
            optRepay: "📤 Il a remboursé (-)",
            optAdvance: "💵 Il a donné un peu d'avance (-)",
            optFinish: "✅ Règlement total (0)",
            amtPh: "Montant *",
            btnSave: "Enregistrer & Voir Profil",
            navAcc: "Accueil",
            navCli: "Clients",
            navCal: "Calc",
            navShare: "Partager",
            alertMsg: "Attention : Mets le nom et un montant correct !",
            errCalc: "Erreur de calcul",
            convTitle: "🌍 TOUT L'ARGENT DU MONDE ENTIER"
        },
        en: {
            appTitle: "Trading Commerce",
            menuTitle: "Main Menu",
            langLbl: "🌐 Language / Langue :",
            mHome: "Home",
            mClients: "Client Profiles",
            mCalc: "Calculators & Currencies",
            mProfil: "My Profile",
            mSettings: "Settings & Style",
            mSync: "QR Sync",
            mClose: "Close Menu",
            online: "● Online",
            formTitle: "Record a Movement",
            namePh: "Client Name *",
            waPh: "WhatsApp Number (optional)",
            optCredit: "📥 Took Credit (+)",
            optRepay: "📤 Repaid (-)",
            optAdvance: "💵 Advanced Payment (-)",
            optFinish: "✅ Full Payment (0)",
            amtPh: "Amount *",
            btnSave: "Save & View Profile",
            navAcc: "Home",
            navCli: "Clients",
            navCal: "Calc",
            navShare: "Share",
            alertMsg: "Warning: Please enter the name and a valid amount!",
            errCalc: "Calculation Error",
            convTitle: "🌍 ALL THE MONEY IN THE WORLD"
        },
        ar: {
            appTitle: "تجارة التداول",
            menuTitle: "القائمة الرئيسية",
            langLbl: "🌐 اللغة / Language:",
            mHome: "الرئيسية",
            mClients: "ملفات العملاء",
            mCalc: "الآلات الحاسبة والعملات",
            mProfil: "ملفي الشخصي",
            mSettings: "الإعدادات والنمط",
            mSync: "مزامنة QR",
            mClose: "إغلاق القائمة",
            online: "● متصل",
            formTitle: "تسجيل حركة",
            namePh: "اسم العميل *",
            waPh: "رقم واتساب (اختياري)",
            optCredit: "📥 أخذ كريدي/دين (+)",
            optRepay: "📤 سداد (-)",
            optAdvance: "💵 دفعة مقدمة (-)",
            optFinish: "✅ تسوية كاملة (0)",
            amtPh: "المبلغ *",
            btnSave: "حفظ وعرض الملف",
            navAcc: "الرئيسية",
            navCli: "العملاء",
            navCal: "حاسبة",
            navShare: "مشاركة",
            alertMsg: "تنبيه: أدخل الاسم والمبلغ بشكل صحيح!",
            errCalc: "خطأ في الحساب",
            convTitle: "🌍 كل أموال العالم"
        },
        zh: {
            appTitle: "贸易商业",
            menuTitle: "主菜单",
            langLbl: "🌐 语言 / Language:",
            mHome: "首页",
            mClients: "客户档案",
            mCalc: "计算器与货币",
            mProfil: "个人资料",
            mSettings: "设置与样式",
            mSync: "二维码同步",
            mClose: "关闭菜单",
            online: "● 在线",
            formTitle: "记录交易",
            namePh: "客户姓名 *",
            waPh: "WhatsApp 号码（可选）",
            optCredit: "📦 记账欠款 (+)",
            optRepay: "💵 还款 (-)",
            optAdvance: "💵 预付款 (-)",
            optFinish: "✅ 结清 (0)",
            amtPh: "金额 *",
            btnSave: "保存并查看资料",
            navAcc: "首页",
            navCli: "客户",
            navCal: "计算",
            navShare: "分享",
            alertMsg: "警告：请输入姓名和正确的金额！",
            errCalc: "计算错误",
            convTitle: "🌍 全世界的货币"
        }
    };

    // 2. TABLEAU DE TAUX DE CHANGE DE TOUTES LES MONNAIES DU MONDE (BASÉ SUR LE DOLLAR US)
    const TAUX_CHANGE_MONDE = {
        'USD': 1.0, 'EUR': 0.92, 'GBP': 0.79, 'CHF': 0.90, 'CAD': 1.36, 'AUD': 1.50, 'NZD': 1.63,
        'CNY': 7.20, 'JPY': 155.0, 'INR': 83.0, 'KRW': 1350.0, 'SGD': 1.35, 'HKD': 7.82,
        'THB': 36.5, 'IDR': 16000.0, 'MYR': 4.70, 'PHP': 56.0, 'VND': 25400.0, 'PKR': 278.0, 'BDT': 117.0,
        'XOF': 605.0, 'XAF': 605.0, 'GNF': 8600.0, 'NGN': 1450.0, 'GHS': 15.0, 'ZAR': 18.5,
        'KES': 130.0, 'MAD': 10.0, 'DZD': 134.0, 'TND': 3.12, 'EGP': 47.5, 'AOA': 835.0,
        'ETB': 57.0, 'UGX': 3800.0, 'RWF': 1300.0, 'BRL': 5.15, 'MXN': 17.0, 'ARS': 880.0,
        'COP': 3900.0, 'CLP': 950.0, 'PEN': 3.70, 'AED': 3.67, 'SAR': 3.75, 'QAR': 3.64, 'ILS': 3.70,
        'SEK': 10.8, 'NOK': 10.6, 'DKK': 6.88, 'PLN': 4.0, 'RUB': 91.0, 'UAH': 40.0, 'TRY': 32.2
    };

    // 3. OBJET CENTRAL DU CERVEAU (LOGIQUE AVANCÉE)
    window.CerveauApp = {
        TRADUCTIONS_APP: TRADUCTIONS_APP,
        TAUX_CHANGE_MONDE: TAUX_CHANGE_MONDE,

        init: function () {
            const langueActuelle = localStorage.getItem('tc_langue') || 'fr';
            this.appliquerDirectionLangue(langueActuelle);
            this.verifierIntegriteStockage();
        },

        appliquerDirectionLangue: function (lang) {
            if (lang === 'ar') {
                document.dir = 'rtl';
            } else {
                document.dir = 'ltr';
            }
        },

        formaterChiffresArabe: function (texte) {
            const lang = localStorage.getItem('tc_langue') || 'fr';
            if (lang !== 'ar') return texte;
            const mapChiffres = { '0': '٠', '1': '١', '2': '٢', '3': '٣', '4': '٤', '5': '٥', '6': '٦', '7': '٧', '8': '٨', '9': '٩' };
            return String(texte).replace(/[0-9]/g, match => mapChiffres[match]);
        },

        verifierIntegriteStockage: function () {
            if (!localStorage.getItem('tc_clients')) {
                localStorage.setItem('tc_clients', JSON.stringify([]));
            }
            if (!localStorage.getItem('tc_boutique')) {
                localStorage.setItem('tc_boutique', 'Trading Commerce');
            }
        },

        recupererClients: function () {
            try {
                return JSON.parse(localStorage.getItem('tc_clients')) || [];
            } catch (e) {
                return [];
            }
        },

        enregistrerMouvementClient: function (nomClient, numeroWhatsapp, typeOperation, montantValeur, codeDevise) {
            if (!nomClient || isNaN(montantValeur) || montantValeur <= 0) {
                return { succes: false, message: "Nom ou montant invalide." };
            }

            const clients = this.recupererClients();
            const clientExistant = clients.find(c => String(c.nom || '').toLowerCase() === String(nomClient).toLowerCase());
            const maintenant = new Date();
            const dateExacte = maintenant.toLocaleDateString() + " à " + maintenant.toLocaleTimeString();

            const nouveauMouvement = {
                action: typeOperation,
                montant: montantValeur,
                date: dateExacte
            };

            if (clientExistant) {
                const ancienSolde = parseFloat(clientExistant.solde || 0);

                if (typeOperation.includes("crédit") || typeOperation.includes("pris")) {
                    clientExistant.solde = ancienSolde + montantValeur;
                } else if (typeOperation.includes("remboursé") || typeOperation.includes("avance")) {
                    clientExistant.solde = Math.max(0, ancienSolde - montantValeur);
                } else if (typeOperation.includes("fini") || typeOperation.includes("total")) {
                    clientExistant.solde = 0;
                }

                if (!clientExistant.mouvements) clientExistant.mouvements = [];
                clientExistant.mouvements.push(nouveauMouvement);
                clientExistant.devise = codeDevise;
                if (numeroWhatsapp) clientExistant.whatsapp = numeroWhatsapp;
            } else {
                const soldeInitial = (typeOperation.includes("crédit") || typeOperation.includes("pris")) ? montantValeur : 0;
                clients.push({
                    nom: nomClient,
                    whatsapp: numeroWhatsapp || "Pas de numéro",
                    solde: soldeInitial,
                    devise: codeDevise,
                    mouvements: [nouveauMouvement]
                });
            }

            localStorage.setItem('tc_clients', JSON.stringify(clients));
            return { succes: true, message: "Mouvement enregistré avec succès !" };
        },

        convertirMonnaieMondiale: function (montant, deviseSource, deviseCible) {
            const montantNum = parseFloat(montant);
            if (isNaN(montantNum)) return 0;

            const tauxSrc = TAUX_CHANGE_MONDE[deviseSource] || 1.0;
            const tauxCib = TAUX_CHANGE_MONDE[deviseCible] || 1.0;

            const montantEnUSD = montantNum / tauxSrc;
            const resultatConverti = montantEnUSD * tauxCib;
            return resultatConverti.toFixed(2);
        },

        rechercherDansApplication: function (termeRecherche) {
            const query = String(termeRecherche || '').toLowerCase().trim();
            if (!query) return [];

            const resultatsFiltres = [];
            const pagesDisponibles = [
                { nom: "Profils Clients", url: "client.html", mots: ["client", "profil", "dette", "credit"] },
                { nom: "Calculatrices & Devises", url: "calculatrices.html", mots: ["calc", "calculatrice", "monnaie", "argent"] },
                { nom: "Paramètres & Style", url: "settings.html", mots: ["parametre", "reglages", "style"] },
                { nom: "Mon Profil", url: "modul2.html", mots: ["profil", "nom"] },
                { nom: "Synchronisation QR", url: "QRCode.html", mots: ["qr", "sync", "partager"] }
            ];

            pagesDisponibles.forEach(p => {
                if (p.nom.toLowerCase().includes(query) || p.mots.some(m => m.includes(query))) {
                    resultatsFiltres.push({ texte: `⚙️ Aller vers : ${p.nom}`, url: p.url });
                }
            });

            const clients = this.recupererClients();
            clients.forEach(c => {
                if (String(c.nom || '').toLowerCase().includes(query) || (c.whatsapp && String(c.whatsapp).includes(query))) {
                    resultatsFiltres.push({ texte: `👤 Client : ${c.nom} (${c.solde} ${c.devise})`, url: "client.html" });
                }
            });

            return resultatsFiltres;
        }
    };

    document.addEventListener('DOMContentLoaded', function () {
        window.CerveauApp.init();
    });
})(window);


/* =========================================================
   BLOC 1 (CLOUD) — LOGIQUE CERVEAU.JS
   ========================================================= */
(function () {
    const URL_TEST_CLOUD = "https://httpbin.org/get";

    const etatEl = document.getElementById("cloud-etat");
    const msgEl = document.getElementById("cloud-message");
    const btnTester = document.getElementById("btn-tester-cloud");
    const btnVider = document.getElementById("btn-vider-cloud");

    function afficherMessage(texte) {
        if (!msgEl) return;
        msgEl.textContent = texte;
    }

    function mettreAJourEtatReseau() {
        if (!etatEl) return;
        if (navigator.onLine) {
            etatEl.textContent = "En ligne";
            etatEl.classList.add("est-en-ligne");
        } else {
            etatEl.textContent = "Hors ligne";
            etatEl.classList.remove("est-en-ligne");
        }
    }

    async function testerServeur() {
        mettreAJourEtatReseau();
        if (!navigator.onLine) {
            afficherMessage("Pas de connexion internet sur l'appareil.");
            return;
        }

        afficherMessage("Test en cours...");
        try {
            const reponse = await fetch(URL_TEST_CLOUD, { cache: "no-store" });
            if (reponse.ok) {
                afficherMessage("Serveur en ligne accessible (OK).");
            } else {
                afficherMessage("Le serveur a répondu avec une erreur : " + reponse.status);
            }
        } catch (e) {
            afficherMessage("Impossible de joindre le serveur en ligne.");
        }
    }

    if (btnTester) {
        btnTester.addEventListener("click", testerServeur);
    }

    if (btnVider) {
        btnVider.addEventListener("click", function () {
            afficherMessage("Message effacé.");
        });
    }

    window.addEventListener("online", function () {
        mettreAJourEtatReseau();
        afficherMessage("Connexion internet revenue.");
    });

    window.addEventListener("offline", function () {
        mettreAJourEtatReseau();
        afficherMessage("Connexion internet coupée.");
    });

    mettreAJourEtatReseau();
})();


/* =========================================================
   BLOC 2 : LABEL INTELLIGENT, ANIMATIONS & REDIRECTION EN LIGNE
   ========================================================= */
(function () {
    const PAGE_CONNEXION_EN_LIGNE = "connexion-en-ligne.html";
    const PAGE_BASE_EN_LIGNE = "version-en-ligne.html";
    const CLE_SESSION_PROFIL_EN_LIGNE = "tc_session_profil_en_ligne";
    const TEXTE_EN_LIGNE = "En ligne";
    const TEXTE_HORS_LIGNE = "On n'est pas en ligne";
    const MESSAGE_HORS_LIGNE = "Veuillez vous connecter au réseau";

    function getRefs() {
        return {
            blocEtat: document.getElementById("tc-cadenas-jaune-ligne"),
            labelEtat: document.getElementById("tc-label-intelligent"),
            texteEtat: document.getElementById("tc-texte-intelligent"),
            boutonLigne: document.getElementById("tc-bouton-unique-ligne"),
            labelErreurBas: document.getElementById("tc-label-erreur-bas")
        };
    }

    function estEnLigneActuellement() {
        return Boolean(navigator.onLine);
    }

    function aUnProfilConnecte() {
        try {
            const brut = sessionStorage.getItem(CLE_SESSION_PROFIL_EN_LIGNE);
            if (!brut) return false;
            const data = JSON.parse(brut);
            return Boolean(data && data.email);
        } catch (e) {
            return false;
        }
    }

    function obtenirPageCibleEnLigne() {
        return aUnProfilConnecte() ? PAGE_BASE_EN_LIGNE : PAGE_CONNEXION_EN_LIGNE;
    }

    function mettreAJourLabelIntelligent() {
        const { blocEtat, labelEtat, texteEtat, labelErreurBas } = getRefs();
        const enLigne = estEnLigneActuellement();

        if (blocEtat) {
            blocEtat.classList.toggle("est-en-ligne", enLigne);
            blocEtat.classList.toggle("est-hors-ligne", !enLigne);
        }

        if (labelEtat) {
            labelEtat.classList.toggle("est-en-ligne", enLigne);
            labelEtat.classList.toggle("est-hors-ligne", !enLigne);
        }

        if (texteEtat) {
            texteEtat.textContent = enLigne ? TEXTE_EN_LIGNE : TEXTE_HORS_LIGNE;
        }

        if (enLigne && labelErreurBas) {
            labelErreurBas.textContent = "";
        }
    }

    document.addEventListener("click", function (event) {
        const btn = event.target.closest("#tc-bouton-unique-ligne");
        if (!btn) return;

        event.preventDefault();
        event.stopImmediatePropagation();

        const { labelErreurBas } = getRefs();
        const enLigne = estEnLigneActuellement();

        mettreAJourLabelIntelligent();

        if (!enLigne) {
            if (labelErreurBas) {
                labelErreurBas.textContent = MESSAGE_HORS_LIGNE;
            }
            return;
        }

        if (labelErreurBas) {
            labelErreurBas.textContent = "";
        }

        window.location.href = obtenirPageCibleEnLigne();
    }, true);

    window.addEventListener("online", mettreAJourLabelIntelligent);
    window.addEventListener("offline", mettreAJourLabelIntelligent);

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", mettreAJourLabelIntelligent);
    } else {
        mettreAJourLabelIntelligent();
    }
})();


/* =========================================================
   CADENAS CONNEXION VIA ICONE GOOGLE — CERVEAU.JS
   ========================================================= */
(function () {
    const GOOGLE_CLIENT_ID = "";
    const CLE_PROFIL_ACTIF = "tc_profil_email_actif";
    const CLE_DONNEES_PROFILS = "tc_profils_trading_commerce";

    function connecterEmailProfil(emailBrut) {
        const email = String(emailBrut || "").trim().toLowerCase();
        if (!email) return;

        let profils = {};
        try {
            profils = JSON.parse(localStorage.getItem(CLE_DONNEES_PROFILS) || "{}");
        } catch (e) {
            profils = {};
        }

        if (!profils[email]) {
            profils[email] = {
                email: email,
                creeLe: new Date().toLocaleString("fr-FR"),
                actions: []
            };
        }

        profils[email].actions.push({
            date: new Date().toLocaleTimeString("fr-FR"),
            libelle: "Connexion via Google",
            mode: navigator.onLine ? "Hors ligne + En ligne" : "Hors ligne"
        });

        localStorage.setItem(CLE_DONNEES_PROFILS, JSON.stringify(profils));
        localStorage.setItem(CLE_PROFIL_ACTIF, email);
        localStorage.setItem("tc_est_connecte", "true");
        localStorage.setItem("tc_connecte_en_ligne", "true");

        const inputEmail = document.getElementById("tc-input-email");
        const form = document.getElementById("tc-form-connexion-email");
        if (inputEmail && form) {
            inputEmail.value = email;
            form.dispatchEvent(new Event("submit", { cancelable: true }));
        }
    }

    function afficherListeEmailsEnregistres(conteneur) {
        let profils = {};
        try {
            profils = JSON.parse(localStorage.getItem(CLE_DONNEES_PROFILS) || "{}");
        } catch (e) {
            profils = {};
        }

        const emails = Object.keys(profils);
        conteneur.innerHTML = "";

        if (emails.length === 0) {
            const vide = document.createElement("div");
            vide.style.fontSize = "0.78rem";
            vide.style.color = "#475569";
            vide.textContent = "Aucune adresse e-mail enregistrée. Saisis-en une ci-dessus.";
            conteneur.appendChild(vide);
            return;
        }

        emails.forEach(function (email) {
            const btn = document.createElement("button");
            btn.type = "button";
            btn.className = "tc-item-email-google";
            btn.innerHTML = "<span>" + email + "</span><span>Connecter</span>";
            btn.addEventListener("click", function () {
                conteneur.classList.add("tc-cache");
                connecterEmailProfil(email);
            });
            conteneur.appendChild(btn);
        });
    }

    function initialiserBoutonGoogle() {
        const btnGoogle = document.getElementById("tc-btn-icone-google");
        const listeEmails = document.getElementById("tc-liste-emails-google");
        if (!btnGoogle || !listeEmails) return;

        btnGoogle.addEventListener("click", function () {
            if (GOOGLE_CLIENT_ID && window.google && window.google.accounts && window.google.accounts.oauth2) {
                const client = window.google.accounts.oauth2.initTokenClient({
                    client_id: GOOGLE_CLIENT_ID,
                    scope: "email profile openid",
                    callback: function (resp) {
                        if (resp && resp.access_token) {
                            fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
                                headers: { Authorization: "Bearer " + resp.access_token }
                            })
                                .then(function (r) { return r.json(); })
                                .then(function (info) {
                                    if (info && info.email) {
                                        connecterEmailProfil(info.email);
                                    }
                                });
                        }
                    }
                });
                client.requestAccessToken();
                return;
            }

            afficherListeEmailsEnregistres(listeEmails);
            listeEmails.classList.toggle("tc-cache");
        });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", initialiserBoutonGoogle);
    } else {
        initialiserBoutonGoogle();
    }
})();


/* =========================================================
   DONNÉES CLIENTS & STATISTIQUES TEMPS RÉEL
   ========================================================= */
(function () {
    const CLE_PROFILS = "tc_profils_clients";
    const CLE_STATS = "tc_stats_globales";
    const CLE_DERNIER_CLIENT = "tc_dernier_client";
    const CLE_DERNIER_MOUVEMENT = "tc_dernier_mouvement";
    const CLE_FLUX_LIVE = "tc_flux_trading_live";

    function tcFormaterMontant(val) {
        return Number(val || 0).toLocaleString("fr-FR", { maximumFractionDigits: 2 });
    }

    function tcDateCourte() {
        const d = new Date();
        return d.toLocaleDateString("fr-FR") + " " + d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
    }

    function tcLireFluxLive() {
        try {
            const raw = JSON.parse(localStorage.getItem(CLE_FLUX_LIVE) || '{"montants":[],"descentes":[]}');
            return {
                montants: Array.isArray(raw.montants) ? raw.montants : [],
                descentes: Array.isArray(raw.descentes) ? raw.descentes : []
            };
        } catch (e) {
            return { montants: [], descentes: [] };
        }
    }

    function tcSauvegarderFluxLive(flux) {
        localStorage.setItem(CLE_FLUX_LIVE, JSON.stringify({
            montants: (flux.montants || []).slice(0, 25),
            descentes: (flux.descentes || []).slice(0, 25)
        }));
    }

    function tcLireDonneesClients() {
        let profils = [];
        try {
            const raw = JSON.parse(localStorage.getItem(CLE_PROFILS) || "[]");
            profils = Array.isArray(raw) ? raw : [];
        } catch (e) {
            profils = [];
        }

        const totalEmprunts = profils.reduce((s, c) => s + (Number(c.totalEmprunt) || 0), 0);
        const totalRembourses = profils.reduce((s, c) => s + (Number(c.totalRembourse) || 0), 0);
        const resteAPayer = Math.max(0, totalEmprunts - totalRembourses);
        const soldeNet = totalRembourses - totalEmprunts;

        return {
            profils,
            fluxLive: tcLireFluxLive(),
            dernierClient: localStorage.getItem(CLE_DERNIER_CLIENT) || "",
            dernierMouvement: localStorage.getItem(CLE_DERNIER_MOUVEMENT) || "",
            stats: {
                totalClients: profils.length,
                totalEmprunts,
                totalRembourses,
                resteAPayer,
                soldeNet
            }
        };
    }

    function tcCalculerEtSauvegarderStats(profils) {
        const totalEmprunts = profils.reduce((s, c) => s + (Number(c.totalEmprunt) || 0), 0);
        const totalRembourses = profils.reduce((s, c) => s + (Number(c.totalRembourse) || 0), 0);
        const resteAPayer = Math.max(0, totalEmprunts - totalRembourses);
        const soldeNet = totalRembourses - totalEmprunts;

        const stats = {
            totalClients: profils.length,
            totalEmprunts,
            totalRembourses,
            resteAPayer,
            soldeNet,
            misAJourLe: tcDateCourte()
        };

        localStorage.setItem(CLE_STATS, JSON.stringify(stats));
        return stats;
    }

    function tcEnregistrerMouvementClient({
        nom,
        whatsapp = "",
        typeOp = "Il a pris crédit",
        montant,
        devise = "XOF",
        optionLabel = "",
        source = "index.html",
        verifierResteRemboursement = false
    }) {
        const nomClean = String(nom || "").trim();
        const montantNum = Number(String(montant ?? "").replace(/[^0-9.]/g, ""));

        if (!nomClean || !Number.isFinite(montantNum) || montantNum <= 0) {
            return { ok: false, erreur: "Nom du client ou montant invalide." };
        }

        const dataActuelle = tcLireDonneesClients();
        const profils = dataActuelle.profils.slice();
        const nowStr = tcDateCourte();
        const dev = devise || localStorage.getItem("tc_devise") || "XOF";

        const opNorm = String(typeOp || "").toLowerCase();
        const estEntree =
            opNorm.includes("rembours") ||
            opNorm.includes("payer") ||
            opNorm.includes("fini") ||
            opNorm === "rembourser" ||
            opNorm === "payer_avance";
        const estReglementTotal = opNorm.includes("fini de tout payer");
        const estSortie = !estEntree;

        const idx = profils.findIndex((p) => String(p.nom || "").toLowerCase() === nomClean.toLowerCase());
        const existant = idx >= 0 ? { ...profils[idx] } : null;

        const empruntActuel = existant ? (Number(existant.totalEmprunt) || 0) : 0;
        const rembourseActuel = existant ? (Number(existant.totalRembourse) || 0) : 0;
        const resteActuel = Math.max(0, empruntActuel - rembourseActuel);

        if (verifierResteRemboursement && estEntree && !estReglementTotal) {
            if (resteActuel <= 0) {
                return {
                    ok: false,
                    erreur: `Refusé : ${nomClean} n'a aucun emprunt actif à rembourser (reste dû : 0 ${dev}).`
                };
            }
            if (montantNum > resteActuel) {
                return {
                    ok: false,
                    erreur: `Refusé : ${nomClean} a ${tcFormaterMontant(resteActuel)} ${dev} à rembourser. Impossible de dépasser ce montant.`
                };
            }
        }

        const texteMouvement = estSortie
            ? `${nomClean} a emprunté ${tcFormaterMontant(montantNum)} ${dev}`
            : `${nomClean} a remboursé ${tcFormaterMontant(montantNum)} ${dev}`;

        let clientMaj;
        if (existant) {
            clientMaj = { ...existant };
            if (estSortie) {
                clientMaj.totalEmprunt = (Number(clientMaj.totalEmprunt) || 0) + montantNum;
                clientMaj.derniereDateEmprunt = nowStr;
            } else if (estReglementTotal) {
                clientMaj.totalRembourse = Number(clientMaj.totalEmprunt) || montantNum;
                clientMaj.derniereDateRemboursement = nowStr;
            } else {
                clientMaj.totalRembourse = (Number(clientMaj.totalRembourse) || 0) + montantNum;
                clientMaj.derniereDateRemboursement = nowStr;
            }
            clientMaj.resteAPayer = Math.max(0, (Number(clientMaj.totalEmprunt) || 0) - (Number(clientMaj.totalRembourse) || 0));
            clientMaj.soldeNet = (Number(clientMaj.totalRembourse) || 0) - (Number(clientMaj.totalEmprunt) || 0);
            if (whatsapp) clientMaj.whatsapp = String(whatsapp).trim();
            clientMaj.devise = dev;
            clientMaj.dateEnregistrement = nowStr;
            clientMaj.dernierMouvementTexte = texteMouvement;
            if (optionLabel) clientMaj.derniereOption = optionLabel;
            if (source) clientMaj.source = source;
            clientMaj.historique = Array.isArray(clientMaj.historique) ? clientMaj.historique.slice() : [];
            clientMaj.historique.unshift({
                date: nowStr,
                type: estSortie ? "emprunter" : "rembourser",
                option: optionLabel || typeOp,
                montant: montantNum,
                devise: dev,
                texte: texteMouvement,
                source
            });
            profils.splice(idx, 1);
            profils.unshift(clientMaj);
        } else {
            const totalEmprunt = estSortie ? montantNum : 0;
            const totalRembourse = estSortie ? 0 : montantNum;
            clientMaj = {
                nom: nomClean,
                whatsapp: String(whatsapp || "").trim(),
                devise: dev,
                totalEmprunt,
                totalRembourse,
                resteAPayer: Math.max(0, totalEmprunt - totalRembourse),
                soldeNet: totalRembourse - totalEmprunt,
                derniereDateEmprunt: estSortie ? nowStr : "-",
                derniereDateRemboursement: estSortie ? "-" : nowStr,
                dateEnregistrement: nowStr,
                dernierMouvementTexte: texteMouvement,
                derniereOption: optionLabel || typeOp,
                source,
                historique: [{
                    date: nowStr,
                    type: estSortie ? "emprunter" : "rembourser",
                    option: optionLabel || typeOp,
                    montant: montantNum,
                    devise: dev,
                    texte: texteMouvement,
                    source
                }]
            };
            profils.unshift(clientMaj);
        }

        const flux = tcLireFluxLive();
        const entreeFlux = {
            nom: nomClean,
            montant: montantNum,
            devise: dev,
            texte: texteMouvement,
            date: nowStr,
            sens: estSortie ? "down" : "up"
        };
        if (estSortie) {
            flux.descentes.unshift(entreeFlux);
        } else {
            flux.montants.unshift(entreeFlux);
        }
        tcSauvegarderFluxLive(flux);

        localStorage.setItem(CLE_PROFILS, JSON.stringify(profils));
        localStorage.setItem(CLE_DERNIER_CLIENT, nomClean);
        localStorage.setItem(CLE_DERNIER_MOUVEMENT, texteMouvement);
        localStorage.setItem("tc_dernier_profil_actif", JSON.stringify(clientMaj));
        localStorage.setItem("tc_profil_client_selectionne", nomClean);

        const stats = tcCalculerEtSauvegarderStats(profils);
        const payload = {
            profils,
            stats,
            fluxLive: flux,
            dernierClient: nomClean,
            dernierMouvement: texteMouvement,
            clientMaj,
            estSortie,
            montantNum
        };

        window.dispatchEvent(new CustomEvent("tc:client-update", { detail: payload }));
        tcActualiserPage();

        return { ok: true, ...payload };
    }

    function tcAppliquerAuxElementsData(data) {
        document.querySelectorAll("[data-tc]").forEach((el) => {
            const cle = el.getAttribute("data-tc");
            if (cle === "totalClients") el.innerText = data.stats.totalClients;
            else if (cle === "totalEmprunts") el.innerText = data.stats.totalEmprunts;
            else if (cle === "totalRembourses") el.innerText = data.stats.totalRembourses;
            else if (cle === "resteAPayer") el.innerText = data.stats.resteAPayer;
            else if (cle === "soldeNet") el.innerText = data.stats.soldeNet;
            else if (cle === "dernierClient") el.innerText = data.dernierClient;
            else if (cle === "dernierMouvement") el.innerText = data.dernierMouvement;
            else if (cle === "listeClients") {
                el.innerHTML = data.profils.map((c) => {
                    const reste = Math.max(0, (Number(c.totalEmprunt) || 0) - (Number(c.totalRembourse) || 0));
                    return `<div><strong>${c.nom || ""}</strong> — ${c.dernierMouvementTexte || ""} (Reste : ${reste} ${c.devise || "XOF"})</div>`;
                }).join("");
            }
        });
    }

    function tcActualiserPage() {
        const data = tcLireDonneesClients();
        tcAppliquerAuxElementsData(data);
        if (typeof window.onTradingCommerceUpdate === "function") {
            window.onTradingCommerceUpdate(data);
        }
    }

    window.tcLireDonneesClients = tcLireDonneesClients;
    window.tcCalculerEtSauvegarderStats = tcCalculerEtSauvegarderStats;
    window.tcEnregistrerMouvementClient = tcEnregistrerMouvementClient;
    window.tcActualiserPage = tcActualiserPage;
    window.tcFormaterMontant = tcFormaterMontant;

    window.addEventListener("tc:client-update", tcActualiserPage);
    window.addEventListener("storage", tcActualiserPage);

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", tcActualiserPage);
    } else {
        tcActualiserPage();
    }
})();


function allerVersChargementConnexion(email) {
    if (email) {
        localStorage.setItem("tc_email_connexion", email);
    }
    window.location.href = "chargement-connexion.html";
}


/* ============================================================================
   TRADUCTION GLOBALE + TRADUCTION DE TOUTES LES LETTRES ET CHIFFRES
   ============================================================================ */
(function () {
    const CLE_LANGUE = "tc_langue";
    const CLE_MODE_CARACTERES = "tc_mode_lettres_chiffres";
    const CLE_CACHE_TRAD = "tc_cache_traductions_v1";
    const CLE_COMPTES = "tc_comptes_enregistres";
    const CLE_COMPTE_ACTIF = "tc_compte_actif";

    const DICO_BASE = {
        fr: {
            "Paramètres & Langues": "Paramètres & Langues",
            "Paramètres": "Paramètres",
            "Retour": "Retour",
            "Langue de l'Application": "Langue de l'Application",
            "Accueil": "Accueil",
            "Clients": "Clients",
            "Profils Clients": "Profils Clients",
            "Mon Profil": "Mon Profil",
            "Tableau de bord": "Tableau de bord",
            "Calculatrices & Devises": "Calculatrices & Devises",
            "Paramètres & Style": "Paramètres & Style",
            "Synchronisation QR": "Synchronisation QR",
            "Fermer le menu": "Fermer le menu",
            "Enregistrer un mouvement": "Enregistrer un mouvement",
            "Enregistrer & Voir Profil Client": "Enregistrer & Voir Profil Client",
            "Partager": "Partager",
            "Version en ligne": "Version en ligne",
            "On n'est pas en ligne": "On n'est pas en ligne",
            "En ligne": "En ligne"
        },
        en: {
            "Paramètres & Langues": "Settings & Languages",
            "Paramètres": "Settings",
            "Retour": "Back",
            "Langue de l'Application": "App Language",
            "Accueil": "Home",
            "Clients": "Clients",
            "Profils Clients": "Client Profiles",
            "Mon Profil": "My Profile",
            "Tableau de bord": "Dashboard",
            "Calculatrices & Devises": "Calculators & Currencies",
            "Paramètres & Style": "Settings & Style",
            "Synchronisation QR": "QR Sync",
            "Fermer le menu": "Close Menu",
            "Enregistrer un mouvement": "Record a Movement",
            "Enregistrer & Voir Profil Client": "Save & View Client Profile",
            "Partager": "Share",
            "Version en ligne": "Online Version",
            "On n'est pas en ligne": "Offline",
            "En ligne": "Online"
        },
        ar: {
            "Paramètres & Langues": "الإعدادات واللغات",
            "Paramètres": "الإعدادات",
            "Retour": "رجوع",
            "Langue de l'Application": "لغة التطبيق",
            "Accueil": "الرئيسية",
            "Clients": "العملاء",
            "Profils Clients": "ملفات العملاء",
            "Mon Profil": "ملفي الشخصي",
            "Tableau de bord": "لوحة التحكم",
            "Calculatrices & Devises": "الآلات الحاسبة والعملات",
            "Paramètres & Style": "الإعدادات والنمط",
            "Synchronisation QR": "مزامنة QR",
            "Fermer le menu": "إغلاق القائمة",
            "Enregistrer un mouvement": "تسجيل حركة جديدة",
            "Enregistrer & Voir Profil Client": "حفظ وعرض ملف العميل",
            "Partager": "مشاركة",
            "Version en ligne": "النسخة عبر الإنترنت",
            "On n'est pas en ligne": "غير متصل بالإنترنت",
            "En ligne": "متصل"
        }
    };

    const LANGUES_CODES = {
        fr: "fr", français: "fr", french: "fr",
        en: "en", anglais: "en", english: "en",
        ar: "ar", arabe: "ar", arabic: "ar", العربية: "ar",
        es: "es", espagnol: "es", spanish: "es", español: "es",
        pt: "pt", portugais: "pt", portuguese: "pt", português: "pt",
        zh: "zh-CN", chinois: "zh-CN", chinese: "zh-CN", 中文: "zh-CN",
        hi: "hi", hindi: "hi", हिन्दी: "hi",
        ru: "ru", russe: "ru", russian: "ru", русский: "ru",
        de: "de", allemand: "de", german: "de", deutsch: "de",
        ja: "ja", japonais: "ja", japanese: "ja", 日本語: "ja",
        ko: "ko", coréen: "ko", korean: "ko", 한국어: "ko",
        tr: "tr", turc: "tr", turkish: "tr", türkçe: "tr",
        it: "it", italien: "it", italian: "it", italiano: "it",
        sw: "sw", swahili: "sw", kiswahili: "sw",
        ha: "ha", haoussa: "ha", hausa: "ha",
        yo: "yo", yoruba: "yo", yorùbá: "yo",
        ig: "ig", igbo: "ig",
        am: "am", amharique: "am", amharic: "am",
        so: "so", somali: "so",
        zu: "zu", zoulou: "zu", zulu: "zu",
        vi: "vi", vietnamien: "vi", vietnamese: "vi",
        id: "id", indonésien: "id", indonesian: "id",
        th: "th", thaï: "th", thai: "th"
    };

    const LANGUES_RTL = new Set(["ar", "fa", "ur", "he", "ps", "sd", "ug", "yi"]);

    // Tables de transposition de lettres et chiffres sur toute l'application
    const CHIFFRES_ARABES = { "0": "٠", "1": "١", "2": "٢", "3": "٣", "4": "٤", "5": "٥", "6": "٦", "7": "٧", "8": "٨", "9": "٩" };
    const CHIFFRES_PERSANS = { "0": "۰", "1": "۱", "2": "۲", "3": "۳", "4": "۴", "5": "۵", "6": "۶", "7": "۷", "8": "۸", "9": "۹" };
    const LETTRES_ARABES = {
        a: "أ", b: "ب", c: "ك", d: "د", e: "إ", f: "ف", g: "غ", h: "هـ",
        i: "ي", j: "ج", k: "ك", l: "ل", m: "م", n: "ن", o: "و", p: "ب",
        q: "ق", r: "ر", s: "س", t: "ت", u: "و", v: "ف", w: "و", x: "كس",
        y: "ي", z: "ز"
    };
    const LETTRES_CYRILLIQUES = {
        a: "а", b: "б", c: "ц", d: "д", e: "е", f: "ф", g: "г", h: "х",
        i: "и", j: "й", k: "к", l: "л", m: "м", n: "н", o: "о", p: "п",
        q: "к", r: "р", s: "с", t: "т", u: "у", v: "в", w: "в", x: "кс",
        y: "ы", z: "з"
    };
    const LETTRES_GRECQUES = {
        a: "α", b: "β", c: "κ", d: "δ", e: "ε", f: "φ", g: "γ", h: "η",
        i: "ι", j: "ζ", k: "κ", l: "λ", m: "μ", n: "ν", o: "ο", p: "π",
        q: "θ", r: "ρ", s: "σ", t: "τ", u: "υ", v: "β", w: "ω", x: "ξ",
        y: "ψ", z: "ζ"
    };

    function traduireLettresEtChiffres(texte, mode) {
        if (!texte) return texte;
        const m = String(mode || localStorage.getItem(CLE_MODE_CARACTERES) || "auto").toLowerCase();
        if (m === "aucun" || m === "off") return texte;

        let out = String(texte);

        // Chiffres
        if (m === "arabe" || m === "ar" || (m === "auto" && (localStorage.getItem(CLE_LANGUE) || "").toLowerCase().startsWith("ar"))) {
            out = out.replace(/[0-9]/g, ch => CHIFFRES_ARABES[ch] || ch);
        } else if (m === "persan" || m === "fa") {
            out = out.replace(/[0-9]/g, ch => CHIFFRES_PERSANS[ch] || ch);
        }

        // Lettres (uniquement si demandé explicitement via tc_mode_lettres_chiffres)
        let tableLettres = null;
        if (m === "lettres_arabe") tableLettres = LETTRES_ARABES;
        else if (m === "lettres_cyrillique") tableLettres = LETTRES_CYRILLIQUES;
        else if (m === "lettres_grec") tableLettres = LETTRES_GRECQUES;
        else if (m === "majuscules") return out.toUpperCase();
        else if (m === "minuscules") return out.toLowerCase();

        if (tableLettres) {
            out = out.replace(/[a-zA-Z]/g, ch => {
                const lower = ch.toLowerCase();
                const mapped = tableLettres[lower] || ch;
                return ch === ch.toUpperCase() ? mapped.toUpperCase() : mapped;
            });
        }

        return out;
    }

    function normaliserCodeLangue(valeur) {
        const clean = String(valeur || "fr").trim().toLowerCase();
        if (LANGUES_CODES[clean]) return LANGUES_CODES[clean];
        return clean || "fr";
    }

    function lireCache() {
        try {
            return JSON.parse(localStorage.getItem(CLE_CACHE_TRAD) || "{}");
        } catch (e) {
            return {};
        }
    }

    function ecrireCache(cache) {
        try {
            localStorage.setItem(CLE_CACHE_TRAD, JSON.stringify(cache));
        } catch (e) {}
    }

    async function traduireTexteEnLigne(texte, langueCible) {
        const code = normaliserCodeLangue(langueCible);
        if (!texte || !String(texte).trim() || code === "fr") {
            return traduireLettresEtChiffres(texte);
        }

        if (DICO_BASE[code] && DICO_BASE[code][texte.trim()]) {
            return traduireLettresEtChiffres(DICO_BASE[code][texte.trim()]);
        }

        const cache = lireCache();
        const cle = `${code}::${texte.trim()}`;
        if (cache[cle]) {
            return traduireLettresEtChiffres(cache[cle]);
        }

        if (!navigator.onLine) {
            return traduireLettresEtChiffres(texte);
        }

        try {
            const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=fr&tl=${encodeURIComponent(code)}&dt=t&q=${encodeURIComponent(texte.trim())}`;
            const res = await fetch(url);
            if (!res.ok) return traduireLettresEtChiffres(texte);
            const data = await res.json();
            const traduit = Array.isArray(data) && Array.isArray(data[0])
                ? data[0].map(morceau => morceau[0]).join("")
                : texte;

            if (traduit && traduit !== texte) {
                cache[cle] = traduit;
                ecrireCache(cache);
                return traduireLettresEtChiffres(traduit);
            }
        } catch (e) {}

        return traduireLettresEtChiffres(texte);
    }

    async function appliquerLangueGlobale(langueChoisie) {
        if (!document.body) return;

        const langueBrute = String(langueChoisie || localStorage.getItem(CLE_LANGUE) || "fr").trim();
        const code = normaliserCodeLangue(langueBrute);
        localStorage.setItem(CLE_LANGUE, langueBrute);

        const estRtl = LANGUES_RTL.has(code.split("-")[0]);
        document.documentElement.lang = code;
        document.documentElement.dir = estRtl ? "rtl" : "ltr";
        document.body.dir = estRtl ? "rtl" : "ltr";

        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
            acceptNode(node) {
                const parent = node.parentElement;
                if (!parent) return NodeFilter.FILTER_REJECT;
                const tag = parent.tagName;
                if (tag === "SCRIPT" || tag === "STYLE" || tag === "TEXTAREA" || tag === "INPUT" || tag === "OPTION" || tag === "SELECT") {
                    return NodeFilter.FILTER_REJECT;
                }
                const txt = node.nodeValue.trim();
                if (!txt || txt.length > 300) {
                    return NodeFilter.FILTER_REJECT;
                }
                return NodeFilter.FILTER_ACCEPT;
            }
        });

        const noeuds = [];
        while (walker.nextNode()) {
            const n = walker.currentNode;
            if (!n.__tcSourceText) {
                n.__tcSourceText = n.nodeValue;
            }
            noeuds.push(n);
        }

        for (const n of noeuds) {
            const sourceTrim = n.__tcSourceText.trim();
            const avant = n.__tcSourceText.match(/^\s*/)[0];
            const apres = n.__tcSourceText.match(/\s*$/)[0];

            if (code === "fr") {
                n.nodeValue = avant + traduireLettresEtChiffres(sourceTrim) + apres;
                continue;
            }

            if (DICO_BASE[code] && DICO_BASE[code][sourceTrim]) {
                n.nodeValue = avant + traduireLettresEtChiffres(DICO_BASE[code][sourceTrim]) + apres;
                continue;
            }

            const cache = lireCache();
            const cle = `${code}::${sourceTrim}`;
            if (cache[cle]) {
                n.nodeValue = avant + traduireLettresEtChiffres(cache[cle]) + apres;
                continue;
            }

            n.nodeValue = avant + traduireLettresEtChiffres(sourceTrim) + apres;
            traduireTexteEnLigne(sourceTrim, code).then(trad => {
                if (trad) {
                    n.nodeValue = avant + trad + apres;
                }
            });
        }

        const inputs = document.querySelectorAll("input[placeholder]");
        for (const inp of inputs) {
            if (!inp.dataset.tcSourcePh) {
                inp.dataset.tcSourcePh = inp.placeholder;
            }
            const phSource = inp.dataset.tcSourcePh;
            if (code === "fr") {
                inp.placeholder = traduireLettresEtChiffres(phSource);
            } else {
                const tradPh = await traduireTexteEnLigne(phSource, code);
                if (tradPh) inp.placeholder = tradPh;
            }
        }
    }

    function obtenirComptes() {
        try {
            const liste = JSON.parse(localStorage.getItem(CLE_COMPTES) || "[]");
            return Array.isArray(liste) ? liste : [];
        } catch (e) {
            return [];
        }
    }

    function sauvegarderComptes(liste) {
        localStorage.setItem(CLE_COMPTES, JSON.stringify(liste));
    }

    function synchroniserCompteActuelDansListe() {
        const nomBoutique = (localStorage.getItem("tc_boutique") || localStorage.getItem("tc_nom_profil") || "Trading Commerce").trim();
        const estConnecte = localStorage.getItem("tc_connecte_en_ligne") === "true" || localStorage.getItem("tc_est_connecte") === "true";
        if (!estConnecte || !nomBoutique) return;

        const comptes = obtenirComptes();
        const existe = comptes.find(c => String(c.nom || "").toLowerCase() === nomBoutique.toLowerCase());
        if (!existe) {
            comptes.unshift({
                id: "cpt_" + Date.now(),
                nom: nomBoutique,
                devise: localStorage.getItem("tc_devise") || "XOF",
                langue: localStorage.getItem(CLE_LANGUE) || "fr"
            });
            sauvegarderComptes(comptes);
        }
        localStorage.setItem(CLE_COMPTE_ACTIF, nomBoutique);
    }

    window.TC_CerveauTrad = {
        appliquerLangueGlobale,
        traduireTexteEnLigne,
        traduireLettresEtChiffres,
        normaliserCodeLangue,
        obtenirComptes,
        sauvegarderComptes,
        synchroniserCompteActuelDansListe
    };

    document.addEventListener("DOMContentLoaded", function () {
        synchroniserCompteActuelDansListe();
        const langueActuelle = localStorage.getItem(CLE_LANGUE) || "fr";
        appliquerLangueGlobale(langueActuelle);
    });
})();


/* ============================================================================
   ISOLATION COMPLÈTE DES DONNÉES PAR COMPTE (100% HORS LIGNE, LOCALSTORAGE)
   ============================================================================ */
(function () {
    const CLE_COMPTE_ACTIF = "tc_compte_actif";
    const CLE_COMPTES_LISTE = "tc_comptes_enregistres";
    const CLE_DATA_PAR_COMPTE = "tc_donnees_par_compte_v1";

    const CLES_ISOLABLES = [
        "tc_profils_clients",
        "tc_dernier_client",
        "tc_dernier_mouvement",
        "tc_devise"
    ];

    function obtenirNomCompteActif() {
        const actif = (
            localStorage.getItem(CLE_COMPTE_ACTIF) ||
            localStorage.getItem("tc_boutique") ||
            localStorage.getItem("tc_nom_profil") ||
            "Compte Principal"
        ).trim();
        return actif || "Compte Principal";
    }

    function lireTousLesComptesData() {
        try {
            const raw = localStorage.getItem(CLE_DATA_PAR_COMPTE);
            return raw ? JSON.parse(raw) : {};
        } catch (e) {
            return {};
        }
    }

    function ecrireTousLesComptesData(obj) {
        try {
            localStorage.setItem(CLE_DATA_PAR_COMPTE, JSON.stringify(obj));
        } catch (e) {}
    }

    function sauvegarderEtatCompteCourant(nomCompte) {
        const cible = (nomCompte || obtenirNomCompteActif()).trim();
        if (!cible) return;

        const allData = lireTousLesComptesData();
        const snap = allData[cible] || {};

        CLES_ISOLABLES.forEach((cle) => {
            const val = localStorage.getItem(cle);
            if (val !== null) {
                snap[cle] = val;
            } else {
                delete snap[cle];
            }
        });

        allData[cible] = snap;
        ecrireTousLesComptesData(allData);
    }

    function chargerEtatCompte(nomCompte, estNouveauCompte) {
        const cible = (nomCompte || "Compte Principal").trim();
        const allData = lireTousLesComptesData();

        if (estNouveauCompte || !allData[cible]) {
            allData[cible] = {
                tc_profils_clients: JSON.stringify([]),
                tc_dernier_client: "",
                tc_dernier_mouvement: "",
                tc_devise: localStorage.getItem("tc_devise") || "XOF"
            };
            ecrireTousLesComptesData(allData);
        }

        const snap = allData[cible] || {};
        CLES_ISOLABLES.forEach((cle) => {
            if (Object.prototype.hasOwnProperty.call(snap, cle) && snap[cle] !== undefined) {
                localStorage.setItem(cle, snap[cle]);
            } else if (cle === "tc_profils_clients") {
                localStorage.setItem(cle, JSON.stringify([]));
            } else if (cle === "tc_dernier_client" || cle === "tc_dernier_mouvement") {
                localStorage.setItem(cle, "");
            }
        });

        localStorage.setItem(CLE_COMPTE_ACTIF, cible);
        localStorage.setItem("tc_boutique", cible);
        localStorage.setItem("tc_nom_profil", cible);
        localStorage.setItem("tc_connecte_en_ligne", "true");
        localStorage.setItem("tc_est_connecte", "true");
    }

    function enregistrerCompteDansListe(nomCompte) {
        const nom = (nomCompte || "").trim();
        if (!nom) return;
        let liste = [];
        try {
            liste = JSON.parse(localStorage.getItem(CLE_COMPTES_LISTE) || "[]");
            if (!Array.isArray(liste)) liste = [];
        } catch (e) {
            liste = [];
        }
        if (!liste.some((c) => String(c.nom || "").toLowerCase() === nom.toLowerCase())) {
            liste.unshift({
                id: "cpt_" + Date.now(),
                nom: nom,
                creeLe: new Date().toLocaleString("fr-FR")
            });
            localStorage.setItem(CLE_COMPTES_LISTE, JSON.stringify(liste));
        }
    }

    const originalSetItem = localStorage.setItem.bind(localStorage);
    localStorage.setItem = function (key, value) {
        originalSetItem(key, value);
        if (CLES_ISOLABLES.includes(key) && !window.__tcSwitchEnCours) {
            sauvegarderEtatCompteCourant(obtenirNomCompteActif());
        }
    };

    window.TC_Comptes = {
        obtenirNomCompteActif,
        sauvegarderEtatCompteCourant,
        basculerVersCompte: function (nomCompte) {
            const cible = (nomCompte || "").trim();
            if (!cible) return;
            window.__tcSwitchEnCours = true;
            sauvegarderEtatCompteCourant(obtenirNomCompteActif());
            enregistrerCompteDansListe(cible);
            chargerEtatCompte(cible, false);
            window.__tcSwitchEnCours = false;
        },
        creerNouveauCompte: function (nomNouveauCompte) {
            const cible = (nomNouveauCompte || "").trim();
            if (!cible) return;
            window.__tcSwitchEnCours = true;
            sauvegarderEtatCompteCourant(obtenirNomCompteActif());
            enregistrerCompteDansListe(cible);
            chargerEtatCompte(cible, true);
            window.__tcSwitchEnCours = false;
        },
        obtenirListeComptes: function () {
            try {
                const liste = JSON.parse(localStorage.getItem(CLE_COMPTES_LISTE) || "[]");
                return Array.isArray(liste) ? liste : [];
            } catch (e) {
                return [];
            }
        }
    };

    document.addEventListener("DOMContentLoaded", function () {
        const actif = obtenirNomCompteActif();
        enregistrerCompteDansListe(actif);
        const allData = lireTousLesComptesData();
        if (!allData[actif]) {
            window.__tcSwitchEnCours = true;
            chargerEtatCompte(actif, false);
            window.__tcSwitchEnCours = false;
        } else {
            sauvegarderEtatCompteCourant(actif);
        }
    });
})();


/* ============================================================================
   MOTEUR PHYSIQUE 30 FPS & EXPORT SÉCURISÉ
   ============================================================================ */
(function (global) {
    "use strict";

    const FPS_CIBLE = 30;
    const INTERVALLE_MS = 1000 / FPS_CIBLE;

    const EtatPhysique = {
        actif: true,
        tempsDernierFrame: 0,
        accumulateurMs: 0,
        compteurFrames: 0,
        fpsReel: FPS_CIBLE,
        tempsFps: 0,
        rafId: null,
        callbacks: new Set(),
        vaguePhase: 0,
        vitesseVague: 1.6,
        amortissement: 0.92,
        rebondCarte: 0,
        velociteCarte: 0
    };

    function calculerSoldeClient(client) {
        if (!client || typeof client !== "object") return 0;
        const emprunt = Number(client.totalEmprunt ?? client.emprunt ?? client.credit ?? 0) || 0;
        const rembourse = Number(client.totalRembourse ?? client.rembourse ?? client.avance ?? 0) || 0;
        if (emprunt > 0 || rembourse > 0) {
            return Math.max(0, emprunt - rembourse);
        }
        if (typeof client.reste === "number") return Math.max(0, client.reste);
        if (typeof client.solde === "number") return Math.max(0, client.solde);
        if (typeof client.montant === "number") return Math.max(0, client.montant);
        return 0;
    }

    function normaliserClients() {
        try {
            const raw =
                localStorage.getItem("tc_profils_clients") ||
                localStorage.getItem("tc_clients") ||
                "[]";
            const liste = JSON.parse(raw);
            if (!Array.isArray(liste)) return [];

            const propre = liste.map((c) => {
                const solde = calculerSoldeClient(c);
                return Object.assign({}, c, {
                    reste: solde,
                    solde: solde,
                    montant: solde,
                    devise: c.devise || localStorage.getItem("tc_devise") || "XOF"
                });
            });

            localStorage.setItem("tc_profils_clients", JSON.stringify(propre));
            localStorage.setItem("tc_clients", JSON.stringify(propre));
            return propre;
        } catch (e) {
            return [];
        }
    }

    function pasPhysique(dtSec) {
        const dt = Math.min(dtSec, 0.05);
        EtatPhysique.vaguePhase = (EtatPhysique.vaguePhase + dt * EtatPhysique.vitesseVague) % (Math.PI * 2);

        const forceRappel = -140 * EtatPhysique.rebondCarte;
        EtatPhysique.velociteCarte = (EtatPhysique.velociteCarte + forceRappel * dt) * EtatPhysique.amortissement;
        EtatPhysique.rebondCarte += EtatPhysique.velociteCarte * dt;

        if (Math.abs(EtatPhysique.rebondCarte) < 0.0005 && Math.abs(EtatPhysique.velociteCarte) < 0.0005) {
            EtatPhysique.rebondCarte = 0;
            EtatPhysique.velociteCarte = 0;
        }

        const offsetPx = (EtatPhysique.rebondCarte * 6).toFixed(2);
        const decalageVague = (Math.sin(EtatPhysique.vaguePhase) * 4).toFixed(2);

        document.documentElement.style.setProperty("--tc-phys-vague-y", `${decalageVague}px`);
        document.documentElement.style.setProperty("--tc-phys-ressort-y", `${offsetPx}px`);

        EtatPhysique.callbacks.forEach((fn) => {
            try {
                fn(dt, EtatPhysique);
            } catch (e) {}
        });
    }

    function boucle30FPS(maintenant) {
        if (!EtatPhysique.actif) {
            EtatPhysique.rafId = null;
            return;
        }

        if (!EtatPhysique.tempsDernierFrame) {
            EtatPhysique.tempsDernierFrame = maintenant;
            EtatPhysique.tempsFps = maintenant;
        }

        const delta = maintenant - EtatPhysique.tempsDernierFrame;
        EtatPhysique.tempsDernierFrame = maintenant;
        EtatPhysique.accumulateurMs += delta;

        let pasExecutes = 0;
        while (EtatPhysique.accumulateurMs >= INTERVALLE_MS && pasExecutes < 2) {
            pasPhysique(INTERVALLE_MS / 1000);
            EtatPhysique.accumulateurMs -= INTERVALLE_MS;
            pasExecutes++;
            EtatPhysique.compteurFrames++;
        }

        if (pasExecutes >= 2) {
            EtatPhysique.accumulateurMs = 0;
        }

        if (maintenant - EtatPhysique.tempsFps >= 1000) {
            EtatPhysique.fpsReel = EtatPhysique.compteurFrames;
            EtatPhysique.compteurFrames = 0;
            EtatPhysique.tempsFps = maintenant;
        }

        EtatPhysique.rafId = global.requestAnimationFrame(boucle30FPS);
    }

    function demarrerMoteur() {
        if (EtatPhysique.rafId !== null) return;
        EtatPhysique.actif = true;
        EtatPhysique.tempsDernierFrame = 0;
        EtatPhysique.accumulateurMs = 0;
        EtatPhysique.rafId = global.requestAnimationFrame(boucle30FPS);
    }

    function arreterMoteur() {
        EtatPhysique.actif = false;
        if (EtatPhysique.rafId !== null) {
            global.cancelAnimationFrame(EtatPhysique.rafId);
            EtatPhysique.rafId = null;
        }
    }

    document.addEventListener("visibilitychange", function () {
        if (document.hidden) {
            arreterMoteur();
        } else {
            normaliserClients();
            demarrerMoteur();
        }
    });

    async function exporterImageSecurise(sourceCanvasOuDataUrl, nomFichier = "carte_ticket.png") {
        try {
            let blob = null;
            if (sourceCanvasOuDataUrl && typeof sourceCanvasOuDataUrl.toBlob === "function") {
                blob = await new Promise((resolve) => sourceCanvasOuDataUrl.toBlob(resolve, "image/png"));
            } else if (typeof sourceCanvasOuDataUrl === "string" && sourceCanvasOuDataUrl.startsWith("data:image")) {
                const resp = await fetch(sourceCanvasOuDataUrl);
                blob = await resp.blob();
            }
            if (!blob) return false;

            const fichier = new File([blob], nomFichier, { type: "image/png" });
            if (navigator.canShare && navigator.canShare({ files: [fichier] })) {
                await navigator.share({ files: [fichier], title: nomFichier });
                return true;
            }

            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = nomFichier;
            a.rel = "noopener";
            document.body.appendChild(a);
            a.click();
            a.remove();
            setTimeout(() => URL.revokeObjectURL(url), 4000);
            return true;
        } catch (e) {
            if (typeof sourceCanvasOuDataUrl === "string" && sourceCanvasOuDataUrl.startsWith("data:image")) {
                const fen = global.open("", "_blank");
                if (fen) {
                    fen.document.write(
                        `<title>${nomFichier}</title><body style="margin:0;background:#0f172a;display:flex;justify-content:center;align-items:center;min-height:100vh;"><img src="${sourceCanvasOuDataUrl}" style="max-width:100%;height:auto;"/></body>`
                    );
                }
            }
            return false;
        }
    }

    global.TC_Physique = {
        fpsCible: FPS_CIBLE,
        getFpsActuel: () => EtatPhysique.fpsReel,
        impulsionRessort: (force = 0.35) => {
            EtatPhysique.velociteCarte += force;
        },
        surTick: (fn) => {
            if (typeof fn === "function") EtatPhysique.callbacks.add(fn);
            return () => EtatPhysique.callbacks.delete(fn);
        },
        normaliserClients,
        calculerSoldeClient,
        exporterImageSecurise,
        demarrer: demarrerMoteur,
        arreter: arreterMoteur
    };

    document.addEventListener("DOMContentLoaded", function () {
        normaliserClients();
        demarrerMoteur();
    });
})(window);


/* ============================================================================
   MODULE SÉCURITÉ ANTI-INTRUSION (PIN + INTÉGRITÉ DE SESSION)
   ============================================================================ */
(function (global) {
    "use strict";

    const CLE_PIN_HASH = "tc_sec_pin_hash";
    const CLE_VERROU_ACTIF = "tc_sec_verrou_actif";
    const CLE_SESSION_DEVERROUILLEE = "tc_sec_session_ok";
    const CLE_TENTATIVES = "tc_sec_tentatives";

    function hashSimpleRapide(str) {
        let h1 = 0xdeadbeef;
        let h2 = 0x41c6ce57;
        const s = String(str || "");
        for (let i = 0; i < s.length; i++) {
            const ch = s.charCodeAt(i);
            h1 = Math.imul(h1 ^ ch, 2654435761);
            h2 = Math.imul(h2 ^ ch, 1597334677);
        }
        h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
        h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
        return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
    }

    async function calculerHashPin(pin) {
        const clean = String(pin || "").trim();
        if (!clean) return "";
        const sel = "TC_SECURE_2026::";
        if (global.crypto && global.crypto.subtle && typeof TextEncoder !== "undefined") {
            try {
                const buf = new TextEncoder().encode(sel + clean);
                const digest = await global.crypto.subtle.digest("SHA-256", buf);
                return Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, "0")).join("");
            } catch (e) {}
        }
        return hashSimpleRapide(sel + clean);
    }

    async function definirCodePin(nouveauPin) {
        const clean = String(nouveauPin || "").trim();
        if (clean.length < 4) {
            return { ok: false, message: "Le code PIN doit contenir au moins 4 caractères." };
        }
        const h = await calculerHashPin(clean);
        localStorage.setItem(CLE_PIN_HASH, h);
        localStorage.setItem(CLE_VERROU_ACTIF, "true");
        sessionStorage.setItem(CLE_SESSION_DEVERROUILLEE, "1");
        localStorage.setItem(CLE_TENTATIVES, "0");
        return { ok: true, message: "Code PIN activé et sécurisé." };
    }

    function desactiverCodePin() {
        localStorage.removeItem(CLE_PIN_HASH);
        localStorage.setItem(CLE_VERROU_ACTIF, "false");
        sessionStorage.removeItem(CLE_SESSION_DEVERROUILLEE);
    }

    function estVerrouillageActif() {
        return localStorage.getItem(CLE_VERROU_ACTIF) === "true" && Boolean(localStorage.getItem(CLE_PIN_HASH));
    }

    function estSessionDeverrouillee() {
        return sessionStorage.getItem(CLE_SESSION_DEVERROUILLEE) === "1";
    }

    async function verifierPin(pinSaisi) {
        if (!estVerrouillageActif()) return true;
        const tentatives = Number(localStorage.getItem(CLE_TENTATIVES) || "0");
        if (tentatives >= 5) {
            return { ok: false, message: "Trop de tentatives. Recharge la page pour réessayer." };
        }
        const hSaisi = await calculerHashPin(pinSaisi);
        const hStocke = localStorage.getItem(CLE_PIN_HASH);
        if (hSaisi && hSaisi === hStocke) {
            localStorage.setItem(CLE_TENTATIVES, "0");
            sessionStorage.setItem(CLE_SESSION_DEVERROUILLEE, "1");
            return { ok: true };
        }
        localStorage.setItem(CLE_TENTATIVES, String(tentatives + 1));
        return { ok: false, message: "Code PIN incorrect." };
    }

    function afficherEcranVerrouillagePin(onSucces) {
        if (!estVerrouillageActif() || estSessionDeverrouillee()) {
            if (typeof onSucces === "function") onSucces();
            return;
        }
        if (document.getElementById("tc-ecran-pin-securite")) return;

        const monter = () => {
            if (document.getElementById("tc-ecran-pin-securite")) return;
            const box = document.createElement("div");
            box.id = "tc-ecran-pin-securite";
            box.style.cssText = "position:fixed;inset:0;z-index:2147483647;background:#06242f;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:24px;font-family:sans-serif;";

            const titre = document.createElement("div");
            titre.textContent = "🔒 APPLICATION VERROUILLÉE";
            titre.style.cssText = "color:#e0f7fa;font-weight:800;font-size:1rem;";

            const inp = document.createElement("input");
            inp.type = "password";
            inp.inputMode = "numeric";
            inp.placeholder = "Entrez votre code PIN";
            inp.style.cssText = "padding:12px 14px;border-radius:12px;border:1.5px solid #26c6da;background:#0f172a;color:#fff;font-size:1rem;text-align:center;width:230px;outline:none;";

            const err = document.createElement("div");
            err.style.cssText = "color:#fca5a5;font-size:0.82rem;font-weight:700;min-height:18px;";

            const btn = document.createElement("button");
            btn.type = "button";
            btn.textContent = "Déverrouiller";
            btn.style.cssText = "padding:11px 22px;border-radius:12px;border:none;background:#26c6da;color:#06242f;font-weight:800;cursor:pointer;";

            btn.addEventListener("click", async () => {
                const res = await verifierPin(inp.value);
                if (res === true || res.ok) {
                    box.remove();
                    if (typeof onSucces === "function") onSucces();
                } else {
                    err.textContent = res.message || "Code incorrect";
                    inp.value = "";
                }
            });

            inp.addEventListener("keydown", (e) => {
                if (e.key === "Enter") btn.click();
            });

            box.appendChild(titre);
            box.appendChild(inp);
            box.appendChild(err);
            box.appendChild(btn);
            document.body.appendChild(box);
        };

        if (document.body) monter();
        else document.addEventListener("DOMContentLoaded", monter);
    }

    global.TC_Securite = {
        definirCodePin,
        desactiverCodePin,
        estVerrouillageActif,
        estSessionDeverrouillee,
        verifierPin,
        afficherEcranVerrouillagePin
    };
})(window);


/* ============================================================================
   CONNEXION UNIQUE + CIRCULATION 0% -> 100% + SORTIE PAR RÉDUCTION
   Sans texte "Chargement 1 / Chargement 2" — Compatible hors ligne
   ============================================================================ */
(function (global) {
    "use strict";

    var CLE_CONNECTE = "tc_est_connecte";
    var CLE_SESSION_LANCEE = "tc_session_lancee_mod1";
    var CLE_ACCES_MANUEL_MODULES = "tc_acces_manuel_modules";
    var CLE_PROFIL_ACTIF = "tc_profil_email_actif";
    var CLE_CONNECTE_LIGNE = "tc_connecte_en_ligne";

    var IMAGE_LOGO = "1795427340930.jpg";
    var CHEMINS_ALTERNATIFS = [
        "1795427340930.jpg",
        "1000134465_2.jpg",
        "icons/1795427340930.jpg",
        "icons/1000134465_2.jpg"
    ];

    function estConnecte() {
        if (localStorage.getItem(CLE_CONNECTE) === "true") return true;
        if (localStorage.getItem(CLE_CONNECTE_LIGNE) === "true") return true;
        if (localStorage.getItem(CLE_PROFIL_ACTIF)) return true;
        return false;
    }

    function marquerConnecteUneFois(emailOuNom) {
        localStorage.setItem(CLE_CONNECTE, "true");
        localStorage.setItem(CLE_CONNECTE_LIGNE, "true");
        sessionStorage.removeItem(CLE_ACCES_MANUEL_MODULES);
        if (emailOuNom) {
            localStorage.setItem(CLE_PROFIL_ACTIF, String(emailOuNom).trim());
        }
    }

    function autoriserAccesManuelModules(urlCible) {
        sessionStorage.setItem(CLE_ACCES_MANUEL_MODULES, "1");
        if (urlCible) {
            window.location.href = urlCible;
        }
    }

    function pageActuelle() {
        var p = (window.location.pathname.split("/").pop() || "index.html").toLowerCase();
        return p === "" ? "index.html" : p;
    }

    function cacherContenuPrincipalTemporairement() {
        if (document.body) {
            document.body.style.visibility = "hidden";
        }
    }

    function montrerContenuPrincipal() {
        if (document.body) {
            document.body.style.visibility = "visible";
        }
    }

    function pointerDepuisModule1() {
        sessionStorage.setItem(CLE_SESSION_LANCEE, "1");
        if (estConnecte()) {
            window.location.replace("index.html?fromMod1=1");
        } else {
            window.location.replace("modul2.html");
        }
    }

    function enregistrerConnexionModule5(cible) {
        marquerConnecteUneFois();
        sessionStorage.setItem(CLE_SESSION_LANCEE, "1");
        window.location.replace(cible || "index.html?fromMod1=1");
    }

    function seDeconnecter() {
        localStorage.setItem(CLE_CONNECTE, "false");
        localStorage.removeItem(CLE_CONNECTE);
        localStorage.removeItem(CLE_CONNECTE_LIGNE);
        sessionStorage.removeItem(CLE_SESSION_LANCEE);
        sessionStorage.removeItem(CLE_ACCES_MANUEL_MODULES);
        window.location.replace("modul1.html");
    }

    function verifierAccesModule(num) {
        var accesManuel = sessionStorage.getItem(CLE_ACCES_MANUEL_MODULES) === "1";
        if (Number(num) >= 2 && estConnecte() && !accesManuel) {
            window.location.replace("index.html?fromMod1=1");
            return false;
        }
        return true;
    }

    var __sortieEnCours = false;
    function reduireVersDehorsEtQuitter() {
        if (__sortieEnCours) return;
        __sortieEnCours = true;

        var cibleVisuelle = document.body || document.documentElement;
        if (cibleVisuelle) {
            cibleVisuelle.style.transformOrigin = "center center";
            cibleVisuelle.style.transition = "transform 0.34s cubic-bezier(0.4, 0, 0.8, 0.4), opacity 0.34s ease";
            cibleVisuelle.style.transform = "scale(0.12)";
            cibleVisuelle.style.opacity = "0";
        }

        setTimeout(function () {
            try {
                if (typeof navigator !== "undefined" && navigator.app && typeof navigator.app.exitApp === "function") {
                    navigator.app.exitApp();
                    return;
                }
            } catch (e) {}

            try {
                window.close();
            } catch (e) {}

            try {
                if (window.history && window.history.length > 1) {
                    window.history.go(-(window.history.length - 1));
                }
            } catch (e) {}

            setTimeout(function () {
                window.location.replace("about:blank");
            }, 120);
        }, 340);
    }

    function configurerRetourQuitterSurAccueil() {
        try {
            history.pushState({ tcAccueilSortie: true }, "", window.location.href);
            window.addEventListener("popstate", function () {
                if (pageActuelle() !== "index.html") return;
                reduireVersDehorsEtQuitter();
            });
        } catch (e) {}
    }

    function verifierEntreeIndex() {
        var params = new URLSearchParams(window.location.search);
        var depuisMod1 = params.get("fromMod1") === "1" ||
            (document.referrer && document.referrer.toLowerCase().indexOf("modul1") !== -1);

        if (!depuisMod1 && sessionStorage.getItem(CLE_SESSION_LANCEE) !== "1") {
            cacherContenuPrincipalTemporairement();
            window.location.replace("modul1.html");
            return false;
        }

        montrerContenuPrincipal();
        configurerRetourQuitterSurAccueil();
        return true;
    }

    function executerSurModul1() {
        montrerContenuPrincipal();

        // Si modul1.html a déjà sa propre barre / pourcentage, on le laisse piloter
        var barreExistante = document.getElementById("modul1Fill") || document.getElementById("barre-chargement-mod1");
        var pctExistante = document.getElementById("modul1Pct") || document.getElementById("pourcentage-chargement-mod1");
        if (barreExistante || pctExistante) {
            return;
        }

        if (document.getElementById("tc-mod1-circulation-overlay")) return;

        var overlay = document.createElement("div");
        overlay.id = "tc-mod1-circulation-overlay";
        overlay.style.cssText = [
            "position:fixed",
            "inset:0",
            "z-index:2147483646",
            "background:radial-gradient(circle at center, #0e5a68 0%, #050a14 100%)",
            "display:flex",
            "flex-direction:column",
            "align-items:center",
            "justify-content:center",
            "gap:16px",
            "padding:24px",
            "overflow:hidden"
        ].join(";");

        var rail = document.createElement("div");
        rail.style.cssText = "position:relative;width:240px;height:6px;border-radius:999px;background:rgba(255,255,255,0.16);overflow:hidden;";

        var runner = document.createElement("div");
        runner.style.cssText = "position:absolute;top:0;left:-40%;width:40%;height:100%;border-radius:999px;background:linear-gradient(90deg,transparent,#38bdf8,#10b981,transparent);animation:tcCirculerBar 1.4s linear infinite;";

        var styleAnim = document.createElement("style");
        styleAnim.textContent = "@keyframes tcCirculerBar { 0% { left: -40%; } 100% { left: 105%; } }";

        var cadre = document.createElement("div");
        cadre.style.cssText = "width:150px;height:150px;border-radius:32px;overflow:hidden;border:2px solid rgba(56,189,248,0.65);background:rgba(255,255,255,0.06);";

        var img = document.createElement("img");
        img.alt = IMAGE_LOGO;
        img.style.cssText = "width:100%;height:100%;object-fit:cover;display:block;";
        var idx = 0;
        img.onerror = function () {
            idx++;
            if (idx < CHEMINS_ALTERNATIFS.length) {
                img.src = CHEMINS_ALTERNATIFS[idx];
            }
        };
        img.src = CHEMINS_ALTERNATIFS[0];

        var pctLbl = document.createElement("div");
        pctLbl.textContent = "0%";
        pctLbl.style.cssText = "color:#38bdf8;font-family:sans-serif;font-weight:900;font-size:1.1rem;";

        var barreBg = document.createElement("div");
        barreBg.style.cssText = "width:240px;height:10px;border-radius:999px;background:rgba(255,255,255,0.18);overflow:hidden;";

        var barreFg = document.createElement("div");
        barreFg.style.cssText = "width:0%;height:100%;border-radius:999px;background:linear-gradient(90deg,#0284c7,#38bdf8,#10b981);";

        rail.appendChild(runner);
        cadre.appendChild(img);
        barreBg.appendChild(barreFg);
        overlay.appendChild(styleAnim);
        overlay.appendChild(cadre);
        overlay.appendChild(rail);
        overlay.appendChild(barreBg);
        overlay.appendChild(pctLbl);
        document.body.appendChild(overlay);

        var duree = 18000;
        var debut = Date.now();
        var timer = setInterval(function () {
            var p = Math.min(100, Math.round(((Date.now() - debut) / duree) * 100));
            barreFg.style.width = p + "%";
            pctLbl.textContent = p + "%";
            if (p >= 100) {
                clearInterval(timer);
                pointerDepuisModule1();
            }
        }, 100);
    }

    var __tcDemarrageLance = false;
    function executerAuDemarrage() {
        if (__tcDemarrageLance) return;
        __tcDemarrageLance = true;

        var page = pageActuelle();

        if (global.TC_Securite && global.TC_Securite.estVerrouillageActif && global.TC_Securite.estVerrouillageActif() && !global.TC_Securite.estSessionDeverrouillee()) {
            __tcDemarrageLance = false;
            global.TC_Securite.afficherEcranVerrouillagePin(function () {
                executerAuDemarrage();
            });
            return;
        }

        if (page === "index.html") {
            verifierEntreeIndex();
        } else if (page === "modul1.html") {
            if (document.body) {
                executerSurModul1();
            } else {
                __tcDemarrageLance = false;
                document.addEventListener("DOMContentLoaded", function () {
                    __tcDemarrageLance = true;
                    executerSurModul1();
                });
            }
        } else if (page === "modul2.html") {
            verifierAccesModule(2);
        } else if (page === "modul3.html") {
            verifierAccesModule(3);
        } else if (page === "modul4.html") {
            verifierAccesModule(4);
        } else if (page === "modul5.html") {
            verifierAccesModule(5);
        }
    }

    executerAuDemarrage();
    document.addEventListener("DOMContentLoaded", executerAuDemarrage);

    global.TC_CERVEAU = {
        estConnecte: estConnecte,
        marquerConnecteUneFois: marquerConnecteUneFois,
        autoriserAccesManuelModules: autoriserAccesManuelModules,
        pointerDepuisModule1: pointerDepuisModule1,
        enregistrerConnexionModule5: enregistrerConnexionModule5,
        seDeconnecter: seDeconnecter,
        verifierAccesModule: verifierAccesModule,
        verifierEntreeIndex: verifierEntreeIndex,
        reduireVersDehorsEtQuitter: reduireVersDehorsEtQuitter
    };
})(window);
