(function (global) {
  "use strict";

  const PROJECT_ID = "trading-commerce";
  const API_KEY = "AIzaSyAPEnpD8hfQNBZT1wpjSEh9E_OXsjsNiAU";
  const BASE_FIRESTORE =
    "https://firestore.googleapis.com/v1/projects/" +
    PROJECT_ID +
    "/databases/(default)/documents";

  const COL_STORIES = "stories_trading_commerce";
  const COL_PRODUITS = "produits_trading_commerce";

  const CLE_STORY_UNIQUE = "tc_story_unique_24h_v1";
  const CLE_STORIES_PUBLIC = "tc_stories_public_firebase_v1";
  const CLE_PRODUITS = "tc_produits_en_ligne_v1";
  const DUREE_24H = 24 * 60 * 60 * 1000;

  function lireJson(cle, defaut) {
    try {
      const val = JSON.parse(localStorage.getItem(cle) || "null");
      return val !== null && val !== undefined ? val : defaut;
    } catch (_) {
      return defaut;
    }
  }

  function ecrireJson(cle, val) {
    try {
      localStorage.setItem(cle, JSON.stringify(val));
    } catch (_) {}
  }

  function obtenirUtilisateurActuel() {
    let email = "";
    let nom = "";
    try {
      const sess = JSON.parse(sessionStorage.getItem("tc_session_profil_en_ligne") || "null");
      if (sess) {
        email = sess.email || "";
        nom = sess.nom || sess.pseudo || "";
      }
    } catch (_) {}

    const profilLocal = lireJson("tc_profil_tiktok_v1", null);
    if (profilLocal) {
      email = email || profilLocal.email || "";
      nom = nom || profilLocal.nom || profilLocal.pseudo || "";
    }

    email =
      email ||
      localStorage.getItem("tc_user_email") ||
      localStorage.getItem("tc_dernier_email_en_ligne") ||
      "";
    nom = nom || localStorage.getItem("tc_nom") || (email ? email.split("@")[0] : "Utilisateur");

    return {
      id: (email || nom || "anonyme").trim().toLowerCase(),
      email: String(email || "").trim(),
      nom: String(nom || "Utilisateur").trim()
    };
  }

  function extraireValeurChamp(field) {
    if (!field || typeof field !== "object") return "";
    if (typeof field.stringValue === "string") return field.stringValue;
    if (typeof field.integerValue !== "undefined") return Number(field.integerValue);
    if (typeof field.doubleValue !== "undefined") return Number(field.doubleValue);
    if (typeof field.booleanValue === "boolean") return field.booleanValue;
    if (field.arrayValue && Array.isArray(field.arrayValue.values)) {
      return field.arrayValue.values.map(extraireValeurChamp);
    }
    if (field.mapValue && field.mapValue.fields) {
      const obj = {};
      Object.keys(field.mapValue.fields).forEach(function (k) {
        obj[k] = extraireValeurChamp(field.mapValue.fields[k]);
      });
      return obj;
    }
    return "";
  }

  function documentVersObjet(doc) {
    const obj = {};
    const fields = (doc && doc.fields) || {};
    Object.keys(fields).forEach(function (cle) {
      obj[cle] = extraireValeurChamp(fields[cle]);
    });
    if (!obj.id && doc && doc.name) {
      obj.id = doc.name.split("/").pop();
    }
    return obj;
  }

  function afficherDiagnostic(texte) {
    let b = document.getElementById("tc-diag-firebase-public");
    if (!b) {
      b = document.createElement("div");
      b.id = "tc-diag-firebase-public";
      b.style.cssText =
        "margin:6px 0;padding:8px 10px;border-radius:10px;font-size:0.75rem;font-weight:bold;" +
        "background:#fef2f2;color:#991b1b;border:1px solid #fca5a5;";
      const ancres = document.querySelector(".espace-flux");
      if (ancres && ancres.parentNode) {
        ancres.parentNode.insertBefore(b, ancres);
      }
    }
    b.textContent = texte;
  }

  async function chargerStoriesPubliquesTousUtilisateurs() {
    const now = Date.now();
    let listeLocale = lireJson(CLE_STORIES_PUBLIC, []);
    if (!Array.isArray(listeLocale)) listeLocale = [];

    const storyUniqueLocale = lireJson(CLE_STORY_UNIQUE, null);
    if (storyUniqueLocale && (!storyUniqueLocale.expiresAt || Number(storyUniqueLocale.expiresAt) > now)) {
      const existeDeja = listeLocale.some(function (s) { return s && s.id === storyUniqueLocale.id; });
      if (!existeDeja) listeLocale.unshift(storyUniqueLocale);
    }

    listeLocale = listeLocale.filter(function (s) {
      return s && (!s.expiresAt || Number(s.expiresAt) > now);
    });

    if (navigator.onLine) {
      try {
        const res = await fetch(
          BASE_FIRESTORE + "/" + COL_STORIES + "?pageSize=100&key=" + API_KEY,
          { method: "GET", cache: "no-store" }
        );
        if (res.ok) {
          const data = await res.json();
          const docs = Array.isArray(data.documents) ? data.documents : [];
          const storiesDistantes = docs
            .map(documentVersObjet)
            .filter(function (st) {
              return st && st.id && st.public !== false && (!st.expiresAt || Number(st.expiresAt) > now);
            })
            .map(function (st) {
              let items = Array.isArray(st.items) ? st.items : [];
              if (!items.length && typeof st.itemsJson === "string" && st.itemsJson) {
                try { items = JSON.parse(st.itemsJson); } catch (_) { items = []; }
              }
              if (!items.length) {
                items = [
                  {
                    type: st.mediaType === "video" ? "video" : "image",
                    data: st.image || st.mediaUrl || "",
                    texte: st.texte || st.legende || ""
                  }
                ];
              }
              return {
                id: st.id,
                auteurId: st.auteurId || st.auteurNom || "utilisateur",
                auteurNom: st.auteurNom || st.auteur || "Utilisateur",
                auteurEmail: st.auteurEmail || "",
                texte: st.texte || st.legende || "",
                image: st.image || (items[0] && items[0].data) || "",
                createdAt: Number(st.createdAt || now),
                expiresAt: Number(st.expiresAt || now + DUREE_24H),
                likesStory: Number(st.likesStory || 0),
                public: true,
                items: items
              };
            });

          const mapParId = new Map();
          storiesDistantes.forEach(function (s) { mapParId.set(s.id, s); });
          listeLocale.forEach(function (s) {
            if (!mapParId.has(s.id)) mapParId.set(s.id, s);
          });

          const fusion = Array.from(mapParId.values()).sort(function (a, b) {
            return Number(b.createdAt || 0) - Number(a.createdAt || 0);
          });

          ecrireJson(CLE_STORIES_PUBLIC, fusion);
          return fusion;
        } else if (res.status === 403) {
          afficherDiagnostic(
            "Firebase bloque la lecture des stories (HTTP 403). Vérifie que les règles sont publiées."
          );
        }
      } catch (_) {}
    }

    return listeLocale;
  }

  async function publierStoryPublique(payload) {
    const user = obtenirUtilisateurActuel();
    const now = Date.now();
    const idStory =
      (payload && payload.id) ||
      "story_" + user.id.replace(/[^a-z0-9_-]/g, "_") + "_" + now + "_" + Math.random().toString(36).slice(2, 6);

    const mediaUrl = (payload && (payload.image || payload.data || payload.mediaUrl)) || "";
    const texte = String((payload && (payload.texte || payload.legende)) || "").trim();
    const auteurNom = String((payload && payload.auteurNom) || user.nom || "Utilisateur").trim();

    const items =
      payload && Array.isArray(payload.items) && payload.items.length
        ? payload.items
        : [{ type: payload && payload.mediaType === "video" ? "video" : "image", data: mediaUrl, texte: texte }];

    const storyObj = {
      id: idStory,
      auteurId: user.id,
      auteurNom: auteurNom,
      auteurEmail: user.email,
      texte: texte,
      image: mediaUrl,
      createdAt: now,
      expiresAt: now + DUREE_24H,
      likesStory: 0,
      public: true,
      items: items
    };

    ecrireJson(CLE_STORY_UNIQUE, storyObj);
    const actuelles = lireJson(CLE_STORIES_PUBLIC, []);
    const sansDoublon = (Array.isArray(actuelles) ? actuelles : []).filter(function (s) {
      return s && s.id !== idStory;
    });
    sansDoublon.unshift(storyObj);
    ecrireJson(CLE_STORIES_PUBLIC, sansDoublon);

    if (navigator.onLine) {
      const imageSafe = String(mediaUrl).length < 700000 ? String(mediaUrl) : "";
      const itemsSafe = items.map(function (it) {
        return {
          type: it.type || "image",
          data: String(it.data || "").length < 700000 ? String(it.data || "") : "",
          texte: String(it.texte || "")
        };
      });

      try {
        const res = await fetch(
          BASE_FIRESTORE + "/" + COL_STORIES + "/" + encodeURIComponent(idStory) + "?key=" + API_KEY,
          {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              fields: {
                id: { stringValue: idStory },
                auteurId: { stringValue: user.id },
                auteurNom: { stringValue: auteurNom },
                auteurEmail: { stringValue: user.email },
                texte: { stringValue: texte },
                image: { stringValue: imageSafe },
                itemsJson: { stringValue: JSON.stringify(itemsSafe) },
                createdAt: { integerValue: String(now) },
                expiresAt: { integerValue: String(storyObj.expiresAt) },
                likesStory: { integerValue: "0" },
                public: { booleanValue: true }
              }
            })
          }
        );
        if (!res.ok) {
          afficherDiagnostic(
            "Story enregistrée en local, mais refusée par Firebase (HTTP " + res.status + ")."
          );
        }
      } catch (_) {}
    }

    await rafraichirAffichageGlobal();
    return storyObj;
  }

  async function chargerPublicationsPubliquesTousUtilisateurs() {
    let locales = lireJson(CLE_PRODUITS, []);
    if (!Array.isArray(locales)) locales = [];

    if (navigator.onLine) {
      try {
        const res = await fetch(
          BASE_FIRESTORE + "/" + COL_PRODUITS + "?pageSize=120&key=" + API_KEY,
          { method: "GET", cache: "no-store" }
        );
        if (res.ok) {
          const data = await res.json();
          const docs = Array.isArray(data.documents) ? data.documents : [];
          const distantes = docs
            .map(documentVersObjet)
            .filter(function (p) {
              return p && p.id && String(p.nom || "").trim() && p.public !== false;
            })
            .map(function (p) {
              return Object.assign({}, p, {
                nom: String(p.nom || "").trim(),
                prix: p.prix || "",
                vendeur: p.vendeur || p.auteurNom || p.email || "Utilisateur",
                email: p.email || p.auteurEmail || "",
                vues: Number(p.vues || 0),
                likes: Number(p.likes || 0),
                public: true
              });
            });

          const mapProds = new Map();
          distantes.forEach(function (p) { mapProds.set(p.id, p); });
          locales.forEach(function (p) {
            if (p && p.id && !mapProds.has(p.id)) mapProds.set(p.id, p);
          });

          const fusion = Array.from(mapProds.values()).sort(function (a, b) {
            return Number(b.createdAt || b.dateTs || 0) - Number(a.createdAt || a.dateTs || 0);
          });

          ecrireJson(CLE_PRODUITS, fusion);
          return fusion;
        }
      } catch (_) {}
    }

    return locales;
  }

  async function publierPublicationPublique(prodPayload) {
    const user = obtenirUtilisateurActuel();
    const now = Date.now();
    const idProd =
      (prodPayload && prodPayload.id) ||
      "pub_" + user.id.replace(/[^a-z0-9_-]/g, "_") + "_" + now + "_" + Math.random().toString(36).slice(2, 6);

    const pubObj = Object.assign({}, prodPayload || {}, {
      id: idProd,
      nom: String((prodPayload && prodPayload.nom) || "").trim(),
      prix: String((prodPayload && prodPayload.prix) || ""),
      categorie: String((prodPayload && prodPayload.categorie) || "En vedette"),
      ville: String((prodPayload && prodPayload.ville) || ""),
      numero: String((prodPayload && prodPayload.numero) || ""),
      vendeur: String((prodPayload && prodPayload.vendeur) || user.nom),
      auteurNom: user.nom,
      auteurId: user.id,
      email: (prodPayload && prodPayload.email) || user.email,
      image: String((prodPayload && prodPayload.image) || ""),
      vues: Number((prodPayload && prodPayload.vues) || 0),
      likes: Number((prodPayload && prodPayload.likes) || 0),
      createdAt: now,
      public: true
    });

    const actuels = lireJson(CLE_PRODUITS, []);
    const liste = [pubObj].concat(
      (Array.isArray(actuels) ? actuels : []).filter(function (p) { return p && p.id !== idProd; })
    );
    ecrireJson(CLE_PRODUITS, liste);

    if (navigator.onLine) {
      const imgSafe = pubObj.image.length < 700000 ? pubObj.image : "";
      try {
        const res = await fetch(
          BASE_FIRESTORE + "/" + COL_PRODUITS + "/" + encodeURIComponent(idProd) + "?key=" + API_KEY,
          {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              fields: {
                id: { stringValue: pubObj.id },
                nom: { stringValue: pubObj.nom },
                prix: { stringValue: pubObj.prix },
                categorie: { stringValue: pubObj.categorie },
                ville: { stringValue: pubObj.ville },
                numero: { stringValue: pubObj.numero },
                vendeur: { stringValue: pubObj.vendeur },
                auteurNom: { stringValue: pubObj.auteurNom },
                auteurId: { stringValue: pubObj.auteurId },
                email: { stringValue: pubObj.email },
                image: { stringValue: imgSafe },
                vues: { integerValue: String(pubObj.vues) },
                likes: { integerValue: String(pubObj.likes) },
                createdAt: { integerValue: String(pubObj.createdAt) },
                public: { booleanValue: true }
              }
            })
          }
        );
        if (!res.ok) {
          afficherDiagnostic(
            "Publication locale enregistrée, mais refusée par Firebase (HTTP " + res.status + ")."
          );
        }
      } catch (_) {}
    }

    await rafraichirAffichageGlobal();
    return pubObj;
  }

  function rendreStoriesPubliquesDansBarre(stories) {
    const barre = document.getElementById("tc-barre-statuts-haut");
    if (!barre) return;

    const liste = Array.isArray(stories) ? stories : [];
    const existants = new Set(
      Array.from(barre.querySelectorAll("[data-story-id]")).map(function (el) {
        return el.getAttribute("data-story-id");
      })
    );

    liste.forEach(function (st) {
      if (!st || !st.id || existants.has(st.id)) return;
      existants.add(st.id);

      const item = document.createElement("div");
      item.className = "tc-statut-item";
      item.setAttribute("data-story-id", st.id);
      item.style.maxWidth = "120px";
      item.style.minWidth = "88px";

      const anneau = document.createElement("div");
      anneau.className = "tc-statut-anneau";

      const premiereImage = st.image || (st.items && st.items[0] && st.items[0].data) || "";
      if (premiereImage) {
        const img = document.createElement("img");
        img.src = premiereImage;
        img.alt = st.auteurNom || "Story";
        anneau.appendChild(img);
      } else {
        const init = document.createElement("div");
        init.className = "tc-statut-initiale";
        init.textContent = String(st.auteurNom || "U").charAt(0).toUpperCase();
        anneau.appendChild(init);
      }

      const nomEl = document.createElement("div");
      nomEl.className = "tc-statut-nom";
      nomEl.textContent = st.auteurNom || "Utilisateur";

      const apercuEl = document.createElement("div");
      apercuEl.className = "tc-statut-apercu-texte";
      apercuEl.textContent = st.texte || "Story publique";

      item.appendChild(anneau);
      item.appendChild(nomEl);
      item.appendChild(apercuEl);

      item.addEventListener("click", function () {
        ecrireJson(CLE_STORY_UNIQUE, st);
        const premiereStory = barre.querySelector(".tc-statut-item:not([href])");
        if (premiereStory && premiereStory !== item) {
          premiereStory.click();
        } else {
          const vis = document.getElementById("tc-visionneuse-statuts");
          const auteurVis = document.getElementById("tc-visionneuse-auteur");
          const cadreVis = document.getElementById("tc-visionneuse-cadre-media");
          const legVis = document.getElementById("tc-visionneuse-legenda");
          if (vis && cadreVis && legVis) {
            if (auteurVis) auteurVis.textContent = st.auteurNom || "Story publique";
            cadreVis.innerHTML = premiereImage
              ? '<img src="' + premiereImage + '" alt="' + String(st.auteurNom || "Story").replace(/"/g, "&quot;") + '" />'
              : '<div style="padding:24px;font-weight:bold;font-size:1.1rem;">' + String(st.texte || "Story").replace(/</g, "&lt;") + "</div>";
            legVis.innerHTML =
              '<div style="font-weight:bold;color:#fde047;">' + String(st.auteurNom || "Utilisateur").replace(/</g, "&lt;") + "</div>" +
              '<div style="font-size:0.86rem;margin-top:4px;">' + String(st.texte || "").replace(/</g, "&lt;") + "</div>";
            vis.classList.add("ouvert");
          }
        }
      });

      barre.appendChild(item);
    });
  }

  async function rafraichirAffichageGlobal() {
    const stories = await chargerStoriesPubliquesTousUtilisateurs();
    await chargerPublicationsPubliquesTousUtilisateurs();
    rendreStoriesPubliquesDansBarre(stories);

    const champRecherche = document.getElementById("champ-recherche");
    if (champRecherche) {
      champRecherche.dispatchEvent(new Event("input", { bubbles: true }));
    }
  }

  global.TC_FonctionEnLigne = {
    obtenirUtilisateurActuel: obtenirUtilisateurActuel,
    chargerStoriesPubliquesTousUtilisateurs: chargerStoriesPubliquesTousUtilisateurs,
    publierStoryPublique: publierStoryPublique,
    chargerPublicationsPubliquesTousUtilisateurs: chargerPublicationsPubliquesTousUtilisateurs,
    publierPublicationPublique: publierPublicationPublique,
    rafraichirAffichageGlobal: rafraichirAffichageGlobal
  };

  function demarrer() {
    rafraichirAffichageGlobal();
    setInterval(function () {
      if (navigator.onLine) {
        chargerStoriesPubliquesTousUtilisateurs().then(rendreStoriesPubliquesDansBarre);
        chargerPublicationsPubliquesTousUtilisateurs().then(function () {
          const champRecherche = document.getElementById("champ-recherche");
          if (champRecherche) champRecherche.dispatchEvent(new Event("input", { bubbles: true }));
        });
      }
    }, 20000);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", demarrer);
  } else {
    demarrer();
  }
})(window);