// Cache-first app shell + Leaflet. Tiles and routing are left to the browser HTTP cache,
// which honours the providers' Cache-Control headers. Bump V to ship an update.
const V='wander-v3',L='https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/';
const SHELL=['./','index.html','style.css','manifest.webmanifest','icon.svg',...['app','data','geo','mapview','route','settings','stats'].map(n=>`js/${n}.js`),L+'leaflet.js',L+'leaflet.css'];
addEventListener('install',e=>e.waitUntil(caches.open(V).then(c=>c.addAll(SHELL)).then(()=>skipWaiting())));
addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==V).map(x=>caches.delete(x)))).then(()=>clients.claim())));
addEventListener('fetch',e=>{
  const u=new URL(e.request.url);
  if(e.request.method!=='GET'||(u.origin!==location.origin&&u.hostname!=='cdnjs.cloudflare.com'))return;
  e.respondWith(caches.match(e.request).then(h=>h||fetch(e.request)));
});
