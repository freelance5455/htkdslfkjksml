// Leaflet wrapper: OSM raster tiles (visible area only), markers, route polyline.
export function createMap(onTap){
  const ll=p=>[p.lat,p.lng],pin=(c,s)=>L.divIcon({className:'pin '+c,iconSize:[s,s]});
  const map=L.map('map',{zoomControl:false,zoomAnimation:false,fadeAnimation:false,markerZoomAnimation:false}).setView([30,10],2);
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,updateWhenIdle:true,keepBuffer:1,
    attribution:'© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'}).addTo(map);
  map.attributionControl.setPrefix(false);
  map.on('click',e=>onTap({lat:e.latlng.lat,lng:e.latlng.lng}));
  let s,e,me;const line=L.layerGroup().addTo(map);
  const mk=(m,c,p,z)=>{if(m)m.setLatLng(ll(p));else m=L.marker(ll(p),{icon:pin(c,z),interactive:false,keyboard:false}).addTo(map);return m};
  return{
    setStart:p=>{s=mk(s,'s',p,22)},
    setMe:p=>{me=mk(me,'me',p,18)},
    center:(p,z=15)=>map.setView(ll(p),Math.max(map.getZoom(),z),{animate:false}),
    clear(){line.clearLayers();if(e){e.remove();e=null}},
    show(shape,loop){this.clear();const l=shape.map(ll);
      line.addLayer(L.polyline(l,{color:'#fff',weight:9,opacity:.9})).addLayer(L.polyline(l,{color:'#6750a4',weight:5}));
      if(!loop)e=mk(null,'e',shape[shape.length-1],22)},
    fit:(shape,tl,br)=>map.fitBounds(L.latLngBounds(shape.map(ll)),{paddingTopLeft:tl,paddingBottomRight:br,animate:false})
  };
}
