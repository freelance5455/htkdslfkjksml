// Preferences + last route, persisted in localStorage.
const K='wander.v1';
export const DEF={goal:'distance',unit:'km',v:{distance:5,time:60,steps:7000},mode:'loop',style:'balanced',shape:'varied',
  stairs:false,hills:false,live:true,theme:'auto',height:175,speed:5,start:null,last:null};
let s={...DEF};
try{s={...DEF,...JSON.parse(localStorage.getItem(K)||'{}')}}catch{}
export const get=()=>s;
export const set=p=>{Object.assign(s,p);try{localStorage.setItem(K,JSON.stringify(s))}catch{}};
