// Route generation on the public FOSSGIS Valhalla server (pedestrian costing, GET => no CORS preflight).
// Loop: start + 3 jittered waypoints on a circle through the start. One-way: random bearing/distance.
// Every result is resampled to 10 m, then dead-end spurs (out-and-back detours) are cut out, which keeps the
// path continuous. Attempts are scored on distance error + remaining retrace; radius is rescaled and retried.
const API='https://valhalla1.openstreetmap.de/route',R=6371008,rad=Math.PI/180,STEP=10,cache=new Map();
export const dist=(a,b)=>Math.hypot((b.lng-a.lng)*rad*Math.cos((a.lat+b.lat)*rad/2),(b.lat-a.lat)*rad)*R;
const move=(p,br,m)=>({lat:p.lat+m*Math.cos(br)/111320,lng:p.lng+m*Math.sin(br)/(111320*Math.cos(p.lat*rad))});
const len=s=>s.reduce((a,p,i)=>i?a+dist(s[i-1],p):0,0);
function decode(s){let i=0,la=0,ln=0;const o=[];while(i<s.length){for(const k of[0,1]){let r=0,sh=0,b;do{b=s.charCodeAt(i++)-63;r|=(b&31)<<sh;sh+=5}while(b>=32);const d=r&1?~(r>>1):r>>1;k?ln+=d:la+=d}o.push({lat:la/1e6,lng:ln/1e6})}return o}

const STY={scenic:{walkway_factor:.5,use_living_streets:.9,use_tracks:.8},balanced:{walkway_factor:.8,use_living_streets:.7,use_tracks:.5},direct:{walkway_factor:1,use_living_streets:.3,use_tracks:.2}};
const SHP={round:[.15,.1],varied:[.5,.4],winding:[.9,.7]};

async function call(pts,o,signal){
  const q=JSON.stringify({locations:pts.map(p=>({lat:p.lat,lon:p.lng})),costing:'pedestrian',directions_type:'none',
    costing_options:{pedestrian:{...(STY[o.style]||STY.balanced),step_penalty:o.stairs?600:30,use_hills:o.hills?0:.5}}});
  if(cache.has(q))return cache.get(q);
  let r;try{r=await fetch(API+'?json='+encodeURIComponent(q),{signal})}
  catch(e){if(e.name==='AbortError')throw e;throw Error(navigator.onLine?'Routing server unreachable. Try again in a moment.':'You’re offline. Connect to the internet to generate a route.')}
  const j=await r.json().catch(()=>({}));
  if(!r.ok){const e=Error(r.status===429?'The routing server is busy (rate limit). Wait a few seconds and retry.':r.status===400?'No walkable connection found from here. Try another start point.':`Routing failed (HTTP ${r.status}).`);e.noPath=r.status===400;throw e}
  const shape=[];j.trip.legs.forEach(l=>decode(l.shape).forEach((p,i)=>{if(i||!shape.length)shape.push(p)}));
  if(cache.size>20)cache.delete(cache.keys().next().value);cache.set(q,shape);return shape;
}

function resample(s){const o=[s[0]];let c=0;
  for(let i=1;i<s.length;i++){const a=s[i-1],b=s[i],d=dist(a,b);let p=STEP-c;
    for(;p<=d;p+=STEP){const f=p/d;o.push({lat:a.lat+(b.lat-a.lat)*f,lng:a.lng+(b.lng-a.lng)*f})}c=d-(p-STEP)}
  o.push(s[s.length-1]);return o}

// A spur is a stretch where point i+k mirrors point j-k (within 8 m) for ≥4 steps: the path walks out and
// straight back. Cutting everything between the two mirrored ends leaves a valid path. Spurs touching the
// start/end are kept (the start itself may sit on a dead end).
function despur(P){
  for(let r=0;r<12;r++){
    let bk=0,bi=0,bj=0;const n=P.length;
    for(let S=3;S<2*n-4;S++){let i=(S-1)>>1,j=S-i,k=0;
      while(i-k>=0&&j+k<n&&dist(P[i-k],P[j+k])<8)k++;
      if(k>bk&&i-k>=0&&j+k<n){bk=k;bi=i;bj=j}}
    if(bk<4)break;
    P=P.slice(0,bi-bk+2).concat(P.slice(bj+bk));
  }
  return P}

// Remaining retrace (lollipops etc.): share of ~15 m samples that revisit a cell first visited >180 m earlier.
function overlap(s){const seen=new Map();let n=0,k=0;
  for(let i=1;i<s.length;i++){const a=s[i-1],b=s[i],c=Math.max(1,Math.ceil(dist(a,b)/15));
    for(let j=1;j<=c;j++){const f=j/c,la=a.lat+(b.lat-a.lat)*f,ln=a.lng+(b.lng-a.lng)*f,key=Math.round(la*5e3)+','+Math.round(ln*5e3*Math.cos(la*rad));
      if(seen.has(key)&&k-seen.get(key)>12)n++;seen.set(key,k++)}}
  return k?n/k:0}

export async function generate({start,m:T,mode,opts:o,signal}){
  const loop=mode==='loop',[aj,rj]=SHP[o.shape]||SHP.varied;
  let sc=T/(loop?2*Math.PI*1.3:1.3),br=Math.random()*2*Math.PI,best=null;
  for(let a=0;a<6;a++){
    let pts;
    if(loop){const c=move(start,br,sc);
      pts=[start,...[1,2,3].map(i=>move(c,br+Math.PI+i*Math.PI/2+(Math.random()-.5)*aj,sc*(1-rj/2+Math.random()*rj))),start]}
    else pts=[start,move(start,br,sc)];
    let raw;try{raw=await call(pts,o,signal)}catch(e){if(e.noPath&&a<5){sc*=.6;br=Math.random()*2*Math.PI;continue}throw e}
    const shape=despur(resample(raw)),m=len(shape),err=Math.abs(m-T)/T,ov=overlap(shape),score=err+2*ov;
    if(!best||score<best.score)best={shape,m,score,loop};
    if(err<=.1&&ov<.12)break;
    sc*=Math.min(2,Math.max(.5,T/m));if(ov>.12)br=Math.random()*2*Math.PI;
  }
  if(!best)throw Error('Couldn’t build a walkable route here. Try a shorter distance or another start point.');
  return best;
}

const sample=(s,n)=>{const c=[0];for(let i=1;i<s.length;i++)c.push(c[i-1]+dist(s[i-1],s[i]));
  const o=[];let j=0;for(let i=1;i<=n;i++){const t=c[c.length-1]*i/(n+1);while(c[j]<t)j++;o.push(s[j])}return o};
export function gmapsUrl(shape,loop){
  const f=p=>p.lat.toFixed(5)+','+p.lng.toFixed(5);
  return 'https://www.google.com/maps/dir/?api=1&travelmode=walking&origin='+f(shape[0])+
    '&destination='+f(loop?shape[0]:shape[shape.length-1])+'&waypoints='+encodeURIComponent(sample(shape,8).map(f).join('|'));
}
