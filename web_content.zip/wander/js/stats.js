// Slider goals (distance / time / steps) and route statistics.
// Step length (m) = height (m) × 0.415; steps = distance / step length.
export const stepLen=h=>h/100*0.415,MI=1609.344;
const G={distance:{km:{min:.5,max:20,step:.5,def:5},mi:{min:.5,max:12.5,step:.5,def:3}},
  time:{min:10,max:240,step:5,def:60},steps:{min:1000,max:30000,step:500,def:7000}};
export const cfg=s=>s.goal==='distance'?G.distance[s.unit]:G[s.goal];
export const toMeters=(x,s)=>s.goal==='distance'?x*(s.unit==='mi'?MI:1000):s.goal==='time'?x/60*s.speed*1000:x*stepLen(s.height);
export const fmtTime=m=>m<60?`${m} min`:`${Math.floor(m/60)} h${m%60?` ${m%60} min`:''}`;
export const stats=(m,s)=>({d:m/(s.unit==='mi'?MI:1000),min:Math.round(m/1000/s.speed*60),steps:Math.round(m/stepLen(s.height))});
