// Live position. Watching pauses while the tab is hidden, and can be turned off to save battery.
const opt={maximumAge:15000,timeout:30000};
let id=null,ok=null,bad=null,w=true;
const pause=()=>{if(id!==null)navigator.geolocation.clearWatch(id);id=null};
const resume=()=>{pause();if(ok&&w)id=navigator.geolocation.watchPosition(ok,bad,opt)};
export const stop=()=>{w=false;pause()};
export function track(onPos,onErr,watch=true){
  if(!('geolocation' in navigator))return onErr({code:0});
  w=watch;ok=p=>onPos({lat:p.coords.latitude,lng:p.coords.longitude});
  bad=e=>{if(e.code===1){ok=null;pause()}onErr(e)};
  navigator.geolocation.getCurrentPosition(ok,bad,opt);resume();
}
document.addEventListener('visibilitychange',()=>document.hidden?pause():resume());
