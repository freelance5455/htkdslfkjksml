import{get,set,DEF}from'./settings.js';
import{stats,cfg,toMeters,fmtTime}from'./stats.js';
import{initData}from'./data.js';
import{track,stop}from'./geo.js';
import{createMap}from'./mapview.js';
import{generate,gmapsUrl}from'./route.js';

const $=id=>document.getElementById(id),root=document.documentElement,sheet=$('sheet'),rng=$('range'),gen=$('gen'),grab=$('grab'),dlg=$('dlg'),
  desk=matchMedia('(min-width:840px)'),dark=matchMedia('(prefers-color-scheme:dark)'),rm=matchMedia('(prefers-reduced-motion:reduce)').matches,
  mode=()=>document.querySelector('[name=mode]:checked').value;
let start=get().start,route=null,me=null,tt,hide=0,col=false;
const toast=m=>{const t=$('toast');t.textContent=m;t.hidden=false;clearTimeout(tt);tt=setTimeout(()=>t.hidden=true,6000)};
const theme=()=>{const t=get().theme;root.dataset.t=t==='auto'?(dark.matches?'dark':'light'):t};
dark.onchange=theme;theme();
initData($('data'));

// ---- Bottom sheet: animated collapse (tap or drag the handle) so the map can be seen
const peek=()=>$('head').getBoundingClientRect().bottom-sheet.getBoundingClientRect().top+14;
function layout(){if(desk.matches)col=false;hide=col?Math.max(0,sheet.offsetHeight-peek()):0;
  sheet.style.setProperty('--hide',hide+'px');root.style.setProperty('--sh',desk.matches?'0px':sheet.offsetHeight-hide+'px');grab.setAttribute('aria-expanded',!col)}
new ResizeObserver(layout).observe(sheet);desk.onchange=layout;
let y0=null,h0=0,moved=false;
const max=()=>sheet.offsetHeight-peek();
grab.onpointerdown=e=>{y0=e.clientY;h0=hide;moved=false;grab.setPointerCapture(e.pointerId);sheet.classList.add('drag')};
grab.onpointermove=e=>{if(y0===null)return;const d=e.clientY-y0;if(Math.abs(d)>4)moved=true;
  sheet.style.setProperty('--hide',Math.min(max(),Math.max(0,h0+d))+'px')};
grab.onpointerup=()=>{if(y0===null)return;sheet.classList.remove('drag');
  col=moved?parseFloat(sheet.style.getPropertyValue('--hide'))>max()/2:!col;y0=null;layout()};
grab.onpointercancel=grab.onpointerup;
grab.onclick=e=>{if(e.detail===0){col=!col;layout()}};

// ---- Map
const M=createMap(p=>pick(p));
function pick(p,center){start=p;set({start:p,last:null});M.setStart(p);route=null;M.clear();$('gmaps').disabled=true;['sd','st','ss'].forEach(i=>$(i).textContent='–');gen.lastElementChild.textContent='Generate route';
  $('note').textContent='Tap the map to set your start point, then generate a route.';if(center)M.center(p)}
const pad=()=>desk.matches?[[410,40],[30,30]]:[[30,60],[30,sheet.offsetHeight-hide+40]];
function showStats(){const s=get(),x=stats(route.m,s);$('sd').textContent=x.d.toFixed(2);$('su').textContent=s.unit;$('st').textContent=x.min;$('ss').textContent='≈ '+x.steps.toLocaleString()}
function draw(){M.show(route.shape,route.loop);M.fit(route.shape,...pad());showStats();$('gmaps').disabled=false;
  gen.lastElementChild.textContent='Generate new route';
  $('note').textContent='Google Maps gets up to 8 waypoints from this route, so its path between them may differ slightly.'}

// ---- Slider: distance / time / steps (chosen in Settings). Updates labels only; routing runs on the button.
function paint(){const s=get(),x=+rng.value,u=s.unit;
  $('km').innerHTML=(s.goal==='distance'?`${x.toFixed(1)} ${u}`:s.goal==='time'?fmtTime(x):`${x.toLocaleString()} steps`).replace(/[a-z]+/g,'<small>$&</small>');
  rng.style.setProperty('--v',(x-rng.min)/(rng.max-rng.min)*100+'%');
  const e=stats(toMeters(x,s),s),a={distance:`${e.d.toFixed(1)} ${u}`,time:fmtTime(e.min),steps:`${e.steps.toLocaleString()} steps`};
  delete a[s.goal];$('eq').textContent='≈ '+Object.values(a).join(' · ')}
function slider(){const s=get(),c=cfg(s);rng.min=c.min;rng.max=c.max;rng.step=c.step;rng.value=s.v[s.goal]??c.def;
  $('gl').textContent={distance:'Distance',time:'Time',steps:'Steps'}[s.goal];paint()}
rng.oninput=()=>{const s=get();set({v:{...s.v,[s.goal]:+rng.value}});paint();if(!rm)$('km').animate([{transform:'scale(1.07)'},{transform:'scale(1)'}],120)};
document.querySelectorAll('[name=mode]').forEach(r=>{r.checked=r.value===get().mode;r.onchange=()=>set({mode:r.value})});
slider();

// ---- Settings dialog (rendered from a spec)
const SPEC=[
 ['Slider measures','radio','goal',[['distance','Distance'],['time','Time'],['steps','Steps']]],
 ['Units','radio','unit',[['km','Kilometres'],['mi','Miles']]],
 ['Route style','radio','style',[['scenic','Scenic'],['balanced','Balanced'],['direct','Direct']]],
 ['Loop shape','radio','shape',[['round','Round'],['varied','Varied'],['winding','Winding']]],
 ['Avoid','switch',[['stairs','Stairs'],['hills','Steep hills']]],
 ['Your walk','num',[['height','Height (cm)',100,230,1],['speed','Speed (km/h)',2,8,.5]]],
 ['Appearance','radio','theme',[['auto','Auto'],['light','Light'],['dark','Dark']]],
 ['Battery','switch',[['live','Live GPS tracking']]]];
$('sbody').innerHTML=SPEC.map(([t,ty,a,o])=>`<h3>${t}</h3>`+(ty==='radio'
  ?`<div class="seg" style="--n:${o.length}" role="radiogroup" aria-label="${t}">${o.map(([v,l])=>`<label><input type="radio" name="${a}" value="${v}"><span>${l}</span></label>`).join('')}</div>`
  :ty==='switch'?a.map(([k,l])=>`<label class="row">${l}<input type="checkbox" role="switch" name="${k}"></label>`).join('')
  :`<div class="set">${a.map(([k,l,lo,hi,s])=>`<label>${l}<input type="number" name="${k}" min="${lo}" max="${hi}" step="${s}" inputmode="decimal"></label>`).join('')}</div>`)).join('');
$('sbody').querySelectorAll('[name]').forEach(el=>{const v=get()[el.name];
  if(el.type==='radio')el.checked=String(v)===el.value;else if(el.type==='checkbox')el.checked=!!v;else el.value=v});
$('sbody').addEventListener('change',e=>{const el=e.target,k=el.name;let v=el.type==='checkbox'?el.checked:el.value;
  if(el.type==='number'){v=Math.min(+el.max,Math.max(+el.min,+v||DEF[k]));el.value=v}
  set({[k]:v});
  if(k==='unit')set({v:{...get().v,distance:cfg({goal:'distance',unit:v}).def}});
  if(k==='theme')theme();
  if(k==='live')v?track(onPos,err):stop();
  slider();if(route)showStats()});
const idx=()=>document.querySelectorAll('.seg').forEach(s=>s.style.setProperty('--i',[...s.querySelectorAll('input')].findIndex(i=>i.checked)));
idx();document.addEventListener('change',idx);
$('cfg').onclick=()=>dlg.showModal();$('x').onclick=()=>dlg.close();
dlg.onclick=e=>{const r=dlg.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dlg.close()};
$('reset').onclick=()=>{set({...DEF,start:get().start,last:null});location.reload()};

// ---- Generate / Google Maps
gen.onclick=async()=>{
  if(!start)return toast('Tap the map or turn on GPS to choose a start point.');
  if(!navigator.onLine)return toast('You’re offline. Connect to the internet to generate a route.');
  gen.disabled=true;gen.classList.add('busy');gen.lastElementChild.textContent='Generating';
  try{
    const s=get(),T=toMeters(+rng.value,s);
    route=await generate({start,m:T,mode:mode(),opts:s});draw();
    set({last:{loop:route.loop,m:route.m,shape:route.shape.map(p=>[+p.lat.toFixed(5),+p.lng.toFixed(5)])}});
    if(Math.abs(route.m-T)/T>.1){const x=stats(route.m,s);toast(`Closest match is ${x.d.toFixed(1)} ${s.unit} (${x.min} min). The street network here limits other options.`)}
  }catch(e){toast(e.message||'Couldn’t generate a route.');gen.lastElementChild.textContent=route?'Generate new route':'Generate route'}
  finally{gen.disabled=false;gen.classList.remove('busy')}
};
$('gmaps').onclick=()=>route&&open(gmapsUrl(route.shape,route.loop),'_blank','noopener');

// ---- GPS
const err=e=>toast(e.code===1?'Location permission denied. Tap the map to choose a start point.':e.code===0?'This browser has no GPS support. Tap the map to choose a start point.':'Couldn’t get your location. Tap the map to choose a start point.');
const onPos=p=>{me=p;M.setMe(p);if(!start)pick(p,true)};
$('locate').onclick=()=>{if(me){M.center(me);if(!start)pick(me)}else track(onPos,err,get().live)};
if(start){M.setStart(start);M.center(start)}
const l=get().last;
if(l&&start){route={loop:l.loop,m:l.m,shape:l.shape.map(([lat,lng])=>({lat,lng}))};draw()}
(navigator.permissions?navigator.permissions.query({name:'geolocation'}).then(p=>p.state!=='denied',()=>true):Promise.resolve(true))
  .then(ok=>ok?track(onPos,err,get().live):start||toast('Location is blocked. Tap the map to choose a start point.'));
addEventListener('offline',()=>toast('You’re offline. New routes and map tiles need a connection.'));
if('serviceWorker' in navigator)addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));
