// Data counter from Resource Timing. Cached = 0 transfer but a body size; cross-origin
// responses without Timing-Allow-Origin report all zeros, so they're counted as "unmeasured", never guessed.
export function initData(el){
  let bytes=0,unk=0,tm=0;
  const fmt=b=>b<1e6?(b/1e3).toFixed(b<1e5?1:0)+' KB':(b/1e6).toFixed(2)+' MB';
  const paint=()=>{tm=0;el.textContent=`Data used: ${unk?'≥ ':''}${fmt(bytes)}${unk?` · ${unk} unmeasured`:''}`;
    el.title=unk?'Some cross-origin responses (often map tiles) hide their size from the browser, so this is a lower bound.':'Measured with Resource Timing; cached files are not counted.'};
  const add=e=>{if(e.transferSize>0)bytes+=e.transferSize;else if(!e.decodedBodySize)unk++;tm||(tm=setTimeout(paint,400))};
  const nav=performance.getEntriesByType('navigation')[0];if(nav&&nav.transferSize)bytes+=nav.transferSize;
  try{new PerformanceObserver(l=>l.getEntries().forEach(add)).observe({type:'resource',buffered:true})}
  catch{el.textContent='Data counter not supported here';return}
  paint();
}
