# Dasova Survival v3.9 — Android Beta APK build

Bu proje, v3.9 HTML oyununu Android WebView içinde yatay ekranlı bir uygulama olarak açar. HTML dosyası `app/src/main/assets/index.html` içindedir.

## Telefonda APK oluşturma (GitHub Actions)
1. GitHub'da yeni bir repository oluştur.
2. Bu ZIP'i açıp içindeki dosyaları repository'nin ana dizinine yükle (klasörün içindekiler, doğrudan repo kökünde olmalı).
3. GitHub repository sayfasında **Actions** sekmesini aç.
4. **Build Dasova Survival APK** iş akışını seçip **Run workflow** düğmesine bas.
5. İşlem bitince ilgili çalıştırmanın altındaki **Artifacts** bölümünden `Dasova-Survival-v3.9-Beta-APK` dosyasını indir ve ZIP'i aç.
6. İçindeki `app-debug.apk` dosyasını test telefonuna kur. Android, bilinmeyen uygulama yükleme izni isteyebilir.

## Notlar
- Bu kaynak paketi hazır APK değildir; APK, GitHub Actions üzerinde derlenir.
- Oyun Three.js'i CDN'den yüklediği için ilk açılışta internet bağlantısı gerekir.
- Bu, test/beta için debug imzalı APK üretir. Geniş dağıtım için ayrıca release keystore ile imzalama ayarlanmalıdır.
