# Stewardship 3.9.0 — release status

## Included
- Responsive offline-first personal command centre (home, tasks, notes, planner/habits, Steward chat, settings).
- Local device persistence and manual JSON backup/restore.
- Task due dates, priority labels, overdue filter, and task search.
- Offline rule-based Steward responses; optional online mode through a separately deployed secure gateway.
- Capacitor Android wrapper configuration and GitHub Actions debug-build workflow.
- Backend response-size protection and automated gateway tests.

## Verified
- Web bundle build succeeds.
- Backend automated tests: 2/2 pass.
- Backend and inline frontend JavaScript syntax checks pass.
- ZIP archive integrity checked at packaging time.

## Not yet delivered / requires external setup
- No APK has been built or signed in this environment.
- Android SDK/Gradle build and physical-device QA have not been run.
- No live AI provider or backend deployment is configured.
- No cloud database, account system, or cross-device sync is implemented.
- Offline Steward is a lightweight rule-based helper, not a local large language model.
