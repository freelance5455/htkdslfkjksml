import { cp, mkdir, copyFile, rm } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = process.cwd();
const web = resolve(root, 'www');
await rm(web, { recursive: true, force: true });
await mkdir(web, { recursive: true });
for (const file of ['index.html', 'manifest.webmanifest', 'sw.js']) {
  await copyFile(resolve(root, file), resolve(web, file));
}
await cp(resolve(root, 'assets'), resolve(web, 'assets'), { recursive: true });
console.log('Prepared clean Capacitor web bundle in ./www');
