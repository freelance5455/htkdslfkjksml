# Stewardship — final source QA handoff

This package is a source project / PWA plus an Android cloud-build scaffold. It is NOT a compiled APK and does NOT include a live AI service.

## Checks run in this environment
- `node --check` on extracted inline frontend JavaScript: PASS
- `node --check sw.js`: PASS
- `node --check backend/server.mjs`: PASS
- `node --check backend/test/server.test.mjs`: PASS
- `node --test backend/test/server.test.mjs`: PASS (1 test suite; assertions cover health, unconfigured AI response, unknown route, CORS preflight, wrong content type, malformed JSON, invalid role)

## What is implemented in source
- Responsive single-app web/PWA interface for Home, Tasks, Notes, Planner/Habits, Steward chat and Settings.
- Local browser storage for tasks, notes, habits, focus and chat history.
- Manual JSON export/import backup.
- Date-aware habit check-ins.
- Service-worker app-shell cache.
- Offline Steward uses simple rules; it is NOT a local language model.
- Online AI UI plus a server-side OpenAI-compatible gateway scaffold.
- Capacitor wrapper config and GitHub Actions workflow intended to produce a debug APK artifact.

## Not done (requires external services or execution)
- No AI provider has been selected/configured; no API key is included; backend is not deployed.
- No cloud accounts, authentication, database or cross-device sync are implemented.
- No Android APK has been compiled or signed.
- GitHub Actions workflow has not been run against a GitHub repository.
- No real-device phone/tablet QA has been performed.
- No offline LLM is bundled; offline Steward is rule-based.

## External actions eventually needed
1. Put this source into a GitHub repository and run the `Build Stewardship Android APK` workflow to get a debug APK artifact.
2. Configure a suitable AI provider and deploy `backend/` with server-side `AI_BASE_URL`, `AI_MODEL`, `AI_API_KEY`, and allowed frontend origins. Never put the provider key in the app or a public repo.
3. Host the frontend over HTTPS and set the deployed backend URL in app Settings.
4. Cloud sync requires a separate database/auth integration and is not included in this source.

## Production caveats
The gateway's in-memory IP rate limit is starter protection, not production-grade. Before real multi-user/public use, add authentication/per-user quotas, durable rate limiting, monitoring, privacy policy, and review provider age/region/retention/pricing terms. Debug APK is for testing; public distribution requires release signing and store preparation.
