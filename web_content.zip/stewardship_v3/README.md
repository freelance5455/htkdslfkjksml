# STEWARDSHIP v3.8 — offline-first personal command centre

## What is included
- Version 3.2 update: date-aware habit check-ins with migration from the previous boolean format.
- Responsive single-app PWA for phones and tablets.
- Home dashboard, tasks, notes, daily focus, habits and Steward chat.
- Local persistence using browser `localStorage`.
- Chat history persistence without sending the temporary “connecting” status to the AI.
- JSON export/import backup and restore with basic schema validation.
- Date-aware habit check-ins: a completed habit resets visually on the next local calendar day, without erasing its previous check-in date.
- Offline/Online mode selector.
- PWA manifest, app icons and service worker for the app shell.
- Node.js AI gateway with server-side provider secrets, request validation, size limits, timeout handling, basic per-IP rate limiting, strict gateway URL validation in the app, safer backup import validation, explicit allowed-origin CORS (including Capacitor Android origins) and health endpoint.
- Built-in Node tests covering gateway startup, health response, unconfigured AI response, route handling, CORS preflight, content type, malformed JSON and invalid message roles.
- Dockerfile and Render blueprint for a deployable backend service.

## Honest feature status
- Offline productivity features: implemented locally in the browser/PWA. Habit check-ins are date-aware; this is not yet a full streak analytics engine.
- Offline Steward: simple rule-based helper, **not** a local language model.
- Online AI: gateway code is implemented, but it is **not live** until a compatible provider is selected and configured and the backend is deployed.
- Cloud sync: not implemented. Backup/restore is manual JSON export/import.
- Android APK: not included. This is a PWA/source project, not a signed native APK.

## Frontend hosting
Host the contents of this folder on any static HTTPS host. Service workers require HTTPS (or localhost); opening `index.html` directly as a `file://` URL will not enable the installable/offline PWA behaviour.

## Backend deployment
The `render.yaml` blueprint and `backend/Dockerfile` provide a deployment starting point. A hosting account and an AI provider account are external prerequisites. In the backend service's environment settings, configure:
- `AI_BASE_URL`: OpenAI-compatible API base URL, without `/chat/completions`.
- `AI_MODEL`: exact model identifier supplied by the provider.
- `AI_API_KEY`: private provider key; never put it in the frontend, ZIP or APK.
- `ALLOWED_ORIGINS`: comma-separated exact origins allowed to call the gateway. Include the hosted HTTPS frontend origin; Capacitor Android commonly uses `https://localhost`.

After deployment, test `https://YOUR-BACKEND/health`. It should return `ok: true` and `aiConfigured: true`. Copy the backend base URL into Stewardship → Settings → Online AI gateway. Do not paste the provider API key into the app.

The included in-memory rate limiter is a basic starter, not production-grade abuse protection. It deliberately does not trust arbitrary client-supplied `X-Forwarded-For` headers. Before public use, add durable rate limiting, authentication or per-user quotas, monitoring, a privacy policy, and review the provider's pricing, free-tier limits, data retention and age/region terms. Never assume a provider's free tier is permanent.

## Local backend test
Requires Node.js 20+. In `backend/` run `npm test` for the automated gateway smoke test, then run `npm start` after setting environment variables. `GET /health` checks configuration. `POST /api/chat` accepts `{ "messages": [{"role":"user","content":"Hello"}] }`.

## Verification checklist
- Add/complete/delete tasks.
- Save/delete notes and set daily focus.
- Add/check/delete habits.
- Reload and confirm local data persists.
- Export JSON, clear data, import JSON and confirm restore.
- Reload with existing chat history and verify it does not duplicate.
- Select Online without a gateway and confirm a clear connection message.
- After backend deployment, test health and a real AI request.

## Android packaging scaffold (v3.8)
This release hardens the AI gateway timeout and native-origin CORS handling. It retains the Capacitor 7 wrapper configuration, a clean web-bundle preparation script, and a GitHub Actions workflow for producing a **debug APK** in the cloud. It does not contain a precompiled APK or a signing key.

### What the cloud build will do
1. Install the Capacitor dependencies.
2. Copy only the app shell and assets into `www/` (keeps backend/source files out of the APK web bundle).
3. Generate the native Android project from this clean web bundle.
4. Sync the web assets into the Android project.
5. Build `app-debug.apk` and publish it as a downloadable workflow artifact.

### External step still required
The source must be placed in a GitHub repository and the workflow must be run from the Actions tab (or triggered by pushing to `main`). This cannot happen from this chat because it requires access to the user's GitHub account. A debug APK is suitable for testing; public Play Store distribution requires a properly signed release build and additional store preparation.

### Important status
- The Android wrapper/build pipeline is prepared in source; the workflow builds from a dedicated `www/` bundle.
- This does not make the Online AI gateway live. A provider key, provider configuration and deployed backend are still required.
- Cloud sync is still not implemented; JSON backup/restore remains manual.
- Offline Steward is a small rule-based helper, not a local LLM.
