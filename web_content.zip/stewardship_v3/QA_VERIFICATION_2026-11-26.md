# QA verification — Stewardship 3.9.0

Verified in the build environment on 2026-11-26:
- `npm run build:web` completed and refreshed the clean Capacitor `www/` bundle.
- Backend test suite: 2/2 tests passed (gateway validation and oversized upstream response rejection).
- `node --check backend/server.mjs` passed.
- Inline application JavaScript passed `node --check`.

3.9.0 adds task due dates, high/normal/low priority, overdue filtering, and task search. Older task records and backups remain compatible; missing priority defaults to normal and invalid due dates are ignored.

Not verified: Android Gradle/SDK build, generated APK, physical-device testing, deployed AI gateway, real AI provider, or cloud sync. Online AI requires a separately deployed gateway and provider configuration. App data remains local to the device unless the user manually exports a JSON backup.
