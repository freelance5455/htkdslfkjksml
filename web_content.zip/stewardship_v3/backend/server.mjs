// Stewardship AI gateway. Provider credentials stay on the server, never in the app.
import http from 'node:http';

const PORT = Number(process.env.PORT || 8787);
const API_KEY = process.env.AI_API_KEY || '';
const BASE_URL = (process.env.AI_BASE_URL || '').replace(/\/$/, '');
const MODEL = process.env.AI_MODEL || '';
const ALLOWED_ORIGINS = new Set((process.env.ALLOWED_ORIGINS || process.env.APP_ORIGIN || 'https://localhost,capacitor://localhost,http://localhost').split(',').map(x => x.trim()).filter(Boolean));
const MAX_BODY = 24_000;
const MAX_UPSTREAM_RESPONSE = 64_000;
const WINDOW_MS = 60_000;
const MAX_REQUESTS = 12;
const hits = new Map();
const json = (res, status, body) => { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }); res.end(JSON.stringify(body)); };

const server = http.createServer(async (req, res) => {
  const origin = req.headers.origin || '';
  if (origin && !ALLOWED_ORIGINS.has(origin)) return json(res, 403, { error: 'Origin not allowed.' });
  res.setHeader('Vary', 'Origin');
  if (origin && ALLOWED_ORIGINS.has(origin)) res.setHeader('Access-Control-Allow-Origin', origin);
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS, GET');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  if (req.method === 'GET' && req.url === '/health') return json(res, 200, { ok: true, aiConfigured: Boolean(API_KEY && BASE_URL && MODEL) });
  if (req.method !== 'POST' || req.url !== '/api/chat') return json(res, 404, { error: 'Not found.' });

  // Do not trust client-supplied X-Forwarded-For: without an explicitly trusted proxy it is spoofable.
  const ip = (req.socket.remoteAddress || 'unknown').toString();
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter(t => now - t < WINDOW_MS);
  if (recent.length >= MAX_REQUESTS) return json(res, 429, { error: 'Too many requests. Please wait a minute and try again.' });
  recent.push(now); hits.set(ip, recent);
  if (hits.size > 2000) for (const [key, times] of hits) if (!times.some(t => now - t < WINDOW_MS)) hits.delete(key);
  if (!(req.headers['content-type'] || '').toLowerCase().includes('application/json')) return json(res, 415, { error: 'Content-Type must be application/json.' });
  const declaredLength = Number(req.headers['content-length'] || 0);
  if (declaredLength > MAX_BODY) return json(res, 413, { error: 'Request is too large.' });

  try {
    let raw = '';
    for await (const chunk of req) {
      raw += chunk;
      if (Buffer.byteLength(raw, 'utf8') > MAX_BODY) return json(res, 413, { error: 'Request is too large.' });
    }
    const body = JSON.parse(raw || '{}');
    const messages = Array.isArray(body.messages) ? body.messages.slice(-12) : [];
    if (body.messages && !Array.isArray(body.messages)) return json(res, 400, { error: 'Messages must be an array.' });
    if (!messages.length || messages.some(m => !m || !['user', 'assistant'].includes(m.role) || typeof m.content !== 'string' || !m.content.trim() || m.content.length > 3000)) {
      return json(res, 400, { error: 'Invalid conversation. Please send up to 12 recent messages.' });
    }
    if (!API_KEY || !BASE_URL || !MODEL) return json(res, 503, { error: 'Online AI is not configured yet. Offline mode is available.' });
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 22_000);
    try {
      const upstream = await fetch(`${BASE_URL}/chat/completions`, {
        method: 'POST', signal: controller.signal,
        headers: { Authorization: `Bearer ${API_KEY}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: MODEL, messages: [
          { role: 'system', content: 'You are Steward, the thoughtful AI assistant inside Stewardship. Help with studying, planning, problem-solving and personal organisation. Be practical, warm, concise and honest. Do not claim to have changed app data or performed actions unless the user did them in the app.' },
          ...messages
        ], temperature: 0.7, max_tokens: 800 })
      });
      // Bound the provider response before parsing it; never trust an upstream body size.
      const upstreamText = await upstream.text();
      if (Buffer.byteLength(upstreamText, 'utf8') > MAX_UPSTREAM_RESPONSE) return json(res, 502, { error: 'The AI provider response was too large.' });
      let data = {};
      try { data = JSON.parse(upstreamText || '{}'); } catch { return json(res, 502, { error: 'The AI provider returned an invalid response.' }); }
      if (!upstream.ok) return json(res, 502, { error: 'The AI provider could not complete the request. Check provider configuration or try later.' });
      const answer = data?.choices?.[0]?.message?.content;
      if (typeof answer !== 'string' || !answer.trim()) return json(res, 502, { error: 'The AI provider returned an empty response.' });
      return json(res, 200, { reply: answer.trim() });
    } finally { clearTimeout(timeout); }
  } catch (err) {
    if (err instanceof SyntaxError) return json(res, 400, { error: 'Request body must be valid JSON.' });
    if (err?.name === 'AbortError') return json(res, 504, { error: 'The AI provider timed out. Please try again.' });
    return json(res, 502, { error: 'Could not reach the AI provider. Please try again later.' });
  }
});
server.listen(PORT, '0.0.0.0', () => console.log(`Stewardship AI gateway listening on ${PORT}`));
