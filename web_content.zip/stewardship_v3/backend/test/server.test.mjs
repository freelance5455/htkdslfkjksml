import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { once } from 'node:events';

test('gateway health, missing configuration, and route validation', async (t) => {
  const port = 19000 + Math.floor(Math.random() * 10000);
  const child = spawn(process.execPath, ['server.mjs'], {
    cwd: new URL('..', import.meta.url),
    env: { ...process.env, PORT: String(port), AI_API_KEY: '', AI_BASE_URL: '', AI_MODEL: '', APP_ORIGIN: '' },
    stdio: 'ignore'
  });
  t.after(() => child.kill('SIGTERM'));
  const base = `http://127.0.0.1:${port}`;
  let ready = false;
  for (let i = 0; i < 40; i++) {
    try { const r = await fetch(`${base}/health`); if (r.ok) { ready = true; break; } } catch {}
    await new Promise(r => setTimeout(r, 100));
  }
  assert.equal(ready, true, 'gateway should start');
  const health = await (await fetch(`${base}/health`)).json();
  assert.deepEqual(health, { ok: true, aiConfigured: false });
  const missing = await fetch(`${base}/api/chat`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ messages: [{ role: 'user', content: 'hello' }] }) });
  assert.equal(missing.status, 503);
  const route = await fetch(`${base}/wrong`);
  assert.equal(route.status, 404);
  const preflight = await fetch(`${base}/api/chat`, { method: 'OPTIONS', headers: { Origin: 'https://localhost' } });
  assert.equal(preflight.status, 204);
  assert.equal(preflight.headers.get('access-control-allow-origin'), 'https://localhost');
  const wrongType = await fetch(`${base}/api/chat`, { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: 'hello' });
  assert.equal(wrongType.status, 415);
  const malformed = await fetch(`${base}/api/chat`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{bad json' });
  assert.equal(malformed.status, 400);
  const invalidMessages = await fetch(`${base}/api/chat`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ messages: [{ role: 'system', content: 'nope' }] }) });
  assert.equal(invalidMessages.status, 400);
});


test('gateway rejects an oversized upstream provider response', async (t) => {
  const provider = await import('node:http');
  const mock = provider.createServer((req, res) => {
    req.resume();
    req.on('end', () => {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ choices: [{ message: { content: 'x'.repeat(70_000) } }] }));
    });
  });
  mock.listen(0, '127.0.0.1');
  await once(mock, 'listening');
  t.after(() => mock.close());

  const port = 29000 + Math.floor(Math.random() * 10000);
  const child = spawn(process.execPath, ['server.mjs'], {
    cwd: new URL('..', import.meta.url),
    env: {
      ...process.env,
      PORT: String(port),
      AI_API_KEY: 'test-key',
      AI_BASE_URL: `http://127.0.0.1:${mock.address().port}`,
      AI_MODEL: 'test-model',
      APP_ORIGIN: ''
    },
    stdio: 'ignore'
  });
  t.after(() => child.kill('SIGTERM'));
  const base = `http://127.0.0.1:${port}`;
  let ready = false;
  for (let i = 0; i < 40; i++) {
    try { const r = await fetch(`${base}/health`); if (r.ok) { ready = true; break; } } catch {}
    await new Promise(r => setTimeout(r, 100));
  }
  assert.equal(ready, true, 'gateway should start');
  const response = await fetch(`${base}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ messages: [{ role: 'user', content: 'hello' }] })
  });
  assert.equal(response.status, 502);
  assert.deepEqual(await response.json(), { error: 'The AI provider response was too large.' });
});
