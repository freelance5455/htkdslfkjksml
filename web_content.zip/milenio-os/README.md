# Milenio OS

Escritorio retro de los 2000, en oscuro, con color de énfasis a elegir, cuatro idiomas (es, en, pt, fr) y un asistente local.
Todo el sistema vive en `www/index.html`. Esta carpeta lo envuelve para que sea una app de PC (Electron) y de Android (Capacitor).

## Usarlo sin instalar nada

Abre `www/index.html` en cualquier navegador. En Chrome o Edge, el menú permite instalarlo como app (el manifiesto y el service worker ya están incluidos; hace falta servirlo por http, por ejemplo con `npx serve www`).

## App de computadora (Windows, Linux, macOS)

Requiere Node.js 18 o más nuevo.

```
npm install
npm start          # probar
npm run dist       # genera el instalador en dist/
```

Cada sistema se compila en su propio sistema operativo: `.exe` en Windows, `.AppImage` y `.deb` en Linux, `.dmg` en macOS.

## APK de Android

Opción A, sin instalar nada en tu equipo: sube esta carpeta a un repositorio de GitHub, ve a **Actions > Compilar Milenio OS > Run workflow**. Al terminar, descarga el APK y los instaladores de escritorio desde los artefactos.

Opción B, en tu equipo (Node 18+, JDK 17 y Android SDK):

```
npm install
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
```

El APK queda en `android/app/build/outputs/apk/debug/app-debug.apk`. Es un APK de depuración: se instala directo en el teléfono (activa «instalar apps desconocidas»). Para publicarlo en Play Store hay que firmarlo con tu propia clave.

## Asistente local

Abre **Asistente** en el escritorio. Tiene tres modos:

- **Integrado**: no necesita nada. Abre programas, hace cuentas, dice la hora y cuenta chistes con reglas simples.
- **Ollama**: conversa con un modelo en tu propia máquina. Instala [Ollama](https://ollama.com), baja un modelo chico (`ollama pull llama3.2:1b`) y déjalo abierto. La app lo detecta en `http://localhost:11434`.
- **Automático** (por defecto): usa Ollama si responde y, si no, el modo integrado.

En la versión de PC la conexión con Ollama pasa por el proceso principal de Electron, así que no hay problemas de CORS.

En Android, `localhost` es el propio teléfono. Pon en el campo **Servidor** la dirección de tu PC, por ejemplo `http://192.168.1.50:11434`, y en la PC arranca Ollama con `OLLAMA_HOST=0.0.0.0` para aceptar conexiones de la red local.

## Ajustes

Ajustes (en el escritorio) cambia el fondo, el color de énfasis (paleta o cualquier color) y el idioma. Todo se guarda en el equipo.
