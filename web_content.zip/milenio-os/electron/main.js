'use strict';
const { app, BrowserWindow, Menu, ipcMain, shell } = require('electron');
const path = require('path');

// Habla con Ollama desde el proceso principal: no hay CORS ni contenido mixto.
ipcMain.handle('milenio:ollama', async (_e, req) => {
  const { base, path: p, method, body } = req || {};
  let url;
  try {
    url = new URL(p, String(base || 'http://localhost:11434').replace(/\/+$/, '') + '/');
    if (!/^https?:$/.test(url.protocol)) throw new Error('protocolo no permitido');
    if (!String(p).startsWith('/api/')) throw new Error('ruta no permitida');
  } catch (err) {
    return { ok: false, status: 0, text: String(err.message || err) };
  }
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 120000);
  try {
    const res = await fetch(url, {
      method: method || 'GET',
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
      signal: ctrl.signal,
    });
    return { ok: res.ok, status: res.status, text: await res.text() };
  } catch (err) {
    return { ok: false, status: 0, text: String(err.message || err) };
  } finally {
    clearTimeout(timer);
  }
});

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 720,
    minHeight: 520,
    backgroundColor: '#13161d',
    title: 'Milenio OS',
    icon: path.join(__dirname, '..', 'build', 'icon.png'),
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  Menu.setApplicationMenu(null);
  win.loadFile(path.join(__dirname, '..', 'www', 'index.html'));
  win.webContents.on('before-input-event', (e, input) => {
    if (input.type === 'keyDown' && input.key === 'F11') {
      win.setFullScreen(!win.isFullScreen());
      e.preventDefault();
    }
  });
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
