'use strict';
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('milenioNative', {
  platform: process.platform,
  ollama: (req) => ipcRenderer.invoke('milenio:ollama', req),
});
