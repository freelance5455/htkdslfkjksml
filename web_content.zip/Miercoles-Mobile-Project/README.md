# Miércoles Mobile — Proyecto móvil

Proyecto web móvil actualizado a partir de los recursos del APK proporcionado.

## Cambios
- Interfaz móvil oscura con acentos violeta y cian.
- Identidad de creador: Abisai.
- Sala de voz con orbe futurista y murciélago luminoso en el centro (sin inicial M).
- Animación del orbe al escuchar y al hablar.
- Conversación manos libres: reconocimiento de voz en español y lectura automática de respuestas.
- Preferencia por voz masculina cuando Android/navegador ofrece una voz masculina en español.
- Conexión directa del cliente a Groq Chat Completions, sin servidor intermediario.
- Clave API introducida y guardada localmente desde Ajustes.

## Uso
1. Descomprime el ZIP y sirve `assets-web` desde HTTPS o localhost.
2. Abre `index.html` en Chrome Android.
3. En Ajustes, introduce una clave nueva de Groq (`gsk_...`).
4. Permite el micrófono y abre **Voz**.

## Seguridad y limitaciones
La clave personal se almacena localmente en el perfil del navegador y se envía directamente a `https://api.groq.com/openai/v1/chat/completions`. No hay backend propio ni servidor intermediario. Una clave guardada en una app cliente puede extraerse del dispositivo; no compartas el ZIP/APK con una clave real. La clave que venía integrada en versiones anteriores debe revocarse en Groq y reemplazarse por una nueva. Para publicar la app para otras personas, conviene mover las llamadas a un backend/Edge Function con límites por usuario.

El paquete es un proyecto web, no un APK recompilado. La voz masculina depende de las voces instaladas en Android. No se ha validado en un teléfono físico.

## Saludo de bienvenida en la sala de voz
Al abrir la sala de voz, Miércoles saluda según la hora local del dispositivo: buenos días (05:00–11:59), buenas tardes (12:00–18:59) o buenas noches (19:00–04:59), y pregunta «¿en qué puedo ayudarte?». El saludo se reproduce con la voz española disponible en Android.

## Murciélago del orbe
Se rediseñó el emblema central con alas facetadas, acabado metálico violeta/cian, ojos luminosos y halo animado que reacciona cuando Miércoles habla.

## Inicio de sesión de Google y copia de chats
La versión actual guarda los chats localmente en el perfil del navegador. Para exigir una cuenta de Google al entrar y sincronizar conversaciones en la nube hace falta configurar un proyecto de Google Cloud (OAuth 2.0 Client ID, consentimiento OAuth y acceso a Google Drive `appDataFolder`). No se debe simular un inicio de sesión ni pedir la contraseña de Google dentro de Miércoles. Sin ese Client ID no es posible activar un inicio de sesión real y seguro. Cuando se proporcione el Client ID web autorizado, se puede completar el acceso con Google y la sincronización privada de chats.

## Cuentas propias y recuperación de chats
Se añadió una pantalla obligatoria de inicio de sesión/registro con correo y contraseña de Miércoles (sin Google). La sincronización está preparada con Supabase Auth y las tablas `profiles` y `chats` protegidas por Row Level Security. La URL y la clave publishable están configuradas en `assets-web/supabase-config.js`. Antes de probar, ejecuta `SUPABASE-SETUP.sql` en el SQL Editor del proyecto y configura las URL de autenticación. Lee `LEEME-CUENTAS.txt` antes de publicar.


## Pantalla de carga animada

Al abrir Miércoles se muestra una pantalla de bienvenida en tonos morado, negro y cian. El murciélago entra desde arriba y despliega las alas; la pantalla permanece mientras se comprueba la sesión y se sincronizan los chats. La animación respeta la preferencia de reducir movimiento del dispositivo.


## Versión 1.3 — Voz ElevenLabs
- La sala de voz y el botón «Escuchar» usan la Edge Function `miercoles_voice` de Supabase para generar MP3 con ElevenLabs.
- La llamada obtiene el access token vigente desde Supabase Auth y lo envía como Bearer; no expone la clave de ElevenLabs en el navegador.
- El audio se reproduce mediante el elemento Audio del navegador y la sala espera a que termine antes de volver a escuchar.
- Requiere que `assets-web/supabase-config.js` apunte al mismo proyecto Supabase donde se desplegó `miercoles_voice`, y que existan los secretos `ELEVENLABS_API_KEY` y `ELEVENLABS_VOICE_ID`.
- La función Edge debe aceptar POST autenticado y devolver `Content-Type: audio/mpeg`.
