MIÉRCOLES — PROYECTO MÓVIL CON CUENTAS
====================================

Incluye pantalla obligatoria de acceso, registro por correo/contraseña, sesión persistente y sincronización de conversaciones con Supabase en las tablas public.profiles y public.chats.

ANTES DE PROBAR
1. Ejecuta SUPABASE-SETUP.sql en el SQL Editor del proyecto configurado.
2. Configura Site URL y Redirect URLs en Supabase Authentication con el dominio HTTPS donde alojes la app.
3. Publica/importa la carpeta assets-web completa. No abras index.html como archivo local.
4. Prueba registro, confirmación de correo (si está activada), inicio de sesión, creación/eliminación de chats y recuperación en otro dispositivo.

La URL y la clave publishable del proyecto nuevo Miercoles-IA ya están en assets-web/supabase-config.js. No añadas service_role ni secret keys al cliente.

IMPORTANTE: este ZIP contiene el proyecto fuente, no un APK compilado. La clave Groq del cliente también puede extraerse; para distribución pública, pásala a un backend/Edge Function con límites por usuario.

CAMBIOS DE ESTA VERSIÓN
- Pantalla de inicio con murciélago vectorial rediseñado, entrada desde arriba y apertura de alas; mantiene la animación al menos 3,4 segundos.
- Los datos locales de conversaciones se guardan en un espacio separado por ID de usuario de Supabase. Al cambiar de cuenta, no se reutilizan ni se suben chats locales de otra cuenta.
- Supabase mantiene la sesión en el dispositivo (persistSession/autoRefreshToken), por lo que no solicita correo y contraseña cada vez que se abre la app. Se vuelve a pedir acceso al cerrar sesión o al borrar los datos de la aplicación.
- Las políticas RLS de SUPABASE-SETUP.sql siguen siendo obligatorias para que cada usuario solo pueda leer y modificar sus filas.

NOTA DE PRIVACIDAD DEL DISPOSITIVO
La sesión persistente significa que cualquier persona que tenga acceso físico a un teléfono desbloqueado donde Miércoles siga con la sesión abierta podría usar esa cuenta. Para compartir un mismo teléfono, usa el botón “Salir” al terminar o protege el teléfono con bloqueo de pantalla. En otro dispositivo, la persona debe iniciar sesión con sus propias credenciales.
