-- MIÉRCOLES: perfiles y conversaciones por cuenta
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text,
  created_at timestamptz default now()
);

create table if not exists public.chats (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text default 'Nueva conversación',
  messages jsonb not null default '[]'::jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

alter table public.profiles enable row level security;
alter table public.chats enable row level security;

drop policy if exists "Ver perfil propio" on public.profiles;
create policy "Ver perfil propio" on public.profiles for select to authenticated using (auth.uid() = id);
drop policy if exists "Crear perfil propio" on public.profiles;
create policy "Crear perfil propio" on public.profiles for insert to authenticated with check (auth.uid() = id);
drop policy if exists "Editar perfil propio" on public.profiles;
create policy "Editar perfil propio" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "Ver chats propios" on public.chats;
create policy "Ver chats propios" on public.chats for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Guardar chats propios" on public.chats;
create policy "Guardar chats propios" on public.chats for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Editar chats propios" on public.chats;
create policy "Editar chats propios" on public.chats for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Eliminar chats propios" on public.chats;
create policy "Eliminar chats propios" on public.chats for delete to authenticated using (auth.uid() = user_id);

-- Crea automáticamente el perfil cuando se registra una cuenta, incluso si debe confirmar el correo.
create or replace function public.handle_new_miercoles_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, username)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'username', split_part(new.email, '@', 1)))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_miercoles_auth_user_created on auth.users;
create trigger on_miercoles_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_miercoles_user();
