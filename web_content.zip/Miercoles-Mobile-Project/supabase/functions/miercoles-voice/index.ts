import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-api-version, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Max-Age": "86400",
};

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json", "Cache-Control": "no-store" },
  });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { status: 200, headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Método no permitido." }, 405);

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseKey = Deno.env.get("SUPABASE_ANON_KEY") || Deno.env.get("SUPABASE_PUBLISHABLE_KEY");
    const elevenKey = Deno.env.get("ELEVENLABS_API_KEY");
    const voiceId = Deno.env.get("ELEVENLABS_VOICE_ID");

    if (!supabaseUrl || !supabaseKey || !elevenKey || !voiceId) {
      console.error("Faltan variables de entorno de Supabase o ElevenLabs.");
      return json({ error: "La función de voz no está configurada. Revisa los secretos de Supabase." }, 500);
    }

    const authorization = req.headers.get("Authorization") || "";
    const token = authorization.replace(/^Bearer\s+/i, "").trim();
    if (!token) return json({ error: "Inicia sesión para usar la voz." }, 401);

    const supabase = createClient(supabaseUrl, supabaseKey, {
      global: { headers: { Authorization: "Bearer " + token } },
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const { data: userData, error: userError } = await supabase.auth.getUser(token);
    if (userError || !userData.user) return json({ error: "Tu sesión de Supabase no es válida. Vuelve a iniciar sesión." }, 401);

    const body = await req.json().catch(() => ({}));
    const text = typeof body.text === "string" ? body.text.trim() : "";
    if (!text) return json({ error: "No recibí texto para convertir en voz." }, 400);
    if (text.length > 3500) return json({ error: "El fragmento de texto supera el límite permitido." }, 413);

    const elevenResponse = await fetch(
      "https://api.elevenlabs.io/v1/text-to-speech/" + encodeURIComponent(voiceId) + "?output_format=mp3_44100_128",
      {
        method: "POST",
        headers: {
          "xi-api-key": elevenKey,
          "Content-Type": "application/json",
          "Accept": "audio/mpeg",
        },
        body: JSON.stringify({
          text,
          model_id: "eleven_multilingual_v2",
          voice_settings: { stability: 0.48, similarity_boost: 0.82, style: 0.25, use_speaker_boost: true },
        }),
      },
    );

    if (!elevenResponse.ok) {
      const detail = await elevenResponse.text();
      console.error("ElevenLabs:", elevenResponse.status, detail.slice(0, 1000));
      const message = elevenResponse.status === 401 || elevenResponse.status === 403
        ? "ElevenLabs rechazó la clave API. Revisa ELEVENLABS_API_KEY en Supabase."
        : elevenResponse.status === 404
          ? "No se encontró el ID de voz. Revisa ELEVENLABS_VOICE_ID en Supabase."
          : elevenResponse.status === 429
            ? "ElevenLabs alcanzó el límite de uso. Inténtalo más tarde."
            : "ElevenLabs no pudo generar el audio. Revisa el registro de la función.";
      return json({ error: message }, elevenResponse.status === 429 ? 429 : 502);
    }

    return new Response(elevenResponse.body, {
      status: 200,
      headers: {
        ...corsHeaders,
        "Content-Type": "audio/mpeg",
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    console.error("miercoles-voice:", error);
    return json({ error: "Error interno al generar la voz." }, 500);
  }
});
