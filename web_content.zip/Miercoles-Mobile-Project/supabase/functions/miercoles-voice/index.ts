import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") {
    return Response.json({ error: "Método no permitido." }, { status: 405, headers: corsHeaders });
  }

  try {
    const authorization = req.headers.get("Authorization") || "";
    const token = authorization.replace(/^Bearer\s+/i, "");
    if (!token) return Response.json({ error: "Debes iniciar sesión." }, { status: 401, headers: corsHeaders });

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY");
    const elevenKey = Deno.env.get("ELEVENLABS_API_KEY");
    const voiceId = Deno.env.get("ELEVENLABS_VOICE_ID");
    if (!supabaseUrl || !supabaseAnonKey || !elevenKey || !voiceId) {
      console.error("Falta configurar SUPABASE_URL, SUPABASE_ANON_KEY o secretos de ElevenLabs.");
      return Response.json({ error: "La función de voz no está configurada completamente." }, { status: 500, headers: corsHeaders });
    }

    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: `Bearer ${token}` } },
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const { data: userData, error: userError } = await supabase.auth.getUser(token);
    if (userError || !userData.user) {
      return Response.json({ error: "Tu sesión no es válida. Vuelve a iniciar sesión." }, { status: 401, headers: corsHeaders });
    }

    const body = await req.json().catch(() => ({}));
    const text = typeof body.text === "string" ? body.text.trim() : "";
    if (!text) return Response.json({ error: "No recibí texto para convertir en voz." }, { status: 400, headers: corsHeaders });
    if (text.length > 4000) return Response.json({ error: "El texto es demasiado largo para una sola respuesta de voz." }, { status: 413, headers: corsHeaders });

    const elevenResponse = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voiceId)}?output_format=mp3_44100_128`, {
      method: "POST",
      headers: {
        "xi-api-key": elevenKey,
        "Content-Type": "application/json",
        "Accept": "audio/mpeg",
      },
      body: JSON.stringify({
        text,
        model_id: "eleven_multilingual_v2",
        voice_settings: {
          stability: 0.48,
          similarity_boost: 0.82,
          style: 0.25,
          use_speaker_boost: true,
        },
      }),
    });

    if (!elevenResponse.ok) {
      const detail = await elevenResponse.text();
      console.error("ElevenLabs error", elevenResponse.status, detail.slice(0, 1200));
      const message = elevenResponse.status === 401 || elevenResponse.status === 403
        ? "ElevenLabs rechazó la API Key. Comprueba el secreto ELEVENLABS_API_KEY."
        : elevenResponse.status === 404
          ? "No se encontró la voz. Comprueba ELEVENLABS_VOICE_ID."
          : elevenResponse.status === 429
            ? "Se alcanzó el límite de ElevenLabs. Espera un momento e inténtalo de nuevo."
            : "ElevenLabs no pudo generar el audio. Comprueba tu cuenta y los permisos.";
      return Response.json({ error: message }, { status: elevenResponse.status === 429 ? 429 : 502, headers: corsHeaders });
    }

    return new Response(elevenResponse.body, {
      status: 200,
      headers: {
        ...corsHeaders,
        "Content-Type": "audio/mpeg",
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    console.error("miercoles-voice error", error);
    return Response.json({ error: "Ocurrió un error al generar la voz." }, { status: 500, headers: corsHeaders });
  }
});
