/* CONFIGURACIÓN PÚBLICA DE SUPABASE PARA MIÉRCOLES
   La clave publishable está diseñada para el cliente. Nunca incluyas service_role/secret.
*/
window.MIERCOLES_SUPABASE_URL = "https://jzgpsbskynrquhzchkfd.supabase.co";
window.MIERCOLES_SUPABASE_ANON_KEY = "sb_publishable_S7fXTEpQ3_I1PG63Pw4PGw_EZ42t--d";
