/* CONFIGURACIÓN PÚBLICA DE SUPABASE PARA MIÉRCOLES
   Solo la URL y la clave publishable deben estar en el cliente.
   Las claves secretas deben configurarse exclusivamente en el backend.
*/
window.MIERCOLES_SUPABASE_URL = "https://pjibawdbzeitkcnodbvn.supabase.co";
window.MIERCOLES_SUPABASE_ANON_KEY = "sb_publishable_B5JNgp21-rksjiJWsJODPw_lDWzaNK3";
