(function() {
  // ================= AUDIO SYSTEM =================
  const audioBank = {
    pop:   document.getElementById('soundPop'),
    line:  document.getElementById('soundLine'),
    boom:  document.getElementById('soundBoom'),
    coin:  document.getElementById('soundCoin'),
    click: document.getElementById('soundClick'),
    win:   document.getElementById('soundWin'),
    fail:  document.getElementById('soundFail'),
  };

  // Tracks which real mp3 files actually exist/load; if a file is missing
  // or fails, we fall back to a synthesized tone so the effect still plays.
  const audioAvailable = {};
  Object.keys(audioBank).forEach((name) => {
    audioAvailable[name] = true;
    const el = audioBank[name];
    if (el) el.addEventListener('error', () => { audioAvailable[name] = false; });
  });

  // ---- Synthesized fallback sound effects (Web Audio API) ----
  let actx = null;
  function getAudioCtx() {
    if (!actx) {
      try { actx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { actx = null; }
    }
    return actx;
  }
  function synthTone(freq, duration, type, volume, delay) {
    const ctx = getAudioCtx();
    if (!ctx) return;
    const t0 = ctx.currentTime + (delay || 0);
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type || 'sine';
    osc.frequency.setValueAtTime(freq, t0);
    gain.gain.setValueAtTime(0, t0);
    gain.gain.linearRampToValueAtTime(volume, t0 + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.001, t0 + duration);
    osc.connect(gain).connect(ctx.destination);
    osc.start(t0);
    osc.stop(t0 + duration + 0.03);
  }
  function synthNoiseBurst(duration, volume, delay) {
    const ctx = getAudioCtx();
    if (!ctx) return;
    const t0 = ctx.currentTime + (delay || 0);
    const bufferSize = Math.floor(ctx.sampleRate * duration);
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / bufferSize);
    const noise = ctx.createBufferSource();
    noise.buffer = buffer;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(volume, t0);
    gain.gain.exponentialRampToValueAtTime(0.001, t0 + duration);
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 500;
    noise.connect(filter).connect(gain).connect(ctx.destination);
    noise.start(t0);
  }
  const synthEffects = {
    pop:   (vol) => synthTone(720, 0.08, 'triangle', vol * 0.5),
    click: (vol) => synthTone(900, 0.04, 'square', vol * 0.25),
    coin:  (vol) => { synthTone(880, 0.08, 'sine', vol * 0.4); synthTone(1318, 0.12, 'sine', vol * 0.4, 0.07); },
    line:  (vol) => { [523, 659, 784, 1047].forEach((f, i) => synthTone(f, 0.12, 'sine', vol * 0.4, i * 0.05)); },
    boom:  (vol) => synthNoiseBurst(0.3, vol * 0.6),
    win:   (vol) => { [523, 659, 784, 1047, 1319].forEach((f, i) => synthTone(f, 0.15, 'triangle', vol * 0.4, i * 0.09)); },
    fail:  (vol) => { synthTone(300, 0.25, 'sawtooth', vol * 0.35); synthTone(200, 0.35, 'sawtooth', vol * 0.3, 0.12); },
  };

  let soundEnabled = true;
  try {
    const saved = localStorage.getItem('soundEnabled');
    if (saved !== null) soundEnabled = saved === 'true';
  } catch(e) {}

  let musicEnabled = true;
  try {
    const savedMusic = localStorage.getItem('musicEnabled');
    if (savedMusic !== null) musicEnabled = savedMusic === 'true';
  } catch(e) {}

  let vibrationEnabled = true;
  try {
    const savedVib = localStorage.getItem('vibrationEnabled');
    if (savedVib !== null) vibrationEnabled = savedVib === 'true';
  } catch(e) {}

  // ================= VIBRATION =================
  const vibrationPatterns = {
    pop: 10, line: 25, boom: 40, coin: 8, click: 8, win: [30, 50, 30], fail: 60
  };
  function vibrate(name) {
    if (!vibrationEnabled) return;
    if (!('vibrate' in navigator)) return;
    const pattern = vibrationPatterns[name];
    if (!pattern) return;
    try { navigator.vibrate(pattern); } catch (e) {}
  }

  function playSound(name, volume) {
    vibrate(name);
    if (!soundEnabled) return;
    const vol = (typeof volume === 'number') ? volume : 0.7;
    const s = audioBank[name];
    if (s && audioAvailable[name]) {
      try {
        s.currentTime = 0;
        s.volume = vol;
        const p = s.play();
        if (p && p.catch) {
          p.catch(() => { if (synthEffects[name]) synthEffects[name](vol); });
        }
        return;
      } catch (e) {}
    }
    if (synthEffects[name]) synthEffects[name](vol);
  }

  // ================= MUSIC =================
  const bgMusic = document.getElementById('bgMusic');
  function playMusic() {
    if (!musicEnabled || !bgMusic) return;
    try {
      bgMusic.volume = 0.35;
      const p = bgMusic.play();
      if (p && p.catch) p.catch(() => {});
    } catch (e) {}
  }
  function stopMusic() {
    try { if (bgMusic) bgMusic.pause(); } catch (e) {}
  }
  // Browsers block autoplay until a user gesture; start music on first tap —
  // but only if we're still on the menu (not straight into a level/game).
  function unlockMusicOnce() {
    const ctx = getAudioCtx();
    if (ctx && ctx.state === 'suspended') { try { ctx.resume(); } catch (e) {} }
    if (!menuEl.classList.contains('hide')) playMusic();
    document.removeEventListener('click', unlockMusicOnce);
    document.removeEventListener('touchstart', unlockMusicOnce);
  }
  document.addEventListener('click', unlockMusicOnce, { once: true });
  document.addEventListener('touchstart', unlockMusicOnce, { once: true });

  function unlockAudio() {
    Object.values(audioBank).forEach(s => {
      if (!s) return;
      try {
        s.volume = 0;
        const p = s.play();
        if (p && p.then) p.then(() => { s.pause(); s.currentTime = 0; s.volume = 1; }).catch(()=>{});
      } catch(e) {}
    });
    document.removeEventListener('touchstart', unlockAudio);
    document.removeEventListener('click', unlockAudio);
  }
  document.addEventListener('touchstart', unlockAudio, { once: true });
  document.addEventListener('click', unlockAudio, { once: true });

  document.addEventListener('click', (e) => {
    const btn = e.target.closest('button');
    if (btn) playSound('click', 0.5);
  }, true);

  // Toast
  const toastEl = document.getElementById('toast');
  let toastTimer = null;
  function showToast(msg) {
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('show'), 2000);
  }

  // ================= CONFIG =================
  const BOARD_SIZE = 8;
  const POINTS_PER_LINE = 500;
  const POINTS_PER_BLOCK = 1;
  const TOTAL_LEVELS = 500;
  const CHAPTER_SIZE = 50;
  const STORAGE_KEY = 'blockblast_progress_v13';

  const COIN_REWARD_1STAR = 25;
  const COIN_REWARD_2STAR = 50;
  const COIN_REWARD_3STAR = 100;
  const COIN_CLASSIC_PER_1000 = 10;

  const COLOR_NAMES = ['blue', 'orange', 'green', 'purple', 'yellow', 'red', 'cyan', 'pink'];

  const DAILY_REWARDS = [
    { day: 1, coins: 25,   icon: 'coin' },
    { day: 2, coins: 50,   icon: 'coin' },
    { day: 3, coins: 100,  icon: 'coin' },
    { day: 4, coins: 150,  icon: 'coin' },
    { day: 5, coins: 250,  icon: 'coin' },
    { day: 6, coins: 400,  icon: 'coin' },
    { day: 7, coins: 1000, icon: 'chest', items: { extra_piece: 1, clean_row: 1, bomb: 1, skip_level: 1 } },
  ];

  const STORE_ITEMS = [
    { id: 'extra_piece', name: 'Extra Piece', desc: 'Adds 1 extra piece to your tray', price: 50,  icon: 'plus' },
    { id: 'clean_row',   name: 'Clean Row',   desc: 'Clears the bottom-most occupied row', price: 120, icon: 'row' },
    { id: 'bomb',        name: 'Block Bomb',  desc: 'Tap board to blast 3×3 area', price: 200, icon: 'bomb' },
    { id: 'skip_level',  name: 'Skip Level',  desc: 'Skip current level and unlock next one', price: 500, icon: 'skip' },
  ];

  const SHAPES = [
    { cells: [[0,0]],                                          tier: 0, minLevel: 1 },
    { cells: [[0,0],[0,1]],                                    tier: 0, minLevel: 1 },
    { cells: [[0,0],[1,0]],                                    tier: 0, minLevel: 1 },
    { cells: [[0,0],[0,1],[0,2]],                              tier: 0, minLevel: 1 },
    { cells: [[0,0],[1,0],[2,0]],                              tier: 0, minLevel: 1 },
    { cells: [[0,0],[0,1],[1,0],[1,1]],                        tier: 0, minLevel: 1 },
    { cells: [[0,0],[0,1],[1,0]],                              tier: 1, minLevel: 1 },
    { cells: [[0,0],[0,1],[1,1]],                              tier: 1, minLevel: 1 },
    { cells: [[0,0],[1,0],[1,1]],                              tier: 1, minLevel: 1 },
    { cells: [[0,1],[1,0],[1,1]],                              tier: 1, minLevel: 1 },
    { cells: [[0,0],[0,1],[0,2],[0,3]],                        tier: 1, minLevel: 1 },
    { cells: [[0,0],[1,0],[2,0],[3,0]],                        tier: 1, minLevel: 1 },
    { cells: [[0,0],[0,1],[0,2],[1,1]],                        tier: 1, minLevel: 1 },
    { cells: [[0,0],[0,1],[1,1],[1,2]],                        tier: 1, minLevel: 1 },
    { cells: [[0,1],[0,2],[1,0],[1,1]],                        tier: 1, minLevel: 1 },
    { cells: [[0,0],[0,1],[1,0],[1,1],[2,0]],                  tier: 2, minLevel: 1 },
    { cells: [[0,0],[0,1],[0,2],[1,2],[2,2]],                  tier: 2, minLevel: 1 },
    { cells: [[0,0],[1,0],[1,1],[1,2]],                        tier: 2, minLevel: 1 },
    { cells: [[0,2],[1,2],[1,0],[1,1]],                        tier: 2, minLevel: 1 },
    { cells: [[0,0],[1,0],[2,0],[2,1]],                        tier: 2, minLevel: 1 },
    { cells: [[0,0],[0,1],[0,2],[0,3],[0,4]],                  tier: 2, minLevel: 1 },
    { cells: [[0,0],[1,0],[2,0],[3,0],[4,0]],                  tier: 2, minLevel: 1 },
    { cells: [[0,0],[0,1],[0,2],[1,0],[1,1],[1,2],[2,0],[2,1],[2,2]], tier: 3, minLevel: 5 },
    { cells: [[0,0],[0,1],[0,2],[1,0],[1,1],[1,2]],            tier: 4, minLevel: 10 },
    { cells: [[0,0],[0,1],[1,0],[1,1],[2,0],[2,1]],            tier: 4, minLevel: 10 },
    { cells: [[0,0],[0,1],[0,2],[1,0],[1,1],[1,2],[2,0],[2,1],[2,2]], tier: 4, minLevel: 10 },
    { cells: [[0,0],[0,1],[0,2],[0,3],[1,0],[1,1],[1,2],[1,3]], tier: 4, minLevel: 15 },
    { cells: [[0,0],[0,1],[1,0],[1,1],[2,0],[2,1],[3,0],[3,1]], tier: 4, minLevel: 15 },
    { cells: [[0,0],[0,1],[0,2],[0,3],[1,0],[1,1],[1,2],[1,3],[2,0],[2,1],[2,2],[2,3]], tier: 5, minLevel: 25 },
    { cells: [[0,0],[0,1],[0,2],[1,0],[1,1],[1,2],[2,0],[2,1],[2,2],[3,0],[3,1],[3,2]], tier: 5, minLevel: 25 },
    { cells: [[0,0],[0,1],[0,2],[0,3],[0,4],[0,5],[1,0],[1,1],[1,2],[1,3],[1,4],[1,5],[2,0],[2,1],[2,2],[2,3],[2,4],[2,5]], tier: 5, minLevel: 50 },
    { cells: [[0,0],[0,1],[0,2],[1,0],[1,1],[1,2],[2,0],[2,1],[2,2],[3,0],[3,1],[3,2],[4,0],[4,1],[4,2],[5,0],[5,1],[5,2]], tier: 5, minLevel: 50 },
    { cells: [[0,0],[0,1],[0,2],[0,3],[1,0],[1,1],[1,2],[1,3],[2,0],[2,1],[2,2],[2,3],[3,0],[3,1],[3,2],[3,3]], tier: 5, minLevel: 40 },
    { cells: [[0,0],[0,1],[0,2],[0,3],[0,4],[0,5],[1,0],[1,1],[1,2],[1,3],[1,4],[1,5]], tier: 5, minLevel: 40 },
    { cells: [[0,0],[0,1],[1,0],[1,1],[2,0],[2,1],[3,0],[3,1],[4,0],[4,1],[5,0],[5,1]], tier: 5, minLevel: 40 },
  ];

  function getTierWeightsClassic() {
    return { 0: 0.30, 1: 0.35, 2: 0.20, 3: 0.08, 4: 0.05, 5: 0.02, 6: 0 };
  }

  function getTierWeights(level) {
    const t = Math.min(1, (level - 1) / 200);
    const base = {
      0: 0.60 - 0.45 * t,
      1: 0.35 - 0.05 * t,
      2: 0.05 + 0.35 * t,
      3: 0.00 + 0.15 * t,
      4: 0, 5: 0, 6: 0,
    };
    if (level >= 10)  { base[3] = Math.max(0, base[3] - 0.05); base[4] = 0.05; }
    if (level >= 25)  { base[3] = Math.max(0, base[3] - 0.03); base[4] = 0.08; base[5] = 0.03; }
    if (level >= 50)  { base[4] = 0.10; base[5] = 0.06; }
    if (level >= 100) { base[5] = 0.08; base[6] = 0.02; }
    if (level >= 200) { base[5] = 0.10; base[6] = 0.05; }
    const sum = Object.values(base).reduce((a, b) => a + b, 0);
    for (const k in base) base[k] /= sum;
    return base;
  }

  function generateLevels() {
    const levels = [];
    for (let i = 1; i <= TOTAL_LEVELS; i++) {
      const base = 800 + i * 60 + Math.pow(i, 1.35) * 8;
      const wobble = ((i * 37) % 100) * 3;
      const target = Math.round((base + wobble) / 100) * 100;
      levels.push({ level: i, target: target });
    }
    return levels;
  }
  const LEVELS = generateLevels();

  // ================= STATE =================
  let board = [];
  let score = 0;
  let pieces = [null, null, null];
  let dragGhost = null;
  let isDragging = false;
  let dragData = null;
  let previewCells = [];
  let animating = false;
  let currentLevelIndex = 0;
  let levelComplete = false;
  let progress = {};
  let gameStarted = false;
  let gameMode = 'levels';
  let classicBest = 0;
  let coins = 0;
  let inventory = { extra_piece: 0, clean_row: 0, bomb: 0, skip_level: 0 };
  let activeBooster = null;

  let dailyStreak = 0;
  let lastDailyClaim = null;
  let lastDailyClaimDay = null;

  let boardRect = null;
  let boardCellSize = 0;

  // ================= DOM =================
  const splashEl = document.getElementById('splash');
  const menuEl = document.getElementById('menu');
  const gameEl = document.getElementById('game');
  const boardEl = document.getElementById('board');
  const trayEl = document.getElementById('tray');
  const bigScoreEl = document.getElementById('bigScore');
  const topScoreEl = document.getElementById('topScore');
  const menuCoinsEl = document.getElementById('menuCoins');
  const gameCoinsEl = document.getElementById('gameCoins');
  const mapCoinsEl = document.getElementById('mapCoins');
  const coinsDisplayEl = document.getElementById('coinsDisplay');
  const levelBadgeEl = document.getElementById('levelBadge');
  const targetBadgeEl = document.getElementById('targetBadge');
  const progressFillEl = document.getElementById('progressFill');
  const progressWrapEl = document.getElementById('progressWrap');
  const overlay = document.getElementById('overlay');
  const overlayTitle = document.getElementById('overlayTitle');
  const overlayLabel = document.getElementById('overlayLabel');
  const overlayScore = document.getElementById('overlayScore');
  const overlayStars = document.getElementById('overlayStars');
  const overlayCoins = document.getElementById('overlayCoins');
  const overlayCoinsAmount = document.getElementById('overlayCoinsAmount');
  const overlayPrimary = document.getElementById('overlayPrimary');
  const overlaySecondary = document.getElementById('overlaySecondary');
  const settingsBtn = document.getElementById('settingsBtn');
  const mapBtn = document.getElementById('mapBtn');
  const menuHomeBtn = document.getElementById('menuHomeBtn');
  const levelMap = document.getElementById('levelMap');
  const mapScroll = document.getElementById('mapScroll');
  const mapClose = document.getElementById('mapClose');
  const mapTitle = document.getElementById('mapTitle');
  const btnLevels = document.getElementById('btnLevels');
  const btnClassic = document.getElementById('btnClassic');
  const btnStore = document.getElementById('btnStore');
  const btnDaily = document.getElementById('btnDaily');
  const dailyBadge = document.getElementById('dailyBadge');
  const storeModal = document.getElementById('storeModal');
  const storeClose = document.getElementById('storeClose');
  const storeBalance = document.getElementById('storeBalance');
  const storeList = document.getElementById('storeList');
  const storeOwner = document.getElementById('storeOwner');
  const dailyModal = document.getElementById('dailyModal');
  const dailyClose = document.getElementById('dailyClose');
  const dailyGrid = document.getElementById('dailyGrid');
  const dailyClaimBtn = document.getElementById('dailyClaimBtn');
  const dailyStreakNum = document.getElementById('dailyStreakNum');
  const dailyNote = document.getElementById('dailyNote');
  const menuSettingsBtn = document.getElementById('menuSettingsBtn');
  const settingsModal = document.getElementById('settingsModal');
  const settingsClose = document.getElementById('settingsClose');
  const toggleSound = document.getElementById('toggleSound');
  const toggleMusic = document.getElementById('toggleMusic');
  const toggleVibration = document.getElementById('toggleVibration');

  // Booster buttons
  const boosterExtra = document.getElementById('boosterExtra');
  const boosterRow = document.getElementById('boosterRow');
  const boosterBomb = document.getElementById('boosterBomb');
  const boosterSkip = document.getElementById('boosterSkip');
  const countExtra = document.getElementById('countExtra');
  const countRow = document.getElementById('countRow');
  const countBomb = document.getElementById('countBomb');
  const countSkip = document.getElementById('countSkip');

  // ================= INDEXEDDB =================
  const IDB_NAME  = 'BlockBlastDB';
  const IDB_STORE = 'progress';
  const IDB_KEY   = 'save';
  let idbDB = null;

  function idbOpen() {
    return new Promise((resolve) => {
      if (!('indexedDB' in window)) { resolve(null); return; }
      try {
        const req = indexedDB.open(IDB_NAME, 1);
        req.onupgradeneeded = (e) => {
          const db = e.target.result;
          if (!db.objectStoreNames.contains(IDB_STORE)) {
            db.createObjectStore(IDB_STORE, { keyPath: 'key' });
          }
        };
        req.onsuccess = (e) => resolve(e.target.result);
        req.onerror = () => resolve(null);
      } catch (e) { resolve(null); }
    });
  }

  function idbLoad() {
    return new Promise((resolve) => {
      if (!idbDB) { resolve(null); return; }
      try {
        const tx = idbDB.transaction(IDB_STORE, 'readonly');
        const req = tx.objectStore(IDB_STORE).get(IDB_KEY);
        req.onsuccess = () => resolve(req.result ? req.result.data : null);
        req.onerror = () => resolve(null);
      } catch (e) { resolve(null); }
    });
  }

  function idbSave(data) {
    if (!idbDB) return;
    try {
      const tx = idbDB.transaction(IDB_STORE, 'readwrite');
      tx.objectStore(IDB_STORE).put({ key: IDB_KEY, data: data });
    } catch (e) {}
  }

  function applyProgressData(data) {
    if (!data) return;
    if (data.progress) progress = data.progress;
    if (typeof data.classicBest === 'number') classicBest = data.classicBest;
    if (typeof data.coins === 'number') coins = data.coins;
    if (data.inventory) inventory = Object.assign(inventory, data.inventory);
    if (typeof data.dailyStreak === 'number') dailyStreak = data.dailyStreak;
    if (typeof data.lastDailyClaim === 'number') lastDailyClaim = data.lastDailyClaim;
    if (typeof data.lastDailyClaimDay === 'string') lastDailyClaimDay = data.lastDailyClaimDay;
  }

  // Loads the fast, synchronous local copy first so the game can start
  // immediately, then IndexedDB (the durable, primary store) takes over
  // once it's ready and refreshes the UI if it has newer data.
  async function initStorage() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) applyProgressData(JSON.parse(raw));
    } catch (e) { progress = {}; }

    idbDB = await idbOpen();
    if (idbDB) {
      const idbData = await idbLoad();
      if (idbData) {
        applyProgressData(idbData);
        updateCoinsUI();
        updateDailyBadge();
        updateBoosterUI();
      } else {
        // First run on this device/browser: seed IndexedDB from whatever
        // localStorage already had (or the defaults) so it's never empty.
        idbSave({ progress, classicBest, coins, inventory, dailyStreak, lastDailyClaim, lastDailyClaimDay });
      }
    }
  }

  function loadProgress() { /* kept for compatibility; real loading happens in initStorage() */ }

  function saveProgress() {
    const data = { progress, classicBest, coins, inventory, dailyStreak, lastDailyClaim, lastDailyClaimDay };
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); } catch (e) {}
    idbSave(data);
  }
  function getStars(level) { const p = progress[level]; return p ? (p.stars || 0) : 0; }
  function getBestScore(level) { const p = progress[level]; return p ? (p.best || 0) : 0; }

  // ================= COINS =================
  function updateCoinsUI() {
    menuCoinsEl.textContent = coins;
    gameCoinsEl.textContent = coins;
    mapCoinsEl.textContent = coins;
    storeBalance.textContent = coins;
  }

  function addCoins(amount, x, y) {
    if (amount <= 0) return;
    coins += amount;
    updateCoinsUI();
    saveProgress();
    coinsDisplayEl.classList.remove('bump');
    void coinsDisplayEl.offsetWidth;
    coinsDisplayEl.classList.add('bump');
    playSound('coin', 0.6);
    if (typeof x === 'number' && typeof y === 'number') showCoinPopup(amount, x, y);
  }

  function showCoinPopup(amount, x, y) {
    const el = document.createElement('div');
    el.className = 'coin-popup';
    el.style.left = x + 'px';
    el.style.top = y + 'px';
    el.innerHTML = `<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" fill="#ffd75e" stroke="#a06d00" stroke-width="1.8"/><path d="M12 6v12M9 9h4.5a2.5 2.5 0 0 1 0 5H9h5.5a2.5 2.5 0 0 1 0 5H9" stroke="#a06d00" stroke-width="1.6" stroke-linecap="round"/></svg>+${amount}`;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 1300);
  }

  function showScorePopup(text, x, y) {
    const el = document.createElement('div');
    el.className = 'score-popup';
    el.style.left = x + 'px';
    el.style.top = y + 'px';
    el.textContent = text;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 1200);
  }

  // ================= COMBO PRAISE POPUP =================
  const COMBO_LABELS = [
    null,
    { text: 'GOOD!',    emoji: '👍' },
    { text: 'PERFECT!', emoji: '🎉' },
    { text: 'PERFECT!', emoji: '🌟' },
    { text: 'PERFECT!', emoji: '🤩' },
  ];
  function showComboPopup(lines, x, y) {
    const info = COMBO_LABELS[Math.min(lines, COMBO_LABELS.length - 1)];
    if (!info) return;
    const el = document.createElement('div');
    el.className = 'combo-popup';
    el.style.left = x + 'px';
    el.style.top = y + 'px';
    el.innerHTML = `<span class="combo-emoji">${info.emoji}</span><span class="combo-text">${info.text}</span>`;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 1000);
  }

  // ================= BOARD =================
  function createBoard() {
    boardEl.innerHTML = '';
    board = [];
    for (let r = 0; r < BOARD_SIZE; r++) {
      board[r] = [];
      for (let c = 0; c < BOARD_SIZE; c++) {
        board[r][c] = 0;
        const cell = document.createElement('div');
        cell.className = 'cell';
        cell.dataset.r = r;
        cell.dataset.c = c;
        boardEl.appendChild(cell);
      }
    }
    updateBoardRect();
  }

  function updateBoardRect() {
    boardRect = boardEl.getBoundingClientRect();
    const style = getComputedStyle(boardEl);
    const padding = parseFloat(style.paddingLeft) || 8;
    const gap = parseFloat(style.gap) || 2;
    boardCellSize = (boardRect.width - padding * 2 - gap * (BOARD_SIZE - 1)) / BOARD_SIZE;
  }

  function renderBoard() {
    const cells = boardEl.children;
    for (let r = 0; r < BOARD_SIZE; r++) {
      for (let c = 0; c < BOARD_SIZE; c++) {
        const cell = cells[r * BOARD_SIZE + c];
        if (!cell) continue;
        cell.classList.remove('preview-valid', 'preview-invalid', 'flash', 'bomb-blast');
        if (board[r][c]) {
          if (!cell.classList.contains('filled')) cell.classList.add('filled');
        } else {
          cell.classList.remove('filled');
          COLOR_NAMES.forEach(cn => cell.classList.remove('color-' + cn));
        }
      }
    }
  }

  // ================= PIECES =================
  function pickRandomShape(level) {
    const weights = gameMode === 'classic' ? getTierWeightsClassic() : getTierWeights(level);
    const r = Math.random();
    let acc = 0;
    let chosenTier = 0;
    for (const k in weights) {
      acc += weights[k];
      if (r <= acc) { chosenTier = parseInt(k); break; }
    }
    let pool = SHAPES.filter(s => s.tier === chosenTier && level >= s.minLevel);
    if (pool.length === 0) pool = SHAPES.filter(s => level >= s.minLevel);
    if (pool.length === 0) pool = SHAPES;
    return pool[Math.floor(Math.random() * pool.length)];
  }

  function generatePiece(level) {
    const shape = pickRandomShape(level);
    const color = COLOR_NAMES[Math.floor(Math.random() * COLOR_NAMES.length)];
    return { cells: shape.cells.map(c => [...c]), color: color };
  }

  function generateTray(level) {
    pieces = [generatePiece(level), generatePiece(level), generatePiece(level)];
    renderTray();
  }

  function renderTray() {
    for (let i = 0; i < 3; i++) {
      const slot = document.getElementById('slot' + i);
      slot.innerHTML = '';
      const piece = pieces[i];
      if (!piece) continue;

      const minR = Math.min(...piece.cells.map(c => c[0]));
      const minC = Math.min(...piece.cells.map(c => c[1]));
      const normalized = piece.cells.map(([r, c]) => [r - minR, c - minC]);
      const maxR = Math.max(...normalized.map(c => c[0]));
      const maxC = Math.max(...normalized.map(c => c[1]));

      const pieceEl = document.createElement('div');
      pieceEl.className = 'piece';
      pieceEl.style.gridTemplateColumns = `repeat(${maxC + 1}, 18px)`;
      pieceEl.style.gridTemplateRows = `repeat(${maxR + 1}, 18px)`;
      pieceEl.dataset.slot = i;
      pieceEl.dataset.pieceIndex = i;

      const cellSet = new Set(normalized.map(([r, c]) => r + ',' + c));
      for (let r = 0; r <= maxR; r++) {
        for (let c = 0; c <= maxC; c++) {
          const mc = document.createElement('div');
          mc.className = 'mini-cell';
          if (cellSet.has(r + ',' + c)) {
            mc.classList.add('filled');
            if (piece.color) mc.classList.add('color-' + piece.color);
          }
          pieceEl.appendChild(mc);
        }
      }
      pieceEl.addEventListener('pointerdown', onPieceDown);
      slot.appendChild(pieceEl);
    }
  }

  // ================= DRAG & DROP =================
  function onPieceDown(e) {
    if (animating || levelComplete || activeBooster) return;
    const pieceEl = e.currentTarget;
    const idx = parseInt(pieceEl.dataset.pieceIndex);
    if (!pieces[idx]) return;

    e.preventDefault();
    isDragging = true;
    const piece = pieces[idx];
    const minR = Math.min(...piece.cells.map(c => c[0]));
    const minC = Math.min(...piece.cells.map(c => c[1]));
    const normalized = piece.cells.map(([r, c]) => [r - minR, c - minC]);

    dragData = {
      piece, normalized, index: idx,
      offsetX: 0, offsetY: 0, pointerId: e.pointerId,
    };

    createDragGhost(normalized);
    updateBoardRect();

    const rect = pieceEl.getBoundingClientRect();
    dragData.offsetX = e.clientX - rect.left;
    dragData.offsetY = e.clientY - rect.top;

    pieceEl.classList.add('dragging');
    positionGhost(e.clientX, e.clientY);
    updatePreview(e.clientX, e.clientY);

    document.addEventListener('pointermove', onPointerMove);
    document.addEventListener('pointerup', onPointerUp);
    document.addEventListener('pointercancel', onPointerUp);
  }

  function createDragGhost(normalized) {
    if (dragGhost) dragGhost.remove();
    const maxR = Math.max(...normalized.map(c => c[0]));
    const maxC = Math.max(...normalized.map(c => c[1]));
    dragGhost = document.createElement('div');
    dragGhost.className = 'drag-ghost';
    const size = Math.max(maxR + 1, maxC + 1);
    if (size >= 6) dragGhost.classList.add('xl');
    else if (size >= 4) dragGhost.classList.add('large');
    dragGhost.style.gridTemplateColumns = `repeat(${maxC + 1}, auto)`;
    dragGhost.style.gridTemplateRows = `repeat(${maxR + 1}, auto)`;
    const set = new Set(normalized.map(([r, c]) => r + ',' + c));
    for (let r = 0; r <= maxR; r++) {
      for (let c = 0; c <= maxC; c++) {
        const gc = document.createElement('div');
        gc.className = 'ghost-cell';
        if (set.has(r + ',' + c)) {
          gc.classList.add('filled');
          if (dragData && dragData.piece && dragData.piece.color) {
            gc.classList.add('color-' + dragData.piece.color);
          }
        }
        dragGhost.appendChild(gc);
      }
    }
    document.body.appendChild(dragGhost);
  }

  function positionGhost(x, y) {
    if (!dragGhost || !dragData) return;
    const gx = x - dragData.offsetX;
    const gy = y - dragData.offsetY;
    dragGhost.style.transform = `translate3d(${gx}px, ${gy}px, 0)`;
  }

  function onPointerMove(e) {
    if (!isDragging || !dragData) return;
    e.preventDefault();
    positionGhost(e.clientX, e.clientY);
    updatePreview(e.clientX, e.clientY);
  }

  function updatePreview(x, y) {
    clearPreview();
    if (!dragData || !boardRect) return;

    const gx = x - dragData.offsetX;
    const gy = y - dragData.offsetY;
    const localX = gx - boardRect.left;
    const localY = gy - boardRect.top;

    const padding = 8;
    const gap = 2;
    const cellStep = boardCellSize + gap;

    let col = Math.round((localX - padding) / cellStep);
    let row = Math.round((localY - padding) / cellStep);

    const norm = dragData.normalized;
    const pieceW = Math.max(...norm.map(c => c[1])) + 1;
    const pieceH = Math.max(...norm.map(c => c[0])) + 1;

    row = Math.max(0, Math.min(BOARD_SIZE - pieceH, row));
    col = Math.max(0, Math.min(BOARD_SIZE - pieceW, col));

    const cells = boardEl.children;
    let valid = true;
    const previewList = [];

    for (const [r, c] of norm) {
      const br = row + r;
      const bc = col + c;
      if (br < 0 || br >= BOARD_SIZE || bc < 0 || bc >= BOARD_SIZE) { valid = false; break; }
      if (board[br][bc]) { valid = false; }
      previewList.push([br, bc]);
    }

    dragData.pendingRow = row;
    dragData.pendingCol = col;
    dragData.valid = valid;

    for (const [br, bc] of previewList) {
      const cell = cells[br * BOARD_SIZE + bc];
      if (cell) cell.classList.add(valid ? 'preview-valid' : 'preview-invalid');
    }
    previewCells = previewList;
  }

  function clearPreview() {
    for (const [r, c] of previewCells) {
      const cell = boardEl.children[r * BOARD_SIZE + c];
      if (cell) cell.classList.remove('preview-valid', 'preview-invalid');
    }
    previewCells = [];
  }

  function onPointerUp(e) {
    if (!isDragging || !dragData) return;
    document.removeEventListener('pointermove', onPointerMove);
    document.removeEventListener('pointerup', onPointerUp);
    document.removeEventListener('pointercancel', onPointerUp);

    const wasValid = dragData.valid;
    const row = dragData.pendingRow;
    const col = dragData.pendingCol;
    const idx = dragData.index;

    if (dragGhost) { dragGhost.remove(); dragGhost = null; }
    clearPreview();

    const pieceEl = document.querySelector(`.piece[data-piece-index="${idx}"]`);
    if (pieceEl) pieceEl.classList.remove('dragging');

    isDragging = false;
    const savedDrag = dragData;
    dragData = null;

    if (wasValid && typeof row === 'number' && typeof col === 'number') {
      placePiece(idx, row, col, savedDrag.normalized, savedDrag.piece.color);
    }
  }

  // ================= PLACE PIECE =================
  function placePiece(idx, row, col, norm, color) {
    if (animating) return;
    animating = true;

    const useColor = color || 'blue';

    for (const [r, c] of norm) {
      board[row + r][col + c] = 1;
      const cell = boardEl.children[(row + r) * BOARD_SIZE + (col + c)];
      if (cell) {
        cell.classList.add('filled');
        COLOR_NAMES.forEach(cn => cell.classList.remove('color-' + cn));
        cell.classList.add('color-' + useColor);
      }
    }
    score += norm.length * POINTS_PER_BLOCK;
    playSound('pop', 0.7);

    pieces[idx] = null;
    const slot = document.getElementById('slot' + idx);
    if (slot) slot.innerHTML = '';

    updateScoreUI();

    setTimeout(() => {
      const cleared = checkLines();
      if (cleared > 0) playSound('line', 0.85);

      setTimeout(() => {
        animating = false;
        checkLevelStatus();
        if (pieces[0] === null && pieces[1] === null && pieces[2] === null) {
          const nextLvl = gameMode === 'classic' ? 1 : Math.min(TOTAL_LEVELS, currentLevelIndex + 1);
          generateTray(nextLvl);
        }
      }, 350);
    }, 150);
  }

  // ================= LINES =================
  function checkLines() {
    const rowsToClear = [];
    const colsToClear = [];

    for (let r = 0; r < BOARD_SIZE; r++) {
      if (board[r].every(v => v)) rowsToClear.push(r);
    }
    for (let c = 0; c < BOARD_SIZE; c++) {
      let full = true;
      for (let r = 0; r < BOARD_SIZE; r++) if (!board[r][c]) { full = false; break; }
      if (full) colsToClear.push(c);
    }

    const totalLines = rowsToClear.length + colsToClear.length;
    if (totalLines === 0) return 0;

    const gain = totalLines * POINTS_PER_LINE;
    score += gain;
    updateScoreUI();

    for (const r of rowsToClear) {
      for (let c = 0; c < BOARD_SIZE; c++) {
        const cell = boardEl.children[r * BOARD_SIZE + c];
        if (cell) cell.classList.add('flash');
      }
    }
    for (const c of colsToClear) {
      for (let r = 0; r < BOARD_SIZE; r++) {
        const cell = boardEl.children[r * BOARD_SIZE + c];
        if (cell) cell.classList.add('flash');
      }
    }

    setTimeout(() => {
      for (const r of rowsToClear) {
        for (let c = 0; c < BOARD_SIZE; c++) {
          board[r][c] = 0;
          const cell = boardEl.children[r * BOARD_SIZE + c];
          if (cell) {
            cell.classList.remove('filled', 'flash');
            COLOR_NAMES.forEach(cn => cell.classList.remove('color-' + cn));
          }
        }
      }
      for (const c of colsToClear) {
        for (let r = 0; r < BOARD_SIZE; r++) {
          board[r][c] = 0;
          const cell = boardEl.children[r * BOARD_SIZE + c];
          if (cell) {
            cell.classList.remove('filled', 'flash');
            COLOR_NAMES.forEach(cn => cell.classList.remove('color-' + cn));
          }
        }
      }
      const rect = boardEl.getBoundingClientRect();
      showScorePopup('+' + gain, rect.left + rect.width / 2, rect.top + rect.height / 2);
    }, 500);

    boardEl.classList.remove('shake');
    void boardEl.offsetWidth;
    boardEl.classList.add('shake');

    const rectNow = boardEl.getBoundingClientRect();
    showComboPopup(totalLines, rectNow.left + rectNow.width / 2, rectNow.top + rectNow.height / 2.6);

    return totalLines;
  }

  function updateScoreUI() {
    bigScoreEl.textContent = score.toLocaleString();
    topScoreEl.textContent = score.toLocaleString();
    bigScoreEl.classList.remove('bump');
    void bigScoreEl.offsetWidth;
    bigScoreEl.classList.add('bump');
  }

  // ================= BOOSTER SYSTEM =================
  function updateBoosterUI() {
    countExtra.textContent = inventory.extra_piece || 0;
    countRow.textContent = inventory.clean_row || 0;
    countBomb.textContent = inventory.bomb || 0;
    countSkip.textContent = inventory.skip_level || 0;

    boosterExtra.classList.toggle('empty', !inventory.extra_piece || inventory.extra_piece <= 0);
    boosterRow.classList.toggle('empty', !inventory.clean_row || inventory.clean_row <= 0);
    boosterBomb.classList.toggle('empty', !inventory.bomb || inventory.bomb <= 0);
    boosterSkip.classList.toggle('empty', !inventory.skip_level || inventory.skip_level <= 0);

    boosterExtra.classList.toggle('active', activeBooster === 'extra_piece');
    boosterRow.classList.toggle('active', activeBooster === 'clean_row');
    boosterBomb.classList.toggle('active', activeBooster === 'bomb');
    boosterSkip.classList.toggle('active', activeBooster === 'skip_level');

    boardEl.classList.toggle('bomb-mode', activeBooster === 'bomb');
  }

  function useExtraPiece() {
    if (!inventory.extra_piece || inventory.extra_piece <= 0) {
      showToast('No Extra Piece left!');
      return;
    }
    if (pieces.every(p => p !== null)) {
      showToast('Tray is full!');
      return;
    }
    inventory.extra_piece--;
    // Find first empty slot
    let emptyIdx = pieces.findIndex(p => p === null);
    if (emptyIdx === -1) emptyIdx = 0;
    const lvl = gameMode === 'classic' ? 1 : Math.min(TOTAL_LEVELS, currentLevelIndex + 1);
    pieces[emptyIdx] = generatePiece(lvl);
    renderTray();
    saveProgress();
    updateBoosterUI();
    playSound('pop', 0.8);
    showToast('Extra piece added!');
  }

  function useCleanRow() {
    if (!inventory.clean_row || inventory.clean_row <= 0) {
      showToast('No Clean Row left!');
      return;
    }
    // Find bottom-most occupied row
    let bottomRow = -1;
    for (let r = BOARD_SIZE - 1; r >= 0; r--) {
      if (board[r].some(v => v)) { bottomRow = r; break; }
    }
    if (bottomRow === -1) {
      showToast('Board is empty!');
      return;
    }
    inventory.clean_row--;
    // Clear that row
    for (let c = 0; c < BOARD_SIZE; c++) {
      board[bottomRow][c] = 0;
      const cell = boardEl.children[bottomRow * BOARD_SIZE + c];
      if (cell) {
        cell.classList.add('flash');
        setTimeout(() => {
          cell.classList.remove('filled', 'flash');
          COLOR_NAMES.forEach(cn => cell.classList.remove('color-' + cn));
        }, 300);
      }
    }
    playSound('line', 0.9);
    setTimeout(() => {
      checkLines();
      checkLevelStatus();
    }, 400);
    saveProgress();
    updateBoosterUI();
    showToast('Bottom row cleared!');
  }

  function useBomb() {
    if (!inventory.bomb || inventory.bomb <= 0) {
      showToast('No Bomb left!');
      return;
    }
    if (activeBooster === 'bomb') {
      activeBooster = null;
      updateBoosterUI();
      return;
    }
    activeBooster = 'bomb';
    updateBoosterUI();
    showToast('Tap a block on the board to blast!');
  }

  function detonateBomb(r, c) {
    if (!inventory.bomb || inventory.bomb <= 0) return;
    inventory.bomb--;
    saveProgress();
    updateBoosterUI();
    activeBooster = null;

    playSound('boom', 1.0);
    boardEl.classList.remove('bomb-mode');
    boardEl.classList.add('shake');

    // 3x3 area
    const toClear = [];
    for (let dr = -1; dr <= 1; dr++) {
      for (let dc = -1; dc <= 1; dc++) {
        const br = r + dr;
        const bc = c + dc;
        if (br >= 0 && br < BOARD_SIZE && bc >= 0 && bc < BOARD_SIZE) {
          toClear.push([br, bc]);
        }
      }
    }

    for (const [br, bc] of toClear) {
      if (board[br][bc]) {
        const cell = boardEl.children[br * BOARD_SIZE + bc];
        if (cell) {
          cell.classList.add('bomb-blast');
        }
      }
    }

    // Explosion ring effect
    const rect = boardEl.getBoundingClientRect();
    const padding = 8, gap = 2;
    const cellStep = boardCellSize + gap;
    const cx = rect.left + padding + c * cellStep + boardCellSize / 2;
    const cy = rect.top + padding + r * cellStep + boardCellSize / 2;
    const ring = document.createElement('div');
    ring.className = 'boom-ring';
    ring.style.left = cx + 'px';
    ring.style.top = cy + 'px';
    document.body.appendChild(ring);
    setTimeout(() => ring.remove(), 800);

    setTimeout(() => {
      for (const [br, bc] of toClear) {
        board[br][bc] = 0;
        const cell = boardEl.children[br * BOARD_SIZE + bc];
        if (cell) {
          cell.classList.remove('filled', 'bomb-blast');
          COLOR_NAMES.forEach(cn => cell.classList.remove('color-' + cn));
        }
      }
      checkLines();
      checkLevelStatus();
      showToast('Bomb blasted!');
    }, 500);
  }

  function useSkipLevel() {
    if (gameMode !== 'levels') {
      showToast('Skip only works in Level mode!');
      return;
    }
    if (!inventory.skip_level || inventory.skip_level <= 0) {
      showToast('No Skip Level left!');
      return;
    }
    inventory.skip_level--;
    saveProgress();
    updateBoosterUI();

    // Mark current level as completed with 1 star
    const lvl = LEVELS[currentLevelIndex];
    if (lvl) {
      const prev = getStars(lvl.level);
      progress[lvl.level] = {
        stars: Math.max(prev, 1),
        best: getBestScore(lvl.level)
      };
    }
    saveProgress();
    playSound('win', 0.9);
    showToast('Level skipped!');

    setTimeout(() => {
      if (currentLevelIndex + 1 < LEVELS.length) {
        currentLevelIndex++;
        startLevel(currentLevelIndex);
      } else {
        goToMenu();
      }
    }, 500);
  }

  // Booster click handlers
  boosterExtra.addEventListener('click', () => useExtraPiece());
  boosterRow.addEventListener('click', () => useCleanRow());
  boosterBomb.addEventListener('click', () => useBomb());
  boosterSkip.addEventListener('click', () => useSkipLevel());

  // Board click for bomb
  boardEl.addEventListener('click', (e) => {
    if (activeBooster !== 'bomb') return;
    const cell = e.target.closest('.cell');
    if (!cell) return;
    const r = parseInt(cell.dataset.r);
    const c = parseInt(cell.dataset.c);
    if (isNaN(r) || isNaN(c)) return;
    detonateBomb(r, c);
  });

  // ================= LEVEL STATUS =================
  function checkLevelStatus() {
    if (gameMode === 'classic') {
      if (isBoardFull() && !canPlaceAnyPiece()) endClassic();
      return;
    }
    const lvl = LEVELS[currentLevelIndex];
    if (!lvl) return;
    const pct = Math.min(1, score / lvl.target);
    progressFillEl.style.width = (pct * 100) + '%';

    if (score >= lvl.target && !levelComplete) {
      levelComplete = true;
      setTimeout(() => showLevelComplete(), 400);
    } else if (isBoardFull() && !canPlaceAnyPiece()) {
      setTimeout(() => showGameOver(), 400);
    }
  }

  function isBoardFull() {
    for (let r = 0; r < BOARD_SIZE; r++)
      for (let c = 0; c < BOARD_SIZE; c++)
        if (!board[r][c]) return false;
    return true;
  }

  function canPlaceAnyPiece() {
    for (const piece of pieces) {
      if (!piece) continue;
      const minR = Math.min(...piece.cells.map(c => c[0]));
      const minC = Math.min(...piece.cells.map(c => c[1]));
      const norm = piece.cells.map(([r, c]) => [r - minR, c - minC]);
      const pieceW = Math.max(...norm.map(c => c[1])) + 1;
      const pieceH = Math.max(...norm.map(c => c[0])) + 1;
      for (let r = 0; r <= BOARD_SIZE - pieceH; r++) {
        for (let c = 0; c <= BOARD_SIZE - pieceW; c++) {
          let fit = true;
          for (const [pr, pc] of norm) {
            if (board[r + pr][c + pc]) { fit = false; break; }
          }
          if (fit) return true;
        }
      }
    }
    return false;
  }

  // ================= COMPLETE / OVER =================
  function showLevelComplete() {
    playSound('win', 1.0);
    const lvl = LEVELS[currentLevelIndex];
    let stars = 1;
    const ratio = score / lvl.target;
    if (ratio >= 2) stars = 3;
    else if (ratio >= 1.3) stars = 2;

    const prevStars = getStars(lvl.level);
    const bestScore = Math.max(score, getBestScore(lvl.level));
    progress[lvl.level] = { stars: Math.max(stars, prevStars), best: bestScore };
    saveProgress();

    const coinReward = stars === 3 ? COIN_REWARD_3STAR : stars === 2 ? COIN_REWARD_2STAR : COIN_REWARD_1STAR;

    overlayTitle.textContent = 'LEVEL COMPLETE';
    overlayTitle.classList.remove('fail');
    overlayLabel.textContent = 'YOUR SCORE';
    overlayScore.textContent = score.toLocaleString();
    overlayStars.innerHTML = renderStars(stars);
    overlayCoins.style.display = 'flex';
    overlayCoinsAmount.textContent = '+' + coinReward;
    overlayPrimary.textContent = 'NEXT LEVEL';
    overlaySecondary.textContent = 'RESTART';

    overlayPrimary.onclick = () => {
      overlay.classList.remove('show');
      addCoins(coinReward);
      if (currentLevelIndex + 1 < LEVELS.length) {
        currentLevelIndex++;
        startLevel(currentLevelIndex);
      } else {
        goToMenu();
      }
    };
    overlaySecondary.onclick = () => {
      overlay.classList.remove('show');
      startLevel(currentLevelIndex);
    };

    overlay.classList.add('show');
  }

  function renderStars(n) {
    let s = '';
    for (let i = 0; i < 3; i++) s += i < n ? '★' : '<span class="dim">★</span>';
    return s;
  }

  function showGameOver() {
    playSound('fail', 0.9);
    overlayTitle.textContent = 'GAME OVER';
    overlayTitle.classList.add('fail');
    overlayLabel.textContent = 'YOUR SCORE';
    overlayScore.textContent = score.toLocaleString();
    overlayStars.innerHTML = '';
    overlayCoins.style.display = 'none';
    overlayPrimary.textContent = 'RESTART';
    overlaySecondary.textContent = 'MENU';

    overlayPrimary.onclick = () => { overlay.classList.remove('show'); startLevel(currentLevelIndex); };
    overlaySecondary.onclick = () => { overlay.classList.remove('show'); goToMenu(); };
    overlay.classList.add('show');
  }

  function endClassic() {
    playSound('fail', 0.9);
    if (score > classicBest) { classicBest = score; saveProgress(); }
    const earned = Math.floor(score / 1000) * COIN_CLASSIC_PER_1000;
    if (earned > 0) addCoins(earned);

    overlayTitle.textContent = 'GAME OVER';
    overlayTitle.classList.add('fail');
    overlayLabel.textContent = 'FINAL SCORE';
    overlayScore.textContent = score.toLocaleString();
    overlayStars.innerHTML = '';
    overlayCoins.style.display = earned > 0 ? 'flex' : 'none';
    overlayCoinsAmount.textContent = '+' + earned;
    overlayPrimary.textContent = 'PLAY AGAIN';
    overlaySecondary.textContent = 'MENU';

    overlayPrimary.onclick = () => { overlay.classList.remove('show'); startClassic(); };
    overlaySecondary.onclick = () => { overlay.classList.remove('show'); goToMenu(); };
    overlay.classList.add('show');
  }

  // ================= START =================
  function startLevel(index) {
    currentLevelIndex = index;
    score = 0;
    levelComplete = false;
    gameMode = 'levels';
    gameStarted = true;
    activeBooster = null;

    const lvl = LEVELS[index];
    levelBadgeEl.textContent = 'LEVEL ' + lvl.level;
    targetBadgeEl.textContent = 'TARGET ' + lvl.target.toLocaleString();
    progressWrapEl.classList.remove('hidden');
    progressFillEl.style.width = '0%';

    createBoard();
    generateTray(index + 1);
    updateScoreUI();
    updateBoosterUI();

    setTimeout(updateBoardRect, 50);
  }

  function startClassic() {
    gameMode = 'classic';
    score = 0;
    levelComplete = false;
    gameStarted = true;
    activeBooster = null;
    levelBadgeEl.textContent = 'CLASSIC';
    targetBadgeEl.textContent = 'BEST ' + classicBest.toLocaleString();
    progressWrapEl.classList.add('hidden');

    createBoard();
    generateTray(1);
    updateScoreUI();
    updateBoosterUI();

    setTimeout(updateBoardRect, 50);
  }

  // ================= MENU / NAV =================
  function goToMenu() {
    gameEl.classList.add('hidden');
    menuEl.classList.remove('hide');
    playMusic();
    levelMap.classList.add('hidden');
    gameStarted = false;
    activeBooster = null;
  }

  function openGame() {
    menuEl.classList.add('hide');
    gameEl.classList.remove('hidden');
    stopMusic();
  }

  // ================= LEVEL MAP =================
  function buildLevelMap() {
    mapScroll.innerHTML = '';
    const totalChapters = Math.ceil(TOTAL_LEVELS / CHAPTER_SIZE);
    for (let ch = 0; ch < totalChapters; ch++) {
      const heading = document.createElement('div');
      heading.className = 'chapter-heading';
      const startLvl = ch * CHAPTER_SIZE + 1;
      const endLvl = Math.min((ch + 1) * CHAPTER_SIZE, TOTAL_LEVELS);
      heading.textContent = `Chapter ${ch + 1} · Levels ${startLvl}–${endLvl}`;
      mapScroll.appendChild(heading);

      const grid = document.createElement('div');
      grid.className = 'level-grid';

      for (let i = startLvl; i <= endLvl; i++) {
        const btn = document.createElement('button');
        btn.className = 'level-btn';

        const stars = getStars(i);
        const unlocked = i === 1 || getStars(i - 1) > 0 || progress[i];
        const isCurrent = (i - 1) === currentLevelIndex;

        if (isCurrent && unlocked) btn.classList.add('current');
        else if (unlocked) btn.classList.add('unlocked');
        else btn.classList.add('locked');

        btn.innerHTML = `
          <span class="level-num">${i}</span>
          <span class="level-stars">${stars > 0 ? '★'.repeat(stars) : ''}</span>
          ${!unlocked ? '<span class="lock-icon">🔒</span>' : ''}
        `;

        btn.addEventListener('click', () => {
          if (!unlocked) return;
          levelMap.classList.add('hidden');
          openGame();
          startLevel(i - 1);
        });

        grid.appendChild(btn);
      }
      mapScroll.appendChild(grid);
    }
  }

  // ================= STORE =================
  function updateStoreOwner() {
    const parts = [];
    if (inventory.extra_piece > 0) parts.push(`Extra×${inventory.extra_piece}`);
    if (inventory.clean_row > 0) parts.push(`Row×${inventory.clean_row}`);
    if (inventory.bomb > 0) parts.push(`Bomb×${inventory.bomb}`);
    if (inventory.skip_level > 0) parts.push(`Skip×${inventory.skip_level}`);
    storeOwner.textContent = parts.length ? parts.join(' · ') : 'None';
  }

  function buildStore() {
    storeList.innerHTML = '';
    updateStoreOwner();
    for (const item of STORE_ITEMS) {
      const row = document.createElement('div');
      row.className = 'store-item';
      const canAfford = coins >= item.price;
      const owned = inventory[item.id] || 0;
      row.innerHTML = `
        <div class="store-item-icon">${getStoreIcon(item.icon)}</div>
        <div class="store-item-info">
          <div class="store-item-name">${item.name} ${owned > 0 ? `<span style="color:#ffd75e;font-size:0.75rem;">(Owned: ${owned})</span>` : ''}</div>
          <div class="store-item-desc">${item.desc}</div>
        </div>
        <div class="store-item-action">
          <div class="store-price">
            <svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" fill="#ffd75e" stroke="#a06d00" stroke-width="1.8"/><path d="M12 6v12M9 9h4.5a2.5 2.5 0 0 1 0 5H9h5.5a2.5 2.5 0 0 1 0 5H9" stroke="#a06d00" stroke-width="1.6" stroke-linecap="round"/></svg>
            ${item.price}
          </div>
          <button class="store-buy-btn ${canAfford ? '' : 'disabled'}" data-id="${item.id}">
            ${canAfford ? 'BUY' : 'LOCKED'}
          </button>
        </div>
      `;
      storeList.appendChild(row);
    }
    storeList.querySelectorAll('.store-buy-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.id;
        const item = STORE_ITEMS.find(s => s.id === id);
        if (!item) return;
        if (coins < item.price) return;
        coins -= item.price;
        inventory[id] = (inventory[id] || 0) + 1;
        updateCoinsUI();
        saveProgress();
        playSound('coin', 0.7);
        buildStore();
        updateBoosterUI();
      });
    });
  }

  function getStoreIcon(name) {
    switch (name) {
      case 'plus': return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>';
      case 'row':  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M3 12h18M3 6h18M3 18h18"/></svg>';
      case 'bomb': return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="13" r="7"/><path d="M17 7l2-2M19 5l2 2M13 3l1 1"/></svg>';
      case 'skip': return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4l10 8-10 8V4z"/><path d="M19 5v14"/></svg>';
    }
    return '';
  }

  // ================= DAILY =================
  function canClaimDaily() {
    const today = new Date().toISOString().slice(0, 10);
    return lastDailyClaimDay !== today;
  }

  function updateDailyBadge() {
    if (canClaimDaily()) dailyBadge.classList.remove('hidden');
    else dailyBadge.classList.add('hidden');
  }

  const BOOSTER_EMOJI = { extra_piece: '➕', clean_row: '▬', bomb: '💣', skip_level: '⏭️' };

  function buildDailyGrid() {
    dailyGrid.innerHTML = '';
    const todayIdx = dailyStreak % 7;
    for (let i = 0; i < 7; i++) {
      const reward = DAILY_REWARDS[i];
      const dayEl = document.createElement('div');
      dayEl.className = 'daily-day';
      if (i === 6) dayEl.classList.add('day-7');

      const claimed = i < todayIdx || (i === todayIdx && !canClaimDaily());
      if (claimed) dayEl.classList.add('claimed');
      if (i === todayIdx && canClaimDaily()) dayEl.classList.add('today');

      let itemsHtml = '';
      if (reward.items) {
        const icons = Object.keys(reward.items).map(id => BOOSTER_EMOJI[id] || '★').join(' ');
        itemsHtml = `<div class="day-7-items" title="All boosters">${icons}</div>`;
      }

      dayEl.innerHTML = `
        <div class="day-num">Day ${i + 1}</div>
        <div class="day-reward">${reward.icon === 'chest' ? '🎁' : '🪙'} ${reward.coins}</div>
        ${itemsHtml}
      `;
      dailyGrid.appendChild(dayEl);
    }
    dailyStreakNum.textContent = dailyStreak;
    if (canClaimDaily()) {
      dailyClaimBtn.disabled = false;
      dailyClaimBtn.classList.remove('claimed');
      dailyClaimBtn.textContent = 'CLAIM REWARD';
    } else {
      dailyClaimBtn.disabled = true;
      dailyClaimBtn.classList.add('claimed');
      dailyClaimBtn.textContent = 'CLAIMED TODAY';
    }
  }

  dailyClaimBtn.addEventListener('click', () => {
    if (!canClaimDaily()) return;
    const idx = dailyStreak % 7;
    const reward = DAILY_REWARDS[idx];
    addCoins(reward.coins);
    let noteText = `You claimed ${reward.coins} coins!`;
    if (reward.items) {
      for (const id in reward.items) {
        inventory[id] = (inventory[id] || 0) + reward.items[id];
      }
      updateBoosterUI();
      noteText = `You claimed ${reward.coins} coins + all boosters!`;
    }
    dailyStreak = Math.min(7, dailyStreak + 1);
    lastDailyClaim = Date.now();
    lastDailyClaimDay = new Date().toISOString().slice(0, 10);
    saveProgress();
    buildDailyGrid();
    updateDailyBadge();
    dailyNote.textContent = noteText;
  });

  // ================= EVENTS =================
  btnLevels.addEventListener('click', () => { menuEl.classList.add('hide'); levelMap.classList.remove('hidden'); buildLevelMap(); });
  btnClassic.addEventListener('click', () => { openGame(); startClassic(); });
  btnStore.addEventListener('click', () => { buildStore(); storeModal.classList.add('show'); });
  btnDaily.addEventListener('click', () => { buildDailyGrid(); dailyModal.classList.add('show'); });
  dailyClose.addEventListener('click', () => dailyModal.classList.remove('show'));
  storeClose.addEventListener('click', () => storeModal.classList.remove('show'));
  mapClose.addEventListener('click', () => { levelMap.classList.add('hidden'); menuEl.classList.remove('hide'); });
  mapBtn.addEventListener('click', () => { levelMap.classList.remove('hidden'); buildLevelMap(); });
  menuHomeBtn.addEventListener('click', () => { if (confirm('Exit to menu? Progress will be lost.')) goToMenu(); });
  function openSettings() {
    toggleSound.checked = soundEnabled;
    toggleMusic.checked = musicEnabled;
    toggleVibration.checked = vibrationEnabled;
    settingsModal.classList.add('show');
    playSound('click', 0.5);
  }
  function closeSettings() { settingsModal.classList.remove('show'); }

  settingsBtn.addEventListener('click', openSettings);
  menuSettingsBtn.addEventListener('click', openSettings);
  settingsClose.addEventListener('click', closeSettings);

  toggleSound.addEventListener('change', () => {
    soundEnabled = toggleSound.checked;
    try { localStorage.setItem('soundEnabled', soundEnabled); } catch (e) {}
    if (soundEnabled) playSound('click', 0.6);
  });
  toggleMusic.addEventListener('change', () => {
    musicEnabled = toggleMusic.checked;
    try { localStorage.setItem('musicEnabled', musicEnabled); } catch (e) {}
    if (musicEnabled) playMusic(); else stopMusic();
  });
  toggleVibration.addEventListener('change', () => {
    vibrationEnabled = toggleVibration.checked;
    try { localStorage.setItem('vibrationEnabled', vibrationEnabled); } catch (e) {}
    if (vibrationEnabled) vibrate('click');
  });

  window.addEventListener('resize', updateBoardRect);

  // ================= INIT =================
  initStorage();
  updateCoinsUI();
  updateDailyBadge();
  updateBoosterUI();

  setTimeout(() => {
    splashEl.classList.add('hide');
    menuEl.classList.remove('hide');
    setTimeout(() => { splashEl.style.display = 'none'; }, 700);
  }, 2600);

})();
