const V='wird-v10',SHELL=['./','index.html','manifest.webmanifest','icon-192.png','icon-512.png','bg.jpg'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==V).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{const r=e.request;if(r.method!=='GET')return;const u=new URL(r.url);
 if(u.origin===location.origin&&u.pathname.startsWith('/api/'))return;
 if(u.origin===location.origin||u.hostname==='fonts.googleapis.com'||u.hostname==='fonts.gstatic.com'){
  e.respondWith(caches.match(r).then(hit=>{
   const net=fetch(r).then(res=>{if(res&&(res.ok||res.type==='opaque')){const cp=res.clone();caches.open(V).then(c=>c.put(r,cp))}return res}).catch(()=>hit||caches.match('index.html'));
   return hit||net}))}});
self.addEventListener('push',e=>{let d={};try{d=e.data?e.data.json():{}}catch(_){d={body:e.data?e.data.text():''}}
 e.waitUntil(self.registration.showNotification(d.title||'وِرْدٌ',{body:d.body||'',icon:'icon-192.png',badge:'icon-192.png',tag:d.tag,lang:'ar',dir:'rtl',vibrate:[300,150,300,150,300],requireInteraction:/^p\d/.test(d.tag||''),renotify:!!d.tag,data:{url:d.url||'./'}}))});
self.addEventListener('notificationclick',e=>{e.notification.close();const url=(e.notification.data&&e.notification.data.url)||'./';
 const ad=/^p\d/.test(e.notification.tag||'');e.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(l=>{for(const c of l){if(ad)c.postMessage({adhan:1});if('focus' in c)return c.focus()}return clients.openWindow(ad?url+'?adhan=1':url)}))});
