// يجهّز مجلد www: ينسخ التطبيق ثم ينزّل المصحف والتفسير والخطوط ليعمل كل شيء بدون إنترنت
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const root = path.join(__dirname, '..'), src = path.join(root, 'public'), out = path.join(root, 'www');
const DRY = process.env.DRY === '1'; // اختبار التعديلات فقط بدون تنزيل

fs.rmSync(out, { recursive: true, force: true });
fs.cpSync(src, out, { recursive: true });
fs.rmSync(path.join(out, 'sw.js'), { force: true });

const get = async (u, o) => { const r = await fetch(u, o); if (!r.ok) throw new Error(u + ' -> ' + r.status); return r; };
const API = 'https://api.alquran.cloud/v1';

(async () => {
  const f = path.join(out, 'index.html');
  let h = fs.readFileSync(f, 'utf8');
  const rep = (a, b) => { if (!h.includes(a)) throw new Error('لم أجد: ' + a); h = h.split(a).join(b); };
  rep('"https://api.alquran.cloud/v1/quran/quran-uthmani"', '"data/quran-uthmani.json"');
  rep("'https://api.alquran.cloud/v1/quran/ar.muyassar'", "'data/ar.muyassar.json'");
  rep('"https://api.alquran.cloud/v1/surah/"+n+"/quran-uthmani"', '"data/surah/"+n+".json"');
  const link = /<link href="https:\/\/fonts\.googleapis\.com\/css2[^>]*>/;
  if (!link.test(h)) throw new Error('لم أجد رابط الخطوط');
  h = h.replace(link, '<link href="fonts/fonts.css" rel="stylesheet">');
  fs.writeFileSync(f, h);
  if (DRY) return console.log('DRY: التعديلات سليمة');

  fs.mkdirSync(path.join(out, 'data/surah'), { recursive: true });
  const q = await (await get(API + '/quran/quran-uthmani')).json();
  const sur = q.data.surahs, total = sur.reduce((n, s) => n + s.ayahs.length, 0);
  if (sur.length !== 114 || total !== 6236) throw new Error('المصحف ناقص: ' + sur.length + '/' + total);
  fs.writeFileSync(path.join(out, 'data/quran-uthmani.json'), JSON.stringify(q));
  for (const s of sur) fs.writeFileSync(path.join(out, 'data/surah', s.number + '.json'), JSON.stringify({ code: 200, status: 'OK', data: s }));

  const t = await (await get(API + '/quran/ar.muyassar')).json();
  if (t.data.surahs.length !== 114) throw new Error('التفسير ناقص');
  fs.writeFileSync(path.join(out, 'data/ar.muyassar.json'), JSON.stringify(t));

  fs.mkdirSync(path.join(out, 'fonts'), { recursive: true });
  let css = await (await get('https://fonts.googleapis.com/css2?family=Amiri+Quran&family=Cairo:wght@400;600;700&display=swap',
    { headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36' } })).text();
  for (const u of [...new Set([...css.matchAll(/url\((https:[^)]+)\)/g)].map(m => m[1]))]) {
    const name = crypto.createHash('md5').update(u).digest('hex').slice(0, 10) + '.woff2';
    fs.writeFileSync(path.join(out, 'fonts', name), Buffer.from(await (await get(u)).arrayBuffer()));
    css = css.split(u).join(name);
  }
  fs.writeFileSync(path.join(out, 'fonts/fonts.css'), css);
  console.log('تم: المصحف 114 سورة / 6236 آية + التفسير + الخطوط');
})().catch(e => { console.error('فشل:', e.message); process.exit(1); });
