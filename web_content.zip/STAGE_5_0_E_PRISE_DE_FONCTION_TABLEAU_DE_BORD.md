# CGD V117 — Socle 5.0-E
## Prise de fonction et tableau de bord

### Livrables
- Officialisation de la prise de fonction du manager après validation de la sélection 5.0-D.
- Rattachement cohérent du manager et du club ; refus d'un club déjà attribué à un autre manager.
- Enregistrement idempotent de la date de nomination dans la carrière et dans l'historique.
- Activation du bureau du club existant, sans remplacer les données financières, le staff, les installations ou le conseil.
- Tableau de bord calculé depuis les données sauvegardées : club, division, saison/jour, trésorerie, budget de transfert, effectif, staff, confiance du conseil, alertes, prochaines rencontres et derniers résultats.
- Accès rapides vers le bureau du club, les compétitions et la messagerie.
- Mode sans emploi conservé : aucun club n'est attribué par erreur ; le marché des emplois reste accessible.
- Prise de fonction également réconciliée au chargement d'une ancienne sauvegarde de carrière déjà rattachée à un club.

### Fichiers
- `src/manager-dashboard.js`
- `src/app.js`
- `index.html`
- `tests/manager-dashboard.test.js`

### Vérifications
Les tests ciblent l'activation du bureau, l'idempotence de la nomination, le mode sans emploi et l'agrégation du tableau de bord. Exécuter `npm test` depuis `v117/`.
