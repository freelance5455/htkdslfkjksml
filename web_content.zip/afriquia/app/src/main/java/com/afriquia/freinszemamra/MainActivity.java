package com.afriquia.freinszemamra;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.ContactsContract;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int PICK_CONTACT_PHONE = 7001;
    private static final int CREATE_PDF_FILE = 7002;
    private String pendingPdfHtml;
    private String pendingPdfFileName;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new PrintBridge(this), "AndroidPrint");
        webView.loadUrl("file:///android_asset/index.html");
    }

    public void pickContact() {
        try {
            Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
            startActivityForResult(intent, PICK_CONTACT_PHONE);
        } catch (Exception e) {
            Toast.makeText(this, "لا يمكن فتح جهات الاتصال", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_PDF_FILE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingPdfHtml != null) {
                saveHtmlAsPdf(data.getData(), pendingPdfHtml);
            }
            pendingPdfHtml = null;
            pendingPdfFileName = null;
            return;
        }
        if (requestCode != PICK_CONTACT_PHONE || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        Cursor cursor = null;
        try {
            String[] projection = {ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER};
            cursor = getContentResolver().query(uri, projection, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                String name = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                String phone = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER));
                String jsName = org.json.JSONObject.quote(name == null ? "" : name);
                String jsPhone = org.json.JSONObject.quote(phone == null ? "" : phone);
                webView.evaluateJavascript("window.onAndroidContactSelected && window.onAndroidContactSelected(" + jsName + "," + jsPhone + ");", null);
            }
        } catch (Exception e) {
            Toast.makeText(this, "تعذر قراءة بيانات جهة الاتصال", Toast.LENGTH_LONG).show();
        } finally { if (cursor != null) cursor.close(); }
    }

    public class PrintBridge {
        private final Context context;
        PrintBridge(Context context) { this.context = context; }

        @JavascriptInterface
        public void chooseContact() {
            runOnUiThread(() -> pickContact());
        }

        @JavascriptInterface
        public void savePdf(final String html, final String fileName) {
            runOnUiThread(() -> {
                if (html == null || html.trim().isEmpty()) {
                    Toast.makeText(context, "لا يوجد محتوى لإنشاء PDF", Toast.LENGTH_LONG).show();
                    return;
                }
                pendingPdfHtml = html;
                pendingPdfFileName = (fileName == null || fileName.trim().isEmpty()) ? "Bon_de_livraison.pdf" : fileName;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/pdf");
                intent.putExtra(Intent.EXTRA_TITLE, pendingPdfFileName);
                try {
                    startActivityForResult(intent, CREATE_PDF_FILE);
                } catch (ActivityNotFoundException e) {
                    pendingPdfHtml = null;
                    pendingPdfFileName = null;
                    Toast.makeText(context, "لا يمكن فتح نافذة حفظ PDF", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void printHtml(final String html, final String jobName) {
            runOnUiThread(() -> {
                WebView printWeb = new WebView(context);
                printWeb.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                        if (pm == null) { Toast.makeText(context, "خدمة الطباعة غير متاحة", Toast.LENGTH_LONG).show(); return; }
                        String name = (jobName == null || jobName.trim().isEmpty()) ? "Afriquia Stock - Invoice" : jobName;
                        pm.print(name, view.createPrintDocumentAdapter(name), new PrintAttributes.Builder()
                                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                .build());
                    }
                });
                WebSettings ps = printWeb.getSettings();
                ps.setJavaScriptEnabled(false);
                ps.setDomStorageEnabled(false);
                printWeb.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
            });
        }
    }

    private void saveHtmlAsPdf(Uri uri, String html) {
        WebView pdfWeb = new WebView(this);
        pdfWeb.setBackgroundColor(android.graphics.Color.WHITE);
        WebSettings ps = pdfWeb.getSettings();
        ps.setJavaScriptEnabled(false);
        ps.setDomStorageEnabled(false);
        pdfWeb.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                view.postDelayed(() -> {
                    PdfDocument document = new PdfDocument();
                    try {
                        int width = 794;
                        int contentHeight = Math.max(1123, (int) (view.getContentHeight() * view.getScale()));
                        view.measure(android.view.View.MeasureSpec.makeMeasureSpec(width, android.view.View.MeasureSpec.EXACTLY),
                                android.view.View.MeasureSpec.makeMeasureSpec(contentHeight, android.view.View.MeasureSpec.EXACTLY));
                        view.layout(0, 0, width, contentHeight);
                        int pageHeight = 1123;
                        int pages = Math.max(1, (int) Math.ceil(contentHeight / (double) pageHeight));
                        for (int i = 0; i < pages; i++) {
                            PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(width, pageHeight, i + 1).create();
                            PdfDocument.Page page = document.startPage(info);
                            android.graphics.Canvas canvas = page.getCanvas();
                            canvas.drawColor(android.graphics.Color.WHITE);
                            canvas.save();
                            canvas.translate(0, -i * pageHeight);
                            view.draw(canvas);
                            canvas.restore();
                            document.finishPage(page);
                        }
                        try (ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(uri, "w")) {
                            if (pfd == null) throw new java.io.IOException("Unable to open file");
                            try (java.io.FileOutputStream out = new java.io.FileOutputStream(pfd.getFileDescriptor())) {
                                document.writeTo(out);
                            }
                        }
                        Toast.makeText(MainActivity.this, "تم تحميل وصل التسليم بصيغة PDF", Toast.LENGTH_LONG).show();
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "تعذر إنشاء ملف PDF", Toast.LENGTH_LONG).show();
                    } finally {
                        document.close();
                        view.destroy();
                    }
                }, 400);
            }
        });
        pdfWeb.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
