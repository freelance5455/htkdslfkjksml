XOS NOVA Browser - إصدار البحث API

الحصول على API:
- استخدم Brave Search API: https://brave.com/search/api/
- لوحة المفاتيح/المفتاح: https://api-dashboard.search.brave.com/
- التوثيق: https://api-dashboard.search.brave.com/documentation/services/web-search

إضافة المفتاح:
1) افتح ملف api-config.js.
2) استبدل PASTE_YOUR_BRAVE_API_KEY_HERE بمفتاحك.
3) احفظ الملف.
4) افتح index.html في برنامج HTML to APK ثم أعد بناء APK.

الطلب يستخدم Web Search endpoint ويعرض عناوين النتائج والوصف والرابط.

تنبيه أمان مهم:
وضع المفتاح داخل APK يجعله قابلاً للاستخراج. هذا مناسب للتجربة الشخصية فقط. إذا ستنشر التطبيق للناس، أنشئ Backend بسيطاً يخزن المفتاح على الخادم ويعيد نتائج البحث للتطبيق، ولا تضع المفتاح داخل APK.

لو فشل الاتصال بسبب CORS داخل WebView، استخدم Backend proxy؛ لا تضع المفتاح في كود الواجهة المنشور.
