/*
  XOS NOVA - Search API settings
  1) Create an API key at https://brave.com/search/api/
  2) Paste the key between the quotation marks below.
  3) Save the file and rebuild the APK.

  IMPORTANT:
  This direct setup is for personal testing. An API key stored in an APK
  can be extracted. For a public app, put the key on your own backend
  and have the app call your backend instead.
*/
const BRAVE_API_KEY = "PASTE_YOUR_BRAVE_API_KEY_HERE";
const BRAVE_SEARCH_ENDPOINT = "https://api.search.brave.com/res/v1/web/search";
