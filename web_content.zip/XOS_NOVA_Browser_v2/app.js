const $=id=>document.getElementById(id);
function say(t){const el=$("toast");el.textContent=t;el.classList.add("show");clearTimeout(window.tt);window.tt=setTimeout(()=>el.classList.remove("show"),2300)}
function save(s){let a=JSON.parse(localStorage.getItem("novaRecent")||"[]");a=[s,...a.filter(x=>x!==s)].slice(0,4);localStorage.setItem("novaRecent",JSON.stringify(a));draw()}
function draw(){let a=JSON.parse(localStorage.getItem("novaRecent")||"[]");$("recent").textContent=a.length?a.join("  •  "):"ستظهر المواقع الأخيرة هنا"}
function isUrl(q){return /^https?:\/\//i.test(q)||(/^[\w.-]+\.[a-z]{2,}([/?#].*)?$/i.test(q)&&!q.includes(" "))}
function openUrl(q){let u=/^https?:\/\//i.test(q)?q:"https://"+q;save(q);location.href=u}
function showResults(title,items){
  const box=$("searchResults");box.classList.remove("hidden");
  if(!items.length){box.innerHTML='<div class="search-error">ملقيناش نتائج. جرّب كلمات بحث مختلفة.</div>';return}
  box.innerHTML='<div class="results-heading">'+title+'</div>'+items.map(item=>{
    const title=escapeHtml(item.title||"بدون عنوان");
    const desc=escapeHtml(item.description||"");
    const url=escapeHtml(item.url||"#");
    let host="";try{host=new URL(item.url).hostname}catch(e){}
    return `<a class="result-card" href="${url}" target="_blank" rel="noopener"><h3>${title}</h3><p>${desc}</p><small>${escapeHtml(host)}</small></a>`;
  }).join("");
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function searchWeb(q){
  const box=$("searchResults");box.classList.remove("hidden");box.innerHTML='<div class="search-loading">جاري البحث...</div>';
  if(typeof BRAVE_API_KEY==="undefined"||!BRAVE_API_KEY||BRAVE_API_KEY==="PASTE_YOUR_BRAVE_API_KEY_HERE"){
    box.innerHTML='<div class="search-error">حط مفتاح Brave API في ملف api-config.js الأول.</div>';return;
  }
  try{
    const url=BRAVE_SEARCH_ENDPOINT+"?q="+encodeURIComponent(q)+"&count=10&country=EG&search_lang=ar";
    const response=await fetch(url,{method:"GET",headers:{"Accept":"application/json","X-Subscription-Token":BRAVE_API_KEY}});
    if(!response.ok)throw new Error("HTTP "+response.status);
    const data=await response.json();
    const items=(data.web&&data.web.results)||[];
    showResults("نتائج البحث عن: "+escapeHtml(q),items);
    save(q);
  }catch(err){
    console.error(err);
    box.innerHTML='<div class="search-error">تعذّر الاتصال بخدمة البحث. تأكد من صحة المفتاح والإنترنت. لو ظهر خطأ CORS، ستحتاج وسيط Backend لحماية المفتاح وتمرير الطلب.</div>';
  }
}
function go(q){q=q.trim();if(!q)return;if(isUrl(q)){openUrl(q);return;}searchWeb(q)}
$("searchForm").addEventListener("submit",e=>{e.preventDefault();go($("query").value)});
$("back").onclick=()=>history.length>1?history.back():say("لا توجد صفحة سابقة");
$("signin").onclick=()=>say("تسجيل الدخول غير متاح في النسخة الحالية");
$("add").onclick=()=>{let s=prompt("اكتب عنوان الموقع");if(s){$("query").value=s;go(s)}};
$("voice").onclick=()=>{let R=window.SpeechRecognition||window.webkitSpeechRecognition;if(!R){say("البحث الصوتي غير مدعوم");return}let r=new R();r.lang="ar-EG";r.onresult=e=>{$("query").value=e.results[0][0].transcript;go($("query").value)};r.start()};
$("home").onclick=()=>{$("query").value="";$("searchResults").classList.add("hidden");window.scrollTo({top:0,behavior:"smooth"});$("menuPop").classList.add("hidden")};
$("menu").onclick=()=> $("menuPop").classList.toggle("hidden");
$("tabs").onclick=()=>say("علامة تبويب واحدة مفتوحة");
$("bookmarks").onclick=()=>say("الإشارات المرجعية غير مضافة بعد");
$("goHome").onclick=()=> $("home").click();
$("showBookmarks").onclick=()=>{say("لا توجد إشارات مرجعية");$("menuPop").classList.add("hidden")};
$("clearRecent").onclick=()=>{localStorage.removeItem("novaRecent");draw();$("menuPop").classList.add("hidden");say("تم مسح المواقع الأخيرة")};
document.querySelectorAll(".site[href]").forEach(a=>a.addEventListener("click",()=>save(a.innerText.trim())));
draw();
