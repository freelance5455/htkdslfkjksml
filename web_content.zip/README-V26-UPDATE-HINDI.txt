My Group D Study V26.1 — updated source (18 November 2026)

Based on MyGroupDStudy-V26-Navigation-WhiteScreen-Fix.zip.
Included: existing 2,097 practice questions, weekly deterministic 100-question mock, weakness analysis, study calendar/targets, saved video links, original layout, local password gate, and all six bottom navigation actions.
New in this update: home Study & Update Center with real-date display and official RRB/PIB links, backup/restore of browser localStorage, Android share-sheet export and JSON file picker restore, app version 26.1. No daily reminder or fake LIVE alert is sent.

IMPORTANT LIMITATIONS:
- NO automatic real-time LIVE notification or vacancy notification. Accurate alerts require verified YouTube channel IDs, a reliable status-check service/API and Android background execution. No unverified LIVE notices are generated.
- Current affairs are official outbound links, not an automatically fetched offline feed.
- Weekly mock changes question selection/order from existing question bank; no new questions are fetched automatically.
- Android APK has NOT been compiled or tested here. This is source, not an APK.
- Backup sharing via Android share sheet sends plain JSON; choose a private storage destination. Restoring overwrites keys included in backup.

Build: Android Studio with Android Gradle Plugin 8.7.3 and SDK 35, Gradle 8.9+, JDK 17+. Open project folder and build debug APK. Android SDK / Gradle were not available in this execution environment.
