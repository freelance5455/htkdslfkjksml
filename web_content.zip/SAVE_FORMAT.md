# Fox Meadow save format

The `.fox` file is JSON with the custom extension `.fox` (the importer also accepts `.foxt` and `.json`). Current `saveVersion` is `2`; `game` is `FoxMeadowWildheart`.

## Main fields

- `mode`: `story`, `free`, or `sandbox`
- `x`, `z`, `yaw`, `camYaw`: player and camera position/orientation
- `daySeconds`: day/night cycle progress
- `storyStep`, `found`, `pawprints`, `visited`: story and discovery progress
- `seedCount`, `discoveryCount`, `denLevel`, `decorations`: collected items and home progression
- `fur`, `belly`, `tail`, `ear`, `eye`: hex colours
- `quality`, `audio`: options
- `savedAt`: timestamp written on export/autosave

## Preservation and migration behaviour

- Autosave uses a versioned key and writes a backup of the prior local save before replacing it.
- Import rejects a future save version, checks numeric fields and lists, clamps unsafe/out-of-range values, and backs up the current local state before applying the imported file.
- Version-1 Fox Meadow saves can be mapped into version 2, including the old `skin`, `treasures`, and `discoveries` fields.
- For any future format change, a new migration step must be added before incrementing `saveVersion`. No program can guarantee compatibility with an unknown future schema without that migration code, so keep exported `.fox` backups too.
