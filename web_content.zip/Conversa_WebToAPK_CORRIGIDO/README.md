# Conversa Web → APK (corrigido)

Esta versão está preparada para conversores que aceitam um ZIP de HTML.

## Corrigido
- histórico local robusto com limite de 300 mensagens;
- PWA com service worker/offline;
- manifest com scope/orientation;
- Web Bluetooth tratado sem quebrar o app quando a API não existe;
- campo opcional para URL de backend;
- 4G/5G explicado corretamente: é Internet por dados móveis, não uma rede separada;
- mensagens continuam disponíveis localmente quando o servidor não responde.

## Importante
Este pacote não inventa uma conexão online. Para mensagens entre celulares pela Internet, informe a URL de um backend que aceite POST JSON no formato:
`{"text":"...","created":123,"mode":"internet"}`.

Bluetooth Mesh completo continua sendo responsabilidade da versão Android nativa.
