# Android dependency manifest

The existing Android project uses:

- Android Gradle Plugin: 8.7.3
- Gradle Wrapper target: 8.9
- Kotlin: 2.0.21
- compileSdk: 35
- targetSdk: 35
- minSdk: 26
- Compose BOM: 2024.12.01
- Compose UI / Material 3
- activity-compose: 1.10.0
- lifecycle-runtime-compose: 2.8.7
- datastore-preferences: 1.1.1
- kotlinx-coroutines-android: 1.9.0
- kotlinx-serialization-json: 1.7.3

AGP 8.7 requires Gradle 8.9. This matches the existing project plugin version and is not a guessed compatibility change.
