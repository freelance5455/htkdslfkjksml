package com.inkslip.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Toast;
import android.print.PrintManager;
import android.print.PrintAttributes;
import android.util.Base64;
import java.io.OutputStream;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !"file:///android_asset/index.html".equals(request.getUrl().toString());
            }
        });
        webView.addJavascriptInterface(new Bridge(), "InkSlipNative");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void callback(String message) {
        main.post(() -> {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            if (webView != null) webView.evaluateJavascript("window.nativeResult && window.nativeResult(" + org.json.JSONObject.quote(message) + ")", null);
        });
    }

    private Uri store(byte[] bytes, String filename) throws IOException {
        ContentValues v = new ContentValues();
        v.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
        v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/InkSlip");
        v.put(MediaStore.Images.Media.IS_PENDING, 1);
        Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
        if (uri == null) throw new IOException("Cannot create gallery image");
        try {
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new IOException("Cannot open image output");
                out.write(bytes);
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.Images.Media.IS_PENDING, 0);
            getContentResolver().update(uri, done, null, null);
            return uri;
        } catch (Exception e) {
            getContentResolver().delete(uri, null, null);
            throw new IOException(e);
        }
    }

    private byte[] image(String base64) throws IOException {
        if (base64.length() > 25_000_000) throw new IOException("Image too large");
        try { return Base64.decode(base64, Base64.DEFAULT); }
        catch (IllegalArgumentException e) { throw new IOException("Invalid PNG data"); }
    }

    private class Bridge {
        @JavascriptInterface public void save(String data) {
            worker.execute(() -> {
                try {
                    store(image(data), "InkSlip-" + System.currentTimeMillis() + ".png");
                    callback("Saved to Gallery: Pictures/InkSlip");
                } catch (Exception e) { callback("Save failed: " + e.getMessage()); }
            });
        }
        @JavascriptInterface public void share(String data) {
            worker.execute(() -> {
                try {
                    Uri uri = store(image(data), "InkSlip-" + System.currentTimeMillis() + ".png");
                    main.post(() -> {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType("image/png");
                        send.putExtra(Intent.EXTRA_STREAM, uri);
                        send.setClipData(ClipData.newUri(getContentResolver(), "InkSlip", uri));
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(send, "Share InkSlip image"));
                    });
                } catch (Exception e) { callback("Share failed: " + e.getMessage()); }
            });
        }
        @JavascriptInterface public void whatsapp(String data) {
            worker.execute(() -> {
                try {
                    Uri uri = store(image(data), "InkSlip-" + System.currentTimeMillis() + ".png");
                    main.post(() -> {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType("image/png");
                        send.setPackage("com.whatsapp");
                        send.putExtra(Intent.EXTRA_STREAM, uri);
                        send.setClipData(ClipData.newUri(getContentResolver(), "InkSlip", uri));
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        try { startActivity(send); }
                        catch (Exception e) {
                            send.setPackage(null);
                            try { startActivity(Intent.createChooser(send, "Share InkSlip image")); }
                            catch (Exception err) { callback("No sharing app available"); }
                        }
                    });
                } catch (Exception e) { callback("WhatsApp share failed: " + e.getMessage()); }
            });
        }
        @JavascriptInterface public void printPage() {
            main.post(() -> {
                try {
                    PrintManager manager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                    manager.print("InkSlip", webView.createPrintDocumentAdapter("InkSlip"), new PrintAttributes.Builder().build());
                } catch (Exception e) { callback("Print failed: " + e.getMessage()); }
            });
        }
        @JavascriptInterface public void copy(String data) {
            worker.execute(() -> {
                try {
                    Uri uri = store(image(data), "InkSlip-Copy-" + System.currentTimeMillis() + ".png");
                    main.post(() -> {
                        ClipboardManager clip = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                        clip.setPrimaryClip(ClipData.newUri(getContentResolver(), "InkSlip image", uri));
                        callback("Image copied for compatible apps");
                    });
                } catch (Exception e) { callback("Copy failed: " + e.getMessage()); }
            });
        }
        @JavascriptInterface public void copyText(String data) {
            main.post(() -> {
                ClipboardManager clip = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                clip.setPrimaryClip(ClipData.newPlainText("InkSlip numbers", data));
                callback("Numbers copied");
            });
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (webView != null) { webView.removeJavascriptInterface("InkSlipNative"); webView.destroy(); }
        worker.shutdown();
        super.onDestroy();
    }
}
