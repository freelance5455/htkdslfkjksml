# InkSlip 2.0 — Android APK project

This project updates the user-provided InkSlip HTML page with native Android saving and sharing.

## Features
- Five paper colours: pink, white, orange, sky blue, yellow
- Single-page and three-slip layout
- Four writing styles, adjustable natural human-handwriting variation, size and line spacing, optional dividers and totals
- Parse number/amount lines from WhatsApp exports
- Save PNG to Gallery in Pictures/InkSlip (Android 10+)
- Native Android share chooser, direct WhatsApp intent (with chooser fallback), copy image URI, copy numbers
- Clear, sample, PNG preview and Android print/PDF dialog

## Build on Android
1. Install AndroidIDE or another Android-capable IDE with Gradle and Android SDK support.
2. Extract the ZIP and open the `InkSlipAndroid_Enhanced` folder as a Gradle project.
3. Allow Gradle sync and SDK/dependency downloads. Requires Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17 and Android SDK 35.
4. Build `app` debug APK, then install it on Android 10 or newer.

Note: The Gradle wrapper JAR is not included. Configure a compatible Gradle distribution in the IDE. Native Gallery saving works in the compiled APK, not in a regular HTML preview. Sharing to WhatsApp requires WhatsApp installed. Copying image URI works only with receiving apps that accept image URI clipboard data. Android print dialog output can be saved as PDF.

The HTML file can also be opened independently, but its saving/sharing fallbacks depend on browser permissions. The APK has not been compiled or device-tested in this environment.

## Handwriting update
The PNG renderer now draws individual characters with repeatable slight differences in height, tilt, ink intensity and spacing. The Human handwriting slider controls the variation. The on-screen HTML preview is approximate; View PNG shows the exact saved result.
