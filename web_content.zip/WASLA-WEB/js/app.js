/**
 * وصلة PWA — دردشة محلية + Web Bluetooth
 *
 * قيود حقيقية:
 * - Web Bluetooth = BLE فقط، دعم Chrome/Edge أساسًا
 * - يحتاج تفاعل مستخدم + أحيانًا موقع
 * - معدل نقل منخفض؛ الفيديو الكبير غير عملي
 * - لا يوجد multi-hop mesh في المتصفح
 * - يعمل بدون إنترنت بعد التثبيت/التخزين المؤقت (Service Worker)
 */

(function () {
  "use strict";

  const SERVICE_UUID = "0000was0-0000-1000-8000-00805f9b34fb";
  const CHAR_UUID = "0000was1-0000-1000-8000-00805f9b34fb";
  // UUIDs مخصصة قد لا تعمل مع كل الأجهزة؛ نستخدم أيضًا خدمات عامة عند الفشل
  const FALLBACK_SERVICE = 0x1800; // Generic Access — للاكتشاف فقط

  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => [...document.querySelectorAll(sel)];

  // ---------- هوية محلية ----------
  function getOrCreateId() {
    let id = localStorage.getItem("wasla_id");
    if (!id) {
      const hex = Array.from(crypto.getRandomValues(new Uint8Array(3)))
        .map((b) => b.toString(16).padStart(2, "0"))
        .join("")
        .toUpperCase();
      id = "WASLA-" + hex;
      localStorage.setItem("wasla_id", id);
    }
    return id;
  }

  function getDisplayName() {
    return localStorage.getItem("wasla_name") || getOrCreateId();
  }

  function setDisplayName(n) {
    localStorage.setItem("wasla_name", (n || "").slice(0, 24));
  }

  // ---------- IndexedDB للرسائل ----------
  const DB_NAME = "wasla_db";
  const DB_VER = 1;
  let db;

  function openDb() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VER);
      req.onupgradeneeded = () => {
        const d = req.result;
        if (!d.objectStoreNames.contains("messages")) {
          const store = d.createObjectStore("messages", { keyPath: "id" });
          store.createIndex("byTime", "ts");
        }
      };
      req.onsuccess = () => {
        db = req.result;
        resolve(db);
      };
      req.onerror = () => reject(req.error);
    });
  }

  function saveMessage(msg) {
    return new Promise((resolve, reject) => {
      const tx = db.transaction("messages", "readwrite");
      tx.objectStore("messages").put(msg);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  function loadMessages() {
    return new Promise((resolve, reject) => {
      const tx = db.transaction("messages", "readonly");
      const req = tx.objectStore("messages").index("byTime").getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  function clearMessages() {
    return new Promise((resolve, reject) => {
      const tx = db.transaction("messages", "readwrite");
      tx.objectStore("messages").clear();
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  // ---------- حالة الاتصال ----------
  let device = null;
  let server = null;
  let characteristic = null;
  let connected = false;

  function setConnected(v, name) {
    connected = v;
    const badge = $("#connBadge");
    if (badge) {
      badge.textContent = v ? "متصل" + (name ? " · " + name : "") : "غير متصل";
      badge.className = "badge " + (v ? "on" : "off");
    }
  }

  function toast(text) {
    const el = $("#toast");
    el.textContent = text;
    el.hidden = false;
    clearTimeout(toast._t);
    toast._t = setTimeout(() => {
      el.hidden = true;
    }, 2800);
  }

  // ---------- Web Bluetooth ----------
  function bluetoothSupported() {
    return !!(navigator.bluetooth && navigator.bluetooth.requestDevice);
  }

  async function scanAndConnect() {
    if (!bluetoothSupported()) {
      toast("متصفحك لا يدعم Web Bluetooth. استخدم Chrome على أندرويد.");
      $("#scanStatus").textContent = "Web Bluetooth غير مدعوم على هذا المتصفح.";
      return;
    }

    $("#scanStatus").textContent = "جاري فتح نافذة الاختيار…";
    try {
      // طلب جهاز — المستخدم يختار من القائمة
      device = await navigator.bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: [
          "battery_service",
          "device_information",
          "generic_access",
          SERVICE_UUID,
        ],
      });

      $("#scanStatus").textContent = "الاتصال بـ " + (device.name || "جهاز") + "…";
      device.addEventListener("gattserverdisconnected", onDisconnect);

      server = await device.gatt.connect();
      setConnected(true, device.name || "جهاز");

      // محاولة الاشتراك في خاصية إن وُجدت خدمة مخصصة
      try {
        const svc = await server.getPrimaryService(SERVICE_UUID);
        characteristic = await svc.getCharacteristic(CHAR_UUID);
        await characteristic.startNotifications();
        characteristic.addEventListener("characteristicvaluechanged", onNotify);
      } catch (_) {
        // معظم الهواتف لن تعرض خدمة وصلة مخصصة — نستخدم إرسال عبر write إن أمكن لاحقًا
        characteristic = null;
      }

      renderDeviceList([{ name: device.name || "جهاز متصل", id: device.id, connected: true }]);
      $("#scanStatus").textContent = "متصل. يمكنك إرسال رسائل قصيرة.";
      toast("تم الاتصال");
      showScreen("chat");
    } catch (e) {
      console.warn(e);
      $("#scanStatus").textContent =
        e.name === "NotFoundError"
          ? "لم يتم اختيار جهاز."
          : "فشل الاتصال: " + (e.message || e.name);
      toast("لم يتم الاتصال");
    }
  }

  function onDisconnect() {
    setConnected(false);
    characteristic = null;
    server = null;
    toast("انقطع الاتصال");
    $("#scanStatus").textContent = "انقطع الاتصال بالبلوتوث.";
  }

  function onNotify(event) {
    try {
      const value = event.target.value;
      const text = new TextDecoder().decode(value.buffer);
      const packet = JSON.parse(text);
      handleIncoming(packet);
    } catch (e) {
      console.warn("notify parse", e);
    }
  }

  /**
   * إرسال حزمة صغيرة عبر BLE (حد عملي ~20–512 بايت حسب الجهاز).
   * للملفات الأكبر: نقسم لشظايا base64 (بطيء).
   */
  async function sendPacket(packet) {
    const json = JSON.stringify(packet);
    const data = new TextEncoder().encode(json);

    if (!connected || !device || !device.gatt.connected) {
      // حفظ محلي حتى مع عدم وجود رابط
      await persistOutgoing(packet);
      toast("لا يوجد اتصال — حُفظت محليًا فقط");
      return false;
    }

    if (!characteristic) {
      await persistOutgoing(packet);
      toast("الجهاز متصل لكن لا يدعم قناة بيانات وصلة. حُفظت محليًا.");
      // عرض الرسالة عندي كمرسلة محليًا
      return false;
    }

    try {
      // تقسيم إن لزم
      const MTU = 180;
      if (data.length <= MTU) {
        await characteristic.writeValueWithoutResponse(data);
      } else {
        // شظايا
        const id = packet.id || crypto.randomUUID();
        const total = Math.ceil(data.length / MTU);
        for (let i = 0; i < total; i++) {
          const slice = data.slice(i * MTU, (i + 1) * MTU);
          const chunk = {
            t: "chunk",
            id,
            i,
            n: total,
            d: btoa(String.fromCharCode(...slice)),
          };
          const enc = new TextEncoder().encode(JSON.stringify(chunk));
          await characteristic.writeValueWithoutResponse(enc);
          await sleep(30);
        }
      }
      await persistOutgoing(packet);
      return true;
    } catch (e) {
      console.warn(e);
      await persistOutgoing(packet);
      toast("تعذر الإرسال عبر البلوتوث — حُفظت محليًا");
      return false;
    }
  }

  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  async function persistOutgoing(packet) {
    const msg = {
      id: packet.id || crypto.randomUUID(),
      from: getOrCreateId(),
      name: getDisplayName(),
      type: packet.type || "text",
      body: packet.body || "",
      mime: packet.mime || "",
      dataUrl: packet.dataUrl || "",
      me: true,
      ts: Date.now(),
    };
    await saveMessage(msg);
    appendBubble(msg);
  }

  async function handleIncoming(packet) {
    if (packet.t === "chunk") return; // تجميع بسيط يمكن توسيعه لاحقًا
    const msg = {
      id: packet.id || crypto.randomUUID(),
      from: packet.from || "remote",
      name: packet.name || "جهاز",
      type: packet.type || "text",
      body: packet.body || "",
      mime: packet.mime || "",
      dataUrl: packet.dataUrl || "",
      me: false,
      ts: Date.now(),
    };
    await saveMessage(msg);
    appendBubble(msg);
  }

  // ---------- واجهة ----------
  function showScreen(name) {
    $$(".screen").forEach((s) => s.classList.remove("active"));
    const el = $("#screen-" + name);
    if (el) el.classList.add("active");
  }

  function appendBubble(msg) {
    const box = $("#messages");
    if (!box) return;
    const div = document.createElement("div");
    div.className = "bubble " + (msg.me ? "me" : "them");

    if (msg.type === "text") {
      div.innerHTML =
        escapeHtml(msg.body) +
        '<div class="meta">' +
        escapeHtml(msg.name || "") +
        " · " +
        new Date(msg.ts).toLocaleTimeString("ar") +
        "</div>";
    } else if (msg.type === "image" && msg.dataUrl) {
      div.innerHTML =
        '<img src="' +
        msg.dataUrl +
        '" alt="" />' +
        '<div class="meta">صورة · ' +
        new Date(msg.ts).toLocaleTimeString("ar") +
        "</div>";
    } else if (msg.type === "video" && msg.dataUrl) {
      div.innerHTML =
        '<video controls src="' +
        msg.dataUrl +
        '"></video>' +
        '<div class="meta">فيديو · ' +
        new Date(msg.ts).toLocaleTimeString("ar") +
        "</div>";
    } else if (msg.type === "audio" && msg.dataUrl) {
      div.innerHTML =
        '<audio controls src="' +
        msg.dataUrl +
        '"></audio>' +
        '<div class="meta">صوت · ' +
        new Date(msg.ts).toLocaleTimeString("ar") +
        "</div>";
    } else {
      div.innerHTML =
        "📎 " +
        escapeHtml(msg.body || "ملف") +
        '<div class="meta">' +
        new Date(msg.ts).toLocaleTimeString("ar") +
        "</div>";
    }

    box.appendChild(div);
    box.scrollTop = box.scrollHeight;
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function renderDeviceList(items) {
    const ul = $("#deviceList");
    ul.innerHTML = "";
    items.forEach((d) => {
      const li = document.createElement("li");
      li.innerHTML =
        "<span>" +
        escapeHtml(d.name) +
        (d.connected ? " 🟢" : "") +
        '</span><button type="button">فتح الدردشة</button>';
      li.querySelector("button").onclick = () => showScreen("chat");
      ul.appendChild(li);
    });
  }

  // ---------- إرسال نص ----------
  async function sendText() {
    const input = $("#msgInput");
    const text = (input.value || "").trim();
    if (!text) return;
    input.value = "";
    await sendPacket({
      id: crypto.randomUUID(),
      type: "text",
      body: text,
      from: getOrCreateId(),
      name: getDisplayName(),
    });
  }

  // ---------- ملفات ----------
  function fileToDataUrl(file) {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(r.result);
      r.onerror = reject;
      r.readAsDataURL(file);
    });
  }

  async function sendFile(file) {
    if (!file) return;
    // حد عملي للـ data URL عبر BLE
    const MAX = 120 * 1024; // 120KB — فوقها نحفظ محليًا فقط مع تنبيه
    const type = file.type.startsWith("image/")
      ? "image"
      : file.type.startsWith("video/")
        ? "video"
        : file.type.startsWith("audio/")
          ? "audio"
          : "file";

    if (file.size > MAX) {
      toast("الملف كبير لـ BLE. سيُحفظ عندك محليًا فقط.");
      const dataUrl = type === "image" || type === "audio" ? await fileToDataUrl(file) : "";
      const msg = {
        id: crypto.randomUUID(),
        from: getOrCreateId(),
        name: getDisplayName(),
        type,
        body: file.name + " (" + Math.round(file.size / 1024) + " KB)",
        mime: file.type,
        dataUrl,
        me: true,
        ts: Date.now(),
      };
      await saveMessage(msg);
      appendBubble(msg);
      return;
    }

    const dataUrl = await fileToDataUrl(file);
    await sendPacket({
      id: crypto.randomUUID(),
      type,
      body: file.name,
      mime: file.type,
      dataUrl,
      from: getOrCreateId(),
      name: getDisplayName(),
    });
    toast("تم تجهيز الإرسال");
  }

  // ---------- تسجيل صوت ----------
  let mediaRecorder = null;
  let chunks = [];
  let recordedBlob = null;

  async function toggleRecord() {
    if (mediaRecorder && mediaRecorder.state === "recording") {
      mediaRecorder.stop();
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      chunks = [];
      mediaRecorder = new MediaRecorder(stream);
      mediaRecorder.ondataavailable = (e) => chunks.push(e.data);
      mediaRecorder.onstop = () => {
        recordedBlob = new Blob(chunks, { type: "audio/webm" });
        const url = URL.createObjectURL(recordedBlob);
        const audio = $("#recPlayback");
        audio.src = url;
        audio.hidden = false;
        $("#btnSendVoice").disabled = false;
        $("#recStatus").textContent = "جاهز للإرسال";
        $("#btnRecord").classList.remove("recording");
        $("#btnRecord").textContent = "● تسجيل";
        stream.getTracks().forEach((t) => t.stop());
      };
      mediaRecorder.start();
      $("#btnRecord").classList.add("recording");
      $("#btnRecord").textContent = "■ إيقاف";
      $("#recStatus").textContent = "جارٍ التسجيل…";
    } catch (e) {
      toast("لا يمكن الوصول للميكروفون");
    }
  }

  async function sendVoice() {
    if (!recordedBlob) return;
    const file = new File([recordedBlob], "voice.webm", { type: "audio/webm" });
    await sendFile(file);
  }

  // ---------- تنقل ----------
  function bindNav() {
    $$("[data-go]").forEach((btn) => {
      btn.addEventListener("click", () => showScreen(btn.getAttribute("data-go")));
    });
  }

  // ---------- تثبيت PWA ----------
  let deferredPrompt = null;
  window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    deferredPrompt = e;
    const b = $("#btnInstall");
    if (b) b.hidden = false;
  });

  // ---------- init ----------
  async function init() {
    await openDb();
    const id = getOrCreateId();
    $("#myIdLabel").textContent = "هويتي: " + id;
    $("#settingsId").textContent = "المعرف: " + id;
    $("#displayName").value = getDisplayName();

    bindNav();

    $("#btnScan").onclick = scanAndConnect;
    $("#btnSend").onclick = sendText;
    $("#msgInput").addEventListener("keydown", (e) => {
      if (e.key === "Enter") sendText();
    });

    $("#btnAttach").onclick = () => $("#fileInput").click();
    $("#fileInput").onchange = () => {
      const f = $("#fileInput").files[0];
      if (f) sendFile(f);
      $("#fileInput").value = "";
    };

    $("#mediaPicker").onchange = async () => {
      const f = $("#mediaPicker").files[0];
      const prev = $("#mediaPreview");
      prev.innerHTML = "";
      $("#btnSendMedia").disabled = !f;
      if (!f) return;
      if (f.type.startsWith("image/")) {
        const img = document.createElement("img");
        img.src = URL.createObjectURL(f);
        prev.appendChild(img);
      } else {
        prev.textContent = f.name + " · " + Math.round(f.size / 1024) + " KB";
      }
    };
    $("#btnSendMedia").onclick = () => {
      const f = $("#mediaPicker").files[0];
      if (f) sendFile(f);
    };

    $("#btnRecord").onclick = toggleRecord;
    $("#btnSendVoice").onclick = sendVoice;

    $("#displayName").onchange = () => setDisplayName($("#displayName").value);
    $("#btnClear").onclick = async () => {
      if (confirm("مسح كل الرسائل المحلية؟")) {
        await clearMessages();
        $("#messages").innerHTML = "";
        toast("تم المسح");
      }
    };

    $("#btnInstall").onclick = async () => {
      if (!deferredPrompt) return;
      deferredPrompt.prompt();
      deferredPrompt = null;
      $("#btnInstall").hidden = true;
    };

    const msgs = await loadMessages();
    msgs.forEach(appendBubble);

    if (!bluetoothSupported()) {
      $("#scanStatus").textContent =
        "هذا المتصفح لا يدعم Web Bluetooth. جرّب Chrome على أندرويد.";
    }

    // Service Worker
    if ("serviceWorker" in navigator) {
      try {
        await navigator.serviceWorker.register("sw.js");
      } catch (_) {}
    }
  }

  init();
})();
