# DNMs Shirts Stock Manager — Android APK

This project is configured for Capacitor Android.

## Build APK on a computer
1. Install Node.js 20+ and Android Studio with Android SDK + build tools.
2. In this folder run:
   npm install
3. Add Android once:
   npm run android:add
4. Build/sync:
   npm run android:sync
5. Open Android Studio:
   npm run android:open
6. In Android Studio choose **Build > Build APK(s)**.

Debug APK will normally be under:
`android/app/build/outputs/apk/debug/app-debug.apk`

## App details
- App ID: `com.dnmsshirts.stockmanager`
- App name: `DNMs Shirts Stock Manager`
- Default PIN: `1234`
- Bag A: 20×2, 22×2, 24×2
- Bag B: 26×2, 28×2, 30×2
- Bag C: 32×2, 34×2, 36×2
- Bag D: 38×6
- Stock is tracked at bag level.
