window.RZX_SUPABASE = {
  enabled: false,
  url: "",
  anonKey: ""
};
