// ============================================================
// RZX.STUDY — TEMPORIZADOR + HISTÓRICO + SEQUÊNCIA
// ============================================================

const STORAGE_KEY = "rzxStudyData";

// ---------- Elementos ----------
const timeDisplay = document.getElementById("time");
const startBtn = document.getElementById("start-btn");
const pauseBtn = document.getElementById("pause-btn");
const resetBtn = document.getElementById("reset-btn");
const registerBtn = document.getElementById("register-btn");
const ringProgress = document.getElementById("ring-progress");
const subjectInput = document.getElementById("subject");

const restTimeDisplay = document.getElementById("rest-time");
const restStartBtn = document.getElementById("rest-start-btn");
const restPauseBtn = document.getElementById("rest-pause-btn");
const restResetBtn = document.getElementById("rest-reset-btn");

const todayTimeEl = document.getElementById("today-time");
const streakEl = document.getElementById("streak");
const totalSessionsEl = document.getElementById("total-sessions");

const statsPanel = document.getElementById("stats-panel");
const statsBtn = document.getElementById("stats-btn");
const closeStats = document.getElementById("close-stats");
const overlay = document.getElementById("overlay");
const historyEl = document.getElementById("history");
const totalTimeEl = document.getElementById("total-time");
const panelStreakEl = document.getElementById("panel-streak");
const panelAvatar = document.getElementById("panel-avatar");
const panelAvatarMini = document.getElementById("panel-avatar-mini");
const profileDisplayName = document.getElementById("profile-display-name");
const profileStatus = document.getElementById("profile-status");
const profilePhotoInput = document.getElementById("profile-photo-input");
const removeProfilePhoto = document.getElementById("remove-profile-photo");
const rankNameEl = document.getElementById("rank-name");
const rankProgressEl = document.getElementById("rank-progress");
const rankBadgeEl = document.getElementById("rank-badge");
const panelRestTotalEl = document.getElementById("panel-rest-total");
const panelMoveTotalEl = document.getElementById("panel-move-total");
const competitionCodeEl = document.getElementById("competition-code");
const createChallengeBtn = document.getElementById("create-challenge");
const joinChallengeBtn = document.getElementById("join-challenge");
const challengeShare = document.getElementById("challenge-share");
const challengeLink = document.getElementById("challenge-link");
const copyChallengeBtn = document.getElementById("copy-challenge");
const leaderboardEl = document.getElementById("leaderboard");
const clearHistoryBtn = document.getElementById("clear-history");
const moveCategories = document.getElementById("move-categories");
const moveCategoryLabel = document.getElementById("move-category-label");
const moveStatus = document.getElementById("move-status");
const moveTimeDisplay = document.getElementById("move-time");
const moveStartBtn = document.getElementById("move-start");
const movePauseBtn = document.getElementById("move-pause");
const moveResetBtn = document.getElementById("move-reset");
const moveSaveBtn = document.getElementById("move-save");
const moveNameInput = document.getElementById("move-name");
const moveDistanceInput = document.getElementById("move-distance");
const moveMessage = document.getElementById("move-message");
const moveTotalTimeEl = document.getElementById("move-total-time");
const moveTotalDistanceEl = document.getElementById("move-total-distance");
const moveTotalWorkoutsEl = document.getElementById("move-total-workouts");
const moveHistoryEl = document.getElementById("move-history");
let selectedMoveCategory = "Corrida";
let moveSeconds = 0;
let moveTimer = null;
let moveRunning = false;

// ---------- Contas / perfil ----------
const ACCOUNTS_KEY = "rzxAccountsV2";
const CURRENT_USER_KEY = "rzxCurrentUserV2";
const CLOUD_SESSION_KEY = "rzxCloudSessionV1";
const CLOUD_ENABLED = Boolean(window.RZX_SUPABASE?.enabled && window.RZX_SUPABASE.url && window.RZX_SUPABASE.anonKey && window.supabase);
const supabaseClient = CLOUD_ENABLED ? window.supabase.createClient(window.RZX_SUPABASE.url, window.RZX_SUPABASE.anonKey) : null;
let currentUser = null;
let data = { sessions: [], goals: [], fitness: [], restLogs: [], profile: {}, challenge: null };
let authMode = "login";

const authScreen = document.getElementById("auth-screen");
const appShell = document.getElementById("app-shell");
const authForm = document.getElementById("auth-form");
const authName = document.getElementById("auth-name");
const authPassword = document.getElementById("auth-password");
const authMessage = document.getElementById("auth-message");
const authSubmitText = document.getElementById("auth-submit-text");
const authTitle = document.getElementById("auth-title");
const authSubtitle = document.getElementById("auth-subtitle");
const loginTab = document.getElementById("login-tab");
const registerTab = document.getElementById("register-tab");
const rememberMe = document.getElementById("remember-me");
const rememberRow = document.getElementById("remember-row");
const togglePassword = document.getElementById("toggle-password");

function getAccounts() {
    try { return JSON.parse(localStorage.getItem(ACCOUNTS_KEY) || "{}"); }
    catch { return {}; }
}
function saveAccounts(accounts) { localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts)); }
function normalizeUsername(value) { return value.trim().toLowerCase().replace(/\s+/g, " "); }
function validUsername(value) { return /^[\p{L}0-9 _.-]{2,24}$/u.test(value.trim()); }

function bytesToHex(bytes) { return [...new Uint8Array(bytes)].map(b => b.toString(16).padStart(2,"0")).join(""); }
function hexToBytes(hex) { const out = new Uint8Array(hex.length/2); for(let i=0;i<out.length;i++) out[i]=parseInt(hex.slice(i*2,i*2+2),16); return out; }

async function hashPassword(password, saltHex) {
    if (!window.crypto?.subtle) throw new Error("Seu navegador não oferece criptografia segura neste contexto.");
    const salt = saltHex ? hexToBytes(saltHex) : crypto.getRandomValues(new Uint8Array(16));
    const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
    const bits = await crypto.subtle.deriveBits({name:"PBKDF2", salt, iterations:120000, hash:"SHA-256"}, key, 256);
    return { hash: bytesToHex(bits), salt: bytesToHex(salt) };
}

function getCurrentUserKey() {
    return sessionStorage.getItem(CURRENT_USER_KEY) || localStorage.getItem(CURRENT_USER_KEY);
}
function setCurrentUserKey(username, remember) {
    localStorage.removeItem(CURRENT_USER_KEY); sessionStorage.removeItem(CURRENT_USER_KEY);
    (remember ? localStorage : sessionStorage).setItem(CURRENT_USER_KEY, username);
}
function clearCurrentUserKey() { localStorage.removeItem(CURRENT_USER_KEY); sessionStorage.removeItem(CURRENT_USER_KEY); }

async function registerAccount(username, password) {
    if (CLOUD_ENABLED) {
        const { data: result, error } = await supabaseClient.rpc("rzx_register", { p_username: username.trim(), p_password: password });
        if (error) throw new Error(error.message || "Não foi possível criar a conta.");
        return result;
    }
    const key = normalizeUsername(username);
    const accounts = getAccounts();
    if (accounts[key]) throw new Error("Esse nome já está cadastrado.");
    const hashed = await hashPassword(password);
    accounts[key] = { username: username.trim(), passwordHash: hashed.hash, salt: hashed.salt, createdAt: new Date().toISOString(), data: { sessions: [], goals: [], fitness: [], restLogs: [], profile: {}, challenge: null, preferences: {} } };
    saveAccounts(accounts);
    return accounts[key];
}

async function loginAccount(username, password) {
    if (CLOUD_ENABLED) {
        const { data: result, error } = await supabaseClient.rpc("rzx_login", { p_username: username.trim(), p_password: password });
        if (error) throw new Error(error.message || "Nome ou senha incorretos.");
        if (!result?.token) throw new Error("Nome ou senha incorretos.");
        localStorage.setItem(CLOUD_SESSION_KEY, JSON.stringify({ username: result.username, id: result.id, token: result.token }));
        return result;
    }
    const key = normalizeUsername(username);
    const accounts = getAccounts();
    const account = accounts[key];
    if (!account) throw new Error("Nome ou senha incorretos.");
    const hashed = await hashPassword(password, account.salt);
    if (hashed.hash !== account.passwordHash) throw new Error("Nome ou senha incorretos.");
    return account;
}

function loadData() {
    if (!currentUser) return { sessions: [], goals: [], fitness: [], restLogs: [], profile: {}, challenge: null };
    if (CLOUD_ENABLED) {
        const saved = currentUser.data;
        return { sessions: Array.isArray(saved?.sessions) ? saved.sessions : [], goals: Array.isArray(saved?.goals) ? saved.goals : [], fitness: Array.isArray(saved?.fitness) ? saved.fitness : [], restLogs: Array.isArray(saved?.restLogs) ? saved.restLogs : [], profile: saved?.profile || {}, challenge: saved?.challenge || null };
    }
    const accounts = getAccounts();
    const account = accounts[normalizeUsername(currentUser.username)];
    const saved = account?.data;
    if (!saved) return { sessions: [], goals: [] };
    return { sessions: Array.isArray(saved.sessions) ? saved.sessions : [], goals: Array.isArray(saved.goals) ? saved.goals : [], fitness: Array.isArray(saved.fitness) ? saved.fitness : [], restLogs: Array.isArray(saved.restLogs) ? saved.restLogs : [], profile: saved.profile || {}, challenge: saved.challenge || null };
}

async function saveData() {
    if (!currentUser) return;
    if (CLOUD_ENABLED) {
        const { error } = await supabaseClient.rpc("rzx_save", { p_username: currentUser.username, p_token: currentUser.token, p_data: { sessions: data.sessions, goals: data.goals, fitness: data.fitness, restLogs: data.restLogs, profile: data.profile, challenge: data.challenge, preferences: {} } });
        if (error) console.warn("RZX cloud save:", error.message);
        else currentUser.data = { sessions: data.sessions, goals: data.goals, fitness: data.fitness, restLogs: data.restLogs, profile: data.profile, challenge: data.challenge };
        return;
    }
    const accounts = getAccounts(); const key = normalizeUsername(currentUser.username);
    if (!accounts[key]) return;
    accounts[key].data = { ...(accounts[key].data || {}), sessions: data.sessions, goals: data.goals, fitness: data.fitness, restLogs: data.restLogs, profile: data.profile, challenge: data.challenge }; saveAccounts(accounts);
}

function showAuthMessage(message, type="") {
    authMessage.textContent = message;
    authMessage.className = `auth-message ${type}`;
}
function setAuthMode(mode) {
    authMode = mode;
    const registering = mode === "register";
    loginTab.classList.toggle("active", !registering); registerTab.classList.toggle("active", registering);
    authTitle.textContent = registering ? "Crie seu espaço." : "Entrar no seu espaço.";
    authSubtitle.textContent = registering ? "Uma conta. Suas metas. Seu histórico." : "Seu histórico e suas metas ficam ligados à sua conta.";
    authSubmitText.textContent = registering ? "Criar minha conta" : "Entrar";
    rememberRow.style.display = registering ? "none" : "flex";
    authPassword.setAttribute("autocomplete", registering ? "new-password" : "current-password");
    showAuthMessage("");
}

function showApp() {
    data = loadData();
    authScreen.classList.add("exit");
    setTimeout(() => { authScreen.classList.add("is-hidden"); appShell.classList.remove("is-hidden"); }, 520);
    updateUserUI(); updateStats(); renderHistory(); renderGoals(); renderMoveStats(); renderMoveHistory();
    autoJoinFromURL();
}
function showLogin() {
    appShell.classList.add("is-hidden"); authScreen.classList.remove("is-hidden","exit");
    authName.value = ""; authPassword.value = ""; setAuthMode("login");
}
function updateUserUI() {
    if (!currentUser) return;
    const name = currentUser.username;
    const initial = name.trim().charAt(0).toUpperCase() || "R";
    const ids = ["user-name-display","panel-user-name","profile-display-name"];
    ids.forEach(id => { const el=document.getElementById(id); if(el) el.textContent=name; });
    const photos = [panelAvatar, panelAvatarMini, document.getElementById("profile-avatar")];
    photos.forEach(el => {
        if (!el) return;
        el.innerHTML = "";
        if (data.profile?.photo) {
            const img = document.createElement("img"); img.src = data.profile.photo; img.alt = `Foto de perfil de ${name}`; el.appendChild(img);
        } else { el.textContent = initial; }
    });
    renderRank();
    renderProfileStatus();
    renderChallenge();
}

function getFocusDays() { return new Set(data.sessions.map(s => s.date)).size; }
function getTodayRestMinutes() {
    const today = localDateKey(new Date());
    return Math.floor(data.restLogs.filter(x => x.date === today).reduce((sum,x)=>sum + (Number(x.seconds)||0),0) / 60);
}
function getTotalRestMinutes() { return Math.floor(data.restLogs.reduce((sum,x)=>sum + (Number(x.seconds)||0),0) / 60); }
function getTodayMoveMinutes() {
    const today = localDateKey(new Date());
    return Math.floor(data.fitness.filter(x=>x.date===today).reduce((sum,x)=>sum+(Number(x.seconds)||0),0)/60);
}
function getTotalMoveMinutes() { return Math.floor(data.fitness.reduce((sum,x)=>sum+(Number(x.seconds)||0),0)/60); }
function getTodayStatus() {
    const score = todayMinutes() + getTodayMoveMinutes();
    if (score >= 90) return "Hoje: Ótimo";
    if (score >= 30) return "Hoje: De boa";
    return "Hoje: Arrastado";
}
function rankForDays(days) {
    const ranks = [
        {name:"BRONZE", min:0, next:7, badge:"B"},
        {name:"PRATA", min:7, next:30, badge:"P"},
        {name:"OURO", min:30, next:90, badge:"O"},
        {name:"PLATINA", min:90, next:180, badge:"P"},
        {name:"DIMA", min:180, next:365, badge:"D"},
        {name:"MESTRE", min:365, next:null, badge:"M"}
    ];
    return ranks.reduce((best,r)=>days>=r.min?r:best,ranks[0]);
}
function renderRank() {
    const days = getFocusDays(), rank = rankForDays(days);
    if(rankNameEl) rankNameEl.textContent = rank.name;
    if(rankBadgeEl) rankBadgeEl.textContent = rank.badge;
    if(rankProgressEl) rankProgressEl.textContent = rank.next ? `${days} / ${rank.next} dias de foco` : `${days} dias de foco · MESTRE`;
}
function renderProfileStatus() { if(profileStatus) profileStatus.textContent = getTodayStatus(); }

async function resizeProfileImage(file) {
    if (!file || !file.type.startsWith("image/")) throw new Error("Escolha uma imagem válida.");
    if (file.size > 5 * 1024 * 1024) throw new Error("A foto precisa ter no máximo 5 MB.");
    const url = URL.createObjectURL(file);
    try {
        const img = await new Promise((resolve,reject)=>{ const i=new Image(); i.onload=()=>resolve(i); i.onerror=reject; i.src=url; });
        const max=640, scale=Math.min(1,max/Math.max(img.width,img.height));
        const canvas=document.createElement("canvas"); canvas.width=Math.max(1,Math.round(img.width*scale)); canvas.height=Math.max(1,Math.round(img.height*scale));
        const ctx=canvas.getContext("2d"); ctx.drawImage(img,0,0,canvas.width,canvas.height);
        return canvas.toDataURL("image/webp",0.82);
    } finally { URL.revokeObjectURL(url); }
}
profilePhotoInput?.addEventListener("change", async()=>{
    const file=profilePhotoInput.files?.[0]; if(!file) return;
    try { data.profile={...(data.profile||{}),photo:await resizeProfileImage(file)}; await saveData(); updateUserUI(); }
    catch(e){ alert(e.message||"Não foi possível salvar a foto."); }
    profilePhotoInput.value="";
});
removeProfilePhoto?.addEventListener("click", async()=>{ data.profile={...(data.profile||{}),photo:""}; await saveData(); updateUserUI(); });

loginTab?.addEventListener("click", () => setAuthMode("login"));
registerTab?.addEventListener("click", () => setAuthMode("register"));
togglePassword?.addEventListener("click", () => {
    const showing = authPassword.type === "text"; authPassword.type = showing ? "password" : "text"; togglePassword.textContent = showing ? "◌" : "◉";
});
authForm?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const username = authName.value.trim(), password = authPassword.value;
    if (!validUsername(username)) return showAuthMessage("Use um nome de 2 a 24 caracteres.", "error");
    if (password.length < 6) return showAuthMessage("A senha precisa ter pelo menos 6 caracteres.", "error");
    const submit = document.getElementById("auth-submit"); submit.disabled = true;
    showAuthMessage(authMode === "register" ? "Criando seu espaço…" : "Entrando…");
    try {
        if (authMode === "register") {
            let account = await registerAccount(username, password);
            if (CLOUD_ENABLED) account = await loginAccount(username, password);
            currentUser = account; setCurrentUserKey(account.username, true);
            showAuthMessage("Conta criada. Abrindo seu espaço…", "success");
        } else {
            const account = await loginAccount(username, password); currentUser = account; setCurrentUserKey(account.username, !!rememberMe.checked);
            showAuthMessage("Login confirmado.", "success");
        }
        setTimeout(showApp, 220);
    } catch (error) { showAuthMessage(error.message || "Não foi possível concluir.", "error"); }
    finally { submit.disabled = false; }
});

async function restoreSession() {
    if (CLOUD_ENABLED) {
        try {
            const saved = JSON.parse(localStorage.getItem(CLOUD_SESSION_KEY) || "null");
            if (saved?.username && saved?.token) { currentUser = saved; data = {sessions:[],goals:[],fitness:[],restLogs:[],profile:{},challenge:null}; showApp(); }
        } catch {}
        return;
    }
    const savedKey = getCurrentUserKey();
    if (!savedKey) return;
    const accounts = getAccounts(); const account = accounts[normalizeUsername(savedKey)];
    if (account) { currentUser = account; showApp(); }
}

// ---------- Foco ----------

const workTime = 60 * 60;
let currentTime = workTime;
let timer = null;
let isRunning = false;

const circumference = 2 * Math.PI * 145;
if (ringProgress) {
    ringProgress.style.strokeDasharray = circumference;
}

function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
}

function updateDisplay() {
    if (timeDisplay) timeDisplay.textContent = formatTime(currentTime);

    if (ringProgress) {
        const progress = currentTime / workTime;
        const offset = circumference - progress * circumference;
        ringProgress.style.strokeDashoffset = offset;
    }
}

function startTimer() {
    if (isRunning || currentTime <= 0) return;

    isRunning = true;
    startBtn.textContent = "Rodando...";

    timer = setInterval(() => {
        currentTime--;
        updateDisplay();

        if (currentTime <= 0) {
            clearInterval(timer);
            timer = null;
            isRunning = false;
            startBtn.textContent = "Começar";

            registerSession(60, true);
            notify("Sessão finalizada!", "Hora do descanso.");
        }
    }, 1000);
}

function pauseTimer() {
    isRunning = false;
    startBtn.textContent = "Continuar";
    clearInterval(timer);
    timer = null;
}

function resetTimer() {
    pauseTimer();
    currentTime = workTime;
    startBtn.textContent = "Começar";
    updateDisplay();
}

function registerCurrentSession() {
    const elapsed = workTime - currentTime;
    const minutes = Math.floor(elapsed / 60);

    if (minutes < 1) {
        notify("Sessão muito curta", "Estude pelo menos 1 minuto para registrar.");
        return;
    }

    registerSession(minutes, false);
    resetTimer();
}

function registerSession(minutes, completed) {
    const subject = subjectInput ? (subjectInput.value.trim() || "Estudo geral") : "Estudo geral";

    data.sessions.push({
        id: Date.now(),
        subject,
        minutes,
        completed,
        date: localDateKey(new Date()),
        createdAt: new Date().toISOString()
    });

    saveData();
    updateStats();
    renderHistory();

    notify(
        completed ? "Sessão concluída!" : "Sessão registrada!",
        `${minutes} min • ${subject}`
    );
}

// ---------- RZX MOVE / Atividade física ----------
function formatMoveTime(totalSeconds) {
    const safe = Math.max(0, Math.floor(Number(totalSeconds) || 0));
    const h = Math.floor(safe / 3600);
    const m = Math.floor((safe % 3600) / 60);
    const sec = safe % 60;
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}

function updateMoveDisplay() {
    if (moveTimeDisplay) moveTimeDisplay.textContent = formatMoveTime(moveSeconds);
}

function setMoveMessage(message, type = "") {
    if (!moveMessage) return;
    moveMessage.textContent = message;
    moveMessage.className = `move-message ${type}`;
}

function startMoveTimer() {
    if (moveRunning) return;
    moveRunning = true;
    if (moveStatus) moveStatus.textContent = "TREINANDO";
    if (moveStartBtn) moveStartBtn.textContent = "Rodando...";
    moveTimer = setInterval(() => {
        moveSeconds += 1;
        updateMoveDisplay();
    }, 1000);
}

function pauseMoveTimer() {
    moveRunning = false;
    clearInterval(moveTimer);
    moveTimer = null;
    if (moveStatus) moveStatus.textContent = moveSeconds > 0 ? "PAUSADO" : "PRONTO";
    if (moveStartBtn) moveStartBtn.textContent = "Continuar";
}

function resetMoveTimer() {
    pauseMoveTimer();
    moveSeconds = 0;
    updateMoveDisplay();
    if (moveStatus) moveStatus.textContent = "PRONTO";
    if (moveStartBtn) moveStartBtn.textContent = "Começar";
    setMoveMessage("");
}

function renderMoveStats() {
    const totalSeconds = data.fitness.reduce((sum, item) => sum + (Number(item.seconds) || 0), 0);
    const totalDistance = data.fitness.reduce((sum, item) => sum + (Number(item.distance) || 0), 0);
    const totalMinutes = Math.floor(totalSeconds / 60);
    if (moveTotalTimeEl) moveTotalTimeEl.textContent = totalMinutes >= 60 ? `${Math.floor(totalMinutes / 60)}h ${totalMinutes % 60}min` : `${totalMinutes}min`;
    if (moveTotalDistanceEl) moveTotalDistanceEl.textContent = `${totalDistance.toFixed(2).replace(".", ",")} km`;
    if (moveTotalWorkoutsEl) moveTotalWorkoutsEl.textContent = data.fitness.length;
}

function renderMoveHistory() {
    if (!moveHistoryEl) return;
    if (!data.fitness.length) {
        moveHistoryEl.innerHTML = '<p class="empty">Nenhum treino registrado ainda.</p>';
        return;
    }
    moveHistoryEl.innerHTML = [...data.fitness].reverse().slice(0, 12).map(item => {
        const mins = Math.floor((Number(item.seconds) || 0) / 60);
        const secs = (Number(item.seconds) || 0) % 60;
        const duration = mins >= 60 ? `${Math.floor(mins / 60)}h ${mins % 60}min` : `${mins}min ${secs}s`;
        const distance = Number(item.distance) > 0 ? `${Number(item.distance).toFixed(2).replace(".", ",")} km` : "sem distância";
        return `<article class="move-history-item"><div class="move-history-icon">${item.icon || "•"}</div><div class="move-history-copy"><strong>${escapeHtml(item.name)}</strong><span>${escapeHtml(item.category)} · ${duration} · ${distance}</span></div><time>${escapeHtml(item.date)}</time><button class="move-delete" data-move-delete="${item.id}" type="button" aria-label="Apagar treino">×</button></article>`;
    }).join("");
}

function registerMove() {
    const seconds = Math.floor(Number(moveSeconds) || 0);
    const distance = Math.max(0, Number(String(moveDistanceInput?.value || "").replace(",", ".")) || 0);
    const name = (moveNameInput?.value.trim() || selectedMoveCategory);
    if (seconds < 60) {
        setMoveMessage("Treine pelo menos 1 minuto para registrar.", "error");
        return;
    }
    data.fitness.push({
        id: Date.now(),
        category: selectedMoveCategory,
        name,
        seconds,
        distance: Math.min(distance, 999),
        date: localDateKey(new Date()),
        createdAt: new Date().toISOString(),
        icon: ({Corrida:"🏃", Caminhada:"🚶", Ciclismo:"🚴", Academia:"🏋️", Futebol:"⚽", Natação:"🏊", Outra:"＋"})[selectedMoveCategory] || "•"
    });
    saveData();
    renderMoveStats();
    renderMoveHistory();
    setMoveMessage("Treino registrado no seu perfil.", "success");
    moveNameInput.value = "";
    moveDistanceInput.value = "";
    resetMoveTimer();
    setMoveMessage("Treino registrado no seu perfil.", "success");
}

moveCategories?.addEventListener("click", event => {
    const button = event.target.closest("button[data-category]");
    if (!button) return;
    selectedMoveCategory = button.dataset.category || "Outra";
    moveCategories.querySelectorAll(".move-category").forEach(btn => btn.classList.toggle("active", btn === button));
    if (moveCategoryLabel) moveCategoryLabel.textContent = selectedMoveCategory.toUpperCase();
    if (moveNameInput && !moveNameInput.value.trim()) moveNameInput.placeholder = selectedMoveCategory === "Outra" ? "Ex.: Basquete" : `${selectedMoveCategory} leve`;
});
moveStartBtn?.addEventListener("click", startMoveTimer);
movePauseBtn?.addEventListener("click", pauseMoveTimer);
moveResetBtn?.addEventListener("click", resetMoveTimer);
moveSaveBtn?.addEventListener("click", registerMove);
moveHistoryEl?.addEventListener("click", async event=>{
    const btn=event.target.closest("[data-move-delete]"); if(!btn) return;
    data.fitness=data.fitness.filter(x=>String(x.id)!==String(btn.dataset.moveDelete)); await saveData(); renderMoveStats(); renderMoveHistory(); updateStats(); renderRank(); renderProfileStatus();
});
updateMoveDisplay();

// ---------- Descanso ----------
const restTime = 10 * 60;
let currentRestTime = restTime;
let restTimer = null;
let isRestRunning = false;
let restSegmentStart = null;
let restSegmentBase = null;

function updateRestDisplay() {
    if (restTimeDisplay) restTimeDisplay.textContent = formatTime(currentRestTime);
}

function commitRestSegment() {
    if (!restSegmentStart) return;
    const elapsed = Math.max(0, Math.min(restTime, (Number(restSegmentBase) || currentRestTime) - currentRestTime));
    if (elapsed >= 1) data.restLogs.push({id:Date.now(), seconds:elapsed, date:localDateKey(new Date()), createdAt:new Date().toISOString()});
    restSegmentStart = null; restSegmentBase = null;
    saveData(); updateStats(); renderRank(); renderProfileStatus();
}
function startRestTimer() {
    if (isRestRunning || currentRestTime <= 0) return;
    isRestRunning = true; restSegmentStart = Date.now(); restSegmentBase = currentRestTime; restStartBtn.textContent = "Rodando";
    restTimer = setInterval(() => {
        currentRestTime--; updateRestDisplay();
        if (currentRestTime <= 0) {
            clearInterval(restTimer); restTimer=null; isRestRunning=false;
            commitRestSegment(); restStartBtn.textContent="Começar"; notify("Descanso acabou!","Bora voltar pro foco.");
        }
    },1000);
}
function pauseRestTimer() {
    if (!isRestRunning) return;
    commitRestSegment(); isRestRunning=false; restStartBtn.textContent="Continuar"; clearInterval(restTimer); restTimer=null;
}
function resetRestTimer() {
    if (isRestRunning) { clearInterval(restTimer); restTimer=null; commitRestSegment(); isRestRunning=false; }
    currentRestTime=restTime; restStartBtn.textContent="Começar"; updateRestDisplay();
}

// ---------- Datas / estatísticas ----------
function localDateKey(date) {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
}

function dateFromKey(key) {
    const [y, m, d] = key.split("-").map(Number);
    return new Date(y, m - 1, d);
}

function totalMinutes() {
    return data.sessions.reduce((sum, session) => sum + session.minutes, 0);
}

function todayMinutes() {
    const today = localDateKey(new Date());
    return data.sessions
        .filter(session => session.date === today)
        .reduce((sum, session) => sum + session.minutes, 0);
}

function calculateStreak() {
    const days = new Set(data.sessions.map(session => session.date));
    if (days.size === 0) return 0;

    let cursor = new Date();
    const today = localDateKey(cursor);

    if (!days.has(today)) {
        cursor.setDate(cursor.getDate() - 1);
    }

    let streak = 0;

    while (days.has(localDateKey(cursor))) {
        streak++;
        cursor.setDate(cursor.getDate() - 1);
    }

    return streak;
}

function formatMinutes(minutes) {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;

    if (hours === 0) return `${mins}min`;
    if (mins === 0) return `${hours}h`;
    return `${hours}h ${mins}min`;
}

function updateStats() {
    const total = totalMinutes();
    const today = todayMinutes();
    const streak = calculateStreak();

    if (todayTimeEl) todayTimeEl.textContent = formatMinutes(today);
    if (streakEl) streakEl.textContent = streak;
    if (totalSessionsEl) totalSessionsEl.textContent = data.sessions.length;

    if (totalTimeEl) totalTimeEl.textContent = formatMinutes(total);
    if (panelStreakEl) panelStreakEl.textContent = streak;
    if (panelRestTotalEl) panelRestTotalEl.textContent = formatMinutes(getTotalRestMinutes());
    if (panelMoveTotalEl) panelMoveTotalEl.textContent = formatMinutes(getTotalMoveMinutes());
    renderRank(); renderProfileStatus();
}

function renderHistory() {
    if (!historyEl) return;

    if (data.sessions.length === 0) {
        historyEl.innerHTML = '<p class="empty">Nenhuma sessão registrada ainda.</p>';
        return;
    }

    const sessions = [...data.sessions].reverse();

    historyEl.innerHTML = sessions.map(session => {
        const date = dateFromKey(session.date);
        const formattedDate = date.toLocaleDateString("pt-BR", {
            day: "2-digit",
            month: "2-digit"
        });

        return `
            <article class="history-item">
                <div>
                    <strong>${escapeHtml(session.subject)}</strong>
                    <small>${formattedDate}${session.completed ? " • concluída" : ""}</small>
                </div>
                <strong>${session.minutes} min</strong>
                <button class="history-delete" data-session-delete="${session.id}" type="button" aria-label="Apagar sessão">×</button>
            </article>
        `;
    }).join("");
}

function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
}

historyEl?.addEventListener("click", async event=>{
    const btn=event.target.closest("[data-session-delete]"); if(!btn) return;
    data.sessions=data.sessions.filter(x=>String(x.id)!==String(btn.dataset.sessionDelete)); await saveData(); updateStats(); renderHistory(); renderRank(); renderProfileStatus();
});

// ---------- Metas ----------
const goalPanel = document.getElementById("goal-panel");
const goalBtn = document.getElementById("goal-btn");
const closeGoals = document.getElementById("close-goals");
const goalForm = document.getElementById("goal-form");
const goalInput = document.getElementById("goal-input");
const goalsList = document.getElementById("goals-list");

function openGoals() {
    if (!goalPanel) return;
    goalPanel.classList.add("open"); goalPanel.setAttribute("aria-hidden","false");
    renderGoals();
}
function closeGoalPanel() { if(goalPanel){ goalPanel.classList.remove("open"); goalPanel.setAttribute("aria-hidden","true"); } }
function renderGoals() {
    if (!goalsList) return;
    if (!data.goals?.length) {
        goalsList.innerHTML = '<p class="empty">Nenhuma meta ainda. Comece pequeno e acumule.</p>';
    } else {
        goalsList.innerHTML = data.goals.map(goal => `
            <article class="goal-item ${goal.done ? "done" : ""}">
                <button class="goal-check" data-goal-toggle="${goal.id}" type="button">${goal.done ? "✓" : ""}</button>
                <span class="goal-text">${escapeHtml(goal.text)}</span>
                <button class="goal-delete" data-goal-delete="${goal.id}" type="button" aria-label="Excluir meta">×</button>
            </article>`).join("");
    }
    const pending = (data.goals || []).filter(g => !g.done);
    const goalSummary = document.getElementById("goal-summary");
    if (goalSummary) goalSummary.textContent = pending.length ? `${pending.length} meta${pending.length>1?"s":""} pendente${pending.length>1?"s":""}.` : (data.goals?.length ? "Metas concluídas. Próximo nível." : "Defina uma meta para hoje.");
}

goalBtn?.addEventListener("click", openGoals);
closeGoals?.addEventListener("click", closeGoalPanel);
goalForm?.addEventListener("submit", (event) => {
    event.preventDefault(); const text = goalInput.value.trim(); if(!text) return;
    data.goals.push({id:Date.now(), text, done:false, createdAt:new Date().toISOString()}); saveData(); goalInput.value=""; renderGoals();
});
goalsList?.addEventListener("click", (event) => {
    const toggle = event.target.closest("[data-goal-toggle]"); const del = event.target.closest("[data-goal-delete]");
    if(toggle){ const g=data.goals.find(x=>String(x.id)===toggle.dataset.goalToggle); if(g){g.done=!g.done;saveData();renderGoals();} }
    if(del){ data.goals=data.goals.filter(x=>String(x.id)!==del.dataset.goalDelete); saveData(); renderGoals(); }
});

const CHALLENGES_KEY="rzxChallengesV1";
function getChallenges(){ try{return JSON.parse(localStorage.getItem(CHALLENGES_KEY)||"{}");}catch{return{};} }
function saveChallenges(x){localStorage.setItem(CHALLENGES_KEY,JSON.stringify(x));}
function makeCode(){return Math.random().toString(36).slice(2,8).toUpperCase();}
function challengeURL(code){ const u=new URL(window.location.href); u.searchParams.set("challenge",code); return u.toString(); }
function playerMetrics(username, playerData){
    const sessions=playerData?.sessions||[], fitness=playerData?.fitness||[], rest=playerData?.restLogs||[];
    const focus=sessions.reduce((a,x)=>a+(Number(x.minutes)||0),0), move=Math.floor(fitness.reduce((a,x)=>a+(Number(x.seconds)||0),0)/60), restMin=Math.floor(rest.reduce((a,x)=>a+(Number(x.seconds)||0),0)/60);
    const days=new Set(sessions.map(x=>x.date)).size, rank=rankForDays(days);
    const today=localDateKey(new Date()), todayFocus=sessions.filter(x=>x.date===today).reduce((a,x)=>a+(Number(x.minutes)||0),0), todayMove=Math.floor(fitness.filter(x=>x.date===today).reduce((a,x)=>a+(Number(x.seconds)||0),0)/60);
    const status=(todayFocus+todayMove)>=90?"Ótimo":(todayFocus+todayMove)>=30?"De boa":"Arrastado";
    return {username,focus,rest:restMin,move,days,rank:rank.name,status,points:focus+move+days*10};
}
function localChallengePlayers(code){
    const c=getChallenges()[code]; if(!c) return []; const accounts=getAccounts();
    return (c.members||[]).map(name=>{const a=accounts[normalizeUsername(name)]; return a?playerMetrics(a.username,a.data||{}):null;}).filter(Boolean);
}
async function cloudChallengePlayers(){
    if(!CLOUD_ENABLED || !data.challenge?.code) return null;
    const {data:rows,error}=await supabaseClient.rpc("rzx_challenge_leaderboard",{p_username:currentUser.username,p_token:currentUser.token,p_code:data.challenge.code});
    if(error) throw new Error(error.message||"Não foi possível carregar o ranking.");
    return rows||[];
}
async function renderChallenge(){
    const code=data.challenge?.code;
    if(competitionCodeEl) competitionCodeEl.textContent=code||"SEM COMPETIÇÃO";
    if(challengeShare){challengeShare.classList.toggle("is-hidden",!code);}
    if(challengeLink && code) challengeLink.value=challengeURL(code);
    if(!leaderboardEl) return;
    let players=[];
    try { players = CLOUD_ENABLED ? (await cloudChallengePlayers()||[]) : localChallengePlayers(code); } catch(e){ leaderboardEl.innerHTML=`<p class="empty">${escapeHtml(e.message)}</p>`; return; }
    if(!players.length){leaderboardEl.innerHTML='<p class="empty">Crie uma competição e chame seu primeiro amigo.</p>'; return;}
    players.sort((a,b)=>(b.points||0)-(a.points||0));
    leaderboardEl.innerHTML=players.map((p,i)=>`<article class="leader-row"><span class="leader-pos">${i+1}</span><div class="leader-main"><strong>${escapeHtml(p.username)}</strong><small>${escapeHtml(p.rank)} · ${escapeHtml(p.status)} · ${formatMinutes(Number(p.rest)||0)} descanso · ${formatMinutes(Number(p.move)||0)} treino</small></div><div class="leader-stats"><strong>${formatMinutes(Number(p.focus)||0)}</strong><small>estudo</small></div></article>`).join("");
}
async function createChallenge(){
    try {
        let code;
        if(CLOUD_ENABLED){ const r=await supabaseClient.rpc("rzx_create_challenge",{p_username:currentUser.username,p_token:currentUser.token}); if(r.error) throw new Error(r.error.message); code=r.data?.code; }
        else { const cs=getChallenges(); do{code=makeCode();}while(cs[code]); cs[code]={owner:currentUser.username,members:[currentUser.username],createdAt:new Date().toISOString()}; saveChallenges(cs); }
        data.challenge={code}; await saveData(); await renderChallenge(); alert("Competição criada! Agora copie o link e mande para seu amigo.");
    } catch(e){ alert(e.message||"Não foi possível criar a competição."); }
}
async function joinChallenge(code){
    code=(code||"").trim().toUpperCase(); if(!/^[A-Z0-9]{6}$/.test(code)){alert("Código inválido. Use o código de 6 caracteres.");return;}
    try{
        if(CLOUD_ENABLED){const r=await supabaseClient.rpc("rzx_join_challenge",{p_username:currentUser.username,p_token:currentUser.token,p_code:code});if(r.error)throw new Error(r.error.message);}
        else {const cs=getChallenges(); if(!cs[code]){alert("Essa competição ainda não existe neste dispositivo. Para competir entre aparelhos, conecte o Supabase.");return;} if(!cs[code].members.includes(currentUser.username))cs[code].members.push(currentUser.username); saveChallenges(cs);}
        data.challenge={code}; await saveData(); await renderChallenge(); alert("Você entrou na competição.");
    }catch(e){alert(e.message||"Não foi possível entrar.");}
}
createChallengeBtn?.addEventListener("click",createChallenge);
joinChallengeBtn?.addEventListener("click",()=>{const code=prompt("Digite o código da competição:");if(code)joinChallenge(code);});
copyChallengeBtn?.addEventListener("click",async()=>{if(!challengeLink?.value)return; try{await navigator.clipboard.writeText(challengeLink.value);copyChallengeBtn.textContent="Copiado";setTimeout(()=>copyChallengeBtn.textContent="Copiar",1400);}catch{challengeLink.select();document.execCommand("copy");copyChallengeBtn.textContent="Copiado";setTimeout(()=>copyChallengeBtn.textContent="Copiar",1400);}});
function autoJoinFromURL(){const code=new URLSearchParams(window.location.search).get("challenge");if(code && currentUser) joinChallenge(code);}

// ---------- Painel ----------
function openStats() {
    if (statsPanel && overlay) {
        statsPanel.classList.add("open");
        overlay.classList.add("show");
        statsPanel.setAttribute("aria-hidden", "false");
        renderChallenge();
    }
}

function closeStatsPanel() {
    if (statsPanel && overlay) {
        statsPanel.classList.remove("open");
        overlay.classList.remove("show");
        statsPanel.setAttribute("aria-hidden", "true");
    }
}

// ---------- Notificação ----------
function notify(title, body) {
    if ("Notification" in window && Notification.permission === "granted") {
        new Notification(title, { body });
    } else {
        alert(`${title}\n${body}`);
    }
}

function requestNotificationPermission() {
    if ("Notification" in window && Notification.permission === "default") {
        Notification.requestPermission();
    }
}

// ---------- Eventos ----------
if (startBtn) startBtn.addEventListener("click", startTimer);
if (pauseBtn) pauseBtn.addEventListener("click", pauseTimer);
if (resetBtn) resetBtn.addEventListener("click", resetTimer);
if (registerBtn) {
    registerBtn.addEventListener("click", () => {
        requestNotificationPermission();
        registerCurrentSession();
    });
}

if (restStartBtn) restStartBtn.addEventListener("click", startRestTimer);
if (restPauseBtn) restPauseBtn.addEventListener("click", pauseRestTimer);
if (restResetBtn) restResetBtn.addEventListener("click", resetRestTimer);

if (statsBtn) statsBtn.addEventListener("click", openStats);
if (closeStats) closeStats.addEventListener("click", closeStatsPanel);
if (overlay) overlay.addEventListener("click", closeStatsPanel);

if (clearHistoryBtn) {
    clearHistoryBtn.addEventListener("click", () => {
        if (!data.sessions.length) return;

        if (confirm("Apagar todo o histórico de estudos?")) {
            data.sessions = [];
            saveData();
            updateStats();
            renderHistory();
        }
    });
}

// ---------- Sessão ----------
const logoutBtn = document.getElementById("logout-btn");
logoutBtn?.addEventListener("click", () => {
    if (CLOUD_ENABLED && currentUser?.token) { supabaseClient.rpc("rzx_logout", { p_username: currentUser.username, p_token: currentUser.token }).catch(()=>{}); localStorage.removeItem(CLOUD_SESSION_KEY); }
    clearCurrentUserKey(); currentUser = null; data = {sessions:[],goals:[],fitness:[],restLogs:[],profile:{},challenge:null}; closeStatsPanel(); closeGoalPanel(); showLogin();
});

// ---------- Inicialização dos Controles Principais ----------
updateDisplay();
updateRestDisplay();
updateStats();
renderHistory();
updateUserUI();


/* =================================================================================
   🎓 GUIA DIDÁTICO: MOTOR DE CARROSSEL 3D HIGH-END (ESTILO BENCHO.DEV)
   ---------------------------------------------------------------------------------
   💡 COMO ESTE MOTOR FUNCIONA?
   
   1. MATEMÁTICA DA CIRCUNFERÊNCIA (LOOP INFINITO):
      Calculamos a distância ('diff') de cada carta em relação à carta ativa no momento.
      Isso faz com que cartas vizinhas inclinem (-25deg / +25deg) e se afastem no eixo Z
      (profundidade).

   2. FÍSICA DE ARRASTO (TOUCH / SWIPE NO CELULAR):
      Monitoramos onde o usuário encosta o dedo (startX) e pra onde ele arrasta (currentX).
      Se o arrasto for maior que 40 pixels, acionamos a transição para a próxima carta.

   3. COMO REUTILIZAR EM OUTRO SITE (EX: LOJA DE ESPORTES):
      Você só precisa ter uma estrutura HTML com os cards e chamar 'init3DCarousel()'.
   ================================================================================= */

function init3DCarousel() {
    const wrapper = document.getElementById("carouselWrapper");
    const cards = document.querySelectorAll(".carousel-card");
    const prevBtn = document.getElementById("carousel-prev");
    const nextBtn = document.getElementById("carousel-next");
    const dotsContainer = document.getElementById("carouselDots");

    if (!wrapper || cards.length === 0) return;

    let currentIndex = 0;
    const totalCards = cards.length;

    // -------------------------------------------------------------
    // PASSO 1: O CÁLCULO DE POSIÇÃO 3D (O "CORAÇÃO" DA ANIMAÇÃO)
    // -------------------------------------------------------------
    function updateCarousel3D() {
        cards.forEach((card, index) => {
            // Calcula a diferença relativa de posição considerando o loop circular
            let diff = index - currentIndex;

            // Ajuste para criar o loop infinito perfeito (ex: da carta 3 voltar pra 0)
            if (diff > totalCards / 2) diff -= totalCards;
            if (diff < -totalCards / 2) diff += totalCards;

            const absDiff = Math.abs(diff);

            if (absDiff === 0) {
                // 🌟 CARTA ATIVA (CENTRO)
                // Sem Rotação | Totalmente Visível | À frente no Eixo Z
                card.style.transform = `translateX(0px) translateZ(0px) rotateY(0deg) scale(1)`;
                card.style.opacity = "1";
                card.style.zIndex = "10";
                card.style.filter = "blur(0px)";
                card.classList.add("active");
            } else if (absDiff === 1) {
                // 🔹 CARTAS ADJACENTES (1 Posição para Esquerda ou Direita)
                // Viradas 25 graus para o centro, empurradas para trás (-120px Z) e levemente desfocadas
                const direction = diff > 0 ? 1 : -1;
                const translateX = direction * 115; // Afastamento lateral em pixels
                const rotateY = direction * -25;    // Rotação 3D estilo cartas de baralho

                card.style.transform = `translateX(${translateX}px) translateZ(-120px) rotateY(${rotateY}deg) scale(0.88)`;
                card.style.opacity = "0.65";
                card.style.zIndex = "5";
                card.style.filter = "blur(1.5px)";
                card.classList.remove("active");
            } else {
                // 💤 CARTAS DISTANTES (Ocultas no fundo)
                const direction = diff > 0 ? 1 : -1;
                const translateX = direction * 180;

                card.style.transform = `translateX(${translateX}px) translateZ(-250px) rotateY(${direction * -40}deg) scale(0.7)`;
                card.style.opacity = "0";
                card.style.zIndex = "1";
                card.style.filter = "blur(4px)";
                card.classList.remove("active");
            }
        });

        // Atualiza os indicadores de bolinhas (Dots)
        updateDots();
    }

    // -------------------------------------------------------------
    // PASSO 2: ATUALIZAR OS INDICADORES (DOTS)
    // -------------------------------------------------------------
    function updateDots() {
        if (!dotsContainer) return;
        const dots = dotsContainer.querySelectorAll(".dot");
        dots.forEach((dot, idx) => {
            if (idx === currentIndex) {
                dot.classList.add("active");
            } else {
                dot.classList.remove("active");
            }
        });
    }

    // -------------------------------------------------------------
    // PASSO 3: NAVEGAÇÃO (PRÓXIMO / ANTERIOR)
    // -------------------------------------------------------------
    function nextCard() {
        currentIndex = (currentIndex + 1) % totalCards;
        updateCarousel3D();
    }

    function prevCard() {
        currentIndex = (currentIndex - 1 + totalCards) % totalCards;
        updateCarousel3D();
    }

    // Eventos dos botões de seta
    if (nextBtn) nextBtn.addEventListener("click", nextCard);
    if (prevBtn) prevBtn.addEventListener("click", prevCard);

    // Eventos de clique direto nas bolinhas (Dots)
    if (dotsContainer) {
        dotsContainer.addEventListener("click", (e) => {
            const targetDot = e.target.closest(".dot");
            if (targetDot && targetDot.dataset.index !== undefined) {
                currentIndex = parseInt(targetDot.dataset.index, 10);
                updateCarousel3D();
            }
        });
    }

    // Clique direto em qualquer carta para trazê-la para o centro
    cards.forEach((card) => {
        card.addEventListener("click", () => {
            const cardIdx = parseInt(card.dataset.index, 10);
            if (cardIdx !== currentIndex) {
                currentIndex = cardIdx;
                updateCarousel3D();
            }
        });
    });

    // -------------------------------------------------------------
    // PASSO 4: FÍSICA DE SWIPE / ARRASTO (TOUCH NO CELULAR & MOUSE NO PC)
    // -------------------------------------------------------------
    let startX = 0;
    let isDragging = false;
    let deltaX = 0;

    // Início do Toque / Clique
    function handleDragStart(e) {
        isDragging = true;
        startX = e.type.includes("touch") ? e.touches[0].clientX : e.clientX;
    }

    // Movimento do Arraste
    function handleDragMove(e) {
        if (!isDragging) return;
        const currentX = e.type.includes("touch") ? e.touches[0].clientX : e.clientX;
        deltaX = currentX - startX;
    }

    // Soltar o Toque / Clique
    function handleDragEnd() {
        if (!isDragging) return;
        isDragging = false;

        const threshold = 40; // Sensibilidade do arrasto em pixels

        if (deltaX < -threshold) {
            nextCard(); // Arrastou para a esquerda -> Próximo
        } else if (deltaX > threshold) {
            prevCard(); // Arrastou para a direita -> Anterior
        }

        deltaX = 0;
    }

    // Registra os Eventos de Gestos no Container do Carrossel
    wrapper.addEventListener("touchstart", handleDragStart, { passive: true });
    wrapper.addEventListener("touchmove", handleDragMove, { passive: true });
    wrapper.addEventListener("touchend", handleDragEnd);

    wrapper.addEventListener("mousedown", handleDragStart);
    window.addEventListener("mousemove", handleDragMove);
    window.addEventListener("mouseup", handleDragEnd);

    // Renderiza a posição inicial assim que a página carregar
    updateCarousel3D();
}

// Inicializa o Carrossel 3D
document.addEventListener("DOMContentLoaded", init3DCarousel);

// Restaurar conta salva neste dispositivo.
restoreSession();
