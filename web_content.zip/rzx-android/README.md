# RZX.STUDY Android

Empacotamento Android do projeto web RZX.STUDY usando WebView e assets locais.

## Build

Abra esta pasta no Android Studio com Android SDK instalado (compile/target SDK 36).

- Debug APK: `./gradlew assembleDebug`
- Release APK: `./gradlew assembleRelease`
- Play Store: `./gradlew bundleRelease` (gera AAB)

Para publicação, configure sua própria chave de assinatura no Android Studio/Gradle. Não publique com uma chave de debug.

## Observações

- O modo local funciona sem Supabase.
- O projeto original mantém o Supabase desativado por padrão (`supabase-config.js`).
- O WebView usa uma origem HTTPS local (`https://rzx.local`) para preservar recursos web como Web Crypto/`crypto.subtle`.
- Internet é permitida para Google Fonts e, caso o Supabase seja habilitado, para o backend.
