'use strict';
const $=id=>document.getElementById(id),cv=$('cv'),cx=cv.getContext('2d'),ex=document.createElement('canvas'),ec=ex.getContext('2d');
const LS=window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.LiteStream;
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let uid=1,cur=0,sel=-1,live=false,busy=false,mic=true,W=1280,H=720,dirty=true,ovBusy=false,bb=[],chatLines=[],chatOn=false,chatT=0,lcid=null,ptok='',chatErr=false,drag=null;
const imgs=new Map(),SAMPLE=[['Rahul','Nice gameplay, bro!'],['Priya','Which game is this?'],['Sam','GG 🔥']];
const scenes=[{name:'Gameplay',src:[{id:uid++,t:'chat',on:1,x:2,y:50,w:34}]},
{name:'Starting soon',src:[{id:uid++,t:'color',on:1,c:'#1d3557'},{id:uid++,t:'text',on:1,x:12,y:40,w:50,tx:'Stream starting soon'}]}];
const S=()=>scenes[cur],cl=v=>Math.max(0,Math.min(100,v));
function toast(m){const t=$('toast');t.textContent=m;t.style.display='block';clearTimeout(t.h);t.h=setTimeout(()=>t.style.display='none',4000)}
function tab(p){document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('on',b.dataset.p==p));document.querySelectorAll('.pan').forEach(d=>d.classList.toggle('on',d.id==p))}
$('nav').onclick=e=>e.target.dataset.p&&tab(e.target.dataset.p);
/* ---------- rendering ---------- */
function fit(c,s,mw){if(c.measureText(s).width<=mw)return s;while(s.length>1&&c.measureText(s+'…').width>mw)s=s.slice(0,-1);return s+'…'}
function layers(c,W,H,box){c.textAlign='left';
S().src.forEach((o,i)=>{if(!o.on)return;let b=null;const x=W*o.x/100,y=H*o.y/100;
if(o.t=='color'){c.fillStyle=o.c;c.fillRect(0,0,W,H);b=[0,0,W,H]}
else if(o.t=='img'){const m=imgs.get(o.id);if(!m)return;const w=W*o.w/100,h=w*m.naturalHeight/m.naturalWidth;c.drawImage(m,x,y,w,h);b=[x,y,w,h]}
else if(o.t=='text'){const f=H*.08*o.w/30;c.font='bold '+f+'px sans-serif';c.textBaseline='top';c.shadowColor='#000';c.shadowBlur=f/6;c.fillStyle='#fff';c.fillText(o.tx,x,y,W-x);c.shadowBlur=0;b=[x,y,Math.min(c.measureText(o.tx).width,W-x),f*1.2]}
else if(o.t=='chat'){const lines=box&&!live?SAMPLE:chatLines.slice(-6),bw=W*o.w/100,f=bw/20,lh=f*1.4,p=f*.5;
if(lines.length){const bh=lines.length*lh+p*2;c.fillStyle='rgba(0,0,0,.55)';c.fillRect(x,y,bw,bh);c.textBaseline='top';
lines.forEach((l,k)=>{const ty=y+p+k*lh;c.font='bold '+f+'px sans-serif';c.fillStyle='#ffd166';const a=fit(c,l[0],bw*.4)+': ',aw=c.measureText(a).width;c.fillText(a,x+p,ty);c.font=f+'px sans-serif';c.fillStyle='#fff';c.fillText(fit(c,l[1],bw-p*2-aw),x+p+aw,ty)});b=[x,y,bw,bh]}
else b=[x,y,bw,f*3]}
if(box&&b)box[i]=b})}
function paint(){bb=[];cx.fillStyle='#2b2f3a';cx.fillRect(0,0,W,H);cx.fillStyle='#4a5063';cx.font=H/14+'px sans-serif';cx.textAlign='center';cx.textBaseline='middle';cx.fillText('📱 Screen Capture',W/2,H/2);
layers(cx,W,H,bb);if(sel>=0&&bb[sel]){cx.strokeStyle='#4c8dff';cx.lineWidth=Math.max(2,W/320);cx.strokeRect(...bb[sel])}}
async function pushOv(){ovBusy=true;try{ec.clearRect(0,0,W,H);layers(ec,W,H,null);await LS.setOverlay({png:ex.toDataURL('image/png').split(',')[1]})}catch(e){}ovBusy=false}
setInterval(()=>{if(!dirty)return;paint();if(live&&LS){if(ovBusy)return;dirty=false;pushOv()}else dirty=false},300);
function setDims(){const[s]=$('res').value.split('|').map(Number),l=Math.round(s*16/9/2)*2,v=$('ori').value=='v';W=v?s:l;H=v?l:s;cv.width=ex.width=W;cv.height=ex.height=H;dirty=true}
$('ori').onchange=$('res').onchange=setDims;
/* ---------- UI lists ---------- */
const ICON={img:'🖼 ',text:'🔤 ',chat:'💬 Chat',color:'🎨 Color'};
function syncAdj(){const o=S().src[sel],a=$('adj');a.classList.toggle('on',!!o&&o.t!='color');if(o&&o.t!='color'){$('ax').value=o.x;$('ay').value=o.y;$('aw').value=o.w}}
function render(){
$('scl').innerHTML=scenes.map((s,i)=>`<div class="row ${i==cur?'sel':''}"><span style="flex:1" data-a="sc" data-i="${i}">${esc(s.name)}</span><button data-a="rn" data-i="${i}">✏️</button>${scenes.length>1?`<button data-a="dsc" data-i="${i}">🗑</button>`:''}</div>`).join('');
$('sol').innerHTML=S().src.map((o,i)=>`<div class="row ${i==sel?'sel':''}"><span style="flex:1" data-a="pk" data-i="${i}">${ICON[o.t]}${o.t=='text'?esc(o.tx):o.t=='img'?esc(o.nm||'Photo'):''}</span><button data-a="up" data-i="${i}">▲</button><button data-a="dn" data-i="${i}">▼</button>${o.t=='text'?`<button data-a="edt" data-i="${i}">✏️</button>`:''}${o.t=='color'?`<input class="clr" type="color" value="${/^#[0-9a-f]{6}$/i.test(o.c)?o.c:'#000000'}" data-a="clr" data-i="${i}">`:''}<button data-a="tgl" data-i="${i}">${o.on?'👁':'🚫'}</button><button data-a="dso" data-i="${i}">🗑</button></div>`).join('')||'<small>No sources</small>';
syncAdj();dirty=true}
document.addEventListener('click',e=>{const el=e.target.closest('[data-a]');if(!el)return;const i=+el.dataset.i,a=el.dataset.a,s=S().src;
if(a=='sc'){cur=i;sel=-1}else if(a=='rn'){const v=prompt('Scene name',scenes[i].name);if(v)scenes[i].name=v.slice(0,30)}
else if(a=='dsc'){scenes.splice(i,1);cur=0;sel=-1}else if(a=='pk')sel=sel==i?-1:i;
else if(a=='dso'){s.splice(i,1);sel=-1}else if(a=='tgl')s[i].on^=1;
else if(a=='up'&&i<s.length-1){[s[i],s[i+1]]=[s[i+1],s[i]];sel=i+1}else if(a=='dn'&&i>0){[s[i],s[i-1]]=[s[i-1],s[i]];sel=i-1}
else if(a=='edt'){const v=prompt('Text',s[i].tx);if(v!==null)s[i].tx=v.slice(0,80)}else return;render()});
document.addEventListener('input',e=>{const t=e.target;if(t.dataset.a=='clr'){S().src[+t.dataset.i].c=t.value;dirty=true}
else if(['ax','ay','aw'].includes(t.id)&&S().src[sel]){const o=S().src[sel];o[{ax:'x',ay:'y',aw:'w'}[t.id]]=+t.value;dirty=true}});
$('addsc').onclick=()=>{scenes.push({name:'Scene '+(scenes.length+1),src:[]});cur=scenes.length-1;sel=-1;render()};
document.querySelectorAll('[data-add]').forEach(b=>b.onclick=()=>{const t=b.dataset.add,s=S().src;
if(t=='img')return $('pick').click();
s.push(t=='text'?{id:uid++,t,on:1,x:5,y:5,w:30,tx:'New text'}:t=='chat'?{id:uid++,t,on:1,x:2,y:50,w:34}:{id:uid++,t,on:1,c:'#2a9d8f'});sel=t=='color'?-1:s.length-1;render()});
$('pick').onchange=e=>{const f=e.target.files[0];e.target.value='';if(!f)return;if(f.size>12e6)return toast('Photo is too large (max 12MB).');
const m=new Image(),u=URL.createObjectURL(f);m.onload=()=>{const id=uid++;imgs.set(id,m);S().src.push({id,t:'img',on:1,x:5,y:5,w:25,nm:f.name.slice(0,30)});sel=S().src.length-1;render()};m.onerror=()=>toast('Could not open the photo.');m.src=u};
/* drag on preview */
const pt=e=>{const r=cv.getBoundingClientRect();return[(e.clientX-r.left)*W/r.width,(e.clientY-r.top)*H/r.height]};
cv.onpointerdown=e=>{const[p,q]=pt(e);sel=-1;for(let i=bb.length-1;i>=0;i--){const b=bb[i],o=S().src[i];if(b&&o.t!='color'&&p>=b[0]&&p<=b[0]+b[2]&&q>=b[1]&&q<=b[1]+b[3]){sel=i;break}}
if(sel>=0){const o=S().src[sel];drag={p,q,x:o.x,y:o.y};cv.setPointerCapture(e.pointerId)}render()};
cv.onpointermove=e=>{if(!drag)return;const o=S().src[sel],[p,q]=pt(e);o.x=cl(drag.x+(p-drag.p)*100/W);o.y=cl(drag.y+(q-drag.q)*100/H);syncAdj();dirty=true};
cv.onpointerup=cv.onpointercancel=()=>drag=null;
/* ---------- chat (YouTube Data API) ---------- */
const vidId=s=>{s=s.trim();const m=s.match(/(?:v=|youtu\.be\/|\/live\/|\/embed\/)([\w-]{11})/);return m?m[1]:/^[\w-]{11}$/.test(s)?s:''};
async function chatLoop(){clearTimeout(chatT);if(!live)return;const k=$('yk').value.trim(),v=vidId($('vid').value);if(!k||!v)return;let wait=5000;
try{const g=u=>fetch('https://www.googleapis.com/youtube/v3/'+u+'&key='+encodeURIComponent(k)).then(r=>r.json());
if(!lcid){const j=await g('videos?part=liveStreamingDetails&id='+v);if(j.error)throw 0;const d=j.items&&j.items[0]&&j.items[0].liveStreamingDetails;lcid=d&&d.activeLiveChatId;if(!lcid)wait=15000}
if(lcid){const j=await g('liveChatMessages?part=snippet,authorDetails&maxResults=50&liveChatId='+encodeURIComponent(lcid)+(ptok?'&pageToken='+encodeURIComponent(ptok):''));
if(j.error){lcid=null;throw 0}ptok=j.nextPageToken||'';wait=Math.max(5000,j.pollingIntervalMillis||5000);
for(const m of j.items||[]){const t=m.snippet&&m.snippet.displayMessage;if(t)chatLines.push([String(m.authorDetails.displayName).slice(0,30),String(t).slice(0,120)])}
chatLines=chatLines.slice(-20);dirty=true;chatErr=false}}
catch(e){wait=30000;if(!chatErr){chatErr=true;toast('Chat failed to load: check the API key / Video ID.')}}
chatT=setTimeout(chatLoop,wait)}
/* ---------- live ---------- */
function ui(state){live=state=='live'||state=='connecting';busy=false;
const b=$('badge');b.textContent={live:'● LIVE',connecting:'Connecting…',failed:'Failed',stopped:'Offline'}[state]||'Offline';b.className='badge '+(state=='live'?'live':state=='failed'?'fail':'');
$('go').textContent=live?'⏹ End Live':'📡 Go Live';$('go').classList.toggle('red',live);$('go').classList.toggle('grn',!live);
['key','ori','res','fps'].forEach(i=>$(i).disabled=live);
if(live){if(!chatOn){chatOn=true;chatLines=[];lcid=null;ptok='';chatErr=false;chatLoop()}if(state=='live')dirty=true}else{chatOn=false;clearTimeout(chatT)}}
if(LS)LS.addListener('state',e=>{ui(e.state);if(e.msg)toast(e.msg)});
$('mic').onclick=async()=>{mic=!mic;$('mic').textContent=mic?'ON':'OFF';$('mic').classList.toggle('grn',mic);if(live&&LS)try{await LS.setMic({on:mic})}catch(e){}};
$('go').onclick=async()=>{if(busy)return;
if(live){busy=true;try{await LS.stop()}catch(e){}ui('stopped');return}
if(!LS)return toast('This works only in the Android app.');
const key=$('key').value.trim();if(!/^[\w-]{8,64}$/.test(key)){tab('sm');return toast('Enter a valid YouTube stream key.')}
const k=+$('res').value.split('|')[1];
if(scenes.some(s=>s.src.some(o=>o.t=='chat'))&&(!$('yk').value.trim()||!vidId($('vid').value)))toast('Chat will stay off: enter the Video ID + API key in the Stream tab.');
busy=true;ui('connecting');
try{await LS.start({key,width:W,height:H,fps:+$('fps').value,kbps:k,mic})}catch(e){ui('stopped');toast(e&&e.message?e.message:'Screen capture did not start.')}};
setDims();render();ui('stopped');
