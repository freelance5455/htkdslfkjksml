package com.lite.studio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.IBinder;
import android.util.DisplayMetrics;

import com.pedro.common.ConnectChecker;
import com.pedro.encoder.input.gl.render.filters.object.ImageObjectFilterRender;
import com.pedro.rtplibrary.rtmp.RtmpDisplay;

/** Foreground service: screen capture (MediaProjection) -> RTMPS -> YouTube. */
public class LiteStreamService extends Service implements ConnectChecker {
  public interface Listener { void onState(String state, String msg); }
  static volatile Listener listener;
  static volatile RtmpDisplay display;
  static volatile Bitmap pending;                 // latest overlay (photos, QR, chat, text) drawn by the web UI
  static ImageObjectFilterRender filter;

  /** Full-frame transparent overlay on top of the captured screen. */
  static synchronized void setOverlay(Bitmap b) {
    pending = b;
    RtmpDisplay d = display;
    if (d == null || b == null) return;
    try {
      if (filter == null) {
        filter = new ImageObjectFilterRender();
        d.getGlInterface().setFilter(filter);
        filter.setScale(100f, 100f);
        filter.setPosition(0f, 0f);
      }
      filter.setImage(b);
    } catch (Exception ignored) {}
  }

  @Override public IBinder onBind(Intent i) { return null; }

  @Override @SuppressWarnings("deprecation")
  public int onStartCommand(Intent i, int flags, int id) {
    if (i == null) return START_NOT_STICKY;
    if ("stop".equals(i.getAction())) { shutdown("stopped", null); return START_NOT_STICKY; }
    if (display != null) return START_NOT_STICKY;

    NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    Notification.Builder nb;
    if (Build.VERSION.SDK_INT >= 26) {
      nm.createNotificationChannel(new NotificationChannel("live", "Live", NotificationManager.IMPORTANCE_LOW));
      nb = new Notification.Builder(this, "live");
    } else nb = new Notification.Builder(this);
    Notification n = nb.setContentTitle("P Studio").setContentText("Streaming your screen")
        .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build();
    // Must be foreground BEFORE the MediaProjection is created (Android 14+).
    if (Build.VERSION.SDK_INT >= 29)
      startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION | ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
    else startForeground(1, n);

    String key = i.getStringExtra("key");
    int w = i.getIntExtra("w", 1280), h = i.getIntExtra("h", 720), fps = i.getIntExtra("fps", 30), kbps = i.getIntExtra("kbps", 3000);
    boolean mic = i.getBooleanExtra("mic", true);
    Intent data = i.getParcelableExtra("data");
    try {
      display = new RtmpDisplay(this, true, this);
      display.setIntentResult(i.getIntExtra("rc", 0), data);
      DisplayMetrics dm = getResources().getDisplayMetrics();
      boolean ok = display.prepareVideo(w, h, fps, kbps * 1000, 0, dm.densityDpi)
                && display.prepareAudio(128 * 1000, 44100, true);
      if (!ok) { shutdown("failed", "Encoder not supported at this quality. Try lower."); return START_NOT_STICKY; }
      display.startStream("rtmps://a.rtmps.youtube.com:443/live2/" + key);
      if (!mic) display.disableAudio();
    } catch (Exception e) { shutdown("failed", "Could not start capture."); }
    return START_NOT_STICKY;
  }

  static void setMic(boolean on) {
    RtmpDisplay d = display;
    if (d == null) return;
    if (on) d.enableAudio(); else d.disableAudio();
  }

  private void shutdown(String state, String msg) {
    try { if (display != null) { if (display.isStreaming()) display.stopStream(); } } catch (Exception ignored) {}
    display = null; filter = null; pending = null;
    stopForeground(true); stopSelf();
    emit(state, msg);
  }
  private static void emit(String s, String m) { Listener l = listener; if (l != null) l.onState(s, m); }

  @Override public void onDestroy() { if (display != null) shutdown("stopped", null); super.onDestroy(); }

  // ---- ConnectChecker ----
  @Override public void onConnectionStarted(String url) { emit("connecting", null); }
  @Override public void onConnectionSuccess() { setOverlay(pending); emit("live", null); }
  @Override public void onConnectionFailed(String reason) { shutdown("failed", "Connection failed. Check stream key & internet."); }
  @Override public void onNewBitrate(long bitrate) {}
  @Override public void onDisconnect() { if (display != null) shutdown("stopped", "Disconnected."); }
  @Override public void onAuthError() { shutdown("failed", "YouTube rejected the stream key."); }
  @Override public void onAuthSuccess() {}
}
