package com.lite.studio;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.media.projection.MediaProjectionManager;

import androidx.activity.result.ActivityResult;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

@CapacitorPlugin(name = "LiteStream",
    permissions = { @Permission(strings = { Manifest.permission.RECORD_AUDIO }, alias = "mic") })
public class LiteStreamPlugin extends Plugin {

  @PluginMethod
  public void start(PluginCall call) {
    if (getPermissionState("mic") != PermissionState.GRANTED) { requestPermissionForAlias("mic", call, "permCb"); return; }
    launch(call);
  }

  @PermissionCallback
  private void permCb(PluginCall call) {
    if (getPermissionState("mic") == PermissionState.GRANTED) launch(call);
    else call.reject("Microphone permission denied.");
  }

  private void launch(PluginCall call) {
    MediaProjectionManager m = (MediaProjectionManager) getContext().getSystemService(Context.MEDIA_PROJECTION_SERVICE);
    // Android shows its own picker: "Single app" / "Entire screen" (Android 14+).
    startActivityForResult(call, m.createScreenCaptureIntent(), "projCb");
  }

  @ActivityCallback
  private void projCb(PluginCall call, ActivityResult r) {
    if (call == null) return;
    if (r.getResultCode() != Activity.RESULT_OK || r.getData() == null) { call.reject("Screen capture cancelled."); return; }
    LiteStreamService.listener = (state, msg) -> {
      JSObject o = new JSObject(); o.put("state", state); if (msg != null) o.put("msg", msg);
      notifyListeners("state", o);
    };
    Intent s = new Intent(getContext(), LiteStreamService.class);
    s.putExtra("rc", r.getResultCode()).putExtra("data", r.getData())
     .putExtra("key", call.getString("key")).putExtra("w", call.getInt("width", 1280)).putExtra("h", call.getInt("height", 720))
     .putExtra("fps", call.getInt("fps", 30)).putExtra("kbps", call.getInt("kbps", 3000))
     .putExtra("mic", call.getBoolean("mic", true));
    ContextCompat.startForegroundService(getContext(), s);
    call.resolve();
  }

  @PluginMethod
  public void stop(PluginCall call) {
    getContext().startService(new Intent(getContext(), LiteStreamService.class).setAction("stop"));
    call.resolve();
  }

  @PluginMethod
  public void setMic(PluginCall call) { LiteStreamService.setMic(call.getBoolean("on", true)); call.resolve(); }

  @PluginMethod
  public void setOverlay(PluginCall call) {
    try {
      byte[] b = Base64.decode(call.getString("png", ""), Base64.DEFAULT);
      Bitmap bm = BitmapFactory.decodeByteArray(b, 0, b.length);
      if (bm != null) LiteStreamService.setOverlay(bm);
    } catch (Exception ignored) {}
    call.resolve();
  }
}
