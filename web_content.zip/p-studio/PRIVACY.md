# Privacy Policy — P Studio
Last updated: October 21, 2026

**Summary:** P Studio does not collect, store, sell or share your personal data.

## What the app accesses
- **Screen capture and microphone:** only after you allow permission, and only while you stream. Android shows a recording indicator.

## What leaves your device
- **Live streaming:** when you tap Go Live, your screen video and mic audio go directly over an encrypted connection (RTMPS) to YouTube. No server of ours is involved.
- **Recordings:** stay on your phone until you save or delete them. They are never uploaded by the app.

- **Photos/QR you add:** stay in memory, only drawn into your stream.
- **Chat (optional):** if you enter an API key and video ID, the app asks YouTube's API for that live chat. Nothing else is sent.

## What is stored
Nothing. Your stream key lives in memory and disappear when the app closes. The app has no analytics, ads, trackers or crash reporting.

## Your control
Revoke camera/microphone in Android settings at any time. Reset your stream key in YouTube Studio if you think it leaked.

## Third parties
Google/YouTube process data under their own policies (policies.google.com/privacy).

## Contact
Add your email here: ______________
