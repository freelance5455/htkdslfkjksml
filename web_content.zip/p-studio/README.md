# P Studio (direct stream-key version)
No relay server, no password, no Google sign-in. Only your YouTube stream key.
Phone screen + overlay layer (scenes: photos/QR, text, chat, color) -> native RTMPS -> YouTube.
The web UI draws the overlay as a transparent PNG; native code lays it over the screen capture (RootEncoder ImageObjectFilterRender).
Chat (optional) needs a YouTube Data API key + the live's video ID; polling uses API quota (~3 h/day on the free 10k quota).

## Build (Android)
    npm init -y && npm i @capacitor/core @capacitor/cli @capacitor/android
    npx cap add android

1. Copy `native/*.java` into `android/app/src/main/java/com/lite/studio/` (replace MainActivity.java).
2. `android/build.gradle` (or settings.gradle repositories): add  `maven { url 'https://jitpack.io' }`
3. `android/app/build.gradle` dependencies: add
       implementation 'com.github.pedroSG94.RootEncoder:library:2.5.5'
   (if a newer 2.x exists, use it; the package `com.pedro.common.ConnectChecker` may differ slightly by version)
4. `AndroidManifest.xml`, before <application>:
       <uses-permission android:name="android.permission.INTERNET"/>
       <uses-permission android:name="android.permission.RECORD_AUDIO"/>
       <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
       <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION"/>
       <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE"/>
   inside <application> (also set android:allowBackup="false"):
       <service android:name=".LiteStreamService" android:exported="false"
                android:foregroundServiceType="mediaProjection|microphone"/>
5. `npx cap sync android` then build a signed release APK.

## Use
Stream tab: paste stream key -> pick Horizontal/Vertical -> Go Live.
Android asks "Single app or Entire screen" (Android 14+; older versions = entire screen).
