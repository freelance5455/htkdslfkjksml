/* JOSTECH — LABORATOIRE INFORMATIQUE INTERACTIF (CORRIGÉ ACODE) */
(function () { const s = document.createElement("script"); s.src = "lab-sql.js"; document.head.appendChild(s); })();
let labInitialized = false, currentLabMode = "web", pyodideInstance = null;

function initLabView() {
  const host = document.getElementById("view-lab"); if (!host) return;
  if (!labInitialized) {
    labInitialized = true;
    host.innerHTML = `
      <div class="section-header"><h2 class="metallic-text">Laboratoire Interactif</h2><span class="pill-badge pilot">Palier 1</span></div>
      <p class="section-sub">Pratiquez directement sur votre téléphone : Web, JavaScript, SQL (hors ligne) et Python.</p>
      <div id="lab-tabs" class="lab-tabs">
        <button class="level-tab active" data-lab="web">HTML/CSS</button>
        <button class="level-tab" data-lab="js">JS / Algo</button>
        <button class="level-tab" data-lab="sql">SQL</button>
        <button class="level-tab" data-lab="python">Python</button>
      </div>
      <div class="code-card">
        <div class="code-header"><span id="lab-lang-label">Éditeur Web</span><button class="copy-btn" onclick="resetLabTemplate()">Exemple</button></div>
        <textarea id="lab-editor" class="lab-editor" rows="9" spellcheck="false"></textarea>
      </div>
      <div class="hero-actions" style="margin-bottom:14px;">
        <button id="lab-run-btn" class="btn-primary" onclick="runLabCode()">▶ Exécuter le code</button>
        <button class="btn-secondary" onclick="clearLabOutput()">Effacer sortie</button>
      </div>
      <div id="lab-output-box" class="lab-output-box">
        <div class="code-header"><span>Résultat d'exécution</span></div>
        <iframe id="lab-iframe" class="lab-iframe" sandbox="allow-scripts"></iframe>
        <pre id="lab-console-out" class="lab-console" style="display:none; padding:14px;"></pre>
      </div>`;
    document.querySelectorAll("#lab-tabs button").forEach(b => b.addEventListener("click", () => switchLabMode(b.dataset.lab)));
    setTimeout(() => switchLabMode("web"), 80);
  }
}

function switchLabMode(mode) {
  currentLabMode = mode;
  document.querySelectorAll("#lab-tabs button").forEach(b => b.classList.toggle("active", b.dataset.lab === mode));
  const labels = { web: "HTML / CSS / JS", js: "JavaScript (Console)", sql: "SQLite / Mini-SQL", python: "Python 3 (Pyodide)" };
  const lbl = document.getElementById("lab-lang-label"); if (lbl) lbl.textContent = labels[mode] || mode;
  const ed = document.getElementById("lab-editor");
  if (ed && typeof LAB_TEMPLATES !== "undefined") ed.value = LAB_TEMPLATES[mode] || "";
  const ifr = document.getElementById("lab-iframe"), con = document.getElementById("lab-console-out");
  if (ifr && con) { ifr.style.display = mode === "web" ? "block" : "none"; con.style.display = mode === "web" ? "none" : "block"; }
  clearLabOutput();
}

function resetLabTemplate() {
  const ed = document.getElementById("lab-editor");
  if (ed && typeof LAB_TEMPLATES !== "undefined") ed.value = LAB_TEMPLATES[currentLabMode] || "";
}
function clearLabOutput() {
  const ifr = document.getElementById("lab-iframe"), con = document.getElementById("lab-console-out");
  if (ifr) ifr.srcdoc = "<body style='background:#07090d;color:#94a3b8;font-family:sans-serif;padding:14px;'>Appuyez sur Exécuter pour voir le rendu...</body>";
  if (con) con.textContent = "En attente d'exécution...";
}

async function runLabCode() {
  const ed = document.getElementById("lab-editor"), out = document.getElementById("lab-console-out"), ifr = document.getElementById("lab-iframe");
  if (!ed) return;
  const code = ed.value;
  try { localStorage.setItem("jostech_lab_used", "1"); } catch (e) {}

  if (currentLabMode === "web") {
    if (ifr) ifr.srcdoc = code;
    if (typeof showToast === "function") showToast("Rendu Web mis à jour !");
    return;
  }
  if (currentLabMode === "js") {
    const logs = [];
    const fakeCon = { log: (...a) => logs.push(a.map(x => typeof x === "object" ? JSON.stringify(x) : String(x)).join(" ")), error: (...a) => logs.push("ERR: " + a.join(" ")) };
    try { new Function("console", code)(fakeCon); out.textContent = logs.length ? logs.join("\n") : "(Exécuté sans sortie)"; }
    catch (err) { out.textContent = "Erreur JS : " + err.message; }
    return;
  }
  if (currentLabMode === "sql") {
    out.textContent = typeof executeMiniSQL === "function" ? executeMiniSQL(code) : "Moteur SQL en chargement, réessayez.";
    return;
  }
  if (currentLabMode === "python") {
    if (!navigator.onLine) { out.textContent = "Hors connexion : Python (Pyodide) exige Internet au 1er lancement. HTML/CSS, JS et SQL marchent hors ligne !"; return; }
    out.textContent = "Chargement de Python (10-15 sec la 1re fois)...";
    try {
      if (!pyodideInstance) {
        if (typeof loadPyodide === "undefined") {
          await new Promise((ok, ko) => {
            const sc = document.createElement("script");
            sc.src = "https://cdn.jsdelivr.net/pyodide/v0.25.1/full/pyodide.js";
            sc.onload = ok; sc.onerror = ko; document.head.appendChild(sc);
          });
        }
        pyodideInstance = await loadPyodide();
      }
      await pyodideInstance.runPythonAsync("import sys, io\nsys.stdout = io.StringIO()\nsys.stderr = sys.stdout");
      await pyodideInstance.runPythonAsync(code);
      out.textContent = pyodideInstance.runPython("sys.stdout.getvalue()") || "(Exécuté sans sortie)";
    } catch (e) { out.textContent = "Erreur Python : " + (e.message || e); }
  }
}