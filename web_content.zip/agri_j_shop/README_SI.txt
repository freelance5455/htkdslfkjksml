Agri J Plant Nursery — වෙබ් අඩවිය / install කළ හැකි PWA ආකෘතිය

ඇතුළත් දේ:
- Sinhala mobile-friendly shop page
- පැළ සහ කරල්/එළවළු සඳහා demo products
- Cart එක සහ එකතුව ගණනය
- WhatsApp ඇණවුම් පණිවිඩය
- App icon, manifest, offline cache සඳහා service worker

වැදගත්:
1. දැනට ඇති මිල/නිෂ්පාදන උදාහරණ පමණි. index.html ගොනුවේ products ලැයිස්තුව සංස්කරණය කර ඔබේ සැබෑ මිල/තොග දාන්න.
2. Website එකේ Settings කොටසේ ඔබේ WhatsApp අංකය රටේ කේතය සමඟ (උදා: 94...) ඇතුළත් කරන්න.
3. ZIP එක unzip කළ පමණින් Android app එකක් ලෙස install වෙන්නේ නැහැ. Install කිරීමට website එක HTTPS සහිත hosting එකකට publish කළ යුතුයි. පසුව Android Chrome එකෙන් site එක විවෘත කර Install app / Add to Home screen තෝරන්න.
4. මෙය demo front-end එකකි; online payment, admin login, orders database හෝ live stock system එකක් තවම සම්බන්ධ කර නැත.
