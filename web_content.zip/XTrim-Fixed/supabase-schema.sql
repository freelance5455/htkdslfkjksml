-- XTRIM REVISED SCHEMA — EMAIL/PASSWORD ACCOUNTS + SIMPLE QR PAYMENT NOTICE
-- Run in Supabase SQL Editor. Safe to re-run for this project.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.appointments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  customer_name text not null,
  customer_phone text not null,
  service_name text not null,
  appointment_date date not null,
  appointment_time text not null,
  notes text,
  appointment_amount integer not null default 100 check (appointment_amount = 100),
  payment_status text not null default 'submitted' check (payment_status in ('submitted','verified','rejected')),
  booking_status text not null default 'pending' check (booking_status in ('pending','confirmed','cancelled')),
  created_at timestamptz not null default now()
);

-- Keep profiles in sync when an email/password account is created or updated.
create or replace function public.handle_new_xtrim_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id,email) values(new.id,new.email)
  on conflict (id) do update set email=excluded.email;
  return new;
end; $$;
drop trigger if exists on_auth_user_created_xtrim on auth.users;
create trigger on_auth_user_created_xtrim after insert or update of email on auth.users
for each row execute procedure public.handle_new_xtrim_user();

create or replace function public.is_xtrim_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.profiles where id=auth.uid() and role='admin');
$$;

alter table public.profiles enable row level security;
alter table public.appointments enable row level security;

drop policy if exists "profile read self or admin" on public.profiles;
create policy "profile read self or admin" on public.profiles for select to authenticated
using (id=auth.uid() or public.is_xtrim_admin());

drop policy if exists "customer insert own appointment" on public.appointments;
create policy "customer insert own appointment" on public.appointments for insert to authenticated
with check (user_id=auth.uid() and payment_status='submitted' and booking_status='pending' and appointment_amount=100);

drop policy if exists "customer read own or admin read all" on public.appointments;
create policy "customer read own or admin read all" on public.appointments for select to authenticated
using (user_id=auth.uid() or public.is_xtrim_admin());

drop policy if exists "admin update appointments" on public.appointments;
create policy "admin update appointments" on public.appointments for update to authenticated
using (public.is_xtrim_admin()) with check (public.is_xtrim_admin());

-- Promote Vinit only AFTER he creates an account and confirms his email.
-- Replace with Vinit's exact login email and run this statement:
-- update public.profiles set role='admin' where email='vinit@example.com';
-- Never allow public users to update their own role. Do not expose service_role keys.
