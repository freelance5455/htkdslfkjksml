# XTrim — fixed single-file frontend

This package embeds the CSS, JavaScript, Supabase public configuration, and supplied salon logo inside `index.html`. This prevents the unstyled-page issue caused by missing CSS or asset files.

## Files
- `index.html` — self-contained frontend (only Supabase JS and Google Fonts load from CDN).
- `supabase-schema.sql` — revised email/password account and appointment schema.
- `README.md` — setup and deployment notes.

## Setup
1. If the earlier schema was already run, use the migration instructions in the previously supplied revised README before applying schema changes.
2. Run `supabase-schema.sql` in Supabase SQL Editor.
3. Enable Email provider in Supabase Authentication.
4. Create Vinit's account through the app, confirm email if enabled, then promote him:
   `update public.profiles set role='admin' where email='vinit@example.com';`
5. Add the real payment QR image URL to `PAYMENT_QR_URL` near the bottom of `index.html`.
6. Deploy `index.html` to the website root on an HTTPS host. No separate CSS or logo files are required.

## Important
The "I HAVE PAID" button only submits a notification. Vinit must check his UPI/bank account and manually verify receipt before confirming the appointment. Never put a Supabase service_role key in frontend code.


## Separate admin-only page
- `admin.html` is a separate remote admin page.
- Vinit can open `https://YOUR-DOMAIN/admin.html` from any device and sign in.
- The page checks the signed-in user's `profiles.role` in Supabase; non-admin users are denied.
- The homepage also displays an Admin page shortcut only after the profile role is confirmed.
- Promote Vinit after his account exists: `update public.profiles set role='admin' where email='vinit@example.com';`
- The database Row Level Security policies remain the actual security boundary; hiding the page is not the security control.


## Payment QR
The supplied PhonePe/UPI QR image is included at `assets/xtrim-upi-qr.jpg` and configured in `index.html`. Before accepting payments, scan it with a UPI app and verify the displayed recipient/payee is the salon's intended account.
