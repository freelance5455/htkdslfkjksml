# Testing summary (v10.1.0)

## Done (automated, headless Chromium with touch emulation, plus Node)
- Boot of both scenarios without script errors; start screen scenario/mode/nation selection.
- Map: real coastlines, five map modes, tap on land picks a province, tap on sea picks a sea zone; screenshots reviewed.
- Armies, battles and conquest on both maps; ceasefire and peace; diplomacy; espionage; research and doctrines; food and farms (regression of earlier phases).
- Navy: shipbuilding, sailing, naval battles, blockades, amphibious landing, cargo in saves.
- Campaign: goals appear, victory by domination, end-date grades, defeat screen (Campaign) and defeat modal (Sandbox).
- Events: popup pauses the game, choices apply effects, historical events by date, pending events survive save/load.
- Saves: new fields round-trip; Phase 1-9 saves load as Sandbox.
- Soak: 4-6 simulated years on both maps at all AI difficulties without errors.

## Not done
- Not run on a physical Android phone or inside a built APK (only emulated touch and viewport sizes).
- No audio, no multiplayer, no localisation (English UI).
- Country borders in the Old World scenario are approximate (nearest-seed ownership); coastlines are real but simplified.
- Players who keep a very large game running at maximum speed on a slow phone may see the clock run slower than the selected speed.

## How to test on your phone
Open `index.html` in Chrome (landscape) or install the APK. Try: Old World -> Campaign -> any nation -> 🎯 (goals) -> press ▶ and answer the first event -> ⚓ build a ship -> declare war from the Country tab -> menu -> Save -> reload the page -> Load.
