# DreamyPlan source validation

Checks performed on this source package:

- JavaScript syntax check passed for the classic application script and Firebase module script using Node.js `--check`.
- No hardcoded default subject-name literals or default-subject arrays are present in the app source.
- Startup state initializes the active subject list to empty; it has no sample-task seeding or reset-to-default behavior.
- Add Task and Calendar handlers require a currently user-created subject.
- Subject edits preserve linked task dates/completion state; subject removal preserves historical task records and supports explicit reassignment.
- Account planner data is saved under `/users/{uid}/appData/state`, with Firestore rules requiring the same signed-in UID and verified email.
- Profile updates cannot change protected identity/username fields under the included rules; username reservation is checked by an atomic transaction and the matching index rule checks the paired profile using `getAfter`.

Live registration, duplicate-username race tests, email verification, password reset, Google OAuth, real Firestore access, cross-account isolation, and Cloud Function behavior still require your own Firebase project to be configured and deployed. These have not been claimed as live-tested.
