package com.adhi.cybersecurity

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.*
import android.graphics.Color
import android.view.ViewGroup
import android.util.TypedValue
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.MessageDigest
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import java.util.concurrent.Executor

class MainActivity : Activity() {
    private val bg = Color.rgb(8,9,14)
    private val red = Color.rgb(255,48,79)
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(20))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
        text("⬡  ADHI CYBER SECURITY", 23, red, true)
        text("CYBER RED · ANDROID EDITION", 11, Color.LTGRAY, false)
        text("Dashboard keamanan pribadi", 18, Color.WHITE, true)
        text("Fitur Android native dasar. Tidak melakukan pemindaian malware menyeluruh.", 13, Color.LTGRAY, false)
        card("APP LOCK / BIOMETRIC GATE", "Menguji autentikasi biometrik untuk membuka area terlindungi di aplikasi ini.") {
            button("Aktifkan pemeriksaan biometrik") { biometricGate() }
        }
        card("APK / FILE ANALYZER", "Pilih file melalui Android Storage Access Framework; aplikasi menghitung SHA-256 tanpa mengunggah file.") {
            button("Pilih file untuk hash SHA-256") {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                }
                startActivityForResult(i, 41)
            }
        }
        card("PRIVACY DASHBOARD", "Buka halaman pengaturan Android untuk meninjau izin dan privasi.") {
            button("Buka pengaturan privasi") { safeSettings(Settings.ACTION_PRIVACY_SETTINGS) }
            button("Buka daftar aplikasi") { safeSettings(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS) }
            button("Pengaturan keamanan") { safeSettings(Settings.ACTION_SECURITY_SETTINGS) }
        }
        card("WI-FI SECURITY AUDIT", "Checklist manual. Aplikasi biasa tidak dapat membaca password atau konfigurasi keamanan router.") {
            val labels = listOf("Router memakai WPA2-AES / WPA3", "Password Wi-Fi kuat dan unik", "WPS dimatikan bila tidak diperlukan", "Firmware router diperbarui", "Password admin router diganti")
            val checks = labels.map { CheckBox(this).apply { text = it; setTextColor(Color.WHITE) } }
            checks.forEach { root.addView(it) }
            button("Hitung checklist") { Toast.makeText(this, "${checks.count { it.isChecked }} dari 5 selesai", Toast.LENGTH_LONG).show() }
        }
        card("BACKUP SECURITY CHECKLIST", "Pengingat backup dan pemulihan akun.") {
            listOf("Backup data penting tersedia", "Email pemulihan diperbarui", "Verifikasi dua langkah aktif", "Kode pemulihan disimpan aman").forEach {
                root.addView(CheckBox(this).apply { text = it; setTextColor(Color.WHITE) })
            }
        }
        card("DEVELOPER DASHBOARD", "Informasi runtime aplikasi.") {
            button("Lihat diagnostik") {
                AlertDialogCompat.show(this, "Diagnostik", "Android: ${android.os.Build.VERSION.RELEASE}\nSDK: ${android.os.Build.VERSION.SDK_INT}\nDevice: ${android.os.Build.DEVICE}\nApp: 1.0")
            }
        }
        card("SECURITY REPORT", "Buat ringkasan dasar dan bagikan sebagai teks. PDF dapat dibuat melalui fitur cetak Android pada perangkat yang mendukungnya.") {
            button("Bagikan laporan") {
                val report = "ADHI CYBER SECURITY\\nTanggal: ${java.util.Date()}\\nPemeriksaan dilakukan secara manual. Bukan hasil pemindaian malware."
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, report), "Bagikan laporan"))
            }
        }
        card("SECURITY ALERTS", "Notifikasi real-time sistem membutuhkan layanan latar belakang dan izin khusus. Versi awal ini menampilkan pengingat manual.") {
            button("Tampilkan pengingat") { Toast.makeText(this, "Perbarui Android, tinjau izin aplikasi, dan aktifkan Google Play Protect.", Toast.LENGTH_LONG).show() }
        }
    }

    private fun biometricGate() {
        val executor: Executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                Toast.makeText(this@MainActivity, "Autentikasi berhasil untuk area aplikasi ini.", Toast.LENGTH_LONG).show()
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                Toast.makeText(this@MainActivity, "Autentikasi tidak tersedia: $errString", Toast.LENGTH_LONG).show()
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("ADHI CYBER SECURITY")
            .setSubtitle("Verifikasi untuk area terlindungi")
            .setNegativeButtonText("Batal")
            .build()
        prompt.authenticate(info)
    }

    private fun safeSettings(action: String) {
        try { startActivity(Intent(action)) } catch (_: Exception) {
            Toast.makeText(this, "Pengaturan tidak tersedia pada perangkat ini.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 41 && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri).use { stream ->
                    val digest = MessageDigest.getInstance("SHA-256")
                    val buffer = ByteArray(8192)
                    while (true) {
                        val n = stream?.read(buffer) ?: -1
                        if (n <= 0) break
                        digest.update(buffer, 0, n)
                    }
                    val hash = digest.digest().joinToString("") { "%02x".format(it) }
                    AlertDialogCompat.show(this, "File hash SHA-256", hash)
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Gagal membaca file: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun card(title: String, desc: String, content: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.rgb(22,24,35))
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(9), 0, dp(4))
        root.addView(box, lp)
        val t = TextView(this).apply { text = title; setTextColor(red); setTextSize(14f); setTypeface(null, 1) }
        box.addView(t)
        val d = TextView(this).apply { text = desc; setTextColor(Color.LTGRAY); setTextSize(12f); setPadding(0, dp(5), 0, dp(8)) }
        box.addView(d)
        val old = root
        // Temporarily direct card content views into the card container.
        root = box
        content()
        root = old
    }
    private fun text(s: String, size: Int, color: Int, bold: Boolean) {
        root.addView(TextView(this).apply { text = s; setTextColor(color); setTextSize(TypedValue.COMPLEX_UNIT_SP, size.toFloat()); if (bold) setTypeface(null, 1); setPadding(0, dp(5), 0, dp(4)) })
    }
    private fun button(s: String, action: () -> Unit) {
        root.addView(Button(this).apply { text = s; setTextColor(Color.WHITE); setBackgroundColor(red); setOnClickListener { action() } })
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
