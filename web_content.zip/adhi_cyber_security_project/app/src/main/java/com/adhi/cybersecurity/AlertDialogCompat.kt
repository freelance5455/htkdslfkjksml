package com.adhi.cybersecurity
import android.app.AlertDialog
import android.content.Context
object AlertDialogCompat {
    fun show(context: Context, title: String, message: String) {
        AlertDialog.Builder(context).setTitle(title).setMessage(message).setPositiveButton("OK", null).show()
    }
}
