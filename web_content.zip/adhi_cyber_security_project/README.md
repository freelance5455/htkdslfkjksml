# ADHI CYBER SECURITY

Paket berisi:
- `adhi_cyber_security.html`: dashboard HTML yang bisa dibuka langsung.
- Proyek Android Studio Kotlin: source APK native awal.

## Fitur yang benar-benar diimplementasikan
### HTML
- Pemeriksa kekuatan contoh password (berjalan lokal).
- Metadata file dan SHA-256 (bukan deteksi malware).
- Checklist audit Wi-Fi dan backup.
- Diagnostik browser.
- Laporan yang dapat dicetak / disimpan sebagai PDF melalui dialog cetak.
- Tautan percobaan ke pengaturan Android.

### Android native
- Gerbang autentikasi biometrik untuk area aplikasi ini (bukan mengunci aplikasi lain).
- Pemilih file Android dan perhitungan SHA-256.
- Shortcut ke pengaturan privasi, daftar aplikasi, dan keamanan.
- Checklist Wi-Fi dan backup.
- Diagnostik runtime dan berbagi laporan teks.

## Build APK
1. Buka folder proyek ini menggunakan Android Studio.
2. Tunggu Gradle Sync selesai.
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Android Studio akan menampilkan lokasi APK hasil build.

## Batasan keamanan
Aplikasi ini tidak mengklaim memindai malware secara menyeluruh, mengaudit router secara otomatis, mengunci aplikasi pihak ketiga, atau memantau sistem secara real-time. Fitur seperti pemantauan latar belakang memerlukan desain layanan Android, izin yang sesuai, dan pengujian tambahan. Jangan memasukkan password akun asli ke pemeriksa contoh.
