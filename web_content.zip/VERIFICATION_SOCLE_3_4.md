# Vérification technique — Socle 3.4

- Profil manager : création, validation, réputation et mode sans emploi couverts par tests.
- Navigation : huit destinations présentes, affichage à écran unique vérifié statiquement ; bouton CONTINUER global avec états contextuels et messages du conseil bloquants.
- Responsive : règles CSS paysage et portrait présentes.
- Sauvegarde : migration rétrocompatible des nouvelles données de carrière et options.
- Suite automatisée : 200 tests réussis, 0 échec.
- Syntaxe : `node --check` exécuté sur tous les fichiers JavaScript de `src/` et `tests/`.
- Moteurs préservés : comparaison binaire avec la Socle 3.3 des moteurs de règles, simulation, calendrier et huit compétitions ; aucun changement.
- Contrôle visuel navigateur : non effectué dans cette exécution ; à confirmer sur appareil mobile.

## Périmètre non encore livré
La boucle quotidienne unifiée, les offres d'emploi et candidatures, les finances détaillées, le staff/délégation, le conseil d'administration complet, les installations, la gestion avancée des arènes, le système de jeunes, le Hall of Fame et la cérémonie annuelle complète restent à construire dans des socles ultérieurs. La présence de leurs rubriques ou la conservation des moteurs existants ne signifie pas que ces fonctions sont déjà finalisées.
