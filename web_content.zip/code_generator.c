/*
 * ScanRec Studio – One-Time Code Generator (C)
 * Compile:  gcc -o code_gen code_generator.c
 * Run:      ./code_gen [TYPE] [USER_ID]
 *
 * Codes are one-time use. They expire the next calendar day.
 * Format:  TYP-XXXX-XXXX   (e.g. VIP-A3K9-P2M7)
 *
 * Premium contact (Pakistan): 0315-777-42662
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define CHARS "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
#define CHARLEN 32

void random_part(char *buf, int len) {
    for (int i = 0; i < len; i++)
        buf[i] = CHARS[rand() % CHARLEN];
    buf[len] = '\0';
}

void get_date(char *out, int days_ahead) {
    time_t t = time(NULL) + (time_t)days_ahead * 86400;
    struct tm *tm = localtime(&t);
    sprintf(out, "%04d-%02d-%02d",
            tm->tm_year + 1900, tm->tm_mon + 1, tm->tm_mday);
}

int main(int argc, char *argv[]) {
    const char *type = "VIP";
    const char *uid  = "any";

    if (argc >= 2) type = argv[1];
    if (argc >= 3) uid  = argv[2];

    srand((unsigned)time(NULL) ^ (unsigned)getpid());

    char prefix[8];
    strncpy(prefix, type, 3);
    prefix[3] = '\0';
    for (int i = 0; prefix[i]; i++)
        if (prefix[i] >= 'a' && prefix[i] <= 'z')
            prefix[i] -= 32;

    char p1[5], p2[5];
    random_part(p1, 4);
    random_part(p2, 4);

    char code[32];
    sprintf(code, "%s-%s-%s", prefix, p1, p2);

    char created[16], expires[16];
    get_date(created, 0);
    get_date(expires, 1);

    printf("========================================\n");
    printf("  ScanRec One-Time Code Generated\n");
    printf("========================================\n");
    printf("  Code     : %s\n", code);
    printf("  Type     : %s\n", type);
    printf("  User     : %s\n", uid);
    printf("  Created  : %s\n", created);
    printf("  Expires  : %s  (next day)\n", expires);
    printf("  Status   : ACTIVE – single use only\n");
    printf("========================================\n");
    printf("  Premium buy: 0315-777-42662 (PK)\n");
    printf("========================================\n");

    /* Simple local log (append) */
    FILE *f = fopen("codes_log.txt", "a");
    if (f) {
        fprintf(f, "%s|%s|%s|%s|%s|0\n", code, type, uid, created, expires);
        fclose(f);
        printf("  Logged to codes_log.txt\n");
    }

    return 0;
}
