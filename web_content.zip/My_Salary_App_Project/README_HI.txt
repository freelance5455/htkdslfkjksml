MY SALARY WALLET — HINDI QUICK GUIDE

1. index.html ko Android phone par Chrome mein open karein.
2. Settings & Backup mein salary mode Monthly chunein (default ₹12,000 aur 26 salary days hai).
3. OT rate aur Night allowance per hour apne workplace ke hisaab se set karke Save karein.
4. Attendance tab ya Dashboard par Present / Absent / Weekly Off, date, shift aur in/out time save karein.
5. Har attendance save ke baad app poore saved attendance aur conveyance records, salary summary, overtime aur night allowance ke saath CSV file automatically download karne ki koshish karegi. File ka naam MySalary-All-Records-YYYY-MM-DD.csv hoga.
6. Kisi selected month/year ki CSV chahiye to Reports mein period select karke “CSV report download” dabayein. CSV Excel aur Google Sheets mein khul sakti hai.
7. App ka data isi phone/browser ke local storage mein rehta hai. Data safe rakhne ke liye Settings & Backup mein JSON backup download karein. Browser data clear karne ya app ko doosre browser mein kholne par records nahin milenge jab tak JSON restore na karein.

IMPORTANT: Android/browser automatic download ko block ya confirm karwa sakta hai. Attendance save par app CSV download trigger karti hai, lekin phone/browser ki setting ke kaaran har device par silent auto-save guaranteed nahin hai. Agar file download na dikhe to Reports > CSV report download use karein. Browser ke Downloads folder mein file check karein.

This is an editable HTML app, not an APK.
