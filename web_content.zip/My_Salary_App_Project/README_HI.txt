MY SALARY APP - HINDI GUIDE

1. ZIP ko Android phone par download karein aur ZArchiver/File Manager se extract karein.
2. index.html ko browser mein kholein. Agar local file restrictions hon, to HTTPS hosting ki zaroorat ho sakti hai.
3. Settings & Backup tab kholein.
4. Salary type mein Daily salary ya Monthly salary chunein.
5. Monthly salary chunein to Monthly salary mein 12000 aur Salary days per month mein 26 rakhein.
   App daily equivalent ₹12000/26 = ₹461.54 se present pay aur absent deduction calculate karegi.
6. Overtime aur night allowance rates alag-alag configure karein.
7. Backup JSON download karke safe jagah rakhein. Browser data clear karne se local records delete ho sakte hain.

NOTE: Ye HTML web app project hai, Android APK nahi. APK ke liye alag build/export step chahiye.
