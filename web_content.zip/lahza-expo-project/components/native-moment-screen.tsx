import { Image } from "expo-image";
import { VideoView, useVideoPlayer } from "expo-video";
import { useAudioPlayer, useAudioPlayerStatus } from "expo-audio";
import { WebView } from "react-native-webview";
import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import type { NativeMoment } from "@/components/native-home-screen";

export type NativeComment = {
  id: string;
  parentId?: string | null;
  text: string;
  authorName?: string;
  createdAt?: string | number;
};

type Props = {
  mode: "story" | "moment";
  initialCommentsOpen?: boolean;
  moment: NativeMoment;
  storyMoments?: NativeMoment[];
  comments: NativeComment[];
  commentsLoading?: boolean;
  onClose: () => void;
  onOpenComments: (momentId: string) => void;
  onCloseComments: () => void;
  onSubmitComment: (text: string, parentId?: string | null) => Promise<void> | void;
  onLike: (momentId: string) => void;
  onStoryView: (momentId: string) => void;
  onShare: (momentId: string) => void;
  onOriginal: (momentId: string) => void;
};

const BG = "#050b14";
const PANEL = "#0b1b2b";

function NativeVideo({ uri }: { uri: string }) {
  const player = useVideoPlayer(uri, (instance) => {
    instance.loop = false;
    instance.play();
  });
  return <VideoView player={player} style={styles.video} contentFit="contain" nativeControls allowsFullscreen />;
}

function NativeAudio({ uri, title }: { uri: string; title?: string }) {
  const player = useAudioPlayer(uri);
  const status = useAudioPlayerStatus(player);
  const duration = Math.max(0, Number(status.duration || 0));
  const currentTime = Math.max(0, Number(status.currentTime || 0));
  const format = (seconds: number) => `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, "0")}`;
  return (
    <View style={styles.audioCard}>
      <Text style={styles.audioGlyph}>♫</Text>
      <Text numberOfLines={2} style={styles.audioTitle}>{title || "مقطع صوتي من لحظة"}</Text>
      <View style={styles.audioTrack}><View style={[styles.audioTrackFill, { width: `${duration ? Math.min(100, currentTime / duration * 100) : 0}%` }]} /></View>
      <View style={styles.audioControls}>
        <Text style={styles.audioTime}>{format(currentTime)} / {format(duration)}</Text>
        <View style={styles.audioButtons}>
          <Pressable onPress={() => player.seekTo(Math.max(0, currentTime - 10))} style={styles.audioSmallButton}><Text style={styles.audioControlText}>−10</Text></Pressable>
          <Pressable onPress={() => status.playing ? player.pause() : player.play()} style={styles.audioPlayButton}><Text style={styles.audioPlayText}>{status.playing ? "Ⅱ" : "▶"}</Text></Pressable>
          <Pressable onPress={() => player.seekTo(Math.min(duration || currentTime + 10, currentTime + 10))} style={styles.audioSmallButton}><Text style={styles.audioControlText}>+10</Text></Pressable>
        </View>
      </View>
      {status.isBuffering ? <ActivityIndicator color="#6ee7df" /> : null}
    </View>
  );
}

function socialEmbed(moment: NativeMoment): { uri?: string; html?: string; label: string } | null {
  const type = String(moment.mediaType || "").toLowerCase();
  const youtubeId = String(moment.youtubeId || "").trim();
  if ((type === "youtube" || youtubeId) && youtubeId) {
    const id = encodeURIComponent(youtubeId);
    return { label: "YouTube", html: `<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1"></head><body style="margin:0;background:#000"><iframe src="https://www.youtube-nocookie.com/embed/${id}?autoplay=1&playsinline=1&rel=0" title="YouTube video" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen style="position:absolute;inset:0;width:100%;height:100%;border:0"></iframe></body></html>` };
  }
  const telegram = String(moment.telegramPost || "").trim();
  if (type === "telegram" || telegram) {
    const post = telegram.replace(/^https?:\/\/(?:www\.)?t\.me\//i, "").replace(/[?#].*$/, "").replace(/^\/+|\/+$/g, "");
    return /^[A-Za-z0-9_]{4,}\/\d+$/.test(post) ? { label: "Telegram", uri: `https://t.me/${post}?embed=1` } : null;
  }
  const twitter = String(moment.twitterPost || "").trim();
  if (type === "twitter" || twitter) {
    const id = twitter.match(/(?:status|videos\/tweet)\/(\d+)/i)?.[1] || twitter.match(/(\d{8,})/)?.[1];
    return id ? { label: "X", uri: `https://x.com/i/videos/tweet/${id}` } : (twitter.startsWith("http") ? { label: "X", uri: twitter } : null);
  }
  const facebook = String(moment.facebookPost || "").trim();
  if (type === "facebook" || facebook) {
    const url = facebook.startsWith("http") ? facebook : "";
    try { const parsed = new URL(url); if (!["facebook.com", "m.facebook.com", "fb.watch"].includes(parsed.hostname.replace(/^www\./i, ""))) return null; } catch { return null; }
    return url ? { label: "Facebook", uri: `https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(url)}&show_text=false&autoplay=true` } : null;
  }
  const videoUrl = String(moment.videoUrl || "").trim();
  const daily = videoUrl.match(/(?:dailymotion\.com\/(?:video|embed\/video)\/|dai\.ly\/)([a-zA-Z0-9]+)/i);
  if (daily) return { label: "Dailymotion", uri: `https://www.dailymotion.com/embed/video/${daily[1]}` };
  if (videoUrl && /^https?:\/\//i.test(videoUrl) && !/\.(mp4|m3u8|mov|webm|m4v)(?:[?#]|$)/i.test(videoUrl)) return { label: "مشغل الويب", uri: videoUrl };
  return null;
}

function NativeSocialEmbed({ embed }: { embed: { uri?: string; html?: string; label: string } }) {
  return <View style={styles.embedFrame}><View style={styles.embedHeader}><Text style={styles.embedLabel}>مشغل {embed.label}</Text><Text style={styles.embedNativeTag}>مشغل مدمج</Text></View><WebView source={embed.html ? { html: embed.html, baseUrl: "https://www.youtube-nocookie.com" } : { uri: embed.uri! }} originWhitelist={["*"]} javaScriptEnabled domStorageEnabled mediaPlaybackRequiresUserAction={false} allowsInlineMediaPlayback allowsFullscreenVideo setSupportMultipleWindows={false} style={styles.embedWebView} /></View>;
}

function displayTime(value?: string | number) {
  if (!value) return "";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "" : date.toLocaleString("ar", { dateStyle: "medium", timeStyle: "short" });
}

export function NativeMomentScreen({
  mode, initialCommentsOpen = false, moment, storyMoments = [], comments, commentsLoading = false,
  onClose, onOpenComments, onCloseComments, onSubmitComment, onLike, onStoryView, onShare, onOriginal,
}: Props) {
  const sequence = useMemo(() => mode === "story" && storyMoments.length ? storyMoments : [moment], [mode, storyMoments, moment]);
  const [index, setIndex] = useState(Math.max(0, sequence.findIndex((item) => item.id === moment.id)));
  const [commentsOpen, setCommentsOpen] = useState(initialCommentsOpen);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [replyingTo, setReplyingTo] = useState<NativeComment | null>(null);
  const initialCommentsOpenedRef = useRef<string | null>(null);
  const current = sequence[Math.min(index, sequence.length - 1)] || moment;
  const candidateVideoUri = current.mediaType === "video" || current.mediaType === "video-link" ? current.videoUrl || "" : "";
  const audioUri = current.mediaType === "audio" ? current.audioUrl || current.videoUrl || "" : "";
  const videoUri = /\.(mp4|m3u8|mov|webm|m4v)(?:[?#]|$)/i.test(candidateVideoUri) ? candidateVideoUri : "";
  const embed = socialEmbed(current);
  const imageUri = current.storyImageUrl || current.imageUrl || current.posterUrl || current.thumbnailUrl || current.externalThumbnailUrl || current.youtubeThumbnailUrl || "";

  useEffect(() => {
    setIndex(Math.max(0, sequence.findIndex((item) => item.id === moment.id)));
  }, [moment.id, sequence]);
  useEffect(() => {
    if (mode === "story") onStoryView(current.id);
  }, [mode, current.id, onStoryView]);
  useEffect(() => {
    if (initialCommentsOpen && initialCommentsOpenedRef.current !== moment.id) {
      initialCommentsOpenedRef.current = moment.id;
      onOpenComments(moment.id);
    }
  }, [initialCommentsOpen, moment.id]);

  const openComments = () => {
    setCommentsOpen(true);
    onOpenComments(current.id);
  };
  const closeComments = () => {
    setCommentsOpen(false);
    setDraft("");
    onCloseComments();
  };
  const send = async () => {
    const value = draft.trim();
    if (!value || sending) return;
    setSending(true);
    try {
      await onSubmitComment(value, replyingTo?.id || null);
      setDraft("");
      setReplyingTo(null);
    } catch (error) {
      Alert.alert("تعذر نشر التعليق", error instanceof Error ? error.message : "حاول مرة أخرى");
    } finally {
      setSending(false);
    }
  };

  return (
    <View style={styles.root}>
      <View style={styles.header}>
        <Pressable onPress={commentsOpen ? closeComments : onClose} style={styles.close}><Text style={styles.closeText}>×</Text></Pressable>
        <View style={styles.headerCopy}>
          <Text style={styles.headerTitle}>{commentsOpen ? "التعليقات" : mode === "story" ? "القصص" : "تفاصيل اللحظة"}</Text>
          <Text style={styles.headerSub}>{current.displayName || "مستخدم لحظة"}{current.createdAt ? ` · ${displayTime(current.createdAt)}` : ""}</Text>
        </View>
        {commentsOpen ? null : <Pressable onPress={openComments} style={styles.headerComment}><Text style={styles.headerCommentText}>💬 {current.commentsCount || 0}</Text></Pressable>}
      </View>

      {commentsOpen ? (
        <KeyboardAvoidingView style={styles.commentsPane} behavior={Platform.OS === "ios" ? "padding" : undefined}>
          <ScrollView style={styles.commentsList} contentContainerStyle={styles.commentsContent} keyboardShouldPersistTaps="handled">
            {commentsLoading ? <ActivityIndicator color="#22c1c5" style={{ marginTop: 28 }} /> : null}
            {!commentsLoading && comments.length === 0 ? <Text style={styles.emptyComments}>لا توجد تعليقات بعد. كن أول من يعلّق على هذه اللحظة.</Text> : null}
            {comments.map((comment) => (
              <View key={comment.id} style={[styles.commentCard, comment.parentId ? styles.replyCard : null]}>
                <View style={styles.commentMeta}><Text style={styles.commentAuthor}>{comment.authorName || "زائر"}</Text><Text style={styles.commentTime}>{displayTime(comment.createdAt)}</Text></View>
                <Text style={styles.commentText}>{comment.text}</Text>
                <Pressable onPress={() => setReplyingTo(comment)} style={styles.replyButton}><Text style={styles.replyButtonText}>رد</Text></Pressable>
              </View>
            ))}
          </ScrollView>
          <View style={styles.composer}>
            {replyingTo ? <View style={styles.replyingBar}><Text style={styles.replyingText}>الرد على {replyingTo.authorName || "التعليق"}</Text><Pressable onPress={() => setReplyingTo(null)}><Text style={styles.replyingCancel}>إلغاء</Text></Pressable></View> : null}
            <TextInput
              value={draft}
              onChangeText={setDraft}
              placeholder="اكتب تعليقاً..."
              placeholderTextColor="#8ba9ba"
              style={styles.input}
              multiline
              maxLength={500}
              textAlign="right"
              editable={!sending}
            />
            <Pressable onPress={send} disabled={!draft.trim() || sending} style={[styles.sendButton, (!draft.trim() || sending) && styles.disabled]}>
              <Text style={styles.sendText}>{sending ? "…" : "إرسال"}</Text>
            </Pressable>
          </View>
        </KeyboardAvoidingView>
      ) : (
        <>
          <ScrollView style={styles.body} contentContainerStyle={styles.bodyContent} showsVerticalScrollIndicator={false}>
            <View style={styles.authorRow}>
              <View style={styles.avatar}>{current.profileImageUrl || current.avatarUrl ? <Image source={{ uri: current.profileImageUrl || current.avatarUrl }} style={styles.avatarImage} contentFit="cover" /> : <Text style={styles.avatarInitial}>{(current.displayName || "ل").slice(0, 1)}</Text>}</View>
              <View style={{ flex: 1 }}><Text style={styles.authorName}>{current.displayName || "مستخدم لحظة"}</Text><Text style={styles.authorTime}>{displayTime(current.createdAt)}</Text></View>
            </View>
            {videoUri ? <NativeVideo key={current.id} uri={videoUri} /> : audioUri ? <NativeAudio key={current.id} uri={audioUri} title={current.audioFileName || current.description || current.displayName} /> : embed ? <NativeSocialEmbed key={current.id} embed={embed} /> : imageUri ? <Image source={{ uri: imageUri }} style={styles.media} contentFit="contain" /> : <View style={styles.mediaFallback}><Text style={styles.fallbackIcon}>{current.mediaType === "audio" ? "🎙️" : current.mediaType === "text" ? "✍️" : "✨"}</Text></View>}
            {current.description || current.text ? <Text style={styles.description}>{current.description || current.text}</Text> : null}
            {((current.mediaType === "video" || current.mediaType === "video-link") && !videoUri && !embed) ? (
              <Pressable onPress={() => onOriginal(current.id)} style={styles.originalButton}><Text style={styles.originalText}>فتح الرابط الأصلي</Text></Pressable>
            ) : null}
            <View style={styles.actionRow}>
              <Pressable onPress={() => onLike(current.id)} style={styles.action}><Text style={styles.actionText}>♡ إعجاب · {current.likesCount || 0}</Text></Pressable>
              <Pressable onPress={openComments} style={styles.action}><Text style={styles.actionText}>💬 تعليق · {current.commentsCount || 0}</Text></Pressable>
              <Pressable onPress={() => onShare(current.id)} style={styles.action}><Text style={styles.actionText}>↗ مشاركة</Text></Pressable>
            </View>
          </ScrollView>
          {mode === "story" && sequence.length > 1 ? (
            <View style={styles.storyNav}>
              <Pressable disabled={index <= 0} onPress={() => setIndex((value) => Math.max(0, value - 1))} style={[styles.storyNavButton, index <= 0 && styles.disabled]}><Text style={styles.storyNavText}>السابق</Text></Pressable>
              <Text style={styles.storyCount}>{index + 1} / {sequence.length}</Text>
              <Pressable disabled={index >= sequence.length - 1} onPress={() => setIndex((value) => Math.min(sequence.length - 1, value + 1))} style={[styles.storyNavButton, index >= sequence.length - 1 && styles.disabled]}><Text style={styles.storyNavText}>التالي</Text></Pressable>
            </View>
          ) : null}
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { ...StyleSheet.absoluteFillObject, zIndex: 10, backgroundColor: BG },
  header: { minHeight: 68, paddingHorizontal: 14, paddingTop: 5, flexDirection: "row", alignItems: "center", gap: 12, borderBottomWidth: 1, borderBottomColor: "#1a3549" },
  close: { width: 40, height: 40, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: "#102536" },
  closeText: { color: "#fff", fontSize: 27, lineHeight: 30 },
  headerCopy: { flex: 1 }, headerTitle: { color: "#f4f9ff", fontSize: 16, fontWeight: "900", textAlign: "right" }, headerSub: { color: "#8da9bc", fontSize: 10, textAlign: "right", marginTop: 3 },
  headerComment: { borderRadius: 14, backgroundColor: "#10313b", paddingHorizontal: 12, paddingVertical: 10 }, headerCommentText: { color: "#a5efeb", fontWeight: "800" },
  body: { flex: 1 }, bodyContent: { padding: 15, paddingBottom: 30 }, authorRow: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 14 },
  avatar: { width: 43, height: 43, borderRadius: 24, overflow: "hidden", alignItems: "center", justifyContent: "center", backgroundColor: "#17384c" }, avatarImage: { width: "100%", height: "100%" }, avatarInitial: { color: "#fff", fontWeight: "900", fontSize: 18 }, authorName: { color: "#edf8ff", textAlign: "right", fontWeight: "900" }, authorTime: { color: "#85a3b7", textAlign: "right", fontSize: 10, marginTop: 3 },
  media: { width: "100%", height: 420, borderRadius: 20, backgroundColor: "#000" }, video: { width: "100%", height: 420, borderRadius: 20, backgroundColor: "#000" }, audioCard: { width: "100%", minHeight: 220, borderRadius: 20, padding: 20, justifyContent: "center", backgroundColor: "#0d2638", borderWidth: 1, borderColor: "#28506a" }, audioGlyph: { color: "#75e6dc", fontSize: 54, textAlign: "center" }, audioTitle: { color: "#e8f8ff", textAlign: "center", fontWeight: "900", marginTop: 8, marginBottom: 18 }, audioTrack: { height: 5, borderRadius: 8, backgroundColor: "#29475b", overflow: "hidden" }, audioTrackFill: { height: 5, borderRadius: 8, backgroundColor: "#20c7b7" }, audioControls: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 15 }, audioTime: { color: "#9bb8c9", fontSize: 11 }, audioButtons: { flexDirection: "row", alignItems: "center", gap: 10 }, audioSmallButton: { paddingHorizontal: 11, paddingVertical: 9, borderRadius: 11, backgroundColor: "#183c50" }, audioControlText: { color: "#c9f5f1", fontWeight: "900" }, audioPlayButton: { width: 48, height: 48, borderRadius: 24, backgroundColor: "#119b9b", alignItems: "center", justifyContent: "center" }, audioPlayText: { color: "#fff", fontSize: 20, fontWeight: "900" }, embedFrame: { width: "100%", height: 420, borderRadius: 20, overflow: "hidden", backgroundColor: "#000" }, embedHeader: { height: 34, paddingHorizontal: 11, flexDirection: "row", alignItems: "center", justifyContent: "space-between", backgroundColor: "#102536" }, embedLabel: { color: "#e8f8ff", fontSize: 11, fontWeight: "900" }, embedNativeTag: { color: "#76d9d0", fontSize: 10 }, embedWebView: { flex: 1, backgroundColor: "#000" }, mediaFallback: { minHeight: 210, borderRadius: 20, alignItems: "center", justifyContent: "center", backgroundColor: PANEL }, fallbackIcon: { fontSize: 58 },
  description: { color: "#e4f1f8", fontSize: 14, lineHeight: 25, textAlign: "right", marginTop: 15 }, originalButton: { marginTop: 15, borderRadius: 13, backgroundColor: "#114e63", padding: 13, alignItems: "center" }, originalText: { color: "#d7ffff", fontWeight: "900" },
  actionRow: { flexDirection: "row", gap: 10, marginTop: 18, paddingTop: 14, borderTopWidth: 1, borderTopColor: "#1a3549" }, action: { flex: 1, alignItems: "center", borderRadius: 13, backgroundColor: PANEL, padding: 13 }, actionText: { color: "#c4e5f0", fontSize: 12, fontWeight: "800" },
  storyNav: { padding: 12, flexDirection: "row", justifyContent: "space-between", alignItems: "center", borderTopWidth: 1, borderTopColor: "#1a3549" }, storyNavButton: { paddingHorizontal: 22, paddingVertical: 11, borderRadius: 12, backgroundColor: "#10313b" }, storyNavText: { color: "#b9f4ef", fontWeight: "900" }, storyCount: { color: "#9bb8c9", fontWeight: "800" }, disabled: { opacity: 0.35 },
  commentsPane: { flex: 1 }, commentsList: { flex: 1 }, commentsContent: { padding: 14, paddingBottom: 20, flexGrow: 1 }, emptyComments: { color: "#8da9bc", textAlign: "center", marginTop: 36, lineHeight: 24 }, commentCard: { borderRadius: 17, padding: 13, marginBottom: 11, backgroundColor: "#102638", borderWidth: 1, borderColor: "#23465d" }, replyCard: { marginRight: 22, borderRightWidth: 3, borderRightColor: "#25b8b1" }, commentMeta: { flexDirection: "row", justifyContent: "space-between", marginBottom: 8 }, commentAuthor: { color: "#8fe5dc", fontSize: 12, fontWeight: "900" }, commentTime: { color: "#8ba9ba", fontSize: 9 }, commentText: { color: "#e6f5fa", fontSize: 13, lineHeight: 22, textAlign: "right" },
  replyButton: { alignSelf: "flex-start", marginTop: 8, paddingHorizontal: 11, paddingVertical: 5, borderRadius: 9, backgroundColor: "#17384a" }, replyButtonText: { color: "#9fe9e2", fontSize: 11, fontWeight: "900" }, replyingBar: { position: "absolute", left: 12, right: 12, top: -35, height: 31, paddingHorizontal: 10, borderRadius: 10, backgroundColor: "#102536", flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, replyingText: { color: "#b4d5e3", fontSize: 10 }, replyingCancel: { color: "#9fe9e2", fontSize: 10, fontWeight: "900" },
  composer: { flexDirection: "row", alignItems: "flex-end", gap: 8, padding: 12, paddingBottom: Platform.OS === "android" ? 12 : 20, borderTopWidth: 1, borderTopColor: "#23465d", backgroundColor: "#071421" }, input: { flex: 1, minHeight: 44, maxHeight: 110, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 17, borderWidth: 1, borderColor: "#28506a", color: "#edf8ff", backgroundColor: "#102536", fontSize: 14 }, sendButton: { minWidth: 58, height: 44, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: "#118d91" }, sendText: { color: "#fff", fontWeight: "900", fontSize: 12 },
});
