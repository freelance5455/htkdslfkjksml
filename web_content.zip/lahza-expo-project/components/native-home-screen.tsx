import { Image } from "expo-image";
import React, { useMemo, useState } from "react";
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

export type NativeMoment = {
  id: string;
  groupKey?: string;
  displayName?: string;
  profileImageUrl?: string;
  avatarUrl?: string;
  mediaType?: string;
  imageUrl?: string;
  thumbnailUrl?: string;
  posterUrl?: string;
  externalThumbnailUrl?: string;
  youtubeThumbnailUrl?: string;
  youtubeId?: string;
  youtubeTitle?: string;
  youtubeIsShort?: boolean;
  telegramPost?: string;
  twitterPost?: string;
  facebookPost?: string;
  videoUrl?: string;
  audioUrl?: string;
  audioKind?: string;
  audioFileName?: string;
  storyImageUrl?: string;
  description?: string;
  text?: string;
  createdAt?: string;
  likesCount?: number;
  commentsCount?: number;
};
export type NativeStory = { key: string; name: string; image?: string; momentId: string; moments?: NativeMoment[] };
export type NativeHomeSnapshot = { stories: NativeStory[]; feed: NativeMoment[]; activeCount?: number; loading?: boolean };
type Props = {
  snapshot: NativeHomeSnapshot;
  onAction: (action: string, value?: string) => void;
};

const BG = "#050b14";
const CARD = "#091624";
const MUTED = "#91a7bb";

function mediaSource(item: NativeMoment) {
  return item.externalThumbnailUrl || item.youtubeThumbnailUrl || item.thumbnailUrl || item.posterUrl || item.imageUrl || (item.youtubeId ? `https://img.youtube.com/vi/${encodeURIComponent(item.youtubeId)}/mqdefault.jpg` : "");
}
function timeAgo(value?: string) {
  if (!value) return "لحظة جديدة";
  const time = new Date(value).getTime();
  if (!Number.isFinite(time)) return "لحظة جديدة";
  const minutes = Math.max(0, Math.floor((Date.now() - time) / 60000));
  if (minutes < 1) return "الآن";
  if (minutes < 60) return `قبل ${minutes} د`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `قبل ${hours} س`;
  return `قبل ${Math.floor(hours / 24)} ي`;
}

export function NativeHomeScreen({ snapshot, onAction }: Props) {
  const [filter, setFilter] = useState("all");
  const feed = useMemo(
    () => filter === "all" ? snapshot.feed : snapshot.feed.filter((item) => item.mediaType === filter),
    [filter, snapshot.feed],
  );
  const chooseFilter = (next: string) => {
    setFilter(next);
    onAction("filter", next);
  };

  return (
    <View style={styles.root}>
      <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.topbar}>
          <Text style={styles.logo}>لحظة <Text style={styles.logoVersion}>2.0</Text></Text>
          <View style={styles.topActions}>
            <Pressable onPress={() => onAction("favorites")} style={styles.iconButton}><Text style={styles.iconText}>♡</Text></Pressable>
            <Pressable onPress={() => onAction("settings")} style={styles.iconButton}><Text style={styles.iconText}>⚙</Text></Pressable>
          </View>
        </View>

        <View style={styles.hero}>
          <Text style={styles.heroKicker}>✨ عالم لحظة</Text>
          <Text style={styles.heroTitle}>اكتشف لحظتك.</Text>
          <Text style={styles.heroBody}>شاهد الجديد، واستكشف الأشخاص واللحظات والمتاجر التي تستحق وقتك.</Text>
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chips}>
          <FilterChip label="الكل" active={filter === "all"} onPress={() => chooseFilter("all")} />
          <FilterChip label="📷 صور" active={filter === "image"} onPress={() => chooseFilter("image")} />
          <FilterChip label="🎙️ صوت" active={filter === "audio"} onPress={() => chooseFilter("audio")} />
          <Pressable style={[styles.chip, styles.storeChip]} onPress={() => onAction("stores")}><Text style={styles.chipText}>🛍️ متاجر</Text></Pressable>
        </ScrollView>

        <View style={styles.section}>
          <View style={styles.sectionHeading}>
            <Text style={styles.sectionTitle}>🟢 نشط الآن</Text>
            <Text style={styles.sectionCount}>{snapshot.activeCount ?? snapshot.stories.length} أشخاص</Text>
          </View>
          {snapshot.stories.length ? (
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.stories}>
              {snapshot.stories.map((story) => (
                <Pressable key={story.key} style={styles.story} onPress={() => onAction("story", story.key)}>
                  <View style={styles.storyRing}>
                    <View style={styles.storyFace}>
                      {story.image ? <Image source={{ uri: story.image }} style={styles.storyImage} contentFit="cover" /> : <Text style={styles.storyInitial}>{story.name.slice(0, 1) || "ل"}</Text>}
                    </View>
                  </View>
                  <Text numberOfLines={1} style={styles.storyName}>{story.name}</Text>
                </Pressable>
              ))}
            </ScrollView>
          ) : <Text style={styles.emptyStories}>كن أول شخص يشارك الآن 🔥</Text>}
        </View>

        <View style={[styles.section, styles.feedHeading]}>
          <Text style={styles.sectionTitle}>✨ أحدث اللحظات</Text>
          <Text style={styles.sectionCount}>{feed.length} لحظة</Text>
        </View>

        {feed.length ? feed.map((item) => <FeedCard key={item.id} item={item} onAction={onAction} />) : (
          <View style={styles.emptyFeed}>
            <Text style={styles.emptyTitle}>{snapshot.loading ? "جاري تحميل اللحظات…" : "✨ ما في لحظات ظاهرة الآن"}</Text>
            {!snapshot.loading ? <Text style={styles.emptyText}>انشر أول لحظة وخلي الناس يشوفوا وش يصير حولك.</Text> : null}
          </View>
        )}
        <View style={{ height: 18 }} />
      </ScrollView>

      <View style={styles.bottomBar}>
        <NavItem label="الرئيسية" glyph="⌂" active onPress={() => onAction("home")} />
        <NavItem label="الدردشات" glyph="▤" onPress={() => onAction("chats")} />
        <Pressable style={styles.addButton} onPress={() => onAction("add")}><Text style={styles.addText}>+</Text></Pressable>
        <NavItem label="اكتشف" glyph="✦" onPress={() => onAction("discover")} />
        <NavItem label="ملفي" glyph="◉" onPress={() => onAction("profile")} />
      </View>
    </View>
  );
}

function FilterChip({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  return <Pressable onPress={onPress} style={[styles.chip, active && styles.activeChip]}><Text style={[styles.chipText, active && styles.activeChipText]}>{label}</Text></Pressable>;
}
function NavItem({ label, glyph, active, onPress }: { label: string; glyph: string; active?: boolean; onPress: () => void }) {
  return <Pressable onPress={onPress} style={styles.navItem}><Text style={[styles.navGlyph, active && styles.navActive]}>{glyph}</Text><Text style={[styles.navLabel, active && styles.navActive]}>{label}</Text></Pressable>;
}
function FeedCard({ item, onAction }: { item: NativeMoment; onAction: (action: string, value?: string) => void }) {
  const name = item.displayName || "مستخدم لحظة";
  const media = mediaSource(item);
  const type = String(item.mediaType || "image").toLowerCase();
  const textOnly = type === "text" || (!media && !!(item.description || item.text));
  return (
    <View style={styles.feedCard}>
      <Pressable style={styles.feedHeader} onPress={() => onAction("moment", item.id)}>
        <View style={styles.avatar}>
          {item.profileImageUrl || item.avatarUrl ? <Image source={{ uri: item.profileImageUrl || item.avatarUrl }} style={styles.avatarImage} contentFit="cover" /> : <Text style={styles.avatarInitial}>{name.slice(0, 1)}</Text>}
        </View>
        <View style={styles.feedMeta}>
          <Text style={styles.feedName} numberOfLines={1}>{name}</Text>
          <Text style={styles.feedTime}>{timeAgo(item.createdAt)} · لحظة جديدة</Text>
        </View>
        <Text style={styles.more}>⋯</Text>
      </Pressable>
      <Pressable style={[styles.mediaBox, textOnly && styles.textMedia]} onPress={() => onAction("moment", item.id)}>
        {media ? <Image source={{ uri: media }} style={styles.mediaImage} contentFit="cover" /> : <Text style={styles.mediaPlaceholder}>{type === "audio" ? "🎙️" : type === "video" ? "🎬" : "✨"}</Text>}
        {type === "video" || type === "video-link" || type === "youtube" || type === "twitter" || type === "telegram" || type === "facebook" ? <View style={styles.playBadge}><Text style={styles.playText}>▶</Text></View> : null}
        {textOnly ? <Text style={styles.momentDescription}>{item.description || item.text}</Text> : null}
        {!textOnly && item.description ? <Text numberOfLines={3} style={styles.mediaCaption}>{item.description}</Text> : null}
      </Pressable>
      <View style={styles.actions}>
        <Pressable onPress={() => onAction("like", item.id)} style={styles.actionButton}><Text style={styles.actionText}>♡ <Text style={styles.actionCount}>{item.likesCount || 0}</Text></Text></Pressable>
        <Pressable onPress={() => onAction("comments", item.id)} style={styles.actionButton}><Text style={styles.actionText}>💬 <Text style={styles.actionCount}>{item.commentsCount || 0}</Text></Text></Pressable>
        <Pressable onPress={() => onAction("moment", item.id)} style={styles.actionButton}><Text style={styles.actionText}>▶ مشاهدة</Text></Pressable>
        <View style={{ flex: 1 }} />
        <Text style={styles.actionText}>🔖</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: BG },
  scroll: { flex: 1 },
  content: { paddingBottom: 92 },
  topbar: { height: 68, paddingHorizontal: 16, flexDirection: "row", alignItems: "center", justifyContent: "space-between", backgroundColor: "rgba(5,11,20,0.97)", borderBottomWidth: 1, borderBottomColor: "#142a3d" },
  logo: { color: "#f5f9ff", fontSize: 24, fontWeight: "900" },
  logoVersion: { color: "#25b5ff", fontSize: 14 },
  topActions: { flexDirection: "row", gap: 8 },
  iconButton: { width: 40, height: 40, borderRadius: 22, backgroundColor: "#0d1e30", borderWidth: 1, borderColor: "#1a3850", alignItems: "center", justifyContent: "center" },
  iconText: { color: "#dcecff", fontSize: 21 },
  hero: { margin: 14, borderRadius: 26, paddingVertical: 21, paddingHorizontal: 18, backgroundColor: "#172548", borderWidth: 1, borderColor: "#245276" },
  heroKicker: { color: "#83d5ff", fontSize: 12, fontWeight: "900", textAlign: "right" },
  heroTitle: { color: "#f5f9ff", fontSize: 27, fontWeight: "900", textAlign: "right", marginTop: 7 },
  heroBody: { color: "#c5d8e8", fontSize: 12, lineHeight: 20, textAlign: "right", marginTop: 5 },
  chips: { paddingHorizontal: 14, gap: 8, paddingBottom: 4, flexDirection: "row-reverse" },
  chip: { borderWidth: 1, borderColor: "#1d3b55", backgroundColor: "#0b1a2a", borderRadius: 22, paddingVertical: 9, paddingHorizontal: 14 },
  chipText: { color: "#b8c9d9", fontSize: 12, fontWeight: "800" },
  activeChip: { backgroundColor: "#2762a9", borderColor: "transparent" },
  activeChipText: { color: "#fff" },
  storeChip: { borderColor: "#245b68", backgroundColor: "#0b2b35" },
  section: { paddingHorizontal: 14, marginTop: 17 },
  sectionHeading: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 10 },
  sectionTitle: { color: "#f5f9ff", fontSize: 18, fontWeight: "900", textAlign: "right" },
  sectionCount: { color: "#69c7ff", fontSize: 11 },
  stories: { flexDirection: "row-reverse", gap: 11, paddingBottom: 5 },
  story: { width: 72, alignItems: "center" },
  storyRing: { width: 62, height: 62, padding: 3, borderRadius: 32, backgroundColor: "#20b7ff", alignItems: "center", justifyContent: "center" },
  storyFace: { width: 56, height: 56, borderRadius: 28, backgroundColor: "#13263a", borderWidth: 2, borderColor: BG, alignItems: "center", justifyContent: "center", overflow: "hidden" },
  storyImage: { width: "100%", height: "100%" },
  storyInitial: { color: "#fff", fontSize: 23, fontWeight: "900" },
  storyName: { color: "#9eb1c2", fontSize: 10, marginTop: 5, maxWidth: 70 },
  emptyStories: { color: "#8196a9", fontSize: 12, paddingVertical: 8, textAlign: "right" },
  feedHeading: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 10 },
  feedCard: { marginHorizontal: 14, marginBottom: 14, borderWidth: 1, borderColor: "#17354d", borderRadius: 23, backgroundColor: CARD, overflow: "hidden" },
  feedHeader: { flexDirection: "row-reverse", alignItems: "center", gap: 9, padding: 12 },
  avatar: { width: 42, height: 42, borderRadius: 22, backgroundColor: "#3156a0", alignItems: "center", justifyContent: "center", overflow: "hidden" },
  avatarImage: { width: "100%", height: "100%" },
  avatarInitial: { color: "#fff", fontWeight: "900", fontSize: 18 },
  feedMeta: { flex: 1, alignItems: "flex-start" },
  feedName: { color: "#f5f9ff", fontSize: 13, fontWeight: "800", textAlign: "right" },
  feedTime: { color: "#7891a7", fontSize: 10, marginTop: 3, textAlign: "right" },
  more: { color: "#8ca2b7", fontSize: 21 },
  mediaBox: { height: 300, backgroundColor: "#15283a", alignItems: "center", justifyContent: "center", overflow: "hidden" },
  mediaImage: { width: "100%", height: "100%" },
  mediaPlaceholder: { color: "#fff", fontSize: 64 },
  playBadge: { position: "absolute", width: 54, height: 54, borderRadius: 28, backgroundColor: "rgba(5,15,25,0.75)", borderWidth: 2, borderColor: "#fff", alignItems: "center", justifyContent: "center" },
  playText: { color: "#fff", fontSize: 21 },
  textMedia: { height: 190, backgroundColor: "#102236", padding: 18 },
  momentDescription: { color: "#f4f8fc", fontSize: 16, fontWeight: "700", textAlign: "right", lineHeight: 27 },
  mediaCaption: { position: "absolute", bottom: 0, right: 0, left: 0, padding: 12, color: "#fff", fontSize: 13, fontWeight: "700", textAlign: "right", backgroundColor: "rgba(0,0,0,0.48)" },
  actions: { flexDirection: "row-reverse", alignItems: "center", gap: 18, paddingHorizontal: 13, paddingVertical: 11 },
  actionButton: { paddingVertical: 2 },
  actionText: { color: "#c5d2df", fontSize: 13 },
  actionCount: { color: "#fff", fontWeight: "800" },
  emptyFeed: { marginHorizontal: 14, marginTop: 4, padding: 28, borderWidth: 1, borderStyle: "dashed", borderColor: "#29465d", borderRadius: 20, alignItems: "center" },
  emptyTitle: { color: "#e8f3ff", fontWeight: "900", marginBottom: 6 },
  emptyText: { color: MUTED, fontSize: 12, textAlign: "center" },
  bottomBar: { position: "absolute", left: 0, right: 0, bottom: 0, height: 78, zIndex: 5, flexDirection: "row", alignItems: "center", justifyContent: "space-around", backgroundColor: "rgba(5,12,21,0.98)", borderTopWidth: 1, borderTopColor: "#183247", paddingBottom: 5 },
  navItem: { width: 64, alignItems: "center", justifyContent: "center" },
  navGlyph: { color: "#7890a5", fontSize: 22, lineHeight: 26 },
  navLabel: { color: "#7890a5", fontSize: 10, fontWeight: "800" },
  navActive: { color: "#3dbbff" },
  addButton: { width: 58, height: 58, marginTop: -27, borderRadius: 30, borderWidth: 4, borderColor: "#08121e", backgroundColor: "#2879d8", alignItems: "center", justifyContent: "center" },
  addText: { color: "#fff", fontSize: 31, lineHeight: 34 },
});
