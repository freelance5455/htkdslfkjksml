// Load environment variables with proper priority (system > .env)
import "./scripts/load-env.js";
import type { ExpoConfig } from "expo/config";

// Bundle ID format: space.manus.<project_name_dots>.<timestamp>
// e.g., "my-app" created at 2024-01-15 10:30:45 -> "space.manus.my.app.t20240115103045"
// Bundle ID can only contain letters, numbers, and dots
// Android requires each dot-separated segment to start with a letter
const rawBundleId = "com.app.lahzadebugapp";
const bundleId =
  rawBundleId
    .replace(/[-_]/g, ".") // Replace hyphens/underscores with dots
    .replace(/[^a-zA-Z0-9.]/g, "") // Remove invalid chars
    .replace(/\.+/g, ".") // Collapse consecutive dots
    .replace(/^\.+|\.+$/g, "") // Trim leading/trailing dots
    .toLowerCase()
    .split(".")
    .map((segment) => {
      // Android requires each segment to start with a letter
      // Prefix with 'x' if segment starts with a digit
      return /^[a-zA-Z]/.test(segment) ? segment : "x" + segment;
    })
    .join(".") || "space.manus.app";
// Extract timestamp from bundle ID and prefix with "manus" for deep link scheme
// e.g., "space.manus.my.app.t20240115103045" -> "manus20240115103045"
const timestamp = bundleId.split(".").pop()?.replace(/^t/, "") ?? "";
const schemeFromBundleId = `manus${timestamp}`;

const env = {
  // App branding - update these values directly (do not use env vars)
  appName: "لحظة",
  appSlug: "lahza",
  // Durable project metadata logo URL; native bundle assets remain local below.
  logoUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663925613227/zhRPAaCuPAfXNboS.png",
  scheme: schemeFromBundleId,
  iosBundleId: bundleId,
  androidPackage: bundleId,
};

const config: ExpoConfig = {
  name: env.appName,
  slug: env.appSlug,
  version: "1.2.1",
  orientation: "portrait",
  icon: "./assets/images/icon.png",
  scheme: [env.scheme, env.androidPackage],
  userInterfaceStyle: "automatic",
  newArchEnabled: true,
  jsEngine: "hermes",
  ios: {
    supportsTablet: true,
    bundleIdentifier: env.iosBundleId,
    "infoPlist": {
        "ITSAppUsesNonExemptEncryption": false,
        "NSCameraUsageDescription": "يحتاج لحظة إلى الكاميرا لنشر الصور والفيديو.",
        "NSMicrophoneUsageDescription": "يحتاج لحظة إلى الميكروفون لتسجيل الصوت والفيديو.",
        "NSPhotoLibraryUsageDescription": "يحتاج لحظة إلى الصور لاختيار الوسائط ونشرها.",
      }
  },
  android: {
    adaptiveIcon: {
      backgroundColor: "#E6F4FE",
      foregroundImage: "./assets/images/android-icon-foreground.png",
      backgroundImage: "./assets/images/android-icon-background.png",
      monochromeImage: "./assets/images/android-icon-monochrome.png",
    },
    edgeToEdgeEnabled: true,
    predictiveBackGestureEnabled: false,
    softwareKeyboardLayoutMode: "resize",
    package: env.androidPackage,
    googleServicesFile: "./google-services.json",
    versionCode: 14,
    permissions: [
      "POST_NOTIFICATIONS",
      "CAMERA",
      "RECORD_AUDIO",
      "READ_MEDIA_IMAGES",
      "READ_MEDIA_VIDEO"
    ],
    intentFilters: [
      {
        action: "VIEW",
        autoVerify: true,
        data: [
          {
            scheme: env.scheme,
            host: "*",
          },
        ],
        category: ["BROWSABLE", "DEFAULT"],
      },
      {
        action: "VIEW",
        data: [
          {
            scheme: env.androidPackage,
            pathPrefix: "/oauthredirect",
          },
        ],
        category: ["BROWSABLE", "DEFAULT"],
      },
      {
        action: "VIEW",
        autoVerify: false,
        data: [
          {
            scheme: "https",
            host: "lahzaweb-ydgdsdwh.manus.space",
            pathPrefix: "/",
          },
        ],
        category: ["BROWSABLE", "DEFAULT"],
      },
    ],
  },
  web: {
    bundler: "metro",
    output: "static",
    favicon: "./assets/images/favicon.png",
  },
  plugins: [
    "expo-router",
    "react-native-nitro-google-signin",
    ["expo-notifications", { icon: "./assets/images/android-icon-foreground.png", color: "#0f766e", defaultChannel: "interactions" }],
    ["expo-image-picker", { "photosPermission": "اسمح لتطبيق لحظة بالوصول إلى الصور والفيديوهات." }],
    ["expo-share-intent", { disableIOS: true, androidIntentFilters: ["text/*", "image/*", "video/*", "audio/*"], androidMultiIntentFilters: ["image/*", "video/*", "audio/*"] }],
    ["expo-media-library", { "photosPermission": "اسمح لتطبيق لحظة بحفظ المقاطع في الاستديو.", "savePhotosPermission": "اسمح لتطبيق لحظة بحفظ المقاطع في الاستديو." }],
    [
      "expo-audio",
      {
        microphonePermission: "اسمح لتطبيق لحظة باستخدام الميكروفون لتسجيل الرسائل الصوتية.",
      },
    ],
    [
      "expo-video",
      {
        supportsBackgroundPlayback: true,
        supportsPictureInPicture: true,
      },
    ],
    [
      "expo-splash-screen",
      {
        image: "./assets/images/splash-icon.png",
        imageWidth: 200,
        resizeMode: "contain",
        backgroundColor: "#ffffff",
      },
    ],
    [
      "expo-build-properties",
      {
        android: {
          buildArchs: ["arm64-v8a"],
          minSdkVersion: 24,
          compileSdkVersion: 36,
          targetSdkVersion: 36,
        },
      },
    ],
  ],
  experiments: {
    typedRoutes: true,
    reactCompiler: true,
  },
  extra: {
    eas: {
      projectId: "90dfb4bf-31f1-4e6f-82bf-a150bc4809d6",
    },
  },
};

export default config;
