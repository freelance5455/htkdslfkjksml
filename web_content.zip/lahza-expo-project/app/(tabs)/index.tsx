import { useCallback, useEffect, useRef, useState } from "react";
import { ActivityIndicator, BackHandler, DeviceEventEmitter, Keyboard, Linking, Platform, StyleSheet, ToastAndroid, View } from "react-native";
import { WebView, type WebViewMessageEvent } from "react-native-webview";
import { useFocusEffect } from "expo-router";
import * as ImagePicker from "expo-image-picker";
import { GoogleOneTapSignIn, isNoSavedCredentialFoundResponse, isSuccessResponse } from "@/lib/google-signin";
import * as MediaLibrary from "expo-media-library";
import * as Notifications from "expo-notifications";
import { AudioModule, RecordingPresets, setAudioModeAsync, useAudioRecorder } from "expo-audio";
import * as FileSystem from "expo-file-system/legacy";

import { ScreenContainer } from "@/components/screen-container";
import { NativeHomeScreen, type NativeHomeSnapshot, type NativeMoment } from "@/components/native-home-screen";
import { NativeMomentScreen, type NativeComment } from "@/components/native-moment-screen";
import { LAHZA_HTML_BASE64 } from "../../assets/lahza-html";

const WebViewComponent = WebView as any;
const LAHZA_HTML = decodeURIComponent(escape(atob(LAHZA_HTML_BASE64)));
Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowAlert: true, shouldShowBanner: true, shouldShowList: true, shouldPlaySound: true, shouldSetBadge: true }),
});
export default function HomeScreen() {
  const webViewRef = useRef<WebView>(null);
  const googlePromptInProgressRef = useRef(false);
  const [isLoading, setIsLoading] = useState(true);
  const [nativeHomeVisible, setNativeHomeVisible] = useState(false);
  const [nativeHomeSnapshot, setNativeHomeSnapshot] = useState<NativeHomeSnapshot>({ stories: [], feed: [], activeCount: 0 });
  const [nativeMomentScreen, setNativeMomentScreen] = useState<{ mode: "story" | "moment"; moment: NativeMoment; stories?: NativeMoment[]; openComments?: boolean } | null>(null);
  const [nativeComments, setNativeComments] = useState<NativeComment[]>([]);
  const [nativeCommentsLoading, setNativeCommentsLoading] = useState(false);
  const nativeAudioRecorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const nativeAudioRecordingRef = useRef(false);
  const webViewLoadedRef = useRef(false);
  const nativeBackSequenceRef = useRef(0);
  const lastRootBackPressRef = useRef(0);
  const pendingNativeBackRef = useRef<number | null>(null);
  const nativeBackTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pendingSharedMomentRef = useRef<string | null>(null);
  const pendingShareIntentsRef = useRef<any[]>([]);
  const pendingNativeCommentResolveRef = useRef<((success: boolean) => void) | null>(null);
  const pendingNativeCommentTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    try {
      GoogleOneTapSignIn.configure({
        webClientId: "573200937902-6l9ejlqdrpf2buiukfc1pav3i3rgu9eh.apps.googleusercontent.com",
        scopes: ["email", "profile"],
        autoSelectOnSignIn: false,
      });
    } catch (error) {
      console.warn("تعذر تهيئة تسجيل Google الأصلي:", error);
    }
  }, []);


  const deliverPendingShareIntents = async () => {
    if (!webViewLoadedRef.current || !webViewRef.current || !pendingShareIntentsRef.current.length) return;
    const queue = pendingShareIntentsRef.current.splice(0);
    for (const intent of queue) {
      try {
        const text = String(intent?.text || intent?.webUrl || "").trim();
        if (text) {
          webViewRef.current?.injectJavaScript(`window.__receiveNativeShareIntent?.(${JSON.stringify({ text, webUrl: intent?.webUrl || "" })}); true;`);
        }
        const sharedFiles = Array.isArray(intent?.files) ? intent.files : [];
        for (let fileIndex = 0; fileIndex < sharedFiles.length; fileIndex++) {
          const file = sharedFiles[fileIndex];
          const uri = String(file?.path || file?.uri || "");
          if (!uri) continue;
          const size = Number(file?.size || 0);
          const mimeType = String(file?.mimeType || file?.mime || "application/octet-stream");
          const maxBytes = mimeType.startsWith("video/") ? 20 * 1024 * 1024 : 35 * 1024 * 1024;
          if (size > maxBytes) {
            webViewRef.current?.injectJavaScript(`window.showCustomToast?.(${JSON.stringify(mimeType.startsWith("video/") ? "حجم الفيديو المشارك يتجاوز 20 ميجابايت" : "الملف المشارك كبير جداً؛ اختر ملفاً أصغر")}); true;`);
            continue;
          }
          try {
            const base64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
            const id = `share-${Date.now()}-${fileIndex}`;
            const meta = { name: file?.fileName || file?.name || (mimeType.startsWith("video/") ? "shared-video.mp4" : mimeType.startsWith("audio/") ? "shared-audio.m4a" : "shared-image.jpg"), mime: mimeType, mimeType };
            const chunkSize = 256 * 1024;
            const total = Math.ceil(base64.length / chunkSize);
            webViewRef.current?.injectJavaScript(`window.__receiveNativeShareFileStart?.(${JSON.stringify(id)},${JSON.stringify(meta)},${total}); true;`);
            for (let index = 0; index < total; index++) {
              const chunk = base64.slice(index * chunkSize, (index + 1) * chunkSize);
              webViewRef.current?.injectJavaScript(`window.__receiveNativeShareFileChunk?.(${JSON.stringify(id)},${index},${JSON.stringify(chunk)}); true;`);
            }
          } catch {
            webViewRef.current?.injectJavaScript(`window.showCustomToast?.(${JSON.stringify("تعذر قراءة الملف الذي تمت مشاركته")}); true;`);
          }
        }
      } catch {
        webViewRef.current?.injectJavaScript("window.showCustomToast?.('تعذر استقبال المشاركة؛ حاول مرة أخرى'); true;");
      }
    }
  };

  useEffect(() => {
    const receive = (intent: any) => {
      if (!intent) return;
      if ((globalThis as any).__LAHZA_PENDING_SHARE_INTENT__ === intent) delete (globalThis as any).__LAHZA_PENDING_SHARE_INTENT__;
      pendingShareIntentsRef.current.push(intent);
      void deliverPendingShareIntents();
    };
    const subscription = DeviceEventEmitter.addListener("lahza-share-intent", receive);
    const pending = (globalThis as any).__LAHZA_PENDING_SHARE_INTENT__;
    if (pending) {
      delete (globalThis as any).__LAHZA_PENDING_SHARE_INTENT__;
      receive(pending);
    }
    return () => subscription.remove();
  }, []);

  useEffect(() => {
    const deliverSharedMoment = (url: string | null) => {
      if (!url) return;
      try {
        const parsed = new URL(url);
        const id = parsed.searchParams.get("moment");
        if (!id) return;
        pendingSharedMomentRef.current = id;
        if (webViewLoadedRef.current) {
          webViewRef.current?.injectJavaScript(`window.__openSharedMoment?.(${JSON.stringify(id)}); true;`);
          pendingSharedMomentRef.current = null;
        }
      } catch { /* ignore unrelated links */ }
    };
    void Linking.getInitialURL().then(deliverSharedMoment);
    const subscription = Linking.addEventListener("url", ({ url }) => deliverSharedMoment(url));
    return () => subscription.remove();
  }, []);
  useEffect(() => {
    const prepareNotifications = async () => {
      try {
        if (Platform.OS === "android") {
          await Notifications.setNotificationChannelAsync("interactions", { name: "تفاعلات اللحظات", importance: Notifications.AndroidImportance.DEFAULT, sound: "default" });
        }
        const permissions = await Notifications.getPermissionsAsync();
        if (permissions.status !== "granted") await Notifications.requestPermissionsAsync();
      } catch {
        // Notifications are optional; the in-app notification stream remains available.
      }
    };
    void prepareNotifications();
  }, []);

  useFocusEffect(
    useCallback(() => {
      const subscription = BackHandler.addEventListener("hardwareBackPress", () => {
        // أولوية الرجوع للشاشات الأصلية قبل إرسال الطلب إلى صفحة HTML.
        if (nativeMomentScreen) {
          webViewRef.current?.injectJavaScript("window.__lahzaNativeCloseComments?.(); true;");
          setNativeMomentScreen(null);
          setNativeComments([]);
          setNativeHomeVisible(true);
          lastRootBackPressRef.current = 0;
          return true;
        }
        if (nativeHomeVisible) {
          setNativeHomeVisible(false);
          lastRootBackPressRef.current = 0;
          return true;
        }

        const webView = webViewRef.current;
        if (!webView || !webViewLoadedRef.current) {
          const now = Date.now();
          if (now - lastRootBackPressRef.current < 2000) return false;
          lastRootBackPressRef.current = now;
          if (Platform.OS === "android") ToastAndroid.show("اضغط مرة أخرى للخروج", ToastAndroid.SHORT);
          return true;
        }
        if (pendingNativeBackRef.current !== null) return true;

        const requestId = ++nativeBackSequenceRef.current;
        pendingNativeBackRef.current = requestId;
        if (nativeBackTimeoutRef.current) clearTimeout(nativeBackTimeoutRef.current);
        nativeBackTimeoutRef.current = setTimeout(() => {
          if (pendingNativeBackRef.current === requestId) pendingNativeBackRef.current = null;
          nativeBackTimeoutRef.current = null;
        }, 1200);

        try {
          webView.injectJavaScript(
            `(function(){var requestId=${requestId};var handled=false;try{handled=typeof window.handleNativeBack==='function'?window.handleNativeBack()!==false:false;}catch(e){handled=false;}try{window.ReactNativeWebView?.postMessage(JSON.stringify({type:handled?'native-back-handled':'native-back-root',requestId:requestId}));}catch(e){}})(); true;`,
          );
          return true;
        } catch {
          pendingNativeBackRef.current = null;
          if (nativeBackTimeoutRef.current) clearTimeout(nativeBackTimeoutRef.current);
          nativeBackTimeoutRef.current = null;
          return false;
        }
      });
      const showKeyboard = Keyboard.addListener("keyboardDidShow", (event) => {
        const height = Math.max(0, Math.round(event.endCoordinates?.height ?? 0));
        webViewRef.current?.injectJavaScript(
          `if(window.__lahzaKeyboardDidShow){window.__lahzaKeyboardDidShow(${height});}else{document.documentElement.style.setProperty('--lahza-keyboard-height','${height}px');} true;`,
        );
      });
      const hideKeyboard = Keyboard.addListener("keyboardDidHide", () => {
        webViewRef.current?.injectJavaScript(
          "if(window.__lahzaKeyboardDidHide){window.__lahzaKeyboardDidHide();}else{document.documentElement.style.setProperty('--lahza-keyboard-height','0px');} true;",
        );
      });
      return () => {
        subscription.remove();
        showKeyboard.remove();
        hideKeyboard.remove();
        if (nativeBackTimeoutRef.current) clearTimeout(nativeBackTimeoutRef.current);
        nativeBackTimeoutRef.current = null;
        pendingNativeBackRef.current = null;
      };
    }, [nativeHomeVisible, nativeMomentScreen]),
  );

  const handleMessage = async (event: WebViewMessageEvent) => {
    try {
      const message = JSON.parse(event.nativeEvent.data);
      if (message?.type === "lahza-native-comments-snapshot") {
        const nextComments = Array.isArray(message.comments) ? message.comments : [];
        setNativeComments(nextComments);
        setNativeCommentsLoading(false);
        setNativeMomentScreen((current) => current ? { ...current, moment: { ...current.moment, commentsCount: Math.max(current.moment.commentsCount || 0, nextComments.length) } } : current);
        return;
      }
      if (message?.type === "lahza-native-comment-submit-result") {
        if (pendingNativeCommentTimeoutRef.current) clearTimeout(pendingNativeCommentTimeoutRef.current);
        pendingNativeCommentTimeoutRef.current = null;
        pendingNativeCommentResolveRef.current?.(message.success === true);
        pendingNativeCommentResolveRef.current = null;
        return;
      }
      if (message?.type === "lahza-native-comments-loading") {
        setNativeCommentsLoading(true);
        setNativeComments([]);
        return;
      }
      if (message?.type === "lahza-native-home-snapshot" && message.snapshot) {
        const nextSnapshot = message.snapshot as NativeHomeSnapshot;
        setNativeHomeSnapshot(nextSnapshot);
        setNativeMomentScreen((current) => {
          if (!current) return current;
          const refreshed = nextSnapshot.feed.find((item) => item.id === current.moment.id) || current.stories?.find((item) => item.id === current.moment.id);
          return refreshed ? { ...current, moment: refreshed, stories: current.stories?.map((item) => item.id === refreshed.id ? refreshed : item) } : current;
        });
        setNativeHomeVisible(true);
        return;
      }
      if (message?.type === "lahza-native-home-show") {
        setNativeHomeVisible(true);
        return;
      }
      if (message?.type === "lahza-native-home-hide") {
        setNativeHomeVisible(false);
        return;
      }
      if (message?.type === "request-google-signin") {
        if (!googlePromptInProgressRef.current) {
          googlePromptInProgressRef.current = true;
          try {
            await GoogleOneTapSignIn.checkPlayServices();
            let response = await GoogleOneTapSignIn.signIn();
            if (isNoSavedCredentialFoundResponse(response)) response = await GoogleOneTapSignIn.createAccount();
            if (isNoSavedCredentialFoundResponse(response)) response = await GoogleOneTapSignIn.presentExplicitSignIn();
            const idToken = isSuccessResponse(response) ? response.data?.idToken : (response as any)?.data?.idToken;
            if (idToken) {
              webViewRef.current?.injectJavaScript(`window.__completeNativeGoogleSignIn?.(${JSON.stringify(idToken)}); true;`);
            } else {
              const responseType = String((response as any)?.type || "");
              const message = responseType === "cancelled"
                ? "تم إلغاء تسجيل الدخول بحساب Google."
                : "لم يصل رمز Google من الحساب المختار. تحقق من إعدادات Google وأعد المحاولة.";
              webViewRef.current?.injectJavaScript(`window.__nativeGoogleSignInFailed?.(${JSON.stringify(message)}); true;`);
            }
          } catch (error) {
            console.warn("Native Google sign-in failed:", error);
            webViewRef.current?.injectJavaScript("window.__nativeGoogleSignInFailed?.('تعذر فتح اختيار حساب Google. تحقق من إعدادات Google وأعد بناء التطبيق.'); true;");
          } finally {
            googlePromptInProgressRef.current = false;
          }
        }
        return;
      }
      if (message?.type === "native-back-handled" || message?.type === "native-back-root") {
        const pendingId = pendingNativeBackRef.current;
        if (pendingId !== null && message.requestId != null && Number(message.requestId) !== pendingId) return;
        if (pendingId !== null) pendingNativeBackRef.current = null;
        if (nativeBackTimeoutRef.current) clearTimeout(nativeBackTimeoutRef.current);
        nativeBackTimeoutRef.current = null;
        if (message.type === "native-back-root") {
          const now = Date.now();
          if (now - lastRootBackPressRef.current < 2000) {
            lastRootBackPressRef.current = 0;
            BackHandler.exitApp();
          } else {
            lastRootBackPressRef.current = now;
            if (Platform.OS === "android") ToastAndroid.show("اضغط مرة أخرى للخروج", ToastAndroid.SHORT);
          }
        } else {
          lastRootBackPressRef.current = 0;
        }
        return;
      }
      if (message?.type === "open-external-url" && typeof message.url === "string") {
        const url = message.url;
        if (/^(tel:|https:\/\/wa\.me\/|https:\/\/api\.whatsapp\.com\/)/i.test(url)) {
          try {
            await Linking.openURL(url);
          } catch {
            webViewRef.current?.injectJavaScript("window.__externalUrlFailed?.(); true;");
          }
        }
      }
      if (message?.type === "download-video-to-gallery" && typeof message.url === "string") {
        try {
          const permission = await MediaLibrary.requestPermissionsAsync();
          if (!permission.granted) throw new Error("تم رفض إذن حفظ الفيديو في الاستديو");
          const safeName = String(message.filename || `lahza-${Date.now()}.mp4`).replace(/[^a-zA-Z0-9._-]/g, "_");
          const target = `${FileSystem.cacheDirectory || FileSystem.documentDirectory}${safeName}`;
          const result = await FileSystem.downloadAsync(message.url, target);
          await MediaLibrary.createAssetAsync(result.uri);
          webViewRef.current?.injectJavaScript("window.showCustomToast?.('تم حفظ المقطع في الاستديو'); true;");
        } catch (error) {
          webViewRef.current?.injectJavaScript(
            `window.showCustomToast?.(${JSON.stringify(error instanceof Error ? error.message : "تعذر حفظ المقطع في الاستديو")}); true;`,
          );
        }
      }
      if (message?.type === "interaction-notification" && typeof message.body === "string") {
        await Notifications.scheduleNotificationAsync({
          content: { title: "لحظة", body: message.body, sound: "default" },
          trigger: null,
        });
      }
      if (message?.type === "request-profile-image") {
        const result = await ImagePicker.launchImageLibraryAsync({
          mediaTypes: ["images"],
          allowsEditing: true,
          aspect: [1, 1],
          quality: 0.88,
          base64: true,
          exif: false,
        });
        if (!result.canceled && result.assets?.[0]?.base64) {
          const asset = result.assets[0];
          const payload = JSON.stringify({
            base64: asset.base64,
            mimeType: asset.mimeType || "image/jpeg",
            fileName: asset.fileName || "lahza-profile.jpg",
          });
          webViewRef.current?.injectJavaScript(
            `window.__receiveNativeProfileImage?.(${payload}); true;`,
          );
        }
      }
      if (message?.type === "request-chat-image") {
        const result = await ImagePicker.launchImageLibraryAsync({
          mediaTypes: ["images"],
          allowsEditing: false,
          quality: 0.68,
          base64: true,
          exif: false,
        });
        if (!result.canceled && result.assets?.[0]?.base64) {
          const asset = result.assets[0];
          const payload = JSON.stringify({
            base64: asset.base64,
            mimeType: asset.mimeType || "image/jpeg",
            fileName: asset.fileName || "lahza-photo.jpg",
          });
          webViewRef.current?.injectJavaScript(
            `window.__receiveNativeChatImage?.(${payload}); true;`,
          );
        }
      }
      if (message?.type === "start-native-chat-audio") {
        try {
          const permission = await AudioModule.requestRecordingPermissionsAsync();
          if (!permission.granted) throw new Error("تم رفض إذن الميكروفون");
          await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true });
          await nativeAudioRecorder.prepareToRecordAsync();
          nativeAudioRecorder.record();
          nativeAudioRecordingRef.current = true;
          webViewRef.current?.injectJavaScript("window.__nativeAudioStarted?.(); true;");
        } catch (error) {
          nativeAudioRecordingRef.current = false;
          webViewRef.current?.injectJavaScript(
            `window.__nativeAudioCancelled?.(); window.showCustomToast?.(${JSON.stringify(error instanceof Error ? error.message : "تعذر بدء التسجيل")}); true;`,
          );
        }
      }
      if (message?.type === "stop-native-chat-audio") {
        if (nativeAudioRecordingRef.current) {
          try {
            await nativeAudioRecorder.stop();
            nativeAudioRecordingRef.current = false;
            await setAudioModeAsync({ allowsRecording: false, playsInSilentMode: true });
            const uri = nativeAudioRecorder.uri;
            if (!uri) throw new Error("لم يتم حفظ ملف التسجيل");
            const base64 = await FileSystem.readAsStringAsync(uri, {
              encoding: FileSystem.EncodingType.Base64,
            });
            const payload = JSON.stringify({ base64, mimeType: "audio/mp4", fileName: "lahza-voice.m4a" });
            webViewRef.current?.injectJavaScript(
              `window.__receiveNativeChatAudio?.(${payload}); true;`,
            );
          } catch (error) {
            nativeAudioRecordingRef.current = false;
            webViewRef.current?.injectJavaScript(
              `window.__nativeAudioCancelled?.(); window.showCustomToast?.(${JSON.stringify(error instanceof Error ? error.message : "تعذر إرسال التسجيل")}); true;`,
            );
          }
        }
      }
      if (message?.type === "request-media-library-permission") {
        const result = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (result.granted) {
          webViewRef.current?.injectJavaScript("window.__openStudioAfterPermission?.(); window.__openStudioAfterPermission=null; true;");
        }
      }
      if (message?.type === "request-camera-permission") {
        const result = await ImagePicker.requestCameraPermissionsAsync();
        if (result.granted) {
          webViewRef.current?.injectJavaScript("window.__openCameraAfterPermission?.(); window.__openCameraAfterPermission=null; true;");
        }
      }

    } catch {
      // Ignore ordinary page messages.
    }
  };

  const handleNativeHomeAction = (action: string, value?: string) => {
    if (action === "home") return;
    if (action === "filter") {
      webViewRef.current?.injectJavaScript(`window.filterL2Feed?.(${JSON.stringify(value || "all")},null); true;`);
      return;
    }
    if (action === "story") {
      const group = nativeHomeSnapshot.stories.find((item) => item.key === value);
      const sequence = group?.moments || [];
      const first = sequence[0] || nativeHomeSnapshot.feed.find((item) => item.id === group?.momentId);
      if (first) setNativeMomentScreen({ mode: "story", moment: first, stories: sequence.length ? sequence : [first] });
      return;
    }
    if (action === "moment" || action === "comments") {
      const moment = nativeHomeSnapshot.feed.find((item) => item.id === value);
      if (moment) {
        setNativeMomentScreen({ mode: "moment", moment, openComments: action === "comments" });
        if (action === "comments") setNativeCommentsLoading(true);
      }
      return;
    }
    setNativeHomeVisible(false);
    const commands: Record<string, string> = {
      favorites: "window.openFavoritesModal?.();",
      settings: "window.openSettingsModal?.();",
      chats: "window.openLahzaChats?.();",
      discover: "window.l2Go?.('discover');",
      profile: "window.openOwnL2Profile?.();",
      add: "window.openMomentCreationFlow?.();",
      stores: "window.openNearbyStoresModal?.();",
    };
    if (action === "like") {
      webViewRef.current?.injectJavaScript(`window.toggleLikeFromFeed?.(${JSON.stringify(value || "")},null); true;`);
      return;
    }
    const command = commands[action];
    if (command) setTimeout(() => webViewRef.current?.injectJavaScript(`${command} true;`), 80);
  };

  const closeNativeMomentScreen = () => {
    webViewRef.current?.injectJavaScript("window.__lahzaNativeCloseComments?.(); true;");
    setNativeMomentScreen(null);
    setNativeComments([]);
    setNativeHomeVisible(true);
  };
  const openNativeComments = (momentId: string) => {
    setNativeCommentsLoading(true);
    setNativeComments([]);
    webViewRef.current?.injectJavaScript(`window.__lahzaNativeOpenComments?.(${JSON.stringify(momentId)}); true;`);
  };
  const submitNativeComment = async (text: string, parentId?: string | null) => {
    await new Promise<void>((resolve, reject) => {
      if (pendingNativeCommentResolveRef.current) pendingNativeCommentResolveRef.current(false);
      pendingNativeCommentResolveRef.current = (success) => success ? resolve() : reject(new Error("تعذر نشر التعليق"));
      pendingNativeCommentTimeoutRef.current = setTimeout(() => {
        pendingNativeCommentResolveRef.current = null;
        pendingNativeCommentTimeoutRef.current = null;
        reject(new Error("انتهت مهلة إرسال التعليق"));
      }, 15000);
      webViewRef.current?.injectJavaScript(`window.__lahzaNativeSubmitComment?.(${JSON.stringify(text)},${JSON.stringify(parentId || null)}); true;`);
    });
  };
  const closeNativeComments = () => webViewRef.current?.injectJavaScript("window.__lahzaNativeCloseComments?.(); true;");
  const likeNativeMoment = (momentId: string) => webViewRef.current?.injectJavaScript(`window.toggleLikeFromFeed?.(${JSON.stringify(momentId)},null); true;`);
  const viewNativeStoryMoment = (momentId: string) => webViewRef.current?.injectJavaScript(`window.__lahzaNativeViewStory?.(${JSON.stringify(momentId)}); true;`);
  const shareNativeMoment = (momentId: string) => webViewRef.current?.injectJavaScript(`window.shareLahzaMomentExternal?.(${JSON.stringify(momentId)}); true;`);
  const openOriginalMoment = (momentId: string) => {
    setNativeMomentScreen(null);
    setNativeHomeVisible(false);
    webViewRef.current?.injectJavaScript(`window.openL2MomentById?.(${JSON.stringify(momentId)},false); true;`);
  };

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]} containerClassName="bg-white">
      <View style={styles.container}>
        {isLoading ? (
          <View style={styles.loading}>
            <ActivityIndicator size={32} color="#0f766e" />
          </View>
        ) : null}
        <WebViewComponent
          ref={webViewRef}
          source={{ html: LAHZA_HTML, baseUrl: "https://lahza.local/" }}
          originWhitelist={["*"]}
          javaScriptEnabled
          domStorageEnabled
          mediaPlaybackRequiresUserAction={false}
          allowsInlineMediaPlayback
          allowsFullscreenVideo
          mixedContentMode="always"
          sharedCookiesEnabled
          thirdPartyCookiesEnabled
          setSupportMultipleWindows={false}
          startInLoadingState
          cacheEnabled
          cacheMode="LOAD_DEFAULT"
          incognito={false}
          onLoadStart={() => { webViewLoadedRef.current = false; }}
          onLoadEnd={() => {
            webViewLoadedRef.current = true;
            setIsLoading(false);
            webViewRef.current?.injectJavaScript("window.__lahzaEmitNativeHomeSnapshot?.(); true;");
            void deliverPendingShareIntents();
            if (pendingSharedMomentRef.current) {
              const id = pendingSharedMomentRef.current;
              webViewRef.current?.injectJavaScript(`window.__openSharedMoment?.(${JSON.stringify(id)}); true;`);
              pendingSharedMomentRef.current = null;
            }
          }}
          onMessage={handleMessage}
          pointerEvents={nativeHomeVisible ? "none" : "auto"}
          style={[styles.webview, nativeHomeVisible && styles.webviewHidden]}
        />
        {nativeHomeVisible ? (
          <View style={styles.nativeHomeLayer}>
            <NativeHomeScreen snapshot={nativeHomeSnapshot} onAction={handleNativeHomeAction} />
          </View>
        ) : null}
        {nativeMomentScreen ? (
          <NativeMomentScreen
            mode={nativeMomentScreen.mode}
            initialCommentsOpen={nativeMomentScreen.openComments}
            moment={nativeMomentScreen.moment}
            storyMoments={nativeMomentScreen.stories}
            comments={nativeComments}
            commentsLoading={nativeCommentsLoading}
            onClose={closeNativeMomentScreen}
            onOpenComments={openNativeComments}
            onCloseComments={closeNativeComments}
            onSubmitComment={submitNativeComment}
            onLike={likeNativeMoment}
            onStoryView={viewNativeStoryMoment}
            onShare={shareNativeMoment}
            onOriginal={openOriginalMoment}
          />
        ) : null}
      </View>
    </ScreenContainer>
);
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#ffffff" },
  webview: { flex: 1, backgroundColor: "#ffffff" },
  webviewHidden: { ...StyleSheet.absoluteFillObject, opacity: 0 },
  nativeHomeLayer: { ...StyleSheet.absoluteFillObject, zIndex: 3, backgroundColor: "#050b14" },
  loading: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 2,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#ffffff",
  },
});
