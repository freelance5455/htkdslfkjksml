import type { CookieOptions, Request, RequestHandler } from "express";
import { parse as parseCookieHeader } from "cookie";
import { LEGACY_COOKIE_NAME, SESSION_COOKIE_SUFFIX } from "../../shared/const.js";

const LOCAL_HOSTS = new Set(["localhost", "127.0.0.1", "::1"]);

function isIpAddress(host: string) {
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) return true;
  return host.includes(":");
}

function isSecureRequest(req: Request) {
  if (req.protocol === "https") return true;
  const forwardedProto = req.headers["x-forwarded-proto"];
  if (!forwardedProto) return false;
  const protoList = Array.isArray(forwardedProto) ? forwardedProto : forwardedProto.split(",");
  return protoList.some((proto) => proto.trim().toLowerCase() === "https");
}

function shouldUseSecureCookie(req: Request) {
  const hostname = req.hostname;
  if (LOCAL_HOSTS.has(hostname) || isIpAddress(hostname)) return isSecureRequest(req);
  // Public Preview and published HTTPS requests can reach the app over internal HTTP.
  return true;
}

function configuredPreviewApiHostname(): string | null {
  const packagerOrigin = process.env.EXPO_PACKAGER_PROXY_URL;
  if (!packagerOrigin) return null;
  try {
    const url = new URL(packagerOrigin);
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    const apiHostname = url.hostname.replace(/^8081-/, "3000-");
    return apiHostname === url.hostname ? null : apiHostname;
  } catch {
    return null;
  }
}

function isRecognizedPreviewApiHost(req: Request) {
  return configuredPreviewApiHostname() === req.hostname;
}

function getParentDomain(hostname: string): string | undefined {
  if (LOCAL_HOSTS.has(hostname) || isIpAddress(hostname)) return undefined;
  const parts = hostname.split(".");
  if (parts.length < 3) return undefined;
  return "." + parts.slice(-2).join(".");
}

export function getSessionCookieName(req: Request): string {
  return isSecureRequest(req)
    ? `__Host-manus_session_${SESSION_COOKIE_SUFFIX}`
    : `manus_local_session_${SESSION_COOKIE_SUFFIX}`;
}

export function getSessionCookieOptions(
  req: Request,
): Pick<CookieOptions, "httpOnly" | "path" | "sameSite" | "secure"> {
  return {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: shouldUseSecureCookie(req),
  };
}

export function getLegacySessionCookieOptions(
  req: Request,
): Pick<CookieOptions, "domain" | "httpOnly" | "path" | "sameSite" | "secure"> {
  const domain = isRecognizedPreviewApiHost(req) ? getParentDomain(req.hostname) : undefined;
  return {
    domain,
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: shouldUseSecureCookie(req),
  };
}

export function currentSessionCookie(req: Request): string | undefined {
  const cookies = parseCookieHeader(req.headers.cookie ?? "");
  return cookies[getSessionCookieName(req) as keyof typeof cookies];
}

export function clearLegacySessionCookie(): RequestHandler {
  return (req, res, next) => {
    if (isRecognizedPreviewApiHost(req)) {
      res.clearCookie(LEGACY_COOKIE_NAME, {
        ...getLegacySessionCookieOptions(req),
        maxAge: -1,
      });
    }
    next();
  };
}
