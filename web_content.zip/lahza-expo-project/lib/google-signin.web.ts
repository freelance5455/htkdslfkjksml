export const GoogleOneTapSignIn = {
  configure() {
    // Web uses the existing OAuth portal flow instead of the native Google module.
  },
  async checkPlayServices() {
    throw new Error("Native Google Sign-In is only available on Android and iOS");
  },
  async signIn() {
    throw new Error("Native Google Sign-In is only available on Android and iOS");
  },
  async createAccount() {
    throw new Error("Native Google Sign-In is only available on Android and iOS");
  },
  async presentExplicitSignIn() {
    throw new Error("Native Google Sign-In is only available on Android and iOS");
  },
};

export function isNoSavedCredentialFoundResponse(_response: unknown): boolean {
  return false;
}

export function isSuccessResponse(_response: unknown): boolean {
  return false;
}
