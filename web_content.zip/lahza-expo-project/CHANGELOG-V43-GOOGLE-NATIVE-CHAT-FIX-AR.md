# لحظة V43 — تسجيل Google الأصلي وإصلاح فتح الدردشات

- استبدال `expo-auth-session` في مسار تسجيل Google داخل الشاشة الرئيسية بمكتبة `react-native-nitro-google-signin` التي تعتمد على Google Credential Manager في Android.
- تمرير `idToken` الناتج إلى WebView لإكمال تسجيل الدخول عبر Firebase Authentication.
- إضافة config plugin والتبعيات المطلوبة في `app.config.ts` و`package.json` ونسخة package المضمّنة في `template.json`.
- تحسين نافذة الدخول لتطلب اختيار حساب Google الموجود على الهاتف.
- السماح بتسجيل الدخول إلى حساب Google الموجود إذا تعذّر ربط بيانات الاعتماد بالحساب المجهول الحالي.
- إصلاح عناصر قائمة الدردشات الفردية لتستخدم `data-lahza-chat-person` ومستمع click صريح بدل inline onclick.
- إصلاح مقطع مكرر في `app.config.ts` كان يمنع تحليل الملف.

## تحقق

- تم فحص صياغة 38 كتلة JavaScript مضمّنة في HTML بنجاح.
- لم يكتمل فحص TypeScript لأن حزم المشروع غير مثبتة في بيئة العمل الحالية.
- يلزم تشغيل `pnpm install` ثم إعادة بناء APK فعليًا؛ لا يمكن إضافة وحدات Native إلى APK موجود بمجرد تحديث HTML.
