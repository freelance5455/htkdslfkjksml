#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
src="$root/assets/lahza-source.html"
out="$root/assets/lahza-html.ts"
encoded="$(base64 -w0 "$src")"
printf 'export const LAHZA_HTML_BASE64 = "%s";\n' "$encoded" > "$out"
