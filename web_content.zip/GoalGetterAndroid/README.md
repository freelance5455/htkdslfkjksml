# Goal Getter — Android wrapper

This project packages the original Goal Getter PWA from the supplied ZIP as a native Android WebView app.

The original `index.html`, `manifest.webmanifest`, `sw.js`, `worker.js`, and `HOW-TO-INSTALL.txt` are copied unchanged into `app/src/main/assets/goal-getter/`.

## Build

Open the project in Android Studio and build `app`.

The resulting APK is a wrapper around the original PWA; it does not recreate the UI.
