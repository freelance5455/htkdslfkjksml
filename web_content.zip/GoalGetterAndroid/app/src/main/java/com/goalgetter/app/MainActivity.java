package com.goalgetter.app;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String APP_URL = "file:///android_asset/index.html";

    // label, type ("page" = a screen inside your Goal Getter app, "web" = a website), value
    private static final String[][] MENU = {
            {"Dashboard", "page", "home"},
            {"Motivation", "page", "motivation"},
            {"Tasks", "page", "tasks"},
            {"Analytics", "page", "stats"},
            {"Water", "page", "water"},
            {"Goaler AI", "web", "https://chatgpt.com/"},
            {"Gemini", "web", "https://gemini.google.com/app"},
            {"Claude", "web", "https://claude.ai/new"},
            {"Privacy Policy", "web", "file:///android_asset/privacy.html"}
    };

    private DrawerLayout drawer;
    private LinearLayout drawerPanel;
    private WebView appWeb, aiWeb;
    private ProgressBar spinner;
    private TextView title;
    private final List<TextView> items = new ArrayList<>();

    private boolean showingWeb = false;
    private boolean appReady = false;
    private String pendingPage = null;
    private String webLoaded = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        drawer = findViewById(R.id.drawer);
        drawerPanel = findViewById(R.id.drawerPanel);
        appWeb = findViewById(R.id.appWeb);
        aiWeb = findViewById(R.id.aiWeb);
        spinner = findViewById(R.id.spinner);
        title = findViewById(R.id.title);

        setupWebView(appWeb, false);
        setupWebView(aiWeb, true);
        appWeb.loadUrl(APP_URL);

        buildDrawer();
        highlight(0);

        findViewById(R.id.btnMenu).setOnClickListener(v -> drawer.openDrawer(GravityCompat.START));
        findViewById(R.id.btnShare).setOnClickListener(v -> {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_TEXT, "I'm using the Goal Getter app to plan my day and build good habits.");
            startActivity(Intent.createChooser(send, "Share"));
        });
        findViewById(R.id.btnBell).setOnClickListener(v -> {
            openPage("reminder");
            highlight(-1);
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                } else if (showingWeb && aiWeb.canGoBack()) {
                    aiWeb.goBack();
                } else if (showingWeb) {
                    openPage("home");
                    highlight(0);
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });
    }

    private void buildDrawer() {
        float d = getResources().getDisplayMetrics().density;
        for (int i = 0; i < MENU.length; i++) {
            final int index = i;
            TextView t = new TextView(this);
            t.setText(MENU[i][0]);
            t.setTextSize(17);
            t.setTextColor(0xFF222222);
            t.setGravity(Gravity.CENTER_VERTICAL);
            t.setPadding((int) (24 * d), 0, (int) (16 * d), 0);
            t.setBackgroundResource(R.drawable.bg_item);
            t.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) (52 * d)));
            t.setOnClickListener(v -> {
                drawer.closeDrawer(GravityCompat.START);
                highlight(index);
                if ("page".equals(MENU[index][1])) {
                    openPage(MENU[index][2]);
                } else {
                    openWeb(MENU[index][2]);
                }
            });
            drawerPanel.addView(t);
            items.add(t);
        }
    }

    private void highlight(int index) {
        for (int i = 0; i < items.size(); i++) {
            items.get(i).setBackgroundResource(i == index ? R.drawable.bg_item_selected : R.drawable.bg_item);
        }
    }

    private void showWeb(boolean web) {
        showingWeb = web;
        aiWeb.setVisibility(web ? View.VISIBLE : View.GONE);
        appWeb.setVisibility(web ? View.GONE : View.VISIBLE);
        if (!web) spinner.setVisibility(View.GONE);
    }

    // Show one of your Goal Getter screens (calls go('tasks') etc. inside your app)
    private void openPage(String pageId) {
        showWeb(false);
        String js = "if(typeof go==='function'){go('" + pageId + "')}";
        if (appReady) {
            appWeb.evaluateJavascript(js, null);
        } else {
            pendingPage = js;
        }
    }

    // Show a website (ChatGPT, Gemini, Claude, privacy page) under the same top bar
    private void openWeb(String url) {
        showWeb(true);
        if (!url.equals(webLoaded)) {
            webLoaded = url;
            aiWeb.loadUrl(url);
        }
    }

    private boolean isAiSite(String u) {
        return u.startsWith("https://chatgpt.com") || u.startsWith("https://gemini.google.com")
                || u.startsWith("https://claude.ai");
    }

    private void setupWebView(final WebView w, final boolean isWeb) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        if (isWeb) {
            // Look like normal mobile Chrome so the sites load their regular mobile page
            s.setUserAgentString(s.getUserAgentString().replace("; wv", ""));
        }
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(w, true);

        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String u = request.getUrl().toString();
                if (!isWeb) {
                    // Tapping Goaler AI inside the app opens the real site under the top bar
                    if (isAiSite(u)) {
                        openWeb(u);
                        highlight(u.contains("gemini") ? 6 : u.contains("claude") ? 7 : 5);
                        return true;
                    }
                    if (u.startsWith("http")) {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));
                        return true;
                    }
                }
                return false;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                if (isWeb) spinner.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (isWeb) {
                    spinner.setVisibility(View.GONE);
                } else if (url != null && url.startsWith("file:")) {
                    appReady = true;
                    if (pendingPage != null) {
                        view.evaluateJavascript(pendingPage, null);
                        pendingPage = null;
                    }
                }
            }
        });

        if (isWeb) {
            w.setWebChromeClient(new WebChromeClient() {
                @Override
                public void onProgressChanged(WebView view, int progress) {
                    spinner.setVisibility(progress < 100 ? View.VISIBLE : View.GONE);
                }
            });
        }
    }
}
