// Goaler AI server (Cloudflare Worker). Your API key stays here, never in the app.
// Secrets to add in Cloudflare: ANTHROPIC_API_KEY, APP_PASSCODE.  Optional: WEB_SEARCH=on, MODEL.
export default {
  async fetch(req, env) {
    const cors = {'Access-Control-Allow-Origin': env.ALLOW_ORIGIN || '*','Access-Control-Allow-Headers': 'Content-Type, X-App-Key','Access-Control-Allow-Methods': 'POST, OPTIONS'};
    const send = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { ...cors, 'Content-Type': 'application/json' } });
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
    if (req.method !== 'POST') return send({ error: 'POST only' }, 405);
    if (!env.APP_PASSCODE || req.headers.get('X-App-Key') !== env.APP_PASSCODE) return send({ error: 'wrong passcode' }, 401);
    let body;
    try { body = await req.json(); } catch { return send({ error: 'bad json' }, 400); }
    const m = body && body.messages;
    if (!Array.isArray(m) || m.length < 1 || m.length > 30) return send({ error: 'bad messages' }, 400);
    for (const x of m) {
      if (!x || (x.role !== 'user' && x.role !== 'assistant') || typeof x.content !== 'string' || x.content.length > 8000) return send({ error: 'bad message' }, 400);
    }
    if (m[0].role !== 'user' || m[m.length - 1].role !== 'user') return send({ error: 'must start and end with user' }, 400);
    const payload = { model: env.MODEL || 'claude-sonnet-5-5', max_tokens: 1200, messages: m };
    if (env.WEB_SEARCH === 'on') payload.tools = [{ type: 'web_search_20250305', name: 'web_search', max_uses: 3 }];
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'x-api-key': env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!r.ok) return send({ error: 'upstream ' + r.status }, 502);
    const j = await r.json();
    const text = (j.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('');
    return send({ text, truncated: j.stop_reason === 'max_tokens' });
  },
};
