MVD PROFESSIONAL ENGLISH — проект Android APK

Что внутри:
- app/src/main/assets/index.html — проверенная HTML-версия приложения.
- Kotlin WebView-оболочка для Android.
- Поддержка JavaScript и локального хранилища.
- Разрешение INTERNET нужно для встроенных видео YouTube.

Как собрать APK в Android Studio:
1. Распакуйте архив.
2. Откройте папку MVD_Professional_English_Android как проект.
3. Установите Android SDK Platform 35 и JDK 17, если Android Studio попросит.
4. Дождитесь окончания Gradle Sync.
5. Выберите Build → Build Bundle(s) / APK(s) → Build APK(s).
6. APK обычно появится в app/build/outputs/apk/debug/app-debug.apk.

Сборка на Android-телефоне:
Можно открыть проект в совместимой среде AndroidIDE, если в ней настроены Gradle,
JDK и Android SDK. Названия меню могут немного отличаться.

Важно:
- Это Android-проект для сборки APK, а не уже собранный APK.
- В текущей среде нет установленного Android SDK/Gradle, поэтому здесь APK
  скомпилировать и проверить не удалось.
- Учётные данные из HTML сохраняются локально на устройстве; серверной авторизации
  в этом проекте нет.
- Для видео YouTube необходимо подключение к интернету.
