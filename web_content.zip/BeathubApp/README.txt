# Beathub
Simple UI-only Android app based on the supplied Beathub logo.

Flow:
1. Open app -> Beathub logo.
2. Root section shows red "Beathub 1" button.
3. Tap it -> button turns green and "Beathub Off" appears.
4. Tap "Beathub Off" -> Beathub 1 returns to off state.

No root command, background service, or device modification is included.

The `android` folder is an Android Studio project.
The root `index.html` is also a standalone mobile/PWA version.
