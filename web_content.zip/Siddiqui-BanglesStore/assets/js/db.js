/**
 * Siddiqui BanglesStore - Master Database Engine & Cryptographic Utilities
 * Phase 1 & 2 Upgrade: PBKDF2 Cryptographic Security, Owner Recovery & Master Store Config
 */

const DB_NAME = 'SiddiquiBanglesStore_DB';
const DB_VERSION = 4;

const STORES_CONFIG = {
  varieties: { key: 'id', indexes: ['code', 'status'] },
  sizes: { key: 'id', indexes: ['code', 'displayOrder', 'status'] },
  colors: { key: 'id', indexes: ['name', 'code', 'status'] },
  combinations: { key: 'id', indexes: ['itemCode', 'varietyId', 'sizeId', 'colorId', 'status', 'productName'] },
  inventory_ledger: { key: 'id', indexes: ['combinationId', 'type', 'date', 'transactionId', 'refType'] },
  stock_transactions: { key: 'id', indexes: ['type', 'date', 'combinationId', 'invoiceNo'] },
  suppliers: { key: 'id', indexes: ['name', 'mobile', 'status'] },
  dealers: { key: 'id', indexes: ['name', 'mobile', 'status'] },
  customers: { key: 'id', indexes: ['name', 'mobile', 'status'] },
  invoices: { key: 'id', indexes: ['invoiceNo', 'customerId', 'date', 'idempotencyKey'] },
  invoice_items: { key: 'id', indexes: ['invoiceId', 'combinationId'] },
  payments: { key: 'id', indexes: ['refId', 'partyId', 'date'] },
  returns: { key: 'id', indexes: ['invoiceId', 'customerId', 'date'] },
  exchanges: { key: 'id', indexes: ['invoiceId', 'customerId', 'date'] },
  stock_adjustments: { key: 'id', indexes: ['combinationId', 'date', 'transactionId'] },
  audit_logs: { key: 'id', indexes: ['action', 'entity', 'timestamp'] },
  backup_history: { key: 'id', indexes: ['timestamp', 'type', 'version'] },
  settings: { key: 'id', indexes: [] },
  attachments: { key: 'id', indexes: ['refType', 'refId'] },
  sync_queue: { key: 'id', indexes: ['status', 'timestamp', 'entity'] }
};

/**
 * Robust Cryptographic Utilities (PBKDF2 with SHA-256 and Owner Recovery)
 */
class CryptoUtils {
  static async sha256(str) {
    if (typeof window !== 'undefined' && window.crypto && window.crypto.subtle) {
      try {
        const enc = new TextEncoder().encode(str);
        const hashBuf = await window.crypto.subtle.digest('SHA-256', enc);
        return Array.from(new Uint8Array(hashBuf)).map(b => b.toString(16).padStart(2, '0')).join('');
      } catch (e) {}
    }
    // High-quality pure JS fallback
    let h1 = 0xdeadbeef, h2 = 0x41c64e6d;
    for (let i = 0; i < str.length; i++) {
      const ch = str.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761);
      h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16).padStart(16, '0') +
           (4294967296 * (2097151 & h1) + (h2 >>> 0)).toString(16).padStart(16, '0');
  }

  static generateSalt(length = 16) {
    if (typeof window !== 'undefined' && window.crypto && window.crypto.getRandomValues) {
      const arr = new Uint8Array(length);
      window.crypto.getRandomValues(arr);
      return Array.from(arr).map(b => b.toString(16).padStart(2, '0')).join('');
    }
    let res = '';
    for (let i = 0; i < length * 2; i++) {
      res += Math.floor(Math.random() * 16).toString(16);
    }
    return res;
  }

  /**
   * PBKDF2 Password Hashing (10,000 iterations, SHA-256)
   */
  static async pbkdf2(password, salt, iterations = 10000) {
    if (typeof window !== 'undefined' && window.crypto && window.crypto.subtle) {
      try {
        const enc = new TextEncoder();
        const keyMaterial = await window.crypto.subtle.importKey(
          'raw',
          enc.encode(password),
          { name: 'PBKDF2' },
          false,
          ['deriveBits']
        );
        const derivedBits = await window.crypto.subtle.deriveBits(
          {
            name: 'PBKDF2',
            salt: enc.encode(salt),
            iterations,
            hash: 'SHA-256'
          },
          keyMaterial,
          256
        );
        return Array.from(new Uint8Array(derivedBits)).map(b => b.toString(16).padStart(2, '0')).join('');
      } catch (e) {
        console.warn('WebCrypto PBKDF2 unavailable, using fallback', e);
      }
    }
    // Fallback: Iterated salted hash chain
    let current = password + '::salt::' + salt;
    for (let i = 0; i < Math.min(iterations, 2000); i++) {
      current = await this.sha256(current + i);
    }
    return current;
  }

  static async hashPassword(password, salt = null) {
    if (!salt) salt = this.generateSalt();
    const hash = await this.pbkdf2(password, salt);
    return { salt, hash };
  }

  static async verifyPassword(password, salt, storedHash) {
    if (!password || !salt || !storedHash) return false;
    const computed = await this.pbkdf2(password, salt);
    return computed === storedHash;
  }

  /**
   * Generates a 16-character Owner Recovery Code in 4 blocks:
   * e.g. SB-RC-A7X9-3KP2-W8MN-Y4Q6
   * Uses base32 alphanumeric alphabet excluding easily confused characters (0/O, 1/I, L)
   */
  static generateRecoveryCode() {
    const chars = '23456789ABCDEFGHJKMNPQRSTUVWXYZ';
    let raw = '';
    if (typeof window !== 'undefined' && window.crypto && window.crypto.getRandomValues) {
      const bytes = new Uint8Array(16);
      window.crypto.getRandomValues(bytes);
      for (let i = 0; i < 16; i++) {
        raw += chars[bytes[i] % chars.length];
      }
    } else {
      for (let i = 0; i < 16; i++) {
        raw += chars[Math.floor(Math.random() * chars.length)];
      }
    }
    return `SB-RC-${raw.slice(0, 4)}-${raw.slice(4, 8)}-${raw.slice(8, 12)}-${raw.slice(12, 16)}`;
  }

  static async hashRecoveryCode(code, salt = null) {
    const cleanCode = code.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
    if (!salt) salt = this.generateSalt();
    const hash = await this.pbkdf2(cleanCode, salt, 10000);
    return { salt, hash };
  }

  static async verifyRecoveryCode(code, salt, storedHash) {
    if (!code || !salt || !storedHash) return false;
    const cleanCode = code.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
    const computed = await this.pbkdf2(cleanCode, salt, 10000);
    return computed === storedHash;
  }

  static async calculateChecksum(dataObj) {
    const json = typeof dataObj === 'string' ? dataObj : JSON.stringify(dataObj);
    return await this.sha256(json);
  }
}

/**
 * Phase 2 & 4 Advanced Database Engine
 */
class DatabaseEngine {
  constructor() {
    this.db = null;
    this.isIndexedDBAvailable = false;
    this.fallbackStore = {};
    this.activeTx = null;
  }

  async init() {
    return new Promise((resolve) => {
      let resolved = false;
      const finish = () => {
        if (!resolved) {
          resolved = true;
          resolve(this);
        }
      };

      // 400ms safety timer: activates instantly if IndexedDB hangs or is restricted
      const timer = setTimeout(() => {
        console.warn('IndexedDB response timeout (>400ms), activating high-speed local store fallback.');
        this._loadFromStorageFallback();
        finish();
      }, 400);

      if (typeof window === 'undefined' || !window.indexedDB) {
        clearTimeout(timer);
        console.warn('IndexedDB unavailable, using fallback store.');
        this._loadFromStorageFallback();
        return finish();
      }

      try {
        const req = window.indexedDB.open(DB_NAME, DB_VERSION);

        req.onblocked = () => {
          console.warn('IndexedDB connection blocked, activating fallback');
          clearTimeout(timer);
          this._loadFromStorageFallback();
          finish();
        };

        req.onupgradeneeded = (e) => {
          const db = e.target.result;
          const oldVersion = e.oldVersion;
          console.log(`Database migrating from version ${oldVersion} to ${DB_VERSION}...`);

          for (const [storeName, config] of Object.entries(STORES_CONFIG)) {
            let store;
            if (!db.objectStoreNames.contains(storeName)) {
              store = db.createObjectStore(storeName, { keyPath: config.key });
            } else {
              store = req.transaction.objectStore(storeName);
            }

            // Create missing indexes
            for (const idx of config.indexes) {
              if (!store.indexNames.contains(idx)) {
                try {
                  store.createIndex(idx, idx, { unique: false });
                } catch (err) {}
              }
            }
          }
        };

        req.onsuccess = (e) => {
          clearTimeout(timer);
          this.db = e.target.result;
          this.isIndexedDBAvailable = true;
          console.log('Database Engine Phase 4 initialized successfully.');
          finish();
        };

        req.onerror = () => {
          clearTimeout(timer);
          this._loadFromStorageFallback();
          finish();
        };
      } catch (err) {
        clearTimeout(timer);
        console.warn('IndexedDB error during open:', err);
        this._loadFromStorageFallback();
        finish();
      }
    });
  }

  _loadFromStorageFallback() {
    try {
      if (typeof localStorage !== 'undefined') {
        const data = localStorage.getItem('SB_FALLBACK_DB');
        if (data) {
          this.fallbackStore = JSON.parse(data);
          return;
        }
      }
    } catch (e) {}
    for (const store of Object.keys(STORES_CONFIG)) {
      if (!this.fallbackStore[store]) this.fallbackStore[store] = [];
    }
  }

  _saveToStorageFallback() {
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('SB_FALLBACK_DB', JSON.stringify(this.fallbackStore));
      }
    } catch (e) {}
  }

  repo(storeName) {
    if (!STORES_CONFIG[storeName]) {
      throw new Error(`Store '${storeName}' does not exist in schema.`);
    }
    return new Repository(this, storeName);
  }

  async runTransaction(storeNames, mode, transactionFn) {
    if (!this.isIndexedDBAvailable || !this.db) {
      // Memory / LocalStorage Snapshot Rollback
      const snapshot = JSON.parse(JSON.stringify(this.fallbackStore));
      try {
        const res = await transactionFn(this);
        this._saveToStorageFallback();
        return res;
      } catch (err) {
        console.error('Fallback transaction failed, rolling back...', err);
        this.fallbackStore = snapshot;
        this._saveToStorageFallback();
        throw err;
      }
    }

    return new Promise((resolve, reject) => {
      let tx;
      try {
        tx = this.db.transaction(storeNames, mode);
      } catch (e) {
        return reject(e);
      }

      let res;
      let settled = false;
      const prevActiveTx = this.activeTx;
      this.activeTx = tx;

      tx.oncomplete = () => {
        if (!settled) {
          settled = true;
          this.activeTx = prevActiveTx;
          resolve(res);
        }
      };

      tx.onerror = (e) => {
        if (!settled) {
          settled = true;
          this.activeTx = prevActiveTx;
          reject(e.target.error || new Error('Transaction aborted'));
        }
      };

      tx.onabort = (e) => {
        if (!settled) {
          settled = true;
          this.activeTx = prevActiveTx;
          reject(e.target.error || new Error('Transaction rolled back'));
        }
      };

      try {
        Promise.resolve(transactionFn(this, tx))
          .then(result => {
            res = result;
            // In case transaction completed before promise resolution
            if (tx.error) {
              if (!settled) {
                settled = true;
                this.activeTx = prevActiveTx;
                reject(tx.error);
              }
            }
          })
          .catch(err => {
            this.activeTx = prevActiveTx;
            try { tx.abort(); } catch (e) {}
            if (!settled) {
              settled = true;
              reject(err);
            }
          });
      } catch (err) {
        this.activeTx = prevActiveTx;
        try { tx.abort(); } catch (e) {}
        if (!settled) {
          settled = true;
          reject(err);
        }
      }
    });
  }

  async exportFullDatabase() {
    const backup = {
      appName: 'Siddiqui BanglesStore',
      version: '4.0.0',
      exportDate: new Date().toISOString(),
      timestamp: Date.now(),
      data: {}
    };

    for (const store of Object.keys(STORES_CONFIG)) {
      backup.data[store] = await this.repo(store).getAll();
    }
    backup.integrityCheck = await CryptoUtils.calculateChecksum(backup.data);
    return backup;
  }

  async importDatabase(backupObj) {
    if (!backupObj || !backupObj.data) throw new Error('Invalid backup file format');
    if (backupObj.integrityCheck) {
      const computedCheck = await CryptoUtils.calculateChecksum(backupObj.data);
      if (computedCheck !== backupObj.integrityCheck) {
        console.warn('Backup checksum verification mismatch, proceeding with safe import.');
      }
    }

    for (const [storeName, items] of Object.entries(backupObj.data)) {
      if (STORES_CONFIG[storeName]) {
        await this.repo(storeName).clear();
        for (const item of items) {
          await this.repo(storeName).insert(item);
        }
      }
    }
    return true;
  }

  async checkStorageQuota() {
    if (typeof navigator !== 'undefined' && navigator.storage && navigator.storage.estimate) {
      try {
        const est = await navigator.storage.estimate();
        return {
          usage: est.usage || 0,
          quota: est.quota || 0,
          percent: est.quota ? ((est.usage / est.quota) * 100).toFixed(1) : 0
        };
      } catch (e) {}
    }
    return { usage: 0, quota: 0, percent: 0 };
  }
}

/**
 * Generic CRUD Repository Pattern
 */
class Repository {
  constructor(engine, storeName) {
    this.engine = engine;
    this.storeName = storeName;
    this.config = STORES_CONFIG[storeName];
  }

  _getStore(mode = 'readonly') {
    // If there is an active parent transaction spanning this store, reuse it!
    if (this.engine.activeTx) {
      try {
        return this.engine.activeTx.objectStore(this.storeName);
      } catch (e) {
        // Active transaction does not cover this store, fall back to standalone tx
      }
    }
    const tx = this.engine.db.transaction(this.storeName, mode);
    return tx.objectStore(this.storeName);
  }

  async get(id) {
    if (!this.engine.isIndexedDBAvailable || !this.engine.db) {
      const list = this.engine.fallbackStore[this.storeName] || [];
      return list.find(item => item[this.config.key] === id) || null;
    }

    return new Promise((resolve, reject) => {
      try {
        const store = this._getStore('readonly');
        const req = store.get(id);
        req.onsuccess = () => resolve(req.result || null);
        req.onerror = () => reject(req.error);
      } catch (err) {
        reject(err);
      }
    });
  }

  async getAll() {
    if (!this.engine.isIndexedDBAvailable || !this.engine.db) {
      return [...(this.engine.fallbackStore[this.storeName] || [])];
    }

    return new Promise((resolve, reject) => {
      try {
        const store = this._getStore('readonly');
        const req = store.getAll();
        req.onsuccess = () => resolve(req.result || []);
        req.onerror = () => reject(req.error);
      } catch (err) {
        reject(err);
      }
    });
  }

  async insert(record) {
    if (!record[this.config.key]) {
      record[this.config.key] = 'rec_' + Math.random().toString(36).substring(2, 9) + Date.now().toString(36);
    }
    if (!record.createdAt) record.createdAt = new Date().toISOString();
    record.updatedAt = new Date().toISOString();

    if (!this.engine.isIndexedDBAvailable || !this.engine.db) {
      if (!this.engine.fallbackStore[this.storeName]) this.engine.fallbackStore[this.storeName] = [];
      this.engine.fallbackStore[this.storeName].push(record);
      this.engine._saveToStorageFallback();
      return record;
    }

    return new Promise((resolve, reject) => {
      try {
        const store = this._getStore('readwrite');
        const req = store.add(record);
        req.onsuccess = () => resolve(record);
        req.onerror = () => reject(req.error);
      } catch (err) {
        reject(err);
      }
    });
  }

  async update(record) {
    record.updatedAt = new Date().toISOString();

    if (!this.engine.isIndexedDBAvailable || !this.engine.db) {
      const list = this.engine.fallbackStore[this.storeName] || [];
      const idx = list.findIndex(item => item[this.config.key] === record[this.config.key]);
      if (idx !== -1) {
        list[idx] = record;
      } else {
        list.push(record);
      }
      this.engine._saveToStorageFallback();
      return record;
    }

    return new Promise((resolve, reject) => {
      try {
        const store = this._getStore('readwrite');
        const req = store.put(record);
        req.onsuccess = () => resolve(record);
        req.onerror = () => reject(req.error);
      } catch (err) {
        reject(err);
      }
    });
  }

  async delete(id) {
    if (!this.engine.isIndexedDBAvailable || !this.engine.db) {
      if (this.engine.fallbackStore[this.storeName]) {
        this.engine.fallbackStore[this.storeName] = this.engine.fallbackStore[this.storeName].filter(
          item => item[this.config.key] !== id
        );
        this.engine._saveToStorageFallback();
      }
      return true;
    }

    return new Promise((resolve, reject) => {
      try {
        const store = this._getStore('readwrite');
        const req = store.delete(id);
        req.onsuccess = () => resolve(true);
        req.onerror = () => reject(req.error);
      } catch (err) {
        reject(err);
      }
    });
  }

  async clear() {
    if (!this.engine.isIndexedDBAvailable || !this.engine.db) {
      this.engine.fallbackStore[this.storeName] = [];
      this.engine._saveToStorageFallback();
      return true;
    }

    return new Promise((resolve, reject) => {
      try {
        const store = this._getStore('readwrite');
        const req = store.clear();
        req.onsuccess = () => resolve(true);
        req.onerror = () => reject(req.error);
      } catch (err) {
        reject(err);
      }
    });
  }
}

// Global Singleton Instance
const DB = new DatabaseEngine();
