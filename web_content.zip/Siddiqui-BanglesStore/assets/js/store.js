/**
 * Siddiqui BanglesStore - Master Store Engine & Business Logic
 * Unified Phase 1-9 Architecture:
 * - Admin Auth Reset & PBKDF2 Setup / Recovery Engine
 * - Product Identity & Automatic Stock Name Generation ([Variety] [Size] [Color])
 * - Universal Multi-Variable Search Engine
 * - Variety-Wise Matrix Aggregator
 * - Image & Attachment Storage (PNG/JPG/WEBP/GIF)
 * - Atomic Inventory Ledger & Billing Integration
 */

class SyncEngine {
  static generateUUID() {
    return 'sb_' + Date.now().toString(36) + '_' + Math.random().toString(36).substring(2, 9);
  }
}

class StoreEngine {
  constructor() {
    this.adminSession = false;
    this.currentUser = { role: 'guest', name: 'User' };
    this.cachedData = {
      varieties: [],
      sizes: [],
      colors: [],
      combinations: [],
      customers: [],
      dealers: [],
      suppliers: [],
      invoices: [],
      settings: null,
      auth: null
    };
  }

  async init() {
    await DB.init();
    await this.seedInitialDataIfNeeded();
    await this.refreshCache();
  }

  // ==========================================
  // MASTER SEED DATA & MIGRATION
  // ==========================================
  async seedInitialDataIfNeeded() {
    const varieties = await DB.repo('varieties').getAll();
    if (varieties.length === 0) {
      console.log('Seeding Master Product Database & Live Bangles Inventory...');

      // 1. Master Varieties (English and Urdu)
      const defaultVarieties = [
        { id: 'var_sada', name: 'Sada', nameUrdu: 'سادہ', code: 'SDA', description: 'Plain Glass Bangles (سادہ شیشے کی چوڑیاں)', status: 'active' },
        { id: 'var_meena', name: 'MEENA', nameUrdu: 'مینا', code: 'MNA', description: 'Meena Work Designer Bangles (مینا کاری والی چوڑیاں)', status: 'active' },
        { id: 'var_makhan', name: 'Makhan', nameUrdu: 'مکھن', code: 'MKH', description: 'Makhan Polish Silky Bangles (مکھن پالش ملائم چوڑیاں)', status: 'active' },
        { id: 'var_madai', name: 'Madai', nameUrdu: 'مڑائی', code: 'MDI', description: 'Madai Design Bangles (مڑائی ڈیزائن چوڑیاں)', status: 'active' },
        { id: 'var_fancy', name: 'Fancy', nameUrdu: 'فینسی', code: 'FNC', description: 'Fancy Diamond Cut Bangles (فینسی کٹنگ چوڑیاں)', status: 'active' }
      ];
      for (const v of defaultVarieties) await DB.repo('varieties').insert(v);

      // 2. Master Sizes (Standard 04 - 28 + Traditional 2, 21, =2, =21)
      const defaultSizes = [
        { id: 'sz_04', code: '04', name: 'Size 04', displayOrder: 1, status: 'active' },
        { id: 'sz_06', code: '06', name: 'Size 06', displayOrder: 2, status: 'active' },
        { id: 'sz_08', code: '08', name: 'Size 08', displayOrder: 3, status: 'active' },
        { id: 'sz_10', code: '10', name: 'Size 10', displayOrder: 4, status: 'active' },
        { id: 'sz_12', code: '12', name: 'Size 12', displayOrder: 5, status: 'active' },
        { id: 'sz_14', code: '14', name: 'Size 14', displayOrder: 6, status: 'active' },
        { id: 'sz_16', code: '16', name: 'Size 16', displayOrder: 7, status: 'active' },
        { id: 'sz_18', code: '18', name: 'Size 18', displayOrder: 8, status: 'active' },
        { id: 'sz_20', code: '20', name: 'Size 20', displayOrder: 9, status: 'active' },
        { id: 'sz_22', code: '22', name: 'Size 22', displayOrder: 10, status: 'active' },
        { id: 'sz_24', code: '24', name: 'Size 24', displayOrder: 11, status: 'active' },
        { id: 'sz_26', code: '26', name: 'Size 26', displayOrder: 12, status: 'active' },
        { id: 'sz_28', code: '28', name: 'Size 28', displayOrder: 13, status: 'active' },
        { id: 'sz_2', code: '2', name: '2 انچ (2-0/0)', displayOrder: 14, status: 'active' },
        { id: 'sz_21', code: '21', name: 'سوا دو انچ (2-1/4)', displayOrder: 15, status: 'active' },
        { id: 'sz_eq2', code: '=2', name: 'آدھ پا 2 انچ (Adh Pa 2)', displayOrder: 16, status: 'active' },
        { id: 'sz_eq21', code: '=21', name: 'ڈھائی انچ (2-1/2)', displayOrder: 17, status: 'active' }
      ];
      for (const s of defaultSizes) await DB.repo('sizes').insert(s);

      // 3. Master Colors
      const defaultColors = [
        { id: 'col_red', name: 'Red', nameUrdu: 'لال', code: 'RED', hex: '#ef4444', status: 'active' },
        { id: 'col_blue', name: 'Blue', nameUrdu: 'نیلا', code: 'BLU', hex: '#0284c7', status: 'active' },
        { id: 'col_tp', name: 'TP', nameUrdu: 'ٹی پی', code: 'TP', hex: '#d946ef', status: 'active' },
        { id: 'col_brown', name: 'Brown', nameUrdu: 'براؤن', code: 'BRN', hex: '#854d0e', status: 'active' },
        { id: 'col_green', name: 'Green', nameUrdu: 'سبز', code: 'GRN', hex: '#10b981', status: 'active' },
        { id: 'col_yellow', name: 'Yellow', nameUrdu: 'پیلا', code: 'YLW', hex: '#f59e0b', status: 'active' },
        { id: 'col_white', name: 'White', nameUrdu: 'سفید', code: 'WHT', hex: '#ffffff', status: 'active' },
        { id: 'col_black', name: 'Black', nameUrdu: 'کالا', code: 'BLK', hex: '#1e293b', status: 'active' },
        { id: 'col_mongia', name: 'Mongia', nameUrdu: 'مونگیا', code: 'MNG', hex: '#4d7c0f', status: 'active' },
        { id: 'col_lightpink', name: 'Light Pink', nameUrdu: 'ہلکا گلابی', code: 'LPK', hex: '#f472b6', status: 'active' },
        { id: 'col_darkblue', name: 'Dark Blue', nameUrdu: 'گہرا نیلا', code: 'DBL', hex: '#1e3a8a', status: 'active' },
        { id: 'col_k', name: 'K', nameUrdu: 'کے', code: 'K', hex: '#334155', status: 'active' }
      ];
      for (const c of defaultColors) await DB.repo('colors').insert(c);

      // 4. Default Contacts
      await DB.repo('customers').insert({
        id: 'cust_1', name: 'حاجی عبدالرشید بینگلز', mobile: '03001234567', city: 'ملتان',
        address: 'حرم گیٹ چوک، ملتان', businessName: 'عبدالرشید چوڑی سینٹر', balance: 15000, status: 'active'
      });
      await DB.repo('dealers').insert({
        id: 'deal_1', name: 'میاں نعیم ہول سیلر', mobile: '03217654321', city: 'لاہور',
        address: 'شاہ عالم مارکیٹ، لاہور', businessName: 'نعیم ٹریڈرز', balance: 28000, status: 'active'
      });
      await DB.repo('suppliers').insert({
        id: 'supp_1', name: 'حیدرآباد گلاس ورکس', mobile: '03339876543', city: 'حیدرآباد',
        address: 'چوڑی گلی، حیدرآباد، سندھ', businessName: 'حیدرآباد بینگلز انڈسٹری', balance: 50000, status: 'active'
      });

      // 5. Initial Product Combinations with Exact Automatic Names:
      // MEENA 22 RED, Makhan 26 Blue, Sada 28 TP, Sada 26 Red, Sada 14 Brown, etc.
      const sampleCombs = [
        { id: 'comb_sada_26_red', varietyId: 'var_sada', sizeId: 'sz_26', colorId: 'col_red', stock: 125, minStock: 20, purchaseRate: 350, weightedCost: 350, sellingRate: 480 },
        { id: 'comb_sada_28_tp', varietyId: 'var_sada', sizeId: 'sz_28', colorId: 'col_tp', stock: 30, minStock: 15, purchaseRate: 360, weightedCost: 360, sellingRate: 490 },
        { id: 'comb_sada_14_brn', varietyId: 'var_sada', sizeId: 'sz_14', colorId: 'col_brown', stock: 15, minStock: 10, purchaseRate: 340, weightedCost: 340, sellingRate: 460 },
        { id: 'comb_sada_04_red', varietyId: 'var_sada', sizeId: 'sz_04', colorId: 'col_red', stock: 20, minStock: 10, purchaseRate: 320, weightedCost: 320, sellingRate: 450 },
        { id: 'comb_sada_04_blu', varietyId: 'var_sada', sizeId: 'sz_04', colorId: 'col_blue', stock: 15, minStock: 10, purchaseRate: 320, weightedCost: 320, sellingRate: 450 },
        { id: 'comb_sada_06_tp', varietyId: 'var_sada', sizeId: 'sz_06', colorId: 'col_tp', stock: 30, minStock: 15, purchaseRate: 330, weightedCost: 330, sellingRate: 460 },
        { id: 'comb_sada_06_brn', varietyId: 'var_sada', sizeId: 'sz_06', colorId: 'col_brown', stock: 12, minStock: 10, purchaseRate: 330, weightedCost: 330, sellingRate: 460 },
        { id: 'comb_sada_08_red', varietyId: 'var_sada', sizeId: 'sz_08', colorId: 'col_red', stock: 18, minStock: 10, purchaseRate: 340, weightedCost: 340, sellingRate: 470 },
        { id: 'comb_sada_08_grn', varietyId: 'var_sada', sizeId: 'sz_08', colorId: 'col_green', stock: 25, minStock: 15, purchaseRate: 340, weightedCost: 340, sellingRate: 470 },
        { id: 'comb_meena_22_red', varietyId: 'var_meena', sizeId: 'sz_22', colorId: 'col_red', stock: 80, minStock: 25, purchaseRate: 450, weightedCost: 450, sellingRate: 620 },
        { id: 'comb_meena_24_grn', varietyId: 'var_meena', sizeId: 'sz_24', colorId: 'col_green', stock: 40, minStock: 20, purchaseRate: 460, weightedCost: 460, sellingRate: 640 },
        { id: 'comb_makhan_26_blu', varietyId: 'var_makhan', sizeId: 'sz_26', colorId: 'col_blue', stock: 60, minStock: 20, purchaseRate: 380, weightedCost: 380, sellingRate: 520 },
        { id: 'comb_makhan_20_ylw', varietyId: 'var_makhan', sizeId: 'sz_20', colorId: 'col_yellow', stock: 35, minStock: 15, purchaseRate: 370, weightedCost: 370, sellingRate: 500 },
        { id: 'comb_fancy_28_red', varietyId: 'var_fancy', sizeId: 'sz_28', colorId: 'col_red', stock: 10, minStock: 20, purchaseRate: 600, weightedCost: 600, sellingRate: 850 },
        { id: 'comb_fancy_22_mng', varietyId: 'var_fancy', sizeId: 'sz_22', colorId: 'col_mongia', stock: 0, minStock: 20, purchaseRate: 600, weightedCost: 600, sellingRate: 850 },
        { id: 'comb_madai_20_wht', varietyId: 'var_madai', sizeId: 'sz_20', colorId: 'col_white', stock: 25, minStock: 15, purchaseRate: 400, weightedCost: 400, sellingRate: 550 }
      ];

      for (const item of sampleCombs) {
        const v = defaultVarieties.find(x => x.id === item.varietyId);
        const s = defaultSizes.find(x => x.id === item.sizeId);
        const c = defaultColors.find(x => x.id === item.colorId);

        const productName = `${v.name} ${s.code} ${c.name}`;
        const itemCode = `SB-${v.code}-${s.code}-${c.code}`;

        await DB.repo('combinations').insert({
          id: item.id,
          varietyId: item.varietyId,
          sizeId: item.sizeId,
          colorId: item.colorId,
          productName,
          itemCode,
          stock: item.stock,
          minStock: item.minStock,
          purchaseRate: item.purchaseRate,
          weightedCost: item.weightedCost,
          sellingRate: item.sellingRate,
          design: 'Standard Wholesale',
          alertEnabled: true,
          totalIn: item.stock,
          totalOut: 0,
          totalReturns: 0,
          totalAdjustments: 0,
          status: 'active',
          lastUpdated: new Date().toISOString()
        });
      }

      // 6. Store Settings
      await DB.repo('settings').insert({
        id: 'store_info',
        name: 'Siddiqui BanglesStore',
        nameUrdu: 'صدیقی بینگلز اسٹور',
        owner: 'حافظ محمد طلحہ صدیقی',
        ownerPhone: '03016383072',
        ceo: 'حکیم محمد مزمل صدیقی',
        ceoPhone: '03047152589',
        address: 'ہول سیل مارکیٹ، ملتان، پاکستان',
        currency: 'Rs.'
      });

      // 7. Initial Admin Config (isConfigured: false by default to prompt fresh setup)
      // Allows owner to set up their own username and password!
      await DB.repo('settings').insert({
        id: 'admin_auth',
        username: 'Admin',
        isConfigured: false,
        passwordHash: null,
        passwordSalt: null,
        recoveryCodeHash: null,
        recoveryCodeSalt: null,
        createdAt: new Date().toISOString()
      });

      await this.logAudit('SYSTEM_INIT', 'Master Database', 'None', 'Initialized', 'Phase 4 Master Store Engine Initialized');
    } else {
      // Migrate existing records: ensure all combinations have productName
      await this.migrateDataIfNeeded();
    }
  }

  async migrateDataIfNeeded() {
    const combs = await DB.repo('combinations').getAll();
    const varieties = await DB.repo('varieties').getAll();
    const sizes = await DB.repo('sizes').getAll();
    const colors = await DB.repo('colors').getAll();

    for (const c of combs) {
      let changed = false;
      if (!c.productName) {
        const v = varieties.find(x => x.id === c.varietyId);
        const s = sizes.find(x => x.id === c.sizeId);
        const col = colors.find(x => x.id === c.colorId);
        c.productName = this.generateProductName(v, s, col);
        changed = true;
      }
      if (changed) {
        await DB.repo('combinations').update(c);
      }
    }
  }

  async refreshCache() {
    this.cachedData.varieties = await DB.repo('varieties').getAll();
    this.cachedData.sizes = await DB.repo('sizes').getAll();
    this.cachedData.colors = await DB.repo('colors').getAll();
    this.cachedData.combinations = await DB.repo('combinations').getAll();
    this.cachedData.customers = await DB.repo('customers').getAll();
    this.cachedData.dealers = await DB.repo('dealers').getAll();
    this.cachedData.suppliers = await DB.repo('suppliers').getAll();
    this.cachedData.invoices = await DB.repo('invoices').getAll();
    this.cachedData.settings = await DB.repo('settings').get('store_info');
    this.cachedData.auth = await DB.repo('settings').get('admin_auth');
  }

  async logAudit(action, entity, prevVal, newVal, reason = '', transactionId = null) {
    const entry = {
      timestamp: new Date().toISOString(),
      date: new Date().toLocaleDateString('en-PK'),
      time: new Date().toLocaleTimeString('en-PK'),
      action,
      entity,
      transactionId: transactionId || SyncEngine.generateUUID(),
      prevValue: typeof prevVal === 'object' ? JSON.stringify(prevVal) : String(prevVal),
      changedValue: typeof newVal === 'object' ? JSON.stringify(newVal) : String(newVal),
      user: this.currentUser.name,
      reason
    };
    return await DB.repo('audit_logs').insert(entry);
  }

  // ==========================================
  // PHASE 1: ADMIN AUTH, SETUP & RECOVERY
  // ==========================================
  async getAdminAuthConfig() {
    const auth = await DB.repo('settings').get('admin_auth');
    if (!auth || !auth.isConfigured || !auth.passwordHash) {
      return { isConfigured: false, username: (auth && auth.username) || 'Admin' };
    }
    return {
      isConfigured: true,
      username: auth.username || 'Admin',
      lastRotationDate: auth.lastRotationDate || auth.createdAt,
      lastLoginAt: auth.lastLoginAt || null
    };
  }

  /**
   * First-Time Fresh Admin Setup:
   * Sets Username, Password, generates unique Owner Recovery Code,
   * stores PBKDF2 hash & salt, and returns the plaintext recovery code ONCE!
   */
  async setupFirstTimeAdmin(username, password) {
    if (!username || !username.trim()) throw new Error('Username is required.');
    if (!password || password.length < 4) throw new Error('Password must be at least 4 characters long.');

    let auth = await DB.repo('settings').get('admin_auth');
    if (!auth) auth = { id: 'admin_auth' };

    // Generate unique Owner Recovery Code: SB-RC-XXXX-XXXX-XXXX
    const rawRecoveryCode = CryptoUtils.generateRecoveryCode();

    const passHashObj = await CryptoUtils.hashPassword(password);
    const recHashObj = await CryptoUtils.hashRecoveryCode(rawRecoveryCode);

    auth.username = username.trim();
    auth.passwordHash = passHashObj.hash;
    auth.passwordSalt = passHashObj.salt;
    auth.recoveryCodeHash = recHashObj.hash;
    auth.recoveryCodeSalt = recHashObj.salt;
    auth.isConfigured = true;
    auth.createdAt = auth.createdAt || new Date().toISOString();
    auth.updatedAt = new Date().toISOString();
    auth.lastRotationDate = new Date().toISOString();

    await DB.repo('settings').update(auth);

    this.adminSession = true;
    this.currentUser = { role: 'admin', name: `Admin (${auth.username})` };

    await this.logAudit('ADMIN_SETUP', auth.username, 'Unconfigured', 'Configured', 'First-time admin setup completed with PBKDF2');

    return {
      success: true,
      username: auth.username,
      recoveryCode: rawRecoveryCode
    };
  }

  /**
   * Admin Login Verification
   */
  async verifyAdminLogin(username, password) {
    const auth = await DB.repo('settings').get('admin_auth');
    if (!auth || !auth.isConfigured) return false;

    // Check username
    if (auth.username && username) {
      if (auth.username.toLowerCase().trim() !== username.toLowerCase().trim()) {
        return false;
      }
    }

    if (auth.passwordHash && auth.passwordSalt) {
      const match = await CryptoUtils.verifyPassword(password, auth.passwordSalt, auth.passwordHash);
      if (match) {
        this.adminSession = true;
        this.currentUser = { role: 'admin', name: `Admin (${auth.username || 'Admin'})` };
        auth.lastLoginAt = new Date().toISOString();
        await DB.repo('settings').update(auth);
        await this.logAudit('ADMIN_LOGIN', auth.username, 'Logged Out', 'Active', 'Successful login via PBKDF2');
        return true;
      }
    }
    return false;
  }

  /**
   * Reset Admin Credentials to Setup Mode (Emergency Reset)
   * Safely clears Admin login credentials without touching inventory, stock, or customer data!
   */
  async resetAdminCredentialsToSetup() {
    let auth = await DB.repo('settings').get('admin_auth');
    if (!auth) auth = { id: 'admin_auth' };

    auth.isConfigured = false;
    auth.passwordHash = null;
    auth.passwordSalt = null;
    auth.recoveryCodeHash = null;
    auth.recoveryCodeSalt = null;
    auth.resetAt = new Date().toISOString();

    await DB.repo('settings').update(auth);
    this.adminSession = false;
    this.currentUser = { role: 'guest', name: 'User' };

    await this.logAudit('ADMIN_CREDENTIALS_RESET', auth.username || 'Admin', 'Configured', 'Setup Mode', 'Admin credentials reset to setup mode without data loss');
    return true;
  }

  /**
   * Password Reset using Owner Recovery Code
   */
  async resetPasswordWithRecoveryCode(enteredCode, newPassword) {
    if (!enteredCode) throw new Error('Recovery Code is required.');
    if (!newPassword || newPassword.length < 4) throw new Error('New password must be at least 4 characters.');

    const auth = await DB.repo('settings').get('admin_auth');
    if (!auth || !auth.recoveryCodeHash || !auth.recoveryCodeSalt) {
      throw new Error('Recovery settings not found in database.');
    }

    const isValid = await CryptoUtils.verifyRecoveryCode(enteredCode, auth.recoveryCodeSalt, auth.recoveryCodeHash);
    if (!isValid) throw new Error('Invalid Owner Recovery Code. Verification failed.');

    const passHashObj = await CryptoUtils.hashPassword(newPassword);
    auth.passwordHash = passHashObj.hash;
    auth.passwordSalt = passHashObj.salt;
    auth.lastRecoveryUsed = new Date().toISOString();
    auth.updatedAt = new Date().toISOString();

    await DB.repo('settings').update(auth);

    this.adminSession = true;
    this.currentUser = { role: 'admin', name: `Admin (${auth.username || 'Admin'})` };

    await this.logAudit('RECOVERY_USED', auth.username, 'Locked', 'Reset', 'Admin password reset using Owner Recovery Code');
    return true;
  }

  /**
   * Rotate Owner Recovery Code (Generates fresh code and returns it ONCE)
   */
  async rotateRecoveryCode() {
    if (!this.adminSession) throw new Error('Admin authentication required.');
    const auth = await DB.repo('settings').get('admin_auth');

    const newCode = CryptoUtils.generateRecoveryCode();
    const hashObj = await CryptoUtils.hashRecoveryCode(newCode);

    auth.recoveryCodeHash = hashObj.hash;
    auth.recoveryCodeSalt = hashObj.salt;
    auth.lastRotationDate = new Date().toISOString();
    auth.updatedAt = new Date().toISOString();

    await DB.repo('settings').update(auth);

    await this.logAudit('RECOVERY_CODE_ROTATED', auth.username, 'Previous Hash', 'New Hash', 'Owner rotated recovery code');
    return newCode;
  }

  async changeAdminPassword(newPassword) {
    if (!this.adminSession) throw new Error('Admin authentication required.');
    const auth = await DB.repo('settings').get('admin_auth');
    const hashObj = await CryptoUtils.hashPassword(newPassword);
    auth.passwordHash = hashObj.hash;
    auth.passwordSalt = hashObj.salt;
    auth.updatedAt = new Date().toISOString();
    await DB.repo('settings').update(auth);
    await this.logAudit('PASSWORD_CHANGE', auth.username, 'Old Hash', 'New Hash', 'Admin changed password');
    return true;
  }

  // ==========================================
  // PHASE 2: PRODUCT IDENTITY & AUTO-NAMING
  // ==========================================
  generateProductName(variety, size, color) {
    const vName = (variety && (variety.name || variety.nameUrdu)) || 'Unknown';
    const sCode = (size && (size.code || size.name)) || '00';
    const cName = (color && (color.name || color.nameUrdu)) || 'Color';
    return `${vName} ${sCode} ${cName}`.trim();
  }

  generateItemCode(variety, size, color) {
    const vCode = (variety && variety.code) || 'VAR';
    const sCode = (size && size.code) || 'SZ';
    const cCode = (color && color.code) || 'COL';
    return `SB-${vCode}-${sCode}-${cCode}`.toUpperCase();
  }

  async findCombinationByAttributes(varietyId, sizeId, colorId) {
    const combs = await DB.repo('combinations').getAll();
    return combs.find(c => c.varietyId === varietyId && c.sizeId === sizeId && c.colorId === colorId) || null;
  }

  async createOrGetCombination(varietyId, sizeId, colorId, extraData = {}) {
    const existing = await this.findCombinationByAttributes(varietyId, sizeId, colorId);
    if (existing) {
      return { combination: existing, isNew: false };
    }

    const variety = await DB.repo('varieties').get(varietyId);
    const size = await DB.repo('sizes').get(sizeId);
    const color = await DB.repo('colors').get(colorId);

    const productName = this.generateProductName(variety, size, color);
    const itemCode = extraData.itemCode || this.generateItemCode(variety, size, color);

    const newComb = {
      id: 'comb_' + Math.random().toString(36).substring(2, 9) + Date.now().toString(36),
      varietyId,
      sizeId,
      colorId,
      productName,
      itemCode,
      stock: Number(extraData.stock) || 0,
      minStock: Number(extraData.minStock) || 20,
      purchaseRate: Number(extraData.purchaseRate) || 0,
      weightedCost: Number(extraData.purchaseRate) || 0,
      sellingRate: Number(extraData.sellingRate) || 0,
      design: extraData.design || 'Standard Wholesale',
      alertEnabled: true,
      totalIn: Number(extraData.stock) || 0,
      totalOut: 0,
      totalReturns: 0,
      totalAdjustments: 0,
      status: 'active',
      lastUpdated: new Date().toISOString()
    };

    await DB.repo('combinations').insert(newComb);
    await this.refreshCache();
    await this.logAudit('PRODUCT_CREATED', newComb.productName, 'None', newComb.stock, 'New stock combination registered');

    return { combination: newComb, isNew: true };
  }

  // Master Lists Management
  async addVariety(varietyObj) {
    const varieties = await DB.repo('varieties').getAll();
    if (varieties.some(v => v.code.toLowerCase() === varietyObj.code.toLowerCase())) {
      throw new Error(`Variety with code '${varietyObj.code}' already exists.`);
    }
    const created = await DB.repo('varieties').insert(varietyObj);
    await this.refreshCache();
    return created;
  }

  async updateVariety(varietyObj) {
    const updated = await DB.repo('varieties').update(varietyObj);
    await this.refreshCache();
    return updated;
  }

  async addSize(sizeObj) {
    const sizes = await DB.repo('sizes').getAll();
    if (sizes.some(s => s.code.toLowerCase() === sizeObj.code.toLowerCase())) {
      throw new Error(`Size with code '${sizeObj.code}' already exists.`);
    }
    const created = await DB.repo('sizes').insert(sizeObj);
    await this.refreshCache();
    return created;
  }

  async updateSize(sizeObj) {
    const updated = await DB.repo('sizes').update(sizeObj);
    await this.refreshCache();
    return updated;
  }

  async addColor(colorObj) {
    const colors = await DB.repo('colors').getAll();
    if (colors.some(c => c.name.toLowerCase() === colorObj.name.toLowerCase())) {
      throw new Error(`Color with name '${colorObj.name}' already exists.`);
    }
    const created = await DB.repo('colors').insert(colorObj);
    await this.refreshCache();
    return created;
  }

  async updateColor(colorObj) {
    const updated = await DB.repo('colors').update(colorObj);
    await this.refreshCache();
    return updated;
  }

  // ==========================================
  // PHASE 3: UNIVERSAL MULTI-VARIABLE SEARCH
  // ==========================================
  async universalSearch(query) {
    if (!query || !query.trim()) return [];

    const tokens = query.toLowerCase().trim().split(/\s+/);
    const combinations = await DB.repo('combinations').getAll();
    const varieties = await DB.repo('varieties').getAll();
    const sizes = await DB.repo('sizes').getAll();
    const colors = await DB.repo('colors').getAll();

    const results = combinations.filter(comb => {
      const v = varieties.find(x => x.id === comb.varietyId) || { name: '', code: '', nameUrdu: '' };
      const s = sizes.find(x => x.id === comb.sizeId) || { code: '', name: '' };
      const col = colors.find(x => x.id === comb.colorId) || { name: '', code: '', nameUrdu: '' };

      const haystack = [
        comb.productName || '',
        comb.itemCode || '',
        v.name || '',
        v.code || '',
        v.nameUrdu || '',
        s.code || '',
        s.name || '',
        col.name || '',
        col.code || '',
        col.nameUrdu || '',
        comb.design || ''
      ].join(' ').toLowerCase();

      // Every search token must match somewhere in the attributes
      return tokens.every(token => haystack.includes(token));
    });

    // Enrich results with live details and status
    return results.map(comb => {
      const v = varieties.find(x => x.id === comb.varietyId) || { name: 'Unknown' };
      const s = sizes.find(x => x.id === comb.sizeId) || { code: '00' };
      const col = colors.find(x => x.id === comb.colorId) || { name: 'Color', hex: '#00d2ff' };

      const productName = comb.productName || this.generateProductName(v, s, col);
      const stock = Number(comb.stock) || 0;
      const minStock = Number(comb.minStock) || 20;

      let status = 'INSTOCK';
      if (comb.status === 'inactive') status = 'INACTIVE';
      else if (stock <= 0) status = 'OUTOFSTOCK';
      else if (stock <= minStock) status = 'LOWSTOCK';

      return {
        ...comb,
        productName,
        stock,
        minStock,
        displayLabel: `${productName} (${stock} Boxes)`,
        variety: v,
        size: s,
        color: col,
        stockStatus: status
      };
    });
  }

  // ==========================================
  // PHASE 4: VARIETY-WISE MATRIX AGGREGATOR
  // ==========================================
  async getVarietyStockMatrix() {
    const varieties = await DB.repo('varieties').getAll();
    const sizes = await DB.repo('sizes').getAll();
    const colors = await DB.repo('colors').getAll();
    const combinations = await DB.repo('combinations').getAll();
    const attachments = await DB.repo('attachments').getAll();

    // Sort sizes by displayOrder
    sizes.sort((a, b) => (Number(a.displayOrder) || 0) - (Number(b.displayOrder) || 0));

    const matrix = [];

    for (const v of varieties) {
      const vCombs = combinations.filter(c => c.varietyId === v.id && c.status !== 'inactive');
      const vAttachment = attachments.find(a => a.refType === 'variety' && a.refId === v.id);

      const totalBoxes = vCombs.reduce((sum, c) => sum + (Number(c.stock) || 0), 0);
      const lowStockCount = vCombs.filter(c => c.stock > 0 && c.stock <= c.minStock).length;
      const outOfStockCount = vCombs.filter(c => c.stock <= 0).length;

      // Group by sizes
      const sizeGroups = [];
      const presentSizeIds = [...new Set(vCombs.map(c => c.sizeId))];

      for (const sizeId of presentSizeIds) {
        const sizeObj = sizes.find(s => s.id === sizeId) || { code: sizeId, name: sizeId };
        const sizeCombs = vCombs.filter(c => c.sizeId === sizeId);

        const colorList = sizeCombs.map(comb => {
          const col = colors.find(x => x.id === comb.colorId) || { name: 'Color', hex: '#00d2ff' };
          const stock = Number(comb.stock) || 0;
          const minStock = Number(comb.minStock) || 20;

          let status = 'INSTOCK';
          if (stock <= 0) status = 'OUTOFSTOCK';
          else if (stock <= minStock) status = 'LOWSTOCK';

          return {
            combinationId: comb.id,
            combination: comb,
            color: col,
            stock,
            minStock,
            status,
            displayLabel: `${col.name} (${stock})`
          };
        });

        sizeGroups.push({
          size: sizeObj,
          colors: colorList,
          sizeTotalBoxes: sizeCombs.reduce((sum, c) => sum + (Number(c.stock) || 0), 0)
        });
      }

      // Sort size groups by size display order
      sizeGroups.sort((a, b) => (Number(a.size.displayOrder) || 0) - (Number(b.size.displayOrder) || 0));

      matrix.push({
        variety: v,
        totalBoxes,
        sizesCount: sizeGroups.length,
        colorsCount: [...new Set(vCombs.map(c => c.colorId))].length,
        totalItemsCount: vCombs.length,
        lowStockCount,
        outOfStockCount,
        image: vAttachment ? vAttachment.thumbnail || vAttachment.dataUrl : null,
        sizeGroups,
        combinations: vCombs
      });
    }

    return matrix;
  }

  // ==========================================
  // PHASE 6: IMAGE & ATTACHMENT SERVICE
  // ==========================================
  async saveImageAttachment(refType, refId, fileData, fileName, mimeType) {
    const existing = (await DB.repo('attachments').getAll()).find(
      a => a.refType === refType && a.refId === refId
    );

    const attachmentRecord = {
      id: existing ? existing.id : 'att_' + Date.now().toString(36) + '_' + Math.random().toString(36).substring(2, 6),
      refType,
      refId,
      name: fileName || 'image',
      mimeType: mimeType || 'image/png',
      dataUrl: fileData, // Contains exact raw DataURL (preserves GIF animation)
      thumbnail: fileData,
      createdAt: existing ? existing.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    if (existing) {
      await DB.repo('attachments').update(attachmentRecord);
    } else {
      await DB.repo('attachments').insert(attachmentRecord);
    }

    await this.logAudit('IMAGE_UPLOAD', `${refType}:${refId}`, existing ? 'Updated' : 'None', fileName, 'Image attached to stock record');
    return attachmentRecord;
  }

  async getImageAttachment(refType, refId) {
    const attachments = await DB.repo('attachments').getAll();
    return attachments.find(a => a.refType === refType && a.refId === refId) || null;
  }

  async removeImageAttachment(refType, refId) {
    const existing = (await DB.repo('attachments').getAll()).find(
      a => a.refType === refType && a.refId === refId
    );
    if (existing) {
      await DB.repo('attachments').delete(existing.id);
      await this.logAudit('IMAGE_REMOVED', `${refType}:${refId}`, existing.name, 'Deleted', 'Image removed from stock record');
      return true;
    }
    return false;
  }

  // ==========================================
  // PHASE 5: ATOMIC INVENTORY & BILLING
  // ==========================================
  async processStockIn(entryData) {
    if (!entryData) throw new Error('اسٹاک ان کا ڈیٹا غائب ہے۔');
    if (!entryData.combinationId) throw new Error('برائے مہربانی پروڈکٹ منتخب کریں۔ (Please select a product).');

    const transactionId = SyncEngine.generateUUID();
    const qty = Number(entryData.qty);
    if (!qty || qty <= 0 || isNaN(qty)) throw new Error('تعداد ڈبے صفر سے زائد ہونی چاہیے۔');

    const result = await DB.runTransaction(
      ['combinations', 'inventory_ledger', 'stock_transactions', 'audit_logs'],
      'readwrite',
      async () => {
        let comb = await DB.repo('combinations').get(entryData.combinationId);
        if (!comb) throw new Error('منتخب کردہ پروڈکٹ ڈیٹا بیس میں نہیں ملی۔');

        const prevStock = Number(comb.stock) || 0;
        const newStock = prevStock + qty;

        // Weighted Average Cost Calculation
        const purchaseRate = Number(entryData.purchaseRate) || Number(comb.purchaseRate) || 0;
        const prevCost = Number(comb.weightedCost) || purchaseRate;
        const totalOldVal = prevStock * prevCost;
        const totalNewVal = qty * purchaseRate;
        const newWeightedCost = newStock > 0 ? Math.round((totalOldVal + totalNewVal) / newStock) : purchaseRate;

        comb.stock = newStock;
        comb.purchaseRate = purchaseRate;
        comb.weightedCost = newWeightedCost;
        comb.totalIn = (Number(comb.totalIn) || 0) + qty;
        comb.lastUpdated = new Date().toISOString();

        await DB.repo('combinations').update(comb);

        const productName = comb.productName || comb.itemCode || 'Bangles Item';

        // Record in Inventory Ledger
        const ledgerEntry = {
          id: SyncEngine.generateUUID(),
          combinationId: comb.id,
          productName,
          type: 'STOCK_IN',
          refType: 'PURCHASE',
          refId: entryData.invoiceNo || 'PURCHASE',
          prevQty: prevStock,
          deltaQty: qty,
          newQty: newStock,
          rate: purchaseRate,
          party: entryData.supplierName || 'General Supplier',
          remarks: entryData.remarks || 'Stock In Entry',
          date: new Date().toLocaleDateString('en-PK'),
          time: new Date().toLocaleTimeString('en-PK'),
          transactionId
        };
        await DB.repo('inventory_ledger').insert(ledgerEntry);

        // Record in Stock Transactions
        const txRecord = {
          id: SyncEngine.generateUUID(),
          type: 'STOCK_IN',
          combinationId: comb.id,
          productName,
          qty,
          rate: purchaseRate,
          totalAmount: qty * purchaseRate,
          partyName: entryData.supplierName || 'General Supplier',
          invoiceNo: entryData.invoiceNo || '',
          remarks: entryData.remarks || '',
          date: new Date().toLocaleDateString('en-PK'),
          time: new Date().toLocaleTimeString('en-PK'),
          transactionId
        };
        await DB.repo('stock_transactions').insert(txRecord);

        await this.logAudit('STOCK_IN', productName, prevStock, newStock, 'Stock In of ' + qty + ' boxes', transactionId);

        return {
          success: true,
          prevStock,
          newStock,
          combination: comb,
          transactionId,
          ['new stock']: newStock,
          ['newStock']: newStock,
          ['prevStock']: prevStock,
          currentStock: newStock
        };
      }
    );

    try { await this.refreshCache(); } catch (e) {}
    return result;
  }
  async processStockOut(outData) {
    if (!outData) throw new Error('اسٹاک آؤٹ کا ڈیٹا غائب ہے۔');
    if (!outData.combinationId) throw new Error('برائے مہربانی پروڈکٹ منتخب کریں۔ (Please select a product).');

    const transactionId = SyncEngine.generateUUID();
    const qty = Number(outData.qty);
    if (!qty || qty <= 0 || isNaN(qty)) throw new Error('Quantity must be greater than zero.');

    const result = await DB.runTransaction(
      ['combinations', 'inventory_ledger', 'stock_transactions', 'audit_logs'],
      'readwrite',
      async () => {
        let comb = await DB.repo('combinations').get(outData.combinationId);
        if (!comb) throw new Error('Selected product combination does not exist.');

        const prevStock = Number(comb.stock) || 0;
        if (prevStock < qty) {
          throw new Error("Insufficient stock! Available: " + prevStock + " boxes, requested: " + qty + " boxes.");
        }

        const newStock = prevStock - qty;
        comb.stock = newStock;
        comb.totalOut = (Number(comb.totalOut) || 0) + qty;
        comb.lastUpdated = new Date().toISOString();

        await DB.repo('combinations').update(comb);

        const ledgerEntry = {
          id: SyncEngine.generateUUID(),
          combinationId: comb.id,
          productName: comb.productName,
          type: 'STOCK_OUT',
          refType: 'DISPATCH',
          refId: outData.refNo || 'DISPATCH',
          prevQty: prevStock,
          deltaQty: -qty,
          newQty: newStock,
          rate: comb.sellingRate || 0,
          party: outData.partyName || 'Customer',
          remarks: outData.remarks || 'Stock Out Dispatch',
          date: new Date().toLocaleDateString('en-PK'),
          time: new Date().toLocaleTimeString('en-PK'),
          transactionId
        };
        await DB.repo('inventory_ledger').insert(ledgerEntry);

        const txRecord = {
          id: SyncEngine.generateUUID(),
          type: 'STOCK_OUT',
          combinationId: comb.id,
          productName: comb.productName,
          qty,
          rate: comb.sellingRate || 0,
          totalAmount: qty * (comb.sellingRate || 0),
          partyName: outData.partyName || 'Customer',
          invoiceNo: outData.refNo || '',
          remarks: outData.remarks || '',
          date: new Date().toLocaleDateString('en-PK'),
          time: new Date().toLocaleTimeString('en-PK'),
          transactionId
        };
        await DB.repo('stock_transactions').insert(txRecord);

        await this.logAudit('STOCK_OUT', comb.productName, prevStock, newStock, 'Stock Out of ' + qty + ' boxes', transactionId);

        return {
          success: true,
          prevStock,
          newStock,
          combination: comb,
          transactionId,
          ['new stock']: newStock,
          ['newStock']: newStock,
          ['prevStock']: prevStock,
          currentStock: newStock
        };
      }
    );

    try { await this.refreshCache(); } catch (e) {}
    return result;
  }
  async processSaleInvoice(invoiceData) {
    const transactionId = SyncEngine.generateUUID();
    const idempotencyKey = invoiceData.idempotencyKey || SyncEngine.generateUUID();

    return await DB.runTransaction(
      ['invoices', 'invoice_items', 'combinations', 'inventory_ledger', 'stock_transactions', 'customers', 'audit_logs'],
      'readwrite',
      async () => {
        // Idempotency check
        const existingInvoices = await DB.repo('invoices').getAll();
        const dup = existingInvoices.find(inv => inv.idempotencyKey === idempotencyKey);
        if (dup) {
          console.warn('Duplicate invoice request prevented by idempotency key:', idempotencyKey);
          return { invoice: dup, duplicate: true };
        }

        // Validate stock availability for all items before any deduction
        for (const item of invoiceData.items) {
          const comb = await DB.repo('combinations').get(item.combinationId);
          if (!comb) throw new Error(`Product '${item.productName || item.combinationId}' does not exist.`);
          if (comb.stock < item.qty) {
            throw new Error(`Insufficient stock for '${comb.productName}'! Available: ${comb.stock}, In Bill: ${item.qty}`);
          }
        }

        // Deduct stock and write ledger for each item
        for (const item of invoiceData.items) {
          const comb = await DB.repo('combinations').get(item.combinationId);
          const prevStock = comb.stock;
          const newStock = prevStock - item.qty;

          comb.stock = newStock;
          comb.totalOut = (Number(comb.totalOut) || 0) + item.qty;
          comb.lastUpdated = new Date().toISOString();
          await DB.repo('combinations').update(comb);

          const ledgerEntry = {
            id: SyncEngine.generateUUID(),
            combinationId: comb.id,
            productName: comb.productName,
            type: 'SALE',
            refType: 'INVOICE',
            refId: invoiceData.invoiceNo,
            prevQty: prevStock,
            deltaQty: -item.qty,
            newQty: newStock,
            rate: item.rate,
            party: invoiceData.customerName,
            remarks: `Sale Bill #${invoiceData.invoiceNo}`,
            date: new Date().toLocaleDateString('en-PK'),
            time: new Date().toLocaleTimeString('en-PK'),
            transactionId
          };
          await DB.repo('inventory_ledger').insert(ledgerEntry);
        }

        // Create Invoice Record
        const invoiceRecord = {
          id: SyncEngine.generateUUID(),
          invoiceNo: invoiceData.invoiceNo,
          customerId: invoiceData.customerId,
          customerName: invoiceData.customerName,
          mobile: invoiceData.mobile || '',
          city: invoiceData.city || '',
          date: new Date().toLocaleDateString('en-PK'),
          time: new Date().toLocaleTimeString('en-PK'),
          totalQty: invoiceData.items.reduce((s, it) => s + it.qty, 0),
          subTotal: invoiceData.subTotal,
          discount: invoiceData.discount || 0,
          grandTotal: invoiceData.grandTotal,
          paidAmount: invoiceData.paidAmount || 0,
          remainingBalance: invoiceData.remainingBalance || 0,
          paymentStatus: (invoiceData.paidAmount >= invoiceData.grandTotal) ? 'PAID' : (invoiceData.paidAmount > 0 ? 'PARTIAL' : 'UNPAID'),
          idempotencyKey,
          items: invoiceData.items,
          createdAt: new Date().toISOString()
        };
        await DB.repo('invoices').insert(invoiceRecord);

        // Update Customer Balance
        if (invoiceData.customerId) {
          const cust = await DB.repo('customers').get(invoiceData.customerId);
          if (cust) {
            const addedDue = (invoiceData.grandTotal - (invoiceData.paidAmount || 0));
            cust.balance = (Number(cust.balance) || 0) + addedDue;
            await DB.repo('customers').update(cust);
          }
        }

        await this.logAudit('INVOICE_GENERATED', invoiceData.customerName, 'Pending', invoiceData.grandTotal, `Invoice #${invoiceData.invoiceNo} processed`, transactionId);

        return { invoice: invoiceRecord, duplicate: false };
      }
    );
  }

  async adjustStock(adjData) {
    const transactionId = SyncEngine.generateUUID();
    return await DB.runTransaction(
      ['combinations', 'inventory_ledger', 'stock_adjustments', 'audit_logs'],
      'readwrite',
      async () => {
        const comb = await DB.repo('combinations').get(adjData.combinationId);
        if (!comb) throw new Error('Combination not found.');

        const prevStock = Number(comb.stock) || 0;
        const physicalStock = Number(adjData.physicalCount);
        const difference = physicalStock - prevStock;

        comb.stock = physicalStock;
        comb.totalAdjustments = (Number(comb.totalAdjustments) || 0) + Math.abs(difference);
        comb.lastUpdated = new Date().toISOString();
        await DB.repo('combinations').update(comb);

        const adjRecord = {
          id: SyncEngine.generateUUID(),
          combinationId: comb.id,
          productName: comb.productName,
          systemStock: prevStock,
          physicalStock,
          difference,
          reason: adjData.reason || 'Physical Stock Reconciliation',
          date: new Date().toLocaleDateString('en-PK'),
          time: new Date().toLocaleTimeString('en-PK'),
          transactionId
        };
        await DB.repo('stock_adjustments').insert(adjRecord);

        const ledgerEntry = {
          id: SyncEngine.generateUUID(),
          combinationId: comb.id,
          productName: comb.productName,
          type: 'ADJUSTMENT',
          refType: 'RECONCILE',
          refId: adjRecord.id,
          prevQty: prevStock,
          deltaQty: difference,
          newQty: physicalStock,
          rate: comb.purchaseRate || 0,
          party: 'Internal Warehouse Audit',
          remarks: adjData.reason || 'Reconciliation',
          date: new Date().toLocaleDateString('en-PK'),
          time: new Date().toLocaleTimeString('en-PK'),
          transactionId
        };
        await DB.repo('inventory_ledger').insert(ledgerEntry);

        await this.logAudit('STOCK_ADJUSTMENT', comb.productName, prevStock, physicalStock, adjData.reason, transactionId);

        return { success: true, prevStock, physicalStock, difference, combination: comb };
      }
    );
  }

  async getWholesaleStockValuation() {
    const combinations = await DB.repo('combinations').getAll();
    let totalBoxes = 0;
    let totalPurchaseVal = 0;
    let totalWeightedVal = 0;
    let totalRetailVal = 0;

    for (const c of combinations) {
      const stock = Number(c.stock) || 0;
      totalBoxes += stock;
      totalPurchaseVal += stock * (Number(c.purchaseRate) || 0);
      totalWeightedVal += stock * (Number(c.weightedCost) || Number(c.purchaseRate) || 0);
      totalRetailVal += stock * (Number(c.sellingRate) || 0);
    }

    return {
      totalBoxes,
      totalPurchaseVal,
      totalWeightedVal,
      totalRetailVal,
      projectedProfit: totalRetailVal - totalWeightedVal
    };
  }

  // --- Method Aliases & Comprehensive Wrappers ---
  async stockIn(data) {
    return await this.processStockIn(data);
  }

  async stockOut(data) {
    return await this.processStockOut(data);
  }

  async createWholesaleInvoice(data) {
    return await this.processSaleInvoice(data);
  }

  async adjustPhysicalStock(data) {
    return await this.adjustStock(data);
  }

  async setMinimumStock(combId, minStock) {
    const comb = await DB.repo('combinations').get(combId);
    if (!comb) throw new Error('Combination not found');
    const oldMin = comb.minStock;
    comb.minStock = Number(minStock);
    comb.lastUpdated = new Date().toISOString();
    await DB.repo('combinations').update(comb);
    await this.logAudit('MIN_STOCK_UPDATE', comb.productName, oldMin, comb.minStock, 'Minimum stock threshold updated');
    return comb;
  }

  async toggleCombinationStatus(combId) {
    const comb = await DB.repo('combinations').get(combId);
    if (!comb) throw new Error('Combination not found');
    comb.status = comb.status === 'active' ? 'inactive' : 'active';
    comb.lastUpdated = new Date().toISOString();
    await DB.repo('combinations').update(comb);
    await this.logAudit('STATUS_TOGGLE', comb.productName, comb.status === 'active' ? 'inactive' : 'active', comb.status, 'Product status toggled');
    return comb;
  }

  async deleteCombinationWithIntegrityCheck(combId) {
    const comb = await DB.repo('combinations').get(combId);
    if (!comb) throw new Error('Combination not found');

    const ledgers = (await DB.repo('inventory_ledger').getAll()).filter(l => l.combinationId === combId);
    const invoiceItems = (await DB.repo('invoice_items').getAll()).filter(ii => ii.combinationId === combId);

    if (ledgers.length > 0 || invoiceItems.length > 0 || comb.stock > 0) {
      // Cannot delete permanently due to historical transactions; archive instead!
      comb.status = 'archived';
      comb.lastUpdated = new Date().toISOString();
      await DB.repo('combinations').update(comb);
      await this.logAudit('PRODUCT_ARCHIVED', comb.productName, 'active', 'archived', 'Archived instead of delete due to historical transactions');
      return { archived: true, message: 'آئٹم کا سابقہ ریکارڈ یا اسٹاک موجود ہے، لہٰذا اسے محفوظ طور پر آرکائیو (غیر فعال) کر دیا گیا ہے۔' };
    }

    await DB.repo('combinations').delete(combId);
    await this.logAudit('PRODUCT_DELETED', comb.productName, 'Active', 'Deleted', 'Product combination deleted permanently');
    return { archived: false, message: 'پروڈکٹ مکمل طور پر حذف ہو گیا۔' };
  }

  async deleteVarietyWithIntegrityCheck(varId) {
    const combs = (await DB.repo('combinations').getAll()).filter(c => c.varietyId === varId);
    if (combs.length > 0) {
      throw new Error('اس ورائٹی کے تحت پروڈکٹس موجود ہیں۔ پہلے ان کا انتظام کریں۔');
    }
    await DB.repo('varieties').delete(varId);
    await this.refreshCache();
    return true;
  }

  async deleteSizeWithIntegrityCheck(sizeId) {
    const combs = (await DB.repo('combinations').getAll()).filter(c => c.sizeId === sizeId);
    if (combs.length > 0) {
      throw new Error('اس سائز کے تحت پروڈکٹس موجود ہیں۔ پہلے ان کا انتظام کریں۔');
    }
    await DB.repo('sizes').delete(sizeId);
    await this.refreshCache();
    return true;
  }

  async deleteColorWithIntegrityCheck(colorId) {
    const combs = (await DB.repo('combinations').getAll()).filter(c => c.colorId === colorId);
    if (combs.length > 0) {
      throw new Error('اس رنگ کے تحت پروڈکٹس موجود ہیں۔ پہلے ان کا انتظام کریں۔');
    }
    await DB.repo('colors').delete(colorId);
    await this.refreshCache();
    return true;
  }

  // --- Form Draft Auto-Save Engine ---
  saveFormDraft(formKey, data) {
    if (!this._formDrafts) this._formDrafts = {};
    this._formDrafts[formKey] = data;
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(`SB_DRAFT_${formKey}`, JSON.stringify({
          data,
          timestamp: Date.now()
        }));
      }
    } catch (e) {}
  }

  getFormDraft(formKey) {
    try {
      if (typeof localStorage !== 'undefined') {
        const item = localStorage.getItem(`SB_DRAFT_${formKey}`);
        if (item) {
          const parsed = JSON.parse(item);
          return parsed.data;
        }
      }
    } catch (e) {}
    if (this._formDrafts && this._formDrafts[formKey]) return this._formDrafts[formKey];
    return null;
  }

  clearFormDraft(formKey) {
    if (this._formDrafts) delete this._formDrafts[formKey];
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.removeItem(`SB_DRAFT_${formKey}`);
      }
    } catch (e) {}
  }

  // --- Advanced Receiving Batch Engine (Phase 4) ---
  async processAdvancedReceivingBatch(batchData) {
    const transactionId = SyncEngine.generateUUID();
    const items = batchData.items || [];
    if (items.length === 0) throw new Error('Receiving batch must contain at least one product.');

    return await DB.runTransaction(
      ['combinations', 'inventory_ledger', 'stock_transactions', 'audit_logs'],
      'readwrite',
      async () => {
        const results = [];
        for (const it of items) {
          const qty = Number(it.qty) || 0;
          if (qty <= 0) continue;

          let comb = await DB.repo('combinations').get(it.combinationId);
          if (!comb) throw new Error(`Product combination ${it.combinationId} not found.`);

          const prevStock = Number(comb.stock) || 0;
          const newStock = prevStock + qty;
          const purchaseRate = Number(it.rate) || comb.purchaseRate || 0;

          // Recalculate Weighted Cost
          const prevCost = Number(comb.weightedCost) || purchaseRate;
          const totalOldVal = prevStock * prevCost;
          const totalNewVal = qty * purchaseRate;
          const newWeightedCost = newStock > 0 ? Math.round((totalOldVal + totalNewVal) / newStock) : purchaseRate;

          comb.stock = newStock;
          comb.purchaseRate = purchaseRate;
          comb.weightedCost = newWeightedCost;
          comb.totalIn = (Number(comb.totalIn) || 0) + qty;
          comb.lastUpdated = new Date().toISOString();
          await DB.repo('combinations').update(comb);

          const ledgerEntry = {
            id: SyncEngine.generateUUID(),
            combinationId: comb.id,
            productName: comb.productName,
            type: 'STOCK_IN',
            refType: 'ADVANCED_RECEIVING',
            refId: batchData.invoiceNo || 'ADV_RECV',
            prevQty: prevStock,
            deltaQty: qty,
            newQty: newStock,
            rate: purchaseRate,
            party: batchData.supplierName || 'Supplier',
            remarks: it.remarks || batchData.remarks || 'Advanced Stock Receiving Batch',
            date: new Date().toLocaleDateString('en-PK'),
            time: new Date().toLocaleTimeString('en-PK'),
            transactionId
          };
          await DB.repo('inventory_ledger').insert(ledgerEntry);

          const txRecord = {
            id: SyncEngine.generateUUID(),
            type: 'STOCK_IN',
            combinationId: comb.id,
            productName: comb.productName,
            qty,
            rate: purchaseRate,
            totalAmount: qty * purchaseRate,
            partyName: batchData.supplierName || 'Supplier',
            invoiceNo: batchData.invoiceNo || '',
            remarks: it.remarks || batchData.remarks || 'Batch Receiving',
            date: new Date().toLocaleDateString('en-PK'),
            time: new Date().toLocaleTimeString('en-PK'),
            transactionId
          };
          await DB.repo('stock_transactions').insert(txRecord);

          results.push({ combinationId: comb.id, productName: comb.productName, prevStock, newStock, qty });
        }

        await this.logAudit('ADVANCED_RECEIVING', batchData.supplierName || 'Supplier', 'Pending', `${items.length} items`, `Batch receiving of ${results.reduce((s, r) => s + r.qty, 0)} boxes`, transactionId);

        return { success: true, transactionId, items: results };
      }
    );
  }

  // --- Advanced Dispatch Batch Engine (Phase 5) ---
  async processAdvancedDispatchBatch(batchData) {
    const transactionId = SyncEngine.generateUUID();
    const items = batchData.items || [];
    if (items.length === 0) throw new Error('Dispatch batch must contain at least one product.');

    return await DB.runTransaction(
      ['combinations', 'inventory_ledger', 'stock_transactions', 'audit_logs'],
      'readwrite',
      async () => {
        // First validate stock availability for ALL items in batch
        for (const it of items) {
          const qty = Number(it.qty) || 0;
          if (qty <= 0) throw new Error('Item quantity must be greater than zero.');

          const comb = await DB.repo('combinations').get(it.combinationId);
          if (!comb) throw new Error(`Product combination ${it.combinationId} not found.`);
          if (comb.stock < qty) {
            throw new Error(`Insufficient stock for '${comb.productName}'! Available: ${comb.stock} boxes, Requested: ${qty} boxes.`);
          }
        }

        const results = [];
        for (const it of items) {
          const qty = Number(it.qty) || 0;
          const comb = await DB.repo('combinations').get(it.combinationId);
          const prevStock = Number(comb.stock) || 0;
          const newStock = prevStock - qty;

          comb.stock = newStock;
          comb.totalOut = (Number(comb.totalOut) || 0) + qty;
          comb.lastUpdated = new Date().toISOString();
          await DB.repo('combinations').update(comb);

          const ledgerEntry = {
            id: SyncEngine.generateUUID(),
            combinationId: comb.id,
            productName: comb.productName,
            type: 'STOCK_OUT',
            refType: 'ADVANCED_DISPATCH',
            refId: batchData.dispatchRef || 'ADV_DISP',
            prevQty: prevStock,
            deltaQty: -qty,
            newQty: newStock,
            rate: comb.sellingRate || 0,
            party: batchData.partyName || 'Customer/Dealer',
            remarks: it.remarks || batchData.remarks || 'Advanced Stock Dispatch Batch',
            date: new Date().toLocaleDateString('en-PK'),
            time: new Date().toLocaleTimeString('en-PK'),
            transactionId
          };
          await DB.repo('inventory_ledger').insert(ledgerEntry);

          const txRecord = {
            id: SyncEngine.generateUUID(),
            type: 'STOCK_OUT',
            combinationId: comb.id,
            productName: comb.productName,
            qty,
            rate: comb.sellingRate || 0,
            totalAmount: qty * (comb.sellingRate || 0),
            partyName: batchData.partyName || 'Customer/Dealer',
            invoiceNo: batchData.dispatchRef || '',
            remarks: it.remarks || batchData.remarks || 'Batch Dispatch',
            date: new Date().toLocaleDateString('en-PK'),
            time: new Date().toLocaleTimeString('en-PK'),
            transactionId
          };
          await DB.repo('stock_transactions').insert(txRecord);

          results.push({ combinationId: comb.id, productName: comb.productName, prevStock, newStock, qty });
        }

        await this.logAudit('ADVANCED_DISPATCH', batchData.partyName || 'Customer/Dealer', 'Pending', `${items.length} items`, `Batch dispatch of ${results.reduce((s, r) => s + r.qty, 0)} boxes`, transactionId);

        return { success: true, transactionId, items: results };
      }
    );
  }

  // --- Customer Returns & Exchanges Engine ---
  async processReturn(returnData) {
    const transactionId = SyncEngine.generateUUID();
    const qty = Number(returnData.qty) || 0;
    if (qty <= 0) throw new Error('Return quantity must be greater than zero.');

    return await DB.runTransaction(
      ['combinations', 'inventory_ledger', 'returns', 'customers', 'audit_logs'],
      'readwrite',
      async () => {
        const comb = await DB.repo('combinations').get(returnData.combinationId);
        if (!comb) throw new Error('Product not found.');

        const prevStock = comb.stock;
        const newStock = prevStock + qty;
        comb.stock = newStock;
        comb.totalReturns = (Number(comb.totalReturns) || 0) + qty;
        comb.lastUpdated = new Date().toISOString();
        await DB.repo('combinations').update(comb);

        const returnRecord = {
          id: SyncEngine.generateUUID(),
          invoiceId: returnData.invoiceId || '',
          customerId: returnData.customerId || '',
          customerName: returnData.customerName || 'Customer',
          combinationId: comb.id,
          productName: comb.productName,
          qty,
          refundRate: returnData.refundRate || comb.sellingRate || 0,
          totalRefund: qty * (returnData.refundRate || comb.sellingRate || 0),
          reason: returnData.reason || 'Customer Return',
          date: new Date().toLocaleDateString('en-PK'),
          time: new Date().toLocaleTimeString('en-PK'),
          transactionId
        };
        await DB.repo('returns').insert(returnRecord);

        const ledgerEntry = {
          id: SyncEngine.generateUUID(),
          combinationId: comb.id,
          productName: comb.productName,
          type: 'RETURN',
          refType: 'RETURN',
          refId: returnRecord.id,
          prevQty: prevStock,
          deltaQty: qty,
          newQty: newStock,
          rate: returnRecord.refundRate,
          party: returnData.customerName || 'Customer',
          remarks: returnData.reason || 'Customer Return',
          date: new Date().toLocaleDateString('en-PK'),
          time: new Date().toLocaleTimeString('en-PK'),
          transactionId
        };
        await DB.repo('inventory_ledger').insert(ledgerEntry);

        // Adjust customer balance if credit applied
        if (returnData.customerId) {
          const cust = await DB.repo('customers').get(returnData.customerId);
          if (cust) {
            cust.balance = (Number(cust.balance) || 0) - returnRecord.totalRefund;
            await DB.repo('customers').update(cust);
          }
        }

        await this.logAudit('RETURN_PROCESSED', comb.productName, prevStock, newStock, `Returned ${qty} boxes`, transactionId);

        return { success: true, combination: comb, returnRecord };
      }
    );
  }

  async processExchange(exchangeData) {
    const transactionId = SyncEngine.generateUUID();
    return await DB.runTransaction(
      ['combinations', 'inventory_ledger', 'exchanges', 'audit_logs'],
      'readwrite',
      async () => {
        const inComb = await DB.repo('combinations').get(exchangeData.inCombinationId);
        const outComb = await DB.repo('combinations').get(exchangeData.outCombinationId);

        if (!inComb || !outComb) throw new Error('One or both products not found.');
        if (outComb.stock < exchangeData.outQty) {
          throw new Error(`Insufficient stock for exchange item '${outComb.productName}'!`);
        }

        // Return Item IN
        inComb.stock = inComb.stock + exchangeData.inQty;
        await DB.repo('combinations').update(inComb);

        // Replacement Item OUT
        outComb.stock = outComb.stock - exchangeData.outQty;
        await DB.repo('combinations').update(outComb);

        const exchangeRecord = {
          id: SyncEngine.generateUUID(),
          customerId: exchangeData.customerId || '',
          customerName: exchangeData.customerName || 'Customer',
          inCombinationId: inComb.id,
          inProductName: inComb.productName,
          inQty: exchangeData.inQty,
          outCombinationId: outComb.id,
          outProductName: outComb.productName,
          outQty: exchangeData.outQty,
          rateDifference: exchangeData.rateDifference || 0,
          date: new Date().toLocaleDateString('en-PK'),
          time: new Date().toLocaleTimeString('en-PK'),
          transactionId
        };
        await DB.repo('exchanges').insert(exchangeRecord);

        // Ledgers
        await DB.repo('inventory_ledger').insert({
          id: SyncEngine.generateUUID(),
          combinationId: inComb.id,
          productName: inComb.productName,
          type: 'EXCHANGE_IN',
          refType: 'EXCHANGE',
          refId: exchangeRecord.id,
          prevQty: inComb.stock - exchangeData.inQty,
          deltaQty: exchangeData.inQty,
          newQty: inComb.stock,
          party: exchangeData.customerName,
          date: new Date().toLocaleDateString('en-PK'),
          time: new Date().toLocaleTimeString('en-PK'),
          transactionId
        });

        await DB.repo('inventory_ledger').insert({
          id: SyncEngine.generateUUID(),
          combinationId: outComb.id,
          productName: outComb.productName,
          type: 'EXCHANGE_OUT',
          refType: 'EXCHANGE',
          refId: exchangeRecord.id,
          prevQty: outComb.stock + exchangeData.outQty,
          deltaQty: -exchangeData.outQty,
          newQty: outComb.stock,
          party: exchangeData.customerName,
          date: new Date().toLocaleDateString('en-PK'),
          time: new Date().toLocaleTimeString('en-PK'),
          transactionId
        });

        await this.logAudit('EXCHANGE_PROCESSED', `${inComb.productName} <-> ${outComb.productName}`, 'In/Out', 'Completed', 'Product exchange processed', transactionId);

        return { success: true, exchangeRecord };
      }
    );
  }

  // --- Parties CRUD & History (Phase 8) ---
  async addParty(partyObj) {
    if (!partyObj.name) throw new Error('Party Name is required.');
    const storeMap = {
      customer: 'customers',
      dealer: 'dealers',
      retailer: 'customers', // Retailers are tracked with customers
      supplier: 'suppliers'
    };
    const storeName = storeMap[partyObj.type] || 'customers';

    // Duplicate mobile check
    if (partyObj.mobile) {
      const existing = (await DB.repo(storeName).getAll()).find(p => p.mobile === partyObj.mobile);
      if (existing) {
        throw new Error(`اس موبائل نمبر (${partyObj.mobile}) کے ساتھ '${existing.name}' پہلے سے موجود ہے۔`);
      }
    }

    partyObj.id = (partyObj.type ? partyObj.type.slice(0, 4) : 'cust') + '_' + Date.now().toString(36);
    partyObj.balance = Number(partyObj.openingBalance) || 0;
    partyObj.status = 'active';
    partyObj.createdAt = new Date().toISOString();

    const created = await DB.repo(storeName).insert(partyObj);
    await this.refreshCache();
    await this.logAudit('PARTY_CREATED', partyObj.name, 'None', partyObj.type, 'New party registered');
    return created;
  }

  async updateParty(partyObj) {
    const storeMap = {
      customer: 'customers',
      dealer: 'dealers',
      retailer: 'customers',
      supplier: 'suppliers'
    };
    const storeName = storeMap[partyObj.type] || 'customers';
    partyObj.updatedAt = new Date().toISOString();
    const updated = await DB.repo(storeName).update(partyObj);
    await this.refreshCache();
    await this.logAudit('PARTY_UPDATED', partyObj.name, 'Active', 'Updated', 'Party details modified');
    return updated;
  }

  async deletePartyWithIntegrityCheck(partyId, partyType) {
    const storeMap = {
      customer: 'customers',
      dealer: 'dealers',
      retailer: 'customers',
      supplier: 'suppliers'
    };
    const storeName = storeMap[partyType] || 'customers';
    const party = await DB.repo(storeName).get(partyId);
    if (!party) throw new Error('Party not found.');

    const invoices = (await DB.repo('invoices').getAll()).filter(inv => inv.customerId === partyId);
    const transactions = (await DB.repo('stock_transactions').getAll()).filter(tx => tx.partyName === party.name);

    if (invoices.length > 0 || transactions.length > 0 || (Number(party.balance) || 0) !== 0) {
      party.status = 'archived';
      party.updatedAt = new Date().toISOString();
      await DB.repo(storeName).update(party);
      await this.logAudit('PARTY_ARCHIVED', party.name, 'active', 'archived', 'Archived instead of delete due to financial or stock transactions');
      return { archived: true, message: 'اس پارٹی کے بلز یا بقایا جات موجود ہیں، لہٰذا اسے محفوظ طور پر آرکائیو (غیر فعال) کر دیا گیا ہے۔' };
    }

    await DB.repo(storeName).delete(partyId);
    await this.refreshCache();
    await this.logAudit('PARTY_DELETED', party.name, 'Active', 'Deleted', 'Party deleted permanently');
    return { archived: false, message: 'پارٹی کامیابی سے حذف ہو گئی۔' };
  }

  async getPartyHistory(partyId, partyType) {
    const storeMap = {
      customer: 'customers',
      dealer: 'dealers',
      retailer: 'customers',
      supplier: 'suppliers'
    };
    const storeName = storeMap[partyType] || 'customers';
    const party = await DB.repo(storeName).get(partyId);
    if (!party) return { invoices: [], transactions: [], party: null };

    const invoices = (await DB.repo('invoices').getAll()).filter(inv => inv.customerId === partyId);
    const transactions = (await DB.repo('stock_transactions').getAll()).filter(tx => tx.partyName === party.name);
    const ledgers = (await DB.repo('inventory_ledger').getAll()).filter(l => l.party === party.name);

    return {
      party,
      invoices,
      transactions,
      ledgers
    };
  }


  // --- Customer & Party Autocomplete Search (Phase 4) ---
  async searchParties(query) {
    if (!query || !query.trim()) return [];
    const tokens = query.toLowerCase().trim().split(/\s+/);
    const customers = await DB.repo('customers').getAll();
    const dealers = await DB.repo('dealers').getAll();
    const suppliers = await DB.repo('suppliers').getAll();

    const allParties = [
      ...customers.map(c => ({ ...c, partyType: 'Customer' })),
      ...dealers.map(d => ({ ...d, partyType: 'Dealer' })),
      ...suppliers.map(s => ({ ...s, partyType: 'Supplier' }))
    ].filter(p => p.status !== 'archived');

    return allParties.filter(p => {
      const text = [
        p.name || '',
        p.mobile || '',
        p.whatsapp || '',
        p.city || '',
        p.businessName || '',
        p.partyType || '',
        p.address || ''
      ].join(' ').toLowerCase();
      return tokens.every(token => text.includes(token));
    });
  }

}

const Store = new StoreEngine();
