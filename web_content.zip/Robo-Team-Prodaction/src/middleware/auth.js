function requireAuth(req,res,next){if(!req.session.user)return res.status(401).json({error:'Алдымен жүйеге кіріңіз.'});next()}
function requireStudent(req,res,next){requireAuth(req,res,()=>{if(!['student','admin'].includes(req.session.user.role))return res.status(403).json({error:'Бұл бөлім тек оқушыларға арналған.'});next()})}
function requireAdmin(req,res,next){requireAuth(req,res,()=>{if(req.session.user.role!=='admin'||req.session.user.id!=='00000000')return res.status(403).json({error:'Әкімші рұқсаты қажет.'});next()})}
module.exports={requireAuth,requireStudent,requireAdmin};
