EUZZHEN PSN MANAGER — ANDROID PROJECT
====================================

This is the Android source project for the EUZZHEN PSN MANAGER companion app.
It includes a WebView version of the interface and a native FTP bridge.

CURRENT FEATURES
- Connect to a PS4 FTP service by local IPv4 address and port
- Optional username/password fields (use the same settings as your working FTP client)
- List remote directories
- Download files to the app's private Downloads/EUZZHEN folder
- Choose a file from Android storage and upload it
- Rename remote files
- Save the dashboard's connection notes in browser local storage

IMPORTANT
- This app does not jailbreak a console, run payloads, install plugins, or modify PSN accounts.
- FTP is unencrypted. Use it only on your trusted local Wi-Fi network.
- Use the same host, port, and login mode that already work in your FTP client.
- The app source is provided; an APK has not been compiled or tested on your specific phone.
- Do not modify system/account files. Keep backups before file changes.

BUILD ON ANDROID
1. Install a trusted Android IDE that supports Gradle Android projects.
2. Extract this ZIP into a folder on your phone.
3. Open the extracted EuzzhenPSNManager project folder in the IDE.
4. Allow Gradle to sync and download the Android Gradle Plugin, Kotlin plugin, and Commons Net dependency.
5. Build the app's debug APK from the IDE's Build menu.
6. Install the debug APK on your phone.

PROJECT SETTINGS
- Application ID: com.euzzhen.psnmanager
- Minimum Android: 8.0 (API 26)
- Compile/Target SDK: 35
- Version: 1.0
