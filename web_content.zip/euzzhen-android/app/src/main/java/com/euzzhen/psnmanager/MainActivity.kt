package com.euzzhen.psnmanager

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import org.apache.commons.net.ftp.FTPFile
import org.apache.commons.net.ftp.FTPReply
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val ftp = FTPClient()
    private var pickedUri: Uri? = null
    private val pickRequest = 4107

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(FtpBridge(), "Euzzhen")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onDestroy() {
        try { if (ftp.isConnected) ftp.disconnect() } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun result(ok: Boolean, message: String, extra: JSONObject? = null): String {
        val obj = JSONObject()
        obj.put("ok", ok)
        obj.put("message", message)
        if (extra != null) {
            val keys = extra.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                obj.put(key, extra.get(key))
            }
        }
        return obj.toString()
    }

    private fun safeRemote(path: String): String {
        val clean = path.trim().replace('\\', '/')
        require(!clean.split('/').contains("..")) { "Parent-directory paths are not allowed." }
        return if (clean.startsWith("/")) clean else "/$clean"
    }

    inner class FtpBridge {
        @JavascriptInterface
        fun connect(host: String, port: Int, username: String, password: String): String {
            return try {
                synchronized(ftp) {
                    if (ftp.isConnected) try { ftp.logout(); ftp.disconnect() } catch (_: Exception) {}
                    require(host.matches(Regex("""[0-9]{1,3}(\.[0-9]{1,3}){3}"""))) { "Enter the PS4 local IPv4 address." }
                    require(port in 1..65535) { "FTP port is invalid." }
                    ftp.connectTimeout = 7000
                    ftp.defaultTimeout = 7000
                    ftp.dataTimeout = java.time.Duration.ofSeconds(12)
                    ftp.controlEncoding = "UTF-8"
                    ftp.connect(host, port)
                    if (!FTPReply.isPositiveCompletion(ftp.replyCode)) {
                        ftp.disconnect()
                        return@synchronized result(false, "PS4 FTP service did not accept the connection.")
                    }
                    val loginName = username.ifBlank { "anonymous" }
                    if (!ftp.login(loginName, password)) {
                        ftp.disconnect()
                        return@synchronized result(false, "FTP login was rejected. Check the same login settings used in your FTP client.")
                    }
                    ftp.enterLocalPassiveMode()
                    ftp.setFileType(FTP.BINARY_FILE_TYPE)
                    result(true, "Connected to $host:$port.")
                }
            } catch (e: Exception) {
                try { if (ftp.isConnected) ftp.disconnect() } catch (_: Exception) {}
                result(false, e.message ?: "Could not connect to the FTP service.")
            }
        }

        @JavascriptInterface
        fun list(path: String): String {
            return try {
                synchronized(ftp) {
                    if (!ftp.isConnected) return@synchronized result(false, "Connect to your PS4 first.")
                    val safe = safeRemote(path)
                    val files: Array<FTPFile> = ftp.listFiles(safe)
                    if (ftp.replyCode >= 400) return@synchronized result(false, "Could not read this directory. Check the path and permissions.")
                    val arr = JSONArray()
                    files.filter { it.name != "." && it.name != ".." }.forEach { f ->
                        val item = JSONObject()
                        item.put("name", f.name)
                        item.put("directory", f.isDirectory)
                        item.put("size", f.size)
                        item.put("modified", f.timestamp?.time?.time ?: 0L)
                        arr.put(item)
                    }
                    val extra = JSONObject()
                    extra.put("files", arr)
                    result(true, "Directory loaded.", extra)
                }
            } catch (e: Exception) { result(false, e.message ?: "Directory listing failed.") }
        }

        @JavascriptInterface
        fun download(remotePath: String): String {
            return try {
                synchronized(ftp) {
                    if (!ftp.isConnected) return@synchronized result(false, "Connect to your PS4 first.")
                    val safe = safeRemote(remotePath)
                    val name = safe.substringAfterLast('/').ifBlank { "download.bin" }
                    val dir = File(getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS), "EUZZHEN")
                    if (!dir.exists()) dir.mkdirs()
                    val out = File(dir, name)
                    val ok = FileOutputStream(out).use { stream -> ftp.retrieveFile(safe, stream) }
                    if (ok) result(true, "Saved to app Downloads: ${out.absolutePath}")
                    else { out.delete(); result(false, "Download failed. Check the remote file and permissions.") }
                }
            } catch (e: Exception) { result(false, e.message ?: "Download failed.") }
        }

        @JavascriptInterface
        fun pickFile() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(intent, pickRequest)
            }
        }

        @JavascriptInterface
        fun upload(uriText: String, remotePath: String): String {
            return try {
                synchronized(ftp) {
                    if (!ftp.isConnected) return@synchronized result(false, "Connect to your PS4 first.")
                    val uri = Uri.parse(uriText)
                    val safe = safeRemote(remotePath)
                    val input: InputStream = contentResolver.openInputStream(uri)
                        ?: return@synchronized result(false, "Android could not open the selected file.")
                    val ok = input.use { ftp.storeFile(safe, it) }
                    if (ok) result(true, "Upload complete: $safe")
                    else result(false, "Upload failed. Check the destination folder and permissions.")
                }
            } catch (e: Exception) { result(false, e.message ?: "Upload failed.") }
        }

        @JavascriptInterface
        fun rename(oldPath: String, newPath: String): String {
            return try {
                synchronized(ftp) {
                    if (!ftp.isConnected) return@synchronized result(false, "Connect to your PS4 first.")
                    val from = safeRemote(oldPath)
                    val to = safeRemote(newPath)
                    if (ftp.rename(from, to)) result(true, "Remote file renamed.")
                    else result(false, "Rename failed. Check permissions and destination name.")
                }
            } catch (e: Exception) { result(false, e.message ?: "Rename failed.") }
        }
    }

    @Deprecated("Deprecated by Android; retained for broad device compatibility.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickRequest && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            pickedUri = uri
            val name = queryDisplayName(uri) ?: "selected-file"
            val uriJs = JSONObject.quote(uri.toString())
            val nameJs = JSONObject.quote(name)
            webView.evaluateJavascript("window.onNativeFilePicked($uriJs,$nameJs)", null)
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (index >= 0 && cursor.moveToFirst()) cursor.getString(index) else null
        }
    }
}
