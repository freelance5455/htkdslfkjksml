'use strict';

const http = require('http');
const crypto = require('crypto');
const { WebSocketServer, WebSocket } = require('ws');

const PORT = Number(process.env.PORT || 8080);
const HOST = process.env.HOST || '0.0.0.0';
const MAX_ROOMS = Number(process.env.MAX_ROOMS || 1000);
const MAX_MEMBERS_PER_ROOM = Number(process.env.MAX_MEMBERS_PER_ROOM || 30);
const ROOM_TTL_MS = Number(process.env.ROOM_TTL_MS || 6 * 60 * 60 * 1000);
const MAX_MESSAGE_BYTES = 32 * 1024;
const rooms = new Map();

const server = http.createServer((req, res) => {
  if (req.url === '/health' || req.url === '/') {
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
    res.end(JSON.stringify({ ok: true, service: 'PINPLAY Listening Room', rooms: rooms.size }));
    return;
  }
  res.writeHead(404, { 'content-type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify({ ok: false, error: 'not_found' }));
});

const wss = new WebSocketServer({ server, path: '/ws', maxPayload: MAX_MESSAGE_BYTES, perMessageDeflate: false });

function send(ws, payload) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(payload));
}
function cleanCode(value) {
  return String(value || '').trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '').slice(0, 24);
}
function roomFor(code) {
  return rooms.get(code);
}
function sendError(ws, message) { send(ws, { type: 'error', message }); }
function broadcast(room, payload, except) {
  for (const client of room.members) if (client !== except) send(client, payload);
}
function leaveRoom(ws) {
  const code = ws.roomCode;
  if (!code) return;
  const room = rooms.get(code);
  ws.roomCode = null;
  if (!room) return;
  room.members.delete(ws);
  room.lastActive = Date.now();
  if (room.members.size) {
    broadcast(room, { type: 'member_left', room: code, message: 'Seorang anggota meninggalkan ruang.' });
  } else {
    rooms.delete(code);
  }
}
function joinRoom(ws, code, role) {
  const room = roomFor(code);
  if (!room) return sendError(ws, 'Ruang tidak ditemukan. Minta host membuat ruang terlebih dahulu.');
  if (room.members.size >= MAX_MEMBERS_PER_ROOM && !room.members.has(ws)) return sendError(ws, 'Ruang penuh.');
  leaveRoom(ws);
  room.members.add(ws);
  room.lastActive = Date.now();
  ws.roomCode = code;
  ws.role = role === 'host' ? 'host' : 'guest';
  send(ws, { type: 'joined', room: code, role: ws.role, members: room.members.size, message: `Berhasil bergabung ke ruang ${code}.` });
  broadcast(room, { type: 'member_joined', room: code, message: 'Anggota baru bergabung.' }, ws);
  if (room.state) send(ws, { ...room.state, room: code, message: 'Status pemutaran terbaru diterima.' });
}

wss.on('connection', (ws) => {
  ws.isAlive = true;
  ws.roomCode = null;
  ws.role = 'guest';
  ws.on('pong', () => { ws.isAlive = true; });

  send(ws, { type: 'connected', message: 'PINPLAY Listening Room backend siap.' });
  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return sendError(ws, 'Format pesan harus JSON.'); }
    if (!msg || typeof msg !== 'object' || Array.isArray(msg)) return sendError(ws, 'Pesan tidak valid.');
    const type = String(msg.type || '');

    if (type === 'ping') return send(ws, { type: 'pong', ts: Date.now() });

    if (type === 'create_room') {
      let code = cleanCode(msg.room) || crypto.randomBytes(3).toString('hex').toUpperCase();
      if (rooms.has(code)) return sendError(ws, 'Kode ruang sudah digunakan. Pilih kode lain.');
      if (rooms.size >= MAX_ROOMS) return sendError(ws, 'Server sedang penuh. Coba lagi nanti.');
      leaveRoom(ws);
      const room = { code, members: new Set(), state: null, createdAt: Date.now(), lastActive: Date.now() };
      rooms.set(code, room);
      joinRoom(ws, code, 'host');
      // Explicit event retained for compatibility with the PINPLAY client.
      send(ws, { type: 'room_created', room: code, role: 'host', message: `Ruang ${code} berhasil dibuat.` });
      return;
    }

    if (type === 'join_room') {
      const code = cleanCode(msg.room || ws.roomCode);
      if (!code) return sendError(ws, 'Masukkan kode ruang yang valid.');
      return joinRoom(ws, code, 'guest');
    }

    const code = cleanCode(msg.room || ws.roomCode);
    const room = roomFor(code);
    if (!room || !room.members.has(ws)) return sendError(ws, 'Bergabung ke ruang terlebih dahulu.');
    if (!['state', 'play', 'pause', 'seek', 'queue'].includes(type)) return sendError(ws, 'Jenis pesan tidak didukung.');

    const outgoing = {
      type,
      room: code,
      clientId: String(msg.clientId || '').slice(0, 80),
      ts: Date.now()
    };
    if (type === 'queue') {
      outgoing.tracks = Array.isArray(msg.tracks) ? msg.tracks.slice(0, 500) : [];
    } else {
      const song = msg.song && typeof msg.song === 'object' ? msg.song : null;
      if (song) outgoing.song = {
        title: String(song.title || '').slice(0, 200),
        artist: String(song.artist || '').slice(0, 200),
        key: String(song.key || '').slice(0, 500)
      };
      outgoing.time = Number.isFinite(Number(msg.time)) ? Math.max(0, Math.min(Number(msg.time), 24 * 60 * 60)) : 0;
      if (typeof msg.playing === 'boolean') outgoing.playing = msg.playing;
      room.state = outgoing;
    }
    room.lastActive = Date.now();
    broadcast(room, outgoing, ws);
  });

  ws.on('close', () => leaveRoom(ws));
  ws.on('error', () => leaveRoom(ws));
});

const heartbeat = setInterval(() => {
  const now = Date.now();
  for (const ws of wss.clients) {
    if (!ws.isAlive) { ws.terminate(); continue; }
    ws.isAlive = false;
    try { ws.ping(); } catch { ws.terminate(); }
  }
  for (const [code, room] of rooms) {
    if (!room.members.size || now - room.lastActive > ROOM_TTL_MS) {
      for (const member of room.members) {
        send(member, { type: 'error', message: 'Ruang berakhir karena tidak aktif.' });
        member.roomCode = null;
      }
      rooms.delete(code);
    }
  }
}, 30_000);
heartbeat.unref();

server.listen(PORT, HOST, () => {
  console.log(`PINPLAY Listening Room backend listening on ${HOST}:${PORT}; WebSocket path: /ws`);
});

function shutdown() {
  clearInterval(heartbeat);
  for (const ws of wss.clients) ws.close(1001, 'Server restarting');
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 5000).unref();
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
