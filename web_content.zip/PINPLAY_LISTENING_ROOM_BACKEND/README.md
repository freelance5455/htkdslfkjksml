# PINPLAY Listening Room Backend

Backend WebSocket sederhana untuk membuat room, bergabung dengan kode, dan meneruskan status lagu/play/pause/seek antaranggota. Ini adalah layanan server terpisah; file HTML PINPLAY tetap menjadi aplikasi frontend.

## Deploy paling mudah

Deploy folder ini ke layanan Node.js seperti Render, Railway, atau VPS. Buat **Web Service** dari repo yang berisi file-file ini.

- Runtime: Node.js
- Build/install command: `npm install`
- Start command: `npm start`
- Port: gunakan nilai `PORT` yang diberikan platform (server membaca `process.env.PORT` otomatis)
- Health check path (jika diminta): `/health`

Setelah deploy, salin URL HTTPS dari layanan. Untuk aplikasi PINPLAY, endpoint WebSocket biasanya:

`wss://NAMA-LAYANAN-KAMU.onrender.com/ws`

Ganti domain contoh di atas dengan domain asli hasil deploy. Jangan menggunakan URL contoh tersebut sebagai endpoint sungguhan.

## Cara pakai

1. Buka PINPLAY pada perangkat pertama dan perangkat kedua.
2. Buka fitur **Listening Room** di kedua perangkat.
3. Masukkan endpoint `wss://.../ws`, lalu tekan **Hubungkan**.
4. Di perangkat host, isi kode ruang (opsional) lalu tekan **Buat ruang**.
5. Di perangkat lain, masukkan kode yang sama lalu tekan **Gabung**.
6. Host tekan **Kirim lagu aktif** setelah memilih lagu. Gunakan **Sinkronkan Play/Pause** untuk mengirim status pemutaran.

## Catatan penting

- Backend hanya menyelaraskan metadata lagu dan perintah pemutaran; backend tidak mengirim atau meng-host audio. Setiap perangkat harus bisa memutar sumber lagu itu sendiri. Jika sebuah lagu tidak tersedia di katalog/perangkat lain, perangkat tersebut tidak dapat memutarnya secara otomatis.
- Beberapa browser memerlukan interaksi pengguna untuk mengizinkan audio autoplay. Bila perangkat tamu tidak mulai memutar otomatis, sentuh tombol play di perangkat itu.
- Room disimpan di memori proses dan hilang ketika server restart atau sleep. Untuk penggunaan serius/produksi, tambahkan autentikasi, rate limiting, penyimpanan persisten, dan aturan privasi.
- Untuk produksi, gunakan `wss://` melalui TLS dari platform hosting. `ws://` umumnya hanya untuk localhost/pengujian.
- Ini backend awal tanpa akun dan tanpa kata sandi room. Jangan gunakan untuk data privat.

## Local test

```bash
npm install
npm start
```

Health check: `http://localhost:8080/health`
WebSocket endpoint: `ws://localhost:8080/ws`
