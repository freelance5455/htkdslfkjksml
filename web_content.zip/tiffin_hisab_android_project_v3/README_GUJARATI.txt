TIFFIN HISAB ANDROID PROJECT v3.0
આ ZIP Android source project છે, APK નથી.

નવા / અપડેટ થયેલા ફીચર્સ:
- વ્યક્તિ ઉમેરતી વખતે માત્ર નામ; ટિફિનનો ભાવ અને રૂપિયા/Amount હટાવ્યા છે.
- Daily Entry માં દરેક વ્યક્તિ માટે Lunch, Dinner, Notes અને Paid/Unpaid.
- Daily Entry માં અલગ Extra Tiffin વિભાગ: તારીખ, ગમે તેટલી સંખ્યા, Paid/Unpaid અને Notes.
- Summary માં 6 બોક્સ: Total Tiffin, Total Paid, Total Unpaid Tiffin, Total Lunch, Total Dinner, Extra Paid Tiffin.
- Extra Tiffin Total Tiffin અને Paid/Unpaid ગણતરીમાં સામેલ થાય છે.
- Person-wise summary માં Total Tiffin, Paid અને Unpaid.
- Date-wise report માં Lunch, Dinner, Extra Tiffin અને Total.
- CSV export માં વ્યક્તિની તથા Extra Tiffin ની નોંધો.
- Offline local storage. અગાઉની v2 એપની local data key જાળવી છે જેથી જૂનો ડેટા ચાલુ રહે.

APK બનાવવા AndroidIDE અથવા Android Studioમાં project folder ખોલી Gradle sync કરો અને assembleDebug task ચલાવો.
APK: app/build/outputs/apk/debug/app-debug.apk
Build માટે Android SDK/JDK/Gradle setup અને internet જરૂરી છે. ZIP પોતે installable APK નથી.
ડેટા app ના સ્થાનિક storage માં રહે છે; uninstall/app data clear કરવાથી ગુમાઈ શકે છે. CSV backup રાખો.
