package com.sharkshot.app;
import android.app.Activity; import android.os.Bundle; import android.webkit.WebView; import android.webkit.WebSettings; import android.webkit.WebViewClient; import android.view.View;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle savedInstanceState){ super.onCreate(savedInstanceState); WebView web=new WebView(this); web.setBackgroundColor(0xff0b1425); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setLoadsImagesAutomatically(true); s.setAllowFileAccess(true); s.setAllowContentAccess(false); web.setWebViewClient(new WebViewClient()); setContentView(web); web.loadUrl("file:///android_asset/index.html"); }
 @Override public void onBackPressed(){ super.onBackPressed(); }
}
