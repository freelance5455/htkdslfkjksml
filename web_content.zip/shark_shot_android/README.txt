SHARK SHOT Android project

To build an APK:
1. Install Android Studio on a computer and open this folder as a project.
2. Allow Gradle sync/downloads.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The APK is generated in app/build/outputs/apk/debug/.

This project wraps the current HTML panel in a simple Android WebView. The HTML feed endpoint is not independently verified as MaanWin's official API. Live-feed availability can vary. No credentials or wallet access are used.
