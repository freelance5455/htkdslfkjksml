"""The Coffee Shop - MVP (Flask + SQLite). Run: python app.py seed ; python app.py"""
import os, re, sqlite3, secrets, time, sys, json
from urllib.parse import urlparse
from datetime import datetime, date, timezone
from flask import Flask, g, request, session, redirect, render_template, abort, flash, url_for
from jinja2 import DictLoader
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
_production = os.environ.get("APP_ENV", "").lower() == "production" or bool(os.environ.get("RENDER"))
_secret = os.environ.get("SECRET_KEY")
if _production and (not _secret or _secret == "dev-only-change-me"):
    raise RuntimeError("Set a strong SECRET_KEY environment variable before running in production.")
app.config.update(SECRET_KEY=_secret or "dev-only-change-me-local-only",
                  DATABASE=os.environ.get("DATABASE", "coffeeshop.db"), RATE_LIMIT=True,
                  SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                  SESSION_COOKIE_SECURE=_production, MAX_CONTENT_LENGTH=1024 * 1024)
TYPES = {"text": "Text Post", "book_review": "Book Review", "music_review": "Music Review",
         "question": "Question", "story": "Story", "faith": "Faith & Life"}
SCHEMA = """
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, display_name TEXT, bio TEXT DEFAULT '', pw TEXT NOT NULL, role TEXT DEFAULT 'user', created_at TEXT);
CREATE TABLE IF NOT EXISTS posts(id INTEGER PRIMARY KEY, author_id INT NOT NULL REFERENCES users(id), type TEXT NOT NULL, title TEXT, body TEXT NOT NULL, tags TEXT DEFAULT '', spoiler INT DEFAULT 0, cw TEXT DEFAULT '', group_id INT, status TEXT DEFAULT 'ok', created_at TEXT);
CREATE TABLE IF NOT EXISTS reviews(post_id INT PRIMARY KEY REFERENCES posts(id), media_type TEXT, item_title TEXT, creator TEXT, year INT, rating INT CHECK(rating BETWEEN 1 AND 5));
CREATE TABLE IF NOT EXISTS comments(id INTEGER PRIMARY KEY, post_id INT NOT NULL, author_id INT NOT NULL, parent_id INT, body TEXT NOT NULL, status TEXT DEFAULT 'ok', created_at TEXT);
CREATE TABLE IF NOT EXISTS reactions(user_id INT, post_id INT, UNIQUE(user_id, post_id));
CREATE TABLE IF NOT EXISTS bookmarks(user_id INT, post_id INT, UNIQUE(user_id, post_id));
CREATE TABLE IF NOT EXISTS follows(follower_id INT, followed_id INT, UNIQUE(follower_id, followed_id));
CREATE TABLE IF NOT EXISTS groups(id INTEGER PRIMARY KEY, name TEXT, slug TEXT UNIQUE, description TEXT, rules TEXT);
CREATE TABLE IF NOT EXISTS group_members(group_id INT, user_id INT, role TEXT DEFAULT 'member', UNIQUE(group_id, user_id));
CREATE TABLE IF NOT EXISTS news(id INTEGER PRIMARY KEY, headline TEXT, summary TEXT, source_name TEXT, source_url TEXT, published_at TEXT, category TEXT, kind TEXT DEFAULT 'reporting', status TEXT DEFAULT 'published', created_by INT, updated_at TEXT);
CREATE TABLE IF NOT EXISTS news_comments(id INTEGER PRIMARY KEY, article_id INT, author_id INT, body TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS playlists(id INTEGER PRIMARY KEY, title TEXT, mood TEXT);
CREATE TABLE IF NOT EXISTS tracks(id INTEGER PRIMARY KEY, playlist_id INT, title TEXT, artist TEXT, stream_url TEXT DEFAULT '', license_type TEXT NOT NULL, rights_holder TEXT NOT NULL, attribution TEXT DEFAULT '', license_expiry TEXT, active INT DEFAULT 1);
CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY, recipient_id INT, actor_id INT, kind TEXT, post_id INT, read INT DEFAULT 0, created_at TEXT);
CREATE TABLE IF NOT EXISTS reports(id INTEGER PRIMARY KEY, reporter_id INT, target_type TEXT, target_id INT, reason TEXT, status TEXT DEFAULT 'open', created_at TEXT);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, admin_id INT, action TEXT, target TEXT, created_at TEXT);
CREATE UNIQUE INDEX IF NOT EXISTS users_username_nocase ON users(username COLLATE NOCASE);
"""

def db():
    if "db" not in g:
        db_path = app.config["DATABASE"]
        if db_path != ":memory:":
            parent = os.path.dirname(os.path.abspath(db_path))
            os.makedirs(parent, exist_ok=True)
        g.db = sqlite3.connect(db_path, timeout=10)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys=ON")
        g.db.execute("PRAGMA busy_timeout=10000")
        if db_path != ":memory:": g.db.execute("PRAGMA journal_mode=WAL")
        g.db.executescript(SCHEMA)
    return g.db
@app.teardown_appcontext
def close_db(_):
    d = g.pop("db", None)
    if d: d.commit(); d.close()
def now(): return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

def valid_https_url(value):
    """Accept only absolute HTTPS links with a hostname and no embedded credentials."""
    try:
        u = urlparse(value or "")
        return u.scheme == "https" and bool(u.hostname) and not u.username and not u.password
    except (ValueError, TypeError):
        return False

def safe_local_redirect(value, fallback="/"):
    # Never redirect to a caller-controlled external host.
    if not value: return fallback
    try:
        u = urlparse(value)
        if not u.scheme and not u.netloc and value.startswith("/") and not value.startswith("//"):
            return value
    except ValueError:
        pass
    return fallback
def q(sql, *a): return db().execute(sql, a).fetchall()
def q1(sql, *a): return db().execute(sql, a).fetchone()
def ex(sql, *a): return db().execute(sql, a).lastrowid

@app.before_request
def guard():
    g.user = q1("SELECT * FROM users WHERE id=?", session["uid"]) if "uid" in session else None
    session.setdefault("csrf", secrets.token_hex(16))
    if request.method == "POST":
        if not secrets.compare_digest(request.form.get("csrf_token", ""), session["csrf"]): abort(400, "Bad CSRF token")
        if app.config["RATE_LIMIT"]:
            hits = RATE.setdefault((request.remote_addr, request.endpoint), [])
            hits[:] = [t for t in hits if t > time.time() - 60]
            if len(hits) >= 20: abort(429)
            hits.append(time.time())
RATE = {}
app.jinja_env.globals["csrf"] = lambda: session.get("csrf", "")
app.jinja_env.globals["TYPES"] = TYPES

def need_login():
    if not g.user: abort(401)
def need_role(*roles):
    need_login()
    if g.user["role"] not in roles: abort(403)
def clean(s, n): return (s or "").strip()[:n]
@app.errorhandler(401)
def e401(e): return redirect(url_for("login"))
for code in (400, 403, 404, 429):
    app.register_error_handler(code, lambda e: (render_template("err.html", e=e), e.code))

POSTQ = """SELECT p.*, u.username, u.display_name, r.media_type, r.item_title, r.creator, r.year, r.rating,
 (SELECT COUNT(*) FROM reactions WHERE post_id=p.id) likes, (SELECT COUNT(*) FROM comments c WHERE c.post_id=p.id AND c.status='ok') replies
 FROM posts p JOIN users u ON u.id=p.author_id LEFT JOIN reviews r ON r.post_id=p.id WHERE p.status='ok' """

@app.route("/")
def home():
    t, tab, where, args = request.args.get("type", ""), request.args.get("tab", "latest"), "", []
    if t in TYPES: where += " AND p.type=?"; args.append(t)
    if tab == "following" and g.user:
        where += " AND p.author_id IN (SELECT followed_id FROM follows WHERE follower_id=?)"; args.append(g.user["id"])
    where += " AND p.group_id IS NULL"
    posts = q(POSTQ + where + " ORDER BY p.id DESC LIMIT 50", *args)
    news = q("SELECT * FROM news WHERE status='published' ORDER BY published_at DESC LIMIT 2")
    return render_template("home.html", posts=posts, news=news, t=t, tab=tab)

@app.route("/search")
def search():
    s = clean(request.args.get("q"), 80); like = f"%{s}%"
    posts = q(POSTQ + " AND (p.title LIKE ? OR p.body LIKE ? OR p.tags LIKE ? OR r.item_title LIKE ? OR r.creator LIKE ?) ORDER BY p.id DESC LIMIT 50", *[like]*5) if s else []
    groups = q("SELECT * FROM groups WHERE name LIKE ? OR description LIKE ?", like, like) if s else []
    people = q("SELECT username, display_name FROM users WHERE username LIKE ? OR display_name LIKE ? LIMIT 20", like, like) if s else []
    return render_template("search.html", s=s, posts=posts, groups=groups, people=people)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        u, p = clean(request.form.get("username"), 20), request.form.get("password", "")
        if not re.fullmatch(r"[A-Za-z0-9_]{3,20}", u): flash("Username: 3-20 letters, numbers, underscores.")
        elif len(p) < 8: flash("Password must be at least 8 characters.")
        elif len(p) > 128: flash("Password must be 128 characters or fewer.")
        elif q1("SELECT 1 FROM users WHERE username=? COLLATE NOCASE", u): flash("That username is taken.")
        else:
            first = q1("SELECT COUNT(*) c FROM users")["c"] == 0
            has_admin = q1("SELECT 1 FROM users WHERE role='admin' LIMIT 1") is not None
            # In production, only the configured bootstrap username can become admin.
            # Local development keeps first-user admin convenience for a single-user demo.
            bootstrap = os.environ.get("BOOTSTRAP_ADMIN_USERNAME", "").strip().lower()
            make_admin = (not has_admin and bool(bootstrap) and u.lower() == bootstrap) or (first and not _production and not bootstrap)
            uid = ex("INSERT INTO users(username,display_name,pw,role,created_at) VALUES(?,?,?,?,?)",
                     u, clean(request.form.get("display_name"), 40) or u, generate_password_hash(p), "admin" if make_admin else "user", now())
            session.clear(); session["uid"] = uid; return redirect("/")
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = q1("SELECT * FROM users WHERE username=? COLLATE NOCASE", clean(request.form.get("username"), 20))
        if u and check_password_hash(u["pw"], request.form.get("password", "")):
            session.clear(); session["uid"] = u["id"]; return redirect("/")
        flash("Wrong username or password.")
    return render_template("auth.html", mode="login")

@app.route("/logout", methods=["POST"])
def logout(): session.clear(); return redirect("/")

@app.route("/new", methods=["GET", "POST"])
def new_post():
    need_login(); gslug = request.args.get("group") or request.form.get("group", "")
    grp = q1("SELECT * FROM groups WHERE slug=?", gslug) if gslug else None
    if request.method == "POST":
        t, body = request.form.get("type"), clean(request.form.get("body"), 5000)
        if t not in TYPES or not body:
            flash("Pick a type and write something."); return render_template("new.html", grp=grp)
        if gslug and not grp: abort(404)
        meta = None
        if t in ("book_review", "music_review"):
            title, creator = clean(request.form.get("item_title"), 150), clean(request.form.get("creator"), 100)
            try: rating = int(request.form.get("rating", 0)); year = int(request.form.get("year") or 0) or None
            except ValueError: rating = 0; year = None
            if year is not None and not 1000 <= year <= 2100: year = None
            if not title or not creator or not 1 <= rating <= 5:
                flash("Reviews need a title, author/artist and a 1-5 rating."); return render_template("new.html", grp=grp)
            meta = (t.split("_")[0], title, creator, year, rating)
        if grp and not q1("SELECT 1 FROM group_members WHERE group_id=? AND user_id=?", grp["id"], g.user["id"]): abort(403)
        pid = ex("INSERT INTO posts(author_id,type,title,body,tags,spoiler,cw,group_id,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                 g.user["id"], t, clean(request.form.get("title"), 150), body, clean(request.form.get("tags"), 100),
                 int(bool(request.form.get("spoiler"))), clean(request.form.get("cw"), 100), grp["id"] if grp else None, now())
        if meta: ex("INSERT INTO reviews VALUES(?,?,?,?,?,?)", pid, *meta)
        return redirect(f"/post/{pid}")
    return render_template("new.html", grp=grp)

def tree(rows, parent=None):
    return [{"c": r, "kids": tree(rows, r["id"])} for r in rows if r["parent_id"] == parent]

@app.route("/post/<int:pid>")
def post(pid):
    p = q1(POSTQ + " AND p.id=?", pid) or abort(404)
    cs = q("SELECT c.*, u.username FROM comments c JOIN users u ON u.id=c.author_id WHERE c.post_id=? AND c.status='ok' ORDER BY c.id", pid)
    me = g.user["id"] if g.user else 0
    return render_template("post.html", p=p, cs=tree(cs), liked=q1("SELECT 1 FROM reactions WHERE user_id=? AND post_id=?", me, pid),
                           saved=q1("SELECT 1 FROM bookmarks WHERE user_id=? AND post_id=?", me, pid))

@app.route("/post/<int:pid>/comment", methods=["POST"])
def comment(pid):
    need_login(); p = q1("SELECT * FROM posts WHERE id=? AND status='ok'", pid) or abort(404)
    body, parent = clean(request.form.get("body"), 2000), request.form.get("parent_id") or None
    parent_row = None
    if parent:
        try: parent_id = int(parent)
        except (TypeError, ValueError): abort(400)
        parent_row = q1("SELECT * FROM comments WHERE id=? AND post_id=? AND status='ok'", parent_id, pid)
        if not parent_row: abort(400)
        parent = parent_id
    if body:
        ex("INSERT INTO comments(post_id,author_id,parent_id,body,created_at) VALUES(?,?,?,?,?)", pid, g.user["id"], parent, body, now())
        recipients = set()
        if p["author_id"] != g.user["id"]: recipients.add(p["author_id"])
        if parent_row and parent_row["author_id"] != g.user["id"]: recipients.add(parent_row["author_id"])
        for recipient in recipients:
            ex("INSERT INTO notifications(recipient_id,actor_id,kind,post_id,created_at) VALUES(?,?,?,?,?)", recipient, g.user["id"], "reply", pid, now())
    return redirect(f"/post/{pid}")

def toggle(table, pid):
    need_login(); q1("SELECT 1 FROM posts WHERE id=?", pid) or abort(404)
    if q1(f"SELECT 1 FROM {table} WHERE user_id=? AND post_id=?", g.user["id"], pid): ex(f"DELETE FROM {table} WHERE user_id=? AND post_id=?", g.user["id"], pid)
    else: ex(f"INSERT INTO {table} VALUES(?,?)", g.user["id"], pid)
    return redirect(f"/post/{pid}")
@app.route("/post/<int:pid>/like", methods=["POST"])
def like(pid): return toggle("reactions", pid)
@app.route("/post/<int:pid>/save", methods=["POST"])
def save(pid): return toggle("bookmarks", pid)

@app.route("/post/<int:pid>/delete", methods=["POST"])
def delete_post(pid):
    need_login(); p = q1("SELECT * FROM posts WHERE id=?", pid) or abort(404)
    if p["author_id"] != g.user["id"] and g.user["role"] not in ("admin", "moderator"): abort(403)
    ex("UPDATE posts SET status='removed' WHERE id=?", pid)
    if p["author_id"] != g.user["id"]: ex("INSERT INTO audit(admin_id,action,target,created_at) VALUES(?,?,?,?)", g.user["id"], "remove_post", f"post:{pid}", now())
    return redirect("/")

@app.route("/report", methods=["POST"])
def report():
    need_login(); tt = request.form.get("target_type")
    if tt not in ("post", "comment"): abort(400)
    try: target_id = int(request.form.get("target_id", ""))
    except (TypeError, ValueError): abort(400)
    if target_id < 1: abort(400)
    table = "posts" if tt == "post" else "comments"
    target = q1(f"SELECT id FROM {table} WHERE id=? AND status='ok'", target_id)
    if not target: abort(404)
    if q1("SELECT 1 FROM reports WHERE reporter_id=? AND target_type=? AND target_id=? AND status='open'", g.user["id"], tt, target_id):
        flash("You've already reported this item. A moderator will review it.")
    else:
        ex("INSERT INTO reports(reporter_id,target_type,target_id,reason,created_at) VALUES(?,?,?,?,?)", g.user["id"], tt, target_id, clean(request.form.get("reason"), 300) or "Community guidelines concern", now())
        flash("Thanks - a moderator will take a look.")
    return redirect(safe_local_redirect(request.referrer, "/"))

@app.route("/admin/reports", methods=["GET", "POST"])
def admin_reports():
    need_role("admin", "moderator")
    if request.method == "POST":
        try: report_id = int(request.form.get("id", ""))
        except (TypeError, ValueError): abort(400)
        r = q1("SELECT * FROM reports WHERE id=?", report_id) or abort(404); act = request.form.get("action")
        if act not in ("remove", "dismiss"): abort(400)
        if act == "remove":
            ex("UPDATE posts SET status='removed' WHERE id=?" if r["target_type"] == "post" else "UPDATE comments SET status='removed' WHERE id=?", r["target_id"])
        ex("UPDATE reports SET status=? WHERE id=?", "actioned" if act == "remove" else "dismissed", r["id"])
        ex("INSERT INTO audit(admin_id,action,target,created_at) VALUES(?,?,?,?)", g.user["id"], f"report_{act}", f"{r['target_type']}:{r['target_id']}", now())
        return redirect("/admin/reports")
    return render_template("reports.html", rs=q("SELECT * FROM reports WHERE status='open' ORDER BY id DESC"))

@app.route("/u/<username>")
def profile(username):
    u = q1("SELECT * FROM users WHERE username=? COLLATE NOCASE", username) or abort(404)
    tab = request.args.get("tab", "posts"); me = g.user["id"] if g.user else 0
    if tab == "saved" and me == u["id"]: posts = q(POSTQ + " AND p.id IN (SELECT post_id FROM bookmarks WHERE user_id=?) ORDER BY p.id DESC", u["id"])
    else: posts = q(POSTQ + " AND p.author_id=? ORDER BY p.id DESC", u["id"])
    return render_template("profile.html", u=u, posts=posts, tab=tab, followers=q1("SELECT COUNT(*) c FROM follows WHERE followed_id=?", u["id"])["c"],
                           following=q1("SELECT 1 FROM follows WHERE follower_id=? AND followed_id=?", me, u["id"]))

@app.route("/u/<username>/follow", methods=["POST"])
def follow(username):
    need_login(); u = q1("SELECT id FROM users WHERE username=?", username) or abort(404)
    if u["id"] != g.user["id"]:
        if q1("SELECT 1 FROM follows WHERE follower_id=? AND followed_id=?", g.user["id"], u["id"]): ex("DELETE FROM follows WHERE follower_id=? AND followed_id=?", g.user["id"], u["id"])
        else: ex("INSERT INTO follows VALUES(?,?)", g.user["id"], u["id"])
    return redirect(f"/u/{username}")

@app.route("/settings", methods=["GET", "POST"])
def settings():
    need_login()
    if request.method == "POST":
        ex("UPDATE users SET display_name=?, bio=? WHERE id=?", clean(request.form.get("display_name"), 40) or g.user["username"], clean(request.form.get("bio"), 300), g.user["id"])
        flash("Profile saved."); return redirect("/settings")
    return render_template("settings.html")

@app.route("/groups")
def groups():
    return render_template("groups.html", gs=q("SELECT g.*, (SELECT COUNT(*) FROM group_members m WHERE m.group_id=g.id) n FROM groups g ORDER BY n DESC"))

@app.route("/g/<slug>")
def group(slug):
    gr = q1("SELECT * FROM groups WHERE slug=?", slug) or abort(404)
    me = g.user["id"] if g.user else 0; m = q1("SELECT * FROM group_members WHERE group_id=? AND user_id=?", gr["id"], me)
    return render_template("group.html", gr=gr, m=m, posts=q(POSTQ + " AND p.group_id=? ORDER BY p.id DESC", gr["id"]))

@app.route("/g/<slug>/<act>", methods=["POST"])
def group_act(slug, act):
    need_login(); gr = q1("SELECT * FROM groups WHERE slug=?", slug) or abort(404)
    if act == "join": ex("INSERT OR IGNORE INTO group_members(group_id,user_id) VALUES(?,?)", gr["id"], g.user["id"])
    elif act == "leave": ex("DELETE FROM group_members WHERE group_id=? AND user_id=?", gr["id"], g.user["id"])
    else: abort(404)
    return redirect(f"/g/{slug}")

NEWS_CATS = ["Top Stories", "World", "Local", "Culture", "Books", "Music", "Technology", "Lifestyle"]
@app.route("/news")
def news():
    c = request.args.get("cat"); rows = q("SELECT * FROM news WHERE status='published' AND (? IS NULL OR category=?) ORDER BY published_at DESC", c, c)
    return render_template("news.html", rows=rows, cats=NEWS_CATS, c=c)

@app.route("/news/<int:nid>", methods=["GET", "POST"])
def news_item(nid):
    a = q1("SELECT * FROM news WHERE id=? AND status='published'", nid) or abort(404)
    if request.method == "POST":
        need_login()
        if clean(request.form.get("body"), 1000): ex("INSERT INTO news_comments(article_id,author_id,body,created_at) VALUES(?,?,?,?)", nid, g.user["id"], clean(request.form["body"], 1000), now())
        return redirect(f"/news/{nid}")
    return render_template("news_item.html", a=a, cs=q("SELECT n.*, u.username FROM news_comments n JOIN users u ON u.id=n.author_id WHERE article_id=? ORDER BY n.id", nid))

@app.route("/admin/news", methods=["GET", "POST"])
def admin_news():
    need_role("admin", "editor")
    if request.method == "POST":
        f = request.form; url = clean(f.get("source_url"), 500)
        if not valid_https_url(url) or not clean(f.get("headline"), 200) or not clean(f.get("summary"), 600) or not clean(f.get("source_name"), 80):
            flash("Headline, your own short summary, source name and a real http(s) link over HTTPS are required.")
        else:
            nid_raw = clean(f.get("id"), 20)
            try:
                nid = int(nid_raw) if nid_raw else None
                published = clean(f.get("published_at"), 10) or date.today().isoformat()
                date.fromisoformat(published)
            except (ValueError, TypeError):
                flash("Use a valid publication date and article ID.")
                return render_template("admin_news.html", cats=NEWS_CATS, rows=q("SELECT * FROM news ORDER BY id DESC LIMIT 20"))
            vals = (clean(f["headline"], 200), clean(f["summary"], 600), clean(f["source_name"], 80), url, published,
                    f.get("category") if f.get("category") in NEWS_CATS else "Top Stories", f.get("kind") if f.get("kind") in ("reporting", "opinion", "sponsored") else "reporting")
            if nid:
                if not q1("SELECT id FROM news WHERE id=?", nid): abort(404)
                ex("UPDATE news SET headline=?,summary=?,source_name=?,source_url=?,published_at=?,category=?,kind=?,updated_at=? WHERE id=?", *vals, now(), nid)
            else:
                ex("INSERT INTO news(headline,summary,source_name,source_url,published_at,category,kind,created_by,updated_at) VALUES(?,?,?,?,?,?,?,?,?)", *vals, g.user["id"], now())
            ex("INSERT INTO audit(admin_id,action,target,created_at) VALUES(?,?,?,?)", g.user["id"], "news_edit" if nid else "news_create", vals[0][:60], now())
            return redirect("/news")
    return render_template("admin_news.html", cats=NEWS_CATS, rows=q("SELECT * FROM news ORDER BY id DESC LIMIT 20"))

def playable():
    return [t for t in q("SELECT t.*, p.title pl FROM tracks t JOIN playlists p ON p.id=t.playlist_id WHERE t.active=1 AND t.stream_url!='' AND (t.license_expiry IS NULL OR t.license_expiry>=?) ORDER BY t.id", date.today().isoformat()) if valid_https_url(t["stream_url"]) and t["license_type"].strip() and t["rights_holder"].strip() and not t["license_type"].upper().startswith("DEMO")]

@app.route("/beats")
def beats():
    return render_template("beats.html", pls=q("SELECT * FROM playlists"), ts=q("SELECT * FROM tracks ORDER BY id"), ok={t["id"] for t in playable()}, play=playable())

@app.route("/admin/tracks", methods=["POST"])
def admin_tracks():
    need_role("admin"); f = request.form
    if f.get("action") == "toggle":
        try: track_id = int(f.get("id", ""))
        except (TypeError, ValueError): abort(400)
        if not q1("SELECT id FROM tracks WHERE id=?", track_id): abort(404)
        ex("UPDATE tracks SET active=1-active WHERE id=?", track_id)
        audit_target = str(track_id)
    else:
        url = clean(f.get("stream_url"), 500)
        playlist_raw = f.get("playlist_id", "")
        try: playlist_id = int(playlist_raw)
        except (TypeError, ValueError): playlist_id = 0
        expiry = clean(f.get("license_expiry"), 10) or None
        try:
            if expiry: date.fromisoformat(expiry)
        except ValueError: expiry = "INVALID"
        if not (clean(f.get("license_type"), 80) and clean(f.get("rights_holder"), 120) and valid_https_url(url) and clean(f.get("title"), 100)
                and q1("SELECT id FROM playlists WHERE id=?", playlist_id) and expiry != "INVALID"):
            flash("Title, HTTPS audio URL, license type, rights holder, valid playlist and expiry are all required."); return redirect("/beats")
        # Admin must affirm that the stated license actually permits in-app streaming.
        if f.get("rights_confirmed") != "yes":
            flash("Confirm that you have verified the rights for streaming this track in the app."); return redirect("/beats")
        ex("INSERT INTO tracks(playlist_id,title,artist,stream_url,license_type,rights_holder,attribution,license_expiry) VALUES(?,?,?,?,?,?,?,?)", playlist_id, clean(f["title"], 100), clean(f.get("artist"), 100), url,
           clean(f["license_type"], 80), clean(f["rights_holder"], 120), clean(f.get("attribution"), 200), expiry)
        audit_target = clean(f.get("title"), 100)
    ex("INSERT INTO audit(admin_id,action,target,created_at) VALUES(?,?,?,?)", g.user["id"], "track_" + f.get("action", "add"), audit_target, now())
    return redirect("/beats")

@app.route("/inbox")
def inbox():
    need_login()
    rows = q("SELECT n.*, u.username FROM notifications n JOIN users u ON u.id=n.actor_id WHERE recipient_id=? ORDER BY n.id DESC LIMIT 50", g.user["id"])
    ex("UPDATE notifications SET read=1 WHERE recipient_id=?", g.user["id"]); return render_template("inbox.html", rows=rows)

def seed():
    with app.app_context():
        d = db()
        for n, s, ds in [("Book Lovers", "book-lovers", "Honest reviews and book talk."), ("Music & Chill", "music-chill", "Share and discuss music."), ("Faith & Life", "faith-life", "Respectful faith and life questions."),
                         ("Life Stories", "life-stories", "Real stories from real people."), ("Creative Minds", "creative-minds", "Writers and makers."), ("Current Events", "current-events", "Calm talk about the news.")]:
            d.execute("INSERT OR IGNORE INTO groups(name,slug,description,rules) VALUES(?,?,?,?)", (n, s, ds, "Be kind. Be real. No hate, harassment or spam."))
        for t, m in [("Lo-fi & Chill", "chill"), ("Rainy Day", "rain"), ("Quiet Morning", "calm"), ("Reading Room", "focus"), ("Cafe Jazz", "jazz")]:
            d.execute("INSERT OR IGNORE INTO playlists(title,mood) VALUES(?,?)", (t, m))
            pid = d.execute("SELECT id FROM playlists WHERE title=?", (t,)).fetchone()[0]
            d.execute("INSERT INTO tracks(playlist_id,title,artist,license_type,rights_holder,attribution,active) SELECT ?,?,?,?, ?,?,0 WHERE NOT EXISTS (SELECT 1 FROM tracks WHERE playlist_id=? AND title=?)", (pid, f"{t} (demo slot)", "No audio connected", "DEMO - no license, no audio", "n/a", "", pid, f"{t} (demo slot)"))
        for h, c in [("[SAMPLE] Example headline for Top Stories", "Top Stories"), ("[SAMPLE] Example headline for Books", "Books")]:
            d.execute("INSERT INTO news(headline,summary,source_name,source_url,published_at,category) SELECT ?,?,?,?,?,? WHERE NOT EXISTS (SELECT 1 FROM news WHERE headline=?)", (h, "Sample data only - not real news. Editors replace this with their own short summary and a link to the original.", "Sample Source", "https://example.com", date.today().isoformat(), c, h))
        d.commit(); print("Seeded any missing groups, playlists, demo track slots and sample news.")

SW = """const C='cs-v1';
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(['/offline','/static/icon-192.png'])));self.skipWaiting()});
self.addEventListener('activate',e=>e.waitUntil(clients.claim()));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;
 if(e.request.mode==='navigate')e.respondWith(fetch(e.request).catch(()=>caches.match('/offline')));
 else if(new URL(e.request.url).pathname.startsWith('/static/'))e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)))});"""
@app.route("/sw.js")
def sw(): return app.response_class(SW, mimetype="application/javascript", headers={"Cache-Control": "no-cache"})
@app.route("/manifest.webmanifest")
def manifest():
    return app.response_class(__import__("json").dumps({"name": "The Coffee Shop", "short_name": "Coffee Shop", "start_url": "/", "scope": "/", "display": "standalone",
        "background_color": "#121211", "theme_color": "#2B1B14", "description": "Real People. Good Conversations. Better Days.",
        "icons": [{"src": f"/static/icon-{n}.png", "sizes": f"{n}x{n}", "type": "image/png", "purpose": "any maskable"} for n in (192, 512)]}), mimetype="application/manifest+json")
@app.route("/offline")
def offline(): return render_template("offline.html")

TPL_DIR = os.path.join(os.path.dirname(__file__), "templates")
def load_templates():
    t = {}
    for f in os.listdir(TPL_DIR): t[f] = open(os.path.join(TPL_DIR, f), encoding="utf-8").read()
    app.jinja_env.loader = DictLoader(t)
load_templates()

if __name__ == "__main__":
    if sys.argv[1:] == ["seed"]: seed()
    else: app.run(debug=os.environ.get("FLASK_DEBUG") == "1", host="127.0.0.1", port=int(os.environ.get("PORT", 5000)))
