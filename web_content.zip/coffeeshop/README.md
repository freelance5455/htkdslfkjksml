# The Coffee Shop (MVP)

A cozy, text-first community for book and music reviews, questions and replies, stories, Faith & Life discussions, groups, the What's Brewing news section, and Cozy Beats. Built with Flask + SQLite.

## Run locally
1. Install Python 3.10+ from python.org.
2. Open a terminal in this folder.
3. Install dependencies: `python -m pip install -r requirements.txt`
4. Seed starter groups/playlists/sample news: `python app.py seed`
5. Run: `python app.py` and open `http://127.0.0.1:5000`.
6. In local development, the first account becomes admin. Do not expose this development configuration publicly.
7. Tests: `python -m unittest test_app -v`.

## Production / deployment
- Set `APP_ENV=production` and a unique, long random `SECRET_KEY` before starting. The app refuses production startup without a strong configured key.
- Set `BOOTSTRAP_ADMIN_USERNAME` to the exact username that should receive the initial admin role. Only that username can become the first admin in production. Register it first, then unset the variable after setup. If no bootstrap username is configured, first users are ordinary users.
- Set `DATABASE` to a persistent writable path, such as `/data/coffeeshop.db` on a host with a persistent disk. SQLite data may be lost on ephemeral hosts.
- Linux/macOS: `gunicorn app:app`. Windows local development: `python app.py`.
- HTTPS must be terminated by the hosting platform. Production session cookies are marked Secure.
- Deployment was not tested in this environment.

## Known limitations (not fixed by code review alone)
- Email verification and password reset need a configured email provider.
- No direct messages, account deletion/export, or complete block/mute workflows yet.
- Cozy Beats includes no music. The app requires administrators to affirm that they verified streaming rights; this is not an independent legal verification. Only use music with rights that permit streaming in the app.
- What's Brewing is manually curated. Use sources/API/RSS only under terms that permit your use; sample entries are clearly marked and are not real news.
- Legal policies, age policy, takedown process, moderation staffing, and copyright/legal review are still needed before a public launch.
- The service worker provides a basic offline fallback, not offline access to feeds or posts.
- This is a functional MVP, not a full native iOS/Android app.

## Security notes
- CSRF tokens are required on all POST requests. Passwords are hashed. Production requires a configured secret key and secure cookies.
- Reports validate targets and prevent duplicate open reports; report redirects are restricted to local paths.
- Use HTTPS in production, back up the database, keep dependencies updated, and test restore procedures.
