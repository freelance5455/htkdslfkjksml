# The Coffee Shop — Fixes Applied and Verification Status

## Fixes applied in this revision

- Production startup now refuses to use a missing/default secret key; production session cookies are marked Secure.
- Production administrator bootstrap is restricted to the username configured with `BOOTSTRAP_ADMIN_USERNAME`. Local development keeps the convenient first-user-admin behavior.
- SQLite connections now use a timeout, busy timeout, foreign-key enforcement, WAL mode for file databases, and automatic creation of the database parent directory.
- Added a case-insensitive unique username index to prevent accounts that differ only by capitalization.
- Added a maximum password length to avoid excessively large password-hash inputs.
- Invalid group slugs supplied to the create-post form no longer silently create an ordinary post.
- Review years are range-checked; invalid values are discarded safely.
- Replies validate parent IDs and only permit replies to visible comments. Reply notifications now include the parent commenter when appropriate.
- Report targets must exist and be visible; malformed IDs are handled safely; duplicate open reports are prevented; redirects from the report flow cannot send users to external websites.
- Moderation actions are validated instead of treating unknown actions as dismissals.
- What's Brewing links must be valid HTTPS URLs, publication dates and edit IDs are validated, and editing a nonexistent story returns 404.
- Cozy Beats track submissions validate the playlist, URL, and expiry date; admins must explicitly affirm that they verified streaming rights. Invalid/expired/demo tracks are not playable.
- Seed setup is idempotent and can fill in missing groups/playlists/sample stories after a partial seed.
- Music player JavaScript now uses explicit element references instead of relying on browser-created global variables.
- Updated dependencies and deployment documentation, including production secret/admin bootstrap guidance.

## Verification performed

- Python syntax compilation passed for `app.py` and `test_app.py`.
- The SQLite schema and the revised seed SQL were executed successfully in an isolated in-memory SQLite check.
- The included Flask unit-test suite could not be run in this environment because Flask is not installed and package downloads are unavailable. Do not treat the test suite as passing until you run `python -m pip install -r requirements.txt` and `python -m unittest test_app -v` locally or in CI.
- A production deployment, browser/device testing, audio-provider compatibility, and live licensing checks were not performed.

## Remaining work before public launch

- Email verification and password reset need a configured email provider.
- Account deletion/export, direct messages, and complete block/mute workflows are not implemented.
- This revision does not independently verify a music license; the admin confirmation is an accountability check, not legal proof. Only add tracks after confirming the license permits streaming in this app.
- News remains manually curated; automated RSS/news integrations require checking each provider's terms.
- Add reviewed Terms of Service, Privacy Policy, Community Guidelines, age policy, copyright/takedown contact, and an operational moderation plan.
- Configure persistent storage/backups and test database restore. SQLite on ephemeral hosting can lose user data.
