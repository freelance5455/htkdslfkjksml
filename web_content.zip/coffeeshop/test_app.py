import os, tempfile, unittest, re
os.environ["DATABASE"] = os.path.join(tempfile.mkdtemp(), "t.db")
import app as A

class T(unittest.TestCase):
    def setUp(self):
        A.app.config.update(TESTING=True, RATE_LIMIT=False, DATABASE=os.path.join(tempfile.mkdtemp(), "t.db"))
        A.seed(); self.c = A.app.test_client()
    def client(self):
        return A.app.test_client()
    def tok(self, c):
        c.get("/")
        with c.session_transaction() as s: return s["csrf"]
    def post(self, c, url, **d): d["csrf_token"] = self.tok(c); return c.post(url, data=d, follow_redirects=True)
    def user(self, name):
        c = self.client(); r = self.post(c, "/register", username=name, password="password1"); self.assertEqual(r.status_code, 200); return c

    def test_auth_flow(self):
        c = self.user("alice"); self.assertIn(b"@alice", c.get("/").data)
        self.post(c, "/logout"); self.assertIn(b"Sign in", c.get("/").data)
        self.assertIn(b"Wrong username", self.post(c, "/login", username="alice", password="nope").data)
        self.assertIn(b"@alice", self.post(c, "/login", username="alice", password="password1").data)
        self.assertIn(b"taken", self.post(self.client(), "/register", username="ALICE", password="password1").data)
        self.assertIn(b"at least 8", self.post(self.client(), "/register", username="bob", password="short").data)
    def test_csrf_required(self):
        c = A.app.test_client(); self.assertEqual(c.post("/register", data={"username": "x1x", "password": "password1"}).status_code, 400)
    def test_post_reply_nested_like_save_follow(self):
        a, b = self.user("alice"), self.user("bob")
        r = self.post(a, "/new", type="text", title="Hello", body="First post <script>alert(1)</script>")
        self.assertIn(b"First post", r.data); self.assertNotIn(b"<script>alert", r.data)
        self.post(b, "/post/1/comment", body="top reply"); self.post(a, "/post/1/comment", body="nested reply", parent_id="1")
        html = b.get("/post/1").data; self.assertIn(b"top reply", html); self.assertIn(b"nested reply", html)
        self.post(b, "/post/1/like"); self.post(b, "/post/1/like")
        with A.app.app_context(): self.assertEqual(A.q1("SELECT COUNT(*) c FROM reactions")["c"], 0)
        self.post(b, "/post/1/like")
        with A.app.app_context(): self.assertEqual(A.q1("SELECT COUNT(*) c FROM reactions")["c"], 1)
        self.post(b, "/post/1/save"); self.assertIn(b"First post", b.get("/u/bob?tab=saved").data)
        self.post(b, "/u/alice/follow"); self.assertIn(b"First post", b.get("/?tab=following").data)
        self.assertIn(b"replied to your post", a.get("/inbox").data)
    def test_reviews_validate_and_search(self):
        a = self.user("alice")
        self.assertIn(b"need a title", self.post(a, "/new", type="book_review", body="x", item_title="Dune").data)
        self.post(a, "/new", type="book_review", body="Loved it", item_title="Dune", creator="Frank Herbert", rating="5", year="1965")
        self.post(a, "/new", type="music_review", body="Moody", item_title="Blue", creator="Joni Mitchell", rating="4")
        self.assertIn(b"Dune", a.get("/search?q=Herbert").data); self.assertNotIn(b"Joni", a.get("/search?q=Herbert").data)
        self.assertIn("★★★★★".encode(), a.get("/post/1").data)
        self.assertIn(b"Dune", a.get("/?type=book_review").data)
    def test_permissions(self):
        a, b = self.user("alice"), self.user("bob")  # alice = first user = admin
        self.post(b, "/new", type="story", body="bobs story")
        c = self.user("carol"); self.assertEqual(c.post("/post/1/delete", data={"csrf_token": self.tok(c)}).status_code, 403)
        self.assertEqual(c.get("/admin/news").status_code, 403); self.assertEqual(c.get("/admin/reports").status_code, 403)
        self.assertEqual(A.app.test_client().post("/new", data={"csrf_token": "x"}).status_code, 400)
    def test_report_and_moderation(self):
        a, b = self.user("alice"), self.user("bob")
        self.post(b, "/new", type="text", body="bad post"); self.post(a, "/report", target_type="post", target_id="1", reason="spam")
        self.assertIn(b"spam", a.get("/admin/reports").data); self.post(a, "/admin/reports", id="1", action="remove")
        self.assertEqual(a.get("/post/1").status_code, 404)
    def test_groups(self):
        a = self.user("alice"); self.post(a, "/g/book-lovers/join")
        self.assertIn(b"Leave group", a.get("/g/book-lovers").data)
        self.post(a, "/new", type="text", body="group hello", group="book-lovers"); self.assertIn(b"group hello", a.get("/g/book-lovers").data)
        self.assertNotIn(b"group hello", a.get("/").data)
        self.post(a, "/g/book-lovers/leave"); self.assertIn(b"Join group", a.get("/g/book-lovers").data)
        b = self.user("bob"); self.assertEqual(b.post("/new", data={"csrf_token": self.tok(b), "type": "text", "body": "x", "group": "book-lovers"}).status_code, 403)
    def test_news(self):
        a, b = self.user("alice"), self.user("bob")
        self.assertIn(b"real http(s) link", self.post(a, "/admin/news", headline="H", summary="S", source_name="BBC", source_url="javascript:x").data)
        r = self.post(a, "/admin/news", headline="Real headline", summary="My words", source_name="BBC", source_url="https://bbc.com/x", category="World", published_at="2026-10-01")
        self.assertIn(b"Read the original", r.data); self.assertIn(b"BBC", r.data); self.assertIn(b"2026-10-01", r.data)
        self.post(b, "/news/3", body="good story"); self.assertIn(b"good story", b.get("/news/3").data)
    def test_beats_license_rules(self):
        a = self.user("alice"); self.assertIn(b"Demo mode", a.get("/beats").data)
        self.assertIn(b"are all required", self.post(a, "/admin/tracks", playlist_id="1", title="T", stream_url="https://x.com/a.mp3", license_type="", rights_holder="").data)
        self.post(a, "/admin/tracks", playlist_id="1", title="Good", stream_url="https://x.com/a.mp3", license_type="CC BY 4.0", rights_holder="Artist", rights_confirmed="yes")
        self.post(a, "/admin/tracks", playlist_id="1", title="Expired", stream_url="https://x.com/b.mp3", license_type="CC", rights_holder="Artist", license_expiry="2020-01-01", rights_confirmed="yes")
        with A.app.app_context(): titles = [t["title"] for t in A.playable()]
        self.assertEqual(titles, ["Good"]); self.assertIn(b"https://x.com/a.mp3", a.get("/beats").data); self.assertNotIn(b"b.mp3", a.get("/beats").data)
        self.post(a, "/admin/tracks", action="toggle", id="6")
        with A.app.app_context(): self.assertEqual(A.playable(), [])
    def test_profile_edit_and_pages_render(self):
        a = self.user("alice"); self.post(a, "/settings", display_name="Alice A", bio="I read.")
        self.assertIn(b"I read.", a.get("/u/alice").data)
        for u in ["/", "/groups", "/news", "/beats", "/new", "/inbox", "/search?q=a", "/settings"]: self.assertEqual(a.get(u).status_code, 200, u)
        self.assertEqual(a.get("/nope").status_code, 404)
    def test_pwa_files(self):
        c = A.app.test_client(); m = c.get("/manifest.webmanifest"); self.assertEqual(m.status_code, 200)
        self.assertEqual(m.get_json()["display"], "standalone"); self.assertEqual(c.get("/sw.js").mimetype, "application/javascript")
        self.assertEqual(c.get("/static/icon-512.png").status_code, 200); self.assertIn(b"offline", c.get("/offline").data)
        self.assertIn(b'rel="manifest"', c.get("/").data)
if __name__ == "__main__": unittest.main()
