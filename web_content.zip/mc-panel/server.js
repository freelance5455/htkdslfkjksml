'use strict';

const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const { status } = require('minecraft-server-util');

// ---------- Ayarlar (ortam değişkenlerinden) ----------
const PORT = Number(process.env.PORT) || 8080;
const PANEL_PASSWORD = process.env.PANEL_PASSWORD || '';
const PUBLIC_HOST = process.env.PUBLIC_HOST || 'SUNUCU_IP';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');

const CONFIG_FILE = path.join(DATA_DIR, 'panel.json');
const SERVER_DIR = path.join(DATA_DIR, 'server');
const CONTAINER = 'mc-server';
const IMAGE = 'itzg/minecraft-server';
const JAVA_PORT = 25565;
const BEDROCK_PORT = 19132;
const STARTUP_GRACE_MS = 15 * 60 * 1000; // 15 dk içinde açılmazsa kapat
const WATCH_INTERVAL_MS = 30 * 1000;

// Geyser + Floodgate indirme adresleri (GeyserMC resmi API)
const GEYSER_API = 'https://download.geysermc.org/v2/projects';
const BEDROCK_URLS = {
  PAPER: [
    `${GEYSER_API}/geyser/versions/latest/builds/latest/downloads/spigot`,
    `${GEYSER_API}/floodgate/versions/latest/builds/latest/downloads/spigot`,
  ],
  FABRIC: [
    `${GEYSER_API}/geyser/versions/latest/builds/latest/downloads/fabric`,
    `${GEYSER_API}/floodgate/versions/latest/builds/latest/downloads/fabric`,
  ],
};

const DEFAULTS = {
  type: 'PAPER',
  version: 'LATEST',
  memory: '4G',
  maxPlayers: 20,
  motd: 'Benim Minecraft Sunucum',
  bedrock: true,
  extraUrls: '',
  autoStopMinutes: 10,
};

// ---------- Durum ----------
let busy = false;          // start/stop sürerken yeni işlem kabul etme
let lastError = '';
let startedAt = 0;         // "starting" durumunun ne zaman başladığı
let emptySince = 0;        // sunucu hazır ama kimse yokken geçen süre başlangıcı

// ---------- Yardımcılar ----------
function loadConfig() {
  try {
    return { ...DEFAULTS, ...JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')) };
  } catch {
    return { ...DEFAULTS };
  }
}

function saveConfig(cfg) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2));
}

function parseUrls(text) {
  return String(text || '')
    .split(/[\n,]+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

function validate(input) {
  const errors = [];
  const cfg = { ...DEFAULTS };

  const type = String(input.type || '').toUpperCase();
  if (['PAPER', 'FABRIC'].includes(type)) cfg.type = type;
  else errors.push('Tür PAPER veya FABRIC olmalı.');

  const version = String(input.version || '').trim();
  if (/^(LATEST|\d+\.\d+(\.\d+)?)$/i.test(version)) cfg.version = version.toUpperCase();
  else errors.push('Sürüm LATEST ya da 1.21.4 gibi bir değer olmalı.');

  const memory = String(input.memory || '');
  if (/^\d{1,2}G$/.test(memory) && Number(memory.slice(0, -1)) >= 1 && Number(memory.slice(0, -1)) <= 16) {
    cfg.memory = memory;
  } else {
    errors.push('Bellek 1G ile 16G arasında olmalı.');
  }

  const maxPlayers = Number(input.maxPlayers);
  if (Number.isInteger(maxPlayers) && maxPlayers >= 1 && maxPlayers <= 100) cfg.maxPlayers = maxPlayers;
  else errors.push('Maksimum oyuncu 1 ile 100 arasında olmalı.');

  const autoStop = Number(input.autoStopMinutes);
  if (Number.isInteger(autoStop) && autoStop >= 1 && autoStop <= 180) cfg.autoStopMinutes = autoStop;
  else errors.push('Boşken kapanma süresi 1 ile 180 dakika arasında olmalı.');

  cfg.motd = String(input.motd ?? '').replace(/[\r\n]+/g, ' ').trim().slice(0, 59) || DEFAULTS.motd;
  cfg.bedrock = input.bedrock === true || input.bedrock === 'true';

  const urls = parseUrls(input.extraUrls);
  if (urls.length > 10) errors.push('En fazla 10 ekstra eklenti/mod adresi girebilirsin.');
  for (const url of urls) {
    if (!/^https:\/\/\S+$/.test(url)) errors.push(`Geçersiz adres (https:// ile başlamalı): ${url}`);
  }
  cfg.extraUrls = urls.join('\n');

  return { errors, cfg };
}

function docker(args, { timeout = 120000 } = {}) {
  return new Promise((resolve, reject) => {
    execFile('docker', args, { timeout, maxBuffer: 10 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) {
        err.message = (stderr || err.message).trim();
        return reject(err);
      }
      resolve(stdout.toString().trim());
    });
  });
}

async function containerRunning() {
  try {
    return (await docker(['inspect', '-f', '{{.State.Running}}', CONTAINER])) === 'true';
  } catch {
    return false;
  }
}

// Bedrock girişi için Geyser'i Floodgate moduna al (Java hesabı istemez)
function patchGeyserConfig(cfg) {
  if (!cfg.bedrock) return;
  const file =
    cfg.type === 'FABRIC'
      ? path.join(SERVER_DIR, 'config', 'Geyser-Fabric', 'config.yml')
      : path.join(SERVER_DIR, 'plugins', 'Geyser-Spigot', 'config.yml');
  try {
    const text = fs.readFileSync(file, 'utf8');
    const patched = text.replace(/^([ \t]*auth-type:[ \t]*)online[ \t]*$/m, '$1floodgate');
    if (patched !== text) fs.writeFileSync(file, patched);
  } catch {
    // Dosya ilk açılıştan sonra oluşur; yoksa sorun değil
  }
}

// ---------- Sunucu işlemleri ----------
async function startServer() {
  const cfg = loadConfig();

  await docker(['rm', '-f', CONTAINER]).catch(() => {});
  fs.mkdirSync(SERVER_DIR, { recursive: true });
  patchGeyserConfig(cfg);

  const args = ['run', '-d', '--name', CONTAINER, '-t', '-p', `${JAVA_PORT}:25565`];
  if (cfg.bedrock) args.push('-p', `${BEDROCK_PORT}:19132/udp`);
  args.push('-v', `${SERVER_DIR}:/data`);

  const env = {
    EULA: 'TRUE',
    TYPE: cfg.type,
    VERSION: cfg.version,
    MEMORY: cfg.memory,
    MAX_PLAYERS: String(cfg.maxPlayers),
    MOTD: cfg.motd,
    ONLINE_MODE: 'TRUE',
    ENABLE_RCON: 'true',
    STOP_DURATION: '60',
    TZ: 'Europe/Istanbul',
  };

  // Eklenti (Paper) ya da mod (Fabric) listesi
  const urls = [...(cfg.bedrock ? BEDROCK_URLS[cfg.type] : []), ...parseUrls(cfg.extraUrls)];
  if (urls.length) env[cfg.type === 'FABRIC' ? 'MODS' : 'PLUGINS'] = urls.join(',');
  if (cfg.type === 'FABRIC') env.MODRINTH_PROJECTS = 'fabric-api';

  for (const [k, v] of Object.entries(env)) args.push('-e', `${k}=${v}`);
  args.push(IMAGE);

  // İlk açılışta imaj indirildiği için zaman aşımı uzun
  await docker(args, { timeout: 10 * 60 * 1000 });
  startedAt = Date.now();
  emptySince = 0;
}

async function stopServer() {
  try {
    await docker(['stop', '-t', '60', CONTAINER], { timeout: 180000 });
  } finally {
    startedAt = 0;
    emptySince = 0;
  }
}

async function getStatus() {
  const cfg = loadConfig();
  const base = {
    busy,
    lastError,
    address: {
      java: PUBLIC_HOST,
      bedrock: cfg.bedrock ? `${PUBLIC_HOST} (port ${BEDROCK_PORT})` : null,
    },
  };

  if (!(await containerRunning())) {
    return { ...base, state: 'stopped', players: null };
  }

  try {
    const s = await status('127.0.0.1', JAVA_PORT, { timeout: 3000 });
    return {
      ...base,
      state: 'online',
      players: {
        online: s.players.online,
        max: s.players.max,
        names: (s.players.sample || []).map((p) => p.name),
      },
    };
  } catch {
    return { ...base, state: 'starting', players: null };
  }
}

// ---------- Boşta kalınca otomatik kapatma ----------
async function watchOnce() {
  if (busy) return;
  const cfg = loadConfig();
  const st = await getStatus();

  if (st.state === 'stopped') {
    startedAt = 0;
    emptySince = 0;
    return;
  }

  if (st.state === 'starting') {
    if (!startedAt) startedAt = Date.now();
    if (Date.now() - startedAt > STARTUP_GRACE_MS) {
      console.log('Sunucu zamanında açılmadı, kapatılıyor.');
      await stopServer();
    }
    return;
  }

  // online
  if (st.players.online > 0) {
    emptySince = 0;
    return;
  }
  if (!emptySince) emptySince = Date.now();
  if (Date.now() - emptySince >= cfg.autoStopMinutes * 60 * 1000) {
    console.log(`${cfg.autoStopMinutes} dk boş kaldı, sunucu kapatılıyor.`);
    await stopServer();
  }
}

setInterval(() => {
  watchOnce().catch((e) => console.error('İzleme hatası:', e.message));
}, WATCH_INTERVAL_MS);

// ---------- HTTP ----------
const app = express();
app.use(express.json({ limit: '10kb' }));

function auth(req, res, next) {
  if (!PANEL_PASSWORD) {
    return res.status(500).send('PANEL_PASSWORD ayarlanmamış. .env dosyasına ekle.');
  }
  const header = req.headers.authorization || '';
  const [scheme, b64] = header.split(' ');
  if (scheme === 'Basic' && b64) {
    const pass = Buffer.from(b64, 'base64').toString('utf8').split(':').slice(1).join(':');
    const a = crypto.createHash('sha256').update(pass).digest();
    const b = crypto.createHash('sha256').update(PANEL_PASSWORD).digest();
    if (crypto.timingSafeEqual(a, b)) return next();
  }
  res.set('WWW-Authenticate', 'Basic realm="mc-panel"');
  res.status(401).send('Yetkisiz');
}

app.use(auth);
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/status', async (req, res) => {
  try {
    res.json(await getStatus());
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/config', (req, res) => {
  res.json(loadConfig());
});

app.post('/api/config', (req, res) => {
  const { errors, cfg } = validate(req.body || {});
  if (errors.length) return res.status(400).json({ error: errors.join(' ') });
  saveConfig(cfg);
  res.json(cfg);
});

app.post('/api/start', (req, res) => {
  if (busy) return res.status(409).json({ error: 'Başka bir işlem sürüyor, bekle.' });
  busy = true;
  lastError = '';
  res.status(202).json({ ok: true });
  startServer()
    .catch((e) => {
      lastError = `Açılamadı: ${e.message}`;
      console.error(lastError);
    })
    .finally(() => {
      busy = false;
    });
});

app.post('/api/stop', (req, res) => {
  if (busy) return res.status(409).json({ error: 'Başka bir işlem sürüyor, bekle.' });
  busy = true;
  lastError = '';
  res.status(202).json({ ok: true });
  stopServer()
    .catch((e) => {
      lastError = `Kapatılamadı: ${e.message}`;
      console.error(lastError);
    })
    .finally(() => {
      busy = false;
    });
});

app.get('/api/logs', async (req, res) => {
  try {
    const logs = await docker(['logs', '--tail', '150', CONTAINER]);
    res.json({ logs: logs || '(Henüz log yok)' });
  } catch {
    res.json({ logs: '(Sunucu şu an kapalı, log yok)' });
  }
});

app.post('/api/command', async (req, res) => {
  const command = String(req.body?.command || '').trim().slice(0, 200);
  if (!command || /[\r\n]/.test(command)) {
    return res.status(400).json({ error: 'Geçersiz komut.' });
  }
  try {
    const output = await docker(['exec', CONTAINER, 'rcon-cli', command], { timeout: 15000 });
    res.json({ output: output || 'Komut gönderildi.' });
  } catch {
    res.status(500).json({ error: 'Komut gönderilemedi. Sunucu açık mı?' });
  }
});

app.listen(PORT, () => {
  console.log(`MC Panel çalışıyor: http://${PUBLIC_HOST}:${PORT}`);
});
