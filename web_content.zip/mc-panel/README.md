# MC Panel

Telefondan açıp kapatabildiğin, boşken kendini kapatan Minecraft sunucusu paneli.
Paper (eklenti) ve Fabric (mod) desteği, Bedrock girişi (Geyser + Floodgate), oyuncu listesi ve konsol içerir.

## 1. Gereksinimler

- **VPS:** Ubuntu 22.04 veya 24.04. 10-20 kişi için en az 2 vCPU ve 6 GB RAM öneririm (sunucuya 4 GB ayrılıyor).
- **Açık portlar:** `8080/tcp` (panel), `25565/tcp` (Java), `19132/udp` (Bedrock).

## 2. VPS'e Docker kur

```bash
curl -fsSL https://get.docker.com | sh
```

## 3. Dosyaları VPS'e koy

```bash
sudo mkdir -p /opt/mc-panel
# Bu klasördeki dosyaları /opt/mc-panel içine kopyala (scp, SFTP veya git ile)
cd /opt/mc-panel
cp .env.example .env
nano .env        # PANEL_PASSWORD, PUBLIC_HOST ve DATA_DIR değerlerini doldur
mkdir -p /opt/mc-panel/data
```

## 4. Portları aç

```bash
sudo ufw allow 8080/tcp
sudo ufw allow 25565/tcp
sudo ufw allow 19132/udp
sudo ufw enable
```

Sağlayıcının panelinde (Hetzner, DigitalOcean vb.) ayrıca güvenlik duvarı kuralı varsa onu da aç.

## 5. Başlat

```bash
cd /opt/mc-panel
docker compose up -d --build
```

Tarayıcıdan `http://VPS_IP:8080` adresine gir. Kullanıcı adı boş bırakılabilir, şifre `.env` içindeki `PANEL_PASSWORD`.

## 6. Kullanım

1. **Ayarlar** bölümünden tür (Paper veya Fabric), sürüm, bellek ve oyuncu sayısını seç. **Kaydet**'e bas.
2. **Başlat**'a bas. İlk açılışta imaj ve sunucu dosyaları indirildiği için birkaç dakika sürebilir. Sonraki açılışlar genelde daha kısa olur.
3. Durum **Açık** olunca Java oyuncuları `VPS_IP` adresine girer. Bedrock oyuncuları `VPS_IP` ve port `19132` ile girer.
4. Kimse kalmazsa, ayarlardaki süre kadar (varsayılan 10 dk) sonra sunucu kendini kapatır.

### Bedrock notu
İlk açılıştan sonra bir kez **Durdur → Başlat** yap. Panel Geyser ayarını Floodgate moduna çevirir, böylece Bedrock oyuncuların Java hesabına ihtiyacı olmaz.

### Eklenti ve mod notu
- **Paper** seçersen eklentiler `plugins` klasörüne iner.
- **Fabric** seçersen modlar `mods` klasörüne iner. Fabric API otomatik eklenir.
- Ekstra eklenti ya da mod eklemek için **Ayarlar** kısmındaki kutuya her satıra bir `https://` adresi yaz.
- Paper ve Fabric birlikte çalışmaz. Tür değiştirince dünyan silinmez, sadece eklenti/mod seti değişir.

## 7. Domain eklemek (play.sunucuadi.net)

1. Bir domain al (ör. `sunucuadi.net`).
2. DNS panelinde `play` için bir **A kaydı** oluştur: değer `VPS_IP`.
3. `.env` içindeki `PUBLIC_HOST` değerini `play.sunucuadi.net` yap, sonra `docker compose up -d` ile yeniden başlat.
4. Java için port yazmaya gerek yoktur. Bedrock için adres `play.sunucuadi.net` ve port `19132` olarak kalır.

## 8. Güvenlik notları

- Panel şu an **HTTP** üzerinden çalışır, şifre açık metin olarak gider. Domain bağlandıktan sonra Caddy ile HTTPS eklemeni öneririm.
- `docker.sock` bağlantısı panele host üzerinde geniş yetki verir. Paneli sadece sana açık tut ve şifreyi güçlü seç.
- Panel `docker-compose.yml` ile `restart: unless-stopped` olarak çalışır. VPS yeniden başlasa bile panel geri gelir, Minecraft sunucusu ise sen açana kadar kapalı kalır.

## 9. Sorun giderme

- **Başlat'a basınca hata:** Ekranın altındaki hata satırına ve Konsol bölümündeki loglara bak.
- **Fabric + Bedrock'ta Floodgate indirilemiyorsa:** Konsolda bir indirme hatası görürsen bu bağlantı adresini kontrol etmek gerekir. Bana log satırını gönder, düzeltirim.
- **Sunucu açılmadı, panel otomatik kapattı:** Açılış 15 dakikayı geçerse panel sunucuyu kapatır. Logları kontrol et.
- **Bellek hatası:** VPS'in RAM'i yetersizse Ayarlardan bellek değerini düşür.
