// UltraMsg - FINAL with your keys - Platform sends OTP from +256751302025
export async function onRequestPost({ request }) {
  const { phone, otp } = await request.json();

  // YOUR REAL KEYS - FED IN
  const ULTRAMSG_INSTANCE = "instance191451";
  const ULTRAMSG_TOKEN = "mjf004wbnefwuc8g";

  const cleanPhone = phone.replace(/[^0-9]/g, '');

  try {
    const formData = new URLSearchParams();
    formData.append('token', ULTRAMSG_TOKEN);
    formData.append('to', cleanPhone);
    formData.append('body', `🔐 Whisper Chain\n\nYour OTP is: *${otp}*\n\nValid for 5 minutes. Do not share.\n\nSent from platform +256751302025`);

    const res = await fetch(`https://api.ultramsg.com/${ULTRAMSG_INSTANCE}/messages/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: formData
    });

    const data = await res.json();

    return new Response(JSON.stringify({ 
      success: true, 
      sentTo: cleanPhone, 
      otp: otp,
      ultramsg: data 
    }), {
      headers: { 
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    });

  } catch (e) {
    return new Response(JSON.stringify({ 
      success: false, 
      error: e.message, 
      demoOtp: otp
    }), {
      headers: { 
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    });
  }
}

export async function onRequestOptions() {
  return new Response(null, {
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    }
  });
}