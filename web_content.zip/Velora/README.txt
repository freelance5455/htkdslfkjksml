VELORA — VERSION 3 REDESIGN

Files included:
- index.html — complete app
- manifest.json — installable app metadata
- service-worker.js — offline app-shell caching
- README.txt — setup and backup instructions

What's new in this redesign:
- Calm forest-green and warm-ivory visual theme
- Cleaner dashboard and quick-add buttons
- Searchable transaction history
- Income and expense category breakdowns
- Daily, weekly (Monday–Sunday), and monthly reports
- Edit/delete transactions
- CSV export and JSON backup/restore
- Attempts to migrate existing records from Velora v1/v2 browser storage

How to use:
1. Extract the ZIP.
2. Open index.html in a browser for basic use. Data is stored locally in that browser.
3. To install as a home-screen app with offline caching, host the extracted folder on HTTPS, open it in Chrome, then select Install app / Add to Home screen.
4. Export CSV or JSON backups regularly.

Important:
- Service workers require HTTPS or localhost; they do not run from file://.
- Clearing browser data may erase records.
- Data is not synced between devices and no account is required.
