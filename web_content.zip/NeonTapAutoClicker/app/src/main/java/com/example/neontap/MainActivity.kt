package com.example.neontap

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090B14)
private val Panel = Color(0xFF15192A)
private val Blue = Color(0xFF42D7FF)
private val Purple = Color(0xFF9D70FF)
private val Muted = Color(0xFF9AA5C4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Blue, secondary = Purple, background = Bg,
                    surface = Panel, onBackground = Color.White, onSurface = Color.White
                )
            ) { Dashboard(
                onOverlay = {
                    if (!Settings.canDrawOverlays(this)) {
                        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")))
                    } else {
                        Toast.makeText(this, "Overlay permission is already enabled", Toast.LENGTH_SHORT).show()
                    }
                },
                onAccessibility = {
                    Toast.makeText(this, "Enable NeonTap Auto Clicker in Accessibility settings, then return here", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                },
                onCrossAppMode = {
                    // Persist the last configured session so the floating controller can
                    // keep using it after the user switches to another app.
                    getSharedPreferences("neontap", MODE_PRIVATE).edit().apply()
                    when {
                        !Settings.canDrawOverlays(this) -> {
                            Toast.makeText(this, "Step 1/2: allow Display over other apps, then tap the red button again", Toast.LENGTH_LONG).show()
                            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:$packageName")))
                        }
                        TapAccessibilityService.instance == null -> {
                            Toast.makeText(this, "Step 2/2: enable NeonTap Auto Clicker in Accessibility. Android will then show the floating panel.", Toast.LENGTH_LONG).show()
                            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }
                        else -> {
                            // Save the current form values before opening the overlay so
                            // the red hshsh button always uses the latest saved session.
                            TapAccessibilityService.instance?.reloadSettings()
                            TapAccessibilityService.instance?.showFloatingPanel()
                            Toast.makeText(this, "Cross-app controls ready. Switch to another app and press START on the floating panel.", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                onShowPanel = {
                    when {
                        !Settings.canDrawOverlays(this) -> {
                            Toast.makeText(this, "Step 1 of 2: allow Display over other apps, then tap this button again", Toast.LENGTH_LONG).show()
                            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:$packageName")))
                        }
                        TapAccessibilityService.instance == null -> {
                            Toast.makeText(this, "Step 2 of 2: enable NeonTap Auto Clicker in Accessibility settings, then return", Toast.LENGTH_LONG).show()
                            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }
                        else -> {
                            TapAccessibilityService.instance?.reloadSettings()
                            TapAccessibilityService.instance?.showFloatingPanel()
                            Toast.makeText(this, "Floating control panel opened. Tap START on the panel to begin.", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            ) }
        }
    }
}

@Composable
private fun Dashboard(
    onOverlay: () -> Unit,
    onAccessibility: () -> Unit,
    onCrossAppMode: () -> Unit,
    onShowPanel: () -> Unit
) {
    val prefs = androidx.compose.ui.platform.LocalContext.current.getSharedPreferences("neontap", 0)
    var interval by remember { mutableStateOf(prefs.getLong("interval", 500L).toString()) }
    var repeat by remember { mutableStateOf(prefs.getInt("repeat", 0).toString()) }
    var points by remember { mutableStateOf(prefs.getString("points", "500,900") ?: "500,900") }
    var status by remember { mutableStateOf("Ready to configure") }
    var presetSaved by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(
        Brush.verticalGradient(listOf(Color(0xFF10162A), Bg, Color(0xFF090B14)))
    )) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(48.dp).background(
                    Brush.linearGradient(listOf(Blue, Purple)), RoundedCornerShape(16.dp)
                ), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.TouchApp, null, tint = Color.White, modifier = Modifier.size(28.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("NEONTAP", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                    Text("AUTO CLICKER  •  CONTROL CENTER", color = Muted, fontSize = 10.sp, letterSpacing = 1.3.sp)
                }
                Icon(Icons.Default.Settings, null, tint = Purple)
            }

            // Prominent hshsh cross-app button near the top so it is not hidden below the settings.
            Button(
                onClick = onCrossAppMode,
                modifier = Modifier.fillMaxWidth().height(58.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFFF334F),
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(18.dp)
            ) {
                Text("●  hshsh  ·  ENABLE CROSS-APP MODE", fontWeight = FontWeight.ExtraBold)
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Your click session", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text(status, color = Muted, fontSize = 13.sp)
                        }
                        Surface(color = Color(0xFF183C45), shape = RoundedCornerShape(50)) {
                            Text("● READY", Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                color = Blue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatCard("INTERVAL", "${interval.toLongOrNull()?.coerceAtLeast(1) ?: 500} ms", Modifier.weight(1f))
                        StatCard("REPEAT", if ((repeat.toIntOrNull() ?: 0) == 0) "Unlimited" else repeat, Modifier.weight(1f))
                    }
                }
            }

            Text("CLICK SETTINGS", color = Blue, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    OutlinedTextField(
                        value = interval, onValueChange = { interval = it.filter(Char::isDigit).take(6) },
                        modifier = Modifier.fillMaxWidth(), label = { Text("Click interval (milliseconds)") },
                        supportingText = { Text("Minimum 100 ms for a stable session", color = Muted) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = repeat, onValueChange = { repeat = it.filter(Char::isDigit).take(7) },
                        modifier = Modifier.fillMaxWidth(), label = { Text("Repeat count (0 = unlimited)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = points, onValueChange = { points = it },
                        modifier = Modifier.fillMaxWidth(), label = { Text("Tap points: x,y; x,y; ...") },
                        supportingText = { Text("Pixels from top-left, e.g. 500,900;700,1200", color = Muted) }
                    )
                    Button(
                        onClick = {
                            val safeInterval = (interval.toLongOrNull() ?: 500L).coerceIn(100L, 60000L)
                            val safeRepeat = (repeat.toIntOrNull() ?: 0).coerceAtLeast(0)
                            val parsed = TapAccessibilityService.parsePoints(points)
                            if (parsed.isEmpty()) {
                                status = "Enter at least one valid x,y point"
                            } else {
                                prefs.edit().putLong("interval", safeInterval)
                                    .putInt("repeat", safeRepeat).putString("points", points).apply()
                                TapAccessibilityService.instance?.reloadSettings()
                                status = "Settings saved • ${parsed.size} point(s)"
                                presetSaved = true
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Purple),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.Bolt, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (presetSaved) "SAVE PRESET AGAIN" else "SAVE SETTINGS & PRESET", fontWeight = FontWeight.Bold)
                    }
                }
            }

            Text("CROSS-APP MODE", color = Blue, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.TouchApp, contentDescription = null, tint = Blue, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("hshsh", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("Enable clicking while using other apps", color = Muted, fontSize = 12.sp)
                        }
                    }
                    Text(
                        "Tap the button to open overlay permission first, then tap it again to open Accessibility Settings. Enable NeonTap Auto Clicker there and confirm Android's prompt.",
                        color = Muted, fontSize = 12.sp, lineHeight = 17.sp
                    )
                    Button(
                        onClick = onCrossAppMode,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFFF334F),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("●  ENABLE hshsh / CROSS-APP MODE", fontWeight = FontWeight.ExtraBold)
                    }
                }
            }

            Text("ANDROID PERMISSIONS", color = Blue, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            PermissionRow("1", "Display over other apps", "Required for the floating controls", onOverlay)
            PermissionRow("2", "Accessibility service", "Required to dispatch configured tap gestures", onAccessibility)

            Button(
                onClick = {
                    val parsed = TapAccessibilityService.parsePoints(points)
                    if (parsed.isEmpty()) status = "Fix the tap coordinates first"
                    else {
                        prefs.edit().putLong("interval", (interval.toLongOrNull() ?: 500L).coerceIn(100L, 60000L))
                            .putInt("repeat", (repeat.toIntOrNull() ?: 0).coerceAtLeast(0))
                            .putString("points", points).apply()
                        onShowPanel()
                        status = "If permissions are enabled, the floating panel is now available"
                    }
                },
                modifier = Modifier.fillMaxWidth().height(58.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Color(0xFF07111B)),
                shape = RoundedCornerShape(18.dp)
            ) {
                Icon(Icons.Default.PlayArrow, null)
                Spacer(Modifier.width(8.dp))
                Text("SHOW FLOATING CONTROL PANEL", fontWeight = FontWeight.ExtraBold)
            }
            Text(
                "Use responsibly. Some apps and games block or restrict automated taps. Never enable Accessibility for an app you do not trust.",
                color = Muted, fontSize = 12.sp, lineHeight = 18.sp
            )
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Color(0xFF0E1220), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(value, color = Blue, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun PermissionRow(number: String, title: String, subtitle: String, onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Color(0xFF252142), shape = RoundedCornerShape(12.dp)) {
                Text(number, Modifier.padding(horizontal = 13.dp, vertical = 10.dp), color = Purple, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Muted, fontSize = 12.sp)
            }
            TextButton(onClick = onClick) { Text("OPEN", color = Blue) }
        }
    }
}
