package com.financetracker;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses SIP debit SMS messages.
 *
 * Supported formats:
 * 1. HDFC MF (Nifty 50 / Next 50):
 *    "Rs 300.00 successfully debited from ICICI Bank ***** on 20-Nov-26
 *     towards HDFC MUTUAL FUN via UPI AutoPay mandate . RRN: *******"
 *    - 1st occurrence → Nifty 50
 *    - 2nd occurrence → Next 50
 *
 * 2. ICICI Prudential:
 *    "Rs 200.00 successfully debited from ICICI Bank XX*** on 20-Nov-26
 *     towards ICICI Prudentia via UPI AutoPay mandate . RRN: ****"
 *
 * Returns ParsedSms with: fund (key matching JS fund name), amount, date (YYYY-MM-DD).
 */
public class SmsParser {

    // Track how many HDFC MF messages seen per day to distinguish 1st vs 2nd
    private static String lastHdfcDate = "";
    private static int hdfcCountForDate = 0;

    public static class ParsedSms {
        public String fund;   // must match fund name in the web app
        public double amount;
        public String date;   // YYYY-MM-DD

        public String toJson() {
            return "{\"fund\":\"" + esc(fund) + "\","
                 + "\"amount\":" + amount + ","
                 + "\"date\":\"" + date + "\"}";
        }
        private String esc(String s) { return s.replace("\"","\\\""); }
    }

    // Main entry — returns null if SMS is not a recognised SIP debit
    public static synchronized ParsedSms parse(String body) {
        if (body == null) return null;

        // Amount: "Rs 300.00" or "Rs. 300.00" or "INR 300.00"
        Pattern amtPat = Pattern.compile("(?:Rs\\.?|INR)\\s*([\\d,]+\\.?\\d*)",
                Pattern.CASE_INSENSITIVE);
        // Date: "20-Nov-26" or "20-Nov-2026" or "20/11/2026"
        Pattern datePat = Pattern.compile("(\\d{2})[\\-/](\\w+)[\\-/](\\d{2,4})");

        Matcher amtM = amtPat.matcher(body);
        Matcher dateM = datePat.matcher(body);
        if (!amtM.find() || !dateM.find()) return null;

        double amount;
        try {
            amount = Double.parseDouble(amtM.group(1).replace(",", ""));
        } catch (NumberFormatException e) { return null; }

        String date = parseDate(dateM.group(1), dateM.group(2), dateM.group(3));
        if (date == null) return null;

        // Identify fund
        String bodyLow = body.toLowerCase();
        boolean isHdfc = bodyLow.contains("hdfc mutual") || bodyLow.contains("hdfc mf")
                      || bodyLow.contains("hdfc mutual fun");
        boolean isIcici = bodyLow.contains("icici pruden");

        if (isHdfc) {
            // 1st SMS of the day → Nifty 50, 2nd → Next 50
            if (!date.equals(lastHdfcDate)) {
                lastHdfcDate = date;
                hdfcCountForDate = 0;
            }
            hdfcCountForDate++;
            ParsedSms p = new ParsedSms();
            p.amount = amount;
            p.date = date;
            // fund names must match what user typed in the web app exactly
            p.fund = (hdfcCountForDate == 1) ? "Nifty 50" : "Next 50";
            return p;
        }

        if (isIcici) {
            ParsedSms p = new ParsedSms();
            p.amount = amount;
            p.date = date;
            p.fund = "Nasdaq";
            return p;
        }

        return null; // not a recognised SIP SMS
    }

    // "20","Nov","26" → "2026-11-20"
    private static String parseDate(String dd, String mon, String yy) {
        int year;
        try {
            year = Integer.parseInt(yy);
            if (year < 100) year += 2000;
        } catch (NumberFormatException e) { return null; }

        int month;
        try {
            month = Integer.parseInt(mon);
        } catch (NumberFormatException e) {
            // Named month
            String[] names = {"jan","feb","mar","apr","may","jun",
                              "jul","aug","sep","oct","nov","dec"};
            month = -1;
            String ml = mon.toLowerCase();
            for (int i = 0; i < names.length; i++) {
                if (ml.startsWith(names[i])) { month = i + 1; break; }
            }
            if (month == -1) return null;
        }

        return String.format("%04d-%02d-%02d", year, month, Integer.parseInt(dd));
    }
}
