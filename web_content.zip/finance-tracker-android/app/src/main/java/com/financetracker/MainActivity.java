package com.financetracker;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    WebView webView;
    static MainActivity instance;
    static final int SMS_PERMISSION_CODE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccessFromFileURLs(true);
        ws.setAllowUniversalAccessFromFileURLs(true);

        webView.addJavascriptInterface(new SmsJsBridge(), "SmsBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/index.html");

        checkSmsPermission();
    }

    void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS},
                    SMS_PERMISSION_CODE);
        }
    }

    // Called from JS: triggers SMS read + parse
    class SmsJsBridge {
        @JavascriptInterface
        public String readSms() {
            if (ContextCompat.checkSelfPermission(instance, Manifest.permission.READ_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                return "[]";
            }
            return fetchAndParseSms();
        }
    }

    // Called from SmsReceiver when a new SIP SMS arrives
    public static void onNewSms(String body) {
        if (instance == null || instance.webView == null) return;
        SmsParser.ParsedSms p = SmsParser.parse(body);
        if (p == null) return;
        String js = "window.onSmsReceived && window.onSmsReceived(" + p.toJson() + ")";
        instance.runOnUiThread(() -> instance.webView.evaluateJavascript(js, null));
    }

    String fetchAndParseSms() {
        List<SmsParser.ParsedSms> results = new ArrayList<>();
        Uri uri = Uri.parse("content://sms/inbox");
        String[] proj = {"_id", "address", "body", "date"};
        // Read last 100 SMS, freshest first
        try (Cursor c = getContentResolver().query(uri, proj, null, null, "date DESC LIMIT 100")) {
            if (c != null) {
                int bodyIdx = c.getColumnIndex("body");
                while (c.moveToNext()) {
                    String body = c.getString(bodyIdx);
                    SmsParser.ParsedSms p = SmsParser.parse(body);
                    if (p != null) results.add(p);
                }
            }
        } catch (Exception e) { e.printStackTrace(); }

        JSONArray arr = new JSONArray();
        for (SmsParser.ParsedSms p : results) {
            try { arr.put(new JSONObject(p.toJson())); } catch (Exception ignored) {}
        }
        return arr.toString();
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
