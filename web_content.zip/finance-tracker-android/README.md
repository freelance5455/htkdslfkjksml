# Finance Tracker – Android App

## How to get the APK

### One-time setup
1. Go to https://github.com/new
2. Create a repo named `finance-tracker-android` (private is fine)
3. Upload all these files (drag the whole folder)

### Every time you push, GitHub builds the APK automatically:
1. Go to your repo → **Actions** tab
2. Click the latest **Build APK** run
3. Scroll down to **Artifacts** → download **FinanceTracker-debug.zip**
4. Unzip → install `app-debug.apk` on your phone

### On your phone (one-time):
- Settings → Apps → Special app access → Install unknown apps → Files → Allow

---

## SMS Fund Mapping

| SMS contains | Assigned fund | Rule |
|---|---|---|
| `HDFC MUTUAL FUN` | **Nifty 50** | 1st SMS of the day |
| `HDFC MUTUAL FUN` | **Next 50** | 2nd SMS of the day |
| `ICICI Prudentia` | **ICICI Prudential** | any |

> ⚠️ Fund names must match exactly what you typed in the app.
> Edit `SmsParser.java` lines with `"Nifty 50"`, `"Next 50"`, `"ICICI Prudential"` if yours differ.

## SMS tab (📩)
Tap **📩 SMS** in the bottom nav to read today's SIP debits and auto-fill the actual amounts.
Real-time: if the app is open when an SMS arrives, it fills automatically.
