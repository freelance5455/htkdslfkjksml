ARCADE - ANDROID WRAPPER PROJECT (TEST BUILD SETUP)

This project packages the supplied arcade HTML inside an Android WebView.


BUILD THE APK
1. Install Android Studio (official Android developer website).
2. Open this folder: ArcadeAPKProject (File > Open).
3. Allow Gradle sync and install any SDK platform it asks for.
4. In Android Studio choose Build > Build APK(s).
5. When finished, use the Build output notification's Locate link to find app-debug.apk.
6. Copy app-debug.apk to your Android phone and install it. If asked, allow installing apps from this source.


IMPORTANT TESTING NOTES
- This is a wrapper project, not a verified APK. The games should be tested on an actual Android device.
- The arcade HTML uses embedded game data and Blob URLs. Android WebView supports many such features, but game launching and fullscreen behavior should be tested.
- The original HTML is stored at app/src/main/assets/index.html. Keep all game data embedded as in the supplied file.
- App label currently: Arcade. Package: com.example.arcade.
