/* JOSTECH — MANUEL 07 : BASES DE DONNÉES NIVEAU 2 */
registerLessonDetail(7, 2, "bdd-2-1-1", {
  title: "Leçon 1 : Langage SQL Complet, Jointures et Agrégations",
  duration: "45 min (Manuel complet)",
  objectives: [
    "Maîtriser les sous-langages SQL : DDL (CREATE), DML (INSERT/UPDATE/DELETE) et DQL (SELECT).",
    "Différencier INNER JOIN et LEFT JOIN pour croiser plusieurs tables.",
    "Calculer des statistiques par groupes avec COUNT, AVG, SUM, GROUP BY et HAVING."
  ],
  prerequisites: ["Niveau 1 — Modèle relationnel (PK/FK)."],
  sections: [
    {
      type: "theory",
      title: "1. Les familles d'ordres SQL et la différence WHERE vs HAVING",
      text: "SQL (Structured Query Language) est un langage déclaratif : vous décrivez QUOI obtenir, et le moteur SGBD optimise COMMENT le chercher. Pour les statistiques, les fonctions d'agrégation (COUNT, SUM, AVG, MIN, MAX) regroupent les lignes via GROUP BY.\n\nAttention : WHERE filtre les lignes individuelles AVANT le regroupement, alors que HAVING filtre les groupes APRÈS le calcul des moyennes ou totaux !"
    },
    {
      type: "code",
      lang: "SQL — DDL, Jointures et Statistiques universitaires",
      code: [
        "-- 1) Création avec contrainte de clé étrangère :",
        "CREATE TABLE notes (",
        "  id SERIAL PRIMARY KEY,",
        "  etudiant_id INT NOT NULL REFERENCES etudiants(id) ON DELETE CASCADE,",
        "  valeur NUMERIC(4,2) CHECK (valeur >= 0 AND valeur <= 20)",
        ");",
        "",
        "-- 2) Moyenne par étudiant (uniquement ceux ayant >= 12 de moyenne) :",
        "SELECT e.nom, COUNT(n.id) AS nb_notes, ROUND(AVG(n.valeur), 2) AS moyenne",
        "FROM etudiants e",
        "LEFT JOIN notes n ON e.id = n.etudiant_id",
        "GROUP BY e.id, e.nom",
        "HAVING AVG(n.valeur) >= 12",
        "ORDER BY moyenne DESC;"
      ].join("\n")
    },
    {
      type: "table",
      title: "2. INNER JOIN vs LEFT JOIN",
      headers: ["Jointure", "Comportement exact"],
      rows: [
        ["INNER JOIN", "Ne garde que les lignes qui ont une correspondance des DEUX côtés (étudiant ayant au moins 1 note)."],
        ["LEFT JOIN", "Garde TOUS les étudiants de la table de gauche, même ceux qui n'ont aucune note (affiche NULL à droite)."]
      ]
    },
    {
      type: "warning",
      title: "Pièges destructeurs en SQL",
      text: "1) Lancer UPDATE ou DELETE sans clause WHERE précise modifie ou efface TOUTE la table en une milliseconde !\n2) Tester une valeur manquante se fait toujours avec « IS NULL » ou « IS NOT NULL », jamais « = NULL » (qui renvoie toujours Faux en logique trivaluée SQL)."
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Écrire une requête filtrée avec jointure",
      question: "Tables : Etudiants(id, nom, filiere) et Notes(id, etudiant_id, matiere, note). Écrivez la requête SQL affichant le nom et la note en 'Cybersecurite' des étudiants ayant eu strictement plus de 15, triés du plus haut au plus bas.",
      solution: "SELECT e.nom, n.note\nFROM Etudiants e\nINNER JOIN Notes n ON e.id = n.etudiant_id\nWHERE n.matiere = 'Cybersecurite' AND n.note > 15\nORDER BY n.note DESC;"
    },
    {
      title: "Exercice 2 — WHERE vs HAVING",
      question: "Pourquoi écrire « SELECT filiere, COUNT(*) FROM Etudiants WHERE COUNT(*) > 50 GROUP BY filiere; » déclenche-t-il une erreur SQL ?",
      solution: "Parce que WHERE s'exécute avant GROUP BY et ne connaît pas encore COUNT(*). Il faut remplacer WHERE par HAVING après GROUP BY :\nSELECT filiere, COUNT(*) FROM Etudiants GROUP BY filiere HAVING COUNT(*) > 50;"
    }
  ],
  summary: "SQL permet de définir des tables avec contraintes strictes (CHECK, REFERENCES), de croiser les données via INNER/LEFT JOIN et de produire des bilans via GROUP BY et HAVING.",
  references: ["PostgreSQL & MySQL Official SQL Reference.", "Beaulieu, A. — Learning SQL, O'Reilly."]
});