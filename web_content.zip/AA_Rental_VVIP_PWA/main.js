// VVIP PWA bootstrap
(() => {
  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("./sw.js", {scope: "./"}).catch(err => console.warn("Service worker registration failed:", err));
    });
  }
  let deferredPrompt = null;
  window.addEventListener("beforeinstallprompt", event => {
    event.preventDefault();
    deferredPrompt = event;
    if (document.getElementById("pwaInstallBtn")) return;
    const btn = document.createElement("button");
    btn.id = "pwaInstallBtn";
    btn.className = "btn";
    btn.type = "button";
    btn.textContent = "📲 Install App";
    btn.style.cssText = "position:fixed;right:14px;bottom:86px;z-index:140;border-radius:999px;box-shadow:0 8px 30px rgba(0,0,0,.35);";
    btn.addEventListener("click", async () => {
      if (!deferredPrompt) return;
      deferredPrompt.prompt();
      await deferredPrompt.userChoice;
      deferredPrompt = null;
      btn.remove();
    });
    document.body.appendChild(btn);
  });
  window.addEventListener("appinstalled", () => {
    deferredPrompt = null;
    document.getElementById("pwaInstallBtn")?.remove();
  });
})();