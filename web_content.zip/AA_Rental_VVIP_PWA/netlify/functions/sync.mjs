import { getStore } from "@netlify/blobs";

const store = getStore("aa-rental-private-vault");

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "access-control-allow-origin": "*",
      "access-control-allow-methods": "GET,POST,OPTIONS",
      "access-control-allow-headers": "content-type"
    }
  });
}

function validId(id) {
  return typeof id === "string" && /^[a-f0-9]{64}$/.test(id);
}

export default async function handler(req) {
  if (req.method === "OPTIONS") return json({ ok: true });
  try {
    if (req.method === "GET") {
      const id = new URL(req.url).searchParams.get("id");
      if (!validId(id)) return json({ error: "Invalid vault id" }, 400);
      const record = await store.get(id, { type: "json", consistency: "strong" });
      if (!record) return json({ error: "Not found" }, 404);
      return json({ record });
    }

    if (req.method === "POST") {
      const body = await req.json();
      if (!validId(body?.id) || !body?.record?.ciphertext || !body?.record?.salt || !body?.record?.iv) {
        return json({ error: "Invalid vault payload" }, 400);
      }
      const record = body.record;
      if (JSON.stringify(record).length > 12 * 1024 * 1024) {
        return json({ error: "Vault payload too large" }, 413);
      }
      await store.setJSON(body.id, record);
      return json({ ok: true, updatedAt: record.updatedAt || Date.now() });
    }

    return json({ error: "Method not allowed" }, 405);
  } catch (error) {
    console.error("Private vault error:", error);
    return json({ error: "Vault service unavailable" }, 500);
  }
}