AA RENTAL VVIP PWA
===================

PASSWORD / DATA BEHAVIOR (UPDATED)
-----------------------------------
1. First install / first run: Create your password once.
2. The password is remembered on this device.
3. Refreshing the page does NOT ask for the password.
4. Closing and reopening the installed PWA does NOT ask for the password while the device's site/app storage remains.
5. There is NO Lock button and there is NO manual lock flow.
6. If the device/app storage is genuinely cleared by uninstall/reinstall, the app asks for the same password again and uses it to restore the encrypted cloud vault (when the included Netlify sync function is deployed and reachable).
7. Normal offline use continues from the locally stored database.

IMPORTANT
---------
A browser/PWA cannot universally detect every kind of Android uninstall. Some Android/browser combinations may preserve site data. If storage is preserved, the app will behave as an existing installation and will not ask again. If storage is cleared, it will ask for the password and restore the encrypted vault.

NETLIFY
-------
Deploy the whole folder/site, including netlify/functions and package.json, not only Index.html, if you want encrypted reinstall recovery.

CREDIT
------
Made by Osman Abbasi
