MEU FINANCEIRO — PROJETO ANDROID

Este arquivo é o projeto-fonte para gerar o APK. Ele ainda NÃO é um APK instalável.

Como gerar o APK:
1. Em um computador, instale o Android Studio (site oficial: https://developer.android.com/studio).
2. Extraia a pasta MeuFinanceiroAndroid.
3. No Android Studio, escolha Open e selecione a pasta extraída.
4. Aguarde o Gradle sincronizar. É necessário internet na primeira sincronização para baixar ferramentas.
5. No menu Build, escolha Build Bundle(s) / APK(s) > Build APK(s).
6. Quando terminar, clique em locate para encontrar o arquivo app-debug.apk.
7. Transfira o APK para o Android e abra-o para instalar. O Android pode pedir autorização para instalar apps dessa fonte.

O aplicativo:
- Nome: Meu Financeiro
- Pacote: com.meufinanceiro.app
- Registra entradas, gastos, dívidas pagas e dinheiro guardado.
- Atualiza os totais, gráfico, resumo diário e histórico.
- Guarda os registros localmente no aparelho usando o armazenamento do navegador WebView.
- Permite exportar o histórico em CSV.

IMPORTANTE:
- Os dados ficam neste aparelho; não há sincronização em nuvem.
- Faça exportações CSV como backup.
- O projeto usa Android Gradle Plugin 8.7.3 e compileSdk 35.
- Para gerar APK de distribuição assinado, configure uma chave em Build > Generate Signed Bundle / APK.
