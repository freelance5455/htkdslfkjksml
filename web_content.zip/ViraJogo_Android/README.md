# Vira Jogo — projeto Android inicial

Este projeto empacota o jogo Desafio Relâmpago num aplicativo Android com WebView e inclui um banner de anúncios de TESTE do Google AdMob.

## Importante sobre anúncios e ganhos
- O ID do app e o banner incluídos são IDs oficiais de teste do Google. Eles não geram receita.
- Para monetizar, crie uma conta AdMob, cadastre o aplicativo, substitua os dois IDs de teste pelos IDs reais e siga as políticas do Google.
- Não clique nos anúncios de teste repetidamente nem tente gerar cliques artificiais.
- A aprovação da conta/app e a receita não são garantidas.

## Como gerar o APK usando Android Studio
1. Instale o Android Studio num computador e instale o Android SDK 35.
2. Abra a pasta `ViraJogo_Android` no Android Studio.
3. Aguarde o Gradle sincronizar. Se o Android Studio solicitar, instale o SDK e as ferramentas recomendadas.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de depuração normalmente aparecerá em `app/build/outputs/apk/debug/app-debug.apk`.

## Para instalar no celular
Transfira o APK para o Android, toque no arquivo e permita a instalação dessa fonte se o sistema solicitar.

## Próximos passos antes de publicar
- Trocar os IDs de teste do AdMob pelos IDs próprios.
- Adicionar política de privacidade e página de suporte.
- Testar em diferentes tamanhos de tela.
- Preparar ícone, nome final, classificação indicativa e ficha da loja.
- Criar uma versão assinada para distribuição.

## Estrutura
- `app/src/main/assets/index.html`: jogo Desafio Relâmpago.
- `app/src/main/java/com/virajogo/app/MainActivity.java`: tela Android e banner AdMob.
- `app/src/main/AndroidManifest.xml`: permissões e configuração do app.
