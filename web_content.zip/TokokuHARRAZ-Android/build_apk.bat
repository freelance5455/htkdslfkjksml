@echo off
echo Tokoku HARRAZ - Build Debug APK
echo.
echo Buka project ini di Android Studio untuk memastikan SDK sudah tersedia.
echo Jika Gradle wrapper sudah dibuat oleh Android Studio, jalankan:
echo   gradlew.bat assembleDebug
echo.
pause
