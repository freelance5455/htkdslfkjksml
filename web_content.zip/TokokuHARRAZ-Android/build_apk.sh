#!/bin/sh
echo "Tokoku HARRAZ - Build Debug APK"
echo "Buka project di Android Studio dan lakukan Gradle Sync."
echo "Jika Gradle wrapper tersedia:"
echo "  ./gradlew assembleDebug"
