# Tokoku HARRAZ — Android Project

Proyek Android WebView untuk aplikasi Tokoku HARRAZ.

## Isi
- `app/src/main/assets/tokoku_harraz.html` — aplikasi Tokoku HARRAZ terpadu.
- `MainActivity.java` — WebView, localStorage, file picker untuk Restore, dan penyimpanan Backup/CSV ke folder Download/Tokoku HARRAZ.
- Tidak membutuhkan server atau database eksternal.
- Data aplikasi disimpan di localStorage WebView pada perangkat.

## Build dengan Android Studio
1. Ekstrak ZIP ini.
2. Buka folder `TokokuHARRAZ` di Android Studio.
3. Tunggu Gradle Sync selesai dan izinkan Android Studio mengunduh komponen SDK/Gradle yang diperlukan.
4. Pastikan Android SDK Platform 35 terpasang.
5. Pilih `Build > Build App Bundle(s) / APK(s) > Build APK(s)`.
6. APK debug biasanya berada di:
   `app/build/outputs/apk/debug/app-debug.apk`

## APK Release
Untuk APK yang siap dibagikan:
`Build > Generate Signed App Bundle / APK > APK`
Lalu buat/pilih keystore dan lakukan signing.

## Catatan
- Versi aplikasi: 1.0.0
- Minimum Android: Android 6.0 (API 23)
- Target SDK: 35
- Package: `com.harraz.tokoku`
- Nama aplikasi: Tokoku HARRAZ

## Alur data
Produk -> Kasir/Troli -> Checkout -> Riwayat + Laci + Stok
Produk -> Harga Beli (HPP) + Harga Jual -> Laba Kotor
Manajemen -> Entitas / Hutang Piutang / Pengeluaran / Diskon / Laci / Antrian / Kategori / Meja / Ekspor
Pengaturan -> Bahasa / Mata Uang / PIN / Printer / Struk / Backup / Restore


## Printer Thermal
- Preview struk tetap berjalan dari aplikasi.
- APK menyediakan bridge cetak ESC/POS melalui Bluetooth printer yang sudah dipasangkan.
- USB OTG printer yang mengizinkan akses USB juga dicoba otomatis sebagai fallback.
- Ukuran kertas 58 mm / 80 mm dikirim dari pengaturan aplikasi.
- Gunakan `Test Print` dari aplikasi setelah printer dipasangkan/diizinkan.
- Implementasi memilih printer Bluetooth yang sudah bonded; jika tidak ada nama yang cocok, perangkat bonded pertama digunakan.
