package com.harraz.tokoku;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER = 1001;
    private static final int STORAGE_PERMISSION = 1002;
    private static final int BT_PERMISSION = 1003;
    private static final UUID SPP_UUID =
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingFileName, pendingContent, pendingMime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        android.webkit.WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);

        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent;
                try { intent = params.createIntent(); }
                catch (Exception e) {
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                }
                startActivityForResult(intent, FILE_CHOOSER);
                return true;
            }
        });

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.loadUrl("file:///android_asset/tokoku_harraz.html");
    }

    public class AndroidBridge {
        @JavascriptInterface public void saveTextFile(String fileName, String content, String mimeType) {
            runOnUiThread(() -> saveFile(fileName, content, mimeType));
        }

        @JavascriptInterface public void printReceipt(String json, String widthMm) {
            new Thread(() -> {
                try {
                    JSONObject tx = new JSONObject(json);
                    byte[] bytes = buildEscPos(tx, Integer.parseInt(widthMm));
                    boolean ok = printBluetooth(bytes);
                    if (!ok) ok = printUsb(bytes);
                    final boolean result = ok;
                    runOnUiThread(() -> Toast.makeText(MainActivity.this,
                            result ? "Struk berhasil dikirim ke printer"
                                   : "Printer tidak ditemukan/terhubung",
                            Toast.LENGTH_LONG).show());
                } catch (Exception e) {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this,
                            "Gagal mencetak: " + e.getMessage(), Toast.LENGTH_LONG).show());
                }
            }).start();
        }

        @JavascriptInterface public void testPrint(String widthMm) {
            new Thread(() -> {
                try {
                    int width = Integer.parseInt(widthMm);
                    JSONObject tx = new JSONObject();
                    tx.put("store", "TOKOKU HARRAZ");
                    tx.put("address", "TEST PRINT");
                    tx.put("id", "TEST-0001");
                    tx.put("date", "Printer Thermal OK");
                    tx.put("items", new JSONArray());
                    tx.put("subtotal", 0);
                    tx.put("discount", 0);
                    tx.put("total", 0);
                    tx.put("paid", 0);
                    tx.put("change", 0);
                    byte[] bytes = buildEscPos(tx, width);
                    boolean ok = printBluetooth(bytes);
                    if (!ok) ok = printUsb(bytes);
                    final boolean result = ok;
                    runOnUiThread(() -> Toast.makeText(MainActivity.this,
                            result ? "Test print berhasil dikirim"
                                   : "Printer tidak ditemukan/terhubung",
                            Toast.LENGTH_LONG).show());
                } catch (Exception e) {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this,
                            "Test print gagal: " + e.getMessage(), Toast.LENGTH_LONG).show());
                }
            }).start();
        }
    }

    private byte[] buildEscPos(JSONObject tx, int widthMm) throws Exception {
        StringBuilder s = new StringBuilder();
        int chars = widthMm >= 80 ? 48 : 32;

        s.append("\u001B@"); // init
        s.append("\u001Ba\u0001"); // center
        s.append("\u001BE\u0001");
        s.append(line(tx.optString("store", "TOKOKU HARRAZ"), chars)).append("\n");
        s.append("\u001BE\u0000");
        String address = tx.optString("address", "");
        if (!address.isEmpty()) s.append(line(address, chars)).append("\n");
        String phone = tx.optString("phone", "");
        if (!phone.isEmpty()) s.append(line(phone, chars)).append("\n");
        s.append("--------------------------------").append("\n");
        s.append("\u001Ba\u0000");
        s.append("No : ").append(tx.optString("id","")).append("\n");
        s.append("Tgl: ").append(tx.optString("date","")).append("\n");
        if (!tx.optString("customer","").isEmpty())
            s.append("Pelanggan: ").append(tx.optString("customer","")).append("\n");
        if (!tx.optString("cashier","").isEmpty())
            s.append("Kasir: ").append(tx.optString("cashier","")).append("\n");
        s.append("--------------------------------").append("\n");

        JSONArray items = tx.optJSONArray("items");
        if (items != null) {
            for (int i=0;i<items.length();i++) {
                JSONObject it = items.getJSONObject(i);
                String name = it.optString("name","");
                int qty = it.optInt("qty",0);
                long price = it.optLong("price",0);
                long sub = it.optLong("subtotal", price*qty);
                s.append(wrapItem(name, qty, price, sub, chars));
            }
        }
        s.append("--------------------------------").append("\n");
        s.append(twoCol("Subtotal", money(tx.optLong("subtotal",0)), chars));
        s.append(twoCol("Diskon", money(tx.optLong("discount",0)), chars));
        s.append(twoCol("TOTAL", money(tx.optLong("total",0)), chars));
        s.append(twoCol("Bayar", money(tx.optLong("paid",0)), chars));
        s.append(twoCol("Kembali", money(tx.optLong("change",0)), chars));
        if (!tx.optString("method","").isEmpty())
            s.append(twoCol("Metode", tx.optString("method",""), chars));

        s.append("\n");
        s.append("\u001Ba\u0001");
        s.append("Terima kasih").append("\n");
        s.append("TOKOKU HARRAZ").append("\n\n\n");
        s.append("\u001DVA\u0000"); // cut if supported
        return s.toString().getBytes("ISO-8859-1");
    }

    private String wrapItem(String name, int qty, long price, long sub, int chars) {
        String right = qty + "x " + money(price);
        String line1 = name;
        if (line1.length() > chars) line1 = line1.substring(0, chars);
        StringBuilder out = new StringBuilder();
        out.append(line1).append("\n");
        String detail = "  " + right;
        String total = money(sub);
        int gap = Math.max(1, chars - detail.length() - total.length());
        out.append(detail);
        for (int i=0;i<gap;i++) out.append(' ');
        out.append(total).append("\n");
        return out.toString();
    }

    private String twoCol(String left, String right, int width) {
        int gap = Math.max(1, width - left.length() - right.length());
        StringBuilder b = new StringBuilder(left);
        for (int i=0;i<gap;i++) b.append(' ');
        b.append(right).append("\n");
        return b.toString();
    }

    private String line(String x, int width) {
        if (x == null) return "";
        return x.length() <= width ? x : x.substring(0, width);
    }

    private String money(long n) {
        return String.format("Rp %,d", n).replace(',', '.');
    }

    private boolean printBluetooth(byte[] bytes) {
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null || !adapter.isEnabled()) return false;

            if (Build.VERSION.SDK_INT >= 31 &&
                    checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                            != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, BT_PERMISSION);
                return false;
            }

            Set<BluetoothDevice> devices = adapter.getBondedDevices();
            if (devices == null || devices.isEmpty()) return false;

            // Prefer bonded printers whose name suggests thermal/receipt.
            BluetoothDevice selected = null;
            for (BluetoothDevice d : devices) {
                String n = d.getName();
                if (n != null && (n.toLowerCase().contains("print") ||
                        n.toLowerCase().contains("thermal") ||
                        n.toLowerCase().contains("pos") ||
                        n.toLowerCase().contains("rpp"))) {
                    selected = d;
                    break;
                }
            }
            if (selected == null) selected = devices.iterator().next();

            try (BluetoothSocket socket = selected.createRfcommSocketToServiceRecord(SPP_UUID)) {
                socket.connect();
                OutputStream out = socket.getOutputStream();
                out.write(bytes);
                out.flush();
                return true;
            }
        } catch (Exception ignored) {
            return false;
        }
    }

    private boolean printUsb(byte[] bytes) {
        try {
            UsbManager manager = (UsbManager) getSystemService(USB_SERVICE);
            if (manager == null) return false;

            for (UsbDevice device : manager.getDeviceList().values()) {
                if (!manager.hasPermission(device)) continue;

                for (int i=0;i<device.getInterfaceCount();i++) {
                    UsbInterface intf = device.getInterface(i);
                    if (intf.getEndpointCount() == 0) continue;

                    UsbEndpoint outEp = null;
                    for (int j=0;j<intf.getEndpointCount();j++) {
                        UsbEndpoint ep = intf.getEndpoint(j);
                        if (ep.getDirection() == 0) { // USB_DIR_OUT
                            outEp = ep; break;
                        }
                    }
                    if (outEp == null) continue;

                    UsbDeviceConnection conn = manager.openDevice(device);
                    if (conn == null) continue;

                    conn.claimInterface(intf, true);
                    int sent = conn.bulkTransfer(outEp, bytes, bytes.length, 5000);
                    conn.releaseInterface(intf);
                    conn.close();
                    if (sent > 0) return true;
                }
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private void saveFile(String fileName, String content, String mimeType) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                values.put(MediaStore.Downloads.MIME_TYPE, mimeType);
                values.put(MediaStore.Downloads.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS + "/Tokoku HARRAZ");
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                Uri uri = getContentResolver().insert(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("Gagal membuat file");
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    out.write(content.getBytes(StandardCharsets.UTF_8));
                }
                values.clear();
                values.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, values, null, null);
                Toast.makeText(this, "File tersimpan di Download/Tokoku HARRAZ",
                        Toast.LENGTH_LONG).show();
            } else {
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                    pendingFileName=fileName; pendingContent=content; pendingMime=mimeType;
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                            STORAGE_PERMISSION);
                    return;
                }
                java.io.File dir = new java.io.File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                        "Tokoku HARRAZ");
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("Folder gagal dibuat");
                java.io.File file = new java.io.File(dir, fileName);
                try (FileOutputStream out = new FileOutputStream(file)) {
                    out.write(content.getBytes(StandardCharsets.UTF_8));
                }
                Toast.makeText(this, "File tersimpan di Download/Tokoku HARRAZ",
                        Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Gagal menyimpan file: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == STORAGE_PERMISSION && results.length > 0 &&
                results[0] == PackageManager.PERMISSION_GRANTED && pendingFileName != null) {
            String n=pendingFileName,c=pendingContent,m=pendingMime;
            pendingFileName=pendingContent=pendingMime=null;
            saveFile(n,c,m);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER) {
            if (fileCallback == null) return;
            Uri[] result=null;
            if (resultCode==RESULT_OK && data!=null) {
                if (data.getClipData()!=null) {
                    int count=data.getClipData().getItemCount();
                    result=new Uri[count];
                    for(int i=0;i<count;i++) result[i]=data.getClipData().getItemAt(i).getUri();
                } else if(data.getData()!=null) result=new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(result);
            fileCallback=null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("Android");
            webView.destroy();
        }
        super.onDestroy();
    }
}
