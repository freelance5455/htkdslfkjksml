JIGSAW PUZZLE — Starter Project

WHAT'S INCLUDED
- Modern colorful mobile-friendly puzzle game
- Four built-in pictures
- Choose a photo from your phone gallery
- Easy (3x3), Medium (4x4), Hard (5x5)
- Timer, moves, score, shuffle, restart
- Offline gameplay after the files are extracted

HOW TO PLAY ON YOUR PHONE
1. Extract Jigsaw_Puzzle.zip using your phone's Files app.
2. Open the extracted Jigsaw_Puzzle folder.
3. Tap index.html and open it in Chrome (or another browser).
4. Choose a picture and difficulty, then tap tiles to swap them.

IMPORTANT
This ZIP is the HTML source/playable prototype, NOT an APK or Play Store upload.
To publish as an Android app, it must first be packaged and built into an Android APK/AAB.
