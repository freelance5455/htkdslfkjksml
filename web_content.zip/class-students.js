/* =========================================================
   CLASS STUDENTS
   إدارة طلاب الصف + OCR
   النسخة المعدلة النهائية
========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    /* =========================================================
       HELPERS
    ========================================================= */

    const $ = id => document.getElementById(id);

    function on(element, event, handler, options) {
        if (!element) return;
        element.addEventListener(event, handler, options);
    }

    function createId() {
        return (
            Date.now().toString(36) +
            "-" +
            Math.random().toString(36).slice(2)
        );
    }

    function escapeHTML(text) {
        return String(text ?? "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function normalizeArabic(text) {
        return String(text || "")
            .replace(/[\u064B-\u065F\u0670\u0640]/g, "")
            .replace(/[إأآٱ]/g, "ا")
            .replace(/ى/g, "ي")
            .replace(/ة/g, "ه")
            .replace(/\s+/g, " ")
            .trim()
            .toLowerCase();
    }


    /* =========================================================
       ELEMENTS
    ========================================================= */

    const backButton = $("backButton");

    const classNumber = $("classNumber");
    const className = $("className");
    const classSection = $("classSection");
    const classCode = $("classCode");

    const studentsCount = $("studentsCount");
    const studentCountLabel = $("studentCountLabel");
    const studentsList = $("studentsList");
    const emptyState = $("emptyState");

    const studentSearch = $("studentSearch");
    const clearSearchButton = $("clearSearchButton");

    const addStudentButton = $("addStudentButton");
    const emptyAddButton = $("emptyAddButton");
    const importStudentsButton = $("importStudentsButton");

    const importModal = $("importModal");
    const closeImportModal = $("closeImportModal");

    const galleryButton = $("galleryButton");
    const galleryInput = $("galleryInput");

    const imageEditor = $("imageEditor");
    const sourceImage = $("sourceImage");
    const cropContainer = $("cropContainer");
    const cropFrame = $("cropFrame");

    const rotateImageButton = $("rotateImageButton");
    const replaceImageButton = $("replaceImageButton");
    const analyzeImageButton = $("analyzeImageButton");

    const zoomInButton = $("zoomInButton");
    const zoomOutButton = $("zoomOutButton");
    const resetImageButton = $("resetImageButton");
    const zoomValue = $("zoomValue");

    const ocrProgress = $("ocrProgress");
    const ocrStatus = $("ocrStatus");
    const ocrPercent = $("ocrPercent");
    const ocrProgressBar = $("ocrProgressBar");

    const ocrReview = $("ocrReview");
    const recognizedList = $("recognizedList");
    const recognizedCount = $("recognizedCount");

    const cancelRecognitionButton =
        $("cancelRecognitionButton");

    const saveRecognizedButton =
        $("saveRecognizedButton");

    const studentModal = $("studentModal");
    const closeStudentModal = $("closeStudentModal");
    const cancelStudentButton = $("cancelStudentButton");
    const saveStudentButton = $("saveStudentButton");
    const studentNameInput = $("studentNameInput");

    const homeNavigation = $("homeNavigation");
    const studentsNavigation = $("studentsNavigation");
    const attendanceNavigation = $("attendanceNavigation");
    const scheduleNavigation = $("scheduleNavigation");
    const gradesNavigation = $("gradesNavigation");
    const reportsNavigation = $("reportsNavigation");


    /* =========================================================
       CLASS DATA
    ========================================================= */

    const params =
        new URLSearchParams(window.location.search);

    let classId =
        params.get("class") ||
        params.get("classId") ||
        localStorage.getItem("mueen_current_class") ||
        "3/5";

    let classes = [];

    try {

        const stored =
            localStorage.getItem("mueen_classes");

        classes =
            stored
                ? JSON.parse(stored)
                : [];

        if (!Array.isArray(classes)) {
            classes = [];
        }

    } catch (error) {

        console.error(
            "خطأ في قراءة الصفوف:",
            error
        );

        classes = [];

    }


    let currentClass =
        classes.find(item => {

            if (!item) return false;

            return (
                String(item.code ?? "") === String(classId) ||
                String(item.id ?? "") === String(classId) ||
                String(item.classId ?? "") === String(classId)
            );

        });


    if (!currentClass) {

        const savedCurrent =
            localStorage.getItem(
                "mueen_current_class"
            );

        if (savedCurrent) {

            currentClass =
                classes.find(item => {

                    if (!item) return false;

                    return (
                        String(item.code ?? "") ===
                            String(savedCurrent) ||

                        String(item.id ?? "") ===
                            String(savedCurrent)
                    );

                });

        }

    }


    if (!currentClass) {

        currentClass = {

            id: String(classId),

            code: String(classId),

            stage: "المرحلة الابتدائية",

            grade: "الصف الثالث الابتدائي",

            section: "الفصل الخامس",

            students: []

        };

    }


    if (!Array.isArray(currentClass.students)) {
        currentClass.students = [];
    }


    /* =========================================================
       STUDENTS
    ========================================================= */

    let students =
        currentClass.students
            .map((student, index) => {

                if (typeof student === "string") {

                    const name =
                        student
                            .replace(/\s+/g, " ")
                            .trim();

                    if (!name) return null;

                    return {
                        id:
                            "s-" +
                            index +
                            "-" +
                            createId(),

                        name
                    };

                }


                if (
                    student &&
                    typeof student === "object"
                ) {

                    const name =
                        String(
                            student.name ??
                            student.studentName ??
                            student.fullName ??
                            student.title ??
                            ""
                        )
                            .replace(/\s+/g, " ")
                            .trim();

                    if (!name) return null;

                    return {

                        id:
                            student.id ??
                            student.studentId ??
                            student.key ??
                            (
                                "s-" +
                                index +
                                "-" +
                                createId()
                            ),

                        name

                    };

                }

                return null;

            })
            .filter(Boolean);


    /* =========================================================
       SAVE CLASS
    ========================================================= */

    function saveClass() {

        currentClass.students =
            students;

        const index =
            classes.findIndex(item => {

                if (!item) return false;

                return (
                    String(item.id ?? "") ===
                        String(currentClass.id) ||

                    String(item.code ?? "") ===
                        String(currentClass.code)
                );

            });


        if (index >= 0) {

            classes[index] =
                currentClass;

        } else {

            classes.push(
                currentClass
            );

        }


        try {

            localStorage.setItem(
                "mueen_classes",
                JSON.stringify(classes)
            );

            localStorage.setItem(
                "mueen_current_class",
                String(
                    currentClass.code ??
                    currentClass.id ??
                    classId
                )
            );

            return true;

        } catch (error) {

            console.error(
                "خطأ في حفظ بيانات الصف:",
                error
            );

            return false;

        }

    }


    saveClass();


    /* =========================================================
       EMPTY STATE
    ========================================================= */

    function setEmptyState(show) {

        if (!emptyState) return;

        emptyState.hidden =
            !show;

        emptyState.style.setProperty(
            "display",
            show ? "" : "none",
            "important"
        );

    }


    function setStudentsListVisible(show) {

        if (!studentsList) return;

        studentsList.hidden =
            !show;

        studentsList.style.setProperty(
            "display",
            show ? "" : "none",
            "important"
        );

    }


    /* =========================================================
       CLASS HEADER
    ========================================================= */

    function renderClassHeader() {

        if (classNumber) {

            classNumber.textContent =
                currentClass.code ||
                classId;

        }


        if (classCode) {

            classCode.textContent =
                currentClass.code ||
                classId;

        }


        if (className) {

            className.textContent =
                currentClass.grade ||
                currentClass.name ||
                "الصف الدراسي";

        }


        if (classSection) {

            classSection.textContent =
                currentClass.section ||
                "الفصل الدراسي";

        }

    }


    /* =========================================================
       STUDENTS RENDER
    ========================================================= */

    function renderStudents() {

        if (!studentsList) return;


        const query =
            normalizeArabic(
                studentSearch
                    ? studentSearch.value
                    : ""
            );


        if (clearSearchButton) {

            clearSearchButton.classList.toggle(
                "visible",
                Boolean(
                    studentSearch &&
                    studentSearch.value.trim()
                )
            );

        }


        const filtered =
            students.filter(student => {

                if (!query) return true;

                return normalizeArabic(
                    student.name
                ).includes(query);

            });


        studentsList.innerHTML =
            "";


        if (studentsCount) {

            studentsCount.textContent =
                students.length;

        }


        if (studentCountLabel) {

            studentCountLabel.textContent =
                `${students.length} طالب`;

        }


        if (students.length === 0) {

            setStudentsListVisible(false);

            setEmptyState(true);

            return;

        }


        setStudentsListVisible(true);

        setEmptyState(false);


        if (filtered.length === 0) {

            const noResults =
                document.createElement("div");

            noResults.className =
                "students-no-results";

            noResults.innerHTML = `
                <div
                    style="
                        padding:22px 12px;
                        text-align:center;
                        color:#687B80;
                        font-size:13px;
                        font-weight:700;
                    "
                >
                    لا توجد نتيجة مطابقة للبحث.
                </div>
            `;

            studentsList.appendChild(
                noResults
            );

            return;

        }


        filtered.forEach(student => {

            const originalIndex =
                students.findIndex(
                    item =>
                        String(item.id) ===
                        String(student.id)
                );


            const card =
                document.createElement("div");

            card.className =
                "student-card";


            card.innerHTML = `

                <div class="student-number">
                    ${originalIndex + 1}
                </div>

                <div class="student-name-wrap">

                    <div
                        class="student-name"
                        title="${escapeHTML(student.name)}"
                    >
                        ${escapeHTML(student.name)}
                    </div>

                </div>

                <div class="student-actions">

                    <button
                        type="button"
                        class="student-edit"
                        data-id="${escapeHTML(student.id)}"
                        aria-label="تعديل الطالب"
                    >
                        <svg
                            viewBox="0 0 24 24"
                            aria-hidden="true"
                        >
                            <path
                                d="M4 20h4l10.5-10.5a2.1 2.1 0 0 0-3-3L5 17v3Z"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.6"
                                stroke-linejoin="round"
                            />
                        </svg>
                    </button>

                    <button
                        type="button"
                        class="student-delete"
                        data-id="${escapeHTML(student.id)}"
                        aria-label="حذف الطالب"
                    >
                        <svg
                            viewBox="0 0 24 24"
                            aria-hidden="true"
                        >
                            <path
                                d="M5 7h14M9 7V4h6v3M8 10v7M12 10v7M16 10v7M6 7l1 14h10l1-14"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.5"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                            />
                        </svg>
                    </button>

                </div>
            `;


            studentsList.appendChild(
                card
            );

        });

    }


    /* =========================================================
       ADD STUDENT
    ========================================================= */

    function openStudentModal() {

        if (!studentModal) return;

        if (studentNameInput) {
            studentNameInput.value = "";
        }

        studentModal.hidden = false;

        setTimeout(() => {

            if (studentNameInput) {
                studentNameInput.focus();
            }

        }, 100);

    }


    function closeStudentModalWindow() {

        if (studentModal) {
            studentModal.hidden = true;
        }

    }


    function addStudent() {

        if (!studentNameInput) return;


        const name =
            studentNameInput.value
                .replace(/\s+/g, " ")
                .trim();


        if (!name) {

            studentNameInput.focus();

            return;

        }


        const normalizedName =
            normalizeArabic(name);


        const duplicate =
            students.some(student =>
                normalizeArabic(student.name) ===
                normalizedName
            );


        if (duplicate) {

            alert(
                "هذا الطالب موجود بالفعل في القائمة."
            );

            return;

        }


        students.push({

            id: createId(),

            name

        });


        saveClass();

        closeStudentModalWindow();

        renderStudents();

    }


    on(
        addStudentButton,
        "click",
        openStudentModal
    );

    on(
        emptyAddButton,
        "click",
        openStudentModal
    );

    on(
        closeStudentModal,
        "click",
        closeStudentModalWindow
    );

    on(
        cancelStudentButton,
        "click",
        closeStudentModalWindow
    );

    on(
        saveStudentButton,
        "click",
        addStudent
    );


    on(
        studentNameInput,
        "keydown",
        event => {

            if (event.key === "Enter") {

                event.preventDefault();

                addStudent();

            }

        }
    );


    /* =========================================================
       EDIT / DELETE
    ========================================================= */

    on(
        studentsList,
        "click",
        event => {

            const editButton =
                event.target.closest(
                    ".student-edit"
                );

            const deleteButton =
                event.target.closest(
                    ".student-delete"
                );


            if (editButton) {

                editStudent(
                    editButton.dataset.id
                );

                return;

            }


            if (deleteButton) {

                deleteStudent(
                    deleteButton.dataset.id
                );

            }

        }
    );


    function editStudent(id) {

        const student =
            students.find(
                item =>
                    String(item.id) ===
                    String(id)
            );


        if (!student) return;


        const newName =
            prompt(
                "تعديل اسم الطالب",
                student.name
            );


        if (newName === null) return;


        const cleaned =
            newName
                .replace(/\s+/g, " ")
                .trim();


        if (!cleaned) return;


        const normalizedName =
            normalizeArabic(cleaned);


        const duplicate =
            students.some(item =>

                String(item.id) !==
                    String(id) &&

                normalizeArabic(item.name) ===
                normalizedName

            );


        if (duplicate) {

            alert(
                "يوجد طالب آخر بنفس الاسم."
            );

            return;

        }


        student.name =
            cleaned;


        saveClass();

        renderStudents();

    }


    function deleteStudent(id) {

        const student =
            students.find(
                item =>
                    String(item.id) ===
                    String(id)
            );


        if (!student) return;


        const confirmed =
            confirm(
                `هل تريد حذف الطالب "${student.name}"؟`
            );


        if (!confirmed) return;


        students =
            students.filter(
                item =>
                    String(item.id) !==
                    String(id)
            );


        saveClass();

        renderStudents();

    }


    /* =========================================================
       SEARCH
    ========================================================= */

    on(
        studentSearch,
        "input",
        renderStudents
    );


    on(
        clearSearchButton,
        "click",
        () => {

            if (!studentSearch) return;

            studentSearch.value = "";

            renderStudents();

            studentSearch.focus();

        }
    );


    /* =========================================================
       IMPORT
       استيراد صورة من الجهاز فقط — بدون تصوير
    ========================================================= */

    /* =========================================================
       OPEN GALLERY
    ========================================================= */

    function openGalleryDirectly(event) {

        if (event) {

            event.preventDefault();

            event.stopPropagation();

            if (event.stopImmediatePropagation) {
                event.stopImmediatePropagation();
            }

        }


        if (!galleryInput) {

            alert(
                "تعذر فتح معرض الصور."
            );

            return;

        }


        galleryInput.value = "";


        try {

            galleryInput.click();

        } catch (error) {

            console.error(
                "GALLERY ERROR:",
                error
            );

        }

    }


    if (importStudentsButton) {
        importStudentsButton.addEventListener("click", event => {
            event.preventDefault(); event.stopPropagation();
            if (event.stopImmediatePropagation) event.stopImmediatePropagation();
            openGalleryDirectly();
        }, true);
    }


    if (galleryButton) {

        galleryButton.addEventListener(
            "click",
            openGalleryDirectly,
            true
        );

    }


    /* =========================================================
       REPLACE IMAGE
    ========================================================= */

    if (replaceImageButton) {

        replaceImageButton.addEventListener(
            "click",
            event => {

                event.preventDefault();
                event.stopPropagation();

                if (event.stopImmediatePropagation) {
                    event.stopImmediatePropagation();
                }


                if (ocrReview) {
                    ocrReview.hidden = true;
                }

                hideOCRProgress();

                openGalleryDirectly();

            },
            true
        );

    }


    /* =========================================================
       IMPORT MODAL
    ========================================================= */

    function showImportModal() {

        if (!importModal) return;

        importModal.hidden = false;

        importModal.style.setProperty(
            "display",
            "flex",
            "important"
        );

    }


    function hideImportModal() {

        if (!importModal) return;

        importModal.hidden = true;

        importModal.style.setProperty(
            "display",
            "none",
            "important"
        );

    }


    on(
        closeImportModal,
        "click",
        () => {

            hideImportModal();

            resetImport();

        }
    );


    /* =========================================================
       OCR PROGRESS
       لا يظهر أثناء القص
    ========================================================= */

    function hideOCRProgress() {

        if (!ocrProgress) return;

        ocrProgress.hidden = true;

        ocrProgress.style.setProperty(
            "display",
            "none",
            "important"
        );

    }


    function showOCRProgress() {

        if (!ocrProgress) return;

        ocrProgress.hidden = false;

        ocrProgress.style.setProperty(
            "display",
            "flex",
            "important"
        );

    }


    function setOCRStatus(text) {

        if (!ocrStatus) return;

        ocrStatus.textContent =
            text || "";

    }


    /* =========================================================
       SAVE LOADING WINDOW
       نافذة تحميل مستقلة في منتصف الشاشة
    ========================================================= */

    let saveLoadingOverlay = null;


    function createSaveLoadingOverlay() {

        if (saveLoadingOverlay) {
            return saveLoadingOverlay;
        }


        const overlay =
            document.createElement("div");


        overlay.className =
            "save-loading-overlay";


        overlay.innerHTML = `

            <div
                class="save-loading-box"
                role="status"
                aria-live="polite"
            >

                <div class="save-loading-spinner">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>

                <div class="save-loading-title">
                    جاري حفظ الطلاب
                </div>

                <div class="save-loading-text">
                    يتم حفظ الأسماء وإتمام العملية...
                </div>

            </div>

        `;


        const style =
            document.createElement("style");


        style.id =
            "mueen-save-loading-style";


        style.textContent = `

            .save-loading-overlay {
                position: fixed !important;
                inset: 0 !important;
                width: 100% !important;
                height: 100% !important;
                display: none !important;
                align-items: center !important;
                justify-content: center !important;
                background: rgba(7, 59, 70, 0.28) !important;
                backdrop-filter: blur(5px) !important;
                -webkit-backdrop-filter: blur(5px) !important;
                z-index: 999999 !important;
                direction: rtl !important;
                box-sizing: border-box !important;
                padding: 20px !important;
            }

            .save-loading-overlay.is-visible {
                display: flex !important;
            }

            .save-loading-box {
                width: min(88vw, 330px) !important;
                min-height: 185px !important;
                background: #ffffff !important;
                border: 1px solid #E3E9E7 !important;
                border-radius: 24px !important;
                box-shadow:
                    0 22px 60px rgba(7, 59, 70, 0.20) !important;
                display: flex !important;
                flex-direction: column !important;
                align-items: center !important;
                justify-content: center !important;
                text-align: center !important;
                padding: 28px 22px !important;
                box-sizing: border-box !important;
                animation: mueenSaveBoxIn .22s ease-out both !important;
            }

            .save-loading-spinner {
                width: 48px !important;
                height: 48px !important;
                position: relative !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                margin-bottom: 17px !important;
            }

            .save-loading-spinner::before {
                content: "" !important;
                position: absolute !important;
                inset: 2px !important;
                border-radius: 50% !important;
                border: 4px solid #E5CD98 !important;
                border-top-color: #073B46 !important;
                animation: mueenSaveSpin .8s linear infinite !important;
                box-sizing: border-box !important;
            }

            .save-loading-spinner span {
                display: none !important;
            }

            .save-loading-title {
                color: #073B46 !important;
                font-size: 18px !important;
                line-height: 1.5 !important;
                font-weight: 800 !important;
                margin: 0 !important;
            }

            .save-loading-text {
                color: #687B80 !important;
                font-size: 13px !important;
                line-height: 1.7 !important;
                font-weight: 600 !important;
                margin-top: 7px !important;
            }

            @keyframes mueenSaveSpin {
                from {
                    transform: rotate(0deg);
                }

                to {
                    transform: rotate(360deg);
                }
            }

            @keyframes mueenSaveBoxIn {
                from {
                    opacity: 0;
                    transform: translateY(8px) scale(.97);
                }

                to {
                    opacity: 1;
                    transform: translateY(0) scale(1);
                }
            }

            @media (prefers-reduced-motion: reduce) {

                .save-loading-spinner::before {
                    animation: none !important;
                }

                .save-loading-box {
                    animation: none !important;
                }

            }

        `;


        document.head.appendChild(style);

        document.body.appendChild(overlay);


        saveLoadingOverlay =
            overlay;


        return overlay;

    }


    function showSaveLoading() {

        const overlay =
            createSaveLoadingOverlay();


        if (!overlay) return;


        overlay.classList.add(
            "is-visible"
        );


        document.body.style.setProperty(
            "overflow",
            "hidden",
            "important"
        );

    }


    function hideSaveLoading() {

        if (!saveLoadingOverlay) {
            return;
        }


        saveLoadingOverlay.classList.remove(
            "is-visible"
        );


        document.body.style.removeProperty(
            "overflow"
        );

    }


    /* =========================================================
       RESET IMPORT
    ========================================================= */

    function resetImport() {

        if (imageEditor) {

            imageEditor.hidden = true;

            imageEditor.style.setProperty(
                "display",
                "none",
                "important"
            );

        }


        hideOCRProgress();


        if (ocrReview) {

            ocrReview.hidden = true;

            ocrReview.style.setProperty(
                "display",
                "none",
                "important"
            );

        }


        if (sourceImage) {

            sourceImage.removeAttribute("src");

        }


        if (galleryInput) {

            galleryInput.value = "";

        }


        if (recognizedList) {

            recognizedList.innerHTML = "";

        }


        recognizedNames = [];

        currentImageFile = null;

        workingCanvas = null;

        rotation = 0;

        zoom = 1;

        imageX = 0;

        imageY = 0;

        pinchStartDistance = 0;

        pinchStartZoom = 1;

        imagePointers.clear();


        if (ocrProgressBar) {

            ocrProgressBar.style.width =
                "0%";

        }


        if (ocrPercent) {

            ocrPercent.textContent =
                "0%";

        }


        setOCRStatus("");

    }


    /* =========================================================
       IMAGE STATE
    ========================================================= */

    let currentImageFile = null;

    let workingCanvas = null;

    let rotation = 0;

    let zoom = 1;

    let imageX = 0;

    let imageY = 0;


    /* =========================================================
       LOAD IMAGE
    ========================================================= */

    on(
        galleryInput,
        "change",
        event => {

            const file =
                event.target.files &&
                event.target.files[0];


            if (!file) return;


            handleImageFile(file);

        }
    );


    function handleImageFile(file) {

        if (!file) return;


        if (
            !file.type ||
            !file.type.startsWith("image/")
        ) {

            alert(
                "الملف المحدد ليس صورة."
            );

            return;

        }


        currentImageFile =
            file;


        const reader =
            new FileReader();


        reader.onload =
            event => {

                const image =
                    new Image();


                image.onload =
                    () => {

                        try {

                            workingCanvas =
                                document.createElement(
                                    "canvas"
                                );


                            workingCanvas.width =
                                image.naturalWidth;


                            workingCanvas.height =
                                image.naturalHeight;


                            const ctx =
                                workingCanvas.getContext(
                                    "2d"
                                );


                            if (
                                !ctx ||
                                !workingCanvas.width ||
                                !workingCanvas.height
                            ) {

                                throw new Error(
                                    "أبعاد الصورة غير صالحة."
                                );

                            }


                            ctx.drawImage(
                                image,
                                0,
                                0
                            );


                            rotation = 0;

                            resetImageTransform();


                            if (sourceImage) {

                                sourceImage.onload =
                                    () => {

                                        showImportModal();


                                        if (imageEditor) {

                                            imageEditor.hidden =
                                                false;

                                            imageEditor.style.setProperty(
                                                "display",
                                                "block",
                                                "important"
                                            );

                                        }


                                        hideOCRProgress();


                                        if (ocrReview) {

                                            ocrReview.hidden =
                                                true;

                                            ocrReview.style.setProperty(
                                                "display",
                                                "none",
                                                "important"
                                            );

                                        }


                                        setOCRStatus("");


                                        requestAnimationFrame(
                                            () => {

                                                initializeCropFrame();

                                                centerImage();

                                                updateImageTransform();

                                            }
                                        );

                                    };


                                sourceImage.src =
                                    workingCanvas.toDataURL(
                                        "image/jpeg",
                                        0.98
                                    );

                            } else {

                                showImportModal();

                                if (imageEditor) {

                                    imageEditor.hidden =
                                        false;

                                }

                            }

                        } catch (error) {

                            console.error(
                                "IMAGE LOAD ERROR:",
                                error
                            );

                            alert(
                                "تعذر تجهيز الصورة للتحرير."
                            );

                        }

                    };


                image.onerror =
                    () => {

                        alert(
                            "تعذر فتح الصورة. حاول اختيار صورة أخرى."
                        );

                    };


                image.src =
                    event.target.result;

            };


        reader.onerror =
            () => {

                alert(
                    "تعذر قراءة ملف الصورة."
                );

            };


        reader.readAsDataURL(file);

    }


    /* =========================================================
       IMAGE TRANSFORM
    ========================================================= */

    function resetImageTransform() {

        zoom = 1;

        imageX = 0;

        imageY = 0;

        updateZoomLabel();

    }


    function centerImage() {

        imageX = 0;

        imageY = 0;

    }


    function updateZoomLabel() {

        if (!zoomValue) return;

        zoomValue.textContent =
            `${Math.round(zoom * 100)}%`;

    }


    function updateImageTransform() {

        if (!sourceImage) return;


        sourceImage.style.transform =
            `translate(-50%, -50%) ` +
            `translate(${imageX}px, ${imageY}px) ` +
            `scale(${zoom})`;


        updateZoomLabel();

    }


    function changeZoom(amount) {

        zoom =
            Math.max(
                0.35,
                Math.min(
                    5,
                    zoom + amount
                )
            );


        updateImageTransform();

    }


    on(
        zoomInButton,
        "click",
        () => changeZoom(0.25)
    );


    on(
        zoomOutButton,
        "click",
        () => changeZoom(-0.25)
    );


    on(
        resetImageButton,
        "click",
        () => {

            resetImageTransform();

            centerImage();

            updateImageTransform();

        }
    );


    /* =========================================================
       FREE CROP
       كل زاوية مستقلة
       لا نسبة أبعاد
    ========================================================= */

    function forceFreeCropCSS() {

        if (!cropFrame) return;


        cropFrame.style.setProperty(
            "aspect-ratio",
            "auto",
            "important"
        );


        cropFrame.style.setProperty(
            "min-width",
            "35px",
            "important"
        );


        cropFrame.style.setProperty(
            "min-height",
            "35px",
            "important"
        );


        cropFrame.style.setProperty(
            "max-width",
            "none",
            "important"
        );


        cropFrame.style.setProperty(
            "max-height",
            "none",
            "important"
        );


        cropFrame.style.setProperty(
            "box-sizing",
            "border-box",
            "important"
        );


        cropFrame.style.setProperty(
            "right",
            "auto",
            "important"
        );


        cropFrame.style.setProperty(
            "bottom",
            "auto",
            "important"
        );


        const handles =
            cropFrame.querySelectorAll(
                ".crop-handle"
            );


        handles.forEach(handle => {

            handle.style.setProperty(
                "position",
                "absolute",
                "important"
            );

            handle.style.setProperty(
                "pointer-events",
                "auto",
                "important"
            );

            handle.style.setProperty(
                "touch-action",
                "none",
                "important"
            );

            handle.style.setProperty(
                "user-select",
                "none",
                "important"
            );

            handle.style.setProperty(
                "-webkit-user-select",
                "none",
                "important"
            );

        });


        const topLeft =
            cropFrame.querySelector(
                ".crop-handle.top-left"
            );

        const topRight =
            cropFrame.querySelector(
                ".crop-handle.top-right"
            );

        const bottomLeft =
            cropFrame.querySelector(
                ".crop-handle.bottom-left"
            );

        const bottomRight =
            cropFrame.querySelector(
                ".crop-handle.bottom-right"
            );


        if (topLeft) {

            topLeft.style.setProperty(
                "top",
                "-11px",
                "important"
            );

            topLeft.style.setProperty(
                "left",
                "-11px",
                "important"
            );

            topLeft.style.setProperty(
                "right",
                "auto",
                "important"
            );

            topLeft.style.setProperty(
                "bottom",
                "auto",
                "important"
            );

            topLeft.style.setProperty(
                "cursor",
                "nwse-resize",
                "important"
            );

        }


        if (topRight) {

            topRight.style.setProperty(
                "top",
                "-11px",
                "important"
            );

            topRight.style.setProperty(
                "right",
                "-11px",
                "important"
            );

            topRight.style.setProperty(
                "left",
                "auto",
                "important"
            );

            topRight.style.setProperty(
                "bottom",
                "auto",
                "important"
            );

            topRight.style.setProperty(
                "cursor",
                "nesw-resize",
                "important"
            );

        }


        if (bottomLeft) {

            bottomLeft.style.setProperty(
                "bottom",
                "-11px",
                "important"
            );

            bottomLeft.style.setProperty(
                "left",
                "-11px",
                "important"
            );

            bottomLeft.style.setProperty(
                "top",
                "auto",
                "important"
            );

            bottomLeft.style.setProperty(
                "right",
                "auto",
                "important"
            );

            bottomLeft.style.setProperty(
                "cursor",
                "nesw-resize",
                "important"
            );

        }


        if (bottomRight) {

            bottomRight.style.setProperty(
                "bottom",
                "-11px",
                "important"
            );

            bottomRight.style.setProperty(
                "right",
                "-11px",
                "important"
            );

            bottomRight.style.setProperty(
                "top",
                "auto",
                "important"
            );

            bottomRight.style.setProperty(
                "left",
                "auto",
                "important"
            );

            bottomRight.style.setProperty(
                "cursor",
                "nwse-resize",
                "important"
            );

        }

    }


    function initializeCropFrame() {

        if (
            !cropContainer ||
            !cropFrame
        ) {
            return;
        }


        forceFreeCropCSS();


        const rect =
            cropContainer.getBoundingClientRect();


        if (
            rect.width <= 0 ||
            rect.height <= 0
        ) {
            return;
        }


        const width =
            Math.min(
                rect.width - 30,
                Math.max(
                    150,
                    rect.width * 0.86
                )
            );


        const height =
            Math.min(
                rect.height - 30,
                Math.max(
                    100,
                    rect.height * 0.68
                )
            );


        const left =
            Math.max(
                15,
                (rect.width - width) / 2
            );


        const top =
            Math.max(
                15,
                (rect.height - height) / 2
            );


        cropFrame.style.setProperty(
            "left",
            `${left}px`,
            "important"
        );


        cropFrame.style.setProperty(
            "top",
            `${top}px`,
            "important"
        );


        cropFrame.style.setProperty(
            "width",
            `${width}px`,
            "important"
        );


        cropFrame.style.setProperty(
            "height",
            `${height}px`,
            "important"
        );


        cropFrame.style.setProperty(
            "aspect-ratio",
            "auto",
            "important"
        );


        forceFreeCropCSS();

    }


    /* =========================================================
       ROTATE
    ========================================================= */

    on(
        rotateImageButton,
        "click",
        rotateWorkingImage
    );


    function rotateWorkingImage() {

        if (!workingCanvas) return;


        const oldCanvas =
            workingCanvas;


        const canvas =
            document.createElement("canvas");


        canvas.width =
            oldCanvas.height;


        canvas.height =
            oldCanvas.width;


        const ctx =
            canvas.getContext("2d");


        if (!ctx) return;


        ctx.translate(
            canvas.width / 2,
            canvas.height / 2
        );


        ctx.rotate(
            Math.PI / 2
        );


        ctx.drawImage(
            oldCanvas,
            -oldCanvas.width / 2,
            -oldCanvas.height / 2
        );


        workingCanvas =
            canvas;


        rotation =
            (rotation + 90) % 360;


        resetImageTransform();


        if (sourceImage) {

            sourceImage.onload =
                () => {

                    requestAnimationFrame(() => {

                        centerImage();

                        updateImageTransform();

                        initializeCropFrame();

                    });

                };


            sourceImage.src =
                workingCanvas.toDataURL(
                    "image/jpeg",
                    0.98
                );

        }

    }


    /* =========================================================
       IMAGE MOVE
       إصبع واحد
    ========================================================= */

    const imagePointers =
        new Map();


    function startImagePointer(event) {

        if (
            !cropContainer ||
            !sourceImage
        ) {
            return;
        }


        if (
            event.target.closest(
                "#cropFrame, .crop-handle"
            )
        ) {
            return;
        }


        imagePointers.set(
            event.pointerId,
            {
                x: event.clientX,
                y: event.clientY,
                originalX: imageX,
                originalY: imageY
            }
        );


        try {

            cropContainer.setPointerCapture(
                event.pointerId
            );

        } catch (_) {}

    }


    function moveImagePointer(event) {

        if (
            !imagePointers.has(
                event.pointerId
            )
        ) {
            return;
        }


        if (imagePointers.size >= 2) {
            return;
        }


        const pointer =
            imagePointers.get(
                event.pointerId
            );


        if (!pointer) return;


        imageX =
            pointer.originalX +
            (
                event.clientX -
                pointer.x
            );


        imageY =
            pointer.originalY +
            (
                event.clientY -
                pointer.y
            );


        updateImageTransform();

    }


    function stopImagePointer(event) {

        imagePointers.delete(
            event.pointerId
        );


        try {

            cropContainer.releasePointerCapture(
                event.pointerId
            );

        } catch (_) {}

    }


    on(
        cropContainer,
        "pointerdown",
        startImagePointer
    );


    on(
        cropContainer,
        "pointermove",
        moveImagePointer
    );


    on(
        cropContainer,
        "pointerup",
        stopImagePointer
    );


    on(
        cropContainer,
        "pointercancel",
        stopImagePointer
    );


    if (cropContainer) {

        cropContainer.style.setProperty(
            "touch-action",
            "none",
            "important"
        );

        cropContainer.style.setProperty(
            "user-select",
            "none",
            "important"
        );

        cropContainer.style.setProperty(
            "-webkit-user-select",
            "none",
            "important"
        );

    }


    /* =========================================================
       TWO FINGER ZOOM
    ========================================================= */

    let pinchStartDistance = 0;

    let pinchStartZoom = 1;


    function getTouchDistance(a, b) {

        return Math.hypot(
            a.clientX - b.clientX,
            a.clientY - b.clientY
        );

    }


    on(
        cropContainer,
        "touchstart",
        event => {

            if (event.touches.length !== 2) {
                return;
            }


            const a =
                event.touches[0];

            const b =
                event.touches[1];


            pinchStartDistance =
                getTouchDistance(a, b);


            pinchStartZoom =
                zoom;

        },
        {
            passive: false
        }
    );


    on(
        cropContainer,
        "touchmove",
        event => {

            if (event.touches.length !== 2) {
                return;
            }


            event.preventDefault();


            const a =
                event.touches[0];

            const b =
                event.touches[1];


            const distance =
                getTouchDistance(a, b);


            if (pinchStartDistance <= 0) {
                return;
            }


            zoom =
                Math.max(
                    0.35,
                    Math.min(
                        5,
                        pinchStartZoom *
                        (
                            distance /
                            pinchStartDistance
                        )
                    )
                );


            updateImageTransform();

        },
        {
            passive: false
        }
    );


    on(
        cropContainer,
        "touchend",
        event => {

            if (event.touches.length < 2) {

                pinchStartDistance =
                    0;

            }

        },
        {
            passive: true
        }
    );


    /* =========================================================
       CROP FRAME CONTROL
       حر بالكامل
    ========================================================= */

    let cropState = {

        mode: null,

        pointerId: null,

        startX: 0,

        startY: 0,

        left: 0,

        top: 0,

        width: 0,

        height: 0

    };


    function getCropHandleMode(handle) {

        if (!handle) {
            return "move";
        }


        if (
            handle.dataset &&
            handle.dataset.handle
        ) {

            return handle.dataset.handle;

        }


        if (
            handle.classList.contains(
                "top-left"
            )
        ) {

            return "top-left";

        }


        if (
            handle.classList.contains(
                "top-right"
            )
        ) {

            return "top-right";

        }


        if (
            handle.classList.contains(
                "bottom-left"
            )
        ) {

            return "bottom-left";

        }


        if (
            handle.classList.contains(
                "bottom-right"
            )
        ) {

            return "bottom-right";

        }


        return "move";

    }


    on(
        cropFrame,
        "pointerdown",
        event => {

            event.preventDefault();

            event.stopPropagation();


            const handle =
                event.target.closest(
                    ".crop-handle"
                );


            if (
                !cropContainer ||
                !cropFrame
            ) {
                return;
            }


            const containerRect =
                cropContainer.getBoundingClientRect();


            const frameRect =
                cropFrame.getBoundingClientRect();


            cropState.pointerId =
                event.pointerId;


            cropState.startX =
                event.clientX;


            cropState.startY =
                event.clientY;


            cropState.left =
                frameRect.left -
                containerRect.left;


            cropState.top =
                frameRect.top -
                containerRect.top;


            cropState.width =
                frameRect.width;


            cropState.height =
                frameRect.height;


            cropState.mode =
                getCropHandleMode(
                    handle
                );


            try {

                cropFrame.setPointerCapture(
                    event.pointerId
                );

            } catch (_) {}

        }
    );


    on(
        cropFrame,
        "pointermove",
        event => {

            if (
                cropState.pointerId !==
                event.pointerId
            ) {
                return;
            }


            event.preventDefault();


            const containerRect =
                cropContainer.getBoundingClientRect();


            const dx =
                event.clientX -
                cropState.startX;


            const dy =
                event.clientY -
                cropState.startY;


            const minSize =
                35;


            let left =
                cropState.left;

            let top =
                cropState.top;

            let width =
                cropState.width;

            let height =
                cropState.height;


            if (
                cropState.mode ===
                "move"
            ) {

                left =
                    cropState.left +
                    dx;

                top =
                    cropState.top +
                    dy;

            }


            else if (
                cropState.mode ===
                "top-left"
            ) {

                left =
                    cropState.left +
                    dx;

                top =
                    cropState.top +
                    dy;

                width =
                    cropState.width -
                    dx;

                height =
                    cropState.height -
                    dy;

            }


            else if (
                cropState.mode ===
                "top-right"
            ) {

                top =
                    cropState.top +
                    dy;

                width =
                    cropState.width +
                    dx;

                height =
                    cropState.height -
                    dy;

            }


            else if (
                cropState.mode ===
                "bottom-left"
            ) {

                left =
                    cropState.left +
                    dx;

                width =
                    cropState.width -
                    dx;

                height =
                    cropState.height +
                    dy;

            }


            else if (
                cropState.mode ===
                "bottom-right"
            ) {

                width =
                    cropState.width +
                    dx;

                height =
                    cropState.height +
                    dy;

            }


            if (
                cropState.mode !==
                "move"
            ) {

                if (width < minSize) {

                    if (
                        cropState.mode.includes(
                            "left"
                        )
                    ) {

                        left =
                            cropState.left +
                            cropState.width -
                            minSize;

                    }

                    width =
                        minSize;

                }


                if (height < minSize) {

                    if (
                        cropState.mode.includes(
                            "top"
                        )
                    ) {

                        top =
                            cropState.top +
                            cropState.height -
                            minSize;

                    }

                    height =
                        minSize;

                }

            }


            const maxWidth =
                containerRect.width;

            const maxHeight =
                containerRect.height;


            if (
                cropState.mode ===
                "move"
            ) {

                left =
                    Math.max(
                        0,
                        Math.min(
                            Math.max(
                                0,
                                maxWidth -
                                width
                            ),
                            left
                        )
                    );


                top =
                    Math.max(
                        0,
                        Math.min(
                            Math.max(
                                0,
                                maxHeight -
                                height
                            ),
                            top
                        )
                    );

            }


            else {

                if (left < 0) {

                    width += left;

                    left = 0;

                }


                if (top < 0) {

                    height += top;

                    top = 0;

                }


                if (
                    left + width >
                    maxWidth
                ) {

                    width =
                        maxWidth -
                        left;

                }


                if (
                    top + height >
                    maxHeight
                ) {

                    height =
                        maxHeight -
                        top;

                }


                width =
                    Math.max(
                        minSize,
                        width
                    );


                height =
                    Math.max(
                        minSize,
                        height
                    );


                if (
                    left + width >
                    maxWidth
                ) {

                    width =
                        Math.max(
                            minSize,
                            maxWidth -
                            left
                        );

                }


                if (
                    top + height >
                    maxHeight
                ) {

                    height =
                        Math.max(
                            minSize,
                            maxHeight -
                            top
                        );

                }

            }


            cropFrame.style.setProperty(
                "left",
                `${left}px`,
                "important"
            );


            cropFrame.style.setProperty(
                "right",
                "auto",
                "important"
            );


            cropFrame.style.setProperty(
                "top",
                `${top}px`,
                "important"
            );


            cropFrame.style.setProperty(
                "bottom",
                "auto",
                "important"
            );


            cropFrame.style.setProperty(
                "width",
                `${width}px`,
                "important"
            );


            cropFrame.style.setProperty(
                "height",
                `${height}px`,
                "important"
            );


            cropFrame.style.setProperty(
                "aspect-ratio",
                "auto",
                "important"
            );

        }
    );


    on(
        cropFrame,
        "pointerup",
        event => {

            cropState.pointerId =
                null;


            cropState.mode =
                null;


            try {

                cropFrame.releasePointerCapture(
                    event.pointerId
                );

            } catch (_) {}

        }
    );


    on(
        cropFrame,
        "pointercancel",
        event => {

            cropState.pointerId =
                null;


            cropState.mode =
                null;


            try {

                cropFrame.releasePointerCapture(
                    event.pointerId
                );

            } catch (_) {}

        }
    );


    /* =========================================================
       GET CROPPED IMAGE
    ========================================================= */

    async function getCroppedImage() {

        if (!workingCanvas) {

            throw new Error(
                "لا توجد صورة جاهزة للتحليل."
            );

        }


        if (
            !workingCanvas.width ||
            !workingCanvas.height
        ) {

            throw new Error(
                "أبعاد الصورة الأصلية غير صالحة."
            );

        }


        if (
            !sourceImage ||
            !sourceImage.complete ||
            !sourceImage.naturalWidth
        ) {

            throw new Error(
                "الصورة لم تكتمل جاهزيتها بعد."
            );

        }


        if (
            !cropContainer ||
            !cropFrame
        ) {

            throw new Error(
                "تعذر العثور على إطار القص."
            );

        }


        const frameRect =
            cropFrame.getBoundingClientRect();


        const imageRect =
            sourceImage.getBoundingClientRect();


        if (
            imageRect.width <= 0 ||
            imageRect.height <= 0
        ) {

            throw new Error(
                "الصورة غير ظاهرة حاليًا."
            );

        }


        const left =
            Math.max(
                frameRect.left,
                imageRect.left
            );


        const top =
            Math.max(
                frameRect.top,
                imageRect.top
            );


        const right =
            Math.min(
                frameRect.right,
                imageRect.right
            );


        const bottom =
            Math.min(
                frameRect.bottom,
                imageRect.bottom
            );


        const visibleWidth =
            right - left;


        const visibleHeight =
            bottom - top;


        if (
            visibleWidth <= 1 ||
            visibleHeight <= 1
        ) {

            throw new Error(
                "إطار القص لا يتقاطع مع الصورة. حرّك الصورة داخل الإطار ثم حاول مرة أخرى."
            );

        }


        let sx =
            (
                left -
                imageRect.left
            ) *
            (
                workingCanvas.width /
                imageRect.width
            );


        let sy =
            (
                top -
                imageRect.top
            ) *
            (
                workingCanvas.height /
                imageRect.height
            );


        let sw =
            visibleWidth *
            (
                workingCanvas.width /
                imageRect.width
            );


        let sh =
            visibleHeight *
            (
                workingCanvas.height /
                imageRect.height
            );


        sx =
            Math.max(
                0,
                Math.min(
                    workingCanvas.width - 1,
                    sx
                )
            );


        sy =
            Math.max(
                0,
                Math.min(
                    workingCanvas.height - 1,
                    sy
                )
            );


        sw =
            Math.max(
                1,
                Math.min(
                    workingCanvas.width - sx,
                    sw
                )
            );


        sh =
            Math.max(
                1,
                Math.min(
                    workingCanvas.height - sy,
                    sh
                )
            );


        const maxDimension =
            3000;


        const scale =
            Math.min(
                2,
                maxDimension /
                Math.max(sw, sh)
            );


        const outputWidth =
            Math.max(
                1,
                Math.round(sw * scale)
            );


        const outputHeight =
            Math.max(
                1,
                Math.round(sh * scale)
            );


        const canvas =
            document.createElement("canvas");


        canvas.width =
            outputWidth;

        canvas.height =
            outputHeight;


        const ctx =
            canvas.getContext(
                "2d",
                {
                    willReadFrequently: true
                }
            );


        if (!ctx) {

            throw new Error(
                "تعذر إنشاء الصورة المقصوصة."
            );

        }


        ctx.imageSmoothingEnabled =
            true;

        ctx.imageSmoothingQuality =
            "high";


        ctx.drawImage(
            workingCanvas,
            sx,
            sy,
            sw,
            sh,
            0,
            0,
            outputWidth,
            outputHeight
        );


        const imageData =
            ctx.getImageData(
                0,
                0,
                outputWidth,
                outputHeight
            );


        const data =
            imageData.data;


        const contrast =
            1.18;


        for (
            let i = 0;
            i < data.length;
            i += 4
        ) {

            const gray =
                (
                    data[i] * 0.299
                ) +
                (
                    data[i + 1] * 0.587
                ) +
                (
                    data[i + 2] * 0.114
                );


            const adjusted =
                (
                    gray - 128
                ) *
                contrast +
                128;


            const value =
                Math.max(
                    0,
                    Math.min(
                        255,
                        adjusted
                    )
                );


            data[i] =
                value;

            data[i + 1] =
                value;

            data[i + 2] =
                value;

            data[i + 3] =
                255;

        }


        ctx.putImageData(
            imageData,
            0,
            0
        );


        return new Promise(
            (resolve, reject) => {

                canvas.toBlob(
                    blob => {

                        if (
                            !blob ||
                            blob.size < 100
                        ) {

                            reject(
                                new Error(
                                    "تعذر إنشاء الصورة المقصوصة."
                                )
                            );

                            return;

                        }


                        resolve(blob);

                    },
                    "image/png"
                );

            }
        );

    }


    /* =========================================================
       OCR
    ========================================================= */

    on(
        analyzeImageButton,
        "click",
        analyzeImage
    );


    function blobToDataUrl(blob) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
        });
    }

    async function analyzeImage() {

        if (!workingCanvas) {

            alert(
                "اختر صورة أولًا."
            );

            return;

        }


        let croppedBlob =
            null;

        let worker =
            null;


        try {

            showOCRProgress();


            if (ocrProgressBar) {

                ocrProgressBar.style.width =
                    "0%";

            }


            if (ocrPercent) {

                ocrPercent.textContent =
                    "0%";

            }


            setOCRStatus(
                "تجهيز الصورة للتحليل..."
            );


            if (imageEditor) {

                imageEditor.hidden =
                    false;

            }


            croppedBlob =
                await getCroppedImage();


            if (
                !croppedBlob ||
                croppedBlob.size < 100
            ) {

                throw new Error(
                    "الصورة المقصوصة غير صالحة."
                );

            }


            setOCRStatus(
                "تحميل محرك قراءة النص..."
            );


            /*
               في نسخة ToApp لا نعتمد على محرك OCR أصلي داخل التطبيق.
               تحليل الأسماء يحتاج اتصالًا بالإنترنت فقط.
            */
            if (!navigator.onLine) {
                throw new Error(
                    "OFFLINE_OCR"
                );
            }

            setOCRStatus(
                "الاتصال متاح — تجهيز محرك قراءة الأسماء..."
            );

            async function loadOnlineTesseract() {

                if (typeof Tesseract !== "undefined") {
                    return;
                }

                await new Promise((resolve, reject) => {

                    const existing = document.querySelector(
                        'script[data-mueen-tesseract="online"]'
                    );

                    if (existing) {
                        existing.addEventListener("load", resolve, { once: true });
                        existing.addEventListener("error", reject, { once: true });
                        return;
                    }

                    const script = document.createElement("script");
                    script.src = "https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js";
                    script.async = true;
                    script.dataset.mueenTesseract = "online";
                    script.onload = resolve;
                    script.onerror = () => reject(new Error("OCR_SCRIPT_LOAD_FAILED"));
                    document.head.appendChild(script);
                });

                if (typeof Tesseract === "undefined") {
                    throw new Error("OCR_SCRIPT_LOAD_FAILED");
                }
            }

            await loadOnlineTesseract();

            setOCRStatus(
                "جاري تحميل محرك القراءة واللغة العربية..."
            );

            const workerOptions = {
                logger: message => {

                            if (!message) {
                                return;
                            }


                            if (
                                message.status ===
                                "loading tesseract core"
                            ) {

                                setOCRStatus(
                                    "تحميل محرك القراءة..."
                                );

                            }


                            else if (
                                message.status ===
                                "loading language traineddata"
                            ) {

                                setOCRStatus(
                                    "تحميل اللغة العربية..."
                                );

                            }


                            else if (
                                message.status ===
                                "initializing api"
                            ) {

                                setOCRStatus(
                                    "تهيئة القراءة..."
                                );

                            }


                            else if (
                                message.status ===
                                "recognizing text"
                            ) {

                                const progress =
                                    Math.round(
                                        (
                                            message.progress ||
                                            0
                                        ) * 100
                                    );


                                if (ocrPercent) {

                                    ocrPercent.textContent =
                                        `${progress}%`;

                                }


                                if (ocrProgressBar) {

                                    ocrProgressBar.style.width =
                                        `${progress}%`;

                                }


                                setOCRStatus(
                                    "جاري قراءة الأسماء..."
                                );

                            }

                        }
            };

            workerOptions.workerPath =
                "https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/worker.min.js";
            workerOptions.corePath =
                "https://cdn.jsdelivr.net/npm/tesseract.js-core@5/tesseract-core.wasm.js";
            workerOptions.langPath =
                "https://tessdata.projectnaptha.com/4.0.0";

            worker =
                await Tesseract.createWorker(
                    "ara",
                    1,
                    workerOptions
                );


            try {

                await worker.setParameters({

                    preserve_interword_spaces:
                        "1",

                    tessedit_pageseg_mode:
                        "6"

                });

            } catch (parameterError) {

                console.warn(
                    "تعذر تطبيق بعض إعدادات OCR:",
                    parameterError
                );

            }


            setOCRStatus(
                "جاري قراءة الأسماء..."
            );


            const result =
                await worker.recognize(
                    croppedBlob
                );


            const text =
                result &&
                result.data &&
                result.data.text
                    ? result.data.text
                    : "";


            const names =
                extractNames(text);


            try {

                await worker.terminate();

            } catch (_) {}


            worker =
                null;


            hideOCRProgress();


            if (!names.length) {

                if (imageEditor) {

                    imageEditor.hidden =
                        false;

                }


                alert(
                    "لم يتم التعرف على أسماء واضحة.\n\n" +
                    "حاول قص مجموعة أصغر من الطلاب، " +
                    "وتأكد من أن الأسماء واضحة وكاملة داخل الإطار."
                );


                return;

            }


            renderRecognitionReview(
                names
            );

        } catch (error) {

            if (error && error.message === "OFFLINE_OCR") {
                setOCRStatus(
                    "تحليل الأسماء يحتاج اتصالًا بالإنترنت."
                );
                alert(
                    "تحليل أسماء الطلاب من الصورة يحتاج اتصالًا بالإنترنت.\n\nاتصل بالإنترنت ثم حاول مرة أخرى. بقية وظائف مُعين تعمل دون اتصال."
                );
                hideOCRProgress();
                return;
            }

            if (error && (
                error.message === "OCR_SCRIPT_LOAD_FAILED" ||
                String(error.message || "").includes("NetworkError")
            )) {
                setOCRStatus(
                    "تعذر الاتصال بخدمة تحليل الأسماء."
                );
                alert(
                    "تعذر الاتصال بخدمة تحليل الأسماء حاليًا.\n\nتحقق من اتصال الإنترنت ثم حاول مرة أخرى."
                );
                hideOCRProgress();
                return;
            }

            console.error(
                "OCR ERROR:",
                error
            );


            if (worker) {

                try {

                    await worker.terminate();

                } catch (_) {}

            }


            worker =
                null;


            hideOCRProgress();


            if (imageEditor) {

                imageEditor.hidden =
                    false;

            }


            alert(
                error &&
                error.message
                    ? error.message
                    : "حدث خطأ أثناء قراءة الأسماء."
            );

        }

    }


    /* =========================================================
       EXTRACT NAMES
    ========================================================= */

    function extractNames(text) {

        if (!text) return [];


        const lines =
            String(text)
                .split(/\r?\n/)
                .map(line =>
                    line
                        .replace(/\t/g, " ")
                        .trim()
                )
                .filter(Boolean);


        const names = [];

        const seen =
            new Set();


        const ignored = [

            "اسم الطالب",
            "اسماء الطلاب",
            "أسماء الطلاب",
            "الطلاب",
            "الاسم",
            "الاسماء",
            "الأسماء",
            "الرقم",
            "رقم",
            "قائمة الطلاب",
            "الفصل",
            "الصف",
            "المرحلة",
            "المدرسة",
            "العام الدراسي",
            "العام",
            "الادارة",
            "الإدارة",
            "مواد الدور الثاني",
            "بداية البرنامج العلاجي"

        ];


        for (let line of lines) {

            line =
                line.replace(
                    /^\s*[\d٠-٩]+[\s.)\-:ـ]+/,
                    ""
                );


            line =
                line.replace(
                    /^[|•●▪▫\-–—*]+/,
                    ""
                );


            line =
                line.replace(
                    /^\s*[\d٠-٩]+\s*/,
                    ""
                );


            line =
                line
                    .replace(/\s+/g, " ")
                    .trim();


            if (!line) continue;


            const normalized =
                normalizeArabic(line);


            if (!normalized) continue;


            if (
                ignored.some(
                    word =>
                        normalized ===
                        normalizeArabic(word)
                )
            ) {
                continue;
            }


            if (
                normalized.includes("مدرسه") &&
                normalized.length < 35
            ) {
                continue;
            }


            if (
                normalized.includes("الفصل") &&
                normalized.length < 30
            ) {
                continue;
            }


            if (
                normalized.includes("الصف") &&
                normalized.length < 30
            ) {
                continue;
            }


            line =
                line
                    .replace(
                        /[|_~`]+/g,
                        " "
                    )
                    .replace(
                        /\s+/g,
                        " "
                    )
                    .trim();


            if (line.length < 3) {
                continue;
            }


            const lettersOnly =
                line.replace(
                    /[\d٠-٩\s.,:;()[\]{}\-_/\\|]+/g,
                    ""
                );


            if (lettersOnly.length < 3) {
                continue;
            }


            const key =
                normalizeArabic(line);


            if (seen.has(key)) {
                continue;
            }


            seen.add(key);

            names.push(line);

        }


        return names;

    }


    /* =========================================================
       OCR REVIEW
    ========================================================= */

    let recognizedNames = [];


    function renderRecognitionReview(names) {

        const uniqueNames = [];

        const seen = new Set();


        names.forEach(name => {

            const cleaned =
                String(name || "")
                    .replace(/\s+/g, " ")
                    .trim();


            if (!cleaned) return;


            const key =
                normalizeArabic(cleaned);


            if (!key) return;


            if (seen.has(key)) return;


            seen.add(key);

            uniqueNames.push(cleaned);

        });


        recognizedNames =
            uniqueNames;


        if (!recognizedList) return;


        recognizedList.innerHTML =
            "";


        recognizedNames.forEach(
            (name, index) => {

                createRecognizedItem(
                    name,
                    index
                );

            }
        );


        if (recognizedCount) {

            recognizedCount.textContent =
                `${recognizedNames.length} اسم`;

        }


        if (ocrReview) {

            ocrReview.hidden =
                false;

            ocrReview.style.setProperty(
                "display",
                "block",
                "important"
            );

        }


        if (imageEditor) {

            imageEditor.hidden =
                true;

            imageEditor.style.setProperty(
                "display",
                "none",
                "important"
            );

        }

    }


    function createRecognizedItem(
        name,
        index
    ) {

        const item =
            document.createElement(
                "div"
            );


        item.className =
            "recognized-item";


        item.dataset.index =
            index;


        item.innerHTML = `

            <span class="recognized-number">
                ${index + 1}
            </span>

            <input
                type="text"
                value="${escapeHTML(name)}"
                data-index="${index}"
                aria-label="اسم الطالب"
            >

            <button
                type="button"
                class="remove-recognized"
                data-index="${index}"
                aria-label="حذف الاسم"
            >
                ×
            </button>

        `;


        recognizedList.appendChild(
            item
        );

    }


    on(
        recognizedList,
        "input",
        event => {

            if (
                event.target.matches(
                    "input[data-index]"
                )
            ) {

                const index =
                    Number(
                        event.target.dataset.index
                    );


                recognizedNames[index] =
                    event.target.value;

            }

        }
    );


    on(
        recognizedList,
        "click",
        event => {

            const button =
                event.target.closest(
                    ".remove-recognized"
                );


            if (!button) return;


            const index =
                Number(
                    button.dataset.index
                );


            recognizedNames.splice(
                index,
                1
            );


            renderRecognitionReview(
                recognizedNames
            );

        }
    );


    /* =========================================================
       CANCEL OCR REVIEW
    ========================================================= */

    on(
        cancelRecognitionButton,
        "click",
        () => {

            if (ocrReview) {

                ocrReview.hidden =
                    true;

                ocrReview.style.setProperty(
                    "display",
                    "none",
                    "important"
                );

            }


            if (imageEditor) {

                imageEditor.hidden =
                    false;

                imageEditor.style.setProperty(
                    "display",
                    "block",
                    "important"
                );

            }

            hideOCRProgress();

        }
    );


    /* =========================================================
       SAVE OCR NAMES
       نافذة تحميل مستقلة
       منع التكرار بشكل نهائي
    ========================================================= */

    on(
        saveRecognizedButton,
        "click",
        saveRecognizedStudents
    );


    async function saveRecognizedStudents() {

        const cleanedNames =
            recognizedNames

                .map(name =>
                    String(name || "")
                        .replace(/\s+/g, " ")
                        .trim()
                )

                .filter(
                    name =>
                        name.length >= 2
                );


        if (!cleanedNames.length) {

            alert(
                "لا توجد أسماء صالحة للحفظ."
            );

            return;

        }


        const uniqueNames = [];

        const seenInResult =
            new Set();


        cleanedNames.forEach(name => {

            const key =
                normalizeArabic(name);


            if (!key) return;


            if (seenInResult.has(key)) {
                return;
            }


            seenInResult.add(key);

            uniqueNames.push(name);

        });


        let added = 0;

        let skipped = 0;


        uniqueNames.forEach(name => {

            const key =
                normalizeArabic(name);


            const exists =
                students.some(
                    student =>
                        normalizeArabic(
                            student.name
                        ) === key
                );


            if (exists) {

                skipped++;

                return;

            }


            const alreadyAdded =
                students.some(
                    student =>
                        normalizeArabic(
                            student.name
                        ) === key
                );


            if (alreadyAdded) {

                skipped++;

                return;

            }


            students.push({

                id: createId(),

                name

            });


            added++;

        });


        if (added === 0) {

            let duplicateMessage =
                "لم تتم إضافة أي طالب جديد.";

            if (skipped) {

                duplicateMessage +=
                    ` تم تجاهل ${skipped} اسم مكرر.`;

            }

            alert(
                duplicateMessage
            );

            return;

        }


        showSaveLoading();


        await new Promise(resolve => {

            requestAnimationFrame(() => {

                setTimeout(
                    resolve,
                    320
                );

            });

        });


        let saveSuccessful =
            false;


        try {

            saveSuccessful =
                saveClass();


            if (saveSuccessful) {

                renderStudents();

            }


            if (ocrReview) {

                ocrReview.hidden =
                    true;

                ocrReview.style.setProperty(
                    "display",
                    "none",
                    "important"
                );

            }


            if (imageEditor) {

                imageEditor.hidden =
                    true;

                imageEditor.style.setProperty(
                    "display",
                    "none",
                    "important"
                );

            }


            hideOCRProgress();


            hideImportModal();


            recognizedNames = [];

            currentImageFile = null;

            workingCanvas = null;


            if (recognizedList) {

                recognizedList.innerHTML =
                    "";

            }


        } catch (error) {

            console.error(
                "SAVE STUDENTS ERROR:",
                error
            );


            alert(
                "تعذر حفظ الطلاب. حاول مرة أخرى."
            );


            return;

        } finally {

            hideSaveLoading();

        }


        if (!saveSuccessful) {

            alert(
                "تعذر حفظ الطلاب. حاول مرة أخرى."
            );

            return;

        }


        let message =
            `تمت إضافة ${added} طالب`;


        if (skipped) {

            message +=
                `، وتم تجاهل ${skipped} اسم مكرر`;

        }


        message += ".";


        alert(message);

    }


    /* =========================================================
       BACK
       الرجوع من صفحة الطالب إلى صفحة الطلاب فقط
    ========================================================= */

    function goBack() {

        /*
           هذه الصفحة فرعية من صفحة إدارة الطلاب.
           لذلك لا نستخدم history.back()
           حتى لا نرجع إلى خطوات قديمة مثل:
           grades → students → اختيار الصف.

           دائمًا:
           class-students → students
        */

        window.location.replace(
            "students.html"
        );

    }


    on(
        backButton,
        "click",
        goBack
    );


    /* =========================================================
       NAVIGATION
       الأزرار الرئيسية لا تضيف خطوات متراكمة
    ========================================================= */

    function goMain(page) {

        const currentPage =
            window.location.pathname
                .split("/")
                .pop()
                .toLowerCase();


        /*
           إذا كنا في الصفحة الرئيسية،
           نستخدم href طبيعيًا.
        */

        if (
            currentPage === "home.html" ||
            currentPage === ""
        ) {

            window.location.href =
                page;

            return;

        }


        /*
           من أي صفحة فرعية/رئيسية أخرى
           ننتقل بدون إضافة خطوة جديدة
           إلى سجل الرجوع.
        */

        window.location.replace(
            page
        );

    }


    on(
        homeNavigation,
        "click",
        () => {

            goMain(
                "home.html"
            );

        }
    );


    on(
        studentsNavigation,
        "click",
        () => {

            goMain(
                "students.html"
            );

        }
    );


    on(
        attendanceNavigation,
        "click",
        () => {

            goMain(
                `attendance.html?class=${encodeURIComponent(
                    currentClass.code ??
                    currentClass.id ??
                    classId
                )}`
            );

        }
    );


    on(
        scheduleNavigation,
        "click",
        () => {

            goMain(
                "schedule.html"
            );

        }
    );


    /* =========================================================
       GRADES / دفتري
    ========================================================= */

    on(
        gradesNavigation,
        "click",
        () => {

            goMain(
                "grades.html"
            );

        }
    );


    on(
        reportsNavigation,
        "click",
        () => {

            goMain(
                "reports.html"
            );

        }
    );


    /* =========================================================
       ESC
    ========================================================= */

    on(
        document,
        "keydown",
        event => {

            if (event.key !== "Escape") {
                return;
            }


            if (
                studentModal &&
                !studentModal.hidden
            ) {

                closeStudentModalWindow();

                return;

            }


            if (
                importModal &&
                !importModal.hidden
            ) {

                hideImportModal();

                resetImport();

            }

        }
    );


    /* =========================================================
       FINAL INIT
    ========================================================= */

    forceFreeCropCSS();

    hideImportChoices();

    hideOCRProgress();

    setOCRStatus("");


    if (ocrReview) {

        ocrReview.hidden =
            true;

        ocrReview.style.setProperty(
            "display",
            "none",
            "important"
        );

    }


    if (imageEditor) {

        imageEditor.hidden =
            true;

        imageEditor.style.setProperty(
            "display",
            "none",
            "important"
        );

    }


    renderClassHeader();

    renderStudents();


    requestAnimationFrame(() => {

        forceFreeCropCSS();

        if (
            imageEditor &&
            !imageEditor.hidden
        ) {

            initializeCropFrame();

        }

    });

});