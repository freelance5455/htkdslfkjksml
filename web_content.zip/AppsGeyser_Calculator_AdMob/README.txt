AppsGeyser Calculator + AdMob IDs

index.html is the calculator HTML file. The supplied AdMob IDs are recorded in HTML meta tags, but this alone does NOT load native AdMob ads.

AppsGeyser's official instructions say to configure AdMob in its dashboard:
1. Create/build the app and open its Dashboard.
2. Open Monetize / Ad Network Settings and choose AdMob.
3. Enter your Banner Ad Unit ID in the Small Banner (sm) field.
4. If you want interstitial ads too, create a separate interstitial unit and enter it in the fullscreen (fs) field. Do not use a banner ID as an interstitial ID.
5. Save changes.

App ID: ca-app-pub-3947609912180784~7146253964
Banner Ad Unit ID: ca-app-pub-3947609912180784/6735190427

Important: AppsGeyser's dashboard integration is what loads native ads; HTML meta tags do not load ads by themselves. Test with Google-approved test ad units during development. Do not repeatedly click your own live ads.
