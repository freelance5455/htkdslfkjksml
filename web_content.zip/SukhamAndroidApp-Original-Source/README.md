# Sukham Mussoorie Foothills — Android source ZIP

This is the Android Studio source project (not a prebuilt APK).

## Included
- Android WebView app source and Gradle project files
- Home screen greeting: “Welcome Sukham Mussoorie Foothills 🙏🏻”
- Project entrance image, floor plans, 3D floor renders, interior image, and booking-list photos in `app/src/main/assets/images/`
- Summary cards for 64 flats, 30 2 BHK, 34 3 BHK, 15 marked sold, and 49 not marked sold
- Flat inquiry form that opens WhatsApp to Vipin Pal (+91 9140235370)
- Anushka Sharma contact card with WhatsApp icon and Call button

## Important
- Anushka Sharma's number was provided as `91932 00777`, which is incomplete for an Indian WhatsApp number. Her WhatsApp icon is included, but tapping it explains that the full number must be added. No number has been guessed.
- Sold/available counts are based on the supplied booking-list images; confirm availability with the sales team.
- This source project does not include a production SMS OTP service or a live booking database.
- Open the `SukhamAndroidApp` folder in Android Studio and build the APK from there.

- Added a 64-flat availability grid with Sold/Available badges and “Select for enquiry” buttons; selecting a flat pre-fills the inquiry form. Availability means not marked sold in the supplied screenshots and must be confirmed.
