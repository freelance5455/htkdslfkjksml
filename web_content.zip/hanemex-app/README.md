# Hanemex – تطبيق الخامات والتسعير

## محتويات الحزمة
- `www/index.html`: التطبيق كامل (الرئيسية، الخامات، المصمم، 3D والواقعي، الأسعار).
- `www/manifest.webmanifest` و`www/sw.js` و`www/icons/`: تحويله لتطبيق PWA يعمل بدون إنترنت بعد أول فتح.
- `package.json` و`capacitor.config.json`: لتغليفه كتطبيق أندرويد (APK).

## تجربة محلية
```
npm run serve     # ثم افتح http://localhost:8080
```

## 1) تثبيته كتطبيق (PWA) – الأسهل
ارفع مجلد `www` على أي استضافة HTTPS (Netlify أو GitHub Pages أو Cloudflare Pages)، افتح الرابط من الموبايل، ثم "إضافة إلى الشاشة الرئيسية".

## 2) ملف APK (أندرويد)
```
npm install
npx cap add android
npm run android   # يفتح Android Studio، ثم Build > Build APK
```

## ملاحظات
- مكتبة 3D (three.js r128) بتتحمل من الإنترنت. للعمل الكامل بدون إنترنت في الـ APK: نزّل `three.min.js` في `www/lib/` وغيّر وسم `<script src=...>` في `index.html`.
- الأسعار بتتحفظ على الجهاز نفسه (localStorage). كلمة سر تعديل الأسعار 99999 مكتوبة داخل الكود، فهي مش حماية حقيقية.
- الألوان X1–X7 للعرض فقط وليست أكواد كتالوج. الأكواد المعلّمة "غير مؤكد" محتاجة مراجعة.
- أسعار الأكواد فاضية بانتظار ملف الأسعار.
