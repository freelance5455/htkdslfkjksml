# Stick Maudit Android
Ouvre ce dossier dans Android Studio puis Build > Build APK(s).
Le jeu est dans app/src/main/assets/Stick_Maudit.html.
