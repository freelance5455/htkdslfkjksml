package com.stickmaudit.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
public class MainActivity extends Activity {
  public void onCreate(Bundle b) {
    super.onCreate(b);
    WebView w=new WebView(this);
    WebSettings s=w.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    s.setAllowContentAccess(true);
    w.setWebViewClient(new WebViewClient());
    w.loadUrl("file:///android_asset/Stick_Maudit.html");
    setContentView(w);
  }
}
