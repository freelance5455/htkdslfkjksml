DATA X USER V88 — DEEP SESSION EARNING BALANCE FIX

ROOT CAUSE FOUND:
V87 keeps users/{uid}/balance protected by the hardened Firebase Rules. Therefore the persistent balance update must be performed by the trusted Firebase Function. V88 makes that backend trigger compatible and adds deterministic claim + stopped-session recovery.

V88:
• Realtime Database triggers use the broadly compatible Firebase Functions v1 handlers.
• One deterministic earning claim per stopped session: SESSION_<sessionId>.
• Stopped sessions without a processed claim are recovered on login.
• Pending claims get multiple trusted-function retries.
• Server validates stopped session, duration, MB, level rate and earning before changing balance.
• Balance is changed only by the Firebase Admin SDK under the included hardened rules.
• Activation popup includes Contact Telegram @DATAXPROO.

DEPLOY BOTH site and Functions. For the persistent balance fix, do not upload only index.html while the hardened rules are active.

Firebase command:
firebase deploy --only functions,database
