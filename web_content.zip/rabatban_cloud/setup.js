'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const DATA = path.join(__dirname, 'data');
const ADMIN = path.join(DATA, 'admin.json');
fs.mkdirSync(DATA, { recursive: true });

function save(password) {
  if (typeof password !== 'string' || password.length < 10) {
    console.error('رمز باید دست‌کم ۱۰ نویسه داشته باشد.');
    process.exit(1);
  }
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 210000, 32, 'sha256').toString('hex');
  fs.writeFileSync(ADMIN, JSON.stringify({ salt, hash, createdAt: new Date().toISOString() }, null, 2), { mode: 0o600 });
  try { fs.chmodSync(ADMIN, 0o600); } catch {}
  console.log('رمز مدیر با موفقیت ذخیره شد.');
  console.log('برای اجرا: bash start.sh');
}

if (fs.existsSync(ADMIN)) {
  console.log('برای این پروژه رمز مدیر از قبل تنظیم شده است.');
  console.log('اگر فراموشش کرده‌ای، فایل data/admin.json را فقط پس از پشتیبان‌گیری حذف کن و دوباره node setup.js را اجرا کن.');
  process.exit(0);
}

if (process.env.BOT_KEEPER_ADMIN_PASSWORD) {
  save(process.env.BOT_KEEPER_ADMIN_PASSWORD);
} else {
  if (!process.stdin.isTTY || typeof process.stdin.setRawMode !== 'function') {
    console.error('برای ساخت رمز، setup را در ترمینال تعاملی اجرا کن؛ یا از متغیر BOT_KEEPER_ADMIN_PASSWORD استفاده کن.');
    process.exit(1);
  }
  process.stdout.write('یک رمز مدیر محلی (حداقل ۱۰ نویسه) انتخاب کن؛ هنگام تایپ نمایش داده نمی‌شود: ');
  process.stdin.setRawMode(true);
  process.stdin.resume();
  let password = '';
  process.stdin.on('data', chunk => {
    for (const c of chunk.toString('utf8')) {
      if (c === '\u0003') { process.stdout.write('\nلغو شد.\n'); process.exit(130); }
      if (c === '\r' || c === '\n') {
        process.stdin.setRawMode(false); process.stdin.pause(); process.stdout.write('\n'); save(password); return;
      }
      if (c === '\u007f' || c === '\b') { password = password.slice(0, -1); continue; }
      if (c >= ' ' && c !== '\u007f') password += c;
    }
  });
}
