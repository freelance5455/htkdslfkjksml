#!/bin/sh
set -eu
cd /app
mkdir -p data/bots logs
if [ ! -f data/admin.json ]; then
  if [ -z "${BOT_KEEPER_ADMIN_PASSWORD:-}" ]; then
    echo 'ERROR: set BOT_KEEPER_ADMIN_PASSWORD in .env before first start.' >&2
    exit 1
  fi
  node setup.js
fi
exec node server.js
