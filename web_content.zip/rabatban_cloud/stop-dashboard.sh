#!/data/data/com.termux/files/usr/bin/bash
set -eu
cd "$(dirname "$0")"
if [ -f data/server.pid ]; then
  PID="$(cat data/server.pid)"
  if kill -0 "$PID" 2>/dev/null; then kill "$PID" || true; fi
  rm -f data/server.pid
  echo "داشبورد متوقف شد. پردازش ربات‌های جداشده ممکن است همچنان کار کند. برای توقف هر ربات از پنل استفاده کن."
else
  echo "فایل PID داشبورد پیدا نشد."
fi
