#!/data/data/com.termux/files/usr/bin/bash
# Optional: copy this script into ~/.termux/boot/ and adjust the project path.
sleep 20
cd "$HOME/storage/downloads/telegram_bot_keeper" || exit 1
bash start.sh
