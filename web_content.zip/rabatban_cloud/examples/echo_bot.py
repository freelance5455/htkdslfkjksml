"""Minimal example. Add pyTelegramBotAPI in the dependencies box."""
import os
import telebot

BOT_TOKEN = os.environ["BOT_TOKEN"]
bot = telebot.TeleBot(BOT_TOKEN)

@bot.message_handler(commands=["start"])
def start(message):
    bot.reply_to(message, "سلام! ربات با موفقیت روشن شد ✅")

@bot.message_handler(func=lambda message: True)
def echo(message):
    bot.reply_to(message, f"پیامت را دریافت کردم: {message.text or '[پیام غیرمتنی]'}")

bot.infinity_polling(skip_pending=True)
