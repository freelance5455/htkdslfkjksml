#!/data/data/com.termux/files/usr/bin/bash
set -eu
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js نصب نیست. در Termux اجرا کن: pkg install nodejs-lts"
  exit 1
fi
if ! command -v python >/dev/null 2>&1; then
  echo "Python نصب نیست. در Termux اجرا کن: pkg install python"
  exit 1
fi
if [ ! -f data/admin.json ]; then
  node setup.js
fi
mkdir -p data/bots logs
if command -v termux-wake-lock >/dev/null 2>&1; then termux-wake-lock || true; fi
if [ -f data/server.pid ] && kill -0 "$(cat data/server.pid)" 2>/dev/null; then
  echo "ربات‌بان از قبل اجراست: http://127.0.0.1:8787"
  exit 0
fi
nohup node server.js >> logs/server.log 2>&1 < /dev/null &
echo $! > data/server.pid
sleep 1
if kill -0 "$(cat data/server.pid)" 2>/dev/null; then
  echo "ربات‌بان اجرا شد. در مرورگر همین گوشی باز کن: http://127.0.0.1:8787"
  echo "برای آنکه در پس‌زمینه بماند، Termux را Force stop نکن و محدودیت باتری را بردار."
else
  echo "سرور شروع نشد. گزارش: logs/server.log"
  tail -n 30 logs/server.log || true
  exit 1
fi
