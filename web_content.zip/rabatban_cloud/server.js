'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawn } = require('node:child_process');

const ROOT = __dirname;
const DATA = path.join(ROOT, 'data');
const BOTS = path.join(DATA, 'bots');
const ADMIN_PATH = path.join(DATA, 'admin.json');
const HOST = process.env.HOST || '127.0.0.1';
const COOKIE_SECURE = process.env.COOKIE_SECURE === '1';
const PORT = Number(process.env.PORT || 8787);
const MAX_BODY = 1_500_000;
const sessions = new Map();
const loginFailures = new Map();

fs.mkdirSync(BOTS, { recursive: true });

function send(res, status, data, headers = {}) {
  const body = typeof data === 'string' ? data : JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': typeof data === 'string' ? 'text/html; charset=utf-8' : 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'no-referrer',
    'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; form-action 'self'; frame-ancestors 'none'",
    ...headers
  });
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = ''; let size = 0;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > MAX_BODY) { reject(Object.assign(new Error('درخواست بیش از حد بزرگ است.'), { status: 413 })); req.destroy(); return; }
      raw += chunk.toString('utf8');
    });
    req.on('end', () => {
      try { resolve(raw ? JSON.parse(raw) : {}); }
      catch { reject(Object.assign(new Error('دادهٔ ارسالی معتبر نیست.'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}
function parseCookies(req) {
  const out = {};
  for (const bit of (req.headers.cookie || '').split(';')) {
    const i = bit.indexOf('='); if (i > 0) out[bit.slice(0, i).trim()] = decodeURIComponent(bit.slice(i + 1).trim());
  }
  return out;
}
function authed(req) {
  const sid = parseCookies(req).sid;
  if (!sid) return false;
  const expiry = sessions.get(sid);
  if (!expiry || expiry < Date.now()) { sessions.delete(sid); return false; }
  sessions.set(sid, Date.now() + 12 * 60 * 60 * 1000);
  return true;
}
function originOkay(req) {
  const origin = req.headers.origin;
  if (!origin) return true; // clients outside browsers may omit Origin; server is loopback-only.
  try { return new URL(origin).host === req.headers.host; } catch { return false; }
}
function safeId(id) { return /^[a-f0-9]{16,32}$/.test(id); }
function botDir(id) { return path.join(BOTS, id); }
function readManifest(id) {
  try { return JSON.parse(fs.readFileSync(path.join(botDir(id), 'bot.json'), 'utf8')); } catch { return null; }
}
function writeManifest(id, manifest) {
  const file = path.join(botDir(id), 'bot.json');
  fs.writeFileSync(file, JSON.stringify(manifest, null, 2), { mode: 0o600 });
  try { fs.chmodSync(file, 0o600); } catch {}
}
function pidRunning(pid) {
  if (!Number.isInteger(pid) || pid < 2) return false;
  try { process.kill(pid, 0); return true; } catch { return false; }
}
function getBotStatus(m) {
  if (m.status === 'installing') return 'installing';
  if (m.status === 'error') return 'error';
  if (m.pid && pidRunning(m.pid)) return 'running';
  if (m.status === 'stopped') return 'stopped';
  return 'stopped';
}
function listBots() {
  let dirs = [];
  try { dirs = fs.readdirSync(BOTS, { withFileTypes: true }).filter(x => x.isDirectory()).map(x => x.name); } catch {}
  return dirs.map(id => {
    const m = readManifest(id); if (!m) return null;
    const status = getBotStatus(m);
    if (status !== m.status && !['installing', 'error', 'stopped'].includes(m.status)) { m.status = status; writeManifest(id, m); }
    return { id, name: m.name, platform: m.platform || 'telegram', username: m.username || '', status, createdAt: m.createdAt, lastError: m.lastError || '' };
  }).filter(Boolean).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}
function redactLog(id, text) {
  try {
    const token = fs.readFileSync(path.join(botDir(id), '.token'), 'utf8').trim();
    if (token) return text.split(token).join('[TOKEN HIDDEN]');
  } catch {}
  return text;
}
function tokenValidShape(platform, token) {
  if (platform === 'telegram' || platform === 'bale') return /^\d{5,}:[A-Za-z0-9_-]{15,}$/.test(token);
  if (platform === 'splus' || platform === 'rubika') return token.length >= 10 && token.length <= 512 && !/\s/.test(token);
  return false;
}
async function checkBotToken(platform, token) {
  const bases = { telegram: 'https://api.telegram.org/bot', bale: 'https://tapi.bale.ai/bot', splus: 'https://api.splus.ir/bot', rubika: 'https://botapi.rubika.ir/v3/' };
  const labels = { telegram: 'تلگرام', bale: 'بله', splus: 'سروش‌پلاس', rubika: 'روبیکا' };
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);
  try {
    const r = await fetch(`${bases[platform]}${token}/getMe`, { signal: controller.signal });
    const data = await r.json().catch(() => ({}));
    if (!r.ok || data.ok === false || (!data.result && !data.user)) return { ok: false, message: `${labels[platform]} توکن را تأیید نکرد. توکن و API پلتفرم را بررسی کن.` };
    return { ok: true, result: data.result || data.user || {} };
  } catch {
    return { ok: false, message: `به API ${labels[platform]} وصل نشدیم. اینترنت، دسترسی شبکه و آدرس API را بررسی کن. این خطا لزوماً به معنی اشتباه بودن توکن نیست.` };
  } finally { clearTimeout(timer); }
}
function cleanName(value) {
  const s = String(value || '').trim().replace(/[^\p{L}\p{N} _.-]/gu, '').slice(0, 32).trim();
  return s.length >= 2 ? s : '';
}
function validateRequirements(input) {
  if (!String(input || '').trim()) return [];
  const lines = String(input).split(/\r?\n/).map(x => x.trim()).filter(Boolean);
  if (lines.length > 25) throw new Error('حداکثر ۲۵ وابستگی می‌توانی اضافه کنی.');
  const valid = /^[A-Za-z0-9][A-Za-z0-9_.-]*(?:(?:==|>=|<=|~=|!=)[A-Za-z0-9*.+_-]+)?$/;
  if (lines.some(x => !valid.test(x))) throw new Error('فهرست کتابخانه‌ها معتبر نیست. هر خط فقط نام بسته و نسخه مانند python-telegram-bot==21.6 باشد.');
  return [...new Set(lines)];
}
function prepareCode(code, token) {
  let result = String(code);
  // Replace common top-level token assignments with an environment lookup.
  result = result.replace(/(^|\n)([ \t]*)(?:BOT_TOKEN|TOKEN|token)([ \t]*=[ \t]*)(['"])[^\r\n]*?\5/gm,
    '$1$2BOT_TOKEN$3os.environ["BOT_TOKEN"]');
  // Also replace exact token string literals where source uses it directly in a constructor.
  const escaped = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  try { result = result.replace(new RegExp(`(["'])${escaped}\\1`, 'g'), 'os.environ["BOT_TOKEN"]'); } catch {}
  // Keep an existing shebang/coding declaration at the top where possible.
  const lines = result.split('\n');
  let insertAt = 0;
  if (lines[0] && lines[0].startsWith('#!')) insertAt = 1;
  if (lines[insertAt] && /^#.*coding[:=]\s*[-\w.]+/.test(lines[insertAt])) insertAt++;
  if (!/^\s*(?:import\s+os\b|from\s+os\s+import\b)/m.test(result)) lines.splice(insertAt, 0, 'import os  # token is supplied privately by the runner');
  return lines.join('\n');
}
function runCommand(command, args, cwd, logFile, env = process.env) {
  return new Promise(resolve => {
    let fd;
    try { fd = fs.openSync(logFile, 'a'); }
    catch { resolve({ code: 1, error: 'نمی‌توان فایل گزارش را باز کرد.' }); return; }
    let child;
    try { child = spawn(command, args, { cwd, env, stdio: ['ignore', fd, fd] }); }
    catch (e) { try { fs.closeSync(fd); } catch {} resolve({ code: 1, error: e.message }); return; }
    child.on('error', e => { try { fs.closeSync(fd); } catch {} resolve({ code: 1, error: e.message }); });
    child.on('close', code => { try { fs.closeSync(fd); } catch {} resolve({ code: code ?? 1 }); });
  });
}
function startDetachedBot(id, m) {
  const dir = botDir(id);
  const requirements = fs.readFileSync(path.join(dir, 'requirements.txt'), 'utf8').trim();
  const py = requirements ? path.join(dir, '.venv', 'bin', 'python') : (process.env.PYTHON || 'python');
  const token = fs.readFileSync(path.join(dir, '.token'), 'utf8').trim();
  const logfile = path.join(dir, 'bot.log');
  const fd = fs.openSync(logfile, 'a');
  const child = spawn(py, [path.join(dir, 'main.py')], {
    cwd: dir,
    env: { ...process.env, BOT_TOKEN: token, PYTHONUNBUFFERED: '1' },
    detached: true,
    stdio: ['ignore', fd, fd]
  });
  child.once('error', err => {
    try { fs.closeSync(fd); } catch {}
    const latest = readManifest(id) || m;
    latest.pid = null; latest.status = 'error'; latest.lastError = `اجرای پایتون شروع نشد: ${err.message}`; writeManifest(id, latest);
  });
  child.once('spawn', () => {
    try { fs.closeSync(fd); } catch {}
    child.unref();
    const latest = readManifest(id) || m;
    latest.pid = child.pid; latest.status = 'running'; latest.lastError = ''; latest.startedAt = new Date().toISOString();
    writeManifest(id, latest);
  });
}
async function provisionBot(id) {
  const dir = botDir(id);
  let m = readManifest(id); if (!m) return;
  const reqFile = path.join(dir, 'requirements.txt');
  const requirements = fs.readFileSync(reqFile, 'utf8').trim();
  if (requirements) {
    m.status = 'installing'; writeManifest(id, m);
    const logFile = path.join(dir, 'bot.log');
    const venv = await runCommand(process.env.PYTHON || 'python', ['-m', 'venv', '.venv'], dir, logFile, process.env);
    if (venv.code !== 0) {
      m = readManifest(id) || m; m.status = 'error'; m.lastError = 'ساخت محیط پایتون ناموفق بود؛ گزارش را بررسی کن.'; writeManifest(id, m); return;
    }
    m = readManifest(id); if (!m || m.status === 'stopped') return;
    const pip = path.join(dir, '.venv', 'bin', 'python');
    const install = await runCommand(pip, ['-m', 'pip', 'install', '--disable-pip-version-check', '-r', reqFile], dir, logFile, { ...process.env, PIP_NO_INPUT: '1' });
    if (install.code !== 0) {
      m = readManifest(id) || m; m.status = 'error'; m.lastError = 'نصب کتابخانه‌ها ناموفق بود؛ گزارش اجرا را باز کن.'; writeManifest(id, m); return;
    }
    m = readManifest(id); if (!m || m.status === 'stopped') return;
  }
  m = readManifest(id) || m;
  if (m.status === 'stopped') return;
  startDetachedBot(id, m);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || '127.0.0.1'}`);
  const route = url.pathname;
  if (req.method === 'GET' && route === '/') {
    try { return send(res, 200, fs.readFileSync(path.join(ROOT, 'public', 'index.html'), 'utf8')); }
    catch { return send(res, 500, 'فایل رابط کاربری پیدا نشد.'); }
  }
  if (!route.startsWith('/api/')) return send(res, 404, { error: 'مسیر پیدا نشد.' });
  if (!originOkay(req)) return send(res, 403, { error: 'درخواست از مبدأ غیرمجاز رد شد.' });

  if (req.method === 'POST' && route === '/api/login') {
    const remote = req.socket.remoteAddress || 'local';
    const rec = loginFailures.get(remote) || { count: 0, until: 0 };
    if (rec.until > Date.now()) return send(res, 429, { error: 'چند لحظه صبر کن و دوباره تلاش کن.' });
    try {
      const body = await readBody(req);
      const stored = JSON.parse(fs.readFileSync(ADMIN_PATH, 'utf8'));
      const candidate = crypto.pbkdf2Sync(String(body.password || ''), stored.salt, 210000, 32, 'sha256');
      const expected = Buffer.from(stored.hash, 'hex');
      const ok = candidate.length === expected.length && crypto.timingSafeEqual(candidate, expected);
      if (!ok) {
        rec.count += 1; if (rec.count >= 6) { rec.count = 0; rec.until = Date.now() + 60_000; }
        loginFailures.set(remote, rec);
        return send(res, 401, { error: 'رمز مدیر اشتباه است.' });
      }
      loginFailures.delete(remote);
      const sid = crypto.randomBytes(32).toString('hex'); sessions.set(sid, Date.now() + 12 * 60 * 60 * 1000);
      return send(res, 200, { ok: true }, { 'Set-Cookie': `sid=${sid}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200${COOKIE_SECURE ? '; Secure' : ''}` });
    } catch (e) { return send(res, e.status || 500, { error: e.status ? e.message : 'رمز مدیر هنوز تنظیم نشده؛ اول node setup.js را اجرا کن.' }); }
  }
  if (req.method === 'POST' && route === '/api/logout') {
    const sid = parseCookies(req).sid; if (sid) sessions.delete(sid);
    return send(res, 200, { ok: true }, { 'Set-Cookie': `sid=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0${COOKIE_SECURE ? '; Secure' : ''}` });
  }
  if (!authed(req)) return send(res, 401, { error: 'ابتدا وارد پنل شو.' });
  if (req.method === 'POST' && route === '/api/change-password') {
    try {
      const body = await readBody(req);
      const stored = JSON.parse(fs.readFileSync(ADMIN_PATH, 'utf8'));
      const current = crypto.pbkdf2Sync(String(body.currentPassword || ''), stored.salt, 210000, 32, 'sha256');
      const expected = Buffer.from(stored.hash, 'hex');
      if (current.length !== expected.length || !crypto.timingSafeEqual(current, expected)) return send(res, 401, { error: 'رمز فعلی اشتباه است.' });
      const next = String(body.newPassword || '');
      if (next.length < 10 || next.length > 200) return send(res, 400, { error: 'رمز جدید باید بین ۱۰ تا ۲۰۰ نویسه باشد.' });
      const salt = crypto.randomBytes(16).toString('hex');
      const hash = crypto.pbkdf2Sync(next, salt, 210000, 32, 'sha256').toString('hex');
      fs.writeFileSync(ADMIN_PATH, JSON.stringify({ salt, hash, updatedAt: new Date().toISOString() }, null, 2), { mode: 0o600 });
      try { fs.chmodSync(ADMIN_PATH, 0o600); } catch {}
      return send(res, 200, { ok: true, message: 'رمز مدیر با موفقیت تغییر کرد.' });
    } catch { return send(res, 500, { error: 'تغییر رمز انجام نشد.' }); }
  }

  if (req.method === 'GET' && route === '/api/bots') return send(res, 200, { bots: listBots() });

  if (req.method === 'POST' && route === '/api/bots') {
    try {
      const body = await readBody(req);
      const name = cleanName(body.name);
      const platform = String(body.platform || 'telegram');
      const code = String(body.code || '');
      const token = String(body.token || '').trim();
      if (!name) return send(res, 400, { error: 'برای ربات یک نام ۲ تا ۳۲ نویسه‌ای وارد کن.' });
      if (!code.trim()) return send(res, 400, { error: 'کد پایتون ربات را وارد کن.' });
      if (Buffer.byteLength(code, 'utf8') > 1_000_000) return send(res, 413, { error: 'حجم کد بیشتر از حد مجاز است (۱ مگابایت).' });
      if (!['telegram', 'bale', 'splus', 'rubika'].includes(platform)) return send(res, 400, { error: 'پلتفرم انتخاب‌شده پشتیبانی نمی‌شود.' });
      if (!tokenValidShape(platform, token)) return send(res, 400, { error: 'قالب توکن با پلتفرم انتخابی سازگار نیست؛ توکن را دوباره بررسی کن.' });
      let requirements;
      try { requirements = validateRequirements(body.requirements); }
      catch (e) { return send(res, 400, { error: e.message }); }
      const checked = await checkBotToken(platform, token);
      if (!checked.ok) return send(res, 400, { error: checked.message });
      const id = crypto.randomBytes(10).toString('hex');
      const dir = botDir(id); fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
      const patched = prepareCode(code, token);
      fs.writeFileSync(path.join(dir, 'main.py'), patched, { mode: 0o600 });
      fs.writeFileSync(path.join(dir, '.token'), token + '\n', { mode: 0o600 });
      fs.writeFileSync(path.join(dir, 'requirements.txt'), requirements.join('\n') + (requirements.length ? '\n' : ''), { mode: 0o600 });
      const manifest = { id, name, platform, username: checked.result.username || '', status: requirements.length ? 'installing' : 'starting', pid: null, createdAt: new Date().toISOString(), lastError: '' };
      writeManifest(id, manifest);
      provisionBot(id).catch(err => {
        const m = readManifest(id); if (m) { m.status = 'error'; m.lastError = 'خطای داخلی هنگام آماده‌سازی ربات.'; writeManifest(id, m); }
        fs.appendFileSync(path.join(dir, 'bot.log'), `\n[keeper] ${String(err.message || err)}\n`);
      });
      return send(res, 201, { ok: true, bot: { id, name, username: manifest.username, status: manifest.status }, message: `توکن پلتفرم انتخابی تأیید شد؛ ربات در حال آماده‌شدن است. کد و کتابخانه‌ها باید مخصوص ${({telegram:'تلگرام',bale:'بله',splus:'سروش‌پلاس',rubika:'روبیکا'})[platform]} باشند.` });
    } catch (e) { return send(res, e.status || 500, { error: e.status ? e.message : 'ایجاد ربات ناموفق بود.' }); }
  }

  let match = route.match(/^\/api\/bots\/([a-f0-9]{16,32})(?:\/(stop|restart|log))?$/);
  if (match) {
    const [, id, action] = match;
    const m = readManifest(id); if (!m) return send(res, 404, { error: 'ربات پیدا نشد.' });
    if (req.method === 'GET' && action === 'log') {
      let content = ''; try { content = fs.readFileSync(path.join(botDir(id), 'bot.log'), 'utf8'); } catch {}
      const lines = content.split(/\r?\n/).slice(-250).join('\n');
      return send(res, 200, { log: redactLog(id, lines) });
    }
    if (req.method === 'POST' && (action === 'stop' || action === 'restart')) {
      if (m.pid && pidRunning(m.pid)) {
        try { process.kill(-m.pid, 'SIGTERM'); } catch { try { process.kill(m.pid, 'SIGTERM'); } catch {} }
      }
      m.pid = null; m.status = 'stopped'; m.lastError = ''; writeManifest(id, m);
      if (action === 'restart') {
        m.status = 'starting'; writeManifest(id, m);
        setTimeout(() => {
          const latest = readManifest(id); if (latest) provisionBot(id).catch(() => {});
        }, 700);
      }
      return send(res, 200, { ok: true, status: action === 'restart' ? 'starting' : 'stopped' });
    }
    if (req.method === 'DELETE' && !action) {
      if (m.pid && pidRunning(m.pid)) {
        try { process.kill(-m.pid, 'SIGTERM'); } catch { try { process.kill(m.pid, 'SIGTERM'); } catch {} }
      }
      fs.rmSync(botDir(id), { recursive: true, force: true });
      return send(res, 200, { ok: true });
    }
  }
  return send(res, 404, { error: 'مسیر یا روش پشتیبانی نمی‌شود.' });
});

server.on('error', err => {
  console.error(err.code === 'EADDRINUSE' ? `پورت ${PORT} اشغال است؛ سرور قبلی را بررسی کن.` : err.message);
  process.exit(1);
});
server.listen(PORT, HOST, () => {
  console.log('Rabatban Cloud — dashboard running');
  console.log(`Listening on ${HOST}:${PORT}`);
  // Re-launch bots after a VPS/container restart, except bots the admin explicitly stopped.
  for (const item of listBots()) {
    if (item.status === 'stopped') continue;
    const m = readManifest(item.id);
    if (!m) continue;
    m.pid = null; m.status = 'starting'; m.lastError = ''; writeManifest(item.id, m);
    setTimeout(() => provisionBot(item.id).catch(err => {
      const latest = readManifest(item.id);
      if (latest) { latest.status = 'error'; latest.lastError = 'راه‌اندازی پس از شروع سرور ناموفق بود.'; writeManifest(item.id, latest); }
      try { fs.appendFileSync(path.join(botDir(item.id), 'bot.log'), `\n[cloud-restart] ${String(err.message || err)}\n`); } catch {}
    }), 1500);
  }
});
