// Depois de `npx cap add android`: força paisagem + tela cheia imersiva no app (manifesto E código nativo).
import fs from 'fs';
import path from 'path';
const man = 'android/app/src/main/AndroidManifest.xml';
const sty = 'android/app/src/main/res/values/styles.xml';
try {
  let m = fs.readFileSync(man, 'utf8');
  if (/android:screenOrientation="[^"]*"/.test(m)) m = m.replace(/android:screenOrientation="[^"]*"/, 'android:screenOrientation="sensorLandscape"');
  else m = m.replace(/<activity\b/, '<activity\n            android:screenOrientation="sensorLandscape"');
  m = m.replace(/android:configChanges="([^"]*)"/, (a, v) => {
    const s = new Set(v.split('|').filter(Boolean));
    ['orientation', 'screenSize', 'smallestScreenSize', 'screenLayout', 'keyboard', 'keyboardHidden', 'navigation', 'uiMode'].forEach((x) => s.add(x));
    return 'android:configChanges="' + [...s].join('|') + '"';
  });
  fs.writeFileSync(man, m); console.log('AndroidManifest.xml: paisagem ok');
} catch (e) { console.log('Aviso (manifest):', e.message); }
try {
  let s = fs.readFileSync(sty, 'utf8');
  if (!s.includes('windowFullscreen')) s = s.replace(/(<style name="AppTheme\.NoActionBar"[^>]*>)/, '$1\n        <item name="android:windowFullscreen">true</item>\n        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>');
  fs.writeFileSync(sty, s); console.log('styles.xml: tela cheia ok');
} catch (e) { console.log('Aviso (styles):', e.message); }
// MainActivity: trava paisagem por código (garante mesmo se o manifesto mudar) e esconde as barras do sistema
function find(dir) {
  for (const f of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, f.name);
    if (f.isDirectory()) { const r = find(p); if (r) return r; }
    else if (f.name === 'MainActivity.java') return p;
  }
}
try {
  const file = find('android/app/src/main/java');
  if (!file) throw new Error('MainActivity.java não encontrado');
  const pkg = (fs.readFileSync(file, 'utf8').match(/^package\s+([\w.]+);/m) || [])[1];
  fs.writeFileSync(file, `package ${pkg};

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
    super.onCreate(savedInstanceState);
  }

  @Override
  public void onWindowFocusChanged(boolean hasFocus) {
    super.onWindowFocusChanged(hasFocus);
    if (hasFocus) {
      getWindow().getDecorView().setSystemUiVisibility(
        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }
  }
}
`);
  console.log('MainActivity.java: paisagem + imersivo ok');
} catch (e) { console.log('Aviso (MainActivity):', e.message); }
