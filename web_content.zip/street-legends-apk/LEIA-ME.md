# Street Legends — transformar em APK

O jogo inteiro é o arquivo `www/index.html` (um único HTML, sem internet, sem dependências).
Este projeto usa o **Capacitor 6** para embrulhar o HTML num app Android (WebView em tela cheia, paisagem).

## Opção A — sem instalar nada (GitHub Actions)
1. Crie um repositório no GitHub e envie **todo o conteúdo desta pasta** (inclusive `.github`).
2. Abra a aba **Actions → Gerar APK → Run workflow**.
3. Quando terminar (~5 min), baixe o artefato **street-legends-apk** → dentro está o `app-debug.apk`.
4. Copie para o celular, permita "instalar apps desconhecidos" e instale.

## Opção B — no seu computador
Requisitos: Node 20+, JDK 17 e Android Studio (ou só o Android SDK).
```bash
npm install
npm run android:add     # cria a pasta android/, força paisagem e tela cheia
npm run android:apk     # gera android/app/build/outputs/apk/debug/app-debug.apk
# ou: npm run android:open  (abre no Android Studio e use Build > Build APK)
```

## Atualizar o jogo depois
Troque `www/index.html` pelo novo HTML e rode `npm run android:sync` (e gere o APK de novo).

## Para publicar na Play Store
Gere um **AAB assinado** no Android Studio (Build > Generate Signed Bundle) com sua própria chave.
Troque `appId` em `capacitor.config.json` por um identificador seu.

## Alternativa sem Capacitor
Hospede o HTML em qualquer site HTTPS e use o PWABuilder (pwabuilder.com) para gerar o pacote Android.

## Paisagem automática
O script `scripts/patch-android.mjs` (rodado por `npm run android:add`) trava o app em paisagem no manifesto e na MainActivity e esconde as barras do sistema.
