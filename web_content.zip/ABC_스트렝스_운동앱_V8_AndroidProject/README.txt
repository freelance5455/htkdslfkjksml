ABC 스트렝스 코치 V8 - Android WebView 프로젝트

기존 V7 HTML을 Android 앱의 assets/index.html로 포함하고 WebView에서 file:///android_asset/index.html로 직접 로딩하도록 수정한 버전입니다.

Android Studio에서 이 폴더를 열고 Gradle Sync 후 Build > Build APK(s)를 선택하세요.

핵심 수정:
- HTML을 외부 파일로 열지 않고 APK 내부 assets에 포함
- JavaScript 활성화
- localStorage/DOM Storage 활성화
- WebViewClient 지정
- 세로 화면 기본
- 뒤로가기 처리
