Sunset Beach Gestão — Offline v3 (Modo Garçom)

Base preparada para empacotamento Android com WebView local.

Recursos adicionados nesta versão:
- Modo Garçom otimizado para celular
- Identificação do garçom
- Lançamento rápido de produtos por mesa
- Envio do pedido para a fila do caixa
- Ticket de impressão ao enviar o pedido
- Tela de Pedidos para o caixa conferir
- Reimpressão do pedido
- Envio do pedido para a cozinha com ticket
- Dados persistidos no aparelho

Importante: impressão física automática depende da impressora e da ponte de impressão do aplicativo Android. Esta versão abre a função de impressão do sistema/navegador e mantém a fila de pedidos no caixa.
