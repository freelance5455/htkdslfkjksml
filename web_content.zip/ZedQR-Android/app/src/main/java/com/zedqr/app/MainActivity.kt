package com.zedqr.app

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    // opens the system picker for <input type="file"> (logo, photo QR, image QR)
    private val fileChooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        filePathCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data))
        filePathCallback = null
    }

    // The page is served from the app's assets over https (needed for Supabase login + localStorage).
    private val startUrl = "https://appassets.androidplatform.net/assets/index.html"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#070707"))
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                cacheMode = WebSettings.LOAD_DEFAULT
                allowFileAccess = false
                allowContentAccess = false
                setSupportZoom(false)
                builtInZoomControls = false
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    view: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams
                ): Boolean {
                    filePathCallback?.onReceiveValue(null)
                    filePathCallback = callback
                    return try {
                        fileChooser.launch(params.createIntent())
                        true
                    } catch (e: Exception) {
                        filePathCallback = null
                        false
                    }
                }
            }
            addJavascriptInterface(ZedBridge(), "ZedApp")
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView, request: WebResourceRequest
                ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

                override fun shouldOverrideUrlLoading(
                    view: WebView, request: WebResourceRequest
                ): Boolean {
                    val uri = request.url
                    if (uri.host == "appassets.androidplatform.net") return false
                    return try {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                        true
                    } catch (e: Exception) {
                        true
                    }
                }
            }
        }
        setContentView(webView)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })

        if (savedInstanceState == null) webView.loadUrl(startUrl) else webView.restoreState(savedInstanceState)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    private fun t(fa: String, en: String): String =
        if (java.util.Locale.getDefault().language == "fa") fa else en

    private fun toast(msg: String) = runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }

    private fun decode(dataUrl: String): ByteArray? = try {
        Base64.decode(dataUrl.substringAfter("base64,"), Base64.DEFAULT)
    } catch (e: Exception) { null }

    private fun mimeOf(ext: String): String = when (ext) {
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "webp" -> "image/webp"
        "svg" -> "image/svg+xml"
        "zip" -> "application/zip"
        else -> "application/octet-stream"
    }

    private fun safeName(name: String): String =
        name.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "zed-qr.png" }

    /** Called from the page (JS runs on a background thread). */
    inner class ZedBridge {

        @JavascriptInterface
        fun save(name: String, dataUrl: String) {
            val bytes = decode(dataUrl)
            if (bytes == null) { toast(t("ذخیره نشد", "Could not save")); return }
            try {
                val safe = safeName(name)
                val ext = safe.substringAfterLast('.', "").lowercase()
                val isImage = ext in setOf("png", "jpg", "jpeg", "webp")
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, safe)
                    put(MediaStore.MediaColumns.MIME_TYPE, mimeOf(ext))
                    put(
                        MediaStore.MediaColumns.RELATIVE_PATH,
                        (if (isImage) Environment.DIRECTORY_PICTURES else Environment.DIRECTORY_DOWNLOADS) + "/ZED QR"
                    )
                }
                val collection = if (isImage) MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                                 else MediaStore.Downloads.EXTERNAL_CONTENT_URI
                val uri = contentResolver.insert(collection, values) ?: throw IllegalStateException("no uri")
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                toast(if (isImage) t("در گالری ذخیره شد (Pictures/ZED QR)", "Saved to gallery (Pictures/ZED QR)") else t("ذخیره شد (Download/ZED QR)", "Saved (Download/ZED QR)"))
            } catch (e: Exception) {
                toast(t("ذخیره نشد", "Could not save"))
            }
        }

        @JavascriptInterface
        fun share(name: String, dataUrl: String) {
            val bytes = decode(dataUrl)
            if (bytes == null) { toast(t("اشتراک‌گذاری نشد", "Could not share")); return }
            try {
                val dir = File(cacheDir, "shared").apply { mkdirs() }
                val file = File(dir, safeName(name)).apply { writeBytes(bytes) }
                val uri: Uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", file)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = mimeOf(safeName(name).substringAfterLast('.', "").lowercase())
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                runOnUiThread { startActivity(Intent.createChooser(send, "ZED QR")) }
            } catch (e: Exception) {
                toast(t("اشتراک‌گذاری نشد", "Could not share"))
            }
        }
    }
}
