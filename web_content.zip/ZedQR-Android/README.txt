ZED QR - Android (WebView app)

1) Install Android Studio (Koala or newer), then File > Open > select this folder.
2) Let Gradle sync (needs internet the first time).
3) Run on a phone/emulator, or Build > Build APK(s).

The app shows the website bundled in app/src/main/assets/index.html.
To update the app after you change the site: replace that file with your new index.html
(keep the "ZED QR Android bridge" block inside <head>) and rebuild.
Zed+ works automatically: it reads the same Supabase table as the site.


IMPORTANT FOR USERS IN IRAN (no VPN)
The app already works without the website: the page is bundled inside the app.
To make login / saving work without the CDNs (jsdelivr/unpkg may be filtered), bundle the Supabase library too:
  1) With a VPN, download:  https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.js
  2) Save it as  supabase.js  inside:  app/src/main/assets/   (next to index.html)
  3) Rebuild the app. The page loads that local copy first and never needs a CDN.
Login / saving still need supabase.co itself to be reachable from the phone's network.
