# My Video Manager v1

A phone-friendly offline prototype for organizing videos by topic.

Features:
- Topics
- Add multiple videos
- Automatic numbering
- Video preview
- Title + description
- Ready / Downloaded / Uploaded status
- Next Not Uploaded
- Search
- Quick Uploaded
- Local IndexedDB storage
- Installable as a PWA

Important: video blobs are stored locally in the browser/app storage. Very large libraries may exceed Android browser storage limits. Backup currently exports metadata, not video files.

To use on Android without coding: serve these files from a local/HTTPS web server, open index.html in Chrome, then use "Add to Home screen". For a real APK, wrap this web app in an Android WebView/TWA builder or compile it as an Android project.
